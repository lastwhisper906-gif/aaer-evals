# CARR notes — 0001783180-22-000048


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-22-000048:notes:1]
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation is the leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions. The Company's portfolio includes industry-leading brands such as Carrier, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring.

[0001783180-22-000048:notes:2]
[same as prior period, unchanged from 0001783180-22-000034:notes:2]

[0001783180-22-000048:notes:3]
[same as prior period, unchanged from 0001783180-22-000034:notes:3]

[0001783180-22-000048:notes:4]
[same as prior period, unchanged from 0001783180-22-000034:notes:4]


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-22-000048:notes:5]
BASIS OF PRESENTATION
The Unaudited Condensed Consolidated Financial Statements include all accounts of the Company and its wholly-owned and majority-owned subsidiaries in which it has control. All intra-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that the Company controls and consolidates.

[0001783180-22-000048:notes:6]
[same as prior period, unchanged from 0001783180-22-000034:notes:6]

[0001783180-22-000048:notes:7]
[same as prior period, unchanged from 0001783180-22-000034:notes:7]

[0001783180-22-000048:notes:8]
[same as prior period, unchanged from 0001783180-22-000034:notes:8]

[0001783180-22-000048:notes:9]
On April 3, 2020, United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of the Company into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. The Company incurred separation-related costs including employee-related costs, costs to establish certain stand-alone functions, information technology systems, professional service fees and other costs associated with becoming an independent, publicly traded company. These costs are primarily recorded in Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations and totaled $3 million and $19 million for the three and six months ended June 30, 2021, respectively.

[0001783180-22-000048:notes:10]
[same as prior period, unchanged from 0001783180-22-000034:notes:10]

[0001783180-22-000048:notes:11]
[same as prior period, unchanged from 0001783180-22-000034:notes:11]


## us-gaap:InventoryDisclosureTextBlock

[0001783180-22-000048:notes:12]
[same as prior period, unchanged from 0001783180-22-000034:notes:12]

[0001783180-22-000048:notes:13]
[same as prior period, unchanged from 0001783180-22-000034:notes:13]

[0001783180-22-000048:notes:14]
| (In millions) |  | June 30, 2022 |  | December 31, 2021 |
| Raw materials |  | $ | 701 |  |  | $ | 559 |  |
| Work-in-process |  | 243 |  |  | 197 |  |
| Finished goods |  | 1,406 |  |  | 1,214 |  |
| Inventories, net |  | $ | 2,350 |  |  | $ | 1,970 |  |

[0001783180-22-000048:notes:15]
The Company performs periodic assessments utilizing customer demand, production requirements and historical usage rates to determine the existence of excess and obsolete inventory and records necessary provisions to reduce such inventories to the lower of cost or estimated net realizable value. Raw materials, work-in-process and finished goods are net of valuation reserves of $151 million and $154 million as of June 30, 2022 and December 31, 2021, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-22-000048:notes:16]
[same as prior period, unchanged from 0001783180-22-000034:notes:16]

[0001783180-22-000048:notes:17]
[same as prior period, unchanged from 0001783180-22-000034:notes:17]

[0001783180-22-000048:notes:18]
| (In millions) |  |  | HVAC |  | Refrigeration |  | Fire & Security |  | Total |
| Balance as of December 31, 2021 |  |  | $ | 5,658 |  |  | $ | 1,228 |  |  | $ | 2,463 |  |  | $ | 9,349 |  |
| Goodwill resulting from business combinations (1) |  |  | 15 |  |  | — |  |  | 1 |  |  | 16 |  |
| Foreign currency translation |  |  | (162) |  |  | (39) |  |  | (97) |  |  | (298) |  |
| Balance as of June 30, 2022 |  |  | $ | 5,511 |  |  | $ | 1,189 |  |  | $ | 2,367 |  |  | $ | 9,067 |  |

[0001783180-22-000048:notes:19]
[same as prior period, unchanged from 0001783180-22-000034:notes:19]

[0001783180-22-000048:notes:20]
[same as prior period, unchanged from 0001783180-22-000034:notes:20]

[0001783180-22-000048:notes:21]
[same as prior period, unchanged from 0001783180-22-000034:notes:21]

[0001783180-22-000048:notes:22]
|  |  | June 30, 2022 |  | December 31, 2021 |
| (In millions) |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Amortized: |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 919 |  |  | $ | (701) |  |  | $ | 218 |  |  | $ | 945 |  |  | $ | (699) |  |  | $ | 246 |  |
| Patents and trademarks |  | 224 |  |  | (180) |  |  | 44 |  |  | 232 |  |  | (182) |  |  | 50 |  |
| Service portfolios and other |  | 672 |  |  | (540) |  |  | 132 |  |  | 688 |  |  | (539) |  |  | 149 |  |
|  |  | 1,815 |  |  | (1,421) |  |  | 394 |  |  | 1,865 |  |  | (1,420) |  |  | 445 |  |
| Unamortized: |  |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks and other |  | 64 |  |  | — |  |  | 64 |  |  | 64 |  |  | — |  |  | 64 |  |
| Intangible assets, net |  | $ | 1,879 |  |  | $ | (1,421) |  |  | $ | 458 |  |  | $ | 1,929 |  |  | $ | (1,420) |  |  | $ | 509 |  |

[0001783180-22-000048:notes:23]
Amortization of intangible assets was as follows:

[0001783180-22-000048:notes:24]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Amortization expense of Intangible assets |  | $ | 20 |  |  | $ | 25 |  |  | $ | 41 |  |  | $ | 49 |  |


## us-gaap:DebtDisclosureTextBlock

[0001783180-22-000048:notes:25]
BORROWINGS AND LINES OF CREDIT 
Long-term debt consisted of the following:

[0001783180-22-000048:notes:26]
| (In millions) |  |  |  | June 30,2022 |  | December 31,2021 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term Notes |  |  |  | 8,350 |  |  | 9,500 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 279 |  |  | 267 |  |
| Discounts and debt issuance costs |  |  |  | (62) |  |  | (71) |  |
| Total debt |  |  |  | 8,567 |  |  | 9,696 |  |
| Less: current portion of long-term debt |  |  |  | 269 |  |  | 183 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,298 |  |  | $ | 9,513 |  |

[0001783180-22-000048:notes:27]
Revolving Credit Facility

[0001783180-22-000048:notes:28]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements of the Company. A commitment fee of 0.125% is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate plus a ratings-based margin, which was 125 basis points as of June 30, 2022. As of June 30, 2022, there were no borrowings outstanding under the Revolving Credit Facility.

[0001783180-22-000048:notes:29]
Commercial Paper Program

[0001783180-22-000048:notes:30]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general

[0001783180-22-000048:notes:31]
corporate purposes, including the funding of working capital and potential acquisitions. As of June 30, 2022, there were no borrowings outstanding under the commercial paper program.

[0001783180-22-000048:notes:32]
Project Financing Arrangements

[0001783180-22-000048:notes:33]
The Company is involved in several long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $21 million and $71 million of debt during the six months ended June 30, 2022 and 2021, respectively. Long-term debt repayments associated with these financing arrangements during the six months ended June 30, 2022 and 2021 were $12 million and $83 million, respectively.

[0001783180-22-000048:notes:34]
Debt Covenants

[0001783180-22-000048:notes:35]
The Revolving Credit Facility and the indenture for the long-term Notes contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of June 30, 2022, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

[0001783180-22-000048:notes:36]
Tender Offers

[0001783180-22-000048:notes:37]
On March 15, 2022, the Company commenced tender offers to purchase up to $1.15 billion ("Aggregate Tender Cap") aggregate principal of the Company's 2.242% Notes due 2025 and 2.493% Notes due 2027 (together, the "Senior Notes"). The tender offers included payment of applicable accrued and unpaid interest up to the settlement date, along with a fixed spread for early repayment. Based on participation, the Company elected to settle the tender offers on March 30, 2022. The aggregate principal amount of Senior Notes validly tendered and accepted was approximately $1.15 billion, which included $800 million of Notes due 2025 and $350 million of Notes due 2027. As a result, the Company recognized a net gain of $33 million and wrote off $5 million of unamortized deferred financing costs within Interest (expense) income, net on the accompanying Unaudited Condensed Consolidated Statement of Operations during the three months ended March 31, 2022.


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-22-000048:notes:38]
[same as prior period, unchanged from 0001783180-22-000034:notes:36]

[0001783180-22-000048:notes:39]
[same as prior period, unchanged from 0001783180-22-000034:notes:37]

[0001783180-22-000048:notes:40]
[same as prior period, unchanged from 0001783180-22-000034:notes:38]

[0001783180-22-000048:notes:41]
[same as prior period, unchanged from 0001783180-22-000034:notes:39]

[0001783180-22-000048:notes:42]
[same as prior period, unchanged from 0001783180-22-000034:notes:40]

[0001783180-22-000048:notes:43]
[same as prior period, unchanged from 0001783180-22-000034:notes:41]

[0001783180-22-000048:notes:44]
[same as prior period, unchanged from 0001783180-22-000034:notes:42]

[0001783180-22-000048:notes:45]
[same as prior period, unchanged from 0001783180-22-000034:notes:43]

[0001783180-22-000048:notes:46]
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| June 30, 2022 |  |  |  |  |  |  |  |  |
| Derivative assets (1) |  | $ | 3 |  |  | $ | — |  |  | $ | 3 |  |  | $ | — |  |
| Derivative liabilities (2) |  | $ | (9) |  |  | $ | — |  |  | $ | (9) |  |  | $ | — |  |
| December 31, 2021 |  |  |  |  |  |  |  |  |
| Derivative assets (1) |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |  | $ | — |  |
| Derivative liabilities (2) |  | $ | (35) |  |  | $ | — |  |  | $ | (35) |  |  | $ | — |  |

[0001783180-22-000048:notes:47]
[same as prior period, unchanged from 0001783180-22-000034:notes:45]

[0001783180-22-000048:notes:48]
[same as prior period, unchanged from 0001783180-22-000034:notes:46]

[0001783180-22-000048:notes:49]
The following table provides the carrying amounts and fair values of the Company's long-term notes that are not recorded at fair value in the Unaudited Condensed Consolidated Balance Sheet:

[0001783180-22-000048:notes:50]
|  |  | June 30, 2022 |  | December 31, 2021 |  |
| (In millions) |  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  |
| Total long-term Notes (1) |  | $ | 8,350 |  |  | $ | 7,040 |  |  | $ | 9,500 |  |  | $ | 9,842 |  |  |

[0001783180-22-000048:notes:51]
[same as prior period, unchanged from 0001783180-22-000034:notes:49]

[0001783180-22-000048:notes:52]
The fair value of the Company's long-term debt is measured based on observable market inputs which are considered Level 1 within the fair value hierarchy. The carrying value of cash and cash equivalents, accounts receivable, accounts payable and short-term borrowings approximate fair value due to the short-term nature of these accounts and would be classified as Level 1 in the fair value hierarchy. The Company's financing leases and project financing obligations, included in Long-term debt and Current portion of long-term debt on the accompanying Unaudited Condensed Consolidated Balance Sheet, approximate fair value and are classified as Level 3 in the fair value hierarchy.


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001783180-22-000048:notes:53]
In the normal course of business, the Company is exposed to certain risks arising from business operations and economic factors, including foreign currency and commodity price risk. These exposures are managed through operational strategies and the use of undesignated hedging contracts. The Company's derivative assets and liabilities are measured at fair value on a recurring basis using internal models based on observable market inputs, such as forward, interest, contract and discount rates with changes in fair value reported directly in earnings. The fair value of the Company's long-term debt is measured based on observable market inputs which are considered Level 1 within the fair value hierarchy. The carrying value of cash and cash equivalents, accounts receivable, accounts payable and short-term borrowings approximate fair value due to the short-term nature of these accounts and would be classified as Level 1 in the fair value hierarchy. The Company's financing leases and project financing obligations, included in Long-term debt and Current portion of long-term debt on the accompanying Unaudited Condensed Consolidated Balance Sheet, approximate fair value and are classified as Level 3 in the fair value hierarchy.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-22-000048:notes:54]
[same as prior period, unchanged from 0001783180-22-000034:notes:52]

[0001783180-22-000048:notes:55]
[same as prior period, unchanged from 0001783180-22-000034:notes:53]

[0001783180-22-000048:notes:56]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2022 (1) |  | 2021 |  | 2022 (1) |  | 2021 |
| Defined benefit plans |  | $ | 2 |  |  | $ | 3 |  |  | $ | 6 |  |  | $ | 27 |  |
| Defined contribution plans |  | $ | 28 |  |  | $ | 30 |  |  | $ | 66 |  |  | $ | 67 |  |
| Multi-employer pension plans |  | $ | 3 |  |  | $ | 7 |  |  | $ | 6 |  |  | $ | 12 |  |

[0001783180-22-000048:notes:57]
[same as prior period, unchanged from 0001783180-22-000034:notes:55]

[0001783180-22-000048:notes:58]
[same as prior period, unchanged from 0001783180-22-000034:notes:56]

[0001783180-22-000048:notes:59]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2022 (1) |  | 2021 |  | 2022 (1) |  | 2021 |
| Service cost |  | $ | 4 |  |  | $ | 7 |  |  | $ | 9 |  |  | $ | 14 |  |
| Interest cost |  | 4 |  |  | 10 |  |  | 8 |  |  | 19 |  |
| Expected return on plan assets |  | (6) |  |  | (37) |  |  | (13) |  |  | (73) |  |
| Amortization of prior service credit |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Recognized actuarial net (gain) loss |  | 3 |  |  | 8 |  |  | 5 |  |  | 16 |  |
| Net periodic pension expense (benefit) |  | $ | 5 |  |  | $ | (12) |  |  | $ | 10 |  |  | $ | (23) |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001783180-22-000048:notes:60]
[same as prior period, unchanged from 0001783180-22-000034:notes:58]

[0001783180-22-000048:notes:61]
[same as prior period, unchanged from 0001783180-22-000034:notes:59]

[0001783180-22-000048:notes:62]
[same as prior period, unchanged from 0001783180-22-000034:notes:60]

[0001783180-22-000048:notes:63]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Equity compensation costs - equity settled |  | $ | 20 |  |  | $ | 21 |  |  | $ | 41 |  |  | $ | 40 |  |
| Equity compensation costs - cash settled (1) |  | (11) |  |  | 6 |  |  | (17) |  |  | 10 |  |
| Total stock-based compensation expense |  | $ | 9 |  |  | $ | 27 |  |  | $ | 24 |  |  | $ | 50 |  |

[0001783180-22-000048:notes:64]
[same as prior period, unchanged from 0001783180-22-000034:notes:62]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-22-000048:notes:65]
[same as prior period, unchanged from 0001783180-22-000034:notes:63]

[0001783180-22-000048:notes:66]
[same as prior period, unchanged from 0001783180-22-000034:notes:64]

[0001783180-22-000048:notes:67]
|  |  | For the Six Months Ended June 30, |
| (In millions) |  | 2022 |  | 2021 |
| Balance as of January 1, |  | $ | 524 |  |  | $ | 514 |  |
| Warranties, performance guarantees issued and changes in estimated liability |  | 84 |  |  | 89 |  |
| Settlements made |  | (78) |  |  | (80) |  |
| Other |  | (5) |  |  | — |  |
| Balance as of June 30, |  | $ | 525 |  |  | $ | 523 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-22-000048:notes:68]
EQUITY 
The authorized number of shares of common stock of Carrier is 4,000,000,000 shares of $0.01 par value. As of June 30, 2022 and December 31, 2021, 874,951,424 and 873,064,219 shares of common stock were issued, respectively, which includes 33,114,977 and 10,375,654 shares of treasury stock, respectively.

[0001783180-22-000048:notes:69]
[same as prior period, unchanged from 0001783180-22-000034:notes:67]

[0001783180-22-000048:notes:70]
The Company may repurchase its outstanding common stock from time to time subject to market conditions and at the Company's discretion in the open market or through one or more other public or private transactions and subject to compliance with the Company's obligations under certain tax agreements. Shares acquired are recognized at cost and presented separately on the balance sheet as a reduction to Equity. In July 2021, the Company's Board of Directors approved a $1.75 billion increase to the Company's existing $350 million share repurchase program authorizing the repurchase of up to $2.1 billion of the Company's outstanding common stock. During 2021, the Company repurchased 10.4 million shares of common stock for an aggregate purchase price of $529 million.

[0001783180-22-000048:notes:71]
[same as prior period, unchanged from 0001783180-22-000034:notes:69]

[0001783180-22-000048:notes:72]
During the six months ended June 30, 2022, the Company repurchased 22.7 million shares of common stock for an aggregate purchase price of $1.0 billion, which includes shares repurchased under the ASR Agreement. As of June 30, 2022, the Company has approximately $557 million remaining under the current authorization.

[0001783180-22-000048:notes:73]
[same as prior period, unchanged from 0001783180-22-000034:notes:71]

[0001783180-22-000048:notes:74]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three and six months ended June 30, 2022 and 2021 is as follows:

[0001783180-22-000048:notes:75]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2021 |  | $ | (505) |  |  | $ | (484) |  |  |  |  |  |  | $ | (989) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (61) |  |  | (4) |  |  |  |  |  |  | (65) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 3 |  |  |  |  |  |  | 3 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (1) |  |  |  |  |  |  | (1) |  |
| Divestitures, net |  | (574) |  |  | 329 |  |  |  |  |  |  | (245) |  |
| Balance as of March 31, 2022 |  | $ | (1,140) |  |  | $ | (157) |  |  |  |  |  |  | $ | (1,297) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (480) |  |  | — |  |  |  |  |  |  | (480) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 3 |  |  |  |  |  |  | 3 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (1) |  |  |  |  |  |  | (1) |  |
| Balance as of June 30, 2022 |  | $ | (1,620) |  |  | $ | (155) |  |  |  |  |  |  | $ | (1,775) |  |

[0001783180-22-000048:notes:76]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2020 |  | $ | (191) |  |  | $ | (554) |  |  |  |  |  |  | $ | (745) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (121) |  |  | — |  |  |  |  |  |  | (121) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 9 |  |  |  |  |  |  | 9 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (2) |  |  |  |  |  |  | (2) |  |
| Balance as of March 31, 2021 |  | $ | (312) |  |  | $ | (547) |  |  |  |  |  |  | $ | (859) |  |
| Other comprehensive income (loss) before reclassifications, net |  | 59 |  |  | — |  |  |  |  |  |  | 59 |  |
| Amounts reclassified, pre-tax |  | — |  |  | 8 |  |  |  |  |  |  | 8 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (2) |  |  |  |  |  |  | (2) |  |
| Balance as of June 30, 2021 |  | $ | (253) |  |  | $ | (541) |  |  |  |  |  |  | $ | (794) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-22-000048:notes:77]
REVENUE RECOGNITION 
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e. performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.

[0001783180-22-000048:notes:78]
[same as prior period, unchanged from 0001783180-22-000034:notes:76]

[0001783180-22-000048:notes:79]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,005 |  |  | $ | 2,757 |  |  | $ | 5,644 |  |  | $ | 4,904 |  |
| Service |  | 383 |  |  | 363 |  |  | 714 |  |  | 702 |  |
| HVAC sales |  | 3,388 |  |  | 3,120 |  |  | 6,358 |  |  | 5,606 |  |
| Product |  | 925 |  |  | 915 |  |  | 1,792 |  |  | 1,807 |  |
| Service |  | 116 |  |  | 106 |  |  | 225 |  |  | 219 |  |
| Refrigeration sales |  | 1,041 |  |  | 1,021 |  |  | 2,017 |  |  | 2,026 |  |
| Product |  | 838 |  |  | 1,012 |  |  | 1,609 |  |  | 1,931 |  |
| Service |  | 49 |  |  | 391 |  |  | 96 |  |  | 776 |  |
| Fire & Security sales |  | 887 |  |  | 1,403 |  |  | 1,705 |  |  | 2,707 |  |
| Total segment sales |  | 5,316 |  |  | 5,544 |  |  | 10,080 |  |  | 10,339 |  |
| Eliminations and other |  | (105) |  |  | (104) |  |  | (215) |  |  | (200) |  |
| Net sales |  | $ | 5,211 |  |  | $ | 5,440 |  |  | $ | 9,865 |  |  | $ | 10,139 |  |

[0001783180-22-000048:notes:80]
[same as prior period, unchanged from 0001783180-22-000034:notes:78]

[0001783180-22-000048:notes:81]
[same as prior period, unchanged from 0001783180-22-000034:notes:79]

[0001783180-22-000048:notes:82]
| (In millions) |  | June 30, 2022 |  | December 31, 2021 |
| Contract assets, current |  | $ | 712 |  |  | $ | 503 |  |
| Contract assets, non-current (included within Other assets) |  | 6 |  |  | 70 |  |
| Total contract assets |  | 718 |  |  | 573 |  |
| Contract liabilities, current |  | (444) |  |  | (415) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (169) |  |  | (165) |  |
| Total contract liabilities |  | (613) |  |  | (580) |  |
| Net contract assets |  | $ | 105 |  |  | $ | (7) |  |

[0001783180-22-000048:notes:83]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. 
The Company recognized revenue of $221 million during the six months ended June 30, 2022 that related to contract liabilities as of January 1, 2022. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001783180-22-000048:notes:84]
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e. performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-22-000048:notes:85]
[same as prior period, unchanged from 0001783180-22-000034:notes:83]

[0001783180-22-000048:notes:86]
[same as prior period, unchanged from 0001783180-22-000034:notes:84]

[0001783180-22-000048:notes:87]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) | 2022 |  | 2021 |  | 2022 |  | 2021 |
| HVAC | $ | 2 |  |  | $ | 7 |  |  | $ | 6 |  |  | $ | 11 |  |
| Refrigeration | 6 |  |  | 3 |  |  | 6 |  |  | 5 |  |
| Fire & Security | 3 |  |  | 9 |  |  | 9 |  |  | 20 |  |
| Total Segment | 11 |  |  | 19 |  |  | 21 |  |  | 36 |  |
| General corporate expenses | 2 |  |  | 2 |  |  | 2 |  |  | 3 |  |
| Total restructuring costs | $ | 13 |  |  | $ | 21 |  |  | $ | 23 |  |  | $ | 39 |  |
| Cost of sales | $ | 5 |  |  | $ | 6 |  |  | $ | 7 |  |  | $ | 11 |  |
| Selling, general and administrative | 8 |  |  | 15 |  |  | 16 |  |  | 28 |  |
| Total restructuring costs | $ | 13 |  |  | $ | 21 |  |  | $ | 23 |  |  | $ | 39 |  |

[0001783180-22-000048:notes:88]
[same as prior period, unchanged from 0001783180-22-000034:notes:86]

[0001783180-22-000048:notes:89]
|  |  | For the Six Months Ended June 30, |
| (In millions) |  | 2022 |  | 2021 |
| Balance as of January 1, |  | $ | 54 |  |  | $ | 49 |  |
| Net pre-tax restructuring costs |  | 23 |  |  | 39 |  |
| Utilization, foreign exchange and other |  | (34) |  |  | (40) |  |
| Balance as of June 30, |  | $ | 43 |  |  | $ | 48 |  |

[0001783180-22-000048:notes:90]
During the six months ended June 30, 2022 and 2021, charges associated with restructuring initiatives related to cost reduction efforts. Amounts recognized primarily related to severance due to workforce reductions and exit costs due to the consolidation of field operations. As of June 30, 2022, the Company had $43 million accrued for costs associated with its announced restructuring initiatives, all of which is expected to be paid within one year.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-22-000048:notes:91]
INCOME TAXES
The Company accounts for income tax expense in accordance with ASC 740, Income Taxes ("ASC 740"), which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 22.5% for the three months ended June 30, 2022 compared with 32.0% for the three months ended June 30, 2021. The year-over-year decrease was primarily driven by a combined tax benefit of $15 million related to re-organizations in Australia, Canada and the United Kingdom recorded during the three months ended June 30, 2022 as well as the absence of a $43 million deferred tax charge recorded during the three months ended June 30, 2021 associated with a tax rate increase in the United Kingdom enacted on June 10, 2021 with an effective date of April 2023.

[0001783180-22-000048:notes:92]
The effective tax rate was 19.3% for the six months ended June 30, 2022 compared with 27.5% for the six months ended June 30, 2021. The year-over-year decrease was primarily driven by a lower effective tax rate on the Chubb gain compared with the Company's U.S. statutory rate and a favorable tax adjustment of $32 million associated with foreign tax credits generated and expected to be utilized in the current year. The six months ended June 30, 2021 included a $43 million deferred tax charge associated with a tax rate increase in the United Kingdom enacted on June 10, 2021 with an effective date of April 2023, partially offset by the recognition of a favorable tax adjustment of $21 million resulting from the re-organization of a German subsidiary.

[0001783180-22-000048:notes:93]
[same as prior period, unchanged from 0001783180-22-000034:notes:90]

[0001783180-22-000048:notes:94]
[same as prior period, unchanged from 0001783180-22-000034:notes:91]

[0001783180-22-000048:notes:95]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. The Company believes that it is reasonably possible that a net decrease in unrecognized tax benefits of $10 million to $65 million may occur within 12 months as a result of additional uncertain tax positions, the Separation, the revaluation of uncertain tax positions arising from examinations, appeals, court decisions and/or the expiration of tax statutes.


## us-gaap:EarningsPerShareTextBlock

[0001783180-22-000048:notes:96]
[same as prior period, unchanged from 0001783180-22-000034:notes:93]

[0001783180-22-000048:notes:97]
[same as prior period, unchanged from 0001783180-22-000034:notes:94]

[0001783180-22-000048:notes:98]
|  |  | Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions, except per share amounts) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net income attributable to common shareowners |  | $ | 573 |  |  | $ | 487 |  |  | $ | 1,952 |  |  | $ | 871 |  |
| Basic weighted-average number of shares outstanding |  | 845.7 |  |  | 868.7 |  |  | 849.5 |  |  | 869.0 |  |
| Stock awards and equity units (share equivalent) |  | 17.0 |  |  | 22.2 |  |  | 18.9 |  |  | 21.4 |  |
| Diluted weighted-average number of shares outstanding |  | 862.7 |  |  | 890.9 |  |  | 868.4 |  |  | 890.4 |  |
| Antidilutive shares excluded from computation of diluted earnings per share |  | 4.5 |  |  | 3.1 |  |  | 2.9 |  |  | 3.1 |  |
| Earnings Per Share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.68 |  |  | $ | 0.56 |  |  | $ | 2.30 |  |  | $ | 1.00 |  |
| Diluted |  | $ | 0.67 |  |  | $ | 0.55 |  |  | $ | 2.25 |  |  | $ | 0.98 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001783180-22-000048:notes:99]
ACQUISITIONS
During the six months ended June 30, 2022, the Company acquired consolidated businesses and minority-owned businesses. The aggregate cash paid, net of cash acquired, totaled $38 million and was funded through cash on hand. Acquisitions are recorded using the acquisition method of accounting in accordance with ASC 805, Business Combinations. As a result, the aggregate purchase price has been allocated to assets acquired and liabilities assumed based on the estimate of fair market value of such assets and liabilities at the date of acquisition. The excess purchase price over the estimated fair value of net assets acquired during the six months ended June 30, 2022 was recognized as goodwill and totaled $16 million.

[0001783180-22-000048:notes:100]
[same as prior period, unchanged from 0001783180-22-000034:notes:97]

[0001783180-22-000048:notes:101]
On February 6, 2022, the Company entered into a binding agreement to acquire a majority ownership interest in Toshiba Carrier Corporation (“TCC”) for approximately $900 million. TCC, a variable refrigerant flow ("VRF") and light commercial HVAC joint venture between Carrier and Toshiba Corporation, designs and manufactures flexible, energy-efficient and high-performance VRF and light commercial HVAC systems as well as commercial products, compressors and heat pumps. The acquisition will include all of TCC’s advanced research and development centers and global manufacturing operations, product pipeline and the long-term use of Toshiba’s iconic brand. The transaction is expected to close in early August, subject to customary closing conditions, including regulatory approvals. Upon closing, Toshiba Corporation will retain a 5% ownership interest in TCC.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001783180-22-000048:notes:102]
[same as prior period, unchanged from 0001783180-22-000034:notes:99]

[0001783180-22-000048:notes:103]
On January 3, 2022, the Company completed the Chubb Sale for net proceeds of $2.9 billion. Chubb, which was reported within the Company’s Fire & Security segment, delivered essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. During the three months ended March 31, 2022, the Company recognized a net gain on the sale of $1.1 billion, which is included in Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations.

[0001783180-22-000048:notes:104]
[same as prior period, unchanged from 0001783180-22-000034:notes:101]

[0001783180-22-000048:notes:105]
[same as prior period, unchanged from 0001783180-22-000034:notes:102]

[0001783180-22-000048:notes:106]
The sale agreement included several customary provisions to settle working capital and other transaction-related items as of the date of sale. As of June 30, 2022, APi and the Company are in the process of finalizing these amounts in accordance with the terms of the sale agreement. Upon finalization, any adjustments will be recognized within Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-22-000048:notes:107]
[same as prior period, unchanged from 0001783180-22-000034:notes:103]

[0001783180-22-000048:notes:108]
[same as prior period, unchanged from 0001783180-22-000034:notes:104]

[0001783180-22-000048:notes:109]
[same as prior period, unchanged from 0001783180-22-000034:notes:105]

[0001783180-22-000048:notes:110]
[same as prior period, unchanged from 0001783180-22-000034:notes:106]

[0001783180-22-000048:notes:111]
The Company's customers are in both the public and private sectors and its businesses reflect extensive geographic diversification. Inter-company sales between segments are immaterial.

[0001783180-22-000048:notes:112]
[same as prior period, unchanged from 0001783180-22-000034:notes:108]

[0001783180-22-000048:notes:113]
|  |  | Net Sales |  | Operating Profit |
|  |  | For the Three Months Ended June 30, |  | For the Three Months Ended June 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| HVAC |  | $ | 3,388 |  |  | $ | 3,120 |  |  | $ | 585 |  |  | $ | 573 |  |
| Refrigeration |  | 1,041 |  |  | 1,021 |  |  | 147 |  |  | 123 |  |
| Fire & Security |  | 887 |  |  | 1,403 |  |  | 134 |  |  | 148 |  |
| Total segment |  | 5,316 |  |  | 5,544 |  |  | 866 |  |  | 844 |  |
| Eliminations and other |  | (105) |  |  | (104) |  |  | (16) |  |  | (23) |  |
| General corporate expenses |  | — |  |  | — |  |  | (31) |  |  | (38) |  |
| Total Consolidated |  | $ | 5,211 |  |  | $ | 5,440 |  |  | $ | 819 |  |  | $ | 783 |  |

[0001783180-22-000048:notes:114]
|  |  | Net Sales |  | Operating Profit |
|  |  | For the Six Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| HVAC |  | $ | 6,358 |  |  | $ | 5,606 |  |  | $ | 1,055 |  |  | $ | 938 |  |
| Refrigeration |  | 2,017 |  |  | 2,026 |  |  | 254 |  |  | 250 |  |
| Fire & Security |  | 1,705 |  |  | 2,707 |  |  | 1,352 |  |  | 298 |  |
| Total segment |  | 10,080 |  |  | 10,339 |  |  | 2,661 |  |  | 1,486 |  |
| Eliminations and other |  | (215) |  |  | (200) |  |  | (40) |  |  | (63) |  |
| General corporate expenses |  | — |  |  | — |  |  | (65) |  |  | (69) |  |
| Total Consolidated |  | $ | 9,865 |  |  | $ | 10,139 |  |  | $ | 2,556 |  |  | $ | 1,354 |  |

[0001783180-22-000048:notes:115]
Geographic external sales are attributed to the geographic regions based on their location of origin. With the exception of the U.S. presented in the table below, there were no individually significant countries with sales exceeding 10% of total sales during the six months ended June 30, 2022 and 2021.

[0001783180-22-000048:notes:116]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| United States |  | $ | 3,171 |  |  | $ | 2,848 |  |  | $ | 5,955 |  |  | $ | 5,201 |  |
| International: |  |  |  |  |  |  |  |  |
| Europe |  | 1,119 |  |  | 1,459 |  |  | 2,164 |  |  | 2,857 |  |
| Asia Pacific |  | 713 |  |  | 907 |  |  | 1,365 |  |  | 1,649 |  |
| Other |  | 208 |  |  | 226 |  |  | 381 |  |  | 432 |  |
| Net sales |  | $ | 5,211 |  |  | $ | 5,440 |  |  | $ | 9,865 |  |  | $ | 10,139 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-22-000048:notes:117]
RELATED PARTIES 
Equity Method Investments

[0001783180-22-000048:notes:118]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered to be related parties. Amounts attributable to equity method investees are as follows:

[0001783180-22-000048:notes:119]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Sales to equity method investees included in Product sales |  | $ | 787 |  |  | $ | 652 |  |  | $ | 1,411 |  |  | $ | 1,120 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 91 |  |  | $ | 98 |  |  | $ | 201 |  |  | $ | 174 |  |

[0001783180-22-000048:notes:120]
The Company had receivables from and payables to equity method investees as follows:

[0001783180-22-000048:notes:121]
| (In millions) |  | June 30,2022 |  | December 31, 2021 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 315 |  |  | $ | 150 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 57 |  |  | $ | 51 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-22-000048:notes:122]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon the Company's competitive position, results of operations, cash flows or financial condition.

[0001783180-22-000048:notes:123]
Environmental Matters

[0001783180-22-000048:notes:124]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including technology required to remediate, current laws and regulations and prior remediation experience.

[0001783180-22-000048:notes:125]
The outstanding liabilities for environmental obligations are as follows:

[0001783180-22-000048:notes:126]
| (In millions) |  | June 30,2022 |  | December 31, 2021 |
| Environmental reserves included in Accrued liabilities |  | $ | 29 |  |  | $ | 29 |  |
| Environmental reserves included in Other long-term liabilities |  | 187 |  |  | 191 |  |
| Total Environmental reserves |  | $ | 216 |  |  | $ | 220 |  |

[0001783180-22-000048:notes:127]
For sites with multiple responsible parties, the Company considers its likely proportionate share of the anticipated remediation costs and the ability of other parties to fulfill their obligations in establishing a provision for these costs. Accrued environmental liabilities are not reduced by potential insurance reimbursements and are undiscounted.

[0001783180-22-000048:notes:128]
Asbestos Matters

[0001783180-22-000048:notes:129]
The Company has been named as a defendant in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures

[0001783180-22-000048:notes:130]
contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-22-000048:notes:131]
The Company had asbestos liabilities and related insurance recoveries as follows:

[0001783180-22-000048:notes:132]
| (In millions) |  | June 30,2022 |  | December 31,2021 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 215 |  |  | 220 |  |
| Total Asbestos liabilities |  | $ | 232 |  |  | $ | 237 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 92 |  |  | 93 |  |
| Total Asbestos-related recoveries |  | $ | 97 |  |  | $ | 98 |  |

[0001783180-22-000048:notes:133]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.

[0001783180-22-000048:notes:134]
UTC Equity Awards Conversion Litigation

[0001783180-22-000048:notes:135]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenges the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021 (the "Amended Complaint"). The Amended Complaint, now with Raytheon, Carrier and Otis as the only defendants, asserts that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also seeks specific performance. Carrier believes that the claims against the Company are without merit. Defendants moved to dismiss the Amended Complaint on October 13, 2021. The motion to dismiss was fully briefed as of December 3, 2021 and the court held oral argument on the motion on July 14, 2022.

[0001783180-22-000048:notes:136]
Aqueous Film Forming Foam Litigation

[0001783180-22-000048:notes:137]
As of June 30, 2022, the Company has been named as a defendant in more than 2,400 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company has also been named as a defendant in more than 200 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company and others to the U.S. District Court for the District of South Carolina ("MDL Court") for pre-trial proceedings ("MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring and diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

[0001783180-22-000048:notes:138]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires primarily at military bases and airports. AFFF was manufactured by several companies, including National Foam and Angus Fire. UTC first entered the AFFF business with the acquisition of National Foam and Angus Fire in 2005 as part of the acquisition of Kidde. In 2013, Kidde divested the National Foam and Angus Fire businesses to a third party. The Company acquired Kidde as part of its separation from UTC in April 2020. During the eight-year period of its operation by Kidde, National Foam manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania

[0001783180-22-000048:notes:139]
("Pennsylvania Site"). During the same period, Angus Fire manufactured AFFF for sale outside the United States at a single facility located in Bentham, England.

[0001783180-22-000048:notes:140]
The key components of AFFF that contribute to its fire-extinguishing capabilities are known as fluorosurfactants. National Foam and Angus Fire did not manufacture fluorosurfactants but instead purchased these substances from unrelated third parties. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as perflourooctane sulfonate ("PFOS") and/or perflourooctane acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

[0001783180-22-000048:notes:141]
Plaintiffs in the MDL Proceedings allege that PFOS and PFOA contamination has resulted from the use of AFFF containing fluorosurfactants manufactured using a process known as ECF. They also allege that PFOA contamination has resulted from the use of AFFF containing fluorosurfactants manufactured using a different process, known as telomerization. Plaintiffs further allege that 3M was the only AFFF manufacturer that used fluorosurfactants relying on the ECF process and that all other foam manufacturers (including National Foam and Angus Fire) relied solely on fluorosurfactants produced via telomerization. Compounds containing PFOS and PFOA (as well as many other per- and polyfluoroalkyl substances known collectively as "PFAS") have also been used for decades by many third parties in a number of different industries to manufacture carpets, clothing, fabrics, cookware, food packaging, personal care products, cleaning products, paints, varnishes and other consumer and industrial products.

[0001783180-22-000048:notes:142]
Plaintiffs in the MDL Proceedings have named multiple defendants, including four suppliers of chemicals and raw materials used to manufacture fluorosurfactants, four fluorosurfactant manufacturers, two toll manufacturers of fluorosurfactants and seven current (including National Foam and Angus Fire) and former (including the Company) AFFF manufacturers.

[0001783180-22-000048:notes:143]
General liability discovery in the MDL Proceedings continues. Preliminary stage discovery in ten "bellwether" water provider cases was concluded and three of these cases were selected for tier two site-specific discovery. That discovery is ongoing. The MDL Court previously established a briefing schedule with respect to certain aspects of the government contractor defense, potentially applicable to AFFF sold to or used by the U.S. government or other customers requiring product manufactured to meet military specification, with briefing to conclude at the end of January 2022 with a hearing to follow in late March. In late March, the MDL Court postponed the planned hearing and called for briefing on additional elements of the government contractor defense. Briefing was completed as of July 1, 2022. An oral argument is now scheduled on August 19, 2022.

[0001783180-22-000048:notes:144]
Outside of the MDL Proceedings, the Company and other defendants are also party to six lawsuits in U.S. state courts brought by oil refining companies alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage. In addition, the Company and other defendants are party to two actions related to the Pennsylvania Site in which the plaintiff water utility company seeks remediation costs related to the alleged contamination of the local water supply.

[0001783180-22-000048:notes:145]
The Company believes that it has meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Based on the 2013 agreement for the sale of National Foam and Angus Fire, the Company is pursuing indemnification against these claims from the purchaser and current owner of National Foam and Angus Fire. The Company also is pursuing insurance coverage for these claims. At this time, however, given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate the damages, if any, to be allocated to the Company, if one or more plaintiffs were to prevail in these cases. There can be no assurance that any such future exposure will not be material in any period.

[0001783180-22-000048:notes:146]
Income Taxes

[0001783180-22-000048:notes:147]
Under the Tax Matters Agreement relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act ("TCJA") transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, liabilities of $34 million and $383 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of June 30, 2022, respectively. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $34 million due in 2023. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

[0001783180-22-000048:notes:148]
Other

[0001783180-22-000048:notes:149]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of

[0001783180-22-000048:notes:150]
possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-22-000048:notes:151]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its competitive position, results of operations, cash flows or financial condition.


## us-gaap:SubsequentEventsTextBlock

[0001783180-22-000048:notes:152]
SUBSEQUENT EVENTS 
On July 15, 2022, the Company entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings under the Japanese Term Loan Facility bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. In addition, the Japanese Term Loan Facility is subject to customary covenants including a covenant to maintain a maximum consolidated leverage ratio during its term. The Company expects to designate the Japanese Term Loan Facility as a partial hedge of its investment in certain Yen-functional currency subsidiaries in order to manage foreign currency translation risk. As a result, changes in the fair value of the Japanese Term Loan Facility associated with foreign exchange rate movements will be recorded in Equity in the Unaudited Condensed Consolidated Balance Sheet.

[0001783180-22-000048:notes:153]
On July 25, 2022, the Company borrowed JPY 54 billion under the Japanese Term Loan Facility and intends to use the proceeds to fund a portion of the planned acquisition of TCC and to pay related fees and expenses. The Company expects to fund the remaining portion of the Yen denominated purchase price for the planned acquisition of TCC with cash on hand by entering into cross currency swaps with SMBC Capital Markets, Inc. as syndication swap arranger, and certain other financial institutions. The Company expects to designate the cross currency swaps as a partial hedge of its investment in certain Yen-functional currency subsidiaries in order to manage foreign currency translation risk. As a result, changes in the fair value of the swaps will be recorded in Equity in the Unaudited Condensed Consolidated Balance Sheet.
