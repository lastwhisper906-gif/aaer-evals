# CARR 8-K — 0001783180-22-000045 filed 2022-07-28

## item codes, every 8-K on or before 2022-07-28

- 2022-07-28 0001783180-22-000045 — 2.02, 9.01
- 2022-04-28 0001783180-22-000032 — 2.02, 9.01
- 2022-04-15 0001783180-22-000024 — 5.07, 9.01
- 2022-02-08 0001783180-22-000008 — 2.02, 9.01
- 2022-02-07 0000950142-22-000510 — 8.01, 9.01
- 2022-01-03 0000950142-22-000023 — 8.01, 9.01
- 2021-12-17 0001783180-21-000071 — 5.02, 7.01, 9.01
- 2021-11-23 0001783180-21-000068 — 5.03, 9.01
- 2021-10-28 0001783180-21-000062 — 2.02, 9.01
- 2021-08-27 0001783180-21-000056 — 8.01
- 2021-07-30 0001783180-21-000053 — 1.01
- 2021-07-29 0001783180-21-000049 — 2.02, 8.01, 9.01
- 2021-07-27 0000950142-21-002448 — 8.01, 9.01
- 2021-07-15 0000950142-21-002362 — 5.02, 9.01
- 2021-06-09 0000950142-21-001885 — 5.02, 9.01
- 2021-04-29 0001783180-21-000029 — 2.02, 9.01
- 2021-04-22 0001140361-21-013889 — 5.02, 9.01
- 2021-04-20 0001783180-21-000021 — 5.07, 9.01
- 2021-04-19 0000950142-21-001308 — 8.01, 9.01
- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2022-07-28

- none on or before 2022-07-28

## item 2.02 — earnings release, exhibit 99.1

[0001783180-22-000045:8k_2_02:1]
EX-99
2
a99-q22022earningsexhibit.htm
EX-99

[0001783180-22-000045:8k_2_02:2]
Document

[0001783180-22-000045:8k_2_02:3]
Exhibit 99

[0001783180-22-000045:8k_2_02:4]
Carrier Reports Second Quarter 2022 Results

[0001783180-22-000045:8k_2_02:5]
Strong first half results; Raises full-year earnings outlook

[0001783180-22-000045:8k_2_02:6]
Toshiba Carrier Corporation acquisition expected to close in early August 2022

[0001783180-22-000045:8k_2_02:7]
•Net sales down 4% versus 2021 driven by the Chubb divestiture; organic sales up 7%

[0001783180-22-000045:8k_2_02:8]
•Operating margin up 130 basis points; price/cost positive in the quarter

[0001783180-22-000045:8k_2_02:9]
•GAAP EPS of $0.67 and adjusted EPS of $0.69

[0001783180-22-000045:8k_2_02:10]
•Net cash flows from operating activities of $32 million; free cash flow usage of $34 million

[0001783180-22-000045:8k_2_02:11]
•Raising full-year  2022 adjusted EPS* guidance range to $2.25 to $2.35 from $2.20 to $2.30

[0001783180-22-000045:8k_2_02:12]
PALM BEACH GARDENS, Fla., July 28, 2022 – Carrier Global Corporation (NYSE:CARR), the leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions, today reported financial results for the second quarter of 2022 and increased its full-year earnings outlook.

[0001783180-22-000045:8k_2_02:13]
“Our strong results in the second quarter and first half of 2022 underscore the strength of Carrier’s balanced business model, and I want to thank the Carrier team for another solid quarter despite the challenging supply chain environment,” said Carrier Chairman & CEO David Gitlin. “We continue to gain traction on digitally-enabled life-cycle solutions as we delivered double-digit aftermarket growth in the quarter and further expanded customer adoption of our Abound and Lynx digital platforms. We now expect to be price/cost positive for the full year and will continue to invest in differentiated technology to address key secular trends such as sustainability and healthy indoor environments. We are also excited for the opportunities that our combined Carrier and Toshiba Carrier

[0001783180-22-000045:8k_2_02:14]
1

[0001783180-22-000045:8k_2_02:15]
Corporation portfolio and enhanced market position present in the fast-growing Variable Refrigerant Flow, international light commercial and heat pump markets.”

[0001783180-22-000045:8k_2_02:16]
Second Quarter 2022 Results

[0001783180-22-000045:8k_2_02:17]
Carrier’s second quarter sales of $5.2 billion were down 4% compared to the prior year driven by the Chubb divestiture, but organic sales grew 7% over the same period. Sales strength continued in the HVAC segment, with North America residential and light commercial up double-digits in the quarter. Commercial HVAC strength also continued, with orders up double digits for the sixth consecutive quarter. Refrigeration sales were up 9% organically, with both transport and commercial refrigeration up high single-digits. Sales for the Fire & Security segment were up 3% organically. Excluding Chubb sales from the second quarter of 2021, Fire & Security segment sales were up 4%.

[0001783180-22-000045:8k_2_02:18]
GAAP operating profit in the quarter of $819 million was up 5% from last year and adjusted operating profit of $857 million was up 4% despite lower reported sales. Strong price realization helped mitigate continued supply chain challenges. Price/cost was positive in the second quarter.

[0001783180-22-000045:8k_2_02:19]
Net income was $573 million and adjusted net income was $599 million. GAAP EPS was $0.67 and adjusted EPS was $0.69. Net cash flows from operating activities were $32 million and capital expenditures were $66 million, resulting in a free cash outflow of $34 million. The outflow was the result of tax payments related to the gain on the Chubb sale, an increase in receivables driven by strong sales at the end of the quarter, and supply chain challenges continuing to impact inventory levels. During the second quarter, Carrier repurchased $273 million of its common stock.

[0001783180-22-000045:8k_2_02:20]
Updated Full-Year 2022 Outlook**

[0001783180-22-000045:8k_2_02:21]
Carrier is announcing the following updated outlook for 2022. In addition to improvement in the base business, the revised 2022 outlook includes approximately $800 million of incremental sales from the consolidation of Toshiba Carrier Corporation. The Company anticipates closing the acquisition in early August.

[0001783180-22-000045:8k_2_02:22]
2

[0001783180-22-000045:8k_2_02:23]
|  |  | Prior 2022 Outlook | Updated 2022 Outlook Excluding Toshiba Carrier Corporation | Updated 2022 Outlook Including Toshiba Carrier Corporation |  |  |
|  |  | ~$20B | ~$20B | ~$20.8B |  |  |
| Sales |  | Organic* up HSD | Organic* up HSD | Organic* up HSD |  |  |
|  |  | FX ~(1%) | FX ~(3%) | FX ~(3%) |  |  |
|  |  | Acq / Div, net ~(9%) | Acq / Div, net ~(9%) | Acq / Div, net ~(5%) |  |  |
| Adjusted Operating Margin * |  | Up ~75 bps Y/Y | Up ~75 bps Y/Y | Up ~40 bps Y/Y |  |  |
| Adjusted EPS * |  | $2.20 - $2.30 | $2.25 - $2.35 | $2.25 - $2.35 |  |  |
| Free Cash Flow *1 |  | ~$1.65B | ~$1.65B | ~$1.65B |  |  |

[0001783180-22-000045:8k_2_02:24]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-22-000045:8k_2_02:25]
**As of July 28, 2022

[0001783180-22-000045:8k_2_02:26]
1Includes ~$200M in tax payments on Chubb gain

[0001783180-22-000045:8k_2_02:27]
Following the close of the Toshiba Carrier Corporation acquisition, Carrier intends to exclude the impact of amortization of acquired intangibles from its non-GAAP financial measures including adjusted operating profit, adjusted net income and adjusted EPS.  Amortization of acquired intangibles, a non-cash expense, is unrelated to our core operating performance and amounts can vary significantly depending on the number, timing and size of acquisitions, among other factors. We believe this adjustment provides investors meaningful information to better evaluate our operating performance between periods.

[0001783180-22-000045:8k_2_02:28]
Conference Call

[0001783180-22-000045:8k_2_02:29]
Carrier will host a webcast of its earnings conference call today, Thursday, July 28, 2022, at 7:30 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at ir.carrier.com/news-and-events/events-and-presentations or to listen to the earnings call by phone, participants must pre-register at Carrier Earnings Call Registration. All registrants will receive dial-in information and a PIN allowing access to the live call.

[0001783180-22-000045:8k_2_02:30]
3

[0001783180-22-000045:8k_2_02:31]
Cautionary Statement

[0001783180-22-000045:8k_2_02:32]
This communication contains statements which, to the extent they are not statements of historical or present fact, constitute "forward-looking statements" under the securities laws. These forward-looking statements are intended to provide management's current expectations or plans for Carrier's future operating and financial performance, based on assumptions currently believed to be valid. Forward-looking statements can be identified by the use of words such as "believe," "expect," "expectations," "plans," "strategy," "prospects," "estimate," "project," "target," "anticipate," "will," "should," "see," "guidance," "outlook," "confident," "scenario" and other words of similar meaning in connection with a discussion of future operating or financial performance or the separation from United Technologies Corporation (the "Separation"), since renamed Raytheon Technologies Corporation. Forward-looking statements may include, among other things, statements relating to future sales, earnings, cash flow, results of operations, uses of cash, share repurchases, tax rates and other measures of financial performance or potential future plans, strategies or transactions of Carrier, the estimated costs associated with the Separation, Carrier's plans with respect to its indebtedness and other statements that are not historical facts. All forward-looking statements involve risks, uncertainties and other factors that may cause actual results to differ materially from those expressed or implied in the forward-looking statements. For additional information on identifying factors that may cause actual results to vary materially from those stated in forward-looking statements, see Carrier's reports on Forms 10-K, 10-Q and 8-K filed with or furnished to the U.S. Securities and Exchange Commission from time to time. Any forward-looking statement speaks only as of the date on which it is made, and Carrier assumes no obligation to update or revise such statement, whether as a result of new information, future events or otherwise, except as required by applicable law.

[0001783180-22-000045:8k_2_02:33]
Contact:

[0001783180-22-000045:8k_2_02:34]
Media Inquiries

[0001783180-22-000045:8k_2_02:35]
Ashley Barrie

[0001783180-22-000045:8k_2_02:36]
561-365-1260

[0001783180-22-000045:8k_2_02:37]
Ashley.Barrie@Carrier.com

[0001783180-22-000045:8k_2_02:38]
Investor Relations

[0001783180-22-000045:8k_2_02:39]
Sam Pearlstein

[0001783180-22-000045:8k_2_02:40]
561-365-2251

[0001783180-22-000045:8k_2_02:41]
Sam.Pearlstein@Carrier.com

[0001783180-22-000045:8k_2_02:42]
4

[0001783180-22-000045:8k_2_02:43]
SELECTED FINANCIAL DATA, NON-GAAP MEASURES AND DEFINITIONS

[0001783180-22-000045:8k_2_02:44]
Following are tables that present selected financial data of Carrier Global Corporation (“Carrier”). Also included are reconciliations of non-GAAP measures to their most comparable GAAP measures.

[0001783180-22-000045:8k_2_02:45]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-22-000045:8k_2_02:46]
Carrier Global Corporation (“Carrier”) reports its financial results in accordance with accounting principles generally accepted in the United States ("GAAP"). We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables in this Appendix. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-22-000045:8k_2_02:47]
Organic sales, adjusted operating profit, adjusted operating margin, incremental margins / earnings conversion, earnings before interest, taxes and depreciation and amortization (“EBITDA”), adjusted EBITDA, adjusted net income, adjusted earnings per share (“EPS”), adjusted interest expense, net, adjusted effective tax rate and net debt are non-GAAP financial measures.

[0001783180-22-000045:8k_2_02:48]
Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a nonoperational nature (hereinafter referred to as “other significant items”). Adjusted operating profit represents operating profit (a GAAP measure), excluding restructuring costs and other significant items. Adjusted operating margin represents adjusted operating profit as a percentage of net sales (a GAAP measure). Incremental margins / earnings conversion represents the year-over-year change in adjusted operating profit divided by the year-over-year change in net sales. EBITDA represents net income attributable to common shareholders (a GAAP measure), adjusted for interest income and expense, income tax expense, and depreciation and amortization. Adjusted EBITDA represents EBITDA, as calculated above, excluding non-service pension benefit, non-controlling interest in subsidiaries’ earnings from operations, restructuring costs and other significant items. Adjusted net income represents net income attributable to common shareowners (a GAAP measure), excluding restructuring costs and other significant items. Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs and other significant items. Adjusted interest expense, net represents interest expense (a GAAP measure) and interest income (a GAAP measure), net excluding other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs and other significant items. Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents. For the business segments, when applicable, adjustments of operating profit and operating margins represent operating profit, excluding restructuring and other significant items.

[0001783180-22-000045:8k_2_02:49]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by operating activities (a GAAP measure) less capital expenditures. Management believes free cash flow is a useful measure of liquidity and an additional basis for assessing Carrier’s ability to fund its activities, including the financing of acquisitions, debt service, repurchases of Carrier's common stock and distribution of earnings to shareowners.

[0001783180-22-000045:8k_2_02:50]
Orders are contractual commitments with customers to provide specified goods or services for an agreed upon price and may not be subject to penalty if cancelled.

[0001783180-22-000045:8k_2_02:51]
When we provide our expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted interest expense, net, adjusted effective tax rate, incremental margins/earnings conversion, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures (expected net sales, operating profit, operating margin, interest expense, effective tax rate, incremental operating margin, diluted EPS and net cash flows provided by operating activities) generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-22-000045:8k_2_02:52]
5

[0001783180-22-000045:8k_2_02:53]
Carrier Global Corporation

[0001783180-22-000045:8k_2_02:54]
Condensed Consolidated Statement of Operations

[0001783180-22-000045:8k_2_02:55]
|  | (Unaudited) |
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions, except per share amounts) | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net sales: |  |  |  |  |  |  |  |
| Product sales | $ | 4,662 |  |  | $ | 4,584 |  |  | $ | 8,832 |  |  | $ | 8,448 |  |
| Service sales | 549 |  |  | 856 |  |  | 1,033 |  |  | 1,691 |  |
| Total Net sales | 5,211 |  |  | 5,440 |  |  | 9,865 |  |  | 10,139 |  |
| Costs and expenses |  |  |  |  |  |  |  |
| Cost of products sold | (3,363) |  |  | (3,235) |  |  | (6,361) |  |  | (5,959) |  |
| Cost of services sold | (401) |  |  | (586) |  |  | (764) |  |  | (1,167) |  |
| Research and development | (122) |  |  | (125) |  |  | (247) |  |  | (246) |  |
| Selling, general and administrative | (614) |  |  | (813) |  |  | (1,215) |  |  | (1,556) |  |
| Total Costs and expenses | (4,500) |  |  | (4,759) |  |  | (8,587) |  |  | (8,928) |  |
| Equity method investment net earnings | 101 |  |  | 87 |  |  | 159 |  |  | 125 |  |
| Other income (expense), net | 7 |  |  | 15 |  |  | 1,119 |  |  | 18 |  |
| Operating profit | 819 |  |  | 783 |  |  | 2,556 |  |  | 1,354 |  |
| Non-service pension (expense) benefit | (1) |  |  | 19 |  |  | (2) |  |  | 37 |  |
| Interest (expense) income, net | (61) |  |  | (71) |  |  | (109) |  |  | (164) |  |
| Income from operations before income taxes | 757 |  |  | 731 |  |  | 2,445 |  |  | 1,227 |  |
| Income tax (expense) benefit | (170) |  |  | (234) |  |  | (471) |  |  | (338) |  |
| Net income from operations | 587 |  |  | 497 |  |  | 1,974 |  |  | 889 |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations | 14 |  |  | 10 |  |  | 22 |  |  | 18 |  |
| Net income attributable to common shareowners | $ | 573 |  |  | $ | 487 |  |  | $ | 1,952 |  |  | $ | 871 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 0.68 |  |  | $ | 0.56 |  |  | $ | 2.30 |  |  | $ | 1.00 |  |
| Diluted | $ | 0.67 |  |  | $ | 0.55 |  |  | $ | 2.25 |  |  | $ | 0.98 |  |
| Weighted average number of shares outstanding |  |  |  |  |  |  |  |
| Basic | 845.7 |  |  | 868.7 |  |  | 849.5 |  |  | 869.0 |  |
| Diluted | 862.7 |  |  | 890.9 |  |  | 868.4 |  |  | 890.4 |  |

[0001783180-22-000045:8k_2_02:56]
6

[0001783180-22-000045:8k_2_02:57]
Carrier Global Corporation

[0001783180-22-000045:8k_2_02:58]
Condensed Consolidated Balance Sheet

[0001783180-22-000045:8k_2_02:59]
|  |  | (Unaudited) |
| (In millions) |  | June 30, 2022 |  | December 31, 2021 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 3,017 |  |  | $ | 2,987 |  |
| Accounts receivable, net |  | 2,823 |  |  | 2,403 |  |
| Contract assets, current |  | 712 |  |  | 503 |  |
| Inventories, net |  | 2,350 |  |  | 1,970 |  |
| Assets held for sale |  | — |  |  | 3,168 |  |
| Other assets, current |  | 374 |  |  | 376 |  |
| Total current assets |  | 9,276 |  |  | 11,407 |  |
| Future income tax benefits |  | 566 |  |  | 563 |  |
| Fixed assets, net |  | 1,805 |  |  | 1,826 |  |
| Operating lease right-of-use assets |  | 595 |  |  | 640 |  |
| Intangible assets, net |  | 458 |  |  | 509 |  |
| Goodwill |  | 9,067 |  |  | 9,349 |  |
| Pension and post-retirement assets |  | 31 |  |  | 43 |  |
| Equity method investments |  | 1,671 |  |  | 1,593 |  |
| Other assets |  | 193 |  |  | 242 |  |
| Total Assets |  | $ | 23,662 |  |  | $ | 26,172 |  |
| Liabilities and Equity |  |  |  |  |
| Accounts payable |  | $ | 2,403 |  |  | $ | 2,334 |  |
| Accrued liabilities |  | 2,430 |  |  | 2,561 |  |
| Contract liabilities, current |  | 444 |  |  | 415 |  |
| Liabilities held for sale |  | — |  |  | 1,134 |  |
| Current portion of long-term debt |  | 269 |  |  | 183 |  |
| Total current liabilities |  | 5,546 |  |  | 6,627 |  |
| Long-term debt |  | 8,298 |  |  | 9,513 |  |
| Future pension and post-retirement obligations |  | 366 |  |  | 380 |  |
| Future income tax obligations |  | 335 |  |  | 354 |  |
| Operating lease liabilities |  | 490 |  |  | 527 |  |
| Other long-term liabilities |  | 1,635 |  |  | 1,677 |  |
| Total Liabilities |  | 16,670 |  |  | 19,078 |  |
| Equity |  |  |  |  |
| Common stock |  | 9 |  |  | 9 |  |
| Treasury stock |  | (1,543) |  |  | (529) |  |
| Additional paid-in capital |  | 5,441 |  |  | 5,411 |  |
| Retained earnings |  | 4,564 |  |  | 2,865 |  |
| Accumulated other comprehensive loss |  | (1,775) |  |  | (989) |  |
| Non-controlling interest |  | 296 |  |  | 327 |  |
| Total Equity |  | 6,992 |  |  | 7,094 |  |
| Total Liabilities and Equity |  | $ | 23,662 |  |  | $ | 26,172 |  |

[0001783180-22-000045:8k_2_02:60]
7

[0001783180-22-000045:8k_2_02:61]
Carrier Global Corporation

[0001783180-22-000045:8k_2_02:62]
Condensed Consolidated Statement of Cash Flows

[0001783180-22-000045:8k_2_02:63]
|  |  |  |  | (Unaudited) |
|  |  |  | For the Six Months Ended June 30, |
| (In millions) |  |  |  |  | 2022 |  | 2021 |
| Operating Activities |  |  |  |  |  |  |  |
| Net income from operations |  |  |  |  | $ | 1,974 |  |  | $ | 889 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  |  |  | 155 |  |  | 168 |  |
| Deferred income tax provision |  |  |  |  | (17) |  |  | 33 |  |
| Stock-based compensation costs |  |  |  |  | 41 |  |  | 40 |  |
| Equity method investment net earnings |  |  |  |  | (159) |  |  | (125) |  |
| (Gain) loss on extinguishment of debt |  |  |  |  | (36) |  |  | — |  |
| (Gain) loss on sale of investments |  |  |  |  | (1,119) |  |  | — |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  |  |  | (483) |  |  | (288) |  |
| Contract assets, current |  |  |  |  | (224) |  |  | (41) |  |
| Inventories, net |  |  |  |  | (435) |  |  | (210) |  |
| Other assets, current |  |  |  |  | (37) |  |  | (27) |  |
| Accounts payable and accrued liabilities |  |  |  |  | 79 |  |  | 368 |  |
| Contract liabilities, current |  |  |  |  | 42 |  |  | 42 |  |
| Defined benefit plan contributions |  |  |  |  | (6) |  |  | (27) |  |
| Distributions from equity method investments |  |  |  |  | 15 |  |  | 42 |  |
| Other operating activities, net |  |  |  |  | 40 |  |  | (119) |  |
| Net cash flows provided by (used in) operating activities |  |  |  |  | (170) |  |  | 745 |  |
| Investing Activities |  |  |  |  |  |  |  |
| Capital expenditures |  |  |  |  | (122) |  |  | (132) |  |
| Investments in businesses, net of cash acquired |  |  |  |  | (38) |  |  | (167) |  |
| Disposition of businesses |  |  |  |  | 2,944 |  |  | 1 |  |
| Settlement of derivative contracts, net |  |  |  |  | (123) |  |  | (6) |  |
| Other investing activities, net |  |  |  |  | (16) |  |  | 3 |  |
| Net cash flows provided by (used in) investing activities |  |  |  |  | 2,645 |  |  | (301) |  |
| Financing Activities |  |  |  |  |  |  |  |
| Increase (decrease) in short-term borrowings, net |  |  |  |  | (22) |  |  | (13) |  |
| Issuance of long-term debt |  |  |  |  | 21 |  |  | 74 |  |
| Repayment of long-term debt |  |  |  |  | (1,127) |  |  | (605) |  |
| Repurchases of common stock |  |  |  |  | (1,014) |  |  | (130) |  |
| Dividends paid on common stock |  |  |  |  | (257) |  |  | (209) |  |
| Dividends paid to non-controlling interest |  |  |  |  | (22) |  |  | (30) |  |
| Other financing activities, net |  |  |  |  | (13) |  |  | 15 |  |
| Net cash flows provided by (used in) financing activities |  |  |  |  | (2,434) |  |  | (898) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  |  |  | (41) |  |  | (2) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  |  |  |  | — |  |  | (456) |  |
| Cash, cash equivalents and restricted cash, beginning of period |  |  |  |  | 3,025 |  |  | 3,120 |  |
| Cash, cash equivalents and restricted cash, end of period |  |  |  |  | 3,025 |  |  | 2,664 |  |
| Less: restricted cash |  |  |  |  | 8 |  |  | 34 |  |
| Cash and cash equivalents, end of period |  |  |  |  | $ | 3,017 |  |  | $ | 2,630 |  |

[0001783180-22-000045:8k_2_02:64]
8

[0001783180-22-000045:8k_2_02:65]
Carrier Global Corporation

[0001783180-22-000045:8k_2_02:66]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-22-000045:8k_2_02:67]
Operating Profit

[0001783180-22-000045:8k_2_02:68]
|  | (Unaudited) |
|  | For the Three Months Ended June 30, 2022 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 3,388 |  |  | $ | 1,041 |  |  | $ | 887 |  |  | $ | (105) |  |  | $ | — |  |  | $ | 5,211 |  |
| Segment operating profit | $ | 585 |  |  | $ | 147 |  |  | $ | 134 |  |  | $ | (16) |  |  | $ | (31) |  |  | $ | 819 |  |
| Reported operating margin | 17.3 | % |  | 14.1 | % |  | 15.1 | % |  |  |  |  |  | 15.7 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 2 |  |  | $ | 6 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 2 |  |  | $ | 13 |  |
| Charge resulting from legal matter | 22 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 22 |  |
| Acquisition and other related costs | — |  |  | — |  |  | — |  |  | — |  |  | 7 |  |  | 7 |  |
| Russia/Ukraine asset impairment | — |  |  | (1) |  |  | (3) |  |  | — |  |  | — |  |  | (4) |  |
| Total adjustments to operating profit | $ | 24 |  |  | $ | 5 |  |  | $ | — |  |  | $ | — |  |  | $ | 9 |  |  | $ | 38 |  |
| Adjusted operating profit | $ | 609 |  |  | $ | 152 |  |  | $ | 134 |  |  | $ | (16) |  |  | $ | (22) |  |  | $ | 857 |  |
| Adjusted operating margin | 18.0 | % |  | 14.6 | % |  | 15.1 | % |  |  |  |  |  | 16.4 | % |

[0001783180-22-000045:8k_2_02:69]
|  | (Unaudited) |
|  | For the Three Months Ended June 30, 2021 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 3,120 |  |  | $ | 1,021 |  |  | $ | 1,403 |  |  | $ | (104) |  |  | $ | — |  |  | $ | 5,440 |  |
| Segment operating profit | $ | 573 |  |  | $ | 123 |  |  | $ | 148 |  |  | $ | (23) |  |  | $ | (38) |  |  | $ | 783 |  |
| Reported operating margin | 18.4 | % |  | 12.0 | % |  | 10.5 | % |  |  |  |  |  | 14.4 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 7 |  |  | $ | 3 |  |  | $ | 9 |  |  | $ | — |  |  | $ | 2 |  |  | $ | 21 |  |
| Acquisition and other related costs | 2 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2 |  |
| Chubb transaction costs | — |  |  | — |  |  | 12 |  |  | — |  |  | — |  |  | 12 |  |
| Separation costs | — |  |  | — |  |  | — |  |  | 2 |  |  | 1 |  | 3 |  |
| Total adjustments to operating profit | $ | 9 |  |  | $ | 3 |  |  | $ | 21 |  |  | $ | 2 |  |  | $ | 3 |  |  | $ | 38 |  |
| Adjusted operating profit | $ | 582 |  |  | $ | 126 |  |  | $ | 169 |  |  | $ | (21) |  |  | $ | (35) |  |  | $ | 821 |  |
| Adjusted operating margin | 18.7 | % |  | 12.3 | % |  | 12.0 | % |  |  |  |  |  | 15.1 | % |

[0001783180-22-000045:8k_2_02:70]
9

[0001783180-22-000045:8k_2_02:71]
Carrier Global Corporation

[0001783180-22-000045:8k_2_02:72]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-22-000045:8k_2_02:73]
Operating Profit

[0001783180-22-000045:8k_2_02:74]
|  | (Unaudited) |
|  | For the Six Months Ended June 30, 2022 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 6,358 |  |  | $ | 2,017 |  |  | $ | 1,705 |  |  | $ | (215) |  |  | $ | — |  |  | $ | 9,865 |  |
| Segment operating profit | $ | 1,055 |  |  | $ | 254 |  |  | $ | 1,352 |  |  | $ | (40) |  |  | $ | (65) |  |  | $ | 2,556 |  |
| Reported operating margin | 16.6 | % |  | 12.6 | % |  | 79.3 | % |  |  |  |  |  | 25.9 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 6 |  |  | $ | 6 |  |  | $ | 9 |  |  | $ | — |  |  | $ | 2 |  |  | $ | 23 |  |
| Chubb gain | — |  |  | — |  |  | (1,112) |  |  | — |  |  | — |  |  | (1,112) |  |
| Charge resulting from legal matter | 22 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 22 |  |
| Acquisition and other related costs | — |  |  | — |  |  | — |  |  | — |  |  | 13 |  |  | 13 |  |
| Russia/Ukraine asset impairment | — |  |  | 4 |  |  | 1 |  |  | — |  |  | — |  |  | 5 |  |
| Total adjustments to operating profit | $ | 28 |  |  | $ | 10 |  |  | $ | (1,102) |  |  | $ | — |  |  | $ | 15 |  |  | $ | (1,049) |  |
| Adjusted operating profit | $ | 1,083 |  |  | $ | 264 |  |  | $ | 250 |  |  | $ | (40) |  |  | $ | (50) |  |  | $ | 1,507 |  |
| Adjusted operating margin | 17.0 | % |  | 13.1 | % |  | 14.7 | % |  |  |  |  |  | 15.3 | % |

[0001783180-22-000045:8k_2_02:75]
|  | (Unaudited) |
|  | For the Six Months Ended June 30, 2021 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 5,606 |  |  | $ | 2,026 |  |  | $ | 2,707 |  |  | $ | (200) |  |  | $ | — |  |  | $ | 10,139 |  |
| Segment operating profit | $ | 938 |  |  | $ | 250 |  |  | $ | 298 |  |  | $ | (63) |  |  | $ | (69) |  |  | $ | 1,354 |  |
| Reported operating margin | 16.7 | % |  | 12.3 | % |  | 11.0 | % |  |  |  |  |  | 13.4 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 11 |  |  | $ | 5 |  |  | 20 |  |  | $ | — |  |  | $ | 3 |  |  | $ | 39 |  |
| Acquisition and other related costs | 2 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2 |  |
| Chubb transaction costs | — |  |  | — |  |  | 15 |  |  | — |  |  | — |  |  | 15 |  |
| Separation costs | — |  |  | — |  |  | — |  |  | 17 |  |  | 2 |  | 19 |  |
| Total adjustments to operating profit | $ | 13 |  |  | $ | 5 |  |  | $ | 35 |  |  | $ | 17 |  |  | $ | 5 |  |  | $ | 75 |  |
| Adjusted operating profit | $ | 951 |  |  | $ | 255 |  |  | $ | 333 |  |  | $ | (46) |  |  | $ | (64) |  |  | $ | 1,429 |  |
| Adjusted operating margin | 17.0 | % |  | 12.6 | % |  | 12.3 | % |  |  |  |  |  | 14.1 | % |

[0001783180-22-000045:8k_2_02:76]
10

[0001783180-22-000045:8k_2_02:77]
Carrier Global Corporation

[0001783180-22-000045:8k_2_02:78]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-22-000045:8k_2_02:79]
Net Income, Earnings Per Share, and Effective Tax Rate

[0001783180-22-000045:8k_2_02:80]
|  | (Unaudited) |
|  | For the Three Months Ended June 30, 2022 |  | For the Six Months Ended June 30, 2022 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,211 |  |  | $ | — |  |  | $ | 5,211 |  |  | $ | 9,865 |  |  | $ | — |  |  | $ | 9,865 |  |
| Operating profit | $ | 819 |  |  | 38 |  | a | $ | 857 |  |  | $ | 2,556 |  |  | (1,049) |  | a | $ | 1,507 |  |
| Operating margin | 15.7 | % |  |  |  | 16.4 | % |  | 25.9 | % |  |  |  | 15.3 | % |
| Income from operations before income taxes | $ | 757 |  |  | 38 |  | a,b | $ | 795 |  |  | $ | 2,445 |  |  | (1,077) |  | a,b | $ | 1,368 |  |
| Income tax expense | $ | (170) |  |  | (12) |  | c | $ | (182) |  |  | $ | (471) |  |  | 197 |  | c | $ | (274) |  |
| Income tax rate | 22.5 | % |  |  |  | 22.9 | % |  | 19.3 | % |  |  |  | 20.0 | % |
| Net income attributable to common shareowners | $ | 573 |  |  | $ | 26 |  |  | $ | 599 |  |  | $ | 1,952 |  |  | $ | (880) |  |  | $ | 1,072 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 13 |  | a |  |  |  |  | $ | 23 |  | a |  |
| Chubb gain |  |  | — |  | a |  |  |  |  | (1,112) |  | a |  |
| Charge resulting from legal matter |  |  | 22 |  | a |  |  |  |  | 22 |  | a |  |
| Acquisition and other related costs |  |  | 7 |  | a |  |  |  |  | 13 |  | a |  |
| Russia/Ukraine asset impairment |  |  | (4) |  | a |  |  |  |  | 5 |  | a |  |
| Debt extinguishment (gain), net (1) |  |  | — |  | b |  |  |  |  | (28) |  | b |  |
| Total adjustments |  |  | $ | 38 |  |  |  |  |  |  | $ | (1,077) |  |  |  |
| Tax effect on adjustments above |  |  | $ | (7) |  |  |  |  |  |  | $ | 202 |  |  |  |
| Tax specific adjustments |  |  | (5) |  |  |  |  |  |  | (5) |  |  |  |
| Total tax adjustments |  |  | $ | (12) |  | c |  |  |  |  | $ | 197 |  | c |  |
| Shares outstanding - Diluted | 862.7 |  |  |  |  | 862.7 |  |  | 868.4 |  |  |  |  | 868.4 |  |
| Earnings per share - Diluted | $ | 0.67 |  |  |  |  | $ | 0.69 |  |  | $ | 2.25 |  |  |  |  | $ | 1.23 |  |

[0001783180-22-000045:8k_2_02:81]
(1) The Company repurchased approximately $1.15 billion of aggregate principal senior notes on March 30, 2022 and recognized a net gain of $33 million and wrote-off $5 million of unamortized deferred financing costs in Interest (expense) income, net on the accompanying Unaudited Condensed Consolidated Statement of Operations.

[0001783180-22-000045:8k_2_02:82]
11

[0001783180-22-000045:8k_2_02:83]
Carrier Global Corporation

[0001783180-22-000045:8k_2_02:84]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-22-000045:8k_2_02:85]
Net Income, Earnings Per Share, and Effective Tax Rate

[0001783180-22-000045:8k_2_02:86]
|  | (Unaudited) |
|  | For the Three Months Ended June 30, 2021 |  | For the Six Months Ended June 30, 2021 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,440 |  |  | $ | — |  |  | $ | 5,440 |  |  | $ | 10,139 |  |  | $ | — |  |  | $ | 10,139 |  |
| Operating profit | $ | 783 |  |  | 38 |  | a | $ | 821 |  |  | $ | 1,354 |  |  | 75 |  | a | $ | 1,429 |  |
| Operating margin | 14.4 | % |  |  |  | 15.1 | % |  | 13.4 | % |  |  |  | 14.1 | % |
| Income from operations before income taxes | $ | 731 |  |  | 38 |  | a,b | $ | 769 |  |  | $ | 1,227 |  |  | 94 |  | a,b | $ | 1,321 |  |
| Income tax expense | $ | (234) |  |  | 42 |  | c | $ | (192) |  |  | $ | (338) |  |  | 29 |  | c | $ | (309) |  |
| Income tax rate | 32.0 | % |  |  |  | 25.0 | % |  | 27.5 | % |  |  |  | 23.4 | % |
| Net income attributable to common shareowners | $ | 487 |  |  | $ | 80 |  |  | $ | 567 |  |  | $ | 871 |  |  | $ | 123 |  |  | $ | 994 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 21 |  | a |  |  |  |  | $ | 39 |  | a |  |
| Acquisition and other related costs |  |  | 14 |  | a |  |  |  |  | 17 |  | a |  |
| Separation costs |  |  | 3 |  | a |  |  |  |  | 19 |  | a |  |
| Debt prepayment costs |  |  | — |  | b |  |  |  |  | 19 |  | b |  |
| Total adjustments |  |  | $ | 38 |  |  |  |  |  |  | $ | 94 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (1) |  |  |  |  |  |  | $ | (14) |  |  |  |
| Tax specific adjustments |  |  | 43 |  |  |  |  |  |  | 43 |  |  |  |
| Total tax adjustments |  |  | $ | 42 |  | c |  |  |  |  | $ | 29 |  | c |  |
| Shares outstanding - Diluted | 890.9 |  |  |  |  | 890.9 |  |  | 890.4 |  |  |  |  | 890.4 |  |
| Earnings per share - Diluted | $ | 0.55 |  |  |  |  | $ | 0.64 |  |  | $ | 0.98 |  |  |  |  | $ | 1.12 |  |

[0001783180-22-000045:8k_2_02:87]
12

[0001783180-22-000045:8k_2_02:88]
Carrier Global Corporation

[0001783180-22-000045:8k_2_02:89]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-22-000045:8k_2_02:90]
Components of Changes in Net Sales

[0001783180-22-000045:8k_2_02:91]
| Three Months Ended June 30, 2022 Compared with Three Months Ended June 30, 2021 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 8 | % |  | (1) | % |  | 2 | % |  | — | % |  | 9 | % |
| Refrigeration | 9 | % |  | (7) | % |  | — | % |  | — | % |  | 2 | % |
| Fire & Security | 3 | % |  | (2) | % |  | (38) | % |  | — | % |  | (37) | % |
| Consolidated | 7 | % |  | (3) | % |  | (8) | % |  | — | % |  | (4) | % |

[0001783180-22-000045:8k_2_02:92]
| Six Months Ended June 30, 2022 Compared with Six Months Ended June 30, 2021 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 12 | % |  | (1) | % |  | 3 | % |  | (1) | % |  | 13 | % |
| Refrigeration | 5 | % |  | (5) | % |  | — | % |  | — | % |  | — | % |
| Fire & Security | 4 | % |  | (2) | % |  | (39) | % |  | — | % |  | (37) | % |
| Consolidated | 9 | % |  | (3) | % |  | (9) | % |  | — | % |  | (3) | % |

[0001783180-22-000045:8k_2_02:93]
Net Sales Excluding Impact of Chubb

[0001783180-22-000045:8k_2_02:94]
|  | (Unaudited) |
|  | For the Three Months Ended June 30, 2021 |  | For the Six Months Ended June 30, 2021 |
|  | Carrier |  | Fire and Security |  | Carrier |  | Fire and Security |
| Net Sales: |  |  |  |  |  |  |  |
| Reported | $ | 5,440 |  |  | $ | 1,403 |  |  | $ | 10,139 |  |  | $ | 2,707 |  |
| Chubb | (554) |  |  | (554) |  |  | (1,102) |  |  | (1,102) |  |
| Net sales excluding impact of Chubb | $ | 4,886 |  |  | $ | 849 |  |  | $ | 9,037 |  |  | $ | 1,605 |  |
| Percentage increase in Net sales excluding impact of Chubb | 7 | % |  | 4 | % |  | 9 | % |  | 6 | % |

[0001783180-22-000045:8k_2_02:95]
13

[0001783180-22-000045:8k_2_02:96]
Carrier Global Corporation

[0001783180-22-000045:8k_2_02:97]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-22-000045:8k_2_02:98]
Free Cash Flow Reconciliation

[0001783180-22-000045:8k_2_02:99]
|  |  | (Unaudited) |
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |  | Q1 |  | Q2 |  |  |
| (In millions) |  | 2021 |  | 2021 |  | 2021 |  | 2021 |  | 2021 |  | 2022 |  | 2022 |  |  |
| Net cash flows provided by (used in) operating activities |  | $ | 184 |  |  | $ | 561 |  |  | $ | 579 |  |  | $ | 913 |  |  | $ | 2,237 |  |  | $ | (202) |  |  | $ | 32 |  |  |  |
| Less: Capital expenditures |  | 53 |  |  | 79 |  |  | 74 |  |  | 138 |  | 344 |  |  | 56 |  |  | 66 |  |  |  |
| Free cash flow |  | $ | 131 |  |  | $ | 482 |  |  | $ | 505 |  |  | $ | 775 |  |  | $ | 1,893 |  |  | $ | (258) |  |  | $ | (34) |  |  |  |

[0001783180-22-000045:8k_2_02:100]
Net Debt Reconciliation

[0001783180-22-000045:8k_2_02:101]
|  |  | (Unaudited) |
| (In millions) |  | June 30, 2022 |  | December 31, 2021 |
| Long-term debt |  | $ | 8,298 |  |  | $ | 9,513 |  |
| Current portion of long-term debt |  | 269 |  |  | 183 |  |
| Less: Cash and cash equivalents |  | 3,017 |  |  | 2,987 |  |
| Net debt |  | $ | 5,550 |  |  | $ | 6,709 |  |

[0001783180-22-000045:8k_2_02:102]
14
