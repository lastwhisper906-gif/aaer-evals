# CARR MD&A — 0001783180-25-000008


## mdna

[0001783180-25-000008:mdna:1]
ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001783180-25-000008:mdna:2]
BUSINESS OVERVIEW

[0001783180-25-000008:mdna:3]
Business Summary

[0001783180-25-000008:mdna:4]
Carrier Global Corporation ("we" or "our") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to our customers. Our portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic and Carrier Transicold that offer innovative heating, ventilating and air conditioning ("HVAC"), refrigeration and cold chain transportation solutions to help make the world safer and more comfortable. We also provide a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. Our operations are classified into two segments: HVAC and Refrigeration.

[0001783180-25-000008:mdna:5]
Through our performance-driven culture, we anticipate creating long-term shareowner value by investing strategically to strengthen our product position in homes, buildings and across the cold chain in order to drive profitable growth. We believe our business segments are well positioned to benefit from favorable secular trends, including the mega-trends of urbanization, population growth and demographic shifts, food security and safety, digitalization, global connectivity and energy efficiency. Coupled with our industry-leading brands and track record of innovation, we continue to provide market-leading solutions for our customers.

[0001783180-25-000008:mdna:6]
Our worldwide operations are affected by global and regional industrial, economic and political factors, trade policies and trends. They are also affected by changes in the general level of economic activity, such as changes in business and consumer spending, construction and shipping activity as well as short-term economic factors such as currency fluctuations, commodity price volatility and supply disruptions. We continue to invest in our business, take pricing actions to mitigate supply chain and inflationary pressures, develop new products and services in order to remain competitive in our markets and use risk management strategies to mitigate various exposures.

[0001783180-25-000008:mdna:7]
33

[0001783180-25-000008:mdna:8]
We are actively monitoring recent trade policy and tariff announcements including the three executive orders issued by the President in February 2025 directing the United States to impose new tariffs on imports from Canada, Mexico and China and the subsequent announcement that the Administration intended to pause tariffs on Canada and Mexico for a month. We are currently evaluating the potential impact of the announced tariffs on our business and financial condition and actions we may take to mitigate the impact. In addition, we are currently monitoring the potential impact, if any, of actions taken by these countries in response to the announced tariffs. There can be no assurance that the future imposition of any tariffs, changes thereto or potential actions taken by countries in response to the tariffs will not have a material adverse effect upon our results of operations, financial condition or liquidity in any period or that any actions we take to mitigate the impact of the tariffs will be effective.

[0001783180-25-000008:mdna:9]
Significant Events

[0001783180-25-000008:mdna:10]
Acquisition of Viessmann Climate Solutions

[0001783180-25-000008:mdna:11]
On April 25, 2023, we announced that we entered into a Share Purchase Agreement (the “Agreement”) to acquire the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (“Viessmann”), a privately-held company. The VCS Business develops intelligent, integrated and sustainable technologies, including heat pumps, boilers, photovoltaic systems, home battery storage and digital solutions, primarily for residential customers in Europe. The acquisition was completed on January 2, 2024. As a result, the assets, liabilities and results of operations of the VCS Business are consolidated in the accompanying Consolidated Financial Statements as of the date of acquisition and reported within our HVAC segment.

[0001783180-25-000008:mdna:12]
Portfolio Transformation

[0001783180-25-000008:mdna:13]
On June 2, 2024, we completed the sale of our Access Solutions business ("Access Solutions") for cash proceeds of $5.0 billion. Access Solutions, historically reported in our Fire & Security segment, is a global supplier of physical security and digital access solutions supporting the hospitality, commercial, education and military markets. We recognized a net gain on the sale of $1.8 billion, which is included in Discontinued operations, net of tax on the accompanying Consolidated Statement of Operations during the year ended December 31, 2024.

[0001783180-25-000008:mdna:14]
On July 1, 2024, we completed the sale of our Industrial Fire business ("Industrial Fire") for cash proceeds of $1.4 billion. Industrial Fire, historically reported in our Fire & Security segment, is a leading manufacturer of a full spectrum of fire detection and suppression solutions and services in critical high-hazard environments, including oil and gas, power generation, marine and offshore facilities, automotive, data centers and aircraft hangars. We recognized a net gain on the sale of $319 million, which is included in Discontinued operations, net of tax on the accompanying Consolidated Statement of Operations during the year ended December 31, 2024.

[0001783180-25-000008:mdna:15]
On October 1, 2024, we completed the sale of our Commercial Refrigeration business ("CCR") for cash proceeds of $679 million. CCR, historically reported in our Refrigeration segment, is a global supplier of turnkey solutions for commercial refrigeration systems and services, with a primary focus on serving food retail customers, cold storage facilities and warehouses. We recognized a gross gain on the sale of $318 million, which is included in Other income (expense), net on the accompanying Consolidated Statement of Operations during the year ended December 31, 2024. The net proceeds received are subject to working capital and other adjustments provided in the stock purchase agreement.

[0001783180-25-000008:mdna:16]
On December 2, 2024, we completed the sale of our Commercial and Residential Fire business ("CRF Business") for cash proceeds of $2.9 billion. The CRF Business, historically reported in our Fire & Security segment, is a leading manufacturer of fire detection and alarm solutions for both commercial and residential applications. We recognized a net gain on the sale of $1.4 billion, which is included in Discontinued operations, net of tax on the accompanying Consolidated Statement of Operations during the year ended December 31, 2024. The net proceeds received are subject to working capital and other adjustments provided in the stock purchase agreement.

[0001783180-25-000008:mdna:17]
Deconsolidation of Kidde-Fenwal, Inc.

[0001783180-25-000008:mdna:18]
On May 14, 2023, Kidde-Fenwal, Inc. ("KFI"), an indirect wholly-owned subsidiary of ours, filed a petition for voluntary reorganization under Chapter 11 of the United States Bankruptcy Code ("Chapter 11") in the United States Bankruptcy Court for the District of Delaware. KFI, an industrial fire detection and suppression business historically reported in our Fire & Security segment, filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware (the “Bankruptcy Court”) seeking relief under chapter 11 of the Bankruptcy Code. As of the petition date, KFI was deconsolidated and its respective assets and liabilities were derecognized from our Consolidated Financial Statements.

[0001783180-25-000008:mdna:19]
RESULTS OF OPERATIONS

[0001783180-25-000008:mdna:20]
This discussion summarizes the significant factors affecting our consolidated results of operations, financial condition and liquidity for the year ended December 31, 2024, compared with December 31, 2023. This discussion should be read in conjunction with Item 8, the Consolidated Financial Statements and the accompanying Notes to the Consolidated Financial Statements in this Annual Report. A detailed discussion of the year ended December 31, 2023, compared with December 31, 2022, is not included herein and can be found in the Management's Discussion and Analysis of Financial Condition and Results of Operations section in the Company's 2023 Annual Report, filed with the SEC on February 6, 2024, under the heading "Results of Operations," which is incorporated herein by reference.

[0001783180-25-000008:mdna:21]
Year Ended December 31, 2024 Compared with Year Ended December 31, 2023

[0001783180-25-000008:mdna:22]
The following represents our consolidated net sales and operating results:

[0001783180-25-000008:mdna:23]
| (In millions) | 2024 |  | 2023 |  | Period Change |  | % Change |  |
| Net sales | $ | 22,486 |  |  | $ | 18,951 |  |  | $ | 3,535 |  |  | 19 | % |  |
| Cost of products and services sold | (16,505) |  |  | (13,789) |  |  | (2,716) |  |  | 20 | % |  |
| Gross margin | 5,981 |  |  | 5,162 |  |  | 819 |  |  | 16 | % |  |
| Operating expenses | (3,335) |  |  | (3,002) |  |  | (333) |  |  | 11 | % |  |
| Operating profit | 2,646 |  |  | 2,160 |  |  | 486 |  |  | 23 | % |  |
| Non-operating income (expense), net | (372) |  |  | (161) |  |  | (211) |  |  | 131 | % |  |
| Earnings (loss) before income taxes | 2,274 |  |  | 1,999 |  |  | 275 |  |  | 14 | % |  |
| Income tax expense | (1,062) |  |  | (521) |  |  | (541) |  |  | 104 | % |  |
| Earnings (loss) from continuing operations | 1,212 |  |  | 1,478 |  |  | (266) |  |  | (18) | % |  |
| Discontinued operations, net of income taxes | 4,496 |  |  | (38) |  |  | 4,534 |  |  | (11932) | % |  |
| Net earnings (loss) | 5,708 |  |  | 1,440 |  |  | 4,268 |  |  | 296 | % |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations | 104 |  |  | 91 |  |  | 13 |  |  | 14 | % |  |
| Net earnings (loss) attributable to common shareowners | $ | 5,604 |  |  | $ | 1,349 |  |  | $ | 4,255 |  |  | 315 | % |  |

[0001783180-25-000008:mdna:24]
Net Sales

[0001783180-25-000008:mdna:25]
For the year ended December 31, 2024, Net sales was $22.5 billion, an 19% increase compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-25-000008:mdna:26]
|  | 2024 |  |
| Organic / Operational | 3 | % |  |
| Acquisitions and divestitures, net | 16 | % |  |
| Total % change | 19 | % |  |

[0001783180-25-000008:mdna:27]
Organic sales for the year ended December 31, 2024, increased by 3% compared with the same period of 2023. The organic increase was primarily driven by our HVAC segment due to improved end-markets in the Americas, which more than offset reduced end-markets in EMEA and Asia. Results in our Refrigeration segment were down compared to the prior year as each of the segment's businesses experienced challenges in certain end-markets. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-25-000008:mdna:28]
Gross Margin

[0001783180-25-000008:mdna:29]
For the year ended December 31, 2024, gross margin was $6.0 billion, a 16% increase compared with the same period of 2023. The components were as follows:

[0001783180-25-000008:mdna:30]
| (In millions) | 2024 |  | 2023 |
| Net sales | $ | 22,486 |  |  | $ | 18,951 |  |
| Cost of products and services sold | (16,505) |  |  | (13,789) |  |
| Gross margin | $ | 5,981 |  |  | $ | 5,162 |  |
| Percentage of net sales | 26.6 | % |  | 27.2 | % |

[0001783180-25-000008:mdna:31]
Gross margin increased by $819 million compared with the year ended December 31, 2023. The main driver of the increase related to ongoing customer demand, pricing improvements and our continued focus on productivity initiatives. Operating results associated with the VCS Business since the date of acquisition further benefited gross margin during the period. However, the results of the VCS Business included inventory step-up, backlog amortization and intangible asset amortization resulting from the recognition of acquired assets at fair value. These costs had a 260 basis point unfavorable impact on gross margin as a percentage of Net sales. As a result, gross margin as a percentage of Net sales decreased by 60 basis points compared with the same period of 2023.

[0001783180-25-000008:mdna:32]
Operating Expenses

[0001783180-25-000008:mdna:33]
For the year ended December 31, 2024, operating expenses, including Equity method investment net earnings, was $3.3 billion, a 11% increase compared with the same period of 2023. The components were as follows:

[0001783180-25-000008:mdna:34]
|  | For the Year Ended December 31, |  |  |
| (In millions) | 2024 |  | 2023 |  |  |
| Selling, general and administrative | $ | (3,197) |  |  | $ | (2,607) |  |  |  |
| Research and development | (686) |  |  | (493) |  |  |  |
| Equity method investment net earnings | 231 |  |  | 211 |  |  |  |
| Other income (expense), net | 317 |  |  | (113) |  |  |  |
| Operating expenses | $ | (3,335) |  |  | $ | (3,002) |  |  |  |
| Percentage of net sales | 14.8 | % |  | 15.8 | % |  |  |

[0001783180-25-000008:mdna:35]
For the year ended December 31, 2024, Selling, general and administrative expenses were $3.2 billion, a 23% increase compared with the same period of 2023. The increase is primarily due to incremental expenses associated with the VCS Business since the date of acquisition. In addition, higher compensation and other employee-related costs further contributed to the increase. The current year also included $95 million of acquisition and divestiture-related costs compared with $123 million during the year ended December 31, 2023.

[0001783180-25-000008:mdna:36]
Research and development costs relate to new product development and new technology innovation. Due to the variable nature of program development schedules, year-over-year spending levels can fluctuate. In addition, we continue to invest to prepare for future energy efficiency and refrigerant regulation changes and in digital controls technologies.

[0001783180-25-000008:mdna:37]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the year ended December 31, 2024, Equity method investment net earnings were $231 million, a 9% increase compared with the same period of 2023. The increase was primarily driven by higher earnings in HVAC joint ventures across all regions. The increase was partially offset by a $23 million charge associated with the devaluation of U.S. Dollar denominated balances at an HVAC equity investment in Egypt. In addition, prior year results include a $16 million benefit recognized in connection with a favorable tax ruling at a minority owned joint venture.

[0001783180-25-000008:mdna:38]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. During the year ended December 31, 2024, we completed the sale of CCR and recognized a gain on the sale of $318 million. In addition, we recognized a $46 million gain associated with our share of United Technologies Corporation's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the Internal Revenue Service ("IRS"). In connection with the acquisition of the VCS Business, we recognized an $86 million loss on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price.

[0001783180-25-000008:mdna:39]
During the year ended December 31, 2023, we recognized a $96 million loss on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business. In addition, the carrying value of our previously held equity investments in Toshiba Carrier Corporation ("TCC") were recognized at fair value at the date of acquisition. As a result, we recognized an $8 million non-cash loss associated with the increase in our ownership interest.

[0001783180-25-000008:mdna:40]
Non-Operating Income (Expense), net

[0001783180-25-000008:mdna:41]
For the year ended December 31, 2024, Non-operating income (expense), net was $372 million, a 131% increase compared with the same period of 2023. The components were as follows:

[0001783180-25-000008:mdna:42]
|  | For the Year Ended December 31, |  |
| (In millions) | 2024 |  | 2023 |  |
| Non-service pension benefit (expense) | $ | (1) |  |  | $ | (1) |  |  |
| Interest expense | (580) |  |  | (306) |  |  |
| Interest income | 209 |  |  | 146 |  |  |
| Interest (expense) income, net | (371) |  |  | (160) |  |  |
| Non-operating income (expense), net | $ | (372) |  |  | $ | (161) |  |  |

[0001783180-25-000008:mdna:43]
Non-operating income (expense), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the year ended December 31, 2024, interest expense was $580 million, a 90% increase compared with the same period of 2023. During 2024, we redeemed $1.0 billion aggregate principal amount of USD-denominated 5.80% notes due in 2025 and redeemed €750 million aggregate principal amount of 4.375% Euro-denominated notes due 2025 with the proceeds from the issuance of €750 million aggregate principal amount of 3.625% Euro-denominated notes due 2037. In addition, we completed tender offers to repurchase approximately $1.1 billion aggregate principal which included $125 million of notes due 2034, $350 million of notes due 2054, and approximately $600 million of notes due 2050. Combined, we incurred make-whole premiums of $14 million in Interest expense, wrote off $17 million of unamortized deferred financing costs in Interest expense and recognized a net gain of $97 million in Interest income. During 2023, we entered into several financing arrangements in connection with the acquisition of the VCS Business and capitalized $105 million of deferred financing costs. As a result, we amortized $55 million of deferred financing costs in Interest expense, of which $47 million related to our senior unsecured bridge term loan facility (the "Bridge Loan").

[0001783180-25-000008:mdna:44]
Income Taxes

[0001783180-25-000008:mdna:45]
|  |  | 2024 |  | 2023 |  |  |
| Effective tax rate |  | 46.7 | % |  | 26.1 | % |  |  |

[0001783180-25-000008:mdna:46]
The effective tax rate for the year ended December 31, 2024, was higher than the statutory U.S. federal income tax rate. The increase was primarily driven by a net tax charge of $650 million related to a re-organization of the VCS Business and a non-deductible loss of $86 million on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business, partially offset by the lower effective tax rate on the $318 million gain on the sale of CCR and $44 million of foreign tax credits generated and utilized in the current year.

[0001783180-25-000008:mdna:47]
37

[0001783180-25-000008:mdna:48]
The effective tax rate for the year ended December 31, 2023, was higher than the statutory U.S. federal income tax rate. The increase was primarily driven by a net tax charge of $27 million relating to the re-organization and disentanglement of the CCR businesses in advance of the planned divestiture. In addition, the effective tax rate was impacted by the recognition of a deferred tax liability for withholding tax of $19 million on repatriated foreign earnings, non-deductible divestiture-related costs and a non-deductible loss of $96 million on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business.

[0001783180-25-000008:mdna:49]
Segment Review

[0001783180-25-000008:mdna:50]
We conduct our operations through two reportable segments:

[0001783180-25-000008:mdna:51]
•The HVAC segment provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-25-000008:mdna:52]
•The Refrigeration segment includes transport refrigeration and monitoring products, services and digital solutions for trucks, trailers, shipping containers, intermodal and rail.

[0001783180-25-000008:mdna:53]
We determine our segments based on how our Chief Executive Officer, who is the Chief Operating Decision Maker (the "CODM"), allocates resources, assesses performance and makes operational decisions. The CODM allocates resources and evaluates the financial performance of each of our segments based on Net sales and Operating profit. Adjustments to reconcile segment reporting to the consolidated results are included in Note 21 - Segment Financial Data.

[0001783180-25-000008:mdna:54]
Due to the completion of our portfolio transformation activities in 2024, we anticipate changes to our management reporting structure and to the information provided to our CODM beginning in 2025. As a result, we are reassessing our reportable segment structure to align with any changes.

[0001783180-25-000008:mdna:55]
Summary performance for each of our segments is as follows:

[0001783180-25-000008:mdna:56]
|  | Net Sales |  | Operating Profit |  | Operating Margin |
| (In millions) | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 |  |  |
| HVAC | $ | 19,078 |  |  | $ | 15,139 |  |  |  |  | $ | 2,308 |  |  | $ | 2,275 |  |  |  |  | 12.1 | % |  | 15.0 | % |  |  |
| Refrigeration | 3,475 |  |  | 3,818 |  |  |  |  | 715 |  |  | 428 |  |  |  |  | 20.6 | % |  | 11.2 | % |  |  |
| Total segment | $ | 22,553 |  |  | $ | 18,957 |  |  |  |  | $ | 3,023 |  |  | $ | 2,703 |  |  |  |  | 13.4 | % |  | 14.3 | % |  |  |

[0001783180-25-000008:mdna:57]
HVAC Segment

[0001783180-25-000008:mdna:58]
For the year ended December 31, 2024, Net sales in our HVAC segment was $19.1 billion, a 26% increase compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-25-000008:mdna:59]
|  | Net sales |
| Organic / Operational | 5 | % |
| Acquisitions and divestitures, net | 21 | % |
| Total % change | 26 | % |

[0001783180-25-000008:mdna:60]
The organic increase in Net sales of 5% was driven by continued strong results in the segment. Growth in the Americas (up 9%) was primarily driven by our Commercial and Residential businesses which benefited from ongoing customer demand and pricing improvements. Moderate growth in our Light Commercial business was due to improved pricing compared with the prior year. EMEA (down 1%) continues to be impacted by reduced volumes in residential markets. The reduction was partially offset by ongoing customer demand and pricing improvements in our Commercial business. Results in Asia (down 2%) were impacted by lower demand in the region, primarily in China.

[0001783180-25-000008:mdna:61]
On January 2, 2024, we acquired the VCS Business, a leading manufacturer of high efficiency heating and renewable energy systems in Europe. The results of the VCS Business have been included in our Consolidated Financial Statements since the date of acquisition. The transaction added 21% to Net sales for the year ended December 31, 2024, and is included in Acquisitions and divestitures, net.

[0001783180-25-000008:mdna:62]
For the year ended December 31, 2024, Operating profit in our HVAC segment was $2.3 billion, a 1% increase compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-25-000008:mdna:63]
|  | Operating profit |
| Organic / Operational | 23 | % |
| Acquisitions and divestitures, net | 3 | % |
| Amortization of acquired intangibles | (24) | % |
| Restructuring | (2) | % |
| Other | 1 | % |
| Total % change | 1 | % |

[0001783180-25-000008:mdna:64]
The operational profit increase of 23% was primarily attributable to ongoing customer demand and pricing improvements in certain end-markets compared with the prior year. In addition, favorable productivity initiatives further benefited the segment. These benefits more than offset volume reductions in certain end-markets. Higher earnings from equity method investments further benefited operational profit in the segment. The increase was partially offset by a $23 million charge associated with the devaluation of U.S. Dollar denominated balances at an HVAC equity investment in Egypt.

[0001783180-25-000008:mdna:65]
Refrigeration Segment

[0001783180-25-000008:mdna:66]
For the year ended December 31, 2024, Net sales in our Refrigeration segment was $3.5 billion, a 9% decrease compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-25-000008:mdna:67]
|  | Net sales |
| Organic / Operational | (1) | % |
| Acquisitions and divestitures, net | (8) | % |
| Total % change | (9) | % |

[0001783180-25-000008:mdna:68]
The organic decrease in Net sales of 1% was primarily driven by volume reductions within certain end-markets compared with the prior year. Transport results decreased (down 8%) compared to the prior year primarily due to lower end-market demand in North America. The reduction was partially offset by higher volumes in Asia and Europe. Results in the Container business (up 24%) was primarily driven by strong end-market demand and improved pricing.

[0001783180-25-000008:mdna:69]
On October 1, 2024, we divested CCR, a global supplier of turnkey solutions for commercial refrigeration systems and services. The results of CCR are excluded from our Consolidated Financial Statements subsequent to the divestiture date. The transaction reduced Net Sales by 8% for the year ended December 31, 2024, and is included in Acquisitions and divestitures, net.

[0001783180-25-000008:mdna:70]
For the year ended December 31, 2024, Operating profit in our Refrigeration segment was $715 million, a 67% increase compared with the same period of 2023. The components of the year-over-year change were as follows:

[0001783180-25-000008:mdna:71]
|  | Operating profit |
| Organic / Operational | 2 | % |
| Foreign currency translation | (1) | % |
| Acquisitions and divestitures, net | (4) | % |
| Restructuring | 3 | % |
| CCR gain on sale | 74 | % |
| Other | (7) | % |
| Total % change | 67 | % |

[0001783180-25-000008:mdna:72]
The increase in operational profit of 2% was primarily driven by favorable productivity initiatives and price improvements compared with the prior year. In addition, volume growth in certain end-markets further benefited the segment. These amounts were partially offset by volume reductions in certain other end-markets. Amounts reported in Other represent $10 million of divestiture-related costs associated with the sale of CCR. In addition, the prior year includes a $24 million gain on the sale of a business within the Transport business.

[0001783180-25-000008:mdna:73]
LIQUIDITY AND FINANCIAL CONDITION

[0001783180-25-000008:mdna:74]
We assess liquidity in terms of our ability to generate adequate amounts of cash necessary to fund our current and future cash requirements to support our business and strategic initiatives. In doing so, we review and analyze our cash on hand, working capital, debt service requirements and capital expenditures. We rely on operating cash flows as our primary source of liquidity. In addition, we have access to other sources of capital to finance our strategic initiatives and fund growth.

[0001783180-25-000008:mdna:75]
As of December 31, 2024, we had Cash and cash equivalents of $4.0 billion, of which approximately 44% was held by our foreign subsidiaries. We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which we can access funds held by foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection with contractual obligations related to acquisitions or divestitures or other legal obligations. As of December 31, 2024 and 2023, the amount of such restricted cash was $3 million and $1 million, respectively.

[0001783180-25-000008:mdna:76]
We continue to actively manage and strengthen our business portfolio to meet the current and future needs of our customers. This is accomplished through research and development activities with a focus on new product development and new technology innovation as well as sustaining activities with a focus on improving existing products and reducing production costs. We also pursue potential acquisitions to complement existing products and services to enhance our product portfolio. In addition, we routinely conduct discussions, evaluate targets and enter into agreements regarding possible acquisitions, divestitures, joint ventures and equity investments to manage our business portfolio.

[0001783180-25-000008:mdna:77]
We believe that our available cash and operating cash flows will be sufficient to meet our future operating cash needs. Our committed credit facilities and access to the debt and equity markets provide additional sources of short-term and long-term capital to fund current operations, debt maturities and future investment opportunities. Although we believe that the arrangements currently in place permit us to finance our operations on acceptable terms and conditions, our access to and the availability of financing on acceptable terms and conditions in the future will be impacted by many factors, including: (1) our credit ratings or absence of credit ratings; (2) the level of our existing indebtedness; (3) the restrictions under our debt agreements; (4) the liquidity of the overall capital markets and (5) the state of the economy. There can be no assurance that we will be able to obtain additional financing on terms favorable to us, if at all.

[0001783180-25-000008:mdna:78]
The following table contains several key measures of our financial condition and liquidity:

[0001783180-25-000008:mdna:79]
|  |  | As of December 31, |
| (In millions) |  | 2024 |  | 2023 |
| Cash and cash equivalents |  | $ | 3,969 |  |  | $ | 9,852 |  |
| Total debt |  | $ | 12,278 |  |  | $ | 14,293 |  |
| Total equity |  | $ | 14,395 |  |  | $ | 9,005 |  |
| Net debt (total debt less cash and cash equivalents) |  | $ | 8,309 |  |  | $ | 4,441 |  |
| Total capitalization (total debt plus total equity) |  | $ | 26,673 |  |  | $ | 23,298 |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | $ | 22,704 |  |  | $ | 13,446 |  |
| Total debt to total capitalization |  | 46 | % |  | 61 | % |
| Net debt to net capitalization |  | 37 | % |  | 33 | % |

[0001783180-25-000008:mdna:80]
Acquisition of VCS Business

[0001783180-25-000008:mdna:81]
On April 25, 2023, we announced that we entered into an Agreement to acquire the VCS Business. Under the terms of the Agreement, 20% of the purchase price was to be paid in Carrier common stock, issued directly to Viessmann and subject to certain lock-up provisions and 80% was to be paid in cash. Simultaneously, we entered into commitment letters with JPMorgan Chase Bank, N.A., BofA Securities, Inc. and Bank of America, N.A. to provide a €8.2 billion senior unsecured bridge term loan facility (the "Bridge Loan") to fund a portion of the Euro-denominated purchase price.

[0001783180-25-000008:mdna:82]
On May 19, 2023, we entered into a 364-day, $500 million, senior unsecured revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders (the "Revolver"). In addition, we entered into a senior unsecured delayed draw term loan credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders that permits aggregate borrowings of up to €2.3 billion (the "Delayed Draw Facility"). Upon entering into the Delayed Draw Facility, the aggregate principal amount of the Bridge Loan was reduced by €2.3 billion. In November 2023, we issued $3.0 billion principal amount of USD-denominated notes ("USD Notes") and €2.35 billion principal amount of Euro-denominated notes ("Euro Notes"). Upon issuance, the aggregate principal amount of the Bridge Loan was reduced by €5.4 billion. On January 2, 2024, we entered into a 60-day senior unsecured term loan agreement consisting of a Euro-denominated tranche in an aggregate amount of €113 million and a USD-denominated tranche in an aggregate amount of $349 million (the “60-day Loan”). Upon entering into the 60-day Loan, we reduced the final portion of the Bridge Loan by €500 million and subsequently terminated the agreement.

[0001783180-25-000008:mdna:83]
On January 2, 2024, we completed the acquisition of the VCS Business for $14.2 billion. The cash portion of the purchase price was funded through cash on hand, proceeds from the USD Notes and the Euro Notes and borrowings under the Delayed Draw Facility and the 60-day Loan. Proceeds from the Revolver became available upon closing.

[0001783180-25-000008:mdna:84]
In March 2024, borrowings under the 60-day loan were repaid. In May 2024, the Revolver was terminated and refinanced in order to extend its maturity to May 2025 (the "364-day Revolver"). In June 2024, we redeemed our $1.0 billion aggregate principal amount of 5.80% notes due in 2025 and repaid borrowings under the Delayed Draw Facility, which was subsequently terminated. In addition, we completed tender offers on certain tranches of our notes in August 2024 which included $125 million of notes due 2034, $350 million of notes due 2054 and approximately $600 million of notes due 2050. In November 2024, we issued €750 million aggregate principal amount of 3.625% notes due 2037 and used the proceeds to redeem €750 million aggregate principal amount of 4.375% notes due in 2025. In December 2024, we terminated the 364-day Revolver as part of a transaction to refinance and replace prior credit agreements.

[0001783180-25-000008:mdna:85]
Borrowings and Lines of Credit

[0001783180-25-000008:mdna:86]
We maintain a $2.0 billion unsecured, unsubordinated commercial paper program which we can use for general corporate purposes, including the funding of working capital and potential acquisitions. In addition, we maintain a $2.5 billion revolving credit agreement with various banks (the "Revolving Credit Facility") that matures in December 2029 which supports our commercial paper borrowing program and can be used for general corporate purposes. A ratings-based commitment fee is charged on unused commitments. As of December 31, 2024, we had no borrowings outstanding under our commercial paper program or our Revolving Credit Facility.

[0001783180-25-000008:mdna:87]
Our short-term obligations primarily consist of current maturities of long-term debt. Our long-term obligations primarily consist of long-term notes with maturity dates ranging between 2025 and 2054. Interest payments related to long-term notes are expected to approximate $420 million per year, reflecting an approximate weighted-average interest rate of 3.5%. Any borrowings from the Revolving Credit Facility are subject to variable interest rates. See Note 7 - Borrowings and Lines of Credit in the accompanying Notes to the Consolidated Financial Statements for additional information regarding the terms of our long-term debt obligations.

[0001783180-25-000008:mdna:88]
Scheduled maturities of long-term debt, excluding amortization of discount, are as follows:

[0001783180-25-000008:mdna:89]
| (In millions) |  |  |  |
| 2025 |  | $ | 1,252 |  |  |
| 2026 |  | $ | 70 |  |  |
| 2027 |  | $ | 1,284 |  |  |
| 2028 |  | $ | 803 |  |  |
| 2029 |  | $ | 19 |  |  |
| Thereafter |  | $ | 8,938 |  |  |

[0001783180-25-000008:mdna:90]
The following table presents our credit ratings and outlook as of December 31, 2024:

[0001783180-25-000008:mdna:91]
| Rating Agency | Long-term Rating (1) | Short-term Rating (2) |  | Outlook (2) (3) |
| S&P | BBB | A2 |  | Positive |
| Moody's | Baa2 | P2 |  | Positive |
| Fitch Ratings | BBB+ | F1 |  | Stable |

[0001783180-25-000008:mdna:92]
(1) The long-term rating was upgraded by Moody's to Baa2 on May 13, 2024. Fitch's was updated to BBB+ on October 18, 2024.

[0001783180-25-000008:mdna:93]
(2) Fitch upgraded its short-term rating to F1 from F2 and revised its outlook to stable from positive on October 18, 2024.

[0001783180-25-000008:mdna:94]
(3) S&P revised its outlook to positive from stable in December 2023.

[0001783180-25-000008:mdna:95]
Portfolio Transformation

[0001783180-25-000008:mdna:96]
On June 2, 2024, we completed the divestiture of Access Solutions for cash proceeds of $5.0 billion. On July 1, 2024, we completed the divestiture of Industrial Fire for cash proceeds of $1.4 billion. On October 1, 2024, we completed the divestiture of CCR for cash proceeds of $679 million, subject to customary working capital and other adjustments. On December 2, 2024, we completed the divestiture of the CRF Business for cash proceeds of $2.9 billion, subject to customary working capital and other adjustments. Consistent with our capital allocation strategy, the net proceeds will be used to fund repayment of debt, investments in organic and inorganic growth initiatives and capital returns to shareowners as well as for general corporate purposes.

[0001783180-25-000008:mdna:97]
Share Repurchase Program

[0001783180-25-000008:mdna:98]
We may purchase our outstanding common stock from time to time subject to market conditions and at our discretion. Repurchases occur in the open market or through one or more other public or private transactions pursuant to plans complying with Rules 10b5-1 and 10b-18 under the Exchange Act. Since the initial authorization in February 2021, the Company's Board of Directors authorized the repurchase of up to $7.1 billion of our outstanding common stock which includes a $3 billion increase approved in October 2024. As of December 31, 2024, the Company repurchased 70.1 million shares of common stock for an aggregate purchase price of $3.9 billion. As a result, the Company has approximately $3.2 billion remaining under the current authorization at December 31, 2024.

[0001783180-25-000008:mdna:99]
Dividends

[0001783180-25-000008:mdna:100]
We paid dividends on our common stock of $0.76 per share during the year ended December 31, 2024, totaling $670 million. On December 6, 2024, the Board of Directors declared a dividend of $0.225 per share payable on February 7, 2025, to shareowners of record at the close of business on December 20, 2024.

[0001783180-25-000008:mdna:101]
Discussion of Cash Flows

[0001783180-25-000008:mdna:102]
The following table reflects the major categories of cash flows for the following periods:

[0001783180-25-000008:mdna:103]
|  |  | For the Years Ended December 31, |
| (In millions) |  | 2024 |  | 2023 |  |  |
| Net cash provided by (used in): |  |  |  |  |  |  |
| Continuing operating activities |  | $ | 1,571 |  |  | $ | 2,252 |  |  |  |
| Continuing investing activities |  | (11,025) |  |  | (504) |  |  |  |
| Continuing financing activities |  | (4,611) |  |  | 4,632 |  |  |  |

[0001783180-25-000008:mdna:104]
Cash flows from continuing operating activities primarily represent inflows and outflows associated with our continuing operations. Primary activities include net earnings from continuing operations adjusted for non-cash transactions, working capital changes and changes in other assets and liabilities. The year-over-year decrease in net cash provided by continuing operating activities was primarily driven by an increase in working capital balances compared with the prior period. Improved inventory levels and lower customer receivable balances were more than offset by lower accounts payable balances.

[0001783180-25-000008:mdna:105]
Cash flows from continuing investing activities primarily represent inflows and outflows associated with long-term assets. Primary activities include capital expenditures, acquisitions, divestitures and proceeds from the sale of fixed assets. During the year ended December 31, 2024, net cash used in continuing investing activities was $11.0 billion. The primary driver of the outflow related to the acquisition of the VCS Business, which totaled $10.8 billion, net of cash acquired. Additional investing outflows include $264 million related to settlement of derivatives and $519 million of capital expenditures. These outflows were partially offset by net proceeds of $634 million related to divestitures. During the year ended December 31, 2023, net cash used in continuing investing activities was $504 million. The primary driver of the outflow related to $439 million of capital expenditures. In addition, we settled working capital and other transaction-related items associated with the acquisition of Toshiba Carrier Corporation and invested in several businesses. These amounts totaled $84 million, net of cash acquired and were partially offset by the proceeds from the sale of a business during the period.

[0001783180-25-000008:mdna:106]
Cash flows from continuing financing activities primarily represent inflows and outflows associated with equity or borrowings. Primary activities include debt transactions, paying dividends to shareowners and the repurchase of our common stock. During the year ended December 31, 2024, net cash used in continuing financing activities was $4.6 billion. The primary driver of the outflow is due to repayments of long-term debt of $5.3 billion which includes prepayments of the Delayed Draw Facility, redemption of our 5.80% notes due in 2025 and 4.375% notes due in 2025 and tender offers of approximately $1.1 billion. In addition, we made payments totaling $1.9 billion to repurchase shares of our common stock and dividend payments of $670 million to our common shareowners. These outflows were partially offset by the proceeds of borrowings used to fund the cash portion of the acquisition of the VCS Business and the November 2024 issuance of our 3.625% notes due 2037. During the year ended December 31, 2023, net cash provided by continuing financing activities was $4.6 billion. The primary driver of the inflow related to the issuance of the USD Notes and the Euro Notes related to the acquisition of the VCS Business. The inflow was partially offset by the payment of $620 million in dividends to our common shareowners. In addition, we paid $62 million to repurchase shares of our common stock.

[0001783180-25-000008:mdna:107]
Summary of Other Sources and Uses of Cash

[0001783180-25-000008:mdna:108]
Rapid changes in legislation, regulations and government policies, including with respect to regulations intended to combat climate events, affect our operations and business in the countries, regions and localities in which we operate and sell our products. We are committed to comply with these regulations and to environmental stewardship. As a result, we have set goals to invest over $4 billion by 2030 to develop intelligent climate and energy solutions that reduce environmental impacts. In addition, to reach our goal to achieve carbon neutrality in our operations by 2030, we expect to incur capital expenditures for climate-related projects including upgrading our facilities, equipment and controls to optimize energy efficiency, transition our energy consumption from a dependency on fossil fuels to renewable energy and expanding the electrification of our fleet vehicles. See section entitled Environmental Goals under the headings "Other Matters Relating to Our Business as a Whole" for additional information.

[0001783180-25-000008:mdna:109]
We also have obligations related to environmental and asbestos matters, pension and post-retirement benefits and taxes. See Note 10 - Employee Benefit Plans, Note 17 - Income Taxes, and Note 23 - Commitments and Contingent Liabilities in the accompanying Notes to the Consolidated Financial Statements in this Annual Report for additional information.

[0001783180-25-000008:mdna:110]
CRITICAL ACCOUNTING ESTIMATES

[0001783180-25-000008:mdna:111]
Our financial statements are prepared in accordance with accounting principles generally accepted in the United States. The preparation of financial statements in conformity with those accounting principles requires management to use judgement in making estimates and assumptions based on the relevant information available at the end of each period. These estimates and assumptions have a significant effect on reported amounts of assets, liabilities, sales and expenses as well as the disclosure of contingent assets and liabilities because they result primarily from the need to make estimates and assumptions on matters that are inherently uncertain. Actual results could differ from management's estimates.

[0001783180-25-000008:mdna:112]
Business Combinations

[0001783180-25-000008:mdna:113]
In accordance with ASC 805, Business Combinations ("ASC 805"), acquisitions that meet the definition of a business are recorded using the acquisition method of accounting. We recognize and measure the identifiable assets acquired, liabilities assumed and any non-controlling interest as of the acquisition date at fair value. The valuation of intangible assets is determined by an income approach methodology, using assumptions such as projected future revenues, customer attrition rates, royalty rates, tax rates and discount rates. The excess, if any, of total consideration transferred in a business combination over the fair value of identifiable assets acquired, liabilities assumed and any non-controlling interest is recognized as goodwill. Costs incurred as a result of a business combination other than costs related to the issuance of debt or equity securities are recorded in the period the costs are incurred.

[0001783180-25-000008:mdna:114]
Goodwill and Indefinite-Lived Intangible Assets

[0001783180-25-000008:mdna:115]
In accordance with the Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") 350, Intangibles - Goodwill and Other ("ASC 350"), goodwill and other indefinite-lived intangible assets are tested and reviewed annually for impairment or whenever there is a material change in events or circumstances that indicate that the fair value of the asset is more likely than not less than the carrying amount of the asset. We test our reporting units and indefinite-lived intangible assets for impairment annually as of the first day of our third quarter, or more frequently if events or circumstances occur.

[0001783180-25-000008:mdna:116]
ASC 350 provides entities with an option to perform a qualitative assessment (commonly referred to as “step zero”) to determine whether a quantitative analysis for impairment is necessary. In performing step zero for our impairment test, we are required to make assumptions and judgments, including but not limited to the following: the evaluation of macroeconomic conditions as related to our business, industry and market trends, and the overall future financial performance of our reporting units and future opportunities in the markets in which they operate. If impairment indicators are present after performing step zero, we would perform a quantitative impairment analysis to estimate fair value.

[0001783180-25-000008:mdna:117]
For our 2024 goodwill and indefinite-lived intangible assets impairment tests, we elected to perform qualitative step zero assessments for all tests (except one) to determine if it was more likely than not that the fair values of our reporting units and indefinite-lived intangible assets were below carrying value. We considered macroeconomic factors including global economic growth, general macroeconomic trends for the markets in which our reporting units operate and where the intangible assets are utilized and the forecasted growth of the global industrial products industry. In addition to these macroeconomic factors, among other things, we considered the reporting units’ current results and forecasts, changes in the nature of each business, any significant legal, regulatory, contractual, political or other business climate factors, changes in the industry and competitive environment, changes in the composition or carrying amount of net assets and any intention to sell or dispose of a reporting unit or cease the use of any indefinite-lived intangible assets. Based upon our qualitative analysis, we determined that our goodwill and indefinite-lived intangible assets were not impaired.

[0001783180-25-000008:mdna:118]
For the remaining goodwill test, we elected to perform a quantitative test to determine if it was more likely than not that the fair value of our Refrigeration reporting unit was below carrying value. We utilized a discounted cash flow method under the income approach to estimate the fair value of the reporting unit. The approach relies on our estimates of future cash flows, long-term growth rates, discount rates and income tax rates and explicitly addressed factors such as timing, growth and margins with due consideration given to forecasting, market and geographic risk. The results did not indicate any goodwill impairment. A significant increase in the discount rate, decrease in the long-term growth rate or substantial reductions in our end markets and volume assumptions could have a negative impact on the estimated fair value of this reporting unit.

[0001783180-25-000008:mdna:119]
Revenue Recognition from Contracts with Customers

[0001783180-25-000008:mdna:120]
Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of our performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally the time of shipment. The remaining portion of our performance obligations are recognized over time as the customer simultaneously obtains control as we perform work under a contract, or if the product being produced for the customer has no alternative use and we have a contractual right to payment.

[0001783180-25-000008:mdna:121]
A performance obligation is a distinct good, service or a bundle of goods and services promised in a contract. Some of our contracts with customers contain a single performance obligation, while others contain multiple performance obligations most commonly when a contract spans multiple phases of a product life-cycle such as production, installation, maintenance and support. We identify performance obligations at the inception of a contract and allocate the transaction price to each distinct performance obligation. Revenue is recognized when or as the performance obligation is satisfied. When there are multiple performance obligations within a contract, we allocate the transaction price to each performance obligation based on its relative stand-alone selling price.

[0001783180-25-000008:mdna:122]
We primarily generate revenue from the sale of products to customers and recognize revenue at a point in time when control transfers to the customer. Transfer of control is generally based on the shipping terms of the contract. In addition, we recognize revenue on an over-time basis on installation and service contracts. For over-time performance obligations requiring the installation of equipment, revenue is recognized using costs incurred to date relative to total estimated costs at completion to measure progress. Incurred costs represent work performed, which correspond with and best depict transfer of control to the customer. Contract costs include direct costs such as labor, materials and subcontractors’ costs and, where applicable, indirect costs.

[0001783180-25-000008:mdna:123]
The transaction price allocated to performance obligations reflects our expectations about the consideration we will be entitled to receive from a customer. We include variable consideration in the estimated transaction price when there is a basis to reasonably estimate the amount and when it is probable that a significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. In addition, we customarily offer our customers incentives to purchase products to ensure an adequate supply of our products in distribution channels. The principal incentive programs provide reimbursements to distributors for offering promotional pricing for products. We account for estimated incentive payments as a reduction in sales at the time a sale is recognized.

[0001783180-25-000008:mdna:124]
Income Taxes

[0001783180-25-000008:mdna:125]
We account for income taxes in accordance with ASC 740, Income Taxes ("ASC 740"). Deferred tax assets and liabilities are determined based on temporary differences between financial reporting and tax bases of assets and liabilities, applying enacted tax rates expected to be in effect for the year in which the differences are expected to reverse. We recognize future tax benefits to the extent that realizing these benefits is considered in our judgment to be more likely than not. For those jurisdictions where the expiration date of tax carryforwards or the projected operating results indicate that realization is not likely, a valuation allowance is provided. We review the realizability of our deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required and will adjust our estimate if significant events so dictate. To the extent that the ultimate results differ from our original or adjusted estimates, the effect will be recorded in the provision for income taxes in the period that the matter is finally resolved.

[0001783180-25-000008:mdna:126]
In the ordinary course of business, there is inherent uncertainty in quantifying our income tax positions. We assess our income tax positions and record tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. For those tax positions where it is more likely than not that a tax benefit will be sustained, we have recorded the largest amount of tax benefit with a greater than 50% likelihood of being realized upon ultimate settlement with a taxing authority that has full knowledge of all relevant information. For those income tax positions where it is not more likely than not that a tax benefit will be sustained, no tax benefit has been recognized in the Consolidated Financial Statements.

[0001783180-25-000008:mdna:127]
Contingent Liabilities

[0001783180-25-000008:mdna:128]
We are involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies ("ASC 450"), we record accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, we accrue the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. We are unable to predict the final outcome of these matters based on the information currently available. However, we do not believe that the resolution of any of these matters will have a material adverse effect upon our competitive position, results of operations, cash flows or financial condition.

[0001783180-25-000008:mdna:129]
As described in Note 23 – Commitments and Contingent Liabilities in the accompanying Notes to the Consolidated Financial Statements in this Annual Report, contractual, regulatory and other matters, including asbestos claims, may arise in the ordinary course of business that subject us to claims or litigation. We have recorded reserves in the consolidated financial statements related to these matters, which are developed using input derived from actuarial estimates and historical and anticipated experience depending on the nature of the reserve, and in certain instances in consultation with legal counsel, internal and external consultants and engineers. Subject to the uncertainties inherent in estimating future costs for these types of liabilities, we believe our estimated reserves are reasonable and do not believe the final determination of the liabilities with respect to these matters would have a material adverse effect upon our competitive position, results of operations, cash flows or financial condition. See the "Risk Factors" section in this Annual Report for additional information.

[0001783180-25-000008:mdna:130]
Recent Accounting Pronouncements

[0001783180-25-000008:mdna:131]
See Note 3 – Summary of Significant Accounting Policies in the accompanying Notes to the Consolidated Financial Statements in this Annual Report for a discussion of recent accounting pronouncements and their effect on our financial statements.
