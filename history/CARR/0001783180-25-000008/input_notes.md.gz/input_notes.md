# CARR notes — 0001783180-25-000008


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001783180-25-000008:notes:1]
Part III hereof incorporates by reference portions of the Registrant's definitive proxy statement related to its 2025 annual meeting of shareowners.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001783180-25-000008:notes:2]
Impact of cybersecurity risks on business strategy, results of operations or financial condition.

[0001783180-25-000008:notes:3]
As discussed under the “Risk Factors” heading in this Annual Report, our business has been and may again in the future be impacted by disruptions to our Technology infrastructure or our third-party providers’ Technology infrastructures from (among other causes) cybersecurity-based risks, including attacks (i) on our Technology infrastructure (ii) targeting the security, integrity and/or availability of hardware and software; (iii) exploiting weaknesses or vulnerabilities in products, or capturing information installed, stored or transmitted in our products (including after the purchase of those products and when they are installed into third-party products); and (iv) on facilities or similar infrastructure.

[0001783180-25-000008:notes:4]
Risk Management and strategy

[0001783180-25-000008:notes:5]
We mitigate cybersecurity risks (and other material risks) through our enterprise risk management (“ERM”) program, which is a company-wide effort, managed by senior executives and overseen by our Audit Committee and Board of Directors to identify, assess, manage, report and monitor material risks that may affect our ability to achieve our business objectives.

[0001783180-25-000008:notes:6]
In connection with the ERM process, cybersecurity risks, including those relating to risks posed by our use of third-party service providers, are assigned to cross-functional management committees responsible for identifying and classifying the cybersecurity risks in accordance with our ERM risk rating methodology, and developing and administering risk mitigation and incident response plans. These cross-functional management committees regularly meet to review current and emerging cybersecurity risks and maintain policies and procedures governing the evaluation and classification of such risks.

[0001783180-25-000008:notes:7]
Cybersecurity risks deemed to be critical are reviewed by a Critical Threat Committee, which is comprised of members of our senior leadership team including our Chief Financial Officer, Chief Legal Officer, Chief Digital Officer, Senior Vice President of Operations, Chief Technology Officer, Chief Product Officer and Controller/Chief Accounting Officer. The Critical Threat Committee reviews the risk and mitigation plan with the applicable cross-functional management team and facilitates notification to the Audit Committee of emerging critical cybersecurity risks. The Audit Committee and the Board of Directors receive regular briefings on cybersecurity risks. See “Governance” below for further discussion of governance of our cybersecurity program.

[0001783180-25-000008:notes:8]
In the event of a cybersecurity incident, we maintain incident response plans to investigate, classify, respond to, and manage cybersecurity incidents that may compromise the availability or integrity of our information systems, network resources, or data. In accordance with the incident response plans, cross-functional management teams assess and assign a threat level to each cybersecurity incident. A cybersecurity incident (or incidents, if aggregated together) assigned a critical threat level is escalated to the Critical Threat Committee for review.

[0001783180-25-000008:notes:9]
To ensure that our employees are equipped to identify and mitigate material cybersecurity incidents and to empower them to help us maintain a secure environment for our operations and data assets, we utilize a multifaceted training approach aimed at fostering a culture of security awareness and responsibility among all employees. These tailored programs are designed and updated to address evolving threats and industry best practices. In addition to annual cybersecurity training for employees and contractors and simulated phishing email campaigns, our cybersecurity teams conduct tabletop exercises with our senior management team. Our cybersecurity teams also oversee a security assessment process that is used to screen our third-party service providers for cybersecurity vulnerabilities based on the level of inherent risk they pose to the company or our customers, based on factors including but not limited to the products or services they provide and their ability to access our information systems, network resources, or data.

[0001783180-25-000008:notes:10]
We engage and retain outside consultants and legal advisors and we are members of several cybersecurity industry groups to keep us apprised of emerging cybersecurity risks, defense and mitigation strategies and governance best practices. Many of our processes and procedures are independently audited and assessed on a periodic basis against leading international cybersecurity standards and programs. 
Cybersecurity threats are constantly evolving, are becoming more frequent and more sophisticated and are made by groups of individuals with a wide range of expertise and motives which increases the difficulty of detecting and successfully defending against them. However, to date, cybersecurity threats have not materially affected us, including our business, strategy, results of operations or financial condition.


## cyd:CybersecurityRiskRoleOfManagementTextBlock

[0001783180-25-000008:notes:11]
Our cybersecurity programs, including the cross-functional management committees described above are the responsibility of our Chief Information Security Officer. Day-to-day administration of the cybersecurity programs are led by our Chief Information Security Officer and Chief Product Security Officer who collectively possess significant experience related to cybersecurity issues in both the private and government sectors, and possess certifications including but not limited to Certified Information Systems Security Professional ("CISSP") and Certified Information Security Manager ("CISM").

[0001783180-25-000008:notes:12]
Cybersecurity risk oversight continues to remain a top priority for the Board of Directors. Although the Audit Committee maintains primary responsibility for oversight of cybersecurity risks through the ERM program, responsibility related to oversight of cybersecurity risks is also delegated to other committees in alignment with their focus charter responsibilities. For example, the Technology and Innovation and Governance Committees assist with the cybersecurity programs through their oversight of our technology, digital, and innovation strategies and product integrity program, respectively.
The Critical Threat Committee is also responsible for evaluating the materiality of a cybersecurity incident based on criteria that has been reviewed with the Board of Directors, and for determining whether there are disclosure obligations under applicable securities laws. In the event that the Critical Threat Committee determines that a critical cybersecurity incident (or incidents, if aggregated together) is deemed to be material, the Critical Threat Committee will brief the Board of Directors and oversee the disclosure process. For all critical cybersecurity incidents that are not deemed to be material, the Critical Threat Committee will notify the Chairman of the Board to determine whether the Board of Directors will be notified of the critical incident during the next regularly-scheduled cybersecurity update to the Audit Committee, or sooner as circumstances warrant.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-25-000008:notes:13]
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation (the "Company") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic and Carrier Transicold that offer innovative heating, ventilating and air conditioning ("HVAC"), refrigeration and cold chain transportation solutions to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into two segments: HVAC and Refrigeration.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-25-000008:notes:14]
BASIS OF PRESENTATION 
The accompanying Consolidated Financial Statements reflect the consolidated operations of the Company and have been prepared in accordance with U.S. Generally Accepted Accounting Principles ("GAAP") as defined by the Financial Accounting Standards Board ("FASB") within the FASB Accounting Standards Codification ("ASC"). Inter-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated.

[0001783180-25-000008:notes:15]
The accompanying Consolidated Financial Statements include all majority-owned subsidiaries of the Company. A non-controlling interest in a subsidiary is considered an ownership interest in a majority-owned subsidiary that is not attributable to the parent. The Company includes Non-controlling interest as a component of Total equity in the accompanying Consolidated Balance Sheet and the Non-controlling interest in subsidiaries' earnings from operations are presented as an adjustment to Earnings before income taxes used to arrive at Net earnings (loss) attributable to common shareowners in the accompanying Consolidated Statement of Operations. Partially-owned equity affiliates represent 20 to 50% ownership interests in investments where the Company demonstrates significant influence, but does not have a controlling financial interest. Partially-owned equity affiliates are accounted for under the equity method.

[0001783180-25-000008:notes:16]
Acquisition of Viessmann Climate Solutions

[0001783180-25-000008:notes:17]
On April 25, 2023, the Company announced that it entered into a Share Purchase Agreement (the “Agreement”) to acquire the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (“Viessmann”), a privately-held company. The acquisition was completed on January 2, 2024. As a result, the assets, liabilities and results of operations of the VCS Business are consolidated in the accompanying Consolidated Financial Statements as of the date of acquisition and reported within the Company’s HVAC segment. See Note 19 - Acquisitions for additional information.

[0001783180-25-000008:notes:18]
Portfolio Transformation

[0001783180-25-000008:notes:19]
On December 7, 2023, the Company entered into a stock purchase agreement to sell its Access Solutions business ("Access Solutions") to Honeywell International Inc. As a result, the assets and liabilities of Access Solutions are presented as held for sale on the accompanying Consolidated Balance Sheet as of December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. The sale of Access Solutions was completed on June 2, 2024. See Note 20 - Divestitures for additional information.

[0001783180-25-000008:notes:20]
During the fourth quarter of 2023, the net assets of the Company's Industrial Fire business ("Industrial Fire") met the criteria to be classified as held for sale. As a result, the assets and liabilities of Industrial Fire are presented as held for sale on the accompanying Consolidated Balance Sheet as of December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. On March 5, 2024, the Company entered into a stock purchase agreement to sell Industrial Fire to Sentinel Capital Partners. The sale of Industrial Fire was completed on July 1, 2024. See Note 20 - Divestitures for additional information.

[0001783180-25-000008:notes:21]
On December 12, 2023, the Company entered into a stock purchase agreement to sell its Commercial Refrigeration business ("CCR") to Haier Group Corporation. As a result, the assets and liabilities of CCR are presented as held for sale on the accompanying Consolidated Balance Sheet as of December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. The sale of CCR was completed on October 1, 2024. See Note 20 - Divestitures for additional information.

[0001783180-25-000008:notes:22]
On August 15, 2024, the Company entered into a stock purchase agreement to sell its Commercial and Residential Fire business (“CRF Business”) to an affiliate of Lone Star Funds. As a result, the assets and liabilities of the CRF Business are presented as held for sale on the accompanying Consolidated Balance Sheet as of December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. The sale of CRF was completed on December 2, 2024. See Note 20 - Divestitures for additional information.

[0001783180-25-000008:notes:23]
Discontinued Operations

[0001783180-25-000008:notes:24]
In 2023, the Company announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. The announced plan to exit the Fire & Security segment represents a single disposal plan to separately divest multiple businesses over different reporting periods. Upon the CRF Business qualifying as held for sale during the year ended December 31, 2024, the components of the Fire & Security segment in aggregate met the criteria to be presented as discontinued operations in the accompanying Consolidated Statement of Operations and Consolidated Statement of Cash Flows. In addition, the assets and liabilities of the CRF Business have been reclassified to held for sale at December 31, 2023. The results of the CCR business did not meet the criteria to be presented as discontinued operations. See Note 20 - Divestitures for additional information.

[0001783180-25-000008:notes:25]
Deconsolidation of Kidde-Fenwal, Inc.

[0001783180-25-000008:notes:26]
On May 14, 2023, Kidde-Fenwal, Inc. ("KFI"), an indirect wholly-owned subsidiary of the Company, filed a petition for voluntary reorganization under Chapter 11 of the United States Bankruptcy Code ("Chapter 11") in the United States Bankruptcy Court for the District of Delaware. KFI, an industrial fire detection and suppression business historically reported in the Company's Fire & Security segment, filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware (the “Bankruptcy Court”) seeking relief under chapter 11 of the Bankruptcy Code. As of the petition date, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company's Consolidated Financial Statements.

[0001783180-25-000008:notes:27]
Acquisition of Toshiba Carrier Corporation

[0001783180-25-000008:notes:28]
On February 6, 2022, the Company entered into a binding agreement to acquire a majority ownership interest in Toshiba Carrier Corporation (“TCC”), a variable refrigerant flow ("VRF") and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The acquisition was completed on August 1, 2022. As a result, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Consolidated Financial Statements as of the date of acquisition and reported within the Company’s HVAC segment. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC.

[0001783180-25-000008:notes:29]
Sale of Chubb Fire & Security Business

[0001783180-25-000008:notes:30]
On July 26, 2021, the Company entered into a stock purchase agreement to sell its Chubb Fire and Security business ("Chubb") to APi Group Corporation ("APi"). Chubb, which was reported within the Company's Fire & Security segment, delivered essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. On January 3, 2022, the Company completed the sale of Chubb (the "Chubb Sale") for net proceeds of $2.9 billion and recognized a gain on the sale of $1.1 billion, which is included in Other income (expense), net during the year ended December 31, 2022.

[0001783180-25-000008:notes:31]
Separation from United Technologies
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date for the Distribution. In addition, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of December 31, 2024, only certain portions of the Tax Matters Agreement ("TMA") remain in effect.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001783180-25-000008:notes:32]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
A summary of significant accounting policies used in the preparation of the accompanying Consolidated Financial Statements is as follows:

[0001783180-25-000008:notes:33]
Use of Estimates. The preparation of the Consolidated Financial Statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements as well as the reported amounts of revenues and expenses during the reporting period. Estimates are based on several factors including the facts and circumstances available at the time the estimates are made, historical experience and various other assumptions that are believed to be reasonable under the circumstances. Actual results could differ from those estimates.

[0001783180-25-000008:notes:34]
Currency Translation. Assets and liabilities of non-U.S. subsidiaries, where the functional currency is not the U.S. dollar, have been translated at year-end exchange rates, and income and expense accounts have been translated using average exchange rates throughout the year. Adjustments resulting from the process of translating an entity’s financial statements into the U.S. dollar have been recorded in the equity section of the Consolidated Balance Sheet within Accumulated other comprehensive income (loss). Transactions that are denominated in a currency other than an entity’s functional currency are subject to changes in exchange rates with the resulting gains and losses recorded in Net earnings (loss).

[0001783180-25-000008:notes:35]
Cash and Cash Equivalents. Cash and cash equivalents include cash on hand, demand deposits and short-term cash investments that are highly liquid in nature and have original maturities of three months or less. On occasion, the Company is required to maintain restricted cash deposits with certain banks due to contractual or other legal obligations. Restricted cash of $3 million and $1 million is included in Other assets, current as of December 31, 2024 and 2023, respectively.

[0001783180-25-000008:notes:36]
Accounts Receivable. Accounts receivable consist of billed amounts owed for products shipped to or services performed for customers. Amounts are recorded net of an allowance for expected credit losses which represents the best estimate of probable loss inherent in the Company's accounts receivable portfolio. The allowance is determined using a combination of factors including a reserve based on the aging of the outstanding accounts receivable portfolio and the Company's historical credit loss experience with its end markets, customer base and products. In addition, the Company considers knowledge of specific customers, current market conditions as well as reasonable and supportable forecasts of future events and economic conditions. As of December 31, 2024 and 2023, the allowance for expected credit losses was $97 million and $91 million, respectively. These estimates and assumptions are reviewed periodically with the effects of changes, if any, reflected in the Consolidated Statement of Operations in the period that they are determined.

[0001783180-25-000008:notes:37]
Fixed Assets. Property, plant and equipment are stated at cost less accumulated depreciation. Assets placed in service are recorded at cost and depreciated using the straight-line method over the estimated useful life of the asset. Assets acquired in a business combination are recorded at fair value at the date of acquisition. Major expenditures for replacements and significant improvements that increase asset values and extend useful lives are capitalized. Repairs and maintenance expenditures that do not extend the useful life of an asset are charged to expense as incurred.

[0001783180-25-000008:notes:38]
Per ASC 360, Property, Plant and Equipment ("ASC 360"), the Company assesses the recoverability of the carrying value of its property, plant and equipment whenever events or changes in circumstances indicate that the carrying amount of an asset group may not be recoverable. Recoverability is measured by a comparison of the carrying amount of an asset group to the future net undiscounted cash flows expected to be generated by the asset group. If the undiscounted cash flows are less than the carrying amount of the asset group, an impairment loss is recognized for the amount by which the carrying amount of the asset group exceeds the fair value of the asset group.

[0001783180-25-000008:notes:39]
Equity Method Investments. Investments in which the Company has the ability to exercise significant influence, but does not control, are accounted for under the equity method of accounting and are presented on the Consolidated Balance Sheet. Under this method of accounting, the Company’s share of the net earnings or losses of the investee is presented within Operating profit on the Consolidated Statement of Operations since the activities of the investee are closely aligned with the operations of the Company. The Company evaluates its equity method investments whenever events or changes in circumstance indicate that the carrying amounts of such investments may be impaired. If a decline in the value of an equity method investment is determined to be other than temporary, a loss is recorded in earnings in the current period. Distributions received from equity method investees are presented in the Consolidated Statement of Cash Flows based on the cumulative earnings approach.

[0001783180-25-000008:notes:40]
Goodwill and Intangible Assets. The Company records goodwill as the excess of the purchase price over the fair value of the net assets acquired in a business combination. In accordance with ASC 350, Intangibles - Goodwill and Other ("ASC 350"), goodwill and other indefinite-lived intangibles are tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicate that the fair value of the asset is more likely than not less than the carrying amount of the asset.

[0001783180-25-000008:notes:41]
Impairment of goodwill is assessed at the reporting unit level and begins with a qualitative assessment to determine if it is more likely than not that the fair value of each reporting unit is less than its carrying amount as a basis for determining whether it is necessary to perform the goodwill impairment test under ASC 350. For those reporting units that bypass or fail the qualitative assessment, the test compares the carrying amount of the reporting unit to its estimated fair value. If the estimated fair value of a reporting unit exceeds its carrying amount, goodwill of the reporting unit is not impaired. To the extent that the carrying amount of the reporting unit exceeds its estimated fair value, an impairment loss will be recognized for the amount by which the reporting unit's carrying amount exceeds its fair value, not to exceed the carrying amount of goodwill in that reporting unit.

[0001783180-25-000008:notes:42]
Intangible assets such as patents, service contracts, monitoring lines and customer relationships with finite useful lives are amortized based on the pattern in which the economic benefits of the intangible assets are consumed. If a pattern of economic benefit cannot be reliably determined or if straight-line amortization approximates the pattern of economic benefit, a straight-line amortization may be used.

[0001783180-25-000008:notes:43]
The range of useful lives approximate the following (in years):

[0001783180-25-000008:notes:44]
| Customer relationships | 1 to 30 |
| Patents and trademarks | 5 to 40 |
| Monitoring lines | 7 to 10 |
| Service portfolio and other | 1 to 50 |

[0001783180-25-000008:notes:45]
The Company assesses the recoverability of the carrying amount of its intangible assets with finite useful lives whenever events or changes in circumstances indicate that the carrying amount of the asset group may not be recoverable. Recoverability is measured by a comparison of the carrying amount of an asset group to the future net undiscounted cash flows expected to be generated by the asset group. If the undiscounted cash flows are less than the carrying amount of the asset group, an impairment loss is recognized for the amount by which the carrying value of the asset group exceeds the fair value of the asset group.

[0001783180-25-000008:notes:46]
Leases. The Company accounts for leases in accordance with ASC 842, Leases ("ASC 842"), which requires a lessee to record a right-of-use ("ROU") asset and a lease liability on the Consolidated Balance Sheet for all leases with terms longer than 12 months. ROU assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. The Company generally uses its incremental borrowing rate, which is based on information available at the lease commencement date, to determine the present value of lease payments except when an implicit interest rate is readily determinable. The lease term may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. The Company has elected not to recognize ROU assets and lease obligations for its short-term leases, which are defined as leases with an initial term of 12 months or less.

[0001783180-25-000008:notes:47]
Income Taxes. The Company accounts for income taxes in accordance with ASC 740, Income Taxes ("ASC 740"). Deferred tax assets and liabilities are determined based on temporary differences between financial reporting and tax bases of assets and liabilities, applying enacted tax rates expected to be in effect for the year in which the differences are expected to reverse. The Company recognizes future tax benefits to the extent that realizing these benefits is considered in its judgment to be more likely than not. For those jurisdictions where the expiration date of tax carryforwards or the projected operating results indicate that realization is not likely, a valuation allowance is provided. The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required and will adjust its estimate if significant events so dictate. To the extent that the ultimate results differ from the Company's original or adjusted estimates, the effect will be recorded in the provision for income taxes in the period that the matter is finally resolved.

[0001783180-25-000008:notes:48]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. For those tax positions where it is more likely than not that a tax benefit will be sustained, the Company has recorded the largest amount of tax benefit with a greater than 50% likelihood of being realized upon ultimate settlement with a taxing authority that has full knowledge of all relevant information. For those income tax positions where it is not more likely than not that a tax benefit will be sustained, no tax benefit has been recognized in the Consolidated Financial Statements.

[0001783180-25-000008:notes:49]
Pension and Post-retirement Obligations. The Company provides a range of benefit plans to eligible current and former employees. The Company accounts for its benefit plans in accordance with ASC 715, Compensation - Retirement Benefits ("ASC 715") which requires balance sheet recognition of the overfunded or underfunded status of pension and post-retirement benefit plans. Determining the amounts associated with these benefits are performed by actuaries and dependent on various actuarial assumptions including discount rates, expected return on plan assets, compensation increases, mortality and health care cost trends. Actual results may differ from the actuarial assumptions and are generally recorded in Accumulated other comprehensive income (loss) and amortized into Net earnings (loss) over future periods. The Company reviews its actuarial assumptions at each measurement date and makes modifications to the assumptions based on current rates and trends, if appropriate. See Note 10 – Employee Benefit Plans for additional information.

[0001783180-25-000008:notes:50]
Business Combinations. In accordance with ASC 805, Business Combinations ("ASC 805"), acquisitions that meet the definition of a business are recorded using the acquisition method of accounting. The Company recognizes and measures identifiable assets acquired, liabilities assumed and any non-controlling interest as of the acquisition date at fair value. The valuation of intangible assets is determined by an income approach methodology, using assumptions such as projected future revenues, customer attrition rates, royalty rates, tax rates and discount rates. The excess, if any, of total consideration transferred in a business combination over the fair value of identifiable assets acquired, liabilities assumed and any non-controlling interest is recognized as goodwill. Costs incurred as a result of a business combination other than costs related to the issuance of debt or equity securities are recorded in the period the costs are incurred.

[0001783180-25-000008:notes:51]
Asset Retirement Obligations. The Company records the fair value of legal obligations associated with the retirement of tangible long-lived assets in the period in which a liability is determined to exist, if a reasonable estimate of fair value can be made. Upon initial recognition of a liability, the Company capitalizes the cost of the asset retirement obligation by increasing the carrying amount of the related long-lived asset. Over time, the liability is increased for changes in its present value and the capitalized cost is depreciated over the useful life of the related asset.

[0001783180-25-000008:notes:52]
Research and Development. The Company conducts research and development activities with a focus on new product development and technology innovation. These costs are charged to expense as incurred. For the years ended December 31, 2024, 2023 and 2022, these costs amounted to $686 million, $493 million and $416 million, respectively.

[0001783180-25-000008:notes:53]
Recent Pronouncements

[0001783180-25-000008:notes:54]
The FASB ASC is the sole source of authoritative GAAP other than United States Securities and Exchange Commission ("SEC') issued rules and regulations that apply only to SEC registrants. The FASB issues Accounting Standards Updates ("ASU") to communicate changes to the codification. The Company considers the applicability and impact of all ASUs. ASUs not referenced below were assessed and determined to be either not applicable or are not expected to have a material impact on the Consolidated Financial Statements.

[0001783180-25-000008:notes:55]
Recently Issued and Adopted Accounting Pronouncements

[0001783180-25-000008:notes:56]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures (“ASU 2023-07”), which requires public entities to disclose information about their reportable segments’ significant expenses on an interim and annual basis. In addition, the amendments clarify circumstances in which an entity can disclose multiple segment measures of profit or loss, provides new segment disclosure requirements for entities with a single reportable segment and contains other disclosure requirements. The Company adopted ASU 2023-07 on January 1, 2024, with no material impact on its financial statements.

[0001783180-25-000008:notes:57]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"), which requires public entities to disclose disaggregated information about their effective tax rate reconciliation as well as information on income taxes paid. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.

[0001783180-25-000008:notes:58]
On March 6, 2024, the SEC adopted new rules designed to enhance public company disclosures related to the risks and impacts of climate-related matters. The rules amend the provisions of both Regulation S-K and Regulation S-X to require disclosure of climate-related risks, transition plans, targets and goals, risk management and governance as well as require disclosure of the financial effects of severe weather events and other natural conditions as well as the use of carbon offsets or renewable energy credits. Disclosure requirements will begin phasing in for fiscal years beginning on or after January 1, 2025, subject to legal challenges and the SEC's voluntary stay of the disclosure requirements. The Company will continue to assess the impact of these new rules on its financial statements while the stay is in place.

[0001783180-25-000008:notes:59]
In November 2024, the FASB issued ASU 2024-03, Disaggregation of Income Statement Expenses (DISE) ("ASU 2024-03"), which requires public entities to disclose disaggregated information about expenses by nature on an interim and annual basis. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001783180-25-000008:notes:60]
Identifiable intangible assets consisted of the following:

[0001783180-25-000008:notes:61]
|  |  |  | 2024 |  | 2023 |
| (In millions) |  |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Customer relationships |  |  | $ | 5,607 |  |  | $ | (939) |  |  | $ | 4,668 |  |  | $ | 1,056 |  |  | $ | (445) |  |  | $ | 611 |  |
| Patents and trademarks |  |  | 885 |  |  | (147) |  |  | 738 |  |  | 255 |  |  | (96) |  |  | 159 |  |
| Service portfolios and other |  |  | 1,530 |  |  | (504) |  |  | 1,026 |  |  | 431 |  |  | (256) |  |  | 175 |  |
| Total intangible assets (1) |  |  | $ | 8,022 |  |  | $ | (1,590) |  |  | $ | 6,432 |  |  | $ | 1,742 |  |  | $ | (797) |  |  | $ | 945 |  |

[0001783180-25-000008:notes:62]
(1) Indefinite-lived intangible assets were sold as part of the CRF Business divestiture.


## us-gaap:InventoryDisclosureTextBlock

[0001783180-25-000008:notes:63]
INVENTORIES, NET 
Inventories are stated at the lower of cost or estimated net realizable value. Cost is primarily determined based on the first-in, first-out inventory method ("FIFO") or average cost methods, which approximates current replacement cost. However, certain Carrier entities use the last-in, first-out inventory method ("LIFO").

[0001783180-25-000008:notes:64]
Inventories, net consisted of the following:

[0001783180-25-000008:notes:65]
| (In millions) | 2024 |  | 2023 |
| Raw materials | $ | 625 |  |  | $ | 534 |  |
| Work-in-process | 213 |  |  | 245 |  |
| Finished goods | 1,461 |  |  | 1,044 |  |
| Inventories, net | $ | 2,299 |  |  | $ | 1,823 |  |

[0001783180-25-000008:notes:66]
The Company performs periodic assessments utilizing customer demand, production requirements and historical usage rates to determine the existence of excess and obsolete inventory and records necessary provisions to reduce such inventories to the lower of cost or estimated net realizable value. Raw materials, work-in-process and finished goods are net of valuation reserves of $215 million and $173 million as of December 31, 2024 and 2023, respectively.

[0001783180-25-000008:notes:67]
Certain entities use LIFO to determine the cost of inventory. If inventories that were valued using the LIFO method had been valued under the FIFO method, the net book value of the inventories would have been higher by $238 million and $226 million as of December 31, 2024 and 2023, respectively. As of December 31, 2024 and 2023, approximately 39% and 42%, respectively, of all inventory utilized the LIFO method.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001783180-25-000008:notes:68]
FIXED ASSETS, NET 
Fixed assets, net consisted of the following:

[0001783180-25-000008:notes:69]
| (In millions) | Estimated Useful Lives (Years) |  | 2024 |  | 2023 |
| Land |  |  | $ | 169 |  |  | $ | 109 |  |
| Buildings and improvements | 20 to 40 |  | 1,325 |  |  | 1,083 |  |
| Machinery, tools and equipment | 3 to 25 |  | 2,947 |  |  | 2,520 |  |
| Rental assets | 3 to 12 |  | 355 |  |  | 346 |  |
| Other, including assets under construction |  |  | 715 |  |  | 415 |  |
| Fixed assets, gross |  |  | 5,511 |  |  | 4,473 |  |
| Accumulated depreciation |  |  | (2,512) |  |  | (2,313) |  |
| Fixed assets, net |  |  | $ | 2,999 |  |  | $ | 2,160 |  |

[0001783180-25-000008:notes:70]
Depreciation expense was $385 million, $270 million and $224 million for the years ended December 31, 2024, 2023 and 2022, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-25-000008:notes:71]
GOODWILL AND INTANGIBLE ASSETS 
The Company records goodwill as the excess of the purchase price over the fair value of the net assets acquired in a business combination. Goodwill is tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicates that the fair value of the reporting unit may be less than its carrying value.

[0001783180-25-000008:notes:72]
The changes in the carrying amount of goodwill were as follows:

[0001783180-25-000008:notes:73]
| (In millions) | HVAC |  | Refrigeration |  | Corporate and other |  | Total |
| Balance at December 31, 2022 | $ | 6,392 |  |  | $ | 1,158 |  |  | $ | 76 |  |  | $ | 7,626 |  |
| Goodwill resulting from business combinations (1) | 1 |  |  | (4) |  |  | — |  |  | (3) |  |
| Reclassified to held for sale (2) | — |  |  | (72) |  |  | — |  |  | (72) |  |
| Foreign currency translation | 14 |  |  | (45) |  |  | — |  |  | (31) |  |
| Balance at December 31, 2023 | $ | 6,407 |  |  | $ | 1,037 |  |  | $ | 76 |  |  | $ | 7,520 |  |
| Goodwill resulting from business combinations (1) | 7,622 |  |  | 33 |  |  | — |  |  | 7,655 |  |
| Foreign currency translation | (631) |  |  | 57 |  |  | — |  |  | (574) |  |
| Balance as of December 31, 2024 | $ | 13,398 |  |  | $ | 1,127 |  |  | $ | 76 |  |  | $ | 14,601 |  |

[0001783180-25-000008:notes:74]
(1) See Note 19 - Acquisitions for additional information.

[0001783180-25-000008:notes:75]
(2) See Note 20 - Divestitures for additional information.

[0001783180-25-000008:notes:76]
Indefinite-lived intangible assets are tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicates that the fair value of the asset may be less than the carrying amount of the asset. Intangible assets with finite useful lives are amortized over their estimated useful lives.

[0001783180-25-000008:notes:77]
Amortization of intangible assets was $843 million, $221 million and $104 million for the years ended December 31, 2024, 2023 and 2022, respectively.

[0001783180-25-000008:notes:78]
The estimated future amortization of intangible assets is as follows:

[0001783180-25-000008:notes:79]
| (In millions) | 2025 |  | 2026 |  | 2027 |  | 2028 |  | 2029 |  | Thereafter |
| Future amortization | $ | 819 |  |  | $ | 779 |  |  | $ | 731 |  |  | $ | 660 |  |  | $ | 581 |  |  | $ | 2,862 |  |

[0001783180-25-000008:notes:80]
Annual Impairment Assessment

[0001783180-25-000008:notes:81]
The Company tested its goodwill and indefinite-lived intangible assets for impairment on July 1 as part of its annual assessment. For each test except one, the Company qualitatively assessed all relevant events or circumstances that could impact the estimate of fair value and determined it was more likely than not that the fair value of each reporting unit and indefinite-lived intangible assets exceeded their carrying amount. For the remaining test, the Company performed a quantitative goodwill impairment test to determine if any impairment existed. The test did not indicate any goodwill impairment.
In connection with the presentation of the CRF Business as held for sale at December 31, 2024, the Company reassigned goodwill to the remaining business activities previously reported within the Fire & Security segment. For the test, the Company qualitatively assessed all relevant events or circumstances that could impact the estimate of fair value and determined it was more likely than not that the fair value of the remaining business activities exceeded their carrying amount. Due to these business activities no longer meeting the criteria of a reportable segment, they have been included in Corporate and other.


## us-gaap:DebtDisclosureTextBlock

[0001783180-25-000008:notes:82]
BORROWINGS AND LINES OF CREDIT 
Long-term debt consisted of the following:

[0001783180-25-000008:notes:83]
| (In millions) |  | 2024 |  | 2023 |
| 2.242% Notes due 2025 (1) |  | 1,200 |  |  | 1,200 |  |
| 4.375% Notes due 2025 |  | — |  |  | 830 |  |
| 5.800% Notes due 2025 |  | — |  |  | 1,000 |  |
| 2.493% Notes due 2027 |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  | 783 |  |  | 830 |  |
| 2.722% Notes due 2030 |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  | 887 |  |  | 941 |  |
| 5.900% Notes due 2034 |  | 875 |  |  | 1,000 |  |
| 3.625% Notes due 2037 |  | 783 |  |  | — |  |
| 3.377% Notes due 2040 |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  | 1,400 |  |  | 2,000 |  |
| 6.200% Notes due 2054 |  | 650 |  |  | 1,000 |  |
| Total long-term notes |  | 11,728 |  |  | 13,951 |  |
| Japanese Term Loan Facility |  | 342 |  |  | 379 |  |
| Other debt (including project financing obligations and finance leases) |  | 296 |  |  | 74 |  |
| Discounts and debt issuance costs |  | (88) |  |  | (111) |  |
| Total debt |  | 12,278 |  |  | 14,293 |  |
| Less: current portion of long-term debt |  | 1,252 |  |  | 51 |  |
| Long-term debt, net of current portion |  | $ | 11,026 |  |  | $ | 14,242 |  |

[0001783180-25-000008:notes:84]
(1) 2.242% Notes due February 15, 2025; reclassified to Current portion of long-term debt.

[0001783180-25-000008:notes:85]
Acquisition Funding

[0001783180-25-000008:notes:86]
On January 2, 2024, the Company completed the acquisition of the VCS Business for total consideration of $14.2 billion. Under the terms of the Agreement, 20% of the purchase price was paid in Carrier common stock, issued directly to Viessmann and subject to certain lock up provisions and 80% was paid in cash, subject to working capital and other adjustments. In order to fund the Euro-denominated cash portion of the purchase price, the Company used cash on hand, debt financing and various term loan facilities.

[0001783180-25-000008:notes:87]
Debt Issuance

[0001783180-25-000008:notes:88]
In November 2023, the Company issued $3.0 billion principal amount of USD-denominated notes in three tranches. The tranches consisted of $1.0 billion aggregate principal amount of 5.80% notes due 2025, $1.0 billion aggregate principal amount of 5.90% notes due 2034 and $1.0 billion aggregate principal amount of 6.20% notes due 2054 (collectively, the “USD Notes”). In addition, the Company issued €2.35 billion principal amount of Euro-denominated notes in three tranches. The tranches consisted of €750 million aggregate principal amount of 4.375% notes due 2025, €750 million aggregate principal amount of 4.125% notes due 2028 and €850 million aggregate principal amount of 4.50% notes due 2032 (collectively, the “Euro Notes”). The notes are subject to certain customary covenants and the Company has the option to redeem the notes in whole or in part at any time prior to their stated maturity date at the redemption price set forth in the indenture agreements. The Company capitalized $51 million of deferred financing costs which are being amortized over the term of their related notes. In June 2024, the Company redeemed the $1.0 billion aggregate principal amount of 5.80% notes due in 2025 and incurred a $8 million make-whole premium upon prepayment and wrote off $4 million of related unamortized debt financing costs.

[0001783180-25-000008:notes:89]
In November 2024, the Company issued €750 million aggregate principal amount of 3.625% Euro-denominated notes due 2037. The notes are subject to certain customary covenants and the Company has the option to redeem the notes in whole or in part at any time, prior to their stated maturity date at the redemption price set forth in the indenture agreement. The Company capitalized $11 million of deferred financing costs which are being amortized over the term of the notes. The Company used the net proceeds, together with cash on hand, to redeem its €750 million aggregate principal amount of outstanding 4.375% Euro-denominated notes due 2025 and to pay fees and expenses in connection with the new offering. The Company incurred a $6 million make-whole premium upon prepayment and wrote off $2 million of related unamortized debt financing costs.

[0001783180-25-000008:notes:90]
Bridge Loan

[0001783180-25-000008:notes:91]
On April 25, 2023, the Company entered into commitment letters with JPMorgan Chase Bank, N.A., BofA Securities, Inc. and Bank of America, N.A. to provide a €8.2 billion aggregate principal, senior unsecured bridge term loan facility (the “Bridge Loan”). Euro-denominated borrowings bore interest at the EURIBOR Rate plus a ratings-based margin, USD-denominated borrowings bore interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. The Company capitalized $48 million of deferred financing costs associated with the Bridge Loan which were amortized over the commitment period. Upon entering into a senior unsecured delayed draw term loan facility and issuing the USD Notes and the Euro Notes, the Company reduced the Bridge Loan by €7.7 billion and accelerated the amortization on $25 million of deferred financing costs in Interest expense during 2023. On January 2, 2024, the Company entered into a 60-day senior unsecured term loan agreement consisting of a Euro-denominated tranche in an aggregate amount of €113 million and a USD-denominated tranche in an aggregate amount of $349 million (the “60-day Loan”). Upon entering into the 60-day Loan, the Company reduced the final portion of the Bridge Loan by €500 million and subsequently terminated the agreement. Borrowings under the 60-day Loan were repaid in March 2024.

[0001783180-25-000008:notes:92]
Delayed Draw Facility

[0001783180-25-000008:notes:93]
On May 19, 2023, the Company entered into a senior unsecured delayed draw term loan credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders that permitted aggregate borrowings of up to €2.3 billion (the "Delayed Draw Facility"). The facility consisted of an 18-month, Euro-denominated tranche in an aggregate amount of €1.15 billion and a 3-year, Euro-denominated tranche in an aggregate amount of €1.15 billion. Euro-denominated borrowings bear interest at the EURIBOR Rate plus a ratings-based margin, USD-denominated borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. The Company capitalized $4 million of deferred financing costs which will be amortized over the respective term of the tranches. On January 2, 2024, the Company borrowed the full amount available under the Delayed Draw Facility in U.S. Dollars. Borrowings under the Delayed Draw Facility were repaid in June 2024 and the facility was subsequently terminated.

[0001783180-25-000008:notes:94]
364-Day Revolver

[0001783180-25-000008:notes:95]
On May 17, 2024, the Company entered into a 364-day, $500 million, senior unsecured revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders (the “364-day Revolver”). Borrowings are available in U.S. Dollars and Euros. USD-denominated borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin, Euro-denominated borrowings bear interest at the Adjusted EURIBOR Rate plus a ratings-based margin. Upon entering into the 364-day Revolver, the Company terminated its existing $500 million senior unsecured revolving credit agreement that was set to mature in May 2024. In December 2024, the Company terminated the 364-day Revolver as part of a transaction to refinance and replace prior credit agreements.

[0001783180-25-000008:notes:96]
Japanese Term Loan Facility

[0001783180-25-000008:notes:97]
On July 15, 2022, the Company entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings under the Japanese Term Loan Facility bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. In addition, the Japanese Term Loan Facility is subject to customary covenants including a covenant to maintain a maximum consolidated leverage ratio. The Company capitalized $2 million of deferred financing costs which are being amortized over the term of the facility. On July 25, 2022, the Company borrowed JPY 54 billion under the Japanese Term Loan Facility and used the proceeds to fund a portion of the TCC acquisition and to pay related fees and expenses.

[0001783180-25-000008:notes:98]
Revolving Credit Facility

[0001783180-25-000008:notes:99]
On December 20, 2024, the Company entered into a revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.5 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in December 2029 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings can bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. Upon entering into the agreement, the Company terminated its existing $2.0 billion revolving credit facility that was set to mature in May 2028 as part of a transaction to refinance and replace prior credit agreements. In addition, the Company capitalized $11 million of deferred financing costs which are being amortized over the term of the facility. As of December 31, 2024, there were no borrowings outstanding under the Revolving Credit Facility.

[0001783180-25-000008:notes:100]
Commercial Paper Program

[0001783180-25-000008:notes:101]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of December 31, 2024, there were no borrowings outstanding under the commercial paper program.

[0001783180-25-000008:notes:102]
Project Financing Arrangements

[0001783180-25-000008:notes:103]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $53 million and $39 million of debt during the year ended December 31, 2024 and 2023, respectively. Long-term debt repayments associated with these financing arrangements for the years ended December 31, 2024 and 2023, were $14 million and $111 million, respectively.

[0001783180-25-000008:notes:104]
Debt Covenants

[0001783180-25-000008:notes:105]
The Revolving Credit Facility, the indenture for the long-term notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of December 31, 2024, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

[0001783180-25-000008:notes:106]
Tender Offers

[0001783180-25-000008:notes:107]
In July 2024, the Company commenced tender offers to purchase up to $800 million ("Aggregate Tender Cap") aggregate purchase price of certain tranches of the Company's notes. The tender offers included payment of applicable accrued and unpaid interest up to the settlement date, along with a fixed spread for early repayment. Based on several factors, the Company elected to increase the Aggregate Tender Cap and settle the tender offers early. The aggregate principal amount tendered and accepted was approximately $1.1 billion, which included $125 million of notes due 2034, $350 million of notes due 2054 and approximately $600 million of notes due 2050. Upon settlement, the Company recognized a net gain of $97 million and wrote off $11 million of unamortized deferred financing costs within Interest (expense) income, net on the accompanying Consolidated Statement of Operations.

[0001783180-25-000008:notes:108]
Schedule of Long-term Debt Maturities

[0001783180-25-000008:notes:109]
Scheduled maturities of long-term debt, excluding amortization of discount, are as follows:

[0001783180-25-000008:notes:110]
| (In millions) |  |  |
| 2025 |  | $ | 1,252 |  |
| 2026 |  | $ | 70 |  |
| 2027 |  | $ | 1,284 |  |
| 2028 |  | $ | 803 |  |
| 2029 |  | $ | 19 |  |
| Thereafter |  | $ | 8,938 |  |

[0001783180-25-000008:notes:111]
As of December 31, 2024, the average maturity of the Company's long-term notes is approximately 10 years and the weighted-average interest rate on its total borrowings is approximately 3.5%. Interest expense associated with long-term debt for the years ended December 31, 2024, 2023 and 2022 was $580 million, $306 million and $238 million, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-25-000008:notes:112]
FAIR VALUE MEASUREMENTS
ASC 820, Fair Value Measurement ("ASC 820"), defines fair value as the price that would be received if an asset is sold or the price paid to transfer a liability in an orderly transaction between market participants at the measurement date. ASC 820 also establishes a three-level fair value hierarchy that prioritizes information used in developing assumptions when pricing an asset or liability as follows:

[0001783180-25-000008:notes:113]
•Level 1: Observable inputs such as quoted prices in active markets;

[0001783180-25-000008:notes:114]
•Level 2: Inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and

[0001783180-25-000008:notes:115]
•Level 3: Unobservable inputs where there is little or no market data, which requires the reporting entity to develop its own assumptions.

[0001783180-25-000008:notes:116]
ASC 820 requires the use of observable market data, when available, in making fair value measurements. When inputs used to measure fair value fall within different levels of the hierarchy, the level within which the fair value measurement is categorized is based on the lowest level input that is significant to the fair value measurement.

[0001783180-25-000008:notes:117]
In the normal course of business, the Company is exposed to certain risks arising from business operations and economic factors, including foreign currency and commodity price risk. These exposures are managed through operational strategies and the use of undesignated hedging contracts. The Company's derivative assets and liabilities are measured at fair value on a recurring basis using internal models based on observable market inputs, such as forward, interest, contract and discount rates with changes in fair value reported in Other income (expense), net in the accompanying Consolidated Statement of Operations.

[0001783180-25-000008:notes:118]
In connection with the TCC acquisition, the Company funded a portion of the Yen-denominated purchase price with cash on hand by entering into cross currency swaps with various financial institutions. The cross currency swaps are measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates as well as credit default swap spreads. The Company designated the cross currency swaps as a partial hedge of its investment in certain subsidiaries whose functional currency is the Japanese Yen in order to manage foreign currency translation risk. As a result, changes in the fair value of the swaps are recorded in Equity in the accompanying Consolidated Balance Sheet.

[0001783180-25-000008:notes:119]
The remaining portion of the Yen-denominated purchase price was funded by the Japanese Term Loan Facility. The carrying value of the facility is translated on a recurring basis using the exchange rate at the end of the applicable period and approximates its fair value. The Company designated the Japanese Term Loan Facility as a partial hedge of its investment in certain subsidiaries whose functional currency is the Japanese Yen in order to manage foreign currency translation risk. As a result, changes in the carrying value of the Japanese Term Loan Facility associated with foreign exchange rate movements are recorded in Equity in the Consolidated Balance Sheet.

[0001783180-25-000008:notes:120]
In connection with the acquisition of the VCS Business, the Company entered into window forward contracts with Bank of America N.A. and JPMorgan Chase Bank N.A. to mitigate the foreign currency risk of the expected cash outflows associated with the Euro-denominated purchase price. The instruments have an aggregate notional amount of €7 billion and are measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates with changes in fair value reported in Other income (expense), net in the accompanying Consolidated Statement of Operations. During the year ended December 31, 2023, the Company recognized a $96 million loss on the mark-to-market valuation of its window forward contracts. The Company settled the window forward contracts on January 2, 2024, upon the acquisition of the VCS Business and recognized an additional $86 million loss.

[0001783180-25-000008:notes:121]
During 2023, the Company entered into several interest rate swap contracts to mitigate interest rate exposure on the forecasted issuance of long-term debt. The contracts had an aggregate notional amount of $1.5 billion and were designated as cash flow hedges with changes in fair value reported in Equity in the accompanying Consolidated Balance Sheet. Fair value was measured on a recurring basis using observable market inputs, such as forward, discount and interest rates. In November 2023, the contracts were settled upon the issuance of the underlying debt. As a result, the Company deferred a net unrecognized gain of $58 million in Equity which will be subsequently recognized in Interest expense over the term of the related notes which range from 2034 to 2044. The amount expected to be amortized during 2025 is a net gain of $4 million.

[0001783180-25-000008:notes:122]
During 2024, the Company entered into cross currency swaps with Barclays Bank PLC as syndication swap arranger in order to manage foreign currency translation risk on Euro-denominated assets. The swaps have an aggregate notional amount of $2.0 billion and are measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates. The Company designated the cross currency swaps as a partial hedge of its investment in certain subsidiaries whose functional currency is the Euro. As a result, changes in the fair value of the swaps are recorded in Equity in the accompanying Consolidated Balance Sheet.

[0001783180-25-000008:notes:123]
The following tables provide the valuation hierarchy classification of assets and liabilities that are recorded at fair value and measured on a recurring basis in the accompanying Consolidated Balance Sheet:

[0001783180-25-000008:notes:124]
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| December 31, 2024 |  |  |  |  |  |  |  |  |
| Fair value measurement: |  |  |  |  |  |  |  |  |
| Derivative assets (1)(3) |  | $ | 82 |  |  | $ | — |  |  | $ | 82 |  |  | $ | — |  |
| Derivative liabilities (2)(3) |  | $ | (41) |  |  | $ | — |  |  | $ | (41) |  |  | $ | — |  |
| December 31, 2023 |  |  |  |  |  |  |  |  |
| Fair value measurement: |  |  |  |  |  |  |  |  |
| Derivative assets (1) (3) |  | $ | 32 |  |  | $ | — |  |  | $ | 32 |  |  | $ | — |  |
| Derivative liabilities (2)(3) |  | $ | (126) |  |  | $ | — |  |  | $ | (126) |  |  | $ | — |  |

[0001783180-25-000008:notes:125]
(1) Included in Other assets, current and Other assets on the accompanying Consolidated Balance Sheet.

[0001783180-25-000008:notes:126]
(2) Included in Accrued liabilities and Other long-tern liabilities on the accompanying Consolidated Balance Sheet.

[0001783180-25-000008:notes:127]
(3) Includes cross currency swaps and window forward contracts (which were settled on January 2, 2024).

[0001783180-25-000008:notes:128]
The following table provides the carrying amounts and fair values of the Company's long-term notes that are not recorded at fair value in the accompanying Consolidated Balance Sheet:

[0001783180-25-000008:notes:129]
|  |  | 2024 |  | 2023 |
| (In millions) |  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |
| Total long-term notes (1) |  | $ | 11,728 |  |  | $ | 10,798 |  |  | $ | 13,951 |  |  | $ | 13,194 |  |

[0001783180-25-000008:notes:130]
(1) Excludes debt discount and issuance costs.

[0001783180-25-000008:notes:131]
The fair value of the Company's long-term debt is measured based on observable market inputs which are considered Level 1 within the fair value hierarchy. The carrying value of cash and cash equivalents, accounts receivable, accounts payable and short-term borrowings approximate fair value due to the short-term nature of these accounts and would be classified as Level 1 in the fair value hierarchy. The Company's financing leases and project financing obligations, included in Long-term debt and Current portion of long-term debt on the accompanying Consolidated Balance Sheet, approximate fair value and are classified as Level 3 in the fair value hierarchy.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001783180-25-000008:notes:132]
LEASES 
The Company enters into operating and finance leases for the use of real estate, vehicles, information technology equipment and certain other equipment. At contract inception, the Company determines a lease exists if the arrangement conveys the right to control an identified asset for a period of time in exchange for consideration. Control is considered to exist when the lessee has the right to obtain substantially all of the economic benefits from the use of an identified asset as well as the right to direct the use of that asset. If a contract is considered to be a lease, the Company recognizes a lease liability based on the present value of the future lease payments with an offsetting entry to recognize a right-of-use asset.

[0001783180-25-000008:notes:133]
Operating lease right-of-use assets and liabilities are reflected on the Consolidated Balance Sheet as follows:

[0001783180-25-000008:notes:134]
| (In millions) |  | 2024 |  | 2023 |
| Operating lease right-of-use assets |  | $ | 554 |  |  | $ | 421 |  |
| Accrued liabilities |  | $ | (135) |  |  | $ | (93) |  |
| Operating lease liabilities |  | (432) |  |  | (333) |  |
| Total operating lease liabilities |  | $ | (567) |  |  | $ | (426) |  |
| Weighted-Average Remaining Lease Term (in years) |  | 6.8 |  | 7.0 |
| Weighted-Average Discount Rate |  | 4.5 | % |  | 3.9 | % |

[0001783180-25-000008:notes:135]
Where applicable, the Company accounts for each separate lease component of a contract and its associated non-lease component as a single lease component.

[0001783180-25-000008:notes:136]
Supplemental cash flow and lease expense information related to operating leases were as follows:

[0001783180-25-000008:notes:137]
| (In millions) |  | 2024 |  | 2023 |  | 2022 |
| Operating cash flows for measurement of operating lease liabilities |  | $ | 173 |  |  | $ | 135 |  |  | $ | 119 |  |
| Operating lease ROU assets obtained in exchange for operating lease obligations |  | $ | 112 |  |  | $ | 50 |  |  | $ | 91 |  |
| Operating lease expense |  | $ | 175 |  |  | $ | 127 |  |  | $ | 121 |  |

[0001783180-25-000008:notes:138]
Operating lease expense is recognized on a straight-line basis over the lease term. In addition, the Company has certain leases that contain variable lease payments which are based on an index, a rate referenced in the lease or on the actual usage of the leased asset. These payments are not included in the right-of-use asset or lease liability and are expensed as incurred as variable lease expense.

[0001783180-25-000008:notes:139]
Undiscounted maturities of operating lease liabilities as of December 31, 2024, are as follows:

[0001783180-25-000008:notes:140]
| (In millions) |  |  |
| 2025 |  | $ | 154 |  |
| 2026 |  | 128 |  |
| 2027 |  | 93 |  |
| 2028 |  | 68 |  |
| 2029 |  | 48 |  |
| Thereafter |  | 169 |  |
| Total undiscounted lease payments |  | 660 |  |
| Less: imputed interest |  | (93) |  |
| Total discounted lease payments |  | $ | 567 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-25-000008:notes:141]
EMPLOYEE BENEFIT PLANS 
The Company sponsors U.S. and international defined benefit pension and defined contribution plans. In addition, the Company contributes to various U.S. and international multi-employer defined benefit pension plans.

[0001783180-25-000008:notes:142]
Pension Plans

[0001783180-25-000008:notes:143]
Qualified U.S. pension plan benefits covering collectively bargained employees comprise approximately 35% of the projected benefit obligation. This noncontributory defined benefit plan provides benefits on a flat dollar formula based on an employee's location and is closed to new entrants. The non-U.S. plans comprise approximately 65% of the projected benefit obligation; certain of these plans provide participants with one-time payments upon separation of employment rather than a retirement annuity. The plans' benefits are based on plan specific parameters. Non-qualified U.S. pension plans provide supplementary retirement benefits to certain employees and are not a material component of the projected benefit obligation.

[0001783180-25-000008:notes:144]
The following table details information regarding the Company's pension plans:

[0001783180-25-000008:notes:145]
| (In millions) | 2024 |  | 2023 |
| Change in Benefit Obligation |  |  |  |
| Benefit obligation at beginning of year | $ | 575 |  |  | $ | 760 |  |
| Service cost | 14 |  |  | 15 |  |
| Interest cost | 26 |  |  | 31 |  |
| Actuarial (gain) loss | (9) |  |  | 27 |  |
| Benefits paid | (24) |  |  | (25) |  |
| Curtailment, settlements and special termination benefits | (13) |  |  | (24) |  |
| Other, including expenses paid | (25) |  |  | 3 |  |
| Reclassified to held for sale (1) | — |  |  | (212) |  |
| Acquisitions (2) | 113 |  |  | — |  |
| Benefit obligation at end of year | $ | 657 |  |  | $ | 575 |  |
| Change in Plan Assets |  |  |  |
| Fair value at beginning of year | $ | 468 |  |  | $ | 451 |  |
| Actual return on plan assets | 1 |  |  | 39 |  |
| Company contributions | 34 |  |  | 33 |  |
| Benefits paid | (24) |  |  | (25) |  |
| Settlements | (13) |  |  | (24) |  |
| Other, including expenses paid | (15) |  |  | 2 |  |
| Reclassified to held for sale (1) | — |  |  | (8) |  |
| Acquisitions (2) | 56 |  |  | — |  |
| Fair value of assets end of year | $ | 507 |  |  | $ | 468 |  |
| Funded status of plans | $ | (150) |  |  | $ | (107) |  |
| Amounts included in the balance sheet: |  |  |  |
| Other non-current assets | $ | 43 |  |  | $ | 32 |  |
| Accrued compensation and benefits | (13) |  |  | (12) |  |
| Post-employment and other benefit liabilities | (180) |  |  | (127) |  |
| Net amount recognized | $ | (150) |  |  | $ | (107) |  |

[0001783180-25-000008:notes:146]
(1) See Note 20 - Divestitures for additional information.

[0001783180-25-000008:notes:147]
(2) See Note 19 - Acquisitions for additional information.

[0001783180-25-000008:notes:148]
The decrease in funded status was primarily driven by the acquisition of the VCS Business on January 2, 2024. However, the decrease was partially offset by the increase in discount rates over the measurement period which resulted in lower benefit obligations.

[0001783180-25-000008:notes:149]
The pretax amounts recognized in Accumulated other comprehensive (income) loss are:

[0001783180-25-000008:notes:150]
| (In millions) |  | Prior Service Cost (Benefit) |  | Net Actuarial (Gain) Loss |  | Total |
| As of December 31, 2023 |  | $ | 6 |  |  | $ | 120 |  |  | $ | 126 |  |
| Current year changes recorded in AOCI |  | — |  |  | 27 |  |  | 27 |  |
| Amortization reclassified to earnings |  | (1) |  |  | (1) |  |  | (2) |  |
| Prior Service Cost or (Credit) Occurring During Fiscal Year |  | (1) |  |  | — |  |  | (1) |  |
| Settlement/curtailment reclassified to earnings |  | — |  |  | (3) |  |  | (3) |  |
| Currency translation and other |  | — |  |  | (3) |  |  | (3) |  |
| Divestitures |  | — |  |  | (10) |  |  | (10) |  |
| As of December 31, 2024 |  | $ | 4 |  |  | $ | 130 |  |  | $ | 134 |  |

[0001783180-25-000008:notes:151]
Information for pension plans with accumulated benefit obligations in excess of plan assets:

[0001783180-25-000008:notes:152]
| (In millions) | 2024 |  | 2023 |
| Projected benefit obligation | $ | 481 |  |  | $ | 378 |  |
| Accumulated benefit obligation | $ | 456 |  |  | $ | 362 |  |
| Fair value of plan assets | $ | 288 |  |  | $ | 239 |  |

[0001783180-25-000008:notes:153]
Information for pension plans with projected benefit obligations in excess of plan assets:

[0001783180-25-000008:notes:154]
The accumulated benefit obligation for all defined benefit plans was $0.6 billion and $0.6 billion as of December 31, 2024 and 2023, respectively.

[0001783180-25-000008:notes:155]
Pension benefit payments, including amounts to be paid from corporate assets, and reflecting expected future service, as appropriate, are expected to be paid as follows:

[0001783180-25-000008:notes:156]
| (In millions) |  |
| 2025 | $ | 37 |  |
| 2026 | $ | 38 |  |
| 2027 | $ | 47 |  |
| 2028 | $ | 45 |  |
| 2029 | $ | 46 |  |
| 2030 through 2034 | $ | 242 |  |

[0001783180-25-000008:notes:157]
For the years ended December 31, 2024, 2023 and 2022, the Company made $34 million, $33 million and $16 million, respectively, of cash contributions to its defined benefit pension plans. The Company expects to make total contributions of approximately $6 million to its defined benefit pension plans in 2025.

[0001783180-25-000008:notes:158]
The components of net periodic pension expense (benefit) for the defined benefit pension plans are as follows:

[0001783180-25-000008:notes:159]
| (In millions) | 2024 |  | 2023 |  | 2022 |  |  |  |  |
| Service cost | $ | 14 |  |  | $ | 15 |  |  | $ | 20 |  |  |  |  |  |
| Interest cost | 26 |  |  | 31 |  |  | 18 |  |  |  |  |  |
| Expected return on plan assets | (36) |  |  | (32) |  |  | (27) |  |  |  |  |  |
| Amortization of prior service cost | 1 |  |  | 3 |  |  | 2 |  |  |  |  |  |
| Recognized actuarial net loss | 1 |  |  | (2) |  |  | 9 |  |  |  |  |  |
| Net settlement, curtailment and special termination benefit loss | 4 |  |  | 1 |  |  | 2 |  |  |  |  |  |
| Net periodic pension expense (benefit) | $ | 10 |  |  | $ | 16 |  |  | $ | 24 |  |  |  |  |  |
| Amounts recorded in continuing operations | $ | 10 |  |  | $ | 16 |  |  | $ | 24 |  |  |  |  |  |
| Amounts recorded in discontinued operations | — |  |  | — |  |  | — |  |  |  |  |  |
| Net periodic pension expense (benefit) | $ | 10 |  |  | $ | 16 |  |  | $ | 24 |  |  |  |  |  |

[0001783180-25-000008:notes:160]
Major assumptions used in determining the benefit obligation and net cost for pension plans are presented in the following table as weighted-averages:

[0001783180-25-000008:notes:161]
|  |  | Benefit Obligation |  | Net Costs |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |  | 2022 |  |
| Discount rate |  |  |  |  |  |  |  |  |  |  |  |
| Projected benefit obligation | 4.3% |  | 4.3 | % |  | 4.3% |  | 4.2 | % |  | 2.1 | % |  |
| Interest cost (1) |  | —% |  | — | % |  | 4.2% |  | 4.1 | % |  | 1.9 | % |  |
| Service cost (1) |  | —% |  | — | % |  | 4.5% |  | 4.5 | % |  | 2.8 | % |  |
| Salary scale |  | 2.6% |  | 2.2 | % |  | 2.2% |  | 2.4 | % |  | 3.1 | % |  |
| Expected return on plan assets | —% |  | — | % |  | 6.3% |  | 5.7 | % |  | 5.0 | % |  |

[0001783180-25-000008:notes:162]
(1) The 2024 and 2023 discount rates used to measure the service cost and interest cost applies to the significant plans of the Company. The projected benefit obligation discount rate is used for the service cost and interest cost measurements for non-significant plans.

[0001783180-25-000008:notes:163]
The expected long-term rate of return on plan assets is determined by considering the relative weighting of plan assets, the historical performance of total plan assets, individual asset classes, economic and other indicators of future performance. Return projections are assessed for reasonableness using a simulation model that incorporates yield curves, credit spreads and risk premiums to project long-term prospective returns.

[0001783180-25-000008:notes:164]
The Company's investment objective is to provide liquidity and asset levels needed to meet current and future benefit payments, while maintaining a prudent degree of portfolio diversification considering interest rate risk and market volatility. Globally, investment strategies target a mix of approximately 20% of growth seeking assets and 80% of income generating and hedging assets using a wide diversification of asset types, fund strategies and investment managers.

[0001783180-25-000008:notes:165]
The growth seeking allocation consists of global public equities in developed and emerging countries and alternative asset class strategies. The income generating assets primarily consist of government and broadly diversified high quality corporate bonds. In addition, the Company's investment strategies seek to reduce interest rate risk and have incorporated liability hedging programs as part of the long-term investment strategy. Under this objective, the income generating and hedging assets typically increase as the plans' funded status improves. The Company monitors plan funded status and asset allocation regularly in addition to investment manager performance.

[0001783180-25-000008:notes:166]
The fair values of pension plan assets by asset category are as follows:

[0001783180-25-000008:notes:167]
| (In millions) |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Observable Inputs |  | Significant Unobservable Inputs |  | Not Subjectto Leveling |  | Total |
| Asset Category |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  |  |
| Public Equities: |  |  |  |  |  |  |  |  |  |  |
| Global Equities |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | — |  |  | $ | 23 |  |
| Global Equity Funds at net asset value (1) (2) |  | — |  |  | — |  |  | — |  |  | 125 |  |  | 125 |  |
| Fixed Income Securities: |  |  |  |  |  |  |  |  |  |  |
| Governments |  | — |  |  | 23 |  |  | — |  |  | 25 |  |  | 48 |  |
| Corporate Bonds |  | — |  |  | 93 |  |  | — |  |  | — |  |  | 93 |  |
| Fixed Income Securities (2) |  | — |  |  | — |  |  | — |  |  | 156 |  |  | 156 |  |
| Real Estate (3) |  | — |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Other (4) (5) |  | — |  |  | 15 |  |  | — |  |  | 8 |  |  | 23 |  |
| Cash & Cash Equivalents (2)(6) |  | — |  |  | 28 |  |  | — |  |  | 9 |  |  | 37 |  |
| Subtotal |  | $ | — |  |  | $ | 183 |  |  | $ | — |  |  | $ | 323 |  |  | $ | 506 |  |
| Other assets and liabilities (7) |  |  |  |  |  |  |  |  |  | 1 |  |
| Total as of December 31, 2024 |  |  |  |  |  |  |  |  |  | $ | 507 |  |
| (In millions) |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Observable Inputs |  | Significant Unobservable Inputs |  | Not Subjectto Leveling |  | Total |
| Asset Category |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  |  |
| Public Equities: |  |  |  |  |  |  |  |  |  |  |
| Global Equities |  | $ | — |  |  | $ | 26 |  |  | $ | — |  |  | $ | — |  |  | $ | 26 |  |
| Global Equity Funds at net asset value (1) (2) |  | — |  |  | — |  |  | — |  |  | 125 |  |  | 125 |  |
| Fixed Income Securities: |  |  |  |  |  |  |  |  |  |  |
| Governments |  | — |  |  | 40 |  |  | — |  |  | 23 |  |  | 63 |  |
| Corporate Bonds |  | — |  |  | 44 |  |  | — |  |  | — |  |  | 44 |  |
| Fixed Income Securities (2) |  | — |  |  | 9 |  |  | — |  |  | 172 |  |  | 181 |  |
| Real Estate (3) |  | — |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Other (4)(5) |  | — |  |  | 10 |  |  | — |  |  | — |  |  | 10 |  |
| Cash & Cash Equivalents (2)(6) |  | — |  |  | 13 |  |  | — |  |  | 3 |  |  | 16 |  |
| Subtotal |  | $ | — |  |  | $ | 143 |  |  | $ | — |  |  | $ | 323 |  |  | $ | 466 |  |
| Other assets and liabilities (7) |  |  |  |  |  |  |  |  |  | 2 |  |
| Total as of December 31, 2023 |  |  |  |  |  |  |  |  |  | $ | 468 |  |

[0001783180-25-000008:notes:168]
(1) Represents commingled funds that invest primarily in common stocks.

[0001783180-25-000008:notes:169]
(2) In accordance with ASU 2015-07, Fair Value Measurement (Topic 820), certain investments that are measured at fair value using the net asset value per share (or its equivalent) practical expedient have not been classified in the fair value hierarchy. The fair value amounts presented in this table are intended to permit reconciliation of the fair value hierarchy to the amounts presented for the total pension plan assets.

[0001783180-25-000008:notes:170]
(3) Represents investments in real estate, including commingled funds and directly held properties.

[0001783180-25-000008:notes:171]
(4) Represents insurance contracts and global balanced risk commingled funds consisting mainly of equity, bonds and some commodities.

[0001783180-25-000008:notes:172]
(5) Includes fixed income repurchase agreements entered into for purposes of pension asset and liability matching.

[0001783180-25-000008:notes:173]
(6) Represents short-term commercial paper, bonds and other cash or cash-like instruments.

[0001783180-25-000008:notes:174]
(7) Represents trust receivables and payables that are not leveled.

[0001783180-25-000008:notes:175]
Derivatives in the plan are primarily used to manage risk and gain asset class exposure while still maintaining liquidity. Derivative instruments mainly consist of fixed income repurchase agreements, interest rate swaps, total return swaps and currency forward contracts.

[0001783180-25-000008:notes:176]
Quoted market prices are used to value investments when available. Investments in securities traded on exchanges, including listed futures and options, are valued at the last reported sale prices on the last business day of the year or, if not available, the last reported bid prices. Fixed income securities are primarily measured using a market approach pricing methodology, whereby observable prices are obtained by market transactions involving identical or comparable securities of issuers with similar credit ratings. Over-the-counter securities and government obligations are valued at the bid prices or the average of the bid and ask prices on the last business day of the year from published sources or, if not available, from other sources considered reliable, including broker quotes. Temporary cash investments are stated at cost, which approximates fair value.

[0001783180-25-000008:notes:177]
Multiemployer Benefit Plans

[0001783180-25-000008:notes:178]
The Company contributes to various domestic and foreign multiemployer defined benefit pension plans. The risks of participating in these multiemployer plans are different from those of single-employer plans in that assets contributed are pooled and may be used to provide benefits to employees of other participating employers. If a participating employer stops contributing to the plan, the unfunded obligations of the plan may be borne by the remaining participating employers. The Company's contributions to these plans for the years ended December 31, 2024 and 2023, was $15 million and $15 million, respectively.

[0001783180-25-000008:notes:179]
Employee Savings Plans

[0001783180-25-000008:notes:180]
The Company sponsors various employee savings plans. Employer contributions are determined based on criteria specific to each plan and were $138 million, $125 million and $123 million for the years ended December 31, 2024, 2023 and 2022, respectively.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-25-000008:notes:181]
PRODUCT WARRANTIES 
In the ordinary course of business, the Company provides standard warranty coverage on its products. Provisions for these amounts are established at the time of sale and estimated primarily based on product warranty terms and historical claims experience. In addition, the Company incurs discretionary costs to service its products in connection with specific product performance issues. Provisions for these amounts are established when they are known and estimable. The Company assesses the adequacy of its initial provisions and will make adjustments as necessary based on known or anticipated claims or as new information becomes available that suggests it is probable that future costs will be different than estimated amounts. Amounts associated with these provisions are classified on the accompanying Consolidated Balance Sheet as Accrued liabilities or Other long-term liabilities based on their anticipated settlement date.

[0001783180-25-000008:notes:182]
The changes in the carrying amount of warranty related provisions are as follows:

[0001783180-25-000008:notes:183]
| (In millions) | 2024 |  | 2023 |
| Balance as of January 1, | $ | 568 |  |  | $ | 544 |  |
| Warranties, performance guarantees issued and changes in estimated liability | 327 |  |  | 239 |  |
| Settlements made | (346) |  |  | (194) |  |
| Other | 5 |  |  | (11) |  |
| Acquisitions (1) | 232 |  |  | — |  |
| Reclassified to held for sale (2) | — |  |  | (10) |  |
| Balance as of December 31, | $ | 786 |  |  | $ | 568 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-25-000008:notes:184]
EQUITY 
The authorized number of shares of common stock of Carrier is 4,000,000,000 shares of $0.01 par value. As of December 31, 2024 and December 31, 2023, 948,068,772 and 883,068,393 shares of common stock were issued, respectively, which includes 70,093,639 and 43,490,981 shares of treasury stock, respectively.

[0001783180-25-000008:notes:185]
Share Repurchase Program

[0001783180-25-000008:notes:186]
The Company may purchase its outstanding common stock from time to time subject to market conditions and at the Company's discretion. Repurchases occur in the open market or through one or more other public or private transactions pursuant to plans complying with Rules 10b5-1 and 10b-18 under the Exchange Act. Shares acquired are recognized at cost and presented separately on the balance sheet as a reduction to Equity. Since the initial authorization in February 2021, the Company's Board of Directors authorized the repurchase of up to $7.1 billion of the Company's outstanding common stock which includes a $3 billion increase approved in October 2024. As of December 31, 2024, the Company repurchased 70.1 million shares of common stock for an aggregate purchase price of $3.9 billion. As a result, the Company has approximately $3.2 billion remaining under the current authorization at December 31, 2024.

[0001783180-25-000008:notes:187]
Accumulated Other Comprehensive Income (Loss)

[0001783180-25-000008:notes:188]
A summary of changes in the components of Accumulated other comprehensive income (loss) is as follows:

[0001783180-25-000008:notes:189]
| (In millions) | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Unrealized Hedging Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of January 1, 2022 | $ | (505) |  |  | $ | (484) |  |  |  |  |  |  | $ | — |  |  | $ | (989) |  |
| Other comprehensive income (loss) before reclassifications, net | (525) |  |  | 63 |  |  |  |  |  |  | — |  |  | (462) |  |
| Amounts reclassified, pre-tax | — |  |  | 11 |  |  |  |  |  |  | — |  |  | 11 |  |
| Tax benefit reclassified | — |  |  | (3) |  |  |  |  |  |  | — |  |  | (3) |  |
| Chubb divestiture | (574) |  |  | 329 |  |  |  |  |  |  | — |  |  | (245) |  |
| Balance as of December 31, 2022 | $ | (1,604) |  |  | $ | (84) |  |  |  |  |  |  | $ | — |  |  | $ | (1,688) |  |
| Other comprehensive income (loss) before reclassifications, net | 160 |  |  | (17) |  |  |  |  |  |  | 58 |  |  | 201 |  |
| Amounts reclassified, pre-tax | — |  |  | 1 |  |  |  |  |  |  | — |  |  | 1 |  |
| Balance as of December 31, 2023 | $ | (1,444) |  |  | $ | (100) |  |  |  |  |  |  | $ | 58 |  |  | $ | (1,486) |  |
| Other comprehensive income (loss) before reclassifications, net | (1,173) |  |  | (15) |  |  |  |  |  |  | — |  |  | (1,188) |  |
| Amounts reclassified, pre-tax | — |  |  | 2 |  |  |  |  |  |  | (6) |  |  | (4) |  |
| Tax benefit reclassified | — |  |  | (1) |  |  |  |  |  |  | 2 |  |  | 1 |  |
| Divestitures, net | 564 |  |  | 7 |  |  |  |  |  |  | — |  |  | 571 |  |
| Balance as of December 31, 2024 | $ | (2,053) |  |  | $ | (107) |  |  |  |  |  |  | $ | 54 |  |  | $ | (2,106) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-25-000008:notes:190]
REVENUE RECOGNITION 
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.

[0001783180-25-000008:notes:191]
Performance Obligations

[0001783180-25-000008:notes:192]
A performance obligation is a distinct good, service or a bundle of goods and services promised in a contract. Some of the Company's contracts with customers contain a single performance obligation, while others contain multiple performance obligations most commonly when a contract spans multiple phases of a product life-cycle such as production, installation, maintenance and support. The Company identifies performance obligations at the inception of a contract and allocates the transaction price to each distinct performance obligation. Revenue is recognized when or as the performance obligation is satisfied. When there are multiple performance obligations within a contract, the Company allocates the transaction price to each performance obligation based on its relative stand-alone selling price.

[0001783180-25-000008:notes:193]
The Company primarily generates revenue from the sale of products to customers and recognizes revenue at a point in time when control transfers to the customer. Transfer of control is generally based on the shipping terms of the contract. In addition, the Company recognizes revenue on an over-time basis on installation and service contracts. For over-time performance obligations requiring the installation of equipment, revenue is recognized using costs incurred to date relative to total estimated costs at completion to measure progress. Incurred costs represent work performed, which correspond with and best depict transfer of control to the customer. Contract costs include direct costs such as labor, materials and subcontractors’ costs and where applicable, indirect costs.

[0001783180-25-000008:notes:194]
Segment sales disaggregated by product and service are as follows:

[0001783180-25-000008:notes:195]
| (In millions) |  | 2024 |  | 2023 |  | 2022 |
| Sales Type |  |  |  |  |  |  |
| Product |  | $ | 16,986 |  |  | $ | 13,313 |  |  | $ | 11,882 |  |
| Service |  | 2,092 |  |  | 1,826 |  |  | 1,526 |  |
| HVAC sales |  | 19,078 |  |  | 15,139 |  |  | 13,408 |  |
| Product |  | 3,061 |  |  | 3,352 |  |  | 3,432 |  |
| Service |  | 414 |  |  | 466 |  |  | 451 |  |
| Refrigeration sales |  | 3,475 |  |  | 3,818 |  |  | 3,883 |  |
| Total segment sales |  | 22,553 |  |  | 18,957 |  |  | 17,291 |  |
| Eliminations and other (1) |  | (67) |  |  | (6) |  |  | (3) |  |
| Consolidated |  | $ | 22,486 |  |  | $ | 18,951 |  |  | $ | 17,288 |  |

[0001783180-25-000008:notes:196]
(1) Includes certain business activities previously reported in the Fire & Security segment.

[0001783180-25-000008:notes:197]
The transaction price allocated to performance obligations reflects the Company’s expectations about the consideration it will be entitled to receive from a customer. The Company includes variable consideration in the estimated transaction price when there is a basis to reasonably estimate the amount and when it is probable that a significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. In addition, the Company customarily offers its customers incentives to purchase products to ensure an adequate supply of its products in distribution channels. The principal incentive programs provide reimbursements to distributors for offering promotional pricing for products. The Company accounts for estimated incentive payments as a reduction in sales at the time a sale is recognized.

[0001783180-25-000008:notes:198]
Contract Balances

[0001783180-25-000008:notes:199]
Total contract assets and liabilities consisted of the following:

[0001783180-25-000008:notes:200]
| (In millions) | 2024 |  | 2023 |
| Contract assets, current (included within Other current assets) | $ | 366 |  |  | $ | 306 |  |
| Contract assets, non-current (included within Other assets) | 65 |  |  | 26 |  |
| Total contract assets | 431 |  |  | 332 |  |
| Contract liabilities, current (included within Accrued liabilities) | (553) |  |  | (419) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) | (164) |  |  | (160) |  |
| Total contract liabilities | (717) |  |  | (579) |  |
| Net contract assets (liabilities) | $ | (286) |  |  | $ | (247) |  |

[0001783180-25-000008:notes:201]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to the customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.

[0001783180-25-000008:notes:202]
The Company recognized revenue of $469 million for the year ended December 31, 2024, that was related to contract liabilities as of January 1, 2024. The Company expects a majority of its contract liabilities at the end of the period to be recognized as revenue over the next 12 months. There were no individually significant customers with sales exceeding 10% of total sales for the years ended December 31, 2024, 2023 and 2022.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001783180-25-000008:notes:203]
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.

[0001783180-25-000008:notes:204]
The transaction price allocated to performance obligations reflects the Company’s expectations about the consideration it will be entitled to receive from a customer. The Company includes variable consideration in the estimated transaction price when there is a basis to reasonably estimate the amount and when it is probable that a significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. In addition, the Company customarily offers its customers incentives to purchase products to ensure an adequate supply of its products in distribution channels. The principal incentive programs provide reimbursements to distributors for offering promotional pricing for products. The Company accounts for estimated incentive payments as a reduction in sales at the time a sale is recognized.
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to the customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001783180-25-000008:notes:205]
Geographic external sales and operating profits are attributed to the geographic regions based on their location of origin. With the exception of the U.S. as presented in the following table, there were no individually significant countries with sales exceeding 10% of total sales for the years ended December 31, 2024, 2023 and 2022.

[0001783180-25-000008:notes:206]
|  |  | External Sales |  | Long-Lived Assets |  |  |  |
| (In millions) |  | 2024 |  | 2023 |  | 2022 |  | 2024 |  | 2023 |  |  |  |
| United States Operations |  | $ | 11,294 |  |  | $ | 10,457 |  |  | $ | 9,997 |  |  | $ | 807 |  |  | $ | 795 |  |  |  |  |
| International Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Europe |  | 6,687 |  |  | 3,910 |  |  | 3,591 |  |  | 1,253 |  |  | 450 |  |  |  |  |
| Asia Pacific |  | 3,817 |  |  | 3,949 |  |  | 3,090 |  |  | 486 |  |  | 499 |  |  |  |  |
| Other |  | 688 |  |  | 635 |  |  | 610 |  |  | 453 |  |  | 416 |  |  |  |  |
| Consolidated |  | $ | 22,486 |  |  | $ | 18,951 |  |  | $ | 17,288 |  |  | $ | 2,999 |  |  | $ | 2,160 |  |  |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001783180-25-000008:notes:207]
STOCK-BASED COMPENSATION
The Company accounts for stock-based compensation plans in accordance with ASC 718, Compensation - Stock Compensation, which requires a fair-value based method for measuring the value of stock-based compensation. Fair value is measured at the date of grant and is generally not adjusted for subsequent changes. The Company's stock-based compensation plans include programs for stock appreciation rights, restricted stock and performance share units.

[0001783180-25-000008:notes:208]
Stock Options and Appreciation Rights

[0001783180-25-000008:notes:209]
Eligible participants may receive stock options or stock appreciation rights as part of the Company's long-term incentive program. The fair value of each instrument is determined as of the date of grant using a binomial lattice model and expensed on a straight-line basis over the required service period, which is generally a three-year vesting period. However, in the event of retirement, awards held for at least one year may vest and become exercisable (if applicable), subject to certain terms and conditions.

[0001783180-25-000008:notes:210]
The following table summarizes fair value information for stock options and stock appreciation rights:

[0001783180-25-000008:notes:211]
|  |  | 2024 (1) |  | 2023 (1) |  | 2022 (1) |
| Stock options and stock appreciation rights weighted-average fair value per award |  | $ | 14.84 |  |  | $ | 11.64 |  |  | $ | 10.68 |  |
| Assumptions: |  |  |  |  |  |  |
| Volatility |  | 30.6% to 31.7% |  | 30.9% |  | 30.8% to 31.3% |
| Expected term (in years) |  | 5.6 to 7.8 |  | 5.8 |  | 6.1 |
| Expected dividend yield |  | 1.8% |  | 1.8% |  | 1.5% |
| Range of risk-free rates |  | 4.0% to 4.3% |  | 3.6% |  | 1.7% to 3.0% |

[0001783180-25-000008:notes:212]
(1) Carrier has limited historical trading data and used peer group data to estimate expected volatility for the 2024, 2023 and 2022 awards.

[0001783180-25-000008:notes:213]
The Company used historical employee data, including data prior to the Separation and the Distribution, to estimate expected term. The expected dividend yield is consistent with management's expectations. The risk-free rate is based on the term structure of interest rates at the time the awards were granted.

[0001783180-25-000008:notes:214]
Changes in stock options and stock appreciation rights outstanding were as follows:

[0001783180-25-000008:notes:215]
|  | Shares Subject to Option(in thousands) |  | Weighted-Average Exercise Price |  | Aggregate Intrinsic Value (in millions) |  | Weighted- Average Remaining Life (in years) |
| As of December 31, 2021 | 32,441 |  |  | $ | 22.02 |  |  |  |  |  |
| Granted | 2,715 |  |  | $ | 47.72 |  |  |  |  |  |
| Exercised | (3,495) |  |  | $ | 17.76 |  |  |  |  |  |
| Cancelled | (883) |  |  | $ | 30.33 |  |  |  |  |  |
| As of December 31, 2022 | 30,778 |  |  | $ | 24.53 |  |  |  |  |  |
| Granted | 3,494 |  |  | $ | 46.13 |  |  |  |  |  |
| Exercised | (8,432) |  |  | $ | 20.48 |  |  |  |  |  |
| Cancelled | (769) |  |  | $ | 42.94 |  |  |  |  |  |
| As of December 31, 2023 | 25,071 |  |  | $ | 28.34 |  |  |  |  |  |
| Granted | 4,187 |  |  | $ | 56.46 |  |  |  |  |  |
| Exercised | (8,041) |  |  | $ | 23.21 |  |  |  |  |  |
| Cancelled | (430) |  |  | $ | 50.77 |  |  |  |  |  |
| Outstanding as of December 31, 2024 | 20,787 |  |  | $ | 35.52 |  |  | $ | 681 |  |  | 5.8 |
| Exercisable as of December 31, 2024 | 12,746 |  |  | $ | 25.48 |  |  | $ | 545 |  |  | 4.1 |

[0001783180-25-000008:notes:216]
Restricted Stock Units

[0001783180-25-000008:notes:217]
Eligible participants may receive restricted stock units ("RSU") as part of the Company's long-term incentive program. The fair value of restricted stock units are based on the closing market price of the Company's common stock on the date of grant and expensed on a straight-line basis over the required service period (which is generally a three-year vesting period). However, in the event of retirement, awards held for at least one year may vest and become exercisable (if applicable), subject to certain terms and conditions. Dividends accrue during the vesting period and are paid in shares of the Company's common stock.

[0001783180-25-000008:notes:218]
Changes in restricted stock units were as follows:

[0001783180-25-000008:notes:219]
|  | RSUs (in thousands) |  | Weighted-Average Grant Date Fair Value |
| Outstanding and unvested as of December 31, 2021 | 3,570 |  |  | $ | 23.33 |  |
| Granted | 555 |  |  | $ | 41.88 |  |
| Vested | (1,915) |  |  | $ | 20.85 |  |
| Cancelled | (143) |  |  | $ | 32.92 |  |
| Outstanding and unvested as of December 31, 2022 | 2,067 |  |  | $ | 29.87 |  |
| Granted | 577 |  |  | $ | 45.71 |  |
| Vested | (1,140) |  |  | $ | 26.09 |  |
| Cancelled | (161) |  |  | $ | 35.09 |  |
| Outstanding and unvested as of December 31, 2023 | 1,343 |  |  | $ | 39.22 |  |
| Granted | 264 |  |  | $ | 59.88 |  |
| Vested | (448) |  |  | $ | 38.17 |  |
| Cancelled | (68) |  |  | $ | 49.14 |  |
| Outstanding and unvested as of December 31, 2024 | 1,091 |  |  | $ | 43.94 |  |

[0001783180-25-000008:notes:220]
Performance Share Units

[0001783180-25-000008:notes:221]
The Company has a performance share program for key employees whereby awards are provided in the form of performance share units ("PSU") based on performance against pre-established objectives. The annual target level is expressed as shares of the Company's common stock based on the fair value of its stock on the date of grant. Awards are generally earned over a three-year performance period based equally on a performance condition, measured by the compound annual growth rate of the Company's earnings per share and on a market condition, measured by the Company's relative total shareowner return compared to the total shareowner return of a subset of industrial companies in the S&P 500 Index. The fair value of the market condition is estimated using a Monte Carlo simulation approach. The fair value of the PSU awards are expensed over the required service period, which is generally a three-year vesting period. In the event of retirement, performance share units held for at least one year remain eligible to vest based on actual performance relative to pre-established metrics. Dividends do not accrue on the performance share units during the performance period.

[0001783180-25-000008:notes:222]
Changes in PSUs were as follows:

[0001783180-25-000008:notes:223]
|  | PSUs (in thousands) |  | Weighted-Average Grant Date Fair Value |
| Outstanding and unvested as of December 31, 2021 | 1,421 |  |  | $ | 30.75 |  |
| Granted | 653 |  |  | $ | 46.93 |  |
| Vested | (5) |  |  | $ | 41.81 |  |
| Forfeited | (139) |  |  | $ | 35.45 |  |
| Outstanding and unvested as of December 31, 2022 | 1,930 |  |  | $ | 35.86 |  |
| Granted | 902 |  |  | $ | 47.93 |  |
| Vested | (607) |  |  | $ | 18.23 |  |
| Forfeited | (183) |  |  | $ | 46.52 |  |
| Outstanding and unvested as of December 31, 2023 | 2,042 |  |  | $ | 45.47 |  |
| Granted | 1,741 |  |  | $ | 50.75 |  |
| Vested | (1,339) |  |  | $ | 41.49 |  |
| Forfeited | (121) |  |  | $ | 52.56 |  |
| Outstanding and unvested as of December 31, 2024 | 2,323 |  |  | $ | 51.35 |  |

[0001783180-25-000008:notes:224]
Compensation Expense

[0001783180-25-000008:notes:225]
Stock-based compensation expense, net of estimated forfeitures, is included in Cost of products sold, Selling, general and administrative and Research and development, in the accompanying Consolidated Statement of Operations.

[0001783180-25-000008:notes:226]
Stock-based compensation cost by award type are as follows:

[0001783180-25-000008:notes:227]
| (In millions) | 2024 |  | 2023 |  | 2022 |
| Equity compensation costs - equity settled | $ | 98 |  |  | $ | 81 |  |  | $ | 77 |  |
| Equity compensation costs - cash settled (1) | 2 |  |  | 3 |  |  | (15) |  |
| Total stock-based compensation cost | $ | 100 |  |  | $ | 84 |  |  | $ | 62 |  |
| Amounts recorded in continuing operations | $ | 87 |  |  | $ | 74 |  |  | $ | 53 |  |
| Amounts recorded in discontinued operations | 13 |  |  | 10 |  |  | 9 |  |
| Total stock-based compensation cost | $ | 100 |  |  | $ | 84 |  |  | $ | 62 |  |
| Income tax benefit | $ | 13 |  |  | $ | 11 |  |  | $ | 9 |  |

[0001783180-25-000008:notes:228]
(1) The cash settled awards are classified as liability awards and are measured at fair value at each balance sheet date.

[0001783180-25-000008:notes:229]
As of December 31, 2024 and 2023, there were $112 million and $63 million of unrecognized stock-based compensation costs related to non-vested awards granted under the plan, respectively, which will be recognized ratably over the awards weighted-average remaining vesting period of 3 years.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-25-000008:notes:230]
RESTRUCTURING COSTS 
The Company incurs costs associated with restructuring initiatives intended to improve operating performance, profitability and working capital levels. Actions associated with these initiatives may include improving productivity, workforce reductions and the consolidation of facilities. Due to the size, nature and frequency of these discrete plans, they are fundamentally different from the Company’s ongoing productivity initiatives.

[0001783180-25-000008:notes:231]
The Company recorded net pre-tax restructuring costs for new and ongoing restructuring actions as follows:

[0001783180-25-000008:notes:232]
| (In millions) | 2024 |  | 2023 |  | 2022 |
| HVAC | $ | 87 |  |  | $ | 44 |  |  | $ | 8 |  |
| Refrigeration | 8 |  |  | 21 |  |  | 10 |  |
| Total Segment | 95 |  |  | 65 |  |  | 18 |  |
| General corporate expenses | 13 |  |  | 10 |  |  | 2 |  |
| Total restructuring costs (1) | $ | 108 |  |  | $ | 75 |  |  | $ | 20 |  |
| Cost of sales | $ | 42 |  |  | $ | 13 |  |  | $ | 6 |  |
| Selling, general and administrative | 66 |  |  | 62 |  |  | 14 |  |
| Total restructuring costs (1) | $ | 108 |  |  | $ | 75 |  |  | $ | 20 |  |

[0001783180-25-000008:notes:233]
(1) 2024 restructuring costs include period-related charges.

[0001783180-25-000008:notes:234]
The following table summarizes changes in the restructuring reserve, included in Accrued liabilities on the accompanying Consolidated Balance Sheet:

[0001783180-25-000008:notes:235]
| (In millions) |  | 2024 |  | 2023 |
| Balance as of January 1, |  | $ | 41 |  |  | $ | 21 |  |
| Net pre-tax restructuring costs |  | 98 |  |  | 75 |  |
| Acquisitions (1) |  | 8 |  |  | — |  |
| Utilization, foreign exchange and other |  | (78) |  |  | (48) |  |
| Reclassified to held for sale (2) |  | — |  |  | (7) |  |
| Balance as of December 31, |  | $ | 69 |  |  | $ | 41 |  |

[0001783180-25-000008:notes:236]
As of December 31, 2024, the Company had $69 million accrued for costs associated with its announced restructuring initiatives. The balance relates to cost reduction efforts, primarily severance, across each of the Company's segments. In addition, reserves associated with the Company's planned portfolio transformation were established during the year, all of which are expected to be paid within 12 months.


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001783180-25-000008:notes:237]
OTHER INCOME (EXPENSE), NET
Other income (expense), net consisted of the following:

[0001783180-25-000008:notes:238]
| (In millions) | 2024 |  | 2023 |  | 2022 |
| Viessmann-related hedges | (86) |  |  | (96) |  |  | — |  |
| CCR gain | 318 |  |  | — |  |  | — |  |
| TMA-related gain | 46 |  |  | — |  |  | — |  |
| TCC acquisition-related gain | — |  |  | (8) |  |  | 705 |  |
| Chubb gain | — |  |  | — |  |  | 1,105 |  |
| Other | 39 |  |  | (9) |  |  | 8 |  |
| Other income (expense), net | $ | 317 |  |  | $ | (113) |  |  | $ | 1,818 |  |

[0001783180-25-000008:notes:239]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than the entity's functional currency and hedging-related activities. During the year ended December 31, 2024, the Company completed the sale of CCR and recognized a gain on the sale of $318 million. In addition, the Company recognized a $46 million gain associated with its share of UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the IRS. In connection with the acquisition of the VCS Business, the Company recognized a $86 million loss on the mark-to-market valuation of its window forward contracts associated with the cash outflows of the Euro-denominated purchase price.

[0001783180-25-000008:notes:240]
During the year ended December 31, 2023, the Company recognized a $96 million loss on the mark-to-market valuation of its window forward contracts associated with the cash outflows of the Euro-denominated purchase price of the VCS Business. During the year ended December 31, 2022, the carrying value of the Company's previously held equity investments in TCC were recognized at fair value at the date of acquisition. As a result, the Company recognized a $697 million non-cash gain associated with the increase in its ownership interest. In addition, the Company completed the Chubb Sale and recognized a gain on the sale of $1.1 billion.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-25-000008:notes:241]
INCOME TAXES 
Income Before Income Taxes

[0001783180-25-000008:notes:242]
The sources of Income from operations before income taxes are as follows:

[0001783180-25-000008:notes:243]
| (In millions) | 2024 |  | 2023 |  | 2022 |
| United States | $ | 1,948 |  |  | $ | 1,398 |  |  | $ | 1,528 |  |
| Foreign | 326 |  |  | 601 |  |  | 2,295 |  |
| Total | $ | 2,274 |  |  | $ | 1,999 |  |  | $ | 3,823 |  |

[0001783180-25-000008:notes:244]
Provision for Income Taxes

[0001783180-25-000008:notes:245]
The income tax expense (benefit) consisted of the following components:

[0001783180-25-000008:notes:246]
| (In millions) | 2024 |  | 2023 |  | 2022 |
| Current: |  |  |  |  |  |
| United States: |  |  |  |  |  |
| Federal | $ | 920 |  |  | $ | 361 |  |  | $ | 405 |  |
| State | 120 |  |  | 110 |  |  | 106 |  |
| Foreign | 374 |  |  | 293 |  |  | 211 |  |
|  | 1,414 |  |  | 764 |  |  | 722 |  |
| Future: |  |  |  |  |  |
| United States: |  |  |  |  |  |
| Federal | (90) |  |  | (135) |  |  | (10) |  |
| State | (13) |  |  | (28) |  |  | (26) |  |
| Foreign | (249) |  |  | (80) |  |  | (70) |  |
|  | (352) |  |  | (243) |  |  | (106) |  |
| Income tax expense | $ | 1,062 |  |  | $ | 521 |  |  | $ | 616 |  |

[0001783180-25-000008:notes:247]
Reconciliation of Effective Income Tax Rate

[0001783180-25-000008:notes:248]
The differences between the effective income tax rate and the statutory U.S. federal income tax rate are as follows:

[0001783180-25-000008:notes:249]
|  | 2024 |  | 2023 |  | 2022 |  |
| Statutory U.S. federal income tax rate | 21.0 | % |  | 21.0 | % |  | 21.0 | % |  |
| State income tax | 2.4 |  |  | 2.4 |  |  | 1.4 |  |  |
| Taxes on international activities | (0.2) |  |  | 4.9 |  |  | (0.9) |  |  |
| CCR divestiture impact | (2.0) |  |  | — |  |  | — |  |  |
| VCS reorganization impact | 28.6 |  |  | — |  |  | — |  |  |
| TCC acquisition impact | — |  |  | — |  |  | (4.7) |  |  |
| Other | (3.1) |  |  | (2.2) |  |  | (0.7) |  |  |
| Effective income tax rate | 46.7 | % |  | 26.1 | % |  | 16.1 | % |  |

[0001783180-25-000008:notes:250]
The effective tax rate for the year ended December 31, 2024 was higher than the Company's statutory U.S. federal income tax rate. The increase was primarily driven by a net tax charge of $650 million related to a re-organization of the VCS Business and a non-deductible loss of $86 million on the mark-to-market valuation of the Company's window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business, partially offset by the lower effective tax rate on the $318 million gain on the sale of CCR and $44 million of foreign tax credits generated and utilized in the current year.

[0001783180-25-000008:notes:251]
The effective tax rate for the year ended December 31, 2023 was higher than the Company's statutory U.S. federal income tax rate. The increase was primarily driven by a net tax charge of $27 million relating to the re-organization and disentanglement of the CCR businesses in advance of the planned divestiture. In addition, the effective tax rate was impacted by the recognition of a deferred tax liability for withholding tax of $19 million on repatriated foreign earnings, non-deductible divestiture-related costs and a non-deductible loss of $96 million on the mark-to-market valuation of the Company's window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business.

[0001783180-25-000008:notes:252]
The effective tax rate for the year ended December 31, 2022 was lower than the Company's statutory U.S. federal income tax rate. The decrease was driven by a lower effective tax rate on the $705 million non-cash gain resulting from the recognition of the Company's previously held TCC equity investments at fair value upon acquisition of TCC, a lower effective tax rate on the $1.1 billion Chubb gain and $45 million of foreign tax credits generated and utilized in the current year.

[0001783180-25-000008:notes:253]
Deferred Tax Assets and Liabilities

[0001783180-25-000008:notes:254]
Future income taxes represent the tax effects of transactions, which are reported in different periods for tax and GAAP purposes. These amounts consist of the tax effects of differences between tax and GAAP that are expected to be reversed in the future and tax carryforwards. Future income tax benefits and obligations within the same tax paying component of a particular jurisdiction are offset for presentation in the Consolidated Balance Sheet.

[0001783180-25-000008:notes:255]
The tax effects of temporary differences and tax carryforwards which give rise to future income tax benefits and obligations as of December 31, 2024 and 2023, are as follows:

[0001783180-25-000008:notes:256]
| (In millions) | 2024 |  | 2023 |
| Future income tax benefits: |  |  |  |
| Insurance and employee benefits | $ | 142 |  |  | $ | 155 |  |
| Other assets basis differences | 576 |  |  | 413 |  |
| Other liabilities basis differences | 674 |  |  | 531 |  |
| Tax loss carryforwards | 178 |  |  | 159 |  |
| Tax credit carryforwards | 1,404 |  |  | 1,332 |  |
| Valuation allowances | (1,442) |  |  | (1,372) |  |
| Future income tax benefits | $ | 1,532 |  |  | $ | 1,218 |  |
| Future income tax obligations: |  |  |  |
| Goodwill and intangible assets | $ | (1,769) |  |  | $ | (401) |  |
| Other asset basis differences | (381) |  |  | (389) |  |
| Future income tax obligations | $ | (2,150) |  |  | $ | (790) |  |

[0001783180-25-000008:notes:257]
Valuation allowances have been established primarily for tax credit carryforwards, tax loss carryforwards and certain foreign temporary differences to reduce future income tax benefits to expected realizable amounts.

[0001783180-25-000008:notes:258]
Changes to valuation allowances consisted of the following:

[0001783180-25-000008:notes:259]
| (In millions) |  |  |
| Balance as of January 1, 2022 |  | $ | 90 |  |
| Additions charged to income tax expense |  | 18 |  |
| Reduction credited to income tax expense |  | (22) |  |
| Other adjustments |  | 14 |  |
| Reclassified to held for sale |  | (17) |  |
| Balance at December 31, 2022 |  | $ | 83 |  |
| Additions charged to income tax expense |  | 27 |  |
| Reduction credited to income tax expense |  | (22) |  |
| Other adjustments (1) |  | 1,303 |  |
| Reclassified to held for sale |  | (19) |  |
| Balance at December 31, 2023 |  | $ | 1,372 |  |
| Additions charged to income tax expense |  | 46 |  |
| Reduction credited to income tax expense |  | (41) |  |
| Other adjustments |  | 65 |  |
| Balance as of December 31, 2024 |  | $ | 1,442 |  |

[0001783180-25-000008:notes:260]
(1) See discussion below regarding the Swiss tax credit.

[0001783180-25-000008:notes:261]
Tax Credit and Loss Carryforwards

[0001783180-25-000008:notes:262]
As of December 31, 2024, tax credit carryforwards and tax loss carryforwards were as follows:

[0001783180-25-000008:notes:263]
| (In millions) | Tax Loss Carryforwards |  | Tax Credit Carryforwards |
| Expiration period: |  |  |  |
| 2025-2029 | $ | 525 |  |  | $ | 15 |  |
| 2030-2034 | 21 |  |  | 1,375 |  |
| 2035-2044 | 77 |  |  | — |  |
| Indefinite | 457 |  |  | 14 |  |
| Total | $ | 1,080 |  |  | $ | 1,404 |  |

[0001783180-25-000008:notes:264]
The Company assesses the realizability of its deferred tax assets on a quarterly basis through an analysis of potential sources of future taxable income, including prior year taxable income available to absorb a carryback of tax losses, reversals of existing taxable temporary differences, tax planning strategies and forecasts of taxable income. The Company considers all negative and positive evidence, including the weight of the evidence, to determine if valuation allowances against deferred tax assets are required. The Company maintains valuation allowances against certain deferred tax assets.

[0001783180-25-000008:notes:265]
In conjunction with the announced portfolio transformation, the Company is implementing changes to its corporate structure, including intra-entity transfers of certain intellectual property to a subsidiary in Switzerland. During 2025, the Company will begin transferring certain intellectual property from wholly-owned legal entities to the Swiss subsidiary. During 2023, the Company’s Swiss subsidiary was granted a tax credit of approximately $1.3 billion that is available to offset cantonal income tax liability over a ten-year period. As the Company is in the preliminary stages of the reorganization, a full valuation allowance was recorded against this tax credit. As operations in the Swiss subsidiary expand in future years it will be necessary to reassess the estimated realizable tax benefit associated with the tax credit.

[0001783180-25-000008:notes:266]
Unrecognized Tax Benefits

[0001783180-25-000008:notes:267]
As of December 31, 2024, the Company had unrecognized tax benefits of $365 million, all of which, if recognized, would impact its effective tax rate. A reconciliation of the beginning and ending amounts of unrecognized tax benefits and related interest expense is as follows:

[0001783180-25-000008:notes:268]
| (In millions) | 2024 |  | 2023 |  | 2022 |
| Balance at beginning of period | $ | 382 |  |  | $ | 291 |  |  | $ | 251 |  |
| Additions for tax positions related to the current year | 34 |  |  | 37 |  |  | 34 |  |
| Additions for tax positions of prior years (1) | 30 |  |  | 81 |  |  | 32 |  |
| Reductions for tax positions of prior years | (7) |  |  | — |  |  | (13) |  |
| Settlements | (68) |  |  | (27) |  |  | (13) |  |
| Reclassified to other accounts | (6) |  |  | — |  |  | — |  |
| Balance at end of period | $ | 365 |  |  | $ | 382 |  |  | $ | 291 |  |
| Gross interest expense related to unrecognized tax benefits | $ | 19 |  |  | $ | 18 |  |  | $ | 16 |  |
| Total accrued interest balance at end of period | $ | 57 |  |  | $ | 64 |  |  | $ | 48 |  |

[0001783180-25-000008:notes:269]
(1) Includes $73 million during the year ended December 31, 2023, related to acquisitions.

[0001783180-25-000008:notes:270]
The Company conducts business globally and, as a result, the Company and its subsidiaries file income tax returns in the U.S. federal, various state and foreign jurisdictions. In certain jurisdictions, the Company's operations were included in UTC's combined tax returns for the periods through the date of the Separation and Distribution. The IRS finalized the examination of UTC's tax years 2017 and 2018 resulting in the recognition of a tax benefit of $21 million in the first quarter of 2024. The IRS examination of UTC's tax year 2020, which Carrier was included in through the date of Separation and Distribution, is expected to conclude in 2025. The U.S. Federal statute of limitations for Carrier's tax year ending on December 31, 2020 expired during the three months ended December 31, 2024 resulting in a recognized tax benefit of $8 million. The IRS has begun an examination of Carrier's tax year 2022 with the examination in an early stage. In the normal course of business, the Company is subject to examination by taxing authorities throughout the world, including the U.S., Australia, Belgium, Canada, China, France, Germany, India, Italy, Malaysia, Poland, Singapore, Spain, and the United Kingdom. The Company is no longer subject to U.S. federal income tax examination for years prior to 2020 and, with few exceptions, is no longer subject to U.S. state and local and foreign income tax examinations for tax years before 2013.

[0001783180-25-000008:notes:271]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. The Company believes that it is reasonably possible that a net decrease in unrecognized tax benefits of $10 million to $40 million may occur within 12 months as a result of additional uncertain tax positions, the revaluation of uncertain tax positions arising from examinations, appeals, court decisions or the closure of tax statutes.

[0001783180-25-000008:notes:272]
In October 2021, the Organization for Economic Co-operation and Development ("OECD")/G20 finalized the significant components of a two-pillar global tax reform plan, which has now been agreed to by the majority of OECD members. Pillar One allows countries to reallocate amongst other taxing jurisdictions a portion of residual profits earned by multinational enterprises ("MNE"), with annual global revenue exceeding €20 billion and a profit margin over 10%. The adoption of Pillar One and its potential effective date remain uncertain. Pillar Two requires MNEs with annual global revenue exceeding €750 million to pay a global minimum tax of 15%. On January 13, 2025, the OECD published additional administrative guidance on Pillar Two regarding deferred tax accounting for loss carryforwards and tax credits. The Company is evaluating the impact this additional guidance may have on the utilization of the income tax credit generated by the Company's Swiss subsidiary as discussed above.

[0001783180-25-000008:notes:273]
As a result of the Tax Cuts and Jobs Act ("TCJA"), the Company no longer intends to reinvest certain undistributed earnings of its international subsidiaries including some earnings which have been previously taxed in the U.S. As such, the Company has recorded tax liabilities associated with the future remittance of these earnings. For the remainder of the Company's undistributed international earnings, unless it becomes tax effective to repatriate, the Company intends to continue to permanently reinvest these earnings. As of December 31, 2024, such undistributed earnings were approximately $11.5 billion, excluding other comprehensive income amounts. It is not practicable to estimate the amount of tax that might be payable on the remaining amounts. In addition, the TCJA subjects the Company to a tax on global intangible low-taxed income ("GILTI"). GILTI is a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations which the Company has elected to account for as a period cost.


## us-gaap:EarningsPerShareTextBlock

[0001783180-25-000008:notes:274]
EARNINGS PER SHARE 
Earnings per share is computed by dividing Net earnings (loss) attributable to common shareowners by the weighted-average number of shares of common stock outstanding during the period (excluding treasury stock). Diluted earnings per share is computed by giving effect to all potentially dilutive stock awards that are outstanding. The computation of diluted earnings per share excludes the effect of the potential exercise of stock-based awards, including stock appreciation rights and stock options, when the effect of the potential exercise would be anti-dilutive.

[0001783180-25-000008:notes:275]
The following table summarizes the weighted-average number of shares of common stock outstanding for basic and diluted earnings per share calculations:

[0001783180-25-000008:notes:276]
| (In millions, except per share amounts) |  | 2024 |  | 2023 |  | 2022 |  |  |
| Net earnings (loss) attributable to common shareowners |  | $ | 5,604 |  |  | $ | 1,349 |  |  | $ | 3,534 |  |  |  |
| Basic weighted-average number of shares outstanding |  | 898.2 |  |  | 837.3 |  |  | 843.4 |  |  |  |
| Stock awards and equity units (share equivalent) |  | 13.5 |  |  | 15.7 |  |  | 17.8 |  |  |  |
| Diluted weighted-average number of shares outstanding |  | 911.7 |  |  | 853.0 |  |  | 861.2 |  |  |  |
| Antidilutive shares excluded from computation of diluted earnings per share |  | 0.1 |  |  | 2.0 |  |  | 2.9 |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001783180-25-000008:notes:277]
ACQUISITIONS
During the year ended December 31, 2024, the Company acquired consolidated and minority-owned businesses. The aggregate cash paid, net of cash acquired, totaled $10.9 billion. Acquisitions are recorded using the acquisition method of accounting in accordance with ASC 805. As a result, the aggregate purchase price has been allocated to assets acquired and liabilities assumed based on the estimate of fair market value of such assets and liabilities at the date of acquisition. The excess purchase price over the estimated fair value of net assets acquired is recognized as goodwill.

[0001783180-25-000008:notes:278]
Viessmann Climate Solutions

[0001783180-25-000008:notes:279]
On January 2, 2024, the Company completed the acquisition of the VCS Business from Viessmann for total consideration of $14.2 billion. The purchase price consisted of (i) $11.2 billion in cash and (ii) 58,608,959 shares of the Company's common stock, subject to certain lock-up provisions and anti-dilution protection. The Company funded the cash portion of the purchase price with a combination of cash on hand, net proceeds from the USD Notes and Euro Notes and borrowings under the Delayed Draw Facility and the 60-day Loan.

[0001783180-25-000008:notes:280]
The VCS Business develops intelligent, integrated and sustainable technologies, including heat pumps, boilers, photovoltaic systems, home battery storage and digital solutions, primarily for residential customers in Europe. The Company believes that secular trends in these areas will drive significant, sustained future growth. In addition, the Company anticipates realizing significant operational synergies including savings through supplier rationalization and leverage, reduced manufacturing costs and lower general and administrative costs. Longer term, the Company expects to benefit from synergies related to service revenue expansion, leverage of distribution channels and cross-selling opportunities.

[0001783180-25-000008:notes:281]
The components of the purchase price are as follows:

[0001783180-25-000008:notes:282]
| (In millions) |  | January 2, 2024 |
| Cash |  | $ | 11,156 |  |
| Common shares (58,608,959 shares at $51.20 per share) |  | 3,001 |  |
| Total consideration |  | $ | 14,157 |  |

[0001783180-25-000008:notes:283]
The preliminary allocation of the purchase price is as follows:

[0001783180-25-000008:notes:284]
| (In millions) |  | Preliminary January 2, 2024 |  | Measurement Period Adjustments |  | As Adjusted January 2, 2024 |
| Cash and cash equivalents |  | $ | 394 |  |  | $ | (1) |  |  | $ | 393 |  |
| Accounts receivable |  | 408 |  |  | 5 |  |  | 413 |  |
| Inventories |  | 948 |  |  | (28) |  |  | 920 |  |
| Other current assets |  | 17 |  |  | — |  |  | 17 |  |
| Fixed assets |  | 913 |  |  | 6 |  |  | 919 |  |
| Intangible assets |  | 6,640 |  |  | 5 |  |  | 6,645 |  |
| Other assets |  | 284 |  |  | 15 |  |  | 299 |  |
| Accounts payable |  | (288) |  |  | (2) |  |  | (290) |  |
| Other liabilities, current |  | (626) |  |  | (37) |  |  | (663) |  |
| Future income tax obligations |  | (1,825) |  |  | 15 |  |  | (1,810) |  |
| Other liabilities |  | (284) |  |  | (17) |  |  | (301) |  |
| Total identifiable net assets |  | 6,581 |  |  | (39) |  |  | 6,542 |  |
| Goodwill |  | 7,576 |  |  | 31 |  |  | 7,607 |  |
| Total consideration |  | $ | 14,157 |  |  | $ | (8) |  |  | $ | 14,149 |  |

[0001783180-25-000008:notes:285]
The excess purchase price over the estimated fair value of the net identifiable assets acquired was recognized as goodwill and totaled $7.6 billion, which is not deductible for tax purposes. Accounts receivable and current liabilities were stated at their historical carrying value, which approximates fair value given the short-term nature of these assets and liabilities. The estimate of fair value for inventory and fixed assets was based on an assessment of the acquired assets' condition as well as an evaluation of the current market value of such assets.

[0001783180-25-000008:notes:286]
The Company recorded intangible assets based on its estimate of fair value which consisted of the following:

[0001783180-25-000008:notes:287]
| (In millions) |  | Estimated Useful Life (in years) |  | Intangible Assets Acquired |
| Customer relationships |  | 17 |  | $ | 4,787 |  |
| Technology |  | 10 - 20 |  | 1,051 |  |
| Trademark |  | 40 |  | 679 |  |
| Backlog |  | 1 |  | 123 |  |
| Other |  | 50 |  | 5 |  |
| Total intangible assets acquired |  |  |  | $ | 6,645 |  |

[0001783180-25-000008:notes:288]
The valuation of intangible assets was determined using an income approach methodology including the multi-period excess earnings method and the relief from royalty method. Key assumptions used in estimating future cash flows included projected short-term revenue growth rates, research and development expenses, EBITDA margins, income tax rates, discount rates, customer attrition rates, royalty rates, contributory asset charge and obsolescence rates among others. The projected future cash flows are discounted to present value using an appropriate discount rate. The Company finalized the process of allocating the purchase price and valuing the acquired assets and liabilities during the year ended December 31, 2024.

[0001783180-25-000008:notes:289]
The Company incurred $40 million of acquisition-related costs during 2024. During 2023, $80 million of acquisition-related costs were incurred. These acquisition costs are reflected within Selling, general and administrative in the Consolidated Statement of Operations.

[0001783180-25-000008:notes:290]
The assets, liabilities and results of operations of the VCS Business are consolidated in the accompanying Consolidated Financial Statements as of the date of acquisition and reported within the Company's HVAC segment.

[0001783180-25-000008:notes:291]
The following table summarizes the results of the VCS Business since the date of acquisition:

[0001783180-25-000008:notes:292]
| (In millions) | 2024 |
| Net sales | $ | 3,266 |  |
| Net earnings (loss) | (400) |  |

[0001783180-25-000008:notes:293]
The financial results of the VCS Business includes amortization of the step-up to fair value of inventory and backlog as well as intangible amortization totaling $834 million for the year ended December 31, 2024.

[0001783180-25-000008:notes:294]
Unaudited Pro Forma Financial Information

[0001783180-25-000008:notes:295]
The following unaudited pro forma financial information is presented to illustrate the estimated effects of the acquisition of the VCS Business as if the business combination had occurred on January 1, 2023:

[0001783180-25-000008:notes:296]
| (In millions) | 2024 |  | 2023 |
| Net sales | $ | 22,486 |  |  | $ | 23,342 |  |
| Net earnings (loss) | 1,272 |  |  | 1,163 |  |

[0001783180-25-000008:notes:297]
The pro forma amounts include the historical operating results of the Company and the VCS Business prior to the acquisition, with adjustments directly attributable to the acquisition including amortization of the step-up to fair value of inventory and amortization expense of acquired intangible assets. The unaudited pro forma financial information is not necessarily indicative of the results of operations that actually would have been achieved had the acquisition of the VCS Business been consummated as of the dates indicated, nor is it indicative of any future results. In addition, the unaudited pro forma financial information does not reflect the expected realization of any synergies or cost savings associated with the acquisition.

[0001783180-25-000008:notes:298]
Toshiba Carrier Corporation

[0001783180-25-000008:notes:299]
On February 6, 2022, the Company entered into a binding agreement to acquire a majority ownership interest in TCC for $920 million. TCC, a VRF and light commercial HVAC joint venture between Carrier and Toshiba Corporation, designs and manufactures flexible, energy-efficient and high-performance VRF and light commercial HVAC systems as well as commercial products, compressors and heat pumps. The acquisition included all of TCC’s advanced research and development centers and global manufacturing operations, product pipeline and the long-term use of Toshiba’s iconic brand. The acquisition was completed on August 1, 2022 and funded through the Japanese Term Loan Facility and cash on hand. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC.

[0001783180-25-000008:notes:300]
The excess purchase price over the estimated fair value of the net assets acquired was recognized as goodwill and totaled $876 million, which is not deductible for tax purposes. Accounts receivable and current liabilities were stated at their historical carrying value, which approximates fair value given the short-term nature of these assets and liabilities. The estimate of fair value for inventory and fixed assets was based on an assessment of the acquired assets' condition as well as an evaluation of the current market value of such assets. The sale agreement included several customary provisions to settle working capital and other transaction-related items as of the date of sale. During 2022, the parties finalized these amounts in accordance with the terms of the sale agreement and the Company paid an additional $41 million to Toshiba Corporation in 2023. In addition, the parties finalized amounts related to pension funding levels during 2023 which resulted in the Company receiving $12 million from Toshiba Corporation.

[0001783180-25-000008:notes:301]
The Company previously accounted for its minority ownership in TCC under the equity method of accounting. In connection with the transaction, the carrying value of the Company's previously held TCC equity investments were recognized at fair value at the date of acquisition using an income approach methodology. As a result, the Company recognized a $697 million non-cash gain within Other income (expense), net on the accompanying Consolidated Statement of Operations. In addition, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Consolidated Financial Statements as of the date of acquisition and reported within the Company's HVAC segment. The Company incurred $29 million of acquisition-related costs during 2022 which are included within Selling, general and administrative on the accompanying Consolidated Statement of Operations. The Company has not included pro forma financial information required under ASC 805 as the pro forma impact was not deemed significant.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001783180-25-000008:notes:302]
DIVESTITURES
Discontinued Operations

[0001783180-25-000008:notes:303]
In 2023, the Company announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. The announced plan to exit the Fire & Security segment represents a single disposal plan to separately divest multiple businesses over different reporting periods. Upon the CRF Business qualifying as held for sale during the year ended December 31, 2024, the components of the Fire & Security segment in aggregate met the criteria to be presented as discontinued operations in the accompanying Consolidated Statement of Operations and Consolidated Statement of Cash Flows. In addition, the assets and liabilities of the CRF Business have been reclassified to held for sale at December 31, 2023. The results of the CCR business did not meet the criteria to be presented in discontinued operations.

[0001783180-25-000008:notes:304]
The components of Discontinued operations, net of tax are as follows:

[0001783180-25-000008:notes:305]
| (In millions) | 2024 |  | 2023 |  | 2022 |
| Net sales | $ | 2,323 |  |  | $ | 3,147 |  |  | $ | 3,133 |  |
| Costs of sales | (1,390) |  |  | (1,926) |  |  | (1,966) |  |
| Research and development | (86) |  |  | (124) |  |  | (123) |  |
| Selling, general and administrative | (564) |  |  | (690) |  |  | (535) |  |
| Other income (expense), net | (584) |  |  | 26 |  |  | 22 |  |
| Gain (loss) on divestitures and deconsolidation | 5,176 |  |  | (297) |  |  | — |  |
| Interest (expense) income, net | (41) |  |  | (51) |  |  | (62) |  |
| Earnings before income taxes | 4,834 |  |  | 85 |  |  | 469 |  |
| Income tax (expense) benefit | 1,391 |  |  | (128) |  |  | (92) |  |
| Tax on divestitures and deconsolidation | (1,729) |  |  | 5 |  |  | — |  |
| Discontinued operations, net of tax | $ | 4,496 |  |  | $ | (38) |  |  | $ | 377 |  |

[0001783180-25-000008:notes:306]
The following table summarizes assets and liabilities classified as held for sale:

[0001783180-25-000008:notes:307]
|  | December 31, 2023 |
| (In millions) | Commercial Refrigeration |  | AccessSolutions |  | IndustrialFire |  | Commercial & Residential Fire |  | Total |
| Cash and cash equivalents | $ | 131 |  |  | $ | 6 |  |  | $ | 20 |  |  | $ | 163 |  |  | $ | 320 |  |
| Accounts receivable, net | 274 |  |  | 104 |  |  | 101 |  |  | 401 |  |  | 880 |  |
| Inventories, net | 84 |  |  | 31 |  |  | 65 |  |  | 394 |  |  | 574 |  |
| Other assets, current | 113 |  |  | 5 |  |  | 46 |  |  | 25 |  |  | 189 |  |
| Fixed assets, net | 78 |  |  | 13 |  |  | 22 |  |  | 133 |  |  | 246 |  |
| Intangible assets, net | — |  |  | 53 |  |  | 2 |  |  | 83 |  |  | 138 |  |
| Goodwill | 72 |  |  | 1,498 |  |  | 439 |  |  | 469 |  |  | 2,478 |  |
| Operating lease right-of-use assets | 49 |  |  | 13 |  |  | 28 |  |  | 70 |  |  | 160 |  |
| Other assets | 44 |  |  | 10 |  |  | 13 |  |  | 41 |  |  | 108 |  |
| Total assets held for sale | $ | 845 |  |  | $ | 1,733 |  |  | $ | 736 |  |  | $ | 1,779 |  |  | $ | 5,093 |  |
| Accounts payable | $ | 129 |  |  | $ | 20 |  |  | $ | 39 |  |  | $ | 259 |  |  | $ | 447 |  |
| Accrued liabilities | 204 |  |  | 74 |  |  | 77 |  |  | 239 |  |  | 594 |  |
| Long-term debt, including current portion | 8 |  |  | — |  |  | — |  |  | — |  |  | 8 |  |
| Future pension and post-retirement obligations | 203 |  |  | — |  |  | 1 |  |  | 6 |  |  | 210 |  |
| Future income tax obligations | 4 |  |  | 2 |  |  | 3 |  |  | 12 |  |  | 21 |  |
| Operating lease liabilities | 40 |  |  | 11 |  |  | 23 |  |  | 58 |  |  | 132 |  |
| Other long-term liabilities | 3 |  |  | 12 |  |  | 9 |  |  | 14 |  |  | 38 |  |
| Total liabilities held for sale | $ | 591 |  |  | $ | 119 |  |  | $ | 152 |  |  | $ | 588 |  |  | $ | 1,450 |  |

[0001783180-25-000008:notes:308]
On June 2, 2024, the Company completed the sale of Access Solutions for cash proceeds of $5.0 billion. Access Solutions, historically reported in the Company's Fire & Security segment, is a global supplier of physical security and digital access solutions supporting the hospitality, commercial, education and military markets. The Company recognized a net gain on the sale of $1.8 billion, which is included in Discontinued operations, net of tax on the accompanying Consolidated Statement of Operations.

[0001783180-25-000008:notes:309]
On July 1, 2024, the Company completed the sale of Industrial Fire for cash proceeds of $1.4 billion. Industrial Fire, historically reported in the Company's Fire & Security segment, is a leading manufacturer of a full spectrum of fire detection and suppression solutions and services in critical high-hazard environments, including oil and gas, power generation, marine and offshore facilities, automotive, data centers and aircraft hangars. The Company recognized a net gain on the sale of $319 million, which is included in Discontinued operations, net of tax on the accompanying Consolidated Statement of Operations.

[0001783180-25-000008:notes:310]
On October 1, 2024, the Company completed the sale of CCR for cash proceeds of $679 million. CCR, historically reported in the Company's Refrigeration segment, is a global supplier of turnkey solutions for commercial refrigeration systems and services, with a primary focus on serving food retail customers, cold storage facilities and warehouses. The Company recognized a gross gain on the sale of $318 million, which is included in Other income (expense), net on the accompanying Consolidated Statement of Operations. The net proceeds received are subject to working capital and other adjustments provided in the stock purchase agreement governing the sale of CCR.

[0001783180-25-000008:notes:311]
On December 2, 2024, the Company completed the sale of the CRF Business for cash proceeds of $2.9 billion. The CRF Business, historically reported in the Company's Fire & Security segment, is a leading manufacturer of fire detection and alarm solutions for both commercial and residential applications. The Company recognized a net gain on the sale of $1.4 billion, which is included in Discontinued operations, net of tax on the accompanying Consolidated Statement of Operations. The net proceeds received are subject to working capital and other adjustments provided in the stock purchase agreement governing the sale of the CRF Business.

[0001783180-25-000008:notes:312]
The following table summarizes the assets and liabilities divested as of their respective dates of sale:

[0001783180-25-000008:notes:313]
| (In millions) | AccessSolutions |  | IndustrialFire |  | Commercial Refrigeration |  | Commercial & Residential Fire |
| Cash and cash equivalents | $ | 82 |  |  | $ | 40 |  |  | $ | 121 |  |  | $ | 64 |  |
| Accounts receivable, net | 90 |  |  | 93 |  |  | 217 |  |  | 422 |  |
| Inventories, net | 43 |  |  | 73 |  |  | 99 |  |  | 408 |  |
| Other current assets | 6 |  |  | 55 |  |  | 155 |  |  | 26 |  |
| Fixed assets, net | 18 |  |  | 24 |  |  | 84 |  |  | 127 |  |
| Intangible assets, net | 53 |  |  | 2 |  |  | 10 |  |  | 81 |  |
| Goodwill | 1,467 |  |  | 452 |  |  | 72 |  |  | 449 |  |
| Operating lease right-of-use assets | 16 |  |  | 24 |  |  | 48 |  |  | 66 |  |
| Other assets | 8 |  |  | 2 |  |  | 46 |  |  | 29 |  |
| Total assets held for sale | $ | 1,783 |  |  | $ | 765 |  |  | $ | 852 |  |  | $ | 1,672 |  |
| Accounts payable | $ | 54 |  |  | $ | 43 |  |  | $ | 124 |  |  | $ | 195 |  |
| Accrued liabilities | 80 |  |  | 65 |  |  | 154 |  |  | 153 |  |
| Operating lease liabilities | 17 |  |  | 24 |  |  | 49 |  |  | 66 |  |
| Other long-term liabilities | 10 |  |  | 6 |  |  | 213 |  |  | 24 |  |
| Total liabilities held for sale | $ | 161 |  |  | $ | 138 |  |  | $ | 540 |  |  | $ | 438 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-25-000008:notes:314]
SEGMENT FINANCIAL DATA
The Company conducts its operations through two reportable operating segments: HVAC and Refrigeration. In accordance with ASC 280 - Segment Reporting, the Company’s segments maintain separate financial information for which results of operations are evaluated on a regular basis by the Company’s Chief Operating Decision Maker ("CODM") in deciding how to allocate resources and in assessing performance.

[0001783180-25-000008:notes:315]
•The HVAC segment provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-25-000008:notes:316]
•The Refrigeration segment includes transport refrigeration and monitoring products, services and digital solutions for trucks, trailers, shipping containers, intermodal and rail.

[0001783180-25-000008:notes:317]
The Corporate and Other category primarily includes corporate administrative functions such as tax, treasury, internal audit, legal and human resources. A portion of these costs and costs associated with shared service centers that provide transaction processing, accounting and other business support functions are allocated to the reportable segments. In addition, the Corporate and Other category reflects certain business activities previously reported with the Fire & Security segment that no longer met the criteria of a reportable segment. The category also includes elimination of activity between segments.

[0001783180-25-000008:notes:318]
Segment Operating profit is the measure of profit and loss that the Company’s CODM, the Chief Executive Officer (“CEO”), uses to evaluate the financial performance of the business and as the basis for resource allocation, performance reviews and compensation. In addition, it represents the measure most consistent with amounts included in the Company’s consolidated financial statements. Segment Operating profit targets are established on an annual basis and used by the CODM throughout the year to compare with actual results. Quarterly forecasts supplement annual targets and provide incremental information utilized to assess the performance of a segment. Segment Operating profit variance analysis further provides insight into segment end-markets and operational cost optimization. These results also support the CODM to manage the Company’s business portfolio and benchmarking with competitors.

[0001783180-25-000008:notes:319]
Consistent with the management approach for segment reporting, the tables below present reported Net sales and significant expense categories for each of the Company’s segments that are regularly provided to the CODM and included in is reported measure of segment profit or loss. The Company manages research and development costs on a global basis. As a result, amounts presented by segment reflect where costs are incurred rather than where the benefit is received. Due to the completion of the Company's portfolio transformation activities in 2024, the Company anticipates changes to its management reporting structure and to the information provided to its CODM beginning in 2025. As a result, the Company is reassessing its reportable segment structure to align with any changes.

[0001783180-25-000008:notes:320]
|  | For the Year Ended December 31, 2024 |
| (In millions) | HVAC |  | REF |  | Segment Total |  | Corporate & Other |  | Total |
| Net sales | $ | 19,078 |  |  | $ | 3,475 |  |  | $ | 22,553 |  |  | $ | (67) |  |  | $ | 22,486 |  |
| Cost of goods sold | (14,041) |  |  | (2,580) |  |  | (16,621) |  |  | 116 |  |  | (16,505) |  |
| Research and development | (531) |  |  | (88) |  |  | (619) |  |  | (67) |  |  | (686) |  |
| Selling, general and administrative | (2,475) |  |  | (409) |  |  | (2,884) |  |  | (313) |  |  | (3,197) |  |
| Equity method investment net earnings | 225 |  |  | 6 |  |  | 231 |  |  | — |  |  | 231 |  |
| Other income (expense), net | 52 |  |  | 311 |  |  | 363 |  |  | (46) |  |  | 317 |  |
| Operating profit | $ | 2,308 |  |  | $ | 715 |  |  | $ | 3,023 |  |  | $ | (377) |  |  | $ | 2,646 |  |

[0001783180-25-000008:notes:321]
|  | For the Year Ended December 31, 2023 |
| (In millions) | HVAC |  | REF |  | Segment Total |  | Corporate & Other |  | Total |
| Net sales | $ | 15,139 |  |  | $ | 3,818 |  |  | $ | 18,957 |  |  | $ | (6) |  |  | $ | 18,951 |  |
| Cost of goods sold | (10,992) |  |  | (2,889) |  |  | (13,881) |  |  | 92 |  |  | (13,789) |  |
| Research and development | (322) |  |  | (85) |  |  | (407) |  |  | (86) |  |  | (493) |  |
| Selling, general and administrative | (1,782) |  |  | (450) |  |  | (2,232) |  |  | (375) |  |  | (2,607) |  |
| Equity method investment net earnings | 206 |  |  | 6 |  |  | 212 |  |  | (1) |  |  | 211 |  |
| Other income (expense), net | 26 |  |  | 28 |  |  | 54 |  |  | (167) |  |  | (113) |  |
| Operating profit | $ | 2,275 |  |  | $ | 428 |  |  | $ | 2,703 |  |  | $ | (543) |  |  | $ | 2,160 |  |

[0001783180-25-000008:notes:322]
|  | For the Year Ended December 31, 2022 |
| (In millions) | HVAC |  | REF |  | Segment Total |  | Corporate & Other |  | Total |
| Net sales | $ | 13,408 |  |  | $ | 3,883 |  |  | $ | 17,291 |  |  | $ | (3) |  |  | $ | 17,288 |  |
| Cost of goods sold | (10,151) |  |  | (2,926) |  |  | (13,077) |  |  | 86 |  |  | (12,991) |  |
| Research and development | (265) |  |  | (82) |  |  | (347) |  |  | (69) |  |  | (416) |  |
| Selling, general and administrative | (1,341) |  |  | (421) |  |  | (1,762) |  |  | (215) |  |  | (1,977) |  |
| Equity method investment net earnings | 256 |  |  | 6 |  |  | 262 |  |  | — |  |  | 262 |  |
| Other income (expense), net | 703 |  |  | 22 |  |  | 725 |  |  | 1,093 |  |  | 1,818 |  |
| Operating profit | $ | 2,610 |  |  | $ | 482 |  |  | $ | 3,092 |  |  | $ | 892 |  |  | $ | 3,984 |  |

[0001783180-25-000008:notes:323]
Total assets are not presented for each segment as they are not presented to or reviewed by the CODM. Segment assets in the following table represent Accounts receivable, net and Inventories, net. These assets are regularly reviewed by management and are therefore reported in the following table as segment assets. All other remaining assets and liabilities for all periods presented are managed on a company-wide basis.

[0001783180-25-000008:notes:324]
|  | Segment Assets |  | Capital Expenditures |  | Depreciation & Amortization |
| (In millions) | 2024 |  | 2023 |  |  |  | 2024 |  | 2023 |  | 2022 |  | 2024 |  | 2023 |  | 2022 |
| HVAC | $ | 3,851 |  |  | $ | 2,899 |  |  |  |  | $ | 438 |  |  | $ | 313 |  |  | $ | 232 |  |  | $ | 1,153 |  |  | $ | 413 |  |  | $ | 256 |  |
| Refrigeration | 818 |  |  | 833 |  |  |  |  | 32 |  |  | 30 |  |  | 32 |  |  | 35 |  |  | 34 |  |  | 31 |  |
| Total Segment | 4,669 |  |  | 3,732 |  |  |  |  | 470 |  |  | 343 |  |  | 264 |  |  | 1,188 |  |  | 447 |  |  | 287 |  |
| Eliminations and other | 281 |  |  | 171 |  |  |  |  | 49 |  |  | 96 |  |  | 53 |  |  | 44 |  |  | 44 |  |  | 41 |  |
| Consolidated | $ | 4,950 |  |  | $ | 3,903 |  |  |  |  | $ | 519 |  |  | $ | 439 |  |  | $ | 317 |  |  | $ | 1,232 |  |  | $ | 491 |  |  | $ | 328 |  |
| Cash and cash equivalents | 3,969 |  |  | 9,852 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other assets, current | 972 |  |  | 728 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets held for sale | — |  |  | 5,093 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total current assets | $ | 9,891 |  |  | $ | 19,576 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001783180-25-000008:notes:325]
Geographic External Sales


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001783180-25-000008:notes:326]
As a result, the Company is reassessing its reportable segment structure to align with any changes.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-25-000008:notes:327]
RELATED PARTIES 
Equity Method Investments

[0001783180-25-000008:notes:328]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered to be related parties. The Company has 29 directly owned unconsolidated domestic and foreign affiliates as of December 31, 2024, of which 97% of such investments are in its HVAC segment. The Company periodically reviews the carrying value of its equity method investments to determine if there has been an other-than-temporary decline in fair value.

[0001783180-25-000008:notes:329]
Amounts attributable to equity method investees are as follows:

[0001783180-25-000008:notes:330]
| (In millions) | 2024 |  | 2023 |  | 2022 |
| Sales to equity method investees included in Product sales | $ | 2,956 |  |  | $ | 2,920 |  |  | $ | 2,845 |  |
| Purchases from equity method investees included in Cost of products sold | $ | 237 |  |  | $ | 214 |  |  | $ | 331 |  |

[0001783180-25-000008:notes:331]
The Company had receivables from and payables to equity method investees as follows:

[0001783180-25-000008:notes:332]
| (In millions) | 2024 |  | 2023 |
| Receivables from equity method investees included in Accounts receivable, net | $ | 363 |  |  | $ | 231 |  |
| Payables to equity method investees included in Accounts payable | $ | 32 |  |  | $ | 44 |  |

[0001783180-25-000008:notes:333]
The financial results of TCC are included in the Company's consolidated results since the acquisition date of August 1, 2022. Prior to the acquisition, the Company previously accounted for its minority ownership in TCC under the equity method of accounting. As a result, prior period results may not be comparable to the current period.

[0001783180-25-000008:notes:334]
Summarized Financial Information. Pursuant to Rule 3-10 and Rule 4-08(g) of Regulation S-X under the Securities Act, the Company presents summarized financial information of the combined accounts of its non-consolidated joint ventures accounted for by the equity method.

[0001783180-25-000008:notes:335]
Summarized unaudited financial information for equity method investments is as follows:

[0001783180-25-000008:notes:336]
| (In millions) | 2024 |  | 2023 |
| Current assets | $ | 12,823 |  |  | $ | 11,432 |  |
| Non-current assets | 2,396 |  |  | 1,834 |  |
| Total assets | 15,219 |  |  | 13,266 |  |
| Current liabilities | (11,053) |  |  | (9,296) |  |
| Non-current liabilities | (210) |  |  | (190) |  |
| Total liabilities | (11,263) |  |  | (9,486) |  |
| Total net equity of investees | $ | 3,956 |  |  | $ | 3,780 |  |

[0001783180-25-000008:notes:337]
| (In millions) | 2024 |  | 2023 |  | 2022 |
| Net sales | $ | 17,567 |  |  | $ | 16,180 |  |  | $ | 11,524 |  |
| Gross profit | $ | 3,063 |  |  | $ | 2,862 |  |  | $ | 2,274 |  |
| Income from continuing operations | $ | 700 |  |  | $ | 655 |  |  | $ | 757 |  |
| Net earnings (loss) | $ | 700 |  |  | $ | 655 |  |  | $ | 757 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-25-000008:notes:338]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability has been incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon its results of operations or financial condition.

[0001783180-25-000008:notes:339]
Environmental Matters

[0001783180-25-000008:notes:340]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to, investigatory, remediation, operating and maintenance costs and performance guarantees. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including the technology required to remediate, current laws and regulations and prior remediation experience.

[0001783180-25-000008:notes:341]
As of December 31, 2024 and 2023, the outstanding liability for environmental obligations are as follows:

[0001783180-25-000008:notes:342]
| (In millions) |  | 2024 |  | 2023 |
| Environmental reserves included in Accrued liabilities |  | $ | 25 |  |  | $ | 19 |  |
| Environmental reserves included in Other long-term liabilities |  | 185 |  |  | 199 |
| Total environmental reserves |  | $ | 210 |  |  | $ | 218 |  |

[0001783180-25-000008:notes:343]
For sites with multiple responsible parties, the Company considers its likely proportionate share of the anticipated remediation costs and the ability of other parties to fulfill their obligations in establishing a provision for these costs. Accrued environmental liabilities are not reduced by potential insurance reimbursements and are undiscounted.

[0001783180-25-000008:notes:344]
Asbestos Matters

[0001783180-25-000008:notes:345]
The Company has been named as a defendant in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-25-000008:notes:346]
The Company's asbestos liabilities and related insurance recoveries are as follows:

[0001783180-25-000008:notes:347]
| (In millions) |  | 2024 |  | 2023 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 15 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 208 |  |  | 206 |  |
| Total asbestos liabilities |  | $ | 225 |  |  | $ | 221 |  |
| Asbestos-related recoveries included in Accounts receivable, net |  | $ | 7 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 88 |  |  | 88 |  |
| Total asbestos-related recoveries |  | $ | 95 |  |  | $ | 93 |  |

[0001783180-25-000008:notes:348]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and exclude the Company's legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.

[0001783180-25-000008:notes:349]
Aqueous Film Forming Foam Litigation

[0001783180-25-000008:notes:350]
As of December 31, 2024, the Company, Kidde-Fenwal, Inc. ("KFI") and others have been named as defendants in more than 9,000 lawsuits filed in United States state or federal courts and a single case in Canada alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and damage to property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). Individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

[0001783180-25-000008:notes:351]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires. The lawsuits identified above relate to Kidde Fire Fighting, Inc., which owned the “National Foam” business that manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania (the "Pennsylvania Site"). Kidde Fire Fighting, Inc. was acquired by a UTC subsidiary in 2005 and merged into KFI in 2007. In 2013, KFI divested the AFFF businesses to an unrelated third party. The Company acquired KFI as part of the Separation in April 2020.

[0001783180-25-000008:notes:352]
The key components that contribute to AFFF's fire-extinguishing capabilities are known as fluorosurfactants. Neither the Company, nor KFI, nor any of the Company's subsidiaries involved in the AFFF litigation manufactured fluorosurfactants. Instead, the National Foam business purchased these substances from unrelated third parties for use in manufacturing AFFF. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as per- and polyfluoroalkyl substances (referred to collectively as "PFAS"), including perflourooctanesulfonic acid ("PFOS") and perflourooctanoic acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

[0001783180-25-000008:notes:353]
Plaintiffs in the MDL Proceedings have named multiple defendants, including suppliers of chemicals and raw materials used to manufacture fluorosurfactants, fluorosurfactant manufacturers and AFFF manufacturers. The defendants in the MDL Proceedings moved for summary judgment on the government contractor defense, which potentially applies to AFFF sold to or used by the U.S. government. After full briefing and oral argument, on September 16, 2022, the MDL court declined to enter summary judgment for the defendants. The defense, however, remains available at any trial in which it would apply.

[0001783180-25-000008:notes:354]
On May 14, 2023, KFI filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware (the “Bankruptcy Court”) seeking relief under chapter 11 of the Bankruptcy Code, after the Company determined that it would not provide financial support to KFI going forward other than ensuring KFI has access to services necessary for the effective operation of its business. As a result, all litigation against KFI was automatically stayed. By agreement, all AFFF-related litigation against the Company, its other subsidiaries and RTX also was stayed. On November 21, 2023, the Bankruptcy Court ordered certain parties, including the Company, to participate in mediation sessions with respect to claims that might be asserted by and against it in the bankruptcy proceedings.

[0001783180-25-000008:notes:355]
Following the conclusion of these mediation sessions in October 2024, the Company entered into a Settlement and Plan Support Agreement which contemplates that the Company will subsequently enter into three distinct settlement agreements (collectively, the “Proposed Settlement Agreements”) with KFI, the Official Committee of Unsecured Creditors appointed in KFI’s bankruptcy case (the “Committee”) and the Plaintiffs’ Executive Committee (the “MDL PEC”) appointed in the MDL Proceedings.

[0001783180-25-000008:notes:356]
The first of the Proposed Settlement Agreements relates to claims that the Company is responsible for liabilities arising from KFI’s manufacture or sale of AFFF (“Estate Claims Settlement”). Upon Bankruptcy Court approval, the Estate Claims Settlement will permanently resolve all present and future claims that the Company is responsible for any liabilities of KFI, including all liabilities arising from KFI’s manufacture and sale of AFFF. The second and third of the Proposed Settlement Agreements release a very substantial amount of current and future direct claims against the Company (the “Direct Claims Settlements”). Direct claims allege that UTC, which indirectly owned KFI’s AFFF business for eight years, engaged in conduct independent of KFI that caused harm to AFFF claimants. The Company agreed to indemnify UTC for these direct claims when it was spun-off from UTC. Upon approval by the MDL Court, the Direct Claims Settlements resolve and enjoin all current and future AFFF-related direct claims against the Company by participating public water providers and airports. Non-settling parties may still assert direct AFFF-related claims, although we expect a vast majority of public water providers and airports will participate in the Direct Claims Settlements.

[0001783180-25-000008:notes:357]
As part of the Proposed Settlement Agreements, the Company will pay $615 million in cash over five years, 100% of the net sale proceeds from its sale of KFI’s assets to Pacific Avenue Capital Partners, which are estimated to be $115 million, and contribute the right to recover proceeds under certain of its insurance policies. The Company will be entitled to receive up to $2.4 billion of proceeds from those insurance policies and will contribute the first $125 million of such proceeds as additional consideration in the Direct Claims Settlements. The Company also will be entitled to any earnouts payable to KFI under the KFI sale agreement. The Company expects insurance proceeds it receives in the future, in the aggregate, to cover the amount paid under the Proposed Settlement Agreements. As a result of the Proposed Settlement Agreements, the Company recorded a liability in the amount of $565 million during the year December 31, 2024. The amount recognized is in addition to liabilities of $50 million that the Company recorded upon the deconsolidation of KFI on May 14, 2023, as further discussed below. As of December 31, 2024, the Company has not recorded any amounts associated with expected insurance proceeds.

[0001783180-25-000008:notes:358]
The Company and KFI believe that they have meritorious defenses to the remaining AFFF claims. Given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate a range of possible loss at this time. There can be no assurance that any such future exposure will not be material in any period.

[0001783180-25-000008:notes:359]
On November 14, 2024, KFI filed the chapter 11 plan of liquidation (as may be further amended, restated, supplemented, waived, or otherwise modified from time to time, the "Chapter 11 Plan"), which incorporates the Estate Claims Settlement, provides for the treatment of the various creditor classes, and establishes wind-down provisions, among other things, and the disclosure statement for the Chapter 11 Plan (as may be further amended, restated, supplemented, waived, or otherwise modified from time to time, the "Disclosure Statement"). A hearing to approve the Disclosure Statement, its ancillary documents and establish a Chapter 11 Plan confirmation timeline in the Bankruptcy Court is expected to be held in March 2025.

[0001783180-25-000008:notes:360]
Deconsolidation Due to Bankruptcy

[0001783180-25-000008:notes:361]
As of May 14, 2023, the Company no longer controlled KFI as its activities are subject to review and oversight by the Bankruptcy Court. Therefore, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company’s Consolidated Financial Statements. Upon deconsolidation, the Company determined the fair value of its retained interest in KFI to be zero and accounted for it prospectively using the cost method. As a result of these actions, the Company recognized a net loss of $292 million in its Consolidated Statement of Operations within Discontinued operations, net of tax. In addition, the deconsolidation resulted in an investing cash outflow of $134 million in the Company's Consolidated Statement of Cash Flows within Net cash flows provided by (used in) discontinued investing activities.

[0001783180-25-000008:notes:362]
In connection with the bankruptcy filing, KFI entered into several agreements with subsidiaries of the Company to ensure they have access to services necessary for the effective operation of their business. All post-deconsolidation activity between the Company and KFI are reported as third-party transactions recorded within the Company's Consolidated Statement of Operations. Since the petition date, there were no material transactions between the Company and KFI other than a $15 million payment by the Company to KFI under the terms of a tax sharing arrangement.

[0001783180-25-000008:notes:363]
Income Taxes

[0001783180-25-000008:notes:364]
Under the TMA relating to the Separation, the Company is responsible to UTC for its share of the TCJA transition tax associated with foreign undistributed earnings as of December 31, 2017. During 2024, the Company recognized a $46 million gain associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the IRS. In addition, the Company recognized a $23 million tax benefit associated with a favorable court ruling and paid its April 2025 installment in 2024. As a result, a liability of $78 million is included within the accompanying Consolidated Balance Sheet within Other Long-Term Liabilities as of December 31, 2024. This obligation is expected to be settled in April 2026. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

[0001783180-25-000008:notes:365]
Self-Insurance

[0001783180-25-000008:notes:366]
The Company maintains self-insurance for a number of risks, including but not limited to, workers’ compensation, general liability, automobile liability, property and employee-related healthcare benefits. It has obtained insurance coverage for amounts exceeding individual and aggregate loss limits. The Company accrues for known future claims and incurred but not reported losses.

[0001783180-25-000008:notes:367]
The Company's self-insurance liabilities were as follows:

[0001783180-25-000008:notes:368]
| (In millions) | 2024 |  | 2023 |
| Self-insurance liabilities included in Accrued liabilities | $ | 173 |  |  | $ | 160 |  |
| Self-insurance liabilities included in Other long-term liabilities | 43 |  |  | 55 |
| Total self-insurance liabilities | $ | 216 |  |  | $ | 215 |  |

[0001783180-25-000008:notes:369]
The Company incurred expenses related to self-insured risks of $135 million, $139 million and $124 million for the years ended December 31, 2024, 2023 and 2022, respectively.

[0001783180-25-000008:notes:370]
Other Matters

[0001783180-25-000008:notes:371]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-25-000008:notes:372]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its competitive position, results of operations, cash flows or financial condition.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001783180-25-000008:notes:373]
SUPPLEMENTAL CASH FLOW INFORMATION 
Supplemental cash flow information was as follows:

[0001783180-25-000008:notes:374]
| (In millions) | 2024 |  | 2023 |  | 2022 |
| Interest paid, net of amounts capitalized | $ | 610 |  |  | $ | 320 |  |  | $ | 297 |  |
| Income taxes paid, net of refunds | $ | 2,126 |  |  | $ | 942 |  |  | $ | 833 |  |
| Non-cash financing activity: |  |  |  |  |  |
| Common stock dividends payable | $ | 199 |  |  | $ | 161 |  |  | $ | 158 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001783180-25-000008:notes:375]
NOTE 25: SELECTED QUARTERLY FINANCIAL INFORMATION (UNAUDITED)

[0001783180-25-000008:notes:376]
During the year ended December, 31, 2024, the components of the Fire & Security segment in aggregate met the criteria to be presented as discontinued operations. The following table presents select quarterly financial information for continuing operations:

[0001783180-25-000008:notes:377]
|  | 2024 Quarters |
| (In millions) | Q1 |  | Q2 |  | Q3 |  | Q4 |
| Net sales | $ | 5,420 |  |  | $ | 5,934 |  |  | $ | 5,984 |  |  | $ | 5,148 |  |
| Operating profit | $ | 385 |  |  | $ | 724 |  |  | $ | 763 |  |  | $ | 774 |  |
| Earnings from continuing operations attributable to common shareowners | $ | 177 |  |  | $ | 415 |  |  | $ | 564 |  |  | $ | (48) |  |
| Basic earnings per share - continuing operations | $ | 0.20 |  |  | $ | 0.46 |  |  | $ | 0.63 |  |  | $ | (0.05) |  |
| Diluted earnings per share - continuing operations | $ | 0.19 |  |  | $ | 0.45 |  |  | $ | 0.62 |  |  | $ | (0.05) |  |
|  | 2023 Quarters |
| (In millions) | Q1 |  | Q2 |  | Q3 |  | Q4 |
| Net sales | $ | 4,518 |  |  | $ | 5,182 |  |  | $ | 4,935 |  |  | $ | 4,316 |  |
| Operating profit | $ | 460 |  |  | $ | 651 |  |  | $ | 510 |  |  | $ | 539 |  |
| Earnings from continuing operations attributable to common shareowners | $ | 306 |  |  | $ | 394 |  |  | $ | 270 |  |  | $ | 417 |  |
| Basic earnings per share - continuing operations | $ | 0.37 |  |  | $ | 0.47 |  |  | $ | 0.32 |  |  | $ | 0.50 |  |
| Diluted earnings per share - continuing operations | $ | 0.36 |  |  | $ | 0.46 |  |  | $ | 0.32 |  |  | $ | 0.49 |  |
