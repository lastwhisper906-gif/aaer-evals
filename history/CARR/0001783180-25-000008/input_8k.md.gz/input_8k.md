# CARR 8-K — 0001783180-25-000006 filed 2025-02-11

## item codes, every 8-K on or before 2025-02-11

- 2025-02-11 0001783180-25-000006 — 2.02, 9.01
- 2025-01-15 0000950142-25-000133 — 5.02, 9.01
- 2024-12-20 0001783180-24-000093 — 1.01, 1.02, 2.03, 9.01
- 2024-12-03 0000950142-24-002874 — 5.02
- 2024-12-02 0000950142-24-002865 — 7.01, 9.01
- 2024-11-08 0000950142-24-002699 — 1.01, 2.03, 9.01
- 2024-10-28 0000950142-24-002640 — 8.01
- 2024-10-28 0000950142-24-002638 — 8.01
- 2024-10-24 0001783180-24-000084 — 2.02, 7.01, 9.01
- 2024-10-18 0000950142-24-002601 — 1.01
- 2024-08-15 0001140361-24-037426 — 7.01, 9.01
- 2024-07-25 0001783180-24-000075 — 2.02, 9.01
- 2024-06-21 0001783180-24-000069 — 5.02
- 2024-06-21 0000950142-24-001676 — 5.02
- 2024-06-07 0001783180-24-000062 — 5.02, 5.03, 9.01
- 2024-06-03 0000950142-24-001538 — 1.02, 7.01, 9.01
- 2024-05-17 0001783180-24-000049 — 1.01, 1.02, 2.03, 9.01
- 2024-04-25 0001783180-24-000042 — 2.02, 9.01
- 2024-04-19 0001783180-24-000035 — 5.07, 9.01
- 2024-04-19 0000950142-24-001162 — 5.07 — amendment of 0001783180-24-000035
- 2024-02-06 0001783180-24-000007 — 2.02, 9.01
- 2024-02-01 0000950142-24-000264 — 5.02
- 2024-01-02 0001140361-24-000034 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2023-12-13 0001140361-23-057415 — 1.01, 9.01
- 2023-12-08 0001140361-23-056751 — 7.01, 9.01
- 2023-11-30 0000950142-23-002884 — 1.01, 2.03, 8.01, 9.01
- 2023-11-16 0000950142-23-002788 — 8.01, 9.01
- 2023-11-13 0001140361-23-052667 — 7.01, 8.01, 9.01
- 2023-10-26 0001783180-23-000063 — 2.02, 9.01
- 2023-07-27 0001783180-23-000053 — 2.02, 9.01
- 2023-06-12 0000950142-23-001664 — 5.02
- 2023-05-25 0000950142-23-001541 — 1.01, 1.02, 2.03, 9.01
- 2023-04-26 0000950142-23-001205 — 1.01, 9.01
- 2023-04-25 0001783180-23-000036 — 2.02, 7.01, 9.01
- 2023-04-25 0000950142-23-001199 — 7.01, 8.01, 9.01
- 2023-04-21 0001783180-23-000032 — 5.07, 9.01
- 2023-02-07 0001783180-23-000010 — 2.02, 9.01
- 2022-10-27 0001783180-22-000054 — 2.02, 7.01, 9.01
- 2022-09-29 0000950142-22-002805 — 5.02, 9.01
- 2022-07-28 0001783180-22-000045 — 2.02, 9.01
- 2022-04-28 0001783180-22-000032 — 2.02, 9.01
- 2022-04-15 0001783180-22-000024 — 5.07, 9.01
- 2022-02-08 0001783180-22-000008 — 2.02, 9.01
- 2022-02-07 0000950142-22-000510 — 8.01, 9.01
- 2022-01-03 0000950142-22-000023 — 8.01, 9.01
- 2021-12-17 0001783180-21-000071 — 5.02, 7.01, 9.01
- 2021-11-23 0001783180-21-000068 — 5.03, 9.01
- 2021-10-28 0001783180-21-000062 — 2.02, 9.01
- 2021-08-27 0001783180-21-000056 — 8.01
- 2021-07-30 0001783180-21-000053 — 1.01
- 2021-07-29 0001783180-21-000049 — 2.02, 8.01, 9.01
- 2021-07-27 0000950142-21-002448 — 8.01, 9.01
- 2021-07-15 0000950142-21-002362 — 5.02, 9.01
- 2021-06-09 0000950142-21-001885 — 5.02, 9.01
- 2021-04-29 0001783180-21-000029 — 2.02, 9.01
- 2021-04-22 0001140361-21-013889 — 5.02, 9.01
- 2021-04-20 0001783180-21-000021 — 5.07, 9.01
- 2021-04-19 0000950142-21-001308 — 8.01, 9.01
- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2025-02-11

- none on or before 2025-02-11

## item 2.02 — earnings release, exhibit 99.1

[0001783180-25-000006:8k_2_02:1]
EX-99
2
a8-kerexhibit99xq42024.htm
EX-99

[0001783180-25-000006:8k_2_02:2]
Document

[0001783180-25-000006:8k_2_02:3]
Exhibit 99

[0001783180-25-000006:8k_2_02:4]
Carrier Reports Strong 2024 Results and Announces 2025 Outlook

[0001783180-25-000006:8k_2_02:5]
Fourth Quarter 2024 Highlights

[0001783180-25-000006:8k_2_02:6]
•Sales of $5.1 billion, up 19% compared to 2023 including 6% organic growth

[0001783180-25-000006:8k_2_02:7]
•GAAP EPS from continuing operations of ($0.05); adjusted EPS from continuing operations of $0.54, up 50%

[0001783180-25-000006:8k_2_02:8]
•Operating margin expansion of 250 basis points and adjusted operating margin expansion of 370 basis points

[0001783180-25-000006:8k_2_02:9]
Full Year 2024 Highlights

[0001783180-25-000006:8k_2_02:10]
•Sales of $22.5 billion, up 19% compared to 2023 including 3% organic growth

[0001783180-25-000006:8k_2_02:11]
•GAAP EPS from continuing operations of $1.22; adjusted EPS from continuing operations of $2.56 up 16%

[0001783180-25-000006:8k_2_02:12]
•Operating margin expansion of 40 basis points and adjusted operating margin expansion of 180 basis points

[0001783180-25-000006:8k_2_02:13]
•Returned ~$2.6 billion to shareholders, including ~$0.7 billion in dividends and ~$1.9 billion shares repurchased

[0001783180-25-000006:8k_2_02:14]
PALM BEACH GARDENS, Fla., February 11, 2025 – Carrier Global Corporation (NYSE:CARR), global leader in intelligent climate and energy solutions, today reported strong financial results for the fourth quarter and full year of 2024.

[0001783180-25-000006:8k_2_02:15]
“We capped a transformational year for Carrier with robust fourth quarter financial results including 6% organic growth, significant adjusted operating profit margin expansion of 370 basis points and 50% adjusted EPS growth. The quarter also marked the completion of our portfolio transformation, which resulted in total divestiture proceeds of over $10 billion,” said Carrier Chairman & CEO David Gitlin. “We successfully acquired and integrated Viessmann Climate Solutions in 2024, giving us the most comprehensive and differentiated global portfolio in our industry. We are well-positioned to deliver strong results in 2025, reinforced by our growing global commercial HVAC backlog supported by the acceleration in data centers, commitment to double-digit aftermarket growth, and leading positions across our

[0001783180-25-000006:8k_2_02:16]
1

[0001783180-25-000006:8k_2_02:17]
businesses. We remain laser focused on delivering value for our customers, employees and shareholders.”

[0001783180-25-000006:8k_2_02:18]
Fourth Quarter 2024 Results

[0001783180-25-000006:8k_2_02:19]
Carrier’s fourth quarter sales of $5.1 billion increased 19% versus the prior year, including 6% organic growth and a 13% net contribution from acquisitions and divestitures.

[0001783180-25-000006:8k_2_02:20]
Sales in the HVAC segment increased 11% organically. Americas sales were up high-teens organically driven by continued strength in Commercial and North America Residential, both up double-digits, partially offset by declines in Light Commercial. EMEA sales were flat organically, with double-digit growth in Commercial offsetting a decline in Residential and Light Commercial. Asia Pacific sales were slightly positive, driven by strength in Japan and South Asia partially offset by declines in residential light commercial in China.

[0001783180-25-000006:8k_2_02:21]
Refrigeration sales were down 6% organically, mostly driven by declines in North America truck and trailer, with flat sales growth across the remainder of the segment.

[0001783180-25-000006:8k_2_02:22]
GAAP operating profit in the quarter of $774 million was up 44% from last year, primarily due to the gain on the sale of Commercial Refrigeration. Adjusted operating profit of $678 million from continuing operations increased 65%, driven by the contribution of Viessmann Climate Solutions, the benefit of organic growth, and productivity.

[0001783180-25-000006:8k_2_02:23]
GAAP net loss from continuing operations was $48 million primarily driven by a tax charge of approximately $650 million related to an internal business re-organization which was more than offset by a related tax benefit recorded in discontinued operations. Adjusted net earnings from continuing operations was $492 million. GAAP EPS and adjusted EPS from continuing operations were ($0.05) and $0.54, respectively.

[0001783180-25-000006:8k_2_02:24]
Full-Year 2024 Results

[0001783180-25-000006:8k_2_02:25]
Carrier’s 2024 sales of $22.5 billion increased 19% compared to the prior year including organic sales growth of 3% and a 16% impact from acquisitions and divestitures. GAAP operating profit of $2.6 billion from continuing operations increased 23%. Adjusted operating profit of $3.5 billion from continuing operations increased 34%, driven by the addition of Viessmann Climate Solutions and strong operational performance.

[0001783180-25-000006:8k_2_02:26]
2

[0001783180-25-000006:8k_2_02:27]
GAAP net earnings and adjusted net earnings from continuing operations were $1.1 billion and $2.3 billion, respectively. GAAP EPS and adjusted EPS from continuing operations were $1.22 and $2.56, respectively.

[0001783180-25-000006:8k_2_02:28]
Full-Year 2025 Guidance

[0001783180-25-000006:8k_2_02:29]
The Company projects accelerated organic growth in 2025 supported by secular tailwinds, continued innovation and double-digit aftermarket growth.

[0001783180-25-000006:8k_2_02:30]
•Mid-single-digit organic* growth; Reported sales of $22.5 – $23.0 billion

[0001783180-25-000006:8k_2_02:31]
•Commercial Refrigeration divestiture represents a ~$750 million sales headwind versus prior year

[0001783180-25-000006:8k_2_02:32]
•Adjusted operating margin* of 16.5% – 17.0% up ~100 basis points compared to 2024

[0001783180-25-000006:8k_2_02:33]
•Adjusted EPS* of $2.95 – $3.05, up mid to high-teens

[0001783180-25-000006:8k_2_02:34]
•Free cash flow* of $2.4 – $2.6 billion

[0001783180-25-000006:8k_2_02:35]
•Expect to repurchase ~$3 billion in shares

[0001783180-25-000006:8k_2_02:36]
|  | 2025 Guidance |
| Sales | $22.5 – $23.0 billion ~$750 million revenue headwind from CCR exitOrganic* up MSDFX (1%)Acquisitions 0%Divestitures (3%) |
| Adjusted Operating Margin* | 16.5% – 17.0% + ~100 bps Y/Y |
| Adjusted EPS* | $2.95 – $3.05+ ~15-20% Y/Y |
| Free Cash Flow* | $2.4 – $2.6 billion |

[0001783180-25-000006:8k_2_02:37]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-25-000006:8k_2_02:38]
3

[0001783180-25-000006:8k_2_02:39]
Conference Call

[0001783180-25-000006:8k_2_02:40]
Carrier will host a webcast of its earnings conference call today, Tuesday, February 11, 2025, at 7:30 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at ir.carrier.com/news-and-events/events-and-presentations or to listen to the earnings call by phone, participants must pre-register at Carrier Earnings Call Registration. All registrants will receive dial-in information and a PIN allowing access to the live call.

[0001783180-25-000006:8k_2_02:41]
Discontinued Operations

[0001783180-25-000006:8k_2_02:42]
In 2023, the Company announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. The announced plan to exit the Fire & Security segment represented a single disposal plan to separately divest multiple businesses over different reporting periods. Upon the Commercial and Residential Fire Business qualifying as held for sale during the three months ended September 30, 2024, the components of the Fire & Security segment in aggregate met the criteria to be presented as discontinued operations in the Company’s unaudited condensed consolidated statement of operations and unaudited condensed consolidated statement of cash flows. In addition, the assets and liabilities of the Commercial and Residential Fire Business have been reclassified to held for sale at December 31, 2023. The results of the Commercial Refrigeration business did not meet the criteria to be presented in discontinued operations. Accordingly, all financial measures presented herein, including non-GAAP financial measures, are associated with Carrier's continuing operations unless specifically noted. See “Use and Definitions of Non-GAAP Financial Measures” below.

[0001783180-25-000006:8k_2_02:43]
Cautionary Statement

[0001783180-25-000006:8k_2_02:44]
This communication contains statements which, to the extent they are not statements of historical or present fact, constitute "forward-looking statements" under the securities laws. These forward-looking statements are intended to provide management's current expectations or plans for Carrier's future operating and financial performance, based on assumptions currently believed to be valid. Forward-looking statements can be identified by the use of words such as "believe," "expect," "expectations," "plans," "strategy," "prospects," "estimate," "project," "target," "anticipate," "will," "should," "see," "guidance," "outlook," "confident," "scenario" and other words of similar meaning in connection with a discussion of future operating or financial performance. Forward-looking statements may include, among other things, statements relating to future sales, earnings, cash flow, results of operations, uses of cash, share repurchases, tax rates and other measures of financial performance or potential future plans, strategies or transactions of Carrier, Carrier's plans with respect to its indebtedness and other statements that are not historical facts. All forward-looking statements involve risks, uncertainties and other factors that may cause actual results to differ materially from those expressed or implied in the forward-looking statements. For additional information on identifying factors that may cause actual results to vary materially from those stated in forward-looking statements, see Carrier's reports on Forms 10-K, 10-Q and 8-K filed with or furnished to the U.S. Securities and Exchange Commission from time to time. Any forward-looking statement speaks only as of the date on which it is made, and Carrier assumes no

[0001783180-25-000006:8k_2_02:45]
4

[0001783180-25-000006:8k_2_02:46]
obligation to update or revise such statement, whether as a result of new information, future events or otherwise, except as required by applicable law.

[0001783180-25-000006:8k_2_02:47]
About Carrier

[0001783180-25-000006:8k_2_02:48]
Carrier Global Corporation, global leader in intelligent climate and energy solutions, is committed to creating solutions that matter for people and our planet for generations to come. From the beginning, we've led in inventing new technologies and entirely new industries. Today, we continue to lead because we have a world-class, diverse workforce that puts the customer at the center of everything we do. For more information, visit corporate.carrier.com or follow Carrier on social media at @Carrier.

[0001783180-25-000006:8k_2_02:49]
Contact:

[0001783180-25-000006:8k_2_02:50]
Investor Relations

[0001783180-25-000006:8k_2_02:51]
Michael Rednor

[0001783180-25-000006:8k_2_02:52]
561-365-2020

[0001783180-25-000006:8k_2_02:53]
Investor.Relations@Carrier.com

[0001783180-25-000006:8k_2_02:54]
Media Inquiries

[0001783180-25-000006:8k_2_02:55]
Jason Shockley

[0001783180-25-000006:8k_2_02:56]
561-542-0207

[0001783180-25-000006:8k_2_02:57]
Jason.Shockley@Carrier.com

[0001783180-25-000006:8k_2_02:58]
SELECTED FINANCIAL DATA, NON-GAAP MEASURES AND DEFINITIONS

[0001783180-25-000006:8k_2_02:59]
Following are tables that present selected financial data of Carrier Global Corporation. Also included are reconciliations of non-GAAP measures to their most comparable GAAP measures.

[0001783180-25-000006:8k_2_02:60]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-25-000006:8k_2_02:61]
Carrier Global Corporation (“we” or "our") reports its financial results in accordance with accounting principles generally accepted in the United States ("GAAP"). We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables in this Appendix. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-25-000006:8k_2_02:62]
Organic sales, adjusted operating profit, adjusted operating margin, incremental margins / earnings conversion, earnings before interest, taxes and depreciation and amortization (“EBITDA”), adjusted EBITDA, adjusted net earnings (loss), adjusted earnings per share (“EPS”), adjusted interest expense, net, adjusted effective tax rate and net debt are non-GAAP financial measures and are associated with Carrier's continuing operations unless specifically noted.

[0001783180-25-000006:8k_2_02:63]
5

[0001783180-25-000006:8k_2_02:64]
Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a nonoperational nature (hereinafter referred to as “other significant items”). Adjusted operating profit represents operating profit (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted operating margin represents adjusted operating profit as a percentage of net sales (a GAAP measure). Incremental margins / earnings conversion represents the year-over-year change in adjusted operating profit divided by the year-over-year change in net sales. EBITDA represents net earnings (loss) attributable to common shareholders (a GAAP measure), adjusted for interest income and expense, income tax expense, and depreciation and amortization. Adjusted EBITDA represents EBITDA, as calculated above, excluding non-service pension benefit, non-controlling interest in subsidiaries’ earnings from operations, restructuring costs and other significant items. Adjusted net earnings (loss) represents net earnings (loss) attributable to common shareowners (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted interest expense, net represents interest expense (a GAAP measure) and interest income (a GAAP measure), net excluding other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents (a GAAP measure). For the business segments, when applicable, adjustments of operating profit and operating margins represent operating profit, excluding restructuring, amortization of acquired intangibles and other significant items.

[0001783180-25-000006:8k_2_02:65]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by operating activities (a GAAP measure) less capital expenditures. Management believes free cash flow is a useful measure of liquidity and an additional basis for assessing our ability to fund its activities, including the financing of acquisitions, debt service, repurchases of our common stock and distribution of earnings to shareowners.

[0001783180-25-000006:8k_2_02:66]
Orders are contractual commitments with customers to provide specified goods or services for an agreed upon price and may not be subject to penalty if cancelled.

[0001783180-25-000006:8k_2_02:67]
When we provide our expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted interest expense, net, adjusted effective tax rate, incremental margins/earnings conversion, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures (expected net sales, operating profit, operating margin, interest expense, effective tax rate, incremental operating margin, diluted EPS and net cash flows provided by operating activities) generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-25-000006:8k_2_02:68]
6

[0001783180-25-000006:8k_2_02:69]
Carrier Global Corporation

[0001783180-25-000006:8k_2_02:70]
Consolidated Statement of Operations

[0001783180-25-000006:8k_2_02:71]
|  | (Unaudited) |
|  | Three Months Ended December 31, |  | Year Ended December 31, |
| (In millions, except per share amounts) | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net sales |  |  |  |  |  |  |  |
| Product sales | $ | 4,530 |  |  | $ | 3,726 |  |  | $ | 19,990 |  |  | $ | 16,665 |  |
| Service sales | 618 |  |  | 590 |  |  | 2,496 |  |  | 2,286 |  |
| Total Net sales | 5,148 |  |  | 4,316 |  |  | 22,486 |  |  | 18,951 |  |
| Costs and expenses |  |  |  |  |  |  |  |
| Cost of products sold | (3,335) |  |  | (2,733) |  |  | (14,580) |  |  | (12,002) |  |
| Cost of services sold | (469) |  |  | (466) |  |  | (1,925) |  |  | (1,787) |  |
| Research and development | (162) |  |  | (138) |  |  | (686) |  |  | (493) |  |
| Selling, general and administrative | (803) |  |  | (737) |  |  | (3,197) |  |  | (2,607) |  |
| Total Costs and expenses | (4,769) |  |  | (4,074) |  |  | (20,388) |  |  | (16,889) |  |
| Equity method investment net earnings | 44 |  |  | 40 |  |  | 231 |  |  | 211 |  |
| Other income (expense), net | 351 |  |  | 257 |  |  | 317 |  |  | (113) |  |
| Operating profit | 774 |  |  | 539 |  |  | 2,646 |  |  | 2,160 |  |
| Non-service pension benefit (expense) | — |  |  | (1) |  |  | (1) |  |  | (1) |  |
| Interest (expense) income, net | (81) |  |  | (34) |  |  | (371) |  |  | (160) |  |
| Earnings before income taxes | 693 |  |  | 504 |  |  | 2,274 |  |  | 1,999 |  |
| Income tax (expense) benefit | (723) |  |  | (68) |  |  | (1,062) |  |  | (521) |  |
| Earnings from continuing operations | (30) |  |  | 436 |  |  | 1,212 |  |  | 1,478 |  |
| Discontinued operations, net of tax | 2,599 |  |  | 3 |  |  | 4,496 |  |  | (38) |  |
| Net earnings (loss) | $ | 2,569 |  |  | $ | 439 |  |  | $ | 5,708 |  |  | $ | 1,440 |  |
| Less: Non-controlling interest in subsidiaries' | 18 |  |  | 19 |  |  | 104 |  |  | 91 |  |
| Net earnings (loss) attributable to common shareowners | 2,551 |  |  | 420 |  |  | 5,604 |  |  | 1,349 |  |
| Amounts attributable to common shareowners: |  |  |  |  |  |  |  |
| Continuing operations | (48) |  |  | 417 |  |  | 1,108 |  |  | 1,387 |  |
| Discontinued operations | 2,599 |  |  | 3 |  |  | 4,496 |  |  | (38) |  |
| Net earnings (loss) attributable to common shareowners | 2,551 |  |  | 420 |  |  | 5,604 |  |  | 1,349 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |
| Continuing operations | $ | (0.05) |  |  | $ | 0.50 |  |  | $ | 1.23 |  |  | $ | 1.66 |  |
| Discontinued operations | 2.92 |  |  | — |  |  | 5.01 |  |  | (0.05) |  |
| Net earnings (loss) | $ | 2.87 |  |  | $ | 0.50 |  |  | $ | 6.24 |  |  | $ | 1.61 |  |
| Diluted: |  |  |  |  |  |  |  |
| Continuing operations | $ | (0.05) |  |  | $ | 0.49 |  |  | $ | 1.22 |  |  | $ | 1.63 |  |
| Discontinued operations | 2.87 |  |  | — |  |  | 4.93 |  |  | (0.05) |  |
| Net earnings (loss) | $ | 2.82 |  |  | $ | 0.49 |  |  | $ | 6.15 |  |  | $ | 1.58 |  |
| Weighted-average number of shares outstanding |  |  |  |  |  |  |  |
| Basic | 890.1 |  | 839.6 |  | 898.2 |  | 837.3 |
| Diluted | 903.4 |  | 854.2 |  | 911.7 |  | 853.0 |

[0001783180-25-000006:8k_2_02:72]
7

[0001783180-25-000006:8k_2_02:73]
Carrier Global Corporation

[0001783180-25-000006:8k_2_02:74]
Consolidated Balance Sheet

[0001783180-25-000006:8k_2_02:75]
|  | (Unaudited) |
|  | As of December 31, |
| (In millions) | 2024 |  | 2023 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 3,969 |  |  | $ | 9,852 |  |
| Accounts receivable, net | 2,651 |  |  | 2,080 |  |
| Inventories, net | 2,299 |  |  | 1,823 |  |
| Assets held for sale | — |  |  | 5,093 |  |
| Other assets, current | 972 |  |  | 728 |  |
| Total current assets | 9,891 |  |  | 19,576 |  |
| Future income tax benefits | 1,131 |  |  | 718 |  |
| Fixed assets, net | 2,999 |  |  | 2,160 |  |
| Operating lease right-of-use assets | 554 |  |  | 421 |  |
| Intangible assets, net | 6,432 |  |  | 945 |  |
| Goodwill | 14,601 |  |  | 7,520 |  |
| Pension and post-retirement assets | 43 |  |  | 32 |  |
| Equity method investments | 1,194 |  |  | 1,140 |  |
| Other assets | 558 |  |  | 310 |  |
| Total Assets | $ | 37,403 |  |  | $ | 32,822 |  |
| Liabilities and Equity |  |  |  |
| Accounts payable | $ | 2,458 |  |  | $ | 2,483 |  |
| Accrued liabilities | 4,182 |  |  | 2,997 |  |
| Liabilities held for sale | — |  |  | 1,450 |  |
| Current portion of long-term debt | 1,252 |  |  | 51 |  |
| Total current liabilities | 7,892 |  |  | 6,981 |  |
| Long-term debt | 11,026 |  |  | 14,242 |  |
| Future pension and post-retirement obligations | 214 |  |  | 149 |  |
| Future income tax obligations | 2,015 |  |  | 523 |  |
| Operating lease liabilities | 432 |  |  | 333 |  |
| Other long-term liabilities | 1,429 |  |  | 1,589 |  |
| Total Liabilities | 23,008 |  |  | 23,817 |  |
| Equity |  |  |  |
| Common stock, par value $0.01; 4,000,000,000 shares authorized; 948,068,772 and 883,068,393 shares issued; 878,337,677 and 839,910,275 outstanding as of December 31, 2024 and 2023, respectively | 9 |  |  | 9 |  |
| Treasury stock | (3,915) |  |  | (1,972) |  |
| Additional paid-in capital | 8,610 |  |  | 5,535 |  |
| Retained earnings | 11,483 |  |  | 6,591 |  |
| Accumulated other comprehensive loss | (2,106) |  |  | (1,486) |  |
| Non-controlling interest | 314 |  |  | 328 |  |
| Total Equity | 14,395 |  |  | 9,005 |  |
| Total Liabilities and Equity | $ | 37,403 |  |  | $ | 32,822 |  |

[0001783180-25-000006:8k_2_02:76]
8

[0001783180-25-000006:8k_2_02:77]
Carrier Global Corporation

[0001783180-25-000006:8k_2_02:78]
Consolidated Statement of Cash Flows

[0001783180-25-000006:8k_2_02:79]
|  |  |  |  | (Unaudited) |
|  |  | Year Ended December 31, |
| (In millions) |  |  |  | 2024 |  | 2023 |
| Operating Activities |  |  |  |  |  |  |
| Net earnings (loss) |  |  |  | $ | 5,708 |  |  | $ | 1,440 |  |
| Discontinued operations, net of tax |  |  |  | (4,496) |  |  | 38 |  |
| Adjustments for non-cash items, net: |  |  |  |  |  |  |
| Depreciation and amortization |  |  |  | 1,232 |  |  | 491 |  |
| Deferred income tax provision |  |  |  | (352) |  |  | (243) |  |
| Stock-based compensation cost |  |  |  | 86 |  |  | 71 |  |
| Equity method investment net earnings |  |  |  | (231) |  |  | (211) |  |
| (Gain) loss on extinguishment of debt |  |  |  | (82) |  |  | — |  |
| (Gain) loss on sale of investments / deconsolidation |  |  |  | (322) |  |  | (19) |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |
| Accounts receivable, net |  |  |  | (40) |  |  | (161) |  |
| Inventories, net |  |  |  | 292 |  |  | 123 |  |
| Accounts payable and accrued liabilities |  |  |  | 87 |  |  | 541 |  |
| Distributions from equity method investments |  |  |  | 46 |  |  | 129 |  |
| Other operating activities, net |  |  |  | (357) |  |  | 53 |  |
| Net cash flows provided by (used in) continuing operating activities |  |  |  | 1,571 |  |  | 2,252 |  |
| Net cash flows provided by (used in) discontinued operating activities |  |  |  | (1,008) |  |  | 355 |  |
| Net cash flows provided by (used in) operating activities |  |  |  | 563 |  |  | 2,607 |  |
| Investing Activities |  |  |  |  |  |  |
| Capital expenditures |  |  |  | (519) |  |  | (439) |  |
| Investment in businesses, net of cash acquired |  |  |  | (10,890) |  |  | (84) |  |
| Dispositions of businesses |  |  |  | 634 |  |  | 54 |  |
| Settlement of derivative contracts, net |  |  |  | (264) |  |  | (50) |  |
| Other investing activities, net |  |  |  | 14 |  |  | 15 |  |
| Net cash flows provided by (used in) continuing investing activities |  |  |  | (11,025) |  |  | (504) |  |
| Net cash flows provided by (used in) discontinued investing activities |  |  |  | 9,000 |  |  | (156) |  |
| Net cash flows provided by (used in) investing activities |  |  |  | (2,025) |  |  | (660) |  |
| Financing Activities |  |  |  |  |  |  |
| (Decrease) increase in short-term borrowings, net |  |  |  | 50 |  |  | (5) |  |
| Issuance of long-term debt |  |  |  | 3,412 |  |  | 5,609 |  |
| Repayment of long-term debt |  |  |  | (5,345) |  |  | (111) |  |
| Repurchases of common stock |  |  |  | (1,944) |  |  | (62) |  |
| Dividends paid on common stock |  |  |  | (670) |  |  | (620) |  |
| Dividends paid to non-controlling interest |  |  |  | (84) |  |  | (58) |  |
| Other financing activities, net |  |  |  | (30) |  |  | (121) |  |
| Net cash flows provided by (used in) continuing financing activities |  |  |  | (4,611) |  |  | 4,632 |  |
| Net cash flows provided by (used in) discontinued financing activities |  |  |  | (25) |  |  | (20) |  |
| Net cash flows provided by (used in) financing activities |  |  |  | (4,636) |  |  | 4,612 |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  |  | (103) |  |  | 88 |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash, including cash classified in current assets held for sale |  |  |  | (6,201) |  |  | 6,647 |  |
| Less: Change in cash balances classified as assets held for sale |  |  |  | (320) |  |  | 97 |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  |  |  | (5,881) |  |  | 6,550 |  |
| Cash, cash equivalents and restricted cash, beginning of period |  |  |  | 9,853 |  |  | 3,303 |  |
| Cash, cash equivalents and restricted cash, end of period |  |  |  | 3,972 |  |  | 9,853 |  |
| Less: restricted cash |  |  |  | 3 |  |  | 1 |  |
| Cash and cash equivalents, end of period |  |  |  | $ | 3,969 |  |  | $ | 9,852 |  |

[0001783180-25-000006:8k_2_02:80]
9

[0001783180-25-000006:8k_2_02:81]
Carrier Global Corporation

[0001783180-25-000006:8k_2_02:82]
Segment Net Sales and Operating Profit

[0001783180-25-000006:8k_2_02:83]
|  | (Unaudited) |
|  | Three Months Ended December 31, |  | Year Ended December 31, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| (In millions) | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 4,509 |  | $ | 4,509 |  | $ | 3,293 |  | $ | 3,293 |  | $ | 19,078 |  | $ | 19,078 |  | $ | 15,139 |  | $ | 15,139 |
| Refrigeration | 680 |  | 680 |  | 1,024 |  | 1,024 |  | 3,475 |  | 3,475 |  | 3,818 |  | 3,818 |
| Segment sales | 5,189 |  | 5,189 |  | 4,317 |  | 4,317 |  | 22,553 |  | 22,553 |  | 18,957 |  | 18,957 |
| Eliminations and other | (41) |  | (41) |  | (1) |  | (1) |  | (67) |  | (67) |  | (6) |  | (6) |
| Net sales | $ | 5,148 |  | $ | 5,148 |  | $ | 4,316 |  | $ | 4,316 |  | $ | 22,486 |  | $ | 22,486 |  | $ | 18,951 |  | $ | 18,951 |
| Operating profit |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 451 |  | $ | 658 |  | $ | 335 |  | $ | 397 |  | $ | 2,308 |  | $ | 3,370 |  | $ | 2,275 |  | $ | 2,511 |
| Refrigeration | 396 |  | 82 |  | 101 |  | 108 |  | 715 |  | 416 |  | 428 |  | 449 |
| Segment operating profit | 847 |  | 740 |  | 436 |  | 505 |  | 3,023 |  | 3,786 |  | 2,703 |  | 2,960 |
| Eliminations and other | (11) |  | (4) |  | 224 |  | (38) |  | (95) |  | (42) |  | (200) |  | (91) |
| General corporate expenses | (62) |  | (58) |  | (121) |  | (56) |  | (282) |  | (202) |  | (343) |  | (220) |
| Operating profit | $ | 774 |  | $ | 678 |  | $ | 539 |  | $ | 411 |  | $ | 2,646 |  | $ | 3,542 |  | $ | 2,160 |  | $ | 2,649 |
| Operating margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | 10.0 | % |  | 14.6 | % |  | 10.2 | % |  | 12.1 | % |  | 12.1 | % |  | 17.7 | % |  | 15.0 | % |  | 16.6 | % |
| Refrigeration | 58.2 | % |  | 12.1 | % |  | 9.9 | % |  | 10.5 | % |  | 20.6 | % |  | 12.0 | % |  | 11.2 | % |  | 11.8 | % |
| Total Carrier | 15.0 | % |  | 13.2 | % |  | 12.5 | % |  | 9.5 | % |  | 11.8 | % |  | 15.8 | % |  | 11.4 | % |  | 14.0 | % |

[0001783180-25-000006:8k_2_02:84]
10

[0001783180-25-000006:8k_2_02:85]
Carrier Global Corporation

[0001783180-25-000006:8k_2_02:86]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-25-000006:8k_2_02:87]
Operating Profit

[0001783180-25-000006:8k_2_02:88]
|  | (Unaudited) |
|  | Three Months Ended December 31, 2024 |
| (In millions) | HVAC |  | Refrigeration |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 4,509 |  |  | $ | 680 |  |  | $ | (41) |  |  | $ | — |  |  | $ | 5,148 |  |
| Segment operating profit | $ | 451 |  |  | $ | 396 |  |  | $ | (11) |  |  | $ | (62) |  |  | $ | 774 |  |
| Reported operating margin | 10.0 | % |  | 58.2 | % |  |  |  |  |  | 15.0 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 1 |  |  | $ | 3 |  |  | $ | 7 |  |  | $ | — |  |  | $ | 11 |  |
| Amortization of acquired intangibles | 172 |  |  | — |  |  | — |  |  | — |  |  | 172 |  |
| Acquisition step-up amortization (1) | 30 |  |  | 1 |  |  | — |  |  | — |  |  | 31 |  |
| Acquisition/divestiture-related costs | 4 |  |  | — |  |  | — |  |  | 4 |  |  | 8 |  |
| CCR gain | — |  |  | (318) |  |  | — |  |  | — |  |  | (318) |  |
| Total adjustments to operating profit | $ | 207 |  |  | $ | (314) |  |  | $ | 7 |  |  | $ | 4 |  |  | $ | (96) |  |
| Adjusted operating profit | $ | 658 |  |  | $ | 82 |  |  | $ | (4) |  |  | $ | (58) |  |  | $ | 678 |  |
| Adjusted operating margin | 14.6 | % |  | 12.1 | % |  |  |  |  |  | 13.2 | % |

[0001783180-25-000006:8k_2_02:89]
|  | (Unaudited) |
|  | Three Months Ended December 31, 2023 |
| (In millions) | HVAC |  | Refrigeration |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 3,293 |  |  | $ | 1,024 |  |  | $ | (1) |  |  | $ | — |  |  | $ | 4,316 |  |
| Segment operating profit | $ | 335 |  |  | $ | 101 |  |  | $ | 224 |  |  | $ | (121) |  |  | $ | 539 |  |
| Reported operating margin | 10.2 | % |  | 9.9 | % |  |  |  |  |  | 12.5 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 17 |  |  | $ | 7 |  |  | $ | 8 |  |  | $ | — |  |  | $ | 32 |  |
| Amortization of acquired intangibles | 35 |  |  | — |  |  | — |  |  | — |  |  | 35 |  |
| Acquisition step-up amortization (1) | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |
| Acquisition/divestiture-related costs | — |  |  | — |  |  | — |  |  | 65 |  |  | 65 |  |
| Bridge loan financing costs | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Viessmann-related hedges | — |  |  | — |  |  | (272) |  |  | — |  |  | (272) |  |
| Total adjustments to operating profit | $ | 62 |  |  | $ | 7 |  |  | $ | (262) |  |  | $ | 65 |  |  | $ | (128) |  |
| Adjusted operating profit | $ | 397 |  |  | $ | 108 |  |  | $ | (38) |  |  | $ | (56) |  |  | $ | 411 |  |
| Adjusted operating margin | 12.1 | % |  | 10.5 | % |  |  |  |  |  | 9.5 | % |

[0001783180-25-000006:8k_2_02:90]
(1)  Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-25-000006:8k_2_02:91]
11

[0001783180-25-000006:8k_2_02:92]
Carrier Global Corporation

[0001783180-25-000006:8k_2_02:93]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-25-000006:8k_2_02:94]
Operating Profit

[0001783180-25-000006:8k_2_02:95]
|  | (Unaudited) |
|  | Year Ended December 31, 2024 |
| (In millions) | HVAC |  | Refrigeration |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 19,078 |  |  | $ | 3,475 |  |  | $ | (67) |  |  | $ | — |  |  | $ | 22,486 |  |
| Segment operating profit | $ | 2,308 |  |  | $ | 715 |  |  | $ | (95) |  |  | $ | (282) |  |  | $ | 2,646 |  |
| Reported operating margin | 12.1 | % |  | 20.6 | % |  |  |  |  |  | 11.8 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 87 |  |  | $ | 8 |  |  | $ | 13 |  |  | $ | — |  |  | $ | 108 |  |
| Amortization of acquired intangibles | 689 |  |  | — |  |  | — |  |  | — |  |  | 689 |  |
| Acquisition step-up amortization (1) | 281 |  |  | 1 |  |  | — |  |  | — |  |  | 282 |  |
| Acquisition/divestiture-related costs | 5 |  |  | 10 |  |  | — |  |  | 80 |  |  | 95 |  |
| CCR gain | — |  |  | (318) |  |  | — |  |  | — |  |  | (318) |  |
| Viessmann-related hedges | — |  |  | — |  |  | 86 |  |  | — |  |  | 86 |  |
| Gain on liability adjustment (2) | — |  |  | — |  |  | (46) |  |  | — |  |  | (46) |  |
| Total adjustments to operating profit | $ | 1,062 |  |  | $ | (299) |  |  | $ | 53 |  |  | $ | 80 |  |  | $ | 896 |  |
| Adjusted operating profit | $ | 3,370 |  |  | $ | 416 |  |  | $ | (42) |  |  | $ | (202) |  |  | $ | 3,542 |  |
| Adjusted operating margin | 17.7 | % |  | 12.0 | % |  |  |  |  |  | 15.8 | % |

[0001783180-25-000006:8k_2_02:96]
|  | (Unaudited) |
|  | Year Ended December 31, 2023 |
| (In millions) | HVAC |  | Refrigeration |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 15,139 |  |  | $ | 3,818 |  |  | $ | (6) |  |  | $ | — |  |  | $ | 18,951 |  |
| Segment operating profit | $ | 2,275 |  |  | $ | 428 |  |  | $ | (200) |  |  | $ | (343) |  |  | $ | 2,160 |  |
| Reported operating margin | 15.0 | % |  | 11.2 | % |  |  |  |  |  | 11.4 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 44 |  |  | $ | 21 |  |  | $ | 10 |  |  | $ | — |  |  | $ | 75 |  |
| Amortization of acquired intangibles | 143 |  |  | — |  |  | — |  |  | — |  |  | 143 |  |
| Acquisition step-up amortization (1) | 41 |  |  | — |  |  | — |  |  | — |  |  | 41 |  |
| Acquisition/divestiture-related costs | — |  |  | — |  |  | — |  |  | 123 |  |  | 123 |  |
| Bridge loan financing costs | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| TCC acquisition-related gain (3) | 8 |  |  | — |  |  | — |  |  | — |  |  | 8 |  |
| Viessmann-related hedges | — |  |  | — |  |  | 96 |  |  | — |  |  | 96 |  |
| Total adjustments to operating profit | $ | 236 |  |  | $ | 21 |  |  | $ | 109 |  |  | $ | 123 |  |  | $ | 489 |  |
| Adjusted operating profit | $ | 2,511 |  |  | $ | 449 |  |  | $ | (91) |  |  | $ | (220) |  |  | $ | 2,649 |  |
| Adjusted operating margin | 16.6 | % |  | 11.8 | % |  |  |  |  |  | 14.0 | % |

[0001783180-25-000006:8k_2_02:97]
(1)  Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-25-000006:8k_2_02:98]
(2) Gain associated with an adjustment to our tax-related liability owed to UTC.

[0001783180-25-000006:8k_2_02:99]
(3)  The carrying value of our previously held TCC equity investments were recognized at fair value and subsequently adjusted.

[0001783180-25-000006:8k_2_02:100]
Carrier Global Corporation

[0001783180-25-000006:8k_2_02:101]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-25-000006:8k_2_02:102]
Net Earnings (Loss), Earnings Per Share, and Effective Tax Rate

[0001783180-25-000006:8k_2_02:103]
|  | (Unaudited) |
|  | Three Months Ended December 31, 2024 |  | Year Ended December 31, 2024 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,148 |  |  | $ | — |  |  | $ | 5,148 |  |  | $ | 22,486 |  |  | $ | — |  |  | $ | 22,486 |  |
| Operating profit | $ | 774 |  |  | (96) |  | a | $ | 678 |  |  | $ | 2,646 |  |  | 896 |  | a | $ | 3,542 |  |
| Operating margin | 15.0 | % |  |  |  | 13.2 | % |  | 11.8 | % |  |  |  | 15.8 | % |
| Earnings before income taxes | $ | 693 |  |  | (87) |  | a,b | $ | 606 |  |  | $ | 2,274 |  |  | 831 |  | a,b | $ | 3,105 |  |
| Income tax (expense) benefit | $ | (723) |  |  | 627 |  | c | $ | (96) |  |  | $ | (1,062) |  |  | 400 |  | c | $ | (662) |  |
| Effective tax rate | 104.3 | % |  |  |  | 15.8 | % |  | 46.7 | % |  |  |  | 21.3 | % |
| Earnings from continuing operations attributable to common shareowners | $ | (48) |  |  | $ | 540 |  |  | $ | 492 |  |  | $ | 1,108 |  |  | $ | 1,231 |  |  | $ | 2,339 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 11 |  | a |  |  |  |  | $ | 108 |  | a |  |
| Amortization of acquired intangibles |  |  | 172 |  | a |  |  |  |  | 689 |  | a |  |
| Acquisition step-up amortization (1) |  |  | 31 |  | a |  |  |  |  | 282 |  | a |  |
| Acquisition/divestiture-related costs |  |  | 8 |  | a |  |  |  |  | 95 |  | a |  |
| CCR gain |  |  | (318) |  | a |  |  |  |  | (318) |  | a |  |
| Viessmann-related hedges |  |  | — |  | a |  |  |  |  | 86 |  | a |  |
| Gain on liability adjustment (2) |  |  | — |  | a |  |  |  |  | (46) |  | a |  |
| Debt extinguishment (gain) |  |  | — |  | b |  |  |  |  | (97) |  | b |  |
| Debt prepayment costs |  |  | 9 |  | b |  |  |  |  | 32 |  | b |  |
| Total adjustments |  |  | $ | (87) |  |  |  |  |  |  | $ | 831 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (35) |  |  |  |  |  |  | $ | (262) |  |  |  |
| Tax specific adjustments (3) |  |  | 662 |  |  |  |  |  |  | 662 |  |  |  |
| Total tax adjustments |  |  | $ | 627 |  | c |  |  |  |  | $ | 400 |  | c |  |
| Diluted shares outstanding | 903.4 |  |  |  |  | 903.4 |  |  | 911.7 |  |  |  |  | 911.7 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | (0.05) |  |  |  |  | $ | 0.54 |  |  | $ | 1.22 |  |  |  |  | $ | 2.56 |  |

[0001783180-25-000006:8k_2_02:104]
(1) Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-25-000006:8k_2_02:105]
(2) Gain associated with an adjustment to our tax-related liability owed to UTC.

[0001783180-25-000006:8k_2_02:106]
(3) Tax expense associated with the integration of the Viessmann and Carrier legal entity structure.

[0001783180-25-000006:8k_2_02:107]
13

[0001783180-25-000006:8k_2_02:108]
Carrier Global Corporation

[0001783180-25-000006:8k_2_02:109]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-25-000006:8k_2_02:110]
Net Earnings (Loss), Earnings Per Share, and Effective Tax Rate

[0001783180-25-000006:8k_2_02:111]
|  | (Unaudited) |
|  | Three Months Ended December 31, 2023 |  | Year Ended December 31, 2023 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 4,316 |  |  | $ | — |  |  | $ | 4,316 |  |  | $ | 18,951 |  |  | $ | — |  |  | $ | 18,951 |  |
| Operating profit | $ | 539 |  |  | (128) |  | a | $ | 411 |  |  | $ | 2,160 |  |  | 489 |  | a | $ | 2,649 |  |
| Operating margin | 12.5 | % |  |  |  | 9.5 | % |  | 11.4 | % |  |  |  | 14.0 | % |
| Earnings before income taxes | $ | 504 |  |  | (111) |  | a,b | $ | 393 |  |  | $ | 1,999 |  |  | 538 |  | a,b | $ | 2,537 |  |
| Income tax (expense) benefit | $ | (68) |  |  | (3) |  | c | $ | (71) |  |  | $ | (521) |  |  | (47) |  | c | $ | (568) |  |
| Effective tax rate | 13.5 | % |  |  |  | 18.1 | % |  | 26.1 | % |  |  |  | 22.4 | % |
| Earnings from continuing operations attributable to common shareowners | $ | 417 |  |  | $ | (114) |  |  | $ | 303 |  |  | $ | 1,387 |  |  | $ | 491 |  |  | $ | 1,878 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 32 |  | a |  |  |  |  | $ | 75 |  | a |  |
| Amortization of acquired intangibles |  |  | 35 |  | a |  |  |  |  | 143 |  | a |  |
| Acquisition step-up amortization (1) |  |  | 10 |  | a |  |  |  |  | 41 |  | a |  |
| Acquisition/divestiture-related costs |  |  | 65 |  | a |  |  |  |  | 123 |  | a |  |
| Viessmann-related hedges |  |  | (272) |  | a |  |  |  |  | 96 |  | a |  |
| TCC acquisition-related gain (2) |  |  | — |  | a |  |  |  |  | 8 |  | a |  |
| Bridge loan financing costs (3) |  |  | 19 |  | a,b |  |  |  |  | 52 |  | a,b |  |
| Total adjustments |  |  | $ | (111) |  |  |  |  |  |  | $ | 538 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (20) |  |  |  |  |  |  | $ | (83) |  |  |  |
| Tax specific adjustments |  |  | 17 |  |  |  |  |  |  | 36 |  |  |  |
| Total tax adjustments |  |  | $ | (3) |  | c |  |  |  |  | $ | (47) |  | c |  |
| Diluted shares outstanding | 854.2 |  |  |  |  | 854.2 |  |  | 853.0 |  |  |  |  | 853.0 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.49 |  |  |  |  | $ | 0.36 |  |  | $ | 1.63 |  |  |  |  | $ | 2.20 |  |

[0001783180-25-000006:8k_2_02:112]
(1) Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-25-000006:8k_2_02:113]
(2)  The carrying value of our previously held TCC equity investments were recognized at fair value and subsequently adjusted.

[0001783180-25-000006:8k_2_02:114]
(3)  Includes commitment fees recognized in Operating profit.

[0001783180-25-000006:8k_2_02:115]
14

[0001783180-25-000006:8k_2_02:116]
Carrier Global Corporation

[0001783180-25-000006:8k_2_02:117]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-25-000006:8k_2_02:118]
Components of Changes in Net Sales

[0001783180-25-000006:8k_2_02:119]
Three Months Ended December 31, 2024 Compared with Three Months Ended December 31, 2023

[0001783180-25-000006:8k_2_02:120]
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 11% |  | —% |  | 26% |  | —% |  | 37% |
| Refrigeration | (6)% |  | —% |  | (27)% |  | —% |  | (33)% |
| Consolidated | 6% |  | —% |  | 13% |  | —% |  | 19% |

[0001783180-25-000006:8k_2_02:121]
Year Ended December 31, 2024 Compared with Year Ended December 31, 2023

[0001783180-25-000006:8k_2_02:122]
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 5% |  | —% |  | 21% |  | —% |  | 26% |
| Refrigeration | (1)% |  | —% |  | (8)% |  | —% |  | (9)% |
| Consolidated | 3% |  | —% |  | 16% |  | —% |  | 19% |

[0001783180-25-000006:8k_2_02:123]
Free Cash Flow Reconciliation

[0001783180-25-000006:8k_2_02:124]
|  |  | (Unaudited) |
|  |  | Year Ended December 31, |
| (In millions) |  | 2024 |  | 2023 |
| Net cash flows provided by operating activities |  | $ | 563 |  |  | $ | 2,607 |  |
| Less: Capital expenditures - continuing operations |  | (519) |  |  | (439) |  |
| Less: Capital expenditures - discontinued operations |  | (14) |  |  | (30) |  |
| Free cash flow |  | $ | 30 |  |  | $ | 2,138 |  |

[0001783180-25-000006:8k_2_02:125]
Net Debt Reconciliation

[0001783180-25-000006:8k_2_02:126]
|  |  | (Unaudited) |
|  |  | As of December 31, |
| (In millions) |  | 2024 |  | 2023 |
| Long-term debt |  | $ | 11,026 |  |  | $ | 14,242 |  |
| Current portion of long-term debt |  | 1,252 |  |  | 51 |  |
| Less: Cash and cash equivalents |  | 3,969 |  |  | 9,852 |  |
| Net debt |  | $ | 8,309 |  |  | $ | 4,441 |  |

[0001783180-25-000006:8k_2_02:127]
15

[0001783180-25-000006:8k_2_02:128]
Carrier Global Corporation

[0001783180-25-000006:8k_2_02:129]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-25-000006:8k_2_02:130]
Discontinued operations, net of tax Reconciliation

[0001783180-25-000006:8k_2_02:131]
|  |  | (Unaudited) |
|  |  | Year Ended December 31, |
| (In millions, except per share amounts) |  | 2024 |
| Discontinued operations, net of tax |  | $ | 4,496 |  |
| Summary of adjustments, net of tax: |  |  |
| Divestiture-related costs |  | $ | 154 |  |
| Restructuring |  | 15 |  |
| Gain on sale of discontinued businesses |  | (5,176) |  |
| AFFF legal reserve |  | 565 |  |
| Tax specific adjustments |  | 250 |  |
| Total adjustments |  | $ | (4,192) |  |
| Adjusted Discontinued operations, net of tax |  | $ | 304 |  |
| Adjusted diluted earnings per share |  | $ | 0.34 |  |

[0001783180-25-000006:8k_2_02:132]
Diluted EPS Reconciliation - Adjusted

[0001783180-25-000006:8k_2_02:133]
|  |  | (Unaudited) |
|  |  | Year Ended December 31, |
|  |  | 2024 |
| Continuing operations |  | $ | 2.56 |  |
| Discontinued operations |  | 0.34 |  |
| Total |  | $ | 2.90 |  |

[0001783180-25-000006:8k_2_02:134]
16
