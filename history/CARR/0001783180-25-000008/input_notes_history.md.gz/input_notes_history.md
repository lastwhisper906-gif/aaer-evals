# CARR note change history — 0001783180-24-000077 → 0001783180-24-000088


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-10-25):
[0001783180-24-000088:note_history:1]
| (In millions) |  | September 30,2024 |  | December 31,2023 |
| Environmental reserves included in Accrued liabilities |  | $ | 11 |  |  | $ | 19 |  |
| Environmental reserves included in Other long-term liabilities |  | 202 |  |  | 199 |  |
| Total Environmental reserves |  | $ | 213 |  |  | $ | 218 |  |
  (was, 2024-07-25, similarity 0.9758):
[0001783180-24-000077:note_history:1]
| (In millions) |  | June 30,2024 |  | December 31,2023 |
| Environmental reserves included in Accrued liabilities |  | $ | 16 |  |  | $ | 21 |  |
| Environmental reserves included in Other long-term liabilities |  | 200 |  |  | 203 |  |
| Total Environmental reserves |  | $ | 216 |  |  | $ | 224 |  |

- changed (2024-10-25):
[0001783180-24-000088:note_history:2]
| (In millions) |  | September 30,2024 |  | December 31,2023 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 15 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 208 |  |  | 206 |  |
| Total Asbestos liabilities |  | $ | 225 |  |  | $ | 221 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 7 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 88 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 95 |  |  | $ | 93 |  |
  (was, 2024-07-25, similarity 0.9866):
[0001783180-24-000077:note_history:2]
| (In millions) |  | June 30,2024 |  | December 31,2023 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 16 |  |  | $ | 15 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 201 |  |  | 206 |  |
| Total Asbestos liabilities |  | $ | 217 |  |  | $ | 221 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 86 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 91 |  |  | $ | 93 |  |

- added (2024-10-25):
[0001783180-24-000088:note_history:3]
As of September 30, 2024, the Company, Kidde-Fenwal, Inc. ("KFI") and others have been named as defendants in more than 8,000 lawsuits filed in United States state or federal courts and a single case in Canada alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and damage to property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). Individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

- changed (2024-10-25):
[0001783180-24-000088:note_history:4]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires. The lawsuits identified above relate to Kidde Fire Fighting, Inc., which owned the “National Foam” business that manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania (the "Pennsylvania Site"). Kidde Fire Fighting, Inc. was acquired by a UTC subsidiary in 2005 and merged into KFI in 2007. In 2013, KFI divested the AFFF businesses to an unrelated third party. The Company acquired KFI as part of the Separation in April 2020.
  (was, 2024-07-25, similarity 0.6723):
[0001783180-24-000077:note_history:4]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires. The lawsuits identified above relate to Kidde Fire Fighting, Inc., which owned the National Foam business. Kidde Fire Fighting, Inc. was acquired by a UTC subsidiary in 2005 and merged into KFI in 2007. The National Foam business manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania (the "Pennsylvania Site"). In 2013, KFI divested the AFFF businesses to an unrelated third party. The Company acquired KFI as part of the Separation in April 2020.

- changed (2024-10-25):
[0001783180-24-000088:note_history:5]
Plaintiffs in the MDL Proceedings have named multiple defendants, including suppliers of chemicals and raw materials used to manufacture fluorosurfactants, fluorosurfactant manufacturers and AFFF manufacturers. The defendants in the MDL Proceedings moved for summary judgment on the government contractor defense, which potentially applies to AFFF sold to or used by the U.S. government. After full briefing and oral argument, on September 16, 2022, the MDL court declined to enter summary judgment for the defendants. The defense, however, remains available at any trial in which it would apply.
  (was, 2024-07-25, similarity 0.9813):
[0001783180-24-000077:note_history:5]
Plaintiffs in the MDL Proceedings have named multiple defendants, including suppliers of chemicals and raw materials used to manufacture fluorosurfactants, fluorosurfactant manufacturers and AFFF manufacturers. The defendants in the MDL Proceedings moved for summary judgment on the government contractor defense, which potentially applies to AFFF sold to or used by the U.S. government. After full briefing and oral argument, on September 16, 2022, the MDL court declined to enter summary judgment for the defendants. The defense, however, remains available at any trial to which it applies.

- added (2024-10-25):
[0001783180-24-000088:note_history:6]
On May 14, 2023, KFI filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware (the “Bankruptcy Court”) seeking relief under chapter 11 of the Bankruptcy Code, after the Company determined that it would not provide financial support to KFI going forward other than ensuring KFI has access to services necessary for the effective operation of its business. As a result, all litigation against KFI was automatically stayed. By agreement, all AFFF-related litigation against the Company, its other subsidiaries and RTX also was stayed. On November 21, 2023, the Bankruptcy Court ordered certain parties, including the Company, to participate in mediation sessions with respect to claims that might be asserted by and against it in the bankruptcy proceedings.

- added (2024-10-25):
[0001783180-24-000088:note_history:7]
Following the conclusion of these mediation sessions in October 2024, the Company entered into a Settlement and Plan Support Agreement which contemplates that the Company will subsequently enter into three distinct settlement agreements (collectively, the “Proposed Settlement Agreements”) with KFI, the Official Committee of Unsecured Creditors appointed in KFI’s bankruptcy case (the “Committee”) and the Plaintiffs’ Executive Committee (the “MDL PEC”) appointed in the MDL Proceedings.

- added (2024-10-25):
[0001783180-24-000088:note_history:8]
The first of the Proposed Settlement Agreements relates to claims that the Company is responsible for liabilities arising from KFI’s manufacture or sale of AFFF (“Estate Claims Settlement”). Upon Bankruptcy Court approval, the Estate Claims Settlement will permanently resolve all present and future claims that the Company is responsible for any liabilities of KFI, including all liabilities arising from KFI’s manufacture and sale of AFFF. The second and third of the Proposed Settlement Agreements release a very substantial amount of current and future direct claims against the Company (the “Direct Claims Settlements”). Direct claims allege that UTC, which indirectly owned KFI’s AFFF business for eight years, engaged in conduct independent of KFI that caused harm to AFFF claimants. The Company agreed to indemnify UTC for these direct claims when it was spun-off from UTC. Upon approval by the MDL Court, the Direct Claims Settlements resolve and enjoin all current and future AFFF-related direct claims against the Company by participating public water providers and airports. Non-settling parties may still assert direct AFFF-related claims, although we expect a vast majority of public water providers and airports will participate in the Direct Claims Settlements.

- added (2024-10-25):
[0001783180-24-000088:note_history:9]
As part of the Proposed Settlement Agreements, the Company will pay $615 million in cash over five years, 100% of the net sale proceeds from the sale of KFI’s assets from its sale to Pacific Avenue Capital Partners, which are estimated to be $115 million, and contribute the right to recover proceeds under certain of its insurance policies. The Company will be entitled to receive up to $2.4 billion of proceeds from those insurance policies and will contribute the first $125 million of such proceeds as additional consideration in the Direct Claims Settlements. The Company also will be entitled to any earnouts payable to KFI under the KFI sale agreement. The Company expects insurance payments it receives in the future, in the aggregate, to cover the amount paid under the Proposed Settlement Agreements. As a result of the Proposed Settlement Agreements, the Company recorded a liability in the amount of $565 million during the three months ended September 30, 2024. The amount recognized is in addition to liabilities of $50 million that the Company recorded upon the deconsolidation of KFI on May 14, 2023, as further discussed below. As of September 30, 2024, the Company has not recorded any amounts associated with expected insurance proceeds.

- changed (2024-10-25):
[0001783180-24-000088:note_history:10]
The Company and KFI believe that they have meritorious defenses to the remaining AFFF claims. Given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate a range of possible loss at this time. There can be no assurance that any such future exposure will not be material in any period.
  (was, 2024-07-25, similarity 0.9178):
[0001783180-24-000077:note_history:10]
The Company and KFI believe that they have meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate a range of possible loss at this time. There can be no assurance that any such future exposure will not be material in any period.

- changed (2024-10-25):
[0001783180-24-000088:note_history:11]
As of May 14, 2023, the Company no longer controlled KFI as its activities are subject to review and oversight by the Bankruptcy Court. Therefore, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company’s Unaudited Condensed Consolidated Financial Statements. Upon deconsolidation, the Company determined the fair value of its retained interest in KFI to be zero and we accounted for it prospectively using the cost method. As a result of these actions, the Company recognized a loss of $297 million in its Unaudited Condensed Consolidated Statement of Operations
  (was, 2024-07-25, similarity 0.8326):
[0001783180-24-000077:note_history:11]
As of May 14, 2023, the Company no longer controlled KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from the Company’s Unaudited Condensed Consolidated Financial Statements. Upon deconsolidation, the Company determined the fair value of its retained interest in KFI to be zero and will account for it prospectively using the cost method. As a result of these actions, the Company recognized a loss of $297 million in its Unaudited Condensed Consolidated Statement of Operations within Other income/(expense), net. In addition, the deconsolidation resulted in an investing cash outflow of $134 million in the Company's Unaudited Condensed Consolidated Statement of Cash Flows.

- added (2024-10-25):
[0001783180-24-000088:note_history:12]
within within Other income/(expense), net. In addition, the deconsolidation resulted in an investing cash outflow of $134 million in the Company's Unaudited Condensed Consolidated Statement of Cash Flows.

- changed (2024-10-25):
[0001783180-24-000088:note_history:13]
Under the TMA relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. During the nine months ended September 30, 2024, the Company recognized a $46 million gain associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the IRS. Liabilities under the TMA of $118 million and $108 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of September 30, 2024, respectively. This obligation is expected to be settled in annual installments with the next installment of $118 million due in April 2025 and the final installment of $108 million due in April 2026. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.
  (was, 2024-07-25, similarity 0.9585):
[0001783180-24-000077:note_history:13]
Under the TMA relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. During the six months ended June 30, 2024, the Company recognized a $46 million gain associated with the TMA and UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the IRS. Liabilities under the TMA of $118 million and $108 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of June 30, 2024, respectively. This obligation is expected to be settled in annual installments with the next installment of $118 million due in April 2025 and the final installment due in April 2026. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

- removed (2024-10-25):
[0001783180-24-000077:note_history:14]
As of June 30, 2024, the Company, KFI and others have been named as defendants in more than 8,500 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company, KFI and others have also been named as defendants in more than 800 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

- removed (2024-10-25):
[0001783180-24-000077:note_history:15]
Plaintiffs in the MDL Proceedings allege that PFOS and PFOA contamination has resulted from the use of AFFF manufactured using a process known as ECF, and that this process was used exclusively by 3M. They also allege that PFOA contamination has resulted from the use of AFFF manufactured using a different process, known as telomerization, and that this process was used exclusively by the other AFFF manufacturers (including the National Foam business). Compounds containing PFOS and PFOA (as well as many other PFAS) have also been used for decades by many third parties in a number of different industries to manufacture firefighters’ protective outerwear, carpets, clothing, fabrics, cookware, food packaging, personal care products, cleaning products, paints, varnishes and other consumer and industrial products.

- removed (2024-10-25):
[0001783180-24-000077:note_history:16]
On September 23, 2022, after completion of discovery, the MDL court selected one water provider case, the City of Stuart, FL v. 3M, et al., for a bellwether trial. That trial was scheduled to begin in early June 2023 but was postponed indefinitely. The MDL court ordered that the bellwether process for personal injury cases to begin in 2023. However, the court has not yet outlined details on that process or its timing.

- removed (2024-10-25):
[0001783180-24-000077:note_history:17]
Outside of the MDL Proceedings, the Company and other defendants also are party to six lawsuits in U.S. state courts brought by oil refining companies alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage. In addition, the Company and other defendants are party to two actions related to the Pennsylvania Site in which the plaintiff water utility company seeks remediation costs related to the alleged contamination of the local water supply. The Company, KFI and other defendants are also party to one action in Arizona state court brought by a firefighter claiming that occupational exposure to AFFF has caused certain personal injuries.

- removed (2024-10-25):
[0001783180-24-000077:note_history:18]
On May 14, 2023, KFI filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware seeking relief under Chapter 11 of the Bankruptcy Code after the Company determined that it would not provide financial support to KFI going forward, other than ensuring KFI has access to services necessary for the effective operation of its business. As a result, all litigation against KFI is automatically stayed. KFI filed an adversary complaint and motion in the Chapter 11 case seeking an order staying or enjoining all AFFF-related litigation against the Company, its other subsidiaries and RTX. That motion was resolved through an agreement that effectively stays the AFFF litigation against these parties. KFI has also indicated to the bankruptcy court that it intends to pursue insurance coverage for AFFF-related liabilities and contractual indemnification for AFFF-related liabilities from the third party to which KFI sold National Foam. On November 21, 2023, the bankruptcy court ordered certain parties, including the Company, to participate in a mediation with respect to claims that might be asserted by and against it in the bankruptcy proceedings. The parties have engaged in several mediation sessions and anticipate further sessions in the future. The terms and scope of any potential settlement may be affected by, among other factors, the United States Supreme Court's decision in Harrington v. Purdue Pharma, L.P., which held that nonconsensual releases of litigation claims against non-debtors are unavailable.

- removed (2024-10-25):
[0001783180-24-000077:note_history:19]
On March 15, 2024, the Company and Pacific Avenue Capital Partners entered into certain agreements including a stock and asset purchase agreement whereby Pacific Avenue Capital Partners shall acquire certain assets and operating liabilities of KFI, subject to approval by the bankruptcy court. On April 1, 2024, the bankruptcy court subsequently approved the sale, which was completed on July 1, 2024 for $140 million, subject to working capital and other adjustments as provided in the sale agreement. However, there has been no determination with respect to the allocation of sale proceeds.


## us-gaap:ScheduleOfEnvironmentalLossContingenciesBySiteTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-10-25):
[0001783180-24-000088:note_history:20]
| (In millions) |  | September 30,2024 |  | December 31,2023 |
| Environmental reserves included in Accrued liabilities |  | $ | 11 |  |  | $ | 19 |  |
| Environmental reserves included in Other long-term liabilities |  | 202 |  |  | 199 |  |
| Total Environmental reserves |  | $ | 213 |  |  | $ | 218 |  |
  (was, 2024-07-25, similarity 0.9758):
[0001783180-24-000077:note_history:20]
| (In millions) |  | June 30,2024 |  | December 31,2023 |
| Environmental reserves included in Accrued liabilities |  | $ | 16 |  |  | $ | 21 |  |
| Environmental reserves included in Other long-term liabilities |  | 200 |  |  | 203 |  |
| Total Environmental reserves |  | $ | 216 |  |  | $ | 224 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-10-25):
[0001783180-24-000088:note_history:21]
| (In millions) |  | September 30,2024 |  | December 31,2023 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 15 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 208 |  |  | 206 |  |
| Total Asbestos liabilities |  | $ | 225 |  |  | $ | 221 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 7 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 88 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 95 |  |  | $ | 93 |  |
  (was, 2024-07-25, similarity 0.9866):
[0001783180-24-000077:note_history:21]
| (In millions) |  | June 30,2024 |  | December 31,2023 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 16 |  |  | $ | 15 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 201 |  |  | 206 |  |
| Total Asbestos liabilities |  | $ | 217 |  |  | $ | 221 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 86 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 91 |  |  | $ | 93 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2024-10-25):
[0001783180-24-000088:note_history:22]
During the fourth quarter of 2023, the net assets of the Company's Industrial Fire business ("Industrial Fire") met the criteria to be classified as held for sale. As a result, the assets and liabilities of Industrial Fire are presented as held for sale on the accompanying Unaudited Condensed Consolidated Balance Sheet as of December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. On March 5, 2024, the Company entered into a stock purchase agreement to sell Industrial Fire to Sentinel Capital Partners. The sale of Industrial Fire was completed on July 1, 2024. See Note 16 - Divestitures for additional information.

- added (2024-10-25):
[0001783180-24-000088:note_history:23]
On December 12, 2023, the Company entered into a stock purchase agreement to sell its Commercial Refrigeration business ("CCR") to Haier Group Corporation for an enterprise value of approximately $775 million. As a result, the assets and liabilities of CCR are presented as held for sale on the accompanying Unaudited Condensed Consolidated Balance Sheet as of September 30, 2024 and December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. The sale of CCR was completed on October 1, 2024. See Note 16 - Divestitures for additional information.

- added (2024-10-25):
[0001783180-24-000088:note_history:24]
On August 15, 2024, the Company entered into a stock purchase agreement to sell its Commercial and Residential Fire business (“CRF Business”) to an affiliate of Lone Star Funds for an enterprise value of approximately $3.0 billion. As a result, the assets and liabilities of the CRF Business are presented as held for sale on the accompanying Unaudited Condensed Consolidated Balance Sheet as of September 30, 2024 and December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. See Note 16 - Divestitures for additional information.

- added (2024-10-25):
[0001783180-24-000088:note_history:25]
Discontinued Operations

- added (2024-10-25):
[0001783180-24-000088:note_history:26]
In 2023, the Company announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. The announced plan to exit the Fire & Security segment represents a single disposal plan to separately divest multiple businesses over different reporting periods. Upon the CRF Business qualifying as held for sale during the three months ended September 30, 2024, the components of the Fire & Security segment in aggregate met the criteria to be presented as discontinued operations in the accompanying Unaudited Condensed Consolidated Statement of Operations and Unaudited Condensed Consolidated Statement of Cash Flows. In addition, the assets and liabilities of the CRF Business have been reclassified to held for sale at December 31, 2023. The results of the CCR business did not meet the criteria to be presented in discontinued operations. See Note 16 - Divestitures for additional information.

- changed (2024-10-25):
[0001783180-24-000088:note_history:27]
On May 14, 2023, Kidde-Fenwal, Inc. ("KFI"), an indirect wholly-owned subsidiary of the Company, filed a petition for voluntary reorganization under Chapter 11 of the United States Bankruptcy Code ("Chapter 11") in the United States Bankruptcy Court for the District of Delaware. KFI, an industrial fire detection and suppression business historically reported in the Company's Fire & Security segment, indicated that it intended to use the bankruptcy process to explore strategic alternatives, including the sale of KFI as a going concern. As of the petition date, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company's Unaudited Condensed Consolidated Financial Statements. The sale of KFI was completed on July 1, 2024. See Note 19 - Commitments and Contingent Liabilities for additional information.
  (was, 2024-07-25, similarity 0.9644):
[0001783180-24-000077:note_history:27]
On May 14, 2023, Kidde-Fenwal, Inc. ("KFI"), an indirect wholly-owned subsidiary of the Company, filed a petition for voluntary reorganization under Chapter 11 of the United States Bankruptcy Code ("Chapter 11") in the United States Bankruptcy Court for the District of Delaware. KFI, an industrial fire detection and suppression business historically reported in the Company's Fire & Security segment, indicated that it intended to use the bankruptcy process to explore strategic alternatives, including the sale of KFI as a going concern. As of the petition date, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company's Unaudited Condensed Consolidated Financial Statements. See Note 19 - Commitments and Contingent Liabilities for additional information.

- changed (2024-10-25):
[0001783180-24-000088:note_history:28]
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. Following the Separation and Distribution, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of September 30, 2024, only certain portions of the Tax Matters Agreement ("TMA") remain in effect.
  (was, 2024-07-25, similarity 0.9922):
[0001783180-24-000077:note_history:28]
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. Following the Separation and Distribution, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of June 30, 2024, only certain portions of the Tax Matters Agreement ("TMA") remain in effect.

- changed (2024-10-25):
[0001783180-24-000088:note_history:29]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"), which requires public entities to disclose disaggregated information about their effective tax rate reconciliation as well as information on income taxes paid. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.
  (was, 2024-07-25, similarity 0.9198):
[0001783180-24-000077:note_history:29]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"), which requires public entities to disclose disaggregated information about their effective tax rate reconciliation as well as information on income taxes paid. ASU 2023-09 is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.

- removed (2024-10-25):
[0001783180-24-000077:note_history:30]
On December 12, 2023, the Company entered into a stock purchase agreement to sell its Commercial Refrigeration business ("CCR") to Haier Group Corporation for an enterprise value of approximately $775 million. In addition, the net assets of the Company’s Industrial Fire business ("Industrial Fire") met the criteria to be classified as held for sale during the fourth quarter of 2023. As a result, the assets and liabilities of each business are presented as held for sale in the accompanying Unaudited Condensed Consolidated Balance Sheet as of June 30, 2024 and December 31, 2023, and recorded at the lower of their carrying value or fair value less estimated cost to sell. On March 5, 2024, the Company entered into a stock purchase agreement to sell Industrial Fire to Sentinel Capital Partners for an enterprise value of approximately $1.425 billion. The sale of Industrial Fire was completed on July 1, 2024. See Note 16 - Divestitures for additional information.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-10-25):
[0001783180-24-000088:note_history:31]
DESCRIPTION OF THE BUSINESS
Carrier Global Corporation (the "Company") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic and Carrier Transicold that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration and cold chain transportation solutions to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into two segments: HVAC and Refrigeration.
  (was, 2024-07-25, similarity 0.8748):
[0001783180-24-000077:note_history:31]
DESCRIPTION OF THE BUSINESS
Carrier Global Corporation (the "Company") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic, Carrier Transicold, Kidde and Edwards that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration, fire and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into three segments: HVAC, Refrigeration and Fire & Security.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-10-25):
[0001783180-24-000088:note_history:32]
| (In millions) |  |  |  | September 30,2024 |  | December 31,2023 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 4.375% Notes due 2025 (2) |  |  |  | 836 |  |  | 830 |  |
| 5.800% Notes due 2025 |  |  |  | — |  |  | 1,000 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 836 |  |  | 830 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 948 |  |  | 941 |  |
| 5.900% Notes due 2034 |  |  |  | 875 |  |  | 1,000 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 1,400 |  |  | 2,000 |  |
| 6.200% Notes due 2054 |  |  |  | 650 |  |  | 1,000 |  |
| Total long-term notes |  |  |  | 11,895 |  |  | 13,951 |  |
| Japanese Term Loan Facility |  |  |  | 374 |  |  | 379 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 243 |  |  | 74 |  |
| Discounts and debt issuance costs |  |  |  | (80) |  |  | (111) |  |
| Total debt |  |  |  | 12,432 |  |  | 14,293 |  |
| Less: current portion of long-term debt |  |  |  | 2,095 |  |  | 51 |  |
| Long-term debt, net of current portion |  |  |  | $ | 10,337 |  |  | $ | 14,242 |  |
  (was, 2024-07-25, similarity 0.9828):
[0001783180-24-000077:note_history:32]
| (In millions) |  |  |  | June 30,2024 |  | December 31,2023 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 4.375% Notes due 2025 (2) |  |  |  | 801 |  |  | 830 |  |
| 5.800% Notes due 2025 |  |  |  | — |  |  | 1,000 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 801 |  |  | 830 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 908 |  |  | 941 |  |
| 5.900% Notes due 2034 |  |  |  | 1,000 |  |  | 1,000 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| 6.200% Notes due 2054 |  |  |  | 1,000 |  |  | 1,000 |  |
| Total long-term notes |  |  |  | 12,860 |  |  | 13,951 |  |
| Japanese Term Loan Facility |  |  |  | 337 |  |  | 379 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 220 |  |  | 74 |  |
| Discounts and debt issuance costs |  |  |  | (95) |  |  | (111) |  |
| Total debt |  |  |  | 13,322 |  |  | 14,293 |  |
| Less: current portion of long-term debt |  |  |  | 2,052 |  |  | 51 |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,270 |  |  | $ | 14,242 |  |

- changed (2024-10-25):
[0001783180-24-000088:note_history:33]
On May 19, 2023, the Company entered into a senior unsecured delayed draw term loan credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders that permits aggregate borrowings of up to €2.3 billion (the "Delayed Draw Facility"). The facility consisted of an 18-month, Euro-denominated tranche in an aggregate amount of €1.15 billion and a 3-year, Euro-denominated tranche in an aggregate amount of €1.15 billion. Euro-denominated borrowings bear interest at the EURIBOR Rate plus a ratings-based margin, USD-denominated borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. The Company capitalized $4 million of deferred financing costs which will be amortized over the respective term of the tranches. On January 2, 2024, the Company borrowed the full amount available under the Delayed Draw Facility in U.S. Dollars. Borrowings under the Delayed Draw Facility were repaid in June 2024 and the facility was subsequently terminated.
  (was, 2024-07-25, similarity 0.9986):
[0001783180-24-000077:note_history:33]
On May 19, 2023, the Company entered into a senior unsecured delayed draw term loan credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders that permits aggregate borrowings of up to €2.3 billion (the "Delayed Draw Facility"). The facility consists of an 18-month, Euro-denominated tranche in an aggregate amount of €1.15 billion and a 3-year, Euro-denominated tranche in an aggregate amount of €1.15 billion. Euro-denominated borrowings bear interest at the EURIBOR Rate plus a ratings-based margin, USD-denominated borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. The Company capitalized $4 million of deferred financing costs which will be amortized over the respective term of the tranches. On January 2, 2024, the Company borrowed the full amount available under the Delayed Draw Facility in U.S. Dollars. Borrowings under the Delayed Draw Facility were repaid in June 2024 and the facility was subsequently terminated.

- changed (2024-10-25):
[0001783180-24-000088:note_history:34]
On May 17, 2024, the Company entered into a 364-day, $500 million, senior unsecured revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders (the “364-day Revolver”). Borrowings are available in U.S. Dollars and Euros. USD-denominated borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin, Euro-denominated borrowings bear interest at the Adjusted EURIBOR Rate plus a ratings-based margin. Upon entering into the 364-day Revolver, the Company terminated its existing $500 million senior unsecured revolving credit agreement that was set to mature in May 2024. As of September 30, 2024, there were no borrowings outstanding under the 364-day Revolver.
  (was, 2024-07-25, similarity 0.9915):
[0001783180-24-000077:note_history:34]
On May 17, 2024, the Company entered into a 364-day, $500 million, senior unsecured revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders (the “364-day Revolver”). Borrowings are available in U.S. Dollars and Euros. USD-denominated borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin, Euro-denominated borrowings bear interest at the Adjusted EURIBOR Rate plus a ratings-based margin. Upon entering into the 364-day Revolver, the Company terminated its existing $500 million senior unsecured revolving credit agreement that was set to mature in May 2024. As of June 30, 2024, there were no borrowings outstanding under the 364-day Revolver.

- changed (2024-10-25):
[0001783180-24-000088:note_history:35]
On May 19, 2023, the Company entered into a revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in May 2028 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. In addition, the Company capitalized $2 million of deferred financing costs which are being amortized over its term. As of September 30, 2024, there were no borrowings outstanding under the Revolving Credit Facility.
  (was, 2024-07-25, similarity 0.9938):
[0001783180-24-000077:note_history:35]
On May 19, 2023, the Company entered into a revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in May 2028 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. In addition, the Company capitalized $2 million of deferred financing costs which are being amortized over its term. As of June 30, 2024, there were no borrowings outstanding under the Revolving Credit Facility.

- changed (2024-10-25):
[0001783180-24-000088:note_history:36]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of September 30, 2024, there were no borrowings outstanding under the commercial paper program.
  (was, 2024-07-25, similarity 0.9775):
[0001783180-24-000077:note_history:36]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of June 30, 2024, there were no borrowings outstanding under the commercial paper program.

- changed (2024-10-25):
[0001783180-24-000088:note_history:37]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $40 million and $14 million of debt during the nine months ended September 30, 2024 and 2023, respectively. Long-term debt repayments associated with these financing arrangements during the nine months ended September 30, 2024 and 2023, were $7 million and $15 million, respectively.
  (was, 2024-07-25, similarity 0.8832):
[0001783180-24-000077:note_history:37]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $20 million and $6 million of debt during the six months ended June 30, 2024 and 2023, respectively. Long-term debt repayments associated with these financing arrangements during the six months ended June 30, 2024 and 2023 were $6 million and $12 million, respectively.

- changed (2024-10-25):
[0001783180-24-000088:note_history:38]
The Revolving Credit Facility, 364-day Revolver, the indenture for the long-term notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur certain liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of September 30, 2024, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.
  (was, 2024-07-25, similarity 0.7779):
[0001783180-24-000077:note_history:38]
The Revolving Credit Facility, 364-day Revolver, the indenture for the long-term notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur certain liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of June 30, 2024, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

- added (2024-10-25):
[0001783180-24-000088:note_history:39]
Tender Offers
In July 2024, the Company commenced tender offers to purchase up to $800 million ("Aggregate Tender Cap") aggregate principal of certain tranches of the Company's notes. The tender offers included payment of applicable accrued and unpaid interest up to the settlement date, along with a fixed spread for early repayment. Based on participation, the Company elected to increase the Aggregate Tender Cap and settle the tender offers early. The aggregate principal amount tendered and accepted was approximately $1.0 billion, which included $125 million of notes due 2034, $350 million of notes due 2054 and approximately $600 million of notes due 2050. Upon settlement, the Company recognized a net gain of $97 million and wrote off $11 million of unamortized deferred financing costs within Interest (expense) income, net on the accompanying Unaudited Condensed Consolidated Statement of Operations.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-10-25):
[0001783180-24-000088:note_history:40]
| (In millions) |  |  |  | September 30,2024 |  | December 31,2023 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 4.375% Notes due 2025 (2) |  |  |  | 836 |  |  | 830 |  |
| 5.800% Notes due 2025 |  |  |  | — |  |  | 1,000 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 836 |  |  | 830 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 948 |  |  | 941 |  |
| 5.900% Notes due 2034 |  |  |  | 875 |  |  | 1,000 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 1,400 |  |  | 2,000 |  |
| 6.200% Notes due 2054 |  |  |  | 650 |  |  | 1,000 |  |
| Total long-term notes |  |  |  | 11,895 |  |  | 13,951 |  |
| Japanese Term Loan Facility |  |  |  | 374 |  |  | 379 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 243 |  |  | 74 |  |
| Discounts and debt issuance costs |  |  |  | (80) |  |  | (111) |  |
| Total debt |  |  |  | 12,432 |  |  | 14,293 |  |
| Less: current portion of long-term debt |  |  |  | 2,095 |  |  | 51 |  |
| Long-term debt, net of current portion |  |  |  | $ | 10,337 |  |  | $ | 14,242 |  |
  (was, 2024-07-25, similarity 0.9828):
[0001783180-24-000077:note_history:40]
| (In millions) |  |  |  | June 30,2024 |  | December 31,2023 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 4.375% Notes due 2025 (2) |  |  |  | 801 |  |  | 830 |  |
| 5.800% Notes due 2025 |  |  |  | — |  |  | 1,000 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 801 |  |  | 830 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 908 |  |  | 941 |  |
| 5.900% Notes due 2034 |  |  |  | 1,000 |  |  | 1,000 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| 6.200% Notes due 2054 |  |  |  | 1,000 |  |  | 1,000 |  |
| Total long-term notes |  |  |  | 12,860 |  |  | 13,951 |  |
| Japanese Term Loan Facility |  |  |  | 337 |  |  | 379 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 220 |  |  | 74 |  |
| Discounts and debt issuance costs |  |  |  | (95) |  |  | (111) |  |
| Total debt |  |  |  | 13,322 |  |  | 14,293 |  |
| Less: current portion of long-term debt |  |  |  | 2,052 |  |  | 51 |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,270 |  |  | $ | 14,242 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2024-10-25):
[0001783180-24-000088:note_history:41]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Sales to equity method investees included in Product sales |  | $ | 774 |  |  | $ | 730 |  |  | $ | 2,329 |  |  | $ | 2,371 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 64 |  |  | $ | 57 |  |  | $ | 178 |  |  | $ | 159 |  |

- added (2024-10-25):
[0001783180-24-000088:note_history:42]
| (In millions) |  | September 30,2024 |  | December 31,2023 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 287 |  |  | $ | 231 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 47 |  |  | $ | 44 |  |

- removed (2024-10-25):
[0001783180-24-000077:note_history:43]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Sales to equity method investees included in Product sales |  | $ | 832 |  |  | $ | 887 |  |  | $ | 1,555 |  |  | $ | 1,641 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 59 |  |  | $ | 59 |  |  | $ | 114 |  |  | $ | 102 |  |

- removed (2024-10-25):
[0001783180-24-000077:note_history:44]
| (In millions) |  | June 30,2024 |  | December 31,2023 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 276 |  |  | $ | 231 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 51 |  |  | $ | 44 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-10-25):
[0001783180-24-000088:note_history:45]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 4,504 |  |  | $ | 3,533 |  |  | $ | 13,045 |  |  | $ | 10,488 |  |
| Service |  | 554 |  |  | 475 |  |  | 1,524 |  |  | 1,358 |  |
| HVAC sales |  | 5,058 |  |  | 4,008 |  |  | 14,569 |  |  | 11,846 |  |
| Product |  | 811 |  |  | 808 |  |  | 2,434 |  |  | 2,453 |  |
| Service |  | 127 |  |  | 116 |  |  | 361 |  |  | 341 |  |
| Refrigeration sales |  | 938 |  |  | 924 |  |  | 2,795 |  |  | 2,794 |  |
| Total segment sales |  | 5,996 |  |  | 4,932 |  |  | 17,364 |  |  | 14,640 |  |
| Eliminations and other (1) |  | (12) |  |  | 3 |  |  | (26) |  |  | (5) |  |
| Net sales |  | $ | 5,984 |  |  | $ | 4,935 |  |  | $ | 17,338 |  |  | $ | 14,635 |  |
  (was, 2024-07-25, similarity 0.8493):
[0001783180-24-000077:note_history:45]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 4,468 |  |  | $ | 3,754 |  |  | $ | 8,541 |  |  | $ | 6,955 |  |
| Service |  | 502 |  |  | 462 |  |  | 970 |  |  | 883 |  |
| HVAC sales |  | 4,970 |  |  | 4,216 |  |  | 9,511 |  |  | 7,838 |  |
| Product |  | 851 |  |  | 858 |  |  | 1,623 |  |  | 1,645 |  |
| Service |  | 122 |  |  | 114 |  |  | 234 |  |  | 225 |  |
| Refrigeration sales |  | 973 |  |  | 972 |  |  | 1,857 |  |  | 1,870 |  |
| Product |  | 809 |  |  | 869 |  |  | 1,634 |  |  | 1,682 |  |
| Service |  | 62 |  |  | 63 |  |  | 124 |  |  | 119 |  |
| Fire & Security sales |  | 871 |  |  | 932 |  |  | 1,758 |  |  | 1,801 |  |
| Total segment sales |  | 6,814 |  |  | 6,120 |  |  | 13,126 |  |  | 11,509 |  |
| Eliminations and other |  | (125) |  |  | (128) |  |  | (255) |  |  | (244) |  |
| Net sales |  | $ | 6,689 |  |  | $ | 5,992 |  |  | $ | 12,871 |  |  | $ | 11,265 |  |

- added (2024-10-25):
[0001783180-24-000088:note_history:46]
(1) Includes certain business activities previously reported in the Fire & Security segment.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-10-25):
[0001783180-24-000088:note_history:47]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 4,504 |  |  | $ | 3,533 |  |  | $ | 13,045 |  |  | $ | 10,488 |  |
| Service |  | 554 |  |  | 475 |  |  | 1,524 |  |  | 1,358 |  |
| HVAC sales |  | 5,058 |  |  | 4,008 |  |  | 14,569 |  |  | 11,846 |  |
| Product |  | 811 |  |  | 808 |  |  | 2,434 |  |  | 2,453 |  |
| Service |  | 127 |  |  | 116 |  |  | 361 |  |  | 341 |  |
| Refrigeration sales |  | 938 |  |  | 924 |  |  | 2,795 |  |  | 2,794 |  |
| Total segment sales |  | 5,996 |  |  | 4,932 |  |  | 17,364 |  |  | 14,640 |  |
| Eliminations and other (1) |  | (12) |  |  | 3 |  |  | (26) |  |  | (5) |  |
| Net sales |  | $ | 5,984 |  |  | $ | 4,935 |  |  | $ | 17,338 |  |  | $ | 14,635 |  |
  (was, 2024-07-25, similarity 0.8493):
[0001783180-24-000077:note_history:47]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 4,468 |  |  | $ | 3,754 |  |  | $ | 8,541 |  |  | $ | 6,955 |  |
| Service |  | 502 |  |  | 462 |  |  | 970 |  |  | 883 |  |
| HVAC sales |  | 4,970 |  |  | 4,216 |  |  | 9,511 |  |  | 7,838 |  |
| Product |  | 851 |  |  | 858 |  |  | 1,623 |  |  | 1,645 |  |
| Service |  | 122 |  |  | 114 |  |  | 234 |  |  | 225 |  |
| Refrigeration sales |  | 973 |  |  | 972 |  |  | 1,857 |  |  | 1,870 |  |
| Product |  | 809 |  |  | 869 |  |  | 1,634 |  |  | 1,682 |  |
| Service |  | 62 |  |  | 63 |  |  | 124 |  |  | 119 |  |
| Fire & Security sales |  | 871 |  |  | 932 |  |  | 1,758 |  |  | 1,801 |  |
| Total segment sales |  | 6,814 |  |  | 6,120 |  |  | 13,126 |  |  | 11,509 |  |
| Eliminations and other |  | (125) |  |  | (128) |  |  | (255) |  |  | (244) |  |
| Net sales |  | $ | 6,689 |  |  | $ | 5,992 |  |  | $ | 12,871 |  |  | $ | 11,265 |  |

- added (2024-10-25):
[0001783180-24-000088:note_history:48]
(1) Includes certain business activities previously reported in the Fire & Security segment.

- added (2024-10-25):
[0001783180-24-000088:note_history:49]
| (In millions) |  | September 30,2024 |  | December 31,2023 |
| Contract assets (included within Other current assets) |  | $ | 367 |  |  | $ | 306 |  |
| Contract assets, non-current (included within Other assets) |  | 55 |  |  | 26 |  |
| Total contract assets |  | 422 |  |  | 332 |  |
| Contract liabilities (included within Accrued liabilities) |  | (563) |  |  | (419) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (162) |  |  | (160) |  |
| Total contract liabilities |  | (725) |  |  | (579) |  |
| Net contract assets (liabilities) |  | $ | (303) |  |  | $ | (247) |  |

- changed (2024-10-25):
[0001783180-24-000088:note_history:50]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.
The Company recognized revenue of $401 million during the nine months ended September 30, 2024 that related to contract liabilities as of January 1, 2024. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.
  (was, 2024-07-25, similarity 0.7993):
[0001783180-24-000077:note_history:50]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.
The Company recognized revenue of $348 million during the six months ended June 30, 2024 that related to contract liabilities as of January 1, 2024. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.

- removed (2024-10-25):
[0001783180-24-000077:note_history:51]
| (In millions) |  | June 30,2024 |  | December 31,2023 |
| Contract assets |  | $ | 333 |  |  | $ | 306 |  |
| Contract assets, non-current (included within Other assets) |  | 40 |  |  | 26 |  |
| Total contract assets |  | 373 |  |  | 332 |  |
| Contract liabilities |  | (493) |  |  | (425) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (161) |  |  | (160) |  |
| Total contract liabilities |  | (654) |  |  | (585) |  |
| Net contract assets (liabilities) |  | $ | (281) |  |  | $ | (253) |  |
