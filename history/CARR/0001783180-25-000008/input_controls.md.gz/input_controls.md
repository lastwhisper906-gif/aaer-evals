# CARR 10-K controls and the auditor's report


## auditors_report

[0001783180-25-000008:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001783180-25-000008:auditors_report:2]
To the Board of Directors and Shareowners of Carrier Global Corporation

[0001783180-25-000008:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0001783180-25-000008:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Carrier Global Corporation and its subsidiaries (the “Company”) as of December 31, 2024 and 2023, and the related consolidated statements of operations, of comprehensive income (loss), of changes in equity and of cash flows for each of the three years in the period ended December 31, 2024, including the related notes (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of December 31, 2024, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001783180-25-000008:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of December 31, 2024 and 2023, and the results of its operations and its cash flows for each of the three years in the period ended December 31, 2024 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of December 31, 2024, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0001783180-25-000008:auditors_report:6]
Basis for Opinions

[0001783180-25-000008:auditors_report:7]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in Management’s Report on Internal Control Over Financial Reporting appearing under Item 9A. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001783180-25-000008:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001783180-25-000008:auditors_report:9]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001783180-25-000008:auditors_report:10]
As described in Management’s Report on Internal Control Over Financial Reporting, management has excluded the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG from its assessment of internal control over financial reporting as of December 31, 2024 because it was acquired by the Company in a purchase business combination during 2024. We have also excluded the VCS Business from our audit of internal control over financial reporting. The VCS Business is a wholly-owned subsidiary whose total assets excluding intangible assets and goodwill arising from the acquisition and total net sales excluded from management’s assessment and our audit of internal control over financial reporting represent approximately 14% and 15%, respectively, of the related consolidated financial statement amounts as of and for the year ended December 31, 2024.

[0001783180-25-000008:auditors_report:11]
48

[0001783180-25-000008:auditors_report:12]
Definition and Limitations of Internal Control over Financial Reporting

[0001783180-25-000008:auditors_report:13]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001783180-25-000008:auditors_report:14]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001783180-25-000008:auditors_report:15]
Critical Audit Matters

[0001783180-25-000008:auditors_report:16]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001783180-25-000008:auditors_report:17]
Acquisition of the VCS Business - Valuation of Intangible Assets Acquired

[0001783180-25-000008:auditors_report:18]
As described in Note 19 to the consolidated financial statements, on January 2, 2024, the Company completed the acquisition of the VCS Business for total consideration of $14.2 billion. Of the acquired intangible assets, $4,787 million of customer relationships, $679 million of a trademark, and $1,051 million of technology intangible assets (collectively, the “intangible assets acquired”) were recorded. The valuation of the intangible assets acquired was determined using an income approach methodology including the multi-period excess earnings method and the relief from royalty method. Key assumptions used in estimating future cash flows included short-term revenue growth rates, research and development expenses, earnings before interest, taxes, depreciation and amortization (EBITDA) margins, income tax rates, discount rates, customer attrition rate, royalty rates, contributory asset charge, and obsolescence rates, among others.

[0001783180-25-000008:auditors_report:19]
The principal considerations for our determination that performing procedures relating to the valuation of intangible assets acquired in the acquisition of the VCS Business is a critical audit matter are (i) the significant judgment by management when developing the fair value estimate of the intangible assets acquired; (ii) a high degree of auditor judgment, subjectivity, and effort in performing procedures and evaluating management's significant assumptions related to (a) short-term revenue growth rates, research and development expenses, EBITDA margins, income tax rates, discount rate, customer attrition rate, royalty rates, and contributory asset charge for the customer relationships, (b) short-term revenue growth rates, discount rate, and royalty rate for the trademark, and (c) short-term revenue growth rates, discount rate, royalty rates, and obsolescence rates for certain technologies; and (iii) the audit effort involved the use of professionals with specialized skill and knowledge.

[0001783180-25-000008:auditors_report:20]
49

[0001783180-25-000008:auditors_report:21]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the acquisition accounting, including controls over management’s valuation of the intangible assets acquired. These procedures also included, among others (i) reading the purchase agreement; (ii) testing management’s process for developing the fair value estimate of the intangible assets acquired; (iii) evaluating the appropriateness of the multi-period excess earnings and relief from royalty methods used by management; (iv) testing the completeness and accuracy of the underlying data used in the multi-period excess earnings and relief from royalty methods; and (v) evaluating the reasonableness of the significant assumptions used by management related to (a) short-term revenue growth rates, research and development expenses, EBITDA margins, income tax rates, discount rate, customer attrition rate, royalty rates, and contributory asset charge for the customer relationships, (b) short-term revenue growth rates, discount rate, and royalty rate for the trademark, and (c) short-term revenue growth rates, discount rate, royalty rates, and obsolescence rates for certain technologies. Evaluating management’s assumptions related to (a) short-term revenue growth rates, research and development expenses, EBITDA margins, and income tax rates for the customer relationships, (b) short-term revenue growth rates for the trademark, and (c) short-term revenue growth rates for certain technologies involved considering (i) the current and past performance of the VCS Business; (ii) the consistency with external market and industry data; and (iii) whether the assumptions were consistent with evidence obtained in other areas of the audit. Professionals with specialized skill and knowledge were used to assist in evaluating (i) the appropriateness of the multi-period excess earnings and relief from royalty methods and (ii) the reasonableness of the (a) discount rate, customer attrition rate, royalty rates, and contributory asset charge assumptions for the customer relationships, (b) discount rate and royalty rate assumptions for the trademark, and (c) discount rate, royalty rates, and obsolescence rates assumptions for certain technologies.

[0001783180-25-000008:auditors_report:22]
/s/ PricewaterhouseCoopers LLP

[0001783180-25-000008:auditors_report:23]
Miami, Florida

[0001783180-25-000008:auditors_report:24]
February 11, 2025

[0001783180-25-000008:auditors_report:25]
We have served as the Company's auditor since 2019.

[0001783180-25-000008:auditors_report:26]
50

[0001783180-25-000008:auditors_report:27]
CARRIER GLOBAL CORPORATION AND SUBSIDIARIES


## item_9a

[0001783180-25-000008:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES

[0001783180-25-000008:item_9a:2]
Evaluation of Disclosure Controls and Procedures — Our management, with the participation of our CEO and Senior Vice President and Chief Financial Officer ("CFO"), has evaluated the effectiveness of the Company's disclosure controls and procedures (as such term is defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) as of December 31, 2024. Based on that evaluation, the Company's CEO and CFO have concluded that, as of December 31, 2024, the Company's disclosure controls and procedures were effective in recording, processing, summarizing and reporting, within the time periods specified in the SEC's rules and forms, information required to be disclosed by the Company in the reports that it files or submits under the Exchange Act, and that information is accumulated and communicated to the Company's management, including our CEO and CFO, as appropriate, to allow timely decisions regarding required disclosures.

[0001783180-25-000008:item_9a:3]
Management’s Report on Internal Control Over Financial Reporting — The Company’s management is responsible for establishing and maintaining adequate internal control over financial reporting, as such term is defined in Exchange Act Rules 13a-15(f) and 15d-15(f). The Company’s management, with the participation of the Company’s CEO and CFO, has evaluated the effectiveness of the Company’s internal control over financial reporting based on the criteria described in Internal Control-Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on this evaluation, the Company’s management has concluded that, as of December 31, 2024, the Company’s internal control over financial reporting was effective.

[0001783180-25-000008:item_9a:4]
99

[0001783180-25-000008:item_9a:5]
In accordance with guidance issued by the staff of the SEC, companies are permitted to exclude acquisitions from their assessment of internal control over financial reporting for the first fiscal year in which the acquisition occurred. As discussed in Note 19 "Acquisitions" of the Company's Notes to the Consolidated Financial Statements, the Company acquired the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG on January 2, 2024 in a purchase business combination. The VCS Business has total assets excluding intangible assets and goodwill arising from the acquisition and total net sales, of approximately 14% and 15%, respectively, of the related consolidated financial statement amounts as of and for the year ended December 31, 2024. Management's assessment of the effectiveness of our internal control over financial reporting as of December 31, 2024 excluded the VCS Business, as the Company is in the process of aligning and integrating various processes, systems and internal controls related to the business and operations of this subsidiary, excluding intangible assets and goodwill, which are included within the scope of management’s assessment.

[0001783180-25-000008:item_9a:6]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001783180-25-000008:item_9a:7]
PricewaterhouseCoopers LLP, an independent registered public accounting firm, has audited the effectiveness of the Company's internal control over financial reporting as of December 31, 2024, as stated in their report which appears herein.

[0001783180-25-000008:item_9a:8]
Changes in Internal Control Over Financial Reporting — There were no changes in our internal control over financial reporting during the three months ended December 31, 2024, that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
