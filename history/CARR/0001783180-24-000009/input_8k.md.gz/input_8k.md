# CARR 8-K — 0001783180-24-000007 filed 2024-02-06

## item codes, every 8-K on or before 2024-02-06

- 2024-02-06 0001783180-24-000007 — 2.02, 9.01
- 2024-02-01 0000950142-24-000264 — 5.02
- 2024-01-02 0001140361-24-000034 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2023-12-13 0001140361-23-057415 — 1.01, 9.01
- 2023-12-08 0001140361-23-056751 — 7.01, 9.01
- 2023-11-30 0000950142-23-002884 — 1.01, 2.03, 8.01, 9.01
- 2023-11-16 0000950142-23-002788 — 8.01, 9.01
- 2023-11-13 0001140361-23-052667 — 7.01, 8.01, 9.01
- 2023-10-26 0001783180-23-000063 — 2.02, 9.01
- 2023-07-27 0001783180-23-000053 — 2.02, 9.01
- 2023-06-12 0000950142-23-001664 — 5.02
- 2023-05-25 0000950142-23-001541 — 1.01, 1.02, 2.03, 9.01
- 2023-04-26 0000950142-23-001205 — 1.01, 9.01
- 2023-04-25 0001783180-23-000036 — 2.02, 7.01, 9.01
- 2023-04-25 0000950142-23-001199 — 7.01, 8.01, 9.01
- 2023-04-21 0001783180-23-000032 — 5.07, 9.01
- 2023-02-07 0001783180-23-000010 — 2.02, 9.01
- 2022-10-27 0001783180-22-000054 — 2.02, 7.01, 9.01
- 2022-09-29 0000950142-22-002805 — 5.02, 9.01
- 2022-07-28 0001783180-22-000045 — 2.02, 9.01
- 2022-04-28 0001783180-22-000032 — 2.02, 9.01
- 2022-04-15 0001783180-22-000024 — 5.07, 9.01
- 2022-02-08 0001783180-22-000008 — 2.02, 9.01
- 2022-02-07 0000950142-22-000510 — 8.01, 9.01
- 2022-01-03 0000950142-22-000023 — 8.01, 9.01
- 2021-12-17 0001783180-21-000071 — 5.02, 7.01, 9.01
- 2021-11-23 0001783180-21-000068 — 5.03, 9.01
- 2021-10-28 0001783180-21-000062 — 2.02, 9.01
- 2021-08-27 0001783180-21-000056 — 8.01
- 2021-07-30 0001783180-21-000053 — 1.01
- 2021-07-29 0001783180-21-000049 — 2.02, 8.01, 9.01
- 2021-07-27 0000950142-21-002448 — 8.01, 9.01
- 2021-07-15 0000950142-21-002362 — 5.02, 9.01
- 2021-06-09 0000950142-21-001885 — 5.02, 9.01
- 2021-04-29 0001783180-21-000029 — 2.02, 9.01
- 2021-04-22 0001140361-21-013889 — 5.02, 9.01
- 2021-04-20 0001783180-21-000021 — 5.07, 9.01
- 2021-04-19 0000950142-21-001308 — 8.01, 9.01
- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2024-02-06

- none on or before 2024-02-06

## item 2.02 — earnings release, exhibit 99.1

[0001783180-24-000007:8k_2_02:1]
EX-99
2
a8-kerexhibit99xq42023.htm
EX-99

[0001783180-24-000007:8k_2_02:2]
Document

[0001783180-24-000007:8k_2_02:3]
Exhibit 99

[0001783180-24-000007:8k_2_02:4]
Carrier Reports Strong 2023 Results and Announces 2024 Outlook

[0001783180-24-000007:8k_2_02:5]
Fourth Quarter 2023 Highlights

[0001783180-24-000007:8k_2_02:6]
•Sales of $5.1B

[0001783180-24-000007:8k_2_02:7]
•Operating margin expansion of 340 basis points and adjusted operating margin expansion of 80 basis points

[0001783180-24-000007:8k_2_02:8]
•GAAP EPS of $0.49, up 53% vs. 2022 and adjusted EPS of $0.53, up 33% vs. 2022

[0001783180-24-000007:8k_2_02:9]
•Net cash flow from operating activities of $1.1B and free cash flow of $829M

[0001783180-24-000007:8k_2_02:10]
Full Year 2023 Highlights

[0001783180-24-000007:8k_2_02:11]
•Sales of $22.1B, up 8% compared to 2022 including 3% organic growth

[0001783180-24-000007:8k_2_02:12]
•Gross margins up 210 basis points compared to 2022

[0001783180-24-000007:8k_2_02:13]
•GAAP EPS of $1.58 and adjusted EPS of $2.73

[0001783180-24-000007:8k_2_02:14]
•Net cash flow from operating activities of $2.6B and free cash flow of $2.1B, up 49% and 53% respectively

[0001783180-24-000007:8k_2_02:15]
Outlook for 2024

[0001783180-24-000007:8k_2_02:16]
•Global Access Solutions and Commercial Refrigeration included through June 30, 2024

[0001783180-24-000007:8k_2_02:17]
•Viessmann Climate Solutions sales expected to grow mid-single-digits

[0001783180-24-000007:8k_2_02:18]
•Assumes ~$4.5B net proceeds from business exits are used for debt reduction

[0001783180-24-000007:8k_2_02:19]
•Sales of ~$26.5B with mid-single digit organic* growth

[0001783180-24-000007:8k_2_02:20]
•Adjusted operating margin* of 15.0% - 15.5%, up > 50 basis points compared to 2023

[0001783180-24-000007:8k_2_02:21]
•Adjusted EPS* of $2.80 - $2.90

[0001783180-24-000007:8k_2_02:22]
•Free cash flow* of ~$0.7B (includes $1.7B of expected tax payments on the gains from the announced business exits, restructuring, and transaction-related costs): up ~10% excluding these expected items

[0001783180-24-000007:8k_2_02:23]
PALM BEACH GARDENS, Fla., February 6, 2024 – Carrier Global Corporation (NYSE:CARR), global leader in intelligent climate and energy solutions, today reported strong financial results for the fourth quarter and full year of 2023. The Company projects continued solid organic growth in 2024 supported by a projected fourth consecutive year of double-digit aftermarket growth, innovation, and significant secular tailwinds.

[0001783180-24-000007:8k_2_02:24]
1

[0001783180-24-000007:8k_2_02:25]
“Our fourth quarter results continue to show Carrier’s ability to perform while transforming with strong operating profit growth and EPS up over 30% compared to the prior year. For full-year 2023, we grew gross margins 210 basis points on 3% organic sales growth with both operating and free cash flow up about 50% compared to the prior year,” said Carrier Chairman & CEO David Gitlin. “In addition to delivering results ahead of our projections for the year, we completed our game-changing combination with Viessmann Climate Solutions in January and reached definitive agreements to sell both our Global Access Solutions and Commercial Refrigeration businesses for close to $6B combined. Looking forward to 2024, our solid backlog levels and sustainability leadership position Carrier for another year of strong financial performance.”

[0001783180-24-000007:8k_2_02:26]
Fourth Quarter 2023 Results

[0001783180-24-000007:8k_2_02:27]
Carrier’s fourth quarter sales of $5.1B were flat compared to the prior year including flat organic sales growth, a 1% tailwind from currency translation and a 1% net negative impact from acquisitions and divestitures. Sales in the HVAC segment were down 1% decline organically. North America Residential & Light Commercial HVAC sales declined high single digits due to weaker than expected residential sales as distributors reduced inventory levels. This was offset by high single digit growth in Commercial HVAC globally. The Refrigeration segment returned to growth this quarter, with organic sales up 6% driven by growth in Transport Refrigeration. Fire and Security organic sales were down 1% driven by Global Access Solutions and Residential Fire partially offset by growth in Industrial Fire.

[0001783180-24-000007:8k_2_02:28]
GAAP operating profit in the quarter of $607M was up 40% from the fourth quarter of 2022. Adjusted operating profit of $557M was up 8%.

[0001783180-24-000007:8k_2_02:29]
Net income and adjusted net income were $420M and $452M, respectively. GAAP EPS of $0.49 and adjusted EPS of $0.53 benefited from operating margin expansion and lower effective tax rates. Net cash flows provided by operating activities for the quarter were approximately $1.1B and capital expenditures were $233M, resulting in free cash flow of $829M.

[0001783180-24-000007:8k_2_02:30]
2

[0001783180-24-000007:8k_2_02:31]
Full-Year 2023 Results

[0001783180-24-000007:8k_2_02:32]
Carrier’s 2023 sales of $22.1B increased 8% compared to the prior year including organic sales growth of 3% and a 5% impact from acquisitions and divestitures. Gross margins increased 210 basis points compared to the prior year. GAAP operating profit of $2.3B decreased 49% due to prior year gains on the sale of Chubb and the acquisition of Toshiba Carrier, while adjusted operating profit increased 11% to $3.2B. Operating margin decreased due to the prior year impact of the Chubb and Toshiba Carrier-related gains. Adjusted operating margin increased despite the impact from the consolidation of Toshiba Carrier. Strong price realization more than offset continued inflation and productivity savings more than offset strategic incremental investments.

[0001783180-24-000007:8k_2_02:33]
GAAP EPS was $1.58 and adjusted EPS was $2.73. Net income was $1.3B, and adjusted net income was $2.3B. Net cash flows provided by operating activities were $2.6B and capital expenditures were $469M, resulting in free cash flow of $2.1B. During the quarter the company issued $5.6B of debt related to the acquisition of Viessmann Climate Solutions.

[0001783180-24-000007:8k_2_02:34]
Full-Year 2024 Guidance

[0001783180-24-000007:8k_2_02:35]
Carrier is announcing the following outlook for 2024:

[0001783180-24-000007:8k_2_02:36]
|  | 2024 Guidance** |
| Sales | ~$26.5B Organic* up MSDFX 0%Acquisitions +20%Divestitures (5%) |
| Adjusted Operating Margin* | 15.0% - 15.5% |
| Adjusted EPS* | $2.80 - $2.90 |
| Free Cash Flow* | ~$0.7BIncludes $1.7B of expected tax payments on the gains from the announced business exits, restructuring, and transaction-related costs |

[0001783180-24-000007:8k_2_02:37]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-24-000007:8k_2_02:38]
**As of February 6, 2024

[0001783180-24-000007:8k_2_02:39]
3

[0001783180-24-000007:8k_2_02:40]
Conference Call

[0001783180-24-000007:8k_2_02:41]
Carrier will host a webcast of its earnings conference call today, Tuesday, February 6, 2024, at 7:30 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at ir.carrier.com/news-and-events/events-and-presentations or to listen to the earnings call by phone, participants must pre-register at Carrier Earnings Call Registration. All registrants will receive dial-in information and a PIN allowing access to the live call.

[0001783180-24-000007:8k_2_02:42]
Cautionary Statement

[0001783180-24-000007:8k_2_02:43]
This communication contains statements which, to the extent they are not statements of historical or present fact, constitute "forward-looking statements" under the securities laws. These forward-looking statements are intended to provide management's current expectations or plans for Carrier's future operating and financial performance, based on assumptions currently believed to be valid. Forward-looking statements can be identified by the use of words such as "believe," "expect," "expectations," "plans," "strategy," "prospects," "estimate," "project," "target," "anticipate," "will," "should," "see," "guidance," "outlook," "confident," "scenario" and other words of similar meaning in connection with a discussion of future operating or financial performance. Forward-looking statements may include, among other things, statements relating to future sales, earnings, cash flow, results of operations, uses of cash, share repurchases, tax rates and other measures of financial performance or potential future plans, strategies or transactions of Carrier, Carrier's plans with respect to its indebtedness and other statements that are not historical facts. All forward-looking statements involve risks, uncertainties and other factors that may cause actual results to differ materially from those expressed or implied in the forward-looking statements. For additional information on identifying factors that may cause actual results to vary materially from those stated in forward-looking statements, see Carrier's reports on Forms 10-K, 10-Q and 8-K filed with or furnished to the U.S. Securities and Exchange Commission from time to time. Any forward-looking statement speaks only as of the date on which it is made, and Carrier assumes no obligation to update or revise such statement, whether as a result of new information, future events or otherwise, except as required by applicable law.

[0001783180-24-000007:8k_2_02:44]
About Carrier

[0001783180-24-000007:8k_2_02:45]
Carrier Global Corporation, global leader in intelligent climate and energy solutions, is committed to creating solutions that matter for people and our planet for generations to come. From the beginning, we've led in inventing new technologies and entirely new industries. Today, we continue to lead because we have a world-class, diverse workforce that puts the customer at the center of everything we do. For more information, visit corporate.carrier.com or follow Carrier on social media at @Carrier.

[0001783180-24-000007:8k_2_02:46]
4

[0001783180-24-000007:8k_2_02:47]
Contact:

[0001783180-24-000007:8k_2_02:48]
Investor Relations

[0001783180-24-000007:8k_2_02:49]
Sam Pearlstein

[0001783180-24-000007:8k_2_02:50]
561-365-2251

[0001783180-24-000007:8k_2_02:51]
Sam.Pearlstein@Carrier.com

[0001783180-24-000007:8k_2_02:52]
Media Inquiries

[0001783180-24-000007:8k_2_02:53]
Ashley Barrie

[0001783180-24-000007:8k_2_02:54]
561-365-1260

[0001783180-24-000007:8k_2_02:55]
Ashley.Barrie@Carrier.com

[0001783180-24-000007:8k_2_02:56]
SELECTED FINANCIAL DATA, NON-GAAP MEASURES AND DEFINITIONS

[0001783180-24-000007:8k_2_02:57]
Following are tables that present selected financial data of Carrier Global Corporation. Also included are reconciliations of non-GAAP measures to their most comparable GAAP measures.

[0001783180-24-000007:8k_2_02:58]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-24-000007:8k_2_02:59]
Carrier Global Corporation (“we” or "our") reports its financial results in accordance with accounting principles generally accepted in the United States ("GAAP"). We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables in this Appendix. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-24-000007:8k_2_02:60]
Organic sales, adjusted operating profit, adjusted operating margin, incremental margins / earnings conversion, earnings before interest, taxes and depreciation and amortization (“EBITDA”), adjusted EBITDA, adjusted net income, adjusted earnings per share (“EPS”), adjusted interest expense, net, adjusted effective tax rate and net debt are non-GAAP financial measures.

[0001783180-24-000007:8k_2_02:61]
Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a nonoperational nature (hereinafter referred to as “other significant items”). Adjusted operating profit represents operating profit (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted operating margin represents adjusted operating profit as a percentage of net sales (a GAAP measure). Incremental margins / earnings conversion represents the year-over-year change in adjusted operating profit divided by the year-over-year change in net sales. EBITDA represents net income attributable to common shareholders (a GAAP measure), adjusted for interest income and expense, income tax expense, and depreciation and amortization. Adjusted EBITDA represents EBITDA, as calculated above, excluding non-service pension benefit, non-controlling interest in subsidiaries’ earnings from operations, restructuring costs and other significant items. Adjusted net income represents net income attributable to common shareowners (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted interest expense, net represents interest expense (a GAAP measure) and interest income (a GAAP measure), net excluding other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents (a GAAP measure). For the business segments,

[0001783180-24-000007:8k_2_02:62]
5

[0001783180-24-000007:8k_2_02:63]
when applicable, adjustments of operating profit and operating margins represent operating profit, excluding restructuring, amortization of acquired intangibles and other significant items.

[0001783180-24-000007:8k_2_02:64]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by operating activities (a GAAP measure) less capital expenditures. Management believes free cash flow is a useful measure of liquidity and an additional basis for assessing our ability to fund its activities, including the financing of acquisitions, debt service, repurchases of our common stock and distribution of earnings to shareowners.

[0001783180-24-000007:8k_2_02:65]
Orders are contractual commitments with customers to provide specified goods or services for an agreed upon price and may not be subject to penalty if cancelled.

[0001783180-24-000007:8k_2_02:66]
When we provide our expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted interest expense, net, adjusted effective tax rate, incremental margins/earnings conversion, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures (expected net sales, operating profit, operating margin, interest expense, effective tax rate, incremental operating margin, diluted EPS and net cash flows provided by operating activities) generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-24-000007:8k_2_02:67]
6

[0001783180-24-000007:8k_2_02:68]
Carrier Global Corporation

[0001783180-24-000007:8k_2_02:69]
Consolidated Statement of Operations

[0001783180-24-000007:8k_2_02:70]
|  | (Unaudited) |
|  | Three Months Ended December 31, |  | Year Ended December 31, |
| (In millions, except per share amounts) | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales |  |  |  |  |  |  |  |
| Product sales | $ | 4,441 |  |  | $ | 4,527 |  |  | $ | 19,563 |  |  | $ | 18,250 |  |
| Service sales | 661 |  |  | 578 |  |  | 2,535 |  |  | 2,171 |  |
| Total Net sales | 5,102 |  |  | 5,105 |  |  | 22,098 |  |  | 20,421 |  |
| Costs and expenses |  |  |  |  |  |  |  |
| Cost of products sold | (3,176) |  |  | (3,407) |  |  | (13,831) |  |  | (13,337) |  |
| Cost of services sold | (492) |  |  | (451) |  |  | (1,884) |  |  | (1,620) |  |
| Research and development | (170) |  |  | (149) |  |  | (617) |  |  | (539) |  |
| Selling, general and administrative | (961) |  |  | (673) |  |  | (3,297) |  |  | (2,512) |  |
| Total Costs and expenses | (4,799) |  |  | (4,680) |  |  | (19,629) |  |  | (18,008) |  |
| Equity method investment net earnings | 40 |  |  | 40 |  |  | 211 |  |  | 262 |  |
| Other income (expense), net | 264 |  |  | (32) |  |  | (384) |  |  | 1,840 |  |
| Operating profit | 607 |  |  | 433 |  |  | 2,296 |  |  | 4,515 |  |
| Non-service pension benefit (expense) | (1) |  |  | (2) |  |  | (1) |  |  | (4) |  |
| Interest (expense) income, net | (47) |  |  | (54) |  |  | (211) |  |  | (219) |  |
| Income from operations before income taxes | 559 |  |  | 377 |  |  | 2,084 |  |  | 4,292 |  |
| Income tax expense | (120) |  |  | (99) |  |  | (644) |  |  | (708) |  |
| Net income from operations | 439 |  |  | 278 |  |  | 1,440 |  |  | 3,584 |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations | 19 |  |  | 8 |  |  | 91 |  |  | 50 |  |
| Net income attributable to common shareowners | $ | 420 |  |  | $ | 270 |  |  | $ | 1,349 |  |  | $ | 3,534 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 0.50 |  |  | $ | 0.32 |  |  | $ | 1.61 |  |  | $ | 4.19 |  |
| Diluted | $ | 0.49 |  |  | $ | 0.32 |  |  | $ | 1.58 |  |  | $ | 4.10 |  |
| Weighted-average number of shares outstanding |  |  |  |  |  |  |  |
| Basic | 839.6 |  | 835.6 |  | 837.3 |  | 843.4 |
| Diluted | 854.2 |  | 852.2 |  | 853.0 |  | 861.2 |

[0001783180-24-000007:8k_2_02:71]
7

[0001783180-24-000007:8k_2_02:72]
Carrier Global Corporation

[0001783180-24-000007:8k_2_02:73]
Consolidated Balance Sheet

[0001783180-24-000007:8k_2_02:74]
|  | (Unaudited) |
|  | As of December 31, |
| (In millions) | 2023 |  | 2022 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 10,015 |  |  | $ | 3,520 |  |
| Accounts receivable, net | 2,481 |  |  | 2,833 |  |
| Contract assets, current | 306 |  |  | 537 |  |
| Inventories, net | 2,217 |  |  | 2,640 |  |
| Assets held for sale | 3,314 |  |  | — |  |
| Other assets, current | 447 |  |  | 349 |  |
| Total current assets | 18,780 |  |  | 9,879 |  |
| Future income tax benefits | 739 |  |  | 612 |  |
| Fixed assets, net | 2,293 |  |  | 2,241 |  |
| Operating lease right-of-use assets | 491 |  |  | 642 |  |
| Intangible assets, net | 1,028 |  |  | 1,342 |  |
| Goodwill | 7,989 |  |  | 9,977 |  |
| Pension and post-retirement assets | 32 |  |  | 26 |  |
| Equity method investments | 1,140 |  |  | 1,148 |  |
| Other assets | 330 |  |  | 219 |  |
| Total Assets | $ | 32,822 |  |  | $ | 26,086 |  |
| Liabilities and Equity |  |  |  |
| Accounts payable | $ | 2,742 |  |  | $ | 2,833 |  |
| Accrued liabilities | 2,811 |  |  | 2,610 |  |
| Contract liabilities, current | 425 |  |  | 449 |  |
| Liabilities held for sale | 862 |  |  | — |  |
| Current portion of long-term debt | 51 |  |  | 140 |  |
| Total current liabilities | 6,891 |  |  | 6,032 |  |
| Long-term debt | 14,242 |  |  | 8,702 |  |
| Future pension and post-retirement obligations | 155 |  |  | 349 |  |
| Future income tax obligations | 535 |  |  | 568 |  |
| Operating lease liabilities | 391 |  |  | 529 |  |
| Other long-term liabilities | 1,603 |  |  | 1,830 |  |
| Total Liabilities | 23,817 |  |  | 18,010 |  |
| Equity |  |  |  |
| Common stock, par value $0.01; 4,000,000,000 shares authorized; 883,068,393 and 876,487,480 shares issued; 839,910,275 and 834,664,966 outstanding as of December 31, 2023 and 2022, respectively | 9 |  |  | 9 |  |
| Treasury stock | (1,972) |  |  | (1,910) |  |
| Additional paid-in capital | 5,535 |  |  | 5,481 |  |
| Retained earnings | 6,591 |  |  | 5,866 |  |
| Accumulated other comprehensive loss | (1,486) |  |  | (1,688) |  |
| Non-controlling interest | 328 |  |  | 318 |  |
| Total Equity | 9,005 |  |  | 8,076 |  |
| Total Liabilities and Equity | $ | 32,822 |  |  | $ | 26,086 |  |

[0001783180-24-000007:8k_2_02:75]
8

[0001783180-24-000007:8k_2_02:76]
Carrier Global Corporation

[0001783180-24-000007:8k_2_02:77]
Consolidated Statement of Cash Flows

[0001783180-24-000007:8k_2_02:78]
|  |  |  |  | (Unaudited) |
|  |  | Year Ended December 31, |
| (In millions) |  |  |  | 2023 |  | 2022 |
| Operating Activities |  |  |  |  |  |  |
| Net income from operations |  |  |  | $ | 1,440 |  |  | $ | 3,584 |  |
| Adjustments to reconcile net income from operations to net cash flows from operating activities |  |  |  |  |  |  |
| Depreciation and amortization |  |  |  | 542 |  |  | 380 |  |
| Deferred income tax provision |  |  |  | (233) |  |  | (124) |  |
| Stock-based compensation cost |  |  |  | 81 |  |  | 77 |  |
| Equity method investment net earnings |  |  |  | (211) |  |  | (262) |  |
| (Gain) loss on extinguishment of debt |  |  |  | — |  |  | (36) |  |
| (Gain) loss on sale of investments / deconsolidation |  |  |  | 278 |  |  | (1,815) |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |
| Accounts receivable, net |  |  |  | (148) |  |  | (145) |  |
| Contract assets, current |  |  |  | 93 |  |  | (51) |  |
| Inventories, net |  |  |  | 237 |  |  | (334) |  |
| Other assets, current |  |  |  | (117) |  |  | 104 |  |
| Accounts payable and accrued liabilities |  |  |  | 477 |  |  | 61 |  |
| Contract liabilities, current |  |  |  | 74 |  |  | 29 |  |
| Defined benefit plan contributions |  |  |  | (33) |  |  | (16) |  |
| Distributions from equity method investments |  |  |  | 129 |  |  | 148 |  |
| Other operating activities, net |  |  |  | (2) |  |  | 143 |  |
| Net cash flows provided by (used in) operating activities |  |  |  | 2,607 |  |  | 1,743 |  |
| Investing Activities |  |  |  |  |  |  |
| Capital expenditures |  |  |  | (469) |  |  | (353) |  |
| Investment in businesses, net of cash acquired |  |  |  | (84) |  |  | (506) |  |
| Dispositions of businesses |  |  |  | 54 |  |  | 2,902 |  |
| Settlement of derivative contracts, net |  |  |  | (50) |  |  | (194) |  |
| Payment to former shareholders of TCC |  |  |  | — |  |  | (104) |  |
| Kidde-Fenwal, Inc. deconsolidation |  |  |  | (134) |  |  | — |  |
| Other investing activities, net |  |  |  | 23 |  |  | — |  |
| Net cash flows provided by (used in) investing activities |  |  |  | (660) |  |  | 1,745 |  |
| Financing Activities |  |  |  |  |  |  |
| (Decrease) increase in short-term borrowings, net |  |  |  | (15) |  |  | (140) |  |
| Issuance of long-term debt |  |  |  | 5,609 |  |  | 432 |  |
| Repayment of long-term debt |  |  |  | (111) |  |  | (1,275) |  |
| Repurchases of common stock |  |  |  | (62) |  |  | (1,380) |  |
| Dividends paid on common stock |  |  |  | (620) |  |  | (509) |  |
| Dividends paid to non-controlling interest |  |  |  | (58) |  |  | (46) |  |
| Other financing activities, net |  |  |  | (131) |  |  | (13) |  |
| Net cash flows provided by (used in) financing activities |  |  |  | 4,612 |  |  | (2,931) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  |  | 88 |  |  | (56) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash, including cash classified in current assets held for sale |  |  |  | 6,647 |  |  | 501 |  |
| Less: Change in cash balances classified as assets held for sale |  |  |  | 157 |  |  | — |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  |  |  | 6,490 |  |  | 501 |  |
| Cash, cash equivalents and restricted cash, beginning of period |  |  |  | 3,527 |  |  | 3,026 |  |
| Cash, cash equivalents and restricted cash, end of period |  |  |  | 10,017 |  |  | 3,527 |  |
| Less: restricted cash |  |  |  | 2 |  |  | 7 |  |
| Cash and cash equivalents, end of period |  |  |  | $ | 10,015 |  |  | $ | 3,520 |  |

[0001783180-24-000007:8k_2_02:79]
9

[0001783180-24-000007:8k_2_02:80]
Carrier Global Corporation

[0001783180-24-000007:8k_2_02:81]
Segment Net Sales and Operating Profit

[0001783180-24-000007:8k_2_02:82]
|  | (Unaudited) |
|  | Three Months Ended December 31, |  | Year Ended December 31, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| (In millions) | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 3,293 |  | $ | 3,293 |  | $ | 3,316 |  | $ | 3,316 |  | $ | 15,139 |  | $ | 15,139 |  | $ | 13,408 |  | $ | 13,408 |
| Refrigeration | 1,024 |  | 1,024 |  | 943 |  | 943 |  | 3,818 |  | 3,818 |  | 3,883 |  | 3,883 |
| Fire & Security | 909 |  | 909 |  | 960 |  | 960 |  | 3,633 |  | 3,633 |  | 3,570 |  | 3,570 |
| Segment sales | 5,226 |  | 5,226 |  | 5,219 |  | 5,219 |  | 22,590 |  | 22,590 |  | 20,861 |  | 20,861 |
| Eliminations and other | (124) |  | (124) |  | (114) |  | (114) |  | (492) |  | (492) |  | (440) |  | (440) |
| Net sales | $ | 5,102 |  | $ | 5,102 |  | $ | 5,105 |  | $ | 5,105 |  | $ | 22,098 |  | $ | 22,098 |  | $ | 20,421 |  | $ | 20,421 |
| Operating profit |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 335 |  | $ | 397 |  | $ | 241 |  | $ | 317 |  | $ | 2,275 |  | $ | 2,511 |  | $ | 2,610 |  | $ | 2,032 |
| Refrigeration | 101 |  | 108 |  | 113 |  | 114 |  | 428 |  | 449 |  | 483 |  | 496 |
| Fire & Security | 109 |  | 129 |  | 136 |  | 139 |  | 209 |  | 543 |  | 1,630 |  | 541 |
| Segment operating profit | 545 |  | 634 |  | 490 |  | 570 |  | 2,912 |  | 3,503 |  | 4,723 |  | 3,069 |
| Eliminations and other | 207 |  | (55) |  | (30) |  | (30) |  | (275) |  | (166) |  | (80) |  | (78) |
| General corporate expenses | (145) |  | (22) |  | (27) |  | (24) |  | (341) |  | (130) |  | (128) |  | (97) |
| Operating profit | $ | 607 |  | $ | 557 |  | $ | 433 |  | $ | 516 |  | $ | 2,296 |  | $ | 3,207 |  | $ | 4,515 |  | $ | 2,894 |
| Operating margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | 10.2 | % |  | 12.1 | % |  | 7.3 | % |  | 9.6 | % |  | 15.0 | % |  | 16.6 | % |  | 19.5 | % |  | 15.2 | % |
| Refrigeration | 9.9 | % |  | 10.5 | % |  | 12.0 | % |  | 12.1 | % |  | 11.2 | % |  | 11.8 | % |  | 12.4 | % |  | 12.8 | % |
| Fire & Security | 12.0 | % |  | 14.2 | % |  | 14.2 | % |  | 14.5 | % |  | 5.8 | % |  | 14.9 | % |  | 45.7 | % |  | 15.2 | % |
| Total Carrier | 11.9 | % |  | 10.9 | % |  | 8.5 | % |  | 10.1 | % |  | 10.4 | % |  | 14.5 | % |  | 22.1 | % |  | 14.2 | % |

[0001783180-24-000007:8k_2_02:83]
10

[0001783180-24-000007:8k_2_02:84]
Carrier Global Corporation

[0001783180-24-000007:8k_2_02:85]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-24-000007:8k_2_02:86]
Operating Profit

[0001783180-24-000007:8k_2_02:87]
|  | (Unaudited) |
|  | Three Months Ended December 31, 2023 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 3,293 |  |  | $ | 1,024 |  |  | $ | 909 |  |  | $ | (124) |  |  | $ | — |  |  | $ | 5,102 |  |
| Segment operating profit | $ | 335 |  |  | $ | 101 |  |  | $ | 109 |  |  | $ | 207 |  |  | $ | (145) |  |  | $ | 607 |  |
| Reported operating margin | 10.2 | % |  | 9.9 | % |  | 12.0 | % |  |  |  |  |  | 11.9 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 17 |  |  | $ | 7 |  |  | $ | 11 |  |  | $ | 8 |  |  | $ | — |  |  | $ | 43 |  |
| Amortization of acquired intangibles | 35 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 35 |  |
| Acquisition step-up amortization (1) | 10 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 10 |  |
| Acquisition/divestiture-related costs | — |  |  | — |  |  | 9 |  |  | — |  |  | 123 |  |  | 132 |  |
| Bridge loan financing costs | — |  |  | — |  |  | — |  |  | 2 |  |  | — |  |  | 2 |  |
| Viessmann-related hedges | — |  |  | — |  |  | — |  |  | (272) |  |  | — |  |  | (272) |  |
| Total adjustments to operating profit | $ | 62 |  |  | $ | 7 |  |  | $ | 20 |  |  | $ | (262) |  |  | $ | 123 |  |  | $ | (50) |  |
| Adjusted operating profit | $ | 397 |  |  | $ | 108 |  |  | $ | 129 |  |  | $ | (55) |  |  | $ | (22) |  |  | $ | 557 |  |
| Adjusted operating margin | 12.1 | % |  | 10.5 | % |  | 14.2 | % |  |  |  |  |  | 10.9 | % |

[0001783180-24-000007:8k_2_02:88]
|  | (Unaudited) |
|  | Three Months Ended December 31, 2022 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 3,316 |  |  | $ | 943 |  |  | $ | 960 |  |  | $ | (114) |  |  | $ | — |  |  | $ | 5,105 |  |
| Segment operating profit | $ | 241 |  |  | $ | 113 |  |  | $ | 136 |  |  | $ | (30) |  |  | $ | (27) |  |  | $ | 433 |  |
| Reported operating margin | 7.3 | % |  | 12.0 | % |  | 14.2 | % |  |  |  |  |  | 8.5 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | — |  |  | $ | 1 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 2 |  |
| Amortization of acquired intangibles | 22 |  |  | — |  |  | 1 |  |  | — |  |  | — |  |  | 23 |  |
| Acquisition step-up amortization (1) | 27 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 27 |  |
| Acquisition/divestiture-related costs | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | 3 |  |
| TCC acquisition-related gain (2) | 27 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 27 |  |
| Russia/Ukraine asset impairment | — |  |  | — |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Total adjustments to operating profit | $ | 76 |  |  | $ | 1 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 3 |  |  | $ | 83 |  |
| Adjusted operating profit | $ | 317 |  |  | $ | 114 |  |  | $ | 139 |  |  | $ | (30) |  |  | $ | (24) |  |  | $ | 516 |  |
| Adjusted operating margin | 9.6 | % |  | 12.1 | % |  | 14.5 | % |  |  |  |  |  | 10.1 | % |

[0001783180-24-000007:8k_2_02:89]
(1)  Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-24-000007:8k_2_02:90]
(2) The carrying value of our previously held TCC equity investments were recognized at fair value at the TCC acquisition date.

[0001783180-24-000007:8k_2_02:91]
11

[0001783180-24-000007:8k_2_02:92]
Carrier Global Corporation

[0001783180-24-000007:8k_2_02:93]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-24-000007:8k_2_02:94]
Operating Profit

[0001783180-24-000007:8k_2_02:95]
|  | (Unaudited) |
|  | Year Ended December 31, 2023 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 15,139 |  |  | $ | 3,818 |  |  | $ | 3,633 |  |  | $ | (492) |  |  | $ | — |  |  | $ | 22,098 |  |
| Segment operating profit | $ | 2,275 |  |  | $ | 428 |  |  | $ | 209 |  |  | $ | (275) |  |  | $ | (341) |  |  | $ | 2,296 |  |
| Reported operating margin | 15.0 | % |  | 11.2 | % |  | 5.8 | % |  |  |  |  |  | 10.4 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 44 |  |  | $ | 21 |  |  | $ | 22 |  |  | $ | 10 |  |  | $ | — |  |  | $ | 97 |  |
| Amortization of acquired intangibles | 143 |  |  | — |  |  | 6 |  |  | — |  |  | — |  |  | 149 |  |
| Acquisition step-up amortization (1) | 41 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 41 |  |
| Acquisition/divestiture-related costs | — |  |  | — |  |  | 9 |  |  | — |  |  | 211 |  |  | 220 |  |
| Bridge loan financing costs | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| TCC acquisition-related gain (2) | 8 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 8 |  |
| Viessmann-related hedges | — |  |  | — |  |  | — |  |  | 96 |  |  | — |  |  | 96 |  |
| KFI deconsolidation | — |  |  | — |  |  | 297 |  |  | — |  |  | — |  |  | 297 |  |
| Total adjustments to operating profit | $ | 236 |  |  | $ | 21 |  |  | $ | 334 |  |  | $ | 109 |  |  | $ | 211 |  |  | $ | 911 |  |
| Adjusted operating profit | $ | 2,511 |  |  | $ | 449 |  |  | $ | 543 |  |  | $ | (166) |  |  | $ | (130) |  |  | $ | 3,207 |  |
| Adjusted operating margin | 16.6 | % |  | 11.8 | % |  | 14.9 | % |  |  |  |  |  | 14.5 | % |

[0001783180-24-000007:8k_2_02:96]
|  | (Unaudited) |
|  | Year Ended December 31, 2022 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 13,408 |  |  | $ | 3,883 |  |  | $ | 3,570 |  |  | $ | (440) |  |  | $ | — |  |  | $ | 20,421 |  |
| Segment operating profit | $ | 2,610 |  |  | $ | 483 |  |  | $ | 1,630 |  |  | $ | (80) |  |  | $ | (128) |  |  | $ | 4,515 |  |
| Reported operating margin | 19.5 | % |  | 12.4 | % |  | 45.7 | % |  |  |  |  |  | 22.1 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring Cost | $ | 8 |  |  | $ | 10 |  |  | $ | 11 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 31 |  |
| Amortization of acquired intangibles | 46 |  |  | — |  |  | 4 |  |  | — |  |  | — |  |  | 50 |  |
| Acquisition step-up amortization (1) | 51 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 51 |  |
| Acquisition/divestiture-related costs | — |  |  | — |  |  | — |  |  | — |  |  | 31 |  |  | 31 |  |
| Chubb gain | — |  |  | — |  |  | (1,105) |  |  | — |  |  | — |  |  | (1,105) |  |
| TCC acquisition-related gain (2) | (705) |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (705) |  |
| Russia/Ukraine asset impairment | — |  |  | 3 |  |  | 1 |  |  | — |  |  | — |  |  | 4 |  |
| Charge resulting from legal matter | 22 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 22 |  |
| Total adjustments to operating profit | $ | (578) |  |  | $ | 13 |  |  | $ | (1,089) |  |  | $ | 2 |  |  | $ | 31 |  |  | $ | (1,621) |  |
| Adjusted operating profit | $ | 2,032 |  |  | $ | 496 |  |  | $ | 541 |  |  | $ | (78) |  |  | $ | (97) |  |  | $ | 2,894 |  |
| Adjusted operating margin | 15.2 | % |  | 12.8 | % |  | 15.2 | % |  |  |  |  |  | 14.2 | % |

[0001783180-24-000007:8k_2_02:97]
(1)  Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-24-000007:8k_2_02:98]
(2) The carrying value of our previously held TCC equity investments were recognized at fair value at the TCC acquisition date.

[0001783180-24-000007:8k_2_02:99]
Carrier Global Corporation

[0001783180-24-000007:8k_2_02:100]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-24-000007:8k_2_02:101]
Net Income, Earnings Per Share, and Effective Tax Rate

[0001783180-24-000007:8k_2_02:102]
|  | (Unaudited) |
|  | Three Months Ended December 31, 2023 |  | Year Ended December 31, 2023 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,102 |  |  | $ | — |  |  | $ | 5,102 |  |  | $ | 22,098 |  |  | $ | — |  |  | $ | 22,098 |  |
| Operating profit | $ | 607 |  |  | (50) |  | a | $ | 557 |  |  | $ | 2,296 |  |  | 911 |  | a | $ | 3,207 |  |
| Operating margin | 11.9 | % |  |  |  | 10.9 | % |  | 10.4 | % |  |  |  | 14.5 | % |
| Income from operations before income taxes | $ | 559 |  |  | (33) |  | a,b | $ | 526 |  |  | $ | 2,084 |  |  | 960 |  | a,b | $ | 3,044 |  |
| Income tax expense | $ | (120) |  |  | 65 |  | c | $ | (55) |  |  | $ | (644) |  |  | 20 |  | c | $ | (624) |  |
| Income tax rate | 21.5 | % |  |  |  | 10.5 | % |  | 30.9 | % |  |  |  | 20.5 | % |
| Net income attributable to common shareowners | $ | 420 |  |  | $ | 32 |  |  | $ | 452 |  |  | $ | 1,349 |  |  | $ | 980 |  |  | $ | 2,329 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 43 |  | a |  |  |  |  | $ | 97 |  | a |  |
| Amortization of acquired intangibles |  |  | 35 |  | a |  |  |  |  | 149 |  | a |  |
| Acquisition step-up amortization (1) |  |  | 10 |  | a |  |  |  |  | 41 |  | a |  |
| Acquisition/divestiture-related costs |  |  | 132 |  | a |  |  |  |  | 220 |  | a |  |
| Viessmann-related hedges |  |  | (272) |  | a |  |  |  |  | 96 |  | a |  |
| TCC acquisition-related gain (2) |  |  | — |  | a |  |  |  |  | 8 |  | a |  |
| KFI deconsolidation |  |  | — |  | a |  |  |  |  | 297 |  | a |  |
| Bridge loan financing costs (3) |  |  | 19 |  | a, b |  |  |  |  | 52 |  | a, b |  |
| Total adjustments |  |  | $ | (33) |  |  |  |  |  |  | $ | 960 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (36) |  |  |  |  |  |  | $ | (114) |  |  |  |
| Tax specific adjustments |  |  | 101 |  |  |  |  |  |  | 134 |  |  |  |
| Total tax adjustments |  |  | $ | 65 |  | c |  |  |  |  | $ | 20 |  | c |  |
| Shares outstanding - Diluted | 854.2 |  |  |  |  | 854.2 |  |  | 853.0 |  |  |  |  | 853.0 |  |
| Earnings per share - Diluted | $ | 0.49 |  |  |  |  | $ | 0.53 |  |  | $ | 1.58 |  |  |  |  | $ | 2.73 |  |

[0001783180-24-000007:8k_2_02:103]
(1)  Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-24-000007:8k_2_02:104]
(2)  The carrying value of our previously held TCC equity investments were recognized at fair value and subsequently adjusted.

[0001783180-24-000007:8k_2_02:105]
(3)  Includes commitment fees recognized in Operating profit.

[0001783180-24-000007:8k_2_02:106]
13

[0001783180-24-000007:8k_2_02:107]
Carrier Global Corporation

[0001783180-24-000007:8k_2_02:108]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-24-000007:8k_2_02:109]
Net Income, Earnings Per Share, and Effective Tax Rate

[0001783180-24-000007:8k_2_02:110]
|  | (Unaudited) |
|  | Three Months Ended December 31, 2022 |  | Year Ended December 31, 2022 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,105 |  |  | $ | — |  |  | $ | 5,105 |  |  | $ | 20,421 |  |  | $ | — |  |  | $ | 20,421 |  |
| Operating profit | $ | 433 |  |  | 83 |  | a | $ | 516 |  |  | $ | 4,515 |  |  | (1,621) |  | a | $ | 2,894 |  |
| Operating margin | 8.5 | % |  |  |  | 10.1 | % |  | 22.1 | % |  |  |  | 14.2 | % |
| Income from operations before income taxes | $ | 377 |  |  | 83 |  | a | $ | 460 |  |  | $ | 4,292 |  |  | (1,649) |  | a, b | $ | 2,643 |  |
| Income tax expense | $ | (99) |  |  | (13) |  | c | $ | (112) |  |  | $ | (708) |  |  | 135 |  | c | $ | (573) |  |
| Income tax rate | 26.3 | % |  |  |  | 24.3 | % |  | 16.5 | % |  |  |  | 21.7 | % |
| Net income attributable to common shareowners | $ | 270 |  |  | $ | 70 |  |  | $ | 340 |  |  | $ | 3,534 |  |  | $ | (1,514) |  |  | $ | 2,020 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 2 |  | a |  |  |  |  | $ | 31 |  | a |  |
| Amortization of acquired intangibles |  |  | 23 |  | a |  |  |  |  | 50 |  | a |  |
| Acquisition step-up amortization (1) |  |  | 27 |  | a |  |  |  |  | 51 |  | a |  |
| Acquisition/divestiture-related costs |  |  | 3 |  | a |  |  |  |  | 31 |  | a |  |
| Chubb gain |  |  | — |  | a |  |  |  |  | (1,105) |  | a |  |
| TCC acquisition-related gain (2) |  |  | 27 |  | a |  |  |  |  | (705) |  | a |  |
| Russia/Ukraine asset impairment |  |  | 1 |  | a |  |  |  |  | 4 |  | a |  |
| Charge resulting from legal matter |  |  | — |  | a |  |  |  |  | 22 |  | a |  |
| Debt extinguishment (gain), net (3) |  |  | — |  | b |  |  |  |  | (28) |  | b |  |
| Total adjustments |  |  | $ | 83 |  |  |  |  |  |  | $ | (1,649) |  |  |  |
| Tax effect on adjustments above |  |  | $ | (13) |  |  |  |  |  |  | $ | 172 |  |  |  |
| Tax specific adjustments |  |  | — |  |  |  |  |  |  | (37) |  |  |  |
| Total tax adjustments |  |  | $ | (13) |  | c |  |  |  |  | $ | 135 |  | c |  |
| Shares outstanding - Diluted | 852.2 |  |  |  |  | 852.2 |  |  | 861.2 |  |  |  |  | 861.2 |  |
| Earnings per share - Diluted | $ | 0.32 |  |  |  |  | $ | 0.40 |  |  | $ | 4.10 |  |  |  |  | $ | 2.34 |  |

[0001783180-24-000007:8k_2_02:111]
(1) Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-24-000007:8k_2_02:112]
(2) The carrying value of our previously held TCC equity investments were recognized at fair value at the TCC acquisition date.

[0001783180-24-000007:8k_2_02:113]
(3)  The Company repurchased approximately $1.15 billion of aggregate principal senior notes on March 30, 2022 and recognized a net gain of $33 million and wrote-off $5 million of unamortized deferred financing costs in Interest (expense) income, net.

[0001783180-24-000007:8k_2_02:114]
Carrier Global Corporation

[0001783180-24-000007:8k_2_02:115]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-24-000007:8k_2_02:116]
Components of Changes in Net Sales

[0001783180-24-000007:8k_2_02:117]
Three Months Ended December 31, 2023 Compared with Three Months Ended December 31, 2022

[0001783180-24-000007:8k_2_02:118]
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | (1)% |  | 1% |  | (1)% |  | —% |  | (1)% |
| Refrigeration | 6% |  | 3% |  | —% |  | —% |  | 9% |
| Fire & Security | (1)% |  | 1% |  | (5)% |  | —% |  | (5)% |
| Consolidated | —% |  | 1% |  | (1)% |  | —% |  | —% |

[0001783180-24-000007:8k_2_02:119]
Year Ended December 31, 2023 Compared with Year Ended December 31, 2022

[0001783180-24-000007:8k_2_02:120]
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 5% |  | (1)% |  | 9% |  | —% |  | 13% |
| Refrigeration | (2)% |  | 1% |  | (1)% |  | —% |  | (2)% |
| Fire & Security | 6% |  | (1)% |  | (3)% |  | —% |  | 2% |
| Consolidated | 3% |  | —% |  | 5% |  | —% |  | 8% |

[0001783180-24-000007:8k_2_02:121]
Historical Amounts of Amortization of Acquired Intangibles

[0001783180-24-000007:8k_2_02:122]
|  |  | (Unaudited) |  |  |  |  |
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |
| (In millions) |  | 2022 |  | 2022 |  | 2022 |  | 2022 |  | 2022 |  | 2023 |  | 2023 |  | 2023 |  | 2023 |  | 2023 |
| HVAC |  | $ | 4 |  |  | $ | 4 |  |  | $ | 16 |  |  | $ | 22 |  |  | $ | 46 |  |  | $ | 37 |  |  | $ | 36 |  |  | $ | 35 |  |  | $ | 35 |  |  | $ | 143 |  |
| Fire & Security |  | 1 |  |  | 1 |  |  | 1 |  |  | 1 |  |  | 4 |  |  | 2 |  |  | 2 |  |  | 2 |  |  | — |  |  | 6 |  |
| Total Carrier |  | 5 |  |  | 5 |  |  | 17 |  |  | 23 |  | 50 |  |  | 39 |  |  | 38 |  |  | 37 |  |  | 35 |  |  | 149 |  |
| Associated tax effect |  | (1) |  |  | (1) |  |  | (7) |  |  | (4) |  |  | (13) |  |  | (12) |  |  | (11) |  |  | (11) |  |  | (11) |  |  | (45) |  |
| Net impact to adjusted results |  | $ | 4 |  |  | $ | 4 |  |  | $ | 10 |  |  | $ | 19 |  |  | $ | 37 |  |  | $ | 27 |  |  | $ | 27 |  |  | $ | 26 |  |  | $ | 24 |  |  | $ | 104 |  |

[0001783180-24-000007:8k_2_02:123]
Free Cash Flow Reconciliation

[0001783180-24-000007:8k_2_02:124]
|  |  | (Unaudited) |  |
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |
| (In millions) |  | 2022 |  | 2022 |  | 2022 |  | 2022 |  | 2022 |  | 2023 |  | 2023 |  | 2023 |  | 2023 |  | 2023 |
| Net cash flows provided by operating activities |  | $ | (202) |  |  | $ | 32 |  |  | $ | 790 |  |  | $ | 1,123 |  |  | $ | 1,743 |  |  | $ | 120 |  |  | $ | 384 |  |  | $ | 1,041 |  |  | $ | 1,062 |  |  | $ | 2,607 |  |
| Less: Capital expenditures |  | 56 |  |  | 66 |  |  | 91 |  |  | 140 |  |  | 353 |  |  | 70 |  |  | 74 |  |  | 92 |  |  | 233 |  |  | 469 |  |
| Free cash flow |  | $ | (258) |  |  | $ | (34) |  |  | $ | 699 |  |  | $ | 983 |  |  | $ | 1,390 |  |  | $ | 50 |  |  | $ | 310 |  |  | $ | 949 |  |  | $ | 829 |  |  | $ | 2,138 |  |

[0001783180-24-000007:8k_2_02:125]
Net Debt Reconciliation

[0001783180-24-000007:8k_2_02:126]
|  |  | (Unaudited) |
|  |  | As of December 31, |
| (In millions) |  | 2023 |  | 2022 |
| Long-term debt |  | $ | 14,242 |  |  | $ | 8,702 |  |
| Current portion of long-term debt |  | 51 |  |  | 140 |  |
| Less: Cash and cash equivalents |  | 10,015 |  |  | 3,520 |  |
| Net debt |  | $ | 4,278 |  |  | $ | 5,322 |  |

[0001783180-24-000007:8k_2_02:127]
16
