# CARR MD&A — 0001783180-24-000009


## mdna

[0001783180-24-000009:mdna:1]
ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001783180-24-000009:mdna:2]
BUSINESS OVERVIEW

[0001783180-24-000009:mdna:3]
Business Summary

[0001783180-24-000009:mdna:4]
Carrier Global Corporation ("we" or "our") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to our customers. Our portfolio includes industry-leading brands such as Carrier, Toshiba, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating and air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. We also provide a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. Our operations are classified into three segments: HVAC, Refrigeration and Fire & Security.

[0001783180-24-000009:mdna:5]
Our worldwide operations are affected by global and regional industrial, economic and political factors and trends. These include the mega-trends of urbanization, climate change and increasing requirements for food safety driven by the food needs of our growing global population and the rising standards of living in emerging markets. We believe that our business segments are well positioned to benefit from favorable secular trends, including these mega-trends and from the strength of our industry-leading brands and track record of innovation. In addition, we regularly review our end markets to proactively identify trends and adapt our strategies accordingly.

[0001783180-24-000009:mdna:6]
Our business is also affected by changes in the general level of economic activity, such as changes in business and consumer spending, construction and shipping activity as well as short-term economic factors such as currency fluctuations, commodity price volatility and supply disruptions. We continue to invest in our business, take pricing actions to mitigate supply chain and inflationary pressures, develop new products and services in order to remain competitive in our markets and use risk management strategies to mitigate various exposures. We believe that we have industry-leading global brands, which form the foundation of our business strategy. Coupled with our focus on growth, innovation and operational efficiency, we expect to drive long-term future growth and increased value for our shareowners.

[0001783180-24-000009:mdna:7]
32

[0001783180-24-000009:mdna:8]
Significant Events

[0001783180-24-000009:mdna:9]
Planned Portfolio Transformation

[0001783180-24-000009:mdna:10]
On April 25, 2023, we announced that we entered into a Share Purchase Agreement (the “Agreement”) to acquire the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (“Viessmann”), a privately-held company. The VCS Business develops intelligent, integrated and sustainable technologies, including heat pumps, boilers, photovoltaic systems, home battery storage and digital solutions, primarily for residential customers in Europe. The acquisition was completed on January 2, 2024 for total consideration of $14.2 billion.

[0001783180-24-000009:mdna:11]
On April 25, 2023, we announced plans to exit our Fire & Security and Commercial Refrigeration businesses over the course of 2024. On December 7, 2023, we entered into a stock purchase agreement to sell our Fire and Security Access Solutions business to Honeywell International Inc. for an enterprise value of approximately $4.95 billion. On December 12, 2023, we entered into a stock purchase agreement to sell our Commercial Refrigeration business ("CCR") to Haier Group Corporation for an enterprise value of approximately $775 million. Both transactions are expected to close 2024.

[0001783180-24-000009:mdna:12]
Deconsolidation of Kidde-Fenwal, Inc.

[0001783180-24-000009:mdna:13]
On May 14, 2023, Kidde-Fenwal, Inc. ("KFI"), an indirect wholly-owned subsidiary of ours, filed a petition for voluntary reorganization under Chapter 11 of the United States Bankruptcy Code ("Chapter 11") in the United States Bankruptcy Court for the District of Delaware. KFI, an industrial fire detection and suppression business historically reported in our Fire & Security segment, has indicated that it intends to use the bankruptcy process to explore strategic alternatives, including the sale of KFI as a going concern. KFI has further stated that, during the Chapter 11 process, KFI expects that there will be no significant interruptions to its business operations. As of the petition date, KFI was deconsolidated and its respective assets and liabilities were derecognized from our Consolidated Financial Statements.

[0001783180-24-000009:mdna:14]
Acquisition of Toshiba Carrier Corporation

[0001783180-24-000009:mdna:15]
On February 6, 2022, we entered into a binding agreement to acquire a majority ownership interest in Toshiba Carrier Corporation ("TCC"), a variable refrigerant flow ("VRF") and light commercial HVAC joint venture between Carrier and Toshiba Corporation. TCC designs and manufactures flexible, energy-efficient and high-performance VRF and light commercial HVAC systems as well as commercial products, compressors and heat pumps. The acquisition included all of TCC's advanced research and development centers and global manufacturing operations, product pipeline and the long-term use of Toshiba's iconic brand. The acquisition was completed on August 1, 2022. As a result, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Consolidated Financial Statements as of the date of acquisition and reported within our HVAC segment. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC.

[0001783180-24-000009:mdna:16]
Sale of Chubb Fire & Security Business

[0001783180-24-000009:mdna:17]
On July 26, 2021, we entered into a stock purchase agreement to sell our Chubb Fire & Security business ("Chubb") to APi Group Corporation ("APi"). Chubb, which was reported within our Fire & Security segment, delivered essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. On January 3, 2022, we completed the sale of Chubb (the "Chubb Sale") for net proceeds of $2.9 billion and recognized a gain on the sale of $1.1 billion during the year ended December 31, 2022.

[0001783180-24-000009:mdna:18]
RESULTS OF OPERATIONS

[0001783180-24-000009:mdna:19]
This discussion summarizes the significant factors affecting our consolidated results of operations, financial condition and liquidity for the year ended December 31, 2023 compared with December 31, 2022. This discussion should be read in conjunction with Item 8, the Consolidated Financial Statements and the accompanying Notes to the Consolidated Financial Statements in this Annual Report. A detailed discussion of the year ended December 31, 2022 compared with December 31, 2021 is not included herein and can be found in the Management's Discussion and Analysis of Financial Condition and Results of Operations section in the Company's 2022 Annual Report, filed with the SEC on February 7, 2023, under the heading "Results of Operations," which is incorporated herein by reference.

[0001783180-24-000009:mdna:20]
Year Ended December 31, 2023 Compared with Year Ended December 31, 2022

[0001783180-24-000009:mdna:21]
The results of TCC's operations are included in our consolidated results since the acquisition date of August 1, 2022. Prior to the acquisition, we previously accounted for our minority ownership in TCC under the equity method of accounting and recognized our portion of earnings within Equity method investment in net earnings as part of operating expenses. As a result, prior period results may not be comparable to the current period.

[0001783180-24-000009:mdna:22]
The following represents our consolidated net sales and operating results:

[0001783180-24-000009:mdna:23]
| (In millions) | 2023 |  | 2022 |  | Period Change |  | % Change |  |  |
| Net sales | $ | 22,098 |  |  | $ | 20,421 |  |  | $ | 1,677 |  |  | 8 | % |  |  |
| Cost of products and services sold | (15,715) |  |  | (14,957) |  |  | (758) |  |  | 5 | % |  |  |
| Gross margin | 6,383 |  |  | 5,464 |  |  | 919 |  |  | 17 | % |  |  |
| Operating expenses | (4,087) |  |  | (949) |  |  | (3,138) |  |  | 331 | % |  |  |
| Operating profit | 2,296 |  |  | 4,515 |  |  | (2,219) |  |  | (49) | % |  |  |
| Non-operating income (expense), net | (212) |  |  | (223) |  |  | 11 |  |  | (5) | % |  |  |
| Income from operations before income taxes | 2,084 |  |  | 4,292 |  |  | (2,208) |  |  | (51) | % |  |  |
| Income tax expense | (644) |  |  | (708) |  |  | 64 |  |  | (9) | % |  |  |
| Net income from operations | 1,440 |  |  | 3,584 |  |  | (2,144) |  |  | (60) | % |  |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations | 91 |  |  | 50 |  |  | 41 |  |  | 82 | % |  |  |
| Net income attributable to common shareowners | $ | 1,349 |  |  | $ | 3,534 |  |  | $ | (2,185) |  |  | (62) | % |  |  |

[0001783180-24-000009:mdna:24]
Net Sales

[0001783180-24-000009:mdna:25]
For the year ended December 31, 2023, Net sales was $22.1 billion, an 8% increase compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-24-000009:mdna:26]
|  | 2023 |  |
| Organic / Operational | 3 | % |  |
| Acquisitions and divestitures, net | 5 | % |  |
| Total % change | 8 | % |  |

[0001783180-24-000009:mdna:27]
Organic sales for the year ended December 31, 2023 increased by 3% compared with the same period of 2022. The organic increase was primarily driven by our HVAC segment due to improved global end-markets in our Commercial HVAC business and pricing improvements in our North America residential and light commercial business. In addition, our Fire & Security segment benefited from price improvements and volume growth in each region. However, results in our Refrigeration segment decreased due to lower volumes in commercial refrigeration and container end-markets. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-24-000009:mdna:28]
On August 1, 2022, we acquired a majority ownership interest in TCC, a VRF and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The results of TCC have been included in our Consolidated Financial Statements since the date of acquisition. The transaction added 6% to Net sales during the year ended December 31, 2023 and is included in Acquisitions and divestitures, net.

[0001783180-24-000009:mdna:29]
As of May 14, 2023, we no longer controlled KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from our Consolidated Financial Statements. The deconsolidation had a 1% impact on Net sales during the year ended December 31, 2023 and is included in Acquisitions and divestitures, net.

[0001783180-24-000009:mdna:30]
Gross Margin

[0001783180-24-000009:mdna:31]
For the year ended December 31, 2023, gross margin was $6.4 billion, a 17% increase compared with the same period of 2022. The components were as follows:

[0001783180-24-000009:mdna:32]
| (In millions) | 2023 |  | 2022 |  |  |  |  |  |  |
| Net sales | $ | 22,098 |  |  | $ | 20,421 |  |  |  |  |  |  |  |
| Cost of products and services sold | (15,715) |  |  | (14,957) |  |  |  |  |  |  |  |
| Gross margin | $ | 6,383 |  |  | $ | 5,464 |  |  |  |  |  |  |  |
| Percentage of net sales | 28.9 | % |  | 26.8 | % |  |  |  |  |  |  |

[0001783180-24-000009:mdna:33]
Gross margin increased by $919 million compared with the year ended December 31, 2022. A main driver of the increase related to ongoing customer demand, pricing improvements and our continued focus on productivity initiatives. In addition, operating results associated with TCC further benefited gross margin during the year. These amounts were partially offset by the higher cost of commodities and components used in our products and certain supply chain constraints. Although inflationary cost pressures have begun to moderate, they remain elevated and continue to impact the cost of products and services sold in each of our segments. Gross margin as a percentage of Net sales increased by 210 basis points compared with the same period of 2022.

[0001783180-24-000009:mdna:34]
Operating Expenses

[0001783180-24-000009:mdna:35]
For the year ended December 31, 2023, operating expenses, including Equity method investment net earnings, was $4.1 billion, a 331% increase compared with the same period of 2022. The components were as follows:

[0001783180-24-000009:mdna:36]
|  | For the Year Ended December 31, |  |  |
| (In millions) | 2023 |  | 2022 |  |  |
| Selling, general and administrative | $ | (3,297) |  |  | $ | (2,512) |  |  |  |
| Research and development | (617) |  |  | (539) |  |  |  |
| Equity method investment net earnings | 211 |  |  | 262 |  |  |  |
| Other income (expense), net | (384) |  |  | 1,840 |  |  |  |
| Operating expenses | $ | (4,087) |  |  | $ | (949) |  |  |  |
| Percentage of net sales | 18.5 | % |  | 4.6 | % |  |  |

[0001783180-24-000009:mdna:37]
For the year ended December 31, 2023, Selling, general and administrative expenses were $3.3 billion, a 31% increase compared with the same period of 2022. The increase is primarily due to higher compensation, commissions and other employee-related costs during the current period. In addition, incremental selling, general and administrative expenses associated with TCC further contributed to the increase. The current year also included $220 million of acquisition and divestiture-related costs compared with $31 million during the year ended December 31, 2022.

[0001783180-24-000009:mdna:38]
Research and development costs relate to new product development and new technology innovation. Due to the variable nature of program development schedules, year-over-year spending levels can fluctuate. In addition, we continue to invest to prepare for future energy efficiency and refrigerant regulation changes and in digital controls technologies.

[0001783180-24-000009:mdna:39]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the year ended December 31, 2023, Equity method investment net earnings were $211 million, a 19% decrease compared with the same period of 2022. The decrease was primarily driven by the increase in our ownership interest in TCC on August 1, 2022. As a result, TCC is no longer accounted for under the equity method of accounting since the date of acquisition. The decrease was partially offset by a $16 million benefit recognized in connection with a favorable tax ruling at a minority owned joint venture. During the year ended December 31, 2022, pre-acquisition equity earnings of TCC totaled $87 million which included a $27 million gain on the sale of two minority owned subsidiaries.

[0001783180-24-000009:mdna:40]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an

[0001783180-24-000009:mdna:41]
entity's functional currency and hedging-related activities. In connection with the proposed acquisition of the VCS Business, we recognized a $96 million loss during the year ended December 31, 2023 on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price. In addition, we recognized a loss of $297 million on the deconsolidation of KFI due to its Chapter 11 filing.

[0001783180-24-000009:mdna:42]
In connection with the TCC acquisition, the carrying value of our previously held TCC equity investments were recognized at fair value at the date of acquisition. As a result, we recognized a $705 million non-cash gain associated with the increase in our ownership interest during the year ended December 31, 2022. In addition, we completed the Chubb Sale and recognized a net gain on the sale of $1.1 billion. Prior period results also included a $22 million charge resulting from a litigation matter and a $7 million gain on the sale of our interest in a cost method investment reported within our Refrigeration segment.

[0001783180-24-000009:mdna:43]
Non-Operating Income (Expense), net

[0001783180-24-000009:mdna:44]
For the year ended December 31, 2023, Non-operating income (expense), net was $212 million, a 5% decrease compared with the same period of 2022. The components were as follows:

[0001783180-24-000009:mdna:45]
|  | For the Year Ended December 31, |  |
| (In millions) | 2023 |  | 2022 |  |
| Non-service pension benefit (expense) | $ | (1) |  |  | $ | (4) |  |  |
| Interest expense | (362) |  |  | (302) |  |  |
| Interest income | 151 |  |  | 83 |  |  |
| Interest (expense) income, net | (211) |  |  | (219) |  |  |
| Non-operating income (expense), net | $ | (212) |  |  | $ | (223) |  |  |

[0001783180-24-000009:mdna:46]
Non-operating income (expense), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the year ended December 31, 2023, interest expense was $362 million, a 20% increase compared with the same period of 2022. In connection with the proposed acquisition of the VCS Business, we entered into several financing arrangements and capitalized $105 million of deferred financing costs during 2023. As a result, we amortized $55 million of deferred financing costs in Interest expense, of which $47 million related to our senior unsecured bridge term loan facility (the "Bridge Loan"). During the year ended December 31, 2022, we completed tender offers to repurchase approximately $1.15 billion aggregate principal of our 2.242% Notes due 2025 and 2.493% Notes due 2027. Upon settlement, we wrote off $5 million of unamortized deferred financing costs in Interest expense and recognized a net gain of $33 million in Interest income.

[0001783180-24-000009:mdna:47]
Income Taxes

[0001783180-24-000009:mdna:48]
|  |  | 2023 |  | 2022 |  |  |
| Effective tax rate |  | 30.9 | % |  | 16.5 | % |  |  |

[0001783180-24-000009:mdna:49]
The effective tax rate for the year ended December 31, 2023 was higher than our statutory U.S. federal income tax rate. The increase was primarily driven by a net tax charge of $90 million relating to the re-organization and disentanglement of CCR and certain Fire & Security industrial businesses in advance of the planned divestitures and a deferred tax charge of $65 million related to basis differences in certain companies presented as held-for-sale. In addition, the effective tax rate was impacted by the recognition of a deferred tax liability for withholding tax of $33 million on repatriated foreign earnings, non-deductible divestiture-related costs and a non-deductible loss of $96 million on the mark-to-market valuation of the Company's window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business. The unfavorable impact of the above items is partially offset by a $53 million tax benefit recorded from the announced KFI bankruptcy and deconsolidation and $49 million of foreign tax credit generated and utilized in 2023.

[0001783180-24-000009:mdna:50]
The effective tax rate for the year ended December 31, 2022 was lower than our statutory U.S. federal income tax rate. The decrease was driven by a lower effective tax rate on the $705 million non-cash gain resulting from the recognition of our

[0001783180-24-000009:mdna:51]
previously held TCC equity investments at fair value upon acquisition of TCC, a lower effective tax rate on the $1.1 billion Chubb gain and $45 million of foreign tax credits generated and utilized in 2022.

[0001783180-24-000009:mdna:52]
Segment Review

[0001783180-24-000009:mdna:53]
We conduct our operations through three reportable segments:

[0001783180-24-000009:mdna:54]
•The HVAC segment provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-24-000009:mdna:55]
•The Refrigeration segment includes transport refrigeration and monitoring products, services and digital solutions for trucks, trailers, shipping containers, intermodal and rail, as well as commercial refrigeration products.

[0001783180-24-000009:mdna:56]
•The Fire & Security segment provides a wide range of residential, commercial and industrial technologies designed to help protect people and property.

[0001783180-24-000009:mdna:57]
We determine our segments based on how our Chief Executive Officer, who is the Chief Operating Decision Maker (the "CODM"), allocates resources, assesses performance and makes operational decisions. The CODM allocates resources and evaluates the financial performance of each of our segments based on Net sales and Operating profit. Adjustments to reconcile segment reporting to the consolidated results are included in Note 21 - Segment Financial Data.

[0001783180-24-000009:mdna:58]
Summary performance for each of our segments is as follows:

[0001783180-24-000009:mdna:59]
|  | Net Sales |  | Operating Profit |  | Operating Margin |
| (In millions) | 2023 |  | 2022 |  |  |  | 2023 |  | 2022 |  |  |  | 2023 |  | 2022 |  |  |
| HVAC | $ | 15,139 |  |  | $ | 13,408 |  |  |  |  | $ | 2,275 |  |  | $ | 2,610 |  |  |  |  | 15.0 | % |  | 19.5 | % |  |  |
| Refrigeration | 3,818 |  |  | 3,883 |  |  |  |  | 428 |  |  | 483 |  |  |  |  | 11.2 | % |  | 12.4 | % |  |  |
| Fire & Security | 3,633 |  |  | 3,570 |  |  |  |  | 209 |  |  | 1,630 |  |  |  |  | 5.8 | % |  | 45.7 | % |  |  |
| Total segment | $ | 22,590 |  |  | $ | 20,861 |  |  |  |  | $ | 2,912 |  |  | $ | 4,723 |  |  |  |  | 12.9 | % |  | 22.6 | % |  |  |

[0001783180-24-000009:mdna:60]
HVAC Segment

[0001783180-24-000009:mdna:61]
For the year ended December 31, 2023, Net sales in our HVAC segment was $15.1 billion, a 13% increase compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-24-000009:mdna:62]
|  | Net sales |
| Organic / Operational | 5 | % |
| Foreign currency translation | (1) | % |
| Acquisitions and divestitures, net | 9 | % |
| Total % change | 13 | % |

[0001783180-24-000009:mdna:63]
The organic increase in Net sales of 5% was driven by continued strong results in the segment. Increased sales in our Commercial HVAC business (up 12%) benefited from pricing improvements and ongoing customer demand in our end-markets. The business grew in all regions including Europe and Asia as current economic conditions and inflationary cost pressures improved compared with the prior year. Higher sales in our North America residential and light commercial business (up 1%) were primarily driven by pricing improvements and improved mix associated with regulatory changes effective as of the beginning of 2023. These amounts were partially offset by lower volume in North America residential end-markets. Results in our Global Comfort Solutions business (down 2%) were primarily driven by lower demand in certain European end- markets.

[0001783180-24-000009:mdna:64]
On August 1, 2022, we acquired a majority ownership interest in TCC, a VRF and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The results of TCC have been included in our Consolidated Financial Statements since the date of acquisition. The transaction added 9% to Net sales for the year ended December 31, 2023 and is included in Acquisitions and divestitures, net.

[0001783180-24-000009:mdna:65]
For the year ended December 31, 2023, Operating profit in our HVAC segment was $2.3 billion, a 13% decrease compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-24-000009:mdna:66]
|  | Operating profit |
| Organic / Operational | 12 | % |
| Acquisitions and divestitures, net | 6 | % |
| Amortization of acquired intangibles | (4) | % |
| Restructuring | (1) | % |
| Other | (26) | % |
| Total % change | (13) | % |

[0001783180-24-000009:mdna:67]
The operational profit increase of 12% was primarily attributable to pricing improvements and ongoing customer demand in certain end-markets compared with the prior year. These benefits more than offset the higher cost for commodities and components used in our products. Lower earnings from equity method investments impacted operational profit due to the increase in our ownership interest in TCC on August 1, 2022. As a result, TCC is no longer accounted for under the equity method of accounting since the date of acquisition. Inflationary cost pressures have begun to moderate but continue to impact our operating profit.

[0001783180-24-000009:mdna:68]
Acquisitions and divestitures, net primarily related to the results of operations associated with the acquisition of TCC. The transaction added 6% to Operating profit during the year ended December 31, 2023. In connection with the TCC acquisition, the carrying value of our previously held TCC equity investments were recognized at fair value at the date of acquisition. As a result, we recognized a $705 million non-cash gain associated with the increase in our ownership interest in Other.

[0001783180-24-000009:mdna:69]
Refrigeration Segment

[0001783180-24-000009:mdna:70]
For the year ended December 31, 2023, Net sales in our Refrigeration segment was $3.8 billion, a 2% decrease compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-24-000009:mdna:71]
|  | Net sales |
| Organic / Operational | (2) | % |
| Foreign currency translation | 1 | % |
| Acquisitions and divestitures, net | (1) | % |
| Total % change | (2) | % |

[0001783180-24-000009:mdna:72]
Organic Net sales decreased 2% compared to the prior year as the segment experienced challenges in certain end-markets during the year. Results for Commercial refrigeration decreased (down 14%) compared with the prior year, primarily driven by lower volumes in Europe as economic conditions and inflationary cost pressures impacted end-market demand. In addition, Asia results were impacted by reduced end-market demand in China. Transport refrigeration results increased (up 3%) compared to the prior year as pricing improvements and strong end-market demand in all regions were partially offset by continued weakness in container end-markets.

[0001783180-24-000009:mdna:73]
For the year ended December 31, 2023, Operating profit in our Refrigeration segment was $428 million, an 11% decrease compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-24-000009:mdna:74]
|  | Operating profit |
| Organic / Operational | (14) | % |
| Foreign currency translation | 1 | % |
| Restructuring | (3) | % |
| Other | 5 | % |
| Total % change | (11) | % |

[0001783180-24-000009:mdna:75]
The decrease in operational profit of 14% was primarily driven by lower volume in certain end-markets compared with the prior year. In addition, the higher costs of commodities and components used in our products further impacted segment results. These amounts were partially offset by pricing improvements and favorable productivity initiatives. Inflationary cost pressures have begun to moderate but continue to impact our operating profit. Amounts reported in Other represent a $24 million gain on the sale of a business within Transport refrigeration.

[0001783180-24-000009:mdna:76]
Fire & Security Segment

[0001783180-24-000009:mdna:77]
For the year ended December 31, 2023, Net sales in our Fire & Security segment was $3.6 billion, a 2% increase compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-24-000009:mdna:78]
|  | Net sales |
| Organic / Operational | 6 | % |
| Foreign currency translation | (1) | % |
| KFI deconsolidation | (3) | % |
| Total % change | 2 | % |

[0001783180-24-000009:mdna:79]
The organic increase in Net sales of 6% was primarily driven by pricing improvements and volume growth compared with the prior year. Sales grew in all three regions including strong commercial results in the Americas. Growth in Europe moderated as economic conditions and inflationary cost pressures impacted end-market demand. Results in Asia normalized after a strong COVID-19 related recovery. Global industrial sales benefited segment results due to pricing improvements and strong demand. The segment was impacted by ongoing supply chain constraints for certain components used in our products.

[0001783180-24-000009:mdna:80]
For the year ended December 31, 2023, Operating profit in our Fire & Security segment was $209 million, an 87% decrease compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-24-000009:mdna:81]
|  |  |  | Operating profit |
| Organic / Operational |  |  | 2 | % |
| Acquisitions and divestitures, net |  |  | (1) | % |
| Restructuring |  |  | (1) | % |
| KFI deconsolidation |  |  | (18) | % |
| Chubb gain |  |  | (68) | % |
| Other |  |  | (1) | % |
| Total % change |  |  | (87) | % |

[0001783180-24-000009:mdna:82]
The operational profit increase of 2% was primarily driven by pricing improvements, volume growth and lower freight and logistics costs compared to the prior year. These amounts were partially offset by the higher costs of commodities and components used in our products. In addition, higher inventory-related reserves resulting from supply chain challenges further impacted segment results. Inflationary cost pressures have moderated, but continue to impact our operating profit.

[0001783180-24-000009:mdna:83]
As of May 14, 2023, we no longer control KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from our Consolidated Financial Statements. As a result, we recognized a loss on deconsolidation of $297 million during the year ended December 31, 2023. In addition, we incurred divestiture-related costs reported within Other. During the twelve months ended December 31, 2022, we completed the Chubb Sale and recognized a net gain on the sale of $1.1 billion

[0001783180-24-000009:mdna:84]
LIQUIDITY AND FINANCIAL CONDITION

[0001783180-24-000009:mdna:85]
We assess liquidity in terms of our ability to generate adequate amounts of cash necessary to fund our current and future cash requirements to support our business and strategic initiatives. In doing so, we review and analyze our cash on hand, working capital, debt service requirements and capital expenditures. We rely on operating cash flows as our primary source of liquidity. In addition, we have access to other sources of capital to finance our strategic initiatives and fund growth.

[0001783180-24-000009:mdna:86]
As of December 31, 2023, we had Cash and cash equivalents of $10.0 billion, of which approximately 48% was held by our foreign subsidiaries. We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which we can access funds held by foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection with contractual obligations related to acquisitions or divestitures or other legal obligations. As of December 31, 2023 and 2022, the amount of such restricted cash was $2 million and $7 million, respectively.

[0001783180-24-000009:mdna:87]
We continue to actively manage and strengthen our business portfolio to meet the current and future needs of our customers. This is accomplished through research and development activities with a focus on new product development and new technology innovation as well as sustaining activities with a focus on improving existing products and reducing production costs. We also pursue potential acquisitions to complement existing products and services to enhance our product portfolio. In addition, we routinely conduct discussions, evaluate targets and enter into agreements regarding possible acquisitions, divestitures, joint ventures and equity investments to manage our business portfolio.

[0001783180-24-000009:mdna:88]
We believe that our available cash and operating cash flows will be sufficient to meet our future operating cash needs. Our committed credit facilities and access to the debt and equity markets provide additional sources of short-term and long-term capital to fund current operations, debt maturities and future investment opportunities. Although we believe that the arrangements currently in place permit us to finance our operations on acceptable terms and conditions, our access to and the availability of financing on acceptable terms and conditions in the future will be impacted by many factors, including: (1) our credit ratings or absence of credit ratings; (2) the liquidity of the overall capital markets; (3) the state of the economy; and (4) the restrictions under our debt agreements. There can be no assurance that we will be able to obtain additional financing on terms favorable to us, if at all.

[0001783180-24-000009:mdna:89]
The following table contains several key measures of our financial condition and liquidity:

[0001783180-24-000009:mdna:90]
|  |  | As of December 31, |
| (In millions) |  | 2023 |  | 2022 |
| Cash and cash equivalents |  | $ | 10,015 |  |  | $ | 3,520 |  |
| Total debt |  | $ | 14,293 |  |  | $ | 8,842 |  |
| Net debt (total debt less cash and cash equivalents) |  | $ | 4,278 |  |  | $ | 5,322 |  |
| Total equity |  | $ | 9,005 |  |  | $ | 8,076 |  |
| Total capitalization (total debt plus total equity) |  | $ | 23,298 |  |  | $ | 16,918 |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | $ | 13,283 |  |  | $ | 13,398 |  |
| Total debt to total capitalization |  | 61 | % |  | 52 | % |
| Net debt to net capitalization |  | 32 | % |  | 40 | % |

[0001783180-24-000009:mdna:91]
Acquisition of Viessmann

[0001783180-24-000009:mdna:92]
On April 25, 2023, we announced that we entered into an Agreement to acquire the VCS Business. Under the terms of the Agreement, 20% of the purchase price was to be paid in Carrier common stock, issued directly to Viessmann and subject to long-term lock-up provisions and 80% was to be paid in cash. Simultaneously, we entered into commitment letters with JPMorgan Chase Bank, N.A., BofA Securities, Inc. and Bank of America, N.A. to provide a €8.2 billion Bridge Loan to fund a portion of the Euro-denominated purchase price.

[0001783180-24-000009:mdna:93]
On May 19, 2023, we entered into a 364-day, $500 million, senior unsecured revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders (the "Revolver"). In addition, we entered into a senior unsecured delayed draw term loan credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders that permits aggregate borrowings of up to €2.3 billion (the "Delayed Draw Facility"). Upon entering into the Delayed Draw Facility, the aggregate principal amount of the Bridge Loan was reduced by €2.3 billion. In November 30, 2023, we issued $3.0 billion principal amount of USD-denominated notes ("USD Notes") and €2.35 billion principal amount of Euro-denominated notes ("Euro Notes"). Upon issuance, the aggregate principal amount of the Bridge Loan was reduced by €5.4 billion.

[0001783180-24-000009:mdna:94]
On January 2, 2024, we completed the acquisition of the VCS Business for $14.2 billion. The cash portion of the purchase price was funded through cash on hand, proceeds from the USD Notes and the Euro Notes and borrowings under the Delayed Draw Facility and a 60-day senior unsecured bridge term loan. In addition, proceeds from the Revolver became available upon closing.

[0001783180-24-000009:mdna:95]
40

[0001783180-24-000009:mdna:96]
Borrowings and Lines of Credit

[0001783180-24-000009:mdna:97]
We maintain a $2.0 billion unsecured, unsubordinated commercial paper program which we can use for general corporate purposes, including the funding of working capital and potential acquisitions. In addition, we maintain a $2.0 billion revolving credit agreement with various banks (the "Revolving Credit Facility") that matures in May 2028 which supports our commercial paper borrowing program and can be used for general corporate purposes. A ratings-based commitment fee is charged on unused commitments. As of December 31, 2023, we had no borrowings outstanding under our commercial paper program or our Revolving Credit Facility.

[0001783180-24-000009:mdna:98]
Our short-term obligations primarily consist of current maturities of long-term debt. Our long-term obligations primarily consist of long-term notes with maturity dates ranging between 2025 and 2054. Interest payments related to long-term Notes are expected to approximate $507 million per year, reflecting an approximate weighted-average interest rate of 3.8%. Any borrowings from the Revolving Credit Facility are subject to variable interest rates. See Note 7 - Borrowings and Lines of Credit in the accompanying Notes to the Consolidated Financial Statements for additional information regarding the terms of our long-term debt obligations.

[0001783180-24-000009:mdna:99]
Scheduled maturities of long-term debt, excluding amortization of discount, are as follows:

[0001783180-24-000009:mdna:100]
| (In millions) |  |  |  |
| 2024 |  | $ | 51 |  |  |
| 2025 |  | $ | 3,053 |  |  |
| 2026 |  | $ | 4 |  |  |
| 2027 |  | $ | 1,245 |  |  |
| 2028 |  | $ | 832 |  |  |
| Thereafter |  | $ | 9,191 |  |  |

[0001783180-24-000009:mdna:101]
The following table presents our credit ratings and outlook as of December 31, 2023:

[0001783180-24-000009:mdna:102]
| Rating Agency | Long-term Rating (1) | Short-term Rating |  | Outlook (2) |
| S&P | BBB | A2 |  | Positive |
| Moody's | Baa3 | P3 |  | Positive |
| Fitch Ratings | BBB | F3 |  | Stable |

[0001783180-24-000009:mdna:103]
(1) The long-term rating for S&P was affirmed on May 14, 2021, and for Moody's on March 30, 2022. Fitch's long-term rating was updated in December 2023.

[0001783180-24-000009:mdna:104]
(2) S&P revised its outlook to positive from stable in December 2023.

[0001783180-24-000009:mdna:105]
(3) Moody's Investors Service revised its outlook to positive from stable on February 28, 2023.

[0001783180-24-000009:mdna:106]
Portfolio Transformation

[0001783180-24-000009:mdna:107]
On April 25, 2023, we announced plans to exit our Fire & Security and Commercial Refrigeration businesses over the course of 2024. On December 7, 2023, we entered into a stock purchase agreement to sell our Fire & Security Access Solutions business to Honeywell International Inc. for an enterprise value of approximately $4.95 billion. On December 12, 2023, we entered into a stock purchase agreement to sell CCR to Haier Group Corporation for an enterprise value of approximately $775 million. Both transactions are expected to close 2024.

[0001783180-24-000009:mdna:108]
Share Repurchase Program

[0001783180-24-000009:mdna:109]
We may purchase our outstanding common stock from time to time subject to market conditions and at our discretion. Repurchases occur in the open market or through one or more other public or private transactions pursuant to plans complying with Rules 10b5-1 and 10b-18 under the Exchange Act. Since the initial authorization in February 2021, the Company's Board of Directors authorized the repurchase of up to $4.1 billion of our outstanding common stock. As of December 31, 2023, the Company repurchased 43.5 million shares of common stock for an aggregate purchase price of $2.0 billion, which includes shares repurchased under an accelerated share repurchase agreement. As a result, the Company has approximately $2.1 billion remaining under the current authorization at December 31, 2023. Upon announcement of the proposed acquisition of the VCS

[0001783180-24-000009:mdna:110]
41

[0001783180-24-000009:mdna:111]
Business, the Company temporarily paused its share repurchase program in order to advance its capital allocation strategy. As a result, there is no share repurchase activity to report for the fourth quarter of 2023.

[0001783180-24-000009:mdna:112]
Dividends

[0001783180-24-000009:mdna:113]
We paid dividends on our common stock of $0.74 per share during the year ended December 31, 2023, totaling $620 million. On December 6, 2023, the Board of Directors declared a dividend of $0.19 per share payable on February 9, 2024 to shareowners of record at the close of business on December 21, 2023.

[0001783180-24-000009:mdna:114]
Discussion of Cash Flows

[0001783180-24-000009:mdna:115]
|  |  | For the Years Ended December 31, |
| (In millions) |  | 2023 |  | 2022 |  |  |
| Cash provided by (used in): |  |  |  |  |  |  |
| Operating activities |  | $ | 2,607 |  |  | $ | 1,743 |  |  |  |
| Investing activities |  | (660) |  |  | 1,745 |  |  |  |
| Financing activities |  | 4,612 |  |  | (2,931) |  |  |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  | 88 |  |  | (56) |  |  |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  | $ | 6,647 |  |  | $ | 501 |  |  |  |

[0001783180-24-000009:mdna:116]
Cash flows from operating activities primarily represent inflows and outflows associated with our operations. Primary activities include net income from operations adjusted for non-cash transactions, working capital changes and changes in other assets and liabilities. We define working capital as the assets and liabilities, other than cash, generated through our primary operating activities. The year-over-year increase in net cash provided by operating activities was primarily driven by a reduction in working capital balances. Improved inventory management and higher accounts payable balances more that offset an increase in our accounts receivable balances. In addition, Accounts payable and accrued liabilities included a $96 million mark-to-market valuation adjustment on our window forward contracts associated with the Euro-denominated purchase price of the VCS Business. Prior year working capital balances were higher due to higher safety stock and supply chain constraints.

[0001783180-24-000009:mdna:117]
Cash flows from investing activities primarily represent inflows and outflows associated with long-term assets. Primary activities include capital expenditures, acquisitions, divestitures and proceeds from the sale of fixed assets. During the year ended December 31, 2023, net cash used in investing activities was $660 million. The primary drivers of the outflow related to $469 million of capital expenditures and $134 million related to the deconsolidation of KFI. In addition, we settled working capital and other transaction-related items associated with the acquisition of TCC and invested in several businesses. These amounts totaled $84 million, net of cash acquired and were partially offset by the proceeds from the sale of a business during the period. During the year ended December 31, 2022, net cash provided by investing activities was $1.7 billion. The primary driver of the inflow related to the net proceeds from the Chubb Sale. This amount was partially offset by the acquisition of TCC and several other businesses and minority-owned businesses, which totaled $506 million, net of cash acquired and $353 million of capital expenditures.

[0001783180-24-000009:mdna:118]
Cash flows from financing activities primarily represent inflows and outflows associated with equity or borrowings. Primary activities include debt transactions, paying dividends to shareowners and the repurchase of our common stock. During the year ended December 31, 2023 net cash provided by financing activities was $4.6 billion. The primary driver of the inflow related to the issuance of the USD Notes and the Euro Notes. The inflow was partially offset by the payment of $620 million in dividends to our common shareowners and deferred financing costs. In addition, we paid $62 million to repurchase shares of our common stock. During the year ended December 31, 2022 net cash used in financing activities was $2.9 billion. The primary driver of the outflow related to the payment of $1.4 billion to repurchase shares of our common stock. In addition, we settled our tender offers for $1.15 billion and paid $509 million in dividends to our common shareowners.

[0001783180-24-000009:mdna:119]
Summary of Other Sources and Uses of Cash

[0001783180-24-000009:mdna:120]
Rapid changes in legislation, regulations and government policies, including with respect to regulations intended to combat climate change, affect our operations and business in the countries, regions and localities in which we operate and sell our products. We are committed to comply with these regulations and to environmental stewardship. As a result, we have set goals to invest over $2 billion by 2030 to develop healthy, safe, sustainable and intelligent buildings and cold chain solutions that incorporate sustainable design principles and reduce lifecycle impacts. In addition, to reach our goal to achieve carbon

[0001783180-24-000009:mdna:121]
neutrality in our operations by 2030, we expect to incur capital expenditures for climate-related projects including upgrading our facilities, equipment and controls to optimize energy efficiency, transition our energy consumption from a dependency on fossil fuels to renewable energy and expanding the electrification of our fleet vehicles. See section entitled Environmental Goals under the headings "Other Matters Relating to Our Business as a Whole" for additional information.

[0001783180-24-000009:mdna:122]
We also have obligations related to environmental and asbestos matters, pension and post-retirement benefits and taxes. See Note 10 - Employee Benefit Plans, Note 17 - Income Taxes, and Note 23 - Commitments and Contingent Liabilities in the accompanying Notes to the Consolidated Financial Statements in this Annual Report for additional information.

[0001783180-24-000009:mdna:123]
CRITICAL ACCOUNTING ESTIMATES

[0001783180-24-000009:mdna:124]
Our financial statements are prepared in accordance with accounting principles generally accepted in the United States. The preparation of financial statements in conformity with those accounting principles requires management to use judgement in making estimates and assumptions based on the relevant information available at the end of each period. These estimates and assumptions have a significant effect on reported amounts of assets, liabilities, sales and expenses as well as the disclosure of contingent assets and liabilities because they result primarily from the need to make estimates and assumptions on matters that are inherently uncertain. Actual results could differ from management's estimates.

[0001783180-24-000009:mdna:125]
Goodwill and Indefinite-Lived Intangible Assets

[0001783180-24-000009:mdna:126]
In accordance with the Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") 350, Intangibles - Goodwill and Other ("ASC 350"), goodwill and other indefinite-lived intangible assets are tested and reviewed annually for impairment or whenever there is a material change in events or circumstances that indicate that the fair value of the asset is more likely than not less than the carrying amount of the asset. We test our reporting units and indefinite-lived intangible assets for impairment annually as of the first day of our third quarter, or more frequently if events or circumstances occur.

[0001783180-24-000009:mdna:127]
ASC 350 provides entities with an option to perform a qualitative assessment (commonly referred to as “step zero”) to determine whether a quantitative analysis for impairment is necessary. In performing step zero for our impairment test, we are required to make assumptions and judgments, including but not limited to the following: the evaluation of macroeconomic conditions as related to our business, industry and market trends, and the overall future financial performance of our reporting units and future opportunities in the markets in which they operate. If impairment indicators are present after performing step zero, we would perform a quantitative impairment analysis to estimate fair value.

[0001783180-24-000009:mdna:128]
For our 2023 goodwill and indefinite-lived intangible assets impairment tests, we elected to perform qualitative step zero assessments to determine if it was more likely than not that the fair values of our reporting units and indefinite-lived intangible assets were below carrying value. We considered macroeconomic factors including global economic growth, general macroeconomic trends for the markets in which our reporting units operate and where the intangible assets are utilized and the forecasted growth of the global industrial products industry. In addition to these macroeconomic factors, among other things, we considered the reporting units’ current results and forecasts, changes in the nature of each business, any significant legal, regulatory, contractual, political or other business climate factors, changes in the industry and competitive environment, changes in the composition or carrying amount of net assets and any intention to sell or dispose of a reporting unit or cease the use of any indefinite-lived intangible assets. Based upon our qualitative analysis, we determined that our goodwill and indefinite-lived intangible assets were not impaired.

[0001783180-24-000009:mdna:129]
Revenue Recognition from Contracts with Customers

[0001783180-24-000009:mdna:130]
Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of our performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally the time of shipment. The remaining portion of our performance obligations are recognized over time as the customer simultaneously obtains control as we perform work under a contract, or if the product being produced for the customer has no alternative use and we have a contractual right to payment.

[0001783180-24-000009:mdna:131]
A performance obligation is a distinct good, service or a bundle of goods and services promised in a contract. Some of our contracts with customers contain a single performance obligation, while others contain multiple performance obligations most commonly when a contract spans multiple phases of a product life-cycle such as production, installation, maintenance and

[0001783180-24-000009:mdna:132]
support. We identify performance obligations at the inception of a contract and allocate the transaction price to each distinct performance obligation. Revenue is recognized when or as the performance obligation is satisfied. When there are multiple performance obligations within a contract, we allocate the transaction price to each performance obligation based on its relative stand-alone selling price.

[0001783180-24-000009:mdna:133]
We primarily generate revenue from the sale of products to customers and recognize revenue at a point in time when control transfers to the customer. Transfer of control is generally based on the shipping terms of the contract. In addition, we recognize revenue on an over-time basis on installation and service contracts. For over-time performance obligations requiring the installation of equipment, revenue is recognized using costs incurred to date relative to total estimated costs at completion to measure progress. Incurred costs represent work performed, which correspond with and best depict transfer of control to the customer. Contract costs include direct costs such as labor, materials and subcontractors’ costs and, where applicable, indirect costs.

[0001783180-24-000009:mdna:134]
The transaction price allocated to performance obligations reflects our expectations about the consideration we will be entitled to receive from a customer. We include variable consideration in the estimated transaction price when there is a basis to reasonably estimate the amount and when it is probable that a significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. In addition, we customarily offer our customers incentives to purchase products to ensure an adequate supply of our products in distribution channels. The principal incentive programs provide reimbursements to distributors for offering promotional pricing for products. We account for estimated incentive payments as a reduction in sales at the time a sale is recognized.

[0001783180-24-000009:mdna:135]
Income Taxes

[0001783180-24-000009:mdna:136]
We account for income taxes in accordance with ASC 740, Income Taxes ("ASC 740"). Deferred tax assets and liabilities are determined based on temporary differences between financial reporting and tax bases of assets and liabilities, applying enacted tax rates expected to be in effect for the year in which the differences are expected to reverse. We recognize future tax benefits to the extent that realizing these benefits is considered in our judgment to be more likely than not. For those jurisdictions where the expiration date of tax carryforwards or the projected operating results indicate that realization is not likely, a valuation allowance is provided. We review the realizability of our deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required and will adjust our estimate if significant events so dictate. To the extent that the ultimate results differ from our original or adjusted estimates, the effect will be recorded in the provision for income taxes in the period that the matter is finally resolved.

[0001783180-24-000009:mdna:137]
In the ordinary course of business, there is inherent uncertainty in quantifying our income tax positions. We assess our income tax positions and record tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. For those tax positions where it is more likely than not that a tax benefit will be sustained, we have recorded the largest amount of tax benefit with a greater than 50% likelihood of being realized upon ultimate settlement with a taxing authority that has full knowledge of all relevant information. For those income tax positions where it is not more likely than not that a tax benefit will be sustained, no tax benefit has been recognized in the Consolidated Financial Statements.

[0001783180-24-000009:mdna:138]
Employee Benefit Plans

[0001783180-24-000009:mdna:139]
We provide a range of benefit plans to eligible current and former employees. We account for our benefits plans in accordance with ASC 715, Compensation – Retirement Benefits ("ASC 715"), which requires balance sheet recognition of the overfunded or underfunded status of pension plans. The determination of the amounts associated with these benefits is performed by actuaries and dependent on various actuarial assumptions including discount rates, expected return on plan assets, compensation increases, mortality and health care cost trends. Actual results may differ from the actuarial assumptions and are generally recorded in Accumulated other comprehensive income (loss) and amortized into Net income from operations over future periods. We review our actuarial assumptions at each measurement date and make modifications to the assumptions based on current rates and trends, if appropriate.

[0001783180-24-000009:mdna:140]
A change in any of these assumptions would have an effect on net periodic pension and post-retirement benefit costs reported in the Consolidated Financial Statements. The following table summarizes the estimated sensitivity of our 2023 projected benefit obligation and net periodic pension (benefit) cost to a 25 basis point change in the discount rate:

[0001783180-24-000009:mdna:141]
| (In millions) |  | Increase in Discount Rate of 25 bps |  | Decrease in Discount Rate of 25 bps |
| Projected benefit obligation |  | $ | (14) |  |  | $ | 14 |  |
| Net periodic pension (benefit) cost |  | $ | — |  |  | $ | — |  |

[0001783180-24-000009:mdna:142]
Net periodic pension (benefit) cost is also sensitive to changes in the expected return on plan assets. An increase or decrease of 25 basis points in the expected return on plan assets would have decreased or increased 2023 pension expense by approximately $1 million.

[0001783180-24-000009:mdna:143]
Contingent Liabilities

[0001783180-24-000009:mdna:144]
We are involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies ("ASC 450"), we record accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, we accrue the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. We are unable to predict the final outcome of these matters based on the information currently available. However, we do not believe that the resolution of any of these matters will have a material adverse effect upon our competitive position, results of operations, cash flows or financial condition.

[0001783180-24-000009:mdna:145]
As described in Note 23 – Commitments and Contingent Liabilities in the accompanying Notes to the Consolidated Financial Statements in this Annual Report, contractual, regulatory and other matters, including asbestos claims, may arise in the ordinary course of business that subject us to claims or litigation. We have recorded reserves in the consolidated financial statements related to these matters, which are developed using input derived from actuarial estimates and historical and anticipated experience depending on the nature of the reserve, and in certain instances in consultation with legal counsel, internal and external consultants and engineers. Subject to the uncertainties inherent in estimating future costs for these types of liabilities, we believe our estimated reserves are reasonable and do not believe the final determination of the liabilities with respect to these matters would have a material adverse effect upon our competitive position, results of operations, cash flows or financial condition. See the "Risk Factors" section in this Annual Report for additional information.

[0001783180-24-000009:mdna:146]
Recent Accounting Pronouncements

[0001783180-24-000009:mdna:147]
See Note 3 – Summary of Significant Accounting Policies in the accompanying Notes to the Consolidated Financial Statements in this Annual Report for a discussion of recent accounting pronouncements and their effect on our financial statements.
