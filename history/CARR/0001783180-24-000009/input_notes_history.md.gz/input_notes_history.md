# CARR note change history — 0001783180-23-000056 → 0001783180-23-000065


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-10-26):
[0001783180-23-000065:note_history:1]
| (In millions) |  | September 30,2023 |  | December 31,2022 |
| Environmental reserves included in Accrued liabilities |  | $ | 12 |  |  | $ | 24 |  |
| Environmental reserves included in Other long-term liabilities |  | 208 |  |  | 211 |  |
| Total Environmental reserves |  | $ | 220 |  |  | $ | 235 |  |
  (was, 2023-07-27, similarity 0.9758):
[0001783180-23-000056:note_history:1]
| (In millions) |  | June 30,2023 |  | December 31,2022 |
| Environmental reserves included in Accrued liabilities |  | $ | 15 |  |  | $ | 24 |  |
| Environmental reserves included in Other long-term liabilities |  | 203 |  |  | 211 |  |
| Total Environmental reserves |  | $ | 218 |  |  | $ | 235 |  |

- changed (2023-10-26):
[0001783180-23-000065:note_history:2]
| (In millions) |  | September 30,2023 |  | December 31,2022 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 16 |  |  | $ | 16 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 207 |  |  | 212 |  |
| Total Asbestos liabilities |  | $ | 223 |  |  | $ | 228 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 89 |  |  | 90 |  |
| Total Asbestos-related recoveries |  | $ | 94 |  |  | $ | 95 |  |
  (was, 2023-07-27, similarity 0.9867):
[0001783180-23-000056:note_history:2]
| (In millions) |  | June 30,2023 |  | December 31,2022 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 16 |  |  | $ | 16 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 207 |  |  | 212 |  |
| Total Asbestos liabilities |  | $ | 223 |  |  | $ | 228 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 89 |  |  | 90 |  |
| Total Asbestos-related recoveries |  | $ | 94 |  |  | $ | 95 |  |

- changed (2023-10-26):
[0001783180-23-000065:note_history:3]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis Worldwide Corporation ("Otis"), the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenged the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021 (the "Amended Complaint"). The Amended Complaint, with Raytheon Technologies Corporation, Carrier and Otis as the only defendants, asserted that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also sought specific performance. The Company believes all plaintiffs' claims against it are without merit. Defendants moved to dismiss the Amended Complaint. On September 30, 2022, the court dismissed the case against all defendants, with prejudice. Plaintiffs appealed the dismissal to the United States Court of Appeals for the Second Circuit. On August 3, 2023, the Second Circuit Court of Appeals affirmed the district court’s ruling.
  (was, 2023-07-27, similarity 0.9434):
[0001783180-23-000056:note_history:3]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis Worldwide Corporation ("Otis"), the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenged the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021 (the "Amended Complaint"). The Amended Complaint, with Raytheon Technologies Corporation, Carrier and Otis as the only defendants, asserted that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also sought specific performance. The Company believes all plaintiffs' claims against it are without merit. Defendants moved to dismiss the Amended Complaint. On September 30, 2022, the court dismissed the case against all defendants, with prejudice. Plaintiffs appealed the dismissal to the United States Court of Appeals for the Second Circuit. Oral arguments on the appeal were held before the Second Circuit on June 29, 2023 and a decision is pending.

- changed (2023-10-26):
[0001783180-23-000065:note_history:4]
As of September 30, 2023, the Company, KFI and others have been named as defendants in more than 5,000 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company, KFI and others have also been named as defendants in more than 600 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.
  (was, 2023-07-27, similarity 0.9948):
[0001783180-23-000056:note_history:4]
As of June 30, 2023, the Company, KFI and others have been named as defendants in more than 4,500 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company, KFI and others have also been named as defendants in more than 500 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

- changed (2023-10-26):
[0001783180-23-000065:note_history:5]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires. The lawsuits identified above relate to Kidde Fire Fighting, Inc., which owned the National Foam business. Kidde Fire Fighting, Inc. was acquired by a UTC subsidiary in 2005 and merged into KFI in 2007. The National Foam business manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania (the "Pennsylvania Site"). In 2013, KFI divested the AFFF businesses to an unrelated third party. The Company acquired KFI as part of the Separation in April 2020.
  (was, 2023-07-27, similarity 0.9993):
[0001783180-23-000056:note_history:5]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires. The lawsuits identified above relate to Kidde Fire Fighting, Inc. which owned the National Foam business. Kidde Fire Fighting, Inc. was acquired by a UTC subsidiary in 2005 and merged into KFI in 2007. The National Foam business manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania (the "Pennsylvania Site"). In 2013, KFI divested the AFFF businesses to an unrelated third party. The Company acquired KFI as part of the Separation in April 2020.

- changed (2023-10-26):
[0001783180-23-000065:note_history:6]
Outside of the MDL Proceedings, the Company and other defendants also are party to six lawsuits in U.S. state courts brought by oil refining companies alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage. In addition, the Company and other defendants are party to two actions related to the Pennsylvania Site in which the plaintiff water utility company seeks remediation costs related to the alleged contamination of the local water supply. The Company, KFI and other defendants are also party to one action in Arizona state court brought by a firefighter claiming that occupational exposure to AFFF has caused certain personal injuries.
  (was, 2023-07-27, similarity 0.8445):
[0001783180-23-000056:note_history:6]
Outside of the MDL Proceedings, the Company and other defendants also are party to six lawsuits in U.S. state courts brought by oil refining companies alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage. In addition, the Company and other defendants are party to two actions related to the Pennsylvania Site in which the plaintiff water utility company seeks remediation costs related to the alleged contamination of the local water supply.

- changed (2023-10-26):
[0001783180-23-000065:note_history:7]
The Company and KFI believe that they have meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate a range of possible loss at this time. There can be no assurance that any such future exposure will not be material in any period.
  (was, 2023-07-27, similarity 0.8111):
[0001783180-23-000056:note_history:7]
The Company, KFI and other defendants are also party to one action in Arizona state court brought by a firefighter claiming that occupational exposure to AFFF has caused certain personal injuries. The Company and KFI believe that they have meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate a range of possible loss at this time. There can be no assurance that any such future exposure will not be material in any period.

- changed (2023-10-26):
[0001783180-23-000065:note_history:8]
On May 14, 2023, KFI filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware seeking relief under Chapter 11 of the Bankruptcy Code after the Company determined that it would not provide financial support to KFI going forward, other than ensuring KFI has access to services necessary for the effective operation of its business. As a result, all litigation against KFI is automatically stayed. KFI filed an adversary complaint and motion in the Chapter 11 case seeking an order staying or enjoining all AFFF-related litigation against the Company, its other subsidiaries and RTX. That motion was resolved through an agreement that effectively stays the AFFF litigation against these parties. KFI has also indicated to the bankruptcy court that it intends to pursue insurance coverage for AFFF-related liabilities and contractual indemnification for AFFF-related liabilities from the third party to which KFI sold National Foam.
  (was, 2023-07-27, similarity 0.6811):
[0001783180-23-000056:note_history:8]
On May 14, 2023, KFI filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware seeking relief under Chapter 11 of the Bankruptcy Code after the Company determined that it would not provide financial support to KFI going forward, other than ensuring KFI has access to services necessary for the effective operation of its business. As a result, all litigation against KFI is automatically stayed. KFI filed an adversary complaint and motion in the Chapter 11 case seeking an order staying or enjoining all AFFF-related litigation against the Company, its other subsidiaries and RTX. KFI has also indicated to the bankruptcy court that it intends to pursue insurance coverage for AFFF-related liabilities and contractual indemnification for AFFF-related liabilities from the third party to which KFI sold National Foam.

- changed (2023-10-26):
[0001783180-23-000065:note_history:9]
As of May 14, 2023, the Company no longer controlled KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from the Company’s Unaudited Condensed Consolidated Financial Statements. Upon deconsolidation, the Company determined the fair value of its retained interest in KFI to be zero and will account for it prospectively using the cost method. As a result of these actions, the Company recognized a loss of $297 million in its Unaudited Condensed Consolidated Statements of Operations
  (was, 2023-07-27, similarity 0.9967):
[0001783180-23-000056:note_history:9]
As of May 14, 2023, the Company no longer controls KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from the Company’s Unaudited Condensed Consolidated Financial Statements. Upon deconsolidation, the Company determined the fair value of its retained interest in KFI to be zero and will account for it prospectively using the cost method. As a result of these actions, the Company recognized a loss of $293 million in its Unaudited Condensed Consolidated Statements of Operations

- changed (2023-10-26):
[0001783180-23-000065:note_history:10]
Under the Tax Matters Agreement relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, liabilities of $75 million and $293 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of September 30, 2023, respectively. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $75 million due in 2024. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.
  (was, 2023-07-27, similarity 0.9905):
[0001783180-23-000056:note_history:10]
Under the Tax Matters Agreement relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, liabilities of $75 million and $293 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of June 30, 2023, respectively. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $75 million due in 2024. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.


## us-gaap:ScheduleOfEnvironmentalLossContingenciesBySiteTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-10-26):
[0001783180-23-000065:note_history:11]
| (In millions) |  | September 30,2023 |  | December 31,2022 |
| Environmental reserves included in Accrued liabilities |  | $ | 12 |  |  | $ | 24 |  |
| Environmental reserves included in Other long-term liabilities |  | 208 |  |  | 211 |  |
| Total Environmental reserves |  | $ | 220 |  |  | $ | 235 |  |
  (was, 2023-07-27, similarity 0.9758):
[0001783180-23-000056:note_history:11]
| (In millions) |  | June 30,2023 |  | December 31,2022 |
| Environmental reserves included in Accrued liabilities |  | $ | 15 |  |  | $ | 24 |  |
| Environmental reserves included in Other long-term liabilities |  | 203 |  |  | 211 |  |
| Total Environmental reserves |  | $ | 218 |  |  | $ | 235 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-10-26):
[0001783180-23-000065:note_history:12]
| (In millions) |  | September 30,2023 |  | December 31,2022 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 16 |  |  | $ | 16 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 207 |  |  | 212 |  |
| Total Asbestos liabilities |  | $ | 223 |  |  | $ | 228 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 89 |  |  | 90 |  |
| Total Asbestos-related recoveries |  | $ | 94 |  |  | $ | 95 |  |
  (was, 2023-07-27, similarity 0.9867):
[0001783180-23-000056:note_history:12]
| (In millions) |  | June 30,2023 |  | December 31,2022 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 16 |  |  | $ | 16 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 207 |  |  | 212 |  |
| Total Asbestos liabilities |  | $ | 223 |  |  | $ | 228 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 89 |  |  | 90 |  |
| Total Asbestos-related recoveries |  | $ | 94 |  |  | $ | 95 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2023-10-26):
[0001783180-23-000065:note_history:13]
On May 14, 2023, Kidde-Fenwal, Inc. ("KFI"), an indirect wholly-owned subsidiary of the Company, filed a petition for voluntary reorganization under Chapter 11 of the United States Bankruptcy Code ("Chapter 11") in the United States Bankruptcy Court for the District of Delaware. KFI, an industrial fire detection and suppression business historically reported in the Company's Fire & Security segment, has indicated that it intends to use the bankruptcy process to explore strategic alternatives, including the sale of KFI as a going concern. KFI has further stated that, during the Chapter 11 process, KFI expects that there will be no significant interruptions to its business operations. As of the petition date, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company's Unaudited Condensed Consolidated Financial Statements. See Note 19 - Commitments and Contingent Liabilities for additional information.

- removed (2023-10-26):
[0001783180-23-000056:note_history:14]
On May 14, 2023, Kidde-Fenwal, Inc. ("KFI") filed a petition for voluntary reorganization under Chapter 11 of the United States Bankruptcy Code ("Chapter 11") in the United States Bankruptcy Court for the District of Delaware. KFI, an industrial fire detection and suppression business and an indirect wholly-owned subsidiary of the Company, has indicated that it intends to use the bankruptcy process to explore strategic alternatives, including the sale of KFI as a going concern. KFI has further stated that, during the Chapter 11 process, KFI expects that there will be no significant interruptions to its business operations. As of the petition date, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company's Unaudited Condensed Consolidated Financial Statements. See Note 19 - Commitments and Contingent Liabilities for additional information.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-10-26):
[0001783180-23-000065:note_history:15]
| (In millions) |  |  |  | September 30,2023 |  | December 31,2022 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 900 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term notes |  |  |  | 8,350 |  |  | 8,350 |  |
| Japanese Term Loan Facility |  |  |  | 362 |  |  | 404 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 154 |  |  | 149 |  |
| Discounts and debt issuance costs |  |  |  | (81) |  |  | (61) |  |
| Total debt |  |  |  | 8,785 |  |  | 8,842 |  |
| Less: current portion of long-term debt |  |  |  | 134 |  |  | 140 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,651 |  |  | $ | 8,702 |  |
  (was, 2023-07-27, similarity 0.9916):
[0001783180-23-000056:note_history:15]
| (In millions) |  |  |  | June 30,2023 |  | December 31,2022 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 900 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term notes |  |  |  | 8,350 |  |  | 8,350 |  |
| Japanese Term Loan Facility |  |  |  | 374 |  |  | 404 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 146 |  |  | 149 |  |
| Discounts and debt issuance costs |  |  |  | (81) |  |  | (61) |  |
| Total debt |  |  |  | 8,789 |  |  | 8,842 |  |
| Less: current portion of long-term debt |  |  |  | 134 |  |  | 140 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,655 |  |  | $ | 8,702 |  |

- changed (2023-10-26):
[0001783180-23-000065:note_history:16]
On May 19, 2023, the Company entered into a revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in May 2028 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings can bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. Upon entering into the agreement, the Company terminated its existing revolving credit facility that was set to mature in April 2025. In addition, the Company capitalized $2 million of deferred financing costs which are being amortized over its term. As of September 30, 2023, there were no borrowings outstanding under the Revolving Credit Facility.
  (was, 2023-07-27, similarity 0.994):
[0001783180-23-000056:note_history:16]
On May 19, 2023, the Company entered into a revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in May 2028 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings can bear interest at either a Term SOFR Rate plus 0.10% and a rating-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. Upon entering into the agreement, the Company terminated its existing revolving credit facility that was set to mature in April 2025. In addition, the Company capitalized $2 million of deferred financing costs which are being amortized over its term. As of June 30, 2023, there were no borrowings outstanding under the Revolving Credit Facility.

- changed (2023-10-26):
[0001783180-23-000065:note_history:17]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of September 30, 2023, there were no borrowings outstanding under the commercial paper program.
  (was, 2023-07-27, similarity 0.9775):
[0001783180-23-000056:note_history:17]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of June 30, 2023, there were no borrowings outstanding under the commercial paper program.

- changed (2023-10-26):
[0001783180-23-000065:note_history:18]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $14 million and $27 million of debt during the nine months ended September 30, 2023 and 2022, respectively. Long-term debt repayments associated with these financing arrangements during the nine months ended September 30, 2023 and 2022 were $15 million and $70 million, respectively.
  (was, 2023-07-27, similarity 0.8832):
[0001783180-23-000056:note_history:18]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $6 million and $21 million of debt during the six months ended June 30, 2023 and 2022, respectively. Long-term debt repayments associated with these financing arrangements during the six months ended June 30, 2023 and 2022 were $12 million and $12 million, respectively.

- changed (2023-10-26):
[0001783180-23-000065:note_history:19]
The Revolving Credit Facility, the indenture for the long-term notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of September 30, 2023, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.
  (was, 2023-07-27, similarity 0.7719):
[0001783180-23-000056:note_history:19]
The Revolving Credit Facility, the indenture for the long-term notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of June 30, 2023, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-10-26):
[0001783180-23-000065:note_history:20]
| (In millions) |  |  |  | September 30,2023 |  | December 31,2022 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 900 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term notes |  |  |  | 8,350 |  |  | 8,350 |  |
| Japanese Term Loan Facility |  |  |  | 362 |  |  | 404 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 154 |  |  | 149 |  |
| Discounts and debt issuance costs |  |  |  | (81) |  |  | (61) |  |
| Total debt |  |  |  | 8,785 |  |  | 8,842 |  |
| Less: current portion of long-term debt |  |  |  | 134 |  |  | 140 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,651 |  |  | $ | 8,702 |  |
  (was, 2023-07-27, similarity 0.9916):
[0001783180-23-000056:note_history:20]
| (In millions) |  |  |  | June 30,2023 |  | December 31,2022 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 900 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term notes |  |  |  | 8,350 |  |  | 8,350 |  |
| Japanese Term Loan Facility |  |  |  | 374 |  |  | 404 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 146 |  |  | 149 |  |
| Discounts and debt issuance costs |  |  |  | (81) |  |  | (61) |  |
| Total debt |  |  |  | 8,789 |  |  | 8,842 |  |
| Less: current portion of long-term debt |  |  |  | 134 |  |  | 140 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,655 |  |  | $ | 8,702 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2023-10-26):
[0001783180-23-000065:note_history:21]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Sales to equity method investees included in Product sales |  | $ | 730 |  |  | $ | 718 |  |  | $ | 2,371 |  |  | $ | 2,129 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 57 |  |  | $ | 60 |  |  | $ | 159 |  |  | $ | 261 |  |

- added (2023-10-26):
[0001783180-23-000065:note_history:22]
| (In millions) |  | September 30,2023 |  | December 31,2022 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 289 |  |  | $ | 154 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 35 |  |  | $ | 44 |  |

- removed (2023-10-26):
[0001783180-23-000056:note_history:23]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Sales to equity method investees included in Product sales |  | $ | 887 |  |  | $ | 787 |  |  | $ | 1,641 |  |  | $ | 1,411 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 59 |  |  | $ | 91 |  |  | $ | 102 |  |  | $ | 201 |  |

- removed (2023-10-26):
[0001783180-23-000056:note_history:24]
| (In millions) |  | June 30,2023 |  | December 31,2022 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 364 |  |  | $ | 154 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 39 |  |  | $ | 44 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-10-26):
[0001783180-23-000065:note_history:25]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,533 |  |  | $ | 3,330 |  |  | $ | 10,488 |  |  | $ | 8,974 |  |
| Service |  | 475 |  |  | 404 |  |  | 1,358 |  |  | 1,118 |  |
| HVAC sales |  | 4,008 |  |  | 3,734 |  |  | 11,846 |  |  | 10,092 |  |
| Product |  | 808 |  |  | 811 |  |  | 2,453 |  |  | 2,603 |  |
| Service |  | 116 |  |  | 112 |  |  | 341 |  |  | 337 |  |
| Refrigeration sales |  | 924 |  |  | 923 |  |  | 2,794 |  |  | 2,940 |  |
| Product |  | 864 |  |  | 859 |  |  | 2,546 |  |  | 2,468 |  |
| Service |  | 59 |  |  | 46 |  |  | 178 |  |  | 142 |  |
| Fire & Security sales |  | 923 |  |  | 905 |  |  | 2,724 |  |  | 2,610 |  |
| Total segment sales |  | 5,855 |  |  | 5,562 |  |  | 17,364 |  |  | 15,642 |  |
| Eliminations and other |  | (124) |  |  | (111) |  |  | (368) |  |  | (326) |  |
| Net sales |  | $ | 5,731 |  |  | $ | 5,451 |  |  | $ | 16,996 |  |  | $ | 15,316 |  |
  (was, 2023-07-27, similarity 0.968):
[0001783180-23-000056:note_history:25]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,754 |  |  | $ | 3,005 |  |  | $ | 6,955 |  |  | $ | 5,644 |  |
| Service |  | 462 |  |  | 383 |  |  | 883 |  |  | 714 |  |
| HVAC sales |  | 4,216 |  |  | 3,388 |  |  | 7,838 |  |  | 6,358 |  |
| Product |  | 858 |  |  | 925 |  |  | 1,645 |  |  | 1,792 |  |
| Service |  | 114 |  |  | 116 |  |  | 225 |  |  | 225 |  |
| Refrigeration sales |  | 972 |  |  | 1,041 |  |  | 1,870 |  |  | 2,017 |  |
| Product |  | 869 |  |  | 838 |  |  | 1,682 |  |  | 1,609 |  |
| Service |  | 63 |  |  | 49 |  |  | 119 |  |  | 96 |  |
| Fire & Security sales |  | 932 |  |  | 887 |  |  | 1,801 |  |  | 1,705 |  |
| Total segment sales |  | 6,120 |  |  | 5,316 |  |  | 11,509 |  |  | 10,080 |  |
| Eliminations and other |  | (128) |  |  | (105) |  |  | (244) |  |  | (215) |  |
| Net sales |  | $ | 5,992 |  |  | $ | 5,211 |  |  | $ | 11,265 |  |  | $ | 9,865 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-10-26):
[0001783180-23-000065:note_history:26]
REVENUE RECOGNITIONThe Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.
Sales disaggregated by product and service are as follows:
  (was, 2023-07-27, similarity 0.9682):
[0001783180-23-000056:note_history:26]
REVENUE RECOGNITION 
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.

- changed (2023-10-26):
[0001783180-23-000065:note_history:27]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,533 |  |  | $ | 3,330 |  |  | $ | 10,488 |  |  | $ | 8,974 |  |
| Service |  | 475 |  |  | 404 |  |  | 1,358 |  |  | 1,118 |  |
| HVAC sales |  | 4,008 |  |  | 3,734 |  |  | 11,846 |  |  | 10,092 |  |
| Product |  | 808 |  |  | 811 |  |  | 2,453 |  |  | 2,603 |  |
| Service |  | 116 |  |  | 112 |  |  | 341 |  |  | 337 |  |
| Refrigeration sales |  | 924 |  |  | 923 |  |  | 2,794 |  |  | 2,940 |  |
| Product |  | 864 |  |  | 859 |  |  | 2,546 |  |  | 2,468 |  |
| Service |  | 59 |  |  | 46 |  |  | 178 |  |  | 142 |  |
| Fire & Security sales |  | 923 |  |  | 905 |  |  | 2,724 |  |  | 2,610 |  |
| Total segment sales |  | 5,855 |  |  | 5,562 |  |  | 17,364 |  |  | 15,642 |  |
| Eliminations and other |  | (124) |  |  | (111) |  |  | (368) |  |  | (326) |  |
| Net sales |  | $ | 5,731 |  |  | $ | 5,451 |  |  | $ | 16,996 |  |  | $ | 15,316 |  |
  (was, 2023-07-27, similarity 0.968):
[0001783180-23-000056:note_history:27]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,754 |  |  | $ | 3,005 |  |  | $ | 6,955 |  |  | $ | 5,644 |  |
| Service |  | 462 |  |  | 383 |  |  | 883 |  |  | 714 |  |
| HVAC sales |  | 4,216 |  |  | 3,388 |  |  | 7,838 |  |  | 6,358 |  |
| Product |  | 858 |  |  | 925 |  |  | 1,645 |  |  | 1,792 |  |
| Service |  | 114 |  |  | 116 |  |  | 225 |  |  | 225 |  |
| Refrigeration sales |  | 972 |  |  | 1,041 |  |  | 1,870 |  |  | 2,017 |  |
| Product |  | 869 |  |  | 838 |  |  | 1,682 |  |  | 1,609 |  |
| Service |  | 63 |  |  | 49 |  |  | 119 |  |  | 96 |  |
| Fire & Security sales |  | 932 |  |  | 887 |  |  | 1,801 |  |  | 1,705 |  |
| Total segment sales |  | 6,120 |  |  | 5,316 |  |  | 11,509 |  |  | 10,080 |  |
| Eliminations and other |  | (128) |  |  | (105) |  |  | (244) |  |  | (215) |  |
| Net sales |  | $ | 5,992 |  |  | $ | 5,211 |  |  | $ | 11,265 |  |  | $ | 9,865 |  |

- changed (2023-10-26):
[0001783180-23-000065:note_history:28]
| (In millions) |  | September 30,2023 |  | December 31,2022 |
| Contract assets, current |  | $ | 605 |  |  | $ | 537 |  |
| Contract assets, non-current (included within Other assets) |  | 18 |  |  | 6 |  |
| Total contract assets |  | 623 |  |  | 543 |  |
| Contract liabilities, current |  | (496) |  |  | (449) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (166) |  |  | (174) |  |
| Total contract liabilities |  | (662) |  |  | (623) |  |
| Net contract assets (liabilities) |  | $ | (39) |  |  | $ | (80) |  |
  (was, 2023-07-27, similarity 0.9869):
[0001783180-23-000056:note_history:28]
| (In millions) |  | June 30,2023 |  | December 31,2022 |
| Contract assets, current |  | $ | 578 |  |  | $ | 537 |  |
| Contract assets, non-current (included within Other assets) |  | 8 |  |  | 6 |  |
| Total contract assets |  | 586 |  |  | 543 |  |
| Contract liabilities, current |  | (483) |  |  | (449) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (170) |  |  | (174) |  |
| Total contract liabilities |  | (653) |  |  | (623) |  |
| Net contract assets (liabilities) |  | $ | (67) |  |  | $ | (80) |  |

- changed (2023-10-26):
[0001783180-23-000065:note_history:29]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.
  (was, 2023-07-27, similarity 0.8199):
[0001783180-23-000056:note_history:29]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. 
The Company recognized revenue of $264 million during the six months ended June 30, 2023 that related to contract liabilities as of January 1, 2023. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.

- added (2023-10-26):
[0001783180-23-000065:note_history:30]
The Company recognized revenue of $325 million during the nine months ended September 30, 2023 that related to contract liabilities as of January 1, 2023. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.

- removed (2023-10-26):
[0001783180-23-000056:note_history:31]
Sales disaggregated by product and service are as follows:
