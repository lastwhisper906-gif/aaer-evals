# CARR notes — 0001783180-24-000009


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001783180-24-000009:notes:1]
Part III hereof incorporates by reference portions of the Registrant's definitive proxy statement related to its 2024 annual meeting of shareowners.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-24-000009:notes:2]
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation (the "Company") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Toshiba, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating and air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into three segments: HVAC, Refrigeration and Fire & Security.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-24-000009:notes:3]
BASIS OF PRESENTATION 
The accompanying Consolidated Financial Statements reflect the consolidated operations of the Company and have been prepared in accordance with U.S. Generally Accepted Accounting Principles ("GAAP") as defined by the Financial Accounting Standards Board ("FASB") within the FASB Accounting Standards Codification ("ASC"). Inter-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated.

[0001783180-24-000009:notes:4]
The accompanying Consolidated Financial Statements include all majority-owned subsidiaries of the Company. A non-controlling interest in a subsidiary is considered an ownership interest in a majority-owned subsidiary that is not attributable to the parent. The Company includes Non-controlling interest as a component of Total equity in the accompanying Consolidated Balance Sheet and the Non-controlling interest in subsidiaries' earnings from operations are presented as an adjustment to Net income from operations used to arrive at Net income attributable to common shareowners in the accompanying Consolidated Statement of Operations. Partially-owned equity affiliates represent 20 to 50% ownership interests in investments where the Company demonstrates significant influence, but does not have a controlling financial interest. Partially-owned equity affiliates are accounted for under the equity method.

[0001783180-24-000009:notes:5]
Planned Portfolio Transformation

[0001783180-24-000009:notes:6]
On April 25, 2023, the Company announced that it entered into a Share Purchase Agreement (the “Agreement”) to acquire the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (“Viessmann”), a privately-held company. The VCS Business develops intelligent, integrated and sustainable technologies, including heat pumps, boilers, photovoltaic systems, home battery storage and digital solutions, primarily for residential customers in Europe. The acquisition was completed on January 2, 2024 for total consideration of $14.2 billion.

[0001783180-24-000009:notes:7]
On April 25, 2023, the Company announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. On December 7, 2023, the Company entered into a stock purchase agreement to sell its Access Solutions business ("Access Solutions") to Honeywell International Inc. for an enterprise value of approximately $4.95 billion. Access Solutions, historically reported in the Company's Fire & Security segment, is a global supplier of physical security and digital access solutions supporting the hospitality, commercial, education and military markets. On December 12, 2023, the Company entered into a stock purchase agreement to sell its Commercial Refrigeration business ("CCR") to Haier Group Corporation for an enterprise value of approximately $775 million. CCR, historically reported in the Company's Refrigeration segment, is a global supplier of turnkey solutions for commercial refrigeration systems and services, with a primary focus on serving food retail customers, cold storage facilities and warehouses. As a result, the assets and liabilities of both businesses are presented as held for sale in the accompanying Consolidated Balance Sheets as of December 31, 2023 and recorded at the lower of their carrying value or fair value less estimated cost to sell.

[0001783180-24-000009:notes:8]
In addition, the net assets of the Company’s Industrial Fire business met the criteria to be classified as held for sale during the fourth quarter of 2023. Industrial Fire, historically reported in the Company's Fire & Security segment, is a leading manufacturer of a full spectrum of fire detection and suppression solutions and services in critical high-hazard environments, including oil and gas, power generation, marine and offshore facilities, automotive, data centers and aircraft hangars. As a result, the assets and liabilities of the business are presented as held for sale in the accompanying Consolidated Balance Sheet as of December 31, 2023 and recorded at the lower of their carrying value or fair value less estimated cost to sell.

[0001783180-24-000009:notes:9]
Deconsolidation of Kidde-Fenwal, Inc.

[0001783180-24-000009:notes:10]
On May 14, 2023, Kidde-Fenwal, Inc. ("KFI"), an indirect wholly-owned subsidiary of the Company, filed a petition for voluntary reorganization under Chapter 11 of the United States Bankruptcy Code ("Chapter 11") in the United States Bankruptcy Court for the District of Delaware. KFI, an industrial fire detection and suppression business historically reported in the Company's Fire & Security segment, has indicated that it intends to use the bankruptcy process to explore strategic alternatives, including the sale of KFI as a going concern. KFI has further stated that, during the Chapter 11 process, KFI expects that there will be no significant interruptions to its business operations. As of the petition date, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company's Consolidated Financial Statements.

[0001783180-24-000009:notes:11]
Acquisition of Toshiba Carrier Corporation

[0001783180-24-000009:notes:12]
On February 6, 2022, the Company entered into a binding agreement to acquire a majority ownership interest in Toshiba Carrier Corporation (“TCC”), a variable refrigerant flow ("VRF") and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The acquisition was completed on August 1, 2022. As a result, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Consolidated Financial Statements as of the date of acquisition and reported within the Company’s HVAC segment. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC.

[0001783180-24-000009:notes:13]
Sale of Chubb Fire & Security Business

[0001783180-24-000009:notes:14]
On July 26, 2021, the Company entered into a stock purchase agreement to sell its Chubb Fire and Security business ("Chubb") to APi Group Corporation ("APi"). Chubb, which was reported within the Company's Fire & Security segment, delivered essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. On January 3, 2022, the Company completed the sale of Chubb (the "Chubb Sale") for net proceeds of $2.9 billion and recognized a gain on the sale of $1.1 billion during the year ended December 31, 2022.

[0001783180-24-000009:notes:15]
Separation from United Technologies

[0001783180-24-000009:notes:16]
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date for the Distribution. In connection with the Separation, the Company issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020. On April 1, 2020 and April 2, 2020, the Company received cash contributions totaling $590 million from UTC related to the Separation.

[0001783180-24-000009:notes:17]
Following the Separation and Distribution, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of December 31, 2023, only certain portions of the Tax Matters Agreement ("TMA") remain in effect. The Company incurred separation-related costs of $20 million for the year ended December 31, 2021. These costs are primarily included in Selling, general and administrative in the accompanying Consolidated Statement of Operations and consist of employee-related costs, costs to establish certain stand-alone functions and information technology systems, professional service fees and other transaction-related costs resulting from Carrier’s transition to becoming an independent, publicly traded company.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001783180-24-000009:notes:18]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
A summary of significant accounting policies used in the preparation of the accompanying Consolidated Financial Statements is as follows:

[0001783180-24-000009:notes:19]
Use of Estimates. The preparation of the Consolidated Financial Statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements as well as the reported amounts of revenues and expenses during the reporting period. Estimates are based on several factors including the facts and circumstances available at the time the estimates are made, historical experience and various other assumptions that are believed to be reasonable under the circumstances. Actual results could differ from those estimates.

[0001783180-24-000009:notes:20]
Currency Translation. Assets and liabilities of non-U.S. subsidiaries, where the functional currency is not the U.S. dollar, have been translated at year-end exchange rates, and income and expense accounts have been translated using average exchange rates throughout the year. Adjustments resulting from the process of translating an entity’s financial statements into the U.S. dollar have been recorded in the equity section of the Consolidated Balance Sheet within Accumulated other comprehensive income (loss). Transactions that are denominated in a currency other than an entity’s functional currency are subject to changes in exchange rates with the resulting gains and losses recorded in Net income from operations.

[0001783180-24-000009:notes:21]
Cash and Cash Equivalents. Cash and cash equivalents include cash on hand, demand deposits and short-term cash investments that are highly liquid in nature and have original maturities of three months or less. On occasion, the Company is required to maintain restricted cash deposits with certain banks due to contractual or other legal obligations. Restricted cash of $2 million and $7 million is included in Other assets, current as of December 31, 2023 and 2022, respectively.

[0001783180-24-000009:notes:22]
Accounts Receivable. Accounts receivable consist of billed amounts owed for products shipped to or services performed for customers. Amounts are recorded net of an allowance for expected credit losses which represents the best estimate of probable loss inherent in the Company's accounts receivable portfolio. The allowance is determined using a combination of factors including a reserve based on the aging of the outstanding accounts receivable portfolio and the Company's historical credit loss experience with its end markets, customer base and products. In addition, the Company considers knowledge of specific customers, current market conditions as well as reasonable and supportable forecasts of future events and economic conditions. As of December 31, 2023 and 2022, the allowance for expected credit losses was $108 million and $117 million, respectively. These estimates and assumptions are reviewed periodically with the effects of changes, if any, reflected in the Consolidated Statement of Operations in the period that they are determined.

[0001783180-24-000009:notes:23]
Fixed Assets. Property, plant and equipment are stated at cost less accumulated depreciation. Assets placed in service are recorded at cost and depreciated using the straight-line method over the estimated useful life of the asset. Assets acquired in a business combination are recorded at fair value at the date of acquisition. Major expenditures for replacements and significant improvements that increase asset values and extend useful lives are capitalized. Repairs and maintenance expenditures that do not extend the useful life of an asset are charged to expense as incurred.

[0001783180-24-000009:notes:24]
Per ASC 360, Property, Plant and Equipment ("ASC 360"), the Company assesses the recoverability of the carrying value of its property, plant and equipment whenever events or changes in circumstances indicate that the carrying amount of an asset group may not be recoverable. Recoverability is measured by a comparison of the carrying amount of an asset group to the future net undiscounted cash flows expected to be generated by the asset group. If the undiscounted cash flows are less than the carrying amount of the asset group, an impairment loss is recognized for the amount by which the carrying amount of the asset group exceeds the fair value of the asset group.

[0001783180-24-000009:notes:25]
Equity Method Investments. Investments in which the Company has the ability to exercise significant influence, but does not control, are accounted for under the equity method of accounting and are presented on the Consolidated Balance Sheet. Under this method of accounting, the Company’s share of the net earnings or losses of the investee is presented within Operating profit on the Consolidated Statement of Operations since the activities of the investee are closely aligned with the operations of the Company. The Company evaluates its equity method investments whenever events or changes in circumstance indicate that the carrying amounts of such investments may be impaired. If a decline in the value of an equity method investment is determined to be other than temporary, a loss is recorded in earnings in the current period. Distributions received from equity method investees are presented in the Consolidated Statement of Cash Flows based on the cumulative earnings approach.

[0001783180-24-000009:notes:26]
Goodwill and Intangible Assets. The Company records goodwill as the excess of the purchase price over the fair value of the net assets acquired in a business combination. In accordance with ASC 350, Intangibles - Goodwill and Other ("ASC 350"), goodwill and other indefinite-lived intangibles are tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicate that the fair value of the asset is more likely than not less than the carrying amount of the asset.

[0001783180-24-000009:notes:27]
Impairment of goodwill is assessed at the reporting unit level and begins with a qualitative assessment to determine if it is more likely than not that the fair value of each reporting unit is less than its carrying amount as a basis for determining whether it is necessary to perform the goodwill impairment test under ASC 350. For those reporting units that bypass or fail the qualitative assessment, the test compares the carrying amount of the reporting unit to its estimated fair value. If the estimated fair value of a reporting unit exceeds its carrying amount, goodwill of the reporting unit is not impaired. To the extent that the carrying amount of the reporting unit exceeds its estimated fair value, an impairment loss will be recognized for the amount by which the reporting unit's carrying amount exceeds its fair value, not to exceed the carrying amount of goodwill in that reporting unit.

[0001783180-24-000009:notes:28]
Intangible assets such as patents, service contracts, monitoring lines and customer relationships with finite useful lives are amortized based on the pattern in which the economic benefits of the intangible assets are consumed. If a pattern of economic benefit cannot be reliably determined or if straight-line amortization approximates the pattern of economic benefit, a straight-line amortization may be used.

[0001783180-24-000009:notes:29]
The range of useful lives approximate the following (in years):

[0001783180-24-000009:notes:30]
| Customer relationships | 1 to 30 |
| Patents and trademarks | 5 to 30 |
| Monitoring lines | 7 to 10 |
| Service portfolio and other | 1 to 23 |

[0001783180-24-000009:notes:31]
The Company assesses the recoverability of the carrying amount of its intangible assets with finite useful lives whenever events or changes in circumstances indicate that the carrying amount of the asset group may not be recoverable. Recoverability is measured by a comparison of the carrying amount of an asset group to the future net undiscounted cash flows expected to be generated by the asset group. If the undiscounted cash flows are less than the carrying amount of the asset group, an impairment loss is recognized for the amount by which the carrying value of the asset group exceeds the fair value of the asset group.

[0001783180-24-000009:notes:32]
Leases. The Company accounts for leases in accordance with ASC 842, Leases ("ASC 842"), which requires a lessee to record a right-of-use ("ROU") asset and a lease liability on the Consolidated Balance Sheet for all leases with terms longer than 12 months. ROU assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. The Company generally uses its incremental borrowing rate, which is based on information available at the lease commencement date, to determine the present value of lease payments except when an implicit interest rate is readily determinable. The lease term may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. The Company has elected not to recognize ROU assets and lease obligations for its short-term leases, which are defined as leases with an initial term of 12 months or less.

[0001783180-24-000009:notes:33]
Income Taxes. The Company accounts for income taxes in accordance with ASC 740, Income Taxes ("ASC 740"). Deferred tax assets and liabilities are determined based on temporary differences between financial reporting and tax bases of assets and liabilities, applying enacted tax rates expected to be in effect for the year in which the differences are expected to reverse. The Company recognizes future tax benefits to the extent that realizing these benefits is considered in its judgment to be more likely than not. For those jurisdictions where the expiration date of tax carryforwards or the projected operating results indicate that realization is not likely, a valuation allowance is provided. The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required and will adjust its estimate if significant events so dictate. To the extent that the ultimate results differ from the Company's original or adjusted estimates, the effect will be recorded in the provision for income taxes in the period that the matter is finally resolved.

[0001783180-24-000009:notes:34]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. For those tax positions where it is more likely than not that a tax benefit will be sustained, the Company has recorded the largest amount of tax benefit with a greater than 50% likelihood of being realized upon ultimate settlement with a taxing authority that has full knowledge of all relevant information. For those income tax positions where it is not more likely than not that a tax benefit will be sustained, no tax benefit has been recognized in the Consolidated Financial Statements.

[0001783180-24-000009:notes:35]
Pension and Post-retirement Obligations. The Company provides a range of benefit plans to eligible current and former employees. The Company accounts for its benefit plans in accordance with ASC 715, Compensation - Retirement Benefits ("ASC 715") which requires balance sheet recognition of the overfunded or underfunded status of pension and post-retirement benefit plans. Determining the amounts associated with these benefits are performed by actuaries and dependent on various actuarial assumptions including discount rates, expected return on plan assets, compensation increases, mortality and health care cost trends. Actual results may differ from the actuarial assumptions and are generally recorded in Accumulated other comprehensive income (loss) and amortized into Net income from operations over future periods. The Company reviews its actuarial assumptions at each measurement date and makes modifications to the assumptions based on current rates and trends, if appropriate. See Note 10 – Employee Benefit Plans for additional information.

[0001783180-24-000009:notes:36]
Business Combinations. In accordance with ASC 805, Business Combinations ("ASC 805"), acquisitions that meet the definition of a business are recorded using the acquisition method of accounting. We recognize and measure the identifiable assets acquired, liabilities assumed and any non-controlling interest as of the acquisition date at fair value. The valuation of intangible assets is determined by an income approach methodology, using assumptions such as projected future revenues, customer attrition rates, royalty rates, tax rates and discount rates. The excess, if any, of total consideration transferred in a business combination over the fair value of identifiable assets acquired, liabilities assumed and any non-controlling interest is recognized as goodwill. Costs incurred as a result of a business combination other than costs related to the issuance of debt or equity securities are recorded in the period the costs are incurred.

[0001783180-24-000009:notes:37]
Asset Retirement Obligations. The Company records the fair value of legal obligations associated with the retirement of tangible long-lived assets in the period in which a liability is determined to exist, if a reasonable estimate of fair value can be made. Upon initial recognition of a liability, the Company capitalizes the cost of the asset retirement obligation by increasing the carrying amount of the related long-lived asset. Over time, the liability is increased for changes in its present value and the capitalized cost is depreciated over the useful life of the related asset.

[0001783180-24-000009:notes:38]
Research and Development. The Company conducts research and development activities with a focus on new product development and technology innovation. These costs are charged to expense as incurred. For the years ended December 31, 2023, 2022 and 2021, these costs amounted to $617 million, $539 million and $503 million, respectively.

[0001783180-24-000009:notes:39]
Recent Pronouncements

[0001783180-24-000009:notes:40]
The FASB ASC is the sole source of authoritative GAAP other than United States Securities and Exchange Commission ("SEC') issued rules and regulations that apply only to SEC registrants. The FASB issues Accounting Standards Updates ("ASU") to communicate changes to the codification. The Company considers the applicability and impact of all ASUs. ASUs not referenced below were assessed and determined to be either not applicable or are not expected to have a material impact on the Consolidated Financial Statements.

[0001783180-24-000009:notes:41]
Recently Issued Accounting Pronouncements

[0001783180-24-000009:notes:42]
In November 2023, the FASB issued ASU 2023-07, Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures (“ASU 2023-07”), which requires public entities to disclose information about their reportable segments’ significant expenses on an interim and annual basis. In addition, the amendments clarify circumstances in which an entity can disclose multiple segment measures of profit or loss, provides new segment disclosure requirements for entities with a single reportable segment and contains other disclosure requirements. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.

[0001783180-24-000009:notes:43]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"), which requires public entities to disclose disaggregated information about their effective tax rate reconciliation as well as information on income taxes paid. ASU 2023-09 is effective for fiscal years beginning after December 15, 2023 and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001783180-24-000009:notes:44]
Identifiable intangible assets consisted of the following:

[0001783180-24-000009:notes:45]
|  |  |  | 2023 |  | 2022 |
| (In millions) |  |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Amortized: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  |  | $ | 1,222 |  |  | $ | (610) |  |  | $ | 612 |  |  | $ | 1,431 |  |  | $ | (720) |  |  | $ | 711 |  |
| Patents and trademarks |  |  | 332 |  |  | (163) |  |  | 169 |  |  | 401 |  |  | (191) |  |  | 210 |  |
| Service portfolios and other |  |  | 686 |  |  | (503) |  |  | 183 |  |  | 953 |  |  | (595) |  |  | 358 |  |
|  |  |  | 2,240 |  |  | (1,276) |  |  | 964 |  |  | 2,785 |  |  | (1,506) |  |  | 1,279 |  |
| Unamortized: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks and other |  |  | 64 |  |  | — |  |  | 64 |  |  | 63 |  |  | — |  |  | 63 |  |
| Intangible assets, net |  |  | $ | 2,304 |  |  | $ | (1,276) |  |  | $ | 1,028 |  |  | $ | 2,848 |  |  | $ | (1,506) |  |  | $ | 1,342 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001783180-24-000009:notes:46]
INVENTORIES, NET 
Inventories are stated at the lower of cost or estimated net realizable value. Cost is primarily determined based on the first-in, first-out inventory method ("FIFO") or average cost methods, which approximates current replacement cost. However, certain Carrier entities use the last-in, first-out inventory method ("LIFO").

[0001783180-24-000009:notes:47]
Inventories, net consisted of the following:

[0001783180-24-000009:notes:48]
| (In millions) | 2023 |  | 2022 |
| Raw materials | $ | 695 |  |  | $ | 884 |  |
| Work-in-process | 259 |  |  | 230 |  |
| Finished goods | 1,263 |  |  | 1,526 |  |
| Inventories, net | $ | 2,217 |  |  | $ | 2,640 |  |

[0001783180-24-000009:notes:49]
The Company performs periodic assessments utilizing customer demand, production requirements and historical usage rates to determine the existence of excess and obsolete inventory and records necessary provisions to reduce such inventories to the lower of cost or estimated net realizable value. Raw materials, work-in-process and finished goods are net of valuation reserves of $223 million and $190 million as of December 31, 2023 and 2022, respectively.

[0001783180-24-000009:notes:50]
Certain entities use LIFO to determine the cost of inventory. If inventories that were valued using the LIFO method had been valued under the FIFO method, the net book value of the inventories would have been higher by $226 million and $199 million as of December 31, 2023 and 2022, respectively. As of December 31, 2023 and 2022, approximately 35% and 26%, respectively, of all inventory utilized the LIFO method.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001783180-24-000009:notes:51]
FIXED ASSETS, NET 
Fixed assets, net consisted of the following:

[0001783180-24-000009:notes:52]
| (In millions) | Estimated Useful Lives (Years) |  | 2023 |  | 2022 |
| Land |  |  | $ | 112 |  |  | $ | 126 |  |
| Buildings and improvements | 20 to 40 |  | 1,122 |  |  | 1,251 |  |
| Machinery, tools and equipment | 3 to 25 |  | 2,515 |  |  | 2,409 |  |
| Rental assets | 3 to 12 |  | 346 |  |  | 390 |  |
| Other, including assets under construction |  |  | 442 |  |  | 347 |  |
| Fixed assets, gross |  |  | 4,537 |  |  | 4,523 |  |
| Accumulated depreciation |  |  | (2,244) |  |  | (2,282) |  |
| Fixed assets, net |  |  | $ | 2,293 |  |  | $ | 2,241 |  |

[0001783180-24-000009:notes:53]
Depreciation expense was $300 million, $256 million and $238 million for the years ended December 31, 2023, 2022 and 2021, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-24-000009:notes:54]
GOODWILL AND INTANGIBLE ASSETS 
The Company records goodwill as the excess of the purchase price over the fair value of the net assets acquired in a business combination. Goodwill is tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicates that the fair value of the reporting unit may be less than its carrying value.

[0001783180-24-000009:notes:55]
The changes in the carrying amount of goodwill were as follows:

[0001783180-24-000009:notes:56]
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Total |
| Balance at December 31, 2021 | $ | 5,658 |  |  | $ | 1,228 |  |  | $ | 2,463 |  |  | $ | 9,349 |  |
| Goodwill resulting from business combinations (1) | 904 |  |  | — |  |  | 1 |  |  | 905 |  |
| Foreign currency translation | (170) |  |  | (31) |  |  | (76) |  |  | (277) |  |
| Balance at December 31, 2022 | $ | 6,392 |  |  | $ | 1,197 |  |  | $ | 2,388 |  |  | $ | 9,977 |  |
| Goodwill resulting from business combinations | 1 |  |  | (4) |  |  | — |  |  | (3) |  |
| Reclassified to held for sale (2) | — |  |  | (72) |  |  | (1,937) |  |  | (2,009) |  |
| Foreign currency translation | 14 |  |  | 3 |  |  | 7 |  |  | 24 |  |
| Balance as of December 31, 2023 | $ | 6,407 |  |  | $ | 1,124 |  |  | $ | 458 |  |  | $ | 7,989 |  |

[0001783180-24-000009:notes:57]
(1) See Note 19 - Acquisitions for additional information.

[0001783180-24-000009:notes:58]
(2) See Note 20 - Divestitures for additional information.

[0001783180-24-000009:notes:59]
Indefinite-lived intangible assets are tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicates that the fair value of the asset may be less than the carrying amount of the asset. All other intangible assets with finite useful lives are amortized over their estimated useful lives.

[0001783180-24-000009:notes:60]
Amortization of intangible assets was $242 million, $124 million and $98 million for the years ended December 31, 2023, 2022 and 2021, respectively.

[0001783180-24-000009:notes:61]
The estimated future amortization of intangible assets is as follows:

[0001783180-24-000009:notes:62]
| (In millions) | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | Thereafter |
| Future amortization | $ | 175 |  |  | $ | 155 |  |  | $ | 122 |  |  | $ | 95 |  |  | $ | 75 |  |  | $ | 342 |  |

[0001783180-24-000009:notes:63]
Annual Impairment Assessment

[0001783180-24-000009:notes:64]
The Company tested its goodwill and indefinite-lived intangible assets for impairment on July 1 as part of its annual assessment. For each test, the Company qualitatively assessed all relevant events or circumstances that could impact the estimate of fair value and determined it was more likely than not that the fair value of each reporting unit and indefinite-lived intangible asset exceeded their carrying amount.

[0001783180-24-000009:notes:65]
In connection with the presentation of CCR, Access Solutions and Industrial Fire as held for sale at December 31, 2023, the Company reassigned goodwill between each of the remaining reporting units within its Fire & Security segment using a relative fair value approach. As a result, the Company performed a quantitative goodwill impairment test to determine if any impairment existed. The test did not indicate any goodwill impairment.


## us-gaap:DebtDisclosureTextBlock

[0001783180-24-000009:notes:66]
BORROWINGS AND LINES OF CREDIT 
Long-term debt consisted of the following:

[0001783180-24-000009:notes:67]
| (In millions) |  | 2023 |  | 2022 |
| 2.242% Notes due 2025 |  | 1,200 |  |  | 1,200 |  |
| 4.375% Notes due 2025 |  | 830 |  |  | — |  |
| 5.800% Notes due 2025 |  | 1,000 |  |  | — |  |
| 2.493% Notes due 2027 |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  | 830 |  |  | — |  |
| 2.722% Notes due 2030 |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  | 941 |  |  | — |  |
| 5.900% Notes due 2034 |  | 1,000 |  |  | — |  |
| 3.377% Notes due 2040 |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  | 2,000 |  |  | 2,000 |  |
| 6.200% Notes due 2054 |  | 1,000 |  |  | — |  |
| Total long-term notes |  | 13,951 |  |  | 8,350 |  |
| Japanese Term Loan Facility |  | 379 |  |  | 404 |  |
| Other debt (including project financing obligations and finance leases) |  | 74 |  |  | 149 |  |
| Discounts and debt issuance costs |  | (111) |  |  | (61) |  |
| Total debt |  | 14,293 |  |  | 8,842 |  |
| Less: current portion of long-term debt |  | 51 |  |  | 140 |  |
| Long-term debt, net of current portion |  | $ | 14,242 |  |  | $ | 8,702 |  |

[0001783180-24-000009:notes:68]
Debt Issuance

[0001783180-24-000009:notes:69]
In November 2023, the Company issued $3.0 billion principal amount of USD-denominated notes in three tranches. The tranches consist of $1.0 billion aggregate principal amount of 5.800% notes due 2025, $1.0 billion aggregate principal amount of 5.900% notes due 2034 and $1.0 billion aggregate principal amount of 6.200% notes due 2054 (collectively, the “USD Notes”). In addition, the Company issued €2.35 billion principal amount of Euro-denominated notes in three tranches. The tranches consist of €750 million aggregate principal amount of 4.375% notes due 2025, €750 million aggregate principal amount of 4.125% notes due 2028 and €850 million aggregate principal amount of 4.500% notes due 2032 (collectively, the “Euro Notes”). The Company capitalized $51 million of deferred financing costs which are being amortized over the term of their related notes.

[0001783180-24-000009:notes:70]
The Company used the USD Notes and the Euro Notes to fund a portion of the Euro-denominated purchase price of the VCS Business. The Company has the option to redeem the notes in whole or in part at any time, prior to their stated maturity date at redemption prices set forth in the indenture agreements. The notes are subject to certain customary covenants.

[0001783180-24-000009:notes:71]
Japanese Term Loan Facility

[0001783180-24-000009:notes:72]
On July 15, 2022, the Company entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings under the Japanese Term Loan Facility bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. In addition, the Japanese Term Loan Facility is subject to customary covenants including a covenant to maintain a maximum consolidated leverage ratio. The Company capitalized $2 million of deferred financing costs which are being amortized over the term of the facility. On July 25, 2022, the Company borrowed JPY 54 billion under the Japanese Term Loan Facility and used the proceeds to fund a portion of the TCC acquisition and to pay related fees and expenses.

[0001783180-24-000009:notes:73]
Revolving Credit Facility

[0001783180-24-000009:notes:74]
On May 19, 2023, the Company entered into a revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in May 2028 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings can bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. Upon entering into the agreement, the Company terminated its existing revolving credit facility that was set to mature in April 2025. In addition, the Company capitalized $2 million of deferred financing costs which are being amortized over the term of the facility. As of December 31, 2023, there were no borrowings outstanding under the Revolving Credit Facility.

[0001783180-24-000009:notes:75]
Commercial Paper Program

[0001783180-24-000009:notes:76]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of December 31, 2023, there were no borrowings outstanding under the commercial paper program.

[0001783180-24-000009:notes:77]
Project Financing Arrangements

[0001783180-24-000009:notes:78]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $39 million and $38 million of debt during the year ended December 31, 2023 and 2022, respectively. Long-term debt repayments associated with these financing arrangements for the years ended December 31, 2023 and 2022 were $111 million and $160 million, respectively.

[0001783180-24-000009:notes:79]
Debt Covenants

[0001783180-24-000009:notes:80]
The Revolving Credit Facility, the indenture for the long-term notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of December 31, 2023, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

[0001783180-24-000009:notes:81]
Tender Offers

[0001783180-24-000009:notes:82]
On March 15, 2022, the Company commenced tender offers to purchase up to $1.15 billion ("Aggregate Tender Cap") aggregate principal of the Company's 2.242% Notes due 2025 and 2.493% Notes due 2027 (together, the "Senior Notes"). The tender offers included payment of applicable accrued and unpaid interest up to the settlement date, along with a fixed spread for early repayment. Based on participation, the Company elected to settle the tender offers on March 30, 2022. The aggregate principal amount of Senior Notes validly tendered and accepted was approximately $1.15 billion, which included $800 million of Notes due 2025 and $350 million of Notes due 2027. As a result, the Company recognized a net gain of $33 million and wrote off $5 million of unamortized deferred financing costs within Interest (expense) income, net on the accompanying Consolidated Statement of Operations during the year ended December 31, 2022.

[0001783180-24-000009:notes:83]
Schedule of Long-term Debt Maturities

[0001783180-24-000009:notes:84]
Scheduled maturities of long-term debt, excluding amortization of discount, are as follows:

[0001783180-24-000009:notes:85]
| (In millions) |  |  |
| 2024 |  | $ | 51 |  |
| 2025 |  | $ | 3,053 |  |
| 2026 |  | $ | 4 |  |
| 2027 |  | $ | 1,245 |  |
| 2028 |  | $ | 832 |  |
| Thereafter |  | $ | 9,191 |  |

[0001783180-24-000009:notes:86]
As of December 31, 2023, the average maturity of the Company's long-term notes is approximately 11 years and the weighted-average interest rate on its total borrowings is approximately 3.8%. Interest expense associated with long-term debt for the years ended December 31, 2023, 2022 and 2021 was $362 million, $302 million and $319 million, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-24-000009:notes:87]
FAIR VALUE MEASUREMENTS
ASC 820, Fair Value Measurement ("ASC 820"), defines fair value as the price that would be received if an asset is sold or the price paid to transfer a liability in an orderly transaction between market participants at the measurement date. ASC 820 also establishes a three-level fair value hierarchy that prioritizes information used in developing assumptions when pricing an asset or liability as follows:

[0001783180-24-000009:notes:88]
•Level 1: Observable inputs such as quoted prices in active markets;

[0001783180-24-000009:notes:89]
•Level 2: Inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and

[0001783180-24-000009:notes:90]
•Level 3: Unobservable inputs where there is little or no market data, which requires the reporting entity to develop its own assumptions.

[0001783180-24-000009:notes:91]
ASC 820 requires the use of observable market data, when available, in making fair value measurements. When inputs used to measure fair value fall within different levels of the hierarchy, the level within which the fair value measurement is categorized is based on the lowest level input that is significant to the fair value measurement.

[0001783180-24-000009:notes:92]
In the normal course of business, the Company is exposed to certain risks arising from business operations and economic factors, including foreign currency and commodity price risk. These exposures are managed through operational strategies and the use of undesignated hedging contracts. The Company's derivative assets and liabilities are measured at fair value on a recurring basis using internal models based on observable market inputs, such as forward, interest, contract and discount rates with changes in fair value reported in Other income (expense), net in the accompanying Consolidated Statement of Operations.

[0001783180-24-000009:notes:93]
In connection with the TCC acquisition, the Company funded a portion of the Yen-denominated purchase price with cash on hand by entering into cross currency swaps with various financial institutions. The cross currency swaps are measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates as well as credit default swap spreads. The Company designated the cross currency swaps as a partial hedge of its investment in certain subsidiaries whose functional currency is the Japanese Yen in order to manage foreign currency translation risk. As a result, changes in the fair value of the swaps are recorded in Equity in the accompanying Consolidated Balance Sheet.

[0001783180-24-000009:notes:94]
The remaining portion of the Yen-denominated purchase price was funded by the Japanese Term Loan Facility. The carrying value of the facility is translated on a recurring basis using the exchange rate at the end of the applicable period and approximates its fair value. The Company designated the Japanese Term Loan Facility as a partial hedge of its investment in certain subsidiaries whose functional currency is the Japanese Yen in order to manage foreign currency translation risk. As a result, changes in the carrying value of the Japanese Term Loan Facility associated with foreign exchange rate movements are recorded in Equity in the Consolidated Balance Sheet.

[0001783180-24-000009:notes:95]
In connection with the acquisition of the VCS Business, the Company entered into window forward contracts with Bank of America N.A. and JPMorgan Chase Bank N.A. to mitigate the foreign currency risk of the expected cash outflows associated with the Euro-denominated purchase price. The instruments have an aggregate notional amount of €7 billion and are measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates with changes in fair value reported in Other income (expense), net in the accompanying Consolidated Statement of Operations. During the year ended December 31, 2023, the Company recognized a $96 million loss on the mark-to-market valuation of its window forward contracts. The Company settled the window forward contracts on January 2, 2024 upon the acquisition of the VCS Business.

[0001783180-24-000009:notes:96]
During 2023, the Company entered into several interest rate swap contracts to mitigate interest rate exposure on the forecasted issuance of long-term debt. The contracts had an aggregate notional amount of $1.525 billion and were designated as cash flow hedges with changes in fair value reported in Equity in the accompanying Consolidated Balance Sheet. Fair value was measured on a recurring basis using observable market inputs, such as forward, discount and interest rates. In November 2023, the contracts were settled upon the issuance of the underlying debt. As a result, the Company deferred a net unrecognized gain of $58 million in Equity which will be subsequently recognized in Interest expense over the term of the related notes which range from 2034 to 2044. The amount expected to be amortized over the next twelve months is a net gain of $3 million.

[0001783180-24-000009:notes:97]
The following tables provide the valuation hierarchy classification of assets and liabilities that are recorded at fair value and

[0001783180-24-000009:notes:98]
measured on a recurring basis in the accompanying Consolidated Balance Sheet:

[0001783180-24-000009:notes:99]
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| December 31, 2023 |  |  |  |  |  |  |  |  |
| Fair value measurement: |  |  |  |  |  |  |  |  |
| Derivative assets (1)(3) |  | $ | 32 |  |  | $ | — |  |  | $ | 32 |  |  | $ | — |  |
| Derivative liabilities (2)(3) |  | $ | (126) |  |  | $ | — |  |  | $ | (126) |  |  | $ | — |  |
| December 31, 2022 |  |  |  |  |  |  |  |  |
| Fair value measurement: |  |  |  |  |  |  |  |  |
| Derivative assets (1) (3) |  | $ | 28 |  |  | $ | — |  |  | $ | 28 |  |  | $ | — |  |
| Derivative liabilities (2)(3) |  | $ | (48) |  |  | $ | — |  |  | $ | (48) |  |  | $ | — |  |

[0001783180-24-000009:notes:100]
(1) Included in Other assets, current and Other assets on the accompanying Consolidated Balance Sheet.

[0001783180-24-000009:notes:101]
(2) Included in Accrued liabilities and Other long-tern liabilities on the accompanying Consolidated Balance Sheet.

[0001783180-24-000009:notes:102]
(3) Includes cross currency swaps, window forward contracts and interest rate swap contracts.

[0001783180-24-000009:notes:103]
The following table provides the carrying amounts and fair values of the Company's long-term notes that are not recorded at fair value in the accompanying Consolidated Balance Sheet:

[0001783180-24-000009:notes:104]
|  |  | 2023 |  | 2022 |
| (In millions) |  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |
| Total long-term notes (1) |  | $ | 13,951 |  |  | $ | 13,194 |  |  | $ | 8,350 |  |  | $ | 6,832 |  |

[0001783180-24-000009:notes:105]
(1) Excludes debt discount and issuance costs.

[0001783180-24-000009:notes:106]
The fair value of the Company's long-term debt is measured based on observable market inputs which are considered Level 1 within the fair value hierarchy. The carrying value of cash and cash equivalents, accounts receivable, accounts payable and short-term borrowings approximate fair value due to the short-term nature of these accounts and would be classified as Level 1 in the fair value hierarchy. The Company's financing leases and project financing obligations, included in Long-term debt and Current portion of long-term debt on the accompanying Consolidated Balance Sheet, approximate fair value and are classified as Level 3 in the fair value hierarchy.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001783180-24-000009:notes:107]
LEASES 
The Company enters into operating and finance leases for the use of real estate space, vehicles, information technology equipment and certain other equipment. At contract inception, the Company determines a lease exists if the arrangement conveys the right to control an identified asset for a period of time in exchange for consideration. Control is considered to exist when the lessee has the right to obtain substantially all of the economic benefits from the use of an identified asset as well as the right to direct the use of that asset. If a contract is considered to be a lease, the Company recognizes a lease liability based on the present value of the future lease payments with an offsetting entry to recognize a right-of-use asset.

[0001783180-24-000009:notes:108]
Operating lease right-of-use assets and liabilities are reflected on the Consolidated Balance Sheet as follows:

[0001783180-24-000009:notes:109]
| (In millions) |  | 2023 |  | 2022 |
| Operating lease right-of-use assets |  | $ | 491 |  |  | $ | 642 |  |
| Accrued liabilities |  | $ | (108) |  |  | $ | (132) |  |
| Operating lease liabilities |  | (391) |  |  | (529) |  |
| Total operating lease liabilities |  | $ | (499) |  |  | $ | (661) |  |
| Weighted-Average Remaining Lease Term (in years) |  | 7.0 |  | 7.7 |
| Weighted-Average Discount Rate |  | 3.9 | % |  | 3.4 | % |

[0001783180-24-000009:notes:110]
Where applicable, the Company accounts for each separate lease component of a contract and its associated non-lease component as a single lease component.

[0001783180-24-000009:notes:111]
Supplemental cash flow and lease expense information related to operating leases were as follows:

[0001783180-24-000009:notes:112]
| (In millions) |  | 2023 |  | 2022 |  | 2021 |
| Operating cash flows for measurement of operating lease liabilities |  | $ | 166 |  |  | $ | 145 |  |  | $ | 197 |  |
| Operating lease ROU assets obtained in exchange for operating lease obligations |  | $ | 63 |  |  | $ | 109 |  |  | $ | 180 |  |
| Operating lease expense |  | $ | 158 |  |  | $ | 148 |  |  | $ | 200 |  |

[0001783180-24-000009:notes:113]
Operating lease expense is recognized on a straight-line basis over the lease term. In addition, the Company has certain leases that contain variable lease payments which are based on an index, a rate referenced in the lease or on the actual usage of the leased asset. These payments are not included in the right-of-use asset or lease liability and are expensed as incurred as variable lease expense.

[0001783180-24-000009:notes:114]
Undiscounted maturities of operating lease liabilities as of December 31, 2023 are as follows:

[0001783180-24-000009:notes:115]
| (In millions) |  |  |
| 2024 |  | $ | 126 |  |
| 2025 |  | 107 |  |
| 2026 |  | 87 |  |
| 2027 |  | 62 |  |
| 2028 |  | 45 |  |
| Thereafter |  | 149 |  |
| Total undiscounted lease payments |  | 576 |  |
| Less: imputed interest |  | (77) |  |
| Total discounted lease payments |  | $ | 499 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-24-000009:notes:116]
EMPLOYEE BENEFIT PLANS 
The Company sponsors U.S. and international defined benefit pension and defined contribution plans. In addition, the Company contributes to various U.S. and international multi-employer defined benefit pension plans.

[0001783180-24-000009:notes:117]
Pension Plans

[0001783180-24-000009:notes:118]
Qualified U.S. pension plan benefits covering collectively bargained employees comprise approximately 42% of the projected benefit obligation. This noncontributory defined benefit plan provides benefits on a flat dollar formula based on an employee's location and is closed to new entrants. The non-U.S. plans comprise approximately 58% of the projected benefit obligation;

[0001783180-24-000009:notes:119]
certain of these plans provide participants with one-time payments upon separation of employment rather than a retirement annuity. The plans' benefits provided are based on plan specific parameters. Non-qualified U.S. pension plans provide supplementary retirement benefits to certain employees and are not a material component of the projected benefit obligation.

[0001783180-24-000009:notes:120]
The following table details information regarding the Company's pension plans:

[0001783180-24-000009:notes:121]
| (In millions) | 2023 |  | 2022 |
| Change in Benefit Obligation |  |  |  |
| Benefit obligation at beginning of year | $ | 760 |  |  | $ | 906 |  |
| Service cost | 15 |  |  | 20 |  |
| Interest cost | 31 |  |  | 18 |  |
| Actuarial (gain) loss | 27 |  |  | (271) |  |
| Benefits paid | (25) |  |  | (21) |  |
| Curtailment, settlements and special termination benefits | (24) |  |  | (7) |  |
| Other, including expenses paid | 3 |  |  | (38) |  |
| Reclassified to held for sale (1) | (212) |  |  | — |  |
| Acquisitions (2) | — |  |  | 153 |  |
| Benefit obligation at end of year | $ | 575 |  |  | $ | 760 |  |
| Change in Plan Assets |  |  |  |
| Fair value at beginning of year | $ | 451 |  |  | $ | 591 |  |
| Actual return on plan assets | 39 |  |  | (170) |  |
| Company contributions | 33 |  |  | 16 |  |
| Benefits paid | (25) |  |  | (21) |  |
| Settlements | (24) |  |  | (7) |  |
| Other, including expenses paid | 2 |  |  | (18) |  |
| Reclassified to held for sale (1) | (8) |  |  | — |  |
| Acquisitions (2) | — |  |  | 60 |  |
| Fair value of assets end of year | $ | 468 |  |  | $ | 451 |  |
| Funded status of plans | $ | (107) |  |  | $ | (309) |  |
| Amounts included in the balance sheet: |  |  |  |
| Other non-current assets | $ | 32 |  |  | $ | 25 |  |
| Accrued compensation and benefits | (12) |  |  | (18) |  |
| Post-employment and other benefit liabilities | (127) |  |  | (316) |  |
| Net amount recognized | $ | (107) |  |  | $ | (309) |  |

[0001783180-24-000009:notes:122]
(1) See Note 20 - Divestitures for additional information.

[0001783180-24-000009:notes:123]
(2) See Note 19 - Acquisitions for additional information.

[0001783180-24-000009:notes:124]
The change in funded status was primarily driven by the presentation of the Company's CCR business as held for sale. In addition, the discount rates for our significant pension plans in Germany and the U.S. decreased over the measurement period, resulting in higher benefit obligations.

[0001783180-24-000009:notes:125]
The pretax amounts recognized in Accumulated other comprehensive (income) loss are:

[0001783180-24-000009:notes:126]
| (In millions) |  | Prior Service Cost (Benefit) |  | Net Actuarial (Gain) Loss |  | Total |
| As of December 31, 2022 |  | $ | 11 |  |  | $ | 93 |  |  | $ | 104 |  |
| Current year changes recorded in AOCI |  | — |  |  | 20 |  |  | 20 |  |
| Amortization reclassified to earnings |  | (2) |  |  | 1 |  |  | (1) |  |
| Settlement/curtailment reclassified to earnings |  | (3) |  |  | 1 |  |  | (2) |  |
| Currency translation and other |  | — |  |  | 5 |  |  | 5 |  |
| As of December 31, 2023 |  | $ | 6 |  |  | $ | 120 |  |  | $ | 126 |  |

[0001783180-24-000009:notes:127]
Information for pension plans with accumulated benefit obligations in excess of plan assets:

[0001783180-24-000009:notes:128]
| (In millions) | 2023 |  | 2022 |
| Projected benefit obligation | $ | 378 |  |  | $ | 564 |  |
| Accumulated benefit obligation | $ | 362 |  |  | $ | 538 |  |
| Fair value of plan assets | $ | 239 |  |  | $ | 230 |  |

[0001783180-24-000009:notes:129]
Information for pension plans with projected benefit obligations in excess of plan assets:

[0001783180-24-000009:notes:130]
The accumulated benefit obligation for all defined benefit plans was $0.6 billion and $0.7 billion as of December 31, 2023 and 2022, respectively.

[0001783180-24-000009:notes:131]
Pension benefit payments, including amounts to be paid from corporate assets, and reflecting expected future service, as appropriate, are expected to be paid as follows:

[0001783180-24-000009:notes:132]
| (In millions) |  |
| 2024 | $ | 31 |  |
| 2025 | $ | 33 |  |
| 2026 | $ | 37 |  |
| 2027 | $ | 42 |  |
| 2028 | $ | 38 |  |
| 2029 through 2033 | $ | 201 |  |

[0001783180-24-000009:notes:133]
For the years ended December 31, 2023, 2022 and 2021, the Company made $33 million, $16 million and $47 million, respectively, of cash contributions to its defined benefit pension plans. The Company expects to make total contributions of approximately $5 million to its defined benefit pension plans in 2024.

[0001783180-24-000009:notes:134]
The components of net periodic pension expense (benefit) for the defined benefit pension plans are as follows:

[0001783180-24-000009:notes:135]
| (In millions) | 2023 |  | 2022 |  | 2021 |  |  |  |  |
| Service cost | $ | 15 |  |  | $ | 20 |  |  | $ | 27 |  |  |  |  |  |
| Interest cost | 31 |  |  | 18 |  |  | 37 |  |  |  |  |  |
| Expected return on plan assets | (32) |  |  | (27) |  |  | (145) |  |  |  |  |  |
| Amortization of prior service cost | 3 |  |  | 2 |  |  | 2 |  |  |  |  |  |
| Recognized actuarial net loss | (2) |  |  | 9 |  |  | 32 |  |  |  |  |  |
| Net settlement, curtailment and special termination benefit loss | 1 |  |  | 2 |  |  | 13 |  |  |  |  |  |
| Net periodic pension expense (benefit) | $ | 16 |  |  | $ | 24 |  |  | $ | (34) |  |  |  |  |  |

[0001783180-24-000009:notes:136]
Major assumptions used in determining the benefit obligation and net cost for pension plans are presented in the following table as weighted-averages:

[0001783180-24-000009:notes:137]
|  |  | Benefit Obligation |  | Net Costs |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2021 |  |
| Discount rate |  |  |  |  |  |  |  |  |  |  |  |
| Projected benefit obligation | 4.3% |  | 4.2 | % |  | 4.2% |  | 2.1 | % |  | 1.4 | % |  |
| Interest cost (1) |  | —% |  | — | % |  | 4.1% |  | 1.9 | % |  | 1.2 | % |  |
| Service cost (1) |  | —% |  | — | % |  | 4.5% |  | 2.8 | % |  | 2.1 | % |  |
| Salary scale |  | 2.2% |  | 2.4 | % |  | 2.4% |  | 3.1 | % |  | 2.8 | % |  |
| Expected return on plan assets | —% |  | — | % |  | 5.7% |  | 5.0 | % |  | 4.6 | % |  |

[0001783180-24-000009:notes:138]
(1) The 2023 and 2022 discount rates used to measure the service cost and interest cost applies to the significant plans of the Company. The projected benefit obligation discount rate is used for the service cost and interest cost measurements for non-significant plans.

[0001783180-24-000009:notes:139]
The expected long-term rate of return on plan assets is determined by considering the relative weighting of plan assets, the historical performance of total plan assets, individual asset classes, economic and other indicators of future performance. Return projections are assessed for reasonableness using a simulation model that incorporates yield curves, credit spreads and risk premiums to project long-term prospective returns.

[0001783180-24-000009:notes:140]
The Company's investment objective is to provide liquidity and asset levels needed to meet current and future benefit payments, while maintaining a prudent degree of portfolio diversification considering interest rate risk and market volatility. Globally, investment strategies target a mix of approximately 30% of growth seeking assets and 70% of income generating and hedging assets using a wide diversification of asset types, fund strategies and investment managers.

[0001783180-24-000009:notes:141]
The growth seeking allocation consists of global public equities in developed and emerging countries and alternative asset class strategies. The income generating assets primarily consist of government and broadly diversified high quality corporate bonds. In addition, the Company's investment strategies seek to reduce interest rate risk and have incorporated liability hedging programs as part of the long-term investment strategy. Under this objective, the income generating and hedging assets typically increase as the plans' funded status improves. The Company monitors plan funded status and asset allocation regularly in addition to investment manager performance.

[0001783180-24-000009:notes:142]
The fair values of pension plan assets by asset category are as follows:

[0001783180-24-000009:notes:143]
| (In millions) |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Observable Inputs |  | Significant Unobservable Inputs |  | Not Subjectto Leveling |  | Total |
| Asset Category |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  |  |
| Public Equities: |  |  |  |  |  |  |  |  |  |  |
| Global Equities |  | $ | — |  |  | $ | 26 |  |  | $ | — |  |  | $ | — |  |  | $ | 26 |  |
| Global Equity Funds at net asset value (1) (2) |  | — |  |  | — |  |  | — |  |  | 125 |  |  | 125 |  |
| Fixed Income Securities: |  |  |  |  |  |  |  |  |  |  |
| Governments |  | — |  |  | 40 |  |  | — |  |  | 23 |  |  | 63 |  |
| Corporate Bonds |  | — |  |  | 44 |  |  | — |  |  | — |  |  | 44 |  |
| Fixed Income Securities (2) |  | — |  |  | 9 |  |  | — |  |  | 172 |  |  | 181 |  |
| Real Estate (3) |  | — |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Other (4) (5) |  | — |  |  | 10 |  |  | — |  |  | — |  |  | 10 |  |
| Cash & Cash Equivalents (2)(6) |  | — |  |  | 13 |  |  | — |  |  | 3 |  |  | 16 |  |
| Subtotal |  | $ | — |  |  | $ | 143 |  |  | $ | — |  |  | $ | 323 |  |  | $ | 466 |  |
| Other assets and liabilities (7) |  |  |  |  |  |  |  |  |  | 2 |  |
| Total as of December 31, 2023 |  |  |  |  |  |  |  |  |  | $ | 468 |  |
| (In millions) |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Observable Inputs |  | Significant Unobservable Inputs |  | Not Subjectto Leveling |  | Total |
| Asset Category |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  |  |
| Public Equities: |  |  |  |  |  |  |  |  |  |  |
| Global Equities |  | $ | — |  |  | $ | 27 |  |  | $ | — |  |  | $ | — |  |  | $ | 27 |  |
| Global Equity Funds at net asset value (1) (2) |  | — |  |  | — |  |  | — |  |  | 119 |  |  | 119 |  |
| Fixed Income Securities: |  |  |  |  |  |  |  |  |  |  |
| Governments |  | — |  |  | 35 |  |  | — |  |  | 24 |  |  | 59 |  |
| Corporate Bonds |  | — |  |  | 45 |  |  | — |  |  | — |  |  | 45 |  |
| Fixed Income Securities (2) |  | — |  |  | 11 |  |  | — |  |  | 156 |  |  | 167 |  |
| Real Estate (3) |  | — |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Other (4)(5) |  | — |  |  | 8 |  |  | — |  |  | — |  |  | 8 |  |
| Cash & Cash Equivalents (2)(6) |  | — |  |  | 25 |  |  | — |  |  | 1 |  |  | 26 |  |
| Subtotal |  | $ | — |  |  | $ | 152 |  |  | $ | — |  |  | $ | 300 |  |  | $ | 452 |  |
| Other assets and liabilities (7) |  |  |  |  |  |  |  |  |  | (1) |  |
| Total as of December 31, 2022 |  |  |  |  |  |  |  |  |  | $ | 451 |  |

[0001783180-24-000009:notes:144]
(1) Represents commingled funds that invest primarily in common stocks.

[0001783180-24-000009:notes:145]
(2) In accordance with ASU 2015-07, Fair Value Measurement (Topic 820), certain investments that are measured at fair value using the net asset value per share (or its equivalent) practical expedient have not been classified in the fair value hierarchy. The fair value amounts presented in this table are intended to permit reconciliation of the fair value hierarchy to the amounts presented for the total pension plan assets.

[0001783180-24-000009:notes:146]
(3) Represents investments in real estate, including commingled funds and directly held properties.

[0001783180-24-000009:notes:147]
(4) Represents insurance contracts and global balanced risk commingled funds consisting mainly of equity, bonds and some commodities.

[0001783180-24-000009:notes:148]
(5) Includes fixed income repurchase agreements entered into for purposes of pension asset and liability matching.

[0001783180-24-000009:notes:149]
(6) Represents short-term commercial paper, bonds and other cash or cash-like instruments.

[0001783180-24-000009:notes:150]
(7) Represents trust receivables and payables that are not leveled.

[0001783180-24-000009:notes:151]
Derivatives in the plan are primarily used to manage risk and gain asset class exposure while still maintaining liquidity. Derivative instruments mainly consist of fixed income repurchase agreements, interest rate swaps, total return swaps and currency forward contracts.

[0001783180-24-000009:notes:152]
Quoted market prices are used to value investments when available. Investments in securities traded on exchanges, including listed futures and options, are valued at the last reported sale prices on the last business day of the year or, if not available, the last reported bid prices. Fixed income securities are primarily measured using a market approach pricing methodology, whereby observable prices are obtained by market transactions involving identical or comparable securities of issuers with similar credit

[0001783180-24-000009:notes:153]
ratings. Over-the-counter securities and government obligations are valued at the bid prices or the average of the bid and ask prices on the last business day of the year from published sources or, if not available, from other sources considered reliable, including broker quotes. Temporary cash investments are stated at cost, which approximates fair value.

[0001783180-24-000009:notes:154]
Multiemployer Benefit Plans

[0001783180-24-000009:notes:155]
The Company contributes to various domestic and foreign multiemployer defined benefit pension plans. The risks of participating in these multiemployer plans are different from those of single-employer plans in that assets contributed are pooled and may be used to provide benefits to employees of other participating employers. If a participating employer stops contributing to the plan, the unfunded obligations of the plan may be borne by the remaining participating employers. The Company's contributions to these plans for the years ended December 31, 2023 and 2022 was $15 million and $15 million, respectively.

[0001783180-24-000009:notes:156]
Employee Savings Plans

[0001783180-24-000009:notes:157]
The Company sponsors various employee savings plans. Employer contributions are determined based on criteria specific to each plan and were $125 million, $123 million and $115 million for the year ended December 31, 2023, 2022 and 2021, respectively.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-24-000009:notes:158]
PRODUCT WARRANTIES 
In the ordinary course of business, the Company provides standard warranty coverage on its products. Provisions for these amounts are established at the time of sale and estimated primarily based on product warranty terms and historical claims experience. In addition, the Company incurs discretionary costs to service its products in connection with specific product performance issues. Provisions for these amounts are established when they are known and estimable. The Company assesses the adequacy of its initial provisions and will make adjustments as necessary based on known or anticipated claims or as new information becomes available that suggests it is probable that future costs will be different than estimated amounts. Amounts associated with these provisions are classified on the accompanying Consolidated Balance Sheet as Accrued liabilities or Other long-term liabilities based on their anticipated settlement date.

[0001783180-24-000009:notes:159]
The changes in the carrying amount of warranty related provisions are as follows:

[0001783180-24-000009:notes:160]
| (In millions) | 2023 |  | 2022 |
| Balance as of January 1, | $ | 551 |  |  | $ | 524 |  |
| Warranties, performance guarantees issued and changes in estimated liability | 237 |  |  | 184 |  |
| Settlements made | (194) |  |  | (171) |  |
| Other | (13) |  |  | 14 |  |
| Reclassified to held for sale (1) | (13) |  |  | — |  |
| Balance as of December 31, | $ | 568 |  |  | $ | 551 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-24-000009:notes:161]
EQUITY 
The authorized number of shares of common stock of Carrier is 4,000,000,000 shares of $0.01 par value. As of December 31, 2023 and December 31, 2022, 883,068,393 and 876,487,480 shares of common stock were issued, respectively, which includes 43,490,981 and 42,103,995 shares of treasury stock, respectively.

[0001783180-24-000009:notes:162]
Share Repurchase Program

[0001783180-24-000009:notes:163]
The Company may purchase its outstanding common stock from time to time subject to market conditions and at the Company's discretion. Repurchases occur in the open market or through one or more other public or private transactions pursuant to plans complying with Rules 10b5-1 and 10b-18 under the Exchange Act. Shares acquired are recognized at cost and presented separately on the balance sheet as a reduction to Equity. Since the initial authorization in February 2021, the Company's Board of Directors authorized the repurchase of up to $4.1 billion of the Company's outstanding common stock.

[0001783180-24-000009:notes:164]
As of December 31, 2023, the Company repurchased 43.5 million shares of common stock for an aggregate purchase price of $2.0 billion, which includes shares repurchased under an accelerated share repurchase agreement. As a result, the Company has approximately $2.1 billion remaining under the current authorization at December 31, 2023. Upon announcement of the proposed acquisition of the VCS Business, the Company temporarily paused its share repurchase program in order to advance its capital allocation strategy. As a result, there is no share repurchase activity to report for the fourth quarter of 2023.

[0001783180-24-000009:notes:165]
Accumulated Other Comprehensive Income (Loss)

[0001783180-24-000009:notes:166]
A summary of changes in the components of Accumulated other comprehensive income (loss) is as follows:

[0001783180-24-000009:notes:167]
| (In millions) | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Unrealized Hedging Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of January 1, 2021 | $ | (191) |  |  | $ | (554) |  |  |  |  |  |  | $ | — |  |  | $ | (745) |  |
| Other comprehensive income (loss) before reclassifications, net | (322) |  |  | 53 |  |  |  |  |  |  | — |  |  | (269) |  |
| Amounts reclassified, pre-tax | 8 |  |  | 34 |  |  |  |  |  |  | — |  |  | 42 |  |
| Tax benefit reclassified | — |  |  | (17) |  |  |  |  |  |  | — |  |  | (17) |  |
| Balance as of December 31, 2021 | $ | (505) |  |  | $ | (484) |  |  |  |  |  |  | $ | — |  |  | $ | (989) |  |
| Other comprehensive income (loss) before reclassifications, net | (525) |  |  | 63 |  |  |  |  |  |  | — |  |  | (462) |  |
| Amounts reclassified, pre-tax | — |  |  | 11 |  |  |  |  |  |  | — |  |  | 11 |  |
| Tax benefit reclassified | — |  |  | (3) |  |  |  |  |  |  | — |  |  | (3) |  |
| Chubb divestiture | (574) |  |  | 329 |  |  |  |  |  |  | — |  |  | (245) |  |
| Balance as of December 31, 2022 | $ | (1,604) |  |  | $ | (84) |  |  |  |  |  |  | $ | — |  |  | $ | (1,688) |  |
| Other comprehensive income (loss) before reclassifications, net | 160 |  |  | (17) |  |  |  |  |  |  | 58 |  |  | 201 |  |
| Amounts reclassified, pre-tax | — |  |  | 1 |  |  |  |  |  |  | — |  |  | 1 |  |
| Balance as of December 31, 2023 | $ | (1,444) |  |  | $ | (100) |  |  |  |  |  |  | $ | 58 |  |  | $ | (1,486) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-24-000009:notes:168]
REVENUE RECOGNITION 
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company

[0001783180-24-000009:notes:169]
performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.

[0001783180-24-000009:notes:170]
Performance Obligations

[0001783180-24-000009:notes:171]
A performance obligation is a distinct good, service or a bundle of goods and services promised in a contract. Some of the Company's contracts with customers contain a single performance obligation, while others contain multiple performance obligations most commonly when a contract spans multiple phases of a product life-cycle such as production, installation, maintenance and support. The Company identifies performance obligations at the inception of a contract and allocates the transaction price to each distinct performance obligation. Revenue is recognized when or as the performance obligation is satisfied. When there are multiple performance obligations within a contract, the Company allocates the transaction price to each performance obligation based on its relative stand-alone selling price.

[0001783180-24-000009:notes:172]
The Company primarily generates revenue from the sale of products to customers and recognizes revenue at a point in time when control transfers to the customer. Transfer of control is generally based on the shipping terms of the contract. In addition, the Company recognizes revenue on an over-time basis on installation and service contracts. For over-time performance obligations requiring the installation of equipment, revenue is recognized using costs incurred to date relative to total estimated costs at completion to measure progress. Incurred costs represent work performed, which correspond with and best depict transfer of control to the customer. Contract costs include direct costs such as labor, materials and subcontractors’ costs and where applicable, indirect costs.

[0001783180-24-000009:notes:173]
Segment sales disaggregated by product and service are as follows:

[0001783180-24-000009:notes:174]
| (In millions) |  | 2023 |  | 2022 |  | 2021 |
| Sales Type |  |  |  |  |  |  |
| Product |  | $ | 13,313 |  |  | $ | 11,882 |  |  | $ | 9,985 |  |
| Service |  | 1,826 |  |  | 1,526 |  |  | 1,405 |  |
| HVAC sales |  | 15,139 |  |  | 13,408 |  |  | 11,390 |  |
| Product |  | 3,352 |  |  | 3,432 |  |  | 3,653 |  |
| Service |  | 466 |  |  | 451 |  |  | 474 |  |
| Refrigeration sales |  | 3,818 |  |  | 3,883 |  |  | 4,127 |  |
| Product |  | 3,384 |  |  | 3,372 |  |  | 3,985 |  |
| Service |  | 249 |  |  | 198 |  |  | 1,530 |  |
| Fire & Security sales |  | 3,633 |  |  | 3,570 |  |  | 5,515 |  |
| Total segment sales |  | 22,590 |  |  | 20,861 |  |  | 21,032 |  |
| Eliminations and other |  | (492) |  |  | (440) |  |  | (419) |  |
| Consolidated |  | $ | 22,098 |  |  | $ | 20,421 |  |  | $ | 20,613 |  |

[0001783180-24-000009:notes:175]
The transaction price allocated to performance obligations reflects the Company’s expectations about the consideration it will be entitled to receive from a customer. The Company includes variable consideration in the estimated transaction price when there is a basis to reasonably estimate the amount and when it is probable that a significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. In addition, the Company customarily offers its customers incentives to purchase products to ensure an adequate supply of its products in distribution channels. The principal incentive programs provide reimbursements to distributors for offering promotional pricing for products. The Company accounts for estimated incentive payments as a reduction in sales at the time a sale is recognized.

[0001783180-24-000009:notes:176]
Contract Balances

[0001783180-24-000009:notes:177]
Total contract assets and liabilities consisted of the following:

[0001783180-24-000009:notes:178]
| (In millions) | 2023 |  | 2022 |
| Contract assets, current | $ | 306 |  |  | $ | 537 |  |
| Contract assets, non-current (included within Other assets) | 26 |  |  | 6 |  |
| Total contract assets | 332 |  |  | 543 |  |
| Contract liabilities, current | (425) |  |  | (449) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) | (160) |  |  | (174) |  |
| Total contract liabilities | (585) |  |  | (623) |  |
| Net contract assets (liabilities) | $ | (253) |  |  | $ | (80) |  |

[0001783180-24-000009:notes:179]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to the customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.

[0001783180-24-000009:notes:180]
The Company recognized revenue of $347 million for the year ended December 31, 2023 that was related to contract liabilities as of January 1, 2023. The Company expects a majority of its contract liabilities at the end of the period to be recognized as revenue over the next 12 months. There were no individually significant customers with sales exceeding 10% of total sales for the years ended December 31, 2023, 2022 and 2021.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001783180-24-000009:notes:181]
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company

[0001783180-24-000009:notes:182]
The transaction price allocated to performance obligations reflects the Company’s expectations about the consideration it will be entitled to receive from a customer. The Company includes variable consideration in the estimated transaction price when there is a basis to reasonably estimate the amount and when it is probable that a significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. In addition, the Company customarily offers its customers incentives to purchase products to ensure an adequate supply of its products in distribution channels. The principal incentive programs provide reimbursements to distributors for offering promotional pricing for products. The Company accounts for estimated incentive payments as a reduction in sales at the time a sale is recognized.
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to the customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001783180-24-000009:notes:183]
|  |  | External Sales |  | Long-Lived Assets |  |  |  |
| (In millions) |  | 2023 |  | 2022 |  | 2021 |  | 2023 |  | 2022 |  |  |  |
| United States Operations |  | $ | 12,205 |  |  | $ | 11,797 |  |  | $ | 10,492 |  |  | $ | 857 |  |  | $ | 803 |  |  |  |  |
| International Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Europe |  | 4,729 |  |  | 4,359 |  |  | 5,776 |  |  | 497 |  |  | 453 |  |  |  |  |
| Asia Pacific |  | 4,352 |  |  | 3,489 |  |  | 3,464 |  |  | 543 |  |  | 573 |  |  |  |  |
| Other |  | 812 |  |  | 776 |  |  | 881 |  |  | 396 |  |  | 412 |  |  |  |  |
| Consolidated |  | $ | 22,098 |  |  | $ | 20,421 |  |  | $ | 20,613 |  |  | $ | 2,293 |  |  | $ | 2,241 |  |  |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001783180-24-000009:notes:184]
STOCK-BASED COMPENSATION
The Company accounts for stock-based compensation plans in accordance with ASC 718, Compensation - Stock Compensation, which requires a fair-value based method for measuring the value of stock-based compensation. Fair value is measured at the date of grant and is generally not adjusted for subsequent changes. The Company's stock-based compensation plans include programs for stock appreciation rights, restricted stock and performance share units.

[0001783180-24-000009:notes:185]
Stock Options and Appreciation Rights

[0001783180-24-000009:notes:186]
Eligible participants may receive stock options or stock appreciation rights as part of the Company's long-term incentive program. The fair value of each instrument is determined as of the date of grant using a binomial lattice model and expensed on a straight-line basis over the required service period, which is generally a three-year vesting period. However, in the event of retirement, awards held for at least one year may vest and become exercisable (if applicable), subject to certain terms and conditions.

[0001783180-24-000009:notes:187]
The following table summarizes fair value information for stock options and stock appreciation rights:

[0001783180-24-000009:notes:188]
|  |  | 2023 (1) |  | 2022 (1) |  | 2021 (1) |
| Stock options and stock appreciation rights weighted-average fair value per award |  | $ | 11.64 |  |  | $ | 10.68 |  |  | $ | 10.13 |  |
| Assumptions: |  |  |  |  |  |  |
| Volatility |  | 30.9% |  | 30.8% to 31.3% |  | 31.6% to 34.1% |
| Expected term (in years) |  | 5.8 |  | 6.1 |  | 6.6 |
| Expected dividend yield |  | 1.8% |  | 1.5% |  | 1.5% |
| Range of risk-free rates |  | 3.6% |  | 1.7% to 3.0% |  | 0.7% to 1.4% |

[0001783180-24-000009:notes:189]
(1) Carrier has limited historical trading data and used peer group data to estimate expected volatility for the 2023, 2022 and 2021 awards.

[0001783180-24-000009:notes:190]
The Company used historical employee data, including data prior to the Separation and the Distribution, to estimate expected term. The expected dividend yield is consistent with management's expectations. The risk-free rate is based on the term structure of interest rates at the time the awards were granted.

[0001783180-24-000009:notes:191]
Changes in stock options and stock appreciation rights outstanding were as follows:

[0001783180-24-000009:notes:192]
|  | Shares Subject to Option(in thousands) |  | Weighted-Average Exercise Price |  | Aggregate Intrinsic Value (in millions) |  | Weighted- Average Remaining Life (in years) |
| As of December 31, 2020 | 36,732 |  |  | $ | 19.91 |  |  |  |  |  |
| Granted | 3,194 |  |  | $ | 38.92 |  |  |  |  |  |
| Exercised | (5,934) |  |  | $ | 17.59 |  |  |  |  |  |
| Cancelled | (1,551) |  |  | $ | 23.98 |  |  |  |  |  |
| As of December 31, 2021 | 32,441 |  |  | $ | 22.02 |  |  |  |  |  |
| Granted | 2,715 |  |  | $ | 47.72 |  |  |  |  |  |
| Exercised | (3,495) |  |  | $ | 17.76 |  |  |  |  |  |
| Cancelled | (883) |  |  | $ | 30.33 |  |  |  |  |  |
| As of December 31, 2022 | 30,778 |  |  | $ | 24.53 |  |  |  |  |  |
| Granted | 3,494 |  |  | $ | 46.13 |  |  |  |  |  |
| Exercised | (8,432) |  |  | $ | 20.48 |  |  |  |  |  |
| Cancelled | (769) |  |  | $ | 42.94 |  |  |  |  |  |
| Outstanding as of December 31, 2023 | 25,071 |  |  | $ | 28.34 |  |  | $ | 730 |  |  | 5.8 |
| Exercisable as of December 31, 2023 | 17,662 |  |  | $ | 22.05 |  |  | $ | 625 |  |  | 4.8 |

[0001783180-24-000009:notes:193]
Restricted Stock Units

[0001783180-24-000009:notes:194]
Eligible participants may receive restricted stock units ("RSU") as part of the Company's long-term incentive program. The fair value of restricted stock units are based on the closing market price of the Company's common stock on the date of grant and expensed on a straight-line basis over the required service period (which is generally a three-year vesting period). However, in the event of retirement, awards held for at least one year may vest and become exercisable (if applicable), subject to certain terms and conditions. Dividends accrue during the vesting period and are paid in shares of the Company's common stock.

[0001783180-24-000009:notes:195]
Changes in restricted stock units were as follows:

[0001783180-24-000009:notes:196]
|  | RSUs (in thousands) |  | Weighted-Average Grant Date Fair Value |
| Outstanding and unvested as of December 31, 2020 | 5,574 |  |  | $ | 21.57 |  |
| Granted | 286 |  |  | $ | 46.49 |  |
| Vested | (2,168) |  |  | $ | 21.45 |  |
| Cancelled | (122) |  |  | $ | 25.39 |  |
| Outstanding and unvested as of December 31, 2021 | 3,570 |  |  | $ | 23.33 |  |
| Granted | 555 |  |  | $ | 41.88 |  |
| Vested | (1,915) |  |  | $ | 20.85 |  |
| Cancelled | (143) |  |  | $ | 32.92 |  |
| Outstanding and unvested as of December 31, 2022 | 2,067 |  |  | $ | 29.87 |  |
| Granted | 577 |  |  | $ | 45.71 |  |
| Vested | (1,140) |  |  | $ | 26.09 |  |
| Cancelled | (161) |  |  | $ | 35.09 |  |
| Outstanding and unvested as of December 31, 2023 | 1,343 |  |  | $ | 39.22 |  |

[0001783180-24-000009:notes:197]
Performance Share Units

[0001783180-24-000009:notes:198]
The Company has a performance share program for key employees whereby awards are provided in the form of performance share units ("PSU") based on performance against pre-established objectives. The annual target level is expressed as shares of the Company's common stock based on the fair value of its stock on the date of grant. Awards are earned over a three-year performance period based equally on a performance condition, measured by the compound annual growth rate of the Company's earnings per share and on a market condition, measured by the Company's relative total shareowner return compared to the total shareowner return of a subset of industrial companies in the S&P 500 Index. The fair value of the market condition is estimated using a Monte Carlo simulation approach. The fair value of the PSU awards are expensed over the required service period, which is generally a three-year vesting period. In the event of retirement, performance share units held for at least one year remain eligible to vest based on actual performance relative to pre-established metrics. Dividends do not accrue on the performance share units during the performance period.

[0001783180-24-000009:notes:199]
Changes in PSUs were as follows:

[0001783180-24-000009:notes:200]
|  | PSUs (in thousands) |  | Weighted-Average Grant Date Fair Value |
| Outstanding and unvested as of December 31, 2020 | 772 |  |  | $ | 18.46 |  |
| Granted | 821 |  |  | $ | 41.48 |  |
| Vested | (20) |  |  | $ | 23.72 |  |
| Forfeited | (152) |  |  | $ | 27.28 |  |
| Outstanding and unvested as of December 31, 2021 | 1,421 |  |  | $ | 30.75 |  |
| Granted | 653 |  |  | $ | 46.93 |  |
| Vested | (5) |  |  | $ | 41.81 |  |
| Forfeited | (139) |  |  | $ | 35.45 |  |
| Outstanding and unvested as of December 31, 2022 | 1,930 |  |  | $ | 35.86 |  |
| Granted | 902 |  |  | $ | 47.93 |  |
| Vested | (607) |  |  | $ | 18.23 |  |
| Forfeited | (183) |  |  | $ | 46.52 |  |
| Outstanding and unvested as of December 31, 2023 | 2,042 |  |  | $ | 45.47 |  |

[0001783180-24-000009:notes:201]
Compensation Expense

[0001783180-24-000009:notes:202]
Stock-based compensation expense, net of estimated forfeitures, is included in Cost of products sold, Selling, general and administrative and Research and development, in the accompanying Consolidated Statement of Operations.

[0001783180-24-000009:notes:203]
Stock-based compensation cost by award type are as follows:

[0001783180-24-000009:notes:204]
| (In millions) | 2023 |  | 2022 |  | 2021 |
| Equity compensation costs - equity settled | $ | 81 |  |  | $ | 77 |  |  | $ | 92 |  |
| Equity compensation costs - cash settled (1) | 3 |  |  | (15) |  |  | 19 |  |
| Total stock-based compensation cost | $ | 84 |  |  | $ | 62 |  |  | $ | 111 |  |
| Income tax benefit | $ | 11 |  |  | $ | 9 |  |  | $ | 13 |  |

[0001783180-24-000009:notes:205]
(1) The cash settled awards are classified as liability awards and are measured at fair value at each balance sheet date.

[0001783180-24-000009:notes:206]
As of December 31, 2023 and 2022, there were $76 million and $64 million of unrecognized stock-based compensation costs related to non-vested awards granted under the plan, respectively, which will be recognized ratably over the awards weighted-average remaining vesting period of 2 years.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-24-000009:notes:207]
RESTRUCTURING COSTS 
The Company incurs costs associated with restructuring initiatives intended to improve operating performance, profitability and working capital levels. Actions associated with these initiatives may include improving productivity, workforce reductions and the consolidation of facilities. Due to the size, nature and frequency of these discrete plans, they are fundamentally different from the Company’s ongoing productivity initiatives.

[0001783180-24-000009:notes:208]
The Company recorded net pre-tax restructuring costs for new and ongoing restructuring actions as follows:

[0001783180-24-000009:notes:209]
| (In millions) | 2023 |  | 2022 |  | 2021 |
| HVAC | $ | 44 |  |  | $ | 8 |  |  | $ | 33 |  |
| Refrigeration | 21 |  |  | 10 |  |  | 25 |  |
| Fire & Security | 22 |  |  | 11 |  |  | 26 |  |
| Total Segment | 87 |  |  | 29 |  |  | 84 |  |
| General corporate expenses | 10 |  |  | 2 |  |  | 5 |  |
| Total restructuring costs | $ | 97 |  |  | $ | 31 |  |  | $ | 89 |  |
| Cost of sales | $ | 18 |  |  | $ | 9 |  |  | $ | 28 |  |
| Selling, general and administrative | 79 |  |  | 22 |  |  | 60 |  |
| Other income (expense), net | — |  |  | — |  |  | 1 |  |
| Total restructuring costs | $ | 97 |  |  | $ | 31 |  |  | $ | 89 |  |

[0001783180-24-000009:notes:210]
The following table summarizes changes in the restructuring reserve, included in Accrued liabilities on the accompanying Consolidated Balance Sheet:

[0001783180-24-000009:notes:211]
| (In millions) |  | 2023 |  | 2022 |
| Balance as of January 1, |  | $ | 24 |  |  | $ | 54 |  |
| Net pre-tax restructuring costs |  | 97 |  |  | 31 |  |
| Utilization, foreign exchange and other |  | (58) |  |  | (61) |  |
| Reclassified to held for sale (1) |  | (8) |  |  | — |  |
| Balance as of December 31, |  | $ | 55 |  |  | $ | 24 |  |

[0001783180-24-000009:notes:212]
As of December 31, 2023, the Company had $55 million accrued for costs associated with its announced restructuring initiatives. The balance relates to cost reduction efforts, primarily severance, across each of the Company's segments. In addition, reserves associated with the Company's planned portfolio transformation were established during the year, all of which are expected to be paid within 12 months.


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001783180-24-000009:notes:213]
OTHER INCOME (EXPENSE), NET
Other income (expense), net consisted of the following:

[0001783180-24-000009:notes:214]
| (In millions) | 2023 |  | 2022 |  | 2021 |
| Impairment charge on minority-owned joint venture investments | — |  |  | — |  |  | (2) |  |
| Viessmann-related hedges | (96) |  |  | — |  |  | — |  |
| KFI deconsolidation | (297) |  |  | — |  |  | — |  |
| TCC acquisition-related gain | (8) |  |  | 705 |  |  | — |  |
| Chubb gain | — |  |  | 1,105 |  |  | — |  |
| Other | 17 |  |  | 30 |  |  | 41 |  |
| Other income (expense), net | $ | (384) |  |  | $ | 1,840 |  |  | $ | 39 |  |

[0001783180-24-000009:notes:215]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than the entity's functional currency and hedging-related activities. In connection with the proposed acquisition of the VCS Business, the Company recognized a $96 million loss during the year ended December 31, 2023 on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price. In addition, the Company recognized a loss of $297 million on the deconsolidation of KFI due to its Chapter 11 filing.

[0001783180-24-000009:notes:216]
In connection with the TCC acquisition, the carrying value of the Company's previously held TCC equity investments were recognized at fair value at the date of acquisition. As a result, the Company recognized a $697 million non-cash gain associated with the increase in our ownership interest. In addition, the Company completed the Chubb Sale and recognized a net gain on the sale of $1.1 billion during the twelve months ended December 31, 2022.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-24-000009:notes:217]
INCOME TAXES 
Income Before Income Taxes

[0001783180-24-000009:notes:218]
The sources of Income from operations before income taxes are as follows:

[0001783180-24-000009:notes:219]
| (In millions) | 2023 |  | 2022 |  | 2021 |
| United States | $ | 1,311 |  |  | $ | 1,876 |  |  | $ | 1,528 |  |
| Foreign | 773 |  |  | 2,416 |  |  | 872 |  |
| Total | $ | 2,084 |  |  | $ | 4,292 |  |  | $ | 2,400 |  |

[0001783180-24-000009:notes:220]
Provision for Income Taxes

[0001783180-24-000009:notes:221]
The income tax expense (benefit) consisted of the following components:

[0001783180-24-000009:notes:222]
| (In millions) | 2023 |  | 2022 |  | 2021 |
| Current: |  |  |  |  |  |
| United States: |  |  |  |  |  |
| Federal | $ | 412 |  |  | $ | 453 |  |  | $ | 336 |  |
| State | 124 |  |  | 120 |  |  | 83 |  |
| Foreign | 341 |  |  | 259 |  |  | 354 |  |
|  | 877 |  |  | 832 |  |  | 773 |  |
| Future: |  |  |  |  |  |
| United States: |  |  |  |  |  |
| Federal | (138) |  |  | (23) |  |  | (125) |  |
| State | (33) |  |  | (29) |  |  | (14) |  |
| Foreign | (62) |  |  | (72) |  |  | 65 |  |
|  | (233) |  |  | (124) |  |  | (74) |  |
| Income tax expense | $ | 644 |  |  | $ | 708 |  |  | $ | 699 |  |

[0001783180-24-000009:notes:223]
Reconciliation of Effective Income Tax Rate

[0001783180-24-000009:notes:224]
The differences between the effective income tax rate and the statutory U.S. federal income tax rate are as follows:

[0001783180-24-000009:notes:225]
|  | 2023 |  | 2022 |  | 2021 |
| Statutory U.S. federal income tax rate | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| State income tax | 2.7 |  |  | 1.5 |  |  | 1.9 |  |
| Taxes on international activities | 6.3 |  |  | (1.0) |  |  | 7.2 |  |
| TCC acquisition impact | — |  |  | (4.2) |  |  | — |  |
| Other | 0.9 |  |  | (0.8) |  |  | (1.0) |  |
| Effective income tax rate | 30.9 | % |  | 16.5 | % |  | 29.1 | % |

[0001783180-24-000009:notes:226]
The effective tax rate for the year ended December 31, 2023 was higher than the Company's statutory U.S. federal income tax rate. The increase was primarily driven by a net tax charge of $90 million relating to the re-organization and disentanglement of CCR and certain Fire & Security industrial businesses in advance of the planned divestitures and a deferred tax charge of $65 million related to basis differences in certain companies presented as held-for-sale. In addition, the effective tax rate was impacted by the recognition of a deferred tax liability for withholding tax of $33 million on repatriated foreign earnings, non-deductible divestiture-related costs and a non-deductible loss of $96 million on the mark-to-market valuation of the Company's window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business. The unfavorable impact of the above items is partially offset by a $53 million tax benefit recorded from the announced KFI bankruptcy and deconsolidation and $49 million of foreign tax credits generated and utilized in 2023.

[0001783180-24-000009:notes:227]
The effective tax rate for the year ended December 31, 2022 was lower than the Company's statutory U.S. federal income tax rate. The decrease was driven by a lower effective tax rate on the $705 million non-cash gain resulting from the recognition of the Company's previously held TCC equity investments at fair value upon acquisition of TCC, a lower effective tax rate on the $1.1 billion Chubb gain and $45 million of foreign tax credits generated and utilized in the current year.

[0001783180-24-000009:notes:228]
The effective tax rate for the year ended December 31, 2021 was higher than the Company's statutory U.S. federal income tax rate. The increase was driven by a net tax charge of $157 million primarily relating to the re-organization and disentanglement of certain Chubb subsidiaries executed in advance of the planned divestiture of the Chubb business and a $43 million deferred tax charge associated with a tax rate increase in the United Kingdom enacted on June 10, 2021 with an effective date of April 2023. These amounts were partially offset by the recognition of a favorable tax adjustment of $70 million due to foreign tax credits generated and expected to be utilized in the current year and $21 million resulting from the re-organization of a German subsidiary.

[0001783180-24-000009:notes:229]
Deferred Tax Assets and Liabilities

[0001783180-24-000009:notes:230]
Future income taxes represent the tax effects of transactions, which are reported in different periods for tax and GAAP purposes. These amounts consist of the tax effects of differences between tax and GAAP that are expected to be reversed in the future and tax carryforwards. Future income tax benefits and payables within the same tax paying component of a particular jurisdiction are offset for presentation in the Consolidated Balance Sheet.

[0001783180-24-000009:notes:231]
The tax effects of temporary differences and tax carryforwards which give rise to future income tax benefits and payables as of December 31, 2023 and 2022 are as follows:

[0001783180-24-000009:notes:232]
| (In millions) | 2023 |  | 2022 |
| Future income tax benefits: |  |  |  |
| Insurance and employee benefits | $ | 158 |  |  | $ | 161 |  |
| Other assets basis differences | 420 |  |  | 284 |  |
| Other liabilities basis differences | 547 |  |  | 571 |  |
| Tax loss carryforwards | 185 |  |  | 177 |  |
| Tax credit carryforwards | 1,333 |  |  | 29 |  |
| Valuation allowances | (1,399) |  |  | (100) |  |
| Future income tax benefit | $ | 1,244 |  |  | $ | 1,122 |  |
| Future income tax payables: |  |  |  |
| Goodwill and intangible assets | $ | (412) |  |  | $ | (449) |  |
| Other asset basis differences | (388) |  |  | (395) |  |
| Future income tax payables | $ | (800) |  |  | $ | (844) |  |

[0001783180-24-000009:notes:233]
Valuation allowances have been established primarily for tax credit carryforwards, tax loss carryforwards and certain foreign temporary differences to reduce future income tax benefits to expected realizable amounts. As of December 31, 2023, future income tax benefits and future income tax payables exclude a net liability of $9 million classified as held for sale. See Note 20 - Divestitures for additional information.

[0001783180-24-000009:notes:234]
Changes to valuation allowances consisted of the following:

[0001783180-24-000009:notes:235]
| (In millions) |  |  |
| Balance as of January 1, 2021 |  | $ | 231 |  |
| Additions charged to income tax expense |  | 32 |  |
| Reduction credited to income tax expense |  | (22) |  |
| Other adjustments |  | (41) |  |
| Reclassified to held for sale |  | (110) |  |
| Balance at December 31, 2021 |  | $ | 90 |  |
| Additions charged to income tax expense |  | 18 |  |
| Reduction credited to income tax expense |  | (22) |  |
| Other adjustments |  | 14 |  |
| Balance at December 31, 2022 |  | $ | 100 |  |
| Additions charged to income tax expense |  | 27 |  |
| Reduction credited to income tax expense |  | (22) |  |
| Other adjustments (1) |  | 1,303 |  |
| Reclassified to held for sale |  | (9) |  |
| Balance as of December 31, 2023 |  | $ | 1,399 |  |

[0001783180-24-000009:notes:236]
(1) See discussion below regarding the Swiss tax credit

[0001783180-24-000009:notes:237]
Tax Credit and Loss Carryforwards

[0001783180-24-000009:notes:238]
As of December 31, 2023, tax credit carryforwards and tax loss carryforwards were as follows:

[0001783180-24-000009:notes:239]
| (In millions) | Tax Loss Carryforwards |  | Tax Credit Carryforwards |
| Expiration period: |  |  |  |
| 2024-2028 | $ | 70 |  |  | $ | 28 |  |
| 2029-2033 | 96 |  |  | 1,289 |  |
| 2034-2043 | 96 |  |  | — |  |
| Indefinite | 574 |  |  | 16 |  |
| Total | $ | 836 |  |  | $ | 1,333 |  |

[0001783180-24-000009:notes:240]
The Company assesses the realizability of its deferred tax assets on a quarterly basis through an analysis of potential sources of future taxable income, including prior year taxable income available to absorb a carryback of tax losses, reversals of existing taxable temporary differences, tax planning strategies and forecasts of taxable income. The Company considers all negative and positive evidence, including the weight of the evidence, to determine if valuation allowances against deferred tax assets are required. The Company maintains valuation allowances against certain deferred tax assets.

[0001783180-24-000009:notes:241]
In conjunction with the announced portfolio transformation, the Company is implementing changes to its corporate structure, including intra-entity transfers of certain intellectual property to a subsidiary in Switzerland. During 2024, the Company will begin transferring certain intellectual property from wholly-owned legal entities to the Swiss subsidiary. During the three months ended December 31, 2023, the Company’s Swiss subsidiary was granted a tax credit of approximately $1.3 billion that is immediately available to offset cantonal income tax liability over a ten-year period. As the Company is in the preliminary stages of the reorganization, a full valuation allowance was recorded against this tax credit. As operations in the Swiss subsidiary expand in future years it will be necessary to reassess the estimated realizable tax benefit associated with the tax credit.

[0001783180-24-000009:notes:242]
Unrecognized Tax Benefits

[0001783180-24-000009:notes:243]
As of December 31, 2023, the Company had unrecognized tax benefits of $382 million, all of which, if recognized, would impact its effective tax rate. A reconciliation of the beginning and ending amounts of unrecognized tax benefits and related interest expense is as follows:

[0001783180-24-000009:notes:244]
| (In millions) | 2023 |  | 2022 |  | 2021 |
| Balance at beginning of period | $ | 291 |  |  | $ | 251 |  |  | $ | 162 |  |
| Additions for tax positions related to the current year | 37 |  |  | 34 |  |  | 86 |  |
| Additions for tax positions of prior years (1) | 81 |  |  | 32 |  |  | 24 |  |
| Reductions for tax positions of prior years | — |  |  | (13) |  |  | (1) |  |
| Settlements | (27) |  |  | (13) |  |  | (18) |  |
| Reclassified to held for sale | — |  |  | — |  |  | (2) |  |
| Balance at end of period | $ | 382 |  |  | $ | 291 |  |  | $ | 251 |  |
| Gross interest expense related to unrecognized tax benefits | $ | 18 |  |  | $ | 16 |  |  | $ | 8 |  |
| Total accrued interest balance at end of period | $ | 64 |  |  | $ | 48 |  |  | $ | 35 |  |

[0001783180-24-000009:notes:245]
(1) Includes $73 million during the year ended December 31, 2023 and $14 million during the year ended December 31, 2021 related to acquisitions.

[0001783180-24-000009:notes:246]
The Company conducts business globally and, as a result, the Company and its subsidiaries file income tax returns in the U.S. federal, various state and foreign jurisdictions. In certain jurisdictions, the Company's operations were included in UTC's combined tax returns for the periods through the Separation and the Distribution. The IRS commenced an audit of UTC's tax years 2017 and 2018 in the second quarter of 2020 and this audit is expected to conclude in 2024. However, the Company expects that certain of the IRS proposed adjustments will be disputed at the Appeals Division of the IRS. The U.S. Federal statute of limitations for UTC's tax year 2019 expired during the three months ended December 31, 2023. In the normal course of business, the Company is subject to examination by taxing authorities throughout the world, including the U.S., Australia, Belgium, Canada, China, Czech Republic, France, Germany, Hong Kong, India, Italy, Japan, Mexico, the Netherlands,

[0001783180-24-000009:notes:247]
Singapore, Thailand, and the United Kingdom. The Company is no longer subject to U.S. federal income tax examination for years prior to 2017 and, with few exceptions, is no longer subject to U.S. state and local and foreign income tax examinations for tax years before 2013.

[0001783180-24-000009:notes:248]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. The Company believes that it is reasonably possible that a net decrease in unrecognized tax benefits of $60 million to $80 million may occur within 12 months as a result of additional uncertain tax positions, the revaluation of uncertain tax positions arising from examinations, appeals, court decisions or the closure of tax statutes.

[0001783180-24-000009:notes:249]
In October 2021, the Organization for Economic Co-operation and Development ("OECD")/G20 finalized the significant components of a two-pillar global tax reform plan, which has now been agreed to by the majority of OECD members. Pillar One allows countries to reallocate amongst other taxing jurisdictions a portion of residual profits earned by multinational enterprises ("MNE"), with annual global revenue exceeding €20 billion and a profit margin over 10%. The adoption of Pillar One and its potential effective date remain uncertain. Pillar Two requires MNEs with annual global revenue exceeding €750 million to pay a global minimum tax of 15%. The Company does not currently expect the impact of Pillar Two to be material to its effective tax rate, but the impact may be modified as legislation is adopted.

[0001783180-24-000009:notes:250]
As a result of the Tax Cuts and Jobs Act ("TCJA"), the Company no longer intends to reinvest certain undistributed earnings of its international subsidiaries that have been previously taxed in the U.S. As such, the Company has recorded tax liabilities associated with the future remittance of these earnings. For the remainder of the Company's undistributed international earnings, unless it becomes tax effective to repatriate, the Company intends to continue to permanently reinvest these earnings. As of December 31, 2023, such undistributed earnings were approximately $10 billion, excluding other comprehensive income amounts. It is not practicable to estimate the amount of tax that might be payable on the remaining amounts. In addition, the TCJA subjects the Company to a tax on global intangible low-taxed income ("GILTI"). GILTI is a tax on foreign income in excess of a deemed return on tangible assets of foreign corporations which the Company has elected to account for as a period cost.


## us-gaap:EarningsPerShareTextBlock

[0001783180-24-000009:notes:251]
EARNINGS PER SHARE 
Earnings per share is computed by dividing Net income attributable to common shareowners by the weighted-average number of shares of common stock outstanding during the period (excluding treasury stock). Diluted earnings per share is computed by giving effect to all potentially dilutive stock awards that are outstanding. The computation of diluted earnings per share excludes the effect of the potential exercise of stock-based awards, including stock appreciation rights and stock options, when the effect of the potential exercise would be anti-dilutive.

[0001783180-24-000009:notes:252]
The following table summarizes the weighted-average number of shares of common stock outstanding for basic and diluted earnings per share calculations:

[0001783180-24-000009:notes:253]
| (In millions, except per share amounts) |  | 2023 |  | 2022 |  | 2021 |  |  |
| Net income attributable to common shareowners |  | $ | 1,349 |  |  | $ | 3,534 |  |  | $ | 1,664 |  |  |  |
| Basic weighted-average number of shares outstanding |  | 837.3 |  |  | 843.4 |  |  | 867.7 |  |  |  |
| Stock awards and equity units (share equivalent) |  | 15.7 |  |  | 17.8 |  |  | 22.6 |  |  |  |
| Diluted weighted-average number of shares outstanding |  | 853.0 |  |  | 861.2 |  |  | 890.3 |  |  |  |
| Antidilutive shares excluded from computation of diluted earnings per share |  | 2.0 |  |  | 2.9 |  |  | 0.1 |  |  |  |
| Earnings Per Share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.61 |  |  | $ | 4.19 |  |  | $ | 1.92 |  |  |  |
| Diluted |  | $ | 1.58 |  |  | $ | 4.10 |  |  | $ | 1.87 |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001783180-24-000009:notes:254]
ACQUISITIONS
During the year ended December 31, 2023, the Company acquired consolidated and minority-owned businesses. The aggregate cash paid, net of cash acquired, totaled $84 million. Acquisitions are recorded using the acquisition method of accounting in accordance with ASC 805. As a result, the aggregate purchase price has been allocated to assets acquired and liabilities assumed based on the estimate of fair market value of such assets and liabilities at the date of acquisition. The excess purchase price over the estimated fair value of net assets acquired is recognized as goodwill.

[0001783180-24-000009:notes:255]
Toshiba Carrier Corporation

[0001783180-24-000009:notes:256]
On February 6, 2022, the Company entered into a binding agreement to acquire a majority ownership interest in TCC for $920 million. TCC, a VRF and light commercial HVAC joint venture between Carrier and Toshiba Corporation, designs and manufactures flexible, energy-efficient and high-performance VRF and light commercial HVAC systems as well as commercial products, compressors and heat pumps. The acquisition included all of TCC’s advanced research and development centers and global manufacturing operations, product pipeline and the long-term use of Toshiba’s iconic brand. The acquisition was completed on August 1, 2022 and funded through the Japanese Term Loan Facility and cash on hand. Upon closing, Toshiba Corporation retained a 5% ownership interest in TCC.

[0001783180-24-000009:notes:257]
The allocation of the purchase price is as follows:

[0001783180-24-000009:notes:258]
| (In millions) |  | August 1, 2022 |
| Cash and cash equivalents |  | $ | 462 |  |
| Accounts receivable |  | 428 |  |
| Inventories |  | 373 |  |
| Other assets, current |  | 54 |  |
| Fixed assets |  | 330 |  |
| Intangible assets |  | 965 |  |
| Goodwill |  | 876 |  |
| Other assets |  | 299 |  |
| Accounts payable |  | (412) |  |
| Accrued liabilities |  | (445) |  |
| Contract liabilities, current |  | (21) |  |
| Other long-term liabilities |  | (569) |  |
| Net assets acquired |  | $ | 2,340 |  |
| Less: Fair value of non-controlling interests |  | (22) |  |
| Less: Fair value of previously held TCC equity investments |  | (1,398) |  |
| Total cash consideration |  | $ | 920 |  |

[0001783180-24-000009:notes:259]
The excess purchase price over the estimated fair value of the net assets acquired was recognized as goodwill and totaled $876 million, which is not deductible for tax purposes. Accounts receivable and current liabilities were stated at their historical carrying value, which approximates fair value given the short-term nature of these assets and liabilities. The estimate of fair value for inventory and fixed assets was based on an assessment of the acquired assets' condition as well as an evaluation of the current market value of such assets. The sale agreement included several customary provisions to settle working capital and other transaction-related items as of the date of sale. During 2022, the parties finalized these amounts in accordance with the terms of the sale agreement and the Company paid an additional $41 million to Toshiba Corporation in 2023. In addition, the parties finalized amounts related to pension funding levels during 2023 which resulted in the Company receiving $12 million from Toshiba Corporation.

[0001783180-24-000009:notes:260]
The Company recorded intangible assets based on its estimate of fair value which consisted of the following:

[0001783180-24-000009:notes:261]
| (In millions) | Estimated Useful Life (in years) |  | Intangible Assets Acquired |
| Customer relationships | 23 |  | $ | 497 |  |
| Technology | 7 |  | 220 |  |
| Trademark | 26 |  | 180 |  |
| Backlog | 1 |  | 60 |  |
| Land use rights | 45 |  | 8 |  |
| Total intangible assets acquired |  |  | $ | 965 |  |

[0001783180-24-000009:notes:262]
The valuation of intangible assets was determined using an income approach methodology including the multi-period excess earnings method and the relief from royalty method. Key assumptions used in estimating future cash flows included projected revenue growth rates, EBIT margins, discount rates, customer attrition rates and royalty rates among others. The projected future cash flows are discounted to present value using an appropriate discount rate. The Company finalized the process of allocating the purchase price and valuing the acquired assets and liabilities during the year ended December 31, 2023.

[0001783180-24-000009:notes:263]
The Company previously accounted for its minority ownership in TCC under the equity method of accounting. In connection with the transaction, the carrying value of the Company's previously held TCC equity investments were recognized at fair value at the date of acquisition using an income approach methodology. As a result, the Company recognized a $697 million non-cash gain within Other income (expense), net on the accompanying Consolidated Statement of Operations. In addition, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Consolidated Financial Statements as of the date of acquisition and reported within the Company's HVAC segment. The Company incurred $29 million of acquisition-related costs during 2022 which are included within Selling, general and administrative on the accompanying Consolidated Statement of Operations. The Company has not included pro forma financial information required under ASC 805 as the pro forma impact was not deemed significant.

[0001783180-24-000009:notes:264]
Announced Acquisition

[0001783180-24-000009:notes:265]
On April 25, 2023, the Company announced that it entered into an Agreement to acquire the VCS Business, a privately-held company. The VCS Business develops intelligent, integrated and sustainable technologies, including heat pumps, boilers, photovoltaic systems, home battery storage and digital solutions, primarily for residential customers in Europe. Under the terms of the Agreement, 20% of the purchase price was to be paid in Carrier common stock, issued directly to Viessmann and subject to long-term lock-up provisions and 80% was to be paid in cash, subject to working capital and other adjustments. The acquisition was completed on January 2, 2024. See Note 25 - Subsequent Events for additional information.

[0001783180-24-000009:notes:266]
On April 25, 2023, the Company entered into commitment letters with JPMorgan Chase Bank, N.A., BofA Securities, Inc. and Bank of America, N.A. to provide a €8.2 billion aggregate principal, senior unsecured bridge term loan facility (the "Bridge Loan"). The Company capitalized $48 million of deferred financing costs associated with the Bridge Loan which are being amortized over the commitment period. In May 2023, the aggregate principal amount of the Bridge Loan was reduced by €2.3 billion upon entering into a senior unsecured delayed draw term loan credit agreement. As a result, the Company accelerated the amortization on $10 million of deferred financing costs in Interest expense. In November 2023, the aggregate principle amount of the Bridge Loan was reduced by €5.4 billion upon the issuance of the USD Notes and the Euro Notes. As a result, the Company accelerated the amortization on $15 million of deferred financing costs in Interest expense.

[0001783180-24-000009:notes:267]
On May 19, 2023, the Company entered into a senior unsecured delayed draw term loan credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders that permits aggregate borrowings of up to €2.3 billion (the "Delayed Draw Facility"). The Company capitalized $4 million of deferred financing costs associated with the Delayed Draw Facility which will be amortized over the term once the facility is drawn upon. In addition, the Company entered into a 364-day, $500 million, senior unsecured revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent and certain other lenders (the "Revolver") on May 19, 2023. Proceeds from the Revolver became available upon closing the purchase of the VCS Business.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001783180-24-000009:notes:268]
DIVESTITURES
Planned Portfolio Transformation

[0001783180-24-000009:notes:269]
On April 25, 2023, the Company announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. On December 7, 2023, the Company entered into a stock purchase agreement to sell its Access Solutions business to Honeywell International Inc. for an enterprise value of approximately $4.95 billion. Access Solutions, historically reported in the Company's Fire & Security segment, is a global supplier of physical security and digital access solutions supporting the hospitality, commercial, education and military markets. On December 12, 2023, the Company entered into a stock purchase agreement to sell the CCR business to Haier Group Corporation for an enterprise value of approximately $775 million. CCR, historically reported in the Company's Refrigeration segment, is a global supplier of turnkey solutions for commercial refrigeration systems and services, with a primary focus on serving food retail customers, cold storage facilities and warehouses. As a result, the assets and liabilities of both businesses are presented as held for sale in the accompanying Consolidated Balance Sheets as of December 31, 2023 and recorded at the lower of their carrying value or fair value less estimated cost to sell. Both transactions are expected to close in 2024 and are subject to customary closing conditions.

[0001783180-24-000009:notes:270]
The following table summarizes assets and liabilities classified as held for sale:

[0001783180-24-000009:notes:271]
|  | December 31, 2023 |
| (In millions) | Commercial Refrigeration |  | AccessSolutions |  | IndustrialFire |  | Total |
| Cash and cash equivalents | $ | 131 |  |  | $ | 6 |  |  | $ | 20 |  |  | $ | 157 |  |
| Accounts receivable, net | 274 |  |  | 104 |  |  | 101 |  |  | 479 |  |
| Inventories, net | 84 |  |  | 31 |  |  | 65 |  |  | 180 |  |
| Contract assets, current | 98 |  |  | 2 |  |  | 42 |  |  | 142 |  |
| Other assets, current | 15 |  |  | 3 |  |  | 4 |  |  | 22 |  |
| Fixed assets, net | 78 |  |  | 13 |  |  | 22 |  |  | 113 |  |
| Intangible assets, net | — |  |  | 53 |  |  | 2 |  |  | 55 |  |
| Goodwill | 72 |  |  | 1,498 |  |  | 439 |  |  | 2,009 |  |
| Operating lease right-of-use assets | 49 |  |  | 13 |  |  | 28 |  |  | 90 |  |
| Other assets | 44 |  |  | 10 |  |  | 13 |  |  | 67 |  |
| Total assets held for sale | $ | 845 |  |  | $ | 1,733 |  |  | $ | 736 |  |  | $ | 3,314 |  |
| Accounts payable | $ | 129 |  |  | $ | 20 |  |  | $ | 39 |  |  | $ | 188 |  |
| Accrued liabilities | 181 |  |  | 21 |  |  | 55 |  |  | 257 |  |
| Contract liabilities, current | 23 |  |  | 53 |  |  | 22 |  |  | 98 |  |
| Long-term debt, including current portion | 8 |  |  | — |  |  | — |  |  | 8 |  |
| Future pension and post-retirement obligations | 203 |  |  | — |  |  | 1 |  |  | 204 |  |
| Future income tax obligations | 4 |  |  | 2 |  |  | 3 |  |  | 9 |  |
| Operating lease liabilities | 40 |  |  | 11 |  |  | 23 |  |  | 74 |  |
| Other long-term liabilities | 3 |  |  | 12 |  |  | 9 |  |  | 24 |  |
| Total liabilities held for sale | $ | 591 |  |  | $ | 119 |  |  | $ | 152 |  |  | $ | 862 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-24-000009:notes:272]
SEGMENT FINANCIAL DATA
The Company conducts its operations through three reportable operating segments: HVAC, Refrigeration and Fire & Security. In accordance with ASC 280 - Segment Reporting, the Company’s segments maintain separate financial information for which results of operations are evaluated on a regular basis by the Company’s Chief Operating Decision Maker in deciding how to allocate resources and in assessing performance. Inter-company sales between segments are immaterial.

[0001783180-24-000009:notes:273]
•The HVAC segment provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-24-000009:notes:274]
•The Refrigeration segment includes transport refrigeration and monitoring products, services and digital solutions for trucks, trailers, shipping containers, intermodal and rail, as well as commercial refrigeration products.

[0001783180-24-000009:notes:275]
•The Fire & Security segment provides a wide range of residential, commercial and industrial technologies designed to help protect people and property.

[0001783180-24-000009:notes:276]
The Company's customers are in both the public and private sectors and its businesses reflect extensive geographic diversification. Inter-company sales between segments are immaterial.

[0001783180-24-000009:notes:277]
Net sales and Operating profit by segment are as follows:

[0001783180-24-000009:notes:278]
|  | Net Sales |  | Operating Profit |
| (In millions) | 2023 |  | 2022 |  | 2021 |  | 2023 |  | 2022 |  | 2021 |
| HVAC | $ | 15,139 |  |  | $ | 13,408 |  |  | $ | 11,390 |  |  | $ | 2,275 |  |  | $ | 2,610 |  |  | $ | 1,738 |  |
| Refrigeration | 3,818 |  |  | 3,883 |  |  | 4,127 |  |  | 428 |  |  | 483 |  |  | 476 |  |
| Fire & Security | 3,633 |  |  | 3,570 |  |  | 5,515 |  |  | 209 |  |  | 1,630 |  |  | 662 |  |
| Total segment | 22,590 |  |  | 20,861 |  |  | 21,032 |  |  | 2,912 |  |  | 4,723 |  |  | 2,876 |  |
| Eliminations and other | (492) |  |  | (440) |  |  | (419) |  |  | (275) |  |  | (80) |  |  | (96) |  |
| General corporate expenses | — |  |  | — |  |  | — |  |  | (341) |  |  | (128) |  |  | (135) |  |
| Consolidated | $ | 22,098 |  |  | $ | 20,421 |  |  | $ | 20,613 |  |  | $ | 2,296 |  |  | $ | 4,515 |  |  | $ | 2,645 |  |

[0001783180-24-000009:notes:279]
Total assets are not presented for each segment as they are not presented to or reviewed by the CODM. Segment assets in the following table represent Accounts receivable, net, Contract assets, current and Inventories, net. These assets are regularly reviewed by management and are therefore reported in the following table as segment assets. All other remaining assets and liabilities for all periods presented are managed on a company-wide basis.

[0001783180-24-000009:notes:280]
|  | Segment Assets |  | Capital Expenditures |  | Depreciation & Amortization |
| (In millions) | 2023 |  | 2022 |  |  |  | 2023 |  | 2022 |  | 2021 |  | 2023 |  | 2022 |  | 2021 |
| HVAC | $ | 3,204 |  |  | $ | 3,191 |  |  |  |  | $ | 313 |  |  | $ | 232 |  |  | $ | 225 |  |  | $ | 413 |  |  | $ | 256 |  |  | $ | 186 |  |
| Refrigeration | 834 |  |  | 1,279 |  |  |  |  | 30 |  |  | 32 |  |  | 39 |  |  | 34 |  |  | 31 |  |  | 36 |  |
| Fire & Security | 940 |  |  | 1,492 |  |  |  |  | 33 |  |  | 40 |  |  | 49 |  |  | 54 |  |  | 58 |  |  | 83 |  |
| Total Segment | 4,978 |  |  | 5,962 |  |  |  |  | 376 |  |  | 304 |  |  | 313 |  |  | 501 |  |  | 345 |  |  | 305 |  |
| Eliminations and other | 26 |  |  | 48 |  |  |  |  | 93 |  |  | 49 |  |  | 31 |  |  | 41 |  |  | 35 |  |  | 33 |  |
| Consolidated | $ | 5,004 |  |  | $ | 6,010 |  |  |  |  | $ | 469 |  |  | $ | 353 |  |  | $ | 344 |  |  | $ | 542 |  |  | $ | 380 |  |  | $ | 338 |  |
| Cash and cash equivalents | 10,015 |  |  | 3,520 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other assets, current | 447 |  |  | 349 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets held for sale | 3,314 |  |  | — |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total current assets | $ | 18,780 |  |  | $ | 9,879 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001783180-24-000009:notes:281]
Geographic External Sales

[0001783180-24-000009:notes:282]
Geographic external sales and operating profits are attributed to the geographic regions based on their location of origin. With the exception of the U.S. as presented in the following table, there were no individually significant countries with sales exceeding 10% of total sales for the years ended December 31, 2023, 2022 and 2021.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-24-000009:notes:283]
RELATED PARTIES 
Equity Method Investments

[0001783180-24-000009:notes:284]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered to be related parties. The Company has 26 directly owned unconsolidated domestic and foreign affiliates as of December 31, 2023, of which 97% of such investments are in its HVAC segment. The Company periodically reviews the carrying value of its equity method investments to determine if there has been an other-than-temporary decline in fair value.

[0001783180-24-000009:notes:285]
Amounts attributable to equity method investees are as follows:

[0001783180-24-000009:notes:286]
| (In millions) | 2023 |  | 2022 |  | 2021 |
| Sales to equity method investees included in Product sales | $ | 2,920 |  |  | $ | 2,845 |  |  | $ | 2,258 |  |
| Purchases from equity method investees included in Cost of products sold | $ | 214 |  |  | $ | 331 |  |  | $ | 357 |  |

[0001783180-24-000009:notes:287]
The Company had receivables from and payables to equity method investees as follows:

[0001783180-24-000009:notes:288]
| (In millions) | 2023 |  | 2022 |
| Receivables from equity method investees included in Accounts receivable, net | $ | 231 |  |  | $ | 154 |  |
| Payables to equity method investees included in Accounts payable | $ | 44 |  |  | $ | 44 |  |

[0001783180-24-000009:notes:289]
The financial results of TCC are included in the Company's consolidated results since the acquisition date of August 1, 2022. Prior to the acquisition, the Company previously accounted for its minority ownership in TCC under the equity method of accounting. As a result, prior period results may not be comparable to the current period.

[0001783180-24-000009:notes:290]
Summarized Financial Information. Pursuant to Rule 3-10 and Rule 4-08(g) of Regulation S-X under the Securities Act, the Company presents summarized financial information of the combined accounts of its non-consolidated joint ventures accounted for by the equity method.

[0001783180-24-000009:notes:291]
Summarized unaudited financial information for equity method investments is as follows:

[0001783180-24-000009:notes:292]
| (In millions) | 2023 |  | 2022 |
| Current assets | $ | 11,432 |  |  | $ | 10,621 |  |
| Non-current assets | 1,834 |  |  | 1,931 |  |
| Total assets | 13,266 |  |  | 12,552 |  |
| Current liabilities | (9,296) |  |  | (8,631) |  |
| Non-current liabilities | (190) |  |  | (195) |  |
| Total liabilities | (9,486) |  |  | (8,826) |  |
| Total net equity of investees | $ | 3,780 |  |  | $ | 3,726 |  |

[0001783180-24-000009:notes:293]
| (In millions) | 2023 |  | 2022 |  | 2021 |
| Net sales | $ | 16,180 |  |  | $ | 11,524 |  |  | $ | 9,471 |  |
| Gross profit | $ | 2,862 |  |  | $ | 2,274 |  |  | $ | 1,907 |  |
| Income from continuing operations | $ | 655 |  |  | $ | 757 |  |  | $ | 650 |  |
| Net income | $ | 655 |  |  | $ | 757 |  |  | $ | 650 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-24-000009:notes:294]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability has been incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon its results of operations or financial condition.

[0001783180-24-000009:notes:295]
Environmental Matters

[0001783180-24-000009:notes:296]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to, investigatory, remediation, operating and maintenance costs and performance guarantees. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including the technology required to remediate, current laws and regulations and prior remediation experience.

[0001783180-24-000009:notes:297]
As of December 31, 2023 and 2022, the outstanding liability for environmental obligations are as follows:

[0001783180-24-000009:notes:298]
| (In millions) |  | 2023 |  | 2022 |
| Environmental reserves included in Accrued liabilities |  | $ | 21 |  |  | $ | 24 |  |
| Environmental reserves included in Other long-term liabilities |  | 203 |  |  | 211 |
| Total environmental reserves |  | $ | 224 |  |  | $ | 235 |  |

[0001783180-24-000009:notes:299]
For sites with multiple responsible parties, the Company considers its likely proportionate share of the anticipated remediation costs and the ability of other parties to fulfill their obligations in establishing a provision for these costs. Accrued environmental liabilities are not reduced by potential insurance reimbursements and are undiscounted.

[0001783180-24-000009:notes:300]
Asbestos Matters

[0001783180-24-000009:notes:301]
The Company has been named as a defendant in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-24-000009:notes:302]
The Company's asbestos liabilities and related insurance recoveries are as follows:

[0001783180-24-000009:notes:303]
| (In millions) |  | 2023 |  | 2022 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 15 |  |  | $ | 16 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 206 |  |  | 212 |  |
| Total asbestos liabilities |  | $ | 221 |  |  | $ | 228 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 88 |  |  | 90 |  |
| Total asbestos-related recoveries |  | $ | 93 |  |  | $ | 95 |  |

[0001783180-24-000009:notes:304]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and exclude the Company's legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.

[0001783180-24-000009:notes:305]
UTC Equity Awards Conversion Litigation

[0001783180-24-000009:notes:306]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against RTX, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenged the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021 (the "Amended Complaint"). The Amended Complaint, with RTX, Carrier and Otis as the only defendants, asserted that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also sought specific performance. The Company believes all plaintiffs' claims against it are without merit. Defendants moved to dismiss the Amended Complaint. On September 30, 2022, the court dismissed the case against all defendants, with prejudice. Plaintiffs appealed the dismissal to the United States Court of Appeals for the Second Circuit. On August 3, 2023, the Second Circuit of Appeals affirmed the district court's ruling. The Second Circuit’s judgment is final and non-appealable.

[0001783180-24-000009:notes:307]
Aqueous Film Forming Foam Litigation

[0001783180-24-000009:notes:308]
As of December 31, 2022, the Company, KFI and others have been named as defendants in more than 6,000 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company, KFI and others have also been named as defendants in more than 700 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring,

[0001783180-24-000009:notes:309]
diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

[0001783180-24-000009:notes:310]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires. The lawsuits identified above relate to Kidde Fire Fighting, Inc., which owned the National Foam business. Kidde Fire Fighting, Inc. was acquired by a UTC subsidiary in 2005 and merged into KFI in 2007. The National Foam business manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania (the "Pennsylvania Site"). In 2013, KFI divested the AFFF businesses to an unrelated third party. The Company acquired KFI as part of the Separation in April 2020.

[0001783180-24-000009:notes:311]
The key components of AFFF that contribute to its fire-extinguishing capabilities are known as fluorosurfactants. Neither the Company nor KFI, nor any of the Company's subsidiaries involved in the AFFF litigation manufactured fluorosurfactants. Instead, the National Foam business purchased these substances from unrelated third parties to in turn manufacture AFFF. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as per- and polyfluoroalkyl substances (referred to collectively as "PFAS"), including perflourooctanesulfonic acid ("PFOS") and perflourooctanoic acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

[0001783180-24-000009:notes:312]
Plaintiffs in the MDL Proceedings allege that PFOS and PFOA contamination has resulted from the use of AFFF manufactured using a process known as ECF, and that this process was used exclusively by 3M. They also allege that PFOA contamination has resulted from the use of AFFF manufactured using a different process, known as telomerization, and that this process was used exclusively by the other AFFF manufacturers (including the National Foam business). Compounds containing PFOS and PFOA (as well as many other PFAS) have also been used for decades by many third parties in a number of different industries to manufacture firefighters’ protective outerwear, carpets, clothing, fabrics, cookware, food packaging, personal care products, cleaning products, paints, varnishes and other consumer and industrial products.

[0001783180-24-000009:notes:313]
Plaintiffs in the MDL Proceedings have named multiple defendants, including suppliers of chemicals and raw materials used to manufacture fluorosurfactants, fluorosurfactant manufacturers and AFFF manufactures. The defendants in the MDL Proceedings moved for summary judgment on the government contractor defense, which potentially applies to AFFF sold to or used by the U.S. government. After full briefing and oral argument, on September 16, 2022, the MDL court declined to enter summary judgment for the defendants. The defense, however, remains available at any trial to which it applies.

[0001783180-24-000009:notes:314]
On September 23, 2022, after completion of discovery, the MDL court selected one water provider case, the City of Stuart, FL v. 3M, et al., for a bellwether trial. That trial was scheduled to begin in early June 2023 but was postponed indefinitely. The MDL court has ordered that the bellwether process for personal injury cases to begin in 2023. However, the court has not yet outlined details on that process or its timing.

[0001783180-24-000009:notes:315]
Outside of the MDL Proceedings, the Company and other defendants are also party to six lawsuits in U.S. state courts brought by oil refining companies alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage. In addition, the Company and other defendants are party to two actions related to the Pennsylvania Site in which the plaintiff water utility company seeks remediation costs related to the alleged contamination of the local water supply. The Company, KFI and other defendants are also party to one action in Arizona state court brought by a firefighter claiming that occupational exposure to AFFF has caused certain personal injuries.

[0001783180-24-000009:notes:316]
The Company and KFI believe that they have meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate a range of possible loss at this time. There can be no assurance that any such future exposure will not be material in any period.

[0001783180-24-000009:notes:317]
On May 14, 2023, KFI filed a voluntary petition with the United States Bankruptcy court for the District of Delaware seeking relief under Chapter 11 of the Bankruptcy Code after the Company determined that it would not provide financial support to KFI going forward, other than ensuring KFI has access to services necessary for the effective operation of its business. As a result, all litigation against KFI is automatically stayed. KFI filed an adversary complaint and motion in the Chapter 11 case seeking an order staying or enjoining all AFFF-related litigation against the Company, its other subsidiaries and RTX. That

[0001783180-24-000009:notes:318]
motion was resolved through an agreement that effectively stays the AFFF litigation against these parties. KFI has also indicated to the bankruptcy court that it intends to pursue insurance coverage for AFFF-related liabilities and contractual indemnification for AFFF-related liabilities from the third party to which KFI sold National Foam. On November 21, 2023, the bankruptcy court ordered certain parties, including the Company, to participate in a mediation with respect to claims that might be asserted by and against it in the bankruptcy proceedings. The parties have engaged in several mediation sessions and anticipate further sessions in the future.

[0001783180-24-000009:notes:319]
Deconsolidation Due to Bankruptcy

[0001783180-24-000009:notes:320]
As of May 14, 2023, the Company no longer controlled KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from the Company’s Consolidated Financial Statements. Upon deconsolidation, the Company determined the fair value of its retained interest in KFI to be zero and accounted for it prospectively using the cost method. As a result of these actions, the Company recognized a loss of $297 million in its Consolidated Statements of Operations within Other income/(expense), net. In addition, the deconsolidation resulted in an investing cash outflow of $134 million in the Company's Consolidated Statements of Cash Flows.

[0001783180-24-000009:notes:321]
In connection with the bankruptcy filing, KFI entered into several agreements with subsidiaries of the Company to ensure they have access to services necessary for the effective operation of their business. All post-deconsolidation activity between the Company and KFI are reported as third-party transactions recorded within the Company's Consolidated Statements of Operations. Since the petition date, there were no material transactions between the Company and KFI.

[0001783180-24-000009:notes:322]
Income Taxes

[0001783180-24-000009:notes:323]
Under the Tax Matters Agreement relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, liabilities of $132 million and $243 million are included within the accompanying Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of December 31, 2023, respectively. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $89 million due in 2024. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

[0001783180-24-000009:notes:324]
Self-Insurance

[0001783180-24-000009:notes:325]
The Company maintains self-insurance for a number of risks, including but not limited to, workers’ compensation, general liability, automobile liability, property and employee-related healthcare benefits. It has obtained insurance coverage for amounts exceeding individual and aggregate loss limits. The Company accrues for known future claims and incurred but not reported losses.

[0001783180-24-000009:notes:326]
The Company's self-insurance liabilities were as follows:

[0001783180-24-000009:notes:327]
| (In millions) | 2023 |  | 2022 |
| Self-insurance liabilities included in Accrued liabilities | $ | 160 |  |  | $ | 139 |  |
| Self-insurance liabilities included in Other long-term liabilities | 55 |  |  | 53 |
| Total self-insurance liabilities | $ | 215 |  |  | $ | 192 |  |

[0001783180-24-000009:notes:328]
The Company incurred expenses related to self-insured risks of $180 million, $155 million and $155 million for the years ended December 31, 2023, 2022 and 2021, respectively.

[0001783180-24-000009:notes:329]
Other Matters

[0001783180-24-000009:notes:330]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-24-000009:notes:331]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its competitive position, results of operations, cash flows or financial condition.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001783180-24-000009:notes:332]
SUPPLEMENTAL CASH FLOW INFORMATION 
Supplemental cash flow information was as follows:

[0001783180-24-000009:notes:333]
| (In millions) | 2023 |  | 2022 |  | 2021 |
| Interest paid, net of amounts capitalized | $ | 320 |  |  | $ | 297 |  |  | $ | 317 |  |
| Income taxes paid, net of refunds | $ | 942 |  |  | $ | 833 |  |  | $ | 675 |  |
| Non-cash financing activity: |  |  |  |  |  |
| Common stock dividends payable | $ | 161 |  |  | $ | 158 |  |  | $ | 130 |  |


## us-gaap:SubsequentEventsTextBlock

[0001783180-24-000009:notes:334]
SUBSEQUENT EVENTS 
On January 2, 2024, the Company entered into a 60-day senior unsecured bridge term loan agreement with JPMorgan Chase Bank, N.A., as administrative agent ("60-day Bridge Loan"). The facility consisted of a Euro-denominated tranche in an aggregate amount of €113 million and a USD-denominated tranche in an aggregate amount of $349 million. Euro-denominated borrowings bear interest at the EURIBOR Rate plus a ratings-based margin, USD-denominated borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at a base rate plus a ratings-based margin. The proceeds of the senior unsecured bridge term loan were used to fund a portion of the Euro-denominated purchase price of the VCS Business.

[0001783180-24-000009:notes:335]
On January 2, 2024, the Company completed the previously announced acquisition of the VCS Business from Viessmann for total consideration of $14.2 billion. The purchase price consisted of (i) US$11.2 billion in cash and (ii) 58,608,959 shares of the Company's common stock, subject to long-term lock-up provisions and anti-dilution protection. The Company funded the cash portion of the base purchase price with a combination of cash on hand, net proceeds from the USD Notes and Euro Notes and borrowings under the Delayed Draw Facility and the 60-day Bridge Loan.

[0001783180-24-000009:notes:336]
The VCS Business develops intelligent, integrated and sustainable technologies, including heat pumps, boilers, photovoltaic systems, home battery storage and digital solutions, primarily for residential customers in Europe. The Company believes that secular trends in these areas will drive significant, sustained future growth. In addition, the Company anticipates realizing significant operational synergies including purchase material savings through supplier rationalization and procurement leverage, improvement in manufacturing costs and lower general and administrative costs. Longer term, the Company expects to benefit from synergies related to service revenue expansion, leverage of distribution channels and vertical cross selling through certain vertical markets. The net sales of the VCS Business were €3.4 billion during the twelve months ended December 31, 2022.

[0001783180-24-000009:notes:337]
The transaction will be accounted for as a business combination under ASC 805 and the results of operations from the date of acquisition will be reflected within the HVAC segment. The Company is in the process of completing its appraisals of tangible and intangible assets relating to this acquisition and the allocation of the purchase price to the assets acquired and liabilities assumed will be completed once the appraisal process has been finalized. During the year ended December 31, 2023, the Company recognized acquisition-related costs of $80 million, which are reflected within Selling, general and administrative in the Consolidated Statement of Operations.
