# CARR MD&A — 0001783180-26-000008


## mdna

[0001783180-26-000008:mdna:1]
ITEM 7. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001783180-26-000008:mdna:2]
BUSINESS OVERVIEW

[0001783180-26-000008:mdna:3]
Business Summary

[0001783180-26-000008:mdna:4]
Carrier Global Corporation ("we" or "our") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to our customers. Our portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic and Carrier Transicold, among others, that offer innovative heating, cooling and cold chain solutions to enhance the lives we live and the world we share. We also provide a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. Our operations are classified into four segments: Climate Solutions Americas, Climate Solutions Europe, Climate Solutions Asia Pacific, Middle East & Africa and Climate Solutions Transportation.

[0001783180-26-000008:mdna:5]
Through our performance-driven culture, we anticipate creating long-term shareowner value by investing strategically to strengthen our product position in homes, buildings and across the cold chain in order to drive profitable growth. We believe our business segments are well positioned to benefit from favorable secular trends, including the mega-trends of urbanization, population growth and demographic shifts, food security and safety, electrification, increasing demand for climate control and accelerated digitalization. Coupled with our industry-leading brands and track record of innovation, we continue to provide market-leading solutions for our customers.

[0001783180-26-000008:mdna:6]
Our worldwide operations are affected by global and regional industrial, economic and political factors, trade policies and trends. They are also affected by changes in the general level of economic activity, such as changes in business and consumer spending, construction and shipping activity as well as short-term economic factors such as currency fluctuations, commodity price volatility and supply disruptions. We continue to invest in our business, take pricing actions to mitigate supply chain and inflationary pressures, develop new products and services in order to remain competitive in our markets and use risk management strategies to mitigate various exposures.

[0001783180-26-000008:mdna:7]
We continue to actively monitor evolving macroeconomic conditions and recent trade policy announcements. Based on our updated analysis, we fully mitigated the impact of tariffs during 2025 through a combination of supply-chain adjustments, productivity initiatives and approximately $200 million of incremental product pricing actions. To date, tariffs have not had a material impact on our business and we are deploying additional strategies, including cost containment measures, to limit future exposure in the current market environment.

[0001783180-26-000008:mdna:8]
Significant Events

[0001783180-26-000008:mdna:9]
Sale of Riello Business

[0001783180-26-000008:mdna:10]
On December 16, 2025, we entered into a purchase agreement to sell our Riello business ("Riello") to Ariston Group with expected gross proceeds of approximately $430 million. Riello, predominantly reported in our Climate Solutions Europe segment, is a leading international manufacturer that designs, produces and integrates a comprehensive portfolio of thermal solutions including burners, boilers, heat pumps, cooling systems and aftermarket services for residential, commercial and industrial applications, with a strong focus on energy efficiency, innovation and a global distribution network. This transaction is expected to close in the first half of 2026 and is subject to customary closing conditions and regulatory approvals.

[0001783180-26-000008:mdna:11]
Portfolio Transformation

[0001783180-26-000008:mdna:12]
During 2024, we completed several activities designed to simplify our business portfolio, transforming it into a pure-play climate and energy solutions provider. On January 2, 2024, we acquired the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (together with its affiliates, “Viessmann”). The VCS Business, primarily reported in the Climate Solutions Europe segment, is a premier residential and light commercial heating, ventilating and air conditioning ("HVAC") provider in Europe that expanded our portfolio to offer a global, comprehensive suite of sustainable and innovative building and energy management solutions. In addition, we divested our Commercial and Residential Fire, Access Solutions and Industrial Fire businesses which were historically reported in our Fire & Security segment. The transactions represented a single disposal plan to separately divest multiple businesses over different reporting periods and met the criteria to be presented as discontinued operations. We also divested our Commercial Refrigeration business (“CCR”) during 2024. CCR, which was historically reported in the Climate Solutions Transportation segment (previously named Refrigeration), did not meet the criteria to be presented as discontinued operations.

[0001783180-26-000008:mdna:13]
Segment Reorganization

[0001783180-26-000008:mdna:14]
As a result of our portfolio transformation, we revised our reportable segments to better align our reporting structure with our business strategy, resource allocation and performance assessment. Under the revised segment structure, we have three new regional HVAC operating segments. Combined with the existing Climate Solutions Transportation operating segment, the four operating segments also serve as our reportable segments. This model is designed to create a simplified, more focused and customer-centric organization across the globe. Each segment reports through separate management teams which regularly review their operating results with our Chief Operating Decision Maker (the "CODM") determined in accordance with applicable accounting guidance. In connection with the revised structure, the CODM changed the measure used to evaluate segment profitability from Operating profit to Segment operating profit. All prior period comparative information has been recast to reflect the revised segment structure.

[0001783180-26-000008:mdna:15]
RESULTS OF OPERATIONS

[0001783180-26-000008:mdna:16]
This discussion summarizes the significant factors affecting our consolidated results of operations, financial condition and liquidity for the year ended December 31, 2025, compared with December 31, 2024. This discussion should be read in conjunction with Item 8, the Consolidated Financial Statements and the accompanying Notes to the Consolidated Financial Statements in this Annual Report. A detailed discussion of the year ended December 31, 2024, compared with December 31, 2023, is not included herein and can be found in the Management's Discussion and Analysis of Financial Condition and Results of Operations section in the recast of the Company's Annual Report on Form 10-K for the year ended December 31, 2024, included within Exhibit 99.1 to the Current Report on Form 8-K filed with the SEC on July 29, 2025, under the heading "Results of Operations," which is incorporated herein by reference.

[0001783180-26-000008:mdna:17]
Year Ended December 31, 2025 Compared with Year Ended December 31, 2024

[0001783180-26-000008:mdna:18]
The following represents our consolidated net sales and operating results:

[0001783180-26-000008:mdna:19]
| (In millions) | 2025 |  | 2024 |  | Period Change |  | % Change |  |
| Net sales | $ | 21,747 |  |  | $ | 22,486 |  |  | $ | (739) |  |  | (3) | % |  |
| Cost of products and services sold | (16,123) |  |  | (16,505) |  |  | 382 |  |  | (2) | % |  |
| Gross margin | 5,624 |  |  | 5,981 |  |  | (357) |  |  | (6) | % |  |
| Operating expenses | (3,452) |  |  | (3,335) |  |  | (117) |  |  | 4 | % |  |
| Operating profit | 2,172 |  |  | 2,646 |  |  | (474) |  |  | (18) | % |  |
| Non-operating income (expense), net | (374) |  |  | (372) |  |  | (2) |  |  | 1 | % |  |
| Earnings (loss) before income taxes | 1,798 |  |  | 2,274 |  |  | (476) |  |  | (21) | % |  |
| Income tax expense | (240) |  |  | (1,062) |  |  | 822 |  |  | (77) | % |  |
| Earnings (loss) from continuing operations | 1,558 |  |  | 1,212 |  |  | 346 |  |  | 29 | % |  |
| Discontinued operations, net of income taxes | 29 |  |  | 4,496 |  |  | (4,467) |  |  | (99) | % |  |
| Net earnings (loss) | 1,587 |  |  | 5,708 |  |  | (4,121) |  |  | (72) | % |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations | 103 |  |  | 104 |  |  | (1) |  |  | (1) | % |  |
| Net earnings (loss) attributable to common shareowners | $ | 1,484 |  |  | $ | 5,604 |  |  | $ | (4,120) |  |  | (74) | % |  |

[0001783180-26-000008:mdna:20]
Net Sales

[0001783180-26-000008:mdna:21]
For the year ended December 31, 2025, Net sales was $21.7 billion, a 3% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-26-000008:mdna:22]
|  | 2025 |  |
| Organic / Operational | (1) | % |  |
| Foreign currency translation | 1 | % |  |
| Acquisitions and divestitures, net | (3) | % |  |
| Total % change | (3) | % |  |

[0001783180-26-000008:mdna:23]
Organic sales for the year ended December 31, 2025, decreased by 1% compared with the same period of 2024. The organic decrease was primarily due to our Climate Solutions Americas segment as reduced demand in certain end-markets resulted in lower volumes. In addition, lower end-market demand in both Climate Solutions Europe and Climate Solutions Asia Pacific, Middle East & Africa further impacted results. These amounts were partially offset by improved end-market demand in our Climate Solutions Transportation segment. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-26-000008:mdna:24]
Gross Margin

[0001783180-26-000008:mdna:25]
For the year ended December 31, 2025, gross margin was $5.6 billion, a 6% decrease compared with the same period of 2024. The components were as follows:

[0001783180-26-000008:mdna:26]
| (In millions) | 2025 |  | 2024 |
| Net sales | $ | 21,747 |  |  | $ | 22,486 |  |
| Cost of products and services sold | (16,123) |  |  | (16,505) |  |
| Gross margin | $ | 5,624 |  |  | $ | 5,981 |  |
| Percentage of net sales | 25.9 | % |  | 26.6 | % |

[0001783180-26-000008:mdna:27]
Gross margin decreased by $357 million compared with the year ended December 31, 2024, primarily due to lower volumes in certain end-markets partially offset by our continued focus on productivity initiatives. As a result, gross margin as a percentage of Net sales decreased by 70 basis points compared with the same period of 2024. The prior period included inventory step-up and backlog amortization resulting from the recognition of acquired assets of the VCS Business at fair value which are now fully amortized. These costs had a 130 basis point unfavorable impact on the prior period gross margin as a percentage of Net sales.

[0001783180-26-000008:mdna:28]
Operating Expenses

[0001783180-26-000008:mdna:29]
For the year ended December 31, 2025, operating expenses, including Equity method investment net earnings, was $3.5 billion, a 4% increase compared with the same period of 2024. The components were as follows:

[0001783180-26-000008:mdna:30]
|  | For the Year Ended December 31, |  |  |
| (In millions) | 2025 |  | 2024 |  |  |
| Selling, general and administrative | $ | (3,092) |  |  | $ | (3,197) |  |  |  |
| Research and development | (625) |  |  | (686) |  |  |  |
| Equity method investment net earnings | 229 |  |  | 231 |  |  |  |
| Other income (expense), net | 36 |  |  | 317 |  |  |  |
| Operating expenses | $ | (3,452) |  |  | $ | (3,335) |  |  |  |
| Percentage of net sales | 15.9 | % |  | 14.8 | % |  |  |

[0001783180-26-000008:mdna:31]
For the year ended December 31, 2025, Selling, general and administrative expenses were $3.1 billion, a 3% decrease compared with the same period of 2024. The decrease relates to productivity initiatives associated with our portfolio transformation and synergies associated with the integration of the VCS Business. In addition, foreign currency translation further benefitted results. These benefits were partially offset by higher compensation and other employee-related costs. In addition, the current year also included $56 million of acquisition and divestiture-related costs compared with $95 million during the year ended December 31, 2024.

[0001783180-26-000008:mdna:32]
Research and development costs relate to new product development and new technology innovation. Due to the variable nature of program development schedules, year-over-year spending levels can fluctuate. In addition, we continue to invest to prepare for future product innovations and digital controls technologies.

[0001783180-26-000008:mdna:33]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the year ended December 31, 2025, Equity method investment net earnings were $229 million, a 1% decrease compared with the same period of 2024. The decrease was primarily driven by lower earnings in joint ventures within our Climate Solutions Americas segment.

[0001783180-26-000008:mdna:34]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. During the year ended December 31, 2025, we finalized the working capital and other adjustments provided in the stock purchase agreement governing the sale of CCR and recognized gains on sale of several equity method investments.

[0001783180-26-000008:mdna:35]
During the year ended December 31, 2024, we completed the sale of CCR and recognized a gain on the sale of $318 million. In addition, we recognized a $46 million gain associated with our share of United Technologies Corporation's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the Internal Revenue Service ("IRS"). In connection with the acquisition of the VCS Business, we recognized an $86 million loss on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price.

[0001783180-26-000008:mdna:36]
36

[0001783180-26-000008:mdna:37]
Non-Operating Income (Expense), net

[0001783180-26-000008:mdna:38]
For the year ended December 31, 2025, Non-operating income (expense), net was $374 million, a 1% increase compared with the same period of 2024. The components were as follows:

[0001783180-26-000008:mdna:39]
|  | For the Year Ended December 31, |  |
| (In millions) | 2025 |  | 2024 |  |
| Non-service pension benefit (expense) | $ | (10) |  |  | $ | (1) |  |  |
| Interest expense | (458) |  |  | (580) |  |  |
| Interest income | 94 |  |  | 209 |  |  |
| Interest (expense) income, net | (364) |  |  | (371) |  |  |
| Non-operating income (expense), net | $ | (374) |  |  | $ | (372) |  |  |

[0001783180-26-000008:mdna:40]
Non-operating income (expense), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the year ended December 31, 2025, interest expense was $458 million, a 21% decrease compared with the same period of 2024. Consistent with our capital allocation strategy, we reduced our outstanding debt by approximately $3 billion over the course of 2024 and repaid an additional $1.2 billion during 2025. During 2024, we incurred make-whole premiums of $14 million in Interest expense, wrote off $17 million of unamortized deferred financing costs in Interest expense and recognized a net gain of $97 million in Interest income.

[0001783180-26-000008:mdna:41]
Income Taxes

[0001783180-26-000008:mdna:42]
|  |  | 2025 |  | 2024 |  |  |
| Effective tax rate |  | 13.4 | % |  | 46.7 | % |  |  |

[0001783180-26-000008:mdna:43]
The effective tax rate for the year ended December 31, 2025 was lower than the Company's statutory U.S. federal income tax rate. The decrease was primarily driven by a net tax benefit of $64 million from changes to the German effective rate and a statutory reduction to the German corporate tax rate enacted during the year, a tax benefit of $49 million from the re-organization of a Japanese subsidiary and a $16 million tax benefit generated by the purchase of investment tax credits from a third-party.

[0001783180-26-000008:mdna:44]
The effective tax rate for the year ended December 31, 2024 was higher than the Company's statutory U.S. federal income tax rate. The increase was primarily driven by a net tax charge of $650 million related to a re-organization of the VCS Business and a non-deductible loss of $86 million on the mark-to-market valuation of the Company's window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business. These amounts were partially offset by the lower effective tax rate on the $318 million gain on the sale of CCR and $44 million of foreign tax credits generated and utilized in the current year.

[0001783180-26-000008:mdna:45]
37

[0001783180-26-000008:mdna:46]
Adjusted Operating Profit

[0001783180-26-000008:mdna:47]
We report our financial results in accordance with accounting principles generally accepted in the United States ("GAAP"). In addition, we supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. Adjusted operating profit is a non-GAAP measure that we define as consolidated operating profit (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items of a nonoperational nature. This measure is useful to investors because it is how management assesses the operating performance of the business. A reconciliation of the amounts prepared in accordance with GAAP to the corresponding non-GAAP measure appears below and provides additional information as to the items and amounts that have been excluded from the adjusted measure.

[0001783180-26-000008:mdna:48]
|  |  | For the Year Ended December 31, |
| (In millions) |  | 2025 |  | 2024 |
| Reconciliation to Adjusted operating profit |  |  |  |  |
| Operating profit |  | $ | 2,172 |  |  | $ | 2,646 |  |
| Restructuring costs |  | 178 |  |  | 108 |  |
| Amortization of acquired intangibles |  | 856 |  |  | 689 |  |
| Acquisition step-up amortization |  | — |  |  | 282 |  |
| Acquisition/divestiture-related costs |  | 55 |  |  | 95 |  |
| Viessmann-related hedges |  | — |  |  | 86 |  |
| CCR gain |  | (7) |  |  | (318) |  |
| VCS pre-acquisition product replacement cost |  | 38 |  |  | — |  |
| Gain on liability adjustment |  | — |  |  | (46) |  |
| Adjusted operating profit |  | $ | 3,292 |  |  | $ | 3,542 |  |

[0001783180-26-000008:mdna:49]
Adjusted operating profit may not be comparable to similarly-titled measures used by other companies and should not be considered a substitute for Operating profit calculated in accordance with GAAP. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as a substitute for the related GAAP measure. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure.

[0001783180-26-000008:mdna:50]
Segment Review

[0001783180-26-000008:mdna:51]
We have four operating segments:

[0001783180-26-000008:mdna:52]
•Climate Solutions Americas provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers in North and South America while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-26-000008:mdna:53]
•Climate Solutions Europe provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers in Europe while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-26-000008:mdna:54]
•Climate Solutions Asia Pacific, Middle East & Africa provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers in Asia Pacific, the Middle East and Africa while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-26-000008:mdna:55]
•Climate Solutions Transportation includes global transport refrigeration and monitoring products, services and digital solutions for trucks, trailers, shipping containers, intermodal and rail.

[0001783180-26-000008:mdna:56]
Segment operating profit is the measure of profit and loss that our CODM uses to evaluate the financial performance of the business and as the basis for resource allocation, performance reviews and compensation. It represents operating profit (a GAAP measure) adjusted to exclude restructuring costs, amortization of acquired intangible assets and other significant items of a nonoperational nature.

[0001783180-26-000008:mdna:57]
38

[0001783180-26-000008:mdna:58]
Year Ended December 31, 2025 Compared with Year Ended December 31, 2024

[0001783180-26-000008:mdna:59]
Summary performance for each of our segments is as follows:

[0001783180-26-000008:mdna:60]
|  | Net sales |  | Segment operating profit |  | Segment operating profit margin |
| (In millions) | 2025 |  | 2024 |  |  |  |  |  | 2025 |  | 2024 |  |  |  |  |  | 2025 |  | 2024 |  |  |  |  |
| Climate Solutions Americas | $ | 10,470 |  |  | $ | 10,527 |  |  |  |  |  |  | $ | 2,150 |  |  | $ | 2,323 |  |  |  |  |  |  | 20.5 | % |  | 22.1 | % |  |  |  |  |
| Climate Solutions Europe | 5,044 |  |  | 4,984 |  |  |  |  |  |  | 444 |  |  | 469 |  |  |  |  |  |  | 8.8 | % |  | 9.4 | % |  |  |  |  |
| Climate Solutions Asia Pacific, Middle East & Africa | 3,339 |  |  | 3,500 |  |  |  |  |  |  | 448 |  |  | 466 |  |  |  |  |  |  | 13.4 | % |  | 13.3 | % |  |  |  |  |
| Climate Solutions Transportation | 2,894 |  |  | 3,475 |  |  |  |  |  |  | 452 |  |  | 485 |  |  |  |  |  |  | 15.6 | % |  | 14.0 | % |  |  |  |  |
| Total segment | $ | 21,747 |  |  | $ | 22,486 |  |  |  |  |  |  | $ | 3,494 |  |  | $ | 3,743 |  |  |  |  |  |  | 16.1 | % |  | 16.6 | % |  |  |  |  |

[0001783180-26-000008:mdna:61]
A reconciliation of Segment operating profit to Adjusted operating profit is as follows:

[0001783180-26-000008:mdna:62]
|  |  | For the Year Ended December 31, |
| (In millions) |  | 2025 |  | 2024 |
| Segment operating profit |  | $ | 3,494 |  |  | $ | 3,743 |  |
| Corporate and other |  | (202) |  |  | (201) |  |
| Adjusted operating profit |  | $ | 3,292 |  |  | $ | 3,542 |  |

[0001783180-26-000008:mdna:63]
Climate Solutions Americas

[0001783180-26-000008:mdna:64]
For the year ended December 31, 2025, Net sales were $10.5 billion, a 1% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-26-000008:mdna:65]
|  | Net sales |
| Organic / Operational | (1) | % |
| Foreign currency translation | — | % |
| Total % change | (1) | % |

[0001783180-26-000008:mdna:66]
The organic decrease in Net sales of 1% was driven by volume reductions within certain end-markets compared with the prior year. Lower volume in our residential business (down 9%) was primarily due to reduced end-market demand and distributor destocking. In addition, lower volume in our light commercial business (down 20%) further impacted segment results. These results were partially offset by growth in our commercial business (up 23%) primarily driven by ongoing customer demand and improved price.

[0001783180-26-000008:mdna:67]
For the year ended December 31, 2025, Segment operating profit was $2.2 billion, a 7% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-26-000008:mdna:68]
|  | Segment operating profit |
| Organic / Operational | (7) | % |
| Foreign currency translation | — | % |
| Total % change | (7) | % |

[0001783180-26-000008:mdna:69]
The operational profit decrease of 7% was primarily attributable to volume reductions in certain end-markets compared with prior year. In addition, lower earnings from equity method investments and higher selling, general and administrative expenses further impacted the segment. These results were partially offset by favorable productivity initiatives and product mix.

[0001783180-26-000008:mdna:70]
Climate Solutions Europe

[0001783180-26-000008:mdna:71]
For the year ended December 31, 2025, Net sales were $5.0 billion, a 1% increase compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-26-000008:mdna:72]
|  | Net sales |
| Organic / Operational | (3) | % |
| Foreign currency translation | 4 | % |
| Total % change | 1 | % |

[0001783180-26-000008:mdna:73]
The organic decrease in Net sales of 3% was driven by ongoing challenges in certain end-markets compared with the prior year. Results in our residential and light commercial business decreased (down 5%) due to lower volumes across the region as economic conditions, inflationary cost pressures and regulatory uncertainty impacted end-market demand. These results were partially offset by growth in our commercial business (up 2%) as a result of end-market demand and improved price.

[0001783180-26-000008:mdna:74]
For the year ended December 31, 2025, Segment operating profit was $444 million, a 5% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-26-000008:mdna:75]
|  | Segment operating profit |
| Organic / Operational | (8) | % |
| Foreign currency translation | 3 | % |
| Total % change | (5) | % |

[0001783180-26-000008:mdna:76]
The segment operational profit decrease of 8% was primarily attributable to volume reductions in certain end-markets compared with the prior year. In addition, unfavorable product mix and geographical mix further impacted the segment. These amounts were partially offset by favorable productivity initiatives, business integration synergies associated with the acquisition of the VCS Business and lower selling, general and administrative costs    .

[0001783180-26-000008:mdna:77]
Climate Solutions Asia Pacific, Middle East & Africa

[0001783180-26-000008:mdna:78]
For the year ended December 31, 2025, Net sales were $3.3 billion, a 5% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-26-000008:mdna:79]
|  | Net sales |
| Organic / Operational | (5) | % |
| Foreign currency translation | — | % |
| Total % change | (5) | % |

[0001783180-26-000008:mdna:80]
The organic decrease in Net sales of 5% was driven by volume reductions within certain end-markets compared with the prior year. Results in China decreased (down 12%) as residential end-markets experienced economic challenges impacting both demand and price. Commercial end-markets in China were flat compared with the prior year. These results were partially offset by ongoing end-market demand in a majority of the region's remaining geographies.

[0001783180-26-000008:mdna:81]
For the year ended December 31, 2025, Segment operating profit was $448 million, a 4% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-26-000008:mdna:82]
|  | Segment operating profit |
| Organic / Operational | (7) | % |
| Foreign currency translation | 3 | % |
| Total % change | (4) | % |

[0001783180-26-000008:mdna:83]
The segment operational profit decrease of (7)% was primarily attributable to volume reductions within certain end-markets compared with the prior year. In addition, unfavorable price and product mix further impacted segment results. These reductions were partially offset by favorable productivity initiatives, lower selling, general and administrative expenses and higher earnings from equity method investments.

[0001783180-26-000008:mdna:84]
Climate Solutions Transportation

[0001783180-26-000008:mdna:85]
For the year ended December 31, 2025, Net sales were $2.9 billion, a 17% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-26-000008:mdna:86]
|  | Net sales |
| Organic / Operational | 4 | % |
| Foreign currency translation | 1 | % |
| Acquisitions and divestitures, net | (22) | % |
| Total % change | (17) | % |

[0001783180-26-000008:mdna:87]
The organic increase in Net sales of 4% was primarily driven by volume growth within certain end-markets compared with the prior year. Container results increased (up 31%) due to ongoing end-market demand and improved price. These results were partially offset by our global truck and trailer business (down 3%) as lower end-market demand in Asia and Europe more than offset modest growth in North America.

[0001783180-26-000008:mdna:88]
On October 1, 2024, we divested CCR, a global supplier of turnkey solutions for commercial refrigeration systems and services. The results of CCR are excluded from our Consolidated Financial Statements subsequent to the divestiture date. The transaction is included in Acquisitions and divestitures, net as part of the year-over-year change.

[0001783180-26-000008:mdna:89]
For the year ended December 31, 2025, Segment operating profit was $452 million, a 7% decrease compared with the same period of 2024. The components of the year-over-year change were as follows:

[0001783180-26-000008:mdna:90]
|  | Segment operating profit |
| Organic / Operational | (7) | % |
| Foreign currency translation | 1 | % |
| Acquisitions and divestitures, net | (2) | % |
| Other | 1 | % |
| Total % change | (7) | % |

[0001783180-26-000008:mdna:91]
The segment decrease in operational profit of 7% was primarily driven by volume reductions in certain end-markets. In addition, costs associated with warranty-related issues further impacted the segment. These amounts were partially offset by favorable productivity initiatives, lower selling, general and administrative costs and higher volumes in certain end-markets. However, the higher volumes led to an unfavorable mix in the segment. Amounts reported in other represent a gain on the sale of equity method investments.

[0001783180-26-000008:mdna:92]
LIQUIDITY AND FINANCIAL CONDITION

[0001783180-26-000008:mdna:93]
We assess liquidity in terms of our ability to generate adequate amounts of cash necessary to fund our current and future cash requirements to support our business and strategic initiatives. In doing so, we review and analyze our cash on hand, working capital, debt service requirements and capital expenditures. We rely on operating cash flows as our primary source of liquidity. In addition, we have access to other sources of capital to finance our strategic initiatives and fund growth.

[0001783180-26-000008:mdna:94]
As of December 31, 2025, we had Cash and cash equivalents of $1.6 billion, of which approximately 94% was held by our foreign subsidiaries. We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which we can access funds held by foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection with contractual obligations related to acquisitions or divestitures or other legal obligations. As of December 31, 2025 and 2024, the amount of such restricted cash was $2 million and $3 million, respectively.

[0001783180-26-000008:mdna:95]
We continue to actively manage and strengthen our business portfolio to meet the current and future needs of our customers. This is accomplished through research and development activities with a focus on new product development and new technology innovation as well as sustaining activities with a focus on improving existing products and reducing production costs. We also pursue potential acquisitions to complement existing products and services to enhance our product portfolio. In addition, we routinely conduct discussions, evaluate targets and enter into agreements regarding possible acquisitions, divestitures, joint ventures and equity investments to manage our business portfolio.

[0001783180-26-000008:mdna:96]
We believe that our available cash and operating cash flows will be sufficient to meet our future operating cash needs. Our committed credit facilities and access to the debt and equity markets provide additional sources of short-term and long-term capital to fund current operations, debt maturities and future investment opportunities. Although we believe that the arrangements currently in place permit us to finance our operations on acceptable terms and conditions, our access to and the availability of financing on acceptable terms and conditions in the future will be impacted by many factors, including: (1) our credit ratings or absence of credit ratings; (2) the level of our existing indebtedness; (3) the restrictions under our debt agreements; (4) the liquidity of the overall capital markets and (5) the state of the economy. There can be no assurance that we will be able to obtain additional financing on terms favorable to us, if at all.

[0001783180-26-000008:mdna:97]
The following table contains several key measures of our financial condition and liquidity:

[0001783180-26-000008:mdna:98]
|  |  | As of December 31, |
| (In millions) |  | 2025 |  | 2024 |  |  |
| Cash and cash equivalents |  | $ | 1,555 |  |  | $ | 3,969 |  |  |  |
| Total debt |  | $ | 11,833 |  |  | $ | 12,362 |  |  |  |
| Total equity |  | $ | 14,128 |  |  | $ | 14,395 |  |  |  |
| Net debt (total debt less cash and cash equivalents) |  | $ | 10,278 |  |  | $ | 8,393 |  |  |  |
| Total capitalization (total debt plus total equity) |  | $ | 25,961 |  |  | $ | 26,757 |  |  |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | $ | 24,406 |  |  | $ | 22,788 |  |  |  |
| Total debt to total capitalization |  | 46 | % |  | 46 | % |  |  |
| Net debt to net capitalization |  | 42 | % |  | 37 | % |  |  |

[0001783180-26-000008:mdna:99]
Borrowings and Lines of Credit

[0001783180-26-000008:mdna:100]
We maintain a $2.0 billion USD-denominated facility and a $500 million Euro-denominated facility as part of an unsecured, unsubordinated commercial paper program which we can use for general corporate purposes, including the funding of working capital and potential acquisitions. In addition, we maintain a $2.5 billion revolving credit agreement with various banks (the "Revolving Credit Facility") that matures in December 2029 which supports our commercial paper borrowing program and can be used for general corporate purposes. A ratings-based commitment fee is charged on unused commitments. As of December 31, 2025, we had $325 million and zero borrowings outstanding under our commercial paper program and our Revolving Credit Facility, respectively.

[0001783180-26-000008:mdna:101]
Our short-term obligations primarily consist of current maturities of long-term debt. Our long-term obligations primarily consist of long-term notes with maturity dates ranging between 2027 and 2054. Interest payments related to long-term notes are expected to approximate $408 million per year, reflecting an approximate weighted-average interest rate of 3.7%. Any borrowings from the Revolving Credit Facility are subject to variable interest rates. See Note 7 - Borrowings and Lines of Credit in the accompanying Notes to the Consolidated Financial Statements for additional information regarding the terms of our long-term debt obligations.

[0001783180-26-000008:mdna:102]
42

[0001783180-26-000008:mdna:103]
Scheduled maturities of long-term debt, excluding amortization of discount, are as follows:

[0001783180-26-000008:mdna:104]
| (In millions) |  |  |  |
| 2026 |  | $ | 108 |  |  |
| 2027 |  | $ | 1,309 |  |  |
| 2028 |  | $ | 903 |  |  |
| 2029 |  | $ | 43 |  |  |
| 2030 |  | $ | 2,019 |  |  |
| Thereafter |  | $ | 7,169 |  |  |

[0001783180-26-000008:mdna:105]
Our credit ratings are periodically reviewed by the major independent debt-rating agencies. As of December 31, 2025, Standards & Poor's Global Inc. and Moody’s Investor Service Inc. have ratings on our debt set forth in the table below:

[0001783180-26-000008:mdna:106]
| Rating Agency | Long-term Rating | Short-term Rating |  | Outlook |
| Standards & Poor's Global Inc. | BBB+ | A2 |  | Stable |
| Moody's Investors Service Inc. | Baa1 | P-2 |  | Positive |

[0001783180-26-000008:mdna:107]
Portfolio Transformation

[0001783180-26-000008:mdna:108]
On June 2, 2024, we completed the divestiture of Access Solutions for cash proceeds of $5.0 billion. On July 1, 2024, we completed the divestiture of Industrial Fire for cash proceeds of $1.4 billion. On October 1, 2024, we completed the divestiture of CCR for cash proceeds of $679 million. On December 2, 2024, we completed the divestiture of the CRF Business for cash proceeds of $2.9 billion. Consistent with our capital allocation strategy, the net proceeds were to fund repayment of debt, investments in organic and inorganic growth initiatives and capital returns to shareowners as well as for general corporate purposes. Further, on December 16, 2025, we entered into a purchase agreement to sell our Riello business with expected gross proceeds of approximately $430 million, and the transaction is expected to close in the first half of 2026 and is subject to customary closing conditions and regulatory approvals.

[0001783180-26-000008:mdna:109]
Share Repurchase Program

[0001783180-26-000008:mdna:110]
We may purchase our outstanding common stock from time to time subject to market conditions and at our discretion. Repurchases occur in the open market or through one or more other public or private transactions pursuant to plans complying with Rules 10b5-1 and 10b-18 under the Exchange Act. Since the initial authorization in February 2021, the Company's Board of Directors authorized the repurchase of up to $12.1 billion of our outstanding common stock which includes a $5 billion increase approved in October 2025. As of December 31, 2025, the Company repurchased 114.9 million shares of common stock for an aggregate purchase price of $6.8 billion. As a result, the Company has approximately $5.3 billion remaining under the current authorization at December 31, 2025.

[0001783180-26-000008:mdna:111]
Dividends

[0001783180-26-000008:mdna:112]
We paid dividends on our common stock of $0.90 per share during the year ended December 31, 2025, totaling $772 million. On December 3, 2025, the Board of Directors declared a dividend of $0.24 per share payable on February 9, 2026, to shareowners of record at the close of business on January 20, 2026.

[0001783180-26-000008:mdna:113]
43

[0001783180-26-000008:mdna:114]
Discussion of Cash Flows

[0001783180-26-000008:mdna:115]
The following table reflects the major categories of cash flows for the following periods:

[0001783180-26-000008:mdna:116]
|  |  | For the Years Ended December 31, |
| (In millions) |  | 2025 |  | 2024 |  |  |
| Net cash provided by (used in): |  |  |  |  |  |  |
| Continuing operating activities |  | $ | 2,089 |  |  | $ | 1,571 |  |  |  |
| Continuing investing activities |  | (343) |  |  | (11,025) |  |  |  |
| Continuing financing activities |  | (4,672) |  |  | (4,611) |  |  |  |

[0001783180-26-000008:mdna:117]
Cash flows from continuing operating activities primarily represent inflows and outflows associated with our continuing operations. Primary activities include net earnings from continuing operations adjusted for non-cash transactions, working capital changes and changes in other assets and liabilities. The year-over-year increase in net cash provided by continuing operating activities was primarily driven by an increase in net earnings and distributions from equity method investments. In addition, cash conversion on long-term contracts further benefited operating cash flow. These increases were partially offset by changes in working capital balances compared with the prior period.

[0001783180-26-000008:mdna:118]
Cash flows from continuing investing activities primarily represent inflows and outflows associated with long-term assets. Primary activities include capital expenditures, acquisitions, divestitures and proceeds from the sale of fixed assets. During the year ended December 31, 2025, net cash used in continuing investing activities was $343 million. The primary driver of the outflow related to $392 million of capital expenditures offset by $105 million related to settlement of derivatives. During the year ended December 31, 2024, net cash used in continuing investing activities was $11 billion. The primary driver of the outflow related to the acquisition of the VCS Business, which totaled $10.8 billion, net of cash acquired. Additional investing outflows include $264 million related to settlement of derivatives and $519 million of capital expenditures. These outflows were partially offset by net proceeds of $634 million related to divestitures.

[0001783180-26-000008:mdna:119]
Cash flows from continuing financing activities primarily represent inflows and outflows associated with equity or borrowings. Primary activities include debt transactions, paying dividends to shareowners and the repurchase of our common stock. During the year ended December 31, 2025, net cash used in continuing financing activities was $4.7 billion. The primary driver of the outflow was related to repurchases of our common stock totaling $2.9 billion. In addition, we made long-term debt repayments of $1.2 billion and dividend payments of $772 million to our common shareowners. During the year ended December 31, 2024, net cash used in continuing financing activities was $4.6 billion. The primary driver of the outflow was due to repayments of long-term debt of $5.3 billion. In addition, we made payments totaling $1.9 billion to repurchase common stock and dividend payments of $670 million to our common shareowners. These outflows were partially offset by the proceeds of borrowings used to fund the cash portion of the acquisition of the VCS Business.

[0001783180-26-000008:mdna:120]
Summary of Other Sources and Uses of Cash

[0001783180-26-000008:mdna:121]
Rapid changes in legislation, regulations and government policies, including with respect to regulations intended to combat climate events, affect our operations and business in the countries, regions and localities in which we operate and sell our products. We are committed to comply with these regulations and to environmental stewardship. As a result, we have set goals to invest over $4 billion by 2030 to develop intelligent climate and energy solutions that reduce environmental impacts. In addition, to reach our goal to achieve carbon neutrality in our operations by 2030, we expect to incur capital expenditures for climate-related projects including upgrading our facilities, equipment and controls to optimize energy efficiency, transition our energy consumption from a dependency on fossil fuels to renewable energy and expanding the electrification of our fleet vehicles. See section entitled Environmental Goals under the headings "Other Matters Relating to Our Business as a Whole" for additional information.

[0001783180-26-000008:mdna:122]
We also have obligations related to environmental and asbestos matters, pension and post-retirement benefits and taxes. See Note 10 - Employee Benefit Plans, Note 17 - Income Taxes, and Note 23 - Commitments and Contingent Liabilities in the accompanying Notes to the Consolidated Financial Statements in this Annual Report for additional information.

[0001783180-26-000008:mdna:123]
CRITICAL ACCOUNTING ESTIMATES

[0001783180-26-000008:mdna:124]
Our financial statements are prepared in accordance with accounting principles generally accepted in the United States. The preparation of financial statements in conformity with those accounting principles requires management to use judgment in making estimates and assumptions based on the relevant information available at the end of each period. These estimates and assumptions have a significant effect on reported amounts of assets, liabilities, sales and expenses as well as the disclosure of contingent assets and liabilities because they result primarily from the need to make estimates and assumptions on matters that are inherently uncertain. Actual results could differ from management's estimates.

[0001783180-26-000008:mdna:125]
Business Combinations

[0001783180-26-000008:mdna:126]
In accordance with ASC 805, Business Combinations ("ASC 805"), acquisitions that meet the definition of a business are recorded using the acquisition method of accounting. We recognize and measure the identifiable assets acquired, liabilities assumed and any non-controlling interest as of the acquisition date at fair value. The valuation of intangible assets is determined by an income approach methodology, using assumptions such as projected future revenues, customer attrition rates, royalty rates, tax rates and discount rates. The excess, if any, of total consideration transferred in a business combination over the fair value of identifiable assets acquired, liabilities assumed and any non-controlling interest is recognized as goodwill. Costs incurred as a result of a business combination other than costs related to the issuance of debt or equity securities are recorded in the period the costs are incurred.

[0001783180-26-000008:mdna:127]
Goodwill

[0001783180-26-000008:mdna:128]
In accordance with the Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") 350, Intangibles - Goodwill and Other ("ASC 350"), goodwill is tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicates that the fair value of the reporting unit may be less than its carrying value.

[0001783180-26-000008:mdna:129]
ASC 350 provides entities with an option to perform a qualitative assessment (commonly referred to as “step zero”) to determine whether a quantitative analysis for impairment is necessary. In performing step zero for our impairment test, we are required to make assumptions and judgments, including but not limited to the following: the evaluation of macroeconomic conditions as related to our business, industry and market trends, and the overall future financial performance of our reporting units and future opportunities in the markets in which they operate. If impairment indicators are present after performing step zero, we would perform a quantitative impairment analysis to estimate fair value.

[0001783180-26-000008:mdna:130]
For our 2025 goodwill impairment tests, we elected to perform qualitative step zero assessments for all tests, except for our Climate Solutions Europe reporting unit, to determine if the fair values of our reporting units were below carrying value. This constitutes the entire Climate Solutions Europe segment. We considered macroeconomic factors including global economic growth, general macroeconomic trends for the markets in which our reporting units operate and the forecasted growth of the global industrial products industry. In addition to these macroeconomic factors, among other things, we considered the reporting units’ current results and forecasts, changes in the nature of each business, any significant legal, regulatory, contractual, political or other business climate factors, changes in the industry and competitive environment, changes in the composition or carrying value of net assets and any intention to sell or dispose of a reporting unit or a significant portion of a reporting unit. Based upon our qualitative analysis, we determined that our goodwill was not impaired.

[0001783180-26-000008:mdna:131]
For the remaining goodwill test, we elected to perform a quantitative test to determine if the fair value of our Climate Solutions Europe reporting unit was below carrying value. We utilized a discounted cash flow method under the income approach to estimate the fair value of the reporting unit. Key assumptions used in estimating future cash flows included the revenue growth rate, earnings before interest and income taxes margin, discount rate, and terminal growth rate, among others and explicitly addressed factors such as timing, growth and margins with due consideration given to forecasting, market and geographic risk. Upon completion of the test, the reporting unit had a fair value of approximately 14% above its carrying value. As a result, the test did not indicate any goodwill impairment. A significant increase in the discount rate, decrease in the long-term growth rate or substantial reductions in our end markets and volume assumptions could have a negative impact on the estimated fair value of this reporting unit.

[0001783180-26-000008:mdna:132]
Revenue Recognition from Contracts with Customers

[0001783180-26-000008:mdna:133]
Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of our performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally the time of shipment. The remaining portion of our performance obligations are recognized over time as the customer simultaneously obtains control as we perform work under a contract, or if the product being produced for the customer has no alternative use and we have a contractual right to payment.

[0001783180-26-000008:mdna:134]
A performance obligation is a distinct good, service or a bundle of goods and services promised in a contract. Some of our contracts with customers contain a single performance obligation, while others contain multiple performance obligations most commonly when a contract spans multiple phases of a product life-cycle such as production, installation, maintenance and support. We identify performance obligations at the inception of a contract and allocate the transaction price to each distinct performance obligation. Revenue is recognized when or as the performance obligation is satisfied. When there are multiple performance obligations within a contract, we allocate the transaction price to each performance obligation based on its relative stand-alone selling price.

[0001783180-26-000008:mdna:135]
We primarily generate revenue from the sale of products to customers and recognize revenue at a point in time when control transfers to the customer. Transfer of control is generally based on the shipping terms of the contract. In addition, we recognize revenue on an over-time basis on installation and service contracts. For over-time performance obligations requiring the installation of equipment, revenue is recognized using costs incurred to date relative to total estimated costs at completion to measure progress. Incurred costs represent work performed, which correspond with and best depict transfer of control to the customer. Contract costs include direct costs such as labor, materials and subcontractors’ costs and, where applicable, indirect costs.

[0001783180-26-000008:mdna:136]
The transaction price allocated to performance obligations reflects our expectations about the consideration we will be entitled to receive from a customer. We include variable consideration in the estimated transaction price when there is a basis to reasonably estimate the amount and when it is probable that a significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. In addition, we customarily offer our customers incentives to purchase products to ensure an adequate supply of our products in distribution channels. The principal incentive programs provide reimbursements to distributors for offering promotional pricing for products. We account for estimated incentive payments as a reduction in sales at the time a sale is recognized.

[0001783180-26-000008:mdna:137]
Income Taxes

[0001783180-26-000008:mdna:138]
We account for income taxes in accordance with ASC 740, Income Taxes ("ASC 740"). Deferred tax assets and liabilities are determined based on temporary differences between financial reporting and tax bases of assets and liabilities, applying enacted tax rates expected to be in effect for the year in which the differences are expected to reverse. We recognize future tax benefits to the extent that realizing these benefits is considered in our judgment to be more likely than not. For those jurisdictions where the expiration date of tax carryforwards or the projected operating results indicate that realization is not likely, a valuation allowance is provided. We review the realizability of our deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required and will adjust our estimate if significant events so dictate. To the extent that the ultimate results differ from our original or adjusted estimates, the effect will be recorded in the provision for income taxes in the period that the matter is finally resolved.

[0001783180-26-000008:mdna:139]
In the ordinary course of business, there is inherent uncertainty in quantifying our income tax positions. We assess our income tax positions and record tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. For those tax positions where it is more likely than not that a tax benefit will be sustained, we have recorded the largest amount of tax benefit with a greater than 50% likelihood of being realized upon ultimate settlement with a taxing authority that has full knowledge of all relevant information. For those income tax positions where it is not more likely than not that a tax benefit will be sustained, no tax benefit has been recognized in the Consolidated Financial Statements.

[0001783180-26-000008:mdna:140]
46

[0001783180-26-000008:mdna:141]
Contingent Liabilities

[0001783180-26-000008:mdna:142]
We are involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies ("ASC 450"), we record accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, we accrue the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. We are unable to predict the final outcome of these matters based on the information currently available. However, we do not believe that the resolution of any of these matters will have a material adverse effect upon our competitive position, results of operations, cash flows or financial condition.

[0001783180-26-000008:mdna:143]
As described in Note 23 – Commitments and Contingent Liabilities in the accompanying Notes to the Consolidated Financial Statements in this Annual Report, contractual, regulatory and other matters, including asbestos claims, may arise in the ordinary course of business that subject us to claims or litigation. We have recorded reserves in the consolidated financial statements related to these matters, which are developed using input derived from actuarial estimates and historical and anticipated experience depending on the nature of the reserve, and in certain instances in consultation with legal counsel, internal and external consultants and engineers. Subject to the uncertainties inherent in estimating future costs for these types of liabilities, we believe our estimated reserves are reasonable and do not believe the final determination of the liabilities with respect to these matters would have a material adverse effect upon our competitive position, results of operations, cash flows or financial condition. See the "Risk Factors" section in this Annual Report for additional information.

[0001783180-26-000008:mdna:144]
Recent Accounting Pronouncements

[0001783180-26-000008:mdna:145]
See Note 3 – Summary of Significant Accounting Policies in the accompanying Notes to the Consolidated Financial Statements in this Annual Report for a discussion of recent accounting pronouncements and their effect on our financial statements.
