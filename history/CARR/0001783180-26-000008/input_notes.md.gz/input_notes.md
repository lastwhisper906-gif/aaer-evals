# CARR notes — 0001783180-26-000008


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001783180-26-000008:notes:1]
Part III hereof incorporates by reference portions of the Registrant's definitive proxy statement related to its 2026 annual meeting of shareowners.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001783180-26-000008:notes:2]
Impact of cybersecurity risks on business strategy, results of operations or financial condition.

[0001783180-26-000008:notes:3]
As discussed under the “Risk Factors” heading in this Annual Report, our business has been and may again in the future be impacted by disruptions to our Technology infrastructure or our third-party providers’ Technology infrastructures from (among other causes) cybersecurity-based risks, including attacks (i) on our Technology infrastructure (ii) targeting the security, integrity and/or availability of hardware and software; (iii) exploiting weaknesses or vulnerabilities in products, or capturing information installed, stored or transmitted in our products (including after the purchase of those products and when they are installed into third-party products); and (iv) on facilities or similar infrastructure.

[0001783180-26-000008:notes:4]
Risk Management and strategy

[0001783180-26-000008:notes:5]
We mitigate cybersecurity risks (and other material risks) through our enterprise risk management (“ERM”) program, which is a company-wide effort, managed by senior executives and overseen by our Audit Committee and Board of Directors to identify, assess, manage, report and monitor material risks that may affect our ability to achieve our business objectives.

[0001783180-26-000008:notes:6]
In connection with the ERM process, cybersecurity risks, including those relating to risks posed by our use of third-party service providers, are assigned to cross-functional management committees responsible for identifying and classifying the cybersecurity risks in accordance with our ERM risk rating methodology, and developing and administering risk mitigation and incident response plans. These cross-functional management committees regularly meet to review current and emerging cybersecurity risks and maintain policies and procedures governing the evaluation and classification of such risks.

[0001783180-26-000008:notes:7]
Cybersecurity risks deemed to be critical are reviewed by a Critical Threat Committee, which is comprised of members of our senior leadership team including our Executive Vice President, Chief Financial & Strategy Officer; Senior Vice President, Chief Legal Officer; Senior Vice President, Chief Digital Officer; Senior Vice President, Operations; Senior Vice President, Engineering; and Vice President, Controller & Chief Accounting Officer. The Critical Threat Committee reviews the risk and mitigation plan with the applicable cross-functional management team and facilitates notification to the Audit Committee of emerging critical cybersecurity risks. The Audit Committee and the Board of Directors receive regular briefings on cybersecurity risks. See “Governance” below for further discussion of governance of our cybersecurity program.

[0001783180-26-000008:notes:8]
In the event of a cybersecurity incident, we maintain incident response plans to investigate, classify, respond to, and manage cybersecurity incidents that may compromise the availability or integrity of our information systems, network resources, or data. In accordance with the incident response plans, cross-functional management teams assess and assign a threat level to each cybersecurity incident. A cybersecurity incident (or incidents, if aggregated together) assigned a critical threat level is escalated to the Critical Threat Committee for review.

[0001783180-26-000008:notes:9]
To ensure that our employees are equipped to identify and mitigate material cybersecurity incidents and to empower them to help us maintain a secure environment for our operations and data assets, we utilize a multifaceted training approach aimed at fostering a culture of security awareness and responsibility among all employees. These tailored programs are designed and updated to address evolving threats and industry best practices. In addition to annual cybersecurity training for employees and contractors and simulated phishing email campaigns, our cybersecurity teams conduct tabletop exercises with our senior management team. Our cybersecurity teams also oversee a security assessment process that is used to screen our third-party service providers for cybersecurity vulnerabilities based on the level of inherent risk they pose to the company or our customers, based on factors including but not limited to the products or services they provide and their ability to access our information systems, network resources, or data.

[0001783180-26-000008:notes:10]
We engage and retain outside consultants and legal advisors and we are members of several cybersecurity industry groups to keep us apprised of emerging cybersecurity risks, defense and mitigation strategies and governance best practices. Many of our processes and procedures are independently audited and assessed on a periodic basis against leading international cybersecurity standards and programs. 
Cybersecurity threats are constantly evolving, are becoming more frequent and more sophisticated and are made by groups of individuals with a wide range of expertise and motives which increases the difficulty of detecting and successfully defending against them. However, to date, cybersecurity threats have not materially affected us, including our business, strategy, results of operations or financial condition.


## cyd:CybersecurityRiskRoleOfManagementTextBlock

[0001783180-26-000008:notes:11]
Our cybersecurity programs, including the cross-functional management committees described above are the responsibility of our Chief Information Security Officer. Day-to-day administration of the cybersecurity programs are led by our Chief Information Security Officer and Chief Product Security Officer who collectively possess significant experience related to cybersecurity issues in both the private and government sectors, and possess certifications including but not limited to Certified Information Systems Security Professional ("CISSP") and Certified Information Security Manager ("CISM").

[0001783180-26-000008:notes:12]
Cybersecurity risk oversight continues to remain a top priority for the Board of Directors. Although the Audit Committee maintains primary responsibility for oversight of cybersecurity risks through the ERM program, responsibility related to oversight of cybersecurity risks is also delegated to other committees in alignment with their focus charter responsibilities. For example, the Technology and Innovation and Governance Committees assist with the cybersecurity programs through their oversight of our technology, digital, and innovation strategies and product integrity program, respectively.
The Critical Threat Committee is also responsible for evaluating the materiality of a cybersecurity incident based on criteria that has been reviewed with the Board of Directors, and for determining whether there are disclosure obligations under applicable securities laws. In the event that the Critical Threat Committee determines that a critical cybersecurity incident (or incidents, if aggregated together) is deemed to be material, the Critical Threat Committee will brief the Board of Directors and oversee the disclosure process. For all critical cybersecurity incidents that are not deemed to be material, the Critical Threat Committee will notify the Chairman of the Board to determine whether the Board of Directors will be notified of the critical incident during the next regularly-scheduled cybersecurity update to the Audit Committee, or sooner as circumstances warrant.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-26-000008:notes:13]
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation (the "Company") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Viessmann, Toshiba, Automated Logic and Carrier Transicold, among others, that offer innovative heating, cooling and cold chain solutions to enhance the lives we live and the world we share. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into four segments: Climate Solutions Americas, Climate Solutions Europe, Climate Solutions Asia Pacific, Middle East & Africa and Climate Solutions Transportation.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-26-000008:notes:14]
BASIS OF PRESENTATION 
The accompanying Consolidated Financial Statements reflect the consolidated operations of the Company and have been prepared in accordance with U.S. Generally Accepted Accounting Principles ("GAAP") as defined by the Financial Accounting Standards Board ("FASB") within the FASB Accounting Standards Codification ("ASC"). Inter-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated.

[0001783180-26-000008:notes:15]
The accompanying Consolidated Financial Statements include all majority-owned subsidiaries of the Company. A non-controlling interest in a subsidiary is considered an ownership interest in a majority-owned subsidiary that is not attributable to the parent. The Company includes Non-controlling interest as a component of Total equity in the accompanying Consolidated Balance Sheet and the Non-controlling interest in subsidiaries' earnings from operations are presented as an adjustment to Earnings before income taxes used to arrive at Net earnings (loss) attributable to common shareowners in the accompanying Consolidated Statement of Operations. Partially-owned equity affiliates represent 20 to 50% ownership interests in investments where the Company demonstrates significant influence, but does not have a controlling financial interest. Partially-owned equity affiliates are accounted for under the equity method.

[0001783180-26-000008:notes:16]
Sale of Riello Business

[0001783180-26-000008:notes:17]
On December 16, 2025, the Company entered into a stock purchase agreement to sell its Riello business ("Riello") to Ariston Group with expected gross proceeds of approximately $430 million. Riello, predominantly reported in the Company's Climate Solutions Europe segment, is a leading international manufacturer that designs, produces and integrates a comprehensive portfolio of thermal solutions including burners, boilers, heat pumps, cooling systems and aftermarket services for residential, commercial and industrial applications, with a strong focus on energy efficiency, innovation and a global distribution network. As a result, the assets and liabilities of Riello are presented as held for sale in the accompanying Consolidated Balance Sheet as of December 31, 2025 and recorded at the lower of their carrying value or fair value less estimated cost to sell. See Note 20 - Divestitures for additional information.

[0001783180-26-000008:notes:18]
Portfolio Transformation

[0001783180-26-000008:notes:19]
On April 25, 2023, the Company announced that it entered into a Share Purchase Agreement (the “Agreement”) to acquire the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (“Viessmann”), a privately-held company. The acquisition was completed on January 2, 2024. As a result, the assets, liabilities and results of operations of the VCS Business are consolidated in the accompanying Consolidated Financial Statements as of the date of acquisition and reported primarily within the Company’s Climate Solutions Europe segment. See Note 19 - Acquisitions for additional information.

[0001783180-26-000008:notes:20]
During 2024, the Company divested its Commercial and Residential Fire ("CRF Business"), Access Solutions ("Access Solutions") and Industrial Fire ("Industrial Fire") businesses which were historically reported in its Fire & Security segment. The transactions represented a single disposal plan to separately divest multiple businesses over different reporting periods and met the criteria to be presented as discontinued operations in the accompanying Consolidated Statement of Operations and Consolidated Statement of Cash Flows. In addition, the Company also divested its Commercial Refrigeration business (“CCR”). CCR, which was historically reported in the Climate Solutions Transportation segment (previously named Refrigeration), did not meet the criteria to be presented as discontinued operations. See Note 20 - Divestitures for additional information.

[0001783180-26-000008:notes:21]
Segment Reorganization

[0001783180-26-000008:notes:22]
As a result of the Company's portfolio transformation, the Company revised its reportable segments during 2025 to better align the reporting structure with the Company's business strategy, resource allocation and performance assessment. Under the revised segment structure, the Company has three new regional heating, ventilating and air conditioning ("HVAC") operating segments. Combined with the Climate Solutions Transportation operating segment, the four operating segments also serve as the Company's reportable segments. This model is designed to create a simplified, more focused and customer-centric organization across the globe. Each segment reports through separate management teams which regularly review their operating results with the Company's Chief Operating Decision Maker (the "CODM") determined in accordance with applicable accounting guidance. In connection with the revised structure, the CODM changed the measure used to evaluate segment profitability from Operating profit to Segment operating profit. All prior period comparative information has been recast to reflect the revised segment structure. See Note 21 - Segment Financial Data for additional information.

[0001783180-26-000008:notes:23]
Deconsolidation of Kidde-Fenwal, Inc.

[0001783180-26-000008:notes:24]
On May 14, 2023, Kidde-Fenwal, Inc. ("KFI"), an indirect wholly-owned subsidiary of the Company, filed a petition for voluntary reorganization under Chapter 11 of the United States Bankruptcy Code ("Chapter 11") in the United States Bankruptcy Court for the District of Delaware. KFI, an industrial fire detection and suppression business historically reported in the Company's Fire & Security segment, filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware (the “Bankruptcy Court”) seeking relief under chapter 11 of the Bankruptcy Code. As of the petition date, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company's Consolidated Financial Statements.

[0001783180-26-000008:notes:25]
Separation from United Technologies
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date for the Distribution. In addition, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of December 31, 2025, only certain portions of the Tax Matters Agreement ("TMA") remain in effect.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001783180-26-000008:notes:26]
SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
A summary of significant accounting policies used in the preparation of the accompanying Consolidated Financial Statements is as follows:

[0001783180-26-000008:notes:27]
Use of Estimates. The preparation of the Consolidated Financial Statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements as well as the reported amounts of revenues and expenses during the reporting period. Estimates are based on several factors including the facts and circumstances available at the time the estimates are made, historical experience and various other assumptions that are believed to be reasonable under the circumstances. Actual results could differ from those estimates.

[0001783180-26-000008:notes:28]
Currency Translation. Assets and liabilities of non-U.S. subsidiaries, where the functional currency is not the U.S. dollar, have been translated at year-end exchange rates, and income and expense accounts have been translated using average exchange rates throughout the year. Adjustments resulting from the process of translating an entity’s financial statements into the U.S. dollar have been recorded in the equity section of the Consolidated Balance Sheet within Accumulated other comprehensive income (loss). Transactions that are denominated in a currency other than an entity’s functional currency are subject to changes in exchange rates with the resulting gains and losses recorded in Net earnings (loss).

[0001783180-26-000008:notes:29]
Cash and Cash Equivalents. Cash and cash equivalents include cash on hand, demand deposits and short-term cash investments that are highly liquid in nature and have original maturities of three months or less. On occasion, the Company is required to maintain restricted cash deposits with certain banks due to contractual or other legal obligations. Restricted cash of $2 million and $3 million is included in Other assets, current as of December 31, 2025 and 2024, respectively.

[0001783180-26-000008:notes:30]
Accounts Receivable. Accounts receivable consist of billed amounts owed for products shipped to or services performed for customers. Amounts are recorded net of an allowance for expected credit losses which represents the best estimate of probable loss inherent in the Company's accounts receivable portfolio. The allowance is determined using a combination of factors including a reserve based on the aging of the outstanding accounts receivable portfolio and the Company's historical credit loss experience with its end markets, customer base and products. In addition, the Company considers knowledge of specific customers, current market conditions as well as reasonable and supportable forecasts of future events and economic conditions. As of December 31, 2025 and 2024, the allowance for expected credit losses was $81 million and $97 million, respectively. These estimates and assumptions are reviewed periodically with the effects of changes, if any, reflected in the Consolidated Statement of Operations in the period that they are determined.

[0001783180-26-000008:notes:31]
Fixed Assets. Property, plant and equipment are stated at cost less accumulated depreciation. Assets placed in service are recorded at cost and depreciated using the straight-line method over the estimated useful life of the asset. Assets acquired in a business combination are recorded at fair value at the date of acquisition. Major expenditures for replacements and significant improvements that increase asset values and extend useful lives are capitalized. Repairs and maintenance expenditures that do not extend the useful life of an asset are charged to expense as incurred.

[0001783180-26-000008:notes:32]
Per ASC 360, Property, Plant and Equipment ("ASC 360"), the Company assesses the recoverability of the carrying value of its property, plant and equipment whenever events or changes in circumstances indicate that the carrying value of an asset group may not be recoverable. Recoverability is measured by a comparison of the carrying value of an asset group to the future net undiscounted cash flows expected to be generated by the asset group. If the undiscounted cash flows are less than the carrying value of the asset group, an impairment loss is recognized for the amount by which the carrying value of the asset group exceeds the fair value of the asset group.

[0001783180-26-000008:notes:33]
Equity Method Investments. Investments in which the Company has the ability to exercise significant influence, but does not control, are accounted for under the equity method of accounting and are presented on the Consolidated Balance Sheet. Under this method of accounting, the Company’s share of the net earnings or losses of the investee is presented within Operating profit on the Consolidated Statement of Operations since the activities of the investee are closely aligned with the operations of the Company. The Company evaluates its equity method investments whenever events or changes in circumstance indicate that the carrying values of such investments may be impaired. If a decline in the value of an equity method investment is determined to be other than temporary, a loss is recorded in earnings in the current period. Distributions received from equity method investees are presented in the Consolidated Statement of Cash Flows based on the cumulative earnings approach.

[0001783180-26-000008:notes:34]
Goodwill and Intangible Assets. The Company records goodwill as the excess of the purchase price over the fair value of the net assets acquired in a business combination. In accordance with ASC 350, Intangibles - Goodwill and Other ("ASC 350"), goodwill is tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicates that the fair value of the reporting unit may be less than its carrying value.

[0001783180-26-000008:notes:35]
Impairment of goodwill is assessed at the reporting unit level and begins with a qualitative assessment to determine whether it is more likely than not that the fair value of a reporting unit is less than its carrying value as a basis for determining whether it is necessary to perform the goodwill impairment test under ASC 350. For those reporting units that bypass or fail the qualitative assessment, the test compares the carrying value of the reporting unit to its estimated fair value. Fair value of a reporting unit is estimated using a discounted cash flow method under the income approach. The approach relies on estimates of future cash flows, revenue growth rates, earnings before interest and income taxes margins, discount rates, and terminal growth rates and explicitly addressed factors such as timing, growth and margins with due consideration given to forecasting, market and geographic risk. If the estimated fair value of a reporting unit exceeds its carrying value, goodwill of the reporting unit is not impaired. To the extent that the carrying value of the reporting unit exceeds its estimated fair value, an impairment loss will be recognized for the amount by which the reporting unit's carrying value exceeds its fair value, not to exceed the carrying value of goodwill in that reporting unit.

[0001783180-26-000008:notes:36]
Intangible assets such as patents, service contracts, monitoring lines and customer relationships with finite useful lives are amortized based on the pattern in which the economic benefits of the intangible assets are consumed. If a pattern of economic benefit cannot be reliably determined or if straight-line amortization approximates the pattern of economic benefit, a straight-line amortization may be used.

[0001783180-26-000008:notes:37]
The range of useful lives approximate the following (in years):

[0001783180-26-000008:notes:38]
| Customer relationships | 1 to 30 |
| Patents and trademarks | 5 to 40 |
| Technology and other | 1 to 50 |

[0001783180-26-000008:notes:39]
The Company assesses the recoverability of the carrying value of its intangible assets with finite useful lives whenever events or changes in circumstances indicate that the carrying value of the asset group may not be recoverable. Recoverability is measured by a comparison of the carrying value of an asset group to the future net undiscounted cash flows expected to be generated by the asset group. If the undiscounted cash flows are less than the carrying value of the asset group, an impairment loss is recognized for the amount by which the carrying value of the asset group exceeds the fair value of the asset group.

[0001783180-26-000008:notes:40]
Leases. The Company accounts for leases in accordance with ASC 842, Leases ("ASC 842"), which requires a lessee to record a right-of-use ("ROU") asset and a lease liability on the Consolidated Balance Sheet for all leases with terms longer than 12 months. ROU assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. The Company generally uses its incremental borrowing rate, which is based on information available at the lease commencement date, to determine the present value of lease payments except when an implicit interest rate is readily determinable. The lease term may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. The Company has elected not to recognize ROU assets and lease obligations for its short-term leases, which are defined as leases with an initial term of 12 months or less.

[0001783180-26-000008:notes:41]
Income Taxes. The Company accounts for income taxes in accordance with ASC 740, Income Taxes ("ASC 740"). Deferred tax assets and liabilities are determined based on temporary differences between financial reporting and tax bases of assets and liabilities, applying enacted tax rates expected to be in effect for the year in which the differences are expected to reverse. The Company recognizes future tax benefits to the extent that realizing these benefits is considered in its judgment to be more likely than not. For those jurisdictions where the expiration date of tax carryforwards or the projected operating results indicate that realization is not likely, a valuation allowance is provided. The Company reviews the realizability of its deferred tax asset valuation allowances on a quarterly basis, or whenever events or changes in circumstances indicate that a review is required and will adjust its estimate if significant events so dictate. To the extent that the ultimate results differ from the Company's original or adjusted estimates, the effect will be recorded in the provision for income taxes in the period that the matter is finally resolved.

[0001783180-26-000008:notes:42]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. For those tax positions where it is more likely than not that a tax benefit will be sustained, the Company has recorded the largest amount of tax benefit with a greater than 50% likelihood of being realized upon ultimate settlement with a taxing authority that has full knowledge of all relevant information. For those income tax positions where it is not more likely than not that a tax benefit will be sustained, no tax benefit has been recognized in the Consolidated Financial Statements.

[0001783180-26-000008:notes:43]
Pension and Post-retirement Obligations. The Company provides a range of benefit plans to eligible current and former employees. The Company accounts for its benefit plans in accordance with ASC 715, Compensation - Retirement Benefits ("ASC 715") which requires balance sheet recognition of the overfunded or underfunded status of pension and post-retirement benefit plans. Determining the amounts associated with these benefits are performed by actuaries and dependent on various actuarial assumptions including discount rates, expected return on plan assets, compensation increases, mortality and health care cost trends. Actual results may differ from the actuarial assumptions and are generally recorded in Accumulated other comprehensive income (loss) and amortized into Net earnings (loss) over future periods. The Company reviews its actuarial assumptions at each measurement date and makes modifications to the assumptions based on current rates and trends, if appropriate. See Note 10 – Employee Benefit Plans for additional information.

[0001783180-26-000008:notes:44]
Business Combinations. In accordance with ASC 805, Business Combinations ("ASC 805"), acquisitions that meet the definition of a business are recorded using the acquisition method of accounting. The Company recognizes and measures identifiable assets acquired, liabilities assumed and any non-controlling interest as of the acquisition date at fair value. The valuation of intangible assets is determined by an income approach methodology, using assumptions such as projected future revenues, customer attrition rates, royalty rates, tax rates and discount rates. The excess, if any, of total consideration transferred in a business combination over the fair value of identifiable assets acquired, liabilities assumed and any non-controlling interest is recognized as goodwill. Costs incurred as a result of a business combination other than costs related to the issuance of debt or equity securities are recorded in the period the costs are incurred.

[0001783180-26-000008:notes:45]
Asset Retirement Obligations. The Company records the fair value of legal obligations associated with the retirement of tangible long-lived assets in the period in which a liability is determined to exist, if a reasonable estimate of fair value can be made. Upon initial recognition of a liability, the Company capitalizes the cost of the asset retirement obligation by increasing the carrying value of the related long-lived asset. Over time, the liability is increased for changes in its present value and the capitalized cost is depreciated over the useful life of the related asset.

[0001783180-26-000008:notes:46]
Research and Development. The Company conducts research and development activities with a focus on new product development and technology innovation. These costs are charged to expense as incurred. For the years ended December 31, 2025, 2024 and 2023, these costs amounted to $625 million, $686 million and $493 million, respectively.

[0001783180-26-000008:notes:47]
Recent Pronouncements

[0001783180-26-000008:notes:48]
The FASB ASC is the sole source of authoritative GAAP other than United States Securities and Exchange Commission ("SEC') issued rules and regulations that apply only to SEC registrants. The FASB issues Accounting Standards Updates ("ASU") to communicate changes to the codification. The Company considers the applicability and impact of all ASUs. ASUs not referenced below were assessed and determined to be either not applicable or are not expected to have a material impact on the Consolidated Financial Statements.

[0001783180-26-000008:notes:49]
Recently Issued and Adopted Accounting Pronouncements

[0001783180-26-000008:notes:50]
In December 2023, the FASB issued ASU 2023-09, Income Taxes (Topic 740): Improvements to Income Tax Disclosures ("ASU 2023-09"), which requires public entities to disclose disaggregated information about their effective tax rate reconciliation as well as information on income taxes paid. ASU 2023-09 is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. The Company adopted ASU 2023-09 prospectively for the period ending December 31, 2025.

[0001783180-26-000008:notes:51]
In November 2024, the FASB issued ASU 2024-03, Disaggregation of Income Statement Expenses (DISE) ("ASU 2024-03"), which requires public entities to disclose disaggregated information about expenses by nature on an interim and annual basis. ASU 2024-03 is effective for fiscal years beginning after December 15, 2026 and interim periods within fiscal years beginning after December 15, 2027, with early adoption permitted. The Company is currently assessing the impact of this ASU on its financial statements.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001783180-26-000008:notes:52]
Identifiable intangible assets consisted of the following:

[0001783180-26-000008:notes:53]
|  |  |  | 2025 |  | 2024 |
| (In millions) |  |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Customer relationships |  |  | $ | 6,143 |  |  | $ | (1,573) |  |  | $ | 4,570 |  |  | $ | 5,607 |  |  | $ | (939) |  |  | $ | 4,668 |  |
| Patents and trademarks |  |  | 945 |  |  | (191) |  |  | 754 |  |  | 885 |  |  | (147) |  |  | 738 |  |
| Technology and other |  |  | 1,692 |  |  | (690) |  |  | 1,002 |  |  | 1,530 |  |  | (504) |  |  | 1,026 |  |
| Total intangible assets |  |  | $ | 8,780 |  |  | $ | (2,454) |  |  | $ | 6,326 |  |  | $ | 8,022 |  |  | $ | (1,590) |  |  | $ | 6,432 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001783180-26-000008:notes:54]
INVENTORIES, NET 
Inventories are stated at the lower of cost or estimated net realizable value. Cost is primarily determined based on the first-in, first-out inventory method ("FIFO") or average cost methods, which approximates current replacement cost. However, certain Carrier entities use the last-in, first-out inventory method ("LIFO").

[0001783180-26-000008:notes:55]
Inventories, net consisted of the following:

[0001783180-26-000008:notes:56]
| (In millions) | 2025 |  | 2024 |
| Raw materials | $ | 666 |  |  | $ | 625 |  |
| Work-in-process | 245 |  |  | 213 |  |
| Finished goods | 1,572 |  |  | 1,461 |  |
| Inventories, net | $ | 2,483 |  |  | $ | 2,299 |  |

[0001783180-26-000008:notes:57]
The Company performs periodic assessments utilizing customer demand, production requirements and historical usage rates to determine the existence of excess and obsolete inventory and records necessary provisions to reduce such inventories to the lower of cost or estimated net realizable value. Raw materials, work-in-process and finished goods are net of valuation reserves of $337 million and $215 million as of December 31, 2025 and 2024, respectively.

[0001783180-26-000008:notes:58]
Certain entities use LIFO to determine the cost of inventory. If inventories that were valued using the LIFO method had been valued under the FIFO method, the net book value of the inventories would have been higher by $289 million and $238 million as of December 31, 2025 and 2024, respectively. As of December 31, 2025 and 2024, approximately 36% and 39%, respectively, of all inventory utilized the LIFO method.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001783180-26-000008:notes:59]
FIXED ASSETS, NET 
Fixed assets, net consisted of the following:

[0001783180-26-000008:notes:60]
| (In millions) | Estimated Useful Lives (Years) |  | 2025 |  | 2024 |
| Land |  |  | $ | 165 |  |  | $ | 169 |  |
| Buildings and improvements | 20 to 40 |  | 1,535 |  |  | 1,325 |  |
| Machinery, tools and equipment | 3 to 25 |  | 3,344 |  |  | 2,947 |  |
| Rental assets | 3 to 12 |  | 351 |  |  | 355 |  |
| Other, including assets under construction |  |  | 613 |  |  | 715 |  |
| Fixed assets, gross |  |  | 6,008 |  |  | 5,511 |  |
| Accumulated depreciation |  |  | (2,843) |  |  | (2,512) |  |
| Fixed assets, net |  |  | $ | 3,165 |  |  | $ | 2,999 |  |

[0001783180-26-000008:notes:61]
Depreciation expense was $383 million, $385 million and $270 million for the years ended December 31, 2025, 2024 and 2023, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-26-000008:notes:62]
GOODWILL AND INTANGIBLE ASSETS 
The Company records goodwill as the excess of the purchase price over the fair value of the net assets acquired in a business combination. Goodwill is tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicates that the fair value of the reporting unit may be less than its carrying value.

[0001783180-26-000008:notes:63]
The changes in the carrying value of goodwill were as follows:

[0001783180-26-000008:notes:64]
| (In millions) |  | Climate Solutions Americas |  | Climate Solutions Europe |  | Climate Solutions Asia Pacific, Middle East & Africa |  | Climate Solutions Transportation |  | Total |
| Balance at December 31, 2023 |  | $ | 4,543 |  |  | $ | 703 |  |  | $ | 1,237 |  |  | $ | 1,037 |  |  | $ | 7,520 |  |
| Goodwill resulting from business combinations (1) |  | 526 |  |  | 6,861 |  |  | 235 |  |  | 33 |  |  | 7,655 |  |
| Foreign currency translation |  | (10) |  |  | (529) |  |  | (92) |  |  | 57 |  |  | (574) |  |
| Balance at December 31, 2024 |  | $ | 5,059 |  |  | $ | 7,035 |  |  | $ | 1,380 |  |  | $ | 1,127 |  |  | $ | 14,601 |  |
| Goodwill resulting from business combinations (1) |  | 12 |  |  | 3 |  |  | 6 |  |  | 44 |  |  | 65 |  |
| Reclassified to held for sale (2) |  | — |  |  | (175) |  |  | — |  |  | — |  |  | (175) |  |
| Foreign currency translation |  | 4 |  |  | 945 |  |  | 24 |  |  | 37 |  |  | 1,010 |  |
| Balance as of December 31, 2025 |  | $ | 5,075 |  |  | $ | 7,808 |  |  | $ | 1,410 |  |  | $ | 1,208 |  |  | $ | 15,501 |  |

[0001783180-26-000008:notes:65]
(1) See Note 19 - Acquisitions for additional information.

[0001783180-26-000008:notes:66]
(2) See Note 20 - Divestitures for additional information.

[0001783180-26-000008:notes:67]
Amortization of intangible assets was $884 million, $843 million and $221 million for the years ended December 31, 2025, 2024 and 2023, respectively.

[0001783180-26-000008:notes:68]
The estimated future amortization of intangible assets is as follows:

[0001783180-26-000008:notes:69]
| (In millions) | 2026 |  | 2027 |  | 2028 |  | 2029 |  | 2030 |  | Thereafter |
| Future amortization | $ | 868 |  |  | $ | 818 |  |  | $ | 742 |  |  | $ | 655 |  |  | $ | 599 |  |  | $ | 2,644 |  |

[0001783180-26-000008:notes:70]
Impairment Test

[0001783180-26-000008:notes:71]
In connection with its revised segment structure, the Company performed a quantitative goodwill impairment test on its reporting units prior to the reorganization to determine if any impairment existed. The tests did not indicate any goodwill impairment. The Company then reassigned goodwill among its new reporting units using a relative fair value approach. Based on these analyses, the Climate Solutions Europe reporting unit had a fair value of 10% above its carrying value. This constitutes the entire Climate Solutions Europe segment. All other reporting units had fair values substantially in excess of their carrying values.

[0001783180-26-000008:notes:72]
The Company tested its goodwill for impairment on July 1 as part of its annual assessment. For each test, except the Climate Solutions Europe reporting unit, the Company qualitatively assessed all relevant events or circumstances that could impact the estimate of fair value and determined the fair value of each reporting unit substantially exceeded their carrying value. For the remaining test, the Company's Climate Solutions Europe reporting unit, the Company performed a quantitative goodwill impairment test to determine if any impairment existed. Upon completion of the test, the reporting unit had a fair value of approximately 14% above its carrying value. Key assumptions used in estimating future cash flows included the revenue growth rate, earnings before interest and income taxes margin, discount rate, and terminal growth rate, among others. As a result, the test did not indicate any goodwill impairment.


## us-gaap:DebtDisclosureTextBlock

[0001783180-26-000008:notes:73]
BORROWINGS AND LINES OF CREDIT 
Short-term borrowings and current portion of long-term debt consisted of the following:

[0001783180-26-000008:notes:74]
| (In millions) |  | 2025 |  | 2024 |
| Commercial paper |  | $ | 325 |  |  | $ | — |  |
| Short-term borrowings |  | 35 |  |  | 84 |  |
| Current portion of long-term debt |  | 108 |  |  | 1,252 |  |
| Short-term borrowings and current portion of long-term debt |  | $ | 468 |  |  | $ | 1,336 |  |

[0001783180-26-000008:notes:75]
Commercial Paper Program

[0001783180-26-000008:notes:76]
The Company has a $2.0 billion USD-denominated facility and a $500 million Euro-denominated facility as part of an unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of December 31, 2025, the Company had $325 million outstanding under its USD-denominated commercial paper facility, with a weighted average rate of 3.98%.

[0001783180-26-000008:notes:77]
Long-term debt consisted of the following:

[0001783180-26-000008:notes:78]
| (In millions) |  | 2025 |  | 2024 |
| 2.242% Notes due 2025 (1) |  | $ | — |  |  | $ | 1,200 |  |
| 2.493% Notes due 2027 |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  | 883 |  |  | 783 |  |
| 2.722% Notes due 2030 |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  | 1,001 |  |  | 887 |  |
| 5.900% Notes due 2034 |  | 875 |  |  | 875 |  |
| 3.625% Notes due 2037 |  | 883 |  |  | 783 |  |
| 3.377% Notes due 2040 |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  | 1,400 |  |  | 1,400 |  |
| 6.200% Notes due 2054 |  | 650 |  |  | 650 |  |
| Total long-term notes |  | 10,842 |  |  | 11,728 |  |
| Japanese Term Loan Facility |  | 345 |  |  | 342 |  |
| Other debt (including project financing obligations and finance leases) |  | 364 |  |  | 296 |  |
| Discounts and debt issuance costs |  | (78) |  |  | (88) |  |
| Total long-term debt |  | 11,473 |  |  | 12,278 |  |
| Less: current portion of long-term debt |  | 108 |  |  | 1,252 |  |
| Long-term debt, net of current portion |  | $ | 11,365 |  |  | $ | 11,026 |  |

[0001783180-26-000008:notes:79]
(1) 2.242% Notes due February 15, 2025; repaid during February 2025.

[0001783180-26-000008:notes:80]
Revolving Credit Facility

[0001783180-26-000008:notes:81]
On December 20, 2024, the Company entered into a revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.5 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in December 2029 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings can bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. In addition, the Company capitalized $11 million of deferred financing costs which are being amortized over the term of the facility. As of December 31, 2025, there were no borrowings outstanding under the Revolving Credit Facility.

[0001783180-26-000008:notes:82]
Project Financing Arrangements

[0001783180-26-000008:notes:83]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $34 million and $53 million of debt during the year ended December 31, 2025 and 2024, respectively. Long-term debt repayments associated with these financing arrangements for the years ended December 31, 2025 and 2024, were zero and $14 million, respectively.

[0001783180-26-000008:notes:84]
Debt Covenants

[0001783180-26-000008:notes:85]
The Revolving Credit Facility, the indenture for the long-term notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of December 31, 2025, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

[0001783180-26-000008:notes:86]
Tender Offers

[0001783180-26-000008:notes:87]
In July 2024, the Company commenced tender offers to purchase up to $800 million ("Aggregate Tender Cap") aggregate purchase price of certain tranches of the Company's notes. The tender offers included payment of applicable accrued and unpaid interest up to the settlement date, along with a fixed spread for early repayment. Based on several factors, the Company elected to increase the Aggregate Tender Cap and settle the tender offers early. The aggregate principal amount tendered and accepted was approximately $1.1 billion, which included $125 million of notes due 2034, $350 million of notes due 2054 and approximately $600 million of notes due 2050. Upon settlement, the Company recognized a net gain of $97 million and wrote off $11 million of unamortized deferred financing costs within Interest (expense) income, net on the accompanying Consolidated Statement of Operations.

[0001783180-26-000008:notes:88]
Schedule of Long-term Debt Maturities

[0001783180-26-000008:notes:89]
Scheduled maturities of long-term debt, excluding amortization of discount, are as follows:

[0001783180-26-000008:notes:90]
| (In millions) |  |  |
| 2026 |  | $ | 108 |  |
| 2027 |  | $ | 1,309 |  |
| 2028 |  | $ | 903 |  |
| 2029 |  | $ | 43 |  |
| 2030 |  | $ | 2,019 |  |
| Thereafter |  | $ | 7,169 |  |

[0001783180-26-000008:notes:91]
As of December 31, 2025, the average maturity of the Company's long-term notes is approximately 10 years and the weighted-average interest rate on its total borrowings is approximately 3.7%. Interest expense associated with long-term debt for the years ended December 31, 2025, 2024 and 2023 was $458 million, $580 million and $306 million, respectively.


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-26-000008:notes:92]
FAIR VALUE MEASUREMENTS
ASC 820, Fair Value Measurement ("ASC 820"), defines fair value as the price that would be received if an asset is sold or the price paid to transfer a liability in an orderly transaction between market participants at the measurement date. ASC 820 also establishes a three-level fair value hierarchy that prioritizes information used in developing assumptions when pricing an asset or liability as follows:

[0001783180-26-000008:notes:93]
•Level 1: Observable inputs such as quoted prices in active markets;

[0001783180-26-000008:notes:94]
•Level 2: Inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and

[0001783180-26-000008:notes:95]
•Level 3: Unobservable inputs where there is little or no market data, which requires the reporting entity to develop its own assumptions.

[0001783180-26-000008:notes:96]
ASC 820 requires the use of observable market data, when available, in making fair value measurements. When inputs used to measure fair value fall within different levels of the hierarchy, the level within which the fair value measurement is categorized is based on the lowest level input that is significant to the fair value measurement.

[0001783180-26-000008:notes:97]
In the normal course of business, the Company is exposed to certain risks arising from business operations and economic factors, including foreign currency and commodity price risk. These exposures are managed through operational strategies and the use of undesignated hedging contracts. The Company's derivative assets and liabilities are measured at fair value on a recurring basis using internal models based on observable market inputs, such as forward, interest, contract and discount rates with changes in fair value reported in Other income (expense), net in the accompanying Consolidated Statement of Operations.

[0001783180-26-000008:notes:98]
The Company enters into external cross currency swaps in order to manage foreign currency translation risk on assets denominated in a functional currency other than the U.S. Dollar. The swaps have an aggregate notional amount of $3.1 billion and are measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates. The Company designates the cross currency swaps as a partial hedge of its investment in certain subsidiaries whose functional currency is not the U.S. Dollar. As a result, changes in the fair value of the swaps are recorded in Equity in the accompanying Consolidated Balance Sheet.

[0001783180-26-000008:notes:99]
During 2023, the Company entered into several interest rate swap contracts to mitigate interest rate exposure on the forecasted issuance of long-term debt. The contracts had an aggregate notional amount of $1.5 billion and were designated as cash flow hedges with changes in fair value reported in Equity in the accompanying Consolidated Balance Sheet. Fair value was measured on a recurring basis using observable market inputs, such as forward, discount and interest rates. In November 2023, the contracts were settled upon the issuance of the underlying debt. As a result, the Company deferred a net unrecognized gain of $58 million in Equity which will be subsequently recognized in Interest expense over the term of the related notes which range from 2034 to 2044. The amount expected to be amortized during 2026 is a net gain of $4 million.

[0001783180-26-000008:notes:100]
In connection with the acquisition of the VCS Business, the Company entered into window forward contracts with Bank of America N.A. and JPMorgan Chase Bank N.A. to mitigate the foreign currency risk of the expected cash outflows associated with the Euro-denominated purchase price. The instruments have an aggregate notional amount of €7 billion and are measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates with changes in fair value reported in Other income (expense), net in the accompanying Consolidated Statement of Operations. During the year ended December 31, 2023, the Company recognized a $96 million loss on the mark-to-market valuation of its window forward contracts. The Company settled the window forward contracts on January 2, 2024, upon the acquisition of the VCS Business and recognized an additional $86 million loss.

[0001783180-26-000008:notes:101]
The following tables provide the valuation hierarchy classification of assets and liabilities that are recorded at fair value and measured on a recurring basis in the accompanying Consolidated Balance Sheet:

[0001783180-26-000008:notes:102]
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| December 31, 2025 |  |  |  |  |  |  |  |  |
| Fair value measurement: |  |  |  |  |  |  |  |  |
| Derivative assets (1) |  | $ | 129 |  |  | $ | — |  |  | $ | 129 |  |  | $ | — |  |
| Derivative liabilities (2) |  | $ | (166) |  |  | $ | — |  |  | $ | (166) |  |  | $ | — |  |
| December 31, 2024 |  |  |  |  |  |  |  |  |
| Fair value measurement: |  |  |  |  |  |  |  |  |
| Derivative assets (1) |  | $ | 82 |  |  | $ | — |  |  | $ | 82 |  |  | $ | — |  |
| Derivative liabilities (2) |  | $ | (41) |  |  | $ | — |  |  | $ | (41) |  |  | $ | — |  |

[0001783180-26-000008:notes:103]
(1) Included in Other assets, current and Other assets on the accompanying Consolidated Balance Sheet.

[0001783180-26-000008:notes:104]
(2) Included in Accrued liabilities and Other long-term liabilities on the accompanying Consolidated Balance Sheet.

[0001783180-26-000008:notes:105]
The following table provides the carrying values and fair values of the Company's long-term notes that are not recorded at fair value in the accompanying Consolidated Balance Sheet:

[0001783180-26-000008:notes:106]
|  |  | 2025 |  | 2024 |
| (In millions) |  | CarryingValue |  | FairValue |  | CarryingValue |  | FairValue |
| Total long-term notes (1) |  | $ | 10,842 |  |  | $ | 10,167 |  |  | $ | 11,728 |  |  | $ | 10,798 |  |

[0001783180-26-000008:notes:107]
(1) Excludes debt discount and issuance costs.

[0001783180-26-000008:notes:108]
The fair value of the Company's long-term debt is measured based on observable market inputs which are considered Level 1 within the fair value hierarchy. The carrying value of cash and cash equivalents, accounts receivable, accounts payable and short-term borrowings approximate fair value due to the short-term nature of these accounts and would be classified as Level 1 in the fair value hierarchy. The Company's financing leases and project financing obligations, included in Long-term debt and Current portion of long-term debt on the accompanying Consolidated Balance Sheet, approximate fair value and are classified as Level 3 in the fair value hierarchy.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001783180-26-000008:notes:109]
LEASES 
The Company enters into operating and finance leases for the use of real estate, vehicles, information technology equipment and certain other equipment. At contract inception, the Company determines a lease exists if the arrangement conveys the right to control an identified asset for a period of time in exchange for consideration. Control is considered to exist when the lessee has the right to obtain substantially all of the economic benefits from the use of an identified asset as well as the right to direct the use of that asset. If a contract is considered to be a lease, the Company recognizes a lease liability based on the present value of the future lease payments with an offsetting entry to recognize a right-of-use asset.

[0001783180-26-000008:notes:110]
Operating lease right-of-use assets and liabilities are reflected on the Consolidated Balance Sheet as follows:

[0001783180-26-000008:notes:111]
| (In millions) |  | 2025 |  | 2024 |
| Operating lease right-of-use assets |  | $ | 546 |  |  | $ | 554 |  |
| Accrued liabilities |  | $ | (142) |  |  | $ | (135) |  |
| Operating lease liabilities |  | (418) |  |  | (432) |  |
| Total operating lease liabilities |  | $ | (560) |  |  | $ | (567) |  |
| Weighted-Average Remaining Lease Term (in years) |  | 6.4 |  | 6.8 |
| Weighted-Average Discount Rate |  | 4.6 | % |  | 4.5 | % |

[0001783180-26-000008:notes:112]
Where applicable, the Company accounts for each separate lease component of a contract and its associated non-lease component as a single lease component.

[0001783180-26-000008:notes:113]
Supplemental cash flow and lease expense information related to operating leases were as follows:

[0001783180-26-000008:notes:114]
| (In millions) |  | 2025 |  | 2024 |  | 2023 |
| Operating cash flows for measurement of operating lease liabilities |  | $ | 179 |  |  | $ | 173 |  |  | $ | 135 |  |
| Operating lease ROU assets obtained in exchange for operating lease obligations |  | $ | 100 |  |  | $ | 112 |  |  | $ | 50 |  |
| Operating lease expense |  | $ | 184 |  |  | $ | 175 |  |  | $ | 127 |  |

[0001783180-26-000008:notes:115]
Operating lease expense is recognized on a straight-line basis over the lease term. In addition, the Company has certain leases that contain variable lease payments which are based on an index, a rate referenced in the lease or on the actual usage of the leased asset. These payments are not included in the right-of-use asset or lease liability and are expensed as incurred as variable lease expense.

[0001783180-26-000008:notes:116]
Undiscounted maturities of operating lease liabilities as of December 31, 2025, are as follows:

[0001783180-26-000008:notes:117]
| (In millions) |  |  |
| 2026 |  | $ | 163 |  |
| 2027 |  | 124 |  |
| 2028 |  | 95 |  |
| 2029 |  | 70 |  |
| 2030 |  | 50 |  |
| Thereafter |  | 147 |  |
| Total undiscounted lease payments |  | 649 |  |
| Less: imputed interest |  | (89) |  |
| Total discounted lease payments |  | $ | 560 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-26-000008:notes:118]
EMPLOYEE BENEFIT PLANS 
The Company sponsors U.S. and international defined benefit pension and defined contribution plans. In addition, the Company contributes to various U.S. and international multi-employer defined benefit pension plans.

[0001783180-26-000008:notes:119]
Pension Plans

[0001783180-26-000008:notes:120]
Qualified U.S. pension plan benefits covering collectively bargained employees comprise approximately 37% of the projected benefit obligation. This noncontributory defined benefit plan provides benefits on a flat dollar formula based on an employee's location and is closed to new entrants. The non-U.S. plans comprise approximately 63% of the projected benefit obligation; certain of these plans provide participants with one-time payments upon separation of employment rather than a retirement annuity. The plans' benefits are based on plan specific parameters. Non-qualified U.S. pension plans provide supplementary retirement benefits to certain employees and are not a material component of the projected benefit obligation.

[0001783180-26-000008:notes:121]
The following table details information regarding the Company's pension plans:

[0001783180-26-000008:notes:122]
| (In millions) | 2025 |  | 2024 |
| Change in Benefit Obligation |  |  |  |
| Benefit obligation at beginning of year | $ | 657 |  |  | $ | 575 |  |
| Service cost | 13 |  |  | 14 |  |
| Interest cost | 28 |  |  | 26 |  |
| Actuarial (gain) loss | (14) |  |  | (9) |  |
| Benefits paid | (19) |  |  | (24) |  |
| Curtailment, settlements and special termination benefits | (39) |  |  | (13) |  |
| Other, including expenses paid | 37 |  |  | (25) |  |
| Acquisitions (2) | — |  |  | 113 |  |
| Benefit obligation at end of year | $ | 663 |  |  | $ | 657 |  |
| Change in Plan Assets |  |  |  |
| Fair value at beginning of year | $ | 507 |  |  | $ | 468 |  |
| Actual return on plan assets | 38 |  |  | 1 |  |
| Company contributions | 36 |  |  | 34 |  |
| Benefits paid | (19) |  |  | (24) |  |
| Settlements | (46) |  |  | (13) |  |
| Other, including expenses paid | 24 |  |  | (15) |  |
| Acquisitions (2) | — |  |  | 56 |  |
| Fair value of assets end of year | $ | 540 |  |  | $ | 507 |  |
| Funded status of plans | $ | (123) |  |  | $ | (150) |  |
| Amounts included in the balance sheet: |  |  |  |
| Other non-current assets | $ | 56 |  |  | $ | 43 |  |
| Accrued compensation and benefits | (14) |  |  | (13) |  |
| Post-employment and other benefit liabilities | (165) |  |  | (180) |  |
| Net amount recognized | $ | (123) |  |  | $ | (150) |  |

[0001783180-26-000008:notes:123]
(1) See Note 20 - Divestitures for additional information.

[0001783180-26-000008:notes:124]
(2) See Note 19 - Acquisitions for additional information.

[0001783180-26-000008:notes:125]
The funded status improved primarily due to favorable returns on plan assets. In addition, higher employer contributions related to restructuring activities and increases in discount rates that reduced benefit obligations contributed to the improvement. These factors were partially offset by curtailment losses and unfavorable foreign currency movements.

[0001783180-26-000008:notes:126]
The pretax amounts recognized in Accumulated other comprehensive (income) loss are:

[0001783180-26-000008:notes:127]
| (In millions) |  | Prior Service Cost (Benefit) |  | Net Actuarial (Gain) Loss |  | Total |
| As of December 31, 2024 |  | $ | 4 |  |  | $ | 130 |  |  | $ | 134 |  |
| Current year changes recorded in AOCI |  | — |  |  | (12) |  |  | (12) |  |
| Amortization reclassified to earnings |  | (1) |  |  | (2) |  |  | (3) |  |
| Settlement/curtailment reclassified to earnings |  | (2) |  |  | (10) |  |  | (12) |  |
| Currency translation and other |  | — |  |  | 8 |  |  | 8 |  |
| As of December 31, 2025 |  | $ | 1 |  |  | $ | 114 |  |  | $ | 115 |  |

[0001783180-26-000008:notes:128]
Information for pension plans with accumulated benefit obligations in excess of plan assets:

[0001783180-26-000008:notes:129]
| (In millions) | 2025 |  | 2024 |
| Projected benefit obligation | $ | 255 |  |  | $ | 481 |  |
| Accumulated benefit obligation | $ | 232 |  |  | $ | 456 |  |
| Fair value of plan assets | $ | 76 |  |  | $ | 288 |  |

[0001783180-26-000008:notes:130]
Information for pension plans with projected benefit obligations in excess of plan assets:

[0001783180-26-000008:notes:131]
The accumulated benefit obligation for all defined benefit plans was $639 million and $631 million as of December 31, 2025 and 2024, respectively.

[0001783180-26-000008:notes:132]
Pension benefit payments, including amounts to be paid from corporate assets, and reflecting expected future service, as appropriate, are expected to be paid as follows:

[0001783180-26-000008:notes:133]
| (In millions) |  |
| 2026 | $ | 39 |  |
| 2027 | $ | 48 |  |
| 2028 | $ | 45 |  |
| 2029 | $ | 47 |  |
| 2030 | $ | 48 |  |
| 2031 through 2035 | $ | 251 |  |

[0001783180-26-000008:notes:134]
For the years ended December 31, 2025, 2024 and 2023, the Company made $36 million, $34 million and $33 million, respectively, of cash contributions to its defined benefit pension plans. The Company expects to make required funding contributions of approximately $5 million to its defined benefit pension plans in 2026.

[0001783180-26-000008:notes:135]
The components of net periodic pension expense (benefit) for the defined benefit pension plans are as follows:

[0001783180-26-000008:notes:136]
| (In millions) | 2025 |  | 2024 |  | 2023 |  |  |  |  |
| Service cost | $ | 13 |  |  | $ | 14 |  |  | $ | 15 |  |  |  |  |  |
| Interest cost | 28 |  |  | 26 |  |  | 31 |  |  |  |  |  |
| Expected return on plan assets | (33) |  |  | (36) |  |  | (32) |  |  |  |  |  |
| Amortization of prior service cost | 1 |  |  | 1 |  |  | 3 |  |  |  |  |  |
| Recognized actuarial net loss | 2 |  |  | 1 |  |  | (2) |  |  |  |  |  |
| Net settlement, curtailment and special termination benefit loss | 12 |  |  | 4 |  |  | 1 |  |  |  |  |  |
| Net periodic pension expense (benefit) | $ | 23 |  |  | $ | 10 |  |  | $ | 16 |  |  |  |  |  |

[0001783180-26-000008:notes:137]
Major assumptions used in determining the benefit obligation and net cost for pension plans are presented in the following table as weighted-averages:

[0001783180-26-000008:notes:138]
|  |  | Benefit Obligation |  | Net Costs |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |  | 2023 |  |
| Discount rate |  |  |  |  |  |  |  |  |  |  |  |
| Projected benefit obligation | 4.5% |  | 4.3 | % |  | 4.3% |  | 4.3 | % |  | 4.2 | % |  |
| Interest cost (1) |  | —% |  | — | % |  | 4.1% |  | 4.2 | % |  | 4.1 | % |  |
| Service cost (1) |  | —% |  | — | % |  | 3.8% |  | 4.5 | % |  | 4.5 | % |  |
| Salary scale |  | 2.4% |  | 2.6 | % |  | 2.6% |  | 2.2 | % |  | 2.4 | % |  |
| Expected return on plan assets | —% |  | — | % |  | 5.2% |  | 6.3 | % |  | 5.7 | % |  |

[0001783180-26-000008:notes:139]
(1) The 2025 and 2024 discount rates used to measure the service cost and interest cost apply to the significant plans of the Company. The projected benefit obligation discount rate is used for the service cost and interest cost measurements for non-significant plans.

[0001783180-26-000008:notes:140]
The expected long-term rate of return on plan assets is determined by considering the relative weighting of plan assets, the historical performance of total plan assets, individual asset classes, economic and other indicators of future performance. Return projections are assessed for reasonableness using a simulation model that incorporates yield curves, credit spreads and risk premiums to project long-term prospective returns.

[0001783180-26-000008:notes:141]
The Company's investment objective is to provide liquidity and asset levels needed to meet current and future benefit payments, while maintaining a prudent degree of portfolio diversification considering interest rate risk and market volatility. Globally, investment strategies target a mix of approximately 20% of growth seeking assets and 80% of income generating and hedging assets using a wide diversification of asset types, fund strategies and investment managers.

[0001783180-26-000008:notes:142]
The growth seeking allocation consists of global public equities in developed and emerging countries and alternative asset class strategies. The income generating assets primarily consist of government and broadly diversified high quality corporate bonds. In addition, the Company's investment strategies seek to reduce interest rate risk and have incorporated liability hedging programs as part of the long-term investment strategy. Under this objective, the income generating and hedging assets typically increase as the plans' funded status improves. The Company monitors plan funded status and asset allocation regularly in addition to investment manager performance.

[0001783180-26-000008:notes:143]
The fair values of pension plan assets by asset category are as follows:

[0001783180-26-000008:notes:144]
| (In millions) |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Observable Inputs |  | Significant Unobservable Inputs |  | Not Subjectto Leveling |  | Total |
| Asset Category |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  |  |
| Public Equities: |  |  |  |  |  |  |  |  |  |  |
| Global Equities |  | $ | — |  |  | $ | 25 |  |  | $ | — |  |  | $ | — |  |  | $ | 25 |  |
| Global Equity Funds at net asset value (1) (2) |  | — |  |  | — |  |  | — |  |  | 120 |  |  | 120 |  |
| Fixed Income Securities: |  |  |  |  |  |  |  |  |  |  |
| Governments |  | — |  |  | 56 |  |  | — |  |  | 27 |  |  | 83 |  |
| Corporate Bonds |  | — |  |  | 92 |  |  | — |  |  | — |  |  | 92 |  |
| Fixed Income Securities (2) |  | — |  |  | — |  |  | — |  |  | 146 |  |  | 146 |  |
| Real Estate (3) |  | — |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Other (4) (5) |  | — |  |  | 15 |  |  | — |  |  | 7 |  |  | 22 |  |
| Cash & Cash Equivalents (2)(6) |  | — |  |  | 40 |  |  | — |  |  | 9 |  |  | 49 |  |
| Subtotal |  | $ | — |  |  | $ | 229 |  |  | $ | — |  |  | $ | 309 |  |  | $ | 538 |  |
| Other assets and liabilities (7) |  |  |  |  |  |  |  |  |  | 2 |  |
| Total as of December 31, 2025 |  |  |  |  |  |  |  |  |  | $ | 540 |  |
| (In millions) |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Observable Inputs |  | Significant Unobservable Inputs |  | Not Subjectto Leveling |  | Total |
| Asset Category |  | (Level 1) |  | (Level 2) |  | (Level 3) |  |  |  |  |
| Public Equities: |  |  |  |  |  |  |  |  |  |  |
| Global Equities |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | — |  |  | $ | 23 |  |
| Global Equity Funds at net asset value (1) (2) |  | — |  |  | — |  |  | — |  |  | 125 |  |  | 125 |  |
| Fixed Income Securities: |  |  |  |  |  |  |  |  |  |  |
| Governments |  | — |  |  | 23 |  |  | — |  |  | 25 |  |  | 48 |  |
| Corporate Bonds |  | — |  |  | 93 |  |  | — |  |  | — |  |  | 93 |  |
| Fixed Income Securities (2) |  | — |  |  | — |  |  | — |  |  | 156 |  |  | 156 |  |
| Real Estate (3) |  | — |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Other (4)(5) |  | — |  |  | 15 |  |  | — |  |  | 8 |  |  | 23 |  |
| Cash & Cash Equivalents (2)(6) |  | — |  |  | 28 |  |  | — |  |  | 9 |  |  | 37 |  |
| Subtotal |  | $ | — |  |  | $ | 183 |  |  | $ | — |  |  | $ | 323 |  |  | $ | 506 |  |
| Other assets and liabilities (7) |  |  |  |  |  |  |  |  |  | 1 |  |
| Total as of December 31, 2024 |  |  |  |  |  |  |  |  |  | $ | 507 |  |

[0001783180-26-000008:notes:145]
(1) Represents commingled funds that invest primarily in common stocks.

[0001783180-26-000008:notes:146]
(2) In accordance with ASU 2015-07, Fair Value Measurement (Topic 820), certain investments that are measured at fair value using the net asset value per share (or its equivalent) practical expedient have not been classified in the fair value hierarchy. The fair value amounts presented in this table are intended to permit reconciliation of the fair value hierarchy to the amounts presented for the total pension plan assets.

[0001783180-26-000008:notes:147]
(3) Represents investments in real estate, including commingled funds and directly held properties.

[0001783180-26-000008:notes:148]
(4) Represents insurance contracts and global balanced risk commingled funds consisting mainly of equity, bonds and some commodities.

[0001783180-26-000008:notes:149]
(5) Includes fixed income repurchase agreements entered into for purposes of pension asset and liability matching.

[0001783180-26-000008:notes:150]
(6) Represents short-term commercial paper, bonds and other cash or cash-like instruments.

[0001783180-26-000008:notes:151]
(7) Represents trust receivables and payables that are not leveled.

[0001783180-26-000008:notes:152]
Derivatives in the plan are primarily used to manage risk and gain asset class exposure while still maintaining liquidity. Derivative instruments mainly consist of fixed income repurchase agreements, interest rate swaps, total return swaps and currency forward contracts.

[0001783180-26-000008:notes:153]
Quoted market prices are used to value investments when available. Investments in securities traded on exchanges, including listed futures and options, are valued at the last reported sale prices on the last business day of the year or, if not available, the last reported bid prices. Fixed income securities are primarily measured using a market approach pricing methodology, whereby observable prices are obtained by market transactions involving identical or comparable securities of issuers with similar credit ratings. Over-the-counter securities and government obligations are valued at the bid prices or the average of the bid and ask prices on the last business day of the year from published sources or, if not available, from other sources considered reliable, including broker quotes. Temporary cash investments are stated at cost, which approximates fair value.

[0001783180-26-000008:notes:154]
Multiemployer Benefit Plans

[0001783180-26-000008:notes:155]
The Company contributes to various domestic and foreign multiemployer defined benefit pension plans. The risks of participating in these multiemployer plans are different from those of single-employer plans in that assets contributed are pooled and may be used to provide benefits to employees of other participating employers. If a participating employer stops contributing to the plan, the unfunded obligations of the plan may be borne by the remaining participating employers. The Company's contributions to these plans were $15 million for both of the years ended December 31, 2025 and 2024.

[0001783180-26-000008:notes:156]
Employee Savings Plans

[0001783180-26-000008:notes:157]
The Company sponsors various employee savings plans. Employer contributions are determined based on criteria specific to each plan and were $118 million, $138 million and $125 million for the years ended December 31, 2025, 2024 and 2023, respectively.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-26-000008:notes:158]
PRODUCT WARRANTIES 
In the ordinary course of business, the Company provides standard warranty coverage on its products. Provisions for these amounts are established at the time of sale and estimated primarily based on product warranty terms and historical claims experience. In addition, the Company incurs discretionary costs to service its products in connection with specific product performance issues. Provisions for these amounts are established when they are known and estimable. The Company assesses the adequacy of its initial provisions and will make adjustments as necessary based on known or anticipated claims or as new information becomes available that suggests it is probable that future costs will be different than estimated amounts. Amounts associated with these provisions are classified on the accompanying Consolidated Balance Sheet as Accrued liabilities or Other long-term liabilities based on their anticipated settlement date.

[0001783180-26-000008:notes:159]
The changes in the carrying value of warranty related provisions are as follows:

[0001783180-26-000008:notes:160]
| (In millions) | 2025 |  | 2024 |
| Balance as of January 1, | $ | 786 |  |  | $ | 568 |  |
| Warranties, performance guarantees issued and changes in estimated liability | 364 |  |  | 327 |  |
| Settlements made | (282) |  |  | (346) |  |
| Other | 32 |  |  | 5 |  |
| Acquisitions (1) | — |  |  | 232 |  |
| Reclassified to held for sale (2) | (7) |  |  | — |  |
| Balance as of December 31, | $ | 893 |  |  | $ | 786 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-26-000008:notes:161]
EQUITY 
The authorized number of shares of common stock of Carrier is 4,000,000,000 shares of $0.01 par value. As of December 31, 2025 and December 31, 2024, 950,633,287 and 948,068,772 shares of common stock were issued, respectively, which includes 114,891,176 and 70,093,639 shares of treasury stock, respectively.

[0001783180-26-000008:notes:162]
Share Repurchase Program

[0001783180-26-000008:notes:163]
The Company may purchase its outstanding common stock from time to time subject to market conditions and at the Company's discretion. Repurchases occur in the open market or through one or more other public or private transactions pursuant to plans complying with Rules 10b5-1 and 10b-18 under the Exchange Act. Shares acquired are recognized at cost and presented separately on the balance sheet as a reduction to Equity. Since the initial authorization in February 2021, the Company's Board of Directors authorized the repurchase of up to $12.1 billion of the Company's outstanding common stock which includes a $5 billion increase approved in October 2025.

[0001783180-26-000008:notes:164]
In June 2025, the Company repurchased from Viessmann, an entity controlled by one of the Company's directors, an aggregate 4,267,425 shares of the Company's common stock at a price per share of $70.30 for an aggregate purchase price of $300 million. During the year ended December 31, 2025, the Company repurchased 44.8 million shares of common stock for an aggregate purchase price of $2.9 billion, which included shares repurchased from Viessmann under the repurchase agreement. As a result, the Company has approximately $5.3 billion remaining under the current authorization at December 31, 2025.

[0001783180-26-000008:notes:165]
Accumulated Other Comprehensive Income (Loss)

[0001783180-26-000008:notes:166]
A summary of changes in the components of Accumulated other comprehensive income (loss) is as follows:

[0001783180-26-000008:notes:167]
| (In millions) | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Unrealized Hedging Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of January 1, 2023 | $ | (1,604) |  |  | $ | (84) |  |  |  |  |  |  | $ | — |  |  | $ | (1,688) |  |
| Other comprehensive income (loss) before reclassifications, net | 160 |  |  | (17) |  |  |  |  |  |  | 58 |  |  | 201 |  |
| Amounts reclassified, pre-tax | — |  |  | 1 |  |  |  |  |  |  | — |  |  | 1 |  |
| Balance as of December 31, 2023 | $ | (1,444) |  |  | $ | (100) |  |  |  |  |  |  | $ | 58 |  |  | $ | (1,486) |  |
| Other comprehensive income (loss) before reclassifications, net | (1,173) |  |  | (15) |  |  |  |  |  |  | — |  |  | (1,188) |  |
| Amounts reclassified, pre-tax | — |  |  | 2 |  |  |  |  |  |  | (6) |  |  | (4) |  |
| Tax benefit reclassified | — |  |  | (1) |  |  |  |  |  |  | 2 |  |  | 1 |  |
| Divestitures, net | 564 |  |  | 7 |  |  |  |  |  |  | — |  |  | 571 |  |
| Balance as of December 31, 2024 | $ | (2,053) |  |  | $ | (107) |  |  |  |  |  |  | $ | 54 |  |  | $ | (2,106) |  |
| Other comprehensive income (loss) before reclassifications, net | 1,828 |  |  | 12 |  |  |  |  |  |  | — |  |  | 1,840 |  |
| Amounts reclassified, pre-tax | — |  |  | 3 |  |  |  |  |  |  | (6) |  |  | (3) |  |
| Tax benefit reclassified | — |  |  | (1) |  |  |  |  |  |  | 1 |  |  | — |  |
| Balance as of December 31, 2025 | $ | (225) |  |  | $ | (93) |  |  |  |  |  |  | $ | 49 |  |  | $ | (269) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-26-000008:notes:168]
REVENUE RECOGNITION 
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.

[0001783180-26-000008:notes:169]
Performance Obligations

[0001783180-26-000008:notes:170]
A performance obligation is a distinct good, service or a bundle of goods and services promised in a contract. Some of the Company's contracts with customers contain a single performance obligation, while others contain multiple performance obligations most commonly when a contract spans multiple phases of a product life-cycle such as production, installation, maintenance and support. The Company identifies performance obligations at the inception of a contract and allocates the transaction price to each distinct performance obligation. Revenue is recognized when or as the performance obligation is satisfied. When there are multiple performance obligations within a contract, the Company allocates the transaction price to each performance obligation based on its relative stand-alone selling price.

[0001783180-26-000008:notes:171]
The Company primarily generates revenue from the sale of products to customers and recognizes revenue at a point in time when control transfers to the customer. Transfer of control is generally based on the shipping terms of the contract. In addition, the Company recognizes revenue on an over-time basis on installation and service contracts. For over-time performance obligations requiring the installation of equipment, revenue is recognized using costs incurred to date relative to total estimated costs at completion to measure progress. Incurred costs represent work performed, which correspond with and best depict transfer of control to the customer. Contract costs include direct costs such as labor, materials and subcontractors’ costs and where applicable, indirect costs.

[0001783180-26-000008:notes:172]
External segment sales disaggregated by product and service are as follows:

[0001783180-26-000008:notes:173]
| (In millions) |  | 2025 |  | 2024 |  | 2023 |
| Sales Type |  |  |  |  |  |  |
| Product |  | $ | 9,327 |  |  | $ | 9,428 |  |  | $ | 8,538 |  |
| Service |  | 1,143 |  |  | 1,099 |  |  | 1,077 |  |
| Climate Solutions Americas sales |  | 10,470 |  |  | 10,527 |  |  | 9,615 |  |
| Product |  | 4,572 |  |  | 4,652 |  |  | 1,722 |  |
| Service |  | 472 |  |  | 332 |  |  | 215 |  |
| Climate Solutions Europe sales |  | 5,044 |  |  | 4,984 |  |  | 1,937 |  |
| Product |  | 2,606 |  |  | 2,849 |  |  | 3,053 |  |
| Service |  | 733 |  |  | 651 |  |  | 528 |  |
| Climate Solutions Asia Pacific, Middle East & Africa sales |  | 3,339 |  |  | 3,500 |  |  | 3,581 |  |
| Product |  | 2,668 |  |  | 3,061 |  |  | 3,352 |  |
| Service |  | 226 |  |  | 414 |  |  | 466 |  |
| Climate Solutions Transportation sales |  | 2,894 |  |  | 3,475 |  |  | 3,818 |  |
| Net sales |  | $ | 21,747 |  |  | $ | 22,486 |  |  | $ | 18,951 |  |

[0001783180-26-000008:notes:174]
The transaction price allocated to performance obligations reflects the Company’s expectations about the consideration it will be entitled to receive from a customer. The Company includes variable consideration in the estimated transaction price when there is a basis to reasonably estimate the amount and when it is probable that a significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. In addition, the Company customarily offers its customers incentives to purchase products to ensure an adequate supply of its products in distribution channels. The principal incentive programs provide reimbursements to distributors for offering promotional pricing for products. The Company accounts for estimated incentive payments as a reduction in sales at the time a sale is recognized.

[0001783180-26-000008:notes:175]
Contract Balances

[0001783180-26-000008:notes:176]
Total contract assets and liabilities consisted of the following:

[0001783180-26-000008:notes:177]
| (In millions) | 2025 |  | 2024 |
| Contract assets, current (included within Other current assets) | $ | 499 |  |  | $ | 366 |  |
| Contract assets, non-current (included within Other assets) | 83 |  |  | 65 |  |
| Total contract assets | 582 |  |  | 431 |  |
| Contract liabilities, current (included within Accrued liabilities) | (691) |  |  | (553) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) | (203) |  |  | (164) |  |
| Total contract liabilities | (894) |  |  | (717) |  |
| Net contract assets (liabilities) | $ | (312) |  |  | $ | (286) |  |

[0001783180-26-000008:notes:178]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to the customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.

[0001783180-26-000008:notes:179]
The Company recognized revenue of $506 million for the year ended December 31, 2025, that was related to contract liabilities as of January 1, 2025. The Company expects a majority of its contract liabilities at the end of the period to be recognized as revenue over the next 12 months. There were no individually significant customers with sales exceeding 10% of total sales for the years ended December 31, 2025, 2024 and 2023.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001783180-26-000008:notes:180]
The Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.

[0001783180-26-000008:notes:181]
The transaction price allocated to performance obligations reflects the Company’s expectations about the consideration it will be entitled to receive from a customer. The Company includes variable consideration in the estimated transaction price when there is a basis to reasonably estimate the amount and when it is probable that a significant reversal of revenue recognized would not occur when the uncertainty associated with variable consideration is subsequently resolved. In addition, the Company customarily offers its customers incentives to purchase products to ensure an adequate supply of its products in distribution channels. The principal incentive programs provide reimbursements to distributors for offering promotional pricing for products. The Company accounts for estimated incentive payments as a reduction in sales at the time a sale is recognized.
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to the customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001783180-26-000008:notes:182]
Geographic external sales and operating profits are attributed to the geographic regions based on their location of origin. With the exception of the U.S. as presented in the following table, there were no individually significant countries with sales exceeding 10% of total sales for the years ended December 31, 2025, 2024 and 2023.

[0001783180-26-000008:notes:183]
|  |  | External Sales |  | Long-Lived Assets |  |  |  |
| (In millions) |  | 2025 |  | 2024 |  | 2023 |  | 2025 |  | 2024 |  |  |  |
| United States Operations |  | $ | 11,136 |  |  | $ | 11,294 |  |  | $ | 10,457 |  |  | $ | 789 |  |  | $ | 807 |  |  |  |  |
| International Operations |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Europe |  | 6,092 |  |  | 6,687 |  |  | 3,910 |  |  | 1,404 |  |  | 1,253 |  |  |  |  |
| Asia Pacific |  | 3,841 |  |  | 3,817 |  |  | 3,949 |  |  | 482 |  |  | 486 |  |  |  |  |
| Other |  | 678 |  |  | 688 |  |  | 635 |  |  | 490 |  |  | 453 |  |  |  |  |
| Consolidated |  | $ | 21,747 |  |  | $ | 22,486 |  |  | $ | 18,951 |  |  | $ | 3,165 |  |  | $ | 2,999 |  |  |  |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001783180-26-000008:notes:184]
STOCK-BASED COMPENSATION
The Company accounts for stock-based compensation plans in accordance with ASC 718, Compensation - Stock Compensation, which requires a fair-value based method for measuring the value of stock-based compensation. Fair value is measured at the date of grant and is generally not adjusted for subsequent changes. The Company's stock-based compensation plans include programs for stock appreciation rights, restricted stock and performance share units.

[0001783180-26-000008:notes:185]
Stock Options and Appreciation Rights

[0001783180-26-000008:notes:186]
Eligible participants may receive stock options or stock appreciation rights as part of the Company's long-term incentive program. The fair value of each instrument is determined as of the date of grant using a binomial lattice model and expensed on a straight-line basis over the required service period, which is generally a three-year vesting period. However, in the event of retirement, awards held for at least one year may vest and become exercisable (if applicable), subject to certain terms and conditions.

[0001783180-26-000008:notes:187]
The following table summarizes fair value information for stock options and stock appreciation rights:

[0001783180-26-000008:notes:188]
|  |  | 2025 (1) |  | 2024 (1) |  | 2023 (1) |
| Stock options and stock appreciation rights weighted-average fair value per award |  | $ | 17.79 |  |  | $ | 14.84 |  |  | $ | 11.64 |  |
| Assumptions: |  |  |  |  |  |  |
| Volatility |  | 31.2% to 33.4% |  | 30.6% to 31.7% |  | 30.9% |
| Expected term (in years) |  | 5.6 |  | 5.6 to 7.8 |  | 5.8 |
| Expected dividend yield |  | 1.3% |  | 1.8% |  | 1.8% |
| Range of risk-free rates |  | 3.7% to 4.3% |  | 4.0% to 4.3% |  | 3.6% |

[0001783180-26-000008:notes:189]
(1) Carrier has limited historical trading data and used peer group data to estimate expected volatility for the 2025, 2024 and 2023 awards.

[0001783180-26-000008:notes:190]
The Company used historical employee data, including data prior to the Separation and the Distribution, to estimate expected term. The expected dividend yield is consistent with management's expectations. The risk-free rate is based on the term structure of interest rates at the time the awards were granted.

[0001783180-26-000008:notes:191]
Changes in stock options and stock appreciation rights outstanding were as follows:

[0001783180-26-000008:notes:192]
|  | Shares Subject to Option(in thousands) |  | Weighted-Average Exercise Price |  | Aggregate Intrinsic Value (in millions) |  | Weighted- Average Remaining Life (in years) |
| As of December 31, 2022 | 30,778 |  |  | $ | 24.53 |  |  |  |  |  |
| Granted | 3,494 |  |  | $ | 46.13 |  |  |  |  |  |
| Exercised | (8,432) |  |  | $ | 20.48 |  |  |  |  |  |
| Cancelled | (769) |  |  | $ | 42.94 |  |  |  |  |  |
| As of December 31, 2023 | 25,071 |  |  | $ | 28.34 |  |  |  |  |  |
| Granted | 4,187 |  |  | $ | 56.46 |  |  |  |  |  |
| Exercised | (8,041) |  |  | $ | 23.21 |  |  |  |  |  |
| Cancelled | (430) |  |  | $ | 50.77 |  |  |  |  |  |
| As of December 31, 2024 | 20,787 |  |  | $ | 35.52 |  |  |  |  |  |
| Granted | 2,072 |  |  | $ | 64.99 |  |  |  |  |  |
| Exercised | (2,785) |  |  | $ | 26.20 |  |  |  |  |  |
| Cancelled | (724) |  |  | $ | 54.40 |  |  |  |  |  |
| Outstanding as of December 31, 2025 | 19,350 |  |  | $ | 39.31 |  |  | $ | 299 |  |  | 5.4 |
| Exercisable as of December 31, 2025 | 11,909 |  |  | $ | 28.99 |  |  | $ | 285 |  |  | 3.7 |

[0001783180-26-000008:notes:193]
Restricted Stock Units

[0001783180-26-000008:notes:194]
Eligible participants may receive restricted stock units ("RSU") as part of the Company's long-term incentive program. The fair value of restricted stock units is based on the closing market price of the Company's common stock on the date of grant and expensed on a straight-line basis over the required service period (which is generally a three-year vesting period). However, in the event of retirement, awards held for at least one year may vest and become exercisable (if applicable), subject to certain terms and conditions. Dividends accrue during the vesting period and are paid in shares of the Company's common stock.

[0001783180-26-000008:notes:195]
Changes in restricted stock units were as follows:

[0001783180-26-000008:notes:196]
|  | RSUs (in thousands) |  | Weighted-Average Grant Date Fair Value |
| Outstanding and unvested as of December 31, 2022 | 2,067 |  |  | $ | 29.87 |  |
| Granted | 577 |  |  | $ | 45.71 |  |
| Vested | (1,140) |  |  | $ | 26.09 |  |
| Cancelled | (161) |  |  | $ | 35.09 |  |
| Outstanding and unvested as of December 31, 2023 | 1,343 |  |  | $ | 39.22 |  |
| Granted | 264 |  |  | $ | 59.88 |  |
| Vested | (448) |  |  | $ | 38.17 |  |
| Cancelled | (68) |  |  | $ | 49.14 |  |
| Outstanding and unvested as of December 31, 2024 | 1,091 |  |  | $ | 43.94 |  |
| Granted | 330 |  |  | $ | 63.70 |  |
| Vested | (348) |  |  | $ | 44.83 |  |
| Cancelled | (92) |  |  | $ | 42.88 |  |
| Outstanding and unvested as of December 31, 2025 | 981 |  |  | $ | 50.41 |  |

[0001783180-26-000008:notes:197]
Performance Share Units

[0001783180-26-000008:notes:198]
The Company has a performance share program for key employees whereby awards are provided in the form of performance share units ("PSU") based on performance against pre-established objectives. The annual target level is expressed as shares of the Company's common stock based on the fair value of its stock on the date of grant. Awards are generally earned over a three-year performance period based equally on a performance condition, measured by the compound annual growth rate of the Company's earnings per share and on a market condition, measured by the Company's relative total shareowner return compared to the total shareowner return of a subset of industrial companies in the S&P 500 Index. The fair value of the market condition is estimated using a Monte Carlo simulation approach. The fair value of the PSU awards is expensed over the required service period, which is generally a three-year vesting period. In the event of retirement, performance share units held for at least one year remain eligible to vest based on actual performance relative to pre-established metrics. Dividends do not accrue on the performance share units during the performance period.

[0001783180-26-000008:notes:199]
Changes in PSUs were as follows:

[0001783180-26-000008:notes:200]
|  | PSUs (in thousands) |  | Weighted-Average Grant Date Fair Value |
| Outstanding and unvested as of December 31, 2022 | 1,930 |  |  | $ | 35.86 |  |
| Granted | 902 |  |  | $ | 47.93 |  |
| Vested | (607) |  |  | $ | 18.23 |  |
| Forfeited | (183) |  |  | $ | 46.52 |  |
| Outstanding and unvested as of December 31, 2023 | 2,042 |  |  | $ | 45.47 |  |
| Granted | 1,741 |  |  | $ | 50.75 |  |
| Vested | (1,339) |  |  | $ | 41.49 |  |
| Forfeited | (121) |  |  | $ | 52.56 |  |
| Outstanding and unvested as of December 31, 2024 | 2,323 |  |  | $ | 51.35 |  |
| Granted | 836 |  |  | $ | 57.22 |  |
| Vested | (845) |  |  | $ | 46.57 |  |
| Forfeited | (194) |  |  | $ | 55.70 |  |
| Outstanding and unvested as of December 31, 2025 | 2,120 |  |  | $ | 55.17 |  |

[0001783180-26-000008:notes:201]
Compensation Expense

[0001783180-26-000008:notes:202]
Stock-based compensation expense, net of estimated forfeitures, is included in Cost of products sold, Selling, general and administrative and Research and development, in the accompanying Consolidated Statement of Operations.

[0001783180-26-000008:notes:203]
Stock-based compensation cost by award type is as follows:

[0001783180-26-000008:notes:204]
| (In millions) | 2025 |  | 2024 |  | 2023 |
| Equity compensation costs - equity settled | $ | 74 |  |  | $ | 98 |  |  | $ | 81 |  |
| Equity compensation costs - cash settled (1) | (2) |  |  | 2 |  |  | 3 |  |
| Total stock-based compensation cost | $ | 72 |  |  | $ | 100 |  |  | $ | 84 |  |
| Amounts recorded in continuing operations | $ | 72 |  |  | $ | 87 |  |  | $ | 74 |  |
| Amounts recorded in discontinued operations | — |  |  | 13 |  |  | 10 |  |
| Total stock-based compensation cost | $ | 72 |  |  | $ | 100 |  |  | $ | 84 |  |
| Income tax benefit | $ | 8 |  |  | $ | 13 |  |  | $ | 11 |  |

[0001783180-26-000008:notes:205]
(1) The cash settled awards are classified as liability awards and are measured at fair value at each balance sheet date.

[0001783180-26-000008:notes:206]
As of December 31, 2025 and 2024, there were $101 million and $112 million of unrecognized stock-based compensation costs related to non-vested awards granted under the plan, respectively, which will be recognized ratably over the awards weighted-average remaining vesting period of 2 years.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-26-000008:notes:207]
RESTRUCTURING COSTS 
The Company incurs costs associated with restructuring initiatives intended to improve operating performance, profitability and working capital levels. Actions associated with these initiatives may include improving productivity, workforce reductions and the consolidation of facilities. Due to the size, nature and frequency of these discrete plans, they are fundamentally different from the Company’s ongoing productivity initiatives.

[0001783180-26-000008:notes:208]
The Company recorded net pre-tax restructuring costs for new and ongoing restructuring actions as follows:

[0001783180-26-000008:notes:209]
| (In millions) | 2025 |  | 2024 |  | 2023 |
| Climate Solutions Americas | $ | 23 |  |  | $ | 9 |  |  | $ | 11 |  |
| Climate Solutions Europe | 92 |  |  | 70 |  |  | 10 |  |
| Climate Solutions Asia Pacific, Middle East & Africa | 26 |  |  | 10 |  |  | 23 |  |
| Climate Solutions Transportation | 8 |  |  | 8 |  |  | 21 |  |
| Total Segment | 149 |  |  | 97 |  |  | 65 |  |
| Corporate and other | 29 |  |  | 11 |  |  | 10 |  |
| Total restructuring costs (1) | $ | 178 |  |  | $ | 108 |  |  | $ | 75 |  |
| Cost of sales | $ | 42 |  |  | $ | 42 |  |  | $ | 13 |  |
| Selling, general and administrative | 136 |  |  | 66 |  |  | 62 |  |
| Total restructuring costs (1) | $ | 178 |  |  | $ | 108 |  |  | $ | 75 |  |

[0001783180-26-000008:notes:210]
(1) Restructuring costs include period-related charges.

[0001783180-26-000008:notes:211]
The following table summarizes changes in the restructuring reserve, included in Accrued liabilities on the accompanying Consolidated Balance Sheet:

[0001783180-26-000008:notes:212]
| (In millions) |  | 2025 |  | 2024 |
| Balance as of January 1, |  | $ | 69 |  |  | $ | 41 |  |
| Net pre-tax restructuring costs |  | 145 |  |  | 98 |  |
| Acquisitions (1) |  | — |  |  | 8 |  |
| Utilization, foreign exchange and other |  | (110) |  |  | (78) |  |
| Reclassified to held for sale (2) |  | (2) |  |  | — |  |
| Balance as of December 31, |  | $ | 102 |  |  | $ | 69 |  |

[0001783180-26-000008:notes:213]
As of December 31, 2025, the Company had $102 million accrued for costs associated with its announced restructuring initiatives. The balance relates to cost reduction efforts, primarily severance, across each of the Company's segments. The Company expects a majority of the balance to be utilized within 12 months.


## us-gaap:OtherIncomeAndOtherExpenseDisclosureTextBlock

[0001783180-26-000008:notes:214]
OTHER INCOME (EXPENSE), NET
Other income (expense), net consisted of the following:

[0001783180-26-000008:notes:215]
| (In millions) | 2025 |  | 2024 |  | 2023 |
| Viessmann-related hedges | $ | — |  |  | $ | (86) |  |  | $ | (96) |  |
| CCR gain | 7 |  |  | 318 |  |  | — |  |
| CST gain on sale of equity method investment | 6 |  |  | — |  |  | — |  |
| TMA-related gain | — |  |  | 46 |  |  | — |  |
| TCC acquisition-related adjustment | — |  |  | — |  |  | (8) |  |
| Other | 23 |  |  | 39 |  |  | (9) |  |
| Other income (expense), net | $ | 36 |  |  | $ | 317 |  |  | $ | (113) |  |

[0001783180-26-000008:notes:216]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than the entity's functional currency and hedging-related activities. During the year ended December 31, 2025, the Company finalized working capital adjustments provided in the stock purchase agreement governing the sale of CCR and recognized an incremental gain of $7 million.

[0001783180-26-000008:notes:217]
During the year ended December 31, 2024, the Company completed the sale of CCR and recognized a gain on the sale of $318 million. In addition, the Company recognized a $46 million gain associated with its share of UTC's conclusion of certain income tax matters from their 2017 and 2018 tax audit with the IRS. In connection with the acquisition of the VCS Business, the Company recognized an $86 million loss on the mark-to-market valuation of its window forward contracts associated with the cash outflows of the Euro-denominated purchase price. During the year ended December 31, 2023, the Company recognized a $96 million loss on the mark-to-market valuation of its window forward contracts associated with the cash outflows of the Euro-denominated purchase price of the VCS Business. In addition, the Company recognized an $8 million charge related to the fair value adjustment of Toshiba Carrier Corporation (“TCC”) investments.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-26-000008:notes:218]
INCOME TAXES 
Income Before Income Taxes

[0001783180-26-000008:notes:219]
The sources of Income from operations before income taxes are as follows:

[0001783180-26-000008:notes:220]
| (In millions) | 2025 |  | 2024 |  | 2023 |
| United States | $ | 1,536 |  |  | $ | 1,948 |  |  | $ | 1,398 |  |
| Foreign | 262 |  |  | 326 |  |  | 601 |  |
| Total | $ | 1,798 |  |  | $ | 2,274 |  |  | $ | 1,999 |  |

[0001783180-26-000008:notes:221]
Provision for Income Taxes

[0001783180-26-000008:notes:222]
The income tax expense (benefit) consisted of the following components:

[0001783180-26-000008:notes:223]
| (In millions) | 2025 |  | 2024 |  | 2023 |
| Current: |  |  |  |  |  |
| United States: |  |  |  |  |  |
| Federal | $ | 218 |  |  | $ | 920 |  |  | $ | 361 |  |
| State | 86 |  |  | 120 |  |  | 110 |  |
| Foreign | 337 |  |  | 374 |  |  | 293 |  |
|  | 641 |  |  | 1,414 |  |  | 764 |  |
| Future: |  |  |  |  |  |
| United States: |  |  |  |  |  |
| Federal | (28) |  |  | (90) |  |  | (135) |  |
| State | (10) |  |  | (13) |  |  | (28) |  |
| Foreign | (363) |  |  | (249) |  |  | (80) |  |
|  | (401) |  |  | (352) |  |  | (243) |  |
| Income tax expense | $ | 240 |  |  | $ | 1,062 |  |  | $ | 521 |  |

[0001783180-26-000008:notes:224]
Reconciliation of Effective Income Tax Rate

[0001783180-26-000008:notes:225]
Upon adoption of ASU 2023-09, the reconciliation of taxes at the statutory U.S. federal income tax rate to the Company's effective income tax rate is as follows:

[0001783180-26-000008:notes:226]
| (In millions) | 2025 |
| Statutory U.S. federal income tax rate | $ | 377 |  | 21.0 | % |
| State income tax, net of federal income tax effect | 60 |  | 3.4 |  |
| Foreign tax effects: |  |  |
| Canada |  |  |
| Statutory tax rate difference | (3) |  | (0.2) |  |
| Local tax, net of national income tax effect | 9 |  | 0.5 |  |
| All Other | 3 |  | 0.2 |  |
| China |  |  |
| Statutory tax rate difference | 4 |  | 0.2 |  |
| Changes in valuation allowance | 19 |  | 1.1 |  |
| All Other | 6 |  | 0.3 |  |
| France |  |  |
| Statutory tax rate difference | 9 |  | 0.5 |  |
| Changes in valuation allowance | (1) |  | (0.1) |  |
| Germany |  |  |
| Statutory tax rate difference | 58 |  | 3.2 |  |
| Local tax, net of national income tax effect | (78) |  | (4.3) |  |
| Enactment of new tax laws | (130) |  | (7.2) |  |
| All Other | (9) |  | (0.5) |  |
| Ireland |  |  |
| Statutory tax rate difference | (13) |  | (0.7) |  |
| All Other | 7 |  | 0.4 |  |
| Mexico |  |  |
| Statutory tax rate difference | 10 |  | 0.5 |  |
| All Other | 12 |  | 0.7 |  |
| Other foreign jurisdictions | (1) |  | (0.1) |  |
| Effect of cross-border tax laws: |  |  |
| U.S. tax on outside basis | (64) |  | (3.6) |  |
| Net CFC tested income | 14 |  | 0.8 |  |
| U.S. tax on deemed dividends | (6) |  | (0.4) |  |
| Foreign tax credits | (21) |  | (1.2) |  |
| Tax credits: |  |  |
| R&D tax credits | (13) |  | (0.7) |  |
| Other tax credits | (17) |  | (0.9) |  |
| Changes in valuation allowances | 65 |  | 3.6 |  |
| Nontaxable or nondeductible items: |  |  |
| Equity income from joint ventures | (21) |  | (1.2) |  |
| Stock options | (11) |  | (0.6) |  |
| Other | 12 |  | 0.7 |  |
| Changes in unrecognized tax benefits | 4 |  | 0.2 |  |
| All Other |  |  |
| Re-organization tax benefit | (43) |  | (2.4) |  |
| Other | 2 |  | 0.2 |  |
| Effective income tax rate | $ | 240 |  | 13.4 | % |

[0001783180-26-000008:notes:227]
The most significant jurisdictions that comprise the U.S. state income tax, net of federal income tax benefit are Florida, California, New Jersey, Illinois, Georgia, Pennsylvania, New York, and Texas.

[0001783180-26-000008:notes:228]
The differences between the effective income tax rate and the statutory U.S. federal income tax rate, prior to adoption of ASU 2023-09, are as follows:

[0001783180-26-000008:notes:229]
|  | 2024 |  | 2023 |
| Statutory U.S. federal income tax rate | 21.0 | % |  | 21.0 | % |
| State income tax | 2.4 |  |  | 2.4 |  |
| Taxes on international activities | (0.2) |  |  | 4.9 |  |
| CCR divestiture impact | (2.0) |  |  | — |  |
| VCS reorganization impact | 28.6 |  |  | — |  |
| Other | (3.1) |  |  | (2.2) |  |
| Effective income tax rate | 46.7 | % |  | 26.1 | % |

[0001783180-26-000008:notes:230]
The effective tax rate for the year ended December 31, 2025, was lower than the Company's statutory U.S. federal income tax rate. The decrease was primarily driven by a net tax benefit of $64 million from changes to the German effective rate and a statutory reduction to the German corporate tax rate enacted during the year, a tax benefit of $49 million from the re-organization of a Japanese subsidiary and a $16 million tax benefit generated by the purchase of investment tax credits from a third-party.

[0001783180-26-000008:notes:231]
The effective tax rate for the year ended December 31, 2024, was higher than the Company's statutory U.S. federal income tax rate. The increase was primarily driven by a net tax charge of $650 million related to a re-organization of the VCS Business and a non-deductible loss of $86 million on the mark-to-market valuation of the Company's window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business, partially offset by the lower effective tax rate on the $318 million gain on the sale of CCR and $44 million of foreign tax credits generated and utilized in the current year.

[0001783180-26-000008:notes:232]
The effective tax rate for the year ended December 31, 2023, was higher than the Company's statutory U.S. federal income tax rate. The increase was primarily driven by a net tax charge of $27 million relating to the re-organization and disentanglement of the CCR businesses in advance of the planned divestiture. In addition, the effective tax rate was impacted by the recognition of a deferred tax liability for withholding tax of $19 million on repatriated foreign earnings, non-deductible divestiture-related costs and a non-deductible loss of $96 million on the mark-to-market valuation of the Company's window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business.

[0001783180-26-000008:notes:233]
Deferred Tax Assets and Liabilities

[0001783180-26-000008:notes:234]
Future income taxes represent the tax effects of transactions, which are reported in different periods for tax and GAAP purposes. These amounts consist of the tax effects of differences between tax and GAAP that are expected to be reversed in the future and tax carryforwards. Future income tax benefits and obligations within the same tax paying component of a particular jurisdiction are offset for presentation in the Consolidated Balance Sheet.

[0001783180-26-000008:notes:235]
The tax effects of temporary differences and tax carryforwards which give rise to future income tax benefits and obligations as of December 31, 2025 and 2024, are as follows:

[0001783180-26-000008:notes:236]
| (In millions) | 2025 |  | 2024 |
| Future income tax benefits: |  |  |  |
| Insurance and employee benefits | $ | 114 |  |  | $ | 142 |  |
| Other assets basis differences | 519 |  |  | 576 |  |
| Other liabilities basis differences | 773 |  |  | 674 |  |
| Tax loss carryforwards | 256 |  |  | 178 |  |
| Tax credit carryforwards | 1,411 |  |  | 1,404 |  |
| Valuation allowances | (1,539) |  |  | (1,442) |  |
| Future income tax benefits | $ | 1,534 |  |  | $ | 1,532 |  |
| Future income tax obligations: |  |  |  |
| Goodwill and intangible assets | $ | (1,663) |  |  | $ | (1,769) |  |
| Other asset basis differences | (374) |  |  | (381) |  |
| Future income tax obligations | $ | (2,037) |  |  | $ | (2,150) |  |

[0001783180-26-000008:notes:237]
Valuation allowances have been established primarily for tax credit carryforwards, tax loss carryforwards and certain foreign temporary differences to reduce future income tax benefits to expected realizable amounts.

[0001783180-26-000008:notes:238]
Changes to valuation allowances consisted of the following:

[0001783180-26-000008:notes:239]
| (In millions) |  |  |
| Balance as of January 1, 2023 |  | $ | 83 |  |
| Additions charged to income tax expense |  | 27 |  |
| Reduction credited to income tax expense |  | (22) |  |
| Other adjustments |  | 1,303 |  |
| Reclassified to held for sale |  | (19) |  |
| Balance at December 31, 2023 |  | $ | 1,372 |  |
| Additions charged to income tax expense |  | 46 |  |
| Reduction credited to income tax expense |  | (41) |  |
| Other adjustments |  | 65 |  |
| Balance at December 31, 2024 |  | $ | 1,442 |  |
| Additions charged to income tax expense |  | 110 |  |
| Reduction credited to income tax expense |  | (4) |  |
| Other adjustments |  | (9) |  |
| Balance as of December 31, 2025 |  | $ | 1,539 |  |

[0001783180-26-000008:notes:240]
Tax Credit and Loss Carryforwards

[0001783180-26-000008:notes:241]
As of December 31, 2025, tax credit carryforwards and tax loss carryforwards were as follows:

[0001783180-26-000008:notes:242]
| (In millions) | Tax Loss Carryforwards |  | Tax Credit Carryforwards |
| Expiration period: |  |  |  |
| 2026-2030 | $ | 1,179 |  |  | $ | 18 |  |
| 2031-2035 | 10 |  |  | 1,391 |  |
| 2036-2045 | 222 |  |  | — |  |
| Indefinite | 410 |  |  | 2 |  |
| Total | $ | 1,821 |  |  | $ | 1,411 |  |

[0001783180-26-000008:notes:243]
The Company assesses the realizability of its deferred tax assets on a quarterly basis through an analysis of potential sources of future taxable income, including prior year taxable income available to absorb a carryback of tax losses, reversals of existing taxable temporary differences, tax planning strategies and forecasts of taxable income. The Company considers all negative and positive evidence, including the weight of the evidence, to determine if valuation allowances against deferred tax assets are required. The Company maintains valuation allowances against certain deferred tax assets.

[0001783180-26-000008:notes:244]
In conjunction with the announced portfolio transformation, the Company is implementing changes to its corporate structure, including a re-organization of a subsidiary in Switzerland. As operations in the Swiss subsidiary expand within the next 12 months, it is possible that there may be sufficient positive evidence to release a portion of the $1.4 billion valuation allowance applied against a tax credit in Switzerland. A partial release of this valuation allowance would result in a benefit to income tax expense for the period the release is recorded, which could have a material impact on net earnings. The timing and amount of the potential valuation allowance release are subject to significant management judgment, as well as prospective earnings in Switzerland.

[0001783180-26-000008:notes:245]
Unrecognized Tax Benefits

[0001783180-26-000008:notes:246]
As of December 31, 2025, the Company had unrecognized tax benefits of $322 million, all of which, if recognized, would impact its effective tax rate. A reconciliation of the beginning and ending amounts of unrecognized tax benefits and related interest expense is as follows:

[0001783180-26-000008:notes:247]
| (In millions) | 2025 |  | 2024 |  | 2023 |
| Balance at beginning of period | $ | 365 |  |  | $ | 382 |  |  | $ | 291 |  |
| Additions for tax positions related to the current year | 10 |  |  | 34 |  |  | 37 |  |
| Additions for tax positions of prior years (1) | 12 |  |  | 30 |  |  | 81 |  |
| Reductions for tax positions of prior years | (3) |  |  | (7) |  |  | — |  |
| Settlements | (29) |  |  | (68) |  |  | (27) |  |
| Reclassified to other accounts (2) | (33) |  |  | (6) |  |  | — |  |
| Balance at end of period | $ | 322 |  |  | $ | 365 |  |  | $ | 382 |  |
| Gross interest expense related to unrecognized tax benefits | $ | 18 |  |  | $ | 19 |  |  | $ | 18 |  |
| Total accrued interest balance at end of period | $ | 71 |  |  | $ | 57 |  |  | $ | 64 |  |

[0001783180-26-000008:notes:248]
(1) Includes $73 million during the year ended December 31, 2023, related to acquisitions.

[0001783180-26-000008:notes:249]
(2) Includes $33 million during the year ended December 31, 2025, related to held for sale.

[0001783180-26-000008:notes:250]
The Company conducts business globally and, as a result, the Company and its subsidiaries file income tax returns in the U.S. federal, various state and foreign jurisdictions. In certain jurisdictions, the Company's operations were included in UTC's combined tax returns for the periods through the date of the Separation and Distribution. The IRS finalized the examination of UTC's tax year 2020 resulting in the recognition of a tax benefit of $6 million in the second quarter of 2025. The U.S. Federal statute of limitations for Carrier's tax year 2021 expired during the three months ended December 31, 2025 resulting in a recognized tax benefit of $5 million. The IRS is examining Carrier's tax year 2022 with the examination progressing slowly due to IRS turnover and the U.S. government shutdown. In the normal course of business, the Company is subject to examination by taxing authorities throughout the world, including the U.S., Australia, Belgium, Canada, China, France, Germany, India, Italy, Malaysia, Poland, Singapore, Spain, and the United Kingdom. The Company is no longer subject to U.S. federal income tax examination for years prior to 2022 and, with few exceptions, is no longer subject to U.S. state and local and foreign income tax examinations for tax years before 2013.

[0001783180-26-000008:notes:251]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. The Company believes that it is reasonably possible that a net decrease in unrecognized tax benefits of $10 million to $95 million may occur within 12 months as a result of additional uncertain tax positions, the revaluation of uncertain tax positions arising from examinations, appeals, court decisions or the closure of tax statutes.

[0001783180-26-000008:notes:252]
As a result of the Tax Cuts and Jobs Act ("TCJA"), the Company no longer intends to reinvest certain undistributed earnings of its international subsidiaries including some earnings which have been previously taxed in the U.S. As such, the Company has recorded tax liabilities associated with the future remittance of these earnings. For the remainder of the Company's undistributed international earnings, unless it becomes tax effective to repatriate, the Company intends to continue to permanently reinvest these earnings. It is not practicable to estimate the amount of tax that might be payable on the remaining amounts. The One Big Beautiful Bill Act subjects the Company to a tax on net CFC tested income, which the Company accounts for as a period cost.


## us-gaap:EarningsPerShareTextBlock

[0001783180-26-000008:notes:253]
EARNINGS PER SHARE 
Earnings per share is computed by dividing Net earnings (loss) attributable to common shareowners by the weighted-average number of shares of common stock outstanding during the period (excluding treasury stock). Diluted earnings per share is computed by giving effect to all potentially dilutive stock awards that are outstanding. The computation of diluted earnings per share excludes the effect of the potential exercise of stock-based awards, including stock appreciation rights and stock options, when the effect of the potential exercise would be anti-dilutive.

[0001783180-26-000008:notes:254]
The following table summarizes the weighted-average number of shares of common stock outstanding for basic and diluted earnings per share calculations:

[0001783180-26-000008:notes:255]
| (In millions, except per share amounts) |  | 2025 |  | 2024 |  | 2023 |  |  |
| Net earnings (loss) attributable to common shareowners |  | $ | 1,484 |  |  | $ | 5,604 |  |  | $ | 1,349 |  |  |  |
| Basic weighted-average number of shares outstanding |  | 852.4 |  |  | 898.2 |  |  | 837.3 |  |  |  |
| Stock awards and equity units (share equivalent) |  | 10.0 |  |  | 13.5 |  |  | 15.7 |  |  |  |
| Diluted weighted-average number of shares outstanding |  | 862.4 |  |  | 911.7 |  |  | 853.0 |  |  |  |
| Antidilutive shares excluded from computation of diluted earnings per share |  | 1.9 |  |  | 0.1 |  |  | 2.0 |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001783180-26-000008:notes:256]
ACQUISITIONS
During the year ended December 31, 2025, the Company acquired consolidated and minority-owned businesses. The aggregate cash paid, net of cash acquired, totaled $107 million. Acquisitions are recorded using the acquisition method of accounting in accordance with ASC 805. As a result, the aggregate purchase price has been allocated to assets acquired and liabilities assumed based on the estimate of fair market value of such assets and liabilities at the date of acquisition. The excess purchase price over the estimated fair value of net assets acquired is recognized as goodwill.

[0001783180-26-000008:notes:257]
Viessmann Climate Solutions

[0001783180-26-000008:notes:258]
On January 2, 2024, the Company completed the acquisition of the VCS Business from Viessmann for total consideration of $14.2 billion. The purchase price consisted of (i) $11.2 billion in cash and (ii) 58,608,959 shares of the Company's common stock, subject to certain lock-up provisions and anti-dilution protection. The Company funded the cash portion of the purchase price with a combination of cash on hand and proceeds from various borrowing facilities.

[0001783180-26-000008:notes:259]
The VCS Business develops intelligent, integrated and sustainable technologies, including heat pumps, boilers, photovoltaic systems, home battery storage and digital solutions, primarily for residential customers in Europe. The Company believes that secular trends in these areas will drive significant, sustained future growth. In addition, the Company anticipates realizing significant operational synergies including savings through supplier rationalization and leverage, reduced manufacturing costs and lower general and administrative costs. Longer term, the Company expects to benefit from synergies related to service revenue expansion, leverage of distribution channels and cross-selling opportunities.

[0001783180-26-000008:notes:260]
The components of the purchase price are as follows:

[0001783180-26-000008:notes:261]
| (In millions) |  | January 2, 2024 |
| Cash |  | $ | 11,156 |  |
| Common shares (58,608,959 shares at $51.20 per share) |  | 3,001 |  |
| Total consideration |  | $ | 14,157 |  |

[0001783180-26-000008:notes:262]
The preliminary allocation of the purchase price is as follows:

[0001783180-26-000008:notes:263]
| (In millions) |  | Preliminary January 2, 2024 |  | Measurement Period Adjustments |  | As Adjusted January 2, 2024 |
| Cash and cash equivalents |  | $ | 394 |  |  | $ | (1) |  |  | $ | 393 |  |
| Accounts receivable |  | 408 |  |  | 5 |  |  | 413 |  |
| Inventories |  | 948 |  |  | (28) |  |  | 920 |  |
| Other current assets |  | 17 |  |  | — |  |  | 17 |  |
| Fixed assets |  | 913 |  |  | 6 |  |  | 919 |  |
| Intangible assets |  | 6,640 |  |  | 5 |  |  | 6,645 |  |
| Other assets |  | 284 |  |  | 15 |  |  | 299 |  |
| Accounts payable |  | (288) |  |  | (2) |  |  | (290) |  |
| Other liabilities, current |  | (626) |  |  | (37) |  |  | (663) |  |
| Future income tax obligations |  | (1,825) |  |  | 15 |  |  | (1,810) |  |
| Other liabilities |  | (284) |  |  | (17) |  |  | (301) |  |
| Total identifiable net assets |  | 6,581 |  |  | (39) |  |  | 6,542 |  |
| Goodwill |  | 7,576 |  |  | 31 |  |  | 7,607 |  |
| Total consideration |  | $ | 14,157 |  |  | $ | (8) |  |  | $ | 14,149 |  |

[0001783180-26-000008:notes:264]
The excess purchase price over the estimated fair value of the net identifiable assets acquired was recognized as goodwill and totaled $7.6 billion, which is not deductible for tax purposes. Accounts receivable and current liabilities were stated at their historical carrying value, which approximates fair value given the short-term nature of these assets and liabilities. The estimate of fair value for inventory and fixed assets was based on an assessment of the acquired assets' condition as well as an evaluation of the current market value of such assets.

[0001783180-26-000008:notes:265]
The Company recorded intangible assets based on its estimate of fair value which consisted of the following:

[0001783180-26-000008:notes:266]
| (In millions) |  | Estimated Useful Life (in years) |  | Intangible Assets Acquired |
| Customer relationships |  | 17 |  | $ | 4,787 |  |
| Technology |  | 10 - 20 |  | 1,051 |  |
| Trademark |  | 40 |  | 679 |  |
| Backlog |  | 1 |  | 123 |  |
| Other |  | 50 |  | 5 |  |
| Total intangible assets acquired |  |  |  | $ | 6,645 |  |

[0001783180-26-000008:notes:267]
The valuation of intangible assets was determined using an income approach methodology including the multi-period excess earnings method and the relief from royalty method. Key assumptions used in estimating future cash flows included projected short-term revenue growth rates, research and development expenses, EBITDA margins, income tax rates, discount rates, customer attrition rates, royalty rates, contributory asset charge and obsolescence rates among others. The projected future cash flows are discounted to present value using an appropriate discount rate. The Company finalized the process of allocating the purchase price and valuing the acquired assets and liabilities during the year ended December 31, 2024.

[0001783180-26-000008:notes:268]
The Company incurred $40 million of acquisition-related costs during 2024. During 2023, $80 million of acquisition-related costs were incurred. These acquisition costs are reflected within Selling, general and administrative in the Consolidated Statement of Operations.
The assets, liabilities and results of operations of the VCS Business are consolidated in the accompanying Consolidated Financial Statements as of the date of acquisition and primarily reported within the Company's Climate Solutions Europe segment.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001783180-26-000008:notes:269]
DIVESTITURES
On December 16, 2025, the Company entered into a stock purchase agreement to sell its Riello business to Ariston Group with expected gross proceeds of approximately $430 million. Riello, predominantly reported in the Company's Climate Solutions Europe segment, is a leading international manufacturer that designs, produces, and integrates a comprehensive portfolio of thermal solutions—including burners, boilers, heat pumps, cooling systems, and aftermarket services—for residential, commercial, and industrial applications, with a strong focus on energy efficiency, innovation, and a global distribution network. As a result, the assets and liabilities of Riello are presented as held for sale in the accompanying Consolidated Balance Sheet as of December 31, 2025, and recorded at the lower of their carrying value or fair value less estimated cost to sell. This transaction is expected to close in the first half of 2026 and is subject to customary closing conditions and regulatory approvals.

[0001783180-26-000008:notes:270]
The following table summarizes assets and liabilities classified as held for sale:

[0001783180-26-000008:notes:271]
|  |  | December 31, 2025 |
| (In millions) |  |  | Riello |  |  |
| Cash and cash equivalents |  |  | $ | 25 |  |  |  |
| Accounts receivable, net |  |  | 103 |  |  |  |
| Inventories, net |  |  | 98 |  |  |  |
| Other current assets |  |  | 2 |  |  |  |
| Fixed assets, net |  |  | 77 |  |  |  |
| Intangible assets, net |  |  | 18 |  |  |  |
| Goodwill |  |  | 175 |  |  |  |
| Operating lease right-of-use assets |  |  | 7 |  |  |  |
| Other assets |  |  | 87 |  |  |  |
| Total assets held for sale |  |  | $ | 592 |  |  |  |
| Accounts payable |  |  | $ | 91 |  |  |  |
| Accrued liabilities |  |  | 45 |  |  |  |
| Contract liabilities |  |  | 3 |  |  |  |
| Future pension and post-retirement obligations |  |  | 7 |  |  |  |
| Future income tax obligations |  |  | 9 |  |  |  |
| Operating lease liabilities |  |  | 4 |  |  |  |
| Other long-term liabilities |  |  | 11 |  |  |  |
| Total liabilities held for sale |  |  | $ | 170 |  |  |  |

[0001783180-26-000008:notes:272]
Discontinued Operations

[0001783180-26-000008:notes:273]
During 2024, the Company exited its Fire & Security segment in multiple transactions that represented a single disposal plan to separately divest multiple businesses over different reporting periods. As a result, the components of the Fire & Security segment in aggregate met the criteria to be presented as discontinued operations in the accompanying Consolidated Statement of Operations and Consolidated Statement of Cash Flows. Amounts reported during 2023 and 2024 include the operating results of each component through their respective date of sale and related gain on sale or loss on deconsolidation. Amounts reported during 2025 relate to retained obligations from these business divestitures.

[0001783180-26-000008:notes:274]
The components of Discontinued operations, net of tax are as follows:

[0001783180-26-000008:notes:275]
| (In millions) | 2025 |  | 2024 |  | 2023 |
| Net sales | $ | — |  |  | $ | 2,323 |  |  | $ | 3,147 |  |
| Costs of sales | — |  |  | (1,390) |  |  | (1,926) |  |
| Research and development | — |  |  | (86) |  |  | (124) |  |
| Selling, general and administrative | (6) |  |  | (564) |  |  | (690) |  |
| Other income (expense), net | (3) |  |  | (584) |  |  | 26 |  |
| Gain (loss) on divestitures and deconsolidation | (22) |  |  | 5,176 |  |  | (297) |  |
| Interest (expense) income, net | — |  |  | (41) |  |  | (51) |  |
| Earnings before income taxes | (31) |  |  | 4,834 |  |  | 85 |  |
| Income tax (expense) benefit | 55 |  |  | 1,391 |  |  | (128) |  |
| Tax on divestitures and deconsolidation | 5 |  |  | (1,729) |  |  | 5 |  |
| Discontinued operations, net of tax | $ | 29 |  |  | $ | 4,496 |  |  | $ | (38) |  |

[0001783180-26-000008:notes:276]
On June 2, 2024, the Company completed the sale of Access Solutions for cash proceeds of $5.0 billion. Access Solutions, historically reported in the Company's Fire & Security segment, is a global supplier of physical security and digital access solutions supporting the hospitality, commercial, education and military markets. The Company recognized a net gain on the sale of $1.8 billion, which is included in Discontinued operations, net of tax on the accompanying Consolidated Statement of Operations.

[0001783180-26-000008:notes:277]
On July 1, 2024, the Company completed the sale of Industrial Fire for cash proceeds of $1.4 billion. Industrial Fire, historically reported in the Company's Fire & Security segment, is a leading manufacturer of a full spectrum of fire detection and suppression solutions and services in critical high-hazard environments, including oil and gas, power generation, marine and offshore facilities, automotive, data centers and aircraft hangars. The Company recognized a net gain on the sale of $319 million, which is included in Discontinued operations, net of tax on the accompanying Consolidated Statement of Operations.

[0001783180-26-000008:notes:278]
On October 1, 2024, the Company completed the sale of CCR for cash proceeds of $679 million. CCR, historically reported in the Company's Climate Solutions Transportation segment, is a global supplier of turnkey solutions for commercial refrigeration systems and services, with a primary focus on serving food retail customers, cold storage facilities and warehouses. The Company recognized a gross gain on the sale of $318 million, which is included in Other income (expense), net on the accompanying Consolidated Statement of Operations. During 2025, the Company finalized the working capital and other adjustments provided in the stock purchase agreement governing the sale of CCR.
On December 2, 2024, the Company completed the sale of the CRF Business for cash proceeds of $2.9 billion. The CRF Business, historically reported in the Company's Fire & Security segment, is a leading manufacturer of fire detection and alarm solutions for both commercial and residential applications. The Company recognized a net gain on the sale of $1.4 billion, which is included in Discontinued operations, net of tax on the accompanying Consolidated Statement of Operations.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-26-000008:notes:279]
SEGMENT FINANCIAL DATA
The Company conducts its operations through four reportable operating segments. In accordance with ASC 280 - Segment Reporting, the Company's segments maintain separate financial information for which results of operations are evaluated on a regular basis by the Company's CODM in deciding how to allocate resources and in assessing performance.

[0001783180-26-000008:notes:280]
•Climate Solutions Americas ("CSA") provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers in North and South America while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-26-000008:notes:281]
•Climate Solutions Europe ("CSE") provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers in Europe while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-26-000008:notes:282]
•Climate Solutions Asia Pacific, Middle East & Africa ("CSAME") provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers in Asia Pacific, the Middle East and Africa while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-26-000008:notes:283]
•Climate Solutions Transportation ("CST") includes global transport refrigeration and monitoring products, services and digital solutions for trucks, trailers, shipping containers, intermodal and rail.

[0001783180-26-000008:notes:284]
The Corporate and other category primarily includes corporate administrative functions such as tax, treasury, internal audit, legal and human resources. A portion of these costs and costs associated with shared service centers that provide transaction processing, accounting and other business support functions are allocated to the reportable segments.

[0001783180-26-000008:notes:285]
Segment operating profit is the measure of profit and loss that the Company’s CODM, the Chief Executive Officer (“CEO”), uses to evaluate the financial performance of the business and as the basis for resource allocation, performance reviews and compensation. It represents operating profit (a GAAP measure) adjusted to exclude restructuring costs, amortization of acquired intangible assets and other significant items of a nonoperational nature. Targets are established on an annual basis and used by the CODM throughout the year to compare with actual results. Quarterly forecasts supplement annual targets and provide incremental information utilized to assess the performance of a segment. Variance analysis further provides insight into segment end-markets and operational cost optimization. These results also support the CODM to manage the Company’s business portfolio.

[0001783180-26-000008:notes:286]
Consistent with the management approach for segment reporting, the tables below present reported external net sales and significant expense categories for each of the Company’s segments that are regularly provided to the CODM and included in its reported measure of segment profit or loss. The Company manages research and development costs on a global basis and allocates these costs to the reportable segments.

[0001783180-26-000008:notes:287]
A summary of results by reportable segment are as follows:

[0001783180-26-000008:notes:288]
|  | For the Year Ended December 31, 2025 |
| (In millions) | CSA |  | CSE |  | CSAME |  | CST |  | Segment Total |
| Net sales | $ | 10,470 |  |  | $ | 5,044 |  |  | $ | 3,339 |  |  | $ | 2,894 |  |  | $ | 21,747 |  |
| Cost of goods sold | (7,073) |  |  | (3,494) |  |  | (2,499) |  |  | (2,112) |  |  | (15,178) |  |
| Research and development | (347) |  |  | (75) |  |  | (61) |  |  | (66) |  |  | (549) |  |
| Selling, general and administrative | (1,036) |  |  | (1,039) |  |  | (476) |  |  | (287) |  |  | (2,838) |  |
| Equity method investment net earnings | 126 |  |  | (3) |  |  | 100 |  |  | 6 |  |  | 229 |  |
| Other income (expense), net | 10 |  |  | 11 |  |  | 45 |  |  | 17 |  |  | 83 |  |
| Segment operating profit | $ | 2,150 |  |  | $ | 444 |  |  | $ | 448 |  |  | $ | 452 |  |  | $ | 3,494 |  |

[0001783180-26-000008:notes:289]
|  | For the Year Ended December 31, 2024 |
| (In millions) | CSA |  | CSE |  | CSAME |  | CST |  | Segment Total |
| Net sales | $ | 10,527 |  |  | $ | 4,984 |  |  | $ | 3,500 |  |  | $ | 3,475 |  |  | $ | 22,486 |  |
| Cost of goods sold | (6,997) |  |  | (3,368) |  |  | (2,579) |  |  | (2,540) |  |  | (15,484) |  |
| Research and development | (390) |  |  | (81) |  |  | (69) |  |  | (80) |  |  | (620) |  |
| Selling, general and administrative | (962) |  |  | (1,062) |  |  | (520) |  |  | (369) |  |  | (2,913) |  |
| Equity method investment net earnings | 135 |  |  | (1) |  |  | 92 |  |  | 6 |  |  | 232 |  |
| Other income (expense), net | 10 |  |  | (3) |  |  | 42 |  |  | (7) |  |  | 42 |  |
| Segment operating profit | $ | 2,323 |  |  | $ | 469 |  |  | $ | 466 |  |  | $ | 485 |  |  | $ | 3,743 |  |

[0001783180-26-000008:notes:290]
|  | For the Year Ended December 31, 2023 |
| (In millions) | CSA |  | CSE |  | CSAME |  | CST |  | Segment Total |
| Net sales | $ | 9,615 |  |  | $ | 1,937 |  |  | $ | 3,581 |  |  | $ | 3,818 |  |  | $ | 18,951 |  |
| Cost of goods sold | (6,629) |  |  | (1,410) |  |  | (2,697) |  |  | (2,854) |  |  | (13,590) |  |
| Research and development | (294) |  |  | (28) |  |  | (52) |  |  | (74) |  |  | (448) |  |
| Selling, general and administrative | (974) |  |  | (327) |  |  | (573) |  |  | (431) |  |  | (2,305) |  |
| Equity method investment net earnings | 145 |  |  | — |  |  | 61 |  |  | 6 |  |  | 212 |  |
| Other income (expense), net | (32) |  |  | 5 |  |  | 41 |  |  | 29 |  |  | 43 |  |
| Segment operating profit | $ | 1,831 |  |  | $ | 177 |  |  | $ | 361 |  |  | $ | 494 |  |  | $ | 2,863 |  |

[0001783180-26-000008:notes:291]
| (In millions) |  | 2025 |  | 2024 |  | 2023 |
| Reconciliation to Earnings before income taxes |  |  |  |  |  |  |
| Segment operating profit |  | $ | 3,494 |  |  | $ | 3,743 |  |  | $ | 2,863 |  |
| Corporate and other |  | (202) |  |  | (201) |  |  | (214) |  |
| Restructuring costs |  | (178) |  |  | (108) |  |  | (75) |  |
| Amortization of acquired intangibles |  | (856) |  |  | (689) |  |  | (143) |  |
| Acquisition step-up amortization |  | — |  |  | (282) |  |  | (41) |  |
| Acquisition/divestiture-related costs |  | (55) |  |  | (95) |  |  | (123) |  |
| Viessmann-related hedges |  | — |  |  | (86) |  |  | (96) |  |
| CCR gain |  | 7 |  |  | 318 |  |  | — |  |
| VCS pre-acquisition product replacement cost |  | (38) |  |  | — |  |  | — |  |
| Gain on liability adjustment |  | — |  |  | 46 |  |  | — |  |
| Bridge loan financing costs |  | — |  |  | — |  |  | (3) |  |
| TCC Acquisition-related adjustment |  | — |  |  | — |  |  | (8) |  |
| Non-service pension (expense) benefit |  | (10) |  |  | (1) |  |  | (1) |  |
| Interest (expense) income, net |  | (364) |  |  | (371) |  |  | (160) |  |
| Earnings before income taxes |  | $ | 1,798 |  |  | $ | 2,274 |  |  | $ | 1,999 |  |

[0001783180-26-000008:notes:292]
Segment operating profit is not defined under GAAP and may not be comparable to similarly titled measures used by other companies. Measures of capital expenditures, depreciation expense, amortization expense and total assets by reportable segment are not provided to the CODM and therefore not disclosed.

[0001783180-26-000008:notes:293]
Total assets are not presented for each segment as they are not presented to or reviewed by the CODM. Segment assets in the following table represent Accounts receivable, net and Inventories, net. These assets are regularly reviewed by management and are therefore reported in the following table as segment assets. All other remaining assets and liabilities for all periods presented are managed on a company-wide basis.

[0001783180-26-000008:notes:294]
|  | Segment Assets |  | Capital Expenditures |  | Depreciation & Amortization |
| (In millions) | 2025 |  | 2024 |  |  |  | 2025 |  | 2024 |  | 2023 |  | 2025 |  | 2024 |  | 2023 |
| CSA | $ | 1,472 |  |  | $ | 1,405 |  |  |  |  | $ | 151 |  |  | $ | 198 |  |  | $ | 179 |  |  | $ | 133 |  |  | $ | 134 |  |  | $ | 120 |  |
| CSE | 1,660 |  |  | 1,590 |  |  |  |  | 135 |  |  | 197 |  |  | 63 |  |  | 878 |  |  | 813 |  |  | 56 |  |
| CSAME | 988 |  |  | 952 |  |  |  |  | 39 |  |  | 48 |  |  | 74 |  |  | 198 |  |  | 213 |  |  | 241 |  |
| CST | 915 |  |  | 818 |  |  |  |  | 25 |  |  | 32 |  |  | 30 |  |  | 26 |  |  | 35 |  |  | 34 |  |
| Total Segment | 5,035 |  |  | 4,765 |  |  |  |  | 350 |  |  | 475 |  |  | 346 |  |  | 1,235 |  |  | 1,195 |  |  | 451 |  |
| Corporate and other | 87 |  |  | 185 |  |  |  |  | 42 |  |  | 44 |  |  | 93 |  |  | 39 |  |  | 37 |  |  | 40 |  |
| Consolidated | $ | 5,122 |  |  | $ | 4,950 |  |  |  |  | $ | 392 |  |  | $ | 519 |  |  | $ | 439 |  |  | $ | 1,274 |  |  | $ | 1,232 |  |  | $ | 491 |  |
| Cash and cash equivalents | 1,555 |  |  | 3,969 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other assets, current | 1,264 |  |  | 972 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets held for sale | 592 |  |  | — |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total current assets | $ | 8,533 |  |  | $ | 9,891 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001783180-26-000008:notes:295]
Geographic External Sales


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-26-000008:notes:296]
RELATED PARTIES 
Equity Method Investments

[0001783180-26-000008:notes:297]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered to be related parties. The Company has 28 directly owned unconsolidated domestic and foreign affiliates as of December 31, 2025, of which 56% relates to Climate Solutions Americas, and 40% relates to Climate Solutions Asia Pacific, Middle East & Africa. The Company periodically reviews the carrying value of its equity method investments to determine if there has been an other-than-temporary decline in fair value.

[0001783180-26-000008:notes:298]
Amounts attributable to equity method investees are as follows:

[0001783180-26-000008:notes:299]
| (In millions) | 2025 |  | 2024 |  | 2023 |
| Sales to equity method investees included in Product sales | $ | 2,874 |  |  | $ | 2,956 |  |  | $ | 2,920 |  |
| Purchases from equity method investees included in Cost of products sold | $ | 227 |  |  | $ | 237 |  |  | $ | 214 |  |

[0001783180-26-000008:notes:300]
The Company had receivables from and payables to equity method investees as follows:

[0001783180-26-000008:notes:301]
| (In millions) | 2025 |  | 2024 |
| Receivables from equity method investees included in Accounts receivable, net | $ | 220 |  |  | $ | 363 |  |
| Payables to equity method investees included in Accounts payable | $ | 40 |  |  | $ | 32 |  |

[0001783180-26-000008:notes:302]
Summarized Financial Information. Pursuant to Rule 3-10 and Rule 4-08(g) of Regulation S-X under the Securities Act, the Company presents summarized financial information of the combined accounts of its non-consolidated joint ventures accounted for by the equity method.

[0001783180-26-000008:notes:303]
Summarized unaudited financial information for equity method investments is as follows:

[0001783180-26-000008:notes:304]
| (In millions) | 2025 |  | 2024 |
| Current assets | $ | 11,835 |  |  | $ | 12,823 |  |
| Non-current assets | 2,418 |  |  | 2,396 |  |
| Total assets | 14,253 |  |  | 15,219 |  |
| Current liabilities | (9,675) |  |  | (11,053) |  |
| Non-current liabilities | (236) |  |  | (210) |  |
| Total liabilities | (9,911) |  |  | (11,263) |  |
| Total net equity of investees | $ | 4,342 |  |  | $ | 3,956 |  |

[0001783180-26-000008:notes:305]
| (In millions) | 2025 |  | 2024 |  | 2023 |
| Net sales | $ | 18,154 |  |  | $ | 17,567 |  |  | $ | 16,180 |  |
| Gross profit | $ | 3,168 |  |  | $ | 3,063 |  |  | $ | 2,862 |  |
| Income from continuing operations | $ | 676 |  |  | $ | 700 |  |  | $ | 655 |  |
| Net earnings (loss) | $ | 676 |  |  | $ | 700 |  |  | $ | 655 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-26-000008:notes:306]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability has been incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon its results of operations or financial condition.

[0001783180-26-000008:notes:307]
Environmental Matters

[0001783180-26-000008:notes:308]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to, investigatory, remediation, operating and maintenance costs and performance guarantees. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including the technology required to remediate, current laws and regulations and prior remediation experience.

[0001783180-26-000008:notes:309]
As of December 31, 2025 and 2024, the outstanding liability for environmental obligations are as follows:

[0001783180-26-000008:notes:310]
| (In millions) |  | 2025 |  | 2024 |
| Environmental reserves included in Accrued liabilities |  | $ | 18 |  |  | $ | 25 |  |
| Environmental reserves included in Other long-term liabilities |  | 182 |  |  | 185 |
| Total environmental reserves |  | $ | 200 |  |  | $ | 210 |  |

[0001783180-26-000008:notes:311]
For sites with multiple responsible parties, the Company considers its likely proportionate share of the anticipated remediation costs and the ability of other parties to fulfill their obligations in establishing a provision for these costs. Accrued environmental liabilities are not reduced by potential insurance reimbursements and are undiscounted.

[0001783180-26-000008:notes:312]
Asbestos Matters

[0001783180-26-000008:notes:313]
The Company has been named as a defendant in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-26-000008:notes:314]
The Company's asbestos liabilities and related insurance recoveries are as follows:

[0001783180-26-000008:notes:315]
| (In millions) |  | 2025 |  | 2024 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 201 |  |  | 208 |  |
| Total asbestos liabilities |  | $ | 218 |  |  | $ | 225 |  |
| Asbestos-related recoveries included in Accounts receivable, net |  | $ | 6 |  |  | $ | 7 |  |
| Asbestos-related recoveries included in Other assets |  | 86 |  |  | 88 |  |
| Total asbestos-related recoveries |  | $ | 92 |  |  | $ | 95 |  |

[0001783180-26-000008:notes:316]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and exclude the Company's legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.

[0001783180-26-000008:notes:317]
Aqueous Film Forming Foam Litigation

[0001783180-26-000008:notes:318]
As of December 31, 2025, the Company, Kidde-Fenwal, Inc. ("KFI") and others have been named as defendants in more than 17,000 lawsuits filed in United States state or federal courts and a single case in Canada alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and damage to property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). Individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

[0001783180-26-000008:notes:319]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires. The lawsuits identified above relate to Kidde Fire Fighting, Inc., which owned the “National Foam” business that manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania (the "Pennsylvania Site"). Kidde Fire Fighting, Inc. was acquired by a UTC subsidiary in 2005 and merged into KFI in 2007. In 2013, KFI divested the AFFF businesses to an unrelated third party. The Company acquired KFI as part of the Separation in April 2020.

[0001783180-26-000008:notes:320]
The key components that contribute to AFFF's fire-extinguishing capabilities are known as fluorosurfactants. Neither the Company, nor KFI, nor any of the Company's subsidiaries involved in the AFFF litigation manufactured fluorosurfactants. Instead, the National Foam business purchased these substances from unrelated third parties for use in manufacturing AFFF. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as per- and polyfluoroalkyl substances (referred to collectively as "PFAS"), including perflourooctanesulfonic acid ("PFOS") and perflourooctanoic acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

[0001783180-26-000008:notes:321]
Plaintiffs in the MDL Proceedings have named multiple defendants, including suppliers of chemicals and raw materials used to manufacture fluorosurfactants, fluorosurfactant manufacturers and AFFF manufacturers. The defendants in the MDL Proceedings moved for summary judgment on the government contractor defense, which potentially applies to AFFF sold to or used by the U.S. government. After full briefing and oral argument, on September 16, 2022, the MDL court declined to enter summary judgment for the defendants. The defense, however, remains available at any trial in which it would apply.

[0001783180-26-000008:notes:322]
On May 14, 2023, KFI filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware (the “Bankruptcy Court”) seeking relief under chapter 11 of the Bankruptcy Code, after the Company determined that it would not provide financial support to KFI going forward other than ensuring KFI has access to services necessary for the effective operation of its business. As a result, all litigation against KFI was automatically stayed. By agreement, all AFFF-related litigation against the Company, its other subsidiaries and RTX also was stayed. On November 21, 2023, the Bankruptcy Court ordered certain parties, including the Company, to participate in mediation sessions with respect to claims that might be asserted by and against it in the bankruptcy proceedings.

[0001783180-26-000008:notes:323]
Following the conclusion of these mediation sessions in October 2024, the Company entered into a Settlement and Plan Support Agreement which contemplates that the Company will subsequently enter into three distinct settlement agreements (collectively, the “Proposed Settlement Agreements”) with KFI, the Official Committee of Unsecured Creditors appointed in KFI’s bankruptcy case (the “Committee”) and the Plaintiffs’ Executive Committee (the “MDL PEC”) appointed in the MDL Proceedings.

[0001783180-26-000008:notes:324]
The first of the Proposed Settlement Agreements relates to claims that the Company is responsible for liabilities arising from KFI’s manufacture or sale of AFFF (“Estate Claims Settlement”). Upon Bankruptcy Court approval, the Estate Claims Settlement will permanently resolve all present and future claims that the Company is responsible for any liabilities of KFI, including all liabilities arising from KFI’s manufacture and sale of AFFF. The second and third of the Proposed Settlement Agreements release a very substantial amount of current and future direct claims against the Company (the “Direct Claims Settlements”). Direct claims allege that UTC, which indirectly owned KFI’s AFFF business for eight years, engaged in conduct independent of KFI that caused harm to AFFF claimants. The Company agreed to indemnify UTC for these direct claims when it was spun-off from UTC. Upon approval by the MDL Court, the Direct Claims Settlements resolve and enjoin all current and future AFFF-related direct claims against the Company by participating public water providers and airports. Non-settling parties may still assert direct AFFF-related claims, although we expect a vast majority of public water providers and airports will participate in the Direct Claims Settlements.

[0001783180-26-000008:notes:325]
As part of the Proposed Settlement Agreements, the Company will pay $615 million in cash over five years, 100% of the net sale proceeds from its sale of KFI’s assets to Pacific Avenue Capital Partners, which are estimated to be $115 million, and contribute the right to recover proceeds under certain of its insurance policies. The Company will be entitled to receive up to $2.4 billion of proceeds from those insurance policies and will contribute the first $125 million of such proceeds as additional consideration in the Direct Claims Settlements. The Company also will be entitled to any earnouts payable to KFI under the KFI sale agreement. The Company expects insurance proceeds it receives in the future, in the aggregate, to cover the amount paid under the Proposed Settlement Agreements. As a result of the Proposed Settlement Agreements, the Company recorded a liability in the amount of $565 million during the year December 31, 2024. The amount recognized is in addition to liabilities of $50 million that the Company recorded upon the deconsolidation of KFI on May 14, 2023, as further discussed below. As of December 31, 2025, the Company has not recorded any amounts associated with expected insurance proceeds.

[0001783180-26-000008:notes:326]
The Company and KFI believe that they have meritorious defenses to the remaining AFFF claims. Given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate a range of possible loss at this time. There can be no assurance that any such future exposure will not be material in any period.

[0001783180-26-000008:notes:327]
On November 14, 2024, KFI filed the chapter 11 plan of liquidation (as may be further amended, restated, supplemented, waived, or otherwise modified from time to time, the "Chapter 11 Plan"), which incorporates the Estate Claims Settlement, provides for the treatment of the various creditor classes, and establishes wind-down provisions, among other things, and the disclosure statement for the Chapter 11 Plan (as may be further amended, restated, supplemented, waived, or otherwise modified from time to time, the "Disclosure Statement"). A hearing to approve the Disclosure Statement was held in June 2025. A revised and supplemented Disclosure Statement was filed on August 15, 2025. The Bankruptcy Court held a hearing on that statement on October 6, 2025. Following that hearing, the Bankruptcy Court ordered that the revised and supplemented Disclosure Statement be modified further in two areas, which the parties are addressing.

[0001783180-26-000008:notes:328]
Deconsolidation Due to Bankruptcy

[0001783180-26-000008:notes:329]
As of May 14, 2023, the Company no longer controlled KFI as its activities are subject to review and oversight by the Bankruptcy Court. Therefore, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company’s Consolidated Financial Statements. Upon deconsolidation, the Company determined the fair value of its retained interest in KFI to be zero and accounted for it prospectively using the cost method. As a result of these actions, the Company recognized a net loss of $292 million in its Consolidated Statement of Operations within Discontinued operations, net of tax. In addition, the deconsolidation resulted in an investing cash outflow of $134 million in the Company's Consolidated Statement of Cash Flows within Net cash flows provided by (used in) discontinued investing activities.

[0001783180-26-000008:notes:330]
In connection with the bankruptcy filing, KFI entered into several agreements with subsidiaries of the Company to ensure they have access to services necessary for the effective operation of their business. All post-deconsolidation activity between the Company and KFI are reported as third-party transactions recorded within the Company's Consolidated Statement of Operations. Since the petition date, there were no material transactions between the Company and KFI other than a $15 million payment during 2024 by the Company to KFI under the terms of a tax sharing arrangement.

[0001783180-26-000008:notes:331]
Income Taxes

[0001783180-26-000008:notes:332]
Under the TMA relating to the Separation, the Company is responsible to UTC for its share of the TCJA transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, a liability of $101 million is included within the accompanying Consolidated Balance Sheet within Accrued liabilities as of December 31, 2025. This obligation is expected to be settled in April 2026. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

[0001783180-26-000008:notes:333]
Self-Insurance

[0001783180-26-000008:notes:334]
The Company maintains self-insurance for a number of risks, including but not limited to, workers’ compensation, general liability, automobile liability, property and employee-related healthcare benefits. It has obtained insurance coverage for amounts exceeding individual and aggregate loss limits. The Company accrues for known future claims and incurred but not reported losses.

[0001783180-26-000008:notes:335]
The Company's self-insurance liabilities were as follows:

[0001783180-26-000008:notes:336]
| (In millions) | 2025 |  | 2024 |
| Self-insurance liabilities included in Accrued liabilities | $ | 159 |  |  | $ | 173 |  |
| Self-insurance liabilities included in Other long-term liabilities | 42 |  |  | 43 |
| Total self-insurance liabilities | $ | 201 |  |  | $ | 216 |  |

[0001783180-26-000008:notes:337]
The Company incurred expenses related to self-insured risks of $157 million, $135 million and $139 million for the years ended December 31, 2025, 2024 and 2023, respectively.

[0001783180-26-000008:notes:338]
Other Matters

[0001783180-26-000008:notes:339]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-26-000008:notes:340]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its competitive position, results of operations, cash flows or financial condition.


## us-gaap:CashFlowSupplementalDisclosuresTextBlock

[0001783180-26-000008:notes:341]
SUPPLEMENTAL CASH FLOW INFORMATION 
Supplemental cash flow information was as follows:

[0001783180-26-000008:notes:342]
| (In millions) | 2025 |  | 2024 |  | 2023 |
| Interest paid, net of amounts capitalized | $ | 422 |  |  | $ | 610 |  |  | $ | 320 |  |
| Income taxes paid, net of refunds (1) | $ | 729 |  |  | $ | 2,126 |  |  | $ | 942 |  |
| Non-cash financing activity: |  |  |  |  |  |
| Common stock dividends payable | $ | 201 |  |  | $ | 199 |  |  | $ | 161 |  |

[0001783180-26-000008:notes:343]
(1) Following the adoption of ASU 2023-09, for the year ended December 31, 2025, income taxes paid amounted to $284 million for Federal, $118 million for State, $69 million for China, $56 million for France, $53 million for Mexico, and $198 million to other jurisdictions. In addition, refunds received amounted to $49 million for Germany.
