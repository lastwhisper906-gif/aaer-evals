# CARR note change history — 0001783180-25-000052 → 0001783180-25-000066


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-10-28):
[0001783180-25-000066:note_history:1]
| (In millions) |  | September 30,2025 |  | December 31,2024 |
| Environmental reserves included in Accrued liabilities |  | $ | 13 |  |  | $ | 25 |  |
| Environmental reserves included in Other long-term liabilities |  | 187 |  |  | 185 |  |
| Total Environmental reserves |  | $ | 200 |  |  | $ | 210 |  |
  (was, 2025-07-29, similarity 0.9758):
[0001783180-25-000052:note_history:1]
| (In millions) |  | June 30,2025 |  | December 31,2024 |
| Environmental reserves included in Accrued liabilities |  | $ | 16 |  |  | $ | 25 |  |
| Environmental reserves included in Other long-term liabilities |  | 188 |  |  | 185 |  |
| Total Environmental reserves |  | $ | 204 |  |  | $ | 210 |  |

- changed (2025-10-28):
[0001783180-25-000066:note_history:2]
| (In millions) |  | September 30,2025 |  | December 31,2024 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 201 |  |  | 208 |  |
| Total Asbestos liabilities |  | $ | 218 |  |  | $ | 225 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 6 |  |  | $ | 7 |  |
| Asbestos-related recoveries included in Other assets |  | 86 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 92 |  |  | $ | 95 |  |
  (was, 2025-07-29, similarity 0.9866):
[0001783180-25-000052:note_history:2]
| (In millions) |  | June 30,2025 |  | December 31,2024 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 200 |  |  | 208 |  |
| Total Asbestos liabilities |  | $ | 217 |  |  | $ | 225 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 7 |  |  | $ | 7 |  |
| Asbestos-related recoveries included in Other assets |  | 84 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 91 |  |  | $ | 95 |  |

- changed (2025-10-28):
[0001783180-25-000066:note_history:3]
As of September 30, 2025, the Company, Kidde-Fenwal, Inc. ("KFI") and others have been named as defendants in more than 13,000 lawsuits filed in United States state or federal courts and a single case in Canada alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and damage to property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). Individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.
  (was, 2025-07-29, similarity 0.9935):
[0001783180-25-000052:note_history:3]
As of June 30, 2025, the Company, Kidde-Fenwal, Inc. ("KFI") and others have been named as defendants in more than 12,000 lawsuits filed in United States state or federal courts and a single case in Canada alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and damage to property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). Individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

- changed (2025-10-28):
[0001783180-25-000066:note_history:4]
As part of the Proposed Settlement Agreements, the Company will pay $615 million in cash over five years, 100% of the net sale proceeds from its sale of KFI’s assets to Pacific Avenue Capital Partners, which are estimated to be $115 million, and contribute the right to recover proceeds under certain of its insurance policies. The Company will be entitled to receive up to $2.4 billion of proceeds from those insurance policies and will contribute the first $125 million of such proceeds as additional consideration in the Direct Claims Settlements. The Company also will be entitled to any earnouts payable to KFI under the KFI sale agreement. The Company expects insurance payments it receives in the future, in the aggregate, to cover the amount paid under the Proposed Settlement Agreements. As a result of the Proposed Settlement Agreements, the Company recorded a liability in the amount of $565 million during the three months ended September 30, 2024. The amount recognized is in addition to liabilities of $50 million that the Company recorded upon the deconsolidation of KFI on May 14, 2023, as further discussed below. As of September 30, 2025, the Company has not recorded any amounts associated with expected insurance proceeds.
  (was, 2025-07-29, similarity 0.9946):
[0001783180-25-000052:note_history:4]
As part of the Proposed Settlement Agreements, the Company will pay $615 million in cash over five years, 100% of the net sale proceeds from its sale of KFI’s assets to Pacific Avenue Capital Partners, which are estimated to be $115 million, and contribute the right to recover proceeds under certain of its insurance policies. The Company will be entitled to receive up to $2.4 billion of proceeds from those insurance policies and will contribute the first $125 million of such proceeds as additional consideration in the Direct Claims Settlements. The Company also will be entitled to any earnouts payable to KFI under the KFI sale agreement. The Company expects insurance payments it receives in the future, in the aggregate, to cover the amount paid under the Proposed Settlement Agreements. As a result of the Proposed Settlement Agreements, the Company recorded a liability in the amount of $565 million during the three months ended September 30, 2024. The amount recognized is in addition to liabilities of $50 million that the Company recorded upon the deconsolidation of KFI on May 14, 2023, as further discussed below. As of June 30, 2025, the Company has not recorded any amounts associated with expected insurance proceeds.

- changed (2025-10-28):
[0001783180-25-000066:note_history:5]
On November 14, 2024, KFI filed the chapter 11 plan of liquidation (as may be further amended, restated, supplemented, waived, or otherwise modified from time to time, the "Chapter 11 Plan"), which incorporates the Estate Claims Settlement, provides for the treatment of the various creditor classes, and establishes wind-down provisions, among other things, and the disclosure statement for the Chapter 11 Plan (as may be further amended, restated, supplemented, waived, or otherwise modified from time to time, the "Disclosure Statement"). A hearing to approve the Disclosure Statement was held in June 2025. A revised and supplemented Disclosure Statement was filed on August 15, 2025. The Bankruptcy Court held a hearing on that statement on October 6, 2025. Following that hearing, the Bankruptcy Court ordered that the revised and supplemented Disclosure Statement be modified further in two areas, which the parties are addressing.
  (was, 2025-07-29, similarity 0.7517):
[0001783180-25-000052:note_history:5]
On November 14, 2024, KFI filed the chapter 11 plan of liquidation (as may be further amended, restated, supplemented, waived, or otherwise modified from time to time, the "Chapter 11 Plan"), which incorporates the Estate Claims Settlement, provides for the treatment of the various creditor classes, and establishes wind-down provisions, among other things, and the disclosure statement for the Chapter 11 Plan (as may be further amended, restated, supplemented, waived, or otherwise modified from time to time, the "Disclosure Statement"). A hearing to approve the Disclosure Statement was held in June 2025. The Bankruptcy Court ordered that the Disclosure Statement be revised and supplemented, which the Company expects to be filed in the third quarter of 2025.

- changed (2025-10-28):
[0001783180-25-000066:note_history:6]
Under the TMA relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, a liability of $101 million is included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued liabilities as of September 30, 2025. This obligation is expected to be settled in April 2026. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.
  (was, 2025-07-29, similarity 0.9877):
[0001783180-25-000052:note_history:6]
Under the TMA relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, a liability of $101 million is included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued liabilities as of June 30, 2025. This obligation is expected to be settled in April 2026. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.


## us-gaap:ScheduleOfEnvironmentalLossContingenciesBySiteTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-10-28):
[0001783180-25-000066:note_history:7]
| (In millions) |  | September 30,2025 |  | December 31,2024 |
| Environmental reserves included in Accrued liabilities |  | $ | 13 |  |  | $ | 25 |  |
| Environmental reserves included in Other long-term liabilities |  | 187 |  |  | 185 |  |
| Total Environmental reserves |  | $ | 200 |  |  | $ | 210 |  |
  (was, 2025-07-29, similarity 0.9758):
[0001783180-25-000052:note_history:7]
| (In millions) |  | June 30,2025 |  | December 31,2024 |
| Environmental reserves included in Accrued liabilities |  | $ | 16 |  |  | $ | 25 |  |
| Environmental reserves included in Other long-term liabilities |  | 188 |  |  | 185 |  |
| Total Environmental reserves |  | $ | 204 |  |  | $ | 210 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-10-28):
[0001783180-25-000066:note_history:8]
| (In millions) |  | September 30,2025 |  | December 31,2024 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 201 |  |  | 208 |  |
| Total Asbestos liabilities |  | $ | 218 |  |  | $ | 225 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 6 |  |  | $ | 7 |  |
| Asbestos-related recoveries included in Other assets |  | 86 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 92 |  |  | $ | 95 |  |
  (was, 2025-07-29, similarity 0.9866):
[0001783180-25-000052:note_history:8]
| (In millions) |  | June 30,2025 |  | December 31,2024 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 17 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 200 |  |  | 208 |  |
| Total Asbestos liabilities |  | $ | 217 |  |  | $ | 225 |  |
| Asbestos-related recoveries included in Other current assets |  | $ | 7 |  |  | $ | 7 |  |
| Asbestos-related recoveries included in Other assets |  | 84 |  |  | 88 |  |
| Total Asbestos-related recoveries |  | $ | 91 |  |  | $ | 95 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-10-28):
[0001783180-25-000066:note_history:9]
During 2024, the Company completed several activities designed to simplify its business portfolio, transforming it into a pure-play climate and energy solutions provider. On January 2, 2024, the Company acquired the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (together with its affiliates, “Viessmann”). The VCS Business, primarily reported in the Climate Solutions Europe segment, is a premier residential and light commercial HVAC provider in Europe that expanded the Company's portfolio to offer a global, comprehensive suite of sustainable and innovative building and cold-chain solutions. In addition, the Company divested its Commercial and Residential Fire, Access Solutions and Industrial Fire businesses which were historically reported in its Fire & Security segment. The transactions represented a single disposal plan to separately divest multiple businesses over different reporting periods and met the criteria to be presented as discontinued operations in the accompanying financial statements. The Company also divested its Commercial Refrigeration business (“CCR”) during 2024. CCR, which was historically reported in the Climate Solutions Transportation segment (previously named Refrigeration), did not meet the criteria to be presented as discontinued operations.
  (was, 2025-07-29, similarity 0.9939):
[0001783180-25-000052:note_history:9]
During 2024, the Company completed several activities designed to simplify its business portfolio, transforming it into a pure-play climate and energy solutions provider. On January 2, 2024, the Company acquired the climate solutions business (the "VCS Business") of Viessmann Group GmbH & Co. KG (together with its affiliates, “Viessmann”). The VCS Business, primarily reported in the Climate Solutions Europe segment, is a premier residential and light commercial HVAC provider in Europe that expanded our portfolio to offer a global, comprehensive suite of sustainable and innovative building and cold-chain solutions. In addition, the Company divested its Commercial and Residential Fire, Access Solutions and Industrial Fire businesses which were historically reported in its Fire & Security segment. The transactions represented a single disposal plan to separately divest multiple businesses over different reporting periods and met the criteria to be presented as discontinued operations in the accompanying financial statements. The Company also divested its Commercial Refrigeration business (“CCR”) during 2024. CCR, which was historically reported in the Climate Solutions Transportation segment (previously named Refrigeration), did not meet the criteria to be presented as discontinued operations.

- changed (2025-10-28):
[0001783180-25-000066:note_history:10]
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In addition, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of September 30, 2025, only certain portions of the Tax Matters Agreement ("TMA") remain in effect.
  (was, 2025-07-29, similarity 0.9919):
[0001783180-25-000052:note_history:10]
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In addition, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis. As of June 30, 2025, only certain portions of the Tax Matters Agreement ("TMA") remain in effect.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-10-28):
[0001783180-25-000066:note_history:11]
In the opinion of management, the accompanying Unaudited Condensed Consolidated Financial Statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (the "SEC"). The accompanying Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for 2024 filed with the SEC on February 11, 2025 (the "2024 Form 10-K"). Certain prior period amounts have been reclassified to conform to the current period financial statement presentation.
  (was, 2025-07-29, similarity 0.9359):
[0001783180-25-000052:note_history:11]
In the opinion of management, the accompanying Unaudited Condensed Consolidated Financial Statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (the "SEC"). The accompanying Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for 2024 filed with the SEC on February 11, 2025 (the "2024 Form 10-K").


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-10-28):
[0001783180-25-000066:note_history:12]
BORROWINGS AND LINES OF CREDIT
Short-term borrowings and current portion of long-term debt consisted of the following:
  (was, 2025-07-29, similarity 0.7644):
[0001783180-25-000052:note_history:12]
BORROWINGS AND LINES OF CREDIT
Long-term debt consisted of the following:

- added (2025-10-28):
[0001783180-25-000066:note_history:13]
| (In millions) |  |  |  | September 30,2025 |  | December 31,2024 |
| Commercial paper |  |  |  | $ | 415 |  |  | $ | — |  |
| Short-term borrowings |  |  |  | 58 |  |  | 84 |  |
| Current portion of long-term debt |  |  |  | 107 |  |  | 1,252 |  |
| Short-term borrowings and current portion of long-term debt |  |  |  | $ | 580 |  |  | $ | 1,336 |  |

- added (2025-10-28):
[0001783180-25-000066:note_history:14]
The Company has a $2.0 billion USD-denominated facility and a $500 million Euro-denominated facility as part of an unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes including the funding of working capital and potential acquisitions. At September 30, 2025, the Company had $415 million outstanding under its USD-denominated commercial paper facility, with a weighted average rate of 4.28%.

- added (2025-10-28):
[0001783180-25-000066:note_history:15]
Long-term debt consisted of the following:

- changed (2025-10-28):
[0001783180-25-000066:note_history:16]
| (In millions) |  |  |  | September 30,2025 |  | December 31,2024 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | — |  |  | $ | 1,200 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 875 |  |  | 783 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 992 |  |  | 887 |  |
| 5.900% Notes due 2034 |  |  |  | 875 |  |  | 875 |  |
| 3.625% Notes due 2037 |  |  |  | 875 |  |  | 783 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 1,400 |  |  | 1,400 |  |
| 6.200% Notes due 2054 |  |  |  | 650 |  |  | 650 |  |
| Total long-term notes |  |  |  | 10,817 |  |  | 11,728 |  |
| Japanese Term Loan Facility |  |  |  | 360 |  |  | 342 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 347 |  |  | 296 |  |
| Discounts and debt issuance costs |  |  |  | (81) |  |  | (88) |  |
| Total long-term debt |  |  |  | 11,443 |  |  | 12,278 |  |
| Less: current portion of long-term debt |  |  |  | 107 |  |  | 1,252 |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,336 |  |  | $ | 11,026 |  |
  (was, 2025-07-29, similarity 0.9181):
[0001783180-25-000052:note_history:16]
| (In millions) |  |  |  | June 30,2025 |  | December 31,2024 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | — |  |  | $ | 1,200 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 878 |  |  | 783 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 995 |  |  | 887 |  |
| 5.900% Notes due 2034 |  |  |  | 875 |  |  | 875 |  |
| 3.625% Notes due 2037 |  |  |  | 878 |  |  | 783 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 1,400 |  |  | 1,400 |  |
| 6.200% Notes due 2054 |  |  |  | 650 |  |  | 650 |  |
| Total long-term notes |  |  |  | 10,826 |  |  | 11,728 |  |
| Japanese Term Loan Facility |  |  |  | 374 |  |  | 342 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 326 |  |  | 296 |  |
| Discounts and debt issuance costs |  |  |  | (83) |  |  | (88) |  |
| Total debt |  |  |  | 11,443 |  |  | 12,278 |  |
| Less: current portion of long-term debt |  |  |  | 107 |  |  | 1,252 |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,336 |  |  | $ | 11,026 |  |

- changed (2025-10-28):
[0001783180-25-000066:note_history:17]
On December 20, 2024, the Company refinanced its revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.5 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in December 2029 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. Upon entering into the agreement, the Company capitalized $11 million of deferred financing costs which are being amortized over its term. As of September 30, 2025, there were no borrowings outstanding under the Revolving Credit Facility.
  (was, 2025-07-29, similarity 0.9939):
[0001783180-25-000052:note_history:17]
On December 20, 2024, the Company refinanced its revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.5 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in December 2029 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. Upon entering into the agreement, the Company capitalized $11 million of deferred financing costs which are being amortized over its term. As of June 30, 2025, there were no borrowings outstanding under the Revolving Credit Facility.

- added (2025-10-28):
[0001783180-25-000066:note_history:18]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $22 million and $40 million of debt during the nine months ended September 30, 2025 and 2024, respectively. Long-term debt repayments associated with these financing arrangements during the nine months ended September 30, 2025 and 2024, were zero and $7 million, respectively.

- changed (2025-10-28):
[0001783180-25-000066:note_history:19]
The Revolving Credit Facility, the indenture for the long-term notes and the five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility ("Japanese Term Loan Facility") contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur certain liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of September 30, 2025, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.
  (was, 2025-07-29, similarity 0.8056):
[0001783180-25-000052:note_history:19]
The Revolving Credit Facility, the indenture for the long-term notes and the five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility ("Japanese Term Loan Facility") contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur certain liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of June 30, 2025, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

- removed (2025-10-28):
[0001783180-25-000052:note_history:20]
The Company has a $2.0 billion USD-denominated unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of June 30, 2025, there were no borrowings outstanding under the commercial paper program.

- removed (2025-10-28):
[0001783180-25-000052:note_history:21]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $10 million and $20 million of debt during the six months ended June 30, 2025 and 2024, respectively. Long-term debt repayments associated with these financing arrangements during the six months ended June 30, 2025 and 2024, were zero and $6 million, respectively.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-10-28):
[0001783180-25-000066:note_history:22]
| (In millions) |  |  |  | September 30,2025 |  | December 31,2024 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | — |  |  | $ | 1,200 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 875 |  |  | 783 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 992 |  |  | 887 |  |
| 5.900% Notes due 2034 |  |  |  | 875 |  |  | 875 |  |
| 3.625% Notes due 2037 |  |  |  | 875 |  |  | 783 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 1,400 |  |  | 1,400 |  |
| 6.200% Notes due 2054 |  |  |  | 650 |  |  | 650 |  |
| Total long-term notes |  |  |  | 10,817 |  |  | 11,728 |  |
| Japanese Term Loan Facility |  |  |  | 360 |  |  | 342 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 347 |  |  | 296 |  |
| Discounts and debt issuance costs |  |  |  | (81) |  |  | (88) |  |
| Total long-term debt |  |  |  | 11,443 |  |  | 12,278 |  |
| Less: current portion of long-term debt |  |  |  | 107 |  |  | 1,252 |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,336 |  |  | $ | 11,026 |  |
  (was, 2025-07-29, similarity 0.9181):
[0001783180-25-000052:note_history:22]
| (In millions) |  |  |  | June 30,2025 |  | December 31,2024 |
| 2.242% Notes due 2025 (1) |  |  |  | $ | — |  |  | $ | 1,200 |  |
| 2.493% Notes due 2027 |  |  |  | 900 |  |  | 900 |  |
| 4.125% Notes due 2028 |  |  |  | 878 |  |  | 783 |  |
| 2.722% Notes due 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due 2031 |  |  |  | 750 |  |  | 750 |  |
| 4.500% Notes due 2032 |  |  |  | 995 |  |  | 887 |  |
| 5.900% Notes due 2034 |  |  |  | 875 |  |  | 875 |  |
| 3.625% Notes due 2037 |  |  |  | 878 |  |  | 783 |  |
| 3.377% Notes due 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due 2050 |  |  |  | 1,400 |  |  | 1,400 |  |
| 6.200% Notes due 2054 |  |  |  | 650 |  |  | 650 |  |
| Total long-term notes |  |  |  | 10,826 |  |  | 11,728 |  |
| Japanese Term Loan Facility |  |  |  | 374 |  |  | 342 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 326 |  |  | 296 |  |
| Discounts and debt issuance costs |  |  |  | (83) |  |  | (88) |  |
| Total debt |  |  |  | 11,443 |  |  | 12,278 |  |
| Less: current portion of long-term debt |  |  |  | 107 |  |  | 1,252 |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,336 |  |  | $ | 11,026 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2025-10-28):
[0001783180-25-000066:note_history:23]
Short-term borrowings and current portion of long-term debt consisted of the following:

- added (2025-10-28):
[0001783180-25-000066:note_history:24]
| (In millions) |  |  |  | September 30,2025 |  | December 31,2024 |
| Commercial paper |  |  |  | $ | 415 |  |  | $ | — |  |
| Short-term borrowings |  |  |  | 58 |  |  | 84 |  |
| Current portion of long-term debt |  |  |  | 107 |  |  | 1,252 |  |
| Short-term borrowings and current portion of long-term debt |  |  |  | $ | 580 |  |  | $ | 1,336 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2025-10-28):
[0001783180-25-000066:note_history:25]
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Sales to equity method investees included in Product sales |  | $ | 668 |  |  | $ | 774 |  |  | $ | 2,293 |  |  | $ | 2,329 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 68 |  |  | $ | 64 |  |  | $ | 172 |  |  | $ | 178 |  |

- added (2025-10-28):
[0001783180-25-000066:note_history:26]
| (In millions) |  | September 30,2025 |  | December 31,2024 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 255 |  |  | $ | 363 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 40 |  |  | $ | 32 |  |

- removed (2025-10-28):
[0001783180-25-000052:note_history:27]
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Sales to equity method investees included in Product sales |  | $ | 845 |  |  | $ | 832 |  |  | $ | 1,625 |  |  | $ | 1,555 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 57 |  |  | $ | 59 |  |  | $ | 104 |  |  | $ | 114 |  |

- removed (2025-10-28):
[0001783180-25-000052:note_history:28]
| (In millions) |  | June 30,2025 |  | December 31,2024 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 485 |  |  | $ | 363 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 32 |  |  | $ | 32 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-10-28):
[0001783180-25-000066:note_history:29]
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,393 |  |  | $ | 2,669 |  |  | $ | 7,682 |  |  | $ | 7,359 |  |
| Service |  | 318 |  |  | 292 |  |  | 853 |  |  | 827 |  |
| Climate Solutions Americas sales |  | 2,711 |  |  | 2,961 |  |  | 8,535 |  |  | 8,186 |  |
| Product |  | 1,168 |  |  | 1,150 |  |  | 3,376 |  |  | 3,515 |  |
| Service |  | 122 |  |  | 96 |  |  | 336 |  |  | 217 |  |
| Climate Solutions Europe sales |  | 1,290 |  |  | 1,246 |  |  | 3,712 |  |  | 3,732 |  |
| Product |  | 659 |  |  | 678 |  |  | 2,016 |  |  | 2,153 |  |
| Service |  | 174 |  |  | 162 |  |  | 525 |  |  | 473 |  |
| Climate Solutions Asia Pacific, Middle East & Africa sales |  | 833 |  |  | 840 |  |  | 2,541 |  |  | 2,626 |  |
| Product |  | 686 |  |  | 810 |  |  | 1,961 |  |  | 2,433 |  |
| Service |  | 59 |  |  | 127 |  |  | 161 |  |  | 361 |  |
| Climate Solutions Transportation sales |  | 745 |  |  | 937 |  |  | 2,122 |  |  | 2,794 |  |
| Net sales |  | $ | 5,579 |  |  | $ | 5,984 |  |  | $ | 16,910 |  |  | $ | 17,338 |  |
  (was, 2025-07-29, similarity 0.972):
[0001783180-25-000052:note_history:29]
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,970 |  |  | $ | 2,586 |  |  | $ | 5,289 |  |  | $ | 4,690 |  |
| Service |  | 282 |  |  | 279 |  |  | 535 |  |  | 535 |  |
| Climate Solutions Americas sales |  | 3,252 |  |  | 2,865 |  |  | 5,824 |  |  | 5,225 |  |
| Product |  | 1,137 |  |  | 1,127 |  |  | 2,208 |  |  | 2,365 |  |
| Service |  | 116 |  |  | 67 |  |  | 214 |  |  | 121 |  |
| Climate Solutions Europe sales |  | 1,253 |  |  | 1,194 |  |  | 2,422 |  |  | 2,486 |  |
| Product |  | 697 |  |  | 747 |  |  | 1,357 |  |  | 1,475 |  |
| Service |  | 185 |  |  | 155 |  |  | 351 |  |  | 311 |  |
| Climate Solutions Asia Pacific, Middle East & Africa sales |  | 882 |  |  | 902 |  |  | 1,708 |  |  | 1,786 |  |
| Product |  | 673 |  |  | 851 |  |  | 1,275 |  |  | 1,623 |  |
| Service |  | 53 |  |  | 122 |  |  | 102 |  |  | 234 |  |
| Climate Solutions Transportation sales |  | 726 |  |  | 973 |  |  | 1,377 |  |  | 1,857 |  |
| Net sales |  | $ | 6,113 |  |  | $ | 5,934 |  |  | $ | 11,331 |  |  | $ | 11,354 |  |

- changed (2025-10-28):
[0001783180-25-000066:note_history:30]
Geographic external sales are attributed to the geographic regions based on their location of origin. With the exception of the United States as presented in the table below, there were no individually significant countries with sales exceeding 10% of total sales during the three and nine months ended September 30, 2025 and 2024.
  (was, 2025-07-29, similarity 0.9391):
[0001783180-25-000052:note_history:30]
Geographic external sales are attributed to the geographic regions based on their location of origin. With the exception of the U.S. presented in the table below, there were no individually significant countries with sales exceeding 10% of total sales during the three and six months ended June 30, 2025 and 2024.

- changed (2025-10-28):
[0001783180-25-000066:note_history:31]
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| United States |  | $ | 2,860 |  |  | $ | 3,154 |  |  | $ | 9,027 |  |  | $ | 8,778 |  |
| International: |  |  |  |  |  |  |  |  |
| Europe |  | 1,560 |  |  | 1,723 |  |  | 4,481 |  |  | 5,152 |  |
| Asia Pacific |  | 961 |  |  | 923 |  |  | 2,883 |  |  | 2,886 |  |
| Other |  | 198 |  |  | 184 |  |  | 519 |  |  | 522 |  |
| Net sales |  | $ | 5,579 |  |  | $ | 5,984 |  |  | $ | 16,910 |  |  | $ | 17,338 |  |
  (was, 2025-07-29, similarity 0.9394):
[0001783180-25-000052:note_history:31]
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| United States |  | $ | 3,429 |  |  | $ | 3,077 |  |  | $ | 6,168 |  |  | $ | 5,624 |  |
| International: |  |  |  |  |  |  |  |  |
| Europe |  | 1,520 |  |  | 1,678 |  |  | 2,920 |  |  | 3,429 |  |
| Asia Pacific |  | 981 |  |  | 1,003 |  |  | 1,922 |  |  | 1,963 |  |
| Other |  | 183 |  |  | 176 |  |  | 321 |  |  | 338 |  |
| Net sales |  | $ | 6,113 |  |  | $ | 5,934 |  |  | $ | 11,331 |  |  | $ | 11,354 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-10-28):
[0001783180-25-000066:note_history:32]
|  |  | Three Months Ended September 30, |  | Nine Months EndedSeptember 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,393 |  |  | $ | 2,669 |  |  | $ | 7,682 |  |  | $ | 7,359 |  |
| Service |  | 318 |  |  | 292 |  |  | 853 |  |  | 827 |  |
| Climate Solutions Americas sales |  | 2,711 |  |  | 2,961 |  |  | 8,535 |  |  | 8,186 |  |
| Product |  | 1,168 |  |  | 1,150 |  |  | 3,376 |  |  | 3,515 |  |
| Service |  | 122 |  |  | 96 |  |  | 336 |  |  | 217 |  |
| Climate Solutions Europe sales |  | 1,290 |  |  | 1,246 |  |  | 3,712 |  |  | 3,732 |  |
| Product |  | 659 |  |  | 678 |  |  | 2,016 |  |  | 2,153 |  |
| Service |  | 174 |  |  | 162 |  |  | 525 |  |  | 473 |  |
| Climate Solutions Asia Pacific, Middle East & Africa sales |  | 833 |  |  | 840 |  |  | 2,541 |  |  | 2,626 |  |
| Product |  | 686 |  |  | 810 |  |  | 1,961 |  |  | 2,433 |  |
| Service |  | 59 |  |  | 127 |  |  | 161 |  |  | 361 |  |
| Climate Solutions Transportation sales |  | 745 |  |  | 937 |  |  | 2,122 |  |  | 2,794 |  |
| Net sales |  | $ | 5,579 |  |  | $ | 5,984 |  |  | $ | 16,910 |  |  | $ | 17,338 |  |
  (was, 2025-07-29, similarity 0.972):
[0001783180-25-000052:note_history:32]
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,970 |  |  | $ | 2,586 |  |  | $ | 5,289 |  |  | $ | 4,690 |  |
| Service |  | 282 |  |  | 279 |  |  | 535 |  |  | 535 |  |
| Climate Solutions Americas sales |  | 3,252 |  |  | 2,865 |  |  | 5,824 |  |  | 5,225 |  |
| Product |  | 1,137 |  |  | 1,127 |  |  | 2,208 |  |  | 2,365 |  |
| Service |  | 116 |  |  | 67 |  |  | 214 |  |  | 121 |  |
| Climate Solutions Europe sales |  | 1,253 |  |  | 1,194 |  |  | 2,422 |  |  | 2,486 |  |
| Product |  | 697 |  |  | 747 |  |  | 1,357 |  |  | 1,475 |  |
| Service |  | 185 |  |  | 155 |  |  | 351 |  |  | 311 |  |
| Climate Solutions Asia Pacific, Middle East & Africa sales |  | 882 |  |  | 902 |  |  | 1,708 |  |  | 1,786 |  |
| Product |  | 673 |  |  | 851 |  |  | 1,275 |  |  | 1,623 |  |
| Service |  | 53 |  |  | 122 |  |  | 102 |  |  | 234 |  |
| Climate Solutions Transportation sales |  | 726 |  |  | 973 |  |  | 1,377 |  |  | 1,857 |  |
| Net sales |  | $ | 6,113 |  |  | $ | 5,934 |  |  | $ | 11,331 |  |  | $ | 11,354 |  |

- changed (2025-10-28):
[0001783180-25-000066:note_history:33]
| (In millions) |  | September 30,2025 |  | December 31,2024 |
| Contract assets (included within Other current assets) |  | $ | 520 |  |  | $ | 366 |  |
| Contract assets, non-current (included within Other assets) |  | 55 |  |  | 65 |  |
| Total contract assets |  | 575 |  |  | 431 |  |
| Contract liabilities (included within Accrued liabilities) |  | (546) |  |  | (553) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (186) |  |  | (164) |  |
| Total contract liabilities |  | (732) |  |  | (717) |  |
| Net contract assets (liabilities) |  | $ | (157) |  |  | $ | (286) |  |
  (was, 2025-07-29, similarity 0.9883):
[0001783180-25-000052:note_history:33]
| (In millions) |  | June 30,2025 |  | December 31,2024 |
| Contract assets (included within Other current assets) |  | $ | 474 |  |  | $ | 366 |  |
| Contract assets, non-current (included within Other assets) |  | 47 |  |  | 65 |  |
| Total contract assets |  | 521 |  |  | 431 |  |
| Contract liabilities (included within Accrued liabilities) |  | (549) |  |  | (553) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (178) |  |  | (164) |  |
| Total contract liabilities |  | (727) |  |  | (717) |  |
| Net contract assets (liabilities) |  | $ | (206) |  |  | $ | (286) |  |

- changed (2025-10-28):
[0001783180-25-000066:note_history:34]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.
The Company recognized revenue of $491 million during the nine months ended September 30, 2025, that related to contract liabilities as of January 1, 2025. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.
  (was, 2025-07-29, similarity 0.7993):
[0001783180-25-000052:note_history:34]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.
The Company recognized revenue of $340 million during the six months ended June 30, 2025, that related to contract liabilities as of January 1, 2025. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.
