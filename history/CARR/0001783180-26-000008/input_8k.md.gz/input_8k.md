# CARR 8-K — 0001783180-26-000005 filed 2026-02-05

## item codes, every 8-K on or before 2026-02-05

- 2026-02-05 0001783180-26-000005 — 2.02
- 2025-10-28 0001783180-25-000063 — 2.02, 7.01, 9.01
- 2025-09-04 0000950142-25-002375 — 5.02
- 2025-07-29 0001783180-25-000058 — 8.01, 9.01
- 2025-07-29 0001783180-25-000047 — 2.02, 9.01
- 2025-06-05 0000950142-25-001575 — 7.01
- 2025-05-01 0001783180-25-000028 — 2.02, 7.01, 9.01
- 2025-04-17 0000950142-25-001103 — 5.02
- 2025-04-11 0001783180-25-000021 — 5.02, 5.07, 9.01
- 2025-02-11 0001783180-25-000006 — 2.02, 9.01
- 2025-01-15 0000950142-25-000133 — 5.02, 9.01
- 2024-12-20 0001783180-24-000093 — 1.01, 1.02, 2.03, 9.01
- 2024-12-03 0000950142-24-002874 — 5.02
- 2024-12-02 0000950142-24-002865 — 7.01, 9.01
- 2024-11-08 0000950142-24-002699 — 1.01, 2.03, 9.01
- 2024-10-28 0000950142-24-002640 — 8.01
- 2024-10-28 0000950142-24-002638 — 8.01
- 2024-10-24 0001783180-24-000084 — 2.02, 7.01, 9.01
- 2024-10-18 0000950142-24-002601 — 1.01
- 2024-08-15 0001140361-24-037426 — 7.01, 9.01
- 2024-07-25 0001783180-24-000075 — 2.02, 9.01
- 2024-06-21 0001783180-24-000069 — 5.02
- 2024-06-21 0000950142-24-001676 — 5.02
- 2024-06-07 0001783180-24-000062 — 5.02, 5.03, 9.01
- 2024-06-03 0000950142-24-001538 — 1.02, 7.01, 9.01
- 2024-05-17 0001783180-24-000049 — 1.01, 1.02, 2.03, 9.01
- 2024-04-25 0001783180-24-000042 — 2.02, 9.01
- 2024-04-19 0001783180-24-000035 — 5.07, 9.01
- 2024-04-19 0000950142-24-001162 — 5.07 — amendment of 0001783180-24-000035
- 2024-02-06 0001783180-24-000007 — 2.02, 9.01
- 2024-02-01 0000950142-24-000264 — 5.02
- 2024-01-02 0001140361-24-000034 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2023-12-13 0001140361-23-057415 — 1.01, 9.01
- 2023-12-08 0001140361-23-056751 — 7.01, 9.01
- 2023-11-30 0000950142-23-002884 — 1.01, 2.03, 8.01, 9.01
- 2023-11-16 0000950142-23-002788 — 8.01, 9.01
- 2023-11-13 0001140361-23-052667 — 7.01, 8.01, 9.01
- 2023-10-26 0001783180-23-000063 — 2.02, 9.01
- 2023-07-27 0001783180-23-000053 — 2.02, 9.01
- 2023-06-12 0000950142-23-001664 — 5.02
- 2023-05-25 0000950142-23-001541 — 1.01, 1.02, 2.03, 9.01
- 2023-04-26 0000950142-23-001205 — 1.01, 9.01
- 2023-04-25 0001783180-23-000036 — 2.02, 7.01, 9.01
- 2023-04-25 0000950142-23-001199 — 7.01, 8.01, 9.01
- 2023-04-21 0001783180-23-000032 — 5.07, 9.01
- 2023-02-07 0001783180-23-000010 — 2.02, 9.01
- 2022-10-27 0001783180-22-000054 — 2.02, 7.01, 9.01
- 2022-09-29 0000950142-22-002805 — 5.02, 9.01
- 2022-07-28 0001783180-22-000045 — 2.02, 9.01
- 2022-04-28 0001783180-22-000032 — 2.02, 9.01
- 2022-04-15 0001783180-22-000024 — 5.07, 9.01
- 2022-02-08 0001783180-22-000008 — 2.02, 9.01
- 2022-02-07 0000950142-22-000510 — 8.01, 9.01
- 2022-01-03 0000950142-22-000023 — 8.01, 9.01
- 2021-12-17 0001783180-21-000071 — 5.02, 7.01, 9.01
- 2021-11-23 0001783180-21-000068 — 5.03, 9.01
- 2021-10-28 0001783180-21-000062 — 2.02, 9.01
- 2021-08-27 0001783180-21-000056 — 8.01
- 2021-07-30 0001783180-21-000053 — 1.01
- 2021-07-29 0001783180-21-000049 — 2.02, 8.01, 9.01
- 2021-07-27 0000950142-21-002448 — 8.01, 9.01
- 2021-07-15 0000950142-21-002362 — 5.02, 9.01
- 2021-06-09 0000950142-21-001885 — 5.02, 9.01
- 2021-04-29 0001783180-21-000029 — 2.02, 9.01
- 2021-04-22 0001140361-21-013889 — 5.02, 9.01
- 2021-04-20 0001783180-21-000021 — 5.07, 9.01
- 2021-04-19 0000950142-21-001308 — 8.01, 9.01
- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2026-02-05

- none on or before 2026-02-05

## item 2.02 — earnings release, exhibit 99.1

[0001783180-26-000005:8k_2_02:1]
EX-99
2
a8-kerexhibit99xq42025.htm
EX-99

[0001783180-26-000005:8k_2_02:2]
Document

[0001783180-26-000005:8k_2_02:3]
Exhibit 99

[0001783180-26-000005:8k_2_02:4]
Carrier Reports 2025 Results and Announces 2026 Outlook

[0001783180-26-000005:8k_2_02:5]
Fourth Quarter 2025 Results

[0001783180-26-000005:8k_2_02:6]
•Net sales down 6%; organic sales down 9%

[0001783180-26-000005:8k_2_02:7]
•GAAP EPS from continuing operations of $0.03 and adjusted EPS of $0.34

[0001783180-26-000005:8k_2_02:8]
•Net cash flows from operating activities were $1,040 million and free cash flow was $909 million

[0001783180-26-000005:8k_2_02:9]
Full Year 2025 Results

[0001783180-26-000005:8k_2_02:10]
•Sales of $21.75 billion, down 3% compared to 2024, organic sales down 1%

[0001783180-26-000005:8k_2_02:11]
•Global commercial HVAC1 and aftermarket1 up double-digits

[0001783180-26-000005:8k_2_02:12]
•GAAP EPS from continuing operations of $1.69 and adjusted EPS of $2.59

[0001783180-26-000005:8k_2_02:13]
•Operating margin of 10.0% and adjusted operating margin of 15.1%

[0001783180-26-000005:8k_2_02:14]
•Returned ~$3.7 billion to shareholders, including ~$0.8 billion in dividends and ~$2.9 billion in share repurchases

[0001783180-26-000005:8k_2_02:15]
PALM BEACH GARDENS, Fla., February 5, 2026 – Carrier Global Corporation (NYSE:CARR), global leader in intelligent climate and energy solutions, today reported financial results for the fourth quarter and full year of 2025.

[0001783180-26-000005:8k_2_02:16]
“We continue to drive outsized growth in commercial HVAC1 with Q4 orders up nearly 50% driven by key data center wins and are well positioned to drive our sixth consecutive year of double-digit growth in this business in 2026. Our aftermarket1 playbook also continues to yield results, reflected in our fifth consecutive year of double-digit growth. We continue to control the controllables, reducing discretionary costs and building backlog in our long-cycle businesses to mitigate residential market challenges," said Carrier Chairman & CEO David Gitlin.

[0001783180-26-000005:8k_2_02:17]
1  Excludes NORESCO

[0001783180-26-000005:8k_2_02:18]
1

[0001783180-26-000005:8k_2_02:19]
Fourth Quarter 2025 Results

[0001783180-26-000005:8k_2_02:20]
Total Company

[0001783180-26-000005:8k_2_02:21]
|  | (Unaudited) |
|  | Three Months Ended December 31 |
| (In millions) | 2025 | 2024 | Change |
| Net sales | $ | 4,837 |  | $ | 5,148 |  | (6) | % |
| Organic sales | (9) | % |  |  |
| Operating profit | $ | 101 |  | $ | 774 |  | (87) | % |
| Operating margin | 2.1 | % | 15.0 | % | (1,290) bps |
| Adjusted operating profit | $ | 455 |  | $ | 678 |  | (33) | % |
| Adjusted operating margin | 9.4 | % | 13.2 | % | (380) bps |
| Diluted earnings per share: |  |  |  |
| Continuing operations | $ | 0.03 |  | $ | (0.05) |  | (160) | % |
| Continuing operations - Adjusted | $ | 0.34 |  | $ | 0.54 |  | (37) | % |

[0001783180-26-000005:8k_2_02:22]
Carrier’s fourth quarter sales of $4.8 billion decreased 6% versus the prior year, with organic sales down 9%, partially offset by a 3% tailwind from foreign currency translation.

[0001783180-26-000005:8k_2_02:23]
GAAP operating profit of $101 million in the quarter declined 87% from last year reflecting the prior year gain from the sale of our commercial refrigeration business, weaker residential end-markets and distributor destocking in the Americas. This was partially offset by the continued strength in our global commercial HVAC and aftermarket businesses and operating efficiencies.

[0001783180-26-000005:8k_2_02:24]
Adjusted operating profit of $455 million was down 33% primarily due to lower volume in our Climate Solutions Americas residential business, partially offset by profit growth in Climate Solutions Europe and Climate Solutions Transportation. Net earnings from continued operations were $28 million and adjusted net earnings from continuing operations were $285 million. GAAP EPS from continuing operations was $0.03 and adjusted EPS was $0.34. The declines versus the prior year were primarily driven by lower operating profit, partially offset by the benefit of a lower share count.

[0001783180-26-000005:8k_2_02:25]
2

[0001783180-26-000005:8k_2_02:26]
Climate Solutions Americas (CSA)

[0001783180-26-000005:8k_2_02:27]
|  | (Unaudited) |
|  | Three Months Ended December 31, |
| (In millions) | 2025 | 2024 | Change |
| Net sales | $ | 1,935 |  | $ | 2,341 |  | (17) | % |
| Organic sales | (17) | % |  |  |
| Segment operating profit | $ | 168 |  | $ | 435 |  | (61) | % |
| Segment operating margin | 8.7 | % | 18.6 | % | (990) bps |

[0001783180-26-000005:8k_2_02:28]
CSA segment sales declined 17%. Organic sales were down 17% with continued strength in Commercial1, up double digits, more than offset by lower volumes in Residential, down 38%, and Light Commercial down 20%.

[0001783180-26-000005:8k_2_02:29]
Segment operating margin declined 10 points, reflecting the significant volume decline in the Residential and Light Commercial businesses.

[0001783180-26-000005:8k_2_02:30]
Climate Solutions Europe (CSE)

[0001783180-26-000005:8k_2_02:31]
|  | (Unaudited) |
|  | Three Months Ended December 31, |
| (In millions) | 2025 | 2024 | Change |
| Net sales | $ | 1,332 |  | $ | 1,252 |  | 6 | % |
| Organic sales | (2) | % |  |  |
| Segment operating profit | $ | 120 |  | $ | 80 |  | 50 | % |
| Segment operating margin | 9.0 | % | 6.4 | % | 260 bps |

[0001783180-26-000005:8k_2_02:32]
CSE segment sales increased 6%. Organic sales were down 2% with Commercial up mid-single digits and Residential and Light Commercial down mid-single digits.

[0001783180-26-000005:8k_2_02:33]
Segment operating margin increased over 250 basis points driven by strong productivity, including cost synergies, partially offset by lower organic sales and mix.

[0001783180-26-000005:8k_2_02:34]
1 Excludes NORESCO

[0001783180-26-000005:8k_2_02:35]
3

[0001783180-26-000005:8k_2_02:36]
Climate Solutions Asia Pacific, Middle East & Africa (CSAME)

[0001783180-26-000005:8k_2_02:37]
|  | (Unaudited) |
|  | Three Months Ended December 31, |
| (In millions) | 2025 | 2024 | Change |
| Net sales | $ | 798 |  | $ | 874 |  | (9) | % |
| Organic sales | (9) | % |  |  |
| Segment operating profit | $ | 95 |  | $ | 95 |  | — | % |
| Segment operating margin | 11.9 | % | 10.9 | % | 100 bps |

[0001783180-26-000005:8k_2_02:38]
CSAME segment sales declined 9%. Organic sales were down 9% mainly driven by Residential and Light Commercial (RLC) in China, partially offset by modest growth in the rest of Asia.

[0001783180-26-000005:8k_2_02:39]
Segment operating margin increased 100 basis points driven by strong productivity partially offset by lower sales.

[0001783180-26-000005:8k_2_02:40]
Climate Solutions Transportation (CST)

[0001783180-26-000005:8k_2_02:41]
|  | (Unaudited) |
|  | Three Months Ended December 31, |
| (In millions) | 2025 | 2024 | Change |
| Net sales | $ | 772 |  | $ | 681 |  | 13 | % |
| Organic sales | 10 | % |  |  |
| Segment operating profit | $ | 112 |  | $ | 97 |  | 15 | % |
| Segment operating margin | 14.5 | % | 14.2 | % | 30 bps |

[0001783180-26-000005:8k_2_02:42]
CST sales increased 13%. Organic sales increased 10% with nearly 50% growth in Container and Global Truck and Trailer flat.

[0001783180-26-000005:8k_2_02:43]
Segment operating margin increased 30 basis points largely due to organic growth and productivity, offset by business mix.

[0001783180-26-000005:8k_2_02:44]
4

[0001783180-26-000005:8k_2_02:45]
Cash Flow

[0001783180-26-000005:8k_2_02:46]
|  |  | (Unaudited) |  | (Unaudited) |
|  |  | Three Months Ended December 31, |  | Year Ended December 31, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net cash flows provided by operating activities |  | $ | 1,040 |  |  | $ | 132 |  |  | $ | 2,513 |  |  | $ | 563 |  |
| Less: Capital expenditures - continuing operations |  | (131) |  |  | (217) |  |  | (392) |  |  | (519) |  |
| Less: Capital expenditures - discontinued operations |  | — |  |  | (4) |  |  | — |  |  | (14) |  |
| Free cash flow |  | $ | 909 |  |  | $ | (89) |  |  | $ | 2,121 |  |  | $ | 30 |  |

[0001783180-26-000005:8k_2_02:47]
Net cash flows generated from operating activities were $1,040 million and capital expenditures were $131 million, resulting in free cash flow of $909 million.

[0001783180-26-000005:8k_2_02:48]
Full-Year 2026 Guidance

[0001783180-26-000005:8k_2_02:49]
Carrier expects continued double-digit growth in global commercial HVAC1 and aftermarket1 with continued weakness in our Residential and Light Commercial businesses, particularly in the Americas. The full year guidance assumes the divestiture of Riello to conclude by the end of 1Q 20262, reflecting a year-over-year headwind of ~$350 million sales and ~$0.03 adjusted EPS.

[0001783180-26-000005:8k_2_02:50]
•Flat to low-single-digit organic* growth; Reported sales flat to up LSD

[0001783180-26-000005:8k_2_02:51]
•Adjusted operating profit* of ~$3.4 billion

[0001783180-26-000005:8k_2_02:52]
•Adjusted EPS* of ~$2.80

[0001783180-26-000005:8k_2_02:53]
•Free cash flow* of ~$2 billion

[0001783180-26-000005:8k_2_02:54]
•~$1.5 billion in share repurchases

[0001783180-26-000005:8k_2_02:55]
1 Excludes NORESCO

[0001783180-26-000005:8k_2_02:56]
2 The closure of Riello is subject to regulatory approvals

[0001783180-26-000005:8k_2_02:57]
5

[0001783180-26-000005:8k_2_02:58]
|  | 2026 Guidance |
| Sales | ~$22 billion ~$350 million revenue headwind from Riello exitOrganic* flat to up LSDFX 1%Net, Acquisitions / Divestitures (1%) |
| Adjusted Operating Profit* | ~$3.4 billion |
| Adjusted EPS* | ~$2.80 |
| Free Cash Flow* | ~$2 billion |

[0001783180-26-000005:8k_2_02:59]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-26-000005:8k_2_02:60]
Conference Call

[0001783180-26-000005:8k_2_02:61]
Carrier will host a webcast of its earnings conference call today, Thursday, February 5, 2026, at 7:30 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at ir.carrier.com/news-and-events/events-and-presentations. For alternative dial-in information, please contact Carrier investor relations at InvestorRelations@Carrier.com.

[0001783180-26-000005:8k_2_02:62]
6

[0001783180-26-000005:8k_2_02:63]
Cautionary Statement

[0001783180-26-000005:8k_2_02:64]
7

[0001783180-26-000005:8k_2_02:65]
About Carrier

[0001783180-26-000005:8k_2_02:66]
Carrier Global Corporation, global leader in intelligent climate and energy solutions, is committed to creating innovations that bring comfort, safety and sustainability to life. Through cutting-edge advancements in climate solutions such as temperature control, air quality and transportation, we improve lives, empower critical industries and ensure the safe transport of food, life-saving medicines and more. Since inventing modern air conditioning in 1902, we lead with purpose: enhancing the lives we live and the world we share. We continue to lead because of our world-class, inclusive workforce that puts the customer at the center of everything we do. For more information, visit www.carrier.com or follow Carrier on social media at @Carrier.

[0001783180-26-000005:8k_2_02:67]
Contact:

[0001783180-26-000005:8k_2_02:68]
Investor Relations

[0001783180-26-000005:8k_2_02:69]
Michael Rednor

[0001783180-26-000005:8k_2_02:70]
561-365-2020

[0001783180-26-000005:8k_2_02:71]
Investor.Relations@Carrier.com

[0001783180-26-000005:8k_2_02:72]
Media Inquiries

[0001783180-26-000005:8k_2_02:73]
Rob Six

[0001783180-26-000005:8k_2_02:74]
561-365-2020

[0001783180-26-000005:8k_2_02:75]
Robert.Six@Carrier.com

[0001783180-26-000005:8k_2_02:76]
8

[0001783180-26-000005:8k_2_02:77]
SELECTED FINANCIAL DATA, NON-GAAP MEASURES AND DEFINITIONS

[0001783180-26-000005:8k_2_02:78]
Following are tables that present selected financial data of Carrier Global Corporation ("Carrier").

[0001783180-26-000005:8k_2_02:79]
As a result of Carrier's portfolio transformation, Carrier revised its reportable segments during the first quarter of 2025 to better reflect its business strategy, align its management reporting and increase transparency for investors. In connection with the revised structure, the Chief Operating Decision Maker changed the measure used to evaluate segment profitability from Operating profit to Segment operating profit. It represents operating profit (a measure prepared in accordance with accounting principles generally accepted in the United States ("GAAP")) adjusted to exclude restructuring costs, amortization of acquired intangible assets and other significant items of a nonoperational nature. All prior period comparative information has been recast to reflect the revised segment structure.

[0001783180-26-000005:8k_2_02:80]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-26-000005:8k_2_02:81]
Carrier reports its financial results in accordance with accounting principles generally accepted in the United States ("GAAP"). We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables in this Appendix. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-26-000005:8k_2_02:82]
Organic sales, adjusted operating profit, adjusted operating margin, adjusted earnings per share (“EPS”), adjusted effective tax rate and net debt are non-GAAP financial measures and are associated with Carrier's continuing operations unless specifically noted.

[0001783180-26-000005:8k_2_02:83]
Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a nonoperational nature (hereinafter referred to as “other significant items”). Adjusted operating profit represents consolidated operating profit (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted operating margin represents adjusted operating profit as a percentage of consolidated net sales (a GAAP measure). Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents (a GAAP measure).

[0001783180-26-000005:8k_2_02:84]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by continuing operating activities (a GAAP measure) less capital expenditures. Management believes free cash flow is a useful measure of liquidity and an additional basis for assessing Carrier’s ability to fund its activities, including the financing of acquisitions, debt service, repurchases of Carrier's common stock and distribution of earnings to shareowners. Orders are contractual commitments with customers to provide specified goods or services for an agreed upon price and may not be subject to penalty if cancelled.

[0001783180-26-000005:8k_2_02:85]
When Carrier provides our expectations for organic sales, adjusted operating profit (including on a segment basis), adjusted operating margin (including on a segment basis), adjusted effective tax rate, adjusted EPS, free cash flor, and interest expense, net on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-26-000005:8k_2_02:86]
9

[0001783180-26-000005:8k_2_02:87]
Carrier Global Corporation

[0001783180-26-000005:8k_2_02:88]
Consolidated Statement of Operations

[0001783180-26-000005:8k_2_02:89]
|  | (Unaudited) |
|  | Three Months Ended December 31, |  | Year Ended December 31, |
| (In millions, except per share amounts) | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net sales |  |  |  |  |  |  |  |
| Product sales | $ | 4,138 |  |  | $ | 4,530 |  |  | $ | 19,173 |  |  | $ | 19,990 |  |
| Service sales | 699 |  |  | 618 |  |  | 2,574 |  |  | 2,496 |  |
| Total Net sales | 4,837 |  |  | 5,148 |  |  | 21,747 |  |  | 22,486 |  |
| Costs and expenses |  |  |  |  |  |  |  |
| Cost of products sold | (3,351) |  |  | (3,335) |  |  | (14,232) |  |  | (14,580) |  |
| Cost of services sold | (525) |  |  | (469) |  |  | (1,891) |  |  | (1,925) |  |
| Research and development | (160) |  |  | (162) |  |  | (625) |  |  | (686) |  |
| Selling, general and administrative | (747) |  |  | (803) |  |  | (3,092) |  |  | (3,197) |  |
| Total Costs and expenses | (4,783) |  |  | (4,769) |  |  | (19,840) |  |  | (20,388) |  |
| Equity method investment net earnings | 47 |  |  | 44 |  |  | 229 |  |  | 231 |  |
| Other income (expense), net | — |  |  | 351 |  |  | 36 |  |  | 317 |  |
| Operating profit | 101 |  |  | 774 |  |  | 2,172 |  |  | 2,646 |  |
| Non-service pension benefit (expense) | (2) |  |  | — |  |  | (10) |  |  | (1) |  |
| Interest (expense) income, net | (94) |  |  | (81) |  |  | (364) |  |  | (371) |  |
| Earnings before income taxes | 5 |  |  | 693 |  |  | 1,798 |  |  | 2,274 |  |
| Income tax (expense) benefit | 32 |  |  | (723) |  |  | (240) |  |  | (1,062) |  |
| Earnings from continuing operations | 37 |  |  | (30) |  |  | 1,558 |  |  | 1,212 |  |
| Discontinued operations, net of tax | 25 |  |  | 2,599 |  |  | 29 |  |  | 4,496 |  |
| Net earnings (loss) | 62 |  |  | 2,569 |  |  | 1,587 |  |  | 5,708 |  |
| Less: Non-controlling interest in subsidiaries' | 9 |  |  | 18 |  |  | 103 |  |  | 104 |  |
| Net earnings (loss) attributable to common shareowners | $ | 53 |  |  | $ | 2,551 |  |  | $ | 1,484 |  |  | $ | 5,604 |  |
| Amounts attributable to common shareowners: |  |  |  |  |  |  |  |
| Continuing operations | $ | 28 |  |  | $ | (48) |  |  | $ | 1,455 |  |  | $ | 1,108 |  |
| Discontinued operations | 25 |  |  | 2,599 |  |  | 29 |  |  | 4,496 |  |
| Net earnings (loss) attributable to common shareowners | $ | 53 |  |  | $ | 2,551 |  |  | $ | 1,484 |  |  | $ | 5,604 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.03 |  |  | $ | (0.05) |  |  | $ | 1.71 |  |  | $ | 1.23 |  |
| Discontinued operations | 0.03 |  |  | 2.92 |  |  | 0.03 |  |  | 5.01 |  |
| Net earnings (loss) | $ | 0.06 |  |  | $ | 2.87 |  |  | $ | 1.74 |  |  | $ | 6.24 |  |
| Diluted: |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.03 |  |  | $ | (0.05) |  |  | $ | 1.69 |  |  | $ | 1.22 |  |
| Discontinued operations | 0.03 |  |  | 2.87 |  |  | 0.03 |  |  | 4.93 |  |
| Net earnings (loss) | $ | 0.06 |  |  | $ | 2.82 |  |  | $ | 1.72 |  |  | $ | 6.15 |  |
| Weighted-average number of shares outstanding |  |  |  |  |  |  |  |
| Basic | 839.2 |  | 890.1 |  | 852.4 |  | 898.2 |
| Diluted | 846.7 |  | 903.4 |  | 862.4 |  | 911.7 |

[0001783180-26-000005:8k_2_02:90]
10

[0001783180-26-000005:8k_2_02:91]
Carrier Global Corporation

[0001783180-26-000005:8k_2_02:92]
Consolidated Balance Sheet

[0001783180-26-000005:8k_2_02:93]
|  | (Unaudited) |
|  | As of December 31, |
| (In millions) | 2025 |  | 2024 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 1,555 |  |  | $ | 3,969 |  |
| Accounts receivable, net | 2,639 |  |  | 2,651 |  |
| Inventories, net | 2,483 |  |  | 2,299 |  |
| Assets held for sale | 592 |  |  | — |  |
| Other assets, current | 1,264 |  |  | 972 |  |
| Total current assets | 8,533 |  |  | 9,891 |  |
| Future income tax benefits | 1,074 |  |  | 1,131 |  |
| Fixed assets, net | 3,165 |  |  | 2,999 |  |
| Operating lease right-of-use assets | 546 |  |  | 554 |  |
| Intangible assets, net | 6,326 |  |  | 6,432 |  |
| Goodwill | 15,501 |  |  | 14,601 |  |
| Pension and post-retirement assets | 56 |  |  | 43 |  |
| Equity method investments | 1,321 |  |  | 1,194 |  |
| Other assets | 668 |  |  | 558 |  |
| Total Assets | $ | 37,190 |  |  | $ | 37,403 |  |
| Liabilities and Equity |  |  |  |
| Accounts payable | $ | 2,702 |  |  | $ | 2,458 |  |
| Accrued liabilities | 3,774 |  |  | 4,098 |  |
| Liabilities held for sale | 170 |  |  | — |  |
| Short-term borrowings and current portion of long-term debt | 468 |  |  | 1,336 |  |
| Total current liabilities | 7,114 |  |  | 7,892 |  |
| Long-term debt | 11,365 |  |  | 11,026 |  |
| Future pension and post-retirement obligations | 192 |  |  | 214 |  |
| Future income tax obligations | 1,833 |  |  | 2,015 |  |
| Operating lease liabilities | 418 |  |  | 432 |  |
| Other long-term liabilities | 2,140 |  |  | 1,429 |  |
| Total Liabilities | 23,062 |  |  | 23,008 |  |
| Equity |  |  |  |
| Common stock, par value $0.01; 4,000,000,000 shares authorized; 950,633,287 and 948,068,772 shares issued; 836,141,122 and 878,337,677 outstanding as of December 31, 2025 and 2024, respectively | 10 |  |  | 9 |  |
| Treasury stock | (6,795) |  |  | (3,915) |  |
| Additional paid-in capital | 8,665 |  |  | 8,610 |  |
| Retained earnings | 12,193 |  |  | 11,483 |  |
| Accumulated other comprehensive loss | (269) |  |  | (2,106) |  |
| Non-controlling interest | 324 |  |  | 314 |  |
| Total Equity | 14,128 |  |  | 14,395 |  |
| Total Liabilities and Equity | $ | 37,190 |  |  | $ | 37,403 |  |

[0001783180-26-000005:8k_2_02:94]
11

[0001783180-26-000005:8k_2_02:95]
Carrier Global Corporation

[0001783180-26-000005:8k_2_02:96]
Consolidated Statement of Cash Flows

[0001783180-26-000005:8k_2_02:97]
|  | (Unaudited) |
|  | Three Months Ended December 31, |  | Year Ended December 31, |
| (In millions) | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Operating Activities |  |  |  |  |  |  |  |
| Net earnings (loss) | $ | 62 |  |  | $ | 2,569 |  |  | $ | 1,587 |  |  | $ | 5,708 |  |
| Discontinued operations, net of tax | (25) |  |  | (2,599) |  |  | (29) |  |  | (4,496) |  |
| Adjustments for non-cash items, net: |  |  |  |  |  |  |  |
| Depreciation and amortization | 329 |  |  | 318 |  |  | 1,274 |  |  | 1,232 |  |
| Deferred income tax provision | (85) |  |  | (56) |  |  | (401) |  |  | (352) |  |
| Stock-based compensation cost | 19 |  |  | 21 |  |  | 74 |  |  | 86 |  |
| Equity method investment net earnings | (47) |  |  | (44) |  |  | (229) |  |  | (231) |  |
| (Gain) loss on extinguishment of debt | — |  |  | 6 |  |  | — |  |  | (82) |  |
| (Gain) loss on sale of investments / deconsolidation | (15) |  |  | (320) |  |  | (32) |  |  | (322) |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable, net | 392 |  |  | 95 |  |  | (98) |  |  | (40) |  |
| Inventories, net | 447 |  |  | 216 |  |  | (81) |  |  | 292 |  |
| Accounts payable and accrued liabilities | (389) |  |  | 345 |  |  | (219) |  |  | 87 |  |
| Distributions from equity method investments | 96 |  |  | 10 |  |  | 201 |  |  | 46 |  |
| Other operating activities, net | 229 |  |  | (198) |  |  | 42 |  |  | (357) |  |
| Net cash flows provided by (used in) continuing operating activities | 1,013 |  |  | 363 |  |  | 2,089 |  |  | 1,571 |  |
| Net cash flows provided by (used in) discontinued operating activities | 27 |  |  | (231) |  |  | 424 |  |  | (1,008) |  |
| Net cash flows provided by (used in) operating activities | 1,040 |  |  | 132 |  |  | 2,513 |  |  | 563 |  |
| Investing Activities |  |  |  |  |  |  |  |
| Capital expenditures | (131) |  |  | (217) |  |  | (392) |  |  | (519) |  |
| Investment in businesses, net of cash acquired | (15) |  |  | (17) |  |  | (107) |  |  | (10,890) |  |
| Dispositions of businesses | 19 |  |  | 634 |  |  | 27 |  |  | 634 |  |
| Settlement of derivative contracts, net | (15) |  |  | (77) |  |  | 105 |  |  | (264) |  |
| Other investing activities, net | 31 |  |  | (17) |  |  | 24 |  |  | 14 |  |
| Net cash flows provided by (used in) continuing investing activities | (111) |  |  | 306 |  |  | (343) |  |  | (11,025) |  |
| Net cash flows provided by (used in) discontinued investing activities | 1 |  |  | 2,783 |  |  | 36 |  |  | 9,000 |  |
| Net cash flows provided by (used in) investing activities | (110) |  |  | 3,089 |  |  | (307) |  |  | (2,025) |  |
| Financing Activities |  |  |  |  |  |  |  |
| (Decrease) increase in short-term borrowings, net | (112) |  |  | 13 |  |  | 275 |  |  | 50 |  |
| Issuance of long-term debt | 16 |  |  | 826 |  |  | 48 |  |  | 3,412 |  |
| Repayment of long-term debt | (3) |  |  | (815) |  |  | (1,212) |  |  | (5,345) |  |
| Repurchases of common stock | (479) |  |  | (1,513) |  |  | (2,892) |  |  | (1,944) |  |
| Dividends paid on common stock | (189) |  |  | (156) |  |  | (772) |  |  | (670) |  |
| Dividends paid to non-controlling interest | (20) |  |  | (12) |  |  | (101) |  |  | (84) |  |
| Other financing activities, net | — |  |  | (15) |  |  | (18) |  |  | (30) |  |
| Net cash flows provided by (used in) continuing financing activities | (787) |  |  | (1,672) |  |  | (4,672) |  |  | (4,611) |  |
| Net cash flows provided by (used in) discontinued financing activities | — |  |  | (14) |  |  | — |  |  | (25) |  |
| Net cash flows provided by (used in) financing activities | (787) |  |  | (1,686) |  |  | (4,672) |  |  | (4,636) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents | 13 |  |  | (85) |  |  | 76 |  |  | (103) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash, including cash classified in current assets held for sale | 156 |  |  | 1,450 |  |  | (2,390) |  |  | (6,201) |  |
| Less: Change in cash balances classified as assets held for sale | 25 |  |  | (284) |  |  | 25 |  |  | (320) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash | 131 |  |  | 1,734 |  |  | (2,415) |  |  | (5,881) |  |
| Cash, cash equivalents and restricted cash, beginning of period | 1,426 |  |  | 2,238 |  |  | 3,972 |  |  | 9,853 |  |
| Cash, cash equivalents and restricted cash, end of period | 1,557 |  |  | 3,972 |  |  | 1,557 |  |  | 3,972 |  |
| Less: restricted cash | 2 |  |  | 3 |  |  | 2 |  |  | 3 |  |
| Cash and cash equivalents, end of period | $ | 1,555 |  |  | $ | 3,969 |  |  | $ | 1,555 |  |  | $ | 3,969 |  |

[0001783180-26-000005:8k_2_02:98]
Carrier Global Corporation

[0001783180-26-000005:8k_2_02:99]
Segment Summary

[0001783180-26-000005:8k_2_02:100]
|  | (Unaudited) |
|  |  | Three Months Ended December 31, |  | Year Ended December 31, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Segment net sales |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | $ | 1,935 |  | $ | 2,341 |  | $ | 10,470 |  | $ | 10,527 |
| Climate Solutions Europe |  | 1,332 |  | 1,252 |  | 5,044 |  | 4,984 |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 798 |  | 874 |  | 3,339 |  | 3,500 |
| Climate Solutions Transportation |  | 772 |  | 681 |  | 2,894 |  | 3,475 |
| Segment net sales |  | $ | 4,837 |  | $ | 5,148 |  | $ | 21,747 |  | $ | 22,486 |
| Segment operating profit |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | $ | 168 |  | $ | 435 |  | $ | 2,150 |  | $ | 2,323 |
| Climate Solutions Europe |  | 120 |  | 80 |  | 444 |  | 469 |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 95 |  | 95 |  | 448 |  | 466 |
| Climate Solutions Transportation |  | 112 |  | 97 |  | 452 |  | 485 |
| Segment operating profit |  | $ | 495 |  | $ | 707 |  | $ | 3,494 |  | $ | 3,743 |
| Segment operating margin |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | 8.7 | % |  | 18.6 | % |  | 20.5 | % |  | 22.1 | % |
| Climate Solutions Europe |  | 9.0 | % |  | 6.4 | % |  | 8.8 | % |  | 9.4 | % |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 11.9 | % |  | 10.9 | % |  | 13.4 | % |  | 13.3 | % |
| Climate Solutions Transportation |  | 14.5 | % |  | 14.2 | % |  | 15.6 | % |  | 14.0 | % |

[0001783180-26-000005:8k_2_02:101]
13

[0001783180-26-000005:8k_2_02:102]
Carrier Global Corporation

[0001783180-26-000005:8k_2_02:103]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-26-000005:8k_2_02:104]
Components of Changes in Net Sales

[0001783180-26-000005:8k_2_02:105]
Three Months Ended December 31, 2025 Compared with Three Months Ended December 31, 2024

[0001783180-26-000005:8k_2_02:106]
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| Climate Solutions Americas | (17)% |  | —% |  | —% |  | —% |  | (17)% |
| Climate Solutions Europe | (2)% |  | 8% |  | —% |  | —% |  | 6% |
| Climate Solutions Asia Pacific, Middle East & Africa | (9)% |  | —% |  | —% |  | —% |  | (9)% |
| Climate Solutions Transportation | 10% |  | 3% |  | —% |  | —% |  | 13% |
| Consolidated | (9)% |  | 3% |  | —% |  | —% |  | (6)% |

[0001783180-26-000005:8k_2_02:107]
Year Ended December 31, 2025 Compared with Year Ended December 31, 2024

[0001783180-26-000005:8k_2_02:108]
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| Climate Solutions Americas | (1)% |  | —% |  | —% |  | —% |  | (1)% |
| Climate Solutions Europe | (3)% |  | 4% |  | —% |  | —% |  | 1% |
| Climate Solutions Asia Pacific, Middle East & Africa | (5)% |  | —% |  | —% |  | —% |  | (5)% |
| Climate Solutions Transportation | 4% |  | 1% |  | (22)% |  | —% |  | (17)% |
| Consolidated | (1)% |  | 1% |  | (3)% |  | —% |  | (3)% |

[0001783180-26-000005:8k_2_02:109]
14

[0001783180-26-000005:8k_2_02:110]
Carrier Global Corporation

[0001783180-26-000005:8k_2_02:111]
Reconciliations

[0001783180-26-000005:8k_2_02:112]
|  |  | (Unaudited) |
|  |  | Three Months Ended December 31, |  | Year Ended December 31, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Reconciliation to Earnings before income taxes |  |  |  |  |  |  |  |  |
| Segment operating profit |  | $ | 495 |  |  | $ | 707 |  |  | $ | 3,494 |  |  | $ | 3,743 |  |
| Corporate and other |  | (40) |  |  | (29) |  |  | (202) |  |  | (201) |  |
| Restructuring costs |  | (73) |  |  | (11) |  |  | (178) |  |  | (108) |  |
| Amortization of acquired intangibles |  | (220) |  |  | (172) |  |  | (856) |  |  | (689) |  |
| Acquisition step-up amortization |  | — |  |  | (31) |  |  | — |  |  | (282) |  |
| Acquisition/divestiture-related costs |  | (23) |  |  | (8) |  |  | (55) |  |  | (95) |  |
| Viessmann-related hedges |  | — |  |  | — |  |  | — |  |  | (86) |  |
| CCR gain |  | — |  |  | 318 |  |  | 7 |  |  | 318 |  |
| VCS pre-acquisition product replacement cost |  | (38) |  |  | — |  |  | (38) |  |  | — |  |
| Gain on liability adjustment |  | — |  |  | — |  |  | — |  |  | 46 |  |
| Non-service pension (expense) benefit |  | (2) |  |  | — |  |  | (10) |  |  | (1) |  |
| Interest (expense) income, net |  | (94) |  |  | (81) |  |  | (364) |  |  | (371) |  |
| Earnings before income taxes |  | $ | 5 |  |  | $ | 693 |  |  | $ | 1,798 |  |  | $ | 2,274 |  |

[0001783180-26-000005:8k_2_02:113]
|  |  | (Unaudited) |
|  |  | Three Months Ended December 31, |  | Year Ended December 31, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Reconciliation of Segment operating profit to Adjusted operating profit |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | $ | 168 |  |  | $ | 435 |  |  | $ | 2,150 |  |  | $ | 2,323 |  |
| Climate Solutions Europe |  | 120 |  |  | 80 |  |  | 444 |  |  | 469 |  |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 95 |  |  | 95 |  |  | 448 |  |  | 466 |  |
| Climate Solutions Transportation |  | 112 |  |  | 97 |  |  | 452 |  |  | 485 |  |
| Segment operating profit |  | $ | 495 |  |  | $ | 707 |  |  | $ | 3,494 |  |  | $ | 3,743 |  |
| Corporate and other |  | (40) |  |  | (29) |  |  | (202) |  |  | (201) |  |
| Adjusted operating profit |  | $ | 455 |  |  | $ | 678 |  |  | $ | 3,292 |  |  | $ | 3,542 |  |

[0001783180-26-000005:8k_2_02:114]
15

[0001783180-26-000005:8k_2_02:115]
Carrier Global Corporation

[0001783180-26-000005:8k_2_02:116]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-26-000005:8k_2_02:117]
Net Earnings (Loss), Earnings Per Share, and Effective Tax Rate

[0001783180-26-000005:8k_2_02:118]
|  | (Unaudited) |
|  | Three Months Ended December 31, 2025 |  | Year Ended December 31, 2025 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 4,837 |  |  | $ | — |  |  | $ | 4,837 |  |  | $ | 21,747 |  |  | $ | — |  |  | $ | 21,747 |  |
| Operating profit | $ | 101 |  |  | 354 |  | a | $ | 455 |  |  | $ | 2,172 |  |  | 1,120 |  | a | $ | 3,292 |  |
| Operating margin | 2.1 | % |  |  |  | 9.4 | % |  | 10.0 | % |  |  |  | 15.1 | % |
| Earnings before income taxes | $ | 5 |  |  | 354 |  | a,b | $ | 359 |  |  | $ | 1,798 |  |  | 1,131 |  | a,b | $ | 2,929 |  |
| Income tax (expense) benefit | $ | 32 |  |  | (97) |  | c | $ | (65) |  |  | $ | (240) |  |  | (356) |  | c | $ | (596) |  |
| Effective tax rate | (741.2) | % |  |  |  | 18.1 | % |  | 13.4 | % |  |  |  | 20.4 | % |
| Earnings from continuing operations attributable to common shareowners | $ | 28 |  |  | $ | 257 |  |  | $ | 285 |  |  | $ | 1,455 |  |  | $ | 775 |  |  | $ | 2,230 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 73 |  | a |  |  |  |  | $ | 178 |  | a |  |
| Amortization of acquired intangibles |  |  | 220 |  | a |  |  |  |  | 856 |  | a |  |
| Acquisition/divestiture-related costs |  |  | 23 |  | a |  |  |  |  | 55 |  | a |  |
| CCR gain |  |  | — |  | a |  |  |  |  | (7) |  | a |  |
| VCS pre-acquisition product replacement cost |  |  | 38 |  | a |  |  |  |  | 38 |  | a |  |
| Defined benefit pension settlement |  |  | — |  | b |  |  |  |  | 11 |  | b |  |
| Total adjustments |  |  | $ | 354 |  |  |  |  |  |  | $ | 1,131 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (97) |  |  |  |  |  |  | $ | (301) |  |  |  |
| Tax specific adjustments |  |  | — |  |  |  |  |  |  | (55) |  |  |  |
| Total tax adjustments |  |  | $ | (97) |  | c |  |  |  |  | $ | (356) |  | c |  |
| Diluted shares outstanding | 846.7 |  |  |  |  | 846.7 |  |  | 862.4 |  |  |  |  | 862.4 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.03 |  |  |  |  | $ | 0.34 |  |  | $ | 1.69 |  |  |  |  | $ | 2.59 |  |

[0001783180-26-000005:8k_2_02:119]
16

[0001783180-26-000005:8k_2_02:120]
Carrier Global Corporation

[0001783180-26-000005:8k_2_02:121]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-26-000005:8k_2_02:122]
Net Earnings (Loss), Earnings Per Share, and Effective Tax Rate

[0001783180-26-000005:8k_2_02:123]
|  | (Unaudited) |
|  | Three Months Ended December 31, 2024 |  | Year Ended December 31, 2024 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,148 |  |  | $ | — |  |  | $ | 5,148 |  |  | $ | 22,486 |  |  | $ | — |  |  | $ | 22,486 |  |
| Operating profit | $ | 774 |  |  | (96) |  | a | $ | 678 |  |  | $ | 2,646 |  |  | 896 |  | a | $ | 3,542 |  |
| Operating margin | 15.0 | % |  |  |  | 13.2 | % |  | 11.8 | % |  |  |  | 15.8 | % |
| Earnings before income taxes | $ | 693 |  |  | (87) |  | a,b | $ | 606 |  |  | $ | 2,274 |  |  | 831 |  | a,b | $ | 3,105 |  |
| Income tax (expense) benefit | $ | (723) |  |  | 627 |  | c | $ | (96) |  |  | $ | (1,062) |  |  | 400 |  | c | $ | (662) |  |
| Effective tax rate | 104.3 | % |  |  |  | 15.8 | % |  | 46.7 | % |  |  |  | 21.3 | % |
| Earnings from continuing operations attributable to common shareowners | $ | (48) |  |  | $ | 540 |  |  | $ | 492 |  |  | $ | 1,108 |  |  | $ | 1,231 |  |  | $ | 2,339 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 11 |  | a |  |  |  |  | $ | 108 |  | a |  |
| Amortization of acquired intangibles |  |  | 172 |  | a |  |  |  |  | 689 |  | a |  |
| Acquisition step-up amortization (1) |  |  | 31 |  | a |  |  |  |  | 282 |  | a |  |
| Acquisition/divestiture-related costs |  |  | 8 |  | a |  |  |  |  | 95 |  | a |  |
| CCR gain |  |  | (318) |  | a |  |  |  |  | (318) |  | a |  |
| Viessmann-related hedges |  |  | — |  | a |  |  |  |  | 86 |  | a |  |
| Gain on liability adjustment (2) |  |  | — |  | a |  |  |  |  | (46) |  | a |  |
| Debt extinguishment (gain) |  |  | — |  | b |  |  |  |  | (97) |  | b |  |
| Debt prepayment costs |  |  | 9 |  | b |  |  |  |  | 32 |  | b |  |
| Total adjustments |  |  | $ | (87) |  |  |  |  |  |  | $ | 831 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (35) |  |  |  |  |  |  | $ | (262) |  |  |  |
| Tax specific adjustments (3) |  |  | 662 |  |  |  |  |  |  | 662 |  |  |  |
| Total tax adjustments |  |  | $ | 627 |  | c |  |  |  |  | $ | 400 |  | c |  |
| Diluted shares outstanding | 903.4 |  |  |  |  | 903.4 |  |  | 911.7 |  |  |  |  | 911.7 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | (0.05) |  |  |  |  | $ | 0.54 |  |  | $ | 1.22 |  |  |  |  | $ | 2.56 |  |

[0001783180-26-000005:8k_2_02:124]
(1) Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-26-000005:8k_2_02:125]
(2) Gain associated with an adjustment to our tax-related liability owed to UTC.

[0001783180-26-000005:8k_2_02:126]
(3) Tax expense associated with the integration of the Viessmann and Carrier legal entity structure.

[0001783180-26-000005:8k_2_02:127]
Free Cash Flow Reconciliation

[0001783180-26-000005:8k_2_02:128]
|  |  | (Unaudited) |
|  |  | Three Months Ended December 31, |  | Year Ended December 31, |
| (In millions) |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net cash flows provided by operating activities |  | $ | 1,040 |  |  | $ | 132 |  |  | $ | 2,513 |  |  | $ | 563 |  |
| Less: Capital expenditures - continuing operations |  | (131) |  |  | (217) |  |  | (392) |  |  | (519) |  |
| Less: Capital expenditures - discontinued operations |  | — |  |  | (4) |  |  | — |  |  | (14) |  |
| Free cash flow |  | $ | 909 |  |  | $ | (89) |  |  | $ | 2,121 |  |  | $ | 30 |  |

[0001783180-26-000005:8k_2_02:129]
Net Debt Reconciliation

[0001783180-26-000005:8k_2_02:130]
|  |  | (Unaudited) |
|  |  | As of December 31, |
| (In millions) |  | 2025 |  | 2024 |
| Long-term debt |  | $ | 11,365 |  |  | $ | 11,026 |  |
| Short-term borrowings and current portion of long-term debt |  | 468 |  |  | 1,336 |  |
| Less: Cash and cash equivalents |  | 1,555 |  |  | 3,969 |  |
| Net debt |  | $ | 10,278 |  |  | $ | 8,393 |  |

[0001783180-26-000005:8k_2_02:131]
18
