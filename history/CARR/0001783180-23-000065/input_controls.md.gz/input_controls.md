# CARR 10-Q controls and the auditor's report


## item_4_controls

[0001783180-23-000065:item_4_controls:1]
Item 4.    Controls and Procedures

[0001783180-23-000065:item_4_controls:2]
As required by Rule 13a-15 under the Securities Exchange Act of 1934, as amended (the "Exchange Act"), we carried out an evaluation under the supervision and with the participation of our management, including the Chairman and Chief Executive Officer ("CEO"), the Senior Vice President and Chief Financial Officer ("CFO") and the Vice President, Controller ("Controller") of the effectiveness of the design and operation of our disclosure controls and procedures as of September 30, 2023. There are inherent limitations to the effectiveness of any system of disclosure controls and procedures, including the possibility of human error and the circumvention or overriding of the controls and procedures. Accordingly, even effective disclosure controls and procedures can only provide reasonable assurance of achieving their control objectives. Based upon our evaluation, our CEO, CFO and Controller have concluded that, as of September 30, 2023, our disclosure controls and procedures were effective and provide reasonable assurance that information required to be disclosed in the reports that we file

[0001783180-23-000065:item_4_controls:3]
48

[0001783180-23-000065:item_4_controls:4]
or submit under the Exchange Act is recorded, processed, summarized and reported within the time periods specified in the applicable rules and forms, and that it is accumulated and communicated to our management, including our CEO, CFO and Controller, as appropriate, to allow timely decisions regarding required disclosure.

[0001783180-23-000065:item_4_controls:5]
There has been no change in our internal control over financial reporting during the three months ended September 30, 2023 that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.
