# CARR 8-K — 0001783180-23-000063 filed 2023-10-26

## item codes, every 8-K on or before 2023-10-26

- 2023-10-26 0001783180-23-000063 — 2.02, 9.01
- 2023-07-27 0001783180-23-000053 — 2.02, 9.01
- 2023-06-12 0000950142-23-001664 — 5.02
- 2023-05-25 0000950142-23-001541 — 1.01, 1.02, 2.03, 9.01
- 2023-04-26 0000950142-23-001205 — 1.01, 9.01
- 2023-04-25 0001783180-23-000036 — 2.02, 7.01, 9.01
- 2023-04-25 0000950142-23-001199 — 7.01, 8.01, 9.01
- 2023-04-21 0001783180-23-000032 — 5.07, 9.01
- 2023-02-07 0001783180-23-000010 — 2.02, 9.01
- 2022-10-27 0001783180-22-000054 — 2.02, 7.01, 9.01
- 2022-09-29 0000950142-22-002805 — 5.02, 9.01
- 2022-07-28 0001783180-22-000045 — 2.02, 9.01
- 2022-04-28 0001783180-22-000032 — 2.02, 9.01
- 2022-04-15 0001783180-22-000024 — 5.07, 9.01
- 2022-02-08 0001783180-22-000008 — 2.02, 9.01
- 2022-02-07 0000950142-22-000510 — 8.01, 9.01
- 2022-01-03 0000950142-22-000023 — 8.01, 9.01
- 2021-12-17 0001783180-21-000071 — 5.02, 7.01, 9.01
- 2021-11-23 0001783180-21-000068 — 5.03, 9.01
- 2021-10-28 0001783180-21-000062 — 2.02, 9.01
- 2021-08-27 0001783180-21-000056 — 8.01
- 2021-07-30 0001783180-21-000053 — 1.01
- 2021-07-29 0001783180-21-000049 — 2.02, 8.01, 9.01
- 2021-07-27 0000950142-21-002448 — 8.01, 9.01
- 2021-07-15 0000950142-21-002362 — 5.02, 9.01
- 2021-06-09 0000950142-21-001885 — 5.02, 9.01
- 2021-04-29 0001783180-21-000029 — 2.02, 9.01
- 2021-04-22 0001140361-21-013889 — 5.02, 9.01
- 2021-04-20 0001783180-21-000021 — 5.07, 9.01
- 2021-04-19 0000950142-21-001308 — 8.01, 9.01
- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2023-10-26

- none on or before 2023-10-26

## item 2.02 — earnings release, exhibit 99.1

[0001783180-23-000063:8k_2_02:1]
EX-99
2
a99-q32023earningsexhibit.htm
EX-99

[0001783180-23-000063:8k_2_02:2]
Document

[0001783180-23-000063:8k_2_02:3]
Exhibit 99

[0001783180-23-000063:8k_2_02:4]
Carrier Reports Third Quarter 2023 Results

[0001783180-23-000063:8k_2_02:5]
•Net sales up 5% versus third quarter 2022; organic sales up 3%

[0001783180-23-000063:8k_2_02:6]
•GAAP EPS of $0.42 and adjusted EPS of $0.89

[0001783180-23-000063:8k_2_02:7]
•Net cash inflows from operating activities were $1.04 billion and free cash flow generation was $949 million

[0001783180-23-000063:8k_2_02:8]
•Increasing adjusted EPS guidance for 2023 from $2.55 - $2.65 to ~$2.70

[0001783180-23-000063:8k_2_02:9]
PALM BEACH GARDENS, Fla., October 26, 2023 – Carrier Global Corporation (NYSE:CARR), global leader in intelligent climate and energy solutions, today reported strong financial results for the third quarter of 2023 and raised its full year adjusted operating margin and adjusted EPS guidance.

[0001783180-23-000063:8k_2_02:10]
“Carrier continues to perform while transforming, delivering another strong quarter highlighted by an over 400 basis points increase in gross margins and solid cash flow growth,” said Carrier Chairman & CEO David Gitlin. “Traction with our digitally enabled life-cycle solutions continues to build as we delivered another quarter of double-digit aftermarket growth. We are again raising our full year guidance for adjusted operating margin and adjusted EPS. We remain on track to complete the transformational combination with Viessmann Climate Solutions in early January 2024, and we are pleased with the interest level in our strategic business exits.  I could not be more proud of the team as we continue to make progress on our mission to become the global leader in intelligent climate and energy solutions.”

[0001783180-23-000063:8k_2_02:11]
1

[0001783180-23-000063:8k_2_02:12]
Third Quarter 2023 Results

[0001783180-23-000063:8k_2_02:13]
Carrier’s third quarter sales of $5.7 billion were up 5% compared to the prior year and organic sales grew 3% over the same period. Organic sales strength continued with 4% growth in the HVAC segment with commercial HVAC up high-single-digits and North America residential and light commercial HVAC up 5% organically. Fire and Security sales were up 6% organically while Refrigeration sales were down 3% organically driven by declines in container and commercial refrigeration only partially offset by strength in global truck and trailer.

[0001783180-23-000063:8k_2_02:14]
GAAP operating profit in the quarter of $645 million was down 58% from last year, mainly due to the absence of last year’s $732 million gain related to the acquisition of Toshiba Carrier Corporation.  Adjusted operating profit of $1.0 billion was up 21% compared to last year.

[0001783180-23-000063:8k_2_02:15]
Net income was $357 million and adjusted net income was $765 million. GAAP EPS was $0.42 and adjusted EPS was $0.89. Net cash flows generated in operating activities were $1.04 billion and capital expenditures were $92 million, resulting in free cash flow of $949 million.

[0001783180-23-000063:8k_2_02:16]
Full-Year 2023 Guidance

[0001783180-23-000063:8k_2_02:17]
Carrier updated the following guidance for 2023:

[0001783180-23-000063:8k_2_02:18]
|  |  | Current Guidance | Prior Guidance |  |  |
|  |  | Over $22B | Over $22B |  |  |
| Sales |  | Organic* up MSD | Organic* up MSD |  |  |
|  |  | FX ~0% | FX ~0% |  |  |
|  |  | Acquisitions / Divestitures, net +~5% | Acquisitions / Divestitures, net +~5% |  |  |
| Adjusted Operating Margin * |  | ~ 14.5% | 14.0% - 14.5% |  |  |
|  | Includes ~50bps negative impact from TCC | Includes ~50bps negative impact from TCC |  |  |
| Adjusted EPS * |  | ~ $2.70 | $2.55 - $2.65 |  |  |
| Free Cash Flow * |  | Over $1.9B | ~$1.9B |  |  |

[0001783180-23-000063:8k_2_02:19]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-23-000063:8k_2_02:20]
2

[0001783180-23-000063:8k_2_02:21]
Conference Call

[0001783180-23-000063:8k_2_02:22]
Carrier will host a webcast of its earnings conference call today, Thursday, October 26, 2023, at 7:30 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at ir.carrier.com/news-and-events/events-and-presentations or to listen to the earnings call by phone, participants must pre-register at Carrier Earnings Call Registration. All registrants will receive dial-in information and a PIN allowing access to the live call.

[0001783180-23-000063:8k_2_02:23]
About Carrier

[0001783180-23-000063:8k_2_02:24]
Carrier Global Corporation, global leader in intelligent climate and energy solutions, is committed to creating solutions that matter for people and our planet for generations to come. From the beginning, we've led in inventing new technologies and entirely new industries. Today, we continue to lead because we have a world-class, diverse workforce that puts the customer at the center of everything we do. For more information, visit www.corporate.carrier.com or follow Carrier on social media at @Carrier.

[0001783180-23-000063:8k_2_02:25]
Cautionary Statement

[0001783180-23-000063:8k_2_02:26]
This communication contains statements which, to the extent they are not statements of historical or present fact, constitute "forward-looking statements" under the securities laws. These forward-looking statements are intended to provide management's current expectations or plans for Carrier's future operating and financial performance, based on assumptions currently believed to be valid. Forward-looking statements can be identified by the use of words such as "believe," "expect," "expectations," "plans," "strategy," "prospects," "estimate," "project," "target," "anticipate," "will," "should," "see," "guidance," "outlook," "confident," "scenario" and other words of similar meaning in connection with a discussion of future operating or financial performance. Forward-looking statements may include, among other things, statements relating to revised outlook and guidance, future sales, earnings, cash flow, results of operations, uses of cash, share repurchases, tax rates and other measures of financial performance or potential future plans, strategies or transactions of Carrier, Carrier's plans with respect to its indebtedness and other statements that are not historical facts. All forward-looking statements involve risks, uncertainties and other factors that may cause actual results to differ materially from those expressed or implied in the forward-looking statements. For additional information on identifying factors that may cause actual results to vary materially from those stated in forward-looking statements, see Carrier's reports on Forms 10-K, 10-Q and 8-K filed with or furnished to the U.S. Securities and Exchange Commission from time to time. Any forward-looking statement speaks only as of the date on which it is made, and Carrier assumes no obligation to update or revise such statement, whether as a result of new information, future events or otherwise, except as required by applicable law.

[0001783180-23-000063:8k_2_02:27]
3

[0001783180-23-000063:8k_2_02:28]
Contact:

[0001783180-23-000063:8k_2_02:29]
Investor Relations

[0001783180-23-000063:8k_2_02:30]
Sam Pearlstein

[0001783180-23-000063:8k_2_02:31]
561-365-2251

[0001783180-23-000063:8k_2_02:32]
Sam.Pearlstein@Carrier.com

[0001783180-23-000063:8k_2_02:33]
Media Inquiries

[0001783180-23-000063:8k_2_02:34]
Ashley Barrie

[0001783180-23-000063:8k_2_02:35]
561-365-1260

[0001783180-23-000063:8k_2_02:36]
Ashley.Barrie@Carrier.com

[0001783180-23-000063:8k_2_02:37]
4

[0001783180-23-000063:8k_2_02:38]
SELECTED FINANCIAL DATA, NON-GAAP MEASURES AND DEFINITIONS

[0001783180-23-000063:8k_2_02:39]
Following are tables that present selected financial data of Carrier Global Corporation (“Carrier”). Also included are reconciliations of non-GAAP measures to their most comparable GAAP measures.

[0001783180-23-000063:8k_2_02:40]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-23-000063:8k_2_02:41]
Carrier Global Corporation (“Carrier”) reports its financial results in accordance with accounting principles generally accepted in the United States ("GAAP"). We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables in this Appendix. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-23-000063:8k_2_02:42]
Organic sales, adjusted operating profit, adjusted operating margin, incremental margins / earnings conversion, earnings before interest, taxes and depreciation and amortization (“EBITDA”), adjusted EBITDA, adjusted net income, adjusted earnings per share (“EPS”), adjusted interest expense, net, adjusted effective tax rate and net debt are non-GAAP financial measures.

[0001783180-23-000063:8k_2_02:43]
Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a nonoperational nature (hereinafter referred to as “other significant items”). Adjusted operating profit represents operating profit (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted operating margin represents adjusted operating profit as a percentage of net sales (a GAAP measure). Incremental margins / earnings conversion represents the year-over-year change in adjusted operating profit divided by the year-over-year change in net sales. EBITDA represents net income attributable to common shareholders (a GAAP measure), adjusted for interest income and expense, income tax expense, and depreciation and amortization. Adjusted EBITDA represents EBITDA, as calculated above, excluding non-service pension benefit, non-controlling interest in subsidiaries’ earnings from operations, restructuring costs and other significant items. Adjusted net income represents net income attributable to common shareowners (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Adjusted interest expense, net represents interest expense (a GAAP measure) and interest income (a GAAP measure), net excluding other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs, amortization of acquired intangibles and other significant items. Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents (a GAAP measure). For the business segments, when applicable, adjustments of operating profit and operating margins represent operating profit, excluding restructuring, amortization of acquired intangibles and other significant items.

[0001783180-23-000063:8k_2_02:44]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by operating activities (a GAAP measure) less capital expenditures. Management believes free cash flow is a useful measure of liquidity and an additional basis for assessing Carrier’s ability to fund its activities, including the financing of acquisitions, debt service, repurchases of Carrier's common stock and distribution of earnings to shareowners.

[0001783180-23-000063:8k_2_02:45]
Orders are contractual commitments with customers to provide specified goods or services for an agreed upon price and may not be subject to penalty if cancelled.

[0001783180-23-000063:8k_2_02:46]
When we provide our expectations for organic sales, adjusted operating profit, adjusted operating margin, adjusted interest expense, net, adjusted effective tax rate, incremental margins/earnings conversion, EBITDA, adjusted EBITDA, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures (expected net sales, operating profit, operating margin, interest expense, effective tax rate, incremental operating margin, net income attributable to common shareowners, diluted EPS and net cash flows provided by operating activities) generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-23-000063:8k_2_02:47]
5

[0001783180-23-000063:8k_2_02:48]
Carrier Global Corporation

[0001783180-23-000063:8k_2_02:49]
Condensed Consolidated Statement of Operations

[0001783180-23-000063:8k_2_02:50]
|  | (Unaudited) |
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions, except per share amounts) | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net sales |  |  |  |  |  |  |  |
| Product sales | $ | 5,081 |  |  | $ | 4,891 |  |  | $ | 15,122 |  |  | $ | 13,723 |  |
| Service sales | 650 |  |  | 560 |  |  | 1,874 |  |  | 1,593 |  |
| Total Net sales | 5,731 |  |  | 5,451 |  |  | 16,996 |  |  | 15,316 |  |
| Costs and expenses |  |  |  |  |  |  |  |
| Cost of products sold | (3,428) |  |  | (3,569) |  |  | (10,655) |  |  | (9,930) |  |
| Cost of services sold | (487) |  |  | (405) |  |  | (1,392) |  |  | (1,169) |  |
| Research and development | (157) |  |  | (143) |  |  | (447) |  |  | (390) |  |
| Selling, general and administrative | (831) |  |  | (624) |  |  | (2,336) |  |  | (1,839) |  |
| Total Costs and expenses | (4,903) |  |  | (4,741) |  |  | (14,830) |  |  | (13,328) |  |
| Equity method investment net earnings | 75 |  |  | 63 |  |  | 171 |  |  | 222 |  |
| Other income (expense), net | (258) |  |  | 753 |  |  | (648) |  |  | 1,872 |  |
| Operating profit | 645 |  |  | 1,526 |  |  | 1,689 |  |  | 4,082 |  |
| Non-service pension (expense) benefit | — |  |  | — |  |  | — |  |  | (2) |  |
| Interest (expense) income, net | (51) |  |  | (56) |  |  | (164) |  |  | (165) |  |
| Income from operations before income taxes | 594 |  |  | 1,470 |  |  | 1,525 |  |  | 3,915 |  |
| Income tax (expense) benefit | (213) |  |  | (138) |  |  | (524) |  |  | (609) |  |
| Net income from operations | 381 |  |  | 1,332 |  |  | 1,001 |  |  | 3,306 |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations | 24 |  |  | 20 |  |  | 72 |  |  | 42 |  |
| Net income attributable to common shareowners | $ | 357 |  |  | $ | 1,312 |  |  | $ | 929 |  |  | $ | 3,264 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 0.43 |  |  | $ | 1.56 |  |  | $ | 1.11 |  |  | $ | 3.86 |  |
| Diluted | $ | 0.42 |  |  | $ | 1.53 |  |  | $ | 1.09 |  |  | $ | 3.78 |  |
| Weighted-average number of shares outstanding |  |  |  |  |  |  |  |
| Basic | 838.7 |  |  | 839.6 |  |  | 836.6 |  |  | 846.1 |  |
| Diluted | 854.7 |  |  | 856.5 |  |  | 852.7 |  |  | 864.3 |  |

[0001783180-23-000063:8k_2_02:51]
6

[0001783180-23-000063:8k_2_02:52]
Carrier Global Corporation

[0001783180-23-000063:8k_2_02:53]
Condensed Consolidated Balance Sheet

[0001783180-23-000063:8k_2_02:54]
|  |  | (Unaudited) |
| (In millions) |  | September 30, 2023 |  | December 31, 2022 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 3,902 |  |  | $ | 3,520 |  |
| Accounts receivable, net |  | 3,030 |  |  | 2,833 |  |
| Contract assets, current |  | 605 |  |  | 537 |  |
| Inventories, net |  | 2,562 |  |  | 2,640 |  |
| Other assets, current |  | 412 |  |  | 349 |  |
| Total current assets |  | 10,511 |  |  | 9,879 |  |
| Future income tax benefits |  | 712 |  |  | 612 |  |
| Fixed assets, net |  | 2,210 |  |  | 2,241 |  |
| Operating lease right-of-use assets |  | 577 |  |  | 642 |  |
| Intangible assets, net |  | 1,100 |  |  | 1,342 |  |
| Goodwill |  | 9,825 |  |  | 9,977 |  |
| Pension and post-retirement assets |  | 29 |  |  | 26 |  |
| Equity method investments |  | 1,166 |  |  | 1,148 |  |
| Other assets |  | 414 |  |  | 219 |  |
| Total Assets |  | $ | 26,544 |  |  | $ | 26,086 |  |
| Liabilities and Equity |  |  |  |  |
| Accounts payable |  | $ | 2,887 |  |  | $ | 2,833 |  |
| Accrued liabilities |  | 2,832 |  |  | 2,610 |  |
| Contract liabilities, current |  | 496 |  |  | 449 |  |
| Current portion of long-term debt |  | 134 |  |  | 140 |  |
| Total current liabilities |  | 6,349 |  |  | 6,032 |  |
| Long-term debt |  | 8,651 |  |  | 8,702 |  |
| Future pension and post-retirement obligations |  | 337 |  |  | 349 |  |
| Future income tax obligations |  | 553 |  |  | 568 |  |
| Operating lease liabilities |  | 465 |  |  | 529 |  |
| Other long-term liabilities |  | 1,687 |  |  | 1,830 |  |
| Total Liabilities |  | 18,042 |  |  | 18,010 |  |
| Equity |  |  |  |  |
| Common stock |  | 9 |  |  | 9 |  |
| Treasury stock |  | (1,972) |  |  | (1,910) |  |
| Additional paid-in capital |  | 5,517 |  |  | 5,481 |  |
| Retained earnings |  | 6,486 |  |  | 5,866 |  |
| Accumulated other comprehensive loss |  | (1,856) |  |  | (1,688) |  |
| Non-controlling interest |  | 318 |  |  | 318 |  |
| Total Equity |  | 8,502 |  |  | 8,076 |  |
| Total Liabilities and Equity |  | $ | 26,544 |  |  | $ | 26,086 |  |

[0001783180-23-000063:8k_2_02:55]
7

[0001783180-23-000063:8k_2_02:56]
Carrier Global Corporation

[0001783180-23-000063:8k_2_02:57]
Condensed Consolidated Statement of Cash Flows

[0001783180-23-000063:8k_2_02:58]
|  |  |  |  | (Unaudited) |
|  |  |  | Nine Months Ended September 30, |
| (In millions) |  |  |  |  | 2023 |  | 2022 |
| Operating Activities |  |  |  |  |  |  |  |
| Net income from operations |  |  |  |  | $ | 1,001 |  |  | $ | 3,306 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  |  |  | 407 |  |  | 257 |  |
| Deferred income tax provision |  |  |  |  | (151) |  |  | (107) |  |
| Stock-based compensation costs |  |  |  |  | 63 |  |  | 58 |  |
| Equity method investment net earnings |  |  |  |  | (171) |  |  | (222) |  |
| (Gain) loss on extinguishment of debt |  |  |  |  | — |  |  | (36) |  |
| (Gain) loss on sale of investments / deconsolidation |  |  |  |  | 278 |  |  | (1,844) |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  |  |  | (297) |  |  | (433) |  |
| Contract assets, current |  |  |  |  | (74) |  |  | (201) |  |
| Inventories, net |  |  |  |  | 7 |  |  | (492) |  |
| Other assets, current |  |  |  |  | (75) |  |  | (3) |  |
| Accounts payable and accrued liabilities |  |  |  |  | 491 |  |  | 180 |  |
| Contract liabilities, current |  |  |  |  | 55 |  |  | 34 |  |
| Defined benefit plan contributions |  |  |  |  | (17) |  |  | (10) |  |
| Distributions from equity method investments |  |  |  |  | 45 |  |  | 55 |  |
| Other operating activities, net |  |  |  |  | (17) |  |  | 78 |  |
| Net cash flows provided by (used in) operating activities |  |  |  |  | 1,545 |  |  | 620 |  |
| Investing Activities |  |  |  |  |  |  |  |
| Capital expenditures |  |  |  |  | (236) |  |  | (213) |  |
| Investments in businesses, net of cash acquired |  |  |  |  | (69) |  |  | (472) |  |
| Disposition of businesses |  |  |  |  | 54 |  |  | 2,944 |  |
| Settlement of derivative contracts, net |  |  |  |  | (66) |  |  | (202) |  |
| Kidde-Fenwal, Inc. deconsolidation |  |  |  |  | (134) |  |  | — |  |
| Other investing activities, net |  |  |  |  | 20 |  |  | (12) |  |
| Net cash flows provided by (used in) investing activities |  |  |  |  | (431) |  |  | 2,045 |  |
| Financing Activities |  |  |  |  |  |  |  |
| Increase (decrease) in short-term borrowings, net |  |  |  |  | (35) |  |  | (125) |  |
| Issuance of long-term debt |  |  |  |  | 14 |  |  | 421 |  |
| Repayment of long-term debt |  |  |  |  | (15) |  |  | (1,185) |  |
| Repurchases of common stock |  |  |  |  | (62) |  |  | (1,261) |  |
| Dividends paid on common stock |  |  |  |  | (465) |  |  | (384) |  |
| Dividends paid to non-controlling interest |  |  |  |  | (46) |  |  | (22) |  |
| Other financing activities, net |  |  |  |  | (79) |  |  | (28) |  |
| Net cash flows provided by (used in) financing activities |  |  |  |  | (688) |  |  | (2,584) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  |  |  | (45) |  |  | (115) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  |  |  |  | 381 |  |  | (34) |  |
| Cash, cash equivalents and restricted cash, beginning of period |  |  |  |  | 3,527 |  |  | 3,025 |  |
| Cash, cash equivalents and restricted cash, end of period |  |  |  |  | 3,908 |  |  | 2,991 |  |
| Less: restricted cash |  |  |  |  | 6 |  |  | 6 |  |
| Cash and cash equivalents, end of period |  |  |  |  | $ | 3,902 |  |  | $ | 2,985 |  |

[0001783180-23-000063:8k_2_02:59]
8

[0001783180-23-000063:8k_2_02:60]
Carrier Global Corporation

[0001783180-23-000063:8k_2_02:61]
Segment Net Sales and Operating Profit

[0001783180-23-000063:8k_2_02:62]
|  | (Unaudited) |
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| (In millions) | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 4,008 |  | $ | 4,008 |  | $ | 3,734 |  | $ | 3,734 |  | $ | 11,846 |  | $ | 11,846 |  | $ | 10,092 |  | $ | 10,092 |
| Refrigeration | 924 |  | 924 |  | 923 |  | 923 |  | 2,794 |  | 2,794 |  | 2,940 |  | 2,940 |
| Fire & Security | 923 |  | 923 |  | 905 |  | 905 |  | 2,724 |  | 2,724 |  | 2,610 |  | 2,610 |
| Segment sales | 5,855 |  | 5,855 |  | 5,562 |  | 5,562 |  | 17,364 |  | 17,364 |  | 15,642 |  | 15,642 |
| Eliminations and other | (124) |  | (124) |  | (111) |  | (111) |  | (368) |  | (368) |  | (326) |  | (326) |
| Net sales | $ | 5,731 |  | $ | 5,731 |  | $ | 5,451 |  | $ | 5,451 |  | $ | 16,996 |  | $ | 16,996 |  | $ | 15,316 |  | $ | 15,316 |
| Operating profit |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 763 |  | $ | 833 |  | $ | 1,314 |  | $ | 624 |  | $ | 1,940 |  | $ | 2,114 |  | $ | 2,369 |  | $ | 1,715 |
| Refrigeration | 107 |  | 111 |  | 116 |  | 118 |  | 327 |  | 341 |  | 370 |  | 382 |
| Fire & Security | 164 |  | 169 |  | 142 |  | 150 |  | 100 |  | 414 |  | 1,494 |  | 402 |
| Segment operating profit | 1,034 |  | 1,113 |  | 1,572 |  | 892 |  | 2,367 |  | 2,869 |  | 4,233 |  | 2,499 |
| Eliminations and other | (298) |  | (41) |  | (10) |  | (10) |  | (482) |  | (112) |  | (50) |  | (50) |
| General corporate expenses | (91) |  | (28) |  | (36) |  | (21) |  | (196) |  | (107) |  | (101) |  | (71) |
| Operating profit | $ | 645 |  | $ | 1,044 |  | $ | 1,526 |  | $ | 861 |  | $ | 1,689 |  | $ | 2,650 |  | $ | 4,082 |  | $ | 2,378 |
| Operating margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | 19.0 | % |  | 20.8 | % |  | 35.2 | % |  | 16.7 | % |  | 16.4 | % |  | 17.8 | % |  | 23.5 | % |  | 17.0 | % |
| Refrigeration | 11.6 | % |  | 12.0 | % |  | 12.6 | % |  | 12.8 | % |  | 11.7 | % |  | 12.2 | % |  | 12.6 | % |  | 13.0 | % |
| Fire & Security | 17.8 | % |  | 18.3 | % |  | 15.7 | % |  | 16.6 | % |  | 3.7 | % |  | 15.2 | % |  | 57.2 | % |  | 15.4 | % |
| Total Carrier | 11.3 | % |  | 18.2 | % |  | 28.0 | % |  | 15.8 | % |  | 9.9 | % |  | 15.6 | % |  | 26.7 | % |  | 15.5 | % |

[0001783180-23-000063:8k_2_02:63]
9

[0001783180-23-000063:8k_2_02:64]
Carrier Global Corporation

[0001783180-23-000063:8k_2_02:65]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-23-000063:8k_2_02:66]
Operating Profit

[0001783180-23-000063:8k_2_02:67]
|  | (Unaudited) |
|  | Three Months Ended September 30, 2023 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 4,008 |  |  | $ | 924 |  |  | $ | 923 |  |  | $ | (124) |  |  | $ | — |  |  | $ | 5,731 |  |
| Segment operating profit | $ | 763 |  |  | $ | 107 |  |  | $ | 164 |  |  | $ | (298) |  |  | $ | (91) |  |  | $ | 645 |  |
| Reported operating margin | 19.0 | % |  | 11.6 | % |  | 17.8 | % |  |  |  |  |  | 11.3 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 25 |  |  | $ | 4 |  |  | $ | (1) |  |  | $ | — |  |  | $ | — |  |  | $ | 28 |  |
| Amortization of acquired intangibles | 35 |  |  | — |  |  | 2 |  |  | — |  |  | — |  |  | 37 |  |
| Acquisition step-up amortization (1) | 10 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 10 |  |
| Acquisition/divestiture-related costs | — |  |  | — |  |  | — |  |  | — |  |  | 62 |  |  | 62 |  |
| Bridge loan financing costs | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Viessmann-related hedges | — |  |  | — |  |  | — |  |  | 257 |  |  | — |  |  | 257 |  |
| KFI deconsolidation | — |  |  | — |  |  | 4 |  |  | — |  |  | — |  |  | 4 |  |
| Total adjustments to operating profit | $ | 70 |  |  | $ | 4 |  |  | $ | 5 |  |  | $ | 258 |  |  | $ | 62 |  |  | $ | 399 |  |
| Adjusted operating profit | $ | 833 |  |  | $ | 111 |  |  | $ | 169 |  |  | $ | (40) |  |  | $ | (29) |  |  | $ | 1,044 |  |
| Adjusted operating margin | 20.8 | % |  | 12.0 | % |  | 18.3 | % |  |  |  |  |  | 18.2 | % |

[0001783180-23-000063:8k_2_02:68]
|  | (Unaudited) |
|  | Three Months Ended September 30, 2022 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 3,734 |  |  | $ | 923 |  |  | $ | 905 |  |  | $ | (111) |  |  | $ | — |  |  | $ | 5,451 |  |
| Segment operating profit | $ | 1,314 |  |  | $ | 116 |  |  | $ | 142 |  |  | $ | (10) |  |  | $ | (36) |  |  | $ | 1,526 |  |
| Reported operating margin | 35.2 | % |  | 12.6 | % |  | 15.7 | % |  |  |  |  |  | 28.0 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 2 |  |  | $ | 3 |  |  | $ | 1 |  |  | $ | — |  |  | $ | — |  |  | $ | 6 |  |
| Amortization of acquired intangibles | 16 |  |  | — |  |  | 1 |  |  | — |  |  | — |  |  | 17 |  |
| Acquisition step-up amortization (1) | 24 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 24 |  |
| Acquisition/divestiture-related costs | — |  |  | — |  |  | — |  |  | — |  |  | 15 |  |  | 15 |  |
| Chubb gain | — |  |  | — |  |  | 7 |  |  | — |  |  | — |  |  | 7 |  |
| TCC acquisition-related gain (2) | (732) |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (732) |  |
| Russia/Ukraine asset impairment | — |  |  | (1) |  |  | (1) |  |  | — |  |  | — |  |  | (2) |  |
| Total adjustments to operating profit | $ | (690) |  |  | $ | 2 |  |  | $ | 8 |  |  | $ | — |  |  | $ | 15 |  |  | $ | (665) |  |
| Adjusted operating profit | $ | 624 |  |  | $ | 118 |  |  | $ | 150 |  |  | $ | (10) |  |  | $ | (21) |  |  | $ | 861 |  |
| Adjusted operating margin | 16.7 | % |  | 12.8 | % |  | 16.6 | % |  |  |  |  |  | 15.8 | % |

[0001783180-23-000063:8k_2_02:69]
(1)  Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-23-000063:8k_2_02:70]
(2) The carrying value of our previously held TCC equity investments were recognized at fair value at the TCC acquisition date.

[0001783180-23-000063:8k_2_02:71]
10

[0001783180-23-000063:8k_2_02:72]
Carrier Global Corporation

[0001783180-23-000063:8k_2_02:73]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-23-000063:8k_2_02:74]
Operating Profit

[0001783180-23-000063:8k_2_02:75]
|  | (Unaudited) |
|  | Nine Months Ended September 30, 2023 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 11,846 |  |  | $ | 2,794 |  |  | $ | 2,724 |  |  | $ | (368) |  |  | $ | — |  |  | $ | 16,996 |  |
| Segment operating profit | $ | 1,940 |  |  | $ | 327 |  |  | $ | 100 |  |  | $ | (482) |  |  | $ | (196) |  |  | $ | 1,689 |  |
| Reported operating margin | 16.4 | % |  | 11.7 | % |  | 3.7 | % |  |  |  |  |  | 9.9 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 27 |  |  | $ | 14 |  |  | $ | 11 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 54 |  |
| Amortization of acquired intangibles | 108 |  |  | — |  |  | 6 |  |  | — |  |  | — |  |  | 114 |  |
| Acquisition step-up amortization (1) | 31 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 31 |  |
| Acquisition/divestiture-related costs | — |  |  | — |  |  | — |  |  | — |  |  | 88 |  |  | 88 |  |
| Bridge load financing costs | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Viessmann-related hedges | — |  |  | — |  |  | — |  |  | 368 |  |  | — |  |  | 368 |  |
| TCC acquisition-related gain (2) | 8 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 8 |  |
| KFI deconsolidation | — |  |  | — |  |  | 297 |  |  | — |  |  | — |  |  | 297 |  |
| Total adjustments to operating profit | $ | 174 |  |  | $ | 14 |  |  | $ | 314 |  |  | $ | 371 |  |  | $ | 88 |  |  | $ | 961 |  |
| Adjusted operating profit | $ | 2,114 |  |  | $ | 341 |  |  | $ | 414 |  |  | $ | (111) |  |  | $ | (108) |  |  | $ | 2,650 |  |
| Adjusted operating margin | 17.8 | % |  | 12.2 | % |  | 15.2 | % |  |  |  |  |  | 15.6 | % |

[0001783180-23-000063:8k_2_02:76]
|  | (Unaudited) |
|  | Nine Months Ended September 30, 2022 |
| (In millions) | HVAC |  | Refrigeration |  | Fire & Security |  | Eliminations and Other |  | General Corporate Expenses |  | Carrier |
| Net sales | $ | 10,092 |  |  | $ | 2,940 |  |  | $ | 2,610 |  |  | $ | (326) |  |  | $ | — |  |  | $ | 15,316 |  |
| Segment operating profit | $ | 2,369 |  |  | $ | 370 |  |  | $ | 1,494 |  |  | $ | (50) |  |  | $ | (101) |  |  | $ | 4,082 |  |
| Reported operating margin | 23.5 | % |  | 12.6 | % |  | 57.2 | % |  |  |  |  |  | 26.7 | % |
| Adjustments to segment operating profit: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs | $ | 8 |  |  | $ | 9 |  |  | $ | 10 |  |  | $ | — |  |  | $ | 2 |  |  | $ | 29 |  |
| Amortization of acquired intangibles | 24 |  |  | — |  |  | 3 |  |  | — |  |  | — |  |  | 27 |  |
| Acquisition step-up amortization (1) | 24 |  |  |  |  | — |  |  | — |  |  | — |  |  | 24 |  |
| Acquisition/divestiture-related costs | — |  |  | — |  |  | — |  |  | — |  |  | 28 |  |  | 28 |  |
| Chubb gain | — |  |  | — |  |  | (1,105) |  |  | — |  |  | — |  |  | (1,105) |  |
| TCC acquisition-related gain (2) | (732) |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (732) |  |
| Russia/Ukraine asset impairment | — |  |  | 3 |  |  | — |  |  | — |  |  | — |  |  | 3 |  |
| Charge resulting from legal matter | 22 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 22 |  |
| Total adjustments to operating profit | $ | (654) |  |  | $ | 12 |  |  | $ | (1,092) |  |  | $ | — |  |  | $ | 30 |  | $ | 30 |  | $ | (1,704) |  |
| Adjusted operating profit | $ | 1,715 |  |  | $ | 382 |  |  | $ | 402 |  |  | $ | (50) |  |  | $ | (71) |  |  | $ | 2,378 |  |
| Adjusted operating margin | 17.0 | % |  | 13.0 | % |  | 15.4 | % |  |  |  |  |  | 15.5 | % |

[0001783180-23-000063:8k_2_02:77]
(1)  Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-23-000063:8k_2_02:78]
(2)  The carrying value of our previously held TCC equity investments were recognized at fair value and subsequently adjusted.

[0001783180-23-000063:8k_2_02:79]
11

[0001783180-23-000063:8k_2_02:80]
Carrier Global Corporation

[0001783180-23-000063:8k_2_02:81]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-23-000063:8k_2_02:82]
Net Income, Earnings Per Share and Effective Tax Rate

[0001783180-23-000063:8k_2_02:83]
|  | (Unaudited) |
|  | Three Months Ended September 30, 2023 |  | Nine Months Ended September 30, 2023 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,731 |  |  | $ | — |  |  | $ | 5,731 |  |  | $ | 16,996 |  |  | $ | — |  |  | $ | 16,996 |  |
| Operating profit | $ | 645 |  |  | 399 |  | a | $ | 1,044 |  |  | $ | 1,689 |  |  | 961 |  | a | $ | 2,650 |  |
| Operating margin | 11.3 | % |  |  |  | 18.2 | % |  | 9.9 | % |  |  |  | 15.6 | % |
| Income from operations before income taxes | $ | 594 |  |  | 410 |  | a,b | $ | 1,004 |  |  | $ | 1,525 |  |  | 993 |  | a,b | $ | 2,518 |  |
| Income tax expense | $ | (213) |  |  | (2) |  | c | $ | (215) |  |  | $ | (524) |  |  | (45) |  | c | $ | (569) |  |
| Effective tax rate | 35.9 | % |  |  |  | 21.4 | % |  | 34.4 | % |  |  |  | 22.6 | % |
| Net income attributable to common shareowners | $ | 357 |  |  | $ | 408 |  |  | $ | 765 |  |  | $ | 929 |  |  | $ | 948 |  |  | $ | 1,877 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 28 |  | a |  |  |  |  | $ | 54 |  | a |  |
| Amortization of acquired intangibles |  |  | 37 |  | a |  |  |  |  | 114 |  | a |  |
| Acquisition step-up amortization (1) |  |  | 10 |  | a |  |  |  |  | 31 |  | a |  |
| Acquisition/divestiture-related costs |  |  | 62 |  | a |  |  |  |  | 88 |  | a |  |
| Viessmann-related hedges |  |  | 257 |  | a |  |  |  |  | 368 |  | a |  |
| TCC acquisition-related gain (2) |  |  | — |  | a |  |  |  |  | 8 |  | a |  |
| KFI deconsolidation |  |  | 4 |  | a |  |  |  |  | 297 |  | a |  |
| Bridge loan financing costs (3) |  |  | 12 |  | a,b |  |  |  |  | 33 |  | a,b |  |
| Total adjustments |  |  | $ | 410 |  |  |  |  |  |  | $ | 993 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (35) |  |  |  |  |  |  | $ | (78) |  |  |  |
| Tax specific adjustments |  |  | 33 |  |  |  |  |  |  | 33 |  |  |  |
| Total tax adjustments |  |  | $ | (2) |  | c |  |  |  |  | $ | (45) |  | c |  |
| Shares outstanding - Diluted | 854.7 |  |  |  |  | 854.7 |  |  | 852.7 |  |  |  |  | 852.7 |  |
| Earnings per share - Diluted | $ | 0.42 |  |  |  |  | $ | 0.89 |  |  | $ | 1.09 |  |  |  |  | $ | 2.20 |  |

[0001783180-23-000063:8k_2_02:84]
(1)  Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-23-000063:8k_2_02:85]
(2)  The carrying value of our previously held TCC equity investments were recognized at fair value and subsequently adjusted.

[0001783180-23-000063:8k_2_02:86]
(3)  Includes commitment fees recognized in Selling, general and administrative.

[0001783180-23-000063:8k_2_02:87]
12

[0001783180-23-000063:8k_2_02:88]
Carrier Global Corporation

[0001783180-23-000063:8k_2_02:89]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-23-000063:8k_2_02:90]
Net Income, Earnings Per Share and Effective Tax Rate

[0001783180-23-000063:8k_2_02:91]
|  | (Unaudited) |
|  | Three Months Ended September 30, 2022 |  | Nine Months Ended September 30, 2022 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,451 |  |  | $ | — |  |  | $ | 5,451 |  |  | $ | 15,316 |  |  | $ | — |  |  | $ | 15,316 |  |
| Operating profit | $ | 1,526 |  |  | (665) |  | a | $ | 861 |  |  | $ | 4,082 |  |  | (1,704) |  | a | $ | 2,378 |  |
| Operating margin | 28.0 | % |  |  |  | 15.8 | % |  | 26.7 | % |  |  |  | 15.5 | % |
| Income from operations before income taxes | $ | 1,470 |  |  | (665) |  | a | $ | 805 |  |  | $ | 3,915 |  |  | (1,732) |  | a,b | $ | 2,183 |  |
| Income tax expense | $ | (138) |  |  | (47) |  | c | $ | (185) |  |  | $ | (609) |  |  | 148 |  | c | $ | (461) |  |
| Effective tax rate | 9.4 | % |  |  |  | 23.0 | % |  | 15.6 | % |  |  |  | 21.1 | % |
| Net income attributable to common shareowners | $ | 1,312 |  |  | $ | (712) |  |  | $ | 600 |  |  | $ | 3,264 |  |  | $ | (1,584) |  |  | $ | 1,680 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 6 |  | a |  |  |  |  | $ | 29 |  | a |  |
| Amortization of acquired intangibles |  |  | 17 |  | a |  |  |  |  | 27 |  | a |  |
| Acquisition step-up amortization (1) |  |  | 24 |  | a |  |  |  |  | 24 |  | a |  |
| Acquisition/divestiture-related costs |  |  | 15 |  | a |  |  |  |  | 28 |  | a |  |
| Chubb gain |  |  | 7 |  | a |  |  |  |  | (1,105) |  | a |  |
| TCC acquisition-related gain (2) |  |  | (732) |  | a |  |  |  |  | (732) |  | a |  |
| Russia/Ukraine asset impairment |  |  | (2) |  | a |  |  |  |  | 3 |  | a |  |
| Charge resulting from legal matter |  |  | — |  | a |  |  |  |  | 22 |  | a |  |
| Debt extinguishment (gain), net (3) |  |  | — |  | b |  |  |  |  | (28) |  | b |  |
| Total adjustments |  |  | $ | (665) |  |  |  |  |  |  | $ | (1,732) |  |  |  |
| Tax effect on adjustments above |  |  | $ | (15) |  |  |  |  |  |  | $ | 185 |  |  |  |
| Tax specific adjustments |  |  | (32) |  |  |  |  |  |  | (37) |  |  |  |
| Total tax adjustments |  |  | $ | (47) |  | c |  |  |  |  | $ | 148 |  | c |  |
| Shares outstanding - Diluted | 856.5 |  |  |  |  | 856.5 |  |  | 864.3 |  |  |  |  | 864.3 |  |
| Earnings per share - Diluted | $ | 1.53 |  |  |  |  | $ | 0.70 |  |  | $ | 3.78 |  |  |  |  | $ | 1.94 |  |

[0001783180-23-000063:8k_2_02:92]
(1) Amortization of the step-up to fair value of acquired inventory and backlog.

[0001783180-23-000063:8k_2_02:93]
(2) The carrying value of our previously held TCC equity investments were recognized at fair value at the TCC acquisition date.

[0001783180-23-000063:8k_2_02:94]
(3)  The Company repurchased approximately $1.15 billion of aggregate principal senior notes on March 30, 2022 and recognized a net gain of $33 million and wrote-off $5 million of unamortized deferred financing costs in Interest (expense) income, net.

[0001783180-23-000063:8k_2_02:95]
13

[0001783180-23-000063:8k_2_02:96]
Carrier Global Corporation

[0001783180-23-000063:8k_2_02:97]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-23-000063:8k_2_02:98]
Components of Changes in Net Sales

[0001783180-23-000063:8k_2_02:99]
| Three Months Ended September 30, 2023 Compared with Three Months Ended September 30, 2022 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 4 | % |  | — | % |  | 3 | % |  | — | % |  | 7 | % |
| Refrigeration | (3) | % |  | 3 | % |  | — | % |  | — | % |  | — | % |
| Fire & Security | 6 | % |  | 1 | % |  | — | % |  | (5) | % |  | 2 | % |
| Consolidated | 3 | % |  | 1 | % |  | 1 | % |  | — | % |  | 5 | % |

[0001783180-23-000063:8k_2_02:100]
| Nine Months Ended September 30, 2023 Compared with Nine Months Ended September 30, 2022 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 6 | % |  | (1) | % |  | 12 | % |  | — | % |  | 17 | % |
| Refrigeration | (4) | % |  | — | % |  | (1) | % |  | — | % |  | (5) | % |
| Fire & Security | 8 | % |  | (1) | % |  | — | % |  | (3) | % |  | 4 | % |
| Consolidated | 4 | % |  | (1) | % |  | 8 | % |  | — | % |  | 11 | % |

[0001783180-23-000063:8k_2_02:101]
Historical Amounts of Amortization of Acquired Intangibles

[0001783180-23-000063:8k_2_02:102]
|  |  | (Unaudited) |
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |  |  |  |  |
| (In millions) |  | 2022 |  | 2022 |  | 2022 |  | 2022 |  | 2022 |  |  |  |  |
| HVAC |  | $ | 4 |  |  | $ | 4 |  |  | $ | 16 |  |  | $ | 22 |  |  | $ | 46 |  |  |  |  |  |
| Fire & Security |  | 1 |  |  | 1 |  |  | 1 |  |  | 1 |  |  | 4 |  |  |  |  |  |
| Total Carrier |  | 5 |  |  | 5 |  |  | 17 |  |  | 23 |  | 50 |  |  |  |  |  |
| Associated tax effect |  | (1) |  |  | (1) |  |  | (7) |  |  | (4) |  |  | (13) |  |  |  |  |  |
| Net impact to adjusted results |  | $ | 4 |  |  | $ | 4 |  |  | $ | 10 |  |  | $ | 19 |  |  | $ | 37 |  |  |  |  |  |

[0001783180-23-000063:8k_2_02:103]
14

[0001783180-23-000063:8k_2_02:104]
Free Cash Flow Reconciliation

[0001783180-23-000063:8k_2_02:105]
|  |  | (Unaudited) |
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |  | Q1 |  | Q2 |  | Q3 |
| (In millions) |  | 2022 |  | 2022 |  | 2022 |  | 2022 |  | 2022 |  | 2023 |  | 2023 |  | 2023 |
| Net cash flows provided by (used in) operating activities |  | $ | (202) |  |  | $ | 32 |  |  | $ | 790 |  |  | $ | 1,123 |  |  | $ | 1,743 |  |  | $ | 120 |  |  | $ | 384 |  |  | $ | 1,041 |  |
| Less: Capital expenditures |  | 56 |  |  | 66 |  |  | 91 |  |  | 140 |  | 353 |  |  | 70 |  |  | 74 |  |  | 92 |  |
| Free cash flow |  | $ | (258) |  |  | $ | (34) |  |  | $ | 699 |  |  | $ | 983 |  |  | $ | 1,390 |  |  | $ | 50 |  |  | $ | 310 |  |  | $ | 949 |  |

[0001783180-23-000063:8k_2_02:106]
Net Debt Reconciliation

[0001783180-23-000063:8k_2_02:107]
|  |  | (Unaudited) |
| (In millions) |  | September 30, 2023 |  | December 31, 2022 |
| Long-term debt |  | $ | 8,651 |  |  | $ | 8,702 |  |
| Current portion of long-term debt |  | 134 |  |  | 140 |  |
| Less: Cash and cash equivalents |  | 3,902 |  |  | 3,520 |  |
| Net debt |  | $ | 4,883 |  |  | $ | 5,322 |  |

[0001783180-23-000063:8k_2_02:108]
15
