# CARR notes — 0001783180-23-000065


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-23-000065:notes:1]
DESCRIPTION OF THE BUSINESS
Carrier Global Corporation (the "Company") is a global leader in intelligent climate and energy solutions with a focus on providing differentiated, digitally-enabled lifecycle solutions to its customers. The Company's portfolio includes industry-leading brands such as Carrier, Toshiba, Automated Logic, Carrier Transicold, Kidde, Edwards and LenelS2 that offer innovative heating, ventilating, air conditioning ("HVAC"), refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. The Company's operations are classified into three segments: HVAC, Refrigeration and Fire & Security.

[0001783180-23-000065:notes:2]
[same as prior period, unchanged from 0001783180-23-000056:notes:2]


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-23-000065:notes:3]
BASIS OF PRESENTATION
The Unaudited Condensed Consolidated Financial Statements include all accounts of the Company and its wholly-owned and majority-owned subsidiaries in which it has control. Inter-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that the Company controls and consolidates.

[0001783180-23-000065:notes:4]
[same as prior period, unchanged from 0001783180-23-000056:notes:4]

[0001783180-23-000065:notes:5]
[same as prior period, unchanged from 0001783180-23-000056:notes:5]

[0001783180-23-000065:notes:6]
[same as prior period, unchanged from 0001783180-23-000056:notes:6]

[0001783180-23-000065:notes:7]
On May 14, 2023, Kidde-Fenwal, Inc. ("KFI"), an indirect wholly-owned subsidiary of the Company, filed a petition for voluntary reorganization under Chapter 11 of the United States Bankruptcy Code ("Chapter 11") in the United States Bankruptcy Court for the District of Delaware. KFI, an industrial fire detection and suppression business historically reported in the Company's Fire & Security segment, has indicated that it intends to use the bankruptcy process to explore strategic alternatives, including the sale of KFI as a going concern. KFI has further stated that, during the Chapter 11 process, KFI expects that there will be no significant interruptions to its business operations. As of the petition date, KFI was deconsolidated and its respective assets and liabilities were derecognized from the Company's Unaudited Condensed Consolidated Financial Statements. See Note 19 - Commitments and Contingent Liabilities for additional information.

[0001783180-23-000065:notes:8]
[same as prior period, unchanged from 0001783180-23-000056:notes:8]

[0001783180-23-000065:notes:9]
[same as prior period, unchanged from 0001783180-23-000056:notes:9]

[0001783180-23-000065:notes:10]
[same as prior period, unchanged from 0001783180-23-000056:notes:10]

[0001783180-23-000065:notes:11]
[same as prior period, unchanged from 0001783180-23-000056:notes:11]

[0001783180-23-000065:notes:12]
[same as prior period, unchanged from 0001783180-23-000056:notes:12]

[0001783180-23-000065:notes:13]
[same as prior period, unchanged from 0001783180-23-000056:notes:13]

[0001783180-23-000065:notes:14]
On April 3, 2020 (the Distribution Date"), United Technologies Corporation ("UTC"), since renamed RTX Corporation ("Raytheon Technologies Corporation" or "RTX"), completed the spin-off of Carrier into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of Carrier to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In connection with the Separation, the Company issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020. On April 1, 2020 and April 2, 2020, the Company received cash contributions totaling $590 million from UTC related to the Separation.

[0001783180-23-000065:notes:15]
[same as prior period, unchanged from 0001783180-23-000056:notes:15]

[0001783180-23-000065:notes:16]
[same as prior period, unchanged from 0001783180-23-000056:notes:16]


## us-gaap:InventoryDisclosureTextBlock

[0001783180-23-000065:notes:17]
INVENTORIES, NET
Inventories are stated at the lower of cost or estimated net realizable value. Cost is primarily determined based on the first-in, first-out inventory method ("FIFO") or average cost methods, which approximates current replacement cost. However, certain subsidiaries use the last-in, first-out inventory method ("LIFO").

[0001783180-23-000065:notes:18]
[same as prior period, unchanged from 0001783180-23-000056:notes:18]

[0001783180-23-000065:notes:19]
| (In millions) |  | September 30,2023 |  | December 31,2022 |
| Raw materials |  | $ | 782 |  |  | $ | 884 |  |
| Work-in-process |  | 260 |  |  | 230 |  |
| Finished goods |  | 1,520 |  |  | 1,526 |  |
| Inventories, net |  | $ | 2,562 |  |  | $ | 2,640 |  |

[0001783180-23-000065:notes:20]
The Company performs periodic assessments utilizing customer demand, production requirements and historical usage rates to determine the existence of excess and obsolete inventory and records necessary provisions to reduce such inventories to the lower of cost or estimated net realizable value. Raw materials, work-in-process and finished goods are net of valuation reserves of $230 million and $190 million as of September 30, 2023 and December 31, 2022, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-23-000065:notes:21]
GOODWILL AND INTANGIBLE ASSETSThe Company records goodwill as the excess of the purchase price over the fair value of the net assets acquired in a business combination. Goodwill is tested and reviewed annually for impairment on July 1 or whenever there is a material change in events or circumstances that indicates that the fair value of the reporting unit may be less than its carrying value. 
The changes in the carrying amount of goodwill were as follows:

[0001783180-23-000065:notes:22]
| (In millions) |  |  | HVAC |  | Refrigeration |  | Fire & Security |  | Total |
| Balance as of December 31, 2022 |  |  | $ | 6,392 |  |  | $ | 1,197 |  |  | $ | 2,388 |  |  | $ | 9,977 |  |
| Acquisitions / divestitures |  |  | — |  |  | (4) |  |  | — |  |  | (4) |  |
| Foreign currency translation |  |  | (91) |  |  | (16) |  |  | (41) |  |  | (148) |  |
| Balance as of September 30, 2023 |  |  | $ | 6,301 |  |  | $ | 1,177 |  |  | $ | 2,347 |  |  | $ | 9,825 |  |

[0001783180-23-000065:notes:23]
[same as prior period, unchanged from 0001783180-23-000056:notes:23]

[0001783180-23-000065:notes:24]
[same as prior period, unchanged from 0001783180-23-000056:notes:24]

[0001783180-23-000065:notes:25]
|  |  | September 30, 2023 |  | December 31, 2022 |
| (In millions) |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Amortized: |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 1,387 |  |  | $ | (766) |  |  | $ | 621 |  |  | $ | 1,431 |  |  | $ | (720) |  |  | $ | 711 |  |
| Patents and trademarks |  | 375 |  |  | (201) |  |  | 174 |  |  | 401 |  |  | (191) |  |  | 210 |  |
| Service portfolios and other |  | 915 |  |  | (674) |  |  | 241 |  |  | 953 |  |  | (595) |  |  | 358 |  |
|  |  | 2,677 |  |  | (1,641) |  |  | 1,036 |  |  | 2,785 |  |  | (1,506) |  |  | 1,279 |  |
| Unamortized: |  |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks and other |  | 64 |  |  | — |  |  | 64 |  |  | 63 |  |  | — |  |  | 63 |  |
| Intangible assets, net |  | $ | 2,741 |  |  | $ | (1,641) |  |  | $ | 1,100 |  |  | $ | 2,848 |  |  | $ | (1,506) |  |  | $ | 1,342 |  |

[0001783180-23-000065:notes:26]
[same as prior period, unchanged from 0001783180-23-000056:notes:26]

[0001783180-23-000065:notes:27]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Amortization expense of Intangible assets |  | $ | 60 |  |  | $ | 38 |  |  | $ | 185 |  |  | $ | 79 |  |

[0001783180-23-000065:notes:28]
Annual Impairment Test

[0001783180-23-000065:notes:29]
The Company tested its goodwill and indefinite-lived intangible assets for impairment on July 1 as part of its annual assessment. For each test, the Company qualitatively assessed all relevant events or circumstances that could impact the estimate of fair value and determined it was more likely than not that the fair value of each reporting unit and indefinite-lived intangible assets exceeded their carrying amount.


## us-gaap:DebtDisclosureTextBlock

[0001783180-23-000065:notes:30]
BORROWINGS AND LINES OF CREDIT
Long-term debt consisted of the following:

[0001783180-23-000065:notes:31]
| (In millions) |  |  |  | September 30,2023 |  | December 31,2022 |
| 2.242% Notes due February 15, 2025 |  |  |  | $ | 1,200 |  |  | $ | 1,200 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 900 |  |  | 900 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term notes |  |  |  | 8,350 |  |  | 8,350 |  |
| Japanese Term Loan Facility |  |  |  | 362 |  |  | 404 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 154 |  |  | 149 |  |
| Discounts and debt issuance costs |  |  |  | (81) |  |  | (61) |  |
| Total debt |  |  |  | 8,785 |  |  | 8,842 |  |
| Less: current portion of long-term debt |  |  |  | 134 |  |  | 140 |  |
| Long-term debt, net of current portion |  |  |  | $ | 8,651 |  |  | $ | 8,702 |  |

[0001783180-23-000065:notes:32]
Japanese Term Loan Facility

[0001783180-23-000065:notes:33]
On July 15, 2022, the Company entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings under the Japanese Term Loan Facility bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. In addition, the Japanese Term Loan Facility is subject to customary covenants including a covenant to maintain a maximum consolidated leverage ratio. The Company capitalized $2 million of deferred financing costs which are being amortized over its term. On July 25, 2022, the Company borrowed JPY 54 billion under the Japanese Term Loan Facility and used the proceeds to fund a portion of the TCC acquisition and to pay related fees and expenses.

[0001783180-23-000065:notes:34]
Revolving Credit Facility

[0001783180-23-000065:notes:35]
On May 19, 2023, the Company entered into a revolving credit agreement with JPMorgan Chase Bank, N.A., as administrative agent, and certain other lenders, permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures in May 2028 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and can be used for other general corporate purposes. Borrowings are available in U.S. Dollars and Euros. U.S. Dollar borrowings can bear interest at either a Term SOFR Rate plus 0.10% and a ratings-based margin or, alternatively, at an alternate base rate plus a ratings-based margin. Euro borrowings bear interest at an adjusted EURIBOR rate plus a ratings-based margin. A ratings-based commitment fee is charged on unused commitments. Upon entering into the agreement, the Company terminated its existing revolving credit facility that was set to mature in April 2025. In addition, the Company capitalized $2 million of deferred financing costs which are being amortized over its term. As of September 30, 2023, there were no borrowings outstanding under the Revolving Credit Facility.

[0001783180-23-000065:notes:36]
Commercial Paper Program

[0001783180-23-000065:notes:37]
The Company has a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of September 30, 2023, there were no borrowings outstanding under the commercial paper program.

[0001783180-23-000065:notes:38]
Project Financing Arrangements

[0001783180-23-000065:notes:39]
The Company is involved in long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $14 million and $27 million of debt during the nine months ended September 30, 2023 and 2022, respectively. Long-term debt repayments associated with these financing arrangements during the nine months ended September 30, 2023 and 2022 were $15 million and $70 million, respectively.

[0001783180-23-000065:notes:40]
Debt Covenants

[0001783180-23-000065:notes:41]
The Revolving Credit Facility, the indenture for the long-term notes and the Japanese Term Loan Facility contain affirmative and negative covenants customary for financings of these types, which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of September 30, 2023, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

[0001783180-23-000065:notes:42]
Tender Offers

[0001783180-23-000065:notes:43]
On March 15, 2022, the Company commenced tender offers to purchase up to $1.15 billion ("Aggregate Tender Cap") aggregate principal of the Company's 2.242% Notes due 2025 and 2.493% Notes due 2027 (together, the "Senior Notes"). The tender offers included payment of applicable accrued and unpaid interest up to the settlement date, along with a fixed spread for early repayment. Based on participation, the Company elected to settle the tender offers on March 30, 2022. The aggregate principal amount of Senior Notes validly tendered and accepted was approximately $1.15 billion, which included $800 million of Notes due 2025 and $350 million of Notes due 2027. As a result, the Company recognized a net gain of $33 million and wrote off $5 million of unamortized deferred financing costs within Interest (expense) income, net on the accompanying Unaudited Condensed Consolidated Statement of Operations during the three months ended March 31, 2022.


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-23-000065:notes:44]
[same as prior period, unchanged from 0001783180-23-000056:notes:42]

[0001783180-23-000065:notes:45]
[same as prior period, unchanged from 0001783180-23-000056:notes:43]

[0001783180-23-000065:notes:46]
[same as prior period, unchanged from 0001783180-23-000056:notes:44]

[0001783180-23-000065:notes:47]
[same as prior period, unchanged from 0001783180-23-000056:notes:45]

[0001783180-23-000065:notes:48]
[same as prior period, unchanged from 0001783180-23-000056:notes:46]

[0001783180-23-000065:notes:49]
[same as prior period, unchanged from 0001783180-23-000056:notes:47]

[0001783180-23-000065:notes:50]
[same as prior period, unchanged from 0001783180-23-000056:notes:48]

[0001783180-23-000065:notes:51]
[same as prior period, unchanged from 0001783180-23-000056:notes:49]

[0001783180-23-000065:notes:52]
In connection with the proposed acquisition of the VCS Business, the Company entered into window forward contracts with Bank of America N.A. and JPMorgan Chase Bank N.A. to mitigate the foreign currency risk of the expected cash outflows associated with the Euro-denominated purchase price. The instruments have an aggregate notional amount of €7 billion and a settlement window between November 28, 2023 and February 27, 2024. The window forward contracts are measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates with changes in fair value reported in Other income (expense), net in the accompanying Unaudited Condensed Consolidated Statement of Operations. During the three and nine months ended September 30, 2023, the Company recognized a $257 million and $368 million loss on the mark-to-market valuation of its window forward contracts, respectively.

[0001783180-23-000065:notes:53]
During the three months ended September 30, 2023, the Company entered into several floating-to-fixed interest rate swap contracts to mitigate interest rate exposure on the forecasted issuance of long-term debt. The contracts have an aggregate notional amount of $1.275 billion and were designated as cash flow hedges. The interest rate swap contracts are measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates with changes in fair value reported in Equity in the accompanying Unaudited Condensed Consolidated Balance Sheet. During the three months ended September 30, 2023, the Company recorded an $80 million unrealized gain on the mark-to-market valuation of its interest rate swap contracts.

[0001783180-23-000065:notes:54]
[same as prior period, unchanged from 0001783180-23-000056:notes:51]

[0001783180-23-000065:notes:55]
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| September 30, 2023 |  |  |  |  |  |  |  |  |
| Derivative assets (1)(3) |  | $ | 116 |  |  | $ | — |  |  | $ | 116 |  |  | $ | — |  |
| Derivative liabilities (2)(3) |  | $ | (408) |  |  | $ | — |  |  | $ | (408) |  |  | $ | — |  |
| December 31, 2022 |  |  |  |  |  |  |  |  |
| Derivative assets (1) (3) |  | $ | 28 |  |  | $ | — |  |  | $ | 28 |  |  | $ | — |  |
| Derivative liabilities (2) (3) |  | $ | (48) |  |  | $ | — |  |  | $ | (48) |  |  | $ | — |  |

[0001783180-23-000065:notes:56]
(1) Included in Other assets, current and Other assets on the accompanying Unaudited Condensed Consolidated Balance Sheet.

[0001783180-23-000065:notes:57]
(2) Included in Accrued liabilities and Other long-term liabilities on the accompanying Unaudited Condensed Consolidated Balance Sheet.

[0001783180-23-000065:notes:58]
(3) Includes cross currency swaps, window forward contracts and interest rate swap contracts.

[0001783180-23-000065:notes:59]
[same as prior period, unchanged from 0001783180-23-000056:notes:56]

[0001783180-23-000065:notes:60]
|  |  | September 30, 2023 |  | December 31, 2022 |  |
| (In millions) |  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  |
| Total long-term Notes (1) |  | $ | 8,350 |  |  | $ | 6,653 |  |  | $ | 8,350 |  |  | $ | 6,832 |  |  |

[0001783180-23-000065:notes:61]
[same as prior period, unchanged from 0001783180-23-000056:notes:58]

[0001783180-23-000065:notes:62]
[same as prior period, unchanged from 0001783180-23-000056:notes:59]


## us-gaap:FairValueMeasurementPolicyPolicyTextBlock

[0001783180-23-000065:notes:63]
[same as prior period, unchanged from 0001783180-23-000056:notes:60]

[0001783180-23-000065:notes:64]
During the three months ended September 30, 2023, the Company entered into several floating-to-fixed interest rate swap contracts to mitigate interest rate exposure on the forecasted issuance of long-term debt. The contracts have an aggregate notional amount of $1.275 billion and were designated as cash flow hedges. The interest rate swap contracts are measured at fair value on a recurring basis using observable market inputs, such as forward, discount and interest rates with changes in fair value reported in Equity in the accompanying Unaudited Condensed Consolidated Balance Sheet. During the three months ended September 30, 2023, the Company recorded an $80 million unrealized gain on the mark-to-market valuation of its interest rate swap contracts.
The fair value of the Company's long-term debt is measured based on observable market inputs which are considered Level 1 within the fair value hierarchy. The carrying value of cash and cash equivalents, accounts receivable, accounts payable and short-term borrowings approximate fair value due to the short-term nature of these accounts and would be classified as Level 1 in the fair value hierarchy. The Company's financing leases and project financing obligations, included in Long-term debt and Current portion of long-term debt on the accompanying Unaudited Condensed Consolidated Balance Sheet, approximate fair value and are classified as Level 3 in the fair value hierarchy.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-23-000065:notes:65]
EMPLOYEE BENEFIT PLANSThe Company sponsors both funded and unfunded domestic and international defined benefit pension and defined contribution plans. In addition, the Company contributes to various domestic and international multi-employer pension plans.
Contributions to the plans were as follows:

[0001783180-23-000065:notes:66]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Defined benefit plans |  | $ | 6 |  |  | $ | 4 |  |  | $ | 17 |  |  | $ | 10 |  |
| Defined contribution plans |  | $ | 30 |  |  | $ | 29 |  |  | $ | 96 |  |  | $ | 95 |  |
| Multi-employer pension plans |  | $ | 3 |  |  | $ | 5 |  |  | $ | 11 |  |  | $ | 11 |  |

[0001783180-23-000065:notes:67]
[same as prior period, unchanged from 0001783180-23-000056:notes:65]

[0001783180-23-000065:notes:68]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Service cost |  | $ | 4 |  |  | $ | 5 |  |  | $ | 12 |  |  | $ | 14 |  |
| Interest cost |  | 8 |  |  | 5 |  |  | 24 |  |  | 13 |  |
| Expected return on plan assets |  | (8) |  |  | (7) |  |  | (24) |  |  | (20) |  |
| Amortization of prior service credit |  | 1 |  |  | 1 |  |  | 2 |  |  | 2 |  |
| Recognized actuarial net (gain) loss |  | (1) |  |  | 2 |  |  | (2) |  |  | 7 |  |
| Net periodic pension expense (benefit) |  | $ | 4 |  |  | $ | 6 |  |  | $ | 12 |  |  | $ | 16 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001783180-23-000065:notes:69]
[same as prior period, unchanged from 0001783180-23-000056:notes:67]

[0001783180-23-000065:notes:70]
[same as prior period, unchanged from 0001783180-23-000056:notes:68]

[0001783180-23-000065:notes:71]
[same as prior period, unchanged from 0001783180-23-000056:notes:69]

[0001783180-23-000065:notes:72]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Equity compensation costs - equity settled |  | $ | 23 |  |  | $ | 17 |  |  | $ | 63 |  |  | $ | 58 |  |
| Equity compensation costs - cash settled (1) |  | 1 |  |  | 1 |  |  | 3 |  |  | (16) |  |
| Total stock-based compensation expense |  | $ | 24 |  |  | $ | 18 |  |  | $ | 66 |  |  | $ | 42 |  |

[0001783180-23-000065:notes:73]
[same as prior period, unchanged from 0001783180-23-000056:notes:71]


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-23-000065:notes:74]
PRODUCT WARRANTIESIn the ordinary course of business, the Company provides standard warranty coverage on its products. Provisions for these amounts are established at the time of sale and estimated primarily based on product warranty terms and historical claims experience. In addition, the Company incurs discretionary costs to service its products in connection with specific product performance issues. Provisions for these amounts are established when they are known and estimable. The Company assesses the adequacy of its initial provisions and will make adjustments as necessary based on known or anticipated claims or as new information becomes available that suggests it is probable that future costs will be different than estimated amounts. Amounts associated with these provisions are classified on the accompanying Unaudited Condensed Consolidated Balance Sheet as Accrued liabilities or Other long-term liabilities based on their anticipated settlement date.
The changes in the carrying amount of warranty related provisions are as follows:

[0001783180-23-000065:notes:75]
|  |  | Nine Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |
| Balance as of January 1, |  | $ | 552 |  |  | $ | 524 |  |
| Warranties, performance guarantees issued and changes in estimated liability |  | 186 |  |  | 120 |  |
| Settlements made |  | (146) |  |  | (116) |  |
| Other |  | (15) |  |  | 9 |  |
| Balance as of September 30, |  | $ | 577 |  |  | $ | 537 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-23-000065:notes:76]
EQUITY
The authorized number of shares of common stock of Carrier is 4,000,000,000 shares of $0.01 par value. As of September 30, 2023 and December 31, 2022, 882,497,944 and 876,487,480 shares of common stock were issued, respectively, which includes 43,490,981 and 42,103,995 shares of treasury stock, respectively.

[0001783180-23-000065:notes:77]
[same as prior period, unchanged from 0001783180-23-000056:notes:76]

[0001783180-23-000065:notes:78]
[same as prior period, unchanged from 0001783180-23-000056:notes:77]

[0001783180-23-000065:notes:79]
During the nine months ended September 30, 2023, the Company repurchased 1.4 million shares of common stock for an aggregate purchase price of $62 million. As a result, the Company has approximately $2.1 billion remaining under the current authorization at September 30, 2023.

[0001783180-23-000065:notes:80]
[same as prior period, unchanged from 0001783180-23-000056:notes:79]

[0001783180-23-000065:notes:81]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three and nine months ended September 30, 2023 is as follows:

[0001783180-23-000065:notes:82]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  | Unrealized Hedging Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2022 |  | $ | (1,604) |  |  | $ | (84) |  |  |  |  | $ | — |  |  | $ | (1,688) |  |
| Other comprehensive income (loss) before reclassifications, net |  | 52 |  |  | — |  |  |  |  | — |  |  | 52 |  |
| Amounts reclassified, pre-tax |  | — |  |  | — |  |  |  |  | — |  |  | — |  |
| Tax expense (benefit) reclassified |  | — |  |  | — |  |  |  |  | — |  |  | — |  |
| Balance as of March 31, 2023 |  | $ | (1,552) |  |  | $ | (84) |  |  |  |  | $ | — |  |  | $ | (1,636) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (55) |  |  | — |  |  |  |  | — |  |  | (55) |  |
| Amounts reclassified, pre-tax |  | — |  |  | — |  |  |  |  | — |  |  | — |  |
| Tax expense (benefit) reclassified |  | — |  |  | — |  |  |  |  | — |  |  | — |  |
| Balance as of June 30, 2023 |  | $ | (1,607) |  |  | $ | (84) |  |  |  |  | $ | — |  |  | $ | (1,691) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (245) |  |  | — |  |  |  |  | 80 |  |  | (165) |  |
| Amounts reclassified, pre-tax |  | — |  |  | — |  |  |  |  | — |  |  | — |  |
| Tax expense (benefit) reclassified |  | — |  |  | — |  |  |  |  | — |  |  | — |  |
| Balance as of September 30, 2023 |  | $ | (1,852) |  |  | $ | (84) |  |  |  |  | $ | 80 |  |  | $ | (1,856) |  |

[0001783180-23-000065:notes:83]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three and nine months ended September 30, 2022 is as follows:

[0001783180-23-000065:notes:84]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2021 |  | $ | (505) |  |  | $ | (484) |  |  |  |  |  |  | $ | (989) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (61) |  |  | (4) |  |  |  |  |  |  | (65) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 3 |  |  |  |  |  |  | 3 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (1) |  |  |  |  |  |  | (1) |  |
| Chubb divestiture |  | (574) |  |  | 329 |  |  |  |  |  |  | (245) |  |
| Balance as of March 31, 2022 |  | $ | (1,140) |  |  | $ | (157) |  |  |  |  |  |  | $ | (1,297) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (480) |  |  | — |  |  |  |  |  |  | (480) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 3 |  |  |  |  |  |  | 3 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (1) |  |  |  |  |  |  | (1) |  |
| Balance as of June 30, 2022 |  | $ | (1,620) |  |  | $ | (155) |  |  |  |  |  |  | $ | (1,775) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (632) |  |  | — |  |  |  |  |  |  | (632) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 3 |  |  |  |  |  |  | 3 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (1) |  |  |  |  |  |  | (1) |  |
| Balance as of September 30, 2022 |  | $ | (2,252) |  |  | $ | (153) |  |  |  |  |  |  | $ | (2,405) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-23-000065:notes:85]
REVENUE RECOGNITIONThe Company accounts for revenue in accordance with ASC 606: Revenue from Contracts with Customers. Revenue is recognized when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefits from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company’s performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.
Sales disaggregated by product and service are as follows:

[0001783180-23-000065:notes:86]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 3,533 |  |  | $ | 3,330 |  |  | $ | 10,488 |  |  | $ | 8,974 |  |
| Service |  | 475 |  |  | 404 |  |  | 1,358 |  |  | 1,118 |  |
| HVAC sales |  | 4,008 |  |  | 3,734 |  |  | 11,846 |  |  | 10,092 |  |
| Product |  | 808 |  |  | 811 |  |  | 2,453 |  |  | 2,603 |  |
| Service |  | 116 |  |  | 112 |  |  | 341 |  |  | 337 |  |
| Refrigeration sales |  | 924 |  |  | 923 |  |  | 2,794 |  |  | 2,940 |  |
| Product |  | 864 |  |  | 859 |  |  | 2,546 |  |  | 2,468 |  |
| Service |  | 59 |  |  | 46 |  |  | 178 |  |  | 142 |  |
| Fire & Security sales |  | 923 |  |  | 905 |  |  | 2,724 |  |  | 2,610 |  |
| Total segment sales |  | 5,855 |  |  | 5,562 |  |  | 17,364 |  |  | 15,642 |  |
| Eliminations and other |  | (124) |  |  | (111) |  |  | (368) |  |  | (326) |  |
| Net sales |  | $ | 5,731 |  |  | $ | 5,451 |  |  | $ | 16,996 |  |  | $ | 15,316 |  |

[0001783180-23-000065:notes:87]
[same as prior period, unchanged from 0001783180-23-000056:notes:87]

[0001783180-23-000065:notes:88]
[same as prior period, unchanged from 0001783180-23-000056:notes:88]

[0001783180-23-000065:notes:89]
| (In millions) |  | September 30,2023 |  | December 31,2022 |
| Contract assets, current |  | $ | 605 |  |  | $ | 537 |  |
| Contract assets, non-current (included within Other assets) |  | 18 |  |  | 6 |  |
| Total contract assets |  | 623 |  |  | 543 |  |
| Contract liabilities, current |  | (496) |  |  | (449) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (166) |  |  | (174) |  |
| Total contract liabilities |  | (662) |  |  | (623) |  |
| Net contract assets (liabilities) |  | $ | (39) |  |  | $ | (80) |  |

[0001783180-23-000065:notes:90]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under a contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to a customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract.

[0001783180-23-000065:notes:91]
The Company recognized revenue of $325 million during the nine months ended September 30, 2023 that related to contract liabilities as of January 1, 2023. The Company expects a majority of its current contract liabilities at the end of the period to be recognized as revenue in the next 12 months.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001783180-23-000065:notes:92]
[same as prior period, unchanged from 0001783180-23-000056:notes:91]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-23-000065:notes:93]
RESTRUCTURING COSTSThe Company incurs costs associated with restructuring initiatives intended to improve operating performance, profitability and working capital levels. Actions associated with these initiatives may include improving productivity, workforce reductions and 
the consolidation of facilities. Due to the size, nature and frequency of these discrete plans, they are fundamentally different from the Company's ongoing productivity actions.

[0001783180-23-000065:notes:94]
[same as prior period, unchanged from 0001783180-23-000056:notes:93]

[0001783180-23-000065:notes:95]
|  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC | $ | 25 |  |  | $ | 2 |  |  | $ | 27 |  |  | $ | 8 |  |
| Refrigeration | 4 |  |  | 3 |  |  | 14 |  |  | 9 |  |
| Fire & Security | (1) |  |  | 1 |  |  | 11 |  |  | 10 |  |
| Total Segment | 28 |  |  | 6 |  |  | 52 |  |  | 27 |  |
| General corporate expenses | — |  |  | — |  |  | 2 |  |  | 2 |  |
| Total restructuring costs | $ | 28 |  |  | $ | 6 |  |  | $ | 54 |  |  | $ | 29 |  |
| Cost of sales | $ | 3 |  |  | $ | 1 |  |  | $ | 12 |  |  | $ | 8 |  |
| Selling, general and administrative | 25 |  |  | 5 |  |  | 42 |  |  | 21 |  |
| Total restructuring costs | $ | 28 |  |  | $ | 6 |  |  | $ | 54 |  |  | $ | 29 |  |

[0001783180-23-000065:notes:96]
The following table summarizes changes in the restructuring reserve, included in Accrued liabilities on the accompanying Unaudited Condensed Consolidated Balance Sheet:

[0001783180-23-000065:notes:97]
|  |  | Nine Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |
| Balance as of January 1, |  | $ | 24 |  |  | $ | 54 |  |
| Net pre-tax restructuring costs |  | 54 |  |  | 29 |  |
| Utilization, foreign exchange and other |  | (34) |  |  | (50) |  |
| Balance as of September 30, |  | $ | 44 |  |  | $ | 33 |  |

[0001783180-23-000065:notes:98]
During the nine months ended September 30, 2023 and 2022, charges associated with restructuring initiatives related to cost reduction efforts. Amounts recognized primarily related to severance due to workforce reductions and exit costs due to the consolidation of field operations. As of September 30, 2023, the Company had $44 million accrued for costs associated with its announced restructuring initiatives, all of which is expected to be paid within one year.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-23-000065:notes:99]
INCOME TAXES
The Company accounts for income tax expense in accordance with ASC 740, Income Taxes ("ASC 740"), which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 35.9% for the three months ended September 30, 2023 compared with 9.4% for the three months ended September 30, 2022. The year-over-year increase was primarily driven by the non-deductible loss of $257 million on the mark-to-market valuation of the Company's window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business and a tax charge of $33 million related to the Company's intention to no longer permanently reinvest historical earnings from certain jurisdictions. In addition, the three months ended September 30, 2022 included a lower effective tax rate on a $732 million non-cash gain resulting from the recognition of the Company's previously held TCC equity investments at fair value upon acquisition of TCC compared to the Company's U.S. statutory tax rate.

[0001783180-23-000065:notes:100]
The effective tax rate was 34.4% for the nine months ended September 30, 2023 compared with 15.6% for the nine months ended September 30, 2022. The year-over-year increase was primarily driven by the non-deductible loss of $297 million on the deconsolidation of KFI due to its Chapter 11 filing and the $368 million loss on the mark-to-market valuation of the Company's

[0001783180-23-000065:notes:101]
window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business. In addition, the nine months ended September 30, 2022 included a lower effective tax rate on a $732 million non-cash gain resulting from the recognition of the Company's previously held TCC equity investments at fair value upon acquisition of TCC and the $1.1 billion Chubb gain compared with the Company's U.S. statutory rate and a favorable tax adjustment of $32 million associated with foreign tax credits generated and utilized in the prior year.

[0001783180-23-000065:notes:102]
[same as prior period, unchanged from 0001783180-23-000056:notes:100]

[0001783180-23-000065:notes:103]
[same as prior period, unchanged from 0001783180-23-000056:notes:101]

[0001783180-23-000065:notes:104]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. The Company believes that it is reasonably possible that a net decrease in unrecognized tax benefits of $70 million to $85 million may occur within 12 months as a result of additional uncertain tax positions, the Separation, the revaluation of uncertain tax positions arising from examinations, appeals, court decisions and/or the expiration of tax statutes.


## us-gaap:EarningsPerShareTextBlock

[0001783180-23-000065:notes:105]
EARNINGS PER SHARE
Earnings per share is computed by dividing Net income attributable to common shareowners by the weighted-average number of shares of common stock outstanding during the period (excluding treasury stock). Diluted earnings per share is computed by giving effect to all potentially dilutive stock awards that are outstanding. The computation of diluted earnings per share excludes the effect of the potential exercise of stock-based awards, including stock appreciation rights and stock options, when the effect of the potential exercise would be anti-dilutive.

[0001783180-23-000065:notes:106]
[same as prior period, unchanged from 0001783180-23-000056:notes:104]

[0001783180-23-000065:notes:107]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions, except per share amounts) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net income attributable to common shareowners |  | $ | 357 |  |  | $ | 1,312 |  |  | $ | 929 |  |  | $ | 3,264 |  |
| Basic weighted-average number of shares outstanding |  | 838.7 |  |  | 839.6 |  |  | 836.6 |  |  | 846.1 |  |
| Stock awards and equity units (share equivalent) |  | 16.0 |  |  | 16.9 |  |  | 16.1 |  |  | 18.2 |  |
| Diluted weighted-average number of shares outstanding |  | 854.7 |  |  | 856.5 |  |  | 852.7 |  |  | 864.3 |  |
| Antidilutive shares excluded from computation of diluted earnings per share |  | 2.0 |  |  | 4.5 |  |  | 1.9 |  |  | 3.1 |  |
| Earnings Per Share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.43 |  |  | $ | 1.56 |  |  | $ | 1.11 |  |  | $ | 3.86 |  |
| Diluted |  | $ | 0.42 |  |  | $ | 1.53 |  |  | $ | 1.09 |  |  | $ | 3.78 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001783180-23-000065:notes:108]
[same as prior period, unchanged from 0001783180-23-000056:notes:106]

[0001783180-23-000065:notes:109]
[same as prior period, unchanged from 0001783180-23-000056:notes:107]

[0001783180-23-000065:notes:110]
[same as prior period, unchanged from 0001783180-23-000056:notes:108]

[0001783180-23-000065:notes:111]
The allocation of the purchase price is as follows:

[0001783180-23-000065:notes:112]
| (In millions) |  | August 1, 2022 |
| Cash and cash equivalents |  | $ | 462 |  |
| Accounts receivable |  | 428 |  |
| Inventories |  | 373 |  |
| Other assets, current |  | 54 |  |
| Fixed assets |  | 330 |  |
| Intangible assets |  | 965 |  |
| Goodwill |  | 876 |  |
| Other assets |  | 299 |  |
| Accounts payable |  | (412) |  |
| Accrued liabilities |  | (445) |  |
| Contract liabilities, current |  | (21) |  |
| Other long-term liabilities |  | (569) |  |
| Net assets acquired |  | $ | 2,340 |  |
| Less: Fair value of non-controlling interests |  | (22) |  |
| Less: Fair value of previously held TCC equity investments |  | (1,398) |  |
| Total cash consideration |  | $ | 920 |  |

[0001783180-23-000065:notes:113]
The excess purchase price over the estimated fair value of the net assets acquired was recognized as goodwill and totaled $876 million, which is not deductible for tax purposes. Accounts receivable and current liabilities were stated at their historical carrying value, which approximates fair value given the short-term nature of these assets and liabilities. The estimate of fair value for inventory and fixed assets was based on an assessment of the acquired assets' condition as well as an evaluation of the current market value of such assets. The sale agreement included several customary provisions to settle working capital and other transaction-related items as of the date of sale. During 2022, the parties finalized these amounts in accordance with the terms of the sale agreement and the Company paid an additional $41 million to Toshiba Corporation in 2023. In addition, the parties finalized amounts related to pension funding levels during 2023 which resulted in the Company receiving $12 million from Toshiba Corporation.

[0001783180-23-000065:notes:114]
The Company recorded intangible assets based on its estimate of fair value which consisted of the following:

[0001783180-23-000065:notes:115]
[same as prior period, unchanged from 0001783180-23-000056:notes:113]

[0001783180-23-000065:notes:116]
The valuation of intangible assets was determined using an income approach methodology including the multi-period excess earnings method and the relief from royalty method. Key assumptions used in estimating future cash flows included projected revenue growth rates, EBIT margins, discount rates, customer attrition rates and royalty rates among others. The projected future cash flows are discounted to present value using an appropriate discount rate. As of September 30, 2023, the Company has finalized the process of allocating the purchase price and valuing the acquired assets and liabilities.

[0001783180-23-000065:notes:117]
The Company previously accounted for its minority ownership in TCC under the equity method of accounting. In connection

[0001783180-23-000065:notes:118]
with the transaction, the carrying value of the Company's previously held TCC equity investments were recognized at fair value at the date of acquisition using an income approach methodology. As a result, the Company recognized a $696 million non-cash gain within Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations. In addition, the assets, liabilities and results of operations of TCC are consolidated in the accompanying Unaudited Condensed Consolidated Financial Statements as of the date of acquisition and reported within the Company's HVAC segment. The Company incurred $29 million of acquisition-related costs during 2022, of which $26 million was recognized during the nine months ended September 30, 2022 and included within Selling, general and administrative on the accompanying Unaudited Condensed Consolidated Statement of Operations. The Company has not included pro forma financial information required under ASC 805 as the pro forma impact was not significant.

[0001783180-23-000065:notes:119]
[same as prior period, unchanged from 0001783180-23-000056:notes:116]

[0001783180-23-000065:notes:120]
[same as prior period, unchanged from 0001783180-23-000056:notes:117]

[0001783180-23-000065:notes:121]
On April 25, 2023, the Company entered into commitment letters with JPMorgan Chase Bank, N.A., BofA Securities, Inc. and Bank of America, N.A. to provide a €8.2 billion aggregate principal, senior unsecured bridge term loan facility (the "Bridge Loan"). Proceeds from the Bridge Loan are expected to be used to fund a portion of the Euro-denominated purchase price of the VCS Business if other debt financing is not secured by the acquisition date. The Company capitalized $48 million of deferred financing costs associated with the Bridge Loan which are being amortized over the commitment period. On May 19, 2023, the aggregate principal amount of the Bridge Loan was reduced by €2.3 billion upon entering into a senior unsecured delayed draw term loan credit agreement. As a result, the Company accelerated the amortization on $10 million of deferred financing costs in Interest expense.

[0001783180-23-000065:notes:122]
[same as prior period, unchanged from 0001783180-23-000056:notes:119]


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001783180-23-000065:notes:123]
[same as prior period, unchanged from 0001783180-23-000056:notes:120]

[0001783180-23-000065:notes:124]
On January 3, 2022, the Company completed the Chubb Sale for net proceeds of $2.9 billion. Chubb, which was reported within the Company’s Fire & Security segment, delivered essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. The sale agreement included several customary provisions to settle working capital and other transaction-related items as of the date of sale. The parties finalized these amounts in accordance with the terms of the sale agreement during 2022. During the nine months ended September 30, 2022, the Company recognized a net gain on the sale of $1.1 billion, which is included in Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations.

[0001783180-23-000065:notes:125]
On April 25, 2023, the Company announced plans to exit its Fire & Security and Commercial Refrigeration businesses over the course of 2024. Carrier expects to use the proceeds from these transactions to reduce leverage, advance the Company’s capital allocation priorities and for general corporate purposes. The planned exit is not expected to impact UTEC, Fire & Security’s controls business for residential HVAC customers or the Sensitech monitoring businesses.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-23-000065:notes:126]
SEGMENT FINANCIAL DATA
The Company conducts its operations through three reportable operating segments: HVAC, Refrigeration and Fire & Security. In accordance with ASC 280 - Segment Reporting, the Company's segments maintain separate financial information for which results of operations are evaluated on a regular basis by the Company's Chief Operating Decision Maker in deciding how to allocate resources and in assessing performance.

[0001783180-23-000065:notes:127]
[same as prior period, unchanged from 0001783180-23-000056:notes:124]

[0001783180-23-000065:notes:128]
[same as prior period, unchanged from 0001783180-23-000056:notes:125]

[0001783180-23-000065:notes:129]
[same as prior period, unchanged from 0001783180-23-000056:notes:126]

[0001783180-23-000065:notes:130]
[same as prior period, unchanged from 0001783180-23-000056:notes:127]

[0001783180-23-000065:notes:131]
[same as prior period, unchanged from 0001783180-23-000056:notes:128]

[0001783180-23-000065:notes:132]
|  |  | Net Sales |  | Operating Profit |
|  |  | Three Months Ended September 30, |  | Three Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC |  | $ | 4,008 |  |  | $ | 3,734 |  |  | $ | 763 |  |  | $ | 1,314 |  |
| Refrigeration |  | 924 |  |  | 923 |  |  | 107 |  |  | 116 |  |
| Fire & Security |  | 923 |  |  | 905 |  |  | 164 |  |  | 142 |  |
| Total segment |  | 5,855 |  |  | 5,562 |  |  | 1,034 |  |  | 1,572 |  |
| Eliminations and other |  | (124) |  |  | (111) |  |  | (298) |  |  | (10) |  |
| General corporate expenses |  | — |  |  | — |  |  | (91) |  |  | (36) |  |
| Total Consolidated |  | $ | 5,731 |  |  | $ | 5,451 |  |  | $ | 645 |  |  | $ | 1,526 |  |

[0001783180-23-000065:notes:133]
|  |  | Net Sales |  | Operating Profit |
|  |  | Nine Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC |  | $ | 11,846 |  |  | $ | 10,092 |  |  | $ | 1,940 |  |  | $ | 2,369 |  |
| Refrigeration |  | 2,794 |  |  | 2,940 |  |  | 327 |  |  | 370 |  |
| Fire & Security |  | 2,724 |  |  | 2,610 |  |  | 100 |  |  | 1,494 |  |
| Total segment |  | 17,364 |  |  | 15,642 |  |  | 2,367 |  |  | 4,233 |  |
| Eliminations and other |  | (368) |  |  | (326) |  |  | (482) |  |  | (50) |  |
| General corporate expenses |  | — |  |  | — |  |  | (196) |  |  | (101) |  |
| Total Consolidated |  | $ | 16,996 |  |  | $ | 15,316 |  |  | $ | 1,689 |  |  | $ | 4,082 |  |

[0001783180-23-000065:notes:134]
Geographic external sales are attributed to the geographic regions based on their location of origin. With the exception of the U.S. presented in the table below, there were no individually significant countries with sales exceeding 10% of total sales during the nine months ended September 30, 2023 and 2022.

[0001783180-23-000065:notes:135]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| United States |  | $ | 3,335 |  |  | $ | 3,154 |  |  | $ | 9,584 |  |  | $ | 9,109 |  |
| International: |  |  |  |  |  |  |  |  |
| Europe |  | 1,124 |  |  | 1,024 |  |  | 3,525 |  |  | 3,188 |  |
| Asia Pacific |  | 1,061 |  |  | 1,071 |  |  | 3,288 |  |  | 2,436 |  |
| Other |  | 211 |  |  | 202 |  |  | 599 |  |  | 583 |  |
| Net sales |  | $ | 5,731 |  |  | $ | 5,451 |  |  | $ | 16,996 |  |  | $ | 15,316 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-23-000065:notes:136]
RELATED PARTIES
Equity Method Investments

[0001783180-23-000065:notes:137]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered to be related parties. Amounts attributable to equity method investees are as follows:

[0001783180-23-000065:notes:138]
|  |  | Three Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Sales to equity method investees included in Product sales |  | $ | 730 |  |  | $ | 718 |  |  | $ | 2,371 |  |  | $ | 2,129 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 57 |  |  | $ | 60 |  |  | $ | 159 |  |  | $ | 261 |  |

[0001783180-23-000065:notes:139]
The Company had receivables from and payables to equity method investees as follows:

[0001783180-23-000065:notes:140]
| (In millions) |  | September 30,2023 |  | December 31,2022 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 289 |  |  | $ | 154 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 35 |  |  | $ | 44 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-23-000065:notes:141]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies, the Company records accruals for loss contingencies when it is probable that a liability has been incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon its results of operations, cash flows or financial condition.

[0001783180-23-000065:notes:142]
Environmental Matters

[0001783180-23-000065:notes:143]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees. The most likely cost to be incurred is accrued based on an evaluation of currently available facts with respect to individual sites, including the technology required to remediate, current laws and regulations and prior remediation experience.

[0001783180-23-000065:notes:144]
The outstanding liabilities for environmental obligations are as follows:

[0001783180-23-000065:notes:145]
| (In millions) |  | September 30,2023 |  | December 31,2022 |
| Environmental reserves included in Accrued liabilities |  | $ | 12 |  |  | $ | 24 |  |
| Environmental reserves included in Other long-term liabilities |  | 208 |  |  | 211 |  |
| Total Environmental reserves |  | $ | 220 |  |  | $ | 235 |  |

[0001783180-23-000065:notes:146]
For sites with multiple responsible parties, the Company considers its likely proportionate share of the anticipated remediation costs and the ability of other parties to fulfill their obligations in establishing a provision for these costs. Accrued environmental liabilities are not reduced by potential insurance reimbursements and are undiscounted.

[0001783180-23-000065:notes:147]
Asbestos Matters

[0001783180-23-000065:notes:148]
The Company has been named as a defendant in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-23-000065:notes:149]
The Company's asbestos liabilities and related insurance recoveries are as follows:

[0001783180-23-000065:notes:150]
| (In millions) |  | September 30,2023 |  | December 31,2022 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 16 |  |  | $ | 16 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 207 |  |  | 212 |  |
| Total Asbestos liabilities |  | $ | 223 |  |  | $ | 228 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 5 |  |  | $ | 5 |  |
| Asbestos-related recoveries included in Other assets |  | 89 |  |  | 90 |  |
| Total Asbestos-related recoveries |  | $ | 94 |  |  | $ | 95 |  |

[0001783180-23-000065:notes:151]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded insurance recovery receivables for probable asbestos-related recoveries.

[0001783180-23-000065:notes:152]
UTC Equity Awards Conversion Litigation

[0001783180-23-000065:notes:153]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis Worldwide Corporation ("Otis"), the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenged the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. Defendants moved to dismiss the Complaint. Plaintiffs amended their Complaint on September 13, 2021 (the "Amended Complaint"). The Amended Complaint, with Raytheon Technologies Corporation, Carrier and Otis as the only defendants, asserted that the defendants are liable for breach of certain equity compensation plans and for breach of the implied covenant of good faith and fair dealing. The Amended Complaint also sought specific performance. The Company believes all plaintiffs' claims against it are without merit. Defendants moved to dismiss the Amended Complaint. On September 30, 2022, the court dismissed the case against all defendants, with prejudice. Plaintiffs appealed the dismissal to the United States Court of Appeals for the Second Circuit. On August 3, 2023, the Second Circuit Court of Appeals affirmed the district court’s ruling.

[0001783180-23-000065:notes:154]
Aqueous Film Forming Foam Litigation

[0001783180-23-000065:notes:155]
As of September 30, 2023, the Company, KFI and others have been named as defendants in more than 5,000 lawsuits filed by individuals in or removed to the federal courts of the United States alleging that the historic use of Aqueous Film Forming Foam ("AFFF") caused personal injuries and/or property damage. The Company, KFI and others have also been named as defendants in more than 600 lawsuits filed by several U.S. states, municipalities and water utilities in or removed to U.S. federal courts alleging that the historic use of AFFF caused contamination of property and water supplies. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation transferred and consolidated all AFFF cases pending in the U.S. federal courts against the Company, KFI and others to the U.S. District Court for the District of South Carolina (the "MDL Proceedings"). The individual plaintiffs in the MDL Proceedings generally seek damages for alleged personal injuries, medical monitoring, diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S. state, municipal and water utility plaintiffs in the MDL Proceedings generally seek damages and costs related to the remediation of public property and water supplies.

[0001783180-23-000065:notes:156]
AFFF is a firefighting foam, developed beginning in the late 1960s pursuant to U.S. military specification, used to extinguish certain types of hydrocarbon-fueled fires. The lawsuits identified above relate to Kidde Fire Fighting, Inc., which owned the National Foam business. Kidde Fire Fighting, Inc. was acquired by a UTC subsidiary in 2005 and merged into KFI in 2007. The National Foam business manufactured AFFF for sale to government (including the U.S. federal government) and non-government customers in the U.S. at a single facility located in West Chester, Pennsylvania (the "Pennsylvania Site"). In 2013, KFI divested the AFFF businesses to an unrelated third party. The Company acquired KFI as part of the Separation in April 2020.

[0001783180-23-000065:notes:157]
The key components that contribute to AFFF's fire-extinguishing capabilities are known as fluorosurfactants. Neither the Company, nor KFI, nor any of the Company's subsidiaries involved in the AFFF litigation manufactured fluorosurfactants. Instead, the National Foam business purchased these substances from unrelated third parties for use in manufacturing AFFF. Plaintiffs in the MDL Proceedings allege that the fluorosurfactants used by various manufacturers in producing AFFF contained, or over time degraded into, compounds known as per- and polyfluoroalkyl substances (referred to collectively as "PFAS"), including perflourooctanesulfonic acid ("PFOS") and perflourooctanoic acid ("PFOA"). Plaintiffs further allege that, as a result of the use of AFFF, PFOS and PFOA were released into the environment and, in some instances, ultimately reached drinking water supplies.

[0001783180-23-000065:notes:158]
Plaintiffs in the MDL Proceedings allege that PFOS and PFOA contamination has resulted from the use of AFFF manufactured using a process known as ECF, and that this process was used exclusively by 3M. They also allege that PFOA contamination has resulted from the use of AFFF manufactured using a different process, known as telomerization, and that this process was used exclusively by the other AFFF manufacturers (including the National Foam business). Compounds containing PFOS and PFOA (as well as many other PFAS) have also been used for decades by many third parties in a number of different industries to manufacture firefighters’ protective outerwear, carpets, clothing, fabrics, cookware, food packaging, personal care products, cleaning products, paints, varnishes and other consumer and industrial products.

[0001783180-23-000065:notes:159]
Plaintiffs in the MDL Proceedings have named multiple defendants, including suppliers of chemicals and raw materials used to manufacture fluorosurfactants, fluorosurfactant manufacturers and AFFF manufacturers. The defendants in the MDL Proceedings moved for summary judgment on the government contractor defense, which potentially applies to AFFF sold to or used by the U.S. government. After full briefing and oral argument, on September 16, 2022, the MDL court declined to enter summary judgment for the defendants. The defense, however, remains available at any trial to which it applies.

[0001783180-23-000065:notes:160]
On September 23, 2022, after completion of discovery, the MDL court selected one water provider case, the City of Stuart, FL v. 3M, et al., for a bellwether trial. That trial was scheduled to begin in early June 2023 but was postponed indefinitely. The MDL court ordered that the bellwether process for personal injury cases will begin in 2023. The court has not yet outlined details on that process or its timing.

[0001783180-23-000065:notes:161]
Outside of the MDL Proceedings, the Company and other defendants also are party to six lawsuits in U.S. state courts brought by oil refining companies alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage. In addition, the Company and other defendants are party to two actions related to the Pennsylvania Site in which the plaintiff water utility company seeks remediation costs related to the alleged contamination of the local water supply. The Company, KFI and other defendants are also party to one action in Arizona state court brought by a firefighter claiming that occupational exposure to AFFF has caused certain personal injuries.

[0001783180-23-000065:notes:162]
The Company and KFI believe that they have meritorious defenses to the claims in the MDL Proceedings and the other AFFF lawsuits. Given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or to reasonably estimate a range of possible loss at this time. There can be no assurance that any such future exposure will not be material in any period.

[0001783180-23-000065:notes:163]
On May 14, 2023, KFI filed a voluntary petition with the United States Bankruptcy Court for the District of Delaware seeking relief under Chapter 11 of the Bankruptcy Code after the Company determined that it would not provide financial support to KFI going forward, other than ensuring KFI has access to services necessary for the effective operation of its business. As a result, all litigation against KFI is automatically stayed. KFI filed an adversary complaint and motion in the Chapter 11 case seeking an order staying or enjoining all AFFF-related litigation against the Company, its other subsidiaries and RTX. That motion was resolved through an agreement that effectively stays the AFFF litigation against these parties. KFI has also indicated to the bankruptcy court that it intends to pursue insurance coverage for AFFF-related liabilities and contractual indemnification for AFFF-related liabilities from the third party to which KFI sold National Foam.

[0001783180-23-000065:notes:164]
Deconsolidation Due to Bankruptcy

[0001783180-23-000065:notes:165]
As of May 14, 2023, the Company no longer controlled KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from the Company’s Unaudited Condensed Consolidated Financial Statements. Upon deconsolidation, the Company determined the fair value of its retained interest in KFI to be zero and will account for it prospectively using the cost method. As a result of these actions, the Company recognized a loss of $297 million in its Unaudited Condensed Consolidated Statements of Operations

[0001783180-23-000065:notes:166]
within Other income/(expense), net. In addition, the deconsolidation resulted in an investing cash outflow of $134 million in the Company's Unaudited Condensed Consolidated Statements of Cash Flows.

[0001783180-23-000065:notes:167]
In connection with the bankruptcy filing, KFI entered into several agreements with subsidiaries of the Company to ensure they have access to services necessary for the effective operation of their business. All post-deconsolidation activity between the Company and KFI are reported as third-party transactions recorded within the Company's Unaudited Condensed Consolidated Statements of Operations. Since the petition date, there were no material transactions between the Company and KFI.

[0001783180-23-000065:notes:168]
Income Taxes

[0001783180-23-000065:notes:169]
Under the Tax Matters Agreement relating to the Separation, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, liabilities of $75 million and $293 million are included within the accompanying Unaudited Condensed Consolidated Balance Sheet within Accrued Liabilities and Other Long-Term Liabilities as of September 30, 2023, respectively. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $75 million due in 2024. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

[0001783180-23-000065:notes:170]
Other

[0001783180-23-000065:notes:171]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-23-000065:notes:172]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its results of operations, cash flows or financial condition.
