# CARR MD&A — 0001783180-23-000065


## mdna

[0001783180-23-000065:mdna:1]
[same as prior period, unchanged from 0001783180-23-000056:mdna:1]

[0001783180-23-000065:mdna:2]
[same as prior period, unchanged from 0001783180-23-000056:mdna:2]

[0001783180-23-000065:mdna:3]
[same as prior period, unchanged from 0001783180-23-000056:mdna:3]

[0001783180-23-000065:mdna:4]
[same as prior period, unchanged from 0001783180-23-000056:mdna:4]

[0001783180-23-000065:mdna:5]
[same as prior period, unchanged from 0001783180-23-000056:mdna:5]

[0001783180-23-000065:mdna:6]
[same as prior period, unchanged from 0001783180-23-000056:mdna:6]

[0001783180-23-000065:mdna:7]
[same as prior period, unchanged from 0001783180-23-000056:mdna:7]

[0001783180-23-000065:mdna:8]
[same as prior period, unchanged from 0001783180-23-000056:mdna:8]

[0001783180-23-000065:mdna:9]
[same as prior period, unchanged from 0001783180-23-000056:mdna:9]

[0001783180-23-000065:mdna:10]
[same as prior period, unchanged from 0001783180-23-000056:mdna:10]

[0001783180-23-000065:mdna:11]
[same as prior period, unchanged from 0001783180-23-000056:mdna:11]

[0001783180-23-000065:mdna:12]
[same as prior period, unchanged from 0001783180-23-000056:mdna:12]

[0001783180-23-000065:mdna:13]
[same as prior period, unchanged from 0001783180-23-000056:mdna:13]

[0001783180-23-000065:mdna:14]
On May 14, 2023, Kidde-Fenwal, Inc. ("KFI"), an indirect wholly-owned subsidiary of ours, filed a petition for voluntary reorganization under Chapter 11 of the United States Bankruptcy Code ("Chapter 11") in the United States Bankruptcy Court for the District of Delaware. KFI, an industrial fire detection and suppression business historically reported in our Fire & Security segment, has indicated that it intends to use the bankruptcy process to explore strategic alternatives, including the sale of KFI as a going concern. KFI has further stated that, during the Chapter 11 process, KFI expects that there will be no significant interruptions to its business operations. As of the petition date, KFI was deconsolidated and its respective assets and liabilities were derecognized from our Unaudited Condensed Consolidated Financial Statements.

[0001783180-23-000065:mdna:15]
[same as prior period, unchanged from 0001783180-23-000056:mdna:15]

[0001783180-23-000065:mdna:16]
[same as prior period, unchanged from 0001783180-23-000056:mdna:16]

[0001783180-23-000065:mdna:17]
[same as prior period, unchanged from 0001783180-23-000056:mdna:17]

[0001783180-23-000065:mdna:18]
[same as prior period, unchanged from 0001783180-23-000056:mdna:18]

[0001783180-23-000065:mdna:19]
[same as prior period, unchanged from 0001783180-23-000056:mdna:19]

[0001783180-23-000065:mdna:20]
[same as prior period, unchanged from 0001783180-23-000056:mdna:20]

[0001783180-23-000065:mdna:21]
[same as prior period, unchanged from 0001783180-23-000056:mdna:21]

[0001783180-23-000065:mdna:22]
[same as prior period, unchanged from 0001783180-23-000056:mdna:22]

[0001783180-23-000065:mdna:23]
Three Months Ended September 30, 2023 Compared with the Three Months Ended September 30, 2022

[0001783180-23-000065:mdna:24]
[same as prior period, unchanged from 0001783180-23-000056:mdna:24]

[0001783180-23-000065:mdna:25]
|  |  | Three Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |  | Period Change |  | % Change |
| Net sales |  | $ | 5,731 |  |  | $ | 5,451 |  |  | $ | 280 |  |  | 5 | % |
| Cost of products and services sold |  | (3,915) |  |  | (3,974) |  |  | 59 |  |  | (1) | % |
| Gross margin |  | 1,816 |  |  | 1,477 |  |  | 339 |  |  | 23 | % |
| Operating expenses |  | (1,171) |  |  | 49 |  |  | (1,220) |  |  | (2,490) | % |
| Operating profit |  | 645 |  |  | 1,526 |  |  | (881) |  |  | (58) | % |
| Non-operating income (expense), net |  | (51) |  |  | (56) |  |  | 5 |  |  | (9) | % |
| Income from operations before income taxes |  | 594 |  |  | 1,470 |  |  | (876) |  |  | (60) | % |
| Income tax expense |  | (213) |  |  | (138) |  |  | (75) |  |  | 54 | % |
| Net income from operations |  | 381 |  |  | 1,332 |  |  | (951) |  |  | (71) | % |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 24 |  |  | 20 |  |  | 4 |  |  | 20 | % |
| Net income attributable to common shareowners |  | $ | 357 |  |  | $ | 1,312 |  |  | $ | (955) |  |  | (73) | % |

[0001783180-23-000065:mdna:26]
[same as prior period, unchanged from 0001783180-23-000056:mdna:26]

[0001783180-23-000065:mdna:27]
For the three months ended September 30, 2023, Net sales were $5.7 billion, a 5% increase compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000065:mdna:28]
|  |  | Three Months Ended September 30, 2023 |
| Organic |  | 3 | % |
| Foreign currency translation |  | 1 | % |
| Acquisitions and divestitures, net |  | 1 | % |
| Total % change |  | 5 | % |

[0001783180-23-000065:mdna:29]
Organic sales for the three months ended September 30, 2023 increased by 3% compared with the same period of 2022. The organic increase was driven by our HVAC segment due to improved global end-markets in our Commercial HVAC business and pricing improvements in our North America residential and light commercial business. In addition, our Fire & Security segment benefited from price improvements and volume growth in the Americas as well as strong demand in global industrial markets. Refrigeration results decreased due to volume reductions in commercial refrigeration and container end-markets. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-23-000065:mdna:30]
On August 1, 2022, we acquired a majority ownership interest in TCC, a VRF and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The results of TCC have been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 2% to Net sales during the three months ended September 30, 2023 and is included in Acquisitions and divestitures, net.

[0001783180-23-000065:mdna:31]
As of May 14, 2023, we no longer controlled KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from our Unaudited Condensed Consolidated Financial Statements. The deconsolidation had a 1% impact on Net sales during the three months ended September 30, 2023 and is included in Acquisitions and divestitures, net.

[0001783180-23-000065:mdna:32]
[same as prior period, unchanged from 0001783180-23-000056:mdna:32]

[0001783180-23-000065:mdna:33]
For the three months ended September 30, 2023, gross margin was $1.8 billion, a 23% increase compared with the same period of 2022. The components were as follows:

[0001783180-23-000065:mdna:34]
|  |  | Three Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |
| Net sales |  | $ | 5,731 |  |  | $ | 5,451 |  |
| Cost of products and services sold |  | (3,915) |  |  | (3,974) |  |
| Gross margin |  | $ | 1,816 |  |  | $ | 1,477 |  |
| Percentage of net sales |  | 31.7 | % |  | 27.1 | % |

[0001783180-23-000065:mdna:35]
Gross margin increased by $339 million compared with the three months ended September 30, 2022. The main driver of the increase related to ongoing customer demand, pricing improvements and our continued focus on productivity initiatives. In addition, operating results associated with TCC since the date of acquisition further benefited gross margin during the period. These amounts were partially offset by the higher cost of commodities and components used in our products. Although inflationary cost pressures have begun to moderate, they remain elevated and continue to impact the cost of products and services sold in each of our segments. Gross margin as a percentage of Net sales increased by 460 basis points compared with the same period of 2022.

[0001783180-23-000065:mdna:36]
[same as prior period, unchanged from 0001783180-23-000056:mdna:36]

[0001783180-23-000065:mdna:37]
For the three months ended September 30, 2023, operating expenses, including Equity method investment net earnings, were $1.2 billion, a 2,490% decrease compared with the same period of 2022. The components were as follows:

[0001783180-23-000065:mdna:38]
|  |  | Three Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |
| Selling, general and administrative |  | $ | (831) |  |  | $ | (624) |  |
| Research and development |  | (157) |  |  | (143) |  |
| Equity method investment net earnings |  | 75 |  |  | 63 |  |
| Other income (expense), net |  | (258) |  |  | 753 |  |
| Total operating expenses |  | $ | (1,171) |  |  | $ | 49 |  |
| Percentage of net sales |  | 20.4 | % |  | (0.9) | % |

[0001783180-23-000065:mdna:39]
For the three months ended September 30, 2023, Selling, general and administrative expenses were $831 million, a 33% increase compared with the same period of 2022. The increase is primarily due to higher compensation, commissions and other employee-related costs in the current period. In addition, incremental selling, general and administrative expenses associated with TCC since the date of acquisition further contributed to the increase. The current period also included $62 million of acquisition and divestiture-related costs compared with $15 million during the three months ended September 30, 2022.

[0001783180-23-000065:mdna:40]
[same as prior period, unchanged from 0001783180-23-000056:mdna:40]

[0001783180-23-000065:mdna:41]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the three months ended September 30, 2023, Equity method investment net earnings were $75 million, a 19% increase compared with the same period of 2022. The increase was primarily driven by a $16 million benefit recognized in connection with a favorable tax ruling at a minority owned joint venture. The amount was partially offset by an increase in our ownership interest in TCC on August 1, 2022. As a result, TCC is no longer accounted for under the equity method of accounting since the date of acquisition. During the three months ended September 30, 2022, pre-acquisition equity earnings of TCC totaled $20 million.

[0001783180-23-000065:mdna:42]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. In connection with the proposed acquisition of the VCS Business, we recognized a $257 million loss during the three months ended September 30, 2023 on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price for the VCS Business.

[0001783180-23-000065:mdna:43]
In connection with the TCC acquisition, the carrying value of our previously held TCC equity investments were recognized at fair value at the date of acquisition. As a result, we recognized a $732 million non-cash gain associated with the increase in our ownership interest during the three months ended September 30, 2022. In addition, we recognized a $7 million charge resulting from the settlement of working capital and other transaction-related items associated with the Chubb Sale.

[0001783180-23-000065:mdna:44]
[same as prior period, unchanged from 0001783180-23-000056:mdna:43]

[0001783180-23-000065:mdna:45]
For the three months ended September 30, 2023, Non-operating income (expense), net was $51 million, a 9% decrease compared with the same period of 2022. The components were as follows:

[0001783180-23-000065:mdna:46]
|  |  | Three Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |
| Non-service pension (expense) benefit |  | $ | — |  |  | $ | — |  |
| Interest expense |  | $ | (86) |  |  | $ | (71) |  |
| Interest income |  | 35 |  |  | 15 |  |
| Interest (expense) income, net |  | $ | (51) |  |  | $ | (56) |  |
| Non-operating income (expense), net |  | $ | (51) |  |  | $ | (56) |  |

[0001783180-23-000065:mdna:47]
Non-operating income (expense), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the three months ended September 30, 2023, Interest expense was $86 million, a 21% increase compared with the same period of 2022. In connection with the proposed acquisition of the VCS Business, we entered into several financing arrangements and capitalized $54 million of deferred financing costs. During the three months ended September 30, 2023, we amortized $12 million of deferred financing costs in Interest expense, of which $11 million related to our senior unsecured bridge term loan facility ("the Bridge Loan").

[0001783180-23-000065:mdna:48]
[same as prior period, unchanged from 0001783180-23-000056:mdna:47]

[0001783180-23-000065:mdna:49]
|  |  | Three Months Ended September 30, |
|  |  | 2023 |  | 2022 |
| Effective tax rate |  | 35.9 | % |  | 9.4 | % |

[0001783180-23-000065:mdna:50]
We account for income tax expense in accordance with ASC 740, which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 35.9% for the three months ended September 30, 2023 compared with 9.4% for the three months ended September 30, 2022. The year-over-year increase was primarily driven by the non-deductible loss of $257 million on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business and a tax charge of $33 million related to our intention to no longer permanently reinvest historical earnings from certain jurisdictions. In addition, the three months ended September 30, 2022 included a lower effective tax rate on a $732 million non-cash gain resulting from the recognition of our previously held TCC equity investments at fair value upon acquisition of TCC compared to our U.S. statutory tax rate.

[0001783180-23-000065:mdna:51]
35

[0001783180-23-000065:mdna:52]
Nine Months Ended September 30, 2023 Compared with the Nine Months Ended September 30, 2022

[0001783180-23-000065:mdna:53]
[same as prior period, unchanged from 0001783180-23-000056:mdna:52]

[0001783180-23-000065:mdna:54]
|  |  | Nine Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |  | Period Change |  | % Change |
| Net sales |  | $ | 16,996 |  |  | $ | 15,316 |  |  | $ | 1,680 |  |  | 11 | % |
| Cost of products and services sold |  | (12,047) |  |  | (11,099) |  |  | (948) |  |  | 9 | % |
| Gross margin |  | 4,949 |  |  | 4,217 |  |  | 732 |  |  | 17 | % |
| Operating expenses |  | (3,260) |  |  | (135) |  |  | (3,125) |  |  | 2,315 | % |
| Operating profit |  | 1,689 |  |  | 4,082 |  |  | (2,393) |  |  | (59) | % |
| Non-operating income (expense), net |  | (164) |  |  | (167) |  |  | 3 |  |  | (2) | % |
| Income from operations before income taxes |  | 1,525 |  |  | 3,915 |  |  | (2,390) |  |  | (61) | % |
| Income tax expense |  | (524) |  |  | (609) |  |  | 85 |  |  | (14) | % |
| Net income from operations |  | 1,001 |  |  | 3,306 |  |  | (2,305) |  |  | (70) | % |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 72 |  |  | 42 |  |  | 30 |  |  | 71 | % |
| Net income attributable to common shareowners |  | $ | 929 |  |  | $ | 3,264 |  |  | $ | (2,335) |  |  | (72) | % |

[0001783180-23-000065:mdna:55]
[same as prior period, unchanged from 0001783180-23-000056:mdna:54]

[0001783180-23-000065:mdna:56]
For the nine months ended September 30, 2023, Net sales were $17.0 billion, a 11% increase compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000065:mdna:57]
|  |  | Nine Months Ended September 30, 2023 |
| Organic |  | 4 | % |
| Foreign currency translation |  | (1) | % |
| Acquisitions and divestitures, net |  | 8 | % |
| Total % change |  | 11 | % |

[0001783180-23-000065:mdna:58]
Organic sales for the nine months ended September 30, 2023 increased by 4% compared with the same period of 2022. The organic increase was primarily driven by our HVAC segment due to improved global end-markets in our Commercial HVAC business and pricing improvements in our North America residential and light commercial business. In addition, our Fire & Security segment benefited from price improvements and volume growth in each region. Refrigeration results decreased due to volume reductions in commercial refrigeration and container end-markets. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-23-000065:mdna:59]
On August 1, 2022, we acquired a majority ownership interest in TCC, a VRF and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The results of TCC have been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 9% to Net sales during the nine months ended September 30, 2023 and is included in Acquisitions and divestitures, net.

[0001783180-23-000065:mdna:60]
As of May 14, 2023, we no longer controlled KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from our Unaudited Condensed Consolidated Financial Statements. The deconsolidation had a 1% impact on Net sales during the nine months ended September 30, 2023 and is included in Acquisitions and divestitures, net.

[0001783180-23-000065:mdna:61]
[same as prior period, unchanged from 0001783180-23-000056:mdna:79]

[0001783180-23-000065:mdna:62]
[same as prior period, unchanged from 0001783180-23-000056:mdna:61]

[0001783180-23-000065:mdna:63]
For the nine months ended September 30, 2023, gross margin was $4.9 billion, a 17% increase compared with the same period of 2022. The components were as follows:

[0001783180-23-000065:mdna:64]
|  |  | Nine Months Ended September 30, |  |  |  |  |
| (In millions) |  | 2023 |  | 2022 |  |  |  |  |
| Net sales |  | $ | 16,996 |  |  | $ | 15,316 |  |  |  |  |  |
| Cost of products and services sold |  | (12,047) |  |  | (11,099) |  |  |  |  |  |
| Gross margin |  | $ | 4,949 |  |  | $ | 4,217 |  |  |  |  |  |
| Percentage of net sales |  | 29.1 | % |  | 27.5 | % |  |  |  |  |

[0001783180-23-000065:mdna:65]
Gross margin increased by $732 million compared with the nine months ended September 30, 2022. The main driver of the increase related to ongoing customer demand, pricing improvements and our continued focus on productivity initiatives. In addition, operating results associated with TCC since the date of acquisition further benefited gross margin during the period. These amounts were partially offset by the higher cost of commodities and components used in our products and certain supply chain constraints. Although inflationary cost pressures have begun to moderate, they remain elevated and continue to impact the cost of products and services sold in each of our segments. Gross margin as a percentage of Net sales increased 160 basis points compared with the same period of 2022.

[0001783180-23-000065:mdna:66]
[same as prior period, unchanged from 0001783180-23-000056:mdna:65]

[0001783180-23-000065:mdna:67]
For the nine months ended September 30, 2023, operating expenses, including Equity method investment net earnings, were $3.3 billion, a 2,315% increase compared with the same period of 2022. The components were as follows:

[0001783180-23-000065:mdna:68]
|  |  | Nine Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |
| Selling, general and administrative |  | $ | (2,336) |  |  | $ | (1,839) |  |
| Research and development |  | (447) |  |  | (390) |  |
| Equity method investment net earnings |  | 171 |  |  | 222 |  |
| Other income (expense), net |  | (648) |  |  | 1,872 |  |
| Total operating expenses |  | $ | (3,260) |  |  | $ | (135) |  |
| Percentage of net sales |  | 19.2 | % |  | 0.9 | % |

[0001783180-23-000065:mdna:69]
For the nine months ended September 30, 2023, Selling, general and administrative expenses were $2.3 billion, a 27% increase compared with the same period of 2022. The increase is primarily due to higher compensation, commissions and other employee-related costs during the current period. In addition, incremental selling, general and administrative expenses associated with TCC since the date of acquisition further contributed to the increase. The current period also included $88 million of acquisition and divestiture-related costs compared with $28 million during the nine months ended September 30, 2022.

[0001783180-23-000065:mdna:70]
[same as prior period, unchanged from 0001783180-23-000056:mdna:69]

[0001783180-23-000065:mdna:71]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the nine months ended September 30, 2023, Equity method investment net earnings were $171 million, a 23% decrease compared with the same period of 2022. The decrease was primarily driven by the increase in our ownership interest in TCC on August 1, 2022. As a result, TCC is no longer accounted for under the equity method of accounting since the date of acquisition. The decrease was partially offset by a $16 million benefit recognized in connection with a favorable tax ruling at a minority owned joint venture. During the nine months ended September 30, 2022, pre-acquisition equity earnings of TCC totaled $87 million which included a $27 million gain on the sale of two minority owned subsidiaries.

[0001783180-23-000065:mdna:72]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of businesses or interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. In connection with the proposed acquisition of the VCS Business, we recognized a $368 million loss during the nine months ended September 30, 2023 on the mark-to-market valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price. In addition, we recognized a loss of $297 million on the deconsolidation of KFI due to its Chapter 11 filing.

[0001783180-23-000065:mdna:73]
In connection with the TCC acquisition, the carrying value of our previously held TCC equity investments were recognized at fair value at the date of acquisition. As a result, we recognized a $732 million non-cash gain associated with the increase in our ownership interest during the nine months ended September 30, 2022. In addition, we completed the Chubb Sale and recognized a net gain on the sale of $1.1 billion. Prior period results also included a $22 million charge resulting from a litigation matter and a $7 million gain on the sale of our interest in a cost method investment reported within our Refrigeration segment.

[0001783180-23-000065:mdna:74]
[same as prior period, unchanged from 0001783180-23-000056:mdna:72]

[0001783180-23-000065:mdna:75]
For the nine months ended September 30, 2023, Non-operating income (expense), net was $164 million, a 2% decrease compared with the same period of 2022. The components were as follows:

[0001783180-23-000065:mdna:76]
|  |  | Nine Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |
| Non-service pension (expense) benefit |  | $ | — |  |  | $ | (2) |  |
| Interest expense |  | $ | (251) |  |  | $ | (226) |  |
| Interest income |  | 87 |  |  | 61 |  |
| Interest (expense) income, net |  | $ | (164) |  |  | $ | (165) |  |
| Non-operating income (expense), net |  | $ | (164) |  |  | $ | (167) |  |

[0001783180-23-000065:mdna:77]
Non-operating income (expense), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the nine months ended September 30, 2023, Interest expense was $251 million, a 11% increase compared with the same period of 2022. In connection with the proposed acquisition of the VCS Business, we entered into several financing arrangements and capitalized $54 million of deferred financing costs. During the nine months ended September 30, 2023, we amortized $34 million of deferred financing costs in Interest expense, of which $30 million related to our Bridge Loan. During the nine months ended September 30, 2022, we completed tender offers to repurchase approximately $1.15 billion aggregate principal of our 2.242% Notes due 2025 and 2.493% Notes due 2027. Upon settlement, we wrote off $5 million of unamortized deferred financing costs in Interest expense and recognized a net gain of $33 million in Interest income.

[0001783180-23-000065:mdna:78]
[same as prior period, unchanged from 0001783180-23-000056:mdna:76]

[0001783180-23-000065:mdna:79]
|  |  | Nine Months Ended September 30, |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| Effective tax rate |  | 34.4 | % |  | 15.6 | % |  |  |  |  |

[0001783180-23-000065:mdna:80]
We account for income tax expense in accordance with ASC 740, which requires an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate was 34.4% for the nine months ended September 30, 2023 compared with 15.6% for the nine months ended September 30, 2022. The year-over-year increase was primarily driven by the non-deductible loss of $297 million on the deconsolidation of KFI due to its Chapter 11 filing and the $368 million loss on the mark-to-market

[0001783180-23-000065:mdna:81]
valuation of our window forward contracts associated with the expected cash outflows of the Euro-denominated purchase price of the VCS Business. In addition, the nine months ended September 30, 2022 included a lower effective tax rate on a $732 million non-cash gain resulting from the recognition of our previously held TCC equity investments at fair value upon acquisition of TCC and the $1.1 billion Chubb gain compared with our U.S. statutory rate and a favorable tax adjustment of $32 million associated with foreign tax credits generated and utilized in the prior year.

[0001783180-23-000065:mdna:82]
39

[0001783180-23-000065:mdna:83]
[same as prior period, unchanged from 0001783180-23-000056:mdna:80]

[0001783180-23-000065:mdna:84]
[same as prior period, unchanged from 0001783180-23-000056:mdna:81]

[0001783180-23-000065:mdna:85]
[same as prior period, unchanged from 0001783180-23-000056:mdna:82]

[0001783180-23-000065:mdna:86]
[same as prior period, unchanged from 0001783180-23-000056:mdna:83]

[0001783180-23-000065:mdna:87]
[same as prior period, unchanged from 0001783180-23-000056:mdna:84]

[0001783180-23-000065:mdna:88]
[same as prior period, unchanged from 0001783180-23-000056:mdna:85]

[0001783180-23-000065:mdna:89]
Three Months Ended September 30, 2023 Compared with Three Months Ended September 30, 2022

[0001783180-23-000065:mdna:90]
[same as prior period, unchanged from 0001783180-23-000056:mdna:87]

[0001783180-23-000065:mdna:91]
|  |  | Net Sales |  | Operating Profit |  | Operating Profit Margin |
|  |  | Three Months Ended September 30, |  | Three Months Ended September 30, |  | Three Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC |  | $ | 4,008 |  |  | $ | 3,734 |  |  | $ | 763 |  |  | $ | 1,314 |  |  | 19.0 | % |  | 35.2 | % |
| Refrigeration |  | 924 |  |  | 923 |  |  | 107 |  |  | 116 |  |  | 11.6 | % |  | 12.6 | % |
| Fire & Security |  | 923 |  |  | 905 |  |  | 164 |  |  | 142 |  |  | 17.8 | % |  | 15.7 | % |
| Total segment |  | $ | 5,855 |  |  | $ | 5,562 |  |  | $ | 1,034 |  |  | $ | 1,572 |  |  | 17.7 | % |  | 28.3 | % |

[0001783180-23-000065:mdna:92]
[same as prior period, unchanged from 0001783180-23-000056:mdna:89]

[0001783180-23-000065:mdna:93]
For the three months ended September 30, 2023, Net sales in our HVAC segment were $4.0 billion, a 7% increase compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000065:mdna:94]
|  |  | Net Sales |
| Organic |  | 4 | % |
| Foreign currency translation |  | — | % |
| Acquisitions and divestitures, net |  | 3 | % |
| Total % change in Net sales |  | 7 | % |

[0001783180-23-000065:mdna:95]
The organic increase in Net sales of 4% was driven by continued strong results in the segment. Increased sales in our Commercial HVAC business (up 9%) benefited from pricing improvements and ongoing customer demand in our end-markets. The business saw strong growth in North America and volume improvements in Europe. Asia results were impacted by reduced end-market demand in China. Higher sales in our North America residential and light commercial business (up 5%) were primarily driven by pricing improvements and improved mix associated with regulatory changes effective as of the beginning of 2023. These amounts were partially offset by volume reductions in North America residential end-markets. Results in our Global Comfort Solutions business (down 7%) were primarily driven by lower demand in certain European end-markets.

[0001783180-23-000065:mdna:96]
On August 1, 2022, we acquired a majority ownership interest in TCC, a VRF and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The results of TCC have been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 3% to Net sales during the three months ended September 30, 2023 and is included in Acquisitions and divestitures, net.

[0001783180-23-000065:mdna:97]
[same as prior period, unchanged from 0001783180-23-000056:mdna:122]

[0001783180-23-000065:mdna:98]
For the three months ended September 30, 2023, Operating profit in our HVAC segment was $763 million, a 42% decrease compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000065:mdna:99]
|  |  | Operating Profit |
| Operational |  | 12 | % |
| Acquisitions and divestitures, net |  | 1 | % |
| Restructuring |  | (2) | % |
| Other |  | (53) | % |
| Total % change in Operating profit |  | (42) | % |

[0001783180-23-000065:mdna:100]
The operational profit increase of 12% was primarily attributable to pricing improvements and ongoing customer demand in certain end-markets compared with the prior year. These benefits more than offset the higher costs for commodities and components used in our products. Higher earnings from equity method investments further benefited operational profit and included a $16 million benefit recognized in connection with a favorable tax ruling at a minority owned joint venture. These amounts were partially offset by the increase in our ownership interest in TCC on August 1, 2022. As a result, TCC is no longer accounted for under the equity method of accounting since the date of acquisition. Inflationary cost pressures have begun to moderate, but continue to impact our operating profit.

[0001783180-23-000065:mdna:101]
Acquisitions and divestitures, net primarily related to the results of operations associated with the acquisition of TCC. The transaction added 1% to Operating profit during the three months ended September 30, 2022. In connection with the TCC acquisition, the carrying value of our previously held TCC equity investments were recognized at fair value at the date of acquisition. As a result, we recognized a $732 million non-cash gain associated with the increase in our ownership interest in Other.

[0001783180-23-000065:mdna:102]
[same as prior period, unchanged from 0001783180-23-000056:mdna:97]

[0001783180-23-000065:mdna:103]
For the three months ended September 30, 2023, Net sales in our Refrigeration segment were $924 million, flat compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000065:mdna:104]
|  |  | Net Sales |
| Organic |  | (3) | % |
| Foreign currency translation |  | 3 | % |
| Acquisitions and divestitures, net |  | — | % |
| Total % change in Net sales |  | — | % |

[0001783180-23-000065:mdna:105]
Organic Net sales decreased 3% compared to the prior year as the segment experienced challenges in certain end-markets during the period. Results for Commercial refrigeration decreased (down 12%) compared with the prior year, primarily driven by lower volumes in Europe as economic conditions and inflationary cost pressures impacted end-market demand. In addition, Asia results were impacted by reduced end-market demand in China. Transport refrigeration results increased (up 1%) compared to the prior year as pricing improvements and strong end-market demand in Europe and Asia were offset by continued weakness in container end-markets.

[0001783180-23-000065:mdna:106]
For the three months ended September 30, 2023, Operating profit in our Refrigeration segment was $107 million, a 8% decrease compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000065:mdna:107]
|  |  | Operating Profit |
| Operational |  | (9) | % |
| Foreign currency translation |  | 3 | % |
| Acquisitions and divestitures, net |  | (1) | % |
| Restructuring |  | (1) | % |
| Total % change in Operating profit |  | (8) | % |

[0001783180-23-000065:mdna:108]
The decrease in operational profit of 9% was primarily driven by volume reductions in certain end-markets compared with the prior year. In addition, the higher costs of commodities and components used in our products further impacted segment results. These amounts were partially offset by pricing improvements and favorable productivity initiatives during the period. Inflationary cost pressures have begun to moderate, but continue to impact our operating profit.

[0001783180-23-000065:mdna:109]
[same as prior period, unchanged from 0001783180-23-000056:mdna:104]

[0001783180-23-000065:mdna:110]
For the three months ended September 30, 2023, Net sales in our Fire & Security segment were $923 million, a 2% increase compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000065:mdna:111]
|  |  | Net Sales |
| Organic |  | 6 | % |
| Foreign currency translation |  | 1 | % |
| KFI deconsolidation |  | (5) | % |
| Total % change in Net sales |  | 2 | % |

[0001783180-23-000065:mdna:112]
The organic increase in Net sales of 6% was primarily driven by pricing improvements and volume growth compared with the prior year. Growth in the Americas was primarily driven by strong commercial markets while residential markets were down compared with the prior year. End-market demand in Europe continued to be be impacted by economic conditions and inflationary cost pressures. Results in Asia normalized after a strong COVID-19 related recovery but were further impacted by reduced end-market demand in China. Global industrial sales benefited segment results due to pricing improvements and strong end-market demand. The segment continues to be impacted by ongoing supply chain constraints for certain components used in our products.

[0001783180-23-000065:mdna:113]
For the three months ended September 30, 2023, Operating profit in our Fire & Security segment was $164 million, a 15% increase compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000065:mdna:114]
|  |  | Operating Profit |
| Operational |  | 17 | % |
| Foreign currency translation |  | 1 | % |
| Restructuring |  | 1 | % |
| KFI deconsolidation |  | (9) | % |
| Chubb gain |  | 5 | % |
| Total % change in Operating profit |  | 15 | % |

[0001783180-23-000065:mdna:115]
The increase in operational profit of 17% was primarily driven by pricing improvements, volume growth and lower freight and logistics costs compared to the prior year. These amounts were partially offset by the higher costs of commodities and components used in our products. In addition, higher inventory-related reserves resulting from supply chain challenges further impacted segment results. Inflationary cost pressures have moderated, but continue to impact our operating profit.

[0001783180-23-000065:mdna:116]
As of May 14, 2023, we no longer control KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from our Unaudited Condensed Consolidated Financial Statements.

[0001783180-23-000065:mdna:117]
42

[0001783180-23-000065:mdna:118]
Nine Months Ended September 30, 2023 Compared with Nine Months Ended September 30, 2022

[0001783180-23-000065:mdna:119]
| Summary performance for each of our segments is as follows: |
|  | Net Sales |  | Operating Profit |  | Operating Profit Margin |
|  | Nine Months Ended September 30, |  | Nine Months Ended September 30, |  | Nine Months Ended September 30, |
| (In millions) | 2023 |  | 2022 |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| HVAC | $ | 11,846 |  |  | $ | 10,092 |  |  | $ | 1,940 |  |  | $ | 2,369 |  |  | 16.4 | % |  | 23.5 | % |
| Refrigeration | 2,794 |  |  | 2,940 |  |  | 327 |  |  | 370 |  |  | 11.7 | % |  | 12.6 | % |
| Fire & Security | 2,724 |  |  | 2,610 |  |  | 100 |  |  | 1,494 |  |  | 3.7 | % |  | 57.2 | % |
| Total segment | $ | 17,364 |  |  | $ | 15,642 |  |  | $ | 2,367 |  |  | $ | 4,233 |  |  | 13.6 | % |  | 27.1 | % |

[0001783180-23-000065:mdna:120]
[same as prior period, unchanged from 0001783180-23-000056:mdna:114]

[0001783180-23-000065:mdna:121]
For the nine months ended September 30, 2023, Net sales in our HVAC segment were $11.8 billion, a 17% increase compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000065:mdna:122]
|  |  | Net Sales |
| Organic |  | 6 | % |
| Foreign currency translation |  | (1) | % |
| Acquisitions and divestitures, net |  | 12 | % |
| Total % change in Net sales |  | 17 | % |

[0001783180-23-000065:mdna:123]
The organic increase in Net sales of 6% was driven by continued strong results in the segment. Increased sales in our Commercial HVAC business (up 14%) benefited from pricing improvements and ongoing customer demand in our end-markets. The business saw strong growth in all regions including Europe and Asia as current economic conditions and inflationary cost pressures improved compared with the prior year. Higher sales in our North America residential and light commercial business (up 3%) were primarily driven by pricing improvements and improved mix associated with regulatory changes effective as of the beginning of 2023. These amounts were partially offset by volume reductions in North America residential end-markets. Results in our Global Comfort Solutions business (down 4%) were primarily driven by lower demand in certain European end-markets.

[0001783180-23-000065:mdna:124]
On August 1, 2022, we acquired a majority ownership interest in TCC, a VRF and light commercial HVAC joint venture between Carrier and Toshiba Corporation. The results of TCC have been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 12% to Net sales during the nine months ended September 30, 2023 and is included in Acquisitions and divestitures, net.

[0001783180-23-000065:mdna:125]
For the nine months ended September 30, 2023, Operating profit in our HVAC segment was $1.9 billion, a 18% decrease compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000065:mdna:126]
|  |  | Operating Profit |
| Operational |  | 8 | % |
| Acquisitions and divestitures, net |  | 6 | % |
| Restructuring |  | (1) | % |
| Amortization of acquired intangibles |  | (3) | % |
| Other |  | (28) | % |
| Total % change in Operating profit |  | (18) | % |

[0001783180-23-000065:mdna:127]
The operational profit increase of 8% was primarily attributable to pricing improvements and ongoing customer demand in certain end-markets compared with the prior year. These benefits more than offset the higher costs for commodities and

[0001783180-23-000065:mdna:128]
components used in our products. Lower earnings from equity method investments impacted operational profit due to the increase in our ownership interest in TCC on August 1, 2022. As a result, TCC is no longer accounted for under the equity method of accounting since the date of acquisition. Inflationary cost pressures have begun to moderate, but continue to impact our operating profit.

[0001783180-23-000065:mdna:129]
Acquisitions and divestitures, net primarily related to the results of operations associated with the acquisition of TCC. The transaction added 1% to Operating profit during the nine months ended September 30, 2022. In connection with the TCC acquisition, the carrying value of our previously held TCC equity investments were recognized at fair value at the date of acquisition. As a result, we recognized a $732 million non-cash gain associated with the increase in our ownership interest in Other.

[0001783180-23-000065:mdna:130]
[same as prior period, unchanged from 0001783180-23-000056:mdna:123]

[0001783180-23-000065:mdna:131]
For the nine months ended September 30, 2023, Net sales in our Refrigeration segment were $2.8 billion, a 5% decrease compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000065:mdna:132]
|  |  | Net Sales |
| Organic |  | (4) | % |
| Foreign currency translation |  | — | % |
| Acquisitions and divestitures, net |  | (1) | % |
| Total % change in Net sales |  | (5) | % |

[0001783180-23-000065:mdna:133]
Organic Net sales decreased 4% compared to the prior year as the segment experienced challenges in certain end-markets during the period. Results for Commercial refrigeration decreased (down 16%) compared with the prior year, primarily driven by lower volumes in Europe as economic conditions and inflationary cost pressures impacted end-market demand. In addition, Asia results were impacted by reduced end-market demand in China. Transport refrigeration sales were flat compared to the prior year as pricing improvements and strong end-market demand in the U.S. and Europe offset continued weakness in container end-markets.

[0001783180-23-000065:mdna:134]
For the nine months ended September 30, 2023, Operating profit in our Refrigeration segment was $327 million, a 12% decrease compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000065:mdna:135]
|  |  | Operating Profit |
| Operational |  | (16) | % |
| Acquisitions and divestitures, net |  | (1) | % |
| Restructuring |  | (1) | % |
| Other |  | 6 | % |
| Total % change in Operating profit |  | (12) | % |

[0001783180-23-000065:mdna:136]
The decrease in operational profit of 16% was primarily driven by volume reductions in certain end-markets compared with the prior year. In addition, the higher costs of commodities and components used in our products further impacted segment results. These amounts were partially offset by pricing improvements and favorable productivity initiatives. Inflationary cost pressures have begun to moderate, but continue to impact our operating profit. Amounts reported in Other represent a $24 million gain on the sale of a business within Transport refrigeration.

[0001783180-23-000065:mdna:137]
[same as prior period, unchanged from 0001783180-23-000056:mdna:130]

[0001783180-23-000065:mdna:138]
For the nine months ended September 30, 2023, Net sales in our Fire & Security segment were $2.7 billion, a 4% increase compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000065:mdna:139]
|  |  | Net Sales |
| Organic |  | 8 | % |
| Foreign currency translation |  | (1) | % |
| KFI deconsolidation |  | (3) | % |
| Total % change in Net sales |  | 4 | % |

[0001783180-23-000065:mdna:140]
The organic increase in Net sales of 8% was primarily driven by pricing improvements and volume growth compared with the prior year. Sales grew in all three regions including strong commercial and residential results in the Americas. Growth in Europe moderated as economic conditions and inflationary cost pressures impacted end-market demand. Results in Asia normalized after a strong COVID-19 related recovery. Global industrial sales benefited segment results due to pricing improvements and strong demand. The segment continues to be impacted by ongoing supply chain constraints for certain components used in our products.

[0001783180-23-000065:mdna:141]
For the nine months ended September 30, 2023, Operating profit in our Fire & Security segment was $100 million, a 93% decrease compared with the same period of 2022. The components of the year-over-year change were as follows:

[0001783180-23-000065:mdna:142]
|  |  | Operating Profit |
| Operational |  | 2 | % |
| KFI deconsolidation |  | (21) | % |
| Chubb gain |  | (74) | % |
| Total % change in Operating profit |  | (93) | % |

[0001783180-23-000065:mdna:143]
The increase in operational profit of 2% was primarily driven by pricing improvements, volume growth and lower freight and logistics costs compared to the prior year. These amounts were partially offset by the higher costs of commodities and components used in our products. In addition, higher inventory-related reserves resulting from supply chain challenges further impacted segment results. Inflationary cost pressures have moderated, but continue to impact our operating profit.

[0001783180-23-000065:mdna:144]
As of May 14, 2023, we no longer control KFI as their activities are subject to review and oversight by the bankruptcy court. Therefore, KFI was deconsolidated and their respective assets and liabilities were derecognized from our Unaudited Condensed Consolidated Financial Statements. As a result, we recognized a loss on deconsolidation of $297 million during the nine months ended September 30, 2023.

[0001783180-23-000065:mdna:145]
[same as prior period, unchanged from 0001783180-23-000056:mdna:138]

[0001783180-23-000065:mdna:146]
[same as prior period, unchanged from 0001783180-23-000056:mdna:139]

[0001783180-23-000065:mdna:147]
As of September 30, 2023, we had cash and cash equivalents of $3.9 billion, of which approximately 39% was held by our foreign subsidiaries. We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which we can access funds held by foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection with contractual obligations related to acquisitions, divestitures or other legal obligations. As of September 30, 2023 and December 31, 2022, the amount of such restricted cash was approximately $6 million and $7 million, respectively.

[0001783180-23-000065:mdna:148]
We maintain a $2.0 billion unsecured, unsubordinated commercial paper program which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. In addition, we maintain a $2.0 billion revolving credit agreement with various banks (the "Revolving Credit Facility") that matures in May 2028 which supports our commercial paper borrowing program and can be used for other general corporate purposes. A ratings-based commitment fee is charged on

[0001783180-23-000065:mdna:149]
unused commitments. As of September 30, 2023, we had no borrowings outstanding under our commercial paper program and our Revolving Credit Facility.

[0001783180-23-000065:mdna:150]
[same as prior period, unchanged from 0001783180-23-000056:mdna:142]

[0001783180-23-000065:mdna:151]
[same as prior period, unchanged from 0001783180-23-000056:mdna:143]

[0001783180-23-000065:mdna:152]
[same as prior period, unchanged from 0001783180-23-000056:mdna:144]

[0001783180-23-000065:mdna:153]
| (In millions) |  | September 30,2023 |  | December 31,2022 |
| Cash and cash equivalents |  | $ | 3,902 |  |  | $ | 3,520 |  |
| Total debt |  | $ | 8,785 |  |  | $ | 8,842 |  |
| Total equity |  | $ | 8,502 |  |  | $ | 8,076 |  |
| Net debt (total debt less cash and cash equivalents) |  | $ | 4,883 |  |  | $ | 5,322 |  |
| Total capitalization (total debt plus total equity) |  | $ | 17,287 |  |  | $ | 16,918 |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | $ | 13,385 |  |  | $ | 13,398 |  |
| Total debt to total capitalization |  | 51 | % |  | 52 | % |
| Net debt to net capitalization |  | 36 | % |  | 40 | % |

[0001783180-23-000065:mdna:154]
[same as prior period, unchanged from 0001783180-23-000056:mdna:146]

[0001783180-23-000065:mdna:155]
Our short-term obligations primarily consist of current maturities of long-term debt. Our long-term obligations primarily consist of long-term notes with maturity dates ranging between 2025 and 2050. Interest payments related to long-term Notes are expected to approximate $249 million per year, reflecting an approximate weighted-average interest rate of 2.86%. Any borrowings from the Revolving Credit Facility are subject to variable interest rates. See Note 5 – Borrowings and Lines of Credit in the Notes to the accompanying Unaudited Condensed Consolidated Financial Statements for additional information regarding the terms of our long-term debt obligations.

[0001783180-23-000065:mdna:156]
[same as prior period, unchanged from 0001783180-23-000056:mdna:148]

[0001783180-23-000065:mdna:157]
On July 15, 2022, we entered into a five-year, JPY 54 billion (approximately $400 million) senior unsecured term loan facility with MUFG Bank Ltd., as administrative agent and lender, and certain other lenders (the "Japanese Term Loan Facility"). Borrowings bear interest at a rate equal to the Tokyo Term Risk Free Rate plus 0.75%. In addition, it is subject to customary covenants including a covenant to maintain a maximum consolidated leverage ratio. On July 25, 2022, we borrowed JPY 54 billion under the Japanese Term Loan Facility and used the proceeds to fund a portion of the TCC acquisition and to pay related fees and expenses.

[0001783180-23-000065:mdna:158]
The Revolving Credit Facility, the Japanese Term Loan Facility and the indentures for the long-term notes contain affirmative and negative covenants customary for financings of these types, which among other things, limit our ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of September 30, 2023, we were compliant with the covenants under the agreements governing our outstanding indebtedness.

[0001783180-23-000065:mdna:159]
The following table presents our credit ratings and outlook as of September 30, 2023:

[0001783180-23-000065:mdna:160]
[same as prior period, unchanged from 0001783180-23-000056:mdna:152]

[0001783180-23-000065:mdna:161]
[same as prior period, unchanged from 0001783180-23-000056:mdna:153]

[0001783180-23-000065:mdna:162]
[same as prior period, unchanged from 0001783180-23-000056:mdna:154]

[0001783180-23-000065:mdna:163]
[same as prior period, unchanged from 0001783180-23-000056:mdna:155]

[0001783180-23-000065:mdna:164]
[same as prior period, unchanged from 0001783180-23-000056:mdna:156]

[0001783180-23-000065:mdna:165]
[same as prior period, unchanged from 0001783180-23-000056:mdna:157]

[0001783180-23-000065:mdna:166]
[same as prior period, unchanged from 0001783180-23-000056:mdna:158]

[0001783180-23-000065:mdna:167]
[same as prior period, unchanged from 0001783180-23-000056:mdna:159]

[0001783180-23-000065:mdna:168]
[same as prior period, unchanged from 0001783180-23-000056:mdna:160]

[0001783180-23-000065:mdna:169]
We may repurchase our outstanding common stock from time to time subject to market conditions and at our discretion. Repurchases occur in the open market or through one or more other public or private transactions pursuant to plans complying with Rules 10b5-1 and 10b-18 under the Exchange Act. Since the initial authorization in February 2021, our Board of Directors authorized the repurchase of up to $4.1 billion of our outstanding common stock. As of December 31, 2022, we repurchased 42.1 million shares of common stock for an aggregate purchase price of $1.9 billion, including shares repurchased under an accelerated share repurchase agreement. As a result, we had approximately $2.2 billion remaining under the current authorization at December 31, 2022.

[0001783180-23-000065:mdna:170]
During the three months ended September 30, 2023, we did not repurchase any shares of common stock. During the nine months ended September 30, 2023, we repurchased 1.4 million shares of common stock for an aggregate purchase price of $62 million. As a result, we have approximately $2.1 billion remaining under the current authorization at September 30, 2023.

[0001783180-23-000065:mdna:171]
[same as prior period, unchanged from 0001783180-23-000056:mdna:163]

[0001783180-23-000065:mdna:172]
We paid dividends on common stock during the nine months ended September 30, 2023, totaling $465 million. In October 2023, the Board of Directors declared a dividend of $0.185 per share of common stock payable on November 20, 2023 to shareowners of record at the close of business on October 27, 2023.

[0001783180-23-000065:mdna:173]
[same as prior period, unchanged from 0001783180-23-000056:mdna:165]

[0001783180-23-000065:mdna:174]
|  |  | Nine Months Ended September 30, |
| (In millions) |  | 2023 |  | 2022 |
| Net cash flows provided by (used in): |  |  |  |  |
| Operating activities |  | $ | 1,545 |  |  | $ | 620 |  |
| Investing activities |  | (431) |  |  | 2,045 |  |
| Financing activities |  | (688) |  |  | (2,584) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  | (45) |  |  | (115) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  | $ | 381 |  |  | $ | (34) |  |

[0001783180-23-000065:mdna:175]
Cash flows from operating activities primarily represent inflows and outflows associated with our operations. Primary activities include net income from operations adjusted for non-cash transactions, working capital changes and changes in other assets and liabilities. The year-over-year increase in net cash provided by operating activities was primarily driven by a decrease in working capital balances compared with the prior period. Improved inventory management and higher accounts payable balances more than offset higher accounts receivable balances. In addition, Accounts payable and accrued liabilities included a $368 million mark-to-market valuation adjustment on our window forward contracts associated with the Euro-denominated purchase price of the VCS Business. Prior year working capital balances increased due to higher safety stock and supply chain constraints.

[0001783180-23-000065:mdna:176]
Cash flows from investing activities primarily represent inflows and outflows associated with long-term assets. Primary activities include capital expenditures, acquisitions, divestitures and proceeds from the sale of fixed assets. During the nine months ended September 30, 2023, net cash used in investing activities was $431 million. The primary drivers of the outflow related to $236 million of capital expenditures and $134 million related to the deconsolidation of KFI. In addition, we settled working capital and other transaction-related items associated with the acquisition of TCC and invested in several businesses. These amounts totaled $69 million, net of cash acquired and were partially offset by the proceeds from the sale of a business during the period. During the nine months ended September 30, 2022, net cash provided by investing activities was $2.0 billion. The primary driver of the inflow related to the net proceeds from the Chubb Sale. This amount was partially offset by the acquisition of TCC and several other businesses and minority-owned businesses, which totaled $472 million, net of cash acquired and $213 million of capital expenditures.

[0001783180-23-000065:mdna:177]
Cash flows from financing activities primarily represent inflows and outflows associated with equity or borrowings. During the nine months ended September 30, 2023, net cash used in financing activities was $688 million. The primary driver of the outflow related to the payment of $465 million in dividends to our common shareowners. In addition, we paid $62 million to repurchase shares of our common stock. During the nine months ended September 30, 2022, net cash used in financing activities was $2.6 billion. The primary driver of the outflow related to the payment of $1.3 billion to repurchase shares of our common stock. In addition, we settled our tender offers for $1.15 billion and paid $384 million in dividends to our common shareowners.
