# CARR note change history — 0001783180-21-000032 → 0001783180-21-000050


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-07-29):
[0001783180-21-000050:note_history:1]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees, and the Company periodically reassesses these amounts. Management believes that the likelihood of incurring losses materially in excess of the amounts accrued is remote. The outstanding liabilities for environmental obligations are as follows:
  (was, 2021-04-29, similarity 0.9991):
[0001783180-21-000032:note_history:1]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees and the Company periodically reassesses these amounts. Management believes that the likelihood of incurring losses materially in excess of the amounts accrued is remote. The outstanding liabilities for environmental obligations are as follows:

- changed (2021-07-29):
[0001783180-21-000050:note_history:2]
| (In millions) |  | June 30,2021 |  | December 31, 2020 |
| Environmental reserves included in Accrued liabilities |  | $ | 25 |  |  | $ | 26 |  |
| Environmental reserves included in Other long-term liabilities |  | 209 |  |  | 213 |  |
| Total Environmental reserves |  | $ | 234 |  |  | $ | 239 |  |
  (was, 2021-04-29, similarity 0.9796):
[0001783180-21-000032:note_history:2]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| Environmental reserves included in Accrued liabilities |  | $ | 25 |  |  | $ | 26 |  |
| Environmental reserves included in Other long-term liabilities |  | 210 |  |  | 213 |  |
| Total Environmental reserves |  | $ | 235 |  |  | $ | 239 |  |

- changed (2021-07-29):
[0001783180-21-000050:note_history:3]
| (In millions) |  | June 30,2021 |  | December 31,2020 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 18 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 222 |  |  | 228 |  |
| Total Asbestos liabilities |  | $ | 240 |  |  | $ | 245 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 6 |  |  | $ | 6 |  |
| Asbestos-related recoveries included in Other assets |  | 95 |  |  | 97 |  |
| Total Asbestos-related recoveries |  | $ | 101 |  |  | $ | 103 |  |
  (was, 2021-04-29, similarity 0.9579):
[0001783180-21-000032:note_history:3]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 18 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 225 |  |  | 228 |  |
| Total Asbestos liabilities |  | $ | 243 |  |  | $ | 245 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 6 |  |  | $ | 6 |  |
| Asbestos-related recoveries included in Other assets |  | 96 |  |  | 97 |  |
| Total Asbestos-related recoveries |  | $ | 102 |  |  | $ | 103 |  |

- changed (2021-07-29):
[0001783180-21-000050:note_history:4]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenges the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. The Complaint asserted that the defendants are liable for breach of certain equity compensation plans and for breach of fiduciary duty and also asserted claims under certain provisions of the Employee Retirement Income Security Act of 1974, as amended. Plaintiffs have withdrawn, with prejudice, their claims against Otis's and Carrier's current Boards of Directors. Carrier believes that the remaining claims against the Company are without merit.
  (was, 2021-04-29, similarity 0.8291):
[0001783180-21-000032:note_history:4]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenges the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. The Complaint asserted that the defendants are liable for breach of certain equity compensation plans and for breach of fiduciary duty and also asserted claims under certain provisions of the Employee Retirement Income Security Act of 1974, as amended. Plaintiffs recently withdrew, with prejudice, their claims against Otis's and Carrier's current Boards of Directors. Carrier believes that the remaining claims against the Company are without merit.

- added (2021-07-29):
[0001783180-21-000050:note_history:5]
Under the TMA, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act ("TCJA") transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, a liability of $453 million is included within the accompanying Unaudited Condensed Consolidated Balance Sheet at June 30, 2021. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $36 million included within Accrued Liabilities. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

- changed (2021-07-29):
[0001783180-21-000050:note_history:6]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its competitive position, results of operations, cash flows or financial condition.
  (was, 2021-04-29, similarity 0.9993):
[0001783180-21-000032:note_history:6]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its competitive position, results of operations, cash flows or financial condition.

- removed (2021-07-29):
[0001783180-21-000032:note_history:7]
Under the TMA, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act ("TCJA") transition tax associated with foreign undistributed earnings as of December 31, 2017. As of March 31, 2021, a liability of $72 million, primarily related to the Company's share of the TCJA transition tax associated with foreign undistributed earnings is included within Other long-term liabilities on the accompanying Unaudited Condensed Consolidated Balance Sheet. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.


## us-gaap:ScheduleOfEnvironmentalLossContingenciesBySiteTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-07-29):
[0001783180-21-000050:note_history:8]
| (In millions) |  | June 30,2021 |  | December 31, 2020 |
| Environmental reserves included in Accrued liabilities |  | $ | 25 |  |  | $ | 26 |  |
| Environmental reserves included in Other long-term liabilities |  | 209 |  |  | 213 |  |
| Total Environmental reserves |  | $ | 234 |  |  | $ | 239 |  |
  (was, 2021-04-29, similarity 0.9796):
[0001783180-21-000032:note_history:8]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| Environmental reserves included in Accrued liabilities |  | $ | 25 |  |  | $ | 26 |  |
| Environmental reserves included in Other long-term liabilities |  | 210 |  |  | 213 |  |
| Total Environmental reserves |  | $ | 235 |  |  | $ | 239 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-07-29):
[0001783180-21-000050:note_history:9]
| (In millions) |  | June 30,2021 |  | December 31,2020 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 18 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 222 |  |  | 228 |  |
| Total Asbestos liabilities |  | $ | 240 |  |  | $ | 245 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 6 |  |  | $ | 6 |  |
| Asbestos-related recoveries included in Other assets |  | 95 |  |  | 97 |  |
| Total Asbestos-related recoveries |  | $ | 101 |  |  | $ | 103 |  |
  (was, 2021-04-29, similarity 0.9579):
[0001783180-21-000032:note_history:9]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 18 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 225 |  |  | 228 |  |
| Total Asbestos liabilities |  | $ | 243 |  |  | $ | 245 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 6 |  |  | $ | 6 |  |
| Asbestos-related recoveries included in Other assets |  | 96 |  |  | 97 |  |
| Total Asbestos-related recoveries |  | $ | 102 |  |  | $ | 103 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-07-29):
[0001783180-21-000050:note_history:10]
BASIS OF PRESENTATION
The Unaudited Condensed Consolidated Financial Statements include all accounts of the Company and its wholly-owned and majority-owned subsidiaries in which it has control. All intra-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that the Company controls and consolidates.
  (was, 2021-04-29, similarity 0.9138):
[0001783180-21-000032:note_history:10]
BASIS OF PRESENTATION
The Unaudited Condensed Consolidated Financial Statements include all accounts of the Company and its wholly-owned and majority-owned subsidiaries in which it has control. All intra-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that the Company controls and consolidates. Certain prior year amounts have been reclassified to conform to the current period presentation.

- changed (2021-07-29):
[0001783180-21-000050:note_history:11]
The Company's financial statements for the periods prior to the Separation and the Distribution are prepared on a "carve-out" basis and include all amounts directly attributable to the Company. Net cash transfers and other property transferred between UTC and the Company, including related party receivables and payables between the Company and other UTC affiliates, are presented as Net transfers to UTC. In addition, the financial statements include allocations of costs for administrative functions and services performed on behalf of the Company by centralized groups within UTC. All allocations and estimates in the Unaudited Condensed Consolidated Financial Statements are based on assumptions that management believes are reasonable. The Company's financial statements for the periods subsequent to April 3, 2020 are consolidated financial statements based on the reported results of Carrier as a stand-alone company.
  (was, 2021-04-29, similarity 0.9978):
[0001783180-21-000032:note_history:11]
The Company's financial statements for periods prior to the Separation and the Distribution are prepared on a "carve-out" basis and include all amounts directly attributable to the Company. Net cash transfers and other property transferred between UTC and the Company, including related party receivables and payables between the Company and other UTC affiliates, are presented as Net transfers to UTC. In addition, the financial statements include allocations of costs for administrative functions and services performed on behalf of the Company by centralized groups within UTC. All allocations and estimates in the Unaudited Condensed Consolidated Financial Statements are based on assumptions that management believes are reasonable. The Company's financial statements for the periods subsequent to April 3, 2020 are consolidated financial statements based on the reported results of Carrier as a stand-alone company.

- added (2021-07-29):
[0001783180-21-000050:note_history:12]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes ("ASU 2019-12"), which simplifies certain aspects of income tax accounting guidance in ASC 740, Income Taxes ("ASC 740") reducing the complexity of its application while maintaining or improving the usefulness of the information required to be reported. The ASU eliminates certain exceptions from ASC 740 including: intra-period tax allocation, deferred tax liabilities related to outside basis differences and year-to-date loss in interim periods, among others. ASU 2019-12 was effective for periods beginning after December 15, 2020, including interim periods therein with early adoption permitted. The Company adopted this ASU on January 1, 2021 with no material impact on the Unaudited Condensed Consolidated Financial Statements.

- removed (2021-07-29):
[0001783180-21-000032:note_history:13]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes ("ASU 2019-12"), which simplifies certain aspects of income tax accounting guidance in ASC 740, reducing the complexity of its application while maintaining or improving the usefulness of the information required to be reported. The ASU eliminates certain exceptions from ASC 740 including: intra-period tax allocation, deferred tax liabilities related to outside basis differences and year-to-date loss in interim periods, among others. ASU 2019-12 was effective for periods beginning after December 15, 2020, including interim periods therein with early adoption permitted. The Company adopted this ASU on January 1, 2021 with no material impact on the Unaudited Condensed Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-07-29):
[0001783180-21-000050:note_history:14]
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of the Company into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In connection with the Separation, the Company issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020. On April 1, 2020 and April 2, 2020, the Company received cash contributions totaling $590 million from UTC related to the Separation.
  (was, 2021-04-29, similarity 0.9189):
[0001783180-21-000032:note_history:14]
On April 3, 2020, (the "Distribution Date"), United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of the Company into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In connection with the Separation, the Company issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020.

- changed (2021-07-29):
[0001783180-21-000050:note_history:15]
In connection with the Separation, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis following the Separation and the Distribution, including a transition services agreement ("TSA"), a tax matters agreement ("TMA"), an employee matters agreement and an intellectual property agreement that cover services such as information technology, tax, finance and human resources. In addition, the Company incurred separation-related costs including employee-related costs, costs to establish certain stand-alone functions, information technology systems, professional service fees and other costs associated with becoming an independent, publicly traded company. These costs are primarily recorded in Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations and totaled $3 million and $23 million for the three months ended June 30, 2021 and 2020, respectively. Costs for the six months ended June 30, 2021 and 2020 were $19 million and $68 million, respectively. The TSA expired on March 31, 2021.
  (was, 2021-04-29, similarity 0.9267):
[0001783180-21-000032:note_history:15]
In connection with the Separation, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship between the Company, UTC and Otis following the Separation and the Distribution, including a transition services agreement ("TSA"), a tax matters agreement ("TMA"), an employee matters agreement and an intellectual property agreement that cover services such as information technology, tax, finance and human resources. In addition, the Company incurred separation-related costs including employee-related costs, costs to establish certain stand-alone functions, information technology systems, professional service fees and other costs associated with becoming an independent, publicly traded company. These costs are primarily recorded in Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations and totaled $16 million and $45 million for the three months ended March 31, 2021 and 2020, respectively. The TSA expired on March 31, 2021.

- changed (2021-07-29):
[0001783180-21-000050:note_history:16]
In early 2020, the World Health Organization declared the outbreak of a respiratory disease known as COVID-19 as a global pandemic. In response, many countries implemented containment and mitigation measures to combat the outbreak, which severely restricted the level of economic activity and caused a significant contraction in the global economy. As a result, the Company temporarily closed or reduced production at manufacturing facilities across the globe to ensure employee safety and instructed non-essential employees to work from home. In addition, the Company took several preemptive actions during 2020 to manage liquidity as demand for its products decreased. Despite the adverse impacts of the pandemic on the Company’s results beginning in the first quarter of 2020, manufacturing operations resumed and several restorative actions were completed during 2020, including the reinstatement of annual merit-based salary increases and continued investment to support the Company's core strategy.
  (was, 2021-04-29, similarity 0.9819):
[0001783180-21-000032:note_history:16]
In early 2020, the World Health Organization declared the outbreak of a respiratory disease known as COVID-19 as a global pandemic. In response, many countries implemented containment and mitigation measures to combat the outbreak, which severely restricted the level of economic activity and caused a significant contraction in the global economy. As a result, the Company temporarily closed or reduced production at manufacturing facilities across the globe to ensure employee safety and instructed non-essential employees to work from home. In addition, the Company took several preemptive actions during the year to manage liquidity as demand for its products decreased. Despite the continued adverse impacts of the pandemic on the Company’s results since the first quarter of 2020, manufacturing operations resumed and several restorative actions were completed during 2020, including the reinstatement of annual merit-based salary increases and continued investment to support the Company's core strategy.

- changed (2021-07-29):
[0001783180-21-000050:note_history:17]
The Company continues to focus its efforts on preserving the health and safety of its employees and customers as well as maintaining the continuity of its operations. In addition, the Company continues to actively monitor its liquidity position and working capital needs and believes that its overall capital resources and liquidity position are adequate. The preparation of financial statements requires management to use judgments in making estimates and assumptions based on the relevant information available at the end of each period, which can have a significant effect on reported amounts. However, due to significant uncertainty surrounding the pandemic, management's judgments could change. While the Company's results of operations, cash flows and financial condition could be negatively impacted, the extent of any continuing impact cannot be estimated with certainty at this time.
  (was, 2021-04-29, similarity 0.6163):
[0001783180-21-000032:note_history:17]
The Company continues to focus its efforts on preserving the health and safety of its employees and customers as well as maintaining the continuity of its operations. In addition, the Company continues to actively monitor its liquidity position and working capital needs and believes that its overall capital resources and liquidity position are adequate. The preparation of financial statements requires management to use judgments in making estimates and assumptions based on the relevant information available at the end of each period which can have a significant effect on reported amounts. However, due to significant uncertainty surrounding the pandemic, management's judgments could change. While the Company's results of operations, cash flows and financial condition could be negatively impacted, the extent of the impact cannot be estimated with certainty at this time.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-07-29):
[0001783180-21-000050:note_history:18]
| (In millions, except percentages) |  |  |  | June 30,2021 |  | December 31,2020 |
| 1.923% Notes due February 15, 2023 |  |  |  | $ | — |  | (1) | $ | 500 |  |
| 2.242% Notes due February 15, 2025 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 1,250 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term Notes |  |  |  | 9,500 |  |  | 10,000 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 300 |  |  | 308 |  |
| Discounts and debt issuance costs |  |  |  | (75) |  |  | (81) |  |
| Total debt |  |  |  | 9,725 |  |  | 10,227 |  |
| Less: current portion of long-term debt |  |  |  | 125 |  |  | 191 |  |
| Long-term debt, net of current portion |  |  |  | $ | 9,600 |  |  | $ | 10,036 |  |

- changed (2021-07-29):
[0001783180-21-000050:note_history:19]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements of the Company. A commitment fee of 0.125% is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate based on LIBOR plus a ratings-based margin, which was 125 basis points as of June 30, 2021. As of June 30, 2021, there were no borrowings outstanding under the Revolving Credit Facility.
  (was, 2021-04-29, similarity 0.9261):
[0001783180-21-000032:note_history:19]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements of the Company. A commitment fee of 0.125% is charged on the unused commitments under the Revolving Credit Facility. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate based on LIBOR plus a ratings-based margin, which was 125 basis points as of March 31, 2021. As of March 31, 2021, there were no borrowings outstanding under the Revolving Credit Facility.

- changed (2021-07-29):
[0001783180-21-000050:note_history:20]
As of June 30, 2021, the Company had a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of June 30, 2021, there were no borrowings outstanding under the commercial paper program.
  (was, 2021-04-29, similarity 0.9703):
[0001783180-21-000032:note_history:20]
As of March 31, 2021, the Company had a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of March 31, 2021, there were no borrowings outstanding under the commercial paper program.

- changed (2021-07-29):
[0001783180-21-000050:note_history:21]
The Company is involved in several long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $71 million and $75 million of debt during the six months ended June 30, 2021 and 2020, respectively. Long-term debt repayments associated with these financing arrangements during the six months ended June 30, 2021 and 2020 were $83 million and $36 million, respectively.
  (was, 2021-04-29, similarity 0.8918):
[0001783180-21-000032:note_history:21]
The Company is involved in several long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $46 million and $40 million of debt during the three months ended March 31, 2021 and 2020, respectively. Long-term debt repayments associated with these financing arrangements during the three months ended March 31, 2021 and 2020 were $53 million and $34 million, respectively.

- changed (2021-07-29):
[0001783180-21-000050:note_history:22]
The Revolving Credit Facility and the indenture for the long-term notes contain affirmative and negative covenants customary for financings of these types which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. On June 2, 2020, the Company entered into an amendment of the Revolving Credit Facility, under which certain terms of the facility were amended for a period beginning on June 2, 2020 and ending on December 30, 2021 (the "Covenant Modification Period"). The Company may terminate the Covenant Modification Period prior to December 30, 2021, subject to the satisfaction of certain conditions. The amendment deferred testing of the Company's consolidated total net leverage ratio financial covenant until June 30, 2021 and increases the consolidated total net leverage ratio limit until December 31, 2021. The amendment also required the Company to maintain 
liquidity at a certain level until the earlier of (1) June 29, 2021 and (2) the last day of the Covenant Modification Period. As of June 30, 2021 the requirement to test the Company's consolidated total net leverage ratio was reinstated, and there is no remaining requirement to maintain liquidity at a certain level. Additionally, during the Covenant Modification Period, the Company is subject to: (a) limitations on the incurrence of subsidiary indebtedness, (b) limitations on the making of restricted payments, including purchases by the Company of shares of its common stock and the amount of dividends the Company may pay and (c) a "most favored nations" provision related to certain terms of any committed credit facility in an amount greater than $100 million. As of June 30, 2021, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.
  (was, 2021-04-29, similarity 0.9412):
[0001783180-21-000032:note_history:22]
The Revolving Credit Facility and the indenture for the long-term notes contain affirmative and negative covenants customary for financings of these types, which among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. On June 2, 2020, the Company entered into an amendment of the Revolving Credit Facility, under which certain terms of the facility were amended for a period beginning on June 2, 2020 and ending on December 30, 2021 (the "Covenant Modification Period"). The Company may terminate the Covenant Modification Period prior to December 30, 2021, subject to the satisfaction of certain conditions. The amendment 
defers testing of the Company's consolidated total net leverage ratio financial covenant until June 30, 2021 and increases the consolidated total net leverage ratio limit until December 31, 2021. The amendment also requires the Company to maintain liquidity at a certain level until the earlier of (1) June 29, 2021 and (2) the last day of the Covenant Modification Period. Additionally, during the Covenant Modification Period, the Company is subject to: (a) limitations on the incurrence of subsidiary indebtedness, (b) limitations on the making of restricted payments, including purchases by the Company of shares of its common stock and the amount of dividends the Company may pay and (c) a "most favored nations" provision related to certain terms of any committed credit facility in an amount greater than $100 million. As of March 31, 2021, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.

- removed (2021-07-29):
[0001783180-21-000032:note_history:23]
| (In millions, except percentages) |  |  |  | March 31, 2021 |  | December 31, 2020 |
| 1.923% Notes due February 15, 2023 |  |  |  | $ | — |  | (1) | $ | 500 |  |
| 2.242% Notes due February 15, 2025 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 1,250 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Other (including project financing obligations and finance leases) |  |  |  | 307 |  |  | 308 |  |
| Total principal long-term debt |  |  |  | 9,807 |  |  | 10,308 |  |
| Other (discounts and debt issuance costs) (1) |  |  |  | (77) |  |  | (81) |  |
| Total debt |  |  |  | 9,730 |  |  | 10,227 |  |
| Less: current portion of long-term debt |  |  |  | 153 |  |  | 191 |  |
| Long-term debt, net of current portion |  |  |  | $ | 9,577 |  |  | $ | 10,036 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-07-29):
[0001783180-21-000050:note_history:24]
| (In millions, except percentages) |  |  |  | June 30,2021 |  | December 31,2020 |
| 1.923% Notes due February 15, 2023 |  |  |  | $ | — |  | (1) | $ | 500 |  |
| 2.242% Notes due February 15, 2025 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 1,250 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term Notes |  |  |  | 9,500 |  |  | 10,000 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 300 |  |  | 308 |  |
| Discounts and debt issuance costs |  |  |  | (75) |  |  | (81) |  |
| Total debt |  |  |  | 9,725 |  |  | 10,227 |  |
| Less: current portion of long-term debt |  |  |  | 125 |  |  | 191 |  |
| Long-term debt, net of current portion |  |  |  | $ | 9,600 |  |  | $ | 10,036 |  |

- removed (2021-07-29):
[0001783180-21-000032:note_history:25]
| (In millions, except percentages) |  |  |  | March 31, 2021 |  | December 31, 2020 |
| 1.923% Notes due February 15, 2023 |  |  |  | $ | — |  | (1) | $ | 500 |  |
| 2.242% Notes due February 15, 2025 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 1,250 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Other (including project financing obligations and finance leases) |  |  |  | 307 |  |  | 308 |  |
| Total principal long-term debt |  |  |  | 9,807 |  |  | 10,308 |  |
| Other (discounts and debt issuance costs) (1) |  |  |  | (77) |  |  | (81) |  |
| Total debt |  |  |  | 9,730 |  |  | 10,227 |  |
| Less: current portion of long-term debt |  |  |  | 153 |  |  | 191 |  |
| Long-term debt, net of current portion |  |  |  | $ | 9,577 |  |  | $ | 10,036 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2021-07-29):
[0001783180-21-000050:note_history:26]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Sales to equity method investees included in Product sales |  | $ | 652 |  |  | $ | 434 |  |  | $ | 1,120 |  |  | $ | 778 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 98 |  |  | $ | 66 |  |  | $ | 174 |  |  | $ | 143 |  |
  (was, 2021-04-29, similarity 0.8401):
[0001783180-21-000032:note_history:26]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2021 |  | 2020 |  |  |  |  |
| Sales to equity method investees included in Product sales |  | $ | 468 |  |  | $ | 344 |  |  |  |  |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 75 |  |  | $ | 77 |  |  |  |  |  |

- changed (2021-07-29):
[0001783180-21-000050:note_history:27]
| (In millions) |  | June 30,2021 |  | December 31, 2020 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 243 |  |  | $ | 161 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 59 |  |  | $ | 38 |  |
  (was, 2021-04-29, similarity 0.9776):
[0001783180-21-000032:note_history:27]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 197 |  |  | $ | 161 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 45 |  |  | $ | 38 |  |

- changed (2021-07-29):
[0001783180-21-000050:note_history:28]
The Company periodically reviews the carrying value of its equity method investments to determine if there has been an other-than-temporary decline in fair value. During the three months ended March 31, 2020, the Company determined that indicators of impairment existed for a minority owned joint venture investment and performed a valuation of this investment using a  discounted cash flow method. The Company determined that the loss in value was other-than-temporary due to a reduction in sales and earnings that were primarily driven by a deterioration in the oil and gas industry (the joint venture's primary market) and by the impact of the COVID-19 pandemic. As a result, the Company recorded a non-cash, other-than-temporary impairment charge of $71 million on this investment during the three months ended March 31, 2020, which is included in Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations.
  (was, 2021-04-29, similarity 0.776):
[0001783180-21-000032:note_history:28]
The Company periodically reviews the carrying value of its equity method investments to determine if there has been an other-than-temporary decline in fair value. A variety of factors are considered when determining if a decline in carrying value is 
other-than-temporary, including, among other factors, the financial condition and business prospects of the investee, as well as the Company's intent with regard to the investment. During the three months ended March 31, 2020, the Company determined that indicators of impairment existed for a minority owned joint venture investment. The Company performed a valuation of this investment, which was based on the income approach using the discounted cash flow method. The Company determined that the loss in value was other-than-temporary due to a reduction in sales and earnings that were driven by a deterioration in the oil and gas industry (the joint venture's primary market) and by the impact of the COVID-19 pandemic, among other factors. As a result, the Company recorded a non-cash, other-than-temporary impairment charge of $71 million on this investment during the three months ended March 31, 2020, which is included in Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-07-29):
[0001783180-21-000050:note_history:29]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,757 |  |  | $ | 1,976 |  |  | $ | 4,904 |  |  | $ | 3,633 |  |
| Service |  | 363 |  |  | 315 |  |  | 702 |  |  | 617 |  |
| HVAC sales |  | 3,120 |  |  | 2,291 |  |  | 5,606 |  |  | 4,250 |  |
| Product |  | 915 |  |  | 609 |  |  | 1,807 |  |  | 1,322 |  |
| Service |  | 106 |  |  | 91 |  |  | 219 |  |  | 186 |  |
| Refrigeration sales |  | 1,021 |  |  | 700 |  |  | 2,026 |  |  | 1,508 |  |
| Product |  | 1,012 |  |  | 762 |  |  | 1,931 |  |  | 1,622 |  |
| Service |  | 391 |  |  | 295 |  |  | 776 |  |  | 641 |  |
| Fire & Security sales |  | 1,403 |  |  | 1,057 |  |  | 2,707 |  |  | 2,263 |  |
| Total segment sales |  | 5,544 |  |  | 4,048 |  |  | 10,339 |  |  | 8,021 |  |
| Eliminations and other |  | (104) |  |  | (76) |  |  | (200) |  |  | (161) |  |
| Net sales |  | $ | 5,440 |  |  | $ | 3,972 |  |  | $ | 10,139 |  |  | $ | 7,860 |  |
  (was, 2021-04-29, similarity 0.8394):
[0001783180-21-000032:note_history:29]
|  |  | For the Three Months Ended March 31, |  |  |
| (In millions) |  | 2021 |  | 2020 |  |  |  |  |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,147 |  |  | $ | 1,657 |  |  |  |  |  |
| Service |  | 339 |  |  | 302 |  |  |  |  |  |
| HVAC sales |  | 2,486 |  |  | 1,959 |  |  |  |  |  |
| Product |  | 892 |  |  | 713 |  |  |  |  |  |
| Service |  | 113 |  |  | 95 |  |  |  |  |  |
| Refrigeration sales |  | 1,005 |  |  | 808 |  |  |  |  |  |
| Product |  | 919 |  |  | 860 |  |  |  |  |  |
| Service |  | 385 |  |  | 346 |  |  |  |  |  |
| Fire & Security sales |  | 1,304 |  |  | 1,206 |  |  |  |  |  |
| Total segment sales |  | 4,795 |  |  | 3,973 |  |  |  |  |  |
| Eliminations and other |  | (96) |  |  | (85) |  |  |  |  |  |
| Net sales |  | $ | 4,699 |  |  | $ | 3,888 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-07-29):
[0001783180-21-000050:note_history:30]
REVENUE RECOGNITION The Company recognizes revenue when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefit from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company's performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.
Sales disaggregated by product and service are as follows:
  (was, 2021-04-29, similarity 0.9655):
[0001783180-21-000032:note_history:30]
REVENUE RECOGNITION 
The Company recognizes revenue when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefit from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company's performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.

- changed (2021-07-29):
[0001783180-21-000050:note_history:31]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,757 |  |  | $ | 1,976 |  |  | $ | 4,904 |  |  | $ | 3,633 |  |
| Service |  | 363 |  |  | 315 |  |  | 702 |  |  | 617 |  |
| HVAC sales |  | 3,120 |  |  | 2,291 |  |  | 5,606 |  |  | 4,250 |  |
| Product |  | 915 |  |  | 609 |  |  | 1,807 |  |  | 1,322 |  |
| Service |  | 106 |  |  | 91 |  |  | 219 |  |  | 186 |  |
| Refrigeration sales |  | 1,021 |  |  | 700 |  |  | 2,026 |  |  | 1,508 |  |
| Product |  | 1,012 |  |  | 762 |  |  | 1,931 |  |  | 1,622 |  |
| Service |  | 391 |  |  | 295 |  |  | 776 |  |  | 641 |  |
| Fire & Security sales |  | 1,403 |  |  | 1,057 |  |  | 2,707 |  |  | 2,263 |  |
| Total segment sales |  | 5,544 |  |  | 4,048 |  |  | 10,339 |  |  | 8,021 |  |
| Eliminations and other |  | (104) |  |  | (76) |  |  | (200) |  |  | (161) |  |
| Net sales |  | $ | 5,440 |  |  | $ | 3,972 |  |  | $ | 10,139 |  |  | $ | 7,860 |  |
  (was, 2021-04-29, similarity 0.8394):
[0001783180-21-000032:note_history:31]
|  |  | For the Three Months Ended March 31, |  |  |
| (In millions) |  | 2021 |  | 2020 |  |  |  |  |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,147 |  |  | $ | 1,657 |  |  |  |  |  |
| Service |  | 339 |  |  | 302 |  |  |  |  |  |
| HVAC sales |  | 2,486 |  |  | 1,959 |  |  |  |  |  |
| Product |  | 892 |  |  | 713 |  |  |  |  |  |
| Service |  | 113 |  |  | 95 |  |  |  |  |  |
| Refrigeration sales |  | 1,005 |  |  | 808 |  |  |  |  |  |
| Product |  | 919 |  |  | 860 |  |  |  |  |  |
| Service |  | 385 |  |  | 346 |  |  |  |  |  |
| Fire & Security sales |  | 1,304 |  |  | 1,206 |  |  |  |  |  |
| Total segment sales |  | 4,795 |  |  | 3,973 |  |  |  |  |  |
| Eliminations and other |  | (96) |  |  | (85) |  |  |  |  |  |
| Net sales |  | $ | 4,699 |  |  | $ | 3,888 |  |  |  |  |  |

- changed (2021-07-29):
[0001783180-21-000050:note_history:32]
| (In millions) |  | June 30,2021 |  | December 31,2020 |
| Contract assets, current |  | $ | 695 |  |  | $ | 656 |  |
| Contract assets, non-current (included within Other assets) |  | 166 |  |  | 98 |  |
| Total contract assets |  | $ | 861 |  |  | $ | 754 |  |
| Contract liabilities, current |  | (576) |  |  | (512) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (171) |  |  | (165) |  |
| Total contract liabilities |  | (747) |  |  | (677) |  |
| Net contract assets |  | $ | 114 |  |  | $ | 77 |  |
  (was, 2021-04-29, similarity 0.9678):
[0001783180-21-000032:note_history:32]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| Contract assets, current |  | $ | 694 |  |  | $ | 656 |  |
| Contract assets, non-current (included within Other assets) |  | 137 |  |  | 98 |  |
| Total contract assets |  | 831 |  |  | 754 |  |
| Contract liabilities, current |  | (545) |  |  | (512) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (170) |  |  | (165) |  |
| Total contract liabilities |  | (715) |  |  | (677) |  |
| Net contract assets |  | $ | 116 |  |  | $ | 77 |  |

- changed (2021-07-29):
[0001783180-21-000050:note_history:33]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under the contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to the customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. The Company recognized revenue of $100 million during the six months ended June 30, 2021 that related to contract liabilities  as of January 1, 2021. The Company expects a majority of its contract liabilities at the end of the period to be recognized as revenue in the next 12 months.
  (was, 2021-04-29, similarity 0.7367):
[0001783180-21-000032:note_history:33]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under the contract or when the Company has a right to consideration that is unconditional before it transfers a good or service to the customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. The Company recognized revenue of $189 million during the three months ended March 31, 2021 that related to the contract liabilities balance as of January 1, 2021. The Company expects a majority of its contract liability balance at the end of the period to be recognized as revenue in the next 12 months.

- removed (2021-07-29):
[0001783180-21-000032:note_history:34]
Sales disaggregated by product and service are as follows:


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2021-07-29):
[0001783180-21-000050:note_history:35]
SUBSEQUENT EVENTS 
Sale of Chubb Fire & Security Business

- added (2021-07-29):
[0001783180-21-000050:note_history:36]
On July 26, 2021, the Company entered into an agreement to sell its Chubb Fire and Security business (Chubb) to APi Group Corporation (APi) for an enterprise value of $3.1 billion (the “Agreement”). The purchase price is subject to working capital and other adjustments as provided in the Agreement. Chubb, reported within the Company’s Fire & Security segment, delivers essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. At June 30, 2021, Chubb did not meet the criteria for assets held for sale in the Unaudited Condensed Consolidated Balance Sheet. On a prospective basis, the net assets of Chubb will be classified as held for sale until the divestiture is completed. This transaction is expected to close late in the fourth quarter of 2021 or early in the first quarter of 2022, subject to regulatory approvals, required works council consultation in France and customary closing conditions. Based on the carrying amount of Chubb’s net assets, foreign currency translation rates and other assumptions at June 30, 2021, the Company expects to recover the carrying value of the disposal group upon completion of the transaction. In conjunction with the Agreement, the Company has agreed to provide APi, and APi has agreed to provide the Company, certain transitional services for varying periods after the closing.

- added (2021-07-29):
[0001783180-21-000050:note_history:37]
Share Repurchase Program
On July 27, 2021, the Company's Board of Directors approved a $1.75 billion increase to the Company's existing $350 million stock repurchase program authorized in February 2021. Share repurchases may take place from time to time subject to market conditions and at the Company's discretion in the open market or through one or more other public or private transactions.

- removed (2021-07-29):
[0001783180-21-000032:note_history:38]
SUBSEQUENT EVENTS 
On April 19, 2021, the Board of Directors declared a dividend of $0.12 per share of common stock payable on May 24, 2021 to shareowners of record at the close of business on May 3, 2021.

- removed (2021-07-29):
[0001783180-21-000032:note_history:39]
On April 19, 2021, the Company announced that it signed agreements to acquire a controlling stake in Guangdong Giwee Group and its subsidiaries ("Giwee"). Giwee is a China-based manufacturer of HVAC products, offering a portfolio of products including variable refrigerant flow, modular chillers and light commercial air conditioners. The Company expects to close its acquisition of a controlling stake of Giwee in the second quarter of 2021 (with the remainder expected to close in the third quarter of 2021), subject to customary closing conditions, including regulatory approvals.
