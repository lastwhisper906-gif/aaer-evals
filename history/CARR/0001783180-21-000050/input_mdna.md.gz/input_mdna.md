# CARR MD&A — 0001783180-21-000050


## mdna

[0001783180-21-000050:mdna:1]
[same as prior period, unchanged from 0001783180-21-000032:mdna:1]

[0001783180-21-000050:mdna:2]
[same as prior period, unchanged from 0001783180-21-000032:mdna:2]

[0001783180-21-000050:mdna:3]
[same as prior period, unchanged from 0001783180-21-000032:mdna:3]

[0001783180-21-000050:mdna:4]
[same as prior period, unchanged from 0001783180-21-000032:mdna:4]

[0001783180-21-000050:mdna:5]
Our worldwide operations are affected by global and regional industrial, economic and political factors and trends. These include the mega-trends of urbanization, climate change and increasing requirements for food safety driven by the food needs of our growing global population and the rising standards of living in emerging markets. We believe that our business segments are well positioned to benefit from favorable secular trends, including these mega-trends and from the strength of our industry-leading brands and track record of innovation. In addition, we regularly review our markets to proactively detect trends and adapt our strategies accordingly.

[0001783180-21-000050:mdna:6]
Our business is also affected by changes in the general level of economic activity, such as changes in business and consumer spending, construction and shipping activity as well as short-term economic factors such as currency fluctuations, commodity price volatility and supply disruptions. However, we continue to invest in our business, take pricing actions to mitigate supply chain and inflationary pressures, develop new products and services in order to remain competitive in our markets and use risk management strategies to mitigate various exposures. We believe that we have industry-leading global brands which form the foundation of our business strategy. Coupled with our focus on growth, innovation and operational efficiency, we expect to drive long-term future growth and increased value for our shareowners.

[0001783180-21-000050:mdna:7]
Recent Developments

[0001783180-21-000050:mdna:8]
Sale of Chubb Fire & Security Business

[0001783180-21-000050:mdna:9]
On July 26, 2021, we entered into an agreement to sell our Chubb business to APi for an enterprise value of $3.1 billion. The purchase price is subject to working capital and other adjustments as provided in the Agreement. Chubb, reported within our Fire & Security segment, delivers essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. At June 30, 2021, Chubb did not meet the criteria for assets held for sale in the Unaudited Condensed Consolidated Balance Sheet. On a prospective basis, the net assets of Chubb will be classified as held for sale until the divestiture is completed. This transaction is expected to close late in the fourth quarter of 2021 or early in the first quarter of 2022, subject to regulatory approvals, required works council consultation in France  and customary closing conditions. Based on the carrying amount of Chubb’s net assets, foreign currency translation rates and other assumptions at June 30, 2021, we expect to recover the carrying value of the disposal group upon completion of the transaction. In conjunction with the Agreement, we have agreed to provide APi, and APi has agreed to provide the Company, certain transitional services for varying periods after the closing.

[0001783180-21-000050:mdna:10]
Share Repurchase Program

[0001783180-21-000050:mdna:11]
On July 27, 2021, our Board of Directors approved a $1.75 billion increase to our existing $350 million stock repurchase program authorized in February 2021. Share repurchases may take place from time to time subject to market conditions and at our discretion in the open market or through one or more other public or private transactions.

[0001783180-21-000050:mdna:12]
[same as prior period, unchanged from 0001783180-21-000032:mdna:8]

[0001783180-21-000050:mdna:13]
On April 3, 2020, UTC completed the Separation of Carrier into an independent, publicly traded company. In connection with the Separation, we issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020. In addition, we entered into several agreements with UTC and Otis that govern various aspects of the relationship among us, UTC and Otis following the Separation and the Distribution including the TSA (which expired on March 31, 2021), the TMA, an employee matters agreement and an intellectual property agreement. Income and expense under these agreements are not material.

[0001783180-21-000050:mdna:14]
Our financial statements for periods prior to the Separation and the Distribution are prepared on a "carve-out" basis and include all amounts directly attributable to Carrier. Net cash transfers and other property transferred between UTC and us, including related party receivables and payables between us and other UTC affiliates, are presented as Net transfers to UTC. In addition, the financial statements include allocations of costs for administrative functions and services performed on our behalf by centralized groups within UTC. All allocations and estimates in the Unaudited Condensed Consolidated Financial Statements are based on assumptions that management believes are reasonable. Our financial statements for the periods subsequent to April 3, 2020 are consolidated financial statements based on the reported results of Carrier as a stand-alone company.

[0001783180-21-000050:mdna:15]
[same as prior period, unchanged from 0001783180-21-000032:mdna:12]

[0001783180-21-000050:mdna:16]
In early 2020, the World Health Organization declared the outbreak of a respiratory disease known as COVID-19 as a global pandemic. In response, many countries implemented containment and mitigation measures to combat the outbreak, which severely restricted the level of economic activity and caused a significant contraction in the global economy. As a result, we temporarily closed or reduced production at manufacturing facilities across the globe to ensure employee safety and instructed non-essential employees to work from home. In addition, we took several preemptive actions during 2020 to manage liquidity as demand for our products decreased. Despite the adverse impacts of the pandemic on our results beginning in the first quarter of 2020, manufacturing operations resumed and several restorative actions were completed during 2020 including the reinstatement of annual merit-based salary increases and continued investment to support our core strategy.

[0001783180-21-000050:mdna:17]
We continue to focus our efforts on preserving the health and safety of our employees and customers as well as maintaining the continuity of our operations. In addition, we continue to actively monitor our liquidity position and working capital needs and believe that our overall capital resources and liquidity position are adequate. The preparation of financial statements requires management to use judgments in making estimates and assumptions based on the relevant information available at the end of each period, which can have a significant effect on reported amounts. However, due to significant uncertainty surrounding the pandemic, management's judgments could change. While our results of operations, cash flows and financial condition could be negatively impacted, the extent of any continuing impact cannot be estimated with certainty at this time.

[0001783180-21-000050:mdna:18]
[same as prior period, unchanged from 0001783180-21-000032:mdna:17]

[0001783180-21-000050:mdna:19]
[same as prior period, unchanged from 0001783180-21-000032:mdna:18]

[0001783180-21-000050:mdna:20]
[same as prior period, unchanged from 0001783180-21-000032:mdna:49]

[0001783180-21-000050:mdna:21]
[same as prior period, unchanged from 0001783180-21-000032:mdna:19]

[0001783180-21-000050:mdna:22]
Three Months Ended June 30, 2021 Compared with the Three Months Ended June 30, 2020

[0001783180-21-000050:mdna:23]
|  |  | For the Three Months Ended June 30, |  |  |  |  |  |  |
| (In millions) |  | 2021 |  | 2020 |  | Period Change |  | % Change |  |  |  |  |  |  |
| Net sales |  | $ | 5,440 |  |  | $ | 3,972 |  |  | $ | 1,468 |  |  | 37 | % |  |  |  |  |  |  |
| Cost of products and services sold |  | (3,821) |  |  | (2,831) |  |  | (990) |  |  | 35 | % |  |  |  |  |  |  |
| Gross margin |  | 1,619 |  |  | 1,141 |  |  | 478 |  |  | 42 | % |  |  |  |  |  |  |
| Operating expenses |  | (836) |  |  | (699) |  |  | (137) |  |  | 20 | % |  |  |  |  |  |  |
| Operating profit |  | 783 |  |  | 442 |  |  | 341 |  |  | 77 | % |  |  |  |  |  |  |
| Non-operating income (expenses), net |  | (52) |  |  | (67) |  |  | 15 |  |  | (22) | % |  |  |  |  |  |  |
| Income from operations before income taxes |  | 731 |  |  | 375 |  |  | 356 |  |  | 95 | % |  |  |  |  |  |  |
| Income tax expense |  | (234) |  |  | (106) |  |  | (128) |  |  | 121 | % |  |  |  |  |  |  |
| Net income from operations |  | 497 |  |  | 269 |  |  | 228 |  |  | 85 | % |  |  |  |  |  |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 10 |  |  | 8 |  |  | 2 |  |  | 25 | % |  |  |  |  |  |  |
| Net income attributable to common shareowners |  | $ | 487 |  |  | $ | 261 |  |  | $ | 226 |  |  | 87 | % |  |  |  |  |  |  |

[0001783180-21-000050:mdna:24]
[same as prior period, unchanged from 0001783180-21-000032:mdna:22]

[0001783180-21-000050:mdna:25]
For the three months ended June 30, 2021, Net sales were $5.4 billion, a 37% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000050:mdna:26]
|  |  | For the Three Months Ended June 30, 2021 |  |  |  |  |  |  |
| Organic |  | 31 | % |  |  |  |  |  |  |
| Foreign currency translation |  | 5 | % |  |  |  |  |  |  |
| Acquisitions and divestitures, net |  | 1 | % |  |  |  |  |  |  |
| Total % change |  | 37 | % |  |  |  |  |  |  |

[0001783180-21-000050:mdna:27]
As the global economy continues to recover from the impact of the COVID-19 pandemic, we continue to see improvement across our global business. During the three months ended June 30, 2021, higher volume in each of our segments increased organic sales by 31% compared with the same period of 2020. The organic increase was primarily driven by our HVAC segment with continued strong results in the North America residential and light commercial business and improved global end-markets in our Commercial HVAC business. Strong results in both our Refrigeration and Fire & Security segments were driven by improved global end-markets compared with the prior period. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-21-000050:mdna:28]
[same as prior period, unchanged from 0001783180-21-000032:mdna:28]

[0001783180-21-000050:mdna:29]
For the three months ended June 30, 2021, gross margin was $1.6 billion, a 42% increase compared with the same period of 2020. The components were as follows:

[0001783180-21-000050:mdna:30]
|  |  | For the Three Months Ended June 30, |  |  |  |  |  |  |
| (In millions) |  | 2021 |  | 2020 |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 5,440 |  |  | $ | 3,972 |  |  |  |  |  |  |  |  |  |
| Cost of products and services sold |  | (3,821) |  |  | (2,831) |  |  |  |  |  |  |  |  |  |
| Gross margin |  | $ | 1,619 |  |  | $ | 1,141 |  |  |  |  |  |  |  |  |  |
| Percentage of net sales |  | 29.8 | % |  | 28.7 | % |  |  |  |  |  |  |  |  |

[0001783180-21-000050:mdna:31]
[same as prior period, unchanged from 0001783180-21-000032:mdna:63]

[0001783180-21-000050:mdna:32]
The increase in gross margin for the three months ended June 30, 2021 was primarily driven by strong operational performance and continued improvement in the global economic climate during the current period. Higher volume in each of our segments outpaced operational costs as we continued to focus on Carrier 700 cost containment actions. These improvements were partially offset by the rising cost for commodities and components used in our products, certain supply chain inefficiencies and freight costs. As a result, gross margin as a percentage of Net sales increased by 110 basis points compared with the same period of 2020.

[0001783180-21-000050:mdna:33]
[same as prior period, unchanged from 0001783180-21-000032:mdna:32]

[0001783180-21-000050:mdna:34]
For the three months ended June 30, 2021, operating expenses, including Equity method investment net earnings, were $836 million, a 20% increase compared with the same period of 2020. The components were as follows:

[0001783180-21-000050:mdna:35]
|  |  | For the Three Months Ended June 30, |  |  |  |  |  |  |
| (In millions) |  | 2021 |  | 2020 |  |  |  |  |  |  |  |  |
| Selling, general and administrative |  | $ | (813) |  |  | $ | (637) |  |  |  |  |  |  |  |  |  |
| Research and development |  | (125) |  |  | (94) |  |  |  |  |  |  |  |  |  |
| Equity method investment net earnings |  | 87 |  |  | 57 |  |  |  |  |  |  |  |  |  |
| Other income (expense), net |  | 15 |  |  | (25) |  |  |  |  |  |  |  |  |  |
| Total operating expenses |  | $ | (836) |  |  | $ | (699) |  |  |  |  |  |  |  |  |  |
| Percentage of net sales |  | 15.4 | % |  | 17.6 | % |  |  |  |  |  |  |  |  |

[0001783180-21-000050:mdna:36]
For the three months ended June 30, 2021, Selling, general and administrative expenses were $813 million, a 28% increase compared with the same period of 2020. At the onset of the COVID-19 pandemic, we initiated various cost containment initiatives in order to help mitigate the impacts on our business, which included reducing discretionary spending, employee furloughs and temporarily closing or limiting the presence of our workforce in our facilities. As a result, the increase in Selling, general and administrative expense in the current period reflects the gradual return to our operational spending levels prior to the COVID-19 pandemic. In addition, higher compensation costs, restructuring charges and unfavorable foreign currency movements along with transaction costs associated with the planned divestiture of our Chubb business further contributed to the year-over-year increase . Costs associated with the Separation were $3 million during the three months ended June 30, 2021 compared with $23 million for the same period in 2020.

[0001783180-21-000050:mdna:37]
Research and development costs relate to new product development and new technology innovation. Due to the variable nature of program development schedules, year-over-year spending levels can fluctuate. In addition, we continue to invest to prepare for future energy efficiency and refrigerant regulation changes as well as digital controls technologies.

[0001783180-21-000050:mdna:38]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the three months ended June 30, 2021, Equity method investment net earnings were $87 million, a 53% increase compared with the same period of 2020. The increase was primarily related to higher earnings in HVAC joint ventures in North America and Asia as end-markets improved compared with the prior period. These amounts were partially offset by the reduction in earnings resulting from the sale of our investment in Beijer REF AB in 2020.

[0001783180-21-000050:mdna:39]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. The year-over-year change of $40 million for the three months ended June 30, 2021 is primarily driven by higher gains recognized on hedging activities, the absence of an unfavorable impact of a change in the estimate of certain long-term liabilities and the unfavorable impact of a product recall matter in 2020.

[0001783180-21-000050:mdna:40]
[same as prior period, unchanged from 0001783180-21-000032:mdna:74]

[0001783180-21-000050:mdna:41]
[same as prior period, unchanged from 0001783180-21-000032:mdna:41]

[0001783180-21-000050:mdna:42]
For the three months ended June 30, 2021, Non-operating income (expenses), net was $52 million, a 22% increase compared with the same period of 2020. The components were as follows:

[0001783180-21-000050:mdna:43]
|  |  | For the Three Months Ended June 30, |  |  |
| (In millions) |  | 2021 |  | 2020 |  |  |  |  |
| Non-service pension (expense) benefit |  | $ | 19 |  |  | $ | 14 |  |  |  |  |  |
| Interest expense |  | $ | (75) |  |  | $ | (85) |  |  |  |  |  |
| Interest income |  | 4 |  |  | 4 |  |  |  |  |  |
| Interest (expense) income, net |  | $ | (71) |  |  | $ | (81) |  |  |  |  |  |
| Non-operating income (expenses), net |  | $ | (52) |  |  | $ | (67) |  |  |  |  |  |

[0001783180-21-000050:mdna:44]
Non-operating income (expenses), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the three months ended June 30, 2021, Interest expense was $75 million, a 12% decrease compared with the same period in 2020. The decrease was primarily driven by the repayment of our $1.75 billion Term Loan Credit Facility in 2020 and the prepayment of the $500 million 1.923% Notes in February 2021.

[0001783180-21-000050:mdna:45]
[same as prior period, unchanged from 0001783180-21-000032:mdna:46]

[0001783180-21-000050:mdna:46]
|  |  | For the Three Months Ended June 30, |  |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |  |  |  |
| Effective tax rate |  | 32.0 | % |  | 28.2 | % |  |  |  |  |  |  |  |

[0001783180-21-000050:mdna:47]
The increase in the effective tax rate for the three months ended June 30, 2021 compared with the same period in 2020 is primarily due to a $43 million deferred tax charge as a result of an enacted tax rate increase from 19% to 25% in the United Kingdom.

[0001783180-21-000050:mdna:48]
Six Months Ended June 30, 2021 Compared with the Six Months Ended June 30, 2020

[0001783180-21-000050:mdna:49]
|  |  | For the Six Months Ended June 30, |  |  |  |  |  |  |
| (In millions) |  | 2021 |  | 2020 |  | Period Change |  | % Change |  |  |  |  |  |  |
| Net sales |  | $ | 10,139 |  |  | $ | 7,860 |  |  | $ | 2,279 |  |  | 29 | % |  |  |  |  |  |  |
| Cost of products and services sold |  | (7,126) |  |  | (5,597) |  |  | (1,529) |  |  | 27 | % |  |  |  |  |  |  |
| Gross margin |  | 3,013 |  |  | 2,263 |  |  | 750 |  |  | 33 | % |  |  |  |  |  |  |
| Operating expenses |  | (1,659) |  |  | (1,506) |  |  | (153) |  |  | 10 | % |  |  |  |  |  |  |
| Operating profit |  | 1,354 |  |  | 757 |  |  | 597 |  |  | 79 | % |  |  |  |  |  |  |
| Non-operating income (expenses), net |  | (127) |  |  | (87) |  |  | (40) |  |  | 46 | % |  |  |  |  |  |  |
| Income from operations before income taxes |  | 1,227 |  |  | 670 |  |  | 557 |  |  | 83 | % |  |  |  |  |  |  |
| Income tax expense |  | (338) |  |  | (299) |  |  | (39) |  |  | 13 | % |  |  |  |  |  |  |
| Net income from operations |  | 889 |  |  | 371 |  |  | 518 |  |  | 140 | % |  |  |  |  |  |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 18 |  |  | 14 |  |  | 4 |  |  | 29 | % |  |  |  |  |  |  |
| Net income attributable to common shareowners |  | $ | 871 |  |  | $ | 357 |  |  | $ | 514 |  |  | 144 | % |  |  |  |  |  |  |

[0001783180-21-000050:mdna:50]
Net Sales

[0001783180-21-000050:mdna:51]
For the six months ended June 30, 2021, Net sales were $10.1 billion, a 29% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000050:mdna:52]
|  |  |  |  | For the Six Months Ended June 30, 2021 |  |  |  |  |
| Organic |  |  |  | 24 | % |  |  |  |  |
| Foreign currency translation |  |  |  | 5 | % |  |  |  |  |
| Total % change |  |  |  | 29 | % |  |  |  |  |

[0001783180-21-000050:mdna:53]
As the global economy continues to recover from the impact of the COVID-19 pandemic, we continue to see improvement across our global business. During the six months ended June 30, 2021, higher volume in each of our segments increased organic sales by 24% compared with the same period in 2020. The organic increase was primarily driven by our HVAC segment with continued strong results for North America residential and light commercial business and improved global end-markets in our Commercial HVAC business. Strong results in both our Refrigeration and Fire & Security segments were driven by improved global end-markets compared with the prior period. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-21-000050:mdna:54]
Gross Margin

[0001783180-21-000050:mdna:55]
For the six months ended June 30, 2021, gross margin was $3.0 billion, a 33% increase compared with the same period of 2020. The components were as follows:

[0001783180-21-000050:mdna:56]
|  |  |  |  | For the Six Months Ended June 30, |  |  |  |  |
| (In millions) |  |  |  |  |  | 2021 |  | 2020 |  |  |  |  |
| Net sales |  |  |  |  |  | $ | 10,139 |  |  | $ | 7,860 |  |  |  |  |  |
| Cost of products and services sold |  |  |  |  |  | (7,126) |  |  | (5,597) |  |  |  |  |  |
| Gross margin |  |  |  |  |  | $ | 3,013 |  |  | $ | 2,263 |  |  |  |  |  |
| Percentage of net sales |  |  |  |  |  | 29.7 | % |  | 28.8 | % |  |  |  |  |

[0001783180-21-000050:mdna:57]
The increase in gross margin for the six months ended June 30, 2021 was primarily driven by strong operational performance and continued improvement in the global economic climate during the current period. Higher volume in each of our segments outpaced operational costs as we continued to focus on Carrier 700 cost containment actions. These improvements were partially offset by the rising cost for commodities and components used in our products, certain supply chain inefficiencies and freight costs. As a result, gross margin as a percentage of Net sales increased by 90 basis points compared with the same period of 2020.

[0001783180-21-000050:mdna:58]
Operating Expenses

[0001783180-21-000050:mdna:59]
For the six months ended June 30, 2021, operating expenses, including Equity method investment net earnings, were $1.7 billion, a 10% increase compared with the same period in 2020. The components were as follows:

[0001783180-21-000050:mdna:60]
|  |  |  |  | For the Six Months Ended June 30, |  |  |  |  |
| (In millions) |  |  |  |  |  | 2021 |  | 2020 |  |  |  |  |
| Selling, general and administrative |  |  |  |  |  | $ | (1,556) |  |  | $ | (1,329) |  |  |  |  |  |
| Research and development |  |  |  |  |  | (246) |  |  | (192) |  |  |  |  |  |
| Equity method investment net earnings |  |  |  |  |  | 125 |  |  | 86 |  |  |  |  |  |
| Other income (expense), net |  |  |  |  |  | 18 |  |  | (71) |  |  |  |  |  |
| Total operating expenses |  |  |  |  |  | $ | (1,659) |  |  | $ | (1,506) |  |  |  |  |  |
| Percentage of net sales |  |  |  |  |  | 16.4 | % |  | 19.2 | % |  |  |  |  |

[0001783180-21-000050:mdna:61]
31

[0001783180-21-000050:mdna:62]
For the six months ended June 30, 2021, Selling, general and administrative expenses were $1.6 billion, a 17% increase compared with the same period of 2020. At the onset of the COVID-19 pandemic, we initiated various cost containment initiatives in order to help mitigate the impacts on our business, which included reducing discretionary spending, employee furloughs and temporarily closing or limiting the presence of our workforce in our facilities. As a result, the increase in Selling, general and administrative expense in the current period reflects the gradual return to our operational spending levels prior to the COVID-19 pandemic. In addition, higher compensation costs and restructuring charges in the current period along with transaction costs associated with the planned divestiture of our Chubb business further contributed to the year-over-year increase. Costs associated with the Separation were $19 million during the six months ended June 30, 2021 compared with $68 million for the same period in 2020.

[0001783180-21-000050:mdna:63]
Research and development costs relate to new product development and new technology innovation. Due to the variable nature of program development schedules, year-over-year spending levels can fluctuate. In addition, we continue to invest to prepare for future energy efficiency and refrigerant regulation changes as well as digital controls technologies.

[0001783180-21-000050:mdna:64]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the six months ended June 30, 2021, Equity method investment net earnings were $125 million, a 45% increase compared with the same period of 2020. The increase was primarily related to higher earnings in HVAC joint ventures in Asia, the Middle East and North America as end-markets improved compared with the prior period. These amounts were partially offset by a change in the estimated cost of a product recall matter and the reduction in earnings resulting from the sale of our investment in Beijer REF AB in 2020.

[0001783180-21-000050:mdna:65]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. The year-over-year change of $89 million for the six months ended June 30, 2021 is primarily driven by the absence of an other-than-temporary impairment charge of $71 million on a minority-owned joint venture investment in 2020. In addition, higher gains on hedging activities were partially offset by higher deferred compensation costs in the current period.

[0001783180-21-000050:mdna:66]
Non-Operating Income (Expenses), net

[0001783180-21-000050:mdna:67]
For the six months ended June 30, 2021, Non-operating income (expenses), net was $127 million, a 46% decrease compared with the same period of 2020. The components were as follows:

[0001783180-21-000050:mdna:68]
|  |  |  |  | For the Six Months Ended June 30, |
| (In millions) |  |  |  |  |  | 2021 |  | 2020 |
| Non-service pension (expense) benefit |  |  |  |  |  | $ | 37 |  |  | $ | 31 |  |
| Interest expense |  |  |  |  |  | $ | (171) |  |  | $ | (123) |  |
| Interest income |  |  |  |  |  | 7 |  |  | 5 |  |
| Interest (expense) income, net |  |  |  |  |  | $ | (164) |  |  | $ | (118) |  |
| Non-operating income (expenses), net |  |  |  |  |  | $ | (127) |  |  | $ | (87) |  |

[0001783180-21-000050:mdna:69]
Non-operating income (expenses), net includes the results from activities other than normal business operations such as interest expense, interest income and the non-service components of pension and post-retirement obligations. For the six months ended June 30, 2021 Interest expense was $171 million, a 39% increase compared with the same period in 2020. In connection with the Separation and the Distribution, we issued $11.0 billion of long-term debt in February 2020. As a result, interest expense during the six months ended June 30, 2020 only included interest expense incurred on such debt after the issuance date. In addition, during the six months ended June 30, 2021, we incurred a make-whole premium of $17 million and wrote-off $2 million of unamortized deferred financing costs as a result of the redemption of our $500 million 1.923% Notes originally due in February 2023.

[0001783180-21-000050:mdna:70]
Income Taxes

[0001783180-21-000050:mdna:71]
32

[0001783180-21-000050:mdna:72]
|  |  |  | For the Six Months Ended June 30, |  |  |
|  |  |  |  |  | 2021 |  | 2020 |  |  |  |  |
| Effective tax rate |  |  |  |  | 27.5 | % |  | 44.6 | % |  |  |  |  |

[0001783180-21-000050:mdna:73]
The decrease in the effective tax rate for the six months ended June 30, 2021 compared with the same period in 2020 is primarily due to the absence of a prior year charge of $51 million related to a valuation allowance recorded against a United Kingdom tax loss and credit carry forward and a $46 million charge resulting from our decision to no longer permanently reinvest certain pre-2018 unremitted non-U.S. earnings. The six months ended June 30, 2021 included a $43 million deferred tax charge as a result of an enacted tax rate increase from 19% to 25% in the United Kingdom, partially offset by the recognition of a favorable tax adjustment of $21 million resulting from a re-organization of our German subsidiaries.

[0001783180-21-000050:mdna:74]
[same as prior period, unchanged from 0001783180-21-000032:mdna:50]

[0001783180-21-000050:mdna:75]
[same as prior period, unchanged from 0001783180-21-000032:mdna:52]

[0001783180-21-000050:mdna:76]
[same as prior period, unchanged from 0001783180-21-000032:mdna:53]

[0001783180-21-000050:mdna:77]
[same as prior period, unchanged from 0001783180-21-000032:mdna:54]

[0001783180-21-000050:mdna:78]
[same as prior period, unchanged from 0001783180-21-000032:mdna:55]

[0001783180-21-000050:mdna:79]
We determine our segments based on how our Chief Executive Officer, who is the Chief Operating Decision Maker (the "CODM"), allocates resources, assesses performance and makes operational decisions. The CODM allocates resources and evaluates the financial performance of each of our segments based on Net sales and Operating profit. Adjustments to reconcile segment reporting to the consolidated results are included in Note 16 - Segment Financial Data.

[0001783180-21-000050:mdna:80]
Three Months Ended June 30, 2021 Compared with Three Months Ended June 30, 2020

[0001783180-21-000050:mdna:81]
Summary performance for each of our segments for the three months ended June 30, 2021 and 2020 is as follows:

[0001783180-21-000050:mdna:82]
|  |  | Net Sales |  | Operating Profit |  | Operating Profit Margin |
|  |  | For the Three Months Ended June 30, |  | For the Three Months Ended June 30, |  | For the Three Months Ended June 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC |  | $ | 3,120 |  |  | $ | 2,291 |  |  | $ | 573 |  |  | $ | 358 |  |  | 18.4 | % |  | 15.6 | % |
| Refrigeration |  | 1,021 |  |  | 700 |  |  | 123 |  |  | 61 |  |  | 12.0 | % |  | 8.7 | % |
| Fire & Security |  | 1,403 |  |  | 1,057 |  |  | 148 |  |  | 106 |  |  | 10.5 | % |  | 10.0 | % |
| Total segment |  | $ | 5,544 |  |  | $ | 4,048 |  |  | $ | 844 |  |  | $ | 525 |  |  | 15.2 | % |  | 13.0 | % |

[0001783180-21-000050:mdna:83]
[same as prior period, unchanged from 0001783180-21-000032:mdna:59]

[0001783180-21-000050:mdna:84]
For the three months ended June 30, 2021, Net sales in our HVAC segment were $3.1 billion, a 36% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000050:mdna:85]
|  |  | Net Sales |
| Organic |  | 32 | % |
| Foreign currency translation |  | 3 | % |
| Acquisitions and divestitures, net |  | 1 | % |
| Total % change in Net sales |  | 36 | % |

[0001783180-21-000050:mdna:86]
33

[0001783180-21-000050:mdna:87]
The organic increase in Net sales of 32% was driven by strong results across each of the segment's businesses. Increased sales in our North America residential and light commercial HVAC business (40%) were driven by new construction, the ongoing stay-at-home workforce and higher distributor stocking levels. Increased sales in our Commercial HVAC business (22%) benefited from the gradual improvement in the global economic environment as our end markets continue to improve from the prior year impacts of the COVID-19 pandemic. Volume growth in North America, Europe and Asia were the primary drivers of improved results during the period.

[0001783180-21-000050:mdna:88]
In addition, the Commercial HVAC business completed the acquisition of Giwee on June 1, 2021. Giwee is a China-based manufacturer of HVAC products, offering a portfolio of products including variable refrigerant flow, modular chillers and light commercial air conditioners. Giwee has been included in our Unaudited Condensed Consolidated Financial Statements since the date of acquisition. The transaction added 1% to Net sales during the three months ended June 30, 2021. Refer to Note 15 - Business Acquisitions and Dispositions for additional information.

[0001783180-21-000050:mdna:89]
For the three months ended June 30, 2021, Operating profit in our HVAC segment was $573 million, a 60% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000050:mdna:90]
|  |  | Operating Profit |
| Operational |  | 61 | % |
| Foreign currency translation |  | 2 | % |
| Acquisitions and divestitures, net |  | (1) | % |
| Restructuring |  | (2) | % |
| Total % change in Operating profit |  | 60 | % |

[0001783180-21-000050:mdna:91]
The increase in operational profit of 61% was primarily attributable to higher sales volumes in each of the segment's businesses compared with the prior period. In addition, favorable product mix, productivity initiatives and higher income from equity method investments benefited operational profit. These amounts were partially offset by the rising cost for commodities and components used in our products and higher freight costs. Higher selling, general and administrative costs and research and development further impacted operational profit as our businesses return to normal spending levels as compared with the prior period. The segment was also impacted by transaction costs, inventory step-up and backlog amortization associated with the acquisition of Giwee.

[0001783180-21-000050:mdna:92]
[same as prior period, unchanged from 0001783180-21-000032:mdna:68]

[0001783180-21-000050:mdna:93]
For the three months ended June 30, 2021, Net sales in our Refrigeration segment were $1.0 billion, a 46% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000050:mdna:94]
|  |  | Net Sales |
| Organic |  | 38 | % |
| Foreign currency translation |  | 8 | % |
| Total % change in Net sales |  | 46 | % |

[0001783180-21-000050:mdna:95]
The organic increase in Net sales of 38% was driven by strong results across each of the segment's businesses reflecting the gradual improvement in the global economic environment as our end markets significantly improved from the prior year impacts of the COVID-19 pandemic. Transport refrigeration sales (42%) benefited from the continued recovery associated with the cyclical decline that began in late 2019 as well as a rebound in the demand for global transportation. Commercial refrigeration sales (30%) also increased due to a rebound in demand.

[0001783180-21-000050:mdna:96]
For the three months ended June 30, 2021, Operating profit in our Refrigeration segment was $123 million, a 102% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000050:mdna:97]
34

[0001783180-21-000050:mdna:98]
|  |  | Operating Profit |
| Operational |  | 87 | % |
| Foreign currency translation |  | 12 | % |
| Other |  | 3 | % |
| Total % change in Operating profit |  | 102 | % |

[0001783180-21-000050:mdna:99]
The increase in operational profit of 87% was primarily attributable to higher sales volumes compared with the prior period which was impacted by the COVID-19 pandemic. In addition, favorable productivity initiatives benefited factory costs. These amounts were partially offset by the rising cost for commodities and components used in our products and logistics costs. Higher selling, general and administrative costs and research and development activities further impacted operational profit as our businesses return to normal spending levels compared with the prior period.

[0001783180-21-000050:mdna:100]
[same as prior period, unchanged from 0001783180-21-000032:mdna:76]

[0001783180-21-000050:mdna:101]
For the three months ended June 30, 2021, Net sales in our Fire & Security segment were $1.4 billion, a 33% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000050:mdna:102]
|  |  | Net Sales |
| Organic |  | 25 | % |
| Foreign currency translation |  | 8 | % |
| Total % change in Net sales |  | 33 | % |

[0001783180-21-000050:mdna:103]
The organic increase in Net sales of 25% was driven by strong results across each of our businesses reflecting the gradual improvement in the global economic environment as our end markets improved from the prior year impacts of the COVID-19 pandemic. Field service sales (27%) benefited from improved end-markets impacted by COVID-19 in the prior period. All regions benefited from increased volumes compared with the prior period. An increase in product sales (24%) was primarily driven by stronger residential and commercial sales in the Americas. In addition, volume increases in Europe and Asia benefited the period as lockdowns continue to be lifted.

[0001783180-21-000050:mdna:104]
For the three months ended June 30, 2021, Operating profit in our Fire & Security segment was $148 million, a 40% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000050:mdna:105]
|  |  | Operating Profit |
| Operational |  | 53 | % |
| Foreign currency translation |  | 8 | % |
| Restructuring |  | (3) | % |
| Other |  | (18) | % |
| Total % change in Operating profit |  | 40 | % |

[0001783180-21-000050:mdna:106]
The increase in operational profit of 53% was primarily attributable to higher sales volumes compared with the prior period which was heavily impacted by the COVID-19 pandemic. These amounts were partially offset by the rising cost for commodities and components used in our products, certain supply chain inefficiencies and freight costs. In addition, higher selling, general and administrative costs and research and development further impacted operational profit as our businesses return to normal spending levels as compared with the prior period. Amounts reported in Other represent transaction costs associated with the planned divestiture of our Chubb business as well as the absence of a favorable adjustment related to a product recall matter in the prior period.

[0001783180-21-000050:mdna:107]
35

[0001783180-21-000050:mdna:108]
Six Months Ended June 30, 2021 Compared with Six Months Ended June 30, 2020

[0001783180-21-000050:mdna:109]
| Summary performance for each of our segments for the six months ended June 30, 2021 and 2020 is as follows: |
|  | Net Sales |  | Operating Profit |  | Operating Profit Margin |
| (dollars in millions) | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC | $ | 5,606 |  |  | $ | 4,250 |  |  | $ | 938 |  |  | $ | 525 |  |  | 16.7 | % |  | 12.4 | % |
| Refrigeration | 2,026 |  |  | 1,508 |  |  | 250 |  |  | 160 |  |  | 12.3 | % |  | 10.6 | % |
| Fire & Security | 2,707 |  |  | 2,263 |  |  | 298 |  |  | 226 |  |  | 11.0 | % |  | 10.0 | % |
| Total segment | $ | 10,339 |  |  | $ | 8,021 |  |  | $ | 1,486 |  |  | $ | 911 |  |  | 14.4 | % |  | 11.4 | % |

[0001783180-21-000050:mdna:110]
HVAC Segment

[0001783180-21-000050:mdna:111]
For the six months ended June 30, 2021, Net sales in our HVAC segment were $5.6 billion, a 32% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000050:mdna:112]
|  |  | Net Sales |
| Organic |  | 28 | % |
| Foreign currency translation |  | 3 | % |
| Acquisitions and divestitures, net |  | 1 | % |
| Total % change in Net sales |  | 32 | % |

[0001783180-21-000050:mdna:113]
The organic increase in Net sales of 28% was driven by strong results across each of the segment's businesses. Increased sales in our North America residential and light commercial HVAC business (37%) were driven by new construction, the ongoing stay-at-home workforce and higher distributor stocking levels. Increased sales in our Commercial HVAC business (19%) benefited from the gradual improvement in the global economic environment as our end markets continue to improve from the prior year impacts of the COVID-19 pandemic. Volume growth in Europe and Asia were the primary drivers of improved results during the period.

[0001783180-21-000050:mdna:114]
For the six months ended June 30, 2021, Operating profit in our HVAC segment was $938 million, a 79% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000050:mdna:115]
|  |  |  | Operating Profit |
| Operational |  |  | 69 | % |
| Foreign currency translation |  |  | 2 | % |
| Acquisitions and divestitures, net |  |  | (2) | % |
| Restructuring |  |  | (2) | % |
| Other |  |  | 12 | % |
| Total % change |  |  | 79 | % |

[0001783180-21-000050:mdna:116]
The operational profit increase of 69% was primarily attributable to higher sales volumes in each of the segment's businesses compared with the prior period. In addition, favorable product mix, productivity initiatives and higher income from equity method investments benefited operational profit. These amounts were partially offset by higher selling, general and administrative costs and research and development as our businesses return to normal spending levels as compared with the prior period.

[0001783180-21-000050:mdna:117]
The increase in Other of 12% primarily reflects the absence of a prior period non-cash, other-than-temporary impairment charge of $71 million on a minority-owned joint venture investment due to a reduction in sales and earnings that were driven by a deterioration in the oil and gas industry (the joint venture's primary market) and the impact of the COVID-19 pandemic. In addition, amounts reported in Other reflects the absence of a gain on sale of an interest in a joint venture in the prior period.

[0001783180-21-000050:mdna:118]
36

[0001783180-21-000050:mdna:119]
Refrigeration Segment

[0001783180-21-000050:mdna:120]
For the six months ended June 30, 2021, Net sales in our Refrigeration segment were $2.0 billion, a 34% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000050:mdna:121]
|  |  | Net Sales |
| Organic |  | 28 | % |
| Foreign currency translation |  | 6 | % |
| Total % change in Net sales |  | 34 | % |

[0001783180-21-000050:mdna:122]
The organic increase in Net sales of 28% was driven by strong results across each of the segment's businesses reflecting the gradual improvement in the global economic environment as our end markets significantly improved from the prior year impacts of the COVID-19 pandemic. Transport refrigeration sales (32%) benefited from the continued recovery associated with the cyclical decline that began in late 2019 as well as a rebound in the demand for global transportation and COVID-19 vaccine-related cargo monitoring. Commercial refrigeration sales (21%) also increased due to a rebound in demand.

[0001783180-21-000050:mdna:123]
For the six months ended June 30, 2021, Operating profit in our Refrigeration segment was $250 million, a 56% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000050:mdna:124]
|  |  |  | Operating Profit |
| Operational |  |  | 49 | % |
| Foreign currency translation |  |  | 7 | % |
| Restructuring |  |  | (1) | % |
| Other |  |  | 1 | % |
| Total % change |  |  | 56 | % |

[0001783180-21-000050:mdna:125]
The increase in operational profit of 49% was primarily attributable to higher sales volumes compared with the prior period which was heavily impacted by the COVID-19 pandemic. In addition, favorable productivity initiatives benefited material and factory costs. These amounts were partially offset by inflation and increased logistics costs. Higher selling, general and administrative costs and research and development further impacted operational profit as our businesses return to normal spending levels as compared with the prior period.

[0001783180-21-000050:mdna:126]
Fire & Security Segment

[0001783180-21-000050:mdna:127]
For the six months ended June 30, 2021, Net sales in our Fire & Security segment were $2.7 billion, a 20% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000050:mdna:128]
|  |  | Net Sales |
| Organic |  | 13 | % |
| Foreign currency translation |  | 7 | % |
| Total % change in Net sales |  | 20 | % |

[0001783180-21-000050:mdna:129]
The organic increase in Net sales of 13% was driven by strong results across each of the segment's businesses reflecting the gradual improvement in the global economic environment as our end markets improved from the prior year impacts of the COVID-19 pandemic. Field service sales (14%) benefited from improved end-markets in regions that were previously impacted by COVID-19, including Europe and Asia. An increase in product sales (13%) was primarily driven by improvements in the Americas, Asia and Europe which were impacted by shutdowns related to COVID-19 in the prior period.

[0001783180-21-000050:mdna:130]
37

[0001783180-21-000050:mdna:131]
For the six months ended June 30, 2021, Operating profit in our Fire & Security segment was $298 million, a 32% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000050:mdna:132]
|  |  |  | Operating Profit |
| Operational |  |  | 40 | % |
| Foreign currency translation |  |  | 6 | % |
| Restructuring |  |  | (5) | % |
| Other |  |  | (9) | % |
| Total % change |  |  | 32 | % |

[0001783180-21-000050:mdna:133]
The increase in operational profit of 40% was primarily attributable to higher sales volumes and favorable mix compared with the prior period which was heavily impacted by the COVID-19 pandemic. These operational increases were partially offset by unfavorable component costs and higher freight. In addition, higher selling, general and administrative costs and research and development further impacted operational profit as our businesses return to normal spending levels as compared with the prior period. Amounts reported in Other represent transaction costs associated with the planned divestiture of our Chubb business as well as the absence of a favorable adjustment related to a product recall matter in the prior period.

[0001783180-21-000050:mdna:134]
[same as prior period, unchanged from 0001783180-21-000032:mdna:90]

[0001783180-21-000050:mdna:135]
We assess liquidity in terms of our ability to generate adequate amounts of cash necessary to fund our current and future cash requirements to support our business and strategic initiatives. In doing so, we review and analyze our cash on hand, working capital, debt service requirements and capital expenditures. We rely on operating cash flows as our primary source of liquidity. In addition, we have access to other sources of capital to finance our strategic initiatives and fund growth.

[0001783180-21-000050:mdna:136]
As of June 30, 2021, we had cash and cash equivalents of $2.6 billion, of which approximately 38% was held by our foreign subsidiaries. We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which we can access funds held by foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection with contractual obligations related to acquisitions, divestitures or other legal obligations. As of June 30, 2021 and December 31, 2020, the amount of such restricted cash was approximately $34 million and $4 million, respectively.

[0001783180-21-000050:mdna:137]
We maintain a $2.0 billion unsecured, unsubordinated commercial paper program which can be used for general corporate purposes, including working capital and potential acquisitions. In addition, we maintain our $2.0 billion Revolving Credit Facility that matures on April 3, 2025 which supports our commercial paper borrowing program and cash requirements. This Revolving Credit Facility has a commitment fee of 0.125% that is charged on unused commitments. Borrowings are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable rate based on LIBOR plus a ratings-based margin (or customary LIBOR replacement provisions), which was 125 basis points as of June 30, 2021. As of June 30, 2021, we had no borrowings outstanding under our commercial paper program and our Revolving Credit Facility.

[0001783180-21-000050:mdna:138]
We continue to actively manage and strengthen our business portfolio to meet the current and future needs of our customers. This is accomplished through research and development activities with a focus on new product development and new technology innovation as well as sustaining activities with a focus on improving existing products and reducing production costs. We also pursue potential acquisitions to compliment existing products and services to enhance our product portfolio. In addition, we routinely conduct discussions, evaluate targets and enter into agreements regarding possible acquisitions, divestitures, joint ventures and equity investments to manage our business portfolio.

[0001783180-21-000050:mdna:139]
[same as prior period, unchanged from 0001783180-21-000032:mdna:94]

[0001783180-21-000050:mdna:140]
38

[0001783180-21-000050:mdna:141]
The Revolving Credit Facility and the indentures for the long-term notes contain affirmative and negative covenants customary for financings of these types, which among other things, limit our ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. As of June 30, 2021, we were in compliance with the covenants under the agreements governing our outstanding indebtedness.

[0001783180-21-000050:mdna:142]
The following table presents our credit ratings and outlook as of June 30, 2021:

[0001783180-21-000050:mdna:143]
| Rating Agency |  | Long-term Rating (1) |  | Short-term Rating |  | Outlook (2) |
| Standards & Poor's ("S&P") |  | BBB |  | A2 |  | Stable |
| Moody's Investor Services, Inc. ("Moody's") |  | Baa3 |  | P3 |  | Stable |
| Fitch Ratings ("Fitch") |  | BBB- |  | F3 |  | Stable |

[0001783180-21-000050:mdna:144]
(1) The long-term rating for S&P was affirmed on May 14, 2021, and for Moody's on June 16, 2020. Fitch's long-term rating was affirmed on June 3, 2021.

[0001783180-21-000050:mdna:145]
(2) S&P revised its outlook to stable from negative on May 14, 2021.

[0001783180-21-000050:mdna:146]
[same as prior period, unchanged from 0001783180-21-000032:mdna:99]

[0001783180-21-000050:mdna:147]
| (In millions, except percentages) |  | June 30,2021 |  | December 31,2020 |
| Cash and cash equivalents |  | $ | 2,630 |  |  | $ | 3,115 |  |
| Total debt |  | $ | 9,725 |  |  | $ | 10,227 |  |
| Total equity |  | $ | 7,120 |  |  | $ | 6,578 |  |
| Net debt (total debt less cash and cash equivalents) |  | $ | 7,095 |  |  | $ | 7,112 |  |
| Total capitalization (total debt plus total equity) |  | $ | 16,845 |  |  | $ | 16,805 |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | $ | 14,215 |  |  | $ | 13,690 |  |
| Total debt to total capitalization |  | 58 | % |  | 61 | % |
| Net debt to net capitalization |  | 50 | % |  | 52 | % |

[0001783180-21-000050:mdna:148]
Our short-term obligations primarily consist of current maturities of long-term debt. Our long-term obligations primarily consist of long-term notes with maturity dates ranging between 2025 and 2050. Interest payments related to indebtedness are expected to approximate $282 million per year, reflecting an approximate weighted-average interest rate of 2.89%. Any borrowings from the Revolving Credit Facility are subject to variable interest rates. See Note 5 – Borrowings and Lines of Credit in the Notes to the Unaudited Condensed Consolidated Financial Statements for additional information regarding the terms of our long-term debt obligations.

[0001783180-21-000050:mdna:149]
During the six months ended June 30, 2021, we acquired consolidated and minority-owned businesses, including a 70% controlling stake in Giwee. We plan to complete the acquisition of the remaining 30% stake in Giwee in 2021. The aggregate cash paid for acquisitions, net of cash acquired, totaled $167 million and was funded through cash on hand. See Note 15 - Business Acquisitions and Dispositions for additional information.

[0001783180-21-000050:mdna:150]
On February 4, 2021, our Board of Directors approved a stock repurchase program authorizing the repurchase of up to $350 million of our outstanding common stock. Share repurchases may take place from time to time subject to market conditions and at our discretion in the open market or through one or more other public or private transactions, subject to compliance with our obligations under the TMA and our Revolving Credit Facility. During the three and six months ended June 30, 2021, we repurchased 2.1 million and 3.1 million shares of our common stock, respectively, for an aggregate purchase price of $130 million for the six months ended June 30, 2021, which are held in Treasury stock as of June 30, 2021 in the Unaudited Condensed Consolidated Balance Sheet.

[0001783180-21-000050:mdna:151]
We paid dividends on common stock of $0.12 per share during the three months ended June 30, 2021, totaling $104 million. On June 9, 2021, the Board of Directors declared a dividend of $0.12 per share of common stock payable on August 10, 2021 to shareowners of record at the close of business on June 24, 2021.

[0001783180-21-000050:mdna:152]
[same as prior period, unchanged from 0001783180-21-000032:mdna:104]

[0001783180-21-000050:mdna:153]
[same as prior period, unchanged from 0001783180-21-000032:mdna:105]

[0001783180-21-000050:mdna:154]
|  |  | Six Months Ended June 30, |
| (In millions) |  | 2021 |  | 2020 |
| Net cash flows provided by (used in): |  |  |  |  |
| Operating activities |  | $ | 745 |  |  | $ | 556 |  |
| Investing activities |  | (301) |  |  | (103) |  |
| Financing activities |  | (898) |  |  | 1,315 |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  | (2) |  |  | (17) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  | $ | (456) |  |  | $ | 1,751 |  |

[0001783180-21-000050:mdna:155]
Cash flows from operating activities primarily represent inflows and outflows associated with our operations. Primary activities include net income from operations adjusted for non-cash transactions, working capital changes and changes in other assets and liabilities. The year-over-year increase in net cash provided by operating activities was primarily driven by higher net income from operations in the current period and improved working capital balances. Higher outstanding accounts payable balances  driven by the timing of raw material purchases and vendor payments more than offset the seasonal increase in inventory, higher accounts receivable balances, increase in tax payments and interest payments.

[0001783180-21-000050:mdna:156]
Cash flows from investing activities primarily represent inflows and outflows associated with long-term assets. Primary activities include capital expenditures, acquisitions, divestitures and proceeds from the sale of fixed assets. During the six months ended June 30, 2021, net cash used in investing activities was $301 million. The primary driver of the outflow related to the acquisition of several businesses and a joint venture, which totaled $167 million, net of cash acquired and $132 million of capital expenditures. During the six months ended June 30, 2020, net cash used by investing activities was $103 million with the primary drivers of the outflow relating to capital expenditures of $94 million and the settlement of derivative contracts of $23 million.

[0001783180-21-000050:mdna:157]
Cash flows from financing activities primarily represent inflows and outflows associated with equity or borrowings. Primary activities include debt transactions, paying dividends to shareowners and the repurchase of our common stock. During the six months ended June 30, 2021, net cash used in financing activities was $898 million. The primary driver of the outflow related to the redemption of long-term Notes of $500 million. In addition, we paid $209 million in dividends to our common shareowners and paid $130 million to repurchase shares of our common stock. During the six months ended June 30, 2020, net cash provided by financing activities was $1.3 billion with the primary drivers of the increase relating to the issuance of $750 million of long-term debt and a $590 million cash contribution from UTC in connection with the Separation.

[0001783180-21-000050:mdna:158]
[same as prior period, unchanged from 0001783180-21-000032:mdna:110]

[0001783180-21-000050:mdna:159]
The section entitled "Management's Discussion and Analysis of Financial Condition and Results of Operations – Off-Balance Sheet Arrangements and Contractual Obligations" in our 2020 Form 10-K provided a table summarizing our contractual obligations and commercial commitments at the end of 2020. There have been no material changes for the three and six months ended June 30, 2021 to our off-balance sheet arrangements and contractual obligations disclosed in our 2020 Form 10-K.
