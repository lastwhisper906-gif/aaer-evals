# CARR notes — 0001783180-21-000050


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-21-000050:notes:1]
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation is a leading global provider of heating, ventilating, air conditioning ("HVAC"), refrigeration and fire and security solutions. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. In the opinion of management, the accompanying Unaudited Condensed Consolidated Financial Statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (the "SEC"). These Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for 2020 filed with the SEC on February 9, 2021 (the "2020 Form 10-K").

[0001783180-21-000050:notes:2]
On April 3, 2020 (the "Distribution Date"), United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of the Company into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In connection with the Separation, the Company issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020. On April 1, 2020 and April 2, 2020, the Company received cash contributions totaling $590 million from UTC related to the Separation.

[0001783180-21-000050:notes:3]
In connection with the Separation, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship among the Company, UTC and Otis following the Separation and the Distribution, including a transition services agreement ("TSA"), a tax matters agreement ("TMA"), an employee matters agreement and an intellectual property agreement that cover services such as information technology, tax, finance and human resources. In addition, the Company incurred separation-related costs including employee-related costs, costs to establish certain stand-alone functions, information technology systems, professional service fees and other costs associated with becoming an independent, publicly traded company. These costs are primarily recorded in Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations and totaled $3 million and $23 million for the three months ended June 30, 2021 and 2020, respectively. Costs for the six months ended June 30, 2021 and 2020 were $19 million and $68 million, respectively. The TSA expired on March 31, 2021.

[0001783180-21-000050:notes:4]
[same as prior period, unchanged from 0001783180-21-000032:notes:4]

[0001783180-21-000050:notes:5]
In early 2020, the World Health Organization declared the outbreak of a respiratory disease known as COVID-19 as a global pandemic. In response, many countries implemented containment and mitigation measures to combat the outbreak, which severely restricted the level of economic activity and caused a significant contraction in the global economy. As a result, the Company temporarily closed or reduced production at manufacturing facilities across the globe to ensure employee safety and instructed non-essential employees to work from home. In addition, the Company took several preemptive actions during 2020 to manage liquidity as demand for its products decreased. Despite the adverse impacts of the pandemic on the Company’s results beginning in the first quarter of 2020, manufacturing operations resumed and several restorative actions were completed during 2020, including the reinstatement of annual merit-based salary increases and continued investment to support the Company's core strategy.

[0001783180-21-000050:notes:6]
The Company continues to focus its efforts on preserving the health and safety of its employees and customers as well as maintaining the continuity of its operations. In addition, the Company continues to actively monitor its liquidity position and working capital needs and believes that its overall capital resources and liquidity position are adequate. The preparation of financial statements requires management to use judgments in making estimates and assumptions based on the relevant information available at the end of each period, which can have a significant effect on reported amounts. However, due to significant uncertainty surrounding the pandemic, management's judgments could change. While the Company's results of operations, cash flows and financial condition could be negatively impacted, the extent of any continuing impact cannot be estimated with certainty at this time.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-21-000050:notes:7]
BASIS OF PRESENTATION
The Unaudited Condensed Consolidated Financial Statements include all accounts of the Company and its wholly-owned and majority-owned subsidiaries in which it has control. All intra-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that the Company controls and consolidates.

[0001783180-21-000050:notes:8]
The Company's financial statements for the periods prior to the Separation and the Distribution are prepared on a "carve-out" basis and include all amounts directly attributable to the Company. Net cash transfers and other property transferred between UTC and the Company, including related party receivables and payables between the Company and other UTC affiliates, are presented as Net transfers to UTC. In addition, the financial statements include allocations of costs for administrative functions and services performed on behalf of the Company by centralized groups within UTC. All allocations and estimates in the Unaudited Condensed Consolidated Financial Statements are based on assumptions that management believes are reasonable. The Company's financial statements for the periods subsequent to April 3, 2020 are consolidated financial statements based on the reported results of Carrier as a stand-alone company.

[0001783180-21-000050:notes:9]
Recently Adopted Accounting Pronouncements

[0001783180-21-000050:notes:10]
[same as prior period, unchanged from 0001783180-21-000032:notes:10]

[0001783180-21-000050:notes:11]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes ("ASU 2019-12"), which simplifies certain aspects of income tax accounting guidance in ASC 740, Income Taxes ("ASC 740") reducing the complexity of its application while maintaining or improving the usefulness of the information required to be reported. The ASU eliminates certain exceptions from ASC 740 including: intra-period tax allocation, deferred tax liabilities related to outside basis differences and year-to-date loss in interim periods, among others. ASU 2019-12 was effective for periods beginning after December 15, 2020, including interim periods therein with early adoption permitted. The Company adopted this ASU on January 1, 2021 with no material impact on the Unaudited Condensed Consolidated Financial Statements.


## us-gaap:InventoryDisclosureTextBlock

[0001783180-21-000050:notes:12]
[same as prior period, unchanged from 0001783180-21-000032:notes:12]

[0001783180-21-000050:notes:13]
[same as prior period, unchanged from 0001783180-21-000032:notes:13]

[0001783180-21-000050:notes:14]
| (In millions) |  | June 30,2021 |  | December 31,2020 |
| Raw materials |  | $ | 478 |  |  | $ | 363 |  |
| Work-in-process |  | 190 |  |  | 143 |  |
| Finished goods |  | 1,217 |  |  | 1,123 |  |
| Inventories, net |  | $ | 1,885 |  |  | $ | 1,629 |  |

[0001783180-21-000050:notes:15]
The Company performs periodic assessments to determine the existence of excess and obsolete inventory and records necessary provisions to reduce such inventories to estimated realizable value. Raw materials, work-in-process and finished goods are net of valuation reserves of $189 million and $183 million as of June 30, 2021 and December 31, 2020, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-21-000050:notes:16]
GOODWILL AND INTANGIBLE ASSETS The Company records goodwill as the excess of the purchase price over the fair value of the net assets acquired in a business combination. Goodwill is tested and reviewed annually for impairment during the third quarter or whenever there is a material change in events or circumstances that indicates that the fair value of the reporting unit may be less than its carrying value.
The changes in the carrying amount of goodwill are as follows:

[0001783180-21-000050:notes:17]
| (In millions) |  |  | HVAC |  | Refrigeration |  | Fire & Security |  | Total |
| Balance as of December 31, 2020 |  |  | $ | 5,489 |  |  | $ | 1,251 |  |  | $ | 3,399 |  |  | $ | 10,139 |  |
| Goodwill resulting from business combinations | (1) |  | 175 |  |  | — |  |  | — |  |  | 175 |  |
| Foreign currency translation |  |  | (19) |  |  | (4) |  |  | (12) |  |  | (35) |  |
| Balance as of June 30, 2021 |  |  | $ | 5,645 |  |  | $ | 1,247 |  |  | $ | 3,387 |  |  | $ | 10,279 |  |

[0001783180-21-000050:notes:18]
(1) See Note 15 - Business Acquisitions and Dispositions for more information.

[0001783180-21-000050:notes:19]
Indefinite-lived intangible assets are tested and reviewed annually for impairment during the third quarter or whenever there is a material change in events or circumstances that indicates that the fair value of the asset may be less than the carrying amount of the asset. All other intangible assets with finite useful lives are amortized over their estimated useful lives.

[0001783180-21-000050:notes:20]
[same as prior period, unchanged from 0001783180-21-000032:notes:20]

[0001783180-21-000050:notes:21]
|  |  | June 30, 2021 |  | December 31, 2020 |
| (In millions) |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |  | Gross Amount |  | Accumulated Amortization |  | Net Amount |
| Amortized: |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 1,593 |  |  | $ | (1,302) |  |  | $ | 291 |  |  | $ | 1,558 |  |  | $ | (1,285) |  |  | $ | 273 |  |
| Patents and trademarks |  | 300 |  |  | (227) |  |  | 73 |  |  | 301 |  |  | (222) |  |  | 79 |  |
| Monitoring lines |  | 72 |  |  | (61) |  |  | 11 |  |  | 71 |  |  | (59) |  |  | 12 |  |
| Service portfolios and other |  | 683 |  |  | (550) |  |  | 133 |  |  | 644 |  |  | (542) |  |  | 102 |  |
|  |  | 2,648 |  |  | (2,140) |  |  | 508 |  |  | 2,574 |  |  | (2,108) |  |  | 466 |  |
| Unamortized: |  |  |  |  |  |  |  |  |  |  |  |  |
| Trademarks and other |  | 563 |  |  | — |  |  | 563 |  |  | 571 |  |  | — |  |  | 571 |  |
| Intangible assets, net |  | $ | 3,211 |  |  | $ | (2,140) |  |  | $ | 1,071 |  |  | $ | 3,145 |  |  | $ | (2,108) |  |  | $ | 1,037 |  |

[0001783180-21-000050:notes:22]
Amortization of intangible assets was $25 million and $25 million for the three months ended June 30, 2021 and 2020, respectively, and $49 million and $50 million for the six months ended June 30, 2021 and 2020, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001783180-21-000050:notes:23]
BORROWINGS AND LINES OF CREDIT 
Long-term debt consisted of the following:

[0001783180-21-000050:notes:24]
| (In millions, except percentages) |  |  |  | June 30,2021 |  | December 31,2020 |
| 1.923% Notes due February 15, 2023 |  |  |  | $ | — |  | (1) | $ | 500 |  |
| 2.242% Notes due February 15, 2025 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 1,250 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Total long-term Notes |  |  |  | 9,500 |  |  | 10,000 |  |
| Other debt (including project financing obligations and finance leases) |  |  |  | 300 |  |  | 308 |  |
| Discounts and debt issuance costs |  |  |  | (75) |  |  | (81) |  |
| Total debt |  |  |  | 9,725 |  |  | 10,227 |  |
| Less: current portion of long-term debt |  |  |  | 125 |  |  | 191 |  |
| Long-term debt, net of current portion |  |  |  | $ | 9,600 |  |  | $ | 10,036 |  |

[0001783180-21-000050:notes:25]
(1) In February 2021, the Company prepaid the 1.923% Notes due in February 2023 and incurred a $17 million make-whole premium upon prepayment and wrote-off $2 million of the remaining unamortized deferred financing costs.

[0001783180-21-000050:notes:26]
Revolving Credit Facility

[0001783180-21-000050:notes:27]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements of the Company. A commitment fee of 0.125% is charged on unused commitments. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate based on LIBOR plus a ratings-based margin, which was 125 basis points as of June 30, 2021. As of June 30, 2021, there were no borrowings outstanding under the Revolving Credit Facility.

[0001783180-21-000050:notes:28]
Commercial Paper Program

[0001783180-21-000050:notes:29]
As of June 30, 2021, the Company had a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of June 30, 2021, there were no borrowings outstanding under the commercial paper program.

[0001783180-21-000050:notes:30]
Project Financing Arrangements

[0001783180-21-000050:notes:31]
The Company is involved in several long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $71 million and $75 million of debt during the six months ended June 30, 2021 and 2020, respectively. Long-term debt repayments associated with these financing arrangements during the six months ended June 30, 2021 and 2020 were $83 million and $36 million, respectively.

[0001783180-21-000050:notes:32]
Debt Covenants

[0001783180-21-000050:notes:33]
The Revolving Credit Facility and the indenture for the long-term notes contain affirmative and negative covenants customary for financings of these types which, among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. On June 2, 2020, the Company entered into an amendment of the Revolving Credit Facility, under which certain terms of the facility were amended for a period beginning on June 2, 2020 and ending on December 30, 2021 (the "Covenant Modification Period"). The Company may terminate the Covenant Modification Period prior to December 30, 2021, subject to the satisfaction of certain conditions. The amendment deferred testing of the Company's consolidated total net leverage ratio financial covenant until June 30, 2021 and increases the consolidated total net leverage ratio limit until December 31, 2021. The amendment also required the Company to maintain 
liquidity at a certain level until the earlier of (1) June 29, 2021 and (2) the last day of the Covenant Modification Period. As of June 30, 2021 the requirement to test the Company's consolidated total net leverage ratio was reinstated, and there is no remaining requirement to maintain liquidity at a certain level. Additionally, during the Covenant Modification Period, the Company is subject to: (a) limitations on the incurrence of subsidiary indebtedness, (b) limitations on the making of restricted payments, including purchases by the Company of shares of its common stock and the amount of dividends the Company may pay and (c) a "most favored nations" provision related to certain terms of any committed credit facility in an amount greater than $100 million. As of June 30, 2021, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-21-000050:notes:34]
[same as prior period, unchanged from 0001783180-21-000032:notes:34]

[0001783180-21-000050:notes:35]
[same as prior period, unchanged from 0001783180-21-000032:notes:35]

[0001783180-21-000050:notes:36]
[same as prior period, unchanged from 0001783180-21-000032:notes:36]

[0001783180-21-000050:notes:37]
[same as prior period, unchanged from 0001783180-21-000032:notes:37]

[0001783180-21-000050:notes:38]
[same as prior period, unchanged from 0001783180-21-000032:notes:38]

[0001783180-21-000050:notes:39]
In the normal course of business, the Company is exposed to certain risks arising from business operations and economic factors, including foreign currency and commodity price risk. These exposures are managed through operational strategies and the use of undesignated hedging contracts. The Company's derivative assets and liabilities are measured at fair value on a recurring basis using internal models based on observable market inputs, such as forward, interest, contract and discount rates. The following tables provide the valuation hierarchy classification of assets and liabilities that are recorded at fair value and measured on a recurring basis in the Company's Unaudited Condensed Consolidated Balance Sheet:

[0001783180-21-000050:notes:40]
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| June 30, 2021 |  |  |  |  |  |  |  |  |  |
| Derivative assets |  | $ | 3 |  | (1) |  | $ | — |  |  | $ | 3 |  |  | $ | — |  |
| Derivative liabilities |  | $ | (3) |  | (2) |  | $ | — |  |  | $ | (3) |  |  | $ | — |  |
| December 31, 2020 |  |  |  |  |  |  |  |  |  |
| Derivative assets |  | $ | 17 |  | (1) |  | $ | — |  |  | $ | 17 |  |  | $ | — |  |
| Derivative liabilities |  | $ | (5) |  | (2) |  | $ | — |  |  | $ | (5) |  |  | $ | — |  |

[0001783180-21-000050:notes:41]
[same as prior period, unchanged from 0001783180-21-000032:notes:42]

[0001783180-21-000050:notes:42]
[same as prior period, unchanged from 0001783180-21-000032:notes:43]

[0001783180-21-000050:notes:43]
The Company's long-term debt is measured at fair value based on observable market inputs which are considered Level 1 within the fair value hierarchy. The following table provides the carrying amounts and fair values of financial instruments that are not recorded at fair value in the Company's Unaudited Condensed Consolidated Balance Sheet:

[0001783180-21-000050:notes:44]
|  |  | June 30, 2021 |  | December 31, 2020 |  |
| (In millions) |  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  |
| Total Long-term Notes (1) |  | $ | 9,500 |  |  | $ | 9,930 |  |  | $ | 10,000 |  |  | $ | 10,811 |  |  |

[0001783180-21-000050:notes:45]
(1) Excludes debt discount and issuance costs

[0001783180-21-000050:notes:46]
The carrying value of cash and cash equivalents, accounts receivable, accounts payable and short-term borrowings approximate 
fair value due to the short-term nature of these accounts and would be classified as Level 1 in the fair value hierarchy. The Company's financing leases and project financing obligations, included in Long-term debt, approximate fair value and are classified as Level 3 in the fair value hierarchy.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-21-000050:notes:47]
[same as prior period, unchanged from 0001783180-21-000032:notes:51]

[0001783180-21-000050:notes:48]
[same as prior period, unchanged from 0001783180-21-000032:notes:52]

[0001783180-21-000050:notes:49]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Defined benefit plans |  | $ | 3 |  |  | $ | 2 |  |  | $ | 27 |  |  | $ | 27 |  |
| Defined contribution plans |  | $ | 30 |  |  | $ | 25 |  |  | $ | 67 |  |  | $ | 55 |  |
| Multi-employer pension plans |  | $ | 7 |  |  | $ | 5 |  |  | $ | 12 |  |  | $ | 10 |  |

[0001783180-21-000050:notes:50]
[same as prior period, unchanged from 0001783180-21-000032:notes:54]

[0001783180-21-000050:notes:51]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Service cost |  | $ | 7 |  |  | $ | 7 |  |  | $ | 14 |  |  | $ | 15 |  |
| Interest cost |  | 10 |  |  | 13 |  |  | 19 |  |  | 26 |  |
| Expected return on plan assets |  | (37) |  |  | (34) |  |  | (73) |  |  | (69) |  |
| Amortization of prior service credit |  | — |  |  | — |  |  | 1 |  |  | 1 |  |
| Recognized actuarial net (gain) loss |  | 8 |  |  | 5 |  |  | 16 |  |  | 10 |  |
| Net settlement, curtailment and special termination benefit (gain) loss |  | — |  |  | — |  |  | — |  |  | 1 |  |
| Net periodic pension expense (benefit) |  | $ | (12) |  |  | $ | (9) |  |  | $ | (23) |  |  | $ | (16) |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001783180-21-000050:notes:52]
STOCK-BASED COMPENSATION

[0001783180-21-000050:notes:53]
The Company accounts for stock-based compensation plans in accordance with ASC 718, Compensation - Stock Compensation, which requires a fair-value based method for measuring the value of stock-based compensation. Fair value is measured once at the date of grant and is not adjusted for subsequent changes. The Company's stock-based compensation plans include programs for stock appreciation rights, restricted stock units and performance share units.

[0001783180-21-000050:notes:54]
Stock-based compensation expense is included in Selling, general and administrative in the accompanying Unaudited Condensed Consolidated Statements of Operations. The expense recognized was as follows:

[0001783180-21-000050:notes:55]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (in millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Equity settled |  | $ | 21 |  |  | $ | 22 |  |  | $ | 40 |  |  | $ | 35 |  |
| Cash settled |  | 6 |  |  | 4 |  |  | 10 |  |  | (1) |  |
| Total stock-based compensation expense |  | $ | 27 |  |  | $ | 26 |  |  | $ | 50 |  |  | $ | 34 |  |

[0001783180-21-000050:notes:56]
Prior to the Separation and the Distribution, the Company participated in UTC's long-term incentive plans, which authorized various types of market and performance-based incentive awards. For these periods, stock-based compensation expense was allocated to the Company from UTC based upon direct employee headcount. In connection with the Separation and the 
Distribution, all awards were converted into Carrier stock-based awards with unvested awards converted to preserve their intrinsic value immediately before and after the Separation.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-21-000050:notes:57]
GUARANTEES
The Company provides service and warranty coverage on its products and extends performance and operating cost guarantees beyond normal service and warranty coverage on certain products. In addition, the Company incurs discretionary costs to service its products in connection with specific product performance issues. Liabilities for performance and operating cost guarantees are based upon future product performance and durability and are estimated based upon historical experience. Adjustments are recorded to accruals based on claims data and historical experience. The changes in the carrying amount of service and product warranties and product performance guarantees, included in Accrued liabilities on the accompanying Unaudited Condensed Consolidated Balance Sheet, are as follows:

[0001783180-21-000050:notes:58]
|  |  | For the Six Months Ended June 30, |
| (In millions) |  | 2021 |  | 2020 |
| Balance as of January 1, |  | $ | 514 |  |  | $ | 488 |  |
| Warranties, performance guarantees issued and changes in estimated liability |  | 89 |  |  | 105 |  |
| Settlements made |  | (80) |  |  | (92) |  |
| Balance as of June 30, |  | $ | 523 |  |  | $ | 501 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-21-000050:notes:59]
EQUITY 
The authorized number of shares of common stock of Carrier is 4,000,000,000 shares of $0.01 par value. As of June 30, 2021, 870,754,214 shares of common stock were issued, which includes 3,053,847 shares of treasury stock.

[0001783180-21-000050:notes:60]
[same as prior period, unchanged from 0001783180-21-000032:notes:59]

[0001783180-21-000050:notes:61]
On February 4, 2021, the Company's Board of Directors approved a stock repurchase program authorizing the repurchase of up to $350 million of the Company's outstanding common stock. The Company may repurchase shares from time to time subject to market conditions and at the Company's discretion in the open market or through one or more other public or private transactions, subject to compliance with the Company's obligations under the TMA and the Revolving Credit Facility. The Company records repurchases under the cost method whereby the entire cost of the acquired stock is recorded as Treasury stock as a reduction to equity. The reissuance of treasury stock uses the first-in, first-out method of accounting.

[0001783180-21-000050:notes:62]
The Company repurchased 2.1 million shares and 3.1 million shares of common stock for an aggregate purchase price of $92 million and  $130 million for the three and six months ended June 30, 2021, respectively, which are held in Treasury stock as of June 30, 2021 as reflected on its Unaudited Condensed Consolidated Balance Sheet.

[0001783180-21-000050:notes:63]
[same as prior period, unchanged from 0001783180-21-000032:notes:62]

[0001783180-21-000050:notes:64]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the three months ended June 30, 2021 and 2020 is as follows:

[0001783180-21-000050:notes:65]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of March 31, 2021 |  | $ | (312) |  |  | $ | (547) |  |  |  |  |  |  | $ | (859) |  |
| Other comprehensive income (loss) before reclassifications, net |  | 59 |  |  | — |  |  |  |  |  |  | 59 |  |
| Amounts reclassified, pre-tax |  | — |  |  | 8 |  |  |  |  |  |  | 8 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (2) |  |  |  |  |  |  | (2) |  |
| Balance as of June 30, 2021 |  | $ | (253) |  |  | $ | (541) |  |  |  |  |  |  | $ | (794) |  |

[0001783180-21-000050:notes:66]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of March 31, 2020 |  | $ | (1,268) |  |  | $ | (468) |  |  |  |  |  |  | $ | (1,736) |  |
| Other comprehensive income (loss) before reclassifications, net |  | 250 |  |  | 2 |  |  |  |  |  |  | 252 |  |
| Amounts reclassified, pre-tax |  | — |  |  | 6 |  |  |  |  |  |  | 6 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (1) |  |  |  |  |  |  | (1) |  |
| Balance as of June 30, 2020 |  | $ | (1,018) |  |  | $ | (461) |  |  |  |  |  |  | $ | (1,479) |  |

[0001783180-21-000050:notes:67]
A summary of changes in the components of Accumulated other comprehensive income (loss) for the six months ended June 30, 2021 and 2020 is as follows:

[0001783180-21-000050:notes:68]
| (In millions) | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2020 | $ | (191) |  |  | $ | (554) |  |  |  |  |  |  | $ | (745) |  |
| Other comprehensive income (loss) before reclassifications, net | (62) |  |  | — |  |  |  |  |  |  | (62) |  |
| Amounts reclassified, pre-tax | — |  |  | 17 |  |  |  |  |  |  | 17 |  |
| Tax benefit reclassified | — |  |  | (4) |  |  |  |  |  |  | (4) |  |
| Balance as of June 30, 2021 | $ | (253) |  |  | $ | (541) |  |  |  |  |  |  | $ | (794) |  |

[0001783180-21-000050:notes:69]
| (In millions) | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2019 | $ | (780) |  |  | $ | (473) |  |  |  |  |  |  | $ | (1,253) |  |
| Other comprehensive income (loss) before reclassifications, net | (238) |  |  | 2 |  |  |  |  |  |  | (236) |  |
| Amounts reclassified, pre-tax | — |  |  | 12 |  |  |  |  |  |  | 12 |  |
| Tax benefit reclassified | — |  |  | (2) |  |  |  |  |  |  | (2) |  |
| Balance as of June 30, 2020 | $ | (1,018) |  |  | $ | (461) |  |  |  |  |  |  | $ | (1,479) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-21-000050:notes:70]
REVENUE RECOGNITION The Company recognizes revenue when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefit from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company's performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.
Sales disaggregated by product and service are as follows:

[0001783180-21-000050:notes:71]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,757 |  |  | $ | 1,976 |  |  | $ | 4,904 |  |  | $ | 3,633 |  |
| Service |  | 363 |  |  | 315 |  |  | 702 |  |  | 617 |  |
| HVAC sales |  | 3,120 |  |  | 2,291 |  |  | 5,606 |  |  | 4,250 |  |
| Product |  | 915 |  |  | 609 |  |  | 1,807 |  |  | 1,322 |  |
| Service |  | 106 |  |  | 91 |  |  | 219 |  |  | 186 |  |
| Refrigeration sales |  | 1,021 |  |  | 700 |  |  | 2,026 |  |  | 1,508 |  |
| Product |  | 1,012 |  |  | 762 |  |  | 1,931 |  |  | 1,622 |  |
| Service |  | 391 |  |  | 295 |  |  | 776 |  |  | 641 |  |
| Fire & Security sales |  | 1,403 |  |  | 1,057 |  |  | 2,707 |  |  | 2,263 |  |
| Total segment sales |  | 5,544 |  |  | 4,048 |  |  | 10,339 |  |  | 8,021 |  |
| Eliminations and other |  | (104) |  |  | (76) |  |  | (200) |  |  | (161) |  |
| Net sales |  | $ | 5,440 |  |  | $ | 3,972 |  |  | $ | 10,139 |  |  | $ | 7,860 |  |

[0001783180-21-000050:notes:72]
[same as prior period, unchanged from 0001783180-21-000032:notes:69]

[0001783180-21-000050:notes:73]
[same as prior period, unchanged from 0001783180-21-000032:notes:70]

[0001783180-21-000050:notes:74]
| (In millions) |  | June 30,2021 |  | December 31,2020 |
| Contract assets, current |  | $ | 695 |  |  | $ | 656 |  |
| Contract assets, non-current (included within Other assets) |  | 166 |  |  | 98 |  |
| Total contract assets |  | $ | 861 |  |  | $ | 754 |  |
| Contract liabilities, current |  | (576) |  |  | (512) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (171) |  |  | (165) |  |
| Total contract liabilities |  | (747) |  |  | (677) |  |
| Net contract assets |  | $ | 114 |  |  | $ | 77 |  |

[0001783180-21-000050:notes:75]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under the contract or when the Company has a right to consideration that is conditioned upon transfer of a good or service to the customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. The Company recognized revenue of $100 million during the six months ended June 30, 2021 that related to contract liabilities  as of January 1, 2021. The Company expects a majority of its contract liabilities at the end of the period to be recognized as revenue in the next 12 months.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-21-000050:notes:76]
RESTRUCTURING COSTSThe Company incurs costs associated with restructuring initiatives intended to improve operating performance, profitability and working capital levels. Actions associated with these initiatives may include improving productivity, workforce reductions and the consolidation of facilities. 
The Company recorded net pre-tax restructuring costs for new and ongoing restructuring initiatives as follows:

[0001783180-21-000050:notes:77]
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC | $ | 7 |  |  | $ | 1 |  |  | $ | 11 |  |  | $ | 3 |  |
| Refrigeration | 3 |  |  | 3 |  |  | 5 |  |  | 3 |  |
| Fire & Security | 9 |  |  | 6 |  |  | 20 |  |  | 9 |  |
| Total Segment | 19 |  |  | 10 |  |  | 36 |  |  | 15 |  |
| General corporate expenses | 2 |  |  | 1 |  |  | 3 |  |  | 1 |  |
| Total restructuring costs | $ | 21 |  |  | $ | 11 |  |  | $ | 39 |  |  | $ | 16 |  |
| Cost of sales | $ | 6 |  |  | $ | 5 |  |  | $ | 11 |  |  | $ | 6 |  |
| Selling, general and administrative | 15 |  |  | 6 |  |  | 28 |  |  | 10 |  |
| Total restructuring costs | $ | 21 |  |  | $ | 11 |  |  | $ | 39 |  |  | $ | 16 |  |

[0001783180-21-000050:notes:78]
[same as prior period, unchanged from 0001783180-21-000032:notes:76]

[0001783180-21-000050:notes:79]
|  |  | For the Six Months Ended June 30, |
| (In millions) |  | 2021 |  | 2020 |
| Balance as of January 1, |  | $ | 49 |  |  | $ | 66 |  |
| Net pre-tax restructuring costs |  | 39 |  |  | 16 |  |
| Utilization, foreign exchange and other |  | (40) |  |  | (35) |  |
| Balance as of June 30, |  | $ | 48 |  |  | $ | 47 |  |

[0001783180-21-000050:notes:80]
During the six months ended June 30, 2021, charges associated with restructuring initiatives related to cost reduction efforts. Amounts recognized primarily related to severance due to workforce reductions and exit costs due to the consolidation of field operations. As of June 30, 2021, the Company had $48 million accrued for costs associated with its announced restructuring initiatives, all of which is expected to be paid within one year.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-21-000050:notes:81]
INCOME TAXES 
The Company accounts for income tax expense in accordance with ASC 740, which requires that an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate for the three months ended June 30, 2021 was 32.0% compared with 28.2% for the three months ended June 30, 2020. The period-over-period increase is primarily due to a $43 million deferred tax charge as a result of a tax rate increase enacted on June 10, 2021, with an effective date of April 2023, from 19% to 25% in the United Kingdom.

[0001783180-21-000050:notes:82]
The effective tax rate for the six months ended June 30, 2021 was 27.5% compared with 44.6% for the six months ended June 30, 2020. The year-over-year decrease is primarily due to the absence of a prior year charge of $51 million related to a valuation allowance recorded against a United Kingdom tax loss and credit carryforward and a $46 million charge resulting from the Company's decision to no longer permanently reinvest certain pre-2018 unremitted non-U.S. earnings.  The six months ended June 30, 2021 included a $43 million deferred tax charge as a result of the tax rate increase from 19% to 25% in the United Kingdom, partially offset by the recognition of a favorable tax adjustment of $21 million resulting from a re-organization in our German subsidiaries.

[0001783180-21-000050:notes:83]
Income taxes through March 31, 2020 were recorded based on a "carve-out" and separate company basis. Prior to the Separation and the Distribution, the Company’s portion of income taxes for domestic and certain foreign jurisdictions were

[0001783180-21-000050:notes:84]
deemed settled in the period the related tax expense was recorded. After the Separation and the Distribution, the Company’s income taxes are prepared on a stand-alone basis.

[0001783180-21-000050:notes:85]
[same as prior period, unchanged from 0001783180-21-000032:notes:81]

[0001783180-21-000050:notes:86]
The Company conducts business globally and files income tax returns in U.S. federal, state and foreign jurisdictions. In certain jurisdictions, the Company's operations were included in UTC's combined tax returns for the periods through the Distribution. The U.S. Internal Revenue Service ("IRS") commenced an audit of UTC's tax years 2017 and 2018 in the second quarter of 2020. In the normal course of business, the Company is subject to examination by taxing authorities throughout the world, including Australia, Belgium, Canada, China, Czech Republic, France, Germany, Hong Kong, India, Italy, Mexico, the Netherlands, Singapore, the United Kingdom and the United States. The Company is no longer subject to U.S. federal income tax examination for years prior to 2017 and, with few exceptions, is no longer subject to state, local and foreign income tax examinations for tax years prior to 2013.

[0001783180-21-000050:notes:87]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. The Company believes that it is reasonably possible that a net decrease in unrecognized tax benefits of between $20 million and $35 million may occur within 12 months as a result of additional uncertain tax positions, the Separation, the revaluation of uncertain tax positions arising from examinations, appeals, court decisions and/or the expiration of tax statutes.


## us-gaap:EarningsPerShareTextBlock

[0001783180-21-000050:notes:88]
[same as prior period, unchanged from 0001783180-21-000032:notes:84]

[0001783180-21-000050:notes:89]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions, except per share amounts) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net income attributable to common shareowners |  | $ | 487 |  |  | $ | 261 |  |  | $ | 871 |  |  | $ | 357 |  |
| Basic weighted-average number of shares outstanding |  | 868.7 |  |  | 866.2 |  |  | 869.0 |  |  | 866.2 |  |
| Stock awards and equity units (share equivalent) |  | 22.2 |  |  | 4.7 |  |  | 21.4 |  |  | 4.7 |  |
| Diluted weighted-average number of shares outstanding |  | 890.9 |  |  | 870.9 |  |  | 890.4 |  |  | 870.9 |  |
| Antidilutive shares excluded from computation of diluted earnings per share |  | 3.1 |  |  | 30.9 |  |  | 3.1 |  |  | 30.9 |  |
| Earnings Per Share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.56 |  |  | $ | 0.30 |  |  | $ | 1.00 |  |  | $ | 0.41 |  |
| Diluted |  | $ | 0.55 |  |  | $ | 0.30 |  |  | $ | 0.98 |  |  | $ | 0.41 |  |

[0001783180-21-000050:notes:90]
[same as prior period, unchanged from 0001783180-21-000032:notes:86]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001783180-21-000050:notes:91]
BUSINESS ACQUISITIONS AND DISPOSITIONS
During the six months ended June 30, 2021, the Company acquired consolidated and minority-owned businesses. The aggregate cash paid, net of cash acquired, totaled $167 million and was funded through cash on hand. Acquisitions are recorded using the acquisition method of accounting in accordance with ASC 805, Business Combinations ("ASC 805"). As a result, the aggregate purchase price has been allocated to assets acquired and liabilities assumed based on the estimate of fair market value of such assets and liabilities at the date of acquisition. Intangible assets associated with these transactions totaled $94 million and primarily related to customer relationships, technology assets and a non-compete agreement. The excess purchase price over the estimated fair value of net assets acquired was recognized as goodwill and totaled $175 million.

[0001783180-21-000050:notes:92]
Acquisition of Giwee Group Co.

[0001783180-21-000050:notes:93]
On June 1, 2021, the Company acquired a 70% controlling stake in Guangdong Giwee Group and its subsidiaries ("Giwee"). Giwee is a China-based manufacturer of HVAC products, offering a portfolio of products including variable refrigerant flow, modular chillers and light commercial air conditioners. The results of Giwee are reported within the HVAC segment as of the date of acquisition. The Company has not included pro forma financial information required under ASC 805 as the pro forma impact was not deemed significant.

[0001783180-21-000050:notes:94]
The excess of the purchase price over the estimated fair value of the net assets acquired was recognized as goodwill and totaled $168 million, which is not deductible for tax purposes. Accounts receivable and current liabilities were stated at their historical carrying value, which approximates fair value given the short-term nature of these assets and liabilities. The estimate of fair value for inventory and property, plant and equipment was based on an assessment of the acquired assets' condition as well as an evaluation of the current market value of such assets.

[0001783180-21-000050:notes:95]
The Company recorded intangible assets based on its preliminary estimate of fair value, which consisted of the following:

[0001783180-21-000050:notes:96]
| (in millions) | Estimated Useful Life (in years) |  | Intangible Assets Acquired |
| Customer relationships | 14 |  | $ | 52 |  |
| Technology | 10 |  | 34 |  |
| Non-compete agreement | 5 |  | 8 |  |
| Total intangible assets acquired |  |  | $ | 94 |  |

[0001783180-21-000050:notes:97]
The valuation of intangible assets was determined using an income approach methodology including the multi-period excess earnings method and the relief from royalty method. Key assumptions used in estimating future cash flows included projected revenue growth rate, customer attrition rates and royalty rates. The projected future cash flows are discounted to present value using an appropriate discount rate. As of June 30, 2021, the Company has not finalized the process of allocating the purchase price and valuing the acquired assets and liabilities for the Giwee acquisition.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-21-000050:notes:98]
[same as prior period, unchanged from 0001783180-21-000032:notes:87]

[0001783180-21-000050:notes:99]
[same as prior period, unchanged from 0001783180-21-000032:notes:88]

[0001783180-21-000050:notes:100]
[same as prior period, unchanged from 0001783180-21-000032:notes:89]

[0001783180-21-000050:notes:101]
[same as prior period, unchanged from 0001783180-21-000032:notes:90]

[0001783180-21-000050:notes:102]
[same as prior period, unchanged from 0001783180-21-000032:notes:91]

[0001783180-21-000050:notes:103]
[same as prior period, unchanged from 0001783180-21-000032:notes:92]

[0001783180-21-000050:notes:104]
|  |  | Net Sales |  | Operating Profit |
|  |  | For the Three Months Ended June 30, |  | For the Three Months Ended June 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC |  | $ | 3,120 |  |  | $ | 2,291 |  |  | $ | 573 |  |  | $ | 358 |  |
| Refrigeration |  | 1,021 |  |  | 700 |  |  | 123 |  |  | 61 |  |
| Fire & Security |  | 1,403 |  |  | 1,057 |  |  | 148 |  |  | 106 |  |
| Total segment |  | 5,544 |  |  | 4,048 |  |  | 844 |  |  | 525 |  |
| Eliminations and other |  | (104) |  |  | (76) |  |  | (23) |  |  | (56) |  |
| General corporate expenses |  | — |  |  | — |  |  | (38) |  |  | (27) |  |
| Total Consolidated |  | $ | 5,440 |  |  | $ | 3,972 |  |  | $ | 783 |  |  | $ | 442 |  |

[0001783180-21-000050:notes:105]
|  |  | Net Sales |  | Operating Profit |
|  |  | For the Six Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC |  | $ | 5,606 |  |  | $ | 4,250 |  |  | $ | 938 |  |  | $ | 525 |  |
| Refrigeration |  | 2,026 |  |  | 1,508 |  |  | 250 |  |  | 160 |  |
| Fire & Security |  | 2,707 |  |  | 2,263 |  |  | 298 |  |  | 226 |  |
| Total segment |  | 10,339 |  |  | 8,021 |  |  | 1,486 |  |  | 911 |  |
| Eliminations and other |  | (200) |  |  | (161) |  |  | (63) |  |  | (91) |  |
| General corporate expenses |  | — |  |  | — |  |  | (69) |  |  | (63) |  |
| Total Consolidated |  | $ | 10,139 |  |  | $ | 7,860 |  |  | $ | 1,354 |  |  | $ | 757 |  |

[0001783180-21-000050:notes:106]
Geographic external sales are attributed to the geographic regions based on their location of origin. With the exception of the U.S. presented in the table below, there were no individually significant countries with sales exceeding 10% of total sales during the six months ended June 30, 2021 and 2020.

[0001783180-21-000050:notes:107]
|  |  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| United States |  | $ | 2,848 |  |  | $ | 2,192 |  |  | $ | 5,201 |  |  | $ | 4,203 |  |
| International: |  |  |  |  |  |  |  |  |
| Europe |  | 1,459 |  |  | 969 |  |  | 2,857 |  |  | 2,148 |  |
| Asia Pacific |  | 907 |  |  | 645 |  |  | 1,649 |  |  | 1,164 |  |
| Other |  | 226 |  |  | 166 |  |  | 432 |  |  | 345 |  |
| Net sales |  | $ | 5,440 |  |  | $ | 3,972 |  |  | $ | 10,139 |  |  | $ | 7,860 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-21-000050:notes:108]
RELATED PARTIES 
Equity Method Investments

[0001783180-21-000050:notes:109]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered to be related parties. Amounts attributable to equity method investees are as follows:

[0001783180-21-000050:notes:110]
|  |  | Three Months Ended June 30, |  | Six Months Ended June 30, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Sales to equity method investees included in Product sales |  | $ | 652 |  |  | $ | 434 |  |  | $ | 1,120 |  |  | $ | 778 |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 98 |  |  | $ | 66 |  |  | $ | 174 |  |  | $ | 143 |  |

[0001783180-21-000050:notes:111]
The Company had receivables from and payables to equity method investees as follows:

[0001783180-21-000050:notes:112]
| (In millions) |  | June 30,2021 |  | December 31, 2020 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 243 |  |  | $ | 161 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 59 |  |  | $ | 38 |  |

[0001783180-21-000050:notes:113]
The Company periodically reviews the carrying value of its equity method investments to determine if there has been an other-than-temporary decline in fair value. During the three months ended March 31, 2020, the Company determined that indicators of impairment existed for a minority owned joint venture investment and performed a valuation of this investment using a  discounted cash flow method. The Company determined that the loss in value was other-than-temporary due to a reduction in sales and earnings that were primarily driven by a deterioration in the oil and gas industry (the joint venture's primary market) and by the impact of the COVID-19 pandemic. As a result, the Company recorded a non-cash, other-than-temporary impairment charge of $71 million on this investment during the three months ended March 31, 2020, which is included in Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-21-000050:notes:114]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies ("ASC 450"), the Company records accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon the Company's competitive position, results of operations, cash flows or financial condition.

[0001783180-21-000050:notes:115]
Environmental Matters

[0001783180-21-000050:notes:116]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees, and the Company periodically reassesses these amounts. Management believes that the likelihood of incurring losses materially in excess of the amounts accrued is remote. The outstanding liabilities for environmental obligations are as follows:

[0001783180-21-000050:notes:117]
| (In millions) |  | June 30,2021 |  | December 31, 2020 |
| Environmental reserves included in Accrued liabilities |  | $ | 25 |  |  | $ | 26 |  |
| Environmental reserves included in Other long-term liabilities |  | 209 |  |  | 213 |  |
| Total Environmental reserves |  | $ | 234 |  |  | $ | 239 |  |

[0001783180-21-000050:notes:118]
Asbestos Matters

[0001783180-21-000050:notes:119]
The Company and its consolidated subsidiaries have been named as defendants in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-21-000050:notes:120]
The Company had asbestos liabilities and related recoveries as follows:

[0001783180-21-000050:notes:121]
| (In millions) |  | June 30,2021 |  | December 31,2020 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 18 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 222 |  |  | 228 |  |
| Total Asbestos liabilities |  | $ | 240 |  |  | $ | 245 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 6 |  |  | $ | 6 |  |
| Asbestos-related recoveries included in Other assets |  | 95 |  |  | 97 |  |
| Total Asbestos-related recoveries |  | $ | 101 |  |  | $ | 103 |  |

[0001783180-21-000050:notes:122]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. Where no amount within a range of estimates is more likely, the minimum is accrued. These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded an insurance recovery receivable for probable asbestos-related recoveries.

[0001783180-21-000050:notes:123]
UTC Equity Awards Conversion Litigation

[0001783180-21-000050:notes:124]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenges the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. The Complaint asserted that the defendants are liable for breach of certain equity compensation plans and for breach of fiduciary duty and also asserted claims under certain provisions of the Employee Retirement Income Security Act of 1974, as amended. Plaintiffs have withdrawn, with prejudice, their claims against Otis's and Carrier's current Boards of Directors. Carrier believes that the remaining claims against the Company are without merit.

[0001783180-21-000050:notes:125]
Aqueous Film Forming Foam Litigation

[0001783180-21-000050:notes:126]
Aqueous Film Forming Foam ("AFFF") is a firefighting foam developed in the 1970s pursuant to U.S. military specification and used to extinguish certain types of fires primarily at airports and military bases. AFFF was manufactured by several companies, including National Foam and Angus Fire. UTC acquired the National Foam and Angus Fire businesses in 2005 as part of the acquisition of Kidde, which had been operated by Carrier. In 2013, UTC divested the National Foam and Angus Fire businesses to a third party.

[0001783180-21-000050:notes:127]
The Company and many other parties, including the third-party buyer of the National Foam and Angus Fire businesses, have been named as defendants in over 1,300 cases, including putative class actions and other lawsuits, alleging that the historic use of AFFF caused personal injuries and property damage. Additionally, several state, municipal and water utility plaintiffs have commenced litigation against the same defendants to recover remediation costs related to historic use of AFFF. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation ("MDL") transferred and consolidated all of the AFFF cases pending in the federal courts to the U.S. District Court for the District of South Carolina for pre-trial proceedings.

[0001783180-21-000050:notes:128]
Plaintiffs in the MDL allege that a chemical ingredient in AFFF contains, or breaks down into, compounds known as perflourooctane sulfonate ("PFOS") and perflourooctane acid ("PFOA") that were released into the environment and, in some instances, ultimately leached into drinking water supplies. National Foam and Angus Fire purchased these perflourinated chemical ingredients from third-party chemical manufacturers to manufacture AFFF. Chemicals containing PFOS and PFOA (or their precursors) have also been used for decades by many third parties to manufacture carpets, clothing, fabrics, cookware and other consumer products. The individual plaintiffs in the MDL generally seek compensatory damages for alleged personal injuries, medical monitoring and diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S., state, municipal and water utility plaintiffs in the MDL generally seek damages and costs related to the remediation of public property and water supplies.

[0001783180-21-000050:notes:129]
The Company and other defendants are also party to fewer than 10 cases in state court brought by oil refining companies in the U.S. alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage.

[0001783180-21-000050:notes:130]
The Company and other defendants are also party to an action related to the AFFF manufacturing facility that was operated by National Foam and Angus Fire in which the plaintiff water utility seeks remediation costs related to the alleged contamination of the local water supply.

[0001783180-21-000050:notes:131]
The Company believes that it has meritorious defenses to these claims and the Company is also seeking insurance coverage for these claims. At this time, however, given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or reasonably estimate the damages, if any, to be allocated to the Company, if one or more plaintiffs were to prevail in these cases, and there can be no assurance that any such future exposure will not be material in any period.

[0001783180-21-000050:notes:132]
Income Taxes

[0001783180-21-000050:notes:133]
Under the TMA, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act ("TCJA") transition tax associated with foreign undistributed earnings as of December 31, 2017. As a result, a liability of $453 million is included within the accompanying Unaudited Condensed Consolidated Balance Sheet at June 30, 2021. This obligation is expected to be settled in annual installments ending in April 2026 with the next installment of $36 million included within Accrued Liabilities. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

[0001783180-21-000050:notes:134]
Other

[0001783180-21-000050:notes:135]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-21-000050:notes:136]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings, claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its competitive position, results of operations, cash flows or financial condition.


## us-gaap:SubsequentEventsTextBlock

[0001783180-21-000050:notes:137]
SUBSEQUENT EVENTS 
Sale of Chubb Fire & Security Business

[0001783180-21-000050:notes:138]
On July 26, 2021, the Company entered into an agreement to sell its Chubb Fire and Security business (Chubb) to APi Group Corporation (APi) for an enterprise value of $3.1 billion (the “Agreement”). The purchase price is subject to working capital and other adjustments as provided in the Agreement. Chubb, reported within the Company’s Fire & Security segment, delivers essential fire safety and security solutions from design and installation to monitoring, service and maintenance across more than 17 countries around the globe. At June 30, 2021, Chubb did not meet the criteria for assets held for sale in the Unaudited Condensed Consolidated Balance Sheet. On a prospective basis, the net assets of Chubb will be classified as held for sale until the divestiture is completed. This transaction is expected to close late in the fourth quarter of 2021 or early in the first quarter of 2022, subject to regulatory approvals, required works council consultation in France and customary closing conditions. Based on the carrying amount of Chubb’s net assets, foreign currency translation rates and other assumptions at June 30, 2021, the Company expects to recover the carrying value of the disposal group upon completion of the transaction. In conjunction with the Agreement, the Company has agreed to provide APi, and APi has agreed to provide the Company, certain transitional services for varying periods after the closing.

[0001783180-21-000050:notes:139]
Share Repurchase Program
On July 27, 2021, the Company's Board of Directors approved a $1.75 billion increase to the Company's existing $350 million stock repurchase program authorized in February 2021. Share repurchases may take place from time to time subject to market conditions and at the Company's discretion in the open market or through one or more other public or private transactions.
