# CARR 8-K — 0001783180-21-000049 filed 2021-07-29

## item codes, every 8-K on or before 2021-07-29

- 2021-07-29 0001783180-21-000049 — 2.02, 8.01, 9.01
- 2021-07-27 0000950142-21-002448 — 8.01, 9.01
- 2021-07-15 0000950142-21-002362 — 5.02, 9.01
- 2021-06-09 0000950142-21-001885 — 5.02, 9.01
- 2021-04-29 0001783180-21-000029 — 2.02, 9.01
- 2021-04-22 0001140361-21-013889 — 5.02, 9.01
- 2021-04-20 0001783180-21-000021 — 5.07, 9.01
- 2021-04-19 0000950142-21-001308 — 8.01, 9.01
- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2021-07-29

- none on or before 2021-07-29

## item 2.02 — earnings release, exhibit 99.1

[0001783180-21-000049:8k_2_02:1]
EX-99.1
2
a991-q22021earningsrelease.htm
EX-99.1

[0001783180-21-000049:8k_2_02:2]
Document

[0001783180-21-000049:8k_2_02:3]
Exhibit 99.1

[0001783180-21-000049:8k_2_02:4]
Carrier Reports Second Quarter 2021 Results

[0001783180-21-000049:8k_2_02:5]
Raises Full Year Outlook for Sales, Adjusted EPS and Free Cash Flow

[0001783180-21-000049:8k_2_02:6]
•Sales of $5.4 billion, up 37% compared to 2020 including 31% organic growth

[0001783180-21-000049:8k_2_02:7]
•GAAP EPS of $0.55 and adjusted EPS of $0.64

[0001783180-21-000049:8k_2_02:8]
•Net cash flow from operating activities of $561 million and free cash flow of $482 million

[0001783180-21-000049:8k_2_02:9]
•Increases full-year 2021 sales growth outlook to 14% to 16%, 10% to 12% organic*

[0001783180-21-000049:8k_2_02:10]
•Increases full-year 2021 adjusted EPS range to $2.10 to $2.20*

[0001783180-21-000049:8k_2_02:11]
•Increases full-year 2021 expected free cash flow to about $1.9 billion*

[0001783180-21-000049:8k_2_02:12]
PALM BEACH GARDENS, Fla., July 29, 2021 – Carrier Global Corporation (NYSE:CARR) today reported financial results for the second quarter of 2021 and updated its full year outlook. Carrier is the leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions.

[0001783180-21-000049:8k_2_02:13]
“I am very pleased with our second quarter results.  We delivered strong revenue growth over the second quarters of both 2020 and 2019. Our operational performance also enabled us to meet higher than expected customer demand,” said Carrier Chairman & CEO David Gitlin. “We see secular trends supporting continued growth. We are making targeted organic and inorganic investments to further enhance our differentiation and deliver long-term value to customers and shareowners. Given our first half performance, healthy backlog, and improved expectations for the remainder of the year, we are again raising our full-year guidance for sales, adjusted EPS, adjusted operating margin and free cash flow.”

[0001783180-21-000049:8k_2_02:14]
1

[0001783180-21-000049:8k_2_02:15]
Second Quarter 2021 Results

[0001783180-21-000049:8k_2_02:16]
Carrier’s second quarter sales of $5.4 billion were up 37% compared to the prior year and organic sales were up 31% over the same period. The strong sales performance was broad-based across all three segments, including growth in commercial HVAC, transport refrigeration, the Fire & Security segment and continued strength in North American residential HVAC. GAAP operating profit in the quarter of $783 million was up 77% from last year and adjusted operating profit of $821 million was up 72%.  These results benefitted from higher volume and productivity that more than offset cost increases.

[0001783180-21-000049:8k_2_02:17]
Net income was $487 million, and adjusted net income was $567 million.  GAAP EPS was $0.55 while adjusted EPS was $0.64. Net cash flows provided by operating activities were $561 million and capital expenditures were $79 million, resulting in free cash flow of $482 million. The second quarter results include the results of Guangdong Giwee Group and its subsidiaries (“Giwee”) following Carrier’s acquisition of 70% of Giwee on June 1, 2021.

[0001783180-21-000049:8k_2_02:18]
Updated Full-Year 2021 Outlook*

[0001783180-21-000049:8k_2_02:19]
Carrier is announcing the following updated outlook for 2021:

[0001783180-21-000049:8k_2_02:20]
•Sales growth of 14% to 16%, up from 7% to 10%

[0001783180-21-000049:8k_2_02:21]
◦Organic sales growth of 10% to 12%, up from 5% to 8%

[0001783180-21-000049:8k_2_02:22]
◦Completed acquisitions to add approximately 1%

[0001783180-21-000049:8k_2_02:23]
◦Currency translation to add approximately 3%, up from approximately 2%

[0001783180-21-000049:8k_2_02:24]
•Adjusted operating margin greater than 13.5%

[0001783180-21-000049:8k_2_02:25]
•Adjusted EPS of $2.10 to $2.20, up from $1.95 to $2.05

[0001783180-21-000049:8k_2_02:26]
•Free cash flow of about $1.9 billion, up from about $1.7 billion

[0001783180-21-000049:8k_2_02:27]
•Chubb is included in the full-year 2021 outlook

[0001783180-21-000049:8k_2_02:28]
2

[0001783180-21-000049:8k_2_02:29]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted operating margin, incremental margins / earnings conversion, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-21-000049:8k_2_02:30]
Conference Call

[0001783180-21-000049:8k_2_02:31]
Carrier will host a webcast of its earnings conference call today, Thursday, July 29, 2021, at 8:30 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at  ir.carrier.com/news-and-events/events-and-presentations or to listen to the earnings call by phone, dial (877) 742-9091.

[0001783180-21-000049:8k_2_02:32]
About Carrier

[0001783180-21-000049:8k_2_02:33]
As the leading global provider of healthy, safe, sustainable and intelligent building and cold chain solutions, Carrier Global Corporation is committed to making the world safer, sustainable and more comfortable for generations to come. From the beginning, we've led in inventing new technologies and entirely new industries. Today, we continue to lead because we have a world-class, diverse workforce that puts the customer at the center of everything we do.  For more information, visit   www.corporate.carrier.com or follow Carrier on social media at @Carrier.

[0001783180-21-000049:8k_2_02:34]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-21-000049:8k_2_02:35]
Carrier Global Corporation (“Carrier”) reports its financial results in accordance with accounting principles generally accepted in the United States ("GAAP").

[0001783180-21-000049:8k_2_02:36]
We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information.  The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures.  Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables attached to this release. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-21-000049:8k_2_02:37]
Organic sales, adjusted operating profit, adjusted operating margin, incremental margins / earnings conversion, earnings before interest, taxes and depreciation and amortization (“EBITDA”), adjusted EBITDA, adjusted net income, adjusted earnings per share (“EPS”), the adjusted effective tax rate, and net debt are non-GAAP financial measures.

[0001783180-21-000049:8k_2_02:38]
Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a nonoperational nature

[0001783180-21-000049:8k_2_02:39]
3

[0001783180-21-000049:8k_2_02:40]
(hereinafter referred to as “other significant items”). Adjusted operating profit represents operating profit (a GAAP measure), excluding restructuring costs and other significant items.  Adjusted operating margin represents adjusted operating profit as a percentage of net sales (a GAAP measure).  Incremental margins / earnings conversion represents the year-over-year change in adjusted operating profit divided by the year-over-year change in net sales.  EBITDA represents net income attributable to common shareholders (a GAAP measure), adjusted for interest income and expense, income tax expense, and depreciation and amortization. Adjusted EBITDA represents EBITDA, as calculated above, excluding non-service pension benefit, non-controlling interest in subsidiaries’ earnings from operations, restructuring costs and other significant items.  Adjusted net income represents net income attributable to common shareowners (a GAAP measure), excluding restructuring costs and other significant items.  Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs and other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs and other significant items.  Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents.  For the business segments, when applicable, adjustments of operating profit and operating margins represent operating profit, excluding restructuring and other significant items.

[0001783180-21-000049:8k_2_02:41]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by operating activities (a GAAP measure) less capital expenditures.  Management believes free cash flow is a useful measure of liquidity and an additional basis for assessing Carrier’s ability to fund its activities, including the financing of acquisitions, debt service, repurchases of Carrier's common stock and distribution of earnings to shareowners.

[0001783180-21-000049:8k_2_02:42]
When we provide our expectations for organic sales, adjusted operating profit, adjusted operating margin, incremental margins / earnings conversion, adjusted EPS, and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures (expected net sales, operating profit, operating margin, incremental operating margin, diluted EPS and net cash flows provided by operating activities) generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance.  The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-21-000049:8k_2_02:43]
Cautionary Statement

[0001783180-21-000049:8k_2_02:44]
This communication contains statements which, to the extent they are not statements of historical or present fact, constitute “forward-looking statements” under the securities laws.  From time to time, oral or written forward-looking statements may also be included in other information released to the public.  These forward-looking statements are intended to provide management’s current expectations or plans for our future operating and financial performance, based on assumptions currently believed to be valid.  Forward-looking statements can be identified by the use of words such as

[0001783180-21-000049:8k_2_02:45]
4

[0001783180-21-000049:8k_2_02:46]
5

[0001783180-21-000049:8k_2_02:47]
Internal Revenue Service and other tax authorities that the Distribution or certain related transactions should be treated as taxable transactions; (19) risks associated with indebtedness, including that incurred as a result of financing transactions undertaken in connection with the Separation, as well as our ability to reduce indebtedness and the timing thereof; (20) the risk that dis-synergy costs, costs of restructuring transactions and other costs incurred in connection with the Separation will exceed Carrier’s estimates; and (21) the impact of the Separation on Carrier’s business and Carrier’s resources, systems, procedures and controls, diversion of management’s attention and the impact on relationships with customers, suppliers, employees and other business counterparties.

[0001783180-21-000049:8k_2_02:48]
The above list of factors is not exhaustive or necessarily in order of importance. For additional information on identifying factors that may cause actual results to vary materially from those stated in forward-looking statements, see Carrier’s reports on Forms 10-K, 10-Q and 8-K filed with or furnished to the SEC from time to time. Any forward-looking statement speaks only as of the date on which it is made, and Carrier assumes no obligation to update or revise such statement, whether as a result of new information, future events or otherwise, except as required by applicable law.

[0001783180-21-000049:8k_2_02:49]
Contact:                        Media Inquiries

[0001783180-21-000049:8k_2_02:50]
Danielle Canzanella

[0001783180-21-000049:8k_2_02:51]
561-365-1101

[0001783180-21-000049:8k_2_02:52]
Danielle.Canzanella@Carrier.com

[0001783180-21-000049:8k_2_02:53]
Investor Relations

[0001783180-21-000049:8k_2_02:54]
Sam Pearlstein

[0001783180-21-000049:8k_2_02:55]
561-365-2251

[0001783180-21-000049:8k_2_02:56]
Sam.Pearlstein@Carrier.com

[0001783180-21-000049:8k_2_02:57]
6

[0001783180-21-000049:8k_2_02:58]
Carrier Global Corporation

[0001783180-21-000049:8k_2_02:59]
Condensed Consolidated Statement of Operations

[0001783180-21-000049:8k_2_02:60]
|  | (Unaudited) |
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
| (dollars in millions, except per share amounts; shares in millions) | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net sales: |  |  |  |  |  |  |  |
| Product sales | $ | 4,584 |  |  | $ | 3,275 |  |  | $ | 8,448 |  |  | $ | 6,422 |  |
| Service sales | 856 |  |  | 697 |  |  | 1,691 |  |  | 1,438 |  |
| Total Net sales | 5,440 |  |  | 3,972 |  |  | 10,139 |  |  | 7,860 |  |
| Costs and expenses |  |  |  |  |  |  |  |
| Cost of products sold | (3,235) |  |  | (2,343) |  |  | (5,959) |  |  | (4,580) |  |
| Cost of services sold | (586) |  |  | (488) |  |  | (1,167) |  |  | (1,017) |  |
| Research and development | (125) |  |  | (94) |  |  | (246) |  |  | (192) |  |
| Selling, general and administrative | (813) |  |  | (637) |  |  | (1,556) |  |  | (1,329) |  |
| Total Costs and expenses | (4,759) |  |  | (3,562) |  |  | (8,928) |  |  | (7,118) |  |
| Equity method investment net earnings | 87 |  |  | 57 |  |  | 125 |  |  | 86 |  |
| Other income (expense), net | 15 |  |  | (25) |  |  | 18 |  |  | (71) |  |
| Operating profit | 783 |  |  | 442 |  |  | 1,354 |  |  | 757 |  |
| Non-service pension (expense) benefit | 19 |  |  | 14 |  |  | 37 |  |  | 31 |  |
| Interest (expense) income, net | (71) |  |  | (81) |  |  | (164) |  |  | (118) |  |
| Income from operations before income taxes | 731 |  |  | 375 |  |  | 1,227 |  |  | 670 |  |
| Income tax (expense) benefit | (234) |  |  | (106) |  |  | (338) |  |  | (299) |  |
| Net income from operations | 497 |  |  | 269 |  |  | 889 |  |  | 371 |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations | 10 |  |  | 8 |  |  | 18 |  |  | 14 |  |
| Net income attributable to common shareowners | $ | 487 |  |  | $ | 261 |  |  | $ | 871 |  |  | $ | 357 |  |
| Earnings per share (1), (2) |  |  |  |  |  |  |  |
| Basic | $ | 0.56 |  |  | $ | 0.30 |  |  | $ | 1.00 |  |  | $ | 0.41 |  |
| Diluted | $ | 0.55 |  |  | $ | 0.30 |  |  | $ | 0.98 |  |  | $ | 0.41 |  |
| Weighted average number of shares outstanding (2) |  |  |  |  |  |  |  |
| Basic | 868.7 |  | 866.2 |  | 869.0 |  | 866.2 |
| Diluted | 890.9 |  | 870.9 |  | 890.4 |  | 870.9 |

[0001783180-21-000049:8k_2_02:61]
(1) On April 3, 2020, United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of Carrier into a separate publicly traded company (the "Separation"). The Separation was completed through a pro-rata distribution (the "Distribution") of all of the outstanding common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020.

[0001783180-21-000049:8k_2_02:62]
(2) Basic and diluted earnings per share for the three and six months ended June 30, 2020 are calculated using the weighted-average number of common shares outstanding for the period beginning after the Distribution date. Diluted earnings per share is computed by giving effect to all potentially dilutive stock awards that are outstanding. For periods prior to the Separation it was assumed that there were no dilutive equity instruments as there were no equity awards in Carrier common stock outstanding prior to the Separation.

[0001783180-21-000049:8k_2_02:63]
7

[0001783180-21-000049:8k_2_02:64]
Carrier Global Corporation

[0001783180-21-000049:8k_2_02:65]
Condensed Consolidated Balance Sheet

[0001783180-21-000049:8k_2_02:66]
|  | (Unaudited) |
|  | As of |
| (dollars in millions) | June 30, 2021 |  | December 31, 2020 |
| Assets |  |  |  |
| Cash and cash equivalents | $ | 2,630 |  |  | $ | 3,115 |  |
| Accounts receivable, net | 3,128 |  |  | 2,781 |  |
| Contract assets, current | 695 |  |  | 656 |  |
| Inventories, net | 1,885 |  |  | 1,629 |  |
| Other assets, current | 416 |  |  | 343 |  |
| Total current assets | 8,754 |  |  | 8,524 |  |
| Future income tax benefits | 461 |  |  | 449 |  |
| Fixed assets, net | 1,837 |  |  | 1,810 |  |
| Operating lease right-of-use assets | 786 |  |  | 788 |  |
| Intangible assets, net | 1,071 |  |  | 1,037 |  |
| Goodwill | 10,279 |  |  | 10,139 |  |
| Pension and post-retirement assets | 635 |  |  | 554 |  |
| Equity method investments | 1,572 |  |  | 1,513 |  |
| Other assets | 343 |  |  | 279 |  |
| Total Assets | $ | 25,738 |  |  | $ | 25,093 |  |
| Liabilities and Equity |  |  |  |
| Accounts payable | $ | 2,362 |  |  | $ | 1,936 |  |
| Accrued liabilities | 2,541 |  |  | 2,471 |  |
| Contract liabilities, current | 576 |  |  | 512 |  |
| Current portion of long-term debt | 125 |  |  | 191 |  |
| Total current liabilities | 5,604 |  |  | 5,110 |  |
| Long-term debt | 9,600 |  |  | 10,036 |  |
| Future pension and post-retirement obligations | 511 |  |  | 524 |  |
| Future income tax obligations | 556 |  |  | 479 |  |
| Operating lease liabilities | 635 |  |  | 642 |  |
| Other long-term liabilities | 1,712 |  |  | 1,724 |  |
| Total Liabilities | 18,618 |  |  | 18,515 |  |
| Equity |  |  |  |
| Common stock | 9 |  |  | 9 |  |
| Treasury stock | (130) |  |  | — |  |
| Additional paid-in capital | 5,366 |  |  | 5,345 |  |
| Retained earnings | 2,305 |  |  | 1,643 |  |
| Accumulated other comprehensive loss | (794) |  |  | (745) |  |
| Non-controlling interest | 364 |  |  | 326 |  |
| Total Equity | 7,120 |  |  | 6,578 |  |
| Total Liabilities and Equity | $ | 25,738 |  |  | $ | 25,093 |  |

[0001783180-21-000049:8k_2_02:67]
8

[0001783180-21-000049:8k_2_02:68]
Carrier Global Corporation

[0001783180-21-000049:8k_2_02:69]
Condensed Consolidated Statement of Cash Flows

[0001783180-21-000049:8k_2_02:70]
|  |  |  |  | (Unaudited) |
|  |  |  | For the Six Months Ended June 30, |
| (dollars in millions) |  |  |  |  | 2021 |  | 2020 |
| Operating Activities |  |  |  |  |  |  |  |
| Net income from operations |  |  |  |  | $ | 889 |  |  | $ | 371 |  |
| Adjustments to reconcile net income to net cash flows from operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  |  |  | 168 |  |  | 159 |  |
| Deferred income tax provision |  |  |  |  | 33 |  |  | 135 |  |
| Stock-based compensation costs |  |  |  |  | 40 |  |  | 35 |  |
| Equity method investment net earnings |  |  |  |  | (125) |  |  | (86) |  |
| Distributions from equity method investments |  |  |  |  | 42 |  |  | 49 |  |
| Impairment charge on minority-owned joint venture investments |  |  |  |  | — |  |  | 72 |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  |  |  | (288) |  |  | 27 |  |
| Contract assets, current |  |  |  |  | (41) |  |  | (140) |  |
| Inventories, net |  |  |  |  | (210) |  |  | (325) |  |
| Other assets, current |  |  |  |  | (27) |  |  | 32 |  |
| Accounts payable and accrued liabilities |  |  |  |  | 368 |  |  | 152 |  |
| Contract liabilities, current |  |  |  |  | 42 |  |  | 37 |  |
| Defined benefit plan contributions |  |  |  |  | (27) |  |  | (27) |  |
| Other operating activities, net |  |  |  |  | (119) |  |  | 65 |  |
| Net cash flows provided by (used in) operating activities |  |  |  |  | 745 |  |  | 556 |  |
| Investing Activities |  |  |  |  |  |  |  |
| Capital expenditures |  |  |  |  | (132) |  |  | (94) |  |
| Investments in businesses, net of cash acquired |  |  |  |  | (167) |  |  | — |  |
| Disposition of businesses |  |  |  |  | 1 |  |  | — |  |
| Settlement of derivative contracts, net |  |  |  |  | (6) |  |  | (23) |  |
| Other investing activities, net |  |  |  |  | 3 |  |  | 14 |  |
| Net cash flows provided by (used in) investing activities |  |  |  |  | (301) |  |  | (103) |  |
| Financing Activities |  |  |  |  |  |  |  |
| Increase (decrease) in short-term borrowings, net |  |  |  |  | (13) |  |  | (17) |  |
| Issuance of long-term debt |  |  |  |  | 74 |  |  | 11,734 |  |
| Repayment of long-term debt |  |  |  |  | (605) |  |  | (36) |  |
| Repurchases of common stock |  |  |  |  | (130) |  |  | — |  |
| Dividends paid on common stock |  |  |  |  | (209) |  |  | — |  |
| Dividends paid to non-controlling interest |  |  |  |  | (30) |  |  | (8) |  |
| Net transfers to UTC |  |  |  |  | — |  |  | (10,359) |  |
| Other financing activities, net |  |  |  |  | 15 |  |  | 1 |  |
| Net cash flows provided by (used in) financing activities |  |  |  |  | (898) |  |  | 1,315 |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  |  |  |  | (2) |  |  | (17) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  |  |  |  | (456) |  |  | 1,751 |  |
| Cash, cash equivalents and restricted cash, beginning of period |  |  |  |  | 3,120 |  |  | 957 |  |
| Cash, cash equivalents and restricted cash, end of period |  |  |  |  | 2,664 |  |  | 2,708 |  |
| Less: restricted cash |  |  |  |  | 34 |  |  | 4 |  |
| Cash and cash equivalents, end of period |  |  |  |  | $ | 2,630 |  |  | $ | 2,704 |  |

[0001783180-21-000049:8k_2_02:71]
9

[0001783180-21-000049:8k_2_02:72]
Carrier Global Corporation

[0001783180-21-000049:8k_2_02:73]
Segment Net Sales and Operating Profit Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-21-000049:8k_2_02:74]
|  | (Unaudited) |
|  | For the Three Months Ended June 30, |  | For the Six Months Ended June 30, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| (In millions) | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |  | Reported |  | Adjusted |
| Net sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 3,120 |  |  | $ | 3,120 |  |  | $ | 2,291 |  |  | $ | 2,291 |  |  | $ | 5,606 |  |  | $ | 5,606 |  |  | $ | 4,250 |  |  | $ | 4,250 |  |
| Refrigeration | 1,021 |  |  | 1,021 |  |  | 700 |  |  | 700 |  |  | 2,026 |  |  | 2,026 |  |  | 1,508 |  |  | 1,508 |  |
| Fire & Security | 1,403 |  |  | 1,403 |  |  | 1,057 |  |  | 1,057 |  |  | 2,707 |  |  | 2,707 |  |  | 2,263 |  |  | 2,263 |  |
| Segment sales | 5,544 |  |  | 5,544 |  |  | 4,048 |  |  | 4,048 |  |  | 10,339 |  |  | 10,339 |  |  | 8,021 |  |  | 8,021 |  |
| Eliminations and other | (104) |  |  | (104) |  |  | (76) |  |  | (76) |  |  | (200) |  |  | (200) |  |  | (161) |  |  | (161) |  |
| Net sales | $ | 5,440 |  |  | $ | 5,440 |  |  | $ | 3,972 |  |  | $ | 3,972 |  |  | $ | 10,139 |  |  | $ | 10,139 |  |  | $ | 7,860 |  |  | $ | 7,860 |  |
| Operating profit |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | $ | 573 |  |  | $ | 582 |  | $ | 358 |  |  | $ | 359 |  |  | $ | 938 |  |  | $ | 951 |  |  | $ | 525 |  |  | $ | 601 |  |
| Refrigeration | 123 |  |  | 126 |  | 61 |  |  | 64 |  |  | 250 |  |  | 255 |  |  | 160 |  |  | 163 |  |
| Fire & Security | 148 |  |  | 169 |  | 106 |  |  | 112 |  |  | 298 |  |  | 333 |  |  | 226 |  |  | 238 |  |
| Segment operating profit | 844 |  |  | 877 |  | 525 |  |  | 535 |  |  | 1,486 |  |  | 1,539 |  |  | 911 |  |  | 1,002 |  |
| Eliminations and other | (23) |  |  | (21) |  | (56) |  |  | (36) |  |  | (63) |  |  | (46) |  |  | (91) |  |  | (31) |  |
| General corporate expenses | (38) |  |  | (35) |  | (27) |  |  | (23) |  |  | (69) |  |  | (64) |  |  | (63) |  |  | (59) |  |
| Operating profit | $ | 783 |  |  | $ | 821 |  | $ | 442 |  |  | $ | 476 |  |  | $ | 1,354 |  |  | $ | 1,429 |  |  | $ | 757 |  |  | $ | 912 |  |
| Operating margin |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HVAC | 18.4 | % |  | 18.7 | % |  | 15.6 | % |  | 15.7 | % |  | 16.7 | % |  | 17.0 | % |  | 12.4 | % |  | 14.1 | % |
| Refrigeration | 12.0 | % |  | 12.3 | % |  | 8.7 | % |  | 9.1 | % |  | 12.3 | % |  | 12.6 | % |  | 10.6 | % |  | 10.8 | % |
| Fire & Security | 10.5 | % |  | 12.0 | % |  | 10.0 | % |  | 10.6 | % |  | 11.0 | % |  | 12.3 | % |  | 10.0 | % |  | 10.5 | % |
| Total Carrier | 14.4 | % |  | 15.1 | % |  | 11.1 | % |  | 12.0 | % |  | 13.4 | % |  | 14.1 | % |  | 9.6 | % |  | 11.6 | % |

[0001783180-21-000049:8k_2_02:75]
10

[0001783180-21-000049:8k_2_02:76]
Carrier Global Corporation

[0001783180-21-000049:8k_2_02:77]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP)

[0001783180-21-000049:8k_2_02:78]
Operating Profit

[0001783180-21-000049:8k_2_02:79]
|  |  | (Unaudited) |  |
|  |  | For the Three Months Ended |  | For the Six Months Ended |  |
|  | June 30, |  | June 30, |  |
| (dollars in millions - Income (Expense)) | 2021 |  | 2020 |  | 2021 |  | 2020 |  |
| HVAC |  |  |  |  |  |
|  | Net sales | $ | 3,120 |  |  | $ | 2,291 |  |  | $ | 5,606 |  |  | $ | 4,250 |  |  |
|  | Operating profit | $ | 573 |  |  | $ | 358 |  |  | $ | 938 |  |  | $ | 525 |  |  |
|  | Restructuring | (7) |  |  | (1) |  |  | (11) |  |  | (3) |  |  |
|  | Impairment of joint venture investment | — |  |  | — |  |  | — |  |  | (71) |  |  |
|  | Separation costs | — |  |  | — |  |  | — |  |  | (2) |  |  |
|  | Giwee acquisition-related costs | (2) |  |  | — |  |  | (2) |  |  | — |  |  |
|  | Adjusted operating profit | $ | 582 |  |  | $ | 359 |  |  | $ | 951 |  |  | $ | 601 |  |  |
| Refrigeration |  |  |  |  |  |  |  |  |
|  | Net sales | $ | 1,021 |  |  | $ | 700 |  |  | $ | 2,026 |  |  | $ | 1,508 |  |  |
|  | Operating profit | $ | 123 |  |  | $ | 61 |  |  | $ | 250 |  |  | $ | 160 |  |  |
|  | Restructuring | (3) |  |  | (3) |  |  | (5) |  |  | (3) |  |  |
|  | Adjusted operating profit | $ | 126 |  |  | $ | 64 |  |  | $ | 255 |  |  | $ | 163 |  |  |
| Fire & Security |  |  |  |  |  |  |  |  |
|  | Net sales | $ | 1,403 |  |  | $ | 1,057 |  |  | $ | 2,707 |  |  | $ | 2,263 |  |  |
|  | Operating profit | $ | 148 |  |  | $ | 106 |  |  | $ | 298 |  |  | $ | 226 |  |  |
|  | Restructuring | (9) |  |  | (6) |  |  | (20) |  |  | (9) |  |  |
|  | Separation costs | — |  |  | — |  |  | — |  |  | (3) |  |  |
|  | Chubb transaction costs | (12) |  |  | — |  |  | (15) |  |  | — |  |  |
|  | Adjusted operating profit | $ | 169 |  |  | $ | 112 |  |  | $ | 333 |  |  | $ | 238 |  |  |
| General Corporate Expenses and Eliminations and Other |  |  |  |  |  |  |  |  |
|  | Net sales | $ | (104) |  |  | $ | (76) |  |  | $ | (200) |  |  | $ | (161) |  |  |
|  | Operating profit | $ | (61) |  |  | $ | (83) |  |  | $ | (132) |  |  | $ | (154) |  |  |
|  | Restructuring | (2) |  |  | (1) |  |  | (3) |  |  | (1) |  |  |
|  | Separation costs | (3) |  |  | (23) |  |  | (19) |  |  | (63) |  |  |
|  | Adjusted operating profit | $ | (56) |  |  | $ | (59) |  |  | $ | (110) |  |  | $ | (90) |  |  |
| Carrier |  |  |  |  |  |  |  |  |
|  | Net sales | $ | 5,440 |  |  | $ | 3,972 |  |  | $ | 10,139 |  |  | $ | 7,860 |  |  |
|  | Operating profit | $ | 783 |  |  | $ | 442 |  | $ | 1,354 |  |  | $ | 757 |  |
|  | Total restructuring costs | (21) |  |  | (11) |  |  | (39) |  |  | (16) |  |  |
|  | Total non-recurring and non-operational items | (17) |  |  | (23) |  |  | (36) |  |  | (139) |  |  |
|  | Adjusted operating profit | $ | 821 |  |  | $ | 476 |  |  | $ | 1,429 |  |  | $ | 912 |  |  |

[0001783180-21-000049:8k_2_02:80]
11

[0001783180-21-000049:8k_2_02:81]
Carrier Global Corporation

[0001783180-21-000049:8k_2_02:82]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-21-000049:8k_2_02:83]
Net Income, Earnings Per Share, and Effective Tax Rate

[0001783180-21-000049:8k_2_02:84]
|  | (Unaudited) |
|  | For the Three Months Ended June 30, 2021 |  | For the Six Months Ended June 30, 2021 |
| (In millions) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 5,440 |  |  | $ | — |  |  | $ | 5,440 |  |  | $ | 10,139 |  |  | $ | — |  |  | $ | 10,139 |  |
| Operating profit | 783 |  |  | 38 |  | a | 821 |  |  | 1,354 |  |  | 75 |  | a | 1,429 |  |
| Operating margin | 14.4 | % |  |  |  | 15.1 | % |  | 13.4 | % |  |  |  | 14.1 | % |
| Income from operations before income taxes | 731 |  |  | 38 |  | a,b | 769 |  |  | 1,227 |  |  | 94 |  | a,b | 1,321 |  |
| Income tax expense | (234) |  |  | 42 |  | c | (192) |  |  | (338) |  |  | 29 |  | c | (309) |  |
| Income tax rate | 32.0 | % |  |  |  | 25.0 | % |  | 27.5 | % |  |  |  | 23.4 | % |
| Net income attributable to common shareowners | $ | 487 |  |  | $ | 80 |  |  | $ | 567 |  |  | $ | 871 |  |  | $ | 123 |  |  | $ | 994 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 21 |  | a |  |  |  |  | $ | 39 |  | a |  |
| Separation costs |  |  | 3 |  | a |  |  |  |  | 19 |  | a |  |
| Debt prepayment costs |  |  | — |  | b |  |  |  |  | 19 |  | b |  |
| Giwee acquisition-related costs |  |  | 2 |  | a |  |  |  |  | 2 |  | a |  |
| Chubb transaction costs |  |  | 12 |  | a |  |  |  |  | 15 |  | a |  |
| Total adjustments |  |  | $ | 38 |  |  |  |  |  |  | $ | 94 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (1) |  |  |  |  |  |  | $ | (14) |  |  |  |
| Tax specific adjustments |  |  | 43 |  |  |  |  |  |  | 43 |  |  |  |
| Total tax adjustments |  |  | $ | 42 |  | c |  |  |  |  | $ | 29 |  | c |  |
| Shares outstanding - Diluted | 890.9 |  |  |  |  | 890.9 |  |  | 890.4 |  |  |  |  | 890.4 |  |
| Earnings per share - Diluted | $ | 0.55 |  |  |  |  | $ | 0.64 |  |  | $ | 0.98 |  |  |  |  | $ | 1.12 |  |

[0001783180-21-000049:8k_2_02:85]
12

[0001783180-21-000049:8k_2_02:86]
Carrier Global Corporation

[0001783180-21-000049:8k_2_02:87]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-21-000049:8k_2_02:88]
Net Income, Earnings Per Share, and Effective Tax Rate

[0001783180-21-000049:8k_2_02:89]
|  | (Unaudited) |
|  | For the Three Months Ended June 30, 2020 |  | For the Six Months Ended June 30, 2020 |
| (In millions) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 3,972 |  |  | $ | — |  |  | $ | 3,972 |  |  | $ | 7,860 |  |  | $ | — |  |  | $ | 7,860 |  |
| Operating profit | 442 |  |  | 34 |  | a | 476 |  |  | 757 |  |  | 155 |  | a | 912 |  |
| Operating margin | 11.1 | % |  |  |  | 12.0 | % |  | 9.6 | % |  |  |  | 11.6 | % |
| Income from operations before income taxes | 375 |  |  | 34 |  | a,b | 409 |  |  | 670 |  |  | 160 |  | a,b | 830 |  |
| Income tax expense | (106) |  |  | (9) |  | c | (115) |  |  | (299) |  |  | 75 |  | c | (224) |  |
| Income tax rate | 28.2 | % |  |  |  | 28.0 | % |  | 44.6 | % |  |  |  | 27.0 | % |
| Net income attributable to common shareowners | $ | 261 |  |  | $ | 25 |  |  | $ | 286 |  |  | $ | 357 |  |  | $ | 235 |  |  | $ | 592 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 11 |  | a |  |  |  |  | $ | 16 |  | a |  |
| Impairment of equity method investment |  |  | — |  | a |  |  |  |  | 71 |  | a |  |
| Separation costs |  |  | 23 |  | a |  |  |  |  | 68 |  | a |  |
| Debt issuance costs |  |  | — |  | b |  |  |  |  | 5 |  | b |  |
| Total adjustments |  |  | $ | 34 |  |  |  |  |  |  | $ | 160 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (9) |  |  |  |  |  |  | $ | (22) |  |  |  |
| Tax specific adjustments |  |  | — |  |  |  |  |  |  | 97 |  |  |  |
| Total tax adjustments |  |  | $ | (9) |  | c |  |  |  |  | $ | 75 |  | c |  |
| Shares outstanding - Diluted | 870.9 |  |  |  |  | 870.9 |  |  | 870.9 |  |  |  |  | 870.9 |  |
| Earnings per share - Diluted | $ | 0.30 |  |  |  |  | $ | 0.33 |  |  | $ | 0.41 |  |  |  |  | $ | 0.68 |  |

[0001783180-21-000049:8k_2_02:90]
13

[0001783180-21-000049:8k_2_02:91]
Carrier Global Corporation

[0001783180-21-000049:8k_2_02:92]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-21-000049:8k_2_02:93]
Components of Changes in Net Sales

[0001783180-21-000049:8k_2_02:94]
| Three Months Ended June 30, 2021 Compared with Three Months Ended June 30, 2020 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 32 | % |  | 3 | % |  | 1 | % |  | — | % |  | 36 | % |
| Refrigeration | 38 | % |  | 8 | % |  | — | % |  | — | % |  | 46 | % |
| Fire & Security | 25 | % |  | 8 | % |  | — | % |  | — | % |  | 33 | % |
| Consolidated | 31 | % |  | 5 | % |  | 1 | % |  | — | % |  | 37 | % |

[0001783180-21-000049:8k_2_02:95]
| Six Months Ended June 30, 2021 Compared with Six Months Ended June 30, 2020 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| HVAC | 28 | % |  | 3 | % |  | 1 | % |  | — | % |  | 32 | % |
| Refrigeration | 28 | % |  | 6 | % |  | — | % |  | — | % |  | 34 | % |
| Fire & Security | 13 | % |  | 7 | % |  | — | % |  | — | % |  | 20 | % |
| Consolidated | 24 | % |  | 5 | % |  | — | % |  | — | % |  | 29 | % |

[0001783180-21-000049:8k_2_02:96]
Free Cash Flow Reconciliation

[0001783180-21-000049:8k_2_02:97]
|  |  | (Unaudited) |
|  |  | Q1 |  | Q2 |  | Q3 |  | Q4 |  | FY |  | Q1 |  | Q2 |
| (dollars in millions) |  | 2020 |  | 2020 |  | 2020 |  | 2020 |  | 2020 |  | 2021 |  | 2021 |
| Net cash flows provided by operating activities |  | $ | 47 |  |  | $ | 509 |  |  | $ | 937 |  |  | $ | 199 |  |  | $ | 1,692 |  |  | $ | 184 |  |  | $ | 561 |  |
| Less: Capital expenditures |  | 48 |  |  | 46 |  |  | 57 |  |  | 161 |  | 312 |  |  | 53 |  |  | 79 |  |
| Free cash flow |  | $ | (1) |  |  | $ | 463 |  |  | $ | 880 |  |  | $ | 38 |  |  | $ | 1,380 |  |  | $ | 131 |  |  | $ | 482 |  |

[0001783180-21-000049:8k_2_02:98]
Net Debt Reconciliation

[0001783180-21-000049:8k_2_02:99]
|  |  | (Unaudited) |
|  |  | As of |
| (dollars in millions) |  | June 30, 2021 |  | December 31, 2020 |
| Long-term debt |  | $ | 9,600 |  |  | $ | 10,036 |  |
| Current portion of long-term debt |  | 125 |  |  | 191 |  |
| Less: Cash and cash equivalents |  | 2,630 |  |  | 3,115 |  |
| Net debt |  | $ | 7,095 |  |  | $ | 7,112 |  |

[0001783180-21-000049:8k_2_02:100]
14
