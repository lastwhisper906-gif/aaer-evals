# CARR 8-K — 0001783180-26-000030 filed 2026-07-28

## item codes, every 8-K on or before 2026-07-28

- 2026-07-28 0001783180-26-000030 — 2.02, 9.01
- 2026-07-24 0000950142-26-002161 — 5.02, 9.01
- 2026-04-30 0001783180-26-000023 — 2.02, 9.01
- 2026-04-16 0000950142-26-001146 — 5.07
- 2026-02-05 0001783180-26-000005 — 2.02
- 2025-10-28 0001783180-25-000063 — 2.02, 7.01, 9.01
- 2025-09-04 0000950142-25-002375 — 5.02
- 2025-07-29 0001783180-25-000058 — 8.01, 9.01
- 2025-07-29 0001783180-25-000047 — 2.02, 9.01
- 2025-06-05 0000950142-25-001575 — 7.01
- 2025-05-01 0001783180-25-000028 — 2.02, 7.01, 9.01
- 2025-04-17 0000950142-25-001103 — 5.02
- 2025-04-11 0001783180-25-000021 — 5.02, 5.07, 9.01
- 2025-02-11 0001783180-25-000006 — 2.02, 9.01
- 2025-01-15 0000950142-25-000133 — 5.02, 9.01
- 2024-12-20 0001783180-24-000093 — 1.01, 1.02, 2.03, 9.01
- 2024-12-03 0000950142-24-002874 — 5.02
- 2024-12-02 0000950142-24-002865 — 7.01, 9.01
- 2024-11-08 0000950142-24-002699 — 1.01, 2.03, 9.01
- 2024-10-28 0000950142-24-002640 — 8.01
- 2024-10-28 0000950142-24-002638 — 8.01
- 2024-10-24 0001783180-24-000084 — 2.02, 7.01, 9.01
- 2024-10-18 0000950142-24-002601 — 1.01
- 2024-08-15 0001140361-24-037426 — 7.01, 9.01
- 2024-07-25 0001783180-24-000075 — 2.02, 9.01
- 2024-06-21 0001783180-24-000069 — 5.02
- 2024-06-21 0000950142-24-001676 — 5.02
- 2024-06-07 0001783180-24-000062 — 5.02, 5.03, 9.01
- 2024-06-03 0000950142-24-001538 — 1.02, 7.01, 9.01
- 2024-05-17 0001783180-24-000049 — 1.01, 1.02, 2.03, 9.01
- 2024-04-25 0001783180-24-000042 — 2.02, 9.01
- 2024-04-19 0001783180-24-000035 — 5.07, 9.01
- 2024-04-19 0000950142-24-001162 — 5.07 — amendment of 0001783180-24-000035
- 2024-02-06 0001783180-24-000007 — 2.02, 9.01
- 2024-02-01 0000950142-24-000264 — 5.02
- 2024-01-02 0001140361-24-000034 — 1.01, 2.01, 2.03, 5.02, 7.01, 9.01
- 2023-12-13 0001140361-23-057415 — 1.01, 9.01
- 2023-12-08 0001140361-23-056751 — 7.01, 9.01
- 2023-11-30 0000950142-23-002884 — 1.01, 2.03, 8.01, 9.01
- 2023-11-16 0000950142-23-002788 — 8.01, 9.01
- 2023-11-13 0001140361-23-052667 — 7.01, 8.01, 9.01
- 2023-10-26 0001783180-23-000063 — 2.02, 9.01
- 2023-07-27 0001783180-23-000053 — 2.02, 9.01
- 2023-06-12 0000950142-23-001664 — 5.02
- 2023-05-25 0000950142-23-001541 — 1.01, 1.02, 2.03, 9.01
- 2023-04-26 0000950142-23-001205 — 1.01, 9.01
- 2023-04-25 0001783180-23-000036 — 2.02, 7.01, 9.01
- 2023-04-25 0000950142-23-001199 — 7.01, 8.01, 9.01
- 2023-04-21 0001783180-23-000032 — 5.07, 9.01
- 2023-02-07 0001783180-23-000010 — 2.02, 9.01
- 2022-10-27 0001783180-22-000054 — 2.02, 7.01, 9.01
- 2022-09-29 0000950142-22-002805 — 5.02, 9.01
- 2022-07-28 0001783180-22-000045 — 2.02, 9.01
- 2022-04-28 0001783180-22-000032 — 2.02, 9.01
- 2022-04-15 0001783180-22-000024 — 5.07, 9.01
- 2022-02-08 0001783180-22-000008 — 2.02, 9.01
- 2022-02-07 0000950142-22-000510 — 8.01, 9.01
- 2022-01-03 0000950142-22-000023 — 8.01, 9.01
- 2021-12-17 0001783180-21-000071 — 5.02, 7.01, 9.01
- 2021-11-23 0001783180-21-000068 — 5.03, 9.01
- 2021-10-28 0001783180-21-000062 — 2.02, 9.01
- 2021-08-27 0001783180-21-000056 — 8.01
- 2021-07-30 0001783180-21-000053 — 1.01
- 2021-07-29 0001783180-21-000049 — 2.02, 8.01, 9.01
- 2021-07-27 0000950142-21-002448 — 8.01, 9.01
- 2021-07-15 0000950142-21-002362 — 5.02, 9.01
- 2021-06-09 0000950142-21-001885 — 5.02, 9.01
- 2021-04-29 0001783180-21-000029 — 2.02, 9.01
- 2021-04-22 0001140361-21-013889 — 5.02, 9.01
- 2021-04-20 0001783180-21-000021 — 5.07, 9.01
- 2021-04-19 0000950142-21-001308 — 8.01, 9.01
- 2021-02-09 0001783180-21-000009 — 2.02, 9.01
- 2021-02-05 0001140361-21-003513 — 8.01, 9.01
- 2020-12-23 0001140361-20-029419 — 7.01, 9.01
- 2020-12-22 0001140361-20-029097 — 8.01
- 2020-12-14 0001140361-20-028246 — 5.03, 9.01
- 2020-12-07 0001140361-20-027515 — 1.01, 7.01, 9.01
- 2020-10-29 0001783180-20-000063 — 2.02, 9.01
- 2020-10-19 0001140361-20-023241 — 5.02, 7.01, 9.01
- 2020-09-23 0001140361-20-021220 — 8.01, 9.01
- 2020-09-22 0001140361-20-021124 — 8.01, 9.01
- 2020-07-30 0001783180-20-000045 — 2.02, 9.01
- 2020-06-19 0001140361-20-014325 — 1.01, 2.03, 9.01
- 2020-06-16 0001140361-20-013880 — 8.01, 9.01
- 2020-06-03 0001140361-20-012939 — 1.01, 9.01
- 2020-05-08 0001783180-20-000013 — 2.02, 9.01
- 2020-04-03 0001140361-20-007888 — 1.01, 5.02, 5.03, 5.05, 7.01, 9.01
- 2020-03-16 0001140361-20-005868 — 8.01, 9.01

## late-filing notifications on or before 2026-07-28

- none on or before 2026-07-28

## item 2.02 — earnings release, exhibit 99.1

[0001783180-26-000030:8k_2_02:1]
EX-99
2
a99-q22026earningsexhibit.htm
EX-99

[0001783180-26-000030:8k_2_02:2]
Document

[0001783180-26-000030:8k_2_02:3]
Exhibit 99

[0001783180-26-000030:8k_2_02:4]
Carrier Reports Second Quarter 2026 Results

[0001783180-26-000030:8k_2_02:5]
Increases Full-year Outlook for Sales, Adj. Op. Profit and Adj. EPS

[0001783180-26-000030:8k_2_02:6]
•Total company orders1 up ~40%; Commercial HVAC1 up ~65%; data centers up >300%

[0001783180-26-000030:8k_2_02:7]
•Net sales up 4%; organic sales up 3%

[0001783180-26-000030:8k_2_02:8]
•GAAP EPS of $0.60 and adjusted EPS of $0.86

[0001783180-26-000030:8k_2_02:9]
•Net cash flows from operating activities of $927 million and free cash flow of $810 million

[0001783180-26-000030:8k_2_02:10]
•Returned ~$640 million to shareholders through dividends and repurchases

[0001783180-26-000030:8k_2_02:11]
•Raises full year outlook to ~$23B sales, ~$3.5B adj. op. profit and ~$2.90 adj. EPS

[0001783180-26-000030:8k_2_02:12]
◦Includes ~($0.05) adj. EPS impact from NORESCO exit and new U.S. factory costs

[0001783180-26-000030:8k_2_02:13]
PALM BEACH GARDENS, Fla., July 28, 2026 – Carrier Global Corporation (NYSE: CARR), global leader in intelligent climate and energy solutions, today reported better than expected financial results for the second quarter of 2026.

[0001783180-26-000030:8k_2_02:14]
“We ended the first half with a stronger than expected second quarter, including better sales, adjusted EPS and free cash flow,” said Chairman & CEO David Gitlin. “Organic sales returned to growth earlier than expected, up 3%, driven by strong performance in our CSA segment. Improving Residential and Light Commercial markets in CSA and CSE are encouraging. Orders were very strong globally in the second quarter supported by continued data center demand. Given record backlog levels and our year-to-date performance, we are raising our full-year outlook and now expect sales of about $23 billion and adjusted EPS of ~$2.90."

[0001783180-26-000030:8k_2_02:15]
1 Excludes NORESCO (exit announced) and Riello (exit completed on July 1, 2026)

[0001783180-26-000030:8k_2_02:16]
1

[0001783180-26-000030:8k_2_02:17]
Second Quarter 2026 Results

[0001783180-26-000030:8k_2_02:18]
Total Company

[0001783180-26-000030:8k_2_02:19]
|  | (Unaudited) |
|  | Three Months Ended June 30 |  |
| (In millions) | 2026 | 2025 | Change |  |  |  |
| Net sales | $ | 6,351 |  | $ | 6,113 |  | 4 | % |  |  |  |
| Organic sales | 3 | % |  |  |  |  |  |
| Operating profit | $ | 825 |  | $ | 903 |  | (9) | % |  |  |  |
| Operating margin | 13.0 | % | 14.8 | % | (180) bps |  |  |  |
| Adjusted operating profit | $ | 1,095 |  | $ | 1,166 |  | (6) | % |  |  |  |
| Adjusted operating margin | 17.2 | % | 19.1 | % | (190) bps |  |  |  |
| Diluted earnings per share: |  |  |  |  |  |  |
| Continuing operations | $ | 0.60 |  | $ | 0.70 |  | (14) | % |  |  |  |
| Continuing operations - Adjusted | $ | 0.86 |  | $ | 0.92 |  | (7) | % |  |  |  |

[0001783180-26-000030:8k_2_02:20]
Carrier’s second-quarter sales of $6.4 billion increased 4% compared to the prior year. Organic sales increased 3% and foreign currency translation was a tailwind of 1%.

[0001783180-26-000030:8k_2_02:21]
GAAP operating profit of $825 million in the quarter declined 9% from last year, driven primarily by the Climate Solutions Americas (CSA) and Climate Solutions Asia Pacific, Middle East and Africa segments (CSAME).  
    Adjusted operating margin of 17.2% was down 190 basis points from last year, predominantly due to favorable volume and productivity more than offset by the impact of increased input costs and unfavorable business mix.

[0001783180-26-000030:8k_2_02:22]
Net earnings from continuing operations were $501 million and adjusted net earnings from continuing operations were $721 million. GAAP EPS from continuing operations was $0.60 and adjusted EPS was $0.86, down 14% and 7% year-over-year, respectively. The declines were primarily driven by lower operating profit and a higher effective tax rate, partially offset by the benefit of a lower share count.

[0001783180-26-000030:8k_2_02:23]
2

[0001783180-26-000030:8k_2_02:24]
Climate Solutions Americas (CSA)

[0001783180-26-000030:8k_2_02:25]
|  | (Unaudited) |
|  | Three Months Ended June 30 |  |
| (In millions) | 2026 | 2025 | Change |  |  |  |
| Net sales | $ | 3,372 |  | $ | 3,252 |  | 4 | % |  |  |  |
| Organic sales | 4 | % |  |  |  |  |  |
| Segment operating profit | $ | 823 |  | $ | 879 |  | (6) | % |  |  |  |
| Segment operating margin | 24.4 | % | 27.0 | % | (260) bps |  |  |  |

[0001783180-26-000030:8k_2_02:26]
CSA segment sales grew 4%. Organic sales were up 4% driven by Residential and Light Commercial (RLC), up 9% and 10% respectively, partially offset by Commercial1, down 8% due to the timing of customer deliveries.

[0001783180-26-000030:8k_2_02:27]
Segment operating margin decreased 260 basis points as revenue growth mainly related to price which was more than offset by unfavorable mix and input costs.

[0001783180-26-000030:8k_2_02:28]
Climate Solutions Europe (CSE)

[0001783180-26-000030:8k_2_02:29]
|  | (Unaudited) |
|  | Three Months Ended June 30 |  |
| (In millions) | 2026 | 2025 | Change |  |  |  |
| Net sales | $ | 1,324 |  | $ | 1,253 |  | 6 | % |  |  |  |
| Organic sales | 3 | % |  |  |  |  |  |
| Segment operating profit | $ | 95 |  | $ | 99 |  | (4) | % |  |  |  |
| Segment operating margin | 7.2 | % | 7.9 | % | (70) bps |  |  |  |

[0001783180-26-000030:8k_2_02:30]
CSE segment sales increased 6%. Organic sales were up 3% with RLC up high-single digits and Commercial down mid-single digits.

[0001783180-26-000030:8k_2_02:31]
Segment operating margin decreased 70 basis points driven by volume growth and favorable price / cost more than offset by unfavorable mix and selling investments.

[0001783180-26-000030:8k_2_02:32]
1 Excludes NORESCO

[0001783180-26-000030:8k_2_02:33]
3

[0001783180-26-000030:8k_2_02:34]
Climate Solutions Asia Pacific, Middle East & Africa (CSAME)

[0001783180-26-000030:8k_2_02:35]
|  | (Unaudited) |
|  | Three Months Ended June 30 |  |
| (In millions) | 2026 | 2025 | Change |  |  |  |
| Net sales | $ | 917 |  | $ | 882 |  | 4 | % |  |  |  |
| Organic sales | 4 | % |  |  |  |  |  |
| Segment operating profit | $ | 108 |  | $ | 135 |  | (20) | % |  |  |  |
| Segment operating margin | 11.8 | % | 15.3 | % | (350) bps |  |  |  |

[0001783180-26-000030:8k_2_02:36]
CSAME segment sales increased 4%. Organic sales were up 4% driven by double-digit growth in India, the Middle East, Southeast Asia and Australia partially offset by continued pressure in RLC in China.

[0001783180-26-000030:8k_2_02:37]
Segment operating margin decreased 350 basis points driven by volume growth and productivity more than offset by unfavorable mix and lower JV income due to the impacts from the Middle East conflict.

[0001783180-26-000030:8k_2_02:38]
Climate Solutions Transportation (CST)

[0001783180-26-000030:8k_2_02:39]
|  | (Unaudited) |
|  | Three Months Ended June 30 |  |
| (In millions) | 2026 | 2025 | Change |  |  |  |
| Net sales | $ | 738 |  | $ | 726 |  | 2 | % |  |  |  |
| Organic sales | — | % |  |  |  |  |  |
| Segment operating profit | $ | 118 |  | $ | 128 |  | (8) | % |  |  |  |
| Segment operating margin | 16.0 | % | 17.6 | % | (160) bps |  |  |  |

[0001783180-26-000030:8k_2_02:40]
CST sales increased 2% driven by strong growth in Container. Organic sales were flat as strong Container growth of ~40% was offset by low-teens declines in Global Truck and Trailer.

[0001783180-26-000030:8k_2_02:41]
Segment operating margin declined 160 basis points, due to unfavorable mix from lower Global Truck and Trailer volume offset by higher Container volume.

[0001783180-26-000030:8k_2_02:42]
4

[0001783180-26-000030:8k_2_02:43]
Cash Flow

[0001783180-26-000030:8k_2_02:44]
|  |  | (Unaudited) |  | (Unaudited) |
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Net cash flows provided by operating activities |  | $ | 927 |  |  | $ | 649 |  |  | $ | 1,006 |  |  | $ | 1,132 |  |
| Less: Capital expenditures |  | (117) |  |  | (81) |  |  | (211) |  |  | (144) |  |
| Free cash flow |  | $ | 810 |  |  | $ | 568 |  |  | $ | 795 |  |  | $ | 988 |  |

[0001783180-26-000030:8k_2_02:45]
Net cash flows generated from operating activities were $927 million and capital expenditures were $117 million, resulting in free cash flow of $810 million.

[0001783180-26-000030:8k_2_02:46]
5

[0001783180-26-000030:8k_2_02:47]
Full-Year 2026 Guidance**

[0001783180-26-000030:8k_2_02:48]
|  | Current Guidance** | Prior Guidance |  |
| Sales | ~$23 billionOrganic* up ~M-HSDFX 1%Net, Acquisitions / Divestitures (2%) ~$225 million and ~$125 million year-over-year revenue headwind from Riello and NORESCO exits, respectively | ~$22 billionOrganic* flat to up LSDFX 1%Net, Acquisitions / Divestitures (1%) ~$250 million year-over-year revenue headwind from Riello exit |  |
| Adjusted Operating Profit* | ~$3.5 billion | ~$3.4 billion |  |
| Adjusted EPS* | ~$2.90 | ~$2.80 |  |
| Free Cash Flow* | ~$2 billion | ~$2 billion |  |

[0001783180-26-000030:8k_2_02:49]
Riello divestiture completed on July 1st. NORESCO divestiture announced.

[0001783180-26-000030:8k_2_02:50]
*Note: When the company provides expectations for organic sales, adjusted operating profit, adjusted EPS and free cash flow on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort. See “Use and Definitions of Non-GAAP Financial Measures” below for additional information.

[0001783180-26-000030:8k_2_02:51]
**As of July 28, 2026

[0001783180-26-000030:8k_2_02:52]
Conference Call

[0001783180-26-000030:8k_2_02:53]
Carrier will host a webcast of its earnings conference call today, Tuesday, July 28, 2026, at 7:30 a.m. ET. To access the webcast, visit the Events & Presentations section of the Carrier Investor Relations site at ir.carrier.com/news-and-events/events-and-presentations. For alternative dial-in information, please contact Carrier investor relations at InvestorRelations@Carrier.com.

[0001783180-26-000030:8k_2_02:54]
6

[0001783180-26-000030:8k_2_02:55]
Cautionary Statement

[0001783180-26-000030:8k_2_02:56]
7

[0001783180-26-000030:8k_2_02:57]
About Carrier

[0001783180-26-000030:8k_2_02:58]
Carrier Global Corporation, global leader in intelligent climate and energy solutions, is committed to creating innovations that bring comfort, safety and sustainability to life. Through cutting-edge advancements in climate solutions such as temperature control, air quality and transportation, we improve lives, empower critical industries and ensure the safe transport of food, life-saving medicines and more. Since inventing modern air conditioning in 1902, we lead with purpose: enhancing the lives we live and the world we share. We continue to lead because of our world-class, inclusive workforce that puts the customer at the center of everything we do. For more information, visit www.carrier.com or follow Carrier on social media at @Carrier.

[0001783180-26-000030:8k_2_02:59]
Carrier. For the World We Share

[0001783180-26-000030:8k_2_02:60]
CARR-IR

[0001783180-26-000030:8k_2_02:61]
Contact:

[0001783180-26-000030:8k_2_02:62]
Investor Relations

[0001783180-26-000030:8k_2_02:63]
Michael Rednor

[0001783180-26-000030:8k_2_02:64]
561-365-2020

[0001783180-26-000030:8k_2_02:65]
InvestorRelations@Carrier.com

[0001783180-26-000030:8k_2_02:66]
Media Inquiries

[0001783180-26-000030:8k_2_02:67]
Kristina Pantelides

[0001783180-26-000030:8k_2_02:68]
561-236-4241

[0001783180-26-000030:8k_2_02:69]
Kristina.Pantelides@Carrier.com

[0001783180-26-000030:8k_2_02:70]
8

[0001783180-26-000030:8k_2_02:71]
SELECTED FINANCIAL DATA, NON-GAAP MEASURES AND DEFINITIONS

[0001783180-26-000030:8k_2_02:72]
Following are tables that present selected financial data of Carrier Global Corporation (“Carrier”). Also included are reconciliations of non-GAAP measures to their most comparable GAAP measures.

[0001783180-26-000030:8k_2_02:73]
Use and Definitions of Non-GAAP Financial Measures

[0001783180-26-000030:8k_2_02:74]
Carrier reports its financial results in accordance with accounting principles generally accepted in the United States ("GAAP"). We supplement the reporting of our financial information determined under GAAP with certain non-GAAP financial information. The non-GAAP information presented provides investors with additional useful information, but should not be considered in isolation or as substitutes for the related GAAP measures. Moreover, other companies may define non-GAAP measures differently, which limits the usefulness of these measures for comparisons with such other companies. We encourage investors to review our financial statements and publicly filed reports in their entirety and not to rely on any single financial measure. A reconciliation of the non-GAAP measures to the corresponding amounts prepared in accordance with GAAP appears in the tables in this Appendix. The tables provide additional information as to the items and amounts that have been excluded from the adjusted measures.

[0001783180-26-000030:8k_2_02:75]
Organic sales, adjusted operating profit, adjusted operating margin, adjusted earnings per share (“EPS”), adjusted effective tax rate and net debt are non-GAAP financial measures and are associated with Carrier's continuing operations unless specifically noted.

[0001783180-26-000030:8k_2_02:76]
Organic sales represents consolidated net sales (a GAAP measure), excluding the impact of foreign currency translation, acquisitions and divestitures completed in the preceding twelve months and other significant items of a nonoperational nature (hereinafter referred to as “other significant items”). Adjusted operating profit represents consolidated operating profit (a GAAP measure), excluding restructuring costs, amortization of acquired intangible assets and other significant items. Adjusted operating margin represents adjusted operating profit as a percentage of consolidated net sales (a GAAP measure). Adjusted EPS represents diluted earnings per share (a GAAP measure), excluding restructuring costs, amortization of acquired intangible assets and other significant items. The adjusted effective tax rate represents the effective tax rate (a GAAP measure), excluding restructuring costs, amortization of acquired intangible assets and other significant items. Net debt represents long-term debt (a GAAP measure) less cash and cash equivalents (a GAAP measure).

[0001783180-26-000030:8k_2_02:77]
Segment operating profit is the measure of profit and loss that the Chief Operating Decision Maker uses to evaluate segment profitability. Segment operating profit represents operating profit (a GAAP measure) adjusted to exclude restructuring costs, amortization of acquired intangible assets and other significant items of a nonoperational nature.

[0001783180-26-000030:8k_2_02:78]
Free cash flow is a non-GAAP financial measure that represents net cash flows provided by continuing operating activities (a GAAP measure) less capital expenditures. Management believes free cash flow is a useful measure of liquidity and an additional basis for assessing Carrier’s ability to fund its activities, including the financing of acquisitions, debt service, repurchases of Carrier's common stock and distribution of earnings to shareowners. Orders are contractual commitments with customers to provide specified goods or services for an agreed upon price and may not be subject to penalty if cancelled.

[0001783180-26-000030:8k_2_02:79]
Price/cost represents the combined impact of realized pricing, cost inflation and productivity actions, including manufacturing efficiencies, sourcing initiatives and certain productivity measures.

[0001783180-26-000030:8k_2_02:80]
When Carrier provides our expectations for organic sales, adjusted operating profit (including on a segment basis), adjusted operating margin (including on a segment basis), adjusted effective tax rate, adjusted EPS, free cash flow, and interest expense, net on a forward-looking basis, a reconciliation of the differences between the non-GAAP expectations and the corresponding GAAP measures generally is not available without unreasonable effort due to potentially high variability, complexity and low visibility as to the items that would be excluded from the GAAP measure in the relevant future period, such as unusual gains and losses, the ultimate outcome of pending litigation, fluctuations in foreign currency exchange rates, the impact and timing of potential acquisitions and divestitures, future restructuring costs, and other structural changes or their probable significance. The variability of the excluded items may have a significant, and potentially unpredictable, impact on our future GAAP results.

[0001783180-26-000030:8k_2_02:81]
9

[0001783180-26-000030:8k_2_02:82]
Carrier Global Corporation

[0001783180-26-000030:8k_2_02:83]
Condensed Consolidated Statement of Operations

[0001783180-26-000030:8k_2_02:84]
|  |  | (Unaudited) |
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions, except per share amounts) |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Net sales |  |  |  |  |  |  |  |  |
| Product sales |  | $ | 5,634 |  |  | $ | 5,477 |  |  | $ | 10,301 |  |  | $ | 10,129 |  |
| Service sales |  | 717 |  |  | 636 |  |  | 1,391 |  |  | 1,202 |  |
| Total Net sales |  | 6,351 |  |  | 6,113 |  |  | 11,692 |  |  | 11,331 |  |
| Costs and expenses |  |  |  |  |  |  |  |  |
| Cost of products sold |  | (4,081) |  |  | (3,867) |  |  | (7,672) |  |  | (7,225) |  |
| Cost of services sold |  | (542) |  |  | (477) |  |  | (1,048) |  |  | (892) |  |
| Research and development |  | (148) |  |  | (161) |  |  | (291) |  |  | (314) |  |
| Selling, general and administrative |  | (810) |  |  | (813) |  |  | (1,672) |  |  | (1,542) |  |
| Total Costs and expenses |  | (5,581) |  |  | (5,318) |  |  | (10,683) |  |  | (9,973) |  |
| Equity method investment net earnings |  | 58 |  |  | 78 |  |  | 89 |  |  | 122 |  |
| Other income (expense), net |  | (3) |  |  | 30 |  |  | (15) |  |  | 52 |  |
| Operating profit |  | 825 |  |  | 903 |  |  | 1,083 |  |  | 1,532 |  |
| Non-service pension benefit (expense) |  | 1 |  |  | — |  |  | 2 |  |  | 1 |  |
| Interest (expense) income, net |  | (105) |  |  | (91) |  |  | (195) |  |  | (173) |  |
| Earnings before income taxes |  | 721 |  |  | 812 |  |  | 890 |  |  | 1,360 |  |
| Income tax (expense) benefit |  | (180) |  |  | (162) |  |  | (84) |  |  | (273) |  |
| Earnings from continuing operations |  | 541 |  |  | 650 |  |  | 806 |  |  | 1,087 |  |
| Discontinued operations, net of tax |  | — |  |  | (17) |  |  | — |  |  | (17) |  |
| Net earnings (loss) |  | 541 |  |  | 633 |  |  | 806 |  |  | 1,070 |  |
| Less: Non-controlling interest in subsidiaries' |  | 40 |  |  | 42 |  |  | 67 |  |  | 67 |  |
| Net earnings (loss) attributable to common shareowners |  | $ | 501 |  |  | $ | 591 |  |  | $ | 739 |  |  | $ | 1,003 |  |
| Amounts attributable to common shareowners: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 501 |  |  | $ | 608 |  |  | $ | 739 |  |  | $ | 1,020 |  |
| Discontinued operations |  | — |  |  | (17) |  |  | — |  |  | (17) |  |
| Net earnings (loss) attributable to common shareowners |  | $ | 501 |  |  | $ | 591 |  |  | $ | 739 |  |  | $ | 1,003 |  |
| Earnings per share |  |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.61 |  |  | $ | 0.71 |  |  | $ | 0.89 |  |  | $ | 1.18 |  |
| Discontinued operations |  | — |  |  | (0.02) |  |  | — |  |  | (0.01) |  |
| Net earnings (loss) |  | $ | 0.61 |  |  | $ | 0.69 |  |  | $ | 0.89 |  |  | $ | 1.17 |  |
| Diluted: |  |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.60 |  |  | $ | 0.70 |  |  | $ | 0.88 |  |  | $ | 1.17 |  |
| Discontinued operations |  | — |  |  | (0.02) |  |  | — |  |  | (0.02) |  |
| Net earnings (loss) |  | $ | 0.60 |  |  | $ | 0.68 |  |  | $ | 0.88 |  |  | $ | 1.15 |  |
| Weighted-average number of shares outstanding |  |  |  |  |  |  |  |  |
| Basic |  | 828.1 |  |  | 854.9 |  |  | 831.5 |  |  | 860.8 |  |
| Diluted |  | 836.5 |  |  | 866.3 |  |  | 839.6 |  |  | 872.3 |  |

[0001783180-26-000030:8k_2_02:85]
10

[0001783180-26-000030:8k_2_02:86]
Carrier Global Corporation

[0001783180-26-000030:8k_2_02:87]
Condensed Consolidated Balance Sheet

[0001783180-26-000030:8k_2_02:88]
|  |  | (Unaudited) |
| (In millions) |  | June 30, 2026 |  | December 31, 2025 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 1,344 |  |  | $ | 1,555 |  |
| Accounts receivable, net |  | 3,246 |  |  | 2,639 |  |
| Inventories, net |  | 2,759 |  |  | 2,483 |  |
| Assets held for sale |  | 815 |  |  | 592 |  |
| Other current assets |  | 1,250 |  |  | 1,264 |  |
| Total current assets |  | 9,414 |  |  | 8,533 |  |
| Future income tax benefits |  | 1,126 |  |  | 1,074 |  |
| Fixed assets, net |  | 3,162 |  |  | 3,165 |  |
| Operating lease right-of-use assets |  | 568 |  |  | 546 |  |
| Intangible assets, net |  | 5,756 |  |  | 6,326 |  |
| Goodwill |  | 15,267 |  |  | 15,501 |  |
| Pension and post-retirement assets |  | 61 |  |  | 56 |  |
| Equity method investments |  | 1,341 |  |  | 1,321 |  |
| Other assets |  | 677 |  |  | 668 |  |
| Total Assets |  | $ | 37,372 |  |  | $ | 37,190 |  |
| Liabilities and Equity |  |  |  |  |
| Accounts payable |  | $ | 3,216 |  |  | $ | 2,702 |  |
| Accrued liabilities |  | 3,963 |  |  | 3,774 |  |
| Liabilities held for sale |  | 414 |  |  | 170 |  |
| Short-term borrowings and current portion of long-term debt |  | 1,638 |  |  | 468 |  |
| Total current liabilities |  | 9,231 |  |  | 7,114 |  |
| Long-term debt |  | 10,314 |  |  | 11,365 |  |
| Future pension and post-retirement obligations |  | 185 |  |  | 192 |  |
| Future income tax obligations |  | 1,622 |  |  | 1,833 |  |
| Operating lease liabilities |  | 442 |  |  | 418 |  |
| Other long-term liabilities |  | 2,106 |  |  | 2,140 |  |
| Total Liabilities |  | 23,900 |  |  | 23,062 |  |
| Equity |  |  |  |  |
| Common stock |  | 10 |  |  | 10 |  |
| Treasury stock |  | (7,550) |  |  | (6,795) |  |
| Additional paid-in capital |  | 8,688 |  |  | 8,665 |  |
| Retained earnings |  | 12,536 |  |  | 12,193 |  |
| Accumulated other comprehensive income (loss) |  | (537) |  |  | (269) |  |
| Non-controlling interest |  | 325 |  |  | 324 |  |
| Total Equity |  | 13,472 |  |  | 14,128 |  |
| Total Liabilities and Equity |  | $ | 37,372 |  |  | $ | 37,190 |  |

[0001783180-26-000030:8k_2_02:89]
11

[0001783180-26-000030:8k_2_02:90]
Carrier Global Corporation

[0001783180-26-000030:8k_2_02:91]
Condensed Consolidated Statement of Cash Flows

[0001783180-26-000030:8k_2_02:92]
(Unaudited)

[0001783180-26-000030:8k_2_02:93]
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Operating Activities |  |  |  |  |  |  |  |  |
| Net earnings (loss) |  | $ | 541 |  |  | $ | 633 |  |  | $ | 806 |  |  | $ | 1,070 |  |
| Discontinued operations, net of tax |  | — |  |  | 17 |  |  | — |  |  | 17 |  |
| Adjustments for non-cash items, net: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  | 314 |  |  | 317 |  |  | 629 |  |  | 620 |  |
| Deferred income tax provision |  | (63) |  |  | (89) |  |  | (242) |  |  | (158) |  |
| Stock-based compensation costs |  | 12 |  |  | 21 |  |  | 33 |  |  | 44 |  |
| Equity method investment net earnings |  | (58) |  |  | (78) |  |  | (89) |  |  | (122) |  |
| (Gain) loss on sale of investments and impairments, net |  | 40 |  |  | (12) |  |  | 37 |  |  | (17) |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  | (142) |  |  | (340) |  |  | (651) |  |  | (702) |  |
| Inventories, net |  | (197) |  |  | (111) |  |  | (335) |  |  | (412) |  |
| Accounts payable and accrued liabilities |  | 280 |  |  | (103) |  |  | 631 |  |  | 378 |  |
| Distributions from equity method investments |  | 39 |  |  | 4 |  |  | 51 |  |  | 81 |  |
| Other operating activities, net |  | 122 |  |  | 5 |  |  | 83 |  |  | (47) |  |
| Net cash flows provided by (used in) continuing operating activities |  | 888 |  |  | 264 |  |  | 953 |  |  | 752 |  |
| Net cash flows provided by (used in) discontinued operating activities |  | 39 |  |  | 385 |  |  | 53 |  |  | 380 |  |
| Net cash flows provided by (used in) operating activities |  | 927 |  |  | 649 |  |  | 1,006 |  |  | 1,132 |  |
| Investing Activities |  |  |  |  |  |  |  |  |
| Capital expenditures |  | (117) |  |  | (81) |  |  | (211) |  |  | (144) |  |
| Investment in businesses, net of cash acquired |  | (31) |  |  | (49) |  |  | (54) |  |  | (61) |  |
| Dispositions of businesses |  | 7 |  |  | — |  |  | 15 |  |  | 8 |  |
| Settlement of derivative contracts, net |  | (29) |  |  | 51 |  |  | 6 |  |  | 87 |  |
| Other investing activities, net |  | — |  |  | (4) |  |  | 9 |  |  | (3) |  |
| Net cash flows provided by (used in) continuing investing activities |  | (170) |  |  | (83) |  |  | (235) |  |  | (113) |  |
| Net cash flows provided by (used in) discontinued investing activities |  | — |  |  | 28 |  |  | — |  |  | 35 |  |
| Net cash flows provided by (used in) investing activities |  | (170) |  |  | (55) |  |  | (235) |  |  | (78) |  |
| Financing Activities |  |  |  |  |  |  |  |  |
| Increase (decrease) in short-term borrowings, net |  | (10) |  |  | (8) |  |  | 361 |  |  | (57) |  |
| Issuance of long-term debt |  | 17 |  |  | 6 |  |  | 39 |  |  | 15 |  |
| Repayment of long-term debt |  | (41) |  |  | (3) |  |  | (57) |  |  | (1,208) |  |
| Repurchases of common stock |  | (439) |  |  | (340) |  |  | (745) |  |  | (1,628) |  |
| Dividends paid on common stock |  | (199) |  |  | (192) |  |  | (400) |  |  | (390) |  |
| Dividends paid to non-controlling interest |  | (64) |  |  | (9) |  |  | (65) |  |  | (9) |  |
| Other financing activities, net |  | (24) |  |  | (1) |  |  | (34) |  |  | (17) |  |
| Net cash flows provided by (used in) continuing financing activities |  | (760) |  |  | (547) |  |  | (901) |  |  | (3,294) |  |
| Net cash flows provided by (used in) discontinued financing activities |  | — |  |  | — |  |  | — |  |  | — |  |
| Net cash flows provided by (used in) financing activities |  | (760) |  |  | (547) |  |  | (901) |  |  | (3,294) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  | 3 |  |  | 51 |  |  | (10) |  |  | 68 |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash, including cash classified in current assets held for sale |  | — |  |  | 98 |  |  | (140) |  |  | (2,172) |  |
| Less: Change in cash balances classified as assets held for sale |  | 27 |  |  | — |  |  | 70 |  |  | — |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  | (27) |  |  | 98 |  |  | (210) |  |  | (2,172) |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | 1,374 |  |  | 1,702 |  |  | 1,557 |  |  | 3,972 |  |
| Cash, cash equivalents and restricted cash, end of period |  | 1,347 |  |  | 1,800 |  |  | 1,347 |  |  | 1,800 |  |
| Less: restricted cash |  | 3 |  |  | 3 |  |  | 3 |  |  | 3 |  |
| Cash and cash equivalents, end of period |  | $ | 1,344 |  |  | $ | 1,797 |  |  | $ | 1,344 |  |  | $ | 1,797 |  |

[0001783180-26-000030:8k_2_02:94]
12

[0001783180-26-000030:8k_2_02:95]
Carrier Global Corporation

[0001783180-26-000030:8k_2_02:96]
Segment Summary

[0001783180-26-000030:8k_2_02:97]
|  | (Unaudited) |
|  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Segment net sales |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | $ | 3,372 |  | $ | 3,252 |  | $ | 5,873 |  | $ | 5,824 |
| Climate Solutions Europe |  | 1,324 |  | 1,253 |  | 2,617 |  | 2,422 |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 917 |  | 882 |  | 1,751 |  | 1,708 |
| Climate Solutions Transportation |  | 738 |  | 726 |  | 1,451 |  | 1,377 |
| Segment net sales |  | $ | 6,351 |  | $ | 6,113 |  | $ | 11,692 |  | $ | 11,331 |
| Segment operating profit |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | $ | 823 |  | $ | 879 |  | $ | 1,196 |  | $ | 1,449 |
| Climate Solutions Europe |  | 95 |  | 99 |  | 184 |  | 204 |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 108 |  | 135 |  | 189 |  | 256 |
| Climate Solutions Transportation |  | 118 |  | 128 |  | 219 |  | 225 |
| Segment operating profit |  | $ | 1,144 |  | $ | 1,241 |  | $ | 1,788 |  | $ | 2,134 |
| Segment operating margin |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | 24.4 | % |  | 27.0 | % |  | 20.4 | % |  | 24.9 | % |
| Climate Solutions Europe |  | 7.2 | % |  | 7.9 | % |  | 7.0 | % |  | 8.4 | % |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 11.8 | % |  | 15.3 | % |  | 10.8 | % |  | 15.0 | % |
| Climate Solutions Transportation |  | 16.0 | % |  | 17.6 | % |  | 15.1 | % |  | 16.3 | % |

[0001783180-26-000030:8k_2_02:98]
13

[0001783180-26-000030:8k_2_02:99]
Components of Changes in Net Sales

[0001783180-26-000030:8k_2_02:100]
| Three Months Ended June 30, 2026 Compared with Three Months Ended June 30, 2025 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| Climate Solutions Americas | 4 | % |  | — | % |  | — | % |  | — | % |  | 4 | % |
| Climate Solutions Europe | 3 | % |  | 3 | % |  | — | % |  | — | % |  | 6 | % |
| Climate Solutions Asia Pacific, Middle East & Africa | 4 | % |  | — | % |  | — | % |  | — | % |  | 4 | % |
| Climate Solutions Transportation | — | % |  | 2 | % |  | — | % |  | — | % |  | 2 | % |
| Consolidated | 3 | % |  | 1 | % |  | — | % |  | — | % |  | 4 | % |

[0001783180-26-000030:8k_2_02:101]
| Six Months Ended June 30, 2026 Compared with Six Months Ended June 30, 2025 |
|  | (Unaudited) |
|  | Factors Contributing to Total % change in Net Sales |
|  | Organic |  | FX Translation |  | Acquisitions / Divestitures, net |  | Other |  | Total |
| Climate Solutions Americas | 1 | % |  | — | % |  | — | % |  | — | % |  | 1 | % |
| Climate Solutions Europe | 1 | % |  | 7 | % |  | — | % |  | — | % |  | 8 | % |
| Climate Solutions Asia Pacific, Middle East & Africa | 1 | % |  | 1 | % |  | 1 | % |  | — | % |  | 3 | % |
| Climate Solutions Transportation | 2 | % |  | 3 | % |  | — | % |  | — | % |  | 5 | % |
| Consolidated | 1 | % |  | 2 | % |  | — | % |  | — | % |  | 3 | % |

[0001783180-26-000030:8k_2_02:102]
14

[0001783180-26-000030:8k_2_02:103]
Carrier Global Corporation

[0001783180-26-000030:8k_2_02:104]
Reconciliations

[0001783180-26-000030:8k_2_02:105]
|  |  | (Unaudited) |
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Reconciliation to Earnings before income taxes |  |  |  |  |  |  |  |  |
| Segment operating profit |  | $ | 1,144 |  |  | $ | 1,241 |  |  | $ | 1,788 |  |  | $ | 2,134 |  |
| Corporate and other |  | (49) |  |  | (75) |  |  | (99) |  |  | (120) |  |
| Restructuring costs |  | (8) |  |  | (47) |  |  | (116) |  |  | (55) |  |
| Amortization of acquired intangible assets |  | (213) |  |  | (214) |  |  | (426) |  |  | (415) |  |
| Acquisition/divestiture-related costs |  | (8) |  |  | (6) |  |  | (18) |  |  | (11) |  |
| Riello impairment |  | (46) |  |  | — |  |  | (46) |  |  | — |  |
| CCR gain |  | — |  |  | 7 |  |  | — |  |  | 7 |  |
| Other |  | 5 |  |  | (3) |  |  | — |  |  | (8) |  |
| Non-service pension (expense) benefit |  | 1 |  |  | — |  |  | 2 |  |  | 1 |  |
| Interest (expense) income, net |  | (105) |  |  | (91) |  |  | (195) |  |  | (173) |  |
| Earnings before income taxes |  | $ | 721 |  |  | $ | 812 |  |  | $ | 890 |  |  | $ | 1,360 |  |

[0001783180-26-000030:8k_2_02:106]
|  |  | (Unaudited) |
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Reconciliation of Segment operating profit to Adjusted operating profit |  |  |  |  |  |  |  |  |
| Climate Solutions Americas |  | $ | 823 |  |  | $ | 879 |  |  | $ | 1,196 |  |  | $ | 1,449 |  |
| Climate Solutions Europe |  | 95 |  |  | 99 |  |  | 184 |  |  | 204 |  |
| Climate Solutions Asia Pacific, Middle East & Africa |  | 108 |  |  | 135 |  |  | 189 |  |  | 256 |  |
| Climate Solutions Transportation |  | 118 |  |  | 128 |  |  | 219 |  |  | 225 |  |
| Segment operating profit |  | $ | 1,144 |  |  | $ | 1,241 |  |  | $ | 1,788 |  |  | $ | 2,134 |  |
| Corporate and other |  | (49) |  |  | (75) |  |  | (99) |  |  | (120) |  |
| Adjusted operating profit |  | $ | 1,095 |  |  | $ | 1,166 |  |  | $ | 1,689 |  |  | $ | 2,014 |  |

[0001783180-26-000030:8k_2_02:107]
15

[0001783180-26-000030:8k_2_02:108]
Carrier Global Corporation

[0001783180-26-000030:8k_2_02:109]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-26-000030:8k_2_02:110]
Net Income, Earnings Per Share and Effective Tax Rate

[0001783180-26-000030:8k_2_02:111]
|  | (Unaudited) |
|  | Three Months Ended June 30, 2026 |  | Six Months Ended June 30, 2026 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 6,351 |  |  | $ | — |  |  | $ | 6,351 |  |  | $ | 11,692 |  |  | $ | — |  |  | $ | 11,692 |  |
| Operating profit | $ | 825 |  |  | 270 |  | a | $ | 1,095 |  |  | $ | 1,083 |  |  | 606 |  | a | $ | 1,689 |  |
| Operating margin | 13.0 | % |  |  |  | 17.2 | % |  | 9.3 | % |  |  |  | 14.4 | % |
| Earnings before income taxes | $ | 721 |  |  | 270 |  | a | $ | 991 |  |  | $ | 890 |  |  | 606 |  | a | $ | 1,496 |  |
| Income tax (expense) benefit | $ | (180) |  |  | (50) |  | b | $ | (230) |  |  | $ | (84) |  |  | (142) |  | b | $ | (226) |  |
| Effective tax rate | 25.0 | % |  |  |  | 23.2 | % |  | 9.4 | % |  |  |  | 15.1 | % |
| Earnings from continuing operations attributable to common shareowners | $ | 501 |  |  | $ | 220 |  |  | $ | 721 |  |  | $ | 739 |  |  | $ | 464 |  |  | $ | 1,203 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 8 |  | a |  |  |  |  | $ | 116 |  | a |  |
| Amortization of acquired intangible assets |  |  | 213 |  | a |  |  |  |  | 426 |  | a |  |
| Acquisition/divestiture-related costs |  |  | 8 |  | a |  |  |  |  | 18 |  | a |  |
| Riello impairment |  |  | 46 |  | a |  |  |  |  | 46 |  | a |  |
| Other |  |  | (5) |  | a |  |  |  |  | — |  | a |  |
| Total adjustments |  |  | $ | 270 |  |  |  |  |  |  | $ | 606 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (50) |  |  |  |  |  |  | $ | (142) |  |  |  |
| Total tax adjustments |  |  | $ | (50) |  | b |  |  |  |  | $ | (142) |  | b |  |
| Diluted shares outstanding | 836.5 |  |  |  |  | 836.5 |  |  | 839.6 |  |  |  |  | 839.6 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.60 |  |  |  |  | $ | 0.86 |  |  | $ | 0.88 |  |  |  |  | $ | 1.43 |  |

[0001783180-26-000030:8k_2_02:112]
16

[0001783180-26-000030:8k_2_02:113]
Carrier Global Corporation

[0001783180-26-000030:8k_2_02:114]
Reconciliation of Reported (GAAP) to Adjusted (Non-GAAP) Results

[0001783180-26-000030:8k_2_02:115]
Net Income, Earnings Per Share and Effective Tax Rate

[0001783180-26-000030:8k_2_02:116]
|  | (Unaudited) |
|  | Three Months Ended June 30, 2025 |  | Six Months Ended June 30, 2025 |
| (In millions, except per share amounts) | Reported |  | Adjustments |  | Adjusted |  | Reported |  | Adjustments |  | Adjusted |
| Net sales | $ | 6,113 |  |  | $ | — |  |  | $ | 6,113 |  |  | $ | 11,331 |  |  | $ | — |  |  | $ | 11,331 |  |
| Operating profit | $ | 903 |  |  | 263 |  | a | $ | 1,166 |  |  | $ | 1,532 |  |  | 482 |  | a | $ | 2,014 |  |
| Operating margin | 14.8 | % |  |  |  | 19.1 | % |  | 13.5 | % |  |  |  | 17.8 | % |
| Earnings before income taxes | $ | 812 |  |  | 263 |  | a | $ | 1,075 |  |  | $ | 1,360 |  |  | 482 |  | a | $ | 1,842 |  |
| Income tax (expense) benefit | $ | (162) |  |  | (75) |  | b | $ | (237) |  |  | $ | (273) |  |  | (133) |  | b | $ | (406) |  |
| Effective tax rate | 20.0 | % |  |  |  | 22.1 | % |  | 20.1 | % |  |  |  | 22.1 | % |
| Earnings from continuing operations attributable to common shareowners | $ | 608 |  |  | $ | 188 |  |  | $ | 796 |  |  | $ | 1,020 |  |  | $ | 349 |  |  | $ | 1,369 |  |
| Summary of Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring costs |  |  | $ | 47 |  | a |  |  |  |  | 55 |  | a |  |
| Amortization of acquired intangible assets |  |  | 214 |  | a |  |  |  |  | $ | 415 |  | a |  |
| Acquisition/divestiture-related costs |  |  | 6 |  | a |  |  |  |  | 11 |  | a |  |
| CCR gain |  |  | (7) |  | a |  |  |  |  | (7) |  | a |  |
| Other |  |  | 3 |  | a |  |  |  |  | 8 |  | a |  |
| Total adjustments |  |  | $ | 263 |  |  |  |  |  |  | $ | 482 |  |  |  |
| Tax effect on adjustments above |  |  | $ | (69) |  |  |  |  |  |  | $ | (127) |  |  |  |
| Tax specific adjustments |  |  | (6) |  |  |  |  |  |  | (6) |  |  |  |
| Total tax adjustments |  |  | $ | (75) |  | b |  |  |  |  | $ | (133) |  | b |  |
| Diluted shares outstanding | 866.3 |  |  |  |  | 866.3 |  |  | 872.3 |  |  |  |  | 872.3 |  |
| Diluted earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.70 |  |  |  |  | $ | 0.92 |  |  | $ | 1.17 |  |  |  |  | $ | 1.57 |  |

[0001783180-26-000030:8k_2_02:117]
17

[0001783180-26-000030:8k_2_02:118]
Free Cash Flow Reconciliation

[0001783180-26-000030:8k_2_02:119]
|  |  | (Unaudited) |
|  |  | Three Months Ended June 30, |  | Six Months EndedJune 30, |
| (In millions) |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Net cash flows provided by operating activities |  | $ | 927 |  |  | $ | 649 |  |  | $ | 1,006 |  |  | $ | 1,132 |  |
| Less: Capital expenditures |  | (117) |  |  | (81) |  |  | (211) |  |  | (144) |  |
| Free cash flow |  | $ | 810 |  |  | $ | 568 |  |  | $ | 795 |  |  | $ | 988 |  |

[0001783180-26-000030:8k_2_02:120]
Net Debt Reconciliation

[0001783180-26-000030:8k_2_02:121]
|  |  | (Unaudited) |
| (In millions) |  | June 30, 2026 |  | December 31, 2025 |
| Long-term debt |  | $ | 10,314 |  |  | $ | 11,365 |  |
| Short-term borrowings and current portion of long-term debt |  | 1,638 |  |  | 468 |  |
| Less: Cash and cash equivalents |  | 1,344 |  |  | 1,555 |  |
| Net debt |  | $ | 10,608 |  |  | $ | 10,278 |  |

[0001783180-26-000030:8k_2_02:122]
18
