# CARR note change history — 0001783180-20-000067 → 0001783180-21-000032


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2021-04-29):
[0001783180-21-000032:note_history:1]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies ("ASC 450"), the Company records accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon the Company's competitive position, results of operations, cash flows or financial condition.

- added (2021-04-29):
[0001783180-21-000032:note_history:2]
Environmental Matters

- added (2021-04-29):
[0001783180-21-000032:note_history:3]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees and the Company periodically reassesses these amounts. Management believes that the likelihood of incurring losses materially in excess of the amounts accrued is remote. The outstanding liabilities for environmental obligations are as follows:

- added (2021-04-29):
[0001783180-21-000032:note_history:4]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| Environmental reserves included in Accrued liabilities |  | $ | 25 |  |  | $ | 26 |  |
| Environmental reserves included in Other long-term liabilities |  | 210 |  |  | 213 |  |
| Total Environmental reserves |  | $ | 235 |  |  | $ | 239 |  |

- added (2021-04-29):
[0001783180-21-000032:note_history:5]
Asbestos Matters

- changed (2021-04-29):
[0001783180-21-000032:note_history:6]
The Company and its consolidated subsidiaries have been named as defendants in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.
  (was, 2020-10-29, similarity 0.6445):
[0001783180-20-000067:note_history:6]
Legal Proceedings.  Asbestos Matters – The Company and its consolidated subsidiaries have been named as defendants in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises.  While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that Carrier no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or were covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

- added (2021-04-29):
[0001783180-21-000032:note_history:7]
The Company had asbestos liabilities and related recoveries as follows:

- added (2021-04-29):
[0001783180-21-000032:note_history:8]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 18 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 225 |  |  | 228 |  |
| Total Asbestos liabilities |  | $ | 243 |  |  | $ | 245 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 6 |  |  | $ | 6 |  |
| Asbestos-related recoveries included in Other assets |  | 96 |  |  | 97 |  |
| Total Asbestos-related recoveries |  | $ | 102 |  |  | $ | 103 |  |

- added (2021-04-29):
[0001783180-21-000032:note_history:9]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. Where no amount within a range of estimates is more likely, the minimum is accrued. These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded an insurance recovery receivable for probable asbestos-related recoveries.

- added (2021-04-29):
[0001783180-21-000032:note_history:10]
UTC Equity Awards Conversion Litigation

- added (2021-04-29):
[0001783180-21-000032:note_history:11]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenges the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. The Complaint asserted that the defendants are liable for breach of certain equity compensation plans and for breach of fiduciary duty and also asserted claims under certain provisions of the Employee Retirement Income Security Act of 1974, as amended. Plaintiffs recently withdrew, with prejudice, their claims against Otis's and Carrier's current Boards of Directors. Carrier believes that the remaining claims against the Company are without merit.

- added (2021-04-29):
[0001783180-21-000032:note_history:12]
Aqueous Film Forming Foam Litigation

- added (2021-04-29):
[0001783180-21-000032:note_history:13]
Aqueous Film Forming Foam ("AFFF") is a firefighting foam developed in the 1970s pursuant to U.S. military specification and used to extinguish certain types of fires primarily at airports and military bases. AFFF was manufactured by several companies, including National Foam and Angus Fire. UTC acquired the National Foam and Angus Fire businesses in 2005 as part of the acquisition of Kidde, which had been operated by Carrier. In 2013, UTC divested the National Foam and Angus Fire businesses to a third party.

- added (2021-04-29):
[0001783180-21-000032:note_history:14]
The Company and many other parties, including the third-party buyer of the National Foam and Angus Fire businesses, have been named as defendants in over 900 cases, including putative class actions and other lawsuits, alleging that the historic use of AFFF caused personal injuries and property damage. Additionally, several state, municipal and water utility plaintiffs have commenced litigation against the same defendants to recover remediation costs related to historic use of AFFF. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation ("MDL") transferred and consolidated all of the AFFF cases pending in the federal courts to the U.S. District Court for the District of South Carolina for pre-trial proceedings.

- added (2021-04-29):
[0001783180-21-000032:note_history:15]
Plaintiffs in the MDL allege that a chemical ingredient in AFFF contains, or breaks down into, compounds known as perflourooctane sulfonate ("PFOS") and perflourooctane acid ("PFOA") that were released into the environment and, in some instances, ultimately leached into drinking water supplies. National Foam and Angus Fire purchased these perflourinated chemical ingredients from third-party chemical manufacturers to manufacture AFFF. Chemicals containing PFOS and PFOA (or their precursors) have also been used for decades by many third parties to manufacture carpets, clothing, fabrics, cookware and other consumer products. The individual plaintiffs in the MDL generally seek compensatory damages for alleged personal injuries, medical monitoring and diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S., state, municipal and water utility plaintiffs in the MDL generally seek damages and costs related to the remediation of public property and water supplies.

- added (2021-04-29):
[0001783180-21-000032:note_history:16]
The Company and other defendants are also party to fewer than 10 cases in state court brought by oil refining companies in the U.S. alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage.

- added (2021-04-29):
[0001783180-21-000032:note_history:17]
The Company and other defendants are also party to an action related to the AFFF manufacturing facility that was operated by National Foam and Angus Fire in which the plaintiff water utility seeks remediation costs related to the alleged contamination of the local water supply.

- added (2021-04-29):
[0001783180-21-000032:note_history:18]
The Company believes that it has meritorious defenses to these claims and the Company is also seeking insurance coverage for these claims. At this time, however, given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or reasonably estimate the damages, if any, to be allocated to the Company, if one or more plaintiffs were to prevail in these cases, and there can be no assurance that any such future exposure will not be material in any period.

- added (2021-04-29):
[0001783180-21-000032:note_history:19]
Income Taxes

- added (2021-04-29):
[0001783180-21-000032:note_history:20]
Under the TMA, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act ("TCJA") transition tax associated with foreign undistributed earnings as of December 31, 2017. As of March 31, 2021, a liability of $72 million, primarily related to the Company's share of the TCJA transition tax associated with foreign undistributed earnings is included within Other long-term liabilities on the accompanying Unaudited Condensed Consolidated Balance Sheet. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

- added (2021-04-29):
[0001783180-21-000032:note_history:21]
Other

- changed (2021-04-29):
[0001783180-21-000032:note_history:22]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its competitive position, results of operations, cash flows or financial condition.
  (was, 2020-10-29, similarity 0.8669):
[0001783180-20-000067:note_history:22]
In the ordinary course of business, Carrier is routinely a defendant in, party to or otherwise subject to pending and threatened legal actions, claims, disputes and proceedings.  These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws.  In some of these proceedings or instances, claims for substantial monetary damages are asserted against the Company and its subsidiaries and could result in fines, penalties, compensatory or treble damages or non-monetary relief. We do not believe that these matters will have a material adverse effect upon our competitive position, results of operations, cash flows or financial condition.

- removed (2021-04-29):
[0001783180-20-000067:note_history:23]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is unable to predict the final outcome of the following matters based on the information currently available except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon our competitive position, results of operations, cash flows or financial condition.

- removed (2021-04-29):
[0001783180-20-000067:note_history:24]
Environmental.  The Company’s operations are subject to environmental regulation by various authorities.  We have accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees, and we periodically reassess these amounts.  Management believes that the likelihood of incurring losses materially in excess of the amounts accrued is remote.  As of September 30, 2020 and December 31, 2019, the outstanding liability for environmental obligations was $233 million and $217 million, respectively, of which $13 million and $14 million, respectively, is included in Accrued liabilities and $220 million and $203 million, respectively, is included in Other long-term liabilities on the accompanying Unaudited Condensed Consolidated Balance Sheet.

- removed (2021-04-29):
[0001783180-20-000067:note_history:25]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that we believe are reasonable and are made with input from outside actuarial experts. As of September 30, 2020, the estimated range of liability to resolve all pending and unasserted potential future asbestos claims through 2059 is approximately $250 million to $290 million. Where no amount within a range of estimates is more likely, the minimum is accrued. We have recorded the minimum amount of $250 million and $255 million, which is principally recorded in Other long-term liabilities on the Unaudited Condensed Consolidated Balance Sheet, as of September 30, 2020 and December 31, 2019, respectively.  These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred.  In addition, the Company has recorded an insurance recovery receivable for probable asbestos-related recoveries of approximately $104 million and $104 million, which is included primarily in Other assets on the Unaudited Condensed Consolidated Balance Sheet, as of September 30, 2020 and December 31, 2019, respectively.

- removed (2021-04-29):
[0001783180-20-000067:note_history:26]
UTC Equity Awards Conversion Litigation. On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint in the United States District Court for the District of Connecticut against UTC, Carrier, and Otis, the former members of the UTC Board of Directors, and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The complaint challenges the method by which UTC equity awards were converted to UTC, Carrier, and Otis equity awards following the separation of UTC into three independent, publicly traded companies on April 3, 2020. The complaint claims that the defendants are liable for breach of certain equity compensation plans and for breach of fiduciary duty, and also asserts claims under certain provisions of Employee Retirement Income Security Act of 1974 ("ERISA"). Carrier believes that the claims against the Company are without merit.

- removed (2021-04-29):
[0001783180-20-000067:note_history:27]
Income Taxes.  As described in Note 1 – Description of the Business, under the TMA the Company is responsible to UTC for its share of the TCJA transition tax associated with foreign undistributed earnings as of December 31, 2017.  As of September 30, 2020, a liability of $72 million, primarily related to our share of TCJA transition tax associated with foreign undistributed earnings is included within Other long-term liabilities on the accompanying Unaudited Condensed Consolidated Balance Sheet.  We believe that the likelihood of incurring losses materially in excess of this amount is remote.

- removed (2021-04-29):
[0001783180-20-000067:note_history:28]
Other.  As described in Note 16 – Guarantees, the Company extends performance and operating cost guarantees beyond the normal warranty and service policies for extended periods on some of its products.  The Company typically accrues its estimate of the liability that may result under these guarantees and for service costs that are probable and can be reasonably estimated.


## us-gaap:ScheduleOfEnvironmentalLossContingenciesBySiteTextBlock (contingencies) — matched_by: no_prior_note, score: 0.0

- added (2021-04-29):
[0001783180-21-000032:note_history:29]
The outstanding liabilities for environmental obligations are as follows:

- added (2021-04-29):
[0001783180-21-000032:note_history:30]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| Environmental reserves included in Accrued liabilities |  | $ | 25 |  |  | $ | 26 |  |
| Environmental reserves included in Other long-term liabilities |  | 210 |  |  | 213 |  |
| Total Environmental reserves |  | $ | 235 |  |  | $ | 239 |  |


## us-gaap:ScheduleOfLossContingenciesByContingencyTextBlock (contingencies) — matched_by: no_prior_note, score: 0.0

- added (2021-04-29):
[0001783180-21-000032:note_history:31]
The Company had asbestos liabilities and related recoveries as follows:

- added (2021-04-29):
[0001783180-21-000032:note_history:32]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 18 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 225 |  |  | 228 |  |
| Total Asbestos liabilities |  | $ | 243 |  |  | $ | 245 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 6 |  |  | $ | 6 |  |
| Asbestos-related recoveries included in Other assets |  | 96 |  |  | 97 |  |
| Total Asbestos-related recoveries |  | $ | 102 |  |  | $ | 103 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2021-04-29):
[0001783180-21-000032:note_history:33]
BASIS OF PRESENTATION
The Unaudited Condensed Consolidated Financial Statements include all accounts of the Company and its wholly-owned and majority-owned subsidiaries in which it has control. All intra-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that the Company controls and consolidates. Certain prior year amounts have been reclassified to conform to the current period presentation.

- added (2021-04-29):
[0001783180-21-000032:note_history:34]
The Company's financial statements for periods prior to the Separation and the Distribution are prepared on a "carve-out" basis and include all amounts directly attributable to the Company. Net cash transfers and other property transferred between UTC and the Company, including related party receivables and payables between the Company and other UTC affiliates, are presented as Net transfers to UTC. In addition, the financial statements include allocations of costs for administrative functions and services performed on behalf of the Company by centralized groups within UTC. All allocations and estimates in the Unaudited Condensed Consolidated Financial Statements are based on assumptions that management believes are reasonable. The Company's financial statements for the periods subsequent to April 3, 2020 are consolidated financial statements based on the reported results of Carrier as a stand-alone company.

- added (2021-04-29):
[0001783180-21-000032:note_history:35]
The Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") is the sole source of authoritative U.S. GAAP other than SEC issued rules and regulations that apply only to SEC registrants. The FASB issues Accounting Standards Updates ("ASU") to communicate changes to the codification. The Company considers the applicability and impact of all ASUs. ASUs not referenced below were assessed and determined to be either not applicable or are not expected to have a material impact on the Unaudited Condensed Consolidated Financial Statements.

- added (2021-04-29):
[0001783180-21-000032:note_history:36]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes ("ASU 2019-12"), which simplifies certain aspects of income tax accounting guidance in ASC 740, reducing the complexity of its application while maintaining or improving the usefulness of the information required to be reported. The ASU eliminates certain exceptions from ASC 740 including: intra-period tax allocation, deferred tax liabilities related to outside basis differences and year-to-date loss in interim periods, among others. ASU 2019-12 was effective for periods beginning after December 15, 2020, including interim periods therein with early adoption permitted. The Company adopted this ASU on January 1, 2021 with no material impact on the Unaudited Condensed Consolidated Financial Statements.

- removed (2021-04-29):
[0001783180-20-000067:note_history:37]
BASIS OF PRESENTATION  
The Unaudited Condensed Consolidated Financial Statements have been prepared in accordance with generally accepted accounting principles in the United States of America ("GAAP") for interim financial information and with the instructions to Form 10-Q and Rule 10-01 of Regulation S-X. Accordingly, they do not include all of the information and notes required by GAAP for complete financial statements.  All significant intra-company accounts and transactions have been eliminated in the preparation of the Unaudited Condensed Consolidated Financial Statements.  Related party transactions between the Company and its equity method investees have not been eliminated.

- removed (2021-04-29):
[0001783180-20-000067:note_history:38]
Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that we control and consolidate.

- removed (2021-04-29):
[0001783180-20-000067:note_history:39]
Certain immaterial amounts presented in the Information Statement have been reclassified to conform to the current period presentation, including the reclassification of the Current portion of long-term debt from Accrued liabilities for 2019 on the accompanying Unaudited Condensed Consolidated Balance Sheet.

- removed (2021-04-29):
[0001783180-20-000067:note_history:40]
The Company's financial statements for periods prior to the Separation and the Distribution are prepared on a "carve-out" basis, as described below.  The Company's financial statements for the period from April 3, 2020 through September 30, 2020 are consolidated financial statements based on the reported results of Carrier as a stand-alone company.

- removed (2021-04-29):
[0001783180-20-000067:note_history:41]
Basis of Presentation Prior to the Separation and the Distribution

- removed (2021-04-29):
[0001783180-20-000067:note_history:42]
For the period prior to the Separation and the Distribution, the Unaudited Condensed Consolidated Financial Statements reflect the Company's financial position, results of operations and cash flows for the periods presented, which were historically managed by UTC. For the periods presented prior to the Separation and the Distribution, the Unaudited Condensed Consolidated Financial Statements are derived from UTC's consolidated financial statements and accounting records.

- removed (2021-04-29):
[0001783180-20-000067:note_history:43]
The Unaudited Condensed Consolidated Statement of Operations includes all revenues and costs directly attributable to Carrier, including costs for facilities, functions and services used by Carrier.  Prior to the Separation, costs for certain functions and services performed by UTC were directly charged to Carrier based on specific identification when possible or based on a reasonable allocation driver such as net sales, headcount, proportionate usage or other allocation methods.  The results of operations include allocations of costs for administrative functions and services performed on behalf of Carrier by centralized groups within UTC and of certain pension and other post-retirement benefit costs (see Note 5 – Related Parties for a description of the allocation methodologies).  All charges and allocations for facilities, functions and services performed by UTC have been deemed settled in cash by Carrier to UTC in the period in which the cost was recorded in the Unaudited Condensed Consolidated Statement of Operations.

- removed (2021-04-29):
[0001783180-20-000067:note_history:44]
Prior to the Separation, UTC used a centralized approach to cash management and the financing of its operations.  Accordingly, none of UTC's cash, third party debt or related interest expense has been allocated to Carrier in the Unaudited Condensed Consolidated Financial Statements for the period prior to the Separation.  However, cash balances primarily associated with certain foreign entities that did not participate in UTC’s cash management program have been included in the Unaudited Condensed Consolidated Financial Statements for periods prior to the Separation.  Transactions between UTC and Carrier are deemed settled immediately through UTC’s Net investment, other than those transactions which have been historically cash-settled and which are reflected in the Unaudited Condensed Consolidated Balance Sheet within Accounts receivable, net and Accounts payable.  The net effect of the deemed settled transactions is reflected in the Unaudited Condensed Consolidated Statement of Cash Flows as Net transfers to UTC within financing activities and in the Unaudited Condensed Consolidated Balance Sheet as UTC’s Net investment (see Note 5 – Related Parties for additional information).

- removed (2021-04-29):
[0001783180-20-000067:note_history:45]
All of the allocations and estimates in the Unaudited Condensed Consolidated Financial Statements are based on assumptions that management believes are reasonable.  However, for the periods prior to the Separation, the Unaudited Condensed Consolidated Financial Statements may not be indicative of the Company's future financial position, results of operations and cash flows or if the Company had been a separate, stand-alone entity during the periods presented.

- removed (2021-04-29):
[0001783180-20-000067:note_history:46]
In June 2016, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. This ASU and its related amendments (collectively, the "Credit Loss Standard") modified the credit loss model to utilize an expected loss methodology in place of an incurred loss methodology for financial instruments, including trade receivables, contract assets, long-term receivables and off-balance sheet credit exposures. The Credit Loss Standard requires consideration of a broader range of information to estimate expected credit losses, including historical information, current conditions and a reasonable forecast period. This ASU requires that the statement of operations reflect the measurement of credit losses for newly recognized financial assets as well as an expected increase or decrease of expected credit losses that have taken place during the period, which may result in earlier recognition.  The Company adopted the Credit Loss Standard effective January 1, 2020, utilizing a modified retrospective approach and its adoption did not have a significant impact on the Company's Unaudited Condensed Consolidated Financial Statements.

- removed (2021-04-29):
[0001783180-20-000067:note_history:47]
In January 2017, the FASB issued ASU 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.  This ASU simplifies how an entity is required to test goodwill for impairment by eliminating Step 2 from the goodwill impairment test. Under this ASU, a goodwill impairment is calculated as the difference between the carrying amount of the reporting unit and its fair value, but not to exceed the carrying amount of the goodwill allocated to that reporting unit.  Additionally, this ASU requires the same impairment testing methodology for all reporting units, even those with a zero or negative carrying amount, and requires an entity to disclose the amount of goodwill allocated to each reporting unit with a zero or negative carrying amount.  The Company adopted this ASU effective January 1, 2020 and its adoption did not have a significant impact on the Company's Unaudited Condensed Consolidated Financial Statements.

- removed (2021-04-29):
[0001783180-20-000067:note_history:48]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework – Changes to the Disclosure Requirements for Fair Value Measurement.  This ASU removes the disclosure requirements for the amount of and reasons for transfers between Level 1 and Level 2 of the fair value hierarchy.  The Company adopted this ASU effective January 1, 2020 and its adoption did not have a significant impact on the Company's Unaudited Condensed Consolidated Financial Statements.

- removed (2021-04-29):
[0001783180-20-000067:note_history:49]
Recently Issued SEC Rules

- removed (2021-04-29):
[0001783180-20-000067:note_history:50]
In May 2020, the SEC issued Final Rule Release No. 33-10786, which amends the financial statement requirements for acquisitions and dispositions of businesses and related pro forma financial information required under SEC Regulation S-X, Rule 3-05. The final rule modifies the significance test required in SEC Regulation S-X, Rule 1-02(w) by raising the significance threshold for reporting dispositions of a business from 10% to 20% and by modifying the calculation of the investment and income tests.  In accordance with Rules 3-09 or 4-08(g), the revised income test will apply to the evaluation of equity method investments for significance.  The Company is currently evaluating the impact of these modifications, which are effective for fiscal years beginning after December 31, 2020.

- removed (2021-04-29):
[0001783180-20-000067:note_history:51]
In August 2020, the SEC issued Final Rule Release No. 33-10825, which amends certain disclosure requirements required by Regulation S-K relating to the description of business (Item 101), legal proceedings (Item 103) and risk factors (Item 105). The amendments to Item 101 will, among other things, allow the Company to provide updates regarding the business based on materiality, if it incorporates by reference disclosure from a previous SEC filing.  The amendment also requires disclosures regarding the registrant’s human capital resources to the extent such disclosures would be material to an understanding of the registrant’s business. The amendments to Item 103 will, among other things, increase the quantitative threshold for disclosing certain environmental proceedings, and the amendments to Item 105 will, among other things, require a risk factor summary if the risk factors section is longer than 15 pages. The Company is currently evaluating the impact of these modifications, which are effective on November 9, 2020.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2021-04-29):
[0001783180-21-000032:note_history:52]
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation is a leading global provider of heating, ventilating, air conditioning ("HVAC"), refrigeration and fire and security solutions. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. In the opinion of management, the accompanying Unaudited Condensed Consolidated Financial Statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (the "SEC"). These unaudited condensed consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for 2020 filed with the SEC on February 9, 2021 (the "2020 Form 10-K").

- added (2021-04-29):
[0001783180-21-000032:note_history:53]
On April 3, 2020, (the "Distribution Date"), United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of the Company into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In connection with the Separation, the Company issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020.

- added (2021-04-29):
[0001783180-21-000032:note_history:54]
In connection with the Separation, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship between the Company, UTC and Otis following the Separation and the Distribution, including a transition services agreement ("TSA"), a tax matters agreement ("TMA"), an employee matters agreement and an intellectual property agreement that cover services such as information technology, tax, finance and human resources. In addition, the Company incurred separation-related costs including employee-related costs, costs to establish certain stand-alone functions, information technology systems, professional service fees and other costs associated with becoming an independent, publicly traded company. These costs are primarily recorded in Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations and totaled $16 million and $45 million for the three months ended March 31, 2021 and 2020, respectively. The TSA expired on March 31, 2021.

- added (2021-04-29):
[0001783180-21-000032:note_history:55]
In early 2020, the World Health Organization declared the outbreak of a respiratory disease known as COVID-19 as a global pandemic. In response, many countries implemented containment and mitigation measures to combat the outbreak, which severely restricted the level of economic activity and caused a significant contraction in the global economy. As a result, the Company temporarily closed or reduced production at manufacturing facilities across the globe to ensure employee safety and instructed non-essential employees to work from home. In addition, the Company took several preemptive actions during the year to manage liquidity as demand for its products decreased. Despite the continued adverse impacts of the pandemic on the Company’s results since the first quarter of 2020, manufacturing operations resumed and several restorative actions were completed during 2020, including the reinstatement of annual merit-based salary increases and continued investment to support the Company's core strategy.

- added (2021-04-29):
[0001783180-21-000032:note_history:56]
The Company continues to focus its efforts on preserving the health and safety of its employees and customers as well as maintaining the continuity of its operations. In addition, the Company continues to actively monitor its liquidity position and working capital needs and believes that its overall capital resources and liquidity position are adequate. The preparation of financial statements requires management to use judgments in making estimates and assumptions based on the relevant information available at the end of each period which can have a significant effect on reported amounts. However, due to significant uncertainty surrounding the pandemic, management's judgments could change. While the Company's results of operations, cash flows and financial condition could be negatively impacted, the extent of the impact cannot be estimated with certainty at this time.

- removed (2021-04-29):
[0001783180-20-000067:note_history:57]
The Condensed Consolidated Financial Statements as of September 30, 2020 and for the three and nine months ended September 30, 2020 and 2019 are unaudited, and include all adjustments, consisting only of normal recurring adjustments considered necessary by management to fairly state our results of operations, financial position and cash flows for the interim periods. The results reported in the Unaudited Condensed Consolidated Financial Statements are not necessarily indicative of results that may be expected for any other interim period or the entire year. The financial information included herein should be read in conjunction with the financial statements and notes in the Company's information statement, dated March 16, 2020, which was included as Exhibit 99.1 in our Current Report on Form 8-K filed with the Securities and Exchange Commission ("SEC") on March 16, 2020 (the "Information Statement").

- removed (2021-04-29):
[0001783180-20-000067:note_history:58]
A novel strain of coronavirus ("COVID-19") surfaced in Wuhan, China in late 2019 and has since spread throughout the rest of the world. In March 2020, COVID-19 was declared a pandemic by the World Health Organization and a national emergency by the U.S. Government.  The pandemic has negatively affected the U.S. and global economies, disrupted global supply chains and financial markets, resulted in significant travel restrictions, mandated facility closures and shelter-in-place orders.

- removed (2021-04-29):
[0001783180-20-000067:note_history:59]
Carrier is taking all prudent measures to protect the health and safety of our employees. In particular, we have implemented work from home requirements (where possible), social distancing and deep cleaning protocols at all of our facilities as well as travel restrictions, among other measures. We have also taken appropriate measures to work with our customers to minimize potential disruptions and to support the communities that we serve to address the challenges posed by the pandemic.

- removed (2021-04-29):
[0001783180-20-000067:note_history:60]
The full extent of the impact of COVID-19 on our operational and financial performance will depend on future developments, including the duration and spread of the pandemic as well as any worsening or additional outbreaks of the pandemic, and related containment and mitigation actions taken by the U.S., state and local and international governments to prevent disease spread. The extent of the pandemic's impact on Carrier will also depend upon our employees' ability to work safely in our facilities, our customers’ ability to continue to operate or to receive our products, and the level of activity and demand for the ultimate products and services of our customers or their customers.

- removed (2021-04-29):
[0001783180-20-000067:note_history:61]
During the three months ended March 31, 2020, we temporarily closed or reduced production at manufacturing facilities in North America, Asia and Europe for safety reasons and in response to lower demand for our products.  Subsequently, our manufacturing operations have resumed, measures have been enacted to scale capacity to demand, and we continue to actively take steps to mitigate supply chain risk. We continue to apply appropriate safety measures and have not experienced any significant disruptions to our manufacturing operations.  We also initiated return-to-work protocols at our non-manufacturing facilities where employees were previously working remotely.

- removed (2021-04-29):
[0001783180-20-000067:note_history:62]
We continue to focus on navigating the challenges COVID-19 presents by preserving our liquidity and managing our cash flows through preemptive actions to enhance our ability to meet our liquidity needs over the next twelve months. Such actions during the nine months ended September 30, 2020 include, but are not limited to, modifying the financial covenants in our revolving and term loan credit facilities and issuing $750 million of unsecured, unsubordinated long-term debt (see Note 10 – Borrowings and Lines of Credit for additional information), reducing our discretionary spending, capital investments and general and administrative costs by implementing temporary pay freezes and pay cuts, employee furloughs and suspending non-critical hiring, and participating in global COVID-19 relief measures, including the Coronavirus Aid, Relief, and Economic Security ("CARES") Act, which provides for payroll tax deferrals and credits, income tax payment deferrals and an increase in the income tax interest deduction limitation. 
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation is a leading global provider of heating, ventilating, air conditioning ("HVAC"), refrigeration, and fire and security solutions. Carrier also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. Carrier’s operations are classified into three segments: HVAC, Refrigeration and Fire & Security. The HVAC and Refrigeration segments sell their products and solutions directly, including to building contractors and owners, transportation companies and retail stores, or indirectly through joint venture and other minority-owned investments, independent sales representatives, distributors, wholesalers, dealers and retail outlets. These products and services are sold under the Carrier name and other brand names including Automated Logic, Bryant, CIAT, Day & Night, Heil, NORESCO, Riello, Carrier Commercial Refrigeration, Carrier Transicold, Sensitech and others. The Fire & Security segment sells its products directly to customers, or indirectly through manufacturers’ representatives, distributors, dealers, value-added resellers and retailers. Fire & Security’s products and services are used by governments, financial institutions, architects, building owners and developers, security and fire consultants, homeowners and other end-users requiring a high level of security and fire protection for their businesses and residences. These products and services are sold under brand names including Autronica, Chubb, Det-Tronics, Edwards, Fireye, GST, Kidde, LenelS2, Marioff, Onity, Supra and others.

- removed (2021-04-29):
[0001783180-20-000067:note_history:63]
On November 26, 2018, United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), announced its intention to spin off Carrier, one of UTC's reportable segments, into a separate publicly traded company (the "Separation").  On April 3, 2020 (the "Distribution Date"), UTC completed the Separation through a pro-rata distribution (the "Distribution") of all of the outstanding common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date for the Distribution. UTC distributed 866,158,910 shares of Carrier common stock in the Distribution, which was effective at 12:01 a.m., Eastern Time, on April 3, 2020 (the "Effective Time"). As a result of the Distribution, UTC shareowners of record received one share of the Company's common stock for every one share of UTC common stock and Carrier became an independent public company and our common stock is listed under the symbol "CARR" on the New York Stock Exchange.  In connection with the Separation, Carrier issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020. On April 1, 2020 and April 2, 2020, Carrier received cash contributions totaling $590 million from UTC related to the Separation. See Note 10 – Borrowings and Lines of Credit and Note 3 – Earnings Per Share for additional information.

- removed (2021-04-29):
[0001783180-20-000067:note_history:64]
In connection with the Separation, Carrier entered into several agreements with UTC and Otis Worldwide Corporation ("Otis"), including a separation and distribution agreement that sets forth certain agreements with UTC and Otis regarding the principal actions to be taken in connection with the Separation, including identifying the assets transferred, the liabilities assumed and the contracts transferred to each of UTC, Otis and Carrier as part of the Separation, and when and how these transfers and assumptions occurred.  Other agreements we entered into that govern aspects of our relationship with UTC and Otis following the Separation include:

- removed (2021-04-29):
[0001783180-20-000067:note_history:65]
Transition Services Agreement.  We entered into a Transition Services Agreement (the "TSA") with UTC and Otis in connection with the Separation pursuant to which UTC provides us with certain services and we provide certain services to UTC for a limited time to help ensure an orderly transition following the Separation. The services we receive include, but are not limited to, information technology services, technical and engineering support, application support for operations, legal, payroll, finance, tax and accounting, general administrative services and other support services. The costs for these services historically were included in our operating results based on allocations from UTC and in the nine months ended September 30, 2020, were not materially different under the TSA from such costs historically nor do we expect such costs to be materially different when these services are ultimately transitioned from UTC to Carrier.

- removed (2021-04-29):
[0001783180-20-000067:note_history:66]
Tax Matters Agreement.  We entered into a Tax Matters Agreement (the "TMA") with UTC and Otis that governs the parties’ respective rights, responsibilities and obligations with respect to tax matters (including responsibility for taxes, entitlement to refunds, allocation of tax attributes, preparation of tax returns, control of tax contests and other tax matters).  Subject to certain exceptions set forth in the TMA, Carrier generally is responsible for federal, state and foreign taxes imposed on a separate return basis upon Carrier (or any of its subsidiaries) with respect to taxable periods (or portions thereof) that ended on or prior to the date of the Distribution.  The TMA provides special rules that allocate responsibility for tax liabilities arising from a failure of the Separation transactions to qualify for tax-free treatment based on the reasons for such failure.  The

- removed (2021-04-29):
[0001783180-20-000067:note_history:67]
TMA also imposes restrictions on each of Carrier and Otis during the two-year period following the Distribution that are intended to prevent certain transactions from failing to qualify as transactions that are generally tax-free.

- removed (2021-04-29):
[0001783180-20-000067:note_history:68]
Employee Matters Agreement and Intellectual Property Agreement.  We entered into an employee matters agreement and intellectual property agreement with UTC and Otis in connection with the Separation.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-04-29):
[0001783180-21-000032:note_history:69]
BORROWINGS AND LINES OF CREDIT 
Long-term debt consisted of the following:

- added (2021-04-29):
[0001783180-21-000032:note_history:70]
| (In millions, except percentages) |  |  |  | March 31, 2021 |  | December 31, 2020 |
| 1.923% Notes due February 15, 2023 |  |  |  | $ | — |  | (1) | $ | 500 |  |
| 2.242% Notes due February 15, 2025 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 1,250 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Other (including project financing obligations and finance leases) |  |  |  | 307 |  |  | 308 |  |
| Total principal long-term debt |  |  |  | 9,807 |  |  | 10,308 |  |
| Other (discounts and debt issuance costs) (1) |  |  |  | (77) |  |  | (81) |  |
| Total debt |  |  |  | 9,730 |  |  | 10,227 |  |
| Less: current portion of long-term debt |  |  |  | 153 |  |  | 191 |  |
| Long-term debt, net of current portion |  |  |  | $ | 9,577 |  |  | $ | 10,036 |  |

- added (2021-04-29):
[0001783180-21-000032:note_history:71]
(1) In February 2021, the Company prepaid the 1.923% Notes due in February 2023 and incurred a $17 million make-whole premium upon prepayment and wrote-off $2 million of the remaining unamortized deferred financing costs.

- added (2021-04-29):
[0001783180-21-000032:note_history:72]
Revolving Credit Facility

- added (2021-04-29):
[0001783180-21-000032:note_history:73]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements of the Company. A commitment fee of 0.125% is charged on the unused commitments under the Revolving Credit Facility. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate based on LIBOR plus a ratings-based margin, which was 125 basis points as of March 31, 2021. As of March 31, 2021, there were no borrowings outstanding under the Revolving Credit Facility.

- added (2021-04-29):
[0001783180-21-000032:note_history:74]
Commercial Paper Program

- changed (2021-04-29):
[0001783180-21-000032:note_history:75]
As of March 31, 2021, the Company had a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of March 31, 2021, there were no borrowings outstanding under the commercial paper program.
  (was, 2020-10-29, similarity 0.7344):
[0001783180-20-000067:note_history:75]
As of September 30, 2020, we have a $2.0 billion unsecured, unsubordinated commercial paper program which we plan to use for general corporate purposes, including the funding of working capital and potential acquisitions. As of September 30, 2020, there were no borrowings outstanding under the commercial paper program.

- added (2021-04-29):
[0001783180-21-000032:note_history:76]
Project Financing Arrangements

- added (2021-04-29):
[0001783180-21-000032:note_history:77]
The Company is involved in several long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $46 million and $40 million of debt during the three months ended March 31, 2021 and 2020, respectively. Long-term debt repayments associated with these financing arrangements during the three months ended March 31, 2021 and 2020 were $53 million and $34 million, respectively.

- added (2021-04-29):
[0001783180-21-000032:note_history:78]
Debt Covenants

- changed (2021-04-29):
[0001783180-21-000032:note_history:79]
The Revolving Credit Facility and the indenture for the long-term notes contain affirmative and negative covenants customary for financings of these types, which among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. On June 2, 2020, the Company entered into an amendment of the Revolving Credit Facility, under which certain terms of the facility were amended for a period beginning on June 2, 2020 and ending on December 30, 2021 (the "Covenant Modification Period"). The Company may terminate the Covenant Modification Period prior to December 30, 2021, subject to the satisfaction of certain conditions. The amendment 
defers testing of the Company's consolidated total net leverage ratio financial covenant until June 30, 2021 and increases the consolidated total net leverage ratio limit until December 31, 2021. The amendment also requires the Company to maintain liquidity at a certain level until the earlier of (1) June 29, 2021 and (2) the last day of the Covenant Modification Period. Additionally, during the Covenant Modification Period, the Company is subject to: (a) limitations on the incurrence of subsidiary indebtedness, (b) limitations on the making of restricted payments, including purchases by the Company of shares of its common stock and the amount of dividends the Company may pay and (c) a "most favored nations" provision related to certain terms of any committed credit facility in an amount greater than $100 million. As of March 31, 2021, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.
  (was, 2020-10-29, similarity 0.651):
[0001783180-20-000067:note_history:79]
The revolving credit facility, term loan credit facility and indenture contain affirmative and negative covenants customary for financings of this type, that among other things, limit Carrier and its subsidiaries' ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. On June 2, 2020, the Company entered into amendments to both the revolving credit facility and the term loan credit facility.  Pursuant to the amendments, certain terms of the revolving credit facility and the term loan credit facility were amended for a period beginning on June 2, 2020 and ending on December 30, 2021 (the "Covenant Modification Period").  The Company may terminate the Covenant Modification Period prior to December 30, 2021, subject to the satisfaction of certain conditions.  The amendments defer testing of our consolidated total net leverage ratio financial covenant until June 30, 2021 and increase the consolidated total net leverage ratio limit until December 31, 2021.  The amendments also require us to maintain liquidity at a certain level until the earlier of (1) June 29, 2021 and (2) the last day of the Covenant Modification Period.  Additionally, during the Covenant Modification Period, the Company is subject to (a) limitations on the incurrence of subsidiary indebtedness, (b) limitations on the making of restricted payments, including purchases by the Company of its ordinary shares and the amount of dividends the Company may pay, and

- removed (2021-04-29):
[0001783180-20-000067:note_history:80]
BORROWINGS AND LINES OF CREDIT 
On February 10, 2020, we entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "revolving credit facility").  The revolving credit facility supports our commercial paper program and cash requirements.  A commitment fee of 0.125% is charged on the unused commitments.  Borrowings under the revolving credit facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate based on LIBOR plus a ratings-based margin, which was 125 basis points as of September 30, 2020.  As of September 30, 2020, there were no borrowings under the revolving credit facility.

- removed (2021-04-29):
[0001783180-20-000067:note_history:81]
On February 10, 2020, we entered into a $1.75 billion term loan credit agreement that provides an unsecured, unsubordinated term loan credit facility which matures on February 10, 2023 (the "term loan credit facility").

- removed (2021-04-29):
[0001783180-20-000067:note_history:82]
On February 27, 2020, Carrier issued $9.25 billion of unsecured, unsubordinated long-term notes in six series with maturity dates ranging from 2023 through 2050. The notes were issued pursuant to an indenture between the Company and The Bank of New York Mellon Trust Company, N.A., as trustee.

- removed (2021-04-29):
[0001783180-20-000067:note_history:83]
On March 27, 2020, Carrier drew $1.75 billion on the term loan credit facility. The proceeds from the notes and the term loan credit facility were used to distribute $10.9 billion to UTC in connection with the Separation.

- removed (2021-04-29):
[0001783180-20-000067:note_history:84]
(c) a "most favored nations" provision related to certain terms of any committed credit facility in an amount greater than $100 million.  As of September 30, 2020, we were compliant with our covenants under the agreements governing our outstanding indebtedness.

- removed (2021-04-29):
[0001783180-20-000067:note_history:85]
On June 19, 2020, we issued $750 million of unsecured, unsubordinated 2.700% Notes due 2031.  These notes rank equally with our existing unsecured, unsubordinated obligations.  The net proceeds from the sale of the notes, which further enhance our liquidity and financial flexibility during the ongoing COVID-19 pandemic, are being used for general corporate purposes.

- removed (2021-04-29):
[0001783180-20-000067:note_history:86]
Long-term debt, all of which was issued during the nine months ended September 30, 2020 except for Other long-term debt, consisted of the following:

- removed (2021-04-29):
[0001783180-20-000067:note_history:87]
| (dollars in millions) |  |  |  |  |  |  |  |  |
| Debt Description | Interest Rate |  |  | September 30, 2020 |  |  | December 31, 2019 |  |
| 3-Year Term Loan Credit Facility due February 10, 2023 | 1.275 | % | 1 |  | $ | 1,750 |  | 2 |  | $ | — |  |  |
| 1.923% Notes due February 15, 2023 | 1.923 | % |  |  | 500 |  | 2 |  | — |  |  |
| 2.242% Notes due February 15, 2025 | 2.242 | % |  |  | 2,000 |  | 2 |  | — |  |  |
| 2.493% Notes due February 15, 2027 | 2.493 | % |  |  | 1,250 |  | 2 |  | — |  |  |
| 2.722% Notes due February 15, 2030 | 2.722 | % |  |  | 2,000 |  | 2 |  | — |  |  |
| 2.700% Notes due February 15, 2031 | 2.700 | % |  |  | 750 |  |  |  | — |  |  |
| 3.377% Notes due April 5, 2040 | 3.377 | % |  |  | 1,500 |  | 2 |  | — |  |  |
| 3.577% Notes due April 5, 2050 | 3.577 | % |  |  | 2,000 |  | 2 |  | — |  |  |
| Other (including project financing obligations and finance leases) |  |  |  | 309 |  |  |  | 319 |  |  |
| Total principal long-term debt |  |  |  | 12,059 |  |  |  | 319 |  |  |
| Other (discounts and debt issuance costs) |  |  |  | (85) |  |  |  | — |  |  |
| Total debt |  |  |  | 11,974 |  |  |  | 319 |  |  |
| Less: current portion of long-term debt |  |  |  | 223 |  |  |  | 237 |  |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,751 |  |  |  | $ | 82 |  |  |

- removed (2021-04-29):
[0001783180-20-000067:note_history:88]
1 The interest rate on the term loan as of September 30, 2020 was 1.275% which is a variable rate based on one-month LIBOR plus 112.5 basis points.

- removed (2021-04-29):
[0001783180-20-000067:note_history:89]
2 The net proceeds of the financing arrangements were used to distribute cash to UTC.

- removed (2021-04-29):
[0001783180-20-000067:note_history:90]
We issued $102 million and $106 million of debt during the nine months ended September 30, 2020 and 2019, respectively, relating to project financing arrangements.  Long-term debt repayments during the nine months ended September 30, 2020 and 2019 were $124 million and $98 million, respectively, relating to project financing arrangements.

- removed (2021-04-29):
[0001783180-20-000067:note_history:91]
Scheduled maturities of long-term debt, excluding amortization of discount, are as follows:

- removed (2021-04-29):
[0001783180-20-000067:note_history:92]
| (dollars in millions) |  |  |  |
| 2020 |  | $ | 223 |  |  |
| 2021 |  | $ | 45 |  |  |
| 2022 |  | $ | 40 |  |  |
| 2023 |  | $ | 2,251 |  |  |
| 2024 |  | $ | — |  |  |
| Thereafter |  | $ | 9,500 |  |  |

- removed (2021-04-29):
[0001783180-20-000067:note_history:93]
The average maturity of our long-term debt as of September 30, 2020 is approximately 12 years and the weighted-average interest rate on our total borrowings for the three months ended September 30, 2020 is approximately 2.7%. Interest expense associated with long-term debt for the three and nine months ended September 30, 2020 was $90 million and $213 million, respectively.  Included in Interest expense, net on the accompanying Unaudited Condensed Consolidated Statement of Operations is amortization of debt issuance costs of $2 million and $5 million, respectively, for the three and nine months ended September 30, 2020.  Also included in Interest expense, net for the nine months ended September 30, 2020 are debt issuance costs of $5 million that were expensed in the three months ended March 31, 2020.  Included in Accrued liabilities on the accompanying Unaudited Condensed Consolidated Balance Sheet was accrued interest of $127 million as of September 30, 2020.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-04-29):
[0001783180-21-000032:note_history:94]
Long-term debt consisted of the following:

- added (2021-04-29):
[0001783180-21-000032:note_history:95]
| (In millions, except percentages) |  |  |  | March 31, 2021 |  | December 31, 2020 |
| 1.923% Notes due February 15, 2023 |  |  |  | $ | — |  | (1) | $ | 500 |  |
| 2.242% Notes due February 15, 2025 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 1,250 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Other (including project financing obligations and finance leases) |  |  |  | 307 |  |  | 308 |  |
| Total principal long-term debt |  |  |  | 9,807 |  |  | 10,308 |  |
| Other (discounts and debt issuance costs) (1) |  |  |  | (77) |  |  | (81) |  |
| Total debt |  |  |  | 9,730 |  |  | 10,227 |  |
| Less: current portion of long-term debt |  |  |  | 153 |  |  | 191 |  |
| Long-term debt, net of current portion |  |  |  | $ | 9,577 |  |  | $ | 10,036 |  |

- added (2021-04-29):
[0001783180-21-000032:note_history:96]
(1) In February 2021, the Company prepaid the 1.923% Notes due in February 2023 and incurred a $17 million make-whole premium upon prepayment and wrote-off $2 million of the remaining unamortized deferred financing costs.

- removed (2021-04-29):
[0001783180-20-000067:note_history:97]
Long-term debt, all of which was issued during the nine months ended September 30, 2020 except for Other long-term debt, consisted of the following:

- removed (2021-04-29):
[0001783180-20-000067:note_history:98]
| (dollars in millions) |  |  |  |  |  |  |  |  |
| Debt Description | Interest Rate |  |  | September 30, 2020 |  |  | December 31, 2019 |  |
| 3-Year Term Loan Credit Facility due February 10, 2023 | 1.275 | % | 1 |  | $ | 1,750 |  | 2 |  | $ | — |  |  |
| 1.923% Notes due February 15, 2023 | 1.923 | % |  |  | 500 |  | 2 |  | — |  |  |
| 2.242% Notes due February 15, 2025 | 2.242 | % |  |  | 2,000 |  | 2 |  | — |  |  |
| 2.493% Notes due February 15, 2027 | 2.493 | % |  |  | 1,250 |  | 2 |  | — |  |  |
| 2.722% Notes due February 15, 2030 | 2.722 | % |  |  | 2,000 |  | 2 |  | — |  |  |
| 2.700% Notes due February 15, 2031 | 2.700 | % |  |  | 750 |  |  |  | — |  |  |
| 3.377% Notes due April 5, 2040 | 3.377 | % |  |  | 1,500 |  | 2 |  | — |  |  |
| 3.577% Notes due April 5, 2050 | 3.577 | % |  |  | 2,000 |  | 2 |  | — |  |  |
| Other (including project financing obligations and finance leases) |  |  |  | 309 |  |  |  | 319 |  |  |
| Total principal long-term debt |  |  |  | 12,059 |  |  |  | 319 |  |  |
| Other (discounts and debt issuance costs) |  |  |  | (85) |  |  |  | — |  |  |
| Total debt |  |  |  | 11,974 |  |  |  | 319 |  |  |
| Less: current portion of long-term debt |  |  |  | 223 |  |  |  | 237 |  |  |
| Long-term debt, net of current portion |  |  |  | $ | 11,751 |  |  |  | $ | 82 |  |  |

- removed (2021-04-29):
[0001783180-20-000067:note_history:99]
1 The interest rate on the term loan as of September 30, 2020 was 1.275% which is a variable rate based on one-month LIBOR plus 112.5 basis points.

- removed (2021-04-29):
[0001783180-20-000067:note_history:100]
2 The net proceeds of the financing arrangements were used to distribute cash to UTC.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2021-04-29):
[0001783180-20-000067:note_history:101]
Scheduled maturities of long-term debt, excluding amortization of discount, are as follows:

- removed (2021-04-29):
[0001783180-20-000067:note_history:102]
| (dollars in millions) |  |  |  |
| 2020 |  | $ | 223 |  |  |
| 2021 |  | $ | 45 |  |  |
| 2022 |  | $ | 40 |  |  |
| 2023 |  | $ | 2,251 |  |  |
| 2024 |  | $ | — |  |  |
| Thereafter |  | $ | 9,500 |  |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2021-04-29):
[0001783180-21-000032:note_history:103]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered to be related parties. Amounts attributable to equity method investees are as follows:

- added (2021-04-29):
[0001783180-21-000032:note_history:104]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2021 |  | 2020 |  |  |  |  |
| Sales to equity method investees included in Product sales |  | $ | 468 |  |  | $ | 344 |  |  |  |  |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 75 |  |  | $ | 77 |  |  |  |  |  |

- added (2021-04-29):
[0001783180-21-000032:note_history:105]
The Company had receivables from and payables to equity method investees as follows:

- added (2021-04-29):
[0001783180-21-000032:note_history:106]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 197 |  |  | $ | 161 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 45 |  |  | $ | 38 |  |

- changed (2021-04-29):
[0001783180-21-000032:note_history:107]
The Company periodically reviews the carrying value of its equity method investments to determine if there has been an other-than-temporary decline in fair value. A variety of factors are considered when determining if a decline in carrying value is 
other-than-temporary, including, among other factors, the financial condition and business prospects of the investee, as well as the Company's intent with regard to the investment. During the three months ended March 31, 2020, the Company determined that indicators of impairment existed for a minority owned joint venture investment. The Company performed a valuation of this investment, which was based on the income approach using the discounted cash flow method. The Company determined that the loss in value was other-than-temporary due to a reduction in sales and earnings that were driven by a deterioration in the oil and gas industry (the joint venture's primary market) and by the impact of the COVID-19 pandemic, among other factors. As a result, the Company recorded a non-cash, other-than-temporary impairment charge of $71 million on this investment during the three months ended March 31, 2020, which is included in Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations.
  (was, 2020-10-29, similarity 0.9727):
[0001783180-20-000067:note_history:107]
The Company periodically reviews the carrying value of its equity method investments to determine if there has been an other-than-temporary decline in fair value. A variety of factors are considered when determining if a decline in carrying value is other-than-temporary, including, among other factors, the financial condition and business prospects of the investee, as well as the Company's intent with regard to the investment.  During the three months ended March 31, 2020, we determined that indicators of impairment existed for a minority owned joint venture investment in the portfolio.  We performed a valuation of this investment, which was based on the income approach using the discounted cash flow method. We determined that the loss in value was other-than-temporary due to a reduction in sales and earnings that were driven by a deterioration in the oil and gas industry (the joint venture's primary market) and by the impact of the COVID-19 pandemic, among other factors. As a result, we recorded a non-cash, other-than-temporary impairment charge of $71 million on this investment during the three months ended March 31, 2020 which is included in Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations.

- removed (2021-04-29):
[0001783180-20-000067:note_history:108]
Carrier sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered related parties.  During the three months ended September 30, 2020 and 2019, Product sales in the Unaudited Condensed Consolidated Statement of Operations included sales to equity method investees of $576 million and $498 million, respectively. During the three months ended September 30, 2020 and 2019, Cost of products sold in the Unaudited Condensed Consolidated Statement of Operations included purchases from equity method investees of $70 million and $96 million, respectively.

- removed (2021-04-29):
[0001783180-20-000067:note_history:109]
During the nine months ended September 30, 2020 and 2019, Product sales in the Unaudited Condensed Consolidated Statement of Operations included sales to equity method investees of $1.4 billion and $1.4 billion, respectively. During the nine months ended September 30, 2020 and 2019, Cost of products sold in the Unaudited Condensed Consolidated Statement of Operations included purchases from equity method investees of $213 million and $274 million, respectively.

- removed (2021-04-29):
[0001783180-20-000067:note_history:110]
Carrier had receivables from equity method investees of $213 million and $137 million at September 30, 2020 and December 31, 2019, respectively. Carrier also had payables to equity method investees of $40 million and $55 million at September 30, 2020 and December 31, 2019, respectively. The receivables and payables are included in Accounts receivable, net and Accounts payable on the Unaudited Condensed Consolidated Balance Sheet.

- removed (2021-04-29):
[0001783180-20-000067:note_history:111]
In September 2020, the Company sold 9.25 million B shares of Beijer Ref AB ("Beijer") for SEK290 ($32.38) per share equal to approximately 7.9% of the outstanding B shares in Beijer, through an accelerated equity offering. We received proceeds of approximately $300 million and recognized a pre-tax gain on the sale of $252 million included in Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations.  Following the sale, Beijer, which is listed on the Nasdaq Stockholm, continues to be reported as an equity method investment with Carrier continuing to hold approximately 30% of Beijer's B shares, approximately 22% of Beijer's A shares and approximately 26% of the Beijer total votes.

- removed (2021-04-29):
[0001783180-20-000067:note_history:112]
Related Party with UTC

- removed (2021-04-29):
[0001783180-20-000067:note_history:113]
Prior to the Separation, Carrier had been managed and operated in the normal course of business with other affiliates of UTC.  Accordingly, certain shared costs were allocated to the Company and are reflected as expenses in the Unaudited Condensed Consolidated Financial Statements.

- removed (2021-04-29):
[0001783180-20-000067:note_history:114]
Related Party Sales.  During the periods prior to the Separation, the Company sold products and services to UTC and its other affiliates.  Product sales in the Unaudited Condensed Consolidated Statement of Operations include sales to UTC and affiliates of UTC other than Carrier of $0 million and $6 million for the three months ended September 30, 2020 and 2019, respectively, and $3 million and $18 million for the nine months ended September 30, 2020 and 2019, respectively.

- removed (2021-04-29):
[0001783180-20-000067:note_history:115]
Allocated Centralized Costs.  Prior to the Separation, UTC incurred corporate costs for services provided to Carrier and to other UTC businesses.  These services included treasury, tax, accounting, human resources, internal audit, legal, purchasing and information technology.  The costs associated with these services generally included all payroll and benefit costs as well as related overhead costs.  UTC also allocated costs associated with corporate insurance coverage and medical, pension, post-retirement and other health plan costs for employees participating in UTC sponsored plans. UTC corporate costs were either specifically attributed and charged to Carrier, when possible, or allocated to the Company. Allocations were based on direct usage where identifiable and on a number of other utilization measures including headcount, proportionate usage and net sales.  All such amounts were deemed incurred and settled by the Company in the period in which the costs were recorded and are included in UTC Net investment.

- removed (2021-04-29):
[0001783180-20-000067:note_history:116]
The allocated centralized costs for the three months ended September 30, 2020 and 2019 were $0 million and $62 million, respectively, and for the nine months ended September 30, 2020 and 2019 were $43 million and $178 million, respectively, and are primarily included in Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations.

- removed (2021-04-29):
[0001783180-20-000067:note_history:117]
The expense and cost allocations have been determined on a basis considered to be a reasonable reflection of the utilization of services provided to or for the benefit of the Company prior to the Separation.  The amounts that would have been, or will be incurred on a stand-alone basis could differ from the amounts allocated due to economies of scale, differences in management approach, a need for more or fewer employees, or other factors. In addition, the Company's future results of operations, financial position and cash flows could differ materially from the historical results presented herein.

- removed (2021-04-29):
[0001783180-20-000067:note_history:118]
Separation Costs. In connection with the Separation, we have incurred separation-related costs of approximately $24 million and $92 million for the three and nine months ended September 30, 2020, respectively, and $13 million and $13 million for the three and nine months ended September 30, 2019, respectively, primarily recorded in Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations, which primarily consist of employee-related costs, costs to establish certain stand-alone functions and information technology systems, professional service fees and other transaction-related costs resulting from Carrier becoming an independent, publicly traded company.

- removed (2021-04-29):
[0001783180-20-000067:note_history:119]
Cash Management and Financing. Prior to the Separation, the Company participated in UTC’s centralized cash management and financing programs.  Cash receipts and disbursements were executed through centralized systems, which were operated by UTC.  As cash was received and disbursed by UTC, it was accounted for by the Company through UTC Net investment.  The majority of external debt was financed by UTC, and financing decisions for wholly and majority owned subsidiaries were determined by UTC. See Note 1 – Description of the Business for additional information. The Company’s cash that was excluded from UTC's centralized cash management and financing programs is classified as Cash and cash equivalents in the Unaudited Condensed Consolidated Balance Sheet as of December 31, 2019.

- removed (2021-04-29):
[0001783180-20-000067:note_history:120]
During the nine months ended September 30, 2020, net assets of $780 million were contributed to the Company by UTC which primarily consisted of cash of $590 million, deferred tax assets and liabilities and fixed assets. These contributions of net assets are recorded as Net transfers from UTC on the Unaudited Condensed Consolidated Statement of Changes in Equity through UTC Net investment.

- removed (2021-04-29):
[0001783180-20-000067:note_history:121]
Accounts Receivable and Payable. Certain related party transactions between the Company and UTC were included within UTC Net investment in the Unaudited Condensed Consolidated Balance Sheet as of December 31, 2019 when the related party transactions were not settled in cash.  As of December 31, 2019, the UTC Net investment includes related party receivables due from UTC and its affiliates of $16.0 billion and related party payables due to UTC and its affiliates of $3.3 billion.  At the Distribution Date, UTC Net investment was reclassified to Common stock and Additional paid-in capital.

- removed (2021-04-29):
[0001783180-20-000067:note_history:122]
Prior to the Separation, interest income and expense related to activity with UTC that was historically included in Carrier’s results is presented on a net basis in the Unaudited Condensed Consolidated Statement of Operations.  For the three and nine months ended September 30, 2019, there was $21 million and $70 million, respectively, of interest income from activity with UTC.  For the three and nine months ended September 30, 2019, there was $12 million and $44 million, respectively, of interest expense from activity with UTC.  The effect of the settlement of these related party transactions is included in financing activity

- removed (2021-04-29):
[0001783180-20-000067:note_history:123]
in the Unaudited Condensed Consolidated Statement of Cash Flows.  There was no interest income or expense from activity with UTC for the three and nine months ended September 30, 2020.

- removed (2021-04-29):
[0001783180-20-000067:note_history:124]
Additionally, certain transactions between Carrier and its subsidiaries, and UTC and its affiliates, were cash-settled prior to the Separation and are reflected in Accounts receivable, net and Accounts payable in the Unaudited Condensed Consolidated Balance Sheet as of December 31, 2019 in the amounts of $6 million and $4 million, respectively. As of September 30, 2020, there were no outstanding Accounts receivable, net or Accounts payable with UTC.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2021-04-29):
[0001783180-21-000032:note_history:125]
Sales disaggregated by product and service are as follows:

- added (2021-04-29):
[0001783180-21-000032:note_history:126]
|  |  | For the Three Months Ended March 31, |  |  |
| (In millions) |  | 2021 |  | 2020 |  |  |  |  |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,147 |  |  | $ | 1,657 |  |  |  |  |  |
| Service |  | 339 |  |  | 302 |  |  |  |  |  |
| HVAC sales |  | 2,486 |  |  | 1,959 |  |  |  |  |  |
| Product |  | 892 |  |  | 713 |  |  |  |  |  |
| Service |  | 113 |  |  | 95 |  |  |  |  |  |
| Refrigeration sales |  | 1,005 |  |  | 808 |  |  |  |  |  |
| Product |  | 919 |  |  | 860 |  |  |  |  |  |
| Service |  | 385 |  |  | 346 |  |  |  |  |  |
| Fire & Security sales |  | 1,304 |  |  | 1,206 |  |  |  |  |  |
| Total segment sales |  | 4,795 |  |  | 3,973 |  |  |  |  |  |
| Eliminations and other |  | (96) |  |  | (85) |  |  |  |  |  |
| Net sales |  | $ | 4,699 |  |  | $ | 3,888 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-04-29):
[0001783180-21-000032:note_history:127]
REVENUE RECOGNITION 
The Company recognizes revenue when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefit from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company's performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.

- added (2021-04-29):
[0001783180-21-000032:note_history:128]
Sales disaggregated by product and service are as follows:

- added (2021-04-29):
[0001783180-21-000032:note_history:129]
|  |  | For the Three Months Ended March 31, |  |  |
| (In millions) |  | 2021 |  | 2020 |  |  |  |  |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,147 |  |  | $ | 1,657 |  |  |  |  |  |
| Service |  | 339 |  |  | 302 |  |  |  |  |  |
| HVAC sales |  | 2,486 |  |  | 1,959 |  |  |  |  |  |
| Product |  | 892 |  |  | 713 |  |  |  |  |  |
| Service |  | 113 |  |  | 95 |  |  |  |  |  |
| Refrigeration sales |  | 1,005 |  |  | 808 |  |  |  |  |  |
| Product |  | 919 |  |  | 860 |  |  |  |  |  |
| Service |  | 385 |  |  | 346 |  |  |  |  |  |
| Fire & Security sales |  | 1,304 |  |  | 1,206 |  |  |  |  |  |
| Total segment sales |  | 4,795 |  |  | 3,973 |  |  |  |  |  |
| Eliminations and other |  | (96) |  |  | (85) |  |  |  |  |  |
| Net sales |  | $ | 4,699 |  |  | $ | 3,888 |  |  |  |  |  |

- added (2021-04-29):
[0001783180-21-000032:note_history:130]
Contract Balances

- added (2021-04-29):
[0001783180-21-000032:note_history:131]
Total contract assets and liabilities arising from contracts with customers are as follows:

- added (2021-04-29):
[0001783180-21-000032:note_history:132]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| Contract assets, current |  | $ | 694 |  |  | $ | 656 |  |
| Contract assets, non-current (included within Other assets) |  | 137 |  |  | 98 |  |
| Total contract assets |  | 831 |  |  | 754 |  |
| Contract liabilities, current |  | (545) |  |  | (512) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (170) |  |  | (165) |  |
| Total contract liabilities |  | (715) |  |  | (677) |  |
| Net contract assets |  | $ | 116 |  |  | $ | 77 |  |

- added (2021-04-29):
[0001783180-21-000032:note_history:133]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under the contract or when the Company has a right to consideration that is unconditional before it transfers a good or service to the customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. The Company recognized revenue of $189 million during the three months ended March 31, 2021 that related to the contract liabilities balance as of January 1, 2021. The Company expects a majority of its contract liability balance at the end of the period to be recognized as revenue in the next 12 months.

- removed (2021-04-29):
[0001783180-20-000067:note_history:134]
REVENUE RECOGNITION 
Contract Assets and Liabilities. Total contract assets and liabilities are as follows:

- removed (2021-04-29):
[0001783180-20-000067:note_history:135]
| (dollars in millions) | September 30, 2020 |  | December 31, 2019 |
| Contract assets, current | $ | 753 |  |  | $ | 622 |  |
| Contract assets, non-current (included within Other assets) | 75 |  |  | 57 |  |
| Total contract assets | 828 |  |  | 679 |  |
| Contract liabilities, current | (495) |  |  | (443) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) | (166) |  |  | (168) |  |
| Total contract liabilities | (661) |  |  | (611) |  |
| Net contract assets | $ | 167 |  |  | $ | 68 |  |

- removed (2021-04-29):
[0001783180-20-000067:note_history:136]
Contract assets increased $149 million for the nine months ended September 30, 2020, primarily due to the timing of billings on customer contracts and contract completions. Contract liabilities increased $50 million for the nine months ended September 30, 2020, primarily due to customer billings in excess of revenue earned.

- removed (2021-04-29):
[0001783180-20-000067:note_history:137]
For the three months ended September 30, 2020 and 2019, we recognized revenue of $55 million and $53 million, respectively, and for the nine months ended September 30, 2020 and 2019, we recognized revenue of $288 million and $301 million, respectively, that was related to contract liabilities as of January 1, 2020 and 2019, respectively.

- removed (2021-04-29):
[0001783180-20-000067:note_history:138]
Remaining Performance Obligations ("RPO").  As of September 30, 2020, our total RPO was approximately $5.6 billion compared with $4.7 billion as of December 31, 2019. Of the total RPO as of September 30, 2020, we expect that approximately 73% will be recognized as sales over the next 12 months.

- removed (2021-04-29):
[0001783180-20-000067:note_history:139]
See Note 19 – Segment Financial Data which provides incremental disclosures required by Accounting Standard Codification ("ASC") Topic 606 – Revenue from Contracts with Customers.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2021-04-29):
[0001783180-21-000032:note_history:140]
SUBSEQUENT EVENTS 
On April 19, 2021, the Board of Directors declared a dividend of $0.12 per share of common stock payable on May 24, 2021 to shareowners of record at the close of business on May 3, 2021.
  (was, 2020-10-29, similarity 0.9206):
[0001783180-20-000067:note_history:140]
SUBSEQUENT EVENTS On October 15, 2020, the Board of Directors declared a dividend of $0.08 per share of common stock payable November 23, 2020 to shareowners of record at the close of business on October 30, 2020.

- added (2021-04-29):
[0001783180-21-000032:note_history:141]
On April 19, 2021, the Company announced that it signed agreements to acquire a controlling stake in Guangdong Giwee Group and its subsidiaries ("Giwee"). Giwee is a China-based manufacturer of HVAC products, offering a portfolio of products including variable refrigerant flow, modular chillers and light commercial air conditioners. The Company expects to close its acquisition of a controlling stake of Giwee in the second quarter of 2021 (with the remainder expected to close in the third quarter of 2021), subject to customary closing conditions, including regulatory approvals.
