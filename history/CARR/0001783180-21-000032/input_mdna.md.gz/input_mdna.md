# CARR MD&A — 0001783180-21-000032


## mdna

[0001783180-21-000032:mdna:1]
[same as prior period, unchanged from 0001783180-20-000067:mdna:1]

[0001783180-21-000032:mdna:2]
[same as prior period, unchanged from 0001783180-20-000067:mdna:2]

[0001783180-21-000032:mdna:3]
[same as prior period, unchanged from 0001783180-20-000067:mdna:12]

[0001783180-21-000032:mdna:4]
Carrier is a leading global provider of healthy, safe and sustainable building and cold chain solutions. We operate three business segments, HVAC, Refrigeration and Fire & Security, each with strong brands and innovative products which we expect to drive future growth. Today, our portfolio includes industry-leading brands such as Carrier, Kidde, Edwards, LenelS2, Carrier Transicold and Automated Logic that offer innovative HVAC, refrigeration, fire, security and building automation technologies to help make the world safer and more comfortable.

[0001783180-21-000032:mdna:5]
Our worldwide operations are affected by global and regional industrial, economic and political factors and trends. These factors and trends include the mega-trends of urbanization, climate change and increasing requirements for food safety driven by the food needs of our growing global population and the rising standards of living in emerging markets. We believe that our business segments are well positioned to benefit from favorable secular trends, including these mega-trends, and from the strength of our industry-leading brands and track record of innovation. In addition, we regularly review our markets to proactively detect trends and adapt our strategies accordingly.

[0001783180-21-000032:mdna:6]
The effects of climate change, such as extreme weather conditions, create financial risks to our business. Demand for our HVAC products and services, representing our largest segment by sales, is seasonal and affected by the weather. Cooler than normal summers depress our sales of replacement air conditioning products and services. Similarly, warmer than normal winters have the same effect on our heating products. The results of any quarterly period may not be indicative of the expected results for a full year.

[0001783180-21-000032:mdna:7]
Our business is also affected by changes in the general level of economic activity, such as changes in business and consumer spending, construction and shipping activity as well as short-term economic factors such as currency fluctuations, commodity prices and supply disruptions. We continue to develop and commercialize new products in order to remain competitive in our markets and use risk management strategies to mitigate various exposures. In addition, we work with our suppliers to ensure inventory levels are sufficient to meet customer demand and use pricing actions as appropriate to help mitigate inflationary pressure on the costs of commodities and components used in our products.

[0001783180-21-000032:mdna:8]
[same as prior period, unchanged from 0001783180-20-000067:mdna:3]

[0001783180-21-000032:mdna:9]
On April 3, 2020, UTC completed the Separation of Carrier into an independent, publicly traded company. In connection with the Separation, we issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020.

[0001783180-21-000032:mdna:10]
In connection with the Separation, we entered into several agreements with UTC and Otis that govern various aspects of the relationship between us, UTC and Otis following the Separation and the Distribution including the TSA (which expired on March 31, 2021), the TMA, an employee matters agreement and an intellectual property agreement. Income and expense under these agreements are not material.

[0001783180-21-000032:mdna:11]
Our financial statements for periods prior to the Separation and the Distribution are prepared on a "carve-out" basis and include all amounts directly attributable to Carrier. Net cash transfers and other property transferred between UTC and us, including related party receivables and payables between us and other UTC affiliates, are presented as Net transfers to UTC. In addition, the financial statements include allocations of costs for administrative functions and services performed on our behalf by centralized groups within UTC. All allocations and estimates in the Unaudited Condensed Consolidated Financial Statements are based on assumptions that management believes are reasonable. Our financial statements for the periods subsequent to April 3, 2020 are consolidated financial statements based on the reported results of Carrier as a stand-alone company.

[0001783180-21-000032:mdna:12]
Impact of the COVID-19 Pandemic

[0001783180-21-000032:mdna:13]
In early 2020, the World Health Organization declared the outbreak of a respiratory disease known as COVID-19 as a global pandemic. In response, many countries implemented containment and mitigation measures to combat the outbreak which severely restricted the level of economic activity and caused a significant contraction in the global economy. As a result, we temporarily closed or reduced production at manufacturing facilities across the globe to ensure employee safety and instructed non-essential employees to work from home. In addition, we took several preemptive actions during the year to manage

[0001783180-21-000032:mdna:14]
24

[0001783180-21-000032:mdna:15]
liquidity as demand for our products decreased. Despite the continued adverse impacts of the pandemic on our results since the first quarter of 2020, manufacturing operations resumed and several restorative actions were completed during 2020 including the reinstatement of annual merit-based salary increases and continued investment to support our core strategy.

[0001783180-21-000032:mdna:16]
We continue to focus our efforts on preserving the health and safety of our employees and customers as well as maintaining the continuity of our operations. In addition, we continue to actively monitor our liquidity position and working capital needs and believe that our overall capital resources and liquidity position are adequate. The preparation of financial statements requires management to use judgments in making estimates and assumptions based on the relevant information available at the end of each period which can have a significant effect on reported amounts. However, due to significant uncertainty surrounding the pandemic, management's judgments could change. While our results of operations, cash flows and financial condition could be negatively impacted, the extent of the impact cannot be estimated with certainty at this time.

[0001783180-21-000032:mdna:17]
[same as prior period, unchanged from 0001783180-20-000067:mdna:28]

[0001783180-21-000032:mdna:18]
Preparation of our financial statements requires management to make estimates and assumptions that affect the reported amounts of assets, liabilities, sales and expenses. We believe that the most complex and sensitive judgments, because of their potential significance to the Unaudited Condensed Consolidated Financial Statements, result primarily from the need to make estimates about the effects of matters that are inherently uncertain. In "Management’s Discussion and Analysis of Financial Condition and Results of Operations" of our 2020 Form 10-K, we describe the significant accounting estimates and policies used in the preparation of the Unaudited Condensed Consolidated Financial Statements. There have been no significant changes in our critical accounting estimates.

[0001783180-21-000032:mdna:19]
[same as prior period, unchanged from 0001783180-20-000067:mdna:34]

[0001783180-21-000032:mdna:20]
Consolidated Results

[0001783180-21-000032:mdna:21]
|  |  | For the Three Months Ended March 31, |  |  |  |  |  |  |
| (In millions) |  | 2021 |  | 2020 |  | Period Change |  | % Change |  |  |  |  |  |  |
| Net sales |  | $ | 4,699 |  |  | $ | 3,888 |  |  | $ | 811 |  |  | 21 | % |  |  |  |  |  |  |
| Cost of products and services sold |  | (3,305) |  |  | (2,766) |  |  | (539) |  |  | 19 | % |  |  |  |  |  |  |
| Gross margin |  | 1,394 |  |  | 1,122 |  |  | 272 |  |  | 24 | % |  |  |  |  |  |  |
| Operating expenses |  | (823) |  |  | (807) |  |  | (16) |  |  | 2 | % |  |  |  |  |  |  |
| Operating profit |  | 571 |  |  | 315 |  |  | 256 |  |  | 81 | % |  |  |  |  |  |  |
| Non-operating income (expenses), net |  | (75) |  |  | (20) |  |  | (55) |  |  | 275 | % |  |  |  |  |  |  |
| Income from operations before income taxes |  | 496 |  |  | 295 |  |  | 201 |  |  | 68 | % |  |  |  |  |  |  |
| Income tax expense |  | (104) |  |  | (193) |  |  | 89 |  |  | (46) | % |  |  |  |  |  |  |
| Net income from operations |  | 392 |  |  | 102 |  |  | 290 |  |  | 284 | % |  |  |  |  |  |  |
| Less: Non-controlling interest in subsidiaries' earnings from operations |  | 8 |  |  | 6 |  |  | 2 |  |  | 33 | % |  |  |  |  |  |  |
| Net income attributable to common shareowners |  | $ | 384 |  |  | $ | 96 |  |  | $ | 288 |  |  | 300 | % |  |  |  |  |  |  |

[0001783180-21-000032:mdna:22]
[same as prior period, unchanged from 0001783180-20-000067:mdna:35]

[0001783180-21-000032:mdna:23]
For the three months ended March 31, 2021, Net sales were $4.7 billion, a 21% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000032:mdna:24]
| Organic |  | 17 | % |  |  |  |  |
| Foreign currency translation |  | 4 | % |  |  |  |  |
| Total % change |  | 21 | % |  |  |  |  |

[0001783180-21-000032:mdna:25]
We continue to be impacted by the current economic environment brought about by the COVID-19 global pandemic. However, strong operational performance and continued improvement in the global economic climate during the quarter increased organic sales by 17%. The organic increase was primarily driven by our HVAC segment with continued strong results for North

[0001783180-21-000032:mdna:26]
25

[0001783180-21-000032:mdna:27]
America residential and improved end-markets in Europe and China for commercial HVAC. Strong results in both our Refrigeration segment and our Fire & Security segment were also driven by improved global end-markets compared with the prior year period. Refer to "Segment Review" below for a discussion of Net sales by segment.

[0001783180-21-000032:mdna:28]
[same as prior period, unchanged from 0001783180-20-000067:mdna:46]

[0001783180-21-000032:mdna:29]
For the three months ended March 31, 2021, Gross margin was $1.4 billion, a 24% increase compared with the same period of 2020.

[0001783180-21-000032:mdna:30]
|  |  | For the Three Months Ended March 31, |  |  |  |  |  |  |  |  |
| (In millions) |  | 2021 |  | 2020 |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 4,699 |  |  | $ | 3,888 |  |  |  |  |  |  |  |  |  |
| Cost of products and services sold |  | (3,305) |  |  | (2,766) |  |  |  |  |  |  |  |  |  |
| Gross margin |  | $ | 1,394 |  |  | $ | 1,122 |  |  |  |  |  |  |  |  |  |
| Percentage of net sales |  | 29.7 | % |  | 28.9 | % |  |  |  |  |  |  |  |  |

[0001783180-21-000032:mdna:31]
The increase in Gross margin was primarily driven by strong operational performance and continued improvement in the global economic climate during the current period. Higher volumes in each of our segments outpaced operational costs due to continued cost containment initiatives as well as improved material and factory productivity actions. These amounts were partially offset by the rising cost for commodities and components used in our products, certain supply chain inefficiencies and freight costs. As a result, gross margin as a percentage of Net sales increased by 80 basis points compared with the same period of 2020.

[0001783180-21-000032:mdna:32]
Operating Expenses

[0001783180-21-000032:mdna:33]
For the three months ended March 31, 2021, operating expenses, including Equity method investment net earnings, were $823 million, a 2% increase compared with the same period of 2020. The components were as follows:

[0001783180-21-000032:mdna:34]
|  |  | For the Three Months Ended March 31, |  |  |  |  |  |  |  |  |
| (In millions) |  | 2021 |  | 2020 |  |  |  |  |  |  |  |  |
| Selling, general and administrative |  | $ | (743) |  |  | $ | (692) |  |  |  |  |  |  |  |  |  |
| Research and development |  | (121) |  |  | (98) |  |  |  |  |  |  |  |  |  |
| Equity method investment net earnings |  | 38 |  |  | 29 |  |  |  |  |  |  |  |  |  |
| Other income (expense), net |  | 3 |  |  | (46) |  |  |  |  |  |  |  |  |  |
| Total operating expenses |  | $ | (823) |  |  | $ | (807) |  |  |  |  |  |  |  |  |  |
| Percentage of net sales |  | 17.5 | % |  | 20.8 | % |  |  |  |  |  |  |  |  |

[0001783180-21-000032:mdna:35]
For the three months ended March 31, 2021, Selling, general and administrative expenses were $743 million, a 7% increase compared with the same period of 2020. At the onset of the COVID-19 pandemic, we initiated various cost containment initiatives in order to help mitigate the impacts on our business, which included reducing discretionary spending and temporarily closing or limiting the presence of our workforce in our facilities. These amounts were partially offset by $45 million of Separation related costs during the three months ended March 31, 2020. As a result, the increase in Selling, general and administrative expense in the current period reflects the gradual return to our operational spending levels prior to the COVID-19 pandemic. In addition, higher compensation and benefit charges related to variable compensation, restructuring charges and unfavorable foreign currency movements in the current period further contributed to the year-over-year increase.

[0001783180-21-000032:mdna:36]
Research and development costs relate to new product development and new technology innovation. Due to the variable nature of program development schedules, year-over-year spending levels can fluctuate. In addition, we continue to invest to prepare for future refrigerant regulation changes and digital controls technologies.

[0001783180-21-000032:mdna:37]
Investments over which we do not exercise control, but have significant influence, are accounted for using the equity method of accounting. For the three months ended March 31, 2021, Equity method investment net earnings were $38 million, a 31%

[0001783180-21-000032:mdna:38]
26

[0001783180-21-000032:mdna:39]
increase compared with the same period of 2020. The increase was primarily related to higher earnings in HVAC joint ventures in the Middle East and North America as end-markets improved compared with the prior period. These amounts were partially offset by a change in the estimated cost of a product trouble matter and the reduction in earnings resulting from the sale of our investment in Beijer REF AB in 2020.

[0001783180-21-000032:mdna:40]
Other income (expense), net primarily includes the impact of gains and losses related to the sale of interests in our equity method investments, foreign currency gains and losses on transactions that are denominated in a currency other than an entity's functional currency and hedging-related activities. During the three months ended March 31, 2020, Other income (expense), net included a $71 million other-than-temporary impairment charge in 2020 on a minority-owned joint venture investment.

[0001783180-21-000032:mdna:41]
Non-Operating Income (Expenses), net

[0001783180-21-000032:mdna:42]
For the three months ended March 31, 2021, Non-operating income (expenses), net were $75 million, a 275% increase compared with the same period of 2020. The components were as follows:

[0001783180-21-000032:mdna:43]
|  |  | For the Three Months Ended March 31, |  |  |  |  |
| (In millions) |  | 2021 |  | 2020 |  |  |  |  |
| Non-service pension (expense) benefit |  | $ | 18 |  |  | $ | 17 |  |  |  |  |  |
| Interest expense |  | $ | (96) |  |  | $ | (38) |  |  |  |  |  |
| Interest income |  | 3 |  |  | 1 |  |  |  |  |  |
| Interest (expense) income, net |  | $ | (93) |  |  | $ | (37) |  |  |  |  |  |
| Non-operating income (expenses), net |  | $ | (75) |  |  | $ | (20) |  |  |  |  |  |

[0001783180-21-000032:mdna:44]
Non-operating income (expenses), net include the results from activities other than normal business operations such as interest expense and interest income and the components of net periodic benefit cost for pension and post-retirement obligations.

[0001783180-21-000032:mdna:45]
Interest expense is affected by the amount of debt outstanding and the interest rates on that debt. For the three months ended March 31, 2021 Interest expense was $96 million, a 153% increase compared with the same period in 2020. In connection with the Separation and the Distribution, we issued $11.0 billion of long-term debt in February 2020. As a result, interest expense during the three months ended March 31, 2020 only included interest expense incurred after the issuance date. In addition, during the three months ended March 31, 2021, we incurred a make-whole premium of $17 million and wrote-off $2 million of unamortized deferred financing costs as a result of the redemption of our $500 million 1.923% Notes originally due in February 2023.

[0001783180-21-000032:mdna:46]
[same as prior period, unchanged from 0001783180-20-000067:mdna:77]

[0001783180-21-000032:mdna:47]
|  |  | For the Three Months Ended March 31, |  |  |
|  |  | 2021 |  | 2020 |  |  |  |  |
| Effective tax rate |  | 21.0 | % |  | 65.4 | % |  |  |  |  |

[0001783180-21-000032:mdna:48]
The decrease in the effective tax rate for the three months ended March 31, 2021 is primarily due to the recognition of a favorable tax adjustment of $21 million resulting from a re-organization in our German subsidiaries and the absence of a prior year charge of $51 million related to a valuation allowance recorded against a United Kingdom tax loss and credit carry forward and a $46 million charge resulting from our decision to no longer permanently reinvest certain pre-2018 unremitted non-U.S. earnings.

[0001783180-21-000032:mdna:49]
27

[0001783180-21-000032:mdna:50]
SEGMENT REVIEW

[0001783180-21-000032:mdna:51]
Three Months Ended March 31, 2021 Compared with Three Months Ended March 31, 2020

[0001783180-21-000032:mdna:52]
We have three operating segments:

[0001783180-21-000032:mdna:53]
•The HVAC segment provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers while enhancing building performance, energy efficiency and sustainability.

[0001783180-21-000032:mdna:54]
•The Refrigeration segment includes transport refrigeration and monitoring products, services and digital solutions for trucks, trailers, shipping containers, intermodal and rail, as well as commercial refrigeration products.

[0001783180-21-000032:mdna:55]
•The Fire & Security segment provides a wide range of residential, commercial and industrial technologies and systems and services solutions to protect people and property.

[0001783180-21-000032:mdna:56]
We determine our segments based on how our Chief Executive Officer, who is the Chief Operating Decision Maker (the "CODM"), allocates resources, assesses performance and makes operational decisions. The CODM allocates resources and evaluates the financial performance of each of our segments based on Net sales and Operating profit. Adjustments to reconcile segment reporting to the consolidated results are included in "Eliminations and other and General corporate expenses."

[0001783180-21-000032:mdna:57]
Summary performance for each of our segments for the three months ended March 31, 2021 and 2020 is as follows:

[0001783180-21-000032:mdna:58]
|  |  | Net Sales |  | Operating Profit |  | Operating Profit Margin |
|  |  | For the Three Months Ended March 31, |  | For the Three Months Ended March 31, |  | For the Three Months Ended March 31, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC |  | $ | 2,486 |  |  | $ | 1,959 |  |  | $ | 365 |  |  | $ | 167 |  |  | 14.7 | % |  | 8.5 | % |
| Refrigeration |  | 1,005 |  |  | 808 |  |  | 127 |  |  | 99 |  |  | 12.6 | % |  | 12.3 | % |
| Fire & Security |  | 1,304 |  |  | 1,206 |  |  | 150 |  |  | 120 |  |  | 11.5 | % |  | 10.0 | % |
| Total segment |  | 4,795 |  |  | 3,973 |  |  | 642 |  |  | 386 |  |  | 13.4 | % |  | 9.7 | % |
| Eliminations and other |  | (96) |  |  | (85) |  |  | (40) |  |  | (35) |  |  |  |  |  |
| General corporate expenses |  | — |  |  | — |  |  | (31) |  |  | (36) |  |  |  |  |  |
| Total Consolidated |  | $ | 4,699 |  |  | $ | 3,888 |  |  | $ | 571 |  |  | $ | 315 |  |  | 12.2 | % |  | 8.1 | % |

[0001783180-21-000032:mdna:59]
HVAC Segment

[0001783180-21-000032:mdna:60]
For the three months ended March 31, 2021, Net sales in our HVAC segment were $2.5 billion, a 27% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000032:mdna:61]
|  |  | Net Sales |
| Organic |  | 25 | % |
| Foreign currency translation |  | 2 | % |
| Total % change in Net sales |  | 27 | % |

[0001783180-21-000032:mdna:62]
The organic increase in Net sales of 25% was driven by strong results across each of the segment's product lines. Increased sales in our North America residential and light commercial HVAC business (33%) were driven by new construction, the ongoing stay-at-home workforce and higher levels of distributor stocking. Increased sales in our Commercial HVAC business (16%) benefited from the gradual improvement in the global economic environment as our end markets continue to improve from the prior year impacts of the COVID-19 pandemic. In addition, continued growth in our business, particularly in Europe and China, supported improved results.

[0001783180-21-000032:mdna:63]
28

[0001783180-21-000032:mdna:64]
For the three months ended March 31, 2021, Operating profit in our HVAC segment was $365 million, a 119% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000032:mdna:65]
|  |  | Operating Profit |
| Operational |  | 84 | % |
| Acquisitions and divestitures, net |  | (4) | % |
| Restructuring |  | (1) | % |
| Other |  | 40 | % |
| Total % change in Operating profit |  | 119 | % |

[0001783180-21-000032:mdna:66]
The increase in operational profit was primarily attributable to higher sales volumes in the North America residential and light commercial HVAC and the commercial HVAC businesses compared with the prior year period. In addition, favorable productivity initiatives benefited logistics and material costs, while higher income from equity method investments benefited operational profit. These amounts were partially offset by higher selling, general and administrative costs and research and development activities during the current period.

[0001783180-21-000032:mdna:67]
For the three months ended March 31, 2020, we realized a non-cash other-than-temporary impairment charge of $71 million related to a minority-owned joint venture. The charge was driven by a deterioration in the oil and gas industry (the joint venture's primary market) as well as the impact of the COVID-19 pandemic and was recorded within Other.

[0001783180-21-000032:mdna:68]
Refrigeration Segment

[0001783180-21-000032:mdna:69]
For the three months ended March 31, 2021, Net sales in our Refrigeration segment were $1.0 billion, a 24% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000032:mdna:70]
|  |  | Net Sales |
| Organic |  | 19 | % |
| Foreign currency translation |  | 5 | % |
| Total % change in Net sales |  | 24 | % |

[0001783180-21-000032:mdna:71]
The organic increase in Net sales of 19% was driven by the gradual improvement in the global economic environment as our end markets continue to improve from the prior year impacts of the COVID-19 pandemic. Transport refrigeration sales (22%) benefited from the continued recovery associated with the cyclical decline that began in late 2019 as well as a rebound in the demand for global transportation and COVID-19 vaccine-related cargo monitoring. Commercial refrigeration sales (12%) also increased due to a rebound in demand.

[0001783180-21-000032:mdna:72]
For the three months ended March 31, 2021, Operating profit in our Refrigeration segment was $127 million, a 28% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000032:mdna:73]
|  |  | Operating Profit |
| Operational |  | 26 | % |
| Foreign currency translation |  | 5 | % |
| Restructuring |  | (2) | % |
| Other |  | (1) | % |
| Total % change in Operating profit |  | 28 | % |

[0001783180-21-000032:mdna:74]
29

[0001783180-21-000032:mdna:75]
The increase in operational profit was primarily attributable to higher sales volumes compared with the prior year period which was heavily impacted by the COVID-19 pandemic. In addition, favorable productivity initiatives benefited material and factory costs. These amounts were partially offset by higher selling, general and administrative costs and research and development activities during the current period.

[0001783180-21-000032:mdna:76]
Fire & Security Segment

[0001783180-21-000032:mdna:77]
For the three months ended March 31, 2021, Net sales in our Fire & Security segment were $1.3 billion, an 8% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000032:mdna:78]
|  |  | Net Sales |
| Organic |  | 3 | % |
| Foreign currency translation |  | 5 | % |
| Total % change in Net sales |  | 8 | % |

[0001783180-21-000032:mdna:79]
The organic increase in Net sales of 3% was driven by the gradual improvement in the global economic environment as our end markets continued to improve from the prior year impacts of the COVID-19 pandemic. Field service sales (4%) benefited from improved end-markets in regions heavily impacted by COVID-19 including Europe and Asia. An increase in product sales (3%) was primarily driven by improvements in China, which was impacted by shutdowns related to COVID-19 in the prior period. In addition, stronger residential and commercial sales were partially offset by lower demand from the hospitality and oil and gas industries.

[0001783180-21-000032:mdna:80]
For the three months ended March 31, 2021, Operating profit in our Fire & Security segment was $150 million, a 25% increase compared with the same period of 2020. The components of the year-over-year change were as follows:

[0001783180-21-000032:mdna:81]
|  |  | Operating Profit |
| Operational |  | 28 | % |
| Foreign currency translation |  | 4 | % |
| Restructuring |  | (7) | % |
| Total % change in Operating profit |  | 25 | % |

[0001783180-21-000032:mdna:82]
The increase in operational profit was primarily attributable to higher sales volumes compared with the prior year period which was heavily impacted by the COVID-19 pandemic. In addition, favorable productivity initiatives benefited material and factory costs. These amounts were partially offset by higher selling, general and administrative costs and research and development activities during the current period.

[0001783180-21-000032:mdna:83]
[same as prior period, unchanged from 0001783180-20-000067:mdna:146]

[0001783180-21-000032:mdna:84]
Eliminations and other reflects the elimination of sales, other income and operating profit resulting from activity between segments, net hedging and foreign exchange-related gains and losses, as well as other infrequently occurring items, such as acquisition or divestiture transaction costs. In addition, Eliminations and other includes asbestos-related costs and recoveries associated with the settlement and defense of potential future claims, insurance settlements and revisions in the estimated liability for potential future claims.

[0001783180-21-000032:mdna:85]
General corporate expenses include various costs incurred to operate the organization including human resources, accounting, legal and tax. Prior to the Separation and the Distribution, General corporate expenses include the allocation of costs from UTC which are not indicative of our future expenses as a public company.

[0001783180-21-000032:mdna:86]
The following table presents the impact of Eliminations and other and General corporate expenses on Net sales and Operating profit for the three months ended March 31, 2021 compared with the three months ended March 31, 2020:

[0001783180-21-000032:mdna:87]
|  |  | Net Sales |  | Operating Profit |
|  |  | For the Three Months Ended March 31, |  | For the Three Months Ended March 31, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Eliminations and other |  | $ | (96) |  |  | $ | (85) |  |  | $ | (40) |  |  | $ | (35) |  |
| General corporate expenses |  | $ | — |  |  | $ | — |  |  | $ | (31) |  |  | $ | (36) |  |

[0001783180-21-000032:mdna:88]
For the three months ended March 31, 2021, the impact of Eliminations and other on Operating Profit was $40 million. The year-over-year increase in costs was primarily related to higher research and development costs, higher deferred compensation charges and inter-segment profit elimination, which were partially offset by lower separation-related costs.

[0001783180-21-000032:mdna:89]
For the three months ended March 31, 2021, the impact of General corporate expenses on Operating Profit was $31 million. The year-over-year decrease in costs was primarily related to the reduction of separation-related costs.

[0001783180-21-000032:mdna:90]
[same as prior period, unchanged from 0001783180-20-000067:mdna:152]

[0001783180-21-000032:mdna:91]
We assess liquidity in terms of our ability to generate adequate amounts of cash necessary to fund our current and future cash requirements. In doing so, we review and analyze our cash on hand and our working capital to ensure that we have adequate liquidity to support our business and strategic initiatives. We rely on operating cash flows as our primary source of liquidity. In addition, we have access to other sources of capital to finance our strategic initiatives and fund growth.

[0001783180-21-000032:mdna:92]
As of March 31, 2021, we had cash and cash equivalents of $2.6 billion, of which approximately 32% was held by our foreign subsidiaries. We manage our worldwide cash requirements by reviewing available funds and the cost effectiveness with which we can access funds held by foreign subsidiaries. On occasion, we are required to maintain cash deposits in connection with contractual obligations related to acquisitions, divestitures or other legal obligations. As of March 31, 2021 and December 31, 2020, the amount of such restricted cash was approximately $4 million and $4 million, respectively.

[0001783180-21-000032:mdna:93]
We maintain a $2.0 billion unsecured, unsubordinated commercial paper program which can be used for general corporate purposes, including working capital and potential acquisitions. In addition, we maintain our $2.0 billion Revolving Credit Facility that matures on April 3, 2025 which supports our commercial paper borrowing program and cash requirements. This Revolving Credit Facility has a commitment fee of 0.125% that is charged on unused commitments and borrowings are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable rate based on LIBOR plus a ratings-based margin, which was 125 basis points as of March 31, 2021. As of March 31, 2021, we had no borrowings outstanding under our commercial paper program and our Revolving Credit Facility.

[0001783180-21-000032:mdna:94]
We believe that our available cash and operating cash flows will be sufficient to meet our future operating cash needs. Our committed credit facilities and access to the debt and equity markets provide additional sources of short-term and long-term capital to fund current operations, debt maturities and future investment opportunities. Although we believe that the arrangements currently in place permit us to finance our operations on acceptable terms and conditions, our access to and the availability of financing on acceptable terms and conditions in the future will be impacted by many factors, including: (1) our credit ratings or absence of credit ratings, (2) the liquidity of the overall capital markets and (3) the state of the economy, including the impact of the COVID-19 pandemic. There can be no assurance that we will be able to obtain additional financing on terms favorable to us, if at all.

[0001783180-21-000032:mdna:95]
The following table presents our credit ratings and outlook as of March 31, 2021:

[0001783180-21-000032:mdna:96]
| Rating Agency |  | Long-term Rating (1) |  | Short-term Rating |  | Outlook (2) |
| Standards & Poor's ("S&P") |  | BBB |  | A2 |  | Negative |
| Moody's Investor Services, Inc. ("Moody's") |  | Baa3 |  | P3 |  | Stable |
| Fitch Ratings ("Fitch") |  | BBB- |  | F3 |  | Stable |

[0001783180-21-000032:mdna:97]
(1) The long-term rating for S&P was affirmed on June 15, 2020, and for Moody's on June 16, 2020. Fitch's long-term rating was issued on June 11, 2020.

[0001783180-21-000032:mdna:98]
(2) S&P revised its outlook to negative from stable on June 15, 2020.

[0001783180-21-000032:mdna:99]
The following table contains several key measures of our financial condition and liquidity:

[0001783180-21-000032:mdna:100]
| (In millions, except percentages) |  | March 31, 2021 |  | December 31, 2020 |
| Cash and cash equivalents |  | $ | 2,599 |  |  | $ | 3,115 |  |
| Total debt |  | $ | 9,730 |  |  | $ | 10,227 |  |
| Total equity |  | $ | 6,818 |  |  | $ | 6,578 |  |
| Net debt (total debt less cash and cash equivalents) |  | $ | 7,131 |  |  | $ | 7,112 |  |
| Total capitalization (total debt plus total equity) |  | $ | 16,548 |  |  | $ | 16,805 |  |
| Net capitalization (total debt plus total equity less cash and cash equivalents) |  | $ | 13,949 |  |  | $ | 13,690 |  |
| Total debt to total capitalization |  | 59 | % |  | 61 | % |
| Net debt to net capitalization |  | 51 | % |  | 52 | % |

[0001783180-21-000032:mdna:101]
Our short-term obligations primarily consist of current maturities of long-term debt. Our long-term obligations primarily consist of long-term notes with final maturity dates ranging between 2025 and 2050. Interest payments related to indebtedness are expected to approximate $286 million per year, reflecting an approximate weighted-average interest rate of 2.8%. Any borrowings from the Revolving Credit Facility are subject to variable interest rates. See Note 5 – Borrowings and Lines of Credit in the Notes to the Unaudited Condensed Consolidated Financial Statements for additional information regarding the terms of our long-term debt obligations.

[0001783180-21-000032:mdna:102]
On February 4, 2021, our Board of Directors approved a stock repurchase program authorizing the repurchase of up to $350 million of our outstanding common stock. Share repurchases may take place from time to time subject to market conditions and at our discretion in the open market or through one or more other public or private transactions, subject to compliance with our obligations under the TMA and our Revolving Credit Facility. For the three months ended March 31, 2021, we repurchased 976,374 shares of our common stock for an aggregate purchase price of $38 million which are held in Treasury stock as of March 31, 2021, as reflected on our Unaudited Condensed Consolidated Balance Sheet.

[0001783180-21-000032:mdna:103]
We paid dividends on common stock of $0.12 per share during the three months ended March 31, 2021, totaling $104 million. On April 19, 2021, our Board of Directors declared a dividend of $0.12 per share of common stock payable on May 24, 2021 to shareowners of record at the close of business on May 3, 2021.

[0001783180-21-000032:mdna:104]
Cash Flows

[0001783180-21-000032:mdna:105]
The following table reflects the major categories of cash flows. For additional details, see the Unaudited Condensed Consolidated Statement of Cash Flows in the Unaudited Condensed Consolidated Financial Statements.

[0001783180-21-000032:mdna:106]
|  |  | Three Months Ended March 31, |
| (In millions) |  | 2021 |  | 2020 |
| Net cash flows provided by (used in): |  |  |  |  |
| Operating activities |  | $ | 184 |  |  | $ | 47 |  |
| Investing activities |  | (49) |  |  | (128) |  |
| Financing activities |  | (643) |  |  | (76) |  |
| Effect of foreign exchange rate changes on cash and cash equivalents |  | (9) |  |  | (28) |  |
| Net increase (decrease) in cash and cash equivalents and restricted cash |  | $ | (517) |  |  | $ | (185) |  |

[0001783180-21-000032:mdna:107]
Cash flows from operating activities primarily represent inflows and outflows associated with our operations. Primary activities include net income from operations adjusted for non-cash transactions, working capital changes and changes in other assets and liabilities. The year-over-year increase in net cash provided by operating activities was primarily driven by higher net income from operations in the current period and improved working capital balances. Higher outstanding accounts payable balances  driven by the timing of raw material purchases and vendor payments more than offset the seasonal increase in inventory and higher accounts receivable balances.

[0001783180-21-000032:mdna:108]
Cash flows from investing activities primarily represent inflows and outflows associated with long-term assets. Primary activities include capital expenditures, acquisitions, divestitures and proceeds from the sale of fixed assets. During the three months ended March 31, 2021, net cash used in investing activities was $49 million. The primary driver of the outflow related to capital expenditures of $53 million. During the three months ended March 31, 2020, net cash used in financing activities was $128 million. The primary driver of the outflow related to the settlement of derivative contracts of $95 million and capital expenditures of $48 million.

[0001783180-21-000032:mdna:109]
Cash flows from financing activities primarily represent inflows and outflows associated with equity or borrowings. Primary activities include debt transactions, paying dividends to shareowners and the repurchase of our common stock. During the three months ended March 31, 2021, net cash used in financing activities was $643 million. The primary driver of the outflow related to the redemption of long-term debt of $500 million. In addition, we paid $104 million in dividends to our common shareowners and paid $36 million to repurchase shares of our common stock. During the three months ended March 31, 2020, net cash used in financing activities was $76 million. The primary driver of the outflow related to the payment of short-term borrowings and long-term debt.

[0001783180-21-000032:mdna:110]
[same as prior period, unchanged from 0001783180-20-000067:mdna:189]

[0001783180-21-000032:mdna:111]
The section entitled "Management's Discussion and Analysis of Financial Condition and Results of Operations – Off-Balance Sheet Arrangements and Contractual Obligations" in our 2020 Form 10-K provided a table summarizing our contractual obligations and commercial commitments at the end of 2020. There have been no material changes for the three months ended March 31, 2021 to our off-balance sheet arrangements and contractual obligations disclosed in our 2020 Form 10-K.
