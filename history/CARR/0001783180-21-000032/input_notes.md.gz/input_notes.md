# CARR notes — 0001783180-21-000032


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001783180-21-000032:notes:1]
DESCRIPTION OF THE BUSINESS 
Carrier Global Corporation is a leading global provider of heating, ventilating, air conditioning ("HVAC"), refrigeration and fire and security solutions. The Company also provides a broad array of related building services, including audit, design, installation, system integration, repair, maintenance and monitoring. In the opinion of management, the accompanying Unaudited Condensed Consolidated Financial Statements contain all adjustments (which include normal recurring adjustments) necessary to state fairly the financial position, results of operations and cash flows for the periods presented. Certain information and footnote disclosures normally included in financial statements prepared in accordance with accounting principles generally accepted in the United States ("U.S. GAAP") have been omitted pursuant to the rules and regulations of the United States Securities and Exchange Commission (the "SEC"). These unaudited condensed consolidated financial statements should be read in conjunction with the audited financial statements and notes thereto included in the Company's Annual Report on Form 10-K for 2020 filed with the SEC on February 9, 2021 (the "2020 Form 10-K").

[0001783180-21-000032:notes:2]
On April 3, 2020, (the "Distribution Date"), United Technologies Corporation, since renamed Raytheon Technologies Corporation ("UTC"), completed the spin-off of the Company into an independent, publicly traded company (the "Separation") through a pro-rata distribution (the "Distribution") on a one-for-one basis of all of the outstanding shares of common stock of the Company to UTC shareowners who held shares of UTC common stock as of the close of business on March 19, 2020, the record date of the Distribution. In connection with the Separation, the Company issued an aggregate principal balance of $11.0 billion of debt and transferred approximately $10.9 billion of cash to UTC on February 27, 2020 and March 27, 2020.

[0001783180-21-000032:notes:3]
In connection with the Separation, the Company entered into several agreements with UTC and Otis Worldwide Corporation ("Otis") that govern various aspects of the relationship between the Company, UTC and Otis following the Separation and the Distribution, including a transition services agreement ("TSA"), a tax matters agreement ("TMA"), an employee matters agreement and an intellectual property agreement that cover services such as information technology, tax, finance and human resources. In addition, the Company incurred separation-related costs including employee-related costs, costs to establish certain stand-alone functions, information technology systems, professional service fees and other costs associated with becoming an independent, publicly traded company. These costs are primarily recorded in Selling, general and administrative in the Unaudited Condensed Consolidated Statement of Operations and totaled $16 million and $45 million for the three months ended March 31, 2021 and 2020, respectively. The TSA expired on March 31, 2021.

[0001783180-21-000032:notes:4]
Impact of the COVID-19 Pandemic

[0001783180-21-000032:notes:5]
In early 2020, the World Health Organization declared the outbreak of a respiratory disease known as COVID-19 as a global pandemic. In response, many countries implemented containment and mitigation measures to combat the outbreak, which severely restricted the level of economic activity and caused a significant contraction in the global economy. As a result, the Company temporarily closed or reduced production at manufacturing facilities across the globe to ensure employee safety and instructed non-essential employees to work from home. In addition, the Company took several preemptive actions during the year to manage liquidity as demand for its products decreased. Despite the continued adverse impacts of the pandemic on the Company’s results since the first quarter of 2020, manufacturing operations resumed and several restorative actions were completed during 2020, including the reinstatement of annual merit-based salary increases and continued investment to support the Company's core strategy.

[0001783180-21-000032:notes:6]
The Company continues to focus its efforts on preserving the health and safety of its employees and customers as well as maintaining the continuity of its operations. In addition, the Company continues to actively monitor its liquidity position and working capital needs and believes that its overall capital resources and liquidity position are adequate. The preparation of financial statements requires management to use judgments in making estimates and assumptions based on the relevant information available at the end of each period which can have a significant effect on reported amounts. However, due to significant uncertainty surrounding the pandemic, management's judgments could change. While the Company's results of operations, cash flows and financial condition could be negatively impacted, the extent of the impact cannot be estimated with certainty at this time.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001783180-21-000032:notes:7]
BASIS OF PRESENTATION
The Unaudited Condensed Consolidated Financial Statements include all accounts of the Company and its wholly-owned and majority-owned subsidiaries in which it has control. All intra-company accounts and transactions have been eliminated. Related party transactions between the Company and its equity method investees have not been eliminated. Non-controlling interest represents a non-controlling investor's interests in the results of subsidiaries that the Company controls and consolidates. Certain prior year amounts have been reclassified to conform to the current period presentation.

[0001783180-21-000032:notes:8]
The Company's financial statements for periods prior to the Separation and the Distribution are prepared on a "carve-out" basis and include all amounts directly attributable to the Company. Net cash transfers and other property transferred between UTC and the Company, including related party receivables and payables between the Company and other UTC affiliates, are presented as Net transfers to UTC. In addition, the financial statements include allocations of costs for administrative functions and services performed on behalf of the Company by centralized groups within UTC. All allocations and estimates in the Unaudited Condensed Consolidated Financial Statements are based on assumptions that management believes are reasonable. The Company's financial statements for the periods subsequent to April 3, 2020 are consolidated financial statements based on the reported results of Carrier as a stand-alone company.

[0001783180-21-000032:notes:9]
Recently Adopted Accounting Pronouncements

[0001783180-21-000032:notes:10]
The Financial Accounting Standards Board ("FASB") Accounting Standards Codification ("ASC") is the sole source of authoritative U.S. GAAP other than SEC issued rules and regulations that apply only to SEC registrants. The FASB issues Accounting Standards Updates ("ASU") to communicate changes to the codification. The Company considers the applicability and impact of all ASUs. ASUs not referenced below were assessed and determined to be either not applicable or are not expected to have a material impact on the Unaudited Condensed Consolidated Financial Statements.

[0001783180-21-000032:notes:11]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes ("ASU 2019-12"), which simplifies certain aspects of income tax accounting guidance in ASC 740, reducing the complexity of its application while maintaining or improving the usefulness of the information required to be reported. The ASU eliminates certain exceptions from ASC 740 including: intra-period tax allocation, deferred tax liabilities related to outside basis differences and year-to-date loss in interim periods, among others. ASU 2019-12 was effective for periods beginning after December 15, 2020, including interim periods therein with early adoption permitted. The Company adopted this ASU on January 1, 2021 with no material impact on the Unaudited Condensed Consolidated Financial Statements.


## us-gaap:InventoryDisclosureTextBlock

[0001783180-21-000032:notes:12]
INVENTORIES, NET 
Inventories are stated at the lower of cost or estimated realizable value. Cost is primarily determined based on the first-in, first-out inventory method ("FIFO") or average cost methods, which approximates current replacement cost. However, certain subsidiaries use the last-in, first-out inventory method ("LIFO").

[0001783180-21-000032:notes:13]
The major classes of inventory are as follows:

[0001783180-21-000032:notes:14]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| Raw materials |  | $ | 407 |  |  | $ | 363 |  |
| Work-in-process |  | 171 |  |  | 143 |  |
| Finished goods |  | 1,276 |  |  | 1,123 |  |
| Inventories, net |  | $ | 1,854 |  |  | $ | 1,629 |  |

[0001783180-21-000032:notes:15]
The Company performs periodic assessments to determine the existence of excess and obsolete inventory and records necessary provisions to reduce such inventories to estimated realizable value. Raw materials, work-in-process and finished goods are net of valuation reserves of $182 million and $183 million as of March 31, 2021 and December 31, 2020, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001783180-21-000032:notes:16]
GOODWILL AND INTANGIBLE ASSETS 
The Company records goodwill as the excess of the purchase price over the fair value of the net assets acquired in a business combination. Goodwill is tested and reviewed annually for impairment during the third quarter or whenever there is a material change in events or circumstances that indicates that the fair value of the reporting unit may be less than its carrying value.

[0001783180-21-000032:notes:17]
The changes in the carrying amount of goodwill are as follows:

[0001783180-21-000032:notes:18]
| (In millions) |  | HVAC |  | Refrigeration |  | Fire & Security |  | Total |
| Balance as of December 31, 2020 |  | $ | 5,489 |  |  | $ | 1,251 |  |  | $ | 3,399 |  |  | $ | 10,139 |  |
| Goodwill resulting from business combinations |  | 5 |  |  | — |  |  | — |  |  | 5 |  |
| Foreign currency translation |  | (37) |  |  | (8) |  |  | (22) |  |  | (67) |  |
| Balance as of March 31, 2021 |  | $ | 5,457 |  |  | $ | 1,243 |  |  | $ | 3,377 |  |  | $ | 10,077 |  |

[0001783180-21-000032:notes:19]
Indefinite-lived intangible assets are tested and reviewed annually for impairment during the third quarter or whenever there is a material change in events or circumstances that indicates that the fair value of the asset may be less than the carrying amount of the asset. All other intangible assets with finite useful lives are amortized on a straight-line basis over their estimated useful lives.

[0001783180-21-000032:notes:20]
Identifiable intangible assets are comprised of the following:

[0001783180-21-000032:notes:21]
|  |  | March 31, 2021 |  | December 31, 2020 |
| (In millions) |  | Gross Amount |  | Accumulated Amortization |  | Gross Amount |  | Accumulated Amortization |
| Amortized: |  |  |  |  |  |  |  |  |
| Customer relationships |  | $ | 1,538 |  |  | $ | (1,284) |  |  | $ | 1,558 |  |  | $ | (1,285) |  |
| Patents and trademarks |  | 298 |  |  | (222) |  |  | 301 |  |  | (222) |  |
| Monitoring lines |  | 71 |  |  | (60) |  |  | 71 |  |  | (59) |  |
| Service portfolios and other |  | 638 |  |  | (541) |  |  | 644 |  |  | (542) |  |
|  |  | 2,545 |  |  | (2,107) |  |  | 2,574 |  |  | (2,108) |  |
| Unamortized: |  |  |  |  |  |  |  |  |
| Trademarks and other |  | 564 |  |  | — |  |  | 571 |  |  | — |  |
| Intangible assets, net |  | $ | 3,109 |  |  | $ | (2,107) |  |  | $ | 3,145 |  |  | $ | (2,108) |  |

[0001783180-21-000032:notes:22]
Amortization of Intangible assets was $24 million and $25 million for the three months ended March 31, 2021 and 2020, respectively.


## us-gaap:DebtDisclosureTextBlock

[0001783180-21-000032:notes:23]
BORROWINGS AND LINES OF CREDIT 
Long-term debt consisted of the following:

[0001783180-21-000032:notes:24]
| (In millions, except percentages) |  |  |  | March 31, 2021 |  | December 31, 2020 |
| 1.923% Notes due February 15, 2023 |  |  |  | $ | — |  | (1) | $ | 500 |  |
| 2.242% Notes due February 15, 2025 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.493% Notes due February 15, 2027 |  |  |  | 1,250 |  |  | 1,250 |  |
| 2.722% Notes due February 15, 2030 |  |  |  | 2,000 |  |  | 2,000 |  |
| 2.700% Notes due February 15, 2031 |  |  |  | 750 |  |  | 750 |  |
| 3.377% Notes due April 5, 2040 |  |  |  | 1,500 |  |  | 1,500 |  |
| 3.577% Notes due April 5, 2050 |  |  |  | 2,000 |  |  | 2,000 |  |
| Other (including project financing obligations and finance leases) |  |  |  | 307 |  |  | 308 |  |
| Total principal long-term debt |  |  |  | 9,807 |  |  | 10,308 |  |
| Other (discounts and debt issuance costs) (1) |  |  |  | (77) |  |  | (81) |  |
| Total debt |  |  |  | 9,730 |  |  | 10,227 |  |
| Less: current portion of long-term debt |  |  |  | 153 |  |  | 191 |  |
| Long-term debt, net of current portion |  |  |  | $ | 9,577 |  |  | $ | 10,036 |  |

[0001783180-21-000032:notes:25]
(1) In February 2021, the Company prepaid the 1.923% Notes due in February 2023 and incurred a $17 million make-whole premium upon prepayment and wrote-off $2 million of the remaining unamortized deferred financing costs.

[0001783180-21-000032:notes:26]
Revolving Credit Facility

[0001783180-21-000032:notes:27]
On February 10, 2020, the Company entered into a revolving credit agreement with various banks permitting aggregate borrowings of up to $2.0 billion pursuant to an unsecured, unsubordinated revolving credit facility that matures on April 3, 2025 (the "Revolving Credit Facility"). The Revolving Credit Facility supports the Company's commercial paper program and cash requirements of the Company. A commitment fee of 0.125% is charged on the unused commitments under the Revolving Credit Facility. Borrowings under the Revolving Credit Facility are available in U.S. Dollars, Euros and Pounds Sterling and bear interest at a variable interest rate based on LIBOR plus a ratings-based margin, which was 125 basis points as of March 31, 2021. As of March 31, 2021, there were no borrowings outstanding under the Revolving Credit Facility.

[0001783180-21-000032:notes:28]
Commercial Paper Program

[0001783180-21-000032:notes:29]
As of March 31, 2021, the Company had a $2.0 billion unsecured, unsubordinated commercial paper program, which can be used for general corporate purposes, including the funding of working capital and potential acquisitions. As of March 31, 2021, there were no borrowings outstanding under the commercial paper program.

[0001783180-21-000032:notes:30]
Project Financing Arrangements

[0001783180-21-000032:notes:31]
The Company is involved in several long-term construction contracts in which it arranges project financing with certain customers. As a result, the Company issued $46 million and $40 million of debt during the three months ended March 31, 2021 and 2020, respectively. Long-term debt repayments associated with these financing arrangements during the three months ended March 31, 2021 and 2020 were $53 million and $34 million, respectively.

[0001783180-21-000032:notes:32]
Debt Covenants

[0001783180-21-000032:notes:33]
The Revolving Credit Facility and the indenture for the long-term notes contain affirmative and negative covenants customary for financings of these types, which among other things, limit the Company's ability to incur additional liens, to make certain fundamental changes and to enter into sale and leaseback transactions. On June 2, 2020, the Company entered into an amendment of the Revolving Credit Facility, under which certain terms of the facility were amended for a period beginning on June 2, 2020 and ending on December 30, 2021 (the "Covenant Modification Period"). The Company may terminate the Covenant Modification Period prior to December 30, 2021, subject to the satisfaction of certain conditions. The amendment 
defers testing of the Company's consolidated total net leverage ratio financial covenant until June 30, 2021 and increases the consolidated total net leverage ratio limit until December 31, 2021. The amendment also requires the Company to maintain liquidity at a certain level until the earlier of (1) June 29, 2021 and (2) the last day of the Covenant Modification Period. Additionally, during the Covenant Modification Period, the Company is subject to: (a) limitations on the incurrence of subsidiary indebtedness, (b) limitations on the making of restricted payments, including purchases by the Company of shares of its common stock and the amount of dividends the Company may pay and (c) a "most favored nations" provision related to certain terms of any committed credit facility in an amount greater than $100 million. As of March 31, 2021, the Company was in compliance with the covenants under the agreements governing its outstanding indebtedness.


## us-gaap:FairValueDisclosuresTextBlock

[0001783180-21-000032:notes:34]
FAIR VALUE MEASUREMENTS
ASC 820, Fair Value Measurement ("ASC 820"), defines fair value as the price that would be received if an asset is sold or the price paid to transfer a liability in an orderly transaction between market participants at the measurement date. ASC 820 also establishes a three-level fair value hierarchy that prioritizes information used in developing assumptions when pricing an asset or liability as follows:

[0001783180-21-000032:notes:35]
•Level 1: Observable inputs such as quoted prices in active markets;

[0001783180-21-000032:notes:36]
•Level 2: Inputs, other than quoted prices in active markets, that are observable either directly or indirectly; and

[0001783180-21-000032:notes:37]
•Level 3: Unobservable inputs where there is little or no market data, which requires the reporting entity to develop its own assumptions.

[0001783180-21-000032:notes:38]
ASC 820 requires the use of observable market data, when available, in making fair value measurements. When inputs used to measure fair value fall within different levels of the hierarchy, the level within which the fair value measurement is categorized is based on the lowest level input that is significant to the fair value measurement.

[0001783180-21-000032:notes:39]
The Company invests a portion of its Cash and cash equivalents in money market mutual funds with original maturities of three months or less. Foreign currency transaction exposures are managed through operational strategies and the use of foreign currency hedging contracts. The following tables provide the valuation hierarchy classification of assets and liabilities that are recorded at fair value and measured on a recurring basis in the Company's Unaudited Condensed Consolidated Balance Sheet:

[0001783180-21-000032:notes:40]
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |
| March 31, 2021 |  |  |  |  |  |  |  |  |  |
| Recurring fair value measurement: |  |  |  |  |  |  |  |  |  |
| Money market mutual funds |  | $ | 38 |  | (1) |  | $ | — |  |  | $ | 38 |  |  | $ | — |  |
| Derivative assets |  | $ | 6 |  | (2) |  | $ | — |  |  | $ | 6 |  |  | $ | — |  |
| Derivative liabilities |  | $ | (20) |  | (3) |  | $ | — |  |  | $ | (20) |  |  | $ | — |  |
| December 31, 2020 |  |  |  |  |  |  |  |  |  |
| Recurring fair value measurement: |  |  |  |  |  |  |  |  |  |
| Money market mutual funds |  | $ | 38 |  | (1) |  | $ | — |  |  | $ | 38 |  |  | $ | — |  |
| Derivative assets |  | $ | 17 |  | (2) |  | $ | — |  |  | $ | 17 |  |  | $ | — |  |
| Derivative liabilities |  | $ | (5) |  | (3) |  | $ | — |  |  | $ | (5) |  |  | $ | — |  |

[0001783180-21-000032:notes:41]
(1) Included in Cash and cash equivalents on the accompanying Unaudited Condensed Consolidated Balance Sheet

[0001783180-21-000032:notes:42]
(2) Included in Other assets, current on the accompanying Unaudited Condensed Consolidated Balance Sheet

[0001783180-21-000032:notes:43]
(3) Included in Accrued liabilities on the accompanying Unaudited Condensed Consolidated Balance Sheet

[0001783180-21-000032:notes:44]
The following table provides the carrying amounts and fair values of financial instruments that are not recorded at fair value in the Company's Unaudited Condensed Consolidated Balance Sheet:

[0001783180-21-000032:notes:45]
|  |  | March 31, 2021 |  | December 31, 2020 |  |
| (In millions) |  | CarryingAmount |  | FairValue |  | CarryingAmount |  | FairValue |  |
| Current and long-term debt (excluding finance leases) |  | $ | 9,720 |  |  | $ | 9,884 |  |  | $ | 10,221 |  |  | $ | 11,115 |  |  |

[0001783180-21-000032:notes:46]
The following tables provide the valuation hierarchy classification of assets and liabilities that are not carried at fair value in the Company's Unaudited Condensed Consolidated Balance Sheet:

[0001783180-21-000032:notes:47]
| March 31, 2021 |  |  |  |  |  |  |  |  |  |
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  |
| Current and long-term debt (excluding finance leases) |  | $ | 9,884 |  |  | $ | 9,587 |  |  | $ | — |  |  | $ | 297 |  |  |

[0001783180-21-000032:notes:48]
| December 31, 2020 |  |  |  |  |  |  |  |  |  |
| (In millions) |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  |
| Current and long-term debt (excluding finance leases) |  | $ | 11,115 |  |  | $ | 10,811 |  |  | $ | — |  |  | $ | 304 |  |  |

[0001783180-21-000032:notes:49]
Valuation Techniques

[0001783180-21-000032:notes:50]
The Company's derivative assets and liabilities are measured at fair value using internal models based on observable market inputs, such as forward, interest, contract and discount rates. As of March 31, 2021 and 2020, the project financing obligations included in Long-term debt approximate fair value.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001783180-21-000032:notes:51]
EMPLOYEE BENEFIT PLANS 
The Company sponsors both funded and unfunded domestic and international defined benefit and defined contribution plans as well as other post-retirement benefit plans. In addition, the Company contributes to various domestic and international multi-employer defined benefit pension and other post-retirement benefit plans.

[0001783180-21-000032:notes:52]
[same as prior period, unchanged from 0001783180-20-000067:notes:96]

[0001783180-21-000032:notes:53]
|  |  | For the Three Months Ended March 31, |  |  |
| (In millions) |  | 2021 |  | 2020 |  |  |  |  |
| Defined benefit plans |  | $ | 24 |  |  | $ | 25 |  |  |  |  |  |
| Defined contribution plans |  | $ | 37 |  |  | $ | 30 |  |  |  |  |  |
| Multi-employer pension plans |  | $ | 5 |  |  | $ | 5 |  |  |  |  |  |

[0001783180-21-000032:notes:54]
The following table illustrates the components of net periodic pension benefits for the defined benefit pension and post-retirement benefit plans:

[0001783180-21-000032:notes:55]
|  |  | For the Three Months Ended March 31, |  |  |  |  |
| (In millions) |  | 2021 |  | 2020 |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 7 |  |  | $ | 8 |  |  |  |  |  |  |  |  |  |
| Interest cost |  | 9 |  |  | 13 |  |  |  |  |  |  |  |  |  |
| Expected return on plan assets |  | (36) |  |  | (35) |  |  |  |  |  |  |  |  |  |
| Amortization of prior service credit |  | 1 |  |  | 1 |  |  |  |  |  |  |  |  |  |
| Recognized actuarial net (gain) loss |  | 8 |  |  | 5 |  |  |  |  |  |  |  |  |  |
| Net settlement, curtailment and special termination benefit (gain) loss |  | — |  |  | 1 |  |  |  |  |  |  |  |  |  |
| Net periodic pension expense (benefit) |  | $ | (11) |  |  | $ | (7) |  |  |  |  |  |  |  |  |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001783180-21-000032:notes:56]
GUARANTEES
The Company provides service and warranty coverage on its products and extends performance and operating cost guarantees beyond normal service and warranty coverage on certain products. In addition, the Company incurs discretionary costs to service its products in connection with specific product performance issues. Liabilities for performance and operating cost guarantees are based upon future product performance and durability and are largely estimated based upon historical experience. Adjustments are recorded to accruals based on claims data and historical experience. The changes in the carrying amount of service and product warranties and product performance guarantees, included in Accrued liabilities on the accompanying Unaudited Condensed Consolidated Balance Sheet, for the three months ended March 31, 2021 and 2020 are as follows:

[0001783180-21-000032:notes:57]
|  |  | For the Three Months Ended March 31, |
| (In millions) |  | 2021 |  | 2020 |
| Balance as of January 1, |  | $ | 514 |  |  | $ | 488 |  |
| Warranties, performance guarantees issued and changes in estimated liability |  | 39 |  |  | 35 |  |
| Settlements made |  | (38) |  |  | (39) |  |
| Other |  | (1) |  |  | (3) |  |
| Balance as of March 31, |  | $ | 514 |  |  | $ | 481 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001783180-21-000032:notes:58]
EQUITY 
The authorized number of shares of common stock of Carrier is 4,000,000,000 shares of $0.01 par value. As of March 31, 2021, 869,789,967 shares of common stock were issued, which includes 976,374 shares of treasury stock.

[0001783180-21-000032:notes:59]
Share Repurchase Program

[0001783180-21-000032:notes:60]
On February 4, 2021, the Company's Board of Directors approved a stock repurchase program authorizing the repurchase of up to $350 million of the Company's outstanding common stock. The Company may repurchase shares from time to time subject to market conditions and at the Company's discretion in the open market or through one or more other public or private transactions, subject to compliance with the Company's obligations under the TMA and the Revolving Credit Facility. The Company records repurchases under the cost method whereby the entire cost of the acquired stock is recorded as Treasury stock as a reduction to equity. The reissuance of treasury stock uses the first-in, first-out method of accounting.

[0001783180-21-000032:notes:61]
For the three months ended March 31, 2021, the Company repurchased 976,374 shares of common stock for an aggregate purchase price of $38 million, which are held in Treasury stock as of March 31, 2021 as reflected on its Unaudited Condensed Consolidated Balance Sheet.

[0001783180-21-000032:notes:62]
Accumulated Other Comprehensive Income (Loss)

[0001783180-21-000032:notes:63]
A summary of the changes in each component of Accumulated other comprehensive income (loss), net of tax is as follows:

[0001783180-21-000032:notes:64]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2020 |  | $ | (191) |  |  | $ | (554) |  |  |  |  |  |  | $ | (745) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (121) |  |  | — |  |  |  |  |  |  | (121) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 9 |  |  |  |  |  |  | 9 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (2) |  |  |  |  |  |  | (2) |  |
| Balance as of March 31, 2021 |  | $ | (312) |  |  | $ | (547) |  |  |  |  |  |  | $ | (859) |  |

[0001783180-21-000032:notes:65]
| (In millions) |  | Foreign Currency Translation |  | Defined Benefit Pension and Post-retirement Plans |  |  |  |  |  | Accumulated Other Comprehensive Income (Loss) |
| Balance as of December 31, 2019 |  | $ | (780) |  |  | $ | (473) |  |  |  |  |  |  | $ | (1,253) |  |
| Other comprehensive income (loss) before reclassifications, net |  | (488) |  |  | — |  |  |  |  |  |  | (488) |  |
| Amounts reclassified, pre-tax |  | — |  |  | 6 |  |  |  |  |  |  | 6 |  |
| Tax expense (benefit) reclassified |  | — |  |  | (1) |  |  |  |  |  |  | (1) |  |
| Balance as of March 31, 2020 |  | $ | (1,268) |  |  | $ | (468) |  |  |  |  |  |  | $ | (1,736) |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001783180-21-000032:notes:66]
REVENUE RECOGNITION 
The Company recognizes revenue when control of a good or service promised in a contract (i.e., performance obligation) is transferred to a customer. Control is obtained when a customer has the ability to direct the use of and obtain substantially all of the remaining benefit from that good or service. A significant portion of the Company's performance obligations are recognized at a point-in-time when control of the product transfers to the customer, which is generally at the time of shipment. The remaining portion of the Company's performance obligations are recognized over time as the customer simultaneously obtains control as the Company performs work under a contract, or if the product being produced for the customer has no alternative use and the Company has a contractual right to payment.

[0001783180-21-000032:notes:67]
Sales disaggregated by product and service are as follows:

[0001783180-21-000032:notes:68]
|  |  | For the Three Months Ended March 31, |  |  |
| (In millions) |  | 2021 |  | 2020 |  |  |  |  |
| Sales Type |  |  |  |  |  |  |  |  |
| Product |  | $ | 2,147 |  |  | $ | 1,657 |  |  |  |  |  |
| Service |  | 339 |  |  | 302 |  |  |  |  |  |
| HVAC sales |  | 2,486 |  |  | 1,959 |  |  |  |  |  |
| Product |  | 892 |  |  | 713 |  |  |  |  |  |
| Service |  | 113 |  |  | 95 |  |  |  |  |  |
| Refrigeration sales |  | 1,005 |  |  | 808 |  |  |  |  |  |
| Product |  | 919 |  |  | 860 |  |  |  |  |  |
| Service |  | 385 |  |  | 346 |  |  |  |  |  |
| Fire & Security sales |  | 1,304 |  |  | 1,206 |  |  |  |  |  |
| Total segment sales |  | 4,795 |  |  | 3,973 |  |  |  |  |  |
| Eliminations and other |  | (96) |  |  | (85) |  |  |  |  |  |
| Net sales |  | $ | 4,699 |  |  | $ | 3,888 |  |  |  |  |  |

[0001783180-21-000032:notes:69]
Contract Balances

[0001783180-21-000032:notes:70]
Total contract assets and liabilities arising from contracts with customers are as follows:

[0001783180-21-000032:notes:71]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| Contract assets, current |  | $ | 694 |  |  | $ | 656 |  |
| Contract assets, non-current (included within Other assets) |  | 137 |  |  | 98 |  |
| Total contract assets |  | 831 |  |  | 754 |  |
| Contract liabilities, current |  | (545) |  |  | (512) |  |
| Contract liabilities, non-current (included within Other long-term liabilities) |  | (170) |  |  | (165) |  |
| Total contract liabilities |  | (715) |  |  | (677) |  |
| Net contract assets |  | $ | 116 |  |  | $ | 77 |  |

[0001783180-21-000032:notes:72]
The timing of revenue recognition, billings and cash collections results in contract assets and contract liabilities. Contract assets relate to the conditional right to consideration for any completed performance under a contract when costs are incurred in excess of billings under the percentage-of-completion methodology. Contract liabilities relate to payments received in advance of performance under the contract or when the Company has a right to consideration that is unconditional before it transfers a good or service to the customer. Contract liabilities are recognized as revenue as (or when) the Company performs under the contract. The Company recognized revenue of $189 million during the three months ended March 31, 2021 that related to the contract liabilities balance as of January 1, 2021. The Company expects a majority of its contract liability balance at the end of the period to be recognized as revenue in the next 12 months.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001783180-21-000032:notes:73]
RESTRUCTURING COSTS
The Company incurs costs associated with restructuring initiatives intended to improve operating performance, profitability and working capital levels. Actions associated with these initiatives may include improving productivity, workforce reductions and the consolidation of facilities.

[0001783180-21-000032:notes:74]
The Company recorded net pre-tax restructuring costs for new and ongoing restructuring initiatives as follows:

[0001783180-21-000032:notes:75]
|  | For the Three Months Ended March 31, |  |  |
| (In millions) | 2021 |  | 2020 |  |  |  |  |
| HVAC | $ | 4 |  |  | $ | 2 |  |  |  |  |  |
| Refrigeration | 2 |  |  | — |  |  |  |  |  |
| Fire & Security | 11 |  |  | 3 |  |  |  |  |  |
| Total Segment | 17 |  |  | 5 |  |  |  |  |  |
| General corporate expenses | 1 |  |  | — |  |  |  |  |  |
| Total restructuring costs | $ | 18 |  |  | $ | 5 |  |  |  |  |  |
| Cost of sales | $ | 5 |  |  | $ | 1 |  |  |  |  |  |
| Selling, general and administrative | 13 |  |  | 4 |  |  |  |  |  |
| Total restructuring costs | $ | 18 |  |  | $ | 5 |  |  |  |  |  |

[0001783180-21-000032:notes:76]
The following table summarizes the reserves and charges related to restructuring actions:

[0001783180-21-000032:notes:77]
|  |  | For the Three Months Ended March 31, |
| (In millions) |  | 2021 |  | 2020 |
| Balance as of January 1, |  | $ | 49 |  |  | $ | 66 |  |
| Net pre-tax restructuring costs |  | 18 |  |  | 5 |  |
| Utilization, foreign exchange and other costs |  | (18) |  |  | (24) |  |
| Balance as of March 31, |  | $ | 49 |  |  | $ | 47 |  |

[0001783180-21-000032:notes:78]
During the three months ended March 31, 2021, charges associated with restructuring initiatives related to cost reduction efforts. Amounts recognized primarily related to severance due to workforce reductions and exit costs due to the consolidation of field operations. As of March 31, 2021, the Company had $49 million accrued for costs associated with its announced restructuring initiatives, all of which is expected to be paid within one year.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001783180-21-000032:notes:79]
INCOME TAXES 
The Company accounts for Income tax expense in accordance with ASC 740, Income Taxes, which requires that an estimate of the annual effective income tax rate for the full year to be applied to the respective interim period, taking into account year-to-date amounts and projected results for the full year. The effective tax rate for the three months ended March 31, 2021 was 21.0% compared with 65.4% for the three months ended March 31, 2020. The year-over-year decrease is primarily due to the recognition of a favorable tax adjustment of $21 million resulting from a re-organization in our German subsidiaries and the absence of a prior year charge of $51 million related to a valuation allowance recorded against a United Kingdom tax loss and credit carryforward and a $46 million charge resulting from the Company's decision to no longer permanently reinvest certain pre-2018 unremitted non-U.S. earnings.

[0001783180-21-000032:notes:80]
Income taxes through March 31, 2020 were recorded based on a "carve-out" and separate company basis. Prior to the Separation and the Distribution, the Company’s portion of income taxes for domestic and certain foreign jurisdictions were deemed settled in the period the related tax expense was recorded. After the Separation and the Distribution, the Company’s income taxes are prepared on a stand-alone basis.

[0001783180-21-000032:notes:81]
The Company assesses the realizability of its deferred tax assets on a quarterly basis through an analysis of potential sources of future taxable income, including prior year taxable income that may be available to absorb a carryback of tax losses, reversals of existing taxable temporary differences, tax planning strategies and forecasts of taxable income. The Company considers all negative and positive evidence, including the weight of the evidence, to determine whether valuation allowances against deferred tax assets are required. The Company maintains valuation allowances against certain deferred tax assets.

[0001783180-21-000032:notes:82]
The Company conducts business globally and files income tax returns in U.S. federal, state and foreign jurisdictions. In certain jurisdictions, the Company's operations were included in UTC's combined tax returns for the periods through the Distribution. The U.S. Internal Revenue Service ("IRS") commenced an audit of UTC's tax years 2017 and 2018 in the second quarter of 2020. In the normal course of business, the Company is subject to examination by taxing authorities throughout the world, including Australia, Belgium, Canada, China, Czech Republic, France, Germany, Hong Kong, India, Italy, Mexico, Netherlands, Singapore, the United Kingdom and the United States. The Company is no longer subject to U.S. federal income tax examination for years prior to 2017 and, with few exceptions, is no longer subject to state, local and foreign income tax examinations for tax years prior to 2013.

[0001783180-21-000032:notes:83]
In the ordinary course of business, there is inherent uncertainty in quantifying the Company's income tax positions. The Company assesses its income tax positions and records tax benefits for all years subject to examination based upon management’s evaluation of the facts, circumstances and information available at the reporting date. The Company believes that it is reasonably possible that a net decrease in unrecognized tax benefits of between $15 million and $40 million may occur within 12 months as a result of additional uncertain tax positions, the Separation, the revaluation of uncertain tax positions arising from examinations, appeals, court decisions and/or the expiration of tax statutes.


## us-gaap:EarningsPerShareTextBlock

[0001783180-21-000032:notes:84]
EARNINGS PER SHARE 
Earnings per share is computed by dividing Net income attributable to common shareowners by the weighted-average number of shares of common stock outstanding during the period (excluding treasury stock). Diluted earnings per share is computed by giving effect to all potentially dilutive stock awards that are outstanding. The computation of diluted earnings per share excludes the effect of the potential exercise of stock-based awards, including stock appreciation rights and stock options, when the effect of the potential exercise would be anti-dilutive.

[0001783180-21-000032:notes:85]
|  |  | Three Months Ended March 31, |  |  |
| (In millions, except per share amounts) |  | 2021 |  | 2020 |  |  |  |  |
| Net income attributable to common shareowners |  | $ | 384 |  |  | $ | 96 |  |  |  |  |  |
| Basic weighted-average number of shares outstanding |  | 869.3 |  |  | 866.2 |  |  |  |  |  |
| Stock awards and equity units (share equivalent) |  | 20.5 |  |  | — |  |  |  |  |  |
| Diluted weighted-average number of shares outstanding |  | 889.8 |  |  | 866.2 |  |  |  |  |  |
| Antidilutive shares excluded from computation of diluted earnings per share |  | 3.3 |  |  | — |  |  |  |  |  |
| Earnings Per Share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.44 |  |  | $ | 0.11 |  |  |  |  |  |
| Diluted |  | $ | 0.43 |  |  | $ | 0.11 |  |  |  |  |  |

[0001783180-21-000032:notes:86]
On the Distribution Date, 866,158,910 shares of the Company’s common stock, par value $0.01 per share, were distributed to UTC shareowners of record as of March 19, 2020. This share amount is utilized for the calculation of basic and diluted earnings per share for all periods presented prior to the Separation and the Distribution and such shares are treated as issued and outstanding for purposes of calculating historical earnings per share. It is assumed that there are no dilutive equity instruments for the periods prior to the Separation and Distribution because there were no Carrier stock-based awards outstanding prior to the Separation and the Distribution.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001783180-21-000032:notes:87]
SEGMENT FINANCIAL DATA 
The Company has three operating segments:

[0001783180-21-000032:notes:88]
•The HVAC segment provides products, controls, services and solutions to meet the heating, cooling and ventilation needs of residential and commercial customers while enhancing building performance, health, energy efficiency and sustainability.

[0001783180-21-000032:notes:89]
•The Refrigeration segment includes transport refrigeration and monitoring products, services and digital solutions for trucks, trailers, shipping containers, intermodal and rail, as well as commercial refrigeration products.

[0001783180-21-000032:notes:90]
•The Fire & Security segment provides a wide range of residential, commercial and industrial technologies and systems, and service solutions to protect people and property.

[0001783180-21-000032:notes:91]
Our customers are in both the public and private sectors and our businesses reflect extensive geographic diversification. Inter-company sales between segments are immaterial.

[0001783180-21-000032:notes:92]
Net sales and Operating profit by segment are as follows:

[0001783180-21-000032:notes:93]
|  |  | Net Sales |  | Operating Profit |
|  |  | For the Three Months Ended March 31, |  | For the Three Months Ended March 31, |
| (In millions) |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| HVAC |  | $ | 2,486 |  |  | $ | 1,959 |  |  | $ | 365 |  |  | $ | 167 |  |
| Refrigeration |  | 1,005 |  |  | 808 |  |  | 127 |  |  | 99 |  |
| Fire & Security |  | 1,304 |  |  | 1,206 |  |  | 150 |  |  | 120 |  |
| Total segment |  | 4,795 |  |  | 3,973 |  |  | 642 |  |  | 386 |  |
| Eliminations and other |  | (96) |  |  | (85) |  |  | (40) |  |  | (35) |  |
| General corporate expenses |  | — |  |  | — |  |  | (31) |  |  | (36) |  |
| Total Consolidated |  | $ | 4,699 |  |  | $ | 3,888 |  |  | $ | 571 |  |  | $ | 315 |  |

[0001783180-21-000032:notes:94]
Geographic external sales are attributed to the geographic regions based on their location of origin. With the exception of the U.S. presented in the table below, there were no individually significant countries with sales exceeding 10% of total sales during the three months ended March 31, 2021 and 2020.

[0001783180-21-000032:notes:95]
|  |  | For the Three Months Ended March 31, |  |  |  |  |  |
| (In millions) |  | 2021 |  | 2020 |  |  |  |  |  |  |  |
| United States |  | $ | 2,353 |  |  | $ | 2,011 |  |  |  |  |  |  |  |  |
| International: |  |  |  |  |  |  |  |  |  |  |  |
| Europe |  | 1,398 |  |  | 1,179 |  |  |  |  |  |  |  |  |
| Asia Pacific |  | 742 |  |  | 519 |  |  |  |  |  |  |  |  |
| Other |  | 206 |  |  | 179 |  |  |  |  |  |  |  |  |
| Net sales |  | $ | 4,699 |  |  | $ | 3,888 |  |  |  |  |  |  |  |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001783180-21-000032:notes:96]
RELATED PARTIES 
Equity Method Investments

[0001783180-21-000032:notes:97]
The Company sells products to and purchases products from unconsolidated entities accounted for under the equity method and, therefore, these entities are considered to be related parties. Amounts attributable to equity method investees are as follows:

[0001783180-21-000032:notes:98]
|  |  | Three Months Ended March 31, |  |  |
| (In millions) |  | 2021 |  | 2020 |  |  |  |  |
| Sales to equity method investees included in Product sales |  | $ | 468 |  |  | $ | 344 |  |  |  |  |  |
| Purchases from equity method investees included in Cost of products sold |  | $ | 75 |  |  | $ | 77 |  |  |  |  |  |

[0001783180-21-000032:notes:99]
The Company had receivables from and payables to equity method investees as follows:

[0001783180-21-000032:notes:100]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| Receivables from equity method investees included in Accounts receivable, net |  | $ | 197 |  |  | $ | 161 |  |
| Payables to equity method investees included in Accounts payable |  | $ | 45 |  |  | $ | 38 |  |

[0001783180-21-000032:notes:101]
The Company periodically reviews the carrying value of its equity method investments to determine if there has been an other-than-temporary decline in fair value. A variety of factors are considered when determining if a decline in carrying value is 
other-than-temporary, including, among other factors, the financial condition and business prospects of the investee, as well as the Company's intent with regard to the investment. During the three months ended March 31, 2020, the Company determined that indicators of impairment existed for a minority owned joint venture investment. The Company performed a valuation of this investment, which was based on the income approach using the discounted cash flow method. The Company determined that the loss in value was other-than-temporary due to a reduction in sales and earnings that were driven by a deterioration in the oil and gas industry (the joint venture's primary market) and by the impact of the COVID-19 pandemic, among other factors. As a result, the Company recorded a non-cash, other-than-temporary impairment charge of $71 million on this investment during the three months ended March 31, 2020, which is included in Other income (expense), net on the accompanying Unaudited Condensed Consolidated Statement of Operations.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001783180-21-000032:notes:102]
COMMITMENTS AND CONTINGENT LIABILITIES
The Company is involved in various litigation, claims and administrative proceedings, including those related to environmental (including asbestos) and legal matters. In accordance with ASC 450, Contingencies ("ASC 450"), the Company records accruals for loss contingencies when it is probable that a liability will be incurred and the amount of the loss can be reasonably estimated. These accruals are generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount. In addition, these estimates are reviewed periodically and adjusted to reflect additional information when it becomes available. The Company is unable to predict the final outcome of the following matters based on the information currently available, except as otherwise noted. However, the Company does not believe that the resolution of any of these matters will have a material adverse effect upon the Company's competitive position, results of operations, cash flows or financial condition.

[0001783180-21-000032:notes:103]
Environmental Matters

[0001783180-21-000032:notes:104]
The Company’s operations are subject to environmental regulation by various authorities. The Company has accrued for the costs of environmental remediation activities, including but not limited to investigatory, remediation, operating and maintenance costs and performance guarantees and the Company periodically reassesses these amounts. Management believes that the likelihood of incurring losses materially in excess of the amounts accrued is remote. The outstanding liabilities for environmental obligations are as follows:

[0001783180-21-000032:notes:105]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| Environmental reserves included in Accrued liabilities |  | $ | 25 |  |  | $ | 26 |  |
| Environmental reserves included in Other long-term liabilities |  | 210 |  |  | 213 |  |
| Total Environmental reserves |  | $ | 235 |  |  | $ | 239 |  |

[0001783180-21-000032:notes:106]
Asbestos Matters

[0001783180-21-000032:notes:107]
The Company and its consolidated subsidiaries have been named as defendants in lawsuits alleging personal injury as a result of exposure to asbestos allegedly integrated into certain Carrier products or business premises. While the Company has never manufactured asbestos and no longer incorporates it into any currently-manufactured products, certain products that the Company no longer manufactures contained components incorporating asbestos. A substantial majority of these asbestos-related claims have been dismissed without payment or have been covered in full or in part by insurance or other forms of indemnity. Additional cases were litigated and settled without any insurance reimbursement. The amounts involved in asbestos-related claims were not material individually or in the aggregate in any period.

[0001783180-21-000032:notes:108]
The Company had asbestos liabilities and related recoveries as follows:

[0001783180-21-000032:notes:109]
| (In millions) |  | March 31, 2021 |  | December 31, 2020 |
| Asbestos liabilities included in Accrued liabilities |  | $ | 18 |  |  | $ | 17 |  |
| Asbestos liabilities included in Other long-term liabilities |  | 225 |  |  | 228 |  |
| Total Asbestos liabilities |  | $ | 243 |  |  | $ | 245 |  |
| Asbestos-related recoveries included in Other assets, current |  | $ | 6 |  |  | $ | 6 |  |
| Asbestos-related recoveries included in Other assets |  | 96 |  |  | 97 |  |
| Total Asbestos-related recoveries |  | $ | 102 |  |  | $ | 103 |  |

[0001783180-21-000032:notes:110]
The amounts recorded for asbestos-related liabilities are based on currently available information and assumptions that the Company believes are reasonable and are made with input from outside actuarial experts. Where no amount within a range of estimates is more likely, the minimum is accrued. These amounts are undiscounted and exclude the Company’s legal fees to defend the asbestos claims, which are expensed as incurred. In addition, the Company has recorded an insurance recovery receivable for probable asbestos-related recoveries.

[0001783180-21-000032:notes:111]
UTC Equity Awards Conversion Litigation

[0001783180-21-000032:notes:112]
On August 12, 2020, several former employees of UTC or its subsidiaries filed a putative class action complaint (the "Complaint") in the United States District Court for the District of Connecticut against Raytheon Technologies Corporation, Carrier, Otis, the former members of the UTC Board of Directors and the members of the Carrier and Otis Boards of Directors (Geraud Darnis, et al. v. Raytheon Technologies Corporation, et al.). The Complaint challenges the method by which UTC equity awards were converted to UTC, Carrier and Otis equity awards following the Separation and the Distribution. The Complaint asserted that the defendants are liable for breach of certain equity compensation plans and for breach of fiduciary duty and also asserted claims under certain provisions of the Employee Retirement Income Security Act of 1974, as amended. Plaintiffs recently withdrew, with prejudice, their claims against Otis's and Carrier's current Boards of Directors. Carrier believes that the remaining claims against the Company are without merit.

[0001783180-21-000032:notes:113]
Aqueous Film Forming Foam Litigation

[0001783180-21-000032:notes:114]
Aqueous Film Forming Foam ("AFFF") is a firefighting foam developed in the 1970s pursuant to U.S. military specification and used to extinguish certain types of fires primarily at airports and military bases. AFFF was manufactured by several companies, including National Foam and Angus Fire. UTC acquired the National Foam and Angus Fire businesses in 2005 as part of the acquisition of Kidde, which had been operated by Carrier. In 2013, UTC divested the National Foam and Angus Fire businesses to a third party.

[0001783180-21-000032:notes:115]
The Company and many other parties, including the third-party buyer of the National Foam and Angus Fire businesses, have been named as defendants in over 900 cases, including putative class actions and other lawsuits, alleging that the historic use of AFFF caused personal injuries and property damage. Additionally, several state, municipal and water utility plaintiffs have commenced litigation against the same defendants to recover remediation costs related to historic use of AFFF. In December 2018, the U.S. Judicial Panel on Multidistrict Litigation ("MDL") transferred and consolidated all of the AFFF cases pending in the federal courts to the U.S. District Court for the District of South Carolina for pre-trial proceedings.

[0001783180-21-000032:notes:116]
Plaintiffs in the MDL allege that a chemical ingredient in AFFF contains, or breaks down into, compounds known as perflourooctane sulfonate ("PFOS") and perflourooctane acid ("PFOA") that were released into the environment and, in some instances, ultimately leached into drinking water supplies. National Foam and Angus Fire purchased these perflourinated chemical ingredients from third-party chemical manufacturers to manufacture AFFF. Chemicals containing PFOS and PFOA (or their precursors) have also been used for decades by many third parties to manufacture carpets, clothing, fabrics, cookware and other consumer products. The individual plaintiffs in the MDL generally seek compensatory damages for alleged personal injuries, medical monitoring and diminution in property value and injunctive relief to remediate alleged contamination of water supplies. The U.S., state, municipal and water utility plaintiffs in the MDL generally seek damages and costs related to the remediation of public property and water supplies.

[0001783180-21-000032:notes:117]
The Company and other defendants are also party to fewer than 10 cases in state court brought by oil refining companies in the U.S. alleging product liability claims related to legacy sales of AFFF and seeking damages for the costs to replace the product and for property damage.

[0001783180-21-000032:notes:118]
The Company and other defendants are also party to an action related to the AFFF manufacturing facility that was operated by National Foam and Angus Fire in which the plaintiff water utility seeks remediation costs related to the alleged contamination of the local water supply.

[0001783180-21-000032:notes:119]
The Company believes that it has meritorious defenses to these claims and the Company is also seeking insurance coverage for these claims. At this time, however, given the numerous factual, scientific and legal issues to be resolved relating to these claims, the Company is unable to assess the probability of liability or reasonably estimate the damages, if any, to be allocated to the Company, if one or more plaintiffs were to prevail in these cases, and there can be no assurance that any such future exposure will not be material in any period.

[0001783180-21-000032:notes:120]
Income Taxes

[0001783180-21-000032:notes:121]
Under the TMA, the Company is responsible to UTC for its share of the Tax Cuts and Jobs Act ("TCJA") transition tax associated with foreign undistributed earnings as of December 31, 2017. As of March 31, 2021, a liability of $72 million, primarily related to the Company's share of the TCJA transition tax associated with foreign undistributed earnings is included within Other long-term liabilities on the accompanying Unaudited Condensed Consolidated Balance Sheet. The Company believes that the likelihood of incurring losses materially in excess of this amount is remote.

[0001783180-21-000032:notes:122]
Other

[0001783180-21-000032:notes:123]
The Company has other commitments and contingent liabilities related to legal proceedings, self-insurance programs and matters arising in the ordinary course of business. The Company accrues for contingencies generally based upon a range of possible outcomes. If no amount within the range is a better estimate than any other, the Company accrues the minimum amount.

[0001783180-21-000032:notes:124]
In the ordinary course of business, the Company is also routinely a defendant in, party to or otherwise subject to many pending and threatened legal actions, claims, disputes and proceedings. These matters are often based on alleged violations of contract, product liability, warranty, regulatory, environmental, health and safety, employment, intellectual property, tax and other laws. In some of these proceedings claims for substantial monetary damages are asserted against the Company and could result in fines, penalties, compensatory or treble damages or non-monetary relief. The Company does not believe that these matters will have a material adverse effect upon its competitive position, results of operations, cash flows or financial condition.


## us-gaap:SubsequentEventsTextBlock

[0001783180-21-000032:notes:125]
SUBSEQUENT EVENTS 
On April 19, 2021, the Board of Directors declared a dividend of $0.12 per share of common stock payable on May 24, 2021 to shareowners of record at the close of business on May 3, 2021.

[0001783180-21-000032:notes:126]
On April 19, 2021, the Company announced that it signed agreements to acquire a controlling stake in Guangdong Giwee Group and its subsidiaries ("Giwee"). Giwee is a China-based manufacturer of HVAC products, offering a portfolio of products including variable refrigerant flow, modular chillers and light commercial air conditioners. The Company expects to close its acquisition of a controlling stake of Giwee in the second quarter of 2021 (with the remainder expected to close in the third quarter of 2021), subject to customary closing conditions, including regulatory approvals.
