# FN 8-K — 0001408710-22-000058 filed 2022-11-07

## item codes, every 8-K on or before 2022-11-08

- 2022-11-07 0001408710-22-000058 — 2.02, 9.01
- 2022-08-15 0001408710-22-000041 — 2.02, 5.02, 9.01
- 2022-05-02 0001408710-22-000026 — 2.02, 9.01
- 2022-01-31 0001408710-22-000016 — 2.02, 9.01
- 2022-01-19 0001408710-22-000010 — 5.02
- 2022-01-06 0001408710-22-000006 — 5.02
- 2021-12-10 0001408710-21-000051 — 5.07
- 2021-11-01 0001408710-21-000045 — 2.02, 9.01
- 2021-08-16 0001408710-21-000031 — 2.02, 5.02, 9.01
- 2021-05-03 0001408710-21-000019 — 2.02, 9.01
- 2021-02-01 0001408710-21-000008 — 2.02, 9.01
- 2020-12-11 0001193125-20-315861 — 5.07
- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2022-11-08

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001408710-22-000058:8k_2_02:1]
EX-99.1
2
fn-20221107xex991q123.htm
EX-99.1

[0001408710-22-000058:8k_2_02:2]
Document

[0001408710-22-000058:8k_2_02:3]
Exhibit 99.1

[0001408710-22-000058:8k_2_02:4]
Fabrinet Announces First Quarter Fiscal Year 2023 Financial Results

[0001408710-22-000058:8k_2_02:5]
•Record First Quarter Revenue of $655.4 Million Exceeds Guidance

[0001408710-22-000058:8k_2_02:6]
•Record GAAP and Non-GAAP Net Income per Share Exceeds Guidance

[0001408710-22-000058:8k_2_02:7]
BANGKOK, Thailand – November 7, 2022 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its first quarter of fiscal year 2023 ended September 30, 2022.

[0001408710-22-000058:8k_2_02:8]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “We delivered strong revenue that exceeded our guidance and executed well to produce robust margins, particularly for a first quarter. This performance, combined with favorable foreign exchange tailwinds helped produce earnings per share that were well above the high-end of our guidance range. We are optimistic that favorable demand trends and our track record of execution will extend into the second quarter to produce another quarter of strong financial results.”

[0001408710-22-000058:8k_2_02:9]
First Quarter Fiscal Year 2023 Financial Highlights

[0001408710-22-000058:8k_2_02:10]
GAAP Results

[0001408710-22-000058:8k_2_02:11]
•Revenue for the first quarter of fiscal year 2023, a 14-week quarter, was $655.4 million, compared to $543.3 million for the first quarter of fiscal year 2022, a 13-week quarter.

[0001408710-22-000058:8k_2_02:12]
•GAAP net income for the first quarter of fiscal year 2023 was $64.6 million, compared to $44.7 million for the first quarter of fiscal year 2022.

[0001408710-22-000058:8k_2_02:13]
•GAAP net income per diluted share for the first quarter of fiscal year 2023 was $1.76, compared to $1.20 for the first quarter of fiscal year 2022.

[0001408710-22-000058:8k_2_02:14]
Non-GAAP Results

[0001408710-22-000058:8k_2_02:15]
•Non-GAAP net income for the first quarter of fiscal year 2023 was $72.4 million, compared to $54.2 million for the first quarter of fiscal year 2022.

[0001408710-22-000058:8k_2_02:16]
•Non-GAAP net income per diluted share for the first quarter of fiscal year 2023 was $1.97, compared to $1.45 for the first quarter of fiscal year 2022.

[0001408710-22-000058:8k_2_02:17]
Business Outlook

[0001408710-22-000058:8k_2_02:18]
Based on information available as of November 7, 2022, Fabrinet is issuing guidance for its second quarter of fiscal year 2023, a 13-week quarter ending December 30, 2022, as follows:

[0001408710-22-000058:8k_2_02:19]
•Fabrinet expects second quarter revenue to be in the range of $640 million to $660 million.

[0001408710-22-000058:8k_2_02:20]
•GAAP net income per diluted share is expected to be in the range of $1.67 to $1.74, based on approximately 37.6 million fully diluted shares outstanding.

[0001408710-22-000058:8k_2_02:21]
•Non-GAAP net income per diluted share is expected to be in the range of $1.86 to $1.93, based on approximately 37.6 million fully diluted shares outstanding.

[0001408710-22-000058:8k_2_02:22]
Conference Call Information

[0001408710-22-000058:8k_2_02:23]
| What: |  | Fabrinet First Quarter Fiscal Year 2023 Financial Results Call |
| When: |  | November 7, 2022 |
| Time: |  | 5:00 p.m. ET |
| Live Call and Replay: |  | https://investor.fabrinet.com/events-and-presentations/events |

[0001408710-22-000058:8k_2_02:24]
A recorded version of this webcast will be available approximately two hours after the call and accessible at http://investor.fabrinet.com. The webcast will be archived on Fabrinet’s website for a period of one year.

[0001408710-22-000058:8k_2_02:25]
About Fabrinet

[0001408710-22-000058:8k_2_02:26]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China, Israel and the

[0001408710-22-000058:8k_2_02:27]
United Kingdom. For more information visit: www.fabrinet.com.

[0001408710-22-000058:8k_2_02:28]
Forward-Looking Statements

[0001408710-22-000058:8k_2_02:29]
Use of Non-GAAP Financials

[0001408710-22-000058:8k_2_02:30]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; depreciation of fair value uplift; amortization of intangibles; severance payment and others; other expenses in relation to reduction in workforce; and amortization of deferred debt issuance costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001408710-22-000058:8k_2_02:31]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001408710-22-000058:8k_2_02:32]
Investor Contact:

[0001408710-22-000058:8k_2_02:33]
Garo Toomajanian

[0001408710-22-000058:8k_2_02:34]
ir@fabrinet.com

[0001408710-22-000058:8k_2_02:35]
FABRINET

[0001408710-22-000058:8k_2_02:36]
CONDENSED CONSOLIDATED BALANCE SHEETS (unaudited)

[0001408710-22-000058:8k_2_02:37]
| (in thousands of U.S. dollars, except share data and par value) | September 30,2022 |  | June 24,2022 |
| Assets |  |  |  |
| Current assets |  |  |  |
| Cash and cash equivalents | $ | 255,260 |  |  | $ | 197,996 |  |
| Short-term restricted cash | — |  |  | 220 |  |
| Short-term investments | 244,536 |  |  | 280,157 |  |
| Trade accounts receivable, net of allowance for doubtful accounts of $1,177 and $1,271, respectively | 462,352 |  |  | 439,330 |  |
| Contract assets | 14,220 |  |  | 13,464 |  |
| Inventories | 528,050 |  |  | 557,145 |  |
| Prepaid expenses | 15,466 |  |  | 11,626 |  |
| Other current assets | 32,029 |  |  | 25,233 |  |
| Total current assets | 1,551,913 |  |  | 1,525,171 |  |
| Non-current assets |  |  |  |
| Long-term restricted cash | 141 |  |  | 149 |  |
| Property, plant and equipment, net | 294,877 |  |  | 292,277 |  |
| Intangibles, net | 3,348 |  |  | 3,508 |  |
| Operating right-of-use assets | 3,247 |  |  | 4,084 |  |
| Deferred tax assets | 10,200 |  |  | 9,800 |  |
| Other non-current assets | 663 |  |  | 652 |  |
| Total non-current assets | 312,476 |  |  | 310,470 |  |
| Total Assets | $ | 1,864,389 |  |  | $ | 1,835,641 |  |
| Liabilities and Shareholders’ Equity |  |  |  |
| Current liabilities |  |  |  |
| Long-term borrowings, current portion, net | $ | 12,156 |  |  | $ | 12,156 |  |
| Trade accounts payable | 409,414 |  |  | 439,684 |  |
| Fixed assets payable | 12,541 |  |  | 9,085 |  |
| Contract liabilities | 6,348 |  |  | 1,982 |  |
| Finance lease liability, current portion | 9 |  |  | 10 |  |
| Operating lease liabilities, current portion | 2,305 |  |  | 2,319 |  |
| Income tax payable | 2,771 |  |  | 2,898 |  |
| Accrued payroll, bonus and related expenses | 22,103 |  |  | 20,374 |  |
| Accrued expenses | 32,556 |  |  | 24,758 |  |
| Other payables | 26,152 |  |  | 25,221 |  |
| Total current liabilities | 526,355 |  |  | 538,487 |  |
| Non-current liabilities |  |  |  |
| Long-term borrowings, non-current portion, net | 9,117 |  |  | 15,202 |  |
| Deferred tax liability | 6,609 |  |  | 6,001 |  |
| Finance lease liability, non-current portion | 65 |  |  | 75 |  |
| Operating lease liability, non-current portion | 647 |  |  | 1,476 |  |
| Severance liabilities | 17,892 |  |  | 18,384 |  |
| Other non-current liabilities | 1,338 |  |  | 2,334 |  |
| Total non-current liabilities | 35,668 |  |  | 43,472 |  |
| Total Liabilities | 562,023 |  |  | 581,959 |  |
| Shareholders’ equity |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of September 30, 2022 and June 24, 2022) | — |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 39,245,547 shares and 39,048,700 shares issued at September 30, 2022 and June 24, 2022, respectively; and 36,586,553 shares and 36,436,683 shares outstanding at September 30, 2022 and June 24, 2022, respectively) | 392 |  |  | 390 |  |
| Additional paid-in capital | 187,899 |  |  | 196,667 |  |
| Less: Treasury shares (2,658,994 shares and 2,612,017 shares as of September 30, 2022 and June 24, 2022, respectively) | (152,158) |  |  | (147,258) |  |
| Accumulated other comprehensive income (loss) | (15,058) |  |  | (12,793) |  |
| Retained earnings | 1,281,291 |  |  | 1,216,676 |  |
| Total Shareholders’ Equity | 1,302,366 |  |  | 1,253,682 |  |
| Total Liabilities and Shareholders’ Equity | $ | 1,864,389 |  |  | $ | 1,835,641 |  |

[0001408710-22-000058:8k_2_02:38]
FABRINET

[0001408710-22-000058:8k_2_02:39]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME (unaudited)

[0001408710-22-000058:8k_2_02:40]
|  | Three Months Ended |
| (in thousands of U.S. dollars, except per share data) | September 30,2022 |  | September 24,2021 |
| Revenues | $ | 655,429 |  |  | $ | 543,322 |  |
| Cost of revenues | (572,673) |  |  | (479,725) |  |
| Gross profit | 82,756 |  |  | 63,597 |  |
| Selling, general and administrative expenses | (20,565) |  |  | (20,587) |  |
| Operating income | 62,191 |  |  | 43,010 |  |
| Interest income | 1,559 |  |  | 761 |  |
| Interest expense | (391) |  |  | (36) |  |
| Foreign exchange gain (loss), net | 2,085 |  |  | 1,772 |  |
| Other income (expense), net | (141) |  |  | (260) |  |
| Income before income taxes | 65,303 |  |  | 45,247 |  |
| Income tax expense | (688) |  |  | (596) |  |
| Net income | 64,615 |  |  | 44,651 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities | (1,461) |  |  | (213) |  |
| Change in net unrealized gain (loss) on derivative instruments | (1,218) |  |  | (1,217) |  |
| Change in net retirement benefits plan – prior service cost | 168 |  |  | 198 |  |
| Change in foreign currency translation adjustment | 246 |  |  | (164) |  |
| Total other comprehensive income (loss), net of tax | (2,265) |  |  | (1,396) |  |
| Net comprehensive income | $ | 62,350 |  |  | $ | 43,255 |  |
| Earnings per share |  |  |  |
| Basic | $ | 1.77 |  |  | $ | 1.21 |  |
| Diluted | $ | 1.76 |  |  | $ | 1.20 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |
| Basic | 36,528 |  |  | 36,877 |  |
| Diluted | 36,758 |  |  | 37,328 |  |

[0001408710-22-000058:8k_2_02:41]
FABRINET

[0001408710-22-000058:8k_2_02:42]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited)

[0001408710-22-000058:8k_2_02:43]
|  | Three Months Ended |
| (in thousands of U.S. dollars) | September 30,2022 |  | September 24,2021 |
| Cash flows from operating activities |  |  |  |
| Net income for the period | $ | 64,615 |  |  | $ | 44,651 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 11,055 |  |  | 9,535 |  |
| (Gain) loss on disposal and impairment of property, plant and equipment | (9) |  |  | (98) |  |
| (Gain) loss from sales and maturities of available-for-sale securities | 92 |  |  | (13) |  |
| Amortization of discount (premium) of short-term investment | 442 |  |  | 1,109 |  |
| Amortization of deferred debt issuance costs | 8 |  |  | 8 |  |
| (Reversal of) allowance for doubtful accounts | (91) |  |  | (1) |  |
| Unrealized loss (gain) on exchange rate and fair value of foreign currency forward contracts | (386) |  |  | (1,436) |  |
| Amortization of fair value at hedge inception of interest rate swaps | (191) |  |  | (268) |  |
| Share-based compensation | 7,723 |  |  | 9,292 |  |
| Deferred income tax | (219) |  |  | (104) |  |
| Other non-cash expenses | (447) |  |  | 257 |  |
| Changes in operating assets and liabilities |  |  |  |
| Trade accounts receivable | (23,625) |  |  | (10,160) |  |
| Contract assets | (756) |  |  | (1,242) |  |
| Inventories | 28,808 |  |  | (43,135) |  |
| Other current assets and non-current assets | (10,756) |  |  | (1,054) |  |
| Trade accounts payable | (29,774) |  |  | 27,541 |  |
| Contract liabilities | 4,366 |  |  | 75 |  |
| Income tax payable | (276) |  |  | (747) |  |
| Severance liabilities | 617 |  |  | 893 |  |
| Other current liabilities and non-current liabilities | 9,438 |  |  | 1,808 |  |
| Net cash provided by operating activities | 60,634 |  |  | 36,911 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of short-term investments | (25,609) |  |  | (78,101) |  |
| Proceeds from sales of short-term investments | 30,000 |  |  | 19,463 |  |
| Proceeds from maturities of short-term investments | 29,236 |  |  | 43,791 |  |
| Purchase of property, plant and equipment | (10,258) |  |  | (32,522) |  |
| Purchase of intangibles | (11) |  |  | (311) |  |
| Proceeds from disposal of property, plant and equipment | 9 |  |  | 145 |  |
| Net cash used in investing activities | 23,367 |  |  | (47,535) |  |
| Cash flows from financing activities |  |  |  |
| Repayment of long-term borrowings | (6,094) |  |  | (3,047) |  |
| Repayment of finance lease liability | (2) |  |  | — |  |
| Repurchase of ordinary shares | (4,900) |  |  | — |  |
| Withholding tax related to net share settlement of restricted share units | (16,489) |  |  | (19,065) |  |
| Net cash used in financing activities | (27,485) |  |  | (22,112) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | 56,516 |  |  | $ | (32,736) |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at the beginning of period | $ | 198,365 |  |  | $ | 303,123 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | 56,516 |  |  | (32,736) |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash | 520 |  |  | (321) |  |
| Cash, cash equivalents and restricted cash at the end of period | $ | 255,401 |  |  | $ | 270,066 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment-related payables | $ | 12,541 |  |  | $ | 24,174 |  |

[0001408710-22-000058:8k_2_02:44]
FABRINET

[0001408710-22-000058:8k_2_02:45]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited) (Continued)

[0001408710-22-000058:8k_2_02:46]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the condensed consolidated balance sheets that sum to the total of the same amounts shown in the condensed consolidated statements of cash flows:

[0001408710-22-000058:8k_2_02:47]
|  | As of |
| (in thousands) | September 30,2022 |  | September 24,2021 |
| Cash and cash equivalents | $ | 255,260 |  |  | $ | 269,911 |  |
| Restricted cash | 141 |  |  | 155 |  |
| Cash, cash equivalents and restricted cash | $ | 255,401 |  |  | $ | 270,066 |  |

[0001408710-22-000058:8k_2_02:48]
FABRINET

[0001408710-22-000058:8k_2_02:49]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-22-000058:8k_2_02:50]
|  | Three Months Ended |
|  | September 30,2022 |  | September 24,2021 |
| (in thousands of U.S. dollars, except share data) | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |
| GAAP measures | $ | 64,615 |  |  | $ | 1.76 |  |  | $ | 44,651 |  |  | $ | 1.20 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |
| Share-based compensation expenses | 1,915 |  |  | 0.05 |  |  | 1,975 |  |  | 0.05 |  |
| Depreciation of fair value uplift | — |  |  | — |  |  | 92 |  |  | 0.00 |
| Total related to gross profit | 1,915 |  |  | 0.05 |  |  | 2,067 |  |  | 0.05 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |
| Share-based compensation expenses | 5,808 |  |  | 0.16 |  |  | 7,317 |  |  | 0.20 |  |
| Amortization of intangibles | 83 |  |  | 0.00 |  |  | 119 |  |  | 0.00 |  |
| Total related to selling, general and administrative expenses | 5,891 |  |  | 0.16 |  |  | 7,436 |  |  | 0.20 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |
| Amortization of deferred debt issuance costs | 8 |  |  | 0.00 |  | 8 |  |  | 0.00 |
| Total related to other incomes and other expenses | 8 |  |  | 0.00 |  | 8 |  |  | 0.00 |
| Total related to net income & EPS | 7,814 |  |  | 0.21 |  |  | 9,511 |  |  | 0.25 |  |
| Non-GAAP measures | $ | 72,429 |  |  | $ | 1.97 |  |  | $ | 54,162 |  |  | $ | 1.45 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  | 36,758 |  |  |  |  | 37,328 |  |
| Non-GAAP diluted shares |  |  | 36,758 |  |  |  |  | 37,328 |  |

[0001408710-22-000058:8k_2_02:51]
FABRINET

[0001408710-22-000058:8k_2_02:52]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001408710-22-000058:8k_2_02:53]
| (in thousands) |  | Three Months Ended |
|  |  | September 30,2022 |  | September 24,2021 |
| Net cash provided by operating activities |  | $ | 60,634 |  |  | $ | 36,911 |  |
| Less: Purchase of property, plant and equipment |  | (10,258) |  |  | (32,522) |  |
| Non-GAAP free cash flow |  | $ | 50,376 |  |  | $ | 4,389 |  |

[0001408710-22-000058:8k_2_02:54]
FABRINET

[0001408710-22-000058:8k_2_02:55]
GUIDANCE FOR QUARTER ENDING DECEMBER 30, 2022

[0001408710-22-000058:8k_2_02:56]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-22-000058:8k_2_02:57]
|  | DilutedEPS |
| GAAP net income per diluted share: | $1.67 to $1.74 |
| Related to cost of revenues: |  |
| Share-based compensation expenses | 0.05 |
| Total related to gross profit | 0.05 |
| Related to selling, general and administrative expenses: |  |
| Share-based compensation expenses | 0.14 |
| Total related to selling, general and administrative expenses | 0.14 |
| Total related to net income & EPS | 0.19 |
| Non-GAAP net income per diluted share | $1.86 to $1.93 |
