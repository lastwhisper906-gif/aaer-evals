# FN MD&A — 0001408710-22-000060


## mdna

[0001408710-22-000060:mdna:1]
[same as prior period, unchanged from 0001408710-22-000028:mdna:1]

[0001408710-22-000060:mdna:2]
[same as prior period, unchanged from 0001408710-22-000028:mdna:2]

[0001408710-22-000060:mdna:3]
[same as prior period, unchanged from 0001408710-22-000028:mdna:3]

[0001408710-22-000060:mdna:4]
[same as prior period, unchanged from 0001408710-22-000028:mdna:4]

[0001408710-22-000060:mdna:5]
•our expectation that the portion of our revenues attributable to customers in regions outside of North America for the remainder of fiscal year 2023 will be in line with the portion of revenues attributable to such customers during the three months ended September 30, 2022;

[0001408710-22-000060:mdna:6]
[same as prior period, unchanged from 0001408710-22-000028:mdna:6]

[0001408710-22-000060:mdna:7]
•our expectation that our fiscal year 2023 selling, general and administrative (“SG&A”) expenses will increase compared to our fiscal year 2022 SG&A expenses;

[0001408710-22-000060:mdna:8]
[same as prior period, unchanged from 0001408710-22-000028:mdna:8]

[0001408710-22-000060:mdna:9]
[same as prior period, unchanged from 0001408710-22-000028:mdna:9]

[0001408710-22-000060:mdna:10]
[same as prior period, unchanged from 0001408710-22-000028:mdna:10]

[0001408710-22-000060:mdna:11]
[same as prior period, unchanged from 0001408710-22-000028:mdna:11]

[0001408710-22-000060:mdna:12]
[same as prior period, unchanged from 0001408710-22-000028:mdna:12]

[0001408710-22-000060:mdna:13]
[same as prior period, unchanged from 0001408710-22-000028:mdna:13]

[0001408710-22-000060:mdna:14]
[same as prior period, unchanged from 0001408710-22-000028:mdna:14]

[0001408710-22-000060:mdna:15]
[same as prior period, unchanged from 0001408710-22-000028:mdna:15]

[0001408710-22-000060:mdna:16]
[same as prior period, unchanged from 0001408710-22-000028:mdna:16]

[0001408710-22-000060:mdna:17]
[same as prior period, unchanged from 0001408710-22-000028:mdna:17]

[0001408710-22-000060:mdna:18]
[same as prior period, unchanged from 0001408710-22-000028:mdna:18]

[0001408710-22-000060:mdna:19]
[same as prior period, unchanged from 0001408710-22-000028:mdna:19]

[0001408710-22-000060:mdna:20]
[same as prior period, unchanged from 0001408710-22-000028:mdna:20]

[0001408710-22-000060:mdna:21]
[same as prior period, unchanged from 0001408710-22-000028:mdna:21]

[0001408710-22-000060:mdna:22]
[same as prior period, unchanged from 0001408710-22-000028:mdna:22]

[0001408710-22-000060:mdna:23]
[same as prior period, unchanged from 0001408710-22-000028:mdna:23]

[0001408710-22-000060:mdna:24]
[same as prior period, unchanged from 0001408710-22-000028:mdna:24]

[0001408710-22-000060:mdna:25]
[same as prior period, unchanged from 0001408710-22-000028:mdna:25]

[0001408710-22-000060:mdna:26]
In October 2022, our subsidiary in Thailand relaxed certain precautionary measures in accordance with the termination of Thailand’s emergency decree related to COVID-19, which lowered the status of COVID-19 to a communicable disease under surveillance. Although we did not experience any significant disruptions in our operations or decrease in customer demand during the three months ended September 30, 2022, any worsening of the pandemic may result in more stringent measures being implemented by local authorities, such as shutting down our manufacturing facilities, which would have a significant negative impact on our operations.

[0001408710-22-000060:mdna:27]
Due to the unprecedented and unpredictable human and economic impact of the COVID-19 pandemic globally, including inflationary pressures and supply chain constraints that have emerged as the world exits the acute phase of the pandemic, and the evolving and differing national strategies for dealing with COVID-19, it is challenging to provide a forward-looking assessment. Despite uncertainty and concern about the global economy and the health of various industries, we can share some relevant perspectives as we continue to assess the impacts of COVID-19 on our business in the future:

[0001408710-22-000060:mdna:28]
•A significant portion of our costs is variable, which allows us to adjust manufacturing costs relatively quickly to respond to the changing demand of our customers. However, because parts and materials account for the largest portion of our costs, inflationary pressures and supply chain issues will continue to negatively affect our gross margins for the foreseeable future.

[0001408710-22-000060:mdna:29]
•The ongoing safety and health of our employees is and will remain a key priority. To this end, we will continue to monitor local restrictions at our facilities across the world, the administration and efficacy of vaccines and the number of new COVID-19 cases to determine whether and when additional safeguards may become necessary.

[0001408710-22-000060:mdna:30]
•Given our $499.8 million in cash, cash equivalents and short-term investments, and our total debt of approximately $21.3 million as of September 30, 2022, we believe we are in a solid position from a capital and financial resources perspective. We expect that current cash and cash equivalent balances and short-term investments, and cash flows generated from operations will be sufficient to meet our domestic and international working capital needs and other capital and liquidity requirements for at least the next 12 months.

[0001408710-22-000060:mdna:31]
[same as prior period, unchanged from 0001408710-22-000028:mdna:36]

[0001408710-22-000060:mdna:32]
We believe we are able to expand our relationships with existing customers and attract new customers due to, among other factors, our broad range of complex engineering and manufacturing service offerings, flexible low-cost manufacturing platform, process optimization capabilities, advanced supply chain management, excellent customer service, and experienced management team. Although we expect the prices we charge for our manufactured products to decrease over time (partly as a

[0001408710-22-000060:mdna:33]
result of competitive market forces), we believe we will be able to continue to maintain favorable pricing for our services because of our ability to reduce cycle time, adjust our product mix by focusing on more complicated products, improve product quality and yields, and reduce material costs for the products we manufacture. We believe these capabilities have enabled us to help our OEM customers reduce their manufacturing costs while maintaining or improving the design, quality, reliability, and delivery times for their products.

[0001408710-22-000060:mdna:34]
We expect that disruptions in our supply chain and fluctuations in the availability of parts and materials will continue to have a significant impact on our ability to generate revenue, despite strong demand from our customers. These supply chain disruptions have been exacerbated by recent global events, such as (1) COVID-related lockdowns in China, which have caused freight and logistics issues and unforeseen delays, and (2) the armed conflict between Russia and Ukraine. While we have no significant direct business in Ukraine or Russia, the conflict has negatively impacted demand from some of our automotive customers that have other suppliers in the region. Moreover, if the facilities of our subsidiary in Fuzhou, China were to be locked down due to COVID-19, we would be negatively impacted since we and some of our customers rely on the optics components that are manufactured in such facilities. Furthermore, in some cases, our efforts to identify and secure alternative supply chain sources has resulted in our customers or their end customers requiring requalification and validation of components, a process that can often be lengthy and has negatively impacted the timing of our revenue. We expect these supply constraints to continue, and potentially worsen, for at least the next 12 months.

[0001408710-22-000060:mdna:35]
[same as prior period, unchanged from 0001408710-22-000028:mdna:39]

[0001408710-22-000060:mdna:36]
We generate revenues from three geographic regions: North America, Asia-Pacific and others, and Europe. Revenues are attributed to a particular geographic area based on the bill-to-location of our customers, notwithstanding that our customers may ultimately ship their products to end customers in a different geographic region. The substantial majority of our revenues are derived from our manufacturing facilities in Asia-Pacific.

[0001408710-22-000060:mdna:37]
The percentage of our revenues generated from a bill-to location outside of North America decreased from 54.6% in the three months ended September 24, 2021 to 46.8% in the three months ended September 30, 2022, primarily because the increase in sales to our customers outside of North America was lower than the increase in sales to our customers in North America.

[0001408710-22-000060:mdna:38]
Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside North America for the remainder of fiscal year 2023 will be in line with the portion of revenues attributable to such customers during the three months ended September 30, 2022.

[0001408710-22-000060:mdna:39]
[same as prior period, unchanged from 0001408710-22-000028:mdna:44]

[0001408710-22-000060:mdna:40]
|  | Three Months Ended |
|  | September 30, 2022 |  | September 24, 2021 |
| North America | 53.2 | % |  | 45.4 | % |
| Asia-Pacific and others | 37.9 |  |  | 37.9 |  |
| Europe | 8.9 |  |  | 16.7 |  |
|  | 100.0 | % |  | 100.0 | % |

[0001408710-22-000060:mdna:41]
[same as prior period, unchanged from 0001408710-22-000028:mdna:46]

[0001408710-22-000060:mdna:42]
We enter into supply agreements with our customers which generally have an initial term of up to three years, subject to automatic renewals for subsequent one-year terms unless expressly terminated. Although there are no minimum purchase requirements in our supply agreements, our customers provide us with rolling forecasts of their demand requirements. Our supply agreements generally include provisions for pricing and periodic review of pricing, consignment of our customer’s unique production equipment to us, and the sharing of benefits from cost-savings derived from our efforts. We are generally required to purchase materials, which may include long lead-time materials and materials that are subject to minimum order quantities and/or non-cancelable or non-returnable terms, to meet the stated demands of our customers. After procuring materials, we manufacture products for our customers based on purchase orders that contain terms regarding product quantities, delivery locations and delivery dates. Our customers generally are obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by our customers within a specified period of time, or that are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under our contracts. Once materials are designated as either excess or obsolete inventory, our customers are

[0001408710-22-000060:mdna:43]
typically required to purchase such inventory from us even if they have chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

[0001408710-22-000060:mdna:44]
[same as prior period, unchanged from 0001408710-22-000028:mdna:48]

[0001408710-22-000060:mdna:45]
[same as prior period, unchanged from 0001408710-22-000028:mdna:49]

[0001408710-22-000060:mdna:46]
A second significant element of our cost of revenues is employee costs, including indirect employee costs related to design, configuration and optimization of manufacturing processes for our customers, quality testing, materials testing and other engineering services; and direct costs related to our manufacturing employees. Direct employee costs include employee salaries, insurance and benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a lesser extent, costs to recruit, train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand, the PRC and the United Kingdom, the fluctuation of the Thai baht, Chinese Renminbi ("RMB") and Pound Sterling ("GBP") against our functional currency, the U.S. dollar, and our ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention and asset utilization.

[0001408710-22-000060:mdna:47]
[same as prior period, unchanged from 0001408710-22-000028:mdna:52]

[0001408710-22-000060:mdna:48]
[same as prior period, unchanged from 0001408710-22-000028:mdna:53]

[0001408710-22-000060:mdna:49]
[same as prior period, unchanged from 0001408710-22-000028:mdna:54]

[0001408710-22-000060:mdna:50]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative and other support personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other general expenses not related to cost of revenues. In fiscal year 2023, we expect our SG&A expenses will increase compared with our fiscal year 2022 SG&A expenses, mainly due to increased employee costs.

[0001408710-22-000060:mdna:51]
The compensation committee of our board of directors approved a fiscal year 2023 executive incentive plan with quantitative objectives based solely on achieving certain revenue targets and non-GAAP operating margin targets for fiscal year 2023. Bonuses under the fiscal year 2023 executive incentive plan are payable after the end of fiscal year 2023. In fiscal year 2022, the compensation committee approved a fiscal year 2022 executive incentive plan with quantitative objectives that were based solely on achieving certain revenue targets and non-GAAP operating margin targets for fiscal year 2022.

[0001408710-22-000060:mdna:52]
[same as prior period, unchanged from 0001408710-22-000028:mdna:57]

[0001408710-22-000060:mdna:53]
[same as prior period, unchanged from 0001408710-22-000028:mdna:58]

[0001408710-22-000060:mdna:54]
As a result of our international operations, we are exposed to foreign exchange risk arising from various currency exposures, and primarily with respect to the Thai baht. Although a majority of our total revenues is denominated in U.S. dollars, a substantial portion of our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rate between the Thai baht and the U.S. dollar has fluctuated substantially in recent years and may continue to fluctuate substantially in the future. We report our financial results in U.S. dollars and our results of operations have been and could in the future be negatively impacted if the Thai baht appreciates against the U.S. dollar. Smaller portions of our expenses are incurred in a variety of other currencies, including RMB, GBP, Canadian dollars, Euros, and Japanese yen, the appreciation of which may also negatively impact our financial results.

[0001408710-22-000060:mdna:55]
In order to manage the risks arising from fluctuations in foreign currency exchange rates, we use derivative instruments. We may enter into foreign currency exchange forward or put option contracts to manage foreign currency exposures associated with certain assets and liabilities and other forecasted foreign currency transactions and may designate these instruments as hedging instruments. The forward and put option contracts generally have maturities of up to 12 months. All foreign currency exchange contracts are recognized in the unaudited condensed consolidated balance sheets at fair value. Gains or losses on our forward and put option contracts generally present gross amount in the assets, liabilities, and transactions economically hedged.

[0001408710-22-000060:mdna:56]
[same as prior period, unchanged from 0001408710-22-000028:mdna:61]

[0001408710-22-000060:mdna:57]
|  | As of September 30, 2022 |  | As of June 24, 2022 |
| (amount in thousands, except percentages) | Currency |  | $ |  | % |  | Currency |  | $ |  | % |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 872,783 |  |  | $ | 23,022 |  |  | 70.4 | % |  | 753,924 |  |  | $ | 21,213 |  |  | 64.0 | % |
| RMB | 28,308 |  |  | 3,987 |  |  | 12.2 |  |  | 34,382 |  |  | 5,132 |  |  | 15.5 |  |
| GBP | 5,099 |  |  | 5,678 |  |  | 17.4 |  |  | 5,544 |  |  | 6,801 |  |  | 20.5 |  |
| Total |  |  | $ | 32,687 |  |  | 100.0 | % |  |  |  | $ | 33,146 |  |  | 100.0 | % |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 2,847,513 |  |  | $ | 75,112 |  |  | 88.2 | % |  | 2,393,112 |  |  | $ | 67,336 |  |  | 84.8 | % |
| RMB | 55,478 |  |  | 7,814 |  |  | 9.2 |  |  | 61,191 |  |  | 9,133 |  |  | 11.5 |  |
| GBP | 1,999 |  |  | 2,225 |  |  | 2.6 |  |  | 2,379 |  |  | 2,918 |  |  | 3.7 |  |
| Total |  |  | $ | 85,151 |  |  | 100.0 | % |  |  |  | $ | 79,387 |  |  | 100.0 | % |

[0001408710-22-000060:mdna:58]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of September 30, 2022, there was $146.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 24, 2022, there was $135.0 million of foreign currency forward contracts outstanding on the Thai baht payables.

[0001408710-22-000060:mdna:59]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of September 30, 2022 and June 24, 2022, we did not have any derivative contracts denominated in RMB.

[0001408710-22-000060:mdna:60]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable and other payables. As of September 30, 2022 and June 24, 2022, we did not have any derivative contracts denominated in GBP.

[0001408710-22-000060:mdna:61]
For the three months ended September 30, 2022 and September 24, 2021, we recorded a loss of $0.2 million and $0.6 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-22-000060:mdna:62]
[same as prior period, unchanged from 0001408710-22-000028:mdna:68]

[0001408710-22-000060:mdna:63]
[same as prior period, unchanged from 0001408710-22-000028:mdna:69]

[0001408710-22-000060:mdna:64]
•Foreign Currency Administration Rules, as amended on August 5, 2008, or the Exchange Rules;

[0001408710-22-000060:mdna:65]
•Administration Rules of the Settlement, Sale and Payment of Foreign Exchange (1996), or the Administration Rules; and

[0001408710-22-000060:mdna:66]
•Notice on Perfecting Practices Concerning Foreign Exchange Settlement Regarding the Capital Contribution by Foreign-invested Enterprises, as promulgated by the State Administration of Foreign Exchange (“SAFE”), on August 29, 2008, or Circular 142.

[0001408710-22-000060:mdna:67]
[same as prior period, unchanged from 0001408710-22-000028:mdna:73]

[0001408710-22-000060:mdna:68]
Under the Administration Rules, foreign-invested enterprises may only buy, sell, or remit foreign currencies at banks authorized to conduct foreign exchange business after providing valid commercial documents and relevant supporting

[0001408710-22-000060:mdna:69]
documents and, in the case of capital account item transactions, obtaining approval from SAFE. Capital investments by foreign-invested enterprises outside of the PRC are also subject to limitations, which include approvals by the Ministry of Commerce, SAFE and the State Development and Reform Commission.

[0001408710-22-000060:mdna:70]
[same as prior period, unchanged from 0001408710-22-000028:mdna:76]

[0001408710-22-000060:mdna:71]
On January 5, 2007, SAFE promulgated the Detailed Rules for Implementing the Measures for the Administration on Individual Foreign Exchange, or the Implementation Rules. Under the Implementation Rules, PRC citizens who are granted share options by an overseas publicly-listed company are required, through a PRC agent or PRC subsidiary of such overseas publicly-listed company, to register with SAFE and complete certain other procedures.

[0001408710-22-000060:mdna:72]
[same as prior period, unchanged from 0001408710-22-000028:mdna:78]

[0001408710-22-000060:mdna:73]
[same as prior period, unchanged from 0001408710-22-000028:mdna:79]

[0001408710-22-000060:mdna:74]
[same as prior period, unchanged from 0001408710-22-000028:mdna:80]

[0001408710-22-000060:mdna:75]
Our effective tax rate is a function of the mix of tax rates in the various jurisdictions in which we do business. We are domiciled in the Cayman Islands. Under the current laws of the Cayman Islands, we are not subject to tax in the Cayman Islands on income or capital gains until March 6, 2039.

[0001408710-22-000060:mdna:76]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption on income generated from projects to manufacture certain products at our Chonburi campus is currently available to us through June 2026. Similar preferential tax treatment was available to us through June 2020 with respect to products manufactured at our Pinehurst campus Building 6. After June 2020, 50% of our income generated from products manufactured at our Pinehurst campus will be exempted from tax through June 2025. New preferential tax treatment is available to us for products manufactured at our Chonburi campus Building 9, where income generated will be tax exempt through 2030, capped at our actual investment amount. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted. Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001408710-22-000060:mdna:77]
The corporate income tax rates for our subsidiaries in the PRC, the U.S., the U.K. and Israel are 25%, 21%, 19% and 23%, respectively. In October 2022, the U.K. announced an increase in the corporate income tax rate from 19% to 25% effective on April 1, 2023.

[0001408710-22-000060:mdna:78]
[same as prior period, unchanged from 0001408710-22-000028:mdna:84]

[0001408710-22-000060:mdna:79]
We prepare our unaudited condensed consolidated financial statements in conformity with U.S. GAAP, which requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent liabilities on the date of the unaudited condensed consolidated financial statements and the reported amounts of revenues and expenses during the financial reporting period. We continually evaluate these estimates and assumptions based on the most recently available information, our own historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Because the use of estimates is an integral component of the financial reporting process, actual results could differ from those estimates. Some of our accounting policies require higher degrees of judgment than others in their application. We consider the policies discussed below to be critical to an understanding of our unaudited

[0001408710-22-000060:mdna:80]
condensed consolidated financial statements, as their application places the most significant demands on our management’s judgment.

[0001408710-22-000060:mdna:81]
Our critical accounting policies are disclosed in our Annual Report on Form10-K for the fiscal year ended June 24, 2022. The adoption of new accounting policies and accounting standards are disclosed in Note 2 to the unaudited condensed consolidated financial statements. There were no changes to our accounting policies.

[0001408710-22-000060:mdna:82]
[same as prior period, unchanged from 0001408710-22-000028:mdna:87]

[0001408710-22-000060:mdna:83]
[same as prior period, unchanged from 0001408710-22-000028:mdna:88]

[0001408710-22-000060:mdna:84]
| (in thousands) | Three Months Ended |
| September 30,2022 |  | September 24,2021 |
| Revenues | $ | 655,429 |  |  | $ | 543,322 |  |
| Cost of revenues | (572,673) |  |  | (479,725) |  |
| Gross profit | 82,756 |  |  | 63,597 |  |
| Selling, general and administrative expenses | (20,565) |  |  | (20,587) |  |
| Operating income | 62,191 |  |  | 43,010 |  |
| Interest income | 1,559 |  |  | 761 |  |
| Interest expense | (391) |  |  | (36) |  |
| Foreign exchange gain (loss), net | 2,085 |  |  | 1,772 |  |
| Other income (expense), net | (141) |  |  | (260) |  |
| Income before income taxes | 65,303 |  |  | 45,247 |  |
| Income tax expense | (688) |  |  | (596) |  |
| Net income | 64,615 |  |  | 44,651 |  |
| Other comprehensive income (loss), net of tax | (2,265) |  |  | (1,396) |  |
| Net comprehensive income | $ | 62,350 |  |  | $ | 43,255 |  |

[0001408710-22-000060:mdna:85]
[same as prior period, unchanged from 0001408710-22-000028:mdna:90]

[0001408710-22-000060:mdna:86]
|  | Three Months Ended |
|  | September 30,2022 |  | September 24,2021 |
| Revenues | 100.0 | % |  | 100.0 | % |
| Cost of revenues | (87.4) |  |  | (88.3) |  |
| Gross profit | 12.6 |  |  | 11.7 |  |
| Selling, general and administrative expenses | (3.1) |  |  | (3.8) |  |
| Operating income | 9.5 |  |  | 7.9 |  |
| Interest income | 0.3 |  |  | 0.1 |  |
| Interest expense | (0.1) |  |  | 0.0 |  |
| Foreign exchange gain (loss), net | 0.3 |  |  | 0.3 |  |
| Other income (expense), net | 0.0 |  |  | 0.0 |  |
| Income before income taxes | 10.0 |  |  | 8.3 |  |
| Income tax expense | (0.1) |  |  | (0.1) |  |
| Net income | 9.9 |  |  | 8.2 |  |
| Other comprehensive income (loss), net of tax | (0.4) |  |  | (0.2) |  |
| Net comprehensive income | 9.5 | % |  | 8.0 | % |

[0001408710-22-000060:mdna:87]
34

[0001408710-22-000060:mdna:88]
[same as prior period, unchanged from 0001408710-22-000028:mdna:93]

[0001408710-22-000060:mdna:89]
|  | Three Months Ended |
| (in thousands of U.S. dollars) | September 30,2022 |  | September 24,2021 |
| Optical communications | $ | 497,561 |  |  | $ | 427,301 |  |
| Lasers, sensors and other | 157,868 |  |  | 116,021 |  |
| Total | $ | 655,429 |  |  | $ | 543,322 |  |

[0001408710-22-000060:mdna:90]
[same as prior period, unchanged from 0001408710-22-000028:mdna:95]

[0001408710-22-000060:mdna:91]
Comparison of Three Months Ended September 30, 2022 with Three Months Ended September 24, 2021

[0001408710-22-000060:mdna:92]
Revenues. Our revenues increased by $112.1 million, or 20.6%, to $655.4 million for the three months ended September 30, 2022, compared with $543.3 million for the three months ended September 24, 2021. This increase was due to (1) an increase in our key customers’ demand for optical communications manufacturing services during the three months ended September 30, 2022 and (2) the positive impact of an additional week of revenue during the three months ended September 30, 2022. Revenues from optical communications products increased by $70.3 million, or 16.4%, for the three months ended September 30, 2022, compared to the same period in the prior fiscal year.

[0001408710-22-000060:mdna:93]
Cost of revenues. Our cost of revenues increased by $93.0 million, or 19.4%, to $572.7 million, or 87.4% of revenues, for the three months ended September 30, 2022, compared with $479.7 million, or 88.3% of revenues, for the three months ended September 24, 2021. This increase in cost of revenues on an absolute dollar basis was in line with the increase in sales volume.

[0001408710-22-000060:mdna:94]
Gross profit. Our gross profit increased by $19.2 million, or 30.2%, to $82.8 million, or 12.6% of revenues, for the three months ended September 30, 2022, compared with $63.6 million, or 11.7% of revenues, for the three months ended September 24, 2021. The increase was primarily due to an increase in sales volume.

[0001408710-22-000060:mdna:95]
SG&A expenses. Our SG&A expenses remained flat at $20.6 million, or 3.1% of revenues, for the three months ended September 30, 2022, compared with $20.6 million, or 3.8% of revenues, for the three months ended September 24, 2021.

[0001408710-22-000060:mdna:96]
Operating income. Our operating income increased by $19.2 million, or 44.7%, to $62.2 million, or 9.5% of revenues, for the three months ended September 30, 2022, compared with $43.0 million, or 7.9% of revenues, for the three months ended September 24, 2021. The increase was primarily due to an increase in revenues.

[0001408710-22-000060:mdna:97]
Interest income. Our interest income increased by $0.8 million, or 104.9%, to $1.6 million, or 0.3% of revenues, for the three months ended September 30, 2022, compared with $0.8 million, or 0.1% of revenues, for the three months ended September 24, 2021. The increase was primarily due to a higher weighted average interest rate during the three months ended September 30, 2022 compared to same period in the prior fiscal year.

[0001408710-22-000060:mdna:98]
Interest expense. Our interest expense increased by $0.4 million to $0.4 million or 0.1% of revenues, for the three months ended September 30, 2022, compared with $36.0 thousand for the three months ended September 24, 2021. The increase was primarily due to (1) lower interest expense capitalized of $0.3 million since we ceased interest capitalization from the completion of a new manufacturing building at our Chonburi campus in July 1, 2022, and (2) lower amortization of the fair value of interest rate swaps of $0.1 million during the three months ended September 30, 2022.

[0001408710-22-000060:mdna:99]
Foreign exchange gain (loss), net. We recorded foreign exchange gain, net of $2.1 million for the three months ended September 30, 2022, compared with foreign exchange gain, net of $1.8 million for the three months ended September 24, 2021. The increase in foreign exchange gain was mainly due to (1) lower unrealized loss from mark-to-market forward contracts of $0.4 million for the three months ended September 30, 2022, (2) higher unrealized gain from revaluation of currencies other than Thai baht of $0.3 million for the three months ended September 30, 2022, and (3) higher realized gain from payment/receipt of $0.3 million for the three months ended September 30, 2022, offset by (1) higher foreign exchange loss, totaling $0.6

[0001408710-22-000060:mdna:100]
million for the three months ended September 30, 2022 from our subsidiaries in the PRC and the U.K., and (2) lower unrealized gain from revaluation of outstanding Thai baht assets and liabilities of $0.1 million for the three months ended September 30, 2022.

[0001408710-22-000060:mdna:101]
Income before income taxes. We recorded income before income taxes of $65.3 million for the three months ended September 30, 2022, compared with $45.2 million for the three months ended September 24, 2021.

[0001408710-22-000060:mdna:102]
Income tax expense. Our provision for income tax reflects effective tax rates of 1.1% and 1.3% for the three months ended September 30, 2022 and September 24, 2021, respectively. The decrease was primarily due to an increase in income not subject to tax during the first quarter of fiscal year 2023 as compared to the same period in fiscal year 2022.

[0001408710-22-000060:mdna:103]
Net income. We recorded net income of $64.6 million, or 9.9% of revenues, for the three months ended September 30, 2022, compared with $44.7 million, or 8.2% of revenues, for the three months ended September 24, 2021.

[0001408710-22-000060:mdna:104]
Other comprehensive income (loss). We recorded other comprehensive loss of $2.3 million, or 0.3% of revenues, for the three months ended September 30, 2022, compared with other comprehensive loss of $1.4 million, or 0.2% of revenues, for the three months ended September 24, 2021. The increase in other comprehensive loss was mainly due to higher unrealized loss from mark-to-market of available-for-sale debt securities of $1.2 million for the three months ended September 30, 2022, offset by unrealized gain from foreign currency translation adjustment of $0.4 million for the three months ended September 30, 2022.

[0001408710-22-000060:mdna:105]
[same as prior period, unchanged from 0001408710-22-000028:mdna:134]

[0001408710-22-000060:mdna:106]
[same as prior period, unchanged from 0001408710-22-000028:mdna:135]

[0001408710-22-000060:mdna:107]
We primarily finance our operations through cash flow from operations. As of September 30, 2022 and September 24, 2021, we had cash, cash equivalents, and short-term investments of $499.8 million and $528.4 million, respectively, and outstanding debt of $21.3 million and $36.6 million, respectively.

[0001408710-22-000060:mdna:108]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents for the three months ended September 30, 2022 and September 24, 2021, was 1.5% and 0.7%, respectively.

[0001408710-22-000060:mdna:109]
[same as prior period, unchanged from 0001408710-22-000028:mdna:138]

[0001408710-22-000060:mdna:110]
During the three months ended September 30, 2022, we repaid $6.1 million of the term loan under our credit facility agreement with the Bank of Ayudhya Public Company Limited. As a result, as of September 30, 2022, we had a long-term borrowing of $21.3 million under such credit facility agreement. (See Note 10 for further details.) We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held short-term investments of $244.5 million as of September 30, 2022.

[0001408710-22-000060:mdna:111]
We believe that our current cash and cash equivalents, short-term investments, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001408710-22-000060:mdna:112]
[same as prior period, unchanged from 0001408710-22-000028:mdna:141]

[0001408710-22-000060:mdna:113]
[same as prior period, unchanged from 0001408710-22-000028:mdna:142]

[0001408710-22-000060:mdna:114]
|  | Three Months Ended |
| (in thousands) | September 30, 2022 |  | September 24, 2021 |
| Net cash provided by operating activities | $ | 60,634 |  |  | $ | 36,911 |  |
| Net cash provided by (used in) investing activities | $ | 23,367 |  |  | $ | (47,535) |  |
| Net cash used in financing activities | $ | (27,485) |  |  | $ | (22,112) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | 56,516 |  |  | $ | (32,736) |  |

[0001408710-22-000060:mdna:115]
[same as prior period, unchanged from 0001408710-22-000028:mdna:144]

[0001408710-22-000060:mdna:116]
Cash provided by operating activities is net income adjusted for certain non-cash items and changes in certain assets and liabilities. The increase in cash provided by operating activities during the three months ended September 30, 2022 as compared to the three months ended September 24, 2021 was primarily driven by higher net income and was also affected by cash-favorable working capital changes.

[0001408710-22-000060:mdna:117]
[same as prior period, unchanged from 0001408710-22-000028:mdna:147]

[0001408710-22-000060:mdna:118]
Investing cash flows consist primarily of investment purchases, sales, maturities, and disposals; and capital expenditures. Cash provided by investing activities was higher for the three months ended September 30, 2022 as compared to cash used in investing activities for the three months ended September 24, 2021 primarily due to fewer investment purchases, an increase in proceeds from the sale of short-term investments, and a decrease in capital expenditures, offset by a decrease in proceeds from maturities of short-term investments.

[0001408710-22-000060:mdna:119]
[same as prior period, unchanged from 0001408710-22-000028:mdna:150]

[0001408710-22-000060:mdna:120]
Financing cash flows consist primarily of repayment of long-term debt, share repurchases, and withholding tax related to net share settlement of restricted share units. Cash used in financing activities was higher for the three months ended September 30, 2022 as compared to the three months ended September 24, 2021 primarily due to an increase in the repayment of long-term borrowings due to an additional installment from the additional week in the first quarter of fiscal year 2023 and an increase in cash paid for share repurchases, offset by a decrease in withholding tax related to net share settlement of restricted share units.

[0001408710-22-000060:mdna:121]
[same as prior period, unchanged from 0001408710-22-000028:mdna:153]

[0001408710-22-000060:mdna:122]
[same as prior period, unchanged from 0001408710-22-000028:mdna:154]
