# FN notes — 0001408710-22-000060


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001408710-22-000060:notes:1]
[same as prior period, unchanged from 0001408710-22-000028:notes:1]

[0001408710-22-000060:notes:2]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of September 30, 2022 and for the three months ended September 30, 2022 and September 24, 2021 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 24, 2022.

[0001408710-22-000060:notes:3]
The balance sheet as of June 24, 2022 has been derived from the audited financial statements at that date but does not include all of the information and footnotes required by U.S. GAAP for complete financial statements.

[0001408710-22-000060:notes:4]
The results for the three months ended September 30, 2022 may not be indicative of results for the year ending June 30, 2023 or any future periods.

[0001408710-22-000060:notes:5]
[same as prior period, unchanged from 0001408710-22-000028:notes:5]

[0001408710-22-000060:notes:6]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information. Additionally, the extent to which the evolving COVID-19 pandemic impacts the Company’s unaudited condensed consolidated financial statements will depend on a number of factors, including the magnitude and duration of the pandemic. These estimates may change, as new events occur and additional information is obtained, or based upon the occurrence of other factors related to the COVID-19 pandemic that could result in material impacts to the Company's unaudited condensed consolidated financial statements in future reporting periods.

[0001408710-22-000060:notes:7]
[same as prior period, unchanged from 0001408710-22-000028:notes:7]

[0001408710-22-000060:notes:8]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  September 30, 2022 and September 24, 2021 consisted of 14 weeks and 13 weeks, respectively. Fiscal year 2023 will comprise 53 weeks and will end on June 30, 2023.

[0001408710-22-000060:notes:9]
Adoption of New Accounting Standards
In November 2021, the Financial Accounting Standard Board issued Accounting Standards Update ("ASU") 2021-10, “Government Assistance (Topic 832), Disclosures by Business Entities about Government Assistance,” which requires annual disclosures that increase the transparency of transactions involving government assistance, including (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The amendments in this update are effective for all entities within the ASU's scope for financial statements issued for annual periods beginning after December 15, 2021. The Company adopted this standard in the first quarter of fiscal year 2023 with no material impact on its unaudited condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001408710-22-000060:notes:10]
[same as prior period, unchanged from 0001408710-22-000028:notes:13]

[0001408710-22-000060:notes:11]
[same as prior period, unchanged from 0001408710-22-000028:notes:14]

[0001408710-22-000060:notes:12]
[same as prior period, unchanged from 0001408710-22-000028:notes:15]

[0001408710-22-000060:notes:13]
| (in thousands, except percentages) | Three Months EndedSeptember 30, 2022 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 24, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 345,080 |  |  |  |  | $ | 245,274 |  |  |  |
| Others (1) | 3,624 |  |  |  |  | 1,316 |  |  |  |
| Total revenue in North America | 348,704 |  |  | 53.2 | % |  | 246,590 |  |  | 45.4 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 80,033 |  |  |  |  | 64,932 |  |  |  |
| Malaysia | 49,324 |  |  |  |  | 51,749 |  |  |  |
| Israel | 37,277 |  |  |  |  | 27,634 |  |  |  |
| Hong Kong | 32,472 |  |  |  |  | 21,031 |  |  |  |
| China | 23,064 |  |  |  |  | 13,635 |  |  |  |
| Thailand | 12,616 |  |  |  |  | 9,759 |  |  |  |
| Japan | 10,348 |  |  |  |  | 14,977 |  |  |  |
| Others | 3,160 |  |  |  |  | 2,466 |  |  |  |
| Total revenue in Asia-Pacific and others | 248,294 |  |  | 37.9 | % |  | 206,183 |  |  | 37.9 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 32,832 |  |  |  |  | 19,578 |  |  |  |
| Germany | 13,314 |  |  |  |  | 8,425 |  |  |  |
| Ireland (2) | 119 |  |  |  |  | 49,484 |  |  |  |
| Others | 12,166 |  |  |  |  | 13,062 |  |  |  |
| Total revenue in Europe | $ | 58,431 |  |  | 8.9 | % |  | $ | 90,549 |  |  | 16.7 | % |
| Total revenue | $ | 655,429 |  |  | 100.0 | % |  | $ | 543,322 |  |  | 100.0 | % |

[0001408710-22-000060:notes:14]
[same as prior period, unchanged from 0001408710-22-000028:notes:18]

[0001408710-22-000060:notes:15]
(2)Due to change in bill-to-location for a certain customer.

[0001408710-22-000060:notes:16]
[same as prior period, unchanged from 0001408710-22-000028:notes:19]

[0001408710-22-000060:notes:17]
| (in thousands, except percentages) | Three Months EndedSeptember 30, 2022 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 24, 2021 |  | As a % of TotalRevenues |
| Optical communications | $ | 497,561 |  |  | 75.9 | % |  | $ | 427,301 |  |  | 78.6 | % |
| Lasers, sensors and other | 157,868 |  |  | 24.1 | % |  | 116,021 |  |  | 21.4 | % |
| Total | $ | 655,429 |  |  | 100.0 | % |  | $ | 543,322 |  |  | 100.0 | % |

[0001408710-22-000060:notes:18]
[same as prior period, unchanged from 0001408710-22-000028:notes:22]

[0001408710-22-000060:notes:19]
[same as prior period, unchanged from 0001408710-22-000028:notes:23]

[0001408710-22-000060:notes:20]
[same as prior period, unchanged from 0001408710-22-000028:notes:24]

[0001408710-22-000060:notes:21]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the three months ended September 30, 2022:

[0001408710-22-000060:notes:22]
| (in thousands) | ContractAssets |
| Beginning balance, June 24, 2022 | $ | 13,464 |  |
| Revenue recognized | 15,803 |  |
| Amounts collected or invoiced | (15,047) |  |
| Ending balance, September 30, 2022 | $ | 14,220 |  |

[0001408710-22-000060:notes:23]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 24, 2022 | $ | 1,982 |  |
| Advance payment received during the period | 8,411 |  |
| Revenue recognized | (4,045) |  |
| Ending balance, September 30, 2022 | $ | 6,348 |  |


## us-gaap:EarningsPerShareTextBlock

[0001408710-22-000060:notes:24]
[same as prior period, unchanged from 0001408710-22-000028:notes:28]

[0001408710-22-000060:notes:25]
[same as prior period, unchanged from 0001408710-22-000028:notes:29]

[0001408710-22-000060:notes:26]
|  | Three Months Ended |
| (in thousands, except per share data) | September 30,2022 |  | September 24,2021 |
| Net income attributable to shareholders | $ | 64,615 |  |  | $ | 44,651 |  |
| Weighted-average number of ordinary shares outstanding | 36,528 |  |  | 36,877 |  |
| Incremental shares arising from the assumed vesting of restricted share units and performance share units | 230 |  |  | 451 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share | 36,758 |  |  | 37,328 |  |
| Basic earnings per ordinary share | $ | 1.77 |  |  | $ | 1.21 |  |
| Diluted earnings per ordinary share | $ | 1.76 |  |  | $ | 1.20 |  |


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001408710-22-000060:notes:27]
[same as prior period, unchanged from 0001408710-22-000028:notes:32]

[0001408710-22-000060:notes:28]
|  |  |  | Fair Value |
| (in thousands) | CarryingCost |  | UnrealizedGain/(Loss) |  | Cash andCashEquivalents |  | MarketableSecurities |  | OtherInvestments |
| As of September 30, 2022 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 241,658 |  |  | $ | — |  |  | $ | 241,658 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 13,603 |  |  | (1) |  |  | 13,602 |  |  | — |  |  | — |  |
| Corporate debt securities | 236,977 |  |  | (7,101) |  |  | — |  |  | 229,876 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 15,035 |  |  | (375) |  |  | — |  |  | 14,660 |  |  | — |  |
| Total | $ | 507,273 |  |  | $ | (7,477) |  |  | $ | 255,260 |  |  | $ | 244,536 |  |  | $ | — |  |
| As of June 24, 2022 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 187,630 |  |  | $ | — |  |  | $ | 187,630 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 10,367 |  |  | (1) |  |  | 10,366 |  |  | — |  |  | — |  |
| Liquidity funds | 31,477 |  |  | — |  |  | — |  |  | — |  |  | 31,477 |  |
| Corporate debt securities | 234,689 |  |  | (5,671) |  |  | — |  |  | 229,018 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 20,007 |  |  | (345) |  |  | — |  |  | 19,662 |  |  | — |  |
| Total | $ | 484,170 |  |  | $ | (6,017) |  |  | $ | 197,996 |  |  | $ | 248,680 |  |  | $ | 31,477 |  |

[0001408710-22-000060:notes:29]
[same as prior period, unchanged from 0001408710-22-000028:notes:34]

[0001408710-22-000060:notes:30]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of September 30, 2022 and June 24, 2022:

[0001408710-22-000060:notes:31]
|  | September 30, 2022 |  | June 24, 2022 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 87,907 |  |  | $ | 87,038 |  |  | $ | 101,976 |  |  | $ | 101,400 |  |
| Due between one to five years | 164,105 |  |  | 157,498 |  |  | 184,197 |  |  | 178,757 |  |
| Total | $ | 252,012 |  |  | $ | 244,536 |  |  | $ | 286,173 |  |  | $ | 280,157 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001408710-22-000060:notes:32]
Fair value of financial instruments
Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. A fair value hierarchy is established, which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs for the valuation of an asset or liability as of the measurement date. The three levels of inputs that may be used to measure fair value are defined as follows:

[0001408710-22-000060:notes:33]
Level 1 inputs are quoted prices (unadjusted) in active markets for identical assets or liabilities.

[0001408710-22-000060:notes:34]
Level 2 inputs are inputs other than quoted prices included within Level 1 that are observable for assets or liabilities, either directly or indirectly. If the assets or liabilities have a specified (contractual) term, Level 2 inputs must be observable for substantially the full term of assets or liabilities.

[0001408710-22-000060:notes:35]
[same as prior period, unchanged from 0001408710-22-000028:notes:44]

[0001408710-22-000060:notes:36]
[same as prior period, unchanged from 0001408710-22-000028:notes:45]

[0001408710-22-000060:notes:37]
[same as prior period, unchanged from 0001408710-22-000028:notes:46]

[0001408710-22-000060:notes:38]
|  | Fair Value Measurements at Reporting Date Using |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of September 30, 2022 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 13,602 |  |  |  | $ | — |  |  | $ | 13,602 |  |
| Corporate debt securities | — |  |  | 229,876 |  |  |  | — |  |  | 229,876 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 14,660 |  |  |  | — |  |  | 14,660 |  |
| Derivative assets – current portion | — |  |  | 458 |  | (1) |  | — |  |  | 458 |  |
| Derivative assets – non-current portion | — |  |  | 64 |  | (2) |  | — |  |  | 64 |  |
| Total | $ | — |  |  | $ | 258,660 |  |  |  | $ | — |  |  | $ | 258,660 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | (10,489) |  |  |  | $ | — |  |  | $ | (10,489) |  |
| Total | $ | — |  |  | $ | (10,489) |  | (3) |  | $ | — |  |  | $ | (10,489) |  |

[0001408710-22-000060:notes:39]
|  | Fair Value Measurements at Reporting Date Using |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of June 24, 2022 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 10,366 |  |  |  | $ | — |  |  | $ | 10,366 |  |
| Liquidity funds | — |  |  | 31,477 |  |  |  | — |  |  | 31,477 |  |
| Corporate debt securities | — |  |  | 229,018 |  |  |  | — |  |  | 229,018 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 19,662 |  |  |  | — |  |  | 19,662 |  |
| Derivative assets – current portion | — |  |  | 110 |  | (4) |  | — |  |  | 110 |  |
| Total | $ | — |  |  | $ | 290,633 |  |  |  | $ | — |  |  | $ | 290,633 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | (7,345) |  |  |  | $ | — |  |  | $ | (7,345) |  |
| Derivative liabilities – non-current portion | — |  |  | (234) |  |  |  | — |  |  | (234) |  |
| Total | $ | — |  |  | $ | (7,579) |  | (5) |  | $ | — |  |  | $ | (7,579) |  |

[0001408710-22-000060:notes:40]
(1)Foreign currency forward contracts with an aggregate notional amount of $4.0 million and an interest rate swap agreement with a notional amount of $64.2 million.

[0001408710-22-000060:notes:41]
(2)Interest rate swap agreement with notional amount of $60.9 million.

[0001408710-22-000060:notes:42]
(3)Foreign currency forward contracts with an aggregate notional amount of $142.0 million and 0.6 million Canadian dollars and an interest rate swap agreement with a notional amount of $60.9 million.

[0001408710-22-000060:notes:43]
(4)Interest rate swap agreement with a notional amount of $64.2 million.

[0001408710-22-000060:notes:44]
(5)Foreign currency forward contracts with an aggregate notional amount of $135.0 million and 0.5 million Canadian dollars and an interest rate swap agreement with a notional amount of $60.9 million.

[0001408710-22-000060:notes:45]
[same as prior period, unchanged from 0001408710-22-000028:notes:53]

[0001408710-22-000060:notes:46]
The Company utilizes derivative financial instruments to hedge (i) foreign exchange risk associated with certain foreign currency denominated assets and liabilities and other foreign currency transactions, and (ii) interest rate risk associated with its long-term debt.

[0001408710-22-000060:notes:47]
[same as prior period, unchanged from 0001408710-22-000028:notes:55]

[0001408710-22-000060:notes:48]
[same as prior period, unchanged from 0001408710-22-000028:notes:56]

[0001408710-22-000060:notes:49]
[same as prior period, unchanged from 0001408710-22-000028:notes:57]

[0001408710-22-000060:notes:50]
The Company may enter into foreign currency forward contracts with maturities of up to 12 months to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht, including inventory purchases, payroll and other operating expenses. The Company considers these forward contracts as dual-purpose hedges, that hedge both the foreign exchange fluctuation (i) from inception through the forecasted expenditure, and (ii) any subsequent revaluation of the account payable or accrual. The Company may designate the forward contracts that hedge the foreign exchange fluctuation from inception through the forecasted expenditure as cash flow hedges. The gain or loss on a derivative instrument designated and qualified as a cash flow hedging instrument is recorded as a component of other comprehensive income and reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings. The reclassified amounts are presented in the same income statement line item as the earnings effect of the hedged item. Once the forecasted transactions are recorded, the Company will discontinue the hedging relationship by de-designating the derivative instrument and recording subsequent changes in fair value through contract maturity to foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income as a natural hedge against the Thai baht denominated assets and liabilities.

[0001408710-22-000060:notes:51]
The Company may also enter into non-designated foreign currency forward and option contracts to provide an offset to the re-measurement of foreign currency denominated assets and liabilities and to hedge certain forecasted exposures. Changes in the fair value of these non-designated derivatives are recorded as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-22-000060:notes:52]
As of September 30, 2022, the Company had 146 outstanding U.S. dollar foreign currency forward contracts against Thai baht, with an aggregate notional amount of $146.0 million and maturity dates ranging from October 2022 through April 2023 and one outstanding Canadian dollar foreign currency forward contract with an aggregate notional amount of 0.6 million Canadian dollars and a maturity date in December 2022.

[0001408710-22-000060:notes:53]
As of June 24, 2022, the Company had 135 outstanding U.S. dollar foreign currency forward contracts against Thai baht with an aggregate notional amount of $135.0 million and maturity dates ranging from July 2022 through January 2023, and one foreign currency contract with a notional amount of 0.5 million Canadian dollars and with a maturity date in September 2022.

[0001408710-22-000060:notes:54]
As of September 30, 2022, the hedging relationship over foreign currency forward contracts that were designated for hedge accounting was determined to be highly effective based on the performance of retrospective and prospective regression testing. As of September 30, 2022, the amount in accumulated other comprehensive income (“AOCI”) that is expected to be reclassified into earnings within 12 months was a loss of $6.3 million.

[0001408710-22-000060:notes:55]
As of June 24, 2022, the hedging relationship over foreign currency forward contracts that were designated for hedge accounting had been tested to be highly effective based on the performance of retrospective and prospective regression testing. As of June 24, 2022, the amount in AOCI that is expected to be reclassified into earnings within 12 months was a loss of $4.8 million.

[0001408710-22-000060:notes:56]
During the three months ended September 30, 2022 and September 24, 2021, the Company included an unrealized loss of $0.2 million and $0.6 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-22-000060:notes:57]
[same as prior period, unchanged from 0001408710-22-000028:notes:67]

[0001408710-22-000060:notes:58]
The Company entered into interest rate swap agreements to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. As of September 30, 2022 and June 24, 2022, the Company had two outstanding interest rate swap agreements with an aggregate notional amount of $125.1 million.

[0001408710-22-000060:notes:59]
On July 25, 2018, Fabrinet Thailand entered into an interest rate swap agreement to effectively convert the floating interest rate of its term loan under a credit facility agreement with Bank of America to a fixed interest rate of 2.86% per annum

[0001408710-22-000060:notes:60]
through the scheduled maturity of the term loan in June 2023 (see Note 10). The Company did not designate this interest rate swap for hedge accounting.

[0001408710-22-000060:notes:61]
On September 3, 2019, Fabrinet Thailand entered into a term loan agreement under a credit facility agreement with the Bank of Ayudhya Public Company Limited (the “Bank”) (see Note 10) and on September 10, 2019, the Company repaid in full the outstanding term loan under the Bank of America Credit Facility Agreement (see Note 10). In conjunction with the funding of the new term loan, the Company entered into a second interest rate swap agreement. The combination of both of these interest rate swaps effectively converts the floating interest rate of the Company’s term loan with the Bank to a fixed interest rate of 4.36% per annum through the maturity of the term loan in June 2024.

[0001408710-22-000060:notes:62]
On September 27, 2019, the Company designated these two interest rate swaps as a cash flow hedge for the Company’s term loan under the credit facility agreement with the Bank. The combination of these two interest rate swaps qualified for hedge accounting because the hedges are highly effective, and the Company has designated and documented contemporaneously the hedging relationships involving these interest rate swaps. While the Company intends to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in earnings. From September 27, 2019, any gains or losses related to these interest rate swaps are recorded in AOCI in the unaudited condensed consolidated balance sheets. The Company reclassifies a portion of the gains or losses from AOCI into earnings at each reporting period based on either the accrued interest amount or the interest payment.

[0001408710-22-000060:notes:63]
As of September 30, 2022, the amount in AOCI that is expected to be reclassified into earnings within 12 months was a loss of $0.2 million.

[0001408710-22-000060:notes:64]
As of June 24, 2022, the amount in AOCI that is expected to be reclassified into earnings within 12 months was a loss of $0.5 million.

[0001408710-22-000060:notes:65]
[same as prior period, unchanged from 0001408710-22-000028:notes:74]

[0001408710-22-000060:notes:66]
|  |  |  | Three Months Ended |
| (in thousands) | Financialstatementsline item |  | September 30,2022 |  | September 24,2021 |
| Derivatives gain (loss) recognized in other comprehensive income (loss): |  |  |  |  |  |
| Foreign currency forward contracts | Othercomprehensiveincome |  | $ | (2,992) |  |  | $ | (2,136) |  |
| Interest rate swaps | Othercomprehensiveincome |  | 516 |  |  | 408 |  |
| Total derivatives gain (loss) recognized in other comprehensive income (loss) |  |  | $ | (2,476) |  |  | $ | (1,728) |  |
| Derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings: |  |  |  |  |  |
| Foreign currency forward contracts | Cost of revenues |  | $ | 3,794 |  |  | $ | 2,115 |  |
| Foreign currency forward contracts | SG&A |  | 160 |  |  | 88 |  |
| Foreign currency forward contracts | Foreign exchange loss, net |  | (2,505) |  |  | (1,424) |  |
| Interest rate swaps | Interest expense |  | (191) |  |  | (268) |  |
| Total derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings |  |  | $ | 1,258 |  |  | $ | 511 |  |
| Change in net unrealized gain (loss) on derivatives instruments |  |  | $ | (1,218) |  |  | $ | (1,217) |  |

[0001408710-22-000060:notes:67]
[same as prior period, unchanged from 0001408710-22-000028:notes:76]

[0001408710-22-000060:notes:68]
[same as prior period, unchanged from 0001408710-22-000028:notes:77]

[0001408710-22-000060:notes:69]
|  | September 30,2022 |  | June 24,2022 |
| (in thousands) | DerivativeAssets |  | DerivativeLiabilities |  | DerivativeAssets |  | DerivativeLiabilities |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts | $ | — |  |  | $ | (3,067) |  |  | $ | — |  |  | $ | (1,561) |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward contracts | 14 |  |  | (6,342) |  |  | — |  |  | (4,821) |  |
| Interest rate swaps | 508 |  |  | (1,080) |  |  | 110 |  |  | (1,197) |  |
| Derivatives, gross balances | $ | 522 |  |  | $ | (10,489) |  |  | $ | 110 |  |  | $ | (7,579) |  |

[0001408710-22-000060:notes:70]
[same as prior period, unchanged from 0001408710-22-000028:notes:79]

[0001408710-22-000060:notes:71]
| Derivative Financial Instruments | Balance Sheet line item |
| Fair Value of Derivative Assets | Other current assets, Other non-current assets |
| Fair Value of Derivative Liabilities | Accrued expenses, Other non-current liabilities |


## us-gaap:InventoryDisclosureTextBlock

[0001408710-22-000060:notes:72]
[same as prior period, unchanged from 0001408710-22-000028:notes:81]

[0001408710-22-000060:notes:73]
| (in thousands) | As of September 30,2022 |  | As of June 24,2022 |
| Raw materials | $ | 196,196 |  |  | $ | 275,730 |  |
| Work in progress | 268,075 |  |  | 217,638 |  |
| Finished goods | 24,587 |  |  | 15,203 |  |
| Goods in transit | 39,192 |  |  | 48,574 |  |
| Total inventories | $ | 528,050 |  |  | $ | 557,145 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001408710-22-000060:notes:74]
LeasesThe Company leases facilities under non-cancelable operating lease agreements. The Company leases a portion of its capital equipment and vehicles, certain land and buildings for its facilities in Thailand, the Cayman Islands, the PRC, the U.S., the U.K., Israel and Singapore under operating lease arrangements that expire at various dates through 2025. Certain of these lease arrangements provide the Company the ability to extend the lease from one to five years following the expiration of the current term. However, the Company has excluded all lease extension options from its right of use (“ROU”) assets and lease liabilities as the Company is not reasonably assured that it will exercise these options. None of the lease agreements contain residual value guarantees provided by the lessee. The Company also has one intercompany lease transaction in the form of a lease of office and manufacturing space.
Operating leases

[0001408710-22-000060:notes:75]
As of September 30, 2022, the maturities of the Company’s operating lease liabilities were as follows:

[0001408710-22-000060:notes:76]
| (in thousands) |  |  |
| 2023 (remaining nine months) | $ | 1,749 |  |  |
| 2024 | 1,238 |  |  |
| 2025 | 37 |  |  |
| Total undiscounted lease payments | 3,024 |  |  |
| Less imputed interest | (72) |  |  |
| Total present value of lease liabilities | $ | 2,952 |  | (1) |

[0001408710-22-000060:notes:77]
(1)Includes current portion of operating lease liabilities of $2.3 million.

[0001408710-22-000060:notes:78]
Rental expense related to the Company’s operating leases is recognized on a straight-line basis over the lease term.

[0001408710-22-000060:notes:79]
Rental expense for long-term leases for the three months ended September 30, 2022 and September 24, 2021 was $0.6 million and $0.7 million, respectively. Rental expense for short-term leases for the three months ended September 30, 2022 and September 24, 2021 was immaterial.

[0001408710-22-000060:notes:80]
Finance leases

[0001408710-22-000060:notes:81]
As of September 30, 2022, the Company had one finance lease agreement with a de minimis amount.

[0001408710-22-000060:notes:82]
[same as prior period, unchanged from 0001408710-22-000028:notes:89]

[0001408710-22-000060:notes:83]
|  | As ofSeptember 30, 2022 |  | As ofJune 24, 2022 |
| Weighted-average remaining lease term (in years) | 1.6 |  | 1.8 |
| Weighted-average discount rate | 3.4 | % |  | 3.4 | % |

[0001408710-22-000060:notes:84]
The following table presents supplemental disclosure for the unaudited condensed consolidated statement of cash flows related to operating and finance leases for the three months ended September 30, 2022 and September 24, 2021:

[0001408710-22-000060:notes:85]
|  | Three Months Ended |
| (in thousands) | September 30,2022 |  | September 24,2021 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |
| Operating cash flows from operating leases | $ | 641 |  |  | $ | 689 |  |
| Financing cash flows from finance leases | $ | 2 |  |  | $ | — |  |
| ROU assets obtained in exchange for lease liabilities | $ | — |  |  | $ | 38 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001408710-22-000060:notes:86]
[same as prior period, unchanged from 0001408710-22-000028:notes:93]

[0001408710-22-000060:notes:87]
| (in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  | ForeignCurrencyTranslationAdjustment |  | Net |
| As of September 30, 2022 |  |  |  |  |  |  |  |
| Software | $ | 10,718 |  |  | $ | (7,935) |  |  | $ | — |  |  | $ | 2,783 |  |
| Customer relationships | 4,373 |  |  | (3,700) |  |  | (108) |  |  | 565 |  |
| Total intangibles | $ | 15,091 |  |  | $ | (11,635) |  |  | $ | (108) |  |  | $ | 3,348 |  |

[0001408710-22-000060:notes:88]
| (in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  | ForeignCurrencyTranslationAdjustment |  | Net |
| As of June 24, 2022 |  |  |  |  |  |  |  |
| Software | $ | 10,484 |  |  | $ | (7,681) |  |  | $ | — |  |  | $ | 2,803 |  |
| Customer relationships | 4,373 |  |  | (3,610) |  |  | (58) |  |  | 705 |  |
| Backlog | 119 |  |  | (119) |  |  | — |  |  | — |  |
| Total intangibles | $ | 14,976 |  |  | $ | (11,410) |  |  | $ | (58) |  |  | $ | 3,508 |  |

[0001408710-22-000060:notes:89]
The Company recorded amortization expense relating to intangibles of $0.4 million for each of the three months ended September 30, 2022 and September 24, 2021.

[0001408710-22-000060:notes:90]
The weighted-average remaining life of software and customer relationships was:

[0001408710-22-000060:notes:91]
| (years) | As ofSeptember 30, 2022 |  | As ofJune 24, 2022 |
| Software | 3.7 |  | 3.8 |
| Customer relationships | 2.9 |  | 3.1 |
| Total intangibles | 3.7 |  | 3.8 |

[0001408710-22-000060:notes:92]
Based on the carrying amount of intangibles as of September 30, 2022, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001408710-22-000060:notes:93]
| (in thousands) |  |
| 2023 (remaining 9 months) | $ | 987 |  |
| 2024 | 1,059 |  |
| 2025 | 801 |  |
| 2026 | 356 |  |
| 2027 | 135 |  |
| Thereafter | 10 |  |
| Total | $ | 3,348 |  |


## us-gaap:DebtDisclosureTextBlock

[0001408710-22-000060:notes:94]
Borrowings 
The Company’s total borrowings, including current and non-current portions of long-term borrowings, consisted of the following:

[0001408710-22-000060:notes:95]
| (in thousands of U.S. dollars) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofSeptember 30, 2022 |  | As ofJune 24, 2022 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 21,327 |  |  | $ | 27,421 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs, non-current portion |  |  |  |  | (22) |  |  | (31) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 9,117 |  |  | $ | 15,202 |  |

[0001408710-22-000060:notes:96]
(1)The Company has entered into interest rate swaps that effectively fix a series of future interest payments on its term loans. Refer to Note 6.

[0001408710-22-000060:notes:97]
The movements of long-term borrowings for the three months ended September 30, 2022 and September 24, 2021 were as follows:

[0001408710-22-000060:notes:98]
|  | Three Months Ended |
| (in thousands) | September 30,2022 |  | September 24,2021 |
| Opening balance | $ | 27,421 |  |  | $ | 39,609 |  |
| Repayments during the period | (6,094) |  |  | (3,047) |  |
| Closing balance | $ | 21,327 |  |  | $ | 36,562 |  |

[0001408710-22-000060:notes:99]
As of September 30, 2022, future maturities of long-term borrowings during each fiscal year were as follows:

[0001408710-22-000060:notes:100]
| (in thousands) |  |
| 2023 (remaining nine months) | $ | 6,093 |  |
| 2024 | 12,187 |  |
| 2025 | 3,047 |  |
| Total | $ | 21,327 |  |

[0001408710-22-000060:notes:101]
Credit facility agreements:

[0001408710-22-000060:notes:102]
Bank of Ayudhya Public Company Limited

[0001408710-22-000060:notes:103]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a credit facility agreement (the “Credit Facility Agreement”), which provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million that may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

[0001408710-22-000060:notes:104]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a term loan agreement (the "Term Loan Agreement") pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company's previous syndicated senior credit facility agreement.

[0001408710-22-000060:notes:105]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three months ended September 30, 2022, the Company recorded $0.6 million of interest expense in connection with this term loan, including the impact from interest rate swaps.

[0001408710-22-000060:notes:106]
Any borrowings under the Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

[0001408710-22-000060:notes:107]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, and restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of September 30, 2022, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

[0001408710-22-000060:notes:108]
The events of default under the Term Loan Agreement include failure to timely pay amounts due under the Term Loan Agreement or the related finance documents, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

[0001408710-22-000060:notes:109]
As of September 30, 2022, there was $21.3 million outstanding under the term loan.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001408710-22-000060:notes:110]
Income taxes
As of September 30, 2022 and June 24, 2022, the liability for uncertain tax positions including accrued interest and penalties was $0.8 million and $1.6 million, respectively. The Company expects the estimated amount of liability associated with its uncertain tax positions to decrease within the next 12 months due to the expiration of statutes of limitations with respect to these positions.

[0001408710-22-000060:notes:111]
[same as prior period, unchanged from 0001408710-22-000028:notes:118]

[0001408710-22-000060:notes:112]
The effective tax rate for the Company for the three months ended September 30, 2022 and September 24, 2021 was 1.1% and 1.3%, respectively, of net income. The decrease was primarily due to an increase in income not subject to tax during the first quarter of fiscal year 2023 as compared to the same period in fiscal year 2022.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001408710-22-000060:notes:113]
[same as prior period, unchanged from 0001408710-22-000028:notes:121]

[0001408710-22-000060:notes:114]
[same as prior period, unchanged from 0001408710-22-000028:notes:122]

[0001408710-22-000060:notes:115]
The effect of recording share-based compensation expense for the three months ended September 30, 2022 and September 24, 2021 was as follows:

[0001408710-22-000060:notes:116]
|  | Three Months Ended |
| (in thousands) | September 30,2022 |  | September 24,2021 |
| Share-based compensation expense by type of award: |  |  |  |
| Restricted share units | $ | 4,901 |  |  | $ | 4,924 |  |
| Performance share units | 2,822 |  |  | 4,368 |  |
| Total share-based compensation expense | 7,723 |  |  | 9,292 |  |
| Tax effect on share-based compensation expense | — |  |  | — |  |
| Net effect on share-based compensation expense | $ | 7,723 |  |  | $ | 9,292 |  |

[0001408710-22-000060:notes:117]
[same as prior period, unchanged from 0001408710-22-000028:notes:125]

[0001408710-22-000060:notes:118]
|  | Three Months Ended |
| (in thousands) | September 30,2022 |  | September 24,2021 |
| Cost of revenue | $ | 1,915 |  |  | $ | 1,975 |  |
| Selling, general and administrative expense | 5,808 |  |  | 7,317 |  |
| Total share-based compensation expense | $ | 7,723 |  |  | $ | 9,292 |  |

[0001408710-22-000060:notes:119]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the three months ended September 30, 2022 and September 24, 2021.

[0001408710-22-000060:notes:120]
[same as prior period, unchanged from 0001408710-22-000028:notes:128]

[0001408710-22-000060:notes:121]
[same as prior period, unchanged from 0001408710-22-000028:notes:129]

[0001408710-22-000060:notes:122]
As of September 30, 2022, there were 344,223 restricted share units outstanding, 204,016 performance share units outstanding and 1,989,573 ordinary shares available for future grant under the 2020 Plan.

[0001408710-22-000060:notes:123]
As of September 30, 2022, there were 47,876 restricted share units outstanding under the 2010 Plan. No ordinary shares are available for future grant under the 2010 Plan.

[0001408710-22-000060:notes:124]
On November 2, 2017, the Company adopted the 2017 Inducement Equity Incentive Plan (the “2017 Inducement Plan”) with a reserve of 160,000 ordinary shares authorized for future issuance solely for the granting of inducement share options and equity awards to new employees. The 2017 Inducement Plan was adopted without shareholder approval in reliance on the “employment inducement exemption” provided under the New York Stock Exchange Listed Company Manual. As of September 30, 2022, there were no awards outstanding and 111,347 ordinary shares available for future grant under the 2017 Inducement Plan.

[0001408710-22-000060:notes:125]
[same as prior period, unchanged from 0001408710-22-000028:notes:133]

[0001408710-22-000060:notes:126]
[same as prior period, unchanged from 0001408710-22-000028:notes:134]

[0001408710-22-000060:notes:127]
[same as prior period, unchanged from 0001408710-22-000028:notes:135]

[0001408710-22-000060:notes:128]
[same as prior period, unchanged from 0001408710-22-000028:notes:136]

[0001408710-22-000060:notes:129]
[same as prior period, unchanged from 0001408710-22-000028:notes:137]

[0001408710-22-000060:notes:130]
[same as prior period, unchanged from 0001408710-22-000028:notes:138]

[0001408710-22-000060:notes:131]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 24, 2022 | 459,626 |  |  | $ | 75.14 |  |
| Granted | 122,743 |  |  | $ | 117.35 |  |
| Vested | (180,824) |  |  | $ | 64.19 |  |
| Forfeited | (9,446) |  |  | $ | 90.47 |  |
| Balance as of September 30, 2022 | 392,099 |  |  | $ | 93.03 |  |

[0001408710-22-000060:notes:132]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 25, 2021 | 641,875 |  |  | $ | 55.74 |  |
| Granted | 137,165 |  |  | $ | 101.05 |  |
| Vested | (259,533) |  |  | $ | 50.76 |  |
| Forfeited | (9,084) |  |  | $ | 67.97 |  |
| Balance as of September 24, 2021 | 510,423 |  |  | $ | 70.23 |  |

[0001408710-22-000060:notes:133]
[same as prior period, unchanged from 0001408710-22-000028:notes:141]

[0001408710-22-000060:notes:134]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 24, 2022 | 285,882 |  |  | $ | 81.64 |  |
| Granted | 97,142 |  |  | $ | 117.35 |  |
| Vested | (179,008) |  |  | $ | 70.05 |  |
| Forfeited | — |  |  | $ | — |  |
| Balance as of September 30, 2022 | 204,016 |  |  | $ | 108.81 |  |

[0001408710-22-000060:notes:135]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 25, 2021 | 427,028 |  |  | $ | 57.82 |  |
| Granted | 110,832 |  |  | $ | 101.05 |  |
| Vested | (190,213) |  |  | 48.65 |  |
| Forfeited | (52,097) |  |  | $ | 48.65 |  |
| Balance as of September 24, 2021 | 295,550 |  |  | $ | 81.55 |  |

[0001408710-22-000060:notes:136]
The fair value of restricted share units and performance share units is based on the market value of Fabrinet's ordinary shares on the date of grant.

[0001408710-22-000060:notes:137]
As of September 30, 2022, there was $20.0 million and $14.9 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.9 and 1.6 years, respectively.
For the three months ended September 30, 2022 and September 24, 2021, the Company withheld an aggregate of 162,985 shares and 197,948 shares, respectively, upon the vesting of restricted share units and performance shares units, based upon the closing share price on the vesting date to settle employee tax withholding obligations. For the three months ended September 30, 2022 and September 24, 2021, the Company then remitted cash of $16.5 million and $19.1 million, respectively, to the appropriate taxing authorities and presented it as a financing activity within the unaudited condensed consolidated statements of cash flows. The payment was recorded as a reduction of additional paid-in capital.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001408710-22-000060:notes:138]
[same as prior period, unchanged from 0001408710-22-000028:notes:147]

[0001408710-22-000060:notes:139]
[same as prior period, unchanged from 0001408710-22-000028:notes:148]

[0001408710-22-000060:notes:140]
For the three months ended September 30, 2022, Fabrinet issued 196,847 ordinary shares upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-22-000060:notes:141]
For the three months ended September 24, 2021, Fabrinet issued 251,798 ordinary shares upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-22-000060:notes:142]
[same as prior period, unchanged from 0001408710-22-000028:notes:151]

[0001408710-22-000060:notes:143]
[same as prior period, unchanged from 0001408710-22-000028:notes:152]

[0001408710-22-000060:notes:144]
In August 2017, the Company’s board of directors approved a share repurchase program to permit the Company to repurchase up to $30.0 million worth of its issued and outstanding ordinary shares in the open market in accordance with applicable rules and regulations. In February 2018, May 2019, August 2020 and August 2022, the Company’s board of directors approved an increase of $30.0 million, $50.0 million, $58.5 million and $78.7 million, respectively, to the original share repurchase authorization, bringing the aggregate authorization to $247.2 million.

[0001408710-22-000060:notes:145]
During the three months ended September 30, 2022, the Company repurchased 46,977 shares under the program at an average price per share (excluding other direct costs) of $104.28 totaling $4.9 million. As of September 30, 2022, the Company had a remaining authorization to repurchase up to $95.1 million worth of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001408710-22-000060:notes:146]
Accumulated other comprehensive income (loss)
The changes in AOCI for the three months ended September 30, 2022 and September 24, 2021 were as follows:

[0001408710-22-000060:notes:147]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 24, 2022 | $ | (6,018) |  |  | $ | (5,082) |  |  | $ | (803) |  |  | $ | (890) |  |  | $ | (12,793) |  |
| Other comprehensive income before reclassification adjustment | (1,553) |  |  | (2,476) |  |  | — |  |  | 246 |  |  | (3,783) |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | 92 |  |  | 1,258 |  |  | 168 |  |  | — |  |  | 1,518 |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | $ | (1,461) |  |  | $ | (1,218) |  |  | $ | 168 |  |  | $ | 246 |  |  | $ | (2,265) |  |
| Balance as of September 30, 2022 | $ | (7,479) |  |  | $ | (6,300) |  |  | $ | (635) |  |  | $ | (644) |  |  | $ | (15,058) |  |

[0001408710-22-000060:notes:148]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 25, 2021 | $ | 308 |  |  | $ | (4,504) |  |  | $ | (1,425) |  |  | $ | (645) |  |  | $ | (6,266) |  |
| Other comprehensive income before reclassification adjustment | (200) |  |  | (1,728) |  |  | — |  |  | (164) |  |  | (2,092) |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | (13) |  |  | 511 |  |  | 198 |  |  | — |  |  | 696 |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | $ | (213) |  |  | $ | (1,217) |  |  | $ | 198 |  |  | $ | (164) |  |  | $ | (1,396) |  |
| Balance as of September 24, 2021 | $ | 95 |  |  | $ | (5,721) |  |  | $ | (1,227) |  |  | $ | (809) |  |  | $ | (7,662) |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001408710-22-000060:notes:149]
Commitments and contingencies
Bank guarantees

[0001408710-22-000060:notes:150]
As of September 30, 2022 and June 24, 2022, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $1.4 million and $1.4 million, or Thai baht 53.0 million and 50.2 million, respectively, and an outstanding bank guarantee on behalf of the Company's subsidiary in the PRC to support the subsidiary's operations totaling Renminbi 1.0 million, which bank guarantee was backed by cash collateral of $0.1 million. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in the U.K. to support its operations.

[0001408710-22-000060:notes:151]
Purchase obligations

[0001408710-22-000060:notes:152]
Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001408710-22-000060:notes:153]
As of September 30, 2022, the Company had a purchase obligation and other commitments to third parties of $1.39 billion.

[0001408710-22-000060:notes:154]
Capital expenditures

[0001408710-22-000060:notes:155]
As of September 30, 2022, the Company had total capital expenditure commitments to third parties of $25.9 million.

[0001408710-22-000060:notes:156]
Indemnification of directors and officers

[0001408710-22-000060:notes:157]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001408710-22-000060:notes:158]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001408710-22-000060:notes:159]
Business segments and geographic information
Operating segments are defined as components of an enterprise for which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. The Company’s chief operating decision maker is Fabrinet’s Chief Executive Officer. As of September 30, 2022, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001408710-22-000060:notes:160]
[same as prior period, unchanged from 0001408710-22-000028:notes:168]

[0001408710-22-000060:notes:161]
[same as prior period, unchanged from 0001408710-22-000028:notes:169]

[0001408710-22-000060:notes:162]
| (in thousands) |  | September 30,2022 |  | June 24,2022 |
| Long-Lived Assets: |  |  |  |  |
| Thailand |  | $ | 244,548 |  |  | $ | 240,750 |  |
| U.S. |  | 26,234 |  |  | 25,938 |  |
| China |  | 18,851 |  |  | 19,686 |  |
| Israel |  | 3,678 |  |  | 4,025 |  |
| U.K. |  | 1,015 |  |  | 1,281 |  |
| Cayman Islands |  | 551 |  |  | 597 |  |
|  |  | $ | 294,877 |  |  | $ | 292,277 |  |

[0001408710-22-000060:notes:163]
[same as prior period, unchanged from 0001408710-22-000028:notes:171]

[0001408710-22-000060:notes:164]
The Company had three customers that each contributed to 10% or more of the Company's total trade accounts receivable as of September 30, 2022 and June 24, 2022.
