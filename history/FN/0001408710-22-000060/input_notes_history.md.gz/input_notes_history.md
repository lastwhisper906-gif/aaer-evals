# FN note change history — 0001408710-22-000028 → 0001408710-22-000060


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0001408710-22-000060:note_history:1]
As of September 30, 2022 and June 24, 2022, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $1.4 million and $1.4 million, or Thai baht 53.0 million and 50.2 million, respectively, and an outstanding bank guarantee on behalf of the Company's subsidiary in the PRC to support the subsidiary's operations totaling Renminbi 1.0 million, which bank guarantee was backed by cash collateral of $0.1 million. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in the U.K. to support its operations.
  (was, 2022-05-03, similarity 0.8704):
[0001408710-22-000028:note_history:1]
As of March 25, 2022 and June 25, 2021, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling to $1.5 million and $1.6 million, respectively, or Thai Baht 50.2 million. As of March 25, 2022 and June 25, 2021, the Company had an outstanding bank guarantee on behalf of its subsidiary in the PRC to support the subsidiary's operations totaling Renminbi 1.0 million, which bank guarantee was backed by cash collateral of $0.2 million. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in the U.K. to support its operations.

- changed (2022-11-08):
[0001408710-22-000060:note_history:2]
As of September 30, 2022, the Company had a purchase obligation and other commitments to third parties of $1.39 billion.
  (was, 2022-05-03, similarity 0.945):
[0001408710-22-000028:note_history:2]
As of March 25, 2022, the Company had a purchase obligation and other commitments to third parties of $1,414.6 million.

- changed (2022-11-08):
[0001408710-22-000060:note_history:3]
As of September 30, 2022, the Company had total capital expenditure commitments to third parties of $25.9 million.
  (was, 2022-05-03, similarity 0.9515):
[0001408710-22-000028:note_history:3]
As of March 25, 2022, the Company had total capital expenditure commitments to third parties of $17.7 million.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0001408710-22-000060:note_history:4]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of September 30, 2022 and for the three months ended September 30, 2022 and September 24, 2021 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 24, 2022.
  (was, 2022-05-03, similarity 0.947):
[0001408710-22-000028:note_history:4]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of March 25, 2022 and for the three and nine months ended March 25, 2022 and March 26, 2021 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 25, 2021.

- changed (2022-11-08):
[0001408710-22-000060:note_history:5]
The results for the three months ended September 30, 2022 may not be indicative of results for the year ending June 30, 2023 or any future periods.
  (was, 2022-05-03, similarity 0.9319):
[0001408710-22-000028:note_history:5]
The results for the three and nine months ended March 25, 2022 may not be indicative of results for the year ending June 24, 2022 or any future periods.

- changed (2022-11-08):
[0001408710-22-000060:note_history:6]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information. Additionally, the extent to which the evolving COVID-19 pandemic impacts the Company’s unaudited condensed consolidated financial statements will depend on a number of factors, including the magnitude and duration of the pandemic. These estimates may change, as new events occur and additional information is obtained, or based upon the occurrence of other factors related to the COVID-19 pandemic that could result in material impacts to the Company's unaudited condensed consolidated financial statements in future reporting periods.
  (was, 2022-05-03, similarity 0.9684):
[0001408710-22-000028:note_history:6]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information. Additionally, the extent to which the evolving COVID-19 pandemic impacts the Company’s unaudited condensed consolidated financial statements will depend on a number of factors, including the magnitude and duration of the pandemic. These estimates may change as new events occur and additional information is obtained, as well as based upon the occurrence of other factors related to the COVID-19 pandemic that could result in material impacts to the Company's unaudited condensed consolidated financial statements in future reporting periods.

- added (2022-11-08):
[0001408710-22-000060:note_history:7]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  September 30, 2022 and September 24, 2021 consisted of 14 weeks and 13 weeks, respectively. Fiscal year 2023 will comprise 53 weeks and will end on June 30, 2023.

- changed (2022-11-08):
[0001408710-22-000060:note_history:8]
Adoption of New Accounting Standards
In November 2021, the Financial Accounting Standard Board issued Accounting Standards Update ("ASU") 2021-10, “Government Assistance (Topic 832), Disclosures by Business Entities about Government Assistance,” which requires annual disclosures that increase the transparency of transactions involving government assistance, including (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The amendments in this update are effective for all entities within the ASU's scope for financial statements issued for annual periods beginning after December 15, 2021. The Company adopted this standard in the first quarter of fiscal year 2023 with no material impact on its unaudited condensed consolidated financial statements.
  (was, 2022-05-03, similarity 0.7451):
[0001408710-22-000028:note_history:8]
In November 2021, FASB issued ASU 2021-10, “Government Assistance (Topic 832), Disclosures by Business Entities about Government Assistance,” which requires annual disclosures that increase the transparency of transactions involving government assistance, including (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The amendments in this update are effective for all entities within the ASU's scope for financial statements issued for annual periods beginning after December 15, 2021. This ASU will be effective for the Company in the first quarter of fiscal year 2023. Early adoption is permitted.  The Company is currently evaluating the impact of the adoption of this update on its consolidated financial statements.

- removed (2022-11-08):
[0001408710-22-000028:note_history:9]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  March 25, 2022 and March 26, 2021 each consisted of 13 weeks. The nine months ended March 25, 2022 and March 26, 2021 each consisted of 39 weeks. Fiscal year 2022 will be comprised of 52 weeks and will end on June 24, 2022.

- removed (2022-11-08):
[0001408710-22-000028:note_history:10]
Adoption of New Accounting Standards

- removed (2022-11-08):
[0001408710-22-000028:note_history:11]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2019-12, “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.” The amendments in this update simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify U.S. GAAP for other areas of Topic 740 by clarifying and amending existing guidance. The Company adopted this standard in the first quarter of fiscal year 2022 with no material impact on its unaudited condensed consolidated financial statements.

- removed (2022-11-08):
[0001408710-22-000028:note_history:12]
New Accounting Pronouncements – not yet adopted by the Company


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0001408710-22-000060:note_history:13]
| (in thousands of U.S. dollars) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofSeptember 30, 2022 |  | As ofJune 24, 2022 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 21,327 |  |  | $ | 27,421 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs, non-current portion |  |  |  |  | (22) |  |  | (31) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 9,117 |  |  | $ | 15,202 |  |
  (was, 2022-05-03, similarity 0.9111):
[0001408710-22-000028:note_history:13]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofMarch 25, 2022 |  | As ofJune 25, 2021 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 30,468 |  |  | $ | 39,609 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs, non-current portion |  |  |  |  | (39) |  |  | (63) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 18,241 |  |  | $ | 27,358 |  |

- changed (2022-11-08):
[0001408710-22-000060:note_history:14]
(1)The Company has entered into interest rate swaps that effectively fix a series of future interest payments on its term loans. Refer to Note 6.
  (was, 2022-05-03, similarity 0.9155):
[0001408710-22-000028:note_history:14]
(1)We have entered into interest rate swaps that effectively fix a series of our future interest payments on our term loans. Refer to Note 6.

- changed (2022-11-08):
[0001408710-22-000060:note_history:15]
The movements of long-term borrowings for the three months ended September 30, 2022 and September 24, 2021 were as follows:
  (was, 2022-05-03, similarity 0.8756):
[0001408710-22-000028:note_history:15]
The movements of long-term borrowings for the nine months ended March 25, 2022 and March 26, 2021 were as follows:

- added (2022-11-08):
[0001408710-22-000060:note_history:16]
|  | Three Months Ended |
| (in thousands) | September 30,2022 |  | September 24,2021 |
| Opening balance | $ | 27,421 |  |  | $ | 39,609 |  |
| Repayments during the period | (6,094) |  |  | (3,047) |  |
| Closing balance | $ | 21,327 |  |  | $ | 36,562 |  |

- changed (2022-11-08):
[0001408710-22-000060:note_history:17]
As of September 30, 2022, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2022-05-03, similarity 0.95):
[0001408710-22-000028:note_history:17]
As of March 25, 2022, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2022-11-08):
[0001408710-22-000060:note_history:18]
| (in thousands) |  |
| 2023 (remaining nine months) | $ | 6,093 |  |
| 2024 | 12,187 |  |
| 2025 | 3,047 |  |
| Total | $ | 21,327 |  |
  (was, 2022-05-03, similarity 0.886):
[0001408710-22-000028:note_history:18]
| (amount in thousands) |  |
| 2022 (remaining three months) | $ | 3,047 |  |
| 2023 | 15,233 |  |
| 2024 | 9,141 |  |
| 2025 | 3,047 |  |
| Total | $ | 30,468 |  |

- changed (2022-11-08):
[0001408710-22-000060:note_history:19]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a term loan agreement (the "Term Loan Agreement") pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company's previous syndicated senior credit facility agreement.
  (was, 2022-05-03, similarity 0.9977):
[0001408710-22-000028:note_history:19]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a term loan agreement (the "Term Loan Agreement") pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company’s previous syndicated senior credit facility agreement.

- added (2022-11-08):
[0001408710-22-000060:note_history:20]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three months ended September 30, 2022, the Company recorded $0.6 million of interest expense in connection with this term loan, including the impact from interest rate swaps.

- changed (2022-11-08):
[0001408710-22-000060:note_history:21]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, and restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of September 30, 2022, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.
  (was, 2022-05-03, similarity 0.9916):
[0001408710-22-000028:note_history:21]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of March 25, 2022, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

- changed (2022-11-08):
[0001408710-22-000060:note_history:22]
As of September 30, 2022, there was $21.3 million outstanding under the term loan.
  (was, 2022-05-03, similarity 0.9296):
[0001408710-22-000028:note_history:22]
As of March 25, 2022, there was $30.5 million outstanding under the term loan.

- removed (2022-11-08):
[0001408710-22-000028:note_history:23]
|  | Nine Months Ended |
| (amount in thousands) | March 25,2022 |  | March 26,2021 |
| Opening balance | $ | 39,609 |  |  | $ | 51,797 |  |
| Borrowings during the period | — |  |  | — |  |
| Repayments during the period | (9,141) |  |  | (9,141) |  |
| Closing balance | $ | 30,468 |  |  | $ | 42,656 |  |

- removed (2022-11-08):
[0001408710-22-000028:note_history:24]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three and nine months ended March 25, 2022, the Company recorded $0.6 million and $1.7 million, respectively, of interest expense in connection with this term loan, including impact from interest rate swaps. $0.3 million and $0.6 million of these interest expenses were capitalized during the three and nine months ended March 25, 2022, respectively, in a new manufacturing building at the Company's Chonburi campus.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0001408710-22-000060:note_history:25]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of September 30, 2022 and June 24, 2022:
  (was, 2022-05-03, similarity 0.9655):
[0001408710-22-000028:note_history:25]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of March 25, 2022 and June 25, 2021:

- added (2022-11-08):
[0001408710-22-000060:note_history:26]
|  | September 30, 2022 |  | June 24, 2022 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 87,907 |  |  | $ | 87,038 |  |  | $ | 101,976 |  |  | $ | 101,400 |  |
| Due between one to five years | 164,105 |  |  | 157,498 |  |  | 184,197 |  |  | 178,757 |  |
| Total | $ | 252,012 |  |  | $ | 244,536 |  |  | $ | 286,173 |  |  | $ | 280,157 |  |

- removed (2022-11-08):
[0001408710-22-000028:note_history:27]
|  | March 25, 2022 |  | June 25, 2021 |
| (amount in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 68,455 |  |  | $ | 68,383 |  |  | $ | 30,000 |  |  | $ | 31,226 |  |
| Due between one to five years | 180,697 |  |  | 177,469 |  |  | 202,927 |  |  | 203,237 |  |
| Total | $ | 249,152 |  |  | $ | 245,852 |  |  | $ | 232,927 |  |  | $ | 234,463 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0001408710-22-000060:note_history:28]
The movements of long-term borrowings for the three months ended September 30, 2022 and September 24, 2021 were as follows:
  (was, 2022-05-03, similarity 0.8756):
[0001408710-22-000028:note_history:28]
The movements of long-term borrowings for the nine months ended March 25, 2022 and March 26, 2021 were as follows:

- added (2022-11-08):
[0001408710-22-000060:note_history:29]
|  | Three Months Ended |
| (in thousands) | September 30,2022 |  | September 24,2021 |
| Opening balance | $ | 27,421 |  |  | $ | 39,609 |  |
| Repayments during the period | (6,094) |  |  | (3,047) |  |
| Closing balance | $ | 21,327 |  |  | $ | 36,562 |  |

- removed (2022-11-08):
[0001408710-22-000028:note_history:30]
|  | Nine Months Ended |
| (amount in thousands) | March 25,2022 |  | March 26,2021 |
| Opening balance | $ | 39,609 |  |  | $ | 51,797 |  |
| Borrowings during the period | — |  |  | — |  |
| Repayments during the period | (9,141) |  |  | (9,141) |  |
| Closing balance | $ | 30,468 |  |  | $ | 42,656 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0001408710-22-000060:note_history:31]
| (in thousands of U.S. dollars) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofSeptember 30, 2022 |  | As ofJune 24, 2022 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 21,327 |  |  | $ | 27,421 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs, non-current portion |  |  |  |  | (22) |  |  | (31) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 9,117 |  |  | $ | 15,202 |  |
  (was, 2022-05-03, similarity 0.9111):
[0001408710-22-000028:note_history:31]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofMarch 25, 2022 |  | As ofJune 25, 2021 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 30,468 |  |  | $ | 39,609 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs, non-current portion |  |  |  |  | (39) |  |  | (63) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 18,241 |  |  | $ | 27,358 |  |

- changed (2022-11-08):
[0001408710-22-000060:note_history:32]
(1)The Company has entered into interest rate swaps that effectively fix a series of future interest payments on its term loans. Refer to Note 6.
  (was, 2022-05-03, similarity 0.9155):
[0001408710-22-000028:note_history:32]
(1)We have entered into interest rate swaps that effectively fix a series of our future interest payments on our term loans. Refer to Note 6.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0001408710-22-000060:note_history:33]
As of September 30, 2022, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2022-05-03, similarity 0.95):
[0001408710-22-000028:note_history:33]
As of March 25, 2022, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2022-11-08):
[0001408710-22-000060:note_history:34]
| (in thousands) |  |
| 2023 (remaining nine months) | $ | 6,093 |  |
| 2024 | 12,187 |  |
| 2025 | 3,047 |  |
| Total | $ | 21,327 |  |
  (was, 2022-05-03, similarity 0.886):
[0001408710-22-000028:note_history:34]
| (amount in thousands) |  |
| 2022 (remaining three months) | $ | 3,047 |  |
| 2023 | 15,233 |  |
| 2024 | 9,141 |  |
| 2025 | 3,047 |  |
| Total | $ | 30,468 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0001408710-22-000060:note_history:35]
| (in thousands, except percentages) | Three Months EndedSeptember 30, 2022 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 24, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 345,080 |  |  |  |  | $ | 245,274 |  |  |  |
| Others (1) | 3,624 |  |  |  |  | 1,316 |  |  |  |
| Total revenue in North America | 348,704 |  |  | 53.2 | % |  | 246,590 |  |  | 45.4 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 80,033 |  |  |  |  | 64,932 |  |  |  |
| Malaysia | 49,324 |  |  |  |  | 51,749 |  |  |  |
| Israel | 37,277 |  |  |  |  | 27,634 |  |  |  |
| Hong Kong | 32,472 |  |  |  |  | 21,031 |  |  |  |
| China | 23,064 |  |  |  |  | 13,635 |  |  |  |
| Thailand | 12,616 |  |  |  |  | 9,759 |  |  |  |
| Japan | 10,348 |  |  |  |  | 14,977 |  |  |  |
| Others | 3,160 |  |  |  |  | 2,466 |  |  |  |
| Total revenue in Asia-Pacific and others | 248,294 |  |  | 37.9 | % |  | 206,183 |  |  | 37.9 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 32,832 |  |  |  |  | 19,578 |  |  |  |
| Germany | 13,314 |  |  |  |  | 8,425 |  |  |  |
| Ireland (2) | 119 |  |  |  |  | 49,484 |  |  |  |
| Others | 12,166 |  |  |  |  | 13,062 |  |  |  |
| Total revenue in Europe | $ | 58,431 |  |  | 8.9 | % |  | $ | 90,549 |  |  | 16.7 | % |
| Total revenue | $ | 655,429 |  |  | 100.0 | % |  | $ | 543,322 |  |  | 100.0 | % |
  (was, 2022-05-03, similarity 0.7568):
[0001408710-22-000028:note_history:35]
| (amount in thousands, except percentages) | Three Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 230,177 |  |  |  |  | 661,410 |  |  |  |
| Others (1) | 618 |  |  |  |  | 1,459 |  |  |  |
| Total revenue in North America | 230,795 |  |  | 48.2 | % |  | 662,869 |  |  | 48.4 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Malaysia | 22,910 |  |  |  |  | 107,700 |  |  |  |
| India | 56,719 |  |  |  |  | 85,535 |  |  |  |
| Israel | 25,796 |  |  |  |  | 82,915 |  |  |  |
| Hong Kong | 21,524 |  |  |  |  | 63,397 |  |  |  |
| Japan | 18,582 |  |  |  |  | 56,223 |  |  |  |
| Others | 21,770 |  |  |  |  | 71,477 |  |  |  |
| Total revenue in Asia-Pacific and others | 167,301 |  |  | 34.9 | % |  | 467,247 |  |  | 34.1 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 47,096 |  |  |  |  | 149,696 |  |  |  |
| U.K. | 15,298 |  |  |  |  | 40,742 |  |  |  |
| Germany | 7,543 |  |  |  |  | 19,596 |  |  |  |
| Others | 11,284 |  |  |  |  | 29,633 |  |  |  |
| Total revenue in Europe | $ | 81,221 |  |  | 16.9 | % |  | $ | 239,667 |  |  | 17.5 | % |
| Total revenue | $ | 479,317 |  |  | 100.0 | % |  | $ | 1,369,783 |  |  | 100.0 | % |

- added (2022-11-08):
[0001408710-22-000060:note_history:36]
(2)Due to change in bill-to-location for a certain customer.

- removed (2022-11-08):
[0001408710-22-000028:note_history:37]
| (amount in thousands, except percentages) | Three Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 292,475 |  |  |  |  | 781,469 |  |  |  |
| Others (1) | 4,123 |  |  |  |  | 8,996 |  |  |  |
| Total revenue in North America | 296,598 |  |  | 52.5 | % |  | 790,465 |  |  | 47.2 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 70,956 |  |  |  |  | 210,009 |  |  |  |
| Malaysia | 51,188 |  |  |  |  | 163,306 |  |  |  |
| Hong Kong | 17,338 |  |  |  |  | 61,575 |  |  |  |
| Israel | 16,883 |  |  |  |  | 67,318 |  |  |  |
| Japan | 16,449 |  |  |  |  | 47,258 |  |  |  |
| China | 12,843 |  |  |  |  | 40,624 |  |  |  |
| Others | 10,559 |  |  |  |  | 34,349 |  |  |  |
| Total revenue in Asia-Pacific and others | 196,216 |  |  | 34.8 | % |  | 624,439 |  |  | 37.3 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 28,640 |  |  |  |  | 133,024 |  |  |  |
| U.K. | 21,632 |  |  |  |  | 64,151 |  |  |  |
| Germany | 10,688 |  |  |  |  | 28,098 |  |  |  |
| Others | 10,621 |  |  |  |  | 34,173 |  |  |  |
| Total revenue in Europe | $ | 71,581 |  |  | 12.7 | % |  | $ | 259,446 |  |  | 15.5 | % |
| Total revenue | $ | 564,395 |  |  | 100.0 | % |  | $ | 1,674,350 |  |  | 100.0 | % |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-11-08):
[0001408710-22-000060:note_history:38]
| (in thousands, except percentages) | Three Months EndedSeptember 30, 2022 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 24, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 345,080 |  |  |  |  | $ | 245,274 |  |  |  |
| Others (1) | 3,624 |  |  |  |  | 1,316 |  |  |  |
| Total revenue in North America | 348,704 |  |  | 53.2 | % |  | 246,590 |  |  | 45.4 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 80,033 |  |  |  |  | 64,932 |  |  |  |
| Malaysia | 49,324 |  |  |  |  | 51,749 |  |  |  |
| Israel | 37,277 |  |  |  |  | 27,634 |  |  |  |
| Hong Kong | 32,472 |  |  |  |  | 21,031 |  |  |  |
| China | 23,064 |  |  |  |  | 13,635 |  |  |  |
| Thailand | 12,616 |  |  |  |  | 9,759 |  |  |  |
| Japan | 10,348 |  |  |  |  | 14,977 |  |  |  |
| Others | 3,160 |  |  |  |  | 2,466 |  |  |  |
| Total revenue in Asia-Pacific and others | 248,294 |  |  | 37.9 | % |  | 206,183 |  |  | 37.9 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 32,832 |  |  |  |  | 19,578 |  |  |  |
| Germany | 13,314 |  |  |  |  | 8,425 |  |  |  |
| Ireland (2) | 119 |  |  |  |  | 49,484 |  |  |  |
| Others | 12,166 |  |  |  |  | 13,062 |  |  |  |
| Total revenue in Europe | $ | 58,431 |  |  | 8.9 | % |  | $ | 90,549 |  |  | 16.7 | % |
| Total revenue | $ | 655,429 |  |  | 100.0 | % |  | $ | 543,322 |  |  | 100.0 | % |
  (was, 2022-05-03, similarity 0.7568):
[0001408710-22-000028:note_history:38]
| (amount in thousands, except percentages) | Three Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 230,177 |  |  |  |  | 661,410 |  |  |  |
| Others (1) | 618 |  |  |  |  | 1,459 |  |  |  |
| Total revenue in North America | 230,795 |  |  | 48.2 | % |  | 662,869 |  |  | 48.4 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Malaysia | 22,910 |  |  |  |  | 107,700 |  |  |  |
| India | 56,719 |  |  |  |  | 85,535 |  |  |  |
| Israel | 25,796 |  |  |  |  | 82,915 |  |  |  |
| Hong Kong | 21,524 |  |  |  |  | 63,397 |  |  |  |
| Japan | 18,582 |  |  |  |  | 56,223 |  |  |  |
| Others | 21,770 |  |  |  |  | 71,477 |  |  |  |
| Total revenue in Asia-Pacific and others | 167,301 |  |  | 34.9 | % |  | 467,247 |  |  | 34.1 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 47,096 |  |  |  |  | 149,696 |  |  |  |
| U.K. | 15,298 |  |  |  |  | 40,742 |  |  |  |
| Germany | 7,543 |  |  |  |  | 19,596 |  |  |  |
| Others | 11,284 |  |  |  |  | 29,633 |  |  |  |
| Total revenue in Europe | $ | 81,221 |  |  | 16.9 | % |  | $ | 239,667 |  |  | 17.5 | % |
| Total revenue | $ | 479,317 |  |  | 100.0 | % |  | $ | 1,369,783 |  |  | 100.0 | % |

- added (2022-11-08):
[0001408710-22-000060:note_history:39]
(2)Due to change in bill-to-location for a certain customer.

- changed (2022-11-08):
[0001408710-22-000060:note_history:40]
| (in thousands, except percentages) | Three Months EndedSeptember 30, 2022 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 24, 2021 |  | As a % of TotalRevenues |
| Optical communications | $ | 497,561 |  |  | 75.9 | % |  | $ | 427,301 |  |  | 78.6 | % |
| Lasers, sensors and other | 157,868 |  |  | 24.1 | % |  | 116,021 |  |  | 21.4 | % |
| Total | $ | 655,429 |  |  | 100.0 | % |  | $ | 543,322 |  |  | 100.0 | % |
  (was, 2022-05-03, similarity 0.6839):
[0001408710-22-000028:note_history:40]
| (amount in thousands, except percentages) | Three Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |
| Optical communications | $ | 440,003 |  |  | 78.0 | % |  | $ | 1,318,087 |  |  | 78.7 | % |
| Lasers, sensors and other | 124,392 |  |  | 22.0 | % |  | 356,263 |  |  | 21.3 | % |
| Total | $ | 564,395 |  |  | 100.0 | % |  | $ | 1,674,350 |  |  | 100.0 | % |

- changed (2022-11-08):
[0001408710-22-000060:note_history:41]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the three months ended September 30, 2022:
  (was, 2022-05-03, similarity 0.9408):
[0001408710-22-000028:note_history:41]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the nine months ended March 25, 2022:

- changed (2022-11-08):
[0001408710-22-000060:note_history:42]
| (in thousands) | ContractAssets |
| Beginning balance, June 24, 2022 | $ | 13,464 |  |
| Revenue recognized | 15,803 |  |
| Amounts collected or invoiced | (15,047) |  |
| Ending balance, September 30, 2022 | $ | 14,220 |  |
  (was, 2022-05-03, similarity 0.9561):
[0001408710-22-000028:note_history:42]
| (amount in thousands) | ContractAssets |
| Beginning balance, June 25, 2021 | $ | 11,878 |  |
| Revenue recognized | 37,195 |  |
| Amounts collected or invoiced | (35,505) |  |
| Ending balance, March 25, 2022 | $ | 13,568 |  |

- changed (2022-11-08):
[0001408710-22-000060:note_history:43]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 24, 2022 | $ | 1,982 |  |
| Advance payment received during the period | 8,411 |  |
| Revenue recognized | (4,045) |  |
| Ending balance, September 30, 2022 | $ | 6,348 |  |
  (was, 2022-05-03, similarity 0.9551):
[0001408710-22-000028:note_history:43]
| (amount in thousands) | ContractLiabilities |
| Beginning balance, June 25, 2021 | $ | 1,680 |  |
| Advance payment received during the period | 4,898 |  |
| Revenue recognized | (4,655) |  |
| Ending balance, March 25, 2022 | $ | 1,923 |  |

- removed (2022-11-08):
[0001408710-22-000028:note_history:44]
| (amount in thousands, except percentages) | Three Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 292,475 |  |  |  |  | 781,469 |  |  |  |
| Others (1) | 4,123 |  |  |  |  | 8,996 |  |  |  |
| Total revenue in North America | 296,598 |  |  | 52.5 | % |  | 790,465 |  |  | 47.2 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 70,956 |  |  |  |  | 210,009 |  |  |  |
| Malaysia | 51,188 |  |  |  |  | 163,306 |  |  |  |
| Hong Kong | 17,338 |  |  |  |  | 61,575 |  |  |  |
| Israel | 16,883 |  |  |  |  | 67,318 |  |  |  |
| Japan | 16,449 |  |  |  |  | 47,258 |  |  |  |
| China | 12,843 |  |  |  |  | 40,624 |  |  |  |
| Others | 10,559 |  |  |  |  | 34,349 |  |  |  |
| Total revenue in Asia-Pacific and others | 196,216 |  |  | 34.8 | % |  | 624,439 |  |  | 37.3 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 28,640 |  |  |  |  | 133,024 |  |  |  |
| U.K. | 21,632 |  |  |  |  | 64,151 |  |  |  |
| Germany | 10,688 |  |  |  |  | 28,098 |  |  |  |
| Others | 10,621 |  |  |  |  | 34,173 |  |  |  |
| Total revenue in Europe | $ | 71,581 |  |  | 12.7 | % |  | $ | 259,446 |  |  | 15.5 | % |
| Total revenue | $ | 564,395 |  |  | 100.0 | % |  | $ | 1,674,350 |  |  | 100.0 | % |

- removed (2022-11-08):
[0001408710-22-000028:note_history:45]
| (amount in thousands, except percentages) | Three Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |
| Optical communications | $ | 361,739 |  |  | 75.5 | % |  | $ | 1,053,496 |  |  | 76.9 | % |
| Lasers, sensors and other | 117,578 |  |  | 24.5 | % |  | 316,287 |  |  | 23.1 | % |
| Total | $ | 479,317 |  |  | 100.0 | % |  | $ | 1,369,783 |  |  | 100.0 | % |
