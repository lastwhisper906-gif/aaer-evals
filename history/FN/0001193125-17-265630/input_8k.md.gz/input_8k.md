# FN 8-K — 0001193125-17-263714 filed 2017-08-21

## item codes, every 8-K on or before 2017-08-23

- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2017-08-23

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-263714:8k_2_02:1]
EX-99.1
2
d436847dex991.htm
EX-99.1

[0001193125-17-263714:8k_2_02:2]
EX-99.1

[0001193125-17-263714:8k_2_02:3]
Exhibit 99.1

[0001193125-17-263714:8k_2_02:4]
Fabrinet Announces Fourth Quarter and Fiscal-Year 2017 Financial Results

[0001193125-17-263714:8k_2_02:5]
BANGKOK, Thailand – August 21, 2017 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical,
electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its fourth quarter and fiscal year ended June 30, 2017.

[0001193125-17-263714:8k_2_02:6]
Tom Mitchell, Chief Executive Officer of Fabrinet, said, “Our strong fourth quarter performance, with revenue and net income per diluted share that
exceeded our guidance ranges, represented an excellent finish to a record year for Fabrinet. The fourth quarter was our 12th consecutive quarter of year-over-year revenue growth, at 34%. This
performance was driven by a combination of growth from both existing customers and new customer programs.

[0001193125-17-263714:8k_2_02:7]
“In addition to delivering a strong
financial performance, fiscal year 2017 was also significant from a strategic perspective. We substantially increased our manufacturing capacity and further developed our new product introduction capabilities, especially outside the optical
communications market, positioning us to generate strong returns from a diversifying customer base. With our expanded capacity and a robust pipeline of opportunities, we are optimistic that our success in fiscal year 2017 will extend into fiscal
year 2018.”

[0001193125-17-263714:8k_2_02:8]
Fourth Quarter Fiscal-Year 2017 Financial Highlights

[0001193125-17-263714:8k_2_02:9]
GAAP Results

[0001193125-17-263714:8k_2_02:10]
|  | • |  | Revenue was $370.5 million for the fourth quarter of fiscal year 2017, an increase of 34% compared to revenue of $276.4 million for the comparable period in fiscal year 2016. |

[0001193125-17-263714:8k_2_02:11]
|  | • |  | GAAP net income for the fourth quarter of fiscal year 2017 was $27.4 million, compared to GAAP net income of $19.7 million for the fourth quarter of fiscal year 2016. |

[0001193125-17-263714:8k_2_02:12]
|  | • |  | GAAP net income per diluted share for the fourth quarter of fiscal year 2017 was $0.72, compared to GAAP net income per diluted share of $0.53 for the fourth quarter of fiscal year 2016. |

[0001193125-17-263714:8k_2_02:13]
Non-GAAP Results

[0001193125-17-263714:8k_2_02:14]
|  | • |  | Non-GAAP net income for the fourth quarter of fiscal year 2017 was $32.8 million, an increase of 46% compared to non-GAAP net income of $22.4 million for the same period a year ago. |

[0001193125-17-263714:8k_2_02:15]
|  | • |  | Non-GAAP net income per diluted share for the fourth quarter of fiscal year 2017 was $0.86, an increase from non-GAAP net income per diluted share of $0.60 for the same period a year ago. |

[0001193125-17-263714:8k_2_02:16]
Fiscal-Year 2017 Financial Highlights

[0001193125-17-263714:8k_2_02:17]
GAAP Results

[0001193125-17-263714:8k_2_02:18]
|  | • |  | Revenue was $1.4 billion for fiscal year 2017, an increase of 45% compared to total revenue of $976.7 million for fiscal year 2016. |

[0001193125-17-263714:8k_2_02:19]
|  | • |  | GAAP net income for fiscal year 2017 was $97.1 million, compared to GAAP net income of $61.9 million for fiscal year 2016. |

[0001193125-17-263714:8k_2_02:20]
|  | • |  | GAAP net income per diluted share for fiscal year 2017 was $2.57, compared to GAAP net income per diluted share of $1.68 for fiscal year 2016. |

[0001193125-17-263714:8k_2_02:21]
Non-GAAP Results

[0001193125-17-263714:8k_2_02:22]
|  | • |  | Non-GAAP net income for fiscal year 2017 was $127.4 million, an increase of 64% compared to non-GAAP net income of $77.7 million for fiscal year 2016. |

[0001193125-17-263714:8k_2_02:23]
|  | • |  | Non-GAAP net income per diluted share for fiscal year 2017 was $3.37, an increase from non-GAAP net income per diluted share of $2.11 for fiscal year 2016. |

[0001193125-17-263714:8k_2_02:24]
Business Outlook

[0001193125-17-263714:8k_2_02:25]
Based on information available as of August 21, 2017, Fabrinet is issuing guidance for the first quarter of fiscal year 2018 ending September 29,
2017, as follows:

[0001193125-17-263714:8k_2_02:26]
|  | • |  | Fabrinet expects first quarter revenue to be in the range of $356 million to $360 million. |

[0001193125-17-263714:8k_2_02:27]
|  | • |  | GAAP net income per diluted share is expected to be in the range of $0.60 to $0.62, based on approximately 38.2 million fully diluted shares outstanding. |

[0001193125-17-263714:8k_2_02:28]
|  | • |  | Non-GAAP net income per diluted share is expected to be in the range of $0.78 to $0.80, based on approximately 38.2 million fully diluted shares outstanding. |

[0001193125-17-263714:8k_2_02:29]
Share Repurchase Program Authorized

[0001193125-17-263714:8k_2_02:30]
Fabrinet also
announced that its Board of Directors has approved a share repurchase program to permit the Company to repurchase up to $30.0 million worth of its issued and outstanding ordinary shares in the open market in accordance with applicable rules and
regulations, at such time and such prices as management may decide.

[0001193125-17-263714:8k_2_02:31]
The repurchased shares will be held as treasury stock.

[0001193125-17-263714:8k_2_02:32]
Conference Call Information

[0001193125-17-263714:8k_2_02:33]
| What: |  | Fabrinet Fourth Quarter and Fiscal-Year 2017 Financial Results Conference Call |
| When: |  | Monday, August 21, 2017 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic |
|  |  | (253) 237-1137, international |
|  |  | Passcode: 59923512 |
| Replay: |  | (855) 859-2056, domestic |
|  |  | (404) 537-3406, international |
|  |  | Passcode: 59923512 |
| Webcast: |  | http://investor.fabrinet.com (live and replay) |

[0001193125-17-263714:8k_2_02:34]
This press release and any other information related to the call will also be posted on Fabrinet’s website at
http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-17-263714:8k_2_02:35]
About Fabrinet

[0001193125-17-263714:8k_2_02:36]
Fabrinet is a leading provider of
advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive
components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain
management, manufacturing, advanced packaging, integration, final assembly and test. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in
Thailand, the United States of America, the People’s Republic of China and the United Kingdom. For more information visit: www.fabrinet.com.

[0001193125-17-263714:8k_2_02:37]
Forward-Looking Statements

[0001193125-17-263714:8k_2_02:38]
Use of Non-GAAP Financials

[0001193125-17-263714:8k_2_02:39]
The Company refers to the
non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding the Company’s ongoing operational performance. Non-GAAP net income excludes share-based compensation
expenses, depreciation of fair value uplift, costs resulting from a non-recurring warranty charge, executive separation costs, expenses related to our CEO search, debt administration expenses, amortization of intangibles, business combination
expenses, income related to flooding, gain or loss on foreign currency contracts, amortization of debt issuance costs and non-recurring income tax expense. We have excluded these items in order to enhance investors’ understanding of our
underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these
material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001193125-17-263714:8k_2_02:40]
These non-GAAP financial measures are used
to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making
financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001193125-17-263714:8k_2_02:41]
SOURCE: Fabrinet

[0001193125-17-263714:8k_2_02:42]
Investor Contact:

[0001193125-17-263714:8k_2_02:43]
Garo Toomajanian

[0001193125-17-263714:8k_2_02:44]
ir@fabrinet.com

[0001193125-17-263714:8k_2_02:45]
FABRINET

[0001193125-17-263714:8k_2_02:46]
CONSOLIDATED BALANCE SHEETS

[0001193125-17-263714:8k_2_02:47]
| (in thousands of U.S. dollars, except share data) |  | June 30,2017 |  |  | June 24,2016 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 133,825 |  |  | $ | 142,804 |  |
| Marketable securities |  |  | 151,450 |  |  |  | 141,709 |  |
| Trade accounts receivable, net |  |  | 264,349 |  |  |  | 196,145 |  |
| Inventory, net |  |  | 238,665 |  |  |  | 181,499 |  |
| Deferred tax assets |  |  | — |  |  |  | 1,358 |  |
| Prepaid expenses |  |  | 6,306 |  |  |  | 3,114 |  |
| Other current assets |  |  | 4,159 |  |  |  | 6,662 |  |
| Total current assets |  |  | 798,754 |  |  |  | 673,291 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Restricted cash in connection with business acquisition |  |  | 3,312 |  |  |  | — |  |
| Property, plant and equipment, net |  |  | 216,881 |  |  |  | 178,410 |  |
| Intangibles, net |  |  | 5,840 |  |  |  | 499 |  |
| Goodwill |  |  | 3,806 |  |  |  | — |  |
| Deferred tax assets |  |  | 2,905 |  |  |  | 1,806 |  |
| Deferred debt issuance costs on revolving loan and other non-current assets |  |  | 1,577 |  |  |  | 1,851 |  |
| Total non-current assets |  |  | 234,321 |  |  |  | 182,566 |  |
| Total Assets |  | $ | 1,033,075 |  |  | $ | 855,857 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Bank borrowings, net of unamortized debt issuance costs |  | $ | 48,402 |  |  | $ | 24,307 |  |
| Trade accounts payable |  |  | 215,262 |  |  |  | 172,052 |  |
| Fixed assets payable |  |  | 8,141 |  |  |  | 20,628 |  |
| Capital lease liability, current portion |  |  | 344 |  |  |  | — |  |
| Income tax payable |  |  | 1,976 |  |  |  | 2,010 |  |
| Accrued payroll, bonus and related expenses |  |  | 13,852 |  |  |  | 12,300 |  |
| Accrued expenses |  |  | 9,227 |  |  |  | 8,072 |  |
| Other payables |  |  | 14,068 |  |  |  | 16,356 |  |
| Total current liabilities |  |  | 311,272 |  |  |  | 255,725 |  |
| Non-current liabilities |  |  |  |  |
| Long-term loan from bank, net of unamortized debt issuance costs |  |  | 22,701 |  |  |  | 36,100 |  |
| Deferred tax liability |  |  | 1,981 |  |  |  | 854 |  |
| Capital lease liability, non-current portion |  |  | 1,024 |  |  |  | — |  |
| Deferred liability in connection with business acquisition |  |  | 3,312 |  |  |  | — |  |
| Severance liabilities |  |  | 8,488 |  |  |  | 6,684 |  |
| Other non-current liabilities |  |  | 2,723 |  |  |  | 2,075 |  |
| Total non-current liabilities |  |  | 40,229 |  |  |  | 45,713 |  |
| Total Liabilities |  |  | 351,501 |  |  |  | 301,438 |  |
| Commitments and contingencies (Note 19) |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of June 30, 2017 and June 24, 2016) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 37,340,496 shares a |  |  |  |  |  |  |  |  |
| 36,156,446 shares issued and outstanding as of June 30, 2017 and June 24, 2016, respectively) |  |  | 373 |  |  |  | 362 |  |
| Additional paid-in capital |  |  | 133,293 |  |  |  | 102,325 |  |
| Accumulated other comprehensive (loss) income |  |  | (348 | ) |  |  | 591 |  |
| Retained earnings |  |  | 548,256 |  |  |  | 451,141 |  |
| Total Shareholders’ Equity |  |  | 681,574 |  |  |  | 554,419 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 1,033,075 |  |  | $ | 855,857 |  |

[0001193125-17-263714:8k_2_02:48]
FABRINET

[0001193125-17-263714:8k_2_02:49]
CONSOLIDATED STATEMENT OF OPERATIONS AND COMPREHENSIVE INCOME

[0001193125-17-263714:8k_2_02:50]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
| (in thousands of U.S. dollars, except per share data) |  | June 30,2017 |  |  | June 24,2016 |  |  | June 30,2017 |  |  | June 24,2016 |  |
| Revenues |  | $ | 370,454 |  |  | $ | 276,388 |  |  | $ | 1,420,490 |  |  | $ | 976,747 |  |
| Cost of revenues |  |  | (325,694 | ) |  |  | (242,546 | ) |  |  | (1,249,030 | ) |  |  | (857,224 | ) |
| Gross profit |  |  | 44,760 |  |  |  | 33,842 |  |  |  | 171,460 |  |  |  | 119,523 |  |
| Selling, general and administrative expenses |  |  | (15,057 | ) |  |  | (11,839 | ) |  |  | (65,626 | ) |  |  | (49,753 | ) |
| Other income relating to flooding |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 36 |  |
| Operating income |  |  | 29,703 |  |  |  | 22,003 |  |  |  | 105,834 |  |  |  | 69,806 |  |
| Interest income |  |  | 507 |  |  |  | 425 |  |  |  | 1,977 |  |  |  | 1,535 |  |
| Interest expense |  |  | (804 | ) |  |  | (413 | ) |  |  | (3,321 | ) |  |  | (1,569 | ) |
| Foreign exchange loss, net |  |  | (1,042 | ) |  |  | (670 | ) |  |  | (1,142 | ) |  |  | (1,916 | ) |
| Other income |  |  | 112 |  |  |  | 110 |  |  |  | 509 |  |  |  | 376 |  |
| Income before income taxes |  |  | 28,476 |  |  |  | 21,455 |  |  |  | 103,857 |  |  |  | 68,232 |  |
| Income tax expense |  |  | (1,075 | ) |  |  | (1,786 | ) |  |  | (6,742 | ) |  |  | (6,335 | ) |
| Net income |  |  | 27,401 |  |  |  | 19,669 |  |  |  | 97,115 |  |  |  | 61,897 |  |
| Other comprehensive income (loss), net of tax adjustment |  |  | 645 |  |  |  | (156 | ) |  |  | (939 | ) |  |  | 635 |  |
| Net comprehensive income |  | $ | 28,046 |  |  | $ | 19,513 |  |  | $ | 96,176 |  |  | $ | 62,532 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.73 |  |  | $ | 0.55 |  |  | $ | 2.63 |  |  | $ | 1.73 |  |
| Diluted |  | $ | 0.72 |  |  | $ | 0.53 |  |  | $ | 2.57 |  |  | $ | 1.68 |  |
| Weighted average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 37,334 |  |  |  | 36,075 |  |  |  | 36,927 |  |  |  | 35,858 |  |
| Diluted |  |  | 38,118 |  |  |  | 37,259 |  |  |  | 37,852 |  |  |  | 36,872 |  |

[0001193125-17-263714:8k_2_02:51]
FABRINET

[0001193125-17-263714:8k_2_02:52]
CONSOLIDATED STATEMENTS OF SHAREHOLDERS’ EQUITY

[0001193125-17-263714:8k_2_02:53]
|  |  | Ordinary Share |  |  | AdditionalPaid-inCapital |  |  | AccumulatedOtherComprehensiveIncome (Loss) |  |  | RetainedEarnings |  |  | Total |  |
| (in thousands of U.S. dollars, except share data) |  | Shares |  |  | Amount |  |  |  |  |  |
| Balances at June 27, 2014 |  |  | 35,152,772 |  |  |  | 352 |  |  |  | 80,882 |  |  |  | — |  |  |  | 345,602 |  |  |  | 426,836 |  |
| Net income |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 43,642 |  |  |  | 43,642 |  |
| Other comprehensive loss |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (44 | ) |  |  | — |  |  |  | (44 | ) |
| Share-based compensation expense |  |  | — |  |  |  | — |  |  |  | 8,027 |  |  |  | — |  |  |  | — |  |  |  | 8,027 |  |
| Issuance of ordinary shares |  |  | 284,882 |  |  |  | 2 |  |  |  | 833 |  |  |  | — |  |  |  | — |  |  |  | 835 |  |
| Tax withholdings related to net share settlement of restricted share units |  |  | — |  |  |  | — |  |  |  | (352 | ) |  |  | — |  |  |  | — |  |  |  | (352 | ) |
| Balances at June 26, 2015 |  |  | 35,437,654 |  |  |  | 354 |  |  |  | 89,390 |  |  |  | (44 | ) |  |  | 389,244 |  |  |  | 478,944 |  |
| Net income |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 61,897 |  |  |  | 61,897 |  |
| Other comprehensive income |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 635 |  |  |  | — |  |  |  | 635 |  |
| Share-based compensation expense |  |  | — |  |  |  | — |  |  |  | 9,927 |  |  |  | — |  |  |  | — |  |  |  | 9,927 |  |
| Issuance of ordinary shares |  |  | 718,792 |  |  |  | 8 |  |  |  | 5,471 |  |  |  | — |  |  |  | — |  |  |  | 5,479 |  |
| Tax withholdings related to net share settlement of restricted share units |  |  | — |  |  |  | — |  |  |  | (2,463 | ) |  |  | — |  |  |  | — |  |  |  | (2,463 | ) |
| Balances at June 24, 2016 |  |  | 36,156,446 |  |  |  | 362 |  |  |  | 102,325 |  |  |  | 591 |  |  |  | 451,141 |  |  |  | 554,419 |  |
| Net income |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 97,115 |  |  |  | 97,115 |  |
| Other comprehensive loss |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (939 | ) |  |  | — |  |  |  | (939 | ) |
| Share-based compensation expense |  |  | — |  |  |  | — |  |  |  | 26,507 |  |  |  | — |  |  |  | — |  |  |  | 26,507 |  |
| Issuance of ordinary shares |  |  | 1,184,050 |  |  |  | 11 |  |  |  | 5,886 |  |  |  | — |  |  |  | — |  |  |  | 5,897 |  |
| Tax withholdings related to net share settlement of restricted share units |  |  | — |  |  |  | — |  |  |  | (1,425 | ) |  |  | — |  |  |  | — |  |  |  | (1,425 | ) |
| Balances at June 30, 2017 |  |  | 37,340,496 |  |  |  | 373 |  |  |  | 133,293 |  |  |  | (348 | ) |  |  | 548,256 |  |  |  | 681,574 |  |

[0001193125-17-263714:8k_2_02:54]
FABRINET

[0001193125-17-263714:8k_2_02:55]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-17-263714:8k_2_02:56]
| (in thousands of U. S. dollars) |  | June 30,2017 |  |  | June 24,2016 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income for the year |  | $ | 97,115 |  |  | $ | 61,897 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 23,793 |  |  |  | 17,357 |  |
| Gain on disposal of property, plant and equipment |  |  | (30 | ) |  |  | (73 | ) |
| Loss from sales and maturities of marketable securities |  |  | 822 |  |  |  | 194 |  |
| Amortization of investment (discount) premium |  |  | (193 | ) |  |  | 798 |  |
| Amortization of deferred debt issuance costs |  |  | 1,396 |  |  |  | 758 |  |
| Income related to flooding |  |  | — |  |  |  | (828 | ) |
| Proceeds from insurers in settlement of claim related to flood damage |  |  | — |  |  |  | 272 |  |
| (Reversal of) allowance for doubtful accounts |  |  | (1 | ) |  |  | (17 | ) |
| Unrealized loss on exchange rate and fair value of derivative |  |  | 1,884 |  |  |  | 1,905 |  |
| Share-based compensation |  |  | 26,507 |  |  |  | 9,927 |  |
| Deferred income tax |  |  | 754 |  |  |  | 864 |  |
| Other non-cash expenses |  |  | 2,173 |  |  |  | 1,744 |  |
| Inventory obsolescence (reversal of) |  |  | 42 |  |  |  | (521 | ) |
| Loss from written-off inventory due to flood loss |  |  | — |  |  |  | 233 |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | (64,142 | ) |  |  | (61,013 | ) |
| Inventory |  |  | (53,802 | ) |  |  | (50,598 | ) |
| Other current assets and non-current assets |  |  | (2,231 | ) |  |  | (5,901 | ) |
| Trade accounts payable |  |  | 38,293 |  |  |  | 56,308 |  |
| Income tax payable |  |  | (67 | ) |  |  | 573 |  |
| Other current liabilities and non-current liabilities |  |  | (1,379 | ) |  |  | 13,209 |  |
| Net cash provided by operating activities |  |  | 70,934 |  |  |  | 47,088 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of marketable securities |  |  | (122,778 | ) |  |  | (108,341 | ) |
| Proceeds from sales of marketable securities |  |  | 39,578 |  |  |  | 41,836 |  |
| Proceeds from maturities of marketable securities |  |  | 72,361 |  |  |  | 67,113 |  |
| Payments in connection with business acquisition, net of cash acquired |  |  | (9,917 | ) |  |  | — |  |
| Purchase of property, plant and equipment |  |  | (68,262 | ) |  |  | (40,616 | ) |
| Gain on cash settlement of hedged forward contracts |  |  | — |  |  |  | 34 |  |
| Proceeds from disposal of property, plant and equipment |  |  | 230 |  |  |  | 194 |  |
| Purchase of intangibles |  |  | (1,768 | ) |  |  | (379 | ) |
| Proceeds from insurers in settlement of claims related to flood damage |  |  | — |  |  |  | 556 |  |
| Net cash used in investing activities |  |  | (90,556 | ) |  |  | (39,603 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Payment of debt issuance costs |  |  | — |  |  |  | (654 | ) |
| Proceeds of short-term loan from bank |  |  | 27,500 |  |  |  | 18,000 |  |
| Repayment of short-term loan from bank |  |  | (157 | ) |  |  | (41,500 | ) |
| Proceeds of long-term loan from bank |  |  | — |  |  |  | 50,000 |  |
| Repayment of long-term loan from bank |  |  | (18,100 | ) |  |  | (6,000 | ) |
| Proceeds from issuance of ordinary shares under employee share option plan |  |  | 5,890 |  |  |  | 5,479 |  |
| Repayment of capital lease liability |  |  | (276 | ) |  |  | — |  |
| Withholding tax related to net share settlement of restricted share units |  |  | (1,425 | ) |  |  | (2,463 | ) |
| Net cash provided by financing activities |  |  | 13,432 |  |  |  | 22,862 |  |
| Net (decrease) increase in cash, cash equivalents and restricted cash |  | $ | (6,190 | ) |  | $ | 30,347 |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  | $ | 142,804 |  |  | $ | 112,978 |  |
| (Decrease) increase in cash, cash equivalents and restricted cash |  |  | (6,190 | ) |  |  | 30,347 |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash |  |  | 523 |  |  |  | (521 | ) |
| Cash, cash equivalents and restricted cash at end of period |  | $ | 137,137 |  |  | $ | 142,804 |  |

[0001193125-17-263714:8k_2_02:57]
FABRINET

[0001193125-17-263714:8k_2_02:58]
CONSOLIDATED STATEMENTS OF CASH FLOWS (Continued)

[0001193125-17-263714:8k_2_02:59]
| (in thousands of U. S. dollars) |  | June 30,2017 |  |  | June 24,2016 |  |
| Supplemental disclosures |  |  |  |  |  |  |  |  |
| Cash paid for |  |  |  |  |
| Interest |  | $ | 1,924 |  |  | $ | 1,091 |  |
| Taxes |  | $ | 5,218 |  |  | $ | 5,473 |  |
| Cash received for interest |  | $ | 1,753 |  |  | $ | 1,049 |  |
| Non-cash investing and financing activities |  |  |  |  |
| Construction, software related and equipment related payables |  | $ | 8,434 |  |  | $ | 20,628 |  |

[0001193125-17-263714:8k_2_02:60]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the consolidated
balance sheets that sum to the total of same amounts shown in the consolidated statements of cash flows:

[0001193125-17-263714:8k_2_02:61]
| (in thousands of U. S. dollars) |  | June 30,2017 |  |  | June 24,2016 |  |
| Cash and cash equivalents |  | $ | 133,825 |  |  | $ | 142,804 |  |
| Restricted cash in connection with business acquisition (non-current assets) |  |  | 3,312 |  |  |  | — |  |
| Cash, cash equivalents and restricted cash |  | $ | 137,137 |  |  | $ | 142,804 |  |

[0001193125-17-263714:8k_2_02:62]
FABRINET

[0001193125-17-263714:8k_2_02:63]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-17-263714:8k_2_02:64]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | June 30, 2017 |  |  | June 24, 2016 |  |  | June 30, 2017 |  |  | June 24, 2016 |  |
| (in thousands of U.S. dollars, except per share data) |  | Netincome |  |  | Diluted EPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |
| GAAP measures |  |  | 27,401 |  |  |  | 0.72 |  |  |  | 19,669 |  |  |  | 0.53 |  |  |  | 97,115 |  |  |  | 2.57 |  |  |  | 61,897 |  |  |  | 1.68 |  |
| Items reconciling GAAP net (loss) income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,133 |  |  |  | 0.03 |  |  |  | 385 |  |  |  | 0.01 |  |  |  | 5,318 |  |  |  | 0.14 |  |  |  | 1,979 |  |  |  | 0.05 |  |
| Depreciation of fair value uplift |  |  | 80 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |  |  | 147 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |
| Cost resulting from a non-recurring warranty charge |  |  | — |  |  |  | — |  |  |  | 1,000 |  |  |  | 0.03 |  |  |  | — |  |  |  | — |  |  |  | 1,000 |  |  |  | 0.03 |  |
| Total related to gross profit |  |  | 1,213 |  |  |  | 0.03 |  |  |  | 1,385 |  |  |  | 0.04 |  |  |  | 5,465 |  |  |  | 0.14 |  |  |  | 2,979 |  |  |  | 0.08 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 3,438 |  |  |  | 0.09 |  |  |  | 1,760 |  |  |  | 0.05 |  |  |  | 21,190 |  |  |  | 0.56 |  |  |  | 7,948 |  |  |  | 0.22 |  |
| Executive separation costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 577 |  |  |  | 0.02 |  |  |  | 1,360 |  |  |  | 0.04 |  |
| Expenses related to CEO search |  |  | 100 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |  |  | 203 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |
| Debt administration expenses |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 320 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |
| Amortization of intangibles |  |  | 199 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 607 |  |  |  | 0.02 |  |  |  | — |  |  |  | — |  |
| Business combination expenses |  |  | 160 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |  |  | 1,790 |  |  |  | 0.05 |  |  |  | — |  |  |  | — |  |
| Total related to selling, general and administrative expenses |  |  | 3,897 |  |  |  | 0.10 |  |  |  | 1,760 |  |  |  | 0.05 |  |  |  | 24,687 |  |  |  | 0.65 |  |  |  | 9,308 |  |  |  | 0.25 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income related to flooding |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (36 | ) |  |  | (0.00 | ) |
| Loss (gain) on foreign currency contracts |  |  | — |  |  |  | — |  |  |  | (581 | ) |  |  | (0.02 | ) |  |  | (1,713 | ) |  |  | (0.05 | ) |  |  | 1,715 |  |  |  | 0.05 |  |
| Amortization of debt issuance costs |  |  | 257 |  |  |  | 0.01 |  |  |  | 203 |  |  |  | 0.01 |  |  |  | 1,884 |  |  |  | 0.05 |  |  |  | 745 |  |  |  | 0.02 |  |
| Total related to other incomes and other expenses |  |  | 257 |  |  |  | 0.01 |  |  |  | (378 | ) |  |  | (0.01 | ) |  |  | 171 |  |  |  | 0.00 |  |  |  | 2,424 |  |  |  | 0.07 |  |
| Related to income tax expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-recurring income tax expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,119 |  |  |  | — |  |
| Total related to income tax expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,119 |  |  |  | 0.03 |  |
| Total related to net income & EPS |  |  | 5,367 |  |  |  | 0.14 |  |  |  | 2,767 |  |  |  | 0.07 |  |  |  | 30,323 |  |  |  | 0.80 |  |  |  | 15,830 |  |  |  | 0.43 |  |
| Non-GAAP measures |  |  | 32,768 |  |  |  | 0.86 |  |  |  | 22,436 |  |  |  | 0.60 |  |  |  | 127,438 |  |  |  | 3.37 |  |  |  | 77,727 |  |  |  | 2.11 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 38,118 |  |  |  |  |  |  |  | 37,258 |  |  |  |  |  |  |  | 37,852 |  |  |  |  |  |  |  | 36,872 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 38,118 |  |  |  |  |  |  |  | 37,258 |  |  |  |  |  |  |  | 37,852 |  |  |  |  |  |  |  | 36,872 |  |

[0001193125-17-263714:8k_2_02:65]
FABRINET

[0001193125-17-263714:8k_2_02:66]
GUIDANCE FOR QUARTER ENDING SEPTEMBER 29, 2017

[0001193125-17-263714:8k_2_02:67]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-17-263714:8k_2_02:68]
|  |  | DilutedEPS |
| GAAP net income per diluted share: |  | $0.60 to $0.62 |
| Related to cost of revenues: |  |  |
| Share-based compensation expenses |  | 0.04 |
| Total related to gross profit |  | 0.04 |
| Related to selling, general and administrative expenses: |  |  |
| Share-based compensation expenses |  | 0.12 |
| Amortization of intangibles |  | 0.01 |
| Total related to selling, general and administrative expenses |  | 0.13 |
| Related to other incomes and other expenses: |  |  |
| Amortization of debt issuance costs |  | 0.01 |
| Total related to net income & EPS |  | 0.18 |
| Non-GAAP net income per diluted share |  | $0.78 to $0.80 |
