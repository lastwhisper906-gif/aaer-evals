# FN notes — 0001193125-17-265630


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-17-265630:notes:1]
The following
 table summarizes the cost and estimated fair value of marketable
 securities classified as available-for-sale securities based on
 stated effective maturities as of June 30, 2017:

[0001193125-17-265630:notes:2]
| (amount in thousands) |  | Carrying Cost |  |  | Fair Value |  |
| Due within one year |  | $ | 14,369 |  |  | $ | 14,363 |  |
| Due between one to three years |  |  | 133,634 |  |  |  | 133,574 |  |
| Due after three years |  |  | 3,519 |  |  |  | 3,513 |  |
| Total |  | $ | 151,522 |  |  | $ | 151,450 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001193125-17-265630:notes:3]
Cash and
 cash equivalents

[0001193125-17-265630:notes:4]
All highly
 liquid investments with original maturities of three months or less
 at the date of purchase are classified as cash equivalents. Cash
 and cash equivalents consist of cash deposited in checking
 accounts, time deposits with maturities of less than three months,
 money market accounts, and marketable securities with maturities of
 three months or less at the date of purchase.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-17-265630:notes:5]
| 19. | Commitments and contingencies |

[0001193125-17-265630:notes:6]
Bank
 guarantees

[0001193125-17-265630:notes:7]
As of
 June 30, 2017 and June 24, 2016, there were outstanding
 bank guarantees given by a bank on behalf of our subsidiary in
 Thailand for electricity usage and other normal business amounting
 to $1.5 and $0.8 million, respectively.

[0001193125-17-265630:notes:8]
Operating lease commitments

[0001193125-17-265630:notes:9]
The Company
 leases a portion of its capital equipment, vehicle, and certain
 land and buildings for its facilities in Thailand, Cayman Islands,
 China, the United States and the United Kingdom under operating
 lease arrangements that expire in various years through 2023.
 Rental expense under these operating leases amounted to $1.7
 million, $1.2 million and $1.1 million for the years ended
 June 30, 2017, June 24, 2016 and June 26, 2015,
 respectively.

[0001193125-17-265630:notes:10]
As of
 June 30, 2017, the future minimum lease payments due under
 non-cancelable operating leases during each fiscal year were as
 follows:

[0001193125-17-265630:notes:11]
| (amount in thousands) |  |  |  |
| 2018 |  | $ | 1,744 |  |
| 2019 |  |  | 1,162 |  |
| 2020 |  |  | 946 |  |
| 2021 |  |  | 540 |  |
| 2022 |  |  | 416 |  |
| Thereafter |  |  | 520 |  |
| Total future minimum operating lease payments |  | $ | 5,328 |  |

[0001193125-17-265630:notes:12]
Capital
 lease commitments

[0001193125-17-265630:notes:13]
In connection
 with the acquisition of Exception EMS, the Company assumed the
 capital lease commitments of several machines and equipment, with
 various expiration dates until September 2020. The equipment can be
 purchased at the determined prices upon expiration of such
 contracts.

[0001193125-17-265630:notes:14]
As of
 June 30, 2017, the future minimum lease payments under
 non-cancelable capital leases during each fiscal year were as
 follows:

[0001193125-17-265630:notes:15]
| (amount in thousands) |  |  |  |
| 2018 |  | $ | 466 |  |
| 2019 |  |  | 479 |  |
| 2020 |  |  | 422 |  |
| 2021 |  |  | 105 |  |
| Total |  |  | 1,472 |  |
| Less: Future finance charge on capital leases |  |  | (104 | ) |
| Present value of capital lease |  | $ | 1,368 |  |

[0001193125-17-265630:notes:16]
Representing
 capital lease liabilities

[0001193125-17-265630:notes:17]
| Current |  | $ | 344 |  |
| Non-current |  |  | 1,024 |  |
| Total capital lease liabilities |  | $ | 1,368 |  |

[0001193125-17-265630:notes:18]
As of
 June 30, 2017, the present value of capital lease during each
 fiscal year were as follows:

[0001193125-17-265630:notes:19]
| (amount in thousands) |  |  |  |
| 2018 |  | $ | 344 |  |
| 2019 |  |  | 510 |  |
| 2020 |  |  | 409 |  |
| 2021 |  |  | 105 |  |
| Total future minimum capital lease payments |  | $ | 1,368 |  |

[0001193125-17-265630:notes:20]
Purchase obligations

[0001193125-17-265630:notes:21]
Purchase
 obligations represent legally-binding commitments to purchase
 inventory and other commitments made in the normal course of
 business to meet operational requirements. Although open purchase
 orders are considered enforceable and legally binding, their terms
 generally give the Company the option to cancel, reschedule and/or
 adjust its requirements based on its business needs prior to the
 delivery of goods or performance of services. Obligations to
 purchase inventory and other commitments are generally expected to
 be fulfilled within one year.

[0001193125-17-265630:notes:22]
On
 December 23, 2016, the Company entered into an agreement to
 purchase a parcel of land in Chonburi, Thailand, to support the
 expansion of the Company’s production in Thailand. The
 aggregate purchase price is approximately $5.6 million, of which
 the first installment of $1.1 million was paid by the Company on
 January 10, 2017. The Company expects to pay the remaining
 balance of the purchase price on or before December 25,
 2017.

[0001193125-17-265630:notes:23]
As of
 June 30, 2017, the Company had an outstanding commitment to
 third parties of $10.6 million, of which $4.5 million was from the
 commitment to purchase land in Chonburi, Thailand.

[0001193125-17-265630:notes:24]
Indemnification of directors and
 officers

[0001193125-17-265630:notes:25]
Cayman
 Islands law does not limit the extent to which a company’s
 memorandum and articles of association may provide for
 indemnification of directors and officers, except to the extent any
 such provision may be held by the Cayman Islands courts to be
 contrary to public policy, such as to provide indemnification
 against civil fraud or the consequences of committing a crime.
 Fabrinet’s amended and restated memorandum and articles of
 association provide for indemnification of directors and officers
 for actions, costs, charges, losses, damages and expenses incurred
 in their capacities as such, except that such indemnification does
 not extend to any matter in respect of any fraud or dishonesty that
 may attach to any of them.

[0001193125-17-265630:notes:26]
In accordance
 with Fabrinet’s form of indemnification agreement for its
 directors and officers, Fabrinet has agreed to indemnify its
 directors and officers against certain liabilities and expenses
 incurred by such persons in connection with claims by reason of
 their being such a director or officer. Fabrinet maintains a
 director and officer liability insurance policy that may enable it
 to recover a portion of any future amounts paid under the
 indemnification agreements.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-17-265630:notes:27]
| 15. | Share-based compensation |

[0001193125-17-265630:notes:28]
Share-based compensation

[0001193125-17-265630:notes:29]
In determining
 the fair value of share option awards, the Company is required to
 make estimates of expected dividends to be issued, expected
 volatility of Fabrinet’s ordinary shares, expected
 forfeitures of the awards, risk free interest rates for the
 expected term of the awards and expected terms of the awards.
 Forfeitures are estimated at the time of grant and revised if
 necessary in subsequent periods if actual forfeitures differ from
 those estimates. The fair value of restricted share units is based
 on the market value of our ordinary shares on the date of
 grant.

[0001193125-17-265630:notes:30]
The effect of
 recording share-based compensation expense for the years ended
 June 30, 2017, June 24, 2016 and June 26, 2015
 was as follows:

[0001193125-17-265630:notes:31]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 30, 2017 |  |  | June 24, 2016 |  |  | June 26, 2015 |  |
| Share-based compensation expense by type of award: |  |  |  |  |
| Share options |  | $ | — |  |  | $ | 16 |  |  | $ | 226 |  |
| Restricted share units |  |  | 22,412 |  |  |  | 9,911 |  |  |  | 7,801 |  |
| Performance share units |  |  | 4,095 |  |  |  | — |  |  |  | — |  |
| Total share-based compensation expense |  |  | 26,507 |  |  |  | 9,927 |  |  |  | 8,027 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 26,507 |  |  | $ | 9,927 |  |  | $ | 8,027 |  |

[0001193125-17-265630:notes:32]
Share-based
 compensation expense was recorded in the consolidated statements of
 operations and comprehensive income as follows:

[0001193125-17-265630:notes:33]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 30, 2017 |  |  | June 24, 2016 |  |  | June 26, 2015 |  |
| Cost of revenue |  | $ | 5,318 |  |  | $ | 1,979 |  |  | $ | 1,450 |  |
| Selling, general and administrative expense |  |  | 21,189 |  |  |  | 7,948 |  |  |  | 6,577 |  |
| Total share-based compensation expense |  | $ | 26,507 |  |  | $ | 9,927 |  |  | $ | 8,027 |  |

[0001193125-17-265630:notes:34]
The Company did
 not capitalize any share-based compensation expense as part of any
 asset costs during the years ended June 30,
 2017, June 24, 2016 and June 26, 2015.

[0001193125-17-265630:notes:35]
Share-based award activity

[0001193125-17-265630:notes:36]
Share options
 have been granted to directors and employees. As of June 30,
 2017, there were no share options outstanding under
 Fabrinet’s Amended and Restated 1999 Share Option Plan
 (“1999 Plan”). Additional option grants may not be made
 under the 1999 Plan.

[0001193125-17-265630:notes:37]
As of
 June 30, 2017, there were an aggregate of 96,688 share options
 outstanding, 1,058,605 restricted share units outstanding and
 227,268 performance share units outstanding under Fabrinet’s
 2010 Performance Incentive Plan (“2010 Plan”). As of
 June 30, 2017, there were 1,111,573 ordinary shares available
 for future grant under Fabrinet’s 2010 Performance Incentive
 Plan (“2010 Plan”). The 1999 Plan and 2010 Plan are
 collectively referred to as the “Share Option
 Plans”.

[0001193125-17-265630:notes:38]
Share
 options

[0001193125-17-265630:notes:39]
Fabrinet’s board of directors has the authority to
 determine the type of option and the number of shares subject to an
 option. Options generally vest and become exercisable over four
 years and expire, if not exercised, within seven years of the grant
 date. In the case of a grantee’s first grant, 25 percent of
 the underlying shares subject to an option vest 12 months after the
 vesting commencement date and 1/48 of the underlying shares vest
 monthly over each of the subsequent 36 months. In the case of any
 additional grants to a grantee, 1/48 of the underlying shares
 subject to an option vest monthly over four years, commencing one
 month after the vesting commencement date.

[0001193125-17-265630:notes:40]
The following
 table summarizes share options activity:

[0001193125-17-265630:notes:41]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 27, 2014 |  |  | 865,890 |  |  |  | 666,305 |  |  | $ | 16.27 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (56,968 | ) |  |  |  |  |  | $ | 14.67 |  |  |  |  |  |
| Forfeited |  |  | (8,347 | ) |  |  |  |  |  | $ | 15.90 |  |  |  |  |  |
| Expired |  |  | (8,556 | ) |  |  |  |  |  | $ | 21.44 |  |  |  |  |  |
| Balance as of June 26, 2015 |  |  | 792,019 |  |  |  | 758,451 |  |  | $ | 16.33 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (325,530 | ) |  |  |  |  |  | $ | 16.83 |  |  |  |  |  |
| Forfeited |  |  | (755 | ) |  |  |  |  |  | $ | 17.10 |  |  |  |  |  |
| Expired |  |  | (1,400 | ) |  |  |  |  |  | $ | 23.62 |  |  |  |  |  |
| Balance as of June 24, 2016 |  |  | 464,334 |  |  |  | 464,334 |  |  | $ | 15.95 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (367,641 | ) |  |  |  |  |  | $ | 16.02 |  |  |  |  |  |
| Forfeited |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Expired |  |  | (5 | ) |  |  |  |  |  | $ | 5.75 |  |  |  |  |  |
| Balance as of June 30, 2017 |  |  | 96,688 |  |  |  | 96,688 |  |  | $ | 15.70 |  |  |  |  |  |
| Expected to vest as of June 30, 2017 |  |  | 96,688 |  |  |  |  |  |  | $ | 15.70 |  |  |  |  |  |

[0001193125-17-265630:notes:42]
The fair value
 of each share option grant was determined by the Company using the
 methods and assumptions discussed below. Each of these inputs is
 subjective and generally requires significant judgment and
 management estimate to determine.

[0001193125-17-265630:notes:43]
The total fair
 value of share options vested during the years ended June 30,
 2017, June 24, 2016 and June 26, 2015 was nil, $0.2
 million and $1.1 million, respectively. The total intrinsic value
 of options exercised during the years ended June 30,
 2017 June 24, 2016 and June 26, 2015 was $8.9
 million, $3.6 million and $0.2 million, respectively. In
 conjunction with these exercises, there was no tax benefit realized
 by the Company due to the fact that it is exempted from income tax.
 The amount of cash received from the exercise of share options was
 $5.9 million during the year ended June 30, 2017.

[0001193125-17-265630:notes:44]
Valuation
 Method—The Company estimated the fair value of the
 Company’s ordinary shares to be used in the BSM by taking
 into consideration a number of assumptions, as discussed
 below.

[0001193125-17-265630:notes:45]
Expected
 Dividend—The Company used zero as an annualized dividend
 yield since it did not anticipate paying any cash dividends in the
 near future.

[0001193125-17-265630:notes:46]
Expected
 Volatility – The Company determined the expected
 volatility based on the Company’s historical volatility over
 the last four years.

[0001193125-17-265630:notes:47]
Risk-Free
 Interest Rate—The Company based the risk-free interest
 rate on the implied yield currently available on U.S. Treasury
 zero-coupon issues with a remaining term equivalent to the expected
 term of the option.

[0001193125-17-265630:notes:48]
Expected
 Term—Expected terms used in the BSM represent the periods
 that the company’s share options are expected to be
 outstanding and are determined based on the Company’s
 historical experience of similar awards, giving consideration to
 the contractual terms of the share options, vesting schedules and
 expectations of future employee behavior.

[0001193125-17-265630:notes:49]
Vesting
 Period—Fabrinet’s share options generally vest and
 become exercisable over a four-year period, and expire seven years
 from the date of grant. For an initial grant, 25 percent of the
 underlying shares subject to an option vest 12 months after the
 vesting commencement date and 1/48 of the underlying shares vest
 monthly over each of the subsequent 36 months. In the case of any
 additional grants to an optionee, 1/48 of the underlying shares
 subject to an option vest monthly over four years, commencing one
 month after the vesting commencement date.

[0001193125-17-265630:notes:50]
Fair
 Value—The fair value of Fabrinet’s share options
 granted to employees was estimated using the weighted-average for
 each assumption of expected volatility, risk-free rate of return,
 and expected term.

[0001193125-17-265630:notes:51]
The following
 table summarizes information for share options outstanding as of
 June 30, 2017 under the Share Option Plans:

[0001193125-17-265630:notes:52]
|  |  | Number of Shares Underlying Options |  |  | Exercise Price Per Share |  |  | Weighted Average Remaining Contractual Life (years) |  |  | Aggregate Intrinsic Value (amount in thousands) |  |
|  |  |  | 25,238 |  |  | $ | 14.12 |  |  |  | 1.36 |  |  |  |  |  |
|  |  |  | 30,000 |  |  | $ | 15.05 |  |  |  | 0.35 |  |  |  |  |  |
|  |  |  | 6,100 |  |  | $ | 15.16 |  |  |  | 1.13 |  |  |  |  |  |
|  |  |  | 28,300 |  |  | $ | 16.83 |  |  |  | 0.29 |  |  |  |  |  |
|  |  |  | 5,550 |  |  | $ | 18.60 |  |  |  | 1.67 |  |  |  |  |  |
|  |  |  | 1,500 |  |  | $ | 25.50 |  |  |  | 0.54 |  |  |  |  |  |
| Options outstanding |  |  | 96,688 |  |  |  |  |  |  |  | 0.72 |  |  | $ | 2,607 |  |
| Options exercisable |  |  | 96,688 |  |  |  |  |  |  |  | 0.72 |  |  | $ | 2,607 |  |
| Expected to vest as of June 30, 2017 |  |  | 96,688 |  |  |  |  |  |  |  | 0.72 |  |  | $ | 2,607 |  |

[0001193125-17-265630:notes:53]
As of
 June 30, 2017, there was no unrecognized compensation cost
 under the Share Option Plans.

[0001193125-17-265630:notes:54]
Restricted
 share units and performance share units

[0001193125-17-265630:notes:55]
Restricted
 share units are one type of share-based award that may be granted
 under the 2010 Plan. Restricted share units granted to non-employee
 directors generally cliff vest 100% on the first of January,
 approximately one year from the grant date, provided the director
 continues to serve through such date. Restricted share units
 granted to employees generally vest in four equal installments over
 four years on each anniversary of the vesting commencement
 date.

[0001193125-17-265630:notes:56]
Performance
 share units granted to executives will vest at the end of a
 two-year performance period based on the Company’s
 achievement of pre-defined performance criteria, which consist of
 revenue and gross margin targets. The actual number
 of performance share units that may vest at the end of the
 performance period ranges from 0% to 100% of the award
 grant.

[0001193125-17-265630:notes:57]
The Company has
 entered into an employment agreement, as amended on August 12,
 2016, with one executive of the Company that provided for
 accelerated vesting of equity awards under certain circumstances.
 Pursuant to such agreement, because the executive’s
 employment with the Company continued through February 20,
 2017, (1) all outstanding equity awards granted to the
 executive prior to August 2016 became 100% vested on
 February 20, 2017 and (2) certain restricted share units
 granted to the executive in August 2016 became 100% vested on
 February 20, 2017.

[0001193125-17-265630:notes:58]
The following
 table summarizes restricted share unit activity under the 2010
 Plan:

[0001193125-17-265630:notes:59]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 27, 2014 |  |  | 762,295 |  |  | $ | 14.23 |  |
| Granted |  |  | 666,582 |  |  | $ | 17.53 |  |
| Issued |  |  | (247,593 | ) |  | $ | 14.44 |  |
| Forfeited |  |  | (40,357 | ) |  | $ | 16.68 |  |
| Balance as of June 26, 2015 |  |  | 1,140,927 |  |  | $ | 16.03 |  |
| Granted |  |  | 654,589 |  |  | $ | 21.15 |  |
| Issued |  |  | (507,621 | ) |  | $ | 15.60 |  |
| Forfeited |  |  | (106,493 | ) |  | $ | 18.34 |  |
| Balance as of June 24, 2016 |  |  | 1,181,402 |  |  | $ | 18.34 |  |
| Granted |  |  | 861,356 |  |  | $ | 38.95 |  |
| Issued |  |  | (853,535 | ) |  | $ | 21.16 |  |
| Forfeited |  |  | (130,618 | ) |  | $ | 29.31 |  |
| Balance as of June 30, 2017 |  |  | 1,058,605 |  |  | $ | 31.59 |  |
| Expected to vest as of June 30, 2017 |  |  | 1,024,706 |  |  | $ | 31.56 |  |

[0001193125-17-265630:notes:60]
The following
 summarizes performance share unit activity under the 2010
 Plan:

[0001193125-17-265630:notes:61]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 24, 2016 |  |  | — |  |  |  | — |  |
| Granted |  |  | 234,678 |  |  | $ | 40.48 |  |
| Issued |  |  | — |  |  |  | — |  |
| Forfeited |  |  | (7,410 | ) |  |  | — |  |
| Balance as of June 30, 2017 |  |  | 227,268 |  |  | $ | 40.48 |  |
| Expected to vest as of June 30, 2017 |  |  | 227,268 |  |  |  |  |  |

[0001193125-17-265630:notes:62]
The fair value
 of restricted share units and performance share units are based on
 the market value of our ordinary shares on the date of
 grant.

[0001193125-17-265630:notes:63]
The total fair
 value of restricted share units and performance share unit vested
 during the year ended June 30, 2017, June 24, 2016
 and June 26, 2015 was $18.1 million, $7.9 million and $3.6
 million, respectively. The aggregate intrinsic value of restricted
 share units outstanding as of June 30, 2017 was $45.2
 million.

[0001193125-17-265630:notes:64]
As of
 June 30, 2017, there was $16.1 million and $5.1 million of
 unrecognized share-based compensation expense related to restricted
 share units and performance share units, respectively, under the
 2010 Plan that is expected to be recorded over a weighted-average
 period of 2.46 years and 1.13 years, respectively.

[0001193125-17-265630:notes:65]
For the years
 ended June 30, 2017 and June 24, 2016, the Company
 withheld an aggregate of 37,126 shares and 114,359 shares,
 respectively, upon the vesting of restricted share units, based
 upon the closing share price on the vesting date to settle the
 employees’ minimum statutory obligation for the applicable
 income and other employment taxes. For fiscal year 2017 and fiscal
 year 2016, the Company then remitted cash of $1.4 million and $2.5
 million, respectively, to the appropriate taxing authorities, and
 presented it as a financing activity within the consolidated
 statements of cash flows. The payment had the effect on shares
 issued by the Company as it reduced the number of shares that would
 have been issued on the vesting date and was recorded as a
 reduction of additional paid-in capital.


## us-gaap:FairValueInputsAssetsQuantitativeInformationTableTextBlock

[0001193125-17-265630:notes:66]
The fair value
 of the identified intangible assets was determined based on the
 multi-period excess earnings method, which applied the following
 key assumptions:

[0001193125-17-265630:notes:67]
| Risk free rate: |  | 30-year UK Government Bond adjusted by spot yield to reflect recent volatility |
| Long-term revenue growth: |  | 5.0% - 8.0% |
| Churn rate: |  | 10% |
| Operating margin: |  | 4.0% - 6.0% |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-17-265630:notes:68]
| 8. | Inventory |

[0001193125-17-265630:notes:69]
| (amount in thousands) |  | As of June 30, 2017 |  |  | As of June 24, 2016 |  |
| Raw materials |  | $ | 88,640 |  |  | $ | 58,199 |  |
| Work in progress |  |  | 105,732 |  |  |  | 94,762 |  |
| Finished goods |  |  | 33,998 |  |  |  | 21,593 |  |
| Goods in transit |  |  | 13,025 |  |  |  | 9,381 |  |
|  |  |  | 241,395 |  |  |  | 183,935 |  |
| Less: Inventory obsolescence |  |  | (2,730 | ) |  |  | (2,436 | ) |
| Inventory, net |  | $ | 238,665 |  |  | $ | 181,499 |  |


## us-gaap:InventoryPolicyTextBlock

[0001193125-17-265630:notes:70]
Inventory

[0001193125-17-265630:notes:71]
Inventory is
 stated at the lower of cost or market value. Cost is estimated
 using the standard costing method, computed on a first-in,
 first-out basis, with adjustments for variances to reflect actual
 costs not in excess of net realizable market value. Market value is
 the estimated selling price in the ordinary course of business,
 less the costs of completion and selling expenses. The Company
 assesses the valuation of inventory on a quarterly basis and writes
 down the value for estimated excess and obsolete inventory based
 upon estimates of future demand.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-17-265630:notes:72]
New
 Accounting Pronouncements—adopted by the
 Company

[0001193125-17-265630:notes:73]
In November
 2016, the FASB issued ASU 2016-18, “Statement of Cash Flows
 (Topic 230): Restricted Cash,” which requires the statement
 of cash flows to explain the change during the period in the total
 of cash, cash equivalents and restricted cash or restricted cash
 equivalents. The Company has early adopted this update in the
 second quarter of fiscal year 2017 on a retrospective basis but
 there was no impact to the presentation of the comparative period
 in the consolidated financial statements.

[0001193125-17-265630:notes:74]
In November
 2015, the FASB issued ASU 2015-17, “Balance Sheet
 Classification of Deferred Taxes,” which will require
 entities to present deferred tax assets (“DTAs”) and
 deferred tax liabilities (“DTLs”) as non-current in a
 classified balance sheet. The ASU simplifies the current guidance,
 which requires entities to separately present DTAs and DTLs as
 current and non-current in a classified balance sheet. The Company
 has early adopted this update in the first quarter of fiscal year
 2017. The Company adopted this update on a prospective basis and
 did not change the presentation of the comparative
 period.

[0001193125-17-265630:notes:75]
In September
 2015, the FASB issued ASU 2015-16, “Business Combinations
 (Topic 805): Simplifying the Accounting for Measurement-Period
 Adjustments” which require an acquirer to recognize
 adjustments to provisional amounts that are identified during the
 measurement period in the reporting period in which the adjustment
 amounts are determined. The Company adopted this update in the
 first quarter of fiscal year 2017 and applied it on a prospective
 basis. See Footnote 9—Business acquisition, for further
 disclosure on measurement period adjustments recorded in the year
 ended June 30, 2017.

[0001193125-17-265630:notes:76]
In July 2015,
 the FASB issued ASU 2015-11, “Inventory (Topic 330):
 Simplifying the Measurement of Inventory.” The update
 provides the guidance that an entity, that measured inventory by
 using first-in, first-out or average cost, should measure inventory
 at the lower of cost and net realizable value. Subsequent
 measurement is unchanged for inventory measured using last-in,
 first-out or the retail inventory method. The Company adopted this
 update in the first quarter of fiscal year 2017 with no impact to
 the consolidated financial statements.

[0001193125-17-265630:notes:77]
In April 2015,
 the FASB issued ASU 2015-03, “Interest—Imputation of
 Interest (Subtopic 835-30): Simplifying the Presentation of Debt
 Issuance Costs.” The update requires debt issuance costs
 related to a recognized debt liability be presented in the balance
 sheet as a direct deduction from the carrying amount of the related
 debt liability instead of being presented as an asset. Debt
 disclosures will include the face amount of the debt liability and
 the effective interest rate. The update requires retrospective
 application and represents a change in accounting principle.
 Additionally, in August 2015, the FASB issued ASU 2015-15,
 “Interest – Imputation of Interest (Subtopic 835-30):
 Presentation and Subsequent Measurement of Debt Issuance Costs
 Associated with Line-of-Credit Arrangements” to amend ASU
 2015-03. The Company adopted this amendment retrospectively in the
 first quarter of fiscal year 2017. As of June 30, 2017 and
 June 24, 2016, debt issuance costs of $0.3 million and $0.6
 million, respectively, related to a recognized debt liability are
 presented in the balance sheet as a direct reduction of the
 carrying amount of the related debts.

[0001193125-17-265630:notes:78]
In February
 2015, the FASB issued ASU 2015-02, “Consolidation (Topic
 810): Amendments to the Consolidation Analysis.” ASU
 No. 2015-02 amended the process that a reporting entity must
 perform to determine whether it should consolidate certain types of
 legal entities. In the first quarter of fiscal year 2017, the
 Company adopted this update with no impact to the consolidated
 financial statements.

[0001193125-17-265630:notes:79]
In January
 2015, the FASB issued ASU 2015-01, “Income
 Statement—Extraordinary and Unusual Items (Subtopic 225-20):
 Simplifying Income Statement Presentation by Eliminating the
 Concept of Extraordinary Items.” The objective of this
 amendment is to reduce the complexity in accounting standards by
 eliminating the concept of extraordinary items from U.S. GAAP. To
 meet for extraordinary classification the underlying event or
 transaction should (a) possess a high degree of abnormality
 and be of a type clearly unrelated to, or only incidentally related
 to, the ordinary and typical activities of the entity and
 (b) not reasonably be expected to recur in the foreseeable
 future. In the first quarter of fiscal year 2017, the Company
 adopted this update with no impact to the consolidated financial
 statements.


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0001193125-17-265630:notes:80]
The following
 table presents the pre-tax amounts reclassified from AOCI into the
 consolidated statements of operations and comprehensive income for
 the years ended June 30, 2017 and June 24, 2016,
 respectively (amounts in thousands).

[0001193125-17-265630:notes:81]
|  |  |  |  | Years ended |  |
| AOCI components |  | Financial statements line item |  | June 30, 2017 |  |  | June 24, 2016 |  |
| Unrealized losses on marketable securities |  | Interest income |  | $ | (822 | ) |  | $ | (194 | ) |
| Unrealized gains on derivative instruments |  | Cost of revenues |  |  | — |  |  |  | 471 |  |
|  |  | Selling, general and administrative expenses |  |  | (158 | ) |  |  | 19 |  |
| Total amounts reclassified from AOCI |  |  |  | $ | (980 | ) |  | $ | 296 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-17-265630:notes:82]
The changes in
 AOCI by component for the years ended June 30, 2017 and
 June 24, 2016 were as follows:

[0001193125-17-265630:notes:83]
| (amount in thousands) |  | Unrealized net (Losses)/Gains on Marketable Securities |  |  | Unrealized net (Losses)/Gains on Derivative Instruments |  |  | Foreign Currency Translation Adjustment |  |  | Total |  |
| Balance as of June 26, 2015 |  | $ | (44 | ) |  | $ | — |  |  | $ | — |  |  | $ | (44 | ) |
| Other comprehensive income before reclassification |  |  | 637 |  |  |  | (298 | ) |  |  | — |  |  |  | 339 |  |
| Amounts reclassified from AOCI |  |  | (194 | ) |  |  | 490 |  |  |  | — |  |  |  | 296 |  |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income |  |  | 399 |  |  |  | 192 |  |  |  | — |  |  |  | 591 |  |
| Balance as of June 24, 2016 |  |  | 399 |  |  |  | 192 |  |  |  | — |  |  |  | 591 |  |
| Other comprehensive income before reclassification |  |  | 351 |  |  |  | — |  |  |  | (310 | ) |  |  | 41 |  |
| Amounts reclassified from AOCI |  |  | (822 | ) |  |  | (158 | ) |  |  | — |  |  |  | (980 | ) |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income |  |  | (471 | ) |  |  | (158 | ) |  |  | (310 | ) |  |  | (939 | ) |
| Balance as of June 30, 2017 |  | $ | (72 | ) |  | $ | 34 |  |  | $ | (310 | ) |  | $ | (348 | ) |


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001193125-17-265630:notes:84]
The
 Company’s income tax expense consisted of the
 following:

[0001193125-17-265630:notes:85]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 30, 2017 |  |  | June 24, 2016 |  |  | June 26, 2015 |  |
| Current |  | $ | 6,299 |  |  | $ | 5,413 |  |  | $ | 4,191 |  |
| Deferred |  |  | 443 |  |  |  | 922 |  |  |  | (207 | ) |
| Total income tax expense |  | $ | 6,742 |  |  | $ | 6,335 |  |  | $ | 3,984 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001193125-17-265630:notes:86]
The movements
 of long-term loans were as follows for the years ended
 June 30, 2017 and June 24, 2016:

[0001193125-17-265630:notes:87]
|  |  | Years ended |  |
| (amount in thousands) |  | June 30, 2017 |  |  | June 24, 2016 |  |
| Opening net book amount |  | $ | 54,500 |  |  | $ | 10,500 |  |
| Additional loan during the period |  |  | — |  |  |  | 50,000 |  |
| Repayment during the period |  |  | (18,100 | ) |  |  | (6,000 | ) |
| Closing net book amount |  | $ | 36,400 |  |  | $ | 54,500 |  |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock

[0001193125-17-265630:notes:88]
Undrawn
 available credit facilities classified by available period of
 future borrowing as of June 30, 2017 and June 24, 2016
 were as follows:

[0001193125-17-265630:notes:89]
| (amount in thousands) |  | June 30, 2017 |  |  | June 24, 2016 |  |
| Short-term |  | $ | 1,965 |  |  | $ | 1,414 |  |
| Long-term |  | $ | 116,000 |  |  | $ | 143,500 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-17-265630:notes:90]
The following
 table presents total revenues by geographic regions:

[0001193125-17-265630:notes:91]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 30, 2017 |  |  | June 24, 2016 |  |  | June 26, 2015 |  |
| North America |  | $ | 661,267 |  |  | $ | 525,161 |  |  | $ | 370,836 |  |
| Asia-Pacific |  |  | 539,317 |  |  |  | 351,033 |  |  |  | 309,941 |  |
| Europe |  |  | 219,906 |  |  |  | 100,553 |  |  |  | 92,810 |  |
| Total |  | $ | 1,420,490 |  |  | $ | 976,747 |  |  | $ | 773,587 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-17-265630:notes:92]
| 2. | Summary of significant accounting policies |

[0001193125-17-265630:notes:93]
Principles of consolidation

[0001193125-17-265630:notes:94]
The Company
 utilizes a 52-53 week fiscal year ending on the Friday in June
 closest to June 30. Fiscal year 2017 ended on June 30,
 2017 and consisted of 53 weeks. Fiscal year 2016 and fiscal year
 2015 ended on June 24, 2016 and June 26, 2015,
 respectively, and each consisted of 52 weeks.

[0001193125-17-265630:notes:95]
The
 consolidated financial statements have been prepared in accordance
 with accounting principles generally accepted in the United States
 (“U.S. GAAP”) and include Fabrinet and its
 subsidiaries. All inter-company accounts and transactions have been
 eliminated.

[0001193125-17-265630:notes:96]
Where
 necessary, comparative figures have been reclassified to conform to
 the current period accounting policies and presentation
 adopted.

[0001193125-17-265630:notes:97]
On
 September 14, 2016, the Company acquired Global CEM Solutions,
 Ltd. and all of its subsidiaries (collectively, “Exception
 EMS”), a privately-held group located in Wiltshire,
 United Kingdom. The consolidated financial statements of the
 Company include the financial position, results of operations and
 the cash flows of Exception EMS commencing as of the acquisition
 date. See Note 9—Business acquisition for further details on
 the accounting for this transaction.

[0001193125-17-265630:notes:98]
Use of
 estimates

[0001193125-17-265630:notes:99]
The preparation
 of the Company’s consolidated financial statements in
 conformity with U.S. GAAP requires management to make estimates and
 assumptions that affect the reported amounts of assets and
 liabilities and disclosure of contingent liabilities at the date of
 the financial statements, and the reported amount of total revenues
 and expenses during the year. The Company bases estimates on
 historical experience and various assumptions about the future that
 are believed to be reasonable based on available information. The
 Company’s reported financial position or results of
 operations may be materially different under different conditions
 or when using different estimates and assumptions, particularly
 with respect to significant accounting policies, which are
 discussed below. Significant assumptions are used in accounting for
 share-based compensation, allowance for doubtful accounts, income
 taxes, inventory obsolescence and valuation of intangible assets
 related to business acquisition, among others. Due to the inherent
 uncertainty involved in making estimates, actual results reported
 in future periods may be different from these estimates. In the
 event that estimates or assumptions prove to differ from actual
 results, adjustments will be made in subsequent periods to reflect
 more current information.

[0001193125-17-265630:notes:100]
Foreign
 currency transactions and translation

[0001193125-17-265630:notes:101]
The
 consolidated financial statements are presented in United States
 dollars (“$” or “USD”). The functional
 currency of Fabrinet and most of its subsidiaries is the
 USD.

[0001193125-17-265630:notes:102]
With respect to
 subsidiaries that use USD as their functional currency,
 transactions denominated in a currency other than USD are
 translated into USD at the rates of exchange in effect at the date
 of the transaction. Monetary assets and liabilities denominated in
 foreign currencies are translated into the functional currency at
 the exchange rate prevailing at the consolidated balance sheet
 dates. Transaction gains and losses are included in other income
 (expense) or foreign exchange gain (loss) in the accompanying
 consolidated statements of operations and comprehensive
 income.

[0001193125-17-265630:notes:103]
Fabrinet
 translates the assets and liabilities of its subsidiaries that do
 not use USD as their functional currency into USD using exchange
 rates in effect at the end of each period. Revenue and expenses for
 such subsidiaries are translated using rates that approximate those
 in effect during the period. Gains and losses from these
 translations are recognized in foreign currency translation
 adjustment included in accumulated other comprehensive income
 (loss) (“AOCI”).

[0001193125-17-265630:notes:104]
Marketable securities

[0001193125-17-265630:notes:105]
Management
 determines the appropriate classification of its investments at the
 time of purchase and reevaluates the designations at each balance
 sheet date. The Company may sell certain of the Company’s
 marketable securities prior to their stated maturities for
 strategic reasons including, but not limited to, anticipation of
 credit deterioration and duration management. The maturities of the
 Company’s marketable securities generally range from three
 months to three years. The Company’s marketable securities
 consist of investment in U.S. Treasury and fixed income securities
 and have been classified and accounted for as
 available-for-sale.

[0001193125-17-265630:notes:106]
The
 Company’s investments in marketable securities are classified
 as available-for-sale securities and reported at fair value.
 Unrealized gains and losses related to changes in the fair value of
 securities are recognized in accumulated other comprehensive
 income, net of tax, in the Company’s consolidated balance
 sheets. Changes in the fair value of available-for-sale securities
 impact the Company’s net income only when such securities are
 sold or other-than-temporary impairment is recognized. Realized
 gains and losses on the sale of securities are determined by
 specific identification of each security’s cost
 basis.

[0001193125-17-265630:notes:107]
The Company
 reviews its marketable securities on a regular basis to evaluate
 whether or not any security has experienced an other-than-temporary
 decline in fair value. The Company considers factors such as the
 length of time and extent to which the market value has been less
 than the cost, the financial condition and near-term prospects of
 the issue and the Company’s intent to sell, or whether it is
 more likely than not the Company will be required to sell the
 investment before recovery of the investment’s amortized cost
 basis. If the Company believes that an other-than-temporary decline
 exists in one of these securities, the Company will write down
 these investments to fair value.

[0001193125-17-265630:notes:108]
Trade
 accounts receivable

[0001193125-17-265630:notes:109]
Accounts
 receivable are carried at anticipated realizable value. The Company
 assesses the collectability of its accounts receivable based on
 specific customer circumstances, current economic trends,
 historical experience with collection and the age of past due
 receivables and provides an allowance for doubtful receivables
 based on a review of all outstanding amounts at the period end. Bad
 debts are written-off when identified.

[0001193125-17-265630:notes:110]
Unanticipated
 changes in the liquidity or financial position of the
 Company’s customers may require revision to the allowances
 for doubtful accounts.

[0001193125-17-265630:notes:111]
Leases

[0001193125-17-265630:notes:112]
Operating
 leases

[0001193125-17-265630:notes:113]
Payments made
 under operating leases are expensed on a straight-line basis over
 the lease term.

[0001193125-17-265630:notes:114]
Capital
 lease

[0001193125-17-265630:notes:115]
Certain machine
 and equipment held under capital leases are classified as property,
 plant and equipment and amortized using the straight-line method
 over the terms of the lease contracts. The related obligations from
 the capital lease are recorded as liabilities in the consolidated
 balance sheets.

[0001193125-17-265630:notes:116]
Property,
 plant and equipment

[0001193125-17-265630:notes:117]
Land is stated
 at historical cost. Other property, plant and equipment, except for
 construction in process and machinery under installation, are
 stated at historical cost less accumulated depreciation.
 Depreciation is calculated using the straight-line method to
 write-off the cost of each asset to its residual value over its
 estimated useful life as follows:

[0001193125-17-265630:notes:118]
| Land improvements |  |  | 10 years |  |
| Building and building improvements |  |  | 7 - 30 years |  |
| Leasehold improvements |  |  | Shorter of useful life or lease term |  |
| Manufacturing equipment |  |  | 3 - 7 years |  |
| Office equipment |  |  | 3 - 7 years |  |
| Motor vehicles |  |  | 3 - 5 years |  |
| Computer hardware |  |  | 3 - 5 years |  |

[0001193125-17-265630:notes:119]
Construction in
 process and machinery under installation is stated at historic cost
 and depreciation begins after it is constructed and fully installed
 and is ready for its intended use in the operations of the
 Company.

[0001193125-17-265630:notes:120]
Gains and
 losses on disposal are determined by comparing proceeds with
 carrying amounts and are included in operating income in the
 consolidated statements of operations and comprehensive
 income.

[0001193125-17-265630:notes:121]
The Company
 tests long-lived assets or asset groups for recoverability when
 events or changes in circumstances indicate that their carrying
 amount may not be recoverable. Recoverability of long-lived assets
 or asset groups is measured by comparing their carrying amount to
 the projected undiscounted cash flows that the long-lived assets or
 asset groups are expected to generate. If such assets are
 considered to be impaired, the impairment loss recognized, if any,
 is the amount by which the carrying amount of the property and
 equipment exceeds its fair value.

[0001193125-17-265630:notes:122]
Intangibles

[0001193125-17-265630:notes:123]
Intangibles are
 stated at historical cost less amortization. Amortization of
 customer relationships is calculated using the accelerated method
 as to reflect the pattern in which the economic benefits of the
 intangible assets are consumed. Amortization of other intangibles
 is calculated using the straight-line method.

[0001193125-17-265630:notes:124]
Business
 acquisition

[0001193125-17-265630:notes:125]
For the
 acquisition of Exception EMS, the Company allocated the fair value
 of purchase consideration to the assets acquired and liabilities
 assumed based on their fair values at the acquisition date. The
 allocation of consideration to the individual net assets was
 finalized in the fourth quarter of fiscal year 2017.

[0001193125-17-265630:notes:126]
The acquired
 intangible assets, which consist of customer relationships and
 backlog, are recorded as intangibles in the consolidated balance
 sheets. The fair value of the acquired intangible assets was
 determined based on the multi-period excess earnings method. The
 Company reviews intangibles for impairment whenever changes or
 circumstances indicate the carrying amount may not be
 recoverable.

[0001193125-17-265630:notes:127]
In connection
 with the business acquisition, $3.3 million of cash for deferred
 consideration, net of foreign currency translation adjustment, was
 placed into an escrow account which is under the Company’s
 control. However, the Company has contractually agreed to remit
 this deferred consideration to the sellers of Exception EMS,
 subject to the resolution of claims that the Company may make
 against the funds with respect to indemnification and other claims
 within 24 months from the closing date of the transaction. The cash
 is presented as restricted cash in the consolidated balance sheets
 within non-current assets and the related liability is presented
 within non-current liabilities for the deferred
 consideration.

[0001193125-17-265630:notes:128]
Goodwill

[0001193125-17-265630:notes:129]
Goodwill
 arising from the acquisition is primarily attributable to the
 ability to expand future products and services and the assembled
 workforce. Goodwill is reviewed annually for impairment or more
 frequently whenever changes or circumstances indicate the carrying
 amount of goodwill may not be recoverable.

[0001193125-17-265630:notes:130]
Borrowing
 costs

[0001193125-17-265630:notes:131]
Borrowing costs
 are accounted for on an accrual basis and are charged to the
 consolidated statements of operations and comprehensive income in
 the year incurred, except for interest costs on general and
 specific borrowings attributable to finance certain qualifying
 assets. Such costs to finance qualifying assets are capitalized
 during the period of time that is required to complete and prepare
 the assets for their intended use, as part of the cost of the
 assets. All other borrowing costs are expensed as
 incurred.

[0001193125-17-265630:notes:132]
Where funds are
 not borrowed for a specific acquisition, construction or production
 of assets, the capitalization rate used to determine the amount of
 interest to be capitalized is the weighted average interest rate
 applicable to the Company’s outstanding borrowings during the
 year. Where funds are borrowed specifically for the acquisition,
 construction or production of assets, the amount of borrowing costs
 eligible for capitalization on the respective assets is determined
 as the actual borrowing costs are incurred on that borrowing during
 the respective periods.

[0001193125-17-265630:notes:133]
Fair
 value of financial instruments

[0001193125-17-265630:notes:134]
Fair value is
 defined as the exchange price that would be received for an asset
 or paid to transfer a liability (an exit price) in the principal or
 most advantageous market for the asset or liability in an orderly
 transaction between market participants on the measurement date. A
 fair value hierarchy is established which requires an entity to
 maximize the use of observable inputs and minimize the use of
 unobservable inputs for the valuation of an asset or liability as
 of the measurement date. The three levels of inputs that may be
 used to measure fair value are defined as follows:

[0001193125-17-265630:notes:135]
Level 1 inputs
 are quoted prices (unadjusted) in active markets for identical
 assets or liabilities.

[0001193125-17-265630:notes:136]
Level 2 inputs
 for similar assets and liabilities in active markets other than
 quoted prices included within Level 1 that are observable for the
 asset or liability, either directly or indirectly, for
 substantially the full term of the asset or liability.

[0001193125-17-265630:notes:137]
Level 3 inputs
 that are significant to the fair value measurement and unobservable
 (i.e. supported by little or no market activity), which require the
 reporting entity to develop its own valuation techniques and
 assumptions.

[0001193125-17-265630:notes:138]
The Company
 utilizes the market approach to measure fair value for its
 financial assets and liabilities. The market approach uses prices
 and other relevant information generated by market transactions
 involving identical or comparable assets or liabilities.

[0001193125-17-265630:notes:139]
The carrying
 amounts of certain financial instruments, which include cash and
 cash equivalents, trade accounts receivable, and trade accounts
 payable, approximate their fair values due to their short
 maturities. The carrying amounts of borrowings approximate their
 fair values as the applicable interest rate is based on market
 interest rates. The particular recognition methods adopted are
 disclosed in the individual policy statements associated with each
 item.

[0001193125-17-265630:notes:140]
Derivatives

[0001193125-17-265630:notes:141]
The derivatives
 assets and liabilities are recognized on the consolidated balance
 sheets as other current assets or accrued expenses and are measured
 at fair value.

[0001193125-17-265630:notes:142]
The Company
 applies hedge accounting to arrangements that qualify and are
 designated for cash flow or fair value hedge accounting treatment.
 Hedge accounting is discontinued prospectively if the hedging
 relationship ceases to be effective or the hedging or hedged items
 cease to exist as a result of maturity, sale, termination or
 cancellation.

[0001193125-17-265630:notes:143]
Derivatives
 designated and qualifying as hedges of the exposure to variability
 in expected future cash flows, or other types of forecasted
 transactions, are considered cash flow hedges which include forward
 currency contracts. In a cash flow hedging relationship, the
 effective portion of the change in the fair value of the hedging
 derivative is initially recorded in AOCI, while any ineffective
 portion is recognized directly in earnings, as a component of other
 income (expense). The portion of gain or loss on the derivative
 instrument remains in AOCI until the forecasted transaction is
 recognized in earnings.

[0001193125-17-265630:notes:144]
The Company
 also enters into derivative contracts that are intended to
 economically hedge certain of the Company’s risks. The
 changes in the fair value of the derivatives are recorded directly
 in earnings as a component of other income (expense). In accordance
 with the fair value measurement guidance, the Company’s
 accounting policy is to measure the credit risk of its derivative
 financial instruments that are subject to master netting agreements
 on a net basis by counterparty portfolio. The Company executes
 derivative instruments with financial institutions that are
 credit-worthy, which the Company defines as institutions that hold
 an investment grade credit rating.

[0001193125-17-265630:notes:145]
Concentration of credit risk

[0001193125-17-265630:notes:146]
Financial
 instruments that potentially subject the Company to concentrations
 of credit risk consist of cash and cash equivalents, marketable
 securities, derivatives and accounts receivable.

[0001193125-17-265630:notes:147]
Cash, cash
 equivalents and marketable securities are maintained with several
 financial institutions. Deposits held with banks may exceed the
 amount of insurance provided on such deposits. Generally, these
 deposits may be redeemed upon demand and are maintained with
 financial institutions with reputable credit and therefore bear
 minimal credit risk. The Company seeks to mitigate its credit risks
 by spreading such risks across multiple counterparties and
 monitoring the risk profiles of these counterparties. The Company
 limits its investments in marketable securities to securities with
 a maturity not in excess of three years, and all marketable
 securities that the Company invests in are rated A1, P-1, F1, or
 better.

[0001193125-17-265630:notes:148]
The Company
 performs ongoing credit evaluations for credit worthiness of its
 customers and usually does not require collateral from its
 customers. Management has implemented a program to closely monitor
 near term cash collection and credit exposures to mitigate any
 material losses.

[0001193125-17-265630:notes:149]
Revenue
 recognition

[0001193125-17-265630:notes:150]
The Company
 derives total revenues primarily from the assembly of products
 under supply agreements with its customers and the fabrication of
 customized optics and glass. Revenues represent the invoiced value
 of products, net of trade discounts and allowances, and exclude
 goods and services tax. The Company recognizes revenues when
 realized or realizable and earned. The Company considers revenues
 realized or realizable and earned when there is persuasive evidence
 of an arrangement, delivery has occurred, the sales price is fixed
 or determinable, and collectability is reasonably assured. Delivery
 does not occur until products have been shipped or services have
 been provided to the customer, risk of loss has transferred to the
 customer and customer acceptance has been obtained, customer
 acceptance provisions have lapsed, or the Company has objective
 evidence that the criteria specified in the customer acceptance
 provisions have been satisfied. In situations where a formal
 acceptance is required but the acceptance only relates to whether
 the product meets its published specifications, revenues are
 generally recognized upon shipment provided all other revenue
 recognition criteria are met. The sales price is not considered to
 be fixed or determinable until all contingencies related to the
 sale have been resolved. The Company reduces revenues for rebates
 and other similar allowances. Revenues are recognized only if these
 estimates can be reasonably and reliably determined. The Company
 bases its estimates utilizing historical results taking into
 consideration the type of customer, the type of transaction and the
 specifics of each arrangement. In addition to the aforementioned
 general policies, the following are the specific revenue
 recognition policies for each major category of
 revenues.

[0001193125-17-265630:notes:151]
Services

[0001193125-17-265630:notes:152]
The Company
 provides services for its customers that range from process design
 to product manufacturing. The Company recognizes service revenues
 when the services have been performed. The related costs are
 expensed as incurred.

[0001193125-17-265630:notes:153]
Services
 revenue of $75.4 million, $31.7 million and $32.3 million were
 recognized in the consolidated statements of operations and
 comprehensive income for the years ended June 30,
 2017, June 24, 2016 and June 26, 2015,
 respectively.

[0001193125-17-265630:notes:154]
Sales of
 goods

[0001193125-17-265630:notes:155]
Revenues from
 sales of goods are generally recognized when the product is shipped
 to the customer and when there are no unfulfilled obligations that
 affect the customer’s final acceptance of the arrangement.
 Any cost of warranties and remaining obligations that are
 inconsequential or perfunctory are accrued when the corresponding
 revenues are recognized.

[0001193125-17-265630:notes:156]
Certain
 customers may request the Company to store finished products
 purchased by them at the Company’s warehouse. In these
 instances, the Company receives a written request from the customer
 asking the Company to hold the inventory at the Company’s
 warehouse and the ordered goods are segregated in the
 Company’s warehouse from other inventory and cannot be used
 to fulfill other customer orders. In these situations, revenue is
 only recognized when persuasive evidence of the sales arrangement
 exists, the goods are completed and ready for shipment, pricing is
 fixed or determinable, collection is reasonably assured, and title
 and risk of loss have passed to the customer.

[0001193125-17-265630:notes:157]
Warranty
 provision

[0001193125-17-265630:notes:158]
Provisions for
 estimated expenses relating to product warranties are made at the
 time the products are sold using historical experience. Generally,
 this warranty is limited to workmanship and the Company’s
 liability is capped at the price of the product. The provisions
 will be adjusted when experience indicates an expected settlement
 will differ from initial estimates.

[0001193125-17-265630:notes:159]
Warranty cost
 allowances of $1.0 million, $0.1 million and $0.03 million were
 recognized in the consolidated statements of operations and
 comprehensive income for the years ended June 30, 2017,
 June 24, 2016 and June 26, 2015, respectively.

[0001193125-17-265630:notes:160]
Shipping
 and handling costs

[0001193125-17-265630:notes:161]
The Company
 records costs related to shipping and handling in cost of revenues
 for all periods presented.

[0001193125-17-265630:notes:162]
Share-based
 compensation is recognized in the consolidated financial statements
 based on grant-date fair value. The value of the portion of the
 award that is ultimately expected to vest is recognized as expense
 ratably over the requisite service period. The Company estimates
 the fair value of share option awards utilizing the
 Black-Scholes-Merton option-pricing model (“BSM”), net
 of estimated forfeitures. For restricted share units and
 performance share units, the fair values are based on the market
 value of our ordinary shares on the date of grant.

[0001193125-17-265630:notes:163]
Employee
 contribution plan

[0001193125-17-265630:notes:164]
The Company
 operates a defined contribution plan, known as a provident fund, in
 its subsidiaries in Thailand and the United Kingdom. The assets of
 these plans are in separate trustee-administered funds. The
 provident fund is funded by matching payments from employees and by
 the subsidiaries on a monthly basis. Current contributions to the
 provident fund are accrued and paid to the fund manager on a
 monthly basis. The Company sponsors the Fabrinet U.S. 401(k)
 Retirement Plan (the “401(k) Plan”), a Defined
 Contribution Plan under ERISA, at its subsidiaries in the United
 States, which provides retirement benefits for its eligible
 employees through tax deferred salary deductions.

[0001193125-17-265630:notes:165]
Severance
 liabilities

[0001193125-17-265630:notes:166]
Under labor
 protection laws applicable in Thailand and the Company’s
 subsidiary in Thailand’s employment policy, all employees of
 such subsidiary with more than 120 days of service are entitled to
 severance pay on forced termination or retrenchment or in the event
 that the employee reaches the retirement age of 55. The entitlement
 to severance pay is determined according to an employee’s
 individual employment tenure with the Company and is subject to a
 maximum benefit of 10 months of salary unless otherwise agreed upon
 in an employee’s employment contract. For employees of other
 subsidiaries who have a specific termination date, the entitlement
 to severance pay is determined according to their employment
 tenure, until their designated termination date.

[0001193125-17-265630:notes:167]
The Company
 accounts for these severance liabilities on an actuarial basis
 using the Projected Unit Credit Method, using the long-term Thai
 government bond yield as a discount rate. There are no separate
 plan assets held in respect of these liabilities.

[0001193125-17-265630:notes:168]
Annual
 leave

[0001193125-17-265630:notes:169]
Employee
 entitlements to annual leave are recognized when they accrue to the
 employee. On termination of employment, accrued employee
 entitlement to annual leave is paid in cash.

[0001193125-17-265630:notes:170]
Income
 taxes

[0001193125-17-265630:notes:171]
The Company
 uses the asset and liability method of accounting for income taxes,
 whereby deferred tax assets and liabilities are recognized for
 future tax consequences attributable to temporary differences
 between the financial statement carrying amounts of existing assets
 and liabilities and their respective tax bases. Deferred tax assets
 and liabilities are measured using tax rates expected to apply to
 taxable income in the years in which those temporary differences
 are expected to reverse. The effect of a change in tax rates on
 deferred tax assets and liabilities is recognized in income in the
 period that includes the enactment date. Deferred tax assets are
 reduced by a valuation allowance if, based on the weight of the
 available evidence, it is more likely than not that some portion or
 all of the deferred tax assets will not be realized.

[0001193125-17-265630:notes:172]
Fabrinet’s subsidiaries are subject to income tax audits
 by the respective tax authorities in all of the jurisdictions in
 which they operate. The determination of tax liabilities in each of
 these jurisdictions requires the interpretation and application of
 complex and sometimes uncertain tax laws and regulations. The
 Company recognizes liabilities based on its estimate of whether,
 and the extent to which, additional tax liabilities are
 more-likely-than-not. If the Company ultimately determines that the
 payment of such a liability is not probable, then it reverses the
 liability and recognizes a tax benefit during the period in which
 the determination is made that the liability is no longer probable.
 The recognition and measurement of current taxes payable or
 refundable and deferred tax assets and liabilities requires that
 the Company makes certain estimates and judgments. Changes to these
 estimates or a change in judgment may have a material impact on the
 Company’s tax provision in a future period.

[0001193125-17-265630:notes:173]
The
 authoritative guidance provides for recognition of deferred tax
 assets if the realization of such deferred tax assets is more
 likely than not to occur based on an evaluation of both positive
 and negative evidence and the relative weight of the evidence. The
 Company has determined that it is more likely than not that
 deferred tax asset attributable to a subsidiary in the United
 States will not be realized, primarily due to uncertainties related
 to its ability to utilize its net operating loss carryforward
 before they expire. Accordingly, the Company has established a
 valuation allowance for such deferred tax asset. If there is a
 change in the Company’s ability to realize its deferred tax
 assets for which a valuation allowance has been established, then
 its tax provision may decrease in the period in which it determines
 that realization is more likely than not. Likewise, if the Company
 determines that it is not more likely than not that its deferred
 tax assets will be realized, then a valuation allowance may be
 established for such deferred tax assets and the Company’s
 tax provision may increase in the period in which it makes the
 determination.

[0001193125-17-265630:notes:174]
The accounting
 standard clarifies the accounting for uncertainty in income taxes
 recognized in an entity’s financial statements and prescribes
 a recognition threshold and measurement attributes for financial
 statement disclosure of tax positions taken or expected to be taken
 on a tax return.

[0001193125-17-265630:notes:175]
The Company
 recognizes a tax benefit in the financial statements for an
 uncertain tax position only if management’s assessment is
 that the position is “more likely than not” (i.e., a
 likelihood greater than 50 percent) to be sustained upon
 examination by the tax jurisdiction based solely on the technical
 merits of the position. The term “tax position” refers
 to a position in a previously filed tax return or a position
 expected to be taken in a future tax return that is reflected in
 measuring current or deferred income tax assets and liabilities for
 interim or annual periods. The accounting interpretation also
 provides guidance on measurement methodology, derecognition
 thresholds, financial statement classification and disclosures,
 recognition of interest and penalties, and accounting for the
 cumulative-effect adjustment at the date of adoption.

[0001193125-17-265630:notes:176]
New
 Accounting Pronouncements—not yet adopted by the
 Company

[0001193125-17-265630:notes:177]
In January
 2017, the FASB issued ASU 2017-04,
 “Intangibles—Goodwill and Other (Topic 350):
 Simplifying the Test for Goodwill Impairment.” This amendment
 modified the concept of impairment assessment from the condition
 that exists when the carrying amount of goodwill exceeds its
 implied fair value to the condition that exists when the carrying
 amount of a reporting unit exceeds its fair value. Public companies
 that are SEC filers should adopt the amendment for its annual and
 any interim goodwill impairment tests in fiscal years beginning
 after December 15, 2019. Early adoption is permitted for
 interim or annual goodwill impairment tests performed on testing
 dates after January 1, 2017. The Company is currently
 evaluating the impact of the adoption of this update on its
 consolidated financial statements.

[0001193125-17-265630:notes:178]
In January
 2017, the FASB issued ASU 2017-03, “Accounting Changes and
 Error Corrections (Topic 250) and Investments—Equity Method
 and Joint Ventures (Topic 323): Amendments to SEC Paragraphs
 Pursuant to Staff Announcements at the September 22, 2016 and
 November 17, 2016 Emerging Issues Task Force
 (“EITF”) Meetings.” The amendment provides
 guidance to the Company in relation to the disclosure of the impact
 that ASU 2014-09, ASU 2016-02 and ASU 2016-13 will have on the
 Company’s financial statements when adopted. The Company is
 currently evaluating the impact of the adoption of this update on
 its consolidated financial statements.

[0001193125-17-265630:notes:179]
In January
 2017, the FASB issued ASU 2017-01, “Business Combination
 (Topic 805): Clarifying the Definition of a Business.” This
 amendment clarifies the definition of a business to assist entities
 when evaluating whether transactions should be accounted for as
 acquisitions (or disposals) of assets or business. For public
 companies, this ASU is effective for annual periods beginning after
 December 15, 2017, including interim periods within those
 periods. Early adoption is permitted for the transactions that
 occur before the issuance date or effective date of the amendment,
 only when the transaction has not been reported in financial
 statements that have been issued or made available for issuance.
 The Company does not expect that the adoption of this update will
 have a material impact to its consolidated financial
 statements.

[0001193125-17-265630:notes:180]
In August 2016,
 the FASB issued ASU 2016-15, “Classification of Certain Cash
 Receipts and Cash Payments (a consensus of the Emerging Issues Task
 Force).” The amendments in this ASU provide guidance on the
 presentation of certain cash receipts and cash payments in the
 statement of cash flows in order to reduce diversity in existing
 practice. The amendments in ASU 2016-15 are effective for public
 business entities for fiscal years beginning after
 December 15, 2017, and interim periods within those fiscal
 years. Early adoption is permitted, including adoption in an
 interim period. The Company is currently evaluating the impact of
 the adoption of this update on its consolidated financial
 statements.

[0001193125-17-265630:notes:181]
In March 2016,
 the FASB issued ASU 2016-09, “Compensation—Stock
 Compensation (Topic 718): Improvements to Employee Share-Based
 Payment Accounting.” This ASU simplifies several aspects of
 the accounting for share-based payment award transactions,
 including the income tax consequences, classification of awards as
 either equity or liabilities and classification on the statement of
 cash flows. The amendments in this update are effective for annual
 periods beginning after December 15, 2016, and interim periods
 within those annual periods, for public companies. Early adoption
 is permitted for any entity in any interim or annual period. The
 Company is currently evaluating the impact of the adoption of this
 update on its consolidated financial statements.

[0001193125-17-265630:notes:182]
In March 2016,
 the FASB issued ASU 2016-05, “Derivatives and Hedging (Topic
 815),” to clarify that a change in the counterparty to a
 derivative instrument that has been designated as a hedging
 instrument under Topic 815, does not, in and of itself, require a
 de-designation of the hedging relationship, provided that all other
 hedge accounting criteria continue to be met. This guidance is
 effective for public entities for financial statements issued for
 fiscal years beginning after December 15, 2016 and interim
 periods within those fiscal years. Early adoption is permitted. The
 Company is currently evaluating the impact of the adoption of this
 update on its consolidated financial statements.

[0001193125-17-265630:notes:183]
In February
 2016, the FASB issued ASU 2016-02, “Lease (Topic 842).”
 The core principle of Topic 842 is that a lessee should recognize
 the lease assets and liabilities that arise from leases in the
 statement of financial position. For public business entities, this
 update is effective for fiscal years beginning after
 December 15, 2018, including interim periods within those
 fiscal years. Early application is permitted. The Company is
 currently evaluating the impact of the adoption of this update on
 its consolidated financial statements.

[0001193125-17-265630:notes:184]
In January
 2016, the FASB issued ASU 2016-01, “Financial
 Instruments—Overall (Subtopic 825-10): Recognition and
 Measurement of Financial Assets and Financial Liabilities.”
 This new guidance requires certain equity investments to be
 measured at fair value, use of the exit price notion and separate
 presentation of financial assets and financial liabilities by
 measurement category and form of financial asset on the balance
 sheet or the accompanying notes to the financial statements. The
 ASU on recognition and measurement will take effect for public
 companies for fiscal years beginning after December 15, 2017,
 including interim periods within those fiscal years. The
 Company is currently evaluating the impact of the adoption of this
 update on its consolidated financial statements.

[0001193125-17-265630:notes:185]
In May 2014,
 the FASB issued ASU 2014-09, “Revenue from Contracts with
 Customers (Topic 606), issued as a new Topic, Accounting Standards
 Codification.” The core principle of this amendment is that
 an entity should recognize revenue to depict the transfer of
 promised goods or services to customers in an amount that reflects
 the consideration to which the entity expects to be entitled in
 exchange for those goods or services. This update is effective for
 public companies, as amended by ASU 2015-14, for annual reporting
 periods beginning after December 15, 2017, including interim
 periods within that reporting period. Earlier application of this
 guidance is permitted, but not before the original date of
 December 15, 2016, which can be adopted either retrospectively
 to each prior reporting period presented or as a cumulative-effect
 adjustment as of the date of adoption. Subsequently, in March 2016
 and April 2016, the FASB issued ASU 2016-08 and ASU 2016-10,
 respectively, to clarify the implementation guidance on principle
 versus agent considerations and address the potential diversity in
 practice at initial application and cost; and the complexity of
 applying Topic 606, both at transition and on an ongoing basis
 related to identification of performance obligations and licensing
 arrangements; and ASU 2016-12 and ASU 2016-20, in May 2016 and
 December 2016, respectively, to improve in certain aspects of Topic
 606, with the same effective date as ASU 2015-14. The Company is
 continuing to assess the impact of adopting this new guidance on
 its consolidated financial statements, including whether the effect
 will be material. The Company has not decided on the method of
 adoption. Additionally, as the Company continues to assess the new
 standard along with industry trends and additional interpretive
 guidance, the Company may adjust its implementation plan
 accordingly. The process is still ongoing and the Company expects
 to make significant progress in the coming quarters.


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001193125-17-265630:notes:186]
| 5. | Cash, cash equivalents and marketable securities |

[0001193125-17-265630:notes:187]
The
 Company’s cash, cash equivalents,
 and marketable securities can be analyzed as
 follows:

[0001193125-17-265630:notes:188]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized (Loss)/Gain |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of June 30, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 131,240 |  |  | $ | — |  |  | $ | 131,240 |  |  | $ | — |  |
| Cash equivalents |  |  | 2,585 |  |  |  | — |  |  |  | 2,585 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 98,247 |  |  |  | 27 |  |  |  | — |  |  |  | 98,274 |  |
| U.S. agency and U.S. treasury securities |  |  | 50,768 |  |  |  | (102 | ) |  |  | — |  |  |  | 50,666 |  |
| Sovereign and municipal securities |  |  | 2,507 |  |  |  | 3 |  |  |  | — |  |  |  | 2,510 |  |
| Total |  | $ | 285,347 |  |  | $ | (72 | ) |  | $ | 133,825 |  |  | $ | 151,450 |  |

[0001193125-17-265630:notes:189]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Gain |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of June 24, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 136,754 |  |  | $ | — |  |  | $ | 136,754 |  |  | $ | — |  |
| Cash equivalents |  |  | 6,050 |  |  |  | — |  |  |  | 6,050 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 112,128 |  |  |  | 394 |  |  |  | — |  |  |  | 112,522 |  |
| U.S. agency and U.S. treasury securities |  |  | 28,028 |  |  |  | 2 |  |  |  | — |  |  |  | 28,030 |  |
| Sovereign and municipal securities |  |  | 1,154 |  |  |  | 3 |  |  |  | — |  |  |  | 1,157 |  |
| Total |  | $ | 284,114 |  |  | $ | 399 |  |  | $ | 142,804 |  |  | $ | 141,709 |  |

[0001193125-17-265630:notes:190]
The cash
 equivalents include short-term bank deposits, investments in money
 market funds, and marketable securities with maturities of three
 months or less at the date of purchase. The effective interest rate
 on short term bank deposits was 0.6% and 0.7% per annum for
 the years ended June 30, 2017 and June 24, 2016,
 respectively.

[0001193125-17-265630:notes:191]
As of
 June 30, 2017 and June 24, 2016, 66% of our cash and cash
 equivalents were held by the Parent Company.

[0001193125-17-265630:notes:192]
During the year
 ended June 30, 2017, the net realized loss from changes in
 fair value of marketable securities recognized by the Company was
 $0.8 million.

[0001193125-17-265630:notes:193]
As of
 June 30, 2017 and June 24, 2016, the Company considered
 the declines in market value of its marketable securities
 investment portfolio to be temporary in nature and did not consider
 any of its securities other-than-temporarily impaired. The Company
 typically invests in highly-rated securities, and its investment
 policy generally limits the amount of credit exposure to any one
 issuer. The policy requires investments generally to be investment
 grade, with the primary objective of minimizing the potential risk
 of principal loss. Fair values were determined for each individual
 security in the investment portfolio. When evaluating an investment
 for other-than-temporary impairment, the Company reviews factors
 such as the length of time and extent to which fair value has been
 below its cost basis, the financial condition of the issuer and any
 changes thereto, changes in market interest rates, and the
 Company’s intent to sell, or whether it is more likely than
 not it will be required to sell, the investment before recovery of
 the investment’s cost basis. No impairment losses were
 recorded for the years ended June 30, 2017 and June 24,
 2016.

[0001193125-17-265630:notes:194]
As of
 June 30, 2017 and June 24, 2016, cash, cash equivalents,
 and marketable securities included bank deposits of $40.0 million
 held in various financial institutions located in the United States
 in order to support the availability of the Facility Agreement and
 comply with covenants. Under the terms and conditions of the
 Facility Agreement, the Company shall maintain cash, cash
 equivalents and/or marketable securities in an aggregate amount not
 less than $40.0 million in unencumbered deposits, and/or securities
 in accounts located in the United States at all times during the
 term of the Facility Agreement. As discussed in Note 13, the
 Company must comply with this covenant from and after the effective
 date of the Facility Agreement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-17-265630:notes:195]
| 3. | Income taxes |

[0001193125-17-265630:notes:196]
Cayman
 Islands

[0001193125-17-265630:notes:197]
Fabrinet is
 domiciled in the Cayman Islands. Under the current laws of the
 Cayman Islands, Fabrinet is not subject to tax in the Cayman
 Islands on income or capital gains. Fabrinet has received this
 undertaking for a 20-year period ending August 24, 2019, and
 after the expiration date, Fabrinet can make a request for renewal
 with the office of the Clerk of the Cabinet for another 20
 years.

[0001193125-17-265630:notes:198]
Income of the
 Company exempted from corporate income tax in the Cayman Islands
 amounted to $64.2 million, $41.0 million and $27.0 million in the
 years ended June 30, 2017, June 24, 2016 and
 June 26, 2015, respectively.

[0001193125-17-265630:notes:199]
Thailand

[0001193125-17-265630:notes:200]
Fabrinet
 Thailand is where the majority of the Company’s operations
 and production takes place. The Company was not subject to tax for
 the period from July 2010 through June 2015 on income generated
 from the manufacture of products at Pinehurst Building 5, and is
 not subject to tax from July 2012 through June 2020 on income
 generated from the manufacture of products at Pinehurst Building 6.
 Such preferential tax treatment is contingent on, among other
 things, the export of the Company’s customers’ products
 out of Thailand and the Company’s agreement not to move its
 manufacturing facilities out of its current province in Thailand
 for at least 15 years from the date on which preferential tax
 treatment was granted i.e., at least until June 2020. Additionally,
 in March 2016, the Thailand Revenue Department announced the
 permanent decrease of corporate income tax rates to 20% for tax
 periods beginning on or after January 1, 2016. As a result,
 corporate income tax rates for Fabrinet Thailand remain at 20% from
 fiscal year 2017 onwards.

[0001193125-17-265630:notes:201]
People’s Republic of China

[0001193125-17-265630:notes:202]
The corporate
 income tax rate for Casix is 25%.

[0001193125-17-265630:notes:203]
The
 reconciliation between the Company’s taxes that would arise
 by applying the statutory tax rate of the country of the
 Company’s principal operations, Thailand, to the
 Company’s effective tax charge is shown below:

[0001193125-17-265630:notes:204]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 30, 2017 |  |  | June 24, 2016 |  |  | June 26, 2015 |  |
| Income before income taxes (1) |  | $ | 103,857 |  |  | $ | 68,232 |  |  | $ | 47,626 |  |
| Tax expense calculated at a statutory corporate income tax rate of 20% |  |  | 20,771 |  |  |  | 13,646 |  |  |  | 9,525 |  |
| Effect of income taxes from locations with tax rates different from Thailand |  |  | 1,469 |  |  |  | 1,573 |  |  |  | 1,134 |  |
| Income not subject to tax (2) |  |  | (17,212 | ) |  |  | (10,493 | ) |  |  | (7,094 | ) |
| Income tax on unremitted earnings |  |  | 1,058 |  |  |  | 741 |  |  |  | 1,263 |  |
| Effect of different tax rate in relation to deferred tax utilization (3) |  |  | — |  |  |  | 894 |  |  |  | (221 | ) |
| Effect of foreign exchange rate adjustment |  |  | 667 |  |  |  | 375 |  |  |  | (365 | ) |
| Tax rebate from research and development application |  |  | (226 | ) |  |  | (145 | ) |  |  | (102 | ) |
| Others |  |  | 215 |  |  |  | (256 | ) |  |  | (156 | ) |
| Corporate income tax expense |  | $ | 6,742 |  |  | $ | 6,335 |  |  | $ | 3,984 |  |

[0001193125-17-265630:notes:205]
| (1) | Income before income taxes was mostly generated from domestic income in the Cayman Islands. |

[0001193125-17-265630:notes:206]
| (2) | Income not subject to tax relates to income earned in the Cayman Islands and income subject to an investment promotion privilege for Building 5 and Building 6. Income not subject to tax per ordinary share on a diluted basis (in dollars) was $0.18, $0.06 and $0.20 for the years ended June 30, 2017, June 24, 2016 and June 26, 2015, respectively. |

[0001193125-17-265630:notes:207]
| (3) | The balances were effect of different tax rate in relation to the rate recognized deferred taxes during the fiscal year and the rate when deferred taxes will be utilized in the following fiscal years. |

[0001193125-17-265630:notes:208]
The
 Company’s deferred tax assets and deferred tax liabilities,
 net of valuation allowance, at each balance sheet date are as
 follows:

[0001193125-17-265630:notes:209]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 30, 2017 |  |  | June 24, 2016 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Depreciation |  | $ | 1,674 |  |  | $ | 1,679 |  |
| Severance liability |  |  | 1,127 |  |  |  | 955 |  |
| Reserves and allowance |  |  | 1,046 |  |  |  | 1,363 |  |
| Loss carrying forward |  |  | 496 |  |  |  | — |  |
| Others |  |  | 10 |  |  |  | — |  |
| Total |  | $ | 4,353 |  |  | $ | 3,997 |  |

[0001193125-17-265630:notes:210]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 30, 2017 |  |  | June 24, 2016 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Temporary differences from intangibles and changes in the fair value of assets acquired |  | $ | (944 | ) |  | $ | — |  |
| Deferred tax from unremitted earnings |  |  | (2,485 | ) |  |  | (1,687 | ) |
| Total |  |  | (3,429 | ) |  |  | (1,687 | ) |
| Net |  | $ | 924 |  |  | $ | 2,310 |  |

[0001193125-17-265630:notes:211]
As of
 June 30, 2017 and June 24, 2016, the Company recognized
 deferred tax assets of $6.4 million and $4.9 million, respectively,
 from tax on net operating loss carrying forward of Fabrinet West.
 Utilization of the tax net operating losses carrying forward may be
 subject to substantial limitations according to the
 subsidiary’s future operation, which may result in the
 reduced utilization of a portion of the Company’s net
 operating losses.

[0001193125-17-265630:notes:212]
Income tax
 liabilities have not been established for withholding tax and other
 taxes that would be payable on the unremitted earnings of Fabrinet
 Thailand. Such amounts of Fabrinet Thailand are permanently
 reinvested; unremitted earnings for Fabrinet Thailand totaled $97.3
 million and $68.8 million as of June 30, 2017 and
 June 24, 2016, respectively. Unrecognized deferred tax
 liabilities for such unremitted earnings were $5.2 million and $4.2
 million as of June 30, 2017 and June 24, 2016,
 respectively.

[0001193125-17-265630:notes:213]
Deferred tax
 liabilities of $0.8 million and $0.7 million have been established
 for withholding tax on the unremitted earnings of Casix for the
 year ended June 30, 2017, which are included in non-current
 deferred tax liability as of June 30, 2017 and June 24,
 2016, respectively.

[0001193125-17-265630:notes:214]
Uncertain
 income tax positions

[0001193125-17-265630:notes:215]
Interest and
 penalties related to uncertain tax positions are recognized in
 income tax expense. The Company had approximately $0.6 million and
 $0.4 million of accrued interest and penalties related to uncertain
 tax positions on the consolidated balance sheets as of
 June 30, 2017 and June 24, 2016, respectively. The
 Company recorded interest and penalties of $0.3 million, $0.2
 million and $0.1 million for the years ended June 30,
 2017, June 24, 2016 and June 26, 2015, respectively,
 in the consolidated statements of operations and comprehensive
 income. With regard to the Thailand jurisdiction, tax years 2012
 through 2016 remain open to examination by the local
 authorities.

[0001193125-17-265630:notes:216]
The following
 table indicates the changes to the Company’s uncertain income
 tax positions for the years ended June 30,
 2017, June 24, 2016 and June 26, 2015 included in
 other non-current liabilities.

[0001193125-17-265630:notes:217]
| (amount in thousands) |  | As of June 30, 2017 |  |  | As of June 24, 2016 |  |  | As of June 26, 2015 |  |
| Beginning balance |  | $ | 1,420 |  |  | $ | 1,420 |  |  | $ | 868 |  |
| Additions during the year |  |  | — |  |  |  | — |  |  |  | 552 |  |
| Reductions for tax positions of prior years |  |  | — |  |  |  | — |  |  |  | — |  |
| Ending balance |  | $ | 1,420 |  |  | $ | 1,420 |  |  | $ | 1,420 |  |


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001193125-17-265630:notes:218]
| 7. | Trade accounts receivable, net |

[0001193125-17-265630:notes:219]
| (amount in thousands) |  | As of June 30, 2017 |  |  | As of June 24, 2016 |  |
| Trade accounts receivable |  | $ | 264,389 |  |  | $ | 196,178 |  |
| Less: Allowance for doubtful account |  |  | (40 | ) |  |  | (33 | ) |
| Trade accounts receivable, net |  | $ | 264,349 |  |  | $ | 196,145 |  |

[0001193125-17-265630:notes:220]
As of
 June 30, 2017, trade accounts receivable of $3.0 million were
 secured to short-term loans from bank (see Note 13).


## us-gaap:ScheduleOfAssumptionsUsedTableTextBlock

[0001193125-17-265630:notes:221]
The principal
 actuarial assumptions used were as follows:

[0001193125-17-265630:notes:222]
|  |  | Years Ended |  |
|  |  | June 30, 2017 |  | June 24, 2016 |  |  | June 26, 2015 |  |
| Discount rate |  | 1.93% - 3.6% |  |  | 2.0% - 3.2% |  |  |  | 4.0% |  |
| Future salary increases |  | 3.5% - 10.0% |  |  | 4.1% - 10.0% |  |  |  | 4.2% |  |


## us-gaap:ScheduleOfDebtTableTextBlock

[0001193125-17-265630:notes:223]
The
 Company’s total borrowings, including revolving and long-term
 borrowings, consisted of the following (dollars in
 thousands):

[0001193125-17-265630:notes:224]
| Rate (1) |  | Conditions |  |  | Maturity |  |  | As of June 30, 2017 |  |  | As of June 24, 2016 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  |  | Repayable in 1 to 6 months |  |  |  | July 2017 | (2) |  | $ | 34,000 |  |  | $ | 6,500 |  |
| Short-term loans from bank: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank of England base rate +1.85% |  |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  |  |  |  | 1,003 |  |  |  | — |  |
| Current portion of long-term borrowing |  |  |  |  |  |  |  |  |  |  | 13,600 |  |  |  | 18,100 |  |
|  |  |  |  |  |  |  |  |  |  |  | 48,603 |  |  |  | 24,600 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  |  |  |  |  | (201 | ) |  |  | (293 | ) |
|  |  |  |  |  |  |  |  |  |  | $ | 48,402 |  |  | $ | 24,307 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.80% per annum |  |  | Repayable in quarterly installments |  |  |  | March 2017 |  |  | $ | — |  |  | $ | 4,500 |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  |  | Repayable in quarterly installments |  |  |  | May 2019 |  |  |  | 36,400 |  |  | $ | 50,000 |  |
|  |  |  |  |  |  |  |  |  |  |  | 36,400 |  |  |  | 54,500 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (13,600 | ) |  |  | (18,100 | ) |
| Unamortized debt issuance costs |  |  |  |  |  |  |  |  |  |  | (99 | ) |  |  | (300 | ) |
| Non-current portion |  |  |  |  |  |  |  |  |  | $ | 22,701 |  |  | $ | 36,100 |  |

[0001193125-17-265630:notes:225]
|  | (1) | LIBOR is London Interbank Offered Rate. |

[0001193125-17-265630:notes:226]
|  | (2) | In June 2017, the maturity date of this revolving borrowing was extended to mature in July 2017. |


## us-gaap:ScheduleOfDefinedBenefitPlansDisclosuresTextBlock

[0001193125-17-265630:notes:227]
The following
 table provides the information of the severance
 liabilities:

[0001193125-17-265630:notes:228]
| (amount in thousands) |  | As of June 30, 2017 |  |  | As of June 24, 2016 |  |
| Balance, beginning of the fiscal year |  | $ | 6,684 |  |  | $ | 5,477 |  |
| Charged to selling, general and administrative expenses in the consolidated statements of operations and comprehensive income |  |  | 1,804 |  |  |  | 1,207 |  |
| Balance, end of the fiscal year |  | $ | 8,488 |  |  | $ | 6,684 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-17-265630:notes:229]
As of
 June 30, 2017, the estimated future amortization of intangible
 assets during each fiscal year was as follows:

[0001193125-17-265630:notes:230]
| (amount in thousand) |  |  |  |
| 2018 |  | $ | 1,482 |  |
| 2019 |  |  | 1,339 |  |
| 2020 |  |  | 934 |  |
| 2021 |  |  | 787 |  |
| 2022 |  |  | 527 |  |
| Thereafter |  |  | 771 |  |
| Total |  | $ | 5,840 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001193125-17-265630:notes:231]
|  | The | changes in the carrying amount of goodwill were as follows: |

[0001193125-17-265630:notes:232]
| (amount in thousands) |  | Goodwill |  |
| Balance as of June 24, 2016 |  | $ | — |  |
| Addition in connection with business acquisition |  |  | 3,883 |  |
| Foreign currency translation adjustment |  |  | (77 | ) |
| Balance as of June 30, 2017 |  | $ | 3,806 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001193125-17-265630:notes:233]
As of
 June 30, 2017, the future maturities of long-term debt during
 each fiscal year were as follows:

[0001193125-17-265630:notes:234]
| (amount in thousand) |  |  |  |
| 2018 |  | $ | 13,600 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 36,400 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001193125-17-265630:notes:235]
Total revenues,
 by percentage, from individual customers representing 10% or more
 of total revenues in the respective periods were as
 follows:

[0001193125-17-265630:notes:236]
|  |  | Years Ended |  |
|  |  | June 30, 2017 |  |  | June 24, 2016 |  |  | June 26, 2015 |  |
| Lumentum Operations LLC |  |  | 17 | % |  |  | 20 | % |  |  | 20 | % |
| Oclaro, Inc. |  |  | * | (1) |  |  | * | (1) |  |  | 10 | % |

[0001193125-17-265630:notes:237]
|  | (1) | Less than 10% of total revenue. |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-17-265630:notes:238]
| 9. | Business acquisition |

[0001193125-17-265630:notes:239]
On
 September 14, 2016, the Company acquired 100% shareholding in
 Exception EMS for cash consideration of approximately $13.0
 million, net of $0.5 million cash acquired. Exception EMS provides
 contract electronics manufacturing services to the global
 electronics industry with innovative solutions, adding value to the
 design, manufacture and testing of printed circuit board
 assemblies. Pursuant to the acquisition agreement, the Company has
 placed $3.3 million of cash, net of foreign currency translation
 adjustment, for deferred consideration in an escrow account which
 is under the Company’s control. However, the Company has
 contractually agreed to remit this deferred consideration to the
 sellers of Exception EMS, subject to the resolution of claims that
 the Company may make against the funds with respect to
 indemnification and other claims within 24 months from the closing
 date of the transaction.

[0001193125-17-265630:notes:240]
The Company has
 accounted for this acquisition under the provisions of business
 combinations accounting, in accordance with Accounting Standards
 Codification Topic 805—Business Combinations. Accordingly,
 the estimated fair value of the acquisition consideration was
 allocated to the assets acquired and the liabilities assumed based
 on their respective fair values on the acquisition date. The
 Company has made certain estimates and assumptions in determining
 the allocation of the acquisition consideration.

[0001193125-17-265630:notes:241]
The allocation
 of consideration to the individual net assets acquired was
 finalized in the fourth quarter of fiscal year 2017. As the
 functional currency of Exception EMS is pound sterling
 (“GBP”), for the year ended June 30, 2017, the
 Company recognized a $0.3 million loss from foreign currency
 translation adjustment in its consolidated statements of operations
 and comprehensive income.

[0001193125-17-265630:notes:242]
During the year
 ended June 30, 2017, the Company recorded a measurement period
 adjustment to recognized deferred tax liabilities of $1.2 million
 related to taxable temporary differences from intangibles and
 changes in the fair value of assets acquired. Therefore, goodwill
 which was previously reported at acquisition date of $2.7 million
 was changed to $3.9 million.

[0001193125-17-265630:notes:243]
The
 Company’s allocation of the total purchase price for the
 acquisition is summarized below:

[0001193125-17-265630:notes:244]
| (amount in thousands) |  | Purchase price allocation |  |
| Cash |  | $ | 474 |  |
| Accounts receivable |  |  | 4,064 |  |
| Inventory |  |  | 3,490 |  |
| Other current assets |  |  | 427 |  |
| Property, plant and equipment |  |  | 5,678 |  |
| Intangibles |  |  | 4,492 |  |
| Goodwill |  |  | 3,883 |  |
| Other non-current assets |  |  | 516 |  |
| Current liabilities |  |  | (6,796 | ) |
| Deferred tax liabilities |  |  | (1,148 | ) |
| Other non-current liabilities |  |  | (1,563 | ) |
| Total fair value of assets acquired and liabilities assumed |  | $ | 13,517 |  |
| Total purchase price, net of cash acquired |  | $ | 13,043 |  |

[0001193125-17-265630:notes:245]
In connection
 with the Company’s acquisition of Exception EMS, the Company
 assumed lease agreements for certain machine and equipment, which
 are accounted for as capital leases. As of June 30, 2017, the
 Company included approximately $1.9 million of capital lease assets
 and $1.4 million of capital lease liability in the consolidated
 balance sheets associated with these acquired lease
 agreements.

[0001193125-17-265630:notes:246]
During
 the year ended June 30, 2017, the Company incurred
 approximately $1.5 million in transaction costs related to the
 acquisition, which primarily consisted of legal, accounting and
 valuation-related expenses. These expenses were recorded in
 selling, general and administrative expense in the accompanying
 consolidated statements of operations and comprehensive
 income.

[0001193125-17-265630:notes:247]
Pro forma
 results of operations for the acquisition have not been presented
 as they were not material to the Company’s results of
 operations.

[0001193125-17-265630:notes:248]
Identifiable intangibles

[0001193125-17-265630:notes:249]
The acquired
 identifiable intangible assets include customer relationships and
 backlog. The fair value of the identified intangible assets was
 determined based on the multi-period excess earnings method, which
 applied the following key assumptions:

[0001193125-17-265630:notes:250]
Customer
 relationships represent the fair value of future projected revenues
 derived from the estimated sale of products to existing customers
 of the acquired company. The fair value of $4.4 million will be
 amortized over an estimated useful life of ten years.

[0001193125-17-265630:notes:251]
Backlog
 represents the fair value of sales orders backlog as of the
 valuation date. The fair value of $0.1 million will be amortized
 over an estimated useful life of three years.

[0001193125-17-265630:notes:252]
Goodwill
 arising from the acquisition is primarily attributable to the
 ability to expand future products and services and the assembled
 workforce. Goodwill is not deductible for tax purposes.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-17-265630:notes:253]
| 18. | Accumulated other comprehensive income (loss) |


## us-gaap:DebtDisclosureTextBlock

[0001193125-17-265630:notes:254]
13.
 Borrowings

[0001193125-17-265630:notes:255]
Credit
 facilities:

[0001193125-17-265630:notes:256]
The Company
 entered into a syndicated senior credit facility agreement (the
 “Facility Agreement”) with a consortium of banks on
 May 22, 2014. The Facility Agreement, led by Bank of America,
 provides for a $200.0 million credit line, comprised of a $150.0
 million revolving loan facility and a $50.0 million delayed draw
 term loan facility. The revolving loan facility contains an
 accordion feature permitting Fabrinet to request an increase in the
 facility up to $100.0 million subject to customary terms and
 conditions and provided that no default or event of default exists
 at the time of request. The revolving loan facility terminates and
 all amounts outstanding are due and payable in full on May 22,
 2019. The principal amount of any drawn term loans must be repaid
 according to the scheduled quarterly amortization payments, with
 final payment of all amounts outstanding, plus accrued interest,
 being due on May 22, 2019.

[0001193125-17-265630:notes:257]
On
 February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allows the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. The
 Company fully drew down the term loan facility of $50.0 million in
 fiscal year 2016. As of June 30, 2017, $34.0 million of
 revolving borrowing and $36.4 million of term loan borrowing was
 outstanding under the Facility Agreement, resulting in available
 credit facilities of $116.0 million. Borrowings under the revolving
 credit facility are classified as current liabilities in the
 audited consolidated balance sheet as the Company has the periodic
 option to renew or pay, all or a portion of, the outstanding
 balance at the end of the maturity date, which is in the range of
 one to six months, without premium or penalty, upon notice to the
 administrative agent. Subsequent to the balance sheet date, the
 Company sent a notice to the bank to renew the maturity date of
 this revolving borrowing. The bank approved the notice and extended
 the maturity to July 2017.

[0001193125-17-265630:notes:258]
Loans under the
 Facility Agreement bear interest, at Fabrinet’s option, at a
 rate per annum equal to a LIBOR rate plus a spread of 1.75% to
 2.50%, or a base rate, determined in accordance with the Facility
 Agreement, plus a spread of 0.75% to 1.50%, in each case with such
 spread determined based on Fabrinet’s consolidated total
 leverage ratio for the preceding four fiscal quarter period.
 Interest is due and payable quarterly in arrears for loans bearing
 interest at the base rate and at the end of an interest period (or
 at each three-month interval in the case of loans with interest
 periods greater than three months) in the case of loans bearing
 interest at the LIBOR rate.

[0001193125-17-265630:notes:259]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or the
 equivalent under the local law, can be effected. The Facility
 Agreement contains customary affirmative and negative covenants.
 Negative covenants include, among other things, limitations on
 liens, indebtedness, investments, mergers, sales of assets, changes
 in the nature of the business, dividends and distributions,
 affiliate transactions and capital expenditures. The Facility
 Agreement contains financial covenants requiring Fabrinet to
 maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage
 ratio of not more than 2.50:1.00; and (iv) a minimum quick
 ratio of not less than 1.10:1.00. Each of these financial covenants
 is calculated on a consolidated basis for the consecutive four
 fiscal quarter period then ended. As of June 30, 2017, the
 Company was in compliance with all covenants under the Facility
 Agreement.

[0001193125-17-265630:notes:260]
The Facility
 Agreement also contains customary events of default including,
 among other things, payment defaults, breaches of covenants or
 representations and warranties, cross-defaults with certain other
 indebtedness, bankruptcy and insolvency events and change in
 control of Fabrinet, subject to grace periods in certain instances.
 Upon an event of default, the lenders may terminate their
 commitments, declare all or a portion of the outstanding
 obligations payable by Fabrinet to be immediately due and payable
 and exercise other rights and remedies provided for under the
 Facility Agreement.

[0001193125-17-265630:notes:261]
Fabrinet
 intends to use the proceeds of the credit line to finance its
 future expansion in the United States and Thailand, and for general
 corporate purposes including mergers and acquisitions of
 complementary manufacturing businesses or technology, although
 Fabrinet has no current commitments with respect to any such
 acquisitions.

[0001193125-17-265630:notes:262]
Short-term borrowings from bank

[0001193125-17-265630:notes:263]
In connection
 with the acquisition of Exception EMS, the Company assumed a
 secured borrowing agreement that is secured by trade accounts
 receivable of Exception EMS. As of June 30, 2017, the carrying
 amount of trade accounts receivable secured to the loans was $3.0
 million. The secured borrowing agreement contains certain covenants
 that Exception EMS is required to comply with: (1) the value
 of credit notes may not exceed 4% of the value of assigned debts
 measured on a monthly basis, and (2) rolling cash flow must be
 provided to the financial institution along with monthly management
 information. As of June 30, 2017, the subsidiary was in
 compliance with all covenants under the secured borrowing
 agreement.

[0001193125-17-265630:notes:264]
As of
 June 30, 2017, the Company drew down $1.0 million from this
 facility, which is recorded as short-term loans in the consolidated
 balance sheets. The agreement bears interest for discount charge at
 1.85% per annum above Bank of England base rate.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-17-265630:notes:265]
| 21. | Financial instruments |

[0001193125-17-265630:notes:266]
Objectives and significant terms and
 conditions

[0001193125-17-265630:notes:267]
The principal
 financial risks faced by the Company are foreign currency risk and
 interest rate risk. The Company borrows at floating rates of
 interest to finance its operations. A minority of sales and
 purchases and a majority of labor and overhead costs are entered
 into in foreign currencies. In order to manage the risks arising
 from fluctuations in currency exchange rates, the Company uses
 derivative instruments. Trading for speculative purposes is
 prohibited under Company policies.

[0001193125-17-265630:notes:268]
The Company
 enters into short-term foreign currency forward and option
 contracts to manage foreign currency exposures associated with
 certain assets, liabilities and other forecasted foreign currency
 transactions and may designate these instruments as hedging
 instruments. The foreign currency forward and option contracts
 generally have maturity of up to six months. All foreign currency
 exchange contracts are recognized on the consolidated balance
 sheets at fair value. Gain or loss on the Company’s
 derivative instruments generally offset the assets, liabilities and
 transactions economically hedged.

[0001193125-17-265630:notes:269]
Foreign
 currency risk

[0001193125-17-265630:notes:270]
The Company
 operates internationally and is exposed to foreign exchange risk
 arising from various currency exposures primarily with respect to
 the Thai baht, Chinese Renminbi (“RMB”) GBP.

[0001193125-17-265630:notes:271]
As of
 June 30, 2017 and June 24, 2016, the Company had
 outstanding foreign currency assets and liabilities as
 follows:

[0001193125-17-265630:notes:272]
|  |  | As of June 30, 2017 |  |  | As of June 24, 2016 |  |
| (amount in thousands) |  | Currency |  |  | $ |  |  | Currency |  |  | $ |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 395,123 |  |  | $ | 11,628 |  |  |  | 834,536 |  |  | $ | 23,594 |  |
| RMB |  |  | 26,965 |  |  |  | 3,980 |  |  |  | 14,835 |  |  |  | 2,255 |  |
| GBP |  |  | 6,896 |  |  |  | 8,982 |  |  |  | — |  |  |  | — |  |
| Total |  |  |  |  |  | $ | 24,590 |  |  |  |  |  |  | $ | 25,849 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,875,338 |  |  | $ | 55,189 |  |  |  | 1,517,782 |  |  | $ | 42,912 |  |
| RMB |  |  | 28,451 |  |  |  | 4,200 |  |  |  | 24,654 |  |  |  | 3,748 |  |
| GBP |  |  | 5,625 |  |  |  | 7,326 |  |  |  | — |  |  |  | — |  |
| Total |  |  |  |  |  | $ | 66,715 |  |  |  |  |  |  | $ | 46,660 |  |

[0001193125-17-265630:notes:273]
The Thai baht
 assets represent cash and cash equivalents, trade accounts
 receivable, deposits and other current assets. The Thai baht
 liabilities represent trade accounts payable, accrued expenses,
 income tax payable and other payables. The Company manages its
 exposure to fluctuations in foreign exchange rates by the use of
 foreign currency contracts and offsetting assets and liabilities
 denominated in the same currency in accordance with
 management’s policy. As of June 30, 2017 and
 June 24, 2016, there was $1.0 million and $84.5 million in
 foreign currency forward contracts, respectively, outstanding on
 the Thai baht payables.

[0001193125-17-265630:notes:274]
The RMB assets
 represent cash and cash equivalents, trade accounts receivable and
 other current assets. The RMB liabilities represent trade accounts
 payable, accrued expenses, income tax payable and other payables.
 As of June 30, 2017 and June 24, 2016, there were no
 derivative contracts denominated in RMB.

[0001193125-17-265630:notes:275]
The GBP assets
 primarily represent cash, trade accounts receivable and property,
 plant and equipment, net. The GBP liabilities primarily represent
 short-term loans, trade accounts payable and other payables. As of
 June 30, 2017, there were no derivative contracts denominated
 in GBP.

[0001193125-17-265630:notes:276]
For fiscal year
 2017 and fiscal year 2016, the Company recorded unrealized loss of
 $0.02 million and $1.8 million, respectively, related to
 derivatives that are not designated as hedging instruments in its
 consolidated statements of operations and comprehensive
 income.

[0001193125-17-265630:notes:277]
Interest
 Rate Risk

[0001193125-17-265630:notes:278]
The
 Company’s principal interest bearing assets are time deposits
 and short-term investments with maturities of three months or less
 held with high quality financial institutions. The Company’s
 principal interest bearing liabilities are bank loans which bear
 interest at floating rates.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-17-265630:notes:279]
| 11. | Intangibles |

[0001193125-17-265630:notes:280]
The following
 tables present details of the Company’s
 intangibles:

[0001193125-17-265630:notes:281]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net |  |
| As of June 30, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 5,944 |  |  | $ | (3,850 | ) |  | $ | — |  |  | $ | 2,094 |  |
| Customer relationships |  |  | 4,373 |  |  |  | (606 | ) |  |  | (88 | ) |  |  | 3,679 |  |
| Backlog |  |  | 119 |  |  |  | (51 | ) |  |  | (1 | ) |  |  | 67 |  |
| Total intangibles |  | $ | 10,436 |  |  | $ | (4,507 | ) |  | $ | (89 | ) |  | $ | 5,840 |  |

[0001193125-17-265630:notes:282]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net |  |
| As of June 24, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 3,786 |  |  | $ | (3,287 | ) |  | $ | — |  |  | $ | 499 |  |
| Customer relationships |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Backlog |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total intangibles |  | $ | 3,786 |  |  | $ | (3,287 | ) |  | $ | — |  |  | $ | 499 |  |

[0001193125-17-265630:notes:283]
In connection
 with the acquisition of Exception EMS, the Company recorded $4.4
 million of customer relationships and $0.1 million of backlog. As
 of June 30, 2017, the weighted-average remaining life of
 customer relationships and backlog was 6.9 years and 1.6 years,
 respectively.

[0001193125-17-265630:notes:284]
The Company
 recorded amortization expense relating to intangibles of $1.2
 million, $0.1 million and $0.1 million for the years ended
 June 30, 2017, June 24, 2016 and June 26, 2015,
 respectively.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-17-265630:notes:285]
| 16. | Employee benefit plans |

[0001193125-17-265630:notes:286]
The Company
 operates a defined contribution plan, known as a provident fund, in
 its subsidiaries in Thailand and the United Kingdom. The assets of
 these plans are in separate trustee-administered funds. The
 provident fund is funded by matching payments from employees and by
 the subsidiaries on a monthly basis. Current contributions to the
 provident fund are accrued and paid to the fund manager on a
 monthly basis. The Company’s contributions to the provident
 fund amounted to $3.6 million, $2.8 million and $2.3 million during
 the years ended June 30, 2017, June 24, 2016 and
 June 26, 2015, respectively.

[0001193125-17-265630:notes:287]
The Company
 sponsors the Fabrinet U.S. 401(k) Retirement Plan (“401(k)
 Plan”), a Defined Contribution Plan under ERISA, at its
 subsidiaries in the United States which provides retirement
 benefits for eligible employees through tax deferred salary
 deductions. The 401(k) Plan allows employees to contribute up
 to 80% of their annual compensation, subject to annual
 contributions limits established by the Internal Revenue Service.
 The Company provides for a 100% match of employees’
 contributions to the 401(k) Plan up to the first 6% of annual
 compensation. All matching contributions are made in cash and vest
 immediately. The Company’s matching contributions to the
 401(k) Plan were $0.6 million, $0.5 million and $0.3 million during
 the years ended June 30, 2017, June 24, 2016 and
 June 26, 2015, respectively.

[0001193125-17-265630:notes:288]
Executive
 incentive plan and employee performance bonuses

[0001193125-17-265630:notes:289]
For the year
 ended June 30, 2017, the Company maintained an executive
 incentive plan with quantitative objectives, based on achieving
 certain revenue and gross margin targets. For the years ended
 June 24, 2016 and June 26, 2015, the Company maintained
 an executive incentive plan with quantitative objectives, based on
 achieving certain revenue and non-GAAP earnings per share targets
 as well as qualitative objectives, based on achieving individual
 performance goals for the applicable fiscal year. During the years
 ended June 30, 2017, June 24, 2016 and June 26,
 2015, discretionary merit-based bonus awards were also available to
 Fabrinet’s non-executive employees.

[0001193125-17-265630:notes:290]
Bonus
 distributions to employees were $7.6 million, $7.5 million and $6.0
 million for the years ended June 30, 2017, June 24,
 2016 and June 26, 2015, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001193125-17-265630:notes:291]
| 10. | Property, plant and equipment, net |

[0001193125-17-265630:notes:292]
The components
 of property, plant and equipment, net were as follows:

[0001193125-17-265630:notes:293]
| (amount in thousands) |  | Land and Land Improvements |  |  | Building and Building Improvements |  |  | Manufacturing Equipment |  |  | Office Equipment |  |  | Motor Vehicles |  |  | Computers |  |  | Construction and Machinery Under Installation |  |  | Total |  |
| As of June 30, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost |  | $ | 39,096 |  |  | $ | 138,578 |  |  | $ | 127,085 |  |  | $ | 7,688 |  |  | $ | 534 |  |  | $ | 19,642 |  |  | $ | 6,058 |  |  | $ | 338,681 |  |
| Less: Accumulated depreciation |  |  | (2 | ) |  |  | (31,881 | ) |  |  | (72,130 | ) |  |  | (4,163 | ) |  |  | (376 | ) |  |  | (13,248 | ) |  |  | — |  |  |  | (121,800 | ) |
| Net book value |  | $ | 39,094 |  |  | $ | 106,697 |  |  | $ | 54,955 |  |  | $ | 3,525 |  |  | $ | 158 |  |  | $ | 6,394 |  |  | $ | 6,058 |  |  | $ | 216,881 |  |
| As of June 24, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost |  | $ | 39,048 |  |  | $ | 95,386 |  |  | $ | 96,041 |  |  | $ | 5,826 |  |  | $ | 443 |  |  | $ | 15,578 |  |  | $ | 23,248 |  |  | $ | 275,570 |  |
| Less: Accumulated depreciation |  |  | — |  |  |  | (25,438 | ) |  |  | (56,564 | ) |  |  | (3,500 | ) |  |  | (366 | ) |  |  | (11,292 | ) |  |  | — |  |  |  | (97,160 | ) |
| Net book value |  | $ | 39,048 |  |  | $ | 69,948 |  |  | $ | 39,477 |  |  | $ | 2,326 |  |  | $ | 77 |  |  | $ | 4,286 |  |  | $ | 23,248 |  |  | $ | 178,410 |  |

[0001193125-17-265630:notes:294]
During the year
 ended June 30, 2017, property, plant and equipment, net
 included $5.0 million in assets acquired from the acquisition of
 Exception EMS, of which $1.9 million was capital leased assets.
 During the year ended June 24, 2016, the Company purchased a
 parcel of land in Chonburi, Thailand, with an aggregate purchase
 price of approximately $12.4 million, to support the expansion of
 its production capacity and capabilities in Thailand.

[0001193125-17-265630:notes:295]
Leased assets
 included above comprise certain machine and equipment from capital
 lease agreements assumed from the acquisition of Exception
 EMS.

[0001193125-17-265630:notes:296]
| (amount in thousands) |  | As of June 30, 2017 |  |
| Cost—Capital leases |  | $ | 2,725 |  |
| Less: Accumulated depreciation |  |  | (856 | ) |
| Net book value |  | $ | 1,869 |  |

[0001193125-17-265630:notes:297]
Depreciation
 expense amounted to $22.5 million, $17.3 million and $12.9 million
 for the years ended June 30, 2017, June 24, 2016 and
 June 26, 2015, respectively, and have been allocated between
 cost of revenues and selling, general and administrative expenses
 in the consolidated statements of operations and comprehensive
 income.

[0001193125-17-265630:notes:298]
The cost of
 fully depreciated property, plant and equipment written-off during
 the years ended June 30, 2017, June 24, 2016 and
 June 26, 2015 amounted to $5.4 million, $2.0 million and $1.1
 million, respectively.

[0001193125-17-265630:notes:299]
During the
 years ended June 30, 2017 and June 24, 2016, the Company
 capitalized $0.5 million and $0.1 million of borrowing costs in
 construction in progress of its new manufacturing building at
 Chonburi Campus. The Company stopped capitalizing borrowing costs
 in the third quarter of fiscal year 2017 upon the completion of
 this campus.


## us-gaap:ScheduleOfAmountsRecognizedInBalanceSheetTableTextBlock

[0001193125-17-265630:notes:300]
The amount
 recognized in the consolidated balance sheets under non-current
 liabilities was determined as follows:

[0001193125-17-265630:notes:301]
| (amount in thousands) |  | As of June 30, 2017 |  |  | As of June 24, 2016 |  |
| Present value of defined benefit obligation |  | $ | 8,488 |  |  | $ | 6,684 |  |
| Total |  | $ | 8,488 |  |  | $ | 6,684 |  |


## us-gaap:ScheduleOfNetBenefitCostsTableTextBlock

[0001193125-17-265630:notes:302]
The amount
 recognized in the consolidated statements of operations and
 comprehensive income was as follows:

[0001193125-17-265630:notes:303]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 30, 2017 |  |  | June 24, 2016 |  |  | June 26, 2015 |  |
| Current service cost |  | $ | 1,451 |  |  | $ | 842 |  |  | $ | 360 |  |
| Interest cost |  |  | 213 |  |  |  | 203 |  |  |  | 203 |  |
| Benefit paid |  |  | — |  |  |  | (11 | ) |  |  | (10 | ) |
| Actuarial loss on obligation |  |  | 140 |  |  |  | 173 |  |  |  | 471 |  |
| Total |  | $ | 1,804 |  |  | $ | 1,207 |  |  | $ | 1,024 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-17-265630:notes:304]
| 17. | Shareholders’ equity |

[0001193125-17-265630:notes:305]
Fabrinet’s
 authorized share capital is 500,000,000 ordinary shares, par value
 of $0.01 per ordinary share, and 5,000,000 preferred shares, par
 value of $0.01 per preferred share.

[0001193125-17-265630:notes:306]
For the year
 ended June 30, 2017, Fabrinet issued 367,641 ordinary shares
 upon the exercise of options, for cash consideration at a weighted
 average exercise price of $16.02 per share, and 816,409 ordinary
 shares upon the vesting of restricted share units, net of shares
 withheld.

[0001193125-17-265630:notes:307]
For the year
 ended June 24, 2016, Fabrinet issued 325,530 ordinary shares
 upon the exercise of options, for cash consideration at a weighted
 average exercise price of $16.83 per share, and 393,262 ordinary
 shares upon the vesting of restricted share units, net of shares
 withheld.

[0001193125-17-265630:notes:308]
For the year
 ended June 26, 2015, Fabrinet issued 56,968 ordinary shares
 upon the exercise of options, for cash consideration at a weighted
 average exercise price of $14.67 per share, and 227,914 ordinary
 shares upon the vesting of restricted share units, net of shares
 withheld.

[0001193125-17-265630:notes:309]
All such issued
 shares are fully paid.


## us-gaap:EarningsPerShareTextBlock

[0001193125-17-265630:notes:310]
| 4. | Earnings per ordinary share |

[0001193125-17-265630:notes:311]
Basic earnings
 per ordinary share is computed by dividing reported net income by
 the weighted average number of ordinary shares outstanding during
 each period. Diluted earnings per ordinary share is computed by
 calculating the effect of potential dilutive ordinary shares
 outstanding during the year using the treasury stock method.
 Dilutive ordinary equivalent shares consist of share options,
 restricted share units and performance share units. The earnings
 per ordinary share was calculated as follows:

[0001193125-17-265630:notes:312]
|  |  | Years Ended |  |
| (amount in thousands except per share amounts) |  | June 30, 2017 |  |  | June 24, 2016 |  |  | June 26, 2015 |  |
| Net income attributable to shareholders |  | $ | 97,115 |  |  | $ | 61,897 |  |  | $ | 43,642 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  | 36,927 |  |  |  | 35,857 |  |  |  | 35,354 |  |
| Incremental shares arising from the assumed exercise of share options and vesting of restricted share units and performance share units (thousands of shares) |  |  | 925 |  |  |  | 1,015 |  |  |  | 630 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 37,852 |  |  |  | 36,872 |  |  |  | 35,984 |  |
| Basic earnings per ordinary share |  | $ | 2.63 |  |  | $ | 1.73 |  |  | $ | 1.23 |  |
| Diluted earnings per ordinary share |  | $ | 2.57 |  |  | $ | 1.68 |  |  | $ | 1.21 |  |
| Outstanding share options excluded in the computation of diluted earnings per ordinary share (1) |  |  | — |  |  |  | — |  |  |  | 39,544 |  |

[0001193125-17-265630:notes:313]
| (1) | These share options were not included in the computation of diluted earnings per ordinary share because the exercise price of the options was greater than the average market price of the underlying shares. |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001193125-17-265630:notes:314]
The following
 table provides details of the financial instruments measured at
 fair value on a recurring basis, including:

[0001193125-17-265630:notes:315]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 30, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 2,585 |  |  | $ | — |  |  | $ | 2,585 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 98,274 |  |  |  | — |  |  |  | 98,274 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 50,666 |  |  |  | — |  |  |  | 50,666 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 2,510 |  |  |  | — |  |  |  | 2,510 |  |
| Derivative assets |  |  | — |  |  |  | 15 | (1) |  |  | — |  |  |  | 15 |  |
| Total |  | $ | — |  |  | $ | 154,050 |  |  | $ | — |  |  | $ | 154,050 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001193125-17-265630:notes:316]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 24, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 6,050 |  |  | $ | — |  |  | $ | 6,050 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 112,522 |  |  |  | — |  |  |  | 112,522 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 28,030 |  |  |  | — |  |  |  | 28,030 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 1,157 |  |  |  | — |  |  |  | 1,157 |  |
| Derivative assets |  |  | — |  |  |  | 158 | (2) |  |  | — |  |  |  | 158 |  |
| Total |  | $ | — |  |  | $ | 147,917 |  |  | $ | — |  |  | $ | 147,917 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 1,754 | (3) |  | $ | — |  |  | $ | 1,754 |  |
| Total |  | $ | — |  |  | $ | 1,754 |  |  | $ | — |  |  | $ | 1,754 |  |

[0001193125-17-265630:notes:317]
| (1) | Foreign currency forward contract with notional amount of $1.0 million and Canadian dollars 0.6 million. |

[0001193125-17-265630:notes:318]
| (2) | Foreign currency forward contract with notional amount of $7.0 million. |

[0001193125-17-265630:notes:319]
| (3) | Foreign currency forward contract with notional amount of $77.5 million and Canadian dollars 0.6 million. |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-17-265630:notes:320]
| 6. | Fair Value |

[0001193125-17-265630:notes:321]
Derivative
 Financial Instruments

[0001193125-17-265630:notes:322]
As a result of
 foreign currency rate fluctuations, the U.S. dollar equivalent
 values of the Company’s foreign currency denominated assets
 and liabilities change. The Company uses foreign currency contracts
 to manage the foreign exchange risk associated with certain foreign
 currency denominated assets and liabilities and other foreign
 currency transactions. The Company minimizes the credit risk in
 derivative instruments by limiting its exposure to any single
 counterparty and by entering into derivative instruments only with
 counterparties that meet the Company’s minimum credit quality
 standard. As of June 30, 2017, the Company recognized the fair
 value of foreign currency forward contracts of $0.02 million as
 derivative assets in the consolidated balance sheets under other
 current assets. As of June 24, 2016, the Company recognized
 the fair value of foreign currency forward contracts of $0.2
 million as derivative assets and $1.7 million as derivative
 liabilities in the consolidated balance sheets under other current
 assets and accrued expenses, respectively.

[0001193125-17-265630:notes:323]
As of
 June 30, 2017, the Company had no foreign currency forward
 contracts designated as cash flow hedges. During the year ended
 June 30, 2017, the Company discontinued cash flow hedges and
 recognized a gain from unwinding foreign currency forward contracts
 of $0.3 million as foreign exchange gain, net in the consolidated
 statements of operations and comprehensive income.

[0001193125-17-265630:notes:324]
As of
 June 24, 2016, the Company hedged forecasted foreign currency
 transactions related to the construction costs of a new
 manufacturing building at the Company’s Chonburi Campus with
 certain forward contracts, designated as cash flow hedges. The
 Company had two outstanding forward contracts with notional amount
 of $7.0 million, which mature during August 2016 and September
 2016. The Company included unrealized gain of $0.2 million from
 changes in fair value of these foreign currency forward contracts,
 designated as hedging instrument in AOCI in the consolidated
 balance sheets. As of June 24, 2016, gain of $0.01 million in
 AOCI is expected to be reclassified as earning within the next 12
 months. During the year ended June 24, 2016, there was no
 ineffective portion or discontinued cash flow hedges recognized in
 the consolidated statements of operations and comprehensive
 income.

[0001193125-17-265630:notes:325]
As of
 June 30, 2017, the Company had 2 outstanding foreign currency
 forward contracts with notional amount of $1.0 million and Canadian
 dollars 0.6 million, with maturity dates from July through
 September 2017. These foreign currency forward contracts were not
 designated for hedge accounting and were used to hedge fluctuations
 in the U.S. dollar value of forecasted transactions denominated in
 Thai baht and Canadian dollars. During the year ended June 30,
 2017, the Company included unrealized gain of $0.02 million from
 changes in fair value of foreign currency contracts in the
 consolidated statements of operations and comprehensive
 income.

[0001193125-17-265630:notes:326]
As of
 June 24, 2016, the Company had 14 outstanding foreign currency
 forward contracts with notional amount of $77.5 million and
 Canadian dollars 0.6 million, which matured during July to
 December 2016. These foreign currency forward contracts were not
 designated for hedge accounting and were used to hedge fluctuations
 in the U.S. dollar value of forecasted transactions denominated in
 Thai baht and Canadian dollar. During the year ended June 24,
 2016, the Company included unrealized loss of $1.8 million from
 changes in fair value of foreign currency contracts in the
 consolidated statements of operations and comprehensive
 income.


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-17-265630:notes:327]
| 12. | Goodwill |

[0001193125-17-265630:notes:328]
As of
 June 30, 2017, the Company recorded $3.8 million of goodwill,
 in connection with the acquisition of Exception EMS, in the
 consolidated balance sheets.

[0001193125-17-265630:notes:329]
Goodwill is not
 deductible for tax purposes. Goodwill is reviewed annually for
 impairment or more frequently whenever changes or circumstances
 indicate the carrying amount of goodwill may not be recoverable. As
 of June 30, 2017, the Company performed the annual impairment
 test for goodwill, which indicated there was no goodwill
 impairment.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001193125-17-265630:notes:330]
UNAUDITED
 QUARTERLY FINANCIAL INFORMATION

[0001193125-17-265630:notes:331]
The following
 table sets forth a summary of the Company’s quarterly
 financial information for each of the four quarters in the fiscal
 years ended June 30, 2017 and June 24, 2016:

[0001193125-17-265630:notes:332]
|  |  | Three Months Ended |  |
| (in thousands, except per share data) |  | Jun 30, 2017 |  |  | Mar 31, 2017 |  |  | Dec 30, 2016 |  |  | Sep 30, 2016 |  |  | Jun 24, 2016 |  |  | Mar 25, 2016 |  |  | Dec 25, 2015 |  |  | Sep 25, 2015 |  |
| Total revenues |  | $ | 370,454 |  |  | $ | 366,837 |  |  | $ | 351,156 |  |  | $ | 332,043 |  |  | $ | 276,388 |  |  | $ | 250,888 |  |  | $ | 233,038 |  |  | $ | 216,433 |  |
| Gross profit |  | $ | 44,760 |  |  | $ | 44,046 |  |  | $ | 43,046 |  |  | $ | 39,608 |  |  | $ | 33,842 |  |  | $ | 31,177 |  |  | $ | 28,493 |  |  | $ | 26,011 |  |
| Net income |  | $ | 27,401 |  |  | $ | 21,656 |  |  | $ | 25,292 |  |  | $ | 22,766 |  |  | $ | 19,669 |  |  | $ | 20,822 |  |  | $ | 19,803 |  |  | $ | 1,603 |  |
| Basic net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 0.73 |  |  | $ | 0.58 |  |  | $ | 0.69 |  |  | $ | 0.63 |  |  | $ | 0.55 |  |  | $ | 0.58 |  |  | $ | 0.55 |  |  | $ | 0.05 |  |
| Weighted-average shares used in basic net income per share calculations |  |  | 37,334 |  |  |  | 37,116 |  |  |  | 36,848 |  |  |  | 36,404 |  |  |  | 36,075 |  |  |  | 35,964 |  |  |  | 35,812 |  |  |  | 35,579 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 0.72 |  |  | $ | 0.57 |  |  | $ | 0.67 |  |  | $ | 0.61 |  |  | $ | 0.53 |  |  | $ | 0.56 |  |  | $ | 0.54 |  |  | $ | 0.04 |  |
| Weighted-average shares used in diluted net income per share calculations |  |  | 38,118 |  |  |  | 37,872 |  |  |  | 37,805 |  |  |  | 37,330 |  |  |  | 37,258 |  |  |  | 37,089 |  |  |  | 36,826 |  |  |  | 36,315 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001193125-17-265630:notes:333]
The following
 table presents revenues by end market:

[0001193125-17-265630:notes:334]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 30, 2017 |  |  | June 24, 2016 |  |  | June 26, 2015 |  |
| Optical communications |  | $ | 1,108,637 |  |  | $ | 727,580 |  |  | $ | 553,245 |  |
| Lasers, sensors, and other |  |  | 311,853 |  |  |  | 249,167 |  |  |  | 220,342 |  |
| Total |  | $ | 1,420,490 |  |  | $ | 976,747 |  |  | $ | 773,587 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-17-265630:notes:335]
| 20. | Business segments and geographic information |

[0001193125-17-265630:notes:336]
Operating
 segments are defined as components of an enterprise for which
 separate financial information is available that is evaluated
 regularly by the chief operating decision maker in deciding how to
 allocate resources and in assessing performance. The
 Company’s chief operating decision maker is Fabrinet’s
 chief executive officer. As of June 30,
 2017, June 24, 2016 and June 26, 2015, the Company
 operated and internally managed a single operating segment.
 Accordingly, the Company does not accumulate discrete information
 with respect to separate product lines and does not have separate
 reportable segments.

[0001193125-17-265630:notes:337]
Total revenues
 are attributed to a particular geographic area based on the
 bill-to-location of the customer. The Company operates primarily in
 three geographic regions: North America, Asia-Pacific and Europe.
 The following table presents total revenues by geographic
 regions:

[0001193125-17-265630:notes:338]
As of
 June 30, 2017 and June 24, 2016, the Company had
 approximately $34.9 million and $34.7 million, respectively, of
 long-lived assets based in North America, with the substantial
 remainder of assets based in Asia-Pacific.

[0001193125-17-265630:notes:339]
Significant customers

[0001193125-17-265630:notes:340]
Accounts
 receivable from individual customers representing 10% or more of
 accounts receivable as of June 30, 2017 and June 24,
 2016, respectively, were as follows:

[0001193125-17-265630:notes:341]
|  |  | As of June 30, 2017 |  |  | As of June 24, 2016 |  |
| Lumentum Operations LLC |  |  | 15 | % |  |  | 18 | % |
| NeoPhotonics Corporation |  |  | 12 | % |  |  | * | (1) |
| Acacia Communications Inc. |  |  | 10 | % |  |  | * | (1) |
| Valeo |  |  | * | (1) |  |  | 11 | % |

[0001193125-17-265630:notes:342]
|  | (1) | Less than 10% of total accounts receivable. |


## us-gaap:SubsequentEventsTextBlock

[0001193125-17-265630:notes:343]
| 23. | Subsequent event |

[0001193125-17-265630:notes:344]
In August 2017,
 the Company’s Board of Directors approved a share repurchase
 program to permit the Company to repurchase up to $30.0 million
 worth of its issued and outstanding ordinary shares in the open
 market in accordance with applicable rules and regulations, at such
 time and such prices as management may decide.

[0001193125-17-265630:notes:345]
The repurchased
 shares will be held as treasury stock.


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001193125-17-265630:notes:346]
| 22. | Income related to flooding |

[0001193125-17-265630:notes:347]
During the week
 of August 10, 2015, the Company’s subsidiary in China
 temporarily suspended production in its manufacturing facility due
 to flooding caused by Typhoon Soudelor and resumed operations on
 August 15, 2015. During the year ended June 24, 2016, the
 Company recognized income related to flooding of $0.04 million,
 which consisted of a $0.9 million final payment from an insurer
 against the Company’s claim for flood damage, offset by
 expenses in relation to flood of $0.86 million, which mainly
 consisted of $0.6 million of repaired cost of equipment and $0.2
 million of inventory losses.


## fn:AccruedSeveranceBenefitsDisclosureTextBlock

[0001193125-17-265630:notes:348]
| 14. | Severance liabilities |
