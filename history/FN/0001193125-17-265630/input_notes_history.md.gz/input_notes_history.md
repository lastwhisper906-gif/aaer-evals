# FN note change history — 0001193125-17-033383 → 0001193125-17-164153


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2017-05-09):
[0001193125-17-164153:note_history:1]
Collateral assets

- added (2017-05-09):
[0001193125-17-164153:note_history:2]
As of March 31, 2017 and June 24, 2016, certain property,
 plant and equipment of a subsidiary of $45.9 million and $47.7
 million were pledged as collateral to overdraft facilities, letter
 of guarantee and foreign exchange lines, respectively. In April
 2017, the bank released certain property, plant and equipment of
 the subsidiary which had been secured and pledged as collateral to
 such items.

- changed (2017-05-09):
[0001193125-17-164153:note_history:3]
As of March 31, 2017 and June 24, 2016, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $1.5 million and $0.8 million, respectively.
  (was, 2017-02-07, similarity 0.97):
[0001193125-17-033383:note_history:3]
As of December 30, 2016 and June 24, 2016, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $1.4 million and $0.8 million, respectively.

- changed (2017-05-09):
[0001193125-17-164153:note_history:4]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, New Jersey and the United Kingdom under operating
 lease arrangements that expire in various calendar years through
 2023. Rental expense under these operating leases amounted to $1.2
 million and $0.9 million for the nine months ended March 31,
 2017 and March 25, 2016, respectively.
  (was, 2017-02-07, similarity 0.9031):
[0001193125-17-033383:note_history:4]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, New Jersey and the United Kingdom under operating
 lease arrangements that expire in various calendar years through
 2023. Rental expense under these operating leases amounted to $0.8
 million and $0.6 million for the six months ended December 30,
 2016 and December 25, 2015, respectively.

- changed (2017-05-09):
[0001193125-17-164153:note_history:5]
As of March 31, 2017, the future minimum lease payments due
 under non-cancelable operating leases during each fiscal year were
 as follows:
  (was, 2017-02-07, similarity 0.9663):
[0001193125-17-033383:note_history:5]
As of December 30, 2016, the future minimum lease payments due
 under non-cancelable operating leases during each fiscal year were
 as follows:

- changed (2017-05-09):
[0001193125-17-164153:note_history:6]
| (amount in thousands) |  |  |  |
| 2017 (remaining three months) |  | $ | 439 |  |
| 2018 |  |  | 1,663 |  |
| 2019 |  |  | 1,116 |  |
| 2020 |  |  | 911 |  |
| 2021 |  |  | 510 |  |
| Thereafter |  |  | 897 |  |
| Total minimum operating lease payments |  | $ | 5,536 |  |
  (was, 2017-02-07, similarity 0.8894):
[0001193125-17-033383:note_history:6]
| (amount in thousands) |  |  |  |
| 2017 (remaining six months) |  | $ | 180 |  |
| 2018 |  |  | 387 |  |
| 2019 |  |  | 419 |  |
| 2020 |  |  | 385 |  |
| 2021 |  |  | 99 |  |
| Total minimum capital lease payments |  | $ | 1,470 |  |

- changed (2017-05-09):
[0001193125-17-164153:note_history:7]
As of March 31, 2017, the future minimum lease payments due
 under non-cancelable capital leases during each fiscal year were as
 follows:
  (was, 2017-02-07, similarity 0.9658):
[0001193125-17-033383:note_history:7]
As of December 30, 2016, the future minimum lease payments due
 under non-cancelable capital leases during each fiscal year were as
 follows:

- added (2017-05-09):
[0001193125-17-164153:note_history:8]
| (amount in thousands) |  |  |  |
| 2017 (remaining three months) |  | $ | 92 |  |
| 2018 |  |  | 393 |  |
| 2019 |  |  | 426 |  |
| 2020 |  |  | 391 |  |
| 2021 |  |  | 101 |  |
| Total minimum capital lease payments |  | $ | 1,403 |  |

- changed (2017-05-09):
[0001193125-17-164153:note_history:9]
As of March 31, 2017, the Company had an outstanding
 commitment to third parties of approximately $12.1 million.
  (was, 2017-02-07, similarity 0.9569):
[0001193125-17-033383:note_history:9]
As of December 30, 2016, the Company had an outstanding
 commitment to third parties of approximately $11.9 million.

- removed (2017-05-09):
[0001193125-17-033383:note_history:10]
| (amount in thousands) |  |  |  |
| 2017 (remaining six months) |  | $ | 867 |  |
| 2018 |  |  | 1,641 |  |
| 2019 |  |  | 1,104 |  |
| 2020 |  |  | 902 |  |
| 2021 |  |  | 503 |  |
| Thereafter |  |  | 850 |  |
| Total minimum operating lease payments |  | $ | 5,867 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-05-09):
[0001193125-17-164153:note_history:11]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of March 31, 2017 and for the three
 and nine months ended March 31, 2017 and March 25, 2016
 includes normal recurring adjustments, necessary for a fair
 statement of the financial information set forth herein, in
 accordance with accounting principles generally accepted in the
 United States of America (“U.S. GAAP”) for interim
 financial information and the rules and regulations of the
 Securities and Exchange Commission (“SEC”).
 Accordingly, such information does not include all of the
 information and footnotes required by U.S. GAAP for annual
 financial statements. For further information, please refer to the
 consolidated financial statements and footnotes thereto included in
 Fabrinet’s Annual Report on Form 10-K for the year ended
 June 24, 2016.
  (was, 2017-02-07, similarity 0.9422):
[0001193125-17-033383:note_history:11]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of December 30, 2016 and for the
 three and six months ended December 30, 2016 and
 December 25, 2015 includes normal recurring adjustments,
 necessary for a fair statement of the financial statements set
 forth herein, in accordance with accounting principles generally
 accepted in the United States of America (“U.S. GAAP”)
 for interim financial information and the rules and regulations of
 the Securities and Exchange Commission (“SEC”).
 Accordingly, such information does not include all of the
 information and footnotes required by U.S. GAAP for annual
 financial statements. For further information, please refer to the
 consolidated financial statements and footnotes thereto included in
 Fabrinet’s Annual Report on Form 10-K for the year ended
 June 24, 2016.

- changed (2017-05-09):
[0001193125-17-164153:note_history:12]
The balance sheet as of June 24, 2016 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three and nine
 months ended March 31, 2017 may not be indicative of results
 for the year ending June 30, 2017 or any future periods.
  (was, 2017-02-07, similarity 0.9331):
[0001193125-17-033383:note_history:12]
The balance sheet as of June 24, 2016 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three and six
 months ended December 30, 2016 may not be indicative of
 results for the year ending June 30, 2017 or any future
 periods.

- changed (2017-05-09):
[0001193125-17-164153:note_history:13]
On September 14, 2016, the Company acquired 100% shareholding
 in Global CEM Solutions, Ltd. and all of its subsidiaries
 (including Exception EMS), a privately-held group located
 in Wiltshire, United Kingdom. The unaudited condensed
 consolidated financial statements of the Company include the
 financial position, results of operations and the cash flows of
 Exception EMS commencing as of the acquisition date. See Note 8 -
 Business acquisitions for further details on the accounting for
 this transaction.
  (was, 2017-02-07, similarity 0.996):
[0001193125-17-033383:note_history:13]
On September 14, 2016, the Company acquired 100% shareholding
 in Global CEM Solutions, Ltd. and all of its subsidiaries
 (including Exception EMS), a privately-held group located
 in Wiltshire, United Kingdom. The unaudited condensed
 consolidated financial statements of the Company include the
 financial position, results of operations and the cash flows of
 Exception EMS commencing as of the acquisition date. See Note
 8—Business acquisitions for further details on the accounting
 for this transaction.

- changed (2017-05-09):
[0001193125-17-164153:note_history:14]
The preparation of the Company’s unaudited condensed
 consolidated financial statements in conformity with U.S. GAAP
 requires management to make estimates and assumptions that affect
 the reported amounts of assets and liabilities and disclosure of
 contingent liabilities at the date of the financial statements, and
 the reported amount of total revenues and expenses during the year.
 The Company bases estimates on historical experience and various
 assumptions about the future that are believed to be reasonable
 based on available information. The Company’s reported
 financial position or results of operations may be materially
 different under different conditions or when using different
 estimates and assumptions, particularly with respect to significant
 accounting policies, which are discussed below. Significant
 assumptions are used in accounting for share-based compensation,
 allowance for doubtful accounts, income taxes, inventory
 obsolescence and valuation of intangible assets related to business
 acquisition, among others. Due to the inherent uncertainty involved
 in making estimates, actual results reported in future periods may
 be different from these estimates. In the event that estimates or
 assumptions prove to differ from actual results, adjustments will
 be made in subsequent periods to reflect more current
 information.
  (was, 2017-02-07, similarity 0.9963):
[0001193125-17-033383:note_history:14]
The preparation of the Company’s condensed consolidated
 financial statements in conformity with U.S. GAAP requires
 management to make estimates and assumptions that affect the
 reported amounts of assets and liabilities and disclosure of
 contingent liabilities at the date of the financial statements, and
 the reported amount of total revenues and expenses during the year.
 The Company bases estimates on historical experience and various
 assumptions about the future that are believed to be reasonable
 based on available information. The Company’s reported
 financial position or results of operations may be materially
 different under different conditions or when using different
 estimates and assumptions, particularly with respect to significant
 accounting policies, which are discussed below. Significant
 assumptions are used in accounting for share-based compensation,
 allowance for doubtful accounts, income taxes, inventory
 obsolescence and valuation of intangible assets related to business
 acquisition, among others. Due to the inherent uncertainty involved
 in making estimates, actual results reported in future periods may
 be different from these estimates. In the event that estimates or
 assumptions prove to differ from actual results, adjustments will
 be made in subsequent periods to reflect more current
 information.

- changed (2017-05-09):
[0001193125-17-164153:note_history:15]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended
 March 31, 2017 and March 25, 2016 each consisted of 13
 weeks. The nine months ended March 31, 2017 and March 25,
 2016 consisted of 40 weeks and 39 weeks, respectively. Fiscal year
 2017 will be comprised of 53 weeks and will end on June 30,
 2017.
  (was, 2017-02-07, similarity 0.8145):
[0001193125-17-033383:note_history:15]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended
 December 30, 2016 and December 25, 2015 each consisted of
 13 weeks. The six months ended December 30, 2016 and
 December 25, 2015 consisted of 27 weeks and 26 weeks,
 respectively. Fiscal year 2017 will be comprised of 53 weeks and
 will end on June 30, 2017.

- changed (2017-05-09):
[0001193125-17-164153:note_history:16]
The derivatives assets and liabilities are recognized on the
 unaudited condensed consolidated balance sheets as other current
 assets or accrued expenses and are measured at fair value.
  (was, 2017-02-07, similarity 0.9778):
[0001193125-17-033383:note_history:16]
The derivatives assets and liabilities are recognized on the
 unaudited condensed consolidated balance sheets as other current
 assets or accrued expenses measured at fair value.

- changed (2017-05-09):
[0001193125-17-164153:note_history:17]
The Company applies hedge accounting to arrangements that qualify
 and are designated for cash flow or fair value hedge accounting
 treatment. Hedge accounting is discontinued prospectively if the
 hedging relationship ceases to be effective or the hedging or
 hedged items cease to exist as a result of maturity, sale,
 termination or cancellation.
  (was, 2017-02-07, similarity 0.9792):
[0001193125-17-033383:note_history:17]
The Company applies hedge accounting to arrangements that qualify
 and are designated for cash flow hedge accounting treatment. Hedge
 accounting is discontinued prospectively if the hedging
 relationship ceases to be effective or the hedging or hedged items
 cease to exist as a result of maturity, sale, termination or
 cancellation.

- changed (2017-05-09):
[0001193125-17-164153:note_history:18]
For the acquisition of Exception EMS, the Company allocated the
 fair value of purchase consideration to the assets acquired and
 liabilities assumed based on their fair values at the acquisition
 date. The total consideration and the allocation of consideration
 to the individual net assets are preliminary, pending the
 finalization of the estimated fair value attributable to the
 acquired customer relationships.
  (was, 2017-02-07, similarity 0.6638):
[0001193125-17-033383:note_history:18]
For the acquisition of Exception EMS, the Company allocated the
 fair value of purchase consideration to the assets acquired and
 liabilities assumed based on their fair values at the acquisition
 date. The total consideration and the allocation of consideration
 to the individual net assets is preliminary, as there are remaining
 uncertainties to be resolved, including the settlement of the final
 net working capital adjustment and the finalization of the
 estimated fair value attributable to the acquired intangible
 assets.

- changed (2017-05-09):
[0001193125-17-164153:note_history:19]
The acquired intangible assets, which consist of customer
 relationships and backlog, are recorded within intangibles, net in
 the unaudited condensed consolidated balance sheets. The fair value
 of the acquired intangible assets was determined based on the
 multi-period excess earnings method. The Company reviews definite
 lived intangibles for impairment whenever changes or circumstances
 indicate the carrying amount may not be recoverable.
  (was, 2017-02-07, similarity 0.7009):
[0001193125-17-033383:note_history:19]
The acquired intangible assets, which consist of customer
 relationships and backlog, are recorded as intangibles in the
 unaudited condensed consolidated balance sheets. The fair value of
 the acquired intangible assets was determined based on the
 multi-period excess earnings method. The Company reviews
 intangibles for impairment whenever changes or circumstances
 indicate the carrying amount may not be recoverable.

- changed (2017-05-09):
[0001193125-17-164153:note_history:20]
In August 2014, the FASB issued ASU 2014-15, “Presentation of
 Financial Statements – Going Concern (Subtopic 205-40):
 Disclosure of Uncertainties about an Entity’s Ability to
 Continue as a Going Concern.” The amendments require
 management to evaluate, for each annual and interim reporting
 period, an entity’s ability to continue as a going concern
 when relevant conditions and events, considered in the aggregate,
 indicate that it is probable that the entity will be unable to meet
 its obligations that become due within one year after the date that
 the financial statements are issued (or available to be issued).
 This ASU is effective for annual periods and interim reporting
 periods ending after December 15, 2016. The Company does not
 expect that the adoption of this update will have an effect on its
 consolidated financial statements.
  (was, 2017-02-07, similarity 0.9945):
[0001193125-17-033383:note_history:20]
In August 2014, the FASB issued ASU 2014-15, “Presentation of
 Financial Statements – Going Concern (Subtopic 205-40):
 Disclosure of Uncertainties about an Entity’s Ability to
 Continue as a Going Concern.” The amendments require
 management to evaluate, for each annual and interim reporting
 period, an entity’s ability to continue as a going concern
 when relevant conditions and events, considered in the aggregate,
 indicate that it is probable that the entity will be unable to meet
 its obligations that become due within one year after the date that
 the financial statements are issued (or available to be issued).
 This ASU is effective for annual periods and interim reporting
 periods beginning after December 15, 2016. The Company does
 not expect that the adoption of this update will have an effect on
 its consolidated financial statements.

- changed (2017-05-09):
[0001193125-17-164153:note_history:21]
In May 2014, the FASB issued ASU 2014-09, “Revenue from
 Contracts with Customers (Topic 606), issued as a new Topic,
 Accounting Standards Codification.” The core principle of
 this amendment is that an entity should recognize revenue to depict
 the transfer of promised goods or services to customers in an
 amount that reflects the consideration to which the entity expects
 to be entitled in exchange for those goods or services. This update
 is effective for public companies, as amended by ASU 2015-14, for
 annual reporting periods beginning after December 15, 2017,
 including interim periods within that reporting period. Earlier
 application of this guidance is permitted, but not before the
 original date of December 15, 2016, which can be adopted
 either retrospectively to each prior reporting period presented or
 as a cumulative-effect adjustment as of the date of adoption.
 Subsequently, in March 2016 and April 2016, the FASB issued ASU
 2016-08 and ASU 2016-10, respectively, to clarify the
 implementation guidance on principle versus agent considerations
 and address the potential diversity in practice at initial
 application and cost; and the complexity of applying Topic 606,
 both at transition and on an ongoing basis related to
 identification of performance obligations and licensing
 arrangements; and ASU 2016-12 and ASU 2016-20, in May 2016 and
 December 2016, respectively, to improve in certain aspects of Topic
 606, with the same effective date as ASU 2015-14. The Company will
 adopt this standard during its fiscal year ending June 28,
 2019. In the current period, the Company is assessing the contracts
 with its customers to identify the impact to its consolidated
 financial statements. The process is still ongoing and the Company
 expects to make significant progress in the coming quarters.
  (was, 2017-02-07, similarity 0.9994):
[0001193125-17-033383:note_history:21]
In May 2014, the FASB issued ASU 2014-09, “Revenue from
 Contracts with Customers (Topic 606), issued as a new Topic,
 Accounting Standards Codification.” The core principle of
 this amendment is that an entity should recognize revenue to depict
 the transfer of promised goods or services to customers in an
 amount that reflects the consideration to which the entity expects
 to be entitled in exchange for those goods or services. This update
 is effective for public companies, as amended by ASU 2015-14, for
 annual reporting periods beginning after December 15, 2017,
 including interim periods within that reporting period. Earlier
 application of this guidance is permitted, but not before the
 original date of December 15, 2016, which can be adopted
 either retrospectively to each prior reporting period presented or
 as a cumulative-effect adjustment as of the date of adoption.
 Subsequently, in March 2016 and April 2016, the FASB issued ASU
 2016-08 and ASU 2016-10, respectively, to clarify the
 implementation guidance on principle versus agent considerations
 and address the potential diversity in practice at initial
 application and cost; and the complexity of applying Topic 606,
 both at transition and on an ongoing basis related to
 identification of performance obligations and licensing
 arrangements; and ASU 2016-12 and ASU 2016-20, in May 2016 and
 December 2016, respectively, to improve in certain aspects of Topic
 606 , with the same effective date as ASU 2015-14. The Company will
 adopt this standard during its fiscal year ending June 28,
 2018. In the current period, the Company is assessing the contracts
 with its customers to identify the impact to its consolidated
 financial statements. The process is still ongoing and the Company
 expects to make significant progress in the coming quarters.

- changed (2017-05-09):
[0001193125-17-164153:note_history:22]
In November 2015, the FASB issued ASU 2015-17, “Balance Sheet
 Classification of Deferred Taxes,” which will require
 entities to present deferred tax assets (“DTAs”) and
 deferred tax liabilities (“DTLs”) as non-current in a
 classified balance sheet. The ASU simplifies the current guidance,
 which requires entities to separately present DTAs and DTLs as
 current and non-current in a classified balance sheet. The Company
 has early adopted this update in the first quarter of fiscal year
 2017. The Company adopted this update on a prospective basis and
 did not change the presentation of the comparative period.
  (was, 2017-02-07, similarity 0.8826):
[0001193125-17-033383:note_history:22]
In November 2015, the FASB issued ASU 2015-17, “Balance Sheet
 Classification of Deferred Taxes,” which will require
 entities to present deferred tax assets (“DTAs”) and
 deferred tax liabilities (“DTLs”) as non-current in a
 classified balance sheet. The ASU simplifies the current guidance,
 which requires entities to separately present DTAs and DTLs as
 current and non-current in a classified balance sheet. The Company
 has early adopted this update in the first quarter of fiscal year
 2017. Accordingly, as of December 30, 2016, DTAs of $0.8
 million were classified to non-current assets in the unaudited
 condensed consolidated balance sheets. The Company adopted this
 update on a prospective basis and did not change the presentation
 of the comparative period.

- changed (2017-05-09):
[0001193125-17-164153:note_history:23]
In September 2015, the FASB issued ASU 2015-16, “Business
 Combinations (Topic 805): Simplifying the Accounting for
 Measurement-Period Adjustments” which require an acquirer to
 recognize adjustments to provisional amounts that are identified
 during the measurement period in the reporting period in which the
 adjustment amounts are determined. The Company adopted this update
 in the first quarter of fiscal year 2017 and applied it on a
 prospective basis. See Footnote 8 – Business acquisition, for
 further disclosure on measurement period adjustments recorded in
 the nine months ended March 31, 2017.
  (was, 2017-02-07, similarity 0.7606):
[0001193125-17-033383:note_history:23]
In September 2015, the FASB issued ASU 2015-16, “Business
 Combinations (Topic 805): Simplifying the Accounting for
 Measurement-Period Adjustments” which require an acquirer to
 recognize adjustments to provisional amounts that are identified
 during the measurement period in the reporting period in which the
 adjustment amounts are determined. The Company has adopted this
 update and applied it on a prospective basis.

- changed (2017-05-09):
[0001193125-17-164153:note_history:24]
In July 2015, the FASB issued ASU 2015-11, “Inventory (Topic
 330): Simplifying the Measurement of Inventory.” The update
 provides the guidance that an entity, that measured inventory by
 using first-in, first-out or average cost, should measure inventory
 at the lower of cost and net realizable value. Subsequent
 measurement is unchanged for inventory measured using last-in,
 first-out or the retail inventory method. The Company adopted this
 update in the first quarter of fiscal year 2017 with no impact to
 the unaudited condensed consolidated financial statements.
  (was, 2017-02-07, similarity 0.9252):
[0001193125-17-033383:note_history:24]
In July 2015, the FASB issued ASU 2015-11, “Inventory (Topic
 330): Simplifying the Measurement of Inventory.” The update
 provides the guidance that an entity, that measured inventory by
 using first-in, first-out or average cost, should measure inventory
 at the lower of cost and net realizable value. Subsequent
 measurement is unchanged for inventory measured using last-in,
 first-out or the retail inventory method. The Company has adopted
 this update with no impact to the unaudited condensed consolidated
 financial statements.

- changed (2017-05-09):
[0001193125-17-164153:note_history:25]
In April 2015, the FASB issued ASU 2015-03, “Interest –
 Imputation of Interest (Subtopic 835-30): Simplifying the
 Presentation of Debt Issuance Costs.” The update requires
 debt issuance costs related to a recognized debt liability be
 presented in the balance sheet as a direct deduction from the
 carrying amount of the related debt liability instead of being
 presented as an asset. Debt disclosures will include the face
 amount of the debt liability and the effective interest rate. The
 update requires retrospective application and represents a change
 in accounting principle. Additionally, in August 2015, the FASB
 issued ASU 2015-15, “Interest – Imputation of Interest
 (Subtopic 835-30): Presentation and Subsequent Measurement of Debt
 Issuance Costs Associated with Line-of-Credit Arrangements”
 to amend ASU 2015-03. The Company adopted this amendment
 retrospectively in the first quarter of fiscal year 2017. As of
 March 31, 2017 and June 24, 2016, debt issuance costs of
 $0.4 million and $0.6 million, respectively, related to a
 recognized debt liability are presented in the balance sheet as a
 direct reduction of the carrying amount of the related debts.
  (was, 2017-02-07, similarity 0.9682):
[0001193125-17-033383:note_history:25]
In April 2015, the FASB issued ASU 2015-03, “Interest –
 Imputation of Interest (Subtopic 835-30): Simplifying the
 Presentation of Debt Issuance Costs.” The update requires
 debt issuance costs related to a recognized debt liability be
 presented in the balance sheet as a direct deduction from the
 carrying amount of the related debt liability instead of being
 presented as an asset. Debt disclosures will include the face
 amount of the debt liability and the effective interest rate. The
 update requires retrospective application and represents a change
 in accounting principle. Additionally, in August 2015, the FASB
 issued ASU 2015-15, “Interest – Imputation of Interest
 (Subtopic 835-30): Presentation and Subsequent Measurement of Debt
 Issuance Costs Associated with Line-of-Credit Arrangements”
 to amend ASU 2015-03. The Company has adopted this amendment
 retrospectively. As of December 30, 2016 and June 24,
 2016, debt issuance costs of $0.4 million and $0.6 million,
 respectively, related to a recognized debt liability are presented
 in the balance sheet as a direct reduction of the carrying amount
 of the related debts.

- changed (2017-05-09):
[0001193125-17-164153:note_history:26]
In February 2015, the FASB issued ASU 2015-02, “Consolidation
 (Topic 810): Amendments to the Consolidation Analysis.” ASU
 No. 2015-02 amended the process that a reporting entity must
 perform to determine whether it should consolidate certain types of
 legal entities. In the first quarter of fiscal year 2017, the
 Company adopted this update with no impact to the unaudited
 condensed consolidated financial statements.
  (was, 2017-02-07, similarity 0.916):
[0001193125-17-033383:note_history:26]
In February 2015, the FASB issued ASU 2015-02, “Consolidation
 (Topic 810): Amendments to the Consolidation Analysis.” ASU
 No. 2015-02 amended the process that a reporting entity must
 perform to determine whether it should consolidate certain types of
 legal entities. The Company has adopted this update with no impact
 to the unaudited condensed consolidated financial statements.

- changed (2017-05-09):
[0001193125-17-164153:note_history:27]
In January 2015, the FASB issued ASU 2015-01, “Income
 Statement – Extraordinary and Unusual Items (Subtopic
 225-20): Simplifying Income Statement Presentation by Eliminating
 the Concept of Extraordinary Items.” The objective of this
 amendment is to reduce the complexity in accounting standards by
 eliminating the concept of extraordinary items from U.S. GAAP. To
 meet for extraordinary classification the underlying event or
 transaction should (a) possess a high degree of abnormality
 and be of a type clearly unrelated to, or only incidentally related
 to, the ordinary and typical activities of the entity and
 (b) not reasonably be expected to recur in the foreseeable
 future. In the first quarter of fiscal year 2017, the Company
 adopted this update with no impact to the unaudited condensed
 consolidated financial statements.
  (was, 2017-02-07, similarity 0.9598):
[0001193125-17-033383:note_history:27]
In January 2015, the FASB issued ASU 2015-01, “Income
 Statement – Extraordinary and Unusual Items (Subtopic
 225-20): Simplifying Income Statement Presentation by Eliminating
 the Concept of Extraordinary Items.” The objective of this
 amendment is to reduce the complexity in accounting standards by
 eliminating the concept of extraordinary items from U.S. GAAP. To
 meet for extraordinary classification the underlying event or
 transaction should (a) possess a high degree of abnormality
 and be of a type clearly unrelated to, or only incidentally related
 to, the ordinary and typical activities of the entity and
 (b) not reasonably be expected to recur in the foreseeable
 future. The Company has adopted this update with no impact to the
 unaudited condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-09):
[0001193125-17-164153:note_history:28]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  | As of |  |  | As of |  |
|  |  |  |  |  |  |  | March 31, |  |  | June 24, |  |
| Rate (1) |  | Conditions |  | Maturity |  |  | 2017 |  |  | 2016 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  |  | April 2017 (2) |  |  | $ | 34,000 |  |  | $ | 6,500 |  |
| Short-term borrowings from bank: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank of England base rate +1.85% per annum |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  |  |  | 1,257 |  |  |  | — |  |
| Bank of England base rate + 2.2% per annum (3) |  | Repayable on monthly basis |  |  | May 2017 |  |  |  | 23 |  |  |  | — |  |
| Current portion of long-term borrowing |  |  |  |  |  |  |  |  | 13,600 |  |  |  | 18,100 |  |
|  |  |  |  |  |  |  |  |  | 48,880 |  |  |  | 24,600 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  |  |  | (222 | ) |  |  | (293 | ) |
|  |  |  |  |  |  |  |  | $ | 48,658 |  |  | $ | 24,307 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments |  |  | March 2017 |  |  | $ | — | (4) |  | $ | 4,500 |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  | Repayable in quarterly installments |  |  | May 2019 |  |  |  | 39,800 |  |  |  | 50,000 |  |
|  |  |  |  |  |  |  |  |  | 39,800 |  |  |  | 54,500 |  |
| Less: Current portion |  |  |  |  |  |  |  |  | (13,600 | ) |  |  | (18,100 | ) |
| Unamortized debt issuance costs |  |  |  |  |  |  |  |  | (141 | ) |  |  | (300 | ) |
| Non-current portion |  |  |  |  |  |  |  | $ | 26,059 |  |  | $ | 36,100 |  |
  (was, 2017-02-07, similarity 0.8934):
[0001193125-17-033383:note_history:28]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  | As of December 30, 2016 |  |  | As of June 24, 2016 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  | January 2017 (2) |  | $ | 20,000 |  |  | $ | 6,500 |  |
| Short-term loans from bank: |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank of England base rate +1.85% per annum |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  | 3,377 |  |  |  | — |  |
| Bank of England base rate + 2.2% per annum(3) |  | Repayable on monthly basis |  | May 2017 |  |  | 55 |  |  |  | — |  |
| Current portion of long-term borrowing |  |  |  |  |  |  | 15,100 |  |  |  | 18,100 |  |
|  |  |  |  |  |  |  | 38,532 |  |  |  | 24,600 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (245 | ) |  |  | (293 | ) |
|  |  |  |  |  |  | $ | 38,287 |  |  | $ | 24,307 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments |  | March 2017 |  | $ | 1,500 |  |  | $ | 4,500 |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  | Repayable in quarterly installments |  | May 2019 |  |  | 43,200 |  |  |  | 50,000 |  |
|  |  |  |  |  |  |  | 44,700 |  |  |  | 54,500 |  |
| Less: Current portion |  |  |  |  |  |  | (15,100 | ) |  |  | (18,100 | ) |
| Unamortized debt issuance costs |  |  |  |  |  |  | (188 | ) |  |  | (300 | ) |
| Non-current portion |  |  |  |  |  | $ | 29,412 |  |  | $ | 36,100 |  |

- changed (2017-05-09):
[0001193125-17-164153:note_history:29]
| (2) | In March 2017, the maturity date was extended to April 2017. |
  (was, 2017-02-07, similarity 0.8682):
[0001193125-17-033383:note_history:29]
| (2) | In December 2016, the maturity date was extended to January 2017. |

- changed (2017-05-09):
[0001193125-17-164153:note_history:30]
| (3) | As of March 31, 2017, the carrying amount of plant and machinery of Exception EMS secured to such loan was $0.8 million. Under the conditions stipulated in the loan agreement, this loan will be cross securitized, cross default and co-terminus with the short terms loans of $1.3 million which are secured by accounts receivable. |
  (was, 2017-02-07, similarity 0.9758):
[0001193125-17-033383:note_history:30]
| (3) | As of December 30, 2016, the carrying amount of plant and machinery of Exception EMS secured to such loan was $4.3 million. Under the conditions stipulated in the loan agreement, this loan will be cross securitized, cross default and co-terminus with the short terms of loans of $3.4 million which are secured by accounts receivable. |

- added (2017-05-09):
[0001193125-17-164153:note_history:31]
| (4) | In March 2017, a subsidiary fully repaid the long term borrowing. The carrying amount of assets secured and pledged as collateral to such loan as of March 31, 2017 and June 24, 2016 was $45.9 million and $47.7 million, respectively. In April 2017, the bank released certain property, plant and equipment of the subsidiary which had been secured and pledged as collateral to such loans. |

- changed (2017-05-09):
[0001193125-17-164153:note_history:32]
The movement of long-term borrowings was as follows for the nine
 months ended March 31, 2017 and March 25, 2016:
  (was, 2017-02-07, similarity 0.8155):
[0001193125-17-033383:note_history:32]
The movements of long-term loans were as follows for the six months
 ended December 30, 2016 and December 25, 2015:

- changed (2017-05-09):
[0001193125-17-164153:note_history:33]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 31, 2017 |  |  | March 25, 2016 |  |
| Opening balance |  | $ | 54,500 |  |  | $ | 10,500 |  |
| Repayments during the period |  |  | (14,700 | ) |  |  | (4,500 | ) |
| Closing balance |  | $ | 39,800 |  |  | $ | 6,000 |  |
  (was, 2017-02-07, similarity 0.6196):
[0001193125-17-033383:note_history:33]
| (amount in thousands) |  | December 30, 2016 |  |  | June 24, 2016 |  |
| Short-term |  | $ | 3,395 |  |  | $ | 1,414 |  |
| Long-term |  | $ | 136,800 |  |  | $ | 143,500 |  |

- changed (2017-05-09):
[0001193125-17-164153:note_history:34]
As of March 31, 2017, future maturities of long-term
 borrowings during each fiscal year were as follows:
  (was, 2017-02-07, similarity 0.8912):
[0001193125-17-033383:note_history:34]
As of December 30, 2016, future maturities of long-term debt
 during each fiscal year were as follows:

- changed (2017-05-09):
[0001193125-17-164153:note_history:35]
| (amount in thousands) |  |  |  |
| 2017 (remaining three months) |  | $ | 3,400 |  |
| 2018 |  |  | 13,600 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 39,800 |  |
  (was, 2017-02-07, similarity 0.9685):
[0001193125-17-033383:note_history:35]
| (amount in thousands) |  |  |  |
| 2017 (remaining six months) |  | $ | 8,300 |  |
| 2018 |  |  | 13,600 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 44,700 |  |

- added (2017-05-09):
[0001193125-17-164153:note_history:36]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. As of
 March 31, 2017, $34.0 million of the revolving borrowing and
 $39.8 million of the term loan borrowing was outstanding under the
 Facility Agreement, resulting in available credit facilities for
 long-term borrowing of $126.2 million. Borrowings under the
 revolving credit facility are classified as current liabilities in
 the unaudited condensed consolidated balance sheets as the Company
 has the periodic option to renew or pay, all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. During March 2017, the Company
 sent notices to the bank to renew the maturity date of its
 revolving borrowings. The bank approved the notices and extended
 the maturity to April 2017.

- changed (2017-05-09):
[0001193125-17-164153:note_history:37]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material of
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or the
 equivalent under the local law, can be effected.
  (was, 2017-02-07, similarity 0.998):
[0001193125-17-033383:note_history:37]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or the
 equivalent under the local law, can be effected.

- changed (2017-05-09):
[0001193125-17-164153:note_history:38]
The Facility Agreement contains customary affirmative and negative
 covenants. Negative covenants include, among other things,
 limitations on liens, indebtedness, investments, mergers, sales of
 assets, changes in the nature of the business, dividends and
 distributions, affiliate transactions and capital expenditures. The
 Facility Agreement contains financial covenants requiring Fabrinet
 to maintain: (1) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (2) a minimum debt service coverage ratio of
 not less than 1.50:1.00; (3) a maximum senior leverage ratio
 of not more than 2.50:1.00; and (4) a minimum quick ratio of
 not less than 1.10:1.00. Each of these financial covenants is
 calculated on a consolidated basis for the consecutive four fiscal
 quarter period then ended. As of March 31, 2017, the Company
 was in compliance with all covenants under the Facility
 Agreement.
  (was, 2017-02-07, similarity 0.993):
[0001193125-17-033383:note_history:38]
The Facility Agreement contains customary affirmative and negative
 covenants. Negative covenants include, among other things,
 limitations on liens, indebtedness, investments, mergers, sales of
 assets, changes in the nature of the business, dividends and
 distributions, affiliate transactions and capital expenditures. The
 Facility Agreement contains financial covenants requiring Fabrinet
 to maintain: (1) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (2) a minimum debt service coverage ratio of
 not less than 1.50:1.00; (3) a maximum senior leverage ratio
 of not more than 2.50:1.00; and (4) a minimum quick ratio of
 not less than 1.10:1.00. Each of these financial covenants is
 calculated on a consolidated basis for the consecutive four fiscal
 quarter period then ended. As of December 30, 2016, the
 Company was in compliance with all covenants under the Facility
 Agreement.

- changed (2017-05-09):
[0001193125-17-164153:note_history:39]
Short-term borrowings from bank
  (was, 2017-02-07, similarity 0.8421):
[0001193125-17-033383:note_history:39]
Short-term loans from bank

- changed (2017-05-09):
[0001193125-17-164153:note_history:40]
In connection with the acquisition of Exception EMS, the Company
 assumed a secured borrowing agreement that is secured by trade
 accounts receivable of Exception EMS. As of March 31, 2017,
 the carrying amount of trade accounts receivable secured to the
 loans was $5.6 million. The secured borrowing agreement contains
 certain covenants that Exception EMS is required to comply with:
 (1) the value of credit notes may not exceed 4% of the value
 of assigned debts measured on a monthly basis, and (2) rolling
 cash flow must be provided to the financial institution along with
 monthly management information. As of March 31, 2017, the
 subsidiary was in compliance with all covenants under the secured
 borrowing agreement.
  (was, 2017-02-07, similarity 0.9471):
[0001193125-17-033383:note_history:40]
In connection with the acquisition of Exception EMS, the Company
 assumed a secured borrowing agreement that is secured by trade
 accounts receivable of Exception EMS. As of December 30, 2016,
 the carrying amount of trade accounts receivable secured to the
 loans was $6.5 million. The secured borrowing agreement contains
 certain covenants that Exception EMS is required to comply with:
 (1) the value of credit notes may not exceed 4% of the value
 of assigned debts measured on a monthly basis, and (2) rolling
 cash flow must be provided with the monthly management information.
 As of December 30, 2016, the subsidiary was in compliance with
 all covenants under the secured borrowing agreement.

- changed (2017-05-09):
[0001193125-17-164153:note_history:41]
As of March 31, 2017, the Company drew down $1.3 million from
 this facility, which is recorded as short-term loans in the
 unaudited condensed consolidated balance sheets. The agreement
 bears interest for discount charge at 1.85% per annum above
 Bank of England base rate.
  (was, 2017-02-07, similarity 0.9751):
[0001193125-17-033383:note_history:41]
As of December 30, 2016, the Company drew down $3.4 million
 from this facility, which is recorded as short-term loans in the
 unaudited condensed consolidated balance sheets. The agreement
 bears interest for discount charge at 1.85% per annum above
 Bank of England base rate.

- changed (2017-05-09):
[0001193125-17-164153:note_history:42]
Undrawn available credit facilities classified by availability
 period of future borrowing as of March 31, 2017 and
 June 24, 2016 were as follows:
  (was, 2017-02-07, similarity 0.967):
[0001193125-17-033383:note_history:42]
Undrawn available credit facilities classified by availability
 period of future borrowing as of December 30, 2016 and
 June 24, 2016 were as follows:

- added (2017-05-09):
[0001193125-17-164153:note_history:43]
| (amount in thousands) |  | March 31, 2017 |  |  | June 24, 2016 |  |
| Short-term |  | $ | 4,799 |  |  | $ | 1,414 |  |
| Long-term |  | $ | 126,200 |  |  | $ | 143,500 |  |

- removed (2017-05-09):
[0001193125-17-033383:note_history:44]
Under the long-term borrowing contract of a subsidiary, the loan is
 secured by certain property, plant and equipment of the subsidiary.
 The carrying amount of assets secured and pledged as collateral to
 such loan as of December 30, 2016 and June 24, 2016 was
 $46.4 million and $47.7 million, respectively. This subsidiary is
 also required to comply with maximum ratios of debt to equity and
 minimum levels of debt service coverage ratios, and Fabrinet must
 maintain an effective shareholding ratio. The carrying amounts of
 bank borrowings approximate their fair value.

- removed (2017-05-09):
[0001193125-17-033383:note_history:45]
As of December 30, 2016 and June 24, 2016, the Company
 was in compliance with its bank borrowing agreements. In addition
 to financial ratios, certain of the Company’s credit
 facilities include customary events of default.

- removed (2017-05-09):
[0001193125-17-033383:note_history:46]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 30, 2016 |  |  | December 25, 2015 |  |
| Opening balance |  | $ | 54,500 |  |  | $ | 10,500 |  |
| Repayments during the period |  |  | (9,800 | ) |  |  | (3,000 | ) |
| Closing balance |  | $ | 44,700 |  |  | $ | 7,500 |  |

- removed (2017-05-09):
[0001193125-17-033383:note_history:47]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. As of
 December 30, 2016, $20.0 million of the revolving borrowing
 and $43.2 million of the term loan borrowing was outstanding under
 the Facility Agreement, resulting in available credit facilities of
 $136.8 million. Borrowings under the revolving credit facility are
 classified as current liabilities in the unaudited condensed
 consolidated balance sheets as the Company has the periodic option
 to renew or pay, all or a portion of, the outstanding balance at
 the end of the maturity date, which is in the range of one to six
 months, without premium or penalty, upon notice to the
 administrative agent. During December 2016, the Company sent
 notices to the bank to renew the maturity date of its revolving
 borrowings. The bank approved the notices and extended the maturity
 to January 2017.

- removed (2017-05-09):
[0001193125-17-033383:note_history:48]
As of December 30, 2016, Fabrinet had made a request to
 drawdown $14.0 million on its available outstanding revolving
 borrowing. The bank approved the request for drawdown and provided
 cash to settle this request to Fabrinet on January 3, 2017.
 Due to the settlement of the transaction taking place after the
 balance sheet date, the respective cash and loan amount are not
 recorded in the unaudited condensed consolidated balance sheet as
 of December 30, 2016.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-09):
[0001193125-17-164153:note_history:49]
The movement of long-term borrowings was as follows for the nine
 months ended March 31, 2017 and March 25, 2016:
  (was, 2017-02-07, similarity 0.8155):
[0001193125-17-033383:note_history:49]
The movements of long-term loans were as follows for the six months
 ended December 30, 2016 and December 25, 2015:

- added (2017-05-09):
[0001193125-17-164153:note_history:50]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 31, 2017 |  |  | March 25, 2016 |  |
| Opening balance |  | $ | 54,500 |  |  | $ | 10,500 |  |
| Repayments during the period |  |  | (14,700 | ) |  |  | (4,500 | ) |
| Closing balance |  | $ | 39,800 |  |  | $ | 6,000 |  |

- removed (2017-05-09):
[0001193125-17-033383:note_history:51]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 30, 2016 |  |  | December 25, 2015 |  |
| Opening balance |  | $ | 54,500 |  |  | $ | 10,500 |  |
| Repayments during the period |  |  | (9,800 | ) |  |  | (3,000 | ) |
| Closing balance |  | $ | 44,700 |  |  | $ | 7,500 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-09):
[0001193125-17-164153:note_history:52]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  | As of |  |  | As of |  |
|  |  |  |  |  |  |  | March 31, |  |  | June 24, |  |
| Rate (1) |  | Conditions |  | Maturity |  |  | 2017 |  |  | 2016 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  |  | April 2017 (2) |  |  | $ | 34,000 |  |  | $ | 6,500 |  |
| Short-term borrowings from bank: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank of England base rate +1.85% per annum |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  |  |  | 1,257 |  |  |  | — |  |
| Bank of England base rate + 2.2% per annum (3) |  | Repayable on monthly basis |  |  | May 2017 |  |  |  | 23 |  |  |  | — |  |
| Current portion of long-term borrowing |  |  |  |  |  |  |  |  | 13,600 |  |  |  | 18,100 |  |
|  |  |  |  |  |  |  |  |  | 48,880 |  |  |  | 24,600 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  |  |  | (222 | ) |  |  | (293 | ) |
|  |  |  |  |  |  |  |  | $ | 48,658 |  |  | $ | 24,307 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments |  |  | March 2017 |  |  | $ | — | (4) |  | $ | 4,500 |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  | Repayable in quarterly installments |  |  | May 2019 |  |  |  | 39,800 |  |  |  | 50,000 |  |
|  |  |  |  |  |  |  |  |  | 39,800 |  |  |  | 54,500 |  |
| Less: Current portion |  |  |  |  |  |  |  |  | (13,600 | ) |  |  | (18,100 | ) |
| Unamortized debt issuance costs |  |  |  |  |  |  |  |  | (141 | ) |  |  | (300 | ) |
| Non-current portion |  |  |  |  |  |  |  | $ | 26,059 |  |  | $ | 36,100 |  |
  (was, 2017-02-07, similarity 0.8934):
[0001193125-17-033383:note_history:52]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  | As of December 30, 2016 |  |  | As of June 24, 2016 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  | January 2017 (2) |  | $ | 20,000 |  |  | $ | 6,500 |  |
| Short-term loans from bank: |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank of England base rate +1.85% per annum |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  | 3,377 |  |  |  | — |  |
| Bank of England base rate + 2.2% per annum(3) |  | Repayable on monthly basis |  | May 2017 |  |  | 55 |  |  |  | — |  |
| Current portion of long-term borrowing |  |  |  |  |  |  | 15,100 |  |  |  | 18,100 |  |
|  |  |  |  |  |  |  | 38,532 |  |  |  | 24,600 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (245 | ) |  |  | (293 | ) |
|  |  |  |  |  |  | $ | 38,287 |  |  | $ | 24,307 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments |  | March 2017 |  | $ | 1,500 |  |  | $ | 4,500 |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  | Repayable in quarterly installments |  | May 2019 |  |  | 43,200 |  |  |  | 50,000 |  |
|  |  |  |  |  |  |  | 44,700 |  |  |  | 54,500 |  |
| Less: Current portion |  |  |  |  |  |  | (15,100 | ) |  |  | (18,100 | ) |
| Unamortized debt issuance costs |  |  |  |  |  |  | (188 | ) |  |  | (300 | ) |
| Non-current portion |  |  |  |  |  | $ | 29,412 |  |  | $ | 36,100 |  |

- changed (2017-05-09):
[0001193125-17-164153:note_history:53]
| (2) | In March 2017, the maturity date was extended to April 2017. |
  (was, 2017-02-07, similarity 0.8682):
[0001193125-17-033383:note_history:53]
| (2) | In December 2016, the maturity date was extended to January 2017. |

- changed (2017-05-09):
[0001193125-17-164153:note_history:54]
| (3) | As of March 31, 2017, the carrying amount of plant and machinery of Exception EMS secured to such loan was $0.8 million. Under the conditions stipulated in the loan agreement, this loan will be cross securitized, cross default and co-terminus with the short terms loans of $1.3 million which are secured by accounts receivable. |
  (was, 2017-02-07, similarity 0.9758):
[0001193125-17-033383:note_history:54]
| (3) | As of December 30, 2016, the carrying amount of plant and machinery of Exception EMS secured to such loan was $4.3 million. Under the conditions stipulated in the loan agreement, this loan will be cross securitized, cross default and co-terminus with the short terms of loans of $3.4 million which are secured by accounts receivable. |

- added (2017-05-09):
[0001193125-17-164153:note_history:55]
| (4) | In March 2017, a subsidiary fully repaid the long term borrowing. The carrying amount of assets secured and pledged as collateral to such loan as of March 31, 2017 and June 24, 2016 was $45.9 million and $47.7 million, respectively. In April 2017, the bank released certain property, plant and equipment of the subsidiary which had been secured and pledged as collateral to such loans. |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-09):
[0001193125-17-164153:note_history:56]
Undrawn available credit facilities classified by availability
 period of future borrowing as of March 31, 2017 and
 June 24, 2016 were as follows:
  (was, 2017-02-07, similarity 0.967):
[0001193125-17-033383:note_history:56]
Undrawn available credit facilities classified by availability
 period of future borrowing as of December 30, 2016 and
 June 24, 2016 were as follows:

- changed (2017-05-09):
[0001193125-17-164153:note_history:57]
| (amount in thousands) |  | March 31, 2017 |  |  | June 24, 2016 |  |
| Short-term |  | $ | 4,799 |  |  | $ | 1,414 |  |
| Long-term |  | $ | 126,200 |  |  | $ | 143,500 |  |
  (was, 2017-02-07, similarity 0.9665):
[0001193125-17-033383:note_history:57]
| (amount in thousands) |  | December 30, 2016 |  |  | June 24, 2016 |  |
| Short-term |  | $ | 3,395 |  |  | $ | 1,414 |  |
| Long-term |  | $ | 136,800 |  |  | $ | 143,500 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-09):
[0001193125-17-164153:note_history:58]
As of March 31, 2017, future maturities of long-term
 borrowings during each fiscal year were as follows:
  (was, 2017-02-07, similarity 0.8912):
[0001193125-17-033383:note_history:58]
As of December 30, 2016, future maturities of long-term debt
 during each fiscal year were as follows:

- changed (2017-05-09):
[0001193125-17-164153:note_history:59]
| (amount in thousands) |  |  |  |
| 2017 (remaining three months) |  | $ | 3,400 |  |
| 2018 |  |  | 13,600 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 39,800 |  |
  (was, 2017-02-07, similarity 0.9685):
[0001193125-17-033383:note_history:59]
| (amount in thousands) |  |  |  |
| 2017 (remaining six months) |  | $ | 8,300 |  |
| 2018 |  |  | 13,600 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 44,700 |  |
