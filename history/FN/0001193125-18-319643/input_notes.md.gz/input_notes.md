# FN notes — 0001193125-18-319643


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-18-319643:notes:1]
[same as prior period, unchanged from 0001193125-18-155969:notes:70]

[0001193125-18-319643:notes:2]
[same as prior period, unchanged from 0001193125-18-155969:notes:71]

[0001193125-18-319643:notes:3]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of September 28, 2018 and for the
 three months ended September 28, 2018 and September 29,
 2017 includes normal recurring adjustments, necessary for a fair
 statement of the financial statements set forth herein, in
 accordance with accounting principles generally accepted in the
 United States of America (“U.S. GAAP”) for interim
 financial information and the rules and regulations of the
 Securities and Exchange Commission (“SEC”).
 Accordingly, such information does not include all of the
 information and footnotes required by U.S. GAAP for annual
 financial statements. For further information, please refer to the
 consolidated financial statements and footnotes thereto included in
 Fabrinet’s Annual Report on
 Form 10-K for the year
 ended June 29, 2018.

[0001193125-18-319643:notes:4]
The balance sheet as of June 29, 2018 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three months
 ended September 28, 2018 may not be indicative of results for
 the year ending June 28, 2019 or any future periods.

[0001193125-18-319643:notes:5]
[same as prior period, unchanged from 0001193125-18-155969:notes:75]

[0001193125-18-319643:notes:6]
[same as prior period, unchanged from 0001193125-18-155969:notes:76]

[0001193125-18-319643:notes:7]
[same as prior period, unchanged from 0001193125-18-155969:notes:77]

[0001193125-18-319643:notes:8]
The Company utilizes a 52-53 week fiscal
 year ending on the Friday in June closest to June 30. The three
 months ended September 28, 2018 and September 29, 2017
 each consisted of 13 weeks. Fiscal year 2019 will be comprised of
 52 weeks and will end on June 28, 2019.

[0001193125-18-319643:notes:9]
Changes in Accounting Policies

[0001193125-18-319643:notes:10]
Except for the adoption of the new revenue recognition accounting
 standard described below and as disclosed in Note 3—Revenue,
 the Company has consistently applied the accounting policies to all
 periods presented in these condensed consolidated financial
 statements.

[0001193125-18-319643:notes:11]
Adoption of New Accounting Standard

[0001193125-18-319643:notes:12]
On June 30, 2018, the Company adopted Revenue from Contracts
 with Customers (Topic 606), which created Accounting Standards
 Codification Topic 606 (“ASC 606”), using the modified
 retrospective method applied to those contracts which were not
 completed as of June 29, 2018. The modified retrospective
 method requires the Company to recognize the cumulative effect of
 the adoption of ASC 606, for all contracts with customers, to the
 opening balance of equity at June 30, 2018. Accordingly, the
 Company’s comparative financial information as
 of June 29, 2018 has not been adjusted and continues
 to be reported under ASC 605, Revenue Recognition (“ASC
 605”).

[0001193125-18-319643:notes:13]
The cumulative effect adjustment recorded was based on the timing
 difference of revenue recognition between ASC 605 and ASC 606
 related to certain manufacturing contracts with vendor managed
 inventory arrangements. Under ASC 605, revenue for such
 contracts was recognized at the earlier of when the inventory was
 consumed by the customers or if not consumed, on the expiration of
 time specified in the contract. On adoption of ASC 606, revenue is
 recognized when inventory is shipped to the customers.

[0001193125-18-319643:notes:14]
The following table shows the impact of adoption of ASC 606 on
 adoption date of June 29, 2018 on the unaudited condensed
 consolidated balance sheets:

[0001193125-18-319643:notes:15]
Condensed Consolidated Balance Sheets

[0001193125-18-319643:notes:16]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | Balance at June 29, 2018 |  |  | Adjustment |  |  | Balance at June 30, 2018 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract assets |  | $ | — |  |  | $ | 9,877 | (1) |  | $ | 9,877 |  |
| Inventory, net |  | $ | 257,687 |  |  | $ | (8,672 | )(2) |  | $ | 249,015 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 632,423 |  |  | $ | 1,205 | (3) |  | $ | 633,628 |  |

[0001193125-18-319643:notes:17]
| (1) | Majority of adjustment relates to certain manufacturing contracts with vendor managed inventory arrangements for which revenue was recognized on shipment. |

[0001193125-18-319643:notes:18]
| (2) | Adjustment relates to reduction of finished goods inventory for certain vendor managed inventory arrangements. |

[0001193125-18-319643:notes:19]
| (3) | Adjustment relates to cumulative effect adjustment upon adoption of ASC 606. |

[0001193125-18-319643:notes:20]
[same as prior period, unchanged from 0001193125-18-155969:notes:79]

[0001193125-18-319643:notes:21]
Financial instruments that potentially subject the Company to
 concentrations of credit risk consist of cash and cash equivalents,
 marketable securities, derivatives, accounts receivable and
 contract assets.

[0001193125-18-319643:notes:22]
Cash, cash equivalents, and marketable securities are maintained
 with several financial institutions. Deposits held with banks may
 exceed the amount of insurance provided on such deposits.
 Generally, these deposits may be redeemed upon demand and are
 maintained with financial institutions with reputable credit and
 therefore bear minimal credit risk. The Company seeks to mitigate
 its credit risks by spreading such risks across multiple
 counterparties and monitoring the risk profiles of these
 counterparties. The Company limits its investments in marketable
 securities to securities with a maturity not in excess of three
 years, and all marketable securities that the Company invests in
 are rated A1, P-1, F1, or
 better.

[0001193125-18-319643:notes:23]
[same as prior period, unchanged from 0001193125-18-155969:notes:82]

[0001193125-18-319643:notes:24]
[same as prior period, unchanged from 0001193125-18-155969:notes:83]

[0001193125-18-319643:notes:25]
In August 2018, the Financial Accounting Standards Board
 (“FASB”) issued ASU 2018-13, “Fair
 Value Measurement (Topic 820), Disclosure Framework – Changes
 to the Disclosure Requirements for Fair Value Measurement. This ASU
 is intended to improve the effectiveness of disclosures in the
 notes to the financial statements including 1) the development of a
 framework that promotes consistent decisions by the Board about
 disclosure requirements and 2) the appropriate exercise of
 discretion by reporting entities. The amendment modifies the
 disclosure requirements on transferring between level 1 and level 2
 and valuation processes of level 3 fair value measurements. The
 amendments in this update are effective for all entities for fiscal
 years, and interim periods within those fiscal years, beginning
 after December 15, 2019. The Company is currently evaluating
 the impact of the adoption of this update on its consolidated
 financial statements.

[0001193125-18-319643:notes:26]
In July 2018, the FASB issued ASU 2018-11, “Leases
 (Topic 842), Target Improvements.” This ASU provided guidance
 on comparative reporting requirements for initial adoption. This
 ASU also provides additional guidance for lessors, on separating
 lease and non-lease components
 in a contract and allocating the consideration in the contract to
 the separate components. For public business entities, this update
 is effective for fiscal years beginning after December 15,
 2018, including interim periods within those fiscal years. Early
 adoption is permitted. The Company is currently evaluating the
 impact of the adoption of this update on its consolidated financial
 statements.

[0001193125-18-319643:notes:27]
In July 2018, the FASB issued ASU 2018-10, “Codification
 Improvements to Topic 842, Leases.” The amendment in this
 update affects narrow aspects of the guidance issued in the
 amendments in update 2016-02 on various
 matters. For public business entities, this update is effective for
 fiscal years beginning after December 15, 2018, including
 interim periods within those fiscal years. Early adoption is
 permitted. The Company is currently evaluating the impact of the
 adoption of this update on its consolidated financial
 statements.

[0001193125-18-319643:notes:28]
In January 2017, the FASB issued ASU 2017-04, “Intangibles
 – Goodwill and Other (Topic 350): Simplifying the Test for
 Goodwill Impairment.” This amendment modified the concept of
 impairment assessment from the condition that exists when the
 carrying amount of goodwill exceeds its implied fair value to the
 condition that exists when the carrying amount of a reporting unit
 exceeds its fair value. Public companies that are SEC filers should
 adopt the amendment for its annual and any interim goodwill
 impairment tests in fiscal years beginning after December 15,
 2019. Early adoption is permitted for interim or annual goodwill
 impairment tests performed on testing dates after January 1,
 2017. The Company does not expect the amendments will impact its
 consolidated financial statements.

[0001193125-18-319643:notes:29]
In February 2016, the FASB issued
 ASU 2016-02, “Lease
 (Topic 842).” The core principle of Topic 842 is that a
 lessee should recognize the lease assets and liabilities that arise
 from leases in the statement of financial position. For public
 business entities, this update is effective for fiscal years
 beginning after December 15, 2018, including interim periods
 within those fiscal years. Early application is permitted. The
 Company is currently evaluating the impact of the adoption of this
 update on its consolidated financial statements.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-18-319643:notes:30]
The following table summarizes the cost and estimated fair value of
 marketable securities classified as available-for-sale securities
 based on stated effective maturities as of September 28,
 2018:

[0001193125-18-319643:notes:31]
| (amount in thousands) |  | Carrying Cost |  |  | Fair Value |  |
| Due within one year |  | $ | 16,403 |  |  | $ | 16,350 |  |
| Due between one to three years |  |  | 117,297 |  |  |  | 116,033 |  |
| Total |  | $ | 133,700 |  |  | $ | 132,383 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-18-319643:notes:32]
| 9. | Business acquisition |

[0001193125-18-319643:notes:33]
On September 14, 2016, the Company acquired 100% shareholding
 in Fabrinet UK (formerly known as Exception EMS), a privately-held
 group located in Wiltshire, United Kingdom, for cash
 consideration of approximately $13.0 million, net of
 $0.5 million cash acquired. Fabrinet UK provides contract
 electronics manufacturing services to the global electronics
 industry with innovative solutions, adding value to the design,
 manufacture and testing of printed circuit board assemblies.
 Pursuant to the acquisition agreement, the Company has placed
 $3.4 million of cash, net of foreign currency translation
 adjustment, for deferred consideration in an escrow account which
 was under the Company control. On September 15, 2018, the cash
 was released from the escrow account to the sellers.

[0001193125-18-319643:notes:34]
[same as prior period, unchanged from 0001193125-18-155969:notes:122]

[0001193125-18-319643:notes:35]
The allocation of consideration to the individual net assets
 acquired was finalized in the fourth quarter of fiscal year
 2017.

[0001193125-18-319643:notes:36]
[same as prior period, unchanged from 0001193125-18-155969:notes:124]

[0001193125-18-319643:notes:37]
[same as prior period, unchanged from 0001193125-18-155969:notes:125]

[0001193125-18-319643:notes:38]
In connection with the Company’s acquisition of Fabrinet UK,
 the Company assumed lease agreements for certain machine and
 equipment, which are accounted for as capital leases. As of
 September 28, 2018 and June 29, 2018, the Company
 included approximately $1.3 million and $1.4 million,
 respectively, of capital lease assets and $0.8 million and
 $1.0 million, respectively, of capital lease liability in the
 unaudited condensed consolidated balance sheets associated with
 these acquired lease agreements.

[0001193125-18-319643:notes:39]
[same as prior period, unchanged from 0001193125-18-155969:notes:129]

[0001193125-18-319643:notes:40]
[same as prior period, unchanged from 0001193125-18-155969:notes:130]

[0001193125-18-319643:notes:41]
[same as prior period, unchanged from 0001193125-18-155969:notes:131]

[0001193125-18-319643:notes:42]
Customer relationships represent the fair value of future projected
 revenues that were derived from the sale of products to existing
 customers of the acquired company. The fair value of
 $4.4 million will be amortized, using the accelerated method,
 over an estimated useful life of ten years.

[0001193125-18-319643:notes:43]
Backlog represents the fair value of sales orders backlog as of the
 valuation date. The fair value of $0.1 million will be
 amortized, using an accelerated amortization method, over the
 respective estimated useful life of three years.

[0001193125-18-319643:notes:44]
[same as prior period, unchanged from 0001193125-18-155969:notes:134]

[0001193125-18-319643:notes:45]
[same as prior period, unchanged from 0001193125-18-155969:notes:135]


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001193125-18-319643:notes:46]
| 5. | Cash, cash equivalents and marketable securities |

[0001193125-18-319643:notes:47]
[same as prior period, unchanged from 0001193125-18-155969:notes:94]

[0001193125-18-319643:notes:48]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Gain/(Loss) |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of September 28, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 201,795 |  |  | $ | — |  |  | $ | 201,795 |  |  | $ | — |  |
| Cash equivalents |  |  | 18,181 |  |  |  | — |  |  |  | 18,181 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 96,810 |  |  |  | (887 | ) |  |  | — |  |  |  | 95,923 |  |
| U.S. agency and U.S. treasury securities |  |  | 34,122 |  |  |  | (377 | ) |  |  | — |  |  |  | 33,745 |  |
| Sovereign and municipal securities |  |  | 2,768 |  |  |  | (53 | ) |  |  | — |  |  |  | 2,715 |  |
| Total |  | $ | 353,676 |  |  | $ | (1,317 | ) |  | $ | 219,976 |  |  | $ | 132,383 |  |

[0001193125-18-319643:notes:49]
|  |  |  |  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Gain/(Loss) |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of June 29, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 146,778 |  |  | $ | — |  |  | $ | 146,778 |  |  | $ | — |  |
| Cash equivalents |  |  | 11,324 |  |  |  | — |  |  |  | 11,324 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 128,441 |  |  |  | (736 | ) |  |  | — |  |  |  | 127,705 |  |
| U.S. agency and U.S. treasury securities |  |  | 43,734 |  |  |  | (324 | ) |  |  | — |  |  |  | 43,410 |  |
| Sovereign and municipal securities |  |  | 3,185 |  |  |  | (31 | ) |  |  | — |  |  |  | 3,154 |  |
| Total |  | $ | 333,462 |  |  | $ | (1,091 | ) |  | $ | 158,102 |  |  | $ | 174,269 |  |

[0001193125-18-319643:notes:50]
All highly liquid investments with original maturities of three
 months or less at the date of purchase are classified as cash
 equivalents. Management determines the appropriate classification
 of its investments at the time of purchase and re-evaluates the designations at each
 balance sheet date. The Company may sell certain of its marketable
 securities prior to their stated maturities for strategic reasons
 including, but not limited to, anticipation of credit deterioration
 and duration management. The maturities of the Company’s
 marketable securities generally range from three months to three
 years. The Company’s investments in marketable securities
 consist of investments in U.S. Treasuries and fixed income
 securities and have been classified and accounted for as
 available-for-sale.

[0001193125-18-319643:notes:51]
During the three months ended September 28, 2018, the Company
 recognized a realized gain of $0.1 million from sales and
 maturities of available-for-sale.

[0001193125-18-319643:notes:52]
As of September 28, 2018, the Company considered the declines
 in market value of its marketable securities investment portfolio
 to be temporary in nature and did not consider any of its
 securities other-than-temporarily impaired. The Company typically
 invests in highly-rated securities, and its investment policy
 generally limits the amount of credit exposure to any one issuer.
 The policy requires investments generally to be investment grade,
 with the primary objective of minimizing the potential risk of
 principal loss. Fair values were determined for each individual
 security in the investment portfolio. When evaluating an investment
 for other-than-temporary impairment, the Company reviews factors
 such as the length of time and extent to which fair value has been
 below its cost basis, the financial condition of the issuer and any
 changes thereto, changes in market interest rates, and the
 Company’s intent to sell, or whether it is more likely than
 not it will be required to sell, the investment before recovery of
 the investment’s cost basis. No impairment losses were
 recorded for the three months ended September 28, 2018.

[0001193125-18-319643:notes:53]
As of September 28, 2018, cash, cash equivalents, and
 marketable securities included bank deposits of $40.0 million
 held in various financial institutions located in the United States
 in order to support the availability of the Facility Agreement (as
 defined in Note 12) and comply with covenants. Under the terms and
 conditions of the Facility Agreement, the Company shall maintain
 cash, cash equivalents and/or marketable securities in an aggregate
 amount not less than $40.0 million in unencumbered deposits,
 and/or securities in accounts located in the United States at all
 times during the term of the Facility Agreement. As discussed in
 Note 12, the Company must comply with this covenant from and after
 the effective date of the Facility Agreement.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-18-319643:notes:54]
17. Commitments and contingencies

[0001193125-18-319643:notes:55]
Bank guarantees

[0001193125-18-319643:notes:56]
As of September 28, 2018 and June 29, 2018, there were
 outstanding bank guarantees given by a bank on behalf of our
 subsidiary in Thailand for electricity usage and other normal
 business amounting to $1.5 million.

[0001193125-18-319643:notes:57]
Operating lease commitments

[0001193125-18-319643:notes:58]
The Company leases a portion of its capital equipment, vehicles,
 and certain land and buildings for its facilities in Thailand,
 Cayman Islands, China, the United States and the United Kingdom
 under operating lease arrangements that expire in various years
 through 2023. Rental expense under these operating leases amounted
 to $0.5 million and $0.5 million for the three months
 ended September 28, 2018 and September 29, 2017,
 respectively.

[0001193125-18-319643:notes:59]
As of September 28, 2018, the future minimum lease payments
 due under non-cancelable
 operating leases during each fiscal year were as follows:

[0001193125-18-319643:notes:60]
| (amount in thousands) |  |  |  |
| 2019 (remaining nine months) |  | $ | 1,396 |  |
| 2020 |  |  | 1,721 |  |
| 2021 |  |  | 1,320 |  |
| 2022 |  |  | 1,204 |  |
| 2023 |  |  | 1,195 |  |
| Thereafter |  |  | 230 |  |
| Total minimum operating lease payments |  | $ | 7,066 |  |

[0001193125-18-319643:notes:61]
Capital lease commitments

[0001193125-18-319643:notes:62]
In connection with the acquisition of Fabrinet UK, the Company
 assumed the capital lease commitments of several machines and
 equipment, with various expiration dates until September 2020. The
 equipment can be purchased at the determined prices upon expiration
 of such contracts.

[0001193125-18-319643:notes:63]
As of September 28, 2018, the future minimum lease payments
 due under non-cancelable
 capital leases during each fiscal year were as follows:

[0001193125-18-319643:notes:64]
| (amount in thousands) |  |  |  |
| 2019 (remaining nine months) |  | $ | 333 |  |
| 2020 |  |  | 410 |  |
| 2021 |  |  | 105 |  |
| 2022 |  |  | — |  |
| Total minimum capital lease payments |  | $ | 848 |  |

[0001193125-18-319643:notes:65]
Purchase obligations

[0001193125-18-319643:notes:66]
Purchase obligations represent legally-binding commitments to
 purchase inventory and other commitments made in the normal course
 of business to meet operational requirements. Although open
 purchase orders are considered enforceable and legally binding,
 their terms generally give the Company the option to cancel,
 reschedule and/or adjust its requirements based on its business
 needs prior to the delivery of goods or performance of services.
 Obligations to purchase inventory and other commitments are
 generally expected to be fulfilled within one year.

[0001193125-18-319643:notes:67]
On December 23, 2016, the Company entered into an agreement to
 purchase a parcel of land in Chonburi, Thailand, to support the
 expansion of the Company’s production in Thailand. The
 aggregate purchase price was approximately $5.6 million, of
 which the first installment of $1.1 million was paid by the
 Company on January 10, 2017 and the remainder was fully paid
 on December 25, 2017.

[0001193125-18-319643:notes:68]
As of September 28, 2018, the Company had an outstanding
 commitment to third parties of $4.9 million.

[0001193125-18-319643:notes:69]
Indemnification of directors and officers

[0001193125-18-319643:notes:70]
Cayman Islands law does not limit the extent to which a
 company’s memorandum and articles of association may provide
 for indemnification of directors and officers, except to the extent
 any such provision may be held by the Cayman Islands courts to be
 contrary to public policy, such as to provide indemnification
 against civil fraud or the consequences of committing a crime.
 Fabrinet’s amended and restated memorandum and articles of
 association provide for indemnification of directors and officers
 for actions, costs, charges, losses, damages and expenses incurred
 in their capacities as such, except that such indemnification does
 not extend to any matter in respect of any fraud or dishonesty that
 may attach to any of them.

[0001193125-18-319643:notes:71]
In accordance with Fabrinet’s form of indemnification
 agreement for its directors and officers, Fabrinet has agreed to
 indemnify its directors and officers against certain liabilities
 and expenses incurred by such persons in connection with claims by
 reason of their being such a director or officer. Fabrinet
 maintains a director and officer liability insurance policy that
 may enable it to recover a portion of any future amounts paid under
 the indemnification agreements.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-18-319643:notes:72]
16. Accumulated other comprehensive income (loss)

[0001193125-18-319643:notes:73]
The changes in AOCI for the three months ended September 28,
 2018 were as follows:

[0001193125-18-319643:notes:74]
| (amount in thousands) |  | Unrealized net (Losses) Gains on Marketable Securities |  |  | Unrealized net (Losses) Gains on Derivative Instruments |  |  | Foreign Currency Translation Adjustment |  |  | Total |  |
| Balance as of June 29, 2018 |  | $ | (1,091 | ) |  | $ | 33 |  |  | $ | (199 | ) |  | $ | (1,257 | ) |
| Other comprehensive income before reclassification adjustment |  |  | 591 |  |  |  | — |  |  |  | (200 | ) |  |  | 391 |  |
| Amounts reclassified out of AOCI to foreign exchange loss in the unaudited condensed consolidated statements of operations and comprehensive income |  |  | (303 | ) |  |  | (1 | ) |  |  | — |  |  |  | (304 | ) |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income (loss) |  | $ | 288 |  |  | $ | (1 | ) |  | $ | (200 | ) |  | $ | 87 |  |
| Balance as of September 28, 2018 |  | $ | (803 | ) |  | $ | 32 |  |  | $ | (399 | ) |  | $ | (1,170 | ) |
| (amount in thousands) |  | Unrealized net (Losses) Gains on Marketable Securities |  |  | Unrealized net (Losses) Gains on Derivative Instruments |  |  | Foreign Currency Translation Adjustment |  |  | Total |  |
| Balance as of June 30, 2017 |  | $ | (72 | ) |  | $ | 34 |  |  | $ | (310 | ) |  | $ | (348 | ) |
| Other comprehensive income before reclassification adjustment |  |  | 382 |  |  |  | — |  |  |  | 526 |  |  |  | 908 |  |
| Amounts reclassified out of AOCI to foreign exchange loss in the unaudited condensed consolidated statements of operations and comprehensive income |  |  | (353 | ) |  |  | (1 | ) |  |  | — |  |  |  | (354 | ) |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income (loss) |  | $ | 29 |  |  | $ | (1 | ) |  | $ | 526 |  |  | $ | 554 |  |
| Balance as of September 29, 2017 |  | $ | (43 | ) |  | $ | 33 |  |  | $ | 216 |  |  | $ | 206 |  |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001193125-18-319643:notes:75]
The following table summarizes the activity in the Company’s
 contract assets during the three-month period ended
 September 29, 2018:

[0001193125-18-319643:notes:76]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 30, 2018 |  | $ | — |  |
| Cumulative effect adjustment at June 30, 2018 |  |  | 9,877 |  |
| Revenue recognized |  |  | 27,954 |  |
| Amounts collected or invoiced |  |  | (27,674 | ) |
| Ending balance, September 28, 2018 |  | $ | 10,157 |  |


## us-gaap:DebtDisclosureTextBlock

[0001193125-18-319643:notes:77]
| 12. | Borrowings |

[0001193125-18-319643:notes:78]
The Company’s total borrowings, including short-term and
 long-term borrowings, consisted of the following:

[0001193125-18-319643:notes:79]
| Rate (1) |  | Conditions |  |  | Maturity |  |  | As of September 28, 2018 |  |  | As of June 29, 2018 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current portion of long-term borrowing |  |  | $ | 3,250 |  |  | $ | 3,250 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.50% per annum |  |  | Repayable in quarterly installments |  |  |  | June 2023 |  |  | $ | 63,375 |  |  | $ | 64,188 |  |
|  |  |  |  |  |  |  |  |  |  |  | 63,375 |  |  |  | 64,188 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (3,250 | ) |  |  | (3,250 | ) |
| Non-current portion of long-term borrowings |  |  |  |  |  |  |  |  |  | $ | 60,125 |  |  | $ | 60,938 |  |

[0001193125-18-319643:notes:80]
| (1) | LIBOR is London Interbank Offered Rate. |

[0001193125-18-319643:notes:81]
The movements of long-term borrowings for the three months ended
 September 28, 2018 and September 29, 2017 were as
 follows:

[0001193125-18-319643:notes:82]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 28, 2018 |  |  | September 29, 2017 |  |
| Opening balance |  | $ | 64,188 |  |  | $ | 36,400 |  |
| Repayments during the period |  |  | (813 | ) |  |  | (3,400 | ) |
| Closing balance |  | $ | 63,375 |  |  | $ | 33,000 |  |

[0001193125-18-319643:notes:83]
As of September 28, 2018, future maturities of long-term
 borrowings during each fiscal year were as follows:

[0001193125-18-319643:notes:84]
| (amount in thousands) |  |  |  |  |
| 2019 (remaining nine months) |  | $ | 2,438 |  |
| 2020 |  |  | 3,250 |  |
| 2021 |  |  | 3,250 |  |
| 2022 |  |  | 3,250 |  |
| 2023 |  |  | 51,187 |  |
| Total |  | $ | 63,375 |  |

[0001193125-18-319643:notes:85]
Credit facilities:

[0001193125-18-319643:notes:86]
The Company entered into a syndicated senior credit facility
 agreement (the “Facility Agreement”) with a consortium
 of banks on May 22, 2014. The Facility Agreement, led by Bank
 of America, provided for a $200.0 million credit line,
 comprised of a $150.0 million revolving loan facility and a
 $50.0 million delayed draw term loan facility. The revolving
 loan facility contains an accordion feature permitting Fabrinet to
 request an increase in the facility up to $100.0 million
 subject to customary terms and conditions and provided that no
 default or event of default exists at the time of request.

[0001193125-18-319643:notes:87]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. This
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. On
 July 22, 2016, the Company entered into the Fourth Amendment
 to the Facility Agreement to change the timing of filing certain
 financial information with the bank.

[0001193125-18-319643:notes:88]
Loans under the Facility Agreement bear interest, at
 Fabrinet’s option, at a rate per annum equal to a LIBOR rate
 plus a spread of 1.75% to 2.50%, or a base rate, determined in
 accordance with the Facility Agreement, plus a spread of 0.75% to
 1.50%, in each case with such spread determined based on
 Fabrinet’s consolidated total leverage ratio for the
 preceding four fiscal quarter period. Interest is due and payable
 quarterly in arrears for loans bearing interest at the base rate
 and at the end of an interest period (or at each three-month
 interval in the case of loans with interest periods greater than
 three months) in the case of loans bearing interest at the LIBOR
 rate.

[0001193125-18-319643:notes:89]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or
 the equivalent under the local law, can be effected.

[0001193125-18-319643:notes:90]
The Facility Agreement contains customary affirmative and negative
 covenants. Negative covenants include, among other things,
 limitations on liens, indebtedness, investments, mergers, sales of
 assets, changes in the nature of the business, dividends and
 distributions, affiliate transactions and capital expenditures. The
 Facility Agreement contains financial covenants requiring Fabrinet
 to maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage ratio
 of not more than 2.50:1.00; and (iv) a minimum quick ratio of
 not less than 1.10:1.00. Each of these financial covenants is
 calculated on a consolidated basis for the consecutive four fiscal
 quarter period then ended.

[0001193125-18-319643:notes:91]
The Facility Agreement also contains customary events of default
 including, among other things, payment defaults, breaches of
 covenants or representations and warranties, cross-defaults with
 certain other indebtedness, bankruptcy and insolvency events and
 change in control of Fabrinet, subject to grace periods in certain
 instances. Upon an event of default, the lenders may terminate
 their commitments, declare all or a portion of the outstanding
 obligations payable by Fabrinet to be immediately due and payable
 and exercise other rights and remedies provided for under the
 Facility Agreement.

[0001193125-18-319643:notes:92]
On June 4, 2018, the Company entered into the Fifth Amendment
 to the Facility Agreement to (i) reduce the revolving
 commitments thereunder from $150.0 million to
 $25.0 million, (ii) extend the termination date of the
 revolving commitments from May 22, 2019 to June 4, 2023,
 (iii) refinance the then-existing term loan and revolving loans
 under the Facility Agreement into a $65.0 million term loan
 and (iv) reduce the applicable interest rate margins and
 commitment fees. Term loans must be repaid in quarterly
 installments, beginning on June 30, 2018, with the remaining
 outstanding principal and accrued and unpaid interest being due and
 payable on June 4, 2023. After giving effect to the amendment,
 $65.0 million aggregate principal amount of term loans and no
 revolving loans were outstanding under the Facility Agreement as of
 June 28, 2018. In addition, the Fifth Amendment to the
 Facility Agreement contains an accordion feature permitting the
 Company to request an increase in the revolving loan facility to
 provide up to an aggregate of $200.0 million in additional
 commitments, subject to customary terms and conditions, and
 provided that no default or event of default exists at the time of
 such request. The Fifth Amendment is considered debt extinguishment
 of which the Company recognized interest expenses of
 $0.1 million from remaining unamortized debt issuance costs in
 consolidated statements of operations and comprehensive income. As
 of September 28, 2018 and June 29, 2018,
 $63.4 million and $64.2 million aggregate principal
 amount of term loans and no revolving loans were outstanding under
 the Facility Agreement.

[0001193125-18-319643:notes:93]
After the Fifth Amendment, loans under the Facility Agreement bear
 interest, at Fabrinet’s option, at a rate per annum equal to
 a LIBOR rate plus a spread of 1.50% to 2.25%, or a base rate plus a
 spread of 0.50% to 1.25%, determined in accordance with the
 Facility Agreement in each case with such spread determined based
 on Fabrinet’s consolidated total leverage ratio for the
 preceding four fiscal quarter period.

[0001193125-18-319643:notes:94]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future material direct
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $20.0 million in a jurisdiction where a control agreement, or
 the equivalent under the local law, can be effected.

[0001193125-18-319643:notes:95]
Moreover, the Fifth Amendment of Facility Agreement amends
 customary affirmative and negative covenants. Negative covenants
 include, among other things, limitations on liens, indebtedness,
 investments, mergers, sales of assets, changes in the nature of the
 business, dividends and distributions, affiliate transactions and
 capital expenditures. The Facility Agreement contains financial
 covenants requiring Fabrinet to maintain: (1) a minimum
 tangible net worth of not less than $338.0 million plus 50% of
 quarterly net income after June 30, 2018, exclusive of
 quarterly losses; (2) a minimum debt service coverage ratio of
 not less than 1.50:1.00; (3) a maximum total leverage ratio of not
 more than 2.50:1.00; and (4) a minimum quick ratio of not less
 than 1.10:1.00. Each of these financial covenants is calculated on
 a consolidated basis for the consecutive four fiscal quarter period
 then ended. As of September 28, 2018, the Company was in
 compliance with all covenants under the Facility Agreement.

[0001193125-18-319643:notes:96]
Fabrinet intends to use the proceeds of the credit line to finance
 its future expansion in the United States and Thailand, and for
 general corporate purposes including mergers and acquisitions of
 complementary manufacturing businesses or technology, although
 Fabrinet has no current commitments with respect to any such
 acquisitions.

[0001193125-18-319643:notes:97]
On July 24, 2017, the Company entered into an interest rate
 swap agreement (the “Swap Agreement”), which the
 Company did not designate as hedging instruments. The Swap
 Agreement was used to mitigate interest rate risk and improve the
 interest rate profile of the Company’s debt obligations. The
 terms of the Swap Agreement effectively converted the floating
 interest rate of the term loans under the Facility Agreement to the
 fixed interest rate of 1.55% per annum through maturity of the term
 loan in May 2019. On June 4, 2018, the Company terminated the
 Swap Agreement in connection with entering into the Fifth Amendment
 to the Facility Agreement.

[0001193125-18-319643:notes:98]
On July 25, 2018, the Company entered into Swap Agreement,
 which the Company did not designate as hedging instruments. The
 Swap Agreement was used to mitigate interest rate risk and improve
 the interest rate profile of the Company’s debt obligations.
 The terms of the Swap Agreement effectively converted the floating
 interest rate of the term loans under the Facility Agreement to the
 fixed interest rate of 2.86% per annum through maturity of the term
 loan in June 2023. The swap transactions are due and settled
 monthly. During the three months ended September 28, 2018, the
 Company included a net loss of $33 thousand from the
 settlement of the Swap Agreement as interest expenses in the
 unaudited condensed consolidated statements of operations and
 comprehensive income.

[0001193125-18-319643:notes:99]
Undrawn available credit facilities classified by availability
 period of future borrowing as of September 28, 2018 and
 June 29, 2018 were as follows:

[0001193125-18-319643:notes:100]
| (amount in thousands) |  | September 28, 2018 |  |  | June 29, 2018 |  |
| Expiring within one year |  | $ | — |  |  | $ | — |  |
| Expiring beyond one year |  | $ | 25,000 |  |  | $ | 25,000 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001193125-18-319643:notes:101]
The following table presents total revenues by geographic
 regions:

[0001193125-18-319643:notes:102]
| (amount in thousands) |  | Three Months Ended September 28, 2018 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 179,826 |  |  |  | 47.7 | % |
| Asia-Pacific |  |  | 151,947 |  |  |  | 40.3 |  |
| Europe |  |  | 45,404 |  |  |  | 12.0 |  |
|  |  | $ | 377,177 |  |  |  | 100.0 | % |


## us-gaap:EarningsPerShareTextBlock

[0001193125-18-319643:notes:103]
| 4. | Earnings per ordinary share |

[0001193125-18-319643:notes:104]
[same as prior period, unchanged from 0001193125-18-155969:notes:163]

[0001193125-18-319643:notes:105]
|  |  | Three Months Ended |  |
| (amount in thousands except per share amounts) |  | September 28, 2018 |  |  | September 29, 2017 |  |
| Net income attributable to shareholders |  | $ | 27,850 |  |  | $ | 21,033 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  | 36,625 |  |  |  | 37,447 |  |
| Incremental shares arising from the assumed exercise of share options and vesting of restricted share units and performance share units (thousands of shares) |  |  | 515 |  |  |  | 716 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 37,140 |  |  |  | 38,163 |  |
| Basic earnings per ordinary share |  | $ | 0.76 |  |  | $ | 0.56 |  |
| Diluted earnings per ordinary share |  | $ | 0.75 |  |  | $ | 0.55 |  |
| Outstanding performance share units excluded in the computation of diluted earnings per ordinary share (thousands of shares) (1) |  |  | 351 |  |  |  | — |  |

[0001193125-18-319643:notes:106]
| (1) | These performance share units were not included in the computation of diluted earnings per ordinary share because they are not expected to vest based on the Company’s current assessment of the related performance obligations. |

[0001193125-18-319643:notes:107]
As of September 28, 2018 and September 29, 2017, there
 were no anti-dilutive share options.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-18-319643:notes:108]
| 14. | Share-based compensation |

[0001193125-18-319643:notes:109]
[same as prior period, unchanged from 0001193125-18-155969:notes:22]

[0001193125-18-319643:notes:110]
In determining the grant date fair value of share equity awards,
 the Company is required to make estimates of expected dividends to
 be issued, expected volatility of Fabrinet’s ordinary shares,
 expected forfeitures of the awards, risk free interest rates for
 the expected term of the awards and expected terms of the awards.
 Forfeitures are estimated at the time of grant and revised if
 necessary in subsequent periods if actual forfeitures differ from
 those estimates. The grant date fair value of restricted share
 units and performance share units is based on the market value of
 our ordinary shares on the date of grant.

[0001193125-18-319643:notes:111]
The effect of recording share-based compensation expense for the
 three months ended September 28, 2018 and September 29,
 2017 was as follows:

[0001193125-18-319643:notes:112]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 28, 2018 |  |  | September 29, 2017 |  |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |  |
| Restricted share units |  | $ | 4,685 |  |  | $ | 4,847 |  |
| Performance share units |  |  | 295 |  |  |  | 2,073 |  |
| Total share-based compensation expense |  |  | 4,980 |  |  |  | 6,920 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 4,980 |  |  | $ | 6,920 |  |

[0001193125-18-319643:notes:113]
[same as prior period, unchanged from 0001193125-18-155969:notes:26]

[0001193125-18-319643:notes:114]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 28, 2018 |  |  | September 29, 2017 |  |
| Cost of revenue |  | $ | 1,847 |  |  | $ | 1,901 |  |
| Selling, general and administrative expense |  |  | 3,133 |  |  |  | 5,019 |  |
| Total share-based compensation expense |  | $ | 4,980 |  |  | $ | 6,920 |  |

[0001193125-18-319643:notes:115]
The Company did not capitalize any share-based compensation expense
 as part of any asset costs during the three months ended
 September 28, 2018 and September 29, 2017.

[0001193125-18-319643:notes:116]
[same as prior period, unchanged from 0001193125-18-155969:notes:29]

[0001193125-18-319643:notes:117]
Fabrinet maintains the following equity incentive plans: the
 Amended and Restated 2010 Performance Incentive Plan (the
 “2010 Plan”) and the 2017 Inducement Equity Incentive
 Plan (the “2017 Inducement Plan”). 2010 Plan and 2017
 Inducement Plan are collectively referred to as the “Share
 Option Plans.”

[0001193125-18-319643:notes:118]
On December 14, 2017, Fabrinet’s shareholders approved
 amendments to the 2010 Plan to increase the number of ordinary
 shares authorized for issuance under the 2010 Plan by 2,100,000
 shares. As of September 28, 2018, there were an aggregate of
 881,146 restricted share units outstanding and 455,358 performance
 share units outstanding under the 2010 Plan. As of
 September 28, 2018, there were 1,968,456 ordinary shares
 available for future grant under the 2010 Plan.

[0001193125-18-319643:notes:119]
On November 2, 2017, Fabrinet adopted the 2017 Inducement Plan
 with a reserve of 160,000 ordinary shares authorized for future
 issuance solely for the granting of inducement share options and
 equity awards to new key employee. The 2017 Inducement Plan was
 adopted without shareholder approval in reliance on the
 “employment inducement exemption” provided under the
 rules of the New York Stock Exchange. As of September 28,
 2018, there were an aggregate of 48,653 restricted share units
 outstanding and 97,306 performance share units outstanding under
 the 2017 Inducement Plan. As of September 28, 2018, there were
 14,041 ordinary shares available for future grant under the 2017
 Inducement Plan.

[0001193125-18-319643:notes:120]
[same as prior period, unchanged from 0001193125-18-155969:notes:33]

[0001193125-18-319643:notes:121]
Fabrinet’s board of directors has the authority to determine
 the type of option and the number of shares subject to an option.
 Options generally vest and become exercisable over four years and
 expire, if not exercised, within seven years of the grant date. In
 the case of a grantee’s first grant, 25 percent of the
 underlying shares vest 12 months after the vesting commencement
 date and 1/48 of the underlying shares vest monthly over each of
 the subsequent 36 months. In the case of any additional grants
 to a grantee, 1/48 of the underlying shares vest monthly over four
 years, commencing one month after the vesting commencement date.
 Share options have been granted to directors and employees.

[0001193125-18-319643:notes:122]
[same as prior period, unchanged from 0001193125-18-155969:notes:35]

[0001193125-18-319643:notes:123]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 29, 2018 |  |  | 2,900 |  |  |  | 2,900 |  |  | $ | 15.16 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Forfeited |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Expired |  |  | (2,900 | ) |  |  |  |  |  | $ | 15.16 |  |  |  |  |  |
| Balance as of September 28, 2018 |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |

[0001193125-18-319643:notes:124]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 30, 2017 |  |  | 96,688 |  |  |  | 96,688 |  |  | $ | 15.70 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (58,531 | ) |  |  |  |  |  | $ | 15.91 |  |  |  |  |  |
| Forfeited |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Expired |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Balance as of September 29, 2017 |  |  | 38,157 |  |  |  | 38,157 |  |  | $ | 15.38 |  |  |  |  |  |

[0001193125-18-319643:notes:125]
As of September 28, 2018, there was no unrecognized
 compensation cost under the Share Option Plans.

[0001193125-18-319643:notes:126]
[same as prior period, unchanged from 0001193125-18-155969:notes:41]

[0001193125-18-319643:notes:127]
[same as prior period, unchanged from 0001193125-18-155969:notes:42]

[0001193125-18-319643:notes:128]
Restricted share units granted to employees generally vest in equal
 installments over three or four years on each anniversary of the
 vesting commencement date. Restricted share units granted
 to non-employee directors
 generally cliff vest 100% on the first of January, approximately
 one year from the grant date, provided the director continues to
 serve through such date.

[0001193125-18-319643:notes:129]
Performance share units granted to executives will vest, if at all,
 at the end of a two-year performance
 period based on the Company’s achievement
 of pre-defined performance
 criteria, which consist of revenue and gross margin targets. The
 actual number of performance share units that may vest at the end
 of the performance period ranges from 0% to 100% of the award
 grant.

[0001193125-18-319643:notes:130]
The following table summarizes restricted share unit activity under
 the 2010 Plan and 2017 Inducement Plan:

[0001193125-18-319643:notes:131]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 29, 2018 |  |  | 1,073,580 |  |  | $ | 35.19 |  |
| Granted |  |  | 255,821 |  |  | $ | 48.02 |  |
| Issued |  |  | (369,757 | ) |  | $ | 34.34 |  |
| Forfeited |  |  | (29,845 | ) |  | $ | 38.32 |  |
| Balance as of September 28, 2018 |  |  | 929,799 |  |  | $ | 38.95 |  |

[0001193125-18-319643:notes:132]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 30, 2017 |  |  | 1,058,605 |  |  | $ | 31.59 |  |
| Granted |  |  | 321,405 |  |  | $ | 39.35 |  |
| Issued |  |  | (259,033 | ) |  | $ | 26.17 |  |
| Forfeited |  |  | (12,967 | ) |  | $ | 35.33 |  |
| Balance as of September 29, 2017 |  |  | 1,108,010 |  |  | $ | 35.07 |  |

[0001193125-18-319643:notes:133]
The following table summarizes performance share unit activity
 under the 2010 Plan and 2017 Inducement Plan:

[0001193125-18-319643:notes:134]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 29, 2018 |  |  | 605,892 |  |  | $ | 38.41 |  |
| Granted |  |  | 201,994 |  |  | $ | 48.02 |  |
| Issued |  |  | (227,268 | ) |  | $ | 40.48 |  |
| Forfeited |  |  | (27,954 | ) |  | $ | 39.35 |  |
| Balance as of September 28, 2018 |  |  | 552,664 |  |  | $ | 41.02 |  |

[0001193125-18-319643:notes:135]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 30, 2017 |  |  | 227,268 |  |  | $ | 40.48 |  |
| Granted |  |  | 281,318 |  |  | $ | 39.95 |  |
| Issued |  |  | — |  |  |  | — |  |
| Forfeited |  |  | — |  |  |  | — |  |
| Balance as of September 29, 2017 |  |  | 508,586 |  |  | $ | 39.86 |  |

[0001193125-18-319643:notes:136]
As of September 28, 2018, there was $20.0 million and
 $7.9 million of unrecognized share-based compensation expense
 related to restricted share units and performance share units,
 respectively, under the 2010 Plan and the 2017 Inducement Plan that
 is expected to be recorded over a weighted-average period of 2.9
 years and 1.9 years, respectively.

[0001193125-18-319643:notes:137]
For the three months ended September 28, 2018 and
 September 29, 2017, the Company withheld an aggregate of
 201,877 shares and 85,758 shares, respectively, upon the vesting of
 restricted share units, based upon the closing share price on the
 vesting date to settle the employees’ minimum statutory
 obligation for the applicable income and other employment taxes.
 For the three months ended September 28, 2018 and
 September 29, 2017, the Company then remitted cash of
 $8.9 million and $3.6 million, respectively, to the
 appropriate taxing authorities, and presented it as a financing
 activity within the unaudited condensed consolidated statements of
 cash flows. The payment had the effect on shares issued by the
 Company as it reduced the number of shares that would have been
 issued on the vesting date and was recorded as a reduction of
 additional paid-in capital.


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001193125-18-319643:notes:138]
[same as prior period, unchanged from 0001193125-18-155969:notes:166]

[0001193125-18-319643:notes:139]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of September 28, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 18,181 |  |  | $ | — |  |  | $ | 18,181 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 95,923 |  |  |  | — |  |  |  | 95,923 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 33,745 |  |  |  | — |  |  |  | 33,745 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 2,715 |  |  |  | — |  |  |  | 2,715 |  |
| Derivative assets |  |  | — |  |  |  | 249 | (1) |  |  | — |  |  |  | 249 |  |
| Total |  | $ | — |  |  | $ | 150,813 |  |  | $ | — |  |  | $ | 150,813 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001193125-18-319643:notes:140]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 29, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 11,324 |  |  | $ | — |  |  | $ | 11,324 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 127,705 |  |  |  | — |  |  |  | 127,705 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 43,410 |  |  |  | — |  |  |  | 43,410 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 3,154 |  |  |  | — |  |  |  | 3,154 |  |
| Derivative assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | — |  |  | $ | 185,593 |  |  | $ | — |  |  | $ | 185,593 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 1,745 | (2) |  | $ | — |  |  | $ | 1,745 |  |
| Total |  | $ | — |  |  | $ | 1,745 |  |  | $ | — |  |  | $ | 1,745 |  |

[0001193125-18-319643:notes:141]
| (1) | Foreign currency forward contracts with a notional amount of $6.0 million. Foreign currency option contracts with a notional amount of $19.0 million. |

[0001193125-18-319643:notes:142]
| (2) | Foreign currency forward contracts with a notional amount of $7.0 million and Canadian dollars 0.4 million. Foreign currency option contracts with a notional amount of $30.0 million. |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-18-319643:notes:143]
| 6. | Fair value of financial instruments |

[0001193125-18-319643:notes:144]
[same as prior period, unchanged from 0001193125-18-155969:notes:171]

[0001193125-18-319643:notes:145]
[same as prior period, unchanged from 0001193125-18-155969:notes:172]

[0001193125-18-319643:notes:146]
[same as prior period, unchanged from 0001193125-18-155969:notes:173]

[0001193125-18-319643:notes:147]
[same as prior period, unchanged from 0001193125-18-155969:notes:174]

[0001193125-18-319643:notes:148]
[same as prior period, unchanged from 0001193125-18-155969:notes:175]

[0001193125-18-319643:notes:149]
[same as prior period, unchanged from 0001193125-18-155969:notes:176]

[0001193125-18-319643:notes:150]
As a result of foreign currency rate fluctuations, the U.S. dollar
 equivalent values of the Company’s foreign currency
 denominated assets and liabilities are changed. The Company uses
 foreign currency contracts to manage the foreign exchange risk
 associated with certain foreign currency denominated assets and
 liabilities and other foreign currency transactions. The Company
 minimizes the credit risk in derivative instruments by limiting its
 exposure to any single counterparty and by entering into derivative
 instruments only with counterparties that meet the Company’s
 minimum credit quality standard. As of September 28, 2018, the
 Company recognized the fair value of foreign currency forward
 contracts of $0.2 million as derivative assets in the
 unaudited condensed consolidated balance sheets under other current
 assets. As of June 29, 2018, the Company recognized the fair
 value of foreign currency forward contracts of $1.7 million as
 derivative liabilities in the consolidated balance sheets under
 other current liabilities.

[0001193125-18-319643:notes:151]
As of September 28, 2018 and June 29, 2018, the Company
 had no foreign currency forward contracts designated as cash flow
 hedges.

[0001193125-18-319643:notes:152]
As of September 28, 2018, the Company had three outstanding
 foreign currency forward contracts with a notional amount of
 $6.0 million, and six outstanding foreign currency option
 contracts with a notional amount of $19.0 million with
 maturity dates from October through December 2018. These foreign
 currency forward contracts and option contracts were not designated
 for hedge accounting and were used to hedge fluctuations in the
 U.S. dollar value of forecasted transactions denominated in Thai
 baht. During the three months ended September 28, 2018, the
 Company included unrealized gain of $0.2 million from changes
 in the fair value of foreign currency contracts in earnings as
 foreign exchange gain, net in the unaudited condensed consolidated
 statements of operations and comprehensive income.

[0001193125-18-319643:notes:153]
As of September 29, 2017, the Company had 15 outstanding
 foreign currency forward contracts with a notional amount of
 $26.0 million and Canadian dollars 0.6 million, maturing
 during October to December 2017. These foreign currency forward
 contracts were not designated for hedge accounting and were used to
 hedge fluctuations in the U.S. dollar value of forecasted
 transactions denominated in Thai baht and Canadian dollar. During
 the three months ended September 29, 2017, the Company
 included unrealized loss of $0.4 million from changes in the
 fair value of foreign currency contracts in earnings as foreign
 exchange loss in the unaudited condensed consolidated statements of
 operations and comprehensive income.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-18-319643:notes:154]
| 13. | Income taxes |

[0001193125-18-319643:notes:155]
As of September 28, 2018 and June 29, 2018, the liability
 for uncertain tax positions including accrued interest and
 penalties was $2.4 million and $2.3 million,
 respectively. The Company expects the estimated amount of liability
 associated with its uncertain tax positions to decrease within the
 next 12 months due to the lapse of the applicable statute of
 limitations in foreign tax jurisdictions.

[0001193125-18-319643:notes:156]
The Company files income tax returns in the United States and
 foreign tax jurisdictions. The tax years from 2013 to 2017 remain
 open to examination by U.S. federal and state, and foreign tax
 authorities. The Company’s income tax is recognized based on
 the best estimate of the expected annual effective tax rate for the
 full financial year of each entity in the Company, adjusted for
 discrete items arising in that quarter. If the Company’s
 estimated annual effective tax rate changes, the Company makes a
 cumulative adjustment in that quarter.

[0001193125-18-319643:notes:157]
The effective tax rate for the Company for the three months ended
 September 28, 2018 and September 29, 2017 was 6.7% and
 6.3%, respectively, of net income. The increase was primarily due
 to the fact that the Company had higher income subject to tax
 during the first quarter of fiscal year 2019 as compared to the
 same period in fiscal year 2018.


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-18-319643:notes:158]
| 11. | Goodwill |

[0001193125-18-319643:notes:159]
The changes in the carrying amount of goodwill from the acquisition
 of Fabrinet UK were as follows:

[0001193125-18-319643:notes:160]
| (amount in thousands) |  | Goodwill |  |
| Balance as of June 29, 2018 |  | $ | 3,828 |  |
| Foreign currency translation adjustment |  |  | (6 | ) |
| Balance as of September 28, 2018 |  | $ | 3,822 |  |

[0001193125-18-319643:notes:161]
| (amount in thousands) |  | Goodwill |  |
| Balance as of June 30, 2017 |  | $ | 3,806 |  |
| Foreign currency translation adjustment |  |  | 22 |  |
| Balance as of June 29, 2018 |  | $ | 3,828 |  |

[0001193125-18-319643:notes:162]
Goodwill is not deductible for tax purposes. Goodwill is reviewed
 annually for impairment or more frequently whenever changes or
 circumstances indicate the carrying amount of goodwill may not be
 recoverable.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001193125-18-319643:notes:163]
| 7. | Trade accounts receivable, net |

[0001193125-18-319643:notes:164]
| (amount in thousands) |  | As of September 28, 2018 |  |  | As of June 29, 2018 |  |
| Trade accounts receivable |  | $ | 258,766 |  |  | $ | 246,972 |  |
| Less: allowance for doubtful account |  |  | (61 | ) |  |  | (60 | ) |
| Trade accounts receivable, net |  | $ | 258,705 |  |  | $ | 246,912 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-18-319643:notes:165]
| 8. | Inventory |

[0001193125-18-319643:notes:166]
| (amount in thousands) |  | As of September 28, 2018 |  |  | As of June 29, 2018 |  |
| Raw materials |  | $ | 105,736 |  |  | $ | 100,241 |  |
| Work in progress |  |  | 136,042 |  |  |  | 121,797 |  |
| Finished goods |  |  | 18,802 |  |  |  | 20,690 |  |
| Goods in transit |  |  | 19,896 |  |  |  | 17,516 |  |
|  |  |  | 280,476 |  |  |  | 260,244 |  |
| Less: Inventory obsolescence |  |  | (2,079 | ) |  |  | (2,557 | ) |
| Inventory, net |  | $ | 278,397 |  |  | $ | 257,687 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-18-319643:notes:167]
| 10. | Intangibles |

[0001193125-18-319643:notes:168]
[same as prior period, unchanged from 0001193125-18-155969:notes:150]

[0001193125-18-319643:notes:169]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net |  |
| As of September 28, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 6,304 |  |  | $ | (4,461 | ) |  | $ | — |  |  | $ | 1,843 |  |
| Customer relationships |  |  | 4,373 |  |  |  | (1,592 | ) |  |  | (44 | ) |  |  | 2,737 |  |
| Backlog |  |  | 119 |  |  |  | (109 | ) |  |  | — |  |  |  | 10 |  |
| Total intangibles |  | $ | 10,796 |  |  | $ | (6,162 | ) |  | $ | (44 | ) |  | $ | 4,590 |  |

[0001193125-18-319643:notes:170]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net |  |
| As of June 29, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 6,269 |  |  | $ | (4,324 | ) |  | $ | — |  |  | $ | 1,945 |  |
| Customer relationships |  |  | 4,373 |  |  |  | (1,413 | ) |  |  | (42 | ) |  |  | 2,918 |  |
| Backlog |  |  | 119 |  |  |  | (101 | ) |  |  | (1 | ) |  |  | 17 |  |
| Total intangibles |  | $ | 10,761 |  |  | $ | (5,838 | ) |  | $ | (43 | ) |  | $ | 4,880 |  |

[0001193125-18-319643:notes:171]
The Company recorded amortization expense relating to intangibles
 of $0.3 million and $0.3 million for the three months
 ended September 28, 2018 and September 29, 2017,
 respectively.

[0001193125-18-319643:notes:172]
[same as prior period, unchanged from 0001193125-18-155969:notes:153]

[0001193125-18-319643:notes:173]
| (years) |  | As of September 28, 2018 |  |  | As of June 29, 2018 |  |
| Customer relationships |  |  | 5.9 |  |  |  | 6.1 |  |
| Backlog |  |  | 0.7 |  |  |  | 0.9 |  |

[0001193125-18-319643:notes:174]
Based on the carrying amount of intangibles as of
 September 28, 2018, and assuming no future impairment of the
 underlying assets, the estimated future amortization during each
 fiscal year was as follows:

[0001193125-18-319643:notes:175]
| (amount in thousands) |  |  |  |  |
| 2019 (remaining nine months) |  | $ | 935 |  |
| 2020 |  |  | 1,098 |  |
| 2021 |  |  | 951 |  |
| 2022 |  |  | 717 |  |
| 2023 |  |  | 453 |  |
| Thereafter |  |  | 436 |  |
| Total |  | $ | 4,590 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001193125-18-319643:notes:176]
| 3. | Revenues |

[0001193125-18-319643:notes:177]
The Company derives total revenues primarily from the assembly of
 products under supply agreements with its customers and the
 fabrication of customized optics and glass. The Company recognizes
 revenue relating to contracts with customers that depicts the
 transfer of promised goods or services to customers in an amount
 reflecting the consideration to which the Company expects to be
 entitled in exchange for such goods or services. In order to meet
 this requirement, the Company applies the following five steps:
 (1) identify the contract with a customer, (2) identify
 the performance obligations in the contract, (3) determine the
 transaction price, (4) allocate the transaction price to the
 performance obligations in the contract, and (5) recognize
 revenue when a performance obligation is satisfied. Revenue is
 recognized net of any taxes collected from customers, which is
 subsequently remitted to governmental authorities.

[0001193125-18-319643:notes:178]
A performance obligation is a promise in a contract to transfer a
 distinct good or service to the customer. In contracts with
 multiple performance obligations, the Company identifies each
 performance obligation and evaluates whether the performance
 obligation is distinct within the context of the contract at
 contract inception. The majority of the Company’s contracts
 have a single performance obligation as the promise to transfer the
 individual goods or services is not separately identifiable from
 other promises in the contracts and, therefore, not distinct.

[0001193125-18-319643:notes:179]
The Company manufactures products that are customized to
 customers’ specifications, however, control of the products
 is typically transferred to the customer at the point in time the
 product is either shipped or delivered, depending on the terms of
 the arrangement, as the criteria for overtime recognition are not
 met. On the evaluation of the contracts the Company identified that
 it did not have contractual rights to bill profit for work in
 progress in the event of a contract termination which is expected
 to be infrequent. Further, in limited circumstances,
 substantive acceptance by the customer exists which results in the
 deferral of revenue until acceptance is formally received from the
 customer. Judgment may be required in determining if the acceptance
 clause is substantive.

[0001193125-18-319643:notes:180]
Certain customers may request the Company to store finished
 products purchased by them at the Company’s
 warehouse. In these instances, the Company receives a written
 request from the customer asking the Company to hold the inventory
 at the Company’s warehouse and the ordered goods cannot be
 used to fulfill other customer orders. In these situations,
 revenue is only recognized when the goods are completed and ready
 for shipment and transferred to the Company’s warehouse.

[0001193125-18-319643:notes:181]
Our customers generally are obligated to purchase finished goods
 that we have manufactured according to their demand requirements.
 Materials that are not consumed by our customers within a specified
 period of time, or are no longer required due to a product’s
 cancellation or end-of-life, are typically
 designated as excess or obsolete inventory under our contracts.
 Once materials are designated as either excess or obsolete
 inventory, our customers are typically required to purchase such
 inventory from us even if they have chosen to cancel production of
 the related products. The excess or obsolete inventory is shipped
 to the customer and revenue is recognized upon shipment.

[0001193125-18-319643:notes:182]
A contract’s transaction price is allocated to each distinct
 performance obligation and recognized as revenue when, or as, the
 performance obligation is satisfied. In determining the
 transaction price, the Company evaluates whether the price is
 subject to refund or adjustment to determine the net consideration
 to which the Company expects to be entitled. The Company generally
 does not grant return privileges, except for defective products
 during the warranty period. The Company generally provides a
 warranty of between one to five years on the product.

[0001193125-18-319643:notes:183]
Warranty provision

[0001193125-18-319643:notes:184]
Provisions for estimated expenses relating to product warranties
 are made at the time the products are sold using historical
 experience. Generally, this warranty is limited to workmanship and
 the Company’s liability is capped at the price of the
 product. The provisions will be adjusted when experience indicates
 an expected settlement will differ from initial estimates.

[0001193125-18-319643:notes:185]
Contract Assets and Liabilities

[0001193125-18-319643:notes:186]
A contract asset is recognized when the Company has recognized
 revenues, but not yet an invoice for payment. Contract assets are
 classified separately on the condensed consolidated balance sheets
 and transferred to accounts receivable when rights to payment
 become unconditional. The following table summarizes the activity
 in the Company’s contract assets during the three-month
 period ended September 29, 2018:

[0001193125-18-319643:notes:187]
The Company continually evaluates whether advanced payment
 arrangements with customers result in the recognition of contract
 liabilities. No such liabilities existed as of September 28,
 2018 or June 29, 2018. Separately, accounts receivable, net,
 represents receivables from contracts with customers.

[0001193125-18-319643:notes:188]
Contract Costs

[0001193125-18-319643:notes:189]
The Company has elected the practical expedient to recognize the
 incremental costs of obtaining a contract as an expense when
 incurred if the amortization period of the asset that the Company
 otherwise would have recognized is one year or less. During the
 three months ended September 28, 2018, the Company did not
 have any incremental costs of obtaining the contract.

[0001193125-18-319643:notes:190]
Shipping and Handling

[0001193125-18-319643:notes:191]
Shipping costs billed to customers are recorded as revenue.
 Shipping and handling expense related to costs incurred to deliver
 product are recognized within cost of goods sold. The Company
 accounts for shipping and handling activities that occur after
 control has transferred as a fulfillment cost as opposed to a
 separate performance obligation, and the costs of shipping and
 handling are recognized concurrently with the related revenue.

[0001193125-18-319643:notes:192]
In accordance with the new revenue standard requirements, the
 disclosure of the impact of adoption on the Company’s
 unaudited condensed consolidated statements of operations and
 comprehensive income for the three months ended September 28,
 2018 and unaudited condensed consolidated balance sheets as of
 September 28, 2018 was as follows:

[0001193125-18-319643:notes:193]
Condensed Consolidated Statement of Operations

[0001193125-18-319643:notes:194]
Three Months Ended September 28, 2018

[0001193125-18-319643:notes:195]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | As Reported |  |  | Adjustment |  |  | Balance without ASC 606 Adoption |  |
| Revenues |  | $ | 377,177 |  |  | $ | (280 | )(1) |  | $ | 376,897 |  |
| Cost of revenues |  | $ | (336,901 | ) |  | $ | 249 | (2) |  | $ | (336,652 | ) |
| Gross profit |  | $ | 40,276 |  |  | $ | (31 | )(3) |  | $ | 40,245 |  |
| Net income |  | $ | 27,850 |  |  | $ | (31 | )(3) |  | $ | 27,819 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.76 |  |  | $ | (0.00 | ) |  | $ | 0.76 |  |
| Diluted |  | $ | 0.75 |  |  | $ | (0.00 | ) |  | $ | 0.75 |  |

[0001193125-18-319643:notes:196]
| (1) | Adjustment relates to certain manufacturing contracts with vendor managed inventory arrangements for which revenue was recognized at shipping. |

[0001193125-18-319643:notes:197]
| (2) | Adjustment relates to costs associated with revenue recognized. |

[0001193125-18-319643:notes:198]
| (3) | Adjustment relates to net impact on income upon adoption of ASC 606. |

[0001193125-18-319643:notes:199]
As of September 28, 2018

[0001193125-18-319643:notes:200]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | As Reported |  |  | Adjustments |  |  | Balance without ASC 606 Adoption |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract assets |  | $ | 10,157 |  |  | $ | (10,157 | )(1) |  | $ | — |  |
| Inventory, net |  | $ | 278,397 |  |  | $ | 8,921 | (2) |  | $ | 287,318 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 661,478 |  |  | $ | (1,236 | )(3) |  | $ | 660,242 |  |

[0001193125-18-319643:notes:201]
| (2) | Adjustment relates to reduction of finished goods inventory for vendor managed inventory. |

[0001193125-18-319643:notes:202]
Revenue by Geographic Area:

[0001193125-18-319643:notes:203]
Total revenues are attributed to a particular geographic area based
 on the bill-to-location of
 the customers. The Company operates primarily in three geographic
 regions: North America, Asia-Pacific and Europe. The following
 table presents total revenues by geographic regions:

[0001193125-18-319643:notes:204]
The following table sets forth our revenues by end market.

[0001193125-18-319643:notes:205]
| (amount in thousands) |  | Three Months Ended September 28, 2018 |  |  | As a % of Total Revenues |  |
| Optical communications |  | $ | 280,768 |  |  |  | 74.4 | % |
| Lasers, sensors and other |  |  | 96,409 |  |  |  | 25.6 |  |
| Total |  | $ | 377,177 |  |  |  | 100.0 | % |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-18-319643:notes:206]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 28, 2018 |  |  | September 29, 2017 |  |
| North America |  | $ | 179,826 |  |  | $ | 156,991 |  |
| Asia-Pacific |  |  | 151,947 |  |  |  | 142,863 |  |
| Europe |  |  | 45,404 |  |  |  | 57,459 |  |
|  |  | $ | 377,177 |  |  | $ | 357,313 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-18-319643:notes:207]
| 18. | Business segments and geographic information |

[0001193125-18-319643:notes:208]
Operating segments are defined as components of an enterprise for
 which separate financial information is available that is evaluated
 regularly by the chief operating decision maker in deciding how to
 allocate resources and in assessing performance. The
 Company’s chief operating decision maker is Fabrinet’s
 chief executive officer. As of September 28, 2018, the Company
 operated and internally managed a single operating segment.
 Accordingly, the Company does not accumulate discrete information
 with respect to separate product lines and does not have separate
 reportable segments.

[0001193125-18-319643:notes:209]
[same as prior period, unchanged from 0001193125-18-155969:notes:185]

[0001193125-18-319643:notes:210]
As of September 28, 2018 and September 29, 2017, the
 Company had approximately $32.5 million and
 $35.0 million, respectively, of long-lived assets based in
 North America, with the substantial remainder of assets based in
 Asia-Pacific and Europe.

[0001193125-18-319643:notes:211]
[same as prior period, unchanged from 0001193125-18-155969:notes:187]

[0001193125-18-319643:notes:212]
The Company had a customer and two customers that contributed to
 10% or more of its total trade accounts receivable as of
 September 28, 2018 and June 29, 2018, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-18-319643:notes:213]
| 15. | Shareholders’ equity |

[0001193125-18-319643:notes:214]
[same as prior period, unchanged from 0001193125-18-155969:notes:156]

[0001193125-18-319643:notes:215]
Fabrinet’s authorized share capital is 500,000,000 ordinary
 shares, par value of $0.01 per ordinary share, and 5,000,000
 preferred shares, par value of $0.01 per preferred share.

[0001193125-18-319643:notes:216]
For the three months ended September 28, 2018, Fabrinet issued
 395,148 ordinary shares upon the vesting of restricted share units,
 net of shares withheld.

[0001193125-18-319643:notes:217]
For the three months ended September 29, 2017, Fabrinet issued
 58,531 ordinary shares upon the exercise of options, for cash
 consideration at a weighted-average exercise price of $15.91 per
 share, and 173,275 ordinary shares upon the vesting of restricted
 share units, net of shares withheld.

[0001193125-18-319643:notes:218]
[same as prior period, unchanged from 0001193125-18-155969:notes:159]

[0001193125-18-319643:notes:219]
[same as prior period, unchanged from 0001193125-18-155969:notes:160]

[0001193125-18-319643:notes:220]
In August 2017, the Company’s board of directors approved a
 share repurchase program to permit the Company to repurchase up to
 $30.0 million worth of its issued and outstanding ordinary
 shares in the open market in accordance with applicable rules and
 regulations. In February 2018, the Company’s board of
 directors approved a $30.0 million increase to the share
 repurchase authorization. During the three months ended
 September 28, 2018, no shares were repurchased under the
 program. As of September 28, 2018, the Company had a remaining
 authorization to purchase up to an additional $17.6 million
 worth of its ordinary shares under the share repurchase program.
 Shares repurchased under the share repurchase program are held as
 treasury shares.
