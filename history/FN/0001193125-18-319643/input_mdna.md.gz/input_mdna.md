# FN MD&A — 0001193125-18-319643


## mdna

[0001193125-18-319643:mdna:1]
ITEM 2. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION
AND RESULTS OF OPERATIONS

[0001193125-18-319643:mdna:2]
[same as prior period, unchanged from 0001193125-18-155969:mdna:2]

[0001193125-18-319643:mdna:3]
[same as prior period, unchanged from 0001193125-18-155969:mdna:3]

[0001193125-18-319643:mdna:4]
|  | • |  | our expectation that the portion of our future revenues attributable to customers in regions outside of North America will be in line with the portion of those revenues for the three months ended September 28, 2018; |

[0001193125-18-319643:mdna:5]
[same as prior period, unchanged from 0001193125-18-155969:mdna:5]

[0001193125-18-319643:mdna:6]
|  | • |  | our expectation that our fiscal year 2019 selling, general and administrative (“SG&A”) expenses will decrease as a percentage of revenue compared to fiscal year 2018 SG&A expenses; |

[0001193125-18-319643:mdna:7]
[same as prior period, unchanged from 0001193125-18-155969:mdna:7]

[0001193125-18-319643:mdna:8]
[same as prior period, unchanged from 0001193125-18-155969:mdna:8]

[0001193125-18-319643:mdna:9]
[same as prior period, unchanged from 0001193125-18-155969:mdna:9]

[0001193125-18-319643:mdna:10]
[same as prior period, unchanged from 0001193125-18-155969:mdna:10]

[0001193125-18-319643:mdna:11]
[same as prior period, unchanged from 0001193125-18-155969:mdna:11]

[0001193125-18-319643:mdna:12]
[same as prior period, unchanged from 0001193125-18-155969:mdna:12]

[0001193125-18-319643:mdna:13]
[same as prior period, unchanged from 0001193125-18-155969:mdna:13]

[0001193125-18-319643:mdna:14]
[same as prior period, unchanged from 0001193125-18-155969:mdna:14]

[0001193125-18-319643:mdna:15]
[same as prior period, unchanged from 0001193125-18-155969:mdna:15]

[0001193125-18-319643:mdna:16]
[same as prior period, unchanged from 0001193125-18-155969:mdna:16]

[0001193125-18-319643:mdna:17]
[same as prior period, unchanged from 0001193125-18-155969:mdna:17]

[0001193125-18-319643:mdna:18]
[same as prior period, unchanged from 0001193125-18-155969:mdna:18]

[0001193125-18-319643:mdna:19]
[same as prior period, unchanged from 0001193125-18-155969:mdna:19]

[0001193125-18-319643:mdna:20]
[same as prior period, unchanged from 0001193125-18-155969:mdna:20]

[0001193125-18-319643:mdna:21]
[same as prior period, unchanged from 0001193125-18-155969:mdna:21]

[0001193125-18-319643:mdna:22]
[same as prior period, unchanged from 0001193125-18-155969:mdna:22]

[0001193125-18-319643:mdna:23]
[same as prior period, unchanged from 0001193125-18-155969:mdna:23]

[0001193125-18-319643:mdna:24]
We believe our ability to
expand our relationships with existing customers and attract new customers is due to a number of factors, including our broad range of complex engineering and manufacturing service offerings, flexible low-cost
manufacturing platform, process optimization capabilities, advanced supply chain management, excellent customer service, and experienced management team. Although we expect the prices we charge for our manufactured products to decrease over time
(partly as a result of competitive market forces), we still believe we will be able to maintain favorable pricing for our services because of our ability to reduce cycle time, adjust our product mix by focusing on more complicated products, improve
product quality and yields, and reduce material costs for the products we manufacture. We believe these capabilities have enabled us to help our OEM customers reduce their manufacturing costs while maintaining or improving the design, quality,
reliability, and delivery times for their products.

[0001193125-18-319643:mdna:25]
[same as prior period, unchanged from 0001193125-18-155969:mdna:25]

[0001193125-18-319643:mdna:26]
[same as prior period, unchanged from 0001193125-18-155969:mdna:26]

[0001193125-18-319643:mdna:27]
The percentage of our revenues generated from a
bill-to location outside of North America decreased from 56.1% in the three months ended September 29, 2017 to 52.3% in the three months ended September 28, 2018, primarily because the increase in
sales to our customers in North America was higher than the increase in sales to our customers outside of North America. Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future
revenues attributable to customers in regions outside North America will be in line with the portion of revenues attributable to such customers during the three months ended September 28, 2018.

[0001193125-18-319643:mdna:28]
[same as prior period, unchanged from 0001193125-18-155969:mdna:28]

[0001193125-18-319643:mdna:29]
|  |  | Three Months Ended |  |
|  |  | September 28,2018 |  |  | September 29,2017 |  |
| North America |  |  | 47.7 | % |  |  | 43.9 | % |
| Asia-Pacific |  |  | 40.3 |  |  |  | 40.0 |  |
| Europe |  |  | 12.0 |  |  |  | 16.1 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-18-319643:mdna:30]
[same as prior period, unchanged from 0001193125-18-155969:mdna:30]

[0001193125-18-319643:mdna:31]
We enter into supply agreements with our customers which generally have an initial term of up to three years, subject to automatic renewals for
subsequent one-year terms unless expressly terminated. Although there are no minimum purchase requirements in our supply agreements, our customers provide us with rolling forecasts of their demand
requirements. Our supply agreements generally include provisions for pricing and periodic review of pricing, consignment of our customer’s unique production equipment to us, and the sharing of benefits from cost-savings derived from our
efforts. We are generally required to purchase materials, which may include long lead-time materials and materials that are subject to minimum order quantities and/or non-cancelable or non-returnable terms, to meet the stated demands of our customers. After procuring materials, we manufacture products for our customers based on purchase orders that contain terms regarding product quantities,
delivery locations and delivery dates. Our customers generally are obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by our customers within a specified period of
time, or are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under our contracts. Once
materials are designated as either excess or obsolete inventory, our customers are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products. The excess or obsolete inventory is
shipped to the customer and revenue is recognized upon shipment.

[0001193125-18-319643:mdna:32]
[same as prior period, unchanged from 0001193125-18-155969:mdna:32]

[0001193125-18-319643:mdna:33]
The key components of our cost of revenues are material costs, employee costs, and infrastructure-related costs. Material costs generally
represent the majority of our cost of revenues. Several of the materials we require to manufacture products for our customers are customized for their products and often sourced from a single supplier or in some cases, our own subsidiaries.
Shortages from sole-source suppliers due to yield loss, quality concerns and capacity constraints, among other factors, may increase our expenses and negatively impact our gross profit margin or total revenues in a given quarter. Material costs
include scrap material. Historically, scrap rate diminishes during a product’s life cycle due to process, fixturing and test improvement and optimization.

[0001193125-18-319643:mdna:34]
A second significant element of our cost of revenues is employee costs, including indirect employee costs related to design, configuration and
optimization of manufacturing processes for our customers, quality testing, materials testing and other engineering services; and direct costs related to our manufacturing employees. Direct employee costs include employee salaries, insurance and
benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a lesser extent, costs to recruit,
train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand, the PRC and the United Kingdom, the fluctuation of the Thai baht, Chinese Renminbi (“RMB”) and Pound Sterling (“GBP”)
against our functional currency, the U.S. dollar, and our ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may impact our ability to sustain our
competitive advantage and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention and asset utilization.

[0001193125-18-319643:mdna:35]
[same as prior period, unchanged from 0001193125-18-155969:mdna:35]

[0001193125-18-319643:mdna:36]
[same as prior period, unchanged from 0001193125-18-155969:mdna:36]

[0001193125-18-319643:mdna:37]
[same as prior period, unchanged from 0001193125-18-155969:mdna:37]

[0001193125-18-319643:mdna:38]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative and other support
personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other general expenses not related to cost of
revenues. In fiscal year 2019, we expect our SG&A expenses will decrease as a percentage of revenue compared with our fiscal year 2018 SG&A expenses.

[0001193125-18-319643:mdna:39]
The compensation committee of our board of directors approved a fiscal year 2019 executive incentive plan with quantitative objectives that
are based solely on achieving certain revenue targets and non-GAAP gross margin targets for our fiscal year ending June 28, 2019. Bonuses under the fiscal year 2019 executive incentive plan are payable after
the end of fiscal year 2019. In fiscal year 2018, the compensation committee approved a fiscal year 2018 executive incentive plan with quantitative objectives that were based solely on achieving certain revenue targets and non-GAAP gross margin targets for our fiscal year ended June 29, 2018. Because we did not achieve the targets under our fiscal year 2018 executive incentive plan, no bonuses were paid under such plan. In the
three months ended September 29, 2017, the compensation committee awarded bonuses to our executive employees for Company achievements of performance under the fiscal 2017 executive incentive plan. Discretionary merit-based bonus awards are also
available to our non-executive employees and payable on a quarterly basis.

[0001193125-18-319643:mdna:40]
In addition, during
the three months ended September 28, 2018, $1.4 million share-based compensation expenses recorded in fiscal 2018 for the remaining portion of performance share units granted to our executives were reversed due to the unlikelihood that the
performance targets would be achieved.

[0001193125-18-319643:mdna:41]
[same as prior period, unchanged from 0001193125-18-155969:mdna:40]

[0001193125-18-319643:mdna:42]
[same as prior period, unchanged from 0001193125-18-155969:mdna:41]

[0001193125-18-319643:mdna:43]
As a result of
our international operations, we are exposed to foreign exchange risk arising from various currency exposures primarily with respect to the Thai baht. Although a majority of our total revenues is denominated in U.S. dollars, a substantial portion of
our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rate between the Thai baht and the U.S. dollar has fluctuated substantially in recent years and may continue to fluctuate substantially in the future.
We report our financial results in U.S. dollars and our results of operations have been and could in the future be negatively impacted if the Thai baht appreciates against the U.S. dollar. Smaller portions of our expenses are incurred in a variety
of other currencies, including RMB, GBP, Canadian dollars, Euros, and Japanese yen, the appreciation of which may also negatively impact our financial results.

[0001193125-18-319643:mdna:44]
In order to manage the risks arising from fluctuations in foreign currency exchange rates, we use derivative instruments. We may enter into
exchange currency forward or put option contracts to manage foreign currency exposures associated with certain assets and liabilities and other forecasted foreign currency transactions and may designate these instruments as hedging instruments. The
forward and put option contracts generally have maturities of up to 12 months. All foreign currency exchange contracts are recognized in the unaudited condensed consolidated balance sheets at fair value. Gain or loss on our forward and put option
contracts generally offset the assets, liabilities, and transactions economically hedged.

[0001193125-18-319643:mdna:45]
We had foreign currency denominated assets and liabilities in Thai baht, RMB and GBP as
follows:

[0001193125-18-319643:mdna:46]
|  |  | As of September 28, 2018 |  |  | As of June 29, 2018 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,031,793 |  |  | $ | 31,836 |  |  |  | 75.3 |  |  |  | 980,778 |  |  | $ | 29,568 |  |  |  | 60.7 |  |
| RMB |  |  | 25,525 |  |  |  | 3,710 |  |  |  | 8.8 |  |  |  | 18,455 |  |  |  | 2,789 |  |  |  | 5.7 |  |
| GBP |  |  | 5,130 |  |  |  | 6,709 |  |  |  | 15.9 |  |  |  | 12,514 |  |  |  | 16,392 |  |  |  | 33.6 |  |
| Total |  |  |  |  |  | $ | 42,255 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 48,749 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,800,696 |  |  | $ | 55,560 |  |  |  | 87.8 |  |  |  | 1,401,473 |  |  | $ | 42,251 |  |  |  | 84.5 |  |
| RMB |  |  | 27,380 |  |  |  | 3,980 |  |  |  | 6.2 |  |  |  | 19,893 |  |  |  | 3,007 |  |  |  | 6.0 |  |
| GBP |  |  | 2,886 |  |  |  | 3,775 |  |  |  | 6.0 |  |  |  | 3,615 |  |  |  | 4,735 |  |  |  | 9.5 |  |
| Total |  |  |  |  |  | $ | 63,315 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 49,993 |  |  |  | 100.0 |  |

[0001193125-18-319643:mdna:47]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other
current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and
offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of September 28, 2018 there were $6.0 million of foreign currency forward contracts and $19.0 million of foreign
currency option contracts outstanding on the Thai baht payables. As of June 29, 2018, there were $7.0 million in foreign currency forward contracts and $30.0 million of foreign currency option contracts outstanding on the Thai baht
payables.

[0001193125-18-319643:mdna:48]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities
represent trade accounts payable, accrued expenses, income tax payable and other payables. As of September 28, 2018 and June 29, 2018, we did not have any derivative contracts denominated in RMB.

[0001193125-18-319643:mdna:49]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable and
other payables. As of September 28, 2018 and June 29, 2018, we did not have any derivative contracts denominated in GBP.

[0001193125-18-319643:mdna:50]
For
the three months ended September 28, 2018 and September 29, 2017, we recorded gain of $0.2 million and loss of $10 thousand, respectively, related to derivatives that are not designated as hedging instruments in the unaudited
condensed consolidated statements of operations and comprehensive income.

[0001193125-18-319643:mdna:51]
[same as prior period, unchanged from 0001193125-18-155969:mdna:50]

[0001193125-18-319643:mdna:52]
[same as prior period, unchanged from 0001193125-18-155969:mdna:51]

[0001193125-18-319643:mdna:53]
[same as prior period, unchanged from 0001193125-18-155969:mdna:52]

[0001193125-18-319643:mdna:54]
[same as prior period, unchanged from 0001193125-18-155969:mdna:53]

[0001193125-18-319643:mdna:55]
[same as prior period, unchanged from 0001193125-18-155969:mdna:54]

[0001193125-18-319643:mdna:56]
Under the Exchange Rules, RMB is freely convertible into foreign currencies for current account items, including the distribution of
dividends, interest payments, trade and service-related foreign exchange transactions. However, conversion of RMB for capital account items, such as direct investments, loans, security investments and repatriation of investments, is still subject to
the approval of SAFE.

[0001193125-18-319643:mdna:57]
Under the Administration Rules, foreign-invested enterprises may only buy, sell, or remit
foreign currencies at banks authorized to conduct foreign exchange business after providing valid commercial documents and relevant supporting documents and, in the case of capital account item transactions, obtaining approval from SAFE. Capital
investments by foreign-invested enterprises outside of the PRC are also subject to limitations, which include approvals by the Ministry of Commerce, SAFE and the State Development and Reform Commission.

[0001193125-18-319643:mdna:58]
Circular 142 regulates the conversion by a foreign-invested company of foreign currency into RMB by restricting how the converted RMB may be
used. Circular 142 requires that the registered capital of a foreign-invested enterprise settled in RMB converted from foreign currencies may only be used for purposes within the business scope approved by the applicable governmental authority and
may not be used for equity investments within the PRC. In addition, SAFE strengthened its oversight of the flow and use of the registered capital of foreign-invested enterprises settled in RMB converted from foreign currencies. The use of such RMB
capital may not be changed without SAFE’s approval and may not be used to repay RMB loans if the proceeds of such loans have not been used.

[0001193125-18-319643:mdna:59]
[same as prior period, unchanged from 0001193125-18-155969:mdna:58]

[0001193125-18-319643:mdna:60]
[same as prior period, unchanged from 0001193125-18-155969:mdna:59]

[0001193125-18-319643:mdna:61]
[same as prior period, unchanged from 0001193125-18-155969:mdna:60]

[0001193125-18-319643:mdna:62]
[same as prior period, unchanged from 0001193125-18-155969:mdna:61]

[0001193125-18-319643:mdna:63]
[same as prior period, unchanged from 0001193125-18-155969:mdna:62]

[0001193125-18-319643:mdna:64]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of
Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption is currently available to us through June 2020 and June 2026 on income generated from projects to manufacture certain products at our Pinehurst
campus and Chonburi campus, respectively. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our
current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted (i.e., at least in the case of our Pinehurst campus and until June 2026 in the case of our Chonburi campus). In March 2016, the Thailand
Revenue Department announced a permanent decrease of corporate income tax rates to 20% for tax periods beginning on or after January 1, 2016. As a result, corporate income tax rates for our Thai subsidiary are expected to remain at 20% from
fiscal year 2017 onward.

[0001193125-18-319643:mdna:65]
The Tax Cuts and Jobs Act, or the Tax Reform Act, was enacted on December 22, 2017 and provides for
significant changes to U.S. tax law. Among other provisions, the Tax Reform Act reduces the U.S. corporate income tax rate to 21% effective in 2018. The Tax Reform Act also contains a number of provisions that may impact us in future years. Since
the Tax Reform Act was recently finalized and ongoing guidance and accounting interpretation is expected over the next twelve months, we have made certain provisional accounting estimates, as permitted under Staff Accounting Bulletin No. 118,
and continue to analyze our accounting policies in this area. The U.S. Treasury Department, the IRS, and other standard-setting bodies could interpret or issue guidance on how provisions of the Tax Reform Act will be applied or otherwise
administered that is different from our interpretation. As we complete our analysis of the Tax Reform Act, collect and prepare necessary data, and interpret any additional guidance, we may make adjustments to provisional amounts that we have
recorded that may be material in the period in which the adjustments are made. The final accounting analysis will occur no later than one year from the date the Tax Reform Act was enacted.

[0001193125-18-319643:mdna:66]
[same as prior period, unchanged from 0001193125-18-155969:mdna:65]

[0001193125-18-319643:mdna:67]
[same as prior period, unchanged from 0001193125-18-155969:mdna:66]

[0001193125-18-319643:mdna:68]
Our critical accounting policies are disclosed in our Annual Report on Form 10-K for the fiscal year
ended June 29, 2018. The adoption of new accounting policies and the accounting standards are disclosed in Note 2 – Accounting policies to the unaudited condensed consolidated financial statements. There were no changes to our accounting
policies other than the adoption of Revenue from Contracts with Customers (Topic 606), which created Accounting Standards Codification Topic 606 (“ASC 606”).

[0001193125-18-319643:mdna:69]
On June 30, 2018, we adopted ASC 606 using the modified retrospective method, which was applied to those contracts which were not
completed as of June 29, 2018. The modified retrospective method requires us to recognize the cumulative effect of the adoption of ASC 606, for all contracts with customers, to the opening balance of equity at June 30, 2018. Accordingly,
the comparative financial information as of June 29, 2018 has not been adjusted and continues to be reported under ASC 605, Revenue Recognition (“ASC 605”). Refer to Note 2 – Accounting policies and Note 3 –
Revenue to the unaudited condensed consolidated financial statements for further details.

[0001193125-18-319643:mdna:70]
35

[0001193125-18-319643:mdna:71]
[same as prior period, unchanged from 0001193125-18-155969:mdna:68]

[0001193125-18-319643:mdna:72]
The following table sets forth a summary of our unaudited condensed consolidated statements of operations and comprehensive income. Note that period-to-period comparisons of operating results should not be relied upon as indicative of future performance.

[0001193125-18-319643:mdna:73]
| (amount in thousands) |  | Three Months Ended |  |
|  | September 29,2017 |  |  | September 29,2017 |  |
| Revenues |  | $ | 377,177 |  |  | $ | 357,313 |  |
| Cost of revenues |  |  | (336,901 | ) |  |  | (316,981 | ) |
| Gross profit |  |  | 40,276 |  |  |  | 40,332 |  |
| Selling, general and administrative expenses |  |  | (14,437 | ) |  |  | (15,678 | ) |
| Expenses related to reduction in workforce |  |  | (85 | ) |  |  | — |  |
| Operating income |  |  | 25,754 |  |  |  | 24,654 |  |
| Interest income |  |  | 1,444 |  |  |  | 809 |  |
| Interest expense |  |  | (634 | ) |  |  | (853 | ) |
| Foreign exchange gain (loss), net |  |  | 3,068 |  |  |  | (1,934 | ) |
| Other income |  |  | 77 |  |  |  | 97 |  |
| Income before income taxes |  |  | 29,709 |  |  |  | 22,773 |  |
| Income tax expense |  |  | (1,859 | ) |  |  | (1,740 | ) |
| Net income |  |  | 27,850 |  |  |  | 21,033 |  |
| Other comprehensive (loss) income, net of tax |  |  | 87 |  |  |  | 554 |  |
| Net comprehensive income |  | $ | 27,937 |  |  | $ | 21,587 |  |

[0001193125-18-319643:mdna:74]
[same as prior period, unchanged from 0001193125-18-155969:mdna:71]

[0001193125-18-319643:mdna:75]
|  |  | Three Months Ended |  |
|  |  | September 28,2018 |  |  | September 29,2017 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (89.3 | ) |  |  | (88.7 | ) |
| Gross profit |  |  | 10.7 |  |  |  | 11.3 |  |
| Selling, general and administrative expenses |  |  | (3.8 | ) |  |  | (4.4 | ) |
| Expenses related to reduction in workforce |  |  | 0.0 |  |  |  | — |  |
| Operating income |  |  | 6.9 |  |  |  | 6.9 |  |
| Interest income |  |  | 0.4 |  |  |  | 0.2 |  |
| Interest expense |  |  | (0.2 | ) |  |  | (0.2 | ) |
| Foreign exchange gain (loss), net |  |  | 0.8 |  |  |  | (0.5 | ) |
| Other income |  |  | 0.0 |  |  |  | 0.0 |  |
| Income before income taxes |  |  | 7.9 |  |  |  | 6.4 |  |
| Income tax expense |  |  | (0.5 | ) |  |  | (0.5 | ) |
| Net income |  |  | 7.4 |  |  |  | 5.9 |  |
| Other comprehensive (loss) income, net of tax |  |  | 0.0 |  |  |  | 0.2 |  |
| Net comprehensive income |  |  | 7.4 | % |  |  | 6.1 | % |

[0001193125-18-319643:mdna:76]
[same as prior period, unchanged from 0001193125-18-155969:mdna:74]

[0001193125-18-319643:mdna:77]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 28,2018 |  |  | September 29,2017 |  |
| Optical communications |  | $ | 280,768 |  |  | $ | 275,613 |  |
| Lasers, sensors and other |  |  | 96,409 |  |  |  | 81,700 |  |
| Total |  | $ | 377,177 |  |  | $ | 357,313 |  |

[0001193125-18-319643:mdna:78]
[same as prior period, unchanged from 0001193125-18-155969:mdna:76]

[0001193125-18-319643:mdna:79]
Comparison of Three Months Ended September 28, 2018 with Three Months Ended
September 29, 2017

[0001193125-18-319643:mdna:80]
[same as prior period, unchanged from 0001193125-18-155969:mdna:78]

[0001193125-18-319643:mdna:81]
Our total revenues increased by $19.9 million, or 5.6%, to $377.2 million for the three months ended September 28, 2018,
compared with $357.3 million for the three months ended September 29, 2017. This increase was primarily due to an increase in our customers’ demand for both optical and non-optical
communications manufacturing services during the three months ended September 28, 2018. Revenues from optical and non-optical communications products increased by $5.2 million and $14.7 million,
or 1.9% and 18.0%, respectively, for the three months ended September 28, 2018.

[0001193125-18-319643:mdna:82]
[same as prior period, unchanged from 0001193125-18-155969:mdna:81]

[0001193125-18-319643:mdna:83]
Our cost of revenues increased by $19.9 million, or 6.3%, to $336.9 million, or 89.3% of total revenues, for the three months ended
September 28, 2018, compared with $317.0 million, or 88.7% of total revenues, for the three months ended September 29, 2017. This increase in cost of revenues was in line with the increase in sales volume.

[0001193125-18-319643:mdna:84]
[same as prior period, unchanged from 0001193125-18-155969:mdna:84]

[0001193125-18-319643:mdna:85]
Our gross
profit decreased by $56 thousand, or 0.1%, to $40.3 million, or 10.7% of total revenues, for the three months ended September 28, 2018, compared with $40.3 million, or 11.3% of total revenues, for the three months ended
September 29, 2017. The decrease was primarily due to product mixed and the incremental employees cost from merit increase of our employees.

[0001193125-18-319643:mdna:86]
[same as prior period, unchanged from 0001193125-18-155969:mdna:87]

[0001193125-18-319643:mdna:87]
Our
SG&A expenses decreased by $1.2 million, or 7.9%, to $14.4 million, or 3.8% of total revenues, for the three months ended September 28, 2018, compared with $15.7 million, or 4.4% of total revenues, for the three months ended
September 29, 2017. The decrease was primarily due to $1.4 million reversal of the remaining portion of share-based compensation expenses recorded in fiscal 2018 for performance share units granted to our executives in August 2017 due to
the unlikelihood that the performance targets would be achieved.

[0001193125-18-319643:mdna:88]
[same as prior period, unchanged from 0001193125-18-155969:mdna:90]

[0001193125-18-319643:mdna:89]
Our operating income increased by $1.1 million to $25.8 million, or 6.9% of total revenues, for the three months ended
September 28, 2018, compared with $24.7 million, or 6.9% of total revenues, for the three months ended September 29, 2017. The increase was primarily due to a decrease of SG&A expenses.

[0001193125-18-319643:mdna:90]
[same as prior period, unchanged from 0001193125-18-155969:mdna:93]

[0001193125-18-319643:mdna:91]
Our
interest income increased by $0.6 million, or 78.5%, to $1.4 million, or 0.4% of total revenues, for the three months ended September 28, 2018, compared with $0.8 million, or 0.2% of total revenues, for the three months ended
September 29, 2017. The increase was primarily due to the higher weighted average interest rate compared to the same period in the last year and an increase in the average balance of our outstanding cash.

[0001193125-18-319643:mdna:92]
[same as prior period, unchanged from 0001193125-18-155969:mdna:95]

[0001193125-18-319643:mdna:93]
Our interest expense decreased by $0.3 million to $0.6 million for the three months ended September 28, 2018, compared with
$0.9 million for the three months ended September 29, 2017. The decrease was primarily due to a decrease in the average balance of our bank borrowings.

[0001193125-18-319643:mdna:94]
Foreign exchange gain (loss), net.

[0001193125-18-319643:mdna:95]
We recorded foreign exchange gain, net of $3.1 million for the three months ended September 28, 2018, compared with $1.9 million
loss for the three months ended September 29, 2017.

[0001193125-18-319643:mdna:96]
[same as prior period, unchanged from 0001193125-18-155969:mdna:101]

[0001193125-18-319643:mdna:97]
We recorded income before income taxes of $29.7 million for the three months ended September 28, 2018, compared with
$22.8 million for the three months ended September 29, 2017.

[0001193125-18-319643:mdna:98]
[same as prior period, unchanged from 0001193125-18-155969:mdna:103]

[0001193125-18-319643:mdna:99]
Our provision for income tax reflects an effective tax rate of 6.7% and 6.3% for the three months ended September 28, 2018 and
September 29, 2017, respectively. The increase was primarily due to the fact that we had higher income subject to tax during the first quarter of fiscal year 2019 as compared to the same period in fiscal year 2018.

[0001193125-18-319643:mdna:100]
[same as prior period, unchanged from 0001193125-18-155969:mdna:106]

[0001193125-18-319643:mdna:101]
We recorded
net income of $27.9 million, or 7.4% of total revenues, for the three months ended September 28, 2018, compared with $21.0 million, or 5.9% of total revenues, for the three months ended September 29, 2017. The increase was mainly
due to (1) the $1.4 million reversal of the remaining portion of share based compensation expenses recorded in fiscal 2018 for performance share units granted to our executives due to the unlikelihood that the performance targets would be
achieved; (2) net increase of interest income and expenses of $ 0.7 million; and (3) net increase of foreign exchange gain of $5.0 million.

[0001193125-18-319643:mdna:102]
Other comprehensive income.

[0001193125-18-319643:mdna:103]
We recorded other comprehensive income of $87 thousand, or 0.0% of total revenues, for the three months ended September 28, 2018,
compared with other comprehensive income of $0.6 million, or 0.2% of total revenues, for the three months ended September 29, 2017.

[0001193125-18-319643:mdna:104]
[same as prior period, unchanged from 0001193125-18-155969:mdna:112]

[0001193125-18-319643:mdna:105]
[same as prior period, unchanged from 0001193125-18-155969:mdna:113]

[0001193125-18-319643:mdna:106]
We primarily finance our operations through cash flow from operations. As of September 28, 2018 and
September 29, 2017, we had cash, cash equivalents, and marketable securities of $352.4 million and $263.3 million, respectively, and outstanding debt of $63.4 million and $67.0 million, respectively.

[0001193125-18-319643:mdna:107]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of
three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents for the three months ended as of September 28, 2018 and September 29, 2017 was 1.9% and 0.9%,
respectively.

[0001193125-18-319643:mdna:108]
Our cash investments are made in accordance with an investment policy approved by the Audit Committee of our board of
directors. In general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed
income securities are primarily classified as available-for-sale and are recorded at fair value. The cost of securities sold is based on the specific identification
method. Unrealized gains and losses on these securities are recorded as other comprehensive income (loss) and are reported as a separate component of shareholders’ equity.

[0001193125-18-319643:mdna:109]
During the three months ended September 28, 2018, we repaid a term loan of $0.8 million under our Facility Agreement; as a result,
as of September 28, 2018, we had a long-term borrowing of $63.4 million under our Facility Agreement. We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these
obligations. To better manage our cash on hand, we held investments in short-term marketable securities of $132.4 million as of September 28, 2018.

[0001193125-18-319643:mdna:110]
We believe that our current cash and cash equivalents, marketable securities, cash flow from
operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of
risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001193125-18-319643:mdna:111]
We
also believe that our current manufacturing capacity is sufficient to meet our anticipated production requirements for at least the next few quarters.

[0001193125-18-319643:mdna:112]
[same as prior period, unchanged from 0001193125-18-155969:mdna:120]

[0001193125-18-319643:mdna:113]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 28,2018 |  |  | September 29,2017 |  |
| Net cash provided by (used in) operating activities |  | $ | 34,593 |  |  | $ | (3,054 | ) |
| Net cash provided by (used in) investing activities |  | $ | 36,601 |  |  | $ | (12,055 | ) |
| Net cash used in financing activities |  | $ | (13,318 | ) |  | $ | (7,106 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | 57,876 |  |  | $ | (22,215 | ) |

[0001193125-18-319643:mdna:114]
[same as prior period, unchanged from 0001193125-18-155969:mdna:122]

[0001193125-18-319643:mdna:115]
Net cash provided by operating activities increased by $37.6 million, or 1,232.7%, to $34.6 million for the three months ended
September 28, 2018, compared with net cash used in operating activities of $3.1 million for the three months ended September 29, 2017. This increase was primarily due to a decrease of $40.5 million in payments to trade accounts
payable resulting from the implementation of new payment pattern in September 2018.

[0001193125-18-319643:mdna:116]
[same as prior period, unchanged from 0001193125-18-155969:mdna:124]

[0001193125-18-319643:mdna:117]
Net cash provided by investing activities increased by $48.7 million, or 403.6%, to $36.6 million for the three months ended
September 28, 2018, compared with net cash used in investing activities of $12.1 million for the three months ended September 29, 2017. This increase was primarily due to (1) a decrease of purchase of marketable securities of
$25.0 million; (2) an increase in proceeds from sales of marketable securities of $12.5 million; (3) an increase of proceeds from maturities of marketable securities of $4.9 million; and (4) a decrease of investments in
property, plant and equipment of $5.8 million.

[0001193125-18-319643:mdna:118]
[same as prior period, unchanged from 0001193125-18-155969:mdna:126]

[0001193125-18-319643:mdna:119]
Net cash used in financing activities increased by $6.2 million, or 87.4%, to $13.3 million for the three months ended
September 28, 2018, compared with net cash used by financing activities of $7.1 million for the three months ended September 29, 2017. This increase was primarily due to (1) an increase in withholding tax related to net share
settlement of restricted share units of $5.4 million and (2) the release of restricted cash in connection with business acquisition of $3.5 million. These increases were offset by the decrease of repayment of a long-term loan of
$2.6 million.

[0001193125-18-319643:mdna:120]
Off-Balance Sheet Commitments and Arrangements

[0001193125-18-319643:mdna:121]
We have not entered into any financial guarantees or other commitments to guarantee the payment obligations of any third parties. In addition,
we have not entered into any derivative contracts that are not reflected in our unaudited condensed consolidated financial statements. Furthermore, we do not have any retained or contingent interest in assets transferred to an unconsolidated entity
that serves as credit, liquidity or market risk support to such entity. We also do not have any variable interest in any unconsolidated entity that provides financing, liquidity, market risk or credit support to us or engage in leasing, hedging or
research and development services with us.

[0001193125-18-319643:mdna:122]
[same as prior period, unchanged from 0001193125-18-155969:mdna:130]

[0001193125-18-319643:mdna:123]
[same as prior period, unchanged from 0001193125-18-155969:mdna:131]
