# FN note change history — 0001193125-18-155969 → 0001193125-18-319643


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-11-06):
[0001193125-18-319643:note_history:1]
17. Commitments and contingencies
  (was, 2018-05-08, similarity 0.9118):
[0001193125-18-155969:note_history:1]
| 16. | Commitments and contingencies |

- added (2018-11-06):
[0001193125-18-319643:note_history:2]
As of September 28, 2018 and June 29, 2018, there were
 outstanding bank guarantees given by a bank on behalf of our
 subsidiary in Thailand for electricity usage and other normal
 business amounting to $1.5 million.

- added (2018-11-06):
[0001193125-18-319643:note_history:3]
The Company leases a portion of its capital equipment, vehicles,
 and certain land and buildings for its facilities in Thailand,
 Cayman Islands, China, the United States and the United Kingdom
 under operating lease arrangements that expire in various years
 through 2023. Rental expense under these operating leases amounted
 to $0.5 million and $0.5 million for the three months
 ended September 28, 2018 and September 29, 2017,
 respectively.

- changed (2018-11-06):
[0001193125-18-319643:note_history:4]
As of September 28, 2018, the future minimum lease payments
 due under non-cancelable
 operating leases during each fiscal year were as follows:
  (was, 2018-05-08, similarity 0.9627):
[0001193125-18-155969:note_history:4]
As of March 30, 2018, the future minimum lease payments due
 under non-cancelable
 operating leases during each fiscal year were as follows:

- changed (2018-11-06):
[0001193125-18-319643:note_history:5]
| (amount in thousands) |  |  |  |
| 2019 (remaining nine months) |  | $ | 1,396 |  |
| 2020 |  |  | 1,721 |  |
| 2021 |  |  | 1,320 |  |
| 2022 |  |  | 1,204 |  |
| 2023 |  |  | 1,195 |  |
| Thereafter |  |  | 230 |  |
| Total minimum operating lease payments |  | $ | 7,066 |  |
  (was, 2018-05-08, similarity 0.9839):
[0001193125-18-155969:note_history:5]
| (amount in thousands) |  |  |  |
| 2018 (remaining three months) |  | $ | 468 |  |
| 2019 |  |  | 1,319 |  |
| 2020 |  |  | 965 |  |
| 2021 |  |  | 562 |  |
| 2022 |  |  | 448 |  |
| Thereafter |  |  | 486 |  |
| Total minimum operating lease payments |  | $ | 4,248 |  |

- added (2018-11-06):
[0001193125-18-319643:note_history:6]
In connection with the acquisition of Fabrinet UK, the Company
 assumed the capital lease commitments of several machines and
 equipment, with various expiration dates until September 2020. The
 equipment can be purchased at the determined prices upon expiration
 of such contracts.

- changed (2018-11-06):
[0001193125-18-319643:note_history:7]
As of September 28, 2018, the future minimum lease payments
 due under non-cancelable
 capital leases during each fiscal year were as follows:
  (was, 2018-05-08, similarity 0.9621):
[0001193125-18-155969:note_history:7]
As of March 30, 2018, the future minimum lease payments due
 under non-cancelable
 capital leases during each fiscal year were as follows:

- changed (2018-11-06):
[0001193125-18-319643:note_history:8]
| (amount in thousands) |  |  |  |
| 2019 (remaining nine months) |  | $ | 333 |  |
| 2020 |  |  | 410 |  |
| 2021 |  |  | 105 |  |
| 2022 |  |  | — |  |
| Total minimum capital lease payments |  | $ | 848 |  |
  (was, 2018-05-08, similarity 0.9742):
[0001193125-18-155969:note_history:8]
| (amount in thousands) |  |  |  |
| 2018 (remaining three months) |  | $ | 125 |  |
| 2019 |  |  | 484 |  |
| 2020 |  |  | 440 |  |
| 2021 |  |  | 113 |  |
| Total minimum capital lease payments |  | $ | 1,162 |  |

- changed (2018-11-06):
[0001193125-18-319643:note_history:9]
On December 23, 2016, the Company entered into an agreement to
 purchase a parcel of land in Chonburi, Thailand, to support the
 expansion of the Company’s production in Thailand. The
 aggregate purchase price was approximately $5.6 million, of
 which the first installment of $1.1 million was paid by the
 Company on January 10, 2017 and the remainder was fully paid
 on December 25, 2017.
  (was, 2018-05-08, similarity 0.6361):
[0001193125-18-155969:note_history:9]
On December 23, 2016, the Company entered into an agreement to
 purchase a parcel of land in Chonburi, Thailand, to support the
 expansion of the Company’s production in Thailand. The
 aggregate purchase price is approximately $5.6 million, of
 which the first installment of $1.1 million was paid by the
 Company on January 10, 2017 and the remaining balance of the
 purchase price was paid by the Company on December 25,
 2017.

- changed (2018-11-06):
[0001193125-18-319643:note_history:10]
As of September 28, 2018, the Company had an outstanding
 commitment to third parties of $4.9 million.
  (was, 2018-05-08, similarity 0.8776):
[0001193125-18-155969:note_history:10]
As of March 30, 2018, the Company had an outstanding
 commitment to third parties of approximately $3.5 million.

- removed (2018-11-06):
[0001193125-18-155969:note_history:11]
As of March 30, 2018 and June 30, 2017, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to Thai baht 50.1 million as of both dates ($1.6 million
 and $1.5 million, respectively).

- removed (2018-11-06):
[0001193125-18-155969:note_history:12]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, New Jersey and the United Kingdom under operating
 lease arrangements that expire in various calendar years through
 2023. Rental expense under these operating leases amounted to
 $1.3 million and $1.2 million for the nine months ended
 March 30, 2018 and March 31, 2017, respectively.

- removed (2018-11-06):
[0001193125-18-155969:note_history:13]
In connection with the acquisition of Fabrinet UK, the Company
 assumed the capital lease commitments of certain machines and
 equipment, with various expiration dates until September 2020. The
 equipment can be purchased at the determined prices upon expiration
 of such contracts.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-11-06):
[0001193125-18-319643:note_history:14]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of September 28, 2018 and for the
 three months ended September 28, 2018 and September 29,
 2017 includes normal recurring adjustments, necessary for a fair
 statement of the financial statements set forth herein, in
 accordance with accounting principles generally accepted in the
 United States of America (“U.S. GAAP”) for interim
 financial information and the rules and regulations of the
 Securities and Exchange Commission (“SEC”).
 Accordingly, such information does not include all of the
 information and footnotes required by U.S. GAAP for annual
 financial statements. For further information, please refer to the
 consolidated financial statements and footnotes thereto included in
 Fabrinet’s Annual Report on
 Form 10-K for the year
 ended June 29, 2018.
  (was, 2018-05-08, similarity 0.9523):
[0001193125-18-155969:note_history:14]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of March 30, 2018 and for the three
 and nine months ended March 30, 2018 and March 31, 2017
 include normal recurring adjustments, necessary for a fair
 statement of the financial statements set forth herein, in
 accordance with accounting principles generally accepted in the
 United States of America (“U.S. GAAP”) for interim
 financial information and the rules and regulations of the
 Securities and Exchange Commission (“SEC”).
 Accordingly, such information does not include all of the
 information and footnotes required by U.S. GAAP for annual
 financial statements. For further information, please refer to the
 consolidated financial statements and footnotes thereto included in
 Fabrinet’s Annual Report on Form 10-K for the year ended June 30,
 2017.

- changed (2018-11-06):
[0001193125-18-319643:note_history:15]
The balance sheet as of June 29, 2018 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three months
 ended September 28, 2018 may not be indicative of results for
 the year ending June 28, 2019 or any future periods.
  (was, 2018-05-08, similarity 0.7032):
[0001193125-18-155969:note_history:15]
The balance sheet as of June 30, 2017 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three and nine
 months ended March 30, 2018 may not be indicative of results
 for the year ending June 29, 2018 or any future periods.

- changed (2018-11-06):
[0001193125-18-319643:note_history:16]
The Company utilizes a 52-53 week fiscal
 year ending on the Friday in June closest to June 30. The three
 months ended September 28, 2018 and September 29, 2017
 each consisted of 13 weeks. Fiscal year 2019 will be comprised of
 52 weeks and will end on June 28, 2019.
  (was, 2018-05-08, similarity 0.6502):
[0001193125-18-155969:note_history:16]
The Company utilizes a 52-53 week fiscal year ending on the
 Friday in June closest to June 30. The three months ended
 March 30, 2018 and March 31, 2017 each consisted of 13
 weeks. The nine months ended March 30, 2018 and March 31,
 2017 consisted of 39 weeks and 40 weeks, respectively. Fiscal year
 2018 will be comprised of 52 weeks and will end on June 29,
 2018.

- added (2018-11-06):
[0001193125-18-319643:note_history:17]
Changes in Accounting Policies

- added (2018-11-06):
[0001193125-18-319643:note_history:18]
Except for the adoption of the new revenue recognition accounting
 standard described below and as disclosed in Note 3—Revenue,
 the Company has consistently applied the accounting policies to all
 periods presented in these condensed consolidated financial
 statements.

- added (2018-11-06):
[0001193125-18-319643:note_history:19]
Adoption of New Accounting Standard

- added (2018-11-06):
[0001193125-18-319643:note_history:20]
On June 30, 2018, the Company adopted Revenue from Contracts
 with Customers (Topic 606), which created Accounting Standards
 Codification Topic 606 (“ASC 606”), using the modified
 retrospective method applied to those contracts which were not
 completed as of June 29, 2018. The modified retrospective
 method requires the Company to recognize the cumulative effect of
 the adoption of ASC 606, for all contracts with customers, to the
 opening balance of equity at June 30, 2018. Accordingly, the
 Company’s comparative financial information as
 of June 29, 2018 has not been adjusted and continues
 to be reported under ASC 605, Revenue Recognition (“ASC
 605”).

- added (2018-11-06):
[0001193125-18-319643:note_history:21]
The cumulative effect adjustment recorded was based on the timing
 difference of revenue recognition between ASC 605 and ASC 606
 related to certain manufacturing contracts with vendor managed
 inventory arrangements. Under ASC 605, revenue for such
 contracts was recognized at the earlier of when the inventory was
 consumed by the customers or if not consumed, on the expiration of
 time specified in the contract. On adoption of ASC 606, revenue is
 recognized when inventory is shipped to the customers.

- added (2018-11-06):
[0001193125-18-319643:note_history:22]
The following table shows the impact of adoption of ASC 606 on
 adoption date of June 29, 2018 on the unaudited condensed
 consolidated balance sheets:

- added (2018-11-06):
[0001193125-18-319643:note_history:23]
Condensed Consolidated Balance Sheets

- added (2018-11-06):
[0001193125-18-319643:note_history:24]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | Balance at June 29, 2018 |  |  | Adjustment |  |  | Balance at June 30, 2018 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract assets |  | $ | — |  |  | $ | 9,877 | (1) |  | $ | 9,877 |  |
| Inventory, net |  | $ | 257,687 |  |  | $ | (8,672 | )(2) |  | $ | 249,015 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 632,423 |  |  | $ | 1,205 | (3) |  | $ | 633,628 |  |

- added (2018-11-06):
[0001193125-18-319643:note_history:25]
| (1) | Majority of adjustment relates to certain manufacturing contracts with vendor managed inventory arrangements for which revenue was recognized on shipment. |

- added (2018-11-06):
[0001193125-18-319643:note_history:26]
| (2) | Adjustment relates to reduction of finished goods inventory for certain vendor managed inventory arrangements. |

- added (2018-11-06):
[0001193125-18-319643:note_history:27]
| (3) | Adjustment relates to cumulative effect adjustment upon adoption of ASC 606. |

- changed (2018-11-06):
[0001193125-18-319643:note_history:28]
Financial instruments that potentially subject the Company to
 concentrations of credit risk consist of cash and cash equivalents,
 marketable securities, derivatives, accounts receivable and
 contract assets.
  (was, 2018-05-08, similarity 0.9367):
[0001193125-18-155969:note_history:28]
Financial instruments that potentially subject the Company to
 concentrations of credit risk consist of cash and cash equivalents,
 marketable securities, derivatives and accounts receivable.

- changed (2018-11-06):
[0001193125-18-319643:note_history:29]
Cash, cash equivalents, and marketable securities are maintained
 with several financial institutions. Deposits held with banks may
 exceed the amount of insurance provided on such deposits.
 Generally, these deposits may be redeemed upon demand and are
 maintained with financial institutions with reputable credit and
 therefore bear minimal credit risk. The Company seeks to mitigate
 its credit risks by spreading such risks across multiple
 counterparties and monitoring the risk profiles of these
 counterparties. The Company limits its investments in marketable
 securities to securities with a maturity not in excess of three
 years, and all marketable securities that the Company invests in
 are rated A1, P-1, F1, or
 better.
  (was, 2018-05-08, similarity 0.9993):
[0001193125-18-155969:note_history:29]
Cash, cash equivalents and marketable securities are maintained
 with several financial institutions. Deposits held with banks may
 exceed the amount of insurance provided on such deposits.
 Generally, these deposits may be redeemed upon demand and are
 maintained with financial institutions with reputable credit and
 therefore bear minimal credit risk. The Company seeks to mitigate
 its credit risks by spreading such risks across multiple
 counterparties and monitoring the risk profiles of these
 counterparties. The Company limits its investments in marketable
 securities to securities with a maturity not in excess of three
 years, and all marketable securities that the Company invests in
 are rated A1, P-1, F1, or
 better.

- added (2018-11-06):
[0001193125-18-319643:note_history:30]
In August 2018, the Financial Accounting Standards Board
 (“FASB”) issued ASU 2018-13, “Fair
 Value Measurement (Topic 820), Disclosure Framework – Changes
 to the Disclosure Requirements for Fair Value Measurement. This ASU
 is intended to improve the effectiveness of disclosures in the
 notes to the financial statements including 1) the development of a
 framework that promotes consistent decisions by the Board about
 disclosure requirements and 2) the appropriate exercise of
 discretion by reporting entities. The amendment modifies the
 disclosure requirements on transferring between level 1 and level 2
 and valuation processes of level 3 fair value measurements. The
 amendments in this update are effective for all entities for fiscal
 years, and interim periods within those fiscal years, beginning
 after December 15, 2019. The Company is currently evaluating
 the impact of the adoption of this update on its consolidated
 financial statements.

- added (2018-11-06):
[0001193125-18-319643:note_history:31]
In July 2018, the FASB issued ASU 2018-11, “Leases
 (Topic 842), Target Improvements.” This ASU provided guidance
 on comparative reporting requirements for initial adoption. This
 ASU also provides additional guidance for lessors, on separating
 lease and non-lease components
 in a contract and allocating the consideration in the contract to
 the separate components. For public business entities, this update
 is effective for fiscal years beginning after December 15,
 2018, including interim periods within those fiscal years. Early
 adoption is permitted. The Company is currently evaluating the
 impact of the adoption of this update on its consolidated financial
 statements.

- added (2018-11-06):
[0001193125-18-319643:note_history:32]
In July 2018, the FASB issued ASU 2018-10, “Codification
 Improvements to Topic 842, Leases.” The amendment in this
 update affects narrow aspects of the guidance issued in the
 amendments in update 2016-02 on various
 matters. For public business entities, this update is effective for
 fiscal years beginning after December 15, 2018, including
 interim periods within those fiscal years. Early adoption is
 permitted. The Company is currently evaluating the impact of the
 adoption of this update on its consolidated financial
 statements.

- changed (2018-11-06):
[0001193125-18-319643:note_history:33]
In January 2017, the FASB issued ASU 2017-04, “Intangibles
 – Goodwill and Other (Topic 350): Simplifying the Test for
 Goodwill Impairment.” This amendment modified the concept of
 impairment assessment from the condition that exists when the
 carrying amount of goodwill exceeds its implied fair value to the
 condition that exists when the carrying amount of a reporting unit
 exceeds its fair value. Public companies that are SEC filers should
 adopt the amendment for its annual and any interim goodwill
 impairment tests in fiscal years beginning after December 15,
 2019. Early adoption is permitted for interim or annual goodwill
 impairment tests performed on testing dates after January 1,
 2017. The Company does not expect the amendments will impact its
 consolidated financial statements.
  (was, 2018-05-08, similarity 0.9295):
[0001193125-18-155969:note_history:33]
In January 2017, the FASB issued ASU 2017-04, “Intangibles –
 Goodwill and Other (Topic 350): Simplifying the Test for Goodwill
 Impairment.” This amendment modified the concept of
 impairment assessment from the condition that exists when the
 carrying amount of goodwill exceeds its implied fair value to the
 condition that exists when the carrying amount of a reporting unit
 exceeds its fair value. Public companies that are SEC filers should
 adopt the amendment for its annual and any interim goodwill
 impairment tests in fiscal years beginning after December 15,
 2019. Early adoption is permitted for interim or annual goodwill
 impairment tests performed on testing dates after January 1,
 2017. The Company is currently evaluating the impact of the
 adoption of this update on its consolidated financial
 statements.

- removed (2018-11-06):
[0001193125-18-155969:note_history:34]
On September 14, 2016, the Company acquired 100% shareholding
 in Global CEM Solutions, Ltd. and all of its subsidiaries
 (including Fabrinet UK), a privately-held group located
 in Wiltshire, United Kingdom. The unaudited condensed
 consolidated financial statements of the Company include the
 financial position, results of operations and the cash flows of
 Fabrinet UK commencing as of the acquisition date. See Note
 8—Business acquisition for further details on the accounting
 for this transaction.

- removed (2018-11-06):
[0001193125-18-155969:note_history:35]
In November 2017, the Financial Accounting Standards Board
 (“FASB”) issued Accounting Standards Update
 (“ASU”) 2017-14, “Income Statement
 – Reporting Comprehensive Income (Topic 220), Revenue
 Recognition (Topic 605), and Revenue from Contracts with Customers
 (Topic 606): Amendments to SEC Paragraphs Pursuant to the Staff
 Accounting Bulletin (“SAB”) No. 116 and SEC
 Release No. 33-10403”. This ASU
 amended, superseded and added certain SEC paragraphs in Topic 220,
 Topic 605 and Topic 606 to reflect the August 2017 issuance of SEC
 Staff Accounting Bulletin (SAB) 116 and SEC Release No. 33-10403. The SEC staff
 issued SAB 116 to align its revenue guidance with Accounting
 Standards Codification (ASC) 606. For public business entities,
 this update is effective for fiscal years beginning after
 December 15, 2017, including interim periods within those
 fiscal years. Early application is permitted. The Company is
 currently evaluating the impact of the adoption of this update on
 its consolidated financial statements.

- removed (2018-11-06):
[0001193125-18-155969:note_history:36]
In September 2017, the FASB issued ASU 2017-13, “Revenue Recognition
 (Topic 605), Revenue from Contracts with Customers (Topic 606),
 Leases (Topic 840), and Leases (Topic 842): Amendments to SEC
 Paragraphs Pursuant to the Staff Announcement at the July 20,
 2017 EITF Meeting and Rescission of Prior SEC Staff Announcements
 and Observer Comments.” The amendment delays the mandatory
 adoption of Topic 606 and Topic 842 for certain entities, revises
 the guidance related to performance-based incentive fees in Topic
 605 and revises the guidance related to leases in Topic 840 and
 Topic 842. The revisions to the lease guidance eliminate language
 specific to certain sale-leaseback arrangements, guarantees of
 lease residual assets and loans made by lessees to owner-lessors.
 Also included is an amendment to Topic 842 to retain the guidance
 in Topic 840 covering the impact of changes in tax rates on
 investments in leveraged leases. This guidance, which is effective
 immediately, generally relates to the adoption of Topic 606 and
 Topic 842. The Company does not expect the amendments will impact
 its consolidated financial statements.

- removed (2018-11-06):
[0001193125-18-155969:note_history:37]
In January 2017, the FASB issued ASU 2017-03, “Accounting Changes and
 Error Corrections (Topic 250) and Investments – Equity Method
 and Joint Ventures (Topic 323): Amendments to SEC Paragraphs
 Pursuant to Staff Announcements at the September 22, 2016 and
 November 17, 2016 EITF Meetings.” The amendment provides
 guidance to the Company in relation to the disclosure of the impact
 that ASU 2014-09, ASU
 2016-02 and ASU
 2016-13 will have on the
 Company’s financial statements when adopted. The Company is
 currently evaluating the impact of the adoption of this update on
 its consolidated financial statements.

- removed (2018-11-06):
[0001193125-18-155969:note_history:38]
In January 2017, the FASB issued ASU 2017-01, “Business Combination
 (Topic 805): Clarifying the Definition of a Business.” This
 amendment clarifies the definition of a business to assist entities
 when evaluating whether transactions should be accounted for as
 acquisitions (or disposals) of assets or business. For public
 companies, this ASU is effective for annual periods beginning after
 December 15, 2017, including interim periods within those
 periods. Early adoption is permitted for the transactions that
 occur before the issuance date or effective date of the amendment,
 only when the transaction has not been reported in financial
 statements that have been issued or made available for issuance.
 The Company does not expect that the adoption of this update will
 have a material impact on its consolidated financial
 statements.

- removed (2018-11-06):
[0001193125-18-155969:note_history:39]
In August 2016, the FASB issued ASU 2016-15, “Classification of
 Certain Cash Receipts and Cash Payments (a consensus of the
 Emerging Issues Task Force).” The amendments in this ASU
 provide guidance on the presentation of certain cash receipts and
 cash payments in the statement of cash flows in order to reduce
 diversity in existing practice. The amendments in ASU 2016-15 are effective for public
 business entities for fiscal years beginning after
 December 15, 2017, and interim periods within those fiscal
 years. Early adoption is permitted, including adoption in an
 interim period. The Company is currently evaluating the impact of
 the adoption of this update on its consolidated financial
 statements.

- removed (2018-11-06):
[0001193125-18-155969:note_history:40]
In January 2016, the FASB issued ASU 2016-01, “Financial Instruments
 – Overall (Subtopic 825-10): Recognition and Measurement
 of Financial Assets and Financial Liabilities.” This new
 guidance requires certain equity investments to be measured at fair
 value, use of the exit price notion and separate presentation of
 financial assets and financial liabilities by measurement category
 and form of financial asset on the balance sheet or the
 accompanying notes to the financial statements. The ASU on
 recognition and measurement will take effect for public companies
 for fiscal years beginning after December 15, 2017, including
 interim periods within those fiscal years. In addition, in
 February 2018, the FASB issued ASU 2018-03, “Technical Corrections
 and Improvements to Financial Instruments – Overall (Subtopic
 825-10), Recognition and
 Measurement of Financial Assets and Financial Liabilities. This
 guidance clarifies certain aspects of the guidance issued in ASU
 2016-01 on (1) equity
 securities without a readily determinable fair value –
 discontinuation, (2) equity securities without a readily
 determinable fair value – adjustments, (3) forward
 contracts and purchased options, (4) presentation requirements
 for certain fair value option liabilities, and (5) fair value
 option liabilities denominated in a foreign currency. The Company
 is currently evaluating the impact of the adoption of this update
 on its consolidated financial statements.

- removed (2018-11-06):
[0001193125-18-155969:note_history:41]
In May 2014, the FASB issued ASU 2014-09, “Revenue from Contracts
 with Customers (Topic 606), issued as a new Topic, Accounting
 Standards Codification.” The core principle of this amendment
 is that an entity should recognize revenue to depict the transfer
 of promised goods or services to customers in an amount that
 reflects the consideration to which the entity expects to be
 entitled in exchange for those goods or services. This update is
 effective for public companies, as amended by ASU 2015-14, for annual reporting periods
 beginning after December 15, 2017, including interim periods
 within that reporting period. Earlier application of this guidance
 is permitted, but not before the original date of December 15,
 2016, which can be adopted either retrospectively to each prior
 reporting period presented or as a cumulative-effect adjustment as
 of the date of adoption. Subsequently, in March 2016 and April
 2016, the FASB issued ASU 2016-08 and ASU 2016-10, respectively, to clarify the
 implementation guidance on principle versus agent considerations
 and address the potential diversity in practice at initial
 application and cost; and the complexity of applying Topic 606,
 both at transition and on an ongoing basis related to
 identification of performance obligations and licensing
 arrangements; and ASU 2016-12 and ASU 2016-20 in May 2016 and December 2016,
 respectively, to improve certain aspects of Topic 606, with the
 same effective date as ASU 2015-14. The Company will adopt this
 standard during its fiscal year ending June 28, 2019. In the
 current period, the Company is assessing the contracts with its
 customers to identify the impact to its consolidated financial
 statements. The Company expects to conclude the impact to its
 consolidated financial statements in the coming quarter.

- removed (2018-11-06):
[0001193125-18-155969:note_history:42]
New Accounting Pronouncements – adopted by the
 Company

- removed (2018-11-06):
[0001193125-18-155969:note_history:43]
In February 2018, the FASB issued ASU 2018-02 “Income Statement
 – Reporting Comprehensive Income (Topic 220),
 Reclassification of Certain Tax Effects from Accumulated Other
 Comprehensive Income.” This ASU which allows companies to
 reclassify stranded tax effects in accumulated other comprehensive
 income (loss) that have been caused by the Tax Cuts and Jobs Act of
 2017 (the Act) to retained earnings for each period in which the
 effect of the change in the U.S. federal corporate income tax rate
 is recorded. The FASB has made the reclassification
 optional. In addition, in March 2018, the FASB issued ASU
 2018-05, “Income
 Taxes (Topic 740), Amendments to SEC Paragraphs Pursuant to SEC
 Staff Accounting Bulletin No. 118,” which updates the
 income tax accounting in U.S. GAAP to reflect SEC guidance released
 on December 22, 2017, when the Act was signed into law. The
 Company adopted these updates with no impact to the unaudited
 condensed consolidated financial statements.

- removed (2018-11-06):
[0001193125-18-155969:note_history:44]
In August 2017, the FASB issued ASU 2017-12, “Derivatives and
 Hedging (Topic 815): Targeted Improvements to Accounting for
 Hedging Activities.” The amendments better align an
 entity’s risk management activities and financial reporting
 for hedging relationships through changes to both the designation
 and measurement guidance for qualifying hedging relationships and
 the presentation of hedge results. To meet that objective, the
 amendments expand and refine hedge accounting for both nonfinancial
 and financial risk components and align the recognition and
 presentation of the effects of the hedging instrument and the
 hedged item in the financial statements. The amendments also make
 certain targeted improvements to simplify the application of hedge
 accounting guidance and ease the administrative burden of hedge
 documentation requirements and assessing hedge effectiveness. This
 ASU is the final version of Proposed Accounting Standards Update
 2016-310—Derivatives
 and Hedging (Topic 815): Targeted Improvements to Accounting for
 Hedging Activities, which has been deleted. During the first nine
 months of fiscal year 2018, the Company adopted this update with no
 impact to the unaudited condensed consolidated financial
 statements.

- removed (2018-11-06):
[0001193125-18-155969:note_history:45]
In November 2016, the FASB issued ASU 2016-18, “Statement of Cash
 Flows (Topic 230): Restricted Cash,” which requires the
 statement of cash flows to explain the change during the period in
 the total of cash, cash equivalents and restricted cash or
 restricted cash equivalents. The Company has early adopted this
 update in the second quarter of fiscal year 2017 on a retrospective
 basis. As of March 30, 2018, restricted cash in connection
 with business acquisition of $3.6 million was presented in the
 statement of cash flows as cash, cash equivalents and restricted
 cash.

- removed (2018-11-06):
[0001193125-18-155969:note_history:46]
In March 2016, the FASB issued ASU 2016-09, “Compensation
 – Stock Compensation (Topic 718): Improvements to Employee
 Share-Based Payment Accounting.” This ASU simplifies several
 aspects of the accounting for share-based payment award
 transactions, including, the income tax consequences,
 classification of awards as either equity or liabilities and
 classification on the statement of cash flows. The amendments in
 this update are effective for annual periods beginning after
 December 15, 2016, and interim periods within those annual
 periods, for public companies. Early adoption is permitted for any
 entity in any interim or annual period. During the first nine
 months of fiscal year 2018, the Company adopted this update with no
 impact to the unaudited condensed consolidated financial
 statements.

- removed (2018-11-06):
[0001193125-18-155969:note_history:47]
In March 2016, the FASB issued ASU 2016-05, “Derivatives and
 Hedging (Topic 815),” to clarify that a change in the
 counterparty to a derivative instrument that has been designated as
 a hedging instrument under Topic 815, does not, in and of itself,
 require designation of the hedging relationship, provided that all
 other hedge accounting criteria continue to be met. This guidance
 is effective for public entities for financial statements issued
 for fiscal years beginning after December 15, 2016 and interim
 periods within those fiscal years. During the first nine months of
 fiscal year 2018, the Company adopted this update with no impact to
 the unaudited condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-11-06):
[0001193125-18-319643:note_history:48]
| Rate (1) |  | Conditions |  |  | Maturity |  |  | As of September 28, 2018 |  |  | As of June 29, 2018 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current portion of long-term borrowing |  |  | $ | 3,250 |  |  | $ | 3,250 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.50% per annum |  |  | Repayable in quarterly installments |  |  |  | June 2023 |  |  | $ | 63,375 |  |  | $ | 64,188 |  |
|  |  |  |  |  |  |  |  |  |  |  | 63,375 |  |  |  | 64,188 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (3,250 | ) |  |  | (3,250 | ) |
| Non-current portion of long-term borrowings |  |  |  |  |  |  |  |  |  | $ | 60,125 |  |  | $ | 60,938 |  |

- changed (2018-11-06):
[0001193125-18-319643:note_history:49]
The movements of long-term borrowings for the three months ended
 September 28, 2018 and September 29, 2017 were as
 follows:
  (was, 2018-05-08, similarity 0.8302):
[0001193125-18-155969:note_history:49]
The movements of long-term loans for the nine months ended
 March 30, 2018 and March 31, 2017 were as follows:

- added (2018-11-06):
[0001193125-18-319643:note_history:50]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 28, 2018 |  |  | September 29, 2017 |  |
| Opening balance |  | $ | 64,188 |  |  | $ | 36,400 |  |
| Repayments during the period |  |  | (813 | ) |  |  | (3,400 | ) |
| Closing balance |  | $ | 63,375 |  |  | $ | 33,000 |  |

- changed (2018-11-06):
[0001193125-18-319643:note_history:51]
As of September 28, 2018, future maturities of long-term
 borrowings during each fiscal year were as follows:
  (was, 2018-05-08, similarity 0.8866):
[0001193125-18-155969:note_history:51]
As of March 30, 2018, future maturities of long-term debt
 during each fiscal year were as follows:

- changed (2018-11-06):
[0001193125-18-319643:note_history:52]
| (amount in thousands) |  |  |  |  |
| 2019 (remaining nine months) |  | $ | 2,438 |  |
| 2020 |  |  | 3,250 |  |
| 2021 |  |  | 3,250 |  |
| 2022 |  |  | 3,250 |  |
| 2023 |  |  | 51,187 |  |
| Total |  | $ | 63,375 |  |
  (was, 2018-05-08, similarity 0.7912):
[0001193125-18-155969:note_history:52]
| (amount in thousands) |  |  |  |
| 2018 (remaining three months) |  | $ | 3,400 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 26,200 |  |

- changed (2018-11-06):
[0001193125-18-319643:note_history:53]
The Company entered into a syndicated senior credit facility
 agreement (the “Facility Agreement”) with a consortium
 of banks on May 22, 2014. The Facility Agreement, led by Bank
 of America, provided for a $200.0 million credit line,
 comprised of a $150.0 million revolving loan facility and a
 $50.0 million delayed draw term loan facility. The revolving
 loan facility contains an accordion feature permitting Fabrinet to
 request an increase in the facility up to $100.0 million
 subject to customary terms and conditions and provided that no
 default or event of default exists at the time of request.
  (was, 2018-05-08, similarity 0.7738):
[0001193125-18-155969:note_history:53]
Fabrinet entered into a syndicated senior credit facility agreement
 (the “Facility Agreement”) with a consortium of banks
 on May 22, 2014. The Facility Agreement, led by Bank of
 America, provides for a $200.0 million credit line, comprised
 of a $150.0 million revolving loan facility and a
 $50.0 million delayed draw term loan facility. The revolving
 loan facility contains an accordion feature permitting Fabrinet to
 request an increase in the facility up to $100.0 million
 subject to customary terms and conditions and provided that no
 default or event of default exists at the time of request. The
 revolving loan facility terminates and all amounts outstanding are
 due and payable in full on May 22, 2019. The principal amount
 of any drawn term loans must be repaid according to scheduled
 quarterly amortization payments, with final payment of all amounts
 outstanding, plus accrued interest, being due May 22,
 2019.

- changed (2018-11-06):
[0001193125-18-319643:note_history:54]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. This
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. On
 July 22, 2016, the Company entered into the Fourth Amendment
 to the Facility Agreement to change the timing of filing certain
 financial information with the bank.
  (was, 2018-05-08, similarity 0.6366):
[0001193125-18-155969:note_history:54]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. On
 July 22, 2016, the Company entered into the Fourth Amendment
 to the Facility Agreement to change the timing of filing certain
 financial information with the bank. The Company fully drew
 down the term loan facility in fiscal year 2016. As of
 March 30, 2018, $39.0 million of the revolving borrowing
 and $26.2 million of the term loan borrowing was outstanding
 under the Facility Agreement, resulting in available credit
 facilities of $111.0 million. Borrowings under the revolving
 credit facility are classified as current liabilities in the
 unaudited condensed consolidated balance sheets as the Company has
 the periodic option to renew or pay, all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. During March 2018, the Company
 sent notices to the bank to renew the maturity date of its
 revolving borrowings. The bank approved the notices and extended
 the maturity to April 2018.

- changed (2018-11-06):
[0001193125-18-319643:note_history:55]
Loans under the Facility Agreement bear interest, at
 Fabrinet’s option, at a rate per annum equal to a LIBOR rate
 plus a spread of 1.75% to 2.50%, or a base rate, determined in
 accordance with the Facility Agreement, plus a spread of 0.75% to
 1.50%, in each case with such spread determined based on
 Fabrinet’s consolidated total leverage ratio for the
 preceding four fiscal quarter period. Interest is due and payable
 quarterly in arrears for loans bearing interest at the base rate
 and at the end of an interest period (or at each three-month
 interval in the case of loans with interest periods greater than
 three months) in the case of loans bearing interest at the LIBOR
 rate.
  (was, 2018-05-08, similarity 0.919):
[0001193125-18-155969:note_history:55]
Loans under the Facility Agreement bear interest, at
 Fabrinet’s option, at a rate per annum equal to a LIBOR rate
 plus a spread of 1.75% to 2.50%, or a base rate plus a spread of
 0.75% to 1.50%, determined in accordance with the Facility
 Agreement in each case with such spread determined based on
 Fabrinet’s consolidated total leverage ratio for the
 preceding four fiscal quarter period. Interest is due and payable
 quarterly in arrears for loans bearing interest at the base rate
 and at the end of an interest period (or at each three-month
 interval in the case of loans with interest periods greater than
 three months) in the case of loans bearing interest at the LIBOR
 rate.

- changed (2018-11-06):
[0001193125-18-319643:note_history:56]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or
 the equivalent under the local law, can be effected.
  (was, 2018-05-08, similarity 0.9953):
[0001193125-18-155969:note_history:56]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material of
 its subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or
 the equivalent under the local law, can be effected.

- changed (2018-11-06):
[0001193125-18-319643:note_history:57]
The Facility Agreement contains customary affirmative and negative
 covenants. Negative covenants include, among other things,
 limitations on liens, indebtedness, investments, mergers, sales of
 assets, changes in the nature of the business, dividends and
 distributions, affiliate transactions and capital expenditures. The
 Facility Agreement contains financial covenants requiring Fabrinet
 to maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage ratio
 of not more than 2.50:1.00; and (iv) a minimum quick ratio of
 not less than 1.10:1.00. Each of these financial covenants is
 calculated on a consolidated basis for the consecutive four fiscal
 quarter period then ended.
  (was, 2018-05-08, similarity 0.9392):
[0001193125-18-155969:note_history:57]
The Facility Agreement contains customary affirmative and negative
 covenants. Negative covenants include, among other things,
 limitations on liens, indebtedness, investments, mergers, sales of
 assets, changes in the nature of the business, dividends and
 distributions, affiliate transactions and capital expenditures. The
 Facility Agreement contains financial covenants requiring Fabrinet
 to maintain: (1) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (2) a minimum debt service coverage ratio of
 not less than 1.50:1.00; (3) a maximum senior leverage ratio of not
 more than 2.50:1.00; and (4) a minimum quick ratio of not less
 than 1.10:1.00. Each of these financial covenants is calculated on
 a consolidated basis for the consecutive four fiscal quarter period
 then ended. As of March 30, 2018, the Company was in
 compliance with all covenants under the Facility Agreement.

- added (2018-11-06):
[0001193125-18-319643:note_history:58]
On June 4, 2018, the Company entered into the Fifth Amendment
 to the Facility Agreement to (i) reduce the revolving
 commitments thereunder from $150.0 million to
 $25.0 million, (ii) extend the termination date of the
 revolving commitments from May 22, 2019 to June 4, 2023,
 (iii) refinance the then-existing term loan and revolving loans
 under the Facility Agreement into a $65.0 million term loan
 and (iv) reduce the applicable interest rate margins and
 commitment fees. Term loans must be repaid in quarterly
 installments, beginning on June 30, 2018, with the remaining
 outstanding principal and accrued and unpaid interest being due and
 payable on June 4, 2023. After giving effect to the amendment,
 $65.0 million aggregate principal amount of term loans and no
 revolving loans were outstanding under the Facility Agreement as of
 June 28, 2018. In addition, the Fifth Amendment to the
 Facility Agreement contains an accordion feature permitting the
 Company to request an increase in the revolving loan facility to
 provide up to an aggregate of $200.0 million in additional
 commitments, subject to customary terms and conditions, and
 provided that no default or event of default exists at the time of
 such request. The Fifth Amendment is considered debt extinguishment
 of which the Company recognized interest expenses of
 $0.1 million from remaining unamortized debt issuance costs in
 consolidated statements of operations and comprehensive income. As
 of September 28, 2018 and June 29, 2018,
 $63.4 million and $64.2 million aggregate principal
 amount of term loans and no revolving loans were outstanding under
 the Facility Agreement.

- added (2018-11-06):
[0001193125-18-319643:note_history:59]
After the Fifth Amendment, loans under the Facility Agreement bear
 interest, at Fabrinet’s option, at a rate per annum equal to
 a LIBOR rate plus a spread of 1.50% to 2.25%, or a base rate plus a
 spread of 0.50% to 1.25%, determined in accordance with the
 Facility Agreement in each case with such spread determined based
 on Fabrinet’s consolidated total leverage ratio for the
 preceding four fiscal quarter period.

- added (2018-11-06):
[0001193125-18-319643:note_history:60]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future material direct
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $20.0 million in a jurisdiction where a control agreement, or
 the equivalent under the local law, can be effected.

- added (2018-11-06):
[0001193125-18-319643:note_history:61]
Moreover, the Fifth Amendment of Facility Agreement amends
 customary affirmative and negative covenants. Negative covenants
 include, among other things, limitations on liens, indebtedness,
 investments, mergers, sales of assets, changes in the nature of the
 business, dividends and distributions, affiliate transactions and
 capital expenditures. The Facility Agreement contains financial
 covenants requiring Fabrinet to maintain: (1) a minimum
 tangible net worth of not less than $338.0 million plus 50% of
 quarterly net income after June 30, 2018, exclusive of
 quarterly losses; (2) a minimum debt service coverage ratio of
 not less than 1.50:1.00; (3) a maximum total leverage ratio of not
 more than 2.50:1.00; and (4) a minimum quick ratio of not less
 than 1.10:1.00. Each of these financial covenants is calculated on
 a consolidated basis for the consecutive four fiscal quarter period
 then ended. As of September 28, 2018, the Company was in
 compliance with all covenants under the Facility Agreement.

- changed (2018-11-06):
[0001193125-18-319643:note_history:62]
Fabrinet intends to use the proceeds of the credit line to finance
 its future expansion in the United States and Thailand, and for
 general corporate purposes including mergers and acquisitions of
 complementary manufacturing businesses or technology, although
 Fabrinet has no current commitments with respect to any such
 acquisitions.
  (was, 2018-05-08, similarity 0.9529):
[0001193125-18-155969:note_history:62]
Fabrinet intends to use the proceeds of the credit line to finance
 its future manufacturing buildings in the United States and
 Thailand, and for general corporate purposes including mergers and
 acquisitions of complementary manufacturing businesses or
 technology, although Fabrinet has no current commitments with
 respect to any such acquisitions.

- changed (2018-11-06):
[0001193125-18-319643:note_history:63]
On July 24, 2017, the Company entered into an interest rate
 swap agreement (the “Swap Agreement”), which the
 Company did not designate as hedging instruments. The Swap
 Agreement was used to mitigate interest rate risk and improve the
 interest rate profile of the Company’s debt obligations. The
 terms of the Swap Agreement effectively converted the floating
 interest rate of the term loans under the Facility Agreement to the
 fixed interest rate of 1.55% per annum through maturity of the term
 loan in May 2019. On June 4, 2018, the Company terminated the
 Swap Agreement in connection with entering into the Fifth Amendment
 to the Facility Agreement.
  (was, 2018-05-08, similarity 0.7546):
[0001193125-18-155969:note_history:63]
On July 24, 2017, the Company entered into an interest rate
 swap agreement (the “Swap Agreement”), which the
 Company did not designate as hedging instruments. The Swap
 Agreement was used to mitigate interest rate risk and improve the
 interest rate profile of the Company’s debt obligations. The
 terms of the Swap Agreement effectively convert the floating
 interest rate of the term loans under the Facility Agreement to the
 fixed interest rate of 1.55% per annum through maturity of the term
 loan in May 2019. The swap transactions are due and settled
 monthly. During the nine months ended March 30, 2018, the
 Company included a net loss of $0.04 million from the
 settlement of the Swap Agreement as interest expenses in the
 unaudited condensed consolidated statements of operations and
 comprehensive income.

- added (2018-11-06):
[0001193125-18-319643:note_history:64]
On July 25, 2018, the Company entered into Swap Agreement,
 which the Company did not designate as hedging instruments. The
 Swap Agreement was used to mitigate interest rate risk and improve
 the interest rate profile of the Company’s debt obligations.
 The terms of the Swap Agreement effectively converted the floating
 interest rate of the term loans under the Facility Agreement to the
 fixed interest rate of 2.86% per annum through maturity of the term
 loan in June 2023. The swap transactions are due and settled
 monthly. During the three months ended September 28, 2018, the
 Company included a net loss of $33 thousand from the
 settlement of the Swap Agreement as interest expenses in the
 unaudited condensed consolidated statements of operations and
 comprehensive income.

- changed (2018-11-06):
[0001193125-18-319643:note_history:65]
Undrawn available credit facilities classified by availability
 period of future borrowing as of September 28, 2018 and
 June 29, 2018 were as follows:
  (was, 2018-05-08, similarity 0.9635):
[0001193125-18-155969:note_history:65]
Undrawn available credit facilities classified by availability
 period of future borrowing as of March 30, 2018 and
 June 30, 2017 were as follows:

- changed (2018-11-06):
[0001193125-18-319643:note_history:66]
| (amount in thousands) |  | September 28, 2018 |  |  | June 29, 2018 |  |
| Expiring within one year |  | $ | — |  |  | $ | — |  |
| Expiring beyond one year |  | $ | 25,000 |  |  | $ | 25,000 |  |
  (was, 2018-05-08, similarity 0.7759):
[0001193125-18-155969:note_history:66]
| (amount in thousands) |  | March 30, 2018 |  |  | June 30, 2017 |  |
| Short-term |  | $ | — |  |  | $ | 1,965 |  |
| Long-term |  | $ | 111,000 |  |  | $ | 116,000 |  |

- removed (2018-11-06):
[0001193125-18-155969:note_history:67]
| (amount in thousands) |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  | Maturity |  |  | As of March 30, 2018 |  |  | As of June 30, 2017 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR(1) + 1.75% per annum |  | Repayable in 1 to 6 months |  |  | April 2018 | (2) |  | $ | 39,000 |  |  | $ | 34,000 |  |
| Short-term loans from bank: |  |
| Bank Base rate +1.85% per annum |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  |  |  | — |  |  |  | 1,003 |  |
| Current portion of long-term borrowing |  |  |  | 13,600 |  |  |  | 13,600 |  |
|  |  |  |  | 52,600 |  |  |  | 48,603 |  |
| Less: Unamortized debt issuance costs |  |  |  | (136 | ) |  |  | (201 | ) |
|  |  |  |  |  |  |  |  | $ | 52,464 |  |  | $ | 48,402 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  | Repayable in quarterly installments |  |  | May 2019 |  |  | $ | 26,200 |  |  | $ | 36,400 |  |
| Less: Current portion |  |  |  |  |  |  |  |  | (13,600 | ) |  |  | (13,600 | ) |
| Unamortized debt issuance costs |  |  |  | (5 | ) |  |  | (99 | ) |
| Non-current portion |  |  |  |  |  |  |  | $ | 12,595 |  |  | $ | 22,701 |  |

- removed (2018-11-06):
[0001193125-18-155969:note_history:68]
| (2) | In March 2018, the maturity date was extended to April 2018. |

- removed (2018-11-06):
[0001193125-18-155969:note_history:69]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 30, 2018 |  |  | March 31, 2017 |  |
| Opening balance |  | $ | 36,400 |  |  | $ | 54,500 |  |
| Repayments during the period |  |  | (10,200 | ) |  |  | (14,700 | ) |
| Closing balance |  | $ | 26,200 |  |  | $ | 39,800 |  |

- removed (2018-11-06):
[0001193125-18-155969:note_history:70]
Short-term loans from bank

- removed (2018-11-06):
[0001193125-18-155969:note_history:71]
In connection with the business acquisition in the first quarter of
 fiscal year 2017, the Company assumed a secured borrowing
 agreement. In the first quarter of fiscal year 2018, the Company
 fully repaid these short-term loans and sent a notification letter
 to the bank to terminate this secured borrowing agreement. As a
 result, the bank released secured trade accounts receivable and the
 way chattels mortgage over the plant and machine of Fabrinet
 UK.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-06):
[0001193125-18-319643:note_history:72]
The movements of long-term borrowings for the three months ended
 September 28, 2018 and September 29, 2017 were as
 follows:
  (was, 2018-05-08, similarity 0.8302):
[0001193125-18-155969:note_history:72]
The movements of long-term loans for the nine months ended
 March 30, 2018 and March 31, 2017 were as follows:

- added (2018-11-06):
[0001193125-18-319643:note_history:73]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 28, 2018 |  |  | September 29, 2017 |  |
| Opening balance |  | $ | 64,188 |  |  | $ | 36,400 |  |
| Repayments during the period |  |  | (813 | ) |  |  | (3,400 | ) |
| Closing balance |  | $ | 63,375 |  |  | $ | 33,000 |  |

- removed (2018-11-06):
[0001193125-18-155969:note_history:74]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 30, 2018 |  |  | March 31, 2017 |  |
| Opening balance |  | $ | 36,400 |  |  | $ | 54,500 |  |
| Repayments during the period |  |  | (10,200 | ) |  |  | (14,700 | ) |
| Closing balance |  | $ | 26,200 |  |  | $ | 39,800 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-11-06):
[0001193125-18-319643:note_history:75]
| Rate (1) |  | Conditions |  |  | Maturity |  |  | As of September 28, 2018 |  |  | As of June 29, 2018 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current portion of long-term borrowing |  |  | $ | 3,250 |  |  | $ | 3,250 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.50% per annum |  |  | Repayable in quarterly installments |  |  |  | June 2023 |  |  | $ | 63,375 |  |  | $ | 64,188 |  |
|  |  |  |  |  |  |  |  |  |  |  | 63,375 |  |  |  | 64,188 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (3,250 | ) |  |  | (3,250 | ) |
| Non-current portion of long-term borrowings |  |  |  |  |  |  |  |  |  | $ | 60,125 |  |  | $ | 60,938 |  |

- removed (2018-11-06):
[0001193125-18-155969:note_history:76]
| (amount in thousands) |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  | Maturity |  |  | As of March 30, 2018 |  |  | As of June 30, 2017 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR(1) + 1.75% per annum |  | Repayable in 1 to 6 months |  |  | April 2018 | (2) |  | $ | 39,000 |  |  | $ | 34,000 |  |
| Short-term loans from bank: |  |
| Bank Base rate +1.85% per annum |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  |  |  | — |  |  |  | 1,003 |  |
| Current portion of long-term borrowing |  |  |  | 13,600 |  |  |  | 13,600 |  |
|  |  |  |  | 52,600 |  |  |  | 48,603 |  |
| Less: Unamortized debt issuance costs |  |  |  | (136 | ) |  |  | (201 | ) |
|  |  |  |  |  |  |  |  | $ | 52,464 |  |  | $ | 48,402 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  | Repayable in quarterly installments |  |  | May 2019 |  |  | $ | 26,200 |  |  | $ | 36,400 |  |
| Less: Current portion |  |  |  |  |  |  |  |  | (13,600 | ) |  |  | (13,600 | ) |
| Unamortized debt issuance costs |  |  |  | (5 | ) |  |  | (99 | ) |
| Non-current portion |  |  |  |  |  |  |  | $ | 12,595 |  |  | $ | 22,701 |  |

- removed (2018-11-06):
[0001193125-18-155969:note_history:77]
| (2) | In March 2018, the maturity date was extended to April 2018. |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-06):
[0001193125-18-319643:note_history:78]
Undrawn available credit facilities classified by availability
 period of future borrowing as of September 28, 2018 and
 June 29, 2018 were as follows:
  (was, 2018-05-08, similarity 0.9635):
[0001193125-18-155969:note_history:78]
Undrawn available credit facilities classified by availability
 period of future borrowing as of March 30, 2018 and
 June 30, 2017 were as follows:

- changed (2018-11-06):
[0001193125-18-319643:note_history:79]
| (amount in thousands) |  | September 28, 2018 |  |  | June 29, 2018 |  |
| Expiring within one year |  | $ | — |  |  | $ | — |  |
| Expiring beyond one year |  | $ | 25,000 |  |  | $ | 25,000 |  |
  (was, 2018-05-08, similarity 0.7759):
[0001193125-18-155969:note_history:79]
| (amount in thousands) |  | March 30, 2018 |  |  | June 30, 2017 |  |
| Short-term |  | $ | — |  |  | $ | 1,965 |  |
| Long-term |  | $ | 111,000 |  |  | $ | 116,000 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-11-06):
[0001193125-18-319643:note_history:80]
As of September 28, 2018, future maturities of long-term
 borrowings during each fiscal year were as follows:
  (was, 2018-05-08, similarity 0.8866):
[0001193125-18-155969:note_history:80]
As of March 30, 2018, future maturities of long-term debt
 during each fiscal year were as follows:

- changed (2018-11-06):
[0001193125-18-319643:note_history:81]
| (amount in thousands) |  |  |  |  |
| 2019 (remaining nine months) |  | $ | 2,438 |  |
| 2020 |  |  | 3,250 |  |
| 2021 |  |  | 3,250 |  |
| 2022 |  |  | 3,250 |  |
| 2023 |  |  | 51,187 |  |
| Total |  | $ | 63,375 |  |
  (was, 2018-05-08, similarity 0.7912):
[0001193125-18-155969:note_history:81]
| (amount in thousands) |  |  |  |
| 2018 (remaining three months) |  | $ | 3,400 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 26,200 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-11-06):
[0001193125-18-319643:note_history:82]
The following table presents total revenues by geographic
 regions:

- added (2018-11-06):
[0001193125-18-319643:note_history:83]
| (amount in thousands) |  | Three Months Ended September 28, 2018 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 179,826 |  |  |  | 47.7 | % |
| Asia-Pacific |  |  | 151,947 |  |  |  | 40.3 |  |
| Europe |  |  | 45,404 |  |  |  | 12.0 |  |
|  |  | $ | 377,177 |  |  |  | 100.0 | % |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-11-06):
[0001193125-18-319643:note_history:84]
| 3. | Revenues |

- added (2018-11-06):
[0001193125-18-319643:note_history:85]
The Company derives total revenues primarily from the assembly of
 products under supply agreements with its customers and the
 fabrication of customized optics and glass. The Company recognizes
 revenue relating to contracts with customers that depicts the
 transfer of promised goods or services to customers in an amount
 reflecting the consideration to which the Company expects to be
 entitled in exchange for such goods or services. In order to meet
 this requirement, the Company applies the following five steps:
 (1) identify the contract with a customer, (2) identify
 the performance obligations in the contract, (3) determine the
 transaction price, (4) allocate the transaction price to the
 performance obligations in the contract, and (5) recognize
 revenue when a performance obligation is satisfied. Revenue is
 recognized net of any taxes collected from customers, which is
 subsequently remitted to governmental authorities.

- added (2018-11-06):
[0001193125-18-319643:note_history:86]
A performance obligation is a promise in a contract to transfer a
 distinct good or service to the customer. In contracts with
 multiple performance obligations, the Company identifies each
 performance obligation and evaluates whether the performance
 obligation is distinct within the context of the contract at
 contract inception. The majority of the Company’s contracts
 have a single performance obligation as the promise to transfer the
 individual goods or services is not separately identifiable from
 other promises in the contracts and, therefore, not distinct.

- added (2018-11-06):
[0001193125-18-319643:note_history:87]
The Company manufactures products that are customized to
 customers’ specifications, however, control of the products
 is typically transferred to the customer at the point in time the
 product is either shipped or delivered, depending on the terms of
 the arrangement, as the criteria for overtime recognition are not
 met. On the evaluation of the contracts the Company identified that
 it did not have contractual rights to bill profit for work in
 progress in the event of a contract termination which is expected
 to be infrequent. Further, in limited circumstances,
 substantive acceptance by the customer exists which results in the
 deferral of revenue until acceptance is formally received from the
 customer. Judgment may be required in determining if the acceptance
 clause is substantive.

- added (2018-11-06):
[0001193125-18-319643:note_history:88]
Certain customers may request the Company to store finished
 products purchased by them at the Company’s
 warehouse. In these instances, the Company receives a written
 request from the customer asking the Company to hold the inventory
 at the Company’s warehouse and the ordered goods cannot be
 used to fulfill other customer orders. In these situations,
 revenue is only recognized when the goods are completed and ready
 for shipment and transferred to the Company’s warehouse.

- added (2018-11-06):
[0001193125-18-319643:note_history:89]
Our customers generally are obligated to purchase finished goods
 that we have manufactured according to their demand requirements.
 Materials that are not consumed by our customers within a specified
 period of time, or are no longer required due to a product’s
 cancellation or end-of-life, are typically
 designated as excess or obsolete inventory under our contracts.
 Once materials are designated as either excess or obsolete
 inventory, our customers are typically required to purchase such
 inventory from us even if they have chosen to cancel production of
 the related products. The excess or obsolete inventory is shipped
 to the customer and revenue is recognized upon shipment.

- added (2018-11-06):
[0001193125-18-319643:note_history:90]
A contract’s transaction price is allocated to each distinct
 performance obligation and recognized as revenue when, or as, the
 performance obligation is satisfied. In determining the
 transaction price, the Company evaluates whether the price is
 subject to refund or adjustment to determine the net consideration
 to which the Company expects to be entitled. The Company generally
 does not grant return privileges, except for defective products
 during the warranty period. The Company generally provides a
 warranty of between one to five years on the product.

- added (2018-11-06):
[0001193125-18-319643:note_history:91]
Warranty provision

- added (2018-11-06):
[0001193125-18-319643:note_history:92]
Provisions for estimated expenses relating to product warranties
 are made at the time the products are sold using historical
 experience. Generally, this warranty is limited to workmanship and
 the Company’s liability is capped at the price of the
 product. The provisions will be adjusted when experience indicates
 an expected settlement will differ from initial estimates.

- added (2018-11-06):
[0001193125-18-319643:note_history:93]
Contract Assets and Liabilities

- added (2018-11-06):
[0001193125-18-319643:note_history:94]
A contract asset is recognized when the Company has recognized
 revenues, but not yet an invoice for payment. Contract assets are
 classified separately on the condensed consolidated balance sheets
 and transferred to accounts receivable when rights to payment
 become unconditional. The following table summarizes the activity
 in the Company’s contract assets during the three-month
 period ended September 29, 2018:

- added (2018-11-06):
[0001193125-18-319643:note_history:95]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 30, 2018 |  | $ | — |  |
| Cumulative effect adjustment at June 30, 2018 |  |  | 9,877 |  |
| Revenue recognized |  |  | 27,954 |  |
| Amounts collected or invoiced |  |  | (27,674 | ) |
| Ending balance, September 28, 2018 |  | $ | 10,157 |  |

- added (2018-11-06):
[0001193125-18-319643:note_history:96]
The Company continually evaluates whether advanced payment
 arrangements with customers result in the recognition of contract
 liabilities. No such liabilities existed as of September 28,
 2018 or June 29, 2018. Separately, accounts receivable, net,
 represents receivables from contracts with customers.

- added (2018-11-06):
[0001193125-18-319643:note_history:97]
Contract Costs

- added (2018-11-06):
[0001193125-18-319643:note_history:98]
The Company has elected the practical expedient to recognize the
 incremental costs of obtaining a contract as an expense when
 incurred if the amortization period of the asset that the Company
 otherwise would have recognized is one year or less. During the
 three months ended September 28, 2018, the Company did not
 have any incremental costs of obtaining the contract.

- added (2018-11-06):
[0001193125-18-319643:note_history:99]
Shipping and Handling

- added (2018-11-06):
[0001193125-18-319643:note_history:100]
Shipping costs billed to customers are recorded as revenue.
 Shipping and handling expense related to costs incurred to deliver
 product are recognized within cost of goods sold. The Company
 accounts for shipping and handling activities that occur after
 control has transferred as a fulfillment cost as opposed to a
 separate performance obligation, and the costs of shipping and
 handling are recognized concurrently with the related revenue.

- added (2018-11-06):
[0001193125-18-319643:note_history:101]
In accordance with the new revenue standard requirements, the
 disclosure of the impact of adoption on the Company’s
 unaudited condensed consolidated statements of operations and
 comprehensive income for the three months ended September 28,
 2018 and unaudited condensed consolidated balance sheets as of
 September 28, 2018 was as follows:

- added (2018-11-06):
[0001193125-18-319643:note_history:102]
Condensed Consolidated Statement of Operations

- added (2018-11-06):
[0001193125-18-319643:note_history:103]
Three Months Ended September 28, 2018

- added (2018-11-06):
[0001193125-18-319643:note_history:104]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | As Reported |  |  | Adjustment |  |  | Balance without ASC 606 Adoption |  |
| Revenues |  | $ | 377,177 |  |  | $ | (280 | )(1) |  | $ | 376,897 |  |
| Cost of revenues |  | $ | (336,901 | ) |  | $ | 249 | (2) |  | $ | (336,652 | ) |
| Gross profit |  | $ | 40,276 |  |  | $ | (31 | )(3) |  | $ | 40,245 |  |
| Net income |  | $ | 27,850 |  |  | $ | (31 | )(3) |  | $ | 27,819 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.76 |  |  | $ | (0.00 | ) |  | $ | 0.76 |  |
| Diluted |  | $ | 0.75 |  |  | $ | (0.00 | ) |  | $ | 0.75 |  |

- added (2018-11-06):
[0001193125-18-319643:note_history:105]
| (1) | Adjustment relates to certain manufacturing contracts with vendor managed inventory arrangements for which revenue was recognized at shipping. |

- added (2018-11-06):
[0001193125-18-319643:note_history:106]
| (2) | Adjustment relates to costs associated with revenue recognized. |

- added (2018-11-06):
[0001193125-18-319643:note_history:107]
| (3) | Adjustment relates to net impact on income upon adoption of ASC 606. |

- added (2018-11-06):
[0001193125-18-319643:note_history:108]
Condensed Consolidated Balance Sheets

- added (2018-11-06):
[0001193125-18-319643:note_history:109]
As of September 28, 2018

- added (2018-11-06):
[0001193125-18-319643:note_history:110]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | As Reported |  |  | Adjustments |  |  | Balance without ASC 606 Adoption |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract assets |  | $ | 10,157 |  |  | $ | (10,157 | )(1) |  | $ | — |  |
| Inventory, net |  | $ | 278,397 |  |  | $ | 8,921 | (2) |  | $ | 287,318 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 661,478 |  |  | $ | (1,236 | )(3) |  | $ | 660,242 |  |

- added (2018-11-06):
[0001193125-18-319643:note_history:111]
| (1) | Majority of adjustment relates to certain manufacturing contracts with vendor managed inventory arrangements for which revenue was recognized on shipment. |

- added (2018-11-06):
[0001193125-18-319643:note_history:112]
| (2) | Adjustment relates to reduction of finished goods inventory for vendor managed inventory. |

- added (2018-11-06):
[0001193125-18-319643:note_history:113]
| (3) | Adjustment relates to cumulative effect adjustment upon adoption of ASC 606. |

- added (2018-11-06):
[0001193125-18-319643:note_history:114]
Revenue by Geographic Area:

- added (2018-11-06):
[0001193125-18-319643:note_history:115]
Total revenues are attributed to a particular geographic area based
 on the bill-to-location of
 the customers. The Company operates primarily in three geographic
 regions: North America, Asia-Pacific and Europe. The following
 table presents total revenues by geographic regions:

- added (2018-11-06):
[0001193125-18-319643:note_history:116]
| (amount in thousands) |  | Three Months Ended September 28, 2018 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 179,826 |  |  |  | 47.7 | % |
| Asia-Pacific |  |  | 151,947 |  |  |  | 40.3 |  |
| Europe |  |  | 45,404 |  |  |  | 12.0 |  |
|  |  | $ | 377,177 |  |  |  | 100.0 | % |

- added (2018-11-06):
[0001193125-18-319643:note_history:117]
The following table sets forth our revenues by end market.

- added (2018-11-06):
[0001193125-18-319643:note_history:118]
| (amount in thousands) |  | Three Months Ended September 28, 2018 |  |  | As a % of Total Revenues |  |
| Optical communications |  | $ | 280,768 |  |  |  | 74.4 | % |
| Lasers, sensors and other |  |  | 96,409 |  |  |  | 25.6 |  |
| Total |  | $ | 377,177 |  |  |  | 100.0 | % |
