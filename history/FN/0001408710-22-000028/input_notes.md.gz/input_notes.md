# FN notes — 0001408710-22-000028


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001408710-22-000028:notes:1]
[same as prior period, unchanged from 0001408710-22-000018:notes:1]

[0001408710-22-000028:notes:2]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of March 25, 2022 and for the three and nine months ended March 25, 2022 and March 26, 2021 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 25, 2021.

[0001408710-22-000028:notes:3]
[same as prior period, unchanged from 0001408710-22-000018:notes:3]

[0001408710-22-000028:notes:4]
The results for the three and nine months ended March 25, 2022 may not be indicative of results for the year ending June 24, 2022 or any future periods.

[0001408710-22-000028:notes:5]
[same as prior period, unchanged from 0001408710-22-000018:notes:5]

[0001408710-22-000028:notes:6]
[same as prior period, unchanged from 0001408710-22-000018:notes:6]

[0001408710-22-000028:notes:7]
[same as prior period, unchanged from 0001408710-22-000018:notes:7]

[0001408710-22-000028:notes:8]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  March 25, 2022 and March 26, 2021 each consisted of 13 weeks. The nine months ended March 25, 2022 and March 26, 2021 each consisted of 39 weeks. Fiscal year 2022 will be comprised of 52 weeks and will end on June 24, 2022.

[0001408710-22-000028:notes:9]
[same as prior period, unchanged from 0001408710-22-000018:notes:9]

[0001408710-22-000028:notes:10]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2019-12, “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.” The amendments in this update simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify U.S. GAAP for other areas of Topic 740 by clarifying and amending existing guidance. The Company adopted this standard in the first quarter of fiscal year 2022 with no material impact on its unaudited condensed consolidated financial statements.

[0001408710-22-000028:notes:11]
[same as prior period, unchanged from 0001408710-22-000018:notes:11]

[0001408710-22-000028:notes:12]
In November 2021, FASB issued ASU 2021-10, “Government Assistance (Topic 832), Disclosures by Business Entities about Government Assistance,” which requires annual disclosures that increase the transparency of transactions involving government assistance, including (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The amendments in this update are effective for all entities within the ASU's scope for financial statements issued for annual periods beginning after December 15, 2021. This ASU will be effective for the Company in the first quarter of fiscal year 2023. Early adoption is permitted.  The Company is currently evaluating the impact of the adoption of this update on its consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001408710-22-000028:notes:13]
[same as prior period, unchanged from 0001408710-22-000018:notes:13]

[0001408710-22-000028:notes:14]
Revenues are attributed to a particular geographic area based on the bill-to-location of the Company’s customers. The Company operates in three geographic regions: North America; Asia-Pacific and others; and Europe.

[0001408710-22-000028:notes:15]
[same as prior period, unchanged from 0001408710-22-000018:notes:15]

[0001408710-22-000028:notes:16]
| (amount in thousands, except percentages) | Three Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 292,475 |  |  |  |  | 781,469 |  |  |  |
| Others (1) | 4,123 |  |  |  |  | 8,996 |  |  |  |
| Total revenue in North America | 296,598 |  |  | 52.5 | % |  | 790,465 |  |  | 47.2 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 70,956 |  |  |  |  | 210,009 |  |  |  |
| Malaysia | 51,188 |  |  |  |  | 163,306 |  |  |  |
| Hong Kong | 17,338 |  |  |  |  | 61,575 |  |  |  |
| Israel | 16,883 |  |  |  |  | 67,318 |  |  |  |
| Japan | 16,449 |  |  |  |  | 47,258 |  |  |  |
| China | 12,843 |  |  |  |  | 40,624 |  |  |  |
| Others | 10,559 |  |  |  |  | 34,349 |  |  |  |
| Total revenue in Asia-Pacific and others | 196,216 |  |  | 34.8 | % |  | 624,439 |  |  | 37.3 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 28,640 |  |  |  |  | 133,024 |  |  |  |
| U.K. | 21,632 |  |  |  |  | 64,151 |  |  |  |
| Germany | 10,688 |  |  |  |  | 28,098 |  |  |  |
| Others | 10,621 |  |  |  |  | 34,173 |  |  |  |
| Total revenue in Europe | $ | 71,581 |  |  | 12.7 | % |  | $ | 259,446 |  |  | 15.5 | % |
| Total revenue | $ | 564,395 |  |  | 100.0 | % |  | $ | 1,674,350 |  |  | 100.0 | % |

[0001408710-22-000028:notes:17]
| (amount in thousands, except percentages) | Three Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 230,177 |  |  |  |  | 661,410 |  |  |  |
| Others (1) | 618 |  |  |  |  | 1,459 |  |  |  |
| Total revenue in North America | 230,795 |  |  | 48.2 | % |  | 662,869 |  |  | 48.4 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Malaysia | 22,910 |  |  |  |  | 107,700 |  |  |  |
| India | 56,719 |  |  |  |  | 85,535 |  |  |  |
| Israel | 25,796 |  |  |  |  | 82,915 |  |  |  |
| Hong Kong | 21,524 |  |  |  |  | 63,397 |  |  |  |
| Japan | 18,582 |  |  |  |  | 56,223 |  |  |  |
| Others | 21,770 |  |  |  |  | 71,477 |  |  |  |
| Total revenue in Asia-Pacific and others | 167,301 |  |  | 34.9 | % |  | 467,247 |  |  | 34.1 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 47,096 |  |  |  |  | 149,696 |  |  |  |
| U.K. | 15,298 |  |  |  |  | 40,742 |  |  |  |
| Germany | 7,543 |  |  |  |  | 19,596 |  |  |  |
| Others | 11,284 |  |  |  |  | 29,633 |  |  |  |
| Total revenue in Europe | $ | 81,221 |  |  | 16.9 | % |  | $ | 239,667 |  |  | 17.5 | % |
| Total revenue | $ | 479,317 |  |  | 100.0 | % |  | $ | 1,369,783 |  |  | 100.0 | % |

[0001408710-22-000028:notes:18]
[same as prior period, unchanged from 0001408710-22-000018:notes:18]

[0001408710-22-000028:notes:19]
The following table presents revenues by end market:

[0001408710-22-000028:notes:20]
| (amount in thousands, except percentages) | Three Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |
| Optical communications | $ | 440,003 |  |  | 78.0 | % |  | $ | 1,318,087 |  |  | 78.7 | % |
| Lasers, sensors and other | 124,392 |  |  | 22.0 | % |  | 356,263 |  |  | 21.3 | % |
| Total | $ | 564,395 |  |  | 100.0 | % |  | $ | 1,674,350 |  |  | 100.0 | % |

[0001408710-22-000028:notes:21]
| (amount in thousands, except percentages) | Three Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |
| Optical communications | $ | 361,739 |  |  | 75.5 | % |  | $ | 1,053,496 |  |  | 76.9 | % |
| Lasers, sensors and other | 117,578 |  |  | 24.5 | % |  | 316,287 |  |  | 23.1 | % |
| Total | $ | 479,317 |  |  | 100.0 | % |  | $ | 1,369,783 |  |  | 100.0 | % |

[0001408710-22-000028:notes:22]
[same as prior period, unchanged from 0001408710-22-000018:notes:22]

[0001408710-22-000028:notes:23]
[same as prior period, unchanged from 0001408710-22-000018:notes:23]

[0001408710-22-000028:notes:24]
[same as prior period, unchanged from 0001408710-22-000018:notes:24]

[0001408710-22-000028:notes:25]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the nine months ended March 25, 2022:

[0001408710-22-000028:notes:26]
| (amount in thousands) | ContractAssets |
| Beginning balance, June 25, 2021 | $ | 11,878 |  |
| Revenue recognized | 37,195 |  |
| Amounts collected or invoiced | (35,505) |  |
| Ending balance, March 25, 2022 | $ | 13,568 |  |

[0001408710-22-000028:notes:27]
| (amount in thousands) | ContractLiabilities |
| Beginning balance, June 25, 2021 | $ | 1,680 |  |
| Advance payment received during the period | 4,898 |  |
| Revenue recognized | (4,655) |  |
| Ending balance, March 25, 2022 | $ | 1,923 |  |


## us-gaap:EarningsPerShareTextBlock

[0001408710-22-000028:notes:28]
[same as prior period, unchanged from 0001408710-22-000018:notes:28]

[0001408710-22-000028:notes:29]
[same as prior period, unchanged from 0001408710-22-000018:notes:29]

[0001408710-22-000028:notes:30]
|  | Three Months Ended |  | Nine Months Ended |
| (amount in thousands except per share amounts) | March 25,2022 |  | March 26,2021 |  | March 25,2022 |  | March 26,2021 |
| Net income attributable to shareholders | $ | 50,661 |  |  | $ | 37,493 |  |  | $ | 144,191 |  |  | $ | 105,928 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) | 36,940 |  |  | 36,875 |  |  | 36,945 |  |  | 36,876 |  |
| Incremental shares arising from the assumed vesting of restricted share units and performance share units (thousands of shares) | 533 |  |  | 734 |  |  | 506 |  |  | 638 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) | 37,473 |  |  | 37,609 |  |  | 37,451 |  |  | 37,514 |  |
| Basic earnings per ordinary share | $ | 1.37 |  |  | $ | 1.02 |  |  | $ | 3.90 |  |  | $ | 2.87 |  |
| Diluted earnings per ordinary share | $ | 1.35 |  |  | $ | 1.00 |  |  | $ | 3.85 |  |  | $ | 2.82 |  |
| Outstanding performance share units excluded from the computation of diluted earnings per ordinary share (thousands of shares)(1) | — |  |  | 76 |  |  | — |  |  | 76 |  |

[0001408710-22-000028:notes:31]
[same as prior period, unchanged from 0001408710-22-000018:notes:31]


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001408710-22-000028:notes:32]
[same as prior period, unchanged from 0001408710-22-000018:notes:32]

[0001408710-22-000028:notes:33]
|  |  |  | Fair Value |
| (amount in thousands) | CarryingCost |  | UnrealizedGain/(Loss) |  | Cash andCashEquivalents |  | MarketableSecurities |  | OtherInvestments |
| As of March 25, 2022 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 232,796 |  |  | $ | — |  |  | $ | 232,796 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 36,349 |  |  | (5) |  |  | 36,344 |  |  | — |  |  | — |  |
| Liquidity funds | 31,382 |  |  | — |  |  | — |  |  | — |  |  | 31,382 |  |
| Corporate debt securities | 192,746 |  |  | (3,024) |  |  | — |  |  | 189,722 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 25,024 |  |  | (276) |  |  | — |  |  | 24,748 |  |  | — |  |
| Total | $ | 518,297 |  |  | $ | (3,305) |  |  | $ | 269,140 |  |  | $ | 214,470 |  |  | $ | 31,382 |  |
| As of June 25, 2021 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 222,664 |  |  | $ | — |  |  | $ | 222,664 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 80,305 |  |  | — |  |  | 80,305 |  |  | — |  |  | — |  |
| Liquidity funds | 30,000 |  |  | 1,226 |  |  | — |  |  | — |  |  | 31,226 |  |
| Certificates of deposit and time deposits | 10,500 |  |  | — |  |  | — |  |  | — |  |  | 10,500 |  |
| Corporate debt securities | 171,626 |  |  | 164 |  |  | — |  |  | 171,790 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 31,301 |  |  | 146 |  |  | — |  |  | 31,447 |  |  | — |  |
| Total | $ | 546,396 |  |  | $ | 1,536 |  |  | $ | 302,969 |  |  | $ | 203,237 |  |  | $ | 41,726 |  |

[0001408710-22-000028:notes:34]
[same as prior period, unchanged from 0001408710-22-000018:notes:34]

[0001408710-22-000028:notes:35]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of March 25, 2022 and June 25, 2021:

[0001408710-22-000028:notes:36]
|  | March 25, 2022 |  | June 25, 2021 |
| (amount in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 68,455 |  |  | $ | 68,383 |  |  | $ | 30,000 |  |  | $ | 31,226 |  |
| Due between one to five years | 180,697 |  |  | 177,469 |  |  | 202,927 |  |  | 203,237 |  |
| Total | $ | 249,152 |  |  | $ | 245,852 |  |  | $ | 232,927 |  |  | $ | 234,463 |  |

[0001408710-22-000028:notes:37]
As of March 25, 2022, the Company considered the decline in market value of its available-for-sale debt securities by using the AFS debt security impairment model. The Company typically invests in highly-rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy requires investments generally to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. The Company assesses impairment at the individual security level according to applicable accounting standards by comparing fair value/market value with amortized cost. The Company considered factors such as the failure of the issuer of the security to make scheduled interest and principal payments and any changes to the credit rating of the security by a rating agency. The credit ratings of the Company's invested securities are still in compliance with the Company's investment policy. No impairment losses on available-for-sale debt securities were recorded for the three months ended March 25, 2022.

[0001408710-22-000028:notes:38]
The following table summarizes the carrying cost of short-term investments classified as held-to-maturity securities based on stated effective maturities as of March 25, 2022 and June 25, 2021:

[0001408710-22-000028:notes:39]
| (amount in thousands) | As of March 25, 2022 |  | As of June 25, 2021 |
| Due within one year | $ | — |  | (1) | $ | 10,500 |  |
| Due between one to five years | — |  |  | — |  |
| Total | $ | — |  |  | $ | 10,500 |  |

[0001408710-22-000028:notes:40]
[same as prior period, unchanged from 0001408710-22-000018:notes:40]


## us-gaap:FairValueDisclosuresTextBlock

[0001408710-22-000028:notes:41]
[same as prior period, unchanged from 0001408710-22-000018:notes:41]

[0001408710-22-000028:notes:42]
[same as prior period, unchanged from 0001408710-22-000018:notes:42]

[0001408710-22-000028:notes:43]
[same as prior period, unchanged from 0001408710-22-000018:notes:43]

[0001408710-22-000028:notes:44]
[same as prior period, unchanged from 0001408710-22-000018:notes:44]

[0001408710-22-000028:notes:45]
[same as prior period, unchanged from 0001408710-22-000018:notes:45]

[0001408710-22-000028:notes:46]
[same as prior period, unchanged from 0001408710-22-000018:notes:46]

[0001408710-22-000028:notes:47]
|  | Fair Value Measurements at Reporting Date Using |
| (amount in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of March 25, 2022 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 36,344 |  |  |  | $ | — |  |  | $ | 36,344 |  |
| Liquidity funds | — |  |  | 31,382 |  |  |  | — |  |  | 31,382 |  |
| Corporate debt securities | — |  |  | 189,722 |  |  |  | — |  |  | 189,722 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 24,748 |  |  |  | — |  |  | 24,748 |  |
| Derivative assets – current portion | — |  |  | 182 |  | (1) |  | — |  |  | 182 |  |
| Total | $ | — |  |  | $ | 282,378 |  |  |  | $ | — |  |  | $ | 282,378 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | (2,834) |  |  |  | $ | — |  |  | $ | (2,834) |  |
| Derivative liabilities – non-current portion | — |  |  | (524) |  |  |  | — |  |  | (524) |  |
| Total | $ | — |  |  | $ | (3,358) |  | (2) |  | $ | — |  |  | $ | (3,358) |  |

[0001408710-22-000028:notes:48]
|  | Fair Value Measurements at Reporting Date Using |
| (amount in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of June 25, 2021 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 80,305 |  |  |  | $ | — |  |  | $ | 80,305 |  |
| Liquidity funds | — |  |  | 31,226 |  |  |  | — |  |  | 31,226 |  |
| Corporate debt securities | — |  |  | 171,790 |  |  |  | — |  |  | 171,790 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 31,447 |  |  |  | — |  |  | 31,447 |  |
| Derivative assets – current portion | — |  |  | 1 |  | (3) |  | — |  |  | 1 |  |
| Total | $ | — |  |  | $ | 314,769 |  |  |  | $ | — |  |  | $ | 314,769 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | (5,654) |  |  |  | $ | — |  |  | $ | (5,654) |  |
| Derivative liabilities – non-current portion | — |  |  | (1,977) |  |  |  | — |  |  | (1,977) |  |
| Total | $ | — |  |  | $ | (7,631) |  | (4) |  | $ | — |  |  | $ | (7,631) |  |

[0001408710-22-000028:notes:49]
(1)Foreign currency forward contracts with a notional amount of $32.0 million and of 0.8 million Canadian dollars.

[0001408710-22-000028:notes:50]
(2)Foreign currency forward contracts with a notional amount of $103.0 million  and two interest rate swap agreements with an aggregate notional amount of $125.1 million.

[0001408710-22-000028:notes:51]
[same as prior period, unchanged from 0001408710-22-000018:notes:51]

[0001408710-22-000028:notes:52]
[same as prior period, unchanged from 0001408710-22-000018:notes:52]

[0001408710-22-000028:notes:53]
[same as prior period, unchanged from 0001408710-22-000018:notes:53]

[0001408710-22-000028:notes:54]
[same as prior period, unchanged from 0001408710-22-000018:notes:54]

[0001408710-22-000028:notes:55]
[same as prior period, unchanged from 0001408710-22-000018:notes:55]

[0001408710-22-000028:notes:56]
[same as prior period, unchanged from 0001408710-22-000018:notes:56]

[0001408710-22-000028:notes:57]
[same as prior period, unchanged from 0001408710-22-000018:notes:57]

[0001408710-22-000028:notes:58]
[same as prior period, unchanged from 0001408710-22-000018:notes:58]

[0001408710-22-000028:notes:59]
[same as prior period, unchanged from 0001408710-22-000018:notes:59]

[0001408710-22-000028:notes:60]
[same as prior period, unchanged from 0001408710-22-000018:notes:60]

[0001408710-22-000028:notes:61]
As of March 25, 2022, the Company had 135 outstanding U.S. dollar foreign currency forward contracts against Thai baht, with an aggregate notional amount of $135.0 million and maturity dates ranging from April 2022 through October 2022 and one outstanding Canadian dollar foreign currency forward contract with an aggregate notional amount of 0.8 million Canadian dollars and a maturity date in June 2022.

[0001408710-22-000028:notes:62]
[same as prior period, unchanged from 0001408710-22-000018:notes:62]

[0001408710-22-000028:notes:63]
As of March 25, 2022, the hedging relationship over foreign currency forward contracts that were designated for hedge accounting was determined to be highly effective based on the performance of retrospective and prospective regression testing. As of March 25, 2022, the amount in accumulated other comprehensive income (“AOCI”) that is expected to be reclassified into earnings within 12 months was a loss of $1.1 million.

[0001408710-22-000028:notes:64]
As of June 25, 2021, the hedging relationship over foreign currency forward contracts that were designated for hedge accounting was determined to be highly effective based on the performance of retrospective and prospective regression testing. As of June 25, 2021, the amount in AOCI that is expected to be reclassified into earnings within 12 months was a loss of $2.7 million.

[0001408710-22-000028:notes:65]
During the three and nine months ended March 25, 2022, the Company recorded an unrealized gain of $0.1 million and $0.6 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting, in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-22-000028:notes:66]
During the three and nine months ended March 26, 2021, the Company recorded an unrealized loss of $2.0 million and $1.7 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting, in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-22-000028:notes:67]
[same as prior period, unchanged from 0001408710-22-000018:notes:67]

[0001408710-22-000028:notes:68]
The Company entered into interest rate swap agreements to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. As of March 25, 2022 and June 25, 2021, the Company had two outstanding interest rate swap agreements with an aggregate notional amount of $125.1 million.

[0001408710-22-000028:notes:69]
On July 25, 2018, Fabrinet Thailand entered into an interest rate swap agreement to effectively convert the floating interest rate of its term loan under a credit facility agreement with Bank of America to a fixed interest rate of 2.86% per annum through the scheduled maturity of the term loan in June 2023 (see Note 10). The Company did not designate this interest rate swap for hedge accounting.

[0001408710-22-000028:notes:70]
On September 3, 2019, the Company entered into a new term loan agreement under a credit facility agreement with the Bank of Ayudhya Public Company Limited (the “Bank”) (see Note 10) and on September 10, 2019, the Company repaid in full the outstanding term loan under the Bank of America credit facility agreement (see Note 10). In conjunction with the funding of the new term loan, the Company entered into a second interest rate swap agreement. The combination of both of these interest rate swaps effectively converts the floating interest rate of the Company’s new term loan with the Bank to a fixed interest rate of 4.36% per annum through the maturity of the term loan in June 2024.

[0001408710-22-000028:notes:71]
On September 27, 2019, the Company designated these two interest rate swaps as a cash flow hedge for the Company’s term loan under the credit facility agreement with the Bank. The combination of these two interest rate swaps qualified for hedge accounting because the hedges are highly effective, and the Company has designated and documented contemporaneously the hedging relationships involving these interest rate swaps. While the Company intends to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in earnings. From September 27, 2019, any gains or losses related to these interest rate swaps will be recorded in AOCI in the unaudited condensed consolidated balance sheets. The Company will reclassify a portion of the gains or losses from AOCI into earnings at each reporting period based on either the accrued interest amount or the interest payment.

[0001408710-22-000028:notes:72]
As of March 25, 2022, the amount in AOCI that is expected to be reclassified into earnings within 12 months was a loss of $0.7 million.

[0001408710-22-000028:notes:73]
[same as prior period, unchanged from 0001408710-22-000018:notes:73]

[0001408710-22-000028:notes:74]
[same as prior period, unchanged from 0001408710-22-000018:notes:74]

[0001408710-22-000028:notes:75]
|  |  |  | Three Months Ended |  | Nine Months Ended |
| (amount in thousands) | Financialstatementsline item |  | March 25,2022 |  | March 26,2021 |  | March 25,2022 |  | March 26,2021 |
| Derivatives gain (loss)recognized in othercomprehensive income (loss): |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Othercomprehensiveincome |  | $ | 1,009 |  |  | $ | (6,098) |  |  | $ | 2,558 |  |  | $ | (5,289) |  |
| Interest rate swaps | Othercomprehensiveincome |  | 882 |  |  | 453 |  |  | 1,885 |  |  | 1,196 |  |
| Total derivatives gain (loss) recognized in other comprehensive income (loss) |  |  | $ | 1,891 |  |  | $ | (5,645) |  |  | $ | 4,443 |  |  | $ | (4,093) |  |
| Derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings: |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Cost of revenues |  | $ | 1,117 |  |  | $ | (1,470) |  |  | $ | 6,216 |  |  | $ | (3,190) |  |
| Foreign currency forward contracts | SG&A |  | 46 |  |  | (62) |  |  | 258 |  |  | (135) |  |
| Foreign currency forward contracts | Foreign exchange loss, net |  | (2,165) |  |  | 2,491 |  |  | (7,438) |  |  | 2,604 |  |
| Interest rate swaps | Interest expense |  | (223) |  |  | (314) |  |  | (736) |  |  | (1,009) |  |
| Total derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings |  |  | $ | (1,225) |  |  | $ | 645 |  |  | $ | (1,700) |  |  | $ | (1,730) |  |
| Change in net unrealized gain (loss) on derivatives instruments |  |  | $ | 666 |  |  | $ | (5,000) |  |  | $ | 2,743 |  |  | $ | (5,823) |  |

[0001408710-22-000028:notes:76]
[same as prior period, unchanged from 0001408710-22-000018:notes:76]

[0001408710-22-000028:notes:77]
[same as prior period, unchanged from 0001408710-22-000018:notes:77]

[0001408710-22-000028:notes:78]
|  | March 25,2022 |  | June 25,2021 |
| (amount in thousands) | DerivativeAssets |  | DerivativeLiabilities |  | DerivativeAssets |  | DerivativeLiabilities |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts | $ | 19 |  |  | $ | (405) |  |  | $ | — |  |  | $ | (1,379) |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward contracts | 163 |  |  | (1,289) |  |  | 1 |  |  | (2,703) |  |
| Interest rate swaps | — |  |  | (1,664) |  |  | — |  |  | (3,549) |  |
| Derivatives, gross balances | $ | 182 |  |  | $ | (3,358) |  |  | $ | 1 |  |  | $ | (7,631) |  |

[0001408710-22-000028:notes:79]
[same as prior period, unchanged from 0001408710-22-000018:notes:79]

[0001408710-22-000028:notes:80]
[same as prior period, unchanged from 0001408710-22-000018:notes:80]


## us-gaap:InventoryDisclosureTextBlock

[0001408710-22-000028:notes:81]
[same as prior period, unchanged from 0001408710-22-000018:notes:81]

[0001408710-22-000028:notes:82]
| (amount in thousands) | As of March 25,2022 |  | As of June 25,2021 |
| Raw materials | $ | 181,160 |  |  | $ | 196,345 |  |
| Work in progress | 205,512 |  |  | 174,654 |  |
| Finished goods | 16,969 |  |  | 15,471 |  |
| Goods in transit | 48,997 |  |  | 35,663 |  |
| Total inventories | $ | 452,638 |  |  | $ | 422,133 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001408710-22-000028:notes:83]
Leases
The Company leases facilities under non-cancelable operating lease agreements. The Company leases a portion of its capital equipment and vehicles, certain land and buildings for its facilities in Thailand, the Cayman Islands, the PRC, the U.S., the U.K., Israel and Singapore under operating lease arrangements that expire at various dates through 2025. Certain of these lease arrangements provide the Company the ability to extend the lease from one to five years following the expiration of the current term. However, the Company has excluded all lease extension options from its right of use (“ROU”) assets and lease liabilities as the Company is not reasonably assured that it will exercise these options. None of the lease agreements contain residual value guarantees provided by the lessee. The Company also has one intercompany lease of office and manufacturing space.

[0001408710-22-000028:notes:84]
[same as prior period, unchanged from 0001408710-22-000018:notes:84]

[0001408710-22-000028:notes:85]
As of March 25, 2022, the maturities of the Company’s operating lease liabilities were as follows:

[0001408710-22-000028:notes:86]
| (amount in thousands) |  |  |
| 2022 (remaining three months) | $ | 687 |  |  |
| 2023 | 2,675 |  |  |
| 2024 | 1,258 |  |  |
| 2025 | 41 |  |  |
| Total undiscounted lease payments | 4,661 |  |  |
| Less imputed interest | (146) |  |  |
| Total present value of lease liabilities | $ | 4,515 |  | (1) |

[0001408710-22-000028:notes:87]
[same as prior period, unchanged from 0001408710-22-000018:notes:87]

[0001408710-22-000028:notes:88]
Rental expense related to the Company’s operating leases is recognized on a straight-line basis over the lease term. Rental expense for long-term leases for the three and nine months ended March 25, 2022 was $0.7 million and $2.1 million, respectively, and for the three and nine months ended March 26, 2021 was $0.7 million and $1.9 million, respectively. Rental expense for short-term leases for the three and nine months ended March 25, 2022 was $0.1 million and $0.2 million, respectively, and for the three and nine months ended March 26, 2021 was $0.1 million and $0.3 million, respectively.

[0001408710-22-000028:notes:89]
[same as prior period, unchanged from 0001408710-22-000018:notes:89]

[0001408710-22-000028:notes:90]
|  | As ofMarch 25, 2022 |  | As ofJune 25, 2021 |
| Weighted-average remaining lease term (in years) | 2.0 |  | 2.7 |
| Weighted-average discount rate | 3.5 | % |  | 3.5 | % |

[0001408710-22-000028:notes:91]
The following table presents supplemental disclosure for the unaudited condensed consolidated statement of cash flows related to operating and finance leases for the three and nine months ended March 25, 2022 and March 26, 2021:

[0001408710-22-000028:notes:92]
|  | Three Months Ended |  | Nine Months Ended |
| (amount in thousands) | March 25,2022 |  | March 26,2021 |  | March 25,2022 |  | March 26,2021 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |
| Operating cash flows from operating leases | $ | 678 |  |  | $ | 628 |  |  | $ | 2,076 |  |  | $ | 1,889 |  |
| Financing cash flows from finance leases | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 100 |  |
| ROU assets obtained in exchange for lease liabilities | $ | — |  |  | $ | 76 |  |  | $ | 38 |  |  | $ | 443 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001408710-22-000028:notes:93]
[same as prior period, unchanged from 0001408710-22-000018:notes:93]

[0001408710-22-000028:notes:94]
| (amount in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  | ForeignCurrencyTranslationAdjustment |  | Net |
| As of March 25, 2022 |  |  |  |  |  |  |  |
| Software | $ | 10,157 |  |  | $ | (7,417) |  |  | $ | — |  |  | $ | 2,740 |  |
| Customer relationships | 4,373 |  |  | (3,515) |  |  | (5) |  |  | 853 |  |
| Backlog | 119 |  |  | (119) |  |  | — |  |  | — |  |
| Total intangibles | $ | 14,649 |  |  | $ | (11,051) |  |  | $ | (5) |  |  | $ | 3,593 |  |

[0001408710-22-000028:notes:95]
[same as prior period, unchanged from 0001408710-22-000018:notes:95]

[0001408710-22-000028:notes:96]
The Company recorded amortization expense relating to intangibles of $0.4 million and $0.5 million for the three months ended March 25, 2022 and March 26, 2021, respectively, and $1.2 million for the nine months ended March 25, 2022 and March 26, 2021.

[0001408710-22-000028:notes:97]
[same as prior period, unchanged from 0001408710-22-000018:notes:97]

[0001408710-22-000028:notes:98]
| (years) | As ofMarch 25, 2022 |  | As ofJune 25, 2021 |
| Customer relationships | 3.3 |  | 3.9 |

[0001408710-22-000028:notes:99]
Based on the carrying amount of intangibles as of March 25, 2022, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001408710-22-000028:notes:100]
| (amount in thousands) |  |
| 2022 (remaining three months) | $ | 509 |  |
| 2023 | 1,232 |  |
| 2024 | 999 |  |
| 2025 | 517 |  |
| 2026 | 325 |  |
| Thereafter | 11 |  |
| Total | $ | 3,593 |  |


## us-gaap:DebtDisclosureTextBlock

[0001408710-22-000028:notes:101]
Borrowings 
The Company’s total borrowings, including current and non-current portions of long-term borrowings, consisted of the following:

[0001408710-22-000028:notes:102]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofMarch 25, 2022 |  | As ofJune 25, 2021 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 30,468 |  |  | $ | 39,609 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs, non-current portion |  |  |  |  | (39) |  |  | (63) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 18,241 |  |  | $ | 27,358 |  |

[0001408710-22-000028:notes:103]
(1)We have entered into interest rate swaps that effectively fix a series of our future interest payments on our term loans. Refer to Note 6.

[0001408710-22-000028:notes:104]
The movements of long-term borrowings for the nine months ended March 25, 2022 and March 26, 2021 were as follows:

[0001408710-22-000028:notes:105]
|  | Nine Months Ended |
| (amount in thousands) | March 25,2022 |  | March 26,2021 |
| Opening balance | $ | 39,609 |  |  | $ | 51,797 |  |
| Borrowings during the period | — |  |  | — |  |
| Repayments during the period | (9,141) |  |  | (9,141) |  |
| Closing balance | $ | 30,468 |  |  | $ | 42,656 |  |

[0001408710-22-000028:notes:106]
As of March 25, 2022, future maturities of long-term borrowings during each fiscal year were as follows:

[0001408710-22-000028:notes:107]
| (amount in thousands) |  |
| 2022 (remaining three months) | $ | 3,047 |  |
| 2023 | 15,233 |  |
| 2024 | 9,141 |  |
| 2025 | 3,047 |  |
| Total | $ | 30,468 |  |

[0001408710-22-000028:notes:108]
Credit facility agreements:

[0001408710-22-000028:notes:109]
Bank of Ayudhya Public Company Limited

[0001408710-22-000028:notes:110]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a credit facility agreement (the “Credit Facility Agreement”), which provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million that may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

[0001408710-22-000028:notes:111]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a term loan agreement (the "Term Loan Agreement") pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company’s previous syndicated senior credit facility agreement.

[0001408710-22-000028:notes:112]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three and nine months ended March 25, 2022, the Company recorded $0.6 million and $1.7 million, respectively, of interest expense in connection with this term loan, including impact from interest rate swaps. $0.3 million and $0.6 million of these interest expenses were capitalized during the three and nine months ended March 25, 2022, respectively, in a new manufacturing building at the Company's Chonburi campus.

[0001408710-22-000028:notes:113]
Any borrowings under the Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

[0001408710-22-000028:notes:114]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of March 25, 2022, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

[0001408710-22-000028:notes:115]
The events of default under the Term Loan Agreement include failure to timely pay amounts due under the Term Loan Agreement or the related finance documents, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

[0001408710-22-000028:notes:116]
As of March 25, 2022, there was $30.5 million outstanding under the term loan.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001408710-22-000028:notes:117]
Income taxes
As of March 25, 2022 and June 25, 2021, the liability for uncertain tax positions including accrued interest and penalties was $1.5 million and $0.9 million, respectively. The Company expects the estimated amount of liability associated with its uncertain tax positions to increase within the next 12 months due to additional provisions on uncertain tax positions from one of its subsidiaries and interest on these positions.

[0001408710-22-000028:notes:118]
[same as prior period, unchanged from 0001408710-22-000018:notes:118]

[0001408710-22-000028:notes:119]
The effective tax rate for the Company for the three months ended March 25, 2022 and March 26, 2021 was 5.4% and 4.1%, respectively, of net income. The increase was primarily due to the fact that the Company had more income subject to tax during the third quarter of fiscal year 2022 as compared to the same period in fiscal year 2021.

[0001408710-22-000028:notes:120]
The effective tax rate for the Company for the nine months ended March 25, 2022 and March 26, 2021 was 3.2% and 3.8%, respectively, of net income. The decrease was primarily due to the fact that the Company had less income subject to tax during the first nine months of fiscal year 2022 as compared to the same period in fiscal year 2021.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001408710-22-000028:notes:121]
[same as prior period, unchanged from 0001408710-22-000018:notes:121]

[0001408710-22-000028:notes:122]
[same as prior period, unchanged from 0001408710-22-000018:notes:122]

[0001408710-22-000028:notes:123]
The effect of recording share-based compensation expense for the three and nine months ended March 25, 2022 and March 26, 2021 was as follows:

[0001408710-22-000028:notes:124]
|  | Three Months Ended |  | Nine Months Ended |
| (amount in thousands) | March 25,2022 |  | March 26,2021 |  | March 25,2022 |  | March 26,2021 |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |
| Restricted share units | $ | 3,126 |  |  | $ | 3,953 |  |  | $ | 11,720 |  |  | $ | 13,377 |  |
| Performance share units | 2,597 |  |  | 2,911 |  |  | 9,981 |  |  | 5,365 |  |
| Total share-based compensation expense | 5,723 |  |  | 6,864 |  |  | 21,701 |  |  | 18,742 |  |
| Tax effect on share-based compensation expense | — |  |  | — |  |  | — |  |  | — |  |
| Net effect on share-based compensation expense | $ | 5,723 |  |  | $ | 6,864 |  |  | $ | 21,701 |  |  | $ | 18,742 |  |

[0001408710-22-000028:notes:125]
[same as prior period, unchanged from 0001408710-22-000018:notes:125]

[0001408710-22-000028:notes:126]
|  | Three Months Ended |  | Nine Months Ended |
| (amount in thousands) | March 25,2022 |  | March 26,2021 |  | March 25,2022 |  | March 26,2021 |
| Cost of revenue | $ | 1,183 |  |  | $ | 1,388 |  |  | $ | 4,579 |  |  | $ | 4,805 |  |
| Selling, general and administrative expense | 4,540 |  |  | 5,476 |  |  | 17,122 |  |  | 13,937 |  |
| Total share-based compensation expense | $ | 5,723 |  |  | $ | 6,864 |  |  | $ | 21,701 |  |  | $ | 18,742 |  |

[0001408710-22-000028:notes:127]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the three and nine months ended March 25, 2022 and March 26, 2021.

[0001408710-22-000028:notes:128]
[same as prior period, unchanged from 0001408710-22-000018:notes:128]

[0001408710-22-000028:notes:129]
[same as prior period, unchanged from 0001408710-22-000018:notes:129]

[0001408710-22-000028:notes:130]
As of March 25, 2022, there were 299,009 restricted share units outstanding, 285,882 performance share units outstanding and 2,231,558 ordinary shares available for future grant under the 2020 Plan.

[0001408710-22-000028:notes:131]
As of March 25, 2022, there were 149,755 restricted share units outstanding under the 2010 Plan. No ordinary shares are available for future grant under the 2010 Plan.

[0001408710-22-000028:notes:132]
On November 2, 2017, the Company adopted the 2017 Inducement Equity Incentive Plan (the “2017 Inducement Plan”) with a reserve of 160,000 ordinary shares authorized for future issuance solely for the granting of inducement share options and equity awards to new employees. The 2017 Inducement Plan was adopted without shareholder approval in reliance on the “employment inducement exemption” provided under the New York Stock Exchange Listed Company Manual. As of March 25, 2022, there were 12,164 restricted share units outstanding and 111,347 ordinary shares available for future grant under the 2017 Inducement Plan.

[0001408710-22-000028:notes:133]
[same as prior period, unchanged from 0001408710-22-000018:notes:133]

[0001408710-22-000028:notes:134]
[same as prior period, unchanged from 0001408710-22-000018:notes:134]

[0001408710-22-000028:notes:135]
[same as prior period, unchanged from 0001408710-22-000018:notes:135]

[0001408710-22-000028:notes:136]
[same as prior period, unchanged from 0001408710-22-000018:notes:136]

[0001408710-22-000028:notes:137]
[same as prior period, unchanged from 0001408710-22-000018:notes:137]

[0001408710-22-000028:notes:138]
[same as prior period, unchanged from 0001408710-22-000018:notes:138]

[0001408710-22-000028:notes:139]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 25, 2021 | 641,875 |  |  | $ | 55.74 |  |
| Granted | 165,684 |  |  | $ | 102.74 |  |
| Issued | (310,473) |  |  | $ | 52.12 |  |
| Forfeited | (36,158) |  |  | $ | 69.84 |  |
| Balance as of March 25, 2022 | 460,928 |  |  | $ | 73.96 |  |

[0001408710-22-000028:notes:140]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 26, 2020 | 797,757 |  |  | $ | 46.88 |  |
| Granted | 222,886 |  |  | $ | 69.97 |  |
| Issued | (347,662) |  |  | $ | 45.18 |  |
| Forfeited | (23,432) |  |  | $ | 57.71 |  |
| Balance as of March 26, 2021 | 649,549 |  |  | $ | 55.33 |  |

[0001408710-22-000028:notes:141]
[same as prior period, unchanged from 0001408710-22-000018:notes:141]

[0001408710-22-000028:notes:142]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 25, 2021 | 427,028 |  |  | $ | 57.82 |  |
| Granted | 110,832 |  |  | $ | 101.05 |  |
| Issued | (190,213) |  |  | $ | 48.65 |  |
| Forfeited | (61,765) |  |  | $ | 53.38 |  |
| Balance as of March 25, 2022 | 285,882 |  |  | $ | 81.64 |  |

[0001408710-22-000028:notes:143]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 26, 2020 | 440,140 |  |  | $ | 48.37 |  |
| Granted | 184,718 |  |  | $ | 69.85 |  |
| Issued | (82,185) |  |  | 48.02 |  |
| Forfeited | (115,645) |  |  | $ | 48.02 |  |
| Balance as of March 26, 2021 | 427,028 |  |  | $ | 57.82 |  |

[0001408710-22-000028:notes:144]
[same as prior period, unchanged from 0001408710-22-000018:notes:144]

[0001408710-22-000028:notes:145]
As of March 25, 2022, there was $13.6 million and $9.3 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.4 and 1.1 years, respectively.

[0001408710-22-000028:notes:146]
For the nine months ended March 25, 2022 and March 26, 2021, the Company withheld an aggregate of 210,006 shares and 160,648 shares, respectively, upon the vesting of restricted share units, based upon the closing share price on the vesting date to settle employee tax withholding obligations. For the nine months ended March 25, 2022 and March 26, 2021, the Company then remitted cash of $20.4 million and $11.4 million, respectively, to the appropriate taxing authorities and presented it as a financing activity within the unaudited condensed consolidated statements of cash flows. The payment was recorded as a reduction of additional paid-in capital.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001408710-22-000028:notes:147]
[same as prior period, unchanged from 0001408710-22-000018:notes:147]

[0001408710-22-000028:notes:148]
[same as prior period, unchanged from 0001408710-22-000018:notes:148]

[0001408710-22-000028:notes:149]
For the three and nine months ended March 25, 2022, Fabrinet issued 30,729 and 290,680 ordinary shares, respectively, upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-22-000028:notes:150]
For the three and nine months ended March 26, 2021, Fabrinet issued 43,098 and 269,199 ordinary shares, respectively, upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-22-000028:notes:151]
[same as prior period, unchanged from 0001408710-22-000018:notes:151]

[0001408710-22-000028:notes:152]
[same as prior period, unchanged from 0001408710-22-000018:notes:152]

[0001408710-22-000028:notes:153]
In August 2017, the Company’s board of directors approved a share repurchase program to permit the Company to repurchase up to $30.0 million worth of its issued and outstanding ordinary shares in the open market in accordance with applicable rules and regulations. In February 2018, May 2019 and August 2020, the Company’s board of directors approved an increase of $30.0 million, $50.0 million and $58.5 million, respectively, to the original share repurchase authorization, bringing the aggregate authorization to $168.5 million. During the three and nine months ended March 25, 2022, the Company repurchased 237,339 and 275,608 shares, respectively, under the program at an average price per share (excluding other direct costs) of $101.90 and $103.84, respectively, totaling $24.2 million and $28.6 million, respectively. As of March 25, 2022, the Company had a remaining authorization to repurchase up to $52.5 million worth of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001408710-22-000028:notes:154]
Accumulated other comprehensive income (loss)
The changes in AOCI for the nine months ended March 25, 2022 and March 26, 2021 were as follows:

[0001408710-22-000028:notes:155]
| (amount in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 25, 2021 | $ | 308 |  |  | $ | (4,504) |  |  | $ | (1,425) |  |  | $ | (645) |  |  | $ | (6,266) |  |
| Other comprehensive income before reclassification adjustment | (3,602) |  |  | 4,443 |  |  | — |  |  | (198) |  |  | 643 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | (13) |  |  | (1,700) |  |  | 448 |  |  | — |  |  | (1,265) |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | $ | (3,615) |  |  | $ | 2,743 |  |  | $ | 448 |  |  | $ | (198) |  |  | $ | (622) |  |
| Balance as of March 25, 2022 | $ | (3,307) |  |  | $ | (1,761) |  |  | $ | (977) |  |  | $ | (843) |  |  | $ | (6,888) |  |

[0001408710-22-000028:notes:156]
| (amount in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 26, 2020 | $ | 1,490 |  |  | $ | 602 |  |  | $ | (2,009) |  |  | $ | (1,230) |  |  | $ | (1,147) |  |
| Other comprehensive income before reclassification adjustment | (758) |  |  | (4,093) |  |  | — |  |  | 547 |  |  | (4,304) |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | (179) |  |  | (1,730) |  |  | 421 |  |  | — |  |  | (1,488) |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | $ | (937) |  |  | $ | (5,823) |  |  | $ | 421 |  |  | $ | 547 |  |  | $ | (5,792) |  |
| Balance as of March 26, 2021 | $ | 553 |  |  | $ | (5,221) |  |  | $ | (1,588) |  |  | $ | (683) |  |  | $ | (6,939) |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001408710-22-000028:notes:157]
Commitments and contingencies
Bank guarantees

[0001408710-22-000028:notes:158]
As of March 25, 2022 and June 25, 2021, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling to $1.5 million and $1.6 million, respectively, or Thai Baht 50.2 million. As of March 25, 2022 and June 25, 2021, the Company had an outstanding bank guarantee on behalf of its subsidiary in the PRC to support the subsidiary's operations totaling Renminbi 1.0 million, which bank guarantee was backed by cash collateral of $0.2 million. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in the U.K. to support its operations.

[0001408710-22-000028:notes:159]
Purchase obligations

[0001408710-22-000028:notes:160]
Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001408710-22-000028:notes:161]
As of March 25, 2022, the Company had a purchase obligation and other commitments to third parties of $1,414.6 million.

[0001408710-22-000028:notes:162]
Capital expenditures

[0001408710-22-000028:notes:163]
As of March 25, 2022, the Company had total capital expenditure commitments to third parties of $17.7 million.

[0001408710-22-000028:notes:164]
Indemnification of directors and officers

[0001408710-22-000028:notes:165]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001408710-22-000028:notes:166]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001408710-22-000028:notes:167]
Business segments and geographic information
Operating segments are defined as components of an enterprise for which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. The Company’s chief operating decision maker is Fabrinet’s Chief Executive Officer. As of March 25, 2022, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001408710-22-000028:notes:168]
[same as prior period, unchanged from 0001408710-22-000018:notes:170]

[0001408710-22-000028:notes:169]
[same as prior period, unchanged from 0001408710-22-000018:notes:171]

[0001408710-22-000028:notes:170]
| (amount in thousands) |  | March 25,2022 |  | June 25,2021 |
| Long-Lived Assets: |  |  |  |  |
| Thailand |  | $ | 240,728 |  |  | $ | 190,843 |  |
| U.S. |  | 26,180 |  |  | 27,403 |  |
| China |  | 18,444 |  |  | 14,977 |  |
| Israel |  | 4,338 |  |  | 5,271 |  |
| U.K. |  | 1,463 |  |  | 2,223 |  |
| Cayman Island |  | 614 |  |  | 412 |  |
|  |  | $ | 291,767 |  |  | $ | 241,129 |  |

[0001408710-22-000028:notes:171]
[same as prior period, unchanged from 0001408710-22-000018:notes:173]

[0001408710-22-000028:notes:172]
The Company had two and three customers that each contributed to 10% or more of the Company's total trade accounts receivable as of March 25, 2022 and June 25, 2021, respectively.
