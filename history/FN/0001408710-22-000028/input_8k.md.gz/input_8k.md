# FN 8-K — 0001408710-22-000026 filed 2022-05-02

## item codes, every 8-K on or before 2022-05-03

- 2022-05-02 0001408710-22-000026 — 2.02, 9.01
- 2022-01-31 0001408710-22-000016 — 2.02, 9.01
- 2022-01-19 0001408710-22-000010 — 5.02
- 2022-01-06 0001408710-22-000006 — 5.02
- 2021-12-10 0001408710-21-000051 — 5.07
- 2021-11-01 0001408710-21-000045 — 2.02, 9.01
- 2021-08-16 0001408710-21-000031 — 2.02, 5.02, 9.01
- 2021-05-03 0001408710-21-000019 — 2.02, 9.01
- 2021-02-01 0001408710-21-000008 — 2.02, 9.01
- 2020-12-11 0001193125-20-315861 — 5.07
- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2022-05-03

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001408710-22-000026:8k_2_02:1]
EX-99.1
6
fn-20220502xex991q322.htm
EX-99.1

[0001408710-22-000026:8k_2_02:2]
Document

[0001408710-22-000026:8k_2_02:3]
Exhibit 99.1

[0001408710-22-000026:8k_2_02:4]
Fabrinet Announces Third Quarter Fiscal Year 2022 Financial Results

[0001408710-22-000026:8k_2_02:5]
•Solid Third Quarter Revenue of $564.4 Million

[0001408710-22-000026:8k_2_02:6]
•Record GAAP and Non-GAAP Net Income per Share

[0001408710-22-000026:8k_2_02:7]
BANGKOK, Thailand – May 2, 2022 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its third fiscal quarter ended March 25, 2022.

[0001408710-22-000026:8k_2_02:8]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “With strong execution we delivered solid revenue and non-GAAP EPS that were within our guidance ranges in the third quarter. We are optimistic that we can continue to effectively manage supply chain constraints amid growing demand to deliver strong fourth quarter results.”

[0001408710-22-000026:8k_2_02:9]
Third Quarter Fiscal Year 2022 Financial Highlights

[0001408710-22-000026:8k_2_02:10]
GAAP Results

[0001408710-22-000026:8k_2_02:11]
•Revenue for the third quarter of fiscal year 2022 was $564.4 million, compared to $479.3 million in the third quarter of fiscal year 2021.

[0001408710-22-000026:8k_2_02:12]
•GAAP net income for the third quarter of fiscal year 2022 was $50.7 million, compared to GAAP net income of $37.5 million for the third quarter of fiscal year 2021.

[0001408710-22-000026:8k_2_02:13]
•GAAP net income per diluted share for the third quarter of fiscal year 2022 was $1.35, compared to GAAP net income per diluted share of $1.00 for the third quarter of fiscal year 2021.

[0001408710-22-000026:8k_2_02:14]
Non-GAAP Results

[0001408710-22-000026:8k_2_02:15]
•Non-GAAP net income for the third quarter of fiscal year 2022 was $56.2 million, compared to non-GAAP net income of $45.4 million for the third quarter of fiscal year 2021.

[0001408710-22-000026:8k_2_02:16]
•Non-GAAP net income per diluted share for the third quarter of fiscal year 2022 was $1.50, compared to non-GAAP net income per diluted share of $1.21 for the third quarter of fiscal year 2021.

[0001408710-22-000026:8k_2_02:17]
Business Outlook

[0001408710-22-000026:8k_2_02:18]
Based on information available as of May 2, 2022, Fabrinet is issuing guidance for its fourth fiscal quarter ending

[0001408710-22-000026:8k_2_02:19]
June 24, 2022, as follows:

[0001408710-22-000026:8k_2_02:20]
•Fabrinet expects fourth quarter revenue to be in the range of $570 million to $590 million.

[0001408710-22-000026:8k_2_02:21]
•GAAP net income per diluted share is expected to be in the range of $1.35 to $1.42, based on approximately 37.6 million fully diluted shares outstanding.

[0001408710-22-000026:8k_2_02:22]
•Non-GAAP net income per diluted share is expected to be in the range of $1.52 to $1.59, based on approximately 37.6 million fully diluted shares outstanding.

[0001408710-22-000026:8k_2_02:23]
Conference Call Information

[0001408710-22-000026:8k_2_02:24]
| What: |  | Fabrinet Third Quarter Fiscal Year 2022 Financial Results Call |
| When: |  | Monday, May 2, 2022 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic(253) 237-1137, internationalConference ID: 8682742 |
| Replay: |  | (855) 859-2056, domestic(404) 537-3406, internationalConference ID: 8682742 |
| Webcast: |  | http://investor.fabrinet.com/ (live and replay) |

[0001408710-22-000026:8k_2_02:25]
A recorded version of this webcast will be available approximately two hours after the call and accessible at http://investor.fabrinet.com. The webcast will be archived on Fabrinet’s website for a period of one year.

[0001408710-22-000026:8k_2_02:26]
About Fabrinet

[0001408710-22-000026:8k_2_02:27]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China, Israel and the

[0001408710-22-000026:8k_2_02:28]
United Kingdom. For more information visit: www.fabrinet.com.

[0001408710-22-000026:8k_2_02:29]
Forward-Looking Statements

[0001408710-22-000026:8k_2_02:30]
Use of Non-GAAP Financials

[0001408710-22-000026:8k_2_02:31]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; depreciation of fair value uplift; amortization of intangibles; severance payment and others; other expenses in relation to reduction in workforce; and amortization of deferred debt issuance costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001408710-22-000026:8k_2_02:32]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001408710-22-000026:8k_2_02:33]
Investor Contact:

[0001408710-22-000026:8k_2_02:34]
Garo Toomajanian

[0001408710-22-000026:8k_2_02:35]
ir@fabrinet.com

[0001408710-22-000026:8k_2_02:36]
FABRINET

[0001408710-22-000026:8k_2_02:37]
CONDENSED CONSOLIDATED BALANCE SHEETS (unaudited)

[0001408710-22-000026:8k_2_02:38]
| (in thousands of U.S. dollars, except share data and par value) | March 25,2022 |  | June 25,2021 |
| Assets |  |  |  |
| Current assets |  |  |  |
| Cash and cash equivalents | $ | 269,140 |  |  | $ | 302,969 |  |
| Short-term investments | 245,852 |  |  | 244,963 |  |
| Trade accounts receivable, net of allowance for doubtful accounts of $61 and $100, respectively | 446,052 |  |  | 336,547 |  |
| Contract assets | 13,568 |  |  | 11,878 |  |
| Inventories | 452,638 |  |  | 422,133 |  |
| Prepaid expenses | 13,729 |  |  | 11,398 |  |
| Other current assets | 29,169 |  |  | 22,619 |  |
| Total current assets | 1,470,148 |  |  | 1,352,507 |  |
| Non-current assets |  |  |  |
| Long-term restricted cash | 157 |  |  | 154 |  |
| Property, plant and equipment, net | 291,767 |  |  | 241,129 |  |
| Intangibles, net | 3,593 |  |  | 4,371 |  |
| Operating right-of-use assets | 4,790 |  |  | 6,699 |  |
| Deferred tax assets | 9,171 |  |  | 9,428 |  |
| Other non-current assets | 513 |  |  | 1,834 |  |
| Total non-current assets | 309,991 |  |  | 263,615 |  |
| Total Assets | $ | 1,780,139 |  |  | $ | 1,616,122 |  |
| Liabilities and Shareholders’ Equity |  |  |  |
| Current liabilities |  |  |  |
| Long-term borrowings, current portion, net | $ | 12,156 |  |  | $ | 12,156 |  |
| Trade accounts payable | 402,581 |  |  | 346,555 |  |
| Fixed assets payable | 14,060 |  |  | 19,206 |  |
| Contract liabilities | 1,923 |  |  | 1,680 |  |
| Operating lease liabilities, current portion | 2,593 |  |  | 2,593 |  |
| Income tax payable | 2,794 |  |  | 3,612 |  |
| Accrued payroll, bonus and related expenses | 21,396 |  |  | 20,464 |  |
| Accrued expenses | 21,144 |  |  | 17,134 |  |
| Other payables | 24,012 |  |  | 20,958 |  |
| Total current liabilities | 502,659 |  |  | 444,358 |  |
| Non-current liabilities |  |  |  |
| Long-term borrowings, non-current portion, net | 18,241 |  |  | 27,358 |  |
| Deferred tax liability | 5,771 |  |  | 5,107 |  |
| Operating lease liability, non-current portion | 1,922 |  |  | 3,850 |  |
| Severance liabilities | 20,352 |  |  | 19,485 |  |
| Other non-current liabilities | 2,467 |  |  | 3,444 |  |
| Total non-current liabilities | 48,753 |  |  | 59,244 |  |
| Total Liabilities | 551,412 |  |  | 503,602 |  |
| Commitments and contingencies |  |  |  |
| Shareholders’ equity |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of March 25, 2022 and June 25, 2021) | — |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 39,039,725 shares and 38,749,045 shares issued at March 25, 2022 and June 25, 2021, respectively; and 36,780,528 shares and 36,765,456 shares outstanding at March 25, 2022 and June 25, 2021, respectively) | 390 |  |  | 388 |  |
| Additional paid-in capital | 190,705 |  |  | 189,445 |  |
| Less: Treasury shares (2,259,197 shares and 1,983,589 shares as of March 25, 2022 and June 25, 2021, respectively) | (115,967) |  |  | (87,343) |  |
| Accumulated other comprehensive income (loss) | (6,888) |  |  | (6,266) |  |
| Retained earnings | 1,160,487 |  |  | 1,016,296 |  |
| Total Shareholders’ Equity | 1,228,727 |  |  | 1,112,520 |  |
| Total Liabilities and Shareholders’ Equity | $ | 1,780,139 |  |  | $ | 1,616,122 |  |

[0001408710-22-000026:8k_2_02:39]
FABRINET

[0001408710-22-000026:8k_2_02:40]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME (unaudited)

[0001408710-22-000026:8k_2_02:41]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands of U.S. dollars, except per share data) | March 25,2022 |  | March 26,2021 |  | March 25,2022 |  | March 26,2021 |
| Revenues | $ | 564,395 |  |  | $ | 479,317 |  |  | $ | 1,674,350 |  |  | $ | 1,369,783 |  |
| Cost of revenues | (493,702) |  |  | (422,539) |  |  | (1,470,689) |  |  | (1,209,504) |  |
| Gross profit | 70,693 |  |  | 56,778 |  |  | 203,661 |  |  | 160,279 |  |
| Selling, general and administrative expenses | (17,034) |  |  | (19,059) |  |  | (55,412) |  |  | (53,078) |  |
| Expenses related to reduction in workforce | — |  |  | (43) |  |  | (135) |  |  | (43) |  |
| Operating income | 53,659 |  |  | 37,676 |  |  | 148,114 |  |  | 107,158 |  |
| Interest income | 414 |  |  | 941 |  |  | 1,470 |  |  | 3,156 |  |
| Interest expense | (73) |  |  | (282) |  |  | (347) |  |  | (798) |  |
| Foreign exchange gain (loss), net | (410) |  |  | 629 |  |  | 998 |  |  | 224 |  |
| Other income (expense), net | (36) |  |  | 124 |  |  | (1,351) |  |  | 403 |  |
| Income before income taxes | 53,554 |  |  | 39,088 |  |  | 148,884 |  |  | 110,143 |  |
| Income tax expense | (2,893) |  |  | (1,595) |  |  | (4,693) |  |  | (4,215) |  |
| Net income | 50,661 |  |  | 37,493 |  |  | 144,191 |  |  | 105,928 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities | (2,455) |  |  | (570) |  |  | (3,615) |  |  | (937) |  |
| Change in net unrealized gain (loss) on derivative instruments | 666 |  |  | (5,000) |  |  | 2,743 |  |  | (5,823) |  |
| Change in net retirement benefits plan – prior service cost | 124 |  |  | 198 |  |  | 448 |  |  | 421 |  |
| Change in foreign currency translation adjustment | (34) |  |  | 90 |  |  | (198) |  |  | 547 |  |
| Total other comprehensive income (loss), net of tax | (1,699) |  |  | (5,282) |  |  | (622) |  |  | (5,792) |  |
| Net comprehensive income (loss) | $ | 48,962 |  |  | $ | 32,211 |  |  | $ | 143,569 |  |  | $ | 100,136 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 1.37 |  |  | $ | 1.02 |  |  | $ | 3.90 |  |  | $ | 2.87 |  |
| Diluted | $ | 1.35 |  |  | $ | 1.00 |  |  | $ | 3.85 |  |  | $ | 2.82 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |
| Basic | 36,940 |  |  | 36,875 |  |  | 36,945 |  |  | 36,876 |  |
| Diluted | 37,473 |  |  | 37,609 |  |  | 37,451 |  |  | 37,514 |  |

[0001408710-22-000026:8k_2_02:42]
FABRINET

[0001408710-22-000026:8k_2_02:43]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited)

[0001408710-22-000026:8k_2_02:44]
|  | Nine Months Ended |
| (in thousands of U.S. dollars) | March 25,2022 |  | March 26,2021 |
| Cash flows from operating activities |  |  |  |
| Net income for the period | $ | 144,191 |  |  | $ | 105,928 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 28,907 |  |  | 26,781 |  |
| Gain on disposal of property, plant and equipment | (175) |  |  | (24) |  |
| Gain from sales and maturities of available-for-sale securities | (13) |  |  | (187) |  |
| Amortization of investment discount | 3,038 |  |  | 1,479 |  |
| Amortization of deferred debt issuance costs | 24 |  |  | 24 |  |
| (Reversal of) allowance for doubtful accounts | (39) |  |  | (317) |  |
| Unrealized gain on exchange rate and fair value of foreign currency forward contracts | (1,422) |  |  | (825) |  |
| Amortization of fair value at hedge inception of interest rate swaps | (736) |  |  | (1,009) |  |
| Share-based compensation | 21,701 |  |  | 18,742 |  |
| Deferred income tax | 563 |  |  | (382) |  |
| Other non-cash expenses | 1,067 |  |  | (614) |  |
| Changes in operating assets and liabilities |  |  |  |
| Trade accounts receivable | (109,334) |  |  | (36,437) |  |
| Contract assets | (1,690) |  |  | (3,874) |  |
| Inventories | (30,503) |  |  | (43,497) |  |
| Other current assets and non-current assets | (11,221) |  |  | (18,433) |  |
| Trade accounts payable | 55,333 |  |  | 25,589 |  |
| Contract liabilities | 243 |  |  | (147) |  |
| Income tax payable | (872) |  |  | 911 |  |
| Severance liabilities | 1,883 |  |  | 2,204 |  |
| Other current liabilities and non-current liabilities | 6,952 |  |  | 3,404 |  |
| Net cash provided by operating activities | 107,897 |  |  | 79,316 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of short-term investments | (119,853) |  |  | (183,041) |  |
| Proceeds from sales of short-term investments | 19,463 |  |  | 84,049 |  |
| Proceeds from maturities of short-term investments | 92,862 |  |  | 97,721 |  |
| Purchase of property, plant and equipment | (75,327) |  |  | (33,269) |  |
| Purchase of intangibles | (592) |  |  | (1,912) |  |
| Proceeds from disposal of property, plant and equipment | 229 |  |  | 38 |  |
| Net cash used in investing activities | (83,218) |  |  | (36,414) |  |
| Cash flows from financing activities |  |  |  |
| Repayment of long-term borrowings | (9,141) |  |  | (9,141) |  |
| Repayment of finance lease liability | — |  |  | (100) |  |
| Repurchase of ordinary shares | (28,624) |  |  | (8,312) |  |
| Withholding tax related to net share settlement of restricted share units | (20,439) |  |  | (11,362) |  |
| Net cash used in financing activities | (58,204) |  |  | (28,915) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | (33,525) |  |  | $ | 13,987 |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at the beginning of period | $ | 303,123 |  |  | $ | 232,832 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | (33,525) |  |  | 13,987 |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash | (301) |  |  | 345 |  |
| Cash, cash equivalents and restricted cash at the end of period | $ | 269,297 |  |  | $ | 247,164 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment-related payables | $ | 14,060 |  |  | $ | 11,060 |  |

[0001408710-22-000026:8k_2_02:45]
FABRINET

[0001408710-22-000026:8k_2_02:46]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited) (Continued)

[0001408710-22-000026:8k_2_02:47]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the unaudited condensed consolidated balance sheets that sum to the total of the same amounts shown in the unaudited condensed consolidated statements of cash flows:

[0001408710-22-000026:8k_2_02:48]
| (amount in thousands) | As ofMarch 25, 2022 |  | As ofMarch 26, 2021 |
| Cash and cash equivalents | $ | 269,140 |  |  | $ | 247,011 |  |
| Restricted cash | 157 |  |  | 153 |  |
| Cash, cash equivalents and restricted cash | $ | 269,297 |  |  | $ | 247,164 |  |

[0001408710-22-000026:8k_2_02:49]
FABRINET

[0001408710-22-000026:8k_2_02:50]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-22-000026:8k_2_02:51]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 25,2022 |  | March 26,2021 |  | March 25,2022 |  | March 26,2021 |
| (in thousands of U.S. dollars, except share data and par value) | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |
| GAAP measures | $ | 50,661 |  |  | $ | 1.35 |  |  | $ | 37,493 |  |  | $ | 1.00 |  |  | $ | 144,191 |  |  | $ | 3.85 |  |  | $ | 105,928 |  |  | $ | 2.82 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 1,183 |  |  | 0.03 |  |  | 1,388 |  |  | 0.04 |  |  | 4,579 |  |  | 0.12 |  |  | 4,805 |  |  | 0.13 |  |
| Depreciation of fair value uplift | — |  |  | — |  |  | 89 |  |  | 0.00 |  | 92 |  |  | 0.00 |  | 256 |  |  | 0.00 |
| Total related to gross profit | 1,183 |  |  | 0.03 |  |  | 1,477 |  |  | 0.04 |  |  | 4,671 |  |  | 0.12 |  |  | 5,061 |  |  | 0.13 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 4,540 |  |  | 0.12 |  |  | 5,476 |  |  | 0.15 |  |  | 17,122 |  |  | 0.46 |  |  | 13,937 |  |  | 0.37 |  |
| Amortization of intangibles | 101 |  |  | 0.00 |  |  | 127 |  |  | 0.00 |  |  | 328 |  |  | 0.01 |  |  | 382 |  |  | 0.01 |  |
| Severance payment and others | (250) |  |  | 0.00 |  |  | 755 |  |  | 0.02 |  |  | 105 |  |  | 0.00 |  |  | 755 |  |  | 0.02 |  |
| Total related to selling, general and administrative expenses | 4,391 |  |  | 0.12 |  |  | 6,358 |  |  | 0.17 |  |  | 17,555 |  |  | 0.47 |  |  | 15,074 |  |  | 0.40 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other expenses in relation to reduction in workforce | — |  |  | — |  |  | 43 |  |  | 0.00 |  | 135 |  |  | 0.01 |  | 43 |  |  | 0.00 |
| Amortization of deferred debt issuance costs | 8 |  |  | 0.00 |  | 8 |  |  | 0.00 |  | 24 |  |  | 0.00 |  | 24 |  |  | 0.00 |
| Total related to other incomes and other expenses | 8 |  |  | 0.00 |  | 51 |  |  | 0.00 |  | 159 |  |  | 0.01 |  | 67 |  |  | 0.00 |
| Total related to net income & EPS | 5,582 |  |  | 0.15 |  |  | 7,886 |  |  | 0.21 |  |  | 22,385 |  |  | 0.60 |  |  | 20,202 |  |  | 0.54 |  |
| Non-GAAP measures | $ | 56,243 |  |  | $ | 1.50 |  |  | $ | 45,379 |  |  | $ | 1.21 |  |  | $ | 166,576 |  |  | $ | 4.45 |  |  | $ | 126,130 |  |  | $ | 3.36 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  | 37,473 |  |  |  |  | 37,609 |  |  |  |  | 37,451 |  |  |  | 37,514 |
| Non-GAAP diluted shares |  |  | 37,473 |  |  |  |  | 37,609 |  |  |  |  | 37,451 |  |  |  | 37,514 |

[0001408710-22-000026:8k_2_02:52]
FABRINET

[0001408710-22-000026:8k_2_02:53]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001408710-22-000026:8k_2_02:54]
| (amount in thousands) |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 25,2022 |  | March 26,2021 |  | March 25,2022 |  | March 26,2021 |
| Net cash provided by operating activities |  | $ | 50,329 |  |  | $ | 38,002 |  |  | $ | 107,897 |  |  | $ | 79,316 |  |
| Less: Purchase of property, plant and equipment |  | (23,410) |  |  | (10,576) |  |  | (75,327) |  |  | (33,269) |  |
| Non-GAAP free cash flow |  | $ | 26,919 |  |  | $ | 27,426 |  |  | $ | 32,570 |  |  | $ | 46,047 |  |

[0001408710-22-000026:8k_2_02:55]
FABRINET

[0001408710-22-000026:8k_2_02:56]
GUIDANCE FOR QUARTER ENDING JUNE 24, 2022

[0001408710-22-000026:8k_2_02:57]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-22-000026:8k_2_02:58]
|  | DilutedEPS |
| GAAP net income per diluted share: | $1.35 to $1.42 |
| Related to cost of revenues: |  |
| Share-based compensation expenses | 0.04 |
| Total related to gross profit | 0.04 |
| Related to selling, general and administrative expenses: |  |
| Share-based compensation expenses | 0.13 |
| Total related to selling, general and administrative expenses | 0.13 |
| Total related to net income & EPS | 0.17 |
| Non-GAAP net income per diluted share | $1.52 to $1.59 |
