# FN MD&A — 0001408710-22-000028


## mdna

[0001408710-22-000028:mdna:1]
[same as prior period, unchanged from 0001408710-22-000018:mdna:1]

[0001408710-22-000028:mdna:2]
[same as prior period, unchanged from 0001408710-22-000018:mdna:2]

[0001408710-22-000028:mdna:3]
[same as prior period, unchanged from 0001408710-22-000018:mdna:3]

[0001408710-22-000028:mdna:4]
[same as prior period, unchanged from 0001408710-22-000018:mdna:4]

[0001408710-22-000028:mdna:5]
•our expectation that the portion of our revenues attributable to customers in regions outside of North America for the remainder of fiscal year 2022 will be in line with the portion of those revenues for the nine months ended March 25, 2022;

[0001408710-22-000028:mdna:6]
[same as prior period, unchanged from 0001408710-22-000018:mdna:6]

[0001408710-22-000028:mdna:7]
•our expectation that our fiscal year 2022 selling, general and administrative (“SG&A”) expenses will increase compared to fiscal year 2021 SG&A expenses;

[0001408710-22-000028:mdna:8]
[same as prior period, unchanged from 0001408710-22-000018:mdna:8]

[0001408710-22-000028:mdna:9]
[same as prior period, unchanged from 0001408710-22-000018:mdna:9]

[0001408710-22-000028:mdna:10]
[same as prior period, unchanged from 0001408710-22-000018:mdna:10]

[0001408710-22-000028:mdna:11]
[same as prior period, unchanged from 0001408710-22-000018:mdna:11]

[0001408710-22-000028:mdna:12]
[same as prior period, unchanged from 0001408710-22-000018:mdna:12]

[0001408710-22-000028:mdna:13]
[same as prior period, unchanged from 0001408710-22-000018:mdna:13]

[0001408710-22-000028:mdna:14]
[same as prior period, unchanged from 0001408710-22-000018:mdna:14]

[0001408710-22-000028:mdna:15]
[same as prior period, unchanged from 0001408710-22-000018:mdna:15]

[0001408710-22-000028:mdna:16]
[same as prior period, unchanged from 0001408710-22-000018:mdna:16]

[0001408710-22-000028:mdna:17]
[same as prior period, unchanged from 0001408710-22-000018:mdna:17]

[0001408710-22-000028:mdna:18]
[same as prior period, unchanged from 0001408710-22-000018:mdna:18]

[0001408710-22-000028:mdna:19]
[same as prior period, unchanged from 0001408710-22-000018:mdna:19]

[0001408710-22-000028:mdna:20]
[same as prior period, unchanged from 0001408710-22-000018:mdna:20]

[0001408710-22-000028:mdna:21]
[same as prior period, unchanged from 0001408710-22-000018:mdna:21]

[0001408710-22-000028:mdna:22]
[same as prior period, unchanged from 0001408710-22-000018:mdna:22]

[0001408710-22-000028:mdna:23]
[same as prior period, unchanged from 0001408710-22-000018:mdna:23]

[0001408710-22-000028:mdna:24]
[same as prior period, unchanged from 0001408710-22-000018:mdna:24]

[0001408710-22-000028:mdna:25]
[same as prior period, unchanged from 0001408710-22-000018:mdna:25]

[0001408710-22-000028:mdna:26]
[same as prior period, unchanged from 0001408710-22-000018:mdna:26]

[0001408710-22-000028:mdna:27]
During the three months ended March 25, 2022, several countries where we have manufacturing facilities, including Thailand, the PRC, the U.S. and the U.K., experienced a surge in the number of COVID-19 cases. We continue to take precautionary measures including implementing leaves of absence for affected employees and their close contacts, stringent contact tracing, enhanced safe distancing measures, and arrangements for the vaccination of our employees in Thailand. Although we did not experience any significant disruptions in our operations or decrease in customer demand during the three months ended March 25, 2022, any worsening of the pandemic may result in more stringent measures being implemented by local authorities, such as shutting down our manufacturing facilities, which would have a significant negative impact on our operations.

[0001408710-22-000028:mdna:28]
[same as prior period, unchanged from 0001408710-22-000018:mdna:28]

[0001408710-22-000028:mdna:29]
Given the unprecedented human and economic impact of the COVID-19 pandemic globally, the extraordinary economic short-term uncertainty resulting therefrom, and the evolving and differing national strategies for dealing with COVID-19, it is challenging to provide a forward-looking assessment. However, despite uncertainty and concern about the global economy and the health of various industries, we can share some relevant perspectives as we continue to assess the impacts of COVID-19 on our business in the future:

[0001408710-22-000028:mdna:30]
[same as prior period, unchanged from 0001408710-22-000018:mdna:31]

[0001408710-22-000028:mdna:31]
[same as prior period, unchanged from 0001408710-22-000018:mdna:32]

[0001408710-22-000028:mdna:32]
•In the near term, we expect to continue experiencing disruptions in our supply chain and fluctuations in the availability of parts and materials, especially if the COVID-19 pandemic intensifies or returns in various geographic areas. These disruptions and shortages have impacted, and will continue to impact, our ability to generate revenue.

[0001408710-22-000028:mdna:33]
[same as prior period, unchanged from 0001408710-22-000018:mdna:34]

[0001408710-22-000028:mdna:34]
[same as prior period, unchanged from 0001408710-22-000018:mdna:35]

[0001408710-22-000028:mdna:35]
•Given our $515.0 million in cash, cash equivalents and short-term investments, and our total debt of approximately $30.5 million as of March 25, 2022, we believe we are in a solid position from a capital and financial resources perspective. We expect that our current cash and cash equivalent balances and short-term investments, and cash flows generated from operations will be sufficient to meet our domestic and international working capital needs and other capital and liquidity requirements for at least the next 12 months.

[0001408710-22-000028:mdna:36]
[same as prior period, unchanged from 0001408710-22-000018:mdna:37]

[0001408710-22-000028:mdna:37]
[same as prior period, unchanged from 0001408710-22-000018:mdna:38]

[0001408710-22-000028:mdna:38]
We expect that disruptions in our supply chain and fluctuations in the availability of parts and materials will continue to have a significant impact on our ability to generate revenue, despite strong demand from our customers. These supply chain disruptions have been exacerbated by recent global events, such as (1) COVID-related lockdowns in China, which are causing freight and logistics issues and unforeseen delays, and (2) the armed conflict between Russia and Ukraine. While we have no direct business in Ukraine, the conflict has negatively impacted demand from some of our automotive customers that have other suppliers in the region.  Moreover, if the facilities of our subsidiary in Fuzhou, China are locked down, we would also be negatively impacted since we and some of our customers rely on the optics components that are manufactured in such facilities. Furthermore, in some cases, our efforts to identify and secure alternative supply chain sources has resulted in our customers or their end customers requiring requalification and validation of components, a process that can often be lengthy and has negatively impacted the timing of our revenue. We expect these supply constraints to continue, and potentially worsen, for at least the next 12 months.

[0001408710-22-000028:mdna:39]
[same as prior period, unchanged from 0001408710-22-000018:mdna:39]

[0001408710-22-000028:mdna:40]
We generate revenues from three geographic regions: North America; Asia-Pacific and others; and Europe. Revenues are attributed to a particular geographic area based on the bill-to location of our customers, notwithstanding that our customers may ultimately ship their products to end customers in a different geographic region. The majority of our revenues are derived from our manufacturing facilities in Asia-Pacific.

[0001408710-22-000028:mdna:41]
The percentage of our revenues generated from a bill-to location outside of North America decreased from 51.8% in the three months ended March 26, 2021 to 47.5% in the three months ended March 25, 2022, primarily because the increase in sales to our customers outside of North America was lower than the increase in sales to our customers in North America.

[0001408710-22-000028:mdna:42]
The percentage of our revenues generated from a bill-to location outside of North America increased from 51.6% in the nine months ended March 26, 2021 to 52.8% in the nine months ended March 25, 2022, primarily because the increase in sales to our customers outside of North America was greater than the increase in sales to our customers in North America.

[0001408710-22-000028:mdna:43]
Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside North America for the remainder of fiscal year 2022 will be in line with the portion of revenues attributable to such customers during the nine months ended March 25, 2022.

[0001408710-22-000028:mdna:44]
[same as prior period, unchanged from 0001408710-22-000018:mdna:44]

[0001408710-22-000028:mdna:45]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 25, 2022 |  | March 26, 2021 |  | March 25, 2022 |  | March 26, 2021 |
| North America | 52.5 | % |  | 48.2 | % |  | 47.2 | % |  | 48.4 | % |
| Asia-Pacific and others | 34.8 |  |  | 34.9 |  |  | 37.3 |  |  | 34.1 |  |
| Europe | 12.7 |  |  | 16.9 |  |  | 15.5 |  |  | 17.5 |  |
|  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001408710-22-000028:mdna:46]
[same as prior period, unchanged from 0001408710-22-000018:mdna:46]

[0001408710-22-000028:mdna:47]
[same as prior period, unchanged from 0001408710-22-000018:mdna:47]

[0001408710-22-000028:mdna:48]
[same as prior period, unchanged from 0001408710-22-000018:mdna:48]

[0001408710-22-000028:mdna:49]
[same as prior period, unchanged from 0001408710-22-000018:mdna:49]

[0001408710-22-000028:mdna:50]
A second significant element of our cost of revenues is employee costs, including indirect employee costs related to design, configuration and optimization of manufacturing processes for our customers, quality testing, materials testing and other

[0001408710-22-000028:mdna:51]
engineering services; and direct costs related to our manufacturing employees. Direct employee costs include employee salaries, insurance and benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a lesser extent, costs to recruit, train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand, the PRC and the U.K., the fluctuation of the Thai baht, Chinese Renminbi (“RMB”) and Pound Sterling (“GBP”) against our functional currency, the U.S. dollar, and our ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention and asset utilization.

[0001408710-22-000028:mdna:52]
[same as prior period, unchanged from 0001408710-22-000018:mdna:51]

[0001408710-22-000028:mdna:53]
[same as prior period, unchanged from 0001408710-22-000018:mdna:52]

[0001408710-22-000028:mdna:54]
[same as prior period, unchanged from 0001408710-22-000018:mdna:53]

[0001408710-22-000028:mdna:55]
[same as prior period, unchanged from 0001408710-22-000018:mdna:54]

[0001408710-22-000028:mdna:56]
[same as prior period, unchanged from 0001408710-22-000018:mdna:55]

[0001408710-22-000028:mdna:57]
[same as prior period, unchanged from 0001408710-22-000018:mdna:56]

[0001408710-22-000028:mdna:58]
[same as prior period, unchanged from 0001408710-22-000018:mdna:57]

[0001408710-22-000028:mdna:59]
As a result of our international operations, we are exposed to foreign exchange risk arising from various currency exposures, primarily with respect to the Thai baht. Although a majority of our total revenues is denominated in U.S. dollars, a substantial portion of our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rate between the Thai baht and the U.S. dollar has fluctuated substantially in recent years and may continue to fluctuate substantially in the future. We report our financial results in U.S. dollars and our results of operations have been and could in the future be negatively impacted if the Thai baht appreciates against the U.S. dollar. Smaller portions of our expenses are incurred in a variety of other currencies, including RMB, GBP, Canadian dollars, Euros, and Japanese yen, the appreciation of which may also negatively impact our financial results.

[0001408710-22-000028:mdna:60]
[same as prior period, unchanged from 0001408710-22-000018:mdna:59]

[0001408710-22-000028:mdna:61]
[same as prior period, unchanged from 0001408710-22-000018:mdna:60]

[0001408710-22-000028:mdna:62]
|  | As of March 25, 2022 |  | As of June 25, 2021 |
| (amount in thousands, except percentages) | Currency |  | $ |  | % |  | Currency |  | $ |  | % |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 727,851 |  |  | $ | 21,727 |  |  | 55.1 | % |  | 1,472,249 |  |  | $ | 46,312 |  |  | 67.5 | % |
| RMB | 65,937 |  |  | 10,345 |  |  | 26.2 |  |  | 98,056 |  |  | 15,145 |  |  | 22.1 |  |
| GBP | 5,589 |  |  | 7,381 |  |  | 18.7 |  |  | 5,111 |  |  | 7,119 |  |  | 10.4 |  |
| Total |  |  | $ | 39,453 |  |  | 100.0 | % |  |  |  | $ | 68,576 |  |  | 100.0 | % |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 2,549,770 |  |  | $ | 76,113 |  |  | 84.6 | % |  | 2,250,514 |  |  | $ | 70,793 |  |  | 87.7 | % |
| RMB | 67,651 |  |  | 10,614 |  |  | 11.8 |  |  | 40,112 |  |  | 6,195 |  |  | 7.7 |  |
| GBP | 2,428 |  |  | 3,207 |  |  | 3.6 |  |  | 2,656 |  |  | 3,699 |  |  | 4.6 |  |
| Total |  |  | $ | 89,934 |  |  | 100.0 | % |  |  |  | $ | 80,687 |  |  | 100.0 | % |

[0001408710-22-000028:mdna:63]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of March 25, 2022, there was $135.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 25, 2021, there was $130.0 million of foreign currency forward contracts outstanding on the Thai baht payables.

[0001408710-22-000028:mdna:64]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of March 25, 2022 and June 25, 2021, we did not have any derivative contracts denominated in RMB.

[0001408710-22-000028:mdna:65]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable and other payables. As of March 25, 2022 and June 25, 2021, we did not have any derivative contracts denominated in GBP.

[0001408710-22-000028:mdna:66]
For the three months ended March 25, 2022 and March 26, 2021, we recorded gain of $0.1 million and loss of $2.0 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-22-000028:mdna:67]
For the nine months ended March 25, 2022 and March 26, 2021, we recorded gain of $0.6 million and loss of $1.7 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-22-000028:mdna:68]
[same as prior period, unchanged from 0001408710-22-000018:mdna:67]

[0001408710-22-000028:mdna:69]
[same as prior period, unchanged from 0001408710-22-000018:mdna:68]

[0001408710-22-000028:mdna:70]
[same as prior period, unchanged from 0001408710-22-000018:mdna:69]

[0001408710-22-000028:mdna:71]
[same as prior period, unchanged from 0001408710-22-000018:mdna:70]

[0001408710-22-000028:mdna:72]
[same as prior period, unchanged from 0001408710-22-000018:mdna:71]

[0001408710-22-000028:mdna:73]
[same as prior period, unchanged from 0001408710-22-000018:mdna:72]

[0001408710-22-000028:mdna:74]
Under the Administration Rules, foreign-invested enterprises may only buy, sell, or remit foreign currencies at banks authorized to conduct foreign exchange business after providing valid commercial documents and relevant supporting documents and, in the case of capital account item transactions, obtaining approval from SAFE. Capital investments by foreign-

[0001408710-22-000028:mdna:75]
invested enterprises outside of the PRC are also subject to limitations, which include approvals by the Ministry of Commerce, SAFE and the State Development and Reform Commission.

[0001408710-22-000028:mdna:76]
[same as prior period, unchanged from 0001408710-22-000018:mdna:74]

[0001408710-22-000028:mdna:77]
On January 5, 2007, SAFE promulgated the Detailed Rules for Implementing the Measures for the Administration on Individual Foreign Exchange (the “Implementation Rules”). Under the Implementation Rules, PRC citizens who are granted share options by an overseas publicly-listed company are required, through a PRC agent or PRC subsidiary of such overseas publicly-listed company, to register with SAFE and complete certain other procedures.

[0001408710-22-000028:mdna:78]
In addition, the General Administration of Taxation has issued circulars concerning employee share options. Under these circulars, our employees working in the PRC who exercise share options will be subject to PRC individual income tax. Our PRC subsidiary has obligations to file documents related to employee share options with relevant tax authorities and withhold individual income taxes of those employees who exercise their share options.

[0001408710-22-000028:mdna:79]
[same as prior period, unchanged from 0001408710-22-000018:mdna:78]

[0001408710-22-000028:mdna:80]
[same as prior period, unchanged from 0001408710-22-000018:mdna:79]

[0001408710-22-000028:mdna:81]
[same as prior period, unchanged from 0001408710-22-000018:mdna:80]

[0001408710-22-000028:mdna:82]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption on income generated from projects to manufacture certain products at our Chonburi campus is currently available to us through June 2026. Similar preferential tax treatment was available to us through June 2020 with respect to certain products manufactured at our Pinehurst campus Building 6. After June 2020, 50% of our income generated from certain products manufactured at our Pinehurst campus is exempted from tax through June 2025. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted. Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001408710-22-000028:mdna:83]
[same as prior period, unchanged from 0001408710-22-000018:mdna:82]

[0001408710-22-000028:mdna:84]
[same as prior period, unchanged from 0001408710-22-000018:mdna:83]

[0001408710-22-000028:mdna:85]
[same as prior period, unchanged from 0001408710-22-000018:mdna:84]

[0001408710-22-000028:mdna:86]
[same as prior period, unchanged from 0001408710-22-000018:mdna:85]

[0001408710-22-000028:mdna:87]
[same as prior period, unchanged from 0001408710-22-000018:mdna:86]

[0001408710-22-000028:mdna:88]
[same as prior period, unchanged from 0001408710-22-000018:mdna:87]

[0001408710-22-000028:mdna:89]
| (amount in thousands) | Three Months Ended |  | Nine Months Ended |
| March 25,2022 |  | March 26,2021 |  | March 25,2022 |  | March 26,2021 |
| Revenues | $ | 564,395 |  |  | $ | 479,317 |  |  | $ | 1,674,350 |  |  | $ | 1,369,783 |  |
| Cost of revenues | (493,702) |  |  | (422,539) |  |  | (1,470,689) |  |  | (1,209,504) |  |
| Gross profit | 70,693 |  |  | 56,778 |  |  | 203,661 |  |  | 160,279 |  |
| Selling, general and administrative expenses | (17,034) |  |  | (19,059) |  |  | (55,412) |  |  | (53,078) |  |
| Expenses related to reduction in workforce | — |  |  | (43) |  |  | (135) |  |  | (43) |  |
| Operating income | 53,659 |  |  | 37,676 |  |  | 148,114 |  |  | 107,158 |  |
| Interest income | 414 |  |  | 941 |  |  | 1,470 |  |  | 3,156 |  |
| Interest expense | (73) |  |  | (282) |  |  | (347) |  |  | (798) |  |
| Foreign exchange gain (loss), net | (410) |  |  | 629 |  |  | 998 |  |  | 224 |  |
| Other income (expense), net | (36) |  |  | 124 |  |  | (1,351) |  |  | 403 |  |
| Income before income taxes | 53,554 |  |  | 39,088 |  |  | 148,884 |  |  | 110,143 |  |
| Income tax expense | (2,893) |  |  | (1,595) |  |  | (4,693) |  |  | (4,215) |  |
| Net income | 50,661 |  |  | 37,493 |  |  | 144,191 |  |  | 105,928 |  |
| Other comprehensive income (loss), net of tax | (1,699) |  |  | (5,282) |  |  | (622) |  |  | (5,792) |  |
| Net comprehensive income | $ | 48,962 |  |  | $ | 32,211 |  |  | $ | 143,569 |  |  | $ | 100,136 |  |

[0001408710-22-000028:mdna:90]
[same as prior period, unchanged from 0001408710-22-000018:mdna:89]

[0001408710-22-000028:mdna:91]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 25,2022 |  | March 26,2021 |  | March 25,2022 |  | March 26,2021 |
| Revenues | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenues | (87.5) |  |  | (88.2) |  |  | (87.8) |  |  | (88.3) |  |
| Gross profit | 12.5 |  |  | 11.8 |  |  | 12.2 |  |  | 11.7 |  |
| Selling, general and administrative expenses | (3.0) |  |  | (4.0) |  |  | (3.4) |  |  | (3.9) |  |
| Expenses related to reduction in workforce | — |  |  | 0.0 |  |  | 0.0 |  |  | 0.0 |  |
| Operating income | 9.5 |  |  | 7.8 |  |  | 8.8 |  |  | 7.8 |  |
| Interest income | 0.1 |  |  | 0.2 |  |  | 0.1 |  |  | 0.2 |  |
| Interest expense | 0.0 |  |  | 0.0 |  |  | 0.1 |  |  | 0.0 |  |
| Foreign exchange gain (loss), net | (0.1) |  |  | 0.1 |  |  | 0.1 |  |  | 0.0 |  |
| Other income (expense), net | 0.0 |  |  | 0.0 |  |  | (0.2) |  |  | 0.0 |  |
| Income before income taxes | 9.5 |  |  | 8.1 |  |  | 8.9 |  |  | 8.0 |  |
| Income tax expense | (0.5) |  |  | (0.3) |  |  | (0.3) |  |  | (0.3) |  |
| Net income | 9.0 |  |  | 7.8 |  |  | 8.6 |  |  | 7.7 |  |
| Other comprehensive income (loss), net of tax | (0.3) |  |  | (1.1) |  |  | 0.0 |  |  | (0.4) |  |
| Net comprehensive income | 8.7 | % |  | 6.7 | % |  | 8.6 | % |  | 7.3 | % |

[0001408710-22-000028:mdna:92]
[same as prior period, unchanged from 0001408710-22-000018:mdna:91]

[0001408710-22-000028:mdna:93]
[same as prior period, unchanged from 0001408710-22-000018:mdna:92]

[0001408710-22-000028:mdna:94]
|  | Three Months Ended |  | Nine Months Ended |
| (amount in thousands) | March 25,2022 |  | March 26,2021 |  | March 25,2022 |  | March 26,2021 |
| Optical communications | $ | 440,003 |  |  | $ | 361,739 |  |  | $ | 1,318,087 |  |  | $ | 1,053,496 |  |
| Lasers, sensors and other | 124,392 |  |  | 117,578 |  |  | 356,263 |  |  | 316,287 |  |
| Total | $ | 564,395 |  |  | $ | 479,317 |  |  | $ | 1,674,350 |  |  | $ | 1,369,783 |  |

[0001408710-22-000028:mdna:95]
[same as prior period, unchanged from 0001408710-22-000018:mdna:94]

[0001408710-22-000028:mdna:96]
Comparison of Three and Nine Months Ended March 25, 2022 with Three and Nine Months Ended March 26, 2021

[0001408710-22-000028:mdna:97]
[same as prior period, unchanged from 0001408710-22-000018:mdna:96]

[0001408710-22-000028:mdna:98]
Our revenues increased by $85.1 million, or 17.7%, to $564.4 million for the three months ended March 25, 2022, compared with $479.3 million for the three months ended March 26, 2021. This increase was due to an increase in our key customers’ demand for optical communications manufacturing services during the three months ended March 25, 2022. Revenues from optical communications products increased by $78.3 million, or 21.6%, for the three months ended March 25, 2022 compared to the same period in the prior fiscal year.

[0001408710-22-000028:mdna:99]
Our revenues increased by $304.6 million, or 22.2%, to $1,674.4 million for the nine months ended March 25, 2022, compared with $1,369.8 million for the nine months ended March 26, 2021. This increase was due to an increase in our key customers’ demand for optical communications manufacturing services during the nine months ended March 25, 2022. Revenues from optical communications products increased by $264.6 million, or 25.1%, for the nine months ended March 25, 2022 compared to the same period in the prior fiscal year.

[0001408710-22-000028:mdna:100]
[same as prior period, unchanged from 0001408710-22-000018:mdna:99]

[0001408710-22-000028:mdna:101]
Our cost of revenues increased by $71.2 million, or 16.8%, to $493.7 million, or 87.5% of revenues, for the three months ended March 25, 2022, compared with $422.5 million, or 88.2% of revenues, for the three months ended March 26, 2021. This increase in cost of revenues on an absolute dollar basis was in line with the increase in sales volume.

[0001408710-22-000028:mdna:102]
Our cost of revenues increased by $261.2 million, or 21.6%, to $1,470.7 million, or 87.8% of revenues, for the nine months ended March 25, 2022, compared with $1,209.5 million, or 88.3% of revenues, for the nine months ended March 26, 2021. This increase in cost of revenues on an absolute dollar basis was in line with the increase in sales volume.

[0001408710-22-000028:mdna:103]
[same as prior period, unchanged from 0001408710-22-000018:mdna:102]

[0001408710-22-000028:mdna:104]
Our gross profit increased by $13.9 million, or 24.5%, to $70.7 million, or 12.5% of revenues, for the three months ended March 25, 2022, compared with $56.8 million, or 11.8% of revenues, for the three months ended March 26, 2021. The increase was primarily due to an increase in sales volume.

[0001408710-22-000028:mdna:105]
Our gross profit increased by $43.4 million, or 27.1%, to $203.7 million, or 12.2% of revenues, for the nine months ended March 25, 2022, compared with $160.3 million, or 11.7% of revenues, for the nine months ended March 26, 2021. The increase was primarily due to an increase in sales volume.

[0001408710-22-000028:mdna:106]
[same as prior period, unchanged from 0001408710-22-000018:mdna:105]

[0001408710-22-000028:mdna:107]
Our SG&A expenses decreased by $2.0 million, or 10.6%, to $17.0 million, or 3.0% of revenues, for the three months ended March 25, 2022, compared with $19.1 million, or 4.0% of revenues, for the three months ended March 26, 2021. The decrease was primarily due to (1) a decrease in share-based compensation expenses of $0.9 million, (2) a severance payment of $0.8 million related to a senior management retirement in the third quarter of fiscal year 2021, and (3) a decrease in start-up cost for our subsidiary in Israel of $0.4 million, offset by an increase in insurance expense of $0.1 million.

[0001408710-22-000028:mdna:108]
Our SG&A expenses increased by $2.3 million, or 4.4%, to $55.4 million, or 3.4% of revenues, for the nine months ended March 25, 2022, compared with $53.1 million, or 3.9% of revenues, for the nine months ended March 26, 2021. The increase was primarily due to (1) an increase in share-based compensation expenses of $3.2 million, mainly due to higher achievement of our targets for performance-based awards, (2) an increase in insurance expense of $0.5 million, and (3) the

[0001408710-22-000028:mdna:109]
reversal of allowance for doubtful debt of $0.3 million in the same period of fiscal year 2021, offset by a decrease in start-up cost for our subsidiary in Israel of $1.7 million.

[0001408710-22-000028:mdna:110]
[same as prior period, unchanged from 0001408710-22-000018:mdna:109]

[0001408710-22-000028:mdna:111]
Our operating income increased by $16.0 million to $53.7 million, or 9.5% of revenues, for the three months ended March 25, 2022, compared with $37.7 million, or 7.8% of revenues, for the three months ended March 26, 2021. The increase was primarily due to an increase in revenues.

[0001408710-22-000028:mdna:112]
Our operating income increased by $41.0 million to $148.1 million, or 8.8% of revenues, for the nine months ended March 25, 2022, compared with $107.2 million, or 7.8% of revenues, for the nine months ended March 26, 2021. The increase was primarily due to an increase in revenues.

[0001408710-22-000028:mdna:113]
[same as prior period, unchanged from 0001408710-22-000018:mdna:112]

[0001408710-22-000028:mdna:114]
Our interest income decreased by $0.5 million, or 56.0%, to $0.4 million, or 0.1% of revenues, for the three months ended March 25, 2022, compared with $0.9 million, or 0.2% of revenues, for the three months ended March 26, 2021. The decrease was primarily due to a lower weighted average interest rate during the three months ended March 25, 2022 compared to same period in the prior fiscal year.

[0001408710-22-000028:mdna:115]
Our interest income decreased by $1.7 million, or 53.4%, to $1.5 million, or 0.1% of revenues, for the nine months ended March 25, 2022, compared with $3.2 million, or 0.2% of revenues, for the nine months ended March 26, 2021. The decrease was primarily due to a lower weighted average interest rate during the nine months ended March 25, 2022 compared to same period in the prior fiscal year.

[0001408710-22-000028:mdna:116]
[same as prior period, unchanged from 0001408710-22-000018:mdna:115]

[0001408710-22-000028:mdna:117]
Our interest expense decreased by $0.2 million to $0.1 million for the three months ended March 25, 2022, compared with $0.3 million for the three months ended March 26, 2021. The decrease was primarily due to interest expense capitalized to a new manufacturing building at our Chonburi campus of $0.3 million during the three months ended March 25, 2022, offset by lower amortization of the fair value of interest rate swaps of $0.1 million.

[0001408710-22-000028:mdna:118]
Our interest expense decreased by $0.5 million to $0.3 million for the nine months ended March 25, 2022, compared with $0.8 million for the nine months ended March 26, 2021. The decrease was primarily due to interest expense capitalized to a new manufacturing building at our Chonburi campus of $0.6 million during the nine months ended March 25, 2022, offset by lower amortization of the fair value of interest rate swaps of $0.3 million.

[0001408710-22-000028:mdna:119]
[same as prior period, unchanged from 0001408710-22-000018:mdna:118]

[0001408710-22-000028:mdna:120]
We recorded foreign exchange loss, net of $0.4 million for the three months ended March 25, 2022, compared with foreign exchange gain, net of $0.6 million for the three months ended March 26, 2021. The increase in foreign exchange loss was mainly due to (1) unrealized loss from revaluation of outstanding Thai baht assets and liabilities of $0.3 million for the three months ended March 25, 2022, as compared to unrealized gain from revaluation of outstanding Thai baht assets and liabilities of $2.5 million for the three months ended March 26, 2021, (2) foreign exchange loss from our subsidiaries in the PRC and the U.K. totaling $0.2 million for the three months ended March 25, 2022, as compared to foreign exchange gain from our subsidiaries in the PRC and the U.K. totaling $0.1 million for the three months ended March 26, 2021, and (3) lower unrealized gain from revaluation of other currencies of $8.0 thousand for the three months ended March 25, 2022, as compared to unrealized gain from revaluation of other currencies of $0.2 million for the three months ended March 26, 2021, offset by unrealized gain from mark-to-market forward contracts of $0.1 million for the three months ended March 25, 2022, as compared to unrealized loss from mark-to-market forward contracts of $2.0 million for the three months ended March 26, 2021.

[0001408710-22-000028:mdna:121]
We recorded foreign exchange gain, net of $1.0 million for the nine months ended March 25, 2022, compared with foreign exchange gain, net of $0.2 million for the nine months ended March 26, 2021. The increase in foreign exchange gain was mainly due to (1) unrealized gain from mark-to-market forward contracts of $0.6 million for the nine months ended March 25, 2022, as compared to unrealized loss from mark-to-market forward contracts of $1.7 million for the nine months ended March 26, 2021, and (2) realized gain from payment/receipt of $0.7 million for the nine months ended March 25, 2022, as compared to realized loss from payment/receipt of $1.1 million for the nine months ended March 26, 2021, partially offset by (1) foreign exchange loss from our subsidiaries in the PRC and the U.K. totaling $0.6 million for the nine months ended March 25, 2022, as compared to foreign exchange gain from our subsidiaries in the PRC and the U.K. totaling $1.2 million for the nine months ended March 26, 2021, and (2) lower unrealized gain from revaluation of outstanding Thai baht assets and

[0001408710-22-000028:mdna:122]
liabilities of $0.3 million for the nine months ended March 25, 2022, as compared to unrealized gain from revaluation of outstanding Thai baht assets and liabilities of $1.9 million for the nine months ended March 26, 2021.

[0001408710-22-000028:mdna:123]
[same as prior period, unchanged from 0001408710-22-000018:mdna:122]

[0001408710-22-000028:mdna:124]
We recorded income before income taxes of $53.6 million and $148.9 million for the three and nine months ended March 25, 2022, respectively, compared with $39.1 million and $110.1 million for the three and nine months ended March 26, 2021, respectively.

[0001408710-22-000028:mdna:125]
[same as prior period, unchanged from 0001408710-22-000018:mdna:124]

[0001408710-22-000028:mdna:126]
Our provision for income tax reflects effective tax rates of 5.4% and 4.1% for the three months ended March 25, 2022 and March 26, 2021, respectively. The increase was primarily due to the fact that we had more income subject to tax during the third quarter of fiscal year 2022 as compared to the same period in fiscal year 2021.

[0001408710-22-000028:mdna:127]
Our provision for income tax reflects effective tax rates of 3.2% and 3.8% for the nine months ended March 25, 2022 and March 26, 2021, respectively. The decrease was primarily due to the fact that we had less income subject to tax during the first nine months of fiscal year 2022 as compared to the same period in fiscal year 2021.

[0001408710-22-000028:mdna:128]
[same as prior period, unchanged from 0001408710-22-000018:mdna:127]

[0001408710-22-000028:mdna:129]
We recorded net income of $50.7 million, or 9.0% of revenues, for the three months ended March 25, 2022, compared with $37.5 million, or 7.8% of revenues, for the three months ended March 26, 2021.

[0001408710-22-000028:mdna:130]
We recorded net income of $144.2 million, or 8.6% of revenues, for the nine months ended March 25, 2022, compared with $105.9 million, or 7.7% of revenues, for the nine months ended March 26, 2021.

[0001408710-22-000028:mdna:131]
[same as prior period, unchanged from 0001408710-22-000018:mdna:130]

[0001408710-22-000028:mdna:132]
We recorded other comprehensive loss of $1.7 million, or 0.3% of revenues, for the three months ended March 25, 2022, compared with other comprehensive loss of $5.3 million, or 1.1% of revenues, for the three months ended March 26, 2021. The decrease in other comprehensive loss was mainly due to higher unrealized gain from mark-to-market of forward contracts and interest rate swap agreements of $0.7 million for the three months ended March 25, 2022, as compared to unrealized loss from mark-to-market of forward contracts and interest rate swap agreements of $5.0 million for the three months ended March 26, 2021, partially offset by (1) higher unrealized loss from mark-to-market of available-for-sale debt securities of $2.5 million for the three months ended March 25, 2022, as compared to unrealized loss from mark-to-market of available-for-sale debt securities of $0.6 million for the three months ended March 26, 2021, and (2) lower unrealized gain from foreign currency translation adjustment and retirement benefits plan of $0.1 million for the three months ended March 25, 2022, as compared to unrealized gain from foreign currency translation adjustment and retirement benefits plan of $0.3 million for the three months ended March 26, 2021.

[0001408710-22-000028:mdna:133]
We recorded other comprehensive loss of $0.6 million, or 0.0% of revenues, for the nine months ended March 25, 2022, compared with other comprehensive loss of $5.8 million, or 0.4% of revenues, for the nine months ended March 26, 2021. The decrease in other comprehensive loss was mainly due to unrealized gain from mark-to-market of forward contracts and interest rate swap agreements of $2.7 million for the nine months ended March 25, 2022, as compared to unrealized loss from mark-to-market of forward contracts and interest rate swap agreements of $5.8 million for the nine months ended March 26, 2021, partially offset by (1) higher unrealized loss from mark-to-market of available-for-sale debt securities of $3.6 million for the nine months ended March 25, 2022, as compared to unrealized loss from mark-to-market of available-for-sale debt securities of $0.9 million for the nine months ended March 26, 2021, and (2) unrealized loss from foreign currency translation adjustment of $0.2 million for the nine months ended March 25, 2022, as compared to unrealized gain from foreign currency translation adjustment of $0.5 million for the nine months ended March 26, 2021.

[0001408710-22-000028:mdna:134]
[same as prior period, unchanged from 0001408710-22-000018:mdna:133]

[0001408710-22-000028:mdna:135]
[same as prior period, unchanged from 0001408710-22-000018:mdna:134]

[0001408710-22-000028:mdna:136]
We primarily finance our operations through cash flow from operations. As of March 25, 2022 and March 26, 2021, we had cash, cash equivalents, and short-term investments of $515.0 million and $508.7 million, respectively, and outstanding debt of $30.5 million and $42.7 million, respectively.

[0001408710-22-000028:mdna:137]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents was 0.4% and 0.5% for the three and nine months ended March 25, 2022, respectively, and 0.7% and 0.8% for the three and nine months ended March 26, 2021, respectively.

[0001408710-22-000028:mdna:138]
[same as prior period, unchanged from 0001408710-22-000018:mdna:137]

[0001408710-22-000028:mdna:139]
During the nine months ended March 25, 2022, we repaid $9.1 million of the term loan under our credit facility agreement with the Bank of Ayudhya Public Company Limited. As a result, as of March 25, 2022, we had a long-term borrowing of $30.5 million under such credit facility agreement. (See Note 10 for further details.) We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held short-term investments of $245.9 million as of March 25, 2022.

[0001408710-22-000028:mdna:140]
We believe that our current cash and cash equivalents, short-term investments, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001408710-22-000028:mdna:141]
[same as prior period, unchanged from 0001408710-22-000018:mdna:140]

[0001408710-22-000028:mdna:142]
[same as prior period, unchanged from 0001408710-22-000018:mdna:141]

[0001408710-22-000028:mdna:143]
|  | Nine Months Ended |
| (amount in thousands) | March 25, 2022 |  | March 26, 2021 |
| Net cash provided by operating activities | $ | 107,897 |  |  | $ | 79,316 |  |
| Net cash used in investing activities | $ | (83,218) |  |  | $ | (36,414) |  |
| Net cash used in financing activities | $ | (58,204) |  |  | $ | (28,915) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | (33,525) |  |  | $ | 13,987 |  |

[0001408710-22-000028:mdna:144]
[same as prior period, unchanged from 0001408710-22-000018:mdna:143]

[0001408710-22-000028:mdna:145]
Net cash provided by operating activities of $107.9 million for the nine months ended March 25, 2022 was primarily due to (1) net income of $144.2 million, (2) an increase in trade accounts payable of $55.3 million, (3) depreciation and amortization of $28.9 million, and (4) share-based compensation of $21.7 million; offset by (1) an increase in trade accounts receivable of $109.3 million, and (2) inventories of $30.5 million.

[0001408710-22-000028:mdna:146]
Net cash provided by operating activities of $79.3 million for the nine months ended March 26, 2021 was primarily due to (1) net income $105.9 million, (2) an increase in depreciation and amortization of $26.8 million, (3) trade accounts payable $25.6 million, and (4) share-based compensation of $18.7 million; offset by (1) an increase in inventories of $43.5 million, (2) trade accounts receivable of $36.4 million, and (3) other assets of $18.4 million.

[0001408710-22-000028:mdna:147]
[same as prior period, unchanged from 0001408710-22-000018:mdna:146]

[0001408710-22-000028:mdna:148]
Net cash used in investing activities of $83.2 million for the nine months ended March 25, 2022 was primarily due to (1) the purchase of property, plant and equipment of $75.3 million, mainly related to investment in a new manufacturing building at our Chonburi campus, acquisition of land and other equipments, (2) a net purchase of short-term investments of $7.5 million, and (3) the purchase of intangibles assets of $0.6 million.

[0001408710-22-000028:mdna:149]
Net cash used in investing activities of $36.4 million for the nine months ended March 26, 2021 was primarily due to (1) the purchase of property, plant and equipment of $33.3 million, (2) the purchase of intangibles assets of $1.9 million, and (3) a net purchase of short-term investments of $1.3 million.

[0001408710-22-000028:mdna:150]
[same as prior period, unchanged from 0001408710-22-000018:mdna:149]

[0001408710-22-000028:mdna:151]
Net cash used in financing activities of $58.2 million for the nine months ended March 25, 2022 was primarily due to (1) cash paid for repurchase of ordinary shares of $28.6 million, (2) withholding tax related to net share settlement of restricted share units of $20.4 million, and (3) repayment of bank loans of $9.1 million.

[0001408710-22-000028:mdna:152]
Net cash used in financing activities of $28.9 million for the nine months ended March 26, 2021 was primarily due to (1) cash paid for withholding tax related to net share settlement of restricted share units of $11.4 million, (2) repayment of loans to banks of $9.1 million, and (3) repurchase of ordinary shares of $8.3 million.

[0001408710-22-000028:mdna:153]
[same as prior period, unchanged from 0001408710-22-000018:mdna:152]

[0001408710-22-000028:mdna:154]
[same as prior period, unchanged from 0001408710-22-000018:mdna:153]
