# FN note change history — 0001193125-20-024258 → 0001193125-20-133708


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2020-05-05):
[0001193125-20-133708:note_history:1]
As of March 27, 2020 and June 28, 2019, the Company had one outstanding standby letter of credit of 6.0 million Euros, related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. As of March 27, 2020 and June 28, 2019, the standby letter of credit was backed by cash collateral of $7.4 million.

- added (2020-05-05):
[0001193125-20-133708:note_history:2]
As of March 27, 2020 and June 28, 2019, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business 
expenses

- changed (2020-05-05):
[0001193125-20-133708:note_history:3]
totaling 
$1.5 million and $1.6 million, respectively, and there were other bank guarantees given by a bank on behalf of our subsidiaries in China and the United Kingdom to support their operations of
  (was, 2020-02-04, similarity 0.6121):
[0001193125-20-024258:note_history:3]
As of December 27, 2019 and June 28, 2019, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business amounting to $1.7 million and $1.6 million, respectively, and there were other bank guarantees given by a bank on behalf of our subsidiaries in China and the United Kingdom to support their operations of $0.1 
million 
and $26 thousand, respectively.

- added (2020-05-05):
[0001193125-20-133708:note_history:4]
de minimis amounts.

- added (2020-05-05):
[0001193125-20-133708:note_history:5]
Purchase obligations represent legally

- changed (2020-05-05):
[0001193125-20-133708:note_history:6]
binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2020-02-04, similarity 0.9635):
[0001193125-20-024258:note_history:6]
Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- changed (2020-05-05):
[0001193125-20-133708:note_history:7]
As of March 27, 2020, the Company had purchase obligations to third parties of $15.2 million.
  (was, 2020-02-04, similarity 0.7727):
[0001193125-20-024258:note_history:7]
As of December 27, 2019, the Company had an outstanding commitment to third parties of $10.1 million.

- removed (2020-05-05):
[0001193125-20-024258:note_history:8]
As of December 27, 2019 
and
 June 28, 2019,

- removed (2020-05-05):
[0001193125-20-024258:note_history:9]
the Company had two outstanding standby letters of credit 
in the aggregate amount 
of 6.2 million Euros

- removed (2020-05-05):
[0001193125-20-024258:note_history:10]
and
 one outstanding standby letter of credit of 6.0 million Euros
, respectively,
 related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand.

- removed (2020-05-05):
[0001193125-20-024258:note_history:11]
As of December 27, 2019 and June 28, 2019, these

- removed (2020-05-05):
[0001193125-20-024258:note_history:12]
standby letter
s
 of credit w
ere
 backed by cash collateral

- removed (2020-05-05):
[0001193125-20-024258:note_history:13]
in the aggregate amount

- removed (2020-05-05):
[0001193125-20-024258:note_history:14]
of

- removed (2020-05-05):
[0001193125-20-024258:note_history:15]
$
7.7 
million and $
7.4
 million, respectively.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-05-05):
[0001193125-20-133708:note_history:16]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of March 27, 2020 and for the three and nine months ended March 27, 2020 and March 29, 2019 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 
10-K
 for the year ended June 28, 2019.
  (was, 2020-02-04, similarity 0.9542):
[0001193125-20-024258:note_history:16]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of December 27, 2019 and for the three and six months ended December 27, 2019 and December 28, 2018 includes normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 
10-K
 for the year ended June 28, 2019.

- changed (2020-05-05):
[0001193125-20-133708:note_history:17]
The results for the three and nine months ended March 27, 2020 may not be indicative of results for the year ending June 26, 2020 or any future periods.
  (was, 2020-02-04, similarity 0.951):
[0001193125-20-024258:note_history:17]
The results for the three and six months ended December 27, 2019 may not be indicative of results for the year ending June 26, 2020 or any future periods.

- changed (2020-05-05):
[0001193125-20-133708:note_history:18]
Use of 
e
stimates
  (was, 2020-02-04, similarity 0.9697):
[0001193125-20-024258:note_history:18]
Use of Estimates

- changed (2020-05-05):
[0001193125-20-133708:note_history:19]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements, and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisitions, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information.
  (was, 2020-02-04, similarity 0.9996):
[0001193125-20-024258:note_history:19]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements, and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information.

- added (2020-05-05):
[0001193125-20-133708:note_history:20]
The Company utilizes a 
52
 to 
53
-

- changed (2020-05-05):
[0001193125-20-133708:note_history:21]
week fiscal year ending on the Friday in June closest to June 30. The three months ended March 27, 2020 and March 29, 2019 each consisted of 13 weeks. The nine months ended March 27, 2020 and March 29, 2019 each consisted of 39 weeks. Fiscal year 2020 will be comprised of 52 weeks and will end on June 26, 2020.
  (was, 2020-02-04, similarity 0.7475):
[0001193125-20-024258:note_history:21]
The Company utilizes a 
52-53
 week fiscal year ending on the Friday in June closest to June 30. The three months ended December 27, 2019 and December 28, 2018 each consisted of 13 weeks. The six months ended December 27, 2019 and December 28, 2018 each consisted of 26 weeks. Fiscal year 2020 will be comprised of 52 weeks and will end on June 26, 2020.

- added (2020-05-05):
[0001193125-20-133708:note_history:22]
Reclassifications

- added (2020-05-05):
[0001193125-20-133708:note_history:23]
For presentation purposes, certain prior period amounts have been reclassified to conform to the current period presentation. These reclassifications do not affect the Company’s net income, cash flows or stockholders’ equity.

- changed (2020-05-05):
[0001193125-20-133708:note_history:24]
Changes in 
a
ccounting 
p
olicies
  (was, 2020-02-04, similarity 0.9677):
[0001193125-20-024258:note_history:24]
Changes in Accounting Policies

- changed (2020-05-05):
[0001193125-20-133708:note_history:25]
Except for the adoption of the new lease accounting standard and the derivatives and hedging standard described below, the Company has consistently applied 
its
 accounting policies to all periods presented in these unaudited condensed consolidated financial statements.
  (was, 2020-02-04, similarity 0.9888):
[0001193125-20-024258:note_history:25]
Except for the adoption of the new lease accounting standard and the derivatives and hedging standard described below, the Company has consistently applied the accounting policies to all periods presented in these unaudited condensed consolidated financial statements.

- changed (2020-05-05):
[0001193125-20-133708:note_history:26]
C
oncentration of credit risk
  (was, 2020-02-04, similarity 0.875):
[0001193125-20-024258:note_history:26]
Concentration ​​​​​​​of credit risk

- changed (2020-05-05):
[0001193125-20-133708:note_history:27]
On June 29, 2019, the Company adopted the new lease accounting standard, Accounting Standards Codification (“ASC”) Topic 842, which provides guidance for the recognition and disclosure of lease arrangements. The Company adopted ASC 842 using the modified retrospective transition approach. Accordingly, the Company’s comparative financial statements as of June 28, 2019 have not been adjusted. ASC 842 also provides practical expedients for the Company’s ongoing accounting. The Company elected the short-term lease recognition exemption for its operating leases with a term of less than 12 months, which will not require recognition of right of use (“ROU”) assets or lease liabilities for these leases.
  (was, 2020-02-04, similarity 0.9861):
[0001193125-20-024258:note_history:27]
On June 29, 2019, the Company adopted the new lease accounting standard, Accounting Standards Codification Topic 842 (“ASC 842”), which provides guidance for the recognition and disclosure of lease arrangements. The Company adopted ASC 842 using the modified retrospective transition approach. Accordingly, the Company’s comparative financial statements as of June 28, 2019 have not been adjusted. ASC 842 also provides practical expedients for the Company’s ongoing accounting. The Company elected the short-term lease recognition exemption for its operating leases with a term of less than 12 months, which will not require recognition of right of use (“ROU”) assets or lease liabilities for these leases.

- changed (2020-05-05):
[0001193125-20-133708:note_history:28]
For periods prior to adoption of ASC 842, the Company is required to present disclosures in accordance with ASC Topic 840. Future minimum lease payments due under non-cancelable operating leases as of June 28, 2019 were as follows:
  (was, 2020-02-04, similarity 0.9977):
[0001193125-20-024258:note_history:28]
For periods prior to adoption of ASC 842, the Company is required to present disclosures in accordance with ASC Topic 840. 
F
uture minimum lease payments due under 
non-cancelable
 operating leases as of June 28, 2019 were as follows:

- changed (2020-05-05):
[0001193125-20-133708:note_history:29]
On June 29, 2019, the Company also adopted Accounting Standards Update (“ASU”) 
2017-12,
 “Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities.” ASU 
2017-12
 simplifies existing hedge accounting guidance in order to better portray the economic impact of risk management activities in the financial statements, including eliminating the separate measurement and presentation of hedge ineffectiveness. Prior to the adoption of ASU 
2017-12,
 the Company was required to separately measure and reflect the amount by which the hedging instrument did not offset the changes in the fair value or cash flows of hedged items, and to record the ineffective portion as earnings. Upon the adoption of ASU 
2017-12,
 the Company no longer recognizes hedge ineffectiveness as earnings, but instead records the entire changes in the fair value of the hedged instruments as other comprehensive income. Amounts recorded as other comprehensive income are subsequently reclassified to earnings in the same income statement line item that is used to present the earnings effect of the hedged item when the hedged item affects earnings. See Note 6 for further details.
  (was, 2020-02-04, similarity 0.9889):
[0001193125-20-024258:note_history:29]
On June 29, 2019, the Company also adopted Accounting Standards Update (“ASU”) 
2017-12,
 Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. ASU 
2017-12
 simplifies existing hedge accounting guidance in order to better portray in financial statements the economic impact of risk management activities in the financial statements, including eliminating the separate measurement and presentation of hedge ineffectiveness. Prior to the adoption of ASU 
2017-12,
 the Company was required to separately measure and reflect the amount by which the hedging instrument did not offset the changes in the fair value or cash flows of hedged items, and to record the ineffective portion as earnings. Upon the adoption of ASU 
2017-12,
 the Company no longer recognizes hedge ineffectiveness as earnings, but instead records the entire changes in the fair value of the hedged instruments as other comprehensive income. Amounts recorded as other comprehensive income are subsequently reclassified to earnings in the same income statement line item that is used to present the earnings effect of the hedged item when the hedged item affects earnings. See Note 6 for further details.

- added (2020-05-05):
[0001193125-20-133708:note_history:30]
In March 2020, the Financial Accounting Standards Board (“FASB”) issued ASU 
2020-04,
 “Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting,” which temporarily simplifies the accounting for contract modifications, including hedging relationships, due to the transition from LIBOR and other interbank offered rates to alternative reference interest rates. For example, entities can elect not to remeasure the contracts at the modification date or reassess a previous accounting determination if certain conditions are met. Additionally, entities can elect to continue applying hedge accounting for hedging relationships affected by reference rate reform if certain conditions are met. The new standard was effective upon issuance and generally can be applied to applicable contract modifications through December 31, 2022. This ASU was effective for the Company in the third quarter of fiscal 2020 with no impact to the Company’s unaudited condensed consolidated financial statements.

- added (2020-05-05):
[0001193125-20-133708:note_history:31]
In December 2019, the FASB issued ASU 
2019-12,
 “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.” The amendments in this update simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify U.S. GAAP for other areas of Topic 740 by clarifying and amending existing guidance. For public business entities, the amendments in this update are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2020. This ASU will be effective for the Company in the first quarter of fiscal 2022. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.

- changed (2020-05-05):
[0001193125-20-133708:note_history:32]
In August 2018, the FASB issued ASU 
2018-13,
 “Fair Value Measurement (Topic 820), Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement.” ASU 
2018-13
 is intended to improve the effectiveness of disclosures in the notes to the financial statements, including (1) the development of a framework that promotes consistent decisions by the FASB about disclosure requirements and (2) the appropriate exercise of discretion by reporting entities. The amendment modifies the disclosure requirements on transferring between level 1 and level 2 and valuation processes of level 3 fair value measurements. This update is effective for all entities for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. This ASU will be effective for the Company in the first quarter of fiscal 2021. The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.
  (was, 2020-02-04, similarity 0.7735):
[0001193125-20-024258:note_history:32]
In August 2018, the FASB issued ASU 
2018-13,
 “Fair Value Measurement (Topic 820), Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement.” ASU 
2018-13
 is intended to improve the effectiveness of disclosures in the notes to the financial statements, including (1) the development of a framework that promotes consistent decisions by the FASB about disclosure requirements and (2) the appropriate exercise of discretion by reporting entities. The amendment modifies the disclosure requirements on transferring between level 1 and level 2 and valuation processes of level 3 fair value measurements. This update is effective for all entities for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years, beginning after December 15, 2019. This ASU will be effective for the Company in the first quarter of fiscal 2021. The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.

- changed (2020-05-05):
[0001193125-20-133708:note_history:33]
In January 2017, the FASB issued ASU 
2017-04,
 “Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.” ASU 
2017-04
 modifies the concept of impairment assessment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. Public companies that are SEC filers should adopt the amendment for annual and any interim goodwill impairment tests in fiscal years beginning after December 15, 2019. Early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017. This ASU will be effective for the Company in the first quarter of fiscal 2021. The Company does not expect this update will impact its condensed consolidated financial statements.
  (was, 2020-02-04, similarity 0.9988):
[0001193125-20-024258:note_history:33]
In January 2017, the FASB issued ASU 
2017-04,
 “Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.” ASU 
2017-04
 modified the concept of impairment assessment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. Public companies that are SEC filers should adopt the amendment for annual and any interim goodwill impairment tests in fiscal years beginning after December 15, 2019. Early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017. This ASU will be effective for the Company in the first quarter of fiscal 2021. The Company does not expect this update will impact its condensed consolidated financial statements.

- added (2020-05-05):
[0001193125-20-133708:note_history:34]
In June 2016, the FASB issued ASU 
2016-13,
 “Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which establishes a new credit impairment model for financial assets measured at amortized cost and 
available-for-sale
 debt securities. The FASB issued subsequent amendments to Topic 326, including ASU 
2018-19, 
 ASU 
2019-04,
 ASU 
2019-05,
 ASU 
2019-11
 and ASU 
2020-02,
 which provided further

- changed (2020-05-05):
[0001193125-20-133708:note_history:35]
guidance and transition relief. For public business entities, this 
update 
is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. This ASU will be effective for the Company in the first quarter of fiscal 2021. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.
  (was, 2020-02-04, similarity 0.7097):
[0001193125-20-024258:note_history:35]
In April 2019, 
the 
FASB issued ASU 
2019-04,
 “Codification Improvements to Topic 326, Financial Instruments—Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments.” The amendments in ASU 
2019-04
 apply to all reporting entities within the scope of the affected accounting guidance. For public business entities, this update is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. This ASU will be effective for the Company in the first quarter of fiscal 2021. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.

- removed (2020-05-05):
[0001193125-20-024258:note_history:36]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued ASU 
2019-12,
 “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes
.
” The amendments in this Update simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify GAAP for other areas of Topic 740 by clarifying and amending existing guidance. For public business entities, the amendments in this update are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2020. This ASU will be effective for the Company in the first quarter of fiscal 2022. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.

- removed (2020-05-05):
[0001193125-20-024258:note_history:37]
In May 2019, 
the 
FASB issued ASU 
2019-05,
 “Financial Instruments – Credit Losses (Topic 326): Targeted Transition Relief
.
” The amendments in ASU 
2019-05
 provide entities that have certain instruments within the scope of Subtopic 
326-20
 (“Financial Instruments—Credit Losses—Measured at Amortized Cost”) with an option to irrevocably elect the fair value option in Subtopic 
825-10
 (“Financial Instruments—Overall”), applied on an 
instrument-by-instrument
 basis for eligible instruments, upon adoption of Topic 326. The fair value option election does not apply to 
held-to-maturity
 debt securities. An entity that elects the fair value option should subsequently apply the guidance in Subtopics 
820-10
 (“Fair Value Measurement—Overall”) and 
825-10.
 For public business entities, this update is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. This ASU will be effective for the Company in the first quarter of fiscal 2021. Early adoption is permitted. The Company 
is currently evaluating the i
mpact of the adoption of

- removed (2020-05-05):
[0001193125-20-024258:note_history:38]
this update

- removed (2020-05-05):
[0001193125-20-024258:note_history:39]
o
n

- removed (2020-05-05):
[0001193125-20-024258:note_history:40]
its condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-05):
[0001193125-20-133708:note_history:41]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  |  | Maturity |  |  | As of March 27, 2020 |  |  | As of June 28, 2019 |  |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  | $ | 12,188 |  |  | $ | 3,250 |  |
| Less: Unamortized debt issuance costs – current portion |  |  | (32 | ) |  |  | — |  |
| Long-term borrowings, current portion, net |  |  |  |  |  | $ | 12,156 |  |  | $ | 3,250 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1-month LIBOR +1.50% per annum (1) |  |  | Repayable in quarterly installments |  |  |  | June 2023 |  |  | $ | — |  |  | $ | 60,938 |  |
| 3-month LIBOR +1.35% per annum (1) |  |  | Repayable in quarterly installments |  |  |  | June 2024 |  |  |  | 54,844 |  |  |  | — |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (12,188 | ) |  |  | (3,250 | ) |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  |  |  | (103 | ) |  |  | — |  |
| Long-term borrowings, non-current portion, net |  |  |  |  |  | $ | 42,553 |  |  | $ | 57,688 |  |
  (was, 2020-02-04, similarity 0.9064):
[0001193125-20-024258:note_history:41]
| Rate |  | Conditions |  |  | Maturity |  |  | As of December 27, 2019 |  |  | As of June 28, 2019 |  |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  |  |  |  |  |  | $ | 12,188 |  |  | $ | 3,250 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  |  |  |  |  |  |  | (32 | ) |  |  | — |  |
| Long-term borrowings, current portion, net |  |  |  |  |  | $ | 12,156 |  |  |  | 3,250 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1-month LIBOR +1.50% per annum(1) |  |  | Repayable in quarterly installments |  |  |  | June 2023 |  |  | $ | — |  |  | $ | 60,938 |  |
| 3-month LIBOR +1.35% per annum(1) |  |  | Repayable in quarterly installments |  |  |  | June 2024 |  |  |  | 57,891 |  |  |  | — |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (12,188 | ) |  |  | (3,250 | ) |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  |  |  | (111 | ) |  |  | — |  |
| Long-term borrowings, non-current portion, net |  |  |  |  |  | $ | 45,592 |  |  | $ | 57,688 |  |

- changed (2020-05-05):
[0001193125-20-133708:note_history:42]
The movements of long-term borrowings for the nine months ended March 27, 2020 and March 29, 2019 were as follows:
  (was, 2020-02-04, similarity 0.892):
[0001193125-20-024258:note_history:42]
The movements of long-term borrowings for the six months ended December 27, 2019 and December 28, 2018 were as follows:

- changed (2020-05-05):
[0001193125-20-133708:note_history:43]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27, 2020 |  |  | March 29, 2019 |  |
| Opening balance |  | $ | 60,938 |  |  | $ | 64,188 |  |
| Borrowings during the period |  |  | 60,938 |  |  |  | — |  |
| Repayments during the period |  |  | (67,032 | ) |  |  | (2,438 | ) |
| Closing balance |  | $ | 54,844 |  |  | $ | 61,750 |  |
  (was, 2020-02-04, similarity 0.9043):
[0001193125-20-024258:note_history:43]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 27, 2019 |  |  | December 28, 2018 |  |
| Opening balance |  | $ | 60,938 |  |  | $ | 64,188 |  |
| Borrowings during the period |  |  | 60,938 |  |  |  | — |  |
| Repayments during the period |  |  | (63,985 | ) |  |  | (813 | ) |
| Closing balance |  | $ | 57,891 |  |  | $ | 63,375 |  |

- changed (2020-05-05):
[0001193125-20-133708:note_history:44]
As of March 27, 2020, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2020-02-04, similarity 0.9548):
[0001193125-20-024258:note_history:44]
As of December 27, 2019, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2020-05-05):
[0001193125-20-133708:note_history:45]
| (amount in thousands) |  |  |  |
| 2020 (remaining three months) |  | $ | 3,046 |  |
| 2021 |  |  | 12,188 |  |
| 2022 |  |  | 15,234 |  |
| 2023 |  |  | 12,188 |  |
| 2024 |  |  | 12,188 |  |
| Total |  | $ | 54,844 |  |
  (was, 2020-02-04, similarity 0.9748):
[0001193125-20-024258:note_history:45]
| (amount in thousands) |  |  |  |
| 2020 (remaining six months) |  | $ | 6,093 |  |
| 2021 |  |  | 12,188 |  |
| 2022 |  |  | 15,234 |  |
| 2023 |  |  | 12,188 |  |
| 2024 |  |  | 12,188 |  |
| Total |  | $ | 57,891 |  |

- changed (2020-05-05):
[0001193125-20-133708:note_history:46]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai 
b
aht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities.
  (was, 2020-02-04, similarity 0.7667):
[0001193125-20-024258:note_history:46]
entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai Baht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

- added (2020-05-05):
[0001193125-20-133708:note_history:47]
The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

- changed (2020-05-05):
[0001193125-20-133708:note_history:48]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a Term Loan Agreement pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million.
  (was, 2020-02-04, similarity 0.6867):
[0001193125-20-024258:note_history:48]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a Term Loan Agreement pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company’s 
pre-existing
 credit facility agreement between the Company and Bank of America, N.A.

- added (2020-05-05):
[0001193125-20-133708:note_history:49]
The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company’s previous credit facility agreement with Bank of America, N.A.

- changed (2020-05-05):
[0001193125-20-133708:note_history:50]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be 
re-borrowed.
  (was, 2020-02-04, similarity 0.8436):
[0001193125-20-024258:note_history:50]
The term loan accrues interest at 
3-month LIBOR plus 1.35% and is repayable in quarterly installments of $
3.0 million, commencing on September 30, 2019. The term loan 
will 
mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be 
re-borrowed. 
 During the six months ended December 27, 2019, the Company recorded $0.6 million of interest expense in connection with this term loan.

- added (2020-05-05):
[0001193125-20-133708:note_history:51]
During the three and nine months ended March 27, 2020, the Company recorded $0.5 million and $1.1 million, respectively, of interest expense in connection with this term loan.

- changed (2020-05-05):
[0001193125-20-133708:note_history:52]
Any borrowings under the Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.
  (was, 2020-02-04, similarity 0.998):
[0001193125-20-024258:note_history:52]
Any borrowings under the Credit Facility Agreement, including those borrowings under the Term Loan Agreement
,
 are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

- changed (2020-05-05):
[0001193125-20-133708:note_history:53]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt to equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. At March 27, 2020, the Company was in compliance with all of its covenants under the Term Loan Agreement.
  (was, 2020-02-04, similarity 0.9938):
[0001193125-20-024258:note_history:53]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt to equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. At December 27, 2019, the Company was in compliance with all of its covenants under the Term Loan Agreement.

- changed (2020-05-05):
[0001193125-20-133708:note_history:54]
At March 27, 2020, there was $54.8 million outstanding under the term loan.
  (was, 2020-02-04, similarity 0.9333):
[0001193125-20-024258:note_history:54]
At December 27, 2019, there was $57.9 million outstanding under the term loan.

- changed (2020-05-05):
[0001193125-20-133708:note_history:55]
From time to time, 
the Company
 amended the Bank of America Facility Agreement, before repaying all outstanding amounts under the agreement and terminating such agreement on September 10, 2019.
  (was, 2020-02-04, similarity 0.9697):
[0001193125-20-024258:note_history:55]
From time to time, we amended the Bank of America Facility Agreement, before repaying all outstanding amounts under the agreement and terminating such agreement on September 10, 2019.

- changed (2020-05-05):
[0001193125-20-133708:note_history:56]
The most recent amendment on June 4, 2018 (i) reduced the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) refinanced the outstanding amounts under the revolving loan and term loan facilities into a $65.0 million term loan which was to be repaid in quarterly installments through the maturity date of June 4, 2023, and (iii) reduced the interest rate margins and commitment fees. The term loan bore interest, at the Company’s option, at a rate per annum equal to a LIBOR rate plus a spread of 1.50% to 2.25%, or a base rate plus a spread of 0.50% to 1.25%. During the nine months ended March 27, 2020 and March 29, 2019, the Company recorded $0.5 million and $1.8 million, respectively, of interest expense in connection with this term loan.
  (was, 2020-02-04, similarity 0.9442):
[0001193125-20-024258:note_history:56]
The most recent amendment on June 4, 2018 (i) reduced the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) refinanced the outstanding amounts under the revolving loan and term loan facilities into a $65.0 million term loan which was to be repaid in quarterly installments through the maturity date of June 4, 2023
, 
and (iii) reduced the interest rate margins and commitment fees. The term loan bore interest, at the Company’s option, at a rate per annum equal to a LIBOR rate plus a spread of 1.50% to 2.25%, or a base rate plus a spread of 0.50% to 1.25%. During the six months ended December 27, 2019 and December 28, 2018, the Company recorded $0.5 million and $1.2 million, respectively, of interest expense in connection with this term loan.

- changed (2020-05-05):
[0001193125-20-133708:note_history:57]
On September 10, 2019, the Company fully repaid $61.0 million in principal, accrued interest and other fees under the agreement. The early termination of this agreement did not trigger any early termination fees. At March 27, 2020, there were no amounts outstanding under the Bank of America Facility Agreement. At June 28, 2019, there was $60.9 million 
outstanding 
under the Bank of America Facility Agreement, related to the term loan.
  (was, 2020-02-04, similarity 0.9843):
[0001193125-20-024258:note_history:57]
On September 10, 2019, the Company fully repaid $61.0 million in principal, accrued interest and other fees under the agreement. The early termination of this agreement did not trigger any early termination fees. At December 27, 2019, there were no amounts outstanding under the Bank of America Facility Agreement. At June 28, 2019, there was $60.9 million outstanding under the Bank of America Facility Agreement, related to the term loan.

- removed (2020-05-05):
[0001193125-20-024258:note_history:58]
| (amount in thousands) |

- removed (2020-05-05):
[0001193125-20-024258:note_history:59]
On August 20, 2019, Fabrinet Thailand (the “Borrower”), and

- removed (2020-05-05):
[0001193125-20-024258:note_history:60]
Bank of Ayudhya Public Company Limited (

- removed (2020-05-05):
[0001193125-20-024258:note_history:61]
the

- removed (2020-05-05):
[0001193125-20-024258:note_history:62]
“

- removed (2020-05-05):
[0001193125-20-024258:note_history:63]
Bank

- removed (2020-05-05):
[0001193125-20-024258:note_history:64]
”)


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-05):
[0001193125-20-133708:note_history:65]
The movements of long-term borrowings for the nine months ended March 27, 2020 and March 29, 2019 were as follows:
  (was, 2020-02-04, similarity 0.892):
[0001193125-20-024258:note_history:65]
The movements of long-term borrowings for the six months ended December 27, 2019 and December 28, 2018 were as follows:

- changed (2020-05-05):
[0001193125-20-133708:note_history:66]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27, 2020 |  |  | March 29, 2019 |  |
| Opening balance |  | $ | 60,938 |  |  | $ | 64,188 |  |
| Borrowings during the period |  |  | 60,938 |  |  |  | — |  |
| Repayments during the period |  |  | (67,032 | ) |  |  | (2,438 | ) |
| Closing balance |  | $ | 54,844 |  |  | $ | 61,750 |  |
  (was, 2020-02-04, similarity 0.9043):
[0001193125-20-024258:note_history:66]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 27, 2019 |  |  | December 28, 2018 |  |
| Opening balance |  | $ | 60,938 |  |  | $ | 64,188 |  |
| Borrowings during the period |  |  | 60,938 |  |  |  | — |  |
| Repayments during the period |  |  | (63,985 | ) |  |  | (813 | ) |
| Closing balance |  | $ | 57,891 |  |  | $ | 63,375 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-05):
[0001193125-20-133708:note_history:67]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  |  | Maturity |  |  | As of March 27, 2020 |  |  | As of June 28, 2019 |  |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  | $ | 12,188 |  |  | $ | 3,250 |  |
| Less: Unamortized debt issuance costs – current portion |  |  | (32 | ) |  |  | — |  |
| Long-term borrowings, current portion, net |  |  |  |  |  | $ | 12,156 |  |  | $ | 3,250 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1-month LIBOR +1.50% per annum (1) |  |  | Repayable in quarterly installments |  |  |  | June 2023 |  |  | $ | — |  |  | $ | 60,938 |  |
| 3-month LIBOR +1.35% per annum (1) |  |  | Repayable in quarterly installments |  |  |  | June 2024 |  |  |  | 54,844 |  |  |  | — |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (12,188 | ) |  |  | (3,250 | ) |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  |  |  | (103 | ) |  |  | — |  |
| Long-term borrowings, non-current portion, net |  |  |  |  |  | $ | 42,553 |  |  | $ | 57,688 |  |
  (was, 2020-02-04, similarity 0.9064):
[0001193125-20-024258:note_history:67]
| Rate |  | Conditions |  |  | Maturity |  |  | As of December 27, 2019 |  |  | As of June 28, 2019 |  |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  |  |  |  |  |  | $ | 12,188 |  |  | $ | 3,250 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  |  |  |  |  |  |  | (32 | ) |  |  | — |  |
| Long-term borrowings, current portion, net |  |  |  |  |  | $ | 12,156 |  |  |  | 3,250 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1-month LIBOR +1.50% per annum(1) |  |  | Repayable in quarterly installments |  |  |  | June 2023 |  |  | $ | — |  |  | $ | 60,938 |  |
| 3-month LIBOR +1.35% per annum(1) |  |  | Repayable in quarterly installments |  |  |  | June 2024 |  |  |  | 57,891 |  |  |  | — |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (12,188 | ) |  |  | (3,250 | ) |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  |  |  | (111 | ) |  |  | — |  |
| Long-term borrowings, non-current portion, net |  |  |  |  |  | $ | 45,592 |  |  | $ | 57,688 |  |

- removed (2020-05-05):
[0001193125-20-024258:note_history:68]
| (amount in thousands) |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-05):
[0001193125-20-133708:note_history:69]
As of March 27, 2020, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2020-02-04, similarity 0.9548):
[0001193125-20-024258:note_history:69]
As of December 27, 2019, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2020-05-05):
[0001193125-20-133708:note_history:70]
| (amount in thousands) |  |  |  |
| 2020 (remaining three months) |  | $ | 3,046 |  |
| 2021 |  |  | 12,188 |  |
| 2022 |  |  | 15,234 |  |
| 2023 |  |  | 12,188 |  |
| 2024 |  |  | 12,188 |  |
| Total |  | $ | 54,844 |  |
  (was, 2020-02-04, similarity 0.9748):
[0001193125-20-024258:note_history:70]
| (amount in thousands) |  |  |  |
| 2020 (remaining six months) |  | $ | 6,093 |  |
| 2021 |  |  | 12,188 |  |
| 2022 |  |  | 15,234 |  |
| 2023 |  |  | 12,188 |  |
| 2024 |  |  | 12,188 |  |
| Total |  | $ | 57,891 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-05):
[0001193125-20-133708:note_history:71]
The following tables present total revenues by geographic region
  (was, 2020-02-04, similarity 0.9846):
[0001193125-20-024258:note_history:71]
The following table
s
 present total revenues by geographic region:

- added (2020-05-05):
[0001193125-20-133708:note_history:72]
:

- changed (2020-05-05):
[0001193125-20-133708:note_history:73]
| (amount in thousands, except percentages) |  | Three Months Ended March 27, 2020 |  |  | As a % of Total Revenues |  |  | Nine Months Ended March 27, 2020 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 206,751 |  |  |  | 50.3 | % |  | $ | 631,096 |  |  |  | 51.0 | % |
| Asia-Pacific |  |  | 141,639 |  |  |  | 34.4 |  |  |  | 401,209 |  |  |  | 32.5 |  |
| Europe |  |  | 62,820 |  |  |  | 15.3 |  |  |  | 204,418 |  |  |  | 16.5 |  |
| Total |  | $ | 411,210 |  |  |  | 100.0 | % |  | $ | 1,236,723 |  |  |  | 100.0 | % |
  (was, 2020-02-04, similarity 0.8103):
[0001193125-20-024258:note_history:73]
| (amount in thousands, except percentages) |  | Three MonthsEnded December 27, 2019 |  |  | As a % of TotalRevenues |  |  | Six MonthsEnded December 27, 2019 |  |  | As a % of TotalRevenues |  |
| North America |  | $ | 223,398 |  |  |  | 52.4 | % |  | $ | 424,345 |  |  |  | 51.4 | % |
| Asia-Pacific |  |  | 141,147 |  |  |  | 33.1 |  |  |  | 259,570 |  |  |  | 31.4 |  |
| Europe |  |  | 61,672 |  |  |  | 14.5 |  |  |  | 141,598 |  |  |  | 17.2 |  |
| Total |  | $ | 426,217 |  |  |  | 100.0 | % |  | $ | 825,513 |  |  |  | 100.0 | % |

- changed (2020-05-05):
[0001193125-20-133708:note_history:74]
| (amount in thousands, except percentages) |  | Three Months Ended March 29, 2019 |  |  | As a % of Total Revenues |  |  | Nine Months Ended March 29, 2019 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 195,504 |  |  |  | 49.0 | % |  | $ | 558,028 |  |  |  | 47.3 | % |
| Asia-Pacific |  |  | 151,263 |  |  |  | 37.9 |  |  |  | 469,921 |  |  |  | 39.9 |  |
| Europe |  |  | 52,184 |  |  |  | 13.1 |  |  |  | 151,259 |  |  |  | 12.8 |  |
| Total |  | $ | 398,951 |  |  |  | 100.0 | % |  | $ | 1,179,208 |  |  |  | 100.0 | % |
  (was, 2020-02-04, similarity 0.8103):
[0001193125-20-024258:note_history:74]
| (amount in thousands, except percentages) |  | Three MonthsEnded December 28, 2018 |  |  | As a % of TotalRevenues |  |  | Six MonthsEnded December 28, 2018 |  |  | As a % of TotalRevenues |  |
| North America |  | $ | 182,698 |  |  |  | 45.3 | % |  | $ | 362,524 |  |  |  | 46.5 | % |
| Asia-Pacific |  |  | 166,711 |  |  |  | 41.4 |  |  |  | 318,658 |  |  |  | 40.8 |  |
| Europe |  |  | 53,671 |  |  |  | 13.3 |  |  |  | 99,075 |  |  |  | 12.7 |  |
| Total |  | $ | 403,080 |  |  |  | 100.0 | % |  | $ | 780,257 |  |  |  | 100.0 | % |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-05):
[0001193125-20-133708:note_history:75]
The Company derives revenues primarily from the assembly of products under supply agreements with its customers and the fabrication of customized optics and glass. The Company recognizes revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the Company expects to be entitled in exchange for such goods or services. In order to meet this requirement, the Company applies the following five steps: (1) identify the contract with a customer, (2) identify the performance obligations under the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations under the contract, and (5) recognize revenue when a performance obligation is satisfied. Revenue is recognized net of any taxes collected from customers, which is subsequently remitted to governmental authorities.
  (was, 2020-02-04, similarity 0.9968):
[0001193125-20-024258:note_history:75]
The Company derives total revenues primarily from the assembly of products under supply agreements with its customers and the fabrication of customized optics and glass. The Company recognizes revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the Company expects to be entitled in exchange for such goods or services. In order to meet this requirement, the Company applies the following five steps: (1) identify the contract with a customer, (2) identify the performance obligations under the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations under the contract, and (5) recognize revenue when a performance obligation is satisfied. Revenue is recognized net of any taxes collected from customers, which is subsequently remitted to governmental authorities.

- changed (2020-05-05):
[0001193125-20-133708:note_history:76]
A performance obligation is a contractual promise to transfer a distinct good or service to the customer. In contracts with multiple performance obligations, the Company identifies each performance obligation and evaluates whether the performance obligation is distinct within the context of the contract at contract inception. The majority of the Company’s contracts have a single performance obligation, as the promise to transfer the individual goods or services is not separately identifiable from other promises under the contracts and, therefore, is not distinct.
  (was, 2020-02-04, similarity 0.7458):
[0001193125-20-024258:note_history:76]
A performance obligation is a contractual promise to transfer a distinct good or service to the customer. In contracts with multiple performance obligations, the Company identifies each performance obligation and evaluates whether the performance obligation is distinct within the context of the contract at contract inception. The majority of the Company’s contracts have a single performance obligation as the promise to transfer the individual goods or services is not separately identifiable from other promises under the contracts and, therefore, is not distinct.

- changed (2020-05-05):
[0001193125-20-133708:note_history:77]
The Company manufactures products that are customized to customers’ specifications. However, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for recognizing revenue over time are not met. Based on a review of its contracts, the Company determined that it does not have contractual rights to bill profit for work in progress in the event of a contract termination, an event which is expected to be infrequent. Further, in limited circumstances, substantive acceptance by the customer will result in the deferral of revenue until acceptance is formally received from the customer. Judgment may be required in determining if the acceptance clause provides for substantive acceptance.
  (was, 2020-02-04, similarity 0.6171):
[0001193125-20-024258:note_history:77]
The Company manufactures products that are customized to customers’ specifications, however, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for recognizing revenue over time are not met. On the evaluation of the contracts the Company determined that it did not have contractual rights to bill profit for work in progress in the event of a contract termination, an event which is expected to be infrequent. Further, in limited circumstances, substantive acceptance by the customer will result in the deferral of revenue until acceptance is formally received from the customer. Judgment may be required in determining if the acceptance clause provides for substantive acceptance.

- added (2020-05-05):
[0001193125-20-133708:note_history:78]
Certain customers may request the Company to store finished products purchased by them at the Company’s warehouse. In these instances, the Company receives a written request from the customer asking the Company to hold the inventory at the Company’s warehouse, and the ordered goods cannot be used to fulfill other customer orders. In these situations, revenue is only recognized when the goods are completed and ready for shipment and transferred to the Company’s warehouse.

- added (2020-05-05):
[0001193125-20-133708:note_history:79]
The Company has applied the practical expedient to not adjust the amount of revenue to be recognized due to the effects of a significant financing component when the Company expects, at contract inception, that the period between the transfer of goods and/or services and the payment for those goods and/or services will be less than one year.

- changed (2020-05-05):
[0001193125-20-133708:note_history:80]
Provisions for estimated expenses relating to pr
o
duct warranties are made at the time the products are sold using historical experience. Generally, this warranty is limited to workmanship, and the Company’s liability is capped at the price of the product. The provisions will be adjusted when experience indicates an expected settlement will differ from initial estimates.
  (was, 2020-02-04, similarity 0.9933):
[0001193125-20-024258:note_history:80]
Provisions for estimated expenses relating to product warranties are made at the time the products are sold using historical experience. Generally, this warranty is limited to workmanship and the Company’s liability is capped at the price of the product. The provisions will be adjusted when experience indicates an expected settlement will differ from initial estimates.

- changed (2020-05-05):
[0001193125-20-133708:note_history:81]
A contract asset is recognized when the Company has recognized revenues prior to generating an invoice for payment. Contract assets are classified separately within the unaudited condensed consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. During the nine months ended March 27, 2020, the Company had no impairment for contract assets recognized.
  (was, 2020-02-04, similarity 0.9322):
[0001193125-20-024258:note_history:81]
A contract asset is recognized when the Company​​​​​​​ has recognized revenues prior to generating an invoice for payment. Contract assets are classified separately within the unaudited condensed consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. During the six months ended December 27, 2019, the Company had no impairment for contract assets recognized.

- changed (2020-05-05):
[0001193125-20-133708:note_history:82]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the nine months ended March 27, 2020:
  (was, 2020-02-04, similarity 0.8872):
[0001193125-20-024258:note_history:82]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the 
six

- changed (2020-05-05):
[0001193125-20-133708:note_history:83]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 28, 2019 |  | $ | 12,447 |  |
| Revenue recognized |  |  | 58,037 |  |
| Amounts collected or invoiced |  |  | (54,071 | ) |
| Ending balance, March 27, 2020 |  | $ | 16,413 |  |
  (was, 2020-02-04, similarity 0.9744):
[0001193125-20-024258:note_history:83]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 28, 2019 |  | $ | 12,447 |  |
| Revenue recognized |  |  | 39,093 |  |
| Amounts collected or invoiced |  |  | (40,426 | ) |
| Ending balance, December 27, 2019 |  | $ | 11,114 |  |

- changed (2020-05-05):
[0001193125-20-133708:note_history:84]
| (amount in thousands) |  | Contract Liabilities |  |
| Beginning balance, June 28, 2019 |  | $ | 2,239 |  |
| Advance payment received during the period |  |  | 6,857 |  |
| Revenue recognized |  |  | (7,155 | ) |
| Ending balance, March 27, 2020 |  | $ | 1,941 |  |
  (was, 2020-02-04, similarity 0.9763):
[0001193125-20-024258:note_history:84]
| (amount in thousands) |  | Contract Liabilities |  |
| Beginning balance, June 28, 2019 |  | $ | 2,239 |  |
| Advance payment received during the period |  |  | 3,336 |  |
| Revenue recognized |  |  | (3,215 | ) |
| Ending balance, December 27, 2019 |  | $ | 2,360 |  |

- changed (2020-05-05):
[0001193125-20-133708:note_history:85]
The incremental costs of obtaining a contract with a customer are recognized as an asset (not expensed as incurred) if such costs are expected to be recovered. Incremental costs of obtaining a contract are costs that the Company would not have incurred if the contract had not been obtained (e.g., sales commissions or similar incentive payments linked directly to new or modified customer contracts). Costs that would have been incurred regardless of whether a customer contract was obtained (e.g., costs of pursuing the contact, legal advice, etc.) are expensed as incurred, unless such costs are explicitly chargeable to the customer. During the nine months ended
  (was, 2020-02-04, similarity 0.953):
[0001193125-20-024258:note_history:85]
Consistent with the guidance in ASC 
340-40-25-1,
 the incremental costs of obtaining a contract with a customer are recognized as an asset (not expensed as incurred) if such costs are expected to be recovered. Incremental costs of obtaining a contract are costs that the Company would not have incurred if the contract had not been obtained (e.g., sales commissions or similar incentive payments linked directly to new or modified customer contracts). Costs that would have been incurred regardless of whether a customer contract was obtained (e.g., costs of pursuing the contact, legal advice, etc.) are expensed as incurred, unless such costs are explicitly chargeable to the customer. During the 
six

- changed (2020-05-05):
[0001193125-20-133708:note_history:86]
March 27, 2020, the Company did not have any incremental costs of obtaining a contract.
  (was, 2020-02-04, similarity 0.9123):
[0001193125-20-024258:note_history:86]
ended December 27, 2019, the Company did not have any incremental costs of obtaining a contract.

- changed (2020-05-05):
[0001193125-20-133708:note_history:87]
Shipping and handling
  (was, 2020-02-04, similarity 0.8571):
[0001193125-20-024258:note_history:87]
Shipping and Handling​​​​​​​

- changed (2020-05-05):
[0001193125-20-133708:note_history:88]
Revenue by geographic area
  (was, 2020-02-04, similarity 0.8814):
[0001193125-20-024258:note_history:88]
Revenue by Geographic ​​​​​​​Area

- changed (2020-05-05):
[0001193125-20-133708:note_history:89]
Total revenues are attributed to a particular geographic area based on the
 bill-to-location
 of the Company’s customers. The Company operates in three geographic regions: North America, Asia-Pacific and Europe.
  (was, 2020-02-04, similarity 0.8619):
[0001193125-20-024258:note_history:89]
Total revenues are attributed to a particular geographic area based on the
 bill-to-location
 of the Company’s customers. The Company operates in three geographic regions: North America, Asia-Pacific and Europe. The following table
s
 present total revenues by geographic region:

- changed (2020-05-05):
[0001193125-20-133708:note_history:90]
The following tables present total revenues by geographic region
  (was, 2020-02-04, similarity 0.6935):
[0001193125-20-024258:note_history:90]
The following table
s
 set forth our revenues by end market
:

- added (2020-05-05):
[0001193125-20-133708:note_history:91]
:

- changed (2020-05-05):
[0001193125-20-133708:note_history:92]
| (amount in thousands, except percentages) |  | Three Months Ended March 27, 2020 |  |  | As a % of Total Revenues |  |  | Nine Months Ended March 27, 2020 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 206,751 |  |  |  | 50.3 | % |  | $ | 631,096 |  |  |  | 51.0 | % |
| Asia-Pacific |  |  | 141,639 |  |  |  | 34.4 |  |  |  | 401,209 |  |  |  | 32.5 |  |
| Europe |  |  | 62,820 |  |  |  | 15.3 |  |  |  | 204,418 |  |  |  | 16.5 |  |
| Total |  | $ | 411,210 |  |  |  | 100.0 | % |  | $ | 1,236,723 |  |  |  | 100.0 | % |
  (was, 2020-02-04, similarity 0.8103):
[0001193125-20-024258:note_history:92]
| (amount in thousands, except percentages) |  | Three MonthsEnded December 27, 2019 |  |  | As a % of TotalRevenues |  |  | Six MonthsEnded December 27, 2019 |  |  | As a % of TotalRevenues |  |
| North America |  | $ | 223,398 |  |  |  | 52.4 | % |  | $ | 424,345 |  |  |  | 51.4 | % |
| Asia-Pacific |  |  | 141,147 |  |  |  | 33.1 |  |  |  | 259,570 |  |  |  | 31.4 |  |
| Europe |  |  | 61,672 |  |  |  | 14.5 |  |  |  | 141,598 |  |  |  | 17.2 |  |
| Total |  | $ | 426,217 |  |  |  | 100.0 | % |  | $ | 825,513 |  |  |  | 100.0 | % |

- changed (2020-05-05):
[0001193125-20-133708:note_history:93]
| (amount in thousands, except percentages) |  | Three Months Ended March 29, 2019 |  |  | As a % of Total Revenues |  |  | Nine Months Ended March 29, 2019 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 195,504 |  |  |  | 49.0 | % |  | $ | 558,028 |  |  |  | 47.3 | % |
| Asia-Pacific |  |  | 151,263 |  |  |  | 37.9 |  |  |  | 469,921 |  |  |  | 39.9 |  |
| Europe |  |  | 52,184 |  |  |  | 13.1 |  |  |  | 151,259 |  |  |  | 12.8 |  |
| Total |  | $ | 398,951 |  |  |  | 100.0 | % |  | $ | 1,179,208 |  |  |  | 100.0 | % |
  (was, 2020-02-04, similarity 0.8103):
[0001193125-20-024258:note_history:93]
| (amount in thousands, except percentages) |  | Three MonthsEnded December 28, 2018 |  |  | As a % of TotalRevenues |  |  | Six MonthsEnded December 28, 2018 |  |  | As a % of TotalRevenues |  |
| North America |  | $ | 182,698 |  |  |  | 45.3 | % |  | $ | 362,524 |  |  |  | 46.5 | % |
| Asia-Pacific |  |  | 166,711 |  |  |  | 41.4 |  |  |  | 318,658 |  |  |  | 40.8 |  |
| Europe |  |  | 53,671 |  |  |  | 13.3 |  |  |  | 99,075 |  |  |  | 12.7 |  |
| Total |  | $ | 403,080 |  |  |  | 100.0 | % |  | $ | 780,257 |  |  |  | 100.0 | % |

- added (2020-05-05):
[0001193125-20-133708:note_history:94]
The following tables set forth our revenues by end market:

- changed (2020-05-05):
[0001193125-20-133708:note_history:95]
| (amount in thousands, except percentages) |  | Three Months Ended March 27, 2020 |  |  | As a % of Total Revenues |  |  | Nine Months Ended March 27, 2020 |  |  | As a % of Total Revenues |  |
| Optical communications |  | $ | 308,566 |  |  |  | 75.0 | % |  | $ | 933,013 |  |  |  | 75.4 | % |
| Lasers, sensors and other |  |  | 102,644 |  |  |  | 25.0 |  |  |  | 303,710 |  |  |  | 24.6 |  |
| Total |  | $ | 411,210 |  |  |  | 100.0 | % |  | $ | 1,236,723 |  |  |  | 100.0 | % |
  (was, 2020-02-04, similarity 0.9012):
[0001193125-20-024258:note_history:95]
| (amount in thousands, except percentages) |  | Three MonthsEnded December 27, 2019 |  |  | As a % of TotalRevenues |  |  | Six MonthsEnded December 27, 2019 |  |  | As a % of TotalRevenues |  |
| Optical communications |  | $ | 322,068 |  |  |  | 75.6 | % |  | $ | 624,447 |  |  |  | 75.6 | % |
| Lasers, sensors and other |  |  | 104,149 |  |  |  | 24.4 |  |  |  | 201,066 |  |  |  | 24.4 |  |
| Total |  | $ | 426,217 |  |  |  | 100.0 | % |  | $ | 825,513 |  |  |  | 100.0 | % |

- changed (2020-05-05):
[0001193125-20-133708:note_history:96]
| (amount in thousands, except percentages) |  | Three Months Ended March 29, 2019 |  |  | As a % of Total Revenues |  |  | Nine Months Ended March 29, 2019 |  |  | As a % of Total Revenues |  |
| Optical communications |  | $ | 298,139 |  |  |  | 74.7 | % |  | $ | 884,454 |  |  |  | 75.0 | % |
| Lasers, sensors and other |  |  | 100,812 |  |  |  | 25.3 |  |  |  | 294,754 |  |  |  | 25.0 |  |
| Total |  | $ | 398,951 |  |  |  | 100.0 | % |  | $ | 1,179,208 |  |  |  | 100.0 | % |
  (was, 2020-02-04, similarity 0.9012):
[0001193125-20-024258:note_history:96]
| (amount in thousands, except percentages) |  | Three MonthsEnded December 28, 2018 |  |  | As a % of TotalRevenues |  |  | Six MonthsEnded December 28, 2018 |  |  | As a % of TotalRevenues |  |
| Optical communications |  | $ | 305,547 |  |  |  | 75.8 | % |  | $ | 586,315 |  |  |  | 75.1 | % |
| Lasers, sensors and other |  |  | 97,533 |  |  |  | 24.2 |  |  |  | 193,942 |  |  |  | 24.9 |  |
| Total |  | $ | 403,080 |  |  |  | 100.0 | % |  | $ | 780,257 |  |  |  | 100.0 | % |

- removed (2020-05-05):
[0001193125-20-024258:note_history:97]
Certain customers may request the Company to store finished products purchased by them at the Company’s warehouse. In these instances, the Company receives a written request from the customer asking the Company to hold the inventory at the Company’s warehouse and the ordered goods cannot be used to fulfill other customer orders. In these situations, revenue is only recognized when the goods are completed and ready for shipment and transferred to the Company’s warehouse.

- removed (2020-05-05):
[0001193125-20-024258:note_history:98]
month
s

- removed (2020-05-05):
[0001193125-20-024258:note_history:99]
ended December 27, 2019:

- removed (2020-05-05):
[0001193125-20-024258:note_history:100]
month
s


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2020-05-05):
[0001193125-20-133708:note_history:101]
| 21. | Subsequent events |

- added (2020-05-05):
[0001193125-20-133708:note_history:102]
The outbreak of a novel strain of coronavirus 
(“COVID-19”)
 was recognized as a pandemic by the World Health Organization on March 11, 2020. The outbreak has spread globally, including to Thailand, the United States, UK and Europe.

- added (2020-05-05):
[0001193125-20-133708:note_history:103]
The implications of 
COVID-19
 on the Company’s business remain uncertain. Measures taken by governmental authorities and private actors to limit the spread of 
COVID-19
 may interfere with the ability of the Company’s employees, suppliers and other business providers to carry out their assigned tasks or supply materials at ordinary levels of performance. While the Company’s operations are impacted as a result of this pandemic, the Company has not experienced a direct, materially adverse financial impact. The future impact of this pandemic on the Company’s business, financial condition, results of operations and cash flows cannot be predicted. The Company continues to monitor developments with the spread of 
COVID-19,
 actions taken by governmental authorities and private actors, and impacts to the Company’s suppliers and customers. The Company continues to work to minimize disruptions to its supply chain and manufacturing capabilities, and to ensure the safety of its employees. While the Company’s operations are impacted as a result of this pandemic, including as a result of restrictions on employees’ ability to travel and requirements that portions of the Company’s workforce work from home, the Company has not experienced a direct, materially adverse financial impact.

- added (2020-05-05):
[0001193125-20-133708:note_history:104]
The Company is not currently aware of any business interruption or loss contingencies related to 
COVID-19
 that would require recognition in the third quarter of fiscal 2020.
