# FN notes — 0001193125-20-133708


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-20-133708:notes:1]
[same as prior period, unchanged from 0001193125-20-024258:notes:1]

[0001193125-20-133708:notes:2]
[same as prior period, unchanged from 0001193125-20-024258:notes:2]

[0001193125-20-133708:notes:3]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of March 27, 2020 and for the three and nine months ended March 27, 2020 and March 29, 2019 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 
10-K
 for the year ended June 28, 2019.

[0001193125-20-133708:notes:4]
[same as prior period, unchanged from 0001193125-20-024258:notes:4]

[0001193125-20-133708:notes:5]
The results for the three and nine months ended March 27, 2020 may not be indicative of results for the year ending June 26, 2020 or any future periods.

[0001193125-20-133708:notes:6]
Use of 
e
stimates

[0001193125-20-133708:notes:7]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements, and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisitions, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information.

[0001193125-20-133708:notes:8]
[same as prior period, unchanged from 0001193125-20-024258:notes:8]

[0001193125-20-133708:notes:9]
The Company utilizes a 
52
 to 
53
-

[0001193125-20-133708:notes:10]
week fiscal year ending on the Friday in June closest to June 30. The three months ended March 27, 2020 and March 29, 2019 each consisted of 13 weeks. The nine months ended March 27, 2020 and March 29, 2019 each consisted of 39 weeks. Fiscal year 2020 will be comprised of 52 weeks and will end on June 26, 2020.

[0001193125-20-133708:notes:11]
Reclassifications

[0001193125-20-133708:notes:12]
For presentation purposes, certain prior period amounts have been reclassified to conform to the current period presentation. These reclassifications do not affect the Company’s net income, cash flows or stockholders’ equity.

[0001193125-20-133708:notes:13]
Changes in 
a
ccounting 
p
olicies

[0001193125-20-133708:notes:14]
Except for the adoption of the new lease accounting standard and the derivatives and hedging standard described below, the Company has consistently applied 
its
 accounting policies to all periods presented in these unaudited condensed consolidated financial statements.

[0001193125-20-133708:notes:15]
C
oncentration of credit risk

[0001193125-20-133708:notes:16]
[same as prior period, unchanged from 0001193125-20-024258:notes:19]

[0001193125-20-133708:notes:17]
[same as prior period, unchanged from 0001193125-20-024258:notes:20]

[0001193125-20-133708:notes:18]
The Company enters into derivative contracts with financial 
institutions 
with 
reputable 
credit and monitors the credit profiles of these counterparties.

[0001193125-20-133708:notes:19]
[same as prior period, unchanged from 0001193125-20-024258:notes:22]

[0001193125-20-133708:notes:20]
Adoption of new accounting standards

[0001193125-20-133708:notes:21]
On June 29, 2019, the Company adopted the new lease accounting standard, Accounting Standards Codification (“ASC”) Topic 842, which provides guidance for the recognition and disclosure of lease arrangements. The Company adopted ASC 842 using the modified retrospective transition approach. Accordingly, the Company’s comparative financial statements as of June 28, 2019 have not been adjusted. ASC 842 also provides practical expedients for the Company’s ongoing accounting. The Company elected the short-term lease recognition exemption for its operating leases with a term of less than 12 months, which will not require recognition of right of use (“ROU”) assets or lease liabilities for these leases.

[0001193125-20-133708:notes:22]
For periods prior to adoption of ASC 842, the Company is required to present disclosures in accordance with ASC Topic 840. Future minimum lease payments due under non-cancelable operating leases as of June 28, 2019 were as follows:

[0001193125-20-133708:notes:23]
[same as prior period, unchanged from 0001193125-20-024258:notes:15]

[0001193125-20-133708:notes:24]
The most significant impact of the adoption of ASC 842 was the recognition of ROU assets and lease liabilities for operating leases with a term of greater than 12 months, while the accounting for finance leases will remain substantially unchanged. See Note 11 for further details.

[0001193125-20-133708:notes:25]
On June 29, 2019, the Company also adopted Accounting Standards Update (“ASU”) 
2017-12,
 “Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities.” ASU 
2017-12
 simplifies existing hedge accounting guidance in order to better portray the economic impact of risk management activities in the financial statements, including eliminating the separate measurement and presentation of hedge ineffectiveness. Prior to the adoption of ASU 
2017-12,
 the Company was required to separately measure and reflect the amount by which the hedging instrument did not offset the changes in the fair value or cash flows of hedged items, and to record the ineffective portion as earnings. Upon the adoption of ASU 
2017-12,
 the Company no longer recognizes hedge ineffectiveness as earnings, but instead records the entire changes in the fair value of the hedged instruments as other comprehensive income. Amounts recorded as other comprehensive income are subsequently reclassified to earnings in the same income statement line item that is used to present the earnings effect of the hedged item when the hedged item affects earnings. See Note 6 for further details.

[0001193125-20-133708:notes:26]
In March 2020, the Financial Accounting Standards Board (“FASB”) issued ASU 
2020-04,
 “Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting,” which temporarily simplifies the accounting for contract modifications, including hedging relationships, due to the transition from LIBOR and other interbank offered rates to alternative reference interest rates. For example, entities can elect not to remeasure the contracts at the modification date or reassess a previous accounting determination if certain conditions are met. Additionally, entities can elect to continue applying hedge accounting for hedging relationships affected by reference rate reform if certain conditions are met. The new standard was effective upon issuance and generally can be applied to applicable contract modifications through December 31, 2022. This ASU was effective for the Company in the third quarter of fiscal 2020 with no impact to the Company’s unaudited condensed consolidated financial statements.

[0001193125-20-133708:notes:27]
New accounting pronouncements – not yet adopted by the Company

[0001193125-20-133708:notes:28]
In December 2019, the FASB issued ASU 
2019-12,
 “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.” The amendments in this update simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify U.S. GAAP for other areas of Topic 740 by clarifying and amending existing guidance. For public business entities, the amendments in this update are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2020. This ASU will be effective for the Company in the first quarter of fiscal 2022. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.

[0001193125-20-133708:notes:29]
In August 2018, the FASB issued ASU 
2018-13,
 “Fair Value Measurement (Topic 820), Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement.” ASU 
2018-13
 is intended to improve the effectiveness of disclosures in the notes to the financial statements, including (1) the development of a framework that promotes consistent decisions by the FASB about disclosure requirements and (2) the appropriate exercise of discretion by reporting entities. The amendment modifies the disclosure requirements on transferring between level 1 and level 2 and valuation processes of level 3 fair value measurements. This update is effective for all entities for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. This ASU will be effective for the Company in the first quarter of fiscal 2021. The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.

[0001193125-20-133708:notes:30]
In January 2017, the FASB issued ASU 
2017-04,
 “Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.” ASU 
2017-04
 modifies the concept of impairment assessment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. Public companies that are SEC filers should adopt the amendment for annual and any interim goodwill impairment tests in fiscal years beginning after December 15, 2019. Early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017. This ASU will be effective for the Company in the first quarter of fiscal 2021. The Company does not expect this update will impact its condensed consolidated financial statements.

[0001193125-20-133708:notes:31]
In June 2016, the FASB issued ASU 
2016-13,
 “Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which establishes a new credit impairment model for financial assets measured at amortized cost and 
available-for-sale
 debt securities. The FASB issued subsequent amendments to Topic 326, including ASU 
2018-19, 
 ASU 
2019-04,
 ASU 
2019-05,
 ASU 
2019-11
 and ASU 
2020-02,
 which provided further

[0001193125-20-133708:notes:32]
guidance and transition relief. For public business entities, this 
update 
is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. This ASU will be effective for the Company in the first quarter of fiscal 2021. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001193125-20-133708:notes:33]
[same as prior period, unchanged from 0001193125-20-024258:notes:32]

[0001193125-20-133708:notes:34]
The Company derives revenues primarily from the assembly of products under supply agreements with its customers and the fabrication of customized optics and glass. The Company recognizes revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the Company expects to be entitled in exchange for such goods or services. In order to meet this requirement, the Company applies the following five steps: (1) identify the contract with a customer, (2) identify the performance obligations under the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations under the contract, and (5) recognize revenue when a performance obligation is satisfied. Revenue is recognized net of any taxes collected from customers, which is subsequently remitted to governmental authorities.

[0001193125-20-133708:notes:35]
A performance obligation is a contractual promise to transfer a distinct good or service to the customer. In contracts with multiple performance obligations, the Company identifies each performance obligation and evaluates whether the performance obligation is distinct within the context of the contract at contract inception. The majority of the Company’s contracts have a single performance obligation, as the promise to transfer the individual goods or services is not separately identifiable from other promises under the contracts and, therefore, is not distinct.

[0001193125-20-133708:notes:36]
The Company manufactures products that are customized to customers’ specifications. However, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for recognizing revenue over time are not met. Based on a review of its contracts, the Company determined that it does not have contractual rights to bill profit for work in progress in the event of a contract termination, an event which is expected to be infrequent. Further, in limited circumstances, substantive acceptance by the customer will result in the deferral of revenue until acceptance is formally received from the customer. Judgment may be required in determining if the acceptance clause provides for substantive acceptance.

[0001193125-20-133708:notes:37]
Certain customers may request the Company to store finished products purchased by them at the Company’s warehouse. In these instances, the Company receives a written request from the customer asking the Company to hold the inventory at the Company’s warehouse, and the ordered goods cannot be used to fulfill other customer orders. In these situations, revenue is only recognized when the goods are completed and ready for shipment and transferred to the Company’s warehouse.

[0001193125-20-133708:notes:38]
[same as prior period, unchanged from 0001193125-20-024258:notes:37]

[0001193125-20-133708:notes:39]
[same as prior period, unchanged from 0001193125-20-024258:notes:38]

[0001193125-20-133708:notes:40]
The Company has applied the practical expedient to not adjust the amount of revenue to be recognized due to the effects of a significant financing component when the Company expects, at contract inception, that the period between the transfer of goods and/or services and the payment for those goods and/or services will be less than one year.

[0001193125-20-133708:notes:41]
[same as prior period, unchanged from 0001193125-20-024258:notes:39]

[0001193125-20-133708:notes:42]
Provisions for estimated expenses relating to pr
o
duct warranties are made at the time the products are sold using historical experience. Generally, this warranty is limited to workmanship, and the Company’s liability is capped at the price of the product. The provisions will be adjusted when experience indicates an expected settlement will differ from initial estimates.

[0001193125-20-133708:notes:43]
Contract assets and liabilities

[0001193125-20-133708:notes:44]
A contract asset is recognized when the Company has recognized revenues prior to generating an invoice for payment. Contract assets are classified separately within the unaudited condensed consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. During the nine months ended March 27, 2020, the Company had no impairment for contract assets recognized.

[0001193125-20-133708:notes:45]
[same as prior period, unchanged from 0001193125-20-024258:notes:43]

[0001193125-20-133708:notes:46]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the nine months ended March 27, 2020:

[0001193125-20-133708:notes:47]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 28, 2019 |  | $ | 12,447 |  |
| Revenue recognized |  |  | 58,037 |  |
| Amounts collected or invoiced |  |  | (54,071 | ) |
| Ending balance, March 27, 2020 |  | $ | 16,413 |  |

[0001193125-20-133708:notes:48]
| (amount in thousands) |  | Contract Liabilities |  |
| Beginning balance, June 28, 2019 |  | $ | 2,239 |  |
| Advance payment received during the period |  |  | 6,857 |  |
| Revenue recognized |  |  | (7,155 | ) |
| Ending balance, March 27, 2020 |  | $ | 1,941 |  |

[0001193125-20-133708:notes:49]
Contract costs

[0001193125-20-133708:notes:50]
The incremental costs of obtaining a contract with a customer are recognized as an asset (not expensed as incurred) if such costs are expected to be recovered. Incremental costs of obtaining a contract are costs that the Company would not have incurred if the contract had not been obtained (e.g., sales commissions or similar incentive payments linked directly to new or modified customer contracts). Costs that would have been incurred regardless of whether a customer contract was obtained (e.g., costs of pursuing the contact, legal advice, etc.) are expensed as incurred, unless such costs are explicitly chargeable to the customer. During the nine months ended

[0001193125-20-133708:notes:51]
March 27, 2020, the Company did not have any incremental costs of obtaining a contract.

[0001193125-20-133708:notes:52]
Shipping and handling

[0001193125-20-133708:notes:53]
[same as prior period, unchanged from 0001193125-20-024258:notes:53]

[0001193125-20-133708:notes:54]
Revenue by geographic area

[0001193125-20-133708:notes:55]
Total revenues are attributed to a particular geographic area based on the
 bill-to-location
 of the Company’s customers. The Company operates in three geographic regions: North America, Asia-Pacific and Europe.

[0001193125-20-133708:notes:56]
The following tables present total revenues by geographic region

[0001193125-20-133708:notes:57]
:

[0001193125-20-133708:notes:58]
| (amount in thousands, except percentages) |  | Three Months Ended March 27, 2020 |  |  | As a % of Total Revenues |  |  | Nine Months Ended March 27, 2020 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 206,751 |  |  |  | 50.3 | % |  | $ | 631,096 |  |  |  | 51.0 | % |
| Asia-Pacific |  |  | 141,639 |  |  |  | 34.4 |  |  |  | 401,209 |  |  |  | 32.5 |  |
| Europe |  |  | 62,820 |  |  |  | 15.3 |  |  |  | 204,418 |  |  |  | 16.5 |  |
| Total |  | $ | 411,210 |  |  |  | 100.0 | % |  | $ | 1,236,723 |  |  |  | 100.0 | % |

[0001193125-20-133708:notes:59]
| (amount in thousands, except percentages) |  | Three Months Ended March 29, 2019 |  |  | As a % of Total Revenues |  |  | Nine Months Ended March 29, 2019 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 195,504 |  |  |  | 49.0 | % |  | $ | 558,028 |  |  |  | 47.3 | % |
| Asia-Pacific |  |  | 151,263 |  |  |  | 37.9 |  |  |  | 469,921 |  |  |  | 39.9 |  |
| Europe |  |  | 52,184 |  |  |  | 13.1 |  |  |  | 151,259 |  |  |  | 12.8 |  |
| Total |  | $ | 398,951 |  |  |  | 100.0 | % |  | $ | 1,179,208 |  |  |  | 100.0 | % |

[0001193125-20-133708:notes:60]
The following tables set forth our revenues by end market:

[0001193125-20-133708:notes:61]
| (amount in thousands, except percentages) |  | Three Months Ended March 27, 2020 |  |  | As a % of Total Revenues |  |  | Nine Months Ended March 27, 2020 |  |  | As a % of Total Revenues |  |
| Optical communications |  | $ | 308,566 |  |  |  | 75.0 | % |  | $ | 933,013 |  |  |  | 75.4 | % |
| Lasers, sensors and other |  |  | 102,644 |  |  |  | 25.0 |  |  |  | 303,710 |  |  |  | 24.6 |  |
| Total |  | $ | 411,210 |  |  |  | 100.0 | % |  | $ | 1,236,723 |  |  |  | 100.0 | % |

[0001193125-20-133708:notes:62]
| (amount in thousands, except percentages) |  | Three Months Ended March 29, 2019 |  |  | As a % of Total Revenues |  |  | Nine Months Ended March 29, 2019 |  |  | As a % of Total Revenues |  |
| Optical communications |  | $ | 298,139 |  |  |  | 74.7 | % |  | $ | 884,454 |  |  |  | 75.0 | % |
| Lasers, sensors and other |  |  | 100,812 |  |  |  | 25.3 |  |  |  | 294,754 |  |  |  | 25.0 |  |
| Total |  | $ | 398,951 |  |  |  | 100.0 | % |  | $ | 1,179,208 |  |  |  | 100.0 | % |


## us-gaap:EarningsPerShareTextBlock

[0001193125-20-133708:notes:63]
[same as prior period, unchanged from 0001193125-20-024258:notes:61]

[0001193125-20-133708:notes:64]
[same as prior period, unchanged from 0001193125-20-024258:notes:62]

[0001193125-20-133708:notes:65]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands except per share amounts) |  | March 27, 2020 |  |  | March 29, 2019 |  |  | March 27, 2020 |  |  | March 29, 2019 |  |
| Net income attributable to shareholders |  | $ | 28,267 |  |  | $ | 28,635 |  |  | $ | 85,455 |  |  | $ | 87,998 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  | 36,987 |  |  |  | 36,891 |  |  |  | 36,970 |  |  |  | 36,786 |  |
| Incremental shares arising from the assumed vesting of restricted share units and performance share units (thousands of shares) |  |  | 810 |  |  |  | 648 |  |  |  | 726 |  |  |  | 597 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 37,797 |  |  |  | 37,539 |  |  |  | 37,696 |  |  |  | 37,383 |  |
| Basic earnings per ordinary share |  | $ | 0.76 |  |  | $ | 0.78 |  |  | $ | 2.31 |  |  | $ | 2.39 |  |
| Diluted earnings per ordinary share |  | $ | 0.75 |  |  | $ | 0.76 |  |  | $ | 2.27 |  |  | $ | 2.35 |  |
| Outstanding performance share units excluded from the computation of diluted earnings per ordinary share (thousands of shares)(1) |  |  | 50 |  |  |  | 401 |  |  |  | 50 |  |  |  | 401 |  |

[0001193125-20-133708:notes:66]
[same as prior period, unchanged from 0001193125-20-024258:notes:64]


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001193125-20-133708:notes:67]
[same as prior period, unchanged from 0001193125-20-024258:notes:65]

[0001193125-20-133708:notes:68]
The Company’s cash, cash equivalents, and short-term investments by category is as follows:

[0001193125-20-133708:notes:69]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Gain/(Loss) |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |  | Other Investments |  |
| As of March 27, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 202,610 |  |  | $ | — |  |  | $ | 202,610 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 21,528 |  |  |  | — |  |  |  | 21,528 |  |  |  | — |  |  |  | — |  |
| Liquidity funds |  |  | 20,954 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 20,954 |  |
| Certificates of deposit and time deposits |  |  | 20,000 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 20,000 |  |
| Corporate debt securities |  |  | 132,877 |  |  |  | (1,439 | ) |  |  | — |  |  |  | 131,438 |  |  |  | — |  |
| U.S. agency and U.S. Treasury securities |  |  | 60,497 |  |  |  | 733 |  |  |  | — |  |  |  | 61,230 |  |  |  | — |  |
| Total |  | $ | 458,466 |  |  | $ | (706 | ) |  | $ | 224,138 |  |  | $ | 192,668 |  |  | $ | 40,954 |  |
| As of June 28, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 178,019 |  |  | $ | — |  |  | $ | 178,019 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 2,820 |  |  |  | — |  |  |  | 2,820 |  |  |  | — |  |  |  | — |  |
| Liquidity funds |  |  | 20,552 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 20,552 |  |
| Certificates of deposit and time deposits |  |  | 35,028 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 35,028 |  |
| Corporate debt securities |  |  | 130,959 |  |  |  | 297 |  |  |  | — |  |  |  | 131,256 |  |  |  | — |  |
| U.S. agency and U.S. Treasury securities |  |  | 69,552 |  |  |  | 105 |  |  |  | — |  |  |  | 69,657 |  |  |  | — |  |
| Total |  | $ | 436,930 |  |  | $ | 402 |  |  | $ | 180,839 |  |  | $ | 200,913 |  |  | $ | 55,580 |  |

[0001193125-20-133708:notes:70]
[same as prior period, unchanged from 0001193125-20-024258:notes:68]

[0001193125-20-133708:notes:71]
The following table summarizes the cost and estimated fair value of short-term investments classified as 
available-for-sale 
 securities based on stated effective maturities as of March 27, 2020:

[0001193125-20-133708:notes:72]
|  |  | March 27, 2020 |  |  | June 28, 2019 |  |
| (amount in thousands) |  | Carrying Cost |  |  | Fair Value |  |  | Carrying Cost |  |  | Fair Value |  |
| Due within one year |  | $ | 30,448 |  |  | $ | 30,472 |  |  | $ | 69,746 |  |  | $ | 69,830 |  |
| Due between one to five years |  |  | 162,926 |  |  |  | 162,196 |  |  |  | 130,765 |  |  |  | 131,083 |  |
| Total |  | $ | 193,374 |  |  | $ | 192,668 |  |  | $ | 200,511 |  |  | $ | 200,913 |  |

[0001193125-20-133708:notes:73]
During the nine months ended March 27, 2020, the Company recognized a realized gain of $0.1 
million 
from sales and maturities of 
available-for-sale
 securities.

[0001193125-20-133708:notes:74]
As of March 27, 2020, the Company considered the decline in market value of its short-term investments portfolio to be temporary in nature and did not consider any of its securities other-than-temporarily impaired. The Company typically invests in highly-rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy requires investments generally to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. When evaluating an investment for other-than-temporary impairment, the Company reviews factors such as the length of time and extent to which fair value has been below its cost basis, the financial condition of the issuer and any changes thereto, changes in market interest rates, and the Company’s intent to sell, or whether it is more likely than not it will be required to sell, the investment before recovery of the investment’s cost basis. No impairment losses were recorded for the nine months ended March 27, 2020.


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-20-133708:notes:75]
[same as prior period, unchanged from 0001193125-20-024258:notes:73]

[0001193125-20-133708:notes:76]
Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. A fair value hierarchy is established
,
 which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs for the valuation of an asset or liability as of the measurement date. The three levels of inputs that may be used to measure fair value are defined as follows:

[0001193125-20-133708:notes:77]
[same as prior period, unchanged from 0001193125-20-024258:notes:75]

[0001193125-20-133708:notes:78]
[same as prior period, unchanged from 0001193125-20-024258:notes:76]

[0001193125-20-133708:notes:79]
[same as prior period, unchanged from 0001193125-20-024258:notes:77]

[0001193125-20-133708:notes:80]
[same as prior period, unchanged from 0001193125-20-024258:notes:78]

[0001193125-20-133708:notes:81]
[same as prior period, unchanged from 0001193125-20-024258:notes:79]

[0001193125-20-133708:notes:82]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of March 27, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 21,528 |  |  | $ | — |  |  | $ | 21,528 |  |
| Liquidity funds |  |  | — |  |  |  | 20,954 |  |  |  | — |  |  |  | 20,954 |  |
| Certificates of deposit and time deposits |  |  | — |  |  |  | 20,000 |  |  |  | — |  |  |  | 20,000 |  |
| Corporate debt securities |  |  | — |  |  |  | 131,438 |  |  |  | — |  |  |  | 131,438 |  |
| U.S. agency and U.S. Treasury securities |  |  | — |  |  |  | 61,230 |  |  |  | — |  |  |  | 61,230 |  |
| Derivative assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | — |  |  | $ | 255,150 |  |  | $ | — |  |  | $ | 255,150 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 11,977 | (1) |  | $ | — |  |  | $ | 11,977 |  |
| Total |  | $ | — |  |  | $ | 11,977 |  |  | $ | — |  |  | $ | 11,977 |  |

[0001193125-20-133708:notes:83]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 28, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 2,820 |  |  | $ | — |  |  | $ | 2,820 |  |
| Liquidity funds |  |  | — |  |  |  | 20,552 |  |  |  | — |  |  |  | 20,552 |  |
| Certificates of deposit and time deposits |  |  | — |  |  |  | 35,028 |  |  |  | — |  |  |  | 35,028 |  |
| Corporate debt securities |  |  | — |  |  |  | 131,256 |  |  |  | — |  |  |  | 131,256 |  |
| U.S. agency and U.S. Treasury securities |  |  | — |  |  |  | 69,657 |  |  |  | — |  |  |  | 69,657 |  |
| Derivative assets |  |  | — |  |  |  | 2,201 | (2) |  |  | — |  |  |  | 2,201 |  |
| Total |  | $ | — |  |  | $ | 261,514 |  |  | $ | — |  |  | $ | 261,514 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 2,591 | (3) |  | $ | — |  |  | $ | 2,591 |  |
| Total |  | $ | — |  |  | $ | 2,591 |  |  | $ | — |  |  | $ | 2,591 |  |

[0001193125-20-133708:notes:84]
| (1) | Foreign currency forward and option contracts with a notional amount of $126.0 million and Canadian dollars of $0.7 million, and two interest rate swap agreements with an aggregate notional amount of $125.1 million. |

[0001193125-20-133708:notes:85]
| (2) | Foreign currency forward contracts with notional amount of $72.0 million and Canadian dollars of $0.6 million. |

[0001193125-20-133708:notes:86]
| (3) | Interest rate swap agreement with a notional amount of $64.2 million. |

[0001193125-20-133708:notes:87]
Derivative financial instruments

[0001193125-20-133708:notes:88]
[same as prior period, unchanged from 0001193125-20-024258:notes:87]

[0001193125-20-133708:notes:89]
[same as prior period, unchanged from 0001193125-20-024258:notes:88]

[0001193125-20-133708:notes:90]
Foreign currency forward and option contracts

[0001193125-20-133708:notes:91]
As a result of foreign currency rate fluctuations, the U.S. dollar equivalent values of the Company’s foreign currency denominated assets and liabilities fluctuate. The Company uses foreign currency contracts to manage the foreign exchange risk associated with a portion of its foreign currency denominated assets and liabilities and other foreign currency transactions. The Company enters into foreign currency forward and option contracts to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht and Canadian dollars.

[0001193125-20-133708:notes:92]
The Company may enter into foreign currency forward contracts to hedge flu
ctu
ations in the U.S. dollar value of forecasted transactions denominated in Thai baht, including inventory purchases, payroll and other operating expenses. The Company considers these forward contracts as dual-purpose hedges, that hedge both the foreign exchange fluctuation (i) from inception through the forecasted expenditure, and (ii) any subsequent revaluation of the account payable or accrual. The Company may designate the forward contracts that hedge the foreign exchange fluctuation from inception through the forecasted expenditure as cash flow hedges. The gain or loss on a derivative instrument designated and qualifying as a cash flow hedging instrument is recorded as a component of other comprehensive income and reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings. The reclassified amounts are presented in the same income statement line item as the earnings effect of the hedged item. Once the forecasted transactions are recorded, the Company will discontinue the hedging relationship by 
de-designating
 the derivative instrument and recording subsequent changes in fair value through contract maturity to foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income as a natural hedge against the Thai baht denominated assets and liabilities.

[0001193125-20-133708:notes:93]
The Company may also enter into 
non-designated
 foreign currency forward and option contracts to provide an offset to the 
re-measurement
 of foreign currency denominated assets and liabilities and to hedge certain forecasted exposures. Changes in the fair value of these 
non-designated
 derivatives are recorded through foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-20-133708:notes:94]
As of March 27, 2020, the Company had 100 outstanding U.S. dollar foreign currency forward contracts against Thai baht
,
 with an aggregate notional amount of $101.0 million 
and
 maturity dates ranging from April 2020 through October 2020 that were designated for cash flow hedge accounting. 
T
he hedging relationship was determined to be highly effective based on the performance of retrospective and prospective regression testing. During the three and nine months ended March 27, 2020, the Company recorded an unrealized loss of $6.6 million from changes in the fair value of these foreign currency forward contracts, designated as hedging instruments, in other comprehensive income in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-20-133708:notes:95]
During the three and nine months ended March 27, 2020, the Company de-designated 20 foreign currency forward contracts against the Thai baht that had previously been designated as cash flow hedges and reclassified a loss of $1.7 million from accumulated other comprehensive income to foreign exchange loss, net, cost of revenues, and selling, general and administrative expenses in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-20-133708:notes:96]
As of March 29, 2019, the Company had no foreign currency forward contracts designated as cash flow hedges.

[0001193125-20-133708:notes:97]
As of March 27, 2020, the Company had 20 outstanding U.S. dollar foreign currency forward contracts with an aggregate notional amount of $24.0 million, one outstanding U.S. dollar foreign currency option contract with a notional amount of $1.0 million
,
 and one outstanding Canadian dollar foreign currency forward contract with a notional amount of $0.5 million,
 and
 maturity dates ranging from June 2020 through July 2020, that were not designated for hedge accounting. These foreign currency option and forward contracts were used to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai 
b
aht and Canadian dollar
s
. During the three and nine months ended March 27, 2020, the Company recorded an unrealized loss of $2.1 million and $4.0 million, respectively, from changes in the fair value of these foreign currency option and forward contracts in earnings as foreign exchange loss, net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-20-133708:notes:98]
As of March 29, 2019, the Company had 45 outstanding U.S. dollar foreign currency forward contracts with an aggregate notional amount of $98.0 million, one outstanding U.S. dollar foreign currency option contract with a notional amount of $5.0 million
,
 and one outstanding Canadian dollar forward contract with a notional amount of $0.4 million
, and

[0001193125-20-133708:notes:99]
maturity dates ranging from April 2019 through August 2019, that were not designated for hedge accounting. These foreign currency forward and option contracts were used to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai 
b
aht and Canadian dollar
s
. During the nine months ended March 29, 2019, the Company recorded an unrealized gain of $1.5 million from changes in the fair value of these foreign currency forward and option contracts in earnings as foreign exchange loss, net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-20-133708:notes:100]
As of March 27, 2020, the amount in a
cc
umulated other 
comprehensive 
income which is expected to be reclassified into earnings within 12 months is $4.9 million.

[0001193125-20-133708:notes:101]
Interest 
r
ate 
s
wap 
a
greements

[0001193125-20-133708:notes:102]
The Company entered into interest rate swap agreements to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. As of March 27, 2020, the Company had two outstanding interest rate swap agreements with an aggregate notional amount of $125.1 million. As of 
June 28
, 2019, the Company had one outstanding interest rate swap agreement with a notional amount of $64.2 million.

[0001193125-20-133708:notes:103]
On July 25, 2018, Fabrinet Thailand entered into an interest rate swap agreement to effectively convert the floating interest rate of its term loan under the Bank of America Credit Facility Agreement to a fixed interest rate of 2.86% per annum through the scheduled maturity of the term loan in June 2023 (see Note 14). The Company did not designate this interest rate swap for hedge accounting.

[0001193125-20-133708:notes:104]
On September 3, 2019, the Company drew down a term loan under a new Credit Facility Agreement with the Bank of Ayudhya Public Company Limited (the “Bank”) (see Note 14) and on September 10, 2019, repaid in full the outstanding term loan under the Bank of America Credit Facility (see Note 14). In conjunction with the funding of the new term loan, the Company entered into a second interest rate swap agreement. The combination of both of these interest rate swaps effectively convert the floating interest rate of the Company’s term loan with the Bank to a fixed interest rate of

[0001193125-20-133708:notes:105]
4.36
% per annum through the maturity of the term loan in 
June 2024
.

[0001193125-20-133708:notes:106]
On September 27, 2019, the Company designated these two interest rate swaps as a cash flow

[0001193125-20-133708:notes:107]
hedge for the Company’s term loan under the Credit Facility Agreement with the Bank. The combination of these two interest rate swaps qualified for hedge accounting based on a regression testing result which proved the hedges are highly effective. In addition, the Company has designated and documented contemporaneously the hedging relationships involving these interest rate swaps. At least quarterly, the Company performs a qualitative effectiveness test on the interest rate swaps to support the continued application of hedge accounting. As of March 27, 2020, the hedging relationship was determined to be highly effective based on the performance of a qualitative effectiveness testing. While the Company intends to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in earnings. From September 27, 2019, any gains or losses related to these interest rate swaps will be recorded in accumulated other comprehensive income in the unaudited condensed consolidated balance sheets, with a portion reclassified from accumulated other comprehensive income into earnings at each reporting period based on either the accrued interest amount or the interest payment.

[0001193125-20-133708:notes:108]
As of March 27, 2020, the amount in accumulated other comprehensive income that is expected to be reclassified into earnings within 12 months is $17 thousand.

[0001193125-20-133708:notes:109]
Prior to September 27, 2019, these interest rate swaps were not designated as cash flow hedges and all changes in the fair value of these interest rate swaps were reflected in earnings. During the nine months ended March 27, 2020 and March 29, 2019, the Company recorded unrealized loss of $1.7 million and $1.6 million, respectively, from changes in the fair value of these interest rate swaps as interest expense in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-20-133708:notes:110]
The following table provides a summary of the impact of derivative gain (loss) of the Company’s foreign currency forward contracts and interest rate swaps which were designated as cash flow hedges on the unaudited condensed consolidated statements of operations and other comprehensive income:

[0001193125-20-133708:notes:111]
|  |  |  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | Financial statements line item |  |  | March 27, 2020 |  |  | March 29, 2019 |  |  | March 27, 2020 |  |  | March 29, 2019 |  |
| Derivatives gain (loss) recognized in other comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  |  | Other comprehensive income |  |  | $ | (6,609 | ) |  | $ | — |  |  | $ | (6,609 | ) |  | $ | — |  |
| Interest rate swaps |  |  | Other comprehensive income |  |  |  | (1,239 | ) |  |  | — |  |  |  | (956 | ) |  |  | — |  |
| Total derivatives loss recognized in other comprehensive income |  |  |  |  |  | $ | (7,848 | ) |  | $ | — |  |  | $ | (7,565 | ) |  | $ | — |  |
| Derivatives gain (loss) reclassified from accumulated other comprehensive income into earnings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  |  | Cost of revenues |  |  | $ | 14 |  |  | $ | — |  |  | $ | 14 |  |  | $ | — |  |
| Foreign currency forward contracts |  |  | SG&A |  |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | — |  |
| Foreign currency forward contracts |  |  | Foreign exchange loss, net |  |  |  | 1,669 |  |  |  | — |  |  |  | 1,669 |  |  |  | — |  |
| Interest rate swaps |  |  | Interest expense |  |  |  | (405 | ) |  |  | — |  |  |  | (838 | ) |  |  | — |  |
| Total derivatives gain reclassified from accumulated other comprehensive income into earnings |  |  |  |  |  | $ | 1,279 |  |  | $ | — |  |  | $ | 846 |  |  | $ | — |  |
| Change in net unrealized loss on derivatives instruments |  |  |  |  |  | $ | (6,569 | ) |  | $ | — |  |  | $ | (6,719 | ) |  | $ | — |  |

[0001193125-20-133708:notes:112]
Fair value of derivatives

[0001193125-20-133708:notes:113]
The following table provides the fair values of the Company’s derivative financial instruments for the periods presented:

[0001193125-20-133708:notes:114]
| (amount in thousands) |  | March 27, 2020 |  |  | June 28, 2019 |  |
| Derivative Assets |  |  | Derivative Liabilities |  |  | Derivative Assets |  |  | Derivative Liabilities |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts |  | $ | — |  |  | $ | (1,833 | ) |  | $ | 2,201 |  |  | $ | — |  |
| Interest rate swaps |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (2,591 | ) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | 31 |  |  | $ | (4,956 | ) |  | $ | — |  |  | $ | — |  |
| Interest rate swaps |  |  | 83 |  |  |  | (5,302 | ) |  |  | — |  |  |  | — |  |
| Derivatives, gross balances |  | $ | 114 |  |  | $ | (12,091 | ) |  | $ | 2,201 |  |  | $ | (2,591 | ) |
| Derivatives, gross balances offset in the balance sheet |  |  | (114 | ) |  |  | 114 |  |  |  | — |  |  |  | — |  |
| Derivatives, net balances |  | $ | — |  |  | $ | (11,977 | ) |  | $ | 2,201 |  |  | $ | (2,591 | ) |

[0001193125-20-133708:notes:115]
The Company presents its derivatives at net fair values in the unaudited condensed consolidated balance sheets.

[0001193125-20-133708:notes:116]
The 
Company’s netting arrangements allow net settlements under certain conditions. The Company’s derivative instruments are typically settled monthly or quarterly.

[0001193125-20-133708:notes:117]
The Company recorded the fair value of derivative financial instruments in the unaudited condensed consolidated balance sheets as follows:

[0001193125-20-133708:notes:118]
[same as prior period, unchanged from 0001193125-20-024258:notes:118]


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001193125-20-133708:notes:119]
[same as prior period, unchanged from 0001193125-20-024258:notes:119]

[0001193125-20-133708:notes:120]
| (amount in thousands) |  | As of March 27, 2020 |  |  | As of June 28, 2019 |  |
| Trade accounts receivable |  | $ | 283,546 |  |  | $ | 260,698 |  |
| Less: allowance for doubtful account |  |  | (79 | ) |  |  | (96 | ) |
| Trade accounts receivable, net |  | $ | 283,467 |  |  | $ | 260,602 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-20-133708:notes:121]
[same as prior period, unchanged from 0001193125-20-024258:notes:121]

[0001193125-20-133708:notes:122]
| (amount in thousands) |  | As of March 27, 2020 |  |  | As of June 28, 2019 |  |
| Raw materials |  | $ | 118,729 |  |  | $ | 113,321 |  |
| Work-in-progress |  |  | 141,646 |  |  |  | 141,730 |  |
| Finished goods |  |  | 18,779 |  |  |  | 24,916 |  |
| Goods in transit |  |  | 11,054 |  |  |  | 13,645 |  |
| Inventories |  | $ | 290,208 |  |  | $ | 293,612 |  |


## fn:ScheduleOfOtherReceivableTextBlock

[0001193125-20-133708:notes:123]
[same as prior period, unchanged from 0001193125-20-024258:notes:123]

[0001193125-20-133708:notes:124]
On October 1, 2019, the Company provided funds in the amount of $24.3

[0001193125-20-133708:notes:125]
million to a customer to support the customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. T
h
e customer has agreed to repay this amount by September 30, 2020. A
s of
 March 27, 2020, the Company recorded the $24.3 million

[0001193125-20-133708:notes:126]
funds as other receivable in the unaudited condensed consolidated balance sheet. For the nine months ended March 27, 2020, the Company classified th
e
s
e
 funds as an investing activity in the unaudited condensed consolidated statement of cash flows.


## fn:RestrictedCashAndCashEquivalentsTextBlock

[0001193125-20-133708:notes:127]
[same as prior period, unchanged from 0001193125-20-024258:notes:125]

[0001193125-20-133708:notes:128]
As of March 27, 2020 and June 28, 2019, the Company had one outstanding standby letter of credit of 6.0 million Euros, related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. As of March 27, 2020 and June 28, 2019, the standby letter of credit was backed by cash collateral of $7.4 million.


## fn:ScheduleOfAdoptionOfTopic842OnOperatingLeaseInConsolidateFinancialPositionTableTextBlock

[0001193125-20-133708:notes:129]
[same as prior period, unchanged from 0001193125-20-024258:notes:127]

[0001193125-20-133708:notes:130]
[same as prior period, unchanged from 0001193125-20-024258:notes:128]

[0001193125-20-133708:notes:131]
Operating lease ROU assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at commencement date. As most of the Company’s leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the lease commencement date in determining the present value of future payments. The operating lease ROU assets also include any lease payments made and exclude lease incentives and initial direct costs incurred. Variable lease payments are expensed as incurred and are not included within the ROU asset and lease liability calculation. Variable lease payments primarily include reimbursements of costs incurred by lessors for common area maintenance and utilities. The Company’s lease terms may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option.

[0001193125-20-133708:notes:132]
Leases with an initial term of 12 months or less are not recorded on the balance sheet. The Company recognizes lease expense for these leases on a straight-line basis over the lease term. The Company does not account for lease components (e.g., fixed payments including rent) separately from the

[0001193125-20-133708:notes:133]
non-lease

[0001193125-20-133708:notes:134]
components (e.g., common-area maintenance costs).

[0001193125-20-133708:notes:135]
[same as prior period, unchanged from 0001193125-20-024258:notes:131]

[0001193125-20-133708:notes:136]
[same as prior period, unchanged from 0001193125-20-024258:notes:132]

[0001193125-20-133708:notes:137]
|  |  | Impact of Adopting ASC 842 |  |
| (amount in thousands) |  | Balance at June 28, 2019 |  |  | Adjustment |  |  | Balance at June 29, 2019 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating lease ROU assets |  | $ | — |  |  | $ | 5,370 |  |  | $ | 5,370 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating lease liabilities, current |  | $ | — |  |  | $ | 1,601 |  |  | $ | 1,601 |  |
| Operating lease liabilities, non-current |  | $ | — |  |  | $ | 3,769 |  |  | $ | 3,769 |  |


## us-gaap:LesseeOperatingLeaseLiabilityMaturityTableTextBlock

[0001193125-20-133708:notes:138]
As of March 27, 2020, the maturities of the Company’s operating lease liabilities were as follows:

[0001193125-20-133708:notes:139]
| (amount in thousands) |  |  |  |
| 2020 (remaining three months) |  | $ | 486 |  |
| 2021 |  |  | 2,131 |  |
| 2022 |  |  | 2,000 |  |
| 2023 |  |  | 1,895 |  |
| 2024 |  |  | 878 |  |
| Thereafter |  |  | 15 |  |
| Total undiscounted lease payments |  |  | 7,405 |  |
| Less imputed interest |  |  | (488 | ) |
| Total present value of lease liabilities |  | $ | 6,917 | (1) |

[0001193125-20-133708:notes:140]
| (1) | Includes current portion of operating lease liabilities of $1.9 million. |


## fn:ScheduleOfAdditionalInformationRelatedToOperatingAndFinanceLeaseTableTextBlock

[0001193125-20-133708:notes:141]
|  |  | As of March 27, 2020 |  |
| Weighted-average remaining lease term (in years) |  |  |  |  |
| Operating leases |  |  | 3.7 |  |
| Finance leases |  |  | 0.5 |  |
| Weighted-average discount rate |  |  |  |  |
| Operating leases |  |  | 3.8 | % |
| Finance leases |  |  | 4.1 | % |


## fn:ScheduleOfSupplementalCashFlowInformationRelatedToOperatingLeaseTableTextBlock

[0001193125-20-133708:notes:142]
The following information represents supplemental disclosure for the statement of cash flows related to operating and finance leases:

[0001193125-20-133708:notes:143]
| (amount in thousands) |  | Nine Months Ended March 27, 2020 |  |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |
| Operating cash flows from operating leases |  | $ | 1,794 |  |
| Financing cash flows from finance leases |  | $ | 304 |  |
| ROU assets obtained in exchange for lease liabilities |  | $ | 7,175 |  |
| Finance lease assets |  | $ | 157 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-20-133708:notes:144]
[same as prior period, unchanged from 0001193125-20-024258:notes:147]

[0001193125-20-133708:notes:145]
[same as prior period, unchanged from 0001193125-20-024258:notes:148]

[0001193125-20-133708:notes:146]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net |  |
| As of March 27, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 7,689 |  |  | $ | (5,365 | ) |  | $ | — |  |  | $ | 2,324 |  |
| Customer relationships |  |  | 4,373 |  |  |  | (2,551 | ) |  |  | (147 | ) |  |  | 1,675 |  |
| Backlog |  |  | 119 |  |  |  | (119 | ) |  |  | — |  |  |  | — |  |
| Total intangibles |  | $ | 12,181 |  |  | $ | (8,035 | ) |  | $ | (147 | ) |  | $ | 3,999 |  |

[0001193125-20-133708:notes:147]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net |  |
| As of June 28, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 6,582 |  |  | $ | (4,868 | ) |  | $ | — |  |  | $ | 1,714 |  |
| Customer relationships |  |  | 4,373 |  |  |  | (2,096 | ) |  |  | (104 | ) |  |  | 2,173 |  |
| Backlog |  |  | 119 |  |  |  | (119 | ) |  |  | — |  |  |  | — |  |
| Total intangibles |  | $ | 11,074 |  |  | $ | (7,083 | ) |  | $ | (104 | ) |  | $ | 3,887 |  |

[0001193125-20-133708:notes:148]
Based on the carrying amount of intangibles as of March 27, 2020, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001193125-20-133708:notes:149]
| (amount in thousands) |  |  |  |
| 2020 (remaining three months) |  | $ | 628 |  |
| 2021 |  |  | 1,139 |  |
| 2022 |  |  | 908 |  |
| 2023 |  |  | 650 |  |
| 2024 |  |  | 423 |  |
| Thereafter |  |  | 251 |  |
| Total |  | $ | 3,999 |  |


## us-gaap:ScheduleOfAcquiredFiniteLivedIntangibleAssetsByMajorClassTextBlock

[0001193125-20-133708:notes:150]
The weighted-average remaining life of customer relationships was:

[0001193125-20-133708:notes:151]
| (years) |  | As of March 27, 2020 |  |  | As of June 28, 2019 |  |
| Customer relationships |  |  | 4.8 |  |  |  | 5.4 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-20-133708:notes:152]
[same as prior period, unchanged from 0001193125-20-024258:notes:156]

[0001193125-20-133708:notes:153]
[same as prior period, unchanged from 0001193125-20-024258:notes:157]

[0001193125-20-133708:notes:154]
| (amount in thousands) |  | Goodwill |  |
| Balance as of June 28, 2019 |  | $ | 3,705 |  |
| Foreign currency translation adjustment |  |  | (134 | ) |
| Balance as of March 27, 2020 |  | $ | 3,571 |  |

[0001193125-20-133708:notes:155]
[same as prior period, unchanged from 0001193125-20-024258:notes:160]

[0001193125-20-133708:notes:156]
During the nine months ended March 27, 2020 and March 29, 2019, there were no goodwill impairment losses.


## us-gaap:DebtDisclosureTextBlock

[0001193125-20-133708:notes:157]
| 14. | Borrowings |

[0001193125-20-133708:notes:158]
The Company’s total borrowings, including 
current 
and 
non-current
 portions of long-term borrowings, consisted of the following:

[0001193125-20-133708:notes:159]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  |  | Maturity |  |  | As of March 27, 2020 |  |  | As of June 28, 2019 |  |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  | $ | 12,188 |  |  | $ | 3,250 |  |
| Less: Unamortized debt issuance costs – current portion |  |  | (32 | ) |  |  | — |  |
| Long-term borrowings, current portion, net |  |  |  |  |  | $ | 12,156 |  |  | $ | 3,250 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1-month LIBOR +1.50% per annum (1) |  |  | Repayable in quarterly installments |  |  |  | June 2023 |  |  | $ | — |  |  | $ | 60,938 |  |
| 3-month LIBOR +1.35% per annum (1) |  |  | Repayable in quarterly installments |  |  |  | June 2024 |  |  |  | 54,844 |  |  |  | — |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (12,188 | ) |  |  | (3,250 | ) |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  |  |  | (103 | ) |  |  | — |  |
| Long-term borrowings, non-current portion, net |  |  |  |  |  | $ | 42,553 |  |  | $ | 57,688 |  |

[0001193125-20-133708:notes:160]
| (1) | We have entered into interest rate swaps that effectively fix a series of our future interest payments on our term loans. Refer to Note 6. |

[0001193125-20-133708:notes:161]
The movements of long-term borrowings for the nine months ended March 27, 2020 and March 29, 2019 were as follows:

[0001193125-20-133708:notes:162]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27, 2020 |  |  | March 29, 2019 |  |
| Opening balance |  | $ | 60,938 |  |  | $ | 64,188 |  |
| Borrowings during the period |  |  | 60,938 |  |  |  | — |  |
| Repayments during the period |  |  | (67,032 | ) |  |  | (2,438 | ) |
| Closing balance |  | $ | 54,844 |  |  | $ | 61,750 |  |

[0001193125-20-133708:notes:163]
As of March 27, 2020, future maturities of long-term borrowings during each fiscal year were as follows:

[0001193125-20-133708:notes:164]
| (amount in thousands) |  |  |  |
| 2020 (remaining three months) |  | $ | 3,046 |  |
| 2021 |  |  | 12,188 |  |
| 2022 |  |  | 15,234 |  |
| 2023 |  |  | 12,188 |  |
| 2024 |  |  | 12,188 |  |
| Total |  | $ | 54,844 |  |

[0001193125-20-133708:notes:165]
Credit facility agreements:

[0001193125-20-133708:notes:166]
Bank of Ayudhya Public Company Limited

[0001193125-20-133708:notes:167]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai 
b
aht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities.

[0001193125-20-133708:notes:168]
The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

[0001193125-20-133708:notes:169]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a Term Loan Agreement pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million.

[0001193125-20-133708:notes:170]
The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company’s previous credit facility agreement with Bank of America, N.A.

[0001193125-20-133708:notes:171]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be 
re-borrowed.

[0001193125-20-133708:notes:172]
During the three and nine months ended March 27, 2020, the Company recorded $0.5 million and $1.1 million, respectively, of interest expense in connection with this term loan.

[0001193125-20-133708:notes:173]
Any borrowings under the Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

[0001193125-20-133708:notes:174]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt to equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. At March 27, 2020, the Company was in compliance with all of its covenants under the Term Loan Agreement.

[0001193125-20-133708:notes:175]
The events of default in the Term Loan Agreement include failure to pay amounts due under the Term Loan Agreement or the related finance documents when due, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

[0001193125-20-133708:notes:176]
At March 27, 2020, there was $54.8 million outstanding under the term loan.

[0001193125-20-133708:notes:177]
Bank of America, N.A.

[0001193125-20-133708:notes:178]
On May 22, 2014, the Company and a consortium of banks entered into a 
syndicated 
senior credit facility agreement led by Bank of America (the “Bank of America Facility Agreement”). The Bank of America Facility Agreement provided for a $200.0 million credit line, comprised of a $150.0 million revolving loan facility and a $50.0 million delayed draw term loan facility.

[0001193125-20-133708:notes:179]
From time to time, 
the Company
 amended the Bank of America Facility Agreement, before repaying all outstanding amounts under the agreement and terminating such agreement on September 10, 2019.

[0001193125-20-133708:notes:180]
The most recent amendment on June 4, 2018 (i) reduced the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) refinanced the outstanding amounts under the revolving loan and term loan facilities into a $65.0 million term loan which was to be repaid in quarterly installments through the maturity date of June 4, 2023, and (iii) reduced the interest rate margins and commitment fees. The term loan bore interest, at the Company’s option, at a rate per annum equal to a LIBOR rate plus a spread of 1.50% to 2.25%, or a base rate plus a spread of 0.50% to 1.25%. During the nine months ended March 27, 2020 and March 29, 2019, the Company recorded $0.5 million and $1.8 million, respectively, of interest expense in connection with this term loan.

[0001193125-20-133708:notes:181]
On September 10, 2019, the Company fully repaid $61.0 million in principal, accrued interest and other fees under the agreement. The early termination of this agreement did not trigger any early termination fees. At March 27, 2020, there were no amounts outstanding under the Bank of America Facility Agreement. At June 28, 2019, there was $60.9 million 
outstanding 
under the Bank of America Facility Agreement, related to the term loan.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-20-133708:notes:182]
[same as prior period, unchanged from 0001193125-20-024258:notes:190]

[0001193125-20-133708:notes:183]
As of March 27, 2020 and June 28, 2019, the liability for uncertain tax positions including accrued interest and penalties was $1.5 million and $2.1 million, respectively. The Company expects the estimated amount of liability associated with its uncertain tax positions to decrease within the next 12 months due to the lapse of the applicable statute of limitations in foreign tax jurisdictions.

[0001193125-20-133708:notes:184]
The Company files income tax returns in the United States and foreign tax jurisdictions. As of March 27, 2020, the tax years from 2014 t
hrough
 2017 remain open to examination by U.S. federal and state
 tax authorities
. In addition, tax returns that remain open to examination in Thailand range from the tax years 2015 through 2019, and 
in 
the People’s Republic of China and the United Kingdom range from the tax years 2015 through 2018. The Company’s income tax is recognized based on the best estimate of the expected annual effective tax rate for the full financial year of each entity in the Company, adjusted for discrete items arising in that quarter. If 
the 
Company’s estimated annual effective tax rate changes, the Company makes a cumulative adjustment in that quarter.

[0001193125-20-133708:notes:185]
The Company’s effective tax rate for the three months ended March 27, 2020 and March 29, 2019 was 2.4% and 5.2%, respectively, of net income. The 
de
crease was primarily due to the fact that the Company had

[0001193125-20-133708:notes:186]
lower

[0001193125-20-133708:notes:187]
income subject to tax during the three months ended March 27, 2020, compared with the three months ended March 29, 2019.

[0001193125-20-133708:notes:188]
The Company’s effective tax rate for the nine months ended March 27, 2020 and March 29, 2019 was 4.2% and 5.2%, respectively, of net income. The decrease was primarily due to the fact that the Company had lower income subject to tax during the nine months ended March 27, 2020 as compared to the nine months ended March 29, 2019.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-20-133708:notes:189]
[same as prior period, unchanged from 0001193125-20-024258:notes:195]

[0001193125-20-133708:notes:190]
[same as prior period, unchanged from 0001193125-20-024258:notes:196]

[0001193125-20-133708:notes:191]
[same as prior period, unchanged from 0001193125-20-024258:notes:197]

[0001193125-20-133708:notes:192]
The effect of recording share-based compensation expense for the three and nine months ended March 27, 2020 and March 29, 2019 was as follows:

[0001193125-20-133708:notes:193]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27,2020 |  |  | March 29,2019 |  |  | March 27, 2020 |  |  | March 29, 2019 |  |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restricted share units |  |  | 4,094 |  |  |  | 3,621 |  |  |  | 12,678 |  |  |  | 11,650 |  |
| Performance share units |  |  | 2,024 |  |  |  | 803 |  |  |  | 5,623 |  |  |  | 1,723 |  |
| Total share-based compensation expense |  |  | 6,118 |  |  |  | 4,424 |  |  |  | 18,301 |  |  |  | 13,373 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 6,118 |  |  | $ | 4,424 |  |  | $ | 18,301 |  |  | $ | 13,373 |  |

[0001193125-20-133708:notes:194]
Share-based compensation expense was recorded in the unaudited condensed consolidated statements of operations and comprehensive income as follows:

[0001193125-20-133708:notes:195]
|  |  | Three Months ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27,2020 |  |  | March 29,2019 |  |  | March 27, 2020 |  |  | March 29, 2019 |  |
| Cost of revenue |  | $ | 1,489 |  |  | $ | 1,237 |  |  | $ | 4,800 |  |  | $ | 4,384 |  |
| Selling, general and administrative expense |  |  | 4,629 |  |  |  | 3,187 |  |  |  | 13,501 |  |  |  | 8,989 |  |
| Total share-based compensation expense |  | $ | 6,118 |  |  | $ | 4,424 |  |  | $ | 18,301 |  |  | $ | 13,373 |  |

[0001193125-20-133708:notes:196]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the three and nine months ended March 27, 2020 and March 29, 2019.

[0001193125-20-133708:notes:197]
[same as prior period, unchanged from 0001193125-20-024258:notes:203]

[0001193125-20-133708:notes:198]
On December 12, 2019, the Company’s shareholders approved Fabrinet’s 2020 Equity Incentive Plan (the “2020 Plan”). Upon the approval of the 2020 Plan, Fabrinet’s Amended and Restated 2010 Performance Incentive Plan (the “2010 Plan”) was simultaneously terminated. The 2020 Plan provides for the grant of equity awards thereunder with respect to (i) 1,700,000 ordinary shares, plus (ii) up to 1,300,000 ordinary shares that, as of immediately prior to the termination of the 2010 Plan, had been reserved but not issued pursuant to any awards granted under the 2010 Plan and are not subject to any awards thereunder. Upon termination of the 2010 Plan, 1,281,619 ordinary shares were reserved for issuance under the 2020 Plan pursuant to clause (ii) of the preceding sentence. As of March 27, 2020, there were 30,262 restricted

[0001193125-20-133708:notes:199]
share units outstanding, 3,836 performance share units outstanding and 2,946,847 ordinary shares available for future grant under the 2020 Plan.

[0001193125-20-133708:notes:200]
As of March 27, 2020, there were 739,838 restricted share units and 436,304 performance share units outstanding

[0001193125-20-133708:notes:201]
under the 2010 Plan.

[0001193125-20-133708:notes:202]
No
 ordinary shares are available for future grant under the 2010 Plan.

[0001193125-20-133708:notes:203]
On November 2, 2017, the Company adopted the 2017 Inducement Equity Incentive Plan (the “2017 Inducement Plan”) with a reserve of 160,000 ordinary shares authorized for future issuance solely for the granting of inducement share options and equity awards to new employees. The 2017 Inducement Plan was adopted without shareholder approval in reliance on the “employment inducement exemption” provided under the New York Stock Exchange Listed Company Manual. As of March 27, 2020, there were an aggregate of 24,327 restricted share units outstanding and 111,347 ordinary shares available for future grant under the 2017 Inducement Plan.

[0001193125-20-133708:notes:204]
The 2010 Plan, 2017 Inducement Plan and 2020 Plan are collectively referred to as the “Equity Incentive Plans.”

[0001193125-20-133708:notes:205]
[same as prior period, unchanged from 0001193125-20-024258:notes:210]

[0001193125-20-133708:notes:206]
Restricted share units and performance share units have been granted under the 2010 Plan, the 2017 Inducement Plan, and the 2020 Plan.

[0001193125-20-133708:notes:207]
[same as prior period, unchanged from 0001193125-20-024258:notes:214]

[0001193125-20-133708:notes:208]
Performance share units granted to executives will vest, if at all, at the end of a 
two-year
 performance period based on the Company’s achievement of 
pre-defined
 performance criteria, which consist of revenue and 
non-GAAP
 gross margin 
or
 operating margin targets. The actual number of performance share units that may vest at the end of the performance period ranges from 0% to 100% of the award grant.

[0001193125-20-133708:notes:209]
[same as prior period, unchanged from 0001193125-20-024258:notes:217]

[0001193125-20-133708:notes:210]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 28, 2019 |  |  | 800,751 |  |  | $ | 42.48 |  |
| Granted |  |  | 343,792 |  |  | $ | 50.32 |  |
| Issued |  |  | (321,659 | ) |  | $ | 40.82 |  |
| Forfeited |  |  | (28,457 | ) |  | $ | 42.80 |  |
| Balance as of March 27, 2020 |  |  | 794,427 |  |  | $ | 46.54 |  |

[0001193125-20-133708:notes:211]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 29, 2018 |  |  | 1,073,580 |  |  | $ | 35.19 |  |
| Granted |  |  | 341,748 |  |  | $ | 48.77 |  |
| Issued |  |  | (496,854 | ) |  | $ | 34.08 |  |
| Forfeited |  |  | (104,194 | ) |  | $ | 38.50 |  |
| Balance as of March 29, 2019 |  |  | 814,280 |  |  | $ | 41.14 |  |

[0001193125-20-133708:notes:212]
[same as prior period, unchanged from 0001193125-20-024258:notes:219]

[0001193125-20-133708:notes:213]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 28, 2019 |  |  | 548,500 |  |  | $ | 40.97 |  |
| Granted |  |  | 242,310 |  |  | $ | 48.65 |  |
| Issued |  |  | — |  |  |  | — |  |
| Forfeited |  |  | (350,670 | ) |  | $ | 36.99 |  |
| Balance as of March 27, 2020 |  |  | 440,140 |  |  | $ | 48.37 |  |

[0001193125-20-133708:notes:214]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 29, 2018 |  |  | 605,892 |  |  | $ | 38.41 |  |
| Granted |  |  | 201,994 |  |  | $ | 48.02 |  |
| Issued |  |  | (227,268 | ) |  | $ | 40.48 |  |
| Forfeited |  |  | (27,954 | ) |  | $ | 39.35 |  |
| Balance as of March 29, 2019 |  |  | 552,664 |  |  | $ | 41.02 |  |

[0001193125-20-133708:notes:215]
As of March 27, 2020, there was $15.0 million and $7.7 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.5 years and 1.3 years, respectively.

[0001193125-20-133708:notes:216]
For the nine months ended March 27, 2020 and March 29, 2019, the Company withheld an aggregate of 91,481 shares and 231,624 shares, respectively, upon the vesting of restricted share units, based upon the closing share price on the vesting date to settle the employees’ minimum statutory obligation for the applicable income and other employment taxes. For the nine months ended March 27, 2020 and March 29, 2019, the Company then remitted cash of $4.7 million and $10.4 million, respectively, to the appropriate taxing authorities, and presented it as a financing activity within the unaudited condensed consolidated statements of cash flows. The payment was recorded as a reduction of additional 
paid-in
 capital.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-20-133708:notes:217]
[same as prior period, unchanged from 0001193125-20-024258:notes:225]

[0001193125-20-133708:notes:218]
[same as prior period, unchanged from 0001193125-20-024258:notes:226]

[0001193125-20-133708:notes:219]
The Company’s authorized share capital is 500,000,000 ordinary shares, par value of $0.01 per ordinary share, and 5,000,000 preferred shares, par value of $0.01 per preferred share.

[0001193125-20-133708:notes:220]
For the three and nine months ended March 27, 2020, the Company issued 52,041 and 230,178 ordinary shares, respectively, upon the vesting of restricted share units, net of shares withheld.

[0001193125-20-133708:notes:221]
For the three and nine months ended March 29, 2019, the Company issued 78,072 and 492,498 ordinary shares, respectively, upon the vesting of restricted share units, net of shares withheld.

[0001193125-20-133708:notes:222]
[same as prior period, unchanged from 0001193125-20-024258:notes:239]

[0001193125-20-133708:notes:223]
[same as prior period, unchanged from 0001193125-20-024258:notes:240]

[0001193125-20-133708:notes:224]
In August 2017, the Company’s board of directors approved a share repurchase program to permit the Company to repurchase up to $30.0 million worth of its issued and outstanding ordinary shares in the open market in accordance with applicable rules and regulations. In February 2018 and May 2019, the Company’s board of directors approved an increase of $30.0 million and $50.0 million, respectively, to the original share repurchase authorization, bringing the aggregate authorization to $110.0 million. During the three and nine months ended March 27, 2020, 
355,000 
shares were repurchased under the program, at an average price per share of $58.37, totaling $20.7 million. As of March 27, 2020, the Company had a remaining authorization to purchase up to $41.5 million of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-20-133708:notes:225]
[same as prior period, unchanged from 0001193125-20-024258:notes:243]

[0001193125-20-133708:notes:226]
The changes in AOCI for the nine months ended March 27, 2020 and March 29, 2019 were as follows:

[0001193125-20-133708:notes:227]
| (amount in thousands) |  | Unrealized net (Losses)/Gains on Available-for-sale Securities |  |  | Unrealized net (Losses)/Gains on Derivative Instruments |  |  | Retirement benefit plan - Prior service cost |  |  | Foreign Currency Translation Adjustment |  |  | Total |  |
| Balance as of June 28, 2019 |  | $ | 952 |  |  | $ | 32 |  |  | $ | (2,537 | ) |  | $ | (833 | ) |  | $ | (2,386 | ) |
| Other comprehensive income before reclassification adjustment |  |  | (1,310 | ) |  |  | (7,565 | ) |  |  | 478 |  |  |  | (353 | ) |  |  | (8,750 | ) |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income |  |  | (93 | ) |  |  | 846 |  |  |  | — |  |  |  | — |  |  |  | 753 |  |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income (loss) |  | $ | (1,403 | ) |  | $ | (6,719 | ) |  | $ | 478 |  |  | $ | (353 | ) |  | $ | (7,997 | ) |
| Balance as of March 27, 2020 |  | $ | (451 | ) |  | $ | (6,687 | ) |  | $ | (2,059 | ) |  | $ | (1,186 | ) |  | $ | (10,383 | ) |

[0001193125-20-133708:notes:228]
| (amount in thousands) |  | Unrealized net (Losses)/Gains on Available-for-sale Securities |  |  | Unrealized net (Losses)/Gains on Derivative Instruments |  |  | Retirement benefit plan - Prior service cost |  |  | Foreign Currency Translation Adjustment |  |  | Total |  |
| Balance as of June 29, 2018 |  | $ | (1,091 | ) |  | $ | 33 |  |  | $ | — |  |  | $ | (199 | ) |  | $ | (1,257 | ) |
| Other comprehensive income before reclassification adjustment |  |  | 1,203 |  |  |  | — |  |  |  | — |  |  |  | (219 | ) |  |  | 984 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income |  |  | 196 |  |  |  | (2 | ) |  |  | — |  |  |  | — |  |  |  | 194 |  |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income (loss) |  | $ | 1,399 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | (219 | ) |  | $ | 1,178 |  |
| Balance as of March 29, 2019 |  | $ | 308 |  |  | $ | 31 |  |  | $ | — |  |  | $ | (418 | ) |  | $ | (79 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-20-133708:notes:229]
| 19. | Commitments and contingencies |

[0001193125-20-133708:notes:230]
Letter of credit and Bank guarantees

[0001193125-20-133708:notes:231]
As of March 27, 2020 and June 28, 2019, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business 
expenses

[0001193125-20-133708:notes:232]
totaling 
$1.5 million and $1.6 million, respectively, and there were other bank guarantees given by a bank on behalf of our subsidiaries in China and the United Kingdom to support their operations of

[0001193125-20-133708:notes:233]
de minimis amounts.

[0001193125-20-133708:notes:234]
Purchase obligations

[0001193125-20-133708:notes:235]
Purchase obligations represent legally

[0001193125-20-133708:notes:236]
binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001193125-20-133708:notes:237]
As of March 27, 2020, the Company had purchase obligations to third parties of $15.2 million.

[0001193125-20-133708:notes:238]
Indemnification of directors and officers

[0001193125-20-133708:notes:239]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001193125-20-133708:notes:240]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-20-133708:notes:241]
[same as prior period, unchanged from 0001193125-20-024258:notes:263]

[0001193125-20-133708:notes:242]
Operating segments are defined as components of an enterprise for which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. The Company’s chief operating decision maker is Fabrinet’s Chief Executive Officer. As of March 27, 2020, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001193125-20-133708:notes:243]
Total revenues are attributed to a particular geographic area based on the 
bill-to-location
 of the Company’s customers. The 
Company 
operates in three geographic regions: North America, Asia-Pacific and Europe.

[0001193125-20-133708:notes:244]
The following table presents total revenues by geographic region:

[0001193125-20-133708:notes:245]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27, 2020 |  |  | March 29, 2019 |  |  | March 27, 2020 |  |  | March 29, 2019 |  |
| North America |  | $ | 206,751 |  |  | $ | 195,504 |  |  | $ | 631,096 |  |  | $ | 558,028 |  |
| Asia-Pacific |  |  | 141,639 |  |  |  | 151,263 |  |  |  | 401,209 |  |  |  | 469,921 |  |
| Europe |  |  | 62,820 |  |  |  | 52,184 |  |  |  | 204,418 |  |  |  | 151,259 |  |
|  |  | $ | 411,210 |  |  | $ | 398,951 |  |  | $ | 1,236,723 |  |  | $ | 1,179,208 |  |

[0001193125-20-133708:notes:246]
As of March 27, 2020 and March 29, 2019, the Company had approximately $29.9 million and $31.7 million, respectively, of long-lived assets based in North America, with the substantial remainder of assets based in Asia-Pacific and Europe.

[0001193125-20-133708:notes:247]
[same as prior period, unchanged from 0001193125-20-024258:notes:269]

[0001193125-20-133708:notes:248]
The Company had three and two customers that individually contributed 10% or more of its total trade accounts receivable as of March 27, 2020 and June 28, 2019, respectively.


## us-gaap:SubsequentEventsTextBlock

[0001193125-20-133708:notes:249]
| 21. | Subsequent events |

[0001193125-20-133708:notes:250]
The outbreak of a novel strain of coronavirus 
(“COVID-19”)
 was recognized as a pandemic by the World Health Organization on March 11, 2020. The outbreak has spread globally, including to Thailand, the United States, UK and Europe.

[0001193125-20-133708:notes:251]
The implications of 
COVID-19
 on the Company’s business remain uncertain. Measures taken by governmental authorities and private actors to limit the spread of 
COVID-19
 may interfere with the ability of the Company’s employees, suppliers and other business providers to carry out their assigned tasks or supply materials at ordinary levels of performance. While the Company’s operations are impacted as a result of this pandemic, the Company has not experienced a direct, materially adverse financial impact. The future impact of this pandemic on the Company’s business, financial condition, results of operations and cash flows cannot be predicted. The Company continues to monitor developments with the spread of 
COVID-19,
 actions taken by governmental authorities and private actors, and impacts to the Company’s suppliers and customers. The Company continues to work to minimize disruptions to its supply chain and manufacturing capabilities, and to ensure the safety of its employees. While the Company’s operations are impacted as a result of this pandemic, including as a result of restrictions on employees’ ability to travel and requirements that portions of the Company’s workforce work from home, the Company has not experienced a direct, materially adverse financial impact.

[0001193125-20-133708:notes:252]
The Company is not currently aware of any business interruption or loss contingencies related to 
COVID-19
 that would require recognition in the third quarter of fiscal 2020.
