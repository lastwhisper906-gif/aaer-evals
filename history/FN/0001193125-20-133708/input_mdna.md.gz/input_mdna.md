# FN MD&A — 0001193125-20-133708


## mdna

[0001193125-20-133708:mdna:1]
[same as prior period, unchanged from 0001193125-20-024258:mdna:1]

[0001193125-20-133708:mdna:2]
[same as prior period, unchanged from 0001193125-20-024258:mdna:2]

[0001193125-20-133708:mdna:3]
[same as prior period, unchanged from 0001193125-20-024258:mdna:3]

[0001193125-20-133708:mdna:4]
[same as prior period, unchanged from 0001193125-20-024258:mdna:4]

[0001193125-20-133708:mdna:5]
|  | • | our expectation that the portion of our revenues attributable to customers in regions outside of North America for the remainder of fiscal year 2020 will be in line with the portion of those revenues for the nine months ended March 27, 2020; |

[0001193125-20-133708:mdna:6]
[same as prior period, unchanged from 0001193125-20-024258:mdna:6]

[0001193125-20-133708:mdna:7]
[same as prior period, unchanged from 0001193125-20-024258:mdna:7]

[0001193125-20-133708:mdna:8]
[same as prior period, unchanged from 0001193125-20-024258:mdna:8]

[0001193125-20-133708:mdna:9]
[same as prior period, unchanged from 0001193125-20-024258:mdna:9]

[0001193125-20-133708:mdna:10]
[same as prior period, unchanged from 0001193125-20-024258:mdna:10]

[0001193125-20-133708:mdna:11]
[same as prior period, unchanged from 0001193125-20-024258:mdna:11]

[0001193125-20-133708:mdna:12]
[same as prior period, unchanged from 0001193125-20-024258:mdna:12]

[0001193125-20-133708:mdna:13]
|  | • | our expectations regarding the potential impact of the COVID-19 pandemic on our business, financial condition and results of operations; |

[0001193125-20-133708:mdna:14]
[same as prior period, unchanged from 0001193125-20-024258:mdna:13]

[0001193125-20-133708:mdna:15]
[same as prior period, unchanged from 0001193125-20-024258:mdna:14]

[0001193125-20-133708:mdna:16]
[same as prior period, unchanged from 0001193125-20-024258:mdna:15]

[0001193125-20-133708:mdna:17]
[same as prior period, unchanged from 0001193125-20-024258:mdna:16]

[0001193125-20-133708:mdna:18]
[same as prior period, unchanged from 0001193125-20-024258:mdna:17]

[0001193125-20-133708:mdna:19]
[same as prior period, unchanged from 0001193125-20-024258:mdna:18]

[0001193125-20-133708:mdna:20]
[same as prior period, unchanged from 0001193125-20-024258:mdna:19]

[0001193125-20-133708:mdna:21]
[same as prior period, unchanged from 0001193125-20-024258:mdna:20]

[0001193125-20-133708:mdna:22]
[same as prior period, unchanged from 0001193125-20-024258:mdna:21]

[0001193125-20-133708:mdna:23]
[same as prior period, unchanged from 0001193125-20-024258:mdna:22]

[0001193125-20-133708:mdna:24]
[same as prior period, unchanged from 0001193125-20-024258:mdna:23]

[0001193125-20-133708:mdna:25]
[same as prior period, unchanged from 0001193125-20-024258:mdna:24]

[0001193125-20-133708:mdna:26]
Recent Developments Related to 
COVID-19

[0001193125-20-133708:mdna:27]
In the quarter ended March 27, 2020, the effects of the global 
COVID-19
 pandemic impacted us in several ways and created various challenges. It started with our Casix facility in Fuzhou, China, which manufactures custom optics components for us and other customers. In January 2020, while many factories (including our Casix facility) were closed for about eight days because of China’s Lunar New Year holiday, the Chinese government, as part of its efforts to mitigate the spread of 
COVID-19,
 ordered that businesses in various parts of the country extend the holiday closures. The Chinese government ordered our Casix facility to not resume operations for almost two weeks. Because of the restrictions on travel in China in place during this period, many of our employees were unable to return from their holiday travel as planned. As a result, fewer than 90% of our employees were able to return to work at our Casix facility until early March. Our other manufacturing facilities also have been affected by various government restrictions put in place in their locations to slow the spread of 
COVID-19.
 In Thailand, the government declared a national state of emergency effective March 26, 2020, to reduce the spread of 
COVID-19.
 The government required the closure of various businesses, in particular retail establishments, and passed measures restricting movement and activities in Thailand. Our operations in Thailand have not been closed, and we have implemented a number of safety protocols that have allowed our operations in those facilities to continue. Our facilities in the United States, located in California and New Jersey, and in the United Kingdom have remained open, while adhering to the local government restrictions and orders implemented in March 2020, including shelter in place orders and social distancing guidelines, except that our facility in California was closed for about a week beginning in late March until it reopened in early April as a previously classified “essential” business.

[0001193125-20-133708:mdna:28]
The health and well-being of our employees is our top priority. Over the past several months, we have implemented significant precautionary measures throughout our worldwide operations to keep our employees and their families safe, such as mandatory temperature detection at building entrances, rigorous and regular facility and equipment disinfection, and mandatory personal protective equipment protocols, including (1) the wearing of face masks throughout our factories at all times, (2) distributing our employees across shifts to better maintain safe personal distances, (3) isolating incoming parts and materials for a week or more before unpacking, or baking them to kill potential viruses, (4) directing our 
non-factory
 personnel to work from home, and (5) restricting all 
non-employee
 visits to our campuses.

[0001193125-20-133708:mdna:29]
During the quarter, we also experienced a shift in the demand for our services, with some customers canceling, decreasing or delaying their orders and other customers accelerating and increasing their orders. However, the most significant effect of 
COVID-19 
 on our operations this quarter was the disruption of our supply chain, in which we experienced significant fluctuations in the availability of parts and materials we need to manufacture products for our customers. We were able to mitigate some of these issues by quickly identifying and securing alternative sources; however, these mitigation efforts, combined with our employee safety initiatives, negatively affected our gross margins because they increased our costs and expenses.

[0001193125-20-133708:mdna:30]
Given the unprecedented global, human, and economic impact of 
COVID-19;
 the extraordinary economic short-term uncertainty; and the evolving and differing national strategies for dealing with 
COVID-19,
 it is extremely difficult and challenging to provide forward-looking disclosure. However, given the uncertainty and concern about the global economy and the health of various industries, we think it important to share some thoughts on how 
COVID-19
 may impact our business in the future:

[0001193125-20-133708:mdna:31]
|  | • | With work-from-home protocols in place around the world, global demand for internet bandwidth has grown and we believe it will continue to grow. Because the next-generation telecom and datacom products we manufacture for our customers are important to expand network capacity, we believe this will have a positive impact on our business in the long-term. |

[0001193125-20-133708:mdna:32]
|  | • | While we believe that the long-term growth outlook for the markets we serve has not been significantly impacted, in the short-term we are likely to continue to see regional downward demand adjustments for products we manufacture for our customers, especially if the COVID-19 outbreak intensifies or returns in various geographic areas as happened at the end of our third fiscal quarter. Moreover, we believe the markets for other products we manufacture, such as the industrial lasers and automotive markets, are likely to see reduced demand in a prolonged economic downturn. |

[0001193125-20-133708:mdna:33]
|  | • | We expect we will continue to experience disruptions in our supply chain and the availability of parts and materials will continue to fluctuate, especially if the COVID-19 outbreak intensifies or returns in various geographic areas. However, we believe we can mitigate these disruptions by continuing to identify and secure alternative sources. |

[0001193125-20-133708:mdna:34]
|  | • | A significant portion of our costs are variable and, because of this, we can adjust manufacturing costs relatively quickly to the changing demand of our customers. However, because the largest portion of our costs is for parts and materials, because of the supply chain issues noted above and, to a lesser extent, our commitment to the safety and health protocols we have implemented across our global operations, our gross margins will continue to be negatively affected for the foreseeable future, at least into the first half of fiscal 2021. |

[0001193125-20-133708:mdna:35]
|  | • | The safety and health of our employees is and will remain a key priority, and we will continue to follow robust safety protocols in all of our facilities. |

[0001193125-20-133708:mdna:36]
|  | • | Given our $457.8 million in cash, cash equivalents and short-term investments, and our total debt of approximately $54.8 million, as of March 27, 2020, we believe we are in a solid position from a capital and financial resources perspective. |

[0001193125-20-133708:mdna:37]
[same as prior period, unchanged from 0001193125-20-024258:mdna:30]

[0001193125-20-133708:mdna:38]
[same as prior period, unchanged from 0001193125-20-024258:mdna:31]

[0001193125-20-133708:mdna:39]
36

[0001193125-20-133708:mdna:40]
[same as prior period, unchanged from 0001193125-20-024258:mdna:32]

[0001193125-20-133708:mdna:41]
[same as prior period, unchanged from 0001193125-20-024258:mdna:33]

[0001193125-20-133708:mdna:42]
The percentage of our revenues generated from a 
bill-to
 location outside of North America decreased from 51.0% in the three months ended March 29, 2019 to 49.7% in the three months ended March 27, 2020 and from 52.7% in the nine months ended March 29, 2019 to 49.0% in the nine months ended March 27, 2020, primarily because the increase in sales to our customers in North America was higher than the increase in sales to our customers outside of North America. Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside North America for the remainder of fiscal year 2020 will be in line with the portion of total revenues attributable to such customers during the nine months ended March 27, 2020.

[0001193125-20-133708:mdna:43]
[same as prior period, unchanged from 0001193125-20-024258:mdna:35]

[0001193125-20-133708:mdna:44]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 27, 2020 |  |  | March 29, 2019 |  |  | March 27, 2020 |  |  | March 29, 2019 |  |
| North America |  |  | 50.3 | % |  |  | 49.0 | % |  |  | 51.0 | % |  |  | 47.3 | % |
| Asia-Pacific |  |  | 34.4 |  |  |  | 37.9 |  |  |  | 32.5 |  |  |  | 39.9 |  |
| Europe |  |  | 15.3 |  |  |  | 13.1 |  |  |  | 16.5 |  |  |  | 12.8 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-20-133708:mdna:45]
[same as prior period, unchanged from 0001193125-20-024258:mdna:37]

[0001193125-20-133708:mdna:46]
[same as prior period, unchanged from 0001193125-20-024258:mdna:38]

[0001193125-20-133708:mdna:47]
[same as prior period, unchanged from 0001193125-20-024258:mdna:39]

[0001193125-20-133708:mdna:48]
[same as prior period, unchanged from 0001193125-20-024258:mdna:40]

[0001193125-20-133708:mdna:49]
A second significant element of our cost of revenues is employee costs, including indirect employee costs related to design, configuration and optimization of manufacturing processes for our customers, quality testing, materials testing and other engineering services; and direct costs related to our manufacturing employees. Direct employee costs include employee salaries, insurance and benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a lesser extent, costs to recruit, train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand, the PRC and the United Kingdom, the fluctuation of the Thai baht, Chinese Renminbi (“RMB”) and

[0001193125-20-133708:mdna:50]
Pound Sterling (“GBP”) against our functional currency, the U.S. dollar, and our ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention and asset utilization.

[0001193125-20-133708:mdna:51]
[same as prior period, unchanged from 0001193125-20-024258:mdna:42]

[0001193125-20-133708:mdna:52]
[same as prior period, unchanged from 0001193125-20-024258:mdna:43]

[0001193125-20-133708:mdna:53]
[same as prior period, unchanged from 0001193125-20-024258:mdna:44]

[0001193125-20-133708:mdna:54]
[same as prior period, unchanged from 0001193125-20-024258:mdna:45]

[0001193125-20-133708:mdna:55]
[same as prior period, unchanged from 0001193125-20-024258:mdna:46]

[0001193125-20-133708:mdna:56]
[same as prior period, unchanged from 0001193125-20-024258:mdna:47]

[0001193125-20-133708:mdna:57]
[same as prior period, unchanged from 0001193125-20-024258:mdna:48]

[0001193125-20-133708:mdna:58]
[same as prior period, unchanged from 0001193125-20-024258:mdna:49]

[0001193125-20-133708:mdna:59]
In order to manage the risks arising from fluctuations in foreign currency exchange rates, we use derivative instruments. We may enter into foreign exchange currency forward or put option contracts to manage foreign currency exposures associated with certain assets and liabilities and other forecasted foreign currency transactions and may designate these instruments as hedging instruments. The forward and put option contracts generally have maturities of up to 12 months. All foreign currency exchange contracts are recognized in the unaudited condensed consolidated balance sheets at fair value. Gains or losses on our forward and put option contracts generally offset the assets, liabilities, and transactions economically hedged.

[0001193125-20-133708:mdna:60]
[same as prior period, unchanged from 0001193125-20-024258:mdna:51]

[0001193125-20-133708:mdna:61]
|  |  | As of March 27, 2020 |  |  | As of June 28, 2019 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 885,394 |  |  | $ | 27,277 |  |  |  | 44.2 |  |  |  | 664,860 |  |  | $ | 21,628 |  |  |  | 60.0 |  |
| RMB |  |  | 189,575 |  |  |  | 26,918 |  |  |  | 43.6 |  |  |  | 53,393 |  |  |  | 7,767 |  |  |  | 21.5 |  |
| GBP |  |  | 6,171 |  |  |  | 7,541 |  |  |  | 12.2 |  |  |  | 5,270 |  |  |  | 6,682 |  |  |  | 18.5 |  |
| Total |  |  |  |  |  | $ | 61,736 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 36,077 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 2,047,689 |  |  | $ | 63,084 |  |  |  | 88.4 |  |  |  | 1,961,972 |  |  | $ | 63,825 |  |  |  | 90.0 |  |
| RMB |  |  | 37,561 |  |  |  | 5,333 |  |  |  | 7.5 |  |  |  | 26,373 |  |  |  | 3,836 |  |  |  | 5.4 |  |
| GBP |  |  | 2,397 |  |  |  | 2,929 |  |  |  | 4.1 |  |  |  | 2,598 |  |  |  | 3,294 |  |  |  | 4.6 |  |
| Total |  |  |  |  |  | $ | 71,346 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 70,955 |  |  |  | 100.0 |  |

[0001193125-20-133708:mdna:62]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of March 27, 2020 there was $126.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 28, 2019, there was $72.0 million of foreign currency forward contracts outstanding on the Thai baht payables.

[0001193125-20-133708:mdna:63]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of March 27, 2020 and June 28, 2019, we did not have any derivative contracts denominated in RMB.

[0001193125-20-133708:mdna:64]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable and other payables. As of March 27, 2020 and June 28, 2019, we did not have any derivative contracts denominated in GBP.

[0001193125-20-133708:mdna:65]
[same as prior period, unchanged from 0001193125-20-024258:mdna:57]

[0001193125-20-133708:mdna:66]
[same as prior period, unchanged from 0001193125-20-024258:mdna:58]

[0001193125-20-133708:mdna:67]
[same as prior period, unchanged from 0001193125-20-024258:mdna:59]

[0001193125-20-133708:mdna:68]
[same as prior period, unchanged from 0001193125-20-024258:mdna:60]

[0001193125-20-133708:mdna:69]
[same as prior period, unchanged from 0001193125-20-024258:mdna:61]

[0001193125-20-133708:mdna:70]
[same as prior period, unchanged from 0001193125-20-024258:mdna:62]

[0001193125-20-133708:mdna:71]
[same as prior period, unchanged from 0001193125-20-024258:mdna:63]

[0001193125-20-133708:mdna:72]
Circular 142 regulates the conversion by a foreign-invested company of foreign currency into RMB by restricting how the converted RMB may be used. Circular 142 requires that the registered capital of a foreign-invested enterprise settled in RMB converted from foreign currencies may only be used for purposes within the business scope approved by

[0001193125-20-133708:mdna:73]
the applicable governmental authority and may not be used for equity investments within the PRC. In addition, SAFE strengthened its oversight of the flow and use of the registered capital of foreign-invested enterprises settled in RMB converted from foreign currencies. The use of such RMB capital may not be changed without SAFE’s approval and may not be used to repay RMB loans if the proceeds of such loans have not been used.

[0001193125-20-133708:mdna:74]
[same as prior period, unchanged from 0001193125-20-024258:mdna:65]

[0001193125-20-133708:mdna:75]
[same as prior period, unchanged from 0001193125-20-024258:mdna:66]

[0001193125-20-133708:mdna:76]
[same as prior period, unchanged from 0001193125-20-024258:mdna:67]

[0001193125-20-133708:mdna:77]
[same as prior period, unchanged from 0001193125-20-024258:mdna:68]

[0001193125-20-133708:mdna:78]
[same as prior period, unchanged from 0001193125-20-024258:mdna:69]

[0001193125-20-133708:mdna:79]
[same as prior period, unchanged from 0001193125-20-024258:mdna:70]

[0001193125-20-133708:mdna:80]
[same as prior period, unchanged from 0001193125-20-024258:mdna:71]

[0001193125-20-133708:mdna:81]
[same as prior period, unchanged from 0001193125-20-024258:mdna:72]

[0001193125-20-133708:mdna:82]
[same as prior period, unchanged from 0001193125-20-024258:mdna:73]

[0001193125-20-133708:mdna:83]
Our critical accounting policies are disclosed in our Annual Report on Form 
10-K
 for the fiscal year ended June 28, 2019. The adoption of new accounting policies and accounting standards are disclosed in Note 2 of Notes to Unaudited Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 
10-Q.
 There were no changes to our accounting policies other than the adoption of Leases (Topic 842) and Derivatives and Hedging (Topic 815).

[0001193125-20-133708:mdna:84]
[same as prior period, unchanged from 0001193125-20-024258:mdna:77]

[0001193125-20-133708:mdna:85]
[same as prior period, unchanged from 0001193125-20-024258:mdna:78]

[0001193125-20-133708:mdna:86]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27, 2020 |  |  | March 29, 2019 |  |  | March 27, 2020 |  |  | March 29, 2019 |  |
| Revenues |  | $ | 411,210 |  |  | $ | 398,951 |  |  | $ | 1,236,723 |  |  | $ | 1,179,208 |  |
| Cost of revenues |  |  | (366,874 | ) |  |  | (352,193 | ) |  |  | (1,097,242 | ) |  |  | (1,046,610 | ) |
| Gross profit |  |  | 44,336 |  |  |  | 46,758 |  |  |  | 139,481 |  |  |  | 132,598 |  |
| Selling, general and administrative expenses |  |  | (17,111 | ) |  |  | (14,132 | ) |  |  | (50,189 | ) |  |  | (41,296 | ) |
| Expenses related to reduction in workforce |  |  | — |  |  |  | (323 | ) |  |  | (16 | ) |  |  | (727 | ) |
| Operating income |  |  | 27,225 |  |  |  | 32,303 |  |  |  | 89,276 |  |  |  | 90,575 |  |
| Interest income |  |  | 2,042 |  |  |  | 2,144 |  |  |  | 6,080 |  |  |  | 4,770 |  |
| Interest expense |  |  | (238 | ) |  |  | (1,423 | ) |  |  | (2,812 | ) |  |  | (3,673 | ) |
| Foreign exchange loss, net |  |  | (8 | ) |  |  | (3,055 | ) |  |  | (2,949 | ) |  |  | (408 | ) |
| Other income, net |  |  | 203 |  |  |  | 159 |  |  |  | 977 |  |  |  | 798 |  |
| Income before income taxes |  |  | 29,224 |  |  |  | 30,128 |  |  |  | 90,572 |  |  |  | 92,062 |  |
| Income tax expense |  |  | (957 | ) |  |  | (1,493 | ) |  |  | (5,117 | ) |  |  | (4,064 | ) |
| Net income |  |  | 28,267 |  |  |  | 28,635 |  |  |  | 85,455 |  |  |  | 87,998 |  |
| Other comprehensive (loss) income, net of tax |  |  | (8,231 | ) |  |  | 998 |  |  |  | (7,997 | ) |  |  | 1,178 |  |
| Net comprehensive income |  | $ | 20,036 |  |  | $ | 29,633 |  |  | $ | 77,458 |  |  | $ | 89,176 |  |

[0001193125-20-133708:mdna:87]
[same as prior period, unchanged from 0001193125-20-024258:mdna:80]

[0001193125-20-133708:mdna:88]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 27, 2020 |  |  | March 29, 2019 |  |  | March 27, 2020 |  |  | March 29, 2019 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (89.2 | ) |  |  | (88.3 | ) |  |  | (88.7 | ) |  |  | (88.8 | ) |
| Gross profit |  |  | 10.8 |  |  |  | 11.7 |  |  |  | 11.3 |  |  |  | 11.2 |  |
| Selling, general and administrative expenses |  |  | (4.2 | ) |  |  | (3.5 | ) |  |  | (4.1 | ) |  |  | (3.5 | ) |
| Expenses related to reduction in workforce |  |  | — |  |  |  | (0.1 | ) |  |  | (0.0 | ) |  |  | (0.1 | ) |
| Operating income |  |  | 6.6 |  |  |  | 8.1 |  |  |  | 7.2 |  |  |  | 7.6 |  |
| Interest income |  |  | 0.5 |  |  |  | 0.5 |  |  |  | 0.5 |  |  |  | 0.4 |  |
| Interest expense |  |  | (0.0 | ) |  |  | (0.4 | ) |  |  | (0.2 | ) |  |  | (0.3 | ) |
| Foreign exchange loss, net |  |  | (0.0 | ) |  |  | (0.8 | ) |  |  | (0.2 | ) |  |  | (0.0 | ) |
| Other income, net |  |  | 0.0 |  |  |  | 0.1 |  |  |  | 0.0 |  |  |  | 0.1 |  |
| Income before income taxes |  |  | 7.1 |  |  |  | 7.5 |  |  |  | 7.3 |  |  |  | 7.8 |  |
| Income tax expense |  |  | (0.2 | ) |  |  | (0.4 | ) |  |  | (0.4 | ) |  |  | (0.3 | ) |
| Net income |  |  | 6.9 |  |  |  | 7.1 |  |  |  | 6.9 |  |  |  | 7.5 |  |
| Other comprehensive (loss) income, net of tax |  |  | (2.0 | ) |  |  | 0.3 |  |  |  | (0.6 | ) |  |  | 0.1 |  |
| Net comprehensive income |  |  | 4.9 | % |  |  | 7.4 | % |  |  | 6.3 | % |  |  | 7.6 | % |

[0001193125-20-133708:mdna:89]
[same as prior period, unchanged from 0001193125-20-024258:mdna:82]

[0001193125-20-133708:mdna:90]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27, 2020 |  |  | March 29, 2019 |  |  | March 27, 2020 |  |  | March 29, 2019 |  |
| Optical communications |  | $ | 308,566 |  |  | $ | 298,139 |  |  | $ | 933,013 |  |  | $ | 884,454 |  |
| Lasers, sensors and other |  |  | 102,644 |  |  |  | 100,812 |  |  |  | 303,710 |  |  |  | 294,754 |  |
| Total |  | $ | 411,210 |  |  | $ | 398,951 |  |  | $ | 1,236,723 |  |  | $ | 1,179,208 |  |

[0001193125-20-133708:mdna:91]
[same as prior period, unchanged from 0001193125-20-024258:mdna:84]

[0001193125-20-133708:mdna:92]
41

[0001193125-20-133708:mdna:93]
Comparison of Three and Nine Months Ended March 27, 2020 with Three and Nine Months Ended March 29, 2019

[0001193125-20-133708:mdna:94]
[same as prior period, unchanged from 0001193125-20-024258:mdna:87]

[0001193125-20-133708:mdna:95]
[same as prior period, unchanged from 0001193125-20-024258:mdna:88]

[0001193125-20-133708:mdna:96]
Our total revenues increased by $12.3 million, or 3.1%, to $411.2 million for the three months ended March 27, 2020, compared with $399.0 million for the three months ended March 29, 2019. This increase was primarily due to an increase in our customers’ demand for both optical and 
non-optical
 communications manufacturing services during the three months ended March 27, 2020. Revenues from optical and 
non-optical
 communications products increased by $10.4 million and $1.8 million, or 3.5% and 1.8%, respectively, for the three months ended March 27, 2020.

[0001193125-20-133708:mdna:97]
Our total revenues increased by $57.5 million, or 4.9%, to $1,236.7 million for the nine months ended March 27, 2020, compared with $1,179.2 million for the nine months ended March 29, 2019. This increase was primarily due to an increase in our customers’ demand for both optical and 
non-optical
 communications manufacturing services during the nine months ended March 27, 2020. Revenues from optical and 
non-optical
 communications products increased by $48.6 million and $9.0 million, or 5.5% and 3.0%, respectively, for the nine months ended March 29, 2019.

[0001193125-20-133708:mdna:98]
[same as prior period, unchanged from 0001193125-20-024258:mdna:91]

[0001193125-20-133708:mdna:99]
[same as prior period, unchanged from 0001193125-20-024258:mdna:92]

[0001193125-20-133708:mdna:100]
Our cost of revenues increased by $14.7 million, or 4.2%, to $366.9 million, or 89.2% of total revenues, for the three months ended March 27, 2020, compared with $352.2 million, or 88.3% of total revenues, for the three months ended March 29, 2019. This increase in cost of revenues was generally in line with the increase in sales volume, except for an increase in costs due to supply chain disruption resulting from COVID-19.

[0001193125-20-133708:mdna:101]
Our cost of revenues increased by $50.6 million, or 4.8%, to $1,097.2 million, or 88.7% of total revenues, for the nine months ended March 27, 2020, compared with $1,046.6 million, or 88.8% of total revenues, for the nine months ended March 29, 2019. This increase in cost of revenues on an absolute dollar basis was in line with the increase in sales volume.

[0001193125-20-133708:mdna:102]
[same as prior period, unchanged from 0001193125-20-024258:mdna:95]

[0001193125-20-133708:mdna:103]
[same as prior period, unchanged from 0001193125-20-024258:mdna:96]

[0001193125-20-133708:mdna:104]
Our gross profit decreased by $2.4 million, or 5.2%, to $44.3 million, or 10.8% of total revenues, for the three months ended March 27, 2020, compared with $46.8 million, or 11.7% of total revenues, for the three months ended March 29, 2019. The decrease was primarily due to a less favorable product mix and an increase in costs due to supply chain disruption resulting from COVID-19.

[0001193125-20-133708:mdna:105]
Our gross profit increased by $6.9 million, or 5.2%, to $139.5 million, or 11.3% of total revenues, for the nine months ended March 27, 2020, compared with $132.6 million, or 11.2% of total revenues, for the nine months ended March 29, 2019. The increase was primarily due to an increase in revenues and effective cost controls.

[0001193125-20-133708:mdna:106]
[same as prior period, unchanged from 0001193125-20-024258:mdna:99]

[0001193125-20-133708:mdna:107]
[same as prior period, unchanged from 0001193125-20-024258:mdna:100]

[0001193125-20-133708:mdna:108]
Our SG&A expenses increased by $3.0 million, or 21.1%, to $17.1 million, or 4.2% of total revenues, for the three months ended March 27, 2020, compared with $14.1 million, or 3.5% of total revenues, for the three months ended March 29, 2019. The increase was primarily due to (1) an increase in share-based compensation expenses of $1.4 million including $1.2 million from an increase in performance share-based awards granted in the period and $0.2 million from an increase in restricted share-based awards granted in the period; (2) an increase in new business 
start-up
 costs in our subsidiary of $0.4 million; (3) an increase in severance liabilities expense of $0.4 million due to a change in labor protection law in Thailand in May 2019 that increased the required severance payment compensation for employees with 20 years of service from 300 days of wage to 400 days of wage; and (4) an increase in executive and management expenses of $0.2 million from bonuses and other benefits.

[0001193125-20-133708:mdna:109]
Our SG&A expenses increased by $8.9 million, or 21.5%, to $50.2 million, or 4.1% of total revenues, for the nine months ended March 27, 2020, compared with $41.3 million, or 3.5% of total revenues, for the nine months ended March 29, 2019. The increase was primarily due to (1) an increase in share-based compensation expenses of $4.5 million including $3.9 million from an increase in performance share-based awards granted in the period and $0.6 million from an increase in restricted share-based awards granted in the period; (2) an increase in executive and management expenses of $2.0 million from bonuses and other benefits; (3) an increase in severance liabilities expense of $1.0 million due to a change in labor protection law in Thailand in May 2019 that increased the required severance payment compensation for employees with 20 years of service from 300 days of wage to 400 days of wage; and (4) an increase in new business 
start-up
 costs in our subsidiary of $0.9 million.

[0001193125-20-133708:mdna:110]
[same as prior period, unchanged from 0001193125-20-024258:mdna:103]

[0001193125-20-133708:mdna:111]
Our operating income decreased by $5.1 million to $27.2 million, or 6.6% of total revenues, for the three months ended March 27, 2020, compared with $32.3 million, or 8.1% of total revenues, for the three months ended March 29, 2019. The decrease was primarily due to an increase in SG&A expenses.

[0001193125-20-133708:mdna:112]
Our operating income decreased by $1.3 million to $89.3 million, or 7.2% of total revenues, for the nine months ended March 27, 2020, compared with $90.6 million, or 7.7% of total revenues, for the nine months ended March 29, 2019. The decrease was primarily due to an increase in SG&A expenses.

[0001193125-20-133708:mdna:113]
[same as prior period, unchanged from 0001193125-20-024258:mdna:106]

[0001193125-20-133708:mdna:114]
[same as prior period, unchanged from 0001193125-20-024258:mdna:107]

[0001193125-20-133708:mdna:115]
Our interest income decreased by $0.1 million, or 4.8%, to $2.0 million, or 0.5% of total revenues, for the three months ended March 27, 2020, compared with $2.1 million, or 0.5% of total revenues, for the three months ended March 29, 2019. The decrease was primarily due to a reduction in the weighted average interest rate compared to the same period in the previous year from 2.3% to 1.9%, consistent with global interest rate trends.

[0001193125-20-133708:mdna:116]
Our interest income increased by $1.3 million, or 27.5%, to $6.1 million, or 0.5% of total revenues, for the nine months ended March 27, 2020, compared with $4.8 million, or 0.4% of total revenues, for the nine months ended March 29, 2019. The increase was primarily due to an increase in the average balance of our outstanding cash.

[0001193125-20-133708:mdna:117]
[same as prior period, unchanged from 0001193125-20-024258:mdna:110]

[0001193125-20-133708:mdna:118]
[same as prior period, unchanged from 0001193125-20-024258:mdna:111]

[0001193125-20-133708:mdna:119]
Our interest expense decreased by $1.2 million to $0.2 million for the three months ended March 27, 2020, compared with $1.4 million for the three months ended March 29, 2019. The decrease was due to the implementation of cash flow hedge on interest rate swaps at September 27, 2019, which resulted in (1) the reduction of interest expense of $0.7 million from the recognition of an unrealized loss from 
mark-to-market
 of interest rate swaps in other comprehensive income instead of in interest expense; and (2) the amortization of the fair value of interest rate swaps as of the hedge inception date of $0.4 million during the three months ended March 27, 2020 in relation to the application of hedge accounting which results in a decrease in interest expense.

[0001193125-20-133708:mdna:120]
Our interest expense decreased by $0.9 million to $2.8 million for the nine months ended March 27, 2020, compared with $3.7 million for the nine months ended March 29, 2019. The decrease was primarily due to an unrealized loss from 
mark-to-market
 of interest rate swaps of $1.7 million for the three months ended September 27, 2019, before applying cash flow hedge, as compared to an unrealized loss of $1.6 million for the nine months ended March 29, 2019; offset by the amortization of the fair value of interest rate swaps as of the hedge inception date of $0.8 million during the nine months ended March 27, 2020 in relation to applying hedge accounting which results in a decrease in interest expense.

[0001193125-20-133708:mdna:121]
Foreign exchange loss, net.

[0001193125-20-133708:mdna:122]
We recorded foreign exchange loss, net of $8 thousand for the three months ended March 27, 2020, compared with a $3.1 million loss for the three months ended March 29, 2019. The decrease in foreign exchange loss was mainly due to unrealized gain from revaluation of outstanding Thai baht assets and liabilities of $3.3 million, offset by an unrealized loss from mark to market forward contracts of $2.1 million and other foreign exchange losses, net of $1.2 million for the three months ended March 27, 2020, as compared to an unrealized loss from mark to market forward contracts and revaluation of outstanding Thai baht assets and liabilities of $2.1 million, and a realized loss from payment and receipts of $0.6 million for the three months ended March 29, 2019.

[0001193125-20-133708:mdna:123]
We recorded foreign exchange loss, net of $2.9 million for the nine months ended March 27, 2020, compared with a $0.4 million loss for the nine months ended March 29, 2019. The increase in foreign exchange loss was due to a realized foreign exchange loss from receipts and payments of $1.6 million for the nine months ended March 27, 2020 as compared to a $0.9 million realized foreign exchange gain from receipts and payments for the nine months ended March 29, 2019.

[0001193125-20-133708:mdna:124]
[same as prior period, unchanged from 0001193125-20-024258:mdna:117]

[0001193125-20-133708:mdna:125]
[same as prior period, unchanged from 0001193125-20-024258:mdna:118]

[0001193125-20-133708:mdna:126]
We recorded income before income taxes of $29.2 million and $90.6 million for the three and nine months ended March 27, 2020, respectively, compared with $30.1 million and $92.1 million for the three and nine months ended March 29, 2019, respectively.

[0001193125-20-133708:mdna:127]
[same as prior period, unchanged from 0001193125-20-024258:mdna:120]

[0001193125-20-133708:mdna:128]
Our provision for income tax reflects an effective tax rate of 2.4% and 5.2% for the three months ended March 27, 2020 and March 29, 2019, respectively. The decrease was primarily due to the fact that we had lower income subject to tax during the three months ended March 27, 2020 as compared to the same period in fiscal year 2019.

[0001193125-20-133708:mdna:129]
Our provision for income tax reflects an effective tax rate of 4.2% and 5.2% for the nine months ended March 27, 2020 and March 29, 2019, respectively. The decrease was primarily due to the fact that we had lower income subject to tax during the nine months ended March 27, 2020 as compared to the same period in fiscal year 2019.

[0001193125-20-133708:mdna:130]
[same as prior period, unchanged from 0001193125-20-024258:mdna:123]

[0001193125-20-133708:mdna:131]
[same as prior period, unchanged from 0001193125-20-024258:mdna:124]

[0001193125-20-133708:mdna:132]
We recorded net income of $28.3 million, or 6.9% of total revenues, for the three months ended March 27, 2020, compared with $28.6 million, or 7.1% of total revenues, for the three months ended March 29, 2019. The decrease was primarily due to (1) an increase in SG&A expenses of $3.0 million and (2) a decrease in gross profit of $2.4 million; partially offset by (1) a decrease in foreign exchange loss of $3.0 million, (2) a net change in interest income and expense of $1.1 million; (3) a decrease in income tax expense of $0.5 million, and (4) a decrease in expenses related to reduction in workforce of $0.3 million.

[0001193125-20-133708:mdna:133]
We recorded net income of $85.5 million, or 6.9% of total revenues, for the nine months ended March 27, 2020, compared with $88.0 million, or 7.5% of total revenues, for the nine months ended March 29, 2019. The decrease was primarily due to (1) a net increase in SG&A expenses of $8.9 million, (2) a net change in foreign exchange gain (loss) of $2.5 million, and (3) an increase in income tax expenses of $1.1 million primarily due to the valuation allowance for deferred tax assets; partially offset by (1) an increase in gross profit of $6.9 million due to increased revenues and effective cost control, (2) a net change in interest income and expense of $2.2 million, and (3) a decrease in expenses related to reduction in workforce of $0.7 million.

[0001193125-20-133708:mdna:134]
Other comprehensive (loss) income, net.

[0001193125-20-133708:mdna:135]
We recorded other comprehensive loss of $8.2 million, or 2.0% of total revenues, for the three months ended March 27, 2020, compared with other comprehensive income of $1.0 million, or 0.3% of total revenues, for the three months ended March 29, 2019.

[0001193125-20-133708:mdna:136]
We recorded other comprehensive loss of $8.0 million, or 0.6% of total revenues, for the nine months ended March 27, 2020, compared with other comprehensive income of $1.2 million, or 0.1% of total revenues, for the nine months ended March 29, 2019.

[0001193125-20-133708:mdna:137]
[same as prior period, unchanged from 0001193125-20-024258:mdna:130]

[0001193125-20-133708:mdna:138]
[same as prior period, unchanged from 0001193125-20-024258:mdna:131]

[0001193125-20-133708:mdna:139]
We primarily finance our operations through cash flow from operations. As of March 27, 2020 and March 29, 2019, we had cash, cash equivalents, and short-term investments of $457.8 million and $408.9 million, respectively, and outstanding debt of $54.8 million and $61.8 million, respectively.

[0001193125-20-133708:mdna:140]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents for each of the three and nine months ended March 27, 2020 was 1.9% and 2.0%, respectively, and for the three and nine months ended March 29, 2019 was 2.3% and 1.9%, respectively.

[0001193125-20-133708:mdna:141]
[same as prior period, unchanged from 0001193125-20-024258:mdna:134]

[0001193125-20-133708:mdna:142]
During the nine months ended March 27, 2020, (1) we paid off a term loan of $60.9 million under our previous Bank of America Facility Agreement, (2) our subsidiaries in Thailand drew down a new term loan of $60.9 million under a new Credit Facility Agreement with the Bank of Ayudhya Public Company Limited, and (3) we repaid $6.1 million of the new term loan under the new Credit Facility Agreement. As a result, as of March 27, 2020, we had a long-term borrowing of $54.8 million under our new Credit Facility Agreement. (See Note 14 for further details.) We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held short-term investments of $233.6 million as of March 27, 2020.

[0001193125-20-133708:mdna:143]
We believe that our current cash and cash equivalents, marketable securities, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 
10-Q.

[0001193125-20-133708:mdna:144]
[same as prior period, unchanged from 0001193125-20-024258:mdna:137]

[0001193125-20-133708:mdna:145]
[same as prior period, unchanged from 0001193125-20-024258:mdna:138]

[0001193125-20-133708:mdna:146]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27, 2020 |  |  | March 29, 2019 |  |
| Net cash provided by operating activities |  | $ | 104,448 |  |  | $ | 105,504 |  |
| Net cash used in investing activities |  | $ | (28,921 | ) |  | $ | (79,045 | ) |
| Net cash used in financing activities |  | $ | (32,000 | ) |  | $ | (22,063 | ) |
| Net increase in cash, cash equivalents and restricted cash |  | $ | 43,527 |  |  | $ | 4,396 |  |

[0001193125-20-133708:mdna:147]
[same as prior period, unchanged from 0001193125-20-024258:mdna:140]

[0001193125-20-133708:mdna:148]
Net cash provided by operating activities decreased by $1.1 million, or 1.0%, to $104.4 million for the nine months ended March 27, 2020, compared with net cash provided by operating activities of $105.5 million for the nine months ended March 29, 2019. The change in net cash provided by operating activities was not significant compared to the same period of the previous year.

[0001193125-20-133708:mdna:149]
[same as prior period, unchanged from 0001193125-20-024258:mdna:142]

[0001193125-20-133708:mdna:150]
Net cash used in investing activities decreased by $50.1 million, or 63.4%, to $28.9 million for the nine months ended March 27, 2020, compared with net cash used in investing activities of $79.0 million for the nine months ended March 29, 2019. This decrease was primarily due to net cash received from short-term investments of $88.2 million, offset by (1) funds provided to a customer of $24.3 million to support the customer’s transfer of certain manufacturing operations from Berlin, Germany to our facilities in Thailand, which the customer has agreed to repay by September 30, 2020, and (2) an increase in investments in property, plant and equipment and intangibles of $14.8 million.

[0001193125-20-133708:mdna:151]
[same as prior period, unchanged from 0001193125-20-024258:mdna:144]

[0001193125-20-133708:mdna:152]
Net cash used in financing activities increased by $9.9 million, or 45.0%, to $32.0 million for the nine months ended March 27, 2020, compared with net cash used in financing activities of $22.1 million for the nine months ended March 29, 2019. This increase was primarily due to (1) an increase in ordinary shares repurchase of $15.3 million and (2) an increase of $3.7 million in net repayments of loans to banks. The increase was offset by (1) an increase in withholding tax related to net share settlement of restricted share units of $5.7 million and (2) the release of restricted cash in connection with a business acquisition of $3.5 million.

[0001193125-20-133708:mdna:153]
[same as prior period, unchanged from 0001193125-20-024258:mdna:146]

[0001193125-20-133708:mdna:154]
As of March 27, 2020, we had one outstanding standby letter of credit of 6.0 million Euros, which was related to our support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to our facilities in Thailand. As of March 27, 2020, the standby letter of credit was backed by cash collateral of $7.4 million.

[0001193125-20-133708:mdna:155]
[same as prior period, unchanged from 0001193125-20-024258:mdna:148]

[0001193125-20-133708:mdna:156]
See Note 2 of Notes to Unaudited Condensed Consolidated Financial Statements in Part I, Item 1 of this Quarterly Report on Form 
10-Q
 for recent accounting pronouncements that could have an effect on us.
