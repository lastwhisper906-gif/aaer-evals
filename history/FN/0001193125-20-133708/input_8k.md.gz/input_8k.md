# FN 8-K — 0001193125-20-132426 filed 2020-05-04

## item codes, every 8-K on or before 2020-05-05

- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2020-05-05

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-20-132426:8k_2_02:1]
EX-99.1
2
d792880dex991.htm
EX-99.1

[0001193125-20-132426:8k_2_02:2]
EX-99.1

[0001193125-20-132426:8k_2_02:3]
Exhibit 99.1

[0001193125-20-132426:8k_2_02:4]
Fabrinet Announces Third Quarter Fiscal Year 2020 Financial Results

[0001193125-20-132426:8k_2_02:5]
BANGKOK, Thailand – May 4, 2020 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision
optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its third quarter ended March 27, 2020.

[0001193125-20-132426:8k_2_02:6]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “We quickly adjusted to a changing business environment in the third quarter to safely remain
operational, demonstrating the flexibility inherent in our business model. As a result, our financial results for the quarter were within our guidance ranges. Looking ahead, we will continue to benefit from our flexible operating model and highly
variable cost structure to generate solid results during this rapidly changing business environment. Keeping our employees safe and healthy remains our top priority, and this enables us to continue providing the highest levels of service to our
customers, reinforcing our strong reputation and leadership position in the market.”

[0001193125-20-132426:8k_2_02:7]
Third Quarter Fiscal Year 2020 Financial Highlights

[0001193125-20-132426:8k_2_02:8]
GAAP Results

[0001193125-20-132426:8k_2_02:9]
|  | • |  | Revenue for the third quarter of fiscal year 2020 was $411.2 million, compared to revenue of $399.0 million for the comparable period in fiscal year 2019. |

[0001193125-20-132426:8k_2_02:10]
|  | • |  | GAAP net income for the third quarter of fiscal year 2020 was $28.3 million, compared to GAAP net income of $28.6 million for the third quarter of fiscal year 2019. GAAP net income for the third quarter of fiscal year 2020 included a foreign exchange loss of $8 thousand, or $0.00 per diluted share, compared to a foreign exchange loss of $3.1 million, or $0.08 per diluted share, for the third quarter of fiscal year 2019. |

[0001193125-20-132426:8k_2_02:11]
|  | • |  | GAAP net income per diluted share for the third quarter of fiscal year 2020 was $0.75, compared to GAAP net income per diluted share of $0.76 for the third quarter of fiscal year 2019. |

[0001193125-20-132426:8k_2_02:12]
Non-GAAP
Results

[0001193125-20-132426:8k_2_02:13]
|  | • |  | Non-GAAP net income for the third quarter of fiscal year 2020 was $34.8 million, compared to non-GAAP net income of $34.3 million for the third quarter of fiscal year 2019. Non-GAAP net income for the third quarter of fiscal year 2020 included a foreign exchange loss of $8 thousand, or $0.00 per diluted share, compared to a foreign exchange loss of $3.1 million, or $0.08 per diluted share, for the third quarter of fiscal year 2019. |

[0001193125-20-132426:8k_2_02:14]
|  | • |  | Non-GAAP net income per diluted share for the third quarter of fiscal year 2020 was $0.92, compared to non-GAAP net income per diluted share of $0.92 for the same period a year ago. |

[0001193125-20-132426:8k_2_02:15]
Business Outlook

[0001193125-20-132426:8k_2_02:16]
Based on information available as of
May 4, 2020, Fabrinet is issuing guidance for its fourth fiscal quarter of 2020 ending June 26, 2020, as follows:

[0001193125-20-132426:8k_2_02:17]
|  | • |  | Fabrinet expects fourth quarter revenue to be in the range of $370.0 million to $400.0 million. |

[0001193125-20-132426:8k_2_02:18]
|  | • |  | GAAP net income per diluted share is expected to be in the range of $0.64 to $0.76, based on approximately 37.6 million fully diluted shares outstanding. |

[0001193125-20-132426:8k_2_02:19]
|  | • |  | Non-GAAP net income per diluted share is expected to be in the range of $0.80 to $0.92, based on approximately 37.6 million fully diluted shares outstanding. |

[0001193125-20-132426:8k_2_02:20]
Conference Call Information

[0001193125-20-132426:8k_2_02:21]
| What: |  | Fabrinet Third Quarter Fiscal-Year 2020 Financial Results Call |
| When: |  | Monday, May 4, 2020 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic |
|  |  | (253) 237-1137, international |
|  |  | Passcode: 2794510 |
| Replay: |  | (855) 859-2056, domestic |
|  |  | (404) 537-3406, international |
|  |  | Passcode: 2794510 |
| Webcast: |  | http://investor.fabrinet.com/ (live and replay) |

[0001193125-20-132426:8k_2_02:22]
This press release and any other information related to the call will also be posted on Fabrinet’s website at
http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-20-132426:8k_2_02:23]
About Fabrinet

[0001193125-20-132426:8k_2_02:24]
Fabrinet is a leading provider of
advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive
components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain
management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities
in Thailand, the United States of America, the People’s Republic of China and the United Kingdom. For more information visit: www.fabrinet.com.

[0001193125-20-132426:8k_2_02:25]
Forward-Looking Statements

[0001193125-20-132426:8k_2_02:26]
geographic areas, and (4) regional downward demand adjustments from our customers, particularly those in areas affected by the outbreak; less customer demand for our products and services
than forecasted; less growth in the optical communications, industrial lasers and sensors markets than we forecast; difficulties expanding into additional markets, such as the semiconductor processing, biotechnology, metrology and materials
processing markets; increased competition in the optical manufacturing services markets; difficulties in delivering products and services that compete effectively from a price and performance perspective; our reliance on a small number of customers
and suppliers; difficulties in managing our operating costs; difficulties in managing and operating our business across multiple countries (including Thailand, the People’s Republic of China, the U.S. and the U.K.); and other important factors
as described in reports and documents we file from time to time with the Securities and Exchange Commission (SEC), including the factors described under the section captioned “Risk Factors” in our Quarterly Report on Form 10-Q, filed on February 4, 2020. We disclaim any obligation to update information contained in these forward-looking statements whether as a result of new information, future events, or otherwise.

[0001193125-20-132426:8k_2_02:27]
Use of Non-GAAP Financials

[0001193125-20-132426:8k_2_02:28]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful
supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; depreciation of fair value uplift; severance liabilities; expenses
related to our CFO search; amortization of intangibles; business combination expenses; amortization of deferred debt issuance costs; expenses related to reduction in workforce; and ASC 606 adjustments. We have excluded these items in order to
enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without
reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001193125-20-132426:8k_2_02:29]
These non-GAAP financial measures are used to: (1) measure company performance against historical results,
(2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001193125-20-132426:8k_2_02:30]
SOURCE: Fabrinet

[0001193125-20-132426:8k_2_02:31]
Investor Contact:

[0001193125-20-132426:8k_2_02:32]
Garo Toomajanian

[0001193125-20-132426:8k_2_02:33]
ir@fabrinet.com

[0001193125-20-132426:8k_2_02:34]
FABRINET

[0001193125-20-132426:8k_2_02:35]
CONDENSED CONSOLIDATED BALANCE SHEETS (unaudited)

[0001193125-20-132426:8k_2_02:36]
| (in thousands of U.S. dollars, except share data and par value) |  | March 27,2020 |  |  | June 28,2019 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 224,138 |  |  | $ | 180,839 |  |
| Short-term restricted cash |  |  | 7,402 |  |  |  | — |  |
| Short-term investments |  |  | 233,622 |  |  |  | 256,493 |  |
| Trade accounts receivable, net |  |  | 283,467 |  |  |  | 260,602 |  |
| Contract assets |  |  | 16,413 |  |  |  | 12,447 |  |
| Inventories |  |  | 290,208 |  |  |  | 293,612 |  |
| Other receivable |  |  | 24,310 |  |  |  | — |  |
| Prepaid expenses |  |  | 4,524 |  |  |  | 8,827 |  |
| Other current assets |  |  | 8,774 |  |  |  | 11,015 |  |
| Total current assets |  |  | 1,092,858 |  |  |  | 1,023,835 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Long-term restricted cash |  |  | — |  |  |  | 7,402 |  |
| Property, plant and equipment, net |  |  | 218,043 |  |  |  | 210,686 |  |
| Intangibles, net |  |  | 3,999 |  |  |  | 3,887 |  |
| Operating right-of-use assets |  |  | 7,175 |  |  |  | — |  |
| Goodwill |  |  | 3,571 |  |  |  | 3,705 |  |
| Deferred tax assets |  |  | 4,353 |  |  |  | 5,679 |  |
| Other non-current assets |  |  | 262 |  |  |  | 124 |  |
| Total non-current assets |  |  | 237,403 |  |  |  | 231,483 |  |
| Total Assets |  | $ | 1,330,261 |  |  | $ | 1,255,318 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion, net |  | $ | 12,156 |  |  | $ | 3,250 |  |
| Trade accounts payable |  |  | 240,028 |  |  |  | 257,617 |  |
| Contract liabilities |  |  | 1,941 |  |  |  | 2,239 |  |
| Operating lease liabilities, current portion |  |  | 1,893 |  |  |  | — |  |
| Income tax payable |  |  | 2,857 |  |  |  | 1,801 |  |
| Accrued payroll, bonus and related expenses |  |  | 19,959 |  |  |  | 16,510 |  |
| Accrued expenses |  |  | 19,798 |  |  |  | 8,997 |  |
| Other payables |  |  | 28,819 |  |  |  | 22,634 |  |
| Total current liabilities |  |  | 327,451 |  |  |  | 313,048 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term borrowings, non-current portion, net |  |  | 42,553 |  |  |  | 57,688 |  |
| Deferred tax liability |  |  | 3,684 |  |  |  | 3,561 |  |
| Operating lease liabilities, non-current portion |  |  | 5,024 |  |  |  | — |  |
| Severance liabilities |  |  | 16,143 |  |  |  | 15,209 |  |
| Other non-current liabilities |  |  | 1,997 |  |  |  | 2,713 |  |
| Total non-current liabilities |  |  | 69,401 |  |  |  | 79,171 |  |
| Total Liabilities |  |  | 396,852 |  |  |  | 392,219 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of March 27, 2020 and June 28, 2019) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 38,460,931 shares and 38,230,753 shares issued as of March 27, 2020 and June 28, 2019, respectively; and 36,716,828 shares and 36,841,650 shares outstanding as of March 27, 2020 and June 28, 2019, respectively) |  |  | 385 |  |  |  | 382 |  |
| Additional paid-in capital |  |  | 171,870 |  |  |  | 158,299 |  |
| Less: Treasury shares, at cost (1,744,103 shares and 1,389,103 shares as of March 27, 2020 and June 28, 2019, respectively) |  |  | (68,501 | ) |  |  | (47,779 | ) |
| Accumulated other comprehensive loss |  |  | (10,383 | ) |  |  | (2,386 | ) |
| Retained earnings |  |  | 840,038 |  |  |  | 754,583 |  |
| Total Shareholders’ Equity |  |  | 933,409 |  |  |  | 863,099 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 1,330,261 |  |  | $ | 1,255,318 |  |

[0001193125-20-132426:8k_2_02:37]
FABRINET

[0001193125-20-132426:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME (unaudited)

[0001193125-20-132426:8k_2_02:39]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (in thousands of U.S. dollars, except per share data) |  | March 27,2020 |  |  | March 29,2019 |  |  | March 27,2020 |  |  | March 29,2019 |  |
| Revenues |  | $ | 411,210 |  |  | $ | 398,951 |  |  | $ | 1,236,723 |  |  | $ | 1,179,208 |  |
| Cost of revenues |  |  | (366,874 | ) |  |  | (352,193 | ) |  |  | (1,097,242 | ) |  |  | (1,046,610 | ) |
| Gross profit |  |  | 44,336 |  |  |  | 46,758 |  |  |  | 139,481 |  |  |  | 132,598 |  |
| Selling, general and administrative expenses |  |  | (17,111 | ) |  |  | (14,132 | ) |  |  | (50,189 | ) |  |  | (41,296 | ) |
| Expenses related to reduction in workforce |  |  | — |  |  |  | (323 | ) |  |  | (16 | ) |  |  | (727 | ) |
| Operating income |  |  | 27,225 |  |  |  | 32,303 |  |  |  | 89,276 |  |  |  | 90,575 |  |
| Interest income |  |  | 2,042 |  |  |  | 2,144 |  |  |  | 6,080 |  |  |  | 4,770 |  |
| Interest expense |  |  | (238 | ) |  |  | (1,423 | ) |  |  | (2,812 | ) |  |  | (3,673 | ) |
| Foreign exchange loss, net |  |  | (8 | ) |  |  | (3,055 | ) |  |  | (2,949 | ) |  |  | (408 | ) |
| Other income, net |  |  | 203 |  |  |  | 159 |  |  |  | 977 |  |  |  | 798 |  |
| Income before income taxes |  |  | 29,224 |  |  |  | 30,128 |  |  |  | 90,572 |  |  |  | 92,062 |  |
| Income tax expense |  |  | (957 | ) |  |  | (1,493 | ) |  |  | (5,117 | ) |  |  | (4,064 | ) |
| Net income |  |  | 28,267 |  |  |  | 28,635 |  |  |  | 85,455 |  |  |  | 87,998 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in net unrealized (loss) gain on available-for-sale securities |  |  | (1,356 | ) |  |  | 513 |  |  |  | (1,403 | ) |  |  | 1,399 |  |
| Change in net unrealized loss on derivative instruments |  |  | (6,569 | ) |  |  | (1 | ) |  |  | (6,719 | ) |  |  | (2 | ) |
| Change in net retirement benefits plan – prior service cost |  |  | 294 |  |  |  | — |  |  |  | 478 |  |  |  | — |  |
| Change in foreign currency translation adjustment |  |  | (600 | ) |  |  | 486 |  |  |  | (353 | ) |  |  | (219 | ) |
| Total other comprehensive (loss) income, net of tax |  |  | (8,231 | ) |  |  | 998 |  |  |  | (7,997 | ) |  |  | 1,178 |  |
| Net comprehensive income |  | $ | 20,036 |  |  | $ | 29,633 |  |  | $ | 77,458 |  |  | $ | 89,176 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.76 |  |  | $ | 0.78 |  |  | $ | 2.31 |  |  | $ | 2.39 |  |
| Diluted |  | $ | 0.75 |  |  | $ | 0.76 |  |  | $ | 2.27 |  |  | $ | 2.35 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |
| Basic |  |  | 36,987 |  |  |  | 36,891 |  |  |  | 36,970 |  |  |  | 36,786 |  |
| Diluted |  |  | 37,797 |  |  |  | 37,539 |  |  |  | 37,696 |  |  |  | 37,383 |  |

[0001193125-20-132426:8k_2_02:40]
FABRINET

[0001193125-20-132426:8k_2_02:41]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited)

[0001193125-20-132426:8k_2_02:42]
|  |  | Nine Months Ended |  |
| (in thousands of U.S. dollars) |  | March 27,2020 |  |  | March 29,2019 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income for the period |  | $ | 85,455 |  |  | $ | 87,998 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 23,115 |  |  |  | 22,521 |  |
| Loss on disposal of property, plant and equipment |  |  | 444 |  |  |  | 81 |  |
| Loss on disposal of intangibles |  |  | — |  |  |  | 149 |  |
| Gain from sales and maturities of available-for-sale securities |  |  | (93 | ) |  |  | (196 | ) |
| Accretion of premiums on short-term investments |  |  | (624 | ) |  |  | (604 | ) |
| Amortization of deferred debt issuance costs |  |  | 18 |  |  |  | — |  |
| (Reversal) allowance for doubtful accounts |  |  | (17 | ) |  |  | 12 |  |
| Unrealized loss (gain) on exchange rate and fair value of foreign currency forward contracts |  |  | 942 |  |  |  | (5,351 | ) |
| Unrealized loss on fair value of interest rate swaps |  |  | 1,672 |  |  |  | 1,564 |  |
| Amortization of fair value at hedge inception of interest rate swaps |  |  | (838 | ) |  |  | — |  |
| Share-based compensation |  |  | 18,301 |  |  |  | 13,373 |  |
| Deferred income tax |  |  | 1,335 |  |  |  | 438 |  |
| Other non-cash expenses |  |  | (559 | ) |  |  | (699 | ) |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | (23,136 | ) |  |  | (17,942 | ) |
| Contract assets |  |  | (3,966 | ) |  |  | (666 | ) |
| Inventories |  |  | 3,404 |  |  |  | (36,418 | ) |
| Other current assets and non-current assets |  |  | 5,830 |  |  |  | (1,568 | ) |
| Trade accounts payable |  |  | (15,571 | ) |  |  | 37,576 |  |
| Contract liabilities |  |  | (298 | ) |  |  | — |  |
| Income tax payable |  |  | 1,056 |  |  |  | 1,942 |  |
| Severance liabilities |  |  | 2,266 |  |  |  | 1,841 |  |
| Other current liabilities and non-current liabilities |  |  | 5,712 |  |  |  | 1,453 |  |
| Net cash provided by operating activities |  |  | 104,448 |  |  |  | 105,504 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of short-term investments |  |  | (123,980 | ) |  |  | (202,328 | ) |
| Proceeds from sales of short-term investments |  |  | 48,808 |  |  |  | 85,941 |  |
| Proceeds from maturities of short-term investments |  |  | 97,358 |  |  |  | 50,370 |  |
| Funds provided to customer to support transfer of manufacturing operations |  |  | (24,310 | ) |  |  | — |  |
| Purchase of property, plant and equipment |  |  | (27,482 | ) |  |  | (13,211 | ) |
| Purchase of intangibles |  |  | (797 | ) |  |  | (290 | ) |
| Proceeds from disposal of property, plant and equipment |  |  | 1,482 |  |  |  | 473 |  |
| Net cash used in investing activities |  |  | (28,921 | ) |  |  | (79,045 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Payment of debt issuance costs |  |  | (153 | ) |  |  | — |  |
| Proceeds from long-term borrowings |  |  | 60,938 |  |  |  | — |  |
| Repayment of long-term borrowings |  |  | (67,032 | ) |  |  | (2,438 | ) |
| Repayment of finance lease liabilities |  |  | (304 | ) |  |  | (342 | ) |
| Repurchase of ordinary shares |  |  | (20,722 | ) |  |  | (5,378 | ) |
| Release of restricted cash held in connection with business acquisition |  |  | — |  |  |  | (3,478 | ) |
| Withholding tax related to net share settlement of restricted share units |  |  | (4,727 | ) |  |  | (10,427 | ) |
| Net cash used in financing activities |  |  | (32,000 | ) |  |  | (22,063 | ) |
| Net increase in cash, cash equivalents and restricted cash |  |  | 43,527 |  |  |  | 4,396 |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 188,241 |  |  |  | 161,433 |  |
| Increase in cash, cash equivalents and restricted cash |  |  | 43,527 |  |  |  | 4,396 |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash |  |  | (228 | ) |  |  | 578 |  |
| Cash, cash equivalents and restricted cash at end of period |  | $ | 231,540 |  |  | $ | 166,407 |  |
| Non-cash investing and financing activities |  |  |  |  |  |  |  |  |
| Construction, software and equipment-related payables |  | $ | 11,906 |  |  | $ | 3,286 |  |

[0001193125-20-132426:8k_2_02:43]
FABRINET

[0001193125-20-132426:8k_2_02:44]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (CONTINUED)

[0001193125-20-132426:8k_2_02:45]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the unaudited condensed
consolidated balance sheets that sum to the total of the same amounts shown in the unaudited condensed consolidated statements of cash flows:

[0001193125-20-132426:8k_2_02:46]
| (amount in thousands) |  | As ofMarch 27,2020 |  |  | As ofMarch 29,2019 |  |
| Cash and cash equivalents |  | $ | 224,138 |  |  | $ | 166,407 |  |
| Restricted cash |  |  | 7,402 |  |  |  | — |  |
| Cash, cash equivalents and restricted cash |  | $ | 231,540 |  |  | $ | 166,407 |  |

[0001193125-20-132426:8k_2_02:47]
FABRINET

[0001193125-20-132426:8k_2_02:48]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-20-132426:8k_2_02:49]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 27,2020 |  |  | March 29,2019 |  |  | March 27,2020 |  |  | March 29,2019 |  |
| (in thousands of U.S. dollars, except per share data) |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |
| GAAP measures |  |  | 28,267 |  |  |  | 0.75 |  |  |  | 28,635 |  |  |  | 0.76 |  |  |  | 85,455 |  |  |  | 2.27 |  |  |  | 87,998 |  |  |  | 2.35 |  |
| Items reconciling GAAP net (loss) income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,489 |  |  |  | 0.04 |  |  |  | 1,237 |  |  |  | 0.03 |  |  |  | 4,800 |  |  |  | 0.13 |  |  |  | 4,384 |  |  |  | 0.12 |  |
| Depreciation of fair value uplift |  |  | 86 |  |  |  | 0.00 |  |  |  | 82 |  |  |  | 0.00 |  |  |  | 247 |  |  |  | 0.01 |  |  |  | 255 |  |  |  | 0.01 |  |
| ASC 606 adoption impact on gross profit |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (31 | ) |  |  | (0.00 | ) |
| Total related to gross profit |  |  | 1,575 |  |  |  | 0.04 |  |  |  | 1,319 |  |  |  | 0.04 |  |  |  | 5,047 |  |  |  | 0.13 |  |  |  | 4,608 |  |  |  | 0.12 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 4,629 |  |  |  | 0.12 |  |  |  | 3,187 |  |  |  | 0.08 |  |  |  | 13,501 |  |  |  | 0.36 |  |  |  | 8,989 |  |  |  | 0.24 |  |
| Expenses related to CFO search |  |  | — |  |  |  | — |  |  |  | 285 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 857 |  |  |  | 0.02 |  |
| Amortization of intangibles |  |  | 145 |  |  |  | 0.00 |  |  |  | 163 |  |  |  | 0.00 |  |  |  | 431 |  |  |  | 0.01 |  |  |  | 531 |  |  |  | 0.01 |  |
| Business combination expenses and consulting fee |  |  | — |  |  |  | — |  |  |  | 88 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |  |  | 328 |  |  |  | 0.01 |  |
| Severance liabilities |  |  | 150 |  |  |  | 0.00 |  |  |  | 348 |  |  |  | 0.01 |  |  |  | 150 |  |  |  | 0.00 |  |  |  | 949 |  |  |  | 0.03 |  |
| Total related to selling, general and administrative expenses |  |  | 4,924 |  |  |  | 0.13 |  |  |  | 4,071 |  |  |  | 0.11 |  |  |  | 14,082 |  |  |  | 0.37 |  |  |  | 11,654 |  |  |  | 0.31 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other expenses in relation to reduction in workforce |  |  | — |  |  |  | — |  |  |  | 323 |  |  |  | 0.01 |  |  |  | 16 |  |  |  | 0.00 |  |  |  | 727 |  |  |  | 0.02 |  |
| Amortization of debt issuance costs |  |  | 8 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |  |  | 18 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |
| Total related to other incomes and other expenses |  |  | 8 |  |  |  | 0.00 |  |  |  | 323 |  |  |  | 0.01 |  |  |  | 34 |  |  |  | 0.00 |  |  |  | 727 |  |  |  | 0.02 |  |
| Total related to net income & EPS |  |  | 6,507 |  |  |  | 0.17 |  |  |  | 5,713 |  |  |  | 0.15 |  |  |  | 19,163 |  |  |  | 0.51 |  |  |  | 16,989 |  |  |  | 0.45 |  |
| Non-GAAP measures |  |  | 34,774 |  |  |  | 0.92 |  |  |  | 34,348 |  |  |  | 0.92 |  |  |  | 104,618 |  |  |  | 2.78 |  |  |  | 104,987 |  |  |  | 2.81 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 37,797 |  |  |  |  |  |  |  | 37,539 |  |  |  |  |  |  |  | 37,696 |  |  |  |  |  |  |  | 37,383 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 37,797 |  |  |  |  |  |  |  | 37,539 |  |  |  |  |  |  |  | 37,696 |  |  |  |  |  |  |  | 37,383 |  |

[0001193125-20-132426:8k_2_02:50]
FABRINET

[0001193125-20-132426:8k_2_02:51]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001193125-20-132426:8k_2_02:52]
| (amount in thousands) |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 27,2020 |  |  | March 29,2019 |  |  | March 27,2020 |  |  | March 29,2019 |  |
| Net cash provided by operating activities |  | $ | 51,838 |  |  | $ | 36,206 |  |  | $ | 104,448 |  |  | $ | 105,504 |  |
| Less: Purchase of property, plant and equipment |  |  | (12,071 | ) |  |  | (3,479 | ) |  |  | (27,482 | ) |  |  | (13,211 | ) |
| Non-GAAP free cash flow |  | $ | 39,767 |  |  | $ | 32,727 |  |  | $ | 76,966 |  |  | $ | 92,293 |  |

[0001193125-20-132426:8k_2_02:53]
FABRINET

[0001193125-20-132426:8k_2_02:54]
GUIDANCE FOR QUARTER ENDING JUNE 26, 2020

[0001193125-20-132426:8k_2_02:55]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-20-132426:8k_2_02:56]
|  |  | DilutedEPS |  |
| GAAP net income per diluted share: |  | $ | 0.64 to $0.76 |  |
| Related to cost of revenues: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.04 |  |
| Total related to gross profit |  |  | 0.04 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.12 |  |
| Total related to selling, general and administrative expenses |  |  | 0.12 |  |
| Total related to net income & EPS |  |  | 0.16 |  |
| Non-GAAP net income per diluted share |  | $ | 0.80 to $0.92 |  |
