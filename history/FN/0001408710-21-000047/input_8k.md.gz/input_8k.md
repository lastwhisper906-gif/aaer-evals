# FN 8-K — 0001408710-21-000045 filed 2021-11-01

## item codes, every 8-K on or before 2021-11-02

- 2021-11-01 0001408710-21-000045 — 2.02, 9.01
- 2021-08-16 0001408710-21-000031 — 2.02, 5.02, 9.01
- 2021-05-03 0001408710-21-000019 — 2.02, 9.01
- 2021-02-01 0001408710-21-000008 — 2.02, 9.01
- 2020-12-11 0001193125-20-315861 — 5.07
- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2021-11-02

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001408710-21-000045:8k_2_02:1]
EX-99.1
2
fn-20211101xex991q122.htm
EX-99.1

[0001408710-21-000045:8k_2_02:2]
Document

[0001408710-21-000045:8k_2_02:3]
EX-99.1

[0001408710-21-000045:8k_2_02:4]
Exhibit 99.1

[0001408710-21-000045:8k_2_02:5]
Fabrinet Announces First Quarter Fiscal Year 2022 Financial Results

[0001408710-21-000045:8k_2_02:6]
•Record First Quarter Revenue of $543.3 Million Exceeds Guidance

[0001408710-21-000045:8k_2_02:7]
BANGKOK, Thailand – November 1, 2021 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its first fiscal quarter ended September 24, 2021.

[0001408710-21-000045:8k_2_02:8]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “We had a strong start to fiscal 2022 with revenue and profitability that exceeded our guidance. By working in close partnership with our customers and suppliers, our supply chain team was effective at reducing the impact of component shortages on our business, particularly in the optical communications market.”

[0001408710-21-000045:8k_2_02:9]
Grady continued, “We are optimistic about continued strong demand across our business and are anticipating healthy sequential growth despite ongoing supply chain headwinds.”

[0001408710-21-000045:8k_2_02:10]
First Quarter Fiscal Year 2022 Financial Highlights

[0001408710-21-000045:8k_2_02:11]
GAAP Results

[0001408710-21-000045:8k_2_02:12]
•Revenue for the first quarter of fiscal year 2022 was $543.3 million, compared to $436.6 million in the first quarter of fiscal year 2021.

[0001408710-21-000045:8k_2_02:13]
•GAAP net income for the first quarter of fiscal year 2022 was $44.7 million, compared to GAAP net income of $33.1 million for the first quarter of fiscal year 2021.

[0001408710-21-000045:8k_2_02:14]
•GAAP net income per diluted share for the first quarter of fiscal year 2022 was $1.20, compared to GAAP net income per diluted share of $0.88 for the first quarter of fiscal year 2021.

[0001408710-21-000045:8k_2_02:15]
Non-GAAP Results

[0001408710-21-000045:8k_2_02:16]
•Non-GAAP net income for the first quarter of fiscal year 2022 was $54.2 million, compared to non-GAAP net income of $39.3 million for the first quarter of fiscal year 2021.

[0001408710-21-000045:8k_2_02:17]
•Non-GAAP net income per diluted share for the first quarter of fiscal year 2022 was $1.45, compared to non-GAAP net income per diluted share of $1.05 for the first quarter of fiscal year 2021.

[0001408710-21-000045:8k_2_02:18]
Business Outlook

[0001408710-21-000045:8k_2_02:19]
Based on information available as of November 1, 2021, Fabrinet is issuing guidance for its second fiscal quarter ending December 24, 2021, as follows:

[0001408710-21-000045:8k_2_02:20]
•Fabrinet expects second quarter revenue to be in the range of $540 million to $560 million.

[0001408710-21-000045:8k_2_02:21]
•GAAP net income per diluted share is expected to be in the range of $1.24 to $1.31, based on approximately 37.6 million fully diluted shares outstanding.

[0001408710-21-000045:8k_2_02:22]
•Non-GAAP net income per diluted share is expected to be in the range of $1.42 to $1.49, based on approximately 37.6 million fully diluted shares outstanding.

[0001408710-21-000045:8k_2_02:23]
EX-99.1

[0001408710-21-000045:8k_2_02:24]
Conference Call Information

[0001408710-21-000045:8k_2_02:25]
| What: |  | Fabrinet First Quarter Fiscal Year 2022 Financial Results Call |
| When: |  | Monday, November 1, 2021 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic(253) 237-1137, internationalPasscode: 2790505 |
| Replay: |  | (855) 859-2056, domestic(404) 537-3406, internationalPasscode: 2790505 |
| Webcast: |  | http://investor.fabrinet.com/ (live and replay) |

[0001408710-21-000045:8k_2_02:26]
This press release and any other information related to the call will also be posted on Fabrinet’s website at http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001408710-21-000045:8k_2_02:27]
About Fabrinet

[0001408710-21-000045:8k_2_02:28]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China, Israel and the United Kingdom. For more information visit: www.fabrinet.com.

[0001408710-21-000045:8k_2_02:29]
Forward-Looking Statements

[0001408710-21-000045:8k_2_02:30]
EX-99.1

[0001408710-21-000045:8k_2_02:31]
Use of Non-GAAP Financials

[0001408710-21-000045:8k_2_02:32]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; depreciation of fair value uplift; amortization of intangibles; and amortization of deferred debt issuance costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001408710-21-000045:8k_2_02:33]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001408710-21-000045:8k_2_02:34]
SOURCE: Fabrinet

[0001408710-21-000045:8k_2_02:35]
Investor Contact:

[0001408710-21-000045:8k_2_02:36]
Garo Toomajanian

[0001408710-21-000045:8k_2_02:37]
ir@fabrinet.com

[0001408710-21-000045:8k_2_02:38]
EX-99.1

[0001408710-21-000045:8k_2_02:39]
FABRINET

[0001408710-21-000045:8k_2_02:40]
CONDENSED CONSOLIDATED BALANCE SHEETS (unaudited)

[0001408710-21-000045:8k_2_02:41]
| (in thousands of U.S. dollars, except share data and par value) | September 24,2021 |  | June 25,2021 |
| Assets |  |  |  |
| Current assets |  |  |  |
| Cash and cash equivalents | $ | 269,911 |  |  | $ | 302,969 |  |
| Short-term investments | 258,501 |  |  | 244,963 |  |
| Trade accounts receivable, net of allowance for doubtful accounts of $99 and $100 respectively | 346,689 |  |  | 336,547 |  |
| Contract assets | 13,120 |  |  | 11,878 |  |
| Inventories | 465,251 |  |  | 422,133 |  |
| Prepaid expenses | 10,404 |  |  | 11,398 |  |
| Other current assets | 24,729 |  |  | 22,619 |  |
| Total current assets | 1,388,605 |  |  | 1,352,507 |  |
| Non-current assets |  |  |  |
| Long-term restricted cash | 155 |  |  | 154 |  |
| Property, plant and equipment, net | 271,659 |  |  | 241,129 |  |
| Intangibles, net | 4,107 |  |  | 4,371 |  |
| Operating right-of-use assets | 6,086 |  |  | 6,699 |  |
| Deferred tax assets | 9,491 |  |  | 9,428 |  |
| Other non-current assets | 518 |  |  | 1,834 |  |
| Total non-current assets | 292,016 |  |  | 263,615 |  |
| Total Assets | 1,680,621 |  |  | 1,616,122 |  |
| Liabilities and Shareholders’ Equity |  |  |  |
| Current liabilities |  |  |  |
| Long-term borrowings, current portion, net | 12,156 |  |  | 12,156 |  |
| Trade accounts payable | 373,663 |  |  | 346,555 |  |
| Fixed assets payable | 24,174 |  |  | 19,206 |  |
| Contract liabilities | 1,755 |  |  | 1,680 |  |
| Operating lease liabilities, current portion | 2,613 |  |  | 2,593 |  |
| Income tax payable | 2,776 |  |  | 3,612 |  |
| Accrued payroll, bonus and related expenses | 19,336 |  |  | 20,464 |  |
| Accrued expenses | 20,147 |  |  | 17,134 |  |
| Other payables | 22,599 |  |  | 20,958 |  |
| Total current liabilities | 479,219 |  |  | 444,358 |  |
| Non-current liabilities |  |  |  |
| Long-term borrowings, non-current portion, net | 24,319 |  |  | 27,358 |  |
| Deferred tax liability | 5,425 |  |  | 5,107 |  |
| Operating lease liability, non-current portion | 3,220 |  |  | 3,850 |  |
| Severance liabilities | 19,157 |  |  | 19,485 |  |
| Other non-current liabilities | 3,279 |  |  | 3,444 |  |
| Total non-current liabilities | 55,400 |  |  | 59,244 |  |
| Total Liabilities | 534,619 |  |  | 503,602 |  |
| Shareholders’ equity |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of September 24, 2021 and June 25, 2021) | — |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 39,000,843 shares and 38,749,045 shares issued at September 24, 2021 and June 25, 2021, respectively; and 37,017,254 shares and 36,765,456 shares outstanding at September 24, 2021 and June 25, 2021, respectively) | 390 |  |  | 388 |  |
| Additional paid-in capital | 179,670 |  |  | 189,445 |  |
| Less: Treasury shares (1,983,589 shares and 1,983,589 shares as of September 24, 2021 and June 25, 2021, respectively) | (87,343) |  |  | (87,343) |  |
| Accumulated other comprehensive income (loss) | (7,662) |  |  | (6,266) |  |
| Retained earnings | 1,060,947 |  |  | 1,016,296 |  |
| Total Shareholders’ Equity | 1,146,002 |  |  | 1,112,520 |  |
| Total Liabilities and Shareholders’ Equity | $ | 1,680,621 |  |  | $ | 1,616,122 |  |

[0001408710-21-000045:8k_2_02:42]
EX-99.1

[0001408710-21-000045:8k_2_02:43]
FABRINET

[0001408710-21-000045:8k_2_02:44]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME (unaudited)

[0001408710-21-000045:8k_2_02:45]
|  | Three Months Ended |
| (in thousands of U.S. dollars, except per share data) | September 24,2021 |  | September 25,2020 |
| Revenues | $ | 543,322 |  |  | $ | 436,639 |  |
| Cost of revenues | (479,725) |  |  | (386,159) |  |
| Gross profit | 63,597 |  |  | 50,480 |  |
| Selling, general and administrative expenses | (20,587) |  |  | (16,863) |  |
| Operating income | 43,010 |  |  | 33,617 |  |
| Interest income | 761 |  |  | 1,104 |  |
| Interest expense | (36) |  |  | (251) |  |
| Foreign exchange gain (loss), net | 1,772 |  |  | 128 |  |
| Other income (expense), net | (260) |  |  | 121 |  |
| Income before income taxes | 45,247 |  |  | 34,719 |  |
| Income tax expense | (596) |  |  | (1,668) |  |
| Net income | 44,651 |  |  | 33,051 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities | (213) |  |  | (325) |  |
| Change in net unrealized gain (loss) on derivative instruments | (1,217) |  |  | (3,208) |  |
| Change in net retirement benefits plan – prior service cost | 198 |  |  | 173 |  |
| Change in foreign currency translation adjustment | (164) |  |  | 603 |  |
| Total other comprehensive income (loss), net of tax | (1,396) |  |  | (2,757) |  |
| Net comprehensive income (loss) | $ | 43,255 |  |  | $ | 30,294 |  |
| Earnings per share |  |  |  |
| Basic | $ | 1.21 |  |  | $ | 0.90 |  |
| Diluted | $ | 1.20 |  |  | $ | 0.88 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |
| Basic | 36,877 |  |  | 36,818 |  |
| Diluted | 37,328 |  |  | 37,383 |  |

[0001408710-21-000045:8k_2_02:46]
EX-99.1

[0001408710-21-000045:8k_2_02:47]
FABRINET

[0001408710-21-000045:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited)

[0001408710-21-000045:8k_2_02:49]
|  | Three Months Ended |
| (in thousands of U.S. dollars) | September 24,2021 |  | September 25,2020 |
| Cash flows from operating activities |  |  |  |
| Net income for the period | $ | 44,651 |  |  | $ | 33,051 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 9,535 |  |  | 8,570 |  |
| (Gain) loss on disposal of property, plant and equipment | (98) |  |  | (19) |  |
| (Gain) loss from sales and maturities of available-for-sale securities | (13) |  |  | — |  |
| Amortization of investment discount | 1,109 |  |  | 481 |  |
| Amortization of deferred debt issuance costs | 8 |  |  | 8 |  |
| (Reversal of) allowance for doubtful accounts | (1) |  |  | (257) |  |
| Unrealized (gain) loss on exchange rate and fair value of foreign currency forward contracts | (1,436) |  |  | (890) |  |
| Amortization of fair value at hedge inception of interest rate swaps | (268) |  |  | (359) |  |
| Share-based compensation | 9,292 |  |  | 6,027 |  |
| Deferred income tax | (104) |  |  | 56 |  |
| Other non-cash expenses | 257 |  |  | 96 |  |
| Changes in operating assets and liabilities |  |  |  |
| Trade accounts receivable | (10,160) |  |  | (16,497) |  |
| Contract assets | (1,242) |  |  | 1,499 |  |
| Inventories | (43,135) |  |  | (29,643) |  |
| Other current assets and non-current assets | (385) |  |  | 7,812 |  |
| Trade accounts payable | 27,541 |  |  | 33,546 |  |
| Contract liabilities | 75 |  |  | (590) |  |
| Income tax payable | (747) |  |  | 871 |  |
| Severance liabilities | 893 |  |  | 745 |  |
| Other current liabilities and non-current liabilities | 3,243 |  |  | (10,001) |  |
| Net cash provided by operating activities | 39,015 |  |  | 34,506 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of short-term investments | (78,101) |  |  | (79,103) |  |
| Proceeds from sales of short-term investments | 19,463 |  |  | — |  |
| Proceeds from maturities of short-term investments | 43,791 |  |  | 33,750 |  |
| Purchase of property, plant and equipment | (34,616) |  |  | (12,572) |  |
| Purchase of intangibles | (321) |  |  | (530) |  |
| Proceeds from disposal of property, plant and equipment | 145 |  |  | 21 |  |
| Net cash used in investing activities | (49,639) |  |  | (58,434) |  |
| Cash flows from financing activities |  |  |  |
| Repayment of long-term borrowings | (3,047) |  |  | (3,047) |  |
| Repayment of finance lease liability | — |  |  | (100) |  |
| Withholding tax related to net share settlement of restricted share units | (19,065) |  |  | (9,920) |  |
| Net cash used in financing activities | (22,112) |  |  | (13,067) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | (32,736) |  |  | (36,995) |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at the beginning of period | 303,123 |  |  | 232,832 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | (32,736) |  |  | (36,995) |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash | (321) |  |  | 766 |  |
| Cash, cash equivalents and restricted cash at the end of period | 270,066 |  |  | 196,603 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment-related payables | $ | 24,174 |  |  | $ | 9,616 |  |

[0001408710-21-000045:8k_2_02:50]
EX-99.1

[0001408710-21-000045:8k_2_02:51]
FABRINET

[0001408710-21-000045:8k_2_02:52]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited) (Continued)

[0001408710-21-000045:8k_2_02:53]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the unaudited condensed consolidated balance sheets that sum to the total of the same amounts shown in the unaudited condensed consolidated statements of cash flows:

[0001408710-21-000045:8k_2_02:54]
|  | As of |
| (amount in thousands) | September 24,2021 |  | September 25,2020 |
| Cash and cash equivalents | $ | 269,911 |  |  | $ | 189,201 |  |
| Restricted cash | 155 |  |  | 7,402 |  |
| Cash, cash equivalents and restricted cash | $ | 270,066 |  |  | $ | 196,603 |  |

[0001408710-21-000045:8k_2_02:55]
EX-99.1

[0001408710-21-000045:8k_2_02:56]
FABRINET

[0001408710-21-000045:8k_2_02:57]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-21-000045:8k_2_02:58]
|  | Three Months Ended |  |
|  | September 24,2021 |  | September 25,2020 |  |
| (in thousands of U.S. dollars, except per share data) | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  |
| GAAP measures | $ | 44,651 |  |  | $ | 1.20 |  |  | $ | 33,051 |  |  | $ | 0.88 |  |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 1,975 |  |  | 0.05 |  |  | 1,825 |  |  | 0.05 |  |  |
| Depreciation of fair value uplift | 92 |  |  | 0.00 |  |  | 84 |  |  | 0.00 |  |  |
| Total related to gross profit | 2,067 |  |  | 0.05 |  |  | 1,909 |  |  | 0.05 |  |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 7,317 |  |  | 0.20 |  |  | 4,202 |  |  | 0.11 |  |  |
| Amortization of intangibles | 119 |  |  | 0.00 |  |  | 131 |  |  | 0.00 |  |  |
| Total related to selling, general and administrative expenses | 7,436 |  |  | 0.20 |  |  | 4,333 |  |  | 0.12 |  |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |
| Amortization of deferred debt issuance costs | 8 |  |  | 0.00 |  |  | 8 |  |  | 0.00 |  |  |
| Total related to other incomes and other expenses | 8 |  |  | 0.00 |  |  | 8 |  |  | 0.00 |  |  |
| Total related to net income & EPS | 9,511 |  |  | 0.25 |  |  | 6,250 |  |  | 0.17 |  |  |
| Non-GAAP measures | 54,162 |  |  | $ | 1.45 |  |  | 39,301 |  |  | $ | 1.05 |  |  |
| Shares used in computing diluted net income per share (thousands of shares) |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  | 37,328 |  |  |  |  | 37,383 |  |  |
| Non-GAAP diluted shares |  |  | 37,328 |  |  |  |  | 37,383 |  |  |

[0001408710-21-000045:8k_2_02:59]
EX-99.1

[0001408710-21-000045:8k_2_02:60]
FABRINET

[0001408710-21-000045:8k_2_02:61]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001408710-21-000045:8k_2_02:62]
| (amount in thousands) | Three Months Ended |
|  | September 24,2021 |  | September 25,2020 |
| Net cash provided by operating activities | $ | 39,015 |  |  | $ | 34,506 |  |
| Less: Purchase of property, plant and equipment | (34,616) |  |  | (12,572) |  |
| Non-GAAP free cash flow | $ | 4,399 |  |  | $ | 21,934 |  |

[0001408710-21-000045:8k_2_02:63]
FABRINET

[0001408710-21-000045:8k_2_02:64]
GUIDANCE FOR QUARTER ENDING DECEMBER 24, 2021

[0001408710-21-000045:8k_2_02:65]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-21-000045:8k_2_02:66]
|  | DilutedEPS |
| GAAP net income per diluted share: | $1.24 to $1.31 |
| Related to cost of revenues: |  |
| Share-based compensation expenses | 0.04 |
| Total related to gross profit | 0.04 |
| Related to selling, general and administrative expenses: |  |
| Share-based compensation expenses | 0.14 |
| Total related to selling, general and administrative expenses | 0.14 |
| Total related to net income & EPS | 0.18 |
| Non-GAAP net income per diluted share | $1.42 to $1.49 |
