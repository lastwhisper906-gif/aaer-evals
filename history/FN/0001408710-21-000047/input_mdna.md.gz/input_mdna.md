# FN MD&A — 0001408710-21-000047


## mdna

[0001408710-21-000047:mdna:1]
[same as prior period, unchanged from 0001408710-21-000022:mdna:1]

[0001408710-21-000047:mdna:2]
[same as prior period, unchanged from 0001408710-21-000022:mdna:2]

[0001408710-21-000047:mdna:3]
[same as prior period, unchanged from 0001408710-21-000022:mdna:3]

[0001408710-21-000047:mdna:4]
[same as prior period, unchanged from 0001408710-21-000022:mdna:4]

[0001408710-21-000047:mdna:5]
•our expectation that the portion of our revenues attributable to customers in regions outside of North America for the remainder of fiscal year 2022 will be in line with the portion of those revenues for the three months ended September 24, 2021;

[0001408710-21-000047:mdna:6]
[same as prior period, unchanged from 0001408710-21-000022:mdna:6]

[0001408710-21-000047:mdna:7]
•our expectation that our fiscal year 2022 selling, general and administrative (“SG&A”) expenses will increase as a percentage of revenue compared to fiscal year 2021 SG&A expenses;

[0001408710-21-000047:mdna:8]
[same as prior period, unchanged from 0001408710-21-000022:mdna:8]

[0001408710-21-000047:mdna:9]
[same as prior period, unchanged from 0001408710-21-000022:mdna:9]

[0001408710-21-000047:mdna:10]
[same as prior period, unchanged from 0001408710-21-000022:mdna:10]

[0001408710-21-000047:mdna:11]
[same as prior period, unchanged from 0001408710-21-000022:mdna:11]

[0001408710-21-000047:mdna:12]
[same as prior period, unchanged from 0001408710-21-000022:mdna:12]

[0001408710-21-000047:mdna:13]
•our expectations regarding the potential impact of the COVID-19 pandemic on our business, financial condition and operating results;

[0001408710-21-000047:mdna:14]
[same as prior period, unchanged from 0001408710-21-000022:mdna:14]

[0001408710-21-000047:mdna:15]
[same as prior period, unchanged from 0001408710-21-000022:mdna:15]

[0001408710-21-000047:mdna:16]
[same as prior period, unchanged from 0001408710-21-000022:mdna:16]

[0001408710-21-000047:mdna:17]
[same as prior period, unchanged from 0001408710-21-000022:mdna:17]

[0001408710-21-000047:mdna:18]
[same as prior period, unchanged from 0001408710-21-000022:mdna:18]

[0001408710-21-000047:mdna:19]
[same as prior period, unchanged from 0001408710-21-000022:mdna:19]

[0001408710-21-000047:mdna:20]
[same as prior period, unchanged from 0001408710-21-000022:mdna:20]

[0001408710-21-000047:mdna:21]
[same as prior period, unchanged from 0001408710-21-000022:mdna:21]

[0001408710-21-000047:mdna:22]
We provide advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers (“OEMs”) of complex products such as optical communication components, modules and sub-systems, industrial lasers, automotive components, medical devices and sensors. We offer a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, complex printed circuit board assembly, advanced packaging, integration, final assembly and testing. Although we focus primarily on low-volume production of a wide variety of high complexity products, which we refer to as “low-volume, high-mix,” we also have the capability to accommodate high-volume production. Based on our extensive experience and the positive feedback we have received from our customers, we believe we are a global leader in providing these services to the optical communications, industrial lasers and automotive markets.

[0001408710-21-000047:mdna:23]
Our customer base includes companies in complex industries that require advanced precision manufacturing capabilities such as optical communications, industrial lasers, automotive and sensors. The products that we manufacture for our OEM customers include: selective switching products; tunable transponders and transceivers; active optical cables; solid state, diode-pumped, gas and fiber lasers; and sensors. In many cases, we are the sole outsourced manufacturing partner used by our customers for the products that we manufacture for them.

[0001408710-21-000047:mdna:24]
[same as prior period, unchanged from 0001408710-21-000022:mdna:24]

[0001408710-21-000047:mdna:25]
[same as prior period, unchanged from 0001408710-21-000022:mdna:25]

[0001408710-21-000047:mdna:26]
The global COVID-19 pandemic has impacted us in several ways and created various challenges. At the onset of the pandemic, our PRC subsidiary, which manufactures custom optics components for us and other customers at its facility in Fuzhou, China, experienced a two-week temporary closure in January 2020 in accordance with the Chinese government’s official efforts to mitigate the spread of COVID-19. Furthermore, travel restrictions in the PRC during that period resulted in fewer than 90% of our employees in the PRC being able to return to work before early March 2020. Our other global manufacturing facilities also have been affected by government restrictions put in place to slow the spread of COVID-19. While our operations in Thailand have not been suspended, we have implemented a number of safety protocols to allow our operations in our facilities there to continue in accordance with government regulations. With the exception of our facility in Santa Clara, California, which closed for approximately one week beginning in late March 2020 before reopening in early April 2020 as a previously classified “essential business,” our facilities in the U.S., including in New Jersey, and in the U.K. have remained open while adhering to the local government restrictions.

[0001408710-21-000047:mdna:27]
During the three months ended September 24, 2021, several countries where we have manufacturing facilities, including Thailand, the PRC, the U.S. and the U.K., experienced a surge in the number of COVID-19 cases. In Thailand, we have recently experienced an increase in the number of employees who have tested positive for COVID-19. We have responded by taking additional precautionary measures based on recommendations from local authorities. These precautionary measures include implementing leaves of absence for affected employees and their close contacts, stringent contact tracing, enhanced safe distancing measures, and arrangements for the vaccination of our employees in Thailand. Although we did not experience any significant disruptions in our operations or decrease in customer demand during the three months ended September 24, 2021, any worsening of the pandemic may result in more stringent recommendations or requirements being implemented by local authorities, such as shutting down our manufacturing facilities, which would have a significant negative impact on our operations.

[0001408710-21-000047:mdna:28]
The health and well-being of our employees continues to be our top priority. In early 2020, we implemented significant precautionary measures throughout our worldwide operations to ensure our employees and their families remain safe. Such measures include mandatory temperature detection at building entrances, rigorous and regular facility and equipment disinfection, and mandatory personal protective equipment protocols, including (1) requiring the wearing of face masks throughout our factories at all times; (2) distributing our employees across shifts to better maintain safe personal distances; (3) isolating incoming parts and materials for a week or more prior to unpacking, or applying extreme heat to kill potential viruses; (4) directing our non-factory personnel to work remotely; and (5) restricting all non-employee visits to our campuses.

[0001408710-21-000047:mdna:29]
Given the unprecedented human and economic impact of the COVID-19 pandemic globally, the extraordinary economic short-term uncertainty resulting therefrom, and the evolving and differing national strategies for dealing with COVID-19, it is challenging to provide a forward-looking assessment. However, despite uncertainty and concern about the global economy and

[0001408710-21-000047:mdna:30]
the health of various industries, we can share some relevant perspectives as we continue to assess the impacts of COVID-19 on our business in the future:

[0001408710-21-000047:mdna:31]
•With work-from-home protocols in place around the world, global demand for internet bandwidth has grown and we believe it will continue to grow. Because the next-generation telecom and datacom products we manufacture for our customers are important to expanding network capacity, we believe such growth in bandwidth demand will have a positive impact on our business in the long-term.

[0001408710-21-000047:mdna:32]
•While we believe the long-term growth outlook for the markets we serve has not been significantly impacted, in the short-term we are likely to continue to see regional downward demand adjustments, especially if the COVID-19 outbreak intensifies or returns in various geographic areas as was the case at the end of our third quarter in fiscal year 2020.

[0001408710-21-000047:mdna:33]
•We expect we will continue to experience disruptions in our supply chain and the availability of parts and materials will continue to fluctuate, especially if the COVID-19 outbreak intensifies or returns in various geographic areas. However, we believe we can mitigate these disruptions by continuing to identify and secure alternative supply chain sources.

[0001408710-21-000047:mdna:34]
•A significant portion of our costs is variable and, because of this, we can adjust manufacturing costs relatively quickly to respond to the changing demand of our customers. However, because parts and materials account for the largest portion of our costs, in combination with the supply chain issues noted above and, to a lesser extent, the expenses associated with the safety and health protocols we have implemented across our global operations, our gross margins will continue to be negatively affected for the foreseeable future.

[0001408710-21-000047:mdna:35]
•The safety and health of our employees is and will remain a key priority, and we will continue to follow robust safety protocols in all of our facilities. To this end, we have arranged for the vaccination of our employees in Thailand in the first quarter of fiscal year 2022.

[0001408710-21-000047:mdna:36]
•Given our $528.4 million in cash, cash equivalents and short-term investments, and our total debt of approximately $36.6 million, as of September 24, 2021, we believe we are in a solid position from a capital and financial resources perspective. We expect that our current cash and cash equivalent balances, short-term investments, and cash flows generated from operations will be sufficient to meet our domestic and international working capital needs and other capital and liquidity requirements for at least the next 12 months.

[0001408710-21-000047:mdna:37]
[same as prior period, unchanged from 0001408710-21-000022:mdna:35]

[0001408710-21-000047:mdna:38]
[same as prior period, unchanged from 0001408710-21-000022:mdna:36]

[0001408710-21-000047:mdna:39]
[same as prior period, unchanged from 0001408710-21-000022:mdna:37]

[0001408710-21-000047:mdna:40]
[same as prior period, unchanged from 0001408710-21-000022:mdna:38]

[0001408710-21-000047:mdna:41]
The percentage of our revenues generated from a bill-to location outside of North America increased from 52.5% in the three months ended September 25, 2020 to 54.6% in the three months ended September 24, 2021, primarily because the increase in sales to our customers outside of North America was greater than the increase in sales to our customers in North America.

[0001408710-21-000047:mdna:42]
Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside North America for the remainder of fiscal year 2022 will be in line with the portion of revenues attributable to such customers during the three months ended September 24, 2021.

[0001408710-21-000047:mdna:43]
[same as prior period, unchanged from 0001408710-21-000022:mdna:42]

[0001408710-21-000047:mdna:44]
|  | Three Months Ended |
|  | September 24, 2021 |  | September 25, 2020 |
| North America | 45.4 | % |  | 47.5 | % |
| Asia-Pacific and others | 37.9 |  |  | 33.4 |  |
| Europe | 16.7 |  |  | 19.1 |  |
|  | 100.0 | % |  | 100.0 | % |

[0001408710-21-000047:mdna:45]
[same as prior period, unchanged from 0001408710-21-000022:mdna:44]

[0001408710-21-000047:mdna:46]
[same as prior period, unchanged from 0001408710-21-000022:mdna:45]

[0001408710-21-000047:mdna:47]
[same as prior period, unchanged from 0001408710-21-000022:mdna:46]

[0001408710-21-000047:mdna:48]
[same as prior period, unchanged from 0001408710-21-000022:mdna:47]

[0001408710-21-000047:mdna:49]
[same as prior period, unchanged from 0001408710-21-000022:mdna:48]

[0001408710-21-000047:mdna:50]
[same as prior period, unchanged from 0001408710-21-000022:mdna:49]

[0001408710-21-000047:mdna:51]
[same as prior period, unchanged from 0001408710-21-000022:mdna:50]

[0001408710-21-000047:mdna:52]
[same as prior period, unchanged from 0001408710-21-000022:mdna:51]

[0001408710-21-000047:mdna:53]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative and other support personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other general expenses not related to cost of revenues. In fiscal year 2022, we expect our SG&A expenses will increase as compared with our fiscal year 2021 SG&A expenses due to an increase in management compensation, staff cost, marketing and business development cost.

[0001408710-21-000047:mdna:54]
The compensation committee of our board of directors approved a fiscal year 2022 executive incentive plan with quantitative objectives that are based solely on achieving certain revenue targets and non-GAAP operating margin targets for our fiscal year ending June 24, 2022. Bonuses under the fiscal year 2022 executive incentive plan are payable after the end of fiscal year 2022. In fiscal year 2021, the compensation committee of our board of directors approved a fiscal year 2021 executive incentive plan with quantitative objectives based solely on achieving certain revenue targets and non-GAAP operating margin targets for fiscal year 2021.

[0001408710-21-000047:mdna:55]
[same as prior period, unchanged from 0001408710-21-000022:mdna:54]

[0001408710-21-000047:mdna:56]
[same as prior period, unchanged from 0001408710-21-000022:mdna:55]

[0001408710-21-000047:mdna:57]
[same as prior period, unchanged from 0001408710-21-000022:mdna:56]

[0001408710-21-000047:mdna:58]
[same as prior period, unchanged from 0001408710-21-000022:mdna:57]

[0001408710-21-000047:mdna:59]
[same as prior period, unchanged from 0001408710-21-000022:mdna:58]

[0001408710-21-000047:mdna:60]
|  | As of September 24, 2021 |  | As of June 25, 2021 |
| (amount in thousands, except percentages) | Currency |  | $ |  | % |  | Currency |  | $ |  | % |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 756,692 |  |  | $ | 22,581 |  |  | 57.5 | % |  | 1,472,249 |  |  | $ | 46,312 |  |  | 67.5 | % |
| RMB | 56,396 |  |  | 8,730 |  |  | 22.2 |  |  | 98,056 |  |  | 15,145 |  |  | 22.1 |  |
| GBP | 5,833 |  |  | 7,950 |  |  | 20.3 |  |  | 5,111 |  |  | 7,119 |  |  | 10.4 |  |
| Total |  |  | $ | 39,261 |  |  | 100.0 | % |  |  |  | $ | 68,576 |  |  | 100.0 | % |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 2,729,136 |  |  | $ | 81,442 |  |  | 89.8 | % |  | 2,250,514 |  |  | $ | 70,793 |  |  | 87.7 | % |
| RMB | 40,456 |  |  | 6,263 |  |  | 6.9 |  |  | 40,112 |  |  | 6,195 |  |  | 7.7 |  |
| GBP | 2,164 |  |  | 2,949 |  |  | 3.3 |  |  | 2,656 |  |  | 3,699 |  |  | 4.6 |  |
| Total |  |  | $ | 90,654 |  |  | 100.0 | % |  |  |  | $ | 80,687 |  |  | 100.0 | % |

[0001408710-21-000047:mdna:61]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of September 24, 2021, there was $135.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 25, 2021, there was $130.0 million of foreign currency forward contracts outstanding on the Thai baht payables.

[0001408710-21-000047:mdna:62]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of September 24, 2021 and June 25, 2021, we did not have any derivative contracts denominated in RMB.

[0001408710-21-000047:mdna:63]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable and other payables. As of September 24, 2021 and June 25, 2021, we did not have any derivative contracts denominated in GBP.

[0001408710-21-000047:mdna:64]
For the three months ended September 24, 2021 and September 25, 2020, we recorded losses of $0.6 million and $1.5 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-21-000047:mdna:65]
[same as prior period, unchanged from 0001408710-21-000022:mdna:65]

[0001408710-21-000047:mdna:66]
[same as prior period, unchanged from 0001408710-21-000022:mdna:66]

[0001408710-21-000047:mdna:67]
[same as prior period, unchanged from 0001408710-21-000022:mdna:67]

[0001408710-21-000047:mdna:68]
[same as prior period, unchanged from 0001408710-21-000022:mdna:68]

[0001408710-21-000047:mdna:69]
[same as prior period, unchanged from 0001408710-21-000022:mdna:69]

[0001408710-21-000047:mdna:70]
[same as prior period, unchanged from 0001408710-21-000022:mdna:70]

[0001408710-21-000047:mdna:71]
[same as prior period, unchanged from 0001408710-21-000022:mdna:71]

[0001408710-21-000047:mdna:72]
[same as prior period, unchanged from 0001408710-21-000022:mdna:72]

[0001408710-21-000047:mdna:73]
[same as prior period, unchanged from 0001408710-21-000022:mdna:73]

[0001408710-21-000047:mdna:74]
[same as prior period, unchanged from 0001408710-21-000022:mdna:74]

[0001408710-21-000047:mdna:75]
[same as prior period, unchanged from 0001408710-21-000022:mdna:75]

[0001408710-21-000047:mdna:76]
[same as prior period, unchanged from 0001408710-21-000022:mdna:76]

[0001408710-21-000047:mdna:77]
[same as prior period, unchanged from 0001408710-21-000022:mdna:77]

[0001408710-21-000047:mdna:78]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption on income generated from projects to manufacture certain products at our Chonburi campus is currently available to us through June 2026. Similar preferential tax treatment was available to us through June 2020 with respect to products manufactured at our Pinehurst campus Building 6. After June 2020, 50% of our income generated from products manufactured at our Pinehurst campus will be exempted from tax through June 2025. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted. Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001408710-21-000047:mdna:79]
The corporate income tax rates for our subsidiaries in the PRC, the U.S., the U.K. and Israel are 25% , 21%, 19% and 23%, respectively.

[0001408710-21-000047:mdna:80]
[same as prior period, unchanged from 0001408710-21-000022:mdna:81]

[0001408710-21-000047:mdna:81]
[same as prior period, unchanged from 0001408710-21-000022:mdna:82]

[0001408710-21-000047:mdna:82]
Our critical accounting policies are disclosed in our Annual Report on Form10-K for the fiscal year ended June 25, 2021. The adoption of new accounting policies and accounting standards are disclosed in Note 2 to the unaudited condensed consolidated financial statements. There were no changes to our accounting policies.

[0001408710-21-000047:mdna:83]
[same as prior period, unchanged from 0001408710-21-000022:mdna:84]

[0001408710-21-000047:mdna:84]
[same as prior period, unchanged from 0001408710-21-000022:mdna:85]

[0001408710-21-000047:mdna:85]
| (amount in thousands) | Three Months Ended |
| September 24,2021 |  | September 25,2020 |
| Revenues | $ | 543,322 |  |  | $ | 436,639 |  |
| Cost of revenues | (479,725) |  |  | (386,159) |  |
| Gross profit | 63,597 |  |  | 50,480 |  |
| Selling, general and administrative expenses | (20,587) |  |  | (16,863) |  |
| Operating income | 43,010 |  |  | 33,617 |  |
| Interest income | 761 |  |  | 1,104 |  |
| Interest expense | (36) |  |  | (251) |  |
| Foreign exchange gain (loss), net | 1,772 |  |  | 128 |  |
| Other income (expense), net | (260) |  |  | 121 |  |
| Income before income taxes | 45,247 |  |  | 34,719 |  |
| Income tax expense | (596) |  |  | (1,668) |  |
| Net income | 44,651 |  |  | 33,051 |  |
| Other comprehensive income (loss), net of tax | (1,396) |  |  | (2,757) |  |
| Net comprehensive income | $ | 43,255 |  |  | $ | 30,294 |  |

[0001408710-21-000047:mdna:86]
[same as prior period, unchanged from 0001408710-21-000022:mdna:87]

[0001408710-21-000047:mdna:87]
|  | Three Months Ended |
|  | September 24,2021 |  | September 25,2020 |
| Revenues | 100.0 | % |  | 100.0 | % |
| Cost of revenues | (88.3) |  |  | (88.4) |  |
| Gross profit | 11.7 |  |  | 11.6 |  |
| Selling, general and administrative expenses | (3.8) |  |  | (3.9) |  |
| Operating income | 7.9 |  |  | 7.7 |  |
| Interest income | 0.1 |  |  | 0.3 |  |
| Interest expense | 0.0 |  |  | (0.1) |  |
| Foreign exchange gain (loss), net | 0.3 |  |  | 0.0 |  |
| Other income (expense), net | (0.0) |  |  | 0.0 |  |
| Income before income taxes | 8.3 |  |  | 7.9 |  |
| Income tax expense | (0.1) |  |  | (0.4) |  |
| Net income | 8.2 |  |  | 7.5 |  |
| Other comprehensive income (loss), net of tax | (0.2) |  |  | (0.6) |  |
| Net comprehensive income | 8.0 | % |  | 6.9 | % |

[0001408710-21-000047:mdna:88]
35

[0001408710-21-000047:mdna:89]
[same as prior period, unchanged from 0001408710-21-000022:mdna:90]

[0001408710-21-000047:mdna:90]
|  | Three Months Ended |
| (amount in thousands) | September 24,2021 |  | September 25,2020 |
| Optical communications | $ | 427,301 |  |  | $ | 343,917 |  |
| Lasers, sensors and other | 116,021 |  |  | 92,722 |  |
| Total | $ | 543,322 |  |  | $ | 436,639 |  |

[0001408710-21-000047:mdna:91]
[same as prior period, unchanged from 0001408710-21-000022:mdna:92]

[0001408710-21-000047:mdna:92]
Comparison of Three Months Ended September 24, 2021 with Three Months Ended September 25, 2020

[0001408710-21-000047:mdna:93]
[same as prior period, unchanged from 0001408710-21-000022:mdna:94]

[0001408710-21-000047:mdna:94]
Our revenues increased by $106.7 million, or 24.4%, to $543.3 million for the three months ended September 24, 2021, compared with $436.6 million for the three months ended September 25, 2020. This increase was due to an increase in our key customers’ demand for optical communications manufacturing services during the three months ended September 24, 2021. Revenues from optical communications products increased by $83.4 million, or 24.2%, for the three months ended September 24, 2021.

[0001408710-21-000047:mdna:95]
[same as prior period, unchanged from 0001408710-21-000022:mdna:97]

[0001408710-21-000047:mdna:96]
Our cost of revenues increased by $93.6 million, or 24.2%, to $479.7 million, or 88.3% of revenues, for the three months ended September 24, 2021, compared with $386.2 million, or 88.4% of revenues, for the three months ended September 25, 2020. This increase in cost of revenues on an absolute dollar basis was in line with the increase in sales volume.

[0001408710-21-000047:mdna:97]
[same as prior period, unchanged from 0001408710-21-000022:mdna:100]

[0001408710-21-000047:mdna:98]
Our gross profit increased by $13.1 million, or 26.0%, to $63.6 million, or 11.7% of revenues, for the three months ended September 24, 2021, compared with $50.5 million, or 11.6% of revenues, for the three months ended September 25, 2020. The increase was primarily due to an increase in sales volume.

[0001408710-21-000047:mdna:99]
[same as prior period, unchanged from 0001408710-21-000022:mdna:103]

[0001408710-21-000047:mdna:100]
Our SG&A expenses increased by $3.7 million, or 22.1%, to $20.6 million, or 3.8% of revenues, for the three months ended September 24, 2021, compared with $16.9 million, or 3.9% of revenues, for the three months ended September 25, 2020. The increase was primarily due to (1) an increase in share-based compensation expenses of $3.1 million, (2) an increase in cost of development business unit of $0.4 million, and (3) a reversal of allowance for doubtful accounts of $0.3 million in fiscal year 2021.

[0001408710-21-000047:mdna:101]
[same as prior period, unchanged from 0001408710-21-000022:mdna:107]

[0001408710-21-000047:mdna:102]
Our operating income increased by $9.4 million to $43.0 million, or 7.9% of revenues, for the three months ended September 24, 2021, compared with $33.6 million, or 7.7% of revenues, for the three months ended September 25, 2020. The increase was primarily due to an increase in revenues.

[0001408710-21-000047:mdna:103]
[same as prior period, unchanged from 0001408710-21-000022:mdna:110]

[0001408710-21-000047:mdna:104]
Our interest income decreased by $0.3 million, or 31.1%, to $0.8 million, or 0.1% of revenues, for the three months ended September 24, 2021, compared with $1.1 million, or 0.3% of revenues, for the three months ended September 25, 2020. The decrease was primarily due to a lower weighted average interest rate following the global interest rate trend.

[0001408710-21-000047:mdna:105]
[same as prior period, unchanged from 0001408710-21-000022:mdna:113]

[0001408710-21-000047:mdna:106]
Our interest expense decreased by $0.2 million to $36.0 thousand for the three months ended September 24, 2021, compared with $0.3 million for the three months ended September 25, 2020. The decrease was primarily due to the

[0001408710-21-000047:mdna:107]
capitalization of interest expense on the new building at our Chonburi campus of $0.3 million, offset by lower amortization of the fair value of interest rate swaps of $0.1 million during the three months ended September 24, 2021, compared with the three months ended September 25, 2020.

[0001408710-21-000047:mdna:108]
[same as prior period, unchanged from 0001408710-21-000022:mdna:116]

[0001408710-21-000047:mdna:109]
We recorded foreign exchange gain, net of $1.8 million for the three months ended September 24, 2021, compared with foreign exchange gain, net of $0.1 million for the three months ended September 25, 2020. The increase in foreign exchange gain was mainly due to (1) lower unrealized loss from mark-to-market forward contracts of $0.6 million for the three months ended September 24, 2021, as compared to unrealized loss from mark-to-market forward contracts of $1.5 million for the three months ended September 25, 2020, (2) higher realized foreign exchange gain from payment/receipt of $0.3 million for the three months ended September 24, 2021, as compared to realized loss of $0.4 million for the three months ended September 25, 2020, and (3) higher unrealized gain from foreign exchange gain from the revaluation of outstanding Thai baht assets and liabilities of $2.2 million for the three months ended September 24, 2021, as compared to an unrealized gain of $2.0 million for the three months ended September 25, 2020, partially offset by higher foreign exchange loss from our subsidiaries in the PRC and the U.K., totaling $0.1 million for the three months ended September 24, 2021, as compared to foreign exchange loss totaling $78 thousand which mainly came from our subsidiaries in the PRC and the U.K. for the three months ended September 25, 2020.

[0001408710-21-000047:mdna:110]
[same as prior period, unchanged from 0001408710-21-000022:mdna:120]

[0001408710-21-000047:mdna:111]
We recorded income before income taxes of $45.2 million for the three months ended September 24, 2021, compared with $34.7 million for the three months ended September 25, 2020.

[0001408710-21-000047:mdna:112]
[same as prior period, unchanged from 0001408710-21-000022:mdna:122]

[0001408710-21-000047:mdna:113]
Our provision for income tax reflects an effective tax rate of 1.3% and 4.8% for the three months ended September 24, 2021 and September 25, 2020, respectively. The decrease was primarily due to an increase in income not subject to tax during the first quarter of fiscal year 2022 as compared to the same period in fiscal year 2021. The effective tax rate for fiscal 2022 is expected to be lower as compared to fiscal year 2021 due to an anticipated increase in income generated in jurisdictions with tax exemption or preferential tax rate.

[0001408710-21-000047:mdna:114]
[same as prior period, unchanged from 0001408710-21-000022:mdna:125]

[0001408710-21-000047:mdna:115]
We recorded net income of $44.7 million, or 8.2% of revenues, for the three months ended September 24, 2021, compared with $33.1 million, or 7.6% of revenues, for the three months ended September 25, 2020.

[0001408710-21-000047:mdna:116]
[same as prior period, unchanged from 0001408710-21-000022:mdna:128]

[0001408710-21-000047:mdna:117]
We recorded other comprehensive loss of $1.4 million, or 0.2% of revenues, for the three months ended September 24, 2021, compared with other comprehensive loss of $2.8 million, or 0.6% of revenues, for the three months ended September 25, 2020. The decrease in other comprehensive loss was mainly due to (1) unrealized loss from mark-to-market of forward contracts and interest rate swap agreement of $1.2 million for the three months ended September 24, 2021, as compared to unrealized loss from mark-to-market of forward contracts and interest rate swap agreement of $3.2 million for the three months ended September 25, 2020, and (2) unrealized loss from mark-to-market of available-for-sale debt securities of $0.2 million for the three months ended September 24, 2021, as compared to unrealized loss from mark-to-market of available-for-sale debt securities of $0.3 million for the three months ended September 25, 2020, partially offset by an unrealized loss from foreign currency translation adjustment of $0.2 million for the three months ended September 24, 2021, as compared to unrealized gain from foreign currency translation adjustment of $0.6 million for the three months ended September 25, 2020.

[0001408710-21-000047:mdna:118]
[same as prior period, unchanged from 0001408710-21-000022:mdna:131]

[0001408710-21-000047:mdna:119]
[same as prior period, unchanged from 0001408710-21-000022:mdna:132]

[0001408710-21-000047:mdna:120]
We primarily finance our operations through cash flow from operations. As of September 24, 2021 and September 25, 2020, we had cash, cash equivalents, and short-term investments of $528.4 million and $496.4 million, respectively, and outstanding debt of $36.6 million and $48.6 million, respectively.

[0001408710-21-000047:mdna:121]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents for the three months ended September 24, 2021 and September 25, 2020, was 0.7% and 0.9%, respectively.

[0001408710-21-000047:mdna:122]
[same as prior period, unchanged from 0001408710-21-000022:mdna:135]

[0001408710-21-000047:mdna:123]
During the three months ended September 24, 2021, we repaid $3.0 million of the term loan under our credit facility agreement with the Bank of Ayudhya Public Company Limited. As a result, as of September 24, 2021, we had a long-term borrowing of $36.6 million under such credit facility agreement. (See Note 12 for further details.) We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held short-term investments of $258.5 million as of September 24, 2021.

[0001408710-21-000047:mdna:124]
We believe that our current cash and cash equivalents, short-term investments, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001408710-21-000047:mdna:125]
[same as prior period, unchanged from 0001408710-21-000022:mdna:138]

[0001408710-21-000047:mdna:126]
[same as prior period, unchanged from 0001408710-21-000022:mdna:139]

[0001408710-21-000047:mdna:127]
|  | Three Months Ended |
| (amount in thousands) | September 24, 2021 |  | September 25, 2020 |
| Net cash provided by operating activities | $ | 39,015 |  |  | $ | 34,506 |  |
| Net cash used in investing activities | $ | (49,639) |  |  | $ | (58,434) |  |
| Net cash used in financing activities | $ | (22,112) |  |  | $ | (13,067) |  |
| Net increase in cash, cash equivalents and restricted cash | $ | (32,736) |  |  | $ | (36,995) |  |

[0001408710-21-000047:mdna:128]
[same as prior period, unchanged from 0001408710-21-000022:mdna:141]

[0001408710-21-000047:mdna:129]
Net cash provided by operating activities of $39.0 million for the three months ended September 24, 2021 was primarily due to (1) net income of $44.7 million, (2) an increase in trade accounts payable of $27.5 million, and (3) depreciation and amortization of $9.5 million; offset by an increase in inventories of $43.1 million to support new business.

[0001408710-21-000047:mdna:130]
Net cash provided by operating activities of $34.5 million for the three months ended September 25, 2020 was primarily due to (1) an increase in trade accounts payable of $33.5 million, (2) net income of $33.1 million, (3) depreciation and amortization of $8.6 million, and (4) share-based compensation of $6.0 million; offset by (1) an increase in inventories of $29.6 million; and (2) an increase in trade accounts receivable of $16.5 million.

[0001408710-21-000047:mdna:131]
[same as prior period, unchanged from 0001408710-21-000022:mdna:143]

[0001408710-21-000047:mdna:132]
Net cash used in investing activities of $49.6 million for the three months ended September 24, 2021 was primarily due to (1) the purchase of property, plant and equipment of $34.6 million, (2) a net purchase of short-term investments of $14.8 million, and (3) the purchase of intangibles assets of $0.3 million.

[0001408710-21-000047:mdna:133]
Net cash used in investing activities of $58.4 million for the three months ended September 25, 2020 was primarily due to (1) a net purchase of short-term investments of $45.4 million, (2) the purchase of property, plant and equipment of $12.6 million, and (3) the purchase of intangibles assets of $0.5 million.

[0001408710-21-000047:mdna:134]
[same as prior period, unchanged from 0001408710-21-000022:mdna:145]

[0001408710-21-000047:mdna:135]
Net cash used in financing activities of $22.1 million for the three months ended September 24, 2021 was primarily due to (1) cash paid for withholding tax related to net share settlement of restricted share units of $19.1 million; and (2) repayment of bank loans of $3.0 million.

[0001408710-21-000047:mdna:136]
Net cash used in financing activities of $13.1 million for the three months ended September 25, 2020 was primarily due to (1) cash paid for withholding tax related to net share settlement of restricted share units of $9.9 million; and (2) repayment of loans to banks of $3.0 million.

[0001408710-21-000047:mdna:137]
[same as prior period, unchanged from 0001408710-21-000022:mdna:147]

[0001408710-21-000047:mdna:138]
[same as prior period, unchanged from 0001408710-21-000022:mdna:148]
