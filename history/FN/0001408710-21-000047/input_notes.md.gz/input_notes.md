# FN notes — 0001408710-21-000047


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001408710-21-000047:notes:1]
[same as prior period, unchanged from 0001408710-21-000022:notes:1]

[0001408710-21-000047:notes:2]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of September 24, 2021 and for the three months ended September 24, 2021 and September 25, 2020 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 25, 2021.

[0001408710-21-000047:notes:3]
The balance sheet as of June 25, 2021 has been derived from the audited financial statements at that date but does not include all of the information and footnotes required by U.S. GAAP for complete financial statements.

[0001408710-21-000047:notes:4]
The results for the three months ended September 24, 2021 may not be indicative of results for the year ending June 24, 2022 or any future periods.

[0001408710-21-000047:notes:5]
[same as prior period, unchanged from 0001408710-21-000022:notes:5]

[0001408710-21-000047:notes:6]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information. Additionally, the extent to which the evolving COVID-19 pandemic impacts the Company’s unaudited condensed consolidated financial statements will depend on a number of factors, including the magnitude and duration of the pandemic. These estimates may change, as new events occur and additional information is obtained, as well as upon the occurrence of other factors related to the COVID-19 pandemic that could result in material impacts to the Company's unaudited condensed consolidated financial statements in future reporting periods.

[0001408710-21-000047:notes:7]
[same as prior period, unchanged from 0001408710-21-000022:notes:7]

[0001408710-21-000047:notes:8]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended September 24, 2021 and September 25, 2020 each consisted of 13 weeks. Fiscal year 2022 will be comprised of 52 weeks and will end on June 24, 2022.

[0001408710-21-000047:notes:9]
[same as prior period, unchanged from 0001408710-21-000022:notes:17]

[0001408710-21-000047:notes:10]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2019-12, “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.” The amendments in this update simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify U.S. GAAP for other areas of Topic 740 by clarifying and amending existing guidance. The Company adopted this standard in the first quarter of fiscal year 2022 with no material impact on its unaudited condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001408710-21-000047:notes:11]
[same as prior period, unchanged from 0001408710-21-000022:notes:45]

[0001408710-21-000047:notes:12]
[same as prior period, unchanged from 0001408710-21-000022:notes:46]

[0001408710-21-000047:notes:13]
[same as prior period, unchanged from 0001408710-21-000022:notes:47]

[0001408710-21-000047:notes:14]
| (amount in thousands, except percentages) | Three Months EndedSeptember 24, 2021 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 25, 2020 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 245,274 |  |  |  |  | 206,950 |  |  |  |
| Others | 1,316 |  |  |  |  | 452 |  |  |  |
| Total revenue in North America | 246,590 |  |  | 45.4 | % |  | 207,402 |  |  | 47.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 64,932 |  |  | (1) |  | 19 |  |  |  |
| Malaysia | 51,749 |  |  |  |  | 43,911 |  |  |  |
| Israel | 27,634 |  |  |  |  | 30,115 |  |  |  |
| Hong Kong | 21,031 |  |  |  |  | 23,505 |  |  |  |
| Japan | 14,977 |  |  |  |  | 20,332 |  |  |  |
| China | 13,635 |  |  |  |  | 13,787 |  |  |  |
| Others | 12,225 |  |  |  |  | 13,977 |  |  |  |
| Total revenue in Asia-Pacific and others | 206,183 |  |  | 37.9 | % |  | 145,646 |  |  | 33.4 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 49,484 |  |  |  |  | 53,611 |  |  |  |
| U.K. | 19,578 |  |  |  |  | 15,311 |  |  |  |
| Germany | 8,425 |  |  |  |  | 5,799 |  |  |  |
| Others | 13,062 |  |  |  |  | 8,870 |  |  |  |
| Total revenue in Europe | $ | 90,549 |  |  | 16.7 | % |  | $ | 83,591 |  |  | 19.1 | % |
| Total revenue | $ | 543,322 |  |  | 100.0 | % |  | $ | 436,639 |  |  | 100.0 | % |

[0001408710-21-000047:notes:15]
(1)Due to change in bill-to-location for certain customer.

[0001408710-21-000047:notes:16]
[same as prior period, unchanged from 0001408710-21-000022:notes:50]

[0001408710-21-000047:notes:17]
| (amount in thousands, except percentages) | Three Months EndedSeptember 24, 2021 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 25, 2020 |  | As a % of TotalRevenues |
| Optical communications | $ | 427,301 |  |  | 78.6 | % |  | $ | 343,917 |  |  | 78.8 | % |
| Lasers, sensors and other | 116,021 |  |  | 21.4 | % |  | 92,722 |  |  | 21.2 | % |
| Total | $ | 543,322 |  |  | 100.0 | % |  | $ | 436,639 |  |  | 100.0 | % |

[0001408710-21-000047:notes:18]
[same as prior period, unchanged from 0001408710-21-000022:notes:53]

[0001408710-21-000047:notes:19]
[same as prior period, unchanged from 0001408710-21-000022:notes:54]

[0001408710-21-000047:notes:20]
[same as prior period, unchanged from 0001408710-21-000022:notes:55]

[0001408710-21-000047:notes:21]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the three months ended September 24, 2021:

[0001408710-21-000047:notes:22]
| (amount in thousands) | ContractAssets |
| Beginning balance, June 25, 2021 | $ | 11,878 |  |
| Revenue recognized | 13,197 |  |
| Amounts collected or invoiced | (11,955) |  |
| Ending balance, September 24, 2021 | $ | 13,120 |  |

[0001408710-21-000047:notes:23]
| (amount in thousands) | ContractLiabilities |
| Beginning balance, June 25, 2021 | $ | 1,680 |  |
| Advance payment received during the period | 1,941 |  |
| Revenue recognized | (1,866) |  |
| Ending balance, September 24, 2021 | $ | 1,755 |  |


## us-gaap:EarningsPerShareTextBlock

[0001408710-21-000047:notes:24]
[same as prior period, unchanged from 0001408710-21-000022:notes:59]

[0001408710-21-000047:notes:25]
[same as prior period, unchanged from 0001408710-21-000022:notes:60]

[0001408710-21-000047:notes:26]
|  |  | Three Months Ended |
| (amount in thousands, except per share amounts) |  | September 24,2021 |  | September 25,2020 |
| Net income attributable to shareholders |  | $ | 44,651 |  |  | $ | 33,051 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  | 36,877 |  |  | 36,818 |  |
| Incremental shares arising from the assumed vesting of restricted share units and performance share units (thousands of shares) |  | 451 |  |  | 565 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  | 37,328 |  |  | 37,383 |  |
| Basic earnings per ordinary share |  | $ | 1.21 |  |  | $ | 0.90 |  |
| Diluted earnings per ordinary share |  | $ | 1.20 |  |  | $ | 0.88 |  |
| Outstanding performance share units excluded from the computation of diluted earnings per ordinary share (thousands of shares)(1) |  | — |  |  | 61 |  |

[0001408710-21-000047:notes:27]
[same as prior period, unchanged from 0001408710-21-000022:notes:62]


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001408710-21-000047:notes:28]
[same as prior period, unchanged from 0001408710-21-000022:notes:63]

[0001408710-21-000047:notes:29]
|  |  |  | Fair Value |
| (amount in thousands) | CarryingCost |  | UnrealizedGain/(Loss) |  | Cash andCashEquivalents |  | MarketableSecurities |  | OtherInvestments |
| As of September 24, 2021 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 223,409 |  |  | $ | — |  |  | $ | 223,409 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 46,502 |  |  | — |  |  | 46,502 |  |  | — |  |  | — |  |
| Liquidity funds | 31,278 |  |  | — |  |  | — |  |  | — |  |  | 31,278 |  |
| Corporate debt securities | 203,069 |  |  | 9 |  |  | — |  |  | 203,078 |  |  | — |  |
| U.S. agency and U.S. Treasury securities | 24,058 |  |  | 87 |  |  | — |  |  | 24,145 |  |  | — |  |
| Total | $ | 528,316 |  |  | $ | 96 |  |  | $ | 269,911 |  |  | $ | 227,223 |  |  | $ | 31,278 |  |
| As of June 25, 2021 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 222,664 |  |  | $ | — |  |  | $ | 222,664 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 80,305 |  |  | — |  |  | 80,305 |  |  | — |  |  | — |  |
| Liquidity funds | 30,000 |  |  | 1,226 |  |  | — |  |  | — |  |  | 31,226 |  |
| Certificates of deposit | 10,500 |  |  | — |  |  | — |  |  | — |  |  | 10,500 |  |
| Corporate debt securities | 171,626 |  |  | 164 |  |  | — |  |  | 171,790 |  |  | — |  |
| U.S. agency and U.S. Treasury securities | 31,301 |  |  | 146 |  |  | — |  |  | 31,447 |  |  | — |  |
| Total | $ | 546,396 |  |  | $ | 1,536 |  |  | $ | 302,969 |  |  | $ | 203,237 |  |  | $ | 41,726 |  |

[0001408710-21-000047:notes:30]
All highly liquid investments with original maturities of three months or less at the date of purchase are classified as cash equivalents. Management determines the appropriate classification of its investments at the time of purchase and reevaluates the designations at each balance sheet date. The Company may sell certain of its short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and

[0001408710-21-000047:notes:31]
duration management. The maturities of the Company’s short-term investments generally range from three months to three years.

[0001408710-21-000047:notes:32]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of September 24, 2021 and June 25, 2021:

[0001408710-21-000047:notes:33]
|  | September 24, 2021 |  | June 25, 2021 |
| (amount in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 69,219 |  |  | $ | 69,211 |  |  | $ | 30,000 |  |  | $ | 31,226 |  |
| Due between one to five years | 189,186 |  |  | 189,290 |  |  | 202,927 |  |  | 203,237 |  |
| Total | $ | 258,405 |  |  | $ | 258,501 |  |  | $ | 232,927 |  |  | $ | 234,463 |  |

[0001408710-21-000047:notes:34]
As of September 24, 2021, the Company considered the decline in market value of its available-for-sale debt securities by using the AFS debt security impairment model. The Company typically invests in highly-rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy requires investments generally to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. The Company assesses impairment at the individual security level according to applicable accounting standards by comparing fair value/market value with amortized cost. The Company considered factors such as the failure of the issuer of the security to make scheduled interest and principal payments and any changes to the credit rating of the security by a rating agency. The credit ratings of the Company's invested securities are still in compliance with the Company's investment policy. No impairment losses on available-for-sale debt securities were recorded for the three months ended September 24, 2021.

[0001408710-21-000047:notes:35]
The following table summarizes the carrying cost of short-term investments classified as held-to-maturity securities based on stated effective maturities as of September 24, 2021 and June 25, 2021:

[0001408710-21-000047:notes:36]
| (amount in thousands) | As of September 24, 2021 |  | As of June 25, 2021 |
| Due within one year | $ | — |  | (1) | $ | 10,500 |  |
| Due between one to five years | — |  |  | — |  |
| Total | $ | — |  |  | $ | 10,500 |  |

[0001408710-21-000047:notes:37]
(1)Short-term investments classified as held-to-maturity securities as of June 25, 2021 matured in July 2021.


## us-gaap:FairValueDisclosuresTextBlock

[0001408710-21-000047:notes:38]
[same as prior period, unchanged from 0001408710-21-000022:notes:68]

[0001408710-21-000047:notes:39]
[same as prior period, unchanged from 0001408710-21-000022:notes:69]

[0001408710-21-000047:notes:40]
[same as prior period, unchanged from 0001408710-21-000022:notes:70]

[0001408710-21-000047:notes:41]
[same as prior period, unchanged from 0001408710-21-000022:notes:71]

[0001408710-21-000047:notes:42]
[same as prior period, unchanged from 0001408710-21-000022:notes:72]

[0001408710-21-000047:notes:43]
[same as prior period, unchanged from 0001408710-21-000022:notes:73]

[0001408710-21-000047:notes:44]
|  | Fair Value Measurements at Reporting Date Using |
| (amount in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of September 24, 2021 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 46,502 |  |  |  | $ | — |  |  | $ | 46,502 |  |
| Liquidity funds | — |  |  | 31,278 |  |  |  | — |  |  | 31,278 |  |
| Corporate debt securities | — |  |  | 203,078 |  |  |  | — |  |  | 203,078 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 24,145 |  |  |  | — |  |  | 24,145 |  |
| Total | $ | — |  |  | $ | 305,003 |  |  |  | $ | — |  |  | $ | 305,003 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | 7,798 |  |  |  | $ | — |  |  | $ | 7,798 |  |
| Derivative liabilities – non-current portion | — |  |  | 1,554 |  |  |  | — |  |  | 1,554 |  |
| Total | $ | — |  |  | $ | 9,352 |  | (1) |  | $ | — |  |  | $ | 9,352 |  |

[0001408710-21-000047:notes:45]
|  | Fair Value Measurements at Reporting Date Using |
| (amount in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of June 25, 2021 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 80,305 |  |  |  | $ | — |  |  | $ | 80,305 |  |
| Liquidity funds | — |  |  | 31,226 |  |  |  | — |  |  | 31,226 |  |
| Corporate debt securities | — |  |  | 171,790 |  |  |  | — |  |  | 171,790 |  |
| U.S. agency and U.S. Treasury securities | — |  |  | 31,447 |  |  |  | — |  |  | 31,447 |  |
| Derivative assets – current portion | — |  |  | 1 |  | (2) |  | — |  |  | 1 |  |
| Total | $ | — |  |  | $ | 314,769 |  |  |  | $ | — |  |  | $ | 314,769 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | 5,654 |  |  |  | $ | — |  |  | $ | 5,654 |  |
| Derivative liabilities – non-current portion | — |  |  | 1,977 |  |  |  | — |  |  | 1,977 |  |
| Total | $ | — |  |  | $ | 7,631 |  | (3) |  | $ | — |  |  | $ | 7,631 |  |

[0001408710-21-000047:notes:46]
(1)Foreign currency forward contracts with a notional amount of $135.0 million and Canadian dollars 0.2 million and two interest rate swap agreements with an aggregate notional amount of $125.1 million.

[0001408710-21-000047:notes:47]
(2)Foreign currency forward contracts with an aggregate notional amount of $2.0 million.

[0001408710-21-000047:notes:48]
(3)Foreign currency forward contracts with an aggregate notional amount of $128.0 million and Canadian dollars 0.4 million and two interest rate swap agreements with an aggregate notional amount of $125.1 million.

[0001408710-21-000047:notes:49]
[same as prior period, unchanged from 0001408710-21-000022:notes:80]

[0001408710-21-000047:notes:50]
[same as prior period, unchanged from 0001408710-21-000022:notes:81]

[0001408710-21-000047:notes:51]
[same as prior period, unchanged from 0001408710-21-000022:notes:82]

[0001408710-21-000047:notes:52]
[same as prior period, unchanged from 0001408710-21-000022:notes:83]

[0001408710-21-000047:notes:53]
[same as prior period, unchanged from 0001408710-21-000022:notes:84]

[0001408710-21-000047:notes:54]
The Company may enter into foreign currency forward contracts with maturities of up to 12 months to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht, including inventory purchases, payroll and other operating expenses. The Company considers these forward contracts as dual-purpose hedges, that hedge the foreign exchange fluctuation (i) from inception through the forecasted expenditure, and (ii) any subsequent revaluation of the account payable or accrual. The Company may designate the forward contracts that hedge the foreign exchange fluctuation from inception through the forecasted expenditure as cash flow hedges. The gain or loss on a derivative instrument designated and qualified as a cash flow hedging instrument is recorded as a component of other comprehensive income and reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings. The reclassified amounts are presented in the same income statement line item as the earnings effect of the hedged item. Once the forecasted transactions are recorded, the Company will discontinue the hedging relationship by de-designating the derivative instrument and recording subsequent changes in fair value through contract maturity to foreign exchange gain (loss), net in the consolidated statements of operations and comprehensive income as a natural hedge against the Thai baht denominated assets and liabilities.

[0001408710-21-000047:notes:55]
The Company may also enter into non-designated foreign currency forward and option contracts to provide an offset to the re-measurement of foreign currency denominated assets and liabilities and to hedge certain forecasted exposures. Changes in the fair value of these non-designated derivatives are recorded to foreign exchange gain (loss), net in the consolidated statements of operations and comprehensive income.

[0001408710-21-000047:notes:56]
As of September 24, 2021, the Company had 135 outstanding U.S. dollar foreign currency forward contracts against Thai baht, with an aggregate notional amount of $135.0 million and maturity dates ranging from October 2021 through April 2022 and one outstanding Canadian dollar foreign currency forward contract with a notional amount of 0.2 million Canadian dollars and a maturity date in December 2021.

[0001408710-21-000047:notes:57]
As of June 25, 2021, the Company had 130 outstanding U.S. dollar foreign currency forward contracts against Thai baht with an aggregate notional amount of $130.0 million and maturity dates ranging from July 2021 through January 2022, and two foreign currency contracts with an aggregate notional amount of 0.4 million Canadian dollars and maturity dates in September 2021.

[0001408710-21-000047:notes:58]
As of September 24, 2021, the hedging relationship over foreign currency forward contracts that were designated for hedge accounting was determined to be highly effective based on the performance of retrospective and prospective regression testing. As of September 24, 2021, the amount in accumulated other comprehensive income ("AOCI") that is expected to be reclassified into earnings within 12 months was a loss of $4.1 million.

[0001408710-21-000047:notes:59]
As of June 25, 2021, the hedging relationship over foreign currency forward contracts that were designated for hedge accounting was determined to be highly effective based on the performance of retrospective and prospective regression testing. As of June 25, 2021, the amount in AOCI that is expected to be reclassified into earnings within 12 months was a gain of $2.7 million.

[0001408710-21-000047:notes:60]
During the three months ended September 24, 2021, the Company recorded an unrealized loss of $0.6 million from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-21-000047:notes:61]
During the three months ended September 25, 2020, the Company recorded an unrealized loss of $1.5 million from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-21-000047:notes:62]
[same as prior period, unchanged from 0001408710-21-000022:notes:93]

[0001408710-21-000047:notes:63]
The Company entered into interest rate swap agreements to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. As of September 24, 2021 and June 25, 2021, the Company had two outstanding interest rate swap agreements with an aggregate notional amount of $125.1 million. On July 25, 2018, Fabrinet Thailand entered into an interest rate swap agreement to effectively convert the floating interest rate of its term loan under the credit facility agreement with Bank of America to a fixed interest rate of 2.86% per annum through the scheduled maturity of the term loan in June 2023 (see Note 12). The Company did not designate this interest rate swap for hedge accounting.

[0001408710-21-000047:notes:64]
On September 3, 2019, the Company entered into a new term loan agreement under a credit facility agreement with the Bank of Ayudhya Public Company Limited (the “Bank”) (see Note 12) and on September 10, 2019, the Company repaid in full the outstanding term loan under the Bank of America credit facility agreement (see Note 12). In conjunction with the funding of the new term loan, the Company entered into a second interest rate swap agreement. The combination of both of

[0001408710-21-000047:notes:65]
these interest rate swaps effectively converts the floating interest rate of the Company’s new term loan with the Bank to a fixed interest rate of 4.36% per annum through the maturity of the term loan in June 2024.

[0001408710-21-000047:notes:66]
On September 27, 2019, the Company designated these two interest rate swaps as a cash flow hedge for the Company’s term loan under the credit facility agreement with the Bank. The combination of these two interest rate swaps qualified for hedge accounting because the hedges are highly effective, and the Company has designated and documented contemporaneously the hedging relationships involving these interest rate swaps. While the Company intends to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in earnings. From September 27, 2019, any gains or losses related to these interest rate swaps will be recorded in AOCI in the unaudited condensed consolidated balance sheets. The Company will reclassify a portion of the gains or losses from AOCI into earnings at each reporting period based on either the accrued interest amount or the interest payment.

[0001408710-21-000047:notes:67]
As of September 24, 2021, the amount in AOCI that is expected to be reclassified into earnings within 12 months is a loss of $0.9 million.

[0001408710-21-000047:notes:68]
As of June 25, 2021, the amount in AOCI that is expected to be reclassified into earnings within 12 months is a loss of $0.8 million.

[0001408710-21-000047:notes:69]
[same as prior period, unchanged from 0001408710-21-000022:notes:100]

[0001408710-21-000047:notes:70]
|  |  |  | Three Months Ended |
| (amount in thousands) | Financialstatementsline item |  | September 24,2021 |  | September 25,2020 |
| Derivatives gain (loss) recognized in other comprehensive income (loss): |  |  |  |  |  |
| Foreign currency forward contracts | Other comprehensiveincome |  | $ | (2,136) |  |  | $ | (2,340) |  |
| Interest rate swaps | Other comprehensiveincome |  | 408 |  |  | 357 |  |
| Total derivatives gain (loss) recognized in other comprehensive income (loss) |  |  | $ | (1,728) |  |  | $ | (1,983) |  |
| Derivatives loss (gain) reclassified from accumulated other comprehensive income (loss) into earnings: |  |  |  |  |  |
| Foreign currency forward contracts | Cost of revenues |  | $ | 2,115 |  |  | $ | (2,057) |  |
| Foreign currency forward contracts | SG&A |  | 88 |  |  | (87) |  |
| Foreign currency forward contracts | Foreign exchange loss, net |  | (1,424) |  |  | 1,278 |  |
| Interest rate swaps | Interest expense |  | (268) |  |  | (359) |  |
| Total derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings |  |  | $ | 511 |  |  | $ | (1,225) |  |
| Change in net unrealized gain (loss) on derivatives instruments |  |  | $ | (1,217) |  |  | $ | (3,208) |  |

[0001408710-21-000047:notes:71]
[same as prior period, unchanged from 0001408710-21-000022:notes:102]

[0001408710-21-000047:notes:72]
[same as prior period, unchanged from 0001408710-21-000022:notes:103]

[0001408710-21-000047:notes:73]
|  | September 24,2021 |  | June 25,2021 |
| (amount in thousands) | DerivativeAssets |  | DerivativeLiabilities |  | DerivativeAssets |  | DerivativeLiabilities |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts | $ | — |  |  | $ | (2,149) |  |  | $ | — |  |  | $ | (1,379) |  |
| Interest rate swaps | — |  |  | — |  |  | — |  |  | — |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | (4,063) |  |  | 1 |  |  | (2,703) |  |
| Interest rate swaps | — |  |  | (3,140) |  |  | — |  |  | (3,549) |  |
| Derivatives, gross balances | $ | — |  |  | $ | (9,352) |  |  | $ | 1 |  |  | $ | (7,631) |  |

[0001408710-21-000047:notes:74]
[same as prior period, unchanged from 0001408710-21-000022:notes:105]

[0001408710-21-000047:notes:75]
[same as prior period, unchanged from 0001408710-21-000022:notes:106]


## us-gaap:InventoryDisclosureTextBlock

[0001408710-21-000047:notes:76]
[same as prior period, unchanged from 0001408710-21-000022:notes:107]

[0001408710-21-000047:notes:77]
| (amount in thousands) | As of September 24,2021 |  | As of June 25,2021 |
| Raw materials | $ | 234,923 |  |  | $ | 196,345 |  |
| Work in progress | 190,964 |  |  | 174,654 |  |
| Finished goods | 15,194 |  |  | 15,471 |  |
| Goods in transit | 24,170 |  |  | 35,663 |  |
| Inventories | $ | 465,251 |  |  | $ | 422,133 |  |


## fn:RestrictedCashAndCashEquivalentsTextBlock

[0001408710-21-000047:notes:78]
Restricted cashAs of September 24, 2021 and June 25, 2021, the Company had long-term restricted cash of Renminbi 1.0 million related to bank guarantees of its subsidiary in the PRC to support the subsidiary's operations. The bank guarantee was backed by cash collateral of $0.2 million.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001408710-21-000047:notes:79]
Leases
The Company leases facilities under non-cancelable operating lease agreements. The Company leases a portion of its capital equipment and vehicles, certain land and buildings for its facilities in Thailand, the Cayman Islands, the PRC, the U.S., the U.K., Israel and Singapore under operating lease arrangements that expire at various dates through 2025. Certain of these lease arrangements provide the Company the ability to extend the lease from one to five years following the expiration of the current term. However, the Company has excluded all lease extension options from its right of use ("ROU") assets and lease liabilities as the Company is not reasonably assured that it will exercise these options. None of the lease agreements contains residual value guarantees provided by the lessee. The Company also has one intercompany lease transaction in the form of a lease of office and manufacturing space between Fabritek and Fabrinet West.

[0001408710-21-000047:notes:80]
Operating leases

[0001408710-21-000047:notes:81]
As of September 24, 2021, the maturities of the Company’s operating lease liabilities were as follows:

[0001408710-21-000047:notes:82]
| (amount in thousands) | As of September 24,2021 |  |
| 2022 (remaining 9 months) | $ | 2,085 |  |  |
| 2023 | 2,686 |  |  |
| 2024 | 1,257 |  |  |
| 2025 | 43 |  |  |
| Total undiscounted lease payments | 6,071 |  |  |
| Less imputed interest | (238) |  |  |
| Total present value of lease liabilities | $ | 5,833 |  | (1) |

[0001408710-21-000047:notes:83]
(1)Included current portion of operating lease liabilities of $2.6 million.

[0001408710-21-000047:notes:84]
Rental expense related to the Company’s operating leases is recognized on a straight-line basis over the lease term.

[0001408710-21-000047:notes:85]
Rental expense for long-term leases for the three months ended September 24, 2021 and September 25, 2020 was $0.7 million and $0.6 million, respectively. Rental expense for short-term leases for the three months ended September 24, 2021 and September 25, 2020 was immaterial.

[0001408710-21-000047:notes:86]
[same as prior period, unchanged from 0001408710-21-000022:notes:116]

[0001408710-21-000047:notes:87]
|  | As ofSeptember 24, 2021 |  | As ofJune 25, 2021 |
| Weighted-average remaining lease term (in years) | 2.5 |  | 2.7 |
| Weighted-average discount rate | 3.5 | % |  | 3.5 | % |

[0001408710-21-000047:notes:88]
The following table presents supplemental disclosure for the unaudited condensed consolidated statement of cash flows related to operating and finance leases for the three months ended September 24, 2021 and September 25, 2020:

[0001408710-21-000047:notes:89]
|  | Three Months Ended |
| (amount in thousands) | September 24,2021 |  | September 25,2020 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |
| Operating cash flows from operating leases | $ | 689 |  |  | $ | 594 |  |
| Financing cash flows from finance leases | $ | — |  |  | $ | 100 |  |
| ROU assets obtained in exchange for lease liabilities | $ | 38 |  |  | $ | 64 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001408710-21-000047:notes:90]
[same as prior period, unchanged from 0001408710-21-000022:notes:120]

[0001408710-21-000047:notes:91]
| (amount in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  | ForeignCurrencyTranslationAdjustment |  | Net |
| As of September 24, 2021 |  |  |  |  |  |  |  |
| Software | $ | 9,915 |  |  | $ | (6,902) |  |  | $ | — |  |  | $ | 3,013 |  |
| Customer relationships | 4,373 |  |  | (3,307) |  |  | 28 |  |  | 1,094 |  |
| Backlog | 119 |  |  | (119) |  |  | — |  |  | — |  |
| Total intangibles | $ | 14,407 |  |  | $ | (10,328) |  |  | $ | 28 |  |  | $ | 4,107 |  |

[0001408710-21-000047:notes:92]
| (amount in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  | ForeignCurrencyTranslationAdjustment |  | Net |
| As of June 25, 2021 |  |  |  |  |  |  |  |
| Software | $ | 9,767 |  |  | $ | (6,632) |  |  | $ | — |  |  | $ | 3,135 |  |
| Customer relationships | 4,373 |  |  | (3,195) |  |  | 58 |  |  | 1,236 |  |
| Backlog | 119 |  |  | (119) |  |  | — |  |  | — |  |
| Total intangibles | $ | 14,259 |  |  | $ | (9,946) |  |  | $ | 58 |  |  | $ | 4,371 |  |

[0001408710-21-000047:notes:93]
The Company recorded amortization expense relating to intangibles of $0.4 million and $0.2 million for the three months ended September 24, 2021 and September 25, 2020, respectively.

[0001408710-21-000047:notes:94]
[same as prior period, unchanged from 0001408710-21-000022:notes:124]

[0001408710-21-000047:notes:95]
| (years) | As ofSeptember 24, 2021 |  | As ofJune 25, 2021 |
| Customer relationships | 3.7 |  | 3.9 |

[0001408710-21-000047:notes:96]
Based on the carrying amount of intangibles as of September 24, 2021, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001408710-21-000047:notes:97]
| (amount in thousands) |  |
| 2022 (remaining 9 months) | $ | 1,077 |  |
| 2023 | 1,196 |  |
| 2024 | 868 |  |
| 2025 | 586 |  |
| Thereafter | 380 |  |
| Total | $ | 4,107 |  |


## us-gaap:DebtDisclosureTextBlock

[0001408710-21-000047:notes:98]
Borrowings 
The Company’s total borrowings, including current and non-current portions of long-term borrowings, consisted of the following:

[0001408710-21-000047:notes:99]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofSeptember 24, 2021 |  | As ofJune 25, 2021 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterlyinstallments |  | June 2024 |  | $ | 36,562 |  |  | $ | 39,609 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  | (55) |  |  | (63) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 24,319 |  |  | $ | 27,358 |  |

[0001408710-21-000047:notes:100]
(1)We have entered into interest rate swaps that effectively fix a series of our future interest payments on our term loans. Refer to Note 6.

[0001408710-21-000047:notes:101]
The movements of long-term borrowings for the three months ended September 24, 2021 and September 25, 2020 were as follows:

[0001408710-21-000047:notes:102]
|  | Three Months Ended |
| (amount in thousands) | September 24,2021 |  | September 25,2020 |
| Opening balance | $ | 39,609 |  |  | $ | 51,797 |  |
| Borrowings during the period | — |  |  | — |  |
| Repayments during the period | (3,047) |  |  | (3,047) |  |
| Closing balance | $ | 36,562 |  |  | $ | 48,750 |  |

[0001408710-21-000047:notes:103]
As of September 24, 2021, future maturities of long-term borrowings during each fiscal year were as follows:

[0001408710-21-000047:notes:104]
| (amount in thousands) |  |
| 2022 (remaining 9 months) | $ | 9,141 |  |
| 2023 | 15,233 |  |
| 2024 | 9,141 |  |
| 2025 | 3,047 |  |
| Total | $ | 36,562 |  |

[0001408710-21-000047:notes:105]
Credit facility agreements:

[0001408710-21-000047:notes:106]
Bank of Ayudhya Public Company Limited

[0001408710-21-000047:notes:107]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a credit facility agreement (the “Credit Facility Agreement”), which provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million that may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

[0001408710-21-000047:notes:108]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a term loan agreement (the "Term Loan Agreement") pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original

[0001408710-21-000047:notes:109]
principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Bank of America credit facility agreement.

[0001408710-21-000047:notes:110]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three months ended September 24, 2021 and September 25, 2020, the Company recorded $0.3 million and $0.2 million, respectively, of interest expense in connection with this term loan.

[0001408710-21-000047:notes:111]
Any borrowings under the Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

[0001408710-21-000047:notes:112]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, and restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.5 times. As of September 24, 2021, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

[0001408710-21-000047:notes:113]
The events of default under the Term Loan Agreement include failure to pay amounts due under the Term Loan Agreement or the related finance documents when due, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

[0001408710-21-000047:notes:114]
As of September 24, 2021, there was $36.6 million outstanding under the term loan.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001408710-21-000047:notes:115]
Income taxes
As of September 24, 2021 and June 25, 2021, the liability for uncertain tax positions including accrued interest and penalties was $1.1 million and $0.9 million, respectively. The Company expects the estimated amount of liability associated with its uncertain tax positions to increase within the next 12 months due to additional provisions on uncertain tax positions from one of the subsidiaries and interest on these positions.

[0001408710-21-000047:notes:116]
[same as prior period, unchanged from 0001408710-21-000022:notes:150]

[0001408710-21-000047:notes:117]
The effective tax rate for the Company for the three months ended September 24, 2021 and September 25, 2020 was 1.3% and 4.8%, respectively, of net income. The decrease was primarily due to an increase in income not subject to tax during the first quarter of fiscal year 2022 as compared to the same period in fiscal year 2021.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001408710-21-000047:notes:118]
[same as prior period, unchanged from 0001408710-21-000022:notes:153]

[0001408710-21-000047:notes:119]
The grant date fair value of restricted share units and performance share units is based on the market value of the Company's ordinary shares on the date of grant.

[0001408710-21-000047:notes:120]
The effect of recording share-based compensation expense for the three months ended September 24, 2021 and September 25, 2020 was as follows:

[0001408710-21-000047:notes:121]
|  | Three Months Ended |
| (amount in thousands) | September 24,2021 |  | September 25,2020 |
| Share-based compensation expense by type of award: |  |  |  |
| Restricted share units | $ | 4,924 |  |  | $ | 5,249 |  |
| Performance share units | 4,368 |  |  | 778 |  |
| Total share-based compensation expense | 9,292 |  |  | 6,027 |  |
| Tax effect on share-based compensation expense | — |  |  | — |  |
| Net effect on share-based compensation expense | $ | 9,292 |  |  | $ | 6,027 |  |

[0001408710-21-000047:notes:122]
[same as prior period, unchanged from 0001408710-21-000022:notes:157]

[0001408710-21-000047:notes:123]
|  | Three Months Ended |
| (amount in thousands) | September 24,2021 |  | September 25,2020 |
| Cost of revenue | $ | 1,975 |  |  | $ | 1,825 |  |
| Selling, general and administrative expense | 7,317 |  |  | 4,202 |  |
| Total share-based compensation expense | $ | 9,292 |  |  | $ | 6,027 |  |

[0001408710-21-000047:notes:124]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the three months ended September 24, 2021 and September 25, 2020.

[0001408710-21-000047:notes:125]
[same as prior period, unchanged from 0001408710-21-000022:notes:160]

[0001408710-21-000047:notes:126]
[same as prior period, unchanged from 0001408710-21-000022:notes:161]

[0001408710-21-000047:notes:127]
As of September 24, 2021, there were 315,203 restricted share units outstanding, 295,550 performance share units outstanding and 2,260,077 ordinary shares available for future grant under the 2020 Plan.

[0001408710-21-000047:notes:128]
As of September 24, 2021, there were 183,056 restricted share units outstanding under the 2010 Plan. No ordinary shares are available for future grant under the 2010 Plan.

[0001408710-21-000047:notes:129]
On November 2, 2017, the Company adopted the 2017 Inducement Equity Incentive Plan (the “2017 Inducement Plan”) with a reserve of 160,000 ordinary shares authorized for future issuance solely for the granting of inducement share options and equity awards to new employees. The 2017 Inducement Plan was adopted without shareholder approval in reliance on the “employment inducement exemption” provided under the New York Stock Exchange Listed Company Manual. As of September 24, 2021, there were 12,164 restricted share units outstanding and 111,347 ordinary shares available for future grant under the 2017 Inducement Plan.

[0001408710-21-000047:notes:130]
[same as prior period, unchanged from 0001408710-21-000022:notes:165]

[0001408710-21-000047:notes:131]
[same as prior period, unchanged from 0001408710-21-000022:notes:166]

[0001408710-21-000047:notes:132]
[same as prior period, unchanged from 0001408710-21-000022:notes:167]

[0001408710-21-000047:notes:133]
[same as prior period, unchanged from 0001408710-21-000022:notes:168]

[0001408710-21-000047:notes:134]
[same as prior period, unchanged from 0001408710-21-000022:notes:169]

[0001408710-21-000047:notes:135]
[same as prior period, unchanged from 0001408710-21-000022:notes:170]

[0001408710-21-000047:notes:136]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 25, 2021 | 641,875 |  |  | $ | 55.74 |  |
| Granted | 137,165 |  |  | $ | 101.05 |  |
| Issued | (259,533) |  |  | $ | 50.76 |  |
| Forfeited | (9,084) |  |  | $ | 67.97 |  |
| Balance as of September 24, 2021 | 510,423 |  |  | $ | 70.23 |  |

[0001408710-21-000047:notes:137]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 26, 2020 | 797,757 |  |  | $ | 46.88 |  |
| Granted | 171,946 |  |  | $ | 70.05 |  |
| Issued | (268,728) |  |  | $ | 43.84 |  |
| Forfeited | (7,199) |  |  | $ | 50.40 |  |
| Balance as of September 25, 2020 | 693,776 |  |  | $ | 53.76 |  |

[0001408710-21-000047:notes:138]
[same as prior period, unchanged from 0001408710-21-000022:notes:173]

[0001408710-21-000047:notes:139]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 25, 2021 | 427,028 |  |  | $ | 57.82 |  |
| Granted | 110,832 |  |  | $ | 101.05 |  |
| Issued | (190,213) |  |  | $ | 48.65 |  |
| Forfeited | (52,097) |  |  | $ | 48.65 |  |
| Balance as of September 24, 2021 | 295,550 |  |  | $ | 81.55 |  |

[0001408710-21-000047:notes:140]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 26, 2020 | 440,140 |  |  | $ | 48.37 |  |
| Granted | 179,008 |  |  | $ | 70.05 |  |
| Issued | (82,185) |  |  | $ | 48.02 |  |
| Forfeited | (115,645) |  |  | $ | 48.02 |  |
| Balance as of September 25, 2020 | 421,318 |  |  | $ | 57.74 |  |

[0001408710-21-000047:notes:141]
[same as prior period, unchanged from 0001408710-21-000022:notes:176]

[0001408710-21-000047:notes:142]
As of September 24, 2021, there was $18.9 million and $15.7 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.7 years and 1.5 years, respectively.

[0001408710-21-000047:notes:143]
For the three months ended September 24, 2021 and September 25, 2020, the Company withheld an aggregate of 197,948 shares and 142,221 shares, respectively, upon the vesting of restricted share units, based upon the closing share price on the vesting date to settle employee obligations for the applicable income and other employment taxes. For the three months ended September 24, 2021 and September 25, 2020, the Company then remitted cash of $19.1 million and $9.9 million, respectively, to the appropriate taxing authorities, and presented it as a financing activity within the unaudited condensed consolidated statements of cash flows. The payment was recorded as a reduction of additional paid-in capital.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001408710-21-000047:notes:144]
[same as prior period, unchanged from 0001408710-21-000022:notes:179]

[0001408710-21-000047:notes:145]
[same as prior period, unchanged from 0001408710-21-000022:notes:180]

[0001408710-21-000047:notes:146]
For the three months ended September 24, 2021, Fabrinet issued 251,798 ordinary shares upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-21-000047:notes:147]
For the three months ended September 25, 2020, Fabrinet issued 208,692 ordinary shares upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-21-000047:notes:148]
[same as prior period, unchanged from 0001408710-21-000022:notes:183]

[0001408710-21-000047:notes:149]
[same as prior period, unchanged from 0001408710-21-000022:notes:184]

[0001408710-21-000047:notes:150]
In August 2017, the Company’s board of directors approved a share repurchase program to permit the Company to repurchase up to $30.0 million worth of its issued and outstanding ordinary shares in the open market in accordance with applicable rules and regulations. In February 2018, May 2019 and August 2020, the Company’s board of directors approved an increase of $30.0 million, $50.0 million and $58.5 million, respectively, to the original share repurchase authorization, bringing the aggregate authorization to $168.5 million.

[0001408710-21-000047:notes:151]
During the three months ended September 24, 2021, no shares were repurchased under the program. As of September 24, 2021, the Company had a remaining authorization to repurchase up to an additional $81.2 million worth of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001408710-21-000047:notes:152]
Accumulated other comprehensive income (loss)
The changes in AOCI for the three months ended September 24, 2021 and September 25, 2020 were as follows:

[0001408710-21-000047:notes:153]
| (amount in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 25, 2021 | $ | 308 |  |  | $ | (4,504) |  |  | $ | (1,425) |  |  | $ | (645) |  |  | $ | (6,266) |  |
| Other comprehensive income before reclassification adjustment | (200) |  |  | (1,728) |  |  | — |  |  | (164) |  |  | (2,092) |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | (13) |  |  | 511 |  |  | 198 |  |  | — |  |  | 696 |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | $ | (213) |  |  | $ | (1,217) |  |  | $ | 198 |  |  | $ | (164) |  |  | $ | (1,396) |  |
| Balance as of September 24, 2021 | $ | 95 |  |  | $ | (5,721) |  |  | $ | (1,227) |  |  | $ | (809) |  |  | $ | (7,662) |  |

[0001408710-21-000047:notes:154]
| (amount in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 26, 2020 | $ | 1,490 |  |  | $ | 602 |  |  | $ | (2,009) |  |  | $ | (1,230) |  |  | $ | (1,147) |  |
| Other comprehensive income before reclassification adjustment | (325) |  |  | (1,983) |  |  | — |  |  | 603 |  |  | (1,705) |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | — |  |  | (1,225) |  |  | 173 |  |  | — |  |  | (1,052) |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | $ | (325) |  |  | $ | (3,208) |  |  | $ | 173 |  |  | $ | 603 |  |  | $ | (2,757) |  |
| Balance as of September 25, 2020 | $ | 1,165 |  |  | $ | (2,606) |  |  | $ | (1,836) |  |  | $ | (627) |  |  | $ | (3,904) |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001408710-21-000047:notes:155]
Commitments and contingencies
Bank guarantees

[0001408710-21-000047:notes:156]
As of September 24, 2021 and June 25, 2021, there were outstanding bank guarantees on behalf of our subsidiary in Thailand for electricity usage and other normal business expenses totaling to $1.5 million and $1.6 million, respectively, or Thai Baht 50.2 million. As of September 24, 2021 and June 25, 2021, the Company had an outstanding bank guarantee of its subsidiary in the PRC to support the subsidiary's operations totaling Renminbi 1.0 million, which was backed by cash collateral of $0.2 million. In addition, there were other immaterial bank guarantees on behalf of our subsidiary in the U.K. to support its operations.

[0001408710-21-000047:notes:157]
Purchase obligations

[0001408710-21-000047:notes:158]
Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001408710-21-000047:notes:159]
As of September 24, 2021, the Company had a purchase obligation and other commitments to third parties of $992.8 million.

[0001408710-21-000047:notes:160]
Capital expenditure

[0001408710-21-000047:notes:161]
In December 2020, the Company entered into a construction contract with a local contractor for construction of a new manufacturing building at the Company’s Chonburi campus. The contract price is approximately $50.3 million.

[0001408710-21-000047:notes:162]
In June 2021, the Company entered into an agreement to purchase a parcel of land in Pathumthani, Thailand to expand the Company's Pinehurst campus. The aggregate purchase price was approximately $13.2 million or Thai Baht 418.8 million, which was paid in two installments: (1) a 10% deposit on May 14, 2021; and (2) the remainder on June 29, 2021.

[0001408710-21-000047:notes:163]
As of September 24, 2021, the Company had total capital expenditure commitments to third parties of $31.0 million, comprised of the construction contract of new manufacturing building at Chonburi campus of $20.1 million and other commitments of $10.9 million.

[0001408710-21-000047:notes:164]
Indemnification of directors and officers

[0001408710-21-000047:notes:165]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001408710-21-000047:notes:166]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001408710-21-000047:notes:167]
Business segments and geographic information
Operating segments are defined as components of an enterprise for which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. The Company’s chief operating decision maker is Fabrinet’s Chief Executive Officer. As of September 24, 2021, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001408710-21-000047:notes:168]
[same as prior period, unchanged from 0001408710-21-000022:notes:203]

[0001408710-21-000047:notes:169]
[same as prior period, unchanged from 0001408710-21-000022:notes:204]

[0001408710-21-000047:notes:170]
| (amount in thousands) |  | September 24,2021 |  | June 25,2021 |
| Long-Lived Assets: |  |  |  |  |
| Thailand |  | $ | 221,512 |  |  | $ | 190,843 |  |
| U.S. |  | 26,883 |  |  | 27,403 |  |
| China |  | 15,929 |  |  | 14,977 |  |
| Israel |  | 4,931 |  |  | 5,271 |  |
| U.K. |  | 1,889 |  |  | 2,223 |  |
| Cayman Islands |  | 515 |  |  | 412 |  |
|  |  | $ | 271,659 |  |  | $ | 241,129 |  |

[0001408710-21-000047:notes:171]
[same as prior period, unchanged from 0001408710-21-000022:notes:206]

[0001408710-21-000047:notes:172]
The Company had three customers that each contributed to 10% or more of the Company's total trade accounts receivable as of September 24, 2021 and June 25, 2021.
