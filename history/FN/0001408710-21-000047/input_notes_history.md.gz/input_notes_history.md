# FN note change history — 0001408710-21-000022 → 0001408710-21-000047


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0001408710-21-000047:note_history:1]
Commitments and contingencies
Bank guarantees
  (was, 2021-05-04, similarity 0.8108):
[0001408710-21-000022:note_history:1]
Commitments and contingencies
Letter of credit and Bank guarantees

- added (2021-11-02):
[0001408710-21-000047:note_history:2]
As of September 24, 2021 and June 25, 2021, there were outstanding bank guarantees on behalf of our subsidiary in Thailand for electricity usage and other normal business expenses totaling to $1.5 million and $1.6 million, respectively, or Thai Baht 50.2 million. As of September 24, 2021 and June 25, 2021, the Company had an outstanding bank guarantee of its subsidiary in the PRC to support the subsidiary's operations totaling Renminbi 1.0 million, which was backed by cash collateral of $0.2 million. In addition, there were other immaterial bank guarantees on behalf of our subsidiary in the U.K. to support its operations.

- changed (2021-11-02):
[0001408710-21-000047:note_history:3]
As of September 24, 2021, the Company had a purchase obligation and other commitments to third parties of $992.8 million.
  (was, 2021-05-04, similarity 0.9541):
[0001408710-21-000022:note_history:3]
As of March 26, 2021, the Company had a purchase obligation and other commitments to third parties of $661.2 million.

- added (2021-11-02):
[0001408710-21-000047:note_history:4]
In June 2021, the Company entered into an agreement to purchase a parcel of land in Pathumthani, Thailand to expand the Company's Pinehurst campus. The aggregate purchase price was approximately $13.2 million or Thai Baht 418.8 million, which was paid in two installments: (1) a 10% deposit on May 14, 2021; and (2) the remainder on June 29, 2021.

- added (2021-11-02):
[0001408710-21-000047:note_history:5]
As of September 24, 2021, the Company had total capital expenditure commitments to third parties of $31.0 million, comprised of the construction contract of new manufacturing building at Chonburi campus of $20.1 million and other commitments of $10.9 million.

- removed (2021-11-02):
[0001408710-21-000022:note_history:6]
As of March 26, 2021, the Company had no outstanding standby letter of credit.

- removed (2021-11-02):
[0001408710-21-000022:note_history:7]
As of June 26, 2020, the Company had one outstanding standby letter of credit of 6.0 million Euros related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. The standby letter of credit was backed by cash collateral of $7.4 million. This standby letter of credit expired on December 31, 2020 and the corresponding cash collateral was released in January 2021.

- removed (2021-11-02):
[0001408710-21-000022:note_history:8]
As of March 26, 2021 and June 26, 2020, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business expenses totaling to $1.6 million or Thai Baht 50.2 million and there were other bank guarantees given by a bank on behalf of our subsidiaries in the PRC and the U.K. to support their operations. As of March 26, 2021, the Company had an outstanding bank guarantee of its subsidiary in the PRC to support the subsidiary's operations totaling Renminbi 1.0 million. The bank guarantee was backed by cash collateral of $0.2 million. The bank guarantee given on behalf of our subsidiaries in the U.K. was not material. As of June 26, 2020, these bank guarantees were immaterial.

- removed (2021-11-02):
[0001408710-21-000022:note_history:9]
As of March 26, 2021, the Company had a purchase obligation and other commitments to third parties of $62.1 million.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0001408710-21-000047:note_history:10]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of September 24, 2021 and for the three months ended September 24, 2021 and September 25, 2020 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 25, 2021.
  (was, 2021-05-04, similarity 0.9523):
[0001408710-21-000022:note_history:10]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of March 26, 2021 and for the three and nine  months ended March 26, 2021 and March 27, 2020 includes normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 26, 2020.

- changed (2021-11-02):
[0001408710-21-000047:note_history:11]
The results for the three months ended September 24, 2021 may not be indicative of results for the year ending June 24, 2022 or any future periods.
  (was, 2021-05-04, similarity 0.9319):
[0001408710-21-000022:note_history:11]
The results for the three and nine  months ended March 26, 2021 may not be indicative of results for the year ending June 25, 2021 or any future periods.

- changed (2021-11-02):
[0001408710-21-000047:note_history:12]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information. Additionally, the extent to which the evolving COVID-19 pandemic impacts the Company’s unaudited condensed consolidated financial statements will depend on a number of factors, including the magnitude and duration of the pandemic. These estimates may change, as new events occur and additional information is obtained, as well as upon the occurrence of other factors related to the COVID-19 pandemic that could result in material impacts to the Company's unaudited condensed consolidated financial statements in future reporting periods.
  (was, 2021-05-04, similarity 0.6532):
[0001408710-21-000022:note_history:12]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements, and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information. Additionally, the extent to which the evolving COVID-19 pandemic impacts the Company’s unaudited condensed consolidated financial statements will depend on a number of factors, including the magnitude and duration of the pandemic. These estimates may change, as new events occur and additional information is obtained, as well as other factors related to the COVID-19 pandemic that could result in material impacts to the Company's unaudited condensed consolidated financial statements in future reporting periods.

- changed (2021-11-02):
[0001408710-21-000047:note_history:13]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended September 24, 2021 and September 25, 2020 each consisted of 13 weeks. Fiscal year 2022 will be comprised of 52 weeks and will end on June 24, 2022.
  (was, 2021-05-04, similarity 0.7817):
[0001408710-21-000022:note_history:13]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended March 26, 2021 and March 27, 2020 each consisted of 13 weeks. The nine months ended March 26, 2021 and March 27, 2020 each consisted of 39 weeks. Fiscal year 2021 will be comprised of 52 weeks and will end on June 25, 2021.

- added (2021-11-02):
[0001408710-21-000047:note_history:14]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2019-12, “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.” The amendments in this update simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify U.S. GAAP for other areas of Topic 740 by clarifying and amending existing guidance. The Company adopted this standard in the first quarter of fiscal year 2022 with no material impact on its unaudited condensed consolidated financial statements.

- removed (2021-11-02):
[0001408710-21-000022:note_history:15]
Reclassifications

- removed (2021-11-02):
[0001408710-21-000022:note_history:16]
For presentation purposes, certain prior period amounts have been reclassified to conform to the current period presentation.

- removed (2021-11-02):
[0001408710-21-000022:note_history:17]
As of June 26, 2020, the derivative assets and liabilities were measured at fair value and recognized by offsetting the fair value amounts under master netting arrangements. Also, the Company chose not to separate a derivative into current and non-current portions as follows:

- removed (2021-11-02):
[0001408710-21-000022:note_history:18]
(i)A derivative for which the fair value is a net liability is classified in total as current.

- removed (2021-11-02):
[0001408710-21-000022:note_history:19]
(ii)A derivative for which the fair value is a net asset and the current portion is an asset is classified in total as non-current. If the current portion is a liability, it is presented as a current liability.

- removed (2021-11-02):
[0001408710-21-000022:note_history:20]
As of March 26, 2021, the derivative assets and liabilities were measured at fair value, but the gross fair value amount is presented in the unaudited condensed consolidated balance sheets. Additionally, a classification of current and non-current portion is determined by the maturity date of that derivative (e.g., a derivative that matures within one year is classified as current).

- removed (2021-11-02):
[0001408710-21-000022:note_history:21]
The reclassifications have been made to the consolidated balance sheet as of June 26, 2020 as shown in the following table:

- removed (2021-11-02):
[0001408710-21-000022:note_history:22]
|  | June 26, 2020 |
| (amount in thousands) | As previouslyreported |  | Reclassification |  | Afterreclassification |
| Consolidated Balance Sheet |  |  |  |  |  |
| Current assets |  |  |  |  |  |
| Other current assets | $ | 13,915 |  |  | $ | 593 |  |  | $ | 14,508 |  |
| Current liabilities |  |  |  |  |  |
| Accrued expenses | $ | 12,104 |  |  | $ | (3,125) |  |  | $ | 8,979 |  |
| Non-current liabilities |  |  |  |  |  |
| Other non-current liabilities | $ | 1,937 |  |  | $ | 3,718 |  |  | $ | 5,655 |  |

- removed (2021-11-02):
[0001408710-21-000022:note_history:23]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13, “Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments.” This standard requires the measurement and recognition of expected credit losses for financial assets held at amortized cost. The standard replaces the existing incurred loss impairment model with an expected loss methodology, which will result in more timely recognition of credit losses. The new standard also expands the required quantitative and qualitative disclosures surrounding expected credit losses.

- removed (2021-11-02):
[0001408710-21-000022:note_history:24]
On June 27, 2020, the Company adopted Accounting Standards Codification (“ASC”) 326 using the modified retrospective transition approach. The modified retrospective method requires the Company to recognize the cumulative effect of the adoption of ASC 326, to the opening accumulated retained earnings. Accordingly, the Company’s comparative financial statements as of June 26, 2020 have not been adjusted. The Company implemented internal controls to enable the preparation of financial information upon adoption.

- removed (2021-11-02):
[0001408710-21-000022:note_history:25]
Management estimates the expected credit losses of financial assets using relevant available information from internal and external sources relating to historical credit loss experience, current conditions and reasonable forecasts over a financial asset’s contractual term. Adjustments to historical loss information are made from qualitative and quantitative factors if economic conditions on the reporting date reflect stronger or weaker economic performance than the historical data implies based on management’s expectations of economic conditions on certain indicators of the Company, industry and economy. The Company reviews factors such as past collection experience, age of the accounts receivable and contract assets balance, significant trends in current balances, internal operations and macroeconomic conditions. In addition, the Company modified its impairment model to the Current Expected Credit Losses (“CECL”) model for available-for-sale (“AFS”) debt securities and discontinued using the concept of “other than temporary” impairment on these AFS debt

- removed (2021-11-02):
[0001408710-21-000022:note_history:26]
securities. CECL on the AFS debt securities are recognized in interest income and other income (expense), net on the Company’s unaudited condensed consolidated statements of operations and comprehensive income, and any remaining unrealized losses, are included in accumulated other comprehensive income (loss) (“AOCI”) in the unaudited condensed consolidated balance sheet.

- removed (2021-11-02):
[0001408710-21-000022:note_history:27]
As of June 27, 2020, the Company recorded a cumulative adjustment from CECL in the amount of $0.1 million, net of tax impact, to accumulated retained earnings in the unaudited condensed consolidated balance sheet.

- removed (2021-11-02):
[0001408710-21-000022:note_history:28]
On June 27, 2020, the Company also adopted ASC 820, “Disclosure Framework – Changes to the Disclosure Requirements for Fair Value Measurement.” This standard is intended to improve the effectiveness of disclosures in the notes to the financial statements, including (1) the development of a framework that promotes consistent decisions by the FASB about disclosure requirements and (2) the appropriate exercise of discretion by reporting entities. The amendment modifies the disclosure requirements on transferring between level 1 and level 2 and valuation processes of level 3 fair value measurements. The Company adopted this standard with no impact on its unaudited condensed consolidated financial statements.

- removed (2021-11-02):
[0001408710-21-000022:note_history:29]
On January 1, 2021, FASB issued ASU 2021-01, “Reference Rate Reform (Topic 848).” This standard requires the measurement and recognition of expected credit losses for financial assets held at amortized cost. The amendments in this update clarify that certain optional expedients and exceptions in Topic 848 for contract modifications and hedge accounting apply to derivatives that are affected by the discounting transition. The Company immediately adopted this standard with no impact on its unaudited condensed consolidated financial statements.

- removed (2021-11-02):
[0001408710-21-000022:note_history:30]
Changes in Accounting Policies

- removed (2021-11-02):
[0001408710-21-000022:note_history:31]
Except for the adoption of ASC 326, ASC 820 and ASC 848, the Company has consistently applied the accounting policies to all periods presented in these unaudited condensed consolidated financial statements.

- removed (2021-11-02):
[0001408710-21-000022:note_history:32]
Short-term investments

- removed (2021-11-02):
[0001408710-21-000022:note_history:33]
Management determines the appropriate classification of its investments at the time of purchase and re-evaluates the designations at each balance sheet date. The Company may sell certain of the Company’s short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s short-term investments generally range from three months to three years. The Company’s short-term investments, which consist of investments in U.S. Treasury, fixed income securities, liquidity funds that invest in short-term debt securities and certificates of deposit and time deposits, have been classified and accounted for as AFS. The AFS investments are carried at estimated fair value with any unrealized gains and losses, included in AOCI in the Company’s unaudited condensed consolidated balance sheet. The Company determines realized gains or losses on sale of marketable securities on a specific identification method and records such gains or losses as interest income and other income (expense), net in the unaudited condensed consolidated statements of operations and comprehensive income.

- removed (2021-11-02):
[0001408710-21-000022:note_history:34]
AFS debt securities are required to be individually evaluated for impairment. A security is considered impaired if the fair value of the security is less than its amortized cost basis.

- removed (2021-11-02):
[0001408710-21-000022:note_history:35]
An impairment is considered other than temporary if (i) the Company has the intent to sell the security, (ii) it is more likely than not that the Company will be required to sell the security before recovery of the entire amortized cost basis, or (iii) the Company does not expect to recover the entire amortized cost basis of the security.

- removed (2021-11-02):
[0001408710-21-000022:note_history:36]
If an impairment is considered other than temporary based on condition (i) or (ii), the entire difference between the amortized cost and the fair value of the debt security is recognized as interest income and other income (expense), net in the unaudited condensed consolidated statements of operations and comprehensive income.

- removed (2021-11-02):
[0001408710-21-000022:note_history:37]
If an impairment is considered other than temporary based on condition (iii), the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) is recognized in interest and other income (expense), net in the unaudited condensed consolidated statements of operations and comprehensive income, and any remaining unrealized losses are included in AOCI in the unaudited condensed consolidated balance sheet.

- removed (2021-11-02):
[0001408710-21-000022:note_history:38]
Trade accounts receivable

- removed (2021-11-02):
[0001408710-21-000022:note_history:39]
Accounts receivable are recorded and carried at the original invoiced amount less an allowance for any potential uncollectible amounts. The Company makes estimates of expected credit losses for the allowance for doubtful accounts based upon its assessment of various factors, including historical experience, the age of the accounts receivable balances, credit quality of its customers, current economic conditions, reasonable and supportable forecasts of future economic

- removed (2021-11-02):
[0001408710-21-000022:note_history:40]
conditions, and other factors that may affect the Company’s ability to collect from customers. The estimated credit loss allowance is recorded as selling, general and administrative expenses in the unaudited condensed consolidated statements of operations and comprehensive income.

- removed (2021-11-02):
[0001408710-21-000022:note_history:41]
Contract assets

- removed (2021-11-02):
[0001408710-21-000022:note_history:42]
A contract asset is recognized when the Company has recognized revenues prior to generating an invoice for payment. Contract assets are classified separately within the unaudited condensed consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. The Company makes estimates of expected credit losses for the allowance for contract assets based upon its assessment of various factors, including historical experience, the age of the contract assets balances, credit quality of its customers, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect the Company’s ability to collect from customers. The estimated credit loss allowance is recorded as selling, general and administrative expenses in its unaudited condensed consolidated statements of operations and comprehensive income.

- removed (2021-11-02):
[0001408710-21-000022:note_history:43]
Concentration of credit risk

- removed (2021-11-02):
[0001408710-21-000022:note_history:44]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash and cash equivalents, short-term investments, derivatives, accounts receivable and contract assets.

- removed (2021-11-02):
[0001408710-21-000022:note_history:45]
Cash, cash equivalents and short-term investments are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. The Company seeks to mitigate its credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties. The Company limits its short-term investments in marketable securities to securities with a maturity not in excess of three years and securities that are rated A1, P-1, F1, or better.

- removed (2021-11-02):
[0001408710-21-000022:note_history:46]
The Company enters into derivative contracts with financial institutions with reputable credit and monitors the credit profiles of these counterparties.

- removed (2021-11-02):
[0001408710-21-000022:note_history:47]
The Company performs ongoing credit evaluations for credit worthiness of its customers and usually does not require collateral from its customers. Management has implemented a program to closely monitor near term cash collection and credit exposures to mitigate any material losses.

- removed (2021-11-02):
[0001408710-21-000022:note_history:48]
New Accounting Pronouncements – not yet adopted by the Company

- removed (2021-11-02):
[0001408710-21-000022:note_history:49]
In December 2019, the FASB issued ASU2019-12, “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.” The amendments in this update simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify U.S. GAAP for other areas of Topic 740 by clarifying and amending existing guidance. For public business entities, the amendments in this update are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2020. This ASU will be effective for the Company in the first quarter of fiscal year 2022. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its unaudited condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0001408710-21-000047:note_history:50]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofSeptember 24, 2021 |  | As ofJune 25, 2021 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterlyinstallments |  | June 2024 |  | $ | 36,562 |  |  | $ | 39,609 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  | (55) |  |  | (63) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 24,319 |  |  | $ | 27,358 |  |
  (was, 2021-05-04, similarity 0.9911):
[0001408710-21-000022:note_history:50]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofMarch 26, 2021 |  | As ofJune 26, 2020 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 42,656 |  |  | $ | 51,797 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  | (71) |  |  | (95) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 30,397 |  |  | $ | 39,514 |  |

- changed (2021-11-02):
[0001408710-21-000047:note_history:51]
The movements of long-term borrowings for the three months ended September 24, 2021 and September 25, 2020 were as follows:
  (was, 2021-05-04, similarity 0.8756):
[0001408710-21-000022:note_history:51]
The movements of long-term borrowings for the nine months ended March 26, 2021 and March 27, 2020 were as follows:

- added (2021-11-02):
[0001408710-21-000047:note_history:52]
|  | Three Months Ended |
| (amount in thousands) | September 24,2021 |  | September 25,2020 |
| Opening balance | $ | 39,609 |  |  | $ | 51,797 |  |
| Borrowings during the period | — |  |  | — |  |
| Repayments during the period | (3,047) |  |  | (3,047) |  |
| Closing balance | $ | 36,562 |  |  | $ | 48,750 |  |

- changed (2021-11-02):
[0001408710-21-000047:note_history:53]
As of September 24, 2021, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2021-05-04, similarity 0.95):
[0001408710-21-000022:note_history:53]
As of March 26, 2021, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2021-11-02):
[0001408710-21-000047:note_history:54]
| (amount in thousands) |  |
| 2022 (remaining 9 months) | $ | 9,141 |  |
| 2023 | 15,233 |  |
| 2024 | 9,141 |  |
| 2025 | 3,047 |  |
| Total | $ | 36,562 |  |
  (was, 2021-05-04, similarity 0.9754):
[0001408710-21-000022:note_history:54]
| (amount in thousands) |  |
| 2021 (remaining three months) | $ | 6,094 |  |
| 2022 | 12,187 |  |
| 2023 | 12,187 |  |
| 2024 | 12,188 |  |
| Total | $ | 42,656 |  |

- changed (2021-11-02):
[0001408710-21-000047:note_history:55]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a credit facility agreement (the “Credit Facility Agreement”), which provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million that may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.
  (was, 2021-05-04, similarity 0.9667):
[0001408710-21-000022:note_history:55]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of September 27,
2019) and $160.9 million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

- changed (2021-11-02):
[0001408710-21-000047:note_history:56]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a term loan agreement (the "Term Loan Agreement") pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original
  (was, 2021-05-04, similarity 0.6234):
[0001408710-21-000022:note_history:56]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a Term Loan Agreement pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company’s previous syndicated senior credit facility agreement.

- added (2021-11-02):
[0001408710-21-000047:note_history:57]
principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Bank of America credit facility agreement.

- changed (2021-11-02):
[0001408710-21-000047:note_history:58]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three months ended September 24, 2021 and September 25, 2020, the Company recorded $0.3 million and $0.2 million, respectively, of interest expense in connection with this term loan.
  (was, 2021-05-04, similarity 0.936):
[0001408710-21-000022:note_history:58]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three and nine  months ended March 26, 2021, the Company recorded $0.2 million and $0.6 million, respectively, of interest expense in connection with this term loan.

- changed (2021-11-02):
[0001408710-21-000047:note_history:59]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, and restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.5 times. As of September 24, 2021, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.
  (was, 2021-05-04, similarity 0.9902):
[0001408710-21-000022:note_history:59]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of March 26, 2021, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

- changed (2021-11-02):
[0001408710-21-000047:note_history:60]
The events of default under the Term Loan Agreement include failure to pay amounts due under the Term Loan Agreement or the related finance documents when due, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.
  (was, 2021-05-04, similarity 0.9933):
[0001408710-21-000022:note_history:60]
The events of default in the Term Loan Agreement include failure to pay amounts due under the Term Loan Agreement or the related finance documents when due, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

- changed (2021-11-02):
[0001408710-21-000047:note_history:61]
As of September 24, 2021, there was $36.6 million outstanding under the term loan.
  (was, 2021-05-04, similarity 0.9296):
[0001408710-21-000022:note_history:61]
As of March 26, 2021, there was $42.7 million outstanding under the term loan.

- removed (2021-11-02):
[0001408710-21-000022:note_history:62]
|  | Nine Months Ended |
| (amount in thousands) | March 26,2021 |  | March 27,2020 |
| Opening balance | $ | 51,797 |  |  | $ | 60,938 |  |
| Borrowings during the period | — |  |  | 60,938 |  |
| Repayments during the period | (9,141) |  |  | (67,032) |  |
| Closing balance | $ | 42,656 |  |  | $ | 54,844 |  |

- removed (2021-11-02):
[0001408710-21-000022:note_history:63]
Bank of America, N.A.

- removed (2021-11-02):
[0001408710-21-000022:note_history:64]
On May 22, 2014, the Company and a consortium of banks, entered into a syndicated senior credit facility agreement led by Bank of America (the “Bank of America Facility Agreement”). The Bank of America Facility Agreement provided for a $200.0 million credit line, comprised of a $150.0 million revolving loan facility and a $50.0 million delayed draw term loan facility.

- removed (2021-11-02):
[0001408710-21-000022:note_history:65]
From time to time, the Company amended the Bank of America Facility Agreement, before repaying all outstanding amounts under the agreement and terminating such agreement on September 10, 2019.

- removed (2021-11-02):
[0001408710-21-000022:note_history:66]
The most recent amendment on June 4, 2018 (i) reduced the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) refinanced the outstanding amounts under the revolving loan and term loan facilities into a $65.0 million term loan which was to be repaid in quarterly installments through the maturity date of June 04, 2023; and (iii) reduced the interest rate margins and commitment fees. The term loan bore interest, at the Company’s option, at a rate per annum equal to a LIBOR rate plus a spread of 1.50% to 2.25%, or a base rate plus a spread of 0.50% to 1.25%. During the three months ended March 27, 2020, the Company had no interest expense related to this term loan. During the nine months ended March 27, 2020, the Company recorded $0.5 million of interest expense in connection with this term loan.

- removed (2021-11-02):
[0001408710-21-000022:note_history:67]
On September 10, 2019, the Company fully repaid $61.0 million in principal, accrued interest and other fees under the agreement. The early termination of this agreement did not trigger any early termination fees.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0001408710-21-000047:note_history:68]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of September 24, 2021 and June 25, 2021:
  (was, 2021-05-04, similarity 0.9655):
[0001408710-21-000022:note_history:68]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of March 26, 2021 and June 26, 2020:

- added (2021-11-02):
[0001408710-21-000047:note_history:69]
|  | September 24, 2021 |  | June 25, 2021 |
| (amount in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 69,219 |  |  | $ | 69,211 |  |  | $ | 30,000 |  |  | $ | 31,226 |  |
| Due between one to five years | 189,186 |  |  | 189,290 |  |  | 202,927 |  |  | 203,237 |  |
| Total | $ | 258,405 |  |  | $ | 258,501 |  |  | $ | 232,927 |  |  | $ | 234,463 |  |

- removed (2021-11-02):
[0001408710-21-000022:note_history:70]
|  | March 26, 2021 |  | June 26, 2020 |
| (amount in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 62,641 |  |  | $ | 62,638 |  |  | $ | 76,127 |  |  | $ | 76,196 |  |
| Due between one to five years | 126,696 |  |  | 127,254 |  |  | 132,223 |  |  | 133,646 |  |
| Total | $ | 189,337 |  |  | $ | 189,892 |  |  | $ | 208,350 |  |  | $ | 209,842 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0001408710-21-000047:note_history:71]
The movements of long-term borrowings for the three months ended September 24, 2021 and September 25, 2020 were as follows:
  (was, 2021-05-04, similarity 0.8756):
[0001408710-21-000022:note_history:71]
The movements of long-term borrowings for the nine months ended March 26, 2021 and March 27, 2020 were as follows:

- added (2021-11-02):
[0001408710-21-000047:note_history:72]
|  | Three Months Ended |
| (amount in thousands) | September 24,2021 |  | September 25,2020 |
| Opening balance | $ | 39,609 |  |  | $ | 51,797 |  |
| Borrowings during the period | — |  |  | — |  |
| Repayments during the period | (3,047) |  |  | (3,047) |  |
| Closing balance | $ | 36,562 |  |  | $ | 48,750 |  |

- removed (2021-11-02):
[0001408710-21-000022:note_history:73]
|  | Nine Months Ended |
| (amount in thousands) | March 26,2021 |  | March 27,2020 |
| Opening balance | $ | 51,797 |  |  | $ | 60,938 |  |
| Borrowings during the period | — |  |  | 60,938 |  |
| Repayments during the period | (9,141) |  |  | (67,032) |  |
| Closing balance | $ | 42,656 |  |  | $ | 54,844 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0001408710-21-000047:note_history:74]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofSeptember 24, 2021 |  | As ofJune 25, 2021 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterlyinstallments |  | June 2024 |  | $ | 36,562 |  |  | $ | 39,609 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  | (55) |  |  | (63) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 24,319 |  |  | $ | 27,358 |  |
  (was, 2021-05-04, similarity 0.9911):
[0001408710-21-000022:note_history:74]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofMarch 26, 2021 |  | As ofJune 26, 2020 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 42,656 |  |  | $ | 51,797 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  | (71) |  |  | (95) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 30,397 |  |  | $ | 39,514 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0001408710-21-000047:note_history:75]
As of September 24, 2021, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2021-05-04, similarity 0.95):
[0001408710-21-000022:note_history:75]
As of March 26, 2021, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2021-11-02):
[0001408710-21-000047:note_history:76]
| (amount in thousands) |  |
| 2022 (remaining 9 months) | $ | 9,141 |  |
| 2023 | 15,233 |  |
| 2024 | 9,141 |  |
| 2025 | 3,047 |  |
| Total | $ | 36,562 |  |
  (was, 2021-05-04, similarity 0.9754):
[0001408710-21-000022:note_history:76]
| (amount in thousands) |  |
| 2021 (remaining three months) | $ | 6,094 |  |
| 2022 | 12,187 |  |
| 2023 | 12,187 |  |
| 2024 | 12,188 |  |
| Total | $ | 42,656 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0001408710-21-000047:note_history:77]
| (amount in thousands, except percentages) | Three Months EndedSeptember 24, 2021 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 25, 2020 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 245,274 |  |  |  |  | 206,950 |  |  |  |
| Others | 1,316 |  |  |  |  | 452 |  |  |  |
| Total revenue in North America | 246,590 |  |  | 45.4 | % |  | 207,402 |  |  | 47.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 64,932 |  |  | (1) |  | 19 |  |  |  |
| Malaysia | 51,749 |  |  |  |  | 43,911 |  |  |  |
| Israel | 27,634 |  |  |  |  | 30,115 |  |  |  |
| Hong Kong | 21,031 |  |  |  |  | 23,505 |  |  |  |
| Japan | 14,977 |  |  |  |  | 20,332 |  |  |  |
| China | 13,635 |  |  |  |  | 13,787 |  |  |  |
| Others | 12,225 |  |  |  |  | 13,977 |  |  |  |
| Total revenue in Asia-Pacific and others | 206,183 |  |  | 37.9 | % |  | 145,646 |  |  | 33.4 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 49,484 |  |  |  |  | 53,611 |  |  |  |
| U.K. | 19,578 |  |  |  |  | 15,311 |  |  |  |
| Germany | 8,425 |  |  |  |  | 5,799 |  |  |  |
| Others | 13,062 |  |  |  |  | 8,870 |  |  |  |
| Total revenue in Europe | $ | 90,549 |  |  | 16.7 | % |  | $ | 83,591 |  |  | 19.1 | % |
| Total revenue | $ | 543,322 |  |  | 100.0 | % |  | $ | 436,639 |  |  | 100.0 | % |
  (was, 2021-05-04, similarity 0.9066):
[0001408710-21-000022:note_history:77]
| (amount in thousands, except percentages) | Three Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 230,177 |  |  |  |  | 661,410 |  |  |  |
| Others | 618 |  |  |  |  | 1,459 |  |  |  |
| Total revenue in North America | 230,795 |  |  | 48.2 | % |  | 662,869 |  |  | 48.4 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Malaysia | 22,910 |  |  |  |  | 107,700 |  |  |  |
| India | 56,719 |  |  |  |  | 85,535 |  |  |  |
| Israel | 25,796 |  |  |  |  | 82,915 |  |  |  |
| Hong Kong | 21,524 |  |  |  |  | 63,397 |  |  |  |
| Japan | 18,582 |  |  |  |  | 56,223 |  |  |  |
| Others | 21,770 |  |  |  |  | 71,477 |  |  |  |
| Total revenue in Asia-Pacific and others | 167,301 |  |  | 34.9 | % |  | 467,247 |  |  | 34.1 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 47,096 |  |  |  |  | 149,696 |  |  |  |
| U.K. | 15,298 |  |  |  |  | 40,742 |  |  |  |
| Germany | 7,543 |  |  |  |  | 19,596 |  |  |  |
| Others | 11,284 |  |  |  |  | 29,633 |  |  |  |
| Total revenue in Europe | $ | 81,221 |  |  | 16.9 | % |  | $ | 239,667 |  |  | 17.5 | % |
| Total revenue | $ | 479,317 |  |  | 100.0 | % |  | $ | 1,369,783 |  |  | 100.0 | % |

- added (2021-11-02):
[0001408710-21-000047:note_history:78]
(1)Due to change in bill-to-location for certain customer.

- removed (2021-11-02):
[0001408710-21-000022:note_history:79]
| (amount in thousands, except percentages) | Three Months EndedMarch 27, 2020 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 27, 2020 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 206,329 |  |  |  |  | 630,023 |  |  |  |
| Others | 422 |  |  |  |  | 1,073 |  |  |  |
| Total revenue in North America | 206,751 |  |  | 50.3 | % |  | 631,096 |  |  | 51.0 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Malaysia | 52,414 |  |  |  |  | 136,698 |  |  |  |
| Japan | 24,985 |  |  |  |  | 78,362 |  |  |  |
| Hong Kong | 20,710 |  |  |  |  | 70,410 |  |  |  |
| Israel | 25,530 |  |  |  |  | 69,310 |  |  |  |
| China | 8,126 |  |  |  |  | 34,882 |  |  |  |
| Others | 9,874 |  |  |  |  | 11,547 |  |  |  |
| Total revenue in Asia-Pacific and others | 141,639 |  |  | 34.4 | % |  | 401,209 |  |  | 32.5 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 26,716 |  |  |  |  | 84,034 |  |  |  |
| U.K. | 22,297 |  |  |  |  | 52,941 |  |  |  |
| Germany | 5,600 |  |  |  |  | 41,207 |  |  |  |
| Others | 8,207 |  |  |  |  | 26,236 |  |  |  |
| Total revenue in Europe | $ | 62,820 |  |  | 15.3 | % |  | $ | 204,418 |  |  | 16.5 | % |
| Total revenue | $ | 411,210 |  |  | 100.0 | % |  | $ | 1,236,723 |  |  | 100.0 | % |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-11-02):
[0001408710-21-000047:note_history:80]
| (amount in thousands, except percentages) | Three Months EndedSeptember 24, 2021 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 25, 2020 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 245,274 |  |  |  |  | 206,950 |  |  |  |
| Others | 1,316 |  |  |  |  | 452 |  |  |  |
| Total revenue in North America | 246,590 |  |  | 45.4 | % |  | 207,402 |  |  | 47.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 64,932 |  |  | (1) |  | 19 |  |  |  |
| Malaysia | 51,749 |  |  |  |  | 43,911 |  |  |  |
| Israel | 27,634 |  |  |  |  | 30,115 |  |  |  |
| Hong Kong | 21,031 |  |  |  |  | 23,505 |  |  |  |
| Japan | 14,977 |  |  |  |  | 20,332 |  |  |  |
| China | 13,635 |  |  |  |  | 13,787 |  |  |  |
| Others | 12,225 |  |  |  |  | 13,977 |  |  |  |
| Total revenue in Asia-Pacific and others | 206,183 |  |  | 37.9 | % |  | 145,646 |  |  | 33.4 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 49,484 |  |  |  |  | 53,611 |  |  |  |
| U.K. | 19,578 |  |  |  |  | 15,311 |  |  |  |
| Germany | 8,425 |  |  |  |  | 5,799 |  |  |  |
| Others | 13,062 |  |  |  |  | 8,870 |  |  |  |
| Total revenue in Europe | $ | 90,549 |  |  | 16.7 | % |  | $ | 83,591 |  |  | 19.1 | % |
| Total revenue | $ | 543,322 |  |  | 100.0 | % |  | $ | 436,639 |  |  | 100.0 | % |
  (was, 2021-05-04, similarity 0.9066):
[0001408710-21-000022:note_history:80]
| (amount in thousands, except percentages) | Three Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 230,177 |  |  |  |  | 661,410 |  |  |  |
| Others | 618 |  |  |  |  | 1,459 |  |  |  |
| Total revenue in North America | 230,795 |  |  | 48.2 | % |  | 662,869 |  |  | 48.4 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Malaysia | 22,910 |  |  |  |  | 107,700 |  |  |  |
| India | 56,719 |  |  |  |  | 85,535 |  |  |  |
| Israel | 25,796 |  |  |  |  | 82,915 |  |  |  |
| Hong Kong | 21,524 |  |  |  |  | 63,397 |  |  |  |
| Japan | 18,582 |  |  |  |  | 56,223 |  |  |  |
| Others | 21,770 |  |  |  |  | 71,477 |  |  |  |
| Total revenue in Asia-Pacific and others | 167,301 |  |  | 34.9 | % |  | 467,247 |  |  | 34.1 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 47,096 |  |  |  |  | 149,696 |  |  |  |
| U.K. | 15,298 |  |  |  |  | 40,742 |  |  |  |
| Germany | 7,543 |  |  |  |  | 19,596 |  |  |  |
| Others | 11,284 |  |  |  |  | 29,633 |  |  |  |
| Total revenue in Europe | $ | 81,221 |  |  | 16.9 | % |  | $ | 239,667 |  |  | 17.5 | % |
| Total revenue | $ | 479,317 |  |  | 100.0 | % |  | $ | 1,369,783 |  |  | 100.0 | % |

- added (2021-11-02):
[0001408710-21-000047:note_history:81]
(1)Due to change in bill-to-location for certain customer.

- changed (2021-11-02):
[0001408710-21-000047:note_history:82]
| (amount in thousands, except percentages) | Three Months EndedSeptember 24, 2021 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 25, 2020 |  | As a % of TotalRevenues |
| Optical communications | $ | 427,301 |  |  | 78.6 | % |  | $ | 343,917 |  |  | 78.8 | % |
| Lasers, sensors and other | 116,021 |  |  | 21.4 | % |  | 92,722 |  |  | 21.2 | % |
| Total | $ | 543,322 |  |  | 100.0 | % |  | $ | 436,639 |  |  | 100.0 | % |
  (was, 2021-05-04, similarity 0.697):
[0001408710-21-000022:note_history:82]
| (amount in thousands, except percentages) | Three Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |
| Optical communications | $ | 361,739 |  |  | 75.5 | % |  | $ | 1,053,496 |  |  | 76.9 | % |
| Lasers, sensors and other | 117,578 |  |  | 24.5 | % |  | 316,287 |  |  | 23.1 | % |
| Total | $ | 479,317 |  |  | 100.0 | % |  | $ | 1,369,783 |  |  | 100.0 | % |

- changed (2021-11-02):
[0001408710-21-000047:note_history:83]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the three months ended September 24, 2021:
  (was, 2021-05-04, similarity 0.9408):
[0001408710-21-000022:note_history:83]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the nine months ended March 26, 2021:

- changed (2021-11-02):
[0001408710-21-000047:note_history:84]
| (amount in thousands) | ContractAssets |
| Beginning balance, June 25, 2021 | $ | 11,878 |  |
| Revenue recognized | 13,197 |  |
| Amounts collected or invoiced | (11,955) |  |
| Ending balance, September 24, 2021 | $ | 13,120 |  |
  (was, 2021-05-04, similarity 0.9746):
[0001408710-21-000022:note_history:84]
| (amount in thousands) | ContractAssets |
| Beginning balance, June 26, 2020 | $ | 13,256 |  |
| Revenue recognized | 50,841 |  |
| Amounts collected or invoiced | (46,967) |  |
| Ending balance, March 26, 2021 | $ | 17,130 |  |

- changed (2021-11-02):
[0001408710-21-000047:note_history:85]
| (amount in thousands) | ContractLiabilities |
| Beginning balance, June 25, 2021 | $ | 1,680 |  |
| Advance payment received during the period | 1,941 |  |
| Revenue recognized | (1,866) |  |
| Ending balance, September 24, 2021 | $ | 1,755 |  |
  (was, 2021-05-04, similarity 0.9721):
[0001408710-21-000022:note_history:85]
| (amount in thousands) | ContractLiabilities |
| Beginning balance, June 26, 2020 | $ | 1,556 |  |
| Advance payment received during the period | 16,414 |  |
| Revenue recognized | (16,561) |  |
| Ending balance, March 26, 2021 | $ | 1,409 |  |

- removed (2021-11-02):
[0001408710-21-000022:note_history:86]
| (amount in thousands, except percentages) | Three Months EndedMarch 27, 2020 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 27, 2020 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 206,329 |  |  |  |  | 630,023 |  |  |  |
| Others | 422 |  |  |  |  | 1,073 |  |  |  |
| Total revenue in North America | 206,751 |  |  | 50.3 | % |  | 631,096 |  |  | 51.0 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Malaysia | 52,414 |  |  |  |  | 136,698 |  |  |  |
| Japan | 24,985 |  |  |  |  | 78,362 |  |  |  |
| Hong Kong | 20,710 |  |  |  |  | 70,410 |  |  |  |
| Israel | 25,530 |  |  |  |  | 69,310 |  |  |  |
| China | 8,126 |  |  |  |  | 34,882 |  |  |  |
| Others | 9,874 |  |  |  |  | 11,547 |  |  |  |
| Total revenue in Asia-Pacific and others | 141,639 |  |  | 34.4 | % |  | 401,209 |  |  | 32.5 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 26,716 |  |  |  |  | 84,034 |  |  |  |
| U.K. | 22,297 |  |  |  |  | 52,941 |  |  |  |
| Germany | 5,600 |  |  |  |  | 41,207 |  |  |  |
| Others | 8,207 |  |  |  |  | 26,236 |  |  |  |
| Total revenue in Europe | $ | 62,820 |  |  | 15.3 | % |  | $ | 204,418 |  |  | 16.5 | % |
| Total revenue | $ | 411,210 |  |  | 100.0 | % |  | $ | 1,236,723 |  |  | 100.0 | % |

- removed (2021-11-02):
[0001408710-21-000022:note_history:87]
| (amount in thousands, except percentages) | Three Months EndedMarch 27, 2020 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 27, 2020 |  | As a % of TotalRevenues |
| Optical communications | $ | 308,566 |  |  | 75.0 | % |  | $ | 933,013 |  |  | 75.4 | % |
| Lasers, sensors and other | 102,644 |  |  | 25.0 | % |  | 303,710 |  |  | 24.6 | % |
| Total | $ | 411,210 |  |  | 100.0 | % |  | $ | 1,236,723 |  |  | 100.0 | % |
