# FN MD&A — 0001408710-21-000034


## mdna

[0001408710-21-000034:mdna:1]
ITEM 7.MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS.

[0001408710-21-000034:mdna:2]
•our goals and strategies;

[0001408710-21-000034:mdna:3]
•our and our customers’ estimates regarding future revenues, operating results, expenses, capital requirements and liquidity;

[0001408710-21-000034:mdna:4]
•our expectation that the portion of our future revenues attributable to customers in regions outside of North America will decrease compared with the portion of those revenues for fiscal year 2021;

[0001408710-21-000034:mdna:5]
•our expectation that we will incur incremental costs of revenue as a result of our planned expansion of our business into new geographic markets;

[0001408710-21-000034:mdna:6]
•our expectation that our fiscal year 2022 selling, general and administrative (“SG&A”) expenses will increase compared to our fiscal year 2021 SG&A expenses;

[0001408710-21-000034:mdna:7]
•our expectation that our employee costs will increase in Thailand and the People’s Republic of China (“PRC”);

[0001408710-21-000034:mdna:8]
•our future capital expenditures and our needs for additional financing;

[0001408710-21-000034:mdna:9]
•the expansion of our manufacturing capacity, including into new geographies;

[0001408710-21-000034:mdna:10]
•the growth rates of our existing markets and potential new markets;

[0001408710-21-000034:mdna:11]
•our ability, and the ability of our customers and suppliers, to respond successfully to technological or industry developments;

[0001408710-21-000034:mdna:12]
•our expectations regarding the potential impact of the COVID-19 pandemic on our business, financial condition and results of operations;

[0001408710-21-000034:mdna:13]
•our suppliers’ estimates regarding future costs;

[0001408710-21-000034:mdna:14]
•our ability to increase our penetration of existing markets and to penetrate new markets;

[0001408710-21-000034:mdna:15]
•our plans to diversify our sources of revenues;

[0001408710-21-000034:mdna:16]
•our plans to execute acquisitions;

[0001408710-21-000034:mdna:17]
•trends in the optical communications, industrial lasers, and sensors markets, including trends to outsource the production of components used in those markets;

[0001408710-21-000034:mdna:18]
•our ability to attract and retain a qualified management team and other qualified personnel and advisors; and

[0001408710-21-000034:mdna:19]
•competition in our existing and new markets.

[0001408710-21-000034:mdna:20]
Overview

[0001408710-21-000034:mdna:21]
For an overview of our business, see PART I – ITEM 1. BUSINESS.

[0001408710-21-000034:mdna:22]
Fiscal Years

[0001408710-21-000034:mdna:23]
We utilize a 52-53 week fiscal year ending on the Friday in June closest to June 30. Fiscal year 2021 ended on June 25, 2021 and consisted of 52 weeks. Fiscal year 2020 ended on June 26, 2020 and consisted of 52 weeks. Fiscal year 2019 ended on June 28, 2019 and consisted of 52 weeks.

[0001408710-21-000034:mdna:24]
Recent Developments Related to COVID-19

[0001408710-21-000034:mdna:25]
For a discussion of the effects of COVID-19 on our business, see “Recent Developments Related to COVID-19” in PART I – ITEM 1. BUSINESS.

[0001408710-21-000034:mdna:26]
Revenues

[0001408710-21-000034:mdna:27]
We believe our ability to expand our relationships with existing customers and attract new customers is due to a number of factors, including our broad range of complex engineering and manufacturing service offerings, flexible low-cost manufacturing platform, process optimization capabilities, advanced supply chain management, excellent customer service, and experienced management team. Although we expect the prices we charge for our manufactured products to decrease over time (partly as a result of competitive market forces), we still believe we will be able to maintain favorable pricing for our services because of our ability to reduce cycle time, adjust our product mix by focusing on more complicated products, improve product quality and yields, and reduce material costs for the products we manufacture. We believe these capabilities have enabled us to help our OEM customers reduce their manufacturing costs while maintaining or improving the design, quality, reliability, and delivery times for their products.

[0001408710-21-000034:mdna:28]
Revenues, by percentage, from individual customers representing 10% or more of our total revenues is set forth in Note 22 of our audited consolidated financial statements. Because we depend upon a small number of customers for a significant percentage of our total revenues, a reduction in orders from, a loss of, or any other adverse actions by, any one of these customers would reduce our revenues and could have a material adverse effect on our business, operating results and share price. Moreover, our customer concentration increases the concentration of our accounts receivable and payment default by any of our key customers will negatively impact our exposure. Many of our existing and potential customers have substantial debt burdens, have experienced financial distress or have static or declining revenues, all of which may be exacerbated by the continued uncertainty in the global economies. Certain customers have gone out of business or have been acquired or announced their withdrawal from segments of the optics market. We generate significant accounts payable and inventory for the services that we provide to our customers, which could expose us to substantial and potentially unrecoverable costs if we do not receive payment from our customers. Therefore, any financial difficulties that our key customers experience could materially and adversely affect our operating results and financial condition by generating charges for inventory write-offs, provisions for doubtful accounts, and increases in working capital requirements due to increased days inventory and in accounts receivable.

[0001408710-21-000034:mdna:29]
Furthermore, reliance on a small number of customers gives those customers substantial purchasing power and leverage in negotiating contracts with us. In addition, although we enter into master supply agreements with our customers, the level of business to be transacted under those agreements is not guaranteed. Instead, we are awarded business under those agreements on a project-by-project basis. Some of our customers have at times significantly reduced or delayed the volume of manufacturing services that they order from us. If we are unable to maintain our relationships with our existing significant customers, our business, financial condition and operating results could be harmed.

[0001408710-21-000034:mdna:30]
COVID-19 has also created dynamics in the semiconductor component supply chain that have led to shortages of the types of components needed in the products we manufacture for our customers. If we or our customers are unable to procure needed semiconductor components, our ability to manufacture products for our customers will be impacted, which may reduce our revenue as we experienced during the fourth quarter of fiscal year 2021. The impact of semiconductor component shortages may increase in the near term as supplier and customer buffer inventories and safety stocks are exhausted.

[0001408710-21-000034:mdna:31]
Revenues by Geography

[0001408710-21-000034:mdna:32]
We generate revenues from three geographic regions: North America, Asia-Pacific, and Europe. Revenues are attributed to a particular geographic area based on the bill-to-location of our customers, notwithstanding that our customers may ultimately ship their products to end customers in a different geographic region. The substantial majority of our revenues are derived from our manufacturing facilities in Asia-Pacific.

[0001408710-21-000034:mdna:33]
The percentage of our revenues generated from a bill-to-location outside of North America increased from 49.4% in fiscal year 2020 to 52.8% in fiscal year 2021, which was partially due to an increase in sales to our customers in Asia-Pacific by 1.9%. Based on the short- and medium-term indications and forecasts from our customers, we expect that the portion of our

[0001408710-21-000034:mdna:34]
future revenues attributable to customers in regions outside of North America will decrease as compared with the portion of revenues attributable to such customers during fiscal year 2021.

[0001408710-21-000034:mdna:35]
The following table presents percentages of total revenues by geographic regions:

[0001408710-21-000034:mdna:36]
|  | Years Ended |
|  | June 25, 2021 |  | June 26, 2020 |  | June 28, 2019 |
| North America | 47.2 | % |  | 50.6 | % |  | 47.7 | % |
| Asia-Pacific | 35.6 |  |  | 33.7 |  |  | 38.4 |  |
| Europe | 17.2 |  |  | 15.7 |  |  | 13.9 |  |
|  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001408710-21-000034:mdna:37]
Our Contracts

[0001408710-21-000034:mdna:38]
We enter into supply agreements with our customers which generally have an initial term of up to three years, subject to automatic renewals for subsequent one-year terms unless expressly terminated. Although there are no minimum purchase requirements in our supply agreements, our customers provide us with rolling forecasts of their demand requirements. Our supply agreements generally include provisions for pricing and periodic review of pricing, consignment of our customer’s unique production equipment to us, and the sharing of benefits from cost-savings derived from our efforts. We are generally required to purchase materials, which may include long lead-time materials and materials that are subject to minimum order quantities and/or non-cancelable or non-returnable terms, to meet the stated demands of our customers. After procuring materials, we manufacture products for our customers based on purchase orders that contain terms regarding product quantities, delivery locations and delivery dates. Our customers generally are obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by our customers within a specified period of time, or that are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under our contracts. Once materials are designated as either excess or obsolete inventory, our customers are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

[0001408710-21-000034:mdna:39]
Cost of Revenues

[0001408710-21-000034:mdna:40]
The key components of our cost of revenues are material costs, employee costs, and infrastructure-related costs. Material costs generally represent the majority of our cost of revenues. Several of the materials we require to manufacture products for our customers are customized for their products and often sourced from a single supplier or in some cases, our own subsidiaries. Shortages from sole-source suppliers due to yield loss, quality concerns and capacity constraints, among other factors, may increase our expenses and negatively impact our gross profit margin or total revenues in a given quarter. Material costs include scrap material. Historically, scrap rate diminishes during a product’s life cycle due to process, fixturing and test improvement and optimization.

[0001408710-21-000034:mdna:41]
A second significant element of our cost of revenues is employee costs, including indirect employee costs related to design, configuration and optimization of manufacturing processes for our customers, quality testing, materials testing and other engineering services; and direct costs related to our manufacturing employees. Direct employee costs include employee salaries, insurance and benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a lesser extent, costs to recruit, train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand, the PRC and the United Kingdom, the fluctuation of the Thai baht, RMB and GBP against our functional currency, the U.S. dollar, and our ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention and asset utilization.

[0001408710-21-000034:mdna:42]
Our infrastructure costs are comprised of depreciation, utilities, facilities management and overhead costs. Most of our facility leases are long-term agreements. Our depreciation costs include buildings and fixed assets, primarily at our Pinehurst and Chonburi campuses in Thailand, and capital equipment located at each of our manufacturing locations.

[0001408710-21-000034:mdna:43]
During fiscal years 2021, 2020 and 2019, discretionary merit-based bonus awards were made to our non-executive employees. Charges included in cost of revenues for bonus awards to non-executive employees were $4.7 million, $4.6 million and $3.9 million for fiscal years 2021, 2020 and 2019, respectively.

[0001408710-21-000034:mdna:44]
Share-based compensation expense included in cost of revenues was $6.2 million, $6.1 million and $5.7 million for fiscal years 2021, 2020 and 2019, respectively.

[0001408710-21-000034:mdna:45]
We expect to incur incremental costs of revenue as a result of our planned expansion into new geographic markets, though we are not able to determine the amount of these incremental expenses.

[0001408710-21-000034:mdna:46]
In addition, we expect our cost of revenue to increase in the first quarter of fiscal 2022 in response to the recent surge in COVID-19 cases, particularly in our Thailand operations. We have implemented additional safeguards beyond what we have been doing for the past 18 months in order to protect our employees. For example, we have increased testing of our employees and have sent employees home – with pay – if they test positive for COVID-19. In addition, we have been granted permission by the Thai government to vaccinate our employees and have been carrying out this initiative since July 2021 at our expense.

[0001408710-21-000034:mdna:47]
Selling, General and Administrative Expenses

[0001408710-21-000034:mdna:48]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative and other support personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other general expenses not related to cost of revenues. In fiscal year 2022, we expect our SG&A expenses will increase compared with our fiscal year 2021 SG&A expenses.

[0001408710-21-000034:mdna:49]
The compensation committee of our board of directors approved a fiscal year 2021 executive incentive plan with quantitative objectives based solely on achieving certain revenue targets and non-U.S. GAAP operating margin targets for fiscal year 2021. Bonuses under the fiscal year 2021 executive incentive plan are payable after the end of fiscal year 2021. In fiscal year 2020, the compensation committee approved a fiscal year 2020 executive incentive plan with quantitative objectives that were based solely on achieving certain revenue targets and non-U.S. GAAP operating margin targets for fiscal year 2020. In the three months ended September 29, 2020, the compensation committee awarded bonuses to our executive employees for Company achievements of performance under our fiscal year 2020 executive incentive plan. Discretionary merit-based bonus awards are also available to our non-executive employees and payable on a quarterly basis.

[0001408710-21-000034:mdna:50]
Charges included in SG&A expenses for bonus distributions to non-executive and executive employees were $4.2 million, $4.1 million and $3.7 million for fiscal years 2021, 2020 and 2019, respectively.

[0001408710-21-000034:mdna:51]
Share-based compensation expense included in SG&A expenses was $19.3 million, $16.1 million and $11.5 million for fiscal years 2021, 2020 and 2019, respectively.

[0001408710-21-000034:mdna:52]
Additional Financial Disclosures

[0001408710-21-000034:mdna:53]
Foreign Exchange

[0001408710-21-000034:mdna:54]
As a result of our international operations, we are exposed to foreign exchange risk arising from various currency exposures primarily with respect to the Thai baht. Although a majority of our total revenues is denominated in U.S. dollars, a substantial portion of our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rate between the Thai baht and the U.S. dollar has fluctuated substantially in recent years and may continue to fluctuate substantially in the future. We report our financial results in U.S. dollars and our results of operations have been and could in the future be negatively impacted if the Thai baht appreciates against the U.S. dollar. Smaller portions of our expenses are incurred in a variety of other currencies, including RMB, GBP, Canadian dollars, Euros, and Japanese yen, the appreciation of which may also negatively impact our financial results.

[0001408710-21-000034:mdna:55]
In order to manage the risks arising from fluctuations in foreign currency exchange rates, we use derivative instruments. We may enter into foreign currency exchange forward or put option contracts to manage foreign currency exposures associated with certain assets and liabilities and other forecasted foreign currency transactions and may designate these instruments as hedging instruments. The forward and put option contracts generally have maturities of up to 12 months. All foreign currency exchange contracts are recognized in the consolidated balance sheets at fair value. Gains or losses on our forward and put option contracts generally present gross amount in the assets, liabilities, and transactions economically hedged.

[0001408710-21-000034:mdna:56]
We had foreign currency denominated assets and liabilities in Thai baht, RMB and GBP as follows:

[0001408710-21-000034:mdna:57]
|  | As of June 25, 2021 |  | As of June 26, 2020 |
| (amount in thousands, except percentages) | ForeignCurrency |  | $ |  | % |  | ForeignCurrency |  | $ |  | % |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 1,472,249 |  |  | $ | 46,312 |  |  | 67.5 |  |  | 667,955 |  |  | $ | 21,617 |  |  | 41.8 |  |
| RMB | 98,056 |  |  | 15,145 |  |  | 22.1 |  |  | 158,060 |  |  | 22,402 |  |  | 43.3 |  |
| GBP | 5,111 |  |  | 7,119 |  |  | 10.4 |  |  | 6,220 |  |  | 7,726 |  |  | 14.9 |  |
| Total |  |  | $ | 68,576 |  |  | 100.0 |  |  |  |  | $ | 51,745 |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 2,250,514 |  |  | $ | 70,793 |  |  | 87.7 |  |  | 2,102,392 |  |  | $ | 68,039 |  |  | 89.5 |  |
| RMB | 40,112 |  |  | 6,195 |  |  | 7.7 |  |  | 42,586 |  |  | 6,036 |  |  | 8.0 |  |
| GBP | 2,656 |  |  | 3,699 |  |  | 4.6 |  |  | 1,545 |  |  | 1,919 |  |  | 2.5 |  |
| Total |  |  | $ | 80,687 |  |  | 100.0 |  |  |  |  | $ | 75,994 |  |  | 100.0 |  |

[0001408710-21-000034:mdna:58]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of June 25, 2021, there was $130.0 million in foreign currency forward contracts outstanding on the Thai baht payables. As of June 26, 2020, there was $125.0 million in foreign currency forward contracts and $1.0 million in foreign currency option contracts outstanding on the Thai baht payables.

[0001408710-21-000034:mdna:59]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of June 25, 2021 and June 26, 2020, we did not have any derivative contracts denominated in RMB.

[0001408710-21-000034:mdna:60]
The GBP assets represent cash and trade accounts receivable. The GBP liabilities represent trade accounts payable and other payables. As of June 25, 2021 and June 26, 2020, we did not have any derivative contracts denominated in GBP.

[0001408710-21-000034:mdna:61]
For fiscal years 2021 and 2020, we recorded an unrealized loss of $1.5 million and $1.2 million, respectively, related to derivatives that are not designated as hedging instruments in the consolidated statements of operations and comprehensive income.

[0001408710-21-000034:mdna:62]
Currency Regulation and Dividend Distribution

[0001408710-21-000034:mdna:63]
Foreign exchange regulation in the PRC is primarily governed by the following rules:

[0001408710-21-000034:mdna:64]
•Foreign Currency Administration Rules, as amended on August 5, 2008, or the Exchange Rules;

[0001408710-21-000034:mdna:65]
•Administration Rules of the Settlement, Sale and Payment of Foreign Exchange (1996), or the Administration Rules; and

[0001408710-21-000034:mdna:66]
•Notice on Perfecting Practices Concerning Foreign Exchange Settlement Regarding the Capital Contribution by Foreign-invested Enterprises, as promulgated by the State Administration of Foreign Exchange (“SAFE”), on August 29, 2008, or Circular 142.

[0001408710-21-000034:mdna:67]
Under the Exchange Rules, RMB is freely convertible into foreign currencies for current account items, including the distribution of dividends, interest payments, trade and service-related foreign exchange transactions. However, conversion of RMB for capital account items, such as direct investments, loans, security investments and repatriation of investments, is still subject to the approval of SAFE.

[0001408710-21-000034:mdna:68]
Under the Administration Rules, foreign-invested enterprises may only buy, sell, or remit foreign currencies at banks authorized to conduct foreign exchange business after providing valid commercial documents and relevant supporting documents and, in the case of capital account item transactions, obtaining approval from SAFE. Capital investments by foreign-invested enterprises outside of the PRC are also subject to limitations, which include approvals by the Ministry of Commerce, SAFE and the State Development and Reform Commission.

[0001408710-21-000034:mdna:69]
Circular 142 regulates the conversion by a foreign-invested company of foreign currency into RMB by restricting how the converted RMB may be used. Circular 142 requires that the registered capital of a foreign-invested enterprise settled in RMB converted from foreign currencies may only be used for purposes within the business scope approved by the applicable governmental authority and may not be used for equity investments within the PRC. In addition, SAFE strengthened its oversight of the flow and use of the registered capital of foreign-invested enterprises settled in RMB converted from foreign currencies. The use of such RMB capital may not be changed without SAFE’s approval and may not be used to repay RMB loans if the proceeds of such loans have not been used.

[0001408710-21-000034:mdna:70]
On January 5, 2007, SAFE promulgated the Detailed Rules for Implementing the Measures for the Administration on Individual Foreign Exchange, or the Implementation Rules. Under the Implementation Rules, PRC citizens who are granted share options by an overseas publicly-listed company are required, through a PRC agent or PRC subsidiary of such overseas publicly-listed company, to register with SAFE and complete certain other procedures.

[0001408710-21-000034:mdna:71]
In addition, the General Administration of Taxation has issued circulars concerning employee share options. Under these circulars, our employees working in the PRC who exercise share options will be subject to PRC individual income tax. Our PRC subsidiary has obligations to file documents related to employee share options with relevant tax authorities and withhold individual income taxes of those employees who exercise their share options.

[0001408710-21-000034:mdna:72]
Furthermore, our transfer of funds to our subsidiaries in Thailand and the PRC are each subject to approval by governmental authorities in case of an increase in registered capital, or subject to registration with governmental authorities in case of a shareholder loan. These limitations on the flow of funds between our subsidiaries and us could restrict our ability to act in response to changing market conditions.

[0001408710-21-000034:mdna:73]
Income Tax

[0001408710-21-000034:mdna:74]
Our effective tax rate is a function of the mix of tax rates in the various jurisdictions in which we do business. We are domiciled in the Cayman Islands. Under the current laws of the Cayman Islands, we are not subject to tax in the Cayman Islands on income or capital gains until March 6, 2039.

[0001408710-21-000034:mdna:75]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption on income generated from projects to manufacture certain products at our Chonburi campus is currently available to us through June 2026. Similar preferential tax treatment was available to us through June 2020 with respect to products manufactured at our Pinehurst campus Building 6. After June 2020, 50% of our income generated from products manufactured at our Pinehurst campus will be exempted from tax through June 2025. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted. Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001408710-21-000034:mdna:76]
The Tax Cuts and Jobs Act was enacted on December 22, 2017 and provided for significant changes to U.S. tax law, including a reduction in the U.S. corporate income tax rate to 21%, which is the current rate for our U.S. subsidiaries.

[0001408710-21-000034:mdna:77]
The corporate income tax rates for our subsidiaries in the PRC, the U.K. and Israel are 25%, 19% and 23%, respectively.

[0001408710-21-000034:mdna:78]
Critical Accounting Policies and Use of Estimates

[0001408710-21-000034:mdna:79]
We prepare our consolidated financial statements in conformity with U.S. GAAP, which requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent liabilities on the date of the consolidated financial statements and the reported amounts of revenues and expenses during the financial reporting period. We continually evaluate these estimates and assumptions based on the most recently available information, our own historical experience and on various other assumptions that we believe to be reasonable under the circumstances. The evaluation results form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Because the use of estimates is an integral component of the financial reporting process, actual results could differ from those estimates. Some of our accounting policies require higher degrees of judgment than others in their application. We consider the policies discussed below to be critical to an understanding of our consolidated financial statements, as their application places the most significant demands on our management’s judgment.

[0001408710-21-000034:mdna:80]
A quantitative sensitivity analysis is provided where such information is reasonably available, can be reliably estimated, and provides material information to investors. The amounts used to assess sensitivity are included for illustrative purposes only and do not represent management’s predictions of variability.

[0001408710-21-000034:mdna:81]
Our critical accounting policies and the adoption of new accounting policies are disclosed in Note 2 – Summary of significant accounting policies. There were no changes to our accounting policies other than the adoption of ASC 326, “Financial Instruments—Credit Losses: Measurement of Credit Losses on Financial Instruments” and ASC 820, “Disclosure Framework – Changes to the Disclosure Requirements for Fair Value Measurement."

[0001408710-21-000034:mdna:82]
Revenue Recognition

[0001408710-21-000034:mdna:83]
On June 30, 2018, we adopted ASC 606 using the modified retrospective method, which was applied to those contracts which were not completed as of June 29, 2018. The modified retrospective method required us to recognize the cumulative effect of the adoption of ASC 606, for all contracts with customers, to the opening balance of equity at June 30, 2018.

[0001408710-21-000034:mdna:84]
We derive total revenues primarily from the assembly of products under supply agreements with our customers and the fabrication of customized optics and glass. We recognize revenue relating to contracts that depict the transfer of promised goods or services to customers in an amount reflecting the consideration to which we expect to be entitled in exchange for such goods or services. In order to meet this requirement, we apply the following five steps: (1) identify the contract with a customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract, and (5) recognize revenue when a performance obligation is satisfied. Revenue is recognized net of any taxes collected from customers, which is subsequently remitted to governmental authorities.

[0001408710-21-000034:mdna:85]
A performance obligation is a contractual promise to transfer a distinct good or service to the customer. In contracts with multiple performance obligations, we identify each performance obligation and evaluate whether the performance obligation is distinct within the context of the contract at contract inception. The majority of our contracts have a single performance obligation, as the promise to transfer the individual goods or services is not separately identifiable from other promises under the contracts and, therefore, is not distinct.

[0001408710-21-000034:mdna:86]
Sales of finished goods

[0001408710-21-000034:mdna:87]
We manufacture products that are customized to customers’ specifications; however, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for over time recognition are not met. On evaluation of the contracts, we identified that there were no contractual rights to bill profit for work in progress in the event of a contract termination, which is expected to be infrequent. Further, in limited circumstances, contracts provide for substantive acceptance by the customer, which results in the deferral of revenue until formal notice of acceptance is received from the customer. Judgment may be required in determining if an acceptance clause provides for substantive acceptance.

[0001408710-21-000034:mdna:88]
Certain customers may request us to store finished products at our warehouse where customers bear risks of loss themselves. In these instances, we receive a written request from the customer asking us to hold the inventory at our warehouse and refrain from using the ordered goods to fulfill other customer orders. In these situations, revenue is only recognized when the completed goods are ready for shipment and transferred to our warehouse.

[0001408710-21-000034:mdna:89]
Customers generally are obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by customers within a specified period of time, or are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under our contracts. Once materials are designated as either excess or obsolete inventory, customers are typically required to purchase such inventory from us even if the customer has chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

[0001408710-21-000034:mdna:90]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. In determining the net consideration to which we expect to be entitled, we evaluate whether the price is subject to refund or adjustment. We generally do not grant return privileges, except for in the case of defective products during the warranty period. We generally provide a warranty of between one to five years on any given product. These standard warranties are assurance-type warranties, and we do not offer any services in addition to the assurance that the product will continue to work as specified.

[0001408710-21-000034:mdna:91]
We recognize revenue net of rebates and other similar allowances. Revenues are recognized only if these estimates can be reasonably and reliably determined. We estimate expected rebates and other similar allowances based on historical results taking into consideration the type of customer, the type of transaction and the specifics of each arrangement. We consider such estimated rebates and other similar allowances as variable consideration when allocating the transaction price to the extent it is probable that there will not be a significant reversal of cumulative revenue recognized. The estimate is primarily based on the most likely level of consideration to be paid to the customer under the specific terms of each arrangement.

[0001408710-21-000034:mdna:92]
Services

[0001408710-21-000034:mdna:93]
We provide services for customers that are related to our manufacturing activities. In many cases, although the nature of work performed is that of a service, revenue is only recognizable upon shipment of the product because the customer has specific requirements as to how many items can be shipped at any given point in time, i.e. at point-in-time. The related costs are expensed as incurred.

[0001408710-21-000034:mdna:94]
Long-Lived Assets

[0001408710-21-000034:mdna:95]
We review property, plant and equipment for impairment on a quarterly basis or when events or changes in circumstances indicate the carrying amount of an asset may not be recoverable. An impairment loss is recognized when the carrying amount of a long-lived asset or assets group exceeds its fair value. Recoverability of property and equipment is measured by comparing carrying amount to the projected undiscounted cash flows the property and equipment are expected to generate. If such assets are considered to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the property and equipment exceeds its fair value.

[0001408710-21-000034:mdna:96]
Allowance for Doubtful Accounts

[0001408710-21-000034:mdna:97]
We perform ongoing credit evaluations of our customers’ financial condition and make provisions for doubtful accounts based on the outcomes of these credit evaluations. We evaluate the collectability of our accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections, and the age of past due receivables. Unanticipated changes in the liquidity or financial position of our customers may require additional provisions for doubtful accounts. Under our specific identification method, it is not practical to assess the sensitivity of our estimates.

[0001408710-21-000034:mdna:98]
Inventory Valuation

[0001408710-21-000034:mdna:99]
Our inventory is stated at the lower of cost (on a first-in, first-out basis) or market value. Our industry is characterized by rapid technological change, short-term customer commitments, and rapid changes in demand. We make provisions for estimated excess and obsolete inventory based on regular reviews of inventory quantities on hand on a quarterly basis and the latest forecasts of product demand and production requirements from our customers. If actual market conditions or our customers’ product demands are less favorable than those projected, additional provisions may be required. In addition, unanticipated changes in liquidity or the financial positions of our customers or changes in economic conditions may require additional provisions for inventory due to our customers’ inability to fulfill their contractual obligations. During fiscal year 2021 and fiscal year 2020, a change of 10% for excess and obsolete materials, based on product demand and production requirements from our customers, would have affected our net income by approximately $0.1 million and $0.2 million, respectively.

[0001408710-21-000034:mdna:100]
Deferred Income Taxes

[0001408710-21-000034:mdna:101]
Our deferred income tax assets represent temporary differences between the carrying amount and the tax basis of existing assets and liabilities that will result in deductible and payable amounts in future years, including net operating loss carry forwards. Based on estimates, the carrying value of our net deferred tax assets assumes that it is more likely than not that we will be able to generate sufficient future taxable income in certain tax jurisdictions to realize these deferred income tax assets. Our judgments regarding future profitability may change depending on future market conditions, changes in U.S. or international tax laws, or other factors. If these estimates and related assumptions change in the future, we may be required to increase or decrease our valuation allowance against the deferred tax assets, resulting in additional or lesser income tax expense.

[0001408710-21-000034:mdna:102]
As of the end of fiscal year 2019, we had assessed and set up a partial valuation allowance for the deferred tax assets at the same level as in fiscal year 2018. However, in fiscal year 2020, one of our subsidiaries in the U.S. generated net operating loss and management expected that such subsidiary would continue to have net operating losses in the foreseeable future; therefore, management believed it was more likely than not that all of the deferred tax assets of such subsidiary would not be utilized. Thus, a full valuation allowance of $2.1 million for the deferred tax assets was set up as of the end of fiscal year 2020.

[0001408710-21-000034:mdna:103]
During fiscal year 2021, our subsidiaries in the U.S. generated taxable income sufficient for the utilization of loss carryforwards due to better operating performance and effective control of operating expenses and management determined that it was more likely than not that future taxable income would be sufficient to allow utilization of the deferred tax assets. Thus, a full valuation allowance of $1.5 million for the deferred tax assets was released as of June 25, 2021.

[0001408710-21-000034:mdna:104]
During fiscal year 2021, our subsidiaries in the U.K. also generated net operating loss and management expected that such subsidiary would continue to have net operating losses in the foreseeable future. Therefore, management believed it was more likely than not that all of the deferred tax assets of such subsidiary would not be utilized. Thus, a full valuation allowance of $2.1 million for the deferred tax assets was set up as of June 25, 2021.

[0001408710-21-000034:mdna:105]
Results of Operations

[0001408710-21-000034:mdna:106]
The following table sets forth a summary of our consolidated statements of operations and comprehensive income. Note that period-to-period comparisons of operating results should not be relied upon as indicative of future performance.

[0001408710-21-000034:mdna:107]
|  | Years Ended |
| (amount in thousands) | June 25, 2021 |  | June 26, 2020 |  | June 28, 2019 |
| Revenues | $ | 1,879,350 |  |  | $ | 1,641,836 |  |  | $ | 1,584,335 |  |
| Cost of revenues | (1,657,987) |  |  | (1,455,731) |  |  | (1,405,111) |  |
| Gross profit | 221,363 |  |  | 186,105 |  |  | 179,224 |  |
| Selling, general and administrative expenses | (70,567) |  |  | (68,374) |  |  | (55,067) |  |
| Expenses related to reduction in workforce | (43) |  |  | (329) |  |  | (1,516) |  |
| Operating income | 150,753 |  |  | 117,402 |  |  | 122,641 |  |
| Interest income | 3,783 |  |  | 7,592 |  |  | 6,699 |  |
| Interest expense | (1,100) |  |  | (3,044) |  |  | (5,381) |  |
| Foreign exchange gain (loss), net | 508 |  |  | (3,797) |  |  | 1,406 |  |
| Other income (expense), net | (3,460) |  |  | 1,089 |  |  | 868 |  |
| Income before income taxes | 150,484 |  |  | 119,242 |  |  | 126,233 |  |
| Income tax expense | (2,143) |  |  | (5,763) |  |  | (5,278) |  |
| Net income | 148,341 |  |  | 113,479 |  |  | 120,955 |  |
| Other comprehensive income (loss), net of tax | (5,119) |  |  | 1,239 |  |  | (1,129) |  |
| Net comprehensive income | $ | 143,222 |  |  | $ | 114,718 |  |  | $ | 119,826 |  |

[0001408710-21-000034:mdna:108]
The following table sets forth a summary of our consolidated statements of operations and comprehensive income as a percentage of total revenues for the periods indicated.

[0001408710-21-000034:mdna:109]
|  | Years Ended |
|  | June 25, 2021 |  | June 26, 2020 |  | June 28, 2019 |
| Revenues | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenues | (88.2) |  |  | (88.7) |  |  | (88.7) |  |
| Gross profit | 11.8 |  |  | 11.3 |  |  | 11.3 |  |
| Selling, general and administrative expenses | (3.8) |  |  | (4.2) |  |  | (3.5) |  |
| Expenses related to reduction in workforce | 0.0 |  |  | 0.0 |  |  | (0.1) |  |
| Operating income | 8.0 |  |  | 7.1 |  |  | 7.7 |  |
| Interest income | 0.2 |  |  | 0.5 |  |  | 0.4 |  |
| Interest expense | 0.0 |  |  | (0.2) |  |  | (0.3) |  |
| Foreign exchange gain (loss), net | 0.0 |  |  | (0.2) |  |  | 0.1 |  |
| Other income (expense), net | (0.2) |  |  | 0.1 |  |  | 0.0 |  |
| Income before income taxes | 8.0 |  |  | 7.3 |  |  | 7.9 |  |
| Income tax expense | (0.1) |  |  | (0.4) |  |  | (0.3) |  |
| Net income | 7.9 |  |  | 6.9 |  |  | 7.6 |  |
| Other comprehensive income (loss), net of tax | (0.3) |  |  | 0.1 |  |  | 0.0 |  |
| Net comprehensive income | 7.6 | % |  | 7.0 | % |  | 7.6 | % |

[0001408710-21-000034:mdna:110]
42

[0001408710-21-000034:mdna:111]
The following table sets forth our revenues by end market for the periods indicated.

[0001408710-21-000034:mdna:112]
|  | Years Ended |
| (amount in thousands) | June 25, 2021 |  | June 26, 2020 |  | June 28, 2019 |
| Optical communications | $ | 1,441,338 |  |  | $ | 1,248,174 |  |  | $ | 1,184,936 |  |
| Lasers, sensors, and other | 438,012 |  |  | 393,662 |  |  | 399,399 |  |
| Total | $ | 1,879,350 |  |  | $ | 1,641,836 |  |  | $ | 1,584,335 |  |

[0001408710-21-000034:mdna:113]
We operate and internally manage a single operating segment. As such, discrete information with respect to separate product lines and segments is not accumulated.

[0001408710-21-000034:mdna:114]
Comparison of Fiscal Year 2021 with Fiscal Year 2020

[0001408710-21-000034:mdna:115]
Total revenues. Our total revenues increased by $237.5 million, or 14.5%, to $1.88 billion for fiscal year 2021, compared with $1.64 billion for fiscal year 2020. This increase was primarily due to an increase in customers’ demand for optical communications manufacturing services, particularly telecom manufacturing services, for fiscal year 2021. Revenues from optical communications products represented 76.7% of our total revenues for fiscal year 2021, compared with 76.0% for fiscal year 2020.

[0001408710-21-000034:mdna:116]
Cost of revenues. Our cost of revenues increased by $202.3 million, or 13.9%, to $1.66 billion, or 88.2% of total revenues, for fiscal year 2021, compared with $1.46 billion, or 88.7% of total revenues, for fiscal year 2020. The increase in cost of revenues was primarily due to a proportional increase in sales volume.

[0001408710-21-000034:mdna:117]
Gross profit. Our gross profit increased by $35.3 million, or 18.9%, to $221.4 million, or 11.8% of total revenues, for fiscal year 2021, compared with $186.1 million, or 11.3% of total revenues, for fiscal year 2020.

[0001408710-21-000034:mdna:118]
SG&A expenses. Our SG&A expenses increased by $2.2 million, or 3.2%, to $70.6 million, or 3.8% of total revenues, for fiscal year 2021, compared with $68.4 million, or 4.2% of total revenues, for fiscal year 2020. Our SG&A expenses increased during fiscal year 2021, compared with fiscal year 2020, mainly due to (1) an increase in share-based compensation expenses of $3.2 million from an increase in awards of performance share units and restricted share units; (2) an increase in new business start-up costs related to our subsidiary in Israel of $1.4 million; and (3) an increase in severance liabilities expense of $0.9 million related to a senior management retirement; offset by a goodwill impairment loss related to our subsidiary in the U.K. of $3.5 million in fiscal year 2020.

[0001408710-21-000034:mdna:119]
Operating income. Our operating income increased by $33.4 million to $150.8 million, or 8.0% of total revenues, for fiscal year 2021, compared with $117.4 million, or 7.1% of total revenues, for fiscal year 2020.

[0001408710-21-000034:mdna:120]
Interest income. Our interest income decreased by $3.8 million to $3.8 million for fiscal year 2021, compared with $7.6 million for fiscal year 2020. The decrease was primarily due to a lower weighted average interest rate in fiscal year 2021 compared with fiscal year 2020.

[0001408710-21-000034:mdna:121]
Interest expense. Our interest expense decreased by $1.9 million to $1.1 million for fiscal year 2021, compared with $3.0 million for fiscal year 2020. The decrease was primarily due to lower unrealized loss from mark-to-market of interest rate swaps recognized to earnings for fiscal year 2021, due to the implementation of cash flow hedge accounting on the interest rate swaps on September 27, 2019 and lower interest expense from loan repayment in fiscal year 2021.

[0001408710-21-000034:mdna:122]
Foreign exchange gain (loss), net. We recorded foreign exchange gain, net of $0.5 million for fiscal year 2021, compared with foreign exchange loss, net of $3.8 million for fiscal year 2020. The increase in foreign exchange gain was mainly due to an unrealized foreign exchange gain from revaluation of outstanding Thai baht assets and liabilities of $2.0 million, foreign exchange gain from subsidiaries in the PRC and the U.K., totaling $1.7 million, and realized foreign exchange gain from payment/receipt of $0.5 million in fiscal year 2021, as compared to an unrealized foreign exchange loss from mark-to-market of forward contracts of $1.2 million and realized foreign exchange loss from payment/receipt of $1.6 million in fiscal year 2020

[0001408710-21-000034:mdna:123]
Income before income taxes. We recorded income before income taxes of $150.5 million for fiscal year 2021, compared with $119.2 million for fiscal year 2020.

[0001408710-21-000034:mdna:124]
Income tax expense. Our provision for income tax reflects an effective tax rate of 1.4% and 4.8% for fiscal year 2021 and fiscal year 2020, respectively. The decrease was primarily due to higher income not subject to tax in fiscal year 2021, as compared to fiscal year 2020.

[0001408710-21-000034:mdna:125]
Net income. We recorded net income of $148.3 million, or 7.9% of total revenues, for fiscal year 2021, compared with net income of $113.5 million, or 6.9% of total revenues, for fiscal year 2020.

[0001408710-21-000034:mdna:126]
Other comprehensive income (loss). We recorded other comprehensive loss of $5.1 million, or 0.3% for fiscal year 2021, compared with other comprehensive income of $1.2 million, or 0.1% for fiscal year 2020. The decrease in other comprehensive income was mainly due to (1) unrealized loss from mark-to-market of forward contracts and interest rate swap agreement of $5.1 million for fiscal year 2021, as compared to unrealized gain from mark-to-market of forward contracts and interest rate swap agreement of $0.6 million for fiscal year 2020, and (2) unrealized loss from mark-to-market of available-for-sale debt securities of $1.2 million for fiscal year 2021, as compared to unrealized gain from mark-to-market of available-for-sale debt securities of $0.5 million for fiscal year 2020.

[0001408710-21-000034:mdna:127]
Comparison of Fiscal Year 2020 with Fiscal Year 2019

[0001408710-21-000034:mdna:128]
Total revenues. Our total revenues increased by $57.5 million, or 3.6%, to $1.64 billion for fiscal year 2020, compared with $1.58 billion for fiscal year 2019. This increase was primarily due to an increase in customers’ demand for optical communications manufacturing services, particularly telecom manufacturing services, for fiscal year 2020. Revenues from optical communications products represented 76.0% of our total revenues for fiscal year 2020, compared with 74.8% for fiscal year 2019.

[0001408710-21-000034:mdna:129]
Cost of revenues. Our cost of revenues increased by $50.6 million, or 3.6%, to $1.46 billion, or 88.7% of total revenues, for fiscal year 2020, compared with $1.41 billion, or 88.7% of total revenues, for fiscal year 2019. The increase in cost of revenues was primarily due to a proportional increase in sales volume.

[0001408710-21-000034:mdna:130]
Gross profit. Our gross profit increased by $6.9 million, or 3.8%, to $186.1 million, or 11.3% of total revenues, for fiscal year 2020, compared with $179.2 million, or 11.3% of total revenues, for fiscal year 2019.

[0001408710-21-000034:mdna:131]
SG&A expenses. Our SG&A expenses increased by $13.3 million, or 24.2%, to $68.4 million, or 4.2% of total revenues, for fiscal year 2020, compared with $55.1 million, or 3.5% of total revenues, for fiscal year 2019. Our SG&A expenses increased during fiscal year 2020, compared with fiscal year 2019, mainly due to by (1) an increase in share-based compensation expenses of $4.6 million, including $3.2 million from an increase in awards of performance share units and $1.4 million from an increase in awards of restricted share units; (2) a goodwill impairment loss related to our UK subsidiary of $3.5 million; (3) an increase in new business start-up costs incurred by our Israel and Thailand subsidiaries of $1.5 million; (4) an increase in severance liabilities expense of $0.9 million due to a change in labor protection law in Thailand in May 2019 that increased the required severance payment compensation for employees with 20 years of service from 300 days of wage to 400 days of wage; and (5) an increase in executive and management expenses of $0.4 million from bonuses and other benefits.

[0001408710-21-000034:mdna:132]
Operating income. Our operating income decreased by $5.2 million to $117.4 million, or 7.1% of total revenues, for fiscal year 2020, compared with $122.6 million, or 7.7% of total revenues, for fiscal year 2019.

[0001408710-21-000034:mdna:133]
Interest income. Our interest income increased by $0.9 million to $7.6 million for fiscal year 2020, compared with $6.7 million for fiscal year 2019. The increase was primarily due to an increase in the average balance of our outstanding cash and cash equivalents and short-term investments.

[0001408710-21-000034:mdna:134]
Interest expense. Our interest expense decreased by $2.4 million to $3.0 million for fiscal year 2020, compared with $5.4 million for fiscal year 2019. The decrease was primarily due to lower unrealized loss from mark-to-market of interest rate swaps recognized to earnings as a result of applying cash flow hedge accounting in fiscal year 2020. In fiscal year 2020, there was unrealized loss from mark-to-market of interest rate swaps of $1.7 million recognized to earnings for the three months ended September 27, 2019, before applying cash flow hedge, as compared to an unrealized loss of $2.6 million for fiscal year 2019. In addition, there was amortization of the fair value of interest rate swaps as of the hedge inception date of $1.2 million during fiscal year 2020 in relation to applying hedge accounting which results in a decrease in interest expense.

[0001408710-21-000034:mdna:135]
Foreign exchange gain (loss), net. We recorded foreign exchange loss, net of $3.8 million for fiscal year 2020, compared with foreign exchange gain, net of $1.4 million for fiscal year 2019. The increase in foreign exchange loss was mainly due to an unrealized foreign exchange loss from mark-to-market of forward contracts of $1.2 million in fiscal year 2020, as compared to an unrealized foreign exchange gain from mark-to-market of forward contracts of $4.8 million in fiscal year 2019.

[0001408710-21-000034:mdna:136]
Income before income taxes. We recorded income before income taxes of $119.2 million for fiscal year 2020, compared with $126.2 million for fiscal year 2019.

[0001408710-21-000034:mdna:137]
Income tax expense. Our provision for income tax reflects an effective tax rate of 4.8% and 4.2% for fiscal year 2020 and fiscal year 2019, respectively. The increase was primarily due to the fact that we had higher income subject to tax in fiscal year 2020, as compared to fiscal year 2019.

[0001408710-21-000034:mdna:138]
Net income. We recorded net income of $113.5 million, or 6.9% of total revenues, for fiscal year 2020, compared with net income of $121.0 million, or 7.6% of total revenues, for fiscal year 2019.

[0001408710-21-000034:mdna:139]
Other comprehensive income (loss). Our other comprehensive income increased by $2.4 million to $1.2 million for fiscal year 2020 compared with other comprehensive loss of $1.1 million for fiscal year 2019.

[0001408710-21-000034:mdna:140]
Liquidity and Capital Resources

[0001408710-21-000034:mdna:141]
Cash Flows and Working Capital

[0001408710-21-000034:mdna:142]
We primarily finance our operations through cash flow from operating activities. As of June 25, 2021 and June 26, 2020, we had cash, cash equivalents, and short-term investments of $547.9 million and $488.1 million, respectively, and outstanding debt of $39.5 million and $51.7 million, respectively.

[0001408710-21-000034:mdna:143]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted average interest rate on our cash and cash equivalents for fiscal year 2021, fiscal year 2020 and fiscal year 2019 was 0.7%, 1.8% and 1.9%, respectively.

[0001408710-21-000034:mdna:144]
Our cash investments are made in accordance with an investment policy approved by the audit committee of our board of directors. In general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed income securities are primarily classified as available-for-sale and and held-to-maturity. Investments in debt securities that we have the positive intent and ability to hold to maturity are carried at amortized cost and classified as held-to-maturity. Investments in debt securities that are not classified as held-to-maturity are carried at fair value and classified as available-for-sale with any unrealized gains and losses included in AOCI in the consolidated balance sheets. We determine realized gains or losses on sale of available-for-sale debt securities on a specific identification method and records such gains or losses as interest income in the consolidated statements of operations and comprehensive income.

[0001408710-21-000034:mdna:145]
During fiscal year 2020, (1) we paid off a term loan of $60.9 million under our previous credit facility agreement with Bank of America, (2) our subsidiary in Thailand drew down a new term loan of $60.9 million under a new credit facility agreement with the Bank of Ayudhya Public Company Limited, and (3) we repaid $9.1 million of the new term loan under the new credit facility agreement. As a result, as of June 26, 2020, we had a long-term borrowing of $51.7 million under our new credit facility agreement. As of June 25, 2021, we had a long-term borrowing of $39.5 million under our new credit facility agreement (see Note 15 for further details). We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held short-term investments of $245.0 million as of June 25, 2021.

[0001408710-21-000034:mdna:146]
We believe that our current cash and cash equivalents, short-term investments, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months following the filing of this Annual Report on Form 10-K. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Item 1A of this Annual Report on Form 10-K.

[0001408710-21-000034:mdna:147]
We also believe that our current manufacturing capacity is sufficient to meet our anticipated production requirements for at least the next few quarters.

[0001408710-21-000034:mdna:148]
The following table shows our cash flows for the periods indicated:

[0001408710-21-000034:mdna:149]
|  | Years Ended |
| (amount in thousands) | June 25, 2021 |  | June 26, 2020 |  | June 28, 2019 |
| Net cash provided by operating activities | $ | 118,665 |  |  | $ | 150,660 |  |  | $ | 147,394 |  |
| Net cash used in investing activities | $ | (5,442) |  |  | $ | (71,248) |  |  | $ | (98,067) |  |
| Net cash used in financing activities | $ | (42,754) |  |  | $ | (35,305) |  |  | $ | (23,223) |  |
| Net increase in cash, cash equivalents and restricted cash | $ | 70,469 |  |  | $ | 44,107 |  |  | $ | 26,104 |  |
| Cash, cash equivalents and restricted cash, beginning of period | $ | 232,832 |  |  | $ | 188,241 |  |  | $ | 161,433 |  |
| Cash, cash equivalents and restricted cash, end of period | $ | 303,123 |  |  | $ | 232,832 |  |  | $ | 188,241 |  |

[0001408710-21-000034:mdna:150]
Operating Activities

[0001408710-21-000034:mdna:151]
Net cash provided by operating activities of $118.7 million for fiscal year 2021 was primarily due to (1) net income of $148.3 million; (2) an increase in trade accounts payable of $96.3 million; (3) depreciation and amortization of $36.3 million; and (4) share-based compensation of $25.5 million; offset by (1) an increase in inventories of $112.3 million to support new business; (2) an increase in trade accounts receivable of $63.8 million due to higher sales and timing of collection; and (3) increase in other current and non-current assets of $15.2 million.

[0001408710-21-000034:mdna:152]
Net cash provided by operating activities of $150.7 million for fiscal year 2020 was primarily due to (1) net income of $113.5 million; (2) depreciation and amortization of $30.9 million; (3) share-based compensation of $22.2 million; and (4) an increase in other current liabilities and non-current liabilities of $11.0 million; offset by (1) an increase in inventories of $16.2 million; and (2) an increase in trade accounts receivable of $12.3 million.

[0001408710-21-000034:mdna:153]
Investing Activities

[0001408710-21-000034:mdna:154]
Net cash used in investing activities of $5.4 million for fiscal year 2021 was primarily due to (1) purchase of property, plant and equipment of $42.5 million; and (2) purchase of intangibles assets of $2.0 million; offset by (1) funds repayment from a customer of $24.3 million; and (2) net proceeds from sales and maturities of short-term investments of $14.6 million.

[0001408710-21-000034:mdna:155]
Net cash used in investing activities of $71.2 million for fiscal year 2020 was primarily due to (1) purchase of property, plant and equipment of $42.3 million; (2) funds provided to our customer in the amount of $24.3 million to support the customer’s transfer of certain manufacturing operations from Berlin, Germany to our facilities in Thailand in fiscal year 2020; (3) a net purchase of short-term investments of $5.1 million; and (4) purchase of intangibles assets of $1.2 million; offset by proceeds from disposal of property, plant and equipment of $1.6 million.

[0001408710-21-000034:mdna:156]
Financing Activities

[0001408710-21-000034:mdna:157]
Net cash used in financing activities of $42.8 million for fiscal year 2021 was primarily due to (1) repurchase of ordinary shares of $18.8 million; (2) repayment of loans to banks of $12.2 million; and (3) cash paid for withholding tax related to net share settlement of restricted share units of $11.6 million.

[0001408710-21-000034:mdna:158]
Net cash used in financing activities of $35.3 million for fiscal year 2020 was primarily due to (1) repurchase of ordinary shares of $20.7 million; (2) repayment of loans to banks of $9.1 million; (3) cash paid for withholding tax related to net share settlement of restricted share units of $4.9 million; and (4) repayment of finance lease liabilities of $0.4 million.

[0001408710-21-000034:mdna:159]
Contractual Obligations

[0001408710-21-000034:mdna:160]
The following table sets forth certain of our contractual obligations as of June 25, 2021:

[0001408710-21-000034:mdna:161]
|  | Payments Due by Period |
| (amount in thousands) | Total |  | Less than1 year |  | 1-3years |  | 3-5years |  | More than5 years |
| Long-term borrowing obligations | $ | 39,609 |  |  | $ | 12,188 |  |  | $ | 27,421 |  |  | $ | — |  |  | $ | — |  |
| Interest expense obligation(1) | 911 |  |  | 487 |  |  | 423 |  |  | 1 |  |  | — |  |
| Operating lease obligations | 6,734 |  |  | 2,775 |  |  | 3,959 |  |  | — |  |  | — |  |
| Severance liabilities(2) | 19,782 |  |  | 1,176 |  |  | 2,647 |  |  | 3,515 |  |  | 12,444 |  |
| Provision for uncertain income tax position | 922 |  |  | — |  |  | 309 |  |  | 498 |  |  | 115 |  |
| Total | $ | 67,958 |  |  | $ | 16,626 |  |  | $ | 34,759 |  |  | $ | 4,014 |  |  | $ | 12,559 |  |

[0001408710-21-000034:mdna:162]
(1)Interest expense obligation reflects the interest rate on long-term debt obligation as of June 25, 2021. The interest rates ranged between 1.5% and 1.6%. For further discussion of long-term borrowing obligations, see Note 15 of our audited consolidated financial statements.

[0001408710-21-000034:mdna:163]
(2)Severance liabilities as of June 25, 2021 are determined based on management assumptions and calculated as expected future cash flows basis. See Note 16 of our audited consolidated financial statements.

[0001408710-21-000034:mdna:164]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

[0001408710-21-000034:mdna:165]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a Term  Loan Agreement pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company’s previous syndicated senior credit facility agreement.

[0001408710-21-000034:mdna:166]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not           be borrowed again. During the year ended June 25, 2021, the Company recorded $0.7 million of interest expense in connection with this term loan.

[0001408710-21-000034:mdna:167]
Any borrowings under the Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

[0001408710-21-000034:mdna:168]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt to equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of June 25, 2021, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

[0001408710-21-000034:mdna:169]
The events of default in the Term Loan Agreement include failure to pay amounts due under the Term Loan Agreement or the related finance documents when due, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the

[0001408710-21-000034:mdna:170]
Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect. As of June 25, 2021, there was $39.5 million outstanding under the term loan.

[0001408710-21-000034:mdna:171]
As of June 25, 2021, we also had certain operating lease arrangements in which the lease payments are calculated using the straight-line method. Our rental expenses under these leases were $2.6 million, $2.1 million and $1.9 million for fiscal year 2021, fiscal year 2020 and fiscal year 2019, respectively.

[0001408710-21-000034:mdna:172]
Capital Expenditures

[0001408710-21-000034:mdna:173]
The following table sets forth our capital expenditures, which include amounts for which payments have been accrued, for the periods indicated.

[0001408710-21-000034:mdna:174]
|  | Years Ended |
| (amount in thousands) | June 25, 2021 |  | June 26, 2020 |  | June 28, 2019 |
| Capital expenditures | $ | 48,563 |  |  | $ | 51,317 |  |  | $ | 20,834 |  |

[0001408710-21-000034:mdna:175]
During fiscal year 2021 and fiscal year 2020, we purchased equipment to support the expansion of our manufacturing facilities in Thailand, the PRC and Israel. During fiscal year 2019, we purchased additional equipment to continue to support the expansion of our manufacturing facilities in Thailand. We expect our capital expenditures for fiscal year 2022  to increase compared to fiscal year 2021 mainly related to investment in existing and new manufacturing facilities.

[0001408710-21-000034:mdna:176]
Recent Accounting Pronouncements

[0001408710-21-000034:mdna:177]
See Note 2 of the Notes to Consolidated Financial Statements for recent accounting pronouncements that could have an effect on us.
