# FN 8-K — 0001408710-21-000031 filed 2021-08-16

## item codes, every 8-K on or before 2021-08-17

- 2021-08-16 0001408710-21-000031 — 2.02, 5.02, 9.01
- 2021-05-03 0001408710-21-000019 — 2.02, 9.01
- 2021-02-01 0001408710-21-000008 — 2.02, 9.01
- 2020-12-11 0001193125-20-315861 — 5.07
- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2021-08-17

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001408710-21-000031:8k_2_02:1]
EX-99.1
3
fn-20210816xex991q4.htm
EX-99.1

[0001408710-21-000031:8k_2_02:2]
Document

[0001408710-21-000031:8k_2_02:3]
Exhibit 99.1

[0001408710-21-000031:8k_2_02:4]
Fabrinet Announces Fourth Quarter And Fiscal Year 2021 Financial Results

[0001408710-21-000031:8k_2_02:5]
•Fourth Quarter Revenue of $509.6 Million Exceeds Guidance

[0001408710-21-000031:8k_2_02:6]
•Record Fiscal Year 2021 Revenue of $1.88 Billion

[0001408710-21-000031:8k_2_02:7]
BANGKOK, Thailand – August 16, 2021 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its fourth quarter and fiscal year ended June 25, 2021.

[0001408710-21-000031:8k_2_02:8]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “We had a strong finish to a record year with revenue and profitability that exceeded our guidance ranges. Demand trends across our business continue to be healthy, with particular fourth quarter strength from the telecom market. With efficient execution, we delivered excellent operating margins during the fourth quarter, which helped propel operating income and net income to record levels for fiscal year 2021.”

[0001408710-21-000031:8k_2_02:9]
Grady continued, “We remain optimistic about demand trends and confident in our ability to execute, positioning us to continue delivering strong results as we enter our new fiscal year.”

[0001408710-21-000031:8k_2_02:10]
Fourth Quarter Fiscal Year 2021 Financial Highlights

[0001408710-21-000031:8k_2_02:11]
GAAP Results

[0001408710-21-000031:8k_2_02:12]
•Revenue for the fourth quarter of fiscal year 2021 was $509.6 million, compared to $405.1 million for the fourth quarter of fiscal year 2020.

[0001408710-21-000031:8k_2_02:13]
•GAAP net income for the fourth quarter of fiscal year 2021 was $42.4 million, compared to GAAP net income of $28.0 million for the fourth quarter of fiscal year 2020.

[0001408710-21-000031:8k_2_02:14]
•GAAP net income per diluted share for the fourth quarter of fiscal year 2021 was $1.13, compared to GAAP net income per diluted share of $0.75 for the fourth quarter of fiscal year 2020.

[0001408710-21-000031:8k_2_02:15]
Non-GAAP Results

[0001408710-21-000031:8k_2_02:16]
•Non-GAAP net income for the fourth quarter of fiscal year 2021 was $49.4 million, compared to non-GAAP net income of $36.0 million for the fourth quarter of fiscal year 2020.

[0001408710-21-000031:8k_2_02:17]
•Non-GAAP net income per diluted share for the fourth quarter of fiscal year 2021 was $1.31, compared to non-GAAP net income per diluted share of $0.96 for the fourth quarter of fiscal year 2020.

[0001408710-21-000031:8k_2_02:18]
Fiscal Year 2021 Financial Highlights

[0001408710-21-000031:8k_2_02:19]
GAAP Results

[0001408710-21-000031:8k_2_02:20]
•Revenue for fiscal year 2021 was $1,879.4 million, compared to $1,641.8 million for fiscal year 2020.

[0001408710-21-000031:8k_2_02:21]
•GAAP net income for fiscal year 2021 was $148.3 million, compared to GAAP net income of $113.5 million for fiscal year 2020.

[0001408710-21-000031:8k_2_02:22]
•GAAP net income per diluted share for fiscal year 2021 was $3.95, compared to GAAP net income per diluted share of $3.01 for fiscal year 2020.

[0001408710-21-000031:8k_2_02:23]
Non-GAAP Results

[0001408710-21-000031:8k_2_02:24]
•Non-GAAP net income for fiscal year 2021 was $175.5 million, compared to non-GAAP net income of $140.6 million for fiscal year 2020.

[0001408710-21-000031:8k_2_02:25]
•Non-GAAP net income per diluted share for fiscal year 2021 was $4.67, compared to non-GAAP net income per diluted share of $3.73 for fiscal year 2020.

[0001408710-21-000031:8k_2_02:26]
Business Outlook

[0001408710-21-000031:8k_2_02:27]
Based on information available as of August 16, 2021, Fabrinet is issuing guidance for its first fiscal year 2022 quarter ending September 24, 2021, as follows:

[0001408710-21-000031:8k_2_02:28]
•Fabrinet expects first quarter revenue to be in the range of $510 million to $530 million.

[0001408710-21-000031:8k_2_02:29]
•GAAP net income per diluted share is expected to be in the range of $1.08 to $1.15, based on approximately 37.5 million fully diluted shares outstanding.

[0001408710-21-000031:8k_2_02:30]
•Non-GAAP net income per diluted share is expected to be in the range of $1.29 to $1.36, based on approximately 37.5 million fully diluted shares outstanding.

[0001408710-21-000031:8k_2_02:31]
Conference Call Information

[0001408710-21-000031:8k_2_02:32]
| What: |  | Fabrinet Fourth Quarter Fiscal Year 2021 Financial Results Call |
| When: |  | Monday, August 16, 2021 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic(253) 237-1137, internationalPasscode: 2199846 |
| Replay: |  | (855) 859-2056, domestic(404) 537-3406, internationalPasscode: 2199846 |
| Webcast: |  | http://investor.fabrinet.com/ (live and replay) |

[0001408710-21-000031:8k_2_02:33]
This press release and any other information related to the call will also be posted on Fabrinet’s website at http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001408710-21-000031:8k_2_02:34]
About Fabrinet

[0001408710-21-000031:8k_2_02:35]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China, Israel and the United Kingdom. For more information visit: www.fabrinet.com.

[0001408710-21-000031:8k_2_02:36]
Forward-Looking Statements

[0001408710-21-000031:8k_2_02:37]
biotechnology, metrology and materials processing markets; increased competition in the optical manufacturing services markets; difficulties in delivering products and services that compete effectively from a price and performance perspective; our reliance on a small number of customers and suppliers; difficulties in managing our operating costs; difficulties in managing and operating our business across multiple countries (including Thailand, the People’s Republic of China, Israel, the U.S. and the U.K.); and other important factors as described in reports and documents we file from time to time with the Securities and Exchange Commission (SEC), including the factors described under the section captioned “Risk Factors” in our Quarterly Report on Form 10-Q, filed with the SEC on May 4, 2021. We disclaim any obligation to update information contained in these forward-looking statements whether as a result of new information, future events, or otherwise.

[0001408710-21-000031:8k_2_02:38]
Use of Non-GAAP Financials

[0001408710-21-000031:8k_2_02:39]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; depreciation of fair value uplift; amortization of intangibles; and amortization of deferred debt issuance costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001408710-21-000031:8k_2_02:40]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001408710-21-000031:8k_2_02:41]
SOURCE: Fabrinet

[0001408710-21-000031:8k_2_02:42]
Investor Contact:

[0001408710-21-000031:8k_2_02:43]
Garo Toomajanian

[0001408710-21-000031:8k_2_02:44]
ir@fabrinet.com

[0001408710-21-000031:8k_2_02:45]
FABRINET

[0001408710-21-000031:8k_2_02:46]
CONSOLIDATED BALANCE SHEETS

[0001408710-21-000031:8k_2_02:47]
| (in thousands of U.S. dollars, except share data and par value) | June 25,2021 |  | June 26,2020 |
| Assets |  |  |  |
| Current assets |  |  |  |
| Cash and cash equivalents | $ | 302,969 |  |  | $ | 225,430 |  |
| Short-term restricted cash | — |  |  | 7,402 |  |
| Short-term investments | 244,963 |  |  | 262,693 |  |
| Trade accounts receivable, net | 336,547 |  |  | 272,665 |  |
| Contract assets | 11,878 |  |  | 13,256 |  |
| Inventories | 422,133 |  |  | 309,786 |  |
| Other receivable | — |  |  | 24,310 |  |
| Prepaid expenses | 11,398 |  |  | 5,399 |  |
| Other current assets | 22,619 |  |  | 14,508 |  |
| Total current assets | 1,352,507 |  |  | 1,135,449 |  |
| Non-current assets |  |  |  |
| Long-term restricted cash | 154 |  |  | — |  |
| Property, plant and equipment, net | 241,129 |  |  | 228,274 |  |
| Intangibles, net | 4,371 |  |  | 4,312 |  |
| Operating right-of-use assets | 6,699 |  |  | 8,068 |  |
| Deferred tax assets | 9,428 |  |  | 5,675 |  |
| Other non-current assets | 1,834 |  |  | 202 |  |
| Total non-current assets | 263,615 |  |  | 246,531 |  |
| Total Assets | $ | 1,616,122 |  |  | $ | 1,381,980 |  |
| Liabilities and Shareholders’ Equity |  |  |  |
| Current liabilities |  |  |  |
| Long-term borrowings, current portion, net | $ | 12,156 |  |  | $ | 12,156 |  |
| Trade accounts payable | 346,555 |  |  | 251,603 |  |
| Fixed assets payable | 19,206 |  |  | 15,127 |  |
| Contract liabilities | 1,680 |  |  | 1,556 |  |
| Operating lease liabilities, current portion | 2,593 |  |  | 1,979 |  |
| Income tax payable | 3,612 |  |  | 2,242 |  |
| Accrued payroll, bonus and related expenses | 20,464 |  |  | 19,265 |  |
| Accrued expenses | 17,134 |  |  | 8,979 |  |
| Other payables | 20,958 |  |  | 21,514 |  |
| Total current liabilities | 444,358 |  |  | 334,421 |  |
| Non-current liabilities |  |  |  |
| Long-term borrowings, non-current portion, net | 27,358 |  |  | 39,514 |  |
| Deferred tax liability | 5,107 |  |  | 4,729 |  |
| Operating lease liabilities, non-current portion | 3,850 |  |  | 5,873 |  |
| Severance liabilities | 19,485 |  |  | 17,379 |  |
| Other non-current liabilities | 3,444 |  |  | 5,655 |  |
| Total non-current liabilities | 59,244 |  |  | 73,150 |  |
| Total Liabilities | 503,602 |  |  | 407,571 |  |
| Commitments and contingencies |  |  |  |
| Shareholders’ equity |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of June 25, 2021 and June 26, 2020) | — |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 38,749,045 shares and 38,471,967 shares issued as of June 25, 2021 and June 26, 2020, respectively; and 36,765,456 shares and 36,727,864 shares outstanding as of June 25, 2021 and June 26, 2020, respectively) | 388 |  |  | 385 |  |
| Additional paid-in capital | 189,445 |  |  | 175,610 |  |
| Less: Treasury shares (1,983,589 shares and 1,744,103 shares as of June 25, 2021 and June 26, 2020, respectively) | (87,343) |  |  | (68,501) |  |
| Accumulated other comprehensive loss | (6,266) |  |  | (1,147) |  |
| Retained earnings | 1,016,296 |  |  | 868,062 |  |
| Total Shareholders’ Equity | 1,112,520 |  |  | 974,409 |  |
| Total Liabilities and Shareholders’ Equity | $ | 1,616,122 |  |  | $ | 1,381,980 |  |

[0001408710-21-000031:8k_2_02:48]
FABRINET

[0001408710-21-000031:8k_2_02:49]
CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME

[0001408710-21-000031:8k_2_02:50]
|  | Three Months Ended |  | Years Ended |
| (in thousands of U.S. dollars, except per share data) | June 25,2021 |  | June 26,2020 |  | June 25,2021 |  | June 26,2020 |
| Revenues | $ | 509,567 |  |  | $ | 405,113 |  |  | $ | 1,879,350 |  |  | $ | 1,641,836 |  |
| Cost of revenues | (448,483) |  |  | (358,489) |  |  | (1,657,987) |  |  | (1,455,731) |  |
| Gross profit | 61,084 |  |  | 46,624 |  |  | 221,363 |  |  | 186,105 |  |
| Selling, general and administrative expenses | (17,489) |  |  | (18,185) |  |  | (70,567) |  |  | (68,374) |  |
| Expenses related to reduction in workforce | — |  |  | (313) |  |  | (43) |  |  | (329) |  |
| Operating income | 43,595 |  |  | 28,126 |  |  | 150,753 |  |  | 117,402 |  |
| Interest income | 627 |  |  | 1,512 |  |  | 3,783 |  |  | 7,592 |  |
| Interest expense | (302) |  |  | (232) |  |  | (1,100) |  |  | (3,044) |  |
| Foreign exchange gain (loss), net | 284 |  |  | (848) |  |  | 508 |  |  | (3,797) |  |
| Other income (expense), net | (3,863) |  |  | 112 |  |  | (3,460) |  |  | 1,089 |  |
| Income before income taxes | 40,341 |  |  | 28,670 |  |  | 150,484 |  |  | 119,242 |  |
| Income tax expense | 2,072 |  |  | (646) |  |  | (2,143) |  |  | (5,763) |  |
| Net income | 42,413 |  |  | 28,024 |  |  | 148,341 |  |  | 113,479 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities | (245) |  |  | 1,941 |  |  | (1,182) |  |  | 538 |  |
| Change in net unrealized gain (loss) on derivative instruments | 717 |  |  | 7,289 |  |  | (5,106) |  |  | 570 |  |
| Change in retirement benefit plan – prior service cost | 163 |  |  | 50 |  |  | 584 |  |  | 528 |  |
| Change in foreign currency translation adjustment | 38 |  |  | (44) |  |  | 585 |  |  | (397) |  |
| Total other comprehensive income (loss), net of tax | 673 |  |  | 9,236 |  |  | (5,119) |  |  | 1,239 |  |
| Net comprehensive income | $ | 43,086 |  |  | $ | 37,260 |  |  | $ | 143,222 |  |  | $ | 114,718 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 1.15 |  |  | $ | 0.76 |  |  | $ | 4.02 |  |  | $ | 3.07 |  |
| Diluted | $ | 1.13 |  |  | $ | 0.75 |  |  | $ | 3.95 |  |  | $ | 3.01 |  |
| Weighted average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |
| Basic | 36,857 |  |  | 36,723 |  |  | 36,872 |  |  | 36,908 |  |
| Diluted | 37,676 |  |  | 37,571 |  |  | 37,555 |  |  | 37,665 |  |

[0001408710-21-000031:8k_2_02:51]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001408710-21-000031:8k_2_02:52]
|  | Years Ended |
| (in thousands of U. S. dollars) | June 25,2021 |  | June 26,2020 |
| Cash flows from operating activities |  |  |  |
| Net income | $ | 148,341 |  |  | $ | 113,479 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 36,252 |  |  | 30,875 |  |
| Loss (gain) on disposal and impairment of property, plant and equipment | 13 |  |  | 329 |  |
| Loss on impairment of goodwill | — |  |  | 3,514 |  |
| Gain from sales and maturities of available-for-sale securities | (187) |  |  | (96) |  |
| Accretion of premiums on short-term investments | 2,093 |  |  | (508) |  |
| Amortization of deferred debt issuance costs | 32 |  |  | 26 |  |
| (Reversal of) allowance for doubtful accounts | (343) |  |  | 240 |  |
| Unrealized (gain) loss on exchange rate and fair value of foreign currency forward contracts | (859) |  |  | 1,963 |  |
| Unrealized loss on fair value of interest rate swaps | — |  |  | 1,672 |  |
| Amortization of fair value at hedge inception of interest rate swaps | (1,299) |  |  | (1,220) |  |
| Share-based compensation | 25,462 |  |  | 22,203 |  |
| Deferred income tax | (3,473) |  |  | 1,262 |  |
| Other non-cash expenses | (450) |  |  | (619) |  |
| Changes in operating assets and liabilities |  |  |  |
| Trade accounts receivable | (63,810) |  |  | (12,260) |  |
| Contract assets | 1,378 |  |  | (809) |  |
| Inventories | (112,349) |  |  | (16,174) |  |
| Other current assets and non-current assets | (15,190) |  |  | (775) |  |
| Trade accounts payable | 96,312 |  |  | (5,990) |  |
| Contract liabilities | 124 |  |  | (683) |  |
| Income tax payable | 1,353 |  |  | 442 |  |
| Severance liabilities | 3,180 |  |  | 2,802 |  |
| Other current liabilities and non-current liabilities | 2,085 |  |  | 10,987 |  |
| Net cash provided by operating activities | 118,665 |  |  | 150,660 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of short-term investments | (244,329) |  |  | (196,373) |  |
| Proceeds from sales of short-term investments | 79,439 |  |  | 48,808 |  |
| Proceeds from maturities of short-term investments | 179,532 |  |  | 142,508 |  |
| Funds repayment from (provided to) customer to support transfer of manufacturing operations (Note 10) | 24,310 |  |  | (24,310) |  |
| Purchase of property, plant and equipment | (42,532) |  |  | (42,327) |  |
| Purchase of intangibles | (1,952) |  |  | (1,180) |  |
| Proceeds from disposal of property, plant and equipment | 90 |  |  | 1,626 |  |
| Net cash used in investing activities | (5,442) |  |  | (71,248) |  |
| Cash flows from financing activities |  |  |  |
| Payment of debt issuance costs | — |  |  | (153) |  |
| Proceeds from long-term borrowings | — |  |  | 60,938 |  |
| Repayment of long-term borrowings | (12,188) |  |  | (70,079) |  |
| Repayment of finance lease liabilities | (100) |  |  | (400) |  |
| Repurchase of ordinary shares | (18,842) |  |  | (20,722) |  |
| Withholding tax related to net share settlement of restricted share units | (11,624) |  |  | (4,889) |  |
| Net cash used in financing activities | (42,754) |  |  | (35,305) |  |
| Net increase in cash, cash equivalents and restricted cash | $ | 70,469 |  |  | $ | 44,107 |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period | $ | 232,832 |  |  | $ | 188,241 |  |
| Increase in cash, cash equivalents and restricted cash | 70,469 |  |  | 44,107 |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash | (178) |  |  | 484 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 303,123 |  |  | $ | 232,832 |  |

[0001408710-21-000031:8k_2_02:53]
|  | Years Ended |
| Supplemental disclosures | June 25,2021 |  | June 26,2020 |
| Cash paid for |  |  |  |
| Interest | $ | 2,438 |  |  | $ | 1,688 |  |
| Taxes | $ | 7,945 |  |  | $ | 8,466 |  |
| Cash received for interest | $ | 4,445 |  |  | $ | 9,676 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment related payables | $ | 19,206 |  |  | $ | 15,127 |  |

[0001408710-21-000031:8k_2_02:54]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the consolidated balance sheets that sum to the total of the same amounts shown in the consolidated statements of cash flows:

[0001408710-21-000031:8k_2_02:55]
|  | As of |
| (amount in thousands) | June 25,2021 |  | June 26,2020 |
| Cash and cash equivalents | $ | 302,969 |  |  | $ | 225,430 |  |
| Restricted cash | 154 |  |  | 7,402 |  |
| Cash, cash equivalents and restricted cash | $ | 303,123 |  |  | $ | 232,832 |  |

[0001408710-21-000031:8k_2_02:56]
FABRINET

[0001408710-21-000031:8k_2_02:57]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-21-000031:8k_2_02:58]
|  | Three Months Ended |  | Years Ended |
|  | June 25,2021 |  | June 26,2020 |  | June 25,2021 |  | June 26,2020 |
| (in thousands of U.S. dollars, except per share data) | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |
| GAAP measures | $ | 42,413 |  |  | $ | 1.13 |  |  | $ | 28,024 |  |  | $ | 0.75 |  |  | $ | 148,341 |  |  | $ | 3.95 |  |  | $ | 113,479 |  |  | $ | 3.01 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 1,380 |  |  | 0.04 |  |  | 1,298 |  |  | 0.03 |  |  | 6,185 |  |  | 0.16 |  |  | 6,098 |  |  | 0.16 |  |
| Depreciation of fair value uplift | 91 |  |  | 0.00 |  |  | 80 |  |  | 0.00 |  |  | 347 |  |  | 0.01 |  |  | 327 |  |  | 0.01 |  |
| Total related to gross profit | 1,471 |  |  | 0.04 |  |  | 1,378 |  |  | 0.03 |  |  | 6,532 |  |  | 0.17 |  |  | 6,425 |  |  | 0.17 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 5,340 |  |  | 0.14 |  |  | 2,604 |  |  | 0.07 |  |  | 19,277 |  |  | 0.52 |  |  | 16,105 |  |  | 0.43 |  |
| Amortization of intangibles | 124 |  |  | 0.00 |  |  | 131 |  |  | 0.00 |  |  | 506 |  |  | 0.01 |  |  | 562 |  |  | 0.01 |  |
| Goodwill impairment charge | — |  |  | — |  |  | 3,514 |  |  | 0.09 |  |  | — |  |  | — |  |  | 3,514 |  | 0.09 |  |
| Severance payment | — |  |  | — |  |  | — |  |  | — |  |  | 755 |  |  | 0.02 |  |  | 150 |  |  | 0.00 |  |
| Total related to selling, general and administrative expenses | 5,464 |  |  | 0.14 |  |  | 6,249 |  |  | 0.17 |  |  | 20,538 |  |  | 0.55 |  |  | 20,331 |  |  | 0.54 |  |
| Related to other income and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other expenses in relation to reduction in workforce | — |  |  | — |  |  | 313 |  |  | 0.01 |  |  | 43 |  |  | 0.00 |  |  | 329 |  |  | 0.01 |  |
| Amortization of deferred debt issuance costs | 8 |  |  | 0.00 |  |  | 8 |  |  | 0.00 |  |  | 32 |  |  | 0.00 |  |  | 26 |  |  | 0.00 |  |
| Total related to other incomes and other expenses | 8 |  |  | 0.00 |  |  | 321 |  |  | 0.01 |  |  | 75 |  |  | 0.00 |  |  | 355 |  |  | 0.01 |  |
| Total related to net income & EPS | 6,943 |  |  | 0.18 |  |  | 7,948 |  |  | 0.21 |  |  | 27,145 |  |  | 0.72 |  |  | 27,111 |  |  | 0.72 |  |
| Non-GAAP measures | $ | 49,356 |  |  | $ | 1.31 |  |  | $ | 35,972 |  |  | $ | 0.96 |  |  | $ | 175,486 |  |  | $ | 4.67 |  |  | $ | 140,590 |  |  | $ | 3.73 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  | 37,676 |  |  |  |  | 37,571 |  |  |  |  | 37,555 |  |  |  | 37,665 |
| Non-GAAP diluted shares |  |  | 37,676 |  |  |  |  | 37,571 |  |  |  |  | 37,555 |  |  |  | 37,665 |

[0001408710-21-000031:8k_2_02:59]
FABRINET

[0001408710-21-000031:8k_2_02:60]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001408710-21-000031:8k_2_02:61]
| (amount in thousands) | Three Months Ended |  | Years Ended |  |  |  |
|  | June 25,2021 |  | June 26,2020 |  | June 25,2021 |  | June 26,2020 |  |  |  |
| Net cash provided by operating activities | $ | 43,508 |  |  | $ | 46,212 |  |  | $ | 118,665 |  |  | $ | 150,660 |  |  |  |  |
| Less: Purchase of property, plant and equipment | (13,471) |  |  | (14,845) |  |  | (42,532) |  |  | (42,327) |  |  |  |  |
| Non-GAAP free cash flow | $ | 30,037 |  |  | $ | 31,367 |  |  | $ | 76,133 |  |  | $ | 108,333 |  |  |  |  |

[0001408710-21-000031:8k_2_02:62]
FABRINET

[0001408710-21-000031:8k_2_02:63]
GUIDANCE FOR QUARTER ENDING SEPTEMBER 24, 2021

[0001408710-21-000031:8k_2_02:64]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-21-000031:8k_2_02:65]
|  | DilutedEPS |
| GAAP net income per diluted share: | $1.08 to $1.15 |
| Related to cost of revenues: |  |
| Share-based compensation expenses | 0.05 |
| Total related to gross profit | 0.05 |
| Related to selling, general and administrative expenses: |  |
| Share-based compensation expenses | 0.16 |
| Total related to selling, general and administrative expenses | 0.16 |
| Total related to net income & EPS | 0.21 |
| Non-GAAP net income per diluted share | $1.29 to $1.36 |

## item 5.02 — body, verbatim

[0001408710-21-000031:8k_body:1]
Item 5.02    Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers;

[0001408710-21-000031:8k_body:2]
Compensatory Arrangements of Certain Officers.

[0001408710-21-000031:8k_body:3]
Fiscal 2022 Executive Incentive Plan

[0001408710-21-000031:8k_body:4]
On August 10, 2021, the Compensation Committee (the “Compensation Committee”) of the board of directors of Fabrinet adopted an executive incentive plan (the “Cash Bonus Plan”) for the Company’s fiscal year ending June 24, 2022 (“fiscal 2022”). The Cash Bonus Plan is an incentive program designed to motivate participants to achieve the Company’s financial objectives, and to reward them for their achievements when those objectives are met. All of the Company’s executive officers pursuant to Section 16 of the Exchange Act are eligible to participate in the Cash Bonus Plan (individually, a “Participant,” and collectively, the “Participants”). The Cash Bonus Plan provides for target and maximum bonus amounts as set forth in the table below. The maximum bonus that a Participant may receive under the Cash Bonus Plan is 120% of such Participant’s target bonus.

[0001408710-21-000031:8k_body:5]
Name

[0001408710-21-000031:8k_body:6]
Fiscal 2022 Target Bonus

[0001408710-21-000031:8k_body:7]
Fiscal 2022 Maximum Bonus

[0001408710-21-000031:8k_body:8]
Seamus Grady

[0001408710-21-000031:8k_body:9]
$1,365,000

[0001408710-21-000031:8k_body:10]
$1,638,000

[0001408710-21-000031:8k_body:11]
Dr. Harpal Gill

[0001408710-21-000031:8k_body:12]
$1,325,000

[0001408710-21-000031:8k_body:13]
$1,590,000

[0001408710-21-000031:8k_body:14]
Csaba Sverha

[0001408710-21-000031:8k_body:15]
$425,000

[0001408710-21-000031:8k_body:16]
$510,000

[0001408710-21-000031:8k_body:17]
Edward Archer

[0001408710-21-000031:8k_body:18]
$370,000

[0001408710-21-000031:8k_body:19]
$444,000

[0001408710-21-000031:8k_body:20]
The amount of bonus actually paid to a Participant under the Cash Bonus Plan will be based 50% on achievement of a fiscal 2022 revenue target and 50% on achievement of a fiscal 2022 non-GAAP operating margin target. As achievement of each financial target is considered independently from the other, the Company must meet a threshold for each factor in order for a Participant to receive any credit for that factor. If the Company achieves 100% of a target financial metric, bonuses would be paid out at 100% of target with respect to that financial metric component. If the Company achieves 105% or more of a target financial metric, bonuses would be paid out at 100% of maximum with respect to that financial metric component. Achievement of the revenue target or non-GAAP operating margin target for fiscal 2022 at a level between 100% and 105% will result in a bonus amount for the applicable metric that is scaled from 100% of target to maximum in a linear fashion. Achievement of the revenue target or non-GAAP operating margin target for fiscal 2022 at a level between 90% and 100% will result in a bonus amount for the applicable metric that is scaled from 20% of target to 100% of target in a linear fashion.

[0001408710-21-000031:8k_body:21]
Fiscal 2022 Salaries

[0001408710-21-000031:8k_body:22]
On August 10, 2021, the Compensation Committee approved an increase to the annual base salaries of the Company’s named executive officers set forth below, effective as of June 26, 2021, the first day of fiscal 2022.

[0001408710-21-000031:8k_body:23]
Name

[0001408710-21-000031:8k_body:24]
Title

[0001408710-21-000031:8k_body:25]
Previous Annual Base Salary

[0001408710-21-000031:8k_body:26]
Fiscal 2022 Annual Base Salary

[0001408710-21-000031:8k_body:27]
Change

[0001408710-21-000031:8k_body:28]
Seamus Grady

[0001408710-21-000031:8k_body:29]
Chief Executive Officer

[0001408710-21-000031:8k_body:30]
$860,000

[0001408710-21-000031:8k_body:31]
$1,025,000

[0001408710-21-000031:8k_body:32]
19.2%

[0001408710-21-000031:8k_body:33]
Dr. Harpal Gill

[0001408710-21-000031:8k_body:34]
President and Chief Operating Officer

[0001408710-21-000031:8k_body:35]
$990,000

[0001408710-21-000031:8k_body:36]
$1,010,000

[0001408710-21-000031:8k_body:37]
2.0%

[0001408710-21-000031:8k_body:38]
Csaba Sverha

[0001408710-21-000031:8k_body:39]
Executive Vice President, Chief Financial Officer

[0001408710-21-000031:8k_body:40]
$470,000

[0001408710-21-000031:8k_body:41]
$500,000

[0001408710-21-000031:8k_body:42]
6.4%

[0001408710-21-000031:8k_body:43]
Edward Archer

[0001408710-21-000031:8k_body:44]
Executive Vice President, Sales & Marketing

[0001408710-21-000031:8k_body:45]
$450,000

[0001408710-21-000031:8k_body:46]
$460,000

[0001408710-21-000031:8k_body:47]
2.2%

[0001408710-21-000031:8k_body:48]
Equity Award Grants

[0001408710-21-000031:8k_body:49]
On August 10, 2021, the Compensation Committee approved the grant, effective as of August 19, 2021 (the “Grant Date”), of the following dollar value of restricted share units (“RSUs”), performance share units (“PSUs”) and “stretch” PSUs (“Stretch PSUs”), rounded down to the nearest whole share, to the Company’s named executive officers as a component of their fiscal 2022 compensation:

[0001408710-21-000031:8k_body:50]
Name

[0001408710-21-000031:8k_body:51]
Grant Date Value of RSUs

[0001408710-21-000031:8k_body:52]
Grant Date Value of PSUs

[0001408710-21-000031:8k_body:53]
Grant Date Value of “Stretch” PSUs

[0001408710-21-000031:8k_body:54]
Seamus Grady

[0001408710-21-000031:8k_body:55]
$2,400,000

[0001408710-21-000031:8k_body:56]
$2,400,000

[0001408710-21-000031:8k_body:57]
$2,400,000

[0001408710-21-000031:8k_body:58]
Dr. Harpal Gill

[0001408710-21-000031:8k_body:59]
$1,500,000

[0001408710-21-000031:8k_body:60]
$1,500,000

[0001408710-21-000031:8k_body:61]
$1,500,000

[0001408710-21-000031:8k_body:62]
Csaba Sverha

[0001408710-21-000031:8k_body:63]
$800,000

[0001408710-21-000031:8k_body:64]
$800,000

[0001408710-21-000031:8k_body:65]
$800,000

[0001408710-21-000031:8k_body:66]
Edward Archer

[0001408710-21-000031:8k_body:67]
$700,000

[0001408710-21-000031:8k_body:68]
$700,000

[0001408710-21-000031:8k_body:69]
$700,000

[0001408710-21-000031:8k_body:70]
The grants will be made under the Company’s 2020 Equity Incentive Plan. The RSUs will vest in equal annual installments over a period of three years on each anniversary of the Grant Date, subject to the individual’s continued service with the Company through each such vesting date.

[0001408710-21-000031:8k_body:71]
The PSUs will vest, if at all, following a 2-year performance period, on the date the Compensation Committee certifies achievement of the performance criteria set forth below, subject to the individual’s continued service with the Company through such vesting date. Vesting of the PSUs will be based 50% on achievement of a cumulative fiscal 2022 and fiscal 2023 revenue target (the “PSU Revenue Target”) and 50% on achievement of a cumulative fiscal 2022 and fiscal 2023 non-GAAP operating margin target (the “PSU Operating Margin Target”). As achievement of each financial target is considered independently from the other, the Company must meet a threshold for each factor in order for an individual to receive any credit for that factor. If the Company achieves 100% or more of a target financial metric, the PSUs will vest at 100% of target with respect to that financial metric component. Achievement of the PSU Revenue Target or the PSU Operating Margin Target at a level between 90% and 100% will result in a number of shares vesting for the applicable metric that is scaled from 20% to 100% in a linear fashion.

[0001408710-21-000031:8k_body:72]
The Stretch PSUs will vest, if at all, following a 2-year performance period, on the date the Compensation Committee certifies achievement of the performance criteria set forth below, subject to the individual’s continued service with the Company through such vesting date. Vesting of the Stretch PSUs will be based 50% on achievement of a cumulative fiscal 2022 and fiscal 2023 revenue target that is 5% higher than the PSU Revenue Target (the “Stretch PSU Revenue Target”) and 50% on achievement of a cumulative fiscal 2022 and fiscal 2023 non-GAAP operating margin target that is 5% higher than the PSU Operating Margin Target (the “Stretch PSU Operating Margin Target”). As achievement of each financial target is considered independently from the other, the Company must meet a threshold for each factor in order for an individual to receive any credit for that factor. The Company must exceed the PSU Revenue Target or the PSU Operating Margin Target in order for any of the Stretch PSUs to vest. If the Company achieves 100% or more of a target financial metric, the Stretch PSUs will vest at 100% of target with respect to that financial metric component. Achievement of the Stretch PSU Revenue Target at a level between the PSU Revenue Target and 100% will result in a number of shares vesting for that metric that is scaled from 0% to 100% in a linear fashion. Achievement of the Stretch PSU Operating Margin Target at a level between the PSU Operating Margin Target and 100% will result in a number of shares vesting for that metric that is scaled from 0% to 100% in a linear fashion.

[0001408710-21-000031:8k_body:73]
Executive Change in Control and Severance Plan

[0001408710-21-000031:8k_body:74]
On August 10, 2021, the Compensation Committee approved the Company’s adoption of the Fabrinet Executive Change in Control and Severance Plan (the “Severance Plan”) in order to provide benefits to certain designated executive officers of Fabrinet and/or its affiliates in connection with an involuntary termination of employment, including in connection with a change in control of Fabrinet. On August 10, 2021, the Compensation Committee designated Mr. Sverha and Mr. Archer as being eligible to participate in the Severance Plan, subject to execution of a participation agreement.

[0001408710-21-000031:8k_body:75]
Under the Severance Plan, if a participant’s employment with Fabrinet (or subsidiary of Fabrinet, as applicable) is terminated outside of the period beginning three months before a change in control (as defined in the Severance Plan) of Fabrinet and ending on (and inclusive of) the date that is the one year anniversary of a change in control of Fabrinet (such period, the “Change in Control Period”) either (i) by Fabrinet (or subsidiary of Fabrinet, as applicable) for a reason other than cause (as defined in the Severance Plan) and other than due to the participant’s death or disability or (ii) by the participant for

[0001408710-21-000031:8k_body:76]
good reason (as defined in the Severance Plan) (clauses (i) and (ii), collectively, a “Qualifying Termination”), then, subject to the participant timely signing and not revoking a separation agreement and release of claims (the “Release Condition”), the participant will be entitled to receive the following severance benefits:

[0001408710-21-000031:8k_body:77]
•A single, lump sum, cash payment equal to 50% of the participant’s annual base salary in effect as of the date of employment termination;

[0001408710-21-000031:8k_body:78]
•A single, lump sum, cash payment equal to the participant’s earned but unpaid bonus as of the date of employment termination;

[0001408710-21-000031:8k_body:79]
•A single, lump sum, cash payment equal to 18 times the monthly premium for continued health coverage under COBRA for the participant and the participant’s eligible dependents, as applicable; and

[0001408710-21-000031:8k_body:80]
•To the extent a participant is receiving tax equalization benefits under the Company’s expatriate policy as of the date of employment termination, continued tax equalization benefits for the calendar year in which the employment termination occurs and the immediately following calendar year.

[0001408710-21-000031:8k_body:81]
Under the Severance Plan, if a participant’s employment with Fabrinet (or subsidiary of Fabrinet, as applicable) is terminated within the Change in Control Period due to a Qualifying Termination, then, subject to the Release Condition, the participant will be entitled to receive the following severance benefits:

[0001408710-21-000031:8k_body:82]
•A single, lump sum, cash payment equal to 100% of the participant’s annual base salary in effect as of the date of employment termination or, if greater, the participant’s annual base salary in effect as of immediately prior to the change in control;

[0001408710-21-000031:8k_body:83]
•A single, lump sum, cash payment equal to the participant’s earned but unpaid bonus as of the date of employment termination;

[0001408710-21-000031:8k_body:84]
•A single, lump sum, cash payment equal to 100% of the participant’s target annual bonus opportunity in effect as of the date of employment termination or, if greater, the participant’s target annual bonus opportunity in effect as of immediately prior to the change in control;

[0001408710-21-000031:8k_body:85]
•A single, lump sum, cash payment equal to 18 times the amount of the monthly premium for continued health coverage under COBRA for the participant and the participant’s eligible dependents, as applicable;

[0001408710-21-000031:8k_body:86]
•100% vesting acceleration of any Company equity awards that are subject to continued service-based vesting criteria, but not subject to the achievement of any performance-based or other similar vesting criteria (“Time-Based Awards”); and

[0001408710-21-000031:8k_body:87]
•to the extent a participant is receiving tax equalization benefits under the Company’s expatriate policy as of the date of employment termination, continued tax equalization benefits for the calendar year in which the employment termination occurs and the immediately following calendar year.

[0001408710-21-000031:8k_body:88]
If any of the severance and other benefits provided for in the Severance Plan or otherwise payable to a participant (“280G Payments”) constitute “parachute payments” within the meaning of Section 280G of the Internal Revenue Code and could be subject to excise tax under Section 4999 of the Internal Revenue Code, then the 280G Payments will be delivered in full or delivered as to such lesser extent which would result in no portion of such benefits being subject to excise tax, whichever results in the greater amount of after-tax benefits to such participant. The Severance Plan does not provide for any tax gross-up payment to any participant in the Severance Plan.

[0001408710-21-000031:8k_body:89]
Fabrinet reserves the right to amend or terminate the Severance Plan at any time, but upon, in connection with or after a change in control, Fabrinet, without a participant’s written consent, may not amend or terminate the Severance Plan in any way, nor take any other action under the Severance Plan, which (i) prevents that participant from becoming eligible for severance benefits, or (ii) reduces or alters to the detriment of the participant the severance benefits, if any, payable, or potentially payable, to the participant (including, without limitation, imposing additional conditions).

[0001408710-21-000031:8k_body:90]
Pursuant to the participation agreement (the “Participation Agreement”) that the Compensation Committee approved under the Severance Plan for each of Mr. Sverha and Mr. Archer, in the event of a change in control of Fabrinet, each such participant’s performance share units previously granted to him under Fabrinet’s 2020 Equity Incentive Plan, and the awards of PSUs and Stretch PSUs described above, that are then outstanding will be treated as follows. To the extent that the performance period has not yet been completed as of the change in control, (1) the performance targets for performance share units that do not have “stretch” performance targets will be deemed to have been achieved in full as of the change in control, will be

[0001408710-21-000031:8k_body:91]
scheduled to vest subject to the participant’s continued service with Fabrinet through the last date of the award’s original performance period, and will be treated as a Time-Based Award under the Severance Plan that may be eligible for the vesting acceleration under the Severance Plan upon a Qualifying Termination during the Change in Control Period, as described further above, and (2) performance share units that have “stretch” performance targets will be forfeited in full.

[0001408710-21-000031:8k_body:92]
The foregoing description of the Severance Plan and Participation Agreement is qualified in its entirety by reference to the Severance Plan and form of Participation Agreement, which is filed herewith as Exhibit 10.1 and is incorporated by reference herein.
