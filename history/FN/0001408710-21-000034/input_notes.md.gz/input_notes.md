# FN notes — 0001408710-21-000034


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001408710-21-000034:notes:1]
Portions of the registrant’s definitive proxy statement relating to its 2021 annual meeting of shareholders are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated. Such proxy statement will be filed with the U.S. Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001408710-21-000034:notes:2]
Summary of significant accounting policies
Principles of consolidation

[0001408710-21-000034:notes:3]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. Fiscal year 2021 ended on June 25, 2021 and consisted of 52 weeks. Fiscal year 2020 ended on June 26, 2020 and consisted of 52 weeks. Fiscal year 2019 ended on June 28, 2019 and consisted of 52 weeks.

[0001408710-21-000034:notes:4]
The consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) and include Fabrinet and its subsidiaries. All inter-company accounts and transactions have been eliminated.

[0001408710-21-000034:notes:5]
Use of estimates

[0001408710-21-000034:notes:6]
The preparation of the Company’s consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements, and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisitions, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information. Additionally, the extent to which the evolving COVID-19 pandemic impacts the Company’s consolidated financial statements will depend on a number of factors, including the magnitude and duration of the pandemic. These estimates may change, as new events occur and additional information is obtained, as well as other factors related to COVID-19 that could result in material impacts to our consolidated financial statements in future reporting periods.

[0001408710-21-000034:notes:7]
Reclassifications

[0001408710-21-000034:notes:8]
For presentation purposes, certain prior period amounts have been reclassified to conform to the current period presentation.

[0001408710-21-000034:notes:9]
As of June 26, 2020, the derivative assets and liabilities were measured at fair value and recognized by offsetting the fair value amounts under master netting arrangements. Also, the Company chose not to separate a derivative into current and non-current portions as follows:

[0001408710-21-000034:notes:10]
(i)A derivative for which the fair value is a net liability is classified in total as current.

[0001408710-21-000034:notes:11]
(ii)A derivative for which the fair value is a net asset and the current portion is an asset is classified in total as non-current. If the current portion is a liability, it is presented as a current liability.

[0001408710-21-000034:notes:12]
As of June 25, 2021, the derivative assets and liabilities were measured at fair value, but the gross fair value amount is presented in the consolidated balance sheets. Additionally, a classification of current and non-current portion is determined by the maturity date of that derivative (e.g., a derivative that matures within one year is classified as current).

[0001408710-21-000034:notes:13]
The reclassifications have been made to the consolidated balance sheet as of June 26, 2020 and the consolidated statement of cash flows for the year ended June 26, 2020 as following table:

[0001408710-21-000034:notes:14]
|  | June 26, 2020 |
| (amount in thousands) | As previouslyreported |  | Reclassification |  | Afterreclassification |
| Consolidated Balance Sheet |  |  |  |  |  |
| Current assets |  |  |  |  |  |
| Other current assets | $ | 13,915 |  |  | $ | 593 |  |  | $ | 14,508 |  |
| Current liabilities |  |  |  |  |  |
| Accrued expenses | $ | 12,104 |  |  | $ | (3,125) |  |  | $ | 8,979 |  |
| Non-current liabilities |  |  |  |  |  |
| Other non-current liabilities | $ | 1,937 |  |  | $ | 3,718 |  |  | $ | 5,655 |  |
| Consolidated Statement of Cash Flows |  |  |  |  |  |
| Changes in operating assets and liabilities |  |  |  |  |  |
| Other current assets and non-current assets | $ | (182) |  |  | $ | (593) |  |  | $ | (775) |  |
| Other current liabilities and non-current liabilities | $ | 10,394 |  |  | $ | 593 |  |  | $ | 10,987 |  |

[0001408710-21-000034:notes:15]
These reclassifications do not affect the Company’s net income or shareholders’ equity.

[0001408710-21-000034:notes:16]
Changes in accounting policies

[0001408710-21-000034:notes:17]
Except for the adoption of the Accounting Standards Codification (“ASC”) 326, “Financial Instruments—Credit Losses”, ASC 820, “Disclosure Framework – Changes to the Disclosure Requirements for Fair Value Measurement” and ASC 848, “Reference Rate Reform,” described within the sub-heading “New Accounting Pronouncements – adopted by the Company,” the Company has consistently applied its accounting policies to all periods presented in these consolidated financial statements.

[0001408710-21-000034:notes:18]
Foreign currency transactions and translation

[0001408710-21-000034:notes:19]
The consolidated financial statements are presented in United States dollars (“$” or “USD”). The functional currency of Fabrinet and most of its subsidiaries is the USD.

[0001408710-21-000034:notes:20]
With respect to subsidiaries that use USD as their functional currency, transactions denominated in a currency other than USD are translated into USD at the rates of exchange in effect at the date of the transaction. Monetary assets and liabilities denominated in foreign currencies are translated into the functional currency at the exchange rate prevailing at the consolidated balance sheet dates. Transaction gains and losses are included in foreign exchange gain (loss) in the accompanying consolidated statements of operations and comprehensive income.

[0001408710-21-000034:notes:21]
Fabrinet translates the assets and liabilities of its subsidiaries that do not use USD as their functional currency into USD using exchange rates in effect at the end of each period. Revenue and expenses for such subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recognized in foreign currency translation adjustment included in accumulated other comprehensive income (loss) (“AOCI”) in the Company’s consolidated balance sheets.

[0001408710-21-000034:notes:22]
Cash and cash equivalents

[0001408710-21-000034:notes:23]
All highly liquid investments with original maturities of three months or less from the date of purchase are classified as cash equivalents. Cash and cash equivalents consist of cash deposited in checking accounts, time deposits with maturities of less than three months, money market accounts, and short-term investments with maturities of three months or less at the date of purchase.

[0001408710-21-000034:notes:24]
Short-term investments

[0001408710-21-000034:notes:25]
Management determines the appropriate classification of its investments at the time of purchase and re-evaluates the designations at each balance sheet date. The maturities of the Company’s short-term investments generally range from three months to three years.

[0001408710-21-000034:notes:26]
The short-term investments in debt securities are carried at either amortized cost or fair value. Investments in debt securities that the Company has the positive intent and ability to hold to maturity are carried at amortized cost and classified as held-to-maturity. Investments in debt securities that are not classified as held-to-maturity are carried at fair value and classified as available-for-sale with any unrealized gains and losses included in AOCI in the consolidated

[0001408710-21-000034:notes:27]
balance sheets. The Company determines realized gains or losses on sale of available-for-sale debt securities on a specific identification method and records such gains or losses as interest income in the consolidated statements of operations and comprehensive income.

[0001408710-21-000034:notes:28]
Held-to-maturity debt securities are required to use the current expected credit losses (“CECL”) impairment model to assess the expected credit loss. According to the CECL model, the Company requires the immediate recognition of estimated expected credit losses over the life of the financial instrument through the allowance for credit losses account. The allowance for credit losses is a valuation account that is deducted from, or added to, the amortized cost basis of the financial asset to present the net amount expected to be collected on the financial asset. In determining expected credit losses, the Company considers relevant qualitative factors including, but not limited to, term and structure of the instrument, credit rating by rating agencies and historic credit losses adjusted for current conditions and reasonable and supportable forecasts.

[0001408710-21-000034:notes:29]
Available-for-sale debt securities are required to be individually evaluated for impairment. A security is considered impaired if the fair value of the security is less than its amortized cost basis.

[0001408710-21-000034:notes:30]
An impairment is considered when (i) the Company has the intent to sell the security, (ii) it is more likely than not that the Company will be required to sell the security before recovery of the entire amortized cost basis, or (iii) the Company does not expect to recover the entire amortized cost basis of the security.

[0001408710-21-000034:notes:31]
If an impairment is considered based on condition (i) or (ii), the entire difference between the amortized cost and the fair value of the debt security is recognized as interest income and other income (expense), net in the consolidated statements of operations and comprehensive income.

[0001408710-21-000034:notes:32]
If an impairment is considered based on condition (iii), the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) is recognized in interest and other income (expense), net in the consolidated statements of operations and comprehensive income, and any remaining unrealized losses are included in AOCI in the consolidated balance sheets.

[0001408710-21-000034:notes:33]
Trade accounts receivable

[0001408710-21-000034:notes:34]
Accounts receivable are recorded and carried at the original invoiced amount less an allowance for any potential uncollectible amounts. The Company estimates expected credit losses for the allowance for doubtful accounts based upon its assessment of various factors, including historical experience, the age of the accounts receivable balances, credit quality of its customers, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect the Company’s ability to collect from customers. The estimated credit loss allowance is recorded as selling, general and administrative expenses in the consolidated statements of operations and comprehensive income.

[0001408710-21-000034:notes:35]
Contract assets

[0001408710-21-000034:notes:36]
A contract asset is recognized when the Company has recognized revenues prior to generating an invoice for payment. Contract assets are classified separately within the consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. The Company estimates expected credit losses for the allowance for contract assets based upon its assessment of various factors, including historical experience, the age of the contract assets balances, credit quality of its customers, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect the Company’s ability to collect from customers. The estimated credit loss allowance is recorded as selling, general and administrative expenses in the Company's consolidated statements of operations and comprehensive income.

[0001408710-21-000034:notes:37]
Contract liabilities

[0001408710-21-000034:notes:38]
A contract liability is recognized when the Company has advance payment arrangements with customers. The contract liabilities balance is normally recognized as revenue within six months.

[0001408710-21-000034:notes:39]
Inventory

[0001408710-21-000034:notes:40]
Inventory is stated at the lower of cost or market value. Cost is estimated using the standard costing method, computed on a first-in, first-out basis, with adjustments for variances to reflect actual costs not in excess of net realizable market value. Market value is the estimated selling price in the ordinary course of business, less the costs of completion and selling expenses. The Company assesses the valuation of inventory on a quarterly basis and writes down the value for estimated excess and obsolete inventory based upon estimates of future demand.

[0001408710-21-000034:notes:41]
Leases

[0001408710-21-000034:notes:42]
Operating leases

[0001408710-21-000034:notes:43]
The Company determines if an arrangement contains a lease at inception. The Company applies the guidance in ASC 842 to determine whether a contract is, or contains, a lease. A contract is or contains a lease if the contract conveys the right to control the use of identified property, plant, or equipment (an identified asset) for a period of time in exchange for consideration. Operating leases are included in operating lease right of use (“ROU”) assets and operating lease liabilities within the Company’s consolidated balance sheets. The Company rents certain real estate under agreements that are classified as operating leases.

[0001408710-21-000034:notes:44]
Operating lease ROU assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at commencement date. As most of the Company’s leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the lease commencement date in determining the present value of future payments. The operating lease ROU assets also include any lease payments made and exclude lease incentives and initial direct costs incurred. Variable lease payments are expensed as incurred and are not included within the ROU asset and lease liability calculation. Variable lease payments primarily include reimbursements of costs incurred by lessors for common area maintenance and utilities. The Company’s lease terms may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option.

[0001408710-21-000034:notes:45]
Leases with an initial term of 12 months or less are not recorded on the balance sheet. The Company recognizes lease expense for these leases on a straight-line basis over the lease term. The Company does not account for lease components (e.g., fixed payments including rent) separately from the non-lease components (e.g., common-area maintenance costs).

[0001408710-21-000034:notes:46]
Finance leases

[0001408710-21-000034:notes:47]
Finance leases are accounted for in a manner similar to financed purchases. The right-of-use asset is amortized to amortization expense. Interest expense is recorded in connection with the lease liability.

[0001408710-21-000034:notes:48]
Property, plant and equipment

[0001408710-21-000034:notes:49]
Land is stated at historical cost. Other property, plant and equipment, except for construction in process and machinery under installation, are stated at historical cost less accumulated depreciation. Repair and maintenance costs are expensed as incurred. Depreciation is calculated using the straight-line method to write-off the cost of each asset to its residual value over its estimated useful life as follows:

[0001408710-21-000034:notes:50]
| Land improvements |  | 10 years |
| Building and building improvements |  | 5-30 years |
| Leasehold improvements | Shorter of useful life or lease term |
| Manufacturing equipment |  | 3-7 years |
| Office equipment |  | 3-7 years |
| Motor vehicles |  | 3-5 years |
| Computer hardware |  | 3-5 years |

[0001408710-21-000034:notes:51]
Construction in process and machinery under installation is stated at historic cost and depreciation begins after it is constructed and fully installed and is ready for its intended use in the operations of the Company.

[0001408710-21-000034:notes:52]
Gains and losses on disposal are determined by comparing proceeds with carrying amounts and are included in other income in the consolidated statements of operations and comprehensive income.

[0001408710-21-000034:notes:53]
The Company reviews long-lived assets or asset groups for recoverability on a quarterly basis for any events or changes in circumstances that indicate that their carrying amount may not be recoverable. Recoverability of long-lived assets or asset groups is measured by comparing their carrying amount to the projected undiscounted cash flows that the long-lived assets or asset groups are expected to generate. If such assets are considered to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the long-lived assets exceeds its fair value.

[0001408710-21-000034:notes:54]
Intangibles

[0001408710-21-000034:notes:55]
Intangibles are stated at historical cost less amortization. Amortization of customer relationships is calculated using the accelerated method as to reflect the pattern in which the economic benefits of the intangible assets are consumed. Amortization of other intangibles is calculated using the straight-line method.

[0001408710-21-000034:notes:56]
Intangible assets are reviewed for impairment quarterly or more frequently whenever changes or circumstances indicate the carrying amount of related assets may not be recoverable.

[0001408710-21-000034:notes:57]
Goodwill

[0001408710-21-000034:notes:58]
Goodwill arising from acquisition is primarily attributable to the ability to expand future products and services and the assembled workforce. Goodwill is reviewed annually for impairment or more frequently whenever circumstances indicate that the carrying amount of a reporting unit may exceed its fair value. The impairment charge is based on that difference and is limited to the amount of goodwill allocated to that unit. The Company conducts impairment testing for goodwill at the reporting unit level. Reporting units may be operating segments as a whole, or an operation one level below an operating segment, referred to as a component. The Company has determined that its reporting unit is Fabrinet UK.

[0001408710-21-000034:notes:59]
The Company may initiate goodwill impairment testing by considering qualitative factors to determine whether it is more likely than not that a reportable segment’s carrying value is greater than its fair value. If the Company’s qualitative assessment indicates it is more likely than not that the fair value of a reporting unit exceeds its carrying value, no further analysis is required and goodwill is not impaired. Otherwise, the Company performs a quantitative goodwill impairment test to determine if goodwill is impaired. The quantitative test compares the fair value of a reporting unit with its carrying amount, including goodwill. If the fair value of the reportable segment exceeds the carrying value of the net assets associated with the segment, goodwill is not considered impaired. If the carrying value of the net assets associated with the reportable segment exceeds the fair value of the segment, the Company recognizes an impairment loss in an amount equal to the excess, not to exceed the carrying value of the reportable segment’s goodwill. The reporting unit’s carrying value used in an impairment test represents the assignment of various assets and liabilities, excluding certain corporate assets and liabilities, such as cash, investments, and debt.

[0001408710-21-000034:notes:60]
Goodwill is not deductible for tax purposes. Accordingly, if goodwill is impaired for financial reporting purposes, there is no impact on deferred taxes.

[0001408710-21-000034:notes:61]
Treasury shares

[0001408710-21-000034:notes:62]
Treasury share purchases are accounted for under the cost method whereby the entire cost of the acquired stock is recorded as treasury shares. Gains and losses in excess of par value on the subsequent reissuance of shares are credited or charged to additional paid-in capital in the consolidated balance sheets using the average-cost method.

[0001408710-21-000034:notes:63]
Borrowing costs

[0001408710-21-000034:notes:64]
Borrowing costs are accounted for on an accrual basis and are charged to the consolidated statements of operations and comprehensive income in the year incurred, except for interest costs on general and specific borrowings attributable to finance certain qualifying assets. Such costs to finance qualifying assets are capitalized during the period of time that is required to complete and prepare the assets for their intended use, as part of the cost of the assets. All other borrowing costs are expensed as incurred.

[0001408710-21-000034:notes:65]
Where funds are not borrowed for a specific acquisition, construction or production of assets, the capitalization rate used to determine the amount of interest to be capitalized is the weighted average interest rate applicable to the Company’s outstanding borrowings during the year. Where funds are borrowed specifically for the acquisition, construction or production of assets, the amount of borrowing costs eligible for capitalization on the respective assets is determined as the actual borrowing costs are incurred on that borrowing during the respective periods.

[0001408710-21-000034:notes:66]
Fair value of financial instruments

[0001408710-21-000034:notes:67]
Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. A fair value hierarchy is established which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs for the valuation of an asset or liability as of the measurement date. The three levels of inputs that may be used to measure fair value are defined as follows:

[0001408710-21-000034:notes:68]
Level 1 inputs are quoted prices (unadjusted) in active markets for identical assets or liabilities.

[0001408710-21-000034:notes:69]
Level 2 inputs for similar assets and liabilities in active markets other than quoted prices included within Level 1 that are observable for the asset or liability, either directly or indirectly, for substantially the full term of the asset or liability.

[0001408710-21-000034:notes:70]
Level 3 inputs that are significant to the fair value measurement and unobservable (i.e. supported by little or no market activity), which require the reporting entity to develop its own valuation techniques and assumptions.

[0001408710-21-000034:notes:71]
The Company utilizes the market approach to measure fair value for its financial assets and liabilities. The market approach uses prices and other relevant information generated by market transactions involving identical or comparable assets or liabilities.

[0001408710-21-000034:notes:72]
The carrying amounts of certain financial instruments, which include cash and cash equivalents, trade accounts receivable, contract assets, trade accounts payable, and contract liabilities, approximate their fair values due to their short maturities. The carrying amounts of borrowings approximate their fair values as the applicable interest rate is based on market interest rates. The particular recognition methods adopted are disclosed in the individual policy statements associated with each item.

[0001408710-21-000034:notes:73]
Derivatives

[0001408710-21-000034:notes:74]
The derivative assets and liabilities are measured at fair value and recognized on the consolidated balance sheets by offsetting the fair value amounts under master netting arrangements. For presentation in consolidated balance sheets, the Company may choose not to separate a derivative into its current and non-current portion as follows:

[0001408710-21-000034:notes:75]
•A derivative for which the fair value is a net liability is classified in total as current.

[0001408710-21-000034:notes:76]
•A derivative for which the fair value is a net asset and the current portion is an asset is classified in total as non-current. If the current portion is liability, it should be presented as current liability.

[0001408710-21-000034:notes:77]
For presentation in consolidated statements of cash flows are classified in the same line item as the underlying item.

[0001408710-21-000034:notes:78]
The Company applies hedge accounting to arrangements that qualify and are designated for cash flow or fair value hedge accounting treatment. Hedge accounting is discontinued prospectively if the hedging relationship ceases to be effective or the hedging or hedged items cease to exist as a result of maturity, sale, termination or cancellation.

[0001408710-21-000034:notes:79]
Derivatives designated and qualifying as hedges of the exposure to variability in expected future cash flows, or other types of forecasted transactions, are considered cash flow hedges which include foreign currency forward contracts and interest rate swap. In a cash flow hedging relationship, the change in the fair value of the hedging derivative is initially recorded in AOCI in the consolidated balance sheets, gain or loss on the derivative instrument is reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings. The reclassified amounts are presented in the same income statement line item as the earnings effect of the hedged item.

[0001408710-21-000034:notes:80]
In accordance with the fair value measurement guidance, the Company’s accounting policy is to measure the credit risk of its derivative financial instruments that are subject to master netting agreements on a net basis by counterparty portfolio. The Company executes derivative instruments with financial institutions that are credit-worthy, which the Company defines as institutions that hold an investment grade credit rating.

[0001408710-21-000034:notes:81]
Concentration of credit risk

[0001408710-21-000034:notes:82]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash and cash equivalents, short-term investments, derivatives, accounts receivable and contract assets.

[0001408710-21-000034:notes:83]
Cash, cash equivalents and short-term investments are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. The Company seeks to mitigate its credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties. The Company limits its short-term investments in marketable securities to securities with a maturity not in excess of three years and securities that are rated A1, P-1, F1, or better.

[0001408710-21-000034:notes:84]
The Company enters into derivative contracts with financial institutions with reputable credit and monitors the credit profiles of these counterparties.

[0001408710-21-000034:notes:85]
The Company performs ongoing credit evaluations for credit worthiness of its customers and usually does not require collateral from its customers. Management has implemented a program to closely monitor near term cash collection and credit exposures to mitigate any material losses.

[0001408710-21-000034:notes:86]
Revenue recognition

[0001408710-21-000034:notes:87]
The Company derives revenues primarily from the assembly of products under supply agreements with its customers and the fabrication of customized optics and glass. The Company recognizes revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the Company expects to be entitled in exchange for such goods or services. In order to meet this requirement, the Company applies the following five steps: (1) identify the contract with a customer, (2) identify the performance obligations under

[0001408710-21-000034:notes:88]
the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations under the contract, and (5) recognize revenue when a performance obligation is satisfied. Revenue is recognized net of any taxes collected from customers, which is subsequently remitted to governmental authorities.

[0001408710-21-000034:notes:89]
A performance obligation is a contractual promise to transfer a distinct good or service to the customer. In contracts with multiple performance obligations, the Company identifies each performance obligation and evaluates whether the performance obligation is distinct within the context of the contract at contract inception. The majority of the Company’s contracts have a single performance obligation, as the promise to transfer the individual goods or services is not separately identifiable from other promises under the contracts and, therefore, is not distinct.

[0001408710-21-000034:notes:90]
Sales of finished goods

[0001408710-21-000034:notes:91]
The Company manufactures products that are customized to customers’ specifications; however, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for over time recognition are not met. On evaluation of the contracts, the Company identified that there were no contractual rights to bill profit for work in progress in the event of a contract termination, which is expected to be infrequent. Further, in limited circumstances, contracts provide for substantive acceptance by the customer, which results in the deferral of revenue until formal notice of acceptance is received from the customer. Judgment may be required in determining if an acceptance clause provides for substantive acceptance.

[0001408710-21-000034:notes:92]
Certain customers may request the Company to store finished products at the Company’s warehouse where customers bear risks of loss themselves. In these instances, the Company receives a written request from the customer asking the Company to hold the inventory at the Company’s warehouse and refrain from using the ordered goods to fulfill other customer orders. In these situations, revenue is only recognized when the completed goods are ready for shipment and transferred to the Company’s warehouse.

[0001408710-21-000034:notes:93]
Customers generally are obligated to purchase finished goods that the Company has manufactured according to their demand requirements. Materials that are not consumed by customers within a specified period of time, or are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under the Company’s contracts. Once materials are designated as either excess or obsolete inventory, customers are typically required to purchase such inventory from the Company even if the customer has chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

[0001408710-21-000034:notes:94]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. In determining the net consideration to which the Company expects to be entitled, the Company evaluates whether the price is subject to refund or adjustment. The Company generally does not grant return privileges, except for in the case of defective products during the warranty period. The Company generally provides a warranty of between one to five years on any given product. These standard warranties are assurance-type warranties, and the Company does not offer any services in addition to the assurance that the product will continue to work as specified.

[0001408710-21-000034:notes:95]
The Company recognized revenue net of rebates and other similar allowances. Revenues are recognized only if these estimates can be reasonably and reliably determined. The Company estimates expected rebates and other similar allowances based on historical results taking into consideration the type of customer, the type of transaction and the specifics of each arrangement. The Company considers such estimated rebates and other similar allowances as variable consideration when allocating the transaction price to the extent it is probable that there will not be a significant reversal of cumulative revenue recognized. The estimate is primarily based on the most likely level of consideration to be paid to the customer under the specific terms of each arrangement.

[0001408710-21-000034:notes:96]
Services

[0001408710-21-000034:notes:97]
The Company provides services for customers that are related to the Company’s manufacturing activities. In many cases, although the nature of work performed is that of a service, revenue is only recognized upon shipment of the product because the customer has specific requirements as to how many items can be shipped at any given point in time, i.e. at point-in-time. The related costs are expensed as incurred.

[0001408710-21-000034:notes:98]
Service revenues of $108.5 million, $90.5 million and $106.1 million were recognized in the consolidated statements of operations and comprehensive income for the years ended June 25, 2021, June 26, 2020 and June 28, 2019, respectively.

[0001408710-21-000034:notes:99]
Contract Costs

[0001408710-21-000034:notes:100]
The incremental costs of obtaining a contract with a customer are recognized as an asset (not expensed as incurred) if such costs are expected to be recovered. Incremental costs of obtaining a contract are costs that the Company would not

[0001408710-21-000034:notes:101]
have incurred if the contract had not been obtained (e.g., sales commissions or similar incentive payments linked directly to new or modified customer contracts). Costs that would have been incurred regardless of whether a customer contract was obtained (e.g., costs of pursuing the contract, legal advice, etc.) are expensed as incurred, unless such costs are explicitly chargeable to the customer. During the years ended June 25, 2021 and June 26, 2020, the Company did not have any incremental costs of obtaining a contract.

[0001408710-21-000034:notes:102]
Shipping and Handling

[0001408710-21-000034:notes:103]
Shipping costs billed to customers are recorded as revenue. Shipping and handling expense related to costs incurred to deliver product are recognized within cost of goods sold. The Company accounts for shipping and handling activities that occur after control has transferred as a fulfillment cost, as opposed to a separate performance obligation, and the costs of shipping and handling are recognized concurrently with the related revenue.

[0001408710-21-000034:notes:104]
Warranty provision

[0001408710-21-000034:notes:105]
Provisions for estimated expenses relating to product warranties are made at the time the products are sold using historical experience. Generally, this warranty is limited to workmanship and the Company’s liability is capped at the price of the product. The provisions will be adjusted when experience indicates an expected settlement will differ from initial estimates.

[0001408710-21-000034:notes:106]
Warranty cost allowances of $0.09 million, $0.02 million and $0.07 million were recognized in the consolidated statements of operations and comprehensive income for the years ended June 25, 2021, June 26, 2020 and June 28, 2019, respectively.

[0001408710-21-000034:notes:107]
Share-based compensation

[0001408710-21-000034:notes:108]
Share-based compensation is recognized in the consolidated financial statements based on grant-date fair value. The value of the portion of the award that is ultimately expected to vest is recognized as expense ratably over the requisite service period. For restricted share units and performance share units, the fair values are based on the market value of our ordinary shares on the date of grant.

[0001408710-21-000034:notes:109]
Employee contribution plan

[0001408710-21-000034:notes:110]
The Company operates a defined contribution plan, known as a provident fund, in its subsidiaries in Thailand and the United Kingdom. The assets of these plans are in separate trustee-administered funds. The provident fund is funded by matching payments from employees and by the subsidiaries on a monthly basis. Current contributions to the provident fund are accrued and paid to the fund manager on a monthly basis. The Company sponsors the Fabrinet U.S. 401(k) Retirement Plan, a Defined Contribution Plan under ERISA, at its subsidiaries in the United States, which provides retirement benefits for its eligible employees through tax deferred salary deductions.

[0001408710-21-000034:notes:111]
Severance liabilities

[0001408710-21-000034:notes:112]
Under labor protection laws applicable in Thailand and the Company’s subsidiary in Thailand’s employment policy, all employees of such subsidiary with more than 120 days of service are entitled to severance pay on forced termination or retrenchment or in the event that the employee reaches the retirement age of 55. The entitlement to severance pay is determined according to an employee’s individual employment tenure with the Company and is subject to a maximum benefit of 400 days of salary unless otherwise agreed upon in an employee’s employment contract. For employees of other subsidiaries who have a specific termination date, the entitlement to severance pay is determined according to their employment tenure, until their designated termination date.

[0001408710-21-000034:notes:113]
The Company accounts for these severance liabilities based on an actuarial valuation using the Projected Unit Credit Method, which apply the long-term Thai government bond yield as a discount rate. There are no separate plan assets held in respect to these liabilities.

[0001408710-21-000034:notes:114]
The Company’s subsidiary in the U.K. operates a defined benefit pension plan that defines the pension benefit an employee will receive on retirement, usually dependent upon several factors including but not limited to age, length of service and remuneration. The defined benefit obligation is calculated using the projected unit credit method. Annually the Company engages independent actuaries to calculate the obligation. The present value is determined by discounting the estimated future payments using market yields on high quality corporate bonds that are denominated in sterling and that have terms approximating the estimated period of the future payments (discount rate). The plan assets are held separately from those of the Company in independently administered funds and are measured at fair value.

[0001408710-21-000034:notes:115]
Severance liabilities are recognized in the Company’s consolidated balance sheet under non-current liabilities. The related expenses, if incurred during the period, are recognized in the Company’s consolidated statements of operations and comprehensive income as selling, general and administrative expenses. Prior service cost is initially recognized to other comprehensive income (loss) at the date of plan amendment. Such prior service cost is amortized as expenses as a component of net periodic pension cost using the weighted average remaining years of service to full eligibility date for active employees.

[0001408710-21-000034:notes:116]
Annual leave

[0001408710-21-000034:notes:117]
Employee entitlements to annual leave are recognized when earned by the employee. On termination of employment, accrued employee entitlement to annual leave is paid in cash.

[0001408710-21-000034:notes:118]
Income taxes

[0001408710-21-000034:notes:119]
The Company uses the asset and liability method of accounting for income taxes, whereby deferred tax assets and liabilities are recognized for future tax consequences attributable to temporary differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using tax rates expected to apply to taxable income in the years in which those temporary differences are expected to reverse. The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date. Deferred tax assets are reduced by a valuation allowance if, based on the weight of the available evidence, it is more likely than not that some portion or all of the deferred tax assets will not be realized.

[0001408710-21-000034:notes:120]
Fabrinet’s subsidiaries are subject to income tax audits by the respective tax authorities in all of the jurisdictions in which they operate. The determination of tax liabilities in each of these jurisdictions requires the interpretation and application of complex and sometimes uncertain tax laws and regulations. The Company recognizes liabilities based on its estimate of whether, and the extent to which, additional tax liabilities are more-likely-than-not. If the Company ultimately determines that the payment of such a liability is not probable, then it reverses the liability and recognizes a tax benefit during the period in which the determination is made that the liability is no longer probable. The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that the Company makes certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on the Company’s tax provision in a future period.

[0001408710-21-000034:notes:121]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. A company shall reduce its deferred tax assets by a valuation allowance if, based on the weight of available evidence, it is “more likely than not” (i.e., a likelihood of greater than 50 percent) that some portion or all of the deferred tax assets will not be realized. The valuation allowance shall be sufficient to reduce the deferred tax asset to the amount that is more likely than not to be realized. The valuation allowance shall be monitored and considered from all available evidence, both positive and negative, to determine whether, based on the weight of that evidence, a valuation allowance for deferred tax assets is not needed.

[0001408710-21-000034:notes:122]
The accounting standard clarifies the accounting for uncertainty in income taxes recognized in an entity’s financial statements and prescribes a recognition threshold and measurement attributes for financial statement disclosure of tax positions taken or expected to be taken on a tax return.

[0001408710-21-000034:notes:123]
The Company recognizes a tax benefit in the financial statements for an uncertain tax position only if management’s assessment is that the position is “more likely than not” to be sustained upon examination by the tax jurisdiction based solely on the technical merits of the position. The term “tax position” refers to a position in a previously filed tax return or a position expected to be taken in a future tax return that is reflected in measuring current or deferred income tax assets and liabilities for interim or annual periods. The accounting interpretation also provides guidance on measurement methodology, derecognition thresholds, financial statement classification and disclosures, recognition of interest and penalties, and accounting for the cumulative-effect adjustment at the date of adoption.

[0001408710-21-000034:notes:124]
New Accounting Pronouncements—adopted by the Company

[0001408710-21-000034:notes:125]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13, “Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments.” This standard requires the measurement and recognition of expected credit losses for financial assets held at amortized cost. The standard replaces the existing incurred loss impairment model with an expected loss methodology, which will

[0001408710-21-000034:notes:126]
result in more timely recognition of credit losses. The new standard also expands the required quantitative and qualitative disclosures surrounding expected credit losses.

[0001408710-21-000034:notes:127]
On June 27, 2020, the Company adopted ASC 326 using the modified retrospective transition approach. The modified retrospective method requires the Company to recognize the cumulative effect of the adoption of ASC 326 on the opening accumulated retained earnings. Accordingly, the Company’s comparative financial statements as of June 26, 2020 have not been adjusted. The Company implemented internal controls to enable the preparation of financial information upon adoption.

[0001408710-21-000034:notes:128]
Management estimates the expected credit losses of financial assets using relevant available information from internal and external sources relating to historical credit loss experience, current conditions and reasonable forecasts over a financial asset’s contractual term. Adjustments to historical loss information are made from qualitative and quantitative factors if economic conditions on the reporting date reflect stronger or weaker economic performance than the historical data implies based on management’s expectations of economic conditions on certain indicators of the Company, industry and economy. The Company reviews factors such as past collection experience, age of the accounts receivable and contract assets balance, significant trends in current balances, internal operations and macroeconomic conditions. In addition, the Company modified its impairment model to the AFS debt security impairment model for AFS debt securities and discontinued using the concept of “other than temporary” impairment on these AFS debt securities. The Current Expected Credit Losses (“CECL”) on the AFS debt securities are recognized in interest income and other income (expense), net on the Company’s consolidated statements of operations and comprehensive income, and any remaining unrealized losses are included in AOCI in the Company's consolidated balance sheet.

[0001408710-21-000034:notes:129]
As of June 27, 2020, the Company recorded a cumulative adjustment from CECL in the amount of $0.1 million, net of tax impact, to accumulated retained earnings in the Company's consolidated balance sheet.

[0001408710-21-000034:notes:130]
On June 27, 2020, the Company also adopted ASC 820, “Disclosure Framework – Changes to the Disclosure Requirements for Fair Value Measurement.” This standard seeks to improve the effectiveness of disclosures in the notes to the financial statements and includes (1) the development of a framework that promotes consistent decisions by the FASB about disclosure requirements and (2) the appropriate exercise of discretion by reporting entities. The amendment modifies the disclosure requirements on transferring between level 1 and level 2 and valuation processes of level 3 fair value measurements. The Company adopted this standard with no impact on the Company's consolidated financial statements.

[0001408710-21-000034:notes:131]
On January 7, 2021, FASB issued ASU 2021-01, “Reference Rate Reform (Topic 848).” This standard requires the measurement and recognition of expected credit losses for financial assets held at amortized cost. The amendments in this update clarify that certain optional expedients and exceptions in Topic 848 for contract modifications and hedge accounting apply to derivatives that are affected by the discounting transition. The Company immediately adopted this standard with no impact on the Company's consolidated financial statements.

[0001408710-21-000034:notes:132]
New Accounting Pronouncements—not yet adopted by the Company

[0001408710-21-000034:notes:133]
In December 2019, the FASB issued ASU2019-12, “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.” The amendments in this update simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify U.S. GAAP for other areas of Topic 740 by clarifying and amending existing guidance. For public business entities, the amendments in this update are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2020. This ASU will be effective for the Company in the first quarter of fiscal year 2022. Early adoption is permitted. The Company assessed the preliminary impact from the adoption of this update and expected no impact on the Company's consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001408710-21-000034:notes:134]
Revenues from contracts with customers
Contract Assets and Liabilities

[0001408710-21-000034:notes:135]
A contract asset is recognized when the Company has recognized revenues prior to an invoice for payment. Contract assets are classified separately on the consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. No impairment for contract assets was recorded for the years ended June 25, 2021 and June 26, 2020.

[0001408710-21-000034:notes:136]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the years ended June 25, 2021 and June 26, 2020:

[0001408710-21-000034:notes:137]
| (amount in thousands) |  |  |  | Contract Assets |
| Beginning balance, June 27, 2020 |  |  |  | $ | 13,256 |  |
| Revenue recognized |  |  |  | 65,182 |  |
| Amounts collected or invoiced |  |  |  | (66,560) |  |
| Ending balance, June 25, 2021 |  |  |  | $ | 11,878 |  |

[0001408710-21-000034:notes:138]
| (amount in thousands) |  |  |  | Contract Assets |
| Beginning balance, June 29, 2019 |  |  |  | $ | 12,447 |  |
| Revenue recognized |  |  |  | 73,476 |  |
| Amounts collected or invoiced |  |  |  | (72,667) |  |
| Ending balance, June 26, 2020 |  |  |  | $ | 13,256 |  |

[0001408710-21-000034:notes:139]
| (amount in thousands) |  |  |  | ContractLiabilities |
| Beginning balance, June 27, 2020 |  |  |  | $ | 1,556 |  |
| Advance payment received during the year |  |  |  | 18,360 |  |
| Revenue recognized |  |  |  | (18,236) |  |
| Ending balance, June 25, 2021 |  |  |  | $ | 1,680 |  |

[0001408710-21-000034:notes:140]
| (amount in thousands) |  |  |  | ContractLiabilities |
| Beginning balance, June 29, 2019 |  |  |  | $ | 2,239 |  |
| Advance payment received during the year |  |  |  | 9,278 |  |
| Revenue recognized |  |  |  | (9,961) |  |
| Ending balance, June 26, 2020 |  |  |  | $ | 1,556 |  |

[0001408710-21-000034:notes:141]
Revenue by Geographic Area and End Market

[0001408710-21-000034:notes:142]
Total revenues are attributed to a particular geographic area based on the bill-to-location of the Company’s customers. The Company operates primarily in three geographic regions: North America, Asia-Pacific and Europe.

[0001408710-21-000034:notes:143]
The following table presents total revenues by geographic regions:

[0001408710-21-000034:notes:144]
| (amount in thousands, except percentages) | Year ended June 25,2021 |  | As a %of TotalRevenues |  | Year ended June 26,2020 |  | As a %of TotalRevenues |  | Year ended June 28,2019 |  | As a %of TotalRevenues |
| North America | $ | 887,536 |  |  | 47.2 | % |  | $ | 830,888 |  |  | 50.6 | % |  | $ | 756,278 |  |  | 47.7 | % |
| Asia-Pacific | 668,597 |  |  | 35.6 |  |  | 552,923 |  |  | 33.7 |  |  | 608,386 |  |  | 38.4 |  |
| Europe | 323,217 |  |  | 17.2 |  |  | 258,025 |  |  | 15.7 |  |  | 219,671 |  |  | 13.9 |  |
|  | $ | 1,879,350 |  |  | 100.0 | % |  | $ | 1,641,836 |  |  | 100.0 | % |  | $ | 1,584,335 |  |  | 100.0 | % |

[0001408710-21-000034:notes:145]
The following table sets forth revenues by end market.

[0001408710-21-000034:notes:146]
| (amount in thousands, except percentages) | Year ended June 25,2021 |  | As a %of TotalRevenues |  | Year ended June 26,2020 |  | As a %of TotalRevenues |  | Year ended June 28,2019 |  | As a %of TotalRevenues |
| Optical communications | $ | 1,441,338 |  |  | 76.7 | % |  | $ | 1,248,174 |  |  | 76.0 | % |  | $ | 1,184,936 |  |  | 74.8 | % |
| Lasers, sensors and other | 438,012 |  |  | 23.3 |  |  | 393,662 |  |  | 24.0 |  |  | 399,399 |  |  | 25.2 |  |
|  | $ | 1,879,350 |  |  | 100.0 | % |  | $ | 1,641,836 |  |  | 100.0 | % |  | $ | 1,584,335 |  |  | 100.0 | % |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001408710-21-000034:notes:147]
The following table presents revenues by end market:

[0001408710-21-000034:notes:148]
|  | Years Ended |
| (amount in thousands) | June 25,2021 |  | June 26,2020 |  | June 28,2019 |
| Optical communications | $ | 1,441,338 |  |  | $ | 1,248,174 |  |  | $ | 1,184,936 |  |
| Lasers, sensors, and other | 438,012 |  |  | 393,662 |  |  | 399,399 |  |
| Total | $ | 1,879,350 |  |  | $ | 1,641,836 |  |  | $ | 1,584,335 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001408710-21-000034:notes:149]
Income taxes
Cayman Islands

[0001408710-21-000034:notes:150]
Fabrinet is domiciled in the Cayman Islands. Under the current laws of the Cayman Islands, Fabrinet is not subject to tax in the Cayman Islands on income or capital gains until March 6, 2039.

[0001408710-21-000034:notes:151]
Income of the Company exempted from corporate income tax in the Cayman Islands amounted to $115.8 million, $101.9 million and $104.6 million for the years ended June 25, 2021, June 26, 2020 and June 28, 2019, respectively.

[0001408710-21-000034:notes:152]
Thailand

[0001408710-21-000034:notes:153]
Fabrinet Thailand is where the majority of the Company’s operations and production takes place. The Company was not subject to tax from July 2012 through June 2020 on income generated from the manufacture of products at Pinehurst Building 6, and is not subject to tax from July 2018 through June 2026 on income generated from the manufacture of products at its Chonburi campus. After June 2020, 50% of our income generated from products manufactured at our Pinehurst campus Building 6 will be exempted from tax through June 2025. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted. Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001408710-21-000034:notes:154]
People’s Republic of China

[0001408710-21-000034:notes:155]
The corporate income tax rate for Casix is 25%.

[0001408710-21-000034:notes:156]
The United States

[0001408710-21-000034:notes:157]
The Tax Cuts and Jobs Act enacted on December 22, 2017 provided for significant changes to U.S. tax law, including a reduction in the U.S. corporate income tax rate to 21% effective January 1, 2018. Accordingly, the Company’s U.S. subsidiaries were subject to a Federal statutory tax rate of 21% for fiscal year 2021 and fiscal year 2020.

[0001408710-21-000034:notes:158]
The United Kingdom

[0001408710-21-000034:notes:159]
The corporate income tax rate for U.K. subsidiaries is 19%.

[0001408710-21-000034:notes:160]
Israel

[0001408710-21-000034:notes:161]
The corporate income tax rate for Israel subsidiaries is 23%.

[0001408710-21-000034:notes:162]
The Company’s income tax expense consisted of the following:

[0001408710-21-000034:notes:163]
|  | Years Ended |
| (amount in thousands) | June 25,2021 |  | June 26,2020 |  | June 28,2019 |
| Current | $ | 6,355 |  |  | $ | 6,274 |  |  | $ | 4,384 |  |
| Deferred | (4,212) |  |  | (511) |  |  | 894 |  |
| Total income tax expense | $ | 2,143 |  |  | $ | 5,763 |  |  | $ | 5,278 |  |

[0001408710-21-000034:notes:164]
The reconciliation between the Company’s taxes that would arise by applying the statutory tax rate of the country of the Company’s principal operations, Thailand, to the Company’s effective tax charge is shown below:

[0001408710-21-000034:notes:165]
|  | Years Ended |
| (amount in thousands) | June 25,2021 |  | June 26,2020 |  | June 28,2019 |
| Income before income taxes(1) | $ | 150,484 |  |  | $ | 119,242 |  |  | $ | 126,233 |  |
| Tax expense calculated at a statutory corporate income tax rate of 20% | 30,097 |  |  | 23,848 |  |  | 25,247 |  |
| Effect of income taxes from locations with tax rates different from Thailand | 198 |  |  | 577 |  |  | 977 |  |
| Income not subject to tax(2) | (23,645) |  |  | (20,797) |  |  | (21,161) |  |
| Income tax on unremitted earnings | 1,395 |  |  | 1,221 |  |  | 1,260 |  |
| Effect of foreign exchange rate adjustment | (2,855) |  |  | 382 |  |  | 603 |  |
| Tax rebate from research and development application | (728) |  |  | (1,228) |  |  | (649) |  |
| Provision for uncertain income tax position | (831) |  |  | (641) |  |  | (229) |  |
| Utilization of loss carryforward | (610) |  |  | — |  |  | — |  |
| Valuation allowance (reversal of) | (1,822) |  |  | 2,446 |  |  | — |  |
| Others | 944 |  |  | (45) |  |  | (770) |  |
| Corporate income tax expense | $ | 2,143 |  |  | $ | 5,763 |  |  | $ | 5,278 |  |

[0001408710-21-000034:notes:166]
(1)Income before income taxes was mostly generated from domestic income in the Cayman Islands.

[0001408710-21-000034:notes:167]
(2)Income not subject to tax relates to income earned in the Cayman Islands and income subject to an investment promotion privilege for Pinehurst Building 6 and the Company’s Chonburi campus. Income not subject to tax per ordinary share on a diluted basis was $0.63, $0.55, and $0.57 for the years ended June 25, 2021, June 26, 2020, and June 28, 2019, respectively.

[0001408710-21-000034:notes:168]
The Company’s deferred tax assets and deferred tax liabilities, net of valuation allowance, at each balance sheet date are as follows:

[0001408710-21-000034:notes:169]
|  | As of |
| (amount in thousands) | June 25,2021 |  | June 26,2020 |
| Deferred tax assets: |  |  |  |
| Depreciation | $ | 1,565 |  |  | $ | 1,219 |  |
| Severance liability | 3,491 |  |  | 2,958 |  |
| Reserves and allowance | 1,751 |  |  | 1,405 |  |
| Net operating loss carryforwards | 1,585 |  |  | — |  |
| Others | 1,036 |  |  | 321 |  |
| Total | $ | 9,428 |  |  | $ | 5,903 |  |
| Deferred tax liabilities: |  |  |  |
| Temporary differences from intangibles and changes in the fair value of assets acquired | $ | (1,202) |  |  | $ | (336) |  |
| Deferred tax from unremitted earnings | (5,072) |  |  | (4,620) |  |
| Others | 1,167 |  |  | — |  |
| Total | (5,107) |  |  | (4,956) |  |
| Net | $ | 4,321 |  |  | $ | 947 |  |

[0001408710-21-000034:notes:170]
The changes in the valuation allowances of deferred tax assets were as follows:

[0001408710-21-000034:notes:171]
| (amount in thousands) | Valuation allowances ofdeferred tax assets |
| Balance as of June 29, 2018 | $ | 1,165 |  |
| Additional | 126 |  |
| Balance as of June 28, 2019 | 1,291 |  |
| Additional | 2,437 |  |
| Balance as of June 26, 2020 | 3,728 |  |
| Additional | 479 |  |
| Reduction | (2,146) |  |
| Balance as of June 25, 2021 | $ | 2,061 |  |

[0001408710-21-000034:notes:172]
During fiscal year 2021, one of the Company’s subsidiaries in the U.S. generated taxable income sufficient for the utilization of loss carryforwards due to better operating performance and effective control of operating expenses. Management determined that it was more likely than not that future taxable income would be sufficient to allow utilization of the deferred tax assets. Thus, a full valuation allowance of $1.5 million for the deferred tax assets was released as of June 25, 2021.

[0001408710-21-000034:notes:173]
During fiscal year 2021, one of the Company’s subsidiaries in the U.K. also generated net operating loss and management expected that such subsidiary would continue to have net operating losses in the foreseeable future. Therefore, management believes it is more likely than not that all of the deferred tax assets of such subsidiary will not be utilized. Thus, a full valuation allowance of $2.1 million for the deferred tax assets was set up as of June 25, 2021.

[0001408710-21-000034:notes:174]
Income tax liabilities have not been established for withholding tax and other taxes that would be payable on the unremitted earnings of Fabrinet Thailand. Such amounts of Fabrinet Thailand are permanently reinvested. Unremitted earnings for Fabrinet Thailand totaled $126.8 million and $112.3 million as of June 25, 2021 and June 26, 2020, respectively. Unrecognized deferred tax liabilities for such unremitted earnings were $7.4 million and $7.0 million as of June 25, 2021 and June 26, 2020, respectively.

[0001408710-21-000034:notes:175]
Deferred tax liabilities of $1.3 million and $1.1 million have been established for withholding tax on the unremitted earnings of Casix for the years ended June 25, 2021 and June 26, 2020, respectively, which are included in non-current deferred tax liability in the consolidated balance sheets.

[0001408710-21-000034:notes:176]
Uncertain income tax positions

[0001408710-21-000034:notes:177]
Interest and penalties related to uncertain income tax positions are recognized in income tax expense. The Company had approximately $0.1 million and $0.5 million of accrued interest and penalties related to uncertain income tax positions on the consolidated balance sheets as of June 25, 2021 and June 26, 2020, respectively. The Company recorded (reversed) interest and penalties of $0.4 million, $0.1 million and $(0.1) million for the years ended June 25, 2021, June 26, 2020 and June 28, 2019, respectively, in the consolidated statements of operations and comprehensive income. With regard to the Thailand jurisdiction, tax years 2015 through 2020 remain open to examination by the local authorities.

[0001408710-21-000034:notes:178]
The following table indicates the changes to the Company’s uncertain income tax positions for the years ended June 25, 2021, June 26, 2020 and June 28, 2019 included in other non-current liabilities.

[0001408710-21-000034:notes:179]
|  | Years Ended |
| (amount in thousands) | June 25,2021 |  | June 26,2020 |  | June 28,2019 |
| Beginning balance | $ | 970 |  |  | $ | 1,323 |  |  | $ | 1,445 |  |
| Additions during the year | 389 |  |  | 157 |  |  | 235 |  |
| Release of tax positions of prior years | (552) |  |  | (510) |  |  | (357) |  |
| Ending balance | $ | 807 |  |  | $ | 970 |  |  | $ | 1,323 |  |


## us-gaap:EarningsPerShareTextBlock

[0001408710-21-000034:notes:180]
Earnings per ordinary shareBasic earnings per ordinary share is computed by dividing reported net income by the weighted average number of ordinary shares outstanding during each period. Diluted earnings per ordinary share is computed by calculating the effect of potential dilutive ordinary shares outstanding during the year using the treasury stock method. Dilutive ordinary 
equivalent shares consist of share options, restricted share units and performance share units. The earnings per ordinary share was calculated as follows:

[0001408710-21-000034:notes:181]
|  | Years Ended |
| (amount in thousands except per share amounts) | June 25,2021 |  | June 26,2020 |  | June 28,2019 |
| Net income attributable to shareholders | $ | 148,341 |  |  | $ | 113,479 |  |  | $ | 120,955 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) | 36,872 |  |  | 36,908 |  |  | 36,798 |  |
| Incremental shares arising from the assumed exercise of share options and vesting of restricted share units and performance share units (thousands of shares) | 683 |  |  | 757 |  |  | 617 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) | 37,555 |  |  | 37,665 |  |  | 37,415 |  |
| Basic earnings per ordinary share | $ | 4.02 |  |  | $ | 3.07 |  |  | $ | 3.29 |  |
| Diluted earnings per ordinary share | $ | 3.95 |  |  | $ | 3.01 |  |  | $ | 3.23 |  |
| Outstanding performance share units excluded from the computation of diluted earnings per ordinary share (thousands of shares)(1) | 53 |  |  | 99 |  |  | 401 |  |

[0001408710-21-000034:notes:182]
(1)These performance share units were not included in the computation of diluted earnings per ordinary share because they are not expected to vest based on the Company’s current assessment of the related performance obligations.


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001408710-21-000034:notes:183]
Cash, cash equivalents and short-term investments
The Company’s cash, cash equivalents, and short-term investments by category is as follows:

[0001408710-21-000034:notes:184]
|  |  |  | Fair Value |
| (amount in thousands) | CarryingCost |  | UnrealizedGain/(Loss) |  | Cash andCashEquivalents |  | MarketableSecurities |  | OtherInvestments |
| As of June 25, 2021 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 222,664 |  |  | $ | — |  |  | $ | 222,664 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 80,305 |  |  | — |  |  | 80,305 |  |  | — |  |  | — |  |
| Liquidity funds | 30,000 |  |  | 1,226 |  |  | — |  |  | — |  |  | 31,226 |  |
| Certificates of deposit | 10,500 |  |  | — |  |  | — |  |  | — |  |  | 10,500 |  |
| Corporate debt securities | 171,626 |  |  | 164 |  |  | — |  |  | 171,790 |  |  | — |  |
| U.S. agency and U.S. Treasury securities | 31,301 |  |  | 146 |  |  | — |  |  | 31,447 |  |  | — |  |
| Total | $ | 546,396 |  |  | $ | 1,536 |  |  | $ | 302,969 |  |  | $ | 203,237 |  |  | $ | 41,726 |  |
| As of June 26, 2020 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 218,117 |  |  | $ | — |  |  | $ | 218,117 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 7,313 |  |  | — |  |  | 7,313 |  |  | — |  |  | — |  |
| Liquidity funds | 40,000 |  |  | 1,051 |  |  | — |  |  | — |  |  | 41,051 |  |
| Time deposits | 11,800 |  |  | — |  |  | — |  |  | — |  |  | 11,800 |  |
| Corporate debt securities | 159,220 |  |  | 948 |  |  | — |  |  | 160,168 |  |  | — |  |
| U.S. agency and U.S. Treasury securities | 49,130 |  |  | 544 |  |  | — |  |  | 49,674 |  |  | — |  |
| Total | $ | 485,580 |  |  | $ | 2,543 |  |  | $ | 225,430 |  |  | $ | 209,842 |  |  | $ | 52,851 |  |

[0001408710-21-000034:notes:185]
The cash equivalents include short-term bank deposits, investments in money market funds, and marketable securities with maturities of three months or less at the date of purchase. The effective interest rate on short term bank deposits was 0.7% and 1.8% per annum for the years ended June 25, 2021 and June 26, 2020, respectively.

[0001408710-21-000034:notes:186]
As of June 25, 2021, the Company had $10.5 million of investments in certificate of deposit classified as held-to-maturity debt securities. As of June 26, 2020, the Company had $11.8 million of investments in time deposit classified as

[0001408710-21-000034:notes:187]
held-to-maturity debt securities. All investments mature within one year. Held-to-maturity debt securities are recorded at amortized cost, which approximates fair value. No unrecognized gains and losses were recorded during the years ended June 25, 2021 and June 26, 2020.

[0001408710-21-000034:notes:188]
As of June 25, 2021 and June 26, 2020, 65% and 63%, respectively, of our cash and cash equivalents were held by the Parent Company.

[0001408710-21-000034:notes:189]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of June 25, 2021:

[0001408710-21-000034:notes:190]
|  | June 25, 2021 |  | June 26, 2020 |
| (amount in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 30,000 |  |  | $ | 31,226 |  |  | $ | 116,127 |  |  | $ | 117,247 |  |
| Due between one to five years | 202,927 |  |  | 203,237 |  |  | 132,223 |  |  | 133,646 |  |
| Total | $ | 232,927 |  |  | $ | 234,463 |  |  | $ | 248,350 |  |  | $ | 250,893 |  |

[0001408710-21-000034:notes:191]
The following table summarizes the carrying cost of short-term investments classified as held-to-maturity securities based on stated effective maturities as of June 25, 2021:

[0001408710-21-000034:notes:192]
| (amount in thousands) | As of June 25, 2021 |  | As of June 26, 2020 |
| Due within one year | $ | 10,500 |  |  | $ | 11,800 |  |
| Due between one to five years | — |  |  | — |  |
| Total | $ | 10,500 |  |  | $ | 11,800 |  |

[0001408710-21-000034:notes:193]
During the year ended June 25, 2021, the Company recognized a realized gain of $0.4 million from sales of available-for-sale debt securities in interest income in the consolidated statements of operations and comprehensive income. During the year ended June 26, 2020, the Company recognized a realized gain of $0.1 million from sales of available-for-sale debt securities in interest income in the consolidated statements of operations and comprehensive income.

[0001408710-21-000034:notes:194]
As of June 25, 2021, the Company considered the decline in market value of its available-for-sale debt securities by using the AFS debt security impairment model. The Company typically invests in highly-rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy requires investments generally to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. The Company assessed impairment at the individual security level according to accounting standard by comparing its fair value/market value with its amortized cost. The Company considered factors such as the failure of the issuer of the security to make scheduled interest and principal payments and any changes to the credit rating of the security by a rating agency. The credit rating of the Company's invested securities are still in compliance with the Company's investment policy. No impairment losses on available-for-sale debt securities were recorded for the year ended June 25, 2021.

[0001408710-21-000034:notes:195]
As of June 25, 2021, the Company evaluated the expected credit loss for held-to-maturity debt securities at the individual security level within scope of CECL model by considering the historical information, current and future economic conditions and events. Additionally, the Company considered the qualitative factors such as term and structure of the instrument and credit rating by rating agencies in determining if a zero-credit loss expectation is supportable. The credit rating of the Company's invested securities are still in compliance with the Company's investment policy. No impairment losses on held-to-maturity debt securities were recorded for the year ended June 25, 2021.

[0001408710-21-000034:notes:196]
As of June 26, 2020, the Company considered the decline in market value of its available-for-sale and held-to-maturity debt securities to be temporary in nature and did not consider any of its securities other-than-temporarily impaired. The Company typically invests in highly-rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy requires investments generally to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. When evaluating an investment for other-than-temporary impairment, the Company reviews factors such as the length of time and extent to which fair value has been below its cost basis, the financial condition of the issuer and any changes thereto, changes in market interest rates, and the Company’s intent to sell, or whether it is more likely than not it will be required to sell, the investment before recovery of the investment’s cost basis. No impairment losses were recorded for the year ended June 26, 2020.


## us-gaap:FairValueDisclosuresTextBlock

[0001408710-21-000034:notes:197]
Fair value of financial instruments
Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. A fair value hierarchy is established, which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs for the valuation of an asset or liability as of the measurement date. The three levels of inputs that may be used to measure fair value are defined as follows:

[0001408710-21-000034:notes:198]
Level 2 inputs are inputs other than quoted prices included within Level 1 that are observable for assets or liabilities, either directly or indirectly. If the assets or liabilities have a specified (contractual) term, Level 2 inputs must be observable for substantially the full term of assets or liabilities.

[0001408710-21-000034:notes:199]
Level 3 inputs are unobservable inputs for assets or liabilities, which require the reporting entity to develop its own valuation techniques and assumptions.

[0001408710-21-000034:notes:200]
The following table provides details of the financial instruments measured at fair value on a recurring basis, including:

[0001408710-21-000034:notes:201]
|  | Fair Value Measurements at Reporting DateUsing |
| (amount in thousands) | Level 1 |  | Level 2 |  |  | Level 3 |  | Total |
| As of June 25, 2021 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 80,305 |  |  |  | $ | — |  |  | $ | 80,305 |  |
| Liquidity funds | — |  |  | 31,226 |  |  |  | — |  |  | 31,226 |  |
| Corporate debt securities | — |  |  | 171,790 |  |  |  | — |  |  | 171,790 |  |
| U.S. agency and U.S. Treasury securities | — |  |  | 31,447 |  |  |  | — |  |  | 31,447 |  |
| Derivative assets - current portion | — |  |  | 1 |  | (1) |  | — |  |  | 1 |  |
| Total | $ | — |  |  | $ | 314,769 |  |  |  | $ | — |  |  | $ | 314,769 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities - current portion | $ | — |  |  | $ | 5,654 |  |  |  | $ | — |  |  | $ | 5,654 |  |
| Derivative liabilities - non-current portion | $ | — |  |  | $ | 1,977 |  |  |  | $ | — |  |  | $ | 1,977 |  |
| Total | $ | — |  |  | $ | 7,631 |  | (2) |  | $ | — |  |  | $ | 7,631 |  |

[0001408710-21-000034:notes:202]
|  | Fair Value Measurements at Reporting DateUsing |
| (amount in thousands) | Level 1 |  | Level 2 |  |  | Level 3 |  | Total |
| As of June 26, 2020 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 7,313 |  |  |  | $ | — |  |  | $ | 7,313 |  |
| Liquidity funds | — |  |  | 41,051 |  |  |  | — |  |  | 41,051 |  |
| Corporate debt securities | — |  |  | 160,168 |  |  |  | — |  |  | 160,168 |  |
| U.S. agency and U.S. Treasury securities | — |  |  | 49,674 |  |  |  | — |  |  | 49,674 |  |
| Derivative assets - current | — |  |  | 2,823 |  | (3) |  |  |  | 2,823 |  |
| Total | $ | — |  |  | $ | 261,029 |  |  |  | $ | — |  |  | $ | 261,029 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities - current portion | $ | — |  |  | $ | 2,148 |  |  |  | $ | — |  |  | $ | 2,148 |  |
| Derivative liabilities - non-current portion | $ | — |  |  | $ | 3,718 |  |  |  | $ | — |  |  | $ | 3,718 |  |
| Total | $ | — |  |  | $ | 5,866 |  | (4) |  | $ | — |  |  | $ | 5,866 |  |

[0001408710-21-000034:notes:203]
(1)Foreign currency forward contracts with an aggregate notional amount of $2.0 million.

[0001408710-21-000034:notes:204]
(2)Foreign currency forward contracts with an aggregate notional amount of $128.0 million and Canadian dollars of 0.4 million and two interest rate swap agreements with an aggregate notional amount of $125.1 million.

[0001408710-21-000034:notes:205]
(3)Foreign currency forward contracts with an aggregate notional amount of $125.0 million and Canadian dollars of 0.6 million, and option contract with a notional amount of $1.0 million.

[0001408710-21-000034:notes:206]
(4)Two interest rate swap agreements with an aggregate notional amount of $125.1 million.

[0001408710-21-000034:notes:207]
Derivative Financial Instruments

[0001408710-21-000034:notes:208]
The Company utilizes derivative financial instruments to hedge (i) foreign exchange risk associated with certain foreign currency denominated assets and liabilities and other foreign currency transactions, and (ii) interest rate risk associated with its long-term debt.

[0001408710-21-000034:notes:209]
The Company minimizes the credit risk associated with its derivative instruments by limiting the exposure to any single counterparty and by entering into derivative instruments only with counterparties that meet the Company’s minimum credit quality standard.

[0001408710-21-000034:notes:210]
Foreign Currency Forward and Option Contracts

[0001408710-21-000034:notes:211]
As a result of foreign currency rate fluctuations, the U.S. dollar equivalent values of the Company’s foreign currency denominated assets and liabilities fluctuate. The Company uses foreign currency forward and option contracts to manage the foreign exchange risk associated with a portion of its foreign currency denominated assets and liabilities and other foreign currency transactions. The Company enters into foreign currency forward and option contracts to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht and Canadian dollars with counterparties that meet the Company’s minimum credit quality standard.

[0001408710-21-000034:notes:212]
The Company may enter into foreign currency forward contracts with maturities of up to 12 months to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht, including inventory purchases, payroll and other operating expenses. The Company considers these forward contracts as dual-purpose hedges, that hedge both the foreign exchange fluctuation (i) from inception through the forecasted expenditure, and (ii) any subsequent revaluation of the account payable or accrual. The Company may designate the forward contracts that hedge the foreign exchange fluctuation from inception through the forecasted expenditure as cash flow hedges. The gain or loss on a derivative instrument designated and qualified as a cash flow hedging instrument is recorded as a component of other comprehensive income and reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings. The reclassified amounts are presented in the same income statement line item as the earnings effect of the hedged item. Once the forecasted transactions are recorded, the Company will discontinue the hedging relationship by de-designating the derivative instrument and recording subsequent changes in fair value through contract maturity to foreign exchange gain (loss), net in the consolidated statements of operations and comprehensive income as a natural hedge against the Thai baht denominated assets and liabilities.

[0001408710-21-000034:notes:213]
The Company may also enter into non-designated foreign currency forward and option contracts to provide an offset to the re-measurement of foreign currency denominated assets and liabilities and to hedge certain forecasted exposures. Changes in the fair value of these non-designated derivatives are recorded through foreign exchange gain (loss), net in the consolidated statements of operations and comprehensive income.

[0001408710-21-000034:notes:214]
As of June 25, 2021, the Company had 130 outstanding U.S. dollar foreign currency forward contracts against Thai baht with an aggregate notional amount of $130.0 million and with maturity dates ranging from July 2021 through January 2022, and two foreign currency contracts with an aggregate notional amount of Canadian dollars of 0.4 million and with maturity dates in September 2021.

[0001408710-21-000034:notes:215]
As of June 26, 2020, the Company had 125 outstanding U.S. dollar foreign currency forward contracts against Thai baht with an aggregate notional amount of $125.0 million, one foreign currency contract with a notional amount of 0.6 million Canadian dollars and one foreign currency option contract with a notional amount of $1.0 million with maturity dates ranging from July 2020 through January 2021.

[0001408710-21-000034:notes:216]
As of June 25, 2021, the hedging relationship over foreign currency forward contracts which were designated for hedge accounting had been tested to be highly effective based on the performance of retrospective and prospective regression testing. As of June 25, 2021, the amount in AOCI that is expected to be reclassified into earnings within 12 months as gain was $2.7 million.

[0001408710-21-000034:notes:217]
During the year ended June 25, 2021 and June 26, 2020, the Company included an unrealized loss of $1.5 million and $1.2 million, respectively, from changes in fair value of foreign currency forward and option contracts which were not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the consolidated statements of operations and comprehensive income.

[0001408710-21-000034:notes:218]
Interest Rate Swap Agreements

[0001408710-21-000034:notes:219]
The Company entered into interest rate swap agreements to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. As of June 25, 2021 and June 26, 2020, the Company had two outstanding interest rate swap agreements with an aggregate notional amount of $125.1 million.

[0001408710-21-000034:notes:220]
On July 25, 2018, Fabrinet Thailand entered into an interest rate swap agreement to effectively convert the floating interest rate of its term loan under the credit facility agreement with Bank of America Credit Facility Agreement to a fixed interest rate of 2.86% per annum through the scheduled maturity of the term loan in June 2023 (see Note 15). The Company did not designate this interest rate swap for hedge accounting.

[0001408710-21-000034:notes:221]
On September 3, 2019, the Company entered into a new term loan agreement under a Credit Facility Agreement with the Bank of Ayudhya Public Company Limited (the “Bank”) (see Note 15) and on September 10, 2019, the Company repaid in full the outstanding term loan under the Bank of America Credit Facility (see Note 15). In conjunction with the funding of the new term loan, the Company entered into a second interest rate swap agreement. The combination of both of these interest rate swaps effectively converts the floating interest rate of the Company’s new term loan with the Bank to a fixed interest rate of 4.36% per annum through the maturity of the term loan in June 2024.

[0001408710-21-000034:notes:222]
On September 27, 2019, the Company designated these two interest rate swaps as a cash flow hedge for the Company’s term loan under the Credit Facility Agreement with the Bank. The combination of these two interest rate swaps qualified for hedge accounting because the hedges are highly effective, and the Company has designated and documented contemporaneously the hedging relationships involving these interest rate swaps. While the Company intends to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in earnings. From September 27, 2019, any gains or losses related to these interest rate swaps will be recorded in AOCI in the consolidated balance sheets. The Company will reclassify a portion of the gains or losses from AOCI into earnings at each reporting period based on either the accrued interest amount or the interest payment.

[0001408710-21-000034:notes:223]
As of June 25, 2021, the amount in AOCI that is expected to be reclassified into earnings within 12 months as loss is $0.8 million.

[0001408710-21-000034:notes:224]
Prior to September 27, 2019, these interest rate swaps were not designated as cash flow hedges and all changes in the fair value of these interest rate swaps were reflected in earnings. During the year ended June 26, 2020, the Company recorded unrealized loss of $1.7 million, from changes in the fair value of these interest rate swaps as interest expense in the consolidated statements of operations and comprehensive income.

[0001408710-21-000034:notes:225]
The following table provides a summary of the impact of derivative gain (loss) of the Company’s foreign currency forward contracts and interest rate swaps which were designated as cash flow hedges on the consolidated statements of operations and other comprehensive income:

[0001408710-21-000034:notes:226]
|  |  |  | Year Ended |
| (amount in thousands) | Financial statementsline item |  | June 25,2021 |  | June 26,2020 |
| Derivatives gain (loss) recognized in other comprehensive income (loss): |  |  |  |  |  |
| Foreign currency forward contracts | Other comprehensive income |  | $ | (6,194) |  |  | $ | 1,081 |  |
| Interest rate swaps | Other comprehensive income |  | 1,624 |  |  | (910) |  |
| Total derivatives loss (gain) recognized in other comprehensive income |  |  | $ | (4,570) |  |  | $ | 171 |  |
| Derivatives loss (gain) reclassified from accumulated other comprehensive income into earnings: |  |  |  |  |  |
| Foreign currency forward contracts | Cost of revenues |  | $ | (966) |  |  | $ | 2,512 |  |
| Foreign currency forward contracts | Selling, general and administrative expenses |  | (40) |  |  | 105 |  |
| Foreign currency forward contracts | Foreign exchange gain (loss), net |  | 1,769 |  |  | (998) |  |
| Interest rate swaps | Interest expense |  | (1,299) |  |  | (1,220) |  |
| Total derivatives (gain) loss reclassified from accumulated other comprehensive income into earnings |  |  | $ | (536) |  |  | $ | 399 |  |
| Change in net unrealized gain (loss) on derivative instruments |  |  | $ | (5,106) |  |  | $ | 570 |  |

[0001408710-21-000034:notes:227]
Fair value of derivatives

[0001408710-21-000034:notes:228]
The following table provides the fair values of the Company’s derivative financial instruments for the periods presented:

[0001408710-21-000034:notes:229]
|  | June 25,2021 |  | June 26,2020 |
| (amount in thousands) | DerivativeAssets |  | DerivativeLiabilities |  | DerivativeAssets |  | DerivativeLiabilities |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts | $ | — |  |  | $ | (1,379) |  |  | $ | 9 |  |  | $ | (611) |  |
| Interest rate swaps | — |  |  | — |  |  | — |  |  | — |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward contracts | 1 |  |  | (2,703) |  |  | 2,814 |  |  | (83) |  |
| Interest rate swaps | — |  |  | (3,549) |  |  | — |  |  | (5,172) |  |
| Derivatives, gross balances | 1 |  |  | (7,631) |  |  | 2,823 |  |  | (5,866) |  |

[0001408710-21-000034:notes:230]
The Company presents its derivatives at gross fair values in the consolidated balance sheets.

[0001408710-21-000034:notes:231]
The Company recorded the fair value of derivative financial instruments in the consolidated balance sheets as follows:

[0001408710-21-000034:notes:232]
| Derivative Financial Instruments | Balance Sheet Line Item |
| Fair Value of Derivative Assets | Other current assets |
| Fair Value of Derivative Liabilities | Accrued expenses |
| Fair Value of Derivative Liabilities | Other non-current liabilities |


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001408710-21-000034:notes:233]
Trade accounts receivable, net

[0001408710-21-000034:notes:234]
| (amount in thousands) | As of June 25,2021 |  | As of June 26,2020 |
| Trade accounts receivable | $ | 336,647 |  |  | $ | 273,001 |  |
| Less: Allowance for doubtful account | (100) |  |  | (336) |  |
| Trade accounts receivable, net | $ | 336,547 |  |  | $ | 272,665 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001408710-21-000034:notes:235]
Inventories

[0001408710-21-000034:notes:236]
| (amount in thousands) | As of June 25,2021 |  | As of June 26,2020 |
| Raw materials | $ | 196,345 |  |  | $ | 141,522 |  |
| Work in progress | 174,654 |  |  | 136,344 |  |
| Finished goods | 15,471 |  |  | 17,950 |  |
| Goods in transit | 35,663 |  |  | 13,970 |  |
| Inventories | $ | 422,133 |  |  | $ | 309,786 |  |


## fn:ScheduleOfOtherReceivableTextBlock

[0001408710-21-000034:notes:237]
Other receivable
On October 1, 2019, the Company provided funds in the amount of $24.3 million to a customer to support the customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand.

[0001408710-21-000034:notes:238]
On October 1, 2020, the Company extended the payment terms of the funds and the accrued interest from September 30, 2020 to April 1, 2021, and reduced the interest rate effective from October 1, 2020. The extension was granted in connection with the customer’s agreement to transfer additional manufacturing operations to the Company’s facilities in Thailand beginning in November 2020. These funds were repaid on April 1, 2021.


## fn:RestrictedCashAndCashEquivalentsTextBlock

[0001408710-21-000034:notes:239]
Restricted cash
As of June 25, 2021, the Company had long-term restricted cash of Chinese Renminbi ("RMB") 1.0 million related to bank guarantees of its subsidiary in the PRC to support the subsidiary's operations. The bank guarantee was backed by cash collateral of $0.2 million.

[0001408710-21-000034:notes:240]
As of June 26, 2020, the Company had one outstanding standby letter of credit of 6.0 million Euros related to the Company’s support of a customer with the transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. The standby letter of credit was backed by cash collateral of $7.4 million. This standby letter of credit expired on December 31, 2020 and the corresponding cash collateral was released in January 2021.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001408710-21-000034:notes:241]
Leases
The Company leases facilities under non-cancelable operating lease agreements. The Company leases a portion of its capital equipment and vehicles, certain land and buildings for its facilities in Thailand, the Cayman Islands, China, the U.S., the U.K. and Israel under operating lease arrangements that expire at various dates through 2025. Certain of these lease arrangements provide the Company the ability to extend the lease from one to five years following the expiration of the current term. However, the Company may exclude lease extension options from its ROU assets and lease liabilities as the Company is not reasonably assured that it will exercise these options. None of the lease agreements contain residual value guarantees provided by the lessee. The Company also has one intercompany lease transaction which is a lease of office and manufacturing space between Fabritek and Fabrinet West.

[0001408710-21-000034:notes:242]
As of June 25, 2021, the maturities of the Company’s operating lease liabilities were as follows:

[0001408710-21-000034:notes:243]
| (amount in thousands) |  |  |
| 2022 | $ | 2,775 |  |  |
| 2023 | 2,676 |  |  |
| 2024 | 1,242 |  |  |
| 2025 | 41 |  |  |
| Total undiscounted lease payments | 6,734 |  |  |
| Less imputed interest | (291) |  |  |
| Total present value of lease liabilities | $ | 6,443 |  | (1) |

[0001408710-21-000034:notes:244]
(1)Includes current portion of operating lease liabilities of $2.6 million.

[0001408710-21-000034:notes:245]
Rental expense related to the Company’s operating leases is recognized on a straight-line basis over the lease term. Rental expense for long-term leases for the years ended June 25, 2021, June 26, 2020 and June 28, 2019 was $2.6 million, $2.1 million and $1.9 million, respectively. Rental expense for short-term leases for the years ended June 25, 2021, June 26, 2020 and June 28, 2019 was $0.3 million, $0.2 million and de minimis amount, respectively.

[0001408710-21-000034:notes:246]
In connection with the acquisition of Fabrinet UK, the Company assumed the finance lease commitments for certain equipment, with various expiration dates through September 2020. The equipment can be purchased at pre-determined prices upon expiration of such contracts.

[0001408710-21-000034:notes:247]
The following summarizes additional information related to the Company’s operating leases:

[0001408710-21-000034:notes:248]
|  | As of June 25, 2021 |
| Weighted-average remaining lease term (in years) |  |
| Operating leases | 2.7 |
| Weighted-average discount rate |  |
| Operating leases | 3.5 | % |

[0001408710-21-000034:notes:249]
The following information represents supplemental disclosure for the statement of cash flows related to operating leases:

[0001408710-21-000034:notes:250]
| (amount in thousands) | Year Ended June 25, 2021 |
| Cash paid for amounts included in the measurement of lease liabilities |  |
| Operating cash flows from operating leases | $ | 2,603 |  |
| Financing cash flows from finance leases | $ | 100 |  |
| ROU assets obtained in exchange for lease liabilities | $ | 959 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001408710-21-000034:notes:251]
Property, plant and equipment, net
The components of property, plant and equipment, net were as follows:

[0001408710-21-000034:notes:252]
| (amount in thousands) | Land andLandImprovements |  | BuildingandBuildingImprovements |  | ManufacturingEquipment |  | OfficeEquipment |  | MotorVehicles |  | Computers |  | ConstructionandMachineryUnderInstallation |  | Total |
| As of June 25, 2021 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost | $ | 45,125 |  |  | $ | 163,375 |  |  | $ | 213,981 |  |  | $ | 9,243 |  |  | $ | 627 |  |  | $ | 29,621 |  |  | $ | 9,377 |  |  | $ | 471,349 |  |
| Less: Accumulated depreciation | (26) |  |  | (58,791) |  |  | (141,997) |  |  | (6,376) |  |  | (509) |  |  | (21,715) |  |  | — |  |  | (229,414) |  |
| Less: Impairment reserve | — |  |  | — |  |  | (804) |  |  | — |  |  | — |  |  | (2) |  |  | — |  |  | (806) |  |
| Net book value | $ | 45,099 |  |  | $ | 104,584 |  |  | $ | 71,180 |  |  | $ | 2,867 |  |  | $ | 118 |  |  | $ | 7,904 |  |  | $ | 9,377 |  |  | $ | 241,129 |  |
| As of June 26, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost | $ | 45,099 |  |  | $ | 145,912 |  |  | $ | 198,036 |  |  | $ | 5,600 |  |  | $ | 939 |  |  | $ | 16,766 |  |  | $ | 12,657 |  |  | $ | 425,009 |  |
| Less: Accumulated depreciation | (17) |  |  | (51,393) |  |  | (127,397) |  |  | (4,135) |  |  | (678) |  |  | (12,273) |  |  | — |  |  | (195,893) |  |
| Less: Impairment reserve | — |  |  | — |  |  | (840) |  |  | — |  |  | — |  |  | (2) |  |  | — |  |  | (842) |  |
| Net book value | $ | 45,082 |  |  | $ | 94,519 |  |  | $ | 69,799 |  |  | $ | 1,465 |  |  | $ | 261 |  |  | $ | 4,491 |  |  | $ | 12,657 |  |  | $ | 228,274 |  |

[0001408710-21-000034:notes:253]
Leased assets included in manufacturing equipment comprise certain machine and equipment from finance lease agreements assumed from the acquisition of Fabrinet UK.

[0001408710-21-000034:notes:254]
| (amount in thousands) | As of June 25, 2021 |  | As of June 26, 2020 |
| Cost—Finance leases | $ | 1,747 |  |  | $ | 1,992 |  |
| Less: Accumulated depreciation | (1,747) |  |  | (1,199) |  |
| Net book value | $ | — |  |  | $ | 793 |  |

[0001408710-21-000034:notes:255]
Depreciation expense amounted to $34.7 million, $29.7 million and $28.7 million for the years ended June 25, 2021, June 26, 2020 and June 28, 2019, respectively, and has been allocated between cost of revenues and selling, general and administrative expenses in the consolidated statements of operations and comprehensive income.

[0001408710-21-000034:notes:256]
The cost of fully depreciated property, plant and equipment written-off during the years ended June 25, 2021, June 26, 2020 and June 28, 2019 amounted to $16.3 million, $2.9 million and $2.0 million, respectively.

[0001408710-21-000034:notes:257]
During the years ended June 25, 2021, June 26, 2020 and June 28, 2019, the Company recognized impairment reserves for property, plant and equipment of $0.8 million, $0.8 million and $0.9 million, respectively.

[0001408710-21-000034:notes:258]
During the years ended June 25, 2021, June 26, 2020 and June 28, 2019, the Company had no borrowing costs capitalized.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001408710-21-000034:notes:259]
Intangibles
The following tables present details of the Company’s intangibles:

[0001408710-21-000034:notes:260]
| (amount in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  | ForeignCurrencyTranslationAdjustment |  | Net |
| As of June 25, 2021 |  |  |  |  |  |  |  |
| Software | $ | 9,767 |  |  | $ | (6,632) |  |  | $ | — |  |  | $ | 3,135 |  |
| Customer relationships | 4,373 |  |  | (3,195) |  |  | 58 |  |  | 1,236 |  |
| Backlog | 119 |  |  | (119) |  |  | — |  |  | — |  |
| Total intangibles | $ | 14,259 |  |  | $ | (9,946) |  |  | $ | 58 |  |  | $ | 4,371 |  |

[0001408710-21-000034:notes:261]
| (amount in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  | ForeignCurrencyTranslationAdjustment |  | Net |
| As of June 26, 2020 |  |  |  |  |  |  |  |
| Software | $ | 8,317 |  |  | $ | (5,577) |  |  | $ | — |  |  | $ | 2,740 |  |
| Customer relationships | 4,373 |  |  | (2,691) |  |  | (110) |  |  | 1,572 |  |
| Backlog | 119 |  |  | (119) |  |  | — |  |  | — |  |
| Total intangibles | $ | 12,809 |  |  | $ | (8,387) |  |  | $ | (110) |  |  | $ | 4,312 |  |

[0001408710-21-000034:notes:262]
In connection with the acquisition of Fabrinet UK, the Company recorded $4.4 million of customer relationships and $0.1 million of backlog in the consolidated balance sheets. As of June 25, 2021 and June 26, 2020, the weighted-average remaining life of customer relationships was 3.9 years and 4.6 years, respectively.

[0001408710-21-000034:notes:263]
The Company recorded amortization expense relating to intangibles of $1.5 million, $1.3 million and $1.2 million for the years ended June 25, 2021, June 26, 2020 and June 28, 2019, respectively.

[0001408710-21-000034:notes:264]
Based on the carrying amount of intangibles as of June 25, 2021, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001408710-21-000034:notes:265]
| (amount in thousand) |  |
| 2022 | $ | 1,614 |  |
| 2023 | 1,159 |  |
| 2024 | 821 |  |
| 2025 | 545 |  |
| Thereafter | 232 |  |
| Total | $ | 4,371 |  |


## us-gaap:DebtDisclosureTextBlock

[0001408710-21-000034:notes:266]
Borrowings
The Company’s total borrowings, including current and non-current portions of long-term borrowings, consisted of the following:

[0001408710-21-000034:notes:267]
(amount in thousands)

[0001408710-21-000034:notes:268]
| Rate |  | Conditions |  | Maturity |  | As of June 25, 2021 |  | As of June 26, 2020 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs—current portion |  |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  |  | $ | 12,156 |  |  | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum(1) |  | Repayable inquarterly installments |  | June 2024 |  | 39,609 |  |  | 51,797 |  |
| Less: Current portion |  |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs—non-current portion |  |  |  |  |  | (63) |  |  | (95) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  |  | $ | 27,358 |  |  | $ | 39,514 |  |

[0001408710-21-000034:notes:269]
(1)We have entered into interest rate swaps that effectively fix a series of our future interest payments on our term loans. Refer to Note 7.

[0001408710-21-000034:notes:270]
The movements of long-term borrowings were as follows for the years ended June 25, 2021 and June 26, 2020:

[0001408710-21-000034:notes:271]
|  | Years ended |
| (amount in thousands) | June 25,2021 |  | June 26,2020 |
| Opening balance | $ | 51,797 |  |  | $ | 60,938 |  |
| Borrowings during the period | — |  |  | 60,938 |  |
| Repayments during the period | (12,188) |  |  | (70,079) |  |
| Closing balance | $ | 39,609 |  |  | $ | 51,797 |  |

[0001408710-21-000034:notes:272]
As of June 25, 2021, the future maturities of long-term borrowings during each fiscal year were as follows:

[0001408710-21-000034:notes:273]
| (amount in thousand) |  |
| 2022 | $ | 12,187 |  |
| 2023 | 12,188 |  |
| 2024 | 12,187 |  |
| 2025 | 3,047 |  |
| Total | $ | 39,609 |  |

[0001408710-21-000034:notes:274]
Credit facilities agreements:

[0001408710-21-000034:notes:275]
Bank of Ayudhya Public Company Limited

[0001408710-21-000034:notes:276]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

[0001408710-21-000034:notes:277]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a Term Loan Agreement pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the BofA Facility Agreement.

[0001408710-21-000034:notes:278]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be re-borrowed. During the year ended June 25, 2021, the Company recorded $0.7 million of interest expense in connection with this term loan.

[0001408710-21-000034:notes:279]
Any borrowings under the Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

[0001408710-21-000034:notes:280]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt to equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of June 25, 2021, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

[0001408710-21-000034:notes:281]
The events of default in the Term Loan Agreement include failure to pay amounts due under the Term Loan Agreement or the related finance documents when due, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

[0001408710-21-000034:notes:282]
As of June 25, 2021, there was $39.6 million outstanding under the term loan.

[0001408710-21-000034:notes:283]
Bank of America, N.A.

[0001408710-21-000034:notes:284]
On May 22, 2014, the Company and a consortium of banks entered into a syndicated senior credit facility agreement led by Bank of America (the “BofA Facility Agreement”). The BofA Facility Agreement provided for a $200.0 million credit line, comprised of a $150.0 million revolving loan facility and a $50.0 million delayed draw term loan facility.

[0001408710-21-000034:notes:285]
From time to time, the Company amended the BofA Facility Agreement, before repaying all outstanding amounts under the agreement and terminating such agreement on September 10, 2019.

[0001408710-21-000034:notes:286]
During the year ended June 26, 2020, the Company recorded $0.5 million of interest expense in connection with this term loan.

[0001408710-21-000034:notes:287]
On September 10, 2019, the Company fully repaid $61.0 million in principal, accrued interest and other fees under the agreement. The early termination of this agreement did not trigger any early termination fees.


## fn:AccruedSeveranceBenefitsDisclosureTextBlock

[0001408710-21-000034:notes:288]
Severance liabilities
The following table provides information regarding severance liabilities:

[0001408710-21-000034:notes:289]
|  | Years Ended |
| (amount in thousands) | June 25,2021 |  | June 26,2020 |
| Changes in severance liabilities |  |  |  |
| Balance, beginning of the fiscal year | $ | 17,673 |  |  | $ | 15,473 |  |
| Current service cost | $ | 1,627 |  |  | $ | 1,907 |  |
| Interest cost | 515 |  |  | 462 |  |
| Benefit paid | (1,198) |  |  | (48) |  |
| Actuarial(gain)loss on obligation | 1,129 |  |  | (117) |  |
| Foreign currency translation | 36 |  |  | (4) |  |
| Balance, end of the fiscal year | $ | 19,782 |  |  | $ | 17,673 |  |
| Changes in plan assets |  |  |  |
| Balance, beginning of the fiscal year | $ | 294 |  |  | $ | 317 |  |
| Actual return on plan assets | $ | 19 |  |  | $ | (34) |  |
| Employer contributions | 43 |  |  | 18 |  |
| Benefit paid | (34) |  |  | — |  |
| Foreign currency translation | 34 |  |  | (7) |  |
| Balance, end of the fiscal year | $ | 356 |  |  | $ | 294 |  |
| Underfunded status | $ | (19,426) |  |  | $ | (17,379) |  |

[0001408710-21-000034:notes:290]
The amount recognized in the consolidated balance sheets under non-current liabilities and non-current assets were determined as follows:

[0001408710-21-000034:notes:291]
| (amount in thousands) | As of June 25,2021 |  | As of June 26,2020 |
| Non-current assets | $ | 59 |  |  | $ | — |  |
| Non-current liabilities | $ | 19,485 |  |  | $ | 17,379 |  |

[0001408710-21-000034:notes:292]
The following table provides information regarding accumulated benefit obligations:

[0001408710-21-000034:notes:293]
| (amount in thousands) | As of June 25,2021 |  | As of June 26,2020 |
| Accumulated benefit obligations | $ | 13,581 |  |  | $ | 11,864 |  |

[0001408710-21-000034:notes:294]
The following table sets forth the plan assets at fair value as of June 25, 2021 and June 26, 2020.

[0001408710-21-000034:notes:295]
| (amount in thousands) |  |  | Fair value measurement as of June 25, 2021 |
|  | Total |  | SignificantObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Assets: |  |  |  |  |  |
| Other(1) | $ | 356 |  |  | $ | 211 |  |  | $ | 145 |  |
| Total Assets | $ | 356 |  |  | $ | 211 |  |  | $ | 145 |  |

[0001408710-21-000034:notes:296]
| (amount in thousands) |  |  | Fair value measurement as of June 26, 2020 |
|  | Total |  | SignificantObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Assets: |  |  |  |  |  |
| Other(1) | $ | 294 |  |  | $ | 160 |  |  | $ | 134 |  |
| Total Assets | $ | 294 |  |  | $ | 160 |  |  | $ | 134 |  |

[0001408710-21-000034:notes:297]
(1)The “Other” category represents the bid value of the trustees’ insurance policy held with Old Mutual Wealth and the value of assets held with Royal London.

[0001408710-21-000034:notes:298]
The Trustees have chosen to invest in the following funds:

[0001408710-21-000034:notes:299]
|  | % of Total |
| Fund | As of June 25,2021 |  | As of June 26,2020 |
| Old Mutual Wealth Invesco Perpetual High Income | — | % |  | 38 | % |
| Old Mutual Wealth Creation Balanced Portfolio | 59 | % |  | 17 | % |
| Royal London Deposit Administration | 41 | % |  | 45 | % |

[0001408710-21-000034:notes:300]
The Old Mutual Wealth assets are administered on unit-linked principles and allow access to a range of funds; these have been treated as Level 2 fair value measurement.

[0001408710-21-000034:notes:301]
The Royal London assets are administered on a deposit administration basis. This is similar to a with profits fund but with a lower exposure to the stock market. The policy is invested in a mix of assets, mainly UK Government bonds and Corporate bonds, the returns of which are smoothed over time. These assets are considered as unobservable inputs and have been treated as Level 3 fair value measurement because the fair value of which is based on the previous year end observable value and other unobservable inputs such as declared rates of bonus plus an enhancement on the policy for this scheme.

[0001408710-21-000034:notes:302]
The principal actuarial assumptions used were as follows:

[0001408710-21-000034:notes:303]
Weighted average actuarial assumptions used to determine severance liabilities

[0001408710-21-000034:notes:304]
|  | Years Ended |
|  | June 25, 2021 |  | June 26, 2020 |  | June 28, 2019 |
| Discount rate | 0.2% - 2.9% |  | 0.4% - 3.1% |  | 2.3% - 3.2% |
| Future salary increases | 3.5% - 10.0% |  | 3.5% - 10.0% |  | 3.5% - 10.0% |

[0001408710-21-000034:notes:305]
Weighted average actuarial assumptions used to determine benefit costs

[0001408710-21-000034:notes:306]
|  | Years Ended |
|  | June 25, 2021 |  | June 26, 2020 |  | June 28, 2019 |
| Discount rate | 0.4% - 3.1% |  | 2.3% - 3.2% |  | 2.5% - 3.7% |
| Expected long-term rate of return on assets | 2.3% |  | 2.1% |  | 1.6% |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001408710-21-000034:notes:307]
Share-based compensation
Share-based compensation

[0001408710-21-000034:notes:308]
In determining the grant date fair value of share option awards, the Company is required to make estimates of expected dividends to be issued, expected volatility of Fabrinet’s ordinary shares, expected forfeitures of the awards, risk free interest rates for the expected term of the awards and expected terms of the awards. Forfeitures are estimated at the time of grant and revised if necessary in subsequent periods if actual forfeitures differ from those estimates. The grant date fair value of restricted share units and performance share units is based on the market value of our ordinary shares on the date of grant.

[0001408710-21-000034:notes:309]
The effect of recording share-based compensation expense for the years ended June 25, 2021, June 26, 2020 and June 28, 2019 was as follows:

[0001408710-21-000034:notes:310]
|  | Years Ended |
| (amount in thousands) | June 25,2021 |  | June 26,2020 |  | June 28,2019 |
| Share-based compensation expense by type of award: |  |  |  |  |  |
| Restricted share units | $ | 16,725 |  |  | $ | 16,555 |  |  | $ | 14,691 |  |
| Performance share units | 8,737 |  |  | 5,648 |  |  | 2,466 |  |
| Total share-based compensation expense | 25,462 |  |  | 22,203 |  |  | 17,157 |  |
| Tax effect on share-based compensation expense | — |  |  | — |  |  | — |  |
| Net effect on share-based compensation expense | $ | 25,462 |  |  | $ | 22,203 |  |  | $ | 17,157 |  |

[0001408710-21-000034:notes:311]
Share-based compensation expense was recorded in the consolidated statements of operations and comprehensive income as follows:

[0001408710-21-000034:notes:312]
|  | Years Ended |
| (amount in thousands) | June 25,2021 |  | June 26,2020 |  | June 28,2019 |
| Cost of revenue | $ | 6,185 |  |  | $ | 6,098 |  |  | $ | 5,656 |  |
| Selling, general and administrative expense | 19,277 |  |  | 16,105 |  |  | 11,501 |  |
| Total share-based compensation expense | $ | 25,462 |  |  | $ | 22,203 |  |  | $ | 17,157 |  |

[0001408710-21-000034:notes:313]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the years ended June 25, 2021, June 26, 2020 and June 28, 2019.

[0001408710-21-000034:notes:314]
Share-based award activity

[0001408710-21-000034:notes:315]
On December 12, 2019, the Company’s shareholders approved Fabrinet’s 2020 Equity Incentive Plan (the “2020 Plan”). Upon the approval of the 2020 Plan, Fabrinet’s Amended and Restated 2010 Performance Incentive Plan (the “2010 Plan”) was simultaneously terminated. The 2020 Plan provides for the grant of equity awards thereunder with respect to (i) 1,700,000 ordinary shares, plus (ii) up to 1,300,000 ordinary shares that, as of immediately prior to the termination of the 2010 Plan, had been reserved but not issued pursuant to any awards granted under the 2010 Plan and are not subject to any awards thereunder. Upon termination of the 2010 Plan, 1,281,619 ordinary shares were reserved for issuance under the 2020 Plan pursuant to clause (ii) of the preceding sentence. As of June 25, 2021, there were 238,302 restricted share units outstanding, 188,554 performance share units outstanding and 2,508,074 ordinary shares available for future grant under the 2020 Plan.

[0001408710-21-000034:notes:316]
As of June 25, 2021, there were 391,409 restricted share units outstanding and 238,474 performance share units outstanding under the 2010 Plan. No ordinary shares are available for future grant under the 2010 Plan.

[0001408710-21-000034:notes:317]
On November 2, 2017, the Company adopted the 2017 Inducement Equity Incentive Plan (the “2017 Inducement Plan”) with a reserve of 160,000 ordinary shares authorized for future issuance solely for the granting of inducement share options and equity awards to new employees. The 2017 Inducement Plan was adopted without shareholder approval in reliance on the “employment inducement exemption” provided under the New York Stock Exchange Listed Company Manual. As of June 25, 2021, there were an aggregate of 12,164 restricted share units outstanding and 111,347 ordinary shares available for future grant under the 2017 Inducement Plan.

[0001408710-21-000034:notes:318]
The 2020 Plan, 2010 Plan and 2017 Inducement Plan are collectively referred to as the “Equity Incentive Plans.”

[0001408710-21-000034:notes:319]
Restricted share units and performance share units

[0001408710-21-000034:notes:320]
Restricted share units and performance share units have been granted under the Equity Incentive Plans.

[0001408710-21-000034:notes:321]
Restricted share units granted to employees generally vest in equal installments over three or four years on each anniversary of the vesting commencement date. Restricted share units granted to non-employee directors generally cliff vest 100% on the first of January, approximately one year from the grant date, provided the director continues to serve through such date.

[0001408710-21-000034:notes:322]
Performance share units granted to executives will vest, if at all, at the end of a two-year performance period based on the Company’s achievement of pre-defined performance criteria, which consist of revenue and non-U.S. GAAP gross

[0001408710-21-000034:notes:323]
margin or operating margin targets. The actual number of performance share units that may vest at the end of the performance period ranges from 0% to 100% of the award grant.

[0001408710-21-000034:notes:324]
The following table summarizes restricted share unit activity under the Equity Incentive Plans:

[0001408710-21-000034:notes:325]
|  | Number ofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 29, 2018 | 1,073,580 |  |  | $ | 35.19 |  |
| Granted | 391,328 |  |  | $ | 50.02 |  |
| Issued | (515,482) |  |  | $ | 34.18 |  |
| Forfeited | (148,675) |  |  | $ | 38.42 |  |
| Balance as of June 28, 2019 | 800,751 |  |  | $ | 42.48 |  |
| Granted | 367,088 |  |  | $ | 50.87 |  |
| Issued | (335,355) |  |  | $ | 40.98 |  |
| Forfeited | (34,727) |  |  | $ | 44.59 |  |
| Balance as of June 26, 2020 | 797,757 |  |  | $ | 46.88 |  |
| Granted | 230,759 |  |  | $ | 70.53 |  |
| Issued | (358,508) |  |  | $ | 45.39 |  |
| Forfeited | (28,133) |  |  | $ | 57.86 |  |
| Balance as of June 25, 2021 | 641,875 |  |  | $ | 55.74 |  |
| Expected to vest as of June 25, 2021 | 524,218 |  |  | $ | 55.98 |  |

[0001408710-21-000034:notes:326]
The following table summarizes performance share unit activity under the Equity Incentive Plans:

[0001408710-21-000034:notes:327]
|  | Number ofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 29, 2018 | 605,892 |  |  | $ | 38.41 |  |
| Granted | 201,994 |  |  | $ | 48.02 |  |
| Issued | (227,268) |  |  | 40.48 |  |
| Forfeited | (32,118) |  |  | 40.47 |  |
| Balance as of June 28, 2019 | 548,500 |  |  | $ | 40.97 |  |
| Granted | 242,310 |  |  | $ | 48.65 |  |
| Issued | — |  |  | $ | — |  |
| Forfeited | (350,670) |  |  | $ | 36.99 |  |
| Balance as of June 26, 2020 | 440,140 |  |  | $ | 48.37 |  |
| Granted | 184,718 |  |  | $ | 69.85 |  |
| Issued | (82,185) |  |  | 48.02 |  |
| Forfeited | (115,645) |  |  | $ | 48.02 |  |
| Balance as of June 25, 2021 | 427,028 |  |  | $ | 57.82 |  |
| Expected to vest as of June 25, 2021 | 388,864 |  |  | $ | 58.72 |  |

[0001408710-21-000034:notes:328]
The fair value of restricted share units and performance share units is based on the market value of our ordinary shares on the date of grant.

[0001408710-21-000034:notes:329]
The total fair value of restricted share units and performance share units vested during the years ended June 25, 2021, June 26, 2020 and June 28, 2019 was $22.1 million, $13.7 million and $26.8 million, respectively. The aggregate intrinsic value of restricted share units and performance share units outstanding as of June 25, 2021 was $101.9 million.

[0001408710-21-000034:notes:330]
As of June 25, 2021, there was $10.2 million and $7.3 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.3 years and 1.1 years, respectively.
For the years ended June 25, 2021 and June 26, 2020, the Company withheld an aggregate of 163,615 shares and 94,141 shares, respectively, upon the vesting of restricted share units, based upon the closing share price on the vesting date to settle the employees’ minimum statutory obligation for the applicable income and other employment taxes. For the years ended June 25, 2021 and June 26, 2020, the Company then remitted cash of $11.6 million and $4.9 million, respectively, to the appropriate taxing authorities, and presented it as a financing activity within the consolidated statements of cash flows. The payment had the effect of reducing the number of shares that the Company would have issued on the vesting date and was recorded as a reduction of additional paid-in capital.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001408710-21-000034:notes:331]
Employee benefit plans
Employee contribution plan

[0001408710-21-000034:notes:332]
The Company operates a defined contribution plan, known as a provident fund, in its subsidiaries in Thailand and the United Kingdom. The assets of these plans are in separate trustee-administered funds. The provident fund is funded by matching payments from employees and by the subsidiaries on a monthly basis. Current contributions to the provident fund are accrued and paid to the fund manager on a monthly basis. The Company’s contributions to the provident fund amounted to $6.0 million, $5.5 million and $4.8 million during the years ended June 25, 2021, June 26, 2020 and June 28, 2019, respectively.

[0001408710-21-000034:notes:333]
The Company sponsors the Fabrinet U.S. 401(k) Retirement Plan (“401(k) Plan”), a Defined Contribution Plan under ERISA, at its subsidiaries in the United States which provides retirement benefits for eligible employees through tax deferred salary deductions. The 401(k) Plan allows employees to contribute up to 80% of their annual compensation, subject to annual contributions limits established by the Internal Revenue Service. The Company provides for a 100% match of employees’ contributions to the 401(k) Plan up to the first 6% of annual compensation. All matching contributions are made in cash and vest immediately. The Company’s matching contributions to the 401(k) Plan were $0.8 million, $0.7 million and $0.8 million during the years ended June 25, 2021, June 26, 2020 and June 28, 2019, respectively.

[0001408710-21-000034:notes:334]
Executive incentive plan and employee performance bonuses

[0001408710-21-000034:notes:335]
For the years ended June 25, 2021 and June 26, 2020, the Company maintained an executive incentive plan with quantitative objectives, based on achieving certain revenue and non-U.S. GAAP operating margin or gross margin targets. During the years ended June 25, 2021, June 26, 2020 and June 28, 2019, discretionary merit-based bonus awards were also available to Fabrinet’s non-executive employees.

[0001408710-21-000034:notes:336]
Bonus distributions to employees were $8.9 million, $8.7 million and $7.6 million for the years ended June 25, 2021, June 26, 2020 and June 28, 2019, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001408710-21-000034:notes:337]
Shareholders’ equity
Fabrinet’s authorized share capital is 500,000,000 ordinary shares, par value of $0.01 per ordinary share, and 5,000,000 preferred shares, par value of $0.01 per preferred share.

[0001408710-21-000034:notes:338]
For the year ended June 25, 2021, Fabrinet issued 277,078 ordinary shares upon the vesting of restricted share units and performance share units, net of shares withheld.

[0001408710-21-000034:notes:339]
For the year ended June 26, 2020, Fabrinet issued 241,214 ordinary shares upon the vesting of restricted share units and performance share units, net of shares withheld.

[0001408710-21-000034:notes:340]
For the year ended June 28, 2019, Fabrinet issued 507,020 ordinary shares upon the vesting of restricted share units, net of shares withheld.

[0001408710-21-000034:notes:341]
All such issued shares are fully paid.

[0001408710-21-000034:notes:342]
In August 2017, the Company’s board of directors approved a share repurchase program to permit the Company to repurchase up to $30.0 million worth of its issued and outstanding ordinary shares in the open market in accordance with applicable rules and regulations. In February 2018, May 2019 and August 2020, the Company’s board of directors approved an increase of $30.0 million, $50.0 million and 58.5 million, respectively, to the original share repurchase authorization, bringing the aggregate authorization to $168.5 million.

[0001408710-21-000034:notes:343]
During the year ended June 25, 2021, the Company repurchased 239,486 shares under the program at an average price per share (excluding other direct costs) of $78.66, totaling $18.8 million. As of June 25, 2021, the Company had a 
remaining authorization to repurchase up to $81.2 million of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001408710-21-000034:notes:344]
Accumulated other comprehensive income (loss) (“AOCI”)
The changes in AOCI for the years ended June 25, 2021 and June 26, 2020 were as follows:

[0001408710-21-000034:notes:345]
| (amount in thousands) | Unrealized Gains(Losses) onAvailable-for-saleSecurities |  | UnrealizedGains (Losses)on DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 28, 2019 | $ | 952 |  |  | $ | 32 |  |  | $ | (2,537) |  |  | $ | (833) |  |  | $ | (2,386) |  |
| Other comprehensive income before reclassification | 634 |  |  | 171 |  |  | — |  |  | (397) |  |  | 408 |  |
| Amounts reclassified from AOCI | (96) |  |  | 399 |  |  | 528 |  |  | — |  |  | 831 |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income | 538 |  |  | 570 |  |  | 528 |  |  | (397) |  |  | 1,239 |  |
| Balance as of June 26, 2020 | 1,490 |  |  | 602 |  |  | (2,009) |  |  | (1,230) |  |  | (1,147) |  |
| Other comprehensive income before reclassification | (1,003) |  |  | (4,570) |  |  | — |  |  | 585 |  |  | (4,988) |  |
| Amounts reclassified from AOCI | (179) |  |  | (536) |  |  | 584 |  |  | — |  |  | (131) |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income | (1,182) |  |  | (5,106) |  |  | 584 |  |  | 585 |  |  | (5,119) |  |
| Balance as of June 25, 2021 | $ | 308 |  |  | $ | (4,504) |  |  | $ | (1,425) |  |  | $ | (645) |  |  | $ | (6,266) |  |

[0001408710-21-000034:notes:346]
The following table presents the pre-tax amounts reclassified from AOCI into the consolidated statements of operations and comprehensive income for the years ended June 25, 2021 and June 26, 2020, respectively.

[0001408710-21-000034:notes:347]
| (amount in thousands) |  |  |  | Years ended |
| AOCI components |  | Financial statementsline item |  | June 25,2021 |  | June 26,2020 |
| Unrealized gains (losses) on available-for-sale securities |  | Interest income |  | $ | (179) |  |  | $ | (96) |  |
| Unrealized gains(losses)on derivative instruments |  | Cost of revenues |  | (966) |  |  | 2,512 |  |
| Unrealized gains(losses)on derivative instruments |  | Selling, general and administrative expenses |  | (40) |  |  | 105 |  |
| Unrealized gains(losses)on derivative instruments |  | Foreign exchange loss, net |  | 1,769 |  |  | (998) |  |
| Unrealized gains(losses)on derivative instruments |  | Interest expense |  | (1,299) |  |  | (1,220) |  |
| Retirement benefit plan – Prior service cost |  | Selling, general and administrative expenses |  | 584 |  |  | 528 |  |
| Total amounts reclassified from AOCI |  |  |  | $ | (131) |  |  | $ | 831 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001408710-21-000034:notes:348]
Commitments and contingencies
Letter of credit and bank guarantees

[0001408710-21-000034:notes:349]
As of June 25, 2021, the Company had no outstanding standby letter of credit.

[0001408710-21-000034:notes:350]
As of June 26, 2020, the Company had one outstanding standby letter of credit of 6.0 million Euros, related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. The standby letter of credit was backed by cash collateral of $7.4 million. This standby letter of credit expired on December 31, 2020 and the corresponding cash collateral was released in January 2021.

[0001408710-21-000034:notes:351]
As of June 25, 2021 and June 26, 2020, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business expenses totaling $1.6 million or Thai Baht 50.2 million and there were other bank guarantees given by a bank on behalf of our subsidiaries in the PRC and the U.K. to support their operations. As of June 25, 2021, the Company had an outstanding bank guarantee of its subsidiary in the PRC to support the subsidiary's operations totaling RMB 1.0 million. The bank guarantee was backed by cash collateral

[0001408710-21-000034:notes:352]
of $0.2 million. The bank guarantee given on behalf of our subsidiary in the U.K. was not material. As of June 26, 2020, these bank guarantees were not material.

[0001408710-21-000034:notes:353]
Purchase obligations

[0001408710-21-000034:notes:354]
Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001408710-21-000034:notes:355]
As of June 25, 2021, the Company had purchase obligations and other commitments to third parties of $918.7 million.

[0001408710-21-000034:notes:356]
Capital expenditure

[0001408710-21-000034:notes:357]
In December 2020, the Company entered into a construction contract with a local contractor for construction of a new manufacturing building at the Company’s Chonburi campus. The contract price is approximately $50.3 million.

[0001408710-21-000034:notes:358]
In June 2021, the Company entered into an agreement to purchase a parcel of land in Pathumthani, Thailand to expand the Company's Pinehurst campus. The aggregate purchase price was approximately $13.2 million or Thai Baht 418.8 million, of which the Company paid a 10% deposit on May 14, 2021 and fully paid the remainder on June 29, 2021.

[0001408710-21-000034:notes:359]
As of June 25, 2021 and prior to paying the remaining 90% of the Pathumthani land purchase price, the Company had total outstanding capital expenditure commitments to third parties of $66.6 million.

[0001408710-21-000034:notes:360]
Indemnification of directors and officers

[0001408710-21-000034:notes:361]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001408710-21-000034:notes:362]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001408710-21-000034:notes:363]
Business segments and geographic information
Operating segments are defined as components of an enterprise that engage in business activities for which discrete financial information is available that is evaluated regularly by the chief operating decision maker (the “CODM”) in deciding how to allocate resources and in assessing performance. The Company’s CODM is Fabrinet’s Chief Executive Officer. As of June 25, 2021, June 26, 2020 and June 28, 2019, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001408710-21-000034:notes:364]
Total revenues are attributed to a particular geographic area based on the bill-to-location of the Company’s customer. The Company operates in three geographic regions: North America, Asia-Pacific and Europe.

[0001408710-21-000034:notes:365]
|  | Years Ended |
| (amount in thousands) | June 25,2021 |  | June 26,2020 |  | June 28,2019 |
| North America |  |  |  |  |  |
| U.S. | 884,862 |  |  | 829,567 |  |  | 753,901 |  |
| Others (1) | 2,674 |  |  | 1,321 |  |  | 2,377 |  |
| Total revenue in North America | 887,536 |  |  | 830,888 |  |  | 756,278 |  |
| Asia-Pacific and others |  |  |  |  |  |
| Malaysia | 157,213 |  |  | 190,574 |  |  | 192,048 |  |
| India | 152,249 |  |  | 91 |  |  | 38 |  |
| Israel | 107,584 |  |  | 315 |  |  | 361 |  |
| Hong Kong | 87,235 |  |  | 92,655 |  |  | 110,732 |  |
| Japan | 69,779 |  |  | 101,588 |  |  | 122,226 |  |
| China | 51,597 |  |  | 48,192 |  |  | 62,262 |  |
| Thailand | 27,081 |  |  | 98,330 |  |  | 92,970 |  |
| Others | 15,859 |  |  | 21,178 |  |  | 27,749 |  |
| Total revenue in Asia-Pacific and others | 668,597 |  |  | 552,923 |  |  | 608,386 |  |
| Europe |  |  |  |  |  |
| Ireland | 193,103 |  |  | 110,747 |  |  | 109,890 |  |
| U.K. | 60,516 |  |  | 67,589 |  |  | 31,164 |  |
| Germany | 28,163 |  |  | 45,628 |  |  | 37,431 |  |
| Others | 41,435 |  |  | 34,061 |  |  | 41,186 |  |
| Total revenue in Europe | $ | 323,217 |  |  | $ | 258,025 |  |  | $ | 219,671 |  |
| Total revenue | $ | 1,879,350 |  |  | $ | 1,641,836 |  |  | $ | 1,584,335 |  |

[0001408710-21-000034:notes:366]
(1)Others includes revenues from external customers based in our country of domicile, the Cayman Islands, which for each year presented is $0.

[0001408710-21-000034:notes:367]
The following table presents long-lived assets by the country in which they are based:

[0001408710-21-000034:notes:368]
|  |  | Years Ended |
| (amount in thousands) |  | June 25,2021 |  | June 26,2020 |  | June 28,2019 |
| Long-Lived Assets: |  |  |  |  |  |  |
| Thailand |  | $ | 190,843 |  |  | $ | 175,738 |  |  | $ | 160,273 |  |
| U.S. |  | 27,403 |  |  | 29,507 |  |  | 31,323 |  |
| China |  | 14,977 |  |  | 14,476 |  |  | 15,014 |  |
| Israel |  | 5,271 |  |  | 5,224 |  |  | 2 |  |
| U.K. |  | 2,223 |  |  | 2,956 |  |  | 3,721 |  |
| Cayman Islands |  | 412 |  |  | 373 |  |  | 353 |  |
|  |  | 241,129 |  |  | 228,274 |  |  | 210,686 |  |

[0001408710-21-000034:notes:369]
Significant customers

[0001408710-21-000034:notes:370]
Total revenues, by percentage, from individual customers representing 10% or more of total revenues in the respective periods were as follows:

[0001408710-21-000034:notes:371]
|  | Years Ended |
|  | June 25,2021 |  | June 26,2020 |  | June 28,2019 |
| Cisco Systems Inc. (1) | 13.9 | % |  | * |  | * |
| Lumentum Operations LLC | 13.6 | % |  | 19.0 | % |  | 20.0 | % |
| Infinera Corporation | 11.6 | % |  | 10.0 | % |  | * |
| Acacia Communications Inc. | * |  | 10.2 | % |  | * |

[0001408710-21-000034:notes:372]
*Represents less than 10% of total revenues.

[0001408710-21-000034:notes:373]
(1)Inclusive of revenue from Acacia Communications, Inc. from March 1, 2021

[0001408710-21-000034:notes:374]
Accounts receivable from individual customers representing 10% or more of accounts receivable as of June 25, 2021 and June 26, 2020, respectively, were as follows:

[0001408710-21-000034:notes:375]
|  | As of June 25,2021 |  | As of June 26,2020 |
| Infinera Corporation | 18.6 | % |  | * |
| Lumentum Operations LLC | 11.6 | % |  | 20.0 | % |
| Cisco Systems Inc. (1) | 15.0 | % |  | * |
| Acacia Communications, Inc. | * |  | 13.4 | % |

[0001408710-21-000034:notes:376]
*Represents less than 10% of accounts receivable.

[0001408710-21-000034:notes:377]
(1)Includes of Acacia Communications Inc. as of June 25, 2021


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001408710-21-000034:notes:378]
Financial instruments
Objectives and significant terms and conditions

[0001408710-21-000034:notes:379]
The principal financial risks faced by the Company are foreign currency risk and interest rate risk. The Company borrows at floating rates of interest to finance its operations. A minority of sales and purchases and a majority of labor and overhead costs are entered into in foreign currencies. In order to manage the risks arising from fluctuations in currency exchange rates, the Company uses derivative instruments. Trading for speculative purposes is prohibited under Company policies.

[0001408710-21-000034:notes:380]
The Company enters into short-term foreign currency forward and option contracts to manage foreign currency exposures associated with certain assets, liabilities and other forecasted foreign currency transactions and may designate these instruments as hedging instruments. The foreign currency forward and option contracts generally have maturities of

[0001408710-21-000034:notes:381]
up to twelve months. All foreign currency exchange contracts are recognized on the consolidated balance sheets at fair value. Gain or loss on the Company’s derivative instruments generally offset the assets, liabilities under master netting arrangement and transactions economically hedged.

[0001408710-21-000034:notes:382]
Foreign currency risk

[0001408710-21-000034:notes:383]
The Company operates internationally and is exposed to foreign exchange risk arising from various currency exposures primarily with respect to the Thai baht, RMB and Pound Sterling ("GBP").

[0001408710-21-000034:notes:384]
As of June 25, 2021 and June 26, 2020, the Company had outstanding foreign currency assets and liabilities as follows:

[0001408710-21-000034:notes:385]
|  | As of June 25, 2021 |  | As of June 26, 2020 |
| (amount in thousands) | Currency |  | $ |  | Currency |  | $ |
| Assets |  |  |  |  |  |  |  |
| Thai baht | 1,472,249 |  |  | $ | 46,312 |  |  | 667,955 |  |  | $ | 21,617 |  |
| RMB | 98,056 |  |  | 15,145 |  |  | 158,060 |  |  | 22,402 |  |
| GBP | 5,111 |  |  | 7,119 |  |  | 6,220 |  |  | 7,726 |  |
| Total |  |  | $ | 68,576 |  |  |  |  | $ | 51,745 |  |
| Liabilities |  |  |  |  |  |  |  |
| Thai baht | 2,250,514 |  |  | $ | 70,793 |  |  | 2,102,392 |  |  | $ | 68,039 |  |
| RMB | 40,112 |  |  | 6,195 |  |  | 42,586 |  |  | 6,036 |  |
| GBP | 2,656 |  |  | 3,699 |  |  | 1,545 |  |  | 1,919 |  |
| Total |  |  | $ | 80,687 |  |  |  |  | $ | 75,994 |  |

[0001408710-21-000034:notes:386]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. The Company manages its exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of June 25, 2021 there were $130.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 26, 2020, there were $125.0 million of foreign currency forward contracts and  $1.0 million of foreign currency option contracts outstanding on the Thai baht payables.

[0001408710-21-000034:notes:387]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses and other payables. As of June 25, 2021 and June 26, 2020, there were no derivative contracts denominated in RMB.

[0001408710-21-000034:notes:388]
The GBP assets represent cash, trade accounts receivable, inventory and property, plant and equipment. The GBP liabilities represent trade accounts payable. As of June 25, 2021 and June 26, 2020, there were no derivative contracts denominated in GBP.

[0001408710-21-000034:notes:389]
For fiscal year 2021, fiscal year 2020, and fiscal year 2019, the Company recorded unrealized loss of $1.5 million, unrealized loss of $1.2 million, and unrealized gain of $4.8 million, respectively, related to derivatives that are not designated as hedging instruments in its consolidated statements of operations and comprehensive income.

[0001408710-21-000034:notes:390]
Interest Rate Risk

[0001408710-21-000034:notes:391]
The Company’s principal interest bearing assets are time deposits and short-term investments with maturities of three years or less held with high quality financial institutions. The Company’s principal interest bearing liabilities are bank loans which bear interest at floating rates.

[0001408710-21-000034:notes:392]
The Company entered into interest rate swap agreements (the “Swap Agreements”) to manage this risk and increase the profile of the Company’s debt obligation. The terms of the Swap Agreements allow the Company to effectively convert the floating interest rate to a fixed interest rate. This locks the variable in interest expenses associated with our floating rate borrowings and results in fixed interest expenses, which is unsusceptible to market rate increase. The Company designated the Swap Agreements as a cash flow hedge, and they qualify for hedge accounting because the hedges are highly effective. While the Company intend to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in our earnings. From September 27, 2019, any gains or losses related to these outstanding interest rate swaps will be recorded in accumulated other comprehensive income in the consolidated balance sheets, with subsequent reclassification to interest expense when settled.
