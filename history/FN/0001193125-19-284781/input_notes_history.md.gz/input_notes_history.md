# FN note change history — 0001193125-19-139609 → 0001193125-19-284781


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-11-05):
[0001193125-19-284781:note_history:1]
| 18. | Commitments and contingencies |
  (was, 2019-05-07, similarity 0.9737):
[0001193125-19-139609:note_history:1]
|  | 16. | Commitments and contingencies |

- added (2019-11-05):
[0001193125-19-284781:note_history:2]
Letter of credit and Bank guarantees

- added (2019-11-05):
[0001193125-19-284781:note_history:3]
As of September 27, 2019,

- added (2019-11-05):
[0001193125-19-284781:note_history:4]
the Company had 
two
 outstanding standby letters of credit 
o
f

- added (2019-11-05):
[0001193125-19-284781:note_history:5]
16.2

- added (2019-11-05):
[0001193125-19-284781:note_history:6]
million Euros and

- added (2019-11-05):
[0001193125-19-284781:note_history:7]
one outstanding standby letter of credit of
 6.0
 million

- added (2019-11-05):
[0001193125-19-284781:note_history:8]
Euros, respectively,

- added (2019-11-05):
[0001193125-19-284781:note_history:9]
related to the Company’s support of a customer

- added (2019-11-05):
[0001193125-19-284781:note_history:10]
’s

- added (2019-11-05):
[0001193125-19-284781:note_history:11]
transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand.

- added (2019-11-05):
[0001193125-19-284781:note_history:12]
T
he
se
 standby letters of credit were backed by cash collateral of $
22.2
 million and $
7.4
 million, respectively.

- added (2019-11-05):
[0001193125-19-284781:note_history:13]
As of June 28, 2019, the Company had one outstanding standby letter of credit of 6.0 million Euros related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. The standby letter of credit was backed by cash collateral of $7.4 million.

- added (2019-11-05):
[0001193125-19-284781:note_history:14]
As of September 27, 2019 and June 28, 2019, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business amounting to $1.6 million and $1.6 million, respectively

- added (2019-11-05):
[0001193125-19-284781:note_history:15]
, and there were other bank guarantees given by a bank on behalf of our subsidiaries in

- added (2019-11-05):
[0001193125-19-284781:note_history:16]
China

- added (2019-11-05):
[0001193125-19-284781:note_history:17]
and

- added (2019-11-05):
[0001193125-19-284781:note_history:18]
the United Kingdom to

- added (2019-11-05):
[0001193125-19-284781:note_history:19]
support their operations of $70 thousand and $25

- added (2019-11-05):
[0001193125-19-284781:note_history:20]
thousand,

- added (2019-11-05):
[0001193125-19-284781:note_history:21]
respectively.

- changed (2019-11-05):
[0001193125-19-284781:note_history:22]
Purchase obligations represent legally-binding commitments to p
u
rchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2019-05-07, similarity 0.9964):
[0001193125-19-139609:note_history:22]
Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- changed (2019-11-05):
[0001193125-19-284781:note_history:23]
As of September 27, 2019, the Company had an outstanding commitment to third parties of $8.2 million.
  (was, 2019-05-07, similarity 0.9451):
[0001193125-19-139609:note_history:23]
As of March 29, 2019, the Company had an outstanding commitment to third parties of $8.6 million.

- changed (2019-11-05):
[0001193125-19-284781:note_history:24]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the
  (was, 2019-05-07, similarity 0.6348):
[0001193125-19-139609:note_history:24]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

- added (2019-11-05):
[0001193125-19-284781:note_history:25]
consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

- removed (2019-11-05):
[0001193125-19-139609:note_history:26]
Bank guarantees

- removed (2019-11-05):
[0001193125-19-139609:note_history:27]
As of March 29, 2019 and June 29, 2018, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business amounting to $1.6 million and $1.5 million, respectively.

- removed (2019-11-05):
[0001193125-19-139609:note_history:28]
Operating lease commitments

- removed (2019-11-05):
[0001193125-19-139609:note_history:29]
The Company leases a portion of its capital equipment, vehicles, and certain land and buildings for its facilities in Thailand, the Cayman Islands, China, the United States and the United Kingdom under operating lease arrangements that expire in various years through 2023. Rental expense under these operating leases amounted to $1.4 million and $1.3 million for the nine months ended March 29, 2019 and March 30, 2018, respectively.

- removed (2019-11-05):
[0001193125-19-139609:note_history:30]
As of March 29, 2019, the future minimum lease payments due under non-cancelable operating leases during each fiscal year were as follows:

- removed (2019-11-05):
[0001193125-19-139609:note_history:31]
| (amount in thousands) |  |  |  |
| 2019 (remaining three months) |  | $ | 450 |  |
| 2020 |  |  | 1,739 |  |
| 2021 |  |  | 1,336 |  |
| 2022 |  |  | 1,208 |  |
| 2023 |  |  | 1,182 |  |
| Thereafter |  |  | 227 |  |
| Total minimum operating lease payments |  | $ | 6,142 |  |

- removed (2019-11-05):
[0001193125-19-139609:note_history:32]
Capital lease commitments

- removed (2019-11-05):
[0001193125-19-139609:note_history:33]
In connection with the acquisition of Fabrinet UK, the Company assumed the capital lease commitments of several machines and equipment, with various expiration dates until September 2020. The equipment can be purchased at the determined prices upon expiration of such contracts.

- removed (2019-11-05):
[0001193125-19-139609:note_history:34]
As of March 29, 2019, the future minimum lease payments due under non-cancelable capital leases during each fiscal year were as follows:

- removed (2019-11-05):
[0001193125-19-139609:note_history:35]
| (amount in thousands) |  |  |  |
| 2019 (remaining three months) |  | $ | 110 |  |
| 2020 |  |  | 410 |  |
| 2021 |  |  | 105 |  |
| Total minimum capital lease payments |  | $ | 625 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-11-05):
[0001193125-19-284781:note_history:36]
| 2. | Accounting policies |
  (was, 2019-05-07, similarity 0.9643):
[0001193125-19-139609:note_history:36]
|  | 2. | Accounting policies |

- changed (2019-11-05):
[0001193125-19-284781:note_history:37]
The accompanying unaudited
 condensed consolidated financial statements for Fabrinet as of September 27, 2019 and for the three months ended September 27, 2019 and September 28, 2018 includes normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 
10-K
 for the year ended June 28, 2019.
  (was, 2019-05-07, similarity 0.9452):
[0001193125-19-139609:note_history:37]
The accompanying condensed consolidated financial statements for Fabrinet as of March 29, 2019 and for the three and nine months ended March 29, 2019 and March 30, 2018 include normal recurring adjustments, necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 29, 2018.

- changed (2019-11-05):
[0001193125-19-284781:note_history:38]
The balance sheet as of June 28, 2019 has been derived from the audited financial statements at that date but does not include all of the information and footnotes required by U.S. GAAP for complete financial statements.
  (was, 2019-05-07, similarity 0.7504):
[0001193125-19-139609:note_history:38]
The balance sheet as of June 29, 2018 has been derived from the audited financial statements at that date but does not include all of the information and footnotes required by U.S. GAAP for complete financial statements. The results for the three and nine months ended March 29, 2019 may not be indicative of results for the year ending June 28, 2019 or any future periods.

- added (2019-11-05):
[0001193125-19-284781:note_history:39]
The results for the three months ended September 27, 2019 may not be indicative of results for the year ending June 26, 2020 or any future periods.

- changed (2019-11-05):
[0001193125-19-284781:note_history:40]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements, and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that estimates or assumptions prove to 
be 
differ
ent
 from actual results, adjustments will be made in subsequent periods to reflect more current information.
  (was, 2019-05-07, similarity 0.9893):
[0001193125-19-139609:note_history:40]
The preparation of the Company’s condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements, and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that estimates or assumptions prove to differ from actual results, adjustments will be made in subsequent periods to reflect more current information.

- added (2019-11-05):
[0001193125-19-284781:note_history:41]
The Company utilizes a

- added (2019-11-05):
[0001193125-19-284781:note_history:42]
52-53

- changed (2019-11-05):
[0001193125-19-284781:note_history:43]
week fiscal year ending on the Friday in June closest to June 30. The three months ended September 27, 2019 and September 28, 2018 each consisted of 13 weeks. Fiscal year 2020 will be comprised of 52 weeks and will end on June 26, 2020.
  (was, 2019-05-07, similarity 0.7181):
[0001193125-19-139609:note_history:43]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended March 29, 2019 and March 30, 2018 each consisted of 13 weeks. The nine months ended March 29, 2019 and March 30, 2018 each consisted of 39 weeks. Fiscal year 2019 will be comprised of 52 weeks and will end on June 28, 2019.

- added (2019-11-05):
[0001193125-19-284781:note_history:44]
Except for the adoption of the new lease accounting standard and the derivatives and hedging standard described below, the Company has consistently applied the accounting policies to all periods presented in these unaudited condensed consolidated financial statements.

- changed (2019-11-05):
[0001193125-19-284781:note_history:45]
Adoption of New Accounting Standard
s
  (was, 2019-05-07, similarity 0.9722):
[0001193125-19-139609:note_history:45]
Adoption of New Accounting Standard

- added (2019-11-05):
[0001193125-19-284781:note_history:46]
On June 29, 2019, the Company adopted the new lease accounting standard, Accounting Standards Codification Topic 842 (“ASC 842”), which provides guidance for the recognition and disclosure of lease arrangements. The Company adopted ASC 842 using the modified retrospective transition approach. Accordingly, the Company’s comparative financial statements as of June 28, 2019 have not been adjusted. ASC 842 also provides practical expedients for the Company’s ongoing accounting. The Company elected the short-term lease recognition exemption for its operating leases with a term of less than 12 months, which will not require recognition of right of use (“ROU”) assets or lease liabilities for these leases.

- added (2019-11-05):
[0001193125-19-284781:note_history:47]
For periods prior to adoption of ASC 842, the Company is required to present disclosures in accordance with ASC Topic 840. The following disclosure provides the future minimum lease payments due under 
non-cancelable
 operating leases as of June 28, 2019:

- added (2019-11-05):
[0001193125-19-284781:note_history:48]
| (amount in thousands) |  |  |  |
| 2020 |  | $ | 1,746 |  |
| 2021 |  |  | 1,342 |  |
| 2022 |  |  | 1,219 |  |
| 2023 |  |  | 1,172 |  |
| Thereafter |  |  | 230 |  |
| Total future minimum operating lease payments |  | $ | 5,709 |  |

- added (2019-11-05):
[0001193125-19-284781:note_history:49]
The most significant impact of the adoption of ASC 842 was the recognition of ROU assets and lease liabilities for operating leases with a term of greater than 12 months, while the accounting for finance leases will remain substantially unchanged. See Note 10 for further details.

- added (2019-11-05):
[0001193125-19-284781:note_history:50]
On June 29, 2019, the Company also adopted Accounting Standards Update (“ASU”) 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. ASU 2017-12 simplifies existing hedge accounting guidance in order to better portray in financial statements the economic impact of risk management activities in the financial statements, including eliminating the separate measurement and presentation of hedge ineffectiveness. Prior to the adoption of ASU 2017-12, the Company 
wa
s required to separately measure and reflect the amount by which the hedging instrument did not offset the changes in the fair value or cash flows of hedged items, and to record the ineffective portion as earnings. Upon the adoption of ASU 2017-12, the Company is no longer recognize
s
 hedge ineffectiveness as earnings, but instead record
s
 the entire changes in the fair value of the hedged instruments as other comprehensive income. 
Amounts recorded as other comprehensive income are subsequently reclassified to earnings in the same income statement line item that is used to present the earnings effect of the hedged item when the hedged item affects earnings
. See Note 6 for further details.

- changed (2019-11-05):
[0001193125-19-284781:note_history:51]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash and cash equivalents, short-term investments, derivatives
,
 accounts receivable
  (was, 2019-05-07, similarity 0.9442):
[0001193125-19-139609:note_history:51]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash and cash equivalents, short-term investments, derivatives, accounts receivable and contract assets.

- added (2019-11-05):
[0001193125-19-284781:note_history:52]
and contract assets

- added (2019-11-05):
[0001193125-19-284781:note_history:53]
.

- changed (2019-11-05):
[0001193125-19-284781:note_history:54]
Cash, cash equivalents and short-term investments are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. The Company seeks to mitigate its credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties. The Company limits its 
short-term 
investments in marketable securities to securities with a maturity not in excess of three years and securities that are rated A1, 
P-1,
 F1, or better.
  (was, 2019-05-07, similarity 0.9197):
[0001193125-19-139609:note_history:54]
Cash, cash equivalents, and short-term investments are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. The Company seeks to mitigate its credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties. The Company limits its investments in short-term investments to term deposits and marketable securities to securities with a maturity not in excess of three years, and all marketable securities that the Company invests in are rated A1, P-1, F1, or better.

- added (2019-11-05):
[0001193125-19-284781:note_history:55]
The Company enters into derivative contracts with financial institutions with reputable credit and monitors the credit profiles of these counterparties.

- added (2019-11-05):
[0001193125-19-284781:note_history:56]
In May 2019, the Financial Accounting Standards Board (“FASB”) issued ASU 
2019-05,
 “Financial Instruments – Credit Losses (Topic 326): Targeted Transition Relief.” The amendments in ASU 
2019-05
 provide entities that have certain instruments within the scope of Subtopic 
326-20
 (“Financial Instruments—Credit Losses—Measured at Amortized Cost”) with an option to irrevocably elect the fair value option in Subtopic 
825-10
 (“Financial Instruments—Overall”), applied on an 
instrument-by-instrument
 basis for eligible instruments, upon adoption of Topic 326. The fair value option election does not apply to 
held-to-maturity
 debt securities. An entity that elects the fair value option should subsequently apply the guidance in Subtopics 
820-10
 (“Fair Value Measurement—Overall”) and 
825-10.
 For public business entities, this update is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. This ASU will be effective for the Company in the first quarter of fiscal 2021. Early adoption is permitted. The Company does not expect this update will impact its condensed consolidated financial statements.

- added (2019-11-05):
[0001193125-19-284781:note_history:57]
In April 2019, 
the 
FASB issued ASU 
2019-04,
 “Codification Improvements to Topic 326, Financial Instruments—Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments.” The amendments in ASU 
2019-04
 apply to all reporting entities within the scope of the affected accounting guidance. For public business entities, this update is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. This ASU will be effective for the Company in the first quarter of fiscal 2021. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.

- changed (2019-11-05):
[0001193125-19-284781:note_history:58]
In August 2018, the FASB issued ASU 
2018-13,
 “Fair Value Measurement (Topic 820), Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement.” ASU 
2018-13
 is intended to improve the effectiveness of disclosures in the notes to the financial statements, including (1) the development of a framework that promotes consistent decisions by the FASB about disclosure requirements and (2) the appropriate exercise of discretion by reporting entities. The amendment modifies the disclosure requirements on transferring between level 1 and level 2 and valuation processes of level 3 fair value measurements. This update is effective for all entities for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years, beginning after December 15, 2019. This ASU will be effective for the Company in the first quarter of fiscal 2021. The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.
  (was, 2019-05-07, similarity 0.6613):
[0001193125-19-139609:note_history:58]
In August 2018, the FASB issued ASU 2018-13, “Fair Value Measurement (Topic 820), Disclosure Framework – Changes to the Disclosure Requirements for Fair Value Measurement.” This ASU is intended to improve the effectiveness of disclosures in the notes to the financial statements including 1) the development of a framework that promotes consistent decisions by the FASB about disclosure requirements and 2) the appropriate exercise of discretion by reporting entities. The amendment modifies the disclosure requirements on transferring between level 1 and level 2 and valuation processes of level 3 fair value measurements. The amendments in this update are effective for all entities for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company is currently evaluating the impact of the adoption of this update on its consolidated financial 
statements.

- added (2019-11-05):
[0001193125-19-284781:note_history:59]
In January 2017, the FASB issued ASU 2017-04, “Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.” ASU 2017-04 modified the concept of impairment assessment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. Public companies that are SEC filers should adopt the amendment for annual and any interim goodwill impairment tests in fiscal years beginning after December 15, 2019. Early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017. This ASU will be effective for the Company in the first quarter of fiscal 2021. The Company does not expect this update will impact its condensed consolidated financial statements.

- removed (2019-11-05):
[0001193125-19-139609:note_history:60]
Except for the adoption of the new revenue recognition accounting standard described below and as disclosed in Note 3—Revenues, the Company has consistently applied the accounting policies to all periods presented in these condensed consolidated financial statements.

- removed (2019-11-05):
[0001193125-19-139609:note_history:61]
On June 30, 2018, the Company adopted Revenue from Contracts with Customers (Topic 606), which created Accounting Standards Codification Topic 606 (“ASC 606”), using the modified retrospective method applied to those contracts which were not completed as of June 29, 2018. The modified retrospective method requires the Company to recognize the cumulative effect of the adoption of ASC 606, for all contracts with customers, to the opening balance of equity at June 30, 2018. Accordingly, the Company’s comparative financial information as of June 29, 2018 has not been adjusted and continues to be reported under ASC 605, Revenue Recognition (“ASC 605”).

- removed (2019-11-05):
[0001193125-19-139609:note_history:62]
The cumulative effect adjustment recorded was based on the timing difference of revenue recognition between ASC 605 and ASC 606 related to certain manufacturing contracts with vendor-managed inventory arrangements. Under ASC 605, revenue for such contracts was recognized at the earlier of when the inventory was consumed by the customers or if not consumed, on the expiration of time specified in the contract. On adoption of ASC 606, revenue is recognized when inventory is shipped to customers.

- removed (2019-11-05):
[0001193125-19-139609:note_history:63]
The following table shows the impact of adoption of ASC 606 on the adoption date of June 29, 2018 on the condensed consolidated balance sheets:

- removed (2019-11-05):
[0001193125-19-139609:note_history:64]
Condensed Consolidated Balance Sheets

- removed (2019-11-05):
[0001193125-19-139609:note_history:65]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | Balance atJune 29, 2018 |  |  | Adjustment |  |  | Balance atJune 30, 2018 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract assets |  | $ | — |  |  | $ | 9,877 | (1) |  | $ | 9,877 |  |
| Inventory, net |  | $ | 257,687 |  |  | $ | (8,672 | )(2) |  | $ | 249,015 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 632,423 |  |  | $ | 1,205 | (3 |  | $ | 633,628 |  |

- removed (2019-11-05):
[0001193125-19-139609:note_history:66]
|  | (1) | Majority of adjustment relates to certain manufacturing contracts with vendor-managed inventory arrangements for which revenue was recognized on shipment. |

- removed (2019-11-05):
[0001193125-19-139609:note_history:67]
|  | (2) | Adjustment relates to reduction of finished goods inventory for certain vendor-managed inventory arrangements. |

- removed (2019-11-05):
[0001193125-19-139609:note_history:68]
|  | (3) | Adjustment relates to cumulative effect adjustment upon adoption of ASC 606. |

- removed (2019-11-05):
[0001193125-19-139609:note_history:69]
In March 2019, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2019-01, “Leases (Topic 842), Codification Improvements.” This ASU provided guidance transition disclosure in the annual period in which a change in accounting principle is made. For public business entities, this update is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its consolidated financial statements.

- removed (2019-11-05):
[0001193125-19-139609:note_history:70]
In July 2018, the FASB issued ASU 2018-11, “Leases (Topic 842), Target Improvements.” This ASU provided guidance on comparative reporting requirements for initial adoption. This ASU also provides additional guidance for lessors, on separating lease and non-lease components in a contract and allocating the consideration in the contract to the separate components. For public business entities, this update is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its consolidated financial statements.

- removed (2019-11-05):
[0001193125-19-139609:note_history:71]
In July 2018, the FASB issued ASU 2018-10, “Codification Improvements to Topic 842, Leases.” The amendment in this update affects narrow aspects of the guidance issued in the amendments in update 2016-02 on various matters. For public business entities, this update is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its consolidated financial statements.

- removed (2019-11-05):
[0001193125-19-139609:note_history:72]
In January 2017, the FASB issued ASU 2017-04, “Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.” This amendment modified the concept of impairment assessment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. Public companies that are SEC filers should adopt the amendment for annual and any interim goodwill impairment tests in fiscal years beginning after December 15, 2019. Early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017. The Company does not expect the amendments will impact its consolidated financial statements.

- removed (2019-11-05):
[0001193125-19-139609:note_history:73]
In February 2016, the FASB issued ASU 2016-02, “Lease (Topic 842).” The core principle of Topic 842 is that a lessee should recognize the lease assets and liabilities that arise from leases in the statement of financial position. For public business entities, this update is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early application is permitted. The Company is currently evaluating the impact of the adoption of this update on its consolidated financial statements.

- removed (2019-11-05):
[0001193125-19-139609:note_history:74]
New Accounting Pronouncements – adopted by the Company

- removed (2019-11-05):
[0001193125-19-139609:note_history:75]
In November 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2017-14, “Income Statement – Reporting Comprehensive Income (Topic 220), Revenue Recognition (Topic 605), and Revenue from Contracts with Customers (Topic 606): Amendments to SEC Paragraphs Pursuant to the Staff Accounting Bulletin (“SAB”) No. 116 and SEC Release No. 33-10403”. This ASU amended, superseded and added certain SEC paragraphs in Topic 220, Topic 605 and Topic 606 to reflect the August 2017 issuance of SEC Staff Accounting Bulletin (SAB) 116 and SEC Release No. 33-10403. The SEC staff issued SAB 116 to align its revenue guidance with Accounting Standards Codification (ASC) 606. For public business entities, this update is effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years. Early application is permitted. The Company adopted this standard along with the implementation of ASC 606 effective June 30, 2018 with immaterial impact to the unaudited condensed consolidated financial statements.

- removed (2019-11-05):
[0001193125-19-139609:note_history:76]
In September 2017, the FASB issued ASU 2017-13, “Revenue Recognition (Topic 605), Revenue from Contracts with Customers (Topic 606), Leases (Topic 840), and Leases (Topic 842): Amendments to SEC Paragraphs Pursuant to the Staff Announcement at the July 20, 2017 EITF Meeting and Rescission of Prior SEC Staff Announcements and Observer Comments.” The amendment delays the mandatory adoption of Topic 606 and Topic 842 for certain entities, revises the guidance related to performance-based incentive fees in Topic 605 and revises the guidance related to leases in Topic 840 and Topic 842. The revisions to the lease guidance eliminate language specific to certain sale-leaseback arrangements, guarantees of lease residual assets and loans made by lessees to owner-lessors. Also included is an amendment to Topic 842 to retain the guidance in Topic 840 covering the impact of changes in tax rates on investments in leveraged leases. This guidance, which is effective immediately, generally relates to the adoption of Topic 606 and Topic 842. The Company adopted this standard along with the implementation of ASC 606 effective June 30, 2018 with immaterial impact to the unaudited condensed consolidated financial statements.

- removed (2019-11-05):
[0001193125-19-139609:note_history:77]
In January 2017, the FASB issued ASU 2017-03, “Accounting Changes and Error Corrections (Topic 250) and Investments – Equity Method and Joint Ventures (Topic 323): Accounting for Investments in Qualified Affordable Housing Projects: Amendments to SEC Paragraphs Pursuant to Staff Announcements at the September 22, 2016 and November 17, 2016 EITF Meetings.” The amendment provides guidance to the Company in relation to the disclosure of the impact that ASU 2014-09, ASU 2016-02 and ASU 2016-13 will have on the Company’s financial statements when adopted. The Company adopted this standard along with the implementation of ASC 606 effective June 30, 2018 with immaterial impact to the unaudited condensed consolidated financial statements.

- removed (2019-11-05):
[0001193125-19-139609:note_history:78]
In August 2016, the FASB issued ASU 2016-15, “Classification of Certain Cash Receipts and Cash Payments (a consensus of the Emerging Issues Task Force).” The amendments in this ASU provide guidance on the presentation of certain cash receipts and cash payments in the statement of cash flows in order to reduce diversity in existing practice. The amendments in ASU 2016-15 are effective for public business entities for fiscal years beginning after December 15, 2017, and interim periods within those fiscal years. Early adoption is permitted, including adoption in an interim period. The Company adopt this new update effective June 30, 2018 with no impact to the unaudited condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-11-05):
[0001193125-19-284781:note_history:79]
The Company’s total borrowings, including current
 portion

- added (2019-11-05):
[0001193125-19-284781:note_history:80]
and 
non-current
 portion of

- changed (2019-11-05):
[0001193125-19-284781:note_history:81]
long-term borrowings, consisted of the following:
  (was, 2019-05-07, similarity 0.6323):
[0001193125-19-139609:note_history:81]
The Company’s total borrowings, including short-term and long-term borrowings, consisted of the following:

- added (2019-11-05):
[0001193125-19-284781:note_history:82]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  | Maturity |  |  | As ofSeptember 27,2019 |  |  | As ofJune 28,2019 |  |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  |  |  |  | $ | 12,188 |  |  | $ | 3,250 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  |  |  |  |  | (31 | ) |  |  | — |  |
| Long-term borrowings, current portion, net |  |  |  |  |  |  |  | $ | 12,157 |  |  |  | 3,250 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1-month LIBOR +1.50% per annum (1) |  | Repayable in quarterly installments |  |  | June 2023 |  |  | $ | — |  |  | $ | 60,938 |  |
| 3-month LIBOR +1.35% per annum (1) |  | Repayable in quarterly installments |  |  | June 2024 |  |  |  | 60,938 |  |  |  | — |  |
| Less: Current portion |  |  |  |  |  |  |  |  | (12,188 | ) |  |  | (3,250 | ) |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  |  |  |  |  | (119 | ) |  |  | — |  |
| Long-term borrowings, non-current portion, net |  |  |  |  |  |  |  | $ | 48,631 |  |  | $ | 57,688 |  |

- added (2019-11-05):
[0001193125-19-284781:note_history:83]
| (1) | We have entered into interest rate swaps that effectively fix a series of our future interest payments on our term loans. Refer to Note 6. |

- changed (2019-11-05):
[0001193125-19-284781:note_history:84]
The movements of long-term borrowings for the three months ended September 27, 2019 and September 28, 2018 were as follows:
  (was, 2019-05-07, similarity 0.8704):
[0001193125-19-139609:note_history:84]
The movements of long-term borrowing for the nine months ended March 29, 2019 and March 30, 2018 were as follows:

- added (2019-11-05):
[0001193125-19-284781:note_history:85]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 27, 2019 |  |  | September 28, 2018 |  |
| Opening balance |  | $ | 60,938 |  |  | $ | 64,188 |  |
| Borrowings during the period |  |  | 60,938 |  |  |  | — |  |
| Repayments during the period |  |  | (60,938 | ) |  |  | (813 | ) |
| Closing balance |  | $ | 60,938 |  |  | $ | 63,375 |  |

- changed (2019-11-05):
[0001193125-19-284781:note_history:86]
As of September 27, 2019, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2019-05-07, similarity 0.9447):
[0001193125-19-139609:note_history:86]
As of March 29, 2019, future maturities of long-term borrowing during each fiscal year were as follows:

- changed (2019-11-05):
[0001193125-19-284781:note_history:87]
| (amount in thousands) |  |  |  |
| 2020 (remaining nine months) |  | $ | 9,140 |  |
| 2021 |  |  | 12,188 |  |
| 2022 |  |  | 15,234 |  |
| 2023 |  |  | 12,188 |  |
| 2024 |  |  | 12,188 |  |
| Total |  | $ | 60,938 |  |
  (was, 2019-05-07, similarity 0.9781):
[0001193125-19-139609:note_history:87]
| (amount in thousands) |  |  |  |
| 2019 (remaining three months) |  | $ | 813 |  |
| 2020 |  |  | 3,250 |  |
| 2021 |  |  | 3,250 |  |
| 2022 |  |  | 3,250 |  |
| 2023 |  |  | 51,187 |  |
| Total |  | $ | 61,750 |  |

- changed (2019-11-05):
[0001193125-19-284781:note_history:88]
Credit facility agreements:
  (was, 2019-05-07, similarity 0.7556):
[0001193125-19-139609:note_history:88]
Credit facilities:

- added (2019-11-05):
[0001193125-19-284781:note_history:89]
Bank of Ayudhya Public Company Limited

- added (2019-11-05):
[0001193125-19-284781:note_history:90]
On August 20, 2019, Fabrinet Thailand (the “Borrower”), and 
the 
Bank entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai Baht

- added (2019-11-05):
[0001193125-19-284781:note_history:91]
(approximately $
3.6
 million based on the applicable exchange rate as of September 
27
, 
2019)
 and $
160.9

- added (2019-11-05):
[0001193125-19-284781:note_history:92]
million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

- added (2019-11-05):
[0001193125-19-284781:note_history:93]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a Term Loan Agreement pursuant to which the Borrower 
drew down
 on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company’s 
pre-existing
 credit facility agreement between the Company and Bank of America, N.A.

- added (2019-11-05):
[0001193125-19-284781:note_history:94]
The term loan accrues interest at 
3-month LIBOR plus 1.35%
 and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan matures on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be 
re-borrowed. 
 During the three months ended September 27, 2019, the Company recorded $0.2 
million
 of interest expense in connection with this term loan.

- added (2019-11-05):
[0001193125-19-284781:note_history:95]
Any borrowings under the Credit Facility Agreement, including those borrowing under the Term Loan Agreement are guaranteed by

- added (2019-11-05):
[0001193125-19-284781:note_history:96]
Fabrinet

- added (2019-11-05):
[0001193125-19-284781:note_history:97]
and secured by land and buildings in Pathumthani and Chonburi Provinces owned by the Borrower in Thailand.

- added (2019-11-05):
[0001193125-19-284781:note_history:98]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt to equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. At September 27, 2019, the Company was in compliance with all of its covenants under the Term Loan Agreement
.

- added (2019-11-05):
[0001193125-19-284781:note_history:99]
The events of default in the Term Loan Agreement include failure to pay amounts due under the Term Loan Agreement or the related finance documents when due, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

- added (2019-11-05):
[0001193125-19-284781:note_history:100]
At September 27, 2019, there was $
60.9 
million outstanding under the term loan.

- added (2019-11-05):
[0001193125-19-284781:note_history:101]
Bank of America, N.A.

- added (2019-11-05):
[0001193125-19-284781:note_history:102]
On May 22, 2014, the Company and

- added (2019-11-05):
[0001193125-19-284781:note_history:103]
a
 consortium

- added (2019-11-05):
[0001193125-19-284781:note_history:104]
of

- added (2019-11-05):
[0001193125-19-284781:note_history:105]
banks

- added (2019-11-05):
[0001193125-19-284781:note_history:106]
entered into a syndicated senior credit facility agreement

- added (2019-11-05):
[0001193125-19-284781:note_history:107]
led by Bank of America

- added (2019-11-05):
[0001193125-19-284781:note_history:108]
(the “Bank of America Facility Agreement”). The Bank of America Facility Agreement provided for a $200.0 million credit line, comprised of a $150.0 million revolving loan facility and a $50.0 million delayed draw term loan facility.

- added (2019-11-05):
[0001193125-19-284781:note_history:109]
From time to time, we amended the Bank of America Facility Agreement, before repaying all outstanding amounts under the agreement and terminating such agreement on 
September 10, 2019
.

- added (2019-11-05):
[0001193125-19-284781:note_history:110]
The most recent amendment on June 4, 2018, (i)

- added (2019-11-05):
[0001193125-19-284781:note_history:111]
reduced

- added (2019-11-05):
[0001193125-19-284781:note_history:112]
the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) refinanced the outstanding amounts under the revolving loan and term loan facilities into a $65.0 million term loan which was to be repaid in quarterly installments through the maturity date of June 4, 2023; and (iii) reduced the interest rate margins and commitment fees. The term loan bore interest, at the Company’s option, at a rate per annum equal to a 
LIBOR rate plus a spread of 1.50% to 2.25%
, or a 
base rate plus a spread of 0.50% to 1.25%
. During the three months ended September 27, 2019 and September 28, 2018, the Company recorded $0.5 
million 
and $
0.7

- added (2019-11-05):
[0001193125-19-284781:note_history:113]
million
, respectively, of interest expense in connection with this term loan.

- added (2019-11-05):
[0001193125-19-284781:note_history:114]
During the three months ended September 27, 2019, the Company fully repaid $61.0 million in principal, accrued interest and other fees under the agreement. The early termination of this agreement did not trigger any early termination fees. At September 27, 2019, there were no amounts outstanding under the Bank of America Facility Agreement. At June 28, 2019, there was $60.9 million outstanding under the Bank of America Facility Agreement, related to the term loan.

- removed (2019-11-05):
[0001193125-19-139609:note_history:115]
| Rate (1) |  | Conditions |  |  | Maturity |  |  | As ofMarch 29,2019 |  |  | As ofJune 29,2018 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current portion of long-term borrowing |  |  | $ | 3,250 |  |  | $ | 3,250 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.50% per annum |  |  | Repayable in quarterlyinstallments |  |  |  | June 2023 |  |  | $ | 61,750 |  |  | $ | 64,188 |  |
|  |  |  |  |  |  |  |  | 61,750 |  |  | 64,188 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (3,250 | ) |  |  | (3,250 | ) |
| Non-current portion of long-term borrowing |  |  |  |  |  |  |  |  |  | $ | 58,500 |  |  | $ | 60,938 |  |

- removed (2019-11-05):
[0001193125-19-139609:note_history:116]
| (1) | LIBOR is London Interbank Offered Rate. |

- removed (2019-11-05):
[0001193125-19-139609:note_history:117]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 29,2019 |  |  | March 30,2018 |  |
| Opening balance |  | $ | 64,188 |  |  | $ | 36,400 |  |
| Repayments during the period |  |  | (2,438 | ) |  |  | (10,200 | ) |
| Closing balance |  | $ | 61,750 |  |  | $ | 26,200 |  |

- removed (2019-11-05):
[0001193125-19-139609:note_history:118]
The Company entered into a syndicated senior credit facility agreement (the “Facility Agreement”) with a consortium of banks on May 22, 2014. The Facility Agreement, led by Bank of America, provided for a $200.0 million credit line, comprised of a $150.0 million revolving loan facility and a $50.0 million delayed draw term loan facility. The revolving loan facility contains an accordion feature permitting Fabrinet to request an increase in the facility up to $100.0 million subject to customary terms and conditions and provided that no default or event of default exists at the time of request.

- removed (2019-11-05):
[0001193125-19-139609:note_history:119]
On February 26, 2015, the Company entered into the Second Amendment to the Facility Agreement. The amendment extended the availability period for draws on the term loan facility from May 21, 2015 to July 31, 2015. It also allowed the Company, upon the satisfaction of certain conditions, to designate from time to time one or more of its subsidiaries as borrowers under the Facility Agreement. On July 31, 2015, the Company entered into the Third Amendment to the Facility Agreement. This amendment extended the availability period for draws on the term loan facility from July 31, 2015 to July 31, 2016. On July 22, 2016, the Company entered into the Fourth Amendment to the Facility Agreement to change the timing of filing certain financial information with the bank.

- removed (2019-11-05):
[0001193125-19-139609:note_history:120]
Loans under the Facility Agreement bear interest, at Fabrinet’s option, at a rate per annum equal to a LIBOR rate plus a spread of 1.75% to 2.50%, or a base rate, determined in accordance with the Facility Agreement, plus a spread of 0.75% to 1.50%, in each case with such spread determined based on Fabrinet’s consolidated total leverage ratio for the preceding four fiscal quarter period. Interest is due and payable quarterly in arrears for loans bearing interest at the base rate and at the end of an interest period (or at each three-month interval in the case of loans with interest periods greater than three months) in the case of loans bearing interest at the LIBOR rate.

- removed (2019-11-05):
[0001193125-19-139609:note_history:121]
Fabrinet’s obligations under the Facility Agreement are guaranteed by certain of its existing and future direct material subsidiaries. In addition, the Facility Agreement is secured by Fabrinet’s present and future accounts receivable, deposit accounts and cash, and a pledge of the capital stock of certain of Fabrinet’s direct subsidiaries. Fabrinet is required to maintain at least $40.0 million of cash, cash equivalents, and marketable securities at financial institutions located in the United States. Further, Fabrinet is required to maintain any of its deposits accounts or securities accounts with balances in excess of $10.0 million in a jurisdiction where a control agreement, or the equivalent under the local law, can be effected.

- removed (2019-11-05):
[0001193125-19-139609:note_history:122]
The Facility Agreement contains customary affirmative and negative covenants. Negative covenants include, among other things, limitations on liens, indebtedness, investments, mergers, sales of assets, changes in the nature of the business, dividends and distributions, affiliate transactions and capital expenditures. The Facility Agreement contains financial covenants requiring Fabrinet to maintain: (i) a minimum tangible net worth of not less than $200.0 million plus 50% of quarterly net income, exclusive of quarterly losses; (ii) a minimum debt service coverage ratio of not less than 1.50:1.00; (iii) a maximum senior leverage ratio of not more than 2.50:1.00; and (iv) a minimum quick ratio of not less than 1.10:1.00. Each of these financial covenants is calculated on a consolidated basis for the consecutive four fiscal quarter period then ended.

- removed (2019-11-05):
[0001193125-19-139609:note_history:123]
The Facility Agreement also contains customary events of default including, among other things, payment defaults, breaches of covenants or representations and warranties, cross-defaults with certain other indebtedness, bankruptcy and insolvency events and change in control of Fabrinet, subject to grace periods in certain instances. Upon an event of default, the lenders may terminate their commitments, declare all or a portion of the outstanding obligations payable by Fabrinet to be immediately due and payable and exercise other rights and remedies provided for under the Facility Agreement.

- removed (2019-11-05):
[0001193125-19-139609:note_history:124]
On June 4, 2018, the Company entered into the Fifth Amendment to the Facility Agreement to (i) reduce the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) extend the termination date of the revolving commitments from May 22, 2019 to June 4, 2023, (iii) refinance the then-existing term loan and revolving loans under the Facility Agreement into a $65.0 million term loan and (iv) reduce the applicable interest rate margins and commitment fees. Term loans must be repaid in quarterly installments, beginning on June 30, 2018, with the remaining outstanding principal and accrued and unpaid interest being due and payable on June 4, 2023. After giving effect to the amendment, $65.0 million aggregate principal amount of term loans and no revolving loans were outstanding under the Facility Agreement. In addition, the Fifth Amendment to the Facility Agreement contains an accordion feature permitting the Company to request an increase in the revolving loan facility to provide up to an aggregate of $200.0 million in additional commitments, subject to customary terms and conditions, and provided that no default or event of default exists at the time of such request. As of March 29, 2019 and June 29, 2
0
18, $61.8 million and $64.2 million aggregate principal amount of term loans, respectively, and no revolving loans were outstanding under the Facility Agreement.

- removed (2019-11-05):
[0001193125-19-139609:note_history:125]
After the Fifth Amendment, loans under the Facility Agreement bear interest, at Fabrinet’s option, at a rate per annum equal to a LIBOR rate plus a spread of 1.50% to 2.25%, or a base rate plus a spread of 0.50% to 1.25%, determined in accordance with the Facility Agreement in each case with such spread determined based on Fabrinet’s consolidated total leverage ratio for the preceding four fiscal quarter period.

- removed (2019-11-05):
[0001193125-19-139609:note_history:126]
Fabrinet’s obligations under the Facility Agreement are guaranteed by certain of existing and future material of its direct subsidiaries. In addition, the Facility Agreement is secured by Fabrinet’s present and future accounts receivable, deposit accounts and cash, and a pledge of the capital stock of certain of Fabrinet’s direct subsidiaries. Fabrinet is required to maintain at least $40.0 million of cash, cash equivalents, and marketable securities at financial institutions located in the United States. Further, Fabrinet is required to maintain any of its deposits accounts or securities accounts with balances in excess of $20.0 million in a jurisdiction where a control agreement, or the equivalent under the local law, can be effected.

- removed (2019-11-05):
[0001193125-19-139609:note_history:127]
Moreover, the Fifth Amendment to the Facility Agreement amends customary affirmative and negative covenants. Negative covenants include, among other things, limitations on liens, indebtedness, investments, mergers, sales of assets, changes in the nature of the business, dividends and distributions, affiliate transactions and capital expenditures. The Facility Agreement contains financial covenants requiring Fabrinet to maintain: (1) a minimum tangible net worth of not less than $338.0 million plus 50% of quarterly net income after June 30, 2018, exclusive of quarterly losses; (2) a minimum debt service coverage ratio of not less than 1.50:1.00; (3) a maximum total leverage ratio of not more than 2.50:1.00; and (4) a minimum quick ratio of not less than 1.10:1.00. Each of these financial covenants is calculated on a consolidated basis for the consecutive four fiscal quarter period then ended. As of March 29, 2019, the Company was in compliance with all covenants under the Facility Agreement.

- removed (2019-11-05):
[0001193125-19-139609:note_history:128]
Fabrinet intends to use the proceeds of the credit line to finance its future expansion in the United States and Thailand, and for general corporate purposes including mergers and acquisitions of complementary manufacturing businesses or technology, although Fabrinet has no current commitments with respect to any such acquisitions.

- removed (2019-11-05):
[0001193125-19-139609:note_history:129]
On July 25, 2018, the Company entered into the Swap Agreement, which the Company did not designate as a hedging instrument. The Swap Agreement was used to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. The terms of the Swap Agreement effectively convert the floating interest rate of the term loans under the Facility Agreement to the fixed interest rate of 2.86% per annum through maturity in June 2023. The swap transactions are due and settled 
monthly. During the nine months ended March 29, 2019, the Company included a net loss of $0.2 million from the Swap Agreement in interest expense in the condensed consolidated statements of operations and comprehensive income.

- removed (2019-11-05):
[0001193125-19-139609:note_history:130]
Undrawn available credit facilities classified by availability period of future borrowing as of March 29, 2019 and June 29, 2018 were as follows:

- removed (2019-11-05):
[0001193125-19-139609:note_history:131]
| (amount in thousands) |  | March 29,2019 |  |  | June 29,2018 |  |
| Expiring within one year |  | $ | — |  |  | $ | — |  |
| Expiring beyond one year |  | $ | 25,000 |  |  | $ | 25,000 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-05):
[0001193125-19-284781:note_history:132]
The movements of long-term borrowings for the three months ended September 27, 2019 and September 28, 2018 were as follows:
  (was, 2019-05-07, similarity 0.8704):
[0001193125-19-139609:note_history:132]
The movements of long-term borrowing for the nine months ended March 29, 2019 and March 30, 2018 were as follows:

- added (2019-11-05):
[0001193125-19-284781:note_history:133]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 27, 2019 |  |  | September 28, 2018 |  |
| Opening balance |  | $ | 60,938 |  |  | $ | 64,188 |  |
| Borrowings during the period |  |  | 60,938 |  |  |  | — |  |
| Repayments during the period |  |  | (60,938 | ) |  |  | (813 | ) |
| Closing balance |  | $ | 60,938 |  |  | $ | 63,375 |  |

- removed (2019-11-05):
[0001193125-19-139609:note_history:134]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 29,2019 |  |  | March 30,2018 |  |
| Opening balance |  | $ | 64,188 |  |  | $ | 36,400 |  |
| Repayments during the period |  |  | (2,438 | ) |  |  | (10,200 | ) |
| Closing balance |  | $ | 61,750 |  |  | $ | 26,200 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-11-05):
[0001193125-19-284781:note_history:135]
The Company’s total borrowings, including current
 portion

- added (2019-11-05):
[0001193125-19-284781:note_history:136]
and 
non-current
 portion of

- changed (2019-11-05):
[0001193125-19-284781:note_history:137]
long-term borrowings, consisted of the following:
  (was, 2019-05-07, similarity 0.6323):
[0001193125-19-139609:note_history:137]
The Company’s total borrowings, including short-term and long-term borrowings, consisted of the following:

- added (2019-11-05):
[0001193125-19-284781:note_history:138]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  | Maturity |  |  | As ofSeptember 27,2019 |  |  | As ofJune 28,2019 |  |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  |  |  |  | $ | 12,188 |  |  | $ | 3,250 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  |  |  |  |  | (31 | ) |  |  | — |  |
| Long-term borrowings, current portion, net |  |  |  |  |  |  |  | $ | 12,157 |  |  |  | 3,250 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1-month LIBOR +1.50% per annum (1) |  | Repayable in quarterly installments |  |  | June 2023 |  |  | $ | — |  |  | $ | 60,938 |  |
| 3-month LIBOR +1.35% per annum (1) |  | Repayable in quarterly installments |  |  | June 2024 |  |  |  | 60,938 |  |  |  | — |  |
| Less: Current portion |  |  |  |  |  |  |  |  | (12,188 | ) |  |  | (3,250 | ) |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  |  |  |  |  | (119 | ) |  |  | — |  |
| Long-term borrowings, non-current portion, net |  |  |  |  |  |  |  | $ | 48,631 |  |  | $ | 57,688 |  |

- added (2019-11-05):
[0001193125-19-284781:note_history:139]
| (1) | We have entered into interest rate swaps that effectively fix a series of our future interest payments on our term loans. Refer to Note 6. |

- removed (2019-11-05):
[0001193125-19-139609:note_history:140]
| Rate (1) |  | Conditions |  |  | Maturity |  |  | As ofMarch 29,2019 |  |  | As ofJune 29,2018 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current portion of long-term borrowing |  |  | $ | 3,250 |  |  | $ | 3,250 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.50% per annum |  |  | Repayable in quarterlyinstallments |  |  |  | June 2023 |  |  | $ | 61,750 |  |  | $ | 64,188 |  |
|  |  |  |  |  |  |  |  | 61,750 |  |  | 64,188 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (3,250 | ) |  |  | (3,250 | ) |
| Non-current portion of long-term borrowing |  |  |  |  |  |  |  |  |  | $ | 58,500 |  |  | $ | 60,938 |  |

- removed (2019-11-05):
[0001193125-19-139609:note_history:141]
| (1) | LIBOR is London Interbank Offered Rate. |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2019-11-05):
[0001193125-19-139609:note_history:142]
| (amount in thousands) |  | March 29,2019 |  |  | June 29,2018 |  |
| Expiring within one year |  | $ | — |  |  | $ | — |  |
| Expiring beyond one year |  | $ | 25,000 |  |  | $ | 25,000 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-11-05):
[0001193125-19-284781:note_history:143]
As of September 27, 2019, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2019-05-07, similarity 0.9447):
[0001193125-19-139609:note_history:143]
As of March 29, 2019, future maturities of long-term borrowing during each fiscal year were as follows:

- changed (2019-11-05):
[0001193125-19-284781:note_history:144]
| (amount in thousands) |  |  |  |
| 2020 (remaining nine months) |  | $ | 9,140 |  |
| 2021 |  |  | 12,188 |  |
| 2022 |  |  | 15,234 |  |
| 2023 |  |  | 12,188 |  |
| 2024 |  |  | 12,188 |  |
| Total |  | $ | 60,938 |  |
  (was, 2019-05-07, similarity 0.9781):
[0001193125-19-139609:note_history:144]
| (amount in thousands) |  |  |  |
| 2019 (remaining three months) |  | $ | 813 |  |
| 2020 |  |  | 3,250 |  |
| 2021 |  |  | 3,250 |  |
| 2022 |  |  | 3,250 |  |
| 2023 |  |  | 51,187 |  |
| Total |  | $ | 61,750 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-11-05):
[0001193125-19-284781:note_history:145]
The following table presents total revenues by geographic region:
  (was, 2019-05-07, similarity 0.9924):
[0001193125-19-139609:note_history:145]
The following table presents total revenues by geographic regions:

- changed (2019-11-05):
[0001193125-19-284781:note_history:146]
| (amount in thousands, except percentages) |  | Three Months Ended September 27, 2019 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 200,947 |  |  |  | 50.3 | % |
| Asia-Pacific |  |  | 118,423 |  |  |  | 29.7 |  |
| Europe |  |  | 79,926 |  |  |  | 20.0 |  |
|  |  | $ | 399,296 |  |  |  | 100.0 | % |
  (was, 2019-05-07, similarity 0.6464):
[0001193125-19-139609:note_history:146]
| (amount in thousands) |  | Three MonthsEndedMarch 29,2019 |  |  | As a % of TotalRevenues |  |  | Nine MonthsEndedMarch 29,2019 |  |  | As a % of TotalRevenues |  |
| North America |  | $ | 195,504 |  |  |  | 49.0 | % |  | $ | 558,028 |  |  |  | 47.3 | % |
| Asia-Pacific |  |  | 151,263 |  |  |  | 37.9 |  |  |  | 469,921 |  |  |  | 39.9 |  |
| Europe |  |  | 52,184 |  |  |  | 13.1 |  |  |  | 151,259 |  |  |  | 12.8 |  |
|  |  | $ | 398,951 |  |  |  | 100.0 | % |  | $ | 1,179,208 |  |  |  | 100.0 | % |

- added (2019-11-05):
[0001193125-19-284781:note_history:147]
| (amount in thousands, except percentages) |  | Three Months Ended September 28, 2018 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 179,826 |  |  |  | 47.7 | % |
| Asia-Pacific |  |  | 151,947 |  |  |  | 40.3 |  |
| Europe |  |  | 45,404 |  |  |  | 12.0 |  |
|  |  | $ | 377,177 |  |  |  | 100.0 | % |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-11-05):
[0001193125-19-284781:note_history:148]
| 3. | Revenues from contracts with customers |

- changed (2019-11-05):
[0001193125-19-284781:note_history:149]
The Company derives total revenues primarily from the assembly of products under supply agreements with its customers and the fabrication of customized optics and glass. The Company recognizes revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the Company expects to be entitled in exchange for such goods or services. In order to meet this requirement, the Company applies the following five steps: (1) identify the contract with a customer, (2) identify the performance obligations 
under
 the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations 
under
 the contract, and (5) recognize revenue when a performance obligation is satisfied. Revenue is recognized net of any taxes collected from customers, which is subsequently remitted to governmental authorities.
  (was, 2019-05-07, similarity 0.9925):
[0001193125-19-139609:note_history:149]
The Company derives total revenues primarily from the assembly of products under supply agreements with its customers and the fabrication of customized optics and glass. The Company recognizes revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the Company expects to be entitled in exchange for such goods or services. In order to meet this requirement, the Company applies the following five steps: (1) identify the contract with a customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract, and (5) recognize revenue when a performance obligation is satisfied. Revenue is recognized net of any taxes collected from customers, which is subsequently remitted to governmental authorities.

- changed (2019-11-05):
[0001193125-19-284781:note_history:150]
A performance obligation is a contractual promise to transfer a distinct good or service to the customer. In contracts with multiple performance obligations, the Company identifies each performance obligation and evaluates whether the performance obligation is distinct within the context of the contract at contract inception. The majority of the Company’s contracts have a single performance obligation as the promise to transfer the individual goods or services is not separately identifiable from other promises under the contracts and, therefore, is not distinct.
  (was, 2019-05-07, similarity 0.9558):
[0001193125-19-139609:note_history:150]
A performance obligation is a promise in a contract to transfer a distinct good or service to the customer. In contracts with multiple performance obligations, the Company identifies each performance obligation and evaluates whether the performance obligation is distinct within the context of the contract at contract inception. The majority of the Company’s contracts have a single performance obligation as the promise to transfer the individual goods or services is not separately identifiable from other promises in the contracts and, therefore, not distinct.

- added (2019-11-05):
[0001193125-19-284781:note_history:151]
The Company manufactures products that are customized to customers’ specifications, however, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for overtime recognition are not met. On the evaluation of the contracts the Company determined that it did not have contractual rights to bill profit for work in progress in the event of a contract termination, an event which is expected to be infrequent. Further, in limited circumstances, substantive acceptance by the customer will result in the deferral of revenue until acceptance is formally received from the customer. Judgment may be required in determining if the acceptance clause provides for substantive acceptance.

- added (2019-11-05):
[0001193125-19-284781:note_history:152]
Our customers generally are obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by our customers within a specified period of time, or that are no longer required due to a product’s cancellation or 
end-of-life,
 are typically designated as excess or obsolete inventory under our contracts. After materials are designated as either excess or obsolete inventory, our customers are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

- changed (2019-11-05):
[0001193125-19-284781:note_history:153]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. In determining the transaction price, the Company evaluates whether the price is subject to refund or adjustment to determine the net consideration to which the Company expects to be entitled. The Company generally does not grant return privileges 
other than
 for defective products during the warranty period. 
The Company generally provides a warranty of between one to five years
 on the product.
  (was, 2019-05-07, similarity 0.983):
[0001193125-19-139609:note_history:153]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. In determining the transaction price, the Company evaluates whether the price is subject to refund or adjustment to determine the net consideration to which the Company expects to be entitled. The Company generally does not grant return privileges, except for defective products during the warranty period. The Company generally provides a warranty of between one to five years on the product.

- added (2019-11-05):
[0001193125-19-284781:note_history:154]
A contract asset is recognized when the Company has recognized revenues prior to 
generating 
an invoice for payment. Contract assets are classified separately on the

- changed (2019-11-05):
[0001193125-19-284781:note_history:155]
unaudited condensed
  (was, 2019-05-07, similarity 0.6429):
[0001193125-19-139609:note_history:155]
Condensed

- added (2019-11-05):
[0001193125-19-284781:note_history:156]
consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. During the three-month 
period 
ended September 27, 2019, the Company had no impairment for contract assets recognized.

- added (2019-11-05):
[0001193125-19-284781:note_history:157]
A contract liability is recognized when the Company has advance payment arrangements with customers. The contract liabilities balance is normally recognized as revenue within six months.

- added (2019-11-05):
[0001193125-19-284781:note_history:158]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the three

- added (2019-11-05):
[0001193125-19-284781:note_history:159]
month
s
 ended September 27, 2019:

- changed (2019-11-05):
[0001193125-19-284781:note_history:160]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 28, 2019 |  | $ | 12,447 |  |
| Revenue recognized |  |  | 21,653 |  |
| Amounts collected or invoiced |  |  | (22,480 | ) |
| Ending balance, September 27, 2019 |  | $ | 11,620 |  |
  (was, 2019-05-07, similarity 0.7984):
[0001193125-19-139609:note_history:160]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 30, 2018 |  | $ | — |  |
| Cumulative effect adjustment upon adoption of ASC 606 |  |  | 9,877 |  |
| Revenue recognized |  |  | 89,131 |  |
| Amounts collected or invoiced |  |  | (88,465 | ) |
| Ending balance, March 29, 2019 |  | $ | 10,543 |  |

- added (2019-11-05):
[0001193125-19-284781:note_history:161]
| (amount in thousands) |  | Contract Liabilities |  |
| Beginning balance, June 28, 2019 |  | $ | 2,239 |  |
| Additions advance payment received during the period |  |  | 2,230 |  |
| Revenue recognized |  |  | (2,203 | ) |
| Ending balance, September 27, 2019 |  | $ | 2,266 |  |

- added (2019-11-05):
[0001193125-19-284781:note_history:162]
Consistent with the guidance in ASC 
340-40-25-1,
 the incremental costs of obtaining a contract with a customer are recognized as an asset (not expensed as incurred) if 
such 
costs are expected to be recovered. Incremental costs of obtaining a contract are 
costs that
 the Company would not have incurred if the contract had not been obtained (e.g., sales commissions or similar incentive payments linked directly to new or modified customer contracts). Costs that would have been incurred regardless of whether a customer contract was obtained (e.g., costs of pursuing the contact, legal advice, etc.) are expensed as incurred, unless 
such 
costs are explicitly chargeable to the customer. During the three

- added (2019-11-05):
[0001193125-19-284781:note_history:163]
month
s
 ended September 27, 2019, the Company did not have any incremental costs of obtaining a contract.

- changed (2019-11-05):
[0001193125-19-284781:note_history:164]
Shipping costs billed to customers are recorded as revenue. Shipping and handling expense related to costs incurred to deliver product are recognized within cost of goods sold. The Company accounts for shipping and handling activities that occur after control has transferred as a fulfillment cost as opposed to a separate performance obligation, and the costs of shipping and handling are recognized concurrently with the related revenue.
  (was, 2019-05-07, similarity 0.9989):
[0001193125-19-139609:note_history:164]
Shipping costs billed to customers are recorded as revenue. Shipping and handling expense related to costs incurred to deliver product are recognized within cost of goods sold. The Company accounts for shipping and handling activities that occur after control has transferred as a fulfillment cost, as opposed to a separate performance obligation, and the costs of shipping and handling are recognized concurrently with the related revenue.

- added (2019-11-05):
[0001193125-19-284781:note_history:165]
Total revenues are attributed to a particular geographic area based on the
 bill-to-location
 of the 
Company’s

- changed (2019-11-05):
[0001193125-19-284781:note_history:166]
customers. The Company operates in three geographic regions: North America, Asia-Pacific and Europe. The following table presents total revenues by geographic region:
  (was, 2019-05-07, similarity 0.758):
[0001193125-19-139609:note_history:166]
Total revenues are attributed to a particular geographic area based on the bill-to-location of customers. The Company operates primarily in three geographic regions: North America, Asia-Pacific and Europe. The following table presents total revenues by geographic regions:

- changed (2019-11-05):
[0001193125-19-284781:note_history:167]
| (amount in thousands, except percentages) |  | Three Months Ended September 27, 2019 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 200,947 |  |  |  | 50.3 | % |
| Asia-Pacific |  |  | 118,423 |  |  |  | 29.7 |  |
| Europe |  |  | 79,926 |  |  |  | 20.0 |  |
|  |  | $ | 399,296 |  |  |  | 100.0 | % |
  (was, 2019-05-07, similarity 0.6464):
[0001193125-19-139609:note_history:167]
| (amount in thousands) |  | Three MonthsEndedMarch 29,2019 |  |  | As a % of TotalRevenues |  |  | Nine MonthsEndedMarch 29,2019 |  |  | As a % of TotalRevenues |  |
| North America |  | $ | 195,504 |  |  |  | 49.0 | % |  | $ | 558,028 |  |  |  | 47.3 | % |
| Asia-Pacific |  |  | 151,263 |  |  |  | 37.9 |  |  |  | 469,921 |  |  |  | 39.9 |  |
| Europe |  |  | 52,184 |  |  |  | 13.1 |  |  |  | 151,259 |  |  |  | 12.8 |  |
|  |  | $ | 398,951 |  |  |  | 100.0 | % |  | $ | 1,179,208 |  |  |  | 100.0 | % |

- added (2019-11-05):
[0001193125-19-284781:note_history:168]
| (amount in thousands, except percentages) |  | Three Months Ended September 28, 2018 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 179,826 |  |  |  | 47.7 | % |
| Asia-Pacific |  |  | 151,947 |  |  |  | 40.3 |  |
| Europe |  |  | 45,404 |  |  |  | 12.0 |  |
|  |  | $ | 377,177 |  |  |  | 100.0 | % |

- changed (2019-11-05):
[0001193125-19-284781:note_history:169]
The following table sets forth our revenues by end market.
  (was, 2019-05-07, similarity 0.9643):
[0001193125-19-139609:note_history:169]
The following table sets forth revenues by end market.

- added (2019-11-05):
[0001193125-19-284781:note_history:170]
| (amount in thousands, except percentages) |  | Three Months Ended September 27, 2019 |  |  | As a % of Total Revenues |  |
| Optical communications |  | $ | 302,379 |  |  |  | 75.7 | % |
| Lasers, sensors and other |  |  | 96,917 |  |  |  | 24.3 |  |
| Total |  | $ | 399,296 |  |  |  | 100.0 | % |

- added (2019-11-05):
[0001193125-19-284781:note_history:171]
| (amount in thousands, except percentages) |  | Three Months Ended September 28, 2018 |  |  | As a % of Total Revenues |  |
| Optical communications |  | $ | 280,768 |  |  |  | 74.4 | % |
| Lasers, sensors and other |  |  | 96,409 |  |  |  | 25.6 |  |
| Total |  | $ | 377,177 |  |  |  | 100.0 | % |

- removed (2019-11-05):
[0001193125-19-139609:note_history:172]
|  | 3. | Revenues |

- removed (2019-11-05):
[0001193125-19-139609:note_history:173]
The Company manufactures products that are customized to customers’ specifications; however, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for overtime recognition are not met. On the evaluation of the contracts, the Company identified that it did not have contractual rights to bill profit for work in progress in the event of a contract termination which is expected to be infrequent. Further, in limited circumstances, substantive acceptance by the customer exists which results in the deferral of revenue until acceptance is formally received from the customer. Judgment may be required in determining if the acceptance clause is substantive.

- removed (2019-11-05):
[0001193125-19-139609:note_history:174]
Customers generally are obligated to purchase finished goods that the Company has manufactured according to their demand requirements. Materials that are not consumed by customers within a specified period of time, or are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under the Company’s contracts. Once materials are designated as either excess or obsolete inventory, customers are typically required to purchase such inventory from the Company even if the customer has chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

- removed (2019-11-05):
[0001193125-19-139609:note_history:175]
A contract asset is recognized when the Company has recognized revenues, but not yet an invoice for payment. Contract assets are classified separately on the condensed consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. The following table summarizes the activity in the Company’s contract assets during the nine-month period ended March 29, 2019:

- removed (2019-11-05):
[0001193125-19-139609:note_history:176]
The Company continually evaluates whether advance payment arrangements with customers result in the recognition of contract liabilities. No such liabilities existed as of March 29, 2019 or June 29, 2018. Separately, accounts receivable, net, represents receivables from contracts with customers.

- removed (2019-11-05):
[0001193125-19-139609:note_history:177]
The Company has elected the practical expedient to recognize the incremental costs of obtaining a contract as an expense when incurred if the amortization period of the asset that the Company otherwise would have recognized is one year or less. During the three and nine months ended March 29, 2019, the Company did not have any incremental costs of obtaining a contract.

- removed (2019-11-05):
[0001193125-19-139609:note_history:178]
In accordance with the new revenue standard requirements, the disclosure of the impact of adoption of ASC 606 on the Company’s condensed consolidated statements of operations and comprehensive income for the three and nine months ended March 29, 2019 and condensed consolidated balance sheets as of March 29, 2019 was as follows:

- removed (2019-11-05):
[0001193125-19-139609:note_history:179]
Condensed Consolidated Statement of Operations and Comprehensive Income (Unaudited)

- removed (2019-11-05):
[0001193125-19-139609:note_history:180]
Three and Nine Months Ended March 29, 2019

- removed (2019-11-05):
[0001193125-19-139609:note_history:181]
|  |  | Impact of Adopting ASC 606 (Three months) |  |  | Impact of Adopting ASC 606 (Nine months) |  |
| (amount in thousands) |  | As Reported |  |  | Adjustment |  |  | Balance withoutASC 606 Adoption |  |  | As Reported |  |  | Adjustment |  |  | Balance withoutASC 606 Adoption |  |
| Revenues |  | $ | 398,951 |  |  | $ | 2,793 | (1) |  | $ | 401,744 |  |  | $ | 1,179,208 |  |  | $ | (666 | )(1) |  | $ | 1,178,542 |  |
| Cost of revenues |  | $ | (352,193 | ) |  | $ | (2,699 | )(2) |  | $ | (354,892 | ) |  | $ | (1,046,610 | ) |  | $ | 341 | (2) |  | $ | (1,046,269 | ) |
| Gross profit |  | $ | 46,758 |  |  | $ | 94 | (3) |  | $ | 46,852 |  |  | $ | 132,598 |  |  | $ | (325 | )(3) |  | $ | 132,273 |  |
| Net income |  | $ | 28,635 |  |  | $ | 94 | (3) |  | $ | 28,729 |  |  | $ | 87,998 |  |  | $ | (325 | )(3) |  | $ | 87,673 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.78 |  |  | $ | 0.00 |  |  | $ | 0.78 |  |  | $ | 2.39 |  |  | $ | (0.01 | ) |  | $ | 2.38 |  |
| Diluted |  | $ | 0.76 |  |  | $ | 0.00 |  |  | $ | 0.76 |  |  | $ | 2.35 |  |  | $ | (0.01 | ) |  | $ | 2.34 |  |

- removed (2019-11-05):
[0001193125-19-139609:note_history:182]
|  | (1) | Adjustment relates to certain manufacturing contracts with vendor-managed inventory arrangements for which revenue was recognized at shipping. |

- removed (2019-11-05):
[0001193125-19-139609:note_history:183]
| (2) | Adjustment relates to costs associated with revenue recognized. |

- removed (2019-11-05):
[0001193125-19-139609:note_history:184]
| (3) | Adjustment relates to net impact on net income upon adoption of ASC 606. |

- removed (2019-11-05):
[0001193125-19-139609:note_history:185]
Consolidated Balance Sheets (Unaudited)

- removed (2019-11-05):
[0001193125-19-139609:note_history:186]
As of March 29, 2019

- removed (2019-11-05):
[0001193125-19-139609:note_history:187]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | As Reported |  |  | Adjustments |  |  | Balancewithout ASC606 Adoption |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract assets |  | $ | 10,543 |  |  | $ | (10,543 | )(1) |  | $ | — |  |
| Inventory, net |  | $ | 285,431 |  |  | $ | 9,013 | (2) |  | $ | 294,444 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 721,626 |  |  | $ | (1,530 | )(3) |  | $ | 720,096 |  |

- removed (2019-11-05):
[0001193125-19-139609:note_history:188]
| (1) | Majority of adjustment relates to certain manufacturing contracts with vendor-managed inventory arrangements for which revenue was recognized on shipment. |

- removed (2019-11-05):
[0001193125-19-139609:note_history:189]
| (2) | Adjustment relates to reduction of finished goods inventory for vendor-managed inventory. |

- removed (2019-11-05):
[0001193125-19-139609:note_history:190]
| (3) | Adjustment relates to cumulative effect adjustment upon adoption of ASC 606. |

- removed (2019-11-05):
[0001193125-19-139609:note_history:191]
| (amount in thousands) |  | Three MonthsEndedMarch 29,2019 |  |  | As a % of TotalRevenues |  |  | Nine MonthsEndedMarch 29,2019 |  |  | As a % of TotalRevenues |  |
| Optical communications |  | $ | 298,139 |  |  |  | 74.7 | % |  | $ | 884,454 |  |  |  | 75.0 | % |
| Lasers, sensors and other |  |  | 100,812 |  |  |  | 25.3 |  |  |  | 294,754 |  |  |  | 25.0 |  |
|  |  | $ | 398,951 |  |  |  | 100.0 | % |  | $ | 1,179,208 |  |  |  | 100.0 | % |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2019-11-05):
[0001193125-19-284781:note_history:192]
On October 1, 2019, the Company advanced fund
s
 in the amount of 
$
24.3

- added (2019-11-05):
[0001193125-19-284781:note_history:193]
million to a customer to support the customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. These advanced funds

- added (2019-11-05):
[0001193125-19-284781:note_history:194]
must be repaid by September 30, 2020.

- removed (2019-11-05):
[0001193125-19-139609:note_history:195]
On December 13, 2018, Thailand’s National Legislative Assembly (NLA) passed an amendment bill to the Thai Labour Protection Act B.E. 2541 (1998) to increase the required severance payment compensation for employees with 20 or more years of service from 300 days of wage to 400 days of wage. The law became effective on May 4, 2019. The Company has engaged an independent actuary to consider the effect of this change.

- removed (2019-11-05):
[0001193125-19-139609:note_history:196]
In

- removed (2019-11-05):
[0001193125-19-139609:note_history:197]
May 2019

- removed (2019-11-05):
[0001193125-19-139609:note_history:198]
, Fabrinet’s board of directors approved the repurchase of up to an additional $50.0 million of Fabrinet’s outstanding ordinary shares, bringing the aggregate authorization under Fabrinet’s existing share repurchase program to $110.0 million.
