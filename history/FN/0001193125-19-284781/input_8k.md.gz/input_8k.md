# FN 8-K — 0001193125-19-283396 filed 2019-11-04

## item codes, every 8-K on or before 2019-11-05

- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2019-11-05

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-19-283396:8k_2_02:1]
EX-99.1
2
d826285dex991.htm
EX-99.1

[0001193125-19-283396:8k_2_02:2]
EX-99.1

[0001193125-19-283396:8k_2_02:3]
Exhibit 99.1

[0001193125-19-283396:8k_2_02:4]
Fabrinet Announces First Quarter Fiscal Year 2020 Financial Results

[0001193125-19-283396:8k_2_02:5]
BANGKOK, Thailand – November 4, 2019 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision
optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its first quarter ended September 27, 2019.

[0001193125-19-283396:8k_2_02:6]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “We had a strong start to the year with fiscal first quarter revenue and earnings that exceeded
our guidance ranges. We have made significant progress establishing a new product introduction facility in Israel that we expect to be operational in the first part of calendar 2020. We believe Fabrinet Israel can mirror the success we have seen at
Fabrinet West in California by attracting new customers and deepening relationships with existing customers. This development, along with our ongoing business success reinforce our confidence as we look ahead.”

[0001193125-19-283396:8k_2_02:7]
First Quarter Fiscal Year 2020 Financial Highlights

[0001193125-19-283396:8k_2_02:8]
GAAP Results

[0001193125-19-283396:8k_2_02:9]
|  | • |  | Revenue for the first quarter of fiscal year 2020 was $399.3 million, compared to revenue of $377.2 million for the comparable period in fiscal year 2019. |

[0001193125-19-283396:8k_2_02:10]
|  | • |  | GAAP net income for the first quarter of fiscal year 2020 was $25.9 million, compared to GAAP net income of $27.9 million for the first quarter of fiscal year 2019. GAAP net income for the first quarter of fiscal year 2020 included a foreign exchange loss of $1.9 million and a mark-to-market loss on the two interest rate swap contracts of $1.7 million, or $0.09 per diluted share, compared to a foreign exchange loss of $3.1 million, or $0.08 per diluted share, for the first quarter of fiscal year 2019. |

[0001193125-19-283396:8k_2_02:11]
|  | • |  | GAAP net income per diluted share for the first quarter of fiscal year 2020 was $0.69, compared to GAAP net income per diluted share of $0.75 for the first quarter of fiscal year 2019. |

[0001193125-19-283396:8k_2_02:12]
Non-GAAP
Results

[0001193125-19-283396:8k_2_02:13]
|  | • |  | Non-GAAP net income for the first quarter of fiscal year 2020 was $32.2 million, compared to non-GAAP net income of $34.1 million for the first quarter of fiscal year 2019. Non-GAAP net income for the first quarter of fiscal year 2020 included a foreign exchange loss of $1.9 million and a mark-to-market loss on the two interest rate swap contracts of $1.7 million, or $0.09 per diluted share, compared to a foreign exchange loss of $3.1 million, or $0.08 per diluted share, for the first quarter of fiscal year 2019. |

[0001193125-19-283396:8k_2_02:14]
|  | • |  | Non-GAAP net income per diluted share for the first quarter of fiscal year 2020 was $0.86, compared to non-GAAP net income per diluted share of $0.92 for the same period a year ago. |

[0001193125-19-283396:8k_2_02:15]
Business Outlook

[0001193125-19-283396:8k_2_02:16]
Based on information available as of
November 4, 2019, Fabrinet is issuing guidance for its second fiscal quarter of 2020 ending December 27, 2019, as follows:

[0001193125-19-283396:8k_2_02:17]
|  | • |  | Fabrinet expects second quarter revenue to be in the range of $408 million to $416 million. |

[0001193125-19-283396:8k_2_02:18]
|  | • |  | GAAP net income per diluted share is expected to be in the range of $0.74 to $0.77, based on approximately 37.7 million fully diluted shares outstanding. |

[0001193125-19-283396:8k_2_02:19]
|  | • |  | Non-GAAP net income per diluted share is expected to be in the range of $0.91 to $0.94, based on approximately 37.7 million fully diluted shares outstanding. |

[0001193125-19-283396:8k_2_02:20]
Conference Call Information

[0001193125-19-283396:8k_2_02:21]
| What: | Fabrinet First Quarter Fiscal-Year 2020 Financial Results Call |

[0001193125-19-283396:8k_2_02:22]
| When: | Monday, November 4, 2019 |

[0001193125-19-283396:8k_2_02:23]
| Time: | 5:00 p.m. ET |

[0001193125-19-283396:8k_2_02:24]
| Live Call: | (888) 357-3694, domestic |

[0001193125-19-283396:8k_2_02:25]
|  | (253) 237-1137, international |

[0001193125-19-283396:8k_2_02:26]
|  | Passcode: 3684935 |

[0001193125-19-283396:8k_2_02:27]
| Replay: | (855) 859-2056, domestic |

[0001193125-19-283396:8k_2_02:28]
|  | (404) 537-3406, international |

[0001193125-19-283396:8k_2_02:29]
|  | Passcode: 3684935 |

[0001193125-19-283396:8k_2_02:30]
| Webcast: | http://investor.fabrinet.com/ (live and replay) |

[0001193125-19-283396:8k_2_02:31]
This press release and any other information related to the call will also be posted on Fabrinet’s website at http://investor.fabrinet.com. A recorded
version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-19-283396:8k_2_02:32]
About Fabrinet

[0001193125-19-283396:8k_2_02:33]
Fabrinet is a leading provider of
advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive
components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain
management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities
in Thailand, the United States of America, the People’s Republic of China and the United Kingdom. For more information visit: www.fabrinet.com.

[0001193125-19-283396:8k_2_02:34]
Forward-Looking Statements

[0001193125-19-283396:8k_2_02:35]
compete effectively from a price and performance perspective; our reliance on a small number of customers and suppliers; difficulties in managing our operating costs; difficulties in managing and
operating our business across multiple countries (including Thailand, the People’s Republic of China, the U.S. and the U.K.); and other important factors as described in reports and documents we file from time to time with the Securities and
Exchange Commission (SEC), including the factors described under the section captioned “Risk Factors” in our Annual Report on Form 10-K, filed on August 20, 2019. We disclaim any obligation to
update information contained in these forward-looking statements whether as a result of new information, future events, or otherwise.

[0001193125-19-283396:8k_2_02:36]
Use of Non-GAAP Financials

[0001193125-19-283396:8k_2_02:37]
We refer to the non-GAAP financial measures cited above
in making operating decisions because they provide meaningful supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses;
depreciation of fair value uplift; severance payments; expenses related to our CFO search; amortization of intangibles; business combination expenses; amortization of deferred debt issuance costs; expenses related to reduction in workforce; and ASC
606 adjustments. We have excluded these items in order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they
should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in
conjunction with GAAP financial measures.

[0001193125-19-283396:8k_2_02:38]
These non-GAAP financial measures are used to: (1) measure company
performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions.
In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001193125-19-283396:8k_2_02:39]
SOURCE: Fabrinet

[0001193125-19-283396:8k_2_02:40]
Investor Contact:

[0001193125-19-283396:8k_2_02:41]
Garo Toomajanian

[0001193125-19-283396:8k_2_02:42]
ir@fabrinet.com

[0001193125-19-283396:8k_2_02:43]
FABRINET

[0001193125-19-283396:8k_2_02:44]
CONDENSED CONSOLIDATED BALANCE SHEETS (unaudited)

[0001193125-19-283396:8k_2_02:45]
| (in thousands of U.S. dollars, except share data and par value) |  | September 27,2019 |  |  | June 28,2019 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 168,535 |  |  | $ | 180,839 |  |
| Short-term restricted cash |  |  | 22,180 |  |  |  | — |  |
| Short-term investments |  |  | 238,266 |  |  |  | 256,493 |  |
| Trade accounts receivable, net |  |  | 273,616 |  |  |  | 260,602 |  |
| Contract assets |  |  | 11,620 |  |  |  | 12,447 |  |
| Inventory, net |  |  | 321,511 |  |  |  | 293,612 |  |
| Prepaid expenses |  |  | 6,313 |  |  |  | 8,827 |  |
| Other current assets |  |  | 9,122 |  |  |  | 11,015 |  |
| Total current assets |  |  | 1,051,163 |  |  |  | 1,023,835 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Long-term restricted cash |  |  | 7,402 |  |  |  | 7,402 |  |
| Property, plant and equipment, net |  |  | 212,270 |  |  |  | 210,686 |  |
| Intangibles, net |  |  | 3,661 |  |  |  | 3,887 |  |
| Operating right-of-use assets |  |  | 6,185 |  |  |  | — |  |
| Goodwill |  |  | 3,603 |  |  |  | 3,705 |  |
| Deferred tax assets |  |  | 5,201 |  |  |  | 5,679 |  |
| Other non-current assets |  |  | 225 |  |  |  | 124 |  |
| Total non-current assets |  |  | 238,547 |  |  |  | 231,483 |  |
| Total Assets |  | $ | 1,289,710 |  |  | $ | 1,255,318 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion, net |  | $ | 12,157 |  |  | $ | 3,250 |  |
| Trade accounts payable |  |  | 252,147 |  |  |  | 257,617 |  |
| Contract liabilities |  |  | 2,266 |  |  |  | 2,239 |  |
| Capital lease liability, current portion |  |  | 391 |  |  |  | 398 |  |
| Operating lease liability, current portion |  |  | 1,550 |  |  |  | — |  |
| Income tax payable |  |  | 2,534 |  |  |  | 1,801 |  |
| Accrued payroll, bonus and related expenses |  |  | 18,713 |  |  |  | 16,510 |  |
| Accrued expenses |  |  | 12,014 |  |  |  | 8,997 |  |
| Other payables |  |  | 21,649 |  |  |  | 22,236 |  |
| Total current liabilities |  |  | 323,421 |  |  |  | 313,048 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term borrowings, non-current portion, net |  |  | 48,631 |  |  |  | 57,688 |  |
| Deferred tax liability |  |  | 3,791 |  |  |  | 3,561 |  |
| Capital lease liability, non-current portion |  |  | — |  |  |  | 102 |  |
| Operating lease liability, non-current portion |  |  | 4,635 |  |  |  | — |  |
| Severance liabilities |  |  | 15,872 |  |  |  | 15,209 |  |
| Other non-current liabilities |  |  | 2,665 |  |  |  | 2,611 |  |
| Total non-current liabilities |  |  | 75,594 |  |  |  | 79,171 |  |
| Total Liabilities |  |  | 399,015 |  |  |  | 392,219 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of September 27, 2019 and June 28, 2019) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 38,389,128 shares and 38,230,753 shares issued; and 37,000,025 shares and 36,841,650 shares outstanding as of September 27, 2019 and June 28, 2019, respectively) |  |  | 384 |  |  |  | 382 |  |
| Additional paid-in capital |  |  | 160,148 |  |  |  | 158,299 |  |
| Less: Treasury shares (1,389,103 shares and 1,389,103 shares as of September 27, 2019 and June 28, 2019, respectively) |  |  | (47,779 | ) |  |  | (47,779 | ) |
| Accumulated other comprehensive loss |  |  | (2,598 | ) |  |  | (2,386 | ) |
| Retained earnings |  |  | 780,540 |  |  |  | 754,583 |  |
| Total Shareholders’ Equity |  |  | 890,695 |  |  |  | 863,099 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 1,289,710 |  |  | $ | 1,255,318 |  |

[0001193125-19-283396:8k_2_02:46]
FABRINET

[0001193125-19-283396:8k_2_02:47]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME (unaudited)

[0001193125-19-283396:8k_2_02:48]
|  |  | Three Months Ended |  |
| (in thousands of U.S. dollars, except per share data) |  | September 27,2019 |  |  | September 28,2018 |  |
| Revenues |  | $ | 399,296 |  |  | $ | 377,177 |  |
| Cost of revenues |  |  | (353,309 | ) |  |  | (336,901 | ) |
| Gross profit |  |  | 45,987 |  |  |  | 40,276 |  |
| Selling, general and administrative expenses |  |  | (16,000 | ) |  |  | (14,437 | ) |
| Expenses related to reduction in workforce |  |  | — |  |  |  | (85 | ) |
| Operating income, net |  |  | 29,987 |  |  |  | 25,754 |  |
| Interest income |  |  | 2,098 |  |  |  | 1,444 |  |
| Interest expense |  |  | (2,393 | ) |  |  | (634 | ) |
| Foreign exchange (loss) gain, net |  |  | (1,953 | ) |  |  | 3,068 |  |
| Other income, net |  |  | 377 |  |  |  | 77 |  |
| Income before income taxes |  |  | 28,116 |  |  |  | 29,709 |  |
| Income tax expense |  |  | (2,159 | ) |  |  | (1,859 | ) |
| Net income |  |  | 25,957 |  |  |  | 27,850 |  |
| Other comprehensive (loss) income, net of tax: |  |  |  |  |  |  |  |  |
| Change in net unrealized gain on available-for-sale securities |  |  | 35 |  |  |  | 288 |  |
| Change in net unrealized gain (loss) on derivative instruments |  |  | 39 |  |  |  | (1 | ) |
| Change in net retirement benefits plan – prior service cost |  |  | 83 |  |  |  | — |  |
| Change in foreign currency translation adjustment |  |  | (369 | ) |  |  | (200 | ) |
| Total other comprehensive (loss) income, net of tax |  |  | (212 | ) |  |  | 87 |  |
| Net comprehensive income |  | $ | 25,745 |  |  | $ | 27,937 |  |
| Earnings per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.70 |  |  | $ | 0.76 |  |
| Diluted |  | $ | 0.69 |  |  | $ | 0.75 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |  |
| Basic |  |  | 36,913 |  |  |  | 36,625 |  |
| Diluted |  |  | 37,529 |  |  |  | 37,140 |  |

[0001193125-19-283396:8k_2_02:49]
FABRINET

[0001193125-19-283396:8k_2_02:50]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited)

[0001193125-19-283396:8k_2_02:51]
|  |  | Three Months Ended |  |
| (in thousands of U.S. dollars) |  | September 27,2019 |  |  | September 28,2018 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income for the period |  | $ | 25,957 |  |  | $ | 27,850 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 7,465 |  |  |  | 7,412 |  |
| Loss on disposal of property, plant and equipment |  |  | 8 |  |  |  | 46 |  |
| Loss on disposal of intangibles |  |  | — |  |  |  | 149 |  |
| (Gain) loss from sales and maturities of available-for-sale securities |  |  | (67 | ) |  |  | 178 |  |
| Amortization of investment discount (premium) |  |  | 65 |  |  |  | (94 | ) |
| Amortization of deferred debt issuance costs |  |  | 2 |  |  |  | — |  |
| (Reversal of) allowance for doubtful accounts |  |  | (5 | ) |  |  | — |  |
| Unrealized loss (gain) on exchange rate and fair value of foreign currency forward contracts |  |  | 1,479 |  |  |  | (4,232 | ) |
| Unrealized loss (gain) on fair value of interest rate swaps |  |  | 1,671 |  |  |  | (50 | ) |
| Share-based compensation |  |  | 5,995 |  |  |  | 4,980 |  |
| Deferred income tax |  |  | 705 |  |  |  | 3 |  |
| Severance liabilities |  |  | 811 |  |  |  | 872 |  |
| Other non-cash expenses |  |  | 53 |  |  |  | (282 | ) |
| Reversal of inventory obsolescence |  |  | (264 | ) |  |  | (478 | ) |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | (12,967 | ) |  |  | (10,887 | ) |
| Contract assets |  |  | 827 |  |  |  | (280 | ) |
| Inventory |  |  | (27,634 | ) |  |  | (28,904 | ) |
| Other current assets and non-current assets |  |  | 4,225 |  |  |  | (979 | ) |
| Trade accounts payable |  |  | (5,263 | ) |  |  | 29,182 |  |
| Contract liabilities |  |  | 27 |  |  |  | — |  |
| Income tax payable |  |  | 733 |  |  |  | 1,680 |  |
| Other current liabilities and non-current liabilities |  |  | (1,176 | ) |  |  | 8,427 |  |
| Net cash provided by operating activities |  |  | 2,647 |  |  |  | 34,593 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of short-term investments |  |  | (62,880 | ) |  |  | (1,955 | ) |
| Proceeds from sales of short-term investments |  |  | 49,472 |  |  |  | 24,181 |  |
| Proceeds from maturities of short-term investments |  |  | 31,673 |  |  |  | 19,863 |  |
| Purchase of property, plant and equipment |  |  | (6,343 | ) |  |  | (5,410 | ) |
| Purchase of intangibles |  |  | (246 | ) |  |  | (78 | ) |
| Net cash provided by investing activities |  |  | 11,676 |  |  |  | 36,601 |  |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Payment of debt issuance costs |  |  | (153 | ) |  |  | — |  |
| Proceeds from long-term borrowings |  |  | 60,938 |  |  |  | — |  |
| Repayment of long-term borrowings |  |  | (60,938 | ) |  |  | (813 | ) |
| Repayment of capital lease liability |  |  | (109 | ) |  |  | (123 | ) |
| Release of restricted cash held in connection with business acquisition |  |  | — |  |  |  | (3,478 | ) |
| Withholding tax related to net share settlement of restricted share units |  |  | (4,144 | ) |  |  | (8,904 | ) |
| Net cash used in financing activities |  |  | (4,406 | ) |  |  | (13,318 | ) |
| Net increase in cash, cash equivalents and restricted cash |  |  | 9,917 |  |  |  | 57,876 |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 188,241 |  |  |  | 161,433 |  |
| Increase in cash, cash equivalents and restricted cash |  |  | 9,917 |  |  |  | 57,876 |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash |  |  | (41 | ) |  |  | 667 |  |
| Cash, cash equivalents and restricted cash at end of period |  | $ | 198,117 |  |  | $ | 219,976 |  |
| Non-cash investing and financing activities |  |  |  |  |  |  |  |  |
| Construction, software and equipment-related payables |  | $ | 9,816 |  |  | $ | 3,830 |  |

[0001193125-19-283396:8k_2_02:52]
FABRINET

[0001193125-19-283396:8k_2_02:53]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-19-283396:8k_2_02:54]
(CONTINUED)

[0001193125-19-283396:8k_2_02:55]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within
the unaudited condensed consolidated balance sheets that sum to the total of the same amounts shown in the unaudited condensed consolidated statements of cash flows:

[0001193125-19-283396:8k_2_02:56]
| (amount in thousands) |  | As ofSeptember 27,2019 |  |  | As ofSeptember 28,2018 |  |
| Cash and cash equivalents |  | $ | 168,535 |  |  | $ | 219,976 |  |
| Restricted cash |  |  | 29,582 |  |  |  | — |  |
| Cash, cash equivalents and restricted cash |  | $ | 198,117 |  |  | $ | 219,976 |  |

[0001193125-19-283396:8k_2_02:57]
FABRINET

[0001193125-19-283396:8k_2_02:58]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-19-283396:8k_2_02:59]
|  |  | Three Months Ended |  |
|  |  | September 27,2019 |  |  | September 28,2018 |  |
| (in thousands of U.S. dollars, except per share data) |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |
| GAAP measures |  | $ | 25,957 |  |  | $ | 0.69 |  |  | $ | 27,850 |  |  | $ | 0.75 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,720 |  |  |  | 0.05 |  |  |  | 1,847 |  |  |  | 0.05 |  |
| Depreciation of fair value uplift |  |  | 79 |  |  |  | 0.00 |  |  |  | 89 |  |  |  | 0.00 |  |
| ASC 606 adoption impact on gross profit |  |  |  |  |  |  |  |  |  |  | (31 | ) |  |  | 0.00 |  |
| Total related to gross profit |  |  | 1,799 |  |  |  | 0.05 |  |  |  | 1,905 |  |  |  | 0.05 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 4,275 |  |  |  | 0.11 |  |  |  | 3,133 |  |  |  | 0.08 |  |
| Expenses related to CFO search |  |  | — |  |  |  | — |  |  |  | 190 |  |  |  | 0.01 |  |
| Amortization of intangibles |  |  | 143 |  |  |  | 0.00 |  |  |  | 192 |  |  |  | 0.01 |  |
| Business combination expenses |  |  | — |  |  |  | — |  |  |  | 182 |  |  |  | 0.00 |  |
| Severance payment |  |  | — |  |  |  | — |  |  |  | 585 |  |  |  | 0.02 |  |
| Total related to selling, general and administrative expenses |  |  | 4,418 |  |  |  | 0.12 |  |  |  | 4,282 |  |  |  | 0.12 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Expenses related to reduction in workforce |  |  | — |  |  |  | — |  |  |  | 85 |  |  |  | 0.00 |  |
| Amortization of deferred debt issuance costs |  |  | 2 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |
| Total related to other incomes and other expenses |  |  | 2 |  |  |  | 0.00 |  |  |  | 85 |  |  |  | 0.00 |  |
| Total related to net income & EPS |  |  | 6,219 |  |  |  | 0.17 |  |  |  | 6,272 |  |  |  | 0.17 |  |
| Non-GAAP measures |  | $ | 32,176 |  |  | $ | 0.86 |  |  | $ | 34,122 |  |  | $ | 0.92 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 37,529 |  |  |  |  |  |  |  | 37,140 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 37,529 |  |  |  |  |  |  |  | 37,140 |  |

[0001193125-19-283396:8k_2_02:60]
FABRINET

[0001193125-19-283396:8k_2_02:61]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001193125-19-283396:8k_2_02:62]
| (amount in thousands) |  | Three Months Ended |  |
|  | September 27,2019 |  |  | September 28,2018 |  |
| Net cash provided by operating activities |  | $ | 2,647 |  |  | $ | 34,593 |  |
| Less: Purchase of property, plant and equipment |  |  | (6,343 | ) |  |  | (5,410 | ) |
| Non-GAAP free cash flow |  | $ | (3,696 | ) |  | $ | 29,183 |  |

[0001193125-19-283396:8k_2_02:63]
FABRINET

[0001193125-19-283396:8k_2_02:64]
GUIDANCE FOR QUARTER ENDING DECEMBER 27, 2019

[0001193125-19-283396:8k_2_02:65]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-19-283396:8k_2_02:66]
|  |  | DilutedEPS |
| GAAP net income per diluted share: |  | $0.74 to $0.77 |
| Related to cost of revenues: |  |  |
| Share-based compensation expenses |  | 0.04 |
| Total related to gross profit |  | 0.04 |
| Related to selling, general and administrative expenses: |  |  |
| Share-based compensation expenses |  | 0.12 |
| Expenses related to our CFO search |  | 0.01 |
| Total related to selling, general and administrative expenses |  | 0.13 |
| Total related to net income & EPS |  | 0.17 |
| Non-GAAP net income per diluted share |  | $0.91 to $0.94 |
