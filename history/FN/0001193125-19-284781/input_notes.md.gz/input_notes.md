# FN notes — 0001193125-19-284781


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-19-284781:notes:1]
| 2. | Accounting policies |

[0001193125-19-284781:notes:2]
Basis of presentation

[0001193125-19-284781:notes:3]
The accompanying unaudited
 condensed consolidated financial statements for Fabrinet as of September 27, 2019 and for the three months ended September 27, 2019 and September 28, 2018 includes normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 
10-K
 for the year ended June 28, 2019.

[0001193125-19-284781:notes:4]
The balance sheet as of June 28, 2019 has been derived from the audited financial statements at that date but does not include all of the information and footnotes required by U.S. GAAP for complete financial statements.

[0001193125-19-284781:notes:5]
The results for the three months ended September 27, 2019 may not be indicative of results for the year ending June 26, 2020 or any future periods.

[0001193125-19-284781:notes:6]
[same as prior period, unchanged from 0001193125-19-139609:notes:184]

[0001193125-19-284781:notes:7]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements, and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that estimates or assumptions prove to 
be 
differ
ent
 from actual results, adjustments will be made in subsequent periods to reflect more current information.

[0001193125-19-284781:notes:8]
[same as prior period, unchanged from 0001193125-19-139609:notes:186]

[0001193125-19-284781:notes:9]
The Company utilizes a

[0001193125-19-284781:notes:10]
52-53

[0001193125-19-284781:notes:11]
week fiscal year ending on the Friday in June closest to June 30. The three months ended September 27, 2019 and September 28, 2018 each consisted of 13 weeks. Fiscal year 2020 will be comprised of 52 weeks and will end on June 26, 2020.

[0001193125-19-284781:notes:12]
Changes in Accounting Policies

[0001193125-19-284781:notes:13]
Except for the adoption of the new lease accounting standard and the derivatives and hedging standard described below, the Company has consistently applied the accounting policies to all periods presented in these unaudited condensed consolidated financial statements.

[0001193125-19-284781:notes:14]
Adoption of New Accounting Standard
s

[0001193125-19-284781:notes:15]
On June 29, 2019, the Company adopted the new lease accounting standard, Accounting Standards Codification Topic 842 (“ASC 842”), which provides guidance for the recognition and disclosure of lease arrangements. The Company adopted ASC 842 using the modified retrospective transition approach. Accordingly, the Company’s comparative financial statements as of June 28, 2019 have not been adjusted. ASC 842 also provides practical expedients for the Company’s ongoing accounting. The Company elected the short-term lease recognition exemption for its operating leases with a term of less than 12 months, which will not require recognition of right of use (“ROU”) assets or lease liabilities for these leases.

[0001193125-19-284781:notes:16]
For periods prior to adoption of ASC 842, the Company is required to present disclosures in accordance with ASC Topic 840. The following disclosure provides the future minimum lease payments due under 
non-cancelable
 operating leases as of June 28, 2019:

[0001193125-19-284781:notes:17]
| (amount in thousands) |  |  |  |
| 2020 |  | $ | 1,746 |  |
| 2021 |  |  | 1,342 |  |
| 2022 |  |  | 1,219 |  |
| 2023 |  |  | 1,172 |  |
| Thereafter |  |  | 230 |  |
| Total future minimum operating lease payments |  | $ | 5,709 |  |

[0001193125-19-284781:notes:18]
The most significant impact of the adoption of ASC 842 was the recognition of ROU assets and lease liabilities for operating leases with a term of greater than 12 months, while the accounting for finance leases will remain substantially unchanged. See Note 10 for further details.

[0001193125-19-284781:notes:19]
On June 29, 2019, the Company also adopted Accounting Standards Update (“ASU”) 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. ASU 2017-12 simplifies existing hedge accounting guidance in order to better portray in financial statements the economic impact of risk management activities in the financial statements, including eliminating the separate measurement and presentation of hedge ineffectiveness. Prior to the adoption of ASU 2017-12, the Company 
wa
s required to separately measure and reflect the amount by which the hedging instrument did not offset the changes in the fair value or cash flows of hedged items, and to record the ineffective portion as earnings. Upon the adoption of ASU 2017-12, the Company is no longer recognize
s
 hedge ineffectiveness as earnings, but instead record
s
 the entire changes in the fair value of the hedged instruments as other comprehensive income. 
Amounts recorded as other comprehensive income are subsequently reclassified to earnings in the same income statement line item that is used to present the earnings effect of the hedged item when the hedged item affects earnings
. See Note 6 for further details.

[0001193125-19-284781:notes:20]
[same as prior period, unchanged from 0001193125-19-139609:notes:188]

[0001193125-19-284781:notes:21]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash and cash equivalents, short-term investments, derivatives
,
 accounts receivable

[0001193125-19-284781:notes:22]
and contract assets

[0001193125-19-284781:notes:23]
.

[0001193125-19-284781:notes:24]
Cash, cash equivalents and short-term investments are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. The Company seeks to mitigate its credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties. The Company limits its 
short-term 
investments in marketable securities to securities with a maturity not in excess of three years and securities that are rated A1, 
P-1,
 F1, or better.

[0001193125-19-284781:notes:25]
The Company enters into derivative contracts with financial institutions with reputable credit and monitors the credit profiles of these counterparties.

[0001193125-19-284781:notes:26]
[same as prior period, unchanged from 0001193125-19-139609:notes:191]

[0001193125-19-284781:notes:27]
New Accounting Pronouncements – not yet adopted by the Company

[0001193125-19-284781:notes:28]
In May 2019, the Financial Accounting Standards Board (“FASB”) issued ASU 
2019-05,
 “Financial Instruments – Credit Losses (Topic 326): Targeted Transition Relief.” The amendments in ASU 
2019-05
 provide entities that have certain instruments within the scope of Subtopic 
326-20
 (“Financial Instruments—Credit Losses—Measured at Amortized Cost”) with an option to irrevocably elect the fair value option in Subtopic 
825-10
 (“Financial Instruments—Overall”), applied on an 
instrument-by-instrument
 basis for eligible instruments, upon adoption of Topic 326. The fair value option election does not apply to 
held-to-maturity
 debt securities. An entity that elects the fair value option should subsequently apply the guidance in Subtopics 
820-10
 (“Fair Value Measurement—Overall”) and 
825-10.
 For public business entities, this update is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. This ASU will be effective for the Company in the first quarter of fiscal 2021. Early adoption is permitted. The Company does not expect this update will impact its condensed consolidated financial statements.

[0001193125-19-284781:notes:29]
In April 2019, 
the 
FASB issued ASU 
2019-04,
 “Codification Improvements to Topic 326, Financial Instruments—Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments.” The amendments in ASU 
2019-04
 apply to all reporting entities within the scope of the affected accounting guidance. For public business entities, this update is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. This ASU will be effective for the Company in the first quarter of fiscal 2021. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.

[0001193125-19-284781:notes:30]
In August 2018, the FASB issued ASU 
2018-13,
 “Fair Value Measurement (Topic 820), Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement.” ASU 
2018-13
 is intended to improve the effectiveness of disclosures in the notes to the financial statements, including (1) the development of a framework that promotes consistent decisions by the FASB about disclosure requirements and (2) the appropriate exercise of discretion by reporting entities. The amendment modifies the disclosure requirements on transferring between level 1 and level 2 and valuation processes of level 3 fair value measurements. This update is effective for all entities for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years, beginning after December 15, 2019. This ASU will be effective for the Company in the first quarter of fiscal 2021. The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.

[0001193125-19-284781:notes:31]
In January 2017, the FASB issued ASU 2017-04, “Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.” ASU 2017-04 modified the concept of impairment assessment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. Public companies that are SEC filers should adopt the amendment for annual and any interim goodwill impairment tests in fiscal years beginning after December 15, 2019. Early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017. This ASU will be effective for the Company in the first quarter of fiscal 2021. The Company does not expect this update will impact its condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001193125-19-284781:notes:32]
| 3. | Revenues from contracts with customers |

[0001193125-19-284781:notes:33]
The Company derives total revenues primarily from the assembly of products under supply agreements with its customers and the fabrication of customized optics and glass. The Company recognizes revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the Company expects to be entitled in exchange for such goods or services. In order to meet this requirement, the Company applies the following five steps: (1) identify the contract with a customer, (2) identify the performance obligations 
under
 the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations 
under
 the contract, and (5) recognize revenue when a performance obligation is satisfied. Revenue is recognized net of any taxes collected from customers, which is subsequently remitted to governmental authorities.

[0001193125-19-284781:notes:34]
A performance obligation is a contractual promise to transfer a distinct good or service to the customer. In contracts with multiple performance obligations, the Company identifies each performance obligation and evaluates whether the performance obligation is distinct within the context of the contract at contract inception. The majority of the Company’s contracts have a single performance obligation as the promise to transfer the individual goods or services is not separately identifiable from other promises under the contracts and, therefore, is not distinct.

[0001193125-19-284781:notes:35]
The Company manufactures products that are customized to customers’ specifications, however, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for overtime recognition are not met. On the evaluation of the contracts the Company determined that it did not have contractual rights to bill profit for work in progress in the event of a contract termination, an event which is expected to be infrequent. Further, in limited circumstances, substantive acceptance by the customer will result in the deferral of revenue until acceptance is formally received from the customer. Judgment may be required in determining if the acceptance clause provides for substantive acceptance.

[0001193125-19-284781:notes:36]
[same as prior period, unchanged from 0001193125-19-139609:notes:151]

[0001193125-19-284781:notes:37]
Our customers generally are obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by our customers within a specified period of time, or that are no longer required due to a product’s cancellation or 
end-of-life,
 are typically designated as excess or obsolete inventory under our contracts. After materials are designated as either excess or obsolete inventory, our customers are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

[0001193125-19-284781:notes:38]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. In determining the transaction price, the Company evaluates whether the price is subject to refund or adjustment to determine the net consideration to which the Company expects to be entitled. The Company generally does not grant return privileges 
other than
 for defective products during the warranty period. 
The Company generally provides a warranty of between one to five years
 on the product.

[0001193125-19-284781:notes:39]
[same as prior period, unchanged from 0001193125-19-139609:notes:154]

[0001193125-19-284781:notes:40]
[same as prior period, unchanged from 0001193125-19-139609:notes:155]

[0001193125-19-284781:notes:41]
[same as prior period, unchanged from 0001193125-19-139609:notes:156]

[0001193125-19-284781:notes:42]
A contract asset is recognized when the Company has recognized revenues prior to 
generating 
an invoice for payment. Contract assets are classified separately on the

[0001193125-19-284781:notes:43]
unaudited condensed

[0001193125-19-284781:notes:44]
consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. During the three-month 
period 
ended September 27, 2019, the Company had no impairment for contract assets recognized.

[0001193125-19-284781:notes:45]
A contract liability is recognized when the Company has advance payment arrangements with customers. The contract liabilities balance is normally recognized as revenue within six months.

[0001193125-19-284781:notes:46]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the three

[0001193125-19-284781:notes:47]
month
s
 ended September 27, 2019:

[0001193125-19-284781:notes:48]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 28, 2019 |  | $ | 12,447 |  |
| Revenue recognized |  |  | 21,653 |  |
| Amounts collected or invoiced |  |  | (22,480 | ) |
| Ending balance, September 27, 2019 |  | $ | 11,620 |  |

[0001193125-19-284781:notes:49]
| (amount in thousands) |  | Contract Liabilities |  |
| Beginning balance, June 28, 2019 |  | $ | 2,239 |  |
| Additions advance payment received during the period |  |  | 2,230 |  |
| Revenue recognized |  |  | (2,203 | ) |
| Ending balance, September 27, 2019 |  | $ | 2,266 |  |

[0001193125-19-284781:notes:50]
[same as prior period, unchanged from 0001193125-19-139609:notes:160]

[0001193125-19-284781:notes:51]
Consistent with the guidance in ASC 
340-40-25-1,
 the incremental costs of obtaining a contract with a customer are recognized as an asset (not expensed as incurred) if 
such 
costs are expected to be recovered. Incremental costs of obtaining a contract are 
costs that
 the Company would not have incurred if the contract had not been obtained (e.g., sales commissions or similar incentive payments linked directly to new or modified customer contracts). Costs that would have been incurred regardless of whether a customer contract was obtained (e.g., costs of pursuing the contact, legal advice, etc.) are expensed as incurred, unless 
such 
costs are explicitly chargeable to the customer. During the three

[0001193125-19-284781:notes:52]
month
s
 ended September 27, 2019, the Company did not have any incremental costs of obtaining a contract.

[0001193125-19-284781:notes:53]
[same as prior period, unchanged from 0001193125-19-139609:notes:162]

[0001193125-19-284781:notes:54]
Shipping costs billed to customers are recorded as revenue. Shipping and handling expense related to costs incurred to deliver product are recognized within cost of goods sold. The Company accounts for shipping and handling activities that occur after control has transferred as a fulfillment cost as opposed to a separate performance obligation, and the costs of shipping and handling are recognized concurrently with the related revenue.

[0001193125-19-284781:notes:55]
[same as prior period, unchanged from 0001193125-19-139609:notes:178]

[0001193125-19-284781:notes:56]
Total revenues are attributed to a particular geographic area based on the
 bill-to-location
 of the 
Company’s

[0001193125-19-284781:notes:57]
customers. The Company operates in three geographic regions: North America, Asia-Pacific and Europe. The following table presents total revenues by geographic region:

[0001193125-19-284781:notes:58]
| (amount in thousands, except percentages) |  | Three Months Ended September 27, 2019 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 200,947 |  |  |  | 50.3 | % |
| Asia-Pacific |  |  | 118,423 |  |  |  | 29.7 |  |
| Europe |  |  | 79,926 |  |  |  | 20.0 |  |
|  |  | $ | 399,296 |  |  |  | 100.0 | % |

[0001193125-19-284781:notes:59]
| (amount in thousands, except percentages) |  | Three Months Ended September 28, 2018 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 179,826 |  |  |  | 47.7 | % |
| Asia-Pacific |  |  | 151,947 |  |  |  | 40.3 |  |
| Europe |  |  | 45,404 |  |  |  | 12.0 |  |
|  |  | $ | 377,177 |  |  |  | 100.0 | % |

[0001193125-19-284781:notes:60]
The following table sets forth our revenues by end market.

[0001193125-19-284781:notes:61]
| (amount in thousands, except percentages) |  | Three Months Ended September 27, 2019 |  |  | As a % of Total Revenues |  |
| Optical communications |  | $ | 302,379 |  |  |  | 75.7 | % |
| Lasers, sensors and other |  |  | 96,917 |  |  |  | 24.3 |  |
| Total |  | $ | 399,296 |  |  |  | 100.0 | % |

[0001193125-19-284781:notes:62]
| (amount in thousands, except percentages) |  | Three Months Ended September 28, 2018 |  |  | As a % of Total Revenues |  |
| Optical communications |  | $ | 280,768 |  |  |  | 74.4 | % |
| Lasers, sensors and other |  |  | 96,409 |  |  |  | 25.6 |  |
| Total |  | $ | 377,177 |  |  |  | 100.0 | % |


## us-gaap:EarningsPerShareTextBlock

[0001193125-19-284781:notes:63]
[same as prior period, unchanged from 0001193125-19-139609:notes:27]

[0001193125-19-284781:notes:64]
Basic earnings per ordinary share is computed by dividing reported net income by the weighted-average number of ordinary shares outstanding during each period. Diluted earnings per ordinary share is computed by calculating the effect of potential dilutive ordinary shares outstanding during the period using the treasury stock method. Dilutive ordinary equivalent shares consist of restricted share units and performance share units. Earnings per ordinary share was calculated as follows:

[0001193125-19-284781:notes:65]
|  |  | Three Months Ended |  |
| (amount in thousands except per share amounts) |  | September 27, 2019 |  |  | September 28, 2018 |  |
| Net income attributable to shareholders |  | $ | 25,957 |  |  | $ | 27,850 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  | 36,913 |  |  |  | 36,625 |  |
| Incremental shares arising from the assumed vesting of restricted share units and performance share units (thousands of shares) |  |  | 616 |  |  |  | 515 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 37,529 |  |  |  | 37,140 |  |
| Basic earnings per ordinary share |  | $ | 0.70 |  |  | $ | 0.76 |  |
| Diluted earnings per ordinary share |  | $ | 0.69 |  |  | $ | 0.75 |  |
| Outstanding performance share units excluded from the computation of diluted earnings per ordinary share (thousands of shares) (1) |  |  | 50 |  |  |  | 351 |  |

[0001193125-19-284781:notes:66]
| (1) | These performance share units were not included in the computation of diluted earnings per ordinary share because they are not expected to vest based on the Company’s current assessment of the related performance obligations. |


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001193125-19-284781:notes:67]
[same as prior period, unchanged from 0001193125-19-139609:notes:91]

[0001193125-19-284781:notes:68]
[same as prior period, unchanged from 0001193125-19-139609:notes:92]

[0001193125-19-284781:notes:69]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Gain/(Loss) |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |  | Other Investments |  |
| As of September 27, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 167,772 |  |  | $ | — |  |  | $ | 167,772 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 763 |  |  |  | — |  |  |  | 763 |  |  |  | — |  |  |  | — |  |
| Liquidity funds |  |  | 20,701 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 20,701 |  |
| Certificates of deposit and time deposits |  |  | 35,020 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 35,020 |  |
| Corporate bonds and commercial papers |  |  | 105,029 |  |  |  | 294 |  |  |  | — |  |  |  | 105,323 |  |  |  | — |  |
| U.S. agency and U.S. treasury securities |  |  | 77,078 |  |  |  | 144 |  |  |  | — |  |  |  | 77,222 |  |  |  | — |  |
| Total |  | $ | 406,363 |  |  | $ | 438 |  |  | $ | 168,535 |  |  | $ | 182,545 |  |  | $ | 55,721 |  |
| As of June 28, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 178,019 |  |  | $ | — |  |  | $ | 178,019 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 2,820 |  |  |  | — |  |  |  | 2,820 |  |  |  | — |  |  |  | — |  |
| Liquidity funds |  |  | 20,552 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 20,552 |  |
| Certificates of deposit and time deposits |  |  | 35,028 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 35,028 |  |
| Corporate bonds and commercial papers |  |  | 130,959 |  |  |  | 297 |  |  |  | — |  |  |  | 131,256 |  |  |  | — |  |
| U.S. agency and U.S. treasury securities |  |  | 69,552 |  |  |  | 105 |  |  |  | — |  |  |  | 69,657 |  |  |  | — |  |
| Total |  | $ | 436,930 |  |  | $ | 402 |  |  | $ | 180,839 |  |  | $ | 200,913 |  |  | $ | 55,580 |  |

[0001193125-19-284781:notes:70]
All highly liquid investments with original maturities of three months or less at the date of purchase are classified as cash equivalents. Management determines the appropriate classification of its investments at the time of purchase and re-evaluates the designations at each balance sheet date. The Company may sell certain of its short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s short-term investments generally range from three months to three years. 
The Company’s short-term investments consist of U.S. Treasuries and fixed income securities and have been classified and accounted for as
 available-for-sale.

[0001193125-19-284781:notes:71]
The following table summarizes the cost and estimated fair value of 
short-term investments 
classified as 
available-for-sale 
 securities based on stated effective maturities as of September 27, 2019:

[0001193125-19-284781:notes:72]
|  |  | September 27, 2019 |  |  | June 29, 2018 |  |
| (amount in thousands) |  | Carrying Cost |  |  | Fair Value |  |  | Carrying Cost |  |  | Fair Value |  |
| Due within one year |  | $ | 55,726 |  |  | $ | 55,786 |  |  | $ | 69,746 |  |  | $ | 69,830 |  |
| Due between one to five years |  |  | 126,381 |  |  |  | 126,759 |  |  |  | 130,765 |  |  |  | 131,083 |  |
| Total |  | $ | 182,107 |  |  | $ | 182,545 |  |  | $ | 200,511 |  |  | $ | 200,913 |  |

[0001193125-19-284781:notes:73]
During the three months ended September 27, 2019, the Company recognized a realized gain of $67 
thousands
 from sales and maturities of 
available-for-sale
 securities.

[0001193125-19-284781:notes:74]
As of September 27, 2019, the Company considered the declines in market value of its short-term investments portfolio to be temporary in nature and did not consider any of its securities other-than-temporarily impaired. The Company typically invests in highly-rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy requires investments generally to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. When evaluating an investment for other-than-temporary impairment, the Company reviews factors such as the length of time and extent to which fair value has been below its cost basis, the financial condition of the issuer and any changes thereto, changes in market interest rates, and the Company’s intent to sell, or whether it is more likely than not it will be required to sell, the investment before recovery of the investment’s cost basis. No impairment losses were recorded for the three months ended September 27, 2019.


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-19-284781:notes:75]
| 6. | Fair value of financial instruments |

[0001193125-19-284781:notes:76]
[same as prior period, unchanged from 0001193125-19-139609:notes:120]

[0001193125-19-284781:notes:77]
[same as prior period, unchanged from 0001193125-19-139609:notes:121]

[0001193125-19-284781:notes:78]
[same as prior period, unchanged from 0001193125-19-139609:notes:122]

[0001193125-19-284781:notes:79]
[same as prior period, unchanged from 0001193125-19-139609:notes:123]

[0001193125-19-284781:notes:80]
[same as prior period, unchanged from 0001193125-19-139609:notes:124]

[0001193125-19-284781:notes:81]
[same as prior period, unchanged from 0001193125-19-139609:notes:125]

[0001193125-19-284781:notes:82]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of September 27, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 763 |  |  | $ | — |  |  | $ | 763 |  |
| Liquidity funds |  |  | — |  |  |  | 20,701 |  |  |  | — |  |  |  | 20,701 |  |
| Certificates of deposit and time deposits |  |  | — |  |  |  | 35,020 |  |  |  | — |  |  |  | 35,020 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 105,323 |  |  |  | — |  |  |  | 105,323 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 77,222 |  |  |  | — |  |  |  | 77,222 |  |
| Derivative assets |  |  | — |  |  |  | 298 | (1) |  |  | — |  |  |  | 298 |  |
| Total |  | $ | — |  |  | $ | 239,327 |  |  | $ | — |  |  | $ | 239,327 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 4,223 | (2) |  | $ | — |  |  | $ | 4,223 |  |
| Total |  | $ | — |  |  | $ | 4,223 |  |  | $ | — |  |  | $ | 4,223 |  |
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 28, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 2,820 |  |  | $ | — |  |  | $ | 2,820 |  |
| Liquidity funds |  |  | — |  |  |  | 20,552 |  |  |  | — |  |  |  | 20,552 |  |
| Certificates of deposit and time deposits |  |  | — |  |  |  | 35,028 |  |  |  | — |  |  |  | 35,028 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 131,256 |  |  |  | — |  |  |  | 131,256 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 69,657 |  |  |  | — |  |  |  | 69,657 |  |
| Derivative assets |  |  | — |  |  |  | 2,201 | (3) |  |  | — |  |  |  | 2,201 |  |
| Total |  | $ | — |  |  | $ | 261,514 |  |  | $ | — |  |  | $ | 261,514 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 2,591 | (4) |  | $ | — |  |  | $ | 2,591 |  |
| Total |  | $ | — |  |  | $ | 2,591 |  |  | $ | — |  |  | $ | 2,591 |  |

[0001193125-19-284781:notes:83]
| (1) | Foreign currency forward contracts with a notional amount of $74.0 million. |

[0001193125-19-284781:notes:84]
| (2) | Two interest rate swap agreements with an aggregate notional amount of $125.1 million. |

[0001193125-19-284781:notes:85]
| (3) | Foreign currency forward contracts with notional amount of $72.0 million and Canadian dollars 0.6 million. |

[0001193125-19-284781:notes:86]
| (4) | Interest rate swap agreement with a notional amount of $64.2 million. |

[0001193125-19-284781:notes:87]
[same as prior period, unchanged from 0001193125-19-139609:notes:129]

[0001193125-19-284781:notes:88]
The Company utilizes derivative financial instruments to hedge (i) foreign exchange risk associated with certain foreign currency denominated assets and liabilities and other foreign currency transactions, and (ii) interest rate risk associated with 
its
 long-term debt.

[0001193125-19-284781:notes:89]
The Company minimizes the credit risk associated with its derivative instruments by limiting the exposure to any single counterparty and by entering into derivative instruments only with counterparties that meet the Company’s minimum credit quality standard.

[0001193125-19-284781:notes:90]
Foreign Currency 
Forward 
Contracts

[0001193125-19-284781:notes:91]
As a result of foreign currency rate fluctuations, the U.S. dollar equivalent values of the Company’s foreign currency denominated assets and liabilities also fluctuate. The Company uses foreign currency contracts to manage the foreign exchange risk associated with certain foreign currency denominated assets and liabilities and other foreign currency transactions.

[0001193125-19-284781:notes:92]
The Company enters into foreign currency 
forward 
contracts to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht and Canadian dollars.

[0001193125-19-284781:notes:93]
As of September 27, 2019, the Company had sixty-one outstanding foreign currency forward contracts with an aggregate notional amount

[0001193125-19-284781:notes:94]
o
f

[0001193125-19-284781:notes:95]
$74.0

[0001193125-19-284781:notes:96]
million with maturity dates from October 2019 through January 2020. These foreign currency forward contracts were not designated for hedge accounting and were used to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht. During the three months 
period

[0001193125-19-284781:notes:97]
ended

[0001193125-19-284781:notes:98]
September 27, 2019, the Company

[0001193125-19-284781:notes:99]
recorded unrealized loss of $1.9 million from changes in the fair value of foreign currency contracts in earnings as foreign exchange gain, net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-19-284781:notes:100]
As of September 28, 2018, the Company had three outstanding foreign currency forward contracts with a
n aggregate
 notional amount of $6.0 million, and six outstanding foreign currency option contracts with a
n aggregate
 notional amount of $19.0 million with maturity dates from 
October through 
December 2018

[0001193125-19-284781:notes:101]
. These foreign currency forward contracts and option contracts were not designated for hedge accounting and were used to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht. During the three months ended September 28, 2018, the Company

[0001193125-19-284781:notes:102]
included unrealized gain of

[0001193125-19-284781:notes:103]
$2.8 million from changes in the fair value of foreign currency contracts in earnings as foreign exchange gain, net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-19-284781:notes:104]
Interest Rate Swap Agreement
s

[0001193125-19-284781:notes:105]
The Company enter
ed
 into interest rate swap agreements to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. As of September 27, 2019, the Company had two outstanding interest rate swap agreements with a
n aggregate
 notional amount of $
125.1
 million

[0001193125-19-284781:notes:106]
. As of September 28, 2018, the Company had one outstanding interest rate swap agreement with a notional amount of $64.2 million.

[0001193125-19-284781:notes:107]
On July 25, 2018,

[0001193125-19-284781:notes:108]
Fabrinet Thailand

[0001193125-19-284781:notes:109]
entered into an interest rate swap agreement to effectively convert the floating interest rate of its term loan under the Bank of America Credit Facility Agreement to a fixed interest rate of 2.86% per annum through the scheduled maturity of the term loan in June 2023 (see Note

[0001193125-19-284781:notes:110]
13). The Company did not designate this interest rate swap for hedge accounting.

[0001193125-19-284781:notes:111]
On September 3, 2019, the Company entered into a new term loan agreement under a Credit Facility Agreement with the Bank of Ayudhya Public Company Limited

[0001193125-19-284781:notes:112]
(the “Bank”)

[0001193125-19-284781:notes:113]
(see Note 13) and on September 10, 2019, repaid in full

[0001193125-19-284781:notes:114]
the outstanding term loan under the Bank of America Credit Facility (see Note 13). In conjunction with the funding of the new term loan, the Company entered into a second interest rate swap agreement. The combination of both of these interest rate swaps effectively convert the floating interest rate of the Company’s new term loan with the Bank to a fixed interest rate of

[0001193125-19-284781:notes:115]
4.36% per annum through the maturity of the term loan in June 2024.

[0001193125-19-284781:notes:116]
On September 27, 2019, the Company designated these two interest rate swaps as a cash flow hedge for the Company’s term loan under the Credit Facility Agreement with the Bank. The combination of these two interest rate swaps

[0001193125-19-284781:notes:117]
qualif
ied
 for hedge accounting 
bec
a
use
 the hedges are highly effective, and 
the Company has
 designated and documented contemporaneously the hedging relationships involving these interest rate swaps. While we intend to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in our earnings. From September 27, 2019, any gains or losses related to these interest rate swaps will be recorded in accumulated other comprehensive income in the

[0001193125-19-284781:notes:118]
unaudited condensed consolidated balance

[0001193125-19-284781:notes:119]
sheets, 
and 
the Company will reclassify a portion of the gains or losses from accumulated other comprehensive income into earnings at each reporting period based on either the accrued interest amount or the interest payment.

[0001193125-19-284781:notes:120]
The following table provides a summary of the impacts of derivative gain (loss) of our cash flow hedges on the 
una
u
dited 
condensed consolidated statements of operations and other comprehensive income:

[0001193125-19-284781:notes:121]
|  |  |  |  | Three Months Ended |  |
| (amount in thousands) |  | Financial statements line item |  | September 27, 2019 |  |  | September 28, 2018 |  |
| Derivatives gain (loss) recognized in other comprehensive income: |  |  |  |  |  |  |  |  |  |  |
| Interest rate swaps |  | Other comprehensive income |  | $ | 39 |  |  | $ | — |  |
| Derivatives gain (loss) reclassified from other comprehensive income into earnings: |  |  |  |  |  |  |  |  |  |  |
| Interest rate swaps |  | Interest expenses |  |  | — |  |  |  | — |  |

[0001193125-19-284781:notes:122]
Prior to September 27, 2019, these interest rate swaps were not designated as cash flow hedges
.

[0001193125-19-284781:notes:123]
A
ll changes in the fair value of these interest rate swaps was reflected in earnings. During the three months ended September 27, 2019 and September 28, 2018, the Company recorded unrealized

[0001193125-19-284781:notes:124]
loss
 of

[0001193125-19-284781:notes:125]
$1.7 million and 
unrealized gain of 
$0.1 million, respectively, from changes in the fair value of these interest rate swaps as interest expense in the 
unaudited 
condensed consolidated statements of operations and comprehensive income.

[0001193125-19-284781:notes:126]
Fair Value

[0001193125-19-284781:notes:127]
The following table provides the fair values of our derivative financial instruments for the periods presented:

[0001193125-19-284781:notes:128]
|  |  | September 27, 2019 |  |  | June 28, 2019 |  |
| (amount in thousands) |  | Derivative Assets |  |  | Derivative Liabilities |  |  | Derivative Assets |  |  | Derivative Liabilities |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | 340 |  |  | $ | (42 | ) |  | $ | 2,201 |  |  | $ | — |  |
| Interest rate swaps |  |  | — |  |  |  | — |  |  | $ | — |  |  | $ | (2,591 | ) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swaps |  |  | — |  |  |  | (4,223 | ) |  | $ | — |  |  | $ | — |  |
| Gross amounts of derivatives |  |  | 340 |  |  |  | (4,265 | ) |  | $ | 2,201 |  |  | $ | (2,591 | ) |
| Gross amounts of derivatives offset in the balance sheet |  |  | (42 | ) |  |  | 42 |  |  | $ | — |  |  | $ | — |  |
| Net amounts of derivatives |  | $ | 298 |  |  | $ | (4,223 | ) |  | $ | 2,201 |  |  | $ | (2,591 | ) |

[0001193125-19-284781:notes:129]
The Company recorded fair value of derivative financial instrument in unaudited condensed consolidated balance sheets as followings:

[0001193125-19-284781:notes:130]
| Derivative Financial Instruments |  | Financial statements line item |
| Fair Value of Derivative Assets |  | Other current assets |
| Fair Value of Derivative Liabilities |  | Accrued expenses |

[0001193125-19-284781:notes:131]
Settlement

[0001193125-19-284781:notes:132]
Our derivative instruments are typically settled monthly or quarterly. The following table presents cash settlements (paid) received related to the below derivative instruments:

[0001193125-19-284781:notes:133]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 27, 2019 |  |  | September 28, 2018 |  |
| Foreign currency forward contract |  | $ | — |  |  | $ | — |  |
| Interest rate swaps |  |  | (57 | ) |  |  | (82 | ) |
| Total |  | $ | (57 | ) |  | $ | (82 | ) |


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001193125-19-284781:notes:134]
| 7. | Trade accounts receivable, net |

[0001193125-19-284781:notes:135]
| (amount in thousands) |  | As of September 27, 2019 |  |  | As of June 28, 2019 |  |
| Trade accounts receivable |  | $ | 273,707 |  |  | $ | 260,698 |  |
| Less: allowance for doubtful account |  |  | (91 | ) |  |  | (96 | ) |
| Trade accounts receivable, net |  | $ | 273,616 |  |  | $ | 260,602 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-19-284781:notes:136]
| 8. | Inventory |

[0001193125-19-284781:notes:137]
| (amount in thousands) |  | As of September 27, 2019 |  |  | As of June 28, 2019 |  |
| Raw materials |  | $ | 133,574 |  |  | $ | 115,008 |  |
| Work-in-progress |  |  | 151,518 |  |  |  | 142,039 |  |
| Finished goods |  |  | 26,039 |  |  |  | 24,916 |  |
| Goods in transit |  |  | 12,112 |  |  |  | 13,645 |  |
|  |  |  | 323,243 |  |  |  | 295,608 |  |
| Less: Inventory obsolescence |  |  | (1,732 | ) |  |  | (1,996 | ) |
| Inventory, net |  | $ | 321,511 |  |  | $ | 293,612 |  |


## fn:RestrictedCashAndCashEquivalentsTextBlock

[0001193125-19-284781:notes:138]
| 9. | Restricted cash |

[0001193125-19-284781:notes:139]
As of September 27, 2019 and June 28, 2019, the Company had 
two
 outstanding standby letter
s
 of credit

[0001193125-19-284781:notes:140]
o

[0001193125-19-284781:notes:141]
f

[0001193125-19-284781:notes:142]
22.2 million Euros

[0001193125-19-284781:notes:143]
and

[0001193125-19-284781:notes:144]
one outstanding standby letter of credit of

[0001193125-19-284781:notes:145]
6.0 million

[0001193125-19-284781:notes:146]
Euros, respectively, related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand.

[0001193125-19-284781:notes:147]
As of September 27, 2019 and June 28, 2019, the standby letters of credit were backed by cash collateral of

[0001193125-19-284781:notes:148]
$29.6 million and $
7.4 
million, respectively.


## fn:ScheduleOfAdoptionOfTopic842OnOperatingLeaseInConsolidateFinancialPositionTableTextBlock

[0001193125-19-284781:notes:149]
The following table shows the impact of adoption of ASC 842 on the adoption date of June 29, 2019 on the consolidated balance sheets:

[0001193125-19-284781:notes:150]
Consolidated Balance Sheets

[0001193125-19-284781:notes:151]
|  |  | Impact of Adopting ASC 842 |  |
| (amount in thousands) |  | Balance at June 28, 2019 |  |  | Adjustment |  |  | Balance at June 29, 2019 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating lease ROU assets |  | $ | — |  |  | $ | 5,370 |  |  | $ | 5,370 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating lease liabilities – current |  | $ | — |  |  | $ | 1,601 |  |  | $ | 1,601 |  |
| Operating lease liabilities – non current |  | $ | — |  |  | $ | 3,769 |  |  | $ | 3,769 |  |


## us-gaap:LesseeOperatingLeaseLiabilityMaturityTableTextBlock

[0001193125-19-284781:notes:152]
As of September 27, 2019, the maturities of the Company’s operating lease liabilities are as follows:

[0001193125-19-284781:notes:153]
| (amount in thousands) |  |  |  |
| 2020 (remaining nine months) |  | $ | 1,323 |  |
| 2021 |  |  | 1,669 |  |
| 2022 |  |  | 1,520 |  |
| 2023 |  |  | 1,427 |  |
| 2024 |  |  | 495 |  |
| Thereafter |  |  | 279 |  |
| Total undiscounted lease payments |  |  | 6,713 |  |
| Less Imputed interest |  |  | (528 | ) |
| Total present value of lease liabilities |  | $ | 6,185 | (1) |

[0001193125-19-284781:notes:154]
| (1) | Included current portion of operating lease liabilities of $1.6 million. |


## fn:ScheduleOfAdditionalInformationRelatedToOperatingAndFinanceLeaseTableTextBlock

[0001193125-19-284781:notes:155]
As of September 27, 2019, the future minimum lease payments under 
non-cancelable
 capital leases during each fiscal year were as follows:

[0001193125-19-284781:notes:156]
| (amount in thousands) |  |  |  |
| 2020 |  | $ | 300 |  |
| 2021 |  |  | 100 |  |
| Total minimum capital lease payments |  |  | 400 |  |
| Less: Future finance charge on capital leases |  |  | (9 | ) |
| Present value of capital lease |  | $ | 391 |  |
| Representing capital lease liabilities |  |  |  |  |
| Current |  | $ | 391 |  |
| Non-current |  |  | — |  |
| Total capital lease liabilities |  | $ | 391 |  |

[0001193125-19-284781:notes:157]
As of September 27, 2019, the present value of capital lease
s
 during each fiscal year w
as
 as follows:

[0001193125-19-284781:notes:158]
| (amount in thousands) |  |  |  |
| 2020 |  | $ | 292 |  |
| 2021 |  |  | 99 |  |
| Present value of capital lease |  | $ | 391 |  |

[0001193125-19-284781:notes:159]
The following summarizes additional information related to the Company’s operating leases and capital leases:

[0001193125-19-284781:notes:160]
|  |  | As of September 27, 2019 |  |
| Weighted-average remaining lease term (in years) |  |  |  |  |
| Operating leases |  |  | 4.4 |  |
| Capital leases |  |  | 1.0 |  |
| Weighted-average discount rate |  |  |  |  |
| Operating leases |  |  | 3.9 | % |
| Capital leases |  |  | 4.1 | % |


## fn:ScheduleOfSupplementalCashFlowInformationRelatedToOperatingLeaseTableTextBlock

[0001193125-19-284781:notes:161]
T
he following information represents supplemental disclosure for the statement of cash flows related to operating and capital leases for the three months ended September 27, 2019:

[0001193125-19-284781:notes:162]
| (amount in thousands) |  | Three Months Ended September 27, 2019 |  |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |
| Operating cash flows from operating leases |  | $ | 458 |  |
| Financing cash flows from capital leases |  | $ | 109 |  |
| ROU assets obtained in exchange for lease liabilities |  | $ | 6,185 |  |
| Capital lease assets |  | $ | 317 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-19-284781:notes:163]
| 11. | Intangibles |

[0001193125-19-284781:notes:164]
[same as prior period, unchanged from 0001193125-19-139609:notes:140]

[0001193125-19-284781:notes:165]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net |  |
| As of September 27, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 6,698 |  |  | $ | (5,004 | ) |  | $ | — |  |  | $ | 1,694 |  |
| Customer relationships |  |  | 4,373 |  |  |  | (2,253 | ) |  |  | (153 | ) |  |  | 1,967 |  |
| Backlog |  |  | 119 |  |  |  | (119 | ) |  |  | — |  |  |  | — |  |
| Total intangibles |  | $ | 11,190 |  |  | $ | (7,376 | ) |  | $ | (153 | ) |  | $ | 3,661 |  |

[0001193125-19-284781:notes:166]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net |  |
| As of June 28, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 6,582 |  |  | $ | (4,868 | ) |  | $ | — |  |  | $ | 1,714 |  |
| Customer relationships |  |  | 4,373 |  |  |  | (2,096 | ) |  |  | (104 | ) |  |  | 2,173 |  |
| Backlog |  |  | 119 |  |  |  | (119 | ) |  |  | — |  |  |  | — |  |
| Total intangibles |  | $ | 11,074 |  |  | $ | (7,083 | ) |  | $ | (104 | ) |  | $ | 3,887 |  |

[0001193125-19-284781:notes:167]
The Company recorded amortization expense relating to intangibles of $0.3 million and $0.3 million for the three months ended September 27, 2019 and September 28, 2018, respectively.

[0001193125-19-284781:notes:168]
The weighted-average remaining life of customer relationships 
was
:

[0001193125-19-284781:notes:169]
| (years) |  | As of September 27, 2019 |  |  | As of June 28, 2019 |  |
| Customer relationships |  |  | 5.2 |  |  |  | 5.4 |  |

[0001193125-19-284781:notes:170]
Based on the carrying amount of intangibles as of September 27, 2019, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001193125-19-284781:notes:171]
| (amount in thousands) |  |  |  |
| 2020 (remaining nine months) |  | $ | 862 |  |
| 2021 |  |  | 1,020 |  |
| 2022 |  |  | 784 |  |
| 2023 |  |  | 516 |  |
| 2024 |  |  | 288 |  |
| Thereafter |  |  | 191 |  |
| Total |  | $ | 3,661 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-19-284781:notes:172]
| 12. | Goodwill |

[0001193125-19-284781:notes:173]
[same as prior period, unchanged from 0001193125-19-139609:notes:112]

[0001193125-19-284781:notes:174]
| (amount in thousands) |  | Goodwill |  |
| Balance as of June 28, 2019 |  | $ | 3,705 |  |
| Foreign currency translation adjustment |  |  | (102 | ) |
| Balance as of September 27, 2019 |  | $ | 3,603 |  |

[0001193125-19-284781:notes:175]
| (amount in thousands) |  | Goodwill |  |
| Balance as of June 29, 2018 |  | $ | 3,828 |  |
| Foreign currency translation adjustment |  |  | (6 | ) |
| Balance as of September 28, 2018 |  | $ | 3,822 |  |

[0001193125-19-284781:notes:176]
[same as prior period, unchanged from 0001193125-19-139609:notes:114]


## us-gaap:DebtDisclosureTextBlock

[0001193125-19-284781:notes:177]
| 13. | Borrowings |

[0001193125-19-284781:notes:178]
The Company’s total borrowings, including current
 portion

[0001193125-19-284781:notes:179]
and 
non-current
 portion of

[0001193125-19-284781:notes:180]
long-term borrowings, consisted of the following:

[0001193125-19-284781:notes:181]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  | Maturity |  |  | As ofSeptember 27,2019 |  |  | As ofJune 28,2019 |  |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  |  |  |  | $ | 12,188 |  |  | $ | 3,250 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  |  |  |  |  | (31 | ) |  |  | — |  |
| Long-term borrowings, current portion, net |  |  |  |  |  |  |  | $ | 12,157 |  |  |  | 3,250 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1-month LIBOR +1.50% per annum (1) |  | Repayable in quarterly installments |  |  | June 2023 |  |  | $ | — |  |  | $ | 60,938 |  |
| 3-month LIBOR +1.35% per annum (1) |  | Repayable in quarterly installments |  |  | June 2024 |  |  |  | 60,938 |  |  |  | — |  |
| Less: Current portion |  |  |  |  |  |  |  |  | (12,188 | ) |  |  | (3,250 | ) |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  |  |  |  |  | (119 | ) |  |  | — |  |
| Long-term borrowings, non-current portion, net |  |  |  |  |  |  |  | $ | 48,631 |  |  | $ | 57,688 |  |

[0001193125-19-284781:notes:182]
| (1) | We have entered into interest rate swaps that effectively fix a series of our future interest payments on our term loans. Refer to Note 6. |

[0001193125-19-284781:notes:183]
The movements of long-term borrowings for the three months ended September 27, 2019 and September 28, 2018 were as follows:

[0001193125-19-284781:notes:184]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 27, 2019 |  |  | September 28, 2018 |  |
| Opening balance |  | $ | 60,938 |  |  | $ | 64,188 |  |
| Borrowings during the period |  |  | 60,938 |  |  |  | — |  |
| Repayments during the period |  |  | (60,938 | ) |  |  | (813 | ) |
| Closing balance |  | $ | 60,938 |  |  | $ | 63,375 |  |

[0001193125-19-284781:notes:185]
As of September 27, 2019, future maturities of long-term borrowings during each fiscal year were as follows:

[0001193125-19-284781:notes:186]
| (amount in thousands) |  |  |  |
| 2020 (remaining nine months) |  | $ | 9,140 |  |
| 2021 |  |  | 12,188 |  |
| 2022 |  |  | 15,234 |  |
| 2023 |  |  | 12,188 |  |
| 2024 |  |  | 12,188 |  |
| Total |  | $ | 60,938 |  |

[0001193125-19-284781:notes:187]
Credit facility agreements:

[0001193125-19-284781:notes:188]
Bank of Ayudhya Public Company Limited

[0001193125-19-284781:notes:189]
On August 20, 2019, Fabrinet Thailand (the “Borrower”), and 
the 
Bank entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai Baht

[0001193125-19-284781:notes:190]
(approximately $
3.6
 million based on the applicable exchange rate as of September 
27
, 
2019)
 and $
160.9

[0001193125-19-284781:notes:191]
million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

[0001193125-19-284781:notes:192]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a Term Loan Agreement pursuant to which the Borrower 
drew down
 on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company’s 
pre-existing
 credit facility agreement between the Company and Bank of America, N.A.

[0001193125-19-284781:notes:193]
The term loan accrues interest at 
3-month LIBOR plus 1.35%
 and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan matures on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be 
re-borrowed. 
 During the three months ended September 27, 2019, the Company recorded $0.2 
million
 of interest expense in connection with this term loan.

[0001193125-19-284781:notes:194]
Any borrowings under the Credit Facility Agreement, including those borrowing under the Term Loan Agreement are guaranteed by

[0001193125-19-284781:notes:195]
Fabrinet

[0001193125-19-284781:notes:196]
and secured by land and buildings in Pathumthani and Chonburi Provinces owned by the Borrower in Thailand.

[0001193125-19-284781:notes:197]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt to equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. At September 27, 2019, the Company was in compliance with all of its covenants under the Term Loan Agreement
.

[0001193125-19-284781:notes:198]
The events of default in the Term Loan Agreement include failure to pay amounts due under the Term Loan Agreement or the related finance documents when due, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

[0001193125-19-284781:notes:199]
At September 27, 2019, there was $
60.9 
million outstanding under the term loan.

[0001193125-19-284781:notes:200]
Bank of America, N.A.

[0001193125-19-284781:notes:201]
On May 22, 2014, the Company and

[0001193125-19-284781:notes:202]
a
 consortium

[0001193125-19-284781:notes:203]
of

[0001193125-19-284781:notes:204]
banks

[0001193125-19-284781:notes:205]
entered into a syndicated senior credit facility agreement

[0001193125-19-284781:notes:206]
led by Bank of America

[0001193125-19-284781:notes:207]
(the “Bank of America Facility Agreement”). The Bank of America Facility Agreement provided for a $200.0 million credit line, comprised of a $150.0 million revolving loan facility and a $50.0 million delayed draw term loan facility.

[0001193125-19-284781:notes:208]
From time to time, we amended the Bank of America Facility Agreement, before repaying all outstanding amounts under the agreement and terminating such agreement on 
September 10, 2019
.

[0001193125-19-284781:notes:209]
The most recent amendment on June 4, 2018, (i)

[0001193125-19-284781:notes:210]
reduced

[0001193125-19-284781:notes:211]
the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) refinanced the outstanding amounts under the revolving loan and term loan facilities into a $65.0 million term loan which was to be repaid in quarterly installments through the maturity date of June 4, 2023; and (iii) reduced the interest rate margins and commitment fees. The term loan bore interest, at the Company’s option, at a rate per annum equal to a 
LIBOR rate plus a spread of 1.50% to 2.25%
, or a 
base rate plus a spread of 0.50% to 1.25%
. During the three months ended September 27, 2019 and September 28, 2018, the Company recorded $0.5 
million 
and $
0.7

[0001193125-19-284781:notes:212]
million
, respectively, of interest expense in connection with this term loan.

[0001193125-19-284781:notes:213]
During the three months ended September 27, 2019, the Company fully repaid $61.0 million in principal, accrued interest and other fees under the agreement. The early termination of this agreement did not trigger any early termination fees. At September 27, 2019, there were no amounts outstanding under the Bank of America Facility Agreement. At June 28, 2019, there was $60.9 million outstanding under the Bank of America Facility Agreement, related to the term loan.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-19-284781:notes:214]
| 14. | Income taxes |

[0001193125-19-284781:notes:215]
As of September 27, 2019 and June 28, 2019, the liability for uncertain tax positions including accrued interest and penalties was $2.2 million and $2.1 million, respectively. The Company expects the estimated amount of liability associated with its uncertain tax positions to decrease within the next 12 months due to the lapse of the applicable statute of limitations in foreign tax jurisdictions.

[0001193125-19-284781:notes:216]
The Company files income tax returns in the United States and foreign tax jurisdictions. The tax years from 2014 to 2018 remain open to examination by U.S. federal and state, and foreign tax authorities. The Company’s income tax is recognized based on the best estimate of the expected annual effective tax rate for the full financial year of each entity in the Company, adjusted for discrete items arising in that quarter. If the Company’s estimated annual effective tax rate changes, the Company makes a cumulative adjustment in that quarter.

[0001193125-19-284781:notes:217]
The effective tax rate for the Company for the three months ended September 27, 2019 and September 28, 2018 was 5.0% and 6.7%, respectively, of net income. The decrease was primarily due to the fact that the Company had lower income subject to tax during the first quarter of fiscal year 2020 as compared to the same period in fiscal year 2019.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-19-284781:notes:218]
| 15. | Share-based compensation |

[0001193125-19-284781:notes:219]
[same as prior period, unchanged from 0001193125-19-139609:notes:65]

[0001193125-19-284781:notes:220]
The grant date fair value of restricted share units and performance share units is based on the market value of our ordinary shares on the date of grant.

[0001193125-19-284781:notes:221]
The effect of recording share-based compensation expense for the three months ended September 27, 2019 and September 28, 2018 was as follows:

[0001193125-19-284781:notes:222]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 27, 2019 |  |  | September 28, 2018 |  |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |  |
| Restricted share units |  | $ | 4,398 |  |  | $ | 4,685 |  |
| Performance share units |  |  | 1,597 |  |  |  | 295 |  |
| Total share-based compensation expense |  |  | 5,995 |  |  |  | 4,980 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 5,995 |  |  | $ | 4,980 |  |

[0001193125-19-284781:notes:223]
Share-based compensation expense was recorded in the unaudited condensed consolidated statements of operations and comprehensive income as follows:

[0001193125-19-284781:notes:224]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 27, 2019 |  |  | September 28, 2018 |  |
| Cost of revenue |  | $ | 1,720 |  |  | $ | 1,847 |  |
| Selling, general and administrative expense |  |  | 4,275 |  |  |  | 3,133 |  |
| Total share-based compensation expense |  | $ | 5,995 |  |  | $ | 4,980 |  |

[0001193125-19-284781:notes:225]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the three months ended September 27, 2019 and September 28, 2018.

[0001193125-19-284781:notes:226]
[same as prior period, unchanged from 0001193125-19-139609:notes:72]

[0001193125-19-284781:notes:227]
Fabrinet maintains the following equity incentive plans: the Amended and Restated 2010 Performance Incentive Plan (the “2010 Plan”) and the 2017 Inducement Equity Incentive Plan (the “2017 Inducement Plan”). The 2010 Plan and 2017 Inducement Plan are collectively referred to as the “Equity Incentive Plans”.

[0001193125-19-284781:notes:228]
As of September 27, 2019, there were an aggregate of 806,573 restricted share units outstanding and 436,304 performance share units outstanding under the 2010 Plan. As of September 27, 2019, there were 1,302,154 ordinary shares available for future grant under the 2010 Plan.

[0001193125-19-284781:notes:229]
On November 2, 2017,

[0001193125-19-284781:notes:230]
the Company

[0001193125-19-284781:notes:231]
adopted the 2017 Inducement Plan with a reserve of 160,000 ordinary shares authorized for future issuance solely for the granting of inducement share options and equity awards to new employees. The 2017 Inducement Plan was adopted without shareholder approval in reliance on the “employment inducement exemption” provided under the New York Stock Exchange Listed Company Manual. As of September 27, 2019, there were an aggregate of 24,327 restricted share units outstanding under the 2017 Inducement Plan. As of September 27, 2019, there were 111,347 ordinary shares available for future grant under the 2017 Inducement Plan.

[0001193125-19-284781:notes:232]
[same as prior period, unchanged from 0001193125-19-139609:notes:81]

[0001193125-19-284781:notes:233]
[same as prior period, unchanged from 0001193125-19-139609:notes:82]

[0001193125-19-284781:notes:234]
Restricted share units granted to employees generally vest in equal installments over three or 
four years 
on each anniversary of the vesting commencement date. Restricted share units granted to 
non-employee
 directors generally cliff vest 100% on the first of January, approximately one year from the grant date, provided the director continues to serve through such date.

[0001193125-19-284781:notes:235]
Performance share units granted to executives will vest, if at all, at the end of a 
two-year
 performance period based on the Company’s achievement of 
pre-defined
 performance criteria, which consist of revenue and 
n
on-
GAAP

[0001193125-19-284781:notes:236]
gross margin 
or operating margin t
argets. The actual number of performance share units that may vest at the end of the performance period ranges from 0% to 100% of the award grant.

[0001193125-19-284781:notes:237]
The following table summarizes restricted share unit activity under the Equity Incentive Plans:

[0001193125-19-284781:notes:238]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 28, 2019 |  |  | 800,751 |  |  | $ | 42.48 |  |
| Granted |  |  | 292,321 |  |  | $ | 48.39 |  |
| Issued |  |  | (240,595 | ) |  | $ | 39.62 |  |
| Forfeited |  |  | (21,577 | ) |  | $ | 42.00 |  |
| Balance as of September 27, 2019 |  |  | 830,900 |  |  | $ | 45.40 |  |

[0001193125-19-284781:notes:239]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 29, 2018 |  |  | 1,073,580 |  |  | $ | 35.19 |  |
| Granted |  |  | 255,821 |  |  | $ | 48.02 |  |
| Issued |  |  | (369,757 | ) |  | $ | 34.34 |  |
| Forfeited |  |  | (29,845 | ) |  | $ | 38.32 |  |
| Balance as of September 28, 2018 |  |  | 929,799 |  |  | $ | 38.95 |  |

[0001193125-19-284781:notes:240]
The following table summarizes performance share unit activity under the Equity Incentive Plans:

[0001193125-19-284781:notes:241]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 28, 2019 |  |  | 548,500 |  |  | $ | 40.97 |  |
| Granted |  |  | 238,474 |  |  | $ | 48.39 |  |
| Issued |  |  | — |  |  |  | — |  |
| Forfeited |  |  | (350,670 | ) |  | $ | 36.99 |  |
| Balance as of September 27, 2019 |  |  | 436,304 |  |  | $ | 48.22 |  |

[0001193125-19-284781:notes:242]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 29, 2018 |  |  | 605,892 |  |  | $ | 38.41 |  |
| Granted |  |  | 201,994 |  |  | $ | 48.02 |  |
| Issued |  |  | (227,268 | ) |  | $ | 40.48 |  |
| Forfeited |  |  | (27,954 | ) |  | $ | 39.35 |  |
| Balance as of September 28, 2018 |  |  | 552,664 |  |  | $ | 41.02 |  |

[0001193125-19-284781:notes:243]
The fair value of restricted share units and performance share units is based on the market value of our ordinary shares on the date of grant.

[0001193125-19-284781:notes:244]
As of September 27, 2019, there was $20.2 million and $11.3 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the

[0001193125-19-284781:notes:245]
Equity Incentive Plans

[0001193125-19-284781:notes:246]
that is expected to be recorded over a weighted-average period of 2.9 years and 1.7 years, respectively.

[0001193125-19-284781:notes:247]
For the three months ended September 27, 2019 and September 28, 2018, the Company withheld an aggregate of 82,220 shares and 201,877 shares, respectively, upon the vesting of restricted share units, based upon the closing share price on the vesting date to settle the employees’ minimum statutory obligation for the applicable income and other employment taxes. For the three months ended September 27, 2019 and September 28, 2018, the Company then remitted cash of $4.1 million and $8.9 million, respectively, to the appropriate taxing authorities, and presented it as a financing activity within the unaudited condensed consolidated statements of cash flows. 
The payment
 was recorded as a reduction of additional 
paid-in
 capital.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-19-284781:notes:248]
| 16. | Shareholders’ equity |

[0001193125-19-284781:notes:249]
[same as prior period, unchanged from 0001193125-19-139609:notes:57]

[0001193125-19-284781:notes:250]
[same as prior period, unchanged from 0001193125-19-139609:notes:58]

[0001193125-19-284781:notes:251]
For the three months ended September 27, 2019, Fabrinet issued 158,375 ordinary shares upon the vesting of restricted share units, net of shares withheld.

[0001193125-19-284781:notes:252]
For the three months ended September 28, 2018, Fabrinet issued 395,148 ordinary shares upon the vesting of restricted share units, net of shares withheld.

[0001193125-19-284781:notes:253]
[same as prior period, unchanged from 0001193125-19-139609:notes:61]

[0001193125-19-284781:notes:254]
Treasury shares

[0001193125-19-284781:notes:255]
In August 2017, the Company’s board of directors approved a share repurchase program to permit the Company to repurchase up to $30.0 million worth of its issued and outstanding ordinary shares in the open market in accordance with applicable rules and regulations. In February 2018 and May 2019, the Company’s board of directors approved 
an
 increase of $30.0 million and $50 million, respectively, to the original share repurchase authorization, bringing the aggregate authorization to $110.0 million. During the three months ended September 27, 2019, no shares were repurchased under the program. As of September 27, 2019, the Company had a remaining authorization to purchase up to an additional $62.2 million worth of its ordinary shares under the share repurchase program. Shares repurchase
d
 under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-19-284781:notes:256]
| 17. | Accumulated other comprehensive income (loss) (“AOCI”) |

[0001193125-19-284781:notes:257]
The changes in AOCI for the three months ended September 27, 2019 and Sept
e
mber 28, 2018 were as follows:

[0001193125-19-284781:notes:258]
| (amount in thousands) |  | Unrealized net (Losses)/Gains on Available-for-sale Securities |  |  | Unrealized net (Losses)/Gains on Derivative Instruments |  |  | Retirement benefit plan - Prior service cost |  |  | Foreign Currency Translation Adjustment |  |  | Total |  |
| Balance as of June 28, 2019 |  | $ | 952 |  |  | $ | 32 |  |  |  | (2,537 | ) |  | $ | (833 | ) |  | $ | (2,386 | ) |
| Other comprehensive income before reclassification adjustment |  |  | (32 | ) |  |  | 39 |  |  |  | 83 |  |  |  | (369 | ) |  |  | (279 | ) |
| Amounts reclassified out of AOCI to foreign exchange loss in the unaudited condensed consolidated statements of operations and comprehensive income |  |  | 67 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 67 |  |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income (loss) |  | $ | 35 |  |  | $ | 39 |  |  |  | 83 |  |  | $ | (369 | ) |  | $ | (212 | ) |
| Balance as of September 27, 2019 |  | $ | 987 |  |  | $ | 71 |  |  |  | (2,454 | ) |  | $ | (1,202 | ) |  | $ | (2,598 | ) |

[0001193125-19-284781:notes:259]
| (amount in thousands) |  | Unrealized net (Losses)/Gains on Available-for-sale Securities |  |  | Unrealized net (Losses)/Gains on Derivative Instruments |  |  | Retirement benefit plan - Prior service cost |  |  | Foreign Currency Translation Adjustment |  |  | Total |  |
| Balance as of June 29, 2018 |  | $ | (1,091 | ) |  | $ | 33 |  |  |  | — |  |  | $ | (199 | ) |  | $ | (1,257 | ) |
| Other comprehensive income before reclassification adjustment |  |  | 591 |  |  |  | — |  |  |  | — |  |  |  | (200 | ) |  |  | 391 |  |
| Amounts reclassified out of AOCI to foreign exchange loss in the unaudited condensed consolidated statements of operations and comprehensive income |  |  | (303 | ) |  |  | (1 | ) |  |  | — |  |  |  | — |  |  |  | (304 | ) |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income (loss) |  | $ | 288 |  |  | $ | (1 | ) |  |  | — |  |  | $ | (200 | ) |  | $ | 87 |  |
| Balance as of September 28, 2018 |  | $ | (803 | ) |  | $ | 32 |  |  |  | — |  |  | $ | (399 | ) |  | $ | (1,170 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-19-284781:notes:260]
| 18. | Commitments and contingencies |

[0001193125-19-284781:notes:261]
Letter of credit and Bank guarantees

[0001193125-19-284781:notes:262]
As of September 27, 2019,

[0001193125-19-284781:notes:263]
the Company had 
two
 outstanding standby letters of credit 
o
f

[0001193125-19-284781:notes:264]
16.2

[0001193125-19-284781:notes:265]
million Euros and

[0001193125-19-284781:notes:266]
one outstanding standby letter of credit of
 6.0
 million

[0001193125-19-284781:notes:267]
Euros, respectively,

[0001193125-19-284781:notes:268]
related to the Company’s support of a customer

[0001193125-19-284781:notes:269]
’s

[0001193125-19-284781:notes:270]
transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand.

[0001193125-19-284781:notes:271]
T
he
se
 standby letters of credit were backed by cash collateral of $
22.2
 million and $
7.4
 million, respectively.

[0001193125-19-284781:notes:272]
As of June 28, 2019, the Company had one outstanding standby letter of credit of 6.0 million Euros related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. The standby letter of credit was backed by cash collateral of $7.4 million.

[0001193125-19-284781:notes:273]
As of September 27, 2019 and June 28, 2019, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business amounting to $1.6 million and $1.6 million, respectively

[0001193125-19-284781:notes:274]
, and there were other bank guarantees given by a bank on behalf of our subsidiaries in

[0001193125-19-284781:notes:275]
China

[0001193125-19-284781:notes:276]
the United Kingdom to

[0001193125-19-284781:notes:277]
support their operations of $70 thousand and $25

[0001193125-19-284781:notes:278]
thousand,

[0001193125-19-284781:notes:279]
respectively.

[0001193125-19-284781:notes:280]
Purchase obligations

[0001193125-19-284781:notes:281]
Purchase obligations represent legally-binding commitments to p
u
rchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001193125-19-284781:notes:282]
As of September 27, 2019, the Company had an outstanding commitment to third parties of $8.2 million.

[0001193125-19-284781:notes:283]
Indemnification of directors and officers

[0001193125-19-284781:notes:284]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the

[0001193125-19-284781:notes:285]
consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001193125-19-284781:notes:286]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-19-284781:notes:287]
| 19. | Business segments and geographic information |

[0001193125-19-284781:notes:288]
Operating segments are defined as components of an enterprise for which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. The Company’s chief operating decision maker is Fabrinet’s 
C
hief 
E
xecutive 
O
fficer. As of September 27, 2019, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001193125-19-284781:notes:289]
Total revenues are attributed to a particular geographic area based on the 
bill-to-location
 of the 
Company’s 
customers. The Company operates in three geographic regions: North America, Asia-Pacific and Europe. The following table presents total revenues by geographic 
region
:

[0001193125-19-284781:notes:290]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 27, 2019 |  |  | September 28, 2018 |  |
| North America |  | $ | 200,947 |  |  | $ | 179,826 |  |
| Asia-Pacific |  |  | 118,423 |  |  |  | 151,947 |  |
| Europe |  |  | 79,926 |  |  |  | 45,404 |  |
|  |  | $ | 399,296 |  |  | $ | 377,177 |  |

[0001193125-19-284781:notes:291]
As of September 2
7
, 201
9
 and September 28, 2018, the Company had approximately $30.8 million and $32.5 million, respectively, of long-lived assets based in North America, with the substantial remainder of assets based in Asia-Pacific and Europe.

[0001193125-19-284781:notes:292]
[same as prior period, unchanged from 0001193125-19-139609:notes:37]

[0001193125-19-284781:notes:293]
The Company had two customers that 
each 
contributed 
to 
10% or more of its total trade accounts receivable as of September 27, 2019 and June 28, 2019

[0001193125-19-284781:notes:294]
for both periods


## us-gaap:SubsequentEventsTextBlock

[0001193125-19-284781:notes:295]
| 20. | Subsequent events |

[0001193125-19-284781:notes:296]
On October 1, 2019, the Company advanced fund
s
 in the amount of 
$
24.3

[0001193125-19-284781:notes:297]
million to a customer to support the customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. These advanced funds

[0001193125-19-284781:notes:298]
must be repaid by September 30, 2020.
