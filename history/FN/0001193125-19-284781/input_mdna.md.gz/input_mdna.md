# FN MD&A — 0001193125-19-284781


## mdna

[0001193125-19-284781:mdna:1]
| ITEM 2. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001193125-19-284781:mdna:2]
|  | • | our goals and strategies; |

[0001193125-19-284781:mdna:3]
|  | • | our and our customers’ estimates regarding future revenues, operating results, expenses, capital requirements and liquidity; |

[0001193125-19-284781:mdna:4]
|  | • | our belief that we will be able to maintain favorable pricing on our services; |

[0001193125-19-284781:mdna:5]
|  | • | our expectation that the portion of our revenues attributable to customers in regions outside of North America for the remainder of fiscal year 2020 will be in line with the portion of those revenues for the three months ended September 27, 2019; |

[0001193125-19-284781:mdna:6]
|  | • | our expectation that we will incur incremental costs of revenue as a result of our planned expansion of our business into new geographic markets; |

[0001193125-19-284781:mdna:7]
|  | • | our expectation that our fiscal year 2020 selling, general and administrative (“SG&A”) expenses will increase as a percentage of revenue compared to fiscal year 2019 SG&A expenses; |

[0001193125-19-284781:mdna:8]
|  | • | our expectation that our employee costs will increase in Thailand and the People’s Republic of China (“PRC”); |

[0001193125-19-284781:mdna:9]
|  | • | our future capital expenditures and our needs for additional financing; |

[0001193125-19-284781:mdna:10]
|  | • | the expansion of our manufacturing capacity, including into new geographies; |

[0001193125-19-284781:mdna:11]
|  | • | the growth rates of our existing markets and potential new markets; |

[0001193125-19-284781:mdna:12]
|  | • | our ability, and the ability of our customers and suppliers, to respond successfully to technological or industry developments; |

[0001193125-19-284781:mdna:13]
|  | • | our suppliers’ estimates regarding future costs; |

[0001193125-19-284781:mdna:14]
|  | • | our ability to increase our penetration of existing markets and to penetrate new markets; |

[0001193125-19-284781:mdna:15]
|  | • | our plans to diversify our sources of revenues; |

[0001193125-19-284781:mdna:16]
|  | • | our plans to execute acquisitions; |

[0001193125-19-284781:mdna:17]
|  | • | trends in the optical communications, industrial lasers, and sensors markets, including trends to outsource the production of components used in those markets; |

[0001193125-19-284781:mdna:18]
|  | • | our ability to attract and retain a qualified management team and other qualified personnel and advisors; and |

[0001193125-19-284781:mdna:19]
|  | • | competition in our existing and new markets. |

[0001193125-19-284781:mdna:20]
[same as prior period, unchanged from 0001193125-19-139609:mdna:19]

[0001193125-19-284781:mdna:21]
We provide advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers (“OEMs”) of complex products such as optical communication components, modules and 
sub-systems,
 industrial lasers, automotive components, medical devices and sensors. We offer a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, complex printed circuit board assembly, advanced packaging, integration, final assembly and testing. Although we focus primarily on 
low-volume
 production of a wide variety of high complexity products, which we refer to as 
“low-volume,

[0001193125-19-284781:mdna:22]
high-mix,”
 we also have the capability to accommodate high-volume production. Based on our experience with, and positive feedback we have received from our customers, we believe we are a global leader in providing these services to the optical communications, industrial lasers and automotive markets.

[0001193125-19-284781:mdna:23]
Our customer base includes companies in complex industries that require advanced precision manufacturing capabilities such as optical communications, industrial lasers, automotive and sensors. The products that we manufacture for our OEM customers include selective switching products; tunable transponders and transceivers; active optical cables; solid state, diode-pumped, gas and fiber lasers; and sensors. In many cases, we are the sole outsourced manufacturing partner used by our customers for the products that we produce for them.

[0001193125-19-284781:mdna:24]
We also design and fabricate application-specific crystals, lenses, prisms, mirrors, laser components, and substrates (collectively referred to as “customized optics”) and other custom and standard borosilicate, clear fused quartz, and synthetic fused silica glass products (collectively referred to as “customized glass”). We incorporate our customized optics and glass into many of the products we manufacture for our OEM customers, and we also sell customized optics and glass in the merchant market.

[0001193125-19-284781:mdna:25]
[same as prior period, unchanged from 0001193125-19-139609:mdna:23]

[0001193125-19-284781:mdna:26]
We believe our ability to expand our relationships with existing customers and attract new customers is due to a number of factors, including our broad range of complex engineering and manufacturing service offerings, flexible 
low-cost
 manufacturing platform, process optimization capabilities, advanced supply chain management, excellent customer service, and experienced management team. Although we expect the prices we charge for our manufactured products to decrease over time (partly as a result of competitive market forces), we still believe we will be able to maintain favorable pricing for our services because of our ability to reduce cycle time, adjust our product mix by focusing on more complicated products, improve product quality and yields, and reduce material costs for the products we manufacture. We believe these capabilities have enabled us to help our OEM customers reduce their manufacturing costs while maintaining or improving the design, quality, reliability, and delivery times for their products.

[0001193125-19-284781:mdna:27]
[same as prior period, unchanged from 0001193125-19-139609:mdna:25]

[0001193125-19-284781:mdna:28]
We generate revenues from three geographic regions: North America, Asia-Pacific and Europe. Revenues are attributed to a particular geographic area based on the 
bill-to
 location of our customers, notwithstanding that our customers may ultimately ship their products to end customers in a different geographic region. The majority of our revenues are derived from our manufacturing facilities in Asia-Pacific.

[0001193125-19-284781:mdna:29]
The percentage of our revenues generated from a 
bill-to
 location outside of North America 
decreased
 from 52.3% in the three months ended September 28, 2018 to 49.7% in the three months ended September 27, 2019, primarily because the increase in sales to our customers in North America was higher than the increase in sales to our customers outside of North America. Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our revenues attributable to customers in regions outside North America for the remainder of fiscal year 2020 will be in line with the portion of revenues attributable to such customers during the three months ended September 27, 2019.

[0001193125-19-284781:mdna:30]
The following table presents percentages of total revenues by geographic region:

[0001193125-19-284781:mdna:31]
|  |  | Three Months Ended |  |
|  |  | September 27, 2019 |  |  | September 28, 2018 |  |
| North America |  |  | 50.3 | % |  |  | 47.7 | % |
| Asia-Pacific |  |  | 29.7 |  |  |  | 40.3 |  |
| Europe |  |  | 20.0 |  |  |  | 12.0 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-19-284781:mdna:32]
[same as prior period, unchanged from 0001193125-19-139609:mdna:30]

[0001193125-19-284781:mdna:33]
We enter into supply agreements with our customers which generally have an initial term of up to three years, subject to automatic renewals for subsequent 
one-year
 terms unless expressly terminated. Although there are no minimum purchase requirements in our supply agreements, our customers provide us with rolling forecasts of their demand requirements. Our supply agreements generally include provisions for pricing and periodic review of pricing, consignment of our customer’s unique production equipment to us, and the sharing of benefits from cost-savings derived from our efforts. We are generally required to purchase materials, which may include long lead-time materials and materials that are subject to minimum order quantities and/or 
non-cancelable
 or 
non-returnable
 terms, to meet the stated demands of our customers. After procuring materials, we manufacture products for our customers based on purchase orders that contain terms regarding product quantities, delivery locations and delivery dates. Our customers generally are obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by our customers within a specified period of time, or are no longer required due to a product’s cancellation or 
end-of-life,
 are typically designated as excess or obsolete inventory under our contracts. Once materials are designated as either excess or obsolete inventory, our customers are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

[0001193125-19-284781:mdna:34]
[same as prior period, unchanged from 0001193125-19-139609:mdna:32]

[0001193125-19-284781:mdna:35]
The key components of our cost of revenues are material costs, employee costs, and infrastructure-related costs. Material costs generally represent the majority of our cost of revenues. Several of the materials we require to manufacture products for our customers are customized for their products and often sourced from a single supplier or in some cases, our own subsidiaries. Shortages from sole-source suppliers due to yield loss, quality concerns and capacity constraints, among other factors, may increase our expenses and negatively impact our gross profit margin or total revenues in a given quarter. Material costs include scrap material. Historically, scrap rate diminishes during a product’s life cycle due to process, fixturing and test improvement and optimization.

[0001193125-19-284781:mdna:36]
A second significant element of our cost of revenues is employee costs, including indirect employee costs related to design, configuration and optimization of manufacturing processes for our customers, quality testing, materials testing and other engineering services; and direct costs related to our manufacturing employees. Direct employee costs include employee salaries, insurance and benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a lesser extent, costs to recruit, train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand, the PRC and the United Kingdom, the fluctuation of the Thai baht, Chinese Renminbi (“RMB”) and Pound Sterling (“GBP”) against our functional currency, the U.S. dollar, and our ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention and asset utilization.

[0001193125-19-284781:mdna:37]
Our infrastructure costs are comprised of depreciation, utilities, facilities management and overhead costs. Most of our facility leases are long-term agreements. Our depreciation costs include buildings and fixed assets, primarily at our Pinehurst and Chonburi campuses in Thailand, and capital equipment located at each of our manufacturing locations.

[0001193125-19-284781:mdna:38]
We expect to incur incremental costs of revenue as a result of our planned expansion into new geographic markets, though we are not able to determine the amount of these incremental expenses.

[0001193125-19-284781:mdna:39]
[same as prior period, unchanged from 0001193125-19-139609:mdna:37]

[0001193125-19-284781:mdna:40]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative and other support personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other general expenses not related to cost of revenues. In fiscal year 2020, we expect our SG&A expenses will increase as a percentage of revenue compared with our fiscal year 2019 SG&A expenses.

[0001193125-19-284781:mdna:41]
The compensation committee of our board of directors approved a fiscal year 2020 executive incentive plan with quantitative objectives that are based solely on achieving certain revenue targets and 
non-GAAP
 operating margin targets

[0001193125-19-284781:mdna:42]
for our fiscal year ending June 26, 2020. Bonuses under the fiscal year 2020 executive incentive plan are payable after the end of fiscal year 2020. In fiscal year 2019, the compensation committee of our board of directors approved a fiscal year 2019 executive incentive plan with quantitative objectives based solely on achieving certain revenue targets and 
non-GAAP
 gross margin targets for fiscal year 2019.

[0001193125-19-284781:mdna:43]
[same as prior period, unchanged from 0001193125-19-139609:mdna:40]

[0001193125-19-284781:mdna:44]
[same as prior period, unchanged from 0001193125-19-139609:mdna:41]

[0001193125-19-284781:mdna:45]
As a result of our international operations, we are exposed to foreign exchange risk arising from various currency exposures primarily with respect to the Thai baht. Although a majority of our total revenues is denominated in U.S. dollars, a substantial portion of our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rate between the Thai baht and the U.S. dollar has fluctuated substantially in recent years and may continue to fluctuate substantially in the future. We report our financial results in U.S. dollars and our results of operations have been and could in the future be negatively impacted if the Thai baht appreciates against the U.S. dollar. Smaller portions of our expenses are incurred in a variety of other currencies, including RMB, GBP, Canadian dollars, Euros, and Japanese yen, the appreciation of which may also negatively impact our financial results.

[0001193125-19-284781:mdna:46]
In order to manage the risks arising from fluctuations in foreign currency exchange rates, we use derivative instruments. We may enter into exchange currency forward or put option contracts to manage foreign currency exposures associated with certain assets and liabilities and other forecasted foreign currency transactions and may designate these instruments as hedging instruments. The forward and put option contracts generally have maturities of up to 12 months. All foreign currency exchange contracts are recognized in the unaudited condensed consolidated balance sheets at fair value. Gain or loss on our forward and put option contracts generally offset the assets, liabilities, and transactions economically hedged.

[0001193125-19-284781:mdna:47]
We had foreign currency denominated assets and liabilities in Thai baht, RMB and GBP as follows:

[0001193125-19-284781:mdna:48]
|  |  | As of September 27, 2019 |  |  | As of June 28, 2019 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 781,245 |  |  | $ | 25,497 |  |  |  | 53.5 |  |  |  | 664,860 |  |  | $ | 21,628 |  |  |  | 60.0 |  |
| RMB |  |  | 99,873 |  |  |  | 14,120 |  |  |  | 29.6 |  |  |  | 53,393 |  |  |  | 7,767 |  |  |  | 21.5 |  |
| GBP |  |  | 6,540 |  |  |  | 8,062 |  |  |  | 16.9 |  |  |  | 5,270 |  |  |  | 6,682 |  |  |  | 18.5 |  |
| Total |  |  |  |  |  | $ | 47,679 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 36,077 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,881,355 |  |  | $ | 61,402 |  |  |  | 90.3 |  |  |  | 1,961,972 |  |  | $ | 63,825 |  |  |  | 90.0 |  |
| RMB |  |  | 28,911 |  |  |  | 4,088 |  |  |  | 6.0 |  |  |  | 26,373 |  |  |  | 3,836 |  |  |  | 5.4 |  |
| GBP |  |  | 2,038 |  |  |  | 2,513 |  |  |  | 3.7 |  |  |  | 2,598 |  |  |  | 3,294 |  |  |  | 4.6 |  |
| Total |  |  |  |  |  | $ | 68,003 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 70,955 |  |  |  | 100.0 |  |

[0001193125-19-284781:mdna:49]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of September 27, 2019 there was $74.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 28, 2019, there was $72.0 million of foreign currency forward contracts outstanding on the Thai baht payables.

[0001193125-19-284781:mdna:50]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of September 27, 2019 and June 28, 2019, we did not have any derivative contracts denominated in RMB.

[0001193125-19-284781:mdna:51]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable and other payables. As of September 27, 2019 and June 28, 2019, we did not have any derivative contracts denominated in GBP.

[0001193125-19-284781:mdna:52]
For the three months ended September 27, 2019 and September 28, 2018, we recorded gain of $0.3 million and $0.2 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-19-284781:mdna:53]
[same as prior period, unchanged from 0001193125-19-139609:mdna:50]

[0001193125-19-284781:mdna:54]
[same as prior period, unchanged from 0001193125-19-139609:mdna:51]

[0001193125-19-284781:mdna:55]
|  | • | Foreign Currency Administration Rules, as amended on August 5, 2008, or the Exchange Rules; |

[0001193125-19-284781:mdna:56]
|  | • | Administration Rules of the Settlement, Sale and Payment of Foreign Exchange (1996), or the Administration Rules; and |

[0001193125-19-284781:mdna:57]
|  | • | Notice on Perfecting Practices Concerning Foreign Exchange Settlement Regarding the Capital Contribution by Foreign-invested Enterprises, as promulgated by the State Administration of Foreign Exchange (“SAFE”), on August 29, 2008, or Circular 142. |

[0001193125-19-284781:mdna:58]
Under the Exchange Rules, RMB is freely convertible into foreign currencies for current account items, including the distribution of dividends, interest payments, trade and service-related foreign exchange transactions. However, conversion of RMB for capital account items, such as direct investments, loans, security investments and repatriation of investments, is still subject to the approval of SAFE.

[0001193125-19-284781:mdna:59]
Under the Administration Rules, foreign-invested enterprises may only buy, sell, or remit foreign currencies at banks authorized to conduct foreign exchange business after providing valid commercial documents and relevant supporting documents and, in the case of capital account item transactions, obtaining approval from SAFE. Capital investments by foreign-invested enterprises outside of the PRC are also subject to limitations, which include approvals by the Ministry of Commerce, SAFE and the State Development and Reform Commission.

[0001193125-19-284781:mdna:60]
Circular 142 regulates the conversion by a foreign-invested company of foreign currency into RMB by restricting how the converted RMB may be used. Circular 142 requires that the registered capital of a foreign-invested enterprise settled in RMB converted from foreign currencies may only be used for purposes within the business scope approved by the applicable governmental authority and may not be used for equity investments within the PRC. In addition, SAFE strengthened its oversight of the flow and use of the registered capital of foreign-invested enterprises settled in RMB converted from foreign currencies. The use of such RMB capital may not be changed without SAFE’s approval and may not be used to repay RMB loans if the proceeds of such loans have not been used.

[0001193125-19-284781:mdna:61]
On January 5, 2007, SAFE promulgated the Detailed Rules for Implementing the Measures for the Administration on Individual Foreign Exchange, or the Implementation Rules. Under the Implementation Rules, PRC citizens who are granted share options by an overseas publicly-listed company are required, through a PRC agent or PRC subsidiary of such overseas publicly-listed company, to register with SAFE and complete certain other procedures.

[0001193125-19-284781:mdna:62]
In addition, the General Administration of Taxation has issued circulars concerning employee share options. Under these circulars, our employees working in the PRC who exercise share options will be subject to PRC individual income tax. Our PRC subsidiary has obligations to file documents related to employee share options with relevant tax authorities and withhold individual income taxes of those employees who exercise their share options.

[0001193125-19-284781:mdna:63]
Furthermore, our transfer of funds to our subsidiaries in Thailand and the PRC are each subject to approval by governmental authorities in case of an increase in registered capital, or subject to registration with governmental authorities in case of a shareholder loan. These limitations on the flow of funds between our subsidiaries and us could restrict our ability to act in response to changing market conditions.

[0001193125-19-284781:mdna:64]
[same as prior period, unchanged from 0001193125-19-139609:mdna:61]

[0001193125-19-284781:mdna:65]
Our effective tax rate is a function of the mix of tax rates in the various jurisdictions in which we do business. We are domiciled in the Cayman Islands. Under the current laws of the Cayman Islands, we are not subject to tax in the Cayman Islands on income or capital gains until March 6, 2039.

[0001193125-19-284781:mdna:66]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption is currently available to us through June 2020 and June 2026 on income generated from projects to manufacture certain products at our Pinehurst campus and Chonburi campus, respectively. Such preferential tax treatment

[0001193125-19-284781:mdna:67]
is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted (i.e., at least until June 2020 in the case of our Pinehurst campus and until June 2026 in the case of our Chonburi campus). Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001193125-19-284781:mdna:68]
The Tax Cuts and Jobs Act (“Tax Reform Act”) was enacted on December 22, 2017 and provided for significant changes to U.S. tax law. Among other provisions, the Tax Reform Act reduced the U.S. corporate income tax rate to 21%, which is the current rate for our U.S. subsidiaries.

[0001193125-19-284781:mdna:69]
[same as prior period, unchanged from 0001193125-19-139609:mdna:65]

[0001193125-19-284781:mdna:70]
We prepare our unaudited condensed consolidated financial statements in conformity with U.S. GAAP, which requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent liabilities on the date of the unaudited condensed consolidated financial statements and the reported amounts of revenues and expenses during the financial reporting period. We continually evaluate these estimates and assumptions based on the most recently available information, our own historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Because the use of estimates is an integral component of the financial reporting process, actual results could differ from those estimates. Some of our accounting policies require higher degrees of judgment than others in their application. We consider the policies discussed below to be critical to an understanding of our unaudited condensed consolidated financial statements, as their application places the most significant demands on our management’s judgment.

[0001193125-19-284781:mdna:71]
Our critical accounting policies are disclosed in our Annual Report on Form 
10-K
 for the fiscal year ended June 28, 2019. The adoption of new accounting policies and accounting standards are disclosed in Note 2 to the unaudited condensed consolidated financial statements. There were no changes to our accounting policies other than the adoption of Leases (Topic 842) and Derivatives and Hedging (Topic 815), which resulted from Accounting Standards Codification Topic 842 (“ASC 842”) and Accounting Standards Update Topic 815 (“ASU 815”), respectively.

[0001193125-19-284781:mdna:72]
We adopted ASC 842 using the modified retrospective transition approach, effective on June 29, 2019. Accordingly, our comparative financial statements as of June 28, 2019 will not be adjusted. ASC 842 also provides practical expedients for our ongoing accounting. We plan to elect the short-term lease recognition exemption for our operating leases with terms of less than 12 months, which will not require recognition of right of use assets or lease liabilities for these leases.

[0001193125-19-284781:mdna:73]
The most significant impact of the adoption of ASC 842 is expected to be the recognition of right of use assets and lease liabilities for the operating leases with terms of greater than 12 months, while the accounting for finance leases will remain substantially unchanged.

[0001193125-19-284781:mdna:74]
[same as prior period, unchanged from 0001193125-19-139609:mdna:70]

[0001193125-19-284781:mdna:75]
The following table sets forth a summary of our unaudited condensed consolidated statements of operations and comprehensive income. Note that 
period-to-period
 comparisons of operating results should not be relied upon as indicative of future performance.

[0001193125-19-284781:mdna:76]
| (amount in thousands) |  | Three Months Ended |  |
| September 27, 2019 |  |  | September 28, 2018 |  |
| Revenues |  | $ | 399,296 |  |  | $ | 377,177 |  |
| Cost of revenues |  |  | (353,309 | ) |  |  | (336,901 | ) |
| Gross profit |  |  | 45,987 |  |  |  | 40,276 |  |
| Selling, general and administrative expenses |  |  | (16,000 | ) |  |  | (14,437 | ) |
| Expenses related to reduction in workforce |  |  | — |  |  |  | (85 | ) |
| Operating income |  |  | 29,987 |  |  |  | 25,754 |  |
| Interest income |  |  | 2,098 |  |  |  | 1,444 |  |
| Interest expense |  |  | (2,393 | ) |  |  | (634 | ) |
| Foreign exchange gain (loss), net |  |  | (1,953 | ) |  |  | 3,068 |  |
| Other income, net |  |  | 377 |  |  |  | 77 |  |
| Income before income taxes |  |  | 28,116 |  |  |  | 29,709 |  |
| Income tax expense |  |  | (2,159 | ) |  |  | (1,859 | ) |
| Net income |  |  | 25,957 |  |  |  | 27,850 |  |
| Other comprehensive (loss) income, net of tax |  |  | (212 | ) |  |  | 87 |  |
| Net comprehensive income |  | $ | 25,745 |  |  | $ | 27,937 |  |

[0001193125-19-284781:mdna:77]
The following table sets forth a summary of our unaudited condensed consolidated statements of operations and comprehensive income as a percentage of total revenues for the periods indicated.

[0001193125-19-284781:mdna:78]
|  |  | Three Months Ended |  |
|  |  | September 27, 2019 |  |  | September 28, 2018 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (88.5 | ) |  |  | (89.3 | ) |
| Gross profit |  |  | 11.5 |  |  |  | 10.7 |  |
| Selling, general and administrative expenses |  |  | (4.0 | ) |  |  | (3.8 | ) |
| Expenses related to reduction in workforce |  |  | 0.0 |  |  |  | 0.0 |  |
| Operating income |  |  | 7.5 |  |  |  | 6.9 |  |
| Interest income |  |  | 0.5 |  |  |  | 0.4 |  |
| Interest expense |  |  | (0.6 | ) |  |  | (0.2 | ) |
| Foreign exchange gain (loss), net |  |  | (0.5 | ) |  |  | 0.8 |  |
| Other income, net |  |  | 0.1 |  |  |  | 0.0 |  |
| Income before income taxes |  |  | 7.0 |  |  |  | 7.9 |  |
| Income tax expense |  |  | (0.5 | ) |  |  | (0.5 | ) |
| Net income |  |  | 6.5 |  |  |  | 7.4 |  |
| Other comprehensive (loss) income, net of tax |  |  | (0.1 | ) |  |  | 0.0 |  |
| Net comprehensive income |  |  | 6.4 | % |  |  | 7.4 | % |

[0001193125-19-284781:mdna:79]
36

[0001193125-19-284781:mdna:80]
[same as prior period, unchanged from 0001193125-19-139609:mdna:75]

[0001193125-19-284781:mdna:81]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 27, 2019 |  |  | September 28, 2018 |  |
| Optical communications |  | $ | 302,379 |  |  | $ | 280,768 |  |
| Lasers, sensors and other |  |  | 96,917 |  |  |  | 96,409 |  |
| Total |  | $ | 399,296 |  |  | $ | 377,177 |  |

[0001193125-19-284781:mdna:82]
We operate and internally manage a single operating segment. As such, discrete information with respect to separate product lines and segments is not accumulated.

[0001193125-19-284781:mdna:83]
Comparison of Three Months Ended September 27, 2019 with Three Months Ended September 28, 2018

[0001193125-19-284781:mdna:84]
Total revenues

[0001193125-19-284781:mdna:85]
.

[0001193125-19-284781:mdna:86]
Our total revenues increased by $22.1 million, or 5.9%, to $399.3 million for the three months ended September 27, 2019, compared with $377.2 million for the three months ended September 28, 2018. This increase was due to an increase in our customers’ demand for both optical and 
non-optical
 communications manufacturing services during the three months ended September 27, 2019. Revenues from optical and 
non-optical
 communications products increased by $21.6 million and $0.5 million, or 7.7% and 0.5%, respectively, for the three months ended September 27, 2019.

[0001193125-19-284781:mdna:87]
Cost of revenues

[0001193125-19-284781:mdna:88]
.

[0001193125-19-284781:mdna:89]
Our cost of revenues increased by $16.4 million, or 4.9%, to $353.3 million, or 88.5% of total revenues, for the three months ended September 27, 2019, compared with $336.9 million, or 89.3% of total revenues, for the three months ended September 28, 2018. The increase in cost of revenues on an absolute dollar basis was in line with the increase in sales volume.

[0001193125-19-284781:mdna:90]
Gross profit

[0001193125-19-284781:mdna:91]
.

[0001193125-19-284781:mdna:92]
Our gross profit increased by $5.7 million, or 14.2%, to $46.0 million, or 11.5% of total revenues, for the three months ended September 27, 2019, compared with $40.3 million, or 10.7% of total revenues, for the three months ended September 28, 2018. The increase was primarily due to a more favorable product mix.

[0001193125-19-284781:mdna:93]
SG&A expenses

[0001193125-19-284781:mdna:94]
.

[0001193125-19-284781:mdna:95]
Our SG&A expenses increased by $1.6 million, or 10.8%, to $16.0 million, or 4.0% of total revenues, for the three months ended September 27, 2019, compared with $14.4 million, or 3.8% of total revenues, for the three months ended September 28, 2018. The increase was primarily due to (1) an increase in share-based compensation of $1.1 million and (2) an increase in severance liabilities of $0.3 million.

[0001193125-19-284781:mdna:96]
[same as prior period, unchanged from 0001193125-19-139609:mdna:91]

[0001193125-19-284781:mdna:97]
Our operating income increased by $4.2 million to $30.0 million, or 7.5% of total revenues, for the three months ended September 27, 2019, compared with $25.8 million, or 6.9% of total revenues, for the three months ended September 28, 2018. The increase was primarily due to an increase in total revenues.

[0001193125-19-284781:mdna:98]
Interest income

[0001193125-19-284781:mdna:99]
.

[0001193125-19-284781:mdna:100]
Our interest income increased by $0.7 million, or 45.3%, to $2.1 million, or 0.5% of total revenues, for the three months ended September 27, 2019, compared with $1.4 million, or 0.4% of total revenues, for the three months ended September 28, 2018. The increase was primarily due to a higher weighted average interest rate and an increase in the average balance of our outstanding cash during the three months ended September 27, 2019.

[0001193125-19-284781:mdna:101]
Interest expense

[0001193125-19-284781:mdna:102]
.

[0001193125-19-284781:mdna:103]
Our interest expense increased by $1.8 million to $2.4 million for the three months ended September 27, 2019, compared with $0.6 million for the three months ended September 28, 2018. The increase was primarily due to an unrealized loss of $1.7 million from 
mark-to-market
 of interest rate swap related to our term loan.

[0001193125-19-284781:mdna:104]
Foreign exchange gain (loss), net.

[0001193125-19-284781:mdna:105]
We recorded foreign exchange loss, net of $2.0 million for the three months ended September 27, 2019, compared with $3.1 million gain for the three months ended September 28, 2018.

[0001193125-19-284781:mdna:106]
Income before income taxes

[0001193125-19-284781:mdna:107]
.

[0001193125-19-284781:mdna:108]
We recorded income before income taxes of $28.1 million for the three months ended September 27, 2019, compared with $29.7 million for the three months ended September 28, 2018.

[0001193125-19-284781:mdna:109]
[same as prior period, unchanged from 0001193125-19-139609:mdna:105]

[0001193125-19-284781:mdna:110]
Our provision for income tax reflects an effective tax rate of 5.6% and 6.7% for the three months ended September 27, 2019 and September 28, 2018, respectively. The decrease was primarily due to the fact that we had lower income subject to tax during the first quarter of fiscal year 2020 as compared to the same period in fiscal year 2019.

[0001193125-19-284781:mdna:111]
Net income

[0001193125-19-284781:mdna:112]
.

[0001193125-19-284781:mdna:113]
We recorded net income of $26.0 million, or 6.5% of total revenues, for the three months ended September 27, 2019, compared with $27.9 million, or 7.4% of total revenues, for the three months ended September 28, 2018. The decrease was mainly due to (1) an increase in SG&A expenses of $1.6 million; (2) a net decrease of interest income and expenses of $ 1.1 million; and (3) a net decrease of foreign exchange gain of $5.0 million, offset by an increase in gross profit of $5.7 million.

[0001193125-19-284781:mdna:114]
[same as prior period, unchanged from 0001193125-19-139609:mdna:111]

[0001193125-19-284781:mdna:115]
We recorded other comprehensive loss of $0.2 million, or 0.1% of total revenues, for the three months ended September 27, 2019, compared with other comprehensive income of $87 thousand, or 0.0% of total revenues, for the three months ended September 28, 2018.

[0001193125-19-284781:mdna:116]
[same as prior period, unchanged from 0001193125-19-139609:mdna:114]

[0001193125-19-284781:mdna:117]
Cash Flows and Working Capital

[0001193125-19-284781:mdna:118]
We primarily finance our operations through cash flow from operations. As of September 27, 2019 and September 28, 2018, we had cash, cash equivalents, and short-term investments of $406.8 million and $352.4 million, respectively, and outstanding debt of $60.9 million and $63.4 million, respectively.

[0001193125-19-284781:mdna:119]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents for the three months ended September 27, 2019 and September 28, 2018 was 2.0% and 1.9%, respectively.

[0001193125-19-284781:mdna:120]
Our cash investments are made in accordance with an investment policy approved by the audit committee of our board of directors. In general, our investment policy requires that securities purchased be rated A1, 
P-1,
 F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed income securities are primarily classified as 
available-for-sale 
 and are recorded at fair value. The cost of securities sold is based on the specific identification method. Unrealized gains and losses on these securities are recorded as other comprehensive income (loss) and are reported as a separate component of shareholders’ equity.

[0001193125-19-284781:mdna:121]
During the three months ended September 27, 2019, we paid off an existing term loan of $60.9 million under our previous Bank of America Facility Agreement and our subsidiaries in Thailand drew down a new term loan of $60.9 million under a new Credit Facility Agreement with the Bank of Ayudhya Public Company Limited. As a result, as of September 27, 2019, we had a long-term borrowing of $60.9 million under our new Credit Facility Agreement. (See Note 13 for further details.) We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held short-term investments of $238.3 million as of September 27, 2019.

[0001193125-19-284781:mdna:122]
We believe that our current cash and cash equivalents, marketable securities, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 
10-Q.

[0001193125-19-284781:mdna:123]
We also believe that our current manufacturing capacity is sufficient to meet our anticipated production requirements for at least the next few quarters.

[0001193125-19-284781:mdna:124]
The following table shows our cash flows for the periods indicated:

[0001193125-19-284781:mdna:125]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 27, 2019 |  |  | September 28, 2018 |  |
| Net cash provided by operating activities |  | $ | 2,647 |  |  | $ | 34,593 |  |
| Net cash provided by investing activities |  | $ | 11,676 |  |  | $ | 36,601 |  |
| Net cash used in financing activities |  | $ | (4,406 | ) |  | $ | (13,318 | ) |
| Net increase in cash, cash equivalents and restricted cash |  | $ | 9,917 |  |  | $ | 57,876 |  |

[0001193125-19-284781:mdna:126]
[same as prior period, unchanged from 0001193125-19-139609:mdna:124]

[0001193125-19-284781:mdna:127]
Net cash provided by operating activities decreased by $31.9 million, or 92.3%, to $2.6 million for the three months ended September 27, 2019, compared with net cash provided by operating activities of $34.6 million for the three months ended September 28, 2018. This decrease was primarily due to (1) an increase of $34.4 million in payments to trade accounts payable offset by (1) an increase in share-based compensation of $1.0 million and (2) an increase in inventory of $1.3 million.

[0001193125-19-284781:mdna:128]
[same as prior period, unchanged from 0001193125-19-139609:mdna:126]

[0001193125-19-284781:mdna:129]
Net cash provided by investing activities decreased by $24.9 million, or 68.1%, to $11.7 million for the three months ended September 27, 2019, compared with net cash provided by investing activities of $36.6 million for the three months ended September 28, 2018. This decrease was primarily due to (1) an increase in purchases of short-term investments, net of proceeds from sales and maturities of $23.8 million; and (2) an increase in the purchase of property, plant and equipment and intangibles of $1.1 million.

[0001193125-19-284781:mdna:130]
[same as prior period, unchanged from 0001193125-19-139609:mdna:128]

[0001193125-19-284781:mdna:131]
Net cash used in financing activities decreased by $8.9 million, or 66.9%, to $4.4 million for the three months ended September 27, 2019, compared with net cash used in financing activities of $13.3 million for the three months ended September 28, 2018. This decrease was primarily due to (1) a decrease in withholding tax related to net share settlement of restricted share units of $4.8 million and (2) the release of restricted cash in connection with business acquisition of $3.5 million in the first quarter of fiscal year 2019.

[0001193125-19-284781:mdna:132]
Off-Balance
 Sheet Commitments and Arrangements

[0001193125-19-284781:mdna:133]
As of September 27, 2019, we had two outstanding standby letters of credit, one for 16.2 million Euros, and the other for 6.0 million Euros related to our support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to our facilities in Thailand. As of September 27, 2019, the standby letters of credit were backed by cash collateral of $29.6 million.

[0001193125-19-284781:mdna:134]
[same as prior period, unchanged from 0001193125-19-139609:mdna:132]

[0001193125-19-284781:mdna:135]
See Note 2 of Notes to Unaudited Condensed Consolidated Financial Statements for recent accounting pronouncements that could have an effect on us.
