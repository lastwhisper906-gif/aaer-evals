# FN note change history — 0001408710-24-000009 → 0001408710-24-000019


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0001408710-24-000019:note_history:1]
As of March 29, 2024 and June 30, 2023, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.0 million and $1.5 million, respectively, or Thai baht 73.2 million and 53.0 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the subsidiary's operations related to the Israeli Customs department.
  (was, 2024-02-06, similarity 0.986):
[0001408710-24-000009:note_history:1]
As of December 29, 2023 and June 30, 2023, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.1 million and $1.5 million, respectively, or Thai baht 73.2 million and 53.0 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the subsidiary's operations related to the Israeli Customs department.

- changed (2024-05-07):
[0001408710-24-000019:note_history:2]
As of March 29, 2024, the Company had purchase obligations and other commitments to third parties of $850.9 million.
  (was, 2024-02-06, similarity 0.9488):
[0001408710-24-000009:note_history:2]
As of December 29, 2023, the Company had purchase obligations and other commitments to third parties of $1.00 billion.

- changed (2024-05-07):
[0001408710-24-000019:note_history:3]
As of March 29, 2024, the Company had total capital expenditure commitments to third parties of $27.7 million.
  (was, 2024-02-06, similarity 0.9561):
[0001408710-24-000009:note_history:3]
As of December 29, 2023, the Company had total capital expenditure commitments to third parties of $13.1 million.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0001408710-24-000019:note_history:4]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of March 29, 2024 and for the three and nine months ended March 29, 2024 and March 31, 2023 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 30, 2023.
  (was, 2024-02-06, similarity 0.9554):
[0001408710-24-000009:note_history:4]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of December 29, 2023 and for the three and six months ended December 29, 2023 and December 30, 2022 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 30, 2023.

- changed (2024-05-07):
[0001408710-24-000019:note_history:5]
The results for the three and nine months ended March 29, 2024 may not be indicative of results for the year ending June 28, 2024 or any future periods.
  (was, 2024-02-06, similarity 0.951):
[0001408710-24-000009:note_history:5]
The results for the three and six months ended December 29, 2023 may not be indicative of results for the year ending June 28, 2024 or any future periods.

- changed (2024-05-07):
[0001408710-24-000019:note_history:6]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  March 29, 2024 and March 31, 2023 consisted of 13 weeks. The nine months ended March 29, 2024 and March 31, 2023 consisted of 39 and 40 weeks, respectively. Fiscal year 2024 will comprise 52 weeks and will end on June 28, 2024.
  (was, 2024-02-06, similarity 0.8038):
[0001408710-24-000009:note_history:6]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  December 29, 2023 and December 30, 2022 consisted of 13 weeks. The six months ended December 29, 2023 and December 30, 2022 consisted of 26 and 27 weeks, respectively. Fiscal year 2024 will comprise 52 weeks and will end on June 28, 2024.

- changed (2024-05-07):
[0001408710-24-000019:note_history:7]
No new accounting standard was adopted during the nine months ended March 29, 2024.
  (was, 2024-02-06, similarity 0.7273):
[0001408710-24-000009:note_history:7]
No new accounting standard was adopted during the first half of fiscal year 2024.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0001408710-24-000019:note_history:8]
| (in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofMarch 29, 2024 |  | As ofJune 30, 2023 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 3,047 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (8) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 3,039 |  |  | $ | 12,156 |  |
  (was, 2024-02-06, similarity 0.9864):
[0001408710-24-000009:note_history:8]
| (in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofDecember 29, 2023 |  | As ofJune 30, 2023 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 6,094 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (16) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 6,078 |  |  | $ | 12,156 |  |

- changed (2024-05-07):
[0001408710-24-000019:note_history:9]
The movements of long-term borrowings for the nine months ended March 29, 2024 and March 31, 2023 were as follows:
  (was, 2024-02-06, similarity 0.892):
[0001408710-24-000009:note_history:9]
The movements of long-term borrowings for the six months ended December 29, 2023 and December 30, 2022 were as follows:

- added (2024-05-07):
[0001408710-24-000019:note_history:10]
|  | Nine Months Ended |
| (in thousands) | March 29,2024 |  | March 31,2023 |
| Opening balance | $ | 12,188 |  |  | $ | 27,421 |  |
| Repayments during the period | (9,141) |  |  | (12,187) |  |
| Closing balance | $ | 3,047 |  |  | $ | 15,234 |  |

- changed (2024-05-07):
[0001408710-24-000019:note_history:11]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. On March 9, 2023, the Borrower and the Bank amended the Term Loan Agreement to replace the interest rate reference from LIBOR to the Secured Overnight Financing Rate ("SOFR") effective from September 29, 2023. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three and nine months ended March 29, 2024, the Company recorded $0.1 million and $0.3 million, respectively, of interest expense in connection with this term loan, including the impact from interest rate swaps.
  (was, 2024-02-06, similarity 0.9686):
[0001408710-24-000009:note_history:11]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. On March 9, 2023, the Borrower and the Bank amended the Term Loan Agreement to replace the interest rate reference from LIBOR to the Secured Overnight Financing Rate ("SOFR") effective from September 29, 2023. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three and six months ended December 29, 2023, the Company recorded $0.1 million and $0.2 million, respectively, of interest expense in connection with this term loan, including the impact from interest rate swaps.

- changed (2024-05-07):
[0001408710-24-000019:note_history:12]
payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of March 29, 2024, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.
  (was, 2024-02-06, similarity 0.969):
[0001408710-24-000009:note_history:12]
payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of December 29, 2023, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

- changed (2024-05-07):
[0001408710-24-000019:note_history:13]
As of March 29, 2024, there was $3.0 million outstanding under the term loan.
  (was, 2024-02-06, similarity 0.9362):
[0001408710-24-000009:note_history:13]
As of December 29, 2023, there was $6.1 million outstanding under the term loan.

- changed (2024-05-07):
[0001408710-24-000019:note_history:14]
As of March 29, 2024, there was no amount outstanding under the 2023 Credit Facility Agreement.
  (was, 2024-02-06, similarity 0.9486):
[0001408710-24-000009:note_history:14]
As of December 29, 2023, there was no amount outstanding under the 2023 Credit Facility Agreement.

- removed (2024-05-07):
[0001408710-24-000009:note_history:15]
|  | Six Months Ended |
| (in thousands) | December 29,2023 |  | December 30,2022 |
| Opening balance | $ | 12,188 |  |  | $ | 27,421 |  |
| Repayments during the period | (6,094) |  |  | (9,140) |  |
| Closing balance | $ | 6,094 |  |  | $ | 18,281 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0001408710-24-000019:note_history:16]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of March 29, 2024 and June 30, 2023:
  (was, 2024-02-06, similarity 0.9679):
[0001408710-24-000009:note_history:16]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of December 29, 2023 and June 30, 2023:

- added (2024-05-07):
[0001408710-24-000019:note_history:17]
|  | March 29, 2024 |  | June 30, 2023 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 101,042 |  |  | $ | 101,379 |  |  | $ | 172,992 |  |  | $ | 173,137 |  |
| Due between one to five years | 308,995 |  |  | 307,536 |  |  | 149,385 |  |  | 145,963 |  |
| Total | $ | 410,037 |  |  | $ | 408,915 |  |  | $ | 322,377 |  |  | $ | 319,100 |  |

- removed (2024-05-07):
[0001408710-24-000009:note_history:18]
|  | December 29, 2023 |  | June 30, 2023 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 200,139 |  |  | $ | 201,672 |  |  | $ | 172,992 |  |  | $ | 173,137 |  |
| Due between one to five years | 205,784 |  |  | 204,868 |  |  | 149,385 |  |  | 145,963 |  |
| Total | $ | 405,923 |  |  | $ | 406,540 |  |  | $ | 322,377 |  |  | $ | 319,100 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0001408710-24-000019:note_history:19]
The movements of long-term borrowings for the nine months ended March 29, 2024 and March 31, 2023 were as follows:
  (was, 2024-02-06, similarity 0.892):
[0001408710-24-000009:note_history:19]
The movements of long-term borrowings for the six months ended December 29, 2023 and December 30, 2022 were as follows:

- added (2024-05-07):
[0001408710-24-000019:note_history:20]
|  | Nine Months Ended |
| (in thousands) | March 29,2024 |  | March 31,2023 |
| Opening balance | $ | 12,188 |  |  | $ | 27,421 |  |
| Repayments during the period | (9,141) |  |  | (12,187) |  |
| Closing balance | $ | 3,047 |  |  | $ | 15,234 |  |

- removed (2024-05-07):
[0001408710-24-000009:note_history:21]
|  | Six Months Ended |
| (in thousands) | December 29,2023 |  | December 30,2022 |
| Opening balance | $ | 12,188 |  |  | $ | 27,421 |  |
| Repayments during the period | (6,094) |  |  | (9,140) |  |
| Closing balance | $ | 6,094 |  |  | $ | 18,281 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0001408710-24-000019:note_history:22]
| (in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofMarch 29, 2024 |  | As ofJune 30, 2023 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 3,047 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (8) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 3,039 |  |  | $ | 12,156 |  |
  (was, 2024-02-06, similarity 0.9864):
[0001408710-24-000009:note_history:22]
| (in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofDecember 29, 2023 |  | As ofJune 30, 2023 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 6,094 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (16) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 6,078 |  |  | $ | 12,156 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0001408710-24-000019:note_history:23]
| (in thousands, except percentages) | Three Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 268,475 |  |  |  |  | $ | 761,622 |  |  |  |
| Others (1) | 3,401 |  |  |  |  | 10,192 |  |  |  |
| Total revenue in North America | 271,876 |  |  | 37.2 | % |  | 771,814 |  |  | 36.3 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel (2) | 275,022 |  |  |  |  | 752,736 |  |  |  |
| India | 63,055 |  |  |  |  | 208,865 |  |  |  |
| Malaysia | 30,993 |  |  |  |  | 100,938 |  |  |  |
| Hong Kong | 15,147 |  |  |  |  | 43,085 |  |  |  |
| Thailand | 13,059 |  |  |  |  | 36,489 |  |  |  |
| China | 12,309 |  |  |  |  | 53,831 |  |  |  |
| Japan | 5,772 |  |  |  |  | 18,408 |  |  |  |
| Others | 1,655 |  |  |  |  | 4,390 |  |  |  |
| Total revenue in Asia-Pacific and others | 417,012 |  |  | 57.0 | % |  | 1,218,742 |  |  | 57.2 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 18,164 |  |  |  |  | 66,808 |  |  |  |
| Germany | 10,148 |  |  |  |  | 33,323 |  |  |  |
| Others | 14,335 |  |  |  |  | 39,019 |  |  |  |
| Total revenue in Europe | $ | 42,647 |  |  | 5.8 | % |  | $ | 139,150 |  |  | 6.5 | % |
| Total revenue | $ | 731,535 |  |  | 100.0 | % |  | $ | 2,129,706 |  |  | 100.0 | % |
  (was, 2024-02-06, similarity 0.9526):
[0001408710-24-000009:note_history:23]
| (in thousands, except percentages) | Three Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |  | Six Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 238,288 |  |  |  |  | $ | 493,147 |  |  |  |
| Others (1) | 3,331 |  |  |  |  | 6,791 |  |  |  |
| Total revenue in North America | 241,619 |  |  | 33.9 | % |  | 499,938 |  |  | 35.8 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel (2) | 267,038 |  |  |  |  | 477,714 |  |  |  |
| India | 75,033 |  |  |  |  | 145,810 |  |  |  |
| Malaysia | 36,626 |  |  |  |  | 69,945 |  |  |  |
| China | 21,262 |  |  |  |  | 41,522 |  |  |  |
| Hong Kong | 12,150 |  |  |  |  | 27,938 |  |  |  |
| Thailand | 10,403 |  |  |  |  | 23,430 |  |  |  |
| Japan | 5,826 |  |  |  |  | 12,636 |  |  |  |
| Others | 1,570 |  |  |  |  | 2,735 |  |  |  |
| Total revenue in Asia-Pacific and others | 429,908 |  |  | 60.3 | % |  | 801,730 |  |  | 57.3 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 18,870 |  |  |  |  | 48,644 |  |  |  |
| Germany | 10,395 |  |  |  |  | 23,175 |  |  |  |
| Others | 11,902 |  |  |  |  | 24,684 |  |  |  |
| Total revenue in Europe | $ | 41,167 |  |  | 5.8 | % |  | $ | 96,503 |  |  | 6.9 | % |
| Total revenue | $ | 712,694 |  |  | 100.0 | % |  | $ | 1,398,171 |  |  | 100.0 | % |

- changed (2024-05-07):
[0001408710-24-000019:note_history:24]
| (in thousands, except percentages) | Three Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 310,100 |  |  |  |  | $ | 975,098 |  |  |  |
| Others (1) | 6,035 |  |  |  |  | 13,693 |  |  |  |
| Total revenue in North America | 316,135 |  |  | 47.5 | % |  | 988,791 |  |  | 49.7 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 85,731 |  |  |  |  | 247,942 |  |  |  |
| Israel | 85,562 |  |  |  |  | 182,732 |  |  |  |
| Hong Kong | 37,120 |  |  |  |  | 109,315 |  |  |  |
| Malaysia | 30,688 |  |  |  |  | 130,402 |  |  |  |
| Thailand | 16,706 |  |  |  |  | 45,420 |  |  |  |
| China | 11,194 |  |  |  |  | 60,738 |  |  |  |
| Japan | 10,044 |  |  |  |  | 32,129 |  |  |  |
| Others | 2,896 |  |  |  |  | 7,957 |  |  |  |
| Total revenue in Asia-Pacific and others | 279,941 |  |  | 42.1 | % |  | 816,635 |  |  | 41.1 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 40,292 |  |  |  |  | 103,440 |  |  |  |
| Germany | 14,532 |  |  |  |  | 40,975 |  |  |  |
| Others | 14,381 |  |  |  |  | 39,525 |  |  |  |
| Total revenue in Europe | $ | 69,205 |  |  | 10.4 | % |  | $ | 183,940 |  |  | 9.2 | % |
| Total revenue | $ | 665,281 |  |  | 100.0 | % |  | $ | 1,989,366 |  |  | 100.0 | % |
  (was, 2024-02-06, similarity 0.9104):
[0001408710-24-000009:note_history:24]
| (in thousands, except percentages) | Three Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |  | Six Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 319,918 |  |  |  |  | $ | 664,998 |  |  |  |
| Others (1) | 4,033 |  |  |  |  | 7,657 |  |  |  |
| Total revenue in North America | 323,951 |  |  | 48.5 | % |  | 672,655 |  |  | 50.8 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 82,178 |  |  |  |  | 162,211 |  |  |  |
| Israel | 59,893 |  |  |  |  | 97,170 |  |  |  |
| Malaysia | 50,390 |  |  |  |  | 99,714 |  |  |  |
| Hong Kong | 39,723 |  |  |  |  | 72,195 |  |  |  |
| China | 26,480 |  |  |  |  | 49,544 |  |  |  |
| Thailand | 16,098 |  |  |  |  | 28,714 |  |  |  |
| Japan | 11,737 |  |  |  |  | 22,085 |  |  |  |
| Others | 1,901 |  |  |  |  | 5,061 |  |  |  |
| Total revenue in Asia-Pacific and others | 288,400 |  |  | 43.1 | % |  | 536,694 |  |  | 40.5 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 30,316 |  |  |  |  | 63,148 |  |  |  |
| Germany | 13,129 |  |  |  |  | 26,443 |  |  |  |
| Others | 12,860 |  |  |  |  | 25,145 |  |  |  |
| Total revenue in Europe | $ | 56,305 |  |  | 8.4 | % |  | $ | 114,736 |  |  | 8.7 | % |
| Total revenue | $ | 668,656 |  |  | 100.0 | % |  | $ | 1,324,085 |  |  | 100.0 | % |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0001408710-24-000019:note_history:25]
As of March 29, 2024 and June 30, 2023, the Company's contract assets are de minimis.
  (was, 2024-02-06, similarity 0.9404):
[0001408710-24-000009:note_history:25]
As of December 29, 2023 and June 30, 2023, the Company's contract assets are de minimis.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-05-07):
[0001408710-24-000019:note_history:26]
Revenues from contracts with customers
Revenue by Geographic Area, End Market and Product Category
  (was, 2024-02-06, similarity 0.8539):
[0001408710-24-000009:note_history:26]
Revenues from contracts with customers
Revenue by Geographic Area and End Market

- changed (2024-05-07):
[0001408710-24-000019:note_history:27]
| (in thousands, except percentages) | Three Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 268,475 |  |  |  |  | $ | 761,622 |  |  |  |
| Others (1) | 3,401 |  |  |  |  | 10,192 |  |  |  |
| Total revenue in North America | 271,876 |  |  | 37.2 | % |  | 771,814 |  |  | 36.3 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel (2) | 275,022 |  |  |  |  | 752,736 |  |  |  |
| India | 63,055 |  |  |  |  | 208,865 |  |  |  |
| Malaysia | 30,993 |  |  |  |  | 100,938 |  |  |  |
| Hong Kong | 15,147 |  |  |  |  | 43,085 |  |  |  |
| Thailand | 13,059 |  |  |  |  | 36,489 |  |  |  |
| China | 12,309 |  |  |  |  | 53,831 |  |  |  |
| Japan | 5,772 |  |  |  |  | 18,408 |  |  |  |
| Others | 1,655 |  |  |  |  | 4,390 |  |  |  |
| Total revenue in Asia-Pacific and others | 417,012 |  |  | 57.0 | % |  | 1,218,742 |  |  | 57.2 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 18,164 |  |  |  |  | 66,808 |  |  |  |
| Germany | 10,148 |  |  |  |  | 33,323 |  |  |  |
| Others | 14,335 |  |  |  |  | 39,019 |  |  |  |
| Total revenue in Europe | $ | 42,647 |  |  | 5.8 | % |  | $ | 139,150 |  |  | 6.5 | % |
| Total revenue | $ | 731,535 |  |  | 100.0 | % |  | $ | 2,129,706 |  |  | 100.0 | % |
  (was, 2024-02-06, similarity 0.9526):
[0001408710-24-000009:note_history:27]
| (in thousands, except percentages) | Three Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |  | Six Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 238,288 |  |  |  |  | $ | 493,147 |  |  |  |
| Others (1) | 3,331 |  |  |  |  | 6,791 |  |  |  |
| Total revenue in North America | 241,619 |  |  | 33.9 | % |  | 499,938 |  |  | 35.8 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel (2) | 267,038 |  |  |  |  | 477,714 |  |  |  |
| India | 75,033 |  |  |  |  | 145,810 |  |  |  |
| Malaysia | 36,626 |  |  |  |  | 69,945 |  |  |  |
| China | 21,262 |  |  |  |  | 41,522 |  |  |  |
| Hong Kong | 12,150 |  |  |  |  | 27,938 |  |  |  |
| Thailand | 10,403 |  |  |  |  | 23,430 |  |  |  |
| Japan | 5,826 |  |  |  |  | 12,636 |  |  |  |
| Others | 1,570 |  |  |  |  | 2,735 |  |  |  |
| Total revenue in Asia-Pacific and others | 429,908 |  |  | 60.3 | % |  | 801,730 |  |  | 57.3 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 18,870 |  |  |  |  | 48,644 |  |  |  |
| Germany | 10,395 |  |  |  |  | 23,175 |  |  |  |
| Others | 11,902 |  |  |  |  | 24,684 |  |  |  |
| Total revenue in Europe | $ | 41,167 |  |  | 5.8 | % |  | $ | 96,503 |  |  | 6.9 | % |
| Total revenue | $ | 712,694 |  |  | 100.0 | % |  | $ | 1,398,171 |  |  | 100.0 | % |

- changed (2024-05-07):
[0001408710-24-000019:note_history:28]
| (in thousands, except percentages) | Three Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 310,100 |  |  |  |  | $ | 975,098 |  |  |  |
| Others (1) | 6,035 |  |  |  |  | 13,693 |  |  |  |
| Total revenue in North America | 316,135 |  |  | 47.5 | % |  | 988,791 |  |  | 49.7 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 85,731 |  |  |  |  | 247,942 |  |  |  |
| Israel | 85,562 |  |  |  |  | 182,732 |  |  |  |
| Hong Kong | 37,120 |  |  |  |  | 109,315 |  |  |  |
| Malaysia | 30,688 |  |  |  |  | 130,402 |  |  |  |
| Thailand | 16,706 |  |  |  |  | 45,420 |  |  |  |
| China | 11,194 |  |  |  |  | 60,738 |  |  |  |
| Japan | 10,044 |  |  |  |  | 32,129 |  |  |  |
| Others | 2,896 |  |  |  |  | 7,957 |  |  |  |
| Total revenue in Asia-Pacific and others | 279,941 |  |  | 42.1 | % |  | 816,635 |  |  | 41.1 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 40,292 |  |  |  |  | 103,440 |  |  |  |
| Germany | 14,532 |  |  |  |  | 40,975 |  |  |  |
| Others | 14,381 |  |  |  |  | 39,525 |  |  |  |
| Total revenue in Europe | $ | 69,205 |  |  | 10.4 | % |  | $ | 183,940 |  |  | 9.2 | % |
| Total revenue | $ | 665,281 |  |  | 100.0 | % |  | $ | 1,989,366 |  |  | 100.0 | % |
  (was, 2024-02-06, similarity 0.9104):
[0001408710-24-000009:note_history:28]
| (in thousands, except percentages) | Three Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |  | Six Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 319,918 |  |  |  |  | $ | 664,998 |  |  |  |
| Others (1) | 4,033 |  |  |  |  | 7,657 |  |  |  |
| Total revenue in North America | 323,951 |  |  | 48.5 | % |  | 672,655 |  |  | 50.8 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 82,178 |  |  |  |  | 162,211 |  |  |  |
| Israel | 59,893 |  |  |  |  | 97,170 |  |  |  |
| Malaysia | 50,390 |  |  |  |  | 99,714 |  |  |  |
| Hong Kong | 39,723 |  |  |  |  | 72,195 |  |  |  |
| China | 26,480 |  |  |  |  | 49,544 |  |  |  |
| Thailand | 16,098 |  |  |  |  | 28,714 |  |  |  |
| Japan | 11,737 |  |  |  |  | 22,085 |  |  |  |
| Others | 1,901 |  |  |  |  | 5,061 |  |  |  |
| Total revenue in Asia-Pacific and others | 288,400 |  |  | 43.1 | % |  | 536,694 |  |  | 40.5 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 30,316 |  |  |  |  | 63,148 |  |  |  |
| Germany | 13,129 |  |  |  |  | 26,443 |  |  |  |
| Others | 12,860 |  |  |  |  | 25,145 |  |  |  |
| Total revenue in Europe | $ | 56,305 |  |  | 8.4 | % |  | $ | 114,736 |  |  | 8.7 | % |
| Total revenue | $ | 668,656 |  |  | 100.0 | % |  | $ | 1,324,085 |  |  | 100.0 | % |

- changed (2024-05-07):
[0001408710-24-000019:note_history:29]
The following table presents revenues by end market and product category:
  (was, 2024-02-06, similarity 0.832):
[0001408710-24-000009:note_history:29]
The following table presents revenues by end market:

- added (2024-05-07):
[0001408710-24-000019:note_history:30]
| (in thousands, except percentages) | Three Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 305,478 |  |  |  |  | $ | 835,642 |  |  |  |
| Telecom | 285,970 |  |  |  |  | 856,997 |  |  |  |
| Total revenue - Optical communications | $ | 591,448 |  |  | 80.9 | % |  | $ | 1,692,639 |  |  | 79.5 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 73,636 |  |  |  |  | $ | 241,166 |  |  |  |
| Industrial laser | 30,319 |  |  |  |  | 90,582 |  |  |  |
| Others | 36,132 |  |  |  |  | 105,319 |  |  |  |
| Total revenue - Non-optical communications | $ | 140,087 |  |  | 19.1 | % |  | $ | 437,067 |  |  | 20.5 | % |
| Total revenue | $ | 731,535 |  |  | 100.0 | % |  | $ | 2,129,706 |  |  | 100.0 | % |

- added (2024-05-07):
[0001408710-24-000019:note_history:31]
| (in thousands, except percentages) | Three Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 122,385 |  |  |  |  | $ | 328,271 |  |  |  |
| Telecom | 380,230 |  |  |  |  | 1,177,961 |  |  |  |
| Total revenue - Optical communications | $ | 502,615 |  |  | 75.5 | % |  | $ | 1,506,232 |  |  | 75.7 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 94,107 |  |  |  |  | $ | 275,704 |  |  |  |
| Industrial laser | 31,040 |  |  |  |  | 97,396 |  |  |  |
| Others | 37,519 |  |  |  |  | 110,034 |  |  |  |
| Total revenue - Non-optical communications | $ | 162,666 |  |  | 24.5 | % |  | $ | 483,134 |  |  | 24.3 | % |
| Total revenue | $ | 665,281 |  |  | 100.0 | % |  | $ | 1,989,366 |  |  | 100.0 | % |

- changed (2024-05-07):
[0001408710-24-000019:note_history:32]
As of March 29, 2024 and June 30, 2023, the Company's contract assets are de minimis.
  (was, 2024-02-06, similarity 0.9404):
[0001408710-24-000009:note_history:32]
As of December 29, 2023 and June 30, 2023, the Company's contract assets are de minimis.

- changed (2024-05-07):
[0001408710-24-000019:note_history:33]
The following tables summarize the activity in the Company’s contract liabilities during the nine months ended March 29, 2024:
  (was, 2024-02-06, similarity 0.9426):
[0001408710-24-000009:note_history:33]
The following tables summarize the activity in the Company’s contract liabilities during the six months ended December 29, 2023:

- changed (2024-05-07):
[0001408710-24-000019:note_history:34]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 30, 2023 | $ | 3,036 |  |
| Advance payments received during the period | 9,131 |  |
| Revenue recognized | (5,301) |  |
| Ending balance, March 29, 2024 | $ | 6,866 |  |
  (was, 2024-02-06, similarity 0.9736):
[0001408710-24-000009:note_history:34]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 30, 2023 | $ | 3,036 |  |
| Advance payments received during the period | 7,610 |  |
| Revenue recognized | (4,325) |  |
| Ending balance, December 29, 2023 | $ | 6,321 |  |

- removed (2024-05-07):
[0001408710-24-000009:note_history:35]
| (in thousands, except percentages) | Three Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |  | Six Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |
| Optical communications | $ | 567,934 |  |  | 79.7 | % |  | $ | 1,101,191 |  |  | 78.8 | % |
| Automotive, lasers and other | 144,760 |  |  | 20.3 | % |  | 296,980 |  |  | 21.2 | % |
| Total | $ | 712,694 |  |  | 100.0 | % |  | $ | 1,398,171 |  |  | 100.0 | % |

- removed (2024-05-07):
[0001408710-24-000009:note_history:36]
| (in thousands, except percentages) | Three Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |  | Six Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |
| Optical communications | $ | 506,056 |  |  | 75.7 | % |  | $ | 1,003,617 |  |  | 75.8 | % |
| Automotive, lasers and other | 162,600 |  |  | 24.3 | % |  | 320,468 |  |  | 24.2 | % |
| Total | $ | 668,656 |  |  | 100.0 | % |  | $ | 1,324,085 |  |  | 100.0 | % |
