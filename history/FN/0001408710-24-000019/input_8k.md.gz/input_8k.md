# FN 8-K — 0001408710-24-000017 filed 2024-05-06

## item codes, every 8-K on or before 2024-05-07

- 2024-05-06 0001408710-24-000017 — 2.02, 9.01
- 2024-02-05 0001408710-24-000007 — 2.02, 9.01
- 2023-12-13 0001408710-23-000038 — 5.07
- 2023-11-06 0001408710-23-000034 — 2.02, 9.01
- 2023-08-21 0001408710-23-000026 — 2.02, 5.02, 9.01
- 2023-05-08 0001408710-23-000016 — 2.02, 5.02, 9.01
- 2023-02-06 0001408710-23-000006 — 2.02, 9.01
- 2022-12-13 0001408710-22-000062 — 5.07
- 2022-11-07 0001408710-22-000058 — 2.02, 9.01
- 2022-08-15 0001408710-22-000041 — 2.02, 5.02, 9.01
- 2022-05-02 0001408710-22-000026 — 2.02, 9.01
- 2022-01-31 0001408710-22-000016 — 2.02, 9.01
- 2022-01-19 0001408710-22-000010 — 5.02
- 2022-01-06 0001408710-22-000006 — 5.02
- 2021-12-10 0001408710-21-000051 — 5.07
- 2021-11-01 0001408710-21-000045 — 2.02, 9.01
- 2021-08-16 0001408710-21-000031 — 2.02, 5.02, 9.01
- 2021-05-03 0001408710-21-000019 — 2.02, 9.01
- 2021-02-01 0001408710-21-000008 — 2.02, 9.01
- 2020-12-11 0001193125-20-315861 — 5.07
- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2024-05-07

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001408710-24-000017:8k_2_02:1]
EX-99.1
2
fn-20240506xex991q324.htm
EX-99.1

[0001408710-24-000017:8k_2_02:2]
Document

[0001408710-24-000017:8k_2_02:3]
Exhibit 99.1

[0001408710-24-000017:8k_2_02:4]
Fabrinet Announces Third Quarter Fiscal Year 2024 Financial Results

[0001408710-24-000017:8k_2_02:5]
•Exceeds Guidance Ranges with Record Revenue and Net Income Per Share

[0001408710-24-000017:8k_2_02:6]
BANGKOK, Thailand – May 6, 2024 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its third fiscal quarter ended March 29, 2024.

[0001408710-24-000017:8k_2_02:7]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “We delivered strong results in the quarter, exceeding both our revenue and EPS guidance. Our results were driven by record datacom revenue from continued demand for high-data-rate products, and sequential growth in telecom revenue, primarily from datacenter interconnect products. Looking to the fourth quarter, we anticipate continued strength in datacom and sequential growth in automotive. Despite ongoing inventory absorption of traditional telecom products, we remain well-positioned to deliver another strong overall performance and further advance our leadership position.”

[0001408710-24-000017:8k_2_02:8]
Third Quarter Fiscal Year 2024 Financial Highlights

[0001408710-24-000017:8k_2_02:9]
GAAP Results

[0001408710-24-000017:8k_2_02:10]
•Revenue for the third quarter of fiscal year 2024 was $731.5 million, compared to $665.3 million for the third quarter of fiscal year 2023.

[0001408710-24-000017:8k_2_02:11]
•GAAP net income for the third quarter of fiscal year 2024 was $80.9 million, compared to $59.4 million for the third quarter of fiscal year 2023.

[0001408710-24-000017:8k_2_02:12]
•GAAP net income per diluted share for the third quarter of fiscal year 2024 was $2.21, compared to $1.60 for the third quarter of fiscal year 2023.

[0001408710-24-000017:8k_2_02:13]
Non-GAAP Results

[0001408710-24-000017:8k_2_02:14]
•Non-GAAP net income for the third quarter of fiscal year 2024 was $87.7 million, compared to $71.8 million for the third quarter of fiscal year 2023.

[0001408710-24-000017:8k_2_02:15]
•Non-GAAP net income per diluted share for the third quarter of fiscal year 2024 was $2.39, compared to $1.94 for the third quarter of fiscal year 2023.

[0001408710-24-000017:8k_2_02:16]
Business Outlook

[0001408710-24-000017:8k_2_02:17]
Based on information available as of May 6, 2024, Fabrinet is issuing guidance for its fourth fiscal quarter ending June 28, 2024, as follows:

[0001408710-24-000017:8k_2_02:18]
•Fabrinet expects fourth quarter revenue to be in the range of $720 million to $740 million.

[0001408710-24-000017:8k_2_02:19]
•GAAP net income per diluted share is expected to be in the range of $2.01 to $2.08, based on approximately 36.5 million fully diluted shares outstanding.

[0001408710-24-000017:8k_2_02:20]
•Non-GAAP net income per diluted share is expected to be in the range of $2.20 to $2.27, based on approximately 36.5 million fully diluted shares outstanding.

[0001408710-24-000017:8k_2_02:21]
Guidance for non-GAAP net income per diluted share excludes share-based compensation expenses and certain non-recurring items. A reconciliation of non-GAAP net income per diluted share to the corresponding GAAP measure is available at the end of this press release.

[0001408710-24-000017:8k_2_02:22]
Conference Call Information

[0001408710-24-000017:8k_2_02:23]
| What: |  | Fabrinet Third Quarter Fiscal Year 2024 Financial Results Call |
| When: |  | May 6, 2024 |
| Time: |  | 5:00 p.m. ET |
| Live Call and Replay: |  | https://investor.fabrinet.com/events-and-presentations/events |

[0001408710-24-000017:8k_2_02:24]
A recorded version of this webcast will be available approximately two hours after the call and accessible at http://investor.fabrinet.com. The webcast will be archived on Fabrinet’s website for a period of one year.

[0001408710-24-000017:8k_2_02:25]
About Fabrinet

[0001408710-24-000017:8k_2_02:26]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China, and Israel. For more information visit: www.fabrinet.com.

[0001408710-24-000017:8k_2_02:27]
Forward-Looking Statements

[0001408710-24-000017:8k_2_02:28]
Non-GAAP Financial Measures

[0001408710-24-000017:8k_2_02:29]
In addition to reporting financial results in accordance with GAAP, we provide investors with certain non-GAAP financial measures. These non-GAAP financial measures are in addition to, and not a substitute for or superior to, measures of financial performance prepared in accordance with GAAP. We believe these non-GAAP financial measures provide investors with useful supplemental information to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, we use some of these non-GAAP financial measures to measure company performance for the purposes of determining employee incentive plan compensation.

[0001408710-24-000017:8k_2_02:30]
Non-GAAP gross profit, non-GAAP operating profit, non-GAAP net income and non-GAAP net income per diluted share exclude: share-based compensation expenses; amortization of intangibles; and amortization of deferred debt issuance costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations.

[0001408710-24-000017:8k_2_02:31]
Non-GAAP free cash flow is  net cash provided by (used in) operating activities less capital expenditures (purchase of property, plant and equipment). We use free cash flow to measure our ability to generate additional cash from our business operations.

[0001408710-24-000017:8k_2_02:32]
There are a number of limitations related to the use of these non-GAAP financial measures versus their nearest GAAP equivalents. For example, other companies may calculate non-GAAP financial measures differently or may use other measures to evaluate their performance, all of which could reduce the usefulness of our non-GAAP financial measures as tools for comparison. We urge you to review the reconciliations of our non-GAAP financial measures to the most directly comparable GAAP financial measures, and not to rely on any single financial measure to evaluate our business.

[0001408710-24-000017:8k_2_02:33]
Investor Contact:

[0001408710-24-000017:8k_2_02:34]
Garo Toomajanian

[0001408710-24-000017:8k_2_02:35]
ir@fabrinet.com

[0001408710-24-000017:8k_2_02:36]
FABRINET

[0001408710-24-000017:8k_2_02:37]
CONDENSED CONSOLIDATED BALANCE SHEETS (unaudited)

[0001408710-24-000017:8k_2_02:38]
| (in thousands of U.S. dollars, except share data and par value) | March 29,2024 |  | June 30,2023 |
| Assets |  |  |  |
| Current assets |  |  |  |
| Cash and cash equivalents | $ | 385,111 |  |  | $ | 231,368 |  |
| Short-term investments | 408,915 |  |  | 319,100 |  |
| Trade accounts receivable, net of allowance for expected credit losses of $2,838 and $965, respectively | 583,882 |  |  | 531,767 |  |
| Inventories | 454,134 |  |  | 519,576 |  |
| Prepaid expenses | 9,369 |  |  | 7,849 |  |
| Other current assets | 74,731 |  |  | 42,880 |  |
| Total current assets | 1,916,142 |  |  | 1,652,540 |  |
| Non-current assets |  |  |  |
| Property, plant and equipment, net | 303,118 |  |  | 310,350 |  |
| Intangibles, net | 2,427 |  |  | 2,394 |  |
| Operating right-of-use assets | 3,742 |  |  | 1,634 |  |
| Deferred tax assets | 10,966 |  |  | 12,095 |  |
| Other non-current assets | 630 |  |  | 635 |  |
| Total non-current assets | 320,883 |  |  | 327,108 |  |
| Total Assets | $ | 2,237,025 |  |  | $ | 1,979,648 |  |
| Liabilities and Shareholders’ Equity |  |  |  |
| Current liabilities |  |  |  |
| Long-term borrowings, current portion, net | $ | 3,039 |  |  | $ | 12,156 |  |
| Trade accounts payable | 429,021 |  |  | 381,129 |  |
| Fixed assets payable | 9,229 |  |  | 13,526 |  |
| Operating lease liabilities, current portion | 1,333 |  |  | 1,201 |  |
| Income tax payable | 4,828 |  |  | 6,024 |  |
| Accrued payroll, bonus and related expenses | 23,727 |  |  | 23,748 |  |
| Accrued expenses | 20,742 |  |  | 20,447 |  |
| Other payables | 52,348 |  |  | 23,654 |  |
| Total current liabilities | 544,267 |  |  | 481,885 |  |
| Non-current liabilities |  |  |  |
| Deferred tax liability | 4,641 |  |  | 4,799 |  |
| Operating lease liability, non-current portion | 2,003 |  |  | 66 |  |
| Severance liabilities | 23,820 |  |  | 22,159 |  |
| Other non-current liabilities | 2,059 |  |  | 2,081 |  |
| Total non-current liabilities | 32,523 |  |  | 29,105 |  |
| Total Liabilities | 576,790 |  |  | 510,990 |  |
| Shareholders’ equity |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of March 29, 2024 and June 30, 2023) | — |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 39,450,434 shares and 39,284,176 shares issued as of March 29, 2024 and June 30, 2023, respectively; and 36,159,101 shares and 36,183,682 shares outstanding as of March 29, 2024 and June 30, 2023, respectively) | 395 |  |  | 393 |  |
| Additional paid-in capital | 215,570 |  |  | 206,624 |  |
| Less: Treasury shares (3,291,333 shares and 3,100,494 shares as of March 29, 2024 and June 30, 2023, respectively) | (230,776) |  |  | (194,833) |  |
| Accumulated other comprehensive income (loss) | (4,658) |  |  | (8,115) |  |
| Retained earnings | 1,679,704 |  |  | 1,464,589 |  |
| Total Shareholders’ Equity | 1,660,235 |  |  | 1,468,658 |  |
| Total Liabilities and Shareholders’ Equity | $ | 2,237,025 |  |  | $ | 1,979,648 |  |

[0001408710-24-000017:8k_2_02:39]
FABRINET

[0001408710-24-000017:8k_2_02:40]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME (unaudited)

[0001408710-24-000017:8k_2_02:41]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands of U.S. dollars, except per share data) | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
| Revenues | $ | 731,535 |  |  | $ | 665,281 |  |  | $ | 2,129,706 |  |  | $ | 1,989,366 |  |
| Cost of revenues | (640,600) |  |  | (579,274) |  |  | (1,866,037) |  |  | (1,735,388) |  |
| Gross profit | 90,935 |  |  | 86,007 |  |  | 263,669 |  |  | 253,978 |  |
| Selling, general and administrative expenses | (19,628) |  |  | (18,309) |  |  | (59,373) |  |  | (57,804) |  |
| Restructuring and other related costs | — |  |  | (5,872) |  |  | — |  |  | (5,872) |  |
| Operating income | 71,307 |  |  | 61,826 |  |  | 204,296 |  |  | 190,302 |  |
| Interest income | 8,509 |  |  | 3,317 |  |  | 22,155 |  |  | 7,210 |  |
| Interest expense | (26) |  |  | (399) |  |  | (107) |  |  | (1,179) |  |
| Foreign exchange gain (loss), net | 3,348 |  |  | (1,303) |  |  | (25) |  |  | (3,122) |  |
| Other income (expense), net | 175 |  |  | 31 |  |  | 60 |  |  | (178) |  |
| Income before income taxes | 83,313 |  |  | 63,472 |  |  | 226,379 |  |  | 193,033 |  |
| Income tax expense | (2,397) |  |  | (4,117) |  |  | (11,264) |  |  | (5,906) |  |
| Net income | 80,916 |  |  | 59,355 |  |  | 215,115 |  |  | 187,127 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities | (1,739) |  |  | 2,046 |  |  | 2,155 |  |  | 1,768 |  |
| Change in net unrealized gain (loss) on derivative instruments | (7,328) |  |  | (5,535) |  |  | 1,062 |  |  | 4,435 |  |
| Change in net retirement benefits plan – prior service cost | 137 |  |  | 113 |  |  | 271 |  |  | 338 |  |
| Change in foreign currency translation adjustment | 75 |  |  | (191) |  |  | (31) |  |  | (29) |  |
| Total other comprehensive income (loss), net of tax | (8,855) |  |  | (3,567) |  |  | 3,457 |  |  | 6,512 |  |
| Net comprehensive income | $ | 72,061 |  |  | $ | 55,788 |  |  | $ | 218,572 |  |  | $ | 193,639 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 2.23 |  |  | $ | 1.62 |  |  | $ | 5.93 |  |  | $ | 5.12 |  |
| Diluted | $ | 2.21 |  |  | $ | 1.60 |  |  | $ | 5.88 |  |  | $ | 5.07 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |
| Basic | 36,250 |  |  | 36,608 |  |  | 36,278 |  |  | 36,575 |  |
| Diluted | 36,603 |  |  | 36,989 |  |  | 36,574 |  |  | 36,895 |  |

[0001408710-24-000017:8k_2_02:42]
FABRINET

[0001408710-24-000017:8k_2_02:43]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited)

[0001408710-24-000017:8k_2_02:44]
|  | Nine Months Ended |
| (in thousands of U.S. dollars) | March 29,2024 |  | March 31,2023 |
| Cash flows from operating activities |  |  |  |
| Net income for the period | $ | 215,115 |  |  | $ | 187,127 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 36,602 |  |  | 32,504 |  |
| Non-cash restructuring charges and other related costs | — |  |  | 2,201 |  |
| (Gain) loss on disposal and impairment of property, plant and equipment and intangibles | (147) |  |  | (1,630) |  |
| (Gain) loss from sales and maturities of available-for-sale securities | (1) |  |  | 92 |  |
| Amortization of discount (premium) of short-term investments | (2,317) |  |  | 300 |  |
| (Reversal of) allowance for expected credit losses | 1,874 |  |  | (240) |  |
| Unrealized loss (gain) on exchange rate and fair value of foreign currency forward contracts | (2,135) |  |  | 693 |  |
| Amortization of fair value at hedge inception of interest rate swaps | (198) |  |  | (478) |  |
| Share-based compensation | 21,440 |  |  | 21,217 |  |
| Deferred income tax | 1,125 |  |  | (276) |  |
| Other non-cash expenses | 194 |  |  | (127) |  |
| Changes in operating assets and liabilities |  |  |  |
| Trade accounts receivable | (54,089) |  |  | (105,932) |  |
| Inventories | 65,442 |  |  | 2,720 |  |
| Other current assets and non-current assets | (33,548) |  |  | (11,704) |  |
| Trade accounts payable | 48,268 |  |  | (5,028) |  |
| Income tax payable | (1,068) |  |  | (262) |  |
| Severance liabilities | 2,249 |  |  | 1,917 |  |
| Other current liabilities and non-current liabilities | 31,278 |  |  | 19,128 |  |
| Net cash provided by operating activities | 330,084 |  |  | 142,222 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of short-term investments | (268,461) |  |  | (154,033) |  |
| Proceeds from sales of short-term investments | 10,000 |  |  | 30,179 |  |
| Proceeds from maturities of short-term investments | 173,120 |  |  | 97,408 |  |
| Purchase of property, plant and equipment | (34,825) |  |  | (43,422) |  |
| Purchase of intangibles | (768) |  |  | (698) |  |
| Proceeds from disposal of property, plant and equipment | 2,319 |  |  | 117 |  |
| Net cash used in investing activities | (118,615) |  |  | (70,449) |  |
| Cash flows from financing activities |  |  |  |
| Repayment of long-term borrowings | (9,141) |  |  | (12,187) |  |
| Repayment of finance lease liability | — |  |  | (7) |  |
| Repurchase of ordinary shares | (35,943) |  |  | (9,217) |  |
| Withholding tax related to net share settlement of restricted share units | (12,716) |  |  | (17,740) |  |
| Net cash used in financing activities | (57,800) |  |  | (39,151) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | 153,669 |  |  | $ | 32,622 |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at the beginning of period | $ | 231,368 |  |  | $ | 198,365 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | 153,669 |  |  | 32,622 |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash | 74 |  |  | (244) |  |
| Cash, cash equivalents and restricted cash at the end of period | $ | 385,111 |  |  | $ | 230,743 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment-related payables | $ | 9,229 |  |  | $ | 20,116 |  |

[0001408710-24-000017:8k_2_02:45]
FABRINET

[0001408710-24-000017:8k_2_02:46]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-24-000017:8k_2_02:47]
Reconciliation of GAAP Gross Profit and GAAP Gross Margin to Non-GAAP Gross Profit and Non-GAAP Gross Margin

[0001408710-24-000017:8k_2_02:48]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands of U.S. dollars, except share data) | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
| Revenues | $ | 731,535 |  |  |  |  | $ | 665,281 |  |  |  |  | $ | 2,129,706 |  |  |  |  | $ | 1,989,366 |  |  |  |
| Gross profit (GAAP) | $ | 90,935 |  |  | 12.4 | % |  | $ | 86,007 |  |  | 12.9 | % |  | $ | 263,669 |  |  | 12.4 | % |  | $ | 253,978 |  |  | 12.8 | % |
| Share-based compensation expenses | 1,561 |  |  |  |  | 1,453 |  |  |  |  | 5,427 |  |  |  |  | 5,028 |  |  |  |
| Gross profit (Non-GAAP) | $ | 92,496 |  |  | 12.6 | % |  | $ | 87,460 |  |  | 13.1 | % |  | $ | 269,096 |  |  | 12.6 | % |  | $ | 259,006 |  |  | 13.0 | % |

[0001408710-24-000017:8k_2_02:49]
Reconciliation of GAAP Operating Profit and GAAP Operating Margin to Non-GAAP Operating Profit and Non-GAAP Operating Margin

[0001408710-24-000017:8k_2_02:50]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands of U.S. dollars, except share data) | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
| Revenues | $ | 731,535 |  |  |  |  | $ | 665,281 |  |  |  |  | $ | 2,129,706 |  |  |  |  | $ | 1,989,366 |  |  |  |
| Operating profit (GAAP) | $ | 71,307 |  |  | 9.7 | % |  | $ | 61,826 |  |  | 9.3 | % |  | $ | 204,296 |  |  | 9.6 | % |  | $ | 190,302 |  |  | 9.6 | % |
| Share-based compensation expenses | 6,726 |  |  |  |  | 6,533 |  |  |  |  | 21,440 |  |  |  |  | 21,031 |  |  |  |
| Restructuring and other related costs | — |  |  |  |  | 5,872 |  |  |  |  | — |  |  |  |  | 5,872 |  |  |  |
| Amortization of intangibles | — |  |  |  |  | 70 |  |  |  |  | — |  |  |  |  | 224 |  |  |  |
| Operating profit (Non-GAAP) | $ | 78,033 |  |  | 10.7 | % |  | $ | 74,301 |  |  | 11.2 | % |  | $ | 225,736 |  |  | 10.6 | % |  | $ | 217,429 |  |  | 10.9 | % |

[0001408710-24-000017:8k_2_02:51]
FABRINET

[0001408710-24-000017:8k_2_02:52]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-24-000017:8k_2_02:53]
Reconciliation of GAAP Net Income and EPS to Non-GAAP Net Income and EPS

[0001408710-24-000017:8k_2_02:54]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
| (in thousands of U.S. dollars, except share data) | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |
| GAAP measures | $ | 80,916 |  |  | $ | 2.21 |  |  | $ | 59,355 |  |  | $ | 1.60 |  |  | $ | 215,115 |  |  | $ | 5.88 |  |  | $ | 187,127 |  |  | $ | 5.07 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 1,561 |  |  | 0.04 |  |  | 1,453 |  |  | 0.04 |  |  | 5,427 |  |  | 0.15 |  |  | 5,028 |  |  | 0.14 |  |
| Total related to gross profit | 1,561 |  |  | 0.04 |  |  | 1,453 |  |  | 0.04 |  |  | 5,427 |  |  | 0.15 |  |  | 5,028 |  |  | 0.14 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 5,165 |  |  | 0.14 |  |  | 5,080 |  |  | 0.14 |  |  | 16,013 |  |  | 0.44 |  |  | 16,003 |  |  | 0.43 |  |
| Amortization of intangibles | — |  |  | — |  |  | 70 |  |  | 0.00 |  |  | — |  |  | — |  |  | 224 |  |  | 0.01 |  |
| Total related to selling, general and administrative expenses | 5,165 |  |  | 0.14 |  |  | 5,150 |  |  | 0.14 |  |  | 16,013 |  |  | 0.44 |  |  | 16,227 |  |  | 0.44 |  |
| Related to other income and expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other related costs | — |  |  | — |  |  | 5,872 |  |  | 0.16 |  |  | — |  |  | — |  |  | 5,872 |  |  | 0.16 |  |
| Amortization of deferred debt issuance costs | 8 |  |  | 0.00 |  |  | 8 |  |  | 0.00 |  |  | 24 |  |  | 0.00 |  |  | 24 |  |  | 0.00 |  |
| Total related to other income and expense | 8 |  |  | 0.00 |  |  | 5,880 |  |  | 0.16 |  |  | 24 |  |  | 0.00 |  |  | 5,896 |  |  | 0.16 |  |
| Total related to net income & EPS | 6,734 |  |  | 0.18 |  |  | 12,483 |  |  | 0.34 |  |  | 21,464 |  |  | 0.59 |  |  | 27,151 |  |  | 0.74 |  |
| Non-GAAP measures | $ | 87,650 |  |  | $ | 2.39 |  |  | $ | 71,838 |  |  | $ | 1.94 |  |  | $ | 236,579 |  |  | $ | 6.47 |  |  | $ | 214,278 |  |  | $ | 5.81 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  | 36,603 |  |  |  |  | 36,989 |  |  |  |  | 36,574 |  |  |  |  | 36,895 |  |
| Non-GAAP diluted shares |  |  | 36,603 |  |  |  |  | 36,989 |  |  |  |  | 36,574 |  |  |  |  | 36,895 |  |

[0001408710-24-000017:8k_2_02:55]
FABRINET

[0001408710-24-000017:8k_2_02:56]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001408710-24-000017:8k_2_02:57]
| (in thousands) |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
| Net cash provided by operating activities |  | $ | 100,870 |  |  | $ | 37,122 |  |  | $ | 330,084 |  |  | $ | 142,222 |  |
| Less: Purchase of property, plant and equipment |  | (13,589) |  |  | (19,779) |  |  | (34,825) |  |  | (43,422) |  |
| Non-GAAP free cash flow |  | $ | 87,281 |  |  | $ | 17,343 |  |  | $ | 295,259 |  |  | $ | 98,800 |  |

[0001408710-24-000017:8k_2_02:58]
FABRINET

[0001408710-24-000017:8k_2_02:59]
GUIDANCE FOR QUARTER ENDING JUNE 28, 2024

[0001408710-24-000017:8k_2_02:60]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-24-000017:8k_2_02:61]
|  | DilutedEPS |
| GAAP net income per diluted share: | $2.01 to $2.08 |
| Related to cost of revenues: |  |
| Share-based compensation expenses | 0.05 |
| Total related to gross profit | 0.05 |
| Related to selling, general and administrative expenses: |  |
| Share-based compensation expenses | 0.14 |
| Total related to selling, general and administrative expenses | 0.14 |
| Total related to net income & EPS | 0.19 |
| Non-GAAP net income per diluted share | $2.20 to $2.27 |
