# FN notes — 0001408710-24-000019


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001408710-24-000019:notes:1]
[same as prior period, unchanged from 0001408710-24-000009:notes:1]

[0001408710-24-000019:notes:2]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of March 29, 2024 and for the three and nine months ended March 29, 2024 and March 31, 2023 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 30, 2023.

[0001408710-24-000019:notes:3]
[same as prior period, unchanged from 0001408710-24-000009:notes:3]

[0001408710-24-000019:notes:4]
The results for the three and nine months ended March 29, 2024 may not be indicative of results for the year ending June 28, 2024 or any future periods.

[0001408710-24-000019:notes:5]
[same as prior period, unchanged from 0001408710-24-000009:notes:5]

[0001408710-24-000019:notes:6]
[same as prior period, unchanged from 0001408710-24-000009:notes:6]

[0001408710-24-000019:notes:7]
[same as prior period, unchanged from 0001408710-24-000009:notes:7]

[0001408710-24-000019:notes:8]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  March 29, 2024 and March 31, 2023 consisted of 13 weeks. The nine months ended March 29, 2024 and March 31, 2023 consisted of 39 and 40 weeks, respectively. Fiscal year 2024 will comprise 52 weeks and will end on June 28, 2024.

[0001408710-24-000019:notes:9]
[same as prior period, unchanged from 0001408710-24-000009:notes:9]

[0001408710-24-000019:notes:10]
No new accounting standard was adopted during the nine months ended March 29, 2024.

[0001408710-24-000019:notes:11]
[same as prior period, unchanged from 0001408710-24-000009:notes:11]

[0001408710-24-000019:notes:12]
In November 2023, the Financial Accounting Standards Board ("FASB") issued ASU 2023-07, “Segment Reporting (Topic 280), Improvements to Reportable Segment Disclosures,” which is intended to improve reportable segment disclosure requirements, primarily through additional disclosures about significant segment expenses. This ASU is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. This ASU will be effective for the Company in the first quarter of fiscal year 2025. The Company is currently assessing the impact to its disclosures.
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740), Improvements to Income Tax Disclosures,” which requires more detailed income tax disclosures. This ASU requires entities to disclose disaggregated information about their effective tax rate reconciliation as well as expanded information on income taxes paid by jurisdiction. This ASU is effective for all entities for fiscal years beginning after December 15, 2024, with early adoption permitted for annual financial statements that have not yet been issued or made available for issuance. This ASU will be effective for the Company in the first quarter of fiscal year 2026. The Company is currently assessing the impact to its disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001408710-24-000019:notes:13]
Revenues from contracts with customers
Revenue by Geographic Area, End Market and Product Category

[0001408710-24-000019:notes:14]
[same as prior period, unchanged from 0001408710-24-000009:notes:14]

[0001408710-24-000019:notes:15]
[same as prior period, unchanged from 0001408710-24-000009:notes:15]

[0001408710-24-000019:notes:16]
| (in thousands, except percentages) | Three Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 268,475 |  |  |  |  | $ | 761,622 |  |  |  |
| Others (1) | 3,401 |  |  |  |  | 10,192 |  |  |  |
| Total revenue in North America | 271,876 |  |  | 37.2 | % |  | 771,814 |  |  | 36.3 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel (2) | 275,022 |  |  |  |  | 752,736 |  |  |  |
| India | 63,055 |  |  |  |  | 208,865 |  |  |  |
| Malaysia | 30,993 |  |  |  |  | 100,938 |  |  |  |
| Hong Kong | 15,147 |  |  |  |  | 43,085 |  |  |  |
| Thailand | 13,059 |  |  |  |  | 36,489 |  |  |  |
| China | 12,309 |  |  |  |  | 53,831 |  |  |  |
| Japan | 5,772 |  |  |  |  | 18,408 |  |  |  |
| Others | 1,655 |  |  |  |  | 4,390 |  |  |  |
| Total revenue in Asia-Pacific and others | 417,012 |  |  | 57.0 | % |  | 1,218,742 |  |  | 57.2 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 18,164 |  |  |  |  | 66,808 |  |  |  |
| Germany | 10,148 |  |  |  |  | 33,323 |  |  |  |
| Others | 14,335 |  |  |  |  | 39,019 |  |  |  |
| Total revenue in Europe | $ | 42,647 |  |  | 5.8 | % |  | $ | 139,150 |  |  | 6.5 | % |
| Total revenue | $ | 731,535 |  |  | 100.0 | % |  | $ | 2,129,706 |  |  | 100.0 | % |

[0001408710-24-000019:notes:17]
| (in thousands, except percentages) | Three Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 310,100 |  |  |  |  | $ | 975,098 |  |  |  |
| Others (1) | 6,035 |  |  |  |  | 13,693 |  |  |  |
| Total revenue in North America | 316,135 |  |  | 47.5 | % |  | 988,791 |  |  | 49.7 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 85,731 |  |  |  |  | 247,942 |  |  |  |
| Israel | 85,562 |  |  |  |  | 182,732 |  |  |  |
| Hong Kong | 37,120 |  |  |  |  | 109,315 |  |  |  |
| Malaysia | 30,688 |  |  |  |  | 130,402 |  |  |  |
| Thailand | 16,706 |  |  |  |  | 45,420 |  |  |  |
| China | 11,194 |  |  |  |  | 60,738 |  |  |  |
| Japan | 10,044 |  |  |  |  | 32,129 |  |  |  |
| Others | 2,896 |  |  |  |  | 7,957 |  |  |  |
| Total revenue in Asia-Pacific and others | 279,941 |  |  | 42.1 | % |  | 816,635 |  |  | 41.1 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 40,292 |  |  |  |  | 103,440 |  |  |  |
| Germany | 14,532 |  |  |  |  | 40,975 |  |  |  |
| Others | 14,381 |  |  |  |  | 39,525 |  |  |  |
| Total revenue in Europe | $ | 69,205 |  |  | 10.4 | % |  | $ | 183,940 |  |  | 9.2 | % |
| Total revenue | $ | 665,281 |  |  | 100.0 | % |  | $ | 1,989,366 |  |  | 100.0 | % |

[0001408710-24-000019:notes:18]
[same as prior period, unchanged from 0001408710-24-000009:notes:18]

[0001408710-24-000019:notes:19]
[same as prior period, unchanged from 0001408710-24-000009:notes:19]

[0001408710-24-000019:notes:20]
The following table presents revenues by end market and product category:

[0001408710-24-000019:notes:21]
| (in thousands, except percentages) | Three Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 305,478 |  |  |  |  | $ | 835,642 |  |  |  |
| Telecom | 285,970 |  |  |  |  | 856,997 |  |  |  |
| Total revenue - Optical communications | $ | 591,448 |  |  | 80.9 | % |  | $ | 1,692,639 |  |  | 79.5 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 73,636 |  |  |  |  | $ | 241,166 |  |  |  |
| Industrial laser | 30,319 |  |  |  |  | 90,582 |  |  |  |
| Others | 36,132 |  |  |  |  | 105,319 |  |  |  |
| Total revenue - Non-optical communications | $ | 140,087 |  |  | 19.1 | % |  | $ | 437,067 |  |  | 20.5 | % |
| Total revenue | $ | 731,535 |  |  | 100.0 | % |  | $ | 2,129,706 |  |  | 100.0 | % |

[0001408710-24-000019:notes:22]
| (in thousands, except percentages) | Three Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 122,385 |  |  |  |  | $ | 328,271 |  |  |  |
| Telecom | 380,230 |  |  |  |  | 1,177,961 |  |  |  |
| Total revenue - Optical communications | $ | 502,615 |  |  | 75.5 | % |  | $ | 1,506,232 |  |  | 75.7 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 94,107 |  |  |  |  | $ | 275,704 |  |  |  |
| Industrial laser | 31,040 |  |  |  |  | 97,396 |  |  |  |
| Others | 37,519 |  |  |  |  | 110,034 |  |  |  |
| Total revenue - Non-optical communications | $ | 162,666 |  |  | 24.5 | % |  | $ | 483,134 |  |  | 24.3 | % |
| Total revenue | $ | 665,281 |  |  | 100.0 | % |  | $ | 1,989,366 |  |  | 100.0 | % |

[0001408710-24-000019:notes:23]
[same as prior period, unchanged from 0001408710-24-000009:notes:23]

[0001408710-24-000019:notes:24]
[same as prior period, unchanged from 0001408710-24-000009:notes:24]

[0001408710-24-000019:notes:25]
As of March 29, 2024 and June 30, 2023, the Company's contract assets are de minimis.

[0001408710-24-000019:notes:26]
[same as prior period, unchanged from 0001408710-24-000009:notes:26]

[0001408710-24-000019:notes:27]
The following tables summarize the activity in the Company’s contract liabilities during the nine months ended March 29, 2024:

[0001408710-24-000019:notes:28]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 30, 2023 | $ | 3,036 |  |
| Advance payments received during the period | 9,131 |  |
| Revenue recognized | (5,301) |  |
| Ending balance, March 29, 2024 | $ | 6,866 |  |


## us-gaap:EarningsPerShareTextBlock

[0001408710-24-000019:notes:29]
[same as prior period, unchanged from 0001408710-24-000009:notes:29]

[0001408710-24-000019:notes:30]
[same as prior period, unchanged from 0001408710-24-000009:notes:30]

[0001408710-24-000019:notes:31]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands, except per share data) | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
| Net income attributable to shareholders | $ | 80,916 |  |  | $ | 59,355 |  |  | $ | 215,115 |  |  | $ | 187,127 |  |
| Weighted-average number of ordinary shares outstanding | 36,250 |  |  | 36,608 |  |  | 36,278 |  |  | 36,575 |  |
| Incremental shares arising from the assumed vesting of restricted share units and performance share units | 353 |  |  | 381 |  |  | 296 |  |  | 320 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share | 36,603 |  |  | 36,989 |  |  | 36,574 |  |  | 36,895 |  |
| Basic earnings per ordinary share | $ | 2.23 |  |  | $ | 1.62 |  |  | $ | 5.93 |  |  | $ | 5.12 |  |
| Diluted earnings per ordinary share | $ | 2.21 |  |  | $ | 1.60 |  |  | $ | 5.88 |  |  | $ | 5.07 |  |


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001408710-24-000019:notes:32]
[same as prior period, unchanged from 0001408710-24-000009:notes:32]

[0001408710-24-000019:notes:33]
|  |  |  | Fair Value |
| (in thousands) | CarryingCost |  | UnrealizedGain/(Loss) |  | Cash andCashEquivalents |  | MarketableSecurities |  | OtherInvestments |
| As of March 29, 2024 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 382,652 |  |  | $ | — |  |  | $ | 382,652 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 2,459 |  |  | — |  |  | 2,459 |  |  | — |  |  | — |  |
| Liquidity funds | 32,213 |  |  | — |  |  | — |  |  | — |  |  | 32,213 |  |
| Certificates of deposit and time deposits | 90,436 |  |  | 338 |  |  | — |  |  | 90,774 |  |  | — |  |
| Corporate debt securities | 138,243 |  |  | (1,331) |  |  | — |  |  | 136,912 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 149,145 |  |  | (129) |  |  | — |  |  | 149,016 |  |  | — |  |
| Total | $ | 795,148 |  |  | $ | (1,122) |  |  | $ | 385,111 |  |  | $ | 376,702 |  |  | $ | 32,213 |  |
| As of June 30, 2023 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 230,967 |  |  | $ | — |  |  | $ | 230,967 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 401 |  |  | — |  |  | 401 |  |  | — |  |  | — |  |
| Liquidity funds | 41,104 |  |  | — |  |  | — |  |  | — |  |  | 41,104 |  |
| Certificates of deposit and time deposits | 64,278 |  |  | 329 |  |  | — |  |  | 64,607 |  |  | — |  |
| Corporate debt securities | 161,453 |  |  | (3,375) |  |  | — |  |  | 158,078 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 55,542 |  |  | (231) |  |  | — |  |  | 55,311 |  |  | — |  |
| Total | $ | 553,745 |  |  | $ | (3,277) |  |  | $ | 231,368 |  |  | $ | 277,996 |  |  | $ | 41,104 |  |

[0001408710-24-000019:notes:34]
[same as prior period, unchanged from 0001408710-24-000009:notes:34]

[0001408710-24-000019:notes:35]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of March 29, 2024 and June 30, 2023:

[0001408710-24-000019:notes:36]
|  | March 29, 2024 |  | June 30, 2023 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 101,042 |  |  | $ | 101,379 |  |  | $ | 172,992 |  |  | $ | 173,137 |  |
| Due between one to five years | 308,995 |  |  | 307,536 |  |  | 149,385 |  |  | 145,963 |  |
| Total | $ | 410,037 |  |  | $ | 408,915 |  |  | $ | 322,377 |  |  | $ | 319,100 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001408710-24-000019:notes:37]
[same as prior period, unchanged from 0001408710-24-000009:notes:37]

[0001408710-24-000019:notes:38]
[same as prior period, unchanged from 0001408710-24-000009:notes:38]

[0001408710-24-000019:notes:39]
[same as prior period, unchanged from 0001408710-24-000009:notes:39]

[0001408710-24-000019:notes:40]
[same as prior period, unchanged from 0001408710-24-000009:notes:40]

[0001408710-24-000019:notes:41]
[same as prior period, unchanged from 0001408710-24-000009:notes:41]

[0001408710-24-000019:notes:42]
[same as prior period, unchanged from 0001408710-24-000009:notes:42]

[0001408710-24-000019:notes:43]
|  | Fair Value Measurements at Reporting Date Using |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of March 29, 2024 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 2,459 |  |  |  | $ | — |  |  | $ | 2,459 |  |
| Liquidity funds | — |  |  | 32,213 |  |  |  | — |  |  | 32,213 |  |
| Certificates of deposit and time deposits | — |  |  | 90,774 |  |  |  | — |  |  | 90,774 |  |
| Corporate debt securities | — |  |  | 136,912 |  |  |  | — |  |  | 136,912 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 149,016 |  |  |  | — |  |  | 149,016 |  |
| Derivative assets – current portion | — |  |  | 21 |  | (1) |  | — |  |  | 21 |  |
| Total | $ | — |  |  | $ | 411,395 |  |  |  | $ | — |  |  | $ | 411,395 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | (3,799) |  |  |  | $ | — |  |  | $ | (3,799) |  |
| Total | $ | — |  |  | $ | (3,799) |  | (2) |  | $ | — |  |  | $ | (3,799) |  |

[0001408710-24-000019:notes:44]
[same as prior period, unchanged from 0001408710-24-000009:notes:44]

[0001408710-24-000019:notes:45]
(1)Interest rate swap agreement with a notional amount of $60.9 million.

[0001408710-24-000019:notes:46]
(2)Foreign currency forward contracts with an aggregate notional amount of $135.0 million and 0.2 million Canadian dollars.

[0001408710-24-000019:notes:47]
[same as prior period, unchanged from 0001408710-24-000009:notes:47]

[0001408710-24-000019:notes:48]
[same as prior period, unchanged from 0001408710-24-000009:notes:48]

[0001408710-24-000019:notes:49]
[same as prior period, unchanged from 0001408710-24-000009:notes:49]

[0001408710-24-000019:notes:50]
[same as prior period, unchanged from 0001408710-24-000009:notes:50]

[0001408710-24-000019:notes:51]
[same as prior period, unchanged from 0001408710-24-000009:notes:51]

[0001408710-24-000019:notes:52]
[same as prior period, unchanged from 0001408710-24-000009:notes:52]

[0001408710-24-000019:notes:53]
[same as prior period, unchanged from 0001408710-24-000009:notes:53]

[0001408710-24-000019:notes:54]
[same as prior period, unchanged from 0001408710-24-000009:notes:54]

[0001408710-24-000019:notes:55]
[same as prior period, unchanged from 0001408710-24-000009:notes:55]

[0001408710-24-000019:notes:56]
As of March 29, 2024, the Company had 135 outstanding U.S. dollar foreign currency forward contracts against Thai baht, with an aggregate notional amount of $135.0 million and maturity dates ranging from April 2024 through October 2024 and one outstanding Canadian dollar foreign currency forward contract with a notional amount of 0.2 million Canadian dollars and a maturity date in June 2024.

[0001408710-24-000019:notes:57]
[same as prior period, unchanged from 0001408710-24-000009:notes:57]

[0001408710-24-000019:notes:58]
As of March 29, 2024, the hedging relationship over foreign currency forward contracts designated for hedge accounting was determined to be highly effective based on the performance of retrospective and prospective regression testing. As of March 29, 2024, the amount in accumulated other comprehensive income (“AOCI”) expected to be reclassified into earnings within 12 months was a loss of $2.9 million.

[0001408710-24-000019:notes:59]
[same as prior period, unchanged from 0001408710-24-000009:notes:59]

[0001408710-24-000019:notes:60]
During the three and nine months ended March 29, 2024, the Company included an unrealized loss of $3.7 million and $0.8 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-24-000019:notes:61]
During the three and nine months ended March 31, 2023, the Company included an unrealized loss of $2.1 million and an unrealized gain of $1.8 million, respectively, from changes in the fair value of a foreign currency forward contract that was

[0001408710-24-000019:notes:62]
not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-24-000019:notes:63]
[same as prior period, unchanged from 0001408710-24-000009:notes:63]

[0001408710-24-000019:notes:64]
The Company has entered into interest rate swap agreements to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. As of March 29, 2024 and June 30, 2023, the Company had one outstanding interest rate swap agreement with a notional amount of $60.9 million.

[0001408710-24-000019:notes:65]
On July 25, 2018, Fabrinet Thailand entered into an interest rate swap agreement to effectively convert the floating interest rate of the term loan under the Company's previous syndicated senior credit facility agreement to a fixed interest rate of 2.86% per annum through the scheduled maturity of the term loan in June 2023 (see Note 10). The Company did not designate this interest rate swap for hedge accounting.

[0001408710-24-000019:notes:66]
On September 3, 2019, Fabrinet Thailand entered into a term loan agreement under a credit facility agreement with Bank of Ayudhya Public Company Limited, and on September 10, 2019, the Company repaid in full the outstanding term loan under the Company's previous syndicated senior credit facility agreement (see Note 10). In conjunction with the funding of the new term loan, the Company entered into a second interest rate swap agreement. The combination of both of these interest rate swaps effectively converts the floating interest rate of the Company’s term loan with Bank of Ayudhya Public Company Limited to a fixed interest rate of 4.36% per annum through the maturity of the term loan in June 2024.

[0001408710-24-000019:notes:67]
On September 27, 2019, the Company designated these two interest rate swaps as a cash flow hedge for the Company’s term loan under the credit facility agreement with Bank of Ayudhya Public Company Limited. The combination of these two interest rate swaps qualified for hedge accounting because the hedges were highly effective, and the Company had designated and documented contemporaneously the hedging relationships involving these interest rate swaps, one of which matured in June 2023. While the Company intends to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in earnings. From September 27, 2019, any gains or losses related to these interest rate swaps are recorded in AOCI in the unaudited condensed consolidated balance sheets. The Company reclassifies a portion of the gains or losses from AOCI into earnings at each reporting period based on either the accrued interest amount or the interest payment.

[0001408710-24-000019:notes:68]
As of March 29, 2024, the amount in AOCI that is expected to be reclassified into earnings within 12 months was de minimis.

[0001408710-24-000019:notes:69]
[same as prior period, unchanged from 0001408710-24-000009:notes:69]

[0001408710-24-000019:notes:70]
[same as prior period, unchanged from 0001408710-24-000009:notes:70]

[0001408710-24-000019:notes:71]
|  |  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) | Financialstatementsline item |  | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
| Derivatives gain (loss) recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Othercomprehensiveincome |  | $ | (8,120) |  |  | $ | (5,068) |  |  | $ | 1,434 |  |  | $ | 6,694 |  |
| Interest rate swaps | Othercomprehensiveincome |  | (41) |  |  | 242 |  |  | (194) |  |  | 1,068 |  |
| Total derivatives gain (loss) recognized in other comprehensive income (loss) |  |  | $ | (8,161) |  |  | $ | (4,826) |  |  | $ | 1,240 |  |  | $ | 7,762 |  |
| Derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings: |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Cost of revenues |  | $ | (2,805) |  |  | $ | (3,245) |  |  | $ | 5,650 |  |  | $ | 6,083 |  |
| Foreign currency forward contracts | SG&A |  | (121) |  |  | (140) |  |  | 233 |  |  | 250 |  |
| Foreign currency forward contracts | Foreign exchange loss, net |  | 4,250 |  |  | 2,807 |  |  | (6,170) |  |  | (9,183) |  |
| Interest rate swaps | Interest expense |  | (44) |  |  | (131) |  |  | (198) |  |  | (477) |  |
| Total derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings |  |  | $ | 1,280 |  |  | $ | (709) |  |  | $ | (485) |  |  | $ | (3,327) |  |
| Change in net unrealized gain (loss) on derivatives instruments |  |  | $ | (6,881) |  |  | $ | (5,535) |  |  | $ | 755 |  |  | $ | 4,435 |  |

[0001408710-24-000019:notes:72]
[same as prior period, unchanged from 0001408710-24-000009:notes:72]

[0001408710-24-000019:notes:73]
[same as prior period, unchanged from 0001408710-24-000009:notes:73]

[0001408710-24-000019:notes:74]
|  | March 29,2024 |  | June 30,2023 |
| (in thousands) | DerivativeAssets |  | DerivativeLiabilities |  | DerivativeAssets |  | DerivativeLiabilities |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts | $ | — |  |  | $ | (901) |  |  | $ | 2 |  |  | $ | (1,256) |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | (2,898) |  |  | 4 |  |  | (3,980) |  |
| Interest rate swaps | 21 |  |  | — |  |  | 215 |  |  | — |  |
| Derivatives, gross balances | $ | 21 |  |  | $ | (3,799) |  |  | $ | 221 |  |  | $ | (5,236) |  |

[0001408710-24-000019:notes:75]
[same as prior period, unchanged from 0001408710-24-000009:notes:75]

[0001408710-24-000019:notes:76]
[same as prior period, unchanged from 0001408710-24-000009:notes:76]


## us-gaap:InventoryDisclosureTextBlock

[0001408710-24-000019:notes:77]
[same as prior period, unchanged from 0001408710-24-000009:notes:77]

[0001408710-24-000019:notes:78]
| (in thousands) | As of March 29,2024 |  | As of June 30,2023 |
| Raw materials | $ | 115,766 |  |  | $ | 157,379 |  |
| Work in progress | 260,965 |  |  | 305,627 |  |
| Finished goods | 44,075 |  |  | 28,608 |  |
| Goods in transit | 33,328 |  |  | 27,962 |  |
| Total inventories | $ | 454,134 |  |  | $ | 519,576 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001408710-24-000019:notes:79]
Leases
The Company leases facilities under non-cancelable operating lease agreements. The Company leases a portion of its capital equipment and vehicles, certain land and buildings for its facilities in Thailand, the Cayman Islands, the PRC, the U.S., Israel and Singapore under operating lease arrangements that expire at various dates through 2029. Certain of these lease arrangements provide the Company the ability to extend the lease term following the expiration of the current term. However, the Company has excluded all lease extension options from its right of use (“ROU”) assets and lease liabilities as the Company is not reasonably assured that it will exercise these options. None of the lease agreements contain residual value guarantees provided by the lessee. The Company also has one intercompany lease transaction in the form of a lease of office and manufacturing space.

[0001408710-24-000019:notes:80]
[same as prior period, unchanged from 0001408710-24-000009:notes:80]

[0001408710-24-000019:notes:81]
As of March 29, 2024, the maturities of the Company’s operating lease liabilities were as follows:

[0001408710-24-000019:notes:82]
| (in thousands) |  |  |
| 2024 (remaining three months) | $ | 444 |  |  |
| 2025 | 1,342 |  |  |
| 2026 | 1,272 |  |  |
| 2027 | 477 |  |  |
| 2028 | 15 |  |  |
| Thereafter | 1 |  |  |
| Total undiscounted lease payments | 3,551 |  |  |
| Less imputed interest | (215) |  |  |
| Total present value of lease liabilities | $ | 3,336 |  | (1) |

[0001408710-24-000019:notes:83]
(1)Includes current portion of operating lease liabilities of $1.3 million.

[0001408710-24-000019:notes:84]
[same as prior period, unchanged from 0001408710-24-000009:notes:84]

[0001408710-24-000019:notes:85]
Rental expense for long-term leases for the three and nine months ended March 29, 2024 was $0.4 million and $1.5 million, respectively, and for the three and nine months ended March 31, 2023 was $0.6 million and $1.8 million, respectively.

[0001408710-24-000019:notes:86]
Rental expense for short-term leases for the three and nine months ended March 29, 2024 was $0.1 million and $0.8 million, respectively, and for the three and nine months ended March 31, 2023 was $0.2 million and $0.3 million, respectively.

[0001408710-24-000019:notes:87]
[same as prior period, unchanged from 0001408710-24-000009:notes:87]

[0001408710-24-000019:notes:88]
|  | As ofMarch 29, 2024 |  | As ofJune 30, 2023 |
| Weighted-average remaining lease term (in years) | 2.5 |  | 1.2 |
| Weighted-average discount rate | 4.6 | % |  | 3.4 | % |

[0001408710-24-000019:notes:89]
The following table presents supplemental disclosure for the unaudited condensed consolidated statements of cash flows related to operating and finance leases for the three and nine months ended March 29, 2024 and March 31, 2023:

[0001408710-24-000019:notes:90]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands) | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |
| Operating cash flows from operating leases | $ | 442 |  |  | $ | 575 |  |  | $ | 2,186 |  |  | $ | 1,877 |  |
| Financing cash flows from finance leases | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 7 |  |
| ROU assets obtained in exchange for lease liabilities | $ | 632 |  |  | $ | — |  |  | $ | 3,406 |  |  | $ | 79 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001408710-24-000019:notes:91]
[same as prior period, unchanged from 0001408710-24-000009:notes:91]

[0001408710-24-000019:notes:92]
| (in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  |  |  | Net |
| As of March 29, 2024 |  |  |  |  |  |  |  |
| Software | $ | 11,253 |  |  | $ | (8,826) |  |  |  |  | $ | 2,427 |  |

[0001408710-24-000019:notes:93]
[same as prior period, unchanged from 0001408710-24-000009:notes:93]

[0001408710-24-000019:notes:94]
The Company recorded amortization expense relating to intangibles of $0.2 million and $0.3 million for the three months ended March 29, 2024 and March 31, 2023, respectively, and $0.8 million and $1.1 million for the nine months ended March 29, 2024 and March 31, 2023, respectively.

[0001408710-24-000019:notes:95]
The weighted-average remaining life of software was:

[0001408710-24-000019:notes:96]
| (years) | As ofMarch 29, 2024 |  | As ofJune 30, 2023 |
| Software | 2.2 |  | 3.1 |

[0001408710-24-000019:notes:97]
Based on the carrying amount of intangibles as of March 29, 2024, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001408710-24-000019:notes:98]
| (in thousands) |  |
| 2024 (remaining three months) | $ | 324 |  |
| 2025 | 831 |  |
| 2026 | 609 |  |
| 2027 | 402 |  |
| 2028 | 229 |  |
| Thereafter | 32 |  |
| Total | $ | 2,427 |  |


## us-gaap:DebtDisclosureTextBlock

[0001408710-24-000019:notes:99]
Borrowings 
The Company’s total borrowings, including current and non-current portions of long-term borrowings, consisted of the following:

[0001408710-24-000019:notes:100]
| (in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofMarch 29, 2024 |  | As ofJune 30, 2023 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 3,047 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (8) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 3,039 |  |  | $ | 12,156 |  |

[0001408710-24-000019:notes:101]
(1)The Company has entered into interest rate swaps that effectively fix a series of future interest payments on its term loans. Refer to Note 6.

[0001408710-24-000019:notes:102]
The movements of long-term borrowings for the nine months ended March 29, 2024 and March 31, 2023 were as follows:

[0001408710-24-000019:notes:103]
|  | Nine Months Ended |
| (in thousands) | March 29,2024 |  | March 31,2023 |
| Opening balance | $ | 12,188 |  |  | $ | 27,421 |  |
| Repayments during the period | (9,141) |  |  | (12,187) |  |
| Closing balance | $ | 3,047 |  |  | $ | 15,234 |  |

[0001408710-24-000019:notes:104]
Credit facility agreements:

[0001408710-24-000019:notes:105]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a credit facility agreement (the “2019 Credit Facility Agreement”), which provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million that may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the 2019 Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

[0001408710-24-000019:notes:106]
Under the 2019 Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a term loan agreement (the "Term Loan Agreement") pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company's previous syndicated senior credit facility agreement.

[0001408710-24-000019:notes:107]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. On March 9, 2023, the Borrower and the Bank amended the Term Loan Agreement to replace the interest rate reference from LIBOR to the Secured Overnight Financing Rate ("SOFR") effective from September 29, 2023. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three and nine months ended March 29, 2024, the Company recorded $0.1 million and $0.3 million, respectively, of interest expense in connection with this term loan, including the impact from interest rate swaps.

[0001408710-24-000019:notes:108]
Any borrowings under the 2019 Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

[0001408710-24-000019:notes:109]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, and restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any

[0001408710-24-000019:notes:110]
payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of March 29, 2024, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

[0001408710-24-000019:notes:111]
The events of default under the Term Loan Agreement include failure to timely pay amounts due under the Term Loan Agreement or the related finance documents, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

[0001408710-24-000019:notes:112]
As of March 29, 2024, there was $3.0 million outstanding under the term loan.

[0001408710-24-000019:notes:113]
On March 9, 2023, Fabrinet Thailand and the Parent Company (the “Borrowers”) and the Bank entered into a credit facility agreement (the “2023 Credit Facility Agreement”), which provides a facility of $55.0 million.

[0001408710-24-000019:notes:114]
Any borrowings under the 2023 Credit Facility Agreement are secured by land and buildings owned by the Borrowers in the Pathumthani and Chonburi Provinces in Thailand.

[0001408710-24-000019:notes:115]
Under the 2023 Credit Facility Agreement, the Borrowers are required to maintain a loan to value of the mortgaged real property ratio of not greater than 60%. The Borrowers are also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times.

[0001408710-24-000019:notes:116]
As of March 29, 2024, there was no amount outstanding under the 2023 Credit Facility Agreement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001408710-24-000019:notes:117]
Income taxes
As of March 29, 2024 and June 30, 2023, the liability for uncertain tax positions including accrued interest and penalties was $1.2 million and $1.5 million, respectively. The Company expects the estimated amount of liability associated with its uncertain tax positions to increase within the next 12 months due to additional provisions associated with uncertain tax positions from one of the Company's subsidiaries and interest on these positions.

[0001408710-24-000019:notes:118]
[same as prior period, unchanged from 0001408710-24-000009:notes:118]

[0001408710-24-000019:notes:119]
The effective tax rate for the Company for the three months ended March 29, 2024 and March 31, 2023 was 2.9% and 6.5%, respectively, of net income. The decrease was due to a decrease in income subject to tax during the three months ended March 29, 2024 as compared to the three months ended March 31, 2023.

[0001408710-24-000019:notes:120]
The effective tax rate for the Company for the nine months ended March 29, 2024 and March 31, 2023 was 5.0% and 3.1%, respectively, of net income. The increase was primarily due to a full valuation allowance of $2.1 million for deferred tax assets being set up during the nine months ended March 29, 2024 due to management's belief that the Company's subsidiary in Israel would continue to have losses in the foreseeable future such that the deferred tax assets of such subsidiary would not be utilized. In addition, a full valuation allowance of $1.6 million from the Company's subsidiary in the U.K. was released during the nine months ended March 31, 2023.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001408710-24-000019:notes:121]
[same as prior period, unchanged from 0001408710-24-000009:notes:120]

[0001408710-24-000019:notes:122]
[same as prior period, unchanged from 0001408710-24-000009:notes:121]

[0001408710-24-000019:notes:123]
The effect of recording share-based compensation expense for the three and nine months ended March 29, 2024 and March 31, 2023 was as follows:

[0001408710-24-000019:notes:124]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands) | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |
| Restricted share units | $ | 3,833 |  |  | $ | 3,945 |  |  | $ | 12,800 |  |  | $ | 12,845 |  |
| Performance share units | 2,893 |  |  | 2,774 |  |  | 8,640 |  |  | 8,372 |  |
| Total share-based compensation expense | 6,726 |  |  | 6,719 |  |  | 21,440 |  |  | 21,217 |  |
| Tax effect on share-based compensation expense | — |  |  | — |  |  | — |  |  | — |  |
| Net effect on share-based compensation expense | $ | 6,726 |  |  | $ | 6,719 |  |  | $ | 21,440 |  |  | $ | 21,217 |  |

[0001408710-24-000019:notes:125]
[same as prior period, unchanged from 0001408710-24-000009:notes:124]

[0001408710-24-000019:notes:126]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands) | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
| Cost of revenue | $ | 1,561 |  |  | $ | 1,453 |  |  | $ | 5,427 |  |  | $ | 5,028 |  |
| Selling, general and administrative expense | 5,165 |  |  | 5,080 |  |  | 16,013 |  |  | 16,003 |  |
| Restructuring and other related costs | — |  |  | 186 |  |  | — |  |  | 186 |  |
| Total share-based compensation expense | $ | 6,726 |  |  | $ | 6,719 |  |  | $ | 21,440 |  |  | $ | 21,217 |  |

[0001408710-24-000019:notes:127]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the three and nine months ended March 29, 2024 and March 31, 2023.

[0001408710-24-000019:notes:128]
[same as prior period, unchanged from 0001408710-24-000009:notes:127]

[0001408710-24-000019:notes:129]
[same as prior period, unchanged from 0001408710-24-000009:notes:128]

[0001408710-24-000019:notes:130]
[same as prior period, unchanged from 0001408710-24-000009:notes:129]

[0001408710-24-000019:notes:131]
[same as prior period, unchanged from 0001408710-24-000009:notes:130]

[0001408710-24-000019:notes:132]
The following table summarizes the number of equity awards outstanding and ordinary shares available for grant under each of the Equity Incentive Plans as of March 29, 2024:

[0001408710-24-000019:notes:133]
| (share units) | Restricted Share Units outstanding |  | Performance Share Units outstanding |  | Ordinary Shares available for future grant |
| 2020 Plan | 311,565 |  |  | 171,078 |  |  | 1,753,905 |  |
| 2017 Inducement Plan | — |  |  | — |  |  | 111,347 |  |
| Total | 311,565 |  |  | 171,078 |  |  | 1,865,252 |  |

[0001408710-24-000019:notes:134]
[same as prior period, unchanged from 0001408710-24-000009:notes:133]

[0001408710-24-000019:notes:135]
[same as prior period, unchanged from 0001408710-24-000009:notes:134]

[0001408710-24-000019:notes:136]
[same as prior period, unchanged from 0001408710-24-000009:notes:135]

[0001408710-24-000019:notes:137]
[same as prior period, unchanged from 0001408710-24-000009:notes:136]

[0001408710-24-000019:notes:138]
[same as prior period, unchanged from 0001408710-24-000009:notes:137]

[0001408710-24-000019:notes:139]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 30, 2023 | 368,765 |  |  | $ | 97.49 |  |
| Granted | 119,097 |  |  | $ | 162.02 |  |
| Vested | (161,927) |  |  | $ | 88.75 |  |
| Forfeited | (14,370) |  |  | $ | 119.71 |  |
| Balance as of March 29, 2024 | 311,565 |  |  | $ | 125.67 |  |

[0001408710-24-000019:notes:140]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 24, 2022 | 459,626 |  |  | $ | 75.14 |  |
| Granted | 154,113 |  |  | $ | 119.23 |  |
| Vested | (220,004) |  |  | $ | 67.23 |  |
| Forfeited | (19,697) |  |  | $ | 91.84 |  |
| Balance as of March 31, 2023 | 374,038 |  |  | $ | 97.08 |  |

[0001408710-24-000019:notes:141]
[same as prior period, unchanged from 0001408710-24-000009:notes:140]

[0001408710-24-000019:notes:142]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 30, 2023 | 204,016 |  |  | $ | 108.81 |  |
| Granted | 73,936 |  |  | $ | 158.91 |  |
| Vested | (106,874) |  |  | $ | 101.05 |  |
| Forfeited | — |  |  | $ | — |  |
| Balance as of March 29, 2024 | 171,078 |  |  | $ | 135.31 |  |

[0001408710-24-000019:notes:143]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 24, 2022 | 285,882 |  |  | $ | 81.64 |  |
| Granted | 97,142 |  |  | $ | 117.35 |  |
| Vested | (179,008) |  |  | 70.05 |  |
| Forfeited | — |  |  | $ | — |  |
| Balance as of March 31, 2023 | 204,016 |  |  | $ | 108.81 |  |

[0001408710-24-000019:notes:144]
As of March 29, 2024, there was $16.3 million and $9.7 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.6 and 1.1 years, respectively.

[0001408710-24-000019:notes:145]
For the nine months ended March 29, 2024 and March 31, 2023, the Company withheld an aggregate of 102,543 shares and 172,929 shares, respectively, upon the vesting of restricted share units and performance shares units, based upon the closing share price on the vesting date to settle employee tax withholding obligations. For the nine months ended March 29, 2024 and March 31, 2023, the Company then remitted cash of $12.7 million and $17.7 million, respectively, to the appropriate taxing authorities and presented it as a financing activity within the unaudited condensed consolidated statements of cash flows. The payment was recorded as a reduction of additional paid-in capital.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001408710-24-000019:notes:146]
[same as prior period, unchanged from 0001408710-24-000009:notes:145]

[0001408710-24-000019:notes:147]
[same as prior period, unchanged from 0001408710-24-000009:notes:146]

[0001408710-24-000019:notes:148]
For the three and nine months ended March 29, 2024, Fabrinet issued 15,080 and 166,258 ordinary shares, respectively, upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-24-000019:notes:149]
For the three and nine months ended March 31, 2023, Fabrinet issued 23,202 and 226,083 ordinary shares, respectively, upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-24-000019:notes:150]
[same as prior period, unchanged from 0001408710-24-000009:notes:149]

[0001408710-24-000019:notes:151]
[same as prior period, unchanged from 0001408710-24-000009:notes:150]

[0001408710-24-000019:notes:152]
[same as prior period, unchanged from 0001408710-24-000009:notes:151]

[0001408710-24-000019:notes:153]
During the nine months ended March 29, 2024, 190,839 shares were repurchased under the program, at an average price per share (excluding other direct costs) of $188.32, for an aggregate purchase price of $35.9 million. As of March 29, 2024, the Company had a remaining authorization to repurchase up to $64.1 million worth of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001408710-24-000019:notes:154]
Accumulated other comprehensive income (loss)
The changes in AOCI for the nine months ended March 29, 2024 and March 31, 2023 were as follows:

[0001408710-24-000019:notes:155]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 30, 2023 | $ | (3,279) |  |  | $ | (3,541) |  |  | $ | (330) |  |  | $ | (965) |  |  | $ | (8,115) |  |
| Other comprehensive income (loss) before reclassification | 2,154 |  |  | 1,240 |  |  | — |  |  | (31) |  |  | 3,363 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | 1 |  |  | (485) |  |  | 250 |  |  | — |  |  | (234) |  |
| Tax effects | — |  |  | 307 |  |  | 21 |  |  | — |  |  | 328 |  |
| Other comprehensive income (loss) | $ | 2,155 |  |  | $ | 1,062 |  |  | $ | 271 |  |  | $ | (31) |  |  | $ | 3,457 |  |
| Balance as of March 29, 2024 | $ | (1,124) |  |  | $ | (2,479) |  |  | $ | (59) |  |  | $ | (996) |  |  | $ | (4,658) |  |

[0001408710-24-000019:notes:156]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 24, 2022 | $ | (6,018) |  |  | $ | (5,082) |  |  | $ | (803) |  |  | $ | (890) |  |  | $ | (12,793) |  |
| Other comprehensive income (loss) before reclassification | 1,675 |  |  | 7,762 |  |  | — |  |  | (29) |  |  | 9,408 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | 93 |  |  | (3,327) |  |  | 338 |  |  | — |  |  | (2,896) |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | $ | 1,768 |  |  | $ | 4,435 |  |  | $ | 338 |  |  | $ | (29) |  |  | $ | 6,512 |  |
| Balance as of March 31, 2023 | $ | (4,250) |  |  | $ | (647) |  |  | $ | (465) |  |  | $ | (919) |  |  | $ | (6,281) |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001408710-24-000019:notes:157]
Commitments and contingencies
Bank guarantees

[0001408710-24-000019:notes:158]
As of March 29, 2024 and June 30, 2023, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.0 million and $1.5 million, respectively, or Thai baht 73.2 million and 53.0 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the subsidiary's operations related to the Israeli Customs department.

[0001408710-24-000019:notes:159]
Purchase obligations

[0001408710-24-000019:notes:160]
Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001408710-24-000019:notes:161]
As of March 29, 2024, the Company had purchase obligations and other commitments to third parties of $850.9 million.

[0001408710-24-000019:notes:162]
Capital expenditures

[0001408710-24-000019:notes:163]
As of March 29, 2024, the Company had total capital expenditure commitments to third parties of $27.7 million.

[0001408710-24-000019:notes:164]
Indemnification of directors and officers

[0001408710-24-000019:notes:165]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001408710-24-000019:notes:166]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001408710-24-000019:notes:167]
Restructuring and other related costs
Restructuring and other related costs may consist of severance-related charges, asset-related charges and other costs due to exit activities. The Company recognizes severance-related charges depending on whether the termination benefits are provided under an ongoing benefit arrangement or under a one-time benefit arrangement. The Company recognizes the charges once the benefits have been communicated to employees.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001408710-24-000019:notes:168]
Business segments and geographic information
Operating segments are defined as components of an enterprise that engage in business activities for which discrete financial information is available that is evaluated regularly by the chief operating decision maker (the “CODM”) in deciding how to allocate resources and in assessing performance. The Company’s CODM is Fabrinet’s Chief Executive Officer. As of March 29, 2024, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001408710-24-000019:notes:169]
For the Company’s revenues by geographic region, see “Revenue by Geographic Area, End Market and Product Category” in Note 3.

[0001408710-24-000019:notes:170]
[same as prior period, unchanged from 0001408710-24-000009:notes:168]

[0001408710-24-000019:notes:171]
| (in thousands) |  | March 29,2024 |  | June 30,2023 |
| Long-Lived Assets: |  |  |  |  |
| Thailand |  | $ | 257,510 |  |  | $ | 264,382 |  |
| U.S. |  | 27,812 |  |  | 25,267 |  |
| China |  | 15,083 |  |  | 17,407 |  |
| Israel |  | 2,268 |  |  | 2,796 |  |
| Others |  | 445 |  |  | 498 |  |
| Total |  | $ | 303,118 |  |  | $ | 310,350 |  |

[0001408710-24-000019:notes:172]
[same as prior period, unchanged from 0001408710-24-000009:notes:170]

[0001408710-24-000019:notes:173]
The Company had three customers that each contributed to 10% or more of the Company's total trade accounts receivable as of March 29, 2024 and June 30, 2023.
