# FN MD&A — 0001408710-24-000019


## mdna

[0001408710-24-000019:mdna:1]
[same as prior period, unchanged from 0001408710-24-000009:mdna:1]

[0001408710-24-000019:mdna:2]
[same as prior period, unchanged from 0001408710-24-000009:mdna:2]

[0001408710-24-000019:mdna:3]
[same as prior period, unchanged from 0001408710-24-000009:mdna:3]

[0001408710-24-000019:mdna:4]
[same as prior period, unchanged from 0001408710-24-000009:mdna:4]

[0001408710-24-000019:mdna:5]
•our expectation that the portion of our revenues attributable to customers in regions outside of North America for the remainder of fiscal year 2024 will be in line with the portion of revenues attributable to such customers during the nine months ended March 29, 2024;

[0001408710-24-000019:mdna:6]
[same as prior period, unchanged from 0001408710-24-000009:mdna:6]

[0001408710-24-000019:mdna:7]
[same as prior period, unchanged from 0001408710-24-000009:mdna:7]

[0001408710-24-000019:mdna:8]
[same as prior period, unchanged from 0001408710-24-000009:mdna:8]

[0001408710-24-000019:mdna:9]
[same as prior period, unchanged from 0001408710-24-000009:mdna:9]

[0001408710-24-000019:mdna:10]
[same as prior period, unchanged from 0001408710-24-000009:mdna:10]

[0001408710-24-000019:mdna:11]
[same as prior period, unchanged from 0001408710-24-000009:mdna:11]

[0001408710-24-000019:mdna:12]
[same as prior period, unchanged from 0001408710-24-000009:mdna:12]

[0001408710-24-000019:mdna:13]
[same as prior period, unchanged from 0001408710-24-000009:mdna:13]

[0001408710-24-000019:mdna:14]
[same as prior period, unchanged from 0001408710-24-000009:mdna:14]

[0001408710-24-000019:mdna:15]
[same as prior period, unchanged from 0001408710-24-000009:mdna:15]

[0001408710-24-000019:mdna:16]
[same as prior period, unchanged from 0001408710-24-000009:mdna:16]

[0001408710-24-000019:mdna:17]
[same as prior period, unchanged from 0001408710-24-000009:mdna:17]

[0001408710-24-000019:mdna:18]
[same as prior period, unchanged from 0001408710-24-000009:mdna:18]

[0001408710-24-000019:mdna:19]
[same as prior period, unchanged from 0001408710-24-000009:mdna:19]

[0001408710-24-000019:mdna:20]
[same as prior period, unchanged from 0001408710-24-000009:mdna:20]

[0001408710-24-000019:mdna:21]
[same as prior period, unchanged from 0001408710-24-000009:mdna:21]

[0001408710-24-000019:mdna:22]
[same as prior period, unchanged from 0001408710-24-000009:mdna:22]

[0001408710-24-000019:mdna:23]
[same as prior period, unchanged from 0001408710-24-000009:mdna:23]

[0001408710-24-000019:mdna:24]
[same as prior period, unchanged from 0001408710-24-000009:mdna:24]

[0001408710-24-000019:mdna:25]
[same as prior period, unchanged from 0001408710-24-000009:mdna:25]

[0001408710-24-000019:mdna:26]
[same as prior period, unchanged from 0001408710-24-000009:mdna:26]

[0001408710-24-000019:mdna:27]
[same as prior period, unchanged from 0001408710-24-000009:mdna:27]

[0001408710-24-000019:mdna:28]
[same as prior period, unchanged from 0001408710-24-000009:mdna:28]

[0001408710-24-000019:mdna:29]
[same as prior period, unchanged from 0001408710-24-000009:mdna:29]

[0001408710-24-000019:mdna:30]
The percentage of our revenues generated from a bill-to location outside of North America increased from 52.5% in the three months ended March 31, 2023 to 62.8% in the three months ended March 29, 2024, primarily because of an increase in revenue from a customer in Israel and a decrease in sales to our customers in North America.

[0001408710-24-000019:mdna:31]
The percentage of our revenues generated from a bill-to location outside of North America increased from 50.3% in the nine months ended March 31, 2023 to 63.7% in the nine months ended March 29, 2024, primarily because of an increase in revenue from a customer in Israel and a decrease in sales to our customers in North America.

[0001408710-24-000019:mdna:32]
31

[0001408710-24-000019:mdna:33]
Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside North America for the remainder of fiscal year 2024 will be in line with the portion of revenues attributable to such customers during the nine months ended March 29, 2024.

[0001408710-24-000019:mdna:34]
[same as prior period, unchanged from 0001408710-24-000009:mdna:33]

[0001408710-24-000019:mdna:35]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29, 2024 |  | March 31, 2023 |  | March 29, 2024 |  | March 31, 2023 |
| North America | 37.2 | % |  | 47.5 | % |  | 36.3 | % |  | 49.7 | % |
| Asia-Pacific and others | 57.0 |  |  | 42.1 |  |  | 57.2 |  |  | 41.1 |  |
| Europe | 5.8 |  |  | 10.4 |  |  | 6.5 |  |  | 9.2 |  |
|  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001408710-24-000019:mdna:36]
[same as prior period, unchanged from 0001408710-24-000009:mdna:35]

[0001408710-24-000019:mdna:37]
[same as prior period, unchanged from 0001408710-24-000009:mdna:36]

[0001408710-24-000019:mdna:38]
[same as prior period, unchanged from 0001408710-24-000009:mdna:37]

[0001408710-24-000019:mdna:39]
[same as prior period, unchanged from 0001408710-24-000009:mdna:38]

[0001408710-24-000019:mdna:40]
[same as prior period, unchanged from 0001408710-24-000009:mdna:39]

[0001408710-24-000019:mdna:41]
[same as prior period, unchanged from 0001408710-24-000009:mdna:40]

[0001408710-24-000019:mdna:42]
[same as prior period, unchanged from 0001408710-24-000009:mdna:41]

[0001408710-24-000019:mdna:43]
[same as prior period, unchanged from 0001408710-24-000009:mdna:42]

[0001408710-24-000019:mdna:44]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative and other support personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other general expenses not related to cost of revenues. In fiscal year 2024, we expect our SG&A expenses will increase compared with our fiscal year 2023 SG&A expenses, mainly due to increases in employee costs and sales and marketing costs.

[0001408710-24-000019:mdna:45]
[same as prior period, unchanged from 0001408710-24-000009:mdna:44]

[0001408710-24-000019:mdna:46]
[same as prior period, unchanged from 0001408710-24-000009:mdna:45]

[0001408710-24-000019:mdna:47]
[same as prior period, unchanged from 0001408710-24-000009:mdna:46]

[0001408710-24-000019:mdna:48]
[same as prior period, unchanged from 0001408710-24-000009:mdna:47]

[0001408710-24-000019:mdna:49]
[same as prior period, unchanged from 0001408710-24-000009:mdna:48]

[0001408710-24-000019:mdna:50]
[same as prior period, unchanged from 0001408710-24-000009:mdna:49]

[0001408710-24-000019:mdna:51]
|  | As of March 29, 2024 |  | As of June 30, 2023 |
| (in thousands, except percentages) | ForeignCurrency |  | $ |  | % |  | ForeignCurrency |  | $ |  | % |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 934,967 |  |  | $ | 25,637 |  |  | 68.1 | % |  | 754,443 |  |  | $ | 21,198 |  |  | 60.6 | % |
| RMB | 49,788 |  |  | 7,017 |  |  | 18.6 |  |  | 66,501 |  |  | 9,203 |  |  | 26.3 |  |
| GBP | 3,979 |  |  | 5,021 |  |  | 13.3 |  |  | 3,626 |  |  | 4,575 |  |  | 13.1 |  |
| Total |  |  | $ | 37,675 |  |  | 100.0 | % |  |  |  | $ | 34,976 |  |  | 100.0 | % |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 3,078,421 |  |  | $ | 84,410 |  |  | 88.3 | % |  | 2,956,730 |  |  | $ | 83,078 |  |  | 87.0 | % |
| RMB | 72,451 |  |  | 10,212 |  |  | 10.7 |  |  | 74,652 |  |  | 10,331 |  |  | 10.8 |  |
| GBP | 743 |  |  | 937 |  |  | 1.0 |  |  | 1,625 |  |  | 2,050 |  |  | 2.2 |  |
| Total |  |  | $ | 95,559 |  |  | 100.0 | % |  |  |  | $ | 95,459 |  |  | 100.0 | % |

[0001408710-24-000019:mdna:52]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy As of March 29, 2024, there was $135.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 30, 2023, there was $143.0 million of foreign currency forward contracts outstanding on the Thai baht payables.

[0001408710-24-000019:mdna:53]
The RMB assets represent cash and cash equivalents, trade accounts receivable, other receivables, and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable, accrued payroll, bonus and related expenses, and other payables. As of March 29, 2024 and June 30, 2023, we did not have any derivative contracts denominated in RMB.

[0001408710-24-000019:mdna:54]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable, accrued expenses and other payables. As of March 29, 2024 and June 30, 2023, we did not have any derivative contracts denominated in GBP.

[0001408710-24-000019:mdna:55]
For the three months ended March 29, 2024 and March 31, 2023, we recorded a loss of $3.7 million and $2.1 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-24-000019:mdna:56]
For the nine months ended March 29, 2024 and March 31, 2023, we recorded a loss of $0.8 million and gain of $1.8 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-24-000019:mdna:57]
[same as prior period, unchanged from 0001408710-24-000009:mdna:56]

[0001408710-24-000019:mdna:58]
[same as prior period, unchanged from 0001408710-24-000009:mdna:57]

[0001408710-24-000019:mdna:59]
[same as prior period, unchanged from 0001408710-24-000009:mdna:58]

[0001408710-24-000019:mdna:60]
[same as prior period, unchanged from 0001408710-24-000009:mdna:59]

[0001408710-24-000019:mdna:61]
[same as prior period, unchanged from 0001408710-24-000009:mdna:60]

[0001408710-24-000019:mdna:62]
[same as prior period, unchanged from 0001408710-24-000009:mdna:61]

[0001408710-24-000019:mdna:63]
[same as prior period, unchanged from 0001408710-24-000009:mdna:62]

[0001408710-24-000019:mdna:64]
[same as prior period, unchanged from 0001408710-24-000009:mdna:63]

[0001408710-24-000019:mdna:65]
[same as prior period, unchanged from 0001408710-24-000009:mdna:64]

[0001408710-24-000019:mdna:66]
[same as prior period, unchanged from 0001408710-24-000009:mdna:66]

[0001408710-24-000019:mdna:67]
[same as prior period, unchanged from 0001408710-24-000009:mdna:67]

[0001408710-24-000019:mdna:68]
[same as prior period, unchanged from 0001408710-24-000009:mdna:68]

[0001408710-24-000019:mdna:69]
[same as prior period, unchanged from 0001408710-24-000009:mdna:69]

[0001408710-24-000019:mdna:70]
[same as prior period, unchanged from 0001408710-24-000009:mdna:70]

[0001408710-24-000019:mdna:71]
As of March 29, 2024, the corporate income tax rates for our subsidiaries in the PRC, the U.S., the U.K. and Israel are 25%, 21%, 25% and 23%, respectively.

[0001408710-24-000019:mdna:72]
[same as prior period, unchanged from 0001408710-24-000009:mdna:72]

[0001408710-24-000019:mdna:73]
[same as prior period, unchanged from 0001408710-24-000009:mdna:73]

[0001408710-24-000019:mdna:74]
[same as prior period, unchanged from 0001408710-24-000009:mdna:74]

[0001408710-24-000019:mdna:75]
[same as prior period, unchanged from 0001408710-24-000009:mdna:75]

[0001408710-24-000019:mdna:76]
[same as prior period, unchanged from 0001408710-24-000009:mdna:76]

[0001408710-24-000019:mdna:77]
[same as prior period, unchanged from 0001408710-24-000009:mdna:77]

[0001408710-24-000019:mdna:78]
| (in thousands) | Three Months Ended |  | Nine Months Ended |
| March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
| Revenues | $ | 731,535 |  |  | $ | 665,281 |  |  | $ | 2,129,706 |  |  | $ | 1,989,366 |  |
| Cost of revenues | (640,600) |  |  | (579,274) |  |  | (1,866,037) |  |  | (1,735,388) |  |
| Gross profit | 90,935 |  |  | 86,007 |  |  | 263,669 |  |  | 253,978 |  |
| Selling, general and administrative expenses | (19,628) |  |  | (18,309) |  |  | (59,373) |  |  | (57,804) |  |
| Restructuring and other related costs | — |  |  | (5,872) |  |  | — |  |  | (5,872) |  |
| Operating income | 71,307 |  |  | 61,826 |  |  | 204,296 |  |  | 190,302 |  |
| Interest income | 8,509 |  |  | 3,317 |  |  | 22,155 |  |  | 7,210 |  |
| Interest expense | (26) |  |  | (399) |  |  | (107) |  |  | (1,179) |  |
| Foreign exchange gain (loss), net | 3,348 |  |  | (1,303) |  |  | (25) |  |  | (3,122) |  |
| Other income (expense), net | 175 |  |  | 31 |  |  | 60 |  |  | (178) |  |
| Income before income taxes | 83,313 |  |  | 63,472 |  |  | 226,379 |  |  | 193,033 |  |
| Income tax expense | (2,397) |  |  | (4,117) |  |  | (11,264) |  |  | (5,906) |  |
| Net income | 80,916 |  |  | 59,355 |  |  | 215,115 |  |  | 187,127 |  |
| Other comprehensive income (loss), net of tax | (8,855) |  |  | (3,567) |  |  | 3,457 |  |  | 6,512 |  |
| Net comprehensive income | $ | 72,061 |  |  | $ | 55,788 |  |  | $ | 218,572 |  |  | $ | 193,639 |  |

[0001408710-24-000019:mdna:79]
[same as prior period, unchanged from 0001408710-24-000009:mdna:79]

[0001408710-24-000019:mdna:80]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 29,2024 |  | March 31,2023 |  | March 29,2024 |  | March 31,2023 |
| Revenues | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenues | (87.6) |  |  | (87.1) |  |  | (87.6) |  |  | (87.2) |  |
| Gross profit | 12.4 |  |  | 12.9 |  |  | 12.4 |  |  | 12.8 |  |
| Selling, general and administrative expenses | (2.7) |  |  | (2.7) |  |  | (2.8) |  |  | (2.9) |  |
| Restructuring and other related costs | — |  |  | (0.9) |  |  | — |  |  | (0.3) |  |
| Operating income | 9.7 |  |  | 9.3 |  |  | 9.6 |  |  | 9.6 |  |
| Interest income | 1.2 |  |  | 0.5 |  |  | 1.0 |  |  | 0.4 |  |
| Interest expense | 0.0 |  |  | (0.1) |  |  | 0.0 |  |  | (0.1) |  |
| Foreign exchange gain (loss), net | 0.5 |  |  | (0.2) |  |  | 0.0 |  |  | (0.2) |  |
| Other income (expense), net | 0.0 |  |  | 0.0 |  |  | 0.0 |  |  | 0.0 |  |
| Income before income taxes | 11.4 |  |  | 9.5 |  |  | 10.6 |  |  | 9.7 |  |
| Income tax expense | (0.3) |  |  | (0.6) |  |  | (0.5) |  |  | (0.3) |  |
| Net income | 11.1 |  |  | 8.9 |  |  | 10.1 |  |  | 9.4 |  |
| Other comprehensive income (loss), net of tax | (1.2) |  |  | (0.5) |  |  | 0.2 |  |  | 0.3 |  |
| Net comprehensive income | 9.9 | % |  | 8.4 | % |  | 10.3 | % |  | 9.7 | % |

[0001408710-24-000019:mdna:81]
[same as prior period, unchanged from 0001408710-24-000009:mdna:81]

[0001408710-24-000019:mdna:82]
The following table sets forth our revenues by end market and product category for the periods indicated.

[0001408710-24-000019:mdna:83]
| (in thousands, except percentages) | Three Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 305,478 |  |  |  |  | $ | 835,642 |  |  |  |
| Telecom | 285,970 |  |  |  |  | 856,997 |  |  |  |
| Total revenue - Optical communications | $ | 591,448 |  |  | 80.9 | % |  | $ | 1,692,639 |  |  | 79.5 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 73,636 |  |  |  |  | $ | 241,166 |  |  |  |
| Industrial laser | 30,319 |  |  |  |  | 90,582 |  |  |  |
| Others | 36,132 |  |  |  |  | 105,319 |  |  |  |
| Total revenue - Non-optical communications | $ | 140,087 |  |  | 19.1 | % |  | $ | 437,067 |  |  | 20.5 | % |
| Total revenue | $ | 731,535 |  |  | 100.0 | % |  | $ | 2,129,706 |  |  | 100.0 | % |

[0001408710-24-000019:mdna:84]
| (in thousands, except percentages) | Three Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 122,385 |  |  |  |  | $ | 328,271 |  |  |  |
| Telecom | 380,230 |  |  |  |  | 1,177,961 |  |  |  |
| Total revenue - Optical communications | $ | 502,615 |  |  | 75.5 | % |  | $ | 1,506,232 |  |  | 75.7 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 94,107 |  |  |  |  | $ | 275,704 |  |  |  |
| Industrial laser | 31,040 |  |  |  |  | 97,396 |  |  |  |
| Others | 37,519 |  |  |  |  | 110,034 |  |  |  |
| Total revenue - Non-optical communications | $ | 162,666 |  |  | 24.5 | % |  | $ | 483,134 |  |  | 24.3 | % |
| Total revenue | $ | 665,281 |  |  | 100.0 | % |  | $ | 1,989,366 |  |  | 100.0 | % |

[0001408710-24-000019:mdna:85]
Comparison of Three and Nine Months Ended March 29, 2024 with Three and Nine Months Ended March 31, 2023

[0001408710-24-000019:mdna:86]
[same as prior period, unchanged from 0001408710-24-000009:mdna:86]

[0001408710-24-000019:mdna:87]
Our revenues increased by $66.2 million, or 10.0%, to $731.5 million for the three months ended March 29, 2024, compared with $665.3 million for the three months ended March 31, 2023. This increase was primarily due to an increase in our key customers’ demand for optical communications products. Revenues from optical communications products, which represented $591.4 million, or 80.9%, of our revenues for the three months ended March 29, 2024, increased by $88.8 million, or 17.7%, compared to the same period in the prior fiscal year, mainly due to an increase in revenues from data communication products, primarily for artificial intelligence applications, offset by a decline in revenues from telecommunication products as inventory absorption within the telecommunication market continued during the three months ended March 29, 2024. Revenues from non-optical communications products, which represented $140.1 million, or 19.1%, of our revenues for the three months ended March 29, 2024, decreased by $22.6 million, or 13.9%, compared to the same period in the prior fiscal year, primarily due to inventory absorption related to certain programs in the automotive market.

[0001408710-24-000019:mdna:88]
Our revenues increased by $140.3 million, or 7.1%, to $2,129.7 million for the nine months ended March 29, 2024 (39-week period), compared with $1,989.4 million for the nine months ended March 31, 2023 (40-week period). This increase was primarily due to an increase in our key customers’ demand for optical communications products. Revenues from optical communications products, which represented $1,692.6 million, or 79.5%, of our revenues for the nine months ended March 29, 2024, increased by $186.4 million, or 12.4%, compared to the same period in the prior fiscal year, mainly due to an increase in revenues from data communication products, primarily for artificial intelligence applications, offset by a decline in revenues from telecommunication products as inventory absorption within the telecommunication market continued during the nine months ended March 29, 2024. Revenues from non-optical communications products, which represented $437.1 million, or

[0001408710-24-000019:mdna:89]
20.5%, of our revenues for the nine months ended March 29, 2024, decreased by $46.1 million, or 9.5%, compared to the same period in the prior fiscal year, primarily due to inventory absorption related to certain programs in the automotive market.

[0001408710-24-000019:mdna:90]
[same as prior period, unchanged from 0001408710-24-000009:mdna:89]

[0001408710-24-000019:mdna:91]
Our cost of revenues increased by $61.3 million, or 10.6%, to $640.6 million, or 87.6% of revenues, for the three months ended March 29, 2024, compared with $579.3 million, or 87.1% of revenues, for the three months ended March 31, 2023. The increase was in line with the increase in sales volume.

[0001408710-24-000019:mdna:92]
Our cost of revenues increased by $130.6 million, or 7.5%, to $1,866.0 million, or 87.6% of revenues, for the nine months ended March 29, 2024, compared with $1,735.4 million, or 87.2% of revenues, for the nine months ended March 31, 2023. This increase was in line with the increase in sales volume.

[0001408710-24-000019:mdna:93]
[same as prior period, unchanged from 0001408710-24-000009:mdna:92]

[0001408710-24-000019:mdna:94]
Our gross profit increased by $4.9 million, or 5.7%, to $90.9 million, or 12.4% of revenues, for the three months ended March 29, 2024, compared with $86.0 million, or 12.9% of revenues, for the three months ended March 31, 2023. The increase was primarily due to an increase in sales volume.

[0001408710-24-000019:mdna:95]
Our gross profit increased by $9.7 million, or 3.8%, to $263.7 million, or 12.4% of revenues, for the nine months ended March 29, 2024, compared with $254.0 million, or 12.8% of revenues, for the nine months ended March 31, 2023. The increase was primarily due to an increase in sales volume.

[0001408710-24-000019:mdna:96]
[same as prior period, unchanged from 0001408710-24-000009:mdna:95]

[0001408710-24-000019:mdna:97]
Our SG&A expenses increased by $1.3 million, or 7.1%, to $19.6 million, or 2.7% of revenues, for the three months ended March 29, 2024, compared with $18.3 million, or 2.7% of revenues, for the three months ended March 31, 2023. The increase was primarily due to (1) a net increase in allowance for expected credit losses of $0.6 million, (2) an increase in compensation related expenses of $0.5 million and (3) an increase in sales and marketing expenses of $0.1 million.

[0001408710-24-000019:mdna:98]
Our SG&A expenses increased by $1.6 million, or 2.8%, to $59.4 million, or 2.8% of revenues, for the nine months ended March 29, 2024, compared with $57.8 million, or 2.9% of revenues, for the nine months ended March 31, 2023. The increase was primarily due to (1) a net increase in allowance for expected credit losses of $2.0 million and (2) an increase in sales and marketing expenses of $0.7 million, offset by (1) lower compensation related expenses of $0.6 million, (2) a decrease in legal and consulting fees of $0.3 million and (3) a decrease in customer relationships amortization of $0.2 million.

[0001408710-24-000019:mdna:99]
[same as prior period, unchanged from 0001408710-24-000009:mdna:98]

[0001408710-24-000019:mdna:100]
Our operating income increased by $9.5 million, or 15.4%, to $71.3 million, or 9.7% of revenues, for the three months ended March 29, 2024, compared with $61.8 million, or 9.3% of revenues, for the three months ended March 31, 2023. The increase was primarily due to an increase in revenues.

[0001408710-24-000019:mdna:101]
Our operating income increased by $14.0 million, or 7.4%, to $204.3 million, or 9.6% of revenues, for the nine months ended March 29, 2024, compared with $190.3 million, or 9.6% of revenues, for the nine months ended March 31, 2023. The increase was primarily due to an increase in revenues.

[0001408710-24-000019:mdna:102]
Restructuring and other related costs

[0001408710-24-000019:mdna:103]
We had no restructuring costs for the three and nine months ended March 29, 2024. We recorded restructuring and other related costs for the three and nine months ended March 31, 2023 of $5.9 million due to cessation of operations in a subsidiary.

[0001408710-24-000019:mdna:104]
[same as prior period, unchanged from 0001408710-24-000009:mdna:101]

[0001408710-24-000019:mdna:105]
Our interest income increased by $5.2 million, or 157.6%, to $8.5 million, or 1.2% of revenues, for the three months ended March 29, 2024, compared with $3.3 million, or 0.5% of revenues, for the three months ended March 31, 2023. The increase was primarily due to a higher weighted average interest rate and higher average cash balance and short-term investment from $493.9 million to $760.0 million during the three months ended March 29, 2024 compared to the same period in the prior fiscal year.

[0001408710-24-000019:mdna:106]
Our interest income increased by $14.9 million, or 206.9%, to $22.1 million, or 1.0% of revenues, for the nine months ended March 29, 2024, compared with $7.2 million, or 0.4% of revenues, for the nine months ended March 31, 2023. The increase was primarily due to a higher weighted average interest rate and higher average cash balance and short-term investment from $458.0 million to $683.0 million during the nine months ended March 29, 2024 compared to same period in the prior fiscal year.

[0001408710-24-000019:mdna:107]
[same as prior period, unchanged from 0001408710-24-000009:mdna:104]

[0001408710-24-000019:mdna:108]
Our interest expense decreased by $0.4 million for the three months ended March 29, 2024, compared with the three months ended March 31, 2023. The decrease was primarily due to a decrease in the long-term loan balance.

[0001408710-24-000019:mdna:109]
Our interest expense decreased by $1.1 million for the nine months ended March 29, 2024, compared with the nine months ended March 31, 2023. The decrease was primarily due to a decrease in the long-term loan balance.

[0001408710-24-000019:mdna:110]
[same as prior period, unchanged from 0001408710-24-000009:mdna:107]

[0001408710-24-000019:mdna:111]
We recorded foreign exchange gain, net of $3.3 million, or 0.5% of revenues, for the three months ended March 29, 2024, compared with foreign exchange loss, net of $1.3 million, or 0.2% of revenues, for the three months ended March 31, 2023. The foreign exchange gain was mainly due to (1) higher unrealized gain from revaluation of outstanding Thai baht assets and liabilities of $5.0 million, (2) higher unrealized gain from revaluation of currencies other than Thai baht of $0.8 million, and (3) lower realized loss from payment/receipt of $0.5 million, offset by (1) higher unrealized loss from mark-to-market forward contracts of $1.6 million, and (2) foreign exchange loss, totaling $0.1 million from our subsidiaries in the PRC and the U.K.

[0001408710-24-000019:mdna:112]
We recorded foreign exchange loss, net of $25.0 thousand, or 0.0% of revenues, for the nine months ended March 29, 2024, compared with foreign exchange loss, net of $3.1 million, or 0.2% of revenues, for the nine months ended March 31, 2023. The decrease in foreign exchange loss was mainly due to (1) unrealized gain from revaluation of outstanding Thai baht assets and liabilities of $5.3 million, and (2) unrealized gain from revaluation of currencies other than Thai baht of $0.6 million, offset by (1) unrealized loss from mark-to-market forward contracts of $2.6 million, and (2) higher realized loss from payment/receipt of $0.2 million.

[0001408710-24-000019:mdna:113]
[same as prior period, unchanged from 0001408710-24-000009:mdna:110]

[0001408710-24-000019:mdna:114]
We recorded income before income taxes of $83.3 million for the three months ended March 29, 2024, compared with $63.5 million for the three months ended March 31, 2023.

[0001408710-24-000019:mdna:115]
We recorded income before income taxes of $226.4 million for the nine months ended March 29, 2024, compared with $193.0 million for the nine months ended March 31, 2023.

[0001408710-24-000019:mdna:116]
[same as prior period, unchanged from 0001408710-24-000009:mdna:113]

[0001408710-24-000019:mdna:117]
Our provision for income tax reflects effective tax rates of 2.9% and 6.5% for the three months ended March 29, 2024 and March 31, 2023, respectively. The decrease was due to a decrease in income subject to tax during the three months ended March 29, 2024 as compared to the three months ended March 31, 2023.

[0001408710-24-000019:mdna:118]
Our provision for income tax reflects effective tax rates of 5.0% and 3.1% for the nine months ended March 29, 2024 and March 31, 2023, respectively. The increase was primarily due to a full valuation allowance of $2.1 million for deferred tax assets being set up during the nine months ended March 29, 2024 due to management's belief that our subsidiary in Israel would continue to have losses in the foreseeable future such that the deferred tax assets of such subsidiary would not be utilized. In addition, a full valuation allowance of $1.6 million from our subsidiary in the U.K. was released during the nine months ended March 31, 2023.

[0001408710-24-000019:mdna:119]
[same as prior period, unchanged from 0001408710-24-000009:mdna:116]

[0001408710-24-000019:mdna:120]
We recorded net income of $80.9 million, or 11.1% of revenues, for the three months ended March 29, 2024, compared with $59.4 million, or 8.9% of revenues, for the three months ended March 31, 2023.

[0001408710-24-000019:mdna:121]
We recorded net income of $215.1 million, or 10.1% of revenues, for the nine months ended March 29, 2024, compared with $187.1 million, or 9.4% of revenues, for the nine months ended March 31, 2023.

[0001408710-24-000019:mdna:122]
[same as prior period, unchanged from 0001408710-24-000009:mdna:119]

[0001408710-24-000019:mdna:123]
We recorded other comprehensive loss of $8.9 million, or 1.2% of revenues, for the three months ended March 29, 2024, compared with other comprehensive loss of $3.6 million, or 0.5% of revenues, for the three months ended March 31, 2023. The change was mainly due to (1) unrealized loss from mark-to-market of available-for-sale debt securities of $3.8 million, and (2) higher unrealized loss from mark-to-market of forward contracts and interest rate swap agreements of $1.8 million, offset by unrealized gain from foreign currency translation adjustment of $0.3 million.

[0001408710-24-000019:mdna:124]
We recorded other comprehensive income of $3.5 million, or 0.2% of revenues, for the nine months ended March 29, 2024, compared with other comprehensive income of $6.5 million, or 0.3% of revenues, for the nine months ended March 31, 2023. The change was mainly due to lower unrealized gain from mark-to-market of forward contracts and interest rate swap

[0001408710-24-000019:mdna:125]
agreements of $3.4 million, offset by higher unrealized gain from mark-to-market of available-for-sale debt securities of $0.4 million.

[0001408710-24-000019:mdna:126]
[same as prior period, unchanged from 0001408710-24-000009:mdna:122]

[0001408710-24-000019:mdna:127]
[same as prior period, unchanged from 0001408710-24-000009:mdna:123]

[0001408710-24-000019:mdna:128]
We primarily finance our operations through cash flow from operations. As of March 29, 2024 and March 31, 2023, we had cash, cash equivalents, and short-term investments of $794.0 million and $538.7 million, respectively, and outstanding debt of $3.0 million and $15.2 million, respectively.

[0001408710-24-000019:mdna:129]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents was 4.5% and 4.3% for the three and nine months ended March 29, 2024, respectively, and 2.7% and 2.1% for the three and nine months ended March 31, 2023, respectively.

[0001408710-24-000019:mdna:130]
Our cash investments are made in accordance with an investment policy approved by the audit committee of our board of directors. In general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed income securities are primarily classified as available-for-sale and are recorded at fair value. The cost of securities sold is based on the specific identification method. Unrealized gains and losses on these securities are recorded as other comprehensive income (loss) and are reported as a separate component of shareholders’ equity.

[0001408710-24-000019:mdna:131]
During the nine months ended March 29, 2024, we repaid $9.1 million of the term loan under our 2019 Credit Facility Agreement. As a result, as of March 29, 2024, we had a long-term borrowing of $3.0 million under our 2019 Credit Facility Agreement (see Note 10 of Notes to Unaudited Condensed Consolidated Financial Statements for further details). We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held short-term investments of $408.9 million as of March 29, 2024.

[0001408710-24-000019:mdna:132]
We believe that our current cash and cash equivalents, short-term investments, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001408710-24-000019:mdna:133]
[same as prior period, unchanged from 0001408710-24-000009:mdna:130]

[0001408710-24-000019:mdna:134]
[same as prior period, unchanged from 0001408710-24-000009:mdna:131]

[0001408710-24-000019:mdna:135]
|  | Nine Months Ended |
| (in thousands) | March 29, 2024 |  | March 31, 2023 |
| Net cash provided by operating activities | $ | 330,084 |  |  | $ | 142,222 |  |
| Net cash used in investing activities | $ | (118,615) |  |  | $ | (70,449) |  |
| Net cash used in financing activities | $ | (57,800) |  |  | $ | (39,151) |  |
| Net increase in cash, cash equivalents and restricted cash | $ | 153,669 |  |  | $ | 32,622 |  |

[0001408710-24-000019:mdna:136]
[same as prior period, unchanged from 0001408710-24-000009:mdna:133]

[0001408710-24-000019:mdna:137]
Cash provided by operating activities is net income adjusted for certain non-cash items and changes in certain assets and liabilities. The increase in cash provided by operating activities during the nine months ended March 29, 2024 as compared to the nine months ended March 31, 2023 was primarily driven by efficient cash-favorable working capital changes mainly from inventory management.

[0001408710-24-000019:mdna:138]
[same as prior period, unchanged from 0001408710-24-000009:mdna:135]

[0001408710-24-000019:mdna:139]
Investing cash flows consist primarily of investment purchases, sales, maturities, and disposals; and capital expenditures. The increase in cash used in investing activities for the nine months ended March 29, 2024 as compared to cash used in investing activities for the nine months ended March 31, 2023 was primarily due to an increase in investment purchases.

[0001408710-24-000019:mdna:140]
[same as prior period, unchanged from 0001408710-24-000009:mdna:137]

[0001408710-24-000019:mdna:141]
Financing cash flows consist primarily of repayment of long-term debt, share repurchases, and withholding tax related to net share settlement of restricted share units. The increase in cash used in financing activities for the nine months ended March 29, 2024 as compared to the nine months ended March 31, 2023 was primarily due to a higher volume of share repurchases, offset by a decrease in withholding tax related to net share settlement of restricted share units, and lower

[0001408710-24-000019:mdna:142]
repayment of long-term borrowings due to one fewer installment from one fewer week in the first quarter of fiscal year 2024 compared to fiscal year 2023.

[0001408710-24-000019:mdna:143]
[same as prior period, unchanged from 0001408710-24-000009:mdna:139]

[0001408710-24-000019:mdna:144]
[same as prior period, unchanged from 0001408710-24-000009:mdna:140]

[0001408710-24-000019:mdna:145]
41
