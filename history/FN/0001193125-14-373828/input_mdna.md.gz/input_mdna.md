# FN MD&A — 0001193125-14-373828


## mdna

[0001193125-14-373828:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS. |

[0001193125-14-373828:mdna:2]
|  | • |  | our goals and strategies; |

[0001193125-14-373828:mdna:3]
|  | • |  | our and our customers’ estimates regarding future revenues, operating results, expenses, capital requirements and liquidity; |

[0001193125-14-373828:mdna:4]
|  | • |  | our expectation that the portion of our future revenues attributable to customers in regions outside of North America will be flat compared with the portion of those revenues for the year ended June 27, 2014; |

[0001193125-14-373828:mdna:5]
|  | • |  | our expectation that we will incur significant incremental costs of revenue as a result of our continued diversification into the industrial lasers and sensors markets and other end-markets outside of the optical communications market or our further development of customized optics and glass manufacturing capabilities; |

[0001193125-14-373828:mdna:6]
|  | • |  | our expectation that we will incur incremental costs of revenue as a result of our planned expansion into new geographic markets; |

[0001193125-14-373828:mdna:7]
|  | • |  | our expectation that our fiscal year 2015 Selling, General and Administrative (SG&A) expenses will increase on an absolute dollar basis and will remain flat as a percentage of revenue compared with fiscal year 2014; |

[0001193125-14-373828:mdna:8]
|  | • |  | our expectation that, aside from the usual incremental costs associated with growing our business, we will not incur material incremental SG&A expenses as a result of our continued diversification into the industrial lasers and sensors markets; other end-markets outside of the optical communications market or our further development of customized optics and glass manufacturing capabilities; |

[0001193125-14-373828:mdna:9]
|  | • |  | our expectation that our employee costs will increase in Thailand and the PRC; |

[0001193125-14-373828:mdna:10]
|  | • |  | our future capital expenditures and our needs for additional financing; |

[0001193125-14-373828:mdna:11]
|  | • |  | the expansion of our manufacturing capacity, including into new geographies; |

[0001193125-14-373828:mdna:12]
|  | • |  | the growth rates of our existing markets and potential new markets; |

[0001193125-14-373828:mdna:13]
|  | • |  | our ability, and the ability of our customers and suppliers, to respond successfully to technological or industry developments; |

[0001193125-14-373828:mdna:14]
|  | • |  | our suppliers’ estimates regarding future costs; |

[0001193125-14-373828:mdna:15]
|  | • |  | our ability to increase our penetration of existing markets and to penetrate new markets; |

[0001193125-14-373828:mdna:16]
|  | • |  | our plans to diversify our sources of revenues; |

[0001193125-14-373828:mdna:17]
|  | • |  | trends in the optical communications, industrial lasers, and sensors markets, including trends to outsource the production of components used in those markets; |

[0001193125-14-373828:mdna:18]
|  | • |  | our ability to attract and retain a qualified management team and other qualified personnel and advisors; and |

[0001193125-14-373828:mdna:19]
|  | • |  | competition in our existing and new markets. |

[0001193125-14-373828:mdna:20]
Overview

[0001193125-14-373828:mdna:21]
We provide advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to
original equipment manufacturers (OEMs) of complex products such as optical communication components, modules and sub-systems, industrial lasers and sensors. We offer a broad range of advanced optical and electro-mechanical capabilities across the
entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and test. Although we focus primarily on low-volume production of a wide variety of high
complexity products, which we refer to as “low-volume, high-mix”, we also have the capability to accommodate high-volume production. Based on our experience, and the positive feedback we have received from our customers, we believe we are
a global leader in providing these services to the optical communications, industrial lasers, automotive, and sensors markets.

[0001193125-14-373828:mdna:22]
Our customer base includes companies in complex industries that require advanced precision manufacturing capabilities such as optical
communications, industrial lasers, automotive, and sensors. The products that we manufacture for our OEM customers include selective switching products; tunable transponders and transceivers; active optical cables; solid state, diode-pumped, gas and
fiber lasers; and sensors. In many cases, we are the sole outsourced manufacturing partner used by our customers for the products that we produce for them.

[0001193125-14-373828:mdna:23]
We also design and fabricate application-specific crystals; prisms; mirrors; laser components; substrates, and other custom and standard borosilicate, clear fused quartz, and synthetic fused silica glass
products. We

[0001193125-14-373828:mdna:24]
36

[0001193125-14-373828:mdna:25]
incorporate our customized optics and glass into many of the products we manufacture for our OEM customers, and we also sell customized optics and glass in the merchant market.

[0001193125-14-373828:mdna:26]
Audit Committee Investigation

[0001193125-14-373828:mdna:27]
During the fourth quarter of our current fiscal year 2014, the Company identified violations of our policies and procedures relating to finished goods held in our warehouse on behalf of our customers (the
Company refers to finished goods held in our warehouse on behalf of our customers as consignment goods or consignment inventory and, when the finished goods are sold, the Company refers to the related revenue as consignment revenue). Specifically,
the Company identified violations related to certain employees in one business unit colluding to cause the improper recognition of revenues for certain goods by recording consignment revenues on goods before such goods were finished.

[0001193125-14-373828:mdna:28]
In connection with the above, the Audit Committee of our Board of Directors initiated an investigation concerning various accounting
cut-off issues in fiscal year 2014, specifically the shipment of unfinished goods to consignment inventory and other inventory cut-off considerations. The investigation found certain process weaknesses concerning the potential to invoice unfinished
goods held under consignment arrangements and the need for certain remedial measures.

[0001193125-14-373828:mdna:29]
The recommended remedial measures
identified through the investigation included the following remedial steps, which are currently being implemented:

[0001193125-14-373828:mdna:30]
|  | • |  | Certain personnel disciplinary actions with respect to the staff involved in the violations; |

[0001193125-14-373828:mdna:31]
|  | • |  | Mandatory training on revenue recognition policies and related cut-off procedures; and |

[0001193125-14-373828:mdna:32]
|  | • |  | Process improvements, including certain controls relating to finished goods recorded as consignment inventory. |

[0001193125-14-373828:mdna:33]
The investigation did not find executive officer involvement in the identified violations.

[0001193125-14-373828:mdna:34]
Impact of the Findings of the Investigation on the Financial Statements and Internal Controls

[0001193125-14-373828:mdna:35]
Based on an analysis prepared by the Company, it was determined that the potential exposure relating to the control deficiencies
identified during the investigation were not material to our financial statements. Further, the Company assessed these control deficiencies to be significant deficiencies rather than material weaknesses on the basis that there was no executive
officer involvement in the violations, the potential misstatements were not material to the financial statements and the Audit Committee was actively involved in the investigation.

[0001193125-14-373828:mdna:36]
Consignment Revenue Recognition

[0001193125-14-373828:mdna:37]
Subsequent to completion of the Audit
Committee’s investigation, the Company evaluated its accounting practices surrounding consignment inventory and consignment revenue. Based on that evaluation, the Company determined that for certain volume supply agreements with our customers,
not all of the revenue recognition criteria prescribed by U.S. GAAP and Staff Accounting Bulletin No. 104 had been met at the time revenue was recorded. Specifically, the Company misapplied the guidance when assessing the terms of these agreements
with respect to when title and risk of loss transfers to our customers. As a result, the Company determined that certain sales previously recognized did not qualify for revenue recognition in the periods in which they were recognized. The Company
has evaluated the impact of the errors on both a quantitative and qualitative basis under the guidance of ASC 250-Accounting Changes and Error Corrections and determined that the errors did not have a material impact to the previously issued
consolidated financial statements. Accordingly, previously issued financial statements for fiscal years 2013 and 2012 have not been revised or restated. Further, the

[0001193125-14-373828:mdna:38]
Company has assessed the control implications and concluded that the deficiency constituted a material weakness in internal control over financial reporting (refer to Item 9A for additional
information).

[0001193125-14-373828:mdna:39]
Had the Company made adjustments to record, in fiscal year 2014, revenues that were inappropriately recorded in
fiscal year 2013, fiscal year 2014 revenues would have increased by $11.09 million. Had adjustments been made to reflect revenues in the appropriate quarters in fiscal year 2014, revenues in fiscal year 2014 would have increased (decreased) as
follows:

[0001193125-14-373828:mdna:40]
| (amount in thousands) |  | Q1-201427-Sep-13 |  |  | Q2-201427-Dec-13 |  |  | Q3-201428-Mar-14 |  |  | Q4-201427-Jun-14 |  |  | FY 201427-Jun-14 |  |
| Revenues |  | $ | 2,706 |  |  | $ | (6,350 | ) |  | $ | 1,964 |  |  | $ | 12,777 |  |  | $ | 11,096 |  |

[0001193125-14-373828:mdna:41]
Thailand Flooding

[0001193125-14-373828:mdna:42]
We suspended production at all of our manufacturing facilities in Thailand from October 17, 2011 through November 14, 2011 owing to severe flooding. Thereafter, we permanently ceased production
at our Chokchai facility. Insurance claims were submitted to our insurers for losses incurred during the flood and all have been settled as of June 27, 2014. During fiscal year 2014, we recognized $45.2 million in flood-related income towards
full and final settlement of our owned and consigned equipment and inventory claims. This income was offset by the recognition of $0.5 million of expenses in connection with write-offs of advance payments to a customer that suffered flood losses.

[0001193125-14-373828:mdna:43]
In fiscal year 2013, we received from our insurers an interim payment of $16.2 million against our claim for owned inventory
losses and owned equipment losses, a payment of $13.1 million as full and final settlement of our claim for business interruption losses, and a payment of $0.1 million as full and final settlement of our claim for damage to our buildings at
Pinehurst. This income was offset by the recognition of $2.3 million of additional expenses in connection with liabilities to third parties due to flood losses.

[0001193125-14-373828:mdna:44]
During fiscal year 2014, we made a cash payment of $5.2 million and transferred equipment with an aggregate value of $2.3 million, to a customer towards full and final settlement for any and all
flood-related losses, in accordance with the settlement agreement entered into during fiscal year 2013 with such customer. In addition, we fulfilled our obligations to a customer’s insurers by making a payment of $2.2 million for full and final
settlement of our liability for damages to customer-owned inventory which occurred during the flooding in accordance with the settlement agreement entered into during fiscal year 2013 with such insurer. We also made a cash payment of $0.1 million
towards the other flood-related settlements during the year ended June 27, 2014.

[0001193125-14-373828:mdna:45]
During fiscal year 2013, we entered
into settlement agreements with each of our customers impacted by the flooding regarding our liability for customers’ losses as a result of the flooding. In connection with such settlement agreements, during fiscal year 2013, we paid an
aggregate of $37.7 million to customers, transferred equipment purchased on behalf of customers to those customers with an aggregate value of $5.9 million and reduced net accounts receivable from customers by an aggregate of $5.7 million. As of
June 28, 2013, our liability to two of our impacted customers for any and all flood-related losses had been satisfied in full.

[0001193125-14-373828:mdna:46]
During fiscal year 2013, we also entered into a settlement agreement with a customer’s insurers to resolve a subrogation claim related to recovery proceeds paid by such insurer to the customer for
damages to customer-owned inventory during the flooding. Under the terms of the settlement agreement, we agreed to pay $6.5 million to the insurer, to be paid in three installments. As of June 28, 2013,
we had paid an aggregate of $4.3 million. The final payment of approximately $2.2 million was made in July 2013.

[0001193125-14-373828:mdna:47]
Revenues

[0001193125-14-373828:mdna:48]
Our total revenues increased by $36.3 million, or 5.7%, to $677.9 million for fiscal year 2014, compared with $641.5
million for fiscal year 2013. This increase was primarily due to an increase in our customers’ demand for optical communications products during the year ended June 27, 2014.

[0001193125-14-373828:mdna:49]
We believe our ability to expand our relationships with existing customers and attract new
customers is due to a number of factors, including our broad range of complex engineering and manufacturing service offerings, flexible low-cost manufacturing platform, process optimization capabilities, advanced supply chain management, excellent
customer service and experienced management team. Although we expect the prices we charge for our manufactured products to decrease over time (partly as a result of competitive market forces), we still believe we will be able to maintain favorable
pricing for our services because of our ability to reduce cycle time, adjust our product mix by focusing on more complicated products, improve product quality and yields, and reduce material costs for the products we manufacture. We believe these
capabilities will enable us to help our OEM customers reduce their manufacturing costs while maintaining or improving the design, quality, reliability and delivery times of their products.

[0001193125-14-373828:mdna:50]
Revenues, by percentage, from individual customers representing 10% or more of our total revenues in the respective periods were as
follows:

[0001193125-14-373828:mdna:51]
|  |  | Years Ended |
|  |  | June 27, 2014 |  | June 28, 2013 |  | June 29, 2012 |
| JDS Uniphase Corporation |  | 24% |  | 22% |  | 25% |
| Oclaro, Inc. (1) |  | 22% |  | 25% |  | 12% |
| Finisar Corporation |  | * (2) |  | * (2) |  | 10% |

[0001193125-14-373828:mdna:52]
|  | (1) | Includes revenue of Opnext, Inc., which was acquired by Oclaro, Inc. in July 2012. |

[0001193125-14-373828:mdna:53]
|  | (2) | Less than 10% of total revenues in the period. |

[0001193125-14-373828:mdna:54]
During fiscal year 2014 and fiscal year 2013, we had two customers that each contributed 10% or more of our total revenues, and such customers together accounted for 46% and 47%, respectively, of our
total revenues during the respective periods. During fiscal year 2012, we had three customers that each contributed 10% or more of our total revenues.

[0001193125-14-373828:mdna:55]
Because we depend upon a small number of customers for a significant percentage of our total revenues, a reduction in orders from, a loss of, or any other adverse actions by, any one of these customers
would reduce our revenues and could have a material adverse effect on our business, operating results and share price. Moreover, our customer concentration increases the concentration of our accounts receivable and payment default by any of our key
customers will negatively impact our exposure. Many of our existing and potential customers have substantial debt burdens, have experienced financial distress or have static or declining revenues, all of which may have been exacerbated by the impact
of the flooding in Thailand, and the continued uncertainty in the global economies. Certain customers have gone out of business or have been acquired or announced their withdrawal from segments of the optics market. We generate significant accounts
payable and inventory for the services that we provide to our customers, which could expose us to substantial and potentially unrecoverable costs if we do not receive payment from our customers. Therefore, any financial difficulties that our key
customers experience could materially and adversely affect our operating results and financial condition by generating charges for inventory write-offs, provisions for doubtful accounts, and increases in working capital requirements due to increased
days inventory and in accounts receivable.

[0001193125-14-373828:mdna:56]
Furthermore, reliance on a small number of customers gives those customers
substantial purchasing power and leverage in negotiating contracts with us. In addition, although we enter into master supply agreements with our customers, the level of business to be transacted under those agreements is not guaranteed. Instead, we
are awarded business under those agreements on a project-by-project basis. Some of our customers have at times significantly reduced or delayed the volume of manufacturing services that they order from us. If we are unable to maintain our
relationships with our existing significant customers, our business, financial condition and operating results could be harmed.

[0001193125-14-373828:mdna:57]
39

[0001193125-14-373828:mdna:58]
Revenues by Geography

[0001193125-14-373828:mdna:59]
We generate revenues from three geographic regions: North America, Asia-Pacific and Europe. Revenues are attributed to a particular
geographic area based on the bill-to location of our customers, notwithstanding that our customers may ultimately ship their products to end customers in a different geographic region. Virtually all of our revenues are derived from our manufacturing
facilities in Asia-Pacific.

[0001193125-14-373828:mdna:60]
The percentage of our revenues generated from bill-to location outside of North America decreased
from 53.3% in fiscal year 2013 to 51.8% in fiscal year 2014, primarily because of a decrease in sales volumes of our customers in those regions. We expect that the portion of our future revenues attributable to customer in regions outside of North
America will remain flat as compared with the fiscal year 2014.

[0001193125-14-373828:mdna:61]
The following table presents percentages of total revenues by
geographic regions:

[0001193125-14-373828:mdna:62]
|  |  | Years Ended |  |
|  |  | June 27, 2014 |  |  | June 28, 2013 |  |  | June 29, 2012 |  |
| North America |  |  | 48.2 | % |  |  | 46.7 | % |  |  | 48.3 | % |
| Asia-Pacific |  |  | 34.0 |  |  |  | 34.0 |  |  |  | 33.5 |  |
| Europe |  |  | 17.8 |  |  |  | 19.3 |  |  |  | 18.2 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-14-373828:mdna:63]
Our Contracts

[0001193125-14-373828:mdna:64]
We enter into supply agreements with our customers which generally have an initial term of up to three years, subject to automatic renewals for subsequent one-year terms unless expressly terminated.
Although there are no minimum purchase requirements in our supply agreements, our customers do provide us with rolling forecasts of their demand requirements. Our supply agreements generally include provisions for pricing and periodic review of
pricing, consignment of our customer’s unique production equipment to us, and the sharing of benefits from cost-savings derived from our efforts. We are generally required to purchase materials, which may include long lead-time materials and
materials that are subject to minimum order quantities and/or non-cancelable or non-returnable terms, to meet the stated demands of our customers. After procuring materials, we manufacture products for our customers based on purchase orders that
contain terms regarding product quantities, delivery locations and delivery dates. Our customers are generally obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by
our customers within a specified period of time, or are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under our contracts. Once materials are designated as either
excess or obsolete inventory, our customers are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products.

[0001193125-14-373828:mdna:65]
Cost of Revenues

[0001193125-14-373828:mdna:66]
The key components of our cost of revenues are material
costs, employee costs, and infrastructure-related costs. Material costs generally represent the majority of our cost of revenues. Several of the materials we require to manufacture products for our customers are customized for their products and
often sourced from a single supplier or in some cases, our own subsidiaries. Shortages from sole-source suppliers due to yield loss, quality concerns, and capacity constraints, among other factors, may increase our expenses and negatively impact our
gross profit margin or total revenues in a given quarter. Material costs include scrap material. Historically, scrap rate diminishes during a product’s life cycle due to process, fixturing and test improvement and optimization.

[0001193125-14-373828:mdna:67]
A second significant element of cost of revenues is employee costs, including indirect
employee costs related to design; configuration and optimization of manufacturing processes for our customers, quality testing; materials testing and other engineering services; and direct costs related to our manufacturing employees. Direct
employee costs include employee salaries, insurance and benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support
our growth and, to a lesser extent, costs to recruit, train and retain employees. Our cost of revenues are significantly impacted by salary levels in Thailand and the PRC; the fluctuation of the Thai baht and RMB against our functional currency, the
U.S. dollar; and our ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. For example, effective April 1, 2012, the Thai government increased minimum daily wages from
215 Thai baht to 300 Thai baht. Wage increases may impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention,
and asset utilization.

[0001193125-14-373828:mdna:68]
Our infrastructure costs are comprised of depreciation, utilities, facilities management, and overhead
costs. Most of our facility leases are long-term agreements. Our depreciation costs include buildings and fixed assets, primarily at our Pinehurst Campus in Thailand, and capital equipment located at each of our manufacturing locations.

[0001193125-14-373828:mdna:69]
During fiscal year 2014 and fiscal year 2013, discretionary merit-based bonus awards were provided to our non-executive employees.
Charges included in cost of revenues for bonus distributions to such employees were $1.9 million, $2.0 million and $1.3 million for fiscal year 2014, fiscal year 2013, and fiscal year 2012, respectively.

[0001193125-14-373828:mdna:70]
Share-based compensation expense included in cost of revenues was $1.2 million, $1.1 million and $1.5 million for fiscal year 2014,
fiscal year 2013, and fiscal year 2012, respectively.

[0001193125-14-373828:mdna:71]
We expect to incur significant incremental costs of revenue as a result
of our continued diversification into the industrial lasers, automotive, and sensors markets, and other end-markets outside of the optical communications market or our further development of customized optics and glass manufacturing capabilities. We
also expect to incur incremental costs of revenue as a result of our planned expansion into new geographic markets, though we are not able to determine the amount of these incremental expenses.

[0001193125-14-373828:mdna:72]
Selling, General and Administrative Expenses

[0001193125-14-373828:mdna:73]
Our selling, general and administrative expenses (SG&A) primarily consist of corporate employee costs for sales and marketing, general and administrative, and other support personnel, including
research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense, and other general expenses not related to cost of revenues. In fiscal year
2015, we expect our SG&A expenses will increase on an absolute dollar basis and remain flat as a percentage of revenue compared with fiscal year 2014.

[0001193125-14-373828:mdna:74]
The compensation committee of our board of directors approved a fiscal year 2014 executive incentive plan with quantitative objectives based on achieving certain revenue and gross margin percentage
targets for our fiscal year ended June 27, 2014, as well as qualitative objectives, based on achieving individual performance goals. Bonuses under our fiscal year 2014 executive incentive plan are payable after the end of fiscal year 2014. In
fiscal year 2013, the compensation committee approved a fiscal year 2013 executive incentive plan with quantitative objectives, based on achieving certain revenue and earnings per share targets for our fiscal year ended June 28, 2013. No
bonuses were earned under the fiscal year 2013 executive incentive plan, however, the compensation committee awarded discretionary bonuses to our executive employees in the three months ended September 27, 2013. Discretionary merit-based bonus
awards were also available to our non-executive employees during fiscal year 2014 and fiscal year 2013.

[0001193125-14-373828:mdna:75]
Charges included in SG&A expenses for bonus distributions to non-executive and executive
employees were $3.1 million, $1.7 million and $0.4 million for fiscal year 2014, fiscal year 2013 and fiscal year 2012, respectively.

[0001193125-14-373828:mdna:76]
Share-based compensation expense included in SG&A expenses was $4.4 million, $4.0 million and $3.1 million for fiscal year 2014, fiscal year 2013, and fiscal year 2012, respectively.

[0001193125-14-373828:mdna:77]
Other than incremental costs associated with growing our business generally, we do not expect to incur material incremental SG&A
expenses as a result of our planned expansion into new geographic markets, our continued diversification into the industrial lasers and sensors markets and other end-markets outside of the optical communications market or our further development of
customized optics and glass manufacturing capabilities.

[0001193125-14-373828:mdna:78]
Additional Financial Disclosures

[0001193125-14-373828:mdna:79]
Foreign Exchange

[0001193125-14-373828:mdna:80]
As a result of our international operations, we are exposed to foreign exchange risk arising from various currency exposures primarily with respect to the Thai baht. Although a majority of our total
revenues is denominated in U.S. dollars, a substantial portion of our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rates between the Thai baht and the U.S. dollar have fluctuated substantially in
recent years and may continue to fluctuate substantially in the future. We report our financial results in U.S. dollars and our results of operations have been and may continue to be negatively impacted owing to appreciation of the Thai baht against
the U.S. dollar. Smaller portions of our expenses are incurred in a variety of other currencies, including RMB, Canadian dollars, Euros, and Japanese yen, the appreciation of which may also negatively impact our financial results.

[0001193125-14-373828:mdna:81]
In addition, we are exposed to foreign exchange risk in connection with the credit facility and cross currency swap arrangements we
entered into with TMB Bank Public Company Limited (the “Bank”) in May 2011 for the construction of Pinehurst Building 6. The terms of the contract with the Bank provide the following facilities: (1) a term loan facility for up to Thai
baht 960 million (equal to $30.0 million) with a fixed interest rate of 5.28% per annum, (2) a hedging facility for currency interest rate swaps with a notional amount of $30.0 million, and (3) a settlement limit of Thai baht
65 million, subject to certain terms and conditions as set forth therein. As of March 30, 2012, we had drawn down the entire $30.0 million available under the term loan facility. Borrowings and interest under the term loan have been
scheduled to be repaid on a quarterly basis between September 2011 and March 2017. As of June 27, 2014 and June 28, 2013, we had outstanding borrowings under the term loan facility of $16.5 million and $22.5 million, respectively. Under
the terms of the cross currency swap arrangement amounts drawn in Thai baht were converted to U.S. dollars for repayment by us on a quarterly basis at the floating rate of 3-month London Interbank Offered Rate (LIBOR) plus 2.8% per annum.

[0001193125-14-373828:mdna:82]
In order to manage the risks arising from fluctuations in foreign currency exchange rates, we use derivative financial
instruments. We may enter into short-term forward foreign currency contracts or put option contracts to help manage currency exposures associated with certain assets and liabilities, primarily short-term obligations. The forward exchange contracts
and put option contracts generally had original maturities of one to six months, and no forward exchange contract or put option contract has had an original maturity greater than one year. All foreign currency exchange contracts are recognized on
the consolidated balance sheets at fair value. As we do not apply hedge accounting to these instruments, the change in the fair value of the derivatives are recorded in foreign exchange (loss) gain, net on the consolidated statements of operations.
The gains and losses on our forward contracts and put option contracts generally offset losses and gains on the assets, liabilities, and transactions economically hedged and, accordingly, generally do not subject us to the risk of significant
accounting losses.

[0001193125-14-373828:mdna:83]
We had foreign currency assets and liabilities in Thai baht and RMB as follows:

[0001193125-14-373828:mdna:84]
|  |  | As of June 27, 2014 |  |  | As of June 28, 2013 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,536,887 |  |  | $ | 47,318 |  |  |  | 79.6 |  |  |  | 567,561 |  |  | $ | 18,232 |  |  |  | 51.6 |  |
| RMB |  |  | 74,813 |  |  |  | 12,156 |  |  |  | 20.4 |  |  |  | 105,680 |  |  |  | 17,104 |  |  |  | 48.4 |  |
| Total |  |  |  |  |  | $ | 59,474 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 35,336 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 735,490 |  |  | $ | 22,644 |  |  |  | 81.1 |  |  |  | 585,364 |  |  | $ | 18,804 |  |  |  | 88.4 |  |
| RMB |  |  | 32,512 |  |  |  | 5,283 |  |  |  | 18.9 |  |  |  | 15,308 |  |  |  | 2,478 |  |  |  | 11.6 |  |
| Total |  |  |  |  |  | $ | 27,927 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 21,282 |  |  |  | 100.0 |  |

[0001193125-14-373828:mdna:85]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other
current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and
liabilities denominated in the same currency in accordance with management’s policy. As of June 27, 2014, there were $15.0 million in put option contracts outstanding on the Thai baht payables. As of June 28, 2013, there were $23.0
million in selling forward contracts and $5.0 million in put option contracts outstanding on the Thai baht payables.

[0001193125-14-373828:mdna:86]
The RMB
assets represent cash and cash equivalents, accounts receivable, and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses and other payables. As of June 27, 2014 and June 28, 2013, we did not have
any RMB to U.S. dollar forward contracts.

[0001193125-14-373828:mdna:87]
As of June 27, 2014 and June 28, 2013, unrealized gain from fair market
value of derivatives amounted to $0.1 million and unrealized loss from fair market value of derivatives amounted $0.8 million, respectively.

[0001193125-14-373828:mdna:88]
Currency Regulation and Dividend Distribution

[0001193125-14-373828:mdna:89]
Foreign exchange
regulation in the PRC is primarily governed by the following rules:

[0001193125-14-373828:mdna:90]
|  | • |  | Foreign Currency Administration Rules, as amended on August 5, 2008, or the Exchange Rules; |

[0001193125-14-373828:mdna:91]
|  | • |  | Administration Rules of the Settlement, Sale and Payment of Foreign Exchange (1996), or the Administration Rules; and |

[0001193125-14-373828:mdna:92]
|  | • |  | Notice on Perfecting Practices Concerning Foreign Exchange Settlement Regarding the Capital Contribution by Foreign-invested Enterprises, as promulgated by the State Administration of Foreign Exchange, or State Administration of Foreign Exchange (SAFE), on August 29, 2008, or Circular 142. |

[0001193125-14-373828:mdna:93]
Under the Exchange Rules, RMB is freely convertible into foreign currencies for current account items, including the distribution of dividends, interest payments, and trade and service-related foreign
exchange transactions. However, conversion of RMB for capital account items, such as direct investments, loans, security investments and repatriation of investments, is still subject to the approval of SAFE.

[0001193125-14-373828:mdna:94]
Under the Administration Rules, foreign-invested enterprises may only buy, sell, or remit foreign currencies at banks authorized to
conduct foreign exchange business after providing valid commercial documents and relevant supporting documents and, in the case of capital account item transactions, obtaining approval from SAFE. Capital investments by foreign-invested enterprises
outside of the PRC are also subject to limitations, which include approvals by the Ministry of Commerce, SAFE, and the State Development and Reform Commission.

[0001193125-14-373828:mdna:95]
Circular 142 regulates the conversion by a foreign-invested company of foreign currency into
RMB by restricting how the converted RMB may be used. Circular 142 requires that the registered capital of a foreign-invested enterprise settled in RMB converted from foreign currencies may only be used for purposes within the business scope
approved by the applicable governmental authority and may not be used for equity investments within the PRC. In addition, SAFE strengthened its oversight of the flow and use of the registered capital of foreign-invested enterprises settled in RMB
converted from foreign currencies. The use of such RMB capital may not be changed without SAFE’s approval and may not be used to repay RMB loans if the proceeds of such loans have not been used.

[0001193125-14-373828:mdna:96]
On January 5, 2007, SAFE promulgated the Detailed Rules for Implementing the Measures for the Administration on Individual Foreign
Exchange, or the Implementation Rules. Under the Implementation Rules, PRC citizens who are granted share options by an overseas publicly-listed company are required, through a PRC agent or PRC subsidiary of such overseas publicly-listed company, to
register with SAFE and complete certain other procedures.

[0001193125-14-373828:mdna:97]
In addition, the General Administration of Taxation has issued
circulars concerning employee share options. Under these circulars, our employees working in the PRC who exercise share options will be subject to PRC individual income tax. Our PRC subsidiary is obligated to file documents related to employee share
options with relevant tax authorities and withhold individual income taxes of those employees who exercise their share options.

[0001193125-14-373828:mdna:98]
Furthermore, our transfer of funds to our subsidiaries in Thailand and the PRC are each subject to approval by governmental authorities
in the case of an increase in registered capital, or subject to registration with governmental authorities in case of a shareholder loan. These limitations on the flow of funds between our subsidiaries and us could restrict our ability to act in
response to changing market conditions.

[0001193125-14-373828:mdna:99]
Income Tax

[0001193125-14-373828:mdna:100]
Our effective tax rate is a function of the mix of tax rates in the various jurisdictions in which we do business. We are domiciled in the
Cayman Islands. Under the current laws of the Cayman Islands, we are not subject to tax in the Cayman Islands on income or capital gains. We have received this undertaking for a 20-year period ending August 24, 2019, and after the expiration
date we may request a renewal with the office of the Clerk of the Cabinet for another twenty years.

[0001193125-14-373828:mdna:101]
Throughout the period of
our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption is currently available to us
from July 2010 through June 2015 on income generated from the manufacture of products at Pinehurst Building 5 and from July 2012 through June 2020 on income generated from the manufacture of products at Pinehurst Building 6. Such preferential tax
treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years. Additionally,
in December 2011, the Thailand Revenue Department announced a reduction in corporate income tax rates for tax periods beginning on or after January 1, 2012. As a result of the announcement, corporate income tax rates for our Thai
subsidiary will be reduced from 30% in fiscal year 2012 to 23% in fiscal year 2013, and to 20% in fiscal year 2014 and fiscal year 2015.

[0001193125-14-373828:mdna:102]
Our subsidiary in China has been granted a tax privilege to reduce its corporate income tax rate from 25% to 15%. This privilege was retroactive to January 1, 2011 and expired December 31, 2013.
Currently, we are preparing an application to renew this tax privilege and plan to submit it in fiscal year 2015; however, there can be no assurances that such tax privilege will be renewed.

[0001193125-14-373828:mdna:103]
Critical Accounting Policies and Use of Estimates

[0001193125-14-373828:mdna:104]
We prepare our consolidated financial statements in conformity with U.S. GAAP which requires us to make estimates and assumptions that
affect the reported amounts of assets and liabilities, the disclosure of contingent liabilities on the date of the consolidated financial statements and the reported amounts of revenues and expenses during the financial reporting period. We
continually evaluate these estimates and assumptions based on the most recently available information, our own historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results form the
basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Because the use of estimates is an integral component of the financial reporting process, actual results could differ
from those estimates. Some of our accounting policies require higher degrees of judgment than others in their application. We consider the policies discussed below to be critical to an understanding of our consolidated financial statements, as their
application places the most significant demands on our management’s judgment.

[0001193125-14-373828:mdna:105]
A quantitative sensitivity analysis is
provided where such information is reasonably available, can be reliably estimated, and provides material information to investors. The amounts used to assess sensitivity are included for illustrative purposes only and do not represent
management’s predictions of variability.

[0001193125-14-373828:mdna:106]
Expenses related to flooding

[0001193125-14-373828:mdna:107]
For the fiscal year 2013 and 2012, expenses related to flooding represented our estimate of losses due to the effects of flooding that
suspended production at all of our manufacturing facilities in Thailand. Expense consisted mainly of losses to our own buildings, equipment and inventory; losses to consigned equipment and inventory; and other flood related expenses.

[0001193125-14-373828:mdna:108]
We estimated flood-related losses to consigned equipment and inventory based on discussions with our customers regarding their
assessments of the damage to, and valuation of, the consigned assets that were under our care, custody and control at our Chokchai facility. For assets owned by us, flood-related losses were estimated based on the net book value of the assets
written-off as a result of the flood. During fiscal year 2014, we recognized $45.2 million as income related to flooding towards full and final settlement of our owned and consigned equipment and inventory claims. This income was offset by the
recognition of $0.5 million of other expenses in connection with write-offs of advance payments to a customer due to flood losses.

[0001193125-14-373828:mdna:109]
Long-Lived Assets

[0001193125-14-373828:mdna:110]
We review property, plant and equipment for
impairment when events or changes in circumstances indicate the carrying amount of an asset may not be recoverable. An impairment loss is recognized when the carrying amount of a long-lived asset exceeds its fair value. Recoverability of property
and equipment is measured by comparing its carrying amount to the projected undiscounted cash flows the property and equipment are expected to generate. If such assets are considered to be impaired, the impairment loss recognized, if any, is the
amount by which the carrying amount of the property and equipment exceeds its fair value. During fiscal year 2012, we set up a provision for impairment of approximately $2.5 million for certain property, plant and equipment that was damaged due to
severe flooding in Thailand during October and November 2011. We submitted claims for such losses to our insurance companies, all of which have been settled as of the end of fiscal year 2014. As a result, we wrote-off all assets damaged from the
flooding and reversed all asset impairment reserve.

[0001193125-14-373828:mdna:111]
Allowance for Doubtful Accounts

[0001193125-14-373828:mdna:112]
We perform ongoing credit evaluations of our customers’ financial condition and make provisions for doubtful accounts based on the
outcomes of these credit evaluations. We evaluate the collectability of our accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections, and the age of past due receivables.
Unanticipated changes in the liquidity or financial position of our customers may require additional provisions for doubtful accounts. Under our specific identification method it is not practical to assess the sensitivity of our estimates.

[0001193125-14-373828:mdna:113]
Inventory Valuation

[0001193125-14-373828:mdna:114]
Our inventory is stated at the lower of cost (on a first-in, first-out basis) or market value. Our industry is characterized by rapid
technological change, short-term customer commitments, and rapid changes in demand. We make provisions for estimated excess and obsolete inventory based on regular reviews of inventory quantities on hand and the latest forecasts of product demand
and production requirements from our customers. If actual market conditions or our customers’ product demands are less favorable than those projected, additional provisions may be required. In addition, unanticipated changes in liquidity or the
financial positions of our customers or changes in economic conditions may require additional provisions for inventory due to our customers’ inability to fulfill their contractual obligations. During fiscal year 2014 and fiscal year 2013, a
change of 10% for excess and obsolete materials, based on product demand and production requirements from our customers, would have affected by decrease our net income of approximately $0.3 million and $0.2 million, respectively.

[0001193125-14-373828:mdna:115]
Deferred Income Taxes

[0001193125-14-373828:mdna:116]
Our deferred income tax assets represent temporary differences between the carrying amount and the tax basis of existing assets and liabilities that will result in deductible and payable amounts in future
years, including net operating loss carryforwards. Based on estimates, the carrying value of our net deferred tax assets assumes that it is more likely than not that we will be able to generate sufficient future taxable income in certain tax
jurisdictions to realize these deferred income tax assets. Our judgments regarding future profitability may change owing to future market conditions, changes in U.S. or international tax laws, or other factors. If these estimates and related
assumptions change in the future, we may be required to increase or decrease our valuation allowance against the deferred tax assets, resulting in additional or lesser income tax expense. As of June 27, 2014 and June 28, 2013, we assessed
all of our deferred tax assets as more likely than not to be realizable and, accordingly, did not have a valuation allowance against our deferred tax assets.

[0001193125-14-373828:mdna:117]
We assess tax positions in a previously filed tax return or a position expected to be taken in a future tax return that is reflected in measuring current or deferred income tax assets and liabilities for
interim or annual periods, based on the technical merits of the position. We apply a “more likely than not” basis (i.e., a likelihood greater than 50 percent), in accordance with the authoritative guidance, and recognize a tax provision in
the consolidated financial statements for an uncertain tax position that would not be sustained.

[0001193125-14-373828:mdna:118]
Share-Based
Compensation

[0001193125-14-373828:mdna:119]
Awards granted are accounted for by recognizing the cost of employee services received in exchange for
awards of equity instruments, based on the fair value of those awards, in the consolidated financial statements. In determining the fair value of awards, we are required to make estimates of the fair value of our ordinary shares, expected dividends
to be issued, expected volatility of our shares, expected forfeitures of the awards, risk free interest rates for the expected terms of the awards, expected terms of the awards, and the vesting period of the respective awards.

[0001193125-14-373828:mdna:120]
The determination of our share-based compensation expense for both current and future periods requires the input of assumptions,
including estimated forfeitures and the price volatility of the underlying ordinary shares. We estimate forfeitures based on past employee retention rates and our expectations of future retention rates, and we will prospectively revise our
forfeiture rates based on actual history. Our share-based compensation expense may change based on changes to our actual forfeitures.

[0001193125-14-373828:mdna:121]
For accounting purposes only, the fair value of each option grant is estimated using the Black-Scholes-Merton option pricing model, which takes into account the following factors: (i) the exercise
price of the options; (ii) the estimated fair value of the underlying ordinary shares; (iii) the expected life of the options; (iv) the expected volatility of the underlying ordinary shares; (v) the risk-free interest rate during
the expected life of the options, and (vi) the expected dividend yield of the underlying ordinary shares. However, these fair values are inherently uncertain and highly subjective.

[0001193125-14-373828:mdna:122]
The exercise price of the options is stated in the option agreements. The expected life of
the options involves estimates of the anticipated timing of the exercise of the vested options. The expected volatility is based on the historical volatility of the capital stock of comparable publicly-traded companies. We have applied the U.S.
Treasury Bill interest rate with a maturity date similar to the expected life of our options as the risk-free interest rate and assumed a dividend yield for periods when we paid dividends.

[0001193125-14-373828:mdna:123]
Results of Operations

[0001193125-14-373828:mdna:124]
The following table sets forth a summary of our
consolidated statements of operations and comprehensive income. Note that period-to-period comparisons of operating results should not be relied upon as indicative of future performance.

[0001193125-14-373828:mdna:125]
|  |  | Years Ended |  |
|  |  | June 27, 2014 |  |  | June 28, 2013 |  |  | June 29, 2012 |  |
| Revenues |  | $ | 677,854 |  |  | $ | 641,542 |  |  | $ | 564,732 |  |
| Cost of revenues |  |  | (603,621 | ) |  |  | (572,124 | ) |  |  | (502,818 | ) |
| Gross profit |  |  | 74,233 |  |  |  | 69,418 |  |  |  | 61,914 |  |
| Selling, general and administrative expenses |  |  | (27,664 | ) |  |  | (23,787 | ) |  |  | (23,466 | ) |
| Income (expense) related to flooding |  |  | 44,748 |  |  |  | 27,211 |  |  |  | (97,286 | ) |
| Expenses related to reduction in workforce |  |  | — |  |  |  | (2,052 | ) |  |  | (1,978 | ) |
| Operating income (loss) |  |  | 91,317 |  |  |  | 70,790 |  |  |  | (60,816 | ) |
| Interest income |  |  | 1,793 |  |  |  | 1,083 |  |  |  | 844 |  |
| Interest expense |  |  | (713 | ) |  |  | (1,010 | ) |  |  | (427 | ) |
| Foreign exchange (loss) gain, net |  |  | (24 | ) |  |  | 354 |  |  |  | 1,569 |  |
| Other income |  |  | 797 |  |  |  | 692 |  |  |  | 395 |  |
| Income (loss) before income taxes |  |  | 93,170 |  |  |  | 71,909 |  |  |  | (58,435 | ) |
| Income tax (expense) benefit |  |  | (1,439 | ) |  |  | (2,940 | ) |  |  | 1,968 |  |
| Net income (loss) |  |  | 91,731 |  |  |  | 68,969 |  |  |  | (56,467 | ) |
| Other comprehensive income |  |  | — |  |  |  | — |  |  |  | — |  |
| Net comprehensive income (loss) |  | $ | 91,731 |  |  | $ | 68,969 |  |  | $ | (56,467 | ) |

[0001193125-14-373828:mdna:126]
47

[0001193125-14-373828:mdna:127]
The following table sets forth a summary of our consolidated statements of operations and
comprehensive income as a percentage of total revenues for the periods indicated.

[0001193125-14-373828:mdna:128]
|  |  | Years Ended |  |
|  |  | June 27, 2014 |  |  | June 28, 2013 |  |  | June 29, 2012 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (89.1 | ) |  |  | (89.2 | ) |  |  | (89.0 | ) |
| Gross profit |  |  | 10.9 |  |  |  | 10.8 |  |  |  | 11.0 |  |
| Selling, general and administrative expenses |  |  | (4.1 | ) |  |  | (3.7 | ) |  |  | (4.2 | ) |
| Income (expense) related to flooding |  |  | 6.6 |  |  |  | 4.2 |  |  |  | (17.2 | ) |
| Expenses related to reduction in workforce |  |  | — |  |  |  | (0.3 | ) |  |  | (0.4 | ) |
| Operating income (loss) |  |  | 13.4 |  |  |  | 11.0 |  |  |  | (10.8 | ) |
| Interest income |  |  | 0.3 |  |  |  | 0.2 |  |  |  | 0.1 |  |
| Interest expense |  |  | (0.1 | ) |  |  | (0.2 | ) |  |  | (0.1 | ) |
| Foreign exchange (loss) gain, net |  |  | (0.0 | ) |  |  | 0.1 |  |  |  | 0.3 |  |
| Other income |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Income (loss) before income taxes |  |  | 13.7 |  |  |  | 11.2 |  |  |  | (10.3 | ) |
| Income tax (expense) benefit |  |  | (0.2 | ) |  |  | (0.5 | ) |  |  | 0.3 |  |
| Net income (loss) |  |  | 13.5 |  |  |  | 10.7 |  |  |  | (10.0 | ) |
| Other comprehensive income |  |  | — |  |  |  | — |  |  |  | — |  |
| Net comprehensive income (loss) |  |  | 13.5 | % |  |  | 10.7 | % |  |  | (10.0 | )% |

[0001193125-14-373828:mdna:129]
The following table sets forth our revenues by end market for the periods indicated. As necessary,
comparative figures have been adjusted to conform with changes in presentation in the current year.

[0001193125-14-373828:mdna:130]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 27, 2014 |  |  | June 28, 2013 |  |  | June 29, 2012 |  |
| Optical communications |  | $ | 484,071 |  |  | $ | 449,790 |  |  | $ | 382,673 |  |
| Lasers, sensors, and other |  |  | 193,783 |  |  |  | 191,752 |  |  |  | 182,059 |  |
| Total |  | $ | 677,854 |  |  | $ | 641,542 |  |  | $ | 564,732 |  |

[0001193125-14-373828:mdna:131]
We operate and internally manage a single operating segment. As such, discrete information with respect
to separate product lines and segments is not accumulated.

[0001193125-14-373828:mdna:132]
Comparison of Fiscal Year 2014 with Fiscal Year 2013

[0001193125-14-373828:mdna:133]
Total revenues. Our total revenues increased by $36.3 million, or 5.7%, to $677.9 million for fiscal year 2014,
as compared with $641.5 million for fiscal year 2013. This increase was primarily due to an increase in optical communication products sales volume. Revenues from optical communications products represented 71.4% of our total revenues for fiscal
year 2014, compared with 70.1% for fiscal year 2013.

[0001193125-14-373828:mdna:134]
Cost of revenues. Our cost of revenues increased by $31.5
million, or 5.5%, to $603.6 million, or 89.1% of total revenues, for fiscal year 2014, compared with $572.1 million, or 89.2% of total revenues, for fiscal year 2013. The increase in cost of revenues on an absolute dollar basis was primarily due to
an increase in sales volume and cost of revenues increased in proportionally. Cost of revenues also included non-cash share-based compensation expense of $1.2 million for fiscal year 2014, compared with $1.1 million for fiscal year 2013.

[0001193125-14-373828:mdna:135]
Gross profit. Our gross profit increased by $4.8 million, or 6.9%, to $74.2 million, or 11.0% of total revenues, for fiscal year
2014, compared with $69.4 million, or 10.8% of total revenues, for fiscal year 2013. The slight increase in gross profit margin during fiscal year 2014, compared with fiscal year 2013, was primarily related to an increase in revenues resulting from
increases in both optical and non-optical products sales volume.

[0001193125-14-373828:mdna:136]
SG&A expenses. Our SG&A expenses increased by $3.9 million, or 16.3%, to
$27.7 million, or 4.1% of total revenues, for fiscal year 2014, compared with $23.8 million, or 3.7% of total revenues, for fiscal year 2013. Our SG&A expenses increased both in absolute dollars and as a percentage of revenue during fiscal year
2014, compared with fiscal year 2013, mainly due to: (a) a $1.8 million increase in accrued executive bonuses, salaries, and other benefits; (b) the recognition of $0.5 million in severance and related payments to an executive who left the
Company in March 2014; (c) a $0.7 million increase in severance liability expense in fiscal year 2014 due to an increase in the number of employees; and (d) a $0.4 million increase in share-based compensation charges. We also recorded
share-based compensation charges of $4.4 million for fiscal year 2014, compared with $4.0 million for fiscal year 2013.

[0001193125-14-373828:mdna:137]
Income related to flooding. In fiscal year 2014, we recognized income related to flooding of $45.2 million towards full and final
settlement of our owned and consigned equipment and inventory claims. This income was offset by the recognition of $0.5 million of other expenses in connection with write-offs of advance payments to a customer due to flood losses. In fiscal year
2013, we recognized $27.2 million of income related to flooding, which consisted of an interim payment from our insurers of $16.2 million against our claims for owned inventory losses and owned equipment losses, a payment of $13.1 million from our
insurers in full and final settlement of our claims for business interruption losses and a payment of $0.1 million from our insurers in full and final settlement of our claim for damage to our buildings at Pinehurst, which was offset by the
recognition of $2.2 million in additional liabilities to third parties due to flood losses.

[0001193125-14-373828:mdna:138]
Expenses related to
reduction in workforce. During fiscal year 2013, we implemented a reduction in workforce and incurred expenses of approximately $2.1 million, which represented severance and benefits costs associated with the termination of approximately 180
employees in accordance with contractual obligations and local regulations.

[0001193125-14-373828:mdna:139]
Operating income. Our operating income
increased by $20.5 million to $91.3 million, or 13.5% of total revenues, for fiscal year 2014, compared with $70.8 million, or 11.0% of total revenues, for fiscal year 2013.

[0001193125-14-373828:mdna:140]
Interest income. Our interest income increased by $0.7 million to $1.8 million for fiscal year 2014, compared with $1.1 million for fiscal year 2013. This increase was due to increases in cash and
cash equivalent balances and an increase in interest rates.

[0001193125-14-373828:mdna:141]
Interest expense. Our interest expense decreased by $0.3
million to $0.7 million for fiscal year 2014, compared with $1.0 million for fiscal year 2013. These decreases were due to a decreases in our average long-term loan balances resulting from repayments during the year.

[0001193125-14-373828:mdna:142]
Income before income taxes. We recorded income before income taxes of $93.2 million for fiscal 2014, compared with $71.9 million
for fiscal year 2013.

[0001193125-14-373828:mdna:143]
Income tax expense. Our provision for income tax reflects an effective tax rate of 1.5% for
fiscal year 2014, compared with an effective tax rate of 4.1% for fiscal year 2013. The decrease was primarily due to the reversal of liability for uncertain tax positions, including accrued interest of $1.5 million and increase in deferred tax
assets of $0.6 million and a higher portion of net income during the period, primarily from income related to flooding of $44.7 million that was not subjected to income tax, compared with the reversal of liability for uncertain tax positions of $0.6
million for fiscal year 2013.

[0001193125-14-373828:mdna:144]
Net income. We recorded net income of $91.7 million, or 13.5% of total revenues, for
fiscal year 2014, compared with a net income of $69.0 million, or 10.7% of total revenues, for fiscal year 2013.

[0001193125-14-373828:mdna:145]
Comparison of Fiscal Year 2013 with Fiscal Year 2012

[0001193125-14-373828:mdna:146]
Total revenues. Our total revenues increased by $76.8 million, or 13.6%, to $641.5 million for fiscal year 2013, compared with
$564.7 million for fiscal year 2012. This increase was primarily due to an increase in optical communication product sales volume resulting from restoration of our operations that had been

[0001193125-14-373828:mdna:147]
temporarily suspended during the three months ended December 30, 2011 owing to the October and November 2011 flooding in Thailand. Revenues from optical communications products represented
70.1% of our total revenues fiscal year 2013, compared with 67.8% for fiscal year 2012.

[0001193125-14-373828:mdna:148]
Cost of revenues. Our cost of
revenues increased by $69.3 million, or 13.8%, to $572.1 million, or 89.2% of total revenues, for fiscal year 2013, compared with $502.8 million, or 89.0% of total revenues, for fiscal year 2012. The increase in absolute dollars was primarily due to
an increase in revenues, unfavorable foreign exchange impact to local spending in Thailand as a result of the appreciation of Thai baht, and an increase in Thailand’s minimum daily wages effective April 1, 2012. Cost of revenues also
included share-based compensation expense of $1.1 million for fiscal year 2013, compared with $1.5 million for fiscal year 2012.

[0001193125-14-373828:mdna:149]
Gross profit. Our gross profit increased by $7.5 million, or 12.1%, to $69.4 million, or 10.8% of total revenues, for fiscal year 2013, compared with $61.9 million, or 11.0% of total revenues, for
fiscal year 2012.

[0001193125-14-373828:mdna:150]
The increase in gross profit margin during fiscal year 2013, compared with fiscal year 2012, was primarily
related to an increase in revenues resulting from restoration of our operations, which had been temporarily suspended during the three months ended December 30, 2011 owing to flooding in Thailand, during which time our revenues decreased
significantly while we continued to incur fixed costs.

[0001193125-14-373828:mdna:151]
SG&A expenses. Our SG&A expenses increased by $0.3
million, or 1.4%, to $23.8 million, or 3.7% of total revenues, for fiscal year 2013, compared with $23.5 million, or 4.2% of total revenues, for fiscal year 2012. Our SG&A expenses increased in absolute dollars during fiscal year 2013, compared
with fiscal year 2012, due primarily to the recognition of accrued executive bonuses of approximately $1.4 million, partially offset by a decrease in business development expenses and CASIX’s administrative and research and development expenses
during fiscal year 2013. We also recorded share-based compensation charges of $4.0 million for fiscal year 2013, compared with $3.1 million for fiscal year 2012.

[0001193125-14-373828:mdna:152]
Income (expense) related to flooding. In fiscal year 2013, we recognized $27.2 million of income related to flooding which consisted of an interim payment from our insurers of $11.4 million against
our claims for owned inventory losses, an interim payment from our insurers of $4.8 million against our claims for owned equipment losses, a payment of $13.1 million from our insurers in full and final settlement of our claims for business
interruption losses, and a payment of $0.1 million from our insurers in full and final settlement of our claim for damage to our buildings at Pinehurst, offset by the recognition of additional liabilities to third parties due to flood losses of $2.2
million. In fiscal year 2012, we recognized $97.3 million of expense related to flooding, which consisted of losses of $48.5 million related to damage to customer-owned equipment and machinery, $28.4 million related to damage to our inventory
and customer-owned inventory, $4.6 million related to damage to our machinery and equipment, $2.4 million related to damage to our Chokchai facility, and $13.4 million of other flood-related expenses.

[0001193125-14-373828:mdna:153]
Expenses related to reduction in workforce. During the fourth quarters of fiscal year 2013 and fiscal year 2012, we implemented a
reduction in workforce and incurred expenses of approximately $2.1 million and $2.0 million, respectively which represented severance and benefits costs associated with the termination of approximately 180 employees and 170 employees,
respectively, in accordance with contractual obligations and local regulations.

[0001193125-14-373828:mdna:154]
Operating income (loss). Our operating
income increased by $131.6 million to $70.8 million, or 11.0% of total revenues, for fiscal year 2013, compared with an operating loss of $(60.8) million, or (10.8)% of total revenues, for fiscal year 2012.

[0001193125-14-373828:mdna:155]
Interest income. Our interest income for fiscal year 2013 increased by $0.2 million to $1.1 million, compared with $0.8 million
for fiscal year 2012. This increase was due to increases in cash and cash equivalent balances and an increase in interest rates.

[0001193125-14-373828:mdna:156]
Interest expense. Our interest expense for fiscal year 2013 increased by $0.6 million to $1.0 million, compared with $0.4 million for fiscal year 2012. This increases was due to an increase in
interest rates; increases

[0001193125-14-373828:mdna:157]
in our average long-term loan balances; and the cessation of capitalizing interest on Building 6 costs following completion of construction in April 2012.

[0001193125-14-373828:mdna:158]
Income (loss) before income taxes. We recorded income before income taxes of $71.9 million for fiscal year 2013, compared with
loss before income taxes of $(58.4) million for fiscal year 2012.

[0001193125-14-373828:mdna:159]
Income tax (expense) benefit. Our provision for
income tax reflects an effective tax rate of 4.1% for fiscal year 2013, compared with an effective tax rate of (3.4)% (tax benefit) for fiscal year 2012. The increase in effective tax rate for fiscal year 2013 was because we had net income from
operations during that period, while in fiscal year 2012, we had a negative effective tax rate due to a tax benefit resulting from a net loss caused by flood-related losses.

[0001193125-14-373828:mdna:160]
Net income (loss). We recorded net income of $69.0 million, or 10.7% of total revenues, for fiscal year 2013, as compared with a net loss of $(56.5) million, or (10.0)% of total revenues, for
fiscal year 2012.

[0001193125-14-373828:mdna:161]
Liquidity and Capital Resources

[0001193125-14-373828:mdna:162]
We primarily finance our operations through cash flow from operations activities. As of June 27, 2014, June 28, 2013 and June 29, 2012, we had cash and cash equivalents of $233.5
million, $149.7 million, and $115.5 million, respectively and outstanding debt of $16.5 million, $28.9 million and $38.6 million, respectively.

[0001193125-14-373828:mdna:163]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits and liquid investments with original maturities of three months or less, are placed with banks and other financial
institutions. The weighted average interest rate on our cash and cash equivalents for fiscal year 2014, fiscal year 2013, and fiscal year 2012 was 1.0%, 0.9% and 0.8%, respectively.

[0001193125-14-373828:mdna:164]
As of June 27, 2014, all claims that we submitted to our insurance companies for flood related losses have been settled. In fiscal
year 2014, we recognized $45.2 million in flood-related income towards full and final settlement of our owned and consigned equipment and inventory claims. This income was offset by the recognition of $0.5 million of other expense in connection with
write-offs of advance payments to a customer due to flood losses.

[0001193125-14-373828:mdna:165]
For fiscal year 2013, we recognized $29.4 million of income
related to flooding, which consisted of an interim payment from our insurers of $16.2 million against our claims for owned inventory losses and owned equipment losses, a payment from our insurer of $13.1 million in full and final settlement of our
claim for business interruption losses, and a payment from our insurer of $0.1 million in full and final settlement of our claim for damage to our buildings at Pinehurst. For fiscal year 2013, we recognized additional expenses of $2.2 million
related to liabilities to third parties due to flood losses.

[0001193125-14-373828:mdna:166]
During fiscal year 2014, we made a cash payment of $5.2 million
and transferred equipment, with an aggregate value of $2.3 million, to a customer towards full and final settlement for any and all flood-related losses incurred by this customer in accordance with the settlement agreement entered into during fiscal
year 2013. In addition, during fiscal year 2014, we fulfilled our obligations to a customer’s insurers by making a payment of $2.2 million for full and final settlement of our liability for damages to customer-owned inventory that occurred
during the flooding in accordance with the settlement agreement entered into during fiscal year 2013. We also made a cash payment of $0.1 million towards the other flood-related settlements during fiscal year 2014.

[0001193125-14-373828:mdna:167]
During fiscal year 2013, we entered into a settlement agreement with three of our customers relating to our liability for the
customers’ losses as a result of the flooding and made an initial aggregate payment of $8.1 million to such customers.

[0001193125-14-373828:mdna:168]
Notwithstanding the foregoing, we believe that our current cash and cash equivalents, and cash flow from operations will be sufficient to
meet our working capital and capital expenditure needs for the next 12 months.

[0001193125-14-373828:mdna:169]
Our ability to sustain our working capital position is subject to a number of risks that we discuss in Item 1A of this Annual Report on Form 10-K.

[0001193125-14-373828:mdna:170]
We also believe that our current manufacturing capacity is sufficient to meet anticipated production requirements for at least the next
12 months. We maintain a long-term credit facility associated with construction of production facilities at our Pinehurst campus in Thailand that will come due within the next 33 months, and we anticipate that our internally generated working
capital, together with our cash and cash equivalents will be adequate to repay this obligation.

[0001193125-14-373828:mdna:171]
The following table shows our
net cash provided by operating activities, net cash used in investing activities, and net cash (used in) provided by financing activities for the periods indicated:

[0001193125-14-373828:mdna:172]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 27, 2014 |  |  | June 28, 2013 |  |  | June 29, 2012 |  |
| Net cash provided by operating activities |  | $ | 66,550 |  |  | $ | 48,750 |  |  | $ | 2,251 |  |
| Net cash provided by (used in) investing activities |  | $ | 26,988 |  |  | $ | (5,862 | ) |  | $ | (37,378 | ) |
| Net cash (used in) provided by financing activities |  | $ | (8,171 | ) |  | $ | (9,128 | ) |  | $ | 23,202 |  |
| Net increase (decrease) in cash and cash equivalents |  | $ | 85,367 |  |  | $ | 33,760 |  |  | $ | (11,925 | ) |
| Cash and cash equivalents, beginning of period |  | $ | 149,716 |  |  | $ | 115,507 |  |  | $ | 127,282 |  |
| Cash and cash equivalents, end of period |  | $ | 233,477 |  |  | $ | 149,716 |  |  | $ | 115,507 |  |

[0001193125-14-373828:mdna:173]
Operating Activities

[0001193125-14-373828:mdna:174]
Net cash provided by operating activities increased by $17.8 million, or 36.5%, to $66.6 million for fiscal year 2014, compared with net
cash provided by operating activities of $48.8 million for fiscal year 2013. The increase was primarily due to an increase in net income from operations, a decrease of $34.5 million in flood-related liabilities to third parties, as we fulfilled our
payment obligations to our customers under settlement agreements entered into during fiscal year 2014 and fiscal year 2013, a decrease of $26.6 million in cash payment to vendor, and an increase of $12.6 million in cash collection from customers
which were offset by an increase of $50.3 million in inventory.

[0001193125-14-373828:mdna:175]
Net cash provided by operating activities increased by $46.5
million, or 2,065.7%, to $48.8 million for fiscal year 2013, compared with net cash provided by operating activities of $2.3 million for fiscal year 2012. The increase was primarily due to an increase in net income resulting from restoration of
operations which had been temporarily suspended during the three months ended December 30, 2011 as a result of flooding in Thailand, compared with a net loss in fiscal year 2012 due to the effects of the flooding, offset by a decrease of
$42.0 million in flood-related liabilities to third parties, as we have substantially fulfilled our payment obligations to our customers under settlement agreements entered into during fiscal year 2014 and fiscal year 2013.

[0001193125-14-373828:mdna:176]
Investing Activities

[0001193125-14-373828:mdna:177]
Net cash provided by investing activities increased by $32.9 million, or 560.4%, to $27.0 million for fiscal year 2014, compared with net cash used in investing activities of $5.9 million for fiscal year
2013. The increase in net cash provided by investing activities was primarily due to the receipt of $37.8 million in proceeds against claims related to flood damage to consigned and owned equipment.

[0001193125-14-373828:mdna:178]
Net cash used in investing activities decreased by $31.5 million, or 84.3 %, to $5.9 million for fiscal year 2013, compared with net
cash used in investing activities of $37.4 million for fiscal year 2012. The decrease was primarily due to a decrease in payments for construction of Pinehurst Building 6, which was completed in April 2012, and the receipt of $4.9 million of
proceeds from our insurers against claims related to flood damage to owned equipment and our buildings at Pinehurst.

[0001193125-14-373828:mdna:179]
Financing Activities

[0001193125-14-373828:mdna:180]
Net cash used in financing activities decreased by $1.0 million, or 10.5%, to $8.2 million for fiscal year 2014, compared with net cash
used in financing activities of $9.1 million for fiscal year 2013. This decrease was primarily due to an increase of $4.0 million from the proceeds from issuance of ordinary shares under employee share option plans, offset by an increase of $2.7
million from the early repayment of long-term loans for Pinehurst Building 5.

[0001193125-14-373828:mdna:181]
Net cash used in financing activities increased
by $32.3 million, or 139.3%, to $9.1 million for fiscal year 2013, compared with net cash provided by financing activities of $23.2 million for fiscal year 2012. This increase was primarily due to scheduled repayments of long-term loans for
Pinehurst Building 5 and Building 6 and no new drawdowns during fiscal year 2013, compared with a drawdown of $28.0 million in fiscal year 2012 for construction of Pinehurst Building 6.

[0001193125-14-373828:mdna:182]
Contractual Obligations

[0001193125-14-373828:mdna:183]
The following table sets forth certain of our
contractual obligations as of June 27, 2014:

[0001193125-14-373828:mdna:184]
|  |  | Payments Due by Period |  |
| (amount in thousands) |  | Total |  |  | Less than 1year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5years |  |
| Long-term debt obligations |  | $ | 16,500 |  |  | $ | 6,000 |  |  | $ | 10,500 |  |  | $ | — |  |  | $ | — |  |
| Interest expense obligation (1) |  |  | 760 |  |  |  | 437 |  |  |  | 323 |  |  |  | — |  |  |  | — |  |
| Operating lease obligations |  |  | 4,505 |  |  |  | 988 |  |  |  | 1,870 |  |  |  | 1,368 |  |  |  | 279 |  |
| Severance liabilities |  |  | 4,453 |  |  |  | 268 |  |  |  | 235 |  |  |  | 345 |  |  |  | 3,605 |  |
| Provision for uncertain income tax position |  |  | 905 |  |  |  | — |  |  |  | 395 |  |  |  | 510 |  |  |  | — |  |
| Total |  | $ | 27,123 |  |  | $ | 7,693 |  |  | $ | 13,323 |  |  | $ | 2,223 |  |  | $ | 3,884 |  |

[0001193125-14-373828:mdna:185]
| (1) | Interest expense obligation reflects the interest rate on long-term debt obligation as of June 27, 2014. The interest rate was 3.0%. For further discussion of long-term debt obligations, see Note 11 of our audited consolidated financial statements. |

[0001193125-14-373828:mdna:186]
As of June 27,
2014, our long-term debt obligations consisted of approximately $16.5 million outstanding under a loan agreement. The loan is secured by certain property, plant and equipment and prescribes maximum ratios of debt to equity and minimum levels of debt
service coverage ratios (i.e., earnings before interest expenses and depreciation and amortization plus cash on hand minus short-term debts divided by current portion of long-term debts plus interest expenses). These financial ratio covenants could
restrict our ability to incur additional indebtedness and limit our ability to use our cash. Our long-term debt obligation also include customary events of default.

[0001193125-14-373828:mdna:187]
As of June 27, 2014, we were in compliance with our long-term loan agreements. Nonetheless, in the event of a default on these loans or a breach of a financial ratio covenant, the lenders may
immediately cancel the loan agreements, deem the full amount of the outstanding indebtedness immediately due and payable; charge us interest on a monthly basis on the full amount of the outstanding indebtedness and, if we cannot repay all of our
outstanding obligations, sell the assets pledged as collateral for the loans in order to fulfill our obligations to the lenders. We may also be held responsible for any damages and related expenses incurred by the lender as a result of any default.

[0001193125-14-373828:mdna:188]
We entered into a syndicated senior credit facility agreement (the “Facility Agreement”) with a consortium of banks
on May 22, 2014. The Facility Agreement, led by Bank of America, provides for a $200.0 million credit line, comprised of a $150.0 million revolving loan facility and a $50.0 million delayed draw term loan facility. The revolving loan facility
contains an accordion feature permitting us to request an increase in the facility up to $100.0 million subject to customary terms and conditions and provided that no default or event of default exists at the time of request. The revolving loan
facility terminates and all amounts outstanding are due and payable in

[0001193125-14-373828:mdna:189]
full on May 22, 2019. The principal amount of any drawn term loans must be repaid according to the scheduled quarterly amortization payments, with final payment of all amounts outstanding,
plus accrued interest, being due May 22, 2019. As of June 27, 2014, no amounts were outstanding under the Facility Agreement.

[0001193125-14-373828:mdna:190]
In addition, we have entered into short-term lending arrangements that are unused but available as needed. As of June 27, 2014, unused borrowing capacity available under short-term banking facilities
totaled $1.5 million.

[0001193125-14-373828:mdna:191]
As of June 27, 2014, we also had certain operating lease arrangements in which the lease payments
are calculated based on specified formulas. Our rental expenses under these leases were $0.8 million, $0.8 million and $1.8 million for fiscal year 2014, fiscal year 2013, and fiscal year 2012, respectively.

[0001193125-14-373828:mdna:192]
Capital Expenditures

[0001193125-14-373828:mdna:193]
The following table sets forth our capital expenditures, which include amounts for which payments have been accrued, for the periods
indicated.

[0001193125-14-373828:mdna:194]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 27, 2014 |  |  | June 28, 2013 |  |  | June 29, 2012 |  |
| Capital expenditures |  | $ | 10,604 |  |  | $ | 9,284 |  |  | $ | 37,386 |  |

[0001193125-14-373828:mdna:195]
Our capital expenditures for fiscal year 2014 and fiscal year 2013 principally consisted of investment in
equipment for our manufacturing facilities. Our capital expenditures for fiscal year 2012 principally consisted of investment in the construction of Pinehurst Building 6, investment in facilities improvements to defend against future flooding, and
the repair, restoration and replacement of flood-damaged equipment. During fiscal year 2015, we expect to purchase additional equipment for our manufacturing facilities.

[0001193125-14-373828:mdna:196]
Off-Balance Sheet Commitments and Arrangements

[0001193125-14-373828:mdna:197]
As of June 27, 2014,
we did not have any off-balance sheet arrangements as defined in Item 303(a)(4)(ii) of SEC Regulation S-K.

[0001193125-14-373828:mdna:198]
Recent Accounting
Pronouncements

[0001193125-14-373828:mdna:199]
See Note 2 of the Notes to Consolidated Financial Statements for recent accounting pronouncements that
could have an effect on us.
