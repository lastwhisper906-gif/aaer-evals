# FN notes — 0001193125-14-373828


## us-gaap:ScheduleOfEarningsPerShareDilutedByCommonClassTextBlock

[0001193125-14-373828:notes:1]
The earnings
 per ordinary share was calculated as follows:

[0001193125-14-373828:notes:2]
|  |  | Years Ended |  |
| (amount in thousands except per share amounts) |  | June 27, 2014 |  |  | June 28, 2013 |  |  | June 29, 2012 |  |
| Net income (loss) attributable to shareholders |  | $ | 91,731 |  |  | $ | 68,969 |  |  | $ | (56,467 | ) |
| Weighted average number of ordinary shares outstanding |  |  | 34,938 |  |  |  | 34,557 |  |  |  | 34,382 |  |
| Incremental shares arising from the assumed exercise of share options and vesting of restricted share units |  |  | 651 |  |  |  | 289 |  |  |  | — | (1) |
| Weighted average number of ordinary shares for diluted earnings (loss) per ordinary share |  |  | 35,589 |  |  |  | 34,846 |  |  |  | 34,382 |  |
| Basic earnings (loss) per ordinary share |  | $ | 2.63 |  |  | $ | 2.00 |  |  | $ | (1.64 | ) |
| Diluted earnings (loss) per ordinary share |  | $ | 2.58 |  |  | $ | 1.98 |  |  | $ | (1.64 | ) |
| Outstanding share options excluded in the computation of diluted earnings per ordinary share (in shares) (2) |  |  | 44,369 |  |  |  | 1,129,933 |  |  |  | — |  |

[0001193125-14-373828:notes:3]
| (1) | 200,055 ordinary shares were excluded from the determination of the loss per ordinary share for the year ended June 29, 2012 as they were considered antidilutive. |

[0001193125-14-373828:notes:4]
| (2) | These share options were not included in the computation of diluted earnings per ordinary share for fiscal year 2014 and fiscal year 2013, respectively, because the exercise price of the options was greater than the average market price of the underlying shares. |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-14-373828:notes:5]
Based on the
 carrying amount of intangibles as of June 27, 2014, and
 assuming no future impairment of the underlying assets, the
 estimated future amortization at the end of each fiscal year in
 June is as follows:

[0001193125-14-373828:notes:6]
| (amount in thousand) |  |  |  |
| 2015 |  | $ | 65 |  |
| 2016 |  |  | 5 |  |
| 2017 |  |  | 1 |  |
| 2018 |  |  | 1 |  |
| Total |  | $ | 72 |  |


## us-gaap:ScheduleOfNetBenefitCostsTableTextBlock

[0001193125-14-373828:notes:7]
The amount
 recognized in the consolidated statements of operations was as
 follows:

[0001193125-14-373828:notes:8]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 27, 2014 |  |  | June 28, 2013 |  |  | June 29, 2012 |  |
| Current service cost |  | $ | 368 |  |  | $ | 722 |  |  | $ | 474 |  |
| Interest cost |  |  | 207 |  |  |  | 211 |  |  |  | 198 |  |
| Benefit paid |  |  | (223 | ) |  |  | (4 | ) |  |  | (81 | ) |
| Actuarial gain on obligation |  |  | (281 | ) |  |  | (967 | ) |  |  | (649 | ) |
| Total |  | $ | 71 |  |  | $ | (38 | ) |  | $ | (58 | ) |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001193125-14-373828:notes:9]
Total revenues,
 by percentage, from individual customers representing 10% or more
 of total revenues in the respective periods were as
 follows:

[0001193125-14-373828:notes:10]
|  |  | Years Ended |  |
|  |  | June 27, 2014 |  |  | June 28, 2013 |  |  | June 29, 2012 |  |
| JDS Uniphase Corporation |  |  | 24 | % |  |  | 22 | % |  |  | 25 | % |
| Oclaro, Inc. (1) |  |  | 22 | % |  |  | 25 | % |  |  | 12 | % |
| Finisar Corporation |  |  | * | (2) |  |  | * | (2) |  |  | 10 | % |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001193125-14-373828:notes:11]
| 9. | Property, plant and equipment, net |

[0001193125-14-373828:notes:12]
The components
 of property, plant and equipment, net were as follows:

[0001193125-14-373828:notes:13]
| (amount in thousands) |  | Land |  |  | Building and Building Improvement |  |  | Manufacturing Equipment |  |  | Office Equipment |  |  | Motor Vehicles |  |  | Computers |  |  | Construction and Machinery Under Installation |  |  | Total |  |
| As of June 27, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost |  | $ | 14,353 |  |  | $ | 73,353 |  |  | $ | 60,354 |  |  | $ | 5,376 |  |  | $ | 615 |  |  | $ | 12,044 |  |  | $ | 1,369 |  |  | $ | 167,464 |  |
| Less: Accumulated depreciation |  |  | — |  |  |  | (17,580 | ) |  |  | (39,100 | ) |  |  | (3,266 | ) |  |  | (608 | ) |  |  | (9,666 | ) |  |  | — |  |  |  | (70,220 | ) |
| Net book value |  | $ | 14,353 |  |  | $ | 55,773 |  |  | $ | 21,254 |  |  | $ | 2,110 |  |  | $ | 7 |  |  | $ | 2,378 |  |  | $ | 1,369 |  |  | $ | 97,244 |  |
| As of June 28, 2013 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost |  | $ | 14,353 |  |  | $ | 74,450 |  |  | $ | 59,392 |  |  | $ | 5,666 |  |  | $ | 638 |  |  | $ | 12,070 |  |  | $ | 3,864 |  |  | $ | 170,433 |  |
| Less: Accumulated depreciation |  |  | — |  |  |  | (15,090 | ) |  |  | (42,344 | ) |  |  | (3,342 | ) |  |  | (628 | ) |  |  | (9,307 | ) |  |  | — |  |  |  | (70,711 | ) |
| Less: Impairment reserve |  |  | — |  |  |  | (1,076 | ) |  |  | (1,091 | ) |  |  | (44 | ) |  |  | — |  |  |  | (301 | ) |  |  | (4 | ) |  |  | (2,516 | ) |
| Net book value |  | $ | 14,353 |  |  | $ | 58,284 |  |  | $ | 15,957 |  |  | $ | 2,280 |  |  | $ | 10 |  |  | $ | 2,462 |  |  | $ | 3,860 |  |  | $ | 97,206 |  |

[0001193125-14-373828:notes:14]
Depreciation
 expense amounted to $10.6 million, $10.0 million and $9.3 million
 for the years ended June 27, 2014, June 28, 2013 and
 June 29, 2012, respectively and have been allocated between
 cost of revenues and selling, general and administrative expenses
 in the consolidated statements of operations. During fiscal year
 2014, we wrote-off all assets damaged from flood and reversed all
 asset impairment reserve due to we fully settled with insurance
 companies for our damaged assets claim.

[0001193125-14-373828:notes:15]
The cost of
 fully depreciated property, plant and equipment written-off during
 the years ended June 27, 2014, June 28, 2013 and
 June 29, 2012 amounted to $2.6 million, $0.3 million and $4.2
 million, respectively.

[0001193125-14-373828:notes:16]
There was no
 interest expense capitalized in construction in progress during the
 years ended June 27, 2014 and June 28, 2013,
 respectively. Interest expense relating to a long-term loan from
 bank for the development of Pinehurst Building 6, of $0.5 million
 was capitalized in construction in progress during the year ended
 June 29, 2012.


## us-gaap:DebtPolicyTextBlock

[0001193125-14-373828:notes:17]
Borrowing
 costs

[0001193125-14-373828:notes:18]
Borrowing costs
 are accounted for on an accrual basis and are charged to the
 consolidated statements of operations in the year incurred, except
 for interest costs on borrowings to finance certain qualifying
 assets. Such costs to finance qualifying assets are capitalized
 during the period of time that is required to complete and prepare
 the assets for their intended use, as part of the cost of the
 assets. All other borrowing costs are expensed as
 incurred.

[0001193125-14-373828:notes:19]
The
 capitalization rate used to determine the amount of interest to be
 capitalized is the weighted average interest rate applicable to the
 Company’s outstanding borrowings during the year. Where funds
 are borrowed specifically for the acquisition, construction or
 production of assets, the amount of borrowing costs eligible for
 capitalization on the respective assets is determined as the actual
 borrowing costs are incurred on that borrowing during the
 respective periods.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001193125-14-373828:notes:20]
Shipping
 and handling costs

[0001193125-14-373828:notes:21]
The Company
 records costs related to shipping and handling in cost of revenues
 for all periods presented.


## us-gaap:DebtDisclosureTextBlock

[0001193125-14-373828:notes:22]
| 11. | Borrowings |

[0001193125-14-373828:notes:23]
Bank borrowings
 and long-term debt was comprised of the following:

[0001193125-14-373828:notes:24]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank borrowing |  | Rate (1) |  | Conditions |  | Term |  | As of June 27, 2014 |  |  | As of June 28, 2013 |  |
| No. 1 |  | LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | June 2012 – March 2017 |  | $ | 16,500 |  |  | $ | 22,500 |  |
| No. 2 (2) |  | SIBOR + 1.5% per annum |  | Repayable in quarterly installments within 8 years |  | May 2009 –February 2015 |  |  | — |  |  |  | 6,411 |  |
| Total |  |  |  |  |  |  |  |  | 16,500 |  |  |  | 28,911 |  |
| Less: Current portion |  |  |  |  |  |  | (6,000 | ) |  |  | (9,668 | ) |
| Non-current portion |  |  |  |  |  | $ | 10,500 |  |  | $ | 19,243 |  |

[0001193125-14-373828:notes:25]
|  | (1) | LIBOR is London Interbank Offered Rate and SIBOR is Singapore Interbank Offered Rate |

[0001193125-14-373828:notes:26]
|  | (2) | On April 28, 2014, the Company extinguished the long-term loan by making a payment of $3.7 million which included principal, interest expense and early repayment fee. Unamortized costs of this debt were recorded to consolidated statement of operation during the year. |

[0001193125-14-373828:notes:27]
On
 April 25, 2014, a subsidiary entered into an amendment to the
 bank borrowing No.1 agreement. Under the amendment of the contract,
 the long-term loan is secured by certain property, plant and
 equipment. The carrying amount of assets secured and pledged as
 collateral as of June 27, 2014 and June 28, 2013 was
 $52.3 and $21.8 million, respectively. This subsidiary is also
 required to comply with the maximum ratios of debt to equity and
 minimum levels of debt service coverage ratios and Fabrinet must
 maintain effective shareholding ratio. The carrying amounts of bank
 borrowings approximate their fair value.

[0001193125-14-373828:notes:28]
As of
 June 27, 2014 and June 28, 2013, the Company was in
 compliance with its long-term bank borrowing agreements. In
 addition to financial ratios, certain of the Company’s
 packing credits and long-term loans include customary events of
 default.

[0001193125-14-373828:notes:29]
The movement of
 long-term loans for the years ended June 27, 2014 and
 June 28, 2013 were as follow;

[0001193125-14-373828:notes:30]
| (amount in thousands) |  | June 27, 2014 |  |  | June 28, 2013 |  |
| Opening net book amount |  | $ | 28,911 |  |  | $ | 38,579 |  |
| Repayment during the year |  |  | (12,411 | ) |  |  | (9,668 | ) |
| Closing net book amount |  | $ | 16,500 |  |  | $ | 28,911 |  |

[0001193125-14-373828:notes:31]
As of
 June 27, 2014, future maturities of long-term debt were as
 follows at the end of each fiscal year below:

[0001193125-14-373828:notes:32]
| (amount in thousands) |  |  |  |
| 2015 |  | $ | 6,000 |  |
| 2016 |  |  | 6,000 |  |
| 2017 |  |  | 4,500 |  |
| Total |  | $ | 16,500 |  |

[0001193125-14-373828:notes:33]
Credit
 facilities:

[0001193125-14-373828:notes:34]
Fabrinet had
 entered into a syndicated senior credit facility agreement (the
 “Facility Agreement”) with a consortium of banks on
 May 22, 2014. The Facility Agreement, led by Bank of America,
 provides for a $200.0 million credit line, comprised of a $150.0
 million revolving loan facility and a $50.0 million delayed draw
 term loan facility. The revolving loan facility contains an
 accordion feature permitting Fabrinet to request an increase in the
 facility up to $100.0 million subject to customary terms and
 conditions and provided that no default or event of default exists
 at the time of request. The revolving loan facility terminates and
 all amounts outstanding are due and payable in full on May 22,
 2019. The principal amount of any drawn term loans must be repaid
 according to the scheduled quarterly amortization payments, with
 final payment of all amounts outstanding, plus accrued interest,
 being due May 22, 2019. As of June 27, 2014, no amounts
 were outstanding under the Facility Agreement.

[0001193125-14-373828:notes:35]
Loans under the
 Facility Agreement bear interest, at Fabrinet’s option, at a
 rate per annum equal to a LIBOR rate plus a spread of 1.75% to
 2.50%, or a base rate, determined in accordance with the Facility
 Agreement, plus a spread of 0.75% to 1.50%, in each case with such
 spread determined based on Fabrinet’s consolidated total
 leverage ratio for the preceding four fiscal quarter period.
 Interest is due and payable quarterly in arrears for loans bearing
 interest at the base rate and at the end of an interest period (or
 at each three month interval in the case of loans with interest
 periods greater than three months) in the case of loans bearing
 interest at the LIBOR rate. The applicable spreads and commitment
 fees will increase in the event that Fabrinet’s Thailand
 subsidiary is unable to guarantee the obligations under the
 Facility Agreement within 180 days after the closing
 date.

[0001193125-14-373828:notes:36]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet must maintain at
 least $40.0 million of cash, cash equivalents and marketable
 securities at financial institutions located in the United States.
 Further, Fabrinet is required to maintain any of its deposits
 accounts or securities accounts with balances in excess of $10.0
 million in a jurisdiction where a control agreement, or the
 equivalent under the local law, can be effected. The Facility
 Agreement contains customary affirmative and negative covenants.
 Negative covenants include, among other things, limitations on
 liens, indebtedness, investments, mergers, sales of assets, changes
 in the nature of the business, dividends and distributions,
 affiliate transactions and capital expenditures. The Facility
 Agreement contains financial covenants requiring Fabrinet to
 maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage
 ratio of not more than 2.50:1.00; and (iv) a minimum quick
 ratio of not less than 1.10:1.00. Each of these financial covenants
 is calculated on a consolidated basis for the consecutive four
 fiscal quarter period then ended.

[0001193125-14-373828:notes:37]
The Facility
 Agreement also contains customary events of default including,
 among other things, payment defaults, breaches of covenants or
 representations and warranties, cross-defaults with certain other
 indebtedness, bankruptcy and insolvency events and change in
 control of Fabrinet, subject to grace periods in certain instances.
 Upon an event of default, the lenders may terminate their
 commitments, declare all or a portion of the outstanding
 obligations payable by Fabrinet to be immediately due and payable
 and exercise other rights and remedies provided for under the
 Facility Agreement. The undrawn credit facility of
 $200.0 million is available on July 15, 2014 after the
 effective closing date.

[0001193125-14-373828:notes:38]
Fabrinet
 intends to use the proceeds of the credit line to finance a future
 manufacturing building in Thailand, and for general corporate
 purposes including mergers and acquisitions of complementary
 manufacturing businesses or technology, although Fabrinet has no
 current commitments with respect to any such
 acquisitions.

[0001193125-14-373828:notes:39]
Undrawn
 available credit facilities as of June 27, 2014 and
 June 28, 2013 totaled:

[0001193125-14-373828:notes:40]
|  |  | As of June 27, 2014 |  |  | As of June 28, 2013 |  |
| Bank borrowings: |  |  |  |  |  |  |  |  |
| Short-term loans |  | $ | 1,539 |  |  | $ | 5,461 |  |


## us-gaap:ScheduleOfFutureMinimumRentalPaymentsForOperatingLeasesTableTextBlock

[0001193125-14-373828:notes:41]
As of
 June 27, 2014, the future minimum lease payments due under
 non-cancelable leases are as follows at the end of each fiscal year
 below:

[0001193125-14-373828:notes:42]
| (amount in thousands) |  |  |  |
| 2015 |  | $ | 988 |  |
| 2016 |  |  | 942 |  |
| 2017 |  |  | 928 |  |
| 2018 |  |  | 928 |  |
| 2019 |  |  | 441 |  |
| Thereafter |  |  | 279 |  |
| Total minimum operating lease payments |  | $ | 4,506 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001193125-14-373828:notes:43]
Revenue
 recognition

[0001193125-14-373828:notes:44]
The Company
 derives total revenues primarily from the assembly of products
 under supply agreements with its customers and the fabrication of
 customized optics and glass. Revenues represent the invoiced value
 of products, net of trade discounts and allowances, and exclude
 goods and services tax. The Company recognizes revenues when
 realized or realizable and earned. The Company considers revenues
 realized or realizable and earned when there is persuasive evidence
 of an arrangement, delivery has occurred, the sales price is fixed
 or determinable, and collectability is reasonably assured. Delivery
 does not occur until products have been shipped or services have
 been provided to the customer, risk of loss has transferred to the
 customer and customer acceptance has been obtained, customer
 acceptance provisions have lapsed, or the Company has objective
 evidence that the criteria specified in the customer acceptance
 provisions have been satisfied. In situations where a formal
 acceptance is required but the acceptance only relates to whether
 the product meets its published specifications, revenues are
 generally recognized upon shipment provided all other revenue
 recognition criteria are met. The sales price is not considered to
 be fixed or determinable until all contingencies related to the
 sale have been resolved. The Company reduces revenues for rebates
 and other similar allowances. Revenues are recognized only if these
 estimates can be reasonably and reliably determined. The Company
 bases its estimates on historical results taking into consideration
 the type of customer, the type of transaction and the specifics of
 each arrangement. In addition to the aforementioned general
 policies, the following are the specific revenue recognition
 policies for each major category of revenues.

[0001193125-14-373828:notes:45]
Services

[0001193125-14-373828:notes:46]
The Company
 provides services for its customers that range from process design
 to product manufacturing. The Company recognizes service revenues
 when the services have been performed. The related costs are
 expensed as incurred.

[0001193125-14-373828:notes:47]
Sales of
 goods

[0001193125-14-373828:notes:48]
Revenues from
 sales of goods are generally recognized when the product is shipped
 to the customer and when there are no unfulfilled obligations that
 affect the customer’s final acceptance of the arrangement.
 Any cost of warranties and remaining obligations that are
 inconsequential or perfunctory are accrued when the corresponding
 revenues are recognized.


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-14-373828:notes:49]
The Company
 operates primarily in three geographic regions: North America,
 Asia-Pacific and Europe. The following table presents total
 revenues by geographic regions:

[0001193125-14-373828:notes:50]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 27, 2014 |  |  | June 28, 2013 |  |  | June 29, 2012 |  |
| North America |  | $ | 326,647 |  |  | $ | 299,510 |  |  | $ | 272,659 |  |
| Asia-Pacific |  |  | 230,314 |  |  |  | 218,393 |  |  |  | 189,455 |  |
| Europe |  |  | 120,893 |  |  |  | 123,639 |  |  |  | 102,618 |  |
| Total |  | $ | 677,854 |  |  | $ | 641,542 |  |  | $ | 564,732 |  |


## us-gaap:ScheduleOfDefinedBenefitPlansDisclosuresTextBlock

[0001193125-14-373828:notes:51]
The following
 table provides the information of the severance
 liabilities:

[0001193125-14-373828:notes:52]
| (amount in thousands) |  | As of June 27, 2014 |  |  | As of June 28, 2013 |  |
| Balance, beginning of the fiscal year |  | $ | 4,382 |  |  | $ | 4,420 |  |
| Charged to consolidated statements of operations |  |  | 71 |  |  |  | (38 | ) |
| Balance, end of the fiscal year |  | $ | 4,453 |  |  | $ | 4,382 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-14-373828:notes:53]
The following
 table summarizes share options activity:

[0001193125-14-373828:notes:54]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 24, 2011 |  |  | 1,349,126 |  |  |  |  |  |  | $ | 13.28 |  |  |  |  |  |
| Granted |  |  | 590,537 |  |  |  |  |  |  | $ | 14.82 |  |  | $ | 14.82 |  |
| Exercised |  |  | (237,350 | ) |  |  |  |  |  | $ | 4.22 |  |  |  |  |  |
| Forfeited |  |  | (218,296 | ) |  |  |  |  |  | $ | 16.18 |  |  |  |  |  |
| Expired |  |  | (13,727 | ) |  |  |  |  |  | $ | 18.38 |  |  |  |  |  |
| Balance as of June 29, 2012 |  |  | 1,470,290 |  |  |  | 532,646 |  |  | $ | 14.88 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (94,188 | ) |  |  |  |  |  | $ | 5.96 |  |  |  |  |  |
| Forfeited |  |  | (44,443 | ) |  |  |  |  |  | $ | 17.33 |  |  |  |  |  |
| Expired |  |  | (54,348 | ) |  |  |  |  |  | $ | 16.97 |  |  |  |  |  |
| Balance as of June 28, 2013 |  |  | 1,277,311 |  |  |  | 750,949 |  |  | $ | 15.37 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (351,435 | ) |  |  |  |  |  | $ | 13.00 |  |  |  |  |  |
| Forfeited |  |  | (26,276 | ) |  |  |  |  |  | $ | 15.54 |  |  |  |  |  |
| Expired |  |  | (33,710 | ) |  |  |  |  |  | $ | 16.93 |  |  |  |  |  |
| Balance as of June 27, 2014 |  |  | 865,890 |  |  |  | 666,305 |  |  | $ | 16.27 |  |  |  |  |  |


## us-gaap:ScheduleOfErrorCorrectionsAndPriorPeriodAdjustmentsTextBlock

[0001193125-14-373828:notes:55]
Had
 adjustments been made to reflect revenues and cost of revenues in
 the appropriate quarters in the fiscal year ended June 27,
 2014, revenues, cost of revenues, and net income for each of the
 quarters in the fiscal year ended June 27, 2014 would have
 increased (decreased) as follows:

[0001193125-14-373828:notes:56]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | Jun 27, 2014 (Q4 FY14) |  |  | Mar 28, 2014 (Q3 FY14) |  |  | Dec 27, 2013 (Q2 FY14) |  |  | Sep 27, 2013 (Q1 FY14) |  |
| Revenues |  | $ | 12,777 |  |  | $ | 1,964 |  |  | $ | (6,350 | ) |  | $ | 2,706 |  |
| Cost of revenues |  | $ | 11,520 |  |  | $ | 1,771 |  |  | $ | (5,726 | ) |  | $ | 2,440 |  |
| Net income |  | $ | 1,257 |  |  | $ | 193 |  |  | $ | (625 | ) |  | $ | 266 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-14-373828:notes:57]
| (amount in thousands) |  | As of June 27, 2014 |  |  | As of June 28, 2013 |  |
| Raw materials |  | $ | 40,885 |  |  | $ | 34,572 |  |
| Work in progress |  |  | 56,376 |  |  |  | 43,806 |  |
| Finished goods |  |  | 22,970 |  |  |  | 7,342 |  |
| Goods in transit |  |  | 6,899 |  |  |  | 5,359 |  |
|  |  |  | 127,130 |  |  |  | 91,079 |  |
| Less: Inventory obsolescence |  |  | (2,560 | ) |  |  | (2,117 | ) |
| Inventory, net |  | $ | 124,570 |  |  | $ | 88,962 |  |


## us-gaap:ScheduleOfQuarterlyFinancialInformationTableTextBlock

[0001193125-14-373828:notes:58]
The following
 tables set forth a summary of the Company’s quarterly
 financial information for each of the four quarters in the fiscal
 years ended June 27, 2014 and June 28, 2013:

[0001193125-14-373828:notes:59]
|  |  | Three Months Ended |  |
| (in thousands, except per share data) |  | Jun 27, 2014 |  |  | Mar 28, 2014 |  |  | Dec 27, 2013 |  |  | Sep 27, 2013 |  |  | Jun 28, 2013 |  |  | Mar 29, 2013 |  |  | Dec 28, 2012 |  |  | Sep 28, 2012 |  |
| Total revenues |  | $ | 160,084 |  |  | $ | 167,657 |  |  | $ | 178,562 |  |  | $ | 171,551 |  |  | $ | 159,934 |  |  | $ | 155,557 |  |  | $ | 167,426 |  |  | $ | 158,625 |  |
| Gross profit |  | $ | 17,775 |  |  | $ | 17,283 |  |  | $ | 20,530 |  |  | $ | 18,645 |  |  |  | 17,071 |  |  |  | 16,255 |  |  |  | 18,370 |  |  |  | 17,722 |  |
| Net income |  | $ | 10,333 |  |  | $ | 47,662 |  |  | $ | 14,539 |  |  | $ | 19,197 |  |  | $ | 15,142 |  |  | $ | 21,126 |  |  | $ | 16,682 |  |  | $ | 16,019 |  |
| Basic net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 0.29 |  |  | $ | 1.36 |  |  | $ | 0.42 |  |  | $ | 0.55 |  |  | $ | 0.44 |  |  | $ | 0.61 |  |  | $ | 0.48 |  |  | $ | 0.46 |  |
| Weighted-average shares used in basic net income per share calculations |  |  | 35,117 |  |  |  | 35,078 |  |  |  | 34,882 |  |  |  | 34,674 |  |  |  | 34,629 |  |  |  | 34,596 |  |  |  | 34,517 |  |  |  | 34,485 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 0.29 |  |  | $ | 1.33 |  |  | $ | 0.41 |  |  | $ | 0.55 |  |  | $ | 0.43 |  |  | $ | 0.61 |  |  | $ | 0.48 |  |  | $ | 0.46 |  |
| Weighted-average shares used in diluted net income per share calculations |  |  | 35,843 |  |  |  | 35,790 |  |  |  | 35,583 |  |  |  | 35,138 |  |  |  | 35,000 |  |  |  | 34,909 |  |  |  | 34,804 |  |  |  | 34,670 |  |


## us-gaap:ScheduleOfCashAndCashEquivalentsTableTextBlock

[0001193125-14-373828:notes:60]
The following
 table provides details for the cash and cash
 equivalents:

[0001193125-14-373828:notes:61]
| (amount in thousands) |  | As of June 27, 2014 |  |  | As of June 28, 2013 |  |
| Cash at banks and on hand |  | $ | 214,283 |  |  | $ | 61,705 |  |
| Cash equivalents |  |  | 19,194 |  |  |  | 88,011 |  |
| Total cash and cash equivalents |  | $ | 233,477 |  |  | $ | 149,716 |  |


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001193125-14-373828:notes:62]
The
 Company’s income tax expense consisted of the
 following:

[0001193125-14-373828:notes:63]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 27, 2014 |  |  | June 28, 2013 |  |  | June 29, 2012 |  |
| Current |  | $ | 2,304 |  |  | $ | 239 |  |  | $ | 282 |  |
| Deferred |  |  | (865 | ) |  |  | 2,701 |  |  |  | (2,250 | ) |
| Total income tax expense (benefit) |  | $ | 1,439 |  |  | $ | 2,940 |  |  | $ | (1,968 | ) |


## us-gaap:IncomeTaxPolicyTextBlock

[0001193125-14-373828:notes:64]
Income
 taxes

[0001193125-14-373828:notes:65]
The Company
 uses the asset and liability method of accounting for income taxes,
 whereby deferred tax assets and liabilities are recognized for
 future tax consequences attributable to temporary differences
 between the financial statement carrying amounts of existing assets
 and liabilities and their respective tax bases. Deferred tax assets
 and liabilities are measured using tax rates expected to apply to
 taxable income in the years in which those temporary differences
 are expected to reverse. The effect of a change in tax rates on
 deferred tax assets and liabilities is recognized in income in the
 period that includes the enactment date. Deferred tax assets are
 reduced by a valuation allowance if, based on the weight of the
 available evidence, it is more likely than not that some portion or
 all of the deferred tax assets will not be realized.

[0001193125-14-373828:notes:66]
Fabrinet’s subsidiaries are subject to income tax audits
 by the respective tax authorities in all of the jurisdictions in
 which they operate. The determination of tax liabilities in each of
 these jurisdictions requires the interpretation and application of
 complex and sometimes uncertain tax laws and regulations. The
 Company recognizes liabilities based on its estimate of whether,
 and the extent to which, additional tax liabilities are probable.
 If the Company ultimately determines that the payment of such a
 liability is not probable, then it reverses the liability and
 recognizes a tax benefit during the period in which the
 determination is made that the liability is no longer probable. The
 recognition and measurement of current taxes payable or refundable
 and deferred tax assets and liabilities requires that the Company
 makes certain estimates and judgments. Changes to these estimates
 or a change in judgment may have a material impact on the
 Company’s tax provision in a future period.

[0001193125-14-373828:notes:67]
The accounting
 standard clarifies the accounting for uncertainty in income taxes
 recognized in an entity’s financial statements and prescribes
 a recognition threshold and measurement attributes for financial
 statement disclosure of tax positions taken or expected to be taken
 on a tax return.

[0001193125-14-373828:notes:68]
The Company
 recognizes a tax benefit in the financial statements for an
 uncertain tax position only if management’s assessment is
 that the position is “more likely than not” (i.e., a
 likelihood greater than 50 percent) to be allowed by the tax
 jurisdiction based solely on the technical merits of the position.
 The term “tax position” refers to a position in a
 previously filed tax return or a position expected to be taken in a
 future tax return that is reflected in measuring current or
 deferred income tax assets and liabilities for interim or annual
 periods. The accounting interpretation also provides guidance on
 measurement methodology, derecognition thresholds, financial
 statement classification and disclosures, recognition of interest
 and penalties, and accounting for the cumulative-effect adjustment
 at the date of adoption.


## us-gaap:ScheduleOfAssumptionsUsedTableTextBlock

[0001193125-14-373828:notes:69]
The principal
 actuarial assumptions used were as follows:

[0001193125-14-373828:notes:70]
|  |  | Years Ended |  |
|  |  | June 27, 2014 |  |  | June 28, 2013 |  |  | June 29, 2012 |  |
| Discount rate |  |  | 4.9 | % |  |  | 5.1 | % |  |  | 4.8 | % |
| Future salary increases |  |  | 4.2 | % |  |  | 4.4 | % |  |  | 4.4 | % |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-14-373828:notes:71]
| 18. | Financial instruments |

[0001193125-14-373828:notes:72]
Objectives and significant terms and
 conditions

[0001193125-14-373828:notes:73]
The principal
 financial risks faced by the Company are foreign currency risk and
 interest rate risk. The Company borrows at floating rates of
 interest to finance its operations. A minority of sales and
 purchases and a majority of labor and overhead costs are entered
 into in foreign currencies. In order to manage the risks arising
 from fluctuations in currency exchange rates, the Company uses
 derivative financial instruments. Trading for speculative purposes
 is prohibited under Company policies.

[0001193125-14-373828:notes:74]
The Company
 enters into short-term forward foreign currency contracts and
 option contracts to help manage currency exposures associated with
 certain assets and liabilities. The forward exchange contracts and
 option contracts have generally ranged from one to six months in
 original maturity, and no forward exchange contract or option
 contract has an original maturity greater than one year. All
 foreign currency exchange contracts and option contracts are
 recognized on the consolidated balance sheets at fair value. As the
 Company does not apply hedge accounting to these instruments, the
 derivatives are recorded at fair value through earnings.

[0001193125-14-373828:notes:75]
The gains and
 losses on the Company’s derivative financial instruments
 generally offset losses and gains on the assets, liabilities and
 transactions economically hedged, and accordingly, generally do not
 subject the Company to risk of significant accounting
 losses.

[0001193125-14-373828:notes:76]
Foreign
 currency risk

[0001193125-14-373828:notes:77]
The Company
 operates internationally and is exposed to foreign exchange risk
 arising from various currency exposures primarily with respect to
 the Thai baht and the Chinese renminbi (RMB).

[0001193125-14-373828:notes:78]
As of
 June 27, 2014 and June 28, 2013, the Company had
 outstanding foreign currency assets and liabilities as
 follows:

[0001193125-14-373828:notes:79]
|  |  | As of June 27, 2014 |  |  | As of June 28, 2013 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | Currency |  |  | $ |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,536,887 |  |  | $ | 47,318 |  |  |  | 567,561 |  |  | $ | 18,232 |  |
| RMB |  |  | 74,813 |  |  |  | 12,156 |  |  |  | 105,680 |  |  |  | 17,104 |  |
| Total |  |  |  |  |  | $ | 59,474 |  |  |  |  |  |  | $ | 35,336 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 735,490 |  |  | $ | 22,644 |  |  |  | 585,364 |  |  | $ | 18,804 |  |
| RMB |  |  | 32,512 |  |  |  | 5,283 |  |  |  | 15,308 |  |  |  | 2,478 |  |
| Total |  |  |  |  |  | $ | 27,927 |  |  |  |  |  |  | $ | 21,282 |  |

[0001193125-14-373828:notes:80]
The Thai baht
 assets represent cash and cash equivalents, accounts receivable,
 deposits and other current assets. The Thai baht liabilities
 represent trade accounts payable, accrued expenses and other
 payables. The Company manages its exposure to fluctuations in
 foreign exchange rates by the use of foreign currency contracts and
 offsetting assets and liabilities denominated in the same currency
 in accordance with management’s policy. As of June 27,
 2014, there was $15.0 million in option contracts outstanding on
 the Thai baht payables and as of June 28, 2013, there were
 $23.0 million in selling forward contracts and $5.0 million in
 option contracts outstanding on the Thai baht payables.

[0001193125-14-373828:notes:81]
The RMB assets
 represent cash and cash equivalents, accounts receivable and other
 current assets. The RMB liabilities represent trade accounts
 payable, accrued expenses and other payables. As of June 27,
 2014 and June 28, 2013, there were no selling RMB to U.S.
 dollar forward contracts outstanding.

[0001193125-14-373828:notes:82]
As of
 June 27, 2014 and June 28, 2013, unrealized gain from
 fair market value of derivatives amounted to $0.1 million and
 unrealized loss from fair market value of derivatives amounted to
 $0.8 million, respectively.

[0001193125-14-373828:notes:83]
Interest
 Rate Risk

[0001193125-14-373828:notes:84]
The
 Company’s principal interest bearing assets are time deposits
 and short-term investments less than three months held with high
 quality financial institutions. The Company’s principal
 interest bearing liabilities are bank loans which bear interest at
 floating rates.


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0001193125-14-373828:notes:85]
The effect of
 recording share-based compensation expense for the years ended
 June 27, 2014, June 28, 2013 and June 29, 2012
 was as follows:

[0001193125-14-373828:notes:86]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 27, 2014 |  |  | June 28, 2013 |  |  | June 29, 2012 |  |
| Share-based compensation expense by type of award: |  |  |  |  |
| Share options |  | $ | 802 |  |  | $ | 1,864 |  |  | $ | 3,443 |  |
| Restricted share units |  |  | 4,745 |  |  |  | 3,236 |  |  |  | 1,206 |  |
| Total share-based compensation expense |  |  | 5,547 |  |  |  | 5,100 |  |  |  | 4,649 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 5,547 |  |  | $ | 5,100 |  |  | $ | 4,649 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-14-373828:notes:87]
| 5. | Fair Value |

[0001193125-14-373828:notes:88]
The following
 table provides details of the financial instruments measured at
 fair value on a recurring basis:

[0001193125-14-373828:notes:89]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 27, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 19,194 |  |  | $ | — |  |  | $ | 19,194 |  |
| Derivative assets |  |  | — |  |  |  | 135 |  |  |  | — |  |  |  | 135 |  |
| Total |  | $ | — |  |  | $ | 19,329 |  |  | $ | — |  |  | $ | 19,329 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Total |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |

[0001193125-14-373828:notes:90]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 28, 2013 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 88,011 |  |  | $ | — |  |  | $ | 88,011 |  |
| Total |  | $ | — |  |  | $ | 88,011 |  |  | $ | — |  |  | $ | 88,011 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 766 |  |  | $ | — |  |  | $ | 766 |  |
| Total |  | $ | — |  |  | $ | 766 |  |  | $ | — |  |  | $ | 766 |  |

[0001193125-14-373828:notes:91]
The Company
 uses foreign currency exchange contracts to manage the foreign
 exchange risk associated with certain foreign currency-denominated
 assets and liabilities. As a result of foreign currency
 fluctuations, the U.S. dollar equivalent values of its foreign
 currency-denominated assets and liabilities change. The Company has
 not designated such foreign currency exchange contracts as hedging
 instruments under the accounting standard for derivatives and
 hedging. The forward exchange contracts and option contracts
 outstanding as of June 27, 2014 and June 28, 2013 had a
 maturity in one to six months duration. The Company minimizes the
 credit risk in derivative instruments by limiting its exposure to
 any single counterparty and by entering into derivative instruments
 only with counterparties that meet the Company’s minimum
 credit quality standard.

[0001193125-14-373828:notes:92]
The derivative
 assets and liabilities are classified in other current assets and
 accrued expenses, respectively, on the consolidated balance sheets.
 The change in the fair value of the derivatives is recorded in
 foreign exchange (loss) gain on the consolidated statement of
 operations.


## us-gaap:AccountingChangesAndErrorCorrectionsTextBlock

[0001193125-14-373828:notes:93]
| 22. | Revenue recognition error related to finished goods awaiting shipment to customers under certain Volume Supply Agreements with customers |

[0001193125-14-373828:notes:94]
During the
 preparation of the fiscal year 2014 consolidated financial
 statements, the Company determined that certain finished goods
 sales recognized in each annual and quarterly reporting period in
 the fiscal years ended June 28, 2013 and June 29, 2012
 and in each of the first three quarterly reporting periods in the
 fiscal year ended June 27, 2014 did not qualify for revenue
 recognition in those periods in accordance with U.S. generally
 accepted accounting principles (“U.S. GAAP”) as the
 risk of loss had not transferred to the Company’s customers.
 The Company has evaluated the impact of the errors on both a
 quantitative and qualitative basis under the guidance of ASC
 250—Accounting Changes and Error Corrections and determined
 that the errors did not have a material impact to the consolidated
 financial statements for the fiscal years ended June 27,
 2014, June 28, 2013 and June 29, 2012, or the
 interim consolidated financial statements for each of the quarters
 within those years. Accordingly, the Company has not made any
 adjustments to those consolidated financial statements. As the
 Company did not revise the historical financial statements, the
 cumulative effect of the errors is reflected in the fiscal year
 2014 fourth quarter and full year results.

[0001193125-14-373828:notes:95]
Had the
 Company made adjustments to record in fiscal year 2014, revenues
 and cost of revenues that were inappropriately recorded in fiscal
 year 2013, fiscal year 2014 revenues, cost of revenues and net
 income would have increased by $11.09 million, $10.00 million and
 $1.09 million, respectively, and fiscal year 2013 revenue, cost of
 revenues and net income would have been lower than previously
 reported.


## us-gaap:ScheduleOfCreditLossesForFinancingReceivablesCurrentTableTextBlock

[0001193125-14-373828:notes:96]
The activities
 and balances for allowance for doubtful accounts were as
 follows:

[0001193125-14-373828:notes:97]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 27, 2014 |  |  | June 28, 2013 |  |  | June 29, 2012 |  |
| Balance, beginning of period |  | $ | 109 |  |  | $ | 203 |  |  | $ | 79 |  |
| (Credited to Income)/Charged to Expense |  |  | (72 | ) |  |  | (94 | ) |  |  | 124 |  |
| Balance, end of period |  | $ | 37 |  |  | $ | 109 |  |  | $ | 203 |  |


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-14-373828:notes:98]
Principles of consolidation

[0001193125-14-373828:notes:99]
The Company
 utilizes a 52-53 week fiscal year ending on the Friday in June
 closest to June 30. Fiscal year 2014, fiscal year 2013, and
 fiscal year 2012 ended on June 27, 2014, June 28,
 2013 and June 29, 2012, respectively and consisted of 52
 weeks, 52 weeks and 53 weeks, respectively.

[0001193125-14-373828:notes:100]
The
 consolidated financial statements have been prepared in accordance
 with accounting principles generally accepted in the United States
 (“U.S. GAAP”) and include Fabrinet and its subsidiaries
 listed in Note 1 above. All inter-company accounts and transactions
 have been eliminated.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001193125-14-373828:notes:101]
UNAUDITED QUARTERLY FINANCIAL INFORMATION

[0001193125-14-373828:notes:102]
As disclosed
 in Note 22 of the consolidated financial statements, the Company
 determined that certain finished goods sales recognized in each
 annual and quarterly reporting period in the fiscal years ended
 June 27, 2014 and June 28, 2013 did not qualify for
 revenue recognition in those periods. The Company has evaluated the
 impact of the errors and determined that the errors did not have a
 material impact to the consolidated financial statements for the
 fiscal years ended June 27, 2014 and June 28, 2013, or
 the interim consolidated financial statements for each of the
 quarters within those years. Accordingly, the Company has not made
 any adjustments to those consolidated financial
 statements.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-14-373828:notes:103]
| 8. | Inventory |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-14-373828:notes:104]
| 15. | Shareholders’ equity |

[0001193125-14-373828:notes:105]
Fabrinet’s
 authorized share capital is 500,000,000 ordinary shares, par value
 of $0.01 per ordinary share, and 5,000,000 preferred shares, par
 value of $0.01 per preferred share.

[0001193125-14-373828:notes:106]
In the year
 ended June 27, 2014, Fabrinet issued 351,435 ordinary shares
 upon the exercise of options, for cash consideration at a weighted
 average exercise price of $13.00 per share, and 166,370 ordinary
 shares upon the vesting of restricted share units, net of shares
 withheld.

[0001193125-14-373828:notes:107]
In the year
 ended June 28, 2013, Fabrinet issued 94,188 ordinary shares
 upon the exercise of options, for cash consideration at a weighted
 average exercise price of $5.96 per share, and 69,950 ordinary
 shares upon the vesting of restricted share units, net of shares
 withheld.

[0001193125-14-373828:notes:108]
In the year
 ended June 29, 2012, Fabrinet issued 237,350 ordinary shares
 upon the exercise of options, for cash consideration at a weighted
 average exercise price of $4.22 per share, and 25,900 ordinary
 shares upon the vesting of restricted share units.

[0001193125-14-373828:notes:109]
All such issued
 shares are fully paid.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0001193125-14-373828:notes:110]
| 6. | Cash and cash equivalents |

[0001193125-14-373828:notes:111]
The cash
 equivalents includes short-term bank deposits and investment in
 money market funds. The weighted average effective interest rate on
 short term bank deposits was 1.01% and 0.87% per annum for the
 years ended June 27, 2014 and June 28, 2013,
 respectively.

[0001193125-14-373828:notes:112]
As of
 June 27, 2014, 70.9% of our cash and cash equivalents were
 held by Parent Company.


## us-gaap:InventoryPolicyTextBlock

[0001193125-14-373828:notes:113]
Inventory

[0001193125-14-373828:notes:114]
Inventory is
 stated at the lower of cost or market value. Cost is estimated
 using the standard costing method, computed on a first-in,
 first-out basis, with adjustments for variances to reflect actual
 costs not in excess of net realizable market value. Market value is
 the estimated selling price in the ordinary course of business,
 less the costs of completion and selling expenses. The Company
 assesses the valuation of inventory on a quarterly basis and writes
 down the value for estimated excess and obsolete inventory based
 upon estimates of future demand.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001193125-14-373828:notes:115]
Property,
 plant and equipment

[0001193125-14-373828:notes:116]
Land is stated
 at historical cost. Other property, plant and equipment, except for
 construction in process and machinery under installation, are
 stated at historical cost less accumulated depreciation.
 Depreciation is calculated on the straight-line method to write-off
 the cost of each asset to its residual value over its estimated
 useful life as follows:

[0001193125-14-373828:notes:117]
| Building and building improvements |  |  | 10 - 30 years |  |
| Leasehold improvements |  |  | Shorter of useful life or lease term |  |
| Manufacturing equipment |  |  | 3 - 5 years |  |
| Office equipment |  |  | 3 - 5 years |  |
| Motor vehicles |  |  | 5 years |  |
| Computer hardware |  |  | 3 - 5 years |  |

[0001193125-14-373828:notes:118]
Construction in
 process and machinery under installation is stated at historic cost
 and depreciation begins after it is constructed and fully installed
 and is used in the operations of the Company.

[0001193125-14-373828:notes:119]
Gains and losses
 on disposal are determined by comparing proceeds with carrying
 amounts and are included in operating income in the consolidated
 statements of operations.

[0001193125-14-373828:notes:120]
The Company
 tests long-lived assets or asset groups for recoverability when
 events or changes in circumstances indicate that their carrying
 amount may not be recoverable. Recoverability of long-lived assets
 or asset groups is measured by comparing their carrying amount to
 the projected undiscounted cash flows that the long-lived assets or
 asset groups are expected to generate. If such assets are
 considered to be impaired, the impairment loss recognized, if any,
 is the amount by which the carrying amount of the property and
 equipment exceeds its fair value.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001193125-14-373828:notes:121]
Cash and
 cash equivalents

[0001193125-14-373828:notes:122]
All highly
 liquid investments with maturities of three months or less from
 original dates of purchase are carried at fair market value and
 considered to be cash equivalents. Cash and cash equivalents
 consist of cash deposited in checking accounts, time deposits with
 maturities of less than three months and money market
 accounts.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-14-373828:notes:123]
| 2. | Summary of significant accounting policies |

[0001193125-14-373828:notes:124]
Use of
 estimates

[0001193125-14-373828:notes:125]
The preparation
 of the Company’s consolidated financial statements in
 conformity with U.S. GAAP requires management to make estimates and
 assumptions that affect the reported amounts of assets and
 liabilities and disclosure of contingent liabilities at the date of
 the financial statements, and the reported amount of total revenues
 and expense during the year. The Company bases estimates on
 historical experience and various assumptions about the future that
 are believed to be reasonable based on available information. The
 Company’s reported financial position or results of
 operations may be materially different under different conditions
 or when using different estimates and assumptions, particularly
 with respect to significant accounting policies, which are
 discussed below. Significant assumptions are used in accounting for
 share-based compensation, allowance for doubtful accounts, income
 taxes and inventory obsolescence, among others. Due to the inherent
 uncertainty involved in making estimates, actual results reported
 in future periods may be different from these estimates. In the
 event that estimates or assumptions prove to differ from actual
 results, adjustments will be made in subsequent periods to reflect
 more current information.

[0001193125-14-373828:notes:126]
Foreign
 currency transactions and translation

[0001193125-14-373828:notes:127]
The
 consolidated financial statements are presented in United States
 Dollars (“$” or “USD”).

[0001193125-14-373828:notes:128]
The functional
 currency of Fabrinet and its subsidiaries is the USD. Transactions
 in currencies other than the functional currency are translated
 into the functional currency at the rates of exchange in effect at
 the date of the transaction. Monetary assets and liabilities
 denominated in foreign currencies are translated into the
 functional currency at the exchange rate prevailing at the balance
 sheet dates. Transaction gains and losses are included in other
 income and expense, net, in the accompanying consolidated
 statements of operations.

[0001193125-14-373828:notes:129]
Trade
 accounts receivable

[0001193125-14-373828:notes:130]
Accounts
 receivable are carried at anticipated realizable value. The Company
 assesses the collectability of its accounts receivable based on
 specific customer circumstances, current economic trends,
 historical experience with collection and the age of past due
 receivables and provides an allowance for doubtful receivables
 based on a review of all outstanding amounts at the period end. Bad
 debts are written-off when identified.

[0001193125-14-373828:notes:131]
Unanticipated
 changes in the liquidity or financial position of the
 Company’s customers may require revision to the allowances
 for doubtful accounts.

[0001193125-14-373828:notes:132]
Leases

[0001193125-14-373828:notes:133]
Payments made
 under operating leases are expensed on a straight-line basis over
 the lease term.

[0001193125-14-373828:notes:134]
Gains and
 losses on disposal are determined by comparing proceeds with
 carrying amounts and are included in operating income in the
 consolidated statements of operations.

[0001193125-14-373828:notes:135]
Fair
 value of financial instruments

[0001193125-14-373828:notes:136]
Fair value is
 defined as the exchange price that would be received for an asset
 or paid to transfer a liability (an exit price) in the principal or
 most advantageous market for the asset or liability in an orderly
 transaction between market participants on the measurement date. A
 fair value hierarchy is established which requires an entity to
 maximize the use of observable inputs and minimize the use of
 unobservable inputs for the valuation of an asset or liability as
 of the measurement date. The three levels of inputs that may be
 used to measure fair value are defined as follows:

[0001193125-14-373828:notes:137]
Level 1 inputs
 are quoted prices (unadjusted) in active markets for identical
 assets or liabilities.

[0001193125-14-373828:notes:138]
Level 2 inputs
 for similar assets and liabilities in active markets other than
 quoted prices included within Level 1 that are observable for the
 asset or liability, either directly or indirectly, for
 substantially the full term of the asset or liability.

[0001193125-14-373828:notes:139]
Level 3 inputs
 that are significant to the fair value measurement and unobservable
 (i.e. supported by little or no market activity), which require the
 reporting entity to develop its own valuation techniques and
 assumptions.

[0001193125-14-373828:notes:140]
The Company
 utilizes the market approach to measure fair value for its
 financial assets and liabilities. The market approach uses prices
 and other relevant information generated by market transactions
 involving identical or comparable assets or liabilities.

[0001193125-14-373828:notes:141]
The carrying
 amounts of certain financial instruments, which include cash and
 cash equivalents, trade accounts receivable, and trade accounts
 payable, approximate their fair values due to their short
 maturities. The carrying amounts of borrowings approximate their
 fair values as the applicable interest rate is based on market
 interest rates. The particular recognition methods adopted are
 disclosed in the individual policy statements associated with each
 item.

[0001193125-14-373828:notes:142]
Derivatives

[0001193125-14-373828:notes:143]
Derivatives are
 recognized on the consolidated balance sheets as other current
 assets or accrued expenses at fair value, based on the
 free-standing derivative instrument. The accounting for changes in
 the fair value of a derivative depends on the intended use of the
 derivative and the resulting designation and can either be
 designated as (1) a hedge of the fair value of a recognized
 asset or liability or of an unrecognized firm commitment
 (“fair value” hedge), (2) a hedge of a forecasted
 transaction or the variability of cash flows to be received or paid
 related to a recognized asset or liability (“cash flow”
 hedge) or (3) held for trading or not designated for hedge
 accounting (“free-standing derivative
 instrument”).

[0001193125-14-373828:notes:144]
Concentration of credit risk

[0001193125-14-373828:notes:145]
Financial
 instruments that potentially subject the Company to concentrations
 of credit risk consist of cash and cash equivalents, derivatives
 and accounts receivable.

[0001193125-14-373828:notes:146]
Cash and cash
 equivalents are maintained with several financial institutions.
 Deposits held with banks may exceed the amount of insurance
 provided on such deposits. Generally, these deposits may be
 redeemed upon demand and are maintained with financial institutions
 with reputable credit and therefore bear minimal credit risk. The
 Company seeks to mitigate its credit risks by spreading such risks
 across multiple counterparties and monitoring the risk profiles of
 these counterparties.

[0001193125-14-373828:notes:147]
The Company
 performs ongoing credit evaluations for credit worthiness of its
 customers and usually does not require collateral from its
 customers. Management has implemented a program to closely monitor
 near term cash collection and credit exposures to mitigate any
 material losses.

[0001193125-14-373828:notes:148]
Warranty
 provision

[0001193125-14-373828:notes:149]
Provisions for
 estimated expenses relating to product warranties are made at the
 time the products are sold using historical experience. Generally,
 this warranty is limited to workmanship and the Company’s
 liability is capped at the price of the product. The provisions
 will be adjusted when experience indicates an expected settlement
 will differ from initial estimates.

[0001193125-14-373828:notes:150]
Warranty cost
 allowances of $0.02 million, $0.02 million, and $0.1 million were
 recognized in the consolidated statements of operations for the
 years ended June 27, 2014, June 28, 2013 and
 June 29, 2012, respectively.

[0001193125-14-373828:notes:151]
Share-based compensation

[0001193125-14-373828:notes:152]
Share-based
 compensation is recognized in the consolidated financial statements
 based on grant-date fair value. The value of the portion of the
 award that is ultimately expected to vest is recognized as expense
 ratably over the requisite service period. The Company estimates
 the fair value of share-based awards utilizing the
 Black-Scholes-Merton (“BSM”) option-pricing model net
 of estimated forfeitures.

[0001193125-14-373828:notes:153]
Employee
 contribution plan

[0001193125-14-373828:notes:154]
The Company
 operates a defined contribution plan, known as a provident fund, in
 Fabrinet Thailand. The assets of this plan are in a separate
 trustee-administered fund. The provident fund is funded by matching
 payments from employees and by the subsidiary on a monthly basis.
 Current contributions to the provident fund are accrued and paid to
 the fund manager on a monthly basis. The Company sponsors the
 Fabrinet U.S. 401(k) Retirement Plan (the “401(k)
 Plan”), a Defined Contribution Plan under ERISA, at its
 Fabrinet USA, Inc. and FBN New Jersey Manufacturing, Inc.
 subsidiaries, which provides retirement benefits for its eligible
 employees through tax deferred salary deductions.

[0001193125-14-373828:notes:155]
Severance
 liabilities

[0001193125-14-373828:notes:156]
Under labor
 protection laws applicable in Thailand and under the Fabrinet
 Thailand employment policy, all employees of Fabrinet Thailand with
 more than 120 days of service are entitled to severance pay on
 forced termination or retrenchment or in the event that the
 employee reaches the retirement age of 55. The entitlement to
 severance pay is determined according to an employee’s
 individual employment tenure with the Company and is subject to a
 maximum benefit of 10 months of salary unless otherwise agreed upon
 in an employee’s employment contract. The Company accounts
 for this severance liability on an actuarial basis using the
 Projected Unit Credit Method, using the long-term Thai government
 bond yield as a discount rate. There are no separate plan assets
 held in respect of this liability.

[0001193125-14-373828:notes:157]
Annual
 leave

[0001193125-14-373828:notes:158]
Employee
 entitlements to annual leave are recognized when they accrue to the
 employee. On termination of employment, accrued employee
 entitlement to annual leave is paid in cash.

[0001193125-14-373828:notes:159]
New
 Accounting Pronouncements—not yet adopted by the
 Company

[0001193125-14-373828:notes:160]
In August 2014,
 The Financial Accounting Standards Board (FASB) issued Accounting
 Standard Update (ASU) no. 2014-15, “Presentation of Financial
 Statements—Going Concern (Subtopic 205-40): Disclosure of
 Uncertainties about an Entity’s Ability to Continue as a
 Going Concern”. The amendments require management to evaluate
 an entity’s ability to continue as a going concern; when
 relevant conditions and events, considered in the aggregate,
 indicate that it is probable that the entity will be unable to meet
 its obligations that become due within one year after the date that
 the financial statements are issued (or available to be issued).
 This applies to all entities and effective for fiscal beginning
 after December 15, 2016 and for annual periods and interim
 periods thereafter. The Company does not expect that the adoption
 of this guidance will have an effect on its consolidated financial
 statements.

[0001193125-14-373828:notes:161]
In June 2014,
 the FASB issued ASU No. 2014-12,
 “Compensation—Stock Compensation (Topic 718),
 Accounting for Share-Based Payments when the terms of an award
 provide that a performance target could be achieved after the
 requisite service period”. This ASU requires that a
 performance target that affects vesting, and that could be achieved
 after the requisite service period, be treated as a performance
 condition. As such, the performance target should not be reflected
 in estimating the grant date fair value of the award. This update
 further clarifies that compensation cost should be recognized in
 the period in which it becomes probable that the performance target
 will be achieved and should represent the compensation cost
 attributable to the period(s) for which the requisite service has
 already been rendered. The Company is currently evaluating the
 impact of adoption on this new guidance on its consolidated
 financial statements.

[0001193125-14-373828:notes:162]
In May 2014,
 the FASB issued ASU No. 2014-09, “Revenue from Contracts
 with Customers (Topic 606), issued as a new Topic, Accounting
 Standards Codification”. The core principle of this amendment
 is that an entity should recognize revenue to depict the transfer
 of promised goods or services to customers in an amount that
 reflects the consideration to which the entity expects to be
 entitled in exchange for those goods or services. This new guidance
 is effective for annual reporting periods beginning after
 December 15, 2016, including interim periods within that
 reporting period, with earlier adoption not being permitted. This
 new guidance can be adopted either retrospectively to each prior
 reporting period presented or as a cumulative-effect adjustment as
 of the date of adoption. The Company is currently assessing impact
 of adoption of this new guidance on its consolidated financial
 statements.

[0001193125-14-373828:notes:163]
In July 2013,
 the FASB issued ASU No. 2013-11, “Income Taxes (Topic
 740): Presentation of an Unrecognized Tax Benefit When a Net
 Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit
 Carryforward Exists”. This ASU provides guidance for netting
 of unrecognized tax benefits (UTBs) against a deferred tax asset
 for a loss or other carryforward that would apply in settlement of
 the uncertain tax positions. Under this new guidance, UTBs will be
 netted against all available same-jurisdiction loss or other tax
 carryforwards that would be utilized, rather than only against
 carryforwards that are created by the UTBs. This guidance is
 effective for fiscal years, and interim periods within those years,
 beginning after December 15, 2013. The Company does not expect
 that the adoption of this guidance will have an effect on its
 consolidated financial statements.

[0001193125-14-373828:notes:164]
In April 2013,
 the FASB issued ASU No. 2013-07, “Presentation of
 Financial Statements (Topic 205): Liquidation Basis of
 Accounting”. The amendments require an entity to prepare its
 financial statements using the liquidation basis of accounting when
 liquidation is imminent. The amendments require financial
 statements prepared using the liquidation basis of accounting to
 present relevant information about an entity’s expected
 resources in liquidation by measuring and presenting assets at the
 amount of the expected cash proceeds from liquidation. This
 guidance is effective for entities that determine liquidation is
 imminent during annual reporting periods beginning after
 December 15, 2013 and interim reporting periods therein. The
 Company does not expect that the adoption of this guidance will
 have an effect on its consolidated financial statements.

[0001193125-14-373828:notes:165]
In March 2013,
 the FASB issued ASU No. 2013-05, “Foreign Currency
 Matters (Topic 830): Parents’ Accounting for the Cumulative
 Translation Adjustment upon Derecognition of Certain Subsidiaries
 or Groups of Assets within a Foreign Entity or of an Investment in
 a Foreign Entity”. This ASU permits an entity to release
 cumulative translation adjustments into net income when a reporting
 entity (parent) ceases to have a controlling financial interest in
 a subsidiary or group of assets that is a business within a foreign
 entity. Accordingly, the cumulative translation adjustment should
 be released into net income only if the sale or transfer results in
 the complete or substantially complete liquidation of the foreign
 entity in which the subsidiary or group of assets had resided, or,
 if a controlling financial interest is no longer held. The guidance
 is effective for fiscal years beginning after December 15,
 2013, with early adoption being permitted. The Company does not
 expect that the adoption of this guidance will have an effect on
 its consolidated financial statements.

[0001193125-14-373828:notes:166]
In February
 2013, the FASB issued ASU No. 2013-04, “Liabilities
 (Topic 405): Obligations Resulting from Joint and Several Liability
 Arrangements for which the Total Amount of the Obligation is Fixed
 at the Reporting Date”. The guidance in this update requires
 an entity to measure obligations resulting from joint and several
 liability arrangements for which the total amount of the obligation
 within the scope of this guidance is fixed at the reporting date,
 as the sum of the following: (a) the amount the reporting
 entity agreed to pay on the basis of its arrangement among its
 co-obligors, and (b) any additional amount the reporting
 entity expects to pay on behalf of its co-obligors. The guidance
 also requires an entity to disclose the nature and amount of the
 obligation as well as other information about those obligations.
 This guidance is effective for fiscal years, and interim periods
 within those years, beginning after December 15, 2013. The
 Company does not expect that the adoption of this guidance will
 have an effect on its consolidated financial statements.

[0001193125-14-373828:notes:167]
Recently
 Adopted Accounting Pronouncements

[0001193125-14-373828:notes:168]
In January
 2013, the FASB issued ASU No. 2013-01, “Balance Sheet
 (Topic 210): Clarifying the Scope of Disclosure about Offsetting
 Assets and Liabilities”. The amendments clarify that the
 scope of Update 2011-11
 applies to derivatives accounted for in accordance with Topic 815,
 Derivatives and Hedging, including bifurcated embedded derivatives,
 repurchase agreements and reverse repurchase agreements, and
 securities borrowing and securities lending transactions that are
 either offset in accordance with Section 210-20-45 or
 Section 815-10-45 or subject to an enforceable master netting
 arrangement or similar agreement. This guidance is effective for
 fiscal years beginning on or after January 1, 2013, and
 interim periods within those annual periods. The Company did not
 have an effect on its consolidated financial statements from the
 adoption.

[0001193125-14-373828:notes:169]
In July 2012,
 the FASB issued ASU No. 2012-02,
 “Intangibles—Goodwill and Other (Topic 350): Testing
 Indefinite-Lived Intangible Assets for Impairment”. Under the
 amendments, an entity has the option first to assess qualitative
 factors to determine whether the existence of events and
 circumstances indicates that it is more likely than not that the
 indefinite-lived intangible asset is impaired. This guidance is
 effective for fiscal years beginning after September 15, 2012.
 Early adoption is permitted. The Company did not have an effect on
 its consolidated financial statements from the adoption.

[0001193125-14-373828:notes:170]
In December
 2011, the FASB issued the Accounting Standards Update
 No. 2011-11, “Balance Sheet (Topic 210):
 Disclosures about Offsetting Assets and Liabilities”. The
 amendments in this Update will enhance disclosures required by U.S.
 GAAP by requiring improved information about financial instruments
 and derivative instruments that are either (1) offset in
 accordance with either Section 210-20-45 or
 Section 815-10-45 or (2) subject to an enforceable master
 netting arrangement or similar agreement, irrespective of whether
 they are offset in accordance with either Section 210-20-45 or
 Section 815-10-45. Information about offsetting and related
 arrangements will enable users of an entity’s financial
 statements to understand the effect of those arrangements on an
 entity’s financial position, including the effect or
 potential effect of rights of setoff associated with certain
 financial instruments and derivative instruments in the scope of
 this Update. This guidance is effective for annual reporting
 periods beginning on or after January 1, 2013, and interim
 periods within those annual periods. The Company did not have an
 effect on its consolidated financial statements from the
 adoption.


## us-gaap:ScheduleOfUnrecognizedTaxBenefitsRollForwardTableTextBlock

[0001193125-14-373828:notes:171]
The following
 table indicates the changes to the Company’s uncertain income
 tax positions for the years ended June 27,
 2014, June 28, 2013 and June 29, 2012 included in
 other non-current liabilities.

[0001193125-14-373828:notes:172]
| (amount in thousands) |  | As of June 27, 2014 |  |  | As of June 28, 2013 |  |  | As of June 29, 2012 |  |
| Beginning balance |  | $ | 1,167 |  |  | $ | 1,124 |  |  | $ | 1,124 |  |
| Additions during the year |  |  | 510 |  |  |  | 358 |  |  |  | — |  |
| Reductions for tax positions of prior years |  |  | (809 | ) |  |  | (315 | ) |  |  | — |  |
| Ending balance |  | $ | 868 |  |  | $ | 1,167 |  |  | $ | 1,124 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-14-373828:notes:173]
| 14. | Employee benefit plans |

[0001193125-14-373828:notes:174]
The Company
 operates a defined contribution plan, known as a provident fund, in
 its Thailand subsidiary. The assets of this plan are in a separate
 trustee-administered fund. The provident fund is funded by matching
 payments from employees and by the subsidiary on a monthly basis.
 Current contributions to the provident fund are accrued and paid to
 the fund manager on a monthly basis. The Company’s
 contributions to the provident fund amounted to $2.1 million, $2.2
 million and $2.3 million in the years ended June 27,
 2014, June 28, 2013 and June 29, 2012,
 respectively.

[0001193125-14-373828:notes:175]
The Company
 sponsors the Fabrinet U.S. 401(k) Retirement Plan (the
 “401(k) Plan”), a Defined Contribution Plan under
 ERISA, at its Fabrinet USA, Inc. and FBN New Jersey Manufacturing,
 Inc. subsidiaries, which provides retirement benefits for its
 eligible employees through tax deferred salary deductions. The
 401(k) Plan allows employees to contribute up to 80% of their
 annual compensation, subject to annual contributions limits
 established by the Internal Revenue Service. The Company provides
 for a 100% match of employees’ contributions to the 401(k)
 Plan up to the first 6% of annual compensation. All matching
 contributions are made in cash and vest immediately. The
 Company’s matching contributions to the 401(k) Plan were $0.2
 million, $0.2 million and $0.2 million in the years ended
 June 27, 2014, June 28, 2013 and June 29, 2012,
 respectively.

[0001193125-14-373828:notes:176]
Executive
 incentive plan and employee performance bonuses

[0001193125-14-373828:notes:177]
For the year
 ended June 27, 2014, the Company maintained an executive
 incentive plan with quantitative objective, based on an achieving
 certain revenue and gross margin percentage target as well as
 qualitative objective, based on achieving individual performance
 goals for the fiscal year. For the year ended June 28, 2013,
 the Company maintained an executive incentive plan with
 quantitative objectives, based on achieving certain revenue and
 earnings per share milestones for the fiscal years. The Company did
 not maintain an executive incentive plan during the year ended
 June 29, 2012. During the years ended June 27,
 2014, June 28, 2013 and June 29, 2012, discretionary
 merit-based bonus awards were also available to Fabrinet’s
 non-executive employees.

[0001193125-14-373828:notes:178]
Bonus
 distributions to employees were $5.1 million, $3.7 million and $1.7
 million for the years ended June 27, 2014, June 28,
 2013 and June 29, 2012, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001193125-14-373828:notes:179]
| 4. | Earnings (loss) per ordinary share |

[0001193125-14-373828:notes:180]
Basic earnings
 (loss) per ordinary share is computed by dividing reported net
 income (loss) by the weighted average number of ordinary shares
 outstanding during each period. Diluted earnings (loss) per
 ordinary share is computed by dividing reported net income (loss)
 by the weighted average number of ordinary shares and dilutive
 ordinary equivalent shares outstanding during each period. Dilutive
 ordinary equivalent shares consist of share options and restricted
 share units. The earnings per ordinary share was calculated as
 follows:


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-14-373828:notes:181]
| 10. | Intangibles |

[0001193125-14-373828:notes:182]
The following
 tables present details of the Company’s
 intangibles:

[0001193125-14-373828:notes:183]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net |  |
| As of June 27, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 3,458 |  |  | $ | (3,386 | ) |  | $ | 72 |  |
| Total intangibles |  | $ | 3,458 |  |  | $ | (3,386 | ) |  | $ | 72 |  |

[0001193125-14-373828:notes:184]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net |  |
| As of June 28, 2013 |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 3,458 |  |  | $ | (3,294 | ) |  | $ | 164 |  |
| Total intangibles |  | $ | 3,458 |  |  | $ | (3,294 | ) |  | $ | 164 |  |

[0001193125-14-373828:notes:185]
The Company
 recorded amortization expense relating to intangibles of $0.1
 million, $0.2 million and $0.4 million for the years ended
 June 27, 2014, June 28, 2013 and June 29, 2012,
 respectively.


## us-gaap:ScheduleOfEffectiveIncomeTaxRateReconciliationTableTextBlock

[0001193125-14-373828:notes:186]
The
 reconciliation between the Company’s taxes that would arise
 by applying the statutory tax rate of the country of the
 Company’s principal operations, Thailand, to the
 Company’s effective tax charge is shown below:

[0001193125-14-373828:notes:187]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 27, 2014 |  |  | June 28, 2013 |  |  | June 29, 2012 |  |
| Income (loss) before income taxes |  | $ | 93,170 |  |  | $ | 71,909 |  |  | $ | (58,435 | ) |
| Tax expense (benefit) calculated at a corporate income tax rate of 20% (2013: 23% and 2012: 30%) |  |  | 18,634 |  |  |  | 16,539 |  |  |  | (17,531 | ) |
| Effect of income taxes from locations with tax rates different from Thailand |  |  | (2 | ) |  |  | (457 | ) |  |  | (551 | ) |
| (Income) loss not subject to tax (1) |  |  | (15,648 | ) |  |  | (12,728 | ) |  |  | 15,240 |  |
| (Reversal of) income tax on unremitted earnings |  |  | (259 | ) |  |  | 466 |  |  |  | 552 |  |
| Effect of tax rate change |  |  | (662 | ) |  |  | (303 | ) |  |  | 1,263 |  |
| Effect of foreign exchange rate adjustment |  |  | (380 | ) |  |  | (90 | ) |  |  | (993 | ) |
| Insurance proceeds from equipment claim due to flooding |  |  | — |  |  |  | (516 | ) |  |  | — |  |
| Reversal of reserve fixed assets damaged from flooding |  |  | (251 | ) |  |  | — |  |  |  | — |  |
| Others |  |  | 7 |  |  |  | 29 |  |  |  | 52 |  |
| Corporate income tax expense (benefit) |  | $ | 1,439 |  |  | $ | 2,940 |  |  | $ | (1,968 | ) |

[0001193125-14-373828:notes:188]
| (1) | Income not subject to tax relates to income earned in the Cayman Islands, income subject to an investment promotion privilege for Building 5 and Building 6. Income (loss) not subject to tax per ordinary share on a diluted basis (in dollars) was $0.44, $0.37and $(0.44) for the years ended June 27, 2014, June 28, 2013 and June 29, 2012, respectively. |


## us-gaap:ShareBasedCompensationArrangementByShareBasedPaymentAwardOptionsVestedAndExpectedToVestOutstandingAndExercisableTableTextBlock

[0001193125-14-373828:notes:189]
The following
 summarizes information for share options outstanding as of
 June 27, 2014 under the share options plan:

[0001193125-14-373828:notes:190]
|  |  | Number of Shares Underlying Options |  |  | Exercise Price Per Share |  |  | Weighted Average Remaining Contractual Life (years) |  |  | Aggregate Intrinsic Value |  |
|  |  |  | 525 |  |  |  | 4.25 |  |  |  | 0.17 |  |  |  |  |  |
|  |  |  | 500 |  |  |  | 4.75 |  |  |  | 0.42 |  |  |  |  |  |
|  |  |  | 2,100 |  |  |  | 5.00 |  |  |  | 0.63 |  |  |  |  |  |
|  |  |  | 1,400 |  |  |  | 5.25 |  |  |  | 0.86 |  |  |  |  |  |
|  |  |  | 9,290 |  |  |  | 5.75 |  |  |  | 2.22 |  |  |  |  |  |
|  |  |  | 8,368 |  |  |  | 13.77 |  |  |  | 3.16 |  |  |  |  |  |
|  |  |  | 444,878 |  |  |  | 16.83 |  |  |  | 3.30 |  |  |  |  |  |
|  |  |  | 30,000 |  |  |  | 15.05 |  |  |  | 3.36 |  |  |  |  |  |
|  |  |  | 26,844 |  |  |  | 25.50 |  |  |  | 3.55 |  |  |  |  |  |
|  |  |  | 7,400 |  |  |  | 26.16 |  |  |  | 3.61 |  |  |  |  |  |
|  |  |  | 10,125 |  |  |  | 23.62 |  |  |  | 3.85 |  |  |  |  |  |
|  |  |  | 97,968 |  |  |  | 15.16 |  |  |  | 4.14 |  |  |  |  |  |
|  |  |  | 193,521 |  |  |  | 14.12 |  |  |  | 4.37 |  |  |  |  |  |
|  |  |  | 25,160 |  |  |  | 19.36 |  |  |  | 4.62 |  |  |  |  |  |
|  |  |  | 5,550 |  |  |  | 18.60 |  |  |  | 4.68 |  |  |  |  |  |
|  |  |  | 2,261 |  |  |  | 12.83 |  |  |  | 4.87 |  |  |  |  |  |
| Options outstanding |  |  | 865,890 |  |  |  |  |  |  |  | 3.68 |  |  |  | 3,924 |  |
| Options exercisable |  |  | 666,305 |  |  |  |  |  |  |  | 3.57 |  |  |  | 2,922 |  |


## us-gaap:ScheduleOfDeferredTaxAssetsAndLiabilitiesTableTextBlock

[0001193125-14-373828:notes:191]
The
 Company’s deferred tax assets and deferred tax liabilities at
 each balance sheet date are as follows:

[0001193125-14-373828:notes:192]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 27, 2014 |  |  | June 28, 2013 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Depreciation |  | $ | 1,777 |  |  | $ | 1,684 |  |
| Severance liability |  |  | 796 |  |  |  | 680 |  |
| Reserve and allowance |  |  | 1,597 |  |  |  | 909 |  |
| Allowance for tax loss carried forward |  |  | — |  |  |  | 983 |  |
| Non-deductible flood loss expenses |  |  | — |  |  |  | 540 |  |
| Others |  |  | — |  |  |  | 70 |  |
| Total |  | $ | 4,170 |  |  | $ | 4,866 |  |

[0001193125-14-373828:notes:193]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 27, 2014 |  |  | June 28, 2013 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Deferred cost of service and expense |  | $ | (23 | ) |  | $ | (24 | ) |
| Insurance proceeds from equipment claim due to flooding |  |  | — |  |  |  | (540 | ) |
| Deferred tax from unremitted earning |  |  | (1,838 | ) |  |  | (1,941 | ) |
| Others |  |  | (13 | ) |  |  | — |  |
| Total |  |  | (1,874 | ) |  |  | (2,505 | ) |
| Net |  | $ | 2,296 |  |  | $ | 2,361 |  |

[0001193125-14-373828:notes:194]
Current deferred
 income tax assets and liabilities and non-current deferred income
 tax assets and liabilities are offset when the income taxes relate
 to the same tax jurisdiction. The following amounts are shown in
 the consolidated balance sheets:

[0001193125-14-373828:notes:195]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 27, 2014 |  |  | June 28, 2013 |  |
| Deferred income tax assets—current |  | $ | 1,561 |  |  | $ | 1,397 |  |
| Deferred income tax liabilities—current |  |  | — |  |  |  | — |  |
| Current deferred income tax—net |  |  | 1,561 |  |  |  | 1,397 |  |
| Deferred income tax assets—non current |  |  | 1,775 |  |  |  | 2,116 |  |
| Deferred income tax liabilities—non current |  |  | (1,040 | ) |  |  | (1,152 | ) |
| Non-current deferred income tax—net |  |  | 735 |  |  |  | 964 |  |
| Net deferred income tax assets |  | $ | 2,296 |  |  | $ | 2,361 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-14-373828:notes:196]
Share-based
 compensation expense was recorded in the consolidated statements of
 operations as follows:

[0001193125-14-373828:notes:197]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 27, 2014 |  |  | June 28, 2013 |  |  | June 29, 2012 |  |
| Cost of revenue |  | $ | 1,182 |  |  | $ | 1,105 |  |  | $ | 1,546 |  |
| Selling, general and administrative expense |  |  | 4,365 |  |  |  | 3,995 |  |  |  | 3,103 |  |
| Total share-based compensation expense |  | $ | 5,547 |  |  | $ | 5,100 |  |  | $ | 4,649 |  |


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001193125-14-373828:notes:198]
Fair
 Value—The fair value of Fabrinet’s share options
 granted to employees for the years ended June 27,
 2014, June 28, 2013 and June 29, 2012 was estimated
 using the following weighted-average assumptions:

[0001193125-14-373828:notes:199]
|  |  | Years Ended |  |
|  |  | June 27, 2014 |  |  | June 28, 2013 |  |  | June 29, 2012 |  |
| Dividend yield |  |  | — |  |  |  | — |  |  |  | — |  |
| Expected volatility |  |  | — |  |  |  | — |  |  |  | 61.3 | % |
| Risk-free rate of return (percent) |  |  | — |  |  |  | — |  |  |  | 0.90 | % |
| Expected term (in years) |  |  | — |  |  |  | — |  |  |  | 4.36 |  |


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001193125-14-373828:notes:200]
| 19. | Income (expense) related to flooding |

[0001193125-14-373828:notes:201]
The Company
 suspended production at all of its manufacturing facilities in
 Thailand from October 17, 2011 through November 14, 2011
 due to severe flooding in Thailand. The Company never resumed, and
 has permanently ceased, production at its Chokchai facility. The
 Company submitted claims for losses to its insurance companies, all
 of which have been settled as of fiscal year 2014. During the
 fiscal year 2014, the Company recognized $45.2 million as income
 related to flooding towards full and final settlement of the
 Company’s owned and consigned equipment and inventory claims.
 This income was offset by the recognition of $0.5 million of other
 expenses in connection with write-offs of advance payments to a
 customer due to flood losses.

[0001193125-14-373828:notes:202]
In fiscal year
 2013, the Company received from our insurers an interim payment of
 $16.2 million against our claim for owned inventory losses and
 owned equipment losses, a payment of $13.1 million as full and
 final settlement of our claim for business interruption losses, and
 a payment of $0.1 million as full and final settlement of our claim
 for damage to our buildings at Pinehurst. This income was offset by
 the recognition of $2.3 million of additional expenses in
 connection with liabilities to third parties due to flood
 losses.

[0001193125-14-373828:notes:203]
During fiscal
 year 2014, the Company made a cash payment of $5.2 million and
 transferred equipment, with an aggregate value of $2.3 million, to
 a customer towards full and final settlement for any and all
 flood-related losses in accordance with the settlement agreement
 entered into during fiscal year 2013 with such customer. In
 addition, the Company fulfilled its obligations to a
 customer’s insurers by making a payment of $2.2 million for
 full and final settlement of the Company’s liability to such
 insurer for damages to customer-owned inventory, which occurred
 during the flooding in accordance with the settlement agreement
 entered into during fiscal year 2013. The Company also made a cash
 payment of $0.1 million towards the other flood-related settlements
 during the year ended June 27, 2014.

[0001193125-14-373828:notes:204]
During fiscal
 year 2013, the Company entered into settlement agreements with each
 of its customers impacted by the flooding regarding the
 Company’s liability for the customers’ losses as a
 result of the flooding. In connection with such settlement
 agreements, during the fiscal year 2013, the Company paid an
 aggregate of $37.7 million to customers, transferred equipment
 purchased on behalf of customers to those customers with an
 aggregate value of $5.9 million and reduced net accounts receivable
 from customers by aggregate of $5.7 million. As of June 28,
 2013, the Company’s liability to two of its impacted
 customers for any and all flood-related losses had been satisfied
 in full.

[0001193125-14-373828:notes:205]
During fiscal
 year 2013, the Company also entered into a settlement agreement
 with a customer’s insurers to resolve a subrogation claim
 related to recovery proceeds paid by such insurer to the customer
 for damages to customer-owned inventory, which occurred during the
 flooding. Under the terms of the settlement agreement, the Company
 agreed to pay $6.5 million to the insurer, to be paid in three
 installments. As of June 28, 2013, the Company had paid an
 aggregate of $4.3 million. The third and final payment of
 approximately $2.2 million was made in July 2013.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-14-373828:notes:206]
| 3. | Income taxes |

[0001193125-14-373828:notes:207]
Cayman
 Islands

[0001193125-14-373828:notes:208]
Fabrinet is
 domiciled in the Cayman Islands. Under the current laws of Cayman
 Islands, Fabrinet is not subject to tax in the Cayman Islands on
 income or capital gains. Fabrinet has received this undertaking for
 a 20-year period ending August 24, 2019, and after the
 expiration date, Fabrinet can make a request for renewal with the
 office of the Clerk of the Cabinet for another 20 years.

[0001193125-14-373828:notes:209]
Income of the
 Company exempted from corporate income tax in the Cayman Islands
 amounted to $73.0 million, $50.3 million and $0 in the years
 ended June 27, 2014, June 28, 2013 and June 29,
 2012, respectively.

[0001193125-14-373828:notes:210]
Thailand

[0001193125-14-373828:notes:211]
Fabrinet Co.,
 Ltd. is where the majority of the Company’s operations and
 production takes place. The Company is not subject to tax for the
 period from July 2010 through June 2015 on income generated from
 the manufacture of products at Pinehurst Building 5, and from July
 2012 through June 2020 on income generated from the manufacture of
 products at Pinehurst Building 6. Such preferential tax treatment
 is contingent on, among other things, the export of the
 Company’s customers’ products out of Thailand and the
 Company’s agreement not to move Fabrinet Thailand’s
 manufacturing facilities out of its current province in Thailand
 for at least 15 years. In addition, in December 2011, the
 Thailand Revenue Department announced a reduction in corporate
 income tax rates for tax periods beginning on or after
 January 1, 2012. As a result of the announcement, enacted
 corporate income tax rates for Fabrinet Thailand was reduced from
 30% in fiscal year 2012 to 23% in fiscal year 2013 and to 20% in
 fiscal year 2014 and fiscal year 2015.

[0001193125-14-373828:notes:212]
People’s Republic of China

[0001193125-14-373828:notes:213]
CASIX has been
 granted a tax privilege to reduce its corporate income tax rate
 from 25% to 15%. This privilege is retroactive to January 1,
 2011 and valid until December 31, 2013, subject to renewal at
 the end of each three-year period. The Company is in the process of
 preparing an application to renew this tax privilege and plan to
 submit it in fiscal year 2015. As a result, the corporate income
 tax rate for Casix has changed to 25% since January
 2014.

[0001193125-14-373828:notes:214]
As of
 June 27, 2014, there were no tax losses carried forward due to
 severe flooding in Thailand during October and November,
 2011.

[0001193125-14-373828:notes:215]
Current
 deferred income tax assets and liabilities and non-current deferred
 income tax assets and liabilities are offset when the income taxes
 relate to the same tax jurisdiction. The following amounts are
 shown in the consolidated balance sheets:

[0001193125-14-373828:notes:216]
Income tax
 liabilities have not been established for withholding tax and other
 taxes that would be payable on the unremitted earnings of Fabrinet
 Thailand. Such amounts of Fabrinet Thailand are permanently
 reinvested; unremitted earnings for Fabrinet Thailand totaled $37.2
 million and $25.4 million as of June 27, 2014 and
 June 28, 2013, respectively. Unrecognized deferred tax
 liabilities for such unremitted earnings were $2.6 million and $2.3
 million as of June 27, 2014 and June 28, 2013,
 respectively.

[0001193125-14-373828:notes:217]
Deferred tax
 liabilities of $1.8 million and $1.9 million have been established
 for withholding tax on the unremitted earnings of CASIX, which
 included in non-current deferred tax liability as of June 27,
 2014 and June 28, 2013, respectively.

[0001193125-14-373828:notes:218]
Uncertain
 income tax positions

[0001193125-14-373828:notes:219]
Interest and
 penalties related to uncertain tax positions are recognized in
 income tax expense. The Company had approximately $0.04 million and
 $0.7 million of accrued interest and penalties related to uncertain
 tax positions on the consolidated balance sheets as of
 June 27, 2014 and June 28, 2013, respectively. The
 Company recorded (reversed) interest and penalties of ($0.6
 million), ($0.1 million) and $0.2 million for the years ended
 June 27, 2014, June 28, 2013 and June 29, 2012,
 respectively, in the consolidated statements of operations. With
 regard to the Thailand jurisdiction, tax years 2009 through 2013
 remain open to examination by the local authorities.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-14-373828:notes:220]
| 13. | Share-based compensation |

[0001193125-14-373828:notes:221]
In determining
 the grant date fair value of equity awards, the Company is required
 to make estimates of the fair value of Fabrinet’s ordinary
 shares, expected dividends to be issued, expected volatility of
 Fabrinet’s ordinary shares, expected forfeitures of the
 awards, risk free interest rates for the expected term of the
 awards, expected terms of the awards, and the vesting period of the
 respective awards. Forfeitures are estimated at the time of grant
 and revised if necessary in subsequent periods if actual
 forfeitures differ from those estimates.

[0001193125-14-373828:notes:222]
The Company did
 not capitalize any share-based compensation expense as part of any
 asset costs during the years ended June 27,
 2014, June 28, 2013 and June 29, 2012.

[0001193125-14-373828:notes:223]
Share-based award activity

[0001193125-14-373828:notes:224]
Share options
 have been granted to directors and employees. As of June 27,
 2014, there were 13,815 share options outstanding under the Amended
 and Restated 1999 Share Option Plan (the “1999 Plan”).
 Additional option grants may not be made under the 1999
 Plan.

[0001193125-14-373828:notes:225]
In March 2010,
 Fabrinet’s shareholders adopted the 2010 Performance
 Incentive Plan (the “2010 Plan”). On December 20,
 2010 and December 20, 2012, the 2010 Plan was amended to
 increase the number of shares reserved for issuance. As of
 June 27, 2014, there were an aggregate of 852,075 share
 options outstanding, 762,295 restricted share units outstanding and
 3,528,778 ordinary shares available for future grant under the 2010
 Plan. The 1999 Plan and 2010 Plan are collectively referred to as
 the “Share Option Plans”.

[0001193125-14-373828:notes:226]
Share
 options

[0001193125-14-373828:notes:227]
Fabrinet’s board of directors has the authority to
 determine the type of option and the number of shares subject to an
 option. Options generally vest and become exercisable over four
 years and expire, if not exercised, within 7 years of the grant
 date. In the case of a grantee’s first grant, 25 percent of
 the underlying shares subject to an option vest 12 months after the
 vesting commencement date and 1/48 of the underlying shares vest
 monthly over each of the subsequent 36 months. In the case of any
 additional grants to a grantee, 1/48 of the underlying shares
 subject to an option vest monthly over four years, commencing one
 month after the vesting commencement date.

[0001193125-14-373828:notes:228]
The fair value
 of each grant of stock options was determined by the Company using
 the methods and assumptions discussed below. Each of these inputs
 is subjective and generally requires significant judgment and
 management estimate to determine.

[0001193125-14-373828:notes:229]
The total fair
 value of shares vested during the years ended June 27,
 2014, June 28, 2013, and June 29, 2012 was $2.0
 million, $2.4 million, and $2.4 million, respectively. The total
 intrinsic value of options exercised during the years ended
 June 27, 2014, June 28, 2013, and June 29, 2012
 was $2.2 million, $0.8 million, and $3.3 million, respectively. In
 conjunction with these exercises, there was no tax benefit realized
 by the Company due to the fact that it is exempted from income tax.
 The amount of cash received from the exercise of share options was
 $4.6 million during the year ended June 27, 2014.

[0001193125-14-373828:notes:230]
Valuation
 Method—The Company estimated the fair value of
 Fabrinet’s ordinary shares to be used in the
 Black-Scholes-Merton (“BSM”) option-pricing formula by
 taking into consideration a number of assumptions.

[0001193125-14-373828:notes:231]
Expected
 Dividend—The Company used zero as an annualized dividend
 yield since it did not anticipate paying any cash dividends in the
 near future.

[0001193125-14-373828:notes:232]
Expected
 Volatility—As the Company did not have a sufficient
 trading history to use the volatility of Fabrinet’s ordinary
 shares, management based its expected volatility on a comparable
 industry index as a reasonable measure of expected
 volatility.

[0001193125-14-373828:notes:233]
Risk-Free
 Interest Rate—The Company based the risk-free interest
 rate on the implied yield currently available on U.S. Treasury
 zero-coupon issues with a remaining term equivalent to the expected
 term of the option.

[0001193125-14-373828:notes:234]
Expected
 Term—Expected terms used in the BSM option-pricing
 formula represent the periods that Fabrinet’s share options
 are expected to be outstanding and are determined based on the
 Company’s historical experience of similar awards, giving
 consideration to the contractual terms of the share options,
 vesting schedules and expectations of future employee
 behavior.

[0001193125-14-373828:notes:235]
Vesting
 Period—Fabrinet’s share options generally vest and
 become exercisable over a four-year period, and expire seven years
 from the date of grant. For an initial grant, 25 percent of the
 underlying shares subject to an option vest 12 months after the
 vesting commencement date and 1/48 of the underlying shares vest
 monthly over each of the subsequent 36 months. In the case of any
 additional grants to an optionee, 1/48 of the underlying shares
 subject to an option vest monthly over four years, commencing one
 month after the vesting commencement date.

[0001193125-14-373828:notes:236]
As of
 June 27, 2014, there was $0.2 million of unrecognized
 compensation cost related to share options under the Share Option
 Plans that is expected to be recognized over a weighted-average
 period of 1.14 years.

[0001193125-14-373828:notes:237]
Restricted
 share units

[0001193125-14-373828:notes:238]
Restricted
 share units are one type of share-based award that may be granted
 under the 2010 Plan. Restricted share units granted to non-employee
 directors generally cliff vest 100% on the first of January,
 approximately one year from the grant date, provided the director
 continues to serve through such date. Restricted share units
 granted to employees generally vest in four equal installments over
 four years on each anniversary of the vesting commencement
 date.

[0001193125-14-373828:notes:239]
The following
 table summarizes restricted share unit activity:

[0001193125-14-373828:notes:240]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 24, 2011 |  |  | 25,900 |  |  | $ | 21.62 |  |  |  |  |  |
| Granted |  |  | 211,266 |  |  | $ | 14.37 |  |  | $ | 14.37 |  |
| Issued |  |  | (25,900 | ) |  | $ | 21.62 |  |  |  |  |  |
| Forfeited |  |  | (42,991 | ) |  | $ | 14.07 |  |  |  |  |  |
| Balance as of June 29, 2012 |  |  | 168,275 |  |  | $ | 14.44 |  |  |  |  |  |
| Granted |  |  | 468,387 |  |  | $ | 12.42 |  |  | $ | 12.42 |  |
| Issued |  |  | (71,880 | ) |  | $ | 14.10 |  |  |  |  |  |
| Forfeited |  |  | (19,114 | ) |  | $ | 12.78 |  |  |  |  |  |
| Balance as of June 28, 2013 |  |  | 545,668 |  |  | $ | 12.81 |  |  |  |  |  |
| Granted |  |  | 479,894 |  |  | $ | 15.37 |  |  | $ | 15.37 |  |
| Issued |  |  | (184,773 | ) |  | $ | 12.98 |  |  |  |  |  |
| Forfeited |  |  | (78,494 | ) |  | $ | 14.25 |  |  |  |  |  |
| Balance as of June 27, 2014 |  |  | 762,295 |  |  | $ | 14.23 |  |  |  |  |  |

[0001193125-14-373828:notes:241]
The total fair
 value of restricted share units vested during the year ended
 June 27, 2014, June 28, 2013 and June 29, 2012
 was $2.4 million, $1.0 million and $0.6 million,
 respectively. The aggregate intrinsic value of restricted share
 units outstanding as of June 27, 2014 was
 $15.7 million.

[0001193125-14-373828:notes:242]
As of
 June 27, 2014, there was $4.5 million of unrecognized
 share-based compensation expense related to restricted share units
 under the 2010 Plan that is expected to be recorded over a
 weighted-average period of 2.76 years.

[0001193125-14-373828:notes:243]
For year ended
 June 27, 2014 and June 28, 2013, the Company withheld an
 aggregate of 18,403 shares and 1,930 shares,
 respectively, upon the vesting of restricted share units, based
 upon the closing share price on the vesting date to settle the
 employees’ minimum statutory obligation for the applicable
 income and other employment taxes. For fiscal year 2014 and 2013,
 the Company then remitted cash of $0.3 million and
 $0.02 million, respectively, to the appropriate taxing
 authorities, and presented it in a financing activity within the
 consolidated statements of cash flows. The payment had the effect
 on shares issued by the Company as it reduced the number of shares
 that would have been issued on the vesting date and was recorded as
 a reduction of additional paid-in capital.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-14-373828:notes:244]
| 17. | Business segments and geographic information |

[0001193125-14-373828:notes:245]
Operating
 segments are defined as components of an enterprise for which
 separate financial information is available that is evaluated
 regularly by the chief operating decision maker in deciding how to
 allocate resources and in assessing performance. The
 Company’s chief operating decision maker is Fabrinet’s
 chief executive officer. As of June 27,
 2014, June 28, 2013 and June 29, 2012, the Company
 operated and internally managed a single operating segment.
 Accordingly, the Company does not accumulate discrete information
 with respect to separate product lines and does not have separate
 reportable segments.

[0001193125-14-373828:notes:246]
Total revenues
 are attributed to a particular geographic area based on the bill-to
 location of the customer.

[0001193125-14-373828:notes:247]
As of
 June 27, 2014 and June 28, 2013, the Company had
 approximately $0.3 million and $0.4 million of long-lived assets
 based in North America, with the substantial remainder of assets
 based in Asia-Pacific.

[0001193125-14-373828:notes:248]
Significant customers

[0001193125-14-373828:notes:249]
Accounts
 receivable from individual customers that were equal to or greater
 than 10% of accounts receivable as of June 27,
 2014, June 28, 2013, and June 29, 2012,
 respectively, were as follows:

[0001193125-14-373828:notes:250]
|  |  | Years Ended |  |
|  |  | June 27, 2014 |  |  | June 28, 2013 |  |  | June 29, 2012 |  |
| JDS Uniphase Corporation |  |  | 23 | % |  |  | 17 | % |  |  | 17 | % |
| Oclaro, Inc. (1) |  |  | 14 | % |  |  | 31 | % |  |  | 30 | % |
| Valeo |  |  | 10 | % |  |  | * | (2) |  |  | * | (2) |
| EMCORE Corporation |  |  | * | (2) |  |  | * | (2) |  |  | 12 | % |

[0001193125-14-373828:notes:251]
|  | (1) | Includes revenue of Opnext, Inc., which was acquired by Oclaro, Inc. in July 2012. |

[0001193125-14-373828:notes:252]
|  | (2) | Less than 10% of total revenue / total accounts receivable. |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-14-373828:notes:253]
| 16. | Commitments and contingencies |

[0001193125-14-373828:notes:254]
Bank
 guarantees

[0001193125-14-373828:notes:255]
As of
 June 27, 2014 and June 28, 2013, there were outstanding
 bank guarantees given by banks on behalf of Fabrinet Thailand for
 electricity usage and other normal business amounting to $0.3
 million and $0.3 million, respectively.

[0001193125-14-373828:notes:256]
Operating
 lease commitments

[0001193125-14-373828:notes:257]
The Company
 leases a portion of its capital equipment and certain land and
 buildings for its facilities in China and New Jersey under
 operating lease arrangements that expire in various years through
 2020. Rental expense under these operating leases amounted to $0.8
 million, $0.8 million and $1.8 million for the years ended
 June 27, 2014, June 28, 2013 and June 29, 2012,
 respectively.

[0001193125-14-373828:notes:258]
Purchase
 obligations

[0001193125-14-373828:notes:259]
Purchase
 obligations represent legally-binding commitments to purchase
 inventory and other commitments made in the normal course of
 business to meet operational requirements. Although open purchase
 orders are considered enforceable and legally binding, their terms
 generally give the Company the option to cancel, reschedule and/or
 adjust its requirements based on its business needs prior to the
 delivery of goods or performance of services. Obligations to
 purchase inventory and other commitments are generally expected to
 be fulfilled within one year.

[0001193125-14-373828:notes:260]
As of
 June 27, 2014, there were no outstanding capital expenditure
 commitments.

[0001193125-14-373828:notes:261]
Indemnification of directors and
 officers

[0001193125-14-373828:notes:262]
Cayman Islands
 law does not limit the extent to which a company’s memorandum
 and articles of association may provide for indemnification of
 directors and officers, except to the extent any such provision may
 be held by the Cayman Islands courts to be contrary to public
 policy, such as to provide indemnification against civil fraud or
 the consequences of committing a crime. Fabrinet’s amended
 and restated memorandum and articles of association provide for
 indemnification of directors and officers for actions, costs,
 charges, losses, damages and expenses incurred in their capacities
 as such, except that such indemnification does not extend to any
 matter in respect of any fraud or dishonesty that may attach to any
 of them.

[0001193125-14-373828:notes:263]
In accordance
 with Fabrinet’s form of indemnification agreement for its
 directors and officers, Fabrinet has agreed to indemnify its
 directors and officers against certain liabilities and expenses
 incurred by such persons in connection with claims by reason of
 their being such a director or officer. Fabrinet maintains a
 director and officer liability insurance policy that may enable it
 to recover a portion of any future amounts paid under the
 indemnification agreements.

[0001193125-14-373828:notes:264]
Contingent
 liability

[0001193125-14-373828:notes:265]
In the first
 week of October 2013, the Company authorized a customer to return a
 number of units of its product manufactured at the Company’s
 Pinehurst facility, due to functional failure. After investigation,
 the Company found that the affected products were produced during
 the first quarter of fiscal year 2014. On March 28, 2014, the
 Company entered into a settlement agreement with the customer for
 the losses as a result of the product failure. The settled amount
 was $0.5 million and recorded in the consolidated statement of
 operations for the year ended June 27, 2014.


## us-gaap:ScheduleOfAmountsRecognizedInBalanceSheetTableTextBlock

[0001193125-14-373828:notes:266]
The amount
 recognized in the consolidated balance sheets under non-current
 liabilities was determined as follows:

[0001193125-14-373828:notes:267]
| (amount in thousands) |  | As of June 27, 2014 |  |  | As of June 28, 2013 |  |
| Present value of defined benefit obligation |  | $ | 4,453 |  |  | $ | 4,382 |  |
| Total |  | $ | 4,453 |  |  | $ | 4,382 |  |


## fn:AllowanceForDoubtfulAccountsTextBlock

[0001193125-14-373828:notes:268]
| 7. | Allowance for doubtful accounts |


## fn:ExpensesRelatedToReductionInWorkforceDisclosureTextBlock

[0001193125-14-373828:notes:269]
| 20. | Expenses related to reduction in workforce |

[0001193125-14-373828:notes:270]
As part of the
 Company’s ongoing efforts to achieve greater efficiencies in
 all areas of its business, during the year ended June 28,
 2013, the Company implemented a reduction in workforce and incurred
 expenses of approximately $2.1 million, which represented severance
 and benefits costs incurred for the termination of approximately
 180 employees in accordance with contractual obligations and local
 regulations.

[0001193125-14-373828:notes:271]
Subsequently on
 October 10, 2014, the Company implemented a reduction in
 workforce and incurred expenses of approximately $1.0 million,
 which represented severance and benefits costs incurred for the
 termination of approximately 100 employees in accordance with
 contractual obligations and local regulations. The Company will
 record this expense in the fiscal year 2015.


## fn:SubsidiaryDisclosureTextBlock

[0001193125-14-373828:notes:272]
| 21. | Principal subsidiaries |

[0001193125-14-373828:notes:273]
Fabrinet’s subsidiaries are:

[0001193125-14-373828:notes:274]
| Name |  | Business |  | Country of Incorporation |  | Percent interest |  |
| Fabrinet Co., Ltd. |  | Manufacturing and assembly |  | Thailand |  |  | 99.99 |  |
| Fabrinet USA, Inc. |  | Marketing and administrative support services |  | United States of America (California) |  |  | 100 |  |
| FBN New Jersey Manufacturing, Inc. |  | Manufacturing and assembly |  | United States of America (Delaware) |  |  | 100 |  |
| Fabrinet China Holdings |  | Holding company |  | Mauritius Island |  |  | 100 |  |
| CASIX Inc. (a wholly-owned subsidiary of Fabrinet China Holdings) |  | Manufacturing and assembly |  | People’s Republic of China |  |  | 100 |  |
| Fabrinet Pte., Ltd. |  | Sales and administrative support services and supply chain sourcing center |  | Singapore |  |  | 100 |  |

[0001193125-14-373828:notes:275]
Fabrinet AB has
 liquidated on May 2, 2014.


## fn:AccruedSeveranceBenefitsDisclosureTextBlock

[0001193125-14-373828:notes:276]
| 12. | Severance liabilities |
