# FN 8-K — 0001193125-14-373872 filed 2014-10-16

## item codes, every 8-K on or before 2014-10-16

- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2014-10-16

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-14-373872:8k_2_02:1]
EX-99.1
2
d792064dex991.htm
EX-99.1

[0001193125-14-373872:8k_2_02:2]
EX-99.1

[0001193125-14-373872:8k_2_02:3]
Exhibit 99.1

[0001193125-14-373872:8k_2_02:4]
Fabrinet Announces Fourth Quarter and Fiscal Year 2014 Financial Results

[0001193125-14-373872:8k_2_02:5]
BANGKOK, Thailand – October 16, 2014 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical,
electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for the fourth quarter and fiscal year ended June 27, 2014.

[0001193125-14-373872:8k_2_02:6]
Fabrinet reported total revenue of $160.1 million for the fourth quarter of fiscal year 2014, an increase of less than 1% compared to total revenue of $159.9
million for the comparable period in fiscal year 2013. During the fourth quarter the Company concluded that certain consignment sales did not qualify for revenue recognition in accordance with the Company’s accounting policies. This was due to
a lack of clarity in the associated contracts with respect to terms related to delivery, risk of loss and title transfer. The financial impact of these consignment sales was $16.5 million and was excluded from the reported revenue in the fourth
quarter of fiscal year 2014. This amount will become recognizable as revenue once the goods have been shipped in fiscal year 2015. GAAP net income for the fourth quarter of fiscal year 2014 was $10.3 million, or $0.29 per diluted share, compared to
GAAP net income of $15.1 million, or $0.43 per diluted share, in the fourth quarter of fiscal year 2013. Non-GAAP net income in the fourth quarter of fiscal 2014 was $12.1 million, or $0.34 per diluted share, a decrease of 2.4% compared to non-GAAP
net income of $12.4 million, or $0.35 per diluted share, in the same period a year ago.

[0001193125-14-373872:8k_2_02:7]
For fiscal year 2014, Fabrinet reported total revenue of $677.9
million, an increase of 5.7% compared to total revenue of $641.5 million for fiscal year 2013. GAAP net income for fiscal year 2014 was $91.7 million, or $2.58 per diluted share, compared to GAAP net income of $69.0 million, or $1.98 per diluted
share, in fiscal year 2013. Non-GAAP net income in fiscal year 2014 was $54.6 million, or $1.53 per diluted share, an increase of 8.1% compared to non-GAAP net income of $50.5 million, or $1.44 per diluted share, in fiscal year 2013.

[0001193125-14-373872:8k_2_02:8]
Tom Mitchell, Chief Executive Officer of Fabrinet, said, “As we begin our new fiscal year, I am optimistic, as our relationships with customers have
never been stronger and our pipeline of new engagements continues to grow. Despite a demand environment that remains challenging, I am confident that our focus on total customer satisfaction and world-class quality will enable us to deliver another
year of profitable growth in fiscal 2015.”

[0001193125-14-373872:8k_2_02:9]
Business Outlook

[0001193125-14-373872:8k_2_02:10]
Based on information available as of October 16, 2014, Fabrinet expects first quarter revenue to be approximately $189 million, which includes
approximately $3 million of consigned shipment revenue excluded from fiscal 2014, as discussed above. GAAP net income per share is expected to be approximately $0.30 with expected non-GAAP net income per share of approximately $0.40, based on
approximately 36 million fully diluted shares outstanding.

[0001193125-14-373872:8k_2_02:11]
Audit Committee Investigation

[0001193125-14-373872:8k_2_02:12]
Prior to the completion of Fabrinet’s fiscal year 2014 financial results, management identified potential accounting violations with respect to
consignment shipments and inventory. Subsequently, the Audit Committee of Fabrinet’s Board of Directors initiated an internal investigation concerning various accounting cut-off issues in fiscal year 2014, specifically the shipment of
unfinished goods to consignment inventory and other inventory cut-off considerations. The investigation found certain process weaknesses concerning the potential to invoice unfinished goods held under consignment arrangements and the need for
certain remedial measures, including (1) process improvements, (2) personnel training regarding revenue recognition policies and inventory management techniques and their relevant accounting considerations, and (3) certain personnel
disciplinary actions. The Audit Committee provided these findings to the Company’s management so they could determine the potential impact on the Company’s disclosure controls and procedures and internal control over financial reporting.

[0001193125-14-373872:8k_2_02:13]
Subsequent to completion of the Audit Committee’s investigation, the Company evaluated its accounting
practices surrounding consignment inventory and consignment revenue. Based on that evaluation, the Company determined that for certain volume supply agreements with its customers not all of the revenue recognition criteria prescribed by the relevant
accounting literature had been met at the time revenue was recorded. Specifically, the Company misapplied the guidance when assessing the terms of these agreements with respect to when title and risk of loss transfers to its customers. As a result,
the Company determined that certain sales previously recognized did not qualify for revenue recognition in the periods in which they were recognized. The Company has evaluated the impact of the errors on both a quantitative and qualitative basis
under the relevant accounting guidance and determined that the errors did not have a material impact to the previously issued consolidated financial statements. Accordingly, previously issued financial statements for fiscal years 2013 and 2012 were
not revised or restated.

[0001193125-14-373872:8k_2_02:14]
For additional information on the Audit Committee’s investigation and the Company’s accounting practices surrounding
consignment inventory and consignment revenue and the corresponding impact to the Company’s disclosure controls and procedures and internal control over financial reporting, please see the Company’s Annual Report on Form 10-K for the
fiscal year ended June 27, 2014, filed on October 16, 2014.

[0001193125-14-373872:8k_2_02:15]
Conference Call Information

[0001193125-14-373872:8k_2_02:16]
| What: |  | Fabrinet Fourth Quarter and Fiscal Year 2014 Financial Results Conference Call |
| When: |  | Thursday, October 16, 2014 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic |
|  |  | (253) 237-1137, international |
|  |  | Passcode: 22009425 |
| Replay: |  | (855) 859-2056, domestic |
|  |  | (404) 537-3406, international |
|  |  | Passcode: 22009425 |
| Webcast: |  | http://investor.fabrinet.com (live and replay) |

[0001193125-14-373872:8k_2_02:17]
This press release and any other information related to the call will also be posted on Fabrinet’s website at
http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-14-373872:8k_2_02:18]
About Fabrinet

[0001193125-14-373872:8k_2_02:19]
Fabrinet is a leading provider of
advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, industrial lasers
and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging,
integration, final assembly and test. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the People’s Republic of China
and the United States. For more information visit: www.fabrinet.com.

[0001193125-14-373872:8k_2_02:20]
Forward-Looking Statements

[0001193125-14-373872:8k_2_02:21]
materially from these forward-looking statements. Important factors that could cause actual results to differ materially from those in the forward-looking statements include, but are not limited
to: potential changes to these expected operating results based on the results of the review by our independent registered public accounting firm; changes in our expected results as we complete our review and other procedures associated with closing
the quarter; less customer demand for our products and services than forecasted; less growth in the optical communications, industrial lasers and sensors markets than we forecast; difficulties expanding into additional markets, such as the
semiconductor processing, biotechnology, metrology and materials processing markets; increased competition in the optical manufacturing services markets; difficulties in delivering products and services that compete effectively from a price and
performance perspective; our reliance on a small number of customers and suppliers; difficulties in managing our operating costs; difficulties in managing and operating our business across multiple countries (including the U.S., Thailand and the
People’s Republic of China); and other important factors as described in reports and documents we file from time to time with the Securities and Exchange Commission (SEC), including the factors described under the section captioned “Risk
Factors” in our Annual Report on Form 10-K, filed on October 16, 2014. We disclaim any obligation to update information contained in these forward-looking statements whether as a result of new information, future events, or otherwise.

[0001193125-14-373872:8k_2_02:22]
Use of Non-GAAP Financials

[0001193125-14-373872:8k_2_02:23]
The Company refers to the
non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding the Company’s ongoing operational performance. Non-GAAP net income excludes share-based compensation
expenses, follow-on offering expenses, expenses related to reduction in workforce, executive separation cost, investigation cost and income related to flooding. We have excluded these items in order to enhance investors’ understanding of our
ongoing operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these
material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001193125-14-373872:8k_2_02:24]
These non-GAAP financial measures are used
to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and
operational decision making. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001193125-14-373872:8k_2_02:25]
SOURCE: Fabrinet

[0001193125-14-373872:8k_2_02:26]
Investor Contact:

[0001193125-14-373872:8k_2_02:27]
Jennifer Predmore

[0001193125-14-373872:8k_2_02:28]
215-428-1797

[0001193125-14-373872:8k_2_02:29]
ir@fabrinet.com

[0001193125-14-373872:8k_2_02:30]
Fabrinet

[0001193125-14-373872:8k_2_02:31]
Consolidated Balance Sheets

[0001193125-14-373872:8k_2_02:32]
As of June 27, 2014
and June 28, 2013

[0001193125-14-373872:8k_2_02:33]
| (in thousands of U.S. dollars, except share data) |  | June 27,2014 |  |  | June 28,2013 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 233,477 |  |  | $ | 149,716 |  |
| Trade accounts receivable, net |  |  | 101,168 |  |  |  | 118,475 |  |
| Inventory, net |  |  | 124,570 |  |  |  | 88,962 |  |
| Deferred tax assets |  |  | 1,561 |  |  |  | 1,397 |  |
| Prepaid expenses |  |  | 1,691 |  |  |  | 1,931 |  |
| Other current assets |  |  | 2,010 |  |  |  | 3,505 |  |
| Total current assets |  |  | 464,477 |  |  |  | 363,986 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 97,244 |  |  |  | 97,206 |  |
| Intangibles, net |  |  | 72 |  |  |  | 164 |  |
| Deferred tax assets |  |  | 1,775 |  |  |  | 2,116 |  |
| Deposits and other non-current assets |  |  | 989 |  |  |  | 107 |  |
| Total non-current assets |  |  | 100,080 |  |  |  | 99,593 |  |
| Total assets |  | $ | 564,557 |  |  | $ | 463,579 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Long-term loans from bank, current portion |  | $ | 6,000 |  |  | $ | 9,668 |  |
| Trade accounts payable |  |  | 94,853 |  |  |  | 77,139 |  |
| Income tax payable |  |  | 1,024 |  |  |  | 1,825 |  |
| Accrued payroll, bonus and related expenses |  |  | 8,612 |  |  |  | 6,220 |  |
| Accrued expenses |  |  | 4,345 |  |  |  | 3,121 |  |
| Other payables |  |  | 5,795 |  |  |  | 5,163 |  |
| Liabilities to third parties due to flood losses |  |  | — |  |  |  | 9,812 |  |
| Total current liabilities |  |  | 120,629 |  |  |  | 112,948 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term loans from bank, non-current portion |  |  | 10,500 |  |  |  | 19,243 |  |
| Deferred tax liability |  |  | 1,040 |  |  |  | 1,152 |  |
| Severance liabilities |  |  | 4,453 |  |  |  | 4,382 |  |
| Other non-current liabilities |  |  | 1,099 |  |  |  | 536 |  |
| Total non-current liabilities |  |  | 17,092 |  |  |  | 25,313 |  |
| Total liabilities |  |  | 137,721 |  |  |  | 138,261 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of June 27, 2014 and June 28, 2013) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 35,152,772 shares and 34,634,967 shares issued and outstanding as of June 27, 2014 and June 28, 2013, respectively) |  |  | 352 |  |  |  | 346 |  |
| Additional paid-in capital |  |  | 80,882 |  |  |  | 71,101 |  |
| Retained earnings |  |  | 345,602 |  |  |  | 253,871 |  |
| Total shareholders’ equity |  |  | 426,836 |  |  |  | 325,318 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 564,557 |  |  | $ | 463,579 |  |

[0001193125-14-373872:8k_2_02:34]
Fabrinet

[0001193125-14-373872:8k_2_02:35]
Consolidated Statements of Operations

[0001193125-14-373872:8k_2_02:36]
For the three
and twelve months ended June 27, 2014 and June 28, 2013

[0001193125-14-373872:8k_2_02:37]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | June 27, |  |  | June 28, |  |  | June 27, |  |  | June 28, |  |
| (in thousands of U.S. dollars, except share data) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Revenues |  | $ | 160,084 |  |  | $ | 159,934 |  |  | $ | 677,854 |  |  | $ | 641,542 |  |
| Cost of revenues |  |  | (142,309 | ) |  |  | (142,863 | ) |  |  | (603,621 | ) |  |  | (572,124 | ) |
| Gross profit |  |  | 17,775 |  |  |  | 17,071 |  |  |  | 74,233 |  |  |  | 69,418 |  |
| Selling, general and administrative expenses |  |  | (6,705 | ) |  |  | (5,340 | ) |  |  | (27,664 | ) |  |  | (23,787 | ) |
| Income related to flooding |  |  | — |  |  |  | 6,147 |  |  |  | 44,748 |  |  |  | 27,211 |  |
| Expenses related to reduction in workforce |  |  | — |  |  |  | (2,052 | ) |  |  | — |  |  |  | (2,052 | ) |
| Operating income |  |  | 11,070 |  |  |  | 15,826 |  |  |  | 91,317 |  |  |  | 70,790 |  |
| Interest income |  |  | 531 |  |  |  | 322 |  |  |  | 1,793 |  |  |  | 1,083 |  |
| Interest expense |  |  | (147 | ) |  |  | (222 | ) |  |  | (713 | ) |  |  | (1,010 | ) |
| Foreign exchange (loss) gain, net |  |  | (70 | ) |  |  | (731 | ) |  |  | (24 | ) |  |  | 354 |  |
| Other income |  |  | 253 |  |  |  | 180 |  |  |  | 797 |  |  |  | 692 |  |
| Income before income taxes |  |  | 11,637 |  |  |  | 15,375 |  |  |  | 93,170 |  |  |  | 71,909 |  |
| Income tax expense |  |  | (1,304 | ) |  |  | (233 | ) |  |  | (1,439 | ) |  |  | (2,940 | ) |
| Net income |  | $ | 10,333 |  |  | $ | 15,142 |  |  | $ | 91,731 |  |  | $ | 68,969 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.29 |  |  | $ | 0.44 |  |  | $ | 2.63 |  |  | $ | 2.00 |  |
| Diluted |  | $ | 0.29 |  |  | $ | 0.43 |  |  | $ | 2.58 |  |  | $ | 1.98 |  |
| Weighted average number of ordinary shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (thousands of shares) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 35,117 |  |  |  | 34,629 |  |  |  | 34,938 |  |  |  | 34,557 |  |
| Diluted |  |  | 35,843 |  |  |  | 35,000 |  |  |  | 35,589 |  |  |  | 34,846 |  |

[0001193125-14-373872:8k_2_02:38]
Fabrinet

[0001193125-14-373872:8k_2_02:39]
Consolidated Statements of Cash Flows

[0001193125-14-373872:8k_2_02:40]
For the twelve
months ended June 27, 2014 and June 28, 2013

[0001193125-14-373872:8k_2_02:41]
|  |  | Twelve Months Ended |  |
| (in thousands of U. S. dollars) |  | June 27, 2014 |  |  | June 28, 2013 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income for the year |  | $ | 91,731 |  |  | $ | 68,969 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 10,565 |  |  |  | 9,994 |  |
| Amortization of intangibles |  |  | 93 |  |  |  | 217 |  |
| Gain on disposal of property, plant and equipment |  |  | (28 | ) |  |  | (24 | ) |
| Income related to flooding |  |  | (45,211 | ) |  |  | (29,465 | ) |
| Proceeds from insurers for business interruption losses related to flooding |  |  | — |  |  |  | 13,143 |  |
| Proceeds from insurers for inventory losses related to flooding |  |  | 7,416 |  |  |  | 11,419 |  |
| Reversal of allowance for doubtful accounts |  |  | (72 | ) |  |  | (94 | ) |
| Unrealized loss (gain) on exchange rate and fair value of derivative |  |  | 722 |  |  |  | (1,043 | ) |
| Share-based compensation |  |  | 5,547 |  |  |  | 5,100 |  |
| Deferred income tax |  |  | 65 |  |  |  | 2,086 |  |
| Other non-cash expenses (income) |  |  | 634 |  |  |  | (89 | ) |
| Reversal of uncertain tax positions |  |  | (1,538 | ) |  |  | — |  |
| Inventory obsolescence (reversal of) |  |  | 443 |  |  |  | (584 | ) |
| Loss from written-off assets and liabilities to third parties due to flood losses |  |  | — |  |  |  | 2,255 |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | 17,379 |  |  |  | 4,739 |  |
| Inventory |  |  | (36,051 | ) |  |  | 14,229 |  |
| Other current assets and non-current assets |  |  | (1,035 | ) |  |  | (1,207 | ) |
| Trade accounts payable |  |  | 17,714 |  |  |  | (8,861 | ) |
| Income tax payable |  |  | 737 |  |  |  | (5 | ) |
| Other current liabilities and non-current liabilities |  |  | 4,951 |  |  |  | (35 | ) |
| Liabilities to third parties due to flood losses |  |  | (7,512 | ) |  |  | (41,994 | ) |
| Net cash provided by operating activities |  |  | 66,550 |  |  |  | 48,750 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of property, plant and equipment |  |  | (10,835 | ) |  |  | (10,793 | ) |
| Purchase of intangibles |  |  | (1 | ) |  |  | (2 | ) |
| Proceeds from disposal of property, plant and equipment |  |  | 29 |  |  |  | 29 |  |
| Proceeds from insurers in settlement of claims related to flood damage |  |  | 37,795 |  |  |  | 4,904 |  |
| Net cash provided by (used in) investing activities |  |  | 26,988 |  |  |  | (5,862 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Repayment of long-term loans from bank |  |  | (12,411 | ) |  |  | (9,668 | ) |
| Proceeds from issuance of ordinary shares under employee share option plans |  |  | 4,567 |  |  |  | 561 |  |
| Withholding tax related to net share settlement of restricted share units |  |  | (327 | ) |  |  | (21 | ) |
| Net cash used in financing activities |  |  | (8,171 | ) |  |  | (9,128 | ) |
| Net increase in cash and cash equivalents |  | $ | 85,367 |  |  | $ | 33,760 |  |
| Movement in cash and cash equivalents |  |  |  |  |  |  |  |  |
| Cash and cash equivalents at beginning of period |  | $ | 149,716 |  |  | $ | 115,507 |  |
| Increase in cash and cash equivalents |  |  | 85,367 |  |  |  | 33,760 |  |
| Effect of exchange rate on cash and cash equivalents |  |  | (1,606 | ) |  |  | 449 |  |
| Cash and cash equivalents at end of period |  | $ | 233,477 |  |  | $ | 149,716 |  |

[0001193125-14-373872:8k_2_02:42]
Fabrinet

[0001193125-14-373872:8k_2_02:43]
Reconciliation of GAAP measures to non-GAAP measures

[0001193125-14-373872:8k_2_02:44]
(in thousands of U.S. dollars, except per share data)

[0001193125-14-373872:8k_2_02:45]
(unaudited)

[0001193125-14-373872:8k_2_02:46]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | June 27, |  |  | June 27, |  |  | June 28, |  |  | June 28, |  |  | June 27, |  |  | June 27, |  |  | June 28, |  |  | June 28, |  |
|  |  | 2014 |  |  | 2014 |  |  | 2013 |  |  | 2013 |  |  | 2014 |  |  | 2014 |  |  | 2013 |  |  | 2013 |  |
|  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |
| GAAP measures |  |  | 10,333 |  |  |  | 0.29 |  |  |  | 15,142 |  |  |  | 0.43 |  |  |  | 91,731 |  |  |  | 2.58 |  |  |  | 68,969 |  |  |  | 1.98 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 294 |  |  |  | 0.01 |  |  |  | 186 |  |  |  | 0.01 |  |  |  | 1,182 |  |  |  | 0.03 |  |  |  | 1,105 |  |  |  | 0.03 |  |
| Total related to gross profit |  |  | 294 |  |  |  | 0.01 |  |  |  | 186 |  |  |  | 0.01 |  |  |  | 1,182 |  |  |  | 0.03 |  |  |  | 1,105 |  |  |  | 0.03 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 715 |  |  |  | 0.02 |  |  |  | 945 |  |  |  | 0.03 |  |  |  | 4,365 |  |  |  | 0.12 |  |  |  | 3,995 |  |  |  | 0.11 |  |
| Executive separation cost |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 547 |  |  |  | 0.02 |  |  |  | — |  |  |  | — |  |
| Follow-on offering expenses |  |  | 344 |  |  |  | 0.01 |  |  |  | (79 | ) |  |  | (0.00 | ) |  |  | 344 |  |  |  | 0.01 |  |  |  | 393 |  |  |  | 0.01 |  |
| Investigation costs |  |  | 400 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 400 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |
| Total related to selling, general and administrative expenses |  |  | 1,459 |  |  |  | 0.04 |  |  |  | 866 |  |  |  | 0.02 |  |  |  | 5,656 |  |  |  | 0.16 |  |  |  | 4,388 |  |  |  | 0.12 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income related to flooding |  |  | — |  |  |  | — |  |  |  | (6,147 | ) |  |  | (0.17 | ) |  |  | (44,748 | ) |  |  | (1.26 | ) |  |  | (27,211 | ) |  |  | (0.77 | ) |
| Unrealized loss on exchange, net of interest incurred from income related to flooding |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 744 |  |  |  | 0.02 |  |  |  | — |  |  |  | — |  |
| Expenses related to reduction in workforce |  |  | — |  |  |  | — |  |  |  | 2,052 |  |  |  | 0.06 |  |  |  | — |  |  |  | — |  |  |  | 2,052 |  |  |  | 0.06 |  |
| Total related to other incomes and other expenses |  |  | — |  |  |  | — |  |  |  | (4,095 | ) |  |  | (0.12 | ) |  |  | (44,004 | ) |  |  | (1.24 | ) |  |  | (25,159 | ) |  |  | (0.72 | ) |
| Related to income tax expense Income tax expense |  |  | — |  |  |  | — |  |  |  | 272 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 1,179 |  |  |  | 0.03 |  |
| Total related to income tax expense |  |  | — |  |  |  | — |  |  |  | 272 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 1,179 |  |  |  | 0.03 |  |
| Total related to net income & EPS |  |  | 1,753 |  |  |  | 0.05 |  |  |  | (2,771 | ) |  |  | (0.08 | ) |  |  | (37,166 | ) |  |  | (1.05 | ) |  |  | (18,487 | ) |  |  | (0.53 | ) |
| Non-GAAP measures |  |  | 12,086 |  |  |  | 0.34 |  |  |  | 12,371 |  |  |  | 0.35 |  |  |  | 54,565 |  |  |  | 1.53 |  |  |  | 50,482 |  |  |  | 1.44 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 35,843 |  |  |  |  |  |  |  | 35,000 |  |  |  |  |  |  |  | 35,589 |  |  |  |  |  |  |  | 34,846 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 35,843 |  |  |  |  |  |  |  | 35,240 |  |  |  |  |  |  |  | 35,589 |  |  |  |  |  |  |  | 35,159 |  |
