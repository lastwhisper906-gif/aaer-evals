# FN 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001193125-14-373828:item_9a:1]
| ITEM 9A. | CONTROLS AND PROCEDURES. |

[0001193125-14-373828:item_9a:2]
Evaluation
of Disclosure Controls and Procedures

[0001193125-14-373828:item_9a:3]
Our management is responsible for establishing and maintaining disclosure controls
and procedures designed to ensure that information we are required to disclose in reports we file or submit under the Securities Exchange Act of 1934, as amended (“Exchange Act”), (i) is recorded, processed, summarized, and reported
within time periods specified in the rules and forms of the Securities and Exchange Commission, and (ii) is accumulated and communicated to Fabrinet’s management, including our Chief Executive Officer (“CEO”) and Chief Financial
Officer (“CFO”), as appropriate, to allow timely decisions regarding required disclosure.

[0001193125-14-373828:item_9a:4]
Our management, including
our CEO and CFO, evaluated the effectiveness of our disclosure controls and procedures (as defined in Rule 13a-15(e) of the Exchange Act), as of the end of the period covered by this Annual Report on Form 10-K. Based on their evaluation, our CEO and
CFO concluded that, as of June 27, 2014, the Company’s disclosure controls and procedures were not effective because of the material weakness in our internal control over financial reporting described below.

[0001193125-14-373828:item_9a:5]
Changes in Internal Control over Financial Reporting

[0001193125-14-373828:item_9a:6]
There have been no changes in internal control over financial reporting that occurred during the quarter ended June 27, 2014 that have materially affected, or are reasonably likely to materially
affect, our internal control over financial reporting.

[0001193125-14-373828:item_9a:7]
Management’s Annual Report on Internal Control over Financial Reporting

[0001193125-14-373828:item_9a:8]
Management is responsible for establishing and maintaining adequate internal control over financial reporting of the
Company as defined in Rule 13a-15(f) under the Exchange Act. Internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements
for external purposes in accordance with generally accepted accounting principles (“GAAP”).

[0001193125-14-373828:item_9a:9]
Our internal control
over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the Company;
(ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the Company are being
made only in accordance with authorizations of management and directors of the Company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the Company’s
assets that could have a material effect on the financial statements.

[0001193125-14-373828:item_9a:10]
Because of its inherent limitations, internal control
over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree
of compliance with the policies or procedures may deteriorate. Management has assessed the effectiveness of our internal control over financial reporting as of June 27, 2014. In making this assessment, management used the criteria described in
Internal Control—Integrated Framework (1992) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001193125-14-373828:item_9a:11]
Based on their assessment, management concluded that, as of June 27, 2014, the Company did not maintain effective internal control over financial reporting based on the criteria in Internal
Control – Integrated Framework (1992) issued by COSO because of the material weakness in our internal control over financial reporting described below.

[0001193125-14-373828:item_9a:12]
A material weakness is a deficiency, or combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the
company’s annual or interim financial statements will not be prevented or detected on a timely basis.

[0001193125-14-373828:item_9a:13]
93

[0001193125-14-373828:item_9a:14]
We did not maintain effective internal controls over the assessment of volume supply
agreements. Specifically, we did not correctly apply appropriate U.S. GAAP knowledge and expertise when assessing the terms of these arrangements with respect to when title and risk of loss transfers to our customers. This deficiency resulted in
audit adjustments to our financial statements in the revenue, accounts receivable, inventory and cost of revenue line items. Additionally, this material weakness could result in misstatements of the aforementioned accounts and related disclosures
that would result in a material misstatement of the annual or interim consolidated financial statements that would not be prevented or detected, and accordingly our CEO and CFO, in consultation with the Audit Committee, concluded that the deficiency
constituted a material weakness as of June 27, 2014.

[0001193125-14-373828:item_9a:15]
The effectiveness of our internal control over financial reporting
as of June 27, 2014 has been audited by PricewaterhouseCoopers ABAS Ltd., an independent registered public accounting firm, as stated in their report which appears herein.

[0001193125-14-373828:item_9a:16]
Remediation Efforts to Address Newly Identified Material Weakness

[0001193125-14-373828:item_9a:17]
Fabrinet
and the Board take control and integrity of the Company’s financial statements seriously and believe that the remediation steps described below will address the aforementioned material weakness.

[0001193125-14-373828:item_9a:18]
|  | • |  | We will implement procedures to ensure that all customer contracts are reviewed at inception and quarterly for compliance with generally accepted accounting principles. |

[0001193125-14-373828:item_9a:19]
|  | • |  | We will enhance our technical accounting training, led by appropriate technical accounting experts to improve awareness and understanding of revenue accounting principles. |

[0001193125-14-373828:item_9a:20]
We are committed to maintaining a strong internal control environment, and believe
that these remediation actions will represent significant improvements in our controls. However, the identified material weakness in internal control over financial reporting will not be considered remediated until controls have been designed and
controls are in operation for a sufficient period of time for our management to conclude that the material weakness has been remediated. Additional remediation measures may be required, which may require additional implementation time. We will
continue to assess the effectiveness of our remediation efforts in connection with our evaluations of internal control over financial reporting.
