# FN 8-K — 0001193125-17-162642 filed 2017-05-08

## item codes, every 8-K on or before 2017-05-09

- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2017-05-09

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-162642:8k_2_02:1]
EX-99.1
2
d392316dex991.htm
EX-99.1

[0001193125-17-162642:8k_2_02:2]
EX-99.1

[0001193125-17-162642:8k_2_02:3]
Exhibit 99.1

[0001193125-17-162642:8k_2_02:4]
Fabrinet Announces Third Quarter Fiscal Year 2017

[0001193125-17-162642:8k_2_02:5]
Financial Results

[0001193125-17-162642:8k_2_02:6]
Revenue Exceeds High-End of Guidance Range

[0001193125-17-162642:8k_2_02:7]
BANGKOK, Thailand – May 8, 2017 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision
optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for the third fiscal quarter ended March 31, 2017.

[0001193125-17-162642:8k_2_02:8]
Tom Mitchell, Chief Executive Officer of Fabrinet, said: “We had a strong third quarter, with revenue that exceeded our guidance range and grew 46% from
a year ago. We are benefiting from growth in a variety of existing customer programs that are further supported by new business. Our new facility in Chonburi, Thailand and our new product introduction facilities in Santa Clara, California and the UK
are also making important contributions that we expect to expand as we look ahead.”

[0001193125-17-162642:8k_2_02:9]
Third Quarter Fiscal-Year 2017 Financial Highlights

[0001193125-17-162642:8k_2_02:10]
GAAP Results

[0001193125-17-162642:8k_2_02:11]
|  | • |  | Revenue for the third quarter of fiscal year 2017 was $366.8 million, an increase of 46% compared to revenue of $250.9 million for the comparable period in fiscal year 2016. |

[0001193125-17-162642:8k_2_02:12]
|  | • |  | GAAP net income for the third quarter of fiscal year 2017 was $21.7 million, compared to GAAP net income of $20.8 million in the third quarter of fiscal year 2016. GAAP net income for the third quarter of fiscal year 2017 included a foreign exchange loss of $3.7 million, or $0.10 per diluted share. |

[0001193125-17-162642:8k_2_02:13]
|  | • |  | GAAP net income per diluted share for the third quarter of fiscal year 2017 was $0.57, compared to GAAP net income per diluted share of $0.56 in the third quarter of fiscal year 2016. |

[0001193125-17-162642:8k_2_02:14]
Non-GAAP Results

[0001193125-17-162642:8k_2_02:15]
|  | • |  | Non-GAAP net income in the third quarter of fiscal 2017 was $30.5 million, an increase of 46% compared to non-GAAP net income of $20.8 million in the third quarter of fiscal year 2016. Non-GAAP net income for the third quarter of fiscal year 2017 included a foreign exchange loss of $3.7 million, or $0.10 per diluted share. |

[0001193125-17-162642:8k_2_02:16]
|  | • |  | Non-GAAP net income per diluted share in the third quarter of fiscal 2017 was $0.80, compared to non-GAAP net income per diluted share of $0.56 in the third quarter of fiscal year 2016. |

[0001193125-17-162642:8k_2_02:17]
Business Outlook

[0001193125-17-162642:8k_2_02:18]
Based on information available as of May 8, 2017, Fabrinet is issuing guidance for the fourth quarter of fiscal year 2017 ending June 30, 2017, as
follows:

[0001193125-17-162642:8k_2_02:19]
|  | • |  | Fabrinet expects revenue for the fourth quarter to be in the range of $361 million to $365 million. |

[0001193125-17-162642:8k_2_02:20]
|  | • |  | GAAP net income per diluted share is expected to be in the range of $0.65 to $0.67, based on approximately 38.2 million fully diluted shares outstanding. |

[0001193125-17-162642:8k_2_02:21]
|  | • |  | Non-GAAP net income per diluted share is expected to be in the range of $0.82 to $0.84, based on approximately 38.2 million fully diluted shares outstanding. |

[0001193125-17-162642:8k_2_02:22]
Conference Call Information

[0001193125-17-162642:8k_2_02:23]
| What: |  | Fabrinet Third Quarter Fiscal Year 2017 Financial Results Conference Call |
| When: |  | Monday, May 8, 2017 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic |
|  |  | (253) 237-1137, international |
|  |  | Passcode: 10614331 |

[0001193125-17-162642:8k_2_02:24]
| Replay: |  | (855) 859-2056, domestic |
|  |  | (404) 537-3406, international |
|  |  | Passcode: 10614331 |
| Webcast: |  | http://investor.fabrinet.com (live and replay) |

[0001193125-17-162642:8k_2_02:25]
This press release and any other information related to the call also will be posted on Fabrinet’s website at
http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and archived on Fabrinet’s website for a period of one year.

[0001193125-17-162642:8k_2_02:26]
About Fabrinet

[0001193125-17-162642:8k_2_02:27]
Fabrinet is a leading provider of
advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, industrial lasers
and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging,
integration, final assembly and test. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the
People’s Republic of China and the United Kingdom. For more information visit: www.fabrinet.com.

[0001193125-17-162642:8k_2_02:28]
Forward-Looking Statements

[0001193125-17-162642:8k_2_02:29]
Use of Non-GAAP Financials

[0001193125-17-162642:8k_2_02:30]
The Company refers to the non-GAAP financial measures cited above in making operating decisions because they provide
meaningful supplemental information regarding the Company’s ongoing operational performance. Non-GAAP net income excludes share-based compensation expenses, executive separation costs, expenses related to
our CEO search, debt administration expenses, income or expense related to flooding, depreciation of fair value uplift, amortization of debt issuance costs, unrealized gain or loss on foreign exchange, business combination expenses, and

[0001193125-17-162642:8k_2_02:31]
amortization of intangible assets. We have excluded these items in order to enhance investors’ understanding of our underlying operations. The use of these
non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these
material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001193125-17-162642:8k_2_02:32]
These non-GAAP financial measures are used to: (1) measure company performance against historical results,
(2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001193125-17-162642:8k_2_02:33]
SOURCE: Fabrinet

[0001193125-17-162642:8k_2_02:34]
Investor Contact:

[0001193125-17-162642:8k_2_02:35]
Garo Toomajanian

[0001193125-17-162642:8k_2_02:36]
ir@fabrinet.com

[0001193125-17-162642:8k_2_02:37]
3

[0001193125-17-162642:8k_2_02:38]
FABRINET

[0001193125-17-162642:8k_2_02:39]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-17-162642:8k_2_02:40]
| (in thousands of U.S. dollars, except share data) |  | March 31,2017 |  |  | June 24,2016 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 136,634 |  |  | $ | 142,804 |  |
| Marketable securities |  |  | 152,608 |  |  |  | 141,709 |  |
| Trade accounts receivable, net |  |  | 250,922 |  |  |  | 196,145 |  |
| Inventory, net |  |  | 224,627 |  |  |  | 181,499 |  |
| Deferred tax assets |  |  | — |  |  |  | 1,358 |  |
| Prepaid expenses |  |  | 3,804 |  |  |  | 3,114 |  |
| Other current assets |  |  | 2,983 |  |  |  | 6,662 |  |
| Total current assets |  |  | 771,578 |  |  |  | 673,291 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Restricted cash in connection with business acquisition |  |  | 3,175 |  |  |  | — |  |
| Property, plant and equipment, net |  |  | 216,378 |  |  |  | 178,410 |  |
| Intangibles, net |  |  | 5,857 |  |  |  | 499 |  |
| Goodwill |  |  | 3,649 |  |  |  | — |  |
| Deferred tax assets |  |  | 2,452 |  |  |  | 1,806 |  |
| Deferred debt issuance costs on revolving loan and other non-current assets |  |  | 1,596 |  |  |  | 1,851 |  |
| Total non-current assets |  |  | 233,107 |  |  |  | 182,566 |  |
| Total Assets |  | $ | 1,004,685 |  |  | $ | 855,857 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Bank borrowings, net of unamortized debt issuance costs |  | $ | 48,658 |  |  | $ | 24,307 |  |
| Trade accounts payable |  |  | 210,105 |  |  |  | 172,052 |  |
| Fixed assets payable |  |  | 12,409 |  |  |  | 20,628 |  |
| Capital lease liability, current portion |  |  | 341 |  |  |  | — |  |
| Income tax payable |  |  | 2,209 |  |  |  | 2,010 |  |
| Accrued payroll, bonus and related expenses |  |  | 15,141 |  |  |  | 12,300 |  |
| Accrued expenses |  |  | 13,020 |  |  |  | 8,072 |  |
| Other payables |  |  | 10,931 |  |  |  | 16,356 |  |
| Total current liabilities |  |  | 312,814 |  |  |  | 255,725 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term loan from bank, non-current portion, net of unamortized debt issuance costs |  |  | 26,059 |  |  |  | 36,100 |  |
| Deferred tax liability |  |  | 1,754 |  |  |  | 854 |  |
| Capital lease liability, non-current portion |  |  | 1,062 |  |  |  | — |  |
| Deferred liability in connection with business acquisition |  |  | 3,175 |  |  |  | — |  |
| Severance liabilities |  |  | 7,896 |  |  |  | 6,684 |  |
| Other non-current liabilities |  |  | 2,822 |  |  |  | 2,075 |  |
| Total non-current liabilities |  |  | 42,768 |  |  |  | 45,713 |  |
| Total Liabilities |  |  | 355,582 |  |  |  | 301,438 |  |
| Commitments and contingencies (Note 16) |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of March 31, 2017 and June 24, 2016) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 37,326,596 shares and 36,156,446 shares issued and outstanding as of March 31, 2017 and June 24, 2016, respectively) |  |  | 373 |  |  |  | 362 |  |
| Additional paid-in capital |  |  | 128,868 |  |  |  | 102,325 |  |
| Accumulated other comprehensive (loss) income |  |  | (993 | ) |  |  | 591 |  |
| Retained earnings |  |  | 520,855 |  |  |  | 451,141 |  |
| Total Shareholders’ Equity |  |  | 649,103 |  |  |  | 554,419 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 1,004,685 |  |  | $ | 855,857 |  |

[0001193125-17-162642:8k_2_02:41]
FABRINET

[0001193125-17-162642:8k_2_02:42]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME

[0001193125-17-162642:8k_2_02:43]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (in thousands of U.S. dollars, except per share amounts) |  | March 31,2017 |  |  | March 25,2016 |  |  | March 31,2017 |  |  | March 25,2016 |  |
| Revenues |  | $ | 366,837 |  |  | $ | 250,888 |  |  | $ | 1,050,036 |  |  | $ | 700,359 |  |
| Cost of revenues |  |  | (322,791 | ) |  |  | (219,711 | ) |  |  | (923,336 | ) |  |  | (614,678 | ) |
| Gross profit |  |  | 44,046 |  |  |  | 31,177 |  |  |  | 126,700 |  |  |  | 85,681 |  |
| Selling, general and administrative expenses |  |  | (17,086 | ) |  |  | (12,299 | ) |  |  | (50,569 | ) |  |  | (37,914 | ) |
| Other income related to flooding, net |  |  | — |  |  |  | 900 |  |  |  | — |  |  |  | 36 |  |
| Operating income |  |  | 26,960 |  |  |  | 19,778 |  |  |  | 76,131 |  |  |  | 47,803 |  |
| Interest income |  |  | 713 |  |  |  | 213 |  |  |  | 1,470 |  |  |  | 1,110 |  |
| Interest expense |  |  | (641 | ) |  |  | (335 | ) |  |  | (2,517 | ) |  |  | (1,156 | ) |
| Foreign exchange (loss) gain, net |  |  | (3,702 | ) |  |  | 3,080 |  |  |  | (100 | ) |  |  | (1,246 | ) |
| Other income |  |  | 108 |  |  |  | 57 |  |  |  | 397 |  |  |  | 266 |  |
| Income before income taxes |  |  | 23,438 |  |  |  | 22,793 |  |  |  | 75,381 |  |  |  | 46,777 |  |
| Income tax expense |  |  | (1,782 | ) |  |  | (1,971 | ) |  |  | (5,667 | ) |  |  | (4,549 | ) |
| Net income |  |  | 21,656 |  |  |  | 20,822 |  |  |  | 69,714 |  |  |  | 42,228 |  |
| Other comprehensive gain (loss), net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on marketable securities |  |  | 49 |  |  |  | 292 |  |  |  | (491 | ) |  |  | 117 |  |
| Change in net unrealized (loss) gain on derivative instruments |  |  | — |  |  |  | 722 |  |  |  | (158 | ) |  |  | 674 |  |
| Change in foreign currency translation adjustment |  |  | 227 |  |  |  | — |  |  |  | (935 | ) |  |  | — |  |
| Total other comprehensive gain (loss), net of tax |  |  | 276 |  |  |  | 1,014 |  |  |  | (1,584 | ) |  |  | 791 |  |
| Net comprehensive income |  | $ | 21,932 |  |  | $ | 21,836 |  |  | $ | 68,130 |  |  | $ | 43,019 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.58 |  |  | $ | 0.58 |  |  | $ | 1.89 |  |  | $ | 1.18 |  |
| Diluted |  | $ | 0.57 |  |  | $ | 0.56 |  |  | $ | 1.85 |  |  | $ | 1.15 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 37,116 |  |  |  | 35,964 |  |  |  | 36,792 |  |  |  | 35,785 |  |
| Diluted |  |  | 37,872 |  |  |  | 37,089 |  |  |  | 37,750 |  |  |  | 36,743 |  |

[0001193125-17-162642:8k_2_02:44]
5

[0001193125-17-162642:8k_2_02:45]
FABRINET

[0001193125-17-162642:8k_2_02:46]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-17-162642:8k_2_02:47]
|  |  | Nine Months Ended |  |
| (in thousands of U.S. dollars) |  | March 31,2017 |  |  | March 25,2016 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income for the period |  | $ | 69,714 |  |  | $ | 42,228 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 16,956 |  |  |  | 12,793 |  |
| Loss (gain) on disposal of property, plant and equipment |  |  | 7 |  |  |  | (13 | ) |
| Loss from sales and maturities of available-for-sale securities |  |  | 407 |  |  |  | 190 |  |
| Amortization of investment premium |  |  | 397 |  |  |  | 605 |  |
| Amortization of deferred debt issuance costs |  |  | 1,591 |  |  |  | 543 |  |
| Income related to flooding |  |  | — |  |  |  | (828 | ) |
| Proceeds from insurer in settlement of claim related to flood damage |  |  | — |  |  |  | 272 |  |
| Allowance for doubtful accounts (reversal) |  |  | 3 |  |  |  | (7 | ) |
| Unrealized (gain) loss on exchange rate and fair value of derivative instruments |  |  | (718 | ) |  |  | 2,406 |  |
| Share-based compensation |  |  | 21,936 |  |  |  | 7,782 |  |
| Deferred income tax |  |  | 1,008 |  |  |  | 1,054 |  |
| Other non-cash expenses |  |  | 1,775 |  |  |  | 1,171 |  |
| Reversal of inventory obsolescence |  |  | (72 | ) |  |  | (344 | ) |
| Loss from written-off inventory due to flood loss |  |  | — |  |  |  | 233 |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | (50,839 | ) |  |  | (37,015 | ) |
| Inventory |  |  | (39,766 | ) |  |  | (19,258 | ) |
| Other current assets and non-current assets |  |  | 3,921 |  |  |  | (3,803 | ) |
| Trade accounts payable |  |  | 32,653 |  |  |  | 30,731 |  |
| Income tax payable |  |  | 166 |  |  |  | (114 | ) |
| Other current liabilities and non-current liabilities |  |  | 1,249 |  |  |  | 2,730 |  |
| Net cash provided by operating activities |  |  | 60,388 |  |  |  | 41,356 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of marketable securities |  |  | (100,751 | ) |  |  | (85,644 | ) |
| Proceeds from sales of marketable securities |  |  | 33,812 |  |  |  | 28,735 |  |
| Proceeds from maturities of marketable securities |  |  | 54,745 |  |  |  | 54,290 |  |
| Payments in connection with business acquisition, net of cash acquired |  |  | (9,917 | ) |  |  | — |  |
| Purchase of property, plant and equipment |  |  | (57,224 | ) |  |  | (33,545 | ) |
| Purchase of intangibles |  |  | (1,910 | ) |  |  | (274 | ) |
| Proceeds from disposal of property, plant and equipment |  |  | 190 |  |  |  | 62 |  |
| Proceeds from insurer in settlement of equipment claims related to flood damage |  |  | — |  |  |  | 556 |  |
| Net cash used in investing activities |  |  | (81,055 | ) |  |  | (35,820 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Payment of debt issuance costs |  |  | — |  |  |  | (506 | ) |
| Proceeds of short-term loans from banks |  |  | 27,665 |  |  |  | 18,000 |  |
| Repayment of long-term loans from bank |  |  | (14,700 | ) |  |  | (8,500 | ) |
| Repayment of capital lease liability |  |  | (182 | ) |  |  | — |  |
| Proceeds from issuance of ordinary shares under employee share option plans |  |  | 5,890 |  |  |  | 3,326 |  |
| Withholding tax related to net share settlement of restricted share units |  |  | (1,272 | ) |  |  | (2,372 | ) |
| Net cash provided by financing activities |  |  | 17,401 |  |  |  | 9,948 |  |
| Net (decrease) increase in cash, cash equivalents and restricted cash |  |  | (3,266 | ) |  |  | 15,484 |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 142,804 |  |  |  | 112,978 |  |
| (Decrease) increase in cash, cash equivalents and restricted cash |  |  | (3,266 | ) |  |  | 15,484 |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash |  |  | 271 |  |  |  | (505 | ) |
| Cash, cash equivalents and restricted cash at end of period |  | $ | 139,809 |  |  | $ | 127,957 |  |
| Non-cash investing and financing activities |  |  |  |  |  |  |  |  |
| Construction, software-related and equipment-related payables |  | $ | 12,409 |  |  | $ | 5,068 |  |

[0001193125-17-162642:8k_2_02:48]
6

[0001193125-17-162642:8k_2_02:49]
FABRINET

[0001193125-17-162642:8k_2_02:50]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (CONTINUED)

[0001193125-17-162642:8k_2_02:51]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the unaudited condensed consolidated balance
sheets that sum to the total of same amounts shown in the unaudited condensed consolidated statements of cash flows:

[0001193125-17-162642:8k_2_02:52]
| (amount in thousands) |  | As ofMarch 31,2017 |  |  | As ofMarch 25,2016 |  |
| Cash and cash equivalents |  | $ | 136,634 |  |  | $ | 127,957 |  |
| Restricted cash in connection with business acquisition (non-current assets) |  |  | 3,175 |  |  |  | — |  |
| Cash, cash equivalents and restricted cash |  | $ | 139,809 |  |  | $ | 127,957 |  |

[0001193125-17-162642:8k_2_02:53]
7

[0001193125-17-162642:8k_2_02:54]
FABRINET

[0001193125-17-162642:8k_2_02:55]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-17-162642:8k_2_02:56]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2017 |  |  | March 31,2017 |  |  | March 25,2016 |  |  | March 25,2016 |  |  | March 31,2017 |  |  | March 31,2017 |  |  | March 25,2016 |  |  | March 25,2016 |  |
|  |  | Net income |  |  | DilutedEPS |  |  | Net income |  |  | DilutedEPS |  |  | Net income |  |  | DilutedEPS |  |  | Net income |  |  | DilutedEPS |  |
| GAAP measures |  |  | 21,656 |  |  |  | 0.57 |  |  |  | 20,822 |  |  |  | 0.56 |  |  |  | 69,714 |  |  |  | 1.85 |  |  |  | 42,228 |  |  |  | 1.15 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,657 |  |  |  | 0.04 |  |  |  | 517 |  |  |  | 0.01 |  |  |  | 4,185 |  |  |  | 0.11 |  |  |  | 1,594 |  |  |  | 0.04 |  |
| Depreciation of fair value uplift |  |  | 67 |  |  |  | 0.00 |  |  |  | — |  |  |  | 0.00 |  |  |  | 67 |  |  |  | 0.00 |  |  |  | — |  |  |  | 0.00 |  |
| Total related to gross profit |  |  | 1,724 |  |  |  | 0.05 |  |  |  | 517 |  |  |  | 0.01 |  |  |  | 4,252 |  |  |  | 0.11 |  |  |  | 1,594 |  |  |  | 0.04 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 6,071 |  |  |  | 0.16 |  |  |  | 1,482 |  |  |  | 0.04 |  |  |  | 17,751 |  |  |  | 0.47 |  |  |  | 6,188 |  |  |  | 0.17 |  |
| Executive separation cost |  |  | — |  |  |  | — |  |  |  | 808 |  |  |  | 0.02 |  |  |  | 577 |  |  |  | 0.02 |  |  |  | 1,360 |  |  |  | 0.04 |  |
| Expenses related to CEO search |  |  | 103 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |  |  | 103 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |
| Debt administration expenses |  |  | 320 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 320 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |
| Amortization of intangibles |  |  | 179 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |  |  | 408 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |
| Business combination expenses |  |  | 120 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |  |  | 1,630 |  |  |  | 0.04 |  |  |  | — |  |  |  | — |  |
| Total related to selling, general and administrative expenses |  |  | 6,793 |  |  |  | 0.18 |  |  |  | 2,290 |  |  |  | 0.06 |  |  |  | 20,789 |  |  |  | 0.55 |  |  |  | 7,548 |  |  |  | 0.21 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Income) expense related to flooding |  |  | — |  |  |  | — |  |  |  | (900 | ) |  |  | (0.02 | ) |  |  | — |  |  |  | — |  |  |  | (36 | ) |  |  | (0.00 | ) |
| Loss (gain) on foreign exchange |  |  | — |  |  |  | — |  |  |  | (3,183 | ) |  |  | (0.09 | ) |  |  | (1,713 | ) |  |  | (0.05 | ) |  |  | 2,296 |  |  |  | 0.06 |  |
| Amortization of debt issuance costs |  |  | 283 |  |  |  | 0.01 |  |  |  | 184 |  |  |  | 0.00 |  |  |  | 1,627 |  |  |  | 0.04 |  |  |  | 542 |  |  |  | 0.01 |  |
| Total related to other incomes and other expenses |  |  | 283 |  |  |  | 0.01 |  |  |  | (3,899 | ) |  |  | (0.11 | ) |  |  | (86 | ) |  |  | (0.00 | ) |  |  | 2,802 |  |  |  | 0.08 |  |
| Related to income tax expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense |  |  | — |  |  |  | 0.00 |  |  |  | 1,119 |  |  |  | 0.03 |  |  |  | — |  |  |  | 0.00 |  |  |  | 1,119 |  |  |  | 0.03 |  |
| Total related to net income & EPS |  |  | 8,800 |  |  |  | 0.23 |  |  |  | 27 |  |  |  | 0.00 |  |  |  | 24,955 |  |  |  | 0.66 |  |  |  | 13,063 |  |  |  | 0.36 |  |
| Non-GAAP measures |  |  | 30,456 |  |  |  | 0.80 |  |  |  | 20,849 |  |  |  | 0.56 |  |  |  | 94,669 |  |  |  | 2.50 |  |  |  | 55,291 |  |  |  | 1.50 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 37,872 |  |  |  |  |  |  |  | 37,089 |  |  |  |  |  |  |  | 37,750 |  |  |  |  |  |  |  | 36,743 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 37,872 |  |  |  |  |  |  |  | 37,089 |  |  |  |  |  |  |  | 37,750 |  |  |  |  |  |  |  | 36,743 |  |

[0001193125-17-162642:8k_2_02:57]
8

[0001193125-17-162642:8k_2_02:58]
FABRINET

[0001193125-17-162642:8k_2_02:59]
GUIDANCE FOR QUARTER ENDING JUNE 30, 2017

[0001193125-17-162642:8k_2_02:60]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-17-162642:8k_2_02:61]
|  |  | DilutedEPS |  |
| GAAP net income per diluted share: |  | $ | 0.65 to $0.67 |  |
| Related to cost of revenues: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.05 |  |
| Total related to cost of revenues |  |  | 0.05 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.10 |  |
| Expenses related to CEO search |  |  | 0.01 |  |
| Total related to selling, general and administrative expenses |  |  | 0.11 |  |
| Related to other incomes and other expenses: |  |  |  |  |
| Amortization of debt issuance costs |  |  | 0.01 |  |
| Total related to net income & EPS |  |  | 0.17 |  |
| Non-GAAP net income per diluted share |  | $ | 0.82 to $0.84 |  |
