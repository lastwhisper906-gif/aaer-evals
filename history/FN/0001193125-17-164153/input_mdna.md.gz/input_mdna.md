# FN MD&A — 0001193125-17-164153


## mdna

[0001193125-17-164153:mdna:1]
[same as prior period, unchanged from 0001193125-17-033383:mdna:1]

[0001193125-17-164153:mdna:2]
[same as prior period, unchanged from 0001193125-17-033383:mdna:2]

[0001193125-17-164153:mdna:3]
[same as prior period, unchanged from 0001193125-17-033383:mdna:3]

[0001193125-17-164153:mdna:4]
|  | • |  | our expectation that the portion of our future revenues attributable to customers in regions outside of North America will increase compared with the portion of those revenues for the nine months ended March 31, 2017; |

[0001193125-17-164153:mdna:5]
[same as prior period, unchanged from 0001193125-17-033383:mdna:5]

[0001193125-17-164153:mdna:6]
[same as prior period, unchanged from 0001193125-17-033383:mdna:6]

[0001193125-17-164153:mdna:7]
[same as prior period, unchanged from 0001193125-17-033383:mdna:7]

[0001193125-17-164153:mdna:8]
[same as prior period, unchanged from 0001193125-17-033383:mdna:8]

[0001193125-17-164153:mdna:9]
[same as prior period, unchanged from 0001193125-17-033383:mdna:9]

[0001193125-17-164153:mdna:10]
[same as prior period, unchanged from 0001193125-17-033383:mdna:10]

[0001193125-17-164153:mdna:11]
[same as prior period, unchanged from 0001193125-17-033383:mdna:11]

[0001193125-17-164153:mdna:12]
[same as prior period, unchanged from 0001193125-17-033383:mdna:12]

[0001193125-17-164153:mdna:13]
[same as prior period, unchanged from 0001193125-17-033383:mdna:13]

[0001193125-17-164153:mdna:14]
[same as prior period, unchanged from 0001193125-17-033383:mdna:14]

[0001193125-17-164153:mdna:15]
[same as prior period, unchanged from 0001193125-17-033383:mdna:15]

[0001193125-17-164153:mdna:16]
[same as prior period, unchanged from 0001193125-17-033383:mdna:16]

[0001193125-17-164153:mdna:17]
[same as prior period, unchanged from 0001193125-17-033383:mdna:17]

[0001193125-17-164153:mdna:18]
[same as prior period, unchanged from 0001193125-17-033383:mdna:18]

[0001193125-17-164153:mdna:19]
[same as prior period, unchanged from 0001193125-17-033383:mdna:19]

[0001193125-17-164153:mdna:20]
[same as prior period, unchanged from 0001193125-17-033383:mdna:20]

[0001193125-17-164153:mdna:21]
[same as prior period, unchanged from 0001193125-17-033383:mdna:21]

[0001193125-17-164153:mdna:22]
[same as prior period, unchanged from 0001193125-17-033383:mdna:22]

[0001193125-17-164153:mdna:23]
[same as prior period, unchanged from 0001193125-17-033383:mdna:23]

[0001193125-17-164153:mdna:24]
On September 14, 2016, we acquired 100% shareholding in Global CEM Solutions Ltd. and all of its subsidiaries, a
privately-held group located in Wiltshire, United Kingdom (“Exception EMS”), for cash consideration of approximately $13.0 million, net of cash acquired. This is a strategic acquisition involving new geographies, new sectors and new
customers. Exception EMS provides contract electronics manufacturing services primarily to the European electronics market with innovative solutions, adding value to the design, manufacture and testing of printed circuit board assemblies. Its
customers include industrial, energy, aerospace and defense companies, with approximately 80% of its revenue derived from customers in Europe. See Note 8 - Business acquisition to the unaudited condensed consolidated financial statements for further
details.

[0001193125-17-164153:mdna:25]
[same as prior period, unchanged from 0001193125-17-033383:mdna:25]

[0001193125-17-164153:mdna:26]
During the week
of August 10, 2015, our subsidiary in China temporarily suspended production in its manufacturing facility due to flooding caused by Typhoon Soudelor and resumed operations on August 15, 2015. During the nine months ended March 25,
2016, we recognized $0.04 million of other income related to flooding, net in the unaudited condensed consolidated statements of operations and comprehensive income, which mainly consisted of a final payment of $0.8 million from an insurer against
our claim for flood damage, offset by expenses in relation to flood of $0.8 million.

[0001193125-17-164153:mdna:27]
[same as prior period, unchanged from 0001193125-17-033383:mdna:27]

[0001193125-17-164153:mdna:28]
Our total revenues increased by $115.9 million, or 46.2%, to $366.8 million for the three months ended March 31, 2017, compared with
$250.9 million for the three months ended March 25, 2016. Our total revenues increased by $349.6 million, or 49.9%, to $1,050.0 million for the nine months ended March 31, 2017, compared with $700.4 million for the nine months ended
March 25, 2016. The increase was primarily due to (1) an increase in our customers’ demand for both optical and non-optical communications manufacturing services during the three and nine months ended March 31, 2017, (2) the
positive impact from an additional week of revenue during the nine months ended March 31, 2017, and (3) $6.4 million of revenue for the three months ended March 31, 2017 and $13.4 million of revenue for the nine months ended
March 31, 2017 from companies we acquired in September 2016.

[0001193125-17-164153:mdna:29]
We believe our ability to expand our relationships with existing
customers and attract new customers is due to a number of factors, including our broad range of complex engineering and manufacturing service offerings, flexible low-cost manufacturing platform, process optimization capabilities, advanced supply
chain management, excellent customer service, and experienced management team. While we expect the prices we charge for our manufactured products to decrease over time (partly as a result of competitive market forces), we still believe we will be
able to maintain favorable pricing for our services because of our ability to reduce cycle time, adjust our product mix by focusing on more complicated products, improve product quality and yields, and reduce material costs for the products we
manufacture. We believe these capabilities have enabled us to help our OEM customers reduce their manufacturing costs while maintaining or improving the design, quality, reliability, and delivery times for their products.

[0001193125-17-164153:mdna:30]
[same as prior period, unchanged from 0001193125-17-033383:mdna:30]

[0001193125-17-164153:mdna:31]
[same as prior period, unchanged from 0001193125-17-033383:mdna:31]

[0001193125-17-164153:mdna:32]
The percentage of our revenues generated from a bill-to location outside of North America increased from 44.7% in the three months ended
March 25, 2016 to 57.8% in the three months ended March 31, 2017 and from 47.3% in the nine months ended March 25, 2016 to 54.4% in the nine months ended March 31, 2017, primarily because of an increase in sales to our customers
outside North America, which was partially due to an increase in sales to our customers in Europe due to the acquisition of Exception EMS in September 2016. We expect that the portion of our future revenues attributable to customers in regions
outside North America will continue to increase as compared with the portion of revenues attributable to such customers during the nine months ended March 31, 2017.

[0001193125-17-164153:mdna:33]
[same as prior period, unchanged from 0001193125-17-033383:mdna:33]

[0001193125-17-164153:mdna:34]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2017 |  |  | March 25,2016 |  |  | March 31,2017 |  |  | March 25,2016 |  |
| North America |  |  | 42.2 | % |  |  | 55.3 | % |  |  | 45.6 | % |  |  | 52.7 | % |
| Asia-Pacific |  |  | 40.7 |  |  |  | 35.2 |  |  |  | 38.1 |  |  |  | 36.7 |  |
| Europe |  |  | 17.1 |  |  |  | 9.5 |  |  |  | 16.3 |  |  |  | 10.6 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-17-164153:mdna:35]
[same as prior period, unchanged from 0001193125-17-033383:mdna:35]

[0001193125-17-164153:mdna:36]
[same as prior period, unchanged from 0001193125-17-033383:mdna:36]

[0001193125-17-164153:mdna:37]
[same as prior period, unchanged from 0001193125-17-033383:mdna:37]

[0001193125-17-164153:mdna:38]
[same as prior period, unchanged from 0001193125-17-033383:mdna:38]

[0001193125-17-164153:mdna:39]
[same as prior period, unchanged from 0001193125-17-033383:mdna:39]

[0001193125-17-164153:mdna:40]
[same as prior period, unchanged from 0001193125-17-033383:mdna:40]

[0001193125-17-164153:mdna:41]
[same as prior period, unchanged from 0001193125-17-033383:mdna:41]

[0001193125-17-164153:mdna:42]
During the three and nine months ended March 31, 2017 and March 25, 2016, discretionary merit-based bonus awards were made to our
non-executive employees. Charges included in cost of revenues for bonus awards to non-executive employees were $0.3 million and $0.7 million for the three months ended March 31, 2017 and March 25, 2016, respectively, and $2.2 million and
$2.2 million for the nine months ended March 31, 2017 and March 25, 2016, respectively.

[0001193125-17-164153:mdna:43]
Share-based compensation expense
included in cost of revenues was $1.7 million and $0.5 million for the three months ended March 31, 2017 and March 25, 2016, respectively, and $4.2 million and $1.6 million for the nine months ended March 31, 2017 and March 25,
2016, respectively.

[0001193125-17-164153:mdna:44]
We expect to incur incremental costs of revenue as a result of our planned expansion into new geographic markets,
though we are not able to determine the amount of these incremental expenses.

[0001193125-17-164153:mdna:45]
[same as prior period, unchanged from 0001193125-17-033383:mdna:45]

[0001193125-17-164153:mdna:46]
[same as prior period, unchanged from 0001193125-17-033383:mdna:46]

[0001193125-17-164153:mdna:47]
The
compensation committee of our board of directors approved a fiscal year 2017 executive incentive plan with quantitative objectives, based on achieving certain revenue targets and gross margin targets for our fiscal year ending June 30, 2017.
Bonuses under our fiscal year 2017 executive incentive plan are payable after the end of fiscal year 2017. In fiscal year 2016, the compensation committee approved a fiscal year 2016 executive incentive plan with quantitative objectives, based on
achieving certain revenue and non-GAAP earnings per share targets for our fiscal year ended June 24, 2016, as well as qualitative objectives, based on achieving individual performance goals. In the three months ended September 30, 2016,
the compensation committee awarded bonuses to our executive employees for Company and individual achievements of performance under our fiscal 2016 executive incentive plan. Discretionary merit-based bonus awards were also available to our
non-executive employees and were payable as of March 31, 2017.

[0001193125-17-164153:mdna:48]
Charges included in SG&A expenses for bonus awards to
non-executive and executive employees were $0.8 million and $1.4 million for the three months ended March 31, 2017 and March 25, 2016, respectively, and $2.9 million and $3.6 million for the nine months ended March 31, 2017 and
March 25, 2016, respectively.

[0001193125-17-164153:mdna:49]
Share-based compensation expense included in SG&A expenses was $6.0 million and $1.5 million for
the three months ended March 31, 2017 and March 25, 2016, respectively, and $17.8 million and $6.2 million for the nine months ended March 31, 2017 and March 25, 2016, respectively.

[0001193125-17-164153:mdna:50]
[same as prior period, unchanged from 0001193125-17-033383:mdna:50]

[0001193125-17-164153:mdna:51]
[same as prior period, unchanged from 0001193125-17-033383:mdna:51]

[0001193125-17-164153:mdna:52]
As a result of our international operations, we are exposed to foreign exchange risk arising from various currency exposures primarily with
respect to the Thai baht. Although a majority of our total revenues is denominated in U.S. dollars, a substantial portion of our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rate between the Thai
baht and the U.S. dollar has fluctuated substantially in recent years and may continue to fluctuate substantially in the future. We report our financial results in U.S. dollars and our results of operations have been and could in the future be
negatively impacted if the Thai baht appreciates against the U.S. dollar. Smaller portions of our expenses are incurred in a variety of other currencies, including RMB, GBP, Canadian dollars, Euros, and Japanese yen, the appreciation of which may
also negatively impact our financial results.

[0001193125-17-164153:mdna:53]
In order to manage the risks arising from fluctuations in foreign currency exchange rates,
we use derivative instruments. We may enter into exchange currency forward or put option contracts to manage foreign currency exposures associated with certain assets and liabilities and other forecasted foreign currency transactions and may
designate these instruments as hedging instruments. The forward and put option contracts generally have maturities of up to 12 months. All foreign currency exchange contracts are recognized in the unaudited condensed consolidated balance sheet at
fair value. Gain or loss on our forward and put option contracts generally offset the assets, liabilities, and transactions economically hedged.

[0001193125-17-164153:mdna:54]
We had foreign currency denominated assets and liabilities in Thai baht, RMB and GBP as follows:

[0001193125-17-164153:mdna:55]
|  |  | As of March 31, 2017 |  |  | As of June 24, 2016 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 502,512 |  |  | $ | 14,587 |  |  |  | 48.6 |  |  |  | 834,536 |  |  | $ | 23,594 |  |  |  | 91.3 |  |
| RMB |  |  | 26,244 |  |  |  | 3,804 |  |  |  | 12.7 |  |  |  | 14,835 |  |  |  | 2,255 |  |  |  | 8.7 |  |
| GBP |  |  | 11,633 |  |  |  | 11,633 |  |  |  | 38.7 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  |  |  |  |  | $ | 30,024 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 25,849 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,899,790 |  |  | $ | 55,146 |  |  |  | 83.9 |  |  |  | 1,517,782 |  |  | $ | 42,912 |  |  |  | 92.0 |  |
| RMB |  |  | 30,121 |  |  |  | 4,366 |  |  |  | 6.6 |  |  |  | 24,654 |  |  |  | 3,748 |  |  |  | 8.0 |  |
| GBP |  |  | 5,008 |  |  |  | 6,253 |  |  |  | 9.5 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  |  |  |  |  | $ | 65,765 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 46,660 |  |  |  | 100.0 |  |

[0001193125-17-164153:mdna:56]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other
current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and
offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of March 31, 2017, we did not have derivative contracts denominated in Thai baht. As of June 24, 2016, we had $84.5 million
in forward contracts outstanding against forecasted Thai baht payables.

[0001193125-17-164153:mdna:57]
The RMB assets represent cash and cash equivalents, accounts
receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of March 31, 2017 and June 24, 2016, we did not have any derivative contracts
denominated in RMB.

[0001193125-17-164153:mdna:58]
The GBP assets primarily represent cash, accounts receivable and fixed assets. The GBP liabilities primarily
represent short-term loans, trade accounts payable and other payables. As of March 31, 2017, we did not have any derivative contracts denominated in GBP.

[0001193125-17-164153:mdna:59]
For the nine months ended March 31, 2017 and March 25, 2016, we recorded an unrealized loss of $8 thousand and $2.3 million,
respectively, for the changes in fair value of derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-17-164153:mdna:60]
[same as prior period, unchanged from 0001193125-17-033383:mdna:61]

[0001193125-17-164153:mdna:61]
[same as prior period, unchanged from 0001193125-17-033383:mdna:62]

[0001193125-17-164153:mdna:62]
[same as prior period, unchanged from 0001193125-17-033383:mdna:63]

[0001193125-17-164153:mdna:63]
[same as prior period, unchanged from 0001193125-17-033383:mdna:64]

[0001193125-17-164153:mdna:64]
|  | • |  | Notice on Perfecting Practices Concerning Foreign Exchange Settlement Regarding the Capital Contribution by Foreign-invested Enterprises, as promulgated by the State Administration of Foreign Exchange (“SAFE”), on August 29, 2008, or Circular 142. |

[0001193125-17-164153:mdna:65]
Under the Exchange Rules, RMB is freely convertible into
foreign currencies for current account items, including the distribution of dividends, interest payments, trade and service-related foreign exchange transactions. However, conversion of RMB for capital account items, such as direct investments,
loans, security investments and repatriation of investments, is still subject to the approval of SAFE.

[0001193125-17-164153:mdna:66]
36

[0001193125-17-164153:mdna:67]
Under the Administration Rules, foreign-invested enterprises may only buy, sell, or remit foreign
currencies at banks authorized to conduct foreign exchange business after providing valid commercial documents and relevant supporting documents and, in the case of capital account item transactions, obtaining approval from SAFE. Capital investments
by foreign-invested enterprises outside of the PRC are also subject to limitations, which include approvals by the Ministry of Commerce, SAFE and the State Development and Reform Commission.

[0001193125-17-164153:mdna:68]
Circular 142 regulates the conversion by a foreign-invested company of foreign currency into RMB by restricting how the converted RMB may be
used. Circular 142 requires that the registered capital of a foreign-invested enterprise settled in RMB converted from foreign currencies may only be used for purposes within the business scope approved by the applicable governmental authority and
may not be used for equity investments within the PRC. In addition, SAFE strengthened its oversight of the flow and use of the registered capital of foreign-invested enterprises settled in RMB converted from foreign currencies. The use of such RMB
capital may not be changed without SAFE’s approval and may not be used to repay RMB loans if the proceeds of such loans have not been used.

[0001193125-17-164153:mdna:69]
[same as prior period, unchanged from 0001193125-17-033383:mdna:69]

[0001193125-17-164153:mdna:70]
[same as prior period, unchanged from 0001193125-17-033383:mdna:70]

[0001193125-17-164153:mdna:71]
[same as prior period, unchanged from 0001193125-17-033383:mdna:71]

[0001193125-17-164153:mdna:72]
[same as prior period, unchanged from 0001193125-17-033383:mdna:72]

[0001193125-17-164153:mdna:73]
[same as prior period, unchanged from 0001193125-17-033383:mdna:73]

[0001193125-17-164153:mdna:74]
Throughout the period of our
operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption is currently available to us
through June 2020 on income generated from projects to manufacture certain products at our Pinehurst campus. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and
our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted. In March 2016, the Thailand Revenue Department announced a permanent
decrease of corporate income tax rates to 20% for tax periods beginning on or after January 1, 2016. As a result, the corporate income tax rates for our Thai subsidiary is expected to remain at 20% from fiscal year 2017 onward.

[0001193125-17-164153:mdna:75]
[same as prior period, unchanged from 0001193125-17-033383:mdna:75]

[0001193125-17-164153:mdna:76]
We prepare our unaudited condensed consolidated financial statements in conformity with U.S. GAAP, which requires us to make estimates and
assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent liabilities on the date of the unaudited condensed consolidated financial statements and the reported amounts of revenues and expenses during the
financial reporting period. We continually evaluate these estimates and assumptions based on the most recently available information, our own historical experience and on various other assumptions that we believe

[0001193125-17-164153:mdna:77]
to be reasonable under the circumstances, the results form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources.
Because the use of estimates is an integral component of the financial reporting process, actual results could differ from those estimates. Some of our accounting policies require higher degrees of judgment than others in their application. We
consider the policies discussed below to be critical to an understanding of our unaudited condensed consolidated financial statements, as their application places the most significant demands on our management’s judgment.

[0001193125-17-164153:mdna:78]
Our critical accounting policies are disclosed in our Annual Report on Form 10-K for the fiscal year ended June 24, 2016. The adoption of
new accounting policies and the accounting standards are disclosed in Note 2 – Accounting policies to the unaudited condensed consolidated financial statements.

[0001193125-17-164153:mdna:79]
[same as prior period, unchanged from 0001193125-17-033383:mdna:78]

[0001193125-17-164153:mdna:80]
The following
table sets forth a summary of our unaudited condensed consolidated statements of operations and comprehensive income. Note that period-to-period comparisons of operating results should not be relied upon as indicative of future performance.

[0001193125-17-164153:mdna:81]
| (amount in thousands) |  | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 31,2017 |  |  | March 25,2016 |  |  | March 31,2017 |  |  | March 25,2016 |  |
| Revenues |  | $ | 366,837 |  |  | $ | 250,888 |  |  | $ | 1,050,036 |  |  | $ | 700,359 |  |
| Cost of revenues |  |  | (322,791 | ) |  |  | (219,711 | ) |  |  | (923,336 | ) |  |  | (614,678 | ) |
| Gross profit |  |  | 44,046 |  |  |  | 31,177 |  |  |  | 126,700 |  |  |  | 85,681 |  |
| Selling, general and administrative expenses |  |  | (17,086 | ) |  |  | (12,299 | ) |  |  | (50,569 | ) |  |  | (37,914 | ) |
| Other income related to flooding, net |  |  | — |  |  |  | 900 |  |  |  | — |  |  |  | 36 |  |
| Operating income |  |  | 26,960 |  |  |  | 19,778 |  |  |  | 76,131 |  |  |  | 47,803 |  |
| Interest income |  |  | 713 |  |  |  | 213 |  |  |  | 1,470 |  |  |  | 1,110 |  |
| Interest expense |  |  | (641 | ) |  |  | (335 | ) |  |  | (2,517 | ) |  |  | (1,156 | ) |
| Foreign exchange (loss) gain, net |  |  | (3,702 | ) |  |  | 3,080 |  |  |  | (100 | ) |  |  | (1,246 | ) |
| Other income |  |  | 108 |  |  |  | 57 |  |  |  | 397 |  |  |  | 266 |  |
| Income before income taxes |  |  | 23,438 |  |  |  | 22,793 |  |  |  | 75,381 |  |  |  | 46,777 |  |
| Income tax expense |  |  | (1,782 | ) |  |  | (1,971 | ) |  |  | (5,667 | ) |  |  | (4,549 | ) |
| Net income |  |  | 21,656 |  |  |  | 20,822 |  |  |  | 69,714 |  |  |  | 42,228 |  |
| Other comprehensive gain (loss), net of tax |  |  | 276 |  |  |  | 1,014 |  |  |  | (1,584 | ) |  |  | 791 |  |
| Net comprehensive income |  | $ | 21,932 |  |  | $ | 21,836 |  |  | $ | 68,130 |  |  | $ | 43,019 |  |

[0001193125-17-164153:mdna:82]
[same as prior period, unchanged from 0001193125-17-033383:mdna:81]

[0001193125-17-164153:mdna:83]
[same as prior period, unchanged from 0001193125-17-033383:mdna:82]

[0001193125-17-164153:mdna:84]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 31,2017 |  |  | March 25,2016 |  |  | March 31,2017 |  |  | March 25,2016 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (88.0 | ) |  |  | (87.6 | ) |  |  | (87.9 | ) |  |  | (87.8 | ) |
| Gross profit |  |  | 12.0 |  |  |  | 12.4 |  |  |  | 12.1 |  |  |  | 12.2 |  |
| Selling, general and administrative expenses |  |  | (4.6 | ) |  |  | (4.9 | ) |  |  | (4.8 | ) |  |  | (5.4 | ) |
| Other income related to flooding, net |  |  | — |  |  |  | 0.4 |  |  |  | — |  |  |  | 0.0 |  |
| Operating income |  |  | 7.4 |  |  |  | 7.9 |  |  |  | 7.3 |  |  |  | 6.8 |  |
| Interest income |  |  | 0.2 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.2 |  |
| Interest expense |  |  | (0.2 | ) |  |  | (0.1 | ) |  |  | (0.2 | ) |  |  | (0.2 | ) |
| Foreign exchange (loss) gain, net |  |  | (1.0 | ) |  |  | 1.2 |  |  |  | 0.0 |  |  |  | (0.2 | ) |
| Other income |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Income before income taxes |  |  | 6.4 |  |  |  | 9.1 |  |  |  | 7.3 |  |  |  | 6.7 |  |
| Income tax expense |  |  | (0.5 | ) |  |  | (0.8 | ) |  |  | (0.6 | ) |  |  | (0.7 | ) |
| Net income |  |  | 5.9 |  |  |  | 8.3 |  |  |  | 6.6 |  |  |  | 6.0 |  |
| Other comprehensive loss, net of tax |  |  | 0.1 |  |  |  | 0.4 |  |  |  | (0.1 | ) |  |  | 0.1 |  |
| Net comprehensive income |  |  | 6.0 | % |  |  | 8.7 | % |  |  | 6.5 | % |  |  | 6.1 | % |

[0001193125-17-164153:mdna:85]
[same as prior period, unchanged from 0001193125-17-033383:mdna:84]

[0001193125-17-164153:mdna:86]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 31,2017 |  |  | March 25,2016 |  |  | March 31,2017 |  |  | March 25,2016 |  |
| Optical communications |  | $ | 286,870 |  |  | $ | 192,173 |  |  | $ | 817,922 |  |  | $ | 515,629 |  |
| Lasers, sensors and other |  |  | 79,967 |  |  |  | 58,715 |  |  |  | 232,114 |  |  |  | 184,730 |  |
| Total |  | $ | 366,837 |  |  | $ | 250,888 |  |  | $ | 1,050,036 |  |  | $ | 700,359 |  |

[0001193125-17-164153:mdna:87]
[same as prior period, unchanged from 0001193125-17-033383:mdna:86]

[0001193125-17-164153:mdna:88]
Comparison of Three and Nine Months Ended March 31, 2017 with Three and Nine Months
Ended March 25, 2016

[0001193125-17-164153:mdna:89]
[same as prior period, unchanged from 0001193125-17-033383:mdna:88]

[0001193125-17-164153:mdna:90]
Our total revenues increased by $115.9 million, or 46.2%, to $366.8 million for the three months ended March 31, 2017, compared with
$250.9 million for the three months ended March 25, 2016. This increase was primarily due to an increase in our customers’ demand for both optical and non-optical communications manufacturing services during the three months ended
March 31, 2017 and $6.4 million of revenue from companies we acquired in September 2016. Revenues from optical communications products represented 78.2% of our total revenues for the three months ended March 31, 2017, compared to 76.6% for
the three months ended March 25, 2016.

[0001193125-17-164153:mdna:91]
Our total revenues increased by $349.7 million, or 49.9%, to $1,050.0 million for the nine
months ended March 31, 2017, compared with $700.4 million for the nine months ended March 25, 2016. This increase was primarily due to (1) an increase in our customers’ demand for both optical and non-optical communications
manufacturing services during the nine months ended March 31, 2017, (2) the positive impact from an additional week of revenue during the nine months ended March 31, 2017, and (3) $13.4 million of revenue from companies we
acquired in September 2016. Revenues from optical communications products represented 77.9% of our total revenues for the nine months ended March 31, 2017, compared to 73.6% for the nine months ended March 25, 2016.

[0001193125-17-164153:mdna:92]
[same as prior period, unchanged from 0001193125-17-033383:mdna:91]

[0001193125-17-164153:mdna:93]
Our cost of revenues increased by $103.1 million, or 46.9%, to $322.8 million, or 88.0% of total revenues, for the three months ended
March 31, 2017, compared with $219.7 million, or 87.6% of total revenues, for the three months ended March 25, 2016. The increase in cost of revenues was primarily due to a proportional increase in sales volume.

[0001193125-17-164153:mdna:94]
Our cost of revenues increased by $308.7 million, or 50.2%, to $923.3 million, or 87.9% of total revenues, for the nine months ended
March 31, 2017, compared with $614.7 million, or 87.8% of total revenues, for the nine months ended March 25, 2016. The increase in cost of revenues was primarily due to a proportional increase in sales volume. The increase in cost of
revenues also included an increase of $2.6 million in share-based compensation expenses, primarily due to a higher number of restricted share units granted to our executives when compared to the prior period.

[0001193125-17-164153:mdna:95]
[same as prior period, unchanged from 0001193125-17-033383:mdna:94]

[0001193125-17-164153:mdna:96]
Our gross
profit increased by $12.9 million, or 41.3%, to $44.0 million, or 12.0% of total revenues, for the three months ended March 31, 2017, compared with $31.2 million, or 12.4% of total revenues, for the three months ended March 25, 2016. Our
gross profit increased by $41.0 million, or 47.9%, to $126.7 million, or 12.1% of total revenues, for the nine months ended March 31, 2017, compared with $85.7 million, or 12.2% of total revenues, for the nine months ended March 25, 2016.

[0001193125-17-164153:mdna:97]
[same as prior period, unchanged from 0001193125-17-033383:mdna:96]

[0001193125-17-164153:mdna:98]
Our SG&A expenses increased by $4.8 million, or 38.9%, to $17.1 million, or 4.6% of total revenues, for the three months ended
March 31, 2017, compared with $12.3 million, or 4.9% of total revenues, for the three months ended March 25, 2016. Our SG&A expenses increased in absolute dollars primarily due to an increase of $4.6 million in share-based compensation
expenses, partially due to the recognition of $1.5 million related to accelerated vesting of executive equity awards during the three months ended March 31, 2017.

[0001193125-17-164153:mdna:99]
Our SG&A expenses increased by $12.7 million, or 33.4%, to $50.6 million, or 4.8% of total revenues, for the nine months ended
March 31, 2017, compared with $37.9 million, or 5.4% of total revenues, for the nine months ended March 25, 2016. Our SG&A expenses increased in absolute dollars primarily due to an increase of $1.5 million in expenses related to
merger and acquisition activities, and an increase in share-based compensation expenses of $11.6 million, partially due to the recognition of $4.3 million related to accelerated vesting of executive equity awards during the nine months ended
March 31, 2017.

[0001193125-17-164153:mdna:100]
Other income related to flooding, net.

[0001193125-17-164153:mdna:101]
In the three and nine months ended March 31, 2017, we did not have any income related to flooding. In the three months ended
March 25, 2016, we recognized other income related to flooding, net of $0.9 million. In the nine months ended March 25, 2016, we recognized other income related to flooding, net of $0.04 million, which mainly consisted of $0.8 million from
an insurer against our claim for flood damage, offset by expenses in relation to flood of $0.8 million.

[0001193125-17-164153:mdna:102]
[same as prior period, unchanged from 0001193125-17-033383:mdna:101]

[0001193125-17-164153:mdna:103]
Our operating income increased by $7.2 million to $27.0 million, or 7.4% of total revenues, for the three months ended March 31, 2017,
compared with $19.8 million, or 7.9% of total revenues, for the three months ended March 25, 2016.

[0001193125-17-164153:mdna:104]
Our operating income increased by
$28.3 million to $76.1 million, or 7.3% of total revenues, for the nine months ended March 31, 2017, compared with $47.8 million, or 6.8% of total revenues, for the nine months ended March 25, 2016.

[0001193125-17-164153:mdna:105]
[same as prior period, unchanged from 0001193125-17-033383:mdna:104]

[0001193125-17-164153:mdna:106]
Our
interest income increased by $0.5 million to $0.7 million, or 0.2% of total revenues, for the three months ended March 31, 2017, compared with $0.2 million, or 0.1% of total revenues, for the three months ended March 25, 2016. Our

[0001193125-17-164153:mdna:107]
interest income increased by $0.4 million to $1.5 million, or 0.1% of total revenues, for the nine months ended March 31, 2017, compared with $1.1 million, or 0.2% of total revenues, for the
nine months ended March 25, 2016. The increase was primarily due to an increase in our average outstanding cash balance.

[0001193125-17-164153:mdna:108]
Interest
expense.

[0001193125-17-164153:mdna:109]
Our interest expense increased by $0.3 million to $0.6 million for the three months ended March 31, 2017, compared with
$0.3 million for the three months ended March 25, 2016. Our interest expense increased by $1.4 million to $2.5 million for the nine months ended March 31, 2017, compared with $1.2 million for the nine months ended March 25, 2016. The
increase was primarily due to an increase in the average balance of our outstanding bank borrowings.

[0001193125-17-164153:mdna:110]
Foreign exchange (loss) gain,
net.

[0001193125-17-164153:mdna:111]
Our foreign exchange (loss) gain, net, decreased by $6.8 million to foreign exchange (loss), net, of $(3.7) million, or (1.0)% of
total revenues, for the three months ended March 31, 2017, compared with foreign exchange gain, net, of $3.1 million, or 1.2% of total revenues, for the three months ended March 25, 2016. The decrease was due to the Thai Baht strengthening
which resulted in foreign exchange loss upon the revaluation of our net Thai Baht liabilities.

[0001193125-17-164153:mdna:112]
Our foreign exchange (loss) gain, net,
increased by $1.2 million to foreign exchange (loss), net, of $(0.1) million, or 0.0% of total revenues, for the nine months ended March 31, 2017, compared with foreign exchange loss, net, of $(1.2) million, or (0.2)% of total revenues, for the
nine months ended March 25, 2016. The increase was due to changes in the fair value of forward contracts as of March 31, 2017 that were not designated as hedging instruments.

[0001193125-17-164153:mdna:113]
[same as prior period, unchanged from 0001193125-17-033383:mdna:111]

[0001193125-17-164153:mdna:114]
We recorded income before income taxes of $23.4 million and $75.4 million for the three and nine months ended March 31, 2017,
respectively, compared with $22.8 million and $46.8 million for the three and nine months ended March 25, 2016, respectively.

[0001193125-17-164153:mdna:115]
[same as prior period, unchanged from 0001193125-17-033383:mdna:113]

[0001193125-17-164153:mdna:116]
Our
provision for income tax reflects an effective tax rate of 6.5% for the three months ended March 31, 2017, compared with an effective tax rate of 5.8% for the three months ended March 25, 2016. The increase was primarily due to the fact
that we had higher taxable income during the three months ended March 31, 2017, compared with the three months ended March 25, 2016.

[0001193125-17-164153:mdna:117]
Our provision for income tax reflects an effective tax rate of 6.7% for nine months ended March 31, 2017, compared with an effective tax
rate of 6.4% for the nine months ended March 25, 2016. The increase was primarily due to the fact that we had higher taxable income during the nine months ended March 31, 2017, compared with the nine months ended March 25, 2016.

[0001193125-17-164153:mdna:118]
[same as prior period, unchanged from 0001193125-17-033383:mdna:116]

[0001193125-17-164153:mdna:119]
We recorded
net income of $21.7 million, or 5.9% of total revenues, for the three months ended March 31, 2017, compared with $20.8 million, or 8.3% of total revenues, for the three months ended March 25, 2016.

[0001193125-17-164153:mdna:120]
We recorded net income of $69.7 million, or 6.6% of total revenues, for the nine months ended March 31, 2017, compared with $42.2
million, or 6.0% of total revenues, for the nine months ended March 25, 2016.

[0001193125-17-164153:mdna:121]
Other comprehensive gain (loss), net of tax.

[0001193125-17-164153:mdna:122]
We recorded other comprehensive gain (loss), net of tax of $0.2 million, or 0.1% of total revenues, for the three months ended March 31,
2017, compared with other comprehensive gain (loss), net of tax of $1.0 million, or 0.4% of total revenues, for the three months ended March 25, 2016. The decrease was primarily due to no forward contracts being designated as hedging
instruments as of March 31, 2017. As such, there was no unrealized gain (loss) from changes in fair value of foreign currency contracts.

[0001193125-17-164153:mdna:123]
We recorded other comprehensive gain (loss), net of tax of $1.6 million, or 0.2% of total revenues, for the nine months ended March 31,
2017, compared with other comprehensive gain (loss), net of tax of $0.8 million, or 0.1% of total revenues, for the nine months ended March 25, 2016. The decrease was primarily due to loss from foreign currency translation adjustment of $0.9
million in connection with the operations of Exception EMS.

[0001193125-17-164153:mdna:124]
[same as prior period, unchanged from 0001193125-17-033383:mdna:122]

[0001193125-17-164153:mdna:125]
[same as prior period, unchanged from 0001193125-17-033383:mdna:123]

[0001193125-17-164153:mdna:126]
We
primarily finance our operations through cash flow from operations. As of March 31, 2017 and March 25, 2016, we had cash, cash equivalents, and marketable securities of $289.2 million and $272.8 million, respectively, and outstanding debt
of $75.1 million and $50.0 million, respectively.

[0001193125-17-164153:mdna:127]
Our cash and cash equivalents, which primarily consist of cash on hand, demand
deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents for the three and nine months ended
March 31, 2017 was 0.6% and 0.5%, respectively, and for the three and nine months ended March 25, 2016 was 0.5% and 0.9%, respectively.

[0001193125-17-164153:mdna:128]
Our cash investments are made in accordance with an investment policy approved by the Audit Committee of our Board of Directors. In general,
our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed income securities are classified as available-for-sale and are
recorded at fair value. The cost of securities sold is based on the specific identification method. Unrealized gains and losses on these securities are recorded as other comprehensive gain (loss), net of tax and are reported as a separate component
of shareholders’ equity.

[0001193125-17-164153:mdna:129]
During the nine months ended March 31, 2017, we borrowed a revolving loan of $27.5 million and repaid
a term loan of $10.2 million under our Facility Agreement; as a result, as of March 31, 2017, we had an outstanding long-term borrowing of $39.8 million and short-term borrowing of $34.0 million under our Facility Agreement. We anticipate that
our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held investments in short-term marketable securities of $152.6 million as of
March 31, 2017.

[0001193125-17-164153:mdna:130]
We believe that our current cash and cash equivalents, marketable securities, cash flow from operations, and funds
available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in
Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001193125-17-164153:mdna:131]
In December 2015, we began construction of a new manufacturing facility
at our Chonburi campus, which we substantially completed in the first quarter of fiscal year 2017. We will continue renovating the facilities and expect to begin substantial operations at this new facility in the fourth quarter of fiscal year 2017.
We believe that our current manufacturing capacity is sufficient to meet our anticipated production requirements for at least the next few quarters. We maintain a long-term loan associated with construction of production facilities at our Pinehurst
campus in Thailand that will come due within the next 12 months.

[0001193125-17-164153:mdna:132]
[same as prior period, unchanged from 0001193125-17-033383:mdna:130]

[0001193125-17-164153:mdna:133]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 31,2017 |  |  | March 25,2016 |  |
| Net cash provided by operating activities |  | $ | 60,388 |  |  | $ | 41,356 |  |
| Net cash used in investing activities |  | $ | (81,055 | ) |  | $ | (35,820 | ) |
| Net cash provided by financing activities |  | $ | 17,401 |  |  | $ | 9,948 |  |
| Net (decrease) increase in cash, cash equivalents and restricted cash |  | $ | (3,266 | ) |  | $ | 15,484 |  |

[0001193125-17-164153:mdna:134]
[same as prior period, unchanged from 0001193125-17-033383:mdna:132]

[0001193125-17-164153:mdna:135]
Net cash provided by operating activities increased by $19.0 million, or 46.0%, to $60.4 million for the nine months ended March 31, 2017,
compared with net cash provided by operating activities of $41.4 million for the nine months ended March 25, 2016. This increase was due to a number of factors, including an increase in net income of $27.5 million, depreciation and amortization
of $4.2 million, and share-based compensation of $14.2 million. These were offset by increases in accounts receivable of $13.8 million and inventory of $20.5 million due to higher sales and customer demand, as compared with the nine months ended
March 25, 2016.

[0001193125-17-164153:mdna:136]
[same as prior period, unchanged from 0001193125-17-033383:mdna:134]

[0001193125-17-164153:mdna:137]
Net cash used in investing activities increased by $45.2 million, or 126.3%, to $81.1 million for the nine months ended March 31, 2017,
compared with net cash used in investing activities of $35.8 million for the nine months ended March 25, 2016. This increase was primarily due to an increase of $23.7 million in the purchase of property, plant and equipment primarily for our
new facility in Chonburi, Thailand, a net increase of $9.6 million in marketable securities and the net payment of $9.9 million in connection with the acquisition of Exception EMS.

[0001193125-17-164153:mdna:138]
[same as prior period, unchanged from 0001193125-17-033383:mdna:136]

[0001193125-17-164153:mdna:139]
Net
cash provided by financing activities increased by $7.5 million, or 74.9%, to $17.4 million for the nine months ended March 31, 2017, compared with net cash provided by financing activities of $9.9 million for the nine months ended
March 25, 2016. This increase was primarily due to an increase of $9.7 million in proceeds of short-term loans from banks, offset by an increase of $6.2 million in repayment of long-term loans from banks.

[0001193125-17-164153:mdna:140]
Off-Balance Sheet Commitments and Arrangements

[0001193125-17-164153:mdna:141]
We have not entered into any financial guarantees or other commitments to guarantee the payment obligations of any third parties. In addition,
we have not entered into any derivative contracts that are not reflected in our unaudited condensed consolidated financial statements. Furthermore, we do not have any retained or contingent interest in assets transferred to an unconsolidated entity
that serves as credit, liquidity or market risk support to such entity. We also do not have any variable interest in any unconsolidated entity that provides financing, liquidity, market risk or credit support to us or engages in leasing, hedging or
research and development services with us.

[0001193125-17-164153:mdna:142]
[same as prior period, unchanged from 0001193125-17-033383:mdna:140]

[0001193125-17-164153:mdna:143]
[same as prior period, unchanged from 0001193125-17-033383:mdna:141]
