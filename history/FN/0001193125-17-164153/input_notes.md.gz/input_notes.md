# FN notes — 0001193125-17-164153


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-17-164153:notes:1]
The following table summarizes the cost and estimated fair value of
 marketable securities classified as available-for-sale securities
 based on stated effective maturities as of March 31, 2017:

[0001193125-17-164153:notes:2]
| (amount in thousands) |  | Carrying Cost |  |  | Fair Value |  |
| Due within one year |  | $ | 21,222 |  |  | $ | 21,214 |  |
| Due between one to three years |  |  | 131,477 |  |  |  | 131,394 |  |
| Total |  | $ | 152,699 |  |  | $ | 152,608 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-17-164153:notes:3]
| 16. | Commitments and contingencies |

[0001193125-17-164153:notes:4]
Collateral assets

[0001193125-17-164153:notes:5]
As of March 31, 2017 and June 24, 2016, certain property,
 plant and equipment of a subsidiary of $45.9 million and $47.7
 million were pledged as collateral to overdraft facilities, letter
 of guarantee and foreign exchange lines, respectively. In April
 2017, the bank released certain property, plant and equipment of
 the subsidiary which had been secured and pledged as collateral to
 such items.

[0001193125-17-164153:notes:6]
Bank guarantees

[0001193125-17-164153:notes:7]
As of March 31, 2017 and June 24, 2016, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $1.5 million and $0.8 million, respectively.

[0001193125-17-164153:notes:8]
Operating lease commitments

[0001193125-17-164153:notes:9]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, New Jersey and the United Kingdom under operating
 lease arrangements that expire in various calendar years through
 2023. Rental expense under these operating leases amounted to $1.2
 million and $0.9 million for the nine months ended March 31,
 2017 and March 25, 2016, respectively.

[0001193125-17-164153:notes:10]
As of March 31, 2017, the future minimum lease payments due
 under non-cancelable operating leases during each fiscal year were
 as follows:

[0001193125-17-164153:notes:11]
| (amount in thousands) |  |  |  |
| 2017 (remaining three months) |  | $ | 439 |  |
| 2018 |  |  | 1,663 |  |
| 2019 |  |  | 1,116 |  |
| 2020 |  |  | 911 |  |
| 2021 |  |  | 510 |  |
| Thereafter |  |  | 897 |  |
| Total minimum operating lease payments |  | $ | 5,536 |  |

[0001193125-17-164153:notes:12]
Capital lease commitments

[0001193125-17-164153:notes:13]
In connection with the acquisition of Exception EMS, the Company
 assumed the capital lease commitments of several machines and
 equipment, with various expiration dates until September 2020. The
 equipment can be purchased at the determined prices upon expiration
 of such contracts.

[0001193125-17-164153:notes:14]
As of March 31, 2017, the future minimum lease payments due
 under non-cancelable capital leases during each fiscal year were as
 follows:

[0001193125-17-164153:notes:15]
| (amount in thousands) |  |  |  |
| 2017 (remaining three months) |  | $ | 92 |  |
| 2018 |  |  | 393 |  |
| 2019 |  |  | 426 |  |
| 2020 |  |  | 391 |  |
| 2021 |  |  | 101 |  |
| Total minimum capital lease payments |  | $ | 1,403 |  |

[0001193125-17-164153:notes:16]
Purchase obligations

[0001193125-17-164153:notes:17]
Purchase obligations represent legally-binding commitments to
 purchase inventory and other commitments made in the normal course
 of business to meet operational requirements. Although open
 purchase orders are considered enforceable and legally binding,
 their terms generally give the Company the option to cancel,
 reschedule and/or adjust its requirements based on its business
 needs prior to the delivery of goods or performance of services.
 Obligations to purchase inventory and other commitments are
 generally expected to be fulfilled within one year.

[0001193125-17-164153:notes:18]
On December 23, 2016, the Company entered into an agreement to
 purchase a parcel of land in Chonburi, Thailand, to support the
 expansion of the Company’s production in Thailand. The
 aggregate purchase price is approximately $5.6 million, of which
 the first installment of $1.1 million was paid by the Company on
 January 10, 2017. The Company expects to pay the remaining
 balance of the purchase price on or before December 25,
 2017.

[0001193125-17-164153:notes:19]
As of March 31, 2017, the Company had an outstanding
 commitment to third parties of approximately $12.1 million.

[0001193125-17-164153:notes:20]
Indemnification of directors and officers

[0001193125-17-164153:notes:21]
Cayman Islands law does not limit the extent to which a
 company’s memorandum and articles of association may provide
 for indemnification of directors and officers, except to the extent
 any such provision may be held by the Cayman Islands courts to be
 contrary to public policy, such as to provide indemnification
 against civil fraud or the consequences of committing a crime.
 Fabrinet’s amended and restated memorandum and articles of
 association provide for indemnification of directors and officers
 for actions, costs, charges, losses, damages and expenses incurred
 in their capacities as such, except that such indemnification does
 not extend to any matter in respect of any fraud or dishonesty that
 may attach to any of them.

[0001193125-17-164153:notes:22]
In accordance with Fabrinet’s form of indemnification
 agreement for its directors and officers, Fabrinet has agreed to
 indemnify its directors and officers against certain liabilities
 and expenses incurred by such persons in connection with claims by
 reason of their being such a director or officer. Fabrinet
 maintains a director and officer liability insurance policy that
 may enable it to recover a portion of any future amounts paid under
 the indemnification agreements.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-17-164153:notes:23]
[same as prior period, unchanged from 0001193125-17-033383:notes:21]

[0001193125-17-164153:notes:24]
[same as prior period, unchanged from 0001193125-17-033383:notes:22]

[0001193125-17-164153:notes:25]
[same as prior period, unchanged from 0001193125-17-033383:notes:23]

[0001193125-17-164153:notes:26]
The effect of recording share-based compensation expense for the
 three and nine months ended March 31, 2017 and March 25,
 2016 was as follows:

[0001193125-17-164153:notes:27]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 31, 2017 |  |  | March 25, 2016 |  |  | March 31, 2017 |  |  | March 25, 2016 |  |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share options |  | $ | — |  |  | $ | (1 | ) |  | $ | — |  |  | $ | 17 |  |
| Restricted share units |  |  | 6,540 |  |  |  | 2,000 |  |  |  | 18,993 |  |  |  | 7,765 |  |
| Performance share units |  |  | 1,188 |  |  |  | — |  |  |  | 2,943 |  |  |  | — |  |
| Total share-based compensation expense |  |  | 7,728 |  |  |  | 1,999 |  |  |  | 21,936 |  |  |  | 7,782 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 7,728 |  |  | $ | 1,999 |  |  | $ | 21,936 |  |  | $ | 7,782 |  |

[0001193125-17-164153:notes:28]
[same as prior period, unchanged from 0001193125-17-033383:notes:26]

[0001193125-17-164153:notes:29]
|  |  | Three Months ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 31, 2017 |  |  | March 25, 2016 |  |  | March 31, 2017 |  |  | March 25, 2016 |  |
| Cost of revenue |  | $ | 1,657 |  |  | $ | 517 |  |  | $ | 4,185 |  |  | $ | 1,594 |  |
| Selling, general and administrative expense |  |  | 6,071 |  |  |  | 1,482 |  |  |  | 17,751 |  |  |  | 6,188 |  |
| Total share-based compensation expense |  | $ | 7,728 |  |  | $ | 1,999 |  |  | $ | 21,936 |  |  | $ | 7,782 |  |

[0001193125-17-164153:notes:30]
The Company did not capitalize any share-based compensation expense
 as part of any asset costs during the three and nine months ended
 March 31, 2017 and March 25, 2016.

[0001193125-17-164153:notes:31]
[same as prior period, unchanged from 0001193125-17-033383:notes:29]

[0001193125-17-164153:notes:32]
Share options have been granted to directors and employees. As of
 March 31, 2017, there were no share options outstanding under
 Fabrinet’s Amended and Restated 1999 Share Option Plan (the
 “1999 Plan”). Additional option grants may not be made
 under the 1999 Plan.

[0001193125-17-164153:notes:33]
As of March 31, 2017, there were an aggregate of 96,688 share
 options outstanding, 1,072,189 restricted share units outstanding
 and 234,678 performance share units outstanding under
 Fabrinet’s 2010 Performance Incentive Plan (the “2010
 Plan”). As of March 31, 2017, there were 1,176,631
 ordinary shares available for future grant under the 2010 Plan. The
 1999 Plan and 2010 Plan are collectively referred to as the
 “Share Option Plans.”

[0001193125-17-164153:notes:34]
[same as prior period, unchanged from 0001193125-17-033383:notes:32]

[0001193125-17-164153:notes:35]
[same as prior period, unchanged from 0001193125-17-033383:notes:33]

[0001193125-17-164153:notes:36]
[same as prior period, unchanged from 0001193125-17-033383:notes:34]

[0001193125-17-164153:notes:37]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price Per Share |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 24, 2016 |  |  | 464,334 |  |  |  | 464,334 |  |  | $ | 15.95 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (367,641 | ) |  |  |  |  |  | $ | 16.02 |  |  |  |  |  |
| Forfeited |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Expired |  |  | (5 | ) |  |  |  |  |  | $ | 5.75 |  |  |  |  |  |
| Balance as of March 31, 2017 |  |  | 96,688 |  |  |  | 96,688 |  |  | $ | 15.70 |  |  |  |  |  |

[0001193125-17-164153:notes:38]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price Per Share |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 26, 2015 |  |  | 792,019 |  |  |  | 758,451 |  |  | $ | 16.33 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (198,334 | ) |  |  |  |  |  | $ | 16.77 |  |  |  |  |  |
| Forfeited |  |  | (755 | ) |  |  |  |  |  | $ | 17.10 |  |  |  |  |  |
| Expired |  |  | (1,400 | ) |  |  |  |  |  | $ | 23.62 |  |  |  |  |  |
| Balance as of March 25, 2016 |  |  | 591,530 |  |  |  | 591,488 |  |  | $ | 16.16 |  |  |  |  |  |

[0001193125-17-164153:notes:39]
The following summarizes information for share options outstanding
 as of March 31, 2017 under the Share Option Plans:

[0001193125-17-164153:notes:40]
|  |  | Range of Exercise Price |  |  | Number of Shares Underlying Options |  |  | Weighted- Average Remaining Contractual Life (years) |  |  | Aggregate Intrinsic Value (amount in thousands) |  |
|  |  |  | $14.12 – $15.05 |  |  |  | 55,238 |  |  |  | 1.06 |  |  |  |  |  |
|  |  |  | $15.16 – $16.83 |  |  |  | 34,400 |  |  |  | 0.69 |  |  |  |  |  |
|  |  |  | $18.60 – $26.16 |  |  |  | 7,050 |  |  |  | 1.68 |  |  |  |  |  |
| Options outstanding |  |  |  |  |  |  | 96,688 |  |  |  | 0.97 |  |  | $ | 2,546 |  |
| Options exercisable |  |  |  |  |  |  | 96,688 |  |  |  | 0.97 |  |  | $ | 2,546 |  |

[0001193125-17-164153:notes:41]
As of March 31, 2017, there was no unrecognized compensation
 cost for share options issued under the Share Option Plans.

[0001193125-17-164153:notes:42]
[same as prior period, unchanged from 0001193125-17-033383:notes:40]

[0001193125-17-164153:notes:43]
[same as prior period, unchanged from 0001193125-17-033383:notes:41]

[0001193125-17-164153:notes:44]
[same as prior period, unchanged from 0001193125-17-033383:notes:42]

[0001193125-17-164153:notes:45]
The Company has entered into an employment agreement, as amended on
 August 12, 2016, with one executive of the Company that
 provides for accelerated vesting of equity awards under certain
 circumstances, including upon termination of employment. In
 addition, pursuant to such agreement, because the executive’s
 employment with the Company continued through February 20,
 2017, (1) all outstanding equity awards granted to the
 executive prior to August 2016 became 100% vested on
 February 20, 2017 and (2) certain restricted share units
 granted to the executive in August 2016 became 100% vested on
 February 20, 2017.

[0001193125-17-164153:notes:46]
[same as prior period, unchanged from 0001193125-17-033383:notes:44]

[0001193125-17-164153:notes:47]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 24, 2016 |  |  | 1,181,402 |  |  | $ | 18.34 |  |
| Granted |  |  | 796,298 |  |  | $ | 39.42 |  |
| Issued |  |  | (835,785 | ) |  | $ | 21.01 |  |
| Forfeited |  |  | (69,726 | ) |  | $ | 25.33 |  |
| Balance as of March 31, 2017 |  |  | 1,072,189 |  |  | $ | 31.57 |  |

[0001193125-17-164153:notes:48]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 26, 2015 |  |  | 1,140,927 |  |  | $ | 16.03 |  |
| Granted |  |  | 586,142 |  |  | $ | 19.82 |  |
| Issued |  |  | (492,124 | )(1) |  | $ | 15.53 |  |
| Forfeited |  |  | (86,343 | ) |  | $ | 17.44 |  |
| Balance as of March 25, 2016 |  |  | 1,148,602 |  |  | $ | 17.56 |  |

[0001193125-17-164153:notes:49]
| (1) | Includes 283 shares vested on March 25, 2016, but not settled. |

[0001193125-17-164153:notes:50]
[same as prior period, unchanged from 0001193125-17-033383:notes:48]

[0001193125-17-164153:notes:51]
|  |  | Number of Shares |  |  | Weighted-Average Grant Date Fair Value Per Share |  |
| Balance as of June 24, 2016 |  |  | — |  |  |  | — |  |
| Granted |  |  | 234,678 |  |  | $ | 40.48 |  |
| Issued |  |  | — |  |  |  | — |  |
| Forfeited |  |  | — |  |  |  | — |  |
| Balance as of March 31, 2017 |  |  | 234,678 |  |  | $ | 40.48 |  |

[0001193125-17-164153:notes:52]
As of March 31, 2017, there was $25.7 million of unrecognized
 share-based compensation expense related to restricted share units
 and performance share units under the 2010 Plan that is expected to
 be recorded over a weighted-average period of 2.10 years.

[0001193125-17-164153:notes:53]
For the nine months ended March 31, 2017 and March 25,
 2016, the Company withheld an aggregate of 33,276 shares and
 111,584 shares, respectively, upon the vesting of restricted share
 units, based upon the closing share price on the vesting date to
 settle the employees’ minimum statutory obligation for the
 applicable income and other employment taxes. For the nine months
 ended March 31, 2017 and March 25, 2016, the Company then
 remitted cash of $1.3 million and $2.4 million, respectively, to
 the appropriate taxing authorities, and presented it as a financing
 activity within the unaudited condensed consolidated statements of
 cash flows. The payment had the effect on shares issued by the
 Company as it reduced the number of shares that would have been
 issued on the vesting date and was recorded as a reduction of
 additional paid-in capital.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-17-164153:notes:54]
[same as prior period, unchanged from 0001193125-17-033383:notes:52]

[0001193125-17-164153:notes:55]
| (amount in thousands) |  | As of March 31, 2017 |  |  | As of June 24, 2016 |  |
| Raw materials |  | $ | 64,715 |  |  | $ | 58,199 |  |
| Work in progress |  |  | 114,844 |  |  |  | 94,762 |  |
| Finished goods |  |  | 31,662 |  |  |  | 21,593 |  |
| Goods in transit |  |  | 16,013 |  |  |  | 9,381 |  |
|  |  |  | 227,234 |  |  |  | 183,935 |  |
| Less: Inventory obsolescence |  |  | (2,607 | ) |  |  | (2,436 | ) |
| Inventory, net |  | $ | 224,627 |  |  | $ | 181,499 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-17-164153:notes:56]
New Accounting Pronouncements – adopted by the
 Company

[0001193125-17-164153:notes:57]
In November 2016, the FASB issued ASU 2016-18, “Statement of
 Cash Flows (Topic 230): Restricted Cash,” which requires the
 statement of cash flows to explain the change during the period in
 the total of cash, cash equivalents and restricted cash or
 restricted cash equivalents. The Company has early adopted this
 update in the second quarter of fiscal year 2017 on a retrospective
 basis but there was no impact to the presentation of the
 comparative period in the unaudited condensed consolidated
 financial statements.

[0001193125-17-164153:notes:58]
In November 2015, the FASB issued ASU 2015-17, “Balance Sheet
 Classification of Deferred Taxes,” which will require
 entities to present deferred tax assets (“DTAs”) and
 deferred tax liabilities (“DTLs”) as non-current in a
 classified balance sheet. The ASU simplifies the current guidance,
 which requires entities to separately present DTAs and DTLs as
 current and non-current in a classified balance sheet. The Company
 has early adopted this update in the first quarter of fiscal year
 2017. The Company adopted this update on a prospective basis and
 did not change the presentation of the comparative period.

[0001193125-17-164153:notes:59]
In September 2015, the FASB issued ASU 2015-16, “Business
 Combinations (Topic 805): Simplifying the Accounting for
 Measurement-Period Adjustments” which require an acquirer to
 recognize adjustments to provisional amounts that are identified
 during the measurement period in the reporting period in which the
 adjustment amounts are determined. The Company adopted this update
 in the first quarter of fiscal year 2017 and applied it on a
 prospective basis. See Footnote 8 – Business acquisition, for
 further disclosure on measurement period adjustments recorded in
 the nine months ended March 31, 2017.

[0001193125-17-164153:notes:60]
In July 2015, the FASB issued ASU 2015-11, “Inventory (Topic
 330): Simplifying the Measurement of Inventory.” The update
 provides the guidance that an entity, that measured inventory by
 using first-in, first-out or average cost, should measure inventory
 at the lower of cost and net realizable value. Subsequent
 measurement is unchanged for inventory measured using last-in,
 first-out or the retail inventory method. The Company adopted this
 update in the first quarter of fiscal year 2017 with no impact to
 the unaudited condensed consolidated financial statements.

[0001193125-17-164153:notes:61]
In April 2015, the FASB issued ASU 2015-03, “Interest –
 Imputation of Interest (Subtopic 835-30): Simplifying the
 Presentation of Debt Issuance Costs.” The update requires
 debt issuance costs related to a recognized debt liability be
 presented in the balance sheet as a direct deduction from the
 carrying amount of the related debt liability instead of being
 presented as an asset. Debt disclosures will include the face
 amount of the debt liability and the effective interest rate. The
 update requires retrospective application and represents a change
 in accounting principle. Additionally, in August 2015, the FASB
 issued ASU 2015-15, “Interest – Imputation of Interest
 (Subtopic 835-30): Presentation and Subsequent Measurement of Debt
 Issuance Costs Associated with Line-of-Credit Arrangements”
 to amend ASU 2015-03. The Company adopted this amendment
 retrospectively in the first quarter of fiscal year 2017. As of
 March 31, 2017 and June 24, 2016, debt issuance costs of
 $0.4 million and $0.6 million, respectively, related to a
 recognized debt liability are presented in the balance sheet as a
 direct reduction of the carrying amount of the related debts.

[0001193125-17-164153:notes:62]
In February 2015, the FASB issued ASU 2015-02, “Consolidation
 (Topic 810): Amendments to the Consolidation Analysis.” ASU
 No. 2015-02 amended the process that a reporting entity must
 perform to determine whether it should consolidate certain types of
 legal entities. In the first quarter of fiscal year 2017, the
 Company adopted this update with no impact to the unaudited
 condensed consolidated financial statements.

[0001193125-17-164153:notes:63]
In January 2015, the FASB issued ASU 2015-01, “Income
 Statement – Extraordinary and Unusual Items (Subtopic
 225-20): Simplifying Income Statement Presentation by Eliminating
 the Concept of Extraordinary Items.” The objective of this
 amendment is to reduce the complexity in accounting standards by
 eliminating the concept of extraordinary items from U.S. GAAP. To
 meet for extraordinary classification the underlying event or
 transaction should (a) possess a high degree of abnormality
 and be of a type clearly unrelated to, or only incidentally related
 to, the ordinary and typical activities of the entity and
 (b) not reasonably be expected to recur in the foreseeable
 future. In the first quarter of fiscal year 2017, the Company
 adopted this update with no impact to the unaudited condensed
 consolidated financial statements.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-17-164153:notes:64]
The changes in AOCI for the nine months ended March 31, 2017
 were as follows:

[0001193125-17-164153:notes:65]
| (amount in thousands) |  | Unrealized net Gains (Losses) on Marketable Securities |  |  | Unrealized net Gains (Losses) on Derivative Instruments |  |  | Foreign Currency Translation Adjustment |  |  | Total |  |
| Balance as of June 24, 2016 |  | $ | 399 |  |  | $ | 192 |  |  | $ | — |  |  | $ | 591 |  |
| Other comprehensive income before reclassification adjustment |  |  | 75 |  |  |  | — |  |  |  | (935 | ) |  |  | (860 | ) |
| Amounts reclassified out of AOCI to foreign exchange loss in the unaudited condensed consolidated statement of operations and comprehensive income |  |  | (566 | ) |  |  | (158 | ) |  |  | — |  |  |  | (724 | ) |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive loss |  | $ | (491 | ) |  | $ | (158 | ) |  | $ | (935 | ) |  | $ | (1,584 | ) |
| Balance as of March 31, 2017 |  | $ | (92 | ) |  | $ | 34 |  |  | $ | (935 | ) |  | $ | (993 | ) |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001193125-17-164153:notes:66]
The movement of long-term borrowings was as follows for the nine
 months ended March 31, 2017 and March 25, 2016:

[0001193125-17-164153:notes:67]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 31, 2017 |  |  | March 25, 2016 |  |
| Opening balance |  | $ | 54,500 |  |  | $ | 10,500 |  |
| Repayments during the period |  |  | (14,700 | ) |  |  | (4,500 | ) |
| Closing balance |  | $ | 39,800 |  |  | $ | 6,000 |  |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock

[0001193125-17-164153:notes:68]
Undrawn available credit facilities classified by availability
 period of future borrowing as of March 31, 2017 and
 June 24, 2016 were as follows:

[0001193125-17-164153:notes:69]
| (amount in thousands) |  | March 31, 2017 |  |  | June 24, 2016 |  |
| Short-term |  | $ | 4,799 |  |  | $ | 1,414 |  |
| Long-term |  | $ | 126,200 |  |  | $ | 143,500 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-17-164153:notes:70]
The following table presents total revenues by geographic
 regions:

[0001193125-17-164153:notes:71]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 31, 2017 |  |  | March 25, 2016 |  |  | March 31, 2017 |  |  | March 25, 2016 |  |
| North America |  | $ | 154,708 |  |  | $ | 138,687 |  |  | $ | 478,700 |  |  | $ | 369,284 |  |
| Asia-Pacific |  |  | 149,271 |  |  |  | 88,433 |  |  |  | 400,708 |  |  |  | 256,676 |  |
| Europe |  |  | 62,858 |  |  |  | 23,768 |  |  |  | 170,628 |  |  |  | 74,399 |  |
|  |  | $ | 366,837 |  |  | $ | 250,888 |  |  | $ | 1,050,036 |  |  | $ | 700,359 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-17-164153:notes:72]
[same as prior period, unchanged from 0001193125-17-033383:notes:70]

[0001193125-17-164153:notes:73]
[same as prior period, unchanged from 0001193125-17-033383:notes:71]

[0001193125-17-164153:notes:74]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of March 31, 2017 and for the three
 and nine months ended March 31, 2017 and March 25, 2016
 includes normal recurring adjustments, necessary for a fair
 statement of the financial information set forth herein, in
 accordance with accounting principles generally accepted in the
 United States of America (“U.S. GAAP”) for interim
 financial information and the rules and regulations of the
 Securities and Exchange Commission (“SEC”).
 Accordingly, such information does not include all of the
 information and footnotes required by U.S. GAAP for annual
 financial statements. For further information, please refer to the
 consolidated financial statements and footnotes thereto included in
 Fabrinet’s Annual Report on Form 10-K for the year ended
 June 24, 2016.

[0001193125-17-164153:notes:75]
The balance sheet as of June 24, 2016 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three and nine
 months ended March 31, 2017 may not be indicative of results
 for the year ending June 30, 2017 or any future periods.

[0001193125-17-164153:notes:76]
[same as prior period, unchanged from 0001193125-17-033383:notes:74]

[0001193125-17-164153:notes:77]
On September 14, 2016, the Company acquired 100% shareholding
 in Global CEM Solutions, Ltd. and all of its subsidiaries
 (including Exception EMS), a privately-held group located
 in Wiltshire, United Kingdom. The unaudited condensed
 consolidated financial statements of the Company include the
 financial position, results of operations and the cash flows of
 Exception EMS commencing as of the acquisition date. See Note 8 -
 Business acquisitions for further details on the accounting for
 this transaction.

[0001193125-17-164153:notes:78]
[same as prior period, unchanged from 0001193125-17-033383:notes:76]

[0001193125-17-164153:notes:79]
The preparation of the Company’s unaudited condensed
 consolidated financial statements in conformity with U.S. GAAP
 requires management to make estimates and assumptions that affect
 the reported amounts of assets and liabilities and disclosure of
 contingent liabilities at the date of the financial statements, and
 the reported amount of total revenues and expenses during the year.
 The Company bases estimates on historical experience and various
 assumptions about the future that are believed to be reasonable
 based on available information. The Company’s reported
 financial position or results of operations may be materially
 different under different conditions or when using different
 estimates and assumptions, particularly with respect to significant
 accounting policies, which are discussed below. Significant
 assumptions are used in accounting for share-based compensation,
 allowance for doubtful accounts, income taxes, inventory
 obsolescence and valuation of intangible assets related to business
 acquisition, among others. Due to the inherent uncertainty involved
 in making estimates, actual results reported in future periods may
 be different from these estimates. In the event that estimates or
 assumptions prove to differ from actual results, adjustments will
 be made in subsequent periods to reflect more current
 information.

[0001193125-17-164153:notes:80]
[same as prior period, unchanged from 0001193125-17-033383:notes:78]

[0001193125-17-164153:notes:81]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended
 March 31, 2017 and March 25, 2016 each consisted of 13
 weeks. The nine months ended March 31, 2017 and March 25,
 2016 consisted of 40 weeks and 39 weeks, respectively. Fiscal year
 2017 will be comprised of 53 weeks and will end on June 30,
 2017.

[0001193125-17-164153:notes:82]
[same as prior period, unchanged from 0001193125-17-033383:notes:80]

[0001193125-17-164153:notes:83]
[same as prior period, unchanged from 0001193125-17-033383:notes:81]

[0001193125-17-164153:notes:84]
[same as prior period, unchanged from 0001193125-17-033383:notes:82]

[0001193125-17-164153:notes:85]
[same as prior period, unchanged from 0001193125-17-033383:notes:83]

[0001193125-17-164153:notes:86]
[same as prior period, unchanged from 0001193125-17-033383:notes:84]

[0001193125-17-164153:notes:87]
The derivatives assets and liabilities are recognized on the
 unaudited condensed consolidated balance sheets as other current
 assets or accrued expenses and are measured at fair value.

[0001193125-17-164153:notes:88]
The Company applies hedge accounting to arrangements that qualify
 and are designated for cash flow or fair value hedge accounting
 treatment. Hedge accounting is discontinued prospectively if the
 hedging relationship ceases to be effective or the hedging or
 hedged items cease to exist as a result of maturity, sale,
 termination or cancellation.

[0001193125-17-164153:notes:89]
[same as prior period, unchanged from 0001193125-17-033383:notes:87]

[0001193125-17-164153:notes:90]
[same as prior period, unchanged from 0001193125-17-033383:notes:88]

[0001193125-17-164153:notes:91]
[same as prior period, unchanged from 0001193125-17-033383:notes:89]

[0001193125-17-164153:notes:92]
For the acquisition of Exception EMS, the Company allocated the
 fair value of purchase consideration to the assets acquired and
 liabilities assumed based on their fair values at the acquisition
 date. The total consideration and the allocation of consideration
 to the individual net assets are preliminary, pending the
 finalization of the estimated fair value attributable to the
 acquired customer relationships.

[0001193125-17-164153:notes:93]
The acquired intangible assets, which consist of customer
 relationships and backlog, are recorded within intangibles, net in
 the unaudited condensed consolidated balance sheets. The fair value
 of the acquired intangible assets was determined based on the
 multi-period excess earnings method. The Company reviews definite
 lived intangibles for impairment whenever changes or circumstances
 indicate the carrying amount may not be recoverable.

[0001193125-17-164153:notes:94]
In connection with the business acquisition, $3.2 million of cash
 for deferred consideration, net of foreign currency translation
 adjustment, was placed into an escrow account which is under the
 Company’s control. However, the Company has contractually
 agreed to remit this deferred consideration to the sellers of
 Exception EMS, subject to the resolution of claims that the Company
 may make against the funds with respect to indemnification and
 other claims within 24 months from the closing date of the
 transaction. The cash is presented as restricted cash in the
 unaudited condensed consolidated balance sheets within non-current
 assets and the related liability is presented within non-current
 liabilities for the deferred consideration.

[0001193125-17-164153:notes:95]
[same as prior period, unchanged from 0001193125-17-033383:notes:93]

[0001193125-17-164153:notes:96]
[same as prior period, unchanged from 0001193125-17-033383:notes:94]

[0001193125-17-164153:notes:97]
[same as prior period, unchanged from 0001193125-17-033383:notes:95]

[0001193125-17-164153:notes:98]
[same as prior period, unchanged from 0001193125-17-033383:notes:96]

[0001193125-17-164153:notes:99]
[same as prior period, unchanged from 0001193125-17-033383:notes:97]

[0001193125-17-164153:notes:100]
In January 2017, the Financial Accounting Standards Board
 (“FASB”) issued Accounting Standards Update
 (“ASU”) 2017-04, “Intangibles – Goodwill
 and Other (Topic 350): Simplifying the Test for Goodwill
 Impairment.” This amendment modified the concept of
 impairment assessment from the condition that exists when the
 carrying amount of goodwill exceeds its implied fair value to the
 condition that exists when the carrying amount of a reporting unit
 exceeds its fair value. Public companies that are SEC filers should
 adopt the amendment for its annual and any interim goodwill
 impairment tests in fiscal years beginning after December 15,
 2019. Early adoption is permitted for interim or annual goodwill
 impairment tests performed on testing dates after January 1,
 2017. The Company is currently evaluating the impact of the
 adoption of this update on its consolidated financial
 statements.

[0001193125-17-164153:notes:101]
In January 2017, the FASB issued ASU 2017-03, “Accounting
 Changes and Error Corrections (Topic 250) and Investments –
 Equity Method and Joint Ventures (Topic 323): Amendments to SEC
 Paragraphs Pursuant to Staff Announcements at the
 September 22, 2016 and November 17, 2016 EITF
 Meetings.” The amendment provides guidance to the Company in
 relation to the disclosure of the impact that ASU 2014-09, ASU
 2016-02 and ASU 2016-13 will have on the Company’s financial
 statements when adopted. The Company is currently evaluating the
 impact of the adoption of this update on its consolidated financial
 statements.

[0001193125-17-164153:notes:102]
In January 2017, the FASB issued ASU 2017-01, “Business
 Combination (Topic 805): Clarifying the Definition of a
 Business.” This amendment clarifies the definition of a
 business to assist entities when evaluating whether transactions
 should be accounted for as acquisitions (or disposals) of assets or
 business. For public companies, this ASU is effective for annual
 periods beginning after December 15, 2017, including interim
 periods within those periods. Early adoption is permitted for the
 transactions that occur before the issuance date or effective date
 of the amendment, only when the transaction has not been reported
 in financial statements that have been issued or made available for
 issuance. The Company does not expect that the adoption of this
 update will have a material impact to its consolidated financial
 statements.

[0001193125-17-164153:notes:103]
In October 2016, the FASB issued ASU 2016-16, “Income Taxes
 (Topic 740): Intra-Entity Transfers of Assets Other Than
 Inventory,” which eliminates the exception for an
 intra-entity transfer of an asset other than inventory that
 prohibits the recognition of current and deferred income taxes
 until the asset has been sold to an outside party. The entity
 should recognize income tax consequences of an intra-entity
 transfer of assets other than inventory when the transfer occurs.
 For public entities, this update is effective for annual reporting
 periods beginning after December 15, 2017, including interim
 reporting periods within those annual reporting periods. Early
 adoption is permitted for all entities as of the beginning of an
 annual reporting period for which financial statements have not
 been issued or made available for issuance. The Company is
 currently evaluating the impact of the adoption of this update on
 its consolidated financial statements.

[0001193125-17-164153:notes:104]
In August 2016, the FASB issued ASU 2016-15, “Classification
 of Certain Cash Receipts and Cash Payments (a consensus of the
 Emerging Issues Task Force).” The amendments in this ASU
 provide guidance on the presentation of certain cash receipts and
 cash payments in the statement of cash flows in order to reduce
 diversity in existing practice. The amendments in ASU 2016-15 are
 effective for public business entities for fiscal years beginning
 after December 15, 2017, and interim periods within those
 fiscal years. Early adoption is permitted, including adoption in an
 interim period. The Company is currently evaluating the impact of
 the adoption of this update on its consolidated financial
 statements.

[0001193125-17-164153:notes:105]
In June 2016, the FASB issued ASU 2016-13, “Financial
 Instruments – Credit Losses (Topic 326): Measurement of
 Credit Losses on Financial Instruments.” The amendments in
 this ASU replace the incurred loss impairment methodology in
 current GAAP with a methodology that reflects expected credit
 losses and requires consideration of a broader range of reasonable
 and supportable information to inform credit loss estimates. The
 amendments are effective for fiscal years beginning after
 December 15, 2019, including interim periods within those
 fiscal years. Early adoption is permitted for fiscal years
 beginning after December 15, 2018, including interim periods
 within those fiscal years. The Company is currently evaluating the
 impact of the adoption of this update on its consolidated financial
 statements.

[0001193125-17-164153:notes:106]
In March 2016, the FASB issued ASU
 2016-09, “Compensation – Stock Compensation (Topic
 718): Improvements to Employee Share-Based Payment
 Accounting.” This ASU simplifies several aspects of the
 accounting for share-based payment award transactions, including
 the income tax consequences, classification of awards as either
 equity or liabilities and classification on the statement of cash
 flows. The amendments in this update are effective for annual
 periods beginning after December 15, 2016, and interim periods
 within those annual periods, for public companies. Early adoption
 is permitted for any entity in any interim or annual period. The
 Company is currently evaluating the impact of the adoption of this
 update on its consolidated financial statements.

[0001193125-17-164153:notes:107]
In March 2016, the FASB issued ASU 2016-05, “Derivatives and
 Hedging (Topic 815),” to clarify that a change in the
 counterparty to a derivative instrument that has been designated as
 a hedging instrument under Topic 815, does not, in and of itself,
 require a de-designation of the hedging relationship, provided that
 all other hedge accounting criteria continue to be met. This
 guidance is effective for public entities for financial statements
 issued for fiscal years beginning after December 15, 2016 and
 interim periods within those fiscal years. Early adoption is
 permitted. The Company is currently evaluating the impact of the
 adoption of this update on its consolidated financial
 statements.

[0001193125-17-164153:notes:108]
In February 2016, the FASB issued ASU 2016-02, “Lease (Topic
 842).” The core principle of Topic 842 is that a lessee
 should recognize the lease assets and liabilities that arise from
 leases in the statement of financial position. For public business
 entities, this update is effective for fiscal years beginning after
 December 15, 2018, including interim periods within those
 fiscal years. Early application is permitted. The Company is
 currently evaluating the impact of the adoption of this update on
 its consolidated financial statements.

[0001193125-17-164153:notes:109]
In January 2016, the FASB issued ASU 2016-01, “Financial
 Instruments – Overall (Subtopic 825-10): Recognition and
 Measurement of Financial Assets and Financial Liabilities.”
 This new guidance requires certain equity investments to be
 measured at fair value, use of the exit price notion and separate
 presentation of financial assets and financial liabilities by
 measurement category and form of financial asset on the balance
 sheet or the accompanying notes to the financial statements. The
 ASU on recognition and measurement will take effect for public
 companies for fiscal years beginning after December 15, 2017,
 including interim periods within those fiscal years. The
 Company is currently evaluating the impact of the adoption of this
 update on its consolidated financial statements.

[0001193125-17-164153:notes:110]
In August 2014, the FASB issued ASU 2014-15, “Presentation of
 Financial Statements – Going Concern (Subtopic 205-40):
 Disclosure of Uncertainties about an Entity’s Ability to
 Continue as a Going Concern.” The amendments require
 management to evaluate, for each annual and interim reporting
 period, an entity’s ability to continue as a going concern
 when relevant conditions and events, considered in the aggregate,
 indicate that it is probable that the entity will be unable to meet
 its obligations that become due within one year after the date that
 the financial statements are issued (or available to be issued).
 This ASU is effective for annual periods and interim reporting
 periods ending after December 15, 2016. The Company does not
 expect that the adoption of this update will have an effect on its
 consolidated financial statements.

[0001193125-17-164153:notes:111]
In May 2014, the FASB issued ASU 2014-09, “Revenue from
 Contracts with Customers (Topic 606), issued as a new Topic,
 Accounting Standards Codification.” The core principle of
 this amendment is that an entity should recognize revenue to depict
 the transfer of promised goods or services to customers in an
 amount that reflects the consideration to which the entity expects
 to be entitled in exchange for those goods or services. This update
 is effective for public companies, as amended by ASU 2015-14, for
 annual reporting periods beginning after December 15, 2017,
 including interim periods within that reporting period. Earlier
 application of this guidance is permitted, but not before the
 original date of December 15, 2016, which can be adopted
 either retrospectively to each prior reporting period presented or
 as a cumulative-effect adjustment as of the date of adoption.
 Subsequently, in March 2016 and April 2016, the FASB issued ASU
 2016-08 and ASU 2016-10, respectively, to clarify the
 implementation guidance on principle versus agent considerations
 and address the potential diversity in practice at initial
 application and cost; and the complexity of applying Topic 606,
 both at transition and on an ongoing basis related to
 identification of performance obligations and licensing
 arrangements; and ASU 2016-12 and ASU 2016-20, in May 2016 and
 December 2016, respectively, to improve in certain aspects of Topic
 606, with the same effective date as ASU 2015-14. The Company will
 adopt this standard during its fiscal year ending June 28,
 2019. In the current period, the Company is assessing the contracts
 with its customers to identify the impact to its consolidated
 financial statements. The process is still ongoing and the Company
 expects to make significant progress in the coming quarters.


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001193125-17-164153:notes:112]
[same as prior period, unchanged from 0001193125-17-033383:notes:110]

[0001193125-17-164153:notes:113]
[same as prior period, unchanged from 0001193125-17-033383:notes:111]

[0001193125-17-164153:notes:114]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Gain (Loss) |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of March 31, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 135,317 |  |  | $ | — |  |  | $ | 135,317 |  |  | $ | — |  |
| Cash equivalents |  |  | 1,317 |  |  |  | — |  |  |  | 1,317 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 95,503 |  |  |  | 22 |  |  |  | — |  |  |  | 95,525 |  |
| U.S. agency and U.S. treasury securities |  |  | 54,201 |  |  |  | (112 | ) |  |  | — |  |  |  | 54,089 |  |
| Sovereign and municipal securities |  |  | 2,995 |  |  |  | (1 | ) |  |  | — |  |  |  | 2,994 |  |
| Total |  | $ | 289,333 |  |  | $ | (91 | ) |  | $ | 136,634 |  |  | $ | 152,608 |  |

[0001193125-17-164153:notes:115]
[same as prior period, unchanged from 0001193125-17-033383:notes:113]

[0001193125-17-164153:notes:116]
[same as prior period, unchanged from 0001193125-17-033383:notes:114]

[0001193125-17-164153:notes:117]
During the nine months ended March 31, 2017, the Company
 recognized a realized loss of $0.4 million from sales and
 maturities of available-for-sale securities as interest income in
 the unaudited condensed consolidated statements of operations and
 comprehensive income.

[0001193125-17-164153:notes:118]
As of March 31, 2017, the Company considered the declines in
 market value of its marketable securities investment portfolio to
 be temporary in nature and did not consider any of its securities
 other-than-temporarily impaired. The Company typically invests in
 highly-rated securities, and its investment policy generally limits
 the amount of credit exposure to any one issuer. The policy
 requires investments generally to be investment grade, with the
 primary objective of minimizing the potential risk of principal
 loss. Fair values were determined for each individual security in
 the investment portfolio. When evaluating an investment for
 other-than-temporary impairment, the Company reviews factors such
 as the length of time and extent to which fair value has been below
 its cost basis, the financial condition of the issuer and any
 changes thereto, changes in market interest rates, and the
 Company’s intent to sell, or whether it is more likely than
 not it will be required to sell, the investment before recovery of
 the investment’s cost basis. No impairment losses were
 recorded for the nine months ended March 31, 2017.

[0001193125-17-164153:notes:119]
As of March 31, 2017, cash, cash equivalents, and marketable
 securities included bank deposits of $40.0 million held in various
 financial institutions located in the United States in order to
 support the availability of the Facility Agreement (as defined in
 Note 11) and comply with covenants. As discussed in Note 11,
 under the terms and conditions of the Facility Agreement, the
 Company shall maintain cash, cash equivalents and/or marketable
 securities in an aggregate amount not less than $40.0 million in
 unencumbered deposits, and/or securities in accounts located in the
 United States at all times during the term of the Facility
 Agreement. The Company must comply with the covenant from and after
 the effective date of the Facility Agreement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-17-164153:notes:120]
[same as prior period, unchanged from 0001193125-17-033383:notes:118]

[0001193125-17-164153:notes:121]
As of March 31, 2017 and June 24, 2016, the liability for
 uncertain tax positions, including accrued interest and penalties,
 was $2.0 million and $1.8 million, respectively. The Company
 expects the estimated amount of liability associated with its
 uncertain tax positions to decrease within the next 12 months
 due to the lapse of the applicable statute of limitations in
 foreign tax jurisdictions.

[0001193125-17-164153:notes:122]
[same as prior period, unchanged from 0001193125-17-033383:notes:120]

[0001193125-17-164153:notes:123]
The effective tax rate for the Company for the three months ended
 March 31, 2017 and March 25, 2016 was 6.5% and 5.8% of
 net income, respectively. The increase in the effective tax rate
 for the three months ended March 31, 2017 was primarily due to
 the fact that the Company had higher taxable income during the
 three months ended March 31, 2017 compared with the three
 months ended March 25, 2016.

[0001193125-17-164153:notes:124]
The effective tax rate for the Company for the nine months ended
 March 31, 2017 and March 25, 2016 was 6.7% and 6.4% of
 net income, respectively. The increase in the effective tax rate
 for the nine months ended March 31, 2017 was primarily due to
 the fact that the Company had higher taxable income during the nine
 months ended March 31, 2017 compared with the nine months
 ended March 25, 2016.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001193125-17-164153:notes:125]
[same as prior period, unchanged from 0001193125-17-033383:notes:123]

[0001193125-17-164153:notes:126]
| (amount in thousands) |  | As of March 31, 2017 |  |  | As of June 24, 2016 |  |
| Trade accounts receivable |  | $ | 250,970 |  |  | $ | 196,178 |  |
| Less: allowance for doubtful account |  |  | (48 | ) |  |  | (33 | ) |
| Trade accounts receivable, net |  | $ | 250,922 |  |  | $ | 196,145 |  |

[0001193125-17-164153:notes:127]
As of March 31, 2017, trade accounts receivable of $5.6
 million were secured to short-term loans from bank (see Note
 11).


## us-gaap:ScheduleOfDebtTableTextBlock

[0001193125-17-164153:notes:128]
The Company’s total borrowings, including short-term and
 long-term borrowings, consisted of the following:

[0001193125-17-164153:notes:129]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  | As of |  |  | As of |  |
|  |  |  |  |  |  |  | March 31, |  |  | June 24, |  |
| Rate (1) |  | Conditions |  | Maturity |  |  | 2017 |  |  | 2016 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  |  | April 2017 (2) |  |  | $ | 34,000 |  |  | $ | 6,500 |  |
| Short-term borrowings from bank: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank of England base rate +1.85% per annum |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  |  |  | 1,257 |  |  |  | — |  |
| Bank of England base rate + 2.2% per annum (3) |  | Repayable on monthly basis |  |  | May 2017 |  |  |  | 23 |  |  |  | — |  |
| Current portion of long-term borrowing |  |  |  |  |  |  |  |  | 13,600 |  |  |  | 18,100 |  |
|  |  |  |  |  |  |  |  |  | 48,880 |  |  |  | 24,600 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  |  |  | (222 | ) |  |  | (293 | ) |
|  |  |  |  |  |  |  |  | $ | 48,658 |  |  | $ | 24,307 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments |  |  | March 2017 |  |  | $ | — | (4) |  | $ | 4,500 |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  | Repayable in quarterly installments |  |  | May 2019 |  |  |  | 39,800 |  |  |  | 50,000 |  |
|  |  |  |  |  |  |  |  |  | 39,800 |  |  |  | 54,500 |  |
| Less: Current portion |  |  |  |  |  |  |  |  | (13,600 | ) |  |  | (18,100 | ) |
| Unamortized debt issuance costs |  |  |  |  |  |  |  |  | (141 | ) |  |  | (300 | ) |
| Non-current portion |  |  |  |  |  |  |  | $ | 26,059 |  |  | $ | 36,100 |  |

[0001193125-17-164153:notes:130]
| (1) | LIBOR is London Interbank Offered Rate. |

[0001193125-17-164153:notes:131]
| (2) | In March 2017, the maturity date was extended to April 2017. |

[0001193125-17-164153:notes:132]
| (3) | As of March 31, 2017, the carrying amount of plant and machinery of Exception EMS secured to such loan was $0.8 million. Under the conditions stipulated in the loan agreement, this loan will be cross securitized, cross default and co-terminus with the short terms loans of $1.3 million which are secured by accounts receivable. |

[0001193125-17-164153:notes:133]
| (4) | In March 2017, a subsidiary fully repaid the long term borrowing. The carrying amount of assets secured and pledged as collateral to such loan as of March 31, 2017 and June 24, 2016 was $45.9 million and $47.7 million, respectively. In April 2017, the bank released certain property, plant and equipment of the subsidiary which had been secured and pledged as collateral to such loans. |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001193125-17-164153:notes:134]
As of March 31, 2017, future maturities of long-term
 borrowings during each fiscal year were as follows:

[0001193125-17-164153:notes:135]
| (amount in thousands) |  |  |  |
| 2017 (remaining three months) |  | $ | 3,400 |  |
| 2018 |  |  | 13,600 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 39,800 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-17-164153:notes:136]
Based on the carrying amount of intangibles as of March 31,
 2017, and assuming no future impairment of the underlying assets,
 the estimated future amortization during each fiscal year was as
 follows:

[0001193125-17-164153:notes:137]
| (amount in thousands) |  |  |  |
| 2017 (remaining three months) |  | $ | 371 |  |
| 2018 |  |  | 1,413 |  |
| 2019 |  |  | 1,275 |  |
| 2020 |  |  | 875 |  |
| 2021 |  |  | 620 |  |
| Thereafter |  |  | 1,303 |  |
| Total |  | $ | 5,857 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001193125-17-164153:notes:138]
[same as prior period, unchanged from 0001193125-17-033383:notes:135]

[0001193125-17-164153:notes:139]
| (amount in thousands) |  | Goodwill |  |
| Balance as of June 24, 2016 |  | $ | — |  |
| Addition in connection with business acquisition |  |  | 3,883 |  |
| Foreign currency translation adjustment |  |  | (234 | ) |
| Balance as of March 31, 2017 |  | $ | 3,649 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-17-164153:notes:140]
[same as prior period, unchanged from 0001193125-17-033383:notes:137]

[0001193125-17-164153:notes:141]
On September 14, 2016, the Company acquired 100% shareholding
 in Exception EMS, a privately-held group located in Wiltshire,
 United Kingdom, for cash consideration of approximately $13.0
 million, net of $0.5 million cash acquired. Exception EMS provides
 contract electronics manufacturing services to the global
 electronics industry with innovative solutions, adding value to the
 design, manufacture and testing of printed circuit board
 assemblies. Pursuant to the acquisition agreement, the Company has
 placed $3.2 million of cash, net of foreign currency translation
 adjustment, for deferred consideration in an escrow account which
 is under the Company’s control. However, the Company has
 contractually agreed to remit this deferred consideration to the
 sellers of Exception EMS, subject to the resolution of claims that
 the Company may make against the funds with respect to
 indemnification and other claims within 24 months from the closing
 date of the transaction.

[0001193125-17-164153:notes:142]
[same as prior period, unchanged from 0001193125-17-033383:notes:139]

[0001193125-17-164153:notes:143]
The total consideration and the allocation of consideration to the
 individual Exception EMS net assets are preliminary, pending the
 finalization of the estimated fair value attributable to the
 acquired customer relationships. As the functional currency of
 Exception EMS is pound sterling (“GBP”), for the nine
 months ended March 31, 2017, the Company recognized a $0.9
 million loss from foreign currency translation adjustment in its
 unaudited condensed consolidated statements of operations and
 comprehensive income.

[0001193125-17-164153:notes:144]
During the third quarter of fiscal year 2017, the Company recorded
 a measurement period adjustment to recognized deferred tax
 liabilities of $1.2 million related to taxable temporary
 differences from intangibles and changes in the fair value of
 assets acquired. Therefore, goodwill which was previously reported
 at acquisition date of $2.7 million was changed to $3.9
 million.

[0001193125-17-164153:notes:145]
[same as prior period, unchanged from 0001193125-17-033383:notes:142]

[0001193125-17-164153:notes:146]
| (amount in thousands) |  | Purchase price allocation |  |
| Cash |  | $ | 474 |  |
| Accounts receivable |  |  | 4,064 |  |
| Inventory |  |  | 3,490 |  |
| Other current assets |  |  | 427 |  |
| Property, plant and equipment |  |  | 5,678 |  |
| Intangibles |  |  | 4,492 |  |
| Goodwill |  |  | 3,883 |  |
| Other non-current assets |  |  | 516 |  |
| Deferred tax liabilities |  |  | (1,148 | ) |
| Current liabilities |  |  | (6,796 | ) |
| Other non-current liabilities |  |  | (1,563 | ) |
| Total fair value of assets acquired and liabilities assumed |  | $ | 13,517 |  |
| Total purchase price, net of cash acquired |  | $ | 13,043 |  |

[0001193125-17-164153:notes:147]
In connection with the Company’s acquisition of Exception
 EMS, the Company assumed lease agreements for certain machine and
 equipment, which are accounted for as capital leases. As of
 March 31, 2017, the Company included approximately $1.9
 million of capital lease assets and $1.4 million of capital lease
 liability in the unaudited condensed consolidated balance sheets
 associated with these acquired lease agreements.

[0001193125-17-164153:notes:148]
During the nine months ended March 31, 2017, the Company
 incurred approximately $1.5 million in transaction costs
 related to the acquisition, which primarily consisted of legal,
 accounting and valuation-related expenses. These expenses were
 recorded in selling, general and administrative expense in the
 accompanying unaudited condensed consolidated statements of
 operations and comprehensive income.

[0001193125-17-164153:notes:149]
[same as prior period, unchanged from 0001193125-17-033383:notes:146]

[0001193125-17-164153:notes:150]
[same as prior period, unchanged from 0001193125-17-033383:notes:147]

[0001193125-17-164153:notes:151]
[same as prior period, unchanged from 0001193125-17-033383:notes:148]

[0001193125-17-164153:notes:152]
Customer relationships represent the fair value of future projected
 revenues derived from the estimated sale of products to existing
 customers of the acquired company. The fair value of $4.4 million
 will be amortized over an estimated remaining useful life of ten
 years.

[0001193125-17-164153:notes:153]
[same as prior period, unchanged from 0001193125-17-033383:notes:150]

[0001193125-17-164153:notes:154]
[same as prior period, unchanged from 0001193125-17-033383:notes:151]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-17-164153:notes:155]
[same as prior period, unchanged from 0001193125-17-033383:notes:152]


## us-gaap:DebtDisclosureTextBlock

[0001193125-17-164153:notes:156]
| 11. | Borrowings |

[0001193125-17-164153:notes:157]
Credit facilities:

[0001193125-17-164153:notes:158]
Fabrinet entered into a syndicated senior credit facility agreement
 (the “Facility Agreement”) with a consortium of banks
 on May 22, 2014. The Facility Agreement, led by Bank of
 America, provides for a $200.0 million credit line, comprised of a
 $150.0 million revolving loan facility and a $50.0 million delayed
 draw term loan facility. The revolving loan facility contains an
 accordion feature permitting Fabrinet to request an increase in the
 facility up to $100.0 million subject to customary terms and
 conditions and provided that no default or event of default exists
 at the time of request. The revolving loan facility will be
 terminated and all amounts outstanding will be due and payable in
 full on May 22, 2019. The principal amount of any drawn term
 loans must be repaid according to scheduled quarterly amortization
 payments, with final payment of all amounts outstanding, plus
 accrued interest, being due May 22, 2019.

[0001193125-17-164153:notes:159]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. As of
 March 31, 2017, $34.0 million of the revolving borrowing and
 $39.8 million of the term loan borrowing was outstanding under the
 Facility Agreement, resulting in available credit facilities for
 long-term borrowing of $126.2 million. Borrowings under the
 revolving credit facility are classified as current liabilities in
 the unaudited condensed consolidated balance sheets as the Company
 has the periodic option to renew or pay, all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. During March 2017, the Company
 sent notices to the bank to renew the maturity date of its
 revolving borrowings. The bank approved the notices and extended
 the maturity to April 2017.

[0001193125-17-164153:notes:160]
Loans under the Facility Agreement bear interest, at
 Fabrinet’s option, at a rate per annum equal to a LIBOR rate
 plus a spread of 1.75% to 2.50%, or a base rate plus a spread of
 0.75% to 1.50%, determined in accordance with the Facility
 Agreement in each case with such spread determined based on
 Fabrinet’s consolidated total leverage ratio for the
 preceding four fiscal quarter period. Interest is due and payable
 quarterly in arrears for loans bearing interest at the base rate
 and at the end of an interest period (or at each three-month
 interval in the case of loans with interest periods greater than
 three months) in the case of loans bearing interest at the LIBOR
 rate.

[0001193125-17-164153:notes:161]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material of
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or the
 equivalent under the local law, can be effected.

[0001193125-17-164153:notes:162]
The Facility Agreement contains customary affirmative and negative
 covenants. Negative covenants include, among other things,
 limitations on liens, indebtedness, investments, mergers, sales of
 assets, changes in the nature of the business, dividends and
 distributions, affiliate transactions and capital expenditures. The
 Facility Agreement contains financial covenants requiring Fabrinet
 to maintain: (1) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (2) a minimum debt service coverage ratio of
 not less than 1.50:1.00; (3) a maximum senior leverage ratio
 of not more than 2.50:1.00; and (4) a minimum quick ratio of
 not less than 1.10:1.00. Each of these financial covenants is
 calculated on a consolidated basis for the consecutive four fiscal
 quarter period then ended. As of March 31, 2017, the Company
 was in compliance with all covenants under the Facility
 Agreement.

[0001193125-17-164153:notes:163]
The Facility Agreement also contains customary events of default
 including, among other things, payment defaults, breaches of
 covenants or representations and warranties, cross-defaults with
 certain other indebtedness, bankruptcy and insolvency events and
 change in control of Fabrinet, subject to grace periods in certain
 instances. Upon an event of default, the lenders may terminate
 their commitments, declare all or a portion of the outstanding
 obligations payable by Fabrinet to be immediately due and payable
 and exercise other rights and remedies provided for under the
 Facility Agreement.

[0001193125-17-164153:notes:164]
Fabrinet intends to use the proceeds of the credit line to finance
 its future manufacturing facility in Thailand, and for general
 corporate purposes including mergers and acquisitions of
 complementary manufacturing businesses or technology, although
 Fabrinet has no current commitments with respect to any such
 acquisitions.

[0001193125-17-164153:notes:165]
Short-term borrowings from bank

[0001193125-17-164153:notes:166]
In connection with the acquisition of Exception EMS, the Company
 assumed a secured borrowing agreement that is secured by trade
 accounts receivable of Exception EMS. As of March 31, 2017,
 the carrying amount of trade accounts receivable secured to the
 loans was $5.6 million. The secured borrowing agreement contains
 certain covenants that Exception EMS is required to comply with:
 (1) the value of credit notes may not exceed 4% of the value
 of assigned debts measured on a monthly basis, and (2) rolling
 cash flow must be provided to the financial institution along with
 monthly management information. As of March 31, 2017, the
 subsidiary was in compliance with all covenants under the secured
 borrowing agreement.

[0001193125-17-164153:notes:167]
As of March 31, 2017, the Company drew down $1.3 million from
 this facility, which is recorded as short-term loans in the
 unaudited condensed consolidated balance sheets. The agreement
 bears interest for discount charge at 1.85% per annum above
 Bank of England base rate.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-17-164153:notes:168]
[same as prior period, unchanged from 0001193125-17-033383:notes:168]

[0001193125-17-164153:notes:169]
[same as prior period, unchanged from 0001193125-17-033383:notes:169]

[0001193125-17-164153:notes:170]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net |  |
| As of March 31, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 5,765 |  |  | $ | (3,686 | ) |  | $ | — |  |  | $ | 2,079 |  |
| Customer relationships |  |  | 4,372 |  |  |  | (407 | ) |  |  | (263 | ) |  |  | 3,702 |  |
| Backlog |  |  | 120 |  |  |  | (34 | ) |  |  | (10 | ) |  |  | 76 |  |
| Total intangibles |  | $ | 10,257 |  |  | $ | (4,127 | ) |  | $ | (273 | ) |  | $ | 5,857 |  |

[0001193125-17-164153:notes:171]
[same as prior period, unchanged from 0001193125-17-033383:notes:171]

[0001193125-17-164153:notes:172]
In connection with the acquisition of Exception EMS, the Company
 recorded $4.4 million of customer relationships and $0.1 million of
 backlog. As of March 31, 2017, the weighted-average remaining
 life of customer relationships and backlog was 7.1 years and 1.8
 years, respectively.

[0001193125-17-164153:notes:173]
The Company recorded amortization expense relating to intangibles
 of $0.9 million and $0.02 million for the three months ended
 March 31, 2017 and March 25, 2016, respectively, and $1.1
 million and $0.04 million for the nine months ended March 31,
 2017 and March 25, 2016, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-17-164153:notes:174]
[same as prior period, unchanged from 0001193125-17-033383:notes:174]

[0001193125-17-164153:notes:175]
[same as prior period, unchanged from 0001193125-17-033383:notes:175]

[0001193125-17-164153:notes:176]
[same as prior period, unchanged from 0001193125-17-033383:notes:176]

[0001193125-17-164153:notes:177]
For the nine months ended March 31, 2017, Fabrinet issued
 367,641 ordinary shares upon the exercise of options, for cash
 consideration at a weighted-average exercise price of $16.02 per
 share, and 802,509 ordinary shares upon the vesting of restricted
 share units, net of shares withheld.

[0001193125-17-164153:notes:178]
[same as prior period, unchanged from 0001193125-17-033383:notes:178]


## us-gaap:EarningsPerShareTextBlock

[0001193125-17-164153:notes:179]
[same as prior period, unchanged from 0001193125-17-033383:notes:179]

[0001193125-17-164153:notes:180]
[same as prior period, unchanged from 0001193125-17-033383:notes:180]

[0001193125-17-164153:notes:181]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands except per share amounts) |  | March 31, 2017 |  |  | March 25, 2016 |  |  | March 31, 2017 |  |  | March 25, 2016 |  |
| Net income attributable to shareholders |  | $ | 21,656 |  |  | $ | 20,822 |  |  | $ | 69,714 |  |  | $ | 42,228 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  | 37,116 |  |  |  | 35,964 |  |  |  | 36,792 |  |  |  | 35,785 |  |
| Incremental shares arising from the assumed exercise of share options and vesting of restricted share units (thousands of shares) |  |  | 756 |  |  |  | 1,125 |  |  |  | 958 |  |  |  | 958 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 37,872 |  |  |  | 37,089 |  |  |  | 37,750 |  |  |  | 36,743 |  |
| Basic earnings per ordinary share |  | $ | 0.58 |  |  | $ | 0.58 |  |  | $ | 1.89 |  |  | $ | 1.18 |  |
| Diluted earnings per ordinary share |  | $ | 0.57 |  |  | $ | 0.56 |  |  | $ | 1.85 |  |  | $ | 1.15 |  |

[0001193125-17-164153:notes:182]
As of March 31, 2017 and March 25, 2016, there were no
 anti-dilutive share options.


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001193125-17-164153:notes:183]
[same as prior period, unchanged from 0001193125-17-033383:notes:183]

[0001193125-17-164153:notes:184]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of March 31, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 1,317 |  |  | $ | — |  |  | $ | 1,317 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 95,525 |  |  |  | — |  |  |  | 95,525 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 54,089 |  |  |  | — |  |  |  | 54,089 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 2,994 |  |  |  | — |  |  |  | 2,994 |  |
| Total |  | $ | — |  |  | $ | 153,925 |  |  | $ | — |  |  | $ | 153,925 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 8 | (1) |  | $ | — |  |  | $ | 8 |  |
| Total |  | $ | — |  |  | $ | 8 |  |  | $ | — |  |  | $ | 8 |  |

[0001193125-17-164153:notes:185]
[same as prior period, unchanged from 0001193125-17-033383:notes:185]

[0001193125-17-164153:notes:186]
| (1) | Foreign currency forward contract with notional amount of Canadian dollars 0.5 million. |

[0001193125-17-164153:notes:187]
[same as prior period, unchanged from 0001193125-17-033383:notes:187]

[0001193125-17-164153:notes:188]
[same as prior period, unchanged from 0001193125-17-033383:notes:188]


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-17-164153:notes:189]
[same as prior period, unchanged from 0001193125-17-033383:notes:189]

[0001193125-17-164153:notes:190]
[same as prior period, unchanged from 0001193125-17-033383:notes:190]

[0001193125-17-164153:notes:191]
[same as prior period, unchanged from 0001193125-17-033383:notes:191]

[0001193125-17-164153:notes:192]
[same as prior period, unchanged from 0001193125-17-033383:notes:192]

[0001193125-17-164153:notes:193]
[same as prior period, unchanged from 0001193125-17-033383:notes:193]

[0001193125-17-164153:notes:194]
[same as prior period, unchanged from 0001193125-17-033383:notes:194]

[0001193125-17-164153:notes:195]
[same as prior period, unchanged from 0001193125-17-033383:notes:195]

[0001193125-17-164153:notes:196]
As a result of foreign currency rate fluctuations, the U.S. dollar
 equivalent values of the Company’s foreign currency
 denominated assets and liabilities change. The Company uses foreign
 currency contracts to manage the foreign exchange risk associated
 with certain foreign currency denominated assets and liabilities
 and other foreign currency transactions. The Company minimizes the
 credit risk in derivative instruments by limiting its exposure to
 any single counterparty and by entering into derivative instruments
 only with counterparties that meet the Company’s minimum
 credit quality standard. As of March 31, 2017, the Company
 recognized the fair value of foreign currency forward contracts of
 $8 thousand as derivative liabilities in the unaudited condensed
 consolidated balance sheet under accrued expenses. As of
 June 24, 2016, the Company recognized the fair value of
 foreign currency forward contracts of $0.2 million as derivative
 assets and $1.7 million as derivative liabilities in the unaudited
 condensed consolidated balance sheet under other current assets and
 accrued expenses, respectively.

[0001193125-17-164153:notes:197]
As of March 31, 2017, the Company had no foreign currency
 forward contracts designated as cash flow hedges. During the nine
 months ended March 31, 2017, the Company discontinued cash
 flow hedges and recognized a gain from unwinding foreign currency
 forward contracts of $0.3 million as foreign exchange gain, net in
 the unaudited condensed consolidated statements of operations and
 comprehensive income.

[0001193125-17-164153:notes:198]
As of March 31, 2017, the Company had one outstanding foreign
 currency forward contract with an aggregate notional amount of
 Canadian dollars 0.5 million, maturing in June 2017. This
 foreign currency forward contract was not designated for hedge
 accounting and was used to hedge fluctuations in the U.S. dollar
 value of forecasted transactions denominated in Canadian dollar.
 During the nine months ended March 31, 2017, the Company
 included unrealized loss of $8 thousand from changes in the fair
 value of foreign currency contracts in earnings as foreign exchange
 loss, net in the unaudited condensed consolidated statements of
 operations and comprehensive income.

[0001193125-17-164153:notes:199]
As of March 25, 2016, the Company had 17 outstanding foreign
 currency forward contracts with an aggregate notional amount of
 $102.0 million and Canadian dollars 0.3 million, maturing
 during June 2016 to December 2016. These foreign currency forward
 contracts were not designated for hedge accounting and were used to
 hedge fluctuations in the U.S. dollar value of forecasted
 transactions denominated in Thai baht and Canadian dollar. During
 the nine months ended March 25, 2016, the Company included
 unrealized loss of $2.3 million from changes in the fair value of
 foreign currency contracts as foreign exchange loss, net in
 earnings in the unaudited condensed consolidated statements of
 operations and comprehensive income.


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-17-164153:notes:200]
[same as prior period, unchanged from 0001193125-17-033383:notes:200]

[0001193125-17-164153:notes:201]
As of March 31, 2017, the Company recorded $3.9 million of
 goodwill, in connection with the acquisition of Exception EMS, in
 the unaudited condensed consolidated balance sheets.

[0001193125-17-164153:notes:202]
[same as prior period, unchanged from 0001193125-17-033383:notes:202]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-17-164153:notes:203]
[same as prior period, unchanged from 0001193125-17-033383:notes:203]

[0001193125-17-164153:notes:204]
Operating segments are defined as components of an enterprise for
 which separate financial information is available that is evaluated
 regularly by the chief operating decision maker in deciding how to
 allocate resources and in assessing performance. The
 Company’s chief operating decision maker is Fabrinet’s
 chief executive officer. As of March 31, 2017, the Company
 operated and internally managed a single operating segment.
 Accordingly, the Company does not accumulate discrete information
 with respect to separate product lines and does not have separate
 reportable segments.

[0001193125-17-164153:notes:205]
[same as prior period, unchanged from 0001193125-17-033383:notes:205]

[0001193125-17-164153:notes:206]
As of March 31, 2017 and March 25, 2016, the Company had
 approximately $35.3 million and $33.4 million of long-lived assets
 based in North America, with the substantial remainder of assets
 based in Asia-Pacific.

[0001193125-17-164153:notes:207]
[same as prior period, unchanged from 0001193125-17-033383:notes:207]

[0001193125-17-164153:notes:208]
The Company had two customers that each contributed 10% or more of
 its total accounts receivable as of March 31, 2017 and
 June 24, 2016, respectively.

[0001193125-17-164153:notes:209]
During the three months ended March 31, 2017 and
 March 25, 2016, the Company had one customer that contributed
 10% or more of its total revenues. This customer accounted for 15%
 and 21% of the Company’s total revenues during the respective
 periods. During the nine months ended March 31, 2017 and
 March 25, 2016, the Company had one customer that contributed
 10% or more of its total revenues. This customer accounted for 18%
 and 20% of the Company’s total revenues during the respective
 periods.


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001193125-17-164153:notes:210]
| 18. | Other income related to flooding, net |

[0001193125-17-164153:notes:211]
During the week of August 10, 2015, the Company’s
 subsidiary in China temporarily suspended production in its
 manufacturing facility due to flooding caused by Typhoon Soudelor
 and resumed operations on August 15, 2015. During the nine
 months ended March 25, 2016, the Company recognized $0.04
 million of other income related to flooding, net in the unaudited
 condensed consolidated statements of operations and comprehensive
 income, which mainly consisted of a final payment of $0.8 million
 from an insurer against the Company’s claim for flood damage,
 offset by expenses in relation to flood of $0.8 million.
