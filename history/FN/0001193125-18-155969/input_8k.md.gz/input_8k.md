# FN 8-K — 0001193125-18-154488 filed 2018-05-07

## item codes, every 8-K on or before 2018-05-08

- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2018-05-08

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-18-154488:8k_2_02:1]
EX-99.1
3
d582222dex991.htm
EX-99.1

[0001193125-18-154488:8k_2_02:2]
EX-99.1

[0001193125-18-154488:8k_2_02:3]
Exhibit 99.1

[0001193125-18-154488:8k_2_02:4]
Fabrinet Announces Third Quarter Fiscal Year 2018 Financial Results

[0001193125-18-154488:8k_2_02:5]
BANGKOK, Thailand – May 7, 2018 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision
optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its third quarter ended March 30, 2018.

[0001193125-18-154488:8k_2_02:6]
Tom Mitchell, Executive Chairman of Fabrinet, said, “We again exceeded our revenue guidance in the third quarter of fiscal 2018. With stabilizing demand
and increasing interest in our capabilities we are confident that we can deliver sequential growth in the fourth quarter and further strengthen our position in the marketplace.”

[0001193125-18-154488:8k_2_02:7]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “We continue to benefit from a mix of established programs and new business, which contributes
to our growth and diversification. Our position in the market continues to strengthen as our diverse customers look to Fabrinet to manufacture their most challenging designs.”

[0001193125-18-154488:8k_2_02:8]
Third Quarter Fiscal Year 2018 Financial Highlights

[0001193125-18-154488:8k_2_02:9]
GAAP Results

[0001193125-18-154488:8k_2_02:10]
|  | • |  | Revenue for the third quarter of fiscal year 2018 was $332.2 million, compared to revenue of $366.8 million for the comparable period in fiscal year 2017. |

[0001193125-18-154488:8k_2_02:11]
|  | • |  | GAAP net income for the third quarter of fiscal year 2018 was $21.1 million, compared to GAAP net income of $21.7 million for the third quarter of fiscal year 2017. GAAP net income for the third quarter of fiscal year 2018 included a foreign exchange loss of $2.4 million, or $0.06 per diluted share, compared to a foreign exchange loss of $3.7 million, or $0.10 per diluted share, for the third quarter of fiscal year 2017. |

[0001193125-18-154488:8k_2_02:12]
|  | • |  | GAAP net income per diluted share for the third quarter of fiscal year 2018 was $0.55, compared to GAAP net income per diluted share of $0.57 for the third quarter of fiscal year 2017. |

[0001193125-18-154488:8k_2_02:13]
Non-GAAP Results

[0001193125-18-154488:8k_2_02:14]
|  | • |  | Non-GAAP net income for the third quarter of fiscal year 2018 was $26.9 million, compared to non-GAAP net income of $30.5 million for the third quarter of fiscal year 2017. Non-GAAP net income for the third quarter of fiscal year 2018 included a foreign exchange loss of $2.4 million, or $0.06 per diluted share, compared to a foreign exchange loss of $3.7 million, or $0.10 per diluted share, for the third quarter of fiscal year 2017. |

[0001193125-18-154488:8k_2_02:15]
|  | • |  | Non-GAAP net income per diluted share for the third quarter of fiscal year 2018 was $0.71, compared to non-GAAP net income per diluted share of $0.80 for the same period a year ago. |

[0001193125-18-154488:8k_2_02:16]
Share Repurchase Program Update

[0001193125-18-154488:8k_2_02:17]
Fabrinet repurchased approximately 422,000 ordinary shares at an average price of $29.58 during the third quarter.

[0001193125-18-154488:8k_2_02:18]
Business Outlook

[0001193125-18-154488:8k_2_02:19]
Based on information available as of
May 7, 2018, Fabrinet is issuing guidance for its fourth fiscal quarter ending June 29, 2018, as follows:

[0001193125-18-154488:8k_2_02:20]
|  | • |  | Fabrinet expects fourth quarter revenue to be in the range of $334 million to $342 million. |

[0001193125-18-154488:8k_2_02:21]
|  | • |  | GAAP net income per diluted share is expected to be in the range of $0.55 to $0.59, based on approximately 37.9 million fully diluted shares outstanding. |

[0001193125-18-154488:8k_2_02:22]
|  | • |  | Non-GAAP net income per diluted share is expected to be in the range of $0.73 to $0.77, based on approximately 37.9 million fully diluted shares outstanding. |

[0001193125-18-154488:8k_2_02:23]
Conference Call Information

[0001193125-18-154488:8k_2_02:24]
| What: |  | Fabrinet Third Quarter Fiscal-Year 2018 Financial Results Call |
| When: |  | Monday, May 7, 2018 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic |
|  |  | (253) 237-1137, international |
|  |  | Passcode: 4590788 |
| Replay: |  | (855) 859-2056, domestic |
|  |  | (404) 537-3406, international |
|  |  | Passcode: 4590788 |
| Webcast: |  | http://investor.fabrinet.com/ (live and replay) |

[0001193125-18-154488:8k_2_02:25]
This press release and any other information related to the call will also be posted on Fabrinet’s website at
http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-18-154488:8k_2_02:26]
About Fabrinet

[0001193125-18-154488:8k_2_02:27]
Fabrinet is a leading provider of
advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive
components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain
management, manufacturing, advanced packaging, integration, final assembly and test. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in
Thailand, the United States of America, the People’s Republic of China and the United Kingdom. For more information visit: www.fabrinet.com.

[0001193125-18-154488:8k_2_02:28]
Forward-Looking Statements

[0001193125-18-154488:8k_2_02:29]
Use of Non-GAAP Financials

[0001193125-18-154488:8k_2_02:30]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful
supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; depreciation of fair value uplift; executive separation costs; expenses
related to our CEO search; amortization of intangibles; business combination expenses; loss (gain) on foreign currency contracts; amortization of debt issuance costs; and restructuring charges. We have excluded these items in order to enhance
investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to
their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001193125-18-154488:8k_2_02:31]
These non-GAAP financial measures are used to: (1) measure company performance against historical results,
(2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001193125-18-154488:8k_2_02:32]
SOURCE: Fabrinet

[0001193125-18-154488:8k_2_02:33]
Investor Contact:

[0001193125-18-154488:8k_2_02:34]
Garo Toomajanian

[0001193125-18-154488:8k_2_02:35]
ir@fabrinet.com

[0001193125-18-154488:8k_2_02:36]
FABRINET

[0001193125-18-154488:8k_2_02:37]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-18-154488:8k_2_02:38]
| (in thousands of U.S. dollars, except share data) |  | March 30,2018 |  |  | June 30,2017 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 142,407 |  |  | $ | 133,825 |  |
| Marketable securities |  |  | 169,444 |  |  |  | 151,450 |  |
| Trade accounts receivable, net |  |  | 243,997 |  |  |  | 264,349 |  |
| Inventory, net |  |  | 239,617 |  |  |  | 238,665 |  |
| Prepaid expenses |  |  | 9,466 |  |  |  | 6,306 |  |
| Other current assets |  |  | 11,049 |  |  |  | 4,159 |  |
| Total current assets |  |  | 815,980 |  |  |  | 798,754 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Restricted cash in connection with business acquisition |  |  | 3,569 |  |  |  | 3,312 |  |
| Property, plant and equipment, net |  |  | 222,047 |  |  |  | 216,881 |  |
| Intangibles, net |  |  | 5,927 |  |  |  | 5,840 |  |
| Goodwill |  |  | 4,101 |  |  |  | 3,806 |  |
| Deferred tax assets |  |  | 3,046 |  |  |  | 2,905 |  |
| Deferred debt issuance costs on revolving loan and other non-current assets |  |  | 135 |  |  |  | 1,577 |  |
| Total non-current assets |  |  | 238,825 |  |  |  | 234,321 |  |
| Total Assets |  | $ | 1,054,805 |  |  | $ | 1,033,075 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Bank borrowings, net of unamortized debt issuance costs |  | $ | 52,464 |  |  | $ | 48,402 |  |
| Trade accounts payable |  |  | 193,374 |  |  |  | 215,262 |  |
| Fixed assets payable |  |  | 4,684 |  |  |  | 8,141 |  |
| Capital lease liability, current portion |  |  | 491 |  |  |  | 344 |  |
| Income tax payable |  |  | 298 |  |  |  | 1,976 |  |
| Accrued payroll, bonus and related expenses |  |  | 13,322 |  |  |  | 13,852 |  |
| Accrued expenses |  |  | 11,750 |  |  |  | 9,227 |  |
| Other payables |  |  | 10,776 |  |  |  | 14,068 |  |
| Total current liabilities |  |  | 287,159 |  |  |  | 311,272 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term loan from bank, non-current portion, net of unamortized debt issuance costs |  |  | 12,595 |  |  |  | 22,701 |  |
| Deferred tax liability |  |  | 2,172 |  |  |  | 1,981 |  |
| Capital lease liability, non-current portion |  |  | 671 |  |  |  | 1,024 |  |
| Deferred liability in connection with business acquisition |  |  | 3,569 |  |  |  | 3,312 |  |
| Severance liabilities |  |  | 10,103 |  |  |  | 8,488 |  |
| Other non-current liabilities |  |  | 2,993 |  |  |  | 2,723 |  |
| Total non-current liabilities |  |  | 32,103 |  |  |  | 40,229 |  |
| Total Liabilities |  |  | 319,262 |  |  |  | 351,501 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of March 30, 2018 and June 30, 2017) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 37,640,215 shares and 37,340,496 shares issued, and 36,901,790 shares and 37,340,496 shares outstanding as of March 30, 2018 and June 30, 2017, respectively) |  |  | 376 |  |  |  | 373 |  |
| Additional paid-in capital |  |  | 147,958 |  |  |  | 133,293 |  |
| Treasury stock at cost (738,425 shares and zero shares as of March 30, 2018 and June 30, 2017, respectively) |  |  | (22,407 | ) |  |  | — |  |
| Accumulated other comprehensive loss |  |  | (39 | ) |  |  | (348 | ) |
| Retained earnings |  |  | 609,655 |  |  |  | 548,256 |  |
| Total Shareholders’ Equity |  |  | 735,543 |  |  |  | 681,574 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 1,054,805 |  |  | $ | 1,033,075 |  |

[0001193125-18-154488:8k_2_02:39]
FABRINET

[0001193125-18-154488:8k_2_02:40]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND

[0001193125-18-154488:8k_2_02:41]
COMPREHENSIVE INCOME

[0001193125-18-154488:8k_2_02:42]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (in thousands of U.S. dollars, except per share amounts) |  | March 30,2018 |  |  | March 31,2017 |  |  | March 30,2018 |  |  | March 31,2017 |  |
| Revenues |  | $ | 332,213 |  |  | $ | 366,837 |  |  | $ | 1,026,598 |  |  | $ | 1,050,036 |  |
| Cost of revenues |  |  | (295,280 | ) |  |  | (322,791 | ) |  |  | (912,167 | ) |  |  | (923,336 | ) |
| Gross profit |  |  | 36,933 |  |  |  | 44,046 |  |  |  | 114,431 |  |  |  | 126,700 |  |
| Selling, general and administrative expenses |  |  | (12,418 | ) |  |  | (17,086 | ) |  |  | (41,253 | ) |  |  | (50,569 | ) |
| Expenses related to reduction in workforce |  |  | — |  |  |  | — |  |  |  | (1,776 | ) |  |  | — |  |
| Operating income |  |  | 24,515 |  |  |  | 26,960 |  |  |  | 71,402 |  |  |  | 76,131 |  |
| Interest income |  |  | 1,149 |  |  |  | 713 |  |  |  | 2,554 |  |  |  | 1,470 |  |
| Interest expense |  |  | (820 | ) |  |  | (641 | ) |  |  | (2,499 | ) |  |  | (2,517 | ) |
| Foreign exchange loss, net |  |  | (2,428 | ) |  |  | (3,702 | ) |  |  | (5,710 | ) |  |  | (100 | ) |
| Other income |  |  | 91 |  |  |  | 108 |  |  |  | 438 |  |  |  | 397 |  |
| Income before income taxes |  |  | 22,507 |  |  |  | 23,438 |  |  |  | 66,185 |  |  |  | 75,381 |  |
| Income tax expense |  |  | (1,454 | ) |  |  | (1,782 | ) |  |  | (4,786 | ) |  |  | (5,667 | ) |
| Net income |  |  | 21,053 |  |  |  | 21,656 |  |  |  | 61,399 |  |  |  | 69,714 |  |
| Other comprehensive loss, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in net unrealized loss on marketable securities |  |  | (616 | ) |  |  | 49 |  |  |  | (1,048 | ) |  |  | (491 | ) |
| Change in net unrealized loss on derivative instruments |  |  | — |  |  |  | — |  |  |  | (1 | ) |  |  | (158 | ) |
| Change in foreign currency translation adjustment |  |  | 789 |  |  |  | 227 |  |  |  | 1,358 |  |  |  | (935 | ) |
| Total other comprehensive loss, net of tax |  |  | 173 |  |  |  | 276 |  |  |  | 309 |  |  |  | (1,584 | ) |
| Net comprehensive income |  | $ | 21,226 |  |  | $ | 21,932 |  |  | $ | 61,708 |  |  | $ | 68,130 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.56 |  |  | $ | 0.58 |  |  | $ | 1.64 |  |  | $ | 1.89 |  |
| Diluted |  | $ | 0.55 |  |  | $ | 0.57 |  |  | $ | 1.61 |  |  | $ | 1.85 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 37,275 |  |  |  | 37,116 |  |  |  | 37,400 |  |  |  | 36,792 |  |
| Diluted |  |  | 38,055 |  |  |  | 37,872 |  |  |  | 38,125 |  |  |  | 37,750 |  |

[0001193125-18-154488:8k_2_02:43]
FABRINET

[0001193125-18-154488:8k_2_02:44]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-18-154488:8k_2_02:45]
|  |  | Nine Months Ended |  |
| (in thousands of U.S. dollars) |  | March 30,2018 |  |  | March 31,2017 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income for the period |  | $ | 61,399 |  |  | $ | 69,714 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 21,288 |  |  |  | 16,956 |  |
| (Gain) loss on disposal of property, plant and equipment |  |  | (153 | ) |  |  | 7 |  |
| Loss from sales and maturities of available-for-sale securities |  |  | 362 |  |  |  | 407 |  |
| Amortization of investment (premium) discount |  |  | (31 | ) |  |  | 397 |  |
| Amortization of deferred debt issuance costs |  |  | 433 |  |  |  | 1,591 |  |
| Allowance for doubtful accounts |  |  | 44 |  |  |  | 3 |  |
| Unrealized loss (gain) on exchange rate and fair value of derivative instruments |  |  | 1,393 |  |  |  | (718 | ) |
| Share-based compensation |  |  | 17,704 |  |  |  | 21,936 |  |
| Deferred income tax |  |  | 19 |  |  |  | 1,008 |  |
| Other non-cash expenses |  |  | 1,941 |  |  |  | 1,775 |  |
| Reversal of inventory obsolescence |  |  | (291 | ) |  |  | (72 | ) |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | 21,411 |  |  |  | (50,839 | ) |
| Inventory |  |  | (973 | ) |  |  | (39,766 | ) |
| Other current assets and non-current assets |  |  | (9,853 | ) |  |  | 3,921 |  |
| Trade accounts payable |  |  | (22,518 | ) |  |  | 32,653 |  |
| Income tax payable |  |  | (1,678 | ) |  |  | 166 |  |
| Other current liabilities and non-current liabilities |  |  | (703 | ) |  |  | 1,249 |  |
| Net cash provided by operating activities |  |  | 89,794 |  |  |  | 60,388 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of marketable securities |  |  | (84,519 | ) |  |  | (100,751 | ) |
| Proceeds from sales of marketable securities |  |  | 22,169 |  |  |  | 33,812 |  |
| Proceeds from maturities of marketable securities |  |  | 42,977 |  |  |  | 54,745 |  |
| Payments in connection with business acquisition, net of cash acquired |  |  | — |  |  |  | (9,917 | ) |
| Purchase of property, plant and equipment |  |  | (28,268 | ) |  |  | (57,224 | ) |
| Purchase of intangibles |  |  | (1,487 | ) |  |  | (1,910 | ) |
| Proceeds from disposal of property, plant and equipment |  |  | 202 |  |  |  | 190 |  |
| Net cash used in investing activities |  |  | (48,926 | ) |  |  | (81,055 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Proceeds of short-term loans from banks |  |  | 5,000 |  |  |  | 27,665 |  |
| Repayment of short-term loans from bank |  |  | (1,003 | ) |  |  | — |  |
| Repayment of long-term loans from bank |  |  | (10,200 | ) |  |  | (14,700 | ) |
| Repayment of capital lease liability |  |  | (293 | ) |  |  | (182 | ) |
| Repurchase of ordinary shares |  |  | (22,407 | ) |  |  | — |  |
| Proceeds from issuance of ordinary shares under employee share option plans |  |  | 993 |  |  |  | 5,890 |  |
| Withholding tax related to net share settlement of restricted share units |  |  | (4,030 | ) |  |  | (1,272 | ) |
| Net cash provided by (used in) financing activities |  |  | (31,940 | ) |  |  | 17,401 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  |  | 8,928 |  |  |  | (3,266 | ) |
| Movement in cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 137,137 |  |  |  | 142,804 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash |  |  | 8,928 |  |  |  | (3,266 | ) |
| Effect of exchange rate on cash, cash equivalents and restricted cash |  |  | (89 | ) |  |  | 271 |  |
| Cash, cash equivalents and restricted cash at end of period |  | $ | 145,976 |  |  | $ | 139,809 |  |
| Non-cash investing and financing activities |  |  |  |  |  |  |  |  |
| Construction, software-related and equipment-related payables |  | $ | 4,684 |  |  | $ | 12,409 |  |

[0001193125-18-154488:8k_2_02:46]
FABRINET

[0001193125-18-154488:8k_2_02:47]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-18-154488:8k_2_02:48]
(Continued)

[0001193125-18-154488:8k_2_02:49]
The following table provides
a reconciliation of cash, cash equivalents and restricted cash reported within the unaudited condensed consolidated balance sheets that sum to the total of same amounts shown in the unaudited condensed consolidated statements of cash flows:

[0001193125-18-154488:8k_2_02:50]
| (amount in thousands) |  | As ofMarch 30,2018 |  |  | As ofMarch 31,2017 |  |
| Cash and cash equivalents |  | $ | 142,407 |  |  | $ | 136,634 |  |
| Restricted cash in connection with business acquisition (non-current assets) |  |  | 3,569 |  |  |  | 3,175 |  |
| Cash, cash equivalents and restricted cash |  | $ | 145,976 |  |  | $ | 139,809 |  |

[0001193125-18-154488:8k_2_02:51]
FABRINET

[0001193125-18-154488:8k_2_02:52]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-18-154488:8k_2_02:53]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 30, 2018 |  |  | March 31, 2017 |  |  | March 30, 2018 |  |  | March 31, 2017 |  |
| (in thousands of U.S. dollars, except per share data) |  | Netincome |  |  | Diluted EPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |
| GAAP measures |  |  | 21,053 |  |  |  | 0.55 |  |  |  | 21,656 |  |  |  | 0.57 |  |  |  | 61,399 |  |  |  | 1.61 |  |  |  | 69,714 |  |  |  | 1.85 |  |
| Items reconciling GAAP net (loss) income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,564 |  |  |  | 0.04 |  |  |  | 1,657 |  |  |  | 0.04 |  |  |  | 5,277 |  |  |  | 0.14 |  |  |  | 4,185 |  |  |  | 0.11 |  |
| Depreciation of fair value uplift |  |  | 88 |  |  |  | 0.00 |  |  |  | 67 |  |  |  | 0.00 |  |  |  | 241 |  |  |  | 0.00 |  |  |  | 67 |  |  |  | 0.00 |  |
| Cost resulting from a non-recurring warranty charge |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total related to gross profit |  |  | 1,652 |  |  |  | 0.04 |  |  |  | 1,724 |  |  |  | 0.05 |  |  |  | 5,518 |  |  |  | 0.14 |  |  |  | 4,252 |  |  |  | 0.11 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 3,762 |  |  |  | 0.10 |  |  |  | 6,071 |  |  |  | 0.16 |  |  |  | 12,427 |  |  |  | 0.33 |  |  |  | 17,751 |  |  |  | 0.47 |  |
| Executive separation costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 577 |  |  |  | 0.02 |  |
| Expenses related to CEO search |  |  | — |  |  |  | — |  |  |  | 103 |  |  |  | 0.00 |  |  |  | 204 |  |  |  | 0.00 |  |  |  | 103 |  |  |  | 0.00 |  |
| Debt administration expenses |  |  | — |  |  |  | — |  |  |  | 320 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 320 |  |  |  | 0.01 |  |
| Amortization of intangibles |  |  | 205 |  |  |  | 0.01 |  |  |  | 179 |  |  |  | 0.00 |  |  |  | 582 |  |  |  | 0.02 |  |  |  | 408 |  |  |  | 0.01 |  |
| Business combination expenses |  |  | — |  |  |  | — |  |  |  | 120 |  |  |  | 0.00 |  |  |  | 117 |  |  |  | 0.00 |  |  |  | 1,630 |  |  |  | 0.04 |  |
| Total related to selling, general and administrative expenses |  |  | 3,967 |  |  |  | 0.11 |  |  |  | 6,793 |  |  |  | 0.18 |  |  |  | 13,329 |  |  |  | 0.35 |  |  |  | 20,789 |  |  |  | 0.55 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss (gain) on foreign currency contracts |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,713 | ) |  |  | (0.05 | ) |
| Other expenses in relation to reduction in workforce |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,776 |  |  |  | 0.05 |  |  |  | — |  |  |  | — |  |
| Amortization of debt issuance costs |  |  | 238 |  |  |  | 0.01 |  |  |  | 283 |  |  |  | 0.01 |  |  |  | 778 |  |  |  | 0.02 |  |  |  | 1,627 |  |  |  | 0.04 |  |
| Total related to other incomes and other expenses |  |  | 238 |  |  |  | 0.01 |  |  |  | 283 |  |  |  | 0.01 |  |  |  | 2,554 |  |  |  | 0.07 |  |  |  | (86 | ) |  |  | (0.00 | ) |
| Related to income tax expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-recurring income tax expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total related to income tax expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total related to net income & EPS |  |  | 5,857 |  |  |  | 0.16 |  |  |  | 8,800 |  |  |  | 0.23 |  |  |  | 21,401 |  |  |  | 0.56 |  |  |  | 24,955 |  |  |  | 0.66 |  |
| Non-GAAP measures |  |  | 26,910 |  |  |  | 0.71 |  |  |  | 30,456 |  |  |  | 0.80 |  |  |  | 82,800 |  |  |  | 2.17 |  |  |  | 94,669 |  |  |  | 2.50 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 38,055 |  |  |  |  |  |  |  | 37,872 |  |  |  |  |  |  |  | 38,125 |  |  |  |  |  |  |  | 37,750 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 38,055 |  |  |  |  |  |  |  | 37,872 |  |  |  |  |  |  |  | 38,125 |  |  |  |  |  |  |  | 37,750 |  |

[0001193125-18-154488:8k_2_02:54]
| FABRINET |
| RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES |
| TO FREE CASH FLOW |

[0001193125-18-154488:8k_2_02:55]
| (in thousands) |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 30, |  |  | March 31, |  |  | March 30, |  |  | March 31, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net cash provided by operating activities |  | $ | 52,681 |  |  | $ | 40,636 |  |  | $ | 89,794 |  |  | $ | 60,388 |  |
| Less: Purchase of property, plant and equipment |  |  | (6,863 | ) |  |  | (12,812 | ) |  |  | (28,268 | ) |  |  | (57,224 | ) |
| Non-GAAP free cash flow |  | $ | 45,818 |  |  | $ | 27,824 |  |  | $ | 61,526 |  |  | $ | 3,164 |  |

[0001193125-18-154488:8k_2_02:56]
FABRINET

[0001193125-18-154488:8k_2_02:57]
GUIDANCE FOR QUARTER ENDING JUNE 29, 2018

[0001193125-18-154488:8k_2_02:58]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-18-154488:8k_2_02:59]
|  |  | DilutedEPS |  |
| GAAP net income per diluted share: |  | $ | 0.55 to $0.59 |  |
| Related to cost of revenues: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.04 |  |
| Total related to gross profit |  |  | 0.04 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.12 |  |
| Business combination expenses |  |  | 0.01 |  |
| Total related to selling, general and administrative expenses |  |  | 0.13 |  |
| Related to other incomes and other expenses: |  |  |  |  |
| Amortization of debt issuance costs |  |  | 0.01 |  |
| Total related to net income & EPS |  |  | 0.18 |  |
| Non-GAAP net income per diluted share |  | $ | 0.73 to $0.77 |  |

## item 5.02 — body, verbatim

[0001193125-18-154488:8k_body:1]
Item 5.02

[0001193125-18-154488:8k_body:2]
Results of Operations and Financial Condition.

[0001193125-18-154488:8k_body:3]
On May 3, 2018, Fabrinet and David T. Mitchell,
Fabrinet’s Executive Chairman of the Board, entered into a letter agreement (the “Amendment”) to amend Mr. Mitchell’s two, performance-based restricted share unit awards, each covering 61,758 ordinary shares of Fabrinet (at
target and maximum performance), that were granted to him on August 18, 2016 (the “PSU Awards”) under Fabrinet’s 2010 Performance Incentive Plan and applicable award agreements thereunder. Under the terms of the PSU Award
agreements, each of the PSU Awards is settled entirely in the form of Fabrinet ordinary shares if and when the PSU Award vests. As a result of the Amendment, upon any vesting and settlement of the PSU Awards, 42% of the shares otherwise issuable
upon such vesting automatically will be settled instead in the form of cash.

[0001193125-18-154488:8k_body:4]
The foregoing description of the Amendment is a summary and is qualified in
its entirety by the terms of the Amendment, a copy of which is attached hereto as Exhibit 10.1.
