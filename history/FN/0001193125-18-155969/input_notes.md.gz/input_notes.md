# FN notes — 0001193125-18-155969


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-18-155969:notes:1]
The following table summarizes the cost and estimated fair value of
 marketable securities classified as available-for-sale securities
 based on stated effective maturities as of March 30, 2018:

[0001193125-18-155969:notes:2]
| (amount in thousands) |  | Carrying Cost |  |  | Fair Value |  |
| Due within one year |  | $ | 13,181 |  |  | $ | 13,174 |  |
| Due between one to three years |  |  | 157,385 |  |  |  | 156,270 |  |
| Total |  | $ | 170,566 |  |  | $ | 169,444 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-18-155969:notes:3]
| 16. | Commitments and contingencies |

[0001193125-18-155969:notes:4]
Bank guarantees

[0001193125-18-155969:notes:5]
As of March 30, 2018 and June 30, 2017, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to Thai baht 50.1 million as of both dates ($1.6 million
 and $1.5 million, respectively).

[0001193125-18-155969:notes:6]
Operating lease commitments

[0001193125-18-155969:notes:7]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, New Jersey and the United Kingdom under operating
 lease arrangements that expire in various calendar years through
 2023. Rental expense under these operating leases amounted to
 $1.3 million and $1.2 million for the nine months ended
 March 30, 2018 and March 31, 2017, respectively.

[0001193125-18-155969:notes:8]
As of March 30, 2018, the future minimum lease payments due
 under non-cancelable
 operating leases during each fiscal year were as follows:

[0001193125-18-155969:notes:9]
| (amount in thousands) |  |  |  |
| 2018 (remaining three months) |  | $ | 468 |  |
| 2019 |  |  | 1,319 |  |
| 2020 |  |  | 965 |  |
| 2021 |  |  | 562 |  |
| 2022 |  |  | 448 |  |
| Thereafter |  |  | 486 |  |
| Total minimum operating lease payments |  | $ | 4,248 |  |

[0001193125-18-155969:notes:10]
Capital lease commitments

[0001193125-18-155969:notes:11]
In connection with the acquisition of Fabrinet UK, the Company
 assumed the capital lease commitments of certain machines and
 equipment, with various expiration dates until September 2020. The
 equipment can be purchased at the determined prices upon expiration
 of such contracts.

[0001193125-18-155969:notes:12]
As of March 30, 2018, the future minimum lease payments due
 under non-cancelable
 capital leases during each fiscal year were as follows:

[0001193125-18-155969:notes:13]
| (amount in thousands) |  |  |  |
| 2018 (remaining three months) |  | $ | 125 |  |
| 2019 |  |  | 484 |  |
| 2020 |  |  | 440 |  |
| 2021 |  |  | 113 |  |
| Total minimum capital lease payments |  | $ | 1,162 |  |

[0001193125-18-155969:notes:14]
Purchase obligations

[0001193125-18-155969:notes:15]
Purchase obligations represent legally-binding commitments to
 purchase inventory and other commitments made in the normal course
 of business to meet operational requirements. Although open
 purchase orders are considered enforceable and legally binding,
 their terms generally give the Company the option to cancel,
 reschedule and/or adjust its requirements based on its business
 needs prior to the delivery of goods or performance of services.
 Obligations to purchase inventory and other commitments are
 generally expected to be fulfilled within one year.

[0001193125-18-155969:notes:16]
On December 23, 2016, the Company entered into an agreement to
 purchase a parcel of land in Chonburi, Thailand, to support the
 expansion of the Company’s production in Thailand. The
 aggregate purchase price is approximately $5.6 million, of
 which the first installment of $1.1 million was paid by the
 Company on January 10, 2017 and the remaining balance of the
 purchase price was paid by the Company on December 25,
 2017.

[0001193125-18-155969:notes:17]
As of March 30, 2018, the Company had an outstanding
 commitment to third parties of approximately $3.5 million.

[0001193125-18-155969:notes:18]
Indemnification of directors and officers

[0001193125-18-155969:notes:19]
Cayman Islands law does not limit the extent to which a
 company’s memorandum and articles of association may provide
 for indemnification of directors and officers, except to the extent
 any such provision may be held by the Cayman Islands courts to be
 contrary to public policy, such as to provide indemnification
 against civil fraud or the consequences of committing a crime.
 Fabrinet’s amended and restated memorandum and articles of
 association provide for indemnification of directors and officers
 for actions, costs, charges, losses, damages and expenses incurred
 in their capacities as such, except that such indemnification does
 not extend to any matter in respect of any fraud or dishonesty that
 may attach to any of them.

[0001193125-18-155969:notes:20]
In accordance with Fabrinet’s form of indemnification
 agreement for its directors and officers, Fabrinet has agreed to
 indemnify its directors and officers against certain liabilities
 and expenses incurred by such persons in connection with claims by
 reason of their being such a director or officer. Fabrinet
 maintains a director and officer liability insurance policy that
 may enable it to recover a portion of any future amounts paid under
 the indemnification agreements.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-18-155969:notes:21]
[same as prior period, unchanged from 0001193125-18-033890:notes:21]

[0001193125-18-155969:notes:22]
[same as prior period, unchanged from 0001193125-18-033890:notes:22]

[0001193125-18-155969:notes:23]
[same as prior period, unchanged from 0001193125-18-033890:notes:23]

[0001193125-18-155969:notes:24]
The effect of recording share-based compensation expense for the
 three and nine months ended March 30, 2018 and March 31,
 2017 was as follows:

[0001193125-18-155969:notes:25]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 30, 2018 |  |  | March 31, 2017 |  |  | March 30, 2018 |  |  | March 31, 2017 |  |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restricted share units |  | $ | 3,904 |  |  | $ | 6,540 |  |  | $ | 13,338 |  |  | $ | 18,993 |  |
| Performance share units |  |  | 1,422 |  |  |  | 1,188 |  |  |  | 4,366 |  |  |  | 2,943 |  |
| Total share-based compensation expense |  |  | 5,326 |  |  |  | 7,728 |  |  |  | 17,704 |  |  |  | 21,936 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 5,326 |  |  | $ | 7,728 |  |  | $ | 17,704 |  |  | $ | 21,936 |  |

[0001193125-18-155969:notes:26]
[same as prior period, unchanged from 0001193125-18-033890:notes:26]

[0001193125-18-155969:notes:27]
|  |  | Three Months ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 30, 2018 |  |  | March 31, 2017 |  |  | March 30, 2018 |  |  | March 31, 2017 |  |
| Cost of revenue |  | $ | 1,564 |  |  | $ | 1,657 |  |  | $ | 5,277 |  |  | $ | 4,185 |  |
| Selling, general and administrative expense |  |  | 3,762 |  |  |  | 6,071 |  |  |  | 12,427 |  |  |  | 17,751 |  |
| Total share-based compensation expense |  | $ | 5,326 |  |  | $ | 7,728 |  |  | $ | 17,704 |  |  | $ | 21,936 |  |

[0001193125-18-155969:notes:28]
The Company did not capitalize any share-based compensation expense
 as part of any asset costs during the three and nine months ended
 March 30, 2018 and March 31, 2017.

[0001193125-18-155969:notes:29]
[same as prior period, unchanged from 0001193125-18-033890:notes:29]

[0001193125-18-155969:notes:30]
[same as prior period, unchanged from 0001193125-18-033890:notes:30]

[0001193125-18-155969:notes:31]
On March 12, 2010, Fabrinet’s shareholders adopted the
 2010 Plan. On December 20, 2010, December 20, 2012 and
 December 14, 2017, Fabrinet’s shareholders adopted
 amendments to the 2010 Plan to increase the number of ordinary
 shares authorized for issuance under the 2010 Plan by 500,000
 shares, 3,700,000 shares and 2,100,000 shares, respectively. As of
 March 30, 2018, there were an aggregate of 32,326 share
 options outstanding, 1,050,811 restricted share units outstanding
 and 508,586 performance share units outstanding under the 2010
 Plan. As of March 30, 2018, there were 2,504,131 ordinary
 shares available for future grant under the 2010 Plan.

[0001193125-18-155969:notes:32]
On November 2, 2017, Fabrinet adopted the 2017 Inducement Plan
 with a reserve of 160,000 ordinary shares authorized for future
 issuance solely for the granting of inducement share options and
 equity awards to new employees. The 2017 Inducement Plan was
 adopted without shareholder approval in reliance on the
 “employment inducement exemption” provided under the
 New York Stock Exchange Listed Company Manual. As of March 30,
 2018, there were an aggregate of 48,653 restricted share units
 outstanding and 97,306 performance share units outstanding under
 the 2017 Inducement Plan. As of March 30, 2018, there were
 14,041 ordinary shares available for future grant under the 2017
 Inducement Plan.

[0001193125-18-155969:notes:33]
[same as prior period, unchanged from 0001193125-18-033890:notes:33]

[0001193125-18-155969:notes:34]
[same as prior period, unchanged from 0001193125-18-033890:notes:34]

[0001193125-18-155969:notes:35]
[same as prior period, unchanged from 0001193125-18-033890:notes:35]

[0001193125-18-155969:notes:36]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price Per Share |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 30, 2017 |  |  | 96,688 |  |  |  | 96,688 |  |  | $ | 15.70 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (62,862 | ) |  |  |  |  |  | $ | 15.80 |  |  |  |  |  |
| Forfeited |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Expired |  |  | (1,500 | ) |  |  |  |  |  | $ | 25.05 |  |  |  |  |  |
| Balance as of March 30, 2018 |  |  | 32,326 |  |  |  | 32,326 |  |  | $ | 15.05 |  |  |  |  |  |

[0001193125-18-155969:notes:37]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price Per Share |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 24, 2016 |  |  | 464,334 |  |  |  | 464,334 |  |  | $ | 15.95 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (367,641 | ) |  |  |  |  |  | $ | 16.02 |  |  |  |  |  |
| Forfeited |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Expired |  |  | (5 | ) |  |  |  |  |  | $ | 5.75 |  |  |  |  |  |
| Balance as of March 31, 2017 |  |  | 96,688 |  |  |  | 96,688 |  |  | $ | 15.70 |  |  |  |  |  |

[0001193125-18-155969:notes:38]
The following summarizes information for share options outstanding
 as of March 30, 2018 under the 2010 Plan:

[0001193125-18-155969:notes:39]
|  |  | Range of Exercise Price |  |  | Number of Shares Underlying Options |  |  | Weighted- Average Remaining Contractual Life (years) |  |  | Aggregate Intrinsic Value (amount in thousands) |  |
|  |  | $ | 14.12 |  |  |  | 21,638 |  |  |  | 0.61 |  |  |  |  |  |
|  |  | $ | 15.16 |  |  |  | 5,138 |  |  |  | 0.38 |  |  |  |  |  |
|  |  | $ | 18.60 |  |  |  | 5,550 |  |  |  | 0.92 |  |  |  |  |  |
| Options outstanding |  |  |  |  |  |  | 32,326 |  |  |  | 0.63 |  |  | $ | 528 |  |
| Options exercisable |  |  |  |  |  |  | 32,326 |  |  |  | 0.63 |  |  | $ | 528 |  |

[0001193125-18-155969:notes:40]
As of March 30, 2018, there was no unrecognized compensation
 cost for share options issued under the 2010 Plan.

[0001193125-18-155969:notes:41]
[same as prior period, unchanged from 0001193125-18-033890:notes:41]

[0001193125-18-155969:notes:42]
[same as prior period, unchanged from 0001193125-18-033890:notes:42]

[0001193125-18-155969:notes:43]
[same as prior period, unchanged from 0001193125-18-033890:notes:43]

[0001193125-18-155969:notes:44]
[same as prior period, unchanged from 0001193125-18-033890:notes:44]

[0001193125-18-155969:notes:45]
[same as prior period, unchanged from 0001193125-18-033890:notes:45]

[0001193125-18-155969:notes:46]
|  |  | Number of Shares |  |  | Weighted-Average Grant Date Fair Value Per Share |  |
| Balance as of June 30, 2017 |  |  | 1,058,605 |  |  | $ | 31.59 |  |
| Granted |  |  | 474,777 |  |  |  | 36.04 |  |
| Issued |  |  | (337,937 | ) |  |  | 28.01 |  |
| Forfeited |  |  | (95,981 | ) |  |  | 33.52 |  |
| Balance as of March 30, 2018 |  |  | 1,099,464 |  |  | $ | 34.44 |  |
|  |  | Number of Shares |  |  | Weighted-Average Grant Date Fair Value Per Share |  |
| Balance as of June 24, 2016 |  |  | 1,181,402 |  |  | $ | 18.34 |  |
| Granted |  |  | 796,298 |  |  |  | 39.42 |  |
| Issued |  |  | (835,785 | ) |  |  | 21.01 |  |
| Forfeited |  |  | (69,726 | ) |  |  | 25.33 |  |
| Balance as of March 31, 2017 |  |  | 1,072,189 |  |  | $ | 31.57 |  |

[0001193125-18-155969:notes:47]
[same as prior period, unchanged from 0001193125-18-033890:notes:48]

[0001193125-18-155969:notes:48]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 30, 2017 |  |  | 227,268 |  |  | $ | 40.48 |  |
| Granted |  |  | 378,624 | (1) |  |  | 37.16 |  |
| Issued |  |  | — |  |  |  | — |  |
| Forfeited |  |  | — |  |  |  | — |  |
| Balance as of March 30, 2018 |  |  | 605,892 |  |  | $ | 38.41 |  |
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 24, 2016 |  |  | — |  |  |  | — |  |
| Granted |  |  | 234,678 | (1) |  | $ | 40.48 |  |
| Issued |  |  | — |  |  |  | — |  |
| Forfeited |  |  | — |  |  |  | — |  |
| Balance as of March 31, 2017 |  |  | 234,678 |  |  | $ | 40.48 |  |

[0001193125-18-155969:notes:49]
| (1) | This represents the target number of performance share units (“PSUs”) granted. The actual number of PSUs that may be earned, if any, is dependent upon performance and may range from 0% to 100% percent of the target. |

[0001193125-18-155969:notes:50]
As of March 30, 2018, there was $15.9 million and
 $2.6 million of unrecognized share-based compensation expense
 related to restricted share units and performance share units,
 respectively, under the 2010 Plan and the 2017 Inducement Plan that
 are expected to be recorded over a weighted-average period of 2.55
 years and 1.03 years, respectively.

[0001193125-18-155969:notes:51]
For the nine months ended March 30, 2018 and March 31,
 2017, the Company withheld an aggregate of 101,080 shares and
 33,276 shares, respectively, upon the vesting of restricted share
 units, based upon the closing share price on the vesting date to
 settle the employees’ minimum statutory obligation for the
 applicable income and other employment taxes. For the nine months
 ended March 30, 2018 and March 31, 2017, the Company then
 remitted cash of $4.0 million and $1.3 million,
 respectively, to the appropriate taxing authorities, and presented
 it as a financing activity within the unaudited condensed
 consolidated statements of cash flows. The payment had the effect
 on shares issued by the Company as it reduced the number of shares
 that would have been issued on the vesting date and was recorded as
 a reduction of additional paid-in capital.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-18-155969:notes:52]
[same as prior period, unchanged from 0001193125-18-033890:notes:54]

[0001193125-18-155969:notes:53]
| (amount in thousands) |  | As of March 30, 2018 |  |  | As of June 30, 2017 |  |
| Raw materials |  | $ | 90,024 |  |  | $ | 88,640 |  |
| Work in progress |  |  | 114,348 |  |  |  | 105,732 |  |
| Finished goods |  |  | 24,010 |  |  |  | 33,998 |  |
| Goods in transit |  |  | 13,674 |  |  |  | 13,025 |  |
|  |  |  | 242,056 |  |  |  | 241,395 |  |
| Less: Inventory obsolescence |  |  | (2,439 | ) |  |  | (2,730 | ) |
| Inventory, net |  | $ | 239,617 |  |  | $ | 238,665 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-18-155969:notes:54]
New Accounting Pronouncements – adopted by the
 Company

[0001193125-18-155969:notes:55]
In February 2018, the FASB issued ASU 2018-02 “Income Statement
 – Reporting Comprehensive Income (Topic 220),
 Reclassification of Certain Tax Effects from Accumulated Other
 Comprehensive Income.” This ASU which allows companies to
 reclassify stranded tax effects in accumulated other comprehensive
 income (loss) that have been caused by the Tax Cuts and Jobs Act of
 2017 (the Act) to retained earnings for each period in which the
 effect of the change in the U.S. federal corporate income tax rate
 is recorded. The FASB has made the reclassification
 optional. In addition, in March 2018, the FASB issued ASU
 2018-05, “Income
 Taxes (Topic 740), Amendments to SEC Paragraphs Pursuant to SEC
 Staff Accounting Bulletin No. 118,” which updates the
 income tax accounting in U.S. GAAP to reflect SEC guidance released
 on December 22, 2017, when the Act was signed into law. The
 Company adopted these updates with no impact to the unaudited
 condensed consolidated financial statements.

[0001193125-18-155969:notes:56]
In August 2017, the FASB issued ASU 2017-12, “Derivatives and
 Hedging (Topic 815): Targeted Improvements to Accounting for
 Hedging Activities.” The amendments better align an
 entity’s risk management activities and financial reporting
 for hedging relationships through changes to both the designation
 and measurement guidance for qualifying hedging relationships and
 the presentation of hedge results. To meet that objective, the
 amendments expand and refine hedge accounting for both nonfinancial
 and financial risk components and align the recognition and
 presentation of the effects of the hedging instrument and the
 hedged item in the financial statements. The amendments also make
 certain targeted improvements to simplify the application of hedge
 accounting guidance and ease the administrative burden of hedge
 documentation requirements and assessing hedge effectiveness. This
 ASU is the final version of Proposed Accounting Standards Update
 2016-310—Derivatives
 and Hedging (Topic 815): Targeted Improvements to Accounting for
 Hedging Activities, which has been deleted. During the first nine
 months of fiscal year 2018, the Company adopted this update with no
 impact to the unaudited condensed consolidated financial
 statements.

[0001193125-18-155969:notes:57]
In November 2016, the FASB issued ASU 2016-18, “Statement of Cash
 Flows (Topic 230): Restricted Cash,” which requires the
 statement of cash flows to explain the change during the period in
 the total of cash, cash equivalents and restricted cash or
 restricted cash equivalents. The Company has early adopted this
 update in the second quarter of fiscal year 2017 on a retrospective
 basis. As of March 30, 2018, restricted cash in connection
 with business acquisition of $3.6 million was presented in the
 statement of cash flows as cash, cash equivalents and restricted
 cash.

[0001193125-18-155969:notes:58]
In March 2016, the FASB issued ASU 2016-09, “Compensation
 – Stock Compensation (Topic 718): Improvements to Employee
 Share-Based Payment Accounting.” This ASU simplifies several
 aspects of the accounting for share-based payment award
 transactions, including, the income tax consequences,
 classification of awards as either equity or liabilities and
 classification on the statement of cash flows. The amendments in
 this update are effective for annual periods beginning after
 December 15, 2016, and interim periods within those annual
 periods, for public companies. Early adoption is permitted for any
 entity in any interim or annual period. During the first nine
 months of fiscal year 2018, the Company adopted this update with no
 impact to the unaudited condensed consolidated financial
 statements.

[0001193125-18-155969:notes:59]
In March 2016, the FASB issued ASU 2016-05, “Derivatives and
 Hedging (Topic 815),” to clarify that a change in the
 counterparty to a derivative instrument that has been designated as
 a hedging instrument under Topic 815, does not, in and of itself,
 require designation of the hedging relationship, provided that all
 other hedge accounting criteria continue to be met. This guidance
 is effective for public entities for financial statements issued
 for fiscal years beginning after December 15, 2016 and interim
 periods within those fiscal years. During the first nine months of
 fiscal year 2018, the Company adopted this update with no impact to
 the unaudited condensed consolidated financial statements.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-18-155969:notes:60]
The changes in AOCI for the nine months ended March 30, 2018
 were as follows:

[0001193125-18-155969:notes:61]
| (amount in thousands) |  | Unrealized net Losses on Marketable Securities |  |  | Unrealized net Gains (Losses) on Derivative Instruments |  |  | Foreign Currency Translation Adjustment (Losses) Gains |  |  | Total |  |
| Balance as of June 30, 2017 |  | $ | (72 | ) |  | $ | 34 |  |  | $ | (310 | ) |  | $ | (348 | ) |
| Other comprehensive (loss) income before reclassification adjustment |  |  | (361 | ) |  |  | — |  |  |  | 1,358 |  |  |  | 997 |  |
| Amounts reclassified out of AOCI to foreign exchange loss, net in the unaudited condensed consolidated statements of operations and comprehensive income |  |  | (687 | ) |  |  | (1 | ) |  |  | — |  |  |  | (688 | ) |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive (loss) income |  | $ | (1,048 | ) |  | $ | (1 | ) |  | $ | 1,358 |  |  | $ | 309 |  |
| Balance as of March 30, 2018 |  | $ | (1,120 | ) |  | $ | 33 |  |  | $ | 1,048 |  |  | $ | (39 | ) |

[0001193125-18-155969:notes:62]
The changes in AOCI for the nine months ended March 31, 2017
 were as follows:

[0001193125-18-155969:notes:63]
| (amount in thousands) |  | Unrealized net (Losses) Gains on Marketable Securities |  |  | Unrealized net Gains (Losses) on Derivative Instruments |  |  | Foreign Currency Translation Adjustment (Losses) Gains |  |  | Total |  |
| Balance as of June 24, 2016 |  | $ | 399 |  |  | $ | 192 |  |  | $ | — |  |  | $ | 591 |  |
| Other comprehensive income (loss) before reclassification adjustment |  |  | 75 |  |  |  | — |  |  |  | (935 | ) |  |  | (860 | ) |
| Amounts reclassified out of AOCI to foreign exchange loss, net in the unaudited condensed consolidated statements of operations and comprehensive income |  |  | (566 | ) |  |  | (158 | ) |  |  | — |  |  |  | (724 | ) |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive loss |  | $ | (491 | ) |  | $ | (158 | ) |  | $ | (935 | ) |  | $ | (1,584 | ) |
| Balance as of March 31, 2017 |  | $ | (92 | ) |  | $ | 34 |  |  | $ | (935 | ) |  | $ | (993 | ) |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001193125-18-155969:notes:64]
The movements of long-term loans for the nine months ended
 March 30, 2018 and March 31, 2017 were as follows:

[0001193125-18-155969:notes:65]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 30, 2018 |  |  | March 31, 2017 |  |
| Opening balance |  | $ | 36,400 |  |  | $ | 54,500 |  |
| Repayments during the period |  |  | (10,200 | ) |  |  | (14,700 | ) |
| Closing balance |  | $ | 26,200 |  |  | $ | 39,800 |  |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock

[0001193125-18-155969:notes:66]
Undrawn available credit facilities classified by availability
 period of future borrowing as of March 30, 2018 and
 June 30, 2017 were as follows:

[0001193125-18-155969:notes:67]
| (amount in thousands) |  | March 30, 2018 |  |  | June 30, 2017 |  |
| Short-term |  | $ | — |  |  | $ | 1,965 |  |
| Long-term |  | $ | 111,000 |  |  | $ | 116,000 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-18-155969:notes:68]
[same as prior period, unchanged from 0001193125-18-033890:notes:69]

[0001193125-18-155969:notes:69]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 30, 2018 |  |  | March 31, 2017 |  |  | March 30, 2018 |  |  | March 31, 2017 |  |
| North America |  | $ | 160,926 |  |  | $ | 154,708 |  |  | $ | 470,084 |  |  | $ | 478,700 |  |
| Asia-Pacific |  |  | 122,631 |  |  |  | 149,271 |  |  |  | 395,848 |  |  |  | 400,708 |  |
| Europe |  |  | 48,656 |  |  |  | 62,858 |  |  |  | 160,666 |  |  |  | 170,628 |  |
|  |  | $ | 332,213 |  |  | $ | 366,837 |  |  | $ | 1,026,598 |  |  | $ | 1,050,036 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-18-155969:notes:70]
[same as prior period, unchanged from 0001193125-18-033890:notes:71]

[0001193125-18-155969:notes:71]
[same as prior period, unchanged from 0001193125-18-033890:notes:72]

[0001193125-18-155969:notes:72]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of March 30, 2018 and for the three
 and nine months ended March 30, 2018 and March 31, 2017
 include normal recurring adjustments, necessary for a fair
 statement of the financial statements set forth herein, in
 accordance with accounting principles generally accepted in the
 United States of America (“U.S. GAAP”) for interim
 financial information and the rules and regulations of the
 Securities and Exchange Commission (“SEC”).
 Accordingly, such information does not include all of the
 information and footnotes required by U.S. GAAP for annual
 financial statements. For further information, please refer to the
 consolidated financial statements and footnotes thereto included in
 Fabrinet’s Annual Report on Form 10-K for the year ended June 30,
 2017.

[0001193125-18-155969:notes:73]
The balance sheet as of June 30, 2017 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three and nine
 months ended March 30, 2018 may not be indicative of results
 for the year ending June 29, 2018 or any future periods.

[0001193125-18-155969:notes:74]
[same as prior period, unchanged from 0001193125-18-033890:notes:75]

[0001193125-18-155969:notes:75]
[same as prior period, unchanged from 0001193125-18-033890:notes:76]

[0001193125-18-155969:notes:76]
[same as prior period, unchanged from 0001193125-18-033890:notes:77]

[0001193125-18-155969:notes:77]
[same as prior period, unchanged from 0001193125-18-033890:notes:78]

[0001193125-18-155969:notes:78]
The Company utilizes a 52-53 week fiscal year ending on the
 Friday in June closest to June 30. The three months ended
 March 30, 2018 and March 31, 2017 each consisted of 13
 weeks. The nine months ended March 30, 2018 and March 31,
 2017 consisted of 39 weeks and 40 weeks, respectively. Fiscal year
 2018 will be comprised of 52 weeks and will end on June 29,
 2018.

[0001193125-18-155969:notes:79]
[same as prior period, unchanged from 0001193125-18-033890:notes:80]

[0001193125-18-155969:notes:80]
[same as prior period, unchanged from 0001193125-18-033890:notes:81]

[0001193125-18-155969:notes:81]
[same as prior period, unchanged from 0001193125-18-033890:notes:82]

[0001193125-18-155969:notes:82]
[same as prior period, unchanged from 0001193125-18-033890:notes:83]

[0001193125-18-155969:notes:83]
[same as prior period, unchanged from 0001193125-18-033890:notes:84]

[0001193125-18-155969:notes:84]
In November 2017, the Financial Accounting Standards Board
 (“FASB”) issued Accounting Standards Update
 (“ASU”) 2017-14, “Income Statement
 – Reporting Comprehensive Income (Topic 220), Revenue
 Recognition (Topic 605), and Revenue from Contracts with Customers
 (Topic 606): Amendments to SEC Paragraphs Pursuant to the Staff
 Accounting Bulletin (“SAB”) No. 116 and SEC
 Release No. 33-10403”. This ASU
 amended, superseded and added certain SEC paragraphs in Topic 220,
 Topic 605 and Topic 606 to reflect the August 2017 issuance of SEC
 Staff Accounting Bulletin (SAB) 116 and SEC Release No. 33-10403. The SEC staff
 issued SAB 116 to align its revenue guidance with Accounting
 Standards Codification (ASC) 606. For public business entities,
 this update is effective for fiscal years beginning after
 December 15, 2017, including interim periods within those
 fiscal years. Early application is permitted. The Company is
 currently evaluating the impact of the adoption of this update on
 its consolidated financial statements.

[0001193125-18-155969:notes:85]
In September 2017, the FASB issued ASU 2017-13, “Revenue Recognition
 (Topic 605), Revenue from Contracts with Customers (Topic 606),
 Leases (Topic 840), and Leases (Topic 842): Amendments to SEC
 Paragraphs Pursuant to the Staff Announcement at the July 20,
 2017 EITF Meeting and Rescission of Prior SEC Staff Announcements
 and Observer Comments.” The amendment delays the mandatory
 adoption of Topic 606 and Topic 842 for certain entities, revises
 the guidance related to performance-based incentive fees in Topic
 605 and revises the guidance related to leases in Topic 840 and
 Topic 842. The revisions to the lease guidance eliminate language
 specific to certain sale-leaseback arrangements, guarantees of
 lease residual assets and loans made by lessees to owner-lessors.
 Also included is an amendment to Topic 842 to retain the guidance
 in Topic 840 covering the impact of changes in tax rates on
 investments in leveraged leases. This guidance, which is effective
 immediately, generally relates to the adoption of Topic 606 and
 Topic 842. The Company does not expect the amendments will impact
 its consolidated financial statements.

[0001193125-18-155969:notes:86]
In January 2017, the FASB issued ASU 2017-04, “Intangibles –
 Goodwill and Other (Topic 350): Simplifying the Test for Goodwill
 Impairment.” This amendment modified the concept of
 impairment assessment from the condition that exists when the
 carrying amount of goodwill exceeds its implied fair value to the
 condition that exists when the carrying amount of a reporting unit
 exceeds its fair value. Public companies that are SEC filers should
 adopt the amendment for its annual and any interim goodwill
 impairment tests in fiscal years beginning after December 15,
 2019. Early adoption is permitted for interim or annual goodwill
 impairment tests performed on testing dates after January 1,
 2017. The Company is currently evaluating the impact of the
 adoption of this update on its consolidated financial
 statements.

[0001193125-18-155969:notes:87]
In January 2017, the FASB issued ASU 2017-03, “Accounting Changes and
 Error Corrections (Topic 250) and Investments – Equity Method
 and Joint Ventures (Topic 323): Amendments to SEC Paragraphs
 Pursuant to Staff Announcements at the September 22, 2016 and
 November 17, 2016 EITF Meetings.” The amendment provides
 guidance to the Company in relation to the disclosure of the impact
 that ASU 2014-09, ASU
 2016-02 and ASU
 2016-13 will have on the
 Company’s financial statements when adopted. The Company is
 currently evaluating the impact of the adoption of this update on
 its consolidated financial statements.

[0001193125-18-155969:notes:88]
In January 2017, the FASB issued ASU 2017-01, “Business Combination
 (Topic 805): Clarifying the Definition of a Business.” This
 amendment clarifies the definition of a business to assist entities
 when evaluating whether transactions should be accounted for as
 acquisitions (or disposals) of assets or business. For public
 companies, this ASU is effective for annual periods beginning after
 December 15, 2017, including interim periods within those
 periods. Early adoption is permitted for the transactions that
 occur before the issuance date or effective date of the amendment,
 only when the transaction has not been reported in financial
 statements that have been issued or made available for issuance.
 The Company does not expect that the adoption of this update will
 have a material impact on its consolidated financial
 statements.

[0001193125-18-155969:notes:89]
In August 2016, the FASB issued ASU 2016-15, “Classification of
 Certain Cash Receipts and Cash Payments (a consensus of the
 Emerging Issues Task Force).” The amendments in this ASU
 provide guidance on the presentation of certain cash receipts and
 cash payments in the statement of cash flows in order to reduce
 diversity in existing practice. The amendments in ASU 2016-15 are effective for public
 business entities for fiscal years beginning after
 December 15, 2017, and interim periods within those fiscal
 years. Early adoption is permitted, including adoption in an
 interim period. The Company is currently evaluating the impact of
 the adoption of this update on its consolidated financial
 statements.

[0001193125-18-155969:notes:90]
In February 2016, the FASB issued ASU 2016-02, “Lease (Topic
 842).” The core principle of Topic 842 is that a lessee
 should recognize the lease assets and liabilities that arise from
 leases in the statement of financial position. For public business
 entities, this update is effective for fiscal years beginning after
 December 15, 2018, including interim periods within those
 fiscal years. Early application is permitted. The Company is
 currently evaluating the impact of the adoption of this update on
 its consolidated financial statements.

[0001193125-18-155969:notes:91]
In January 2016, the FASB issued ASU 2016-01, “Financial Instruments
 – Overall (Subtopic 825-10): Recognition and Measurement
 of Financial Assets and Financial Liabilities.” This new
 guidance requires certain equity investments to be measured at fair
 value, use of the exit price notion and separate presentation of
 financial assets and financial liabilities by measurement category
 and form of financial asset on the balance sheet or the
 accompanying notes to the financial statements. The ASU on
 recognition and measurement will take effect for public companies
 for fiscal years beginning after December 15, 2017, including
 interim periods within those fiscal years. In addition, in
 February 2018, the FASB issued ASU 2018-03, “Technical Corrections
 and Improvements to Financial Instruments – Overall (Subtopic
 825-10), Recognition and
 Measurement of Financial Assets and Financial Liabilities. This
 guidance clarifies certain aspects of the guidance issued in ASU
 2016-01 on (1) equity
 securities without a readily determinable fair value –
 discontinuation, (2) equity securities without a readily
 determinable fair value – adjustments, (3) forward
 contracts and purchased options, (4) presentation requirements
 for certain fair value option liabilities, and (5) fair value
 option liabilities denominated in a foreign currency. The Company
 is currently evaluating the impact of the adoption of this update
 on its consolidated financial statements.

[0001193125-18-155969:notes:92]
In May 2014, the FASB issued ASU 2014-09, “Revenue from Contracts
 with Customers (Topic 606), issued as a new Topic, Accounting
 Standards Codification.” The core principle of this amendment
 is that an entity should recognize revenue to depict the transfer
 of promised goods or services to customers in an amount that
 reflects the consideration to which the entity expects to be
 entitled in exchange for those goods or services. This update is
 effective for public companies, as amended by ASU 2015-14, for annual reporting periods
 beginning after December 15, 2017, including interim periods
 within that reporting period. Earlier application of this guidance
 is permitted, but not before the original date of December 15,
 2016, which can be adopted either retrospectively to each prior
 reporting period presented or as a cumulative-effect adjustment as
 of the date of adoption. Subsequently, in March 2016 and April
 2016, the FASB issued ASU 2016-08 and ASU 2016-10, respectively, to clarify the
 implementation guidance on principle versus agent considerations
 and address the potential diversity in practice at initial
 application and cost; and the complexity of applying Topic 606,
 both at transition and on an ongoing basis related to
 identification of performance obligations and licensing
 arrangements; and ASU 2016-12 and ASU 2016-20 in May 2016 and December 2016,
 respectively, to improve certain aspects of Topic 606, with the
 same effective date as ASU 2015-14. The Company will adopt this
 standard during its fiscal year ending June 28, 2019. In the
 current period, the Company is assessing the contracts with its
 customers to identify the impact to its consolidated financial
 statements. The Company expects to conclude the impact to its
 consolidated financial statements in the coming quarter.


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001193125-18-155969:notes:93]
[same as prior period, unchanged from 0001193125-18-033890:notes:94]

[0001193125-18-155969:notes:94]
[same as prior period, unchanged from 0001193125-18-033890:notes:95]

[0001193125-18-155969:notes:95]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Loss |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of March 30, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 127,279 |  |  | $ | — |  |  | $ | 127,279 |  |  | $ | — |  |
| Cash equivalents |  |  | 15,128 |  |  |  | — |  |  |  | 15,128 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 125,356 |  |  |  | (814 | ) |  |  | — |  |  |  | 124,542 |  |
| U.S. agency and U.S. treasury securities |  |  | 40,910 |  |  |  | (281 | ) |  |  | — |  |  |  | 40,629 |  |
| Sovereign and municipal securities |  |  | 4,300 |  |  |  | (27 | ) |  |  | — |  |  |  | 4,273 |  |
| Total |  | $ | 312,973 |  |  | $ | (1,122 | ) |  | $ | 142,407 |  |  | $ | 169,444 |  |
|  |  |  |  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Gain/(Loss) |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of June 30, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 131,240 |  |  | $ | — |  |  | $ | 131,240 |  |  | $ | — |  |
| Cash equivalents |  |  | 2,585 |  |  |  | — |  |  |  | 2,585 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 98,247 |  |  |  | 27 |  |  |  | — |  |  |  | 98,274 |  |
| U.S. agency and U.S. treasury securities |  |  | 50,768 |  |  |  | (102 | ) |  |  | — |  |  |  | 50,666 |  |
| Sovereign and municipal securities |  |  | 2,507 |  |  |  | 3 |  |  |  | — |  |  |  | 2,510 |  |
| Total |  | $ | 285,347 |  |  | $ | (72 | ) |  | $ | 133,825 |  |  | $ | 151,450 |  |

[0001193125-18-155969:notes:96]
[same as prior period, unchanged from 0001193125-18-033890:notes:98]

[0001193125-18-155969:notes:97]
During the nine months ended March 30, 2018, the Company
 recognized a realized loss of $0.4 million from sales and
 maturities of available-for-sale
 securities.

[0001193125-18-155969:notes:98]
As of March 30, 2018, the Company considered the declines in
 market value of its marketable securities investment portfolio to
 be temporary in nature and did not consider any of its securities
 other-than-temporarily impaired. The Company typically invests in
 highly-rated securities, and its investment policy generally limits
 the amount of credit exposure to any one issuer. The policy
 requires investments generally to be investment grade, with the
 primary objective of minimizing the potential risk of principal
 loss. Fair values were determined for each individual security in
 the investment portfolio. When evaluating an investment for
 other-than-temporary impairment, the Company reviews factors such
 as the length of time and extent to which fair value has been below
 its cost basis, the financial condition of the issuer and any
 changes thereto, changes in market interest rates, and the
 Company’s intent to sell, or whether it is more likely than
 not it will be required to sell, the investment before recovery of
 the investment’s cost basis. No impairment losses were
 recorded for the nine months ended March 30, 2018.

[0001193125-18-155969:notes:99]
As of March 30, 2018, cash, cash equivalents, and marketable
 securities included bank deposits of $40.0 million held in
 various financial institutions located in the United States in
 order to support the availability of the Facility Agreement (as
 defined in Note 11) and comply with covenants. As discussed in Note
 11, under the terms and conditions of the Facility Agreement, the
 Company must maintain cash, cash equivalents and marketable
 securities in an aggregate amount not less than $40.0 million
 in unencumbered deposits, and/or securities in accounts located in
 the United States at all times during the term of the Facility
 Agreement. The Company must comply with this covenant from and
 after the effective date of the Facility Agreement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-18-155969:notes:100]
[same as prior period, unchanged from 0001193125-18-033890:notes:102]

[0001193125-18-155969:notes:101]
As of March 30, 2018 and June 30, 2017, the liability for
 uncertain tax positions including accrued interest and penalties
 was $2.2 million and $2.0 million, respectively. The
 Company expects the estimated amount of liability associated with
 its uncertain tax positions to decrease within the next
 12 months due to the lapse of the applicable statute of
 limitations in foreign tax jurisdictions.

[0001193125-18-155969:notes:102]
[same as prior period, unchanged from 0001193125-18-033890:notes:104]

[0001193125-18-155969:notes:103]
The effective tax rates for the Company for the three months ended
 March 30, 2018 and March 31, 2017 were 6.2% and 6.5%,
 respectively, of net income. The decrease was primarily due to the
 fact that the Company had higher income not subject to tax during
 the three months ended March 30, 2018, compared with the three
 months ended March 31, 2017.

[0001193125-18-155969:notes:104]
The effective tax rates for the Company for the nine months ended
 March 30, 2018 and March 31, 2017 were 6.3% and 6.7%,
 respectively, of net income. The decrease was primarily due to the
 fact that the Company had higher income not subject to tax during
 the nine months ended March 30, 2018, compared with the nine
 months ended March 31, 2017.

[0001193125-18-155969:notes:105]
[same as prior period, unchanged from 0001193125-18-033890:notes:107]


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001193125-18-155969:notes:106]
[same as prior period, unchanged from 0001193125-18-033890:notes:108]

[0001193125-18-155969:notes:107]
| (amount in thousands) |  | As of March 30, 2018 |  |  | As of June 30, 2017 |  |
| Trade accounts receivable |  | $ | 244,081 |  |  | $ | 264,389 |  |
| Less: allowance for doubtful account |  |  | (84 | ) |  |  | (40 | ) |
| Trade accounts receivable, net |  | $ | 243,997 |  |  | $ | 264,349 |  |

[0001193125-18-155969:notes:108]
As of June 30, 2017, trade accounts receivable of
 $3.0 million were secured to short-term loans from bank.
 During the three months ended September 29, 2017, these loans
 were fully repaid and the secured trade accounts receivable were
 released.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001193125-18-155969:notes:109]
The Company’s total borrowings, including short-term and
 long-term borrowings, consisted of the following:

[0001193125-18-155969:notes:110]
| (amount in thousands) |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  | Maturity |  |  | As of March 30, 2018 |  |  | As of June 30, 2017 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR(1) + 1.75% per annum |  | Repayable in 1 to 6 months |  |  | April 2018 | (2) |  | $ | 39,000 |  |  | $ | 34,000 |  |
| Short-term loans from bank: |  |
| Bank Base rate +1.85% per annum |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  |  |  | — |  |  |  | 1,003 |  |
| Current portion of long-term borrowing |  |  |  | 13,600 |  |  |  | 13,600 |  |
|  |  |  |  | 52,600 |  |  |  | 48,603 |  |
| Less: Unamortized debt issuance costs |  |  |  | (136 | ) |  |  | (201 | ) |
|  |  |  |  |  |  |  |  | $ | 52,464 |  |  | $ | 48,402 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  | Repayable in quarterly installments |  |  | May 2019 |  |  | $ | 26,200 |  |  | $ | 36,400 |  |
| Less: Current portion |  |  |  |  |  |  |  |  | (13,600 | ) |  |  | (13,600 | ) |
| Unamortized debt issuance costs |  |  |  | (5 | ) |  |  | (99 | ) |
| Non-current portion |  |  |  |  |  |  |  | $ | 12,595 |  |  | $ | 22,701 |  |

[0001193125-18-155969:notes:111]
| (1) | LIBOR is London Interbank Offered Rate. |

[0001193125-18-155969:notes:112]
| (2) | In March 2018, the maturity date was extended to April 2018. |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-18-155969:notes:113]
Based on the carrying amount of intangibles as of March 30,
 2018, and assuming no future impairment of the underlying assets,
 the estimated future amortization during each fiscal year was as
 follows:

[0001193125-18-155969:notes:114]
| (amount in thousands) |  |  |  |
| 2018 (remaining three months) |  | $ | 505 |  |
| 2019 |  |  | 1,675 |  |
| 2020 |  |  | 1,146 |  |
| 2021 |  |  | 993 |  |
| 2022 |  |  | 724 |  |
| Thereafter |  |  | 884 |  |
| Total |  | $ | 5,927 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001193125-18-155969:notes:115]
[same as prior period, unchanged from 0001193125-18-033890:notes:116]

[0001193125-18-155969:notes:116]
| (amount in thousands) |  | Goodwill |  |
| Balance as of June 30, 2017 |  | $ | 3,806 |  |
| Foreign currency translation adjustment |  |  | 295 |  |
| Balance as of March 30, 2018 |  | $ | 4,101 |  |

[0001193125-18-155969:notes:117]
| (amount in thousands) |  | Goodwill |  |
| Balance as of June 24, 2016 |  | $ | — |  |
| Addition in connection with business acquisition |  |  | 3,883 |  |
| Foreign currency translation adjustment |  |  | (77 | ) |
| Balance as of June 30, 2017 |  | $ | 3,806 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001193125-18-155969:notes:118]
As of March 30, 2018, future maturities of long-term debt
 during each fiscal year were as follows:

[0001193125-18-155969:notes:119]
| (amount in thousands) |  |  |  |
| 2018 (remaining three months) |  | $ | 3,400 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 26,200 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-18-155969:notes:120]
[same as prior period, unchanged from 0001193125-18-033890:notes:120]

[0001193125-18-155969:notes:121]
[same as prior period, unchanged from 0001193125-18-033890:notes:121]

[0001193125-18-155969:notes:122]
[same as prior period, unchanged from 0001193125-18-033890:notes:122]

[0001193125-18-155969:notes:123]
The allocation of consideration to the individual net assets
 acquired was finalized in the fourth quarter of fiscal year 2017.
 As the functional currency of Fabrinet UK is pound sterling
 (“GBP”), for the nine months ended March 30, 2018
 and March 31, 2017, the Company recognized a $1.4 million
 gain and a $0.9 million loss, respectively, from foreign
 currency translation adjustment in its unaudited condensed
 consolidated statements of operations and comprehensive income
 under other comprehensive income, net of tax.

[0001193125-18-155969:notes:124]
[same as prior period, unchanged from 0001193125-18-033890:notes:124]

[0001193125-18-155969:notes:125]
[same as prior period, unchanged from 0001193125-18-033890:notes:125]

[0001193125-18-155969:notes:126]
In connection with the Company’s acquisition of Fabrinet UK,
 the Company assumed lease agreements for certain machine and
 equipment, which are accounted for as capital leases. As of
 March 30, 2018 and June 30, 2017, the Company included
 approximately $1.6 million and $1.9 million,
 respectively, of capital lease assets and $1.2 million and
 $1.4 million, respectively, of capital lease liability in the
 unaudited condensed consolidated balance sheets associated with
 these acquired lease agreements.

[0001193125-18-155969:notes:127]
During the nine months ended March 31, 2017, the Company
 incurred approximately $1.5 million in transaction costs
 related to the acquisition, which primarily consisted of legal,
 accounting and valuation-related expenses. These expenses were
 recorded in selling, general and administrative expense in the
 accompanying unaudited condensed consolidated statements of
 operations and comprehensive income.

[0001193125-18-155969:notes:128]
During the nine months ended March 30, 2018, there were no
 transaction costs related to the acquisition.

[0001193125-18-155969:notes:129]
[same as prior period, unchanged from 0001193125-18-033890:notes:129]

[0001193125-18-155969:notes:130]
[same as prior period, unchanged from 0001193125-18-033890:notes:130]

[0001193125-18-155969:notes:131]
[same as prior period, unchanged from 0001193125-18-033890:notes:131]

[0001193125-18-155969:notes:132]
[same as prior period, unchanged from 0001193125-18-033890:notes:132]

[0001193125-18-155969:notes:133]
[same as prior period, unchanged from 0001193125-18-033890:notes:133]

[0001193125-18-155969:notes:134]
[same as prior period, unchanged from 0001193125-18-033890:notes:134]

[0001193125-18-155969:notes:135]
[same as prior period, unchanged from 0001193125-18-033890:notes:135]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-18-155969:notes:136]
15. Accumulated other comprehensive income


## us-gaap:DebtDisclosureTextBlock

[0001193125-18-155969:notes:137]
| 11. | Borrowings |

[0001193125-18-155969:notes:138]
Credit facilities:

[0001193125-18-155969:notes:139]
Fabrinet entered into a syndicated senior credit facility agreement
 (the “Facility Agreement”) with a consortium of banks
 on May 22, 2014. The Facility Agreement, led by Bank of
 America, provides for a $200.0 million credit line, comprised
 of a $150.0 million revolving loan facility and a
 $50.0 million delayed draw term loan facility. The revolving
 loan facility contains an accordion feature permitting Fabrinet to
 request an increase in the facility up to $100.0 million
 subject to customary terms and conditions and provided that no
 default or event of default exists at the time of request. The
 revolving loan facility terminates and all amounts outstanding are
 due and payable in full on May 22, 2019. The principal amount
 of any drawn term loans must be repaid according to scheduled
 quarterly amortization payments, with final payment of all amounts
 outstanding, plus accrued interest, being due May 22,
 2019.

[0001193125-18-155969:notes:140]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. On
 July 22, 2016, the Company entered into the Fourth Amendment
 to the Facility Agreement to change the timing of filing certain
 financial information with the bank. The Company fully drew
 down the term loan facility in fiscal year 2016. As of
 March 30, 2018, $39.0 million of the revolving borrowing
 and $26.2 million of the term loan borrowing was outstanding
 under the Facility Agreement, resulting in available credit
 facilities of $111.0 million. Borrowings under the revolving
 credit facility are classified as current liabilities in the
 unaudited condensed consolidated balance sheets as the Company has
 the periodic option to renew or pay, all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. During March 2018, the Company
 sent notices to the bank to renew the maturity date of its
 revolving borrowings. The bank approved the notices and extended
 the maturity to April 2018.

[0001193125-18-155969:notes:141]
Loans under the Facility Agreement bear interest, at
 Fabrinet’s option, at a rate per annum equal to a LIBOR rate
 plus a spread of 1.75% to 2.50%, or a base rate plus a spread of
 0.75% to 1.50%, determined in accordance with the Facility
 Agreement in each case with such spread determined based on
 Fabrinet’s consolidated total leverage ratio for the
 preceding four fiscal quarter period. Interest is due and payable
 quarterly in arrears for loans bearing interest at the base rate
 and at the end of an interest period (or at each three-month
 interval in the case of loans with interest periods greater than
 three months) in the case of loans bearing interest at the LIBOR
 rate.

[0001193125-18-155969:notes:142]
On July 24, 2017, the Company entered into an interest rate
 swap agreement (the “Swap Agreement”), which the
 Company did not designate as hedging instruments. The Swap
 Agreement was used to mitigate interest rate risk and improve the
 interest rate profile of the Company’s debt obligations. The
 terms of the Swap Agreement effectively convert the floating
 interest rate of the term loans under the Facility Agreement to the
 fixed interest rate of 1.55% per annum through maturity of the term
 loan in May 2019. The swap transactions are due and settled
 monthly. During the nine months ended March 30, 2018, the
 Company included a net loss of $0.04 million from the
 settlement of the Swap Agreement as interest expenses in the
 unaudited condensed consolidated statements of operations and
 comprehensive income.

[0001193125-18-155969:notes:143]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material of
 its subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or
 the equivalent under the local law, can be effected.

[0001193125-18-155969:notes:144]
The Facility Agreement contains customary affirmative and negative
 covenants. Negative covenants include, among other things,
 limitations on liens, indebtedness, investments, mergers, sales of
 assets, changes in the nature of the business, dividends and
 distributions, affiliate transactions and capital expenditures. The
 Facility Agreement contains financial covenants requiring Fabrinet
 to maintain: (1) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (2) a minimum debt service coverage ratio of
 not less than 1.50:1.00; (3) a maximum senior leverage ratio of not
 more than 2.50:1.00; and (4) a minimum quick ratio of not less
 than 1.10:1.00. Each of these financial covenants is calculated on
 a consolidated basis for the consecutive four fiscal quarter period
 then ended. As of March 30, 2018, the Company was in
 compliance with all covenants under the Facility Agreement.

[0001193125-18-155969:notes:145]
The Facility Agreement also contains customary events of default
 including, among other things, payment defaults, breaches of
 covenants or representations and warranties, cross-defaults with
 certain other indebtedness, bankruptcy and insolvency events and
 change in control of Fabrinet, subject to grace periods in certain
 instances. Upon an event of default, the lenders may terminate
 their commitments, declare all or a portion of the outstanding
 obligations payable by Fabrinet to be immediately due and payable
 and exercise other rights and remedies provided for under the
 Facility Agreement.

[0001193125-18-155969:notes:146]
Fabrinet intends to use the proceeds of the credit line to finance
 its future manufacturing buildings in the United States and
 Thailand, and for general corporate purposes including mergers and
 acquisitions of complementary manufacturing businesses or
 technology, although Fabrinet has no current commitments with
 respect to any such acquisitions.

[0001193125-18-155969:notes:147]
Short-term loans from bank

[0001193125-18-155969:notes:148]
In connection with the business acquisition in the first quarter of
 fiscal year 2017, the Company assumed a secured borrowing
 agreement. In the first quarter of fiscal year 2018, the Company
 fully repaid these short-term loans and sent a notification letter
 to the bank to terminate this secured borrowing agreement. As a
 result, the bank released secured trade accounts receivable and the
 way chattels mortgage over the plant and machine of Fabrinet
 UK.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-18-155969:notes:149]
[same as prior period, unchanged from 0001193125-18-033890:notes:150]

[0001193125-18-155969:notes:150]
[same as prior period, unchanged from 0001193125-18-033890:notes:151]

[0001193125-18-155969:notes:151]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net |  |
| As of March 30, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 7,532 |  |  | $ | (4,955 | ) |  | $ | — |  |  | $ | 2,577 |  |
| Customer relationships |  |  | 4,373 |  |  |  | (1,228 | ) |  |  | 177 |  |  |  | 3,322 |  |
| Backlog |  |  | 119 |  |  |  | (92 | ) |  |  | 1 |  |  |  | 28 |  |
| Total intangibles |  | $ | 12,024 |  |  | $ | (6,275 | ) |  | $ | 178 |  |  | $ | 5,927 |  |
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net |  |
| As of June 30, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 5,944 |  |  | $ | (3,850 | ) |  | $ | — |  |  | $ | 2,094 |  |
| Customer relationships |  |  | 4,373 |  |  |  | (606 | ) |  |  | (88 | ) |  |  | 3,679 |  |
| Backlog |  |  | 119 |  |  |  | (51 | ) |  |  | (1 | ) |  |  | 67 |  |
| Total intangibles |  | $ | 10,436 |  |  | $ | (4,507 | ) |  | $ | (89 | ) |  | $ | 5,840 |  |

[0001193125-18-155969:notes:152]
The Company recorded amortization expense relating to intangibles
 of $0.5 million and $0.9 million for the three months
 ended March 30, 2018 and March 31, 2017, respectively,
 and $1.4 million and $1.1 million for the nine months
 ended March 30, 2018 and March 31, 2017,
 respectively.

[0001193125-18-155969:notes:153]
[same as prior period, unchanged from 0001193125-18-033890:notes:155]

[0001193125-18-155969:notes:154]
| (years) |  | As of March 30, 2018 |  |  | As of June 30, 2017 |  |
| Customer relationships |  |  | 6.3 |  |  |  | 6.9 |  |
| Backlog |  |  | 1.1 |  |  |  | 1.6 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-18-155969:notes:155]
[same as prior period, unchanged from 0001193125-18-033890:notes:157]

[0001193125-18-155969:notes:156]
[same as prior period, unchanged from 0001193125-18-033890:notes:158]

[0001193125-18-155969:notes:157]
The Company’s authorized share capital is 500,000,000
 ordinary shares, par value of $0.01 per ordinary share, and
 5,000,000 preferred shares, par value of $0.01 per preferred
 share.

[0001193125-18-155969:notes:158]
For the nine months ended March 30, 2018, Fabrinet issued
 62,862 ordinary shares upon the exercise of options, for cash
 consideration at a weighted-average exercise price of $15.80 per
 share, and 236,857 ordinary shares upon the vesting of restricted
 share units, net of shares withheld.

[0001193125-18-155969:notes:159]
[same as prior period, unchanged from 0001193125-18-033890:notes:161]

[0001193125-18-155969:notes:160]
[same as prior period, unchanged from 0001193125-18-033890:notes:162]

[0001193125-18-155969:notes:161]
In August 2017, the Company’s board of directors approved a
 share repurchase program to permit the Company to repurchase up to
 $30.0 million worth of its issued and outstanding ordinary
 shares in the open market in accordance with applicable rules and
 regulations. In February 2018, the Company’s board of
 directors approved a $30.0 million increase to the share
 repurchase authorization. During the three and nine months ended
 March 30, 2018, 422,452 and 738,425 shares, respectively, were
 repurchased under the program, at an average price per share of
 $29.58 and $30.34, respectively, totaling $12.5 million and
 $22.4 million, respectively. As of March 30, 2018, the
 Company had a remaining authorization to purchase up to an
 additional $37.6 million worth of its ordinary shares under
 the share repurchase program.


## us-gaap:EarningsPerShareTextBlock

[0001193125-18-155969:notes:162]
[same as prior period, unchanged from 0001193125-18-033890:notes:164]

[0001193125-18-155969:notes:163]
[same as prior period, unchanged from 0001193125-18-033890:notes:165]

[0001193125-18-155969:notes:164]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands except per share amounts) |  | March 30, 2018 |  |  | March 31, 2017 |  |  | March 30, 2018 |  |  | March 31, 2017 |  |
| Net income attributable to shareholders |  | $ | 21,053 |  |  | $ | 21,656 |  |  | $ | 61,399 |  |  | $ | 69,714 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  | 37,275 |  |  |  | 37,116 |  |  |  | 37,400 |  |  |  | 36,792 |  |
| Incremental shares arising from the assumed exercise of share options and vesting of restricted share units (thousands of shares) |  |  | 780 |  |  |  | 756 |  |  |  | 725 |  |  |  | 958 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 38,055 |  |  |  | 37,872 |  |  |  | 38,125 |  |  |  | 37,750 |  |
| Basic earnings per ordinary share |  | $ | 0.56 |  |  | $ | 0.58 |  |  | $ | 1.64 |  |  | $ | 1.89 |  |
| Diluted earnings per ordinary share |  | $ | 0.55 |  |  | $ | 0.57 |  |  | $ | 1.61 |  |  | $ | 1.85 |  |

[0001193125-18-155969:notes:165]
As of March 30, 2018 and March 31, 2017, there were no
 anti-dilutive share options.


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001193125-18-155969:notes:166]
[same as prior period, unchanged from 0001193125-18-033890:notes:168]

[0001193125-18-155969:notes:167]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of March 30, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 15,128 |  |  | $ | — |  |  | $ | 15,128 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 124,542 |  |  |  | — |  |  |  | 124,542 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 40,629 |  |  |  | — |  |  |  | 40,629 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 4,273 |  |  |  | — |  |  |  | 4,273 |  |
| Derivative assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | — |  |  | $ | 184,572 |  |  | $ | — |  |  | $ | 184,572 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  |  | — |  |  | $ | 29 | (1) |  |  | — |  |  | $ | 29 |  |
| Total |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | 29 |  |
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 30, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 2,585 |  |  | $ | — |  |  | $ | 2,585 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 98,274 |  |  |  | — |  |  |  | 98,274 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 50,666 |  |  |  | — |  |  |  | 50,666 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 2,510 |  |  |  | — |  |  |  | 2,510 |  |
| Derivative assets |  |  | — |  |  |  | 15 | (2) |  |  | — |  |  |  | 15 |  |
| Total |  | $ | — |  |  | $ | 154,050 |  |  | $ | — |  |  | $ | 154,050 |  |

[0001193125-18-155969:notes:168]
| (1) | Foreign currency forward contracts with notional amount of $14.0 million and Canadian Dollars 0.1 million. |

[0001193125-18-155969:notes:169]
| (2) | Foreign currency forward contracts with notional amount of $1.0 million and Canadian Dollars 0.6 million. |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-18-155969:notes:170]
[same as prior period, unchanged from 0001193125-18-033890:notes:173]

[0001193125-18-155969:notes:171]
[same as prior period, unchanged from 0001193125-18-033890:notes:174]

[0001193125-18-155969:notes:172]
[same as prior period, unchanged from 0001193125-18-033890:notes:175]

[0001193125-18-155969:notes:173]
[same as prior period, unchanged from 0001193125-18-033890:notes:176]

[0001193125-18-155969:notes:174]
[same as prior period, unchanged from 0001193125-18-033890:notes:177]

[0001193125-18-155969:notes:175]
[same as prior period, unchanged from 0001193125-18-033890:notes:178]

[0001193125-18-155969:notes:176]
[same as prior period, unchanged from 0001193125-18-033890:notes:179]

[0001193125-18-155969:notes:177]
As a result of foreign currency rate fluctuations, the U.S. dollar
 equivalent values of the Company’s foreign currency
 denominated assets and liabilities change. The Company uses foreign
 currency contracts to manage the foreign exchange risk associated
 with certain foreign currency denominated assets and liabilities
 and other foreign currency transactions. The Company minimizes the
 credit risk in derivative instruments by limiting its exposure to
 any single counterparty and by entering into derivative instruments
 only with counterparties that meet the Company’s minimum
 credit quality standard. As of March 30, 2018, the Company
 recognized the fair value of foreign currency forward contracts of
 $0.03 million as derivative liabilities in the unaudited
 condensed consolidated balance sheet under other current
 liabilities. As of June 30, 2017, the Company recognized the
 fair value of foreign currency forward contracts of
 $0.02 million as derivative assets in the consolidated balance
 sheet under other current assets.

[0001193125-18-155969:notes:178]
As of March 30, 2018, the Company had 6 outstanding foreign
 currency forward contracts with an aggregate notional amount of
 $14.0 million and Canadian dollars 0.1 million, maturing
 during April to June 2018. These foreign currency forward contracts
 were not designated for hedge accounting and were used to hedge
 fluctuations in the U.S. dollar value of forecasted transactions
 denominated in Thai baht and Canadian dollar. During the nine
 months ended March 30, 2018, the Company included an
 unrealized loss of $30 thousand from changes in the fair value
 of foreign currency contracts in earnings as foreign exchange loss,
 net in the unaudited condensed consolidated statements of
 operations and comprehensive income.

[0001193125-18-155969:notes:179]
As of March 31, 2017, the Company had no foreign currency
 forward contracts designated as cash flow hedges. During the nine
 months ended March 31, 2017, the Company discontinued cash
 flow hedges and recognized a gain from unwinding foreign currency
 forward contracts of $0.3 million as foreign exchange gain,
 net in the unaudited condensed consolidated statements of
 operations and comprehensive income.

[0001193125-18-155969:notes:180]
As of March 31, 2017, the Company had one outstanding foreign
 currency forward contract with an aggregate notional amount of
 Canadian dollars 0.5 million, maturing in June 2017. This
 foreign currency forward contract was not designated for hedge
 accounting and was used to hedge fluctuations in the U.S. dollar
 value of forecasted transactions denominated in Canadian dollar.
 During the nine months ended March 31, 2017, the Company
 included unrealized loss of $8.0 thousand from changes in the
 fair value of foreign currency contracts in earnings as foreign
 exchange loss, net in the unaudited condensed consolidated
 statements of operations and comprehensive income.


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-18-155969:notes:181]
[same as prior period, unchanged from 0001193125-18-033890:notes:183]

[0001193125-18-155969:notes:182]
[same as prior period, unchanged from 0001193125-18-033890:notes:184]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-18-155969:notes:183]
[same as prior period, unchanged from 0001193125-18-033890:notes:185]

[0001193125-18-155969:notes:184]
Operating segments are defined as components of an enterprise for
 which separate financial information is available that is evaluated
 regularly by the chief operating decision maker in deciding how to
 allocate resources and in assessing performance. The
 Company’s chief operating decision maker is Fabrinet’s
 chief executive officer. As of March 30, 2018, the Company
 operated and internally managed a single operating segment.
 Accordingly, the Company does not accumulate discrete information
 with respect to separate product lines and does not have separate
 reportable segments.

[0001193125-18-155969:notes:185]
[same as prior period, unchanged from 0001193125-18-033890:notes:187]

[0001193125-18-155969:notes:186]
As of March 30, 2018 and March 31, 2017, the Company had
 approximately $33.7 million and $35.3 million of
 long-lived assets based in North America, with the substantial
 remainder of assets based in Asia-Pacific and Europe.

[0001193125-18-155969:notes:187]
[same as prior period, unchanged from 0001193125-18-033890:notes:189]

[0001193125-18-155969:notes:188]
The Company had three customers that each contributed to 10% or
 more of its total trade accounts receivable as of March 30,
 2018 and June 30, 2017.


## fn:ExpensesRelatedToReductionInWorkforceDisclosureTextBlock

[0001193125-18-155969:notes:189]
[same as prior period, unchanged from 0001193125-18-033890:notes:193]

[0001193125-18-155969:notes:190]
As part of the Company’s ongoing efforts to achieve greater
 efficiencies in all areas of its business, during the nine months
 ended March 30, 2018, the Company implemented a reduction in
 workforce and incurred expenses of approximately $1.7 million,
 which represented severance and benefits costs incurred for the
 termination of approximately 204 employees in accordance with
 contractual obligations and local regulations.
