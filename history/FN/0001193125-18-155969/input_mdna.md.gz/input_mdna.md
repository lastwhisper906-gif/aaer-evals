# FN MD&A — 0001193125-18-155969


## mdna

[0001193125-18-155969:mdna:1]
ITEM 2. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND
RESULTS OF OPERATIONS

[0001193125-18-155969:mdna:2]
[same as prior period, unchanged from 0001193125-18-033890:mdna:2]

[0001193125-18-155969:mdna:3]
[same as prior period, unchanged from 0001193125-18-033890:mdna:3]

[0001193125-18-155969:mdna:4]
|  | • |  | our expectation that the portion of our future revenues attributable to customers in regions outside of North America will increase compared with the portion of those revenues attributable to such customers for the nine months ended March 30, 2018; |

[0001193125-18-155969:mdna:5]
[same as prior period, unchanged from 0001193125-18-033890:mdna:5]

[0001193125-18-155969:mdna:6]
|  | • |  | our expectation that our fiscal year 2018 selling, general and administrative (“SG&A”) expenses will decrease compared to fiscal year 2017; |

[0001193125-18-155969:mdna:7]
[same as prior period, unchanged from 0001193125-18-033890:mdna:7]

[0001193125-18-155969:mdna:8]
[same as prior period, unchanged from 0001193125-18-033890:mdna:8]

[0001193125-18-155969:mdna:9]
[same as prior period, unchanged from 0001193125-18-033890:mdna:9]

[0001193125-18-155969:mdna:10]
[same as prior period, unchanged from 0001193125-18-033890:mdna:10]

[0001193125-18-155969:mdna:11]
[same as prior period, unchanged from 0001193125-18-033890:mdna:11]

[0001193125-18-155969:mdna:12]
[same as prior period, unchanged from 0001193125-18-033890:mdna:12]

[0001193125-18-155969:mdna:13]
[same as prior period, unchanged from 0001193125-18-033890:mdna:13]

[0001193125-18-155969:mdna:14]
[same as prior period, unchanged from 0001193125-18-033890:mdna:14]

[0001193125-18-155969:mdna:15]
[same as prior period, unchanged from 0001193125-18-033890:mdna:15]

[0001193125-18-155969:mdna:16]
[same as prior period, unchanged from 0001193125-18-033890:mdna:16]

[0001193125-18-155969:mdna:17]
[same as prior period, unchanged from 0001193125-18-033890:mdna:17]

[0001193125-18-155969:mdna:18]
[same as prior period, unchanged from 0001193125-18-033890:mdna:18]

[0001193125-18-155969:mdna:19]
[same as prior period, unchanged from 0001193125-18-033890:mdna:19]

[0001193125-18-155969:mdna:20]
We provide advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment
manufacturers (“OEMs”) of complex products such as optical communication components, modules and sub-systems, industrial lasers, medical devices and sensors. We offer a broad range of advanced
optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, complex printed circuit board assembly, advanced packaging, integration, final
assembly and test. Although we focus primarily on low-volume production of a wide variety of high complexity products, which we refer to as “low-volume, high-mix,” we also have the capability to accommodate high-volume production. Based on our experience with, and positive feedback we have received from our customers, we believe we are a global leader in
providing these services to the optical communications, industrial lasers and automotive markets.

[0001193125-18-155969:mdna:21]
[same as prior period, unchanged from 0001193125-18-033890:mdna:21]

[0001193125-18-155969:mdna:22]
[same as prior period, unchanged from 0001193125-18-033890:mdna:22]

[0001193125-18-155969:mdna:23]
[same as prior period, unchanged from 0001193125-18-033890:mdna:23]

[0001193125-18-155969:mdna:24]
[same as prior period, unchanged from 0001193125-18-033890:mdna:24]

[0001193125-18-155969:mdna:25]
[same as prior period, unchanged from 0001193125-18-033890:mdna:25]

[0001193125-18-155969:mdna:26]
[same as prior period, unchanged from 0001193125-18-033890:mdna:26]

[0001193125-18-155969:mdna:27]
The percentage of our revenues generated from a
bill-to location outside of North America decreased from 57.8% in the three months ended March 31, 2017 to 51.6% in the three months ended March 30, 2018, and decreased from 54.4% in the nine months
ended March 31, 2017 to 54.2% in the nine months ended March 30, 2018, primarily because of a decrease in sales to our customers in Asia-Pacific. We expect that the portion of our future revenues attributable to customers in regions
outside North America will increase as compared with the portion of revenues attributable to such customers during the nine months ended March 30, 2018.

[0001193125-18-155969:mdna:28]
[same as prior period, unchanged from 0001193125-18-033890:mdna:28]

[0001193125-18-155969:mdna:29]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 30,2018 |  |  | March 31,2017 |  |  | March 30,2018 |  |  | March 31,2017 |  |
| North America |  |  | 48.4 | % |  |  | 42.2 | % |  |  | 45.8 | % |  |  | 45.6 | % |
| Asia-Pacific |  |  | 36.9 |  |  |  | 40.7 |  |  |  | 38.5 |  |  |  | 38.1 |  |
| Europe |  |  | 14.7 |  |  |  | 17.1 |  |  |  | 15.7 |  |  |  | 16.3 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-18-155969:mdna:30]
[same as prior period, unchanged from 0001193125-18-033890:mdna:30]

[0001193125-18-155969:mdna:31]
[same as prior period, unchanged from 0001193125-18-033890:mdna:31]

[0001193125-18-155969:mdna:32]
[same as prior period, unchanged from 0001193125-18-033890:mdna:32]

[0001193125-18-155969:mdna:33]
[same as prior period, unchanged from 0001193125-18-033890:mdna:33]

[0001193125-18-155969:mdna:34]
[same as prior period, unchanged from 0001193125-18-033890:mdna:34]

[0001193125-18-155969:mdna:35]
[same as prior period, unchanged from 0001193125-18-033890:mdna:35]

[0001193125-18-155969:mdna:36]
[same as prior period, unchanged from 0001193125-18-033890:mdna:36]

[0001193125-18-155969:mdna:37]
[same as prior period, unchanged from 0001193125-18-033890:mdna:37]

[0001193125-18-155969:mdna:38]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative and other support
personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other general expenses not related to cost of
revenues. In fiscal year 2018, we expect our SG&A expenses will decrease compared with fiscal year 2017, primarily due to lower share-based compensation expenses granted to executives and adjustments of executive bonus.

[0001193125-18-155969:mdna:39]
The compensation committee of our board of directors approved a fiscal year 2018 executive incentive plan with quantitative objectives that
are based solely on achieving certain revenue and non-GAAP gross margin targets for our fiscal year ending June 29, 2018. Bonuses under our fiscal year 2018 executive incentive plan are payable after the end
of fiscal year 2018. In fiscal year 2017, the compensation committee approved a fiscal year 2017 executive incentive plan with quantitative objectives that were based solely on achieving certain revenue and
non-GAAP gross margin targets for our fiscal year ended June 30, 2017. In the three months ended September 29, 2017, the compensation committee awarded bonuses to our executive employees for Company
achievements of performance under our fiscal 2017 executive incentive plan. Discretionary merit-based bonus awards are also available to our non-executive employees and payable on a quarterly basis.

[0001193125-18-155969:mdna:40]
[same as prior period, unchanged from 0001193125-18-033890:mdna:40]

[0001193125-18-155969:mdna:41]
[same as prior period, unchanged from 0001193125-18-033890:mdna:41]

[0001193125-18-155969:mdna:42]
As a result of our international operations, we are exposed to foreign exchange risk arising from various currency exposures
primarily with respect to the Thai baht. Although a majority of our total revenues is denominated in U.S. dollars, a substantial portion of our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rate
between the Thai baht and the U.S. dollar has fluctuated substantially in recent years and may continue to fluctuate substantially in the future. We report our financial results in U.S. dollars and our results of operations have been and could in
the future be negatively impacted if the Thai baht appreciates against the U.S. dollar. Smaller portions of our expenses are incurred in a variety of other currencies, including RMB, GBP, Canadian dollars, Euros, and Japanese yen, the appreciation
of which may also negatively impact our financial results.

[0001193125-18-155969:mdna:43]
In order to manage the risks arising from fluctuations in foreign currency
exchange rates, we use derivative instruments. We may enter into exchange currency forward or put option contracts to manage foreign currency exposures associated with certain assets and liabilities and other forecasted foreign currency transactions
and may designate these instruments as hedging instruments. The forward and put option contracts generally have maturities of up to 12 months. All foreign currency exchange contracts are recognized in the unaudited condensed consolidated balance
sheet at fair value. Gain or loss on our forward and put option contracts generally offset the assets, liabilities, and transactions economically hedged.

[0001193125-18-155969:mdna:44]
We had foreign currency denominated assets and liabilities in Thai baht, RMB and GBP as follows:

[0001193125-18-155969:mdna:45]
|  |  | As of March 30, 2018 |  |  | As of June 30, 2017 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 541,505 |  |  | $ | 17,339 |  |  |  | 60.5 |  |  |  | 395,123 |  |  | $ | 11,628 |  |  |  | 47.3 |  |
| RMB |  |  | 12,383 |  |  |  | 1,969 |  |  |  | 6.9 |  |  |  | 26,965 |  |  |  | 3,980 |  |  |  | 16.2 |  |
| GBP |  |  | 6,621 |  |  |  | 9,353 |  |  |  | 32.6 |  |  |  | 6,896 |  |  |  | 8,982 |  |  |  | 36.5 |  |
| Total |  |  |  |  |  | $ | 28,661 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 24,590 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,077,348 |  |  | $ | 34,497 |  |  |  | 72.4 |  |  |  | 1,875,338 |  |  | $ | 55,189 |  |  |  | 82.7 |  |
| RMB |  |  | 28,259 |  |  |  | 4,494 |  |  |  | 9.4 |  |  |  | 28,451 |  |  |  | 4,200 |  |  |  | 6.3 |  |
| GBP |  |  | 6,136 |  |  |  | 8,668 |  |  |  | 18.2 |  |  |  | 5,625 |  |  |  | 7,326 |  |  |  | 11.0 |  |
| Total |  |  |  |  |  | $ | 47,659 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 66,715 |  |  |  | 100.0 |  |

[0001193125-18-155969:mdna:46]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other
current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and
offsetting assets and liabilities denominated in the same currency in accordance with our risk management policy. As of March 30, 2018 and June 30, 2017, there were $14.0 million and $1.0 million in forward contracts,
respectively, outstanding against forecasted Thai baht payables.

[0001193125-18-155969:mdna:47]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current
assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of March 30, 2018 and June 30, 2017, we did not have any derivative contracts denominated in RMB.

[0001193125-18-155969:mdna:48]
The GBP assets represent cash, trade accounts receivable and other current assets. The GBP liabilities represent trade accounts payable and
other payables. As of March 30, 2018 and June 30, 2017, we did not have any derivative contracts denominated in GBP.

[0001193125-18-155969:mdna:49]
For the
nine months ended March 30, 2018 and March 31, 2017, we recorded loss of $0.8 million and $8.0 thousand, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated
statements of operations and comprehensive income.

[0001193125-18-155969:mdna:50]
[same as prior period, unchanged from 0001193125-18-033890:mdna:50]

[0001193125-18-155969:mdna:51]
[same as prior period, unchanged from 0001193125-18-033890:mdna:51]

[0001193125-18-155969:mdna:52]
[same as prior period, unchanged from 0001193125-18-033890:mdna:52]

[0001193125-18-155969:mdna:53]
[same as prior period, unchanged from 0001193125-18-033890:mdna:53]

[0001193125-18-155969:mdna:54]
[same as prior period, unchanged from 0001193125-18-033890:mdna:54]

[0001193125-18-155969:mdna:55]
[same as prior period, unchanged from 0001193125-18-033890:mdna:55]

[0001193125-18-155969:mdna:56]
[same as prior period, unchanged from 0001193125-18-033890:mdna:56]

[0001193125-18-155969:mdna:57]
[same as prior period, unchanged from 0001193125-18-033890:mdna:57]

[0001193125-18-155969:mdna:58]
[same as prior period, unchanged from 0001193125-18-033890:mdna:58]

[0001193125-18-155969:mdna:59]
[same as prior period, unchanged from 0001193125-18-033890:mdna:59]

[0001193125-18-155969:mdna:60]
Furthermore, our transfer of funds to our subsidiaries in Thailand and the PRC are each subject to approval by governmental authorities in
case of an increase in registered capital, or subject to registration with governmental authorities in case of a shareholder loan. These limitations on the flow of funds between our subsidiaries and us could restrict our ability to act in response
to changing market conditions.

[0001193125-18-155969:mdna:61]
[same as prior period, unchanged from 0001193125-18-033890:mdna:61]

[0001193125-18-155969:mdna:62]
Our effective tax rate is a function of the mix of tax rates in the various jurisdictions in which we do business. We are domiciled in the
Cayman Islands. Under the current laws of the Cayman Islands, we are not subject to tax in the Cayman Islands on income or capital gains. We have received this undertaking for a 20-year period ending
August 24, 2019. As that date approaches, we intend to request a renewal with the office of the Clerk of the Cabinet for another 20 years.

[0001193125-18-155969:mdna:63]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of
Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption is currently available to us through June 2020 and June 2026 on income generated from projects to manufacture certain products at our Pinehurst
campus and Chonburi campus, respectively. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our
current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted. In March 2016, the Thailand Revenue Department announced a permanent decrease of corporate income tax rates to 20% for tax periods
beginning on or after January 1, 2016. As a result, corporate income tax rates for our Thai subsidiary remain at 20% from fiscal year 2017 onward.

[0001193125-18-155969:mdna:64]
On December 22, 2017, the Tax Cuts and Jobs Act (the “TCJ Act”) was enacted into law. The TCJ Act provides for significant
changes to the U.S. Internal Revenue Code of 1986, as amended (the “Code”), that impact corporate taxation requirements, such as the reduction of the federal tax rate for corporations from 35% to 21% and changes or limitations to certain
tax deductions. While we are able to make reasonable estimates of the impact of the reduction in corporate rate, the final impact of the TCJ Act may differ from these estimates, due to, among other things, changes in our interpretations and
assumptions, additional guidance that may be issued by the I.R.S., and actions we may take.

[0001193125-18-155969:mdna:65]
[same as prior period, unchanged from 0001193125-18-033890:mdna:65]

[0001193125-18-155969:mdna:66]
[same as prior period, unchanged from 0001193125-18-033890:mdna:66]

[0001193125-18-155969:mdna:67]
[same as prior period, unchanged from 0001193125-18-033890:mdna:67]

[0001193125-18-155969:mdna:68]
[same as prior period, unchanged from 0001193125-18-033890:mdna:68]

[0001193125-18-155969:mdna:69]
The following table sets forth a summary of our unaudited condensed consolidated statements of operations and comprehensive income. Note that period-to-period comparisons of operating results should not be relied upon as indicative of future performance. The three months ended March 30, 2018 and March 31,
2017 each consisted of 13 weeks. The nine months ended March 30, 2018 and March 31, 2017 consisted of 39 weeks and 40 weeks, respectively.

[0001193125-18-155969:mdna:70]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 30,2018 |  |  | March 31,2017 |  |  | March 30,2018 |  |  | March 31,2017 |  |
| Revenues |  | $ | 332,213 |  |  | $ | 366,837 |  |  | $ | 1,026,598 |  |  | $ | 1,050,036 |  |
| Cost of revenues |  |  | (295,280 | ) |  |  | (322,791 | ) |  |  | (912,167 | ) |  |  | (923,336 | ) |
| Gross profit |  |  | 36,933 |  |  |  | 44,046 |  |  |  | 114,431 |  |  |  | 126,700 |  |
| Selling, general and administrative expenses |  |  | (12,418 | ) |  |  | (17,086 | ) |  |  | (41,253 | ) |  |  | (50,569 | ) |
| Expenses related to reduction in workforce |  |  | — |  |  |  | — |  |  |  | (1,776 | ) |  |  | — |  |
| Operating income |  |  | 24,515 |  |  |  | 26,960 |  |  |  | 71,402 |  |  |  | 76,131 |  |
| Interest income |  |  | 1,149 |  |  |  | 713 |  |  |  | 2,554 |  |  |  | 1,470 |  |
| Interest expense |  |  | (820 | ) |  |  | (641 | ) |  |  | (2,499 | ) |  |  | (2,517 | ) |
| Foreign exchange loss, net |  |  | (2,428 | ) |  |  | (3,702 | ) |  |  | (5,710 | ) |  |  | (100 | ) |
| Other income |  |  | 91 |  |  |  | 108 |  |  |  | 438 |  |  |  | 397 |  |
| Income before income taxes |  |  | 22,507 |  |  |  | 23,438 |  |  |  | 66,185 |  |  |  | 75,381 |  |
| Income tax expense |  |  | (1,454 | ) |  |  | (1,782 | ) |  |  | (4,786 | ) |  |  | (5,667 | ) |
| Net income |  |  | 21,053 |  |  |  | 21,656 |  |  |  | 61,399 |  |  |  | 69,714 |  |
| Other comprehensive income (loss), net of tax |  |  | 173 |  |  |  | 276 |  |  |  | 309 |  |  |  | (1,584 | ) |
| Net comprehensive income |  | $ | 21,226 |  |  | $ | 21,932 |  |  | $ | 61,708 |  |  | $ | 68,130 |  |

[0001193125-18-155969:mdna:71]
[same as prior period, unchanged from 0001193125-18-033890:mdna:71]

[0001193125-18-155969:mdna:72]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 30,2018 |  |  | March 31,2017 |  |  | March 30,2018 |  |  | March 31,2017 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (88.9 | ) |  |  | (88.0 | ) |  |  | (88.9 | ) |  |  | (87.9 | ) |
| Gross profit |  |  | 11.1 |  |  |  | 12.0 |  |  |  | 11.1 |  |  |  | 12.1 |  |
| Selling, general and administrative expenses |  |  | (3.7 | ) |  |  | (4.6 | ) |  |  | (4.0 | ) |  |  | (4.8 | ) |
| Expenses related to reduction in workforce |  |  | — |  |  |  | — |  |  |  | (0.2 | ) |  |  | — |  |
| Operating income |  |  | 7.4 |  |  |  | 7.4 |  |  |  | 6.9 |  |  |  | 7.3 |  |
| Interest income |  |  | 0.3 |  |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.1 |  |
| Interest expense |  |  | (0.2 | ) |  |  | (0.2 | ) |  |  | (0.2 | ) |  |  | (0.2 | ) |
| Foreign exchange loss, net |  |  | (0.7 | ) |  |  | (1.0 | ) |  |  | (0.6 | ) |  |  | 0.0 |  |
| Other income |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.1 |  |
| Income before income taxes |  |  | 6.8 |  |  |  | 6.4 |  |  |  | 6.3 |  |  |  | 7.3 |  |
| Income tax expense |  |  | (0.4 | ) |  |  | (0.5 | ) |  |  | (0.5 | ) |  |  | (0.6 | ) |
| Net income |  |  | 6.4 |  |  |  | 5.9 |  |  |  | 5.8 |  |  |  | 6.6 |  |
| Other comprehensive income (loss), net of tax |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.0 |  |  |  | (0.1 | ) |
| Net comprehensive income |  |  | 6.5 | % |  |  | 6.0 | % |  |  | 5.8 | % |  |  | 6.5 | % |

[0001193125-18-155969:mdna:73]
34

[0001193125-18-155969:mdna:74]
[same as prior period, unchanged from 0001193125-18-033890:mdna:73]

[0001193125-18-155969:mdna:75]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 30, 2018 |  |  | March 31, 2017 |  |  | March 30, 2018 |  |  | March 31, 2017 |  |
| Optical communications |  | $ | 240,798 |  |  | $ | 286,870 |  |  | $ | 758,299 |  |  | $ | 817,922 |  |
| Lasers, sensors and other |  |  | 91,415 |  |  |  | 79,967 |  |  |  | 268,299 |  |  |  | 232,114 |  |
| Total |  | $ | 332,213 |  |  | $ | 366,837 |  |  | $ | 1,026,598 |  |  | $ | 1,050,036 |  |

[0001193125-18-155969:mdna:76]
[same as prior period, unchanged from 0001193125-18-033890:mdna:75]

[0001193125-18-155969:mdna:77]
Comparison of Three and Nine Months Ended March 30, 2018 with Three and Nine Months
Ended March 31, 2017

[0001193125-18-155969:mdna:78]
[same as prior period, unchanged from 0001193125-18-033890:mdna:78]

[0001193125-18-155969:mdna:79]
Our total revenues decreased by $34.6 million, or 9.4%, to $332.2 million for the three months ended March 30, 2018, compared
with $366.8 million for the three months ended March 31, 2017. This decrease was primarily due to a decrease in our customers’ demand for optical communications manufacturing services partially offset by an increase in our
customers’ demand for non-optical communications manufacturing services. Revenues from optical communications manufacturing services represented 72.5% of our total revenues for the three months ended
March 30, 2018, compared to 78.2% for the three months ended March 31, 2017.

[0001193125-18-155969:mdna:80]
Our total revenues decreased by
$23.4 million, or 2.2%, to $1,026.6 million for the nine months ended March 30, 2018, compared with $1,050.0 million for the nine months ended March 31, 2017. This decrease was primarily due to a decrease in our
customers’ demand for optical communications manufacturing services partially offset by an increase in our customers’ demand for non-optical communications manufacturing services. In addition, the
nine months ended March 30, 2018 was one week shorter than the nine months ended March 31, 2017. Revenues from optical communications manufacturing services represented 73.9% of our total revenues for the nine months ended March 30,
2018, compared to 77.9% for the nine months ended March 31, 2017.

[0001193125-18-155969:mdna:81]
[same as prior period, unchanged from 0001193125-18-033890:mdna:81]

[0001193125-18-155969:mdna:82]
Our cost of revenues decreased by $27.5 million, or 8.5%, to $295.3 million, or 88.9% of total revenues, for the three months ended
March 30, 2018, compared with $322.8 million, or 88.0% of total revenues, for the three months ended March 31, 2017. The decrease in cost of revenues on an absolute dollar basis was primarily due to a decrease in sales volume. Cost of
revenues also included share-based compensation expenses of $1.6 million for the three months ended March 30, 2018, compared with $1.7 million for the three months ended March 31, 2017.

[0001193125-18-155969:mdna:83]
Our cost of revenues decreased by $11.2 million, or 1.2%, to $912.2 million, or 88.9% of total revenues, for the nine months ended
March 30, 2018, compared with $923.3 million, or 87.9% of total revenues, for the nine months ended March 31, 2017. The decrease in cost of revenues was primarily due to a decrease in sales volume. Cost of revenues also included
share-based compensation expenses of $5.3 million for the nine months ended March 30, 2018, compared with $4.2 million for the nine months ended March 31, 2017.

[0001193125-18-155969:mdna:84]
[same as prior period, unchanged from 0001193125-18-033890:mdna:84]

[0001193125-18-155969:mdna:85]
Our gross
profit decreased by $7.1 million, or 16.1%, to $36.9 million, or 11.1% of total revenues, for the three months ended March 30, 2018, compared with $44.0 million, or 12.0% of total revenues, for the three months ended
March 31, 2017.

[0001193125-18-155969:mdna:86]
Our gross profit decreased by $12.3 million, or 9.7%, to $114.4 million, or 11.1% of total revenues, for
the nine months ended March 30, 2018, compared with $126.7 million, or 12.1% of total revenues, for the nine months ended March 31, 2017.

[0001193125-18-155969:mdna:87]
[same as prior period, unchanged from 0001193125-18-033890:mdna:87]

[0001193125-18-155969:mdna:88]
Our SG&A expenses decreased by $4.7 million, or 27.3%, to $12.4 million, or 3.7% of total revenues, for the three months ended
March 30, 2018, compared with $17.1 million, or 4.6% of total revenues, for the three months ended March 31, 2017. Our SG&A expenses decreased primarily due to lower incentive-based compensation.

[0001193125-18-155969:mdna:89]
Our SG&A expenses decreased by $9.3 million, or 18.4%, to $41.2 million, or 4.0% of total revenues, for the nine months ended
March 30, 2018, compared with $50.6 million, or 4.8% of total revenues, for the nine months ended March 31, 2017. Our SG&A expenses decreased primarily due to lower expenses relating to merger and acquisition activities of
$1.6 million, and lower incentive-based compensation.

[0001193125-18-155969:mdna:90]
[same as prior period, unchanged from 0001193125-18-033890:mdna:90]

[0001193125-18-155969:mdna:91]
Our operating income decreased by $2.4 million to $24.5 million, or 7.4% of total revenues, for the three months ended March 30,
2018, compared with $27.0 million, or 7.4% of total revenues, for the three months ended March 31, 2017. The decrease was primarily due to lower gross profit of $7.1 million, offset by a decrease in SG&A expenses of
$4.7 million.

[0001193125-18-155969:mdna:92]
Our operating income decreased by $4.7 million to $71.4 million, or 6.9% of total revenues, for the nine
months ended March 30, 2018, compared with $76.1 million, or 7.3% of total revenues, for the nine months ended March 31, 2017. The decrease was primarily due to lower gross profit of $12.3 million, offset by a decrease in
SG&A expenses of $9.3 million.

[0001193125-18-155969:mdna:93]
[same as prior period, unchanged from 0001193125-18-033890:mdna:93]

[0001193125-18-155969:mdna:94]
Our interest income increased by $0.4 million to $1.1 million, or 0.3% of total revenues, for the three months ended March 30,
2018, compared with $0.7 million, or 0.2% of total revenues, for the three months ended March 31, 2017. Our interest income increased by $1.1 million to $2.6 million, or 0.2% of total revenues, for the nine months ended
March 30, 2018, compared with $1.5 million, or 0.1% of total revenues, for the nine months ended March 31, 2017. The increase was primarily due to a higher weighted average interest rate and an increase in the average balance of our
outstanding cash during the three months ended March 30, 2018.

[0001193125-18-155969:mdna:95]
[same as prior period, unchanged from 0001193125-18-033890:mdna:95]

[0001193125-18-155969:mdna:96]
Our interest expense increased by $0.2 million to $0.8 million for the three months ended March 30, 2018, compared with
$0.6 million for the three months ended March 31, 2017. The increase was primarily due to a higher weighted average interest rate during the three months ended March 30, 2018.

[0001193125-18-155969:mdna:97]
Our interest expense remained flat at $2.5 million for the nine months ended March 30, 2018 and March 31, 2017.

[0001193125-18-155969:mdna:98]
Foreign exchange loss, net.

[0001193125-18-155969:mdna:99]
Our foreign exchange loss, net, decreased by $1.3 million to foreign exchange loss, net, of $2.4 million, or 0.7% of total revenues,
for the three months ended March 30, 2018, compared with foreign exchange loss, net, of $3.7 million, or 1.0% of total revenues, for the three months ended March 31, 2017. The decrease was primarily due to the decrease of liabilities
in foreign currencies as of March 31, 2018.

[0001193125-18-155969:mdna:100]
Our foreign exchange loss, net, increased by $5.6 million to foreign exchange loss,
net, of $5.7 million, or 0.6% of total revenues, for the nine months ended March 30, 2018, compared with foreign exchange loss, net, of $0.1 million, or 0.0% of total revenues, for the nine months ended March 31, 2017. The
increase was primarily due to the fluctuation of foreign currencies, particularly the depreciation of U.S. dollars against Thai baht.

[0001193125-18-155969:mdna:101]
[same as prior period, unchanged from 0001193125-18-033890:mdna:100]

[0001193125-18-155969:mdna:102]
We recorded income before income taxes of $22.5 million and $66.2 million for the three and nine months ended March 30, 2018,
respectively, compared with $23.4 million and $75.4 million for the three and nine months ended March 31, 2017, respectively.

[0001193125-18-155969:mdna:103]
[same as prior period, unchanged from 0001193125-18-033890:mdna:102]

[0001193125-18-155969:mdna:104]
Our
provision for income tax reflects an effective tax rate of 6.2% for the three months ended March 30, 2018, compared with an effective tax rate of 6.5% for the three months ended March 31, 2017. The decrease was primarily due to the fact
that we had higher income not subject to tax during the three months ended March 30, 2018 as compared to the same period in fiscal year 2017.

[0001193125-18-155969:mdna:105]
Our provision for income tax reflects an effective tax rate of 6.3% for the nine months ended
March 30, 2018, compared with an effective tax rate of 6.7% for the nine months ended March 31, 2017. The decrease was primarily due to the fact that we had higher income not subject to tax during the nine months ended March 30, 2018
as compared to the same period in fiscal year 2017.

[0001193125-18-155969:mdna:106]
[same as prior period, unchanged from 0001193125-18-033890:mdna:105]

[0001193125-18-155969:mdna:107]
We recorded net income of $21.1 million, or 6.4% of total revenues, for the three months ended March 30, 2018, compared with
$21.7 million, or 5.9% of total revenues, for the three months ended March 31, 2017. The decrease in net income of $0.6 million was primarily due to lower gross profit of $7.1 million, offset by decreases in SG&A expenses of
$4.7 million and foreign exchange loss, net, of $1.3 million.

[0001193125-18-155969:mdna:108]
We recorded net income of $61.4 million, or 5.8% of total
revenues, for the nine months ended March 30, 2018, compared with $69.7 million, or 6.6% of total revenues, for the nine months ended March 31, 2017. The decrease in net income of $8.3 million was primarily due to lower gross
profit of $12.3 million and an increase in foreign exchange loss, net, of $5.6 million. These were partially offset by a decrease in SG&A expenses of $9.3 million.

[0001193125-18-155969:mdna:109]
Other comprehensive income (loss).

[0001193125-18-155969:mdna:110]
We recorded other comprehensive income (loss) of $0.2 million, or 0.1% of total revenues, for the three months ended March 30, 2018,
compared with other comprehensive income (loss) of $0.3 million, or 0.1% of total revenues, for the three months ended March 31, 2017. The decrease was primarily due to an increase in unrealized loss from fair value adjustments of
marketable securities of $0.6 million.

[0001193125-18-155969:mdna:111]
We recorded other comprehensive income (loss) of $0.3 million, or 0.0% of total
revenues, for the nine months ended March 30, 2018, compared with other comprehensive (loss) of $(1.6) million, or 0.1% of total revenues, for the nine months ended March 31, 2017. The increase was primarily due to the foreign currency
translation adjustment from loss of $0.9 million for the nine months ended March 31, 2017 to gain of $1.4 million for the nine months ended March 30, 2018.

[0001193125-18-155969:mdna:112]
[same as prior period, unchanged from 0001193125-18-033890:mdna:111]

[0001193125-18-155969:mdna:113]
Cash Flows and
Working Capital

[0001193125-18-155969:mdna:114]
We primarily finance our operations through cash flow from operations. As of March 30, 2018 and
March 31, 2017, we had cash, cash equivalents, and marketable securities of $311.9 million and $289.2 million, respectively, and outstanding debt of $65.2 million and $74.7 million, respectively.

[0001193125-18-155969:mdna:115]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of
three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents for the three and nine months ended March 30, 2018 was 1.2% and 1.1%, respectively, and for the
three and nine months ended March 31, 2017 was 0.6% and 0.5%, respectively.

[0001193125-18-155969:mdna:116]
Our cash investments are made in accordance with an
investment policy approved by the Audit Committee of our board of directors. In general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an
effective maturity that exceeds three years. Our investments in fixed income securities are primarily classified as available-for-sale and are recorded at fair value.
The cost of securities sold is based on the specific identification method. Unrealized gains and losses on these securities are recorded as other comprehensive income (loss) and are reported as a separate component of shareholders’ equity.

[0001193125-18-155969:mdna:117]
During the nine months ended March 30, 2018, we repaid a term loan of $10.2 million under our Facility Agreement; as a result, as of
March 30, 2018, we had a long-term borrowing of $26.2 million and short-term borrowing of $39.0 million under our Facility Agreement. We anticipate that our internally generated working capital, along with our cash and cash
equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held investments in short-term marketable securities of $169.4 million as of March 30, 2018.

[0001193125-18-155969:mdna:118]
We believe that our current cash and cash equivalents, marketable securities, cash flow from operations, and funds available through our
credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II,
Item 1A of this Quarterly Report on Form 10-Q.

[0001193125-18-155969:mdna:119]
We also believe that our current manufacturing capacity is sufficient to meet our anticipated
production requirements for at least the next few quarters.

[0001193125-18-155969:mdna:120]
[same as prior period, unchanged from 0001193125-18-033890:mdna:119]

[0001193125-18-155969:mdna:121]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 30,2018 |  |  | March 31,2017 |  |
| Net cash provided by operating activities |  | $ | 89,794 |  |  | $ | 60,388 |  |
| Net cash used in investing activities |  | $ | (48,926 | ) |  | $ | (81,055 | ) |
| Net cash (used in) provided by financing activities |  | $ | (31,940 | ) |  | $ | 17,401 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | 8,928 |  |  | $ | (3,266 | ) |

[0001193125-18-155969:mdna:122]
[same as prior period, unchanged from 0001193125-18-033890:mdna:121]

[0001193125-18-155969:mdna:123]
Net cash provided by operating activities increased by $29.4 million, or 48.7%, to $89.8 million for the nine months ended
March 30, 2018, compared with net cash provided by operating activities of $60.4 million for the nine months ended March 31, 2017. This increase was primarily due to net cash inflow from trade accounts receivable of $72.3 million
and inventory of $38.8 million, partially offset by a decrease in net income of $8.3 million, net cash outflow from trade accounts payable of $55.2 million and a decrease in other current and
non-current assets of $13.8 million compared with the nine months ended March 31, 2017.

[0001193125-18-155969:mdna:124]
[same as prior period, unchanged from 0001193125-18-033890:mdna:123]

[0001193125-18-155969:mdna:125]
Net
cash used in investing activities decreased by $32.1 million, or 39.6%, to $48.9 million for the nine months ended March 30, 2018, compared with net cash used in investing activities of $81.1 million for the nine months ended
March 31, 2017. This decrease was primarily due to (1) a decrease in the purchase of marketable securities of $16.2 million, (2) a decrease in the purchase of property, plant and equipment of $29.0 million, and (3) a
decrease of $9.9 million in payments in connection with the acquisition of Fabrinet UK, offset by a decrease in proceeds from sales and maturities of marketable securities of $23.4 million, compared with the nine months ended
March 31, 2017.

[0001193125-18-155969:mdna:126]
[same as prior period, unchanged from 0001193125-18-033890:mdna:125]

[0001193125-18-155969:mdna:127]
Net cash for financing activities decreased by $49.3 million, or 283.6%, to net cash used in financing activities of $31.9 million
for the nine months ended March 30, 2018, compared with net cash provided by financing activities of $17.4 million for the nine months ended March 31, 2017. This decrease was primarily due to (1) an increase of $22.4 million
in the repurchase of ordinary shares pursuant to our share repurchase program, (2) a decrease in the proceeds from our revolving bank loan of $22.7 million, (3) a decrease in the proceeds from the issuance of ordinary shares under
employee share option plans of $4.9 million, and (4) an increase in withholding tax payment related to net share settlement of restricted share units of $2.8 million, compared with the same period last year. These were offset by a
decrease in the repayment of long-term loans from bank of $4.5 million.

[0001193125-18-155969:mdna:128]
Off-Balance Sheet Commitments and
Arrangements

[0001193125-18-155969:mdna:129]
We have not entered into any financial guarantees or other commitments to guarantee the payment obligations of any third
parties. In addition, we have not entered into any derivative contracts that are not reflected in our unaudited condensed consolidated financial statements. Furthermore, we do not have any retained or contingent interest in assets transferred to an
unconsolidated entity that serves as credit, liquidity or market risk support to such entity. We also do not have any variable interest in any unconsolidated entity that provides financing, liquidity, market risk or credit support to us or engages
in leasing, hedging or research and development services with us.

[0001193125-18-155969:mdna:130]
[same as prior period, unchanged from 0001193125-18-033890:mdna:129]

[0001193125-18-155969:mdna:131]
[same as prior period, unchanged from 0001193125-18-033890:mdna:130]
