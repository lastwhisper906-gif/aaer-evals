# FN note change history — 0001193125-18-033890 → 0001193125-18-155969


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0001193125-18-155969:note_history:1]
As of March 30, 2018 and June 30, 2017, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to Thai baht 50.1 million as of both dates ($1.6 million
 and $1.5 million, respectively).
  (was, 2018-02-07, similarity 0.8):
[0001193125-18-033890:note_history:1]
As of December 29, 2017 and June 30, 2017, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $1.5 million as of both dates.

- changed (2018-05-08):
[0001193125-18-155969:note_history:2]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, New Jersey and the United Kingdom under operating
 lease arrangements that expire in various calendar years through
 2023. Rental expense under these operating leases amounted to
 $1.3 million and $1.2 million for the nine months ended
 March 30, 2018 and March 31, 2017, respectively.
  (was, 2018-02-07, similarity 0.9031):
[0001193125-18-033890:note_history:2]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, New Jersey and the United Kingdom under operating
 lease arrangements that expire in various calendar years through
 2023. Rental expense under these operating leases amounted to
 $0.9 million and $0.8 million for the six months ended
 December 29, 2017 and December 30, 2016,
 respectively.

- changed (2018-05-08):
[0001193125-18-155969:note_history:3]
As of March 30, 2018, the future minimum lease payments due
 under non-cancelable
 operating leases during each fiscal year were as follows:
  (was, 2018-02-07, similarity 0.9663):
[0001193125-18-033890:note_history:3]
As of December 29, 2017, the future minimum lease payments due
 under non-cancelable
 operating leases during each fiscal year were as follows:

- changed (2018-05-08):
[0001193125-18-155969:note_history:4]
| (amount in thousands) |  |  |  |
| 2018 (remaining three months) |  | $ | 468 |  |
| 2019 |  |  | 1,319 |  |
| 2020 |  |  | 965 |  |
| 2021 |  |  | 562 |  |
| 2022 |  |  | 448 |  |
| Thereafter |  |  | 486 |  |
| Total minimum operating lease payments |  | $ | 4,248 |  |
  (was, 2018-02-07, similarity 0.844):
[0001193125-18-033890:note_history:4]
| (amount in thousands) |  |  |  |
| 2018 (remaining six months) |  | $ | 239 |  |
| 2019 |  |  | 464 |  |
| 2020 |  |  | 422 |  |
| 2021 |  |  | 108 |  |
| Total minimum capital lease payments |  | $ | 1,233 |  |

- changed (2018-05-08):
[0001193125-18-155969:note_history:5]
As of March 30, 2018, the future minimum lease payments due
 under non-cancelable
 capital leases during each fiscal year were as follows:
  (was, 2018-02-07, similarity 0.9658):
[0001193125-18-033890:note_history:5]
As of December 29, 2017, the future minimum lease payments due
 under non-cancelable
 capital leases during each fiscal year were as follows:

- added (2018-05-08):
[0001193125-18-155969:note_history:6]
| (amount in thousands) |  |  |  |
| 2018 (remaining three months) |  | $ | 125 |  |
| 2019 |  |  | 484 |  |
| 2020 |  |  | 440 |  |
| 2021 |  |  | 113 |  |
| Total minimum capital lease payments |  | $ | 1,162 |  |

- changed (2018-05-08):
[0001193125-18-155969:note_history:7]
As of March 30, 2018, the Company had an outstanding
 commitment to third parties of approximately $3.5 million.
  (was, 2018-02-07, similarity 0.9569):
[0001193125-18-033890:note_history:7]
As of December 29, 2017, the Company had an outstanding
 commitment to third parties of approximately $7.1 million.

- removed (2018-05-08):
[0001193125-18-033890:note_history:8]
| (amount in thousands) |  |  |  |
| 2018 (remaining six months) |  | $ | 815 |  |
| 2019 |  |  | 1,164 |  |
| 2020 |  |  | 945 |  |
| 2021 |  |  | 543 |  |
| 2022 |  |  | 430 |  |
| Thereafter |  |  | 466 |  |
| Total minimum operating lease payments |  | $ | 4,363 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0001193125-18-155969:note_history:9]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of March 30, 2018 and for the three
 and nine months ended March 30, 2018 and March 31, 2017
 include normal recurring adjustments, necessary for a fair
 statement of the financial statements set forth herein, in
 accordance with accounting principles generally accepted in the
 United States of America (“U.S. GAAP”) for interim
 financial information and the rules and regulations of the
 Securities and Exchange Commission (“SEC”).
 Accordingly, such information does not include all of the
 information and footnotes required by U.S. GAAP for annual
 financial statements. For further information, please refer to the
 consolidated financial statements and footnotes thereto included in
 Fabrinet’s Annual Report on Form 10-K for the year ended June 30,
 2017.
  (was, 2018-02-07, similarity 0.9416):
[0001193125-18-033890:note_history:9]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of December 29, 2017 and for the
 three and six months ended December 29, 2017 and
 December 30, 2016 includes normal recurring adjustments,
 necessary for a fair presentation of the financial statements set
 forth herein, in accordance with accounting principles generally
 accepted in the United States of America (“U.S. GAAP”)
 for interim financial information and the rules and regulations of
 the Securities and Exchange Commission (“SEC”).
 Accordingly, such information does not include all of the
 information and footnotes required by U.S. GAAP for annual
 financial statements. For further information, please refer to the
 consolidated financial statements and footnotes thereto included in
 Fabrinet’s Annual Report on Form 10-K for the year ended June 30,
 2017.

- changed (2018-05-08):
[0001193125-18-155969:note_history:10]
The balance sheet as of June 30, 2017 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three and nine
 months ended March 30, 2018 may not be indicative of results
 for the year ending June 29, 2018 or any future periods.
  (was, 2018-02-07, similarity 0.9331):
[0001193125-18-033890:note_history:10]
The balance sheet as of June 30, 2017 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three and six
 months ended December 29, 2017 may not be indicative of
 results for the year ending June 29, 2018 or any future
 periods.

- changed (2018-05-08):
[0001193125-18-155969:note_history:11]
The Company utilizes a 52-53 week fiscal year ending on the
 Friday in June closest to June 30. The three months ended
 March 30, 2018 and March 31, 2017 each consisted of 13
 weeks. The nine months ended March 30, 2018 and March 31,
 2017 consisted of 39 weeks and 40 weeks, respectively. Fiscal year
 2018 will be comprised of 52 weeks and will end on June 29,
 2018.
  (was, 2018-02-07, similarity 0.8145):
[0001193125-18-033890:note_history:11]
The Company utilizes a 52-53 week fiscal year ending on the
 Friday in June closest to June 30. The three months ended
 December 29, 2017 and December 30, 2016 each consisted of
 13 weeks. The six months ended December 29, 2017 and
 December 30, 2016 consisted of 26 weeks and 27 weeks,
 respectively. Fiscal year 2018 will be comprised of 52 weeks and
 will end on June 29, 2018.

- added (2018-05-08):
[0001193125-18-155969:note_history:12]
In January 2016, the FASB issued ASU 2016-01, “Financial Instruments
 – Overall (Subtopic 825-10): Recognition and Measurement
 of Financial Assets and Financial Liabilities.” This new
 guidance requires certain equity investments to be measured at fair
 value, use of the exit price notion and separate presentation of
 financial assets and financial liabilities by measurement category
 and form of financial asset on the balance sheet or the
 accompanying notes to the financial statements. The ASU on
 recognition and measurement will take effect for public companies
 for fiscal years beginning after December 15, 2017, including
 interim periods within those fiscal years. In addition, in
 February 2018, the FASB issued ASU 2018-03, “Technical Corrections
 and Improvements to Financial Instruments – Overall (Subtopic
 825-10), Recognition and
 Measurement of Financial Assets and Financial Liabilities. This
 guidance clarifies certain aspects of the guidance issued in ASU
 2016-01 on (1) equity
 securities without a readily determinable fair value –
 discontinuation, (2) equity securities without a readily
 determinable fair value – adjustments, (3) forward
 contracts and purchased options, (4) presentation requirements
 for certain fair value option liabilities, and (5) fair value
 option liabilities denominated in a foreign currency. The Company
 is currently evaluating the impact of the adoption of this update
 on its consolidated financial statements.

- changed (2018-05-08):
[0001193125-18-155969:note_history:13]
In May 2014, the FASB issued ASU 2014-09, “Revenue from Contracts
 with Customers (Topic 606), issued as a new Topic, Accounting
 Standards Codification.” The core principle of this amendment
 is that an entity should recognize revenue to depict the transfer
 of promised goods or services to customers in an amount that
 reflects the consideration to which the entity expects to be
 entitled in exchange for those goods or services. This update is
 effective for public companies, as amended by ASU 2015-14, for annual reporting periods
 beginning after December 15, 2017, including interim periods
 within that reporting period. Earlier application of this guidance
 is permitted, but not before the original date of December 15,
 2016, which can be adopted either retrospectively to each prior
 reporting period presented or as a cumulative-effect adjustment as
 of the date of adoption. Subsequently, in March 2016 and April
 2016, the FASB issued ASU 2016-08 and ASU 2016-10, respectively, to clarify the
 implementation guidance on principle versus agent considerations
 and address the potential diversity in practice at initial
 application and cost; and the complexity of applying Topic 606,
 both at transition and on an ongoing basis related to
 identification of performance obligations and licensing
 arrangements; and ASU 2016-12 and ASU 2016-20 in May 2016 and December 2016,
 respectively, to improve certain aspects of Topic 606, with the
 same effective date as ASU 2015-14. The Company will adopt this
 standard during its fiscal year ending June 28, 2019. In the
 current period, the Company is assessing the contracts with its
 customers to identify the impact to its consolidated financial
 statements. The Company expects to conclude the impact to its
 consolidated financial statements in the coming quarter.
  (was, 2018-02-07, similarity 0.9662):
[0001193125-18-033890:note_history:13]
In May 2014, the FASB issued ASU 2014-09, “Revenue from Contracts
 with Customers (Topic 606), issued as a new Topic, Accounting
 Standards Codification.” The core principle of this amendment
 is that an entity should recognize revenue to depict the transfer
 of promised goods or services to customers in an amount that
 reflects the consideration to which the entity expects to be
 entitled in exchange for those goods or services. This update is
 effective for public companies, as amended by ASU 2015-14, for annual reporting periods
 beginning after December 15, 2017, including interim periods
 within that reporting period. Earlier application of this guidance
 is permitted, but not before the original date of December 15,
 2016, which can be adopted either retrospectively to each prior
 reporting period presented or as a cumulative-effect adjustment as
 of the date of adoption. Subsequently, in March 2016 and April
 2016, the FASB issued ASU 2016-08 and ASU 2016-10, respectively, to clarify the
 implementation guidance on principle versus agent considerations
 and address the potential diversity in practice at initial
 application and cost; and the complexity of applying Topic 606,
 both at transition and on an ongoing basis related to
 identification of performance obligations and licensing
 arrangements; and ASU 2016-12 and ASU 2016-20 in May 2016 and December 2016,
 respectively, to improve certain aspects of Topic 606, with the
 same effective date as ASU 2015-14. The Company will adopt this
 standard during its fiscal year ending June 28, 2019. In the
 current period, the Company is assessing the contracts with its
 customers to identify the impact to its consolidated financial
 statements. The process is still ongoing and the Company expects to
 make significant progress in the coming quarters.

- added (2018-05-08):
[0001193125-18-155969:note_history:14]
In February 2018, the FASB issued ASU 2018-02 “Income Statement
 – Reporting Comprehensive Income (Topic 220),
 Reclassification of Certain Tax Effects from Accumulated Other
 Comprehensive Income.” This ASU which allows companies to
 reclassify stranded tax effects in accumulated other comprehensive
 income (loss) that have been caused by the Tax Cuts and Jobs Act of
 2017 (the Act) to retained earnings for each period in which the
 effect of the change in the U.S. federal corporate income tax rate
 is recorded. The FASB has made the reclassification
 optional. In addition, in March 2018, the FASB issued ASU
 2018-05, “Income
 Taxes (Topic 740), Amendments to SEC Paragraphs Pursuant to SEC
 Staff Accounting Bulletin No. 118,” which updates the
 income tax accounting in U.S. GAAP to reflect SEC guidance released
 on December 22, 2017, when the Act was signed into law. The
 Company adopted these updates with no impact to the unaudited
 condensed consolidated financial statements.

- changed (2018-05-08):
[0001193125-18-155969:note_history:15]
In August 2017, the FASB issued ASU 2017-12, “Derivatives and
 Hedging (Topic 815): Targeted Improvements to Accounting for
 Hedging Activities.” The amendments better align an
 entity’s risk management activities and financial reporting
 for hedging relationships through changes to both the designation
 and measurement guidance for qualifying hedging relationships and
 the presentation of hedge results. To meet that objective, the
 amendments expand and refine hedge accounting for both nonfinancial
 and financial risk components and align the recognition and
 presentation of the effects of the hedging instrument and the
 hedged item in the financial statements. The amendments also make
 certain targeted improvements to simplify the application of hedge
 accounting guidance and ease the administrative burden of hedge
 documentation requirements and assessing hedge effectiveness. This
 ASU is the final version of Proposed Accounting Standards Update
 2016-310—Derivatives
 and Hedging (Topic 815): Targeted Improvements to Accounting for
 Hedging Activities, which has been deleted. During the first nine
 months of fiscal year 2018, the Company adopted this update with no
 impact to the unaudited condensed consolidated financial
 statements.
  (was, 2018-02-07, similarity 0.9971):
[0001193125-18-033890:note_history:15]
In August 2017, the FASB issued ASU 2017-12, “Derivatives and
 Hedging (Topic 815): Targeted Improvements to Accounting for
 Hedging Activities.” The amendments better align an
 entity’s risk management activities and financial reporting
 for hedging relationships through changes to both the designation
 and measurement guidance for qualifying hedging relationships and
 the presentation of hedge results. To meet that objective, the
 amendments expand and refine hedge accounting for both nonfinancial
 and financial risk components and align the recognition and
 presentation of the effects of the hedging instrument and the
 hedged item in the financial statements. The amendments also make
 certain targeted improvements to simplify the application of hedge
 accounting guidance and ease the administrative burden of hedge
 documentation requirements and assessing hedge effectiveness. This
 ASU is the final version of Proposed Accounting Standards Update
 2016-310—Derivatives
 and Hedging (Topic 815): Targeted Improvements to Accounting for
 Hedging Activities, which has been deleted. During the first six
 months of fiscal year 2017, the Company adopted this update with no
 impact to the unaudited condensed consolidated financial
 statements.

- changed (2018-05-08):
[0001193125-18-155969:note_history:16]
In November 2016, the FASB issued ASU 2016-18, “Statement of Cash
 Flows (Topic 230): Restricted Cash,” which requires the
 statement of cash flows to explain the change during the period in
 the total of cash, cash equivalents and restricted cash or
 restricted cash equivalents. The Company has early adopted this
 update in the second quarter of fiscal year 2017 on a retrospective
 basis. As of March 30, 2018, restricted cash in connection
 with business acquisition of $3.6 million was presented in the
 statement of cash flows as cash, cash equivalents and restricted
 cash.
  (was, 2018-02-07, similarity 0.9882):
[0001193125-18-033890:note_history:16]
In November 2016, the FASB issued ASU 2016-18, “Statement of Cash
 Flows (Topic 230): Restricted Cash,” which requires the
 statement of cash flows to explain the change during the period in
 the total of cash, cash equivalents and restricted cash or
 restricted cash equivalents. The Company has early adopted this
 update in the second quarter of fiscal year 2017 on a retrospective
 basis. As of December 30, 2016, restricted cash in connection
 with business acquisition of $3.1 million was presented in the
 statement of cash flows as cash, cash equivalents and restricted
 cash.

- changed (2018-05-08):
[0001193125-18-155969:note_history:17]
In March 2016, the FASB issued ASU 2016-09, “Compensation
 – Stock Compensation (Topic 718): Improvements to Employee
 Share-Based Payment Accounting.” This ASU simplifies several
 aspects of the accounting for share-based payment award
 transactions, including, the income tax consequences,
 classification of awards as either equity or liabilities and
 classification on the statement of cash flows. The amendments in
 this update are effective for annual periods beginning after
 December 15, 2016, and interim periods within those annual
 periods, for public companies. Early adoption is permitted for any
 entity in any interim or annual period. During the first nine
 months of fiscal year 2018, the Company adopted this update with no
 impact to the unaudited condensed consolidated financial
 statements.
  (was, 2018-02-07, similarity 0.9955):
[0001193125-18-033890:note_history:17]
In March 2016, the FASB issued ASU 2016-09, “Compensation
 – Stock Compensation (Topic 718): Improvements to Employee
 Share-Based Payment Accounting.” This ASU simplifies several
 aspects of the accounting for share-based payment award
 transactions, including, the income tax consequences,
 classification of awards as either equity or liabilities and
 classification on the statement of cash flows. The amendments in
 this update are effective for annual periods beginning after
 December 15, 2016, and interim periods within those annual
 periods, for public companies. Early adoption is permitted for any
 entity in any interim or annual period. During the first six months
 of fiscal year 2018, the Company adopted this update with no impact
 to the unaudited condensed consolidated financial statements.

- changed (2018-05-08):
[0001193125-18-155969:note_history:18]
In March 2016, the FASB issued ASU 2016-05, “Derivatives and
 Hedging (Topic 815),” to clarify that a change in the
 counterparty to a derivative instrument that has been designated as
 a hedging instrument under Topic 815, does not, in and of itself,
 require designation of the hedging relationship, provided that all
 other hedge accounting criteria continue to be met. This guidance
 is effective for public entities for financial statements issued
 for fiscal years beginning after December 15, 2016 and interim
 periods within those fiscal years. During the first nine months of
 fiscal year 2018, the Company adopted this update with no impact to
 the unaudited condensed consolidated financial statements.
  (was, 2018-02-07, similarity 0.9948):
[0001193125-18-033890:note_history:18]
In March 2016, the FASB issued ASU 2016-05, “Derivatives and
 Hedging (Topic 815),” to clarify that a change in the
 counterparty to a derivative instrument that has been designated as
 a hedging instrument under Topic 815, does not, in and of itself,
 require designation of the hedging relationship, provided that all
 other hedge accounting criteria continue to be met. This guidance
 is effective for public entities for financial statements issued
 for fiscal years beginning after December 15, 2016 and interim
 periods within those fiscal years. During the first six months of
 fiscal year 2018, the Company adopted this update with no impact to
 the unaudited condensed consolidated financial statements.

- removed (2018-05-08):
[0001193125-18-033890:note_history:19]
In January 2016, the FASB issued ASU 2016-01, “Financial Instruments
 – Overall (Subtopic 825-10): Recognition and Measurement
 of Financial Assets and Financial Liabilities.” This new
 guidance requires certain equity investments to be measured at fair
 value, use of the exit price notion and separate presentation of
 financial assets and financial liabilities by measurement category
 and form of financial asset on the balance sheet or the
 accompanying notes to the financial statements. The ASU on
 recognition and measurement will take effect for public companies
 for fiscal years beginning after December 15, 2017, including
 interim periods within those fiscal years. The Company is
 currently evaluating the impact of the adoption of this update on
 its consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0001193125-18-155969:note_history:20]
| (amount in thousands) |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  | Maturity |  |  | As of March 30, 2018 |  |  | As of June 30, 2017 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR(1) + 1.75% per annum |  | Repayable in 1 to 6 months |  |  | April 2018 | (2) |  | $ | 39,000 |  |  | $ | 34,000 |  |
| Short-term loans from bank: |  |
| Bank Base rate +1.85% per annum |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  |  |  | — |  |  |  | 1,003 |  |
| Current portion of long-term borrowing |  |  |  | 13,600 |  |  |  | 13,600 |  |
|  |  |  |  | 52,600 |  |  |  | 48,603 |  |
| Less: Unamortized debt issuance costs |  |  |  | (136 | ) |  |  | (201 | ) |
|  |  |  |  |  |  |  |  | $ | 52,464 |  |  | $ | 48,402 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  | Repayable in quarterly installments |  |  | May 2019 |  |  | $ | 26,200 |  |  | $ | 36,400 |  |
| Less: Current portion |  |  |  |  |  |  |  |  | (13,600 | ) |  |  | (13,600 | ) |
| Unamortized debt issuance costs |  |  |  | (5 | ) |  |  | (99 | ) |
| Non-current portion |  |  |  |  |  |  |  | $ | 12,595 |  |  | $ | 22,701 |  |
  (was, 2018-02-07, similarity 0.9356):
[0001193125-18-033890:note_history:20]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  |  | Maturity |  |  | As of December 29, 2017 |  |  | As of June 30, 2017 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR(1) + 1.75% per annum |  |  | Repayable in 1 to 6 months |  |  |  | January 2018(2) |  |  | $ | 39,000 |  |  | $ | 34,000 |  |
| Short-term loans from bank: |  |
| Bank Base rate +1.85% per annum |  |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  |  |  |  | — |  |  |  | 1,003 |  |
| Current portion of long-term borrowing |  |  |  | 13,600 |  |  |  | 13,600 |  |
|  |  |  |  | 52,600 |  |  |  | 48,603 |  |
| Less: Unamortized debt issuance costs |  |  |  | (157 | ) |  |  | (201 | ) |
|  |  |  |  |  |  |  |  |  |  | $ | 52,443 |  |  | $ | 48,402 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  |  | Repayable in quarterly installments |  |  |  | May 2019 |  |  | $ | 29,600 |  |  | $ | 36,400 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (13,600 | ) |  |  | (13,600 | ) |
| Unamortized debt issuance costs |  |  |  | (31 | ) |  |  | (99 | ) |
| Non-current portion |  |  |  |  |  |  |  |  |  | $ | 15,969 |  |  | $ | 22,701 |  |

- changed (2018-05-08):
[0001193125-18-155969:note_history:21]
| (2) | In March 2018, the maturity date was extended to April 2018. |
  (was, 2018-02-07, similarity 0.8682):
[0001193125-18-033890:note_history:21]
| (2) | In December 2017, the maturity date was extended to January 2018. |

- changed (2018-05-08):
[0001193125-18-155969:note_history:22]
The movements of long-term loans for the nine months ended
 March 30, 2018 and March 31, 2017 were as follows:
  (was, 2018-02-07, similarity 0.8867):
[0001193125-18-033890:note_history:22]
The movements of long-term loans for the six months ended
 December 29, 2017 and December 30, 2016 were as
 follows:

- added (2018-05-08):
[0001193125-18-155969:note_history:23]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 30, 2018 |  |  | March 31, 2017 |  |
| Opening balance |  | $ | 36,400 |  |  | $ | 54,500 |  |
| Repayments during the period |  |  | (10,200 | ) |  |  | (14,700 | ) |
| Closing balance |  | $ | 26,200 |  |  | $ | 39,800 |  |

- changed (2018-05-08):
[0001193125-18-155969:note_history:24]
As of March 30, 2018, future maturities of long-term debt
 during each fiscal year were as follows:
  (was, 2018-02-07, similarity 0.9519):
[0001193125-18-033890:note_history:24]
As of December 29, 2017, future maturities of long-term debt
 during each fiscal year were as follows:

- changed (2018-05-08):
[0001193125-18-155969:note_history:25]
| (amount in thousands) |  |  |  |
| 2018 (remaining three months) |  | $ | 3,400 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 26,200 |  |
  (was, 2018-02-07, similarity 0.964):
[0001193125-18-033890:note_history:25]
| (amount in thousands) |  |  |  |
| 2018 (remaining six months) |  | $ | 6,800 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 29,600 |  |

- changed (2018-05-08):
[0001193125-18-155969:note_history:26]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. On
 July 22, 2016, the Company entered into the Fourth Amendment
 to the Facility Agreement to change the timing of filing certain
 financial information with the bank. The Company fully drew
 down the term loan facility in fiscal year 2016. As of
 March 30, 2018, $39.0 million of the revolving borrowing
 and $26.2 million of the term loan borrowing was outstanding
 under the Facility Agreement, resulting in available credit
 facilities of $111.0 million. Borrowings under the revolving
 credit facility are classified as current liabilities in the
 unaudited condensed consolidated balance sheets as the Company has
 the periodic option to renew or pay, all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. During March 2018, the Company
 sent notices to the bank to renew the maturity date of its
 revolving borrowings. The bank approved the notices and extended
 the maturity to April 2018.
  (was, 2018-02-07, similarity 0.9865):
[0001193125-18-033890:note_history:26]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. On
 July 22, 2016, the Company entered into the Fourth Amendment
 to the Facility Agreement to change the timing of filing certain
 financial information with the bank. The Company fully drew
 down the term loan facility in fiscal year 2016. As of
 December 29, 2017, $39.0 million of the revolving
 borrowing and $29.6 million of the term loan borrowing was
 outstanding under the Facility Agreement, resulting in available
 credit facilities of $111.0 million. Borrowings under the
 revolving credit facility are classified as current liabilities in
 the unaudited condensed consolidated balance sheets as the Company
 has the periodic option to renew or pay, all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. During December 2017, the
 Company sent notices to the bank to renew the maturity date of its
 revolving borrowings. The bank approved the notices and extended
 the maturity to January 2018.

- changed (2018-05-08):
[0001193125-18-155969:note_history:27]
On July 24, 2017, the Company entered into an interest rate
 swap agreement (the “Swap Agreement”), which the
 Company did not designate as hedging instruments. The Swap
 Agreement was used to mitigate interest rate risk and improve the
 interest rate profile of the Company’s debt obligations. The
 terms of the Swap Agreement effectively convert the floating
 interest rate of the term loans under the Facility Agreement to the
 fixed interest rate of 1.55% per annum through maturity of the term
 loan in May 2019. The swap transactions are due and settled
 monthly. During the nine months ended March 30, 2018, the
 Company included a net loss of $0.04 million from the
 settlement of the Swap Agreement as interest expenses in the
 unaudited condensed consolidated statements of operations and
 comprehensive income.
  (was, 2018-02-07, similarity 0.96):
[0001193125-18-033890:note_history:27]
On July 24, 2017, the Company entered into an interest rate
 swap agreement (the “Swap Agreement”), which the
 Company did not designate as hedging instruments. The Swap
 Agreement was used to mitigate interest rate risk and improve the
 interest rate profile of the Company’s debt obligations. The
 terms of the Swap Agreement effectively convert the floating
 interest rate of the term loans under the Facility Agreement to the
 fixed interest rate of 1.55% per annum through maturity of the term
 loan in May 2019. The swap transactions are due and settled
 monthly. During the six months ended December 29, 2017,
 the Company included a net loss of $23.0 thousand from the
 settlement of the Swap Agreement as interest expenses in the
 unaudited condensed consolidated statements of operations and
 comprehensive income.

- changed (2018-05-08):
[0001193125-18-155969:note_history:28]
The Facility Agreement contains customary affirmative and negative
 covenants. Negative covenants include, among other things,
 limitations on liens, indebtedness, investments, mergers, sales of
 assets, changes in the nature of the business, dividends and
 distributions, affiliate transactions and capital expenditures. The
 Facility Agreement contains financial covenants requiring Fabrinet
 to maintain: (1) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (2) a minimum debt service coverage ratio of
 not less than 1.50:1.00; (3) a maximum senior leverage ratio of not
 more than 2.50:1.00; and (4) a minimum quick ratio of not less
 than 1.10:1.00. Each of these financial covenants is calculated on
 a consolidated basis for the consecutive four fiscal quarter period
 then ended. As of March 30, 2018, the Company was in
 compliance with all covenants under the Facility Agreement.
  (was, 2018-02-07, similarity 0.993):
[0001193125-18-033890:note_history:28]
The Facility Agreement contains customary affirmative and negative
 covenants. Negative covenants include, among other things,
 limitations on liens, indebtedness, investments, mergers, sales of
 assets, changes in the nature of the business, dividends and
 distributions, affiliate transactions and capital expenditures. The
 Facility Agreement contains financial covenants requiring Fabrinet
 to maintain: (1) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (2) a minimum debt service coverage ratio of
 not less than 1.50:1.00; (3) a maximum senior leverage ratio of not
 more than 2.50:1.00; and (4) a minimum quick ratio of not less
 than 1.10:1.00. Each of these financial covenants is calculated on
 a consolidated basis for the consecutive four fiscal quarter period
 then ended. As of December 29, 2017, the Company was in
 compliance with all covenants under the Facility Agreement.

- changed (2018-05-08):
[0001193125-18-155969:note_history:29]
Undrawn available credit facilities classified by availability
 period of future borrowing as of March 30, 2018 and
 June 30, 2017 were as follows:
  (was, 2018-02-07, similarity 0.967):
[0001193125-18-033890:note_history:29]
Undrawn available credit facilities classified by availability
 period of future borrowing as of December 29, 2017 and
 June 30, 2017 were as follows:

- changed (2018-05-08):
[0001193125-18-155969:note_history:30]
| (amount in thousands) |  | March 30, 2018 |  |  | June 30, 2017 |  |
| Short-term |  | $ | — |  |  | $ | 1,965 |  |
| Long-term |  | $ | 111,000 |  |  | $ | 116,000 |  |
  (was, 2018-02-07, similarity 0.9665):
[0001193125-18-033890:note_history:30]
| (amount in thousands) |  | December 29, 2017 |  |  | June 30, 2017 |  |
| Short-term |  | $ | — |  |  | $ | 1,965 |  |
| Long-term |  | $ | 111,000 |  |  | $ | 116,000 |  |

- removed (2018-05-08):
[0001193125-18-033890:note_history:31]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 29, 2017 |  |  | December 30, 2016 |  |
| Opening balance |  | $ | 36,400 |  |  | $ | 54,500 |  |
| Repayments during the period |  |  | (6,800 | ) |  |  | (9,800 | ) |
| Closing balance |  | $ | 29,600 |  |  | $ | 44,700 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0001193125-18-155969:note_history:32]
The movements of long-term loans for the nine months ended
 March 30, 2018 and March 31, 2017 were as follows:
  (was, 2018-02-07, similarity 0.8867):
[0001193125-18-033890:note_history:32]
The movements of long-term loans for the six months ended
 December 29, 2017 and December 30, 2016 were as
 follows:

- added (2018-05-08):
[0001193125-18-155969:note_history:33]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 30, 2018 |  |  | March 31, 2017 |  |
| Opening balance |  | $ | 36,400 |  |  | $ | 54,500 |  |
| Repayments during the period |  |  | (10,200 | ) |  |  | (14,700 | ) |
| Closing balance |  | $ | 26,200 |  |  | $ | 39,800 |  |

- removed (2018-05-08):
[0001193125-18-033890:note_history:34]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 29, 2017 |  |  | December 30, 2016 |  |
| Opening balance |  | $ | 36,400 |  |  | $ | 54,500 |  |
| Repayments during the period |  |  | (6,800 | ) |  |  | (9,800 | ) |
| Closing balance |  | $ | 29,600 |  |  | $ | 44,700 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-05-08):
[0001193125-18-155969:note_history:35]
The Company’s total borrowings, including short-term and
 long-term borrowings, consisted of the following:

- changed (2018-05-08):
[0001193125-18-155969:note_history:36]
| (amount in thousands) |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  | Maturity |  |  | As of March 30, 2018 |  |  | As of June 30, 2017 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR(1) + 1.75% per annum |  | Repayable in 1 to 6 months |  |  | April 2018 | (2) |  | $ | 39,000 |  |  | $ | 34,000 |  |
| Short-term loans from bank: |  |
| Bank Base rate +1.85% per annum |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  |  |  | — |  |  |  | 1,003 |  |
| Current portion of long-term borrowing |  |  |  | 13,600 |  |  |  | 13,600 |  |
|  |  |  |  | 52,600 |  |  |  | 48,603 |  |
| Less: Unamortized debt issuance costs |  |  |  | (136 | ) |  |  | (201 | ) |
|  |  |  |  |  |  |  |  | $ | 52,464 |  |  | $ | 48,402 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  | Repayable in quarterly installments |  |  | May 2019 |  |  | $ | 26,200 |  |  | $ | 36,400 |  |
| Less: Current portion |  |  |  |  |  |  |  |  | (13,600 | ) |  |  | (13,600 | ) |
| Unamortized debt issuance costs |  |  |  | (5 | ) |  |  | (99 | ) |
| Non-current portion |  |  |  |  |  |  |  | $ | 12,595 |  |  | $ | 22,701 |  |
  (was, 2018-02-07, similarity 0.9356):
[0001193125-18-033890:note_history:36]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  |  | Maturity |  |  | As of December 29, 2017 |  |  | As of June 30, 2017 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR(1) + 1.75% per annum |  |  | Repayable in 1 to 6 months |  |  |  | January 2018(2) |  |  | $ | 39,000 |  |  | $ | 34,000 |  |
| Short-term loans from bank: |  |
| Bank Base rate +1.85% per annum |  |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  |  |  |  | — |  |  |  | 1,003 |  |
| Current portion of long-term borrowing |  |  |  | 13,600 |  |  |  | 13,600 |  |
|  |  |  |  | 52,600 |  |  |  | 48,603 |  |
| Less: Unamortized debt issuance costs |  |  |  | (157 | ) |  |  | (201 | ) |
|  |  |  |  |  |  |  |  |  |  | $ | 52,443 |  |  | $ | 48,402 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  |  | Repayable in quarterly installments |  |  |  | May 2019 |  |  | $ | 29,600 |  |  | $ | 36,400 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (13,600 | ) |  |  | (13,600 | ) |
| Unamortized debt issuance costs |  |  |  | (31 | ) |  |  | (99 | ) |
| Non-current portion |  |  |  |  |  |  |  |  |  | $ | 15,969 |  |  | $ | 22,701 |  |

- changed (2018-05-08):
[0001193125-18-155969:note_history:37]
| (2) | In March 2018, the maturity date was extended to April 2018. |
  (was, 2018-02-07, similarity 0.8682):
[0001193125-18-033890:note_history:37]
| (2) | In December 2017, the maturity date was extended to January 2018. |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0001193125-18-155969:note_history:38]
Undrawn available credit facilities classified by availability
 period of future borrowing as of March 30, 2018 and
 June 30, 2017 were as follows:
  (was, 2018-02-07, similarity 0.967):
[0001193125-18-033890:note_history:38]
Undrawn available credit facilities classified by availability
 period of future borrowing as of December 29, 2017 and
 June 30, 2017 were as follows:

- changed (2018-05-08):
[0001193125-18-155969:note_history:39]
| (amount in thousands) |  | March 30, 2018 |  |  | June 30, 2017 |  |
| Short-term |  | $ | — |  |  | $ | 1,965 |  |
| Long-term |  | $ | 111,000 |  |  | $ | 116,000 |  |
  (was, 2018-02-07, similarity 0.9665):
[0001193125-18-033890:note_history:39]
| (amount in thousands) |  | December 29, 2017 |  |  | June 30, 2017 |  |
| Short-term |  | $ | — |  |  | $ | 1,965 |  |
| Long-term |  | $ | 111,000 |  |  | $ | 116,000 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-05-08):
[0001193125-18-155969:note_history:40]
As of March 30, 2018, future maturities of long-term debt
 during each fiscal year were as follows:
  (was, 2018-02-07, similarity 0.9519):
[0001193125-18-033890:note_history:40]
As of December 29, 2017, future maturities of long-term debt
 during each fiscal year were as follows:

- changed (2018-05-08):
[0001193125-18-155969:note_history:41]
| (amount in thousands) |  |  |  |
| 2018 (remaining three months) |  | $ | 3,400 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 26,200 |  |
  (was, 2018-02-07, similarity 0.964):
[0001193125-18-033890:note_history:41]
| (amount in thousands) |  |  |  |
| 2018 (remaining six months) |  | $ | 6,800 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 29,600 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2018-05-08):
[0001193125-18-033890:note_history:42]
| 19. | Subsequent event |

- removed (2018-05-08):
[0001193125-18-033890:note_history:43]
In February 2018, Fabrinet’s board of directors approved the
 repurchase of up to an additional $30.0 million of Fabrinet’s
 outstanding ordinary shares, bringing the aggregate authorization
 under Fabrinet’s existing share repurchase program to
 $60.0 million.
