# FN notes — 0001193125-18-255054


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-18-255054:notes:1]
| 2. | Summary of significant accounting policies |

[0001193125-18-255054:notes:2]
Principles of consolidation

[0001193125-18-255054:notes:3]
The Company
 utilizes a 52-53 week fiscal
 year ending on the Friday in June closest to June 30. Fiscal
 year 2018 ended on June 29, 2018 and consisted of 52 weeks.
 Fiscal year 2017 ended on June 30, 2017 and consisted of 53
 weeks. Fiscal year 2016 ended on June 24, 2016 and consisted
 of 52 weeks.

[0001193125-18-255054:notes:4]
The
 consolidated financial statements have been prepared in accordance
 with accounting principles generally accepted in the United States
 (“U.S. GAAP”) and include Fabrinet and its
 subsidiaries. All inter-company accounts and transactions have been
 eliminated.

[0001193125-18-255054:notes:5]
On
 September 14, 2016, the Company acquired Global CEM Solutions,
 Ltd. and all of its subsidiaries (collectively, “Fabrinet
 UK”), a privately-held group located in Wiltshire,
 United Kingdom. The consolidated financial statements of the
 Company include the financial position, results of operations and
 the cash flows of Fabrinet UK commencing as of the acquisition
 date. See Note 9, Business acquisition for further details on the
 accounting for this transaction.

[0001193125-18-255054:notes:6]
Use of
 estimates

[0001193125-18-255054:notes:7]
The
 preparation of the Company’s consolidated financial
 statements in conformity with U.S. GAAP requires management to make
 estimates and assumptions that affect the reported amounts of
 assets and liabilities and disclosure of contingent liabilities at
 the date of the financial statements, and the reported amount of
 total revenues and expenses during the year. The Company bases
 estimates on historical experience and various assumptions about
 the future that are believed to be reasonable based on available
 information. The Company’s reported financial position or
 results of operations may be materially different under different
 conditions or when using different estimates and assumptions,
 particularly with respect to significant accounting policies, which
 are discussed below. Significant assumptions are used in accounting
 for share-based compensation, allowance for doubtful accounts,
 income taxes, inventory obsolescence and valuation of intangible
 assets related to business acquisition, among others. Due to the
 inherent uncertainty involved in making estimates, actual results
 reported in future periods may be different from these estimates.
 In the event that estimates or assumptions prove to differ from
 actual results, adjustments will be made in subsequent periods to
 reflect more current information.

[0001193125-18-255054:notes:8]
Foreign
 currency transactions and translation

[0001193125-18-255054:notes:9]
The
 consolidated financial statements are presented in United States
 dollars (“$” or “USD”). The functional
 currency of Fabrinet and most of its subsidiaries is the
 USD.

[0001193125-18-255054:notes:10]
With respect
 to subsidiaries that use USD as their functional currency,
 transactions denominated in a currency other than USD are
 translated into USD at the rates of exchange in effect at the date
 of the transaction. Monetary assets and liabilities denominated in
 foreign currencies are translated into the functional currency at
 the exchange rate prevailing at the consolidated balance sheet
 dates. Transaction gains and losses are included in foreign
 exchange gain (loss) in the accompanying consolidated statements of
 operations and comprehensive income.

[0001193125-18-255054:notes:11]
Fabrinet
 translates the assets and liabilities of its subsidiaries that do
 not use USD as their functional currency into USD using exchange
 rates in effect at the end of each period. Revenue and expenses for
 such subsidiaries are translated using rates that approximate those
 in effect during the period. Gains and losses from these
 translations are recognized in foreign currency translation
 adjustment included in accumulated other comprehensive income
 (loss) (“AOCI”) in the Company’s consolidated
 balance sheets.

[0001193125-18-255054:notes:12]
Cash
 and cash equivalents

[0001193125-18-255054:notes:13]
All highly
 liquid investments with original maturities of three months or less
 at the date of purchase are classified as cash equivalents. Cash
 and cash equivalents consist of cash deposited in checking
 accounts, time deposits with maturities of less than three months,
 money market accounts, and marketable securities with maturities of
 three months or less at the date of purchase.

[0001193125-18-255054:notes:14]
Marketable securities

[0001193125-18-255054:notes:15]
Management
 determines the appropriate classification of its investments at the
 time of purchase and re-evaluates the
 designations at each balance sheet date. The Company may sell
 certain of the Company’s marketable securities prior to their
 stated maturities for strategic reasons including, but not limited
 to, anticipation of credit deterioration and duration management.
 The maturities of the Company’s marketable securities
 generally range from three months to three years. The
 Company’s marketable securities consist of investment in U.S.
 Treasury and fixed income securities and have been classified and
 accounted for as available-for-sale.

[0001193125-18-255054:notes:16]
The
 Company’s investments in marketable securities are classified
 as available-for-sale securities
 and reported at fair value. Unrealized gains and losses related to
 changes in the fair value of securities are recognized in
 accumulated other comprehensive income, net of tax, in the
 Company’s consolidated balance sheets. Changes in the fair
 value of available-for-sale securities
 impact the Company’s net income only when such securities are
 sold or other-than-temporary impairment is recognized. Realized
 gains and losses on the sale of securities are determined by
 specific identification of each security’s cost
 basis.

[0001193125-18-255054:notes:17]
The Company
 reviews its marketable securities on a regular basis to evaluate
 whether or not any security has experienced an other-than-temporary
 decline in fair value. The Company considers factors such as the
 length of time and extent to which the market value has been less
 than the cost, the financial condition and near-term prospects of
 the issue and the Company’s intent to sell, or whether it is
 more likely than not the Company will be required to sell the
 investment before recovery of the investment’s amortized cost
 basis. If the Company believes that an other-than-temporary decline
 exists in one of these securities, the Company will write down
 these investments to fair value.

[0001193125-18-255054:notes:18]
Trade
 accounts receivable

[0001193125-18-255054:notes:19]
Accounts
 receivable are carried at anticipated realizable value. The Company
 assesses the collectability of its accounts receivable based on
 specific customer circumstances, current economic trends,
 historical experience with collection and the age of past due
 receivables and provides an allowance for doubtful receivables
 based on a review of all outstanding amounts at the period end. Bad
 debts are written-off when
 identified.

[0001193125-18-255054:notes:20]
Unanticipated
 changes in the liquidity or financial position of the
 Company’s customers may require revision to the allowances
 for doubtful accounts.

[0001193125-18-255054:notes:21]
Inventory

[0001193125-18-255054:notes:22]
Inventory is
 stated at the lower of cost or market value. Cost is estimated
 using the standard costing method, computed on
 a first-in, first-out basis,
 with adjustments for variances to reflect actual costs not in
 excess of net realizable market value. Market value is the
 estimated selling price in the ordinary course of business, less
 the costs of completion and selling expenses. The Company assesses
 the valuation of inventory on a quarterly basis and writes down the
 value for estimated excess and obsolete inventory based upon
 estimates of future demand.

[0001193125-18-255054:notes:23]
Leases

[0001193125-18-255054:notes:24]
Operating
 leases

[0001193125-18-255054:notes:25]
Payments made
 under operating leases are expensed on a straight-line basis over
 the lease term.

[0001193125-18-255054:notes:26]
Capital
 lease

[0001193125-18-255054:notes:27]
Certain
 machine and equipment held under capital leases are classified as
 property, plant and equipment and amortized using the straight-line
 method over the terms of the lease contracts. The related
 obligations from the capital lease are recorded as liabilities in
 the consolidated balance sheets.

[0001193125-18-255054:notes:28]
Property, plant and equipment

[0001193125-18-255054:notes:29]
Land is
 stated at historical cost. Other property, plant and equipment,
 except for construction in process and machinery under
 installation, are stated at historical cost less accumulated
 depreciation. Depreciation is calculated using the straight-line
 method to write-off the cost
 of each asset to its residual value over its estimated useful life
 as follows:

[0001193125-18-255054:notes:30]
| Land improvements |  |  | 10 years |  |
| Building and building improvements |  |  | 7 - 30 years |  |
| Leasehold improvements |  |  | Shorter of useful life or lease term |  |
| Manufacturing equipment |  |  | 3 - 7 years |  |
| Office equipment |  |  | 3 - 7 years |  |
| Motor vehicles |  |  | 3 - 5 years |  |
| Computer hardware |  |  | 3 - 5 years |  |

[0001193125-18-255054:notes:31]
Construction
 in process and machinery under installation is stated at historic
 cost and depreciation begins after it is constructed and fully
 installed and is ready for its intended use in the operations of
 the Company.

[0001193125-18-255054:notes:32]
Gains and
 losses on disposal are determined by comparing proceeds with
 carrying amounts and are included in operating income in the
 consolidated statements of operations and comprehensive
 income.

[0001193125-18-255054:notes:33]
The Company
 reviews long-lived assets or asset groups for recoverability on a
 quarterly basis for any events or changes in circumstances that
 indicate that their carrying amount may not be recoverable.
 Recoverability of long-lived assets or asset groups is measured by
 comparing their carrying amount to the projected undiscounted cash
 flows that the long-lived assets or asset groups are expected to
 generate. If such assets are considered to be impaired, the
 impairment loss recognized, if any, is the amount by which the
 carrying amount of the property and equipment exceeds its fair
 value.

[0001193125-18-255054:notes:34]
Intangibles

[0001193125-18-255054:notes:35]
Intangibles
 are stated at historical cost less amortization. Amortization of
 customer relationships is calculated using the accelerated method
 as to reflect the pattern in which the economic benefits of the
 intangible assets are consumed. Amortization of other intangibles
 is calculated using the straight-line method.

[0001193125-18-255054:notes:36]
Intangible
 assets are reviewed for impairment quarterly or more frequently
 whenever changes or circumstances indicate the carrying amount of
 related assets may not be recoverable.

[0001193125-18-255054:notes:37]
Business acquisition

[0001193125-18-255054:notes:38]
For the
 acquisition of Fabrinet UK, the Company allocated the fair value of
 purchase consideration to the assets acquired and liabilities
 assumed based on their fair values at the acquisition date. The
 allocation of consideration to the individual net assets was
 finalized in the fourth quarter of fiscal year 2017.

[0001193125-18-255054:notes:39]
The acquired
 intangible assets, which consist of customer relationships and
 backlog, are recorded as intangibles in the consolidated balance
 sheets. The fair value of the acquired intangible assets was
 determined based on the multi-period excess earnings method. The
 Company reviews intangibles for impairment whenever changes or
 circumstances indicate the carrying amount may not be
 recoverable.

[0001193125-18-255054:notes:40]
In connection
 with the business acquisition, $3.4 million of cash, net of
 foreign currency translation adjustment, for deferred
 consideration, was placed into an escrow account which is under the
 Company’s control. However, the Company has contractually
 agreed to remit this deferred consideration to the sellers of
 Fabrinet UK, subject to the resolution of claims that the Company
 may make against the funds with respect to indemnification and
 other claims within 24 months from the closing date of the
 transaction. As of June 29, 2018, the cash is presented as
 restricted cash in the consolidated balance sheets within current
 assets and the related liability is presented within current
 liabilities for the deferred consideration. As of June 30,
 2017, the cash is presented as restricted cash in the consolidated
 balance sheets within non-current assets
 and the related liability is presented
 within non-current liabilities
 for the deferred consideration.

[0001193125-18-255054:notes:41]
Goodwill

[0001193125-18-255054:notes:42]
Goodwill
 arising from the acquisition is primarily attributable to the
 ability to expand future products and services and the assembled
 workforce. Goodwill is reviewed annually for impairment or more
 frequently whenever changes or circumstances indicate the carrying
 amount of goodwill may not be recoverable.

[0001193125-18-255054:notes:43]
Treasury shares

[0001193125-18-255054:notes:44]
Treasury
 share purchases are accounted for under the cost method whereby the
 entire cost of the acquired stock is recorded as treasury shares.
 Gains and losses in excess of par value on the subsequent
 reissuance of shares are credited or charged to
 additional paid-in capital in
 the consolidated balance sheet using the average-cost
 method.

[0001193125-18-255054:notes:45]
Borrowing costs

[0001193125-18-255054:notes:46]
Borrowing
 costs are accounted for on an accrual basis and are charged to the
 consolidated statements of operations and comprehensive income in
 the year incurred, except for interest costs on general and
 specific borrowings attributable to finance certain qualifying
 assets. Such costs to finance qualifying assets are capitalized
 during the period of time that is required to complete and prepare
 the assets for their intended use, as part of the cost of the
 assets. All other borrowing costs are expensed as
 incurred.

[0001193125-18-255054:notes:47]
Where funds
 are not borrowed for a specific acquisition, construction or
 production of assets, the capitalization rate used to determine the
 amount of interest to be capitalized is the weighted average
 interest rate applicable to the Company’s outstanding
 borrowings during the year. Where funds are borrowed specifically
 for the acquisition, construction or production of assets, the
 amount of borrowing costs eligible for capitalization on the
 respective assets is determined as the actual borrowing costs are
 incurred on that borrowing during the respective
 periods.

[0001193125-18-255054:notes:48]
Fair
 value of financial instruments

[0001193125-18-255054:notes:49]
Fair value is
 defined as the exchange price that would be received for an asset
 or paid to transfer a liability (an exit price) in the principal or
 most advantageous market for the asset or liability in an orderly
 transaction between market participants on the measurement date. A
 fair value hierarchy is established which requires an entity to
 maximize the use of observable inputs and minimize the use of
 unobservable inputs for the valuation of an asset or liability as
 of the measurement date. The three levels of inputs that may be
 used to measure fair value are defined as follows:

[0001193125-18-255054:notes:50]
Level 1
 inputs are quoted prices (unadjusted) in active markets for
 identical assets or liabilities.

[0001193125-18-255054:notes:51]
Level 2
 inputs for similar assets and liabilities in active markets other
 than quoted prices included within Level 1 that are observable
 for the asset or liability, either directly or indirectly, for
 substantially the full term of the asset or liability.

[0001193125-18-255054:notes:52]
Level 3
 inputs that are significant to the fair value measurement and
 unobservable (i.e. supported by little or no market activity),
 which require the reporting entity to develop its own valuation
 techniques and assumptions.

[0001193125-18-255054:notes:53]
The Company
 utilizes the market approach to measure fair value for its
 financial assets and liabilities. The market approach uses prices
 and other relevant information generated by market transactions
 involving identical or comparable assets or liabilities.

[0001193125-18-255054:notes:54]
The carrying
 amounts of certain financial instruments, which include cash and
 cash equivalents, trade accounts receivable, and trade accounts
 payable, approximate their fair values due to their short
 maturities. The carrying amounts of borrowings approximate their
 fair values as the applicable interest rate is based on market
 interest rates. The particular recognition methods adopted are
 disclosed in the individual policy statements associated with each
 item.

[0001193125-18-255054:notes:55]
Derivatives

[0001193125-18-255054:notes:56]
The
 derivatives assets and liabilities are recognized on the
 consolidated balance sheets as other current assets or other
 current liabilities and are measured at fair value.

[0001193125-18-255054:notes:57]
The Company
 applies hedge accounting to arrangements that qualify and are
 designated for cash flow or fair value hedge accounting treatment.
 Hedge accounting is discontinued prospectively if the hedging
 relationship ceases to be effective or the hedging or hedged items
 cease to exist as a result of maturity, sale, termination or
 cancellation.

[0001193125-18-255054:notes:58]
Derivatives
 designated and qualifying as hedges of the exposure to variability
 in expected future cash flows, or other types of forecasted
 transactions, are considered cash flow hedges which include forward
 currency contracts. In a cash flow hedging relationship, the
 effective portion of the change in the fair value of the hedging
 derivative is initially recorded in AOCI in the consolidated
 balance sheets, while any ineffective portion is recognized
 directly in earnings, as a component of foreign exchange gain
 (loss) in the consolidated statements of operations and
 comprehensive income. The portion of gain or loss on the derivative
 instrument remains in AOCI until the forecasted transaction is
 recognized in earnings.

[0001193125-18-255054:notes:59]
The Company
 also enters into derivative contracts that are intended to
 economically hedge certain of the Company’s risks. The
 changes in the fair value of the derivatives are recorded directly
 in earnings as a component of foreign exchange gain (loss) in the
 consolidated statements of operations and comprehensive income. In
 accordance with the fair value measurement guidance, the
 Company’s accounting policy is to measure the credit risk of
 its derivative financial instruments that are subject to master
 netting agreements on a net basis by counterparty portfolio. The
 Company executes derivative instruments with financial institutions
 that are credit-worthy, which the Company defines as institutions
 that hold an investment grade credit rating.

[0001193125-18-255054:notes:60]
Concentration of credit risk

[0001193125-18-255054:notes:61]
Financial
 instruments that potentially subject the Company to concentrations
 of credit risk consist of cash and cash equivalents, marketable
 securities, derivatives and accounts receivable.

[0001193125-18-255054:notes:62]
Cash, cash
 equivalents and marketable securities are maintained with several
 financial institutions. Deposits held with banks may exceed the
 amount of insurance provided on such deposits. Generally, these
 deposits may be redeemed upon demand and are maintained with
 financial institutions with reputable credit and therefore bear
 minimal credit risk. The Company seeks to mitigate its credit risks
 by spreading such risks across multiple counterparties and
 monitoring the risk profiles of these counterparties. The Company
 limits its investments in marketable securities to securities with
 a maturity not in excess of three years, and all marketable
 securities that the Company invests in are rated
 A1, P-1, F1, or
 better.

[0001193125-18-255054:notes:63]
The Company
 performs ongoing credit evaluations for credit worthiness of its
 customers and usually does not require collateral from its
 customers. Management has implemented a program to closely monitor
 near term cash collection and credit exposures to mitigate any
 material losses.

[0001193125-18-255054:notes:64]
Revenue
 recognition

[0001193125-18-255054:notes:65]
The Company
 derives total revenues primarily from the assembly of products
 under supply agreements with its customers and the fabrication of
 customized optics and glass. Revenues represent the invoiced value
 of products, net of trade discounts and allowances, and exclude
 goods and services tax. The Company recognizes revenues when
 realized or realizable and earned. The Company considers revenues
 realized or realizable and earned when there is persuasive evidence
 of an arrangement, delivery has occurred, the sales price is fixed
 or determinable, and collectability is reasonably assured. Delivery
 does not occur until products have been shipped or services have
 been provided to the customer, risk of loss has transferred to the
 customer and customer acceptance has been obtained, customer
 acceptance provisions have lapsed, or the Company has objective
 evidence that the criteria specified in the customer acceptance
 provisions have been satisfied. In situations where a formal
 acceptance is required but the acceptance only relates to whether
 the product meets its published specifications, revenues are
 generally recognized upon shipment provided all other revenue
 recognition criteria are met. The sales price is not considered to
 be fixed or determinable until all contingencies related to the
 sale have been resolved. The Company reduces revenues for rebates
 and other similar allowances. Revenues are recognized only if these
 estimates can be reasonably and reliably determined. The Company
 bases its estimates utilizing historical results taking into
 consideration the type of customer, the type of transaction and the
 specifics of each arrangement. In addition to the aforementioned
 general policies, the following are the specific revenue
 recognition policies for each major category of
 revenues.

[0001193125-18-255054:notes:66]
Services

[0001193125-18-255054:notes:67]
The Company
 provides services for its customers that range from process design
 to product manufacturing. The Company recognizes service revenues
 when the services have been performed. The related costs are
 expensed as incurred.

[0001193125-18-255054:notes:68]
Services
 revenue of $57.1 million, $75.4 million and
 $31.7 million were recognized in the consolidated statements
 of operations and comprehensive income for the years ended
 June 29, 2018, June 30, 2017 and June 24, 2016,
 respectively.

[0001193125-18-255054:notes:69]
Sales of
 goods

[0001193125-18-255054:notes:70]
Revenues from
 sales of goods are generally recognized when the product is shipped
 to the customer and when there are no unfulfilled obligations that
 affect the customer’s final acceptance of the arrangement.
 Any cost of warranties and remaining obligations that are
 inconsequential or perfunctory are accrued when the corresponding
 revenues are recognized.

[0001193125-18-255054:notes:71]
Certain
 customers may request the Company to store finished products
 purchased by them at the Company’s warehouse. In these
 instances, the Company receives a written request from the customer
 asking the Company to hold the inventory at the Company’s
 warehouse and the ordered goods are segregated in the
 Company’s warehouse from other inventory and cannot be used
 to fulfill other customer orders. In these situations, revenue is
 only recognized when persuasive evidence of the sales arrangement
 exists, the goods are completed and ready for shipment, pricing is
 fixed or determinable, collection is reasonably assured, and title
 and risk of loss have passed to the customer.

[0001193125-18-255054:notes:72]
Warranty provision

[0001193125-18-255054:notes:73]
Provisions
 for estimated expenses relating to product warranties are made at
 the time the products are sold using historical experience.
 Generally, this warranty is limited to workmanship and the
 Company’s liability is capped at the price of the product.
 The provisions will be adjusted when experience indicates an
 expected settlement will differ from initial estimates.

[0001193125-18-255054:notes:74]
(Reversal of)
 warranty cost allowances of ($0.02 million), $1.0 million and
 $0.1 million were recognized in the consolidated statements of
 operations and comprehensive income for the years ended
 June 29, 2018, June 30, 2017 and June 24, 2016,
 respectively.

[0001193125-18-255054:notes:75]
Shipping and handling costs

[0001193125-18-255054:notes:76]
The Company
 records costs related to shipping and handling in cost of revenues
 for all periods presented.

[0001193125-18-255054:notes:77]
Share-based compensation

[0001193125-18-255054:notes:78]
Share-based
 compensation is recognized in the consolidated financial statements
 based on grant-date fair value. The value of the portion of the
 award that is ultimately expected to vest is recognized as expense
 ratably over the requisite service period. The Company estimates
 the fair value of share option awards utilizing the
 Black-Scholes-Merton option-pricing model (“BSM”), net
 of estimated forfeitures. For restricted share units and
 performance share units, the fair values are based on the market
 value of our ordinary shares on the date of grant.

[0001193125-18-255054:notes:79]
Employee contribution plan

[0001193125-18-255054:notes:80]
The Company
 operates a defined contribution plan, known as a provident fund, in
 its subsidiaries in Thailand and the United Kingdom. The assets of
 these plans are in separate trustee-administered funds. The
 provident fund is funded by matching payments from employees and by
 the subsidiaries on a monthly basis. Current contributions to the
 provident fund are accrued and paid to the fund manager on a
 monthly basis. The Company sponsors the Fabrinet U.S. 401(k)
 Retirement Plan (the “401(k) Plan”), a Defined
 Contribution Plan under ERISA, at its subsidiaries in the United
 States, which provides retirement benefits for its eligible
 employees through tax deferred salary deductions.

[0001193125-18-255054:notes:81]
Severance liabilities

[0001193125-18-255054:notes:82]
Under labor
 protection laws applicable in Thailand and the Company’s
 subsidiary in Thailand’s employment policy, all employees of
 such subsidiary with more than 120 days of service are entitled to
 severance pay on forced termination or retrenchment or in the event
 that the employee reaches the retirement age of 55. The entitlement
 to severance pay is determined according to an employee’s
 individual employment tenure with the Company and is subject to a
 maximum benefit of 10 months of salary unless otherwise agreed upon
 in an employee’s employment contract. For employees of other
 subsidiaries who have a specific termination date, the entitlement
 to severance pay is determined according to their employment
 tenure, until their designated termination date.

[0001193125-18-255054:notes:83]
The Company
 accounts for these severance liabilities on an actuarial basis
 using the Projected Unit Credit Method, using the long-term Thai
 government bond yield as a discount rate. There are no separate
 plan assets held in respect of these liabilities.

[0001193125-18-255054:notes:84]
Annual
 leave

[0001193125-18-255054:notes:85]
Employee
 entitlements to annual leave are recognized when they accrue to the
 employee. On termination of employment, accrued employee
 entitlement to annual leave is paid in cash.

[0001193125-18-255054:notes:86]
Income
 taxes

[0001193125-18-255054:notes:87]
The Company
 uses the asset and liability method of accounting for income taxes,
 whereby deferred tax assets and liabilities are recognized for
 future tax consequences attributable to temporary differences
 between the financial statement carrying amounts of existing assets
 and liabilities and their respective tax bases. Deferred tax assets
 and liabilities are measured using tax rates expected to apply to
 taxable income in the years in which those temporary differences
 are expected to reverse. The effect of a change in tax rates on
 deferred tax assets and liabilities is recognized in income in the
 period that includes the enactment date. Deferred tax assets are
 reduced by a valuation allowance if, based on the weight of the
 available evidence, it is more likely than not that some portion or
 all of the deferred tax assets will not be realized.

[0001193125-18-255054:notes:88]
Fabrinet’s subsidiaries are subject to income tax audits
 by the respective tax authorities in all of the jurisdictions in
 which they operate. The determination of tax liabilities in each of
 these jurisdictions requires the interpretation and application of
 complex and sometimes uncertain tax laws and
 regulations. The Company recognizes
 liabilities based on its estimate of whether, and the extent to
 which, additional tax liabilities
 are more-likely-than-not. If
 the Company ultimately determines that the payment of such a
 liability is not probable, then it reverses the liability and
 recognizes a tax benefit during the period in which the
 determination is made that the liability is no longer probable. The
 recognition and measurement of current taxes payable or refundable
 and deferred tax assets and liabilities requires that the Company
 makes certain estimates and judgments. Changes to these estimates
 or a change in judgment may have a material impact on the
 Company’s tax provision in a future period.

[0001193125-18-255054:notes:89]
The
 authoritative guidance provides for recognition of deferred tax
 assets if the realization of such deferred tax assets is more
 likely than not to occur based on an evaluation of both positive
 and negative evidence and the relative weight of the evidence. A
 company shall reduce its deferred tax assets by a valuation
 allowance if, based on the weight of available evidence, it is
 “more likely than not” (i.e., a likelihood of greater
 than 50 percent) that some portion or all of the deferred tax
 assets will not be realized. The valuation allowance shall be
 sufficient to reduce the deferred tax asset to the amount that is
 more likely than not to be realized. The valuation allowance shall
 be monitored and considered from all available evidence, both
 positive and negative, to determine whether, based on the weight of
 that evidence, a valuation allowance for deferred tax assets is not
 needed.

[0001193125-18-255054:notes:90]
The
 accounting standard clarifies the accounting for uncertainty in
 income taxes recognized in an entity’s financial statements
 and prescribes a recognition threshold and measurement attributes
 for financial statement disclosure of tax positions taken or
 expected to be taken on a tax return.

[0001193125-18-255054:notes:91]
The Company
 recognizes a tax benefit in the financial statements for an
 uncertain tax position only if management’s assessment is
 that the position is “more likely than not” to be
 sustained upon examination by the tax jurisdiction based solely on
 the technical merits of the position. The term “tax
 position” refers to a position in a previously filed tax
 return or a position expected to be taken in a future tax return
 that is reflected in measuring current or deferred income tax
 assets and liabilities for interim or annual periods. The
 accounting interpretation also provides guidance on measurement
 methodology, derecognition thresholds, financial statement
 classification and disclosures, recognition of interest and
 penalties, and accounting for the cumulative-effect adjustment at
 the date of adoption.

[0001193125-18-255054:notes:92]
New
 Accounting Pronouncements—not yet adopted by the
 Company

[0001193125-18-255054:notes:93]
In November
 2017, the Financial Accounting Standards Board (“FASB”)
 issued Accounting Standards Update
 (“ASU”) 2017-14, “Income
 Statement—Reporting Comprehensive Income (Topic 220), Revenue
 Recognition (Topic 605), and Revenue from Contracts with Customers
 (Topic 606): Amendments to SEC Paragraphs Pursuant to the Staff
 Accounting Bulletin (“SAB”) No. 116 and SEC
 Release No. 33-10403”. This
 ASU amended, superseded and added certain SEC paragraphs in Topic
 220, Topic 605 and Topic 606 to reflect the August 2017 issuance of
 SEC Staff Accounting Bulletin (SAB) 116 and SEC
 Release No. 33-10403. The
 SEC staff issued SAB 116 to align its revenue guidance with
 Accounting Standards Codification (ASC) 606. For public business
 entities, this update is effective for fiscal years beginning after
 December 15, 2017, including interim periods within those
 fiscal years. Early application is permitted. The Company will
 implement this standard along with the implementation of ASC 606
 effective June 30, 2018 and does not expect that the adoption
 of this standard will have a material impact on its consolidated
 financial statements.

[0001193125-18-255054:notes:94]
In September
 2017, the FASB issued ASU 2017-13, “Revenue
 Recognition (Topic 605), Revenue from Contracts with Customers
 (Topic 606), Leases (Topic 840), and Leases (Topic 842): Amendments
 to SEC Paragraphs Pursuant to the Staff Announcement at the
 July 20, 2017 EITF Meeting and Rescission of Prior SEC Staff
 Announcements and Observer Comments.” The amendment delays
 the mandatory adoption of Topic 606 and Topic 842 for certain
 entities, revises the guidance related to performance-based
 incentive fees in Topic 605 and revises the guidance related to
 leases in Topic 840 and Topic 842. The revisions to the lease
 guidance eliminate language specific to certain sale-leaseback
 arrangements, guarantees of lease residual assets and loans made by
 lessees to owner-lessors. Also included is an amendment to Topic
 842 to retain the guidance in Topic 840 covering the impact of
 changes in tax rates on investments in leveraged leases. This
 guidance, which is effective immediately, generally relates to the
 adoption of Topic 606 and Topic 842. The Company does not expect
 the amendments will impact its consolidated financial
 statements.

[0001193125-18-255054:notes:95]
In January
 2017, the FASB issued ASU 2017-04, “Intangibles—Goodwill
 and Other (Topic 350): Simplifying the Test for Goodwill
 Impairment.” This amendment modified the concept of
 impairment assessment from the condition that exists when the
 carrying amount of goodwill exceeds its implied fair value to the
 condition that exists when the carrying amount of a reporting unit
 exceeds its fair value. Public companies that are SEC filers should
 adopt the amendment for its annual and any interim goodwill
 impairment tests in fiscal years beginning after December 15,
 2019. Early adoption is permitted for interim or annual goodwill
 impairment tests performed on testing dates after January 1,
 2017. The Company is currently evaluating the impact of the
 adoption of this update on its consolidated financial
 statements.

[0001193125-18-255054:notes:96]
In January
 2017, the FASB issued ASU 2017-03, “Accounting
 Changes and Error Corrections (Topic 250) and Investments –
 Equity Method and Joint Ventures (Topic 323): Amendments to SEC
 Paragraphs Pursuant to Staff Announcements at the
 September 22, 2016 and November 17, 2016 EITF
 Meetings.” The amendment provides guidance to the Company in
 relation to the disclosure of the impact that
 ASU 2014-09, ASU 2016-02 and
 ASU 2016-13 will have on
 the Company’s financial statements when adopted. The Company
 is currently evaluating the impact of the adoption of this update
 on its consolidated financial statements.

[0001193125-18-255054:notes:97]
In January
 2017, the FASB issued ASU 2017-01, “Business
 Combination (Topic 805): Clarifying the Definition of a
 Business.” This amendment clarifies the definition of a
 business to assist entities when evaluating whether transactions
 should be accounted for as acquisitions (or disposals) of assets or
 business. For public companies, this ASU is effective for annual
 periods beginning after December 15, 2017, including interim
 periods within those periods. Early adoption is permitted for the
 transactions that occur before the issuance date or effective date
 of the amendment, only when the transaction has not been reported
 in financial statements that have been issued or made available for
 issuance. The Company does not expect that the adoption of this
 update will have a material impact on its consolidated financial
 statements.

[0001193125-18-255054:notes:98]
In August
 2016, the FASB issued ASU 2016-15, “Classification
 of Certain Cash Receipts and Cash Payments (a consensus of the
 Emerging Issues Task Force).” The amendments in this ASU
 provide guidance on the presentation of certain cash receipts and
 cash payments in the statement of cash flows in order to reduce
 diversity in existing practice. The amendments in
 ASU 2016-15 are
 effective for public business entities for fiscal years beginning
 after December 15, 2017, and interim periods within those
 fiscal years. Early adoption is permitted, including adoption in an
 interim period. The Company will adopt this new update effective
 June 30, 2018. The Company does not expect that the adoption
 of this update will have a material impact on its consolidated
 financial statements.

[0001193125-18-255054:notes:99]
In February
 2016, the FASB issued ASU 2016-02, “Lease
 (Topic 842).” The core principle of Topic 842 is that a
 lessee should recognize the lease assets and liabilities that arise
 from leases in the statement of financial position. For public
 business entities, this update is effective for fiscal years
 beginning after December 15, 2018, including interim periods
 within those fiscal years. Early application is permitted. The
 Company is currently evaluating the impact of the adoption of this
 update on its consolidated financial statements.

[0001193125-18-255054:notes:100]
In January
 2016, the FASB issued ASU 2016-01, “Financial
 Instruments—Overall (Subtopic 825-10): Recognition
 and Measurement of Financial Assets and Financial
 Liabilities.” This new guidance requires certain equity
 investments to be measured at fair value, use of the exit price
 notion and separate presentation of financial assets and financial
 liabilities by measurement category and form of financial asset on
 the balance sheet or the accompanying notes to the financial
 statements. The ASU on recognition and measurement will take effect
 for public companies for fiscal years beginning after
 December 15, 2017, including interim periods within those
 fiscal years. In addition, in February 2018, the FASB issued
 ASU 2018-03,“Technical Corrections
 and Improvements to Financial Instruments – Overall
 (Subtopic 825-10), Recognition
 and Measurement of Financial Assets and Financial Liabilities. This
 guidance clarifies certain aspects of the guidance issued in
 ASU 2016-01 on
 (1) equity securities without a readily determinable fair
 value – discontinuation, (2) equity securities without a
 readily determinable fair value – adjustments,
 (3) forward contracts and purchased options,
 (4) presentation requirements for certain fair value option
 liabilities, and (5) fair value option liabilities denominated
 in a foreign currency. The Company will adopt this new update
 effective June 30, 2018. The Company does not expect that the
 adoption of this update will have a material impact on its
 consolidated financial statements.

[0001193125-18-255054:notes:101]
In May 2014,
 as part of its ongoing efforts to assist in the convergence
 of accounting principles generally accepted in the United
 States of America (“U.S. GAAP”), the
 FASB issued ASU 2014-09, “Revenue
 from Contracts with Customers (Topic 606)” (“ASC
 606”). The new guidance sets forth a new five-step revenue
 recognition model which replaces the prior revenue recognition
 guidance in its entirety and is intended to eliminate numerous
 industry-specific pieces of revenue recognition guidance that have
 historically existed in U.S. GAAP. The underlying principle of the
 new standard is that a business or other organization will
 recognize revenue to depict the transfer of promised goods or
 services to customers in an amount that reflects what it expects in
 exchange for the goods or services. The standard also requires more
 detailed disclosures and provides additional guidance for
 transactions that were not addressed completely in the prior
 accounting guidance. The ASU provides alternative methods of
 initial adoption and is effective for annual and interim periods
 beginning after December 15, 2017. The FASB has issued several
 updates to the standard which (1) defer the original effective
 date from January 1, 2017 to January 1, 2018, while
 allowing for early adoption as of January 1, 2017
 (ASU 2015-14); (2)
 clarify the application of the principal versus agent guidance
 (ASU 2016-08); (3)
 clarify the guidance on inconsequential and perfunctory promises
 and licensing (ASU 2016-10); and
 (4) clarify the guidance on certain sections of the guidance
 providing technical corrections and improvements
 (ASU 2016-10). In May
 2016, the FASB issued ASU 2016-12, “Revenue from
 Contracts with Customers (Topic 606) Narrow-Scope Improvements and
 Practical Expedients”, to address certain narrow aspects of
 the guidance including collectability criterion, collection of
 sales taxes from customers, noncash consideration, contract
 modifications and completed contracts. This issuance does not
 change the core principle of the guidance in the initial topic
 issued in May 2014.

[0001193125-18-255054:notes:102]
The Company
 set up a team for the implementation of the new revenue recognition
 accounting standard, including hiring of external advisors to help
 with the implementation efforts of ASC 606, as amended. The Company
 utilized a comprehensive approach to evaluate the impact of
 adopting ASC 606 on its contract portfolio by reviewing the current
 revenue accounting policies and practices to identify differences
 that would result from applying the new guidance to the revenue
 contracts on amount and timing of revenue recognition.

[0001193125-18-255054:notes:103]
The Company
 currently recognizes the majority of its manufacturing revenue when
 title and risk and rewards of ownership have passed, the price to
 the buyer is fixed or determinable and recoverability is reasonably
 assured, which generally is when the goods are shipped. The Company
 has determined that the new standard will have no substantial
 changes to its current revenue recognition policy as the
 Company’s revenues will continue to be recognized at a
 “point in time” model. However, there will be a portion
 of revenue contracts that will fall into an “over time”
 model as the customers take control of the products as they are
 produced, as opposed to at a “point in time” upon
 physical delivery. Service revenue will also continue to be
 recognized at an “over time” model as services are
 performed.

[0001193125-18-255054:notes:104]
The Company
 has substantially completed a review of the accounting systems and
 processes required to apply this new guidance. Additionally, the
 Company has completed the majority of the assessment phase and
 documentation of new policies and is currently in the process of
 adjusting its accounting policies, operational and financial
 reporting processes, and relevant internal controls and gathering
 data for the new disclosure requirements.

[0001193125-18-255054:notes:105]
ASC 606
 allows for either “full retrospective” adoption,
 meaning the standard is applied to all periods presented, or
 “modified retrospective” adoption, meaning the standard
 is applied only to the most current period presented in the
 financial statements as of the adoption date. The Company will
 adopt the standard using the modified retrospective approach,
 effective as of June 30, 2018.

[0001193125-18-255054:notes:106]
New
 Accounting Pronouncements—adopted by the
 Company

[0001193125-18-255054:notes:107]
In February
 2018, the FASB issued ASU 2018-02 “Income
 Statement – Reporting Comprehensive Income (Topic 220),
 Reclassification of Certain Tax Effects from Accumulated Other
 Comprehensive Income.” This ASU which allows companies to
 reclassify stranded tax effects in accumulated other comprehensive
 income (loss) that have been caused by the Tax Cuts and Jobs Act of
 2017 (the Act) to retained earnings for each period in which the
 effect of the change in the U.S. federal corporate income tax rate
 is recorded. The FASB has made the reclassification
 optional. In addition, in March 2018, the FASB issued
 ASU 2018-05, “Income
 Taxes (Topic 740), Amendments to SEC Paragraphs Pursuant to SEC
 Staff Accounting Bulletin No. 118,” which updates the
 income tax accounting in U.S. GAAP to reflect SEC guidance released
 on December 22, 2017, when the Act was signed into law. The
 Company adopted these updates with immaterial impact to the
 consolidated financial statements.

[0001193125-18-255054:notes:108]
In August
 2017, the FASB issued ASU 2017-12, “Derivatives
 and Hedging (Topic 815): Targeted Improvements to Accounting for
 Hedging Activities.” The amendments better align an
 entity’s risk management activities and financial reporting
 for hedging relationships through changes to both the designation
 and measurement guidance for qualifying hedging relationships and
 the presentation of hedge results. To meet that objective, the
 amendments expand and refine hedge accounting for both nonfinancial
 and financial risk components and align the recognition and
 presentation of the effects of the hedging instrument and the
 hedged item in the financial statements. The amendments also make
 certain targeted improvements to simplify the application of hedge
 accounting guidance and ease the administrative burden of hedge
 documentation requirements and assessing hedge effectiveness. This
 ASU is the final version of Proposed Accounting Standards
 Update 2016-310—Derivatives and
 Hedging (Topic 815): Targeted Improvements to Accounting for
 Hedging Activities, which has been deleted. During the fiscal year
 2018, the Company adopted this update with no impact to the
 consolidated financial statements.

[0001193125-18-255054:notes:109]
In November
 2016, the FASB issued ASU 2016-18, “Statement
 of Cash Flows (Topic 230): Restricted Cash,” which requires
 the statement of cash flows to explain the change during the period
 in the total of cash, cash equivalents and restricted cash or
 restricted cash equivalents. The Company has early adopted this
 update in the second quarter of fiscal year 2017 on a retrospective
 basis. As of June 29, 2018 and June 30, 2017, restricted
 cash in connection with business acquisition of $3.3 million
 was presented in the statement of cash flows as cash, cash
 equivalents and restricted cash.

[0001193125-18-255054:notes:110]
In March
 2016, the FASB issued ASU 2016-09, “Compensation—Stock Compensation
 (Topic 718): Improvements to Employee Share-Based Payment
 Accounting.” This ASU simplifies several aspects of the
 accounting for share-based payment award transactions, including,
 the income tax consequences, classification of awards as either
 equity or liabilities and classification on the statement of cash
 flows. The amendments in this update are effective for annual
 periods beginning after December 15, 2016, and interim periods
 within those annual periods, for public companies. Early adoption
 is permitted for any entity in any interim or annual period. During
 fiscal year 2018, the Company adopted this update with no impact to
 the consolidated financial statements.

[0001193125-18-255054:notes:111]
In March
 2016, the FASB issued ASU 2016-05, “Derivatives
 and Hedging (Topic 815),” to clarify that a change in the
 counterparty to a derivative instrument that has been designated as
 a hedging instrument under Topic 815, does not, in and of itself,
 require designation of the hedging relationship, provided that all
 other hedge accounting criteria continue to be met. This guidance
 is effective for public entities for financial statements issued
 for fiscal years beginning after December 15, 2016 and interim
 periods within those fiscal years. During fiscal year 2018, the
 Company adopted this update with no impact to the consolidated
 financial statements.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-18-255054:notes:112]
The following
 table summarizes the cost and estimated fair value of marketable
 securities classified as available-for-sale securities
 based on stated effective maturities as of June 29,
 2018:

[0001193125-18-255054:notes:113]
| (amount in thousands) |  | Carrying Cost |  |  | Fair Value |  |
| Due within one year |  | $ | 28,216 |  |  | $ | 28,193 |  |
| Due between one to three years |  |  | 147,144 |  |  |  | 146,076 |  |
| Total |  | $ | 175,360 |  |  | $ | 174,269 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-18-255054:notes:114]
| 9. | Business acquisition |

[0001193125-18-255054:notes:115]
On
 September 14, 2016, the Company acquired 100% shareholding in
 Fabrinet UK (formerly known as Exception EMS), a privately-held
 group located in Wiltshire, United Kingdom, for cash
 consideration of approximately $13.0 million, net of
 $0.5 million cash acquired. Fabrinet UK provides contract
 electronics manufacturing services to the global electronics
 industry with innovative solutions, adding value to the design,
 manufacture and testing of printed circuit board assemblies.
 Pursuant to the acquisition agreement, the Company has placed
 $3.4 million of cash, net of foreign currency translation
 adjustment, for deferred consideration in an escrow account which
 is under the Company’s control. However, the Company has
 contractually agreed to remit this deferred consideration to the
 sellers of Fabrinet UK, subject to the resolution of claims that
 the Company may make against the funds with respect to
 indemnification and other claims, within 24 months from the closing
 date of the transaction.

[0001193125-18-255054:notes:116]
The Company has
 accounted for this acquisition under the provisions of business
 combinations accounting, in accordance with Accounting Standards
 Codification Topic 805—Business Combinations. Accordingly,
 the estimated fair value of the acquisition consideration was
 allocated to the assets acquired and the liabilities assumed based
 on their respective fair values on the acquisition date. The
 Company has made certain estimates and assumptions in determining
 the allocation of the acquisition consideration.

[0001193125-18-255054:notes:117]
The allocation
 of consideration to the individual net assets acquired was
 finalized in the fourth quarter of fiscal year 2017. As the
 functional currency of Fabrinet UK is pound sterling
 (“GBP”), for the year ended June 29, 2018, the
 Company recognized a $0.1 million gain from foreign currency
 translation adjustment in its consolidated statements of operations
 and comprehensive income, under other comprehensive (loss) income,
 net of tax.

[0001193125-18-255054:notes:118]
During the year
 ended June 30, 2017, the Company recorded a measurement period
 adjustment to recognized deferred tax liabilities of
 $1.2 million related to taxable temporary differences from
 intangibles and changes in the fair value of assets acquired.
 Therefore, goodwill which was previously reported at acquisition
 date of $2.7 million was changed to
 $3.9 million.

[0001193125-18-255054:notes:119]
The
 Company’s allocation of the total purchase price for the
 acquisition is summarized below:

[0001193125-18-255054:notes:120]
| (amount in thousands) |  | Purchase price allocation |  |
| Cash |  | $ | 474 |  |
| Accounts receivable |  |  | 4,064 |  |
| Inventory |  |  | 3,490 |  |
| Other current assets |  |  | 427 |  |
| Property, plant and equipment |  |  | 5,678 |  |
| Intangibles |  |  | 4,492 |  |
| Goodwill |  |  | 3,883 |  |
| Other non-current assets |  |  | 516 |  |
| Current liabilities |  |  | (6,796 | ) |
| Deferred tax liabilities |  |  | (1,148 | ) |
| Other non-current liabilities |  |  | (1,563 | ) |
| Total fair value of assets acquired and liabilities assumed |  | $ | 13,517 |  |
| Total purchase price, net of cash acquired |  | $ | 13,043 |  |

[0001193125-18-255054:notes:121]
In connection
 with the Company’s acquisition of Fabrinet UK, the Company
 assumed lease agreements for certain machine and equipment, which
 are accounted for as capital leases. As of June 29, 2018, the
 Company included approximately $1.4 million of capital lease
 assets and $1.0 million of capital lease liability in the
 consolidated balance sheets associated with these acquired lease
 agreements.

[0001193125-18-255054:notes:122]
During
 the year ended June 30, 2017, the Company incurred
 approximately $1.5 million in transaction costs related
 to the acquisition, which primarily consisted of legal, accounting
 and valuation-related expenses. These expenses were recorded in
 selling, general and administrative expense in the accompanying
 consolidated statements of operations and comprehensive
 income.

[0001193125-18-255054:notes:123]
During the year
 ended June 29, 2018, there were no transaction costs related
 to the acquisition.

[0001193125-18-255054:notes:124]
Pro forma
 results of operations for the acquisition have not been presented
 as they were not material to the Company’s results of
 operations.

[0001193125-18-255054:notes:125]
Identifiable intangibles

[0001193125-18-255054:notes:126]
The acquired
 identifiable intangible assets include customer relationships and
 backlog. The fair value of the identified intangible assets was
 determined based on the multi-period excess earnings method, which
 applied the following key assumptions:

[0001193125-18-255054:notes:127]
| Risk free rate: |  | 30-year UK Government Bond adjusted by spot yield to reflect recent volatility |
| Long-term revenue growth: |  | 5.0% - 8.0% |
| Churn rate: |  | 10% |
| Operating margin: |  | 4.0% - 6.0% |

[0001193125-18-255054:notes:128]
Customer
 relationships represent the fair value of future projected revenues
 derived from the sale of products to existing customers of the
 acquired company. The fair value of $4.4 million will be
 amortized, using the accelerated method, over an estimated useful
 life of ten years.

[0001193125-18-255054:notes:129]
Backlog
 represents the fair value of sales orders backlog as of the
 valuation date. The fair value of $0.1 million will be
 amortized, using an accelerated amortization method, over the
 respective estimated useful life of three years.

[0001193125-18-255054:notes:130]
Goodwill
 arising from the acquisition is primarily attributable to the
 ability to expand future products and services and the assembled
 workforce. Goodwill is not deductible for tax purposes.


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001193125-18-255054:notes:131]
| 5. | Cash, cash equivalents and marketable securities |

[0001193125-18-255054:notes:132]
The
 Company’s cash, cash equivalents,
 and marketable securities can be analyzed as
 follows:

[0001193125-18-255054:notes:133]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Loss |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of June 29, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 146,778 |  |  | $ | — |  |  | $ | 146,778 |  |  | $ | — |  |
| Cash equivalents |  |  | 11,324 |  |  |  | — |  |  |  | 11,324 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 128,441 |  |  |  | (736 | ) |  |  | — |  |  |  | 127,705 |  |
| U.S. agency and U.S. treasury securities |  |  | 43,734 |  |  |  | (324 | ) |  |  | — |  |  |  | 43,410 |  |
| Sovereign and municipal securities |  |  | 3,185 |  |  |  | (31 | ) |  |  | — |  |  |  | 3,154 |  |
| Total |  | $ | 333,462 |  |  | $ | (1,091 | ) |  | $ | 158,102 |  |  | $ | 174,269 |  |

[0001193125-18-255054:notes:134]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Gain (Loss) |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of June 30, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 131,240 |  |  | $ | — |  |  | $ | 131,240 |  |  | $ | — |  |
| Cash equivalents |  |  | 2,585 |  |  |  | — |  |  |  | 2,585 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 98,247 |  |  |  | 27 |  |  |  | — |  |  |  | 98,274 |  |
| U.S. agency and U.S. treasury securities |  |  | 50,768 |  |  |  | (102 | ) |  |  | — |  |  |  | 50,666 |  |
| Sovereign and municipal securities |  |  | 2,507 |  |  |  | 3 |  |  |  | — |  |  |  | 2,510 |  |
| Total |  | $ | 285,347 |  |  | $ | (72 | ) |  | $ | 133,825 |  |  | $ | 151,450 |  |

[0001193125-18-255054:notes:135]
The cash
 equivalents include short-term bank deposits, investments in money
 market funds, and marketable securities with maturities of three
 months or less at the date of purchase. The effective interest rate
 on short term bank deposits was 0.8% and 0.6% per annum for the
 years ended June 29, 2018 and June 30, 2017,
 respectively.

[0001193125-18-255054:notes:136]
As of
 June 29, 2018 and June 30, 2017, 49% and 66%,
 respectively, of our cash and cash equivalents were held by the
 Parent Company.

[0001193125-18-255054:notes:137]
During the year
 ended June 29, 2018, the net realized loss from changes in
 fair value of marketable securities recognized by the Company was
 $0.4 million.

[0001193125-18-255054:notes:138]
As of
 June 29, 2018 and June 30, 2017, the Company considered
 the declines in market value of its marketable securities
 investment portfolio to be temporary in nature and did not consider
 any of its securities other-than-temporarily impaired. The Company
 typically invests in highly-rated securities, and its investment
 policy generally limits the amount of credit exposure to any one
 issuer. The policy requires investments generally to be investment
 grade, with the primary objective of minimizing the potential risk
 of principal loss. Fair values were determined for each individual
 security in the investment portfolio. When evaluating an investment
 for other-than-temporary impairment, the Company reviews factors
 such as the length of time and extent to which fair value has been
 below its cost basis, the financial condition of the issuer and any
 changes thereto, changes in market interest rates, and the
 Company’s intent to sell, or whether it is more likely than
 not it will be required to sell, the investment before recovery of
 the investment’s cost basis. No impairment losses were
 recorded for the years ended June 29, 2018 and June 30,
 2017.

[0001193125-18-255054:notes:139]
As of
 June 29, 2018 and June 30, 2017, cash, cash equivalents,
 and marketable securities included a bank deposit of
 $40.0 million held in various financial institutions located
 in the United States in order to support the availability of the
 Facility Agreement and comply with covenants. Under the terms and
 conditions of the Facility Agreement, the Company shall maintain
 cash, cash equivalents and/or marketable securities in an aggregate
 amount not less than $40.0 million in unencumbered deposits,
 and/or securities in accounts located in the United States at all
 times during the term of the Facility Agreement. As discussed in
 Note 13, the Company must comply with this covenant from and after
 the effective date of the Facility Agreement.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-18-255054:notes:140]
| 19. | Commitments and contingencies |

[0001193125-18-255054:notes:141]
Bank
 guarantees

[0001193125-18-255054:notes:142]
As of
 June 29, 2018 and June 30, 2017, there were outstanding
 bank guarantees given by a bank on behalf of our subsidiary in
 Thailand for electricity usage and other normal business amounting
 to $1.5 million.

[0001193125-18-255054:notes:143]
Operating
 lease commitments

[0001193125-18-255054:notes:144]
The Company
 leases a portion of its capital equipment, vehicle, and certain
 land and buildings for its facilities in Thailand, Cayman Islands,
 China, the United States and the United Kingdom under operating
 lease arrangements that expire in various years through 2023.
 Rental expense under these operating leases amounted to
 $1.8 million, $1.7 million and $1.2 million for the
 years ended June 29, 2018, June 30, 2017 and
 June 24, 2016, respectively.

[0001193125-18-255054:notes:145]
As of
 June 29, 2018, the future minimum lease payments due under
 non-cancelable operating
 leases during each fiscal year were as follows:

[0001193125-18-255054:notes:146]
| (amount in thousands) |  |  |  |
| 2019 |  | $ | 1,263 |  |
| 2020 |  |  | 943 |  |
| 2021 |  |  | 542 |  |
| 2022 |  |  | 427 |  |
| Thereafter |  |  | 456 |  |
| Total future minimum operating lease payments |  | $ | 3,631 |  |

[0001193125-18-255054:notes:147]
Capital
 lease commitments

[0001193125-18-255054:notes:148]
In connection
 with the acquisition of Fabrinet UK, the Company assumed the
 capital lease commitments of several machines and equipment, with
 various expiration dates until September 2020. The equipment can be
 purchased at the determined prices upon expiration of such
 contracts.

[0001193125-18-255054:notes:149]
As of
 June 29, 2018, the future minimum lease payments under
 non-cancelable capital
 leases during each fiscal year were as follows:

[0001193125-18-255054:notes:150]
| (amount in thousands) |  |  |  |
| 2019 |  | $ | 481 |  |
| 2020 |  |  | 424 |  |
| 2021 |  |  | 106 |  |
| Total minimum capital lease payments |  |  | 1,011 |  |
| Less: Future finance charge on capital leases |  |  | (44 | ) |
| Present value of capital lease |  | $ | 967 |  |

[0001193125-18-255054:notes:151]
Representing
 capital lease liabilities

[0001193125-18-255054:notes:152]
| Current |  | $ | 451 |  |
| Non-current |  |  | 516 |  |
| Total capital lease liabilities |  | $ | 967 |  |

[0001193125-18-255054:notes:153]
As of
 June 29, 2018, the present value of capital lease during each
 fiscal year were as follows:

[0001193125-18-255054:notes:154]
| (amount in thousands) |  |  |  |
| 2019 |  | $ | 451 |  |
| 2020 |  |  | 411 |  |
| 2021 |  |  | 105 |  |
| Total future minimum capital lease payments |  | $ | 967 |  |

[0001193125-18-255054:notes:155]
Purchase
 obligations

[0001193125-18-255054:notes:156]
Purchase
 obligations represent legally-binding commitments to purchase
 inventory and other commitments made in the normal course of
 business to meet operational requirements. Although open purchase
 orders are considered enforceable and legally binding, their terms
 generally give the Company the option to cancel, reschedule and/or
 adjust its requirements based on its business needs prior to the
 delivery of goods or performance of services. Obligations to
 purchase inventory and other commitments are generally expected to
 be fulfilled within one year.

[0001193125-18-255054:notes:157]
On
 December 23, 2016, the Company entered into an agreement to
 purchase a parcel of land in Chonburi, Thailand, to support the
 expansion of the Company’s production in Thailand. The
 aggregate purchase price was approximately $5.6 million, of
 which the first installment of $1.1 million was paid by the
 Company on January 10, 2017 and the remainder was fully paid
 on December 25, 2017.

[0001193125-18-255054:notes:158]
As of
 June 29, 2018, the Company had an outstanding commitment to
 third parties of $2.4 million.

[0001193125-18-255054:notes:159]
Indemnification of directors and
 officers

[0001193125-18-255054:notes:160]
Cayman Islands
 law does not limit the extent to which a company’s memorandum
 and articles of association may provide for indemnification of
 directors and officers, except to the extent any such provision may
 be held by the Cayman Islands courts to be contrary to public
 policy, such as to provide indemnification against civil fraud or
 the consequences of committing a crime. Fabrinet’s amended
 and restated memorandum and articles of association provide for
 indemnification of directors and officers for actions, costs,
 charges, losses, damages and expenses incurred in their capacities
 as such, except that such indemnification does not extend to any
 matter in respect of any fraud or dishonesty that may attach to any
 of them.

[0001193125-18-255054:notes:161]
In accordance
 with Fabrinet’s form of indemnification agreement for its
 directors and officers, Fabrinet has agreed to indemnify its
 directors and officers against certain liabilities and expenses
 incurred by such persons in connection with claims by reason of
 their being such a director or officer. Fabrinet maintains a
 director and officer liability insurance policy that may enable it
 to recover a portion of any future amounts paid under the
 indemnification agreements.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-18-255054:notes:162]
| 18. | Accumulated other comprehensive income (loss) |

[0001193125-18-255054:notes:163]
The changes in
 AOCI by component for the years ended June 29, 2018 and
 June 30, 2017 were as follows:

[0001193125-18-255054:notes:164]
| (amount in thousands) |  | Unrealized net (Losses)/Gains on Marketable Securities |  |  | Unrealized net (Losses)/Gains on Derivative Instruments |  |  | Foreign Currency Translation Adjustment |  |  | Total |  |
| Balance as of June 24, 2016 |  | $ | 399 |  |  | $ | 192 |  |  | $ | — |  |  | $ | 591 |  |
| Other comprehensive income before reclassification |  |  | 351 |  |  |  | — |  |  |  | (310 | ) |  |  | 41 |  |
| Amounts reclassified from AOCI |  |  | (822 | ) |  |  | (158 | ) |  |  | — |  |  |  | (980 | ) |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income |  |  | (471 | ) |  |  | (158 | ) |  |  | (310 | ) |  |  | (939 | ) |
| Balance as of June 30, 2017 |  |  | (72 | ) |  |  | 34 |  |  |  | (310 | ) |  |  | (348 | ) |
| Other comprehensive income before reclassification |  |  | (655 | ) |  |  | — |  |  |  | 111 |  |  |  | (544 | ) |
| Amounts reclassified from AOCI |  |  | (364 | ) |  |  | (1 | ) |  |  | — |  |  |  | (365 | ) |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income |  |  | (1,019 | ) |  |  | (1 | ) |  |  | 111 |  |  |  | (909 | ) |
| Balance as of June 29, 2018 |  | $ | (1,091 | ) |  | $ | 33 |  |  | $ | (199 | ) |  | $ | (1,257 | ) |

[0001193125-18-255054:notes:165]
The following
 table presents the pre-tax
 amounts reclassified from AOCI into the consolidated statements of
 operations and comprehensive income for the years ended
 June 29, 2018 and June 30, 2017, respectively (amounts in
 thousands).

[0001193125-18-255054:notes:166]
|  |  |  |  | Years ended |  |
| AOCI components |  | Financial statements line item |  | June 29, 2018 |  |  | June 30, 2017 |  |
| Unrealized losses on marketable securities |  | Interest income |  | $ | (364 | ) |  | $ | (822 | ) |
| Unrealized gains on derivative instruments |  | Selling, general and administrative expenses |  |  | (1 | ) |  |  | (158 | ) |
| Total amounts reclassified from AOCI |  |  |  | $ | (365 | ) |  | $ | (980 | ) |


## us-gaap:DebtDisclosureTextBlock

[0001193125-18-255054:notes:167]
13.
 Borrowings

[0001193125-18-255054:notes:168]
The
 Company’s total borrowings, including short-term and
 long-term borrowings, consisted of the following:

[0001193125-18-255054:notes:169]
(dollars in
 thousands)

[0001193125-18-255054:notes:170]
| Rate (1) |  | Conditions |  |  | Maturity |  |  | As of June 29, 2018 |  |  | As of June 30, 2017 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  |  | Repayable in 1 to 6 months |  |  |  | July 2017 | (2) |  | $ | — |  |  | $ | 34,000 |  |
| Short-term borrowings from bank: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank of England base rate +1.85% per annum |  |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  |  |  |  | — |  |  |  | 1,003 |  |
| Current portion of long-term borrowings |  |  |  |  |  |  |  |  |  |  | 3,250 |  |  |  | 13,600 |  |
|  |  |  |  |  |  |  |  |  |  |  | 3,250 |  |  |  | 48,603 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  |  |  |  |  | — |  |  |  | (201 | ) |
|  |  |  |  |  |  |  |  |  |  | $ | 3,250 |  |  | $ | 48,402 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  |  | Repayable in quarterly installments |  |  |  | May 2019 | (2) |  | $ | — |  |  | $ | 36,400 |  |
| LIBOR + 1.50% per annum |  |  | Repayable in quarterly installments |  |  |  | June 2023 | (2) |  |  | 64,188 |  |  |  | — |  |
|  |  |  |  |  |  |  |  |  |  |  | 64,188 |  |  |  | 36,400 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (3,250 | ) |  |  | (13,600 | ) |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  |  |  |  |  | — |  |  |  | (99 | ) |
| Non-current portion of long-term borrowings |  |  |  |  |  |  |  |  |  | $ | 60,938 |  |  | $ | 22,701 |  |

[0001193125-18-255054:notes:171]
|  | (1) | LIBOR is London Interbank Offered Rate. |

[0001193125-18-255054:notes:172]
|  | (2) | In June 2018, the outstanding revolving and term loan borrowings were refinanced to one term loan borrowing and the maturity dates were extended from July 2017 and May 2019 to June 2023. |

[0001193125-18-255054:notes:173]
The movements
 of long-term borrowings were as follows for the years ended
 June 29, 2018 and June 30, 2017:

[0001193125-18-255054:notes:174]
|  |  | Years ended |  |
| (amount in thousands) |  | June 29, 2018 |  |  | June 30, 2017 |  |
| Opening net book amount |  | $ | 36,400 |  |  | $ | 54,500 |  |
| Additional loan during the period |  |  | 39,000 |  |  |  | — |  |
| Repayment during the period |  |  | (11,212 | ) |  |  | (18,100 | ) |
| Closing net book amount |  | $ | 64,188 |  |  | $ | 36,400 |  |

[0001193125-18-255054:notes:175]
As of
 June 29, 2018, the future maturities of long-term borrowings
 during each fiscal year were as follows:

[0001193125-18-255054:notes:176]
| (amount in thousand) |  |  |  |
| 2019 |  | $ | 3,250 |  |
| 2020 |  |  | 3,250 |  |
| 2021 |  |  | 3,250 |  |
| 2022 |  |  | 3,250 |  |
| 2023 |  |  | 51,188 |  |
| Total |  | $ | 64,188 |  |

[0001193125-18-255054:notes:177]
Credit
 facilities:

[0001193125-18-255054:notes:178]
The Company
 entered into a syndicated senior credit facility agreement (the
 “Facility Agreement”) with a consortium of banks on
 May 22, 2014. The Facility Agreement, led by Bank of America,
 provided for a $200.0 million credit line, comprised of a
 $150.0 million revolving loan facility and a
 $50.0 million delayed draw term loan facility. The revolving
 loan facility contains an accordion feature permitting Fabrinet to
 request an increase in the facility up to $100.0 million
 subject to customary terms and conditions and provided that no
 default or event of default exists at the time of
 request.

[0001193125-18-255054:notes:179]
On
 February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. On
 July 22, 2016, the Company entered into the Fourth Amendment
 to the Facility Agreement to change the timing of filing certain
 financial information with the bank.

[0001193125-18-255054:notes:180]
The Company
 fully drew down the term loan facility of $50.0 million in
 fiscal year 2016. As of June 30, 2017, $34.0 million of
 revolving borrowing and $36.4 million of term loan borrowing
 was outstanding under the Facility Agreement. Borrowings under the
 revolving credit facility are classified as current liabilities in
 the audited consolidated balance sheet as the Company has the
 periodic option to renew or pay, all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent.

[0001193125-18-255054:notes:181]
Loans under the
 Facility Agreement bear interest, at Fabrinet’s option, at a
 rate per annum equal to a LIBOR rate plus a spread of 1.75% to
 2.50%, or a base rate, determined in accordance with the Facility
 Agreement, plus a spread of 0.75% to 1.50%, in each case with such
 spread determined based on Fabrinet’s consolidated total
 leverage ratio for the preceding four fiscal quarter period.
 Interest is due and payable quarterly in arrears for loans bearing
 interest at the base rate and at the end of an interest period (or
 at each three-month interval in the case of loans with interest
 periods greater than three months) in the case of loans bearing
 interest at the LIBOR rate.

[0001193125-18-255054:notes:182]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or
 the equivalent under the local law, can be effected.

[0001193125-18-255054:notes:183]
The Facility
 Agreement contains customary affirmative and negative covenants.
 Negative covenants include, among other things, limitations on
 liens, indebtedness, investments, mergers, sales of assets, changes
 in the nature of the business, dividends and distributions,
 affiliate transactions and capital expenditures. The Facility
 Agreement contains financial covenants requiring Fabrinet to
 maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage ratio
 of not more than 2.50:1.00; and (iv) a minimum quick ratio of
 not less than 1.10:1.00. Each of these financial covenants is
 calculated on a consolidated basis for the consecutive four fiscal
 quarter period then ended.

[0001193125-18-255054:notes:184]
The Facility
 Agreement also contains customary events of default including,
 among other things, payment defaults, breaches of covenants or
 representations and warranties, cross-defaults with certain other
 indebtedness, bankruptcy and insolvency events and change in
 control of Fabrinet, subject to grace periods in certain instances.
 Upon an event of default, the lenders may terminate their
 commitments, declare all or a portion of the outstanding
 obligations payable by Fabrinet to be immediately due and payable
 and exercise other rights and remedies provided for under the
 Facility Agreement.

[0001193125-18-255054:notes:185]
On June 4,
 2018, the Company entered into the Fifth Amendment to the Facility
 Agreement to (i) reduce the revolving commitments thereunder
 from $150.0 million to $25.0 million, (ii) extend
 the termination date of the revolving commitments from May 22,
 2019 to June 4, 2023, (iii) refinance the then-existing term
 loan and revolving loans under the Facility Agreement into a
 $65.0 million term loan and (iv) reduce the applicable
 interest rate margins and commitment fees. Term loans shall be
 repaid in quarterly installments, beginning on June 30, 2018,
 with the remaining outstanding principal and accrued and unpaid
 interest being due and payable on June 4, 2023. After giving
 effect to the amendment, $65.0 million aggregate principal
 amount of term loans and no revolving loans were outstanding under
 the Facility Agreement. In addition, the Fifth Amendment to the
 Facility Agreement contains an accordion feature permitting the
 Company to request an increase in the revolving loan facility to
 provide up to an aggregate of $200.0 million in additional
 commitments, subject to customary terms and conditions, and
 provided that no default or event of default exists at the time of
 such request. The Fifth Amendment is considered debt extinguishment
 of which the Company recognized interest expenses of
 $0.1 million from remaining unamortized debt issuance costs in
 consolidated statements of operations and comprehensive income. As
 of June 29, 2018, $64.2 million aggregate principal
 amount of term loans and no revolving loans were outstanding under
 the Facility Agreement.

[0001193125-18-255054:notes:186]
After the Fifth
 Amendment, loans under the Facility Agreement bear interest, at
 Fabrinet’s option, at a rate per annum equal to a LIBOR rate
 plus a spread of 1.50% to 2.25%, or a base rate plus a spread of
 0.50% to 1.25%, determined in accordance with the Facility
 Agreement in each case with such spread determined based on
 Fabrinet’s consolidated total leverage ratio for the
 preceding four fiscal quarter period.

[0001193125-18-255054:notes:187]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future material direct
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $20.0 million in a jurisdiction where a control agreement, or
 the equivalent under the local law, can be effected.

[0001193125-18-255054:notes:188]
Moreover, the
 Fifth Amendment of Facility Agreement amends customary affirmative
 and negative covenants. Negative covenants include, among other
 things, limitations on liens, indebtedness, investments, mergers,
 sales of assets, changes in the nature of the business, dividends
 and distributions, affiliate transactions and capital expenditures.
 The Facility Agreement contains financial covenants requiring
 Fabrinet to maintain: (1) a minimum tangible net worth of not
 less than $338.0 million plus 50% of quarterly net income
 after June 30, 2018, exclusive of quarterly losses; (2) a
 minimum debt service coverage ratio of not less than 1.50:1.00; (3)
 a maximum total leverage ratio of not more than 2.50:1.00; and
 (4) a minimum quick ratio of not less than 1.10:1.00. Each of
 these financial covenants is calculated on a consolidated basis for
 the consecutive four fiscal quarter period then ended. As of
 June 29, 2018, the Company was in compliance with all
 covenants under the Facility Agreement.

[0001193125-18-255054:notes:189]
Fabrinet
 intends to use the proceeds of the credit line to finance its
 future expansion in the United States and Thailand, and for general
 corporate purposes including mergers and acquisitions of
 complementary manufacturing businesses or technology, although
 Fabrinet has no current commitments with respect to any such
 acquisitions.

[0001193125-18-255054:notes:190]
On
 July 24, 2017, the Company entered into an interest rate swap
 agreement (the “Swap Agreement”), which the Company did
 not designate as hedging instruments. The Swap Agreement was used
 to mitigate interest rate risk and improve the interest rate
 profile of the Company’s debt obligations. The terms of the
 Swap Agreement effectively converted the floating interest rate of
 the term loans under the Facility Agreement to the fixed interest
 rate of 1.55% per annum through maturity of the term loan in May
 2019. On June 4, 2018, the Company terminated the Swap
 Agreement in connection with entering into the Fifth Amendment to
 the Facility Agreement. During the year ended June 29, 2018,
 the Company included a net gain of $0.1 million from the
 settlement of the Swap Agreement as interest expenses in the
 consolidated statements of operations and comprehensive
 income.

[0001193125-18-255054:notes:191]
Short-term borrowings from bank

[0001193125-18-255054:notes:192]
In connection
 with the acquisition of Fabrinet UK in the first quarter of fiscal
 year 2017, the Company assumed a secured borrowing agreement. In
 the first quarter of fiscal year 2018, the Company fully repaid
 these short-term loans and sent a notification letter to the bank
 to terminate this secured borrowing agreement. As a result, the
 bank released secured trade accounts receivable and the way
 chattels mortgage over the plant and machine of Fabrinet
 UK.

[0001193125-18-255054:notes:193]
Undrawn
 available credit facilities classified by available period of
 future borrowing as of June 29, 2018 and June 30, 2017
 were as follows:

[0001193125-18-255054:notes:194]
| (amount in thousands) |  | June 29, 2018 |  |  | June 30, 2017 |  |
| Expiring within one year |  | $ | — |  |  | $ | 1,965 |  |
| Expiring beyond one year |  | $ | 25,000 |  |  | $ | 116,000 |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-18-255054:notes:195]
| 4. | Earnings per ordinary share |

[0001193125-18-255054:notes:196]
Basic earnings
 per ordinary share is computed by dividing reported net income by
 the weighted average number of ordinary shares outstanding during
 each period. Diluted earnings per ordinary share is computed by
 calculating the effect of potential dilutive ordinary shares
 outstanding during the year using the treasury stock method.
 Dilutive ordinary equivalent shares consist of share options,
 restricted share units and performance share units. The earnings
 per ordinary share was calculated as follows:

[0001193125-18-255054:notes:197]
|  |  | Years Ended |  |
| (amount in thousands except per share amounts) |  | June 29, 2018 |  |  | June 30, 2017 |  |  | June 24, 2016 |  |
| Net income attributable to shareholders |  | $ | 84,167 |  |  | $ | 97,115 |  |  | $ | 61,897 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  | 37,257 |  |  |  | 36,927 |  |  |  | 35,857 |  |
| Incremental shares arising from the assumed exercise of share options and vesting of restricted share units and performance share units (thousands of shares) |  |  | 778 |  |  |  | 925 |  |  |  | 1,015 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 38,035 |  |  |  | 37,852 |  |  |  | 36,872 |  |
| Basic earnings per ordinary share |  | $ | 2.26 |  |  | $ | 2.63 |  |  | $ | 1.73 |  |
| Diluted earnings per ordinary share |  | $ | 2.21 |  |  | $ | 2.57 |  |  | $ | 1.68 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-18-255054:notes:198]
| 15. | Share-based compensation |

[0001193125-18-255054:notes:199]
In determining
 the grant date fair value of share option awards, the Company is
 required to make estimates of expected dividends to be issued,
 expected volatility of Fabrinet’s ordinary shares, expected
 forfeitures of the awards, risk free interest rates for the
 expected term of the awards and expected terms of the awards.
 Forfeitures are estimated at the time of grant and revised if
 necessary in subsequent periods if actual forfeitures differ from
 those estimates. The grant date fair value of restricted share
 units and performance share units is based on the market value of
 our ordinary shares on the date of grant.

[0001193125-18-255054:notes:200]
The effect of
 recording share-based compensation expense for the years ended
 June 29, 2018, June 30, 2017 and June 24, 2016 was
 as follows:

[0001193125-18-255054:notes:201]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 29, 2018 |  |  | June 30, 2017 |  |  | June 24, 2016 |  |
| Share-based compensation expense by type of award: |  |  |  |  |
| Share options |  | $ | — |  |  | $ | — |  |  | $ | 16 |  |
| Restricted share units |  |  | 17,143 |  |  |  | 22,412 |  |  |  | 9,911 |  |
| Performance share units |  |  | 5,438 |  |  |  | 4,095 |  |  |  | — |  |
| Total share-based compensation expense |  |  | 22,581 |  |  |  | 26,507 |  |  |  | 9,927 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 22,581 |  |  | $ | 26,507 |  |  | $ | 9,927 |  |

[0001193125-18-255054:notes:202]
Share-based
 compensation expense was recorded in the consolidated statements of
 operations and comprehensive income as follows:

[0001193125-18-255054:notes:203]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 29, 2018 |  |  | June 30, 2017 |  |  | June 24, 2016 |  |
| Cost of revenue |  | $ | 6,784 |  |  | $ | 5,318 |  |  | $ | 1,979 |  |
| Selling, general and administrative expense |  |  | 15,797 |  |  |  | 21,189 |  |  |  | 7,948 |  |
| Total share-based compensation expense |  | $ | 22,581 |  |  | $ | 26,507 |  |  | $ | 9,927 |  |

[0001193125-18-255054:notes:204]
The Company did
 not capitalize any share-based compensation expense as part of any
 asset costs during the years ended June 29, 2018,
 June 30, 2017 and June 24, 2016.

[0001193125-18-255054:notes:205]
Share-based award activity

[0001193125-18-255054:notes:206]
Fabrinet
 maintains the following equity incentive plans: the Amended and
 Restated 1999 Share Option Plan (the “1999 Plan”), the
 Amended and Restated 2010 Performance Incentive Plan (the
 “2010 Plan”) and the 2017 Inducement Equity Incentive
 Plan (the “2017 Inducement Plan”). The 1999 Plan, 2010
 Plan and 2017 Inducement Plan are collectively referred to as the
 “Share Option Plans”.

[0001193125-18-255054:notes:207]
As of
 June 29, 2018, there were no outstanding equity awards under
 the 1999 Plan, and no additional grants may be made under the 1999
 Plan.

[0001193125-18-255054:notes:208]
On
 December 14, 2017, Fabrinet’s shareholders adopted
 amendments to the 2010 Plan to increase the number of ordinary
 shares authorized for issuance under the 2010 Plan by 2,100,000
 shares. As of June 29, 2018, there were an aggregate of 2,900
 share options outstanding, 1,024,927 restricted share units
 outstanding and 508,586 performance share units outstanding under
 the 2010 Plan. As of June 29, 2018, there were 2,426,271
 ordinary shares available for future grant under the 2010
 Plan.

[0001193125-18-255054:notes:209]
On
 November 2, 2017, Fabrinet adopted the 2017 Inducement Plan
 with a reserve of 160,000 ordinary shares authorized for future
 issuance solely for the granting of inducement share options and
 equity awards to new employees. The 2017 Inducement Plan was
 adopted without shareholder approval in reliance on the
 “employment inducement exemption” provided under the
 New York Stock Exchange Listed Company Manual. As of June 29,
 2018, there were an aggregate of 48,653 restricted share units
 outstanding and 97,306 performance share units outstanding under
 the 2017 Inducement Plan. As of June 29, 2018, there were
 14,041 ordinary shares available for future grant under the 2017
 Inducement Plan.

[0001193125-18-255054:notes:210]
Share
 options

[0001193125-18-255054:notes:211]
Share options
 have been granted to directors and employees. Fabrinet’s
 board of directors has the authority to determine the type of
 option and the number of shares subject to an option. Options
 generally vest and become exercisable over four years and expire,
 if not exercised, within seven years of the grant date. In the case
 of a grantee’s first grant, 25 percent of the underlying
 shares vest 12 months after the vesting commencement date and 1/48
 of the underlying shares vest monthly over each of the subsequent
 36 months. In the case of any additional grants to a grantee,
 1/48 of the underlying shares vest monthly over four years,
 commencing one month after the vesting commencement
 date.

[0001193125-18-255054:notes:212]
The following
 table summarizes share option activity:

[0001193125-18-255054:notes:213]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 26, 2015 |  |  | 792,019 |  |  |  | 758,451 |  |  | $ | 16.33 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (325,530 | ) |  |  |  |  |  | $ | 16.83 |  |  |  |  |  |
| Forfeited |  |  | (755 | ) |  |  |  |  |  | $ | 17.10 |  |  |  |  |  |
| Expired |  |  | (1,400 | ) |  |  |  |  |  | $ | 23.62 |  |  |  |  |  |
| Balance as of June 24, 2016 |  |  | 464,334 |  |  |  | 464,334 |  |  | $ | 15.95 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (367,641 | ) |  |  |  |  |  | $ | 16.02 |  |  |  |  |  |
| Forfeited |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Expired |  |  | (5 | ) |  |  |  |  |  | $ | 5.75 |  |  |  |  |  |
| Balance as of June 30, 2017 |  |  | 96,688 |  |  |  | 96,688 |  |  | $ | 15.70 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (92,288 | ) |  |  |  |  |  | $ | 15.56 |  |  |  |  |  |
| Forfeited |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Expired |  |  | (1,500 | ) |  |  |  |  |  | $ | 25.50 |  |  |  |  |  |
| Balance as of June 29, 2018 |  |  | 2,900 |  |  |  | 2,900 |  |  | $ | 15.16 |  |  |  |  |  |
| Expected to vest as of June 29, 2018 |  |  | 2,900 |  |  |  |  |  |  | $ | 15.16 |  |  |  |  |  |

[0001193125-18-255054:notes:214]
The fair value
 of each share option grant was determined by the Company using the
 methods and assumptions discussed below. Each of these inputs is
 subjective and generally requires significant judgment and
 management estimate to determine.

[0001193125-18-255054:notes:215]
The total fair
 value of share options vested during the years ended June 29,
 2018, June 30, 2017 and June 24, 2016 was nil, nil and
 $0.2 million, respectively. The total intrinsic value of
 options exercised during the years ended June 29, 2018,
 June 30, 2017 and June 24, 2016 was $2.0 million,
 $8.9 million and $3.6 million, respectively. In
 conjunction with these exercises, there was no tax benefit realized
 by the Company due to the fact that it is exempted from income tax.
 The amount of cash received from the exercise of share options was
 $1.4 million during the year ended June 29,
 2018.

[0001193125-18-255054:notes:216]
Valuation
 Method—The Company estimated the fair value of the
 Company’s ordinary shares to be used in the BSM by taking
 into consideration a number of assumptions, as discussed
 below.

[0001193125-18-255054:notes:217]
Expected
 Dividend—The Company used zero as an annualized dividend
 yield since it did not anticipate paying any cash dividends in the
 near future.

[0001193125-18-255054:notes:218]
Expected
 Volatility – The Company determined the expected
 volatility based on the Company’s historical volatility over
 the last four years.

[0001193125-18-255054:notes:219]
Risk-Free
 Interest Rate—The Company based the risk-free interest
 rate on the implied yield currently available on U.S. Treasury
 zero-coupon issues with a
 remaining term equivalent to the expected term of the
 option.

[0001193125-18-255054:notes:220]
Expected
 Term—Expected terms used in the BSM represent the periods
 that the company’s share options are expected to be
 outstanding and are determined based on the Company’s
 historical experience of similar awards, giving consideration to
 the contractual terms of the share options, vesting schedules and
 expectations of future employee behavior.

[0001193125-18-255054:notes:221]
Vesting
 Period—Fabrinet’s share options generally vest and
 become exercisable over a four-year period, and expire seven years
 from the date of grant. For an initial grant, 25 percent of
 the underlying shares subject to an option vest 12 months after the
 vesting commencement date and 1/48 of the underlying shares vest
 monthly over each of the subsequent 36 months. In the case of any
 additional grants to an optionee, 1/48 of the underlying shares
 subject to an option vest monthly over four years, commencing one
 month after the vesting commencement date.

[0001193125-18-255054:notes:222]
Fair
 Value—The fair value of Fabrinet’s share options
 granted to employees was estimated using the weighted-average for
 each assumption of expected volatility, risk-free rate of return,
 and expected term.

[0001193125-18-255054:notes:223]
The following
 table summarizes information for share options outstanding as of
 June 29, 2018:

[0001193125-18-255054:notes:224]
|  |  | Number of Shares Underlying Options |  |  | Exercise Price Per Share |  |  | Weighted Average Remaining Contractual Life (years) |  |  | Aggregate Intrinsic Value (amount in thousands) |  |
|  |  |  | 2,900 |  |  | $ | 15.16 |  |  |  | 0.13 |  |  |  |  |  |
| Options outstanding |  |  | 2,900 |  |  |  |  |  |  |  | 0.13 |  |  | $ | 63 |  |
| Options exercisable |  |  | 2,900 |  |  |  |  |  |  |  | 0.13 |  |  | $ | 63 |  |
| Expected to vest as of June 29, 2018 |  |  | 2,900 |  |  |  |  |  |  |  | 0.13 |  |  | $ | 63 |  |

[0001193125-18-255054:notes:225]
As of
 June 29, 2018, there was no unrecognized compensation cost
 under the Share Option Plans.

[0001193125-18-255054:notes:226]
Restricted
 share units and performance share units

[0001193125-18-255054:notes:227]
Restricted
 share units and performance share units have been granted under the
 2010 Plan and the 2017 Inducement Plan.

[0001193125-18-255054:notes:228]
Restricted
 share units granted to employees generally vest in equal
 installments over three or four years on each anniversary of the
 vesting commencement date. Restricted share units granted to
 non-employee directors
 generally cliff vest 100% on the first of January, approximately
 one year from the grant date, provided the director continues to
 serve through such date.

[0001193125-18-255054:notes:229]
Performance
 share units granted to executives will vest at the end of a
 two-year performance
 period based on the Company’s achievement of pre-defined performance criteria,
 which consist of revenue and gross margin targets. The actual
 number of performance share units that may vest at the end of
 the performance period ranges from 0% to 100% of the award
 grant.

[0001193125-18-255054:notes:230]
The Company has
 entered into an employment agreement, as amended on August 12,
 2016, with one executive of the Company that provided for
 accelerated vesting of equity awards under certain circumstances.
 Pursuant to such agreement, because the executive’s
 employment with the Company continued through February 20,
 2017, (1) all outstanding equity awards granted to the executive
 prior to August 2016 became 100% vested on February 20, 2017
 and (2) certain restricted share units granted to the
 executive in August 2016 became 100% vested on February 20,
 2017.

[0001193125-18-255054:notes:231]
The following
 table summarizes restricted share unit activity under the 2010 Plan
 and 2017 Inducement Plan:

[0001193125-18-255054:notes:232]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 26, 2015 |  |  | 1,140,927 |  |  | $ | 16.03 |  |
| Granted |  |  | 654,589 |  |  | $ | 21.15 |  |
| Issued |  |  | (507,621 | ) |  | $ | 15.60 |  |
| Forfeited |  |  | (106,493 | ) |  | $ | 18.34 |  |
| Balance as of June 24, 2016 |  |  | 1,181,402 |  |  | $ | 18.34 |  |
| Granted |  |  | 861,356 |  |  | $ | 38.95 |  |
| Issued |  |  | (853,535 | ) |  | $ | 21.16 |  |
| Forfeited |  |  | (130,618 | ) |  | $ | 29.31 |  |
| Balance as of June 30, 2017 |  |  | 1,058,605 |  |  | $ | 31.59 |  |
| Granted |  |  | 552,637 |  |  | $ | 35.95 |  |
| Issued |  |  | (436,867 | ) |  | $ | 27.81 |  |
| Forfeited |  |  | (100,795 | ) |  | $ | 33.62 |  |
| Balance as of June 29, 2018 |  |  | 1,073,580 |  |  | $ | 35.19 |  |
| Expected to vest as of June 29, 2018 |  |  | 1,012,791 |  |  | $ | 34.87 |  |

[0001193125-18-255054:notes:233]
The following
 table summarizes performance share unit activity under the 2010
 Plan and 2017 Inducement Plan:

[0001193125-18-255054:notes:234]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 24, 2016 |  |  | — |  |  |  | — |  |
| Granted |  |  | 234,678 |  |  | $ | 40.48 |  |
| Issued |  |  | — |  |  |  | — |  |
| Forfeited |  |  | (7,410 | ) |  |  | — |  |
| Balance as of June 30, 2017 |  |  | 227,268 |  |  | $ | 40.48 |  |
| Granted |  |  | 378,624 |  |  | $ | 37.16 |  |
| Issued |  |  | — |  |  |  | — |  |
| Forfeited |  |  | — |  |  |  | — |  |
| Balance as of June 29, 2018 |  |  | 605,892 |  |  | $ | 38.41 |  |
| Expected to vest as of June 29, 2018 |  |  | 285,280 |  |  | $ | 33.98 |  |

[0001193125-18-255054:notes:235]
The fair value
 of restricted share units and performance share units is based on
 the market value of our ordinary shares on the date of
 grant.

[0001193125-18-255054:notes:236]
The total fair
 value of restricted share units and performance share units vested
 during the year ended June 29, 2018, June 30, 2017 and
 June 24, 2016 was $12.2 million, $18.1 million and
 $7.9 million, respectively. The aggregate intrinsic value of
 restricted share units outstanding as of June 29, 2018 was
 $39.6 million.

[0001193125-18-255054:notes:237]
As of
 June 29, 2018, there was $14.2 million and
 $1.0 million of unrecognized share-based compensation expense
 related to restricted share units and performance share units,
 respectively, under the 2010 Plan and the 2017 Inducement Plan that
 is expected to be recorded over a weighted-average period of 2.6
 years and 1.0 years, respectively.

[0001193125-18-255054:notes:238]
For the years
 ended June 29, 2018 and June 30, 2017, the Company
 withheld an aggregate of 145,918 shares and 37,126 shares,
 respectively, upon the vesting of restricted share units, based
 upon the closing share price on the vesting date to settle the
 employees’ minimum statutory obligation for the applicable
 income and other employment taxes. For fiscal year 2018 and fiscal
 year 2017, the Company then remitted cash of $5.5 million and
 $1.4 million, respectively, to the appropriate taxing
 authorities, and presented it as a financing activity within the
 consolidated statements of cash flows. The payment had the effect
 on shares issued by the Company as it reduced the number of shares
 that would have been issued on the vesting date and was recorded as
 a reduction of additional paid-in capital.


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001193125-18-255054:notes:239]
The following
 table provides details of the financial instruments measured at
 fair value on a recurring basis, including:

[0001193125-18-255054:notes:240]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 29, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 11,324 |  |  | $ | — |  |  | $ | 11,324 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 127,705 |  |  |  | — |  |  |  | 127,705 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 43,410 |  |  |  | — |  |  |  | 43,410 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 3,154 |  |  |  | — |  |  |  | 3,154 |  |
| Derivative assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | — |  |  | $ | 185,593 |  |  | $ | — |  |  | $ | 185,593 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 1,745 | (1) |  | $ | — |  |  | $ | 1,745 |  |
| Total |  | $ | — |  |  | $ | 1,745 |  |  | $ | — |  |  | $ | 1,745 |  |

[0001193125-18-255054:notes:241]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 30, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 2,585 |  |  | $ | — |  |  | $ | 2,585 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 98,274 |  |  |  | — |  |  |  | 98,274 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 50,666 |  |  |  | — |  |  |  | 50,666 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 2,510 |  |  |  | — |  |  |  | 2,510 |  |
| Derivative assets |  |  | — |  |  |  | 15 | (2) |  |  | — |  |  |  | 15 |  |
| Total |  | $ | — |  |  | $ | 154,050 |  |  | $ | — |  |  | $ | 154,050 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Total |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001193125-18-255054:notes:242]
| (1) | Foreign currency forward contracts with notional amount of $7.0 million and Canadian dollars 0.4 million. Foreign currency option contracts with notional amount of $30.0 million. |

[0001193125-18-255054:notes:243]
| (2) | Foreign currency forward contracts with notional amount of $1.0 million and Canadian dollars 0.6 million. |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-18-255054:notes:244]
| 6. | Fair Value |

[0001193125-18-255054:notes:245]
Derivative
 Financial Instruments

[0001193125-18-255054:notes:246]
As a result of
 foreign currency rate fluctuations, the U.S. dollar equivalent
 values of the Company’s foreign currency denominated assets
 and liabilities change. The Company uses foreign currency contracts
 to manage the foreign exchange risk associated with certain foreign
 currency denominated assets and liabilities and other foreign
 currency transactions. The Company minimizes the credit risk in
 derivative instruments by limiting its exposure to any single
 counterparty and by entering into derivative instruments only with
 counterparties that meet the Company’s minimum credit quality
 standard. As of June 29, 2018, the Company recognized the fair
 value of foreign currency forward contracts of $1.7 million as
 derivative liabilities in the consolidated balance sheets under
 other current liabilities. As of June 30, 2017, the Company
 recognized the fair value of foreign currency forward contracts of
 $0.02 million as derivative assets in the consolidated balance
 sheets under other current assets.

[0001193125-18-255054:notes:247]
As of
 June 29, 2018 and June 30, 2017, the Company had no
 foreign currency forward contracts designated as cash flow hedges.
 During the year ended June 30, 2017, the Company discontinued
 cash flow hedges and recognized a gain from unwinding foreign
 currency forward contracts of $0.3 million as foreign exchange
 gain, net in the consolidated statements of operations and
 comprehensive income.

[0001193125-18-255054:notes:248]
As of
 June 29, 2018, the Company had five outstanding foreign
 currency forward contracts with notional amount of
 $7.0 million, four outstanding foreign currency option
 contracts with notional amount of $30.0 million and one
 foreign currency forward contract with notional amount of Canadian
 dollars 0.4 million with maturity dates from July through
 October 2018. These foreign currency forward and option contracts
 were not designated for hedge accounting and were used to hedge
 fluctuations in the U.S. dollar value of forecasted transactions
 denominated in Thai baht and Canadian dollars. During the year
 ended June 29, 2018, the Company included unrealized loss of
 $1.7 million from changes in fair value of foreign currency
 contracts in earnings as foreign exchange loss, net in the
 consolidated statements of operations and comprehensive
 income.

[0001193125-18-255054:notes:249]
As of
 June 30, 2017, the Company had two outstanding foreign
 currency forward contracts with notional amount of
 $1.0 million and Canadian dollars 0.6 million, with
 maturity dates from July through September 2017. These foreign
 currency forward contracts were not designated for hedge accounting
 and were used to hedge fluctuations in the U.S. dollar value of
 forecasted transactions denominated in Thai baht and Canadian
 dollars. During the year ended June 30, 2017, the Company
 included unrealized gain of $0.02 million from changes in fair
 value of foreign currency contracts in the consolidated statements
 of operations and comprehensive income.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-18-255054:notes:250]
| 3. | Income taxes |

[0001193125-18-255054:notes:251]
Cayman
 Islands

[0001193125-18-255054:notes:252]
Fabrinet is
 domiciled in the Cayman Islands. Under the current laws of the
 Cayman Islands, Fabrinet is not subject to tax in the Cayman
 Islands on income or capital gains. Fabrinet has received this
 undertaking for a 20-year
 period ending August 24, 2019. As that date approaches,
 Fabrinet intends to request a renewal with the office of the Clerk
 of the Cabinet for another 20 years.

[0001193125-18-255054:notes:253]
Income of the
 Company exempted from corporate income tax in the Cayman Islands
 amounted to $58.4 million, $64.2 million and
 $41.0 million in the years ended June 29, 2018,
 June 30, 2017 and June 24, 2016, respectively.

[0001193125-18-255054:notes:254]
Thailand

[0001193125-18-255054:notes:255]
Fabrinet
 Thailand is where the majority of the Company’s operations
 and production takes place. The Company is not subject to tax from
 July 2012 through June 2020 on income generated from the
 manufacture of products at Pinehurst Building 6, and is not subject
 to tax from July 2018 through June 2026 on income generated from
 the manufacture of products at its Chonburi campus. Such
 preferential tax treatment is contingent on, among other things,
 the export of the Company’s customers’ products out of
 Thailand and the Company’s agreement not to move its
 manufacturing facilities out of its current province in Thailand
 for at least 15 years from the date on which preferential tax
 treatment was granted. In March 2016, the Thailand Revenue
 Department announced the permanent decrease of corporate income tax
 rates to 20% for tax periods beginning on or after January 1,
 2016. As a result, corporate income tax rates for Fabrinet Thailand
 are expected to remain at 20% from fiscal year 2017
 onwards.

[0001193125-18-255054:notes:256]
People’s Republic of China

[0001193125-18-255054:notes:257]
The corporate
 income tax rate for Casix is 25%.

[0001193125-18-255054:notes:258]
The United
 States

[0001193125-18-255054:notes:259]
The Tax Cuts
 and Jobs Act, or the Tax Reform Act, was enacted on
 December 22, 2017 and provides for significant changes to U.S.
 tax law. Among other provisions, the Tax Reform Act reduces the
 U.S. corporate income tax rate to 21% effective in 2018. Under the
 Tax Reform Act, our U.S. subsidiaries are subject to an average
 corporate income tax rate of 27.6% for fiscal year 2018. The
 subsidiaries’ corporate income tax rate will be 21% beginning
 in July 2018 for fiscal year 2019.

[0001193125-18-255054:notes:260]
The United
 Kingdom

[0001193125-18-255054:notes:261]
The corporate
 income tax rate for U.K. subsidiaries is 19%.

[0001193125-18-255054:notes:262]
The
 Company’s income tax expense consisted of the
 following:

[0001193125-18-255054:notes:263]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 29, 2018 |  |  | June 30, 2017 |  |  | June 24, 2016 |  |
| Current |  | $ | 5,457 |  |  | $ | 5,986 |  |  | $ | 5,053 |  |
| Deferred |  |  | (1,595 | ) |  |  | 756 |  |  |  | 1,282 |  |
| Total income tax expense |  | $ | 3,862 |  |  | $ | 6,742 |  |  | $ | 6,335 |  |

[0001193125-18-255054:notes:264]
The
 reconciliation between the Company’s taxes that would arise
 by applying the statutory tax rate of the country of the
 Company’s principal operations, Thailand, to the
 Company’s effective tax charge is shown below:

[0001193125-18-255054:notes:265]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 29, 2018 |  |  | June 30, 2017 |  |  | June 24, 2016 |  |
| Income before income taxes (1) |  | $ | 88,029 |  |  | $ | 103,857 |  |  | $ | 68,232 |  |
| Tax expense calculated at a statutory corporate income tax rate of 20% |  |  | 17,606 |  |  |  | 20,771 |  |  |  | 13,646 |  |
| Effect of income taxes from locations with tax rates different from Thailand |  |  | 2,657 |  |  |  | (48 | ) |  |  | (3,309 | ) |
| Income not subject to tax (2) |  |  | (12,824 | ) |  |  | (17,212 | ) |  |  | (10,493 | ) |
| Income tax on unremitted earnings |  |  | 1,007 |  |  |  | 798 |  |  |  | 527 |  |
| Effect of different tax rate in relation to deferred tax utilization |  |  | 423 |  |  |  | — |  |  |  | 894 |  |
| Effect of foreign exchange rate adjustment |  |  | (134 | ) |  |  | 667 |  |  |  | 375 |  |
| Tax rebate from research and development application |  |  | (454 | ) |  |  | (226 | ) |  |  | (145 | ) |
| Provision for uncertain income tax position |  |  | 277 |  |  |  | 260 |  |  |  | 214 |  |
| Utilization of loss carryforward |  |  | (3,224 | ) |  |  | — |  |  |  | — |  |
| (Reversal of) valuation allowance (3) |  |  | (1,587 | ) |  |  | 1,517 |  |  |  | 4,882 |  |
| Others |  |  | 115 |  |  |  | 215 |  |  |  | (256 | ) |
| Corporate income tax expense |  | $ | 3,862 |  |  | $ | 6,742 |  |  | $ | 6,335 |  |

[0001193125-18-255054:notes:266]
| (1) | Income before income taxes was mostly generated from domestic income in the Cayman Islands. |

[0001193125-18-255054:notes:267]
| (2) | Income not subject to tax relates to income earned in the Cayman Islands and income subject to an investment promotion privilege for Pinehurst Building 6. Income not subject to tax per ordinary share on a diluted basis was $0.34, $0.45, and $0.28 for the years ended June 29, 2018, June 30, 2017, and June 24, 2016, respectively. |

[0001193125-18-255054:notes:268]
| (3) | As of June 29, 2018, the Company reversed valuation allowances of deferred tax assets of $5.2 million. The reversal was affected by utilization of deferred tax assets from loss carryforward of $3.2 million and effect of different tax rate in relation to deferred tax utilization of $0.4 million which have been separately presented in another line items. |

[0001193125-18-255054:notes:269]
The
 Company’s deferred tax assets and deferred tax liabilities,
 net of valuation allowance, at each balance sheet date are as
 follows:

[0001193125-18-255054:notes:270]
|  |  | As of |  |
| (amount in thousands) |  | June 29, 2018 |  |  | June 30, 2017 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Depreciation |  | $ | 2,151 |  |  | $ | 1,674 |  |
| Severance liability |  |  | 1,518 |  |  |  | 1,127 |  |
| Reserves and allowance |  |  | 1,545 |  |  |  | 1,046 |  |
| Net operating loss carryforwards |  |  | 1,228 |  |  |  | 496 |  |
| Others |  |  | 277 |  |  |  | 10 |  |
| Total |  | $ | 6,719 |  |  | $ | 4,353 |  |

[0001193125-18-255054:notes:271]
|  |  | As of |  |
| (amount in thousands) |  | June 29, 2018 |  |  | June 30, 2017 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Temporary differences from intangibles and changes in the fair value of assets acquired |  | $ | (860 | ) |  | $ | (944 | ) |
| Deferred tax from unremitted earnings |  |  | (2,863 | ) |  |  | (2,485 | ) |
| Total |  |  | (3,723 | ) |  |  | (3,429 | ) |
| Net |  | $ | 2,996 |  |  | $ | 924 |  |

[0001193125-18-255054:notes:272]
As of
 June 30, 2017, the Company determined that it is more likely
 than not that deferred tax assets attributable to a subsidiary in
 the United States would not be realized, primarily due to
 uncertainties related to the subsidiary’s ability to utilize
 its net operating loss carryforwards before they expire.
 Accordingly, the Company established a valuation allowance for such
 deferred tax asset. During the year ended June 29, 2018, the
 subsidiary generated taxable income sufficient for the utilization
 of loss carryforwards due to better operating performance and
 effective control of operating expenses such that management
 determined that it is more likely than not that future taxable
 income would be sufficient to allow the benefit of the loss to be
 realized. Therefore, as of June 29, 2018, the Company
 partially set up the valuation allowance of deferred tax
 assets.

[0001193125-18-255054:notes:273]
The changes in
 the valuation allowances of deferred tax assets were as
 follows:

[0001193125-18-255054:notes:274]
| (amount in thousands) |  | Valuation allowances of deferred tax assets |  |
| Balance as of June 24, 2016 |  | $ | 4,882 |  |
| Additional |  |  | 1,517 |  |
| Balance as of June 30, 2017 |  |  | 6,399 |  |
| Reversal |  |  | (5,234 | ) |
| Balance as of June 29, 2018 |  | $ | 1,165 |  |

[0001193125-18-255054:notes:275]
The Tax Reform
 Act contains a number of provisions that may impact us in future
 years. Since the Tax Reform Act was recently finalized and ongoing
 guidance and accounting interpretation is expected over the next
 twelve months, the Company has made certain provisional accounting
 estimates, as permitted under Staff Accounting Bulletin
 No. 118, and continued to analyze its accounting policies in
 this area. The U.S. Treasury Department, the IRS, and other
 standard-setting bodies could interpret or issue guidance on how
 provisions of the Tax Reform Act will be applied or otherwise
 administered that is different from the Company’s
 interpretation.

[0001193125-18-255054:notes:276]
As the Company
 completes its analysis of the Tax Reform Act, collects and prepares
 necessary data, and interprets any additional guidance, it may make
 adjustments to provisional amounts that it has recorded that may be
 material in the period in which the adjustments are made. The final
 accounting analysis will occur no later than one year from the date
 the Tax Reform Act was enacted.

[0001193125-18-255054:notes:277]
Currently, the
 Company has completed its assessment of the impact from the Tax
 Reform Act. The Company applied the new corporate tax rate to
 compute its current income tax and remeasured its deferred tax
 assets and liabilities for all U.S. subsidiaries as of
 June 29, 2018 to reflect the lower rate expected to apply when
 these temporary differences are utilized. The remeasurement
 resulted in (1) a reduction in current income tax expenses of
 $0.1 million and (2) a reduction in deferred tax assets
 of $0.4 million.

[0001193125-18-255054:notes:278]
Income tax
 liabilities have not been established for withholding tax and other
 taxes that would be payable on the unremitted earnings of Fabrinet
 Thailand. Such amounts of Fabrinet Thailand are permanently
 reinvested; unremitted earnings for Fabrinet Thailand totaled
 $102.5 million and $97.3 million as of June 29, 2018
 and June 30, 2017, respectively. Unrecognized deferred tax
 liabilities for such unremitted earnings were $5.8 million and
 $5.2 million as of June 29, 2018 and June 30, 2017,
 respectively.

[0001193125-18-255054:notes:279]
Deferred tax
 liabilities of $1.0 million and $0.8 million have been
 established for withholding tax on the unremitted earnings of Casix
 for the year ended June 29, 2018 and June 30, 2017,
 respectively, which are included in non-current deferred tax liability in
 the consolidated balance sheets.

[0001193125-18-255054:notes:280]
Uncertain
 income tax positions

[0001193125-18-255054:notes:281]
Interest and
 penalties related to uncertain tax positions are recognized in
 income tax expense. The Company had approximately $0.9 million
 and $0.6 million of accrued interest and penalties related to
 uncertain tax positions on the consolidated balance sheets as of
 June 29, 2018 and June 30, 2017, respectively. The
 Company recorded interest and penalties of $0.3 million,
 $0.3 million and $0.2 million for the years ended
 June 29, 2018, June 30, 2017 and June 24, 2016,
 respectively, in the consolidated statements of operations and
 comprehensive income. With regard to the Thailand jurisdiction, tax
 years 2013 through 2017 remain open to examination by the local
 authorities.

[0001193125-18-255054:notes:282]
The following
 table indicates the changes to the Company’s uncertain income
 tax positions for the years ended June 29, 2018, June 30,
 2017 and June 24, 2016 included in other non-current liabilities.

[0001193125-18-255054:notes:283]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 29, 2018 |  |  | June 30, 2017 |  |  | June 24, 2016 |  |
| Beginning balance |  | $ | 1,420 |  |  | $ | 1,420 |  |  | $ | 1,420 |  |
| Additions during the year |  |  | 25 |  |  |  | — |  |  |  | — |  |
| Reductions for tax positions of prior years |  |  | — |  |  |  | — |  |  |  | — |  |
| Ending balance |  | $ | 1,445 |  |  | $ | 1,420 |  |  | $ | 1,420 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-18-255054:notes:284]
| 12. | Goodwill |

[0001193125-18-255054:notes:285]
In connection
 with the acquisition of Fabrinet UK, the Company recorded
 $3.8 million of goodwill in the consolidated balance
 sheets.

[0001193125-18-255054:notes:286]
|  | The | changes in the carrying amount of goodwill were as follows: |

[0001193125-18-255054:notes:287]
| (amount in thousands) |  | Goodwill |  |
| Balance as of June 30, 2017 |  | $ | 3,806 |  |
| Foreign currency translation adjustment |  |  | 22 |  |
| Balance as of June 29, 2018 |  | $ | 3,828 |  |

[0001193125-18-255054:notes:288]
Goodwill is not
 deductible for tax purposes. Goodwill is reviewed annually for
 impairment or more frequently whenever changes or circumstances
 indicate the carrying amount of goodwill may not be recoverable. As
 of June 29, 2018, the Company performed the annual impairment
 test for goodwill, which indicated there was no goodwill
 impairment.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-18-255054:notes:289]
| 21. | Financial instruments |

[0001193125-18-255054:notes:290]
Objectives and significant terms and
 conditions

[0001193125-18-255054:notes:291]
The principal
 financial risks faced by the Company are foreign currency risk and
 interest rate risk. The Company borrows at floating rates of
 interest to finance its operations. A minority of sales and
 purchases and a majority of labor and overhead costs are entered
 into in foreign currencies. In order to manage the risks arising
 from fluctuations in currency exchange rates, the Company uses
 derivative instruments. Trading for speculative purposes is
 prohibited under Company policies.

[0001193125-18-255054:notes:292]
The Company
 enters into short-term foreign currency forward and option
 contracts to manage foreign currency exposures associated with
 certain assets, liabilities and other forecasted foreign currency
 transactions and may designate these instruments as hedging
 instruments. The foreign currency forward and option contracts
 generally have maturity of up to six months. All foreign currency
 exchange contracts are recognized on the consolidated balance
 sheets at fair value. Gain or loss on the Company’s
 derivative instruments generally offset the assets, liabilities and
 transactions economically hedged.

[0001193125-18-255054:notes:293]
Foreign
 currency risk

[0001193125-18-255054:notes:294]
The Company
 operates internationally and is exposed to foreign exchange risk
 arising from various currency exposures primarily with respect to
 the Thai baht, Chinese Renminbi (“RMB”) and
 GBP.

[0001193125-18-255054:notes:295]
As of
 June 29, 2018 and June 30, 2017, the Company had
 outstanding foreign currency assets and liabilities as
 follows:

[0001193125-18-255054:notes:296]
|  |  | As of June 29, 2018 |  |  | As of June 30, 2017 |  |
| (amount in thousands) |  | Currency |  |  | $ |  |  | Currency |  |  | $ |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 980,778 |  |  | $ | 29,568 |  |  |  | 395,123 |  |  | $ | 11,628 |  |
| RMB |  |  | 18,455 |  |  |  | 2,789 |  |  |  | 26,965 |  |  |  | 3,980 |  |
| GBP |  |  | 12,514 |  |  |  | 16,392 |  |  |  | 6,896 |  |  |  | 8,982 |  |
| Total |  |  |  |  |  | $ | 48,749 |  |  |  |  |  |  | $ | 24,590 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,401,473 |  |  | $ | 42,251 |  |  |  | 1,875,338 |  |  | $ | 55,189 |  |
| RMB |  |  | 19,893 |  |  |  | 3,007 |  |  |  | 28,451 |  |  |  | 4,200 |  |
| GBP |  |  | 3,615 |  |  |  | 4,735 |  |  |  | 5,625 |  |  |  | 7,326 |  |
| Total |  |  |  |  |  | $ | 49,993 |  |  |  |  |  |  | $ | 66,715 |  |

[0001193125-18-255054:notes:297]
The Thai baht
 assets represent cash and cash equivalents, trade accounts
 receivable, deposits and other current assets. The Thai baht
 liabilities represent trade accounts payable, accrued expenses,
 income tax payable and other payables. The Company manages its
 exposure to fluctuations in foreign exchange rates by the use of
 foreign currency contracts and offsetting assets and liabilities
 denominated in the same currency in accordance with
 management’s policy. As of June 29, 2018 there were
 $7.0 million of foreign currency forward contracts and
 $30.0 million of foreign currency option contracts outstanding
 on the Thai baht payables. As of June 30, 2017, there was
 $1.0 million in foreign currency forward contracts outstanding
 on the Thai baht payables.

[0001193125-18-255054:notes:298]
The RMB assets
 represent cash and cash equivalents, trade accounts receivable and
 other current assets. The RMB liabilities represent trade accounts
 payable, accrued expenses and other payables. As of June 29,
 2018 and June 30, 2017, there were no derivative contracts
 denominated in RMB.

[0001193125-18-255054:notes:299]
The GBP assets
 primarily represent cash, trade accounts receivable, inventory and
 property, plant and equipment. The GBP liabilities primarily
 represent trade accounts payable. As of June 29, 2018, there
 were no derivative contracts denominated in GBP.

[0001193125-18-255054:notes:300]
For fiscal year
 2018, fiscal year 2017, and fiscal year 2016, the Company recorded
 unrealized loss of $1.7 million, unrealized gain of
 $0.02 million, and unrealized loss of $1.8 million,
 respectively, related to derivatives that are not designated as
 hedging instruments in its consolidated statements of operations
 and comprehensive income.

[0001193125-18-255054:notes:301]
Interest
 Rate Risk

[0001193125-18-255054:notes:302]
The
 Company’s principal interest bearing assets are time deposits
 and short-term investments with maturities of three months or less
 held with high quality financial institutions. The Company’s
 principal interest bearing liabilities are bank loans which bear
 interest at floating rates.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001193125-18-255054:notes:303]
| 7. | Trade accounts receivable, net |

[0001193125-18-255054:notes:304]
| (amount in thousands) |  | As of June 29, 2018 |  |  | As of June 30, 2017 |  |
| Trade accounts receivable |  | $ | 246,972 |  |  | $ | 264,389 |  |
| Less: Allowance for doubtful account |  |  | (60 | ) |  |  | (40 | ) |
| Trade accounts receivable, net |  | $ | 246,912 |  |  | $ | 264,349 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-18-255054:notes:305]
| 8. | Inventory |

[0001193125-18-255054:notes:306]
| (amount in thousands) |  | As of June 29, 2018 |  |  | As of June 30, 2017 |  |
| Raw materials |  | $ | 100,241 |  |  | $ | 88,640 |  |
| Work in progress |  |  | 121,797 |  |  |  | 105,732 |  |
| Finished goods |  |  | 20,690 |  |  |  | 33,998 |  |
| Goods in transit |  |  | 17,516 |  |  |  | 13,025 |  |
|  |  |  | 260,244 |  |  |  | 241,395 |  |
| Less: Inventory obsolescence |  |  | (2,557 | ) |  |  | (2,730 | ) |
| Inventory, net |  | $ | 257,687 |  |  | $ | 238,665 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-18-255054:notes:307]
| 11. | Intangibles |

[0001193125-18-255054:notes:308]
The following
 tables present details of the Company’s
 intangibles:

[0001193125-18-255054:notes:309]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net |  |
| As of June 29, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 6,269 |  |  | $ | (4,324 | ) |  | $ | — |  |  | $ | 1,945 |  |
| Customer relationships |  |  | 4,373 |  |  |  | (1,413 | ) |  |  | (42 | ) |  |  | 2,918 |  |
| Backlog |  |  | 119 |  |  |  | (101 | ) |  |  | (1 | ) |  |  | 17 |  |
| Total intangibles |  | $ | 10,761 |  |  | $ | (5,838 | ) |  | $ | (43 | ) |  | $ | 4,880 |  |

[0001193125-18-255054:notes:310]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net |  |
| As of June 30, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 5,944 |  |  | $ | (3,850 | ) |  | $ | — |  |  | $ | 2,094 |  |
| Customer relationships |  |  | 4,373 |  |  |  | (606 | ) |  |  | (88 | ) |  |  | 3,679 |  |
| Backlog |  |  | 119 |  |  |  | (51 | ) |  |  | (1 | ) |  |  | 67 |  |
| Total intangibles |  | $ | 10,436 |  |  | $ | (4,507 | ) |  | $ | (89 | ) |  | $ | 5,840 |  |

[0001193125-18-255054:notes:311]
In connection
 with the acquisition of Fabrinet UK, the Company recorded
 $4.4 million of customer relationships and $0.1 million
 of backlog in the consolidated balance sheets. As of June 29,
 2018, the weighted-average remaining life of customer relationships
 and backlog was 6.1 years and 0.9 years, respectively. As of
 June 30, 2017, the weighted-average remaining life of customer
 relationships and backlog was 6.9 years and 1.6 years,
 respectively.

[0001193125-18-255054:notes:312]
The Company
 recorded amortization expense relating to intangibles of
 $1.7 million, $1.2 million and $0.1 million for the
 years ended June 29, 2018, June 30, 2017 and
 June 24, 2016, respectively.

[0001193125-18-255054:notes:313]
As of
 June 29, 2018, the estimated future amortization of intangible
 assets during each fiscal year was as follows:

[0001193125-18-255054:notes:314]
| (amount in thousand) |  |  |  |
| 2019 |  | $ | 1,462 |  |
| 2020 |  |  | 1,038 |  |
| 2021 |  |  | 892 |  |
| 2022 |  |  | 657 |  |
| 2023 |  |  | 400 |  |
| Thereafter |  |  | 431 |  |
| Total |  | $ | 4,880 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-18-255054:notes:315]
| 16. | Employee benefit plans |

[0001193125-18-255054:notes:316]
Employee
 contribution plan

[0001193125-18-255054:notes:317]
The Company
 operates a defined contribution plan, known as a provident fund, in
 its subsidiaries in Thailand and the United Kingdom. The assets of
 these plans are in separate trustee-administered funds. The
 provident fund is funded by matching payments from employees and by
 the subsidiaries on a monthly basis. Current contributions to the
 provident fund are accrued and paid to the fund manager on a
 monthly basis. The Company’s contributions to the provident
 fund amounted to $4.2 million, $3.6 million and
 $2.8 million during the years ended June 29, 2018,
 June 30, 2017 and June 24, 2016, respectively.

[0001193125-18-255054:notes:318]
The Company
 sponsors the Fabrinet U.S. 401(k) Retirement Plan (“401(k)
 Plan”), a Defined Contribution Plan under ERISA, at its
 subsidiaries in the United States which provides retirement
 benefits for eligible employees through tax deferred salary
 deductions. The 401(k) Plan allows employees to contribute up
 to 80% of their annual compensation, subject to annual
 contributions limits established by the Internal Revenue Service.
 The Company provides for a 100% match of employees’
 contributions to the 401(k) Plan up to the first 6% of annual
 compensation. All matching contributions are made in cash and vest
 immediately. The Company’s matching contributions to the
 401(k) Plan were $0.7 million, $0.6 million and
 $0.5 million during the years ended June 29, 2018,
 June 30, 2017 and June 24, 2016, respectively.

[0001193125-18-255054:notes:319]
Executive
 incentive plan and employee performance bonuses

[0001193125-18-255054:notes:320]
For the years
 ended June 29, 2018 and June 30, 2017, the Company
 maintained an executive incentive plan with quantitative
 objectives, based on achieving certain revenue and non-GAAP gross margin targets. For the
 year ended June 24, 2016, the Company maintained an executive
 incentive plan with quantitative objectives, based on achieving
 certain revenue and non-GAAP earnings per share targets as
 well as qualitative objectives, based on achieving individual
 performance goals. During the years ended June 29, 2018,
 June 30, 2017 and June 24, 2016, discretionary
 merit-based bonus awards were also available to Fabrinet’s
 non-executive
 employees.

[0001193125-18-255054:notes:321]
Bonus
 distributions to employees were $4.0 million,
 $7.6 million and $7.5 million for the years ended
 June 29, 2018, June 30, 2017 and June 24, 2016,
 respectively.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001193125-18-255054:notes:322]
UNAUDITED
 QUARTERLY FINANCIAL INFORMATION

[0001193125-18-255054:notes:323]
The following
 table sets forth a summary of the Company’s quarterly
 financial information for each of the four quarters in the fiscal
 years ended June 29, 2018 and June 30, 2017:

[0001193125-18-255054:notes:324]
|  |  | Three Months Ended |  |
| (in thousands, except per share data) |  | Jun 29, 2018 |  |  | Mar 30, 2018 |  |  | Dec 29, 2017 |  |  | Sep 29, 2017 |  |  | Jun 30, 2017 |  |  | Mar 31, 2017 |  |  | Dec 30, 2016 |  |  | Sep 30, 2016 |  |
| Total revenues |  | $ | 345,327 |  |  | $ | 332,313 |  |  | $ | 337,072 |  |  | $ | 357,313 |  |  | $ | 370,454 |  |  | $ | 366,837 |  |  | $ | 351,156 |  |  | $ | 332,043 |  |
| Gross profit |  | $ | 38,981 |  |  | $ | 36,933 |  |  | $ | 37,166 |  |  | $ | 40,332 |  |  | $ | 44,760 |  |  | $ | 44,046 |  |  | $ | 43,046 |  |  | $ | 39,608 |  |
| Net income |  | $ | 22,768 |  |  | $ | 21,053 |  |  | $ | 19,313 |  |  | $ | 21,033 |  |  | $ | 27,401 |  |  | $ | 21,656 |  |  | $ | 25,292 |  |  | $ | 22,766 |  |
| Basic net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 0.62 |  |  | $ | 0.56 |  |  | $ | 0.52 |  |  | $ | 0.56 |  |  | $ | 0.73 |  |  | $ | 0.58 |  |  | $ | 0.69 |  |  | $ | 0.63 |  |
| Weighted-average shares used in basic net income per share calculations |  |  | 36,828 |  |  |  | 37,275 |  |  |  | 37,477 |  |  |  | 37,447 |  |  |  | 37,334 |  |  |  | 37,116 |  |  |  | 36,848 |  |  |  | 36,404 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 0.60 |  |  | $ | 0.55 |  |  | $ | 0.51 |  |  | $ | 0.55 |  |  | $ | 0.72 |  |  | $ | 0.57 |  |  | $ | 0.67 |  |  | $ | 0.61 |  |
| Weighted-average shares used in diluted net income per share calculations |  |  | 37,766 |  |  |  | 38,055 |  |  |  | 38,156 |  |  |  | 38,163 |  |  |  | 38,118 |  |  |  | 37,872 |  |  |  | 37,805 |  |  |  | 37,330 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001193125-18-255054:notes:325]
| 10. | Property, plant and equipment, net |

[0001193125-18-255054:notes:326]
The components
 of property, plant and equipment, net were as follows:

[0001193125-18-255054:notes:327]
| (amount in thousands) |  | Land and Land Improvements |  |  | Building and Building Improvements |  |  | Manufacturing Equipment |  |  | Office Equipment |  |  | Motor Vehicles |  |  | Computers |  |  | Construction and Machinery Under Installation |  |  | Total |  |
| As of June 29, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost |  | $ | 45,080 |  |  | $ | 139,342 |  |  | $ | 141,869 |  |  | $ | 7,582 |  |  | $ | 456 |  |  | $ | 21,250 |  |  | $ | 8,762 |  |  | $ | 364,341 |  |
| Less: Accumulated depreciation |  |  | (6 | ) |  |  | (38,265 | ) |  |  | (86,989 | ) |  |  | (4,454 | ) |  |  | (334 | ) |  |  | (14,653 | ) |  |  | — |  |  |  | (144,701 | ) |
| Net book value |  | $ | 45,074 |  |  | $ | 101,077 |  |  | $ | 54,880 |  |  | $ | 3,128 |  |  | $ | 122 |  |  | $ | 6,597 |  |  | $ | 8,762 |  |  | $ | 219,640 |  |
| As of June 30, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost |  | $ | 39,096 |  |  | $ | 138,578 |  |  | $ | 127,085 |  |  | $ | 7,688 |  |  | $ | 534 |  |  | $ | 19,642 |  |  | $ | 6,058 |  |  | $ | 338,681 |  |
| Less: Accumulated depreciation |  |  | (2 | ) |  |  | (31,881 | ) |  |  | (72,130 | ) |  |  | (4,163 | ) |  |  | (376 | ) |  |  | (13,248 | ) |  |  | — |  |  |  | (121,800 | ) |
| Net book value |  | $ | 39,094 |  |  | $ | 106,697 |  |  | $ | 54,955 |  |  | $ | 3,525 |  |  | $ | 158 |  |  | $ | 6,394 |  |  | $ | 6,058 |  |  | $ | 216,881 |  |

[0001193125-18-255054:notes:328]
On
 December 23, 2016, the Company entered into an agreement to
 purchase a parcel of land in Chonburi, Thailand to support the
 expansion of the Company’s production in Thailand. The
 aggregate purchase price was approximately $5.6 million, of
 which the first installment of $1.1 million was paid by the
 Company on January 10, 2017 and the remaining balance of the
 purchase price was fully paid on December 25, 2017.

[0001193125-18-255054:notes:329]
Leased assets
 included above comprise certain machine and equipment from capital
 lease agreements assumed from the acquisition of Fabrinet
 UK.

[0001193125-18-255054:notes:330]
| (amount in thousands) |  | As of June 29, 2018 |  |  | As of June 30, 2017 |  |
| Cost—Capital leases |  | $ | 2,481 |  |  |  | 2,725 |  |
| Less: Accumulated depreciation |  |  | (1,043 | ) |  |  | (856 | ) |
| Net book value |  | $ | 1,438 |  |  |  | 1,869 |  |

[0001193125-18-255054:notes:331]
Depreciation
 expense amounted to $27.4 million, $22.5 million and
 $17.3 million for the years ended June 29, 2018,
 June 30, 2017 and June 24, 2016, respectively, and has
 been allocated between cost of revenues and selling, general and
 administrative expenses in the consolidated statements of
 operations and comprehensive income.

[0001193125-18-255054:notes:332]
The cost of
 fully depreciated property, plant and equipment written-off during the years ended
 June 29, 2018, June 30, 2017 and June 24, 2016
 amounted to $3.5 million, $5.4 million and
 $2.0 million, respectively.

[0001193125-18-255054:notes:333]
During the year
 ended June 29, 2018, the Company had no borrowing costs
 capitalized. During the year ended June 30, 2017, the Company
 capitalized $0.5 million of borrowing costs in construction in
 progress of its new manufacturing building at Chonburi Campus. The
 Company stopped capitalizing borrowing costs in the third quarter
 of fiscal year 2017 upon the completion of this campus.


## us-gaap:ScheduleOfAssumptionsUsedTableTextBlock

[0001193125-18-255054:notes:334]
The principal
 actuarial assumptions used were as follows:

[0001193125-18-255054:notes:335]
|  |  | Years Ended |  |
|  |  | June 29, 2018 |  | June 30, 2017 |  |  | June 24, 2016 |  |
| Discount rate |  | 2.5% - 3.7% |  |  | 1.93% - 3.6% |  |  |  | 2.0% - 3.2% |  |
| Future salary increases |  | 3.5% - 10.0% |  |  | 3.5% - 10.0% |  |  |  | 4.1% - 10.0% |  |


## us-gaap:ScheduleOfDefinedBenefitPlansDisclosuresTextBlock

[0001193125-18-255054:notes:336]
The following
 table provides information regarding severance
 liabilities:

[0001193125-18-255054:notes:337]
| (amount in thousands) |  | As of June 29, 2018 |  |  | As of June 30, 2017 |  |
| Balance, beginning of the fiscal year |  | $ | 8,488 |  |  | $ | 6,684 |  |
| Charged to selling, general and administrative expenses in the consolidated statements of operations and comprehensive income |  |  | 1,674 |  |  |  | 1,804 |  |
| Balance, end of the fiscal year |  | $ | 10,162 |  |  | $ | 8,488 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001193125-18-255054:notes:338]
Total revenues,
 by percentage, from individual customers representing 10% or more
 of total revenues in the respective periods were as
 follows:

[0001193125-18-255054:notes:339]
|  |  | Years Ended |  |
|  |  | June 29, 2018 |  |  | June 30, 2017 |  |  | June 24, 2016 |  |
| Lumentum Operations LLC |  |  | 16 | % |  |  | 17 | % |  |  | 20 | % |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-18-255054:notes:340]
The Company
 operates primarily in three geographic regions: North America,
 Asia-Pacific and Europe. The following table presents total
 revenues by geographic regions:

[0001193125-18-255054:notes:341]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 29, 2018 |  |  | June 30, 2017 |  |  | June 24, 2016 |  |
| North America |  | $ | 643,236 |  |  | $ | 661,267 |  |  | $ | 525,161 |  |
| Asia-Pacific |  |  | 519,203 |  |  |  | 539,317 |  |  |  | 351,033 |  |
| Europe |  |  | 209,486 |  |  |  | 219,906 |  |  |  | 100,553 |  |
| Total |  | $ | 1,371,925 |  |  | $ | 1,420,490 |  |  | $ | 976,747 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001193125-18-255054:notes:342]
The following
 table presents revenues by end market:

[0001193125-18-255054:notes:343]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 29, 2018 |  |  | June 30, 2017 |  |  | June 24, 2016 |  |
| Optical communications |  | $ | 1,000,256 |  |  | $ | 1,108,637 |  |  | $ | 727,580 |  |
| Lasers, sensors, and other |  |  | 371,669 |  |  |  | 311,853 |  |  |  | 249,167 |  |
| Total |  | $ | 1,371,925 |  |  | $ | 1,420,490 |  |  | $ | 976,747 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-18-255054:notes:344]
| 20. | Business segments and geographic information |

[0001193125-18-255054:notes:345]
Operating
 segments are defined as components of an enterprise for which
 separate financial information is available that is evaluated
 regularly by the chief operating decision maker in deciding how to
 allocate resources and in assessing performance. The
 Company’s chief operating decision maker is Fabrinet’s
 chief executive officer. As of June 29, 2018, June 30,
 2017 and June 24, 2016, the Company operated and internally
 managed a single operating segment. Accordingly, the Company does
 not accumulate discrete information with respect to separate
 product lines and does not have separate reportable
 segments.

[0001193125-18-255054:notes:346]
Total revenues
 are attributed to a particular geographic area based on the
 bill-to-location of the
 customer. The Company operates primarily in three geographic
 regions: North America, Asia-Pacific and Europe. The following
 table presents total revenues by geographic regions:

[0001193125-18-255054:notes:347]
As of
 June 29, 2018 and June 30, 2017, the Company had
 approximately $33.2 million and $34.9 million,
 respectively, of long-lived assets based in North America, with the
 substantial remainder of assets based in Asia-Pacific.

[0001193125-18-255054:notes:348]
Significant customers

[0001193125-18-255054:notes:349]
Accounts
 receivable from individual customers representing 10% or more of
 accounts receivable as of June 29, 2018 and June 30,
 2017, respectively, were as follows:

[0001193125-18-255054:notes:350]
|  |  | As of June 29, 2018 |  |  | As of June 30, 2017 |  |
| Lumentum Operations LLC |  |  | 18 | % |  |  | 15 | % |
| NeoPhotonics Corporation |  |  | 11 | % |  |  | 12 | % |
| Acacia Communications Inc. |  |  | * |  |  |  | 10 | % |

[0001193125-18-255054:notes:351]
|  | * | Represents less than 10% of total accounts receivable. |


## us-gaap:ScheduleOfAmountsRecognizedInBalanceSheetTableTextBlock

[0001193125-18-255054:notes:352]
The amount
 recognized in the consolidated balance sheets under non-current liabilities was determined
 as follows:

[0001193125-18-255054:notes:353]
| (amount in thousands) |  | As of June 29, 2018 |  |  | As of June 30, 2017 |  |
| Present value of defined benefit obligation |  | $ | 10,162 |  |  | $ | 8,488 |  |
| Total |  | $ | 10,162 |  |  | $ | 8,488 |  |


## us-gaap:SubsequentEventsTextBlock

[0001193125-18-255054:notes:354]
| 22. | Subsequent event |

[0001193125-18-255054:notes:355]
On
 August 1, 2018, a new subsidiary in Singapore, Casix Pte Ltd.
 was set up. The new subsidiary will support the reorganization of
 the Casix sales and marketing structure to improve the operating
 and tax efficiency.


## us-gaap:ScheduleOfNetBenefitCostsTableTextBlock

[0001193125-18-255054:notes:356]
The amount
 recognized in the consolidated statements of operations and
 comprehensive income was as follows:

[0001193125-18-255054:notes:357]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 29, 2018 |  |  | June 30, 2017 |  |  | June 24, 2016 |  |
| Current service cost |  | $ | 1,751 |  |  | $ | 1,451 |  |  | $ | 842 |  |
| Interest cost |  |  | 295 |  |  |  | 213 |  |  |  | 203 |  |
| Benefit paid |  |  | (3,212 | ) |  |  | — |  |  |  | (11 | ) |
| Curtailment gain |  |  | 707 |  |  |  | — |  |  |  | — |  |
| Actuarial loss on obligation |  |  | 2,133 |  |  |  | 140 |  |  |  | 173 |  |
| Total |  | $ | 1,674 |  |  | $ | 1,804 |  |  | $ | 1,207 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-18-255054:notes:358]
| 17. | Shareholders’ equity |

[0001193125-18-255054:notes:359]
Fabrinet’s
 authorized share capital is 500,000,000 ordinary shares, par value
 of $0.01 per ordinary share, and 5,000,000 preferred shares, par
 value of $0.01 per preferred share.

[0001193125-18-255054:notes:360]
For the year
 ended June 29, 2018, Fabrinet issued 92,288 ordinary shares
 upon the exercise of options, for cash consideration at a weighted
 average exercise price of $15.56 per share, and 290,949 ordinary
 shares upon the vesting of restricted share units, net of shares
 withheld.

[0001193125-18-255054:notes:361]
For the year
 ended June 30, 2017, Fabrinet issued 367,641 ordinary shares
 upon the exercise of options, for cash consideration at a weighted
 average exercise price of $16.02 per share, and 816,409 ordinary
 shares upon the vesting of restricted share units, net of shares
 withheld.

[0001193125-18-255054:notes:362]
For the year
 ended June 24, 2016, Fabrinet issued 325,530 ordinary shares
 upon the exercise of options, for cash consideration at a weighted
 average exercise price of $16.83 per share, and 393,262 ordinary
 shares upon the vesting of restricted share units, net of shares
 withheld.

[0001193125-18-255054:notes:363]
All such issued
 shares are fully paid.

[0001193125-18-255054:notes:364]
Treasury
 shares

[0001193125-18-255054:notes:365]
In August 2017,
 the Company’s board of directors approved a share repurchase
 program to permit the Company to repurchase up to
 $30.0 million worth of its issued and outstanding ordinary
 shares in the open market in accordance with applicable rules and
 regulations. In February 2018, the Company’s board of
 directors approved a $30.0 million increase to the share
 repurchase authorization. During the year ended June 29, 2018,
 1,289,103 shares were repurchased under the program, at an average
 price per share of $32.89 totaling $42.4 million. As of
 June 29, 2018, the Company had a remaining authorization to
 purchase up to an additional $17.6 million worth of its
 ordinary shares under the share repurchase program. Shares
 repurchased under the share repurchase program are held as treasury
 shares.


## fn:AccruedSeveranceBenefitsDisclosureTextBlock

[0001193125-18-255054:notes:366]
| 14. | Severance liabilities |
