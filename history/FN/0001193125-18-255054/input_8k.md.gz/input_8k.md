# FN 8-K — 0001193125-18-252936 filed 2018-08-20

## item codes, every 8-K on or before 2018-08-22

- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2018-08-22

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-18-252936:8k_2_02:1]
EX-99.1
3
d611652dex991.htm
EX-99.1

[0001193125-18-252936:8k_2_02:2]
EX-99.1

[0001193125-18-252936:8k_2_02:3]
Exhibit 99.1

[0001193125-18-252936:8k_2_02:4]
Fabrinet Announces Fourth Quarter and Fiscal Year 2018 Financial Results

[0001193125-18-252936:8k_2_02:5]
BANGKOK, Thailand – August 20, 2018 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision
optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its fourth quarter and fiscal year ended June 29, 2018.

[0001193125-18-252936:8k_2_02:6]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “Our financial results for the fourth quarter exceeded our guidance for revenue and
profitability. Our sequential revenue growth was driven by modest growth from optical communications products, and strong growth from non-optical communications products, with a particularly notable
performance in the industrial laser and automotive markets. We are encouraged by the broadly improving demand dynamics we see and are optimistic that we will see continued sequential growth in the first quarter of fiscal year 2019 as we expand our
leadership as a manufacturer of complex products.”

[0001193125-18-252936:8k_2_02:7]
Toh-Seng Ng, Chief Financial Officer of Fabrinet, added, “On a personal note, at my request,
our board of directors has initiated a CFO succession plan. We have retained an executive search firm to assist in identifying and evaluating candidates, and there is no set timeline for this process.”

[0001193125-18-252936:8k_2_02:8]
Fourth Quarter Fiscal Year 2018 Financial Highlights

[0001193125-18-252936:8k_2_02:9]
GAAP Results

[0001193125-18-252936:8k_2_02:10]
|  | • |  | Revenue for the fourth quarter of fiscal year 2018 was $345.3 million, compared to revenue of $370.5 million for the comparable period in fiscal year 2017. |

[0001193125-18-252936:8k_2_02:11]
|  | • |  | GAAP net income for the fourth quarter of fiscal year 2018 was $22.8 million, compared to GAAP net income of $27.4 million for the fourth quarter of fiscal year 2017. GAAP net income for the fourth quarter of fiscal year 2018 included a foreign exchange loss of $0.9 million, or $0.02 per diluted share, compared to a foreign exchange loss of $1.0 million, or $0.03 per diluted share, for the fourth quarter of fiscal year 2017. |

[0001193125-18-252936:8k_2_02:12]
|  | • |  | GAAP net income per diluted share for the fourth quarter of fiscal year 2018 was $0.60, compared to GAAP net income per diluted share of $0.72 for the fourth quarter of fiscal year 2017. |

[0001193125-18-252936:8k_2_02:13]
Non-GAAP
Results

[0001193125-18-252936:8k_2_02:14]
|  | • |  | Non-GAAP net income for the fourth quarter of fiscal year 2018 was $30.7 million, compared to non-GAAP net income of $32.8 million for the fourth quarter of fiscal year 2017. Non-GAAP net income for the fourth quarter of fiscal year 2018 included a foreign exchange loss of $0.9 million, or $0.02 per diluted share, compared to a foreign exchange loss of $1.0 million, or $0.03 per diluted share, for the fourth quarter of fiscal year 2017. |

[0001193125-18-252936:8k_2_02:15]
|  | • |  | Non-GAAP net income per diluted share for the fourth quarter of fiscal year 2018 was $0.81, compared to non-GAAP net income per diluted share of $0.86 for the same period a year ago. |

[0001193125-18-252936:8k_2_02:16]
Fiscal Year 2018 Financial Highlights

[0001193125-18-252936:8k_2_02:17]
GAAP Results

[0001193125-18-252936:8k_2_02:18]
|  | • |  | Revenue for fiscal year 2018 was $1,371.9 million, compared to revenue of $1,420.5 million for fiscal year 2017. |

[0001193125-18-252936:8k_2_02:19]
|  | • |  | GAAP net income for fiscal year 2018 was $84.2 million, compared to GAAP net income of $97.1 million for fiscal year 2017. GAAP net income for fiscal year 2018 included a foreign exchange loss of $6.6 million, or $0.17 per diluted share, compared to a foreign exchange loss of $1.1 million, or $0.03 per diluted share, for fiscal year 2017. |

[0001193125-18-252936:8k_2_02:20]
|  | • |  | GAAP net income per diluted share for fiscal year 2018 was $2.21, compared to GAAP net income per diluted share of $2.57 for fiscal year 2017. |

[0001193125-18-252936:8k_2_02:21]
Non-GAAP Results

[0001193125-18-252936:8k_2_02:22]
|  | • |  | Non-GAAP net income for fiscal year 2018 was $113.5 million, compared to non-GAAP net income of $127.4 million for fiscal year 2017. Non-GAAP net income for fiscal year 2018 included a foreign exchange loss of $6.6 million, or $0.17 per diluted share, compared to a foreign exchange loss of $2.9 million, or $0.08 per diluted share, for fiscal year 2017. |

[0001193125-18-252936:8k_2_02:23]
|  | • |  | Non-GAAP net income per diluted share for fiscal year 2018 was $2.98, compared to non-GAAP net income per diluted share of $3.37 for fiscal year 2017. |

[0001193125-18-252936:8k_2_02:24]
Share
Repurchase Program Update

[0001193125-18-252936:8k_2_02:25]
Fabrinet repurchased approximately 551,000 ordinary shares at an average price of $36.31 during the fourth quarter. As of
June 29, 2018, Fabrinet had a remaining authorization to purchase up to an additional $17.6 million worth of its ordinary shares.

[0001193125-18-252936:8k_2_02:26]
Business
Outlook

[0001193125-18-252936:8k_2_02:27]
The guidance provided below is based on ASC 605. In the first quarter of fiscal 2019, Fabrinet will report results under ASC 606, which it is
adopting for fiscal year 2019 on a modified retrospective transition method, and will provide a reconciliation to ASC 605 at that time.

[0001193125-18-252936:8k_2_02:28]
Based on
information available as of August 20, 2018, Fabrinet is issuing guidance for its first fiscal quarter of 2019 ending September 28, 2018, as follows:

[0001193125-18-252936:8k_2_02:29]
|  | • |  | Fabrinet expects first quarter revenue to be in the range of $347 million to $355 million. |

[0001193125-18-252936:8k_2_02:30]
|  | • |  | GAAP net income per diluted share is expected to be in the range of $0.58 to $0.61, based on approximately 37.9 million fully diluted shares outstanding. |

[0001193125-18-252936:8k_2_02:31]
|  | • |  | Non-GAAP net income per diluted share is expected to be in the range of $0.80 to $0.83, based on approximately 37.9 million fully diluted shares outstanding. |

[0001193125-18-252936:8k_2_02:32]
Conference Call Information

[0001193125-18-252936:8k_2_02:33]
| What: |  | Fabrinet Fourth Quarter and Fiscal Year 2018 Financial Results Call |
| When: |  | Monday, August 20, 2018 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic |
|  |  | (253) 237-1137, international |
|  |  | Passcode: 9097326 |
| Replay: |  | (855) 859-2056, domestic |
|  |  | (404) 537-3406, international |
|  |  | Passcode: 9097326 |
| Webcast: |  | http://investor.fabrinet.com/ (live and replay) |

[0001193125-18-252936:8k_2_02:34]
This press release and any other information related to the call will also be posted on Fabrinet’s website at
http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-18-252936:8k_2_02:35]
About Fabrinet

[0001193125-18-252936:8k_2_02:36]
Fabrinet is a leading provider of
advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive
components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical

[0001193125-18-252936:8k_2_02:37]
capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and test.
Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China and the
United Kingdom. For more information visit: www.fabrinet.com.

[0001193125-18-252936:8k_2_02:38]
Forward-Looking Statements

[0001193125-18-252936:8k_2_02:39]
Use of
Non-GAAP Financials

[0001193125-18-252936:8k_2_02:40]
We refer to the non-GAAP financial measures cited
above in making operating decisions because they provide meaningful supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses;
depreciation of fair value uplift; severance payments; expenses related to our CEO search; debt administration expense; amortization of intangibles; business combination expenses; loss (gain) on foreign currency contracts; amortization of debt
issuance costs; and restructuring charges. We have excluded these items in order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material
limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these
non-GAAP financial measures in conjunction with GAAP financial measures.

[0001193125-18-252936:8k_2_02:41]
These
non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater
transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the
purposes of determining employee incentive plan compensation.

[0001193125-18-252936:8k_2_02:42]
SOURCE: Fabrinet

[0001193125-18-252936:8k_2_02:43]
Investor Contact:

[0001193125-18-252936:8k_2_02:44]
Garo Toomajanian

[0001193125-18-252936:8k_2_02:45]
ir@fabrinet.com

[0001193125-18-252936:8k_2_02:46]
FABRINET

[0001193125-18-252936:8k_2_02:47]
CONSOLIDATED BALANCE SHEETS

[0001193125-18-252936:8k_2_02:48]
| (in thousands of U.S. dollars, except share data) |  | June 29,2018 |  |  | June 30,2017 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 158,102 |  |  | $ | 133,825 |  |
| Restricted cash in connection with business acquisition |  |  | 3,331 |  |  |  | — |  |
| Marketable securities |  |  | 174,269 |  |  |  | 151,450 |  |
| Trade accounts receivable, net |  |  | 246,912 |  |  |  | 264,349 |  |
| Inventory, net |  |  | 257,687 |  |  |  | 238,665 |  |
| Prepaid expenses |  |  | 8,061 |  |  |  | 6,306 |  |
| Other current assets |  |  | 5,948 |  |  |  | 4,159 |  |
| Total current assets |  |  | 854,310 |  |  |  | 798,754 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Restricted cash in connection with business acquisition |  |  | — |  |  |  | 3,312 |  |
| Property, plant and equipment, net |  |  | 219,640 |  |  |  | 216,881 |  |
| Intangibles, net |  |  | 4,880 |  |  |  | 5,840 |  |
| Goodwill |  |  | 3,828 |  |  |  | 3,806 |  |
| Deferred tax assets |  |  | 5,280 |  |  |  | 2,905 |  |
| Deferred debt issuance costs on revolving loan and other non-current assets |  |  | 80 |  |  |  | 1,577 |  |
| Total non-current assets |  |  | 233,708 |  |  |  | 234,321 |  |
| Total Assets |  | $ | 1,088,018 |  |  | $ | 1,033,075 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Bank borrowings, net of unamortized debt issuance costs |  | $ | 3,250 |  |  | $ | 48,402 |  |
| Trade accounts payable |  |  | 220,159 |  |  |  | 215,262 |  |
| Capital lease liability, current portion |  |  | 451 |  |  |  | 344 |  |
| Income tax payable |  |  | 709 |  |  |  | 1,976 |  |
| Deferred liability in connection with business acquisition |  |  | 3,331 |  |  |  | — |  |
| Accrued payroll, bonus and related expenses |  |  | 13,476 |  |  |  | 13,852 |  |
| Accrued expenses |  |  | 9,013 |  |  |  | 9,227 |  |
| Other payables |  |  | 19,728 |  |  |  | 22,209 |  |
| Total current liabilities |  |  | 270,117 |  |  |  | 311,272 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term loan from bank, non-current portion, net of unamortized debt issuance costs |  |  | 60,938 |  |  |  | 22,701 |  |
| Deferred tax liability |  |  | 2,284 |  |  |  | 1,981 |  |
| Capital lease liability, non-current portion |  |  | 516 |  |  |  | 1,024 |  |
| Deferred liability in connection with business acquisition |  |  | — |  |  |  | 3,312 |  |
| Severance liabilities |  |  | 10,162 |  |  |  | 8,488 |  |
| Other non-current liabilities |  |  | 3,062 |  |  |  | 2,723 |  |
| Total non-current liabilities |  |  | 76,962 |  |  |  | 40,229 |  |
| Total Liabilities |  |  | 347,079 |  |  |  | 351,501 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of June 29, 2018 and June 30, 2017) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 37,723,733 shares and 37,340,496 shares issued, and 36,434,630 shares and 37,340,496 shares outstanding as of March 30, 2018 and June 30, 2017, respectively) |  |  | 377 |  |  |  | 373 |  |
| Additional paid-in capital |  |  | 151,797 |  |  |  | 133,293 |  |
| Treasury shares at cost (1,289,103 shares and zero shares as of March 30, 2018 and June 30, 2017, respectively) |  |  | (42,401 | ) |  |  | — |  |
| Accumulated other comprehensive loss |  |  | (1,257 | ) |  |  | (348 | ) |
| Retained earnings |  |  | 632,423 |  |  |  | 548,256 |  |
| Total Shareholders’ Equity |  |  | 740,939 |  |  |  | 681,574 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 1,088,018 |  |  | $ | 1,033,075 |  |

[0001193125-18-252936:8k_2_02:49]
FABRINET

[0001193125-18-252936:8k_2_02:50]
CONSOLIDATED STATEMENTS OF OPERATIONS AND

[0001193125-18-252936:8k_2_02:51]
COMPREHENSIVE INCOME

[0001193125-18-252936:8k_2_02:52]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
| (in thousands of U.S. dollars, except per share amounts) |  | June 29,2018 |  |  | June 30,2017 |  |  | June 29,2018 |  |  | June 30,2017 |  |
| Revenues |  | $ | 345,327 |  |  | $ | 370,454 |  |  | $ | 1,371,925 |  |  | $ | 1,420,490 |  |
| Cost of revenues |  |  | (306,346 | ) |  |  | (325,694 | ) |  |  | (1,218,513 | ) |  |  | (1,249,030 | ) |
| Gross profit |  |  | 38,981 |  |  |  | 44,760 |  |  |  | 153,412 |  |  |  | 171,460 |  |
| Selling, general and administrative expenses |  |  | (16,559 | ) |  |  | (15,057 | ) |  |  | (57,812 | ) |  |  | (65,626 | ) |
| Expenses related to reduction in workforce |  |  | — |  |  |  | — |  |  |  | (1,776 | ) |  |  | — |  |
| Operating income |  |  | 22,422 |  |  |  | 29,703 |  |  |  | 93,824 |  |  |  | 105,834 |  |
| Interest income |  |  | 1,371 |  |  |  | 507 |  |  |  | 3,925 |  |  |  | 1,977 |  |
| Interest expense |  |  | (1,107 | ) |  |  | (804 | ) |  |  | (3,606 | ) |  |  | (3,321 | ) |
| Foreign exchange loss, net |  |  | (877 | ) |  |  | (1,042 | ) |  |  | (6,587 | ) |  |  | (1,142 | ) |
| Other income |  |  | 35 |  |  |  | 112 |  |  |  | 473 |  |  |  | 509 |  |
| Income before income taxes |  |  | 21,844 |  |  |  | 28,476 |  |  |  | 88,029 |  |  |  | 103,857 |  |
| Income tax expense |  |  | 924 |  |  |  | (1,075 | ) |  |  | (3,862 | ) |  |  | (6,742 | ) |
| Net income |  |  | 22,768 |  |  |  | 27,401 |  |  |  | 84,167 |  |  |  | 97,115 |  |
| Other comprehensive loss, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in net unrealized loss on marketable securities |  |  | 29 |  |  |  | 20 |  |  |  | (1,019 | ) |  |  | (471 | ) |
| Change in net unrealized loss on derivative instruments |  |  | — |  |  |  | — |  |  |  | (1 | ) |  |  | (158 | ) |
| Change in foreign currency translation adjustment |  |  | (1,247 | ) |  |  | 625 |  |  |  | 111 |  |  |  | (310 | ) |
| Total other comprehensive loss, net of tax |  |  | (1,218 | ) |  |  | 645 |  |  |  | (909 | ) |  |  | (939 | ) |
| Net comprehensive income |  | $ | 21,550 |  |  | $ | 28,046 |  |  | $ | 83,258 |  |  | $ | 96,176 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.62 |  |  | $ | 0.73 |  |  | $ | 2.26 |  |  | $ | 2.63 |  |
| Diluted |  | $ | 0.60 |  |  | $ | 0.72 |  |  | $ | 2.21 |  |  | $ | 2.57 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |
| Basic |  |  | 36,828 |  |  |  | 37,334 |  |  |  | 37,257 |  |  |  | 36,927 |  |
| Diluted |  |  | 37,766 |  |  |  | 38,118 |  |  |  | 38,035 |  |  |  | 37,852 |  |

[0001193125-18-252936:8k_2_02:53]
FABRINET

[0001193125-18-252936:8k_2_02:54]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-18-252936:8k_2_02:55]
|  |  | Twelve Months Ended |  |
| (in thousands of U.S. dollars) |  | June 29,2018 |  |  | June 30,2017 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income for the period |  | $ | 84,167 |  |  | $ | 97,115 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 29,087 |  |  |  | 23,793 |  |
| Loss (gain) on disposal of property, plant and equipment |  |  | 18 |  |  |  | (30 | ) |
| Loss on disposal of intangibles |  |  | 447 |  |  |  | — |  |
| Loss from sales and maturities of available-for-sale securities |  |  | 364 |  |  |  | 822 |  |
| Amortization of investment discount |  |  | (506 | ) |  |  | (193 | ) |
| Amortization of deferred debt issuance costs |  |  | 994 |  |  |  | 1,396 |  |
| Reversal of allowance for doubtful accounts |  |  | (23 | ) |  |  | (1 | ) |
| Unrealized loss on exchange rate and fair value of derivative instruments |  |  | 4,222 |  |  |  | 1,884 |  |
| Share-based compensation |  |  | 22,581 |  |  |  | 26,507 |  |
| Deferred income tax |  |  | (2,074 | ) |  |  | 754 |  |
| Other non-cash expenses |  |  | 2,133 |  |  |  | 2,173 |  |
| (Reversal of) Inventory obsolescence |  |  | (436 | ) |  |  | 42 |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | 17,852 |  |  |  | (64,142 | ) |
| Inventory |  |  | (19,432 | ) |  |  | (53,802 | ) |
| Other current assets and non-current assets |  |  | (4,464 | ) |  |  | (2,231 | ) |
| Trade accounts payable |  |  | 3,502 |  |  |  | 38,293 |  |
| Income tax payable |  |  | (1,267 | ) |  |  | (67 | ) |
| Other current liabilities and non-current liabilities |  |  | 915 |  |  |  | (1,379 | ) |
| Net cash provided by operating activities |  |  | 138,080 |  |  |  | 70,934 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of marketable securities |  |  | (152,908 | ) |  |  | (122,778 | ) |
| Proceeds from sales of marketable securities |  |  | 61,795 |  |  |  | 39,578 |  |
| Proceeds from maturities of marketable securities |  |  | 67,417 |  |  |  | 72,361 |  |
| Payments in connection with business acquisition, net of cash acquired |  |  | — |  |  |  | (9,917 | ) |
| Purchase of property, plant and equipment |  |  | (33,825 | ) |  |  | (68,262 | ) |
| Purchase of intangibles |  |  | (1,577 | ) |  |  | (1,768 | ) |
| Proceeds from disposal of property, plant and equipment |  |  | 449 |  |  |  | 230 |  |
| Net cash used in investing activities |  |  | (58,649 | ) |  |  | (90,556 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Proceeds of short-term loans from banks |  |  | 5,000 |  |  |  | 27,500 |  |
| Repayment of short-term loans from bank |  |  | (1,003 | ) |  |  | (157 | ) |
| Repayment of long-term loans from bank |  |  | (11,212 | ) |  |  | (18,100 | ) |
| Repayment of capital lease liability |  |  | (417 | ) |  |  | (276 | ) |
| Repurchase of ordinary shares |  |  | (42,401 | ) |  |  | — |  |
| Proceeds from issuance of ordinary shares under employee share option plans |  |  | 1,436 |  |  |  | 5,890 |  |
| Withholding tax related to net share settlement of restricted share units |  |  | (5,509 | ) |  |  | (1,425 | ) |
| Net cash (used in) provided by financing activities |  |  | (54,106 | ) |  |  | 13,432 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  |  | 25,325 |  |  |  | (6,190 | ) |
| Movement in cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 137,137 |  |  |  | 142,804 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash |  |  | 25,325 |  |  |  | (6,190 | ) |
| Effect of exchange rate on cash, cash equivalents and restricted cash |  |  | (1,029 | ) |  |  | 523 |  |
| Cash, cash equivalents and restricted cash at end of period |  | $ | 161,433 |  |  | $ | 137,137 |  |
| Non-cash investing and financing activities |  |  |  |  |  |  |  |  |
| Construction, software-related and equipment-related payables |  | $ | 5,144 |  |  | $ | 8,434 |  |

[0001193125-18-252936:8k_2_02:56]
FABRINET

[0001193125-18-252936:8k_2_02:57]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-18-252936:8k_2_02:58]
(Continued)

[0001193125-18-252936:8k_2_02:59]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within
the consolidated balance sheets that sum to the total of same amounts shown in the consolidated statements of cash flows:

[0001193125-18-252936:8k_2_02:60]
| (amount in thousands) |  | As ofJune 29,2018 |  |  | As ofJune 30,2017 |  |
| Cash and cash equivalents |  | $ | 158,102 |  |  | $ | 133,825 |  |
| Restricted cash in connection with business acquisition (non-current assets) |  |  | 3,331 |  |  |  | 3,312 |  |
| Cash, cash equivalents and restricted cash |  | $ | 161,433 |  |  | $ | 137,137 |  |

[0001193125-18-252936:8k_2_02:61]
FABRINET

[0001193125-18-252936:8k_2_02:62]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-18-252936:8k_2_02:63]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | June 29, 2018 |  |  | June 30, 2017 |  |  | June 29, 2018 |  |  | June 30, 2017 |  |
| (in thousands of U.S. dollars, except per share data) |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |
| GAAP measures |  |  | 22,768 |  |  |  | 0.60 |  |  |  | 27,401 |  |  |  | 0.72 |  |  |  | 84,167 |  |  |  | 2.21 |  |  |  | 97,115 |  |  |  | 2.57 |  |
| Items reconciling GAAP net (loss) income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,507 |  |  |  | 0.04 |  |  |  | 1,133 |  |  |  | 0.03 |  |  |  | 6,784 |  |  |  | 0.18 |  |  |  | 5,318 |  |  |  | 0.14 |  |
| Depreciation of fair value uplift |  |  | 89 |  |  |  | 0.00 |  |  |  | 80 |  |  |  | 0.00 |  |  |  | 330 |  |  |  | 0.01 |  |  |  | 147 |  |  |  | 0.00 |  |
| Total related to gross profit |  |  | 1,596 |  |  |  | 0.04 |  |  |  | 1,213 |  |  |  | 0.03 |  |  |  | 7,114 |  |  |  | 0.19 |  |  |  | 5,465 |  |  |  | 0.14 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 3,370 |  |  |  | 0.09 |  |  |  | 3,438 |  |  |  | 0.09 |  |  |  | 15,797 |  |  |  | 0.42 |  |  |  | 21,190 |  |  |  | 0.56 |  |
| Expenses related to CEO search |  |  | — |  |  |  | — |  |  |  | 100 |  |  |  | 0.00 |  |  |  | 204 |  |  |  | 0.01 |  |  |  | 203 |  |  |  | 0.01 |  |
| Debt administration expenses |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 320 |  |  |  | 0.01 |  |
| Amortization of intangibles |  |  | 199 |  |  |  | 0.01 |  |  |  | 199 |  |  |  | 0.01 |  |  |  | 780 |  |  |  | 0.02 |  |  |  | 607 |  |  |  | 0.02 |  |
| Business combination expenses |  |  | — |  |  |  | — |  |  |  | 160 |  |  |  | 0.00 |  |  |  | 117 |  |  |  | 0.00 |  |  |  | 1,790 |  |  |  | 0.05 |  |
| Severance payments |  |  | 2,142 |  |  |  | 0.06 |  |  |  | — |  |  |  | — |  |  |  | 2,142 |  |  |  | 0.06 |  |  |  | 577 |  |  |  | 0.02 |  |
| Total related to selling, general and administrative expenses |  |  | 5,711 |  |  |  | 0.15 |  |  |  | 3,897 |  |  |  | 0.10 |  |  |  | 19,040 |  |  |  | 0.50 |  |  |  | 24,687 |  |  |  | 0.65 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss on foreign currency contracts |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,713 | ) |  |  | (0.05 | ) |
| Restructuring charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,776 |  |  |  | 0.05 |  |  |  | — |  |  |  | — |  |
| Amortization of debt issuance costs |  |  | 634 |  |  |  | 0.02 |  |  |  | 257 |  |  |  | 0.01 |  |  |  | 1,412 |  |  |  | 0.04 |  |  |  | 1,884 |  |  |  | 0.05 |  |
| Total related to other incomes and other expenses |  |  | 634 |  |  |  | 0.02 |  |  |  | 257 |  |  |  | 0.01 |  |  |  | 3,188 |  |  |  | 0.08 |  |  |  | 171 |  |  |  | 0.00 |  |
| Total related to net income & EPS |  |  | 7,941 |  |  |  | 0.21 |  |  |  | 5,367 |  |  |  | 0.14 |  |  |  | 29,342 |  |  |  | 0.77 |  |  |  | 30,323 |  |  |  | 0.80 |  |
| Non-GAAP measures |  |  | 30,709 |  |  |  | 0.81 |  |  |  | 32,768 |  |  |  | 0.86 |  |  |  | 113,509 |  |  |  | 2.98 |  |  |  | 127,438 |  |  |  | 3.37 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 37,766 |  |  |  |  |  |  |  | 38,118 |  |  |  |  |  |  |  | 38,035 |  |  |  |  |  |  |  | 37,852 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 37,766 |  |  |  |  |  |  |  | 38,118 |  |  |  |  |  |  |  | 38,035 |  |  |  |  |  |  |  | 37,852 |  |

[0001193125-18-252936:8k_2_02:64]
FABRINET

[0001193125-18-252936:8k_2_02:65]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001193125-18-252936:8k_2_02:66]
| (in thousands) |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | June 29, |  |  | June 30, |  |  | June 29, |  |  | June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net cash provided by operating activities |  | $ | 48,286 |  |  | $ | 10,546 |  |  | $ | 138,080 |  |  | $ | 70,934 |  |
| Less: Purchase of property, plant and equipment |  |  | (5,557 | ) |  |  | (11,038 | ) |  |  | (33,825 | ) |  |  | (68,262 | ) |
| Non-GAAP free cash flow |  | $ | 42,729 |  |  | ($ | 492 | ) |  | $ | 104,255 |  |  | $ | 2,672 |  |

[0001193125-18-252936:8k_2_02:67]
FABRINET

[0001193125-18-252936:8k_2_02:68]
GUIDANCE FOR QUARTER ENDING SEPTEMBER 28, 2018

[0001193125-18-252936:8k_2_02:69]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-18-252936:8k_2_02:70]
|  |  | Diluted |  |
|  |  | EPS |  |
| GAAP net income per diluted share: |  | $ | 0.58 to $0.61 |  |
| Related to cost of revenues: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.05 |  |
| Total related to gross profit |  |  | 0.05 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.16 |  |
| Business combination expenses |  |  | 0.01 |  |
| Total related to selling, general and administrative expenses |  |  | 0.17 |  |
| Total related to net income & EPS |  |  | 0.22 |  |
| Non-GAAP net income per diluted share |  | $ | 0.80 to $0.83 |  |

## item 5.02 — body, verbatim

[0001193125-18-252936:8k_body:1]
Item 5.02

[0001193125-18-252936:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers;
Compensatory Arrangements of Certain Officers.

[0001193125-18-252936:8k_body:3]
Fiscal 2019 Salaries

[0001193125-18-252936:8k_body:4]
On August 14, 2018, the Compensation Committee (the “Compensation Committee”) of the board of directors of Fabrinet
approved an increase to the annual base salary of Seamus Grady, the Company’s chief executive officer, as set forth below. Such salary increase is deemed effective as of June 30, 2018, the first day of the Company’s fiscal year ending
June 28, 2019 (“fiscal 2019”). No other named executive officers received increases to their annual base salaries.

[0001193125-18-252936:8k_body:5]
Name

[0001193125-18-252936:8k_body:6]
Title

[0001193125-18-252936:8k_body:7]
Previous Annual
Base Salary

[0001193125-18-252936:8k_body:8]
Fiscal 2019
Annual Base
Salary

[0001193125-18-252936:8k_body:9]
Change

[0001193125-18-252936:8k_body:10]
Seamus Grady

[0001193125-18-252936:8k_body:11]
Chief Executive Officer

[0001193125-18-252936:8k_body:12]
$

[0001193125-18-252936:8k_body:13]
700,000

[0001193125-18-252936:8k_body:14]
$

[0001193125-18-252936:8k_body:15]
775,000

[0001193125-18-252936:8k_body:16]
10.7

[0001193125-18-252936:8k_body:17]
%

[0001193125-18-252936:8k_body:18]
Fiscal 2019 Executive Incentive Plan

[0001193125-18-252936:8k_body:19]
On August 14, 2018, the Compensation Committee adopted an executive incentive plan (the “Cash Bonus Plan”) for fiscal
2019. The Cash Bonus Plan is an incentive program designed to motivate participants to achieve the Company’s financial objectives, and to reward them for their achievements when those objectives are met. All of the Company’s executive
officers pursuant to Section 16 of the Securities Exchange Act of 1934, except Dr. Hong Hou who tendered his resignation to the Company on August 14, 2018, are eligible to participate in the Cash Bonus Plan (individually, a
“Participant,” and collectively, the “Participants”). The Cash Bonus Plan provides for a target bonus amount, as set forth in the table below. The maximum bonus that a Participant may receive under the Cash Bonus
Plan is such Participant’s target bonus.

[0001193125-18-252936:8k_body:20]
Named Executive Officer

[0001193125-18-252936:8k_body:21]
Fiscal 2019 Target Bonus

[0001193125-18-252936:8k_body:22]
Seamus Grady

[0001193125-18-252936:8k_body:23]
$

[0001193125-18-252936:8k_body:24]
970,000

[0001193125-18-252936:8k_body:25]
Dr. Harpal Gill

[0001193125-18-252936:8k_body:26]
$

[0001193125-18-252936:8k_body:27]
1,250,000

[0001193125-18-252936:8k_body:28]
Toh-Seng Ng

[0001193125-18-252936:8k_body:29]
$

[0001193125-18-252936:8k_body:30]
835,000

[0001193125-18-252936:8k_body:31]
The amount of bonus actually paid to a Participant under the Cash Bonus Plan will be based 50% on achievement
of a fiscal 2019 revenue target and 50% on achievement of a fiscal 2019 non-GAAP gross margin target. As achievement of each financial target is considered independently from the other, the Company must meet a
threshold for each factor in order for a Participant to receive any credit for that factor. If the Company achieves 100% or more of a target financial metric, bonuses would be paid out at 100% of target with respect to that financial metric
component. Achievement of the fiscal 2019 revenue target at a level between approximately 91.1% and 100% will result in a bonus amount for that metric that is scaled from 0% to 100% in a linear fashion. Achievement of the fiscal 2019 non-GAAP gross margin target at a level between approximately 94.1% and 100% will result in a bonus amount for that metric that is scaled from 0% to 100% in a linear fashion.

[0001193125-18-252936:8k_body:32]
Equity Award Grants

[0001193125-18-252936:8k_body:33]
On August 14, 2018, the Compensation Committee approved the grant, effective as of August 23, 2018 (the “Grant
Date”), of the following dollar value of restricted share units (“RSUs”), performance share units (“PSUs”) and “stretch” PSUs (“Stretch PSUs”), rounded down to the nearest whole
share, to the following named executive officers of the Company as a component of their fiscal 2019 compensation:

[0001193125-18-252936:8k_body:34]
Executive Officer

[0001193125-18-252936:8k_body:35]
Grant Date Value of
RSUs

[0001193125-18-252936:8k_body:36]
Grant Date Value of
PSUs

[0001193125-18-252936:8k_body:37]
Grant Date Value of
Stretch PSUs

[0001193125-18-252936:8k_body:38]
Seamus Grady

[0001193125-18-252936:8k_body:39]
$

[0001193125-18-252936:8k_body:40]
1,500,000

[0001193125-18-252936:8k_body:41]
$

[0001193125-18-252936:8k_body:42]
1,750,000

[0001193125-18-252936:8k_body:43]
$

[0001193125-18-252936:8k_body:44]
1,750,000

[0001193125-18-252936:8k_body:45]
Dr. Harpal Gill

[0001193125-18-252936:8k_body:46]
$

[0001193125-18-252936:8k_body:47]
1,200,000

[0001193125-18-252936:8k_body:48]
$

[0001193125-18-252936:8k_body:49]
1,500,000

[0001193125-18-252936:8k_body:50]
$

[0001193125-18-252936:8k_body:51]
1,500,000

[0001193125-18-252936:8k_body:52]
Toh-Seng Ng

[0001193125-18-252936:8k_body:53]
$

[0001193125-18-252936:8k_body:54]
1,100,000

[0001193125-18-252936:8k_body:55]
$

[0001193125-18-252936:8k_body:56]
1,300,000

[0001193125-18-252936:8k_body:57]
$

[0001193125-18-252936:8k_body:58]
1,300,000

[0001193125-18-252936:8k_body:59]
The grants will be made under the Company’s Amended and Restated 2010 Performance Incentive Plan. The
RSUs will vest in equal annual installments over a period of three years on the anniversary date of the Grant Date, subject to the individual’s continued service with the Company through each such vesting date.

[0001193125-18-252936:8k_body:60]
The PSUs will vest, if at all, following a 2-year performance period, on the date the Compensation
Committee certifies achievement of the performance criteria set forth below, subject to the individual’s continued service with the Company through such vesting date. Vesting of the PSUs will be based 50% on achievement of a cumulative fiscal
2019 and fiscal 2020 revenue target (the “PSU Revenue Target”) and 50% on achievement of a cumulative fiscal 2019 and fiscal 2020 non-GAAP gross margin target (the “PSU GM
Target”). As achievement of each financial target is considered independently from the other, the Company must meet a threshold for each factor in order for an individual to receive any credit for that factor. If the Company achieves 100%
or more of a target financial metric, the PSUs will vest at 100% of target with respect to that financial metric component. Achievement of the PSU Revenue Target at a level between approximately 94.0% and 100% will result in a number of shares
vesting for that metric that is scaled from 0% to 100% in a linear fashion. Achievement of the PSU GM Target at a level between approximately 97.9% and 100% will result in a number of shares vesting for that metric that is scaled from 0% to 100% in
a linear fashion.

[0001193125-18-252936:8k_body:61]
The Stretch PSUs will vest, if at all, following a 2-year performance period,
on the date the Compensation Committee certifies achievement of the performance criteria set forth below, subject to the individual’s continued service with the Company through such vesting date. Vesting of the Stretch PSUs will be based 50% on
achievement of a cumulative fiscal 2019 and fiscal 2020 revenue target that is higher than the PSU Revenue Target (the “Stretch PSU Revenue Target”) and 50% on achievement of a cumulative fiscal 2019 and fiscal 2020 non-GAAP gross margin target that is higher than the PSU GM Target (the “Stretch PSU GM Target”). As achievement of each financial target is considered independently from the other, the Company must
meet a threshold for each factor in order for an individual to receive any credit for that factor. If the Company achieves 100% or more of a target financial metric, the Stretch PSUs will vest at 100% of target with respect to that financial metric
component. Achievement of the Stretch PSU Revenue Target at a level between the PSU Revenue Target and 100% will result in a number of shares vesting for that metric that is scaled from 0% to 100% in a linear fashion. Achievement of the Stretch PSU
GM Target at a level between the PSU GM Target and 100% will result in a number of shares vesting for that metric that is scaled from 0% to 100% in a linear fashion.

[0001193125-18-252936:8k_body:62]
Departure of Named Executive Officer

[0001193125-18-252936:8k_body:63]
On
August 14, 2018, Dr. Hong Hou, the Company’s Executive Vice President, Chief Technical Officer, resigned from his position with the Company, effective August 25, 2018.

[0001193125-18-252936:8k_body:64]
In connection with Dr. Hou’s resignation, on August 20, 2018, the Company entered into a Separation Agreement and Release (the
“Separation Agreement”) with Dr. Hou. As consideration for non-disparagement, non-solicitation and
non-competition obligations to the Company and Fabrinet USA, Inc. and a full release of all claims related to Dr. Hou’s employment with the Company, Dr. Hou will receive: (1) a lump sum
cash payment in the amount of $525,000; (2) a lump sum cash payment in the amount of $60,000, representing reimbursement for health care insurance premiums under COBRA for a period of twelve months; (3) accelerated vesting with respect to an
aggregate of 22,926 unvested restricted share units; and (4) payment of accrued vacation, if any.

[0001193125-18-252936:8k_body:65]
A copy of the Separation Agreement is attached to this Current Report on Form 8-K as Exhibit 10.1 and is incorporated herein by reference.

[0001193125-18-252936:8k_body:66]
CFO Search

[0001193125-18-252936:8k_body:67]
The information set forth in Item 8.01 of this Current Report on Form 8-K is incorporated herein
by reference.
