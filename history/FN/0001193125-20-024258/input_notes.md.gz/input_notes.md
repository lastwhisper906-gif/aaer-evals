# FN notes — 0001193125-20-024258


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-20-024258:notes:1]
[same as prior period, unchanged from 0001193125-19-284781:notes:1]

[0001193125-20-024258:notes:2]
[same as prior period, unchanged from 0001193125-19-284781:notes:2]

[0001193125-20-024258:notes:3]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of December 27, 2019 and for the three and six months ended December 27, 2019 and December 28, 2018 includes normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 
10-K
 for the year ended June 28, 2019.

[0001193125-20-024258:notes:4]
[same as prior period, unchanged from 0001193125-19-284781:notes:4]

[0001193125-20-024258:notes:5]
The results for the three and six months ended December 27, 2019 may not be indicative of results for the year ending June 26, 2020 or any future periods.

[0001193125-20-024258:notes:6]
[same as prior period, unchanged from 0001193125-19-284781:notes:6]

[0001193125-20-024258:notes:7]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements, and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information.

[0001193125-20-024258:notes:8]
[same as prior period, unchanged from 0001193125-19-284781:notes:8]

[0001193125-20-024258:notes:9]
The Company utilizes a 
52-53
 week fiscal year ending on the Friday in June closest to June 30. The three months ended December 27, 2019 and December 28, 2018 each consisted of 13 weeks. The six months ended December 27, 2019 and December 28, 2018 each consisted of 26 weeks. Fiscal year 2020 will be comprised of 52 weeks and will end on June 26, 2020.

[0001193125-20-024258:notes:10]
[same as prior period, unchanged from 0001193125-19-284781:notes:12]

[0001193125-20-024258:notes:11]
[same as prior period, unchanged from 0001193125-19-284781:notes:13]

[0001193125-20-024258:notes:12]
Adoption of New Accounting Standards

[0001193125-20-024258:notes:13]
[same as prior period, unchanged from 0001193125-19-284781:notes:15]

[0001193125-20-024258:notes:14]
For periods prior to adoption of ASC 842, the Company is required to present disclosures in accordance with ASC Topic 840. 
F
uture minimum lease payments due under 
non-cancelable
 operating leases as of June 28, 2019 were as follows:

[0001193125-20-024258:notes:15]
[same as prior period, unchanged from 0001193125-19-284781:notes:17]

[0001193125-20-024258:notes:16]
[same as prior period, unchanged from 0001193125-19-284781:notes:18]

[0001193125-20-024258:notes:17]
On June 29, 2019, the Company also adopted Accounting Standards Update (“ASU”) 
2017-12,
 Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. ASU 
2017-12
 simplifies existing hedge accounting guidance in order to better portray in financial statements the economic impact of risk management activities in the financial statements, including eliminating the separate measurement and presentation of hedge ineffectiveness. Prior to the adoption of ASU 
2017-12,
 the Company was required to separately measure and reflect the amount by which the hedging instrument did not offset the changes in the fair value or cash flows of hedged items, and to record the ineffective portion as earnings. Upon the adoption of ASU 
2017-12,
 the Company no longer recognizes hedge ineffectiveness as earnings, but instead records the entire changes in the fair value of the hedged instruments as other comprehensive income. Amounts recorded as other comprehensive income are subsequently reclassified to earnings in the same income statement line item that is used to present the earnings effect of the hedged item when the hedged item affects earnings. See Note 6 for further details.

[0001193125-20-024258:notes:18]
Concentration ​​​​​​​of credit risk

[0001193125-20-024258:notes:19]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash and cash equivalents, short-term investments, derivatives, accounts receivable and contract assets.

[0001193125-20-024258:notes:20]
Cash, cash equivalents and short-term investments are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. The Company seeks to mitigate its credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties. The Company limits its short-term investments in marketable securities to securities with a maturity not in excess of three years and securities that are rated A1, 
P-1,
 F1, or better.

[0001193125-20-024258:notes:21]
[same as prior period, unchanged from 0001193125-19-284781:notes:25]

[0001193125-20-024258:notes:22]
[same as prior period, unchanged from 0001193125-19-284781:notes:26]

[0001193125-20-024258:notes:23]
[same as prior period, unchanged from 0001193125-19-284781:notes:27]

[0001193125-20-024258:notes:24]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued ASU 
2019-12,
 “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes
.
” The amendments in this Update simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify GAAP for other areas of Topic 740 by clarifying and amending existing guidance. For public business entities, the amendments in this update are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2020. This ASU will be effective for the Company in the first quarter of fiscal 2022. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.

[0001193125-20-024258:notes:25]
In May 2019, 
the 
FASB issued ASU 
2019-05,
 “Financial Instruments – Credit Losses (Topic 326): Targeted Transition Relief
.
” The amendments in ASU 
2019-05
 provide entities that have certain instruments within the scope of Subtopic 
326-20
 (“Financial Instruments—Credit Losses—Measured at Amortized Cost”) with an option to irrevocably elect the fair value option in Subtopic 
825-10
 (“Financial Instruments—Overall”), applied on an 
instrument-by-instrument
 basis for eligible instruments, upon adoption of Topic 326. The fair value option election does not apply to 
held-to-maturity
 debt securities. An entity that elects the fair value option should subsequently apply the guidance in Subtopics 
820-10
 (“Fair Value Measurement—Overall”) and 
825-10.
 For public business entities, this update is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. This ASU will be effective for the Company in the first quarter of fiscal 2021. Early adoption is permitted. The Company 
is currently evaluating the i
mpact of the adoption of

[0001193125-20-024258:notes:26]
this update

[0001193125-20-024258:notes:27]
o
n

[0001193125-20-024258:notes:28]
its condensed consolidated financial statements.

[0001193125-20-024258:notes:29]
In April 2019, 
the 
FASB issued ASU 
2019-04,
 “Codification Improvements to Topic 326, Financial Instruments—Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments.” The amendments in ASU 
2019-04
 apply to all reporting entities within the scope of the affected accounting guidance. For public business entities, this update is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. This ASU will be effective for the Company in the first quarter of fiscal 2021. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.

[0001193125-20-024258:notes:30]
In August 2018, the FASB issued ASU 
2018-13,
 “Fair Value Measurement (Topic 820), Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement.” ASU 
2018-13
 is intended to improve the effectiveness of disclosures in the notes to the financial statements, including (1) the development of a framework that promotes consistent decisions by the FASB about disclosure requirements and (2) the appropriate exercise of discretion by reporting entities. The amendment modifies the disclosure requirements on transferring between level 1 and level 2 and valuation processes of level 3 fair value measurements. This update is effective for all entities for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years, beginning after December 15, 2019. This ASU will be effective for the Company in the first quarter of fiscal 2021. The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.

[0001193125-20-024258:notes:31]
In January 2017, the FASB issued ASU 
2017-04,
 “Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.” ASU 
2017-04
 modified the concept of impairment assessment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. Public companies that are SEC filers should adopt the amendment for annual and any interim goodwill impairment tests in fiscal years beginning after December 15, 2019. Early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017. This ASU will be effective for the Company in the first quarter of fiscal 2021. The Company does not expect this update will impact its condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001193125-20-024258:notes:32]
[same as prior period, unchanged from 0001193125-19-284781:notes:32]

[0001193125-20-024258:notes:33]
The Company derives total revenues primarily from the assembly of products under supply agreements with its customers and the fabrication of customized optics and glass. The Company recognizes revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the Company expects to be entitled in exchange for such goods or services. In order to meet this requirement, the Company applies the following five steps: (1) identify the contract with a customer, (2) identify the performance obligations under the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations under the contract, and (5) recognize revenue when a performance obligation is satisfied. Revenue is recognized net of any taxes collected from customers, which is subsequently remitted to governmental authorities.

[0001193125-20-024258:notes:34]
[same as prior period, unchanged from 0001193125-19-284781:notes:34]

[0001193125-20-024258:notes:35]
The Company manufactures products that are customized to customers’ specifications, however, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for recognizing revenue over time are not met. On the evaluation of the contracts the Company determined that it did not have contractual rights to bill profit for work in progress in the event of a contract termination, an event which is expected to be infrequent. Further, in limited circumstances, substantive acceptance by the customer will result in the deferral of revenue until acceptance is formally received from the customer. Judgment may be required in determining if the acceptance clause provides for substantive acceptance.

[0001193125-20-024258:notes:36]
[same as prior period, unchanged from 0001193125-19-284781:notes:36]

[0001193125-20-024258:notes:37]
[same as prior period, unchanged from 0001193125-19-284781:notes:37]

[0001193125-20-024258:notes:38]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. In determining the transaction price, the Company evaluates whether the price is subject to refund or adjustment to determine the net consideration to which the Company expects to be entitled. The Company generally does not grant return privileges other than for defective products during the warranty period. The Company generally provides a warranty of between one to five years on the product.

[0001193125-20-024258:notes:39]
[same as prior period, unchanged from 0001193125-19-284781:notes:39]

[0001193125-20-024258:notes:40]
[same as prior period, unchanged from 0001193125-19-284781:notes:40]

[0001193125-20-024258:notes:41]
[same as prior period, unchanged from 0001193125-19-284781:notes:41]

[0001193125-20-024258:notes:42]
A contract asset is recognized when the Company​​​​​​​ has recognized revenues prior to generating an invoice for payment. Contract assets are classified separately within the unaudited condensed consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. During the six months ended December 27, 2019, the Company had no impairment for contract assets recognized.

[0001193125-20-024258:notes:43]
[same as prior period, unchanged from 0001193125-19-284781:notes:45]

[0001193125-20-024258:notes:44]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the 
six

[0001193125-20-024258:notes:45]
month
s

[0001193125-20-024258:notes:46]
ended December 27, 2019:

[0001193125-20-024258:notes:47]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 28, 2019 |  | $ | 12,447 |  |
| Revenue recognized |  |  | 39,093 |  |
| Amounts collected or invoiced |  |  | (40,426 | ) |
| Ending balance, December 27, 2019 |  | $ | 11,114 |  |

[0001193125-20-024258:notes:48]
| (amount in thousands) |  | Contract Liabilities |  |
| Beginning balance, June 28, 2019 |  | $ | 2,239 |  |
| Advance payment received during the period |  |  | 3,336 |  |
| Revenue recognized |  |  | (3,215 | ) |
| Ending balance, December 27, 2019 |  | $ | 2,360 |  |

[0001193125-20-024258:notes:49]
[same as prior period, unchanged from 0001193125-19-284781:notes:50]

[0001193125-20-024258:notes:50]
Consistent with the guidance in ASC 
340-40-25-1,
 the incremental costs of obtaining a contract with a customer are recognized as an asset (not expensed as incurred) if such costs are expected to be recovered. Incremental costs of obtaining a contract are costs that the Company would not have incurred if the contract had not been obtained (e.g., sales commissions or similar incentive payments linked directly to new or modified customer contracts). Costs that would have been incurred regardless of whether a customer contract was obtained (e.g., costs of pursuing the contact, legal advice, etc.) are expensed as incurred, unless such costs are explicitly chargeable to the customer. During the 
six

[0001193125-20-024258:notes:51]
ended December 27, 2019, the Company did not have any incremental costs of obtaining a contract.

[0001193125-20-024258:notes:52]
Shipping and Handling​​​​​​​

[0001193125-20-024258:notes:53]
[same as prior period, unchanged from 0001193125-19-284781:notes:54]

[0001193125-20-024258:notes:54]
Revenue by Geographic ​​​​​​​Area

[0001193125-20-024258:notes:55]
Total revenues are attributed to a particular geographic area based on the
 bill-to-location
 of the Company’s customers. The Company operates in three geographic regions: North America, Asia-Pacific and Europe. The following table
s
 present total revenues by geographic region:

[0001193125-20-024258:notes:56]
| (amount in thousands, except percentages) |  | Three MonthsEnded December 27, 2019 |  |  | As a % of TotalRevenues |  |  | Six MonthsEnded December 27, 2019 |  |  | As a % of TotalRevenues |  |
| North America |  | $ | 223,398 |  |  |  | 52.4 | % |  | $ | 424,345 |  |  |  | 51.4 | % |
| Asia-Pacific |  |  | 141,147 |  |  |  | 33.1 |  |  |  | 259,570 |  |  |  | 31.4 |  |
| Europe |  |  | 61,672 |  |  |  | 14.5 |  |  |  | 141,598 |  |  |  | 17.2 |  |
| Total |  | $ | 426,217 |  |  |  | 100.0 | % |  | $ | 825,513 |  |  |  | 100.0 | % |

[0001193125-20-024258:notes:57]
| (amount in thousands, except percentages) |  | Three MonthsEnded December 28, 2018 |  |  | As a % of TotalRevenues |  |  | Six MonthsEnded December 28, 2018 |  |  | As a % of TotalRevenues |  |
| North America |  | $ | 182,698 |  |  |  | 45.3 | % |  | $ | 362,524 |  |  |  | 46.5 | % |
| Asia-Pacific |  |  | 166,711 |  |  |  | 41.4 |  |  |  | 318,658 |  |  |  | 40.8 |  |
| Europe |  |  | 53,671 |  |  |  | 13.3 |  |  |  | 99,075 |  |  |  | 12.7 |  |
| Total |  | $ | 403,080 |  |  |  | 100.0 | % |  | $ | 780,257 |  |  |  | 100.0 | % |

[0001193125-20-024258:notes:58]
The following table
s
 set forth our revenues by end market
:

[0001193125-20-024258:notes:59]
| (amount in thousands, except percentages) |  | Three MonthsEnded December 27, 2019 |  |  | As a % of TotalRevenues |  |  | Six MonthsEnded December 27, 2019 |  |  | As a % of TotalRevenues |  |
| Optical communications |  | $ | 322,068 |  |  |  | 75.6 | % |  | $ | 624,447 |  |  |  | 75.6 | % |
| Lasers, sensors and other |  |  | 104,149 |  |  |  | 24.4 |  |  |  | 201,066 |  |  |  | 24.4 |  |
| Total |  | $ | 426,217 |  |  |  | 100.0 | % |  | $ | 825,513 |  |  |  | 100.0 | % |

[0001193125-20-024258:notes:60]
| (amount in thousands, except percentages) |  | Three MonthsEnded December 28, 2018 |  |  | As a % of TotalRevenues |  |  | Six MonthsEnded December 28, 2018 |  |  | As a % of TotalRevenues |  |
| Optical communications |  | $ | 305,547 |  |  |  | 75.8 | % |  | $ | 586,315 |  |  |  | 75.1 | % |
| Lasers, sensors and other |  |  | 97,533 |  |  |  | 24.2 |  |  |  | 193,942 |  |  |  | 24.9 |  |
| Total |  | $ | 403,080 |  |  |  | 100.0 | % |  | $ | 780,257 |  |  |  | 100.0 | % |


## us-gaap:EarningsPerShareTextBlock

[0001193125-20-024258:notes:61]
[same as prior period, unchanged from 0001193125-19-284781:notes:63]

[0001193125-20-024258:notes:62]
[same as prior period, unchanged from 0001193125-19-284781:notes:64]

[0001193125-20-024258:notes:63]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands except per share amounts) |  | December 27,2019 |  |  | December 28,2018 |  |  | December 27, 2019 |  |  | December 28, 2018 |  |
| Net income attributable to shareholders |  | $ | 31,231 |  |  | $ | 31,513 |  |  | $ | 57,188 |  |  | $ | 59,363 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  | 37,011 |  |  |  | 36,841 |  |  |  | 36,962 |  |  |  | 36,733 |  |
| Incremental shares arising from the assumed vesting of restricted share units and performance share units (thousands of shares) |  |  | 752 |  |  |  | 630 |  |  |  | 684 |  |  |  | 572 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 37,763 |  |  |  | 37,471 |  |  |  | 37,646 |  |  |  | 37,305 |  |
| Basic earnings per ordinary share |  | $ | 0.84 |  |  | $ | 0.86 |  |  | $ | 1.55 |  |  | $ | 1.62 |  |
| Diluted earnings per ordinary share |  | $ | 0.83 |  |  | $ | 0.84 |  |  | $ | 1.52 |  |  | $ | 1.59 |  |
| Outstanding performance share units excluded from the computation of diluted earnings per ordinary share (thousands of shares)(1) |  |  | 50 |  |  |  | 401 |  |  |  | 50 |  |  |  | 401 |  |

[0001193125-20-024258:notes:64]
[same as prior period, unchanged from 0001193125-19-284781:notes:66]


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001193125-20-024258:notes:65]
[same as prior period, unchanged from 0001193125-19-284781:notes:67]

[0001193125-20-024258:notes:66]
[same as prior period, unchanged from 0001193125-19-284781:notes:68]

[0001193125-20-024258:notes:67]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | UnrealizedGain/(Loss) |  |  | Cash andCashEquivalents |  |  | MarketableSecurities |  |  | OtherInvestments |  |
| As of December 27, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 217,721 |  |  | $ | — |  |  | $ | 217,721 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 2,310 |  |  |  | — |  |  |  | 2,310 |  |  |  | — |  |  |  | — |  |
| Liquidity funds |  |  | 20,837 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 20,837 |  |
| Certificates of deposit and time deposits |  |  | 20,000 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 20,000 |  |
| Corporate bonds and commercial papers |  |  | 102,735 |  |  |  | 261 |  |  |  | — |  |  |  | 102,996 |  |  |  | — |  |
| U.S. agency and U.S. Treasury securities |  |  | 78,840 |  |  |  | 132 |  |  |  | — |  |  |  | 78,972 |  |  |  | — |  |
| Total |  | $ | 442,443 |  |  | $ | 393 |  |  | $ | 220,031 |  |  | $ | 181,968 |  |  | $ | 40,837 |  |
| As of June 28, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 178,019 |  |  | $ | — |  |  | $ | 178,019 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 2,820 |  |  |  | — |  |  |  | 2,820 |  |  |  | — |  |  |  | — |  |
| Liquidity funds |  |  | 20,552 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 20,552 |  |
| Certificates of deposit and time deposits |  |  | 35,028 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 35,028 |  |
| Corporate bonds and commercial papers |  |  | 130,959 |  |  |  | 297 |  |  |  | — |  |  |  | 131,256 |  |  |  | — |  |
| U.S. agency and U.S. Treasury securities |  |  | 69,552 |  |  |  | 105 |  |  |  | — |  |  |  | 69,657 |  |  |  | — |  |
| Total |  | $ | 436,930 |  |  | $ | 402 |  |  | $ | 180,839 |  |  | $ | 200,913 |  |  | $ | 55,580 |  |

[0001193125-20-024258:notes:68]
All highly liquid investments with original maturities of three months or less at the date of purchase are classified as cash equivalents. Management determines the appropriate classification of its investments at the time of purchase and 
re-evaluates
 the designations at each balance sheet date. The Company may sell certain of its short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s short-term investments generally range from three months to three years. The Company’s short-term investments consist of U.S. Treasuries and fixed income securities and have been classified and accounted for as 
available-for-sale.

[0001193125-20-024258:notes:69]
The following table summarizes the cost and estimated fair value of short-term investments classified as 
available-for-sale 
 securities based on stated effective maturities as of December 27, 2019:

[0001193125-20-024258:notes:70]
|  |  | December 27, 2019 |  |  | June 28, 2019 |  |
| (amount in thousands) |  | Carrying Cost |  |  | Fair Value |  |  | Carrying Cost |  |  | Fair Value |  |
| Due within one year |  | $ | 51,938 |  |  | $ | 51,971 |  |  | $ | 69,746 |  |  | $ | 69,830 |  |
| Due between one to five years |  |  | 129,637 |  |  |  | 129,997 |  |  |  | 130,765 |  |  |  | 131,083 |  |
| Total |  | $ | 181,575 |  |  | $ | 181,968 |  |  | $ | 200,511 |  |  | $ | 200,913 |  |

[0001193125-20-024258:notes:71]
During the six months ended December 27, 2019, the Company recognized a realized gain of $79 thousand from sales and maturities of 
available-for-sale
 securities.

[0001193125-20-024258:notes:72]
As of December 27, 2019, the Company considered the 
decline
 in market value of its short-term investments portfolio to be temporary in nature and did not consider any of its securities other-than-temporarily impaired. The Company typically invests in highly-rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy requires investments generally to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. When evaluating an investment for other-than-temporary impairment, the Company reviews factors such as the length of time and extent to which fair value has been below its cost basis, the financial condition of the issuer and any changes thereto, changes in market interest rates, and the Company’s intent to sell, or whether it is more likely than not it will be required to sell, the investment before recovery of the investment’s cost basis. No impairment losses were recorded for the six months ended December 27, 2019.


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-20-024258:notes:73]
[same as prior period, unchanged from 0001193125-19-284781:notes:75]

[0001193125-20-024258:notes:74]
[same as prior period, unchanged from 0001193125-19-284781:notes:76]

[0001193125-20-024258:notes:75]
[same as prior period, unchanged from 0001193125-19-284781:notes:77]

[0001193125-20-024258:notes:76]
[same as prior period, unchanged from 0001193125-19-284781:notes:78]

[0001193125-20-024258:notes:77]
[same as prior period, unchanged from 0001193125-19-284781:notes:79]

[0001193125-20-024258:notes:78]
[same as prior period, unchanged from 0001193125-19-284781:notes:80]

[0001193125-20-024258:notes:79]
[same as prior period, unchanged from 0001193125-19-284781:notes:81]

[0001193125-20-024258:notes:80]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of December 27, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 2,310 |  |  | $ | — |  |  | $ | 2,310 |  |
| Liquidity funds |  |  | — |  |  |  | 20,837 |  |  |  | — |  |  |  | 20,837 |  |
| Certificates of deposit and time deposits |  |  | — |  |  |  | 20,000 |  |  |  | — |  |  |  | 20,000 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 102,996 |  |  |  | — |  |  |  | 102,996 |  |
| U.S. agency and U.S. Treasury securities |  |  | — |  |  |  | 78,972 |  |  |  | — |  |  |  | 78,972 |  |
| Derivative assets |  |  | — |  |  |  | 325 | (1) |  |  | — |  |  |  | 325 |  |
| Total |  | $ | — |  |  | $ | 225,440 |  |  | $ | — |  |  | $ | 225,440 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 3,980 | (2) |  | $ | — |  |  | $ | 3,980 |  |
| Total |  | $ | — |  |  | $ | 3,980 |  |  | $ | — |  |  | $ | 3,980 |  |

[0001193125-20-024258:notes:81]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 28, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 2,820 |  |  | $ | — |  |  | $ | 2,820 |  |
| Liquidity funds |  |  | — |  |  |  | 20,552 |  |  |  | — |  |  |  | 20,552 |  |
| Certificates of deposit and time deposits |  |  | — |  |  |  | 35,028 |  |  |  | — |  |  |  | 35,028 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 131,256 |  |  |  | — |  |  |  | 131,256 |  |
| U.S. agency and U.S. Treasury securities |  |  | — |  |  |  | 69,657 |  |  |  | — |  |  |  | 69,657 |  |
| Derivative assets |  |  | — |  |  |  | 2,201 | (3) |  |  | — |  |  |  | 2,201 |  |
| Total |  | $ | — |  |  | $ | 261,514 |  |  | $ | — |  |  | $ | 261,514 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 2,591 | (4) |  | $ | — |  |  | $ | 2,591 |  |
| Total |  | $ | — |  |  | $ | 2,591 |  |  | $ | — |  |  | $ | 2,591 |  |

[0001193125-20-024258:notes:82]
| (1) | Foreign currency forward contracts with a notional amount of $126.0 million and Canadian dollars 0.4 million. |

[0001193125-20-024258:notes:83]
[same as prior period, unchanged from 0001193125-19-284781:notes:84]

[0001193125-20-024258:notes:84]
[same as prior period, unchanged from 0001193125-19-284781:notes:85]

[0001193125-20-024258:notes:85]
[same as prior period, unchanged from 0001193125-19-284781:notes:86]

[0001193125-20-024258:notes:86]
[same as prior period, unchanged from 0001193125-19-284781:notes:87]

[0001193125-20-024258:notes:87]
The Company utilizes derivative financial instruments to hedge (i) foreign exchange risk associated with certain foreign currency denominated assets and liabilities and other foreign currency transactions, and (ii) interest rate risk associated with its long-term debt.

[0001193125-20-024258:notes:88]
[same as prior period, unchanged from 0001193125-19-284781:notes:89]

[0001193125-20-024258:notes:89]
Foreign Currency Forward Contracts

[0001193125-20-024258:notes:90]
[same as prior period, unchanged from 0001193125-19-284781:notes:91]

[0001193125-20-024258:notes:91]
The Company enters into foreign currency forward contracts to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht and Canadian dollars.

[0001193125-20-024258:notes:92]
As of December 27, 2019, the Company had

[0001193125-20-024258:notes:93]
117

[0001193125-20-024258:notes:94]
outstanding

[0001193125-20-024258:notes:95]
U.S. dollars foreign currency

[0001193125-20-024258:notes:96]
forward contracts with an aggregate notional amount of

[0001193125-20-024258:notes:97]
$
126.0

[0001193125-20-024258:notes:98]
million 
and two outstanding Canadia
n dollars foreign currency forward contracts with an aggregate notional amo
u
nt o
f $
0.4 
million

[0001193125-20-024258:notes:99]
with maturity dates from January 2020 through July 2020. These foreign currency forward contracts were not designated for hedge accounting and were used to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht
 and Canadian dollars
. During the six months ended December 27, 2019, the Company recorded an unrealized 
loss
 of

[0001193125-20-024258:notes:100]
$
1.9

[0001193125-20-024258:notes:101]
million from changes in the fair value of foreign currency 
 forward 
contracts in earnings as foreign exchange 
(
loss
) 
gain, net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-20-024258:notes:102]
As of December 28, 2018, the Company had 
four 
outstanding U.S. dollars foreign currency forward contracts with an aggregate notional amount of $
8.0 
million, 
three 
outstanding U.S. dollars foreign currency option contracts with an aggregate notional amount of $
15.0 
million and one outstanding Canadian dollars forward contract with a notional amount of $
0.4 
million with maturity dates from January through 
April 2019
. These foreign currency forward contracts and option contracts were not designated for hedge accounting and were used to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai Baht and Canadian dollars. During the six months ended December 28, 2018, the Company recorded an unrealized gain of $
2.6 
million from changes in the fair value of foreign currency forward contracts in earnings as foreign exchange (loss) gain, net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-20-024258:notes:103]
Interest Rate Swap Agreements

[0001193125-20-024258:notes:104]
The Company entered into interest rate swap agreements to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. As of December 27, 2019, the Company had 
two
 outstanding interest rate swap agreements with an aggregate notional amount of $125.1 million. As of December 28, 2018, the Company had one outstanding interest rate swap agreement with a notional amount of $64.2 million.

[0001193125-20-024258:notes:105]
On July 25, 2018, Fabrinet Thailand entered into an interest rate swap agreement to effectively convert the floating interest rate of its term loan under the Bank of America Credit Facility Agreement to a fixed interest rate of 2.86% per annum through the scheduled maturity of the term loan in June 2023 (see Note 1
4
). The Company did not designate this interest rate swap for hedge accounting.

[0001193125-20-024258:notes:106]
On September 3, 2019, the Company entered into a new term loan agreement under a Credit Facility Agreement with the Bank of Ayudhya Public Company Limited (the “Bank”) (see Note 1
4
) and on September 10, 2019, repaid in full the outstanding term loan under the Bank of America Credit Facility (see Note 1
4
). In conjunction with the funding of the new term loan, the Company entered into a second interest rate swap agreement. The combination of both of these interest rate swaps effectively convert the floating interest rate of the Company’s new term loan with the Bank to a fixed interest rate of 4.36% per annum through the maturity of the term loan in June 2024.

[0001193125-20-024258:notes:107]
On September 27, 2019, the Company designated these two interest rate swaps as a cash flow hedge for the Company’s term loan under the Credit Facility Agreement with the Bank. The combination of these two interest rate swaps qualified for hedge accounting because the hedges are highly effective, and the Company has designated and documented contemporaneously the hedging relationships involving these interest rate swaps. While we intend to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in our earnings. From September 27, 2019, any gains or losses related to these interest rate swaps will be recorded in accumulated other comprehensive income in the unaudited condensed consolidated balance sheets, 
with 
a portion 
reclassified
 from accumulated other comprehensive income into earnings at each reporting period based on either the accrued interest amount or the interest payment.

[0001193125-20-024258:notes:108]
The following table provides a summary of the impacts of derivative gain (loss) of our cash flow hedges on the unaudited condensed consolidated statements of operations and other comprehensive income:

[0001193125-20-024258:notes:109]
|  |  |  |  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands) |  | Financialstatements line item |  |  | December 27, 2019 |  |  | December 28, 2018 |  |  | December 27, 2019 |  |  | December 28, 2018 |  |
| Derivatives gain (loss) recognized in other comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swaps |  |  | Other comprehensive income |  |  | $ | 243 |  |  | $ | — |  |  | $ | 282 |  |  | $ | — |  |
| Derivatives gain (loss) reclassified from other comprehensive income into earnings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swaps |  |  | Interest expense |  |  |  | (432 | ) |  |  | — |  |  |  | (432 | ) |  |  | — |  |

[0001193125-20-024258:notes:110]
During the six months ended December 27, 2019, there was an amortization of the fair value of interest rate swaps as of hedge inception date in the amount of $
0.4 
million due to the application of hedge accounting which results in interest expense reduction.

[0001193125-20-024258:notes:111]
As of December 27, 2019, 
the 
amount in accumulated other comprehensive income which is expected to be reclassified 
into earnings 
within 12 months w
as
 $0.7 million.

[0001193125-20-024258:notes:112]
Prior to September 27, 2019, these interest rate swaps were not designated as cash flow hedges. All changes in the fair value of these interest rate swaps w
ere
 reflected in earnings. During the six months ended December 27, 2019 and December 28, 2018, the Company recorded unrealized loss of $1.7 million and unrealized 
loss
 of $0.8 million, respectively, from changes in the fair value of these interest rate swaps as interest expense in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-20-024258:notes:113]
[same as prior period, unchanged from 0001193125-19-284781:notes:126]

[0001193125-20-024258:notes:114]
[same as prior period, unchanged from 0001193125-19-284781:notes:127]

[0001193125-20-024258:notes:115]
|  |  | December 27, 2019 |  |  | June 28, 2019 |  |
| (amount in thousands) |  | DerivativeAssets |  |  | DerivativeLiabilities |  |  | DerivativeAssets |  |  | DerivativeLiabilities |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | $ | 338 |  |  | $ | (13 | ) |  | $ | 2,201 |  |  | $ | — |  |
| Interest rate swaps |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (2,591 | ) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest rate swaps |  |  | — |  |  |  | (3,980 | ) |  |  | — |  |  |  | — |  |
| Gross amounts of derivatives |  |  | 338 |  |  |  | (3,993 | ) |  | $ | 2,201 |  |  | $ | (2,591 | ) |
| Gross amounts of derivatives offset in the balance sheet |  |  | (13 | ) |  |  | 13 |  |  | $ | — |  |  | $ | — |  |
| Net amounts of derivatives |  | $ | 325 |  |  | $ | (3,980 | ) |  | $ | 2,201 |  |  | $ | (2,591 | ) |

[0001193125-20-024258:notes:116]
The Company presents its derivatives at gross fair values in the unaudited condensed consolidated ​​​​​​​balance sheets. However, the Company’s netting arrangements allow net settlements under certain conditions. Our derivative instruments are typically settled monthly or quarterly.

[0001193125-20-024258:notes:117]
The Company recorded the fair value of derivative financial instruments in the unaudited condensed consolidated ​​​​​​​balance sheets as follows:

[0001193125-20-024258:notes:118]
| Derivative Financial Instruments |  | Balance Sheet Line Item |
| Fair Value of Derivative Assets |  | Other current assets |
| Fair Value of Derivative Liabilities |  | Accrued expenses |


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001193125-20-024258:notes:119]
[same as prior period, unchanged from 0001193125-19-284781:notes:134]

[0001193125-20-024258:notes:120]
| (amount in thousands) |  | As of December 27, 2019 |  |  | As of June 28, 2019 |  |
| Trade accounts receivable |  | $ | 285,680 |  |  | $ | 260,698 |  |
| Less: allowance for doubtful account |  |  | (101 | ) |  |  | (96 | ) |
| Trade accounts receivable, net |  | $ | 285,579 |  |  | $ | 260,602 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-20-024258:notes:121]
| 8. | Inventories |

[0001193125-20-024258:notes:122]
| (amount in thousands) |  | As of December 27, 2019 |  |  | As of June 28, 2019 |  |
| Raw materials |  | $ | 126,599 |  |  | $ | 113,321 |  |
| Work-in-progress |  |  | 138,542 |  |  |  | 141,730 |  |
| Finished goods |  |  | 20,583 |  |  |  | 24,916 |  |
| Goods in transit |  |  | 8,656 |  |  |  | 13,645 |  |
| Inventories |  | $ | 294,380 |  |  | $ | 293,612 |  |


## fn:ScheduleOfOtherReceivableTextBlock

[0001193125-20-024258:notes:123]
| 9. | Other receivable |

[0001193125-20-024258:notes:124]
On October 1, 2019, the Company provided funds in the amount of $
24.3
 million to a customer to support the customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. The customer has agreed to repay this amount by September 30, 2020. This receivable is reflected within investing activities in the statement of cash flows.


## fn:RestrictedCashAndCashEquivalentsTextBlock

[0001193125-20-024258:notes:125]
| 10. | Restricted cash |

[0001193125-20-024258:notes:126]
As of December 27, 2019 and June 28, 2019, the Company had two outstanding standby letters of credit 
in the aggregate amount 
of 6.2 million Euros and one outstanding standby letter of credit of 6.0 million Euros, respectively, related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. As of December 27, 2019 and June 28, 2019, the standby letters of credit were backed by cash collateral of $7.7 million and $7.4 million, respectively.


## fn:ScheduleOfAdoptionOfTopic842OnOperatingLeaseInConsolidateFinancialPositionTableTextBlock

[0001193125-20-024258:notes:127]
Operating leases

[0001193125-20-024258:notes:128]
The Company determines if an arrangement contains a lease at inception. The Company applies the guidance in ASC 842 to determine whether a contract is, or contains, a lease. A contract is or contains a lease if the contract conveys the right to control the use of identified property, plant, or equipment (an identified asset) for a period of time in exchange for consideration. Operating leases are included in operating lease ROU assets and operating lease liabilities within the Company’s unaudited condensed consolidated balance sheets. The Company rents certain real estate under agreements that are classified as operating leases.

[0001193125-20-024258:notes:129]
Operating lease ROU assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at commencement date. As most of the Company’s leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at commencement date in determining the present value of future payments. The operating lease ROU asset also includes any lease payments made and excludes lease incentives and initial direct costs incurred. Variable lease payments are expensed as incurred and are not included within the ROU asset and lease liability calculation. Variable lease payments primarily include reimbursements of costs incurred by lessors for common area maintenance and utilities. The Company’s lease terms may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option. Lease expense for minimum lease payments is recognized on a straight-line basis over the lease term.

[0001193125-20-024258:notes:130]
Leases with an initial term of 12 months or less are not recorded on the balance sheet. The Company recognizes lease expense for these leases on a straight-line basis over the lease term. The Company does not account for lease components (e.g., fixed payments including rent) separately from the 
non-lease
 components (e.g., common-area maintenance costs).

[0001193125-20-024258:notes:131]
[same as prior period, unchanged from 0001193125-19-284781:notes:149]

[0001193125-20-024258:notes:132]
[same as prior period, unchanged from 0001193125-19-284781:notes:150]

[0001193125-20-024258:notes:133]
|  |  | Impact of Adopting ASC 842 |  |
| (amount in thousands) |  | Balance at June 28, 2019 |  |  | Adjustment |  |  | Balance atJune 29, 2019 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating lease ROU assets |  | $ | — |  |  | $ | 5,370 |  |  | $ | 5,370 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating lease liabilities, current |  | $ | — |  |  | $ | 1,601 |  |  | $ | 1,601 |  |
| Operating lease liabilities, non-current |  | $ | — |  |  | $ | 3,769 |  |  | $ | 3,769 |  |


## us-gaap:LesseeOperatingLeaseLiabilityMaturityTableTextBlock

[0001193125-20-024258:notes:134]
As of December 27, 2019, the maturities of the Company’s operating lease liabilities 
were
 as follows:

[0001193125-20-024258:notes:135]
| (amount in thousands) |  |  |  |
| 2020 (remaining six months) |  | $ | 979 |  |
| 2021 |  |  | 2,140 |  |
| 2022 |  |  | 2,007 |  |
| 2023 |  |  | 1,896 |  |
| 2024 |  |  | 846 |  |
| Thereafter |  |  | 294 |  |
| Total undiscounted lease payments |  |  | 8,162 |  |
| Less Imputed interest |  |  | (611 | ) |
| Total present value of lease liabilities |  | $ | 7,551 | (1) |

[0001193125-20-024258:notes:136]
| (1) | Included current portion of operating lease liabilities of $1.8 million. |


## fn:ScheduleOfAdditionalInformationRelatedToOperatingAndFinanceLeaseTableTextBlock

[0001193125-20-024258:notes:137]
As of December 27, 2019, the future minimum lease payments under 
non-cancelable
 capital leases during each fiscal year were as follows:

[0001193125-20-024258:notes:138]
| (amount in thousands) |  |  |  |
| 2020 (remaining six months) |  | $ | 211 |  |
| 2021 |  |  | 105 |  |
| Total minimum capital lease payments |  |  | 316 |  |
| Less: Future finance charge on capital leases |  |  | (5 | ) |
| Present value of capital lease |  | $ | 311 |  |

[0001193125-20-024258:notes:139]
Representing capital lease liabilities

[0001193125-20-024258:notes:140]
| Current |  | $ | 311 |  |
| Non-current |  |  | — |  |
| Total capital lease liabilities |  | $ | 311 |  |

[0001193125-20-024258:notes:141]
As of December 27, 2019, the present ​​​​​​​value of capital leases during each fiscal year was as follows:

[0001193125-20-024258:notes:142]
| (amount in thousands) |  |  |  |
| 2020 (remaining six months) |  | $ | 206 |  |
| 2021 |  |  | 105 |  |
| Present value of capital lease |  | $ | 311 |  |

[0001193125-20-024258:notes:143]
[same as prior period, unchanged from 0001193125-19-284781:notes:159]

[0001193125-20-024258:notes:144]
|  |  | As of December 27, 2019 |  |
| Weighted-average remaining lease term (in years) |  |  |  |  |
| Operating leases |  |  | 4.0 |  |
| Capital leases |  |  | 0.8 |  |
| Weighted-average discount rate |  |  |  |  |
| Operating leases |  |  | 3.8 | % |
| Capital leases |  |  | 4.1 | % |


## fn:ScheduleOfSupplementalCashFlowInformationRelatedToOperatingLeaseTableTextBlock

[0001193125-20-024258:notes:145]
The following information represents supplemental disclosure for the statement of cash flows related to operating and capital leases for the six months ended December 27, 2019:

[0001193125-20-024258:notes:146]
| (amount in thousands) |  | Six Months EndedDecember 27, 2019 |  |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |
| Operating cash flows from operating leases |  | $ | 1,024 |  |
| Financing cash flows from capital leases |  | $ | 189 |  |
| ROU assets obtained in exchange for lease liabilities |  | $ | 7,558 |  |
| Capital lease assets |  | $ | 251 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-20-024258:notes:147]
| 12. | Intangibles |

[0001193125-20-024258:notes:148]
[same as prior period, unchanged from 0001193125-19-284781:notes:164]

[0001193125-20-024258:notes:149]
| (amount in thousands) |  | GrossCarryingAmount |  |  | AccumulatedAmortization |  |  | ForeignCurrencyTranslationAdjustment |  |  | Net |  |
| As of December 27, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 7,319 |  |  | $ | (5,205 | ) |  | $ | — |  |  | $ | 2,114 |  |
| Customer relationships |  |  | 4,373 |  |  |  | (2,405 | ) |  |  | (44 | ) |  |  | 1,924 |  |
| Backlog |  |  | 119 |  |  |  | (119 | ) |  |  | — |  |  |  | — |  |
| Total intangibles |  | $ | 11,811 |  |  | $ | (7,729 | ) |  | $ | (44 | ) |  | $ | 4,038 |  |

[0001193125-20-024258:notes:150]
| (amount in thousands) |  | GrossCarryingAmount |  |  | AccumulatedAmortization |  |  | ForeignCurrencyTranslationAdjustment |  |  | Net |  |
| As of June 28, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 6,582 |  |  | $ | (4,868 | ) |  | $ | — |  |  | $ | 1,714 |  |
| Customer relationships |  |  | 4,373 |  |  |  | (2,096 | ) |  |  | (104 | ) |  |  | 2,173 |  |
| Backlog |  |  | 119 |  |  |  | (119 | ) |  |  | — |  |  |  | — |  |
| Total intangibles |  | $ | 11,074 |  |  | $ | (7,083 | ) |  | $ | (104 | ) |  | $ | 3,887 |  |

[0001193125-20-024258:notes:151]
The Company recorded amortization expense relating to intangibles of $0.3 million and $0.3 million for the three months ended December 27, 2019 and December 28, 2018, respectively, and $0.6 million and $0.6 million for the six months ended December 27, 2019 and December 28, 2018, respectively.

[0001193125-20-024258:notes:152]
The weighted-average remaining life of customer relationships was:

[0001193125-20-024258:notes:153]
| (years) |  | As of December 27,2019 |  |  | As of June 28, 2019 |  |
| Customer relationships |  |  | 5.0 |  |  |  | 5.4 |  |

[0001193125-20-024258:notes:154]
Based on the carrying amount of intangibles as of December 27, 2019, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001193125-20-024258:notes:155]
| (amount in thousands) |  |  |  |
| 2020 (remaining six months) |  | $ | 646 |  |
| 2021 |  |  | 1,164 |  |
| 2022 |  |  | 921 |  |
| 2023 |  |  | 651 |  |
| 2024 |  |  | 419 |  |
| Thereafter |  |  | 237 |  |
| Total |  | $ | 4,038 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-20-024258:notes:156]
| 13. | Goodwill |

[0001193125-20-024258:notes:157]
[same as prior period, unchanged from 0001193125-19-284781:notes:173]

[0001193125-20-024258:notes:158]
| (amount in thousands) |  | Goodwill |  |
| Balance as of June 28, 2019 |  | $ | 3,705 |  |
| Foreign currency translation adjustment |  |  | 93 |  |
| Balance as of December 27, 2019 |  | $ | 3,798 |  |

[0001193125-20-024258:notes:159]
| (amount in thousands) |  | Goodwill |  |
| Balance as of June 29, 2018 |  | $ | 3,828 |  |
| Foreign currency translation adjustment |  |  | (130 | ) |
| Balance as of December 28, 2018 |  | $ | 3,698 |  |

[0001193125-20-024258:notes:160]
[same as prior period, unchanged from 0001193125-19-284781:notes:176]


## us-gaap:DebtDisclosureTextBlock

[0001193125-20-024258:notes:161]
| 14. | Borrowings |

[0001193125-20-024258:notes:162]
The Company’s total borrowings, including current and 
non-current
 portions of long-term borrowings, consisted of the following:

[0001193125-20-024258:notes:163]
| (amount in thousands) |

[0001193125-20-024258:notes:164]
| Rate |  | Conditions |  |  | Maturity |  |  | As of December 27, 2019 |  |  | As of June 28, 2019 |  |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  |  |  |  |  |  | $ | 12,188 |  |  | $ | 3,250 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  |  |  |  |  |  |  | (32 | ) |  |  | — |  |
| Long-term borrowings, current portion, net |  |  |  |  |  | $ | 12,156 |  |  |  | 3,250 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1-month LIBOR +1.50% per annum(1) |  |  | Repayable in quarterly installments |  |  |  | June 2023 |  |  | $ | — |  |  | $ | 60,938 |  |
| 3-month LIBOR +1.35% per annum(1) |  |  | Repayable in quarterly installments |  |  |  | June 2024 |  |  |  | 57,891 |  |  |  | — |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (12,188 | ) |  |  | (3,250 | ) |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  |  |  | (111 | ) |  |  | — |  |
| Long-term borrowings, non-current portion, net |  |  |  |  |  | $ | 45,592 |  |  | $ | 57,688 |  |

[0001193125-20-024258:notes:165]
| (1) | We have entered into interest rate swaps that effectively fix a series of our future interest payments on our term loans. Refer to Note 6. |

[0001193125-20-024258:notes:166]
The movements of long-term borrowings for the six months ended December 27, 2019 and December 28, 2018 were as follows:

[0001193125-20-024258:notes:167]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 27, 2019 |  |  | December 28, 2018 |  |
| Opening balance |  | $ | 60,938 |  |  | $ | 64,188 |  |
| Borrowings during the period |  |  | 60,938 |  |  |  | — |  |
| Repayments during the period |  |  | (63,985 | ) |  |  | (813 | ) |
| Closing balance |  | $ | 57,891 |  |  | $ | 63,375 |  |

[0001193125-20-024258:notes:168]
As of December 27, 2019, future maturities of long-term borrowings during each fiscal year were as follows:

[0001193125-20-024258:notes:169]
| (amount in thousands) |  |  |  |
| 2020 (remaining six months) |  | $ | 6,093 |  |
| 2021 |  |  | 12,188 |  |
| 2022 |  |  | 15,234 |  |
| 2023 |  |  | 12,188 |  |
| 2024 |  |  | 12,188 |  |
| Total |  | $ | 57,891 |  |

[0001193125-20-024258:notes:170]
Credit facility agreements:

[0001193125-20-024258:notes:171]
Bank of Ayudhya Public Company Limited

[0001193125-20-024258:notes:172]
On August 20, 2019, Fabrinet Thailand (the “Borrower”), and

[0001193125-20-024258:notes:173]
Bank of Ayudhya Public Company Limited (

[0001193125-20-024258:notes:174]
the

[0001193125-20-024258:notes:175]
“

[0001193125-20-024258:notes:176]
Bank

[0001193125-20-024258:notes:177]
”)

[0001193125-20-024258:notes:178]
entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai Baht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

[0001193125-20-024258:notes:179]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a Term Loan Agreement pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company’s 
pre-existing
 credit facility agreement between the Company and Bank of America, N.A.

[0001193125-20-024258:notes:180]
The term loan accrues interest at 
3-month LIBOR plus 1.35% and is repayable in quarterly installments of $
3.0 million, commencing on September 30, 2019. The term loan 
will 
mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be 
re-borrowed. 
 During the six months ended December 27, 2019, the Company recorded $0.6 million of interest expense in connection with this term loan.

[0001193125-20-024258:notes:181]
Any borrowings under the Credit Facility Agreement, including those borrowings under the Term Loan Agreement
,
 are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

[0001193125-20-024258:notes:182]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt to equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. At December 27, 2019, the Company was in compliance with all of its covenants under the Term Loan Agreement.

[0001193125-20-024258:notes:183]
The events of default in the Term Loan Agreement include failure to pay amounts due under the Term Loan Agreement or the related finance documents when due, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

[0001193125-20-024258:notes:184]
At December 27, 2019, there was $57.9 million outstanding under the term loan.

[0001193125-20-024258:notes:185]
Bank of America, N.A.

[0001193125-20-024258:notes:186]
On May 22, 2014, the Company and 
a
 consortium of banks entered into a syndicated senior credit facility agreement led by Bank of America (the “Bank of America Facility Agreement”). The Bank of America Facility Agreement provided for a $200.0 million credit line, comprised of a $150.0 million revolving loan facility and a $50.0 million delayed draw term loan facility.

[0001193125-20-024258:notes:187]
From time to time, we amended the Bank of America Facility Agreement, before repaying all outstanding amounts under the agreement and terminating such agreement on September 10, 2019.

[0001193125-20-024258:notes:188]
The most recent amendment on June 4, 2018 (i) reduced the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) refinanced the outstanding amounts under the revolving loan and term loan facilities into a $65.0 million term loan which was to be repaid in quarterly installments through the maturity date of June 4, 2023
, 
and (iii) reduced the interest rate margins and commitment fees. The term loan bore interest, at the Company’s option, at a rate per annum equal to a LIBOR rate plus a spread of 1.50% to 2.25%, or a base rate plus a spread of 0.50% to 1.25%. During the six months ended December 27, 2019 and December 28, 2018, the Company recorded $0.5 million and $1.2 million, respectively, of interest expense in connection with this term loan.

[0001193125-20-024258:notes:189]
On September 10, 2019, the Company fully repaid $61.0 million in principal, accrued interest and other fees under the agreement. The early termination of this agreement did not trigger any early termination fees. At December 27, 2019, there were no amounts outstanding under the Bank of America Facility Agreement. At June 28, 2019, there was $60.9 million outstanding under the Bank of America Facility Agreement, related to the term loan.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-20-024258:notes:190]
| 15. | Income taxes |

[0001193125-20-024258:notes:191]
As of December 27, 2019 and June 28, 2019, the liability for uncertain tax positions including accrued interest and penalties was $1.2 million and $2.1 million, respectively. The Company expects the estimated amount of liability associated with its uncertain tax positions to decrease within the next 12 months due to the lapse of the applicable statute of limitations in foreign tax jurisdictions.

[0001193125-20-024258:notes:192]
The Company files income tax returns in the United States and foreign tax jurisdictions. The tax years from 2013 to 2018 remain open to examination by U.S. federal and state, and foreign tax authorities. The Company’s income tax is recognized based on the best estimate of the expected annual effective tax rate for the full financial year of each entity in the Company, adjusted for discrete items arising in that quarter. If the Company’s estimated annual effective tax rate changes, the Company makes a cumulative adjustment in that quarter.

[0001193125-20-024258:notes:193]
The Company’s effective tax rate for the three months ended December 27, 2019 and December 28, 2018 was 
4.9
% and 
4.2
%, respectively, of net income. The increase was primarily due to the fact that the Company had higher income subject to tax during the three months ended December 27, 2019, compared with the three months ended December 28, 2018.

[0001193125-20-024258:notes:194]
The Company’s effective tax rate for the six months ended December 27, 2019 and December 28, 2018 was 
5.0
% and 
5.1
%, respectively, of net income. The decrease was primarily due to the fact that the Company had lower income subject to tax during the six months ended December 27, 2019 as compared to the six months ended December 28, 2018.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-20-024258:notes:195]
| 16. | Share-based compensation |

[0001193125-20-024258:notes:196]
[same as prior period, unchanged from 0001193125-19-284781:notes:219]

[0001193125-20-024258:notes:197]
[same as prior period, unchanged from 0001193125-19-284781:notes:220]

[0001193125-20-024258:notes:198]
The effect of recording share-based compensation expense for the three and six months ended December 27, 2019 and December 28, 2018 was as follows:

[0001193125-20-024258:notes:199]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands) |  | December 27, 2019 |  |  | December 28, 2018 |  |  | December 27, 2019 |  |  | December 28, 2018 |  |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restricted share units |  |  | 4,186 |  |  |  | 3,344 |  |  |  | 8,584 |  |  |  | 8,029 |  |
| Performance share units |  |  | 2,002 |  |  |  | 625 |  |  |  | 3,599 |  |  |  | 920 |  |
| Total share-based compensation expense |  |  | 6,188 |  |  |  | 3,969 |  |  |  | 12,183 |  |  |  | 8,949 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 6,188 |  |  | $ | 3,969 |  |  | $ | 12,183 |  |  | $ | 8,949 |  |

[0001193125-20-024258:notes:200]
| Share-based compensation expense was recorded in the unaudited condensed consolidated statements of operations and comprehensive income as follows: |

[0001193125-20-024258:notes:201]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands) |  | December 27, 2019 |  |  | December 28, 2018 |  |  | December 27, 2019 |  |  | December 28, 2018 |  |
| Cost of revenue |  | $ | 1,591 |  |  | $ | 1,300 |  |  | $ | 3,311 |  |  | $ | 3,147 |  |
| Selling, general and administrative expense |  |  | 4,597 |  |  |  | 2,669 |  |  |  | 8,872 |  |  |  | 5,802 |  |
| Total share-based compensation expense |  | $ | 6,188 |  |  | $ | 3,969 |  |  | $ | 12,183 |  |  | $ | 8,949 |  |

[0001193125-20-024258:notes:202]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the three and six months ended December 27, 2019 and December 28, 2018.

[0001193125-20-024258:notes:203]
[same as prior period, unchanged from 0001193125-19-284781:notes:226]

[0001193125-20-024258:notes:204]
On December 12, 2019, 
t
he Company’s shareholders approved Fabrinet’s 2020 Equity Incentive Plan (the “2020 Plan”). Upon the approval of the 2020 Plan, Fabrinet’s Amended and Restated 2010 Performance Incentive Plan (the “2010 Plan”) was simultaneously terminated. The 2020 Plan provides for the grant of equity awards thereunder with respect to (i) 1,700,000 ordinary shares, plus (ii) up to 1,300,000 ordinary shares that, as of immediately prior to the termination of the 2010 Plan, had been reserved but not issued pursuant to any awards granted under the 2010 
Plan and are not subject to any awards thereunder.

[0001193125-20-024258:notes:205]
Upon termination of the 2010 Plan, 
1,281,619
 ordinary shares were reserved for issuance under the 2020 Plan pursuant to clause (ii) of the preceding sentence. As of December 27, 2019, there were 
19,044
 restricted share units outstanding and an aggregate of 
2,962,575
 ordinary shares available for future grant under the 2020 Plan.

[0001193125-20-024258:notes:206]
As of December 27, 2019, there were an aggregate of 
801,150

[0001193125-20-024258:notes:207]
restricted share units and 
436,304
 performance share units outstanding. 
No
 ordinary shares are available for future grant under the 2010 Plan.

[0001193125-20-024258:notes:208]
On November 2, 2017, the Company adopted the 2017 Inducement Equity Incentive Plan (the “2017 Inducement Plan”) with a reserve of 
160,000
 ordinary shares authorized for future issuance solely for the granting of inducement share options and equity awards to new employees. The 2017 Inducement Plan was adopted without shareholder approval in reliance on the “employment inducement exemption” provided under the New York Stock Exchange Listed Company Manual. As of December 27, 2019, there were an aggregate of 
24,327
 restricted share units outstanding and 111,347 ordinary shares available for future grant under the 2017 Inducement Plan.

[0001193125-20-024258:notes:209]
The 2010 Plan, 2017 Inducement Plan, and 2020 Plan are collectively referred to as the “Equity Incentive Plans.”

[0001193125-20-024258:notes:210]
[same as prior period, unchanged from 0001193125-19-284781:notes:232]

[0001193125-20-024258:notes:211]
Restricted share units and performance share units have been granted under the 2010 Plan
,
 the 2017 Inducement Plan

[0001193125-20-024258:notes:212]
, and the 2020 Plan

[0001193125-20-024258:notes:213]
.

[0001193125-20-024258:notes:214]
Restricted share units granted to employees generally vest in equal installments over three or four years on each anniversary of the vesting commencement date. Restricted share units granted to 
non-employee
 directors generally cliff vest 100% on the first of January, approximately one year from the grant date, provided the director continues to serve through such date.

[0001193125-20-024258:notes:215]
Performance share units granted to executives will vest, if at all, at the end of a 
two-year
 performance period based on the Company’s achievement of 
pre-defined
 performance criteria, which consist of revenue and 
non-GAAP 
gross margin 
of non-
GAAP operating margin

[0001193125-20-024258:notes:216]
targets. The actual number of performance share units that may vest at the end of the performance period ranges from 0% to 100% of the award grant.

[0001193125-20-024258:notes:217]
[same as prior period, unchanged from 0001193125-19-284781:notes:237]

[0001193125-20-024258:notes:218]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 28, 2019 |  |  | 800,751 |  |  | $ | 42.48 |  |
| Granted |  |  | 331,900 |  |  | $ | 49.78 |  |
| Issued |  |  | (264,275 | ) |  | $ | 39.60 |  |
| Forfeited |  |  | (23,855 | ) |  | $ | 42.09 |  |
| Balance as of December 27, 2019 |  |  | 844,521 |  |  | $ | 46.26 |  |
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 29, 2018 |  |  | 1,073,580 |  |  | $ | 35.19 |  |
| Granted |  |  | 305,836 |  |  | $ | 48.33 |  |
| Issued |  |  | (393,142 | ) |  | $ | 34.40 |  |
| Forfeited |  |  | (69,075 | ) |  | $ | 38.53 |  |
| Balance as of December 28, 2018 |  |  | 917,799 |  |  | $ | 39.65 |  |

[0001193125-20-024258:notes:219]
[same as prior period, unchanged from 0001193125-19-284781:notes:240]

[0001193125-20-024258:notes:220]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 28, 2019 |  |  | 548,500 |  |  | $ | 40.97 |  |
| Granted |  |  | 238,474 |  |  | $ | 48.39 |  |
| Issued |  |  | — |  |  |  | — |  |
| Forfeited |  |  | (350,670 | ) |  | $ | 36.99 |  |
| Balance as of December 27, 2019 |  |  | 436,304 |  |  | $ | 48.22 |  |

[0001193125-20-024258:notes:221]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 29, 2018 |  |  | 605,892 |  |  | $ | 38.41 |  |
| Granted |  |  | 201,994 |  |  | $ | 48.02 |  |
| Issued |  |  | (227,268 | ) |  | $ | 40.48 |  |
| Forfeited |  |  | (27,954 | ) |  | $ | 39.35 |  |
| Balance as of December 28, 2018 |  |  | 552,664 |  |  | $ | 41.02 |  |

[0001193125-20-024258:notes:222]
[same as prior period, unchanged from 0001193125-19-284781:notes:243]

[0001193125-20-024258:notes:223]
As of December 27, 2019, there was $18.3 million and $9.3 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.7 years and 1.5 years, respectively.

[0001193125-20-024258:notes:224]
For the six months ended December 27, 2019 and December 28, 2018, the Company withheld an aggregate of 86,138 shares and 205,984 shares, respectively, upon the vesting of restricted share units, based upon the closing share price on the vesting date to settle the employees’ minimum statutory obligation for the applicable income and other employment taxes. For the six months ended December 27, 2019 and December 28, 2018, the Company then remitted cash of $4.4 million and $9.1 million, respectively, to the appropriate taxing authorities, and presented it as a financing activity within the unaudited condensed consolidated statements of cash flows. The payment was recorded as a reduction of additional 
paid-in
 capital.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-20-024258:notes:225]
| 17. | Shareholders’ equity |

[0001193125-20-024258:notes:226]
[same as prior period, unchanged from 0001193125-19-284781:notes:249]

[0001193125-20-024258:notes:227]
The Company’s

[0001193125-20-024258:notes:228]
authorized share capital is 500,000,000 ordinary shares, par value of $0.01 per ordinary share, and 5,000,000 preferred shares, par value of $0.01 per preferred share.

[0001193125-20-024258:notes:229]
For the three

[0001193125-20-024258:notes:230]
and six

[0001193125-20-024258:notes:231]
months ended December 27, 2019,

[0001193125-20-024258:notes:232]
the Company

[0001193125-20-024258:notes:233]
issued 19,762 
and 178,137 
ordinary shares

[0001193125-20-024258:notes:234]
, respectively
,

[0001193125-20-024258:notes:235]
upon the vesting of restricted share units, net of shares withheld

[0001193125-20-024258:notes:236]
months ended December 28, 2018,

[0001193125-20-024258:notes:237]
issued 19,278

[0001193125-20-024258:notes:238]
and 
414,426
 ordinary shares, respectively,

[0001193125-20-024258:notes:239]
[same as prior period, unchanged from 0001193125-19-284781:notes:253]

[0001193125-20-024258:notes:240]
[same as prior period, unchanged from 0001193125-19-284781:notes:254]

[0001193125-20-024258:notes:241]
In August 2017, the Company’s board of directors approved a share repurchase program to permit the Company to repurchase up to $
30.0 
million worth of its issued and outstanding ordinary shares in the open market in accordance with applicable rules and regulations. In February 2018 and May 2019, the Company’s board of directors approved an increase of $
30.0 
million and $
50 
million, respectively, to the original share repurchase authorization, bringing

[0001193125-20-024258:notes:242]
the aggregate authorization to $110.0 million. During the three and six months ended December 27, 2019, no shares were repurchased under the program. As of December 27, 2019, the Company had a remaining authorization to purchase up to $62.2 million worth of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shar
e
s.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-20-024258:notes:243]
| 18. | Accumulated other comprehensive income (loss) (“AOCI”) |

[0001193125-20-024258:notes:244]
The changes in AOCI for the six months ended December 27, 2019 and December 28, 2018 were as follows:

[0001193125-20-024258:notes:245]
| (amount in thousands) |  | Unrealized net (Losses)/Gains on Available-for-sale Securities |  |  | Unrealized net (Losses)/Gains on Derivative Instruments |  |  | Retirement benefit plan - Prior service cost |  |  | Foreign Currency Translation Adjustment |  |  | Total |  |
| Balance as of June 28, 2019 |  | $ | 952 |  |  | $ | 32 |  |  |  | (2,537 | ) |  | $ | (833 | ) |  | $ | (2,386 | ) |
| Other comprehensive income before reclassification adjustment |  |  | (126 | ) |  |  | (150 | ) |  |  | 184 |  |  |  | 247 |  |  |  | 155 |  |
| Amounts reclassified out of AOCI to foreign exchange loss in the unaudited condensed consolidated statements of operations and comprehensive income |  |  | 79 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 79 |  |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income (loss) |  | $ | (47 | ) |  | $ | (150 | ) |  |  | 184 |  |  | $ | 247 |  |  | $ | 234 |  |
| Balance as of December 27, 2019 |  | $ | 905 |  |  | $ | (118 | ) |  |  | (2,353 | ) |  | $ | (586 | ) |  | $ | (2,152 | ) |
| (amount in thousands) |  | Unrealized net (Losses)/Gains on Available-for-sale Securities |  |  | Unrealized net (Losses)/Gains on Derivative Instruments |  |  | Retirement benefit plan - Prior service cost |  |  | Foreign Currency Translation Adjustment |  |  | Total |  |
| Balance as of June 29, 2018 |  | $ | (1,091 | ) |  | $ | 33 |  |  |  | — |  |  | $ | (199 | ) |  | $ | (1,257 | ) |
| Other comprehensive income before reclassification adjustment |  |  | 1,947 |  |  |  | — |  |  |  | — |  |  |  | (705 | ) |  |  | 1,242 |  |
| Amounts reclassified out of AOCI to foreign exchange loss in the unaudited condensed consolidated statements of operations and comprehensive income |  |  | (1,061 | ) |  |  | (1 | ) |  |  | — |  |  |  | — |  |  |  | (1,062 | ) |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income (loss) |  | $ | 886 |  |  | $ | (1 | ) |  |  | — |  |  | $ | (705 | ) |  | $ | 180 |  |
| Balance as of December 28, 2018 |  | $ | (205 | ) |  | $ | 32 |  |  |  | — |  |  | $ | (904 | ) |  | $ | (1,077 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-20-024258:notes:246]
| 19. | Commitments and contingencies |

[0001193125-20-024258:notes:247]
Letter of credit and Bank guarantees

[0001193125-20-024258:notes:248]
As of December 27, 2019 
and
 June 28, 2019,

[0001193125-20-024258:notes:249]
the Company had two outstanding standby letters of credit 
in the aggregate amount 
of 6.2 million Euros

[0001193125-20-024258:notes:250]
and
 one outstanding standby letter of credit of 6.0 million Euros
, respectively,
 related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand.

[0001193125-20-024258:notes:251]
As of December 27, 2019 and June 28, 2019, these

[0001193125-20-024258:notes:252]
standby letter
s
 of credit w
ere
 backed by cash collateral

[0001193125-20-024258:notes:253]
in the aggregate amount

[0001193125-20-024258:notes:254]
of

[0001193125-20-024258:notes:255]
$
7.7 
million and $
7.4
 million, respectively.

[0001193125-20-024258:notes:256]
As of December 27, 2019 and June 28, 2019, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business amounting to $1.7 million and $1.6 million, respectively, and there were other bank guarantees given by a bank on behalf of our subsidiaries in China and the United Kingdom to support their operations of $0.1 
million 
and $26 thousand, respectively.

[0001193125-20-024258:notes:257]
Purchase obligations

[0001193125-20-024258:notes:258]
Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001193125-20-024258:notes:259]
As of December 27, 2019, the Company had an outstanding commitment to third parties of $10.1 million.

[0001193125-20-024258:notes:260]
Indemnification of directors and officers

[0001193125-20-024258:notes:261]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001193125-20-024258:notes:262]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-20-024258:notes:263]
| 20. | Business segments and geographic information |

[0001193125-20-024258:notes:264]
Operating segments are defined as components of an enterprise for which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. The Company’s chief​​​​​​​ operating decision maker is Fabrinet’s Chief Executive Officer. As of December 27, 2019, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001193125-20-024258:notes:265]
Total revenues are attributed to a particular geographic area based on the 
bill-to-location
 of the Company’s customers. The Company operates in three geographic regions: North America, Asia-Pacific and Europe.

[0001193125-20-024258:notes:266]
The following table presents total revenues by geographic​​​​​​​ region:

[0001193125-20-024258:notes:267]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands) |  | December 27,2019 |  |  | December 28,2018 |  |  | December 27, 2019 |  |  | December 28, 2018 |  |
| North America |  | $ | 223,398 |  |  | $ | 182,698 |  |  | $ | 424,345 |  |  | $ | 362,524 |  |
| Asia-Pacific |  |  | 141,147 |  |  |  | 166,711 |  |  |  | 259,570 |  |  |  | 318,658 |  |
| Europe |  |  | 61,672 |  |  |  | 53,671 |  |  |  | 141,598 |  |  |  | 99,075 |  |
|  |  | $ | 426,217 |  |  | $ | 403,080 |  |  | $ | 825,513 |  |  | $ | 780,257 |  |

[0001193125-20-024258:notes:268]
As of December 27, 2019 and December 28, 2018, the Company had approximately $30.0 million and $32.3 million, respectively, of long-lived assets based in North America, with the substantial remainder of assets based in Asia-Pacific and Europe.

[0001193125-20-024258:notes:269]
[same as prior period, unchanged from 0001193125-19-284781:notes:292]

[0001193125-20-024258:notes:270]
The Company had three 
and 
two
​​​​​​​ 
customers that

[0001193125-20-024258:notes:271]
individually

[0001193125-20-024258:notes:272]
contributed 10% or more of its total trade accounts receivable as of

[0001193125-20-024258:notes:273]
December 27, 2019 and June 28, 2019, respectively.
