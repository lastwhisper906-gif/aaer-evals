# FN 8-K — 0001193125-20-022972 filed 2020-02-03

## item codes, every 8-K on or before 2020-02-04

- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2020-02-04

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-20-022972:8k_2_02:1]
EX-99.1
3
d878793dex991.htm
EX-99.1

[0001193125-20-022972:8k_2_02:2]
EX-99.1

[0001193125-20-022972:8k_2_02:3]
Exhibit 99.1

[0001193125-20-022972:8k_2_02:4]
Fabrinet Announces Second Quarter Fiscal Year 2020 Financial Results

[0001193125-20-022972:8k_2_02:5]
Csaba Sverha to Succeed TS Ng as Chief Financial Officer

[0001193125-20-022972:8k_2_02:6]
BANGKOK, Thailand – February 3, 2020 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision
optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its second quarter ended December 27, 2019.

[0001193125-20-022972:8k_2_02:7]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “Our second quarter revenue and earnings exceeded our guidance ranges. Sequential growth across
nearly all our markets resulted in a record quarterly revenue performance. We expect to see continued year-over-year growth in the third quarter, even after considering the impact of the coronavirus outbreak in our guidance. From a longer-term
perspective, our ongoing market momentum makes us very optimistic about our ability to continue to drive profitable growth and reinforce our leadership position in the market.”

[0001193125-20-022972:8k_2_02:8]
Second Quarter Fiscal Year 2020 Financial Highlights

[0001193125-20-022972:8k_2_02:9]
GAAP Results

[0001193125-20-022972:8k_2_02:10]
|  | • |  | Revenue for the second quarter of fiscal year 2020 was $426.2 million, compared to revenue of $403.1 million for the comparable period in fiscal year 2019. |

[0001193125-20-022972:8k_2_02:11]
|  | • |  | GAAP net income for the second quarter of fiscal year 2020 was $31.2 million, compared to GAAP net income of $31.5 million for the second quarter of fiscal year 2019. GAAP net income for the second quarter of fiscal year 2020 included a foreign exchange loss of $1.0 million, or $0.03 per diluted share, compared to a foreign exchange loss of $0.4 million, or $0.01 per diluted share, for the second quarter of fiscal year 2019. |

[0001193125-20-022972:8k_2_02:12]
|  | • |  | GAAP net income per diluted share for the second quarter of fiscal year 2020 was $0.83, compared to GAAP net income per diluted share of $0.84 for the second quarter of fiscal year 2019. |

[0001193125-20-022972:8k_2_02:13]
Non-GAAP
Results

[0001193125-20-022972:8k_2_02:14]
|  | • |  | Non-GAAP net income for the second quarter of fiscal year 2020 was $37.7 million, compared to non-GAAP net income of $36.5 million for the second quarter of fiscal year 2019. Non-GAAP net income for the second quarter of fiscal year 2020 included a foreign exchange loss of $1.0 million, or $0.03 per diluted share, compared to a foreign exchange loss of $0.4 million, or $0.01 per diluted share, for the second quarter of fiscal year 2019. |

[0001193125-20-022972:8k_2_02:15]
|  | • |  | Non-GAAP net income per diluted share for the second quarter of fiscal year 2020 was $1.00, compared to non-GAAP net income per diluted share of $0.97 for the same period a year ago. |

[0001193125-20-022972:8k_2_02:16]
Csaba Sverha Named Chief Financial Officer

[0001193125-20-022972:8k_2_02:17]
Fabrinet has
named Csaba Sverha to succeed Toh-Seng (“TS”) Ng as Chief Financial Officer, effective February 17, 2020, as part of a CFO search that was announced in August 2018. Mr. Sverha currently holds the position of Vice President of
Operations Finance at Fabrinet, having joined the company in March 2018, after 13 years at Sanmina in roles of increasing responsibility, most recently as Vice President of Finance & Controller for Sanmina Mechanical Systems Division.

[0001193125-20-022972:8k_2_02:18]
Mr. Grady added, “We are very grateful to TS for his contributions to Fabrinet over the past 13
years, including serving as Chief Financial Officer since 2012. We are excited that Csaba Sverha will be stepping up to the role of CFO, completing our CFO search. Csaba brings a wealth of financial operations experience to the role enabling us to
extend our strong reputation for financial stewardship and track record of success under TS’ leadership. TS will be serving as EVP, Special Projects reporting to me to help transition the CFO role before he retires in February 2021.”

[0001193125-20-022972:8k_2_02:19]
Business Outlook

[0001193125-20-022972:8k_2_02:20]
Based on information available as of
February 3, 2020, Fabrinet is issuing guidance for its third fiscal quarter of 2020 ending March 27, 2020, as follows:

[0001193125-20-022972:8k_2_02:21]
|  | • |  | Fabrinet expects third quarter revenue to be in the range of $410 million to $418 million. |

[0001193125-20-022972:8k_2_02:22]
|  | • |  | GAAP net income per diluted share is expected to be in the range of $0.75 to $0.78, based on approximately 37.9 million fully diluted shares outstanding. |

[0001193125-20-022972:8k_2_02:23]
|  | • |  | Non-GAAP net income per diluted share is expected to be in the range of $0.92 to $0.95, based on approximately 37.9 million fully diluted shares outstanding. |

[0001193125-20-022972:8k_2_02:24]
Conference Call Information

[0001193125-20-022972:8k_2_02:25]
| What: |  | Fabrinet Second Quarter Fiscal-Year 2020 Financial Results Call |
| When: |  | Monday, February 3, 2020 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic (253) 237-1137, international Passcode: 1607729 |
| Replay: |  | (855) 859-2056, domestic (404) 537-3406, international Passcode: 1607729 |
| Webcast: |  | http://investor.fabrinet.com/ (live and replay) |

[0001193125-20-022972:8k_2_02:26]
This press release and any other information related to the call will also be posted on Fabrinet’s website at
http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-20-022972:8k_2_02:27]
About Fabrinet

[0001193125-20-022972:8k_2_02:28]
Fabrinet is a leading provider of
advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive
components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain
management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities
in Thailand, the United States of America, the People’s Republic of China and the United Kingdom. For more information visit: www.fabrinet.com.

[0001193125-20-022972:8k_2_02:29]
Forward-Looking Statements

[0001193125-20-022972:8k_2_02:30]
Use of Non-GAAP Financials

[0001193125-20-022972:8k_2_02:31]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful
supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; depreciation of fair value uplift; severance payments; expenses related
to our CFO search; amortization of intangibles; business combination expenses; amortization of deferred debt issuance costs; expenses related to reduction in workforce; and ASC 606 adjustments. We have excluded these items in order to enhance
investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to
their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001193125-20-022972:8k_2_02:32]
These non-GAAP financial measures are used to: (1) measure company performance against historical results,
(2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001193125-20-022972:8k_2_02:33]
SOURCE: Fabrinet

[0001193125-20-022972:8k_2_02:34]
Investor Contact:

[0001193125-20-022972:8k_2_02:35]
Garo Toomajanian

[0001193125-20-022972:8k_2_02:36]
ir@fabrinet.com

[0001193125-20-022972:8k_2_02:37]
FABRINET

[0001193125-20-022972:8k_2_02:38]
CONDENSED CONSOLIDATED BALANCE SHEETS (unaudited)

[0001193125-20-022972:8k_2_02:39]
| (in thousands of U.S. dollars, except share data and par value) |  | December 27,2019 |  |  | June 28,2019 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 220,031 |  |  | $ | 180,839 |  |
| Short-term restricted cash |  |  | 272 |  |  |  | — |  |
| Short-term investments |  |  | 222,805 |  |  |  | 256,493 |  |
| Trade accounts receivable, net |  |  | 285,579 |  |  |  | 260,602 |  |
| Contract assets |  |  | 11,114 |  |  |  | 12,447 |  |
| Inventories |  |  | 294,380 |  |  |  | 293,612 |  |
| Other receivable |  |  | 24,310 |  |  |  | — |  |
| Prepaid expenses |  |  | 4,919 |  |  |  | 8,827 |  |
| Other current assets |  |  | 7,416 |  |  |  | 11,015 |  |
| Total current assets |  |  | 1,070,826 |  |  |  | 1,023,835 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Long-term restricted cash |  |  | 7,402 |  |  |  | 7,402 |  |
| Property, plant and equipment, net |  |  | 217,038 |  |  |  | 210,686 |  |
| Intangibles, net |  |  | 4,038 |  |  |  | 3,887 |  |
| Operating right-of-use assets |  |  | 7,558 |  |  |  | — |  |
| Goodwill |  |  | 3,798 |  |  |  | 3,705 |  |
| Deferred tax assets |  |  | 4,115 |  |  |  | 5,679 |  |
| Other non-current assets |  |  | 253 |  |  |  | 124 |  |
| Total non-current assets |  |  | 244,202 |  |  |  | 231,483 |  |
| Total Assets |  | $ | 1,315,028 |  |  | $ | 1,255,318 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion, net |  | $ | 12,156 |  |  | $ | 3,250 |  |
| Trade accounts payable |  |  | 234,929 |  |  |  | 257,617 |  |
| Contract liabilities |  |  | 2,360 |  |  |  | 2,239 |  |
| Capital lease liability, current portion |  |  | 311 |  |  |  | 398 |  |
| Operating lease liability, current portion |  |  | 1,823 |  |  |  | — |  |
| Income tax payable |  |  | 3,137 |  |  |  | 1,801 |  |
| Accrued payroll, bonus and related expenses |  |  | 15,942 |  |  |  | 16,510 |  |
| Accrued expenses |  |  | 11,338 |  |  |  | 8,997 |  |
| Other payables |  |  | 31,384 |  |  |  | 22,236 |  |
| Total current liabilities |  |  | 313,380 |  |  |  | 313,048 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term borrowings, non-current portion, net |  |  | 45,592 |  |  |  | 57,688 |  |
| Deferred tax liability |  |  | 3,543 |  |  |  | 3,561 |  |
| Capital lease liability, non-current portion |  |  | — |  |  |  | 102 |  |
| Operating lease liabilities, non-current portion |  |  | 5,728 |  |  |  | — |  |
| Severance liabilities |  |  | 16,735 |  |  |  | 15,209 |  |
| Other non-current liabilities |  |  | 1,723 |  |  |  | 2,611 |  |
| Total non-current liabilities |  |  | 73,321 |  |  |  | 79,171 |  |
| Total Liabilities |  |  | 386,701 |  |  |  | 392,219 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of December 27, 2019 and June 28, 2019) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 38,408,890 shares and 38,230,753 shares issued at December 27, 2019 and June 28, 2019, respectively; and 37,019,787 shares and 36,841,650 shares outstanding at December 27, 2019 and June 28, 2019, respectively) |  |  | 384 |  |  |  | 382 |  |
| Additional paid-in capital |  |  | 166,103 |  |  |  | 158,299 |  |
| Less: Treasury shares, at cost (1,389,103 shares and 1,389,103shares as of December 27, 2019 and June 28, 2019, respectively) |  |  | (47,779 | ) |  |  | (47,779 | ) |
| Accumulated other comprehensive loss |  |  | (2,152 | ) |  |  | (2,386 | ) |
| Retained earnings |  |  | 811,771 |  |  |  | 754,583 |  |
| Total Shareholders’ Equity |  |  | 928,327 |  |  |  | 863,099 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 1,315,028 |  |  | $ | 1,255,318 |  |

[0001193125-20-022972:8k_2_02:40]
FABRINET

[0001193125-20-022972:8k_2_02:41]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME (unaudited)

[0001193125-20-022972:8k_2_02:42]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (in thousands of U.S. dollars, except per share data) |  | December 27,2019 |  |  | December 28,2018 |  |  | December 27,2019 |  |  | December 28,2018 |  |
| Revenues |  | $ | 426,217 |  |  | $ | 403,080 |  |  | $ | 825,513 |  |  | $ | 780,257 |  |
| Cost of revenues |  |  | (377,059 | ) |  |  | (357,516 | ) |  |  | (730,368 | ) |  |  | (694,417 | ) |
| Gross profit |  |  | 49,158 |  |  |  | 45,564 |  |  |  | 95,145 |  |  |  | 85,840 |  |
| Selling, general and administrative expenses |  |  | (17,078 | ) |  |  | (12,727 | ) |  |  | (33,078 | ) |  |  | (27,164 | ) |
| Expenses related to reduction in workforce |  |  | (16 | ) |  |  | (319 | ) |  |  | (16 | ) |  |  | (404 | ) |
| Operating income |  |  | 32,064 |  |  |  | 32,518 |  |  |  | 62,051 |  |  |  | 58,272 |  |
| Interest income |  |  | 1,940 |  |  |  | 1,182 |  |  |  | 4,038 |  |  |  | 2,626 |  |
| Interest expense |  |  | (181 | ) |  |  | (1,616 | ) |  |  | (2,574 | ) |  |  | (2,250 | ) |
| Foreign exchange (loss) gain, net |  |  | (988 | ) |  |  | (421 | ) |  |  | (2,941 | ) |  |  | 2,647 |  |
| Other income, net |  |  | 397 |  |  |  | 562 |  |  |  | 774 |  |  |  | 639 |  |
| Income before income taxes |  |  | 33,232 |  |  |  | 32,225 |  |  |  | 61,348 |  |  |  | 61,934 |  |
| Income tax expense |  |  | (2,001 | ) |  |  | (712 | ) |  |  | (4,160 | ) |  |  | (2,571 | ) |
| Net income |  |  | 31,231 |  |  |  | 31,513 |  |  |  | 57,188 |  |  |  | 59,363 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in net unrealized (loss) gain on available-for-sale securities |  |  | (82 | ) |  |  | 598 |  |  |  | (47 | ) |  |  | 886 |  |
| Change in net unrealized loss on derivative instruments |  |  | (189 | ) |  |  | — |  |  |  | (150 | ) |  |  | (1 | ) |
| Change in net retirement benefits plan—prior service cost |  |  | 101 |  |  |  | — |  |  |  | 184 |  |  |  | — |  |
| Change in foreign currency translation adjustment |  |  | 616 |  |  |  | (505 | ) |  |  | 247 |  |  |  | (705 | ) |
| Total other comprehensive income, net of tax |  |  | 446 |  |  |  | 93 |  |  |  | 234 |  |  |  | 180 |  |
| Net comprehensive income |  | $ | 31,677 |  |  | $ | 31,606 |  |  | $ | 57,422 |  |  | $ | 59,543 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.84 |  |  | $ | 0.86 |  |  | $ | 1.55 |  |  | $ | 1.62 |  |
| Diluted |  | $ | 0.83 |  |  | $ | 0.84 |  |  | $ | 1.52 |  |  | $ | 1.59 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |
| Basic |  |  | 37,011 |  |  |  | 36,841 |  |  |  | 36,962 |  |  |  | 36,733 |  |
| Diluted |  |  | 37,763 |  |  |  | 37,471 |  |  |  | 37,646 |  |  |  | 37,305 |  |

[0001193125-20-022972:8k_2_02:43]
FABRINET

[0001193125-20-022972:8k_2_02:44]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited)

[0001193125-20-022972:8k_2_02:45]
|  |  | Six Months Ended |  |
| (in thousands of U.S. dollars) |  | December 27,2019 |  |  | December 28,2018 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income for the period |  | $ | 57,188 |  |  | $ | 59,363 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 15,279 |  |  |  | 15,000 |  |
| Loss on disposal of property, plant and equipment |  |  | 242 |  |  |  | 528 |  |
| Loss on disposal of intangibles |  |  | — |  |  |  | 149 |  |
| (Gain) loss from sales and maturities of available-for-sale securities |  |  | (79 | ) |  |  | 1,060 |  |
| Amortization of investment discount (premium) |  |  | 117 |  |  |  | (533 | ) |
| Amortization of deferred debt issuance costs |  |  | 10 |  |  |  | — |  |
| Allowance for doubtful accounts |  |  | 6 |  |  |  | — |  |
| Unrealized loss (gain) on exchange rate and fair value of foreign currency forward contracts |  |  | 1,205 |  |  |  | (5,775 | ) |
| Unrealized loss (gain) on fair value of interest rate swaps |  |  | 1,672 |  |  |  | 849 |  |
| Amortization of interest rate swaps’ fair value at hedge inception |  |  | (433 | ) |  |  | — |  |
| Share-based compensation |  |  | 12,183 |  |  |  | 8,949 |  |
| Deferred income tax |  |  | 1,543 |  |  |  | 481 |  |
| Severance liabilities |  |  | 2,015 |  |  |  | 1,339 |  |
| Other non-cash expenses |  |  | (851 | ) |  |  | (759 | ) |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | (24,970 | ) |  |  | (14,381 | ) |
| Contract assets |  |  | 1,333 |  |  |  | (3,459 | ) |
| Inventories |  |  | (767 | ) |  |  | (28,880 | ) |
| Other current assets and non-current assets |  |  | 7,471 |  |  |  | 2,128 |  |
| Trade accounts payable |  |  | (22,816 | ) |  |  | 29,276 |  |
| Contract liabilities |  |  | 121 |  |  |  | — |  |
| Income tax payable |  |  | 1,336 |  |  |  | 1,859 |  |
| Other current liabilities and non-current liabilities |  |  | 805 |  |  |  | 2,104 |  |
| Net cash provided by operating activities |  |  | 52,610 |  |  |  | 69,298 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of short-term investments |  |  | (101,727 | ) |  |  | (82,141 | ) |
| Proceeds from sales of short-term investments |  |  | 72,664 |  |  |  | 70,472 |  |
| Proceeds from maturities of short-term investments |  |  | 62,666 |  |  |  | 34,788 |  |
| Other receivable provided to customer |  |  | (24,310 | ) |  |  | — |  |
| Purchase of property, plant and equipment |  |  | (15,411 | ) |  |  | (9,732 | ) |
| Purchase of intangibles |  |  | (808 | ) |  |  | (251 | ) |
| Proceeds from disposal of property, plant and equipment |  |  | 1,195 |  |  |  | 5 |  |
| Net cash (used in) provided by investing activities |  |  | (5,731 | ) |  |  | 13,141 |  |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Payment of debt issuance costs |  |  | (153 | ) |  |  | — |  |
| Proceeds from long-term borrowings |  |  | 60,938 |  |  |  | — |  |
| Repayment of long-term borrowings |  |  | (63,985 | ) |  |  | (813 | ) |
| Repayment of capital lease liability |  |  | (189 | ) |  |  | (255 | ) |
| Release of restricted cash held in connection with business acquisition |  |  | — |  |  |  | (3,478 | ) |
| Withholding tax related to net share settlement of restricted share units |  |  | (4,377 | ) |  |  | (9,103 | ) |
| Net cash used in financing activities |  |  | (7,766 | ) |  |  | (13,649 | ) |
| Net increase in cash, cash equivalents and restricted cash |  |  | 39,113 |  |  |  | 68,790 |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 188,241 |  |  |  | 161,433 |  |
| Increase in cash, cash equivalents and restricted cash |  |  | 39,113 |  |  |  | 68,790 |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash |  |  | 351 |  |  |  | 773 |  |
| Cash, cash equivalents and restricted cash at end of period |  | $ | 227,705 |  |  | $ | 230,996 |  |
| Non-cash investing and financing activities |  |  |  |  |  |  |  |  |
| Construction, software and equipment-related payables |  | $ | 14,307 |  |  | $ | 2,888 |  |

[0001193125-20-022972:8k_2_02:46]
FABRINET

[0001193125-20-022972:8k_2_02:47]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (CONTINUED)

[0001193125-20-022972:8k_2_02:48]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the unaudited condensed consolidated balance
sheets that sum to the total of the same amounts shown in the unaudited condensed consolidated statements of cash flows:

[0001193125-20-022972:8k_2_02:49]
| (amount in thousands) |  | As ofDecember 27,2019 |  |  | As ofDecember 28,2018 |  |
| Cash and cash equivalents |  | $ | 220,031 |  |  | $ | 230,996 |  |
| Restricted cash |  |  | 7,674 |  |  |  | — |  |
| Cash, cash equivalents and restricted cash |  | $ | 227,705 |  |  | $ | 230,996 |  |

[0001193125-20-022972:8k_2_02:50]
FABRINET

[0001193125-20-022972:8k_2_02:51]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-20-022972:8k_2_02:52]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 27,2019 |  |  | December 28,2018 |  |  | December 27,2019 |  |  | December 28,2018 |  |
| (in thousands of U.S. dollars, except per share data) |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |
| GAAP measures |  |  | 31,231 |  |  |  | 0.83 |  |  |  | 31,513 |  |  |  | 0.84 |  |  |  | 57,188 |  |  |  | 1.52 |  |  |  | 59,363 |  |  |  | 1.59 |  |
| Items reconciling GAAP net (loss) income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,591 |  |  |  | 0.04 |  |  |  | 1,300 |  |  |  | 0.03 |  |  |  | 3,311 |  |  |  | 0.09 |  |  |  | 3,147 |  |  |  | 0.08 |  |
| Depreciation of fair value uplift |  |  | 82 |  |  |  | 0.00 |  |  |  | 84 |  |  |  | 0.00 |  |  |  | 161 |  |  |  | 0.00 |  |  |  | 173 |  |  |  | 0.00 |  |
| ASC 606 adoption impact on gross profit |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (31 | ) |  |  | (0.00 | ) |
| Total related to gross profit |  |  | 1,673 |  |  |  | 0.04 |  |  |  | 1,384 |  |  |  | 0.04 |  |  |  | 3,472 |  |  |  | 0.09 |  |  |  | 3,289 |  |  |  | 0.09 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 4,597 |  |  |  | 0.12 |  |  |  | 2,669 |  |  |  | 0.07 |  |  |  | 8,872 |  |  |  | 0.24 |  |  |  | 5,802 |  |  |  | 0.16 |  |
| Expenses related to CFO search |  |  | — |  |  |  | — |  |  |  | 382 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 572 |  |  |  | 0.02 |  |
| Amortization of intangibles |  |  | 143 |  |  |  | 0.00 |  |  |  | 176 |  |  |  | 0.00 |  |  |  | 286 |  |  |  | 0.01 |  |  |  | 368 |  |  |  | 0.01 |  |
| Business combination expenses and consulting fee |  |  | — |  |  |  | — |  |  |  | 58 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |  |  | 240 |  |  |  | 0.01 |  |
| Severance payment |  |  | — |  |  |  | — |  |  |  | 16 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |  |  | 601 |  |  |  | 0.02 |  |
| Total related to selling, general and administrative expenses |  |  | 4,740 |  |  |  | 0.13 |  |  |  | 3,301 |  |  |  | 0.09 |  |  |  | 9,158 |  |  |  | 0.24 |  |  |  | 7,583 |  |  |  | 0.20 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other expenses in relation to reduction in workforce |  |  | 16 |  |  |  | 0.00 |  |  |  | 319 |  |  |  | 0.01 |  |  |  | 16 |  |  |  | 0.00 |  |  |  | 404 |  |  |  | 0.01 |  |
| Amortization of debt issuance costs |  |  | 8 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |  |  | 10 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |
| Total related to other incomes and other expenses |  |  | 24 |  |  |  | 0.00 |  |  |  | 319 |  |  |  | 0.01 |  |  |  | 26 |  |  |  | 0.00 |  |  |  | 404 |  |  |  | 0.01 |  |
| Total related to net income & EPS |  |  | 6,437 |  |  |  | 0.17 |  |  |  | 5,004 |  |  |  | 0.13 |  |  |  | 12,656 |  |  |  | 0.34 |  |  |  | 11,276 |  |  |  | 0.30 |  |
| Non-GAAP measures |  |  | 37,668 |  |  |  | 1.00 |  |  |  | 36,517 |  |  |  | 0.97 |  |  |  | 69,844 |  |  |  | 1.86 |  |  |  | 70,639 |  |  |  | 1.89 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 37,763 |  |  |  |  |  |  |  | 37,471 |  |  |  |  |  |  |  | 37,646 |  |  |  |  |  |  |  | 37,305 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 37,763 |  |  |  |  |  |  |  | 37,471 |  |  |  |  |  |  |  | 37,646 |  |  |  |  |  |  |  | 37,305 |  |

[0001193125-20-022972:8k_2_02:53]
FABRINET

[0001193125-20-022972:8k_2_02:54]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001193125-20-022972:8k_2_02:55]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands) |  | December 27,2019 |  |  | December 28,2018 |  |  | December 27,2019 |  |  | December 28,2018 |  |
| Net cash provided by operating activities |  | $ | 49,963 |  |  | $ | 34,705 |  |  | $ | 52,610 |  |  | $ | 69,298 |  |
| Less: Purchase of property, plant and equipment |  |  | (9,068 | ) |  |  | (4,322 | ) |  |  | (15,411 | ) |  |  | (9,732 | ) |
| Non-GAAP free cash flow |  | $ | 40,895 |  |  | $ | 30,383 |  |  | $ | 37,199 |  |  | $ | 59,566 |  |

[0001193125-20-022972:8k_2_02:56]
FABRINET

[0001193125-20-022972:8k_2_02:57]
GUIDANCE FOR QUARTER ENDING MARCH 27, 2020

[0001193125-20-022972:8k_2_02:58]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-20-022972:8k_2_02:59]
|  |  | DilutedEPS |  |
| GAAP net income per diluted share: |  | $ | 0.75 to $0.78 |  |
| Related to cost of revenues: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.04 |  |
| Total related to gross profit |  |  | 0.04 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.12 |  |
| Amortization of intangibles |  |  | 0.01 |  |
| Total related to selling, general and administrative expenses |  |  | 0.13 |  |
| Total related to net income & EPS |  |  | 0.17 |  |
| Non-GAAP net income per diluted share |  | $ | 0.92 to $0.95 |  |

## item 5.02 — body, verbatim

[0001193125-20-022972:8k_body:1]
Item 5.02

[0001193125-20-022972:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001193125-20-022972:8k_body:3]
Retirement of Officer

[0001193125-20-022972:8k_body:4]
On February 1, 2020, Toh-Seng Ng, Executive Vice President, Chief Financial Officer of Fabrinet, notified Fabrinet that he would retire on February 1, 2021 (the “Retirement Date”). Effective February 17, 2020, Mr. Ng will step down as Chief Financial Officer and transition to Executive Vice President, Special Projects until his Retirement Date.

[0001193125-20-022972:8k_body:5]
Amended and Restated Offer Letter

[0001193125-20-022972:8k_body:6]
On February 1, 2020, Mr. Ng and Fabrinet USA, Inc. (the “Company”) entered into an amended and restated offer letter of employment (the “Amended Ng Offer Letter”), in order to provide for additional retirement benefits. Pursuant to the Amended Ng Offer Letter, Mr. Ng will continue to report to Fabrinet’s Chief Executive Officer (“CEO”) and provide transition and other services as requested by the CEO until Mr. Ng’s Retirement Date.

[0001193125-20-022972:8k_body:7]
The Amended Ng Offer Letter provides that, upon retirement, Mr. Ng will receive the following severance benefits: (1) a lump sum payment equal to the sum of (a) his one month’s base salary multiplied by the total number of full and fractional years of his employment with the Company as of his termination date; (b) any earned but unpaid bonus; and (c) two times his cost of COBRA coverage for twelve months; (2) any then-outstanding and unvested performance-based equity awards that remain subject to the achievement of any performance goals (the “Performance Awards”) will remain outstanding and eligible to vest based on the extent that the applicable performance-based or other criteria are satisfied; (3) any then-outstanding and unvested restricted share unit awards that are not Performance Awards (the “RSU Awards”) will accelerate vesting as to one hundred percent (100%) of the shares subject thereto and (4) continued tax equalization benefits under the Company’s expatriate policy, as in effect on the date of termination, for the calendar year in which the termination date occurs, and the following calendar year. These severance benefits will also become payable if the Company terminates Mr. Ng’s employment without good cause (and other than due to his death or disability) prior to the Retirement Date.

[0001193125-20-022972:8k_body:8]
In the event Mr. Ng’s employment is terminated on account of Mr. Ng’s death or disability, (i) Mr. Ng will become 100% vested in any then-outstanding and unvested RSU Awards, (ii) any then-outstanding and unvested Performance Awards will remain outstanding and eligible to vest based on the extent that the applicable performance-based or other criteria are satisfied, and (iii) Mr. Ng will receive the severance benefits described in clause (1) of the immediately preceding paragraph.

[0001193125-20-022972:8k_body:9]
Mr. Ng’s severance benefits are conditioned upon the parties’ entry into a separation agreement and release of claims in favor of the Company.

[0001193125-20-022972:8k_body:10]
The foregoing description of the Amended Ng Offer Letter is a summary and is qualified in its entirety by the terms of the Amended Ng Offer Letter, which is incorporated herein by reference and attached to this Current Report on Form 8-K as Exhibit 10.1.

[0001193125-20-022972:8k_body:11]
Appointment of Officer

[0001193125-20-022972:8k_body:12]
On February 3, 2020, Fabrinet announced that Csaba Sverha has been appointed Executive Vice President, Chief Financial Officer of Fabrinet, effective February 17, 2020. A copy of the press release related to this announcement is attached hereto as Exhibit 99.1 and is incorporated herein by reference.

[0001193125-20-022972:8k_body:13]
Mr. Sverha, age 40, joined Fabrinet in March 2018 as Vice President of Operations Finance. From 2005 to March 2018, Mr. Sverha held various finance roles of increasing responsibility at Sanmina Corporation, an electronics manufacturing services company. During his thirteen-year tenure at Sanmina, he assumed site level as well as regional and global finance roles, most recently serving as Vice President Finance & Controller, Mechanical Systems Division, from December 2017 to March 2018. Prior to that, Mr. Sverha served as Controller with Benetton Hungary (United Colors of Benetton). Prior to joining Benetton, Mr. Sverha held a junior Finance Analyst and Controller positions with Flex in Hungary. Mr. Sverha holds a Master’s Degree in Agricultural Economics and Management from the Szent Istvan University, Godollo Hungary (SZIU).

[0001193125-20-022972:8k_body:14]
There are no arrangements or understandings between Mr. Sverha and any other persons pursuant to which he was appointed Executive Vice President, Chief Financial Officer. There are also no family relationships between Mr. Sverha and any director or executive officer of Fabrinet, and he has no direct or indirect material interest in any transaction required to be disclosed pursuant to Item 404(a) of Regulation S-K.
