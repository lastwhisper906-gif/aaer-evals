# FN note change history — 0001193125-19-284781 → 0001193125-20-024258


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-02-04):
[0001193125-20-024258:note_history:1]
As of December 27, 2019 
and
 June 28, 2019,
  (was, 2019-11-05, similarity 0.64):
[0001193125-19-284781:note_history:1]
As of September 27, 2019,

- changed (2020-02-04):
[0001193125-20-024258:note_history:2]
the Company had two outstanding standby letters of credit 
in the aggregate amount 
of 6.2 million Euros
  (was, 2019-11-05, similarity 0.7453):
[0001193125-19-284781:note_history:2]
the Company had 
two
 outstanding standby letters of credit 
o
f

- changed (2020-02-04):
[0001193125-20-024258:note_history:3]
and
 one outstanding standby letter of credit of 6.0 million Euros
, respectively,
 related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand.
  (was, 2019-11-05, similarity 0.6217):
[0001193125-19-284781:note_history:3]
transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand.

- added (2020-02-04):
[0001193125-20-024258:note_history:4]
As of December 27, 2019 and June 28, 2019, these

- changed (2020-02-04):
[0001193125-20-024258:note_history:5]
standby letter
s
 of credit w
ere
 backed by cash collateral
  (was, 2019-11-05, similarity 0.6667):
[0001193125-19-284781:note_history:5]
T
he
se
 standby letters of credit were backed by cash collateral of $
22.2
 million and $
7.4
 million, respectively.

- added (2020-02-04):
[0001193125-20-024258:note_history:6]
in the aggregate amount

- added (2020-02-04):
[0001193125-20-024258:note_history:7]
of

- added (2020-02-04):
[0001193125-20-024258:note_history:8]
$
7.7 
million and $
7.4
 million, respectively.

- added (2020-02-04):
[0001193125-20-024258:note_history:9]
As of December 27, 2019 and June 28, 2019, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business amounting to $1.7 million and $1.6 million, respectively, and there were other bank guarantees given by a bank on behalf of our subsidiaries in China and the United Kingdom to support their operations of $0.1 
million 
and $26 thousand, respectively.

- changed (2020-02-04):
[0001193125-20-024258:note_history:10]
Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2019-11-05, similarity 0.9964):
[0001193125-19-284781:note_history:10]
Purchase obligations represent legally-binding commitments to p
u
rchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- changed (2020-02-04):
[0001193125-20-024258:note_history:11]
As of December 27, 2019, the Company had an outstanding commitment to third parties of $10.1 million.
  (was, 2019-11-05, similarity 0.973):
[0001193125-19-284781:note_history:11]
As of September 27, 2019, the Company had an outstanding commitment to third parties of $8.2 million.

- changed (2020-02-04):
[0001193125-20-024258:note_history:12]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.
  (was, 2019-11-05, similarity 0.6348):
[0001193125-19-284781:note_history:12]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the

- removed (2020-02-04):
[0001193125-19-284781:note_history:13]
16.2

- removed (2020-02-04):
[0001193125-19-284781:note_history:14]
million Euros and

- removed (2020-02-04):
[0001193125-19-284781:note_history:15]
one outstanding standby letter of credit of
 6.0
 million

- removed (2020-02-04):
[0001193125-19-284781:note_history:16]
Euros, respectively,

- removed (2020-02-04):
[0001193125-19-284781:note_history:17]
related to the Company’s support of a customer

- removed (2020-02-04):
[0001193125-19-284781:note_history:18]
’s

- removed (2020-02-04):
[0001193125-19-284781:note_history:19]
As of June 28, 2019, the Company had one outstanding standby letter of credit of 6.0 million Euros related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. The standby letter of credit was backed by cash collateral of $7.4 million.

- removed (2020-02-04):
[0001193125-19-284781:note_history:20]
As of September 27, 2019 and June 28, 2019, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business amounting to $1.6 million and $1.6 million, respectively

- removed (2020-02-04):
[0001193125-19-284781:note_history:21]
, and there were other bank guarantees given by a bank on behalf of our subsidiaries in

- removed (2020-02-04):
[0001193125-19-284781:note_history:22]
China

- removed (2020-02-04):
[0001193125-19-284781:note_history:23]
and

- removed (2020-02-04):
[0001193125-19-284781:note_history:24]
the United Kingdom to

- removed (2020-02-04):
[0001193125-19-284781:note_history:25]
support their operations of $70 thousand and $25

- removed (2020-02-04):
[0001193125-19-284781:note_history:26]
thousand,

- removed (2020-02-04):
[0001193125-19-284781:note_history:27]
respectively.

- removed (2020-02-04):
[0001193125-19-284781:note_history:28]
consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-02-04):
[0001193125-20-024258:note_history:29]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of December 27, 2019 and for the three and six months ended December 27, 2019 and December 28, 2018 includes normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 
10-K
 for the year ended June 28, 2019.
  (was, 2019-11-05, similarity 0.9665):
[0001193125-19-284781:note_history:29]
The accompanying unaudited
 condensed consolidated financial statements for Fabrinet as of September 27, 2019 and for the three months ended September 27, 2019 and September 28, 2018 includes normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 
10-K
 for the year ended June 28, 2019.

- changed (2020-02-04):
[0001193125-20-024258:note_history:30]
The results for the three and six months ended December 27, 2019 may not be indicative of results for the year ending June 26, 2020 or any future periods.
  (was, 2019-11-05, similarity 0.9537):
[0001193125-19-284781:note_history:30]
The results for the three months ended September 27, 2019 may not be indicative of results for the year ending June 26, 2020 or any future periods.

- changed (2020-02-04):
[0001193125-20-024258:note_history:31]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements, and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information.
  (was, 2019-11-05, similarity 0.9996):
[0001193125-19-284781:note_history:31]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements, and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that estimates or assumptions prove to 
be 
differ
ent
 from actual results, adjustments will be made in subsequent periods to reflect more current information.

- changed (2020-02-04):
[0001193125-20-024258:note_history:32]
The Company utilizes a 
52-53
 week fiscal year ending on the Friday in June closest to June 30. The three months ended December 27, 2019 and December 28, 2018 each consisted of 13 weeks. The six months ended December 27, 2019 and December 28, 2018 each consisted of 26 weeks. Fiscal year 2020 will be comprised of 52 weeks and will end on June 26, 2020.
  (was, 2019-11-05, similarity 0.775):
[0001193125-19-284781:note_history:32]
week fiscal year ending on the Friday in June closest to June 30. The three months ended September 27, 2019 and September 28, 2018 each consisted of 13 weeks. Fiscal year 2020 will be comprised of 52 weeks and will end on June 26, 2020.

- changed (2020-02-04):
[0001193125-20-024258:note_history:33]
Adoption of New Accounting Standards
  (was, 2019-11-05, similarity 0.9863):
[0001193125-19-284781:note_history:33]
Adoption of New Accounting Standard
s

- changed (2020-02-04):
[0001193125-20-024258:note_history:34]
For periods prior to adoption of ASC 842, the Company is required to present disclosures in accordance with ASC Topic 840. 
F
uture minimum lease payments due under 
non-cancelable
 operating leases as of June 28, 2019 were as follows:
  (was, 2019-11-05, similarity 0.8769):
[0001193125-19-284781:note_history:34]
For periods prior to adoption of ASC 842, the Company is required to present disclosures in accordance with ASC Topic 840. The following disclosure provides the future minimum lease payments due under 
non-cancelable
 operating leases as of June 28, 2019:

- changed (2020-02-04):
[0001193125-20-024258:note_history:35]
On June 29, 2019, the Company also adopted Accounting Standards Update (“ASU”) 
2017-12,
 Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. ASU 
2017-12
 simplifies existing hedge accounting guidance in order to better portray in financial statements the economic impact of risk management activities in the financial statements, including eliminating the separate measurement and presentation of hedge ineffectiveness. Prior to the adoption of ASU 
2017-12,
 the Company was required to separately measure and reflect the amount by which the hedging instrument did not offset the changes in the fair value or cash flows of hedged items, and to record the ineffective portion as earnings. Upon the adoption of ASU 
2017-12,
 the Company no longer recognizes hedge ineffectiveness as earnings, but instead records the entire changes in the fair value of the hedged instruments as other comprehensive income. Amounts recorded as other comprehensive income are subsequently reclassified to earnings in the same income statement line item that is used to present the earnings effect of the hedged item when the hedged item affects earnings. See Note 6 for further details.
  (was, 2019-11-05, similarity 0.997):
[0001193125-19-284781:note_history:35]
On June 29, 2019, the Company also adopted Accounting Standards Update (“ASU”) 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. ASU 2017-12 simplifies existing hedge accounting guidance in order to better portray in financial statements the economic impact of risk management activities in the financial statements, including eliminating the separate measurement and presentation of hedge ineffectiveness. Prior to the adoption of ASU 2017-12, the Company 
wa
s required to separately measure and reflect the amount by which the hedging instrument did not offset the changes in the fair value or cash flows of hedged items, and to record the ineffective portion as earnings. Upon the adoption of ASU 2017-12, the Company is no longer recognize
s
 hedge ineffectiveness as earnings, but instead record
s
 the entire changes in the fair value of the hedged instruments as other comprehensive income. 
Amounts recorded as other comprehensive income are subsequently reclassified to earnings in the same income statement line item that is used to present the earnings effect of the hedged item when the hedged item affects earnings
. See Note 6 for further details.

- changed (2020-02-04):
[0001193125-20-024258:note_history:36]
Concentration ​​​​​​​of credit risk
  (was, 2019-11-05, similarity 0.8889):
[0001193125-19-284781:note_history:36]
Concentration of credit risk

- changed (2020-02-04):
[0001193125-20-024258:note_history:37]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash and cash equivalents, short-term investments, derivatives, accounts receivable and contract assets.
  (was, 2019-11-05, similarity 0.9442):
[0001193125-19-284781:note_history:37]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash and cash equivalents, short-term investments, derivatives
,
 accounts receivable

- added (2020-02-04):
[0001193125-20-024258:note_history:38]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued ASU 
2019-12,
 “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes
.
” The amendments in this Update simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify GAAP for other areas of Topic 740 by clarifying and amending existing guidance. For public business entities, the amendments in this update are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2020. This ASU will be effective for the Company in the first quarter of fiscal 2022. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.

- changed (2020-02-04):
[0001193125-20-024258:note_history:39]
In May 2019, 
the 
FASB issued ASU 
2019-05,
 “Financial Instruments – Credit Losses (Topic 326): Targeted Transition Relief
.
” The amendments in ASU 
2019-05
 provide entities that have certain instruments within the scope of Subtopic 
326-20
 (“Financial Instruments—Credit Losses—Measured at Amortized Cost”) with an option to irrevocably elect the fair value option in Subtopic 
825-10
 (“Financial Instruments—Overall”), applied on an 
instrument-by-instrument
 basis for eligible instruments, upon adoption of Topic 326. The fair value option election does not apply to 
held-to-maturity
 debt securities. An entity that elects the fair value option should subsequently apply the guidance in Subtopics 
820-10
 (“Fair Value Measurement—Overall”) and 
825-10.
 For public business entities, this update is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. This ASU will be effective for the Company in the first quarter of fiscal 2021. Early adoption is permitted. The Company 
is currently evaluating the i
mpact of the adoption of
  (was, 2019-11-05, similarity 0.9115):
[0001193125-19-284781:note_history:39]
In May 2019, the Financial Accounting Standards Board (“FASB”) issued ASU 
2019-05,
 “Financial Instruments – Credit Losses (Topic 326): Targeted Transition Relief.” The amendments in ASU 
2019-05
 provide entities that have certain instruments within the scope of Subtopic 
326-20
 (“Financial Instruments—Credit Losses—Measured at Amortized Cost”) with an option to irrevocably elect the fair value option in Subtopic 
825-10
 (“Financial Instruments—Overall”), applied on an 
instrument-by-instrument
 basis for eligible instruments, upon adoption of Topic 326. The fair value option election does not apply to 
held-to-maturity
 debt securities. An entity that elects the fair value option should subsequently apply the guidance in Subtopics 
820-10
 (“Fair Value Measurement—Overall”) and 
825-10.
 For public business entities, this update is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. This ASU will be effective for the Company in the first quarter of fiscal 2021. Early adoption is permitted. The Company does not expect this update will impact its condensed consolidated financial statements.

- added (2020-02-04):
[0001193125-20-024258:note_history:40]
this update

- added (2020-02-04):
[0001193125-20-024258:note_history:41]
o
n

- added (2020-02-04):
[0001193125-20-024258:note_history:42]
its condensed consolidated financial statements.

- removed (2020-02-04):
[0001193125-19-284781:note_history:43]
The Company utilizes a

- removed (2020-02-04):
[0001193125-19-284781:note_history:44]
52-53

- removed (2020-02-04):
[0001193125-19-284781:note_history:45]
and contract assets

- removed (2020-02-04):
[0001193125-19-284781:note_history:46]
.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-04):
[0001193125-20-024258:note_history:47]
The Company’s total borrowings, including current and 
non-current
 portions of long-term borrowings, consisted of the following:
  (was, 2019-11-05, similarity 0.6196):
[0001193125-19-284781:note_history:47]
The Company’s total borrowings, including current
 portion

- added (2020-02-04):
[0001193125-20-024258:note_history:48]
| (amount in thousands) |

- changed (2020-02-04):
[0001193125-20-024258:note_history:49]
| Rate |  | Conditions |  |  | Maturity |  |  | As of December 27, 2019 |  |  | As of June 28, 2019 |  |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  |  |  |  |  |  | $ | 12,188 |  |  | $ | 3,250 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  |  |  |  |  |  |  | (32 | ) |  |  | — |  |
| Long-term borrowings, current portion, net |  |  |  |  |  | $ | 12,156 |  |  |  | 3,250 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1-month LIBOR +1.50% per annum(1) |  |  | Repayable in quarterly installments |  |  |  | June 2023 |  |  | $ | — |  |  | $ | 60,938 |  |
| 3-month LIBOR +1.35% per annum(1) |  |  | Repayable in quarterly installments |  |  |  | June 2024 |  |  |  | 57,891 |  |  |  | — |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (12,188 | ) |  |  | (3,250 | ) |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  |  |  | (111 | ) |  |  | — |  |
| Long-term borrowings, non-current portion, net |  |  |  |  |  | $ | 45,592 |  |  | $ | 57,688 |  |
  (was, 2019-11-05, similarity 0.9272):
[0001193125-19-284781:note_history:49]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  | Maturity |  |  | As ofSeptember 27,2019 |  |  | As ofJune 28,2019 |  |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  |  |  |  | $ | 12,188 |  |  | $ | 3,250 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  |  |  |  |  | (31 | ) |  |  | — |  |
| Long-term borrowings, current portion, net |  |  |  |  |  |  |  | $ | 12,157 |  |  |  | 3,250 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1-month LIBOR +1.50% per annum (1) |  | Repayable in quarterly installments |  |  | June 2023 |  |  | $ | — |  |  | $ | 60,938 |  |
| 3-month LIBOR +1.35% per annum (1) |  | Repayable in quarterly installments |  |  | June 2024 |  |  |  | 60,938 |  |  |  | — |  |
| Less: Current portion |  |  |  |  |  |  |  |  | (12,188 | ) |  |  | (3,250 | ) |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  |  |  |  |  | (119 | ) |  |  | — |  |
| Long-term borrowings, non-current portion, net |  |  |  |  |  |  |  | $ | 48,631 |  |  | $ | 57,688 |  |

- changed (2020-02-04):
[0001193125-20-024258:note_history:50]
The movements of long-term borrowings for the six months ended December 27, 2019 and December 28, 2018 were as follows:
  (was, 2019-11-05, similarity 0.9189):
[0001193125-19-284781:note_history:50]
The movements of long-term borrowings for the three months ended September 27, 2019 and September 28, 2018 were as follows:

- changed (2020-02-04):
[0001193125-20-024258:note_history:51]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 27, 2019 |  |  | December 28, 2018 |  |
| Opening balance |  | $ | 60,938 |  |  | $ | 64,188 |  |
| Borrowings during the period |  |  | 60,938 |  |  |  | — |  |
| Repayments during the period |  |  | (63,985 | ) |  |  | (813 | ) |
| Closing balance |  | $ | 57,891 |  |  | $ | 63,375 |  |
  (was, 2019-11-05, similarity 0.9075):
[0001193125-19-284781:note_history:51]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 27, 2019 |  |  | September 28, 2018 |  |
| Opening balance |  | $ | 60,938 |  |  | $ | 64,188 |  |
| Borrowings during the period |  |  | 60,938 |  |  |  | — |  |
| Repayments during the period |  |  | (60,938 | ) |  |  | (813 | ) |
| Closing balance |  | $ | 60,938 |  |  | $ | 63,375 |  |

- changed (2020-02-04):
[0001193125-20-024258:note_history:52]
As of December 27, 2019, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2019-11-05, similarity 0.9754):
[0001193125-19-284781:note_history:52]
As of September 27, 2019, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2020-02-04):
[0001193125-20-024258:note_history:53]
| (amount in thousands) |  |  |  |
| 2020 (remaining six months) |  | $ | 6,093 |  |
| 2021 |  |  | 12,188 |  |
| 2022 |  |  | 15,234 |  |
| 2023 |  |  | 12,188 |  |
| 2024 |  |  | 12,188 |  |
| Total |  | $ | 57,891 |  |
  (was, 2019-11-05, similarity 0.9842):
[0001193125-19-284781:note_history:53]
| (amount in thousands) |  |  |  |
| 2020 (remaining nine months) |  | $ | 9,140 |  |
| 2021 |  |  | 12,188 |  |
| 2022 |  |  | 15,234 |  |
| 2023 |  |  | 12,188 |  |
| 2024 |  |  | 12,188 |  |
| Total |  | $ | 60,938 |  |

- added (2020-02-04):
[0001193125-20-024258:note_history:54]
On August 20, 2019, Fabrinet Thailand (the “Borrower”), and

- added (2020-02-04):
[0001193125-20-024258:note_history:55]
Bank of Ayudhya Public Company Limited (

- added (2020-02-04):
[0001193125-20-024258:note_history:56]
the

- added (2020-02-04):
[0001193125-20-024258:note_history:57]
“

- changed (2020-02-04):
[0001193125-20-024258:note_history:58]
Bank
  (was, 2019-11-05, similarity 0.8889):
[0001193125-19-284781:note_history:58]
banks

- added (2020-02-04):
[0001193125-20-024258:note_history:59]
”)

- added (2020-02-04):
[0001193125-20-024258:note_history:60]
entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai Baht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

- added (2020-02-04):
[0001193125-20-024258:note_history:61]
The term loan accrues interest at 
3-month LIBOR plus 1.35% and is repayable in quarterly installments of $
3.0 million, commencing on September 30, 2019. The term loan 
will 
mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be 
re-borrowed. 
 During the six months ended December 27, 2019, the Company recorded $0.6 million of interest expense in connection with this term loan.

- changed (2020-02-04):
[0001193125-20-024258:note_history:62]
Any borrowings under the Credit Facility Agreement, including those borrowings under the Term Loan Agreement
,
 are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.
  (was, 2019-11-05, similarity 0.6702):
[0001193125-19-284781:note_history:62]
Any borrowings under the Credit Facility Agreement, including those borrowing under the Term Loan Agreement are guaranteed by

- changed (2020-02-04):
[0001193125-20-024258:note_history:63]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt to equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. At December 27, 2019, the Company was in compliance with all of its covenants under the Term Loan Agreement.
  (was, 2019-11-05, similarity 0.9962):
[0001193125-19-284781:note_history:63]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt to equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. At September 27, 2019, the Company was in compliance with all of its covenants under the Term Loan Agreement
.

- changed (2020-02-04):
[0001193125-20-024258:note_history:64]
At December 27, 2019, there was $57.9 million outstanding under the term loan.
  (was, 2019-11-05, similarity 0.9571):
[0001193125-19-284781:note_history:64]
At September 27, 2019, there was $
60.9 
million outstanding under the term loan.

- changed (2020-02-04):
[0001193125-20-024258:note_history:65]
On May 22, 2014, the Company and 
a
 consortium of banks entered into a syndicated senior credit facility agreement led by Bank of America (the “Bank of America Facility Agreement”). The Bank of America Facility Agreement provided for a $200.0 million credit line, comprised of a $150.0 million revolving loan facility and a $50.0 million delayed draw term loan facility.
  (was, 2019-11-05, similarity 0.7714):
[0001193125-19-284781:note_history:65]
(the “Bank of America Facility Agreement”). The Bank of America Facility Agreement provided for a $200.0 million credit line, comprised of a $150.0 million revolving loan facility and a $50.0 million delayed draw term loan facility.

- changed (2020-02-04):
[0001193125-20-024258:note_history:66]
From time to time, we amended the Bank of America Facility Agreement, before repaying all outstanding amounts under the agreement and terminating such agreement on September 10, 2019.
  (was, 2019-11-05, similarity 0.9944):
[0001193125-19-284781:note_history:66]
From time to time, we amended the Bank of America Facility Agreement, before repaying all outstanding amounts under the agreement and terminating such agreement on 
September 10, 2019
.

- added (2020-02-04):
[0001193125-20-024258:note_history:67]
The most recent amendment on June 4, 2018 (i) reduced the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) refinanced the outstanding amounts under the revolving loan and term loan facilities into a $65.0 million term loan which was to be repaid in quarterly installments through the maturity date of June 4, 2023
, 
and (iii) reduced the interest rate margins and commitment fees. The term loan bore interest, at the Company’s option, at a rate per annum equal to a LIBOR rate plus a spread of 1.50% to 2.25%, or a base rate plus a spread of 0.50% to 1.25%. During the six months ended December 27, 2019 and December 28, 2018, the Company recorded $0.5 million and $1.2 million, respectively, of interest expense in connection with this term loan.

- changed (2020-02-04):
[0001193125-20-024258:note_history:68]
On September 10, 2019, the Company fully repaid $61.0 million in principal, accrued interest and other fees under the agreement. The early termination of this agreement did not trigger any early termination fees. At December 27, 2019, there were no amounts outstanding under the Bank of America Facility Agreement. At June 28, 2019, there was $60.9 million outstanding under the Bank of America Facility Agreement, related to the term loan.
  (was, 2019-11-05, similarity 0.9558):
[0001193125-19-284781:note_history:68]
During the three months ended September 27, 2019, the Company fully repaid $61.0 million in principal, accrued interest and other fees under the agreement. The early termination of this agreement did not trigger any early termination fees. At September 27, 2019, there were no amounts outstanding under the Bank of America Facility Agreement. At June 28, 2019, there was $60.9 million outstanding under the Bank of America Facility Agreement, related to the term loan.

- removed (2020-02-04):
[0001193125-19-284781:note_history:69]
and 
non-current
 portion of

- removed (2020-02-04):
[0001193125-19-284781:note_history:70]
long-term borrowings, consisted of the following:

- removed (2020-02-04):
[0001193125-19-284781:note_history:71]
On August 20, 2019, Fabrinet Thailand (the “Borrower”), and 
the 
Bank entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai Baht

- removed (2020-02-04):
[0001193125-19-284781:note_history:72]
(approximately $
3.6
 million based on the applicable exchange rate as of September 
27
, 
2019)
 and $
160.9

- removed (2020-02-04):
[0001193125-19-284781:note_history:73]
million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

- removed (2020-02-04):
[0001193125-19-284781:note_history:74]
The term loan accrues interest at 
3-month LIBOR plus 1.35%
 and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan matures on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be 
re-borrowed. 
 During the three months ended September 27, 2019, the Company recorded $0.2 
million
 of interest expense in connection with this term loan.

- removed (2020-02-04):
[0001193125-19-284781:note_history:75]
Fabrinet

- removed (2020-02-04):
[0001193125-19-284781:note_history:76]
and secured by land and buildings in Pathumthani and Chonburi Provinces owned by the Borrower in Thailand.

- removed (2020-02-04):
[0001193125-19-284781:note_history:77]
On May 22, 2014, the Company and

- removed (2020-02-04):
[0001193125-19-284781:note_history:78]
a
 consortium

- removed (2020-02-04):
[0001193125-19-284781:note_history:79]
of

- removed (2020-02-04):
[0001193125-19-284781:note_history:80]
entered into a syndicated senior credit facility agreement

- removed (2020-02-04):
[0001193125-19-284781:note_history:81]
led by Bank of America

- removed (2020-02-04):
[0001193125-19-284781:note_history:82]
The most recent amendment on June 4, 2018, (i)

- removed (2020-02-04):
[0001193125-19-284781:note_history:83]
reduced

- removed (2020-02-04):
[0001193125-19-284781:note_history:84]
the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) refinanced the outstanding amounts under the revolving loan and term loan facilities into a $65.0 million term loan which was to be repaid in quarterly installments through the maturity date of June 4, 2023; and (iii) reduced the interest rate margins and commitment fees. The term loan bore interest, at the Company’s option, at a rate per annum equal to a 
LIBOR rate plus a spread of 1.50% to 2.25%
, or a 
base rate plus a spread of 0.50% to 1.25%
. During the three months ended September 27, 2019 and September 28, 2018, the Company recorded $0.5 
million 
and $
0.7

- removed (2020-02-04):
[0001193125-19-284781:note_history:85]
million
, respectively, of interest expense in connection with this term loan.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-04):
[0001193125-20-024258:note_history:86]
The movements of long-term borrowings for the six months ended December 27, 2019 and December 28, 2018 were as follows:
  (was, 2019-11-05, similarity 0.9189):
[0001193125-19-284781:note_history:86]
The movements of long-term borrowings for the three months ended September 27, 2019 and September 28, 2018 were as follows:

- changed (2020-02-04):
[0001193125-20-024258:note_history:87]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 27, 2019 |  |  | December 28, 2018 |  |
| Opening balance |  | $ | 60,938 |  |  | $ | 64,188 |  |
| Borrowings during the period |  |  | 60,938 |  |  |  | — |  |
| Repayments during the period |  |  | (63,985 | ) |  |  | (813 | ) |
| Closing balance |  | $ | 57,891 |  |  | $ | 63,375 |  |
  (was, 2019-11-05, similarity 0.9075):
[0001193125-19-284781:note_history:87]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 27, 2019 |  |  | September 28, 2018 |  |
| Opening balance |  | $ | 60,938 |  |  | $ | 64,188 |  |
| Borrowings during the period |  |  | 60,938 |  |  |  | — |  |
| Repayments during the period |  |  | (60,938 | ) |  |  | (813 | ) |
| Closing balance |  | $ | 60,938 |  |  | $ | 63,375 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-04):
[0001193125-20-024258:note_history:88]
The Company’s total borrowings, including current and 
non-current
 portions of long-term borrowings, consisted of the following:
  (was, 2019-11-05, similarity 0.6196):
[0001193125-19-284781:note_history:88]
The Company’s total borrowings, including current
 portion

- added (2020-02-04):
[0001193125-20-024258:note_history:89]
| (amount in thousands) |

- changed (2020-02-04):
[0001193125-20-024258:note_history:90]
| Rate |  | Conditions |  |  | Maturity |  |  | As of December 27, 2019 |  |  | As of June 28, 2019 |  |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  |  |  |  |  |  | $ | 12,188 |  |  | $ | 3,250 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  |  |  |  |  |  |  | (32 | ) |  |  | — |  |
| Long-term borrowings, current portion, net |  |  |  |  |  | $ | 12,156 |  |  |  | 3,250 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1-month LIBOR +1.50% per annum(1) |  |  | Repayable in quarterly installments |  |  |  | June 2023 |  |  | $ | — |  |  | $ | 60,938 |  |
| 3-month LIBOR +1.35% per annum(1) |  |  | Repayable in quarterly installments |  |  |  | June 2024 |  |  |  | 57,891 |  |  |  | — |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (12,188 | ) |  |  | (3,250 | ) |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  |  |  | (111 | ) |  |  | — |  |
| Long-term borrowings, non-current portion, net |  |  |  |  |  | $ | 45,592 |  |  | $ | 57,688 |  |
  (was, 2019-11-05, similarity 0.9272):
[0001193125-19-284781:note_history:90]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  | Maturity |  |  | As ofSeptember 27,2019 |  |  | As ofJune 28,2019 |  |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  |  |  |  | $ | 12,188 |  |  | $ | 3,250 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  |  |  |  |  | (31 | ) |  |  | — |  |
| Long-term borrowings, current portion, net |  |  |  |  |  |  |  | $ | 12,157 |  |  |  | 3,250 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1-month LIBOR +1.50% per annum (1) |  | Repayable in quarterly installments |  |  | June 2023 |  |  | $ | — |  |  | $ | 60,938 |  |
| 3-month LIBOR +1.35% per annum (1) |  | Repayable in quarterly installments |  |  | June 2024 |  |  |  | 60,938 |  |  |  | — |  |
| Less: Current portion |  |  |  |  |  |  |  |  | (12,188 | ) |  |  | (3,250 | ) |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  |  |  |  |  | (119 | ) |  |  | — |  |
| Long-term borrowings, non-current portion, net |  |  |  |  |  |  |  | $ | 48,631 |  |  | $ | 57,688 |  |

- removed (2020-02-04):
[0001193125-19-284781:note_history:91]
and 
non-current
 portion of

- removed (2020-02-04):
[0001193125-19-284781:note_history:92]
long-term borrowings, consisted of the following:


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-02-04):
[0001193125-20-024258:note_history:93]
As of December 27, 2019, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2019-11-05, similarity 0.9754):
[0001193125-19-284781:note_history:93]
As of September 27, 2019, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2020-02-04):
[0001193125-20-024258:note_history:94]
| (amount in thousands) |  |  |  |
| 2020 (remaining six months) |  | $ | 6,093 |  |
| 2021 |  |  | 12,188 |  |
| 2022 |  |  | 15,234 |  |
| 2023 |  |  | 12,188 |  |
| 2024 |  |  | 12,188 |  |
| Total |  | $ | 57,891 |  |
  (was, 2019-11-05, similarity 0.9842):
[0001193125-19-284781:note_history:94]
| (amount in thousands) |  |  |  |
| 2020 (remaining nine months) |  | $ | 9,140 |  |
| 2021 |  |  | 12,188 |  |
| 2022 |  |  | 15,234 |  |
| 2023 |  |  | 12,188 |  |
| 2024 |  |  | 12,188 |  |
| Total |  | $ | 60,938 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-02-04):
[0001193125-20-024258:note_history:95]
The following table
s
 present total revenues by geographic region:
  (was, 2019-11-05, similarity 0.9771):
[0001193125-19-284781:note_history:95]
The following table presents total revenues by geographic region:

- added (2020-02-04):
[0001193125-20-024258:note_history:96]
| (amount in thousands, except percentages) |  | Three MonthsEnded December 27, 2019 |  |  | As a % of TotalRevenues |  |  | Six MonthsEnded December 27, 2019 |  |  | As a % of TotalRevenues |  |
| North America |  | $ | 223,398 |  |  |  | 52.4 | % |  | $ | 424,345 |  |  |  | 51.4 | % |
| Asia-Pacific |  |  | 141,147 |  |  |  | 33.1 |  |  |  | 259,570 |  |  |  | 31.4 |  |
| Europe |  |  | 61,672 |  |  |  | 14.5 |  |  |  | 141,598 |  |  |  | 17.2 |  |
| Total |  | $ | 426,217 |  |  |  | 100.0 | % |  | $ | 825,513 |  |  |  | 100.0 | % |

- added (2020-02-04):
[0001193125-20-024258:note_history:97]
| (amount in thousands, except percentages) |  | Three MonthsEnded December 28, 2018 |  |  | As a % of TotalRevenues |  |  | Six MonthsEnded December 28, 2018 |  |  | As a % of TotalRevenues |  |
| North America |  | $ | 182,698 |  |  |  | 45.3 | % |  | $ | 362,524 |  |  |  | 46.5 | % |
| Asia-Pacific |  |  | 166,711 |  |  |  | 41.4 |  |  |  | 318,658 |  |  |  | 40.8 |  |
| Europe |  |  | 53,671 |  |  |  | 13.3 |  |  |  | 99,075 |  |  |  | 12.7 |  |
| Total |  | $ | 403,080 |  |  |  | 100.0 | % |  | $ | 780,257 |  |  |  | 100.0 | % |

- removed (2020-02-04):
[0001193125-19-284781:note_history:98]
| (amount in thousands, except percentages) |  | Three Months Ended September 27, 2019 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 200,947 |  |  |  | 50.3 | % |
| Asia-Pacific |  |  | 118,423 |  |  |  | 29.7 |  |
| Europe |  |  | 79,926 |  |  |  | 20.0 |  |
|  |  | $ | 399,296 |  |  |  | 100.0 | % |

- removed (2020-02-04):
[0001193125-19-284781:note_history:99]
| (amount in thousands, except percentages) |  | Three Months Ended September 28, 2018 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 179,826 |  |  |  | 47.7 | % |
| Asia-Pacific |  |  | 151,947 |  |  |  | 40.3 |  |
| Europe |  |  | 45,404 |  |  |  | 12.0 |  |
|  |  | $ | 377,177 |  |  |  | 100.0 | % |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-02-04):
[0001193125-20-024258:note_history:100]
The Company manufactures products that are customized to customers’ specifications, however, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for recognizing revenue over time are not met. On the evaluation of the contracts the Company determined that it did not have contractual rights to bill profit for work in progress in the event of a contract termination, an event which is expected to be infrequent. Further, in limited circumstances, substantive acceptance by the customer will result in the deferral of revenue until acceptance is formally received from the customer. Judgment may be required in determining if the acceptance clause provides for substantive acceptance.
  (was, 2019-11-05, similarity 0.9785):
[0001193125-19-284781:note_history:100]
The Company manufactures products that are customized to customers’ specifications, however, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for overtime recognition are not met. On the evaluation of the contracts the Company determined that it did not have contractual rights to bill profit for work in progress in the event of a contract termination, an event which is expected to be infrequent. Further, in limited circumstances, substantive acceptance by the customer will result in the deferral of revenue until acceptance is formally received from the customer. Judgment may be required in determining if the acceptance clause provides for substantive acceptance.

- added (2020-02-04):
[0001193125-20-024258:note_history:101]
A contract asset is recognized when the Company​​​​​​​ has recognized revenues prior to generating an invoice for payment. Contract assets are classified separately within the unaudited condensed consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. During the six months ended December 27, 2019, the Company had no impairment for contract assets recognized.

- changed (2020-02-04):
[0001193125-20-024258:note_history:102]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the 
six
  (was, 2019-11-05, similarity 0.9658):
[0001193125-19-284781:note_history:102]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the three

- added (2020-02-04):
[0001193125-20-024258:note_history:103]
month
s

- changed (2020-02-04):
[0001193125-20-024258:note_history:104]
ended December 27, 2019:
  (was, 2019-11-05, similarity 0.7234):
[0001193125-19-284781:note_history:104]
month
s
 ended September 27, 2019:

- changed (2020-02-04):
[0001193125-20-024258:note_history:105]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 28, 2019 |  | $ | 12,447 |  |
| Revenue recognized |  |  | 39,093 |  |
| Amounts collected or invoiced |  |  | (40,426 | ) |
| Ending balance, December 27, 2019 |  | $ | 11,114 |  |
  (was, 2019-11-05, similarity 0.9838):
[0001193125-19-284781:note_history:105]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 28, 2019 |  | $ | 12,447 |  |
| Revenue recognized |  |  | 21,653 |  |
| Amounts collected or invoiced |  |  | (22,480 | ) |
| Ending balance, September 27, 2019 |  | $ | 11,620 |  |

- changed (2020-02-04):
[0001193125-20-024258:note_history:106]
| (amount in thousands) |  | Contract Liabilities |  |
| Beginning balance, June 28, 2019 |  | $ | 2,239 |  |
| Advance payment received during the period |  |  | 3,336 |  |
| Revenue recognized |  |  | (3,215 | ) |
| Ending balance, December 27, 2019 |  | $ | 2,360 |  |
  (was, 2019-11-05, similarity 0.9645):
[0001193125-19-284781:note_history:106]
| (amount in thousands) |  | Contract Liabilities |  |
| Beginning balance, June 28, 2019 |  | $ | 2,239 |  |
| Additions advance payment received during the period |  |  | 2,230 |  |
| Revenue recognized |  |  | (2,203 | ) |
| Ending balance, September 27, 2019 |  | $ | 2,266 |  |

- changed (2020-02-04):
[0001193125-20-024258:note_history:107]
Consistent with the guidance in ASC 
340-40-25-1,
 the incremental costs of obtaining a contract with a customer are recognized as an asset (not expensed as incurred) if such costs are expected to be recovered. Incremental costs of obtaining a contract are costs that the Company would not have incurred if the contract had not been obtained (e.g., sales commissions or similar incentive payments linked directly to new or modified customer contracts). Costs that would have been incurred regardless of whether a customer contract was obtained (e.g., costs of pursuing the contact, legal advice, etc.) are expensed as incurred, unless such costs are explicitly chargeable to the customer. During the 
six
  (was, 2019-11-05, similarity 0.9943):
[0001193125-19-284781:note_history:107]
Consistent with the guidance in ASC 
340-40-25-1,
 the incremental costs of obtaining a contract with a customer are recognized as an asset (not expensed as incurred) if 
such 
costs are expected to be recovered. Incremental costs of obtaining a contract are 
costs that
 the Company would not have incurred if the contract had not been obtained (e.g., sales commissions or similar incentive payments linked directly to new or modified customer contracts). Costs that would have been incurred regardless of whether a customer contract was obtained (e.g., costs of pursuing the contact, legal advice, etc.) are expensed as incurred, unless 
such 
costs are explicitly chargeable to the customer. During the three

- added (2020-02-04):
[0001193125-20-024258:note_history:108]
month
s

- changed (2020-02-04):
[0001193125-20-024258:note_history:109]
ended December 27, 2019, the Company did not have any incremental costs of obtaining a contract.
  (was, 2019-11-05, similarity 0.9312):
[0001193125-19-284781:note_history:109]
month
s
 ended September 27, 2019, the Company did not have any incremental costs of obtaining a contract.

- changed (2020-02-04):
[0001193125-20-024258:note_history:110]
Shipping and Handling​​​​​​​
  (was, 2019-11-05, similarity 0.8571):
[0001193125-19-284781:note_history:110]
Shipping and Handling

- changed (2020-02-04):
[0001193125-20-024258:note_history:111]
Revenue by Geographic ​​​​​​​Area
  (was, 2019-11-05, similarity 0.8814):
[0001193125-19-284781:note_history:111]
Revenue by Geographic Area

- changed (2020-02-04):
[0001193125-20-024258:note_history:112]
Total revenues are attributed to a particular geographic area based on the
 bill-to-location
 of the Company’s customers. The Company operates in three geographic regions: North America, Asia-Pacific and Europe. The following table
s
 present total revenues by geographic region:
  (was, 2019-11-05, similarity 0.7466):
[0001193125-19-284781:note_history:112]
customers. The Company operates in three geographic regions: North America, Asia-Pacific and Europe. The following table presents total revenues by geographic region:

- added (2020-02-04):
[0001193125-20-024258:note_history:113]
| (amount in thousands, except percentages) |  | Three MonthsEnded December 27, 2019 |  |  | As a % of TotalRevenues |  |  | Six MonthsEnded December 27, 2019 |  |  | As a % of TotalRevenues |  |
| North America |  | $ | 223,398 |  |  |  | 52.4 | % |  | $ | 424,345 |  |  |  | 51.4 | % |
| Asia-Pacific |  |  | 141,147 |  |  |  | 33.1 |  |  |  | 259,570 |  |  |  | 31.4 |  |
| Europe |  |  | 61,672 |  |  |  | 14.5 |  |  |  | 141,598 |  |  |  | 17.2 |  |
| Total |  | $ | 426,217 |  |  |  | 100.0 | % |  | $ | 825,513 |  |  |  | 100.0 | % |

- added (2020-02-04):
[0001193125-20-024258:note_history:114]
| (amount in thousands, except percentages) |  | Three MonthsEnded December 28, 2018 |  |  | As a % of TotalRevenues |  |  | Six MonthsEnded December 28, 2018 |  |  | As a % of TotalRevenues |  |
| North America |  | $ | 182,698 |  |  |  | 45.3 | % |  | $ | 362,524 |  |  |  | 46.5 | % |
| Asia-Pacific |  |  | 166,711 |  |  |  | 41.4 |  |  |  | 318,658 |  |  |  | 40.8 |  |
| Europe |  |  | 53,671 |  |  |  | 13.3 |  |  |  | 99,075 |  |  |  | 12.7 |  |
| Total |  | $ | 403,080 |  |  |  | 100.0 | % |  | $ | 780,257 |  |  |  | 100.0 | % |

- changed (2020-02-04):
[0001193125-20-024258:note_history:115]
The following table
s
 set forth our revenues by end market
:
  (was, 2019-11-05, similarity 0.9492):
[0001193125-19-284781:note_history:115]
The following table sets forth our revenues by end market.

- added (2020-02-04):
[0001193125-20-024258:note_history:116]
| (amount in thousands, except percentages) |  | Three MonthsEnded December 27, 2019 |  |  | As a % of TotalRevenues |  |  | Six MonthsEnded December 27, 2019 |  |  | As a % of TotalRevenues |  |
| Optical communications |  | $ | 322,068 |  |  |  | 75.6 | % |  | $ | 624,447 |  |  |  | 75.6 | % |
| Lasers, sensors and other |  |  | 104,149 |  |  |  | 24.4 |  |  |  | 201,066 |  |  |  | 24.4 |  |
| Total |  | $ | 426,217 |  |  |  | 100.0 | % |  | $ | 825,513 |  |  |  | 100.0 | % |

- added (2020-02-04):
[0001193125-20-024258:note_history:117]
| (amount in thousands, except percentages) |  | Three MonthsEnded December 28, 2018 |  |  | As a % of TotalRevenues |  |  | Six MonthsEnded December 28, 2018 |  |  | As a % of TotalRevenues |  |
| Optical communications |  | $ | 305,547 |  |  |  | 75.8 | % |  | $ | 586,315 |  |  |  | 75.1 | % |
| Lasers, sensors and other |  |  | 97,533 |  |  |  | 24.2 |  |  |  | 193,942 |  |  |  | 24.9 |  |
| Total |  | $ | 403,080 |  |  |  | 100.0 | % |  | $ | 780,257 |  |  |  | 100.0 | % |

- removed (2020-02-04):
[0001193125-19-284781:note_history:118]
A contract asset is recognized when the Company has recognized revenues prior to 
generating 
an invoice for payment. Contract assets are classified separately on the

- removed (2020-02-04):
[0001193125-19-284781:note_history:119]
unaudited condensed

- removed (2020-02-04):
[0001193125-19-284781:note_history:120]
consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. During the three-month 
period 
ended September 27, 2019, the Company had no impairment for contract assets recognized.

- removed (2020-02-04):
[0001193125-19-284781:note_history:121]
Total revenues are attributed to a particular geographic area based on the
 bill-to-location
 of the 
Company’s

- removed (2020-02-04):
[0001193125-19-284781:note_history:122]
| (amount in thousands, except percentages) |  | Three Months Ended September 27, 2019 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 200,947 |  |  |  | 50.3 | % |
| Asia-Pacific |  |  | 118,423 |  |  |  | 29.7 |  |
| Europe |  |  | 79,926 |  |  |  | 20.0 |  |
|  |  | $ | 399,296 |  |  |  | 100.0 | % |

- removed (2020-02-04):
[0001193125-19-284781:note_history:123]
| (amount in thousands, except percentages) |  | Three Months Ended September 28, 2018 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 179,826 |  |  |  | 47.7 | % |
| Asia-Pacific |  |  | 151,947 |  |  |  | 40.3 |  |
| Europe |  |  | 45,404 |  |  |  | 12.0 |  |
|  |  | $ | 377,177 |  |  |  | 100.0 | % |

- removed (2020-02-04):
[0001193125-19-284781:note_history:124]
| (amount in thousands, except percentages) |  | Three Months Ended September 27, 2019 |  |  | As a % of Total Revenues |  |
| Optical communications |  | $ | 302,379 |  |  |  | 75.7 | % |
| Lasers, sensors and other |  |  | 96,917 |  |  |  | 24.3 |  |
| Total |  | $ | 399,296 |  |  |  | 100.0 | % |

- removed (2020-02-04):
[0001193125-19-284781:note_history:125]
| (amount in thousands, except percentages) |  | Three Months Ended September 28, 2018 |  |  | As a % of Total Revenues |  |
| Optical communications |  | $ | 280,768 |  |  |  | 74.4 | % |
| Lasers, sensors and other |  |  | 96,409 |  |  |  | 25.6 |  |
| Total |  | $ | 377,177 |  |  |  | 100.0 | % |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2020-02-04):
[0001193125-19-284781:note_history:126]
| 20. | Subsequent events |

- removed (2020-02-04):
[0001193125-19-284781:note_history:127]
On October 1, 2019, the Company advanced fund
s
 in the amount of 
$
24.3

- removed (2020-02-04):
[0001193125-19-284781:note_history:128]
million to a customer to support the customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. These advanced funds

- removed (2020-02-04):
[0001193125-19-284781:note_history:129]
must be repaid by September 30, 2020.
