# FN MD&A — 0001193125-20-024258


## mdna

[0001193125-20-024258:mdna:1]
ITEM 2. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001193125-20-024258:mdna:2]
[same as prior period, unchanged from 0001193125-19-284781:mdna:2]

[0001193125-20-024258:mdna:3]
[same as prior period, unchanged from 0001193125-19-284781:mdna:3]

[0001193125-20-024258:mdna:4]
[same as prior period, unchanged from 0001193125-19-284781:mdna:4]

[0001193125-20-024258:mdna:5]
|  | • | our expectation that the portion of our revenues attributable to customers in regions outside of North America for the remainder of fiscal year 2020 will be in line with the portion of those revenues for the six months ended December 27, 2019; |

[0001193125-20-024258:mdna:6]
[same as prior period, unchanged from 0001193125-19-284781:mdna:6]

[0001193125-20-024258:mdna:7]
[same as prior period, unchanged from 0001193125-19-284781:mdna:7]

[0001193125-20-024258:mdna:8]
[same as prior period, unchanged from 0001193125-19-284781:mdna:8]

[0001193125-20-024258:mdna:9]
[same as prior period, unchanged from 0001193125-19-284781:mdna:9]

[0001193125-20-024258:mdna:10]
[same as prior period, unchanged from 0001193125-19-284781:mdna:10]

[0001193125-20-024258:mdna:11]
[same as prior period, unchanged from 0001193125-19-284781:mdna:11]

[0001193125-20-024258:mdna:12]
[same as prior period, unchanged from 0001193125-19-284781:mdna:12]

[0001193125-20-024258:mdna:13]
[same as prior period, unchanged from 0001193125-19-284781:mdna:13]

[0001193125-20-024258:mdna:14]
[same as prior period, unchanged from 0001193125-19-284781:mdna:14]

[0001193125-20-024258:mdna:15]
[same as prior period, unchanged from 0001193125-19-284781:mdna:15]

[0001193125-20-024258:mdna:16]
[same as prior period, unchanged from 0001193125-19-284781:mdna:16]

[0001193125-20-024258:mdna:17]
[same as prior period, unchanged from 0001193125-19-284781:mdna:17]

[0001193125-20-024258:mdna:18]
[same as prior period, unchanged from 0001193125-19-284781:mdna:18]

[0001193125-20-024258:mdna:19]
[same as prior period, unchanged from 0001193125-19-284781:mdna:19]

[0001193125-20-024258:mdna:20]
[same as prior period, unchanged from 0001193125-19-284781:mdna:20]

[0001193125-20-024258:mdna:21]
[same as prior period, unchanged from 0001193125-19-284781:mdna:21]

[0001193125-20-024258:mdna:22]
[same as prior period, unchanged from 0001193125-19-284781:mdna:22]

[0001193125-20-024258:mdna:23]
[same as prior period, unchanged from 0001193125-19-284781:mdna:23]

[0001193125-20-024258:mdna:24]
[same as prior period, unchanged from 0001193125-19-284781:mdna:24]

[0001193125-20-024258:mdna:25]
Recent Events

[0001193125-20-024258:mdna:26]
Coronavirus

[0001193125-20-024258:mdna:27]
In December 2019, a strain of Coronavirus surfaced in Wuhan, China, home to numerous high-tech component suppliers, including telecommunications components, and an important transportation hub in China. As a result, there have been numerous factory closures in Wuhan and surrounding areas, and a decrease in traffic in China. As the virus spreads across China, there is uncertainty about whether factories and businesses in other parts of China will be affected. While many factories were closed for a few days because of China’s Lunar New Year holiday (LNY Holiday), the Chinese government has ordered that businesses in various areas extend the LNY Holiday. For example, the Chinese government initially ordered our Casix facility in Fuzhou, China, which manufactures custom optics components, to not resume operations until February 3, 2020, and has subsequently ordered we not resume operations in this facility until after February 9. As a result of this disruption, our revenues for the quarter ending March 27, 2020, will be negatively affected. Moreover, because of the current restrictions on travel in China, our employees may be affected and we may have labor shortages. Also, there can be no assurances the Chinese government will not further extend these closures. Some of our suppliers and customers in China have similarly been affected and currently are experiencing closures and risks of labor shortages. If these suppliers remain closed, we could have difficulty sourcing materials necessary to fulfill production requirements and meet scheduled shipments, which also would negatively affect our revenues. Even if we are able to find alternate sources for such materials, they may cost more, which could affect our profitability. With respect to our customers in China that are experiencing closures, if they are not able to accept orders or if they delay or cancel such orders, our revenues will be negatively affected. At this point in time, there is significant uncertainty relating to the potential effect of the Coronavirus on our business. Infections may become more widespread and factory closures may be extended for longer periods of time and to other parts of China, all of which would have a negative impact on our business, financial condition and operating results.

[0001193125-20-024258:mdna:28]
New CFO

[0001193125-20-024258:mdna:29]
On February 1, 2020, Toh-Seng Ng, Executive Vice President, Chief Financial Officer of the Company, notified the Company that he would retire on February 1, 2021 (the “Retirement Date”). Effective February 17, 2020, Mr. Ng will step down as Chief Financial Officer and transition to Executive Vice President, Special Projects until his Retirement Date. On February 3, 2020, the Company announced that Csaba Sverha was appointed Executive Vice President, Chief Financial Officer of the Company, effective February 17, 2020.

[0001193125-20-024258:mdna:30]
[same as prior period, unchanged from 0001193125-19-284781:mdna:25]

[0001193125-20-024258:mdna:31]
[same as prior period, unchanged from 0001193125-19-284781:mdna:26]

[0001193125-20-024258:mdna:32]
[same as prior period, unchanged from 0001193125-19-284781:mdna:27]

[0001193125-20-024258:mdna:33]
[same as prior period, unchanged from 0001193125-19-284781:mdna:28]

[0001193125-20-024258:mdna:34]
The percentage of our revenues generated from a 
bill-to
 location outside of North America decreased from 54.7% in the three months ended December 28, 2018 to 47.6% in the three months ended December 27, 2019 and from 53.5% in the six months ended December 28, 2018 to 48.6% in the six months ended December 27, 2019, primarily because the increase in sales to our customers in North America was higher than the increase in sales to our customers outside of North America. Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside North America for the remainder of fiscal year 2020 will be in line with the portion of total revenues attributable to such customers during the six months ended December 27, 2019.

[0001193125-20-024258:mdna:35]
[same as prior period, unchanged from 0001193125-19-284781:mdna:30]

[0001193125-20-024258:mdna:36]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 27, 2019 |  |  | December 28, 2018 |  |  | December 27, 2019 |  |  | December 28, 2018 |  |
| North America |  |  | 52.4 | % |  |  | 45.3 | % |  |  | 51.4 | % |  |  | 46.5 | % |
| Asia-Pacific |  |  | 33.1 |  |  |  | 41.4 |  |  |  | 31.4 |  |  |  | 40.8 |  |
| Europe |  |  | 14.5 |  |  |  | 13.3 |  |  |  | 17.2 |  |  |  | 12.7 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-20-024258:mdna:37]
[same as prior period, unchanged from 0001193125-19-284781:mdna:32]

[0001193125-20-024258:mdna:38]
[same as prior period, unchanged from 0001193125-19-284781:mdna:33]

[0001193125-20-024258:mdna:39]
[same as prior period, unchanged from 0001193125-19-284781:mdna:34]

[0001193125-20-024258:mdna:40]
[same as prior period, unchanged from 0001193125-19-284781:mdna:35]

[0001193125-20-024258:mdna:41]
[same as prior period, unchanged from 0001193125-19-284781:mdna:36]

[0001193125-20-024258:mdna:42]
[same as prior period, unchanged from 0001193125-19-284781:mdna:37]

[0001193125-20-024258:mdna:43]
[same as prior period, unchanged from 0001193125-19-284781:mdna:38]

[0001193125-20-024258:mdna:44]
[same as prior period, unchanged from 0001193125-19-284781:mdna:39]

[0001193125-20-024258:mdna:45]
[same as prior period, unchanged from 0001193125-19-284781:mdna:40]

[0001193125-20-024258:mdna:46]
The compensation committee of our board of directors approved a fiscal year 2020 executive incentive plan with quantitative objectives that are based solely on achieving certain revenue targets and 
non-GAAP
 operating margin targets for our fiscal year ending June 26, 2020. Bonuses under the fiscal year 2020 executive incentive plan are payable after the end of fiscal year 2020. In fiscal year 2019, the compensation committee of our board of directors approved a fiscal year 2019 executive incentive plan with quantitative objectives based solely on achieving certain revenue targets and 
non-GAAP
 gross margin targets for fiscal year 2019.

[0001193125-20-024258:mdna:47]
[same as prior period, unchanged from 0001193125-19-284781:mdna:43]

[0001193125-20-024258:mdna:48]
[same as prior period, unchanged from 0001193125-19-284781:mdna:44]

[0001193125-20-024258:mdna:49]
[same as prior period, unchanged from 0001193125-19-284781:mdna:45]

[0001193125-20-024258:mdna:50]
[same as prior period, unchanged from 0001193125-19-284781:mdna:46]

[0001193125-20-024258:mdna:51]
[same as prior period, unchanged from 0001193125-19-284781:mdna:47]

[0001193125-20-024258:mdna:52]
|  |  | As of December 27, 2019 |  |  | As of June 28, 2019 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 707,872 |  |  | $ | 23,463 |  |  |  | 54.0 |  |  |  | 664,860 |  |  | $ | 21,628 |  |  |  | 60.0 |  |
| RMB |  |  | 87,453 |  |  |  | 12,515 |  |  |  | 28.8 |  |  |  | 53,393 |  |  |  | 7,767 |  |  |  | 21.5 |  |
| GBP |  |  | 5,751 |  |  |  | 7,474 |  |  |  | 17.2 |  |  |  | 5,270 |  |  |  | 6,682 |  |  |  | 18.5 |  |
| Total |  |  |  |  |  | $ | 43,452 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 36,077 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,862,509 |  |  | $ | 61,734 |  |  |  | 85.9 |  |  |  | 1,961,972 |  |  | $ | 63,825 |  |  |  | 90.0 |  |
| RMB |  |  | 53,890 |  |  |  | 7,712 |  |  |  | 10.8 |  |  |  | 26,373 |  |  |  | 3,836 |  |  |  | 5.4 |  |
| GBP |  |  | 1,841 |  |  |  | 2,392 |  |  |  | 3.3 |  |  |  | 2,598 |  |  |  | 3,294 |  |  |  | 4.6 |  |
| Total |  |  |  |  |  | $ | 71,838 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 70,955 |  |  |  | 100.0 |  |

[0001193125-20-024258:mdna:53]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of December 27, 2019 there was $126.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 28, 2019, there was $72.0 million of foreign currency forward contracts outstanding on the Thai baht payables.

[0001193125-20-024258:mdna:54]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of December 27, 2019 and June 28, 2019, we did not have any derivative contracts denominated in RMB.

[0001193125-20-024258:mdna:55]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable and other payables. As of December 27, 2019 and June 28, 2019, we did not have any derivative contracts denominated in GBP.

[0001193125-20-024258:mdna:56]
For the six months ended December 27, 2019 and December 28, 2018, we recorded realized gain of $0.8 million and $0.3 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-20-024258:mdna:57]
[same as prior period, unchanged from 0001193125-19-284781:mdna:53]

[0001193125-20-024258:mdna:58]
[same as prior period, unchanged from 0001193125-19-284781:mdna:54]

[0001193125-20-024258:mdna:59]
[same as prior period, unchanged from 0001193125-19-284781:mdna:55]

[0001193125-20-024258:mdna:60]
[same as prior period, unchanged from 0001193125-19-284781:mdna:56]

[0001193125-20-024258:mdna:61]
[same as prior period, unchanged from 0001193125-19-284781:mdna:57]

[0001193125-20-024258:mdna:62]
[same as prior period, unchanged from 0001193125-19-284781:mdna:58]

[0001193125-20-024258:mdna:63]
[same as prior period, unchanged from 0001193125-19-284781:mdna:59]

[0001193125-20-024258:mdna:64]
[same as prior period, unchanged from 0001193125-19-284781:mdna:60]

[0001193125-20-024258:mdna:65]
[same as prior period, unchanged from 0001193125-19-284781:mdna:61]

[0001193125-20-024258:mdna:66]
[same as prior period, unchanged from 0001193125-19-284781:mdna:62]

[0001193125-20-024258:mdna:67]
[same as prior period, unchanged from 0001193125-19-284781:mdna:63]

[0001193125-20-024258:mdna:68]
[same as prior period, unchanged from 0001193125-19-284781:mdna:64]

[0001193125-20-024258:mdna:69]
[same as prior period, unchanged from 0001193125-19-284781:mdna:65]

[0001193125-20-024258:mdna:70]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption is currently available to us through June 2020 and June 2026 on income generated from projects to manufacture certain products at our Pinehurst campus and Chonburi campus, respectively. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted (i.e., at least until June 2020 in the case of our Pinehurst campus and until June 2026 in the case of our Chonburi campus). Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001193125-20-024258:mdna:71]
[same as prior period, unchanged from 0001193125-19-284781:mdna:68]

[0001193125-20-024258:mdna:72]
[same as prior period, unchanged from 0001193125-19-284781:mdna:69]

[0001193125-20-024258:mdna:73]
[same as prior period, unchanged from 0001193125-19-284781:mdna:70]

[0001193125-20-024258:mdna:74]
Our critical accounting policies are disclosed in our Annual Report on Form 
10-K
 for the fiscal year ended June 28, 2019. The adoption of new accounting policies and accounting standards are disclosed in Note 2 to the unaudited condensed consolidated financial statements. There were no changes to our accounting policies other than the adoption of Leases (Topic 842) and Derivatives and Hedging (Topic 815), which resulted from Accounting Standards Codification Topic 842 (“ASC 842”) and Accounting Standards Codification Topic 815 (“ASC 815”), respectively.

[0001193125-20-024258:mdna:75]
We adopted ASC 842 using the modified retrospective transition approach, effective on June 29, 2019. Accordingly, our comparative financial statements as of June 28, 2019 will not be adjusted. ASC 842 also provides practical expedients for our ongoing accounting. We plan to elect the short-term lease recognition exemption for our operating leases with terms of less than 12 months, which will not require recognition of right of use assets or lease liabilities for these leases.

[0001193125-20-024258:mdna:76]
[same as prior period, unchanged from 0001193125-19-284781:mdna:73]

[0001193125-20-024258:mdna:77]
[same as prior period, unchanged from 0001193125-19-284781:mdna:74]

[0001193125-20-024258:mdna:78]
[same as prior period, unchanged from 0001193125-19-284781:mdna:75]

[0001193125-20-024258:mdna:79]
| (amount in thousands) |  | Three Months Ended |  |  | Six Months Ended |  |
| December 27, 2019 |  |  | December 28, 2018 |  |  | December 27, 2019 |  |  | December 28, 2018 |  |
| Revenues |  | $ | 426,217 |  |  | $ | 403,080 |  |  | $ | 825,513 |  |  | $ | 780,257 |  |
| Cost of revenues |  |  | (377,059 | ) |  |  | (357,516 | ) |  |  | (730,368 | ) |  |  | (694,417 | ) |
| Gross profit |  |  | 49,158 |  |  |  | 45,564 |  |  |  | 95,145 |  |  |  | 85,840 |  |
| Selling, general and administrative expenses |  |  | (17,078 | ) |  |  | (12,727 | ) |  |  | (33,078 | ) |  |  | (27,164 | ) |
| Expenses related to reduction in workforce |  |  | (16 | ) |  |  | (319 | ) |  |  | (16 | ) |  |  | (404 | ) |
| Operating income |  |  | 32,064 |  |  |  | 32,518 |  |  |  | 62,051 |  |  |  | 58,272 |  |
| Interest income |  |  | 1,940 |  |  |  | 1,182 |  |  |  | 4,038 |  |  |  | 2,626 |  |
| Interest expense |  |  | (181 | ) |  |  | (1,616 | ) |  |  | (2,574 | ) |  |  | (2,250 | ) |
| Foreign exchange (loss) gain, net |  |  | (988 | ) |  |  | (421 | ) |  |  | (2,941 | ) |  |  | 2,647 |  |
| Other income, net |  |  | 397 |  |  |  | 562 |  |  |  | 774 |  |  |  | 639 |  |
| Income before income taxes |  |  | 33,232 |  |  |  | 32,225 |  |  |  | 61,348 |  |  |  | 61,934 |  |
| Income tax expense |  |  | (2,001 | ) |  |  | (712 | ) |  |  | (4,160 | ) |  |  | (2,571 | ) |
| Net income |  |  | 31,231 |  |  |  | 31,513 |  |  |  | 57,188 |  |  |  | 59,363 |  |
| Other comprehensive income, net of tax |  |  | 446 |  |  |  | 93 |  |  |  | 234 |  |  |  | 180 |  |
| Net comprehensive income |  | $ | 31,677 |  |  | $ | 31,606 |  |  | $ | 57,422 |  |  | $ | 59,543 |  |

[0001193125-20-024258:mdna:80]
[same as prior period, unchanged from 0001193125-19-284781:mdna:77]

[0001193125-20-024258:mdna:81]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 27, 2019 |  |  | December 28, 2018 |  |  | December 27, 2019 |  |  | December 28, 2018 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (88.5 | ) |  |  | (88.7 | ) |  |  | (88.5 | ) |  |  | (89.0 | ) |
| Gross profit |  |  | 11.5 |  |  |  | 11.3 |  |  |  | 11.5 |  |  |  | 11.0 |  |
| Selling, general and administrative expenses |  |  | (4.0 | ) |  |  | (3.2 | ) |  |  | (4.0 | ) |  |  | (3.5 | ) |
| Expenses related to reduction in workforce |  |  | — |  |  |  | (0.0 | ) |  |  | — |  |  |  | (0.0 | ) |
| Operating income |  |  | 7.5 |  |  |  | 8.1 |  |  |  | 7.5 |  |  |  | 7.5 |  |
| Interest income |  |  | 0.4 |  |  |  | 0.3 |  |  |  | 0.5 |  |  |  | 0.3 |  |
| Interest expense |  |  | (0.0 | ) |  |  | (0.4 | ) |  |  | (0.3 | ) |  |  | (0.3 | ) |
| Foreign exchange (loss) gain, net |  |  | (0.2 | ) |  |  | (0.1 | ) |  |  | (0.4 | ) |  |  | 0.3 |  |
| Other income, net |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Income before income taxes |  |  | 7.8 |  |  |  | 8.0 |  |  |  | 7.4 |  |  |  | 7.9 |  |
| Income tax expense |  |  | (0.5 | ) |  |  | (0.2 | ) |  |  | (0.5 | ) |  |  | (0.3 | ) |
| Net income |  |  | 7.3 |  |  |  | 7.8 |  |  |  | 6.9 |  |  |  | 7.6 |  |
| Other comprehensive income, net of tax |  |  | 0.1 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.0 |  |
| Net comprehensive income |  |  | 7.4 | % |  |  | 7.8 | % |  |  | 6.9 | % |  |  | 7.6 | % |

[0001193125-20-024258:mdna:82]
[same as prior period, unchanged from 0001193125-19-284781:mdna:80]

[0001193125-20-024258:mdna:83]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands) |  | December 27, 2019 |  |  | December 28, 2018 |  |  | December 27, 2019 |  |  | December 28, 2018 |  |
| Optical communications |  | $ | 322,068 |  |  | $ | 305,547 |  |  | $ | 624,447 |  |  | $ | 586,315 |  |
| Lasers, sensors and other |  |  | 104,149 |  |  |  | 97,533 |  |  |  | 201,066 |  |  |  | 193,942 |  |
| Total |  | $ | 426,217 |  |  | $ | 403,080 |  |  | $ | 825,513 |  |  | $ | 780,257 |  |

[0001193125-20-024258:mdna:84]
[same as prior period, unchanged from 0001193125-19-284781:mdna:82]

[0001193125-20-024258:mdna:85]
39

[0001193125-20-024258:mdna:86]
Comparison of Three and Six Months Ended December 27, 2019 with Three and Six Months Ended December 28, 2018

[0001193125-20-024258:mdna:87]
[same as prior period, unchanged from 0001193125-19-284781:mdna:84]

[0001193125-20-024258:mdna:88]
[same as prior period, unchanged from 0001193125-19-284781:mdna:85]

[0001193125-20-024258:mdna:89]
Our total revenues increased by $23.1 million, or 5.7%, to $426.2 million for the three months ended December 27, 2019, compared with $403.1 million for the three months ended December 28, 2018. This increase was primarily due to an increase in our customers’ demand for both optical and 
non-optical
 communications manufacturing services during the three months ended December 27, 2019. Revenues from optical and 
non-optical
 communications products increased by $16.5 million and $6.6 million, or 5.4% and 6.8%, respectively, for the three months ended December 27, 2019.

[0001193125-20-024258:mdna:90]
Our total revenues increased by $45.3 million, or 5.8%, to $825.5 million for the six months ended December 27, 2019, compared with $780.3 million for the six months ended December 28, 2018. This increase was primarily due to an increase in our customers’ demand for both optical and 
non-optical
 communications manufacturing services during the six months ended December 27, 2019. Revenues from optical and 
non-optical
 communications products increased by $38.1 million and $7.1 million, or 6.5% and 3.7%, respectively, for the six months ended December 27, 2019.

[0001193125-20-024258:mdna:91]
[same as prior period, unchanged from 0001193125-19-284781:mdna:87]

[0001193125-20-024258:mdna:92]
[same as prior period, unchanged from 0001193125-19-284781:mdna:88]

[0001193125-20-024258:mdna:93]
Our cost of revenues increased by $19.5 million, or 5.5%, to $377.1 million, or 88.5% of total revenues, for the three months ended December 27, 2019, compared with $357.5 million, or 88.7% of total revenues, for the three months ended December 28, 2018. This increase in cost of revenues on an absolute dollar basis was in line with the increase in sales volume.

[0001193125-20-024258:mdna:94]
Our cost of revenues increased by $36.0 million, or 5.2%, to $730.4 million, or 88.5% of total revenues, for the six months ended December 27, 2019, compared with $694.4 million, or 89.0% of total revenues, for the six months ended December 28, 2018. This increase in cost of revenues on an absolute dollar basis was in line with the increase in sales volume.

[0001193125-20-024258:mdna:95]
[same as prior period, unchanged from 0001193125-19-284781:mdna:90]

[0001193125-20-024258:mdna:96]
[same as prior period, unchanged from 0001193125-19-284781:mdna:91]

[0001193125-20-024258:mdna:97]
Our gross profit increased by $3.6 million, or 7.9%, to $49.2 million, or 11.5% of total revenues, for the three months ended December 27, 2019, compared with $45.6 million, or 11.3% of total revenues, for the three months ended December 28, 2018. The increase was primarily due to an increase in revenues and effective cost controls.

[0001193125-20-024258:mdna:98]
Our gross profit increased by $9.3 million, or 10.8%, to $95.1 million, or 11.5% of total revenues, for the six months ended December 27, 2019, compared with $85.8 million, or 11.0% of total revenues, for the six months ended December 28, 2018. The increase was primarily due to an increase in revenues and effective cost controls.

[0001193125-20-024258:mdna:99]
[same as prior period, unchanged from 0001193125-19-284781:mdna:93]

[0001193125-20-024258:mdna:100]
[same as prior period, unchanged from 0001193125-19-284781:mdna:94]

[0001193125-20-024258:mdna:101]
Our SG&A expenses increased by $4.4 million, or 34.3%, to $17.1 million, or 4.0% of total revenues, for the three months ended December 27, 2019, compared with $12.7 million, or 3.2% of total revenues, for the three months ended December 28, 2018. The increase was primarily due to (1) an increase in share-based compensation expenses of $1.9 million; (2) an increase in executive and management expenses of $1.2 million; (3) an increase in severance liabilities of $0.3 million; and (4) an increase in new business 
start-up
 costs of $0.5 million.

[0001193125-20-024258:mdna:102]
Our SG&A expenses increased by $5.9 million, or 21.8%, to $33.1 million, or 4.0% of total revenues, for the six months ended December 27, 2019, compared with $27.2 million, or 3.5% of total revenues, for the six months ended December 28, 2018. The increase was primarily due to (1) an increase in share-based compensation expenses of $3.1 million; (2) an increase in executive and management expenses of $1.8 million; (3) an increase in severance liabilities of $0.6 million; and (4) an increase in new business 
start-up
 costs of $0.5 million.

[0001193125-20-024258:mdna:103]
[same as prior period, unchanged from 0001193125-19-284781:mdna:96]

[0001193125-20-024258:mdna:104]
Our operating income decreased by $0.5 million to $32.1 million, or 7.5% of total revenues, for the three months ended December 27, 2019, compared with $32.5 million, or 8.1% of total revenues, for the three months ended December 28, 2018. The decrease was primarily due to an increase in SG&A expenses.

[0001193125-20-024258:mdna:105]
Our operating income increased by $3.8 million to $62.1 million, or 7.5% of total revenues, for the six months ended December 27, 2019, compared with $58.3 million, or 7.5% of total revenues, for the six months ended December 28, 2018. The increase was primarily due to an increase in revenues.

[0001193125-20-024258:mdna:106]
[same as prior period, unchanged from 0001193125-19-284781:mdna:98]

[0001193125-20-024258:mdna:107]
[same as prior period, unchanged from 0001193125-19-284781:mdna:99]

[0001193125-20-024258:mdna:108]
Our interest income increased by $0.8 million, or 64.1%, to $1.9 million, or 0.5% of total revenues, for the three months ended December 27, 2019, compared with $1.2 million, or 0.3% of total revenues, for the three months ended December 28, 2018. The increase was primarily due to the higher weighted average interest rate and an increase in the average balance of our outstanding cash compared to the same period in the previous year.

[0001193125-20-024258:mdna:109]
Our interest income increased by $1.4 million, or 53.8%, to $4.0 million, or 0.5% of total revenues, for the six months ended December 27, 2019, compared with $2.6 million, or 0.3% of total revenues, for the six months ended December 28, 2018. The increase was primarily due to the higher weighted average interest rate and an increase in the average balance of our outstanding cash compared to the same period in the previous year.

[0001193125-20-024258:mdna:110]
[same as prior period, unchanged from 0001193125-19-284781:mdna:101]

[0001193125-20-024258:mdna:111]
[same as prior period, unchanged from 0001193125-19-284781:mdna:102]

[0001193125-20-024258:mdna:112]
Our interest expense decreased by $1.4 million to $0.2 million for the three months ended December 27, 2019, compared with $1.6 million for the three months ended December 28, 2018. The decrease was due to the implementation of cash flow hedge on interest rate swaps at September 27, 2019 which resulted in (1) the reduction of interest expense of $0.9 million from the recognition of unrealized loss from mark-to-market of interest rate swaps in other comprehensive income instead of in interest expense; and (2) the amortization of the fair value of interest rate swaps as of hedge inception date of $0.4 million during the three months ended December 27, 2019 in relation to applying hedge accounting which results in the decrease in interest expense.

[0001193125-20-024258:mdna:113]
Our interest expense increased by $0.3 million to $2.6 million for the six months ended December 27, 2019, compared with $2.3 million for the six months ended December 28, 2018. The increase was primarily due to an unrealized loss from mark-to-market of interest rate swaps of $1.7 million for the three months ended September 27, 2019, before applying cash flow hedge, as compared to an unrealized loss of $0.8 million for the six months ended December 28, 2018; offset by the amortization of the fair value of interest rate swaps as of hedge inception date of $0.4 million during the three months ended December 27, 2019 in relation to applying hedge accounting which results in the decrease in interest expense.

[0001193125-20-024258:mdna:114]
[same as prior period, unchanged from 0001193125-19-284781:mdna:104]

[0001193125-20-024258:mdna:115]
We recorded foreign exchange loss, net of $1.0 million for the three months ended December 27, 2019, compared with $0.4 million loss for the three months ended December 28, 2018. During the three months ended December 27, 2019, foreign exchange loss mainly came from realized loss from payments and receipts of $1.5 million, compared to the three months ended December 28, 2018, foreign exchange loss mainly came from unrealized loss from revaluation of outstanding Thai Baht assets and liabilities of $0.8 million.

[0001193125-20-024258:mdna:116]
We recorded foreign exchange loss, net of $2.9 million for the six months ended December 27, 2019, compared with $2.6 million gain for the six months ended December 28, 2018. During the six months ended December 27, 2019, foreign exchange loss mainly came from unrealized loss of $1.9 million from 
mark-to-market
 of forward contracts and realized loss from payments and receipts of $1.0 million, compared to the six months ended December 28, 2018, foreign exchange gain mainly came from unrealized gain of $2.6 million from 
mark-to-market
 of forward contracts and realized gain from payments and receipts of $1.5 million.

[0001193125-20-024258:mdna:117]
[same as prior period, unchanged from 0001193125-19-284781:mdna:106]

[0001193125-20-024258:mdna:118]
[same as prior period, unchanged from 0001193125-19-284781:mdna:107]

[0001193125-20-024258:mdna:119]
We recorded income before income taxes of $33.2 million and $61.3 million for the three and six months ended December 27, 2019, respectively, compared with $32.2 million and $61.9 million for the three and six months ended December 28, 2018, respectively.

[0001193125-20-024258:mdna:120]
[same as prior period, unchanged from 0001193125-19-284781:mdna:109]

[0001193125-20-024258:mdna:121]
Our provision for income tax reflects an effective tax rate of 4.9% and 4.2% for the three months ended December 27, 2019 and December 28, 2018, respectively. The increase was primarily due to the fact that we had higher income subject to tax during the three months ended December 27, 2019 as compared to the same period in fiscal year 2019.

[0001193125-20-024258:mdna:122]
Our provision for income tax reflects an effective tax rate of 5.0% and 5.1% for the six months ended December 27, 2019 and December 28, 2018, respectively. The decrease was primarily due to the fact that we had lower income subject to tax during the six months ended December 27, 2019 as compared to the same period in fiscal year 2019.

[0001193125-20-024258:mdna:123]
[same as prior period, unchanged from 0001193125-19-284781:mdna:111]

[0001193125-20-024258:mdna:124]
[same as prior period, unchanged from 0001193125-19-284781:mdna:112]

[0001193125-20-024258:mdna:125]
We recorded net income of $31.2 million, or 7.3% of total revenues, for the three months ended December 27, 2019, compared with $31.5 million, or 7.8% of total revenues, for the three months ended December 28, 2018. The decrease was primarily due to (1) a net increase in SG&A expenses of $4.4 million; (2) an increase in income tax expenses of $1.3 million due to the valuation allowance for deferred tax assets; and (3) a net increase in foreign exchange loss of $0.6 million; partially offset by (1) an increase in gross profit of $3.6 million due to increased revenues and effective cost control; (2) a net change in interest income and expense of $2.2 million; and (3) a decrease in expenses related to reduction in workforce of $0.3 million.

[0001193125-20-024258:mdna:126]
We recorded net income of $57.2 million, or 6.9% of total revenues, for the six months ended December 27, 2019, compared with $59.4 million, or 7.6% of total revenues, for the six months ended December 28, 2018. The decrease was primarily due to (1) a net increase in SG&A expenses of $5.9 million; (2) a net change in foreign exchange gain (loss) of $5.6 million; and (3) an increase in income tax expenses of $1.6 million primarily due to the valuation allowance for deferred tax assets; partially offset by (1) an increase in gross profit of $9.3 million due to increased revenues and effective cost control; (2) a net change in interest income and expense of $1.1 million; and (3) a decrease in expenses related to reduction in workforce of $0.4 million.

[0001193125-20-024258:mdna:127]
[same as prior period, unchanged from 0001193125-19-284781:mdna:114]

[0001193125-20-024258:mdna:128]
We recorded other comprehensive income of $0.4 million, or 0.1% of total revenues, for the three months ended December 27, 2019, compared with other comprehensive income of $93 thousand, or 0.0% of total revenues, for the three months ended December 28, 2018.

[0001193125-20-024258:mdna:129]
We recorded other comprehensive income of $0.2 million, or 0.0% of total revenues, for the six months ended December 27, 2019, compared with other comprehensive income of $0.2 million, or 0.0% of total revenues, for the six months ended December 28, 2018.

[0001193125-20-024258:mdna:130]
[same as prior period, unchanged from 0001193125-19-284781:mdna:116]

[0001193125-20-024258:mdna:131]
[same as prior period, unchanged from 0001193125-19-284781:mdna:117]

[0001193125-20-024258:mdna:132]
We primarily finance our operations through cash flow from operations. As of December 27, 2019 and December 28, 2018, we had cash, cash equivalents, and short-term investments of $442.8 million and $382.5 million, respectively, and outstanding debt of $57.9 million and $63.4 million, respectively.

[0001193125-20-024258:mdna:133]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents for each of the three and six months ended December 27, 2019 was 2.0% and for the three and six months ended December 28, 2018 was 1.4% and 1.6%, respectively.

[0001193125-20-024258:mdna:134]
[same as prior period, unchanged from 0001193125-19-284781:mdna:120]

[0001193125-20-024258:mdna:135]
During the six months ended December 27, 2019, we paid off an existing term loan of $60.9 million under our previous Bank of America Facility Agreement, our subsidiaries in Thailand drew down a new term loan of $60.9 million under a new Credit Facility Agreement with the Bank of Ayudhya Public Company Limited and we repaid $3.0 million of the new term loan. As a result, as of December 27, 2019, we had a long-term borrowing of $57.9 million under our new Credit Facility Agreement. (See Note 14 for further details.) We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held short-term investments of $222.8 million as of December 27, 2019.

[0001193125-20-024258:mdna:136]
We believe that our current cash and cash equivalents, marketable securities, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 
10-Q.

[0001193125-20-024258:mdna:137]
[same as prior period, unchanged from 0001193125-19-284781:mdna:123]

[0001193125-20-024258:mdna:138]
[same as prior period, unchanged from 0001193125-19-284781:mdna:124]

[0001193125-20-024258:mdna:139]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 27, 2019 |  |  | December 28, 2018 |  |
| Net cash provided by operating activities |  | $ | 52,610 |  |  | $ | 69,298 |  |
| Net cash (used in) provided by investing activities |  | $ | (5,731 | ) |  | $ | 13,141 |  |
| Net cash used in financing activities |  | $ | (7,766 | ) |  | $ | (13,649 | ) |
| Net increase in cash, cash equivalents and restricted cash |  | $ | 39,113 |  |  | $ | 68,790 |  |

[0001193125-20-024258:mdna:140]
[same as prior period, unchanged from 0001193125-19-284781:mdna:126]

[0001193125-20-024258:mdna:141]
Net cash provided by operating activities decreased by $16.7 million, or 24.1%, to $52.6 million for the six months ended December 27, 2019, compared with net cash provided by operating activities of $69.3 million for the six months ended December 28, 2018. This decrease was primarily due to (1) an increase of $52.1 million in payments to trade accounts payable; and (2) a decrease in accounts receivable of $10.6 million. These increases were offset by (1) an increase of $28.1 million in inventory; (2) an increase in unrealized loss on exchange rate and fair value of derivative instruments of $7.0 million; (3) an increase of $5.3 million in other current assets and 
non-current
 assets; and (4) an increase in contract assets of $4.8 million.

[0001193125-20-024258:mdna:142]
[same as prior period, unchanged from 0001193125-19-284781:mdna:128]

[0001193125-20-024258:mdna:143]
Net cash used in investing activities increased by $18.8 million, or 143.6%, to $5.7 million for the six months ended December 27, 2019, compared with net cash provided by investing activities of $13.1 million for the six months ended December 28, 2018. This increase was primarily due to (1) funds provided to our customer of $24.3 million to support the customer’s transfer of certain manufacturing operations from Berlin, German to the Company’s facilities in Thailand, which the customer has agreed to repay by September 30, 2020; and (2) an increase in investments in property, plant and equipment and intangibles of $6.2 million, offset by net cash received from short-term investments of $10.5 million.

[0001193125-20-024258:mdna:144]
[same as prior period, unchanged from 0001193125-19-284781:mdna:130]

[0001193125-20-024258:mdna:145]
Net cash used in financing activities decreased by $5.8 million, or 43.1%, to $7.8 million for the six months ended December 27, 2019, compared with net cash used in financing activities of $13.6 million for the six months ended December 28, 2018. This decrease was primarily due to (1) a decrease in withholding tax related to net share settlement of restricted share units of $4.7 million; and (2) the release of restricted cash in connection with business acquisition of $3.5 million. These decreases were offset by an increase of $2.3 million in repayments of loans from bank.

[0001193125-20-024258:mdna:146]
[same as prior period, unchanged from 0001193125-19-284781:mdna:132]

[0001193125-20-024258:mdna:147]
As of December 27, 2019, we had two outstanding standby letters of credit in the aggregate amount of 6.2 million Euros, related to our support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to our facilities in Thailand. As of December 27, 2019, the standby letters of credit were backed by cash collateral of in the aggregate amount of $7.7 million.

[0001193125-20-024258:mdna:148]
[same as prior period, unchanged from 0001193125-19-284781:mdna:134]

[0001193125-20-024258:mdna:149]
[same as prior period, unchanged from 0001193125-19-284781:mdna:135]
