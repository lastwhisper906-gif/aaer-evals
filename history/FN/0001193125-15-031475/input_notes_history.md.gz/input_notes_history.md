# FN note change history — 0001193125-14-398478 → 0001193125-15-031475


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-02-03):
[0001193125-15-031475:note_history:1]
As of December 26, 2014 and June 27, 2014, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $0.8 million and $0.3 million, respectively.
  (was, 2014-11-05, similarity 0.984):
[0001193125-14-398478:note_history:1]
As of
 September 26, 2014 and June 27, 2014, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $0.8 million and $0.3 million, respectively.

- changed (2015-02-03):
[0001193125-15-031475:note_history:2]
The Company leases a portion of its capital equipment and certain
 land and buildings for its facilities in China and New Jersey under
 operating lease arrangements that expire in various calendar years
 through 2020. Rental expense under these operating leases amounted
 to $0.5 million and $0.4 million for the six months ended
 December 26, 2014 and December 27, 2013,
 respectively.
  (was, 2014-11-05, similarity 0.9311):
[0001193125-14-398478:note_history:2]
The Company
 leases a portion of its capital equipment and certain land and
 buildings for its facilities in China and New Jersey under
 operating lease arrangements that expire in various calendar years
 through 2020. Rental expense under these operating leases amounted
 to $0.2 million and $0.2 million for the three months ended
 September 26, 2014 and September 27, 2013,
 respectively.

- changed (2015-02-03):
[0001193125-15-031475:note_history:3]
As of December 26, 2014, the future minimum lease payments due
 under non-cancelable leases are as follows at the end of each
 fiscal year below:
  (was, 2014-11-05, similarity 0.9818):
[0001193125-14-398478:note_history:3]
As of
 September 26, 2014, the future minimum lease payments due
 under non-cancelable leases are as follows at the end of each
 fiscal year below:

- added (2015-02-03):
[0001193125-15-031475:note_history:4]
As of December 26, 2014, the Company had an outstanding
 commitment to third parties of $5.9 million.

- removed (2015-02-03):
[0001193125-14-398478:note_history:5]
As of
 September 26, 2014, there were no outstanding capital
 expenditure commitments.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-02-03):
[0001193125-15-031475:note_history:6]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended
 December 26, 2014 and December 27, 2013 each consisted of
 13 weeks. The six months ended December 26, 2014 and
 December 27, 2013 each consisted of 26 weeks. Fiscal year 2015
 will be comprised of 52 weeks and will end on June 26,
 2015.
  (was, 2014-11-05, similarity 0.7374):
[0001193125-14-398478:note_history:6]
The Company
 utilizes a 52-53 week fiscal year ending on the Friday in June
 closest to June 30. The three months ended September 26,
 2014 and September 27, 2013 each consisted of 13 weeks. Fiscal
 year 2015 will be comprised of 52 weeks and will end on
 June 26, 2015.

- changed (2015-02-03):
[0001193125-15-031475:note_history:7]
Financial instruments that potentially subject the Company to
 concentrations of credit risk consist of cash and cash equivalents,
 marketable securities, derivatives and accounts receivable.
  (was, 2014-11-05, similarity 0.9352):
[0001193125-14-398478:note_history:7]
Financial
 instruments that potentially subject the Company to concentrations
 of credit risk consist of cash and cash equivalents, derivatives
 and accounts receivable.

- changed (2015-02-03):
[0001193125-15-031475:note_history:8]
Cash, cash equivalents and marketable securities are maintained
 with several financial institutions. Deposits held with banks may
 exceed the amount of insurance provided on such deposits.
 Generally, these deposits may be redeemed upon demand and are
 maintained with financial institutions with reputable credit and
 therefore bear minimal credit risk. The Company seeks to mitigate
 its credit risks by spreading such risks across multiple
 counterparties and monitoring the risk profiles of these
 counterparties. The Company limits its investments in marketable
 securities to securities with a maturity not in excess of three
 years, and all marketable securities that the Company invests in
 are rated A1, P-1, F1, or better.
  (was, 2014-11-05, similarity 0.801):
[0001193125-14-398478:note_history:8]
Cash and cash
 equivalents are maintained with several financial institutions.
 Deposits held with banks may exceed the amount of insurance
 provided on such deposits. Generally, these deposits may be
 redeemed upon demand and are maintained with financial institutions
 with reputable credit and therefore bear minimal credit risk. The
 Company seeks to mitigate its credit risks by spreading such risks
 across multiple counterparties and monitoring the risk profiles of
 these counterparties.

- added (2015-02-03):
[0001193125-15-031475:note_history:9]
Revenue recognition

- added (2015-02-03):
[0001193125-15-031475:note_history:10]
Certain customers may request the Company to store finished
 products on their behalf. In these situations revenue is only
 recognized when the goods are completed
 and ready for shipment, and title and risk of loss have passed to
 the customer. The Company receives a written request from the
 customer asking the Company to hold the inventory at the Company
 warehouse, and the ordered goods are segregated in the Company
 warehouse from other inventory and cannot be used to fulfill other
 customer orders.

- added (2015-02-03):
[0001193125-15-031475:note_history:11]
In January 2015, the Financial Accounting Standards Board (FASB)
 issued Accounting Standard Update (ASU) No. 2015-01,
 “Income Statement – Extraordinary and Unusual Items
 (Subtopic 225-20): Simplifying Income Statement presentation by
 Eliminating the Concept of Extraordinary Items”. The
 objective of this amendments are to reduce the complexity of
 extraordinary items concept by the concept of extraordinary items,
 subtopic 225-20. Presently, an event or transaction is presumed to
 be an ordinary and usual activity of the reporting entity unless
 evidence clearly supports its classification as an extraordinary
 item. The criteria that must both be met for extraordinary
 classification: (a) unusual nature with high degree of
 abnormality and be of a type clearly unrelated to, or only
 incidentally related to the ordinary and typical activities of the
 entity; and (b) infrequency of occurrence of the event which
 should not reasonably be expected to recur in the foreseeable
 future. This amendments are effective for fiscal years and interim
 periods beginning after December 15, 2015. Early adoption is
 permitted provided that the guidance is applied from the beginning
 of the fiscal year of adoption. The Company does not expect that
 the adoption of this update will have an effect on its consolidated
 financial statements.

- changed (2015-02-03):
[0001193125-15-031475:note_history:12]
In August 2014, the FASB issued ASU No. 2014-15,
 “Presentation of Financial Statements – Going Concern
 (Subtopic 205-40): Disclosure of Uncertainties about an
 Entity’s Ability to Continue as a Going Concern”. The
 amendments require management to evaluate, for each annual and
 interim reporting period, an entity’s ability to continue as
 a going concern when relevant conditions and events, considered in
 the aggregate, indicate that it is probable that the entity will be
 unable to meet its obligations that become due within one year
 after the date that the financial statements are issued (or
 available to be issued). This ASU is effective for annual periods
 and interim reporting periods beginning after December 15,
 2016. The Company does not expect that the adoption of this update
 will have an effect on its consolidated financial statements.
  (was, 2014-11-05, similarity 0.9444):
[0001193125-14-398478:note_history:12]
In August 2014,
 The Financial Accounting Standards Board (FASB) issued Accounting
 Standard Update (ASU) No. 2014-15, “Presentation of
 Financial Statements – Going Concern (Subtopic 205-40):
 Disclosure of Uncertainties about an Entity’s Ability to
 Continue as a Going Concern”. The amendments require
 management to evaluate, for each annual and interim reporting
 period, an entity’s ability to continue as a going concern
 when relevant conditions and events, considered in the aggregate,
 indicate that it is probable that the entity will be unable to meet
 its obligations that become due within one year after the date that
 the financial statements are issued (or available to be issued).
 This ASU is effective for annual periods and interim reporting
 periods beginning after December 15, 2016. The Company does
 not expect that the adoption of this update will have an effect on
 its consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-02-03):
[0001193125-15-031475:note_history:13]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Term |  | As of December 26, 2014 |  |  | As of June 27, 2014 |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | June 2012 – March 2017 |  | $ | 13,500 |  |  | $ | 16,500 |  |
| Less: Current portion |  |  |  |  |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  |  |  |  | $ | 7,500 |  |  | $ | 10,500 |  |
  (was, 2014-11-05, similarity 0.9682):
[0001193125-14-398478:note_history:13]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Term |  | As of September 26, 2014 |  |  | As of June 27, 2014 |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | June 2012 – March 2017 |  | $ | 15,000 |  |  | $ | 16,500 |  |
| Less: Current portion |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  | $ | 9,000 |  |  | $ | 10,500 |  |

- changed (2015-02-03):
[0001193125-15-031475:note_history:14]
On April 25, 2014, a subsidiary entered into an amendment to
 the bank borrowing agreement. Under the amendment of the contract,
 the long-term loan is secured by certain property, plant and
 equipment. The carrying amount of assets secured and pledged as
 collateral as of December 26, 2014 and June 27, 2014 was
 $51.1 million and $52.3 million, respectively. This
 subsidiary is also required to comply with the maximum ratios of
 debt to equity and minimum levels of debt service coverage ratios
 and Fabrinet must maintain effective shareholding ratio. The
 carrying amounts of bank borrowings approximate their fair
 value.
  (was, 2014-11-05, similarity 0.9941):
[0001193125-14-398478:note_history:14]
On
 April 25, 2014, a subsidiary entered into an amendment to the
 bank borrowing agreement. Under the amendment of the contract, the
 long-term loan is secured by certain property, plant and equipment.
 The carrying amount of assets secured and pledged as collateral as
 of September 26, 2014 and June 27, 2014 was $51.7 million
 and $52.3 million, respectively. This subsidiary is also required
 to comply with the maximum ratios of debt to equity and minimum
 levels of debt service coverage ratios and Fabrinet must maintain
 effective shareholding ratio. The carrying amounts of bank
 borrowings approximate their fair value.

- changed (2015-02-03):
[0001193125-15-031475:note_history:15]
As of December 26, 2014 and June 27, 2014, the Company
 was in compliance with its long-term bank borrowing agreement. In
 addition to financial ratios, certain of the Company’s credit
 facilities include customary events of default.
  (was, 2014-11-05, similarity 0.8753):
[0001193125-14-398478:note_history:15]
As of
 September 26, 2014 and June 27, 2014, the Company was in
 compliance with its long-term bank borrowing agreement. In addition
 to financial ratios, certain of the Company’s packing credits
 and long-term loans include customary events of default.

- changed (2015-02-03):
[0001193125-15-031475:note_history:16]
The movements of long-term loans were as follows for the six months
 ended December 26, 2014 and December 27, 2013:
  (was, 2014-11-05, similarity 0.9151):
[0001193125-14-398478:note_history:16]
The movements
 of long-term loans were as follows for the three months ended
 September 26, 2014 and September 27, 2013:

- changed (2015-02-03):
[0001193125-15-031475:note_history:17]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 26, 2014 |  |  | December 27, 2013 |  |
| Opening net book amount |  | $ | 16,500 |  |  | $ | 28,911 |  |
| Repayment during the period |  |  | (3,000 | ) |  |  | (4,834 | ) |
| Closing net book amount |  | $ | 13,500 |  |  | $ | 24,077 |  |
  (was, 2014-11-05, similarity 0.8937):
[0001193125-14-398478:note_history:17]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 26, 2014 |  |  | September 27, 2013 |  |
| Opening net book amount |  | $ | 16,500 |  |  | $ | 28,911 |  |
| Repayment during the period |  |  | (1,500 | ) |  |  | (2,417 | ) |
| Closing net book amount |  | $ | 15,000 |  |  | $ | 26,494 |  |

- changed (2015-02-03):
[0001193125-15-031475:note_history:18]
As of December 26, 2014, future maturities of long-term debt
 were as follows at the end of each fiscal year below:
  (was, 2014-11-05, similarity 0.977):
[0001193125-14-398478:note_history:18]
As of
 September 26, 2014, future maturities of long-term debt were
 as follows at the end of each fiscal year below:

- changed (2015-02-03):
[0001193125-15-031475:note_history:19]
Fabrinet entered into a syndicated senior credit facility agreement
 (the “Facility Agreement”) with a consortium of banks
 on May 22, 2014. The Facility Agreement, led by Bank of
 America, provides for a $200.0 million credit line, comprised
 of a $150.0 million revolving loan facility and a
 $50.0 million delayed draw term loan facility. The revolving
 loan facility contains an accordion feature permitting Fabrinet to
 request an increase in the facility up to $100.0 million subject to
 customary terms and conditions and provided that no default or
 event of default exists at the time of request. The revolving loan
 facility terminates and all amounts outstanding are due and payable
 in full on May 22, 2019. The principal amount of any drawn
 term loans must be repaid according to the scheduled quarterly
 amortization payments, with final payment of all amounts
 outstanding, plus accrued interest, being due May 22, 2019. As
 of December 26, 2014, no amounts were outstanding under the
 Facility Agreement.
  (was, 2014-11-05, similarity 0.9964):
[0001193125-14-398478:note_history:19]
Fabrinet
 entered into a syndicated senior credit facility agreement (the
 “Facility Agreement”) with a consortium of banks on
 May 22, 2014. The Facility Agreement, led by Bank of America,
 provides for a $200.0 million credit line, comprised of a $150.0
 million revolving loan facility and a $50.0 million delayed draw
 term loan facility. The revolving loan facility contains an
 accordion feature permitting Fabrinet to request an increase in the
 facility up to $100.0 million subject to customary terms and
 conditions and provided that no default or event of default exists
 at the time of request. The revolving loan facility terminates and
 all amounts outstanding are due and payable in full on May 22,
 2019. The principal amount of any drawn term loans must be repaid
 according to the scheduled quarterly amortization payments, with
 final payment of all amounts outstanding, plus accrued interest,
 being due May 22, 2019. As of September 26, 2014, no
 amounts were outstanding under the Facility Agreement.

- changed (2015-02-03):
[0001193125-15-031475:note_history:20]
Loans under the Facility Agreement bear interest, at
 Fabrinet’s option, at a rate per annum equal to a LIBOR rate
 plus a spread of 1.75% to 2.50%, or a base rate, determined in
 accordance with the Facility Agreement, plus a spread of 0.75% to
 1.50%, in each case with such spread determined based on
 Fabrinet’s consolidated total leverage ratio for the
 preceding four fiscal quarter period. Interest is due and payable
 quarterly in arrears for loans bearing interest at the base rate
 and at the end of an interest period (or at each three-month
 interval in the case of loans with interest periods greater than
 three months) in the case of loans bearing interest at the LIBOR
 rate.
  (was, 2014-11-05, similarity 0.863):
[0001193125-14-398478:note_history:20]
Loans under the
 Facility Agreement bear interest, at Fabrinet’s option, at a
 rate per annum equal to a LIBOR rate plus a spread of 1.75% to
 2.50%, or a base rate, determined in accordance with the Facility
 Agreement, plus a spread of 0.75% to 1.50%, in each case with such
 spread determined based on Fabrinet’s consolidated total
 leverage ratio for the preceding four fiscal quarter period.
 Interest is due and payable quarterly in arrears for loans bearing
 interest at the base rate and at the end of an interest period (or
 at each three-month interval in the case of loans with interest
 periods greater than three months) in the case of loans bearing
 interest at the LIBOR rate. The applicable spreads and commitment
 fees will increase in the event that Fabrinet’s Thailand
 subsidiary is unable to guarantee the obligations under the
 Facility Agreement within 180 days after the closing
 date.

- changed (2015-02-03):
[0001193125-15-031475:note_history:21]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or
 the equivalent under the local law, can be effected. The Facility
 Agreement contains customary affirmative and negative covenants.
 Negative covenants include, among other things, limitations on
 liens, indebtedness, investments, mergers, sales of assets, changes
 in the nature of the business, dividends and distributions,
 affiliate transactions and capital expenditures. The Facility
 Agreement contains financial covenants requiring Fabrinet to
 maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage
 ratio of not more than 2.50:1.00; and (iv) a minimum quick
 ratio of not less than 1.10:1.00. Each of these financial covenants
 is calculated on a consolidated basis for the consecutive four
 fiscal quarter period then ended. As of December 26, 2014, the
 Company was in compliance with all covenants under the Facility
 Agreement.
  (was, 2014-11-05, similarity 0.9922):
[0001193125-14-398478:note_history:21]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet shall maintain at
 least $40.0 million of cash, cash equivalents, and marketable
 securities at financial institutions located in the United States.
 Further, Fabrinet is required to maintain any of its deposits
 accounts or securities accounts with balances in excess of $10.0
 million in a jurisdiction where a control agreement, or the
 equivalent under the local law, can be effected. The Facility
 Agreement contains customary affirmative and negative covenants.
 Negative covenants include, among other things, limitations on
 liens, indebtedness, investments, mergers, sales of assets, changes
 in the nature of the business, dividends and distributions,
 affiliate transactions and capital expenditures. The Facility
 Agreement contains financial covenants requiring Fabrinet to
 maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage
 ratio of not more than 2.50:1.00; and (iv) a minimum quick
 ratio of not less than 1.10:1.00. Each of these financial covenants
 is calculated on a consolidated basis for the consecutive four
 fiscal quarter period then ended. As of September 26, 2014,
 the Company was in compliance with all covenants under the Facility
 Agreement.

- changed (2015-02-03):
[0001193125-15-031475:note_history:22]
Undrawn available credit facilities as of December 26, 2014
 and June 27, 2014 were as follows:
  (was, 2014-11-05, similarity 0.9704):
[0001193125-14-398478:note_history:22]
Undrawn
 available credit facilities as of September 26, 2014 and
 June 27, 2014 were as follows:

- changed (2015-02-03):
[0001193125-15-031475:note_history:23]
| (amount in thousands) |  | December 26, 2014 |  |  | June 27, 2014 |  |
| Short-term |  | $ | 1,520 |  |  | $ | 1,539 |  |
| Long-term |  | $ | 200,000 |  |  | $ | — |  |
  (was, 2014-11-05, similarity 0.8462):
[0001193125-14-398478:note_history:23]
| (amount in thousands) |  | September 26, 2014 |  |  | June 27, 2014 |  |
| Bank borrowings: |  |  |  |  |
| Short-term loans |  | $ | 1,548 |  |  | $ | 1,539 |  |
| Long-term loans |  | $ | 200,000 |  |  |  | — |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-02-03):
[0001193125-15-031475:note_history:24]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Term |  | As of December 26, 2014 |  |  | As of June 27, 2014 |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | June 2012 – March 2017 |  | $ | 13,500 |  |  | $ | 16,500 |  |
| Less: Current portion |  |  |  |  |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  |  |  |  | $ | 7,500 |  |  | $ | 10,500 |  |
  (was, 2014-11-05, similarity 0.9682):
[0001193125-14-398478:note_history:24]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Term |  | As of September 26, 2014 |  |  | As of June 27, 2014 |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | June 2012 – March 2017 |  | $ | 15,000 |  |  | $ | 16,500 |  |
| Less: Current portion |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  | $ | 9,000 |  |  | $ | 10,500 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-02-03):
[0001193125-15-031475:note_history:25]
The movements of long-term loans were as follows for the six months
 ended December 26, 2014 and December 27, 2013:
  (was, 2014-11-05, similarity 0.9151):
[0001193125-14-398478:note_history:25]
The movements
 of long-term loans were as follows for the three months ended
 September 26, 2014 and September 27, 2013:

- changed (2015-02-03):
[0001193125-15-031475:note_history:26]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 26, 2014 |  |  | December 27, 2013 |  |
| Opening net book amount |  | $ | 16,500 |  |  | $ | 28,911 |  |
| Repayment during the period |  |  | (3,000 | ) |  |  | (4,834 | ) |
| Closing net book amount |  | $ | 13,500 |  |  | $ | 24,077 |  |
  (was, 2014-11-05, similarity 0.8937):
[0001193125-14-398478:note_history:26]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 26, 2014 |  |  | September 27, 2013 |  |
| Opening net book amount |  | $ | 16,500 |  |  | $ | 28,911 |  |
| Repayment during the period |  |  | (1,500 | ) |  |  | (2,417 | ) |
| Closing net book amount |  | $ | 15,000 |  |  | $ | 26,494 |  |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-02-03):
[0001193125-15-031475:note_history:27]
Undrawn available credit facilities as of December 26, 2014
 and June 27, 2014 were as follows:
  (was, 2014-11-05, similarity 0.9704):
[0001193125-14-398478:note_history:27]
Undrawn
 available credit facilities as of September 26, 2014 and
 June 27, 2014 were as follows:

- changed (2015-02-03):
[0001193125-15-031475:note_history:28]
| (amount in thousands) |  | December 26, 2014 |  |  | June 27, 2014 |  |
| Short-term |  | $ | 1,520 |  |  | $ | 1,539 |  |
| Long-term |  | $ | 200,000 |  |  | $ | — |  |
  (was, 2014-11-05, similarity 0.8462):
[0001193125-14-398478:note_history:28]
| (amount in thousands) |  | September 26, 2014 |  |  | June 27, 2014 |  |
| Bank borrowings: |  |  |  |  |
| Short-term loans |  | $ | 1,548 |  |  | $ | 1,539 |  |
| Long-term loans |  | $ | 200,000 |  |  |  | — |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-02-03):
[0001193125-15-031475:note_history:29]
As of December 26, 2014, future maturities of long-term debt
 were as follows at the end of each fiscal year below:
  (was, 2014-11-05, similarity 0.977):
[0001193125-14-398478:note_history:29]
As of
 September 26, 2014, future maturities of long-term debt were
 as follows at the end of each fiscal year below:


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2015-02-03):
[0001193125-15-031475:note_history:30]
Revenue recognition

- added (2015-02-03):
[0001193125-15-031475:note_history:31]
Certain customers may request the Company to store finished
 products on their behalf. In these situations revenue is only
 recognized when the goods are completed
 and ready for shipment, and title and risk of loss have passed to
 the customer. The Company receives a written request from the
 customer asking the Company to hold the inventory at the Company
 warehouse, and the ordered goods are segregated in the Company
 warehouse from other inventory and cannot be used to fulfill other
 customer orders.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2015-02-03):
[0001193125-15-031475:note_history:32]
| 19. | Subsequent events |
  (was, 2014-11-05, similarity 0.9796):
[0001193125-14-398478:note_history:32]
| 17. | Subsequent event |

- added (2015-02-03):
[0001193125-15-031475:note_history:33]
New subsidiaries

- added (2015-02-03):
[0001193125-15-031475:note_history:34]
On January 6, 2015 the Company incorporated Fabrilink SEZC, a
 100% wholly owned subsidiary, in the Cayman Islands. On
 January 16, 2015, the Company incorporated Fabrinet West, Inc.
 and Fabritek, Inc., 100% wholly owned subsidiaries, in California,
 United States.

- added (2015-02-03):
[0001193125-15-031475:note_history:35]
Lease commitment

- added (2015-02-03):
[0001193125-15-031475:note_history:36]
On January 26, 2015, the Company entered into a commercial
 lease agreement for a period of five years for office space of
 approximately 1,730 square feet at Cayman Enterprise City,
 HSBC House, 68 West Bay Road, Grand Cayman KY1-1003, Cayman
 Islands. Monthly service fee of the premises is $14,475 per
 month.

- added (2015-02-03):
[0001193125-15-031475:note_history:37]
Capital expenditure commitment

- added (2015-02-03):
[0001193125-15-031475:note_history:38]
On January 20, 2015, the Company entered into a building
 remodel project contract for a facility in Thailand of
 approximately $3.7 million.

- removed (2015-02-03):
[0001193125-14-398478:note_history:39]
As part of the
 Company’s ongoing efforts to achieve greater efficiencies in
 all areas of its business, on October 10, 2014, the Company
 implemented a reduction in workforce and incurred expenses of
 approximately $1.0 million, which represented severance and
 benefits costs incurred for the termination of approximately 100
 employees in accordance with contractual obligations and local
 regulations. The Company will record this expense in the next
 quarter.
