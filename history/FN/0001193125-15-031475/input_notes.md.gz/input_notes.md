# FN notes — 0001193125-15-031475


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001193125-15-031475:notes:1]
Basis of presentation

[0001193125-15-031475:notes:2]
The condensed consolidated financial statements of Fabrinet
 included herein have been prepared on a basis consistent with the
 June 27, 2014 audited consolidated financial statements and
 include all material adjustments, consisting of normal recurring
 adjustments, necessary to fairly present the information set forth
 therein. These condensed consolidated financial statements should
 be read in conjunction with the June 27, 2014 audited
 consolidated financial statements and notes thereto. The year-end
 condensed balance sheet data was derived from audited financial
 statements but does not include all disclosures required by
 accounting principles generally accepted in the United States
 (“U.S. GAAP”).

[0001193125-15-031475:notes:3]
The preparation of the Company’s condensed consolidated
 financial statements in conformity with U.S. GAAP requires
 management to make estimates and assumptions that affect the
 reported amounts of assets and liabilities and disclosure of
 contingent liabilities at the date of the financial statements, and
 the reported amount of total revenues and expense during the year.
 The Company bases estimates on historical experience and various
 assumptions about the future that are believed to be reasonable
 based on available information. The Company’s reported
 financial position or results of operations may be materially
 different under different conditions or when using different
 estimates and assumptions, particularly with respect to significant
 accounting policies, which are discussed below. Significant
 assumptions are used in accounting for share-based compensation,
 allowance for doubtful accounts, income taxes, and inventory
 obsolescence, among others. Due to the inherent uncertainty
 involved in making estimates, actual results reported in future
 periods may be different from these estimates. In the event that
 estimates or assumptions prove to differ from actual results,
 adjustments will be made in subsequent periods to reflect more
 current information.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-15-031475:notes:4]
The following table summarizes the cost and estimated fair value of
 fixed income securities classified as available-for-sale securities
 based on stated effective maturities as of December 26,
 2014:

[0001193125-15-031475:notes:5]
| (amount in thousands) |  | Carrying Cost |  |  | Fair value |  |
| Due within one year |  | $ | 48,784 |  |  | $ | 48,730 |  |
| Due between one to three years |  |  | 92,995 |  |  |  | 92,569 |  |
| Total |  | $ | 141,779 |  |  | $ | 141,299 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-15-031475:notes:6]
| 14. | Commitments and contingencies |

[0001193125-15-031475:notes:7]
Bank guarantees

[0001193125-15-031475:notes:8]
As of December 26, 2014 and June 27, 2014, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $0.8 million and $0.3 million, respectively.

[0001193125-15-031475:notes:9]
Operating lease commitments

[0001193125-15-031475:notes:10]
The Company leases a portion of its capital equipment and certain
 land and buildings for its facilities in China and New Jersey under
 operating lease arrangements that expire in various calendar years
 through 2020. Rental expense under these operating leases amounted
 to $0.5 million and $0.4 million for the six months ended
 December 26, 2014 and December 27, 2013,
 respectively.

[0001193125-15-031475:notes:11]
As of December 26, 2014, the future minimum lease payments due
 under non-cancelable leases are as follows at the end of each
 fiscal year below:

[0001193125-15-031475:notes:12]
| (amount in thousands) |  |  |  |
| 2015 |  | $ | 496 |  |
| 2016 |  |  | 947 |  |
| 2017 |  |  | 931 |  |
| 2018 |  |  | 931 |  |
| 2019 |  |  | 442 |  |
| Thereafter |  |  | 279 |  |
| Total minimum operating lease payments |  | $ | 4,026 |  |

[0001193125-15-031475:notes:13]
Purchase obligations

[0001193125-15-031475:notes:14]
Purchase obligations represent legally-binding commitments to
 purchase inventory and other commitments made in the normal course
 of business to meet operational requirements. Although open
 purchase orders are considered enforceable and legally binding,
 their terms generally give the Company the option to cancel,
 reschedule and/or adjust its requirements based on its business
 needs prior to the delivery of goods or performance of services.
 Obligations to purchase inventory and other commitments are
 generally expected to be fulfilled within one year.

[0001193125-15-031475:notes:15]
As of December 26, 2014, the Company had an outstanding
 commitment to third parties of $5.9 million.

[0001193125-15-031475:notes:16]
Indemnification of directors and officers

[0001193125-15-031475:notes:17]
Cayman Islands law does not limit the extent to which a
 company’s memorandum and articles of association may provide
 for indemnification of directors and officers, except to the extent
 any such provision may be held by the Cayman Islands courts to be
 contrary to public policy, such as to provide indemnification
 against civil fraud or the consequences of committing a crime.
 Fabrinet’s amended and restated memorandum and articles of
 association provide for indemnification of directors and officers
 for actions, costs, charges, losses, damages and expenses incurred
 in their capacities as such, except that such indemnification does
 not extend to any matter in respect of any fraud or dishonesty that
 may attach to any of them.

[0001193125-15-031475:notes:18]
In accordance with Fabrinet’s form of indemnification
 agreement for its directors and officers, Fabrinet has agreed to
 indemnify its directors and officers against certain liabilities
 and expenses incurred by such persons in connection with claims by
 reason of their being such a director or officer. Fabrinet
 maintains a director and officer liability insurance policy that
 may enable it to recover a portion of any future amounts paid under
 the indemnification agreements.


## us-gaap:DebtDisclosureTextBlock

[0001193125-15-031475:notes:19]
| 9. | Borrowings |

[0001193125-15-031475:notes:20]
Bank borrowing and long-term debt was comprised of the
 following:

[0001193125-15-031475:notes:21]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Term |  | As of December 26, 2014 |  |  | As of June 27, 2014 |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | June 2012 – March 2017 |  | $ | 13,500 |  |  | $ | 16,500 |  |
| Less: Current portion |  |  |  |  |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  |  |  |  | $ | 7,500 |  |  | $ | 10,500 |  |

[0001193125-15-031475:notes:22]
| (1) | LIBOR is London Interbank Offered Rate. |

[0001193125-15-031475:notes:23]
On April 25, 2014, a subsidiary entered into an amendment to
 the bank borrowing agreement. Under the amendment of the contract,
 the long-term loan is secured by certain property, plant and
 equipment. The carrying amount of assets secured and pledged as
 collateral as of December 26, 2014 and June 27, 2014 was
 $51.1 million and $52.3 million, respectively. This
 subsidiary is also required to comply with the maximum ratios of
 debt to equity and minimum levels of debt service coverage ratios
 and Fabrinet must maintain effective shareholding ratio. The
 carrying amounts of bank borrowings approximate their fair
 value.

[0001193125-15-031475:notes:24]
As of December 26, 2014 and June 27, 2014, the Company
 was in compliance with its long-term bank borrowing agreement. In
 addition to financial ratios, certain of the Company’s credit
 facilities include customary events of default.

[0001193125-15-031475:notes:25]
The movements of long-term loans were as follows for the six months
 ended December 26, 2014 and December 27, 2013:

[0001193125-15-031475:notes:26]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 26, 2014 |  |  | December 27, 2013 |  |
| Opening net book amount |  | $ | 16,500 |  |  | $ | 28,911 |  |
| Repayment during the period |  |  | (3,000 | ) |  |  | (4,834 | ) |
| Closing net book amount |  | $ | 13,500 |  |  | $ | 24,077 |  |

[0001193125-15-031475:notes:27]
As of December 26, 2014, future maturities of long-term debt
 were as follows at the end of each fiscal year below:

[0001193125-15-031475:notes:28]
| (amount in thousands) |  |  |  |
| 2015 |  | $ | 3,000 |  |
| 2016 |  |  | 6,000 |  |
| 2017 |  |  | 4,500 |  |
| Total |  | $ | 13,500 |  |

[0001193125-15-031475:notes:29]
Credit facilities:

[0001193125-15-031475:notes:30]
Fabrinet entered into a syndicated senior credit facility agreement
 (the “Facility Agreement”) with a consortium of banks
 on May 22, 2014. The Facility Agreement, led by Bank of
 America, provides for a $200.0 million credit line, comprised
 of a $150.0 million revolving loan facility and a
 $50.0 million delayed draw term loan facility. The revolving
 loan facility contains an accordion feature permitting Fabrinet to
 request an increase in the facility up to $100.0 million subject to
 customary terms and conditions and provided that no default or
 event of default exists at the time of request. The revolving loan
 facility terminates and all amounts outstanding are due and payable
 in full on May 22, 2019. The principal amount of any drawn
 term loans must be repaid according to the scheduled quarterly
 amortization payments, with final payment of all amounts
 outstanding, plus accrued interest, being due May 22, 2019. As
 of December 26, 2014, no amounts were outstanding under the
 Facility Agreement.

[0001193125-15-031475:notes:31]
Loans under the Facility Agreement bear interest, at
 Fabrinet’s option, at a rate per annum equal to a LIBOR rate
 plus a spread of 1.75% to 2.50%, or a base rate, determined in
 accordance with the Facility Agreement, plus a spread of 0.75% to
 1.50%, in each case with such spread determined based on
 Fabrinet’s consolidated total leverage ratio for the
 preceding four fiscal quarter period. Interest is due and payable
 quarterly in arrears for loans bearing interest at the base rate
 and at the end of an interest period (or at each three-month
 interval in the case of loans with interest periods greater than
 three months) in the case of loans bearing interest at the LIBOR
 rate.

[0001193125-15-031475:notes:32]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or
 the equivalent under the local law, can be effected. The Facility
 Agreement contains customary affirmative and negative covenants.
 Negative covenants include, among other things, limitations on
 liens, indebtedness, investments, mergers, sales of assets, changes
 in the nature of the business, dividends and distributions,
 affiliate transactions and capital expenditures. The Facility
 Agreement contains financial covenants requiring Fabrinet to
 maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage
 ratio of not more than 2.50:1.00; and (iv) a minimum quick
 ratio of not less than 1.10:1.00. Each of these financial covenants
 is calculated on a consolidated basis for the consecutive four
 fiscal quarter period then ended. As of December 26, 2014, the
 Company was in compliance with all covenants under the Facility
 Agreement.

[0001193125-15-031475:notes:33]
The Facility Agreement also contains customary events of default
 including, among other things, payment defaults, breaches of
 covenants or representations and warranties, cross-defaults with
 certain other indebtedness, bankruptcy and insolvency events and
 change in control of Fabrinet, subject to grace periods in certain
 instances. Upon an event of default, the lenders may terminate
 their commitments, declare all or a portion of the outstanding
 obligations payable by Fabrinet to be immediately due and payable
 and exercise other rights and remedies provided for under the
 Facility Agreement. The undrawn credit facility of
 $200.0 million became available on July 15, 2014.

[0001193125-15-031475:notes:34]
Fabrinet intends to use the proceeds of the credit line to finance
 its future manufacturing building in Thailand, and for general
 corporate purposes including mergers and acquisitions of
 complementary manufacturing businesses or technology, although
 Fabrinet has no current commitments with respect to any such
 acquisitions.

[0001193125-15-031475:notes:35]
Undrawn available credit facilities as of December 26, 2014
 and June 27, 2014 were as follows:

[0001193125-15-031475:notes:36]
| (amount in thousands) |  | December 26, 2014 |  |  | June 27, 2014 |  |
| Short-term |  | $ | 1,520 |  |  | $ | 1,539 |  |
| Long-term |  | $ | 200,000 |  |  | $ | — |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-15-031475:notes:37]
[same as prior period, unchanged from 0001193125-14-398478:notes:35]

[0001193125-15-031475:notes:38]
Basic earnings per ordinary share is computed by dividing reported
 net income by the weighted average number of ordinary shares
 outstanding during each period. Diluted earnings per ordinary share
 is computed by dividing reported net income by the weighted average
 number of ordinary shares and dilutive ordinary equivalent shares
 outstanding during each period. Dilutive ordinary equivalent shares
 consist of share options and restricted share units. The earnings
 per ordinary share was calculated as follows:

[0001193125-15-031475:notes:39]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands except per share amounts) |  | December 26, 2014 |  |  | December 27, 2013 |  |  | December 26, 2014 |  |  | December 27, 2013 |  |
| Net income attributable to shareholders |  | $ | 8,726 |  |  | $ | 14,539 |  |  | $ | 19,762 |  |  | $ | 33,736 |  |
| Weighted average number of ordinary shares outstanding (thousands of shares) |  |  | 35,349 |  |  |  | 34,882 |  |  |  | 35,289 |  |  |  | 34,778 |  |
| Incremental shares arising from the assumed exercise of share options and vesting of restricted share units (thousands of shares) |  |  | 568 |  |  |  | 701 |  |  |  | 463 |  |  |  | 583 |  |
| Weighted average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 35,917 |  |  |  | 35,583 |  |  |  | 35,752 |  |  |  | 35,361 |  |
| Basic earnings per ordinary share |  | $ | 0.25 |  |  | $ | 0.42 |  |  | $ | 0.56 |  |  | $ | 0.97 |  |
| Diluted earnings per ordinary share |  | $ | 0.24 |  |  | $ | 0.41 |  |  | $ | 0.55 |  |  | $ | 0.95 |  |
| Outstanding share options excluded in the computation of diluted earnings per ordinary share (1) |  |  |  |  |  |  |  |  |  |  | 71,580 |  |  |  | 45,703 |  |

[0001193125-15-031475:notes:40]
| (1) | These share options were not included in the computation of diluted earnings per ordinary share for three and six months ended December 26, 2014 and December 27, 2013, respectively, because the exercise price of the options was greater than the average market price of the underlying shares. |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-15-031475:notes:41]
The following table presents total revenues by geographic
 regions:

[0001193125-15-031475:notes:42]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands) |  | December 26, 2014 |  |  | December 27, 2013 |  |  | December 26, 2014 |  |  | December 27, 2013 |  |
| North America |  | $ | 93,658 |  |  | $ | 84,354 |  |  | $ | 184,701 |  |  | $ | 163,151 |  |
| Asia-Pacific |  |  | 70,914 |  |  |  | 59,697 |  |  |  | 148,716 |  |  |  | 117,693 |  |
| Europe |  |  | 23,781 |  |  |  | 34,511 |  |  |  | 44,261 |  |  |  | 69,269 |  |
|  |  | $ | 188,353 |  |  | $ | 178,562 |  |  | $ | 377,678 |  |  | $ | 350,113 |  |


## us-gaap:ScheduleOfShareBasedCompensationRestrictedStockUnitsAwardActivityTableTextBlock

[0001193125-15-031475:notes:43]
The following summarizes restricted share unit activity under the
 2010 Plan:

[0001193125-15-031475:notes:44]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 27, 2014 |  |  | 762,295 |  |  |  | $14.23 |  |  |  |  |  |
| Granted |  |  | 557,798 |  |  |  | $17.62 |  |  |  | $17.62 |  |
| Issued |  |  | (209,119 | )(1) |  |  | $17.72 |  |  |  |  |  |
| Forfeited |  |  | (13,370 | ) |  |  | $15.68 |  |  |  |  |  |
| Balance as of December 26, 2014 |  |  | 1,097,604 |  |  |  | $16.03 |  |  |  |  |  |

[0001193125-15-031475:notes:45]
| (1) | Included 283 shares vested on December 23, 2014, but not settled as of December 26, 2014. |

[0001193125-15-031475:notes:46]
|  |  | Number of Shares |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 28, 2013 |  |  | 545,668 |  |  | $ | 12.81 |  |  |  |  |  |
| Granted |  |  | 434,018 |  |  | $ | 15.01 |  |  | $ | 15.01 |  |
| Issued |  |  | (133,311 | )(2) |  | $ | 12.73 |  |  |  |  |  |
| Forfeited |  |  | (6,945 | ) |  | $ | 14.10 |  |  |  |  |  |
| Balance as of December 27, 2013 |  |  | 839,430 |  |  | $ | 13.95 |  |  |  |  |  |

[0001193125-15-031475:notes:47]
| (2) | Included 566 shares vested on December 1, 2013, but not settled as of December 27, 2013. |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-15-031475:notes:48]
[same as prior period, unchanged from 0001193125-14-398478:notes:45]

[0001193125-15-031475:notes:49]
Fiscal years

[0001193125-15-031475:notes:50]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended
 December 26, 2014 and December 27, 2013 each consisted of
 13 weeks. The six months ended December 26, 2014 and
 December 27, 2013 each consisted of 26 weeks. Fiscal year 2015
 will be comprised of 52 weeks and will end on June 26,
 2015.

[0001193125-15-031475:notes:51]
[same as prior period, unchanged from 0001193125-14-398478:notes:48]

[0001193125-15-031475:notes:52]
Financial instruments that potentially subject the Company to
 concentrations of credit risk consist of cash and cash equivalents,
 marketable securities, derivatives and accounts receivable.

[0001193125-15-031475:notes:53]
Cash, cash equivalents and marketable securities are maintained
 with several financial institutions. Deposits held with banks may
 exceed the amount of insurance provided on such deposits.
 Generally, these deposits may be redeemed upon demand and are
 maintained with financial institutions with reputable credit and
 therefore bear minimal credit risk. The Company seeks to mitigate
 its credit risks by spreading such risks across multiple
 counterparties and monitoring the risk profiles of these
 counterparties. The Company limits its investments in marketable
 securities to securities with a maturity not in excess of three
 years, and all marketable securities that the Company invests in
 are rated A1, P-1, F1, or better.

[0001193125-15-031475:notes:54]
The Company performs ongoing credit evaluations for credit
 worthiness of its customers and usually does not require collateral
 from its customers. Management has implemented a program to closely
 monitor near term cash collection and credit exposures to mitigate
 any material losses.

[0001193125-15-031475:notes:55]
Revenue recognition

[0001193125-15-031475:notes:56]
Certain customers may request the Company to store finished
 products on their behalf. In these situations revenue is only
 recognized when the goods are completed
 and ready for shipment, and title and risk of loss have passed to
 the customer. The Company receives a written request from the
 customer asking the Company to hold the inventory at the Company
 warehouse, and the ordered goods are segregated in the Company
 warehouse from other inventory and cannot be used to fulfill other
 customer orders.

[0001193125-15-031475:notes:57]
New Accounting Pronouncements – not yet adopted by the
 Company

[0001193125-15-031475:notes:58]
In January 2015, the Financial Accounting Standards Board (FASB)
 issued Accounting Standard Update (ASU) No. 2015-01,
 “Income Statement – Extraordinary and Unusual Items
 (Subtopic 225-20): Simplifying Income Statement presentation by
 Eliminating the Concept of Extraordinary Items”. The
 objective of this amendments are to reduce the complexity of
 extraordinary items concept by the concept of extraordinary items,
 subtopic 225-20. Presently, an event or transaction is presumed to
 be an ordinary and usual activity of the reporting entity unless
 evidence clearly supports its classification as an extraordinary
 item. The criteria that must both be met for extraordinary
 classification: (a) unusual nature with high degree of
 abnormality and be of a type clearly unrelated to, or only
 incidentally related to the ordinary and typical activities of the
 entity; and (b) infrequency of occurrence of the event which
 should not reasonably be expected to recur in the foreseeable
 future. This amendments are effective for fiscal years and interim
 periods beginning after December 15, 2015. Early adoption is
 permitted provided that the guidance is applied from the beginning
 of the fiscal year of adoption. The Company does not expect that
 the adoption of this update will have an effect on its consolidated
 financial statements.

[0001193125-15-031475:notes:59]
In August 2014, the FASB issued ASU No. 2014-15,
 “Presentation of Financial Statements – Going Concern
 (Subtopic 205-40): Disclosure of Uncertainties about an
 Entity’s Ability to Continue as a Going Concern”. The
 amendments require management to evaluate, for each annual and
 interim reporting period, an entity’s ability to continue as
 a going concern when relevant conditions and events, considered in
 the aggregate, indicate that it is probable that the entity will be
 unable to meet its obligations that become due within one year
 after the date that the financial statements are issued (or
 available to be issued). This ASU is effective for annual periods
 and interim reporting periods beginning after December 15,
 2016. The Company does not expect that the adoption of this update
 will have an effect on its consolidated financial statements.

[0001193125-15-031475:notes:60]
In June 2014, the FASB issued ASU No. 2014-12,
 “Compensation – Stock Compensation (Topic 718):
 Accounting for Share-Based Payments When the Terms of an Award
 Provide That a Performance Target Could Be Achieved After the
 Requisite Service Period”. This ASU requires that a
 performance target that affects vesting, and that could be achieved
 after the requisite service period, be treated as a performance
 condition. As such, the performance target should not be reflected
 in estimating the grant date fair value of the award. This update
 further clarifies that compensation cost should be recognized in
 the period in which it becomes probable that the performance target
 will be achieved and should represent the compensation cost
 attributable to the period(s) for which the requisite service has
 already been rendered. This update is required to be adopted by all
 public companies for annual periods and interim reporting periods
 beginning after December 15, 2015. Early adoption of this ASU
 is permitted. The Company is currently evaluating the impact of
 adoption of this update on its consolidated financial
 statements.

[0001193125-15-031475:notes:61]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue
 from Contracts with Customers (Topic 606), issued as a new Topic,
 Accounting Standards Codification”. The core principle of
 this amendment is that an entity should recognize revenue to depict
 the transfer of promised goods or services to customers in an
 amount that reflects the consideration to which the entity expects
 to be entitled in exchange for those goods or services. This ASU is
 effective for annual reporting periods beginning after
 December 15, 2016, including interim periods within that
 reporting period, with earlier adoption not being permitted. This
 ASU can be adopted either retrospectively to each prior reporting
 period presented or as a cumulative-effect adjustment as of the
 date of adoption. The Company is currently evaluating the impact of
 adoption of this update on its consolidated financial
 statements.

[0001193125-15-031475:notes:62]
Recently Adopted Accounting Pronouncements

[0001193125-15-031475:notes:63]
In July 2013, the FASB issued ASU No. 2013-11, “Income
 Taxes (Topic 740): Presentation of an Unrecognized Tax Benefit When
 a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax
 Credit Carryforward Exists”. This ASU provides guidance for
 netting of unrecognized tax benefits (UTBs) against a deferred tax
 asset for a loss or other carryforward that would apply in
 settlement of the uncertain tax positions. Under this new guidance,
 UTBs will be netted against all available same-jurisdiction loss or
 other tax carryforwards that would be utilized, rather than only
 against carryforwards that are created by the UTBs. This guidance
 is effective for fiscal years, and interim periods within those
 years, beginning after December 15, 2013. The Company adopted
 this ASU in the first quarter of fiscal year 2015. Adoption of this
 guidance did not have a material impact on the Company’s
 unaudited condensed consolidated financial statements.

[0001193125-15-031475:notes:64]
In April 2013, the FASB issued ASU No. 2013-07,
 “Presentation of Financial Statements (Topic 205):
 Liquidation Basis of Accounting”. The amendments require an
 entity to prepare its financial statements using the liquidation
 basis of accounting when liquidation is imminent. The amendments
 require financial statements prepared using the liquidation basis
 of accounting to present relevant information about an
 entity’s expected resources in liquidation by measuring and
 presenting assets at the amount of the expected cash proceeds from
 liquidation. This guidance is effective for entities that determine
 liquidation is imminent during annual reporting periods beginning
 after December 15, 2013 and interim reporting periods therein.
 The Company adopted this ASU in the first quarter of fiscal year
 2015. Adoption of this guidance did not have a material impact on
 the Company’s unaudited condensed consolidated financial
 statements.

[0001193125-15-031475:notes:65]
In March 2013, the FASB issued ASU No. 2013-05, “Foreign
 Currency Matters (Topic 830): Parents’ Accounting for the
 Cumulative Translation Adjustment upon Derecognition of Certain
 Subsidiaries or Groups of Assets within a Foreign Entity or of an
 Investment in a Foreign Entity”. This ASU permits an entity
 to release cumulative translation adjustments into net income when
 a reporting entity (parent) ceases to have a controlling financial
 interest in a subsidiary or group of assets that is a business
 within a foreign entity. Accordingly, the cumulative translation
 adjustment should be released into net income only if the sale or
 transfer results in the complete or substantially complete
 liquidation of the foreign entity in which the subsidiary or group
 of assets had resided, or, if a controlling financial interest is
 no longer held. The guidance is effective for fiscal years
 beginning after December 15, 2013, with early adoption being
 permitted. The Company adopted this ASU in the first quarter of
 fiscal year 2015. Adoption of this guidance did not have a material
 impact on the Company’s unaudited condensed consolidated
 financial statements.

[0001193125-15-031475:notes:66]
In February 2013, the FASB issued ASU No. 2013-04,
 “Liabilities (Topic 405): Obligations Resulting from
 Joint and Several Liability Arrangements for which the Total Amount
 of the Obligation is Fixed at the Reporting Date”. The
 guidance in this update requires an entity to measure obligations
 resulting from joint and several liability arrangements for which
 the total amount of the obligation within the scope of this
 guidance is fixed at the reporting date, as the sum of the
 following: (a) the amount the reporting entity agreed to pay
 on the basis of its arrangement among its co-obligors, and
 (b) any additional amount the reporting entity expects to pay
 on behalf of its co-obligors. The guidance also requires an entity
 to disclose the nature and amount of the obligation as well as
 other information about those obligations. This guidance is
 effective for fiscal years, and interim periods within those years,
 beginning after December 15, 2013. The Company adopted this
 ASU in the first quarter of fiscal year 2015. Adoption of this
 guidance did not have a material impact on the Company’s
 unaudited condensed consolidated financial statements.


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001193125-15-031475:notes:67]
| 4. | Cash, cash equivalents and marketable securities |

[0001193125-15-031475:notes:68]
The Company’s cash, cash equivalents,
 and available-for-sale securities can be analyzed as
 follows:

[0001193125-15-031475:notes:69]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Loss |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of December 26, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | — |  |  | $ | — |  |  | $ | 98,626 |  |  | $ | — |  |
| Cash equivalents |  |  | 13,351 |  |  |  | (6 | ) |  |  | 13,345 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 120,604 |  |  |  | (418 | ) |  |  | — |  |  |  | 120,186 |  |
| U.S. agency and U.S. treasury securities |  |  | 17,230 |  |  |  | (60 | ) |  |  | — |  |  |  | 17,170 |  |
| Sovereign and municipal securities |  |  | 3,945 |  |  |  | (2 | ) |  |  | — |  |  |  | 3,943 |  |
| Total |  | $ | 155,130 |  |  | $ | (486 | ) |  | $ | 111,971 |  |  | $ | 141,299 |  |
|  |  |  |  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Loss |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of June 27, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | — |  |  | $ | — |  |  | $ | 214,283 |  |  | $ | — |  |
| Cash equivalents |  |  | — |  |  |  | — |  |  |  | 19,194 |  |  |  | — |  |
| Total |  | $ | — |  |  | $ | — |  |  | $ | 233,477 |  |  | $ | — |  |

[0001193125-15-031475:notes:70]
All highly liquid investments with original maturities of three
 months or less at the date of purchase are classified as cash
 equivalents. The Company’s marketable securities investments
 have been classified and accounted for as
 available-for-sale. Management determines the appropriate
 classification of its investments at the time of purchase and
 reevaluates the designations at each balance sheet date. The
 Company may sell certain of its marketable securities prior to
 their stated maturities for strategic reasons including, but not
 limited to, anticipation of credit deterioration and duration
 management. The maturities of the Company’s marketable
 securities generally range from three months to three years.

[0001193125-15-031475:notes:71]
The Company’s investments in available-for-sale securities
 are reported at fair value. Unrealized gains and losses related to
 changes in the fair value of securities are recognized in
 accumulated other comprehensive income, net of tax, in the
 Company’s condensed consolidated balance sheets. Changes in
 the fair value of available-for-sale securities impact the
 Company’s net income only when such securities are sold or
 other-than-temporary impairment is recognized. Realized gains and
 losses on the sale of securities are determined by specific
 identification of each security’s cost basis. During the
 three and six months ended December 26, 2014, the net realized
 loss recognized by the Company was $0.01 million and
 $0.01 million, respectively.

[0001193125-15-031475:notes:72]
The Company reviews its available-for-sale securities on a regular
 basis to evaluate whether or not any security has experienced an
 other-than-temporary decline in fair value. The Company considers
 factors such as the length of time and extent to which the market
 value has been less than the cost, the financial condition and
 near-term prospects of the issue and the Company’s intent to
 sell, or whether it is more likely than not the Company will be
 required to sell the investment before recovery of the
 investment’s amortized cost basis. If the Company believes
 that an other-than-temporary decline exists in one of these
 securities, the Company will write down these investments to fair
 value.

[0001193125-15-031475:notes:73]
As of December 26, 2014, the Company considered the declines
 in market value of its available-for-sale securities investment
 portfolio to be temporary in nature and did not consider any of its
 securities other-than-temporarily impaired. The Company typically
 invests in highly-rated securities, and its investment policy
 generally limits the amount of credit exposure to any one issuer.
 The policy requires investments generally to be investment grade,
 with the primary objective of minimizing the potential risk of
 principal loss. Fair values were determined for each individual
 security in the investment portfolio. When evaluating an investment
 for other-than-temporary impairment, the Company reviews factors
 such as the length of time and extent to which fair value has been
 below its cost basis, the financial condition of the issuer and any
 changes thereto, changes in market interest rates, and the
 Company’s intent to sell, or whether it is more likely than
 not it will be required to sell, the investment before recovery of
 the investment’s cost basis. No impairment losses were
 recorded for the three and six months ended December 26,
 2014.

[0001193125-15-031475:notes:74]
As of December 26, 2014, cash, cash equivalents, and
 marketable securities include bank deposits of $40.0 million held
 in various financial institutions located in the United States in
 order to support the availability of the Facility Agreement and
 comply with covenants. Under the terms and conditions of the
 Facility Agreement, the Company shall maintain cash, cash
 equivalents and/or marketable securities in an aggregate amount not
 less than $40.0 million in unencumbered deposits and/or securities
 in accounts located in the United States at all times during the
 term of the Facility Agreement. As discussed in Note 9, the
 Company must comply with this covenant from and after the effective
 date of the Facility Agreement.


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-15-031475:notes:75]
| (amount in thousands) |  | As of December 26, 2014 |  |  | As of June 27, 2014 |  |
| Raw materials |  | $ | 49,514 |  |  | $ | 40,885 |  |
| Work in progress |  |  | 58,312 |  |  |  | 56,376 |  |
| Finished goods |  |  | 17,990 |  |  |  | 22,970 |  |
| Goods in transit |  |  | 4,865 |  |  |  | 6,899 |  |
|  |  |  | 130,681 |  |  |  | 127,130 |  |
| Less: Inventory obsolescence |  |  | (2,877 | ) |  |  | (2,560 | ) |
| Inventory, net |  | $ | 127,804 |  |  | $ | 124,570 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-15-031475:notes:76]
The following summarizes share option activity:

[0001193125-15-031475:notes:77]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 27, 2014 |  |  | 865,890 |  |  |  |  |  |  | $ | 16.27 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (26,677 | ) |  |  |  |  |  | $ | 15.58 |  |  |  |  |  |
| Forfeited |  |  | (3,521 | ) |  |  |  |  |  | $ | 16.93 |  |  |  |  |  |
| Expired |  |  | (3,804 | ) |  |  |  |  |  | $ | 19.47 |  |  |  |  |  |
| Balance as of December 26, 2014 |  |  | 831,888 |  |  |  | 743,800 |  |  | $ | 16.27 |  |  |  |  |  |
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 28, 2013 |  |  | 1,277,311 |  |  |  |  |  |  | $ | 15.37 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (276,711 | ) |  |  |  |  |  | $ | 12.78 |  |  |  |  |  |
| Forfeited |  |  | (6,520 | ) |  |  |  |  |  | $ | 16.35 |  |  |  |  |  |
| Expired |  |  | (25,312 | ) |  |  |  |  |  | $ | 16.71 |  |  |  |  |  |
| Balance as of December 27, 2013 |  |  | 968,768 |  |  |  | 609,385 |  |  | $ | 16.07 |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-15-031475:notes:78]
| 15. | Business segments and geographic information |

[0001193125-15-031475:notes:79]
Operating segments are defined as components of an enterprise for
 which separate financial information is available that is evaluated
 regularly by the chief operating decision maker in deciding how to
 allocate resources and in assessing performance. The
 Company’s chief operating decision maker is Fabrinet’s
 chief executive officer. As of December 26, 2014 and
 December 27, 2013, the Company operated and internally managed
 a single operating segment. Accordingly, the Company does not
 accumulate discrete information with respect to separate product
 lines and does not have separate reportable segments.

[0001193125-15-031475:notes:80]
Total revenues are attributed to a particular geographic area based
 on the bill-to-location of the customers. The Company operates
 primarily in three geographic regions: North America, Asia-Pacific
 and Europe. The following table presents total revenues by
 geographic regions:

[0001193125-15-031475:notes:81]
As of December 26, 2014 and December 27, 2013, the
 Company had approximately $0.3 million and $0.3 million
 of long-lived assets based in North America, with the substantial
 remainder of assets based in Asia-Pacific.

[0001193125-15-031475:notes:82]
[same as prior period, unchanged from 0001193125-14-398478:notes:73]

[0001193125-15-031475:notes:83]
The Company had two customers that each contributed to 10% or more
 of its total account receivable as of December 26, 2014 and
 June 27, 2014, respectively.


## us-gaap:AccountingChangesAndErrorCorrectionsTextBlock

[0001193125-15-031475:notes:84]
| 18. | Revenue recognition error related to finished goods awaiting shipment to customers under certain volume supply agreements with customers |

[0001193125-15-031475:notes:85]
As disclosed, the Consolidated Financial Statements included in the
 Company’s Annual Report on Form 10-K for the fiscal year
 ended June 27, 2014, the Company determined that certain
 finished goods sales recognized in each of the first three
 quarterly reporting periods in the fiscal year ended June 27,
 2014 did not qualify for revenue recognition in the period in which
 they were recorded. The Company evaluated the impact of the errors
 and determined that the errors did not have a material impact to
 the consolidated financial statements for the fiscal year ended
 June 27, 2014, or the interim consolidated financial
 statements for each of the quarters within fiscal 2014.
 Accordingly, the Company has not made any adjustments to the
 unaudited condensed consolidated financial statements for the three
 and six months ended December 27, 2013.

[0001193125-15-031475:notes:86]
Had adjustments been made in the three and six months ended
 December 27, 2013, to reflect revenues and cost of revenues
 that were inappropriately recorded, revenues, cost of revenues, and
 net income for the three months ended December 27, 2013, would
 have been $6.4 million, $5.7 million, and
 $0.6 million lower, respectively, and for the six months ended
 December 27, 2013, would have been $3.6 million,
 $3.3 million, and $0.4 million lower, respectively.


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0001193125-15-031475:notes:87]
The effect of recording share-based compensation expense for the
 three and six months ended December 26, 2014 and
 December 27, 2013 was as follows:

[0001193125-15-031475:notes:88]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands) |  | December 26, 2014 |  |  | December 27, 2013 |  |  | December 26, 2014 |  |  | December 27, 2013 |  |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share options |  | $ | 71 |  |  | $ | 240 |  |  | $ | 191 |  |  | $ | 538 |  |
| Restricted share units |  |  | 1,859 |  |  |  | 1,257 |  |  |  | 3,606 |  |  |  | 2,522 |  |
| Total share-based compensation expense |  |  | 1,930 |  |  |  | 1,497 |  |  |  | 3,797 |  |  |  | 3,060 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 1,930 |  |  | $ | 1,497 |  |  | $ | 3,797 |  |  | $ | 3,060 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-15-031475:notes:89]
[same as prior period, unchanged from 0001193125-14-398478:notes:80]


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-15-031475:notes:90]
Share-based compensation expense was recorded in the condensed
 consolidated statements of operations and comprehensive income as
 follows:

[0001193125-15-031475:notes:91]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands) |  | December 26, 2014 |  |  | December 27, 2013 |  |  | December 26, 2014 |  |  | December 27, 2013 |  |
| Cost of revenue |  | $ | 360 |  |  | $ | 291 |  |  | $ | 728 |  |  | $ | 598 |  |
| Selling, general and administrative expense |  |  | 1,570 |  |  |  | 1,206 |  |  |  | 3,069 |  |  |  | 2,462 |  |
| Total share-based compensation expense |  | $ | 1,930 |  |  | $ | 1,497 |  |  | $ | 3,797 |  |  | $ | 3,060 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-15-031475:notes:92]
Based on the carrying amount of intangibles as of December 26,
 2014, and assuming no future impairment of the underlying assets,
 the estimated future amortization at the end of each fiscal year in
 June is as follows:

[0001193125-15-031475:notes:93]
| (amount in thousands) |  |  |  |
| 2015 |  | $ | 26 |  |
| 2016 |  |  | 10 |  |
| 2017 |  |  | 6 |  |
| 2018 |  |  | 5 |  |
| 2019 |  |  | 4 |  |
| Thereafter |  |  | 1 |  |
| Total |  | $ | 52 |  |


## us-gaap:ScheduleOfCreditLossesForFinancingReceivablesCurrentTableTextBlock

[0001193125-15-031475:notes:94]
The activities and balances for allowance for doubtful accounts
 were as follows:

[0001193125-15-031475:notes:95]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 26, 2014 |  |  | December 27, 2013 |  |
| Balance, beginning of period |  | $ | 37 |  |  | $ | 109 |  |
| Credited to Income |  |  | (3 | ) |  |  | (53 | ) |
| Balance, end of period |  | $ | 34 |  |  | $ | 56 |  |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001193125-15-031475:notes:96]
The following tables present details of the Company’s
 intangibles:

[0001193125-15-031475:notes:97]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net |  |
| As of December 26, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 3,480 |  |  | $ | (3,428 | ) |  | $ | 52 |  |
| Total intangibles |  | $ | 3,480 |  |  | $ | (3,428 | ) |  | $ | 52 |  |

[0001193125-15-031475:notes:98]
[same as prior period, unchanged from 0001193125-14-398478:notes:89]


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-15-031475:notes:99]
For the six months ended December 26, 2014, the changes in
 accumulated other comprehensive loss, net of tax were as
 follows:

[0001193125-15-031475:notes:100]
| (amount in thousands) |  | Unrealized losses on available- for-sale securities |  |
| Balance as of June 27, 2014 |  | $ | — |  |
| Other comprehensive loss before reclassification adjustment |  |  | (493 | ) |
| Less: Reclassification adjustment for net loss realized and included in net income |  |  | 7 |  |
| Net current-period other comprehensive loss |  | $ | (486 | ) |
| Balance as of December 26, 2014 |  | $ | (486 | ) |


## us-gaap:ShareBasedCompensationArrangementByShareBasedPaymentAwardOptionsVestedAndExpectedToVestOutstandingAndExercisableTableTextBlock

[0001193125-15-031475:notes:101]
The following summarizes information for share options outstanding
 as of December 26, 2014 under the Share Option Plans:

[0001193125-15-031475:notes:102]
|  |  | Number of Shares Underlying Options |  |  | Exercise Price Per Share |  |  | Weighted Average Remaining Contractual Life (years) |  |  | Aggregate Intrinsic Value (amount in thousands) |  |
|  |  |  | 2,100 |  |  | $ | 5.00 |  |  |  | 0.13 |  |  |  |  |  |
|  |  |  | 1,400 |  |  | $ | 5.25 |  |  |  | 0.36 |  |  |  |  |  |
|  |  |  | 8,365 |  |  | $ | 5.75 |  |  |  | 1.69 |  |  |  |  |  |
|  |  |  | 8,368 |  |  | $ | 13.77 |  |  |  | 2.66 |  |  |  |  |  |
|  |  |  | 424,619 |  |  | $ | 16.83 |  |  |  | 2.80 |  |  |  |  |  |
|  |  |  | 30,000 |  |  | $ | 15.05 |  |  |  | 2.86 |  |  |  |  |  |
|  |  |  | 26,781 |  |  | $ | 25.50 |  |  |  | 3.05 |  |  |  |  |  |
|  |  |  | 7,400 |  |  | $ | 26.16 |  |  |  | 3.11 |  |  |  |  |  |
|  |  |  | 9,089 |  |  | $ | 23.62 |  |  |  | 3.36 |  |  |  |  |  |
|  |  |  | 89,674 |  |  | $ | 15.16 |  |  |  | 3.64 |  |  |  |  |  |
|  |  |  | 193,521 |  |  | $ | 14.12 |  |  |  | 3.87 |  |  |  |  |  |
|  |  |  | 22,760 |  |  | $ | 19.36 |  |  |  | 4.12 |  |  |  |  |  |
|  |  |  | 5,550 |  |  | $ | 18.60 |  |  |  | 4.18 |  |  |  |  |  |
|  |  |  | 2,261 |  |  | $ | 12.83 |  |  |  | 4.37 |  |  |  |  |  |
| Options outstanding |  |  | 831,888 |  |  |  |  |  |  |  | 3.19 |  |  | $ | 1,481 |  |
| Options exercisable |  |  | 743,800 |  |  |  |  |  |  |  | 3.11 |  |  | $ | 1,233 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-15-031475:notes:103]
[same as prior period, unchanged from 0001193125-14-398478:notes:92]

[0001193125-15-031475:notes:104]
Share capital

[0001193125-15-031475:notes:105]
Fabrinet’s authorized share capital is 500,000,000 ordinary
 shares, par value of $0.01 per ordinary share, and 5,000,000
 preferred shares, par value of $0.01 per preferred share.

[0001193125-15-031475:notes:106]
For the six months ended December 26, 2014, Fabrinet issued
 26,677 ordinary shares upon the exercise of options, for cash
 consideration at a weighted average exercise price of $15.58 per
 share, and 192,437 ordinary shares upon the vesting of restricted
 share units, net of shares withheld.

[0001193125-15-031475:notes:107]
For the six months ended December 27, 2013, Fabrinet issued
 276,711 ordinary shares upon the exercise of options, for cash
 consideration at a weighted average exercise price of $12.78 per
 share, and 122,503 ordinary shares upon the vesting of restricted
 share units, net of shares withheld.

[0001193125-15-031475:notes:108]
All such issued shares are fully paid.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-15-031475:notes:109]
[same as prior period, unchanged from 0001193125-14-398478:notes:98]

[0001193125-15-031475:notes:110]
As of December 26, 2014 and June 27, 2014, the liability
 for uncertain tax positions including accrued interest and
 penalties was $1.2 million and $0.9 million,
 respectively. The Company expects the estimated amount of liability
 associated with its uncertain tax positions to decrease within the
 next 12 months due to the lapse of the applicable statute of
 limitations in foreign tax jurisdictions.

[0001193125-15-031475:notes:111]
The Company files income tax returns in the U.S. and foreign tax
 jurisdictions. The tax years from 2010 to 2014 remain open to
 examination by U.S. federal and state tax authorities, and foreign
 tax authorities. The Company’s income tax is recognized based
 on the best estimate of the expected annual effective tax rate for
 the full financial year of each entity in the Company, adjusted for
 discrete items arising in that quarter. If the Company’s
 estimated annual effective tax rate changes, the Company makes a
 cumulative adjustment in that quarter.

[0001193125-15-031475:notes:112]
The effective tax rate for the Company for the three months ended
 December 26, 2014 and December 27, 2013 was 10.5% and
 (10.4)% of net income, respectively. The increase in the effective
 tax rate for the three months ended December 26, 2014 was
 primarily due to the reversal of liabilities for uncertain tax
 positions, including accrued interest of $1.5 million in the
 three months ended December 27, 2013 and an increase in
 deferred tax assets of $0.6 million from the increase in the
 income tax rate of the Company’s subsidiary in China from 15%
 in the three months ended December 27, 2013 to 25% in the
 three months ended December 26, 2014 due to the expiration of
 a tax privilege.

[0001193125-15-031475:notes:113]
The effective tax rate for the Company for the six months ended
 December 26, 2014 and December 27, 2013 was 9.2% and
 (1.8)% of net income, respectively. The increase in the effective
 tax rate for the six months ended December 26, 2014 was
 primarily due to the reversal of liabilities for uncertain tax
 positions, including accrued interest of $1.5 million in the
 six months ended December 27, 2013 and an increase in deferred
 tax assets of $0.6 million from the increase in the income tax
 rate of the Company’s subsidiary in China from 15% in the six
 months ended December 27, 2013 to 25% in the six months ended
 December 26, 2014 due to the expiration of a tax privilege, as
 well as the fact that the Company had lower net income during the
 six months ended December 26, 2014 from income related to
 flooding of $6.6 million which was recognized during the six months
 ended December 27, 2013 that was not subject to income
 tax.


## us-gaap:SubsequentEventsTextBlock

[0001193125-15-031475:notes:114]
| 19. | Subsequent events |

[0001193125-15-031475:notes:115]
New subsidiaries

[0001193125-15-031475:notes:116]
On January 6, 2015 the Company incorporated Fabrilink SEZC, a
 100% wholly owned subsidiary, in the Cayman Islands. On
 January 16, 2015, the Company incorporated Fabrinet West, Inc.
 and Fabritek, Inc., 100% wholly owned subsidiaries, in California,
 United States.

[0001193125-15-031475:notes:117]
Lease commitment

[0001193125-15-031475:notes:118]
On January 26, 2015, the Company entered into a commercial
 lease agreement for a period of five years for office space of
 approximately 1,730 square feet at Cayman Enterprise City,
 HSBC House, 68 West Bay Road, Grand Cayman KY1-1003, Cayman
 Islands. Monthly service fee of the premises is $14,475 per
 month.

[0001193125-15-031475:notes:119]
Capital expenditure commitment

[0001193125-15-031475:notes:120]
On January 20, 2015, the Company entered into a building
 remodel project contract for a facility in Thailand of
 approximately $3.7 million.


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001193125-15-031475:notes:121]
| 16. | Income related to flooding |

[0001193125-15-031475:notes:122]
The Company suspended production at all of its manufacturing
 facilities in Thailand from October 17, 2011 through
 November 14, 2011 due to severe flooding in Thailand. The
 Company never resumed, and has permanently ceased, production at
 its Chokchai facility. The Company submitted claims for losses to
 its insurance companies, all of which have been settled as of the
 end of fiscal year 2014.

[0001193125-15-031475:notes:123]
In the three months ended December 27, 2013, the Company did
 not recognize any income related to flooding. In the six months
 ended December 27, 2013, the Company received from its
 insurers an interim payment of $6.6 million against its claim
 for owned and customer-owned inventory losses, which the Company
 recognized as income related to flooding.

[0001193125-15-031475:notes:124]
During the six months ended December 27, 2013, the Company
 fulfilled its obligations to a customer in accordance with a
 settlement agreement entered into during the third quarter of
 fiscal 2013 by making a final cash payment to such customer of
 $3.7 million and by transferring equipment, with an aggregate
 value of $2.3 million, to such customer. Also, the Company
 fulfilled its obligations to a customer’s insurers in
 accordance with a settlement agreement entered into during the
 fourth quarter of fiscal 2013 by making a final payment of
 $2.2 million. The Company also entered into other
 flood-related settlements of $0.1 million during the six
 months ended December 27, 2013.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-15-031475:notes:125]
[same as prior period, unchanged from 0001193125-14-398478:notes:108]

[0001193125-15-031475:notes:126]
[same as prior period, unchanged from 0001193125-14-398478:notes:109]

[0001193125-15-031475:notes:127]
In determining the grant date fair value of equity awards, the
 Company is required to make estimates of the fair value of
 Fabrinet’s ordinary shares, expected dividends to be issued,
 expected volatility of Fabrinet’s ordinary shares, expected
 forfeitures of the awards, risk free interest rates for the
 expected term of the awards, expected terms of the awards, and the
 vesting period of the respective awards. Forfeitures are estimated
 at the time of grant and revised if necessary in subsequent periods
 if actual forfeitures differ from those estimates.

[0001193125-15-031475:notes:128]
The Company did not capitalize any share-based compensation expense
 as part of any asset costs during the three and six months ended
 December 26, 2014 and December 27, 2013.

[0001193125-15-031475:notes:129]
[same as prior period, unchanged from 0001193125-14-398478:notes:112]

[0001193125-15-031475:notes:130]
Share options have been granted to directors and employees. As of
 December 26, 2014, there were 11,865 share options
 outstanding under Fabrinet’s Amended and Restated 1999 Share
 Option Plan (the “1999 Plan”). Additional option
 grants may not be made under the 1999 Plan.

[0001193125-15-031475:notes:131]
As of December 26, 2014, there were an aggregate of 820,023
 share options outstanding, 1,097,604 restricted share units
 outstanding, and 3,008,074 ordinary shares available for future
 grant under Fabrinet’s 2010 Performance Incentive Plan (the
 “2010 Plan”). The 1999 Plan and 2010 Plan are
 collectively referred to as the “Share Option
 Plans”.

[0001193125-15-031475:notes:132]
Share options

[0001193125-15-031475:notes:133]
Fabrinet’s board of directors has the authority to determine
 the type of option and the number of shares subject to an option.
 Options generally vest and become exercisable over four years and
 expire, if not exercised, within seven years of the grant date. In
 the case of a grantee’s first grant, 25 percent of the
 underlying shares subject to an option vest 12 months after
 the vesting commencement date and 1/48 of the underlying shares
 vest monthly over each of the subsequent 36 months. In
 the case of any additional grants to a grantee, 1/48 of the
 underlying shares subject to an option vest monthly over four
 years, commencing one month after the vesting commencement
 date.

[0001193125-15-031475:notes:134]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 27, 2014 |  |  | 865,890 |  |  |  |  |  |  | $ | 16.27 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (26,677 | ) |  |  |  |  |  | $ | 15.58 |  |  |  |  |  |
| Forfeited |  |  | (3,521 | ) |  |  |  |  |  | $ | 16.93 |  |  |  |  |  |
| Expired |  |  | (3,804 | ) |  |  |  |  |  | $ | 19.47 |  |  |  |  |  |
| Balance as of December 26, 2014 |  |  | 831,888 |  |  |  | 743,800 |  |  | $ | 16.27 |  |  |  |  |  |
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 28, 2013 |  |  | 1,277,311 |  |  |  |  |  |  | $ | 15.37 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (276,711 | ) |  |  |  |  |  | $ | 12.78 |  |  |  |  |  |
| Forfeited |  |  | (6,520 | ) |  |  |  |  |  | $ | 16.35 |  |  |  |  |  |
| Expired |  |  | (25,312 | ) |  |  |  |  |  | $ | 16.71 |  |  |  |  |  |
| Balance as of December 27, 2013 |  |  | 968,768 |  |  |  | 609,385 |  |  | $ | 16.07 |  |  |  |  |  |

[0001193125-15-031475:notes:135]
As of December 26, 2014, there was $0.1 million of
 unrecognized compensation expense related to share options under
 the Share Option Plans that is expected to be recognized over a
 weighted-average period of 0.82 years.

[0001193125-15-031475:notes:136]
Restricted share units

[0001193125-15-031475:notes:137]
Restricted share units are one type of share-based award that may
 be granted under the 2010 Plan. Restricted share units granted to
 non-employee directors generally cliff vest 100% on the first of
 January, approximately one year from the grant date, provided the
 director continues to serve through such date. Restricted share
 units granted to employees generally vest in four equal
 installments over four years on each anniversary of the vesting
 commencement date.

[0001193125-15-031475:notes:138]
As of December 26, 2014, there was $10.8 million of
 unrecognized share-based compensation expense related to restricted
 share units under the 2010 Plan that is expected to be recorded
 over a weighted-average period of 3.12 years.

[0001193125-15-031475:notes:139]
For the six months ended December 26, 2014 and
 December 27, 2013, the Company withheld an aggregate of 16,399
 shares and 10,242 shares, respectively, upon the vesting of
 restricted share units, based upon the closing share price on the
 vesting date to settle the employees’ minimum statutory
 obligation for the applicable income and other employment taxes.
 For the six months ended December 26, 2014 and
 December 27, 2013, the Company then remitted cash of
 $0.3 million and $0.2 million, respectively, to the
 appropriate taxing authorities, and presented it in a financing
 activity within the condensed consolidated statements of cash
 flows. The payment had the effect on shares issued by the Company
 as it reduced the number of shares that would have been issued on
 the vesting date and was recorded as a reduction of additional
 paid-in capital.


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001193125-15-031475:notes:140]
The following table provides details of the financial instruments
 measured at fair value on a recurring basis, including:

[0001193125-15-031475:notes:141]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of December 26, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 13,345 |  |  | $ | — |  |  | $ | 13,345 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 120,186 |  |  |  | — |  |  |  | 120,186 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 17,170 |  |  |  | — |  |  |  | 17,170 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 3,943 |  |  |  | — |  |  |  | 3,943 |  |
| Derivative assets |  |  | — |  |  |  | 21 | (1) |  |  | — |  |  |  | 21 |  |
| Total |  | $ | — |  |  | $ | 154,665 |  |  | $ | — |  |  | $ | 154,665 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 75 | (2) |  | $ | — |  |  | $ | 75 |  |
| Total |  | $ | — |  |  | $ | 75 |  |  | $ | — |  |  | $ | 75 |  |

[0001193125-15-031475:notes:142]
| (1) | Foreign currency options with notional amount of $11.0 million. |

[0001193125-15-031475:notes:143]
| (2) | Foreign currency options with notional amount of $19.0 million and forward contracts with notional amount of Canadian dollars 1.4 million. |

[0001193125-15-031475:notes:144]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 27, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 19,194 |  |  | $ | — |  |  | $ | 19,194 |  |
| Derivative assets |  |  | — |  |  |  | 135 | (3) |  |  | — |  |  |  | 135 |  |
| Total |  | $ | — |  |  | $ | 19,329 |  |  | $ | — |  |  | $ | 19,329 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 1 | (4) |  | $ | — |  |  | $ | 1 |  |
| Total |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |

[0001193125-15-031475:notes:145]
| (3) | Foreign currency options with notional amount of $15.0 million. |

[0001193125-15-031475:notes:146]
| (4) | Foreign currency forward contracts with notional amount of Canadian dollars 0.9 million. |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-15-031475:notes:147]
| 5. | Fair value of financial instruments |

[0001193125-15-031475:notes:148]
Fair value is defined as the exchange price that would be received
 for an asset or paid to transfer a liability (an exit price) in the
 principal or most advantageous market for the asset or liability in
 an orderly transaction between market participants on the
 measurement date. A fair value hierarchy is established which
 requires an entity to maximize the use of observable inputs and
 minimize the use of unobservable inputs for the valuation of an
 asset or liability as of measurement date. The three levels of
 inputs that may be used to measure fair value are defined as
 follows:

[0001193125-15-031475:notes:149]
Level 1 inputs are quoted prices (unadjusted) in active markets for
 identical assets or liabilities.

[0001193125-15-031475:notes:150]
Level 2 inputs are inputs other than quoted prices included within
 Level 1 that are observable for assets or liabilities, either
 directly or indirectly. If the assets or liabilities have a
 specified (contractual) term, Level 2 inputs must be
 observable for substantially the full term of assets or
 liabilities.

[0001193125-15-031475:notes:151]
Level 3 inputs are unobservable inputs for assets or liabilities,
 which require the reporting entity to develop its own valuation
 techniques and assumptions.

[0001193125-15-031475:notes:152]
The Company utilizes the market approach to measure fair value for
 its financial assets and liabilities. The market approach uses
 prices and other relevant information generated by market
 transactions involving identical or comparable assets or
 liabilities.

[0001193125-15-031475:notes:153]
Derivative Financial Instruments

[0001193125-15-031475:notes:154]
The Company uses foreign currency contracts to manage the foreign
 exchange risk associated with certain foreign currency-denominated
 assets and liabilities. As a result of foreign currency
 fluctuations, the U.S. dollar equivalent values of its foreign
 currency-denominated assets and liabilities change. The Company has
 not designated such foreign currency contracts as hedging
 instruments under the accounting standard for derivatives and
 hedging. The forward exchange contracts and option contracts
 outstanding as of December 26, 2014 and June 27, 2014 had
 a maturity in one to six months duration. The Company minimizes the
 credit risk in derivative instruments by limiting its exposure to
 any single counterparty and by entering into derivative instruments
 only with counterparties that meet the Company’s minimum
 credit quality standard.

[0001193125-15-031475:notes:155]
The derivative assets and liabilities are classified in other
 current assets and accrued expenses, respectively, on the condensed
 consolidated balance sheets. The change in the fair value of the
 derivatives is recorded in foreign exchange gain (loss) on the
 condensed consolidated statements of operations and comprehensive
 income.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-15-031475:notes:156]
[same as prior period, unchanged from 0001193125-14-398478:notes:133]

[0001193125-15-031475:notes:157]
The Company recorded amortization expense relating to intangibles
 of $0.02 million and $0.02 million for the three months
 ended December 26, 2014 and December 27, 2013,
 respectively, and $0.04 million and $0.05 million for the
 six months ended December 26, 2014 and December 27, 2013,
 respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-15-031475:notes:158]
| 13. | Accumulated other comprehensive loss |

[0001193125-15-031475:notes:159]
The Company’s accumulated other comprehensive loss consists
 of the accumulated net unrealized losses on available-for-sale
 securities. For the six months ended December 26, 2014, the
 changes in accumulated other comprehensive loss, net of tax were as
 follows:


## fn:AllowanceForDoubtfulAccountsTextBlock

[0001193125-15-031475:notes:160]
[same as prior period, unchanged from 0001193125-14-398478:notes:135]


## fn:ExpensesRelatedToReductionInWorkforceDisclosureTextBlock

[0001193125-15-031475:notes:161]
| 17. | Expenses related to reduction in workforce |

[0001193125-15-031475:notes:162]
As part of the Company’s ongoing efforts to achieve greater
 efficiencies in all areas of its business, during the six months
 ended December 26, 2014, the Company implemented a reduction
 in workforce and incurred expenses of approximately
 $1.2 million, which represented severance and benefits costs
 incurred for the termination of approximately 100 employees in
 accordance with contractual obligations and local regulations.
