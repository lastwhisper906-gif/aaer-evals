# FN 8-K — 0001193125-15-029705 filed 2015-02-02

## item codes, every 8-K on or before 2015-02-03

- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2015-02-03

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-029705:8k_2_02:1]
EX-99.1
2
d862026dex991.htm
EX-99.1

[0001193125-15-029705:8k_2_02:2]
EX-99.1

[0001193125-15-029705:8k_2_02:3]
Exhibit 99.1

[0001193125-15-029705:8k_2_02:4]
Fabrinet Announces Second Quarter Fiscal 2015 Financial Results

[0001193125-15-029705:8k_2_02:5]
BANGKOK, Thailand – February 2, 2015 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical,
electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for the second quarter ended December 26, 2014.

[0001193125-15-029705:8k_2_02:6]
Fabrinet reported total revenue of $188.4 million for the second quarter of fiscal 2015, an increase of 5.5% compared to total revenue of $178.6 million for
the comparable period in fiscal 2014. GAAP net income for the second quarter of fiscal 2015 was $8.7 million, or $0.24 per diluted share, compared to GAAP net income of $14.5 million, or $0.41 per diluted share, in the second quarter of fiscal 2014.
Non-GAAP net income in the second quarter of fiscal 2015 was $14.4 million, or $0.40 per diluted share, a decrease of 10.0% compared to non-GAAP net income of $16.0 million, or $0.45 per diluted share, in the same period a year ago.

[0001193125-15-029705:8k_2_02:7]
Tom Mitchell, Chief Executive Officer of Fabrinet, said, “Our fiscal second quarter results demonstrate our commitment to profitably growing our business
while making key investments for the future. These investments are beginning to bear fruit as we had another quarter of strong revenue growth from new customers.”

[0001193125-15-029705:8k_2_02:8]
Business Outlook

[0001193125-15-029705:8k_2_02:9]
Based on information available as of
February 2, 2015, Fabrinet is issuing guidance for the third quarter of fiscal 2015 as follows:

[0001193125-15-029705:8k_2_02:10]
Fabrinet expects third quarter revenue to be in the
range of $181 million to $185 million. GAAP net income per share is expected to be in the range of $0.27 to $0.29 with expected non-GAAP net income per share of $0.33 to $0.35, based on approximately 36 million fully diluted shares outstanding.

[0001193125-15-029705:8k_2_02:11]
Conference Call Information

[0001193125-15-029705:8k_2_02:12]
| What: |  | Fabrinet Second Quarter 2015 Financial Results Conference Call |
| When: |  | Monday, February 2, 2015 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic (253) 237-1137, international Passcode: 61174290 |
| Replay: |  | (855) 859-2056, domestic (404) 537-3406, international Passcode: 61174290 |
| Webcast: |  | http://investor.fabrinet.com (live and replay) |

[0001193125-15-029705:8k_2_02:13]
This press release and any other information related to the call will also be posted on Fabrinet’s website at
http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-15-029705:8k_2_02:14]
About Fabrinet

[0001193125-15-029705:8k_2_02:15]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original
equipment manufacturers of complex products, such as optical communication components, modules and subsystems, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire
manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and test. Fabrinet focuses on production of high complexity products in any mix and any volume.
Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the People’s Republic of China and the United States. For more information visit: www.fabrinet.com.

[0001193125-15-029705:8k_2_02:16]
Forward-Looking Statements

[0001193125-15-029705:8k_2_02:17]
Use of Non-GAAP Financials

[0001193125-15-029705:8k_2_02:18]
The Company refers to
the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding the Company’s ongoing operational performance. Non-GAAP net income excludes share-based compensation
expenses, audit committee internal investigation costs, expenses related to reduction in workforce, amortization of debt issuance costs and income related to flooding. We have excluded these items in order to enhance investors’ understanding of
our ongoing operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these
material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001193125-15-029705:8k_2_02:19]
These non-GAAP financial measures are used
to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and
operational decision making. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001193125-15-029705:8k_2_02:20]
SOURCE: Fabrinet

[0001193125-15-029705:8k_2_02:21]
Investor Contact:

[0001193125-15-029705:8k_2_02:22]
Jennifer Predmore

[0001193125-15-029705:8k_2_02:23]
215-428-1797

[0001193125-15-029705:8k_2_02:24]
ir@fabrinet.com

[0001193125-15-029705:8k_2_02:25]
Fabrinet

[0001193125-15-029705:8k_2_02:26]
Consolidated Balance Sheets

[0001193125-15-029705:8k_2_02:27]
As of December 26,
2014 and June 27, 2014

[0001193125-15-029705:8k_2_02:28]
| (in thousands of U.S. dollars, except share data) |  | December 26,2014 |  |  | June 27,2014 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 111,971 |  |  | $ | 233,477 |  |
| Marketable securities |  |  | 141,299 |  |  |  | — |  |
| Trade accounts receivable, net |  |  | 104,096 |  |  |  | 101,168 |  |
| Inventory, net |  |  | 127,804 |  |  |  | 124,570 |  |
| Deferred tax assets |  |  | 1,557 |  |  |  | 1,561 |  |
| Prepaid expenses |  |  | 1,366 |  |  |  | 1,691 |  |
| Other current assets |  |  | 2,356 |  |  |  | 2,010 |  |
| Total current assets |  |  | 490,449 |  |  |  | 464,477 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 106,498 |  |  |  | 97,244 |  |
| Intangibles, net |  |  | 52 |  |  |  | 72 |  |
| Deferred tax assets |  |  | 1,690 |  |  |  | 1,775 |  |
| Deferred debt issuance costs |  |  | 2,507 |  |  |  | 989 |  |
| Total non-current assets |  |  | 110,747 |  |  |  | 100,080 |  |
| Total assets |  | $ | 601,196 |  |  | $ | 564,557 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Long-term loans from bank, current portion |  | $ | 6,000 |  |  | $ | 6,000 |  |
| Trade accounts payable |  |  | 98,651 |  |  |  | 94,853 |  |
| Equipment-related payables |  |  | 10,919 |  |  |  | 1,130 |  |
| Income tax payable |  |  | 1,410 |  |  |  | 1,024 |  |
| Accrued payroll, bonus and related expenses |  |  | 7,619 |  |  |  | 8,612 |  |
| Accrued expenses |  |  | 7,521 |  |  |  | 4,345 |  |
| Other payables |  |  | 4,461 |  |  |  | 4,665 |  |
| Total current liabilities |  |  | 136,581 |  |  |  | 120,629 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term loans from bank, non-current portion |  |  | 7,500 |  |  |  | 10,500 |  |
| Deferred tax liability |  |  | 867 |  |  |  | 1,040 |  |
| Severance liabilities |  |  | 4,771 |  |  |  | 4,453 |  |
| Other non-current liabilities |  |  | 1,446 |  |  |  | 1,099 |  |
| Total non-current liabilities |  |  | 14,584 |  |  |  | 17,092 |  |
| Total liabilities |  |  | 151,165 |  |  |  | 137,721 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of December 26, 2014 and June 27, 2014) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 35,371,886 shares and 35,152,772 shares issued and outstanding as of December 26, 2014 and June 27, 2014, respectively) |  |  | 354 |  |  |  | 352 |  |
| Additional paid-in capital |  |  | 84,799 |  |  |  | 80,882 |  |
| Retained earnings |  |  | 365,364 |  |  |  | 345,602 |  |
| Accumulated other comprehensive loss |  |  | (486 | ) |  |  | — |  |
| Total shareholders’ equity |  |  | 450,031 |  |  |  | 426,836 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 601,196 |  |  | $ | 564,557 |  |

[0001193125-15-029705:8k_2_02:29]
Fabrinet

[0001193125-15-029705:8k_2_02:30]
Consolidated Statements of Operations and Comprehensive Income

[0001193125-15-029705:8k_2_02:31]
For the three and six months ended December 26, 2014 and December 27, 2013

[0001193125-15-029705:8k_2_02:32]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (in thousands of U.S. dollars, except share data) |  | December 26,2014 |  |  | December 27,2013 |  |  | December 26,2014 |  |  | December 27,2013 |  |
| Revenues |  | $ | 188,353 |  |  | $ | 178,562 |  |  | $ | 377,678 |  |  | $ | 350,113 |  |
| Cost of revenues |  |  | (167,292 | ) |  |  | (158,032 | ) |  |  | (336,111 | ) |  |  | (310,938 | ) |
| Gross profit |  |  | 21,061 |  |  |  | 20,530 |  |  |  | 41,567 |  |  |  | 39,175 |  |
| Selling, general and administrative expenses |  |  | (10,314 | ) |  |  | (6,913 | ) |  |  | (19,051 | ) |  |  | (13,607 | ) |
| Expenses related to reduction in workforce |  |  | (1,153 | ) |  |  | — |  |  |  | (1,153 | ) |  |  | — |  |
| Income related to flooding |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 6,597 |  |
| Operating income |  |  | 9,594 |  |  |  | 13,617 |  |  |  | 21,363 |  |  |  | 32,165 |  |
| Interest income |  |  | 324 |  |  |  | 338 |  |  |  | 698 |  |  |  | 702 |  |
| Interest expense |  |  | (117 | ) |  |  | (188 | ) |  |  | (250 | ) |  |  | (394 | ) |
| Foreign exchange gain (loss), net |  |  | 83 |  |  |  | (788 | ) |  |  | (23 | ) |  |  | 300 |  |
| Other (expense) income |  |  | (134 | ) |  |  | 187 |  |  |  | (31 | ) |  |  | 371 |  |
| Income before income taxes |  |  | 9,750 |  |  |  | 13,166 |  |  |  | 21,757 |  |  |  | 33,144 |  |
| Income tax (expense) benefit |  |  | (1,024 | ) |  |  | 1,373 |  |  |  | (1,995 | ) |  |  | 592 |  |
| Net income |  |  | 8,726 |  |  |  | 14,539 |  |  |  | 19,762 |  |  |  | 33,736 |  |
| Other comprehensive loss, before tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in fair value of marketable securities |  |  | (493 | ) |  |  | — |  |  |  | (493 | ) |  |  | — |  |
| Less : Reclassification adjustment for net loss realized and included in net income |  |  | 7 |  |  |  | — |  |  |  | 7 |  |  |  | — |  |
| Total change in unrealized loss on marketable securities, before of tax |  |  | (486 | ) |  |  | — |  |  |  | (486 | ) |  |  | — |  |
| Income tax expense related to items of other comprehensive income |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total other comprehensive loss, net of tax |  |  | (486 | ) |  |  | — |  |  |  | (486 | ) |  |  | — |  |
| Net comprehensive income |  | $ | 8,240 |  |  | $ | 14,539 |  |  | $ | 19,276 |  |  | $ | 33,736 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.25 |  |  | $ | 0.42 |  |  | $ | 0.56 |  |  | $ | 0.97 |  |
| Diluted |  | $ | 0.24 |  |  | $ | 0.41 |  |  | $ | 0.55 |  |  | $ | 0.95 |  |
| Weighted average number of ordinary shares outstanding(thousands of shares) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 35,349 |  |  |  | 34,882 |  |  |  | 35,289 |  |  |  | 34,778 |  |
| Diluted |  |  | 35,917 |  |  |  | 35,583 |  |  |  | 35,752 |  |  |  | 35,361 |  |

[0001193125-15-029705:8k_2_02:33]
Fabrinet

[0001193125-15-029705:8k_2_02:34]
Consolidated Statements of Cash Flows

[0001193125-15-029705:8k_2_02:35]
For the six
months ended December 26, 2014 and December 27, 2013

[0001193125-15-029705:8k_2_02:36]
|  |  | Six Months Ended |  |
| (in thousands of U. S. dollars) |  | December 26,2014 |  |  | December 27,2013 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income for the period |  | $ | 19,762 |  |  | $ | 33,736 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 5,907 |  |  |  | 5,030 |  |
| Amortization of intangibles |  |  | 42 |  |  |  | 51 |  |
| Gain on disposal of property, plant and equipment |  |  | (46 | ) |  |  | (1 | ) |
| Amortization of investment premium |  |  | 298 |  |  |  | — |  |
| Amortization of deferred debt issuance costs |  |  | 228 |  |  |  | — |  |
| Income related to flooding |  |  | — |  |  |  | (6,597 | ) |
| Proceeds from insurers for inventory losses related to flooding |  |  | — |  |  |  | 6,597 |  |
| Reversal of allowance for doubtful accounts |  |  | (3 | ) |  |  | (53 | ) |
| Unrealized (gain) loss on exchange rate and fair value of derivative |  |  |  |  |  |  |  |  |
| and available-for-sale securities |  |  | (109 | ) |  |  | 681 |  |
| Share-based compensation |  |  | 3,797 |  |  |  | 3,060 |  |
| Deferred income tax |  |  | (84 | ) |  |  | 188 |  |
| Other non-cash expenses |  |  | 665 |  |  |  | 232 |  |
| Reversal of uncertain tax positions |  |  | — |  |  |  | (1,538 | ) |
| Inventory obsolescence |  |  | 317 |  |  |  | 104 |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | (2,925 | ) |  |  | (3,244 | ) |
| Inventory |  |  | (3,551 | ) |  |  | (7,856 | ) |
| Other current assets and non-current assets |  |  | (21 | ) |  |  | 171 |  |
| Trade accounts payable |  |  | 3,798 |  |  |  | 10,886 |  |
| Income tax payable |  |  | 386 |  |  |  | 232 |  |
| Other current liabilities and non-current liabilities |  |  | 2,140 |  |  |  | 1,099 |  |
| Liabilities to third parties due to flood losses |  |  | — |  |  |  | (5,974 | ) |
| Net cash provided by operating activities |  |  | 30,601 |  |  |  | 36,804 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of available-for-sale securities |  |  | (143,684 | ) |  |  | — |  |
| Proceeds from maturities of available-for-sale securities |  |  | 543 |  |  |  | — |  |
| Proceeds from sales of available-for-sale securities |  |  | 1,056 |  |  |  | — |  |
| Purchase of property, plant and equipment |  |  | (5,372 | ) |  |  | (4,198 | ) |
| Purchase of Intangibles |  |  | (22 | ) |  |  | — |  |
| Proceeds from disposal of property, plant and equipment |  |  | 46 |  |  |  | 1 |  |
| Net cash used in investing activities |  |  | (147,433 | ) |  |  | (4,197 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Payment of debt issuance costs |  |  | (1,746 | ) |  |  | — |  |
| Repayment of long-term loans from bank |  |  | (3,000 | ) |  |  | (4,834 | ) |
| Proceeds from issuance of ordinary shares under employee share option plans |  |  | 415 |  |  |  | 3,531 |  |
| Withholding tax related to net share settlement of restricted share units |  |  | (293 | ) |  |  | (162 | ) |
| Net cash used in financing activities |  |  | (4,624 | ) |  |  | (1,465 | ) |
| Net (decrease) increase in cash and cash equivalents |  | $ | (121,456 | ) |  | $ | 31,142 |  |

[0001193125-15-029705:8k_2_02:37]
Fabrinet

[0001193125-15-029705:8k_2_02:38]
Consolidated Statements of Cash Flows

[0001193125-15-029705:8k_2_02:39]
For the six
months ended December 26, 2014 and December 27, 2013

[0001193125-15-029705:8k_2_02:40]
|  |  | Six Months Ended |  |
| (in thousands of U.S. dollars) |  | December 26,2014 |  |  | December 27,2013 |  |
| Movement in cash and cash equivalents |  |  |  |  |  |  |  |  |
| Cash and cash equivalents at beginning of period |  | $ | 233,477 |  |  | $ | 149,716 |  |
| (Decrease) increase in cash and cash equivalents |  |  | (121,456 | ) |  |  | 31,142 |  |
| Effect of exchange rate on cash and cash equivalents |  |  | (50 | ) |  |  | (800 | ) |
| Cash and cash equivalents at end of period |  | $ | 111,971 |  |  | $ | 180,058 |  |
| Non-cash investing and financing activities |  |  |  |  |  |  |  |  |
| Equipment-related payables |  |  | 10,919 |  |  |  | 2,825 |  |

[0001193125-15-029705:8k_2_02:41]
Fabrinet

[0001193125-15-029705:8k_2_02:42]
Reconciliation of GAAP measures to non-GAAP measures

[0001193125-15-029705:8k_2_02:43]
(in thousands of U.S. dollars, except per share data)

[0001193125-15-029705:8k_2_02:44]
(unaudited)

[0001193125-15-029705:8k_2_02:45]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 26,2014 |  |  | December 26,2014 |  |  | December 27,2013 |  |  | December 27,2013 |  |  | December 26,2014 |  |  | December 26,2014 |  |  | December 27,2013 |  |  | December 27,2013 |  |
|  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |
| GAAP measures |  |  | 8,726 |  |  |  | 0.24 |  |  |  | 14,539 |  |  |  | 0.41 |  |  |  | 19,762 |  |  |  | 0.55 |  |  |  | 33,736 |  |  |  | 0.95 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 360 |  |  |  | 0.01 |  |  |  | 291 |  |  |  | 0.01 |  |  |  | 728 |  |  |  | 0.02 |  |  |  | 598 |  |  |  | 0.02 |  |
| Total related to gross profit |  |  | 360 |  |  |  | 0.01 |  |  |  | 291 |  |  |  | 0.01 |  |  |  | 728 |  |  |  | 0.02 |  |  |  | 598 |  |  |  | 0.02 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,570 |  |  |  | 0.04 |  |  |  | 1,206 |  |  |  | 0.03 |  |  |  | 3,069 |  |  |  | 0.09 |  |  |  | 2,462 |  |  |  | 0.07 |  |
| Investigation costs |  |  | 2,500 |  |  |  | 0.07 |  |  |  | — |  |  |  | — |  |  |  | 4,100 |  |  |  | 0.11 |  |  |  | — |  |  |  | — |  |
| Total related to selling, general and administrative expenses |  |  | 4,070 |  |  |  | 0.11 |  |  |  | 1,206 |  |  |  | 0.03 |  |  |  | 7,169 |  |  |  | 0.20 |  |  |  | 2,462 |  |  |  | 0.07 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income related to flooding |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (6,597 | ) |  |  | (0.19 | ) |
| Expenses related to reduction in workforce |  |  | 1,153 |  |  |  | 0.03 |  |  |  | — |  |  |  | — |  |  |  | 1,153 |  |  |  | 0.03 |  |  |  | — |  |  |  | — |  |
| Amortization of debt issuance costs |  |  | 228 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 228 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |
| Total related to other incomes and other expenses |  |  | 1,381 |  |  |  | 0.04 |  |  |  | — |  |  |  | — |  |  |  | 1,381 |  |  |  | 0.04 |  |  |  | (6,597 | ) |  |  | (0.19 | ) |
| Related to income tax expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense |  |  | (187 | ) |  |  | (0.01 | ) |  |  | — |  |  |  | — |  |  |  | (187 | ) |  |  | (0.01 | ) |  |  | — |  |  |  | — |  |
| Total related to income tax expense |  |  | (187 | ) |  |  | (0.01 | ) |  |  | — |  |  |  | — |  |  |  | (187 | ) |  |  | (0.01 | ) |  |  | — |  |  |  | — |  |
| Total related to net income & EPS |  |  | 5,624 |  |  |  | 0.16 |  |  |  | 1,497 |  |  |  | 0.04 |  |  |  | 9,091 |  |  |  | 0.25 |  |  |  | (3,537 | ) |  |  | (0.10 | ) |
| Non-GAAP measures |  |  | 14,350 |  |  |  | 0.40 |  |  |  | 16,036 |  |  |  | 0.45 |  |  |  | 28,853 |  |  |  | 0.81 |  |  |  | 30,199 |  |  |  | 0.85 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 35,917 |  |  |  |  |  |  |  | 35,583 |  |  |  |  |  |  |  | 35,752 |  |  |  |  |  |  |  | 35,361 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 35,917 |  |  |  |  |  |  |  | 35,583 |  |  |  |  |  |  |  | 35,752 |  |  |  |  |  |  |  | 35,361 |  |
