# FN 10-Q controls and the auditor's report


## item_4_controls

[0001193125-15-031475:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0001193125-15-031475:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001193125-15-031475:item_4_controls:3]
Our management is responsible for establishing and maintaining disclosure controls and procedures designed to ensure that the information we are required to
disclose in reports we file or submit under the Securities Exchange Act of 1934, as amended (“Exchange Act”), (i) is recorded, processed, summarized, and reported within time periods specified in the rules and forms of the Securities
and Exchange Commission, and (ii) is accumulated and communicated to Fabrinet’s management, including our Chief Executive Officer (“CEO”) and Chief Financial Officer (“CFO”), as appropriate, to allow timely decisions
regarding required disclosure.

[0001193125-15-031475:item_4_controls:4]
Our management, including our CEO and CFO, evaluated the effectiveness of our disclosure controls and procedures (as
defined in Rule 13a-15(e) of the Exchange Act), as of December 26, 2014, the end of the period covered by this Quarterly Report on Form 10-Q. Disclosure controls and procedures include, without
limitation, controls, and procedures designed to ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is accumulated and communicated to the Company’s management, including
its principal executive and principal financial officers, as appropriate to allow timely decisions regarding required disclosure. Based on their evaluation, our CEO and CFO concluded that the Company’s disclosure controls and procedures were
not effective as of that date.

[0001193125-15-031475:item_4_controls:5]
Remediation Steps

[0001193125-15-031475:item_4_controls:6]
As disclosed in our Annual Report for the fiscal year ended June 27, 2014, we identified a material weakness in our internal control over financial
reporting such that our disclosure controls and procedures related to revenue recognition for certain volume supply agreements with our customers were not effective. Specifically, we determined that we did not correctly apply appropriate U.S. GAAP
knowledge and expertise when assessing the terms of these arrangements with respect to when title and risk of loss transfers to our customers.

[0001193125-15-031475:item_4_controls:7]
In
response to this material weakness, our management, under the supervision of our CEO and CFO, is implementing the following remedial measures:

[0001193125-15-031475:item_4_controls:8]
|  | • |  | We are implementing procedures to ensure that all customer contracts are reviewed at inception and quarterly for compliance with U.S. GAAP. Specifically, we are in the process of reviewing and, as necessary, revising or amending our volume supply agreements with our customers to properly reflect our current business practices. We have also developed a detailed plan for periodic U.S. GAAP compliance review on all new and existing contracts. |

[0001193125-15-031475:item_4_controls:9]
|  | • |  | We will continue to enhance our technical accounting training, led by appropriate technical accounting experts to improve awareness and understanding of revenue accounting principles. |

[0001193125-15-031475:item_4_controls:10]
The material weakness identified by management is not fully remediated as of the date of the filing of this Quarterly Report on
Form 10-Q. Some remediation measures such as amendment of our volume supply agreements with our customers are ongoing. We have implemented new controls for consignment process and undertaken internal
audit procedures during the three months ended December 26, 2014. In addition, under the direction of the Audit Committee, management will continue to review and make necessary changes to the overall design of the system of internal controls,
and the control environment, to improve the overall effectiveness of internal control over financial reporting.

[0001193125-15-031475:item_4_controls:11]
Changes in Internal Control over
Financial Reporting

[0001193125-15-031475:item_4_controls:12]
During the three and six months ended December 26, 2014, the Company began implementing the remedial measures described
above. Other than as described herein, there have been no changes in the Company’s internal control over financial reporting during the three and six months ended December 26, 2014 that materially affected, or are reasonably likely to
materially affect, the Company’s internal control over financial reporting.

[0001193125-15-031475:item_4_controls:13]
36
