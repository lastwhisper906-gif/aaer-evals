# FN MD&A — 0001193125-15-031475


## mdna

[0001193125-15-031475:mdna:1]
ITEM 2. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND
RESULTS OF OPERATIONS

[0001193125-15-031475:mdna:2]
[same as prior period, unchanged from 0001193125-14-398478:mdna:2]

[0001193125-15-031475:mdna:3]
[same as prior period, unchanged from 0001193125-14-398478:mdna:3]

[0001193125-15-031475:mdna:4]
|  | • |  | our expectation that the portion of our future revenues attributable to customers in regions outside of North America will decrease compared to the portion of those revenues for the six months ended December 26, 2014; |

[0001193125-15-031475:mdna:5]
[same as prior period, unchanged from 0001193125-14-398478:mdna:5]

[0001193125-15-031475:mdna:6]
[same as prior period, unchanged from 0001193125-14-398478:mdna:6]

[0001193125-15-031475:mdna:7]
[same as prior period, unchanged from 0001193125-14-398478:mdna:7]

[0001193125-15-031475:mdna:8]
|  | • |  | our expectation that, in addition to incremental costs associated with growing our business generally, we will incur additional SG&A expenses as a result of our plan to expand our business in the United States; |

[0001193125-15-031475:mdna:9]
[same as prior period, unchanged from 0001193125-14-398478:mdna:9]

[0001193125-15-031475:mdna:10]
[same as prior period, unchanged from 0001193125-14-398478:mdna:10]

[0001193125-15-031475:mdna:11]
[same as prior period, unchanged from 0001193125-14-398478:mdna:11]

[0001193125-15-031475:mdna:12]
[same as prior period, unchanged from 0001193125-14-398478:mdna:12]

[0001193125-15-031475:mdna:13]
[same as prior period, unchanged from 0001193125-14-398478:mdna:13]

[0001193125-15-031475:mdna:14]
[same as prior period, unchanged from 0001193125-14-398478:mdna:14]

[0001193125-15-031475:mdna:15]
[same as prior period, unchanged from 0001193125-14-398478:mdna:15]

[0001193125-15-031475:mdna:16]
[same as prior period, unchanged from 0001193125-14-398478:mdna:16]

[0001193125-15-031475:mdna:17]
[same as prior period, unchanged from 0001193125-14-398478:mdna:17]

[0001193125-15-031475:mdna:18]
[same as prior period, unchanged from 0001193125-14-398478:mdna:18]

[0001193125-15-031475:mdna:19]
[same as prior period, unchanged from 0001193125-14-398478:mdna:19]

[0001193125-15-031475:mdna:20]
[same as prior period, unchanged from 0001193125-14-398478:mdna:20]

[0001193125-15-031475:mdna:21]
We provide advanced optical
packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers (OEMs) of complex products such as optical communication components, modules and sub-systems, industrial lasers and
sensors. We offer a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final
assembly and test. Although, we focus primarily on low-volume production of a wide variety of high complexity products, which we refer to as “low-volume, high-mix”, we also have the capability to accommodate high-volume production. Based
on our experience with, and positive feedback we have received from our customers, we believe we are a global leader in providing these services to the optical communications, industrial lasers, automotive, and sensors markets.

[0001193125-15-031475:mdna:22]
Our customer base includes companies in complex industries that require advanced precision manufacturing capabilities such as optical
communications, industrial lasers, automotive, and sensors. The products that we manufacture for our OEM customers include selective switching products; tunable transponders and transceivers; active optical cables; solid state, diode-pumped, gas and
fiber lasers; and sensors. In many cases, we are the sole outsourced manufacturing partner used by our customers for the products that we produce for them.

[0001193125-15-031475:mdna:23]
We also design and fabricate application-specific crystals; prisms; mirrors; laser components; substrates, and other custom and standard
borosilicate, clear fused quartz, and synthetic fused silica glass products. We incorporate our customized optics and glass into many of the products we manufacture for our OEM customers, and we also sell customized optics and glass in the merchant
market.

[0001193125-15-031475:mdna:24]
[same as prior period, unchanged from 0001193125-14-398478:mdna:24]

[0001193125-15-031475:mdna:25]
During the fourth quarter of our fiscal year 2014, the Company identified violations of our policies and procedures relating to finished goods
held in our warehouse on behalf of our customers (the Company refers to finished goods held in our warehouse on behalf of our customers as consignment goods or consignment inventory and when the finished goods are sold the Company refers to the
related revenue as consignment revenue). Specifically, the Company identified violations related to certain employees in one business unit colluding to cause the improper recognition of revenues for certain goods by recording consignment revenues on
goods before such goods were finished.

[0001193125-15-031475:mdna:26]
In connection with the above, the Audit Committee of our Board of Directors initiated an
investigation concerning various accounting cut-off issues in fiscal year 2014, specifically the transfer of unfinished goods to consignment inventory and other inventory cut-off considerations. The investigation found certain process weaknesses
concerning the potential to invoice unfinished goods held under consignment arrangements and the need for certain remedial measures.

[0001193125-15-031475:mdna:27]
The
Company is working to complete the following recommended remedial measures that were identified through the investigation:

[0001193125-15-031475:mdna:28]
[same as prior period, unchanged from 0001193125-14-398478:mdna:28]

[0001193125-15-031475:mdna:29]
[same as prior period, unchanged from 0001193125-14-398478:mdna:29]

[0001193125-15-031475:mdna:30]
[same as prior period, unchanged from 0001193125-14-398478:mdna:30]

[0001193125-15-031475:mdna:31]
[same as prior period, unchanged from 0001193125-14-398478:mdna:31]

[0001193125-15-031475:mdna:32]
Based on an analysis prepared by the Company, it was determined that the potential exposure relating to the control deficiencies identified
during the investigation was not material to our consolidated financial statements for the fiscal year 2014. Further, the Company assessed these control deficiencies to be significant deficiencies rather than material weaknesses on the basis that
there was no executive officer involvement in the violations, the potential misstatements were not material to the consolidated financial statements and the Audit Committee was actively involved in the investigation.

[0001193125-15-031475:mdna:33]
[same as prior period, unchanged from 0001193125-14-398478:mdna:33]

[0001193125-15-031475:mdna:34]
Subsequent to completion of the Audit Committee’s investigation, the Company evaluated its accounting practices surrounding consignment
inventory and consignment revenue. Based on that evaluation, the Company determined that for certain volume supply agreements with our customers not all of the revenue recognition criteria prescribed by U.S. GAAP and Staff Accounting Bulletin
No. 104 had been met at the time revenue was recorded. Specifically, the Company misapplied the guidance when assessing the terms of these agreements with respect to when title and risk of loss transfers to our customers. As a result, the
Company determined that certain sales previously recognized did not qualify for revenue recognition in the periods in which they were recognized. The Company has evaluated the impact of the errors on both a quantitative and qualitative basis under
the guidance of ASC 250 – Accounting Changes and Error Corrections and determined that the errors did not have a material impact to the previously issued consolidated financial statements. The Company has assessed the control implications
and concluded that the deficiency constituted a material weakness in internal control over financial reporting (refer to Part I, Item 4 for additional information).

[0001193125-15-031475:mdna:35]
Had adjustments in the prior period been made to reflect revenues that were inappropriately recorded in the three and six months ended
December 27, 2013, revenues for the three and six months ended December 27, 2013 would have been $6.4 million and $3.6 million lower, respectively.

[0001193125-15-031475:mdna:36]
During the three months ended December 26, 2014, we amended certain volume supply agreements such that under certain conditions the Company
recognizes revenue upon product being delivered to our warehouse. We refer to such revenue as “consignment revenue.” Specifically, we recognize consignment revenue when the goods are completed, ready for shipment, and title and risk of
loss have passed to the customer. As a result, in the three months ended December 26, 2014, we recorded revenue of $ 8.0 million with $0.8 million gross profit from these amended volume supply agreements.

[0001193125-15-031475:mdna:37]
[same as prior period, unchanged from 0001193125-14-398478:mdna:36]

[0001193125-15-031475:mdna:38]
We suspended
production at all of our manufacturing facilities in Thailand from October 17, 2011 through November 14, 2011 due to severe flooding in Thailand. We never resumed, and have permanently ceased, production at our Chokchai facility. We
submitted claims for losses to our insurance companies, all of which have been settled as of fiscal year 2014.

[0001193125-15-031475:mdna:39]
In the three months ended
December 27, 2013, we did not recognize any income related to flooding. In the six months ended December 27, 2013, we received from our insurers an interim payment of $6.6 million against our claim for owned and customer-owned
inventory losses, which we recognized as income related to flooding.

[0001193125-15-031475:mdna:40]
During the six months ended December 27, 2013, we fulfilled our
obligations to a customer in accordance with the settlement agreement entered into during the third quarter of fiscal 2013 by making a final cash payment to such customer of $3.7 million and by transferring equipment, with an aggregate value of
$2.3 million, to such customer. Also, we fulfilled our obligations to a customer’s insurers in accordance with the settlement agreement entered into during the fourth quarter of fiscal 2013 by making a final payment of $2.2 million.
We also entered into other flood-related settlements of $0.1 million during the six months ended December 27, 2013.

[0001193125-15-031475:mdna:41]
[same as prior period, unchanged from 0001193125-14-398478:mdna:40]

[0001193125-15-031475:mdna:42]
Our total revenues increased by $9.8 million, or 5.5%, to $188.4 million for the three months ended December 26, 2014, compared
with $178.6 million for the three months ended December 27, 2013. Our total revenues increased by $27.6 million, or 7.9%, to $377.7 million for the six months ended December 26, 2014, compared with $350.1 million for
the six months ended December 27, 2013. The increase was primarily due to an increase in our customers’ demand for both optical and non-optical communications manufacturing services during the six months ended December 26, 2014.

[0001193125-15-031475:mdna:43]
We believe our ability to expand our relationships with existing customers and attract new customers is due to a number of factors, including
our broad range of complex engineering and manufacturing service offerings, flexible low-cost manufacturing platform, process optimization capabilities, advanced supply chain management, excellent customer service, and experienced management team.
While we expect the prices we charge for our manufactured products to decrease over time (partly as a result of competitive market forces), we still believe we will be able to maintain favorable pricing for our services because of our ability to
reduce cycle time, adjust our product mix by focusing on more complicated products, improve product quality and yields, and reduce material costs for the products we manufacture. We believe these capabilities have enabled us to help our OEM
customers reduce their manufacturing costs while maintaining or improving the design, quality, reliability, and delivery times for their products.

[0001193125-15-031475:mdna:44]
[same as prior period, unchanged from 0001193125-14-398478:mdna:43]

[0001193125-15-031475:mdna:45]
We generate revenues from three geographic regions: North America, Asia-Pacific and Europe. Revenues are attributed to a particular geographic
area based on the bill-to location of our customers, notwithstanding that our customers may ultimately ship their products to end customers in a different geographic region. Virtually all of our revenues are derived from our manufacturing facilities
in Asia-Pacific.

[0001193125-15-031475:mdna:46]
The percentage of our revenues generated from bill-to location outside of North America decreased from 52.7% in the
three months ended December 27, 2013 to 50.3% in the three months ended December 26, 2014 and from 53.4% in the six months ended December 27, 2013 to 51.1% in the six months ended December 26, 2014, primarily because of a
decrease in sales volume of our customers in those regions. We expect that the portion of our future revenues attributable to customers in regions outside North America will decrease as compared with the first half of fiscal year 2015.

[0001193125-15-031475:mdna:47]
[same as prior period, unchanged from 0001193125-14-398478:mdna:46]

[0001193125-15-031475:mdna:48]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 26,2014 |  |  | December 27,2013 |  |  | December 26,2014 |  |  | December 27,2013 |  |
| North America |  |  | 49.7 | % |  |  | 47.3 | % |  |  | 48.9 | % |  |  | 46.6 | % |
| Asia-Pacific |  |  | 37.7 |  |  |  | 33.4 |  |  |  | 39.4 |  |  |  | 33.6 |  |
| Europe |  |  | 12.6 |  |  |  | 19.3 |  |  |  | 11.7 |  |  |  | 19.8 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-15-031475:mdna:49]
[same as prior period, unchanged from 0001193125-14-398478:mdna:48]

[0001193125-15-031475:mdna:50]
We enter into supply agreements with our customers which generally have an initial term of up to three years, subject to automatic renewals for
subsequent one-year terms unless expressly terminated. Although there are no minimum purchase requirements in our supply agreements, our customers do provide us with rolling forecasts of their demand requirements. Our supply agreements generally
include provisions for pricing and periodic review of pricing, consignment of our customer’s unique production equipment to us, and the sharing of benefits from cost-savings derived from our efforts. We are generally required to purchase
materials, which may include long lead-time materials and materials that are subject to minimum order quantities and/or non-cancelable or non-returnable terms, to meet the stated demands of our customers. After procuring materials, we manufacture
products for our customers based on purchase orders that contain terms regarding product quantities, delivery locations and delivery dates. Our customers generally are obligated to purchase finished goods that we have manufactured according to their
demand requirements. Materials that are not consumed by our customers within a specified period of time, or are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under
our contracts. Once materials are designated as either excess or obsolete inventory, our customers are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products.

[0001193125-15-031475:mdna:51]
[same as prior period, unchanged from 0001193125-14-398478:mdna:50]

[0001193125-15-031475:mdna:52]
The key components of
our cost of revenues are material costs, employee costs, and infrastructure-related costs. Material costs generally represent the majority of our cost of revenues. Several of the materials we require to manufacture products for our customers are
customized for their products and often sourced from a single supplier or in some cases, our own subsidiaries. Shortages from sole-source suppliers due to yield loss, quality concerns, and capacity constraints, among other factors, may increase our
expenses and negatively impact our gross profit margin or total revenues in a given quarter. Material costs include scrap material. Historically, scrap rate diminishes during a product’s life cycle due to process, fixturing and test
improvement, and optimization.

[0001193125-15-031475:mdna:53]
A second significant element of our cost of revenues is employee costs, including indirect employee costs
related to design; configuration and optimization of manufacturing processes for our customers, quality testing; materials testing and other engineering services; and direct costs related to our manufacturing employees. Direct employee costs include
employee salaries, insurance and benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a
lesser extent, costs to recruit, train and retain employees. Our cost of revenues are significantly impacted by salary levels in Thailand and the PRC; the fluctuation of the Thai baht and RMB against our functional currency, the U.S. dollar; and our
ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. For example, effective April 1, 2012, the Thai government increased minimum daily wages from 215 Thai baht to
300 Thai baht. Wage increases may impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention, and asset
utilization.

[0001193125-15-031475:mdna:54]
Our infrastructure costs are comprised of depreciation, utilities, facilities management, and
overhead costs. Most of our facility leases are long-term agreements. Our depreciation costs include buildings and fixed assets, primarily at our Pinehurst campus in Thailand, and capital equipment located at each of our manufacturing locations.

[0001193125-15-031475:mdna:55]
During the three and six months ended December 26, 2014, discretionary merit-based bonus awards were made to our non-executive
employees. Charges included in cost of revenues for bonus distributions to non-executive employees were $0.6 million and $0.5 million for the three months ended December 26, 2014 and December 27, 2013, respectively, and
$1.2 million and $1.1 million for the six months ended December 26, 2014 and December 27, 2013, respectively.

[0001193125-15-031475:mdna:56]
Share-based compensation expense included in cost of revenues was $0.4 million and $0.3 million for the three months ended
December 26, 2014 and December 27, 2013, respectively, and $0.7 million and $0.6 million for the six months ended December 26, 2014 and December 27, 2013, respectively.

[0001193125-15-031475:mdna:57]
We expect to incur significant incremental costs of revenue as a result of our continued diversification into the industrial lasers,
automotive, and sensors markets and other end-markets outside of the optical communications market or our further development of customized optics and glass manufacturing capabilities. We also expect to incur incremental costs of revenue as a result
of our planned expansion into new geographic markets, though we are not able to determine the amount of these incremental expenses.

[0001193125-15-031475:mdna:58]
Selling, General
and Administrative Expenses

[0001193125-15-031475:mdna:59]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and
administrative, and other support personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense, and other general
expenses not related to cost of revenues. In fiscal year 2015, we expect our SG&A expenses will increase on an absolute dollar basis and remain flat as a percentage of revenue compared with fiscal year 2014.

[0001193125-15-031475:mdna:60]
The compensation committee of our board of directors approved a fiscal year 2015 executive incentive plan with quantitative objectives, based
on achieving certain revenue and non-GAAP earnings per share targets for our fiscal year ending June 26, 2015, as well as qualitative objectives, based on achieving individual performance goals. Bonuses under our fiscal year 2015 executive
incentive plan are payable after the end of fiscal year 2015. In fiscal year 2014, the compensation committee approved a fiscal year 2014 executive incentive plan with quantitative objectives, based on achieving certain revenue and gross margin
percentage targets for our fiscal year ended June 27, 2014, as well as qualitative objectives, based on achieving individual performance goals. In the three months ended December 26, 2014, the compensation committee awarded bonuses to our
executive employees for Company and individual achievements of performance under our fiscal 2014 executive incentive plan. Discretionary merit-based bonus awards were also available to our non-executive employees and were payable as of
December 26, 2014.

[0001193125-15-031475:mdna:61]
Charges included in SG&A expenses for bonus distributions to non-executive and executive employees were
$0.6 million and $1.0 million for the three months ended December 26, 2014 and December 27, 2013, respectively, and $1.2 million and $1.7 million for the six months ended December 26, 2014 and December 27,
2013, respectively.

[0001193125-15-031475:mdna:62]
Share-based compensation expense included in SG&A expenses was $1.6 million and $1.2 million for the
three months ended December 26, 2014 and December 27, 2013, respectively, and $3.1 million and $2.5 million for the six months ended December 26, 2014 and December 27, 2013, respectively.

[0001193125-15-031475:mdna:63]
In addition to our incremental costs associated with growing our business generally, we expect to incur additional SG&A expenses as a
result of our plan to expand our business in the United States.

[0001193125-15-031475:mdna:64]
[same as prior period, unchanged from 0001193125-14-398478:mdna:63]

[0001193125-15-031475:mdna:65]
[same as prior period, unchanged from 0001193125-14-398478:mdna:64]

[0001193125-15-031475:mdna:66]
As a result of our international operations, we are exposed to foreign exchange risk arising from various currency exposures primarily with
respect to the Thai baht. Although a majority of our total revenues is denominated in U.S. dollars, a substantial portion of our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rates between the Thai
baht and the U.S. dollar have fluctuated substantially in recent years and may continue to fluctuate substantially in the future. We report our financial results in U.S. dollars and our results of operations have been and may continue to be
negatively impacted owing to appreciation of the Thai baht against the U.S. dollar. Smaller portions of our expenses are incurred in a variety of other currencies, including RMB, Canadian dollars, Euros, and Japanese yen, the appreciation of which
may also negatively impact our financial results.

[0001193125-15-031475:mdna:67]
In addition, we are exposed to foreign exchange risk in connection with the credit
facility and cross currency swap arrangements we entered into with TMB Bank Public Company Limited (the “Bank”) in May 2011 for the construction of Pinehurst Building 6. The terms of the contract with the Bank provide the following
facilities: (1) a term loan facility for up to Thai baht 960 million (equal to $30.0 million) with a fixed interest rate of 5.28% per annum, (2) a hedging facility for currency interest rate swaps with a notional amount of
$30.0 million, and (3) a settlement limit of Thai baht 65 million, subject to certain terms and conditions as set forth therein. As of March 30, 2012, we had drawn down the entire $30.0 million available under the term loan
facility. Borrowings and interest under the term loan have been scheduled to be repaid on a quarterly basis between September 2011 and March 2017. As of December 26, 2014, we had outstanding borrowings under the term loan facility of
$13.5 million. Under the terms of the cross currency swap arrangement amounts drawn in Thai baht were converted to U.S. dollars for repayment by us on a quarterly basis at the floating rate of 3-month London Interbank Offered Rate (LIBOR) plus
2.8% per annum.

[0001193125-15-031475:mdna:68]
In order to manage the risks arising from fluctuations in foreign currency exchange rates, we use derivative
financial instruments. We may enter into short-term forward exchange currency contracts or put option contracts to help manage currency exposures associated with certain assets and liabilities, primarily short-term obligations. The forward exchange
contracts and put option contracts generally had original maturities of one to six months, and no forward exchange contract or put option contract has had an original maturity greater than one year. All foreign currency exchange contracts are
recognized on the condensed consolidated balance sheet at fair value. As we do not apply hedge accounting to these instruments, the change in the fair value of the derivatives are recorded in foreign exchange (loss) gain, net on the condensed
consolidated statements of operations and comprehensive income. The gains and losses on our forward exchange contracts and put option contracts generally offset losses and gains on the assets, liabilities, and transactions economically hedged and,
accordingly, generally do not subject us to the risk of significant accounting losses.

[0001193125-15-031475:mdna:69]
We had foreign currency assets and liabilities in
Thai baht and RMB as follows:

[0001193125-15-031475:mdna:70]
|  |  | As of December 26, 2014 |  |  | As of June 27, 2014 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 443,087 |  |  | $ | 13,472 |  |  |  | 56.2 |  |  |  | 1,536,887 |  |  | $ | 47,318 |  |  |  | 79.6 |  |
| RMB |  |  | 64,272 |  |  |  | 10,504 |  |  |  | 43.8 |  |  |  | 74,813 |  |  |  | 12,156 |  |  |  | 20.4 |  |
| Total |  |  |  |  |  | $ | 23,976 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 59,474 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 830,098 |  |  | $ | 25,239 |  |  |  | 84.3 |  |  |  | 735,490 |  |  | $ | 22,644 |  |  |  | 81.1 |  |
| RMB |  |  | 25,181 |  |  |  | 4,709 |  |  |  | 15.7 |  |  |  | 32,512 |  |  |  | 5,283 |  |  |  | 18.9 |  |
| Total |  |  |  |  |  | $ | 29,948 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 27,927 |  |  |  | 100.0 |  |

[0001193125-15-031475:mdna:71]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other
current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and
liabilities denominated in the same currency in accordance with management’s policy. As of December 26, 2014 and June 27, 2014, there were $30.0 million and $15.0 million in put option contracts outstanding on the Thai baht
payables, respectively.

[0001193125-15-031475:mdna:72]
The RMB assets represent cash and cash equivalents, accounts receivable and other current assets. The RMB
liabilities represent trade accounts payable, accrued expenses and other payables. As of December 26, 2014 and June 27, 2014, we did not have any selling RMB to U.S. dollar forward or put option contracts.

[0001193125-15-031475:mdna:73]
As of December 26, 2014 and June 27, 2014, unrealized loss from the fair market value
of derivatives and unrealized gain from the fair market value of derivatives amounted to $(0.1) million and $0.1 million, respectively.

[0001193125-15-031475:mdna:74]
Currency Regulation and Dividend Distribution

[0001193125-15-031475:mdna:75]
[same as prior period, unchanged from 0001193125-14-398478:mdna:74]

[0001193125-15-031475:mdna:76]
[same as prior period, unchanged from 0001193125-14-398478:mdna:75]

[0001193125-15-031475:mdna:77]
[same as prior period, unchanged from 0001193125-14-398478:mdna:76]

[0001193125-15-031475:mdna:78]
[same as prior period, unchanged from 0001193125-14-398478:mdna:77]

[0001193125-15-031475:mdna:79]
Under the Exchange Rules, RMB is
freely convertible into foreign currencies for current account items, including the distribution of dividends, interest payments, trade and service-related foreign exchange transactions. However, conversion of RMB for capital account items, such as
direct investments, loans, security investments, and repatriation of investments, is still subject to the approval of SAFE.

[0001193125-15-031475:mdna:80]
Under the
Administration Rules, foreign-invested enterprises may only buy, sell, or remit foreign currencies at banks authorized to conduct foreign exchange business after providing valid commercial documents and relevant supporting documents and, in the case
of capital account item transactions, obtaining approval from SAFE. Capital investments by foreign-invested enterprises outside of the PRC are also subject to limitations, which include approvals by the Ministry of Commerce, SAFE, and the State
Development and Reform Commission.

[0001193125-15-031475:mdna:81]
Circular 142 regulates the conversion by a foreign-invested company of foreign currency into RMB
by restricting how the converted RMB may be used. Circular 142 requires that the registered capital of a foreign-invested enterprise settled in RMB converted from foreign currencies may only be used for purposes within the business scope approved by
the applicable governmental authority and may not be used for equity investments within the PRC. In addition, SAFE strengthened its oversight of the flow and use of the registered capital of foreign-invested enterprises settled in RMB converted from
foreign currencies. The use of such RMB capital may not be changed without SAFE’s approval and may not be used to repay RMB loans if the proceeds of such loans have not been used.

[0001193125-15-031475:mdna:82]
On January 5, 2007, SAFE promulgated the Detailed Rules for Implementing the Measures for the Administration on Individual Foreign
Exchange, or the Implementation Rules. Under the Implementation Rules, PRC citizens who are granted share options by an overseas publicly-listed company are required, through a PRC agent or PRC subsidiary of such overseas publicly-listed company, to
register with SAFE and complete certain other procedures.

[0001193125-15-031475:mdna:83]
In addition, the General Administration of Taxation has issued circulars
concerning employee share options. Under these circulars, our employees working in the PRC who exercise share options will be subject to PRC individual income tax. Our PRC subsidiary has obligations to file documents related to employee share
options with relevant tax authorities and withhold individual income taxes of those employees who exercise their share options.

[0001193125-15-031475:mdna:84]
Furthermore, our transfer of funds to our subsidiaries in Thailand and the PRC are each subject to approval by governmental authorities in
case of an increase in registered capital, or subject to registration with governmental authorities in case of a shareholder loan. These limitations on the flow of funds between our subsidiaries and us could restrict our ability to act in response
to changing market conditions.

[0001193125-15-031475:mdna:85]
[same as prior period, unchanged from 0001193125-14-398478:mdna:84]

[0001193125-15-031475:mdna:86]
[same as prior period, unchanged from 0001193125-14-398478:mdna:85]

[0001193125-15-031475:mdna:87]
Throughout the period of our
operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption is currently available to us from
July 2010 through June 2015 on income generated from the manufacture of products at Pinehurst Building 5 and from July 2012 through June 2020 on income generated from the manufacture of products at Pinehurst Building 6. Such preferential
tax treatment is contingent on various factors, including the export of

[0001193125-15-031475:mdna:88]
our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years. Additionally, in December
2011, the Thailand Revenue Department announced a reduction in corporate income tax rates for tax periods beginning on or after January 1, 2012. As a result of the announcement, corporate income tax rates for our Thai subsidiary were reduced
from 30% in fiscal year 2012 to 23% in fiscal year 2013, and 20% in fiscal year 2014 and fiscal year 2015. In November 2014, the Thailand Revenue Department announced an extension of the 20% corporate income tax rate at 20% for another year to
fiscal year 2016.

[0001193125-15-031475:mdna:89]
Our subsidiary in China had been granted a tax privilege to reduce its corporate income tax rate from 25% to 15% but
the privilege expired on December 31, 2013. Currently, we are preparing an application to renew this tax privilege and plan to submit it in fiscal year 2015. However, there can be no assurances that such tax privilege will be renewed.

[0001193125-15-031475:mdna:90]
Critical Accounting Policies and Use of Estimates

[0001193125-15-031475:mdna:91]
We prepare our condensed consolidated financial statements in conformity with U.S. GAAP, which requires us to make estimates and assumptions
that affect the reported amounts of assets and liabilities, the disclosure of contingent liabilities on the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the financial reporting
period. We continually evaluate these estimates and assumptions based on the most recently available information, our own historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results
form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Because the use of estimates is an integral component of the financial reporting process, actual results could
differ from those estimates. Some of our accounting policies require higher degrees of judgment than others in their application. We consider the policies discussed below to be critical to an understanding of our condensed consolidated financial
statements, as their application places the most significant demands on our management’s judgment.

[0001193125-15-031475:mdna:92]
Our critical accounting policies
are disclosed in our Annual Report on Form 10-K for the fiscal year ended June 27, 2014. During the second quarter of fiscal year 2015, we invested in marketable securities. The accounting policy is
disclosed in Note 4 of our unaudited condensed consolidated financial statements.

[0001193125-15-031475:mdna:93]
[same as prior period, unchanged from 0001193125-14-398478:mdna:92]

[0001193125-15-031475:mdna:94]
The following table sets forth a summary of our unaudited condensed consolidated statements of operations and comprehensive income. Note that
period-to-period comparisons of operating results should not be relied upon as indicative of future performance.

[0001193125-15-031475:mdna:95]
| (amount in thousands) |  | Three Months Ended |  |  | Six Months Ended |  |
|  | December 26,2014 |  |  | December 27,2013 |  |  | December 26,2014 |  |  | December 27,2013 |  |
| Revenues |  | $ | 188,353 |  |  | $ | 178,562 |  |  | $ | 377,678 |  |  | $ | 350,113 |  |
| Cost of revenues |  |  | (167,292 | ) |  |  | (158,032 | ) |  |  | (336,111 | ) |  |  | (310,938 | ) |
| Gross profit |  |  | 21,061 |  |  |  | 20,530 |  |  |  | 41,567 |  |  |  | 39,175 |  |
| Selling, general and administrative expenses |  |  | (10,314 | ) |  |  | (6,913 | ) |  |  | (19,051 | ) |  |  | (13,607 | ) |
| Expenses related to reduction in workforce |  |  | (1,153 | ) |  |  | — |  |  |  | (1,153 | ) |  |  | — |  |
| Income related to flooding, net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 6,597 |  |
| Operating income |  |  | 9,594 |  |  |  | 13,617 |  |  |  | 21,363 |  |  |  | 32,165 |  |
| Interest income |  |  | 324 |  |  |  | 338 |  |  |  | 698 |  |  |  | 702 |  |
| Interest expense |  |  | (117 | ) |  |  | (188 | ) |  |  | (250 | ) |  |  | (394 | ) |
| Foreign exchange gain (loss), net |  |  | 83 |  |  |  | (788 | ) |  |  | (23 | ) |  |  | 300 |  |
| Other (expense) income |  |  | (134 | ) |  |  | 187 |  |  |  | (31 | ) |  |  | 371 |  |
| Income before income taxes |  |  | 9,750 |  |  |  | 13,166 |  |  |  | 21,757 |  |  |  | 33,144 |  |
| Income tax (expense) benefit |  |  | (1,024 | ) |  |  | 1,373 |  |  |  | (1,995 | ) |  |  | 592 |  |
| Net income |  |  | 8,726 |  |  |  | 14,539 |  |  |  | 19,762 |  |  |  | 33,736 |  |
| Other comprehensive loss |  |  | (486 | ) |  |  | — |  |  |  | (486 | ) |  |  | — |  |
| Net comprehensive income |  | $ | 8,240 |  |  | $ | 14,539 |  |  | $ | 19,276 |  |  | $ | 33,736 |  |

[0001193125-15-031475:mdna:96]
The following table sets forth a summary of our unaudited condensed consolidated statements of
operations and comprehensive income as a percentage of total revenues for the periods indicated.

[0001193125-15-031475:mdna:97]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 26,2014 |  |  | December 27,2013 |  |  | December 26,2014 |  |  | December 27,2013 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (88.8 | ) |  |  | (88.5 | ) |  |  | (89.0 | ) |  |  | (88.8 | ) |
| Gross profit |  |  | 11.2 |  |  |  | 11.5 |  |  |  | 11.0 |  |  |  | 11.2 |  |
| Selling, general and administrative expenses |  |  | (5.5 | ) |  |  | (3.9 | ) |  |  | (5.1 | ) |  |  | (3.9 | ) |
| Expenses related to reduction in workforce |  |  | (0.6 | ) |  |  | — |  |  |  | (0.3 | ) |  |  | — |  |
| Income related to flooding, net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1.9 |  |
| Operating income |  |  | 5.1 |  |  |  | 7.6 |  |  |  | 5.6 |  |  |  | 9.2 |  |
| Interest income |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.2 |  |
| Interest expense |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | (0.1 | ) |
| Foreign exchange gain (loss), net |  |  | 0.0 |  |  |  | (0.4 | ) |  |  | (0.0 | ) |  |  | 0.1 |  |
| Other (expense) income |  |  | (0.1 | ) |  |  | 0.1 |  |  |  | (0.0 | ) |  |  | 0.1 |  |
| Income before income taxes |  |  | 5.1 |  |  |  | 7.4 |  |  |  | 5.7 |  |  |  | 9.5 |  |
| Income tax (expense) benefit |  |  | (0.5 | ) |  |  | 0.8 |  |  |  | (0.5 | ) |  |  | 0.2 |  |
| Net income |  |  | 4.6 |  |  |  | 8.2 |  |  |  | 5.2 |  |  |  | 9.7 |  |
| Other comprehensive loss |  |  | (0.3 | ) |  |  | — |  |  |  | (0.2 | ) |  |  | — |  |
| Net comprehensive income |  |  | 4.3 | % |  |  | 8.2 | % |  |  | 5.0 | % |  |  | 9.7 | % |

[0001193125-15-031475:mdna:98]
[same as prior period, unchanged from 0001193125-14-398478:mdna:97]

[0001193125-15-031475:mdna:99]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands) |  | December 26,2014 |  |  | December 27,2013 |  |  | December 26,2014 |  |  | December 27,2013 |  |
| Optical communications |  | $ | 133,807 |  |  | $ | 129,742 |  |  | $ | 269,063 |  |  | $ | 254,270 |  |
| Lasers, sensors and other |  |  | 54,546 |  |  |  | 48,820 |  |  |  | 108,615 |  |  |  | 95,843 |  |
| Total |  | $ | 188,353 |  |  | $ | 178,562 |  |  | $ | 377,678 |  |  | $ | 350,113 |  |

[0001193125-15-031475:mdna:100]
We operate and internally manage a single operating segment. As such, discrete information with respect to
separate product lines and segments is not accumulated.

[0001193125-15-031475:mdna:101]
Comparison of Three and Six Months Ended December 26, 2014 with Three and Six Months
Ended December 27, 2013

[0001193125-15-031475:mdna:102]
[same as prior period, unchanged from 0001193125-14-398478:mdna:101]

[0001193125-15-031475:mdna:103]
Our total revenues increased by $9.8 million, or 5.5%, to $188.4 million for the three months ended December 26, 2014, compared
with $178.6 million for the three months ended December 27, 2013. This increase was primarily due to an increase in customers’ demand for both optical and non-optical communications manufacturing services during the three months ended
December 26, 2014. Revenues from optical communications products represented 71.0% of our total revenues for the three months ended December 26, 2014, compared to 72.7% for the three months ended December 27, 2013.

[0001193125-15-031475:mdna:104]
Our total revenues increased by $27.6 million, or 7.9%, to $377.7 million for the six months ended December 26, 2014, compared
with $350.1 million for the six months ended December 27, 2013. This increase was primarily due to an increase in customers’ demand for both optical and non-optical communications manufacturing services during the six months ended
December 26, 2014. Revenues from optical communications products represented 71.2% of our total revenues for the six months ended December 26, 2014, compared to 72.6% for the six months ended December 27, 2013.

[0001193125-15-031475:mdna:105]
[same as prior period, unchanged from 0001193125-14-398478:mdna:103]

[0001193125-15-031475:mdna:106]
Our cost of revenues increased by $9.3 million, or 5.9%, to $167.3 million, or 88.8% of total revenues, for the three months ended
December 26, 2014, compared with $158.0 million, or 88.5% of total revenues, for the three months ended December 27, 2013. This increase was primarily due to an increase in production costs which were in-line with an increase in
revenues during the three months ended December 26, 2014. Cost of revenues also included share-based compensation expense of $0.4 million for the three months ended December 26, 2014, compared with $0.3 million for the three
months ended December 27, 2013.

[0001193125-15-031475:mdna:107]
Our cost of revenues increased by $25.2 million, or 8.1%, to $336.1 million, or 89.0% of
total revenues, for the six months ended December 26, 2014, compared with $310.9 million, or 88.8% of total revenues, for the six months ended December 27, 2013. This increase was primarily due to an increase in production costs which
were in-line with an increase in revenues during the six months ended December 26, 2014. Cost of revenues also included share-based compensation expense of $0.7 million for the six months ended December 26, 2014, compared with
$0.6 million for the six months ended December 27, 2013.

[0001193125-15-031475:mdna:108]
[same as prior period, unchanged from 0001193125-14-398478:mdna:105]

[0001193125-15-031475:mdna:109]
Our gross profit increased by $0.5 million, or 2.6%, to $21.1 million, or 11.2% of total revenues, for the three months ended
December 26, 2014, compared with $20.5 million, or 11.5% of total revenues, for the three months ended December 27, 2013. Our gross profit increased by $2.4 million, or 6.0%, to $41.6 million, or 11.0% of total revenues, for the
six months ended December 26, 2014, compared with $39.2 million, or 11.2% of total revenues, for the six months ended December 27, 2013.

[0001193125-15-031475:mdna:110]
The slight decrease in gross profit margin during the three and six months ended December 26, 2014, compared with the three and six
months ended December 27, 2013, was related to an increase in production costs during the three and six months ended December 26, 2014.

[0001193125-15-031475:mdna:111]
[same as prior period, unchanged from 0001193125-14-398478:mdna:107]

[0001193125-15-031475:mdna:112]
Our
SG&A expenses increased by $3.4 million, or 49.2%, to $10.3 million, or 5.5% of total revenues, for the three months ended December 26, 2014, compared with $6.9 million, or 3.9% of total revenues, for the three months ended
December 27, 2013. Our SG&A expenses increased in absolute dollars and as a percentage of revenue due primarily to $2.5 million of investigation costs relating to our Audit Committee investigation concerning various accounting cut-off
issues in fiscal year 2014 and an increase in executive salaries and other benefits of $0.5 million. We also recorded share-based compensation charges of $1.6 million for the three months ended December 26, 2014, compared with
$1.2 million for the three months ended December 27, 2013.

[0001193125-15-031475:mdna:113]
Our SG&A expenses increased by $5.4 million, or 40.0%, to
$19.1 million, or 5.0% of total revenues, for the six months ended December 26, 2014, compared with $13.6 million, or 3.9% of total revenues, for the six months ended December 27, 2013. Our SG&A expenses increased in absolute
dollars and as a percentage of revenue due primarily to $4.1 million of investigation costs relating to our Audit Committee investigation concerning various accounting cut-off issues in fiscal year 2014 and an increase in executive salaries and
other benefits of $0.7 million. We also recorded share-based compensation charges of $3.1 million for the six months ended December 26, 2014, compared with $2.5 million for the six months ended December 27, 2013.

[0001193125-15-031475:mdna:114]
Expenses related to reduction in workforce

[0001193125-15-031475:mdna:115]
During the second quarter of fiscal 2015, we implemented a reduction in workforce and incurred expenses of approximately $1.2 million
which represented severance and benefits costs associated with the termination of approximately 100 employees in accordance with contractual obligations and local regulations.

[0001193125-15-031475:mdna:116]
[same as prior period, unchanged from 0001193125-14-398478:mdna:109]

[0001193125-15-031475:mdna:117]
In the three months ended December 26, 2014 and December 27, 2013 and the six months ended December 26, 2014, we did not have
income related to flooding. In the six months ended December 27, 2013, we recognized $6.6 million of income related to flooding, which consisted of an interim payment from our insurers against our claim for owned and customer-owned
inventory losses.

[0001193125-15-031475:mdna:118]
[same as prior period, unchanged from 0001193125-14-398478:mdna:111]

[0001193125-15-031475:mdna:119]
Our operating income decreased by $4.1 million to $9.6 million, or 5.1% of total revenues, for the three months ended
December 26, 2014, compared with $13.6 million, or 7.6% of total revenues, for the three months ended December 27, 2013.

[0001193125-15-031475:mdna:120]
Our operating income decreased by $10.8 million to $21.4 million, or 5.7% of total revenues, for the six months ended
December 26, 2014, compared with $32.2 million, or 9.2% of total revenues, for the six months ended December 27, 2013.

[0001193125-15-031475:mdna:121]
[same as prior period, unchanged from 0001193125-14-398478:mdna:113]

[0001193125-15-031475:mdna:122]
Our
interest income remained flat at $0.3 million for the three months ended December 26, 2014, compared with $0.3 million for the three months ended December 27, 2013. Our interest income remained flat at $0.7 million for the six
months ended December 26, 2014, compared with $0.7 million for the six months ended December 27, 2013.

[0001193125-15-031475:mdna:123]
Interest
expense.

[0001193125-15-031475:mdna:124]
Our interest expense decreased by $0.1 million to $0.1 million for the three months ended December 26, 2014,
compared with $0.2 million for the three months ended December 27, 2013. Our interest expense decreased by $0.1 million to $0.3 million for the six months ended December 26, 2014, compared with $0.4 million for the six
months ended December 27, 2013. These decreases were due to a decrease in our average long-term loan balances resulting from repayment during the fourth quarter of fiscal year 2014.

[0001193125-15-031475:mdna:125]
[same as prior period, unchanged from 0001193125-14-398478:mdna:117]

[0001193125-15-031475:mdna:126]
We recorded income before income taxes of $9.8 million and $21.8 million for the three and six months ended December 26, 2014,
respectively, compared with income before income taxes of $13.2 million and $33.1 million for the three and six months ended December 27, 2013, respectively.

[0001193125-15-031475:mdna:127]
[same as prior period, unchanged from 0001193125-14-398478:mdna:119]

[0001193125-15-031475:mdna:128]
Our
provision for income tax reflects an effective tax rate of 10.5% for the three months ended December 26, 2014, compared with an effective tax rate of (10.4)% for the three months ended December 27, 2013. The increase was primarily due to
the reversal of liabilities for uncertain tax positions, including accrued interest of $1.5 million during the three months ended December 27, 2013 and an increase in deferred tax assets of $0.6 million as a result of the increase in
the income tax rate of our subsidiary in China from 15% in the three months ended December 27, 2013 to 25% in the three months ended December 26, 2014 due to the expiration of a tax privilege.

[0001193125-15-031475:mdna:129]
Our provision for income tax reflects an effective tax rate of 9.2% for the six months ended December 26, 2014, compared with an
effective tax rate of (1.8)% for the six months ended December 27, 2013. The increase was primarily due to the reversal of liabilities for uncertain tax positions, including accrued interest of $1.5 million during the six months ended
December 27, 2013 and an increase in deferred tax assets of $0.6 million as a result of the increase in the income tax rate of our subsidiary in China from 15% in the six months ended December 27, 2013 to 25% in the six months ended
December 26, 2014 due to the expiration of a tax privilege, as well as the fact that we had lower net income during the six months ended December 26, 2014 from income related to flooding of $6.6 million that was not subject to income
tax.

[0001193125-15-031475:mdna:130]
Net income.

[0001193125-15-031475:mdna:131]
We
recorded net income of $8.7 million, or 4.6% of total revenues, for the three months ended December 26, 2014, compared with $14.5 million, or 8.2% of total revenues, for the three months ended December 27, 2013.

[0001193125-15-031475:mdna:132]
We recorded net income of $19.8 million, or 5.2% of total revenues, for the six months ended December 26, 2014, compared with
$33.7 million, or 9.7% of total revenues, for the six months ended December 27, 2013.

[0001193125-15-031475:mdna:133]
Other comprehensive loss

[0001193125-15-031475:mdna:134]
We recorded other comprehensive loss related to accumulated net unrealized losses on available-for-sale investments of $0.5 million for
the three and six months ended December 26, 2014.

[0001193125-15-031475:mdna:135]
[same as prior period, unchanged from 0001193125-14-398478:mdna:123]

[0001193125-15-031475:mdna:136]
[same as prior period, unchanged from 0001193125-14-398478:mdna:124]

[0001193125-15-031475:mdna:137]
We primarily finance our operations through cash flow from operations. As of December 26, 2014 and December 27, 2013, we had cash,
cash equivalents, and marketable securities of $253.3 million and $180.1 million, respectively and outstanding debt of $13.5 million and $24.1 million, respectively.

[0001193125-15-031475:mdna:138]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of
three months or less, are placed with banks and other financial institutions. The weighted average interest rate on our cash and cash equivalents for the three and six months ended December 26, 2014 was 0.7% and 0.6%, respectively and for the
three and six months ended December 27, 2013 was 0.9% and 1.0%, respectively.

[0001193125-15-031475:mdna:139]
Our cash investments are made in accordance with an
investment policy approved by the Audit Committee of our Board of Directors. In general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds 3 year. Our
investments in fixed income securities are primarily classified as available-for-sale securities and are recorded at fair value. The cost of securities sold is based on the specific identification method. Unrealized gains and losses on
available-for-sale securities are recorded as other comprehensive income (loss) and are reported as a separate component of shareholders’ equity.

[0001193125-15-031475:mdna:140]
As of June 27, 2014, all claims that we submitted to our insurance companies for flood related losses have been settled. For the three
months ended December 27, 2013, we did not recognize any income related to flooding. For the six months ended December 27, 2013, we recognized $6.6 million of income related to flooding which consisted of an interim payment from our
insurers against our claim for owned and customer-owned inventory losses.

[0001193125-15-031475:mdna:141]
In the six months ended December 27, 2013, we fulfilled
our obligations to a customer in accordance with the settlement agreement entered into during the third quarter of fiscal 2013 by making a final cash payment to such customer of $3.7 million and by transferring equipment, with an aggregate
value of $2.3 million, to such customer. Also, during the six months ended December 27, 2013, we fulfilled our obligations to a customer’s insurers in accordance with the settlement agreement entered into during the fourth quarter of
fiscal 2013 by making a final payment of $2.2 million. We also entered into other flood-related settlements of $0.1 million during the six months ended December 27, 2013.

[0001193125-15-031475:mdna:142]
We believe that our current cash and cash equivalents, marketable securities, cash flow from operations, and funds available through our
credit facility will be sufficient to meet our working capital and capital expenditure needs for the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II,
Item 1A of this Quarterly Report on Form 10-Q.

[0001193125-15-031475:mdna:143]
We believe that our current
manufacturing capacity is sufficient to meet anticipated production requirements for at least the next 12 months. We maintain a long-term credit facility associated with construction of production facilities at our Pinehurst campus in Thailand
that will come due within the next 27 months. We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay this obligation.

[0001193125-15-031475:mdna:144]
The following table shows our net cash provided by operating activities, net cash used in investing activities and net cash used in financing
activities for the periods indicated:

[0001193125-15-031475:mdna:145]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 26,2014 |  |  | December 27,2013 |  |
| Net cash provided by operating activities |  | $ | 30,601 |  |  | $ | 36,804 |  |
| Net cash used in investing activities |  | $ | (147,433 | ) |  | $ | (4,197 | ) |
| Net cash used in financing activities |  | $ | (4,624 | ) |  | $ | (1,465 | ) |
| Net (decrease) increase in cash and cash equivalents |  | $ | (121,456 | ) |  | $ | 31,142 |  |
| Cash and cash equivalents, beginning of period |  | $ | 233,477 |  |  | $ | 149,716 |  |
| Cash and cash equivalents, end of period |  | $ | 111,971 |  |  | $ | 180,058 |  |

[0001193125-15-031475:mdna:146]
[same as prior period, unchanged from 0001193125-14-398478:mdna:133]

[0001193125-15-031475:mdna:147]
Net cash provided by operating activities decreased by $6.2 million, or 16.9%, to $30.6 million for the six months ended
December 26, 2014, compared with net cash provided by operating activities of $36.8 million for the six months ended December 27, 2013. This decrease was primarily due to a decrease of $13.9 million in net income from operations
resulting from a decrease in proceeds from insurers for inventory losses related to flooding of $6.6 million, as well as an increase in SG&A expenses of $5.5 million and a decrease of $6.0 million in flood-related liabilities to third
parties.

[0001193125-15-031475:mdna:148]
[same as prior period, unchanged from 0001193125-14-398478:mdna:135]

[0001193125-15-031475:mdna:149]
Net cash used in investing activities increased by $143.2 million, or 3,409.5%, to $147.4 million for the six months ended
December 26, 2014, compared with net cash used in investing activities of $4.2 million for the six months ended December 27, 2013. This increase in net cash used in investing activities was primarily due to an increase of
$142.1 million in available-for-sale securities and an increase of $1.2 million in purchase of property, plant, and equipment to support our operations.

[0001193125-15-031475:mdna:150]
[same as prior period, unchanged from 0001193125-14-398478:mdna:137]

[0001193125-15-031475:mdna:151]
Net
cash used in financing activities increased by $3.2 million, or 215.6%, to $4.6 million for the six months ended December 26, 2014, compared with $1.5 million for the six months ended December 27, 2013. This increase in net
cash used in financing activities was primarily due to the payment of debt issuance costs of $1.7 million from our credit facility agreement and a decrease of $3.1 million in proceeds from the issuance of ordinary shares under employee
share option plans, offset by a decrease in repayment of the Company’s long-term loans of $1.8 million due to the payment to extinguish one of the long-term loan contracts in April 2014.

[0001193125-15-031475:mdna:152]
[same as prior period, unchanged from 0001193125-14-398478:mdna:139]

[0001193125-15-031475:mdna:153]
We have not entered into any financial guarantees or other commitments to guarantee the payment obligations of any third parties. In addition,
we have not entered into any derivative contracts that are not reflected in our condensed consolidated financial statements. Furthermore, we do not have any retained or contingent interest in assets transferred to an unconsolidated entity that
serves as credit, liquidity or market risk support to such entity. We also do not have any variable interest in any unconsolidated entity that provides financing, liquidity, market risk or credit support to us or engages in leasing, hedging or
research and development services with us.

[0001193125-15-031475:mdna:154]
[same as prior period, unchanged from 0001193125-14-398478:mdna:141]

[0001193125-15-031475:mdna:155]
See Note 2 of Notes to Unaudited Condensed Consolidated Financial Statements for recent accounting pronouncements that could have an
effect on us.
