# FN MD&A — 0001193125-20-223682


## mdna

[0001193125-20-223682:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS. |

[0001193125-20-223682:mdna:2]
|  | • |  | our goals and strategies; |

[0001193125-20-223682:mdna:3]
|  | • |  | our and our customers’ estimates regarding future revenues, operating results, expenses, capital requirements and liquidity; |

[0001193125-20-223682:mdna:4]
|  | • |  | our expectation that the portion of our future revenues attributable to customers in regions outside of North America will decrease compared with the portion of those revenues for fiscal year 2020; |

[0001193125-20-223682:mdna:5]
|  | • |  | our expectation that we will incur incremental costs of revenue as a result of our planned expansion of our business into new geographic markets; |

[0001193125-20-223682:mdna:6]
|  | • |  | our expectation that our fiscal year 2021 selling, general and administrative (“SG&A”) expenses will increase compared to our fiscal year 2020 SG&A expenses; |

[0001193125-20-223682:mdna:7]
|  | • |  | our expectation that our employee costs will increase in Thailand and the People’s Republic of China (“PRC”); |

[0001193125-20-223682:mdna:8]
|  | • |  | our future capital expenditures and our needs for additional financing; |

[0001193125-20-223682:mdna:9]
|  | • |  | the expansion of our manufacturing capacity, including into new geographies; |

[0001193125-20-223682:mdna:10]
|  | • |  | the growth rates of our existing markets and potential new markets; |

[0001193125-20-223682:mdna:11]
|  | • |  | our ability, and the ability of our customers and suppliers, to respond successfully to technological or industry developments; |

[0001193125-20-223682:mdna:12]
|  | • |  | our expectations regarding the potential impact of the COVID-19 pandemic on our business, financial condition and results of operations; |

[0001193125-20-223682:mdna:13]
|  | • |  | our suppliers’ estimates regarding future costs; |

[0001193125-20-223682:mdna:14]
|  | • |  | our ability to increase our penetration of existing markets and to penetrate new markets; |

[0001193125-20-223682:mdna:15]
|  | • |  | our plans to diversify our sources of revenues; |

[0001193125-20-223682:mdna:16]
|  | • |  | our plans to execute acquisitions; |

[0001193125-20-223682:mdna:17]
|  | • |  | trends in the optical communications, industrial lasers, and sensors markets, including trends to outsource the production of components used in those markets; |

[0001193125-20-223682:mdna:18]
|  | • |  | our ability to attract and retain a qualified management team and other qualified personnel and advisors; and |

[0001193125-20-223682:mdna:19]
|  | • |  | competition in our existing and new markets. |

[0001193125-20-223682:mdna:20]
to revise or publicly release the results of any revision to these forward-looking statements. Given these risks and uncertainties, readers are cautioned not to place undue reliance on such forward-looking statements. “We,” “us” and “our” refer to Fabrinet and its subsidiaries.

[0001193125-20-223682:mdna:21]
Overview

[0001193125-20-223682:mdna:22]
For an overview of our business, see Part I – ITEM 1. BUSINESS.

[0001193125-20-223682:mdna:23]
Fiscal Years

[0001193125-20-223682:mdna:24]
We utilize a 
52-53
 week fiscal year ending on the Friday in June closest to June 30. Fiscal year 2020 ended on June 26, 2020 and consisted of 52 weeks. Fiscal year 2019 ended on June 28, 2019 and consisted of 52 weeks. Fiscal year 2018 ended on June 29, 2018 and consisted of 52 weeks.

[0001193125-20-223682:mdna:25]
Recent Developments Related to 
COVID-19

[0001193125-20-223682:mdna:26]
In the quarter ended March 27, 2020, the effects of the global 
COVID-19
 pandemic impacted us in several ways and created various challenges. At the onset of the pandemic, our PRC subsidiary, which manufactures custom optics components for us and other customers at its facility in Fuzhou, China, experienced a prolonged temporary closure following its customary 
eight-day
 Chinese Lunar New Year holiday in January 2020. In accordance with the Chinese government’s official efforts to mitigate the spread of 
COVID-19,
 our PRC subsidiary, along with other businesses in various parts of the country, delayed resumption of operations following the holiday closures for approximately two weeks. Furthermore, because of the restrictions in place on travel in China during this period, many of our employees were unable to return from their holiday travel as planned, resulting in fewer than 90% of our employees being able to return to work at our PRC subsidiary before early March. Our other global manufacturing facilities also have been affected by various government restrictions put in place to slow the spread of 
COVID-19.
 In Thailand, the government declared a national state of emergency effective March 26, 2020 and required the closure of various businesses, in particular retail establishments, and passed measures restricting movement and activities in Thailand. While our operations in Thailand have not been suspended, we have implemented a number of safety protocols to allow our operations in our facilities there to continue in accordance with government regulations. With the exception of our facility in Santa Clara, California, which closed for approximately one week beginning in late March before reopening in early April as a previously classified “essential business,” our facilities in the U.S., including in New Jersey, and in the U.K. have remained open while adhering to the local government restrictions and orders implemented in March 2020, including

[0001193125-20-223682:mdna:27]
“shelter-in-place”

[0001193125-20-223682:mdna:28]
orders and social distancing guidelines.

[0001193125-20-223682:mdna:29]
The health and well-being of our employees continues to be our top priority. Over the past several months, we have implemented significant precautionary measures throughout our worldwide operations to ensure our employees and their families remain safe, such as mandatory temperature detection at building entrances, rigorous and regular facility and equipment disinfection, and mandatory personal protective equipment protocols, including (1) the wearing of face masks throughout our factories at all times, (2) distributing our employees across shifts to better maintain safe personal distances, (3) isolating incoming parts and materials for a week or more prior to unpacking, or applying extreme heat to them to kill potential viruses, (4) directing our 
non-factory
 personnel to work remotely, and (5) restricting all 
non-employee
 visits to our campuses.

[0001193125-20-223682:mdna:30]
During the six months ended June 26, 2020, we also experienced a shift in the demand for our services, with some customers canceling, decreasing or delaying orders and other customers accelerating and increasing orders. However, the most significant effect of 
COVID-19
 on our operations has been the disruption of our supply chain, including significant fluctuations in the availability of parts and materials necessary to manufacture our products for our customers. While we were able to mitigate some of these issues by quickly identifying and securing alternative sources, these mitigation efforts, combined with our employee safety initiatives, negatively impacted our gross margins due to the associated costs and expenses.

[0001193125-20-223682:mdna:31]
Given the unprecedented global, human, and economic impact of 
COVID-19,
 the extraordinary economic short-term uncertainty, and the evolving and differing national strategies for dealing with 
COVID-19,
 it is extremely challenging to provide forward-looking disclosure. Despite the uncertainty and concern about the global economy and the health of various industries, we believe it important to share our considerations as we continue to assess the impacts of 
COVID-19
 as they relate to our business in the future:

[0001193125-20-223682:mdna:32]
|  | • |  | With work-from-home protocols in place around the world, global demand for internet bandwidth has grown and we believe it will continue to grow. Because the next-generation telecom and datacom products we manufacture for our customers are important to expand network capacity, we believe this will have a positive impact on our business in the long-term. |

[0001193125-20-223682:mdna:33]
|  | • |  | While we believe that the long-term growth outlook for the markets we serve has not been significantly impacted, in the short-term we are likely to continue to see regional downward demand adjustments for products we manufacture for our customers, especially if the COVID-19 outbreak intensifies or returns in various geographic areas as happened at the end of our third fiscal quarter. Moreover, we believe the markets for other products we manufacture, such as the industrial lasers and automotive markets, are likely to see reduced demand in a prolonged economic downturn. |

[0001193125-20-223682:mdna:34]
|  | • |  | We expect we will continue to experience disruptions in our supply chain and the availability of parts and materials will continue to fluctuate, especially if the COVID-19 outbreak intensifies or returns in various geographic areas. However, we believe we can mitigate these disruptions by continuing to identify and secure alternative sources. |

[0001193125-20-223682:mdna:35]
|  | • |  | A significant portion of our costs are variable, and because of this, we can adjust manufacturing costs relatively quickly to respond to the changing demand of our customers. However, because parts and materials account for the largest portion of our costs, in combination with the supply chain issues noted above and, to a lesser extent, the expenses associated with our commitment to the safety and health protocols implemented across our global operations, our gross margins will continue to be negatively affected for the foreseeable future, and at least into the first half of fiscal year 2021. |

[0001193125-20-223682:mdna:36]
|  | • |  | The safety and health of our employees is and will remain a key priority, and we will continue to follow robust safety protocols in all of our facilities. |

[0001193125-20-223682:mdna:37]
|  | • |  | Given our $488.1 million in cash, cash equivalents and short-term investments, and our total debt of approximately $51.8 million, as of June 26, 2020, we believe we are in a solid position from a capital and financial resources perspective. We expect that current cash and cash equivalent balances and short-term investments, and cash flows that are generated from operations will be sufficient to meet our domestic and international working capital needs and other capital and liquidity requirements for at least the next 12 months. |

[0001193125-20-223682:mdna:38]
Revenues

[0001193125-20-223682:mdna:39]
We believe our ability to expand our relationships with existing customers and attract new customers is due to a number of factors, including our broad range of complex engineering and manufacturing service offerings, flexible 
low-cost
 manufacturing platform, process optimization capabilities, advanced supply chain management, excellent customer service, and experienced management team. Although we expect the prices we charge for our manufactured products to decrease over time (partly as a result of competitive market forces), we still believe we will be able to maintain favorable pricing for our services because of our ability to reduce cycle time, adjust our product mix by focusing on more complicated products, improve product quality and yields, and reduce material costs for the products we manufacture. We believe these capabilities have enabled us to help our OEM customers reduce their manufacturing costs while maintaining or improving the design, quality, reliability, and delivery times for their products.

[0001193125-20-223682:mdna:40]
Revenues, by percentage, from individual customers representing 10% or more of our total revenues is set forth in Note 23 of our audited consolidated financial statements. Because we depend upon a small number of

[0001193125-20-223682:mdna:41]
41

[0001193125-20-223682:mdna:42]
customers for a significant percentage of our total revenues, a reduction in orders from, a loss of, or any other adverse actions by, any one of these customers would reduce our revenues and could have a material adverse effect on our business, operating results and share price. Moreover, our customer concentration increases the concentration of our accounts receivable and payment default by any of our key customers will negatively impact our exposure. Many of our existing and potential customers have substantial debt burdens, have experienced financial distress or have static or declining revenues, all of which may be exacerbated by the continued uncertainty in the global economies. Certain customers have gone out of business or have been acquired or announced their withdrawal from segments of the optics market. We generate significant accounts payable and inventory for the services that we provide to our customers, which could expose us to substantial and potentially unrecoverable costs if we do not receive payment from our customers. Therefore, any financial difficulties that our key customers experience could materially and adversely affect our operating results and financial condition by generating charges for inventory write-offs, provisions for doubtful accounts, and increases in working capital requirements due to increased days inventory and in accounts receivable.

[0001193125-20-223682:mdna:43]
Furthermore, reliance on a small number of customers gives those customers substantial purchasing power and leverage in negotiating contracts with us. In addition, although we enter into master supply agreements with our customers, the level of business to be transacted under those agreements is not guaranteed. Instead, we are awarded business under those agreements on a

[0001193125-20-223682:mdna:44]
project-by-project

[0001193125-20-223682:mdna:45]
basis. Some of our customers have at times significantly reduced or delayed the volume of manufacturing services that they order from us. If we are unable to maintain our relationships with our existing significant customers, our business, financial condition and operating results could be harmed.

[0001193125-20-223682:mdna:46]
Revenues by Geography

[0001193125-20-223682:mdna:47]
We generate revenues from three geographic regions: North America, Asia-Pacific, and Europe. Revenues are attributed to a particular geographic area based on the

[0001193125-20-223682:mdna:48]
bill-to-location

[0001193125-20-223682:mdna:49]
of our customers, notwithstanding that our customers may ultimately ship their products to end customers in a different geographic region. The substantial majority of our revenues are derived from our manufacturing facilities in Asia-Pacific.

[0001193125-20-223682:mdna:50]
The percentage of our revenues generated from a

[0001193125-20-223682:mdna:51]
bill-to-location

[0001193125-20-223682:mdna:52]
outside of North America decreased from 52.3% in fiscal year 2019 to 49.4% in fiscal year 2020, which was partially due to a decrease in sales to our customers in Asia-Pacific by 4.7%. Based on the short- and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside of North America will decrease as compared with the portion of revenues attributable to such customers during fiscal year 2020.

[0001193125-20-223682:mdna:53]
The following table presents percentages of total revenues by geographic regions:

[0001193125-20-223682:mdna:54]
|  |  | Years Ended |  |
|  |  | June 26, 2020 |  |  | June 28, 2019 |  |  | June 29, 2018 |  |
| North America |  |  | 50.6 | % |  |  | 47.7 | % |  |  | 46.9 | % |
| Asia-Pacific |  |  | 33.7 |  |  |  | 38.4 |  |  |  | 37.8 |  |
| Europe |  |  | 15.7 |  |  |  | 13.9 |  |  |  | 15.3 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-20-223682:mdna:55]
Our Contracts

[0001193125-20-223682:mdna:56]
We enter into supply agreements with our customers which generally have an initial term of up to three years, subject to automatic renewals for subsequent 
one-year
 terms unless expressly terminated. Although there are no minimum purchase requirements in our supply agreements, our customers provide us with rolling forecasts of their demand requirements. Our supply agreements generally include provisions for pricing and

[0001193125-20-223682:mdna:57]
periodic review of pricing, consignment of our customer’s unique production equipment to us, and the sharing of benefits from cost-savings derived from our efforts. We are generally required to purchase materials, which may include long lead-time materials and materials that are subject to minimum order quantities and/or 
non-cancelable
 or 
non-returnable
 terms, to meet the stated demands of our customers. After procuring materials, we manufacture products for our customers based on purchase orders that contain terms regarding product quantities, delivery locations and delivery dates. Our customers generally are obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by our customers within a specified period of time, or that are no longer required due to a product’s cancellation or

[0001193125-20-223682:mdna:58]
end-of-life,

[0001193125-20-223682:mdna:59]
are typically designated as excess or obsolete inventory under our contracts. Once materials are designated as either excess or obsolete inventory, our customers are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

[0001193125-20-223682:mdna:60]
Cost of Revenues

[0001193125-20-223682:mdna:61]
The key components of our cost of revenues are material costs, employee costs, and infrastructure-related costs. Material costs generally represent the majority of our cost of revenues. Several of the materials we require to manufacture products for our customers are customized for their products and often sourced from a single supplier or in some cases, our own subsidiaries. Shortages from sole-source suppliers due to yield loss, quality concerns and capacity constraints, among other factors, may increase our expenses and negatively impact our gross profit margin or total revenues in a given quarter. Material costs include scrap material. Historically, scrap rate diminishes during a product’s life cycle due to process, fixturing and test improvement and optimization.

[0001193125-20-223682:mdna:62]
A second significant element of our cost of revenues is employee costs, including indirect employee costs related to design, configuration and optimization of manufacturing processes for our customers, quality testing, materials testing and other engineering services; and direct costs related to our manufacturing employees. Direct employee costs include employee salaries, insurance and benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a lesser extent, costs to recruit, train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand, the PRC and the United Kingdom, the fluctuation of the Thai baht, Chinese Renminbi (“RMB”) and Pound Sterling (“GBP”) against our functional currency, the U.S. dollar, and our ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention and asset utilization.

[0001193125-20-223682:mdna:63]
Our infrastructure costs are comprised of depreciation, utilities, facilities management and overhead costs. Most of our facility leases are long-term agreements. Our depreciation costs include buildings and fixed assets, primarily at our Pinehurst and Chonburi campuses in Thailand, and capital equipment located at each of our manufacturing locations.

[0001193125-20-223682:mdna:64]
During fiscal years 2020, 2019 and 2018, discretionary merit-based bonus awards were made to our 
non-executive
 employees. Charges included in cost of revenues for bonus awards to 
non-executive
 employees were $4.6 million, $3.9 million and $3.5 million for fiscal years 2020, 2019 and 2018, respectively.

[0001193125-20-223682:mdna:65]
Share-based compensation expense included in cost of revenues was $6.1 million, $5.7 million and $6.8 million for fiscal years 2020, 2019 and 2018, respectively.

[0001193125-20-223682:mdna:66]
We expect to incur incremental costs of revenue as a result of our planned expansion into new geographic markets, though we are not able to determine the amount of these incremental expenses.

[0001193125-20-223682:mdna:67]
Selling, General and Administrative Expenses

[0001193125-20-223682:mdna:68]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative and other support personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other general expenses not related to cost of revenues. In fiscal year 2021, we expect our SG&A expenses will increase compared with our fiscal year 2020 SG&A expenses.

[0001193125-20-223682:mdna:69]
The compensation committee of our board of directors approved a fiscal year 2020 executive incentive plan with quantitative objectives based solely on achieving certain revenue targets and 
non-U.S.
 GAAP operating margin targets for fiscal year 2020. Bonuses under the fiscal year 2020 executive incentive plan are payable after the end of fiscal year 2020. In fiscal year 2019, the compensation committee approved a fiscal year 2019 executive incentive plan with quantitative objectives that were based solely on achieving certain revenue targets and 
non-U.S.
 GAAP gross margin targets for fiscal year 2019. In the three months ended September 29, 2019, the compensation committee awarded bonuses to our executive employees for Company achievements of performance under our fiscal 2019 executive incentive plan. Discretionary merit-based bonus awards are also available to our 
non-executive
 employees and payable on a quarterly basis.

[0001193125-20-223682:mdna:70]
Charges included in SG&A expenses for bonus distributions to 
non-executive
 and executive employees were $4.1 million, $3.7 million and $0.5 million for fiscal years 2020, 2019 and 2018, respectively.

[0001193125-20-223682:mdna:71]
Share-based compensation expense included in SG&A expenses was $16.1 million, $11.5 million and $15.8 million for fiscal years 2020, 2019 and 2018, respectively.

[0001193125-20-223682:mdna:72]
Additional Financial Disclosures

[0001193125-20-223682:mdna:73]
Foreign Exchange

[0001193125-20-223682:mdna:74]
As a result of our international operations, we are exposed to foreign exchange risk arising from various currency exposures primarily with respect to the Thai baht. Although a majority of our total revenues is denominated in U.S. dollars, a substantial portion of our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rate between the Thai baht and the U.S. dollar has fluctuated substantially in recent years and may continue to fluctuate substantially in the future. We report our financial results in U.S. dollars and our results of operations have been and could in the future be negatively impacted if the Thai baht appreciates against the U.S. dollar. Smaller portions of our expenses are incurred in a variety of other currencies, including RMB, GBP, Canadian dollars, Euros, and Japanese yen, the appreciation of which may also negatively impact our financial results.

[0001193125-20-223682:mdna:75]
In order to manage the risks arising from fluctuations in foreign currency exchange rates, we use derivative instruments. We may enter into foreign currency exchange forward or option contracts to manage foreign currency exposures associated with certain assets and liabilities and other forecasted foreign currency transactions and may designate these instruments as hedging instruments. The forward and put option contracts generally have maturities of up to 12 months. All foreign currency exchange contracts are recognized in the consolidated balance sheets at fair value. Gain or loss on our forward and put option contracts generally offset the assets, liabilities, and transactions economically hedged.

[0001193125-20-223682:mdna:76]
We had foreign currency denominated assets and liabilities in Thai baht, RMB and GBP as follows:

[0001193125-20-223682:mdna:77]
|  |  | As of June 26, 2020 |  |  | As of June 28, 2019 |  |
| (amount in thousands, except percentages) |  | Foreign Currency |  |  | $ |  |  | % |  |  | Foreign Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 667,955 |  |  | $ | 21,617 |  |  |  | 41.8 |  |  |  | 664,860 |  |  | $ | 21,628 |  |  |  | 60.0 |  |
| RMB |  |  | 158,060 |  |  |  | 22,402 |  |  |  | 43.3 |  |  |  | 53,393 |  |  |  | 7,767 |  |  |  | 21.5 |  |
| GBP |  |  | 6,220 |  |  |  | 7,726 |  |  |  | 14.9 |  |  |  | 5,270 |  |  |  | 6,682 |  |  |  | 18.5 |  |
| Total |  |  |  |  |  | $ | 51,745 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 36,077 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 2,102,392 |  |  | $ | 68,039 |  |  |  | 89.5 |  |  |  | 1,961,972 |  |  | $ | 63,825 |  |  |  | 90.0 |  |
| RMB |  |  | 42,586 |  |  |  | 6,036 |  |  |  | 8.0 |  |  |  | 26,373 |  |  |  | 3,836 |  |  |  | 5.4 |  |
| GBP |  |  | 1,545 |  |  |  | 1,919 |  |  |  | 2.5 |  |  |  | 2,598 |  |  |  | 3,294 |  |  |  | 4.6 |  |
| Total |  |  |  |  |  | $ | 75,994 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 70,955 |  |  |  | 100.0 |  |

[0001193125-20-223682:mdna:78]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of June 26, 2020, there was $126.0 million in foreign currency forward contracts and option contracts outstanding on the Thai baht payables. As of June 28, 2019, there was $72.0 million in foreign currency forward contracts outstanding on the Thai baht payables.

[0001193125-20-223682:mdna:79]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of June 26, 2020 and June 28, 2019, we did not have any derivative contracts denominated in RMB.

[0001193125-20-223682:mdna:80]
The GBP assets represent cash, trade accounts receivable, inventory and property, plant and equipment. The GBP liabilities represent trade accounts payable and other payables. As of June 26, 2020 and June 28, 2019, we did not have any derivative contracts denominated in GBP.

[0001193125-20-223682:mdna:81]
For fiscal years 2020 and 2019, we recorded an unrealized loss of $1.2 million and an unrealized gain of $4.8 million, respectively, related to derivatives that are not designated as hedging instruments in the consolidated statements of operations and comprehensive income.

[0001193125-20-223682:mdna:82]
Currency Regulation and Dividend Distribution

[0001193125-20-223682:mdna:83]
Foreign exchange regulation in the PRC is primarily governed by the following rules:

[0001193125-20-223682:mdna:84]
|  | • |  | Foreign Currency Administration Rules, as amended on August 5, 2008, or the Exchange Rules; |

[0001193125-20-223682:mdna:85]
|  | • |  | Administration Rules of the Settlement, Sale and Payment of Foreign Exchange (1996), or the Administration Rules; and |

[0001193125-20-223682:mdna:86]
|  | • |  | Notice on Perfecting Practices Concerning Foreign Exchange Settlement Regarding the Capital Contribution by Foreign-invested Enterprises, as promulgated by the State Administration of Foreign Exchange (“SAFE”), on August 29, 2008, or Circular 142. |

[0001193125-20-223682:mdna:87]
Under the Exchange Rules, RMB is freely convertible into foreign currencies for current account items, including the distribution of dividends, interest payments, trade and service-related foreign exchange transactions. However, conversion of RMB for capital account items, such as direct investments, loans, security investments and repatriation of investments, is still subject to the approval of SAFE.

[0001193125-20-223682:mdna:88]
Under the Administration Rules, foreign-invested enterprises may only buy, sell, or remit foreign currencies at banks authorized to conduct foreign exchange business after providing valid commercial documents and relevant supporting documents and, in the case of capital account item transactions, obtaining approval from SAFE. Capital investments by foreign-invested enterprises outside of the PRC are also subject to limitations, which include approvals by the Ministry of Commerce, SAFE and the State Development and Reform Commission.

[0001193125-20-223682:mdna:89]
Circular 142 regulates the conversion by a foreign-invested company of foreign currency into RMB by restricting how the converted RMB may be used. Circular 142 requires that the registered capital of a foreign-invested enterprise settled in RMB converted from foreign currencies may only be used for purposes within the business scope approved by the applicable governmental authority and may not be used for equity investments within the PRC. In addition, SAFE strengthened its oversight of the flow and use of the registered capital of foreign-invested enterprises settled in RMB converted from foreign currencies. The use of such RMB capital may not be changed without SAFE’s approval and may not be used to repay RMB loans if the proceeds of such loans have not been used.

[0001193125-20-223682:mdna:90]
On January 5, 2007, SAFE promulgated the Detailed Rules for Implementing the Measures for the Administration on Individual Foreign Exchange, or the Implementation Rules. Under the Implementation Rules, PRC citizens who are granted share options by an overseas publicly-listed company are required, through a PRC agent or PRC subsidiary of such overseas publicly-listed company, to register with SAFE and complete certain other procedures.

[0001193125-20-223682:mdna:91]
In addition, the General Administration of Taxation has issued circulars concerning employee share options. Under these circulars, our employees working in the PRC who exercise share options will be subject to PRC individual income tax. Our PRC subsidiary has obligations to file documents related to employee share options with relevant tax authorities and withhold individual income taxes of those employees who exercise their share options.

[0001193125-20-223682:mdna:92]
Furthermore, our transfer of funds to our subsidiaries in Thailand and the PRC are each subject to approval by governmental authorities in case of an increase in registered capital, or subject to registration with governmental authorities in case of a shareholder loan. These limitations on the flow of funds between our subsidiaries and us could restrict our ability to act in response to changing market conditions.

[0001193125-20-223682:mdna:93]
Income Tax

[0001193125-20-223682:mdna:94]
Our effective tax rate is a function of the mix of tax rates in the various jurisdictions in which we do business. We are domiciled in the Cayman Islands. Under the current laws of the Cayman Islands, we are not subject to tax in the Cayman Islands on income or capital gains until March 6, 2039.

[0001193125-20-223682:mdna:95]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption on income generated from projects to manufacture certain products at our Chonburi campus is currently available to us through June 2026. Similar preferential tax treatment was available to us through June 2020 with respect to products manufactured at our Pinehurst campus. After June 2020, 50% of our income generated from products manufactured at our Pinehurst campus will be exempted from tax through June 2025. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted. Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001193125-20-223682:mdna:96]
With respect to our U.S. subsidiaries, the Tax Cuts and Jobs Act (“Tax Reform Act”) enacted on December 22, 2017 provided for significant changes to U.S. tax law. Among other provisions, the Tax Reform Act reduced the U.S. corporate income tax rate to 21%, which is the current rate for our U.S. subsidiaries.

[0001193125-20-223682:mdna:97]
During fiscal year 2019, we completed our assessment of the income tax effects resulting from the Tax Reform Act and concluded that no cumulative remeasurement adjustments were required.

[0001193125-20-223682:mdna:98]
Critical Accounting Policies and Use of Estimates

[0001193125-20-223682:mdna:99]
We prepare our consolidated financial statements in conformity with U.S. GAAP, which requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent liabilities on the date of the consolidated financial statements and the reported amounts of revenues and expenses during the financial reporting period. We continually evaluate these estimates and assumptions based on the most recently available information, our own historical experience and on various other assumptions that we believe to be reasonable under the circumstances. The evaluation results form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Because the use of estimates is an integral component of the financial reporting process, actual results could differ from those estimates. Some of our accounting policies require higher degrees of judgment than others in their application. We consider the policies discussed below to be critical to an understanding of our consolidated financial statements, as their application places the most significant demands on our management’s judgment.

[0001193125-20-223682:mdna:100]
A quantitative sensitivity analysis is provided where such information is reasonably available, can be reliably estimated, and provides material information to investors. The amounts used to assess sensitivity are included for illustrative purposes only and do not represent management’s predictions of variability.

[0001193125-20-223682:mdna:101]
Our critical accounting policies and the adoption of new accounting policies are disclosed in Note 2 – Summary of significant accounting policies. There were no changes to our accounting policies other than the adoption of Leases (Topic 842), Derivatives and Hedging (Topic 815) and Goodwill impairment (ASU 
2017-04).

[0001193125-20-223682:mdna:102]
Revenue Recognition

[0001193125-20-223682:mdna:103]
On June 30, 2018, we adopted ASC 606 using the modified retrospective method, which was applied to those contracts which were not completed as of June 29, 2018. The modified retrospective method required us to recognize the cumulative effect of the adoption of ASC 606, for all contracts with customers, to the opening balance of equity at June 30, 2018.

[0001193125-20-223682:mdna:104]
We derive total revenues primarily from the assembly of products under supply agreements with our customers and the fabrication of customized optics and glass. We recognize revenue relating to contracts that depict the transfer of promised goods or services to customers in an amount reflecting the consideration to which we expect to be entitled in exchange for such goods or services. In order to meet this requirement, we apply the following five steps: (1) identify the contract with a customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract, and (5) recognize revenue when a performance obligation is satisfied. Revenue is recognized net of any taxes collected from customers, which is subsequently remitted to governmental authorities.

[0001193125-20-223682:mdna:105]
A performance obligation is a contractual promise to transfer a distinct good or service to the customer. In contracts with multiple performance obligations, we identify each performance obligation and evaluate whether the performance obligation is distinct within the context of the contract at contract inception. The majority of our contracts have a single performance obligation, as the promise to transfer the individual goods or services is not separately identifiable from other promises under the contracts and, therefore, is not distinct.

[0001193125-20-223682:mdna:106]
Sales of finished goods

[0001193125-20-223682:mdna:107]
We manufacture products that are customized to customers’ specifications; however, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for over time recognition are not met. On evaluation of the

[0001193125-20-223682:mdna:108]
contracts, we identified that there were no contractual rights to bill profit for work in progress in the event of a contract termination, which is expected to be infrequent. Further, in limited circumstances, contracts provide for substantive acceptance by the customer, which results in the deferral of revenue until formal notice of acceptance is received from the customer. Judgment may be required in determining if an acceptance clause provides for substantive acceptance.

[0001193125-20-223682:mdna:109]
Certain customers may request us to store finished products at our warehouse where customers bear risks of loss themselves. In these instances, we receive a written request from the customer asking us to hold the inventory at our warehouse and refrain from using the ordered goods to fulfill other customer orders. In these situations, revenue is only recognized when the completed goods are ready for shipment and transferred to our warehouse.

[0001193125-20-223682:mdna:110]
Customers generally are obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by customers within a specified period of time, or are no longer required due to a product’s cancellation or

[0001193125-20-223682:mdna:111]
end-of-life,

[0001193125-20-223682:mdna:112]
are typically designated as excess or obsolete inventory under our contracts. Once materials are designated as either excess or obsolete inventory, customers are typically required to purchase such inventory from us even if the customer has chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

[0001193125-20-223682:mdna:113]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. In determining the net consideration to which we expect to be entitled, we evaluate whether the price is subject to refund or adjustment. We generally do not grant return privileges, except for in the case of defective products during the warranty period. We generally provide a warranty of between one to five years on any given product. These standard warranties are assurance-type warranties, and we do not offer any services in addition to the assurance that the product will continue to work as specified.

[0001193125-20-223682:mdna:114]
The sales price is not considered to be fixed or determinable until all contingencies related to the sale have been resolved. We recognize revenue net of rebates and other similar allowances. Revenues are recognized only if these estimates can be reasonably and reliably determined. We base our estimates on historical results taking into consideration the type of customer, the type of transaction and the specifics of each arrangement.

[0001193125-20-223682:mdna:115]
Services

[0001193125-20-223682:mdna:116]
We provide services for customers that are related to our manufacturing activities. In many cases, although the nature of work performed is that of a service, revenue is only recognizable upon shipment of the product because the customer has specific requirements as to how many items can be shipped at any given point in time, i.e. at

[0001193125-20-223682:mdna:117]
point-in-time.

[0001193125-20-223682:mdna:118]
The related costs are expensed as incurred.

[0001193125-20-223682:mdna:119]
Long-Lived Assets

[0001193125-20-223682:mdna:120]
We review property, plant and equipment for impairment on a quarterly basis or when events or changes in circumstances indicate the carrying amount of an asset may not be recoverable. An impairment loss is recognized when the carrying amount of a long-lived asset or assets group exceeds its fair value. Recoverability of property and equipment is measured by comparing carrying amount to the projected undiscounted cash flows the property and equipment are expected to generate. If such assets are considered to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the property and equipment exceeds its fair value.

[0001193125-20-223682:mdna:121]
Allowance for Doubtful Accounts

[0001193125-20-223682:mdna:122]
We perform ongoing credit evaluations of our customers’ financial condition and make provisions for doubtful accounts based on the outcomes of these credit evaluations. We evaluate the collectability of our

[0001193125-20-223682:mdna:123]
accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections, and the age of past due receivables. Unanticipated changes in the liquidity or financial position of our customers may require additional provisions for doubtful accounts. Under our specific identification method, it is not practical to assess the sensitivity of our estimates.

[0001193125-20-223682:mdna:124]
Inventory Valuation

[0001193125-20-223682:mdna:125]
Our inventory is stated at the lower of cost (on a 
first-in,

[0001193125-20-223682:mdna:126]
first-out
 basis) or market value. Our industry is characterized by rapid technological change, short-term customer commitments, and rapid changes in demand. We make provisions for estimated excess and obsolete inventory based on regular reviews of inventory quantities on hand on a quarterly basis and the latest forecasts of product demand and production requirements from our customers. If actual market conditions or our customers’ product demands are less favorable than those projected, additional provisions may be required. In addition, unanticipated changes in liquidity or the financial positions of our customers or changes in economic conditions may require additional provisions for inventory due to our customers’ inability to fulfill their contractual obligations. During fiscal year 2020 and fiscal year 2019, a change of 10% for excess and obsolete materials, based on product demand and production requirements from our customers, would have affected our net income by approximately $0.2 million and $0.2 million, respectively.

[0001193125-20-223682:mdna:127]
Deferred Income Taxes

[0001193125-20-223682:mdna:128]
Our deferred income tax assets represent temporary differences between the carrying amount and the tax basis of existing assets and liabilities that will result in deductible and payable amounts in future years, including net operating loss carry forwards. Based on estimates, the carrying value of our net deferred tax assets assumes that it is more likely than not that we will be able to generate sufficient future taxable income in certain tax jurisdictions to realize these deferred income tax assets. Our judgments regarding future profitability may change depending on future market conditions, changes in U.S. or international tax laws, or other factors. If these estimates and related assumptions change in the future, we may be required to increase or decrease our valuation allowance against the deferred tax assets, resulting in additional or lesser income tax expense. During fiscal year 2018, one of our subsidiaries in the U.S. generated taxable income sufficient for the utilization of loss carryforwards due to better operating performance and effective control of operating expenses and management determined that it was more likely than not that future taxable income would be sufficient to allow the benefit of the loss to be realized. As of June 29, 2018, we reversed certain deferred tax assets valuation allowance as management expected it was more likely than not that we would realize profits in subsequent fiscal years so that the loss carryforwards could be partially utilized. Consequently, as of June 28, 2019, we have assessed and set up a partial valuation allowance for the deferred tax assets at the same level as in fiscal year 2018. However, in fiscal year 2020, such subsidiary in the U.S. generated net operating loss and management expected that such subsidiary would continue to have net operating losses in the foreseeable future; therefore, management believes it is more likely than not that all of the deferred tax assets of such subsidiary will not be utilized. Thus, a full valuation allowance of $2.1 million for the deferred tax assets was set up as of June 26, 2020.

[0001193125-20-223682:mdna:129]
During fiscal year 2020, our subsidiary in the U.K. also generated net operating loss and management expected that such subsidiary would continue to have net operating losses in the foreseeable future; therefore, management believes it is more likely than not that all of the deferred tax assets of such subsidiary will not be utilized. Thus, a full valuation allowance of $1.6 million for the deferred tax assets was set up as of June 26, 2020.

[0001193125-20-223682:mdna:130]
We assess tax positions in a previously filed tax return or a position expected to be taken in a future tax return that is reflected in measuring current or deferred income tax assets and liabilities for interim or annual periods, based on the technical merits of the position. We apply a “more likely than not” standard (i.e., a likelihood greater than 50 percent), in accordance with the authoritative guidance, and recognize a tax provision in the consolidated financial statements for an uncertain tax position that would not be sustained.

[0001193125-20-223682:mdna:131]
Share-Based Compensation

[0001193125-20-223682:mdna:132]
Awards granted, including share options, restricted share units and performance share units are accounted for by recognizing the cost of employee services received in exchange for awards of equity instruments, based on the fair value of those awards, in the consolidated financial statements over the requisite service period.

[0001193125-20-223682:mdna:133]
In determining the fair value of share option awards, we are required to make estimates of expected dividends to be issued, expected volatility of our shares, expected forfeitures of the awards, risk free interest rates for the expected terms of the awards and expected terms of the awards.

[0001193125-20-223682:mdna:134]
For accounting purposes only, the fair value of each option grant is estimated using the Black-Scholes-Merton option pricing model, which takes into account the following factors: (1) the exercise price of the options; (2) the fair value of the underlying ordinary shares; (3) the expected life of the options; (4) the expected volatility of the underlying ordinary shares; (5) the risk-free interest rate during the expected life of the options; and (6) the expected dividend yield of the underlying ordinary shares. However, these fair values are inherently uncertain and highly subjective.

[0001193125-20-223682:mdna:135]
The exercise price of the options is stated in the option agreements. The expected life of the options involves estimates of the anticipated timing of the exercise of the vested options. The expected volatility is based on the historical volatility of our share price. We have applied the U.S. Treasury Bill interest rate with a maturity date similar to the expected life of our options as the risk-free interest rate and assumed a dividend yield for periods when we paid dividends.

[0001193125-20-223682:mdna:136]
The fair value of restricted share units and performance share units are based on the market value of our ordinary shares on the date of grant.

[0001193125-20-223682:mdna:137]
The determination of our share-based compensation expense for both current and future periods requires the input of assumptions, including estimated forfeitures and the price volatility of the underlying ordinary shares. We estimate forfeitures based on past employee retention rates and our expectations of future retention rates, and we will prospectively revise our forfeiture rates based on actual history. Our share-based compensation expense may change based on changes to our actual forfeitures.

[0001193125-20-223682:mdna:138]
Intangibles

[0001193125-20-223682:mdna:139]
Intangibles are stated at historical cost less amortization. Amortization of customer relationships is calculated using the accelerated method as to reflect the pattern in which the economic benefits of the intangible assets are consumed. Amortization of other intangibles is calculated using the straight-line method.

[0001193125-20-223682:mdna:140]
Business acquisition

[0001193125-20-223682:mdna:141]
For the acquisition of our UK subsidiary, we allocated the fair value of purchase consideration to the assets acquired and liabilities assumed based on their fair values at the acquisition date. The allocation of consideration to the individual net assets has been finalized.

[0001193125-20-223682:mdna:142]
The acquired intangible assets, which consist of customer relationships and backlog, are recorded as intangibles in the consolidated balance sheets. The fair value of the acquired intangible assets was determined based on the multi-period excess earnings method. We review intangibles for impairment whenever changes or circumstances indicate the carrying amount may not be recoverable.

[0001193125-20-223682:mdna:143]
Goodwill

[0001193125-20-223682:mdna:144]
Goodwill arising from the acquisition is primarily attributable to the ability to expand future products and services and the assembled workforce. Goodwill is reviewed annually for impairment or more frequently

[0001193125-20-223682:mdna:145]
whenever changes or circumstances indicate the carrying amount of goodwill may not be recoverable. During the three months ended June 26, 2020, we performed annual goodwill impairment testing on our subsidiary in the U.K. and found that the carrying amount of the reporting unit exceeded its fair value. As a result, we recognized goodwill impairment loss of $3.5 million in selling, general and administrative expenses in the consolidated statements of operations and comprehensive income.

[0001193125-20-223682:mdna:146]
Results of Operations

[0001193125-20-223682:mdna:147]
The following table sets forth a summary of our consolidated statements of operations and comprehensive income. Note that

[0001193125-20-223682:mdna:148]
period-to-period

[0001193125-20-223682:mdna:149]
comparisons of operating results should not be relied upon as indicative of future performance.

[0001193125-20-223682:mdna:150]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26, 2020 |  |  | June 28, 2019 |  |  | June 29, 2018 |  |
| Revenues |  | $ | 1,641,836 |  |  | $ | 1,584,335 |  |  | $ | 1,371,925 |  |
| Cost of revenues |  |  | (1,455,731 | ) |  |  | (1,405,111 | ) |  |  | (1,218,513 | ) |
| Gross profit |  |  | 186,105 |  |  |  | 179,224 |  |  |  | 153,412 |  |
| Selling, general and administrative expenses |  |  | (68,374 | ) |  |  | (55,067 | ) |  |  | (57,812 | ) |
| Expenses related to reduction in workforce |  |  | (329 | ) |  |  | (1,516 | ) |  |  | (1,776 | ) |
| Operating income |  |  | 117,402 |  |  |  | 122,641 |  |  |  | 93,824 |  |
| Interest income |  |  | 7,592 |  |  |  | 6,699 |  |  |  | 3,925 |  |
| Interest expense |  |  | (3,044 | ) |  |  | (5,381 | ) |  |  | (3,606 | ) |
| Foreign exchange gain (loss), net |  |  | (3,797 | ) |  |  | 1,406 |  |  |  | (6,587 | ) |
| Other income (expense), net |  |  | 1,089 |  |  |  | 868 |  |  |  | 473 |  |
| Income before income taxes |  |  | 119,242 |  |  |  | 126,233 |  |  |  | 88,029 |  |
| Income tax expense |  |  | (5,763 | ) |  |  | (5,278 | ) |  |  | (3,862 | ) |
| Net income |  |  | 113,479 |  |  |  | 120,955 |  |  |  | 84,167 |  |
| Other comprehensive income (loss), net of tax |  |  | 1,239 |  |  |  | (1,129 | ) |  |  | (909 | ) |
| Net comprehensive income |  | $ | 114,718 |  |  | $ | 119,826 |  |  | $ | 83,258 |  |

[0001193125-20-223682:mdna:151]
The following table sets forth a summary of our consolidated statements of operations and comprehensive income as a percentage of total revenues for the periods indicated.

[0001193125-20-223682:mdna:152]
|  |  | Years Ended |  |
|  |  | June 26, 2020 |  |  | June 28, 2019 |  |  | June 29, 2018 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (88.7 | ) |  |  | (88.7 | ) |  |  | (88.8 | ) |
| Gross profit |  |  | 11.3 |  |  |  | 11.3 |  |  |  | 11.2 |  |
| Selling, general and administrative expenses |  |  | (4.2 | ) |  |  | (3.5 | ) |  |  | (4.2 | ) |
| Expenses related to reduction in workforce |  |  | (0.0 | ) |  |  | (0.1 | ) |  |  | (0.1 | ) |
| Operating income |  |  | 7.1 |  |  |  | 7.7 |  |  |  | 6.9 |  |
| Interest income |  |  | 0.5 |  |  |  | 0.4 |  |  |  | 0.3 |  |
| Interest expense |  |  | (0.2 | ) |  |  | (0.3 | ) |  |  | (0.3 | ) |
| Foreign exchange gain (loss), net |  |  | (0.2 | ) |  |  | 0.1 |  |  |  | (0.5 | ) |
| Other income (expense), net |  |  | 0.1 |  |  |  | 0.0 |  |  |  | 0.1 |  |
| Income before income taxes |  |  | 7.3 |  |  |  | 7.9 |  |  |  | 6.5 |  |
| Income tax expense |  |  | (0.4 | ) |  |  | (0.3 | ) |  |  | (0.3 | ) |
| Net income |  |  | 6.9 |  |  |  | 7.6 |  |  |  | 6.2 |  |
| Other comprehensive income (loss), net of tax |  |  | 0.1 |  |  |  | 0.0 |  |  |  | (0.1 | ) |
| Net comprehensive income |  |  | 7.0 | % |  |  | 7.6 | % |  |  | 6.1 | % |

[0001193125-20-223682:mdna:153]
The following table sets forth our revenues by end market for the periods indicated.

[0001193125-20-223682:mdna:154]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26, 2020 |  |  | June 28, 2019 |  |  | June 29, 2018 |  |
| Optical communications |  | $ | 1,248,174 |  |  | $ | 1,184,936 |  |  | $ | 1,000,256 |  |
| Lasers, sensors, and other |  |  | 393,662 |  |  |  | 399,399 |  |  |  | 371,669 |  |
| Total |  | $ | 1,641,836 |  |  | $ | 1,584,335 |  |  | $ | 1,371,925 |  |

[0001193125-20-223682:mdna:155]
We operate and internally manage a single operating segment. As such, discrete information with respect to separate product lines and segments is not accumulated.

[0001193125-20-223682:mdna:156]
Comparison of Fiscal Year 2020 with Fiscal Year 2019

[0001193125-20-223682:mdna:157]
Total revenues.

[0001193125-20-223682:mdna:158]
Our total revenues increased by $57.5 million, or 3.6%, to $1.64 billion for fiscal year 2020, compared with $1.58 billion for fiscal year 2019. This increase was primarily due to an increase in customers’ demand for optical communications manufacturing services, particularly telecom manufacturing services, for fiscal year 2020. Revenues from optical communications products represented 76.0% of our total revenues for fiscal year 2020, compared with 74.8% for fiscal year 2019.

[0001193125-20-223682:mdna:159]
Cost of revenues

[0001193125-20-223682:mdna:160]
. Our cost of revenues increased by $50.6 million, or 3.6%, to $1.46 billion, or 88.7% of total revenues, for fiscal year 2020, compared with $1.41 billion, or 88.7% of total revenues, for fiscal year 2019. The increase in cost of revenues was primarily due to a proportional increase in sales volume.

[0001193125-20-223682:mdna:161]
Gross profit.

[0001193125-20-223682:mdna:162]
Our gross profit increased by $6.9 million, or 3.8%, to $186.1 million, or 11.3% of total revenues, for fiscal year 2020, compared with $179.2 million, or 11.3% of total revenues, for fiscal year 2019.

[0001193125-20-223682:mdna:163]
SG&A expenses

[0001193125-20-223682:mdna:164]
. Our SG&A expenses increased by $13.3 million, or 24.2%, to $68.4 million, or 4.2% of total revenues, for fiscal year 2020, compared with $55.1 million, or 3.5% of total revenues, for fiscal year 2019. Our SG&A expenses increased during fiscal year 2020, compared with fiscal year 2019, mainly due to by (1) an increase in share-based compensation expenses of $4.6 million, including $3.2 million from an increase in awards of performance share units and $1.4 million from an increase in awards of restricted share units; (2) a goodwill impairment loss related to our UK subsidiary of $3.5 million; (3) an increase in new business 
start-up
 costs incurred by our Israel and Thailand subsidiaries of $1.5 million; (4) an increase in severance liabilities expense of $0.9 million due to a change in labor protection law in Thailand in May 2019 that increased the required severance payment compensation for employees with 20 years of service from 300 days of wage to 400 days of wage; and (5) an increase in executive and management expenses of $0.4 million from bonuses and other benefits.

[0001193125-20-223682:mdna:165]
Operating income.

[0001193125-20-223682:mdna:166]
Our operating income decreased by $5.2 million to $117.4 million, or 7.1% of total revenues, for fiscal year 2020, compared with $122.6 million, or 7.7% of total revenues, for fiscal year 2019.

[0001193125-20-223682:mdna:167]
Interest income.

[0001193125-20-223682:mdna:168]
Our interest income increased by $0.9 million to $7.6 million for fiscal year 2020, compared with $6.7 million for fiscal year 2019. The increase was primarily due to an increase in the average balance of our outstanding cash and cash equivalents and short-term investments.

[0001193125-20-223682:mdna:169]
Interest expense.

[0001193125-20-223682:mdna:170]
Our interest expense decreased by $2.4 million to $3.0 million for fiscal year 2020, compared with $5.4 million for fiscal year 2019. The decrease was primarily due to lower unrealized loss from

[0001193125-20-223682:mdna:171]
mark-to-market

[0001193125-20-223682:mdna:172]
of interest rate swaps recognized to earnings as a result of applying cash flow hedge accounting in fiscal year 2020. In fiscal year 2020, there was unrealized loss from

[0001193125-20-223682:mdna:173]
mark-to-market

[0001193125-20-223682:mdna:174]
of interest rate swaps of $1.7 million recognized to earnings for the three months ended September 27, 2019, before applying cash flow hedge, as compared to an unrealized loss of $2.6 million for fiscal year 2019. In addition, there was amortization

[0001193125-20-223682:mdna:175]
of the fair value of interest rate swaps as of the hedge inception date of $1.2 million during fiscal year 2020 in relation to applying hedge accounting which results in a decrease in interest expense.

[0001193125-20-223682:mdna:176]
Foreign exchange gain (loss), net.

[0001193125-20-223682:mdna:177]
We recorded foreign exchange loss, net of $3.8 million for fiscal year 2020, compared with foreign exchange gain, net of $1.4 million for fiscal year 2019. The increase in foreign exchange loss was mainly due to an unrealized foreign exchange loss from

[0001193125-20-223682:mdna:178]
mark-to-market

[0001193125-20-223682:mdna:179]
of forward contracts of $1.2 million in fiscal year 2020, as compared to an unrealized foreign exchange gain from

[0001193125-20-223682:mdna:180]
mark-to-market

[0001193125-20-223682:mdna:181]
of forward contracts of $4.8 million in fiscal year 2019.

[0001193125-20-223682:mdna:182]
Income before income taxes.

[0001193125-20-223682:mdna:183]
We recorded income before income taxes of $119.2 million for fiscal year 2020, compared with $126.2 million for fiscal year 2019.

[0001193125-20-223682:mdna:184]
Income tax expense.

[0001193125-20-223682:mdna:185]
Our provision for income tax reflects an effective tax rate of 4.1% and 4.6% for fiscal year 2020 and fiscal year 2019, respectively. The decrease was primarily due to the fact that we had lower income subject to tax in fiscal year 2020, as compared to fiscal year 2019.

[0001193125-20-223682:mdna:186]
Net income.

[0001193125-20-223682:mdna:187]
We recorded net income of $113.5 million, or 6.9% of total revenues, for fiscal year 2020, compared with net income of $121.0 million, or 7.6% of total revenues, for fiscal year 2019.

[0001193125-20-223682:mdna:188]
Other comprehensive income (loss).

[0001193125-20-223682:mdna:189]
Our other comprehensive income increased by $2.4 million to $1.2 million for fiscal year 2020 compared with other comprehensive loss of $1.1 million for fiscal year 2019.

[0001193125-20-223682:mdna:190]
Comparison of Fiscal Year 2019 with Fiscal Year 2018

[0001193125-20-223682:mdna:191]
Total revenues.

[0001193125-20-223682:mdna:192]
Our total revenues increased by $212.4 million, or 15.5%, to $1.58 billion for fiscal year 2019, compared with $1.37 billion for fiscal year 2018. This increase was primarily due to an increase in customers’ demand for optical communications manufacturing services, particularly telecom manufacturing services, for fiscal year 2019. Revenues from optical communications products represented 74.8% of our total revenues for fiscal year 2019, compared with 72.9% for fiscal year 2018.

[0001193125-20-223682:mdna:193]
Cost of revenues

[0001193125-20-223682:mdna:194]
. Our cost of revenues increased by $186.6 million, or 15.3%, to $1.41 billion, or 88.7% of total revenues, for fiscal year 2019, compared with $1.22 billion, or 88.8% of total revenues, for fiscal year 2018. The increase in cost of revenues was primarily due to a proportional increase in sales volume.

[0001193125-20-223682:mdna:195]
Gross profit.

[0001193125-20-223682:mdna:196]
Our gross profit increased by $25.8 million, or 16.8%, to $179.2 million, or 11.3% of total revenues, for fiscal year 2019, compared with $153.4 million, or 11.2% of total revenues, for fiscal year 2018. The increase in gross profit percentage in fiscal year 2019 was due to higher revenue and fixed costs leverage.

[0001193125-20-223682:mdna:197]
SG&A expenses

[0001193125-20-223682:mdna:198]
. Our SG&A expenses decreased by $2.7 million, or 4.7%, to $55.1 million, or 3.5% of total revenues, for fiscal year 2019, compared with $57.8 million, or 4.2% of total revenues, for fiscal year 2018. Our SG&A expenses decreased during fiscal year 2019, compared with fiscal year 2018, mainly due to (1) a decrease in share-based compensation expenses of $4.3 million because we did not expect to achieve the 
pre-defined
 performance targets for vesting of certain performance-based restricted share units awarded under our 2017 Inducement Equity Incentive Plan and (2) a decrease in executive severance payments of $2.1 million and a decrease in key executive benefits of $1.8 million in connection with the transition of the Executive Chairman of our board of directors to 
non-executive
 Chairman during fiscal year 2018. The decrease was offset by (1) an increase of $2.4 million in executive cash bonuses under our fiscal year 2019 executive incentive plan due to our expectation that certain 
pre-defined
 revenue targets and 
non-U.S.
 GAAP gross margin targets would be achieved; (2) an increase in severance payment of $1.0 million in connection with 
non-executive
 management separations; (3) an increase in public company cost of $0.6 million; and (4) an increase in severance liability expense of $0.4 million due to an increase in headcount as well as a change in labor protection law in Thailand that increased the required severance payment compensation for employees with 20 or more years of service from 300 days of wage to 400 days of wage.

[0001193125-20-223682:mdna:199]
Operating income.

[0001193125-20-223682:mdna:200]
Our operating income increased by $28.8 million to $122.6 million, or 7.7% of total revenues, for fiscal year 2019, compared with $93.8 million, or 6.9% of total revenues, for fiscal year 2018.

[0001193125-20-223682:mdna:201]
Interest income.

[0001193125-20-223682:mdna:202]
Our interest income increased by $2.8 million to $6.7 million for fiscal year 2019, compared with $3.9 million for fiscal year 2018. The increase was primarily due to the higher weighted average interest rate compared to the same period in the last year and an increase in the average balance of our outstanding cash and cash equivalents and short-term investments.

[0001193125-20-223682:mdna:203]
Interest expense.

[0001193125-20-223682:mdna:204]
Our interest expense increased by $1.8 million to $5.4 million for fiscal year 2019, compared with $3.6 million for fiscal year 2018. The increase was due to (1) unrealized loss of $2.6 million from

[0001193125-20-223682:mdna:205]
mark-to-market

[0001193125-20-223682:mdna:206]
of interest rate swap related to our term loan; and (2) an increase of $0.5 million from increase in fixed interest rate from interest rate swap. The increase was offset by (1) the amortization and the write off of deferred debt issuance costs from loan borrowing paid up in fiscal year 2018 of $1.0 million; and (2) a decrease in loan commitment fee of $0.3 million.

[0001193125-20-223682:mdna:207]
Foreign exchange gain (loss), net.

[0001193125-20-223682:mdna:208]
We recorded foreign exchange gain, net of $1.4 million for fiscal year 2019, compared with foreign exchange loss, net of $6.6 million for fiscal year 2018. The foreign exchange gain for fiscal year 2019 was mainly due to unrealized gain of $4.8 million for

[0001193125-20-223682:mdna:209]
mark-to-market

[0001193125-20-223682:mdna:210]
of forward contracts related to hedging of Thai baht spending, compared to unrealized loss of $2.6 million in fiscal year 2018. Moreover, we recorded realized foreign exchange loss from receipts and payments of $4.6 million in fiscal year 2018.

[0001193125-20-223682:mdna:211]
Income before income taxes.

[0001193125-20-223682:mdna:212]
We recorded income before income taxes of $126.2 million for fiscal year 2019, compared with $88.0 million for fiscal year 2018.

[0001193125-20-223682:mdna:213]
Income tax expense.

[0001193125-20-223682:mdna:214]
Our provision for income tax reflects an effective tax rate of 4.6% for fiscal year 2019 and 5.0% for fiscal year 2018.

[0001193125-20-223682:mdna:215]
Net income.

[0001193125-20-223682:mdna:216]
We recorded net income of $121.0 million, or 7.6% of total revenues, for fiscal year 2019, compared with net income of $84.2 million, or 6.2% of total revenues, for fiscal year 2018.

[0001193125-20-223682:mdna:217]
Other comprehensive loss.

[0001193125-20-223682:mdna:218]
Our other comprehensive loss increased by $0.2 million to $1.1 million for fiscal year 2019 compared with $0.9 million for fiscal year 2018.

[0001193125-20-223682:mdna:219]
Liquidity and Capital Resources

[0001193125-20-223682:mdna:220]
Cash Flows and Working Capital

[0001193125-20-223682:mdna:221]
We primarily finance our operations through cash flow from operating activities. As of June 26, 2020 and June 28, 2019, we had cash, cash equivalents, and short-term investments of $488.1 million and $437.3 million, respectively, and outstanding debt of $51.7 million and $60.9 million, respectively.

[0001193125-20-223682:mdna:222]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted average interest rate on our cash and cash equivalents for fiscal year 2020, fiscal year 2019 and fiscal year 2018 was 1.8%, 1.9% and 0.8%, respectively.

[0001193125-20-223682:mdna:223]
Our cash investments are made in accordance with an investment policy approved by the audit committee of our board of directors. In general, our investment policy requires that securities purchased be rated A1, 
P-1,
 F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed income securities are primarily classified as

[0001193125-20-223682:mdna:224]
available-for-sale

[0001193125-20-223682:mdna:225]
and are recorded at fair value. The cost of securities sold is based on the specific identification method. Unrealized gains and losses on these securities are recorded as other comprehensive income (loss) and are reported as a separate component of shareholders’ equity.

[0001193125-20-223682:mdna:226]
During fiscal year 2020, (1) we paid off a term loan of $60.9 million under our previous credit facility agreement with Bank of America, (2) our subsidiary in Thailand drew down a new term loan of $60.9 million under a new credit facility agreement with the Bank of Ayudhya Public Company Limited, and (3) we repaid $9.1 million of the new term loan under the new credit facility agreement. As a result, as of June 26, 2020, we had a long-term borrowing of $51.7 million under our new credit facility agreement. (See Note 16 for further details.) We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held short-term investments of $262.7 million as of June 26, 2020.

[0001193125-20-223682:mdna:227]
We believe that our current cash and cash equivalents, short-term investments, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months following the filing of this Annual Report on Form 
10-K.
 Our ability to sustain our working capital position is subject to a number of risks that we discuss in Item 1A of this Annual Report on Form 
10-K.

[0001193125-20-223682:mdna:228]
We also believe that our current manufacturing capacity is sufficient to meet our anticipated production requirements for at least the next few quarters.

[0001193125-20-223682:mdna:229]
The following table shows our cash flows for the periods indicated:

[0001193125-20-223682:mdna:230]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26, 2020 |  |  | June 28, 2019 |  |  | June 29, 2018 |  |
| Net cash provided by operating activities |  | $ | 150,660 |  |  | $ | 147,394 |  |  | $ | 138,080 |  |
| Net cash used in investing activities |  | $ | (71,248 | ) |  | $ | (98,067 | ) |  | $ | (58,649 | ) |
| Net cash used in financing activities |  | $ | (35,305 | ) |  | $ | (23,223 | ) |  | $ | (54,106 | ) |
| Net increase in cash, cash equivalents and restricted cash |  | $ | 44,107 |  |  | $ | 26,104 |  |  | $ | 25,325 |  |
| Cash, cash equivalents and restricted cash, beginning of period |  | $ | 188,241 |  |  | $ | 161,433 |  |  | $ | 137,137 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 232,832 |  |  | $ | 188,241 |  |  | $ | 161,433 |  |

[0001193125-20-223682:mdna:231]
Operating Activities

[0001193125-20-223682:mdna:232]
Net cash provided by operating activities increased by $3.3 million, or 2.2%, to $150.7 million for fiscal year 2020, compared with net cash provided by operating activities of $147.4 million for fiscal year 2019 due to better working capital management. This increase in cash was primarily due to (1) an increase in share-based compensation of $5.0 million; (2) goodwill impairment loss in fiscal 2020 of $3.5 million; (3) an increase in cash receipts related to the timing of collection of trade accounts receivable of $1.2 million; and (4) an increase in depreciation and amortization of $0.9 million. These increases in cash were offset by a decrease in net income of $7.5 million.

[0001193125-20-223682:mdna:233]
Net cash provided by operating activities increased by $9.3 million, or 6.7%, to $147.4 million for fiscal year 2019, compared with net cash provided by operating activities of $138.1 million for fiscal year 2018 due to better working capital management. This increase was due to an increase in net income of $36.8 million and a decrease in cash paid to settle accounts payable of $35.3 million. These increases in cash were offset by a decrease in cash receipts related to the timing of collection of trade accounts receivable of $31.3 million, an increase in gain on exchange rate and fair value of derivative instruments of $11.2 million, an increase in ending inventories intended for sale in future quarters of $24.6 million and a decrease in share-based compensation of $5.4 million.

[0001193125-20-223682:mdna:234]
Investing Activities

[0001193125-20-223682:mdna:235]
Net cash used in investing activities decreased by $26.8 million, or 27.3 %, to $71.2 million for fiscal year 2020, compared with net cash used in investing activities of $98.1 million for fiscal year 2019. The decrease was primarily due to a net decrease in investment in short-term investments of $74.7 million, offset by funds provided

[0001193125-20-223682:mdna:236]
to a customer of $24.3 million to support the customer’s transfer of certain manufacturing operations from Berlin, Germany to our facilities in Thailand, which the customer has agreed to repay by September 30, 2020, and an increase of $23.5 million in the net movement of property, plant and equipment and intangible assets.

[0001193125-20-223682:mdna:237]
Net cash used in investing activities increased by $39.4 million, or 67.2 %, to $98.1 million for fiscal year 2019, compared with net cash used in investing activities of $58.6 million for fiscal year 2018. The increase was primarily due to a net increase in investment in short-term investments of $56.0 million, offset by a decrease of $16.5 million in the purchase of property, plant and equipment and intangible assets.

[0001193125-20-223682:mdna:238]
Financing Activities

[0001193125-20-223682:mdna:239]
Net cash used in financing activities increased by $12.1 million, or 52.0%, to $35.3 million for fiscal year 2020, compared with net cash used in financing activities of $23.2 million for fiscal year 2019. This increase was primarily due to (1) an increase in cash paid for the repurchase of ordinary shares of $15.3 million; (2) an increase of $5.9 million in net repayments of loans to banks; and (3) an increase in debt issuance costs payment of $0.2 million. These were offset by a decrease in cash paid for withholding tax related to net share settlement of restricted share units of $5.8 million and the release of restricted cash in connection with a business acquisition of $3.5 million in fiscal year 2019.

[0001193125-20-223682:mdna:240]
Net cash used in financing activities decreased by $30.9 million, or 57.1%, to $23.2 million for fiscal year 2019, compared with net cash used in financing activities of $54.1 million for fiscal year 2018. This decrease was primarily due to a decrease in cash paid for the repurchase of ordinary shares of $37.0 million and a decrease in cash paid for long-term loans of $8.0 million. These were offset by (1) an increase in cash paid for withholding tax related to net share settlement of restricted share units of $5.1 million, (2) a decrease in cash received from short-term loans from bank of $5.0 million, and (3) the release of restricted cash in connection with a business acquisition of $3.5 million.

[0001193125-20-223682:mdna:241]
Contractual Obligations

[0001193125-20-223682:mdna:242]
The following table sets forth certain of our contractual obligations as of June 26, 2020:

[0001193125-20-223682:mdna:243]
|  |  | Payments Due by Period |  |
| (amount in thousands) |  | Total |  |  | Less than 1 year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5 years |  |
| Long-term debt obligations |  | $ | 51,797 |  |  | $ | 12,188 |  |  | $ | 27,421 |  |  | $ | 12,188 |  |  | $ | — |  |
| Interest expense obligation (1) |  |  | 1,760 |  |  |  | 751 |  |  |  | 876 |  |  |  | 133 |  |  |  | — |  |
| Finance lease obligations |  |  | 100 |  |  |  | 100 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Operating lease obligations |  |  | 8,448 |  |  |  | 2,313 |  |  |  | 4,514 |  |  |  | 1,464 |  |  |  | 157 |  |
| Severance liabilities (2) |  |  | 54,218 |  |  |  | 1,284 |  |  |  | 3,183 |  |  |  | 4,726 |  |  |  | 45,025 |  |
| Provision for uncertain income tax position |  |  | 1,459 |  |  |  | 1,008 |  |  |  | 6 |  |  |  | 286 |  |  |  | 159 |  |
| Total |  | $ | 117,782 |  |  | $ | 17,644 |  |  | $ | 36,000 |  |  | $ | 18,797 |  |  | $ | 45,341 |  |

[0001193125-20-223682:mdna:244]
| (1) | Interest expense obligation reflects the interest rate on long-term debt obligation as of June 26, 2020. The interest rates ranged between 1.7% and 2.8%. For further discussion of long-term and short-term debt obligations, see Note 16 of our audited consolidated financial statements. |

[0001193125-20-223682:mdna:245]
| (2) | Severance liabilities as of June 26, 2020 are determined based on management assumptions and calculated as expected future cash flows basis. See Note 17 of our audited consolidated financial statements. |

[0001193125-20-223682:mdna:246]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable

[0001193125-20-223682:mdna:247]
exchange rate as of June 26, 2020) and $160.9 million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

[0001193125-20-223682:mdna:248]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a Term Loan Agreement pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company’s previous credit facility agreement with Bank of America, N.A.

[0001193125-20-223682:mdna:249]
The term loan accrues interest at 
3-month
 LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be 
re-borrowed.
 During the year ended June 26, 2020, the Company recorded $1.5 million of interest expense in connection with this term loan.

[0001193125-20-223682:mdna:250]
Any borrowings under the Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

[0001193125-20-223682:mdna:251]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt to equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of June 26, 2020, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

[0001193125-20-223682:mdna:252]
The events of default in the Term Loan Agreement include failure to pay amounts due under the Term Loan Agreement or the related finance documents when due, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

[0001193125-20-223682:mdna:253]
As of June 26, 2020, $51.7 million of the term loan was outstanding under the Credit Facility Agreement.

[0001193125-20-223682:mdna:254]
As of June 26, 2020, we also had certain operating lease arrangements in which the lease payments are calculated using the straight-line method. Our rental expenses under these leases were $2.1 million, $1.9 million and $1.8 million for fiscal year 2020, fiscal year 2019 and fiscal year 2018, respectively.

[0001193125-20-223682:mdna:255]
Capital Expenditures

[0001193125-20-223682:mdna:256]
The following table sets forth our capital expenditures, which include amounts for which payments have been accrued, for the periods indicated.

[0001193125-20-223682:mdna:257]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26, 2020 |  |  | June 28, 2019 |  |  | June 29, 2018 |  |
| Capital expenditures |  | $ | 51,317 |  |  | $ | 20,834 |  |  | $ | 30,535 |  |

[0001193125-20-223682:mdna:258]
Our capital expenditures for fiscal year 2020, fiscal year 2019 and fiscal year 2018 principally related to investment in our new facilities in Thailand and the U.S.. During fiscal year 2020, we purchased equipment to support the expansion of our manufacturing facilities in Thailand, the PRC and Israel. During fiscal year 2019, we purchased additional equipment to continue to support the expansion of our manufacturing facilities in Thailand. During fiscal year 2018, we purchased additional equipment to continue to support the expansion of our manufacturing facilities in Thailand and the U. K. During fiscal year 2021, we expect our capital expenditures to increase compared to fiscal year 2020 mainly related to investment in existing and new manufacturing facilities.

[0001193125-20-223682:mdna:259]
Off-Balance
 Sheet Commitments and Arrangements

[0001193125-20-223682:mdna:260]
As of June 26, 2020, we had an outstanding standby letter of credit of 6.0 million Euros related to our support of a customer with the transfer of certain manufacturing operations from Berlin, Germany to our facilities in Thailand. As of June 26, 2020, the standby letter of credit was backed by cash collateral of $7.4 million.

[0001193125-20-223682:mdna:261]
Recent Accounting Pronouncements

[0001193125-20-223682:mdna:262]
See Note 2 of the Notes to Consolidated Financial Statements for recent accounting pronouncements that could have an effect on us.
