# FN 10-K controls and the auditor's report


## auditors_report

[0001193125-20-223682:auditors_report:1]
REPORT OF INDEPENDENT REGISTERED PUBLIC ACCOUNTING FIRM

[0001193125-20-223682:auditors_report:2]
To the Board of Directors and Shareholders of Fabrinet

[0001193125-20-223682:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0001193125-20-223682:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Fabrinet and its subsidiaries (the Company ) as of June 26, 2020 and June 28, 2019, and the related consolidated statements of operations and comprehensive income, consolidated statements of changes in shareholders’ equity and consolidated statements of cash flows for each of the three years in the period ended June 26, 2020, including the related notes (collectively referred to as the “consolidated financial statements”). We also have audited the Company’s internal control over financial reporting as of June 26, 2020, based on criteria established in Internal Control—Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001193125-20-223682:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of June 26, 2020 and June 28, 2019, and the results of its operations and its cash flows for each of the three years in the period ended June 26, 2020 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of June 26, 2020, based on criteria established in Internal Control—Integrated Framework (2013) issued by the COSO.

[0001193125-20-223682:auditors_report:6]
Basis for Opinions

[0001193125-20-223682:auditors_report:7]
The Company’s management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in Management’s Annual Report on Internal Control over Financial Reporting appearing under Item 9A. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company’s internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001193125-20-223682:auditors_report:8]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001193125-20-223682:auditors_report:9]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001193125-20-223682:auditors_report:10]
Definition and Limitations of Internal Control over Financial Reporting

[0001193125-20-223682:auditors_report:11]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting

[0001193125-20-223682:auditors_report:12]
62

[0001193125-20-223682:auditors_report:13]
includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001193125-20-223682:auditors_report:14]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001193125-20-223682:auditors_report:15]
Critical Audit Matters

[0001193125-20-223682:auditors_report:16]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that: (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing separate opinions on the critical audit matter or on the accounts or disclosures to which it relates.

[0001193125-20-223682:auditors_report:17]
Revenue recognition – Identifying and evaluating terms and conditions in contracts for the timing of revenue recognition.

[0001193125-20-223682:auditors_report:18]
As described in Note 3 to the consolidated financial statements, management applies the following steps in their determination of revenue to be recognized: 1) identification of the contract with a customer; 2) identification of the performance obligations in the contract; 3) determination of the transaction price; 4) allocation of the transaction price to the performance obligations in the contract; and 5) recognition of revenue when, or as, the Company satisfies a performance obligation. Since the control of the product is typically transferred to the customer depending on the terms of the contract, management applies judgment in identifying and evaluating any terms and conditions when the Company has an enforceable right to payment. For the fiscal year ended June 26, 2020, the Company’s revenue was $1,642.0 million.

[0001193125-20-223682:auditors_report:19]
The principal considerations for our determination that performing procedures relating to revenue recognition, specifically the identification and evaluation of terms and conditions in contracts for the timing of revenue recognition, is a critical audit matter are that there was a significant amount of judgment exercised by management in identifying and evaluating terms and conditions in contracts that impact the timing of revenue recognition. This in turn led to a high degree of auditor judgment and an increased extent of audit effort in performing our audit procedures to evaluate whether terms and conditions in contracts and point of controls transferred were appropriately identified and evaluated by management.

[0001193125-20-223682:auditors_report:20]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of internal

[0001193125-20-223682:auditors_report:21]
controls relating to the revenue recognition process, including controls related to the identification and evaluation of terms and conditions in contracts and the determination of the appropriate amount and timing of revenue recognition based on the contractual terms. These procedures also included, among others: (i) assessed the terms in the customer contract and evaluated the appropriateness of management’s application of their accounting policies and determination of revenue recognition; (ii) tested the mathematical accuracy of management’s calculations of revenue and the associated timing of revenue recognized in the financial statements; (iii) selected a sample of sales transaction from the period within a defined period before

[0001193125-20-223682:auditors_report:22]
63

[0001193125-20-223682:auditors_report:23]
and after the Company’s fiscal year ended and obtained the invoice, customer contract, bill of lading and proof of delivery, in order to evaluate whether revenue was recognized in the appropriate fiscal year; and (iv) selected a sample of credit memos from the period immediately subsequent to the Company’s fiscal year end and obtained the related invoice, and shipping documents to evaluate whether they relate to revenue recognition in the fiscal year ended.

[0001193125-20-223682:auditors_report:24]
/s/ PricewaterhouseCoopers ABAS Ltd.

[0001193125-20-223682:auditors_report:25]
Bangkok, Thailand

[0001193125-20-223682:auditors_report:26]
August 18, 2020

[0001193125-20-223682:auditors_report:27]
We have served as the Company’s auditor since 1999.

[0001193125-20-223682:auditors_report:28]
64

[0001193125-20-223682:auditors_report:29]
FABRINET


## item_9a

[0001193125-20-223682:item_9a:1]
| ITEM 9A. | CONTROLS AND PROCEDURES. |

[0001193125-20-223682:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001193125-20-223682:item_9a:3]
Our management, with the participation of our Chief Executive Officer (“CEO”) and Chief Financial Officer (“CFO”), evaluated the effectiveness of our disclosure controls and procedures (as defined in Rule 
13a-15(e)
 and 
15d-15(e)
 of the Securities Exchange Act of 1934, as amended (“Exchange Act”)), as of the end of the period covered by this Annual Report on Form 
10-K.
 Based on their evaluation, our management concluded that our disclosure controls and procedures were effective to provide reasonable assurance that the information we are required to disclose in reports we file or submit under the Exchange Act, (i) is recorded, processed, summarized and reported within the time periods specified in the rules and forms of the U.S. Securities and Exchange Commission, and (ii) is accumulated and communicated to Fabrinet’s management, including our CEO and CFO, as appropriate, to allow timely decisions regarding required disclosure.

[0001193125-20-223682:item_9a:4]
Changes in Internal Control over Financial Reporting

[0001193125-20-223682:item_9a:5]
There were no changes in our internal control over financial reporting during the three months ended June 26, 2020 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001193125-20-223682:item_9a:6]
113

[0001193125-20-223682:item_9a:7]
Management’s Annual Report on Internal Control over Financial Reporting

[0001193125-20-223682:item_9a:8]
Management is responsible for establishing and maintaining adequate internal control over financial reporting of the Company as defined in Rule 
13a-15(f)
 and 
15d-15(f)
 under the Exchange Act. Internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with U.S. generally accepted accounting principles.

[0001193125-20-223682:item_9a:9]
Our internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately, and fairly reflect the transactions and dispositions of the assets of the Company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the Company are being made only in accordance with authorizations of management and directors of the Company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the Company’s assets that could have a material effect on the financial statements.

[0001193125-20-223682:item_9a:10]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate. Management has assessed the effectiveness of our internal control over financial reporting as of June 26, 2020. In making this assessment, management used the criteria described in

[0001193125-20-223682:item_9a:11]
Internal Control -Integrated Framework

[0001193125-20-223682:item_9a:12]
(2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”).

[0001193125-20-223682:item_9a:13]
Based on their assessment, management concluded that we maintained effective internal control over financial reporting as of the end of fiscal year 2020, based on the criteria in Internal Control — Integrated Framework (2013) issued by COSO. The effectiveness of our internal control over financial reporting as of June 26, 2020 has been audited by PricewaterhouseCoopers ABAS Ltd., an independent registered public accounting firm, as stated in their report which appears herein.
