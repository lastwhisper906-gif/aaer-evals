# FN 8-K — 0001193125-20-222468 filed 2020-08-17

## item codes, every 8-K on or before 2020-08-18

- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2020-08-18

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-20-222468:8k_2_02:1]
EX-99.1
2
d64627dex991.htm
EX-99.1

[0001193125-20-222468:8k_2_02:2]
EX-99.1

[0001193125-20-222468:8k_2_02:3]
Exhibit 99.1

[0001193125-20-222468:8k_2_02:4]
Fabrinet Announces Fourth Quarter and Fiscal Year 2020 Financial Results

[0001193125-20-222468:8k_2_02:5]
|  | • |  | Fourth Quarter Revenue of $405 Million Exceeds Guidance Range |

[0001193125-20-222468:8k_2_02:6]
|  | • |  | Record Fiscal Year 2020 Revenue of $1.64 Billion and Record Operating Cash Flow of $151 Million |

[0001193125-20-222468:8k_2_02:7]
|  | • |  | Expands Share Repurchase Program, Resulting in $100 Million Available for Repurchase |

[0001193125-20-222468:8k_2_02:8]
BANGKOK, Thailand – August 17, 2020 – Fabrinet (NYSE: FN), a leading provider of advanced optical
packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its fourth quarter and fiscal year ended June 26, 2020.

[0001193125-20-222468:8k_2_02:9]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “We exceeded our guidance for revenue and earnings in the fourth quarter, ending the year
in a better position than ever to continue our success. This performance helped us generate record operating cash flow in fiscal 2020 and end the year with a record cash balance.”

[0001193125-20-222468:8k_2_02:10]
Grady continued, “We remain optimistic about demand for products in the core markets we serve, despite COVID headwinds, and anticipate sequential growth
in the first quarter. Going forward, we anticipate that we can extend our history of strong cash flow generation and see opportunities to continue investing in further growth while also more aggressively returning value to shareholders through an
expanded share repurchase program.”

[0001193125-20-222468:8k_2_02:11]
Fourth Quarter Fiscal Year 2020 Financial Highlights

[0001193125-20-222468:8k_2_02:12]
GAAP Results

[0001193125-20-222468:8k_2_02:13]
|  | • |  | Revenue for the fourth quarter of fiscal year 2020 was $405.1 million, consistent with the comparable period in fiscal year 2019. |

[0001193125-20-222468:8k_2_02:14]
|  | • |  | GAAP net income for the fourth quarter of fiscal year 2020 was $28.0 million, compared to GAAP net income of $33.0 million for the fourth quarter of fiscal year 2019. GAAP net income for the fourth quarter of fiscal year 2020 included a foreign exchange loss of ($0.8) million, or ($0.02) per diluted share, compared to a foreign exchange gain of $1.8 million, or $0.05 per diluted share, for the fourth quarter of fiscal year 2019. |

[0001193125-20-222468:8k_2_02:15]
|  | • |  | GAAP net income per diluted share for the fourth quarter of fiscal year 2020 was $0.75, compared to GAAP net income per diluted share of $0.88 for the fourth quarter of fiscal year 2019. |

[0001193125-20-222468:8k_2_02:16]
Non-GAAP
Results

[0001193125-20-222468:8k_2_02:17]
|  | • |  | Non-GAAP net income for the fourth quarter of fiscal year 2020 was $36.0 million, compared to non-GAAP net income of $37.6 million for the fourth quarter of fiscal year 2019. Non-GAAP net income for the fourth quarter of fiscal year 2020 included a foreign exchange loss of ($0.8) million, or ($0.02) per diluted share, compared to a foreign exchange gain of $1.8 million, or $0.05 per diluted share, for the fourth quarter of fiscal year 2019. |

[0001193125-20-222468:8k_2_02:18]
|  | • |  | Non-GAAP net income per diluted share for the fourth quarter of fiscal year 2020 was $0.96, compared to non-GAAP net income per diluted share of $1.00 for the same period a year ago. |

[0001193125-20-222468:8k_2_02:19]
Fiscal Year 2020 Financial Highlights

[0001193125-20-222468:8k_2_02:20]
GAAP Results

[0001193125-20-222468:8k_2_02:21]
|  | • |  | Revenue for fiscal year 2020 was $1,641.8 million, compared to revenue of $1,584.3 million for fiscal year 2019. |

[0001193125-20-222468:8k_2_02:22]
|  | • |  | GAAP net income for fiscal year 2020 was $113.5 million, compared to GAAP net income of $121.0 million for fiscal year 2019. GAAP net income for fiscal year 2020 included a foreign exchange loss of ($3.8) million, or ($0.10) per diluted share, compared to a foreign exchange gain of $1.4 million, or $0.04 per diluted share, for fiscal year 2019. |

[0001193125-20-222468:8k_2_02:23]
|  | • |  | GAAP net income per diluted share for fiscal year 2020 was $3.01, compared to GAAP net income per diluted share of $3.23 for fiscal year 2019. |

[0001193125-20-222468:8k_2_02:24]
Non-GAAP Results

[0001193125-20-222468:8k_2_02:25]
|  | • |  | Non-GAAP net income for fiscal year 2020 was $140.6 million, compared to non-GAAP net income of $142.6 million for fiscal year 2019. Non-GAAP net income for fiscal year 2020 included a foreign exchange loss of ($3.8) million, or ($0.10) per diluted share, compared to a foreign exchange gain of $1.4 million, or $0.04 per diluted share, for fiscal year 2019. |

[0001193125-20-222468:8k_2_02:26]
|  | • |  | Non-GAAP net income per diluted share for fiscal year 2020 was $3.73, compared to non-GAAP net income per diluted share of $3.81 for fiscal year 2019. |

[0001193125-20-222468:8k_2_02:27]
Share
Repurchase Program Expanded

[0001193125-20-222468:8k_2_02:28]
Fabrinet also announced that its Board of Directors has approved the repurchase of up to an additional $58.5 million
of Fabrinet’s ordinary shares, bringing the aggregate authorization under Fabrinet’s existing share repurchase program to $168.5 million, with $100.0 million currently remaining.

[0001193125-20-222468:8k_2_02:29]
Business Outlook

[0001193125-20-222468:8k_2_02:30]
Based on information available as of
August 17, 2020, Fabrinet is issuing guidance for its first quarter of fiscal year 2021 ending September 25, 2020, as follows:

[0001193125-20-222468:8k_2_02:31]
|  | • |  | Fabrinet expects first quarter revenue to be in the range of $410 million to $430 million. |

[0001193125-20-222468:8k_2_02:32]
|  | • |  | GAAP net income per diluted share is expected to be in the range of $0.77 to $0.84, based on approximately 37.7 million fully diluted shares outstanding. |

[0001193125-20-222468:8k_2_02:33]
|  | • |  | Non-GAAP net income per diluted share is expected to be in the range of $0.93 to $1.00, based on approximately 37.7 million fully diluted shares outstanding. |

[0001193125-20-222468:8k_2_02:34]
Conference Call Information

[0001193125-20-222468:8k_2_02:35]
| What: | Fabrinet Fourth Quarter and Fiscal Year 2020 Financial Results Call |

[0001193125-20-222468:8k_2_02:36]
| When: | Monday, August 17, 2020 |

[0001193125-20-222468:8k_2_02:37]
| Time: | 5:00 p.m. ET |

[0001193125-20-222468:8k_2_02:38]
| Live Call: | (888) 357-3694, domestic |

[0001193125-20-222468:8k_2_02:39]
(253) 237-1137, international

[0001193125-20-222468:8k_2_02:40]
Passcode: 7432775

[0001193125-20-222468:8k_2_02:41]
| Replay: | (855) 859-2056, domestic |

[0001193125-20-222468:8k_2_02:42]
(404) 537-3406, international

[0001193125-20-222468:8k_2_02:43]
Passcode: 7432775

[0001193125-20-222468:8k_2_02:44]
| Webcast: | http://investor.fabrinet.com/ (live and replay) |

[0001193125-20-222468:8k_2_02:45]
This press release and any other information related to the call will also be posted on Fabrinet’s website at http://investor.fabrinet.com. A recorded
version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-20-222468:8k_2_02:46]
About Fabrinet

[0001193125-20-222468:8k_2_02:47]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original
equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and
electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of
high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China and the United Kingdom. For more information
visit: www.fabrinet.com.

[0001193125-20-222468:8k_2_02:48]
Forward-Looking Statements

[0001193125-20-222468:8k_2_02:49]
Use of Non-GAAP Financials

[0001193125-20-222468:8k_2_02:50]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful
supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; depreciation of fair value uplift; ASC 606 adoption impact on gross
profit; severance payments; expenses related to our CFO search; amortization of intangibles; goodwill impairment charge; business combination expenses and consulting fee; amortization of debt issuance costs; and expenses related to reduction in
workforce. We have excluded these items in order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should
not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in
conjunction with GAAP financial measures.

[0001193125-20-222468:8k_2_02:51]
These non-GAAP financial measures are used to: (1) measure company
performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions.
In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001193125-20-222468:8k_2_02:52]
SOURCE: Fabrinet

[0001193125-20-222468:8k_2_02:53]
Investor Contact:

[0001193125-20-222468:8k_2_02:54]
Garo Toomajanian

[0001193125-20-222468:8k_2_02:55]
ir@fabrinet.com

[0001193125-20-222468:8k_2_02:56]
FABRINET

[0001193125-20-222468:8k_2_02:57]
CONSOLIDATED BALANCE SHEETS

[0001193125-20-222468:8k_2_02:58]
| (in thousands of U.S. dollars, except share data and par value) |  | June 26,2020 |  |  | June 28,2019 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 225,430 |  |  | $ | 180,839 |  |
| Short-term restricted cash |  |  | 7,402 |  |  |  | — |  |
| Short-term investments |  |  | 262,693 |  |  |  | 256,493 |  |
| Trade accounts receivable, net |  |  | 272,665 |  |  |  | 260,602 |  |
| Contract assets |  |  | 13,256 |  |  |  | 12,447 |  |
| Inventories |  |  | 309,786 |  |  |  | 293,612 |  |
| Other receivable |  |  | 24,310 |  |  |  | — |  |
| Prepaid expenses |  |  | 5,399 |  |  |  | 8,827 |  |
| Other current assets |  |  | 13,915 |  |  |  | 11,015 |  |
| Total current assets |  |  | 1,134,856 |  |  |  | 1,023,835 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Long-term restricted cash |  |  | — |  |  |  | 7,402 |  |
| Property, plant and equipment, net |  |  | 228,274 |  |  |  | 210,686 |  |
| Intangibles, net |  |  | 4,312 |  |  |  | 3,887 |  |
| Operating right-of-use assets |  |  | 8,068 |  |  |  | — |  |
| Goodwill |  |  | — |  |  |  | 3,705 |  |
| Deferred tax assets |  |  | 5,675 |  |  |  | 5,679 |  |
| Other non-current assets |  |  | 202 |  |  |  | 124 |  |
| Total non-current assets |  |  | 246,531 |  |  |  | 231,483 |  |
| Total Assets |  | $ | 1,381,387 |  |  | $ | 1,255,318 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion, net |  | $ | 12,156 |  |  | $ | 3,250 |  |
| Trade accounts payable |  |  | 251,603 |  |  |  | 257,617 |  |
| Fixed assets payable |  |  | 15,127 |  |  |  | 7,317 |  |
| Contract liabilities |  |  | 1,556 |  |  |  | 2,239 |  |
| Operating lease liabilities, current portion |  |  | 1,979 |  |  |  | — |  |
| Income tax payable |  |  | 2,242 |  |  |  | 1,801 |  |
| Accrued payroll, bonus and related expenses |  |  | 19,265 |  |  |  | 16,510 |  |
| Accrued expenses |  |  | 12,104 |  |  |  | 8,997 |  |
| Other payables |  |  | 21,514 |  |  |  | 15,317 |  |
| Total current liabilities |  |  | 337,546 |  |  |  | 313,048 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term borrowings, non-current portion, net |  |  | 39,514 |  |  |  | 57,688 |  |
| Deferred tax liability |  |  | 4,729 |  |  |  | 3,561 |  |
| Operating lease liabilities, non-current portion |  |  | 5,873 |  |  |  | — |  |
| Severance liabilities |  |  | 17,379 |  |  |  | 15,209 |  |
| Other non-current liabilities |  |  | 1,937 |  |  |  | 2,713 |  |
| Total non-current liabilities |  |  | 69,432 |  |  |  | 79,171 |  |
| Total Liabilities |  |  | 406,978 |  |  |  | 392,219 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of June 26, 2020 and June 28, 2019) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 38,471,967 shares and 38,230,753 shares issued as of June 26, 2020 and June 28, 2019, respectively; and 36,727,864 shares and 36,841,650 shares outstanding as of June 26, 2020 and June 28, 2019, respectively) |  |  | 385 |  |  |  | 382 |  |
| Additional paid-in capital |  |  | 175,610 |  |  |  | 158,299 |  |
| Less: Treasury shares (1,744,103 shares and 1,389,103 shares as of June 26, 2020 and June 28, 2019, respectively) |  |  | (68,501 | ) |  |  | (47,779 | ) |
| Accumulated other comprehensive loss |  |  | (1,147 | ) |  |  | (2,386 | ) |
| Retained earnings |  |  | 868,062 |  |  |  | 754,583 |  |
| Total Shareholders’ Equity |  |  | 974,409 |  |  |  | 863,099 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 1,381,387 |  |  | $ | 1,255,318 |  |

[0001193125-20-222468:8k_2_02:59]
FABRINET

[0001193125-20-222468:8k_2_02:60]
CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME

[0001193125-20-222468:8k_2_02:61]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
| (in thousands of U.S. dollars, except per share data) |  | June 26,2020 |  |  | June 28,2019 |  |  | June 26,2020 |  |  | June 28,2019 |  |
| Revenues |  | $ | 405,113 |  |  | $ | 405,127 |  |  | $ | 1,641,836 |  |  | $ | 1,584,335 |  |
| Cost of revenues |  |  | (358,489 | ) |  |  | (358,501 | ) |  |  | (1,455,731 | ) |  |  | (1,405,111 | ) |
| Gross profit |  |  | 46,624 |  |  |  | 46,626 |  |  |  | 186,105 |  |  |  | 179,224 |  |
| Selling, general and administrative expenses |  |  | (18,185 | ) |  |  | (13,771 | ) |  |  | (68,374 | ) |  |  | (55,067 | ) |
| Expenses related to reduction in workforce |  |  | (313 | ) |  |  | (789 | ) |  |  | (329 | ) |  |  | (1,516 | ) |
| Operating income |  |  | 28,126 |  |  |  | 32,066 |  |  |  | 117,402 |  |  |  | 122,641 |  |
| Interest income |  |  | 1,512 |  |  |  | 1,929 |  |  |  | 7,592 |  |  |  | 6,699 |  |
| Interest expense |  |  | (232 | ) |  |  | (1,708 | ) |  |  | (3,044 | ) |  |  | (5,381 | ) |
| Foreign exchange gain (loss), net |  |  | (848 | ) |  |  | 1,814 |  |  |  | (3,797 | ) |  |  | 1,406 |  |
| Other income (expense), net |  |  | 112 |  |  |  | 70 |  |  |  | 1,089 |  |  |  | 868 |  |
| Income before income taxes |  |  | 28,670 |  |  |  | 34,171 |  |  |  | 119,242 |  |  |  | 126,233 |  |
| Income tax expense |  |  | (646 | ) |  |  | (1,214 | ) |  |  | (5,763 | ) |  |  | (5,278 | ) |
| Net income |  |  | 28,024 |  |  |  | 32,957 |  |  |  | 113,479 |  |  |  | 120,955 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities |  |  | 1,941 |  |  |  | 644 |  |  |  | 538 |  |  |  | 2,043 |  |
| Change in net unrealized gain (loss) on derivative instruments |  |  | 7,289 |  |  |  | 1 |  |  |  | 570 |  |  |  | (1 | ) |
| Change in retirement benefit plan — prior service cost |  |  | 50 |  |  |  | (2,537 | ) |  |  | 528 |  |  |  | (2,537 | ) |
| Change in foreign currency translation adjustment |  |  | (44 | ) |  |  | (415 | ) |  |  | (397 | ) |  |  | (634 | ) |
| Total other comprehensive income (loss), net of tax |  |  | 9,236 |  |  |  | (2,307 | ) |  |  | 1,239 |  |  |  | (1,129 | ) |
| Net comprehensive income |  | $ | 37,260 |  |  | $ | 30,650 |  |  | $ | 114,718 |  |  | $ | 119,826 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.76 |  |  | $ | 0.89 |  |  | $ | 3.07 |  |  | $ | 3.29 |  |
| Diluted |  | $ | 0.75 |  |  | $ | 0.88 |  |  | $ | 3.01 |  |  | $ | 3.23 |  |
| Weighted average number of ordinary shares outstanding (thousands of shares) |  |
| Basic |  |  | 36,723 |  |  |  | 36,836 |  |  |  | 36,908 |  |  |  | 36,798 |  |
| Diluted |  |  | 37,571 |  |  |  | 37,511 |  |  |  | 37,665 |  |  |  | 37,415 |  |

[0001193125-20-222468:8k_2_02:62]
FABRINET

[0001193125-20-222468:8k_2_02:63]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-20-222468:8k_2_02:64]
|  |  | Years Ended |  |
| (in thousands of U. S. dollars) |  | June 26,2020 |  |  | June 28,2019 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 113,479 |  |  | $ | 120,955 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 30,875 |  |  |  | 29,944 |  |
| Loss (gain) on disposal and impairment of property, plant and equipment |  |  | 329 |  |  |  | (4 | ) |
| Loss on disposal of intangibles |  |  | — |  |  |  | 149 |  |
| Loss on impairment of goodwill |  |  | 3,514 |  |  |  | — |  |
| (Gain) loss from sales and maturities of available-for-sale securities |  |  | (96 | ) |  |  | 135 |  |
| Accretion of premiums on short-term investments |  |  | (508 | ) |  |  | (592 | ) |
| Amortization of deferred debt issuance costs |  |  | 26 |  |  |  | — |  |
| Allowance for doubtful accounts (reversal) |  |  | 240 |  |  |  | 36 |  |
| Unrealized loss (gain) on exchange rate and fair value of foreign currency forward contracts |  |  | 1,963 |  |  |  | (6,980 | ) |
| Unrealized loss on fair value of interest rate swaps |  |  | 1,672 |  |  |  | 2,591 |  |
| Amortization of fair value at hedge inception of interest rate swaps |  |  | (1,220 | ) |  |  | — |  |
| Share-based compensation |  |  | 22,203 |  |  |  | 17,157 |  |
| Deferred income tax |  |  | 1,262 |  |  |  | 879 |  |
| Other non-cash expenses |  |  | (619 | ) |  |  | (450 | ) |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | (12,260 | ) |  |  | (13,494 | ) |
| Contract assets |  |  | (809 | ) |  |  | (2,570 | ) |
| Inventories |  |  | (16,174 | ) |  |  | (44,598 | ) |
| Other current assets and non-current assets |  |  | (182 | ) |  |  | (2,777 | ) |
| Trade accounts payable |  |  | (5,990 | ) |  |  | 38,807 |  |
| Contract liabilities |  |  | (683 | ) |  |  | 2,239 |  |
| Income tax payable |  |  | 442 |  |  |  | 1,092 |  |
| Severance liabilities |  |  | 2,802 |  |  |  | 3,343 |  |
| Other current liabilities and non-current liabilities |  |  | 10,394 |  |  |  | 1,532 |  |
| Net cash provided by operating activities |  |  | 150,660 |  |  |  | 147,394 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of short-term investments |  |  | (196,373 | ) |  |  | (233,080 | ) |
| Proceeds from sales of short-term investments |  |  | 48,808 |  |  |  | 99,142 |  |
| Proceeds from maturities of short-term investments |  |  | 142,508 |  |  |  | 54,215 |  |
| Funds provided to customer to support transfer of manufacturing operations |  |  | (24,310 | ) |  |  | — |  |
| Purchase of property, plant and equipment |  |  | (42,327 | ) |  |  | (18,661 | ) |
| Purchase of intangibles |  |  | (1,180 | ) |  |  | (282 | ) |
| Proceeds from disposal of property, plant and equipment |  |  | 1,626 |  |  |  | 599 |  |
| Net cash used in investing activities |  |  | (71,248 | ) |  |  | (98,067 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Payment of debt issuance costs |  |  | (153 | ) |  |  | — |  |
| Proceeds from short-term borrowings |  |  | — |  |  |  | — |  |
| Repayment of short-term borrowings |  |  | — |  |  |  | — |  |
| Proceeds from long-term borrowings |  |  | 60,938 |  |  |  | — |  |
| Repayment of long-term borrowings |  |  | (70,079 | ) |  |  | (3,250 | ) |
| Proceeds from issuance of ordinary shares under employee share option plan |  |  | — |  |  |  | — |  |
| Repayment of finance lease liabilities |  |  | (400 | ) |  |  | (468 | ) |
| Repurchase of ordinary shares |  |  | (20,722 | ) |  |  | (5,378 | ) |
| Release of restricted cash held in connection with business acquisition |  |  | — |  |  |  | (3,478 | ) |
| Withholding tax related to net share settlement of restricted share units |  |  | (4,889 | ) |  |  | (10,649 | ) |
| Net cash used in financing activities |  |  | (35,305 | ) |  |  | (23,223 | ) |
| Net increase in cash, cash equivalents and restricted cash |  | $ | 44,107 |  |  | $ | 26,104 |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  | $ | 188,241 |  |  | $ | 161,433 |  |
| Increase in cash, cash equivalents and restricted cash |  |  | 44,107 |  |  |  | 26,104 |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash |  |  | 484 |  |  |  | 704 |  |
| Cash, cash equivalents and restricted cash at end of period |  | $ | 232,832 |  |  | $ | 188,241 |  |

[0001193125-20-222468:8k_2_02:65]
FABRINET

[0001193125-20-222468:8k_2_02:66]
CONSOLIDATED STATEMENTS OF CASH FLOWS (Continued)

[0001193125-20-222468:8k_2_02:67]
|  |  | Years Ended |  |
| (in thousands of U. S. dollars) |  | June 262020 |  |  | June 28,2019 |  |
| Supplemental disclosures |  |  |  |  |  |  |  |  |
| Cash paid for |  |  |  |  |  |  |  |  |
| Interest |  | $ | 1,688 |  |  | $ | 2,605 |  |
| Taxes |  | $ | 8,466 |  |  | $ | 7,637 |  |
| Cash received for interest |  | $ | 9,676 |  |  | $ | 5,811 |  |
| Non-cash investing and financing activities |  |  |  |  |  |  |  |  |
| Construction, software and equipment related payables |  | $ | 15,127 |  |  | $ | 7,317 |  |

[0001193125-20-222468:8k_2_02:68]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the consolidated
balance sheets that sums to the total of the same amounts shown in the consolidated statements of cash flows:

[0001193125-20-222468:8k_2_02:69]
|  |  | As of |  |
| (amount in thousands) |  | June 26,2020 |  |  | June 28,2019 |  |
| Cash and cash equivalents |  | $ | 225,430 |  |  | $ | 180,839 |  |
| Restricted cash |  |  | 7,402 |  |  |  | 7,402 |  |
| Cash, cash equivalents and restricted cash |  | $ | 232,832 |  |  | $ | 188,241 |  |

[0001193125-20-222468:8k_2_02:70]
FABRINET

[0001193125-20-222468:8k_2_02:71]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-20-222468:8k_2_02:72]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | June 26, 2020 |  |  | June 28, 2019 |  |  | June 26, 2020 |  |  | June 28, 2019 |  |
| (in thousands of U.S. dollars, except per share data) |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |
| GAAP measures |  |  | 28,024 |  |  |  | 0.75 |  |  |  | 32,957 |  |  |  | 0.88 |  |  |  | 113,479 |  |  |  | 3.01 |  |  |  | 120,955 |  |  |  | 3.23 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,298 |  |  |  | 0.03 |  |  |  | 1,271 |  |  |  | 0.03 |  |  |  | 6,098 |  |  |  | 0.16 |  |  |  | 5,655 |  |  |  | 0.15 |  |
| Depreciation of fair value uplift |  |  | 80 |  |  |  | 0.00 |  |  |  | 86 |  |  |  | 0.00 |  |  |  | 327 |  |  |  | 0.01 |  |  |  | 341 |  |  |  | 0.01 |  |
| ASC 606 adoption impact on gross profit |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (31 | ) |  |  | (0.00 | ) |
| Total related to gross profit |  |  | 1,378 |  |  |  | 0.04 |  |  |  | 1,357 |  |  |  | 0.04 |  |  |  | 6,425 |  |  |  | 0.17 |  |  |  | 5,965 |  |  |  | 0.16 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 2,604 |  |  |  | 0.07 |  |  |  | 2,513 |  |  |  | 0.07 |  |  |  | 16,105 |  |  |  | 0.43 |  |  |  | 11,502 |  |  |  | 0.31 |  |
| Expenses related to CFO search |  |  | — |  |  |  | — |  |  |  | (567 | ) |  |  | (0.02 | ) |  |  | — |  |  |  | — |  |  |  | 290 |  |  |  | 0.01 |  |
| Amortization of intangibles |  |  | 131 |  |  |  | 0.00 |  |  |  | 163 |  |  |  | 0.00 |  |  |  | 562 |  |  |  | 0.01 |  |  |  | 694 |  |  |  | 0.02 |  |
| Goodwill impairment charge |  |  | 3,514 |  |  |  | 0.09 |  |  |  | — |  |  |  | — |  |  |  | 3,514 |  |  |  | 0.09 |  |  |  | — |  |  |  | — |  |
| Business combination expenses and consulting fee |  |  | — |  |  |  | — |  |  |  | 224 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 552 |  |  |  | 0.01 |  |
| Severance payments and others |  |  | — |  |  |  | — |  |  |  | 171 |  |  |  | 0.00 |  |  |  | 150 |  |  |  | 0.00 |  |  |  | 1,120 |  |  |  | 0.03 |  |
| Total related to selling, general and administrative expenses |  |  | 6,249 |  |  |  | 0.17 |  |  |  | 2,504 |  |  |  | 0.07 |  |  |  | 20,331 |  |  |  | 0.54 |  |  |  | 14,158 |  |  |  | 0.38 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Expenses related to reduction in workforce |  |  | 313 |  |  |  | 0.01 |  |  |  | 789 |  |  |  | 0.02 |  |  |  | 329 |  |  |  | 0.01 |  |  |  | 1,516 |  |  |  | 0.04 |  |
| Amortization of debt issuance costs |  |  | 8 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |  |  | 26 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |
| Total related to other incomes and other expenses |  |  | 321 |  |  |  | 0.01 |  |  |  | 789 |  |  |  | 0.02 |  |  |  | 355 |  |  |  | 0.01 |  |  |  | 1,516 |  |  |  | 0.04 |  |
| Total related to net income & EPS |  |  | 7,948 |  |  |  | 0.21 |  |  |  | 4,650 |  |  |  | 0.12 |  |  |  | 27,111 |  |  |  | 0.72 |  |  |  | 21,639 |  |  |  | 0.58 |  |
| Non-GAAP measures |  |  | 35,972 |  |  |  | 0.96 |  |  |  | 37,607 |  |  |  | 1.00 |  |  |  | 140,590 |  |  |  | 3.73 |  |  |  | 142,594 |  |  |  | 3.81 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 37,571 |  |  |  |  |  |  |  | 37,511 |  |  |  |  |  |  |  | 37,665 |  |  |  |  |  |  |  | 37,415 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 37,571 |  |  |  |  |  |  |  | 37,511 |  |  |  |  |  |  |  | 37,665 |  |  |  |  |  |  |  | 37,415 |  |

[0001193125-20-222468:8k_2_02:73]
FABRINET

[0001193125-20-222468:8k_2_02:74]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001193125-20-222468:8k_2_02:75]
| (amount in thousands) |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | June 26,2020 |  |  | June 28,2019 |  |  | June 26,2020 |  |  | June 28,2019 |  |
| Net cash provided by operating activities |  | $ | 46,212 |  |  | $ | 41,890 |  |  | $ | 150,660 |  |  | $ | 147,394 |  |
| Less: Purchase of property, plant and equipment |  |  | (14,845 | ) |  |  | (5,450 | ) |  |  | (42,327 | ) |  |  | (18,661 | ) |
| Non-GAAP free cash flow |  | $ | 31,367 |  |  | $ | 36,440 |  |  | $ | 108,333 |  |  | $ | 128,733 |  |

[0001193125-20-222468:8k_2_02:76]
FABRINET

[0001193125-20-222468:8k_2_02:77]
GUIDANCE FOR QUARTER ENDING SEPTEMBER 25, 2020

[0001193125-20-222468:8k_2_02:78]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-20-222468:8k_2_02:79]
|  |  | Diluted EPS |  |
| GAAP net income per diluted share: |  |  | $0.77 to $0.84 |  |
| Related to cost of revenues: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.04 |  |
| Total related to gross profit |  |  | 0.04 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.11 |  |
| Business combination expenses |  |  | 0.01 |  |
| Total related to selling, general and administrative expenses |  |  | 0.12 |  |
| Total related to net income & EPS |  |  | 0.16 |  |
| Non-GAAP net income per diluted share |  | $ | 0.93 to $1.00 |  |

## item 5.02 — body, verbatim

[0001193125-20-222468:8k_body:1]
Item 5.02

[0001193125-20-222468:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001193125-20-222468:8k_body:3]
Fiscal 2021 Executive Incentive Plan

[0001193125-20-222468:8k_body:4]
On August 11, 2020, the Compensation Committee (the “Compensation Committee”) of the board of directors of Fabrinet adopted an executive incentive plan (the “Cash Bonus Plan”) for the Company’s fiscal year ending June 25, 2021 (“fiscal 2021”). The Cash Bonus Plan is an incentive program designed to motivate participants to achieve the Company’s financial objectives, and to reward them for their achievements when those objectives are met. All of the Company’s executive officers pursuant to Section 16 of the Securities Exchange Act of 1934 are eligible to participate in the Cash Bonus Plan (individually, a “Participant,” and collectively, the “Participants”). The Cash Bonus Plan provides for a target bonus amount, as set forth in the table below. The maximum bonus that a Participant may receive under the Cash Bonus Plan is such Participant’s target bonus.

[0001193125-20-222468:8k_body:5]
Name

[0001193125-20-222468:8k_body:6]
Fiscal 2021 Target Bonus

[0001193125-20-222468:8k_body:7]
Seamus Grady

[0001193125-20-222468:8k_body:8]
$

[0001193125-20-222468:8k_body:9]
1,075,000

[0001193125-20-222468:8k_body:10]
Dr. Harpal Gill

[0001193125-20-222468:8k_body:11]
$

[0001193125-20-222468:8k_body:12]
1,300,000

[0001193125-20-222468:8k_body:13]
Csaba Sverha

[0001193125-20-222468:8k_body:14]
$

[0001193125-20-222468:8k_body:15]
352,500

[0001193125-20-222468:8k_body:16]
Toh-Seng Ng

[0001193125-20-222468:8k_body:17]
$

[0001193125-20-222468:8k_body:18]
865,000

[0001193125-20-222468:8k_body:19]
*

[0001193125-20-222468:8k_body:20]
*

[0001193125-20-222468:8k_body:21]
This amount represents a target bonus for the full fiscal year and is subject to proration in connection with Mr. Ng’s retirement.

[0001193125-20-222468:8k_body:22]
The amount of bonus actually paid to a Participant under the Cash Bonus Plan will be based 50% on achievement of a fiscal 2021 revenue target and 50% on achievement of a fiscal 2021 non-GAAP operating margin target. As achievement of each financial target is considered independently from the other, the Company must meet a threshold for each factor in order for a Participant to receive any credit for that factor. If the Company achieves 100% or more of a target financial metric, bonuses would be paid out at 100% of target with respect to that financial metric component. Achievement of the fiscal 2021 revenue target at a level between 90% and 100% will result in a bonus amount for that metric that is scaled from 20% to 100% in a linear fashion. Achievement of the fiscal 2021 non-GAAP operating margin target at a level between 90% and 100% will result in a bonus amount for that metric that is scaled from 20% to 100% in a linear fashion.

[0001193125-20-222468:8k_body:23]
Equity Award Grants

[0001193125-20-222468:8k_body:24]
On August 11, 2020, the Compensation Committee approved the grant, effective as of August 20, 2020 (the “Grant Date”), of the following dollar value of restricted share units (“RSUs”), performance share units (“PSUs”) and “stretch” PSUs (“Stretch PSUs”), rounded down to the nearest whole share, to the following named executive officers and principal financial officer of the Company as a component of their fiscal 2021 compensation:

[0001193125-20-222468:8k_body:25]
Name

[0001193125-20-222468:8k_body:26]
Grant Date Value of
RSUs

[0001193125-20-222468:8k_body:27]
Grant Date Value of
PSUs

[0001193125-20-222468:8k_body:28]
Grant Date Value of
“Stretch” PSUs

[0001193125-20-222468:8k_body:29]
Seamus Grady

[0001193125-20-222468:8k_body:30]
$

[0001193125-20-222468:8k_body:31]
1,950,000

[0001193125-20-222468:8k_body:32]
$

[0001193125-20-222468:8k_body:33]
1,950,000

[0001193125-20-222468:8k_body:34]
$

[0001193125-20-222468:8k_body:35]
1,950,000

[0001193125-20-222468:8k_body:36]
Dr. Harpal Gill

[0001193125-20-222468:8k_body:37]
$

[0001193125-20-222468:8k_body:38]
1,250,000

[0001193125-20-222468:8k_body:39]
$

[0001193125-20-222468:8k_body:40]
1,560,000

[0001193125-20-222468:8k_body:41]
$

[0001193125-20-222468:8k_body:42]
1,560,000

[0001193125-20-222468:8k_body:43]
Csaba Sverha

[0001193125-20-222468:8k_body:44]
$

[0001193125-20-222468:8k_body:45]
700,000

[0001193125-20-222468:8k_body:46]
$

[0001193125-20-222468:8k_body:47]
700,000

[0001193125-20-222468:8k_body:48]
$

[0001193125-20-222468:8k_body:49]
700,000

[0001193125-20-222468:8k_body:50]
Toh-Seng Ng

[0001193125-20-222468:8k_body:51]
$

[0001193125-20-222468:8k_body:52]
381,667

[0001193125-20-222468:8k_body:53]
$

[0001193125-20-222468:8k_body:54]
1,360,000

[0001193125-20-222468:8k_body:55]
$

[0001193125-20-222468:8k_body:56]
1,360,000

[0001193125-20-222468:8k_body:57]
The grants will be made under the Company’s 2020 Equity Incentive Plan. The RSUs will vest in equal annual installments over a period of three years on the anniversary date of the Grant Date, subject to the individual’s continued service with the Company through each such vesting date.

[0001193125-20-222468:8k_body:58]
The PSUs will vest, if at all, following a 2-year performance period, on the date the Compensation Committee certifies achievement of the performance criteria set forth below, subject to the individual’s continued service with the Company through such vesting date. Vesting of the PSUs will be based 50% on achievement of a cumulative fiscal 2021 and fiscal 2022 revenue target (the “PSU Revenue Target”) and 50% on achievement of a cumulative fiscal 2021 and fiscal 2022 non-GAAP operating margin target (the “PSU Operating Margin Target”). As achievement of each financial target is considered independently from the other, the Company must meet a threshold for each factor in order for an individual to receive any credit for that factor. If the Company achieves 100% or more of a target financial metric, the PSUs will vest at 100% of target with respect to that financial metric component. Achievement of the PSU Revenue Target at a level between 90% and 100% will result in a number of shares vesting for that metric that is scaled from 20% to 100% in a linear fashion. Achievement of the PSU Operating Margin Target at a level between 90% and 100% will result in a number of shares vesting for that metric that is scaled from 20% to 100% in a linear fashion.

[0001193125-20-222468:8k_body:59]
The Stretch PSUs will vest, if at all, following a 2-year performance period, on the date the Compensation Committee certifies achievement of the performance criteria set forth below, subject to the individual’s continued service with the Company through such vesting date. Vesting of the Stretch PSUs will be based 50% on achievement of a cumulative fiscal 2021 and fiscal 2022 revenue target that is higher than the PSU Revenue Target (the “Stretch PSU Revenue Target”) and 50% on achievement of a cumulative fiscal 2021 and fiscal 2022 non-GAAP operating margin target that is higher than the PSU Operating Margin Target (the “Stretch PSU Operating Margin Target”). As achievement of each financial target is considered independently from the other, the Company must meet a threshold for each factor in order for an individual to receive any credit for that factor. If the Company achieves 100% or more of a target financial metric, the Stretch PSUs will vest at 100% of target with respect to that financial metric component. Achievement of the Stretch PSU Revenue Target at a level between the PSU Revenue Target and 100% will result in a number of shares vesting for that metric that is scaled from 0% to 100% in a linear fashion. Achievement of the Stretch PSU GM Target at a level between the PSU GM Target and 100% will result in a number of shares vesting for that metric that is scaled from 0% to 100% in a linear fashion.
