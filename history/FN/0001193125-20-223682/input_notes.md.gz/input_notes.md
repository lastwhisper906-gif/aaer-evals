# FN notes — 0001193125-20-223682


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-20-223682:notes:1]
| 2. | Summary of significant accounting policies |

[0001193125-20-223682:notes:2]
Principles of consolidation

[0001193125-20-223682:notes:3]
The Company utilizes a 
52-53
 week fiscal year ending on the Friday in June closest to June 30. Fiscal year 2020 ended on June 26, 2020 and consisted of 52 weeks. Fiscal year 2019 ended on June 28, 2019 and consisted of 52 weeks. Fiscal year 2018 ended on June 29, 2018 and consisted of 52 weeks.

[0001193125-20-223682:notes:4]
The consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) and include Fabrinet and its subsidiaries. All inter-company accounts and transactions have been eliminated.

[0001193125-20-223682:notes:5]
Use of estimates

[0001193125-20-223682:notes:6]
The preparation of the Company’s consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements, and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisitions, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information. Additionally, the extent to which the evolving COVID-19 pandemic impacts the Company’s consolidated financial statements will depend on a number of factors, including the magnitude and duration of the pandemic. These estimates may change, as new events occur and additional information is obtained, as well as other factors related to COVID-19 that could result in material impacts to our consolidated financial statements in future reporting periods.

[0001193125-20-223682:notes:7]
Reclassifications

[0001193125-20-223682:notes:8]
For presentation purposes, certain prior period amounts have been reclassified to conform to the current period presentation.

[0001193125-20-223682:notes:9]
The reclassifications have been made to the consolidated balance sheet as of June 28, 2019 and the consolidated statement of cash flows for fiscal year ended June 28, 2019 as following table:

[0001193125-20-223682:notes:10]
|  |  | Year ended June 28, 2019 |  |
| (amount in thousands) |  | As previouslyreported |  |  | Reclassification |  |  | Afterreclassified |  |
| Consolidated Balance Sheets |  |  |  |  |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Fixed assets payable |  | $ | — |  |  | $ | 7,317 |  |  | $ | 7,317 |  |
| Finance lease liabilities, current portion |  | $ | 398 |  |  | $ | (398 | ) |  | $ | — |  |
| Other payables |  | $ | 22,236 |  |  | $ | (6,919 | ) |  | $ | 15,317 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Finance lease liabilities, non-current portion |  | $ | 102 |  |  | $ | (102 | ) |  | $ | — |  |
| Other non-current liabilities |  | $ | 2,611 |  |  | $ | 102 |  |  | $ | 2,713 |  |
| Consolidated Statement of Cash Flows |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrealized loss on fair value of interest rate swaps |  | $ | — |  |  | $ | 2,591 |  |  | $ | 2,591 |  |
| Severance liabilities |  | $ | 3,343 |  |  | $ | (3,343 | ) |  | $ | — |  |
| (Reversal of) Inventory obsolescence |  | $ | (563 | ) |  | $ | 563 |  |  | $ | — |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Inventories |  | $ | (44,035 | ) |  | $ | (563 | ) |  | $ | (44,598 | ) |
| Other current assets and non-current assets |  | $ | (186 | ) |  | $ | (2,591 | ) |  | $ | (2,777 | ) |
| Severance liabilities |  | $ | — |  |  | $ | 3,343 |  |  | $ | 3,343 |  |

[0001193125-20-223682:notes:11]
These reclassifications do not affect the Company’s net income, cash flows or shareholders’ equity.

[0001193125-20-223682:notes:12]
Changes in accounting policies

[0001193125-20-223682:notes:13]
Except for the adoption of the new lease accounting standard and the derivatives and hedging standard described within the 
sub-heading
 “New Accounting Pronouncements – adopted by the Company”, the Company has consistently applied its accounting policies to all periods presented in these consolidated financial statements.

[0001193125-20-223682:notes:14]
Foreign currency transactions and translation

[0001193125-20-223682:notes:15]
The consolidated financial statements are presented in United States dollars (“$” or “USD”). The functional currency of Fabrinet and most of its subsidiaries is the USD.

[0001193125-20-223682:notes:16]
With respect to subsidiaries that use USD as their functional currency, transactions denominated in a currency other than USD are translated into USD at the rates of exchange in effect at the date of the transaction. Monetary assets and liabilities denominated in foreign currencies are translated into the functional currency at the exchange rate prevailing at the consolidated balance sheet dates. Transaction gains and losses are included in foreign exchange gain (loss) in the accompanying consolidated statements of operations and comprehensive income.

[0001193125-20-223682:notes:17]
Fabrinet translates the assets and liabilities of its subsidiaries that do not use USD as their functional currency into USD using exchange rates in effect at the end of each period. Revenue and expenses for such

[0001193125-20-223682:notes:18]
subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recognized in foreign currency translation adjustment included in accumulated other comprehensive income (loss) (“AOCI”) in the Company’s consolidated balance sheets.

[0001193125-20-223682:notes:19]
Cash and cash equivalents

[0001193125-20-223682:notes:20]
All highly liquid investments with original maturities of three months or less at the date of purchase are classified as cash equivalents. Cash and cash equivalents consist of cash deposited in checking accounts, time deposits with maturities of less than three months, money market accounts, and short-term investments with maturities of three months or less at the date of purchase.

[0001193125-20-223682:notes:21]
Short-term investments

[0001193125-20-223682:notes:22]
Management determines the appropriate classification of its investments at the time of purchase and 
re-evaluates
 the designations at each balance sheet date. The Company may sell certain of the Company’s short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s short-term investments generally range from three months to three years. The Company’s short-term investments, which consist of investments in U.S. Treasury, fixed income securities, liquidity funds that invest in short-term debt securities and certificates of deposit and time deposits, have been classified and accounted for as

[0001193125-20-223682:notes:23]
available-for-sale.

[0001193125-20-223682:notes:24]
The Company’s investments in marketable securities are classified as

[0001193125-20-223682:notes:25]
available-for-sale

[0001193125-20-223682:notes:26]
securities and reported at fair value. Unrealized gains and losses related to changes in the fair value of securities are recognized in AOCI in the Company’s consolidated balance sheets. Changes in the fair value of

[0001193125-20-223682:notes:27]
securities impact the Company’s net income only when such securities are sold or when other-than-temporary impairment is recognized. Realized gains and losses on the sale of securities are determined by specific identification of each security’s cost basis.

[0001193125-20-223682:notes:28]
The Company reviews its short-term investments on a regular basis to evaluate whether or not any security has experienced an other-than-temporary decline in fair value. The Company considers factors such as the length of time and extent to which the market value has been less than the cost, the financial condition and near-term prospects of the issue and the Company’s intent to sell, or whether it is more likely than not the Company will be required to sell the investment before recovery of the investment’s amortized cost basis. If the Company believes that an other-than-temporary decline exists in one of these securities, the Company will write down these investments to fair value.

[0001193125-20-223682:notes:29]
Trade accounts receivable

[0001193125-20-223682:notes:30]
Accounts receivable are carried at anticipated realizable value. The Company assesses the collectability of its accounts receivable based on specific customer circumstances, current economic trends, historical experience with collection and the age of past due receivables and provides an allowance for doubtful receivables based on a review of all outstanding amounts at the period end. Bad debts are 
written-off
 when identified.

[0001193125-20-223682:notes:31]
Unanticipated changes in the liquidity or financial position of the Company’s customers may require revision to its allowances for doubtful accounts.

[0001193125-20-223682:notes:32]
Contract assets

[0001193125-20-223682:notes:33]
A contract asset is recognized when the Company has recognized revenues prior to generating an invoice for payment. Contract assets are classified separately within the consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. The Company reviews contract assets for impairment on a quarterly basis, or when events or changes in circumstances indicate that their carrying amount may not be recoverable.

[0001193125-20-223682:notes:34]
Contract liabilities

[0001193125-20-223682:notes:35]
A contract liability is recognized when the Company has advance payment arrangements with customers. The contract liabilities balance is normally recognized as revenue within six months.

[0001193125-20-223682:notes:36]
Inventory

[0001193125-20-223682:notes:37]
Inventory is stated at the lower of cost or market value. Cost is estimated using the standard costing method, computed on a 
first-in,

[0001193125-20-223682:notes:38]
first-out
 basis, with adjustments for variances to reflect actual costs not in excess of net realizable market value. Market value is the estimated selling price in the ordinary course of business, less the costs of completion and selling expenses. The Company assesses the valuation of inventory on a quarterly basis and writes down the value for estimated excess and obsolete inventory based upon estimates of future demand.

[0001193125-20-223682:notes:39]
Leases

[0001193125-20-223682:notes:40]
Operating leases

[0001193125-20-223682:notes:41]
The Company determines if an arrangement contains a lease at inception. The Company applies the guidance in ASC 842 to determine whether a contract is, or contains, a lease. A contract is or contains a lease if the contract conveys the right to control the use of identified property, plant, or equipment (an identified asset) for a period of time in exchange for consideration. Operating leases are included in operating lease right of use (“ROU”) assets and operating lease liabilities within the Company’s consolidated balance sheets. The Company rents certain real estate under agreements that are classified as operating leases.

[0001193125-20-223682:notes:42]
Operating lease ROU assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at commencement date. As most of the Company’s leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the lease commencement date in determining the present value of future payments. The operating lease ROU assets also include any lease payments made and exclude lease incentives and initial direct costs incurred. Variable lease payments are expensed as incurred and are not included within the ROU asset and lease liability calculation. Variable lease payments primarily include reimbursements of costs incurred by lessors for common area maintenance and utilities. The Company’s lease terms may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option.

[0001193125-20-223682:notes:43]
Leases with an initial term of 12 months or less are not recorded on the balance sheet. The Company recognizes lease expense for these leases on a straight-line basis over the lease term. The Company does not account for lease components (e.g., fixed payments including rent) separately from the 
non-lease
 components (e.g., common-area maintenance costs).

[0001193125-20-223682:notes:44]
Finance leases

[0001193125-20-223682:notes:45]
Finance leases are accounted for in a manner similar to financed purchases. The

[0001193125-20-223682:notes:46]
right-of-use

[0001193125-20-223682:notes:47]
asset is amortized to amortization expense. Interest expense is recorded in connection with the lease liability.

[0001193125-20-223682:notes:48]
Property, plant and equipment

[0001193125-20-223682:notes:49]
Land is stated at historical cost. Other property, plant and equipment, except for construction in process and machinery under installation, are stated at historical cost less accumulated depreciation. Repair and maintenance costs are expensed as incurred. Depreciation is calculated using the straight-line method to 
write-off
 the cost of each asset to its residual value over its estimated useful life as follows:

[0001193125-20-223682:notes:50]
| Land improvements |  |  | 10 years |  |
| Building and building improvements |  |  | 5 - 30 years |  |
| Leasehold improvements |  |  | Shorter of useful life or lease term |  |

[0001193125-20-223682:notes:51]
| Manufacturing equipment |  |  | 3 - 7 years |  |
| Office equipment |  |  | 3 - 7 years |  |
| Motor vehicles |  |  | 3 - 5 years |  |
| Computer hardware |  |  | 3 - 5 years |  |

[0001193125-20-223682:notes:52]
Construction in process and machinery under installation is stated at historic cost and depreciation begins after it is constructed and fully installed and is ready for its intended use in the operations of the Company.

[0001193125-20-223682:notes:53]
Gains and losses on disposal are determined by comparing proceeds with carrying amounts and are included in other income in the consolidated statements of operations and comprehensive income.

[0001193125-20-223682:notes:54]
The Company reviews long-lived assets or asset groups for recoverability on a quarterly basis for any events or changes in circumstances that indicate that their carrying amount may not be recoverable. Recoverability of long-lived assets or asset groups is measured by comparing their carrying amount to the projected undiscounted cash flows that the long-lived assets or asset groups are expected to generate. If such assets are considered to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the long-lived assets exceeds its fair value.

[0001193125-20-223682:notes:55]
Intangibles

[0001193125-20-223682:notes:56]
Intangibles are stated at historical cost less amortization. Amortization of customer relationships is calculated using the accelerated method as to reflect the pattern in which the economic benefits of the intangible assets are consumed. Amortization of other intangibles is calculated using the straight-line method.

[0001193125-20-223682:notes:57]
Intangible assets are reviewed for impairment quarterly or more frequently whenever changes or circumstances indicate the carrying amount of related assets may not be recoverable.

[0001193125-20-223682:notes:58]
Goodwill

[0001193125-20-223682:notes:59]
Goodwill arising from acquisition is primarily attributable to the ability to expand future products and services and the assembled workforce. Goodwill is reviewed annually for impairment or more frequently whenever circumstances indicate that the carrying amount of a reporting unit may exceed its fair value. The impairment charge is based on that difference and is limited to the amount of goodwill allocated to that unit. The Company conducts impairment testing for goodwill at the reporting unit level. Reporting units may be operating segments as a whole, or an operation one level below an operating segment, referred to as a component. The Company has determined that its reporting unit is Fabrinet UK.

[0001193125-20-223682:notes:60]
The Company may initiate goodwill impairment testing by considering qualitative factors to determine whether it is more likely than not that a reportable segment’s carrying value is greater than its fair value. If the Company’s qualitative assessment indicates it is more likely than not that the fair value of a reporting unit exceeds its carrying value, no further analysis is required and goodwill is not impaired. Otherwise, the Company performs a quantitative goodwill impairment test to determine if goodwill is impaired. The quantitative test compares the fair value of a reporting unit with its carrying amount, including goodwill. If the fair value of the reportable segment exceeds the carrying value of the net assets associated with the segment, goodwill is not considered impaired. If the carrying value of the net assets associated with the reportable segment exceeds the fair value of the segment, the Company recognizes an impairment loss in an amount equal to the excess, not to exceed the carrying value of the reportable segment’s goodwill. The reporting unit’s carrying value used in an impairment test represents the assignment of various assets and liabilities, excluding certain corporate assets and liabilities, such as cash, investments, and debt.

[0001193125-20-223682:notes:61]
Goodwill is not deductible for tax purposes. Accordingly, if goodwill is impaired for financial reporting purposes, there is no impact on deferred taxes.

[0001193125-20-223682:notes:62]
Treasury shares

[0001193125-20-223682:notes:63]
Treasury share purchases are accounted for under the cost method whereby the entire cost of the acquired stock is recorded as treasury shares. Gains and losses in excess of par value on the subsequent reissuance of shares are credited or charged to additional 
paid-in
 capital in the consolidated balance sheets using the average-cost method.

[0001193125-20-223682:notes:64]
Borrowing costs

[0001193125-20-223682:notes:65]
Borrowing costs are accounted for on an accrual basis and are charged to the consolidated statements of operations and comprehensive income in the year incurred, except for interest costs on general and specific borrowings attributable to finance certain qualifying assets. Such costs to finance qualifying assets are capitalized during the period of time that is required to complete and prepare the assets for their intended use, as part of the cost of the assets. All other borrowing costs are expensed as incurred.

[0001193125-20-223682:notes:66]
Where funds are not borrowed for a specific acquisition, construction or production of assets, the capitalization rate used to determine the amount of interest to be capitalized is the weighted average interest rate applicable to the Company’s outstanding borrowings during the year. Where funds are borrowed specifically for the acquisition, construction or production of assets, the amount of borrowing costs eligible for capitalization on the respective assets is determined as the actual borrowing costs are incurred on that borrowing during the respective periods.

[0001193125-20-223682:notes:67]
Fair value of financial instruments

[0001193125-20-223682:notes:68]
Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. A fair value hierarchy is established which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs for the valuation of an asset or liability as of the measurement date. The three levels of inputs that may be used to measure fair value are defined as follows:

[0001193125-20-223682:notes:69]
Level 1 inputs are quoted prices (unadjusted) in active markets for identical assets or liabilities.

[0001193125-20-223682:notes:70]
Level 2 inputs for similar assets and liabilities in active markets other than quoted prices included within Level 1 that are observable for the asset or liability, either directly or indirectly, for substantially the full term of the asset or liability.

[0001193125-20-223682:notes:71]
Level 3 inputs that are significant to the fair value measurement and unobservable (i.e. supported by little or no market activity), which require the reporting entity to develop its own valuation techniques and assumptions.

[0001193125-20-223682:notes:72]
The Company utilizes the market approach to measure fair value for its financial assets and liabilities. The market approach uses prices and other relevant information generated by market transactions involving identical or comparable assets or liabilities.

[0001193125-20-223682:notes:73]
The carrying amounts of certain financial instruments, which include cash and cash equivalents, trade accounts receivable, contract assets, trade accounts payable, and contract liabilities, approximate their fair values due to their short maturities. The carrying amounts of borrowings approximate their fair values as the applicable interest rate is based on market interest rates. The particular recognition methods adopted are disclosed in the individual policy statements associated with each item.

[0001193125-20-223682:notes:74]
Derivatives

[0001193125-20-223682:notes:75]
The derivative assets and liabilities are measured at fair value and recognized on the consolidated balance sheets by offset fair value amounts under master netting arrangements. For presentation in consolidated balance sheets, the Company may choose not to separate a derivative into its current and 
non-current
 portion as follows:

[0001193125-20-223682:notes:76]
|  | • |  | A derivative whose fair value is a net liability is classified in total as current. |

[0001193125-20-223682:notes:77]
|  | • |  | A derivative whose fair value is a net asset and whose current portion is an asset is classified in total as non-current. If the current portion is liability, it should be presented as current liability. |

[0001193125-20-223682:notes:78]
For presentation in consolidated statements of cash flows are classified in the same line item as the underlying item.

[0001193125-20-223682:notes:79]
The Company applies hedge accounting to arrangements that qualify and are designated for cash flow or fair value hedge accounting treatment. Hedge accounting is discontinued prospectively if the hedging relationship ceases to be effective or the hedging or hedged items cease to exist as a result of maturity, sale, termination or cancellation.

[0001193125-20-223682:notes:80]
Derivatives designated and qualifying as hedges of the exposure to variability in expected future cash flows, or other types of forecasted transactions, are considered cash flow hedges which include foreign currency forward contracts and interest rate swap. In a cash flow hedging relationship, the change in the fair value of the hedging derivative is initially recorded in AOCI in the consolidated balance sheets, gain or loss on the derivative instrument is reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings. The reclassified amounts are presented in the same income statement line item as the earnings effect of the hedged item.

[0001193125-20-223682:notes:81]
In accordance with the fair value measurement guidance, the Company’s accounting policy is to measure the credit risk of its derivative financial instruments that are subject to master netting agreements on a net basis by counterparty portfolio. The Company executes derivative instruments with financial institutions that are credit-worthy, which the Company defines as institutions that hold an investment grade credit rating.

[0001193125-20-223682:notes:82]
Concentration of credit risk

[0001193125-20-223682:notes:83]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash and cash equivalents, short-term investments, derivatives, accounts receivable and contract assets.

[0001193125-20-223682:notes:84]
Cash, cash equivalents and short-term investments are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. The Company seeks to mitigate its credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties. The Company limits its short-term investments in marketable securities to securities with a maturity not in excess of three years and securities that are rated A1, 
P-1,
 F1, or better.

[0001193125-20-223682:notes:85]
The Company enters into derivative contracts with financial institutions with reputable credit and monitors the credit profiles of these counterparties.

[0001193125-20-223682:notes:86]
The Company performs ongoing credit evaluations for credit worthiness of its customers and usually does not require collateral from its customers. Management has implemented a program to closely monitor near term cash collection and credit exposures to mitigate any material losses.

[0001193125-20-223682:notes:87]
Revenue recognition

[0001193125-20-223682:notes:88]
The Company derives revenues primarily from the assembly of products under supply agreements with its customers and the fabrication of customized optics and glass. The Company recognizes revenue relating to

[0001193125-20-223682:notes:89]
contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the Company expects to be entitled in exchange for such goods or services. In order to meet this requirement, the Company applies the following five steps: (1) identify the contract with a customer, (2) identify the performance obligations under the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations under the contract, and (5) recognize revenue when a performance obligation is satisfied. Revenue is recognized net of any taxes collected from customers, which is subsequently remitted to governmental authorities.

[0001193125-20-223682:notes:90]
A performance obligation is a contractual promise to transfer a distinct good or service to the customer. In contracts with multiple performance obligations, the Company identifies each performance obligation and

[0001193125-20-223682:notes:91]
evaluates whether the performance obligation is distinct within the context of the contract at contract inception. The majority of the Company’s contracts have a single performance obligation, as the promise to transfer the individual goods or services is not separately identifiable from other promises under the contracts and, therefore, is not distinct.

[0001193125-20-223682:notes:92]
Sales of finished goods

[0001193125-20-223682:notes:93]
The Company manufactures products that are customized to customers’ specifications; however, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for over time recognition are not met. On evaluation of the contracts, the Company identified that there were no contractual rights to bill profit for work in progress in the event of a contract termination, which is expected to be infrequent. Further, in limited circumstances, contracts provide for substantive acceptance by the customer, which results in the deferral of revenue until formal notice of acceptance is received from the customer. Judgment may be required in determining if an acceptance clause provides for substantive acceptance.

[0001193125-20-223682:notes:94]
Certain customers may request the Company to store finished products at the Company’s warehouse where customers bear risks of loss themselves. In these instances, the Company receives a written request from the customer asking the Company to hold the inventory at the Company’s warehouse and refrain from using the ordered goods to fulfill other customer orders. In these situations, revenue is only recognized when the completed goods are ready for shipment and transferred to the Company’s warehouse.

[0001193125-20-223682:notes:95]
Customers generally are obligated to purchase finished goods that the Company has manufactured according to their demand requirements. Materials that are not consumed by customers within a specified period of time, or are no longer required due to a product’s cancellation or

[0001193125-20-223682:notes:96]
end-of-life,

[0001193125-20-223682:notes:97]
are typically designated as excess or obsolete inventory under the Company’s contracts. Once materials are designated as either excess or obsolete inventory, customers are typically required to purchase such inventory from the Company even if the customer has chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

[0001193125-20-223682:notes:98]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. In determining the net consideration to which the Company expects to be entitled, the Company evaluates whether the price is subject to refund or adjustment. The Company generally does not grant return privileges, except for in the case of defective products during the warranty period. The Company generally provides a warranty of between one to five years on any given product.

[0001193125-20-223682:notes:99]
These standard warranties are assurance-type warranties
,
 and the Company does not offer any services in addition to the assurance that the product will continue to work as specified.

[0001193125-20-223682:notes:100]
The sales price is not considered to be fixed or determinable until all contingencies related to the sale have been resolved. The Company recognized revenue net of rebates and other similar allowances. Revenues are recognized only if these estimates can be reasonably and reliably determined. The Company bases its estimates on historical results taking into consideration the type of customer, the type of transaction and the specifics of each arrangement.

[0001193125-20-223682:notes:101]
Services

[0001193125-20-223682:notes:102]
The Company provides services for customers that are related to the Company’s manufacturing activities. In many cases, although the nature of work performed is that of a service, revenue is only 
re
cognized upon shipment

[0001193125-20-223682:notes:103]
of the product because the customer has specific requirements as to how many items can be shipped at any given point in time, i.e. at point-in-time. The related costs are expensed as incurred.

[0001193125-20-223682:notes:104]
Service revenues of $90.5 million, $106.1 million and $73.5 million were recognized in the consolidated statements of operations and comprehensive income for the years ended June 26, 2020, June 28, 2019 and June 29, 2018, respectively.

[0001193125-20-223682:notes:105]
Contract Costs

[0001193125-20-223682:notes:106]
The incremental costs of obtaining a contract with a customer are recognized as an asset (not expensed as incurred) if such costs are expected to be recovered. Incremental costs of obtaining a contract are costs that the Company would not have incurred if the contract had not been obtained (e.g., sales commissions or similar incentive payments linked directly to new or modified customer contracts). Costs that would have been incurred regardless of whether a customer contract was obtained (e.g., costs of pursuing the 
contract
, legal advice, etc.) are expensed as incurred, unless such costs are explicitly chargeable to the customer. During the 
years
 ended June 26, 2020 and June 28, 2019, the Company did not have any incremental costs of obtaining a contract.

[0001193125-20-223682:notes:107]
Shipping and Handling

[0001193125-20-223682:notes:108]
Shipping costs billed to customers are recorded as revenue. Shipping and handling expense related to costs incurred to deliver product are recognized within cost of goods sold. The Company accounts for shipping and handling activities that occur after control has transferred as a fulfillment cost, as opposed to a separate performance obligation, and the costs of shipping and handling are recognized concurrently with the related revenue.

[0001193125-20-223682:notes:109]
Warranty provision

[0001193125-20-223682:notes:110]
Provisions for estimated expenses relating to product warranties are made at the time the products are sold using historical experience. Generally, this warranty is limited to workmanship and the Company’s liability is capped at the price of the product. The provisions will be adjusted when experience indicates an expected settlement will differ from initial estimates.

[0001193125-20-223682:notes:111]
Warranty cost allowances (reversal) of $0.02 million, $0.07 million and $(0.02) million were recognized in the consolidated statements of operations and comprehensive income for the years ended June 26, 2020, June 28, 2019 and June 29, 2018, respectively.

[0001193125-20-223682:notes:112]
Share-based compensation

[0001193125-20-223682:notes:113]
Share-based compensation is recognized in the consolidated financial statements based on grant-date fair value. The value of the portion of the award that is ultimately expected to vest is recognized as expense ratably over the requisite service period. The Company estimates the fair value of share option awards utilizing the Black-Scholes-Merton option-pricing model (“BSM”), net of estimated forfeitures. For restricted share units and performance share units, the fair values are based on the market value of our ordinary shares on the date of grant.

[0001193125-20-223682:notes:114]
Employee contribution plan

[0001193125-20-223682:notes:115]
The Company operates a defined contribution plan, known as a provident fund, in its subsidiaries in Thailand and the United Kingdom. The assets of these plans are in separate trustee-administered funds. The

[0001193125-20-223682:notes:116]
provident fund is funded by matching payments from employees and by the subsidiaries on a monthly basis. Current contributions to the provident fund are accrued and paid to the fund manager on a monthly basis. The Company sponsors the Fabrinet U.S. 401(k) Retirement Plan (the “401(k) Plan”), a Defined Contribution Plan under ERISA, at its subsidiaries in the United States, which provides retirement benefits for its eligible employees through tax deferred salary deductions.

[0001193125-20-223682:notes:117]
Severance liabilities

[0001193125-20-223682:notes:118]
Under labor protection laws applicable in Thailand and the Company’s subsidiary in Thailand’s employment policy, all employees of such subsidiary with more than 120 days of service are entitled to severance pay on forced termination or retrenchment or in the event that the employee reaches the retirement age of 55. The entitlement to severance pay is determined according to an employee’s individual employment tenure with the Company and is subject to a maximum benefit of 400 days of salary unless otherwise agreed upon in an employee’s employment contract. For employees of other subsidiaries who have a specific termination date, the entitlement to severance pay is determined according to their employment tenure, until their designated termination date.

[0001193125-20-223682:notes:119]
The Company accounts for these severance liabilities based on an actuarial valuation using the Projected Unit Credit Method, which apply the long-term Thai government bond yield as a discount rate. There are no separate plan assets held in respect to these liabilities.

[0001193125-20-223682:notes:120]
The Company’s subsidiary in the U.K. operates a defined benefit pension plan that defines the pension benefit an employee will receive on retirement, usually dependent upon several factors including but not limited to age, length of service and remuneration. The defined benefit obligation is calculated using the projected unit credit method. Annually the Company engages independent actuaries to calculate the obligation. The present value is determined by discounting the estimated future payments using market yields on high quality corporate bonds that are denominated in sterling and that have terms approximating the estimated period of the future payments (discount rate). The plan assets are held separately from those of the Company in independently administered funds and are measured at fair value.

[0001193125-20-223682:notes:121]
Severance liabilities are recognized in the Company’s consolidated balance sheet under 
non-current
 liabilities. The related expenses, if incurred during the period, are recognized in the Company’s consolidated statements of operations and comprehensive income as selling, general and administrative expenses. Prior service cost is initially recognized to other comprehensive income (loss) at the date of plan amendment. Such prior service cost is amortized as expenses as a component of net periodic pension cost 
using
 the weighted average remaining years of service to full eligibility date 
for
 active employees.

[0001193125-20-223682:notes:122]
Annual leave

[0001193125-20-223682:notes:123]
Employee entitlements to annual leave are recognized when 
earned by
 the employee. On termination of employment, accrued employee entitlement to annual leave is paid in cash.

[0001193125-20-223682:notes:124]
Income taxes

[0001193125-20-223682:notes:125]
The Company uses the asset and liability method of accounting for income taxes, whereby deferred tax assets and liabilities are recognized for future tax consequences attributable to temporary differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using tax rates expected to apply to taxable income in the years in which those temporary differences are expected to reverse. The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date. Deferred tax assets are reduced by a valuation allowance if, based on the weight of the available evidence, it is more likely than not that some portion or all of the deferred tax assets will not be realized.

[0001193125-20-223682:notes:126]
Fabrinet’s subsidiaries are subject to income tax audits by the respective tax authorities in all of the jurisdictions in which they operate. The determination of tax liabilities in each of these jurisdictions requires the interpretation and application of complex and sometimes uncertain tax laws and regulations.

[0001193125-20-223682:notes:127]
The Company recognizes liabilities based on its estimate of whether, and the extent to which, additional tax liabilities are 
more-likely-than-not.
 If the Company ultimately determines that the payment of such a liability is not probable, then it reverses the liability and recognizes a tax benefit during the period in which the determination is made that the liability is no longer probable. The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that the Company makes certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on the Company’s tax provision in a future period.

[0001193125-20-223682:notes:128]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. A company shall reduce its deferred tax assets by a valuation allowance if, based on the weight of available evidence, it is “more likely than not” (i.e., a likelihood of greater than 50 percent) that some portion or all of the deferred tax assets will not be realized. The valuation allowance shall be sufficient to reduce the deferred tax asset to the amount that is more likely than not to be realized. The valuation allowance shall be monitored and considered from all available evidence, both positive and negative, to determine whether, based on the weight of that evidence, a valuation allowance for deferred tax assets is not needed.

[0001193125-20-223682:notes:129]
The accounting standard clarifies the accounting for uncertainty in income taxes recognized in an entity’s financial statements and prescribes a recognition threshold and measurement attributes for financial statement disclosure of tax positions taken or expected to be taken on a tax return.

[0001193125-20-223682:notes:130]
The Company recognizes a tax benefit in the financial statements for an uncertain tax position only if management’s assessment is that the position is “more likely than not” to be sustained upon examination by the tax jurisdiction based solely on the technical merits of the position. The term “tax position” refers to a position in a previously filed tax return or a position expected to be taken in a future tax return that is reflected in measuring current or deferred income tax assets and liabilities for interim or annual periods. The accounting interpretation also provides guidance on measurement methodology, derecognition thresholds, financial statement classification and disclosures, recognition of interest and penalties, and accounting for the cumulative-effect adjustment at the date of adoption.

[0001193125-20-223682:notes:131]
New Accounting Pronouncements—not yet adopted by the Company

[0001193125-20-223682:notes:132]
In December 2019, the Financial

[0001193125-20-223682:notes:133]
Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 
2019-12,
 “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.” The amendments in this update simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify U.S. GAAP for other areas of Topic 740 by clarifying and amending existing guidance. For public business entities, the amendments in this update are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2020. This ASU will be effective for the Company in the first quarter of fiscal year 2022. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its consolidated financial statements.

[0001193125-20-223682:notes:134]
In August 2018, the FASB issued ASU 2018-13

[0001193125-20-223682:notes:135]
, “Fair Value Measurement (Topic 820), Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement.” This ASU is intended to improve the effectiveness of disclosures in the notes to the financial statements, including (1) the development of a framework that promotes consistent decisions by the FASB about disclosure requirements and (2) the appropriate exercise of discretion by reporting entities. The amendment modifies the disclosure requirements on transferring between level 1 and level 2 and valuation processes of level 3 fair value measurements. The amendments in this update are effective for all entities for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, including interim periods within those

[0001193125-20-223682:notes:136]
fiscal years. The Company assessed the preliminary impact from the adoption of this update and expected no impact on its consolidated financial statements.

[0001193125-20-223682:notes:137]
In June 2016, the FASB issued ASU

[0001193125-20-223682:notes:138]
2016-13,

[0001193125-20-223682:notes:139]
“Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which establishes a new credit impairment model for financial assets measured at amortized cost and

[0001193125-20-223682:notes:140]
debt securities. The FASB issued subsequent amendments to Topic 326, including ASU

[0001193125-20-223682:notes:141]
2018-19,

[0001193125-20-223682:notes:142]
ASU

[0001193125-20-223682:notes:143]
2019-04,

[0001193125-20-223682:notes:144]
2019-05,

[0001193125-20-223682:notes:145]
2019-11

[0001193125-20-223682:notes:146]
and ASU

[0001193125-20-223682:notes:147]
2020-02,

[0001193125-20-223682:notes:148]
which provided further guidance and transition relief. For public business entities, this update is effective for fiscal years beginning after December 15

[0001193125-20-223682:notes:149]
, 2019, including interim periods within those fiscal years. This ASU will be effective for the Company in the first quarter of fiscal year 2021. Early adoption is permitted. The Company assessed the preliminary impact 
from
 the 
adoption
 of this update 
and expected
 no impact on its consolidated financial statements.

[0001193125-20-223682:notes:150]
New Accounting Pronouncements—adopted by the Company

[0001193125-20-223682:notes:151]
On June 29, 2019, the Company adopted the new lease accounting standard, Accounting Standards Codification (“ASC”) Topic 842, which provides guidance for the recognition and disclosure of lease arrangements. The Company adopted ASC 842 using the modified retrospective transition approach. Accordingly, the Company’s comparative financial statements as of June 28, 2019 have not been adjusted. ASC 842 also provides practical expedients for the Company’s ongoing accounting. The Company elected the short-term lease recognition exemption for its operating leases with a term of less than 12 months, which will not require recognition of ROU assets or lease liabilities for these leases.

[0001193125-20-223682:notes:152]
For periods prior to adoption of ASC 842, the Company is required to present disclosures in accordance with ASC Topic 840. Future minimum lease payments due under 
non-cancelable
 operating leases as of June 28, 2019 were as follows:

[0001193125-20-223682:notes:153]
| (amount in thousands) |  |  |  |
| 2020 |  | $ | 1,746 |  |
| 2021 |  |  | 1,342 |  |
| 2022 |  |  | 1,219 |  |
| 2023 |  |  | 1,172 |  |
| Thereafter |  |  | 230 |  |
| Total future minimum operating lease payments |  | $ | 5,709 |  |

[0001193125-20-223682:notes:154]
The most significant impact of the adoption of ASC 842 was the recognition of ROU assets and lease liabilities for operating leases with a term of greater than 12 months, while the accounting for finance leases will remain substantially unchanged. See Note 
12
 for further details.

[0001193125-20-223682:notes:155]
On June 29, 2019, the Company adopted ASU 
2017-12,
 “Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities.” ASU 
2017-12
 simplifies existing hedge accounting guidance in order to better portray the economic impact of risk management activities in the financial statements, including eliminating the separate measurement and presentation of hedge ineffectiveness. Prior to the adoption of ASU 
2017-12,
 the Company was required to separately measure and reflect the amount by which the hedging instrument did not offset the changes in the fair value or cash flows of hedged items, and to record the ineffective portion as earnings. Upon the adoption of ASU 
2017-12,
 the Company no longer recognizes hedge ineffectiveness as earnings, but instead records the entire changes in the fair value of the hedged instruments as other comprehensive income. Amounts recorded as other comprehensive income are subsequently reclassified to earnings in the same income statement line item that is used to present the earnings effect of the hedged item when the hedged item affects earnings. See Note 7 for further details.

[0001193125-20-223682:notes:156]
In March 2020, the FASB issued ASU 
2020-04,
 “Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting,” which temporarily simplifies the accounting for

[0001193125-20-223682:notes:157]
contract modifications, including hedging relationships, due to the transition from LIBOR and other interbank offered rates to alternative reference interest rates. For example, entities can elect not to remeasure the contracts at the modification date or reassess a previous accounting determination if certain conditions are met. Additionally, entities can elect to continue applying hedge accounting for hedging relationships affected by reference rate reform if certain conditions are met. The new standard was effective upon issuance and generally can be applied to applicable contract modifications through December 31, 2022. This ASU was effective for the Company in the third quarter of fiscal year 2020 with no impact to the Company’s consolidated financial statements.

[0001193125-20-223682:notes:158]
In January 2017, the FASB issued ASU 
2017-04,
 “Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.” ASU 
2017-04
 modifies the concept of impairment assessment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. Public companies that are SEC filers should adopt the amendment for annual and any interim goodwill impairment tests in fiscal years beginning after December 15, 2019. Early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017. This ASU will be effective for the Company in the first quarter of fiscal 2021. The Company early adopted this ASU in the fourth quarter of fiscal 2020 with no impact to the Company’s consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001193125-20-223682:notes:159]
| 3. | Revenues from contracts with customers |

[0001193125-20-223682:notes:160]
Contract Assets and Liabilities

[0001193125-20-223682:notes:161]
A contract asset is recognized when the Company has recognized revenues prior to an invoice for payment. Contract assets are classified separately on the consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. No impairment for contract assets was recorded for the years ended June 26, 2020 and June 28, 2019.

[0001193125-20-223682:notes:162]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the 
years
 ended June 26, 2020 and June 28, 2019:

[0001193125-20-223682:notes:163]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 28, 2019 |  | $ | 12,447 |  |
| Revenue recognized |  |  | 73,476 |  |
| Amounts collected or invoiced |  |  | (72,667 | ) |
| Ending balance, June 26, 2020 |  | $ | 13,256 |  |

[0001193125-20-223682:notes:164]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 30, 2018 |  | $ | — |  |
| Cumulative effect adjustment upon adoption of ASC 606 |  |  | 9,877 |  |
| Revenue recognized |  |  | 112,739 |  |
| Amounts collected or invoiced |  |  | (110,169 | ) |
| Ending balance, June 28, 2019 |  | $ | 12,447 |  |

[0001193125-20-223682:notes:165]
| (amount in thousands) |  | Contract Liabilities |  |
| Beginning balance, June 28, 2019 |  | $ | 2,239 |  |
| Advance payment received during the year |  |  | 9,278 |  |
| Revenue recognized |  |  | (9,961 | ) |
| Ending balance, June 26, 2020 |  | $ | 1,556 |  |

[0001193125-20-223682:notes:166]
| (amount in thousands) |  | Contract Liabilities |  |
| Beginning balance, June 30, 2018 |  | $ | — |  |
| Advance payment received during the year |  |  | 4,458 |  |
| Revenue recognized |  |  | (2,219 | ) |
| Ending balance, June 28, 2019 |  | $ | 2,239 |  |

[0001193125-20-223682:notes:167]
Revenue by Geographic Area
 and End Market

[0001193125-20-223682:notes:168]
Total revenues are attributed to a particular geographic area based on

[0001193125-20-223682:notes:169]
the bill-to-location of

[0001193125-20-223682:notes:170]
the Company’s customers. The Company operates primarily in three geographic regions: North America, Asia-Pacific and Europe.

[0001193125-20-223682:notes:171]
The following table presents total revenues by geographic regions:

[0001193125-20-223682:notes:172]
| (amount in thousands, except percentages) |  | Year endedJune 26,2020 |  |  | As a %of TotalRevenues |  |  | Year endedJune 28,2019 |  |  | As a %of TotalRevenues |  |
| North America |  | $ | 830,888 |  |  |  | 50.6 | % |  | $ | 756,278 |  |  |  | 47.7 | % |
| Asia-Pacific |  |  | 552,923 |  |  |  | 33.7 |  |  |  | 608,386 |  |  |  | 38.4 |  |
| Europe |  |  | 258,025 |  |  |  | 15.7 |  |  |  | 219,671 |  |  |  | 13.9 |  |
|  |  | $ | 1,641,836 |  |  |  | 100.0 | % |  | $ | 1,584,335 |  |  |  | 100.0 | % |

[0001193125-20-223682:notes:173]
The following table sets forth revenues by end market.

[0001193125-20-223682:notes:174]
| (amount in thousands, except percentages) |  | Year endedJune 26,2020 |  |  | As a %of TotalRevenues |  |  | Year endedJune 28,2019 |  |  | As a %of TotalRevenues |  |
| Optical communications |  | $ | 1,248,174 |  |  |  | 76.0 | % |  | $ | 1,184,936 |  |  |  | 74.8 | % |
| Lasers, sensors and other |  |  | 393,662 |  |  |  | 24.0 |  |  |  | 399,399 |  |  |  | 25.2 |  |
|  |  | $ | 1,641,836 |  |  |  | 100.0 | % |  | $ | 1,584,335 |  |  |  | 100.0 | % |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-20-223682:notes:175]
| 4. | Income taxes |

[0001193125-20-223682:notes:176]
Cayman Islands

[0001193125-20-223682:notes:177]
Fabrinet is domiciled in the Cayman Islands. Under the current laws of the Cayman Islands, Fabrinet is not subject to tax in the Cayman Islands on income or capital gains until March 6, 2039.

[0001193125-20-223682:notes:178]
Income of the Company exempted from corporate income tax in the Cayman Islands amounted to $101.9 million, $104.6 million and $58.4 million for the years ended June 26, 2020, June 28, 2019 and June 29, 2018, respectively.

[0001193125-20-223682:notes:179]
Thailand

[0001193125-20-223682:notes:180]
Fabrinet Thailand is where the majority of the Company’s operations and production takes place. The Company 
wa
s not subject to tax from July 2012 through June 2020 on income generated from the manufacture of products at Pinehurst Building 6, and is not subject to tax from July 2018 through June 2026 on income generated from the manufacture of products at its Chonburi campus.

[0001193125-20-223682:notes:181]
After June 2020, 50% of our income generated from products manufactured at our Pinehurst campus will be exempted from tax through June 2025.

[0001193125-20-223682:notes:182]
Such preferential tax treatment is

[0001193125-20-223682:notes:183]
contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 
15 years
 from the date on which preferential tax treatment was granted. Currently, the corporate income tax rate for our Thai subsidiary is 
20
%.

[0001193125-20-223682:notes:184]
People’s Republic of China

[0001193125-20-223682:notes:185]
The corporate income tax rate for Casix is 25%.

[0001193125-20-223682:notes:186]
The United States

[0001193125-20-223682:notes:187]
The Tax Cuts and Jobs Act (“Tax Reform Act”) enacted on December 22, 2017 provided for significant changes to U.S. tax law. Among other provisions, the Tax Reform Act reduced the U.S. corporate income tax

[0001193125-20-223682:notes:188]
rate to 21% effective January 1, 2018.

[0001193125-20-223682:notes:189]
Accordingly, the Company’s U.S. subsidiaries were subject to a Federal statutory tax rate

[0001193125-20-223682:notes:190]
of 21%

[0001193125-20-223682:notes:191]
for fiscal year 2020 and fiscal year 2019.

[0001193125-20-223682:notes:192]
The United Kingdom

[0001193125-20-223682:notes:193]
The corporate income tax rate for U.K. subsidiaries is 19%.

[0001193125-20-223682:notes:194]
The Company’s income tax expense consisted of the following:

[0001193125-20-223682:notes:195]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26,2020 |  |  | June 28,2019 |  |  | June 29,2018 |  |
| Current |  | $ | 6,274 |  |  | $ | 4,384 |  |  | $ | 5,457 |  |
| Deferred |  |  | (511 | ) |  |  | 894 |  |  |  | (1,595 | ) |
| Total income tax expense |  | $ | 5,763 |  |  | $ | 5,278 |  |  | $ | 3,862 |  |

[0001193125-20-223682:notes:196]
The reconciliation between the Company’s taxes that would arise by applying the statutory tax rate of the country of the Company’s principal operations, Thailand, to the Company’s effective tax charge is shown below:

[0001193125-20-223682:notes:197]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26,2020 |  |  | June 28,2019 |  |  | June 29,2018 |  |
| Income before income taxes (1) |  | $ | 119,242 |  |  | $ | 126,233 |  |  | $ | 88,029 |  |
| Tax expense calculated at a statutory corporate income tax rate of 20% |  |  | 23,848 |  |  |  | 25,247 |  |  |  | 17,606 |  |
| Effect of income taxes from locations with tax rates different from Thailand |  |  | 577 |  |  |  | 977 |  |  |  | 2,657 |  |
| Income not subject to tax (2) |  |  | (20,797 | ) |  |  | (21,161 | ) |  |  | (12,824 | ) |
| Income tax on unremitted earnings |  |  | 1,221 |  |  |  | 1,260 |  |  |  | 1,007 |  |
| Effect of different tax rate in relation to deferred tax utilization |  |  | — |  |  |  | — |  |  |  | 423 |  |
| Effect of foreign exchange rate adjustment |  |  | 382 |  |  |  | 603 |  |  |  | (134 | ) |
| Tax rebate from research and development application |  |  | (1,228 | ) |  |  | (649 | ) |  |  | (454 | ) |
| Provision for uncertain income tax position |  |  | (641 | ) |  |  | (229 | ) |  |  | 277 |  |
| Utilization of loss carryforward |  |  | — |  |  |  | — |  |  |  | (3,224 | ) |
| Valuation allowance (reversal of) |  |  | 2,446 |  |  |  | — |  |  |  | (1,587 | ) |
| Others |  |  | (45 | ) |  |  | (770 | ) |  |  | 115 |  |
| Corporate income tax expense |  | $ | 5,763 |  |  | $ | 5,278 |  |  | $ | 3,862 |  |

[0001193125-20-223682:notes:198]
| (1) | Income before income taxes was mostly generated from domestic income in the Cayman Islands. |

[0001193125-20-223682:notes:199]
| (2) | Income not subject to tax relates to income earned in the Cayman Islands and income subject to an investment promotion privilege for Pinehurst Building 6 and the Company’s Chonburi campus. Income not subject to tax per ordinary share on a diluted basis was $0.55, $0.57, and $0.34 for the years ended June 26, 2020, June 28, 2019, and June 29, 2018, respectively. |

[0001193125-20-223682:notes:200]
The Company’s deferred tax assets and deferred tax liabilities, net of valuation allowance, at each balance sheet date are as follows:

[0001193125-20-223682:notes:201]
|  |  | As of |  |
| (amount in thousands) |  | June 26,2020 |  |  | June 28,2019 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Depreciation |  | $ | 1,219 |  |  | $ | 1,957 |  |
| Severance liability |  |  | 2,958 |  |  |  | 2,012 |  |
| Reserves and allowance |  |  | 1,405 |  |  |  | 1,485 |  |
| Net operating loss carryforwards |  |  | — |  |  |  | 1,616 |  |
| Others |  |  | 321 |  |  |  | 13 |  |
| Total |  | $ | 5,903 |  |  | $ | 7,083 |  |

[0001193125-20-223682:notes:202]
|  |  | As of |  |
| (amount in thousands) |  | June 26,2020 |  |  | June 28,2019 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Temporary differences from intangibles and changes in the fair value of assets acquired |  | $ | (336 | ) |  | $ | (590 | ) |
| Deferred tax from unremitted earnings |  |  | (4,620 | ) |  |  | (4,123 | ) |
| Others |  |  | — |  |  |  | (252 | ) |
| Total |  |  | (4,956 | ) |  |  | (4,965 | ) |
| Net |  | $ | 947 |  |  | $ | 2,118 |  |

[0001193125-20-223682:notes:203]
The changes in the valuation allowances of deferred tax assets were as follows:

[0001193125-20-223682:notes:204]
| (amount in thousands) |  | Valuation allowances ofdeferred tax assets |  |
| Balance as of June 30, 2017 |  | $ | 6,399 |  |
| Reversal |  |  | (5,234 | ) |
| Balance as of June 29, 2018 |  |  | 1,165 |  |
| Additional |  |  | 126 |  |
| Balance as of June 28, 2019 |  |  | 1,291 |  |
| Additional |  |  | 2,437 |  |
| Balance as of June 26, 2020 |  | $ | 3,728 |  |

[0001193125-20-223682:notes:205]
During fiscal year 2018, one of the Company’s subsidiaries in the U.S. generated taxable income sufficient for the utilization of loss carryforwards due to better operating performance and effective control of operating expenses and management determined that it was more likely than not that future taxable income would be sufficient to allow the benefit of the loss to be realized. As of June 29, 2018, such subsidiary in the U.S. reversed certain deferred tax assets valuation allowance as management expected it was more likely than not that such subsidiary would realize profits in subsequent fiscal years so that the loss carryforwards could be partially utilized. Consequently, as of June 28, 2019, such subsidiary have assessed and set up a partial valuation allowance for the deferred tax assets at the same level as in fiscal year 2018. However, in fiscal year 2020, such subsidiary in the U.S. generated net operating loss and management expected that such subsidiary would continue to have net operating losses in the foreseeable future; therefore, management believes it is more likely than not that all of the deferred tax assets of such subsidiary will not be utilized. Thus, a full valuation allowance of $ 2.1 million for the deferred tax assets was set up as of June 26, 2020.

[0001193125-20-223682:notes:206]
During fiscal year 2020, one of the Company’s subsidiaries in the U.K. also generated net operating loss and management expected that such subsidiary

[0001193125-20-223682:notes:207]
would continue to have net operating losses in the foreseeable future; therefore, management believes it is more likely than not that all of the deferred tax assets of such 
subsidiary
 will not be utilized
.

[0001193125-20-223682:notes:208]
Thus
, a full valuation allowance 
of $1.6 million 
for the deferred tax assets was set up as of June 26, 2020

[0001193125-20-223682:notes:209]
Income tax liabilities have not been established for withholding tax and other taxes that would be payable on the unremitted earnings of Fabrinet Thailand. Such amounts of Fabrinet Thailand are permanently reinvested; unremitted earnings for Fabrinet Thailand totaled $112.3 million and $109.7 million as of June 26, 2020 and June 28, 2019, respectively. Unrecognized deferred tax liabilities for such unremitted earnings were $7.0 million and $6.9 million as of June 26, 2020 and June 28, 2019, respectively.

[0001193125-20-223682:notes:210]
Deferred tax liabilities of $1.1 million and $1.3 million have been established for withholding tax on the unremitted earnings of Casix for the years ended June 26, 2020 and June 28, 2019, respectively, which are included in 
non-current
 deferred tax liability in the consolidated balance sheets.

[0001193125-20-223682:notes:211]
Uncertain income tax positions

[0001193125-20-223682:notes:212]
Interest and penalties related to uncertain income tax positions are recognized in income tax expense. The Company had approximately $0.5 million and $0.8 million of accrued interest and penalties related to uncertain income tax positions on the consolidated balance sheets as of June 26, 2020 and June 28, 2019, respectively. The Company 
recorded 
(reversed) interest and penalties of $0.1 million, $(0.1) million and $0.3 million for the years ended June 26, 2020, June 28, 2019 and June 29, 2018, respectively, in the consolidated statements of operations and comprehensive income. With regard to the Thailand jurisdiction, tax years 2015 through 2019 remain open to examination by the local authorities.

[0001193125-20-223682:notes:213]
The following table indicates the changes to the Company’s uncertain income tax positions for the years ended June 26, 2020, June 28, 2019 and June 29, 2018 included in other 
non-current
 liabilities.

[0001193125-20-223682:notes:214]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26,2020 |  |  | June 28,2019 |  |  | June 29,2018 |  |
| Beginning balance |  | $ | 1,323 |  |  | $ | 1,445 |  |  | $ | 1,420 |  |
| Additions during the year |  |  | 157 |  |  |  | 235 |  |  |  | 25 |  |
| Release of tax positions of prior years |  |  | (510 | ) |  |  | (357 | ) |  |  | — |  |
| Ending balance |  | $ | 970 |  |  | $ | 1,323 |  |  | $ | 1,445 |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-20-223682:notes:215]
5.    Earnings per ordinary share

[0001193125-20-223682:notes:216]
Basic earnings per ordinary share is computed by dividing reported net income by the weighted average number of ordinary shares outstanding during each period. Diluted earnings per ordinary share is computed by calculating the effect of potential dilutive ordinary shares outstanding during the year using the treasury stock method. Dilutive ordinary equivalent shares consist of share options, restricted share units and performance share units. The earnings per ordinary share was calculated as follows:

[0001193125-20-223682:notes:217]
|  |  | Years Ended |  |
| (amount in thousands except per share amounts) |  | June 26,2020 |  |  | June 28,2019 |  |  | June 29,2018 |  |
| Net income attributable to shareholders |  | $ | 113,479 |  |  | $ | 120,955 |  |  | $ | 84,167 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  | 36,908 |  |  |  | 36,798 |  |  |  | 37,257 |  |
| Incremental shares arising from the assumed exercise of share options and vesting of restricted share units and performance share units (thousands of shares) |  |  | 757 |  |  |  | 617 |  |  |  | 778 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 37,665 |  |  |  | 37,415 |  |  |  | 38,035 |  |
| Basic earnings per ordinary share |  | $ | 3.07 |  |  | $ | 3.29 |  |  | $ | 2.26 |  |
| Diluted earnings per ordinary share |  | $ | 3.01 |  |  | $ | 3.23 |  |  | $ | 2.21 |  |
| Outstanding performance share units excluded from the computation of diluted earnings per ordinary share (thousands of shares) (1) |  |  | 99 |  |  |  | 401 |  |  |  | 284 |  |

[0001193125-20-223682:notes:218]
| (1) | These performance share units were not included in the computation of diluted earnings per ordinary share because they are not expected to vest based on the Company’s current assessment of the related performance obligations. |


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001193125-20-223682:notes:219]
| 6. | Cash, cash equivalents and short-term investments |

[0001193125-20-223682:notes:220]
The Company’s cash, cash equivalents,

[0001193125-20-223682:notes:221]
and short-term investments by category is as follows:

[0001193125-20-223682:notes:222]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Gain/ (Loss) |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |  | Other Investments |  |
| As of June 26, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 218,117 |  |  | $ | — |  |  | $ | 218,117 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 7,313 |  |  |  | — |  |  |  | 7,313 |  |  |  | — |  |  |  | — |  |
| Liquidity funds |  |  | 41,051 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 41,051 |  |
| Certificates of deposit and time deposits |  |  | 11,800 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 11,800 |  |
| Corporate debt securities |  |  | 159,220 |  |  |  | 948 |  |  |  | — |  |  |  | 160,168 |  |  |  | — |  |
| U.S. agency and U.S. Treasury securities |  |  | 49,130 |  |  |  | 544 |  |  |  | — |  |  |  | 49,674 |  |  |  | — |  |
| Total |  | $ | 486,631 |  |  | $ | 1,492 |  |  | $ | 225,430 |  |  | $ | 209,842 |  |  | $ | 52,851 |  |
| As of June 28, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 178,019 |  |  | $ | — |  |  | $ | 178,019 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 2,820 |  |  |  | — |  |  |  | 2,820 |  |  |  | — |  |  |  | — |  |
| Liquidity funds |  |  | 20,552 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 20,552 |  |
| Certificates of deposit and time deposits |  |  | 35,028 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 35,028 |  |
| Corporate debt securities |  |  | 130,959 |  |  |  | 297 |  |  |  | — |  |  |  | 131,256 |  |  |  | — |  |
| U.S. agency and U.S. Treasury securities |  |  | 69,552 |  |  |  | 105 |  |  |  | — |  |  |  | 69,657 |  |  |  | — |  |
| Total |  | $ | 436,930 |  |  | $ | 402 |  |  | $ | 180,839 |  |  | $ | 200,913 |  |  | $ | 55,580 |  |

[0001193125-20-223682:notes:223]
The cash equivalents include short-term bank deposits, investments in money market funds, and marketable securities with maturities of three months or less at the date of purchase. The effective interest rate on short term bank deposits was 1.8% and 1.9% per annum for the years ended June 26, 2020 and June 28, 2019, respectively.

[0001193125-20-223682:notes:224]
As of June 26, 2020 and June 28, 2019, 63% and 58%, respectively, of our cash and cash equivalents were held by the Parent Company.

[0001193125-20-223682:notes:225]
The following table summarizes the cost and estimated fair value of short-term investments classified as

[0001193125-20-223682:notes:226]
securities based on stated effective maturities as of June 26, 2020:

[0001193125-20-223682:notes:227]
|  |  | June 26, 2020 |  |  | June 28, 2019 |  |
| (amount in thousands) |  | Carrying Cost |  |  | Fair Value |  |  | Carrying Cost |  |  | Fair Value |  |
| Due within one year |  | $ | 76,127 |  |  | $ | 76,196 |  |  | $ | 69,746 |  |  | $ | 69,830 |  |
| Due between one to five years |  |  | 132,223 |  |  |  | 133,646 |  |  |  | 130,765 |  |  |  | 131,083 |  |
| Total |  | $ | 208,350 |  |  | $ | 209,842 |  |  | $ | 200,511 |  |  | $ | 200,913 |  |

[0001193125-20-223682:notes:228]
During the year ended June 26, 2020, the Company recognized a realized gain of $0.1 million from sales and maturities of

[0001193125-20-223682:notes:229]
securities.

[0001193125-20-223682:notes:230]
As of June 26, 2020 and June 28, 2019, the Company considered the decline in market value of its short-term investments portfolio to be temporary in nature and did not consider any of its securities other-than-temporarily impaired. The Company typically invests in highly-rated securities, and its investment policy

[0001193125-20-223682:notes:231]
generally limits the amount of credit exposure to any one issuer. The policy requires investments generally to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. When evaluating an investment for other-than-temporary impairment, the Company reviews factors such as the length of time and extent to which fair value has been below its cost basis, the financial condition of the issuer and any changes thereto, changes in market interest rates, and the Company’s intent to sell, or whether it is more likely than not it will be required to sell, the investment before recovery of the investment’s cost basis. No impairment losses were recorded for the years ended June 26, 2020 and June 28, 2019.


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-20-223682:notes:232]
| 7. | Fair value of financial instruments |

[0001193125-20-223682:notes:233]
Fair value is defined as the exchange price that would be recei
v
ed for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. A fair value hierarchy is established, which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs for the valuation of an asset or liability as of the measurement date. The three levels of inputs that may be used to measure fair value are defined as follows:

[0001193125-20-223682:notes:234]
Level 2 inputs are inputs other than quoted prices included within Level 1 that are observable for assets or liabilities, either directly or indirectly. If the assets or liabilities have a specified (contractual) term, Level 2 inputs must be observable for substantially the full term of assets or liabilities.

[0001193125-20-223682:notes:235]
Level 3 inputs are unobservable inputs for assets or liabilities, which require the reporting entity to develop its own valuation techniques and assumptions.

[0001193125-20-223682:notes:236]
The following table provides details of

[0001193125-20-223682:notes:237]
the financial instruments measured at fair value on a recurring basis, including:

[0001193125-20-223682:notes:238]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 26, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 7,313 |  |  | $ | — |  |  | $ | 7,313 |  |
| Liquidity funds |  |  | — |  |  |  | 41,051 |  |  |  | — |  |  |  | 41,051 |  |
| Certificates of deposit and time deposits |  |  | — |  |  |  | 11,800 |  |  |  | — |  |  |  | 11,800 |  |
| Corporate debt securities |  |  | — |  |  |  | 160,168 |  |  |  | — |  |  |  | 160,168 |  |
| U.S. agency and U.S. Treasury securities |  |  | — |  |  |  | 49,674 |  |  |  | — |  |  |  | 49,674 |  |
| Derivative assets |  |  | — |  |  |  | 2,230 | (1) |  |  | — |  |  |  | 2,230 |  |
| Total |  | $ | — |  |  | $ | 272,236 |  |  | $ | — |  |  | $ | 272,236 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 5,273 | (2) |  | $ | — |  |  | $ | 5,273 |  |
| Total |  | $ | — |  |  | $ | 5,273 |  |  | $ | — |  |  | $ | 5,273 |  |

[0001193125-20-223682:notes:239]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 28, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 2,820 |  |  | $ | — |  |  | $ | 2,820 |  |
| Liquidity funds |  |  | — |  |  |  | 20,552 |  |  |  | — |  |  |  | 20,552 |  |
| Certificates of deposit and time deposits |  |  | — |  |  |  | 35,028 |  |  |  | — |  |  |  | 35,028 |  |
| Corporate debt securities |  |  | — |  |  |  | 131,256 |  |  |  | — |  |  |  | 131,256 |  |
| U.S. agency and U.S. Treasury securities |  |  | — |  |  |  | 69,657 |  |  |  | — |  |  |  | 69,657 |  |
| Derivative assets |  |  | — |  |  |  | 2,201 | (3) |  |  |  |  |  |  | 2,201 |  |
| Total |  | $ | — |  |  | $ | 261,514 |  |  | $ | — |  |  | $ | 261,514 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 2,591 | (4) |  | $ | — |  |  | $ | 2,591 |  |
| Total |  | $ | — |  |  | $ | 2,591 |  |  | $ | — |  |  | $ | 2,591 |  |

[0001193125-20-223682:notes:240]
| (1) | Foreign currency forward contracts with a notional amount of $125.0 million and Canadian dollars of 0.6 million, and option contract with a notional amount of $1.0 million. |

[0001193125-20-223682:notes:241]
| (2) | Interest rate swap agreements with an aggregate notional amount of $125.1 million. |

[0001193125-20-223682:notes:242]
| (3) | Foreign currency forward contracts with notional amount of $72.0 million and Canadian dollars of $0.6 million. |

[0001193125-20-223682:notes:243]
| (4) | Interest rate swap agreement with a notional amount of $64.2 million. |

[0001193125-20-223682:notes:244]
Derivative financial instruments

[0001193125-20-223682:notes:245]
The Company utilizes derivative financial instruments to hedge (i) foreign exchange risk associated with certain foreign currency denominated assets and liabilities and other foreign currency transactions, and (ii) interest rate risk associated with its long-term debt.

[0001193125-20-223682:notes:246]
The Company minimizes the credit risk associated with its derivative instruments by limiting the exposure to any single counterparty and by entering into derivative instruments only with counterparties that meet the Company’s minimum credit quality standard.

[0001193125-20-223682:notes:247]
Foreign currency forward and option contracts

[0001193125-20-223682:notes:248]
As a result of foreign currency rate fluctuations, the U.S. dollar equivalent values of the Company’s foreign currency denominated assets and liabilities fluctuate. The Company uses foreign currency forward and option contracts to manage the foreign exchange risk associated with a portion of its foreign currency denominated assets and liabilities and other foreign currency transactions. The Company enters into foreign currency forward and option contracts to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht and Canadian dollars with counterparties that meet the Company’s minimum credit quality standard.

[0001193125-20-223682:notes:249]
The Company may enter into foreign currency forward contracts 
with maturi
ties of 
up to 12 months

[0001193125-20-223682:notes:250]
to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht, including inventory purchases, payroll and other operating expenses. The Company considers these forward contracts as dual-purpose hedges, that hedge both the foreign exchange fluctuation (i) from inception through the forecasted expenditure, and (ii) any subsequent revaluation of the account payable or accrual. The Company may designate the forward contracts that hedge the foreign exchange fluctuation from inception through the forecasted expenditure as cash flow hedges. The gain or loss on a derivative instrument designated and qualified as a cash flow hedging instrument is recorded as a component of other comprehensive income and reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings. The reclassified amounts are presented in the same income statement line item as the earnings effect of the hedged item. Once the forecasted transactions are recorded, the Company will

[0001193125-20-223682:notes:251]
discontinue the hedging relationship by 
de-designating
 the derivative instrument and recording subsequent changes in fair value through contract maturity to foreign exchange gain (loss), net in the consolidated statements of operations and comprehensive income as a natural hedge against the Thai baht denominated assets and liabilities.

[0001193125-20-223682:notes:252]
The Company may also enter into 
non-designated
 foreign currency forward and option contracts to provide an offset to the 
re-measurement
 of foreign currency denominated assets and liabilities and to hedge certain forecasted exposures. Changes in the fair value of these 
non-designated
 derivatives are recorded through foreign exchange gain (loss), net in the consolidated statements of operations and comprehensive income.

[0001193125-20-223682:notes:253]
As of June 26, 2020, the Company had 125 outstanding U.S. dollar foreign currency forward contracts against Thai baht with an aggregate notional amount of $125.0 million, one foreign currency contract with notional amount of Canadian dollars 0.6 million and one foreign currency option contract with notional amount of $1.0 million with maturity dates ranging from July 2020 through January 2021.

[0001193125-20-223682:notes:254]
As of June 26, 2020, hedging relationship over foreign currency forward contracts which designated for hedge accounting had been tested to be highly effective based on the performance of retrospective and prospective regression testing. During the year ended June 26, 2020, the Company recorded an unrealized gain

[0001193125-20-223682:notes:255]
of $1.1

[0001193125-20-223682:notes:256]
million 
from changes in the fair value of these foreign currency forward contracts, designated as hedging instruments, in other comprehensive income in the consolidated statements of operations and comprehensive income. A 
loss

[0001193125-20-223682:notes:257]
of $

[0001193125-20-223682:notes:258]
1.6 
million

[0001193125-20-223682:notes:259]
was reclassified from AOCI to foreign exchange gain (loss), net, cost of revenues, and selling, general and administrative expenses in the consolidated statements of operations and comprehensive income from the discontinuance of cash flow hedge. As of June 26, 2020, the amount in AOCI that is expected to be reclassified into earnings within 12 months as

[0001193125-20-223682:notes:260]
gain

[0001193125-20-223682:notes:261]
of $2.7 million
.

[0001193125-20-223682:notes:262]
During the year ended June 26, 2020, the Company included an unrealized
 loss
 of $

[0001193125-20-223682:notes:263]
1.2

[0001193125-20-223682:notes:264]
million from changes in fair value of foreign currency forward and option contracts which were not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the consolidated statements of operations and comprehensive income.

[0001193125-20-223682:notes:265]
As of June 28, 2019, the Company had 45 outstanding foreign currency forward contracts with an aggregate notional amount of $72.0 million and one foreign currency forward contract with notional amount of Canadian dollar
s

[0001193125-20-223682:notes:266]
0.6
 million

[0001193125-20-223682:notes:267]
with maturity dates from July through September 2019. These foreign currency forward contracts were not designated for hedge accounting and were used to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht and Canadian dollars. During the year

[0001193125-20-223682:notes:268]
ended June 28, 2019, the Company included unrealized

[0001193125-20-223682:notes:269]
gain of $
4.8
  million from changes in fair value of foreign currency contracts in earnings as foreign exchange gain (loss), net in the consolidated statements of operations and comprehensive income. As of June 28, 2019, the Company had no foreign currency forward contracts designated as cash flow hedges.

[0001193125-20-223682:notes:270]
Interest rate swap agreements

[0001193125-20-223682:notes:271]
The Company entered into interest rate swap agreements to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. As of June 26, 2020, the Company had two outstanding interest rate swap agreements with an aggregate notional amount of $125.1 million. As of June 28, 2019, the Company had one outstanding interest rate swap agreement with a notional amount of $64.2 million.

[0001193125-20-223682:notes:272]
On July 25, 2018, Fabrinet Thailand entered into an interest rate swap agreement to effectively convert the floating interest rate of its term loan under the credit facility agreement with Bank of America (the “BofA Facility Agreement”) to a fixed interest rate

[0001193125-20-223682:notes:273]
of 
2.86
% per

[0001193125-20-223682:notes:274]
annum through the scheduled maturity of the term loan in June 2023 (see Note 16). The Company did not designate this interest rate swap for hedge accounting.

[0001193125-20-223682:notes:275]
On September 3, 2019, the Company drew down a term loan under a new Credit Facility Agreement with the Bank of Ayudhya Public Company Limited (the “Bank”) (see Note 16) and on September 10, 2019, repaid in full the outstanding term loan under the BofA Facility Agreement (see Note 16). In conjunction with the funding of the new term loan, the Company entered into a second interest rate swap agreement. The

[0001193125-20-223682:notes:276]
combination of both of these interest rate swaps effectively convert the floating interest rate of the Company’s term loan with the Bank to a fixed interest rate of 4.36% per annum through the maturity of the term loan in June 2024.

[0001193125-20-223682:notes:277]
On September 27, 2019, the Company designated these two interest rate swaps as a cash flow hedge for the Company’s term loan under the Credit Facility Agreement with the Bank. The combination of these two interest rate swaps qualified for hedge accounting based on a regression testing result which proved the hedges are highly effective. In addition, the Company has designated and documented contemporaneously the hedging relationships involving these interest rate swaps. At least quarterly, the Company performs a qualitative effectiveness test on the interest rate swaps to support the continued application of hedge accounting. As of June 26, 2020, the hedging relationship was determined to be highly effective based on the performance of a qualitative effectiveness testing. While the Company intends to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in earnings. From September 27, 2019, any gains or losses related to these interest rate swaps will be recorded in AOCI in the consolidated balance sheets, with a portion reclassified from AOCI into earnings at each reporting period based on either the accrued interest amount or the interest payment.

[0001193125-20-223682:notes:278]
As of June 26, 2020, the amount in AOCI that is expected to be reclassified into earnings within 12 months

[0001193125-20-223682:notes:279]
as loss 
is
 $0.3 million.

[0001193125-20-223682:notes:280]
Prior to September 27, 2019, these interest rate swaps were not designated as cash flow hedges and all changes in the fair value of these interest rate swaps were reflected in earnings. During the year
s
 ended June 26, 2020 and June 28, 2019, the Company recorded unrealized loss of $1.7 million and $2.6 million, respectively, from changes in the fair value of these interest rate swaps as interest expense in the consolidated statements of operations and comprehensive income.

[0001193125-20-223682:notes:281]
The following table provides a summary of the impact of derivative gain (loss) of the Company’s foreign currency forward contracts and interest rate swaps which were designated as cash flow hedges on the consolidated statements of operations and other comprehensive income:

[0001193125-20-223682:notes:282]
|  |  |  |  | Year Ended |  |
| (amount in thousands) |  | Financial statements line item |  | June 26, 2020 |  |  | June 28, 2019 |  |
| Derivatives gain (loss) recognized in other comprehensive income: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | Other comprehensive income |  | $ | 1,081 |  |  | $ | — |  |
| Interest rate swaps |  | Other comprehensive income |  |  | (910 | ) |  |  | — |  |
| Total derivatives gain recognized in other comprehensive income |  |  |  | $ | 171 |  |  | $ | — |  |
| Derivatives loss (gain) reclassified from accumulated other comprehensive income into earnings: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  | Cost of revenues |  | $ | 2,512 |  |  | $ | — |  |
| Foreign currency forward contracts |  | Selling, general and administrative expenses |  |  | 105 |  |  |  | — |  |
| Foreign currency forward contracts |  | Foreign exchange gain (loss), net |  |  | (998 | ) |  |  | — |  |
| Interest rate swaps |  | Interest expense |  |  | (1,220 | ) |  |  | — |  |
| Total derivatives loss reclassified from accumulated other comprehensive income into earnings |  |  |  | $ | 399 |  |  | $ | — |  |
| Change in net unrealized gain on derivative instruments |  |  |  | $ | 570 |  |  | $ | — |  |

[0001193125-20-223682:notes:283]
Fair value of derivatives

[0001193125-20-223682:notes:284]
The following table provides the fair values of the Company’s derivative financial instruments for the periods presented:

[0001193125-20-223682:notes:285]
|  |  | June 26, 2020 |  |  | June 28, 2019 |  |
| (amount in thousands) |  | Derivative Assets |  |  | Derivative Liabilities |  |  | Derivative Assets |  |  | Derivative Liabilities |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts |  | $ | 9 |  |  | $ | (611 | ) |  | $ | 2,201 |  |  | $ | — |  |
| Interest rate swaps |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (2,591 | ) |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  |  | 2,814 |  |  |  | (83 | ) |  |  | — |  |  |  | — |  |
| Interest rate swaps |  |  | — |  |  |  | (5,172 | ) |  |  | — |  |  |  | — |  |
| Derivatives, gross balances |  |  | 2,823 |  |  |  | (5,866 | ) |  |  | 2,201 |  |  |  | (2,591 | ) |
| Derivatives, gross balances offset in the balance sheet |  |  | (593 | ) |  |  | 593 |  |  |  | — |  |  |  | — |  |
| Derivatives, net balances |  | $ | 2,230 |  |  | $ | (5,273 | ) |  | $ | 2,201 |  |  | $ | (2,591 | ) |

[0001193125-20-223682:notes:286]
The Company presents its derivatives at net fair values in the consolidated balance sheets.

[0001193125-20-223682:notes:287]
The Company’s netting arrangements allow net settlements under certain conditions. The Company’s derivative instruments are typically settled monthly or quarterly.

[0001193125-20-223682:notes:288]
The Company recorded the fair value of derivative financial instruments in the consolidated balance sheets as follows:

[0001193125-20-223682:notes:289]
| Derivative Financial Instruments |  | Balance Sheet Line Item |
| Fair Value of Derivative Assets |  | Other current assets |
| Fair Value of Derivative Liabilities |  | Accrued expenses |


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001193125-20-223682:notes:290]
| 8. | Trade accounts receivable, net |

[0001193125-20-223682:notes:291]
| (amount in thousands) |  | As of June 26, 2020 |  |  | As of June 28, 2019 |  |
| Trade accounts receivable |  | $ | 273,001 |  |  | $ | 260,698 |  |
| Less: Allowance for doubtful account |  |  | (336 | ) |  |  | (96 | ) |
| Trade accounts receivable, net |  | $ | 272,665 |  |  | $ | 260,602 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-20-223682:notes:292]
| 9. | Inventories |

[0001193125-20-223682:notes:293]
| (amount in thousands) |  | As of June 26, 2020 |  |  | As of June 28, 2019 |  |
| Raw materials |  | $ | 141,522 |  |  | $ | 113,321 |  |
| Work in progress |  |  | 136,344 |  |  |  | 141,730 |  |
| Finished goods |  |  | 17,950 |  |  |  | 24,916 |  |
| Goods in transit |  |  | 13,970 |  |  |  | 13,645 |  |
| Inventories |  | $ | 309,786 |  |  | $ | 293,612 |  |


## fn:ScheduleOfOtherReceivableTextBlock

[0001193125-20-223682:notes:294]
| 10. | Other receivable |

[0001193125-20-223682:notes:295]
On October 1, 2019, the Company provided funds in the amount of $24.3 million to a customer to support the customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. The customer has agreed to repay this amount by September 30, 2020. As of June 26, 2020, the Company recorded the $24.3 million funds as other receivable in the consolidated balance sheet. For the year ended June 26, 2020, the Company classified these funds as an investing activity in the consolidated statement of cash flows.


## fn:RestrictedCashAndCashEquivalentsTextBlock

[0001193125-20-223682:notes:296]
| 11. | Restricted cash |

[0001193125-20-223682:notes:297]
As of June 26, 2020 and June 28, 2019, the Company had one outstanding standby letter of credit of 6.0 million Euros related to the Company’s support of a customer with the transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. As of June 26, 2020 and June 28, 2019, the standby letter of credit was backed by cash collateral of $7.4 million.


## fn:FutureMinimumLeasePaymentsDueUnderNoncancelableOperatingLeasesTableTextBlock

[0001193125-20-223682:notes:298]
Amounts of minimum future annual commitments under 
non-cancelable
 operating and finance leases in accordance with ASC 840 were as follows:

[0001193125-20-223682:notes:299]
|  |  | As of June 28, 2019 |  |
| (amount in thousands) |  | Operating leases |  |  | Finance leases |  |  | Total |  |
| 2020 |  | $ | 1,746 |  |  | $ | 398 |  |  | $ | 2,144 |  |
| 2021 |  |  | 1,342 |  |  |  | 102 |  |  |  | 1,444 |  |
| 2022 |  |  | 1,219 |  |  |  | — |  |  |  | 1,219 |  |
| 2023 |  |  | 1,172 |  |  |  | — |  |  |  | 1,172 |  |
| Thereafter |  |  | 230 |  |  |  | — |  |  |  | 230 |  |
| Total future minimum operating lease payments |  | $ | 5,709 |  |  | $ | 500 |  |  | $ | 6,209 |  |


## fn:ScheduleOfAdoptionOfTopic842OnOperatingLeaseInConsolidateFinancialPositionTableTextBlock

[0001193125-20-223682:notes:300]
The

[0001193125-20-223682:notes:301]
following table shows the impact of adoption of ASC 842 on the adoption date of June 29, 2019 on the consolidated balance sheets:

[0001193125-20-223682:notes:302]
Consolidated Balance Sheets

[0001193125-20-223682:notes:303]
|  |  | Impact of Adopting ASC 842 |  |
| (amount in thousands) |  | Balance at June 28, 2019 |  |  | Adjustment |  |  | Balance at June 29, 2019 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating lease ROU assets |  | $ | — |  |  | $ | 5,370 |  |  | $ | 5,370 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating lease liabilities, current |  | $ | — |  |  | $ | 1,601 |  |  | $ | 1,601 |  |
| Operating lease liabilities, non-current |  | $ | — |  |  | $ | 3,769 |  |  | $ | 3,769 |  |


## us-gaap:LesseeOperatingLeaseLiabilityMaturityTableTextBlock

[0001193125-20-223682:notes:304]
As of June 26, 2020, the maturities of the Company’s operating lease liabilities were as follows:

[0001193125-20-223682:notes:305]
| (amount in thousands) |  |  |  |
| 2021 |  | $ | 2,313 |  |
| 2022 |  |  | 2,314 |  |
| 2023 |  |  | 2,200 |  |
| 2024 |  |  | 1,176 |  |
| 2025 |  |  | 288 |  |
| Thereafter |  |  | 157 |  |
| Total undiscounted lease payments |  |  | 8,448 |  |
| Less imputed interest |  |  | (596 | ) |
| Total present value of lease liabilities |  | $ | 7,852 | (1) |

[0001193125-20-223682:notes:306]
|  | (1) | Includes current portion of operating lease liabilities of $2.0 million. |

[0001193125-20-223682:notes:307]
Rental expense related to the Company’s operating leases is recognized on a straight-line basis over the lease term. Rental expense for long-term leases for the year ended June 26, 2020, June 28, 2019 and June 29, 2018 was $2.1 million, $1.9 million and $1.8 million, respectively. Rental expense for short-term leases for the year ended June 26, 2020, June 28, 2019 and June 29, 2018 was $0.2 million, $0.1 million and de minimis amount, respectively.


## fn:ScheduleOfAdditionalInformationRelatedToOperatingAndFinanceLeaseTableTextBlock

[0001193125-20-223682:notes:308]
The following summarizes additional information related to the Company’s operating leases and finance leases:

[0001193125-20-223682:notes:309]
|  |  | As of June 26, 2020 |  |
| Weighted-average remaining lease term (in years) |  |  |  |  |
| Operating leases |  |  | 3.3 |  |
| Finance leases |  |  | 0.3 |  |
| Weighted-average discount rate |  |  |  |  |
| Operating leases |  |  | 3.7 | % |
| Finance leases |  |  | 4.1 | % |


## fn:ScheduleOfSupplementalCashFlowInformationRelatedToOperatingLeaseTableTextBlock

[0001193125-20-223682:notes:310]
The following information represents supplemental disclosure for the statement of cash flows related to operating and finance leases:

[0001193125-20-223682:notes:311]
| (amount in thousands) |  | Year Ended June 26, 2020 |  |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |
| Operating cash flows from operating leases |  | $ | 2,326 |  |
| Financing cash flows from finance leases |  | $ | 400 |  |
| ROU assets obtained in exchange for lease liabilities |  | $ | 8,068 |  |
| Finance lease assets |  | $ | 80 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001193125-20-223682:notes:312]
| 13. | Property, plant and equipment, net |

[0001193125-20-223682:notes:313]
The components of property, plant and equipment, net were as follows:

[0001193125-20-223682:notes:314]
| (amount in thousands) |  | Land and Land Improvements |  |  | Building and Building Improvements |  |  | Manufacturing Equipment |  |  | Office Equipment |  |  | Motor Vehicles |  |  | Computers |  |  | Construction and Machinery Under Installation |  |  | Total |  |
| As of June 26, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost |  | $ | 45,099 |  |  | $ | 145,912 |  |  | $ | 198,036 |  |  | $ | 5,600 |  |  | $ | 939 |  |  | $ | 16,766 |  |  | $ | 12,657 |  |  | $ | 425,009 |  |
| Less: Accumulated depreciation |  |  | (17 | ) |  |  | (51,393 | ) |  |  | (127,397 | ) |  |  | (4,135 | ) |  |  | (678 | ) |  |  | (12,273 | ) |  |  | — |  |  |  | (195,893 | ) |
| Less: Impairment reserve |  |  | — |  |  |  | — |  |  |  | (840 | ) |  |  | — |  |  |  | — |  |  |  | (2 | ) |  |  | — |  |  |  | (842 | ) |
| Net book value |  | $ | 45,082 |  |  | $ | 94,519 |  |  | $ | 69,799 |  |  | $ | 1,465 |  |  | $ | 261 |  |  | $ | 4,491 |  |  | $ | 12,657 |  |  | $ | 228,274 |  |
| As of June 28, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost |  | $ | 45,080 |  |  | $ | 142,909 |  |  | $ | 163,795 |  |  | $ | 5,029 |  |  | $ | 870 |  |  | $ | 13,987 |  |  | $ | 10,815 |  |  | $ | 382,485 |  |
| Less: Accumulated depreciation |  |  | (11 | ) |  |  | (44,736 | ) |  |  | (110,980 | ) |  |  | (3,656 | ) |  |  | (658 | ) |  |  | (10,900 | ) |  |  | — |  |  |  | (170,941 | ) |
| Less: Impairment reserve |  |  | — |  |  |  | — |  |  |  | (856 | ) |  |  | — |  |  |  | — |  |  |  | (2 | ) |  |  | — |  |  |  | (858 | ) |
| Net book value |  | $ | 45,069 |  |  | $ | 98,173 |  |  | $ | 51,959 |  |  | $ | 1,373 |  |  | $ | 212 |  |  | $ | 3,085 |  |  | $ | 10,815 |  |  | $ | 210,686 |  |

[0001193125-20-223682:notes:315]
Leased assets included in manufacturing equipment comprise certain machine and equipment from finance lease agreements assumed from the acquisition of Fabrinet UK.

[0001193125-20-223682:notes:316]
| (amount in thousands) |  | As of June 26, 2020 |  |  | As of June 28, 2019 |  |
| Cost—Finance leases |  | $ | 1,992 |  |  | $ | 2,034 |  |
| Less: Accumulated depreciation |  |  | (1,199 | ) |  |  | (1,090 | ) |
| Net book value |  | $ | 793 |  |  | $ | 944 |  |

[0001193125-20-223682:notes:317]
Depreciation expense amounted to $
29.7
 million, $
28.7
 million and $
27.4
 million for the years ended June 
26
, 
2020
, June 
28
, 
2019
 and June 
29
, 
2018
, respectively, and has been allocated between cost of revenues and selling, general and administrative expenses in the consolidated statements of operations and comprehensive income.

[0001193125-20-223682:notes:318]
The cost of fully depreciated property, plant and equipment 
written-off
 during the years ended June 26, 2020, June 28, 2019 and June 29, 2018 amounted to $2.9 million, $2.0 million and $3.5 million, respectively.

[0001193125-20-223682:notes:319]
During the year
s
 ended June 26, 2020, June 28, 2019 and June 29, 2018, the Company recognized impairment reserves for property, plant and equipment of 
$0.8 million
,

[0001193125-20-223682:notes:320]
$0.9 million and zero, respectively.

[0001193125-20-223682:notes:321]
During the years ended June 26, 2020, June 28, 2019 and June 29, 2018, the Company had no borrowing costs 
capitalized
.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-20-223682:notes:322]
| 14. | Intangibles |

[0001193125-20-223682:notes:323]
The following tables present details of the Company’s intangibles:

[0001193125-20-223682:notes:324]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net |  |
| As of June 26, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 8,317 |  |  | $ | (5,577 | ) |  | $ | — |  |  | $ | 2,740 |  |
| Customer relationships |  |  | 4,373 |  |  |  | (2,691 | ) |  |  | (110 | ) |  |  | 1,572 |  |
| Backlog |  |  | 119 |  |  |  | (119 | ) |  |  | — |  |  |  | — |  |
| Total intangibles |  | $ | 12,809 |  |  | $ | (8,387 | ) |  | $ | (110 | ) |  | $ | 4,312 |  |

[0001193125-20-223682:notes:325]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net |  |
| As of June 28, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 6,582 |  |  | $ | (4,868 | ) |  | $ | — |  |  | $ | 1,714 |  |
| Customer relationships |  |  | 4,373 |  |  |  | (2,096 | ) |  |  | (104 | ) |  |  | 2,173 |  |
| Backlog |  |  | 119 |  |  |  | (119 | ) |  |  | — |  |  |  | — |  |
| Total intangibles |  | $ | 11,074 |  |  | $ | (7,083 | ) |  | $ | (104 | ) |  | $ | 3,887 |  |

[0001193125-20-223682:notes:326]
In connection with the acquisition of Fabrinet UK, the Company recorded $4.4 million of customer relationships and $0.1 million of backlog in the consolidated balance sheets. As of June 26, 2020 and June 28, 2019, the weighted-average remaining life of customer relationships was 4.6 years and 5.4 years, respectively.

[0001193125-20-223682:notes:327]
The Company recorded amortization expense relating to intangibles of $1.3 million, $1.2 million and $1.7 million for the years ended June 26, 2020, June 28, 2019 and June 29, 2018, respectively.

[0001193125-20-223682:notes:328]
Based on the carrying amount of intangibles as of June 26, 2020, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001193125-20-223682:notes:329]
| (amount in thousand) |  |  |  |
| 2021 |  | $ | 1,320 |  |
| 2022 |  |  | 1,542 |  |
| 2023 |  |  | 663 |  |
| 2024 |  |  | 434 |  |
| 2025 |  |  | 205 |  |
| Thereafter |  |  | 148 |  |
| Total |  | $ | 4,312 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-20-223682:notes:330]
| 15. | Goodwill |

[0001193125-20-223682:notes:331]
In connection with the acquisition of Fabrinet UK, the Company recorded goodwill in the consolidated balance sheets.

[0001193125-20-223682:notes:332]
The changes in the carrying amount of goodwill were as follows:

[0001193125-20-223682:notes:333]
| (amount in thousands) |  | Goodwill |  |
| Balance as of June 28, 2019 |  | $ | 3,705 |  |
| Impairment charge |  |  | (3,514 | ) |
| Foreign currency translation adjustment |  |  | (191 | ) |
| Balance as of June 26, 2020 |  | $ | — |  |

[0001193125-20-223682:notes:334]
As of June 26, 2020, the Company performed the annual impairment test for goodwill. The impairment test includes both qualitative and quantitative factors to assess the likelihood of an impairment. The reporting

[0001193125-20-223682:notes:335]
unit’s carrying value used in an impairment test represents the assignment of various assets and liabilities. Qualitative factors include industry and market considerations, overall financial performance, and other relevant events and factors affecting the reporting unit. The quantitative impairment test was performed by using an income approach. Fair value is estimated based on the discounted cash flow model that the subject assets can be expected to generate over their remaining useful life. Key assumptions used to determine projected cash flow were revenue growth rate, estimated costs and operating expenses and discount rates based on a reporting unit’s weighted average cost of capital. As a result of goodwill impairment testing, the carrying amount of the reporting unit exceeded its fair value, and the Company recognized goodwill impairment loss of $3.5 million in selling, general and administrative expenses in the consolidated statements of operations and comprehensive income. As of June 28, 2019, no goodwill impairment had been recognized.


## us-gaap:DebtDisclosureTextBlock

[0001193125-20-223682:notes:336]
| 16. | Borrowings |

[0001193125-20-223682:notes:337]
The Company’s total borrowings, including current and 
non-current
 portions of long-term borrowings, consisted of the following:

[0001193125-20-223682:notes:338]
(amount in thousands)

[0001193125-20-223682:notes:339]
| Rate |  | Conditions |  |  | Maturity |  |  | As ofJune 26, 2020 |  |  | As ofJune 28, 2019 |  |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  |  |  |  |  |  | $ | 12,188 |  |  | $ | 3,250 |  |
| Less: Unamortized debt issuance costs—current portion |  |  |  |  |  |  |  |  |  |  | (32 | ) |  |  | — |  |
| Long-term borrowings, current portion, net |  |  |  |  |  |  |  |  |  | $ | 12,156 |  |  |  | 3,250 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1-month LIBOR +1.50% per annum (1) |  |  | Repayable inquarterly installments |  |  |  | June 2023 |  |  | $ | — |  |  | $ | 60,938 |  |
| 3-month LIBOR +1.35% per annum (1) |  |  | Repayable inquarterly installments |  |  |  | June 2024 |  |  |  | 51,797 |  |  |  | — |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (12,188 | ) |  |  | (3,250 | ) |
| Less: Unamortized debt issuance costs—non-current portion |  |  |  |  |  |  |  |  |  |  | (95 | ) |  |  | — |  |
| Long-term borrowings, non-current portion, net |  |  |  |  |  |  |  |  |  | $ | 39,514 |  |  | $ | 57,688 |  |

[0001193125-20-223682:notes:340]
|  | (1) | We have entered into interest rate swaps that effectively fix a series of our future interest payments on our term loans. Refer to Note 7. |

[0001193125-20-223682:notes:341]
The movements of long-term borrowings were as follows for the years ended June 26, 2020 and June 28, 2019:

[0001193125-20-223682:notes:342]
|  |  | Years ended |  |
| (amount in thousands) |  | June 26,2020 |  |  | June 28,2019 |  |
| Opening balance |  | $ | 60,938 |  |  | $ | 64,188 |  |
| Borrowings during the period |  |  | 60,938 |  |  |  | — |  |
| Repayments during the period |  |  | (70,079 | ) |  |  | (3,250 | ) |
| Closing balance |  | $ | 51,797 |  |  | $ | 60,938 |  |

[0001193125-20-223682:notes:343]
As of June 26, 2020, the future maturities of long-term borrowings during each fiscal year were as follows:

[0001193125-20-223682:notes:344]
| (amount in thousand) |  |  |  |
| 2021 |  | $ | 12,188 |  |
| 2022 |  |  | 15,233 |  |
| 2023 |  |  | 12,188 |  |
| 2024 |  |  | 12,188 |  |
| Total |  | $ | 51,797 |  |

[0001193125-20-223682:notes:345]
Credit facilities agreements:

[0001193125-20-223682:notes:346]
Bank of Ayudhya Public Company Limited

[0001193125-20-223682:notes:347]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

[0001193125-20-223682:notes:348]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a Term Loan Agreement pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the

[0001193125-20-223682:notes:349]
BofA Facility Agreement.

[0001193125-20-223682:notes:350]
The term loan accrues interest at 
3-month
 LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be 
re-borrowed.
 During the year ended June 26, 2020, the Company recorded $1.5 million of interest expense in connection with this term loan.

[0001193125-20-223682:notes:351]
Any borrowings under the Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

[0001193125-20-223682:notes:352]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt to equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of June 26, 2020, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

[0001193125-20-223682:notes:353]
The events of default in the Term Loan Agreement include failure to pay amounts due under the Term Loan Agreement or the related finance documents when due, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

[0001193125-20-223682:notes:354]
At June 26, 2020, there was $51.8 million outstanding under the term loan.

[0001193125-20-223682:notes:355]
Bank of America, N.A.

[0001193125-20-223682:notes:356]
On May 22, 2014, the Company and a consortium of banks entered into a syndicated senior credit facility agreement led by Bank of America (the “BofA Facility Agreement”). The BofA Facility Agreement provided for a $200.0 million credit line, comprised of a $150.0 million revolving loan facility and a $50.0 million delayed draw term loan facility.

[0001193125-20-223682:notes:357]
From time to time, the Company amended the BofA Facility Agreement, before repaying all outstanding amounts under the agreement and terminating such agreement on September 10, 2019.

[0001193125-20-223682:notes:358]
The most recent amendment on June 4, 2018 (i) reduced the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) refinanced the outstanding amounts under the revolving loan and term loan facilities into a $65.0 million term loan which was to be repaid in quarterly installments through the maturity date of June 4, 2023, and (iii) reduced the interest rate margins and commitment fees. The term loan bore interest, at the Company’s option, at a rate per annum equal to a LIBOR rate plus a spread of 1.50% to 2.25%, or a base rate plus a spread of 0.50% to 1.25%. During the year
s
 ended June 26, 2020 and June 28, 2019, the Company recorded $0.5 million and $2.4 million, respectively, of interest expense in connection with this term loan.

[0001193125-20-223682:notes:359]
On September 10, 2019, the Company fully repaid $61.0 million in principal, accrued interest and other fees under the agreement. The early termination of this agreement did not trigger any early termination fees. A
s of
 June 26, 2020, there were no amounts outstanding under the Bof
A
 Facility Agreement. A
s

[0001193125-20-223682:notes:360]
of 
June 28, 2019, there was $60.9 million outstanding under the 
BofA Facility
 Agreement, related to the term loan.


## fn:AccruedSeveranceBenefitsDisclosureTextBlock

[0001193125-20-223682:notes:361]
| 17. | Severance liabilities |

[0001193125-20-223682:notes:362]
The following table provides information regarding severance liabilities:​​​​​​​

[0001193125-20-223682:notes:363]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26,2020 |  |  | June 28,2019 |  |
| Changes in severance liabilities |  |  |  |  |  |  |  |  |
| Balance, beginning of the fiscal year |  | $ | 15,473 |  |  | $ | 10,390 |  |
| Current service cost |  | $ | 1,907 |  |  | $ | 2,345 |  |
| Prior service cost (1) |  |  | — |  |  |  | 2,537 |  |
| Interest cost |  |  | 462 |  |  |  | 352 |  |
| Benefit paid |  |  | (48 | ) |  |  | (274 | ) |
| Actuarial (gain) loss on obligation |  |  | (117 | ) |  |  | 130 |  |
| Foreign currency translation |  |  | (4 | ) |  |  | (7 | ) |
| Balance, end of the fiscal year |  | $ | 17,673 |  |  | $ | 15,473 |  |
| Changes in plan assets |  |  |  |  |  |  |  |  |
| Balance, beginning of the fiscal year |  | $ | 317 |  |  | $ | 299 |  |
| Actual return on plan assets |  | $ | (34 | ) |  | $ | (7 | ) |
| Employer contributions |  |  | 18 |  |  |  | 36 |  |
| Benefit paid |  |  | — |  |  |  | — |  |
| Foreign currency translation |  |  | (7 | ) |  |  | (11 | ) |
| Balance, end of the fiscal year |  | $ | 294 |  |  | $ | 317 |  |
| Underfunded status |  | $ | (17,379 | ) |  | $ | (15,156 | ) |

[0001193125-20-223682:notes:364]
|  | (1) | Prior service cost is the change in Projected Benefit Obligation resulting from changes to employee benefits from local law changes. |

[0001193125-20-223682:notes:365]
The amount recognized in the consolidated balance sheets under 
non-current
 liabilities and 
non-current
 assets were determined as follows:

[0001193125-20-223682:notes:366]
| (amount in thousands) |  | As ofJune 26,2020 |  |  | As ofJune 28,2019 |  |
| Non-current assets |  | $ | — |  |  | $ | 53 |  |
| Non-current liabilities |  | $ | 17,379 |  |  | $ | 15,209 |  |

[0001193125-20-223682:notes:367]
The following table provides information regarding accumulated benefit obligations:

[0001193125-20-223682:notes:368]
| (amount in thousands) |  | As of June 26, 2020 |  |  | As of June 28, 2019 |  |
| Accumulated benefit obligations |  | $ | 11,864 |  |  | $ | 10,208 |  |

[0001193125-20-223682:notes:369]
The following table sets forth the plan assets at fair value as of June 26, 2020 and June 28, 2019.

[0001193125-20-223682:notes:370]
| (amount in thousands) |  |  |  |  | Fair value measurement as of June 26, 2020 |  |
|  |  | Total |  |  | Significant Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Other (1) |  | $ | 294 |  |  | $ | 160 |  |  | $ | 134 |  |
| Total Assets |  | $ | 294 |  |  | $ | 160 |  |  | $ | 134 |  |

[0001193125-20-223682:notes:371]
| (amount in thousands) |  |  |  |  | Fair value measurement as of June 28, 2019 |  |
|  |  | Total |  |  | Significant Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |
| Other (1) |  | $ | 317 |  |  | $ | 183 |  |  | $ | 134 |  |
| Total Assets |  | $ | 317 |  |  | $ | 183 |  |  | $ | 134 |  |

[0001193125-20-223682:notes:372]
|  | (1) | The “Other” category represents the bid value of the trustees’ insurance policy held with Old Mutual Wealth and the value of assets held with Royal London. |

[0001193125-20-223682:notes:373]
The Trustees have chosen to invest in the following funds:

[0001193125-20-223682:notes:374]
| Fund |  | % of Total |  |
| Old Mutual Wealth Invesco Perpetual High Income |  |  | 38 | % |
| Old Mutual Wealth Creation Balanced Portfolio |  |  | 17 | % |
| Royal London Deposit Administration |  |  | 45 | % |

[0001193125-20-223682:notes:375]
The Old Mutual Wealth assets are administered on unit-linked principles and allow access to a range of funds; these have been treated as Level 2 fair value measurement.

[0001193125-20-223682:notes:376]
The Royal London assets are administered on a deposit administration basis. This is similar to a with profits fund but with a lower exposure to the stock market. The policy is invested in a mix of assets, mainly UK Government bonds and Corporate bonds, the returns of which are smoothed over time. These assets are considered as unobservable inputs and have been treated as Level 3 fair value measurement because the fair value of which is based on the previous year end observable value and other unobservable inputs such as declared rates of bonus plus an enhancement on the policy for this scheme.

[0001193125-20-223682:notes:377]
The principal actuarial assumptions used were as follows:

[0001193125-20-223682:notes:378]
Weighted average actuarial assumptions used to determine severance liabilities

[0001193125-20-223682:notes:379]
|  |  | Years Ended |
|  |  | June 26, 2020 |  | June 28, 2019 |  | June 29, 2018 |
| Discount rate |  | 0.4% - 3.1% |  | 2.3% - 3.2% |  | 2.5% - 3.7% |
| Future salary increases |  | 3.5% - 10.0% |  | 3.5% - 10.0% |  | 3.5% - 10.0% |

[0001193125-20-223682:notes:380]
Weighted average actuarial assumptions used to determine benefit costs

[0001193125-20-223682:notes:381]
|  |  | Years Ended |
|  |  | June 26, 2020 |  | June 28, 2019 |  | June 29, 2018 |
| Discount rate |  | 2.3% - 3.2% |  | 2.5% - 3.7% |  | 1.9% - 3.6% |
| Expected long-term rate of return on assets |  | 2.1% |  | 1.6% |  | 1.9% |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-20-223682:notes:382]
| 18. | Share-based compensation |

[0001193125-20-223682:notes:383]
In determining the grant date fair value of share option awards, the Company is required to make estimates of expected dividends to be issued, expected volatility of Fabrinet’s ordinary shares, expected forfeitures of the awards, risk free interest rates for the expected term of the awards and expected terms of the awards. Forfeitures are estimated at the time of grant and revised if necessary in subsequent periods if actual forfeitures differ from those estimates. The grant date fair value of restricted share units and performance share units is based on the market value of our ordinary shares on the date of grant.

[0001193125-20-223682:notes:384]
The effect of recording share-based compensation expense for the years ended June 26, 2020, June 28, 2019 and June 29, 2018 was as follows:

[0001193125-20-223682:notes:385]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26, 2020 |  |  | June 28, 2019 |  |  | June 29, 2018 |  |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |  |  |  |  |  |
| Restricted share units |  | $ | 16,555 |  |  | $ | 14,691 |  |  | $ | 17,143 |  |
| Performance share units |  |  | 5,648 |  |  |  | 2,466 |  |  |  | 5,438 |  |
| Total share-based compensation expense |  |  | 22,203 |  |  |  | 17,157 |  |  |  | 22,581 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 22,203 |  |  | $ | 17,157 |  |  | $ | 22,581 |  |

[0001193125-20-223682:notes:386]
Share-based compensation expense was recorded in the consolidated statements of operations and comprehensive income as follows:

[0001193125-20-223682:notes:387]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26, 2020 |  |  | June 28, 2019 |  |  | June 29, 2018 |  |
| Cost of revenue |  | $ | 6,098 |  |  | $ | 5,656 |  |  | $ | 6,784 |  |
| Selling, general and administrative expense |  |  | 16,105 |  |  |  | 11,501 |  |  |  | 15,797 |  |
| Total share-based compensation expense |  | $ | 22,203 |  |  | $ | 17,157 |  |  | $ | 22,581 |  |

[0001193125-20-223682:notes:388]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the years ended June 26, 2020, June 28, 2019 and June 29, 2018.

[0001193125-20-223682:notes:389]
Share-based award activity

[0001193125-20-223682:notes:390]
On December 12, 2019, the Company’s shareholders approved Fabrinet’s 2020 Equity Incentive Plan (the “2020 Plan”). Upon the approval of the 2020 Plan, Fabrinet’s Amended and Restated 2010 Performance Incentive Plan (the “2010 Plan”) was simultaneously terminated. The 2020 Plan provides for the grant of equity awards thereunder with respect to (i) 1,700,000 ordinary shares, plus (ii) up to 1,300,000 ordinary shares that, as of immediately prior to the termination of the 2010 Plan, had been reserved but not issued pursuant to any awards granted under the 2010 Plan and are not subject to any awards thereunder. Upon termination of the 2010 Plan, 1,281,619 ordinary shares were reserved for issuance under the 2020 Plan

[0001193125-20-223682:notes:391]
pursuant to clause (ii) of the preceding sentence. As of June 26, 2020, there were 51,916 restricted share units outstanding, 3,836 performance share units outstanding and 2,923,551 ordinary shares available for future grant under the 2020 Plan.

[0001193125-20-223682:notes:392]
As of June 26, 2020, there were 721,514 restricted share units and 436,304 performance share units outstanding under the 2010 Plan. No ordinary shares are available for future grant under the 2010 Plan.

[0001193125-20-223682:notes:393]
On November 
2
, 
2017
, the Company adopted the 
2017
 Inducement Equity Incentive Plan (the “
2017
 Inducement Plan”) with a reserve of 
160,000
 ordinary shares authorized for future issuance solely for the granting of inducement share options and equity awards to new employees. The 
2017
 Inducement Plan was adopted without shareholder approval in reliance on the “employment inducement exemption” provided under the New York Stock Exchange Listed Company Manual. As of

[0001193125-20-223682:notes:394]
June 26, 2020

[0001193125-20-223682:notes:395]
, there were an aggregate of 
24,327
 restricted share units outstanding and 
111,347
 ordinary shares available for future grant under the 
2017
 Inducement Plan.

[0001193125-20-223682:notes:396]
The 2010 Plan, 2017 Inducement Plan and 2020 Plan are collectively referred to as the “Equity Incentive Plans.”

[0001193125-20-223682:notes:397]
Share options

[0001193125-20-223682:notes:398]
Share options have been granted to directors and employees. Fabrinet’s board of directors has the authority to determine the type of option and the number of shares subject to an option. Options generally vest and become exercisable over four years and expire, if not exercised, within seven years of the grant date. In the case of a grantee’s first grant, 25 percent of the underlying shares vest 12 months after the vesting commencement date and 1/48 of the underlying shares vest monthly over each of the subsequent 36 months. In the case of any additional grants to a grantee, 1/48 of the underlying shares vest monthly over four years, commencing one month after the vesting commencement date.

[0001193125-20-223682:notes:399]
The following table summarizes share option activity under the 2010 Plan:

[0001193125-20-223682:notes:400]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 30, 2017 |  |  | 96,688 |  |  |  | 96,688 |  |  | $ | 15.70 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (92,288 | ) |  |  |  |  |  | $ | 16.02 |  |  |  |  |  |
| Forfeited |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Expired |  |  | (1,500 | ) |  |  |  |  |  | $ | 5.75 |  |  |  |  |  |
| Balance as of June 29, 2018 |  |  | 2,900 |  |  |  | 2,900 |  |  | $ | 15.16 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Forfeited |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Expired |  |  | (2,900 | ) |  |  |  |  |  | $ | 15.16 |  |  |  |  |  |
| Balance as of June 28, 2019 |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |

[0001193125-20-223682:notes:401]
During the year ended June 26, 2020, there was no movement of share option.

[0001193125-20-223682:notes:402]
The fair value of each share option grant was determined by the Company using the methods and assumptions discussed below. Each of these inputs is subjective and generally requires significant judgment and management estimate to determine.

[0001193125-20-223682:notes:403]
The total fair value of share options vested during the years ended June 26, 2020, June 28, 2019 and June 29, 2018 was nil. The total intrinsic value of options exercised during the years ended June 26, 2020, June 28, 2019 and June 29, 2018 was nil, nil and $2.0 million, respectively. In conjunction with these option exercises, there was no tax benefit realized by the Company due to the fact that it is exempted from income tax.

[0001193125-20-223682:notes:404]
Valuation Method

[0001193125-20-223682:notes:405]
—The Company estimated the fair value of the Company’s ordinary shares to be used in the BSM by taking into consideration a number of assumptions, as discussed below.

[0001193125-20-223682:notes:406]
Expected Dividend

[0001193125-20-223682:notes:407]
—The Company used zero as an annualized dividend yield since it did not anticipate pay
ing
 any cash dividends in the near future.

[0001193125-20-223682:notes:408]
Expected Volatility

[0001193125-20-223682:notes:409]
—The Company determined the expected volatility based on the Company’s historical volatility over the last four years.

[0001193125-20-223682:notes:410]
Risk-Free Interest Rate

[0001193125-20-223682:notes:411]
—The Company based the risk-free interest rate on the implied yield currently available on U.S. Treasury 
zero-coupon
 issues with a remaining term equivalent to the expected term of the option.

[0001193125-20-223682:notes:412]
Expected Term

[0001193125-20-223682:notes:413]
—Expected terms used in the BSM represent the periods that the company’s share options are expected to be outstanding and are determined based on the Company’s historical experience of similar awards, giving consideration to the contractual terms of the share options, vesting schedules and expectations of future employee behavior.

[0001193125-20-223682:notes:414]
Vesting Period

[0001193125-20-223682:notes:415]
—Fabrinet’s share options generally vest and become exercisable over a four-year period, and expire seven years from the date of grant. For an initial grant, 25 percent of the underlying shares subject to an option vest 12 months after the vesting commencement date and 1/48 of the underlying shares vest monthly over each of the subsequent 36 months. In the case of any additional grants to an optionholder, 1/48 of the underlying shares subject to an option vest monthly over four years, commencing one month after the vesting commencement date.

[0001193125-20-223682:notes:416]
Fair Value

[0001193125-20-223682:notes:417]
—The fair value of Fabrinet’s share options granted to employees was estimated using the weighted-average for each assumption of expected volatility, risk-free rate of return, and expected term.

[0001193125-20-223682:notes:418]
Restricted share units and performance share units

[0001193125-20-223682:notes:419]
Restricted share units and performance share units have been granted under the Equity Incentive 
Plans
.

[0001193125-20-223682:notes:420]
Restricted share units granted to employees generally vest in equal installments over three or four years on each anniversary of the vesting commencement date. Restricted share units granted to 
non-employee
 directors generally cliff vest 100% on the first of January, 
approximately
 one year from the grant date, provided the director continues to serve through such date.

[0001193125-20-223682:notes:421]
Performance share units granted to executives will vest, if at all, at the end of a 
two-year
 performance period based on the Company’s achievement of 
pre-defined
 performance criteria, which consist of revenue and 
non-
U.S. 
GAAP
 gross margin or operating margin targets. The actual number of performance share units that may vest at the end of the performance period ranges from 0% to 100% of the award grant.

[0001193125-20-223682:notes:422]
The following table summarizes restricted share unit activity under the Equity Incentive Plans:

[0001193125-20-223682:notes:423]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 30, 2017 |  |  | 1,058,605 |  |  | $ | 31.59 |  |
| Granted |  |  | 552,637 |  |  | $ | 35.95 |  |
| Issued |  |  | (436,867 | ) |  | $ | 27.81 |  |
| Forfeited |  |  | (100,795 | ) |  | $ | 33.62 |  |
| Balance as of June 29, 2018 |  |  | 1,073,580 |  |  | $ | 35.19 |  |
| Granted |  |  | 391,328 |  |  | $ | 50.02 |  |
| Issued |  |  | (515,482 | ) |  | $ | 34.18 |  |
| Forfeited |  |  | (148,675 | ) |  | $ | 38.42 |  |
| Balance as of June 28, 2019 |  |  | 800,751 |  |  | $ | 42.48 |  |
| Granted |  |  | 367,088 |  |  | $ | 50.87 |  |
| Issued |  |  | (335,355 | ) |  | $ | 40.98 |  |
| Forfeited |  |  | (34,727 | ) |  | $ | 44.59 |  |
| Balance as of June 26, 2020 |  |  | 797,757 |  |  | $ | 46.88 |  |
| Expected to vest as of June 26, 2020 |  |  | 697,093 |  |  | $ | 46.81 |  |

[0001193125-20-223682:notes:424]
The following table summarizes performance share unit activity under the Equity Incentive Plans:

[0001193125-20-223682:notes:425]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 30, 2017 |  |  | 227,268 |  |  | $ | 40.48 |  |
| Granted |  |  | 378,624 |  |  | $ | 37.16 |  |
| Issued |  |  | — |  |  |  | — |  |
| Forfeited |  |  | — |  |  |  | — |  |
| Balance as of June 29, 2018 |  |  | 605,892 |  |  | $ | 38.41 |  |
| Granted |  |  | 201,994 |  |  | $ | 48.02 |  |
| Issued |  |  | (227,268 | ) |  | $ | 40.48 |  |
| Forfeited |  |  | (32,118 | ) |  | $ | 40.47 |  |
| Balance as of June 28, 2019 |  |  | 548,500 |  |  | $ | 40.97 |  |
| Granted |  |  | 242,310 |  |  | $ | 48.65 |  |
| Issued |  |  | — |  |  |  | — |  |
| Forfeited |  |  | (350,670 | ) |  | $ | 36.99 |  |
| Balance as of June 26, 2020 |  |  | 440,140 |  |  | $ | 48.37 |  |
| Expected to vest as of June 26, 2020 |  |  | 378,928 |  |  | $ | 48.37 |  |

[0001193125-20-223682:notes:426]
The fair value of restricted share units and performance share units is based on the market value of our ordinary shares on the date of grant.

[0001193125-20-223682:notes:427]
The total fair value of restricted share units and performance share units vested during the year
s
 ended June 26, 2020, June 28, 2019 and June 29, 2018 was $13.7 million, $26.8 million and $12.2 million, respectively. The aggregate intrinsic value of restricted share units and performance share units outstanding as of June 26, 2020 was $73.5 million.

[0001193125-20-223682:notes:428]
As of June 26, 2020, there was $12.2 million and $5.6 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity

[0001193125-20-223682:notes:429]
Incentive Plans that is expected to be recorded over a weighted-average period of 2.4 years and 1.1 years, respectively.

[0001193125-20-223682:notes:430]
For the years ended June 26, 2020 and June 28, 2019, the Company withheld an aggregate of 94,141 shares and 235,730 shares, respectively, upon the vesting of restricted share units, based upon the closing share price on the vesting date to settle the employees’ minimum statutory obligation for the applicable income and other employment taxes. For the years ended June 26, 2020 and June 28, 2019, the Company then remitted cash of $4.9 million and $10.6 million, respectively, to the appropriate taxing authorities, and presented it as a financing activity within the consolidated statements of cash flows. The payment had the effect on shares issued by the Company as it reduced the number of shares that would have been issued on the vesting date and was recorded as a reduction of additional 
paid-in
 capital.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-20-223682:notes:431]
| 19. | Employee benefit plans |

[0001193125-20-223682:notes:432]
The Company operates a defi
n
ed contribution plan, known as a provident fund, in its subsidiaries in Thailand and the United Kingdom. The assets of these plans are in separate trustee-administered funds. The provident fund is funded by matching payments from employees and by the subsidiaries on a monthly basis. Current contributions to the provident fund are accrued and paid to the fund manager on a monthly basis. The Company’s contributions to the provident fund amounted to $5.5 million, $4.8 million and $4.2 million during the years ended June 26, 2020, June 28, 2019 and June 29, 2018, respectively.

[0001193125-20-223682:notes:433]
The Company sponsors the Fabrinet U.S. 401(k) Retirement Plan (“401(k) Plan”), a Defined Contribution Plan under ERISA, at its subsidiaries in the United States which provides retirement benefits for eligible employees through tax deferred salary deductions. The 401(k) Plan allows employees to contribute up to 80% of their annual compensation, subject to annual contributions limits established by the Internal Revenue Service. The Company provides for a 100% match of employees’ contributions to the 401(k) Plan up to the first 6% of annual compensation. All matching contributions are made in cash and vest immediately. The Company’s matching contributions to the 401(k) Plan were $0.7 million, $0.8 million and $0.7 million during the years ended June 26, 2020, June 28, 2019 and June 29, 2018, respectively.

[0001193125-20-223682:notes:434]
Executive incentive plan and employee performance bonuses

[0001193125-20-223682:notes:435]
For the years ended June 26, 2020 and June 28, 2019, the Company maintained an executive incentive plan with quantitative objectives, based on achieving certain revenue and 
non-U.S.
 GAAP operating margin or gross margin targets. During the years ended June 26, 2020, June 28, 2019 and June 29, 2018, discretionary merit-based bonus awards were also available to Fabrinet’s 
non-executive
 employees.

[0001193125-20-223682:notes:436]
Bonus distributions to employees were $8.7 million, $7.6 million and $4.0 million for the years ended June 26, 2020, June 28, 2019 and June 29, 2018, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-20-223682:notes:437]
| 20. | Shareholders’ equity |

[0001193125-20-223682:notes:438]
Fabrinet’s authorized share capital is 500,000,000 ordinary shares, par value of $0.01 per ordinary share, and 5,000,000 preferred shares, par value of $0.01 per preferred share.

[0001193125-20-223682:notes:439]
For the year ended June 26, 2020, Fabrinet issued 241,214 ordinary shares upon the vesting of restricted share units and performance share units, net of shares withheld.

[0001193125-20-223682:notes:440]
For the year ended June 28, 2019, Fabrinet issued 507,020 ordinary shares upon the vesting of restricted share units and performance share units, net of shares withheld.

[0001193125-20-223682:notes:441]
For the year ended June 29, 2018, Fabrinet issued 92,288 ordinary shares upon the exercise of options, for cash consideration at a weighted average exercise price of $15.56 per share, and 290,949 ordinary shares upon the vesting of restricted share units, net of shares withheld.

[0001193125-20-223682:notes:442]
All such issued shares are fully paid.

[0001193125-20-223682:notes:443]
In August 2017, the Company’s board of directors approved a share repurchase program to permit the Company to repurchase up to $30.0 million worth of its issued and outstanding ordinary shares in the open market in accordance with applicable rules and regulations. In February 2018 and May 2019, the Company’s board of directors approved an increase of $30.0 million and $50.0 million, respectively, to the original share repurchase authorization, bringing the aggregate authorization to $110.0 million.

[0001193125-20-223682:notes:444]
During the year ended June 26, 2020, 355,000 shares were repurchased under the program, at an average price per share of $58.37, totaling $20.7 million. As of June 26, 2020, the Company had a remaining authorization to purchase up to $41.5 million of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-20-223682:notes:445]
| 21. | Accumulated other comprehensive income (loss) (“AOCI”) |

[0001193125-20-223682:notes:446]
The changes in AOCI for the years ended June 26, 2020 and June 28, 2019 were as follows:

[0001193125-20-223682:notes:447]
| (amount in thousands) |  | Unrealized Gains (Losses) on Available-for-sale Securities |  |  | Unrealized Gains (Losses) on Derivative Instruments |  |  | Retirement benefit plan - Prior service cost |  |  | Foreign Currency Translation Adjustment |  |  | Total |  |
| Balance as of June 29, 2018 |  | $ | (1,091 | ) |  | $ | 33 |  |  | $ | — |  |  | $ | (199 | ) |  | $ | (1,257 | ) |
| Other comprehensive income before reclassification |  |  | 1,845 |  |  |  | — |  |  |  | (2,537 | ) |  |  | (634 | ) |  |  | (1,326 | ) |
| Amounts reclassified from AOCI |  |  | 198 |  |  |  | (1 | ) |  |  | — |  |  |  | — |  |  |  | 197 |  |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income |  |  | 2,043 |  |  |  | (1 | ) |  |  | (2,537 | ) |  |  | (634 | ) |  |  | (1,129 | ) |
| Balance as of June 28, 2019 |  |  | 952 |  |  |  | 32 |  |  |  | (2,537 | ) |  |  | (833 | ) |  |  | (2,386 | ) |
| Other comprehensive income before reclassification |  |  | 634 |  |  |  | 171 |  |  |  | — |  |  |  | (397 | ) |  |  | 408 |  |
| Amounts reclassified from AOCI |  |  | (96 | ) |  |  | 399 |  |  |  | 528 |  |  |  | — |  |  |  | 831 |  |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income |  |  | 538 |  |  |  | 570 |  |  |  | 528 |  |  |  | (397 | ) |  |  | 1,239 |  |
| Balance as of June 26, 2020 |  | $ | 1,490 |  |  | $ | 602 |  |  | $ | (2,009 | ) |  | $ | (1,230 | ) |  | $ | (1,147 | ) |

[0001193125-20-223682:notes:448]
The following table presents the 
pre-tax
 amounts reclassified from AOCI into the consolidated statements of operations and comprehensive income for the years ended June 26, 2020 and June 28, 2019, respectively.

[0001193125-20-223682:notes:449]
| (amount in thousands) |  |  |  | Years ended |  |
| AOCI components |  | Financial statements line item |  | June 26, 2020 |  |  | June 28, 2019 |  |
| Unrealized gains (losses) on available-for-sale securities |  | Interest income |  | $ | (96 | ) |  | $ | 198 |  |
| Unrealized gains (losses) on derivative instruments |  | Cost of revenues |  |  | 2,512 |  |  |  | — |  |
| Unrealized gains (losses) on derivative instruments |  | Selling, general and administrative expenses |  |  | 105 |  |  |  | (1 | ) |
| Unrealized gains (losses) on derivative instruments |  | Foreign exchange loss, net |  |  | (998 | ) |  |  | — |  |
| Unrealized gains (losses) on derivative instruments |  | Interest expense |  |  | (1,220 | ) |  |  | — |  |
| Retirement benefit plan – Prior service cost |  | Selling, general and administrative expenses |  |  | 528 |  |  |  | — |  |
| Total amounts reclassified from AOCI |  |  |  | $ | 831 |  |  | $ | 197 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-20-223682:notes:450]
| 22. | Commitments and contingencies |

[0001193125-20-223682:notes:451]
Letter of credit and bank guarantees

[0001193125-20-223682:notes:452]
As of June 26, 2020 and June 28, 2019, the Company had one outstanding standby letter of credit of 6.0 million Euros, related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. As of June 26, 2020 and June 28, 2019, the standby letter of credit was backed by cash collateral of $7.4 million.

[0001193125-20-223682:notes:453]
As of June 26, 2020 and June 28, 2019, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business expenses totaling $1.6 million

[0001193125-20-223682:notes:454]
and there were other bank guarantees given by a bank on behalf of our subsidiaries in China and the U.K. to support their operations of

[0001193125-20-223682:notes:455]
$0.1 million and $25 thousand, respectively.

[0001193125-20-223682:notes:456]
Purchase obligations

[0001193125-20-223682:notes:457]
Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001193125-20-223682:notes:458]
As of June 26, 2020, the Company had an outstanding commitment to third parties of $11.1 million.

[0001193125-20-223682:notes:459]
Indemnification of directors and officers

[0001193125-20-223682:notes:460]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001193125-20-223682:notes:461]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-20-223682:notes:462]
| 23. | Business segments and geographic information |

[0001193125-20-223682:notes:463]
Operating segments are defined as components of an enterprise that engage in business activities for which discrete financial information is available that is evaluated regularly by the chief operating decision maker (the “CODM”) in deciding how to allocate resources and in assessing performance. The Company’s CODM is Fabrinet’s Chief Executive Officer. As of June 26, 2020, June 28, 2019 and June 29, 2018, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001193125-20-223682:notes:464]
Total revenues are attributed to a particular geographic area based on the

[0001193125-20-223682:notes:465]
bill-to-location

[0001193125-20-223682:notes:466]
of the Company’s customer. The Company operates in three geographic regions: North America, Asia-Pacific and Europe.

[0001193125-20-223682:notes:467]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26,2020 |  |  | June 28,2019 |  |  | June 29,2018 |  |
| North America |  | $ | 830,888 |  |  | $ | 756,278 |  |  | $ | 643,236 |  |
| Asia-Pacific |  |  | 552,923 |  |  |  | 608,386 |  |  |  | 519,203 |  |
| Europe |  |  | 258,025 |  |  |  | 219,671 |  |  |  | 209,486 |  |
| Total |  | $ | 1,641,836 |  |  | $ | 1,584,335 |  |  | $ | 1,371,925 |  |

[0001193125-20-223682:notes:468]
As of June 26, 2020 and June 28, 2019, the Company had approximately $29.5 million and $31.4 million, respectively, of long-lived assets based in North America, with the substantial remainder of assets based in Asia-Pacific and Europe.

[0001193125-20-223682:notes:469]
The following table presents revenues by end market:

[0001193125-20-223682:notes:470]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26,2020 |  |  | June 28,2019 |  |  | June 29,2018 |  |
| Optical communications |  | $ | 1,248,174 |  |  | $ | 1,184,936 |  |  | $ | 1,000,256 |  |
| Lasers, sensors, and other |  |  | 393,662 |  |  |  | 399,399 |  |  |  | 371,669 |  |
| Total |  | $ | 1,641,836 |  |  | $ | 1,584,335 |  |  | $ | 1,371,925 |  |

[0001193125-20-223682:notes:471]
Significant customers

[0001193125-20-223682:notes:472]
Total revenues, by percentage, from individual customers representing 10% or more of total revenues in the respective periods were as follows:

[0001193125-20-223682:notes:473]
|  |  | Years Ended |  |
|  |  | June 26,2020 |  |  | June 28,2019 |  |  | June 29,2018 |  |
| Lumentum Operations LLC |  |  | 19 | % |  |  | 20 | % |  |  | 16 | % |
| Acacia Communications Inc. |  |  | 10 | % |  |  | * |  |  |  | * |  |
| Infinera Corporation |  |  | 10 | % |  |  | * |  |  |  | * |  |

[0001193125-20-223682:notes:474]
|  | * | Represents less than 10% of total revenues. |

[0001193125-20-223682:notes:475]
Accounts receivable from individual customers representing 10% or more of accounts receivable as of June 26, 2020 and June 28, 2019, respectively, were as follows:

[0001193125-20-223682:notes:476]
|  |  | As ofJune 26,2020 |  |  | As ofJune 28,2019 |  |
| Lumentum Operations LLC |  |  | 20 | % |  |  | 23 | % |
| Acacia Communications Inc. |  |  | 13 | % |  |  | 12 | % |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-20-223682:notes:477]
| 24. | Financial instruments |

[0001193125-20-223682:notes:478]
Objectives and significant terms and conditions

[0001193125-20-223682:notes:479]
The principal financial risks faced by the Company are foreign currency risk and interest rate risk. The Company borrows at floating rates of interest to finance its operations. A minority of sales and purchases and a majority of labor and overhead costs are entered into in foreign currencies. In order to manage the risks arising from fluctuations in currency exchange rates, the Company uses derivative instruments. Trading for speculative purposes is prohibited under Company policies.

[0001193125-20-223682:notes:480]
The Company enters into short-term foreign currency forward and option contracts to manage foreign currency exposures associated with certain assets, liabilities and other forecasted foreign currency transactions and may designate these instruments as hedging instruments. The foreign currency forward and option contracts generally have maturities of up to twelve months. All foreign currency exchange contracts are recognized on the consolidated balance sheets at fair value. Gain or loss on the Company’s derivative instruments generally offset the assets, liabilities and transactions economically hedged.

[0001193125-20-223682:notes:481]
Foreign currency risk

[0001193125-20-223682:notes:482]
The Company operates internationally and is exposed to foreign exchange risk arising from various currency exposures primarily with respect to the Thai baht, Chinese Renminbi (“RMB”) and Pound sterling (“GBP”).

[0001193125-20-223682:notes:483]
As of June 26, 2020 and June 28, 2019, the Company had outstanding foreign currency assets and liabilities as follows:

[0001193125-20-223682:notes:484]
|  |  | As of June 26, 2020 |  |  | As of June 28, 2019 |  |
| (amount in thousands) |  | Currency |  |  | $ |  |  | Currency |  |  | $ |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 667,955 |  |  | $ | 21,617 |  |  |  | 664,860 |  |  | $ | 21,628 |  |
| RMB |  |  | 158,060 |  |  |  | 22,402 |  |  |  | 53,393 |  |  |  | 7,767 |  |
| GBP |  |  | 6,220 |  |  |  | 7,726 |  |  |  | 5,270 |  |  |  | 6,682 |  |
| Total |  |  |  |  |  | $ | 51,745 |  |  |  |  |  |  | $ | 36,077 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 2,102,392 |  |  | $ | 68,039 |  |  |  | 1,961,972 |  |  | $ | 63,825 |  |
| RMB |  |  | 42,586 |  |  |  | 6,036 |  |  |  | 26,373 |  |  |  | 3,836 |  |
| GBP |  |  | 1,545 |  |  |  | 1,919 |  |  |  | 2,598 |  |  |  | 3,294 |  |
| Total |  |  |  |  |  | $ | 75,994 |  |  |  |  |  |  | $ | 70,955 |  |

[0001193125-20-223682:notes:485]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. The Company manages its exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of June 26, 2020 there were $126.0 million of foreign currency forward and option contracts outstanding on the Thai baht payables. As of June 28, 2019, there were $72.0 million of foreign currency forward contracts outstanding on the Thai baht payables.

[0001193125-20-223682:notes:486]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses and other payables. As of June 26, 2020 and June 28, 2019, there were no derivative contracts denominated in RMB.

[0001193125-20-223682:notes:487]
The GBP assets represent cash, trade accounts receivable, inventory and property, plant and equipment. The GBP liabilities represent trade accounts payable. As of June 26, 2020 and June 28, 2019, there were no derivative contracts denominated in GBP.

[0001193125-20-223682:notes:488]
For fiscal year 2020, fiscal year 2019, and fiscal year 2018, the Company recorded unrealized loss of $1.2 million, unrealized gain of $4.8 million, and unrealized loss of $1.7 million, respectively, related to derivatives that are not designated as hedging instruments in its consolidated statements of operations and comprehensive income.

[0001193125-20-223682:notes:489]
Interest Rate Risk

[0001193125-20-223682:notes:490]
The Company’s principal interest bearing assets are time deposits and short-term investments with maturities of three years or less held with high quality financial institutions. The Company’s principal interest bearing liabilities are bank loans which bear interest at floating rates.

[0001193125-20-223682:notes:491]
The Company entered into interest rate swap agreements (the “Swap Agreements”) to manage this risk and increase the profile of the Company’s debt obligation. The terms of the Swap Agreements allow the Company to effectively convert the floating interest rate to a fixed interest rate. This locks the variable in interest expenses associated with our floating rate borrowings and results in fixed interest expenses, which is unsusceptible to market rate increase. The Company designated the Swap Agreements as a cash flow hedge, and they qualify for hedge accounting because the hedges are highly effective. While the Company intend to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in our earnings. From September 27, 2019, any gains or losses related to these outstanding interest rate swaps will be recorded in accumulated other comprehensive income in the consolidated balance sheets, with subsequent reclassification to interest expense when settled.


## us-gaap:SubsequentEventsTextBlock

[0001193125-20-223682:notes:492]
| 25. | Subsequent Event |

[0001193125-20-223682:notes:493]
In August 2020, the Company’s board of directors approved the repurchase of up to an additional $58.5 million of Fabrinet’s outstanding ordinary shares, bringing the aggregate authorization under Fabrinet’s existing share repurchase program to $168.5 million.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001193125-20-223682:notes:494]
UNAUDITED QUARTERLY FINANCIAL INFORMATION

[0001193125-20-223682:notes:495]
The following table sets forth a summary of the Company’s quarterly financial information for each of the four quarters in the fiscal years ended June 26, 2020 and June 28, 2019:

[0001193125-20-223682:notes:496]
|  |  | Three Months Ended |  |
| (in thousands, except per share data) |  | Jun 26,2020 |  |  | Mar 27,2020 |  |  | Dec 27,2019 |  |  | Sep 27,2019 |  |  | Jun 28,2019 |  |  | Mar 29,2019 |  |  | Dec 28,2018 |  |  | Sep 28,2018 |  |
| Total revenues |  | $ | 405,113 |  |  | $ | 411,210 |  |  | $ | 426,217 |  |  | $ | 399,296 |  |  | $ | 405,127 |  |  | $ | 398,951 |  |  | $ | 403,080 |  |  | $ | 377,177 |  |
| Gross profit |  | $ | 46,624 |  |  | $ | 44,336 |  |  | $ | 49,158 |  |  | $ | 45,987 |  |  | $ | 46,626 |  |  | $ | 46,758 |  |  | $ | 45,564 |  |  | $ | 40,276 |  |
| Net income |  | $ | 28,024 |  |  | $ | 28,267 |  |  | $ | 31,231 |  |  | $ | 25,957 |  |  | $ | 32,957 |  |  | $ | 28,635 |  |  | $ | 31,513 |  |  | $ | 27,850 |  |
| Basic net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 0.76 |  |  | $ | 0.76 |  |  | $ | 0.84 |  |  | $ | 0.70 |  |  | $ | 0.89 |  |  | $ | 0.78 |  |  | $ | 0.86 |  |  | $ | 0.76 |  |
| Weighted-average shares used in basic net income per share calculations |  |  | 36,723 |  |  |  | 36,987 |  |  |  | 37,011 |  |  |  | 36,913 |  |  |  | 36,836 |  |  |  | 36,891 |  |  |  | 36,841 |  |  |  | 36,625 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 0.75 |  |  | $ | 0.75 |  |  | $ | 0.83 |  |  | $ | 0.69 |  |  | $ | 0.88 |  |  | $ | 0.76 |  |  | $ | 0.84 |  |  | $ | 0.75 |  |
| Weighted-average shares used in diluted net income per share calculations |  |  | 37,571 |  |  |  | 37,797 |  |  |  | 37,763 |  |  |  | 37,529 |  |  |  | 37,511 |  |  |  | 37,539 |  |  |  | 37,471 |  |  |  | 37,140 |  |
