# FN notes — 0001408710-23-000018


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001408710-23-000018:notes:1]
[same as prior period, unchanged from 0001408710-23-000008:notes:1]

[0001408710-23-000018:notes:2]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of March 31, 2023 and for the three and nine months ended March 31, 2023 and March 25, 2022 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 24, 2022.

[0001408710-23-000018:notes:3]
[same as prior period, unchanged from 0001408710-23-000008:notes:3]

[0001408710-23-000018:notes:4]
The results for the three and nine months ended March 31, 2023 may not be indicative of results for the year ending June 30, 2023 or any future periods.

[0001408710-23-000018:notes:5]
[same as prior period, unchanged from 0001408710-23-000008:notes:5]

[0001408710-23-000018:notes:6]
[same as prior period, unchanged from 0001408710-23-000008:notes:6]

[0001408710-23-000018:notes:7]
[same as prior period, unchanged from 0001408710-23-000008:notes:7]

[0001408710-23-000018:notes:8]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  March 31, 2023 and March 25, 2022 consisted of 13 weeks. The nine months ended  March 31, 2023 and March 25, 2022 consisted of 40 weeks and 39 weeks, respectively. Fiscal year 2023 will comprise 53 weeks and will end on June 30, 2023.

[0001408710-23-000018:notes:9]
Adoption of New Accounting Standards
In November 2021, the Financial Accounting Standard Board issued Accounting Standards Update ("ASU") 2021-10, “Government Assistance (Topic 832), Disclosures by Business Entities about Government Assistance,” which requires annual disclosures that increase the transparency of transactions involving government assistance, including (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The amendments in this update are effective for all entities within the ASU's scope for financial statements issued for annual periods beginning after December 15, 2021. The Company adopted this standard in the first quarter of fiscal year 2023 with no material impact on its unaudited condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001408710-23-000018:notes:10]
[same as prior period, unchanged from 0001408710-23-000008:notes:10]

[0001408710-23-000018:notes:11]
[same as prior period, unchanged from 0001408710-23-000008:notes:11]

[0001408710-23-000018:notes:12]
[same as prior period, unchanged from 0001408710-23-000008:notes:12]

[0001408710-23-000018:notes:13]
| (in thousands, except percentages) | Three Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 310,100 |  |  |  |  | $ | 975,098 |  |  |  |
| Others (1) | 6,035 |  |  |  |  | 13,693 |  |  |  |
| Total revenue in North America | 316,135 |  |  | 47.5 | % |  | 988,791 |  |  | 49.7 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 85,731 |  |  |  |  | 247,942 |  |  |  |
| Israel | 85,562 |  |  |  |  | 182,732 |  |  |  |
| Hong Kong | 37,120 |  |  |  |  | 109,315 |  |  |  |
| Malaysia | 30,688 |  |  |  |  | 130,402 |  |  |  |
| Thailand | 16,706 |  |  |  |  | 45,420 |  |  |  |
| China | 11,194 |  |  |  |  | 60,738 |  |  |  |
| Japan | 10,044 |  |  |  |  | 32,129 |  |  |  |
| Others | 2,896 |  |  |  |  | 7,957 |  |  |  |
| Total revenue in Asia-Pacific and others | 279,941 |  |  | 42.1 | % |  | 816,635 |  |  | 41.1 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 40,292 |  |  |  |  | 103,440 |  |  |  |
| Germany | 14,532 |  |  |  |  | 40,975 |  |  |  |
| Ireland (2) | 176 |  |  |  |  | 438 |  |  |  |
| Others | 14,205 |  |  |  |  | 39,087 |  |  |  |
| Total revenue in Europe | $ | 69,205 |  |  | 10.4 | % |  | $ | 183,940 |  |  | 9.2 | % |
| Total revenue | $ | 665,281 |  |  | 100.0 | % |  | $ | 1,989,366 |  |  | 100.0 | % |

[0001408710-23-000018:notes:14]
| (in thousands, except percentages) | Three Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 292,475 |  |  |  |  | $ | 781,469 |  |  |  |
| Others (1) | 4,123 |  |  |  |  | 8,996 |  |  |  |
| Total revenue in North America | 296,598 |  |  | 52.5 | % |  | 790,465 |  |  | 47.2 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 70,956 |  |  |  |  | 210,009 |  |  |  |
| Malaysia | 51,188 |  |  |  |  | 163,306 |  |  |  |
| Hong Kong | 17,338 |  |  |  |  | 61,575 |  |  |  |
| Israel | 16,883 |  |  |  |  | 67,318 |  |  |  |
| Japan | 16,449 |  |  |  |  | 47,258 |  |  |  |
| China | 12,843 |  |  |  |  | 40,624 |  |  |  |
| Others | 10,559 |  |  |  |  | 34,349 |  |  |  |
| Total revenue in Asia-Pacific and others | 196,216 |  |  | 34.8 | % |  | 624,439 |  |  | 37.3 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland (2) | 28,640 |  |  |  |  | 133,024 |  |  |  |
| U.K. | 21,632 |  |  |  |  | 64,151 |  |  |  |
| Germany | 10,688 |  |  |  |  | 28,098 |  |  |  |
| Others | 10,621 |  |  |  |  | 34,173 |  |  |  |
| Total revenue in Europe | $ | 71,581 |  |  | 12.7 | % |  | $ | 259,446 |  |  | 15.5 | % |
| Total revenue | $ | 564,395 |  |  | 100.0 | % |  | $ | 1,674,350 |  |  | 100.0 | % |

[0001408710-23-000018:notes:15]
[same as prior period, unchanged from 0001408710-23-000008:notes:15]

[0001408710-23-000018:notes:16]
[same as prior period, unchanged from 0001408710-23-000008:notes:16]

[0001408710-23-000018:notes:17]
[same as prior period, unchanged from 0001408710-23-000008:notes:17]

[0001408710-23-000018:notes:18]
| (in thousands, except percentages) | Three Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |
| Optical communications | $ | 502,615 |  |  | 75.5 | % |  | $ | 1,506,232 |  |  | 75.7 | % |
| Lasers, sensors and other | 162,666 |  |  | 24.5 | % |  | 483,134 |  |  | 24.3 | % |
| Total | $ | 665,281 |  |  | 100.0 | % |  | $ | 1,989,366 |  |  | 100.0 | % |

[0001408710-23-000018:notes:19]
| (in thousands, except percentages) | Three Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |
| Optical communications | $ | 440,003 |  |  | 78.0 | % |  | $ | 1,318,087 |  |  | 78.7 | % |
| Lasers, sensors and other | 124,392 |  |  | 22.0 | % |  | 356,263 |  |  | 21.3 | % |
| Total | $ | 564,395 |  |  | 100.0 | % |  | $ | 1,674,350 |  |  | 100.0 | % |

[0001408710-23-000018:notes:20]
[same as prior period, unchanged from 0001408710-23-000008:notes:20]

[0001408710-23-000018:notes:21]
[same as prior period, unchanged from 0001408710-23-000008:notes:21]

[0001408710-23-000018:notes:22]
[same as prior period, unchanged from 0001408710-23-000008:notes:22]

[0001408710-23-000018:notes:23]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the nine months ended March 31, 2023:

[0001408710-23-000018:notes:24]
| (in thousands) | ContractAssets |
| Beginning balance, June 24, 2022 | $ | 13,464 |  |
| Revenue recognized | 57,617 |  |
| Amounts collected or invoiced | (50,000) |  |
| Ending balance, March 31, 2023 | $ | 21,081 |  |

[0001408710-23-000018:notes:25]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 24, 2022 | $ | 1,982 |  |
| Advance payment received during the period | 13,073 |  |
| Revenue recognized | (11,806) |  |
| Ending balance, March 31, 2023 | $ | 3,249 |  |


## us-gaap:EarningsPerShareTextBlock

[0001408710-23-000018:notes:26]
[same as prior period, unchanged from 0001408710-23-000008:notes:26]

[0001408710-23-000018:notes:27]
[same as prior period, unchanged from 0001408710-23-000008:notes:27]

[0001408710-23-000018:notes:28]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands, except per share data) | March 31,2023 |  | March 25,2022 |  | March 31,2023 |  | March 25,2022 |
| Net income attributable to shareholders | $ | 59,355 |  |  | $ | 50,661 |  |  | $ | 187,127 |  |  | $ | 144,191 |  |
| Weighted-average number of ordinary shares outstanding | 36,608 |  |  | 36,940 |  |  | 36,575 |  |  | 36,945 |  |
| Incremental shares arising from the assumed vesting of restricted share units and performance share units | 381 |  |  | 533 |  |  | 320 |  |  | 506 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share | 36,989 |  |  | 37,473 |  |  | 36,895 |  |  | 37,451 |  |
| Basic earnings per ordinary share | $ | 1.62 |  |  | $ | 1.37 |  |  | $ | 5.12 |  |  | $ | 3.90 |  |
| Diluted earnings per ordinary share | $ | 1.60 |  |  | $ | 1.35 |  |  | $ | 5.07 |  |  | $ | 3.85 |  |


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001408710-23-000018:notes:29]
[same as prior period, unchanged from 0001408710-23-000008:notes:29]

[0001408710-23-000018:notes:30]
|  |  |  | Fair Value |
| (in thousands) | CarryingCost |  | UnrealizedGain/(Loss) |  | Cash andCashEquivalents |  | MarketableSecurities |  | OtherInvestments |
| As of March 31, 2023 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 211,433 |  |  | $ | — |  |  | $ | 211,433 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 19,320 |  |  | (10) |  |  | 19,310 |  |  | — |  |  | — |  |
| Liquidity funds | 40,528 |  |  | — |  |  | — |  |  | — |  |  | 40,528 |  |
| Certificates of deposit and time deposits | 44,341 |  |  | 43 |  |  | — |  |  | 44,384 |  |  | — |  |
| Corporate debt securities | 215,295 |  |  | (4,127) |  |  | — |  |  | 211,168 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 12,054 |  |  | (154) |  |  | — |  |  | 11,900 |  |  | — |  |
| Total | $ | 542,971 |  |  | $ | (4,248) |  |  | $ | 230,743 |  |  | $ | 267,452 |  |  | $ | 40,528 |  |
| As of June 24, 2022 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 187,630 |  |  | $ | — |  |  | $ | 187,630 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 10,367 |  |  | (1) |  |  | 10,366 |  |  | — |  |  | — |  |
| Liquidity funds | 31,477 |  |  | — |  |  | — |  |  | — |  |  | 31,477 |  |
| Corporate debt securities | 234,689 |  |  | (5,671) |  |  | — |  |  | 229,018 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 20,007 |  |  | (345) |  |  | — |  |  | 19,662 |  |  | — |  |
| Total | $ | 484,170 |  |  | $ | (6,017) |  |  | $ | 197,996 |  |  | $ | 248,680 |  |  | $ | 31,477 |  |

[0001408710-23-000018:notes:31]
[same as prior period, unchanged from 0001408710-23-000008:notes:31]

[0001408710-23-000018:notes:32]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of March 31, 2023 and June 24, 2022:

[0001408710-23-000018:notes:33]
|  | March 31, 2023 |  | June 24, 2022 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 150,720 |  |  | $ | 150,547 |  |  | $ | 101,976 |  |  | $ | 101,400 |  |
| Due between one to five years | 161,498 |  |  | 157,433 |  |  | 184,197 |  |  | 178,757 |  |
| Total | $ | 312,218 |  |  | $ | 307,980 |  |  | $ | 286,173 |  |  | $ | 280,157 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001408710-23-000018:notes:34]
[same as prior period, unchanged from 0001408710-23-000008:notes:34]

[0001408710-23-000018:notes:35]
[same as prior period, unchanged from 0001408710-23-000008:notes:35]

[0001408710-23-000018:notes:36]
[same as prior period, unchanged from 0001408710-23-000008:notes:36]

[0001408710-23-000018:notes:37]
[same as prior period, unchanged from 0001408710-23-000008:notes:37]

[0001408710-23-000018:notes:38]
[same as prior period, unchanged from 0001408710-23-000008:notes:38]

[0001408710-23-000018:notes:39]
[same as prior period, unchanged from 0001408710-23-000008:notes:39]

[0001408710-23-000018:notes:40]
|  | Fair Value Measurements at Reporting Date Using |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of March 31, 2023 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 19,310 |  |  |  | $ | — |  |  | $ | 19,310 |  |
| Liquidity funds | — |  |  | 40,528 |  |  |  | — |  |  | 40,528 |  |
| Certificates of deposit and time deposits | — |  |  | 44,384 |  |  |  | — |  |  | 44,384 |  |
| Corporate debt securities | — |  |  | 211,168 |  |  |  | — |  |  | 211,168 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 11,900 |  |  |  | — |  |  | 11,900 |  |
| Derivative assets – current portion | — |  |  | 2,078 |  | (1) |  | — |  |  | 2,078 |  |
| Derivative assets – non-current portion | — |  |  | 10 |  | (2) |  | — |  |  | 10 |  |
| Total | $ | — |  |  | $ | 329,378 |  |  |  | $ | — |  |  | $ | 329,378 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | (1,794) |  |  |  | $ | — |  |  | $ | (1,794) |  |
| Total | $ | — |  |  | $ | (1,794) |  | (3) |  | $ | — |  |  | $ | (1,794) |  |

[0001408710-23-000018:notes:41]
[same as prior period, unchanged from 0001408710-23-000008:notes:41]

[0001408710-23-000018:notes:42]
(1)Foreign currency forward contracts with an aggregate notional amount of $78.0 million and an interest rate swap agreement with a notional amount of $64.2 million.

[0001408710-23-000018:notes:43]
[same as prior period, unchanged from 0001408710-23-000008:notes:43]

[0001408710-23-000018:notes:44]
(3)Foreign currency forward contracts with an aggregate notional amount of $52.0 million and 0.4 million Canadian dollars and an interest rate swap agreement with a notional amount of $60.9 million.

[0001408710-23-000018:notes:45]
[same as prior period, unchanged from 0001408710-23-000008:notes:45]

[0001408710-23-000018:notes:46]
[same as prior period, unchanged from 0001408710-23-000008:notes:46]

[0001408710-23-000018:notes:47]
[same as prior period, unchanged from 0001408710-23-000008:notes:47]

[0001408710-23-000018:notes:48]
[same as prior period, unchanged from 0001408710-23-000008:notes:48]

[0001408710-23-000018:notes:49]
[same as prior period, unchanged from 0001408710-23-000008:notes:49]

[0001408710-23-000018:notes:50]
[same as prior period, unchanged from 0001408710-23-000008:notes:50]

[0001408710-23-000018:notes:51]
[same as prior period, unchanged from 0001408710-23-000008:notes:51]

[0001408710-23-000018:notes:52]
[same as prior period, unchanged from 0001408710-23-000008:notes:52]

[0001408710-23-000018:notes:53]
[same as prior period, unchanged from 0001408710-23-000008:notes:53]

[0001408710-23-000018:notes:54]
As of March 31, 2023, the Company had 130 outstanding U.S. dollar foreign currency forward contracts against Thai baht, with an aggregate notional amount of $130.0 million and maturity dates ranging from April 2023 through October 2023 and one outstanding Canadian dollar foreign currency forward contract with a notional amount of 0.4 million Canadian dollars and a maturity date in June 2023.

[0001408710-23-000018:notes:55]
[same as prior period, unchanged from 0001408710-23-000008:notes:55]

[0001408710-23-000018:notes:56]
As of March 31, 2023, the hedging relationship over foreign currency forward contracts that were designated for hedge accounting was determined to be highly effective based on the performance of retrospective and prospective regression testing. As of March 31, 2023, the amount in accumulated other comprehensive income (“AOCI”) that is expected to be reclassified into earnings within 12 months was a loss of $1.0 million.

[0001408710-23-000018:notes:57]
[same as prior period, unchanged from 0001408710-23-000008:notes:57]

[0001408710-23-000018:notes:58]
During the three and nine months ended March 31, 2023, the Company included an unrealized loss of $2.1 million and unrealized gain of $1.8 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-23-000018:notes:59]
During the three and nine months ended March 25, 2022, the Company included an unrealized gain of $0.1 million and $0.6 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-23-000018:notes:60]
[same as prior period, unchanged from 0001408710-23-000008:notes:60]

[0001408710-23-000018:notes:61]
The Company entered into interest rate swap agreements to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. As of March 31, 2023 and June 24, 2022, the Company had two outstanding interest rate swap agreements with an aggregate notional amount of $125.1 million.

[0001408710-23-000018:notes:62]
On July 25, 2018, Fabrinet Thailand entered into an interest rate swap agreement to effectively convert the floating interest rate of the term loan under the Company's previous syndicated senior credit facility agreement to a fixed interest rate of 2.86% per annum through the scheduled maturity of the term loan in June 2023 (see Note 10). The Company did not designate this interest rate swap for hedge accounting.

[0001408710-23-000018:notes:63]
On September 3, 2019, Fabrinet Thailand entered into a term loan agreement under a credit facility agreement with Bank of Ayudhya Public Company Limited, and on September 10, 2019, the Company repaid in full the outstanding term loan under the Company's previous syndicated senior credit facility agreement (see Note 10). In conjunction with the funding of the new term loan, the Company entered into a second interest rate swap agreement. The combination of both of these interest rate swaps effectively converts the floating interest rate of the Company’s term loan with Bank of Ayudhya Public Company Limited to a fixed interest rate of 4.36% per annum through the maturity of the term loan in June 2024.

[0001408710-23-000018:notes:64]
On September 27, 2019, the Company designated these two interest rate swaps as a cash flow hedge for the Company’s term loan under the credit facility agreement with Bank of Ayudhya Public Company Limited. The combination of these two interest rate swaps qualified for hedge accounting because the hedges are highly effective, and the Company has designated and documented contemporaneously the hedging relationships involving these interest rate swaps. While the Company intends to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in earnings. From September 27, 2019, any gains or losses related to these interest rate swaps are recorded in AOCI in the unaudited condensed consolidated balance sheets. The Company reclassifies a portion of the gains or losses from AOCI into earnings at each reporting period based on either the accrued interest amount or the interest payment.

[0001408710-23-000018:notes:65]
As of March 31, 2023, the amount in AOCI that is expected to be reclassified into earnings within 12 months was a gain of $0.3 million.

[0001408710-23-000018:notes:66]
[same as prior period, unchanged from 0001408710-23-000008:notes:66]

[0001408710-23-000018:notes:67]
[same as prior period, unchanged from 0001408710-23-000008:notes:67]

[0001408710-23-000018:notes:68]
|  |  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) | Financialstatementsline item |  | March 31,2023 |  | March 25,2022 |  | March 31,2023 |  | March 25,2022 |
| Derivatives gain (loss) recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Othercomprehensiveincome |  | $ | (5,068) |  |  | $ | 1,009 |  |  | $ | 6,694 |  |  | $ | 2,558 |  |
| Interest rate swaps | Othercomprehensiveincome |  | 242 |  |  | 882 |  |  | 1,068 |  |  | 1,885 |  |
| Total derivatives gain (loss) recognized in other comprehensive income (loss) |  |  | $ | (4,826) |  |  | $ | 1,891 |  |  | $ | 7,762 |  |  | $ | 4,443 |  |
| Derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings: |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Cost of revenues |  | $ | (3,245) |  |  | $ | 1,117 |  |  | $ | 6,083 |  |  | $ | 6,216 |  |
| Foreign currency forward contracts | SG&A |  | (140) |  |  | 46 |  |  | 250 |  |  | 258 |  |
| Foreign currency forward contracts | Foreign exchange loss, net |  | 2,807 |  |  | (2,165) |  |  | (9,183) |  |  | (7,438) |  |
| Interest rate swaps | Interest expense |  | (131) |  |  | (223) |  |  | (477) |  |  | (736) |  |
| Total derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings |  |  | $ | (709) |  |  | $ | (1,225) |  |  | $ | (3,327) |  |  | $ | (1,700) |  |
| Change in net unrealized gain (loss) on derivatives instruments |  |  | $ | (5,535) |  |  | $ | 666 |  |  | $ | 4,435 |  |  | $ | 2,743 |  |

[0001408710-23-000018:notes:69]
[same as prior period, unchanged from 0001408710-23-000008:notes:69]

[0001408710-23-000018:notes:70]
[same as prior period, unchanged from 0001408710-23-000008:notes:70]

[0001408710-23-000018:notes:71]
|  | March 31,2023 |  | June 24,2022 |
| (in thousands) | DerivativeAssets |  | DerivativeLiabilities |  | DerivativeAssets |  | DerivativeLiabilities |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts | $ | 1,378 |  |  | $ | (7) |  |  | $ | — |  |  | $ | (1,561) |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward contracts | 511 |  |  | (1,569) |  |  | — |  |  | (4,821) |  |
| Interest rate swaps | 199 |  |  | (218) |  |  | 110 |  |  | (1,197) |  |
| Derivatives, gross balances | $ | 2,088 |  |  | $ | (1,794) |  |  | $ | 110 |  |  | $ | (7,579) |  |

[0001408710-23-000018:notes:72]
[same as prior period, unchanged from 0001408710-23-000008:notes:72]

[0001408710-23-000018:notes:73]
[same as prior period, unchanged from 0001408710-23-000008:notes:73]


## us-gaap:InventoryDisclosureTextBlock

[0001408710-23-000018:notes:74]
[same as prior period, unchanged from 0001408710-23-000008:notes:74]

[0001408710-23-000018:notes:75]
| (in thousands) | As of March 31,2023 |  | As of June 24,2022 |
| Raw materials | $ | 174,047 |  |  | $ | 275,730 |  |
| Work in progress | 321,908 |  |  | 217,638 |  |
| Finished goods | 30,244 |  |  | 15,203 |  |
| Goods in transit | 28,048 |  |  | 48,574 |  |
| Total inventories | $ | 554,247 |  |  | $ | 557,145 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001408710-23-000018:notes:76]
[same as prior period, unchanged from 0001408710-23-000008:notes:76]

[0001408710-23-000018:notes:77]
[same as prior period, unchanged from 0001408710-23-000008:notes:77]

[0001408710-23-000018:notes:78]
As of March 31, 2023, the maturities of the Company’s operating lease liabilities were as follows:

[0001408710-23-000018:notes:79]
| (in thousands) |  |  |
| 2023 (remaining three months) | $ | 644 |  |  |
| 2024 | 1,213 |  |  |
| 2025 | 45 |  |  |
| Total undiscounted lease payments | 1,902 |  |  |
| Less imputed interest | (33) |  |  |
| Total present value of lease liabilities | $ | 1,869 |  | (1) |

[0001408710-23-000018:notes:80]
(1)Includes current portion of operating lease liabilities of $1.6 million.

[0001408710-23-000018:notes:81]
[same as prior period, unchanged from 0001408710-23-000008:notes:81]

[0001408710-23-000018:notes:82]
Rental expense for long-term leases for the three and nine months ended March 31, 2023 was $0.6 million and $1.8 million, respectively, and for the three and nine months ended March 25, 2022 was $0.7 million and $2.1 million, respectively. Rental expense for short-term leases for the three and nine months ended March 31, 2023 was $0.2 million and $0.3 million, respectively, and for the three and nine months ended March 25, 2022 was $0.1 million and $0.2 million, respectively.

[0001408710-23-000018:notes:83]
[same as prior period, unchanged from 0001408710-23-000008:notes:83]

[0001408710-23-000018:notes:84]
As of March 31, 2023, the Company had one finance lease agreement with a de minimis amount.

[0001408710-23-000018:notes:85]
[same as prior period, unchanged from 0001408710-23-000008:notes:85]

[0001408710-23-000018:notes:86]
|  | As ofMarch 31, 2023 |  | As ofJune 24, 2022 |
| Weighted-average remaining lease term (in years) | 1.3 |  | 1.8 |
| Weighted-average discount rate | 3.4 | % |  | 3.4 | % |

[0001408710-23-000018:notes:87]
The following table presents supplemental disclosure for the unaudited condensed consolidated statement of cash flows related to operating and finance leases for the three and nine months ended March 31, 2023 and March 25, 2022:

[0001408710-23-000018:notes:88]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands) | March 31,2023 |  | March 25,2022 |  | March 31,2023 |  | March 25,2022 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |
| Operating cash flows from operating leases | $ | 575 |  |  | $ | 678 |  |  | $ | 1,877 |  |  | $ | 2,076 |  |
| Financing cash flows from finance leases | $ | 2 |  |  | $ | — |  |  | $ | 7 |  |  | $ | — |  |
| ROU assets obtained in exchange for lease liabilities | $ | — |  |  | $ | — |  |  | $ | 79 |  |  | $ | 38 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001408710-23-000018:notes:89]
[same as prior period, unchanged from 0001408710-23-000008:notes:89]

[0001408710-23-000018:notes:90]
| (in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  |  |  | ForeignCurrencyTranslationAdjustment |  | Net |
| As of March 31, 2023 |  |  |  |  |  |  |  |  |  |
| Software | $ | 10,379 |  |  | $ | (7,908) |  |  |  |  | $ | — |  |  | $ | 2,471 |  |
| Total intangibles (1) | $ | 10,379 |  |  | $ | (7,908) |  |  |  |  | $ | — |  |  | $ | 2,471 |  |

[0001408710-23-000018:notes:91]
(1)Customer relationships and backlog were written-off in March 2023.

[0001408710-23-000018:notes:92]
[same as prior period, unchanged from 0001408710-23-000008:notes:91]

[0001408710-23-000018:notes:93]
The Company recorded amortization expense relating to intangibles of $0.3 million and $0.4 million for the three months ended March 31, 2023 and March 25, 2022, respectively, and $1.1 million and $1.2 million for the nine months ended March 31, 2023 and March 25, 2022, respectively.

[0001408710-23-000018:notes:94]
[same as prior period, unchanged from 0001408710-23-000008:notes:93]

[0001408710-23-000018:notes:95]
| (years) | As ofMarch 31, 2023 |  | As ofJune 24, 2022 |
| Software | 3.2 |  | 3.8 |
| Customer relationships | — |  |  | 3.1 |
| Total intangibles | 3.2 |  | 3.8 |

[0001408710-23-000018:notes:96]
Based on the carrying amount of intangibles as of March 31, 2023, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001408710-23-000018:notes:97]
| (in thousands) |  |
| 2023 (remaining three months) | $ | 235 |  |
| 2024 | 847 |  |
| 2025 | 660 |  |
| 2026 | 438 |  |
| 2027 | 230 |  |
| Thereafter | 61 |  |
| Total | $ | 2,471 |  |


## us-gaap:DebtDisclosureTextBlock

[0001408710-23-000018:notes:98]
Borrowings 
The Company’s total borrowings, including current and non-current portions of long-term borrowings, consisted of the following:

[0001408710-23-000018:notes:99]
| (in thousands of U.S. dollars) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofMarch 31, 2023 |  | As ofJune 24, 2022 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 15,234 |  |  | $ | 27,421 |  |
| Less: Current portion |  |  |  |  | (12,187) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs, non-current portion |  |  |  |  | (8) |  |  | (31) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 3,039 |  |  | $ | 15,202 |  |

[0001408710-23-000018:notes:100]
(1)The Company has entered into interest rate swaps that effectively fix a series of future interest payments on its term loans. Refer to Note 6.

[0001408710-23-000018:notes:101]
The movements of long-term borrowings for the nine months ended March 31, 2023 and March 25, 2022 were as follows:

[0001408710-23-000018:notes:102]
|  | Nine Months Ended |
| (in thousands) | March 31,2023 |  | March 25,2022 |
| Opening balance | $ | 27,421 |  |  | $ | 39,609 |  |
| Repayments during the period | (12,187) |  |  | (9,141) |  |
| Closing balance | $ | 15,234 |  |  | $ | 30,468 |  |

[0001408710-23-000018:notes:103]
As of March 31, 2023, future maturities of long-term borrowings during each fiscal year were as follows:

[0001408710-23-000018:notes:104]
| (in thousands) |  |
| 2023 (remaining three months) | $ | 3,047 |  |
| 2024 | 12,187 |  |
| Total | $ | 15,234 |  |

[0001408710-23-000018:notes:105]
Credit facility agreements:

[0001408710-23-000018:notes:106]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a credit facility agreement (the “2019 Credit Facility Agreement”), which provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million that may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the 2019 Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

[0001408710-23-000018:notes:107]
Under the 2019 Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a term loan agreement (the "Term Loan Agreement") pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company's previous syndicated senior credit facility agreement.

[0001408710-23-000018:notes:108]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. On March 9, 2023, the Borrower and the Bank amended the Term Loan Agreement to replace the interest rate reference from LIBOR to the Secured Overnight Financing Rate ("SOFR") effective from September 29, 2023. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed

[0001408710-23-000018:notes:109]
again. During the three and nine months ended March 31, 2023, the Company recorded $0.6 million and $1.7 million, respectively, of interest expense in connection with this term loan, including the impact from interest rate swaps.

[0001408710-23-000018:notes:110]
Any borrowings under the 2019 Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

[0001408710-23-000018:notes:111]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, and restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of March 31, 2023, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

[0001408710-23-000018:notes:112]
The events of default under the Term Loan Agreement include failure to timely pay amounts due under the Term Loan Agreement or the related finance documents, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

[0001408710-23-000018:notes:113]
As of March 31, 2023, there was $15.2 million outstanding under the term loan.

[0001408710-23-000018:notes:114]
On March 9, 2023, Fabrinet Thailand and the Parent Company (the “Borrowers”) and the Bank entered into a credit facility agreement (the “2023 Credit Facility Agreement”), which provides a facility of $55.0 million.

[0001408710-23-000018:notes:115]
Any borrowings under the 2023 Credit Facility Agreement are secured by land and buildings owned by the Borrowers in the Pathumthani and Chonburi Provinces in Thailand.

[0001408710-23-000018:notes:116]
Under the 2023 Credit Facility Agreement, the Borrowers are required to maintain a loan to value of the mortgaged real property ratio of not greater than 60%. The Borrowers are also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times.

[0001408710-23-000018:notes:117]
As of March 31, 2023, there was no amount outstanding under the 2023 Credit Facility.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001408710-23-000018:notes:118]
Income taxes
As of March 31, 2023 and June 24, 2022, the liability for uncertain tax positions including accrued interest and penalties was $0.9 million and $1.6 million, respectively. The Company expects the estimated amount of liability associated with its uncertain tax positions to decrease within the next 12 months due to the expiration of statutes of limitations with respect to these positions.

[0001408710-23-000018:notes:119]
[same as prior period, unchanged from 0001408710-23-000008:notes:115]

[0001408710-23-000018:notes:120]
The effective tax rate for the Company for the three months ended March 31, 2023 and March 25, 2022 was 6.5% and 5.4%, respectively, of net income. The increase was primarily due to an increase in income subject to tax during the three months ended March 31, 2023 as compared to the three months ended March 25, 2022.

[0001408710-23-000018:notes:121]
The effective tax rate for the Company for the nine months ended March 31, 2023 and March 25, 2022 was 3.1% and 3.2%, respectively, of net income. The decrease was primarily due to lower annualized effective tax rate offset by an increase in income subject to tax during the nine months ended March 31, 2023 as compared to the nine months ended March 25, 2022.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001408710-23-000018:notes:122]
[same as prior period, unchanged from 0001408710-23-000008:notes:118]

[0001408710-23-000018:notes:123]
[same as prior period, unchanged from 0001408710-23-000008:notes:119]

[0001408710-23-000018:notes:124]
The effect of recording share-based compensation expense for the three and nine months ended March 31, 2023 and March 25, 2022 was as follows:

[0001408710-23-000018:notes:125]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands) | March 31,2023 |  | March 25,2022 |  | March 31,2023 |  | March 25,2022 |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |
| Restricted share units | $ | 3,945 |  |  | $ | 3,126 |  |  | $ | 12,845 |  |  | $ | 11,720 |  |
| Performance share units | 2,774 |  |  | 2,597 |  |  | 8,372 |  |  | 9,981 |  |
| Total share-based compensation expense | 6,719 |  |  | 5,723 |  |  | 21,217 |  |  | 21,701 |  |
| Tax effect on share-based compensation expense | — |  |  | — |  |  | — |  |  | — |  |
| Net effect on share-based compensation expense | $ | 6,719 |  |  | $ | 5,723 |  |  | $ | 21,217 |  |  | $ | 21,701 |  |

[0001408710-23-000018:notes:126]
[same as prior period, unchanged from 0001408710-23-000008:notes:122]

[0001408710-23-000018:notes:127]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands) | March 31,2023 |  | March 25,2022 |  | March 31,2023 |  | March 25,2022 |
| Cost of revenue | $ | 1,453 |  |  | $ | 1,183 |  |  | $ | 5,028 |  |  | $ | 4,579 |  |
| Selling, general and administrative expense | 5,080 |  |  | 4,540 |  |  | 16,003 |  |  | 17,122 |  |
| Restructuring and other related costs | 186 |  |  | — |  |  | 186 |  |  | — |  |
| Total share-based compensation expense | $ | 6,719 |  |  | $ | 5,723 |  |  | $ | 21,217 |  |  | $ | 21,701 |  |

[0001408710-23-000018:notes:128]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the three and nine months ended March 31, 2023 and March 25, 2022.

[0001408710-23-000018:notes:129]
[same as prior period, unchanged from 0001408710-23-000008:notes:125]

[0001408710-23-000018:notes:130]
[same as prior period, unchanged from 0001408710-23-000008:notes:126]

[0001408710-23-000018:notes:131]
As of March 31, 2023, there were 343,211 restricted share units outstanding, 204,016 performance share units outstanding and 1,958,203 ordinary shares available for future grant under the 2020 Plan.

[0001408710-23-000018:notes:132]
As of March 31, 2023, there were 30,827 restricted share units outstanding under the 2010 Plan. No ordinary shares are available for future grant under the 2010 Plan.

[0001408710-23-000018:notes:133]
On November 2, 2017, the Company adopted the 2017 Inducement Equity Incentive Plan (the “2017 Inducement Plan”) with a reserve of 160,000 ordinary shares authorized for future issuance solely for the granting of inducement share options and equity awards to new employees. The 2017 Inducement Plan was adopted without shareholder approval in reliance on the “employment inducement exemption” provided under the New York Stock Exchange Listed Company Manual. As of March 31, 2023, there were no awards outstanding and 111,347 ordinary shares available for future grant under the 2017 Inducement Plan.

[0001408710-23-000018:notes:134]
[same as prior period, unchanged from 0001408710-23-000008:notes:130]

[0001408710-23-000018:notes:135]
The following table summarizes the number of equity awards outstanding and ordinary shares available for grant under each of the Equity Incentive Plans as of March 31, 2023:

[0001408710-23-000018:notes:136]
| (share units) | Restricted Share Units outstanding |  | Performance Share Units outstanding |  | Ordinary Shares available for future grant |
| 2020 Plan | 343,211 |  |  | 204,016 |  |  | 1,958,203 |  |
| 2010 Plan | 30,827 |  |  | — |  |  | — |  |
| 2017 Inducement Plan | — |  |  | — |  |  | 111,347 |  |
| Total | 374,038 |  |  | 204,016 |  |  | 2,069,550 |  |

[0001408710-23-000018:notes:137]
[same as prior period, unchanged from 0001408710-23-000008:notes:131]

[0001408710-23-000018:notes:138]
[same as prior period, unchanged from 0001408710-23-000008:notes:132]

[0001408710-23-000018:notes:139]
[same as prior period, unchanged from 0001408710-23-000008:notes:133]

[0001408710-23-000018:notes:140]
[same as prior period, unchanged from 0001408710-23-000008:notes:134]

[0001408710-23-000018:notes:141]
[same as prior period, unchanged from 0001408710-23-000008:notes:135]

[0001408710-23-000018:notes:142]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 24, 2022 | 459,626 |  |  | $ | 75.14 |  |
| Granted | 154,113 |  |  | $ | 119.23 |  |
| Vested | (220,004) |  |  | $ | 67.23 |  |
| Forfeited | (19,697) |  |  | $ | 91.84 |  |
| Balance as of March 31, 2023 | 374,038 |  |  | $ | 97.08 |  |

[0001408710-23-000018:notes:143]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 25, 2021 | 641,875 |  |  | $ | 55.74 |  |
| Granted | 165,684 |  |  | $ | 102.74 |  |
| Vested | (310,473) |  |  | $ | 51.12 |  |
| Forfeited | (36,158) |  |  | $ | 69.84 |  |
| Balance as of March 25, 2022 | 460,928 |  |  | $ | 73.96 |  |

[0001408710-23-000018:notes:144]
[same as prior period, unchanged from 0001408710-23-000008:notes:138]

[0001408710-23-000018:notes:145]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 24, 2022 | 285,882 |  |  | $ | 81.64 |  |
| Granted | 97,142 |  |  | $ | 117.35 |  |
| Vested | (179,008) |  |  | $ | 70.05 |  |
| Forfeited | — |  |  | $ | — |  |
| Balance as of March 31, 2023 | 204,016 |  |  | $ | 108.81 |  |

[0001408710-23-000018:notes:146]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 25, 2021 | 427,028 |  |  | $ | 57.82 |  |
| Granted | 110,832 |  |  | $ | 101.05 |  |
| Vested | (190,213) |  |  | 48.65 |  |
| Forfeited | (61,765) |  |  | $ | 53.38 |  |
| Balance as of March 25, 2022 | 285,882 |  |  | $ | 81.64 |  |

[0001408710-23-000018:notes:147]
[same as prior period, unchanged from 0001408710-23-000008:notes:141]

[0001408710-23-000018:notes:148]
As of March 31, 2023, there was $15.1 million and $9.4 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.6 and 1.2 years, respectively.

[0001408710-23-000018:notes:149]
For the nine months ended March 31, 2023 and March 25, 2022, the Company withheld an aggregate of 172,929 shares and 210,006 shares, respectively, upon the vesting of restricted share units and performance shares units, based upon the closing share price on the vesting date to settle employee tax withholding obligations. For the nine months ended March 31, 2023 and March 25, 2022, the Company then remitted cash of $17.7 million and $20.4 million, respectively, to the appropriate taxing authorities and presented it as a financing activity within the unaudited condensed consolidated statements of cash flows. The payment was recorded as a reduction of additional paid-in capital.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001408710-23-000018:notes:150]
[same as prior period, unchanged from 0001408710-23-000008:notes:144]

[0001408710-23-000018:notes:151]
Fabrinet’s authorized share capital is 500,000,000 ordinary shares, par value of $0.01 per ordinary share, and 5,000,000 preferred shares, par value of $0.01 per preferred share.

[0001408710-23-000018:notes:152]
For the three and nine months ended March 31, 2023, Fabrinet issued 23,202 and 226,083 ordinary shares, respectively, upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-23-000018:notes:153]
For the three and nine months ended March 25, 2022, Fabrinet issued 30,729 and 290,680 ordinary shares, respectively, upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-23-000018:notes:154]
[same as prior period, unchanged from 0001408710-23-000008:notes:148]

[0001408710-23-000018:notes:155]
[same as prior period, unchanged from 0001408710-23-000008:notes:149]

[0001408710-23-000018:notes:156]
In August 2017, the Company’s board of directors approved a share repurchase program to permit the Company to repurchase up to $30.0 million worth of its issued and outstanding ordinary shares in the open market in accordance with applicable rules and regulations. In February 2018, May 2019, August 2020 and August 2022, the Company’s board of directors approved an increase of $30.0 million, $50.0 million, $58.5 million and $78.7 million, respectively, to the original share repurchase authorization, bringing the aggregate authorization to $247.2 million. 
During the nine months ended March 31, 2023, the Company repurchased 83,857 shares under the program at an average price per share (excluding other direct costs) of $109.89 totaling $9.2 million. As of March 31, 2023, the Company had a remaining authorization to repurchase up to $90.8 million worth of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001408710-23-000018:notes:157]
Accumulated other comprehensive income (loss)
The changes in AOCI for the nine months ended March 31, 2023 and March 25, 2022 were as follows:

[0001408710-23-000018:notes:158]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 24, 2022 | $ | (6,018) |  |  | $ | (5,082) |  |  | $ | (803) |  |  | $ | (890) |  |  | $ | (12,793) |  |
| Other comprehensive income (loss) before reclassification adjustment | 1,675 |  |  | 7,762 |  |  | — |  |  | (29) |  |  | 9,408 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | 93 |  |  | (3,327) |  |  | 338 |  |  | — |  |  | (2,896) |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | $ | 1,768 |  |  | $ | 4,435 |  |  | $ | 338 |  |  | $ | (29) |  |  | $ | 6,512 |  |
| Balance as of March 31, 2023 | $ | (4,250) |  |  | $ | (647) |  |  | $ | (465) |  |  | $ | (919) |  |  | $ | (6,281) |  |

[0001408710-23-000018:notes:159]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 25, 2021 | $ | 308 |  |  | $ | (4,504) |  |  | $ | (1,425) |  |  | $ | (645) |  |  | $ | (6,266) |  |
| Other comprehensive income (loss) before reclassification adjustment | (3,602) |  |  | 4,443 |  |  | — |  |  | (198) |  |  | 643 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | (13) |  |  | (1,700) |  |  | 448 |  |  | — |  |  | (1,265) |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | $ | (3,615) |  |  | $ | 2,743 |  |  | $ | 448 |  |  | $ | (198) |  |  | $ | (622) |  |
| Balance as of March 25, 2022 | $ | (3,307) |  |  | $ | (1,761) |  |  | $ | (977) |  |  | $ | (843) |  |  | $ | (6,888) |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001408710-23-000018:notes:160]
Commitments and contingencies
Bank guarantees

[0001408710-23-000018:notes:161]
As of March 31, 2023 and June 24, 2022, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $1.6 million and $1.4 million, respectively, or Thai baht 53.0 million and 50.2 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the operations related to the Customs department.

[0001408710-23-000018:notes:162]
As of June 24, 2022, there was an outstanding bank guarantee on behalf of the Company's subsidiary in the PRC to support the subsidiary's operations totaling Renminbi 1.0 million, which bank guarantee was backed by cash collateral of $0.1 million. This bank guarantee was released in December 2022. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in the U.K. to support its operations.

[0001408710-23-000018:notes:163]
Purchase obligations

[0001408710-23-000018:notes:164]
Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001408710-23-000018:notes:165]
As of March 31, 2023, the Company had a purchase obligation and other commitments to third parties of $1.09 billion.

[0001408710-23-000018:notes:166]
Capital expenditures

[0001408710-23-000018:notes:167]
As of March 31, 2023, the Company had total capital expenditure commitments to third parties of $18.3 million.

[0001408710-23-000018:notes:168]
Indemnification of directors and officers

[0001408710-23-000018:notes:169]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001408710-23-000018:notes:170]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001408710-23-000018:notes:171]
Restructuring and other related costsRestructuring and other related costs may consist of voluntary or involuntary severance-related charges, asset-related charges and other costs due to exit activities. We recognize voluntary severance-related charges when an employee accepts the offered benefit arrangement. We recognize involuntary severance-related charges depending on whether the termination benefits are provided under an ongoing benefit arrangement or under a one-time benefit arrangement. If the former, we recognize the charges once they are probable and the amounts are estimable. If the latter, we recognize the charges once the benefits have been communicated to employees.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001408710-23-000018:notes:172]
Business segments and geographic information
Operating segments are defined as components of an enterprise for which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. The Company’s chief operating decision maker is Fabrinet’s Chief Executive Officer. As of March 31, 2023, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001408710-23-000018:notes:173]
[same as prior period, unchanged from 0001408710-23-000008:notes:167]

[0001408710-23-000018:notes:174]
[same as prior period, unchanged from 0001408710-23-000008:notes:168]

[0001408710-23-000018:notes:175]
| (in thousands) |  | March 31,2023 |  | June 24,2022 |
| Long-Lived Assets: |  |  |  |  |
| Thailand |  | $ | 261,506 |  |  | $ | 240,750 |  |
| U.S. |  | 25,669 |  |  | 25,938 |  |
| China |  | 17,651 |  |  | 19,686 |  |
| Israel |  | 3,023 |  |  | 4,025 |  |
| Others |  | 516 |  |  | 1,878 |  |
| Total |  | $ | 308,365 |  |  | $ | 292,277 |  |

[0001408710-23-000018:notes:176]
[same as prior period, unchanged from 0001408710-23-000008:notes:170]

[0001408710-23-000018:notes:177]
The Company had three customers that each contributed to 10% or more of the Company's total trade accounts receivable as of March 31, 2023 and June 24, 2022.
