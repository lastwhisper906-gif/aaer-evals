# FN 8-K — 0001408710-23-000016 filed 2023-05-08

## item codes, every 8-K on or before 2023-05-09

- 2023-05-08 0001408710-23-000016 — 2.02, 5.02, 9.01
- 2023-02-06 0001408710-23-000006 — 2.02, 9.01
- 2022-12-13 0001408710-22-000062 — 5.07
- 2022-11-07 0001408710-22-000058 — 2.02, 9.01
- 2022-08-15 0001408710-22-000041 — 2.02, 5.02, 9.01
- 2022-05-02 0001408710-22-000026 — 2.02, 9.01
- 2022-01-31 0001408710-22-000016 — 2.02, 9.01
- 2022-01-19 0001408710-22-000010 — 5.02
- 2022-01-06 0001408710-22-000006 — 5.02
- 2021-12-10 0001408710-21-000051 — 5.07
- 2021-11-01 0001408710-21-000045 — 2.02, 9.01
- 2021-08-16 0001408710-21-000031 — 2.02, 5.02, 9.01
- 2021-05-03 0001408710-21-000019 — 2.02, 9.01
- 2021-02-01 0001408710-21-000008 — 2.02, 9.01
- 2020-12-11 0001193125-20-315861 — 5.07
- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2023-05-09

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001408710-23-000016:8k_2_02:1]
EX-99.1
3
fn-20230508xex991q323.htm
EX-99.1

[0001408710-23-000016:8k_2_02:2]
Document

[0001408710-23-000016:8k_2_02:3]
Exhibit 99.1

[0001408710-23-000016:8k_2_02:4]
Fabrinet Announces Third Quarter Fiscal Year 2023 Financial Results

[0001408710-23-000016:8k_2_02:5]
•Record Third Quarter Revenue of $665.3 Million Exceeds Guidance

[0001408710-23-000016:8k_2_02:6]
BANGKOK, Thailand – May 8, 2023 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its third fiscal quarter ended March 31, 2023.

[0001408710-23-000016:8k_2_02:7]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “Revenue in the third quarter was above our guidance range, and we demonstrated the operating leverage inherent in our business model. While near-term inventory adjustments are affecting some parts of our business, the impacts are being somewhat offset by growth from other customer programs and continued gradual improvements in component availability. Our strong execution continues to benefit our bottom line results and we remain well-positioned to extend our success.”

[0001408710-23-000016:8k_2_02:8]
Third Quarter Fiscal Year 2023 Financial Highlights

[0001408710-23-000016:8k_2_02:9]
GAAP Results

[0001408710-23-000016:8k_2_02:10]
•Revenue for the third quarter of fiscal year 2023 was $665.3 million, compared to $564.4 million for the third quarter of fiscal year 2022.

[0001408710-23-000016:8k_2_02:11]
•GAAP net income for the third quarter of fiscal year 2023 was $59.4 million, compared to $50.7 million for the third quarter of fiscal year 2022.

[0001408710-23-000016:8k_2_02:12]
•GAAP net income per diluted share for the third quarter of fiscal year 2023 was $1.60, compared to $1.35 for the third quarter of fiscal year 2022.

[0001408710-23-000016:8k_2_02:13]
Non-GAAP Results

[0001408710-23-000016:8k_2_02:14]
•Non-GAAP net income for the third quarter of fiscal year 2023 was $71.8 million, compared to $56.2 million for the third quarter of fiscal year 2022.

[0001408710-23-000016:8k_2_02:15]
•Non-GAAP net income per diluted share for the third quarter of fiscal year 2023 was $1.94, compared to $1.50 for the third quarter of fiscal year 2022.

[0001408710-23-000016:8k_2_02:16]
Business Outlook

[0001408710-23-000016:8k_2_02:17]
Based on information available as of May 8, 2023, Fabrinet is issuing guidance for its fourth fiscal quarter ending June 30, 2023, as follows:

[0001408710-23-000016:8k_2_02:18]
•Fabrinet expects fourth quarter revenue to be in the range of $630 million to $650 million.

[0001408710-23-000016:8k_2_02:19]
•GAAP net income per diluted share is expected to be in the range of $1.57 to $1.64, based on approximately 37.0 million fully diluted shares outstanding.

[0001408710-23-000016:8k_2_02:20]
•Non-GAAP net income per diluted share is expected to be in the range of $1.76 to $1.83, based on approximately 37.0 million fully diluted shares outstanding.

[0001408710-23-000016:8k_2_02:21]
Guidance for non-GAAP net income per diluted share excludes share-based compensation expenses and certain non-recurring items. A reconciliation of non-GAAP net income per diluted share to the corresponding GAAP measure is available at the end of this press release.

[0001408710-23-000016:8k_2_02:22]
Conference Call Information

[0001408710-23-000016:8k_2_02:23]
| What: |  | Fabrinet Third Quarter Fiscal Year 2023 Financial Results Call |
| When: |  | May 8, 2023 |
| Time: |  | 5:00 p.m. ET |
| Live Call and Replay: |  | https://investor.fabrinet.com/events-and-presentations/events |

[0001408710-23-000016:8k_2_02:24]
A recorded version of this webcast will be available approximately two hours after the call and accessible at http://investor.fabrinet.com. The webcast will be archived on Fabrinet’s website for a period of one year.

[0001408710-23-000016:8k_2_02:25]
About Fabrinet

[0001408710-23-000016:8k_2_02:26]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China, and Israel. For more information visit: www.fabrinet.com.

[0001408710-23-000016:8k_2_02:27]
Forward-Looking Statements

[0001408710-23-000016:8k_2_02:28]
Use of Non-GAAP Financials

[0001408710-23-000016:8k_2_02:29]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; depreciation of fair value uplift; amortization of intangibles; severance payment and others; restructuring and other related costs; and amortization of deferred debt issuance costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001408710-23-000016:8k_2_02:30]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001408710-23-000016:8k_2_02:31]
Investor Contact:

[0001408710-23-000016:8k_2_02:32]
Garo Toomajanian

[0001408710-23-000016:8k_2_02:33]
ir@fabrinet.com

[0001408710-23-000016:8k_2_02:34]
FABRINET

[0001408710-23-000016:8k_2_02:35]
CONDENSED CONSOLIDATED BALANCE SHEETS (unaudited)

[0001408710-23-000016:8k_2_02:36]
| (in thousands of U.S. dollars, except share data and par value) | March 31,2023 |  | June 24,2022 |
| Assets |  |  |  |
| Current assets |  |  |  |
| Cash and cash equivalents | $ | 230,743 |  |  | $ | 197,996 |  |
| Short-term restricted cash | — |  |  | 220 |  |
| Short-term investments | 307,980 |  |  | 280,157 |  |
| Trade accounts receivable, net of allowance for doubtful accounts of $1,031 and $1,271, respectively | 540,343 |  |  | 439,330 |  |
| Contract assets | 21,081 |  |  | 13,464 |  |
| Inventories | 554,247 |  |  | 557,145 |  |
| Prepaid expenses | 10,606 |  |  | 11,626 |  |
| Other current assets | 39,610 |  |  | 25,233 |  |
| Total current assets | 1,704,610 |  |  | 1,525,171 |  |
| Non-current assets |  |  |  |
| Long-term restricted cash | — |  |  | 149 |  |
| Property, plant and equipment, net | 308,365 |  |  | 292,277 |  |
| Intangibles, net | 2,471 |  |  | 3,508 |  |
| Operating right-of-use assets | 2,210 |  |  | 4,084 |  |
| Deferred tax assets | 10,487 |  |  | 9,800 |  |
| Other non-current assets | 658 |  |  | 652 |  |
| Total non-current assets | 324,191 |  |  | 310,470 |  |
| Total Assets | $ | 2,028,801 |  |  | $ | 1,835,641 |  |
| Liabilities and Shareholders’ Equity |  |  |  |
| Current liabilities |  |  |  |
| Long-term borrowings, current portion, net | $ | 12,156 |  |  | $ | 12,156 |  |
| Trade accounts payable | 436,085 |  |  | 439,684 |  |
| Fixed assets payable | 20,116 |  |  | 9,085 |  |
| Contract liabilities | 3,249 |  |  | 1,982 |  |
| Operating lease liabilities, current portion | 1,634 |  |  | 2,319 |  |
| Income tax payable | 2,785 |  |  | 2,898 |  |
| Accrued payroll, bonus and related expenses | 28,899 |  |  | 20,374 |  |
| Accrued expenses | 23,428 |  |  | 24,758 |  |
| Other payables | 26,637 |  |  | 25,231 |  |
| Total current liabilities | 554,989 |  |  | 538,487 |  |
| Non-current liabilities |  |  |  |
| Long-term borrowings, non-current portion, net | 3,039 |  |  | 15,202 |  |
| Deferred tax liability | 6,159 |  |  | 6,001 |  |
| Operating lease liability, non-current portion | 235 |  |  | 1,476 |  |
| Severance liabilities | 21,267 |  |  | 18,384 |  |
| Other non-current liabilities | 1,531 |  |  | 2,409 |  |
| Total non-current liabilities | 32,231 |  |  | 43,472 |  |
| Total Liabilities | 587,220 |  |  | 581,959 |  |
| Shareholders’ equity |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of March 31, 2023 and June 24, 2022) | — |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 39,274,783 shares and 39,048,700 shares issued at March 31, 2023 and June 24, 2022, respectively; and 36,578,909 shares and 36,436,683 shares outstanding at March 31, 2023 and June 24, 2022, respectively) | 393 |  |  | 390 |  |
| Additional paid-in capital | 200,141 |  |  | 196,667 |  |
| Less: Treasury shares (2,695,874 shares and 2,612,017 shares as of March 31, 2023 and June 24, 2022, respectively) | (156,475) |  |  | (147,258) |  |
| Accumulated other comprehensive income (loss) | (6,281) |  |  | (12,793) |  |
| Retained earnings | 1,403,803 |  |  | 1,216,676 |  |
| Total Shareholders’ Equity | 1,441,581 |  |  | 1,253,682 |  |
| Total Liabilities and Shareholders’ Equity | $ | 2,028,801 |  |  | $ | 1,835,641 |  |

[0001408710-23-000016:8k_2_02:37]
FABRINET

[0001408710-23-000016:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME (unaudited)

[0001408710-23-000016:8k_2_02:39]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands of U.S. dollars, except per share data) | March 31,2023 |  | March 25,2022 |  | March 31,2023 |  | March 25,2022 |
| Revenues | $ | 665,281 |  |  | $ | 564,395 |  |  | $ | 1,989,366 |  |  | $ | 1,674,350 |  |
| Cost of revenues | (579,274) |  |  | (493,702) |  |  | (1,735,388) |  |  | (1,470,689) |  |
| Gross profit | 86,007 |  |  | 70,693 |  |  | 253,978 |  |  | 203,661 |  |
| Selling, general and administrative expenses | (18,309) |  |  | (17,034) |  |  | (57,804) |  |  | (55,412) |  |
| Restructuring and other related costs | (5,872) |  |  | — |  |  | (5,872) |  |  | (135) |  |
| Operating income | 61,826 |  |  | 53,659 |  |  | 190,302 |  |  | 148,114 |  |
| Interest income | 3,317 |  |  | 414 |  |  | 7,210 |  |  | 1,470 |  |
| Interest expense | (399) |  |  | (73) |  |  | (1,179) |  |  | (347) |  |
| Foreign exchange gain (loss), net | (1,303) |  |  | (410) |  |  | (3,122) |  |  | 998 |  |
| Other income (expense), net | 31 |  |  | (36) |  |  | (178) |  |  | (1,351) |  |
| Income before income taxes | 63,472 |  |  | 53,554 |  |  | 193,033 |  |  | 148,884 |  |
| Income tax expense | (4,117) |  |  | (2,893) |  |  | (5,906) |  |  | (4,693) |  |
| Net income | 59,355 |  |  | 50,661 |  |  | 187,127 |  |  | 144,191 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities | 2,046 |  |  | (2,455) |  |  | 1,768 |  |  | (3,615) |  |
| Change in net unrealized gain (loss) on derivative instruments | (5,535) |  |  | 666 |  |  | 4,435 |  |  | 2,743 |  |
| Change in net retirement benefits plan – prior service cost | 113 |  |  | 124 |  |  | 338 |  |  | 448 |  |
| Change in foreign currency translation adjustment | (191) |  |  | (34) |  |  | (29) |  |  | (198) |  |
| Total other comprehensive income (loss), net of tax | (3,567) |  |  | (1,699) |  |  | 6,512 |  |  | (622) |  |
| Net comprehensive income | $ | 55,788 |  |  | $ | 48,962 |  |  | $ | 193,639 |  |  | $ | 143,569 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 1.62 |  |  | $ | 1.37 |  |  | $ | 5.12 |  |  | $ | 3.90 |  |
| Diluted | $ | 1.60 |  |  | $ | 1.35 |  |  | $ | 5.07 |  |  | $ | 3.85 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |
| Basic | 36,608 |  |  | 36,940 |  |  | 36,575 |  |  | 36,945 |  |
| Diluted | 36,989 |  |  | 37,473 |  |  | 36,895 |  |  | 37,451 |  |

[0001408710-23-000016:8k_2_02:40]
FABRINET

[0001408710-23-000016:8k_2_02:41]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited)

[0001408710-23-000016:8k_2_02:42]
|  | Nine Months Ended |
| (in thousands of U.S. dollars) | March 31,2023 |  | March 25,2022 |
| Cash flows from operating activities |  |  |  |
| Net income for the period | $ | 187,127 |  |  | $ | 144,191 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 32,504 |  |  | 28,907 |  |
| Non-cash restructuring charges and other related costs | 2,201 |  |  | — |  |
| (Gain) loss on disposal and impairment of property, plant and equipment | (1,630) |  |  | (175) |  |
| (Gain) loss from sales and maturities of available-for-sale securities | 92 |  |  | (13) |  |
| Amortization of discount (premium) of short-term investments | 300 |  |  | 3,038 |  |
| Amortization of deferred debt issuance costs | 24 |  |  | 24 |  |
| (Reversal of) allowance for doubtful accounts | (240) |  |  | (39) |  |
| Unrealized loss (gain) on exchange rate and fair value of foreign currency forward contracts | 693 |  |  | (1,422) |  |
| Amortization of fair value at hedge inception of interest rate swaps | (478) |  |  | (736) |  |
| Share-based compensation | 21,217 |  |  | 21,701 |  |
| Deferred income tax | (276) |  |  | 563 |  |
| Other non-cash expenses | (151) |  |  | 1,067 |  |
| Changes in operating assets and liabilities |  |  |  |
| Trade accounts receivable | (98,212) |  |  | (109,334) |  |
| Contract assets | (7,617) |  |  | (1,690) |  |
| Inventories | 2,720 |  |  | (30,503) |  |
| Other current assets and non-current assets | (11,807) |  |  | (11,221) |  |
| Trade accounts payable | (5,028) |  |  | 55,333 |  |
| Contract liabilities | 1,267 |  |  | 243 |  |
| Income tax payable | (262) |  |  | (872) |  |
| Severance liabilities | 1,917 |  |  | 1,883 |  |
| Other current liabilities and non-current liabilities | 17,861 |  |  | 6,952 |  |
| Net cash provided by operating activities | 142,222 |  |  | 107,897 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of short-term investments | (154,033) |  |  | (119,853) |  |
| Proceeds from sales of short-term investments | 30,179 |  |  | 19,463 |  |
| Proceeds from maturities of short-term investments | 97,408 |  |  | 92,862 |  |
| Purchase of property, plant and equipment | (43,422) |  |  | (75,327) |  |
| Purchase of intangibles | (698) |  |  | (592) |  |
| Proceeds from disposal of property, plant and equipment | 117 |  |  | 229 |  |
| Net cash used in investing activities | (70,449) |  |  | (83,218) |  |
| Cash flows from financing activities |  |  |  |
| Repayment of long-term borrowings | (12,187) |  |  | (9,141) |  |
| Repayment of finance lease liability | (7) |  |  | — |  |
| Repurchase of ordinary shares | (9,217) |  |  | (28,624) |  |
| Withholding tax related to net share settlement of restricted share units | (17,740) |  |  | (20,439) |  |
| Net cash used in financing activities | (39,151) |  |  | (58,204) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | 32,622 |  |  | $ | (33,525) |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at the beginning of period | $ | 198,365 |  |  | $ | 303,123 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | 32,622 |  |  | (33,525) |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash | (244) |  |  | (301) |  |
| Cash, cash equivalents and restricted cash at the end of period | $ | 230,743 |  |  | $ | 269,297 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment-related payables | $ | 20,116 |  |  | $ | 14,060 |  |

[0001408710-23-000016:8k_2_02:43]
FABRINET

[0001408710-23-000016:8k_2_02:44]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited) (Continued)

[0001408710-23-000016:8k_2_02:45]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the condensed consolidated balance sheets that sum to the total of the same amounts shown in the condensed consolidated statements of cash flows:

[0001408710-23-000016:8k_2_02:46]
|  | As of |
| (in thousands) | March 31,2023 |  | March 25,2022 |
| Cash and cash equivalents | $ | 230,743 |  |  | $ | 269,140 |  |
| Restricted cash | — |  |  | 157 |  |
| Cash, cash equivalents and restricted cash | $ | 230,743 |  |  | $ | 269,297 |  |

[0001408710-23-000016:8k_2_02:47]
FABRINET

[0001408710-23-000016:8k_2_02:48]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-23-000016:8k_2_02:49]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31,2023 |  | March 25,2022 |  | March 31,2023 |  | March 25,2022 |
| (in thousands of U.S. dollars, except share data) | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |
| GAAP measures | $ | 59,355 |  |  | $ | 1.60 |  |  | $ | 50,661 |  |  | $ | 1.35 |  |  | $ | 187,127 |  |  | $ | 5.07 |  |  | $ | 144,191 |  |  | $ | 3.85 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 1,453 |  |  | 0.04 |  |  | 1,183 |  |  | 0.03 |  |  | 5,028 |  |  | 0.14 |  |  | 4,579 |  |  | 0.12 |  |
| Depreciation of fair value uplift | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 92 |  |  | 0.00 |  |
| Total related to gross profit | 1,453 |  |  | 0.04 |  |  | 1,183 |  |  | 0.03 |  |  | 5,028 |  |  | 0.14 |  |  | 4,671 |  |  | 0.12 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 5,080 |  |  | 0.14 |  |  | 4,540 |  |  | 0.12 |  |  | 16,003 |  |  | 0.43 |  |  | 17,122 |  |  | 0.46 |  |
| Amortization of intangibles | 70 |  |  | 0.00 |  |  | 101 |  |  | 0.00 |  |  | 224 |  |  | 0.01 |  |  | 328 |  |  | 0.01 |  |
| Severance payment and others | — |  |  | — |  |  | (250) |  |  | 0.00 |  |  | — |  |  | — |  |  | 105 |  |  | 0.00 |  |
| Total related to selling, general and administrative expenses | 5,150 |  |  | 0.14 |  |  | 4,391 |  |  | 0.12 |  |  | 16,227 |  |  | 0.44 |  |  | 17,555 |  |  | 0.47 |  |
| Related to other income and expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other related costs | 5,872 |  |  | 0.16 |  |  | — |  |  | — |  |  | 5,872 |  |  | 0.16 |  |  | 135 |  |  | 0.01 |  |
| Amortization of deferred debt issuance costs | 8 |  |  | 0.00 |  |  | 8 |  |  | 0.00 |  |  | 24 |  |  | 0.00 |  |  | 24 |  |  | 0.00 |  |
| Total related to other income and expense | 5,880 |  |  | 0.16 |  |  | 8 |  |  | 0.00 |  |  | 5,896 |  |  | 0.16 |  |  | 159 |  |  | 0.01 |  |
| Total related to net income & EPS | 12,483 |  |  | 0.34 |  |  | 5,582 |  |  | 0.15 |  |  | 27,151 |  |  | 0.74 |  |  | 22,385 |  |  | 0.60 |  |
| Non-GAAP measures | $ | 71,838 |  |  | $ | 1.94 |  |  | $ | 56,243 |  |  | $ | 1.50 |  |  | $ | 214,278 |  |  | $ | 5.81 |  |  | $ | 166,576 |  |  | $ | 4.45 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  | 36,989 |  |  |  |  | 37,473 |  |  |  |  | 36,895 |  |  |  |  | 37,451 |  |
| Non-GAAP diluted shares |  |  | 36,989 |  |  |  |  | 37,473 |  |  |  |  | 36,895 |  |  |  |  | 37,451 |  |

[0001408710-23-000016:8k_2_02:50]
FABRINET

[0001408710-23-000016:8k_2_02:51]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001408710-23-000016:8k_2_02:52]
| (in thousands) |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 31,2023 |  | March 25,2022 |  | March 31,2023 |  | March 25,2022 |
| Net cash provided by operating activities |  | $ | 37,122 |  |  | $ | 50,329 |  |  | $ | 142,222 |  |  | $ | 107,897 |  |
| Less: Purchase of property, plant and equipment |  | (19,779) |  |  | (23,410) |  |  | (43,422) |  |  | (75,327) |  |
| Non-GAAP free cash flow |  | $ | 17,343 |  |  | $ | 26,919 |  |  | $ | 98,800 |  |  | $ | 32,570 |  |

[0001408710-23-000016:8k_2_02:53]
FABRINET

[0001408710-23-000016:8k_2_02:54]
GUIDANCE FOR QUARTER ENDING JUNE 30, 2023

[0001408710-23-000016:8k_2_02:55]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-23-000016:8k_2_02:56]
|  | DilutedEPS |
| GAAP net income per diluted share: | $1.57 to $1.64 |
| Related to cost of revenues: |  |
| Share-based compensation expenses | 0.05 |
| Total related to gross profit | 0.05 |
| Related to selling, general and administrative expenses: |  |
| Share-based compensation expenses | 0.14 |
| Total related to selling, general and administrative expenses | 0.14 |
| Total related to net income & EPS | 0.19 |
| Non-GAAP net income per diluted share | $1.76 to $1.83 |

## item 5.02 — body, verbatim

[0001408710-23-000016:8k_body:1]
Item 5.02    Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001408710-23-000016:8k_body:2]
Amended and Restated Offer Letter

[0001408710-23-000016:8k_body:3]
On May 3, 2023, Fabrinet USA, Inc. (the “Company”) and Dr. Harpal Gill, Fabrinet’s President and Chief Operating Officer (“COO”), entered into an amended and restated offer letter of employment (the “Amended Gill Offer Letter”). The Amended Gill Offer Letter confirms Dr. Gill’s current annual base salary of $1,040,300 and his annual cash bonus opportunity of at least 95% of base salary, which will be earned based on evaluation, by the Compensation Committee of Fabrinet’s Board of Directors, of performance objectives established for the applicable year. Dr. Gill also will continue to remain eligible to receive Fabrinet equity awards to the same extent as similarly situated executives of Fabrinet and a car allowance of $1,000 per month.

[0001408710-23-000016:8k_body:4]
Effective January 1, 2025, through December 31, 2025 (the “retirement date,” and such period, the “transition period”), and unless his employment terminates earlier pursuant to the terms of the Amended Gill Offer Letter, Dr. Gill will transition from COO to a revised role with an Executive Vice President title (“EVP”). As EVP, Dr. Gill will assist in the succession efforts of and provide transition services with respect to the COO position and work on such projects as may be reasonably assigned by Fabrinet’s Chief Executive Officer.

[0001408710-23-000016:8k_body:5]
Dr. Gill will continue as a full-time employee, including during any period he is EVP. Dr. Gill and the Company are each free to terminate Dr. Gill’s employment with the Company at any time, effective one year after providing written notice, or if such notice occurs within one year of the retirement date, such lesser period ending on the retirement date (in either case, the “notice period”), provided that Dr. Gill’s employment can be terminated at any time for cause without advance written notice. During any notice period or while Dr. Gill is EVP, the Company in its discretion may reduce Dr. Gill’s authority, duties and responsibilities or his full‑time status, provided that his compensation will continue to include base salary at the level in effect immediately before the transition or notice period (as applicable), continued eligibility to participate in Fabrinet’s Executive Incentive Plan, and eligibility to receive Fabrinet equity awards to the same extent as similarly situated executives of Fabrinet, except that with respect to any Fabrinet time-based restricted share unit award to be granted to Dr. Gill, the aggregate grant date value of the award will be one-third the value of such award he otherwise would receive on a basis consistent with similarly situated Fabrinet executives.

[0001408710-23-000016:8k_body:6]
Upon a termination of Dr. Gill’s employment (x) prior to the retirement date either by the Company without good cause (and other than due to Dr. Gill’s death or disability) or by Dr. Gill for any reason, or (y) on the retirement date due to completion of the transition period, and provided that Dr. Gill provides the applicable transition services during the transition or notice period (as applicable), Dr. Gill will receive (1) a lump sum payment equal to the sum of (a) his one month’s base salary multiplied by the total number of full and fractional years of his employment with the Company; (b) any earned but unpaid bonus; and (c) two times his cost of COBRA coverage for twelve months; (2) any then-outstanding and unvested Fabrinet performance-based equity awards that remain subject to the achievement of any performance goals as of the date of termination of employment (the “Performance Awards”) will remain outstanding and eligible to vest based on the extent that the applicable performance-based or other criteria are satisfied; (3) any then-outstanding and unvested restricted share unit awards that are not Performance Awards (the “RSU Awards”) will accelerate vesting as to 100% of the shares subject thereto; and (4) continued tax equalization benefits under the Company’s expatriate policy, as in effect on the date of termination, for the calendar year in which the termination date occurs, and the following calendar year. In the event Dr. Gill’s employment is terminated on account of his death or disability, Dr. Gill will receive the severance benefits described in the aforementioned clauses (1) through (3).

[0001408710-23-000016:8k_body:7]
Dr. Gill’s severance benefits are conditioned upon the parties’ entry into a separation agreement and release of claims in favor of the Company.

[0001408710-23-000016:8k_body:8]
The foregoing description of the Amended Gill Offer Letter is a summary and is qualified in its entirety by the terms of the Amended Gill Offer Letter, which is incorporated herein by reference and attached to this Current Report on Form 8-K as Exhibit 10.1.
