# FN MD&A — 0001408710-23-000018


## mdna

[0001408710-23-000018:mdna:1]
[same as prior period, unchanged from 0001408710-23-000008:mdna:1]

[0001408710-23-000018:mdna:2]
[same as prior period, unchanged from 0001408710-23-000008:mdna:2]

[0001408710-23-000018:mdna:3]
[same as prior period, unchanged from 0001408710-23-000008:mdna:3]

[0001408710-23-000018:mdna:4]
[same as prior period, unchanged from 0001408710-23-000008:mdna:4]

[0001408710-23-000018:mdna:5]
•our expectation that the portion of our revenues attributable to customers in regions outside of North America for the remainder of fiscal year 2023 will be in line with the portion of revenues attributable to such customers during the nine months ended March 31, 2023;

[0001408710-23-000018:mdna:6]
[same as prior period, unchanged from 0001408710-23-000008:mdna:6]

[0001408710-23-000018:mdna:7]
[same as prior period, unchanged from 0001408710-23-000008:mdna:7]

[0001408710-23-000018:mdna:8]
[same as prior period, unchanged from 0001408710-23-000008:mdna:8]

[0001408710-23-000018:mdna:9]
[same as prior period, unchanged from 0001408710-23-000008:mdna:9]

[0001408710-23-000018:mdna:10]
[same as prior period, unchanged from 0001408710-23-000008:mdna:10]

[0001408710-23-000018:mdna:11]
[same as prior period, unchanged from 0001408710-23-000008:mdna:11]

[0001408710-23-000018:mdna:12]
[same as prior period, unchanged from 0001408710-23-000008:mdna:12]

[0001408710-23-000018:mdna:13]
[same as prior period, unchanged from 0001408710-23-000008:mdna:13]

[0001408710-23-000018:mdna:14]
[same as prior period, unchanged from 0001408710-23-000008:mdna:14]

[0001408710-23-000018:mdna:15]
[same as prior period, unchanged from 0001408710-23-000008:mdna:15]

[0001408710-23-000018:mdna:16]
[same as prior period, unchanged from 0001408710-23-000008:mdna:16]

[0001408710-23-000018:mdna:17]
[same as prior period, unchanged from 0001408710-23-000008:mdna:17]

[0001408710-23-000018:mdna:18]
[same as prior period, unchanged from 0001408710-23-000008:mdna:18]

[0001408710-23-000018:mdna:19]
[same as prior period, unchanged from 0001408710-23-000008:mdna:19]

[0001408710-23-000018:mdna:20]
[same as prior period, unchanged from 0001408710-23-000008:mdna:20]

[0001408710-23-000018:mdna:21]
31

[0001408710-23-000018:mdna:22]
[same as prior period, unchanged from 0001408710-23-000008:mdna:21]

[0001408710-23-000018:mdna:23]
[same as prior period, unchanged from 0001408710-23-000008:mdna:22]

[0001408710-23-000018:mdna:24]
[same as prior period, unchanged from 0001408710-23-000008:mdna:23]

[0001408710-23-000018:mdna:25]
[same as prior period, unchanged from 0001408710-23-000008:mdna:24]

[0001408710-23-000018:mdna:26]
[same as prior period, unchanged from 0001408710-23-000008:mdna:25]

[0001408710-23-000018:mdna:27]
In China, the relaxation in early December 2022 of restrictions related to COVID-19 coincided with a surge in COVID-19 infections, which peaked in the last week of December 2022 and subsided by the second half of January 2023. While the surge in China significantly disrupted our operations there, our operating results were not significantly affected due to the successful execution of our contingency plan and various precautionary measures we have undertaken. However, any worsening of the COVID-19 pandemic in China or globally may result in more stringent measures being implemented by local authorities, such as shutting down our manufacturing facilities, which would have a significant negative impact on our operations.

[0001408710-23-000018:mdna:28]
[same as prior period, unchanged from 0001408710-23-000008:mdna:27]

[0001408710-23-000018:mdna:29]
[same as prior period, unchanged from 0001408710-23-000008:mdna:28]

[0001408710-23-000018:mdna:30]
[same as prior period, unchanged from 0001408710-23-000008:mdna:29]

[0001408710-23-000018:mdna:31]
•Given our $538.7 million in cash, cash equivalents and short-term investments, and our total debt of approximately $15.2 million as of March 31, 2023, we believe we are in a solid position from a capital and financial resources perspective. We expect that current cash and cash equivalent balances and short-term investments, and cash flows generated from operations will be sufficient to meet our domestic and international working capital needs and other capital and liquidity requirements for at least the next 12 months.

[0001408710-23-000018:mdna:32]
[same as prior period, unchanged from 0001408710-23-000008:mdna:31]

[0001408710-23-000018:mdna:33]
[same as prior period, unchanged from 0001408710-23-000008:mdna:32]

[0001408710-23-000018:mdna:34]
We expect that disruptions in our supply chain and fluctuations in the availability of parts and materials will continue to have a significant impact on our ability to generate revenue, despite strong demand from our customers. These supply chain disruptions have been exacerbated by recent global events, such as (1) COVID-related lockdowns in China, which caused freight and logistics issues and unforeseen delays during the first half of fiscal year 2023, and (2) the armed conflict between Russia and Ukraine. While we have no significant direct business in Ukraine or Russia, the conflict has negatively impacted demand from some of our automotive customers that have other suppliers in the region. Moreover, if a future surge in COVID-19 cases in China were to cause the facilities of our subsidiary in Fuzhou, China to be locked down, we would be negatively impacted since we and some of our customers rely on the optics components that are manufactured in such facilities. Furthermore, in some cases, our efforts to identify and secure alternative supply chain sources has resulted in our customers or their end customers requiring requalification and validation of components, a process that can often be lengthy and has negatively impacted the timing of our revenue.

[0001408710-23-000018:mdna:35]
[same as prior period, unchanged from 0001408710-23-000008:mdna:34]

[0001408710-23-000018:mdna:36]
[same as prior period, unchanged from 0001408710-23-000008:mdna:35]

[0001408710-23-000018:mdna:37]
The percentage of our revenues generated from a bill-to location outside of North America increased from 47.5% in the three months ended March 25, 2022 to 52.5% in the three months ended March 31, 2023, primarily because the increase in sales to our customers outside of North America was higher than the increase in sales to our customers in North America.

[0001408710-23-000018:mdna:38]
The percentage of our revenues generated from a bill-to location outside of North America decreased from 52.8% in the nine months ended March 25, 2022 to 50.3% in the nine months ended March 31, 2023, primarily because the increase in sales to our customers outside of North America was lower than the increase in sales to our customers in North America.

[0001408710-23-000018:mdna:39]
Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside North America for the remainder of fiscal year 2023 will be in line with the portion of revenues attributable to such customers during the nine months ended March 31, 2023.

[0001408710-23-000018:mdna:40]
[same as prior period, unchanged from 0001408710-23-000008:mdna:39]

[0001408710-23-000018:mdna:41]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31, 2023 |  | March 25, 2022 |  | March 31, 2023 |  | March 25, 2022 |
| North America | 47.5 | % |  | 52.5 | % |  | 49.7 | % |  | 47.2 | % |
| Asia-Pacific and others | 42.1 |  |  | 34.8 |  |  | 41.1 |  |  | 37.3 |  |
| Europe | 10.4 |  |  | 12.7 |  |  | 9.2 |  |  | 15.5 |  |
|  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001408710-23-000018:mdna:42]
[same as prior period, unchanged from 0001408710-23-000008:mdna:41]

[0001408710-23-000018:mdna:43]
[same as prior period, unchanged from 0001408710-23-000008:mdna:42]

[0001408710-23-000018:mdna:44]
[same as prior period, unchanged from 0001408710-23-000008:mdna:43]

[0001408710-23-000018:mdna:45]
[same as prior period, unchanged from 0001408710-23-000008:mdna:44]

[0001408710-23-000018:mdna:46]
[same as prior period, unchanged from 0001408710-23-000008:mdna:45]

[0001408710-23-000018:mdna:47]
[same as prior period, unchanged from 0001408710-23-000008:mdna:46]

[0001408710-23-000018:mdna:48]
[same as prior period, unchanged from 0001408710-23-000008:mdna:47]

[0001408710-23-000018:mdna:49]
[same as prior period, unchanged from 0001408710-23-000008:mdna:48]

[0001408710-23-000018:mdna:50]
[same as prior period, unchanged from 0001408710-23-000008:mdna:49]

[0001408710-23-000018:mdna:51]
[same as prior period, unchanged from 0001408710-23-000008:mdna:50]

[0001408710-23-000018:mdna:52]
[same as prior period, unchanged from 0001408710-23-000008:mdna:51]

[0001408710-23-000018:mdna:53]
[same as prior period, unchanged from 0001408710-23-000008:mdna:52]

[0001408710-23-000018:mdna:54]
[same as prior period, unchanged from 0001408710-23-000008:mdna:53]

[0001408710-23-000018:mdna:55]
[same as prior period, unchanged from 0001408710-23-000008:mdna:54]

[0001408710-23-000018:mdna:56]
[same as prior period, unchanged from 0001408710-23-000008:mdna:55]

[0001408710-23-000018:mdna:57]
[same as prior period, unchanged from 0001408710-23-000008:mdna:56]

[0001408710-23-000018:mdna:58]
|  | As of March 31, 2023 |  | As of June 24, 2022 |
| (amount in thousands, except percentages) | Currency |  | $ |  | % |  | Currency |  | $ |  | % |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 964,191 |  |  | $ | 28,275 |  |  | 75.3 | % |  | 753,924 |  |  | $ | 21,213 |  |  | 64.0 | % |
| RMB | 28,079 |  |  | 4,086 |  |  | 10.9 |  |  | 34,382 |  |  | 5,132 |  |  | 15.5 |  |
| GBP | 4,168 |  |  | 5,167 |  |  | 13.8 |  |  | 5,544 |  |  | 6,801 |  |  | 20.5 |  |
| Total |  |  | $ | 37,528 |  |  | 100.0 | % |  |  |  | $ | 33,146 |  |  | 100.0 | % |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 3,142,992 |  |  | $ | 92,170 |  |  | 93.3 | % |  | 2,393,112 |  |  | $ | 67,336 |  |  | 84.8 | % |
| RMB | 38,962 |  |  | 5,670 |  |  | 5.7 |  |  | 61,191 |  |  | 9,133 |  |  | 11.5 |  |
| GBP | 794 |  |  | 984 |  |  | 1.0 |  |  | 2,379 |  |  | 2,918 |  |  | 3.7 |  |
| Total |  |  | $ | 98,824 |  |  | 100.0 | % |  |  |  | $ | 79,387 |  |  | 100.0 | % |

[0001408710-23-000018:mdna:59]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of March 31, 2023, there was $130.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 24, 2022, there was $135.0 million of foreign currency forward contracts outstanding on the Thai baht payables.

[0001408710-23-000018:mdna:60]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of March 31, 2023 and June 24, 2022, we did not have any derivative contracts denominated in RMB.

[0001408710-23-000018:mdna:61]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable and other payables. As of March 31, 2023 and June 24, 2022, we did not have any derivative contracts denominated in GBP.

[0001408710-23-000018:mdna:62]
For the three months ended March 31, 2023 and March 25, 2022, we recorded a loss of $2.1 million and gain of $0.1 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-23-000018:mdna:63]
For the nine months ended March 31, 2023 and March 25, 2022, we recorded a gain of $1.8 million and $0.6 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-23-000018:mdna:64]
[same as prior period, unchanged from 0001408710-23-000008:mdna:63]

[0001408710-23-000018:mdna:65]
[same as prior period, unchanged from 0001408710-23-000008:mdna:64]

[0001408710-23-000018:mdna:66]
[same as prior period, unchanged from 0001408710-23-000008:mdna:65]

[0001408710-23-000018:mdna:67]
[same as prior period, unchanged from 0001408710-23-000008:mdna:66]

[0001408710-23-000018:mdna:68]
[same as prior period, unchanged from 0001408710-23-000008:mdna:67]

[0001408710-23-000018:mdna:69]
[same as prior period, unchanged from 0001408710-23-000008:mdna:68]

[0001408710-23-000018:mdna:70]
[same as prior period, unchanged from 0001408710-23-000008:mdna:69]

[0001408710-23-000018:mdna:71]
[same as prior period, unchanged from 0001408710-23-000008:mdna:70]

[0001408710-23-000018:mdna:72]
[same as prior period, unchanged from 0001408710-23-000008:mdna:71]

[0001408710-23-000018:mdna:73]
[same as prior period, unchanged from 0001408710-23-000008:mdna:72]

[0001408710-23-000018:mdna:74]
[same as prior period, unchanged from 0001408710-23-000008:mdna:73]

[0001408710-23-000018:mdna:75]
[same as prior period, unchanged from 0001408710-23-000008:mdna:74]

[0001408710-23-000018:mdna:76]
[same as prior period, unchanged from 0001408710-23-000008:mdna:75]

[0001408710-23-000018:mdna:77]
[same as prior period, unchanged from 0001408710-23-000008:mdna:76]

[0001408710-23-000018:mdna:78]
[same as prior period, unchanged from 0001408710-23-000008:mdna:77]

[0001408710-23-000018:mdna:79]
As of March 31, 2023, the corporate income tax rates for our subsidiaries in the PRC, the U.S., the U.K. and Israel were 25%, 21%, 19% and 23%, respectively. In October 2022, the U.K. announced an increase in the corporate income tax rate from 19% to 25%, effective April 1, 2023.

[0001408710-23-000018:mdna:80]
[same as prior period, unchanged from 0001408710-23-000008:mdna:79]

[0001408710-23-000018:mdna:81]
[same as prior period, unchanged from 0001408710-23-000008:mdna:80]

[0001408710-23-000018:mdna:82]
[same as prior period, unchanged from 0001408710-23-000008:mdna:81]

[0001408710-23-000018:mdna:83]
[same as prior period, unchanged from 0001408710-23-000008:mdna:82]

[0001408710-23-000018:mdna:84]
[same as prior period, unchanged from 0001408710-23-000008:mdna:83]

[0001408710-23-000018:mdna:85]
| (in thousands) | Three Months Ended |  | Nine Months Ended |
| March 31,2023 |  | March 25,2022 |  | March 31,2023 |  | March 25,2022 |
| Revenues | $ | 665,281 |  |  | $ | 564,395 |  |  | $ | 1,989,366 |  |  | $ | 1,674,350 |  |
| Cost of revenues | (579,274) |  |  | (493,702) |  |  | (1,735,388) |  |  | (1,470,689) |  |
| Gross profit | 86,007 |  |  | 70,693 |  |  | 253,978 |  |  | 203,661 |  |
| Selling, general and administrative expenses | (18,309) |  |  | (17,034) |  |  | (57,804) |  |  | (55,412) |  |
| Restructuring and other related costs | (5,872) |  |  | — |  |  | (5,872) |  |  | (135) |  |
| Operating income | 61,826 |  |  | 53,659 |  |  | 190,302 |  |  | 148,114 |  |
| Interest income | 3,317 |  |  | 414 |  |  | 7,210 |  |  | 1,470 |  |
| Interest expense | (399) |  |  | (73) |  |  | (1,179) |  |  | (347) |  |
| Foreign exchange gain (loss), net | (1,303) |  |  | (410) |  |  | (3,122) |  |  | 998 |  |
| Other income (expense), net | 31 |  |  | (36) |  |  | (178) |  |  | (1,351) |  |
| Income before income taxes | 63,472 |  |  | 53,554 |  |  | 193,033 |  |  | 148,884 |  |
| Income tax expense | (4,117) |  |  | (2,893) |  |  | (5,906) |  |  | (4,693) |  |
| Net income | 59,355 |  |  | 50,661 |  |  | 187,127 |  |  | 144,191 |  |
| Other comprehensive income (loss), net of tax | (3,567) |  |  | (1,699) |  |  | 6,512 |  |  | (622) |  |
| Net comprehensive income | $ | 55,788 |  |  | $ | 48,962 |  |  | $ | 193,639 |  |  | $ | 143,569 |  |

[0001408710-23-000018:mdna:86]
[same as prior period, unchanged from 0001408710-23-000008:mdna:85]

[0001408710-23-000018:mdna:87]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 31,2023 |  | March 25,2022 |  | March 31,2023 |  | March 25,2022 |
| Revenues | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenues | (87.1) |  |  | (87.5) |  |  | (87.2) |  |  | (87.8) |  |
| Gross profit | 12.9 |  |  | 12.5 |  |  | 12.8 |  |  | 12.2 |  |
| Selling, general and administrative expenses | (2.7) |  |  | (3.0) |  |  | (2.9) |  |  | (3.4) |  |
| Restructuring and other related costs | (0.9) |  |  | — |  |  | (0.3) |  |  | 0.0 |  |
| Operating income | 9.3 |  |  | 9.5 |  |  | 9.6 |  |  | 8.8 |  |
| Interest income | 0.5 |  |  | 0.1 |  |  | 0.4 |  |  | 0.1 |  |
| Interest expense | (0.1) |  |  | 0.0 |  |  | (0.1) |  |  | 0.1 |  |
| Foreign exchange gain (loss), net | (0.2) |  |  | (0.1) |  |  | (0.2) |  |  | 0.1 |  |
| Other income (expense), net | 0.0 |  |  | 0.0 |  |  | 0.0 |  |  | (0.2) |  |
| Income before income taxes | 9.5 |  |  | 9.5 |  |  | 9.7 |  |  | 8.9 |  |
| Income tax expense | (0.6) |  |  | (0.5) |  |  | (0.3) |  |  | (0.3) |  |
| Net income | 8.9 |  |  | 9.0 |  |  | 9.4 |  |  | 8.6 |  |
| Other comprehensive income (loss), net of tax | (0.5) |  |  | (0.3) |  |  | 0.3 |  |  | 0.0 |  |
| Net comprehensive income | 8.4 | % |  | 8.7 | % |  | 9.7 | % |  | 8.6 | % |

[0001408710-23-000018:mdna:88]
[same as prior period, unchanged from 0001408710-23-000008:mdna:87]

[0001408710-23-000018:mdna:89]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands) | March 31,2023 |  | March 25,2022 |  | March 31,2023 |  | March 25,2022 |
| Optical communications | $ | 502,615 |  |  | $ | 440,003 |  |  | $ | 1,506,232 |  |  | $ | 1,318,087 |  |
| Lasers, sensors and other | 162,666 |  |  | 124,392 |  |  | 483,134 |  |  | 356,263 |  |
| Total | $ | 665,281 |  |  | $ | 564,395 |  |  | $ | 1,989,366 |  |  | $ | 1,674,350 |  |

[0001408710-23-000018:mdna:90]
[same as prior period, unchanged from 0001408710-23-000008:mdna:89]

[0001408710-23-000018:mdna:91]
Comparison of Three and Nine Months Ended March 31, 2023 with Three and Nine Months Ended March 25, 2022

[0001408710-23-000018:mdna:92]
[same as prior period, unchanged from 0001408710-23-000008:mdna:91]

[0001408710-23-000018:mdna:93]
Our revenues increased by $100.9 million, or 17.9%, to $665.3 million for the three months ended March 31, 2023, compared with $564.4 million for the three months ended March 25, 2022. This increase was due to an increase in our key customers’ demand during the three months ended March 31, 2023. Revenues from optical communications products increased by $62.6 million, or 14.2%, and revenue from non-optical communications products increased by $38.3 million, or 30.8%, for the three months ended March 31, 2023, compared to the same period in the prior fiscal year.

[0001408710-23-000018:mdna:94]
Our revenues increased by $315.0 million, or 18.8%, to $1,989.4 million for the nine months ended March 31, 2023, compared with $1,674.4 million for the nine months ended March 25, 2022. This increase was due to (1) an increase in our key customers’ demand during the nine months ended March 31, 2023, and (2) the positive impact of an additional week of revenue during the nine months ended March 31, 2023. Revenues from optical communications products increased by $188.1 million, or 14.3%, and revenue from non-optical communications products increased by $126.9 million, or 35.6%, for the nine months ended March 31, 2023, compared to the same period in the prior fiscal year.

[0001408710-23-000018:mdna:95]
[same as prior period, unchanged from 0001408710-23-000008:mdna:94]

[0001408710-23-000018:mdna:96]
Our cost of revenues increased by $85.6 million, or 17.3%, to $579.3 million, or 87.1% of revenues, for the three months ended March 31, 2023, compared with $493.7 million, or 87.5% of revenues, for the three months ended March 25, 2022. This increase in cost of revenues on an absolute dollar basis was in line with the increase in sales volume.

[0001408710-23-000018:mdna:97]
Our cost of revenues increased by $264.7 million, or 18.0%, to $1,735.4 million, or 87.2% of revenues, for the nine months ended March 31, 2023, compared with $1,470.7 million, or 87.8% of revenues, for the nine months ended March 25, 2022. This increase in cost of revenues on an absolute dollar basis was in line with the increase in sales volume.

[0001408710-23-000018:mdna:98]
[same as prior period, unchanged from 0001408710-23-000008:mdna:97]

[0001408710-23-000018:mdna:99]
Our gross profit increased by $15.3 million, or 21.6%, to $86.0 million, or 12.9% of revenues, for the three months ended March 31, 2023, compared with $70.7 million, or 12.5% of revenues, for the three months ended March 25, 2022. The increase was primarily due to an increase in sales volume.

[0001408710-23-000018:mdna:100]
Our gross profit increased by $50.3 million, or 24.7%, to $254.0 million, or 12.8% of revenues, for the nine months ended March 31, 2023, compared with $203.7 million, or 12.2% of revenues, for the nine months ended March 25, 2022. The increase was primarily due to an increase in sales volume.

[0001408710-23-000018:mdna:101]
[same as prior period, unchanged from 0001408710-23-000008:mdna:100]

[0001408710-23-000018:mdna:102]
Our SG&A expenses increased by $1.3 million, or 7.6%, to $18.3 million, or 2.7% of revenues, for the three months ended March 31, 2023, compared with $17.0 million, or 3.0% of revenues, for the three months ended March 25, 2022. The increase was primarily due to (1) an increase in share-based compensation expenses of $0.5 million, (2) an increase in legal and consulting fees of $0.3 million, (3) an increase in sales and marketing expenses of $0.3 million, and (4) an increase in executive benefits of $0.1 million.

[0001408710-23-000018:mdna:103]
Our SG&A expenses increased by $2.4 million, or 4.3%, to $57.8 million, or 2.9% of revenues, for the nine months ended March 31, 2023, compared with $55.4 million, or 3.3% of revenues, for the nine months ended March 25, 2022. The increase was primarily due to (1) an increase in legal and consulting fees of $0.9 million, (2) an increase in sales and marketing expenses of $0.9 million, (3) an increase in executive benefits of $0.8 million, (4) an increase in R&D expenses of $0.6 million, and (5) an increase in insurance expenses of $0.3 million, offset by a decrease in share-based compensation expenses of $1.1 million.

[0001408710-23-000018:mdna:104]
Restructuring and other related costs

[0001408710-23-000018:mdna:105]
We recorded restructuring and other related costs for the three and nine months ended March 31, 2023 of $5.9 million.

[0001408710-23-000018:mdna:106]
[same as prior period, unchanged from 0001408710-23-000008:mdna:103]

[0001408710-23-000018:mdna:107]
Our operating income increased by $8.1 million, or 15.1%, to $61.8 million, or 9.3% of revenues, for the three months ended March 31, 2023, compared with $53.7 million, or 9.5% of revenues, for the three months ended March 25, 2022. The increase was primarily due to an increase in revenues.

[0001408710-23-000018:mdna:108]
Our operating income increased by $42.2 million, or 28.5%, to $190.3 million, or 9.6% of revenues, for the nine months ended March 31, 2023, compared with $148.1 million, or 8.8% of revenues, for the nine months ended March 25, 2022. The increase was primarily due to an increase in revenues.

[0001408710-23-000018:mdna:109]
[same as prior period, unchanged from 0001408710-23-000008:mdna:106]

[0001408710-23-000018:mdna:110]
Our interest income increased by $2.9 million, or 725.0%, to $3.3 million, or 0.5% of revenues, for the three months ended March 31, 2023, compared with $0.4 million, or 0.1% of revenues, for the three months ended March 25, 2022. The increase was primarily due to a higher weighted average interest rate during the three months ended March 31, 2023 compared to same period in the prior fiscal year.

[0001408710-23-000018:mdna:111]
Our interest income increased by $5.7 million, or 380.0%, to $7.2 million, or 0.4% of revenues, for the nine months ended March 31, 2023, compared with $1.5 million, or 0.1% of revenues, for the nine months ended March 25, 2022. The increase was primarily due to a higher weighted average interest rate during the nine months ended March 31, 2023 compared to same period in the prior fiscal year.

[0001408710-23-000018:mdna:112]
[same as prior period, unchanged from 0001408710-23-000008:mdna:109]

[0001408710-23-000018:mdna:113]
Our interest expense increased by $0.3 million to $0.4 million for the three months ended March 31, 2023, compared with $0.1 million for the three months ended March 25, 2022. The increase was primarily due to (1) lower interest expense capitalized of $0.3 million following the completion of a new manufacturing building at our Chonburi campus in July 2022, and (2) lower amortization of the fair value of interest rate swaps of $0.1 million during the three months ended March 31, 2023, offset by lower interest expense due to a decrease in the amount of outstanding long-term loans.

[0001408710-23-000018:mdna:114]
Our interest expense increased by $0.9 million to $1.2 million for the nine months ended March 31, 2023, compared with $0.3 million for the nine months ended March 25, 2022. The increase was primarily due to (1) lower interest expense capitalized of $0.6 million following the completion of a new manufacturing building at our Chonburi campus in July 2022, and (2) lower amortization of the fair value of interest rate swaps of $0.3 million during the nine months ended March 31, 2023.

[0001408710-23-000018:mdna:115]
[same as prior period, unchanged from 0001408710-23-000008:mdna:112]

[0001408710-23-000018:mdna:116]
We recorded foreign exchange loss, net of $1.3 million for the three months ended March 31, 2023, compared with foreign exchange loss, net of $0.4 million for the three months ended March 25, 2022. The increase in foreign exchange loss was mainly due to (1) unrealized loss from mark-to-market forward contracts of $2.2 million for the three months ended March 31, 2023, and (2) higher realized loss from payment/receipt of $1.1 million for the three months ended March 31, 2023, offset by (1) unrealized gain from revaluation of outstanding Thai baht assets and liabilities of $2.1 million for the three months ended March 31, 2023, and (2) higher unrealized gain from revaluation of currencies other than Thai baht of $0.2 million for the three months ended March 31, 2023.

[0001408710-23-000018:mdna:117]
We recorded foreign exchange loss, net of $3.1 million for the nine months ended March 31, 2023, compared with foreign exchange gain, net of $1.0 million for the nine months ended March 25, 2022. The increase in foreign exchange loss was mainly due to (1) unrealized loss from revaluation of outstanding Thai baht assets and liabilities of $3.7 million for the nine months ended March 31, 2023, (2) realized loss from payment/receipt of $1.8 million for the nine months ended March 31, 2023, and (3) higher unrealized loss from revaluation of currencies other than Thai baht of $0.3 million for the nine months ended March 31, 2023, offset by (1) higher unrealized gain from mark-to-market forward contracts of $1.2 million for the nine months ended March 31, 2023, and (2) foreign exchange gain, totaling $0.6 million for the nine months ended March 31, 2023 from our subsidiaries in the PRC and the U.K.

[0001408710-23-000018:mdna:118]
[same as prior period, unchanged from 0001408710-23-000008:mdna:115]

[0001408710-23-000018:mdna:119]
We recorded income before income taxes of $63.5 million for the three months ended March 31, 2023, compared with $53.6 million for the three months ended March 25, 2022.

[0001408710-23-000018:mdna:120]
We recorded income before income taxes of $193.0 million for the nine months ended March 31, 2023, compared with $148.9 million for the nine months ended March 25, 2022.

[0001408710-23-000018:mdna:121]
[same as prior period, unchanged from 0001408710-23-000008:mdna:118]

[0001408710-23-000018:mdna:122]
Our provision for income tax reflects effective tax rates of 6.5% and 5.4% for the three months ended March 31, 2023 and March 25, 2022, respectively. The increase was primarily due to an increase in income subject to tax during the three months ended March 31, 2023 as compared to the three months ended March 25, 2022.

[0001408710-23-000018:mdna:123]
Our provision for income tax reflects effective tax rates of 3.1% and 3.2% for the nine months ended March 31, 2023 and March 25, 2022, respectively. The decrease was primarily due to lower annualized effective tax rate offset by an increase in income subject to tax during the nine months ended March 31, 2023 as compared to the nine months ended March 25, 2022.

[0001408710-23-000018:mdna:124]
[same as prior period, unchanged from 0001408710-23-000008:mdna:121]

[0001408710-23-000018:mdna:125]
We recorded net income of $59.4 million, or 8.9% of revenues, for the three months ended March 31, 2023, compared with $50.7 million, or 9.0% of revenues, for the three months ended March 25, 2022.

[0001408710-23-000018:mdna:126]
We recorded net income of $187.1 million, or 9.4% of revenues, for the nine months ended March 31, 2023, compared with $144.2 million, or 8.6% of revenues, for the nine months ended March 25, 2022.

[0001408710-23-000018:mdna:127]
[same as prior period, unchanged from 0001408710-23-000008:mdna:124]

[0001408710-23-000018:mdna:128]
We recorded other comprehensive loss of $3.6 million, or 0.5% of revenues, for the three months ended March 31, 2023, compared with other comprehensive loss of $1.7 million, or 0.3% of revenues, for the three months ended March 25, 2022. The increase in other comprehensive loss was mainly due to (1) unrealized loss from mark-to-market of forward contracts and interest rate swap agreement of $6.2 million for the three months ended March 31, 2023, and (2) higher unrealized loss from foreign currency translation adjustment of $0.2 million for the three months ended March 31, 2023, offset by unrealized gain from mark-to-market of available-for-sale debt securities of $4.5 million for the three months ended March 31, 2023.

[0001408710-23-000018:mdna:129]
We recorded other comprehensive income of $6.5 million, or 0.3% of revenues, for the nine months ended March 31, 2023, compared with other comprehensive loss of $0.6 million, or 0.0% of revenues, for the nine months ended March 25, 2022. The increase in other comprehensive income was mainly due to (1) unrealized gain from mark-to-market of available-for-sale debt securities of $5.4 million for the nine months ended March 31, 2023, and (2) higher unrealized gain from mark-to-market of forward contracts and interest rate swap agreement of $1.7 million for the nine months ended March 31, 2023.

[0001408710-23-000018:mdna:130]
[same as prior period, unchanged from 0001408710-23-000008:mdna:127]

[0001408710-23-000018:mdna:131]
[same as prior period, unchanged from 0001408710-23-000008:mdna:128]

[0001408710-23-000018:mdna:132]
We primarily finance our operations through cash flow from operations. As of March 31, 2023 and March 25, 2022, we had cash, cash equivalents, and short-term investments of $538.7 million and $515.0 million, respectively, and outstanding debt of $15.2 million and $30.5 million, respectively.

[0001408710-23-000018:mdna:133]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents was 2.7% and 2.1% for the three and nine months ended March 31, 2023, respectively, and 0.4% and 0.5% for the three and nine months ended March 25, 2022, respectively.

[0001408710-23-000018:mdna:134]
[same as prior period, unchanged from 0001408710-23-000008:mdna:131]

[0001408710-23-000018:mdna:135]
During the nine months ended March 31, 2023, we repaid $12.2 million of the term loan under our 2019 Credit Facility Agreement. As a result, as of March 31, 2023, we had a long-term borrowing of $15.2 million under our 2019 Credit Facility Agreement (see Note 10 of Notes to Unaudited Condensed Consolidated Financial Statements for further details). We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held short-term investments of $308.0 million as of March 31, 2023.

[0001408710-23-000018:mdna:136]
We believe that our current cash and cash equivalents, short-term investments, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001408710-23-000018:mdna:137]
[same as prior period, unchanged from 0001408710-23-000008:mdna:134]

[0001408710-23-000018:mdna:138]
[same as prior period, unchanged from 0001408710-23-000008:mdna:135]

[0001408710-23-000018:mdna:139]
|  | Nine Months Ended |
| (in thousands) | March 31, 2023 |  | March 25, 2022 |
| Net cash provided by operating activities | $ | 142,222 |  |  | $ | 107,897 |  |
| Net cash used in investing activities | $ | (70,449) |  |  | $ | (83,218) |  |
| Net cash used in financing activities | $ | (39,151) |  |  | $ | (58,204) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | 32,622 |  |  | $ | (33,525) |  |

[0001408710-23-000018:mdna:140]
[same as prior period, unchanged from 0001408710-23-000008:mdna:137]

[0001408710-23-000018:mdna:141]
Cash provided by operating activities is net income adjusted for certain non-cash items and changes in certain assets and liabilities. The increase in cash provided by operating activities during the nine months ended March 31, 2023 as compared to the nine months ended March 25, 2022 was primarily driven by higher net income and was also affected by cash-favorable working capital changes.

[0001408710-23-000018:mdna:142]
[same as prior period, unchanged from 0001408710-23-000008:mdna:139]

[0001408710-23-000018:mdna:143]
Investing cash flows consist primarily of investment purchases, sales, maturities, and disposals; and capital expenditures. Cash used in investing activities was lower for the nine months ended March 31, 2023 as compared to cash used in investing activities for the nine months ended March 25, 2022 primarily due to fewer capital expenditures and an increase in proceeds from sales and maturities of short-term investments, offset by higher investment purchases.

[0001408710-23-000018:mdna:144]
[same as prior period, unchanged from 0001408710-23-000008:mdna:141]

[0001408710-23-000018:mdna:145]
Financing cash flows consist primarily of repayment of long-term debt, share repurchases, and withholding tax related to net share settlement of restricted share units. Cash used in financing activities was lower for the nine months ended March 31, 2023 as compared to the nine months ended March 25, 2022 primarily due to less cash paid for share repurchases and a decrease in withholding tax related to net share settlement of restricted share units, offset by an increase in the repayment of long-term borrowings due to an additional installment from the additional week in the first quarter of fiscal year 2023.

[0001408710-23-000018:mdna:146]
[same as prior period, unchanged from 0001408710-23-000008:mdna:143]

[0001408710-23-000018:mdna:147]
[same as prior period, unchanged from 0001408710-23-000008:mdna:144]
