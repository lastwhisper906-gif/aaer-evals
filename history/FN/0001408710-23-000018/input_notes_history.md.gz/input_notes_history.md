# FN note change history — 0001408710-23-000008 → 0001408710-23-000018


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0001408710-23-000018:note_history:1]
As of March 31, 2023 and June 24, 2022, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $1.6 million and $1.4 million, respectively, or Thai baht 53.0 million and 50.2 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the operations related to the Customs department.
  (was, 2023-02-07, similarity 0.7517):
[0001408710-23-000008:note_history:1]
As of December 30, 2022 and June 24, 2022, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $1.5 million and $1.4 million, respectively, or Thai baht 53.0 million and 50.2 million, respectively.

- changed (2023-05-09):
[0001408710-23-000018:note_history:2]
As of March 31, 2023, the Company had a purchase obligation and other commitments to third parties of $1.09 billion.
  (was, 2023-02-07, similarity 0.9585):
[0001408710-23-000008:note_history:2]
As of December 30, 2022, the Company had a purchase obligation and other commitments to third parties of $1.16 billion.

- changed (2023-05-09):
[0001408710-23-000018:note_history:3]
As of March 31, 2023, the Company had total capital expenditure commitments to third parties of $18.3 million.
  (was, 2023-02-07, similarity 0.9561):
[0001408710-23-000008:note_history:3]
As of December 30, 2022, the Company had total capital expenditure commitments to third parties of $27.7 million.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0001408710-23-000018:note_history:4]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of March 31, 2023 and for the three and nine months ended March 31, 2023 and March 25, 2022 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 24, 2022.
  (was, 2023-02-07, similarity 0.9554):
[0001408710-23-000008:note_history:4]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of December 30, 2022 and for the three and six months ended December 30, 2022 and December 24, 2021 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 24, 2022.

- changed (2023-05-09):
[0001408710-23-000018:note_history:5]
The results for the three and nine months ended March 31, 2023 may not be indicative of results for the year ending June 30, 2023 or any future periods.
  (was, 2023-02-07, similarity 0.951):
[0001408710-23-000008:note_history:5]
The results for the three and six months ended December 30, 2022 may not be indicative of results for the year ending June 30, 2023 or any future periods.

- changed (2023-05-09):
[0001408710-23-000018:note_history:6]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  March 31, 2023 and March 25, 2022 consisted of 13 weeks. The nine months ended  March 31, 2023 and March 25, 2022 consisted of 40 weeks and 39 weeks, respectively. Fiscal year 2023 will comprise 53 weeks and will end on June 30, 2023.
  (was, 2023-02-07, similarity 0.8075):
[0001408710-23-000008:note_history:6]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  December 30, 2022 and December 24, 2021 consisted of 13 weeks. The six months ended  December 30, 2022 and December 24, 2021 consisted of 27 weeks and 26 weeks, respectively. Fiscal year 2023 will comprise 53 weeks and will end on June 30, 2023.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0001408710-23-000018:note_history:7]
| (in thousands of U.S. dollars) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofMarch 31, 2023 |  | As ofJune 24, 2022 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 15,234 |  |  | $ | 27,421 |  |
| Less: Current portion |  |  |  |  | (12,187) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs, non-current portion |  |  |  |  | (8) |  |  | (31) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 3,039 |  |  | $ | 15,202 |  |
  (was, 2023-02-07, similarity 0.9924):
[0001408710-23-000008:note_history:7]
| (in thousands of U.S. dollars) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofDecember 30, 2022 |  | As ofJune 24, 2022 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 18,281 |  |  | $ | 27,421 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs, non-current portion |  |  |  |  | (15) |  |  | (31) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 6,078 |  |  | $ | 15,202 |  |

- changed (2023-05-09):
[0001408710-23-000018:note_history:8]
The movements of long-term borrowings for the nine months ended March 31, 2023 and March 25, 2022 were as follows:
  (was, 2023-02-07, similarity 0.892):
[0001408710-23-000008:note_history:8]
The movements of long-term borrowings for the six months ended December 30, 2022 and December 24, 2021 were as follows:

- added (2023-05-09):
[0001408710-23-000018:note_history:9]
|  | Nine Months Ended |
| (in thousands) | March 31,2023 |  | March 25,2022 |
| Opening balance | $ | 27,421 |  |  | $ | 39,609 |  |
| Repayments during the period | (12,187) |  |  | (9,141) |  |
| Closing balance | $ | 15,234 |  |  | $ | 30,468 |  |

- changed (2023-05-09):
[0001408710-23-000018:note_history:10]
As of March 31, 2023, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2023-02-07, similarity 0.9548):
[0001408710-23-000008:note_history:10]
As of December 30, 2022, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2023-05-09):
[0001408710-23-000018:note_history:11]
| (in thousands) |  |
| 2023 (remaining three months) | $ | 3,047 |  |
| 2024 | 12,187 |  |
| Total | $ | 15,234 |  |
  (was, 2023-02-07, similarity 0.9565):
[0001408710-23-000008:note_history:11]
| (in thousands) |  |
| 2023 (remaining six months) | $ | 6,094 |  |
| 2024 | 12,187 |  |
| Total | $ | 18,281 |  |

- changed (2023-05-09):
[0001408710-23-000018:note_history:12]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a credit facility agreement (the “2019 Credit Facility Agreement”), which provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million that may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the 2019 Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.
  (was, 2023-02-07, similarity 0.9971):
[0001408710-23-000008:note_history:12]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a credit facility agreement (the “Credit Facility Agreement”), which provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million that may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

- changed (2023-05-09):
[0001408710-23-000018:note_history:13]
Under the 2019 Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a term loan agreement (the "Term Loan Agreement") pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company's previous syndicated senior credit facility agreement.
  (was, 2023-02-07, similarity 0.9977):
[0001408710-23-000008:note_history:13]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a term loan agreement (the "Term Loan Agreement") pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company's previous syndicated senior credit facility agreement.

- added (2023-05-09):
[0001408710-23-000018:note_history:14]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. On March 9, 2023, the Borrower and the Bank amended the Term Loan Agreement to replace the interest rate reference from LIBOR to the Secured Overnight Financing Rate ("SOFR") effective from September 29, 2023. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed

- changed (2023-05-09):
[0001408710-23-000018:note_history:15]
again. During the three and nine months ended March 31, 2023, the Company recorded $0.6 million and $1.7 million, respectively, of interest expense in connection with this term loan, including the impact from interest rate swaps.
  (was, 2023-02-07, similarity 0.6914):
[0001408710-23-000008:note_history:15]
in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three and six months ended December 30, 2022, the Company recorded $0.5 million and $1.1 million, respectively, of interest expense in connection with this term loan, including the impact from interest rate swaps.

- changed (2023-05-09):
[0001408710-23-000018:note_history:16]
Any borrowings under the 2019 Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.
  (was, 2023-02-07, similarity 0.996):
[0001408710-23-000008:note_history:16]
Any borrowings under the Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

- changed (2023-05-09):
[0001408710-23-000018:note_history:17]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, and restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of March 31, 2023, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.
  (was, 2023-02-07, similarity 0.9939):
[0001408710-23-000008:note_history:17]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, and restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of December 30, 2022, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

- changed (2023-05-09):
[0001408710-23-000018:note_history:18]
As of March 31, 2023, there was $15.2 million outstanding under the term loan.
  (was, 2023-02-07, similarity 0.9362):
[0001408710-23-000008:note_history:18]
As of December 30, 2022, there was $18.3 million outstanding under the term loan.

- added (2023-05-09):
[0001408710-23-000018:note_history:19]
On March 9, 2023, Fabrinet Thailand and the Parent Company (the “Borrowers”) and the Bank entered into a credit facility agreement (the “2023 Credit Facility Agreement”), which provides a facility of $55.0 million.

- added (2023-05-09):
[0001408710-23-000018:note_history:20]
Any borrowings under the 2023 Credit Facility Agreement are secured by land and buildings owned by the Borrowers in the Pathumthani and Chonburi Provinces in Thailand.

- added (2023-05-09):
[0001408710-23-000018:note_history:21]
Under the 2023 Credit Facility Agreement, the Borrowers are required to maintain a loan to value of the mortgaged real property ratio of not greater than 60%. The Borrowers are also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times.

- added (2023-05-09):
[0001408710-23-000018:note_history:22]
As of March 31, 2023, there was no amount outstanding under the 2023 Credit Facility.

- removed (2023-05-09):
[0001408710-23-000008:note_history:23]
|  | Six Months Ended |
| (in thousands) | December 30,2022 |  | December 24,2021 |
| Opening balance | $ | 27,421 |  |  | $ | 39,609 |  |
| Repayments during the period | (9,140) |  |  | (6,094) |  |
| Closing balance | $ | 18,281 |  |  | $ | 33,515 |  |

- removed (2023-05-09):
[0001408710-23-000008:note_history:24]
Bank of Ayudhya Public Company Limited

- removed (2023-05-09):
[0001408710-23-000008:note_history:25]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0001408710-23-000018:note_history:26]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of March 31, 2023 and June 24, 2022:
  (was, 2023-02-07, similarity 0.9679):
[0001408710-23-000008:note_history:26]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of December 30, 2022 and June 24, 2022:

- added (2023-05-09):
[0001408710-23-000018:note_history:27]
|  | March 31, 2023 |  | June 24, 2022 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 150,720 |  |  | $ | 150,547 |  |  | $ | 101,976 |  |  | $ | 101,400 |  |
| Due between one to five years | 161,498 |  |  | 157,433 |  |  | 184,197 |  |  | 178,757 |  |
| Total | $ | 312,218 |  |  | $ | 307,980 |  |  | $ | 286,173 |  |  | $ | 280,157 |  |

- removed (2023-05-09):
[0001408710-23-000008:note_history:28]
|  | December 30, 2022 |  | June 24, 2022 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 102,598 |  |  | $ | 102,106 |  |  | $ | 101,976 |  |  | $ | 101,400 |  |
| Due between one to five years | 180,476 |  |  | 174,672 |  |  | 184,197 |  |  | 178,757 |  |
| Total | $ | 283,074 |  |  | $ | 276,778 |  |  | $ | 286,173 |  |  | $ | 280,157 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0001408710-23-000018:note_history:29]
The movements of long-term borrowings for the nine months ended March 31, 2023 and March 25, 2022 were as follows:
  (was, 2023-02-07, similarity 0.892):
[0001408710-23-000008:note_history:29]
The movements of long-term borrowings for the six months ended December 30, 2022 and December 24, 2021 were as follows:

- added (2023-05-09):
[0001408710-23-000018:note_history:30]
|  | Nine Months Ended |
| (in thousands) | March 31,2023 |  | March 25,2022 |
| Opening balance | $ | 27,421 |  |  | $ | 39,609 |  |
| Repayments during the period | (12,187) |  |  | (9,141) |  |
| Closing balance | $ | 15,234 |  |  | $ | 30,468 |  |

- removed (2023-05-09):
[0001408710-23-000008:note_history:31]
|  | Six Months Ended |
| (in thousands) | December 30,2022 |  | December 24,2021 |
| Opening balance | $ | 27,421 |  |  | $ | 39,609 |  |
| Repayments during the period | (9,140) |  |  | (6,094) |  |
| Closing balance | $ | 18,281 |  |  | $ | 33,515 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0001408710-23-000018:note_history:32]
| (in thousands of U.S. dollars) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofMarch 31, 2023 |  | As ofJune 24, 2022 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 15,234 |  |  | $ | 27,421 |  |
| Less: Current portion |  |  |  |  | (12,187) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs, non-current portion |  |  |  |  | (8) |  |  | (31) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 3,039 |  |  | $ | 15,202 |  |
  (was, 2023-02-07, similarity 0.9924):
[0001408710-23-000008:note_history:32]
| (in thousands of U.S. dollars) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofDecember 30, 2022 |  | As ofJune 24, 2022 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 18,281 |  |  | $ | 27,421 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs, non-current portion |  |  |  |  | (15) |  |  | (31) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 6,078 |  |  | $ | 15,202 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0001408710-23-000018:note_history:33]
As of March 31, 2023, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2023-02-07, similarity 0.9548):
[0001408710-23-000008:note_history:33]
As of December 30, 2022, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2023-05-09):
[0001408710-23-000018:note_history:34]
| (in thousands) |  |
| 2023 (remaining three months) | $ | 3,047 |  |
| 2024 | 12,187 |  |
| Total | $ | 15,234 |  |
  (was, 2023-02-07, similarity 0.9565):
[0001408710-23-000008:note_history:34]
| (in thousands) |  |
| 2023 (remaining six months) | $ | 6,094 |  |
| 2024 | 12,187 |  |
| Total | $ | 18,281 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0001408710-23-000018:note_history:35]
| (in thousands, except percentages) | Three Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 310,100 |  |  |  |  | $ | 975,098 |  |  |  |
| Others (1) | 6,035 |  |  |  |  | 13,693 |  |  |  |
| Total revenue in North America | 316,135 |  |  | 47.5 | % |  | 988,791 |  |  | 49.7 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 85,731 |  |  |  |  | 247,942 |  |  |  |
| Israel | 85,562 |  |  |  |  | 182,732 |  |  |  |
| Hong Kong | 37,120 |  |  |  |  | 109,315 |  |  |  |
| Malaysia | 30,688 |  |  |  |  | 130,402 |  |  |  |
| Thailand | 16,706 |  |  |  |  | 45,420 |  |  |  |
| China | 11,194 |  |  |  |  | 60,738 |  |  |  |
| Japan | 10,044 |  |  |  |  | 32,129 |  |  |  |
| Others | 2,896 |  |  |  |  | 7,957 |  |  |  |
| Total revenue in Asia-Pacific and others | 279,941 |  |  | 42.1 | % |  | 816,635 |  |  | 41.1 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 40,292 |  |  |  |  | 103,440 |  |  |  |
| Germany | 14,532 |  |  |  |  | 40,975 |  |  |  |
| Ireland (2) | 176 |  |  |  |  | 438 |  |  |  |
| Others | 14,205 |  |  |  |  | 39,087 |  |  |  |
| Total revenue in Europe | $ | 69,205 |  |  | 10.4 | % |  | $ | 183,940 |  |  | 9.2 | % |
| Total revenue | $ | 665,281 |  |  | 100.0 | % |  | $ | 1,989,366 |  |  | 100.0 | % |
  (was, 2023-02-07, similarity 0.8655):
[0001408710-23-000008:note_history:35]
| (in thousands, except percentages) | Three Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |  | Six Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 319,918 |  |  |  |  | $ | 664,998 |  |  |  |
| Others (1) | 4,033 |  |  |  |  | 7,657 |  |  |  |
| Total revenue in North America | 323,951 |  |  | 48.5 | % |  | 672,655 |  |  | 50.8 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 82,178 |  |  |  |  | 162,211 |  |  |  |
| Israel | 59,893 |  |  |  |  | 97,170 |  |  |  |
| Malaysia | 50,390 |  |  |  |  | 99,714 |  |  |  |
| Hong Kong | 39,723 |  |  |  |  | 72,195 |  |  |  |
| China | 26,480 |  |  |  |  | 49,544 |  |  |  |
| Thailand | 16,098 |  |  |  |  | 28,714 |  |  |  |
| Japan | 11,737 |  |  |  |  | 22,085 |  |  |  |
| Others | 1,901 |  |  |  |  | 5,061 |  |  |  |
| Total revenue in Asia-Pacific and others | 288,400 |  |  | 43.1 | % |  | 536,694 |  |  | 40.5 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 30,316 |  |  |  |  | 63,148 |  |  |  |
| Germany | 13,129 |  |  |  |  | 26,443 |  |  |  |
| Ireland (2) | 143 |  |  |  |  | 262 |  |  |  |
| Others | 12,717 |  |  |  |  | 24,883 |  |  |  |
| Total revenue in Europe | $ | 56,305 |  |  | 8.4 | % |  | $ | 114,736 |  |  | 8.7 | % |
| Total revenue | $ | 668,656 |  |  | 100.0 | % |  | $ | 1,324,085 |  |  | 100.0 | % |

- changed (2023-05-09):
[0001408710-23-000018:note_history:36]
| (in thousands, except percentages) | Three Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 292,475 |  |  |  |  | $ | 781,469 |  |  |  |
| Others (1) | 4,123 |  |  |  |  | 8,996 |  |  |  |
| Total revenue in North America | 296,598 |  |  | 52.5 | % |  | 790,465 |  |  | 47.2 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 70,956 |  |  |  |  | 210,009 |  |  |  |
| Malaysia | 51,188 |  |  |  |  | 163,306 |  |  |  |
| Hong Kong | 17,338 |  |  |  |  | 61,575 |  |  |  |
| Israel | 16,883 |  |  |  |  | 67,318 |  |  |  |
| Japan | 16,449 |  |  |  |  | 47,258 |  |  |  |
| China | 12,843 |  |  |  |  | 40,624 |  |  |  |
| Others | 10,559 |  |  |  |  | 34,349 |  |  |  |
| Total revenue in Asia-Pacific and others | 196,216 |  |  | 34.8 | % |  | 624,439 |  |  | 37.3 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland (2) | 28,640 |  |  |  |  | 133,024 |  |  |  |
| U.K. | 21,632 |  |  |  |  | 64,151 |  |  |  |
| Germany | 10,688 |  |  |  |  | 28,098 |  |  |  |
| Others | 10,621 |  |  |  |  | 34,173 |  |  |  |
| Total revenue in Europe | $ | 71,581 |  |  | 12.7 | % |  | $ | 259,446 |  |  | 15.5 | % |
| Total revenue | $ | 564,395 |  |  | 100.0 | % |  | $ | 1,674,350 |  |  | 100.0 | % |
  (was, 2023-02-07, similarity 0.9852):
[0001408710-23-000008:note_history:36]
| (in thousands, except percentages) | Three Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |  | Six Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 243,720 |  |  |  |  | $ | 488,994 |  |  |  |
| Others (1) | 3,557 |  |  |  |  | 4,873 |  |  |  |
| Total revenue in North America | 247,277 |  |  | 43.6 | % |  | 493,867 |  |  | 44.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 74,121 |  |  |  |  | 139,054 |  |  |  |
| Malaysia | 60,369 |  |  |  |  | 112,118 |  |  |  |
| Hong Kong | 23,206 |  |  |  |  | 44,237 |  |  |  |
| Israel | 22,801 |  |  |  |  | 50,434 |  |  |  |
| Japan | 15,832 |  |  |  |  | 30,809 |  |  |  |
| China | 14,146 |  |  |  |  | 27,781 |  |  |  |
| Others | 11,565 |  |  |  |  | 23,790 |  |  |  |
| Total revenue in Asia-Pacific and others | 222,040 |  |  | 39.2 | % |  | 428,223 |  |  | 38.6 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland (2) | 54,900 |  |  |  |  | 104,384 |  |  |  |
| U.K. | 22,941 |  |  |  |  | 42,519 |  |  |  |
| Germany | 8,985 |  |  |  |  | 17,410 |  |  |  |
| Others | 10,490 |  |  |  |  | 23,552 |  |  |  |
| Total revenue in Europe | $ | 97,316 |  |  | 17.2 | % |  | $ | 187,865 |  |  | 16.9 | % |
| Total revenue | $ | 566,633 |  |  | 100.0 | % |  | $ | 1,109,955 |  |  | 100.0 | % |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-05-09):
[0001408710-23-000018:note_history:37]
| (in thousands, except percentages) | Three Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 310,100 |  |  |  |  | $ | 975,098 |  |  |  |
| Others (1) | 6,035 |  |  |  |  | 13,693 |  |  |  |
| Total revenue in North America | 316,135 |  |  | 47.5 | % |  | 988,791 |  |  | 49.7 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 85,731 |  |  |  |  | 247,942 |  |  |  |
| Israel | 85,562 |  |  |  |  | 182,732 |  |  |  |
| Hong Kong | 37,120 |  |  |  |  | 109,315 |  |  |  |
| Malaysia | 30,688 |  |  |  |  | 130,402 |  |  |  |
| Thailand | 16,706 |  |  |  |  | 45,420 |  |  |  |
| China | 11,194 |  |  |  |  | 60,738 |  |  |  |
| Japan | 10,044 |  |  |  |  | 32,129 |  |  |  |
| Others | 2,896 |  |  |  |  | 7,957 |  |  |  |
| Total revenue in Asia-Pacific and others | 279,941 |  |  | 42.1 | % |  | 816,635 |  |  | 41.1 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 40,292 |  |  |  |  | 103,440 |  |  |  |
| Germany | 14,532 |  |  |  |  | 40,975 |  |  |  |
| Ireland (2) | 176 |  |  |  |  | 438 |  |  |  |
| Others | 14,205 |  |  |  |  | 39,087 |  |  |  |
| Total revenue in Europe | $ | 69,205 |  |  | 10.4 | % |  | $ | 183,940 |  |  | 9.2 | % |
| Total revenue | $ | 665,281 |  |  | 100.0 | % |  | $ | 1,989,366 |  |  | 100.0 | % |
  (was, 2023-02-07, similarity 0.8655):
[0001408710-23-000008:note_history:37]
| (in thousands, except percentages) | Three Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |  | Six Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 319,918 |  |  |  |  | $ | 664,998 |  |  |  |
| Others (1) | 4,033 |  |  |  |  | 7,657 |  |  |  |
| Total revenue in North America | 323,951 |  |  | 48.5 | % |  | 672,655 |  |  | 50.8 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 82,178 |  |  |  |  | 162,211 |  |  |  |
| Israel | 59,893 |  |  |  |  | 97,170 |  |  |  |
| Malaysia | 50,390 |  |  |  |  | 99,714 |  |  |  |
| Hong Kong | 39,723 |  |  |  |  | 72,195 |  |  |  |
| China | 26,480 |  |  |  |  | 49,544 |  |  |  |
| Thailand | 16,098 |  |  |  |  | 28,714 |  |  |  |
| Japan | 11,737 |  |  |  |  | 22,085 |  |  |  |
| Others | 1,901 |  |  |  |  | 5,061 |  |  |  |
| Total revenue in Asia-Pacific and others | 288,400 |  |  | 43.1 | % |  | 536,694 |  |  | 40.5 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 30,316 |  |  |  |  | 63,148 |  |  |  |
| Germany | 13,129 |  |  |  |  | 26,443 |  |  |  |
| Ireland (2) | 143 |  |  |  |  | 262 |  |  |  |
| Others | 12,717 |  |  |  |  | 24,883 |  |  |  |
| Total revenue in Europe | $ | 56,305 |  |  | 8.4 | % |  | $ | 114,736 |  |  | 8.7 | % |
| Total revenue | $ | 668,656 |  |  | 100.0 | % |  | $ | 1,324,085 |  |  | 100.0 | % |

- changed (2023-05-09):
[0001408710-23-000018:note_history:38]
| (in thousands, except percentages) | Three Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 292,475 |  |  |  |  | $ | 781,469 |  |  |  |
| Others (1) | 4,123 |  |  |  |  | 8,996 |  |  |  |
| Total revenue in North America | 296,598 |  |  | 52.5 | % |  | 790,465 |  |  | 47.2 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 70,956 |  |  |  |  | 210,009 |  |  |  |
| Malaysia | 51,188 |  |  |  |  | 163,306 |  |  |  |
| Hong Kong | 17,338 |  |  |  |  | 61,575 |  |  |  |
| Israel | 16,883 |  |  |  |  | 67,318 |  |  |  |
| Japan | 16,449 |  |  |  |  | 47,258 |  |  |  |
| China | 12,843 |  |  |  |  | 40,624 |  |  |  |
| Others | 10,559 |  |  |  |  | 34,349 |  |  |  |
| Total revenue in Asia-Pacific and others | 196,216 |  |  | 34.8 | % |  | 624,439 |  |  | 37.3 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland (2) | 28,640 |  |  |  |  | 133,024 |  |  |  |
| U.K. | 21,632 |  |  |  |  | 64,151 |  |  |  |
| Germany | 10,688 |  |  |  |  | 28,098 |  |  |  |
| Others | 10,621 |  |  |  |  | 34,173 |  |  |  |
| Total revenue in Europe | $ | 71,581 |  |  | 12.7 | % |  | $ | 259,446 |  |  | 15.5 | % |
| Total revenue | $ | 564,395 |  |  | 100.0 | % |  | $ | 1,674,350 |  |  | 100.0 | % |
  (was, 2023-02-07, similarity 0.9852):
[0001408710-23-000008:note_history:38]
| (in thousands, except percentages) | Three Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |  | Six Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 243,720 |  |  |  |  | $ | 488,994 |  |  |  |
| Others (1) | 3,557 |  |  |  |  | 4,873 |  |  |  |
| Total revenue in North America | 247,277 |  |  | 43.6 | % |  | 493,867 |  |  | 44.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 74,121 |  |  |  |  | 139,054 |  |  |  |
| Malaysia | 60,369 |  |  |  |  | 112,118 |  |  |  |
| Hong Kong | 23,206 |  |  |  |  | 44,237 |  |  |  |
| Israel | 22,801 |  |  |  |  | 50,434 |  |  |  |
| Japan | 15,832 |  |  |  |  | 30,809 |  |  |  |
| China | 14,146 |  |  |  |  | 27,781 |  |  |  |
| Others | 11,565 |  |  |  |  | 23,790 |  |  |  |
| Total revenue in Asia-Pacific and others | 222,040 |  |  | 39.2 | % |  | 428,223 |  |  | 38.6 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland (2) | 54,900 |  |  |  |  | 104,384 |  |  |  |
| U.K. | 22,941 |  |  |  |  | 42,519 |  |  |  |
| Germany | 8,985 |  |  |  |  | 17,410 |  |  |  |
| Others | 10,490 |  |  |  |  | 23,552 |  |  |  |
| Total revenue in Europe | $ | 97,316 |  |  | 17.2 | % |  | $ | 187,865 |  |  | 16.9 | % |
| Total revenue | $ | 566,633 |  |  | 100.0 | % |  | $ | 1,109,955 |  |  | 100.0 | % |

- changed (2023-05-09):
[0001408710-23-000018:note_history:39]
| (in thousands, except percentages) | Three Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |
| Optical communications | $ | 502,615 |  |  | 75.5 | % |  | $ | 1,506,232 |  |  | 75.7 | % |
| Lasers, sensors and other | 162,666 |  |  | 24.5 | % |  | 483,134 |  |  | 24.3 | % |
| Total | $ | 665,281 |  |  | 100.0 | % |  | $ | 1,989,366 |  |  | 100.0 | % |
  (was, 2023-02-07, similarity 0.9139):
[0001408710-23-000008:note_history:39]
| (in thousands, except percentages) | Three Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |  | Six Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |
| Optical communications | $ | 506,056 |  |  | 75.7 | % |  | $ | 1,003,617 |  |  | 75.8 | % |
| Lasers, sensors and other | 162,600 |  |  | 24.3 | % |  | 320,468 |  |  | 24.2 | % |
| Total | $ | 668,656 |  |  | 100.0 | % |  | $ | 1,324,085 |  |  | 100.0 | % |

- changed (2023-05-09):
[0001408710-23-000018:note_history:40]
| (in thousands, except percentages) | Three Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |
| Optical communications | $ | 440,003 |  |  | 78.0 | % |  | $ | 1,318,087 |  |  | 78.7 | % |
| Lasers, sensors and other | 124,392 |  |  | 22.0 | % |  | 356,263 |  |  | 21.3 | % |
| Total | $ | 564,395 |  |  | 100.0 | % |  | $ | 1,674,350 |  |  | 100.0 | % |
  (was, 2023-02-07, similarity 0.9139):
[0001408710-23-000008:note_history:40]
| (in thousands, except percentages) | Three Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |  | Six Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |
| Optical communications | $ | 450,783 |  |  | 79.6 | % |  | $ | 878,084 |  |  | 79.1 | % |
| Lasers, sensors and other | 115,850 |  |  | 20.4 | % |  | 231,871 |  |  | 20.9 | % |
| Total | $ | 566,633 |  |  | 100.0 | % |  | $ | 1,109,955 |  |  | 100.0 | % |

- changed (2023-05-09):
[0001408710-23-000018:note_history:41]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the nine months ended March 31, 2023:
  (was, 2023-02-07, similarity 0.9507):
[0001408710-23-000008:note_history:41]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the six months ended December 30, 2022:

- changed (2023-05-09):
[0001408710-23-000018:note_history:42]
| (in thousands) | ContractAssets |
| Beginning balance, June 24, 2022 | $ | 13,464 |  |
| Revenue recognized | 57,617 |  |
| Amounts collected or invoiced | (50,000) |  |
| Ending balance, March 31, 2023 | $ | 21,081 |  |
  (was, 2023-02-07, similarity 0.9763):
[0001408710-23-000008:note_history:42]
| (in thousands) | ContractAssets |
| Beginning balance, June 24, 2022 | $ | 13,464 |  |
| Revenue recognized | 31,601 |  |
| Amounts collected or invoiced | (31,487) |  |
| Ending balance, December 30, 2022 | $ | 13,578 |  |

- changed (2023-05-09):
[0001408710-23-000018:note_history:43]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 24, 2022 | $ | 1,982 |  |
| Advance payment received during the period | 13,073 |  |
| Revenue recognized | (11,806) |  |
| Ending balance, March 31, 2023 | $ | 3,249 |  |
  (was, 2023-02-07, similarity 0.9735):
[0001408710-23-000008:note_history:43]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 24, 2022 | $ | 1,982 |  |
| Advance payment received during the period | 12,515 |  |
| Revenue recognized | (10,861) |  |
| Ending balance, December 30, 2022 | $ | 3,636 |  |
