# FN note change history — 0001408710-25-000023 → 0001408710-25-000056


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-11-04):
[0001408710-25-000056:note_history:1]
As of September 26, 2025 and June 27, 2025, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.4 million and $2.3 million, respectively, or Thai baht 77.3 million and 75.7 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the subsidiary's operations related to the Israeli Customs department.
  (was, 2025-05-06, similarity 0.9849):
[0001408710-25-000023:note_history:1]
As of March 28, 2025 and June 28, 2024, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.2 million and $2.0 million, respectively, or Thai baht 75.7 million and 73.2 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the subsidiary's operations related to the Israeli Customs department.

- changed (2025-11-04):
[0001408710-25-000056:note_history:2]
As of September 26, 2025, the Company had purchase obligations and other commitments to third parties of $1.54 billion.
  (was, 2025-05-06, similarity 0.9537):
[0001408710-25-000023:note_history:2]
As of March 28, 2025, the Company had purchase obligations and other commitments to third parties of $1.27 billion.

- changed (2025-11-04):
[0001408710-25-000056:note_history:3]
As of September 26, 2025, the Company had total capital expenditure commitments to third parties of $196.0 million.
  (was, 2025-05-06, similarity 0.9515):
[0001408710-25-000023:note_history:3]
As of March 28, 2025, the Company had total capital expenditure commitments to third parties of $174.3 million.

- changed (2025-11-04):
[0001408710-25-000056:note_history:4]
As of September 26, 2025, there was no amount outstanding under the 2023 Credit Facility Agreement.
  (was, 2025-05-06, similarity 0.9432):
[0001408710-25-000023:note_history:4]
As of March 28, 2025, there was no amount outstanding under the 2023 Credit Facility Agreement.

- changed (2025-11-04):
[0001408710-25-000056:note_history:5]
As of September 26, 2025, the Borrowers were in compliance with all of their financial covenants under the 2023 Credit Facility Agreement.
  (was, 2025-05-06, similarity 0.9606):
[0001408710-25-000023:note_history:5]
As of March 28, 2025, the Borrowers were in compliance with all of their financial covenants under the 2023 Credit Facility Agreement.

- changed (2025-11-04):
[0001408710-25-000056:note_history:6]
On June 28, 2024, Ngan In Leng and First Laser Limited (collectively, the “Plaintiffs”) filed a complaint in the Fuzhou Intermediate People’s Court (the “Court”) in Fuzhou, China against Fujian Enterprises (Holdings) Co., Ltd. (“FEHC”), Jian An Investment Limited (“Jian”), and Casix, Inc. (“Casix”), the Company's wholly-owned subsidiary located in the PRC. The complaint alleges unjust enrichment related to a purported investment in Casix by the Plaintiffs in 1997, which predates the Company's acquisition of Casix from JDS Uniphase Corporation. The Plaintiffs have requested that the Court
  (was, 2025-05-06, similarity 0.8415):
[0001408710-25-000023:note_history:6]
On June 28, 2024, Ngan In Leng and First Laser Limited (collectively, the “Plaintiffs”) filed a complaint in the Fuzhou Intermediate People’s Court (the “Court”) in Fuzhou, China against Fujian Enterprises (Holdings) Co., Ltd. (“FEHC”), Jian An Investment Limited (“Jian”), and Casix, Inc. (“Casix”), the Company's wholly-owned subsidiary located in the PRC. The complaint alleges unjust enrichment related to a purported investment in Casix by the Plaintiffs in 1997, which predates the Company's acquisition of Casix from JDS Uniphase Corporation. The Plaintiffs have requested that the Court order FEHC to return the unjust enrichment to the Plaintiffs in the amount of RMB 400 million, with interest from March 1, 2000, and order Jian and Casix to bear joint and several liability for all payment obligations of FEHC.

- added (2025-11-04):
[0001408710-25-000056:note_history:7]
order FEHC to return the unjust enrichment to the Plaintiffs in the amount of RMB 400 million, with interest from March 1, 2000, and order Jian and Casix to bear joint and several liability for all payment obligations of FEHC.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-11-04):
[0001408710-25-000056:note_history:8]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of September 26, 2025 and for the three months ended September 26, 2025 and September 27, 2024 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 27, 2025.
  (was, 2025-05-06, similarity 0.9534):
[0001408710-25-000023:note_history:8]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of March 28, 2025 and for the three and nine months ended March 28, 2025 and March 29, 2024 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 28, 2024.

- changed (2025-11-04):
[0001408710-25-000056:note_history:9]
The results for the three months ended September 26, 2025 may not be indicative of results for the year ending June 26, 2026 or any future periods.
  (was, 2025-05-06, similarity 0.9319):
[0001408710-25-000023:note_history:9]
The results for the three and nine months ended March 28, 2025 may not be indicative of results for the year ending June 27, 2025 or any future periods.

- added (2025-11-04):
[0001408710-25-000056:note_history:10]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended September 26, 2025 and September 27, 2024 consisted of 13 weeks. Fiscal year 2026 will comprise 52 weeks and will end on June 26, 2026.

- added (2025-11-04):
[0001408710-25-000056:note_history:11]
In July 2025, the FASB issued ASU 2025-05, “Financial Instruments – Credit Losses (Topic 326), Measurement of Credit Losses for Account Receivable and Contract Assets,” which requires the Company to consider available information that is relevant to assessing the collectibility of cash flows when developing an estimate of expected credit losses. The historical credit loss experience of financial assets with similar risk characteristics generally provides a basis for the Company's assessment of expected credit losses. However, the Company is required to consider adjustments to that information to reflect the extent to which management expects current conditions and reasonable and supportable forecasts to differ from the conditions that existed for the period over which historical information was evaluated. Those adjustments may be qualitative in nature and should reflect current conditions and forecasted changes related to relevant data (such as changes in unemployment rates, property values, commodity values, delinquency, or other factors that are associated with credit losses on the financial asset or in the group of financial assets). In addition, under current guidance, an entity would not consider collection activity after the balance sheet date when developing its estimate of expected credit losses. This ASU is effective for all entities for fiscal years beginning after December 15, 2025, and interim reporting periods within those fiscal year reporting periods, with early adoption permitted. The Company will adopt this guidance for its annual reporting period beginning June 27, 2026, and interim reporting periods within that annual reporting period, and does not expect the adoption to have a material impact on its consolidated financial statements.

- added (2025-11-04):
[0001408710-25-000056:note_history:12]
In September 2025, the FASB issued ASU 2025-06, “Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40), Targeted Improvements to the Accounting for Internal-Use Software,” which requires the Company to remove all references to software development project stages so that the guidance is neutral to different software development methods, including methods that entities may use to develop software in the future. This ASU is effective for all entities for fiscal years beginning after December 15, 2027, and interim reporting periods within those fiscal year reporting periods, with early adoption permitted. The Company will adopt this guidance for its annual reporting period beginning July 1, 2028, and interim reporting periods within that annual reporting period, and does not expect the adoption to have a material impact on its consolidated financial statements.

- removed (2025-11-04):
[0001408710-25-000023:note_history:13]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended March 28, 2025 and March 29, 2024 consisted of 13 weeks. The nine months ended March 28, 2025 and March 29, 2024 consisted of 39 weeks. Fiscal year 2025 will comprise 52 weeks and will end on June 27, 2025.

- removed (2025-11-04):
[0001408710-25-000023:note_history:14]
In November 2023, the Financial Accounting Standards Board ("FASB") issued ASU 2023-07, “Segment Reporting (Topic 280), Improvements to Reportable Segment Disclosures,” which is intended to improve reportable segment disclosure requirements, primarily through additional disclosures about significant segment expenses. This ASU is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. This ASU is effective for the Company's annual periods beginning June 29, 2024, and interim periods beginning June 28, 2025, and will be applied retrospectively to all prior periods presented in the financial statements. The Company is currently evaluating the ASU to determine its impact on the Company's disclosures.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-04):
[0001408710-25-000056:note_history:15]
The following table summarizes the cost and estimated fair value of debt securities classified as available-for-sale securities based on stated effective maturities as of September 26, 2025 and June 27, 2025:
  (was, 2025-05-06, similarity 0.9745):
[0001408710-25-000023:note_history:15]
The following table summarizes the cost and estimated fair value of debt securities classified as available-for-sale securities based on stated effective maturities as of March 28, 2025 and June 28, 2024:

- added (2025-11-04):
[0001408710-25-000056:note_history:16]
|  | September 26, 2025 |  | June 27, 2025 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 116,496 |  |  | $ | 116,499 |  |  | $ | 128,958 |  |  | $ | 129,977 |  |
| Due between one to five years | 539,368 |  |  | 547,272 |  |  | 490,143 |  |  | 497,842 |  |
| Total | $ | 655,864 |  |  | $ | 663,771 |  |  | $ | 619,101 |  |  | $ | 627,819 |  |

- removed (2025-11-04):
[0001408710-25-000023:note_history:17]
|  | March 28, 2025 |  | June 28, 2024 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 234,076 |  |  | $ | 236,659 |  |  | $ | 110,671 |  |  | $ | 110,669 |  |
| Due between one to five years | 401,226 |  |  | 407,113 |  |  | 339,136 |  |  | 337,961 |  |
| Total | $ | 635,302 |  |  | $ | 643,772 |  |  | $ | 449,807 |  |  | $ | 448,630 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-11-04):
[0001408710-25-000056:note_history:18]
| (in thousands, except percentages) | Three Months EndedSeptember 26, 2025 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 27, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 419,825 |  |  |  |  | $ | 307,820 |  |  |  |
| Others (1) | 2,192 |  |  |  |  | 1,658 |  |  |  |
| Total revenue in North America | 422,017 |  |  | 43.1 | % |  | 309,478 |  |  | 38.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 232,502 |  |  |  |  | 290,953 |  |  |  |
| India | 100,569 |  |  |  |  | 76,830 |  |  |  |
| Hong Kong | 36,523 |  |  |  |  | 18,547 |  |  |  |
| Malaysia | 22,763 |  |  |  |  | 7,498 |  |  |  |
| Thailand | 20,021 |  |  |  |  | 11,121 |  |  |  |
| Singapore | 19,720 |  |  |  |  | 10,763 |  |  |  |
| China | 18,121 |  |  |  |  | 11,872 |  |  |  |
| Japan | 10,581 |  |  |  |  | 8,579 |  |  |  |
| Others | 1,134 |  |  |  |  | 475 |  |  |  |
| Total revenue in Asia-Pacific and others | 461,934 |  |  | 47.2 | % |  | 436,638 |  |  | 54.3 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 52,928 |  |  |  |  | 32,450 |  |  |  |
| Finland | 12,525 |  |  |  |  | 294 |  |  |  |
| Germany | 11,718 |  |  |  |  | 9,344 |  |  |  |
| Others | 17,006 |  |  |  |  | 16,024 |  |  |  |
| Total revenue in Europe | $ | 94,177 |  |  | 9.7 | % |  | $ | 58,112 |  |  | 7.2 | % |
| Total revenue | $ | 978,128 |  |  | 100.0 | % |  | $ | 804,228 |  |  | 100.0 | % |
  (was, 2025-05-06, similarity 0.7824):
[0001408710-25-000023:note_history:18]
| (in thousands, except percentages) | Three Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 268,475 |  |  |  |  | $ | 761,622 |  |  |  |
| Others (1) | 3,401 |  |  |  |  | 10,192 |  |  |  |
| Total revenue in North America | 271,876 |  |  | 37.2 | % |  | 771,814 |  |  | 36.3 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 275,022 |  |  |  |  | 752,736 |  |  |  |
| India | 63,055 |  |  |  |  | 208,865 |  |  |  |
| Malaysia | 30,993 |  |  |  |  | 100,938 |  |  |  |
| Hong Kong | 15,147 |  |  |  |  | 43,085 |  |  |  |
| Thailand | 13,059 |  |  |  |  | 36,489 |  |  |  |
| China | 12,309 |  |  |  |  | 53,831 |  |  |  |
| Japan | 5,772 |  |  |  |  | 18,408 |  |  |  |
| Others | 1,655 |  |  |  |  | 4,390 |  |  |  |
| Total revenue in Asia-Pacific and others | 417,012 |  |  | 57.0 | % |  | 1,218,742 |  |  | 57.2 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 18,164 |  |  |  |  | 66,808 |  |  |  |
| Germany | 10,148 |  |  |  |  | 33,323 |  |  |  |
| Others | 14,335 |  |  |  |  | 39,019 |  |  |  |
| Total revenue in Europe | $ | 42,647 |  |  | 5.8 | % |  | $ | 139,150 |  |  | 6.5 | % |
| Total revenue | $ | 731,535 |  |  | 100.0 | % |  | $ | 2,129,706 |  |  | 100.0 | % |

- changed (2025-11-04):
[0001408710-25-000056:note_history:19]
(1)Others includes revenues from external customers based in our country of domicile, the Cayman Islands, which for each period presented is $0.
  (was, 2025-05-06, similarity 0.9789):
[0001408710-25-000023:note_history:19]
(1)Others includes revenues from external customers based in our country of domicile, the Cayman Islands, which for each year presented is $0.

- removed (2025-11-04):
[0001408710-25-000023:note_history:20]
| (in thousands, except percentages) | Three Months EndedMarch 28, 2025 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 28, 2025 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 401,769 |  |  |  |  | $ | 1,080,701 |  |  |  |
| Others (1) | 1,357 |  |  |  |  | 4,306 |  |  |  |
| Total revenue in North America | 403,126 |  |  | 46.2 | % |  | 1,085,007 |  |  | 43.2 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 226,406 |  |  |  |  | 758,030 |  |  |  |
| India | 86,027 |  |  |  |  | 238,486 |  |  |  |
| Hong Kong | 26,773 |  |  |  |  | 65,735 |  |  |  |
| Thailand | 15,995 |  |  |  |  | 41,185 |  |  |  |
| China | 14,694 |  |  |  |  | 40,216 |  |  |  |
| Singapore | 10,704 |  |  |  |  | 33,948 |  |  |  |
| Japan | 10,425 |  |  |  |  | 27,980 |  |  |  |
| Malaysia | 8,224 |  |  |  |  | 23,287 |  |  |  |
| Others | 589 |  |  |  |  | 1,790 |  |  |  |
| Total revenue in Asia-Pacific and others | 399,837 |  |  | 45.9 | % |  | 1,230,657 |  |  | 49.0 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 36,905 |  |  |  |  | 108,617 |  |  |  |
| Germany | 11,822 |  |  |  |  | 32,033 |  |  |  |
| Others | 20,109 |  |  |  |  | 53,321 |  |  |  |
| Total revenue in Europe | $ | 68,836 |  |  | 7.9 | % |  | $ | 193,971 |  |  | 7.8 | % |
| Total revenue | $ | 871,799 |  |  | 100.0 | % |  | $ | 2,509,635 |  |  | 100.0 | % |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-11-04):
[0001408710-25-000056:note_history:21]
As of September 26, 2025 and June 27, 2025, the Company's contract assets were de minimis.
  (was, 2025-05-06, similarity 0.9351):
[0001408710-25-000023:note_history:21]
As of March 28, 2025 and June 28, 2024, the Company's contract assets were de minimis.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-11-04):
[0001408710-25-000056:note_history:22]
| (in thousands, except percentages) | Three Months EndedSeptember 26, 2025 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 27, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 419,825 |  |  |  |  | $ | 307,820 |  |  |  |
| Others (1) | 2,192 |  |  |  |  | 1,658 |  |  |  |
| Total revenue in North America | 422,017 |  |  | 43.1 | % |  | 309,478 |  |  | 38.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 232,502 |  |  |  |  | 290,953 |  |  |  |
| India | 100,569 |  |  |  |  | 76,830 |  |  |  |
| Hong Kong | 36,523 |  |  |  |  | 18,547 |  |  |  |
| Malaysia | 22,763 |  |  |  |  | 7,498 |  |  |  |
| Thailand | 20,021 |  |  |  |  | 11,121 |  |  |  |
| Singapore | 19,720 |  |  |  |  | 10,763 |  |  |  |
| China | 18,121 |  |  |  |  | 11,872 |  |  |  |
| Japan | 10,581 |  |  |  |  | 8,579 |  |  |  |
| Others | 1,134 |  |  |  |  | 475 |  |  |  |
| Total revenue in Asia-Pacific and others | 461,934 |  |  | 47.2 | % |  | 436,638 |  |  | 54.3 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 52,928 |  |  |  |  | 32,450 |  |  |  |
| Finland | 12,525 |  |  |  |  | 294 |  |  |  |
| Germany | 11,718 |  |  |  |  | 9,344 |  |  |  |
| Others | 17,006 |  |  |  |  | 16,024 |  |  |  |
| Total revenue in Europe | $ | 94,177 |  |  | 9.7 | % |  | $ | 58,112 |  |  | 7.2 | % |
| Total revenue | $ | 978,128 |  |  | 100.0 | % |  | $ | 804,228 |  |  | 100.0 | % |
  (was, 2025-05-06, similarity 0.7824):
[0001408710-25-000023:note_history:22]
| (in thousands, except percentages) | Three Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 268,475 |  |  |  |  | $ | 761,622 |  |  |  |
| Others (1) | 3,401 |  |  |  |  | 10,192 |  |  |  |
| Total revenue in North America | 271,876 |  |  | 37.2 | % |  | 771,814 |  |  | 36.3 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 275,022 |  |  |  |  | 752,736 |  |  |  |
| India | 63,055 |  |  |  |  | 208,865 |  |  |  |
| Malaysia | 30,993 |  |  |  |  | 100,938 |  |  |  |
| Hong Kong | 15,147 |  |  |  |  | 43,085 |  |  |  |
| Thailand | 13,059 |  |  |  |  | 36,489 |  |  |  |
| China | 12,309 |  |  |  |  | 53,831 |  |  |  |
| Japan | 5,772 |  |  |  |  | 18,408 |  |  |  |
| Others | 1,655 |  |  |  |  | 4,390 |  |  |  |
| Total revenue in Asia-Pacific and others | 417,012 |  |  | 57.0 | % |  | 1,218,742 |  |  | 57.2 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 18,164 |  |  |  |  | 66,808 |  |  |  |
| Germany | 10,148 |  |  |  |  | 33,323 |  |  |  |
| Others | 14,335 |  |  |  |  | 39,019 |  |  |  |
| Total revenue in Europe | $ | 42,647 |  |  | 5.8 | % |  | $ | 139,150 |  |  | 6.5 | % |
| Total revenue | $ | 731,535 |  |  | 100.0 | % |  | $ | 2,129,706 |  |  | 100.0 | % |

- changed (2025-11-04):
[0001408710-25-000056:note_history:23]
(1)Others includes revenues from external customers based in our country of domicile, the Cayman Islands, which for each period presented is $0.
  (was, 2025-05-06, similarity 0.9789):
[0001408710-25-000023:note_history:23]
(1)Others includes revenues from external customers based in our country of domicile, the Cayman Islands, which for each year presented is $0.

- added (2025-11-04):
[0001408710-25-000056:note_history:24]
| (in thousands, except percentages) | Three Months EndedSeptember 26, 2025 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 27, 2024 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Telecom | $ | 335,720 |  |  |  |  | $ | 225,627 |  |  |  |
| Datacom | 273,096 |  |  |  |  | 328,881 |  |  |  |
| Datacenter interconnect (1) | 138,080 |  |  |  |  | 71,807 |  |  |  |
| Total revenue - Optical communications | $ | 746,896 |  |  | 76.4 | % |  | $ | 626,315 |  |  | 77.9 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 121,948 |  |  |  |  | $ | 102,741 |  |  |  |
| Industrial laser | 39,679 |  |  |  |  | 35,326 |  |  |  |
| High-performance computing (2) | 15,403 |  |  |  |  | — |  |  |  |
| Others | 54,202 |  |  |  |  | 39,846 |  |  |  |
| Total revenue - Non-optical communications | $ | 231,232 |  |  | 23.6 | % |  | $ | 177,913 |  |  | 22.1 | % |
| Total revenue | $ | 978,128 |  |  | 100.0 | % |  | $ | 804,228 |  |  | 100.0 | % |

- added (2025-11-04):
[0001408710-25-000056:note_history:25]
(1)Datacenter interconnect (DCI) modules are opto-electronic modules used to connect two or more geographically separated data centers.

- added (2025-11-04):
[0001408710-25-000056:note_history:26]
(2)High-performance computing (HPC) products are massively parallel computing systems built from interconnected high-performance processors, accelerators, high-speed memory, and low-latency networking to solve complex, compute-intensive problems.

- changed (2025-11-04):
[0001408710-25-000056:note_history:27]
As of September 26, 2025 and June 27, 2025, the Company's contract assets were de minimis.
  (was, 2025-05-06, similarity 0.9351):
[0001408710-25-000023:note_history:27]
As of March 28, 2025 and June 28, 2024, the Company's contract assets were de minimis.

- changed (2025-11-04):
[0001408710-25-000056:note_history:28]
The following tables summarize the activity in the Company’s contract liabilities during the three months ended September 26, 2025:
  (was, 2025-05-06, similarity 0.9312):
[0001408710-25-000023:note_history:28]
The following tables summarize the activity in the Company’s contract liabilities during the nine months ended March 28, 2025:

- changed (2025-11-04):
[0001408710-25-000056:note_history:29]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 27, 2025 | $ | 14,467 |  |
| Advance payments received during the period | 4,074 |  |
| Revenue recognized | (8,765) |  |
| Ending balance, September 26, 2025 | $ | 9,776 |  |
  (was, 2025-05-06, similarity 0.9713):
[0001408710-25-000023:note_history:29]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 28, 2024 | $ | 7,846 |  |
| Advance payments received during the period | 11,534 |  |
| Revenue recognized | (10,455) |  |
| Ending balance, March 28, 2025 | $ | 8,925 |  |

- changed (2025-11-04):
[0001408710-25-000056:note_history:30]
For the three months ended September 26, 2025, the Company recognized $0.3 million as a reduction to revenue on the unaudited condensed consolidated statements of operations.
  (was, 2025-05-06, similarity 0.9436):
[0001408710-25-000023:note_history:30]
For the three and nine months ended March 28, 2025, the Company recognized $3.9 million as a reduction to revenue on the unaudited condensed consolidated statements of operations.

- removed (2025-11-04):
[0001408710-25-000023:note_history:31]
| (in thousands, except percentages) | Three Months EndedMarch 28, 2025 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 28, 2025 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 401,769 |  |  |  |  | $ | 1,080,701 |  |  |  |
| Others (1) | 1,357 |  |  |  |  | 4,306 |  |  |  |
| Total revenue in North America | 403,126 |  |  | 46.2 | % |  | 1,085,007 |  |  | 43.2 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 226,406 |  |  |  |  | 758,030 |  |  |  |
| India | 86,027 |  |  |  |  | 238,486 |  |  |  |
| Hong Kong | 26,773 |  |  |  |  | 65,735 |  |  |  |
| Thailand | 15,995 |  |  |  |  | 41,185 |  |  |  |
| China | 14,694 |  |  |  |  | 40,216 |  |  |  |
| Singapore | 10,704 |  |  |  |  | 33,948 |  |  |  |
| Japan | 10,425 |  |  |  |  | 27,980 |  |  |  |
| Malaysia | 8,224 |  |  |  |  | 23,287 |  |  |  |
| Others | 589 |  |  |  |  | 1,790 |  |  |  |
| Total revenue in Asia-Pacific and others | 399,837 |  |  | 45.9 | % |  | 1,230,657 |  |  | 49.0 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 36,905 |  |  |  |  | 108,617 |  |  |  |
| Germany | 11,822 |  |  |  |  | 32,033 |  |  |  |
| Others | 20,109 |  |  |  |  | 53,321 |  |  |  |
| Total revenue in Europe | $ | 68,836 |  |  | 7.9 | % |  | $ | 193,971 |  |  | 7.8 | % |
| Total revenue | $ | 871,799 |  |  | 100.0 | % |  | $ | 2,509,635 |  |  | 100.0 | % |

- removed (2025-11-04):
[0001408710-25-000023:note_history:32]
| (in thousands, except percentages) | Three Months EndedMarch 28, 2025 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 28, 2025 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 251,105 |  |  |  |  | $ | 879,087 |  |  |  |
| Telecom | 406,126 |  |  |  |  | 1,051,609 |  |  |  |
| Total revenue - Optical communications | $ | 657,231 |  |  | 75.4 | % |  | $ | 1,930,696 |  |  | 76.9 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 129,468 |  |  |  |  | $ | 336,456 |  |  |  |
| Industrial laser | 40,464 |  |  |  |  | 113,332 |  |  |  |
| Others | 44,636 |  |  |  |  | 129,151 |  |  |  |
| Total revenue - Non-optical communications | $ | 214,568 |  |  | 24.6 | % |  | $ | 578,939 |  |  | 23.1 | % |
| Total revenue | $ | 871,799 |  |  | 100.0 | % |  | $ | 2,509,635 |  |  | 100.0 | % |

- removed (2025-11-04):
[0001408710-25-000023:note_history:33]
| (in thousands, except percentages) | Three Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 305,478 |  |  |  |  | $ | 835,642 |  |  |  |
| Telecom | 285,970 |  |  |  |  | 856,997 |  |  |  |
| Total revenue - Optical communications | $ | 591,448 |  |  | 80.9 | % |  | $ | 1,692,639 |  |  | 79.5 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 73,636 |  |  |  |  | $ | 241,166 |  |  |  |
| Industrial laser | 30,319 |  |  |  |  | 90,582 |  |  |  |
| Others | 36,132 |  |  |  |  | 105,319 |  |  |  |
| Total revenue - Non-optical communications | $ | 140,087 |  |  | 19.1 | % |  | $ | 437,067 |  |  | 20.5 | % |
| Total revenue | $ | 731,535 |  |  | 100.0 | % |  | $ | 2,129,706 |  |  | 100.0 | % |
