# FN 8-K — 0001408710-25-000054 filed 2025-11-03

## item codes, every 8-K on or before 2025-11-04

- 2025-11-03 0001408710-25-000054 — 2.02, 9.01
- 2025-10-17 0001408710-25-000047 — 5.02, 9.01
- 2025-10-16 0001408710-25-000044 — 5.02, 9.01
- 2025-08-18 0001408710-25-000036 — 2.02, 5.02, 9.01
- 2025-05-27 0001408710-25-000027 — 5.02
- 2025-05-05 0001408710-25-000021 — 2.02, 9.01
- 2025-03-13 0001408710-25-000010 — 1.01, 3.02, 7.01, 9.01
- 2025-02-03 0001408710-25-000006 — 2.02, 9.01
- 2024-12-20 0001408710-24-000044 — 5.02
- 2024-12-13 0001408710-24-000042 — 5.07
- 2024-11-04 0001408710-24-000038 — 2.02, 9.01
- 2024-08-19 0001408710-24-000030 — 2.02, 5.02, 9.01
- 2024-06-14 0001408710-24-000023 — 5.02
- 2024-05-06 0001408710-24-000017 — 2.02, 9.01
- 2024-02-05 0001408710-24-000007 — 2.02, 9.01
- 2023-12-13 0001408710-23-000038 — 5.07
- 2023-11-06 0001408710-23-000034 — 2.02, 9.01
- 2023-08-21 0001408710-23-000026 — 2.02, 5.02, 9.01
- 2023-05-08 0001408710-23-000016 — 2.02, 5.02, 9.01
- 2023-02-06 0001408710-23-000006 — 2.02, 9.01
- 2022-12-13 0001408710-22-000062 — 5.07
- 2022-11-07 0001408710-22-000058 — 2.02, 9.01
- 2022-08-15 0001408710-22-000041 — 2.02, 5.02, 9.01
- 2022-05-02 0001408710-22-000026 — 2.02, 9.01
- 2022-01-31 0001408710-22-000016 — 2.02, 9.01
- 2022-01-19 0001408710-22-000010 — 5.02
- 2022-01-06 0001408710-22-000006 — 5.02
- 2021-12-10 0001408710-21-000051 — 5.07
- 2021-11-01 0001408710-21-000045 — 2.02, 9.01
- 2021-08-16 0001408710-21-000031 — 2.02, 5.02, 9.01
- 2021-05-03 0001408710-21-000019 — 2.02, 9.01
- 2021-02-01 0001408710-21-000008 — 2.02, 9.01
- 2020-12-11 0001193125-20-315861 — 5.07
- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2025-11-04

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001408710-25-000054:8k_2_02:1]
EX-99.1
2
fn-20251103xex991q126.htm
EX-99.1

[0001408710-25-000054:8k_2_02:2]
Document

[0001408710-25-000054:8k_2_02:3]
Exhibit 99.1

[0001408710-25-000054:8k_2_02:4]
Fabrinet Announces First Quarter Fiscal Year 2026 Financial Results

[0001408710-25-000054:8k_2_02:5]
•Record First Quarter Revenue and Earnings Per Share Above Guidance Ranges

[0001408710-25-000054:8k_2_02:6]
BANGKOK, Thailand – November 3, 2025 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its first fiscal quarter ended September 26, 2025.

[0001408710-25-000054:8k_2_02:7]
Seamus Grady, Chairman and Chief Executive Officer of Fabrinet, said, “We had an outstanding first quarter with revenue of $978 million dollars, which was above our guidance range. This record result was driven by another strong telecom performance, an early contribution from new High-Performance Computing revenue, and a smaller than anticipated sequential decline in datacom revenue. With continued strong execution, our revenue upside flowed directly to the bottom line, resulting in record earnings per share that also exceeded our guidance. With multiple tailwinds, we are optimistic that we will see our growth further accelerate in the second quarter.”

[0001408710-25-000054:8k_2_02:8]
First Quarter Fiscal Year 2026 Financial Highlights

[0001408710-25-000054:8k_2_02:9]
GAAP Results

[0001408710-25-000054:8k_2_02:10]
•Revenue for the first quarter of fiscal year 2026 was $978.1 million, compared to $804.2 million for the first quarter of fiscal year 2025.

[0001408710-25-000054:8k_2_02:11]
•GAAP net income for the first quarter of fiscal year 2026 was $95.9 million, compared to $77.4 million for the first quarter of fiscal year 2025.

[0001408710-25-000054:8k_2_02:12]
•GAAP net income per diluted share for the first quarter of fiscal year 2026 was $2.66, compared to $2.13 for the first quarter of fiscal year 2025.

[0001408710-25-000054:8k_2_02:13]
Non-GAAP Results

[0001408710-25-000054:8k_2_02:14]
•Non-GAAP net income for the first quarter of fiscal year 2026 was $105.3 million, compared to $86.9 million for the first quarter of fiscal year 2025.

[0001408710-25-000054:8k_2_02:15]
•Non-GAAP net income per diluted share for the first quarter of fiscal year 2026 was $2.92, compared to $2.39 for the first quarter of fiscal year 2025.

[0001408710-25-000054:8k_2_02:16]
Business Outlook

[0001408710-25-000054:8k_2_02:17]
Based on information available as of November 3, 2025, Fabrinet is issuing guidance for its second fiscal quarter ending December 26, 2025, as follows:

[0001408710-25-000054:8k_2_02:18]
•Fabrinet expects second quarter revenue to be in the range of $1.05 billion to $1.10 billion.

[0001408710-25-000054:8k_2_02:19]
•GAAP net income per diluted share is expected to be in the range of $2.91 to $3.06, based on approximately 36.2 million fully diluted shares outstanding.

[0001408710-25-000054:8k_2_02:20]
•Non-GAAP net income per diluted share is expected to be in the range of $3.15 to $3.30, based on approximately 36.2 million fully diluted shares outstanding.

[0001408710-25-000054:8k_2_02:21]
Guidance for non-GAAP net income per diluted share excludes share-based compensation expenses and certain non-recurring items. A reconciliation of non-GAAP net income per diluted share to the corresponding GAAP measure is available at the end of this press release.

[0001408710-25-000054:8k_2_02:22]
Conference Call Information

[0001408710-25-000054:8k_2_02:23]
| What: |  | Fabrinet First Quarter Fiscal Year 2026 Financial Results Call |
| When: |  | November 3, 2025 |
| Time: |  | 5:00 p.m. ET |
| Live Call and Replay: |  | https://investor.fabrinet.com/events-and-presentations/events |

[0001408710-25-000054:8k_2_02:24]
A recorded version of this webcast will be available approximately two hours after the call and accessible at http://investor.fabrinet.com. The webcast will be archived on Fabrinet’s website for a period of one year.

[0001408710-25-000054:8k_2_02:25]
About Fabrinet

[0001408710-25-000054:8k_2_02:26]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China, and Israel. For more information visit: www.fabrinet.com.

[0001408710-25-000054:8k_2_02:27]
Forward-Looking Statements

[0001408710-25-000054:8k_2_02:28]
Non-GAAP Financial Measures

[0001408710-25-000054:8k_2_02:29]
In addition to reporting financial results in accordance with GAAP, we provide investors with certain non-GAAP financial measures. These non-GAAP financial measures are in addition to, and not a substitute for or superior to, measures of financial performance prepared in accordance with GAAP. We believe these non-GAAP financial measures provide investors with useful supplemental information to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, we use some of these non-GAAP financial measures to measure company performance for the purposes of determining employee incentive plan compensation.

[0001408710-25-000054:8k_2_02:30]
Non-GAAP gross profit, non-GAAP operating profit, non-GAAP net income and non-GAAP net income per diluted share exclude: share-based compensation expenses; severance payment and others; restructuring and other related costs; and legal and litigation costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations.

[0001408710-25-000054:8k_2_02:31]
Non-GAAP free cash flow is net cash provided by (used in) operating activities, minus capital expenditures (purchase of property, plant and equipment). We use free cash flow to measure our ability to generate additional cash from our business operations.

[0001408710-25-000054:8k_2_02:32]
There are a number of limitations related to the use of these non-GAAP financial measures versus their nearest GAAP equivalents. For example, other companies may calculate non-GAAP financial measures differently or may use other measures to evaluate their performance, all of which could reduce the usefulness of our non-GAAP financial measures as tools for comparison. We urge you to review the reconciliations of our non-GAAP financial measures to the most directly comparable GAAP financial measures, and not to rely on any single financial measure to evaluate our business.

[0001408710-25-000054:8k_2_02:33]
Investor Contact:

[0001408710-25-000054:8k_2_02:34]
Garo Toomajanian

[0001408710-25-000054:8k_2_02:35]
ir@fabrinet.com

[0001408710-25-000054:8k_2_02:36]
FABRINET

[0001408710-25-000054:8k_2_02:37]
CONSOLIDATED BALANCE SHEETS

[0001408710-25-000054:8k_2_02:38]
| (in thousands of U.S. dollars, except share data and par value) | September 26,2025 |  | June 27,2025 |
|  | (unaudited) |  |  |
| Assets |  |  |  |
| Current assets |  |  |  |
| Cash and cash equivalents | $ | 305,001 |  |  | $ | 306,425 |  |
| Short-term investments | 663,771 |  |  | 627,819 |  |
| Trade accounts receivable, net of allowance for expected credit losses of $1,299 and $1,344, respectively | 706,935 |  |  | 758,894 |  |
| Inventories | 722,194 |  |  | 581,015 |  |
| Prepaid expenses | 36,548 |  |  | 38,476 |  |
| Other current assets | 124,512 |  |  | 116,210 |  |
| Total current assets | 2,558,961 |  |  | 2,428,839 |  |
| Non-current assets |  |  |  |
| Property, plant and equipment, net | 419,481 |  |  | 380,640 |  |
| Intangibles, net | 2,111 |  |  | 2,156 |  |
| Operating right-of-use assets | 5,263 |  |  | 5,768 |  |
| Deferred tax assets | 13,790 |  |  | 13,406 |  |
| Other non-current assets | 9,157 |  |  | 623 |  |
| Total non-current assets | 449,802 |  |  | 402,593 |  |
| Total Assets | $ | 3,008,763 |  |  | $ | 2,831,432 |  |
| Liabilities and Shareholders’ Equity |  |  |  |
| Current liabilities |  |  |  |
| Trade accounts payable | 695,552 |  |  | 637,417 |  |
| Fixed assets payable | 50,941 |  |  | 40,781 |  |
| Operating lease liabilities, current portion | 1,860 |  |  | 1,792 |  |
| Income tax payable | 10,932 |  |  | 7,939 |  |
| Accrued payroll, bonus and related expenses | 26,298 |  |  | 24,566 |  |
| Accrued expenses | 28,952 |  |  | 30,630 |  |
| Severance liabilities, current portion | 2,019 |  |  | — |  |
| Other payables | 88,979 |  |  | 66,717 |  |
| Total current liabilities | 905,533 |  |  | 809,842 |  |
| Non-current liabilities |  |  |  |
| Deferred tax liability | 1,710 |  |  | 1,595 |  |
| Operating lease liability, non-current portion | 3,304 |  |  | 3,679 |  |
| Severance liabilities | 30,330 |  |  | 31,225 |  |
| Other non-current liabilities | 6,718 |  |  | 3,279 |  |
| Total non-current liabilities | 42,062 |  |  | 39,778 |  |
| Total Liabilities | 947,595 |  |  | 849,620 |  |
| Shareholders’ equity |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of September 26, 2025 and June 27, 2025) | — |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 39,701,363 shares and 39,602,152 shares issued as of September 26, 2025 and June 27, 2025, respectively; and 35,826,315 shares and 35,728,074 shares outstanding as of September 26, 2025 and June 27, 2025, respectively) | 397 |  |  | 396 |  |
| Additional paid-in capital | 224,540 |  |  | 237,881 |  |
| Less: Treasury shares (3,875,048 shares and 3,874,078 shares as of September 26, 2025 and June 27, 2025, respectively) | (360,324) |  |  | (360,056) |  |
| Accumulated other comprehensive income (loss) | 7,332 |  |  | 10,294 |  |
| Retained earnings | 2,189,223 |  |  | 2,093,297 |  |
| Total Shareholders’ Equity | 2,061,168 |  |  | 1,981,812 |  |
| Total Liabilities and Shareholders’ Equity | $ | 3,008,763 |  |  | $ | 2,831,432 |  |

[0001408710-25-000054:8k_2_02:39]
FABRINET

[0001408710-25-000054:8k_2_02:40]
CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME (UNAUDITED)

[0001408710-25-000054:8k_2_02:41]
|  |  |  | Three Months Ended |
| (in thousands of U.S. dollars, except per share data) |  |  |  |  | September 26,2025 |  | September 27,2024 |
| Revenues |  |  |  |  | $ | 978,128 |  |  | $ | 804,228 |  |
| Cost of revenues |  |  |  |  | (861,689) |  |  | (705,202) |  |
| Gross profit |  |  |  |  | 116,439 |  |  | 99,026 |  |
| Selling, general and administrative expenses |  |  |  |  | (22,246) |  |  | (22,031) |  |
| Restructuring and other related costs |  |  |  |  | — |  |  | (57) |  |
| Operating income |  |  |  |  | 94,193 |  |  | 76,938 |  |
| Interest income |  |  |  |  | 9,417 |  |  | 10,933 |  |
| Foreign exchange gain (loss), net |  |  |  |  | (2,060) |  |  | (7,095) |  |
| Other income (expense), net |  |  |  |  | (122) |  |  | (19) |  |
| Income before income taxes |  |  |  |  | 101,428 |  |  | 80,757 |  |
| Income tax expense |  |  |  |  | (5,502) |  |  | (3,363) |  |
| Net income |  |  |  |  | 95,926 |  |  | 77,394 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities |  |  |  |  | (811) |  |  | 6,818 |  |
| Change in net unrealized gain (loss) on derivative instruments |  |  |  |  | (2,062) |  |  | 8,533 |  |
| Change in foreign currency translation adjustment |  |  |  |  | (89) |  |  | (352) |  |
| Total other comprehensive income (loss), net of tax |  |  |  |  | (2,962) |  |  | 14,999 |  |
| Net comprehensive income |  |  |  |  | $ | 92,964 |  |  | $ | 92,393 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic |  |  |  |  | $ | 2.68 |  |  | $ | 2.14 |  |
| Diluted |  |  |  |  | $ | 2.66 |  |  | $ | 2.13 |  |
| Weighted-average number of ordinary shares outstanding (in thousands of shares) |  |  |  |  |  |  |  |
| Basic |  |  |  |  | 35,773 |  |  | 36,203 |  |
| Diluted |  |  |  |  | 36,097 |  |  | 36,408 |  |

[0001408710-25-000054:8k_2_02:42]
FABRINET

[0001408710-25-000054:8k_2_02:43]
CONSOLIDATED STATEMENTS OF CASH FLOWS (UNAUDITED)

[0001408710-25-000054:8k_2_02:44]
|  | Three Months Ended |
| (in thousands of U.S. dollars) | September 26,2025 |  | September 27,2024 |
| Cash flows from operating activities |  |  |  |
| Net income for the period | $ | 95,926 |  |  | $ | 77,394 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 14,860 |  |  | 12,752 |  |
| (Gain) loss on disposal of property, plant and equipment and intangibles | (6) |  |  | 10 |  |
| Amortization of discount (premium) of short-term investments | (1,222) |  |  | (1,087) |  |
| Inventory obsolescence impairment | 2,290 |  |  | — |  |
| (Reversal of) allowance for expected credit losses | (45) |  |  | 325 |  |
| Unrealized loss (gain) on exchange rate and fair value of foreign currency forward contracts | 461 |  |  | 6,204 |  |
| Share-based compensation | 9,071 |  |  | 8,682 |  |
| Customer warrant | 286 |  |  | — |  |
| Deferred income tax expense (benefit) | (106) |  |  | (2,721) |  |
| Other non-cash expenses | 66 |  |  | 9 |  |
| Changes in operating assets and liabilities |  |  |  |
| Trade accounts receivable | 51,821 |  |  | (69,396) |  |
| Inventories | (143,469) |  |  | 22,801 |  |
| Other current assets and non-current assets | (13,579) |  |  | 1,205 |  |
| Trade accounts payable | 59,508 |  |  | (17,412) |  |
| Income tax payable | 2,993 |  |  | 467 |  |
| Accrued expenses | (2,539) |  |  | 21,902 |  |
| Other payables | 23,284 |  |  | 18,236 |  |
| Severance liabilities | 826 |  |  | 639 |  |
| Other current liabilities and non-current liabilities | 2,142 |  |  | 3,172 |  |
| Net cash provided by operating activities | 102,568 |  |  | 83,182 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of short-term investments | (110,329) |  |  | (95,572) |  |
| Proceeds from maturities of short-term investments | 74,789 |  |  | 43,914 |  |
| Purchase of property, plant and equipment | (45,266) |  |  | (20,250) |  |
| Purchase of intangibles | (169) |  |  | (122) |  |
| Proceeds from disposal of property, plant and equipment | 15 |  |  | 36 |  |
| Net cash used in investing activities | (80,960) |  |  | (71,994) |  |
| Cash flows from financing activities |  |  |  |
| Repurchase of ordinary shares | (268) |  |  | — |  |
| Withholding tax related to net share settlement of restricted share units | (22,697) |  |  | (20,220) |  |
| Net cash used in financing activities | (22,965) |  |  | (20,220) |  |
| Net increase (decrease) in cash and cash equivalents | $ | (1,357) |  |  | $ | (9,032) |  |
| Movement in cash and cash equivalents |  |  |  |
| Cash and cash equivalents at the beginning of period | $ | 306,425 |  |  | $ | 409,973 |  |
| Increase (decrease) in cash and cash equivalents | (1,357) |  |  | (9,032) |  |
| Effect of exchange rate on cash and cash equivalents | (67) |  |  | (257) |  |
| Cash and cash equivalents at the end of period | $ | 305,001 |  |  | $ | 400,684 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment-related payables | $ | 50,941 |  |  | $ | 10,166 |  |

[0001408710-25-000054:8k_2_02:45]
FABRINET

[0001408710-25-000054:8k_2_02:46]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES (UNAUDITED)

[0001408710-25-000054:8k_2_02:47]
Reconciliation of GAAP Gross Profit and GAAP Gross Margin to Non-GAAP Gross Profit and Non-GAAP Gross Margin

[0001408710-25-000054:8k_2_02:48]
|  |  |  | Three Months Ended |
| (in thousands of U.S. dollars) |  |  |  |  | September 26,2025 |  | September 27,2024 |
| Revenues |  |  |  |  |  |  |  |  | $ | 978,128 |  |  |  |  | $ | 804,228 |  |  |  |
| Gross profit (GAAP) |  |  |  |  |  |  |  |  | $ | 116,439 |  |  | 11.9 | % |  | $ | 99,026 |  |  | 12.3 | % |
| Share-based compensation expenses |  |  |  |  |  |  |  |  | 3,519 |  |  |  |  | 2,898 |  |  |  |
| Gross profit (Non-GAAP) |  |  |  |  |  |  |  |  | $ | 119,958 |  |  | 12.3 | % |  | $ | 101,924 |  |  | 12.7 | % |

[0001408710-25-000054:8k_2_02:49]
Reconciliation of GAAP Operating Profit and GAAP Operating Margin to Non-GAAP Operating Profit and Non-GAAP Operating Margin

[0001408710-25-000054:8k_2_02:50]
|  |  |  | Three Months Ended |
| (in thousands of U.S. dollars) |  |  |  |  | September 26,2025 |  | September 27,2024 |
| Revenues |  |  |  |  |  |  |  |  | $ | 978,128 |  |  |  |  | $ | 804,228 |  |  |  |
| Operating profit (GAAP) |  |  |  |  |  |  |  |  | $ | 94,193 |  |  | 9.6 | % |  | $ | 76,938 |  |  | 9.6 | % |
| Share-based compensation expenses |  |  |  |  |  |  |  |  | 9,071 |  |  |  |  | 8,682 |  |  |  |
| Legal and litigation costs |  |  |  |  |  |  |  |  | 256 |  |  |  |  | — |  |  |  |
| Severance payment and others |  |  |  |  |  |  |  |  | 72 |  |  |  |  | 730 |  |  |  |
| Restructuring and other related costs |  |  |  |  |  |  |  |  | — |  |  |  |  | 57 |  |  |  |
| Operating profit (Non-GAAP) |  |  |  |  |  |  |  |  | $ | 103,592 |  |  | 10.6 | % |  | $ | 86,407 |  |  | 10.7 | % |

[0001408710-25-000054:8k_2_02:51]
FABRINET

[0001408710-25-000054:8k_2_02:52]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES (UNAUDITED)

[0001408710-25-000054:8k_2_02:53]
Reconciliation of GAAP Net Income and EPS to Non-GAAP Net Income and EPS

[0001408710-25-000054:8k_2_02:54]
|  |  |  | Three Months Ended |
|  |  |  |  |  | September 26,2025 |  | September 27,2024 |
| (in thousands of U.S. dollars, except per share data) |  |  |  |  |  |  |  |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |
| GAAP measures |  |  |  |  |  |  |  |  | $ | 95,926 |  |  | $ | 2.66 |  |  | $ | 77,394 |  |  | $ | 2.13 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  |  |  |  |  |  |  | 3,519 |  |  | 0.10 |  |  | 2,898 |  |  | 0.08 |  |
| Total related to cost of revenues |  |  |  |  |  |  |  |  | 3,519 |  |  | 0.10 |  |  | 2,898 |  |  | 0.08 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  |  |  |  |  |  |  | 5,552 |  |  | 0.15 |  |  | 5,784 |  |  | 0.16 |  |
| Legal and litigation costs |  |  |  |  |  |  |  |  | 256 |  |  | 0.01 |  |  | — |  |  | — |  |
| Severance payment and others |  |  |  |  |  |  |  |  | 72 |  |  | 0.00 |  |  | 730 |  |  | 0.02 |  |
| Total related to selling, general and administrative expenses |  |  |  |  |  |  |  |  | 5,880 |  |  | 0.16 |  |  | 6,514 |  |  | 0.18 |  |
| Related to other income and expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other related costs |  |  |  |  |  |  |  |  | — |  |  | — |  |  | 57 |  |  | 0.00 |  |
| Total related to other income and expense |  |  |  |  |  |  |  |  | — |  |  | — |  |  | 57 |  |  | 0.00 |  |
| Total related to net income & EPS |  |  |  |  |  |  |  |  | 9,399 |  |  | 0.26 |  |  | 9,469 |  |  | 0.26 |  |
| Non-GAAP measures |  |  |  |  |  |  |  |  | $ | 105,325 |  |  | $ | 2.92 |  |  | $ | 86,863 |  |  | $ | 2.39 |  |
| Shares used in computing diluted net income per share (in thousands of shares) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  |  |  |  |  | 36,097 |  |  |  |  | 36,408 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  |  |  |  |  | 36,097 |  |  |  |  | 36,408 |  |

[0001408710-25-000054:8k_2_02:55]
FABRINET

[0001408710-25-000054:8k_2_02:56]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW (UNAUDITED)

[0001408710-25-000054:8k_2_02:57]
| (in thousands of U.S. dollars) |  |  |  | Three Months Ended |
|  |  |  |  |  |  | September 26,2025 |  | September 27,2024 |
| Net cash provided by operating activities |  |  |  |  |  | $ | 102,568 |  |  | $ | 83,182 |  |
| Less: Purchase of property, plant and equipment |  |  |  |  |  | (45,266) |  |  | (20,250) |  |
| Non-GAAP free cash flow |  |  |  |  |  | $ | 57,302 |  |  | $ | 62,932 |  |

[0001408710-25-000054:8k_2_02:58]
FABRINET

[0001408710-25-000054:8k_2_02:59]
GUIDANCE FOR QUARTER ENDING DECEMBER 26, 2025

[0001408710-25-000054:8k_2_02:60]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-25-000054:8k_2_02:61]
|  | DilutedEPS |
| GAAP net income per diluted share | $2.91 to $3.06 |
| Related to cost of revenues: |  |
| Share-based compensation expenses | 0.08 |
| Total related to cost of revenues | 0.08 |
| Related to selling, general and administrative expenses: |  |
| Share-based compensation expenses | 0.16 |
| Total related to selling, general and administrative expenses | 0.16 |
| Total related to net income & EPS | 0.24 |
| Non-GAAP net income per diluted share | $3.15 to $3.30 |
