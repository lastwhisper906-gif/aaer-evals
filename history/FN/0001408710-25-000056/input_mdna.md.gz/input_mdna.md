# FN MD&A — 0001408710-25-000056


## mdna

[0001408710-25-000056:mdna:1]
[same as prior period, unchanged from 0001408710-25-000023:mdna:1]

[0001408710-25-000056:mdna:2]
[same as prior period, unchanged from 0001408710-25-000023:mdna:2]

[0001408710-25-000056:mdna:3]
[same as prior period, unchanged from 0001408710-25-000023:mdna:3]

[0001408710-25-000056:mdna:4]
[same as prior period, unchanged from 0001408710-25-000023:mdna:4]

[0001408710-25-000056:mdna:5]
•our expectation that the portion of our revenues attributable to customers in regions outside of North America for the remainder of fiscal year 2026 will be in line with the portion of revenues attributable to such customers during the three months ended September 26, 2025;

[0001408710-25-000056:mdna:6]
•our expectation that our fiscal year 2026 selling, general and administrative (“SG&A”) expenses will increase compared to our fiscal year 2025 SG&A expenses;

[0001408710-25-000056:mdna:7]
[same as prior period, unchanged from 0001408710-25-000023:mdna:8]

[0001408710-25-000056:mdna:8]
•our future capital expenditures, including the expansion of our manufacturing capacity;

[0001408710-25-000056:mdna:9]
[same as prior period, unchanged from 0001408710-25-000023:mdna:11]

[0001408710-25-000056:mdna:10]
[same as prior period, unchanged from 0001408710-25-000023:mdna:12]

[0001408710-25-000056:mdna:11]
[same as prior period, unchanged from 0001408710-25-000023:mdna:13]

[0001408710-25-000056:mdna:12]
[same as prior period, unchanged from 0001408710-25-000023:mdna:14]

[0001408710-25-000056:mdna:13]
[same as prior period, unchanged from 0001408710-25-000023:mdna:15]

[0001408710-25-000056:mdna:14]
[same as prior period, unchanged from 0001408710-25-000023:mdna:16]

[0001408710-25-000056:mdna:15]
[same as prior period, unchanged from 0001408710-25-000023:mdna:17]

[0001408710-25-000056:mdna:16]
[same as prior period, unchanged from 0001408710-25-000023:mdna:18]

[0001408710-25-000056:mdna:17]
[same as prior period, unchanged from 0001408710-25-000023:mdna:19]

[0001408710-25-000056:mdna:18]
[same as prior period, unchanged from 0001408710-25-000023:mdna:20]

[0001408710-25-000056:mdna:19]
[same as prior period, unchanged from 0001408710-25-000023:mdna:21]

[0001408710-25-000056:mdna:20]
[same as prior period, unchanged from 0001408710-25-000023:mdna:22]

[0001408710-25-000056:mdna:21]
[same as prior period, unchanged from 0001408710-25-000023:mdna:23]

[0001408710-25-000056:mdna:22]
[same as prior period, unchanged from 0001408710-25-000023:mdna:24]

[0001408710-25-000056:mdna:23]
[same as prior period, unchanged from 0001408710-25-000023:mdna:25]

[0001408710-25-000056:mdna:24]
[same as prior period, unchanged from 0001408710-25-000023:mdna:26]

[0001408710-25-000056:mdna:25]
[same as prior period, unchanged from 0001408710-25-000023:mdna:27]

[0001408710-25-000056:mdna:26]
[same as prior period, unchanged from 0001408710-25-000023:mdna:28]

[0001408710-25-000056:mdna:27]
The percentage of our revenues generated from a bill-to location outside of North America decreased from 61.5% in the three months ended September 27, 2024 to 56.9% in the three months ended September 26, 2025, primarily because of an increase in revenue from customers in the United States.

[0001408710-25-000056:mdna:28]
Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside North America for the remainder of fiscal year 2026 will be in line with the portion of revenues attributable to such customers during the three months ended September 26, 2025.

[0001408710-25-000056:mdna:29]
[same as prior period, unchanged from 0001408710-25-000023:mdna:32]

[0001408710-25-000056:mdna:30]
|  |  |  | Three Months Ended |
|  |  |  |  |  | September 26, 2025 |  | September 27, 2024 |
| North America |  |  |  |  | 43.1 | % |  | 38.5 | % |
| Asia-Pacific and others |  |  |  |  | 47.2 |  |  | 54.3 |  |
| Europe |  |  |  |  | 9.7 |  |  | 7.2 |  |
|  |  |  |  |  | 100.0 | % |  | 100.0 | % |

[0001408710-25-000056:mdna:31]
[same as prior period, unchanged from 0001408710-25-000023:mdna:34]

[0001408710-25-000056:mdna:32]
[same as prior period, unchanged from 0001408710-25-000023:mdna:35]

[0001408710-25-000056:mdna:33]
[same as prior period, unchanged from 0001408710-25-000023:mdna:36]

[0001408710-25-000056:mdna:34]
[same as prior period, unchanged from 0001408710-25-000023:mdna:37]

[0001408710-25-000056:mdna:35]
A second significant element of our cost of revenues is employee costs, including indirect employee costs related to design, configuration and optimization of manufacturing processes for our customers, quality testing, materials testing and other engineering services, and direct costs related to our manufacturing employees. Direct employee costs include employee salaries, insurance and benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a lesser extent, costs to recruit, train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand and the PRC, the fluctuation of the Thai baht and Chinese Renminbi ("RMB") against our functional currency, the U.S. dollar, and our ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention and asset utilization.

[0001408710-25-000056:mdna:36]
[same as prior period, unchanged from 0001408710-25-000023:mdna:39]

[0001408710-25-000056:mdna:37]
[same as prior period, unchanged from 0001408710-25-000023:mdna:41]

[0001408710-25-000056:mdna:38]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative and other support personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other general expenses not related to cost of revenues. In fiscal year 2026, we expect our SG&A expenses will increase compared with our fiscal year 2025 SG&A expenses, mainly due to an increase in information technology related expenses and employee costs.

[0001408710-25-000056:mdna:39]
The compensation committee of our board of directors approved a fiscal year 2026 executive incentive plan with quantitative objectives based solely on achieving certain revenue targets and non-GAAP operating margin targets for fiscal year 2026. Bonuses under the fiscal year 2025 executive incentive plan are payable after the end of fiscal year 2025. In fiscal year 2025, the compensation committee approved a fiscal year 2025 executive incentive plan with quantitative objectives that were based solely on achieving certain revenue targets and non-GAAP operating margin targets for fiscal year 2025.

[0001408710-25-000056:mdna:40]
[same as prior period, unchanged from 0001408710-25-000023:mdna:45]

[0001408710-25-000056:mdna:41]
[same as prior period, unchanged from 0001408710-25-000023:mdna:46]

[0001408710-25-000056:mdna:42]
[same as prior period, unchanged from 0001408710-25-000023:mdna:47]

[0001408710-25-000056:mdna:43]
[same as prior period, unchanged from 0001408710-25-000023:mdna:48]

[0001408710-25-000056:mdna:44]
[same as prior period, unchanged from 0001408710-25-000023:mdna:49]

[0001408710-25-000056:mdna:45]
|  | As of September 26, 2025 |  | As of June 27, 2025 |
| (in thousands, except percentages) | ForeignCurrency |  | $ |  | % |  | ForeignCurrency |  | $ |  | % |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 917,187 |  |  | 28,458 |  |  | 68.9 | % |  | 1,812,680 |  |  | 55,689 |  |  | 86.3 | % |
| RMB | 72,798 |  |  | 10,231 |  |  | 24.8 |  |  | 43,637 |  |  | 6,092 |  |  | 9.4 |  |
| GBP | 1,939 |  |  | 2,590 |  |  | 6.3 |  |  | 2,031 |  |  | 2,790 |  |  | 4.3 |  |
| Total |  |  | $ | 41,279 |  |  | 100.0 | % |  |  |  | $ | 64,571 |  |  | 100.0 | % |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 4,673,985 |  |  | 145,020 |  |  | 91.5 | % |  | 4,434,661 |  |  | 136,242 |  |  | 91.5 | % |
| RMB | 94,477 |  |  | 13,278 |  |  | 8.4 |  |  | 89,583 |  |  | 12,507 |  |  | 8.4 |  |
| GBP | 81 |  |  | 109 |  |  | 0.1 |  |  | 106 |  |  | 146 |  |  | 0.1 |  |
| Total |  |  | $ | 158,407 |  |  | 100.0 | % |  |  |  | $ | 148,895 |  |  | 100.0 | % |

[0001408710-25-000056:mdna:46]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable, accrued employee benefits and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of September 26, 2025, there was $196.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 27, 2025, there was $165.0 million of foreign currency forward contracts outstanding on the Thai baht payables.

[0001408710-25-000056:mdna:47]
The RMB assets represent cash and cash equivalents, trade accounts receivable, other receivables, and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable, accrued payroll, bonus and related expenses, and other payables. As of September 26, 2025 and June 27, 2025, we did not have any derivative contracts denominated in RMB.

[0001408710-25-000056:mdna:48]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable, accrued expenses, and other payables. As of September 26, 2025 and June 27, 2025, we did not have any derivative contracts denominated in GBP.

[0001408710-25-000056:mdna:49]
For the three months ended September 26, 2025 and September 27, 2024, we recorded an unrealized loss of $1.3 million and unrealized gain of $4.1 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-25-000056:mdna:50]
[same as prior period, unchanged from 0001408710-25-000023:mdna:56]

[0001408710-25-000056:mdna:51]
[same as prior period, unchanged from 0001408710-25-000023:mdna:57]

[0001408710-25-000056:mdna:52]
[same as prior period, unchanged from 0001408710-25-000023:mdna:58]

[0001408710-25-000056:mdna:53]
[same as prior period, unchanged from 0001408710-25-000023:mdna:59]

[0001408710-25-000056:mdna:54]
[same as prior period, unchanged from 0001408710-25-000023:mdna:60]

[0001408710-25-000056:mdna:55]
[same as prior period, unchanged from 0001408710-25-000023:mdna:61]

[0001408710-25-000056:mdna:56]
[same as prior period, unchanged from 0001408710-25-000023:mdna:62]

[0001408710-25-000056:mdna:57]
[same as prior period, unchanged from 0001408710-25-000023:mdna:63]

[0001408710-25-000056:mdna:58]
[same as prior period, unchanged from 0001408710-25-000023:mdna:64]

[0001408710-25-000056:mdna:59]
[same as prior period, unchanged from 0001408710-25-000023:mdna:65]

[0001408710-25-000056:mdna:60]
[same as prior period, unchanged from 0001408710-25-000023:mdna:66]

[0001408710-25-000056:mdna:61]
[same as prior period, unchanged from 0001408710-25-000023:mdna:67]

[0001408710-25-000056:mdna:62]
[same as prior period, unchanged from 0001408710-25-000023:mdna:68]

[0001408710-25-000056:mdna:63]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption on income generated from projects to manufacture certain products at our Chonburi campus is currently available to us through June 2026. Similar preferential tax treatment was available to us through June 2020 with respect to products

[0001408710-25-000056:mdna:64]
manufactured at our Pinehurst campus Building 6. Between June 2020 and June 2025, 50% of our income generated from products manufactured at our Pinehurst campus was exempted from tax. Preferential tax treatment is available to us for products manufactured at our Chonburi campus Building 9, where income generated will be tax exempt through 2031, capped at our actual investment amount. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted. Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001408710-25-000056:mdna:65]
As of September 26, 2025, the corporate income tax rates for our subsidiaries in the PRC, the U.S., the U.K. and Israel are 25%, 21%, 25% and 23%, respectively.

[0001408710-25-000056:mdna:66]
[same as prior period, unchanged from 0001408710-25-000023:mdna:71]

[0001408710-25-000056:mdna:67]
[same as prior period, unchanged from 0001408710-25-000023:mdna:72]

[0001408710-25-000056:mdna:68]
[same as prior period, unchanged from 0001408710-25-000023:mdna:73]

[0001408710-25-000056:mdna:69]
Our critical accounting policies are disclosed in our Annual Report on Form 10-K for the fiscal year ended June 27, 2025. The adoption of new accounting policies and accounting standards are disclosed in Note 2 to the unaudited condensed consolidated financial statements. There were no changes to our accounting policies.

[0001408710-25-000056:mdna:70]
[same as prior period, unchanged from 0001408710-25-000023:mdna:75]

[0001408710-25-000056:mdna:71]
[same as prior period, unchanged from 0001408710-25-000023:mdna:76]

[0001408710-25-000056:mdna:72]
| (in thousands) |  |  | Three Months Ended |
|  |  |  |  | September 26,2025 |  | September 27,2024 |
| Revenues |  |  |  |  | $ | 978,128 |  |  | $ | 804,228 |  |
| Cost of revenues |  |  |  |  | (861,689) |  |  | (705,202) |  |
| Gross profit |  |  |  |  | 116,439 |  |  | 99,026 |  |
| Selling, general and administrative expenses |  |  |  |  | (22,246) |  |  | (22,031) |  |
| Restructuring and other related costs |  |  |  |  | — |  |  | (57) |  |
| Operating income |  |  |  |  | 94,193 |  |  | 76,938 |  |
| Interest income |  |  |  |  | 9,417 |  |  | 10,933 |  |
| Foreign exchange gain (loss), net |  |  |  |  | (2,060) |  |  | (7,095) |  |
| Other income (expense), net |  |  |  |  | (122) |  |  | (19) |  |
| Income before income taxes |  |  |  |  | 101,428 |  |  | 80,757 |  |
| Income tax expense |  |  |  |  | (5,502) |  |  | (3,363) |  |
| Net income |  |  |  |  | 95,926 |  |  | 77,394 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  | (2,962) |  |  | 14,999 |  |
| Net comprehensive income |  |  |  |  | $ | 92,964 |  |  | $ | 92,393 |  |

[0001408710-25-000056:mdna:73]
[same as prior period, unchanged from 0001408710-25-000023:mdna:78]

[0001408710-25-000056:mdna:74]
|  |  |  | Three Months Ended |
|  |  |  |  |  | September 26,2025 |  | September 27,2024 |
| Revenues |  |  |  |  | 100.0 | % |  | 100.0 | % |
| Cost of revenues |  |  |  |  | (88.1) |  |  | (87.7) |  |
| Gross profit |  |  |  |  | 11.9 |  |  | 12.3 |  |
| Selling, general and administrative expenses |  |  |  |  | (2.3) |  |  | (2.7) |  |
| Restructuring and other related costs |  |  |  |  | — |  |  | (0.0) |  |
| Operating income |  |  |  |  | 9.6 |  |  | 9.6 |  |
| Interest income |  |  |  |  | 1.0 |  |  | 1.3 |  |
| Foreign exchange gain (loss), net |  |  |  |  | (0.2) |  |  | (0.9) |  |
| Other income (expense), net |  |  |  |  | (0.0) |  |  | (0.0) |  |
| Income before income taxes |  |  |  |  | 10.4 |  |  | 10.0 |  |
| Income tax expense |  |  |  |  | (0.6) |  |  | (0.4) |  |
| Net income |  |  |  |  | 9.8 |  |  | 9.6 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  | (0.3) |  |  | 1.9 |  |
| Net comprehensive income |  |  |  |  | 9.5 | % |  | 11.5 | % |

[0001408710-25-000056:mdna:75]
32

[0001408710-25-000056:mdna:76]
[same as prior period, unchanged from 0001408710-25-000023:mdna:81]

[0001408710-25-000056:mdna:77]
| (in thousands, except percentages) | Three Months EndedSeptember 26, 2025 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 27, 2024 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Telecom | $ | 335,720 |  |  |  |  | $ | 225,627 |  |  |  |
| Datacom | 273,096 |  |  |  |  | 328,881 |  |  |  |
| Datacenter interconnect (1) | 138,080 |  |  |  |  | 71,807 |  |  |  |
| Total revenue - Optical communications | $ | 746,896 |  |  | 76.4 | % |  | $ | 626,315 |  |  | 77.9 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 121,948 |  |  |  |  | $ | 102,741 |  |  |  |
| Industrial laser | 39,679 |  |  |  |  | 35,326 |  |  |  |
| High-performance computing (2) | 15,403 |  |  |  |  | — |  |  |  |
| Others | 54,202 |  |  |  |  | 39,846 |  |  |  |
| Total revenue - Non-optical communications | $ | 231,232 |  |  | 23.6 | % |  | $ | 177,913 |  |  | 22.1 | % |
| Total revenue | $ | 978,128 |  |  | 100.0 | % |  | $ | 804,228 |  |  | 100.0 | % |

[0001408710-25-000056:mdna:78]
(1)Datacenter interconnect (DCI) modules are opto-electronic modules used to connect two or more geographically separated data centers.

[0001408710-25-000056:mdna:79]
(2)High-performance computing (HPC) products are massively parallel computing systems built from interconnected high-performance processors, accelerators, high-speed memory, and low-latency networking to solve complex, compute-intensive problems.

[0001408710-25-000056:mdna:80]
Comparison of Three Months Ended September 26, 2025 with Three Months Ended September 27, 2024

[0001408710-25-000056:mdna:81]
[same as prior period, unchanged from 0001408710-25-000023:mdna:85]

[0001408710-25-000056:mdna:82]
Our revenues increased by $173.9 million, or 21.6%, to $978.1 million for the three months ended September 26, 2025, compared with $804.2 million for the three months ended September 27, 2024. This increase was primarily due to an increase in our key customers’ demand for both optical communications products and non-optical communications products. Revenues from optical communications products, which represented $746.9 million, or 76.4%, of our revenues for the three months ended September 26, 2025, increased by $120.6 million, or 19.3%, compared to the same period in the prior fiscal year, mainly due to an increase in revenues from telecommunication products and datacenter interconnect products, and partially offset with a decrease in revenues from data communication products during the three months ended September 26, 2025. Revenues from non-optical communications products, which represented $231.2 million, or 23.6%, of our revenues for the three months ended September 26, 2025, increased by $53.3 million, or 30.0%, compared to the same period in the prior fiscal year, primarily due to growth in automotive revenue and high-performance computing.

[0001408710-25-000056:mdna:83]
[same as prior period, unchanged from 0001408710-25-000023:mdna:88]

[0001408710-25-000056:mdna:84]
Our cost of revenues increased by $156.5 million, or 22.2%, to $861.7 million, or 88.1% of revenues, for the three months ended September 26, 2025, compared with $705.2 million, or 87.7% of revenues, for the three months ended September 27, 2024. This increase was in line with the increase in sales volume.

[0001408710-25-000056:mdna:85]
[same as prior period, unchanged from 0001408710-25-000023:mdna:91]

[0001408710-25-000056:mdna:86]
Our gross profit increased by $17.4 million, or 17.6%, to $116.4 million, or 11.9% of revenues, for the three months ended September 26, 2025, compared with $99.0 million, or 12.3% of revenues, for the three months ended September 27, 2024. The increase was primarily due to an increase in sales volume.

[0001408710-25-000056:mdna:87]
[same as prior period, unchanged from 0001408710-25-000023:mdna:94]

[0001408710-25-000056:mdna:88]
Our SG&A expenses increased by $0.2 million, or 0.9%, to $22.2 million, or 2.3% of revenues, for the three months ended September 26, 2025, compared with $22.0 million, or 2.7% of revenues, for the three months ended September 27, 2024. The increase was primarily due to (1) an increase in information technology related expenses of $0.6 million, mainly from network, security system and new hardware costs, and (2) an increase in executive compensation related expenses of $0.3 million, offset by a decrease in severance expenses of $0.7 million.

[0001408710-25-000056:mdna:89]
[same as prior period, unchanged from 0001408710-25-000023:mdna:99]

[0001408710-25-000056:mdna:90]
Our operating income increased by $17.3 million, or 22.5%, to $94.2 million, or 9.6% of revenues, for the three months ended September 26, 2025, compared with $76.9 million, or 9.6% of revenues, for the three months ended September 27, 2024. The increase was primarily due to an increase in revenues.

[0001408710-25-000056:mdna:91]
[same as prior period, unchanged from 0001408710-25-000023:mdna:102]

[0001408710-25-000056:mdna:92]
Our interest income decreased by $1.5 million, or 13.8%, to $9.4 million, or 1.0% of revenues, for the three months ended September 26, 2025, compared with $10.9 million, or 1.3% of revenues, for the three months ended September 27, 2024. The decrease was primarily due to a decrease of weighted average interest income rate following to global interest rate trend, offset by higher average cash balance and short-term investment during the three months ended September 26, 2025 compared to same period in the prior fiscal year.

[0001408710-25-000056:mdna:93]
[same as prior period, unchanged from 0001408710-25-000023:mdna:108]

[0001408710-25-000056:mdna:94]
We recorded foreign exchange loss, net of $2.1 million, or 0.2% of revenues, for the three months ended September 26, 2025, compared with foreign exchange loss, net of $7.1 million, or 0.9% or revenues, for the three months ended September 27, 2024. The decrease in foreign exchange loss was mainly due to (1) unrealized gain from revaluation of outstanding Thai baht assets and liabilities of $10.8 million, and (2) unrealized gain from revaluation of currencies other than Thai baht of $1.7 million, offset by (1) unrealized loss from mark-to-market forward contracts of $5.4 million, (2) higher in realized loss from payment/receipt of $1.4 million, and (3) lower foreign exchange gain, totaling $0.7 million from our subsidiaries in the PRC and the U.K.

[0001408710-25-000056:mdna:95]
[same as prior period, unchanged from 0001408710-25-000023:mdna:111]

[0001408710-25-000056:mdna:96]
We recorded income before income taxes of $101.4 million for the three months ended September 26, 2025, compared with $80.8 million for the three months ended September 27, 2024.

[0001408710-25-000056:mdna:97]
[same as prior period, unchanged from 0001408710-25-000023:mdna:114]

[0001408710-25-000056:mdna:98]
Our provision for income tax reflects effective tax rates of 5.4% and 4.2% for the three months ended September 26, 2025 and September 27, 2024, respectively. The increase was due to higher income subject to tax.

[0001408710-25-000056:mdna:99]
[same as prior period, unchanged from 0001408710-25-000023:mdna:117]

[0001408710-25-000056:mdna:100]
We recorded net income of $95.9 million, or 9.8% of revenues, for the three months ended September 26, 2025, compared with $77.4 million, or 9.6% of revenues, for the three months ended September 27, 2024.

[0001408710-25-000056:mdna:101]
[same as prior period, unchanged from 0001408710-25-000023:mdna:120]

[0001408710-25-000056:mdna:102]
We recorded other comprehensive loss of $3.0 million, or 0.3% of revenues, for the three months ended September 26, 2025, compared with other comprehensive income of $15.0 million, or 1.9% of revenues, for the three months ended September 27, 2024. The change was mainly due to (1) unrealized loss from mark-to-market of forward contracts and interest rate swap agreements of $10.6 million, and (2) unrealized loss from mark-to-market of available-for-sale debt securities of $7.6 million, offset by lower unrealized loss from foreign currency translation adjustment of $0.2 million

[0001408710-25-000056:mdna:103]
[same as prior period, unchanged from 0001408710-25-000023:mdna:124]

[0001408710-25-000056:mdna:104]
[same as prior period, unchanged from 0001408710-25-000023:mdna:125]

[0001408710-25-000056:mdna:105]
We primarily finance our operations through cash flow from operating activities. As of September 26, 2025 and September 27, 2024, we had cash, cash equivalents, and short-term investments of $968.8 million and $908.9.0 million, respectively, and no outstanding debt.

[0001408710-25-000056:mdna:106]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents was 4.0% and 4.6% for the three and three months ended September 26, 2025 and September 27, 2024, respectively.

[0001408710-25-000056:mdna:107]
Our cash investments are made in accordance with an investment policy approved by the audit committee of our board of directors. In general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed income securities are primarily classified as available-for-sale and are recorded at fair value. The cost of securities sold is based on the specific identification method.

[0001408710-25-000056:mdna:108]
Unrealized gains and losses on these securities are recorded as other comprehensive income (loss) and are reported as a separate component of shareholders’ equity.

[0001408710-25-000056:mdna:109]
We believe that our current cash and cash equivalents, short-term investments, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q. We also believe that our current manufacturing capacity is sufficient to meet our anticipated production requirements for at least the next few quarters. In February 2025, we began construction of a new manufacturing facility of approximately 2.0 million square feet at our Chonburi campus. The total expected cost of the project is approximately $132.5 million (Thai baht 4.45 billion).

[0001408710-25-000056:mdna:110]
[same as prior period, unchanged from 0001408710-25-000023:mdna:131]

[0001408710-25-000056:mdna:111]
|  | Three Months Ended |
| (in thousands) | September 26, 2025 |  | September 27, 2024 |
| Net cash provided by operating activities | $ | 102,568 |  |  | $ | 83,182 |  |
| Net cash used in investing activities | $ | (80,960) |  |  | $ | (71,994) |  |
| Net cash used in financing activities | $ | (22,965) |  |  | $ | (20,220) |  |
| Net increase in cash and cash equivalents | $ | (1,357) |  |  | $ | (9,032) |  |

[0001408710-25-000056:mdna:112]
[same as prior period, unchanged from 0001408710-25-000023:mdna:133]

[0001408710-25-000056:mdna:113]
Cash provided by operating activities is net income adjusted for certain non-cash items and changes in certain assets and liabilities. The increase in cash provided by operating activities during the three months ended September 26, 2025 as compared to the three months ended September 27, 2024 was primarily more efficient cash-favorable working capital changes mainly from a decrease in trade receivables due to timing of collection, and an increase in inventories to support higher demand in next quarter.

[0001408710-25-000056:mdna:114]
[same as prior period, unchanged from 0001408710-25-000023:mdna:135]

[0001408710-25-000056:mdna:115]
Investing cash flows consist primarily of investment purchases, sales, maturities, and disposals; and capital expenditures. The increase in cash used in investing activities for the three months ended September 26, 2025 as compared to cash used in investing activities for the three months ended September 27, 2024 was primarily due to (1) an increase related to the construction of a new manufacturing building at our Chonburi campus, and (2) an increase in capital expenditures to support certain customers, offset by an increase in net proceeds of investment.

[0001408710-25-000056:mdna:116]
[same as prior period, unchanged from 0001408710-25-000023:mdna:137]

[0001408710-25-000056:mdna:117]
Financing cash flows consist primarily of repayment of long-term debt, share repurchases, and withholding tax related to net share settlement of restricted share units. The increase in cash used in financing activities for the three months ended September 26, 2025 as compared to the three months ended September 27, 2024 was due to higher withholding tax related to net share settlement of restricted share units and an increase in share repurchases.

[0001408710-25-000056:mdna:118]
[same as prior period, unchanged from 0001408710-25-000023:mdna:139]

[0001408710-25-000056:mdna:119]
[same as prior period, unchanged from 0001408710-25-000023:mdna:140]
