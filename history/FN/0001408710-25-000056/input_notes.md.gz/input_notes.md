# FN notes — 0001408710-25-000056


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001408710-25-000056:notes:1]
[same as prior period, unchanged from 0001408710-25-000023:notes:1]

[0001408710-25-000056:notes:2]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of September 26, 2025 and for the three months ended September 26, 2025 and September 27, 2024 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 27, 2025.

[0001408710-25-000056:notes:3]
The balance sheet as of June 27, 2025 has been derived from the audited financial statements at that date but does not include all of the information and footnotes required by U.S. GAAP for complete financial statements.

[0001408710-25-000056:notes:4]
The results for the three months ended September 26, 2025 may not be indicative of results for the year ending June 26, 2026 or any future periods.

[0001408710-25-000056:notes:5]
[same as prior period, unchanged from 0001408710-25-000023:notes:5]

[0001408710-25-000056:notes:6]
[same as prior period, unchanged from 0001408710-25-000023:notes:6]

[0001408710-25-000056:notes:7]
[same as prior period, unchanged from 0001408710-25-000023:notes:7]

[0001408710-25-000056:notes:8]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended September 26, 2025 and September 27, 2024 consisted of 13 weeks. Fiscal year 2026 will comprise 52 weeks and will end on June 26, 2026.

[0001408710-25-000056:notes:9]
[same as prior period, unchanged from 0001408710-25-000023:notes:9]

[0001408710-25-000056:notes:10]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740), Improvements to Income Tax Disclosures,” which requires more detailed income tax disclosures. This ASU requires entities to disclose disaggregated information about their effective tax rate reconciliation as well as expanded information on income taxes paid by jurisdiction. This ASU is effective for all entities for fiscal years beginning after December 15, 2024, with early adoption permitted for annual financial statements that have not yet been issued or made available for issuance. This ASU will be effective for the Company beginning in fiscal year 2026. The Company is currently assessing the impact to its disclosures.

[0001408710-25-000056:notes:11]
In November 2024, the FASB issued ASU 2024-03, “Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), Disaggregation of Income Statement Expenses,” which requires additional notes to financial statements. This ASU requires entities to include certain current disclosures in the same tabular format disclosure as the other disaggregation requirements in the amendments in this ASU. This ASU is effective for all entities for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027, with early adoption permitted. This ASU is effective for the Company's annual periods beginning June 26, 2027, and interim periods beginning July 1, 2028, and will be applied retrospectively to all prior periods presented in the financial statements. The Company is currently evaluating the ASU to determine its impact on the Company's disclosures.

[0001408710-25-000056:notes:12]
In July 2025, the FASB issued ASU 2025-05, “Financial Instruments – Credit Losses (Topic 326), Measurement of Credit Losses for Account Receivable and Contract Assets,” which requires the Company to consider available information that is relevant to assessing the collectibility of cash flows when developing an estimate of expected credit losses. The historical credit loss experience of financial assets with similar risk characteristics generally provides a basis for the Company's assessment of expected credit losses. However, the Company is required to consider adjustments to that information to reflect the extent to which management expects current conditions and reasonable and supportable forecasts to differ from the conditions that existed for the period over which historical information was evaluated. Those adjustments may be qualitative in nature and should reflect current conditions and forecasted changes related to relevant data (such as changes in unemployment rates, property values, commodity values, delinquency, or other factors that are associated with credit losses on the financial asset or in the group of financial assets). In addition, under current guidance, an entity would not consider collection activity after the balance sheet date when developing its estimate of expected credit losses. This ASU is effective for all entities for fiscal years beginning after December 15, 2025, and interim reporting periods within those fiscal year reporting periods, with early adoption permitted. The Company will adopt this guidance for its annual reporting period beginning June 27, 2026, and interim reporting periods within that annual reporting period, and does not expect the adoption to have a material impact on its consolidated financial statements.

[0001408710-25-000056:notes:13]
In September 2025, the FASB issued ASU 2025-06, “Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40), Targeted Improvements to the Accounting for Internal-Use Software,” which requires the Company to remove all references to software development project stages so that the guidance is neutral to different software development methods, including methods that entities may use to develop software in the future. This ASU is effective for all entities for fiscal years beginning after December 15, 2027, and interim reporting periods within those fiscal year reporting periods, with early adoption permitted. The Company will adopt this guidance for its annual reporting period beginning July 1, 2028, and interim reporting periods within that annual reporting period, and does not expect the adoption to have a material impact on its consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001408710-25-000056:notes:14]
[same as prior period, unchanged from 0001408710-25-000023:notes:13]

[0001408710-25-000056:notes:15]
[same as prior period, unchanged from 0001408710-25-000023:notes:14]

[0001408710-25-000056:notes:16]
[same as prior period, unchanged from 0001408710-25-000023:notes:15]

[0001408710-25-000056:notes:17]
| (in thousands, except percentages) | Three Months EndedSeptember 26, 2025 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 27, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 419,825 |  |  |  |  | $ | 307,820 |  |  |  |
| Others (1) | 2,192 |  |  |  |  | 1,658 |  |  |  |
| Total revenue in North America | 422,017 |  |  | 43.1 | % |  | 309,478 |  |  | 38.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 232,502 |  |  |  |  | 290,953 |  |  |  |
| India | 100,569 |  |  |  |  | 76,830 |  |  |  |
| Hong Kong | 36,523 |  |  |  |  | 18,547 |  |  |  |
| Malaysia | 22,763 |  |  |  |  | 7,498 |  |  |  |
| Thailand | 20,021 |  |  |  |  | 11,121 |  |  |  |
| Singapore | 19,720 |  |  |  |  | 10,763 |  |  |  |
| China | 18,121 |  |  |  |  | 11,872 |  |  |  |
| Japan | 10,581 |  |  |  |  | 8,579 |  |  |  |
| Others | 1,134 |  |  |  |  | 475 |  |  |  |
| Total revenue in Asia-Pacific and others | 461,934 |  |  | 47.2 | % |  | 436,638 |  |  | 54.3 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 52,928 |  |  |  |  | 32,450 |  |  |  |
| Finland | 12,525 |  |  |  |  | 294 |  |  |  |
| Germany | 11,718 |  |  |  |  | 9,344 |  |  |  |
| Others | 17,006 |  |  |  |  | 16,024 |  |  |  |
| Total revenue in Europe | $ | 94,177 |  |  | 9.7 | % |  | $ | 58,112 |  |  | 7.2 | % |
| Total revenue | $ | 978,128 |  |  | 100.0 | % |  | $ | 804,228 |  |  | 100.0 | % |

[0001408710-25-000056:notes:18]
(1)Others includes revenues from external customers based in our country of domicile, the Cayman Islands, which for each period presented is $0.

[0001408710-25-000056:notes:19]
[same as prior period, unchanged from 0001408710-25-000023:notes:19]

[0001408710-25-000056:notes:20]
| (in thousands, except percentages) | Three Months EndedSeptember 26, 2025 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 27, 2024 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Telecom | $ | 335,720 |  |  |  |  | $ | 225,627 |  |  |  |
| Datacom | 273,096 |  |  |  |  | 328,881 |  |  |  |
| Datacenter interconnect (1) | 138,080 |  |  |  |  | 71,807 |  |  |  |
| Total revenue - Optical communications | $ | 746,896 |  |  | 76.4 | % |  | $ | 626,315 |  |  | 77.9 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 121,948 |  |  |  |  | $ | 102,741 |  |  |  |
| Industrial laser | 39,679 |  |  |  |  | 35,326 |  |  |  |
| High-performance computing (2) | 15,403 |  |  |  |  | — |  |  |  |
| Others | 54,202 |  |  |  |  | 39,846 |  |  |  |
| Total revenue - Non-optical communications | $ | 231,232 |  |  | 23.6 | % |  | $ | 177,913 |  |  | 22.1 | % |
| Total revenue | $ | 978,128 |  |  | 100.0 | % |  | $ | 804,228 |  |  | 100.0 | % |

[0001408710-25-000056:notes:21]
(1)Datacenter interconnect (DCI) modules are opto-electronic modules used to connect two or more geographically separated data centers.

[0001408710-25-000056:notes:22]
(2)High-performance computing (HPC) products are massively parallel computing systems built from interconnected high-performance processors, accelerators, high-speed memory, and low-latency networking to solve complex, compute-intensive problems.

[0001408710-25-000056:notes:23]
[same as prior period, unchanged from 0001408710-25-000023:notes:22]

[0001408710-25-000056:notes:24]
[same as prior period, unchanged from 0001408710-25-000023:notes:23]

[0001408710-25-000056:notes:25]
As of September 26, 2025 and June 27, 2025, the Company's contract assets were de minimis.

[0001408710-25-000056:notes:26]
[same as prior period, unchanged from 0001408710-25-000023:notes:25]

[0001408710-25-000056:notes:27]
The following tables summarize the activity in the Company’s contract liabilities during the three months ended September 26, 2025:

[0001408710-25-000056:notes:28]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 27, 2025 | $ | 14,467 |  |
| Advance payments received during the period | 4,074 |  |
| Revenue recognized | (8,765) |  |
| Ending balance, September 26, 2025 | $ | 9,776 |  |

[0001408710-25-000056:notes:29]
[same as prior period, unchanged from 0001408710-25-000023:notes:28]

[0001408710-25-000056:notes:30]
[same as prior period, unchanged from 0001408710-25-000023:notes:29]

[0001408710-25-000056:notes:31]
[same as prior period, unchanged from 0001408710-25-000023:notes:30]

[0001408710-25-000056:notes:32]
For the three months ended September 26, 2025, the Company recognized $0.3 million as a reduction to revenue on the unaudited condensed consolidated statements of operations.


## us-gaap:EarningsPerShareTextBlock

[0001408710-25-000056:notes:33]
[same as prior period, unchanged from 0001408710-25-000023:notes:32]

[0001408710-25-000056:notes:34]
[same as prior period, unchanged from 0001408710-25-000023:notes:33]

[0001408710-25-000056:notes:35]
|  |  |  | Three Months Ended |
| (in thousands, except per share data) |  |  |  |  | September 26,2025 |  | September 27,2024 |
| Net income attributable to shareholders |  |  |  |  | $ | 95,926 |  |  | $ | 77,394 |  |
| Weighted-average number of ordinary shares outstanding |  |  |  |  | 35,773 |  |  | 36,203 |  |
| Incremental shares arising from the assumed vesting of restricted share units and performance share units |  |  |  |  | 185 |  |  | 205 |  |
| Incremental shares arising from the assumed vesting of customer warrant |  |  |  |  | 139 |  |  | — |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share |  |  |  |  | 36,097 |  |  | 36,408 |  |
| Basic earnings per ordinary share |  |  |  |  | $ | 2.68 |  |  | $ | 2.14 |  |
| Diluted earnings per ordinary share |  |  |  |  | $ | 2.66 |  |  | $ | 2.13 |  |
| Outstanding performance share units excluded from the computation of diluted earnings per ordinary share (1) |  |  |  |  | 3 |  |  | — |  |

[0001408710-25-000056:notes:36]
(1)These performance share units were not included in the computation of diluted earnings per ordinary share because they are not expected to vest based on the Company’s current assessment of the related performance obligations.


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001408710-25-000056:notes:37]
[same as prior period, unchanged from 0001408710-25-000023:notes:35]

[0001408710-25-000056:notes:38]
|  |  |  | Fair Value |
| (in thousands) | CarryingCost |  | UnrealizedGain/(Loss) |  | Cash andCashEquivalents |  | Short-term Investments |  | OtherInvestments |
| As of September 26, 2025 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 302,154 |  |  | $ | — |  |  | $ | 302,154 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 2,847 |  |  | — |  |  | 2,847 |  |  | — |  |  | — |  |
| Certificates of deposit and time deposits | 136,496 |  |  | 3 |  |  | — |  |  | 136,499 |  |  | — |  |
| Corporate debt securities | 224,817 |  |  | 6,992 |  |  | — |  |  | 231,809 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 294,551 |  |  | 912 |  |  | — |  |  | 295,463 |  |  | — |  |
| Total | $ | 960,865 |  |  | $ | 7,907 |  |  | $ | 305,001 |  |  | $ | 663,771 |  |  | $ | — |  |
| As of June 27, 2025 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 295,242 |  |  | $ | — |  |  | $ | 295,242 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 11,183 |  |  | — |  |  | 11,183 |  |  | — |  |  | — |  |
| Certificates of deposit and time deposits | 144,730 |  |  | 1,022 |  |  | — |  |  | 145,752 |  |  | — |  |
| Corporate debt securities | 183,076 |  |  | 6,897 |  |  | — |  |  | 189,973 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 291,295 |  |  | 799 |  |  | — |  |  | 292,094 |  |  | — |  |
| Total | $ | 925,526 |  |  | $ | 8,718 |  |  | $ | 306,425 |  |  | $ | 627,819 |  |  | $ | — |  |

[0001408710-25-000056:notes:39]
All highly liquid investments with original maturities of three months or less at the date of purchase are classified as cash equivalents. Management determines the appropriate classification of its investments at the time of purchase. The

[0001408710-25-000056:notes:40]
Company may sell certain of its short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s short-term investments generally range from three months to three years.

[0001408710-25-000056:notes:41]
The following table summarizes the cost and estimated fair value of debt securities classified as available-for-sale securities based on stated effective maturities as of September 26, 2025 and June 27, 2025:

[0001408710-25-000056:notes:42]
|  | September 26, 2025 |  | June 27, 2025 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 116,496 |  |  | $ | 116,499 |  |  | $ | 128,958 |  |  | $ | 129,977 |  |
| Due between one to five years | 539,368 |  |  | 547,272 |  |  | 490,143 |  |  | 497,842 |  |
| Total | $ | 655,864 |  |  | $ | 663,771 |  |  | $ | 619,101 |  |  | $ | 627,819 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001408710-25-000056:notes:43]
[same as prior period, unchanged from 0001408710-25-000023:notes:40]

[0001408710-25-000056:notes:44]
[same as prior period, unchanged from 0001408710-25-000023:notes:41]

[0001408710-25-000056:notes:45]
[same as prior period, unchanged from 0001408710-25-000023:notes:42]

[0001408710-25-000056:notes:46]
[same as prior period, unchanged from 0001408710-25-000023:notes:43]

[0001408710-25-000056:notes:47]
[same as prior period, unchanged from 0001408710-25-000023:notes:44]

[0001408710-25-000056:notes:48]
[same as prior period, unchanged from 0001408710-25-000023:notes:45]

[0001408710-25-000056:notes:49]
|  | Fair Value Measurements at Reporting Date Using |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of September 26, 2025 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 2,847 |  |  |  | $ | — |  |  | $ | 2,847 |  |
| Certificates of deposit and time deposits | — |  |  | 136,499 |  |  |  | — |  |  | 136,499 |  |
| Corporate debt securities | — |  |  | 231,809 |  |  |  | — |  |  | 231,809 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 295,463 |  |  |  | — |  |  | 295,463 |  |
| Derivative assets – current portion | — |  |  | 1,044 |  | (1) |  | — |  |  | 1,044 |  |
| Total | $ | — |  |  | $ | 667,662 |  |  |  | $ | — |  |  | $ | 667,662 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | (1,001) |  | (2) |  | $ | — |  |  | $ | (1,001) |  |
| Total | $ | — |  |  | $ | (1,001) |  |  |  | $ | — |  |  | $ | (1,001) |  |

[0001408710-25-000056:notes:50]
|  | Fair Value Measurements at Reporting Date Using |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of June 27, 2025 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 11,183 |  |  |  | $ | — |  |  | $ | 11,183 |  |
| Certificates of deposit and time deposits | — |  |  | 145,752 |  |  |  | — |  |  | 145,752 |  |
| Corporate debt securities | — |  |  | 189,973 |  |  |  | — |  |  | 189,973 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 292,094 |  |  |  | — |  |  | 292,094 |  |
| Derivative assets – current portion | — |  |  | 2,961 |  | (3) |  | — |  |  | 2,961 |  |
| Total | $ | — |  |  | $ | 641,963 |  |  |  | $ | — |  |  | $ | 641,963 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | (105) |  | (4) |  | $ | — |  |  | $ | (105) |  |
| Total | $ | — |  |  | $ | (105) |  |  |  | $ | — |  |  | $ | (105) |  |

[0001408710-25-000056:notes:51]
(1)Foreign currency forward contracts with an aggregate notional amount of $110.0 million.

[0001408710-25-000056:notes:52]
(2)Foreign currency forward contracts with an aggregate notional amount of $86.0 million and 0.5 million Canadian dollars.

[0001408710-25-000056:notes:53]
(3)Foreign currency forward contracts with an aggregate notional amount of $130.0 million and 0.5 million Canadian dollars.

[0001408710-25-000056:notes:54]
(4)Foreign currency forward contracts with an aggregate notional amount of $35.0 million.

[0001408710-25-000056:notes:55]
[same as prior period, unchanged from 0001408710-25-000023:notes:52]

[0001408710-25-000056:notes:56]
The Company utilizes derivative financial instruments to hedge foreign exchange risk associated with certain foreign currency denominated assets and liabilities and other foreign currency transactions.

[0001408710-25-000056:notes:57]
[same as prior period, unchanged from 0001408710-25-000023:notes:54]

[0001408710-25-000056:notes:58]
[same as prior period, unchanged from 0001408710-25-000023:notes:55]

[0001408710-25-000056:notes:59]
[same as prior period, unchanged from 0001408710-25-000023:notes:56]

[0001408710-25-000056:notes:60]
[same as prior period, unchanged from 0001408710-25-000023:notes:57]

[0001408710-25-000056:notes:61]
[same as prior period, unchanged from 0001408710-25-000023:notes:58]

[0001408710-25-000056:notes:62]
As of September 26, 2025, the Company had 196 outstanding U.S. dollar foreign currency forward contracts against Thai baht, with an aggregate notional amount of $196.0 million and maturity dates ranging from October 2025 through April 2026 and one outstanding Canadian dollar foreign currency forward contract with a notional amount of 0.5 million Canadian dollars and a maturity date in December 2025.

[0001408710-25-000056:notes:63]
As of June 27, 2025, the Company had 165 outstanding U.S. dollar foreign currency forward contracts against Thai baht with an aggregate notional amount of $165.0 million and maturity dates ranging from July 2025 through December 2025, and one foreign currency contract with a notional amount of 0.5 million Canadian dollars and a maturity date in September 2025.

[0001408710-25-000056:notes:64]
As of September 26, 2025, the hedging relationship over foreign currency forward contracts designated for hedge accounting was determined to be highly effective based on the performance of retrospective and prospective regression testing. As of September 26, 2025, the amount in accumulated other comprehensive income (“AOCI”) expected to be reclassified into earnings within 12 months was a loss of $0.6 million.

[0001408710-25-000056:notes:65]
As of June 27, 2025, the hedging relationship over foreign currency forward contracts designated for hedge accounting had been tested to be highly effective based on the performance of retrospective and prospective regression testing. As of June 27, 2025, the amount in AOCI expected to be reclassified into earnings within 12 months as gain was $1.5 million.

[0001408710-25-000056:notes:66]
During the three months ended September 26, 2025 and September 27, 2024, the Company included an unrealized loss of $1.3 million and unrealized gain of $4.1 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-25-000056:notes:67]
[same as prior period, unchanged from 0001408710-25-000023:notes:65]

[0001408710-25-000056:notes:68]
|  |  |  |  |  | Three Months Ended |
| (in thousands) | Financialstatementsline item |  |  |  |  |  | September 26,2025 |  | September 27,2024 |
| Derivatives gain (loss) recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Othercomprehensiveincome (loss) |  |  |  |  |  | $ | (2,800) |  |  | $ | 13,246 |  |
| Total derivatives gain (loss) recognized in other comprehensive income (loss) |  |  |  |  |  |  | $ | (2,800) |  |  | $ | 13,246 |  |
| Derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings: |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Cost of revenues |  |  |  |  |  | $ | (1,251) |  |  | $ | 1,419 |  |
| Foreign currency forward contracts | SG&A |  |  |  |  |  | (95) |  |  | 106 |  |
| Foreign currency forward contracts | Foreign exchange gain (loss), net |  |  |  |  |  | 2,008 |  |  | (5,909) |  |
| Total derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings |  |  |  |  |  |  | $ | 662 |  |  | $ | (4,384) |  |
| Change in net unrealized gain (loss) on derivatives instruments |  |  |  |  |  |  | $ | (2,138) |  |  | $ | 8,862 |  |

[0001408710-25-000056:notes:69]
[same as prior period, unchanged from 0001408710-25-000023:notes:67]

[0001408710-25-000056:notes:70]
[same as prior period, unchanged from 0001408710-25-000023:notes:68]

[0001408710-25-000056:notes:71]
|  | September 26,2025 |  | June 27,2025 |
| (in thousands) | DerivativeAssets |  | DerivativeLiabilities |  | DerivativeAssets |  | DerivativeLiabilities |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts | $ | 655 |  |  | $ | (39) |  |  | $ | 1,303 |  |  | $ | (12) |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward contracts | 389 |  |  | (962) |  |  | 1,658 |  |  | (93) |  |
| Derivatives, gross balances | $ | 1,044 |  |  | $ | (1,001) |  |  | $ | 2,961 |  |  | $ | (105) |  |

[0001408710-25-000056:notes:72]
[same as prior period, unchanged from 0001408710-25-000023:notes:70]

[0001408710-25-000056:notes:73]
| Derivative Financial Instruments | Balance Sheet line item |
| Fair Value of Derivative Assets | Other non-current assets |
| Fair Value of Derivative Liabilities | Accrued expenses |


## us-gaap:InventoryDisclosureTextBlock

[0001408710-25-000056:notes:74]
[same as prior period, unchanged from 0001408710-25-000023:notes:72]

[0001408710-25-000056:notes:75]
| (in thousands) | As of September 26,2025 |  | As of June 27,2025 |
| Raw materials | $ | 191,984 |  |  | $ | 145,128 |  |
| Work in progress | 417,349 |  |  | 377,736 |  |
| Finished goods | 78,691 |  |  | 33,016 |  |
| Goods in transit | 34,170 |  |  | 25,135 |  |
| Total inventories | $ | 722,194 |  |  | $ | 581,015 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001408710-25-000056:notes:76]
[same as prior period, unchanged from 0001408710-25-000023:notes:74]

[0001408710-25-000056:notes:77]
[same as prior period, unchanged from 0001408710-25-000023:notes:75]

[0001408710-25-000056:notes:78]
As of September 26, 2025, the maturities of the Company’s operating lease liabilities, by fiscal year, were as follows:

[0001408710-25-000056:notes:79]
| (in thousands) |  |  |
| 2026 (remaining nine months) | $ | 1,623 |  |  |
| 2027 | 1,351 |  |  |
| 2028 | 880 |  |  |
| 2029 | 806 |  |  |
| 2030 | 441 |  |  |
| Thereafter | 978 |  |  |
| Total undiscounted lease payments | 6,079 |  |  |
| Less imputed interest | (915) |  |  |
| Total present value of lease liabilities | $ | 5,164 |  | (1) |

[0001408710-25-000056:notes:80]
(1)    Includes current portion of operating lease liabilities of $1.9 million.

[0001408710-25-000056:notes:81]
[same as prior period, unchanged from 0001408710-25-000023:notes:79]

[0001408710-25-000056:notes:82]
Rental expense for long-term leases for the three months ended September 26, 2025 and September 27, 2024 was $0.5 million for both periods.

[0001408710-25-000056:notes:83]
Rental expense for short-term leases for the three months ended September 26, 2025 and September 27, 2024 was de minimis.

[0001408710-25-000056:notes:84]
[same as prior period, unchanged from 0001408710-25-000023:notes:82]

[0001408710-25-000056:notes:85]
|  | As ofSeptember 26, 2025 |  | As ofJune 27, 2025 |
| Weighted-average remaining lease term (in years) | 5.0 |  | 5.5 |
| Weighted-average discount rate | 6.5 | % |  | 6.6 | % |

[0001408710-25-000056:notes:86]
The following table presents supplemental disclosure for the unaudited condensed consolidated statements of cash flows related to operating leases for the three months ended September 26, 2025 and September 27, 2024:

[0001408710-25-000056:notes:87]
|  |  |  | Three Months Ended |
| (in thousands) |  |  |  |  | September 26,2025 |  | September 27,2024 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |
| Operating cash flows from operating leases |  |  |  |  | $ | 607 |  |  | $ | 745 |  |
| ROU assets obtained in exchange for lease liabilities |  |  |  |  | $ | 107 |  |  | $ | 159 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001408710-25-000056:notes:88]
[same as prior period, unchanged from 0001408710-25-000023:notes:86]

[0001408710-25-000056:notes:89]
| (in thousands) | As ofSeptember 26, 2025 |  | As ofJune 27, 2025 |  |  |
| Software |  |  |  |  |  |
| Gross carrying amount | $ | 12,343 |  |  | $ | 12,159 |  |  |  |
| Accumulated amortization | (10,232) |  |  | (10,003) |  |  |  |
| Net | $ | 2,111 |  |  | $ | 2,156 |  |  |  |

[0001408710-25-000056:notes:90]
The Company recorded amortization expense relating to intangibles of $0.2 million and $0.3 million for the three months ended September 26, 2025 and September 27, 2024, respectively.

[0001408710-25-000056:notes:91]
[same as prior period, unchanged from 0001408710-25-000023:notes:89]

[0001408710-25-000056:notes:92]
| (years) | As ofSeptember 26, 2025 |  | As ofJune 27, 2025 |
| Software | 3.4 |  | 3.6 |

[0001408710-25-000056:notes:93]
Based on the carrying amount of intangibles as of September 26, 2025, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001408710-25-000056:notes:94]
| (in thousands) |  |
| 2026 (remaining nine months) | $ | 620 |  |
| 2027 | 635 |  |
| 2028 | 459 |  |
| 2029 | 262 |  |
| 2030 | 130 |  |
| Thereafter | 5 |  |
| Total | $ | 2,111 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001408710-25-000056:notes:95]
Income taxes
As of September 26, 2025 and June 27, 2025, the liability for uncertain tax positions including accrued interest and penalties was $2.6 million and $2.2 million, respectively.

[0001408710-25-000056:notes:96]
The Company files income tax returns in the United States and foreign tax jurisdictions. The tax years from 2018 to 2024 remain open to examination by U.S. federal and state, and foreign tax authorities. The Company is currently under examination by the U.S. Internal Revenue Service for fiscal year 2022 and the IRS completed the examination of the US subsidiaries for fiscal year 2022 and fiscal year 2023 in the fiscal year 2025. The Company’s income tax is recognized based on the best estimate of the expected annual effective tax rate for the full financial year of each entity in the Company, adjusted for discrete items arising in that quarter. If the Company’s estimated annual effective tax rate changes, the Company makes a cumulative adjustment in that quarter.
The effective tax rate for the Company for the three months ended September 26, 2025 and September 27, 2024 was 5.4% and 4.2%, respectively, of net income. The increase was due to higher income subject to tax


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001408710-25-000056:notes:97]
[same as prior period, unchanged from 0001408710-25-000023:notes:97]

[0001408710-25-000056:notes:98]
[same as prior period, unchanged from 0001408710-25-000023:notes:98]

[0001408710-25-000056:notes:99]
The effect of recording share-based compensation expense for the three months ended September 26, 2025 and September 27, 2024 was as follows:

[0001408710-25-000056:notes:100]
|  |  |  | Three Months Ended |
| (in thousands) |  |  |  |  | September 26,2025 |  | September 27,2024 |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |
| Restricted share units |  |  |  |  | $ | 6,368 |  |  | $ | 5,713 |  |
| Performance share units |  |  |  |  | 2,703 |  |  | 2,969 |  |
| Total share-based compensation expense |  |  |  |  | 9,071 |  |  | 8,682 |  |
| Tax effect on share-based compensation expense |  |  |  |  | — |  |  | — |  |
| Net effect on share-based compensation expense |  |  |  |  | $ | 9,071 |  |  | $ | 8,682 |  |

[0001408710-25-000056:notes:101]
[same as prior period, unchanged from 0001408710-25-000023:notes:101]

[0001408710-25-000056:notes:102]
|  |  |  | Three Months Ended |
| (in thousands) |  |  |  |  | September 26,2025 |  | September 27,2024 |
| Cost of revenue |  |  |  |  | $ | 3,519 |  |  | $ | 2,898 |  |
| Selling, general and administrative expense |  |  |  |  | 5,552 |  |  | 5,784 |  |
| Total share-based compensation expense |  |  |  |  | $ | 9,071 |  |  | $ | 8,682 |  |

[0001408710-25-000056:notes:103]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the three months ended September 26, 2025 and September 27, 2024.

[0001408710-25-000056:notes:104]
[same as prior period, unchanged from 0001408710-25-000023:notes:104]

[0001408710-25-000056:notes:105]
[same as prior period, unchanged from 0001408710-25-000023:notes:105]

[0001408710-25-000056:notes:106]
On November 2, 2017, the Company adopted the 2017 Inducement Equity Incentive Plan (the “2017 Inducement Plan”) with a reserve of 160,000 ordinary shares authorized for future issuance solely for the granting of inducement share options

[0001408710-25-000056:notes:107]
and equity awards to new employees. The 2017 Inducement Plan was adopted without shareholder approval in reliance on the “employment inducement exemption” provided under the New York Stock Exchange Listed Company Manual.

[0001408710-25-000056:notes:108]
The 2020 Plan and 2017 Inducement Plan are collectively referred to as the “Equity Incentive Plans.”

[0001408710-25-000056:notes:109]
The following table summarizes the number of equity awards outstanding and ordinary shares available for grant under each of the Equity Incentive Plans as of September 26, 2025:

[0001408710-25-000056:notes:110]
| (share units) | Restricted Share Units outstanding |  | Performance Share Units outstanding |  | Ordinary Shares available for future grant |
| 2020 Plan | 232,190 |  |  | 92,843 |  |  | 1,467,256 |  |
| 2017 Inducement Plan | — |  |  | — |  |  | 111,347 |  |
| Total | 232,190 |  |  | 92,843 |  |  | 1,578,603 |  |

[0001408710-25-000056:notes:111]
[same as prior period, unchanged from 0001408710-25-000023:notes:110]

[0001408710-25-000056:notes:112]
[same as prior period, unchanged from 0001408710-25-000023:notes:111]

[0001408710-25-000056:notes:113]
[same as prior period, unchanged from 0001408710-25-000023:notes:112]

[0001408710-25-000056:notes:114]
[same as prior period, unchanged from 0001408710-25-000023:notes:113]

[0001408710-25-000056:notes:115]
[same as prior period, unchanged from 0001408710-25-000023:notes:114]

[0001408710-25-000056:notes:116]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 27, 2025 | 263,014 |  |  | $ | 187.00 |  |
| Granted | 67,584 |  |  | $ | 277.04 |  |
| Vested | (94,607) |  |  | $ | 162.08 |  |
| Forfeited | (3,801) |  |  | $ | 212.71 |  |
| Balance as of September 26, 2025 | 232,190 |  |  | $ | 223.81 |  |

[0001408710-25-000056:notes:117]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 28, 2024 | 306,660 |  |  | $ | 129.01 |  |
| Granted | 92,048 |  |  | $ | 261.84 |  |
| Vested | (113,262) |  |  | $ | 112.98 |  |
| Forfeited | (4,693) |  |  | $ | 138.88 |  |
| Balance as of September 27, 2024 | 280,753 |  |  | $ | 178.86 |  |

[0001408710-25-000056:notes:118]
[same as prior period, unchanged from 0001408710-25-000023:notes:117]

[0001408710-25-000056:notes:119]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 27, 2025 | 120,916 |  |  | $ | 198.90 |  |
| Granted | 48,806 |  |  | $ | 277.04 |  |
| Vested | (73,936) |  |  | $ | 158.91 |  |
| Forfeited | (2,943) |  |  | $ | 261.84 |  |
| Balance as of September 26, 2025 | 92,843 |  |  | $ | 269.83 |  |

[0001408710-25-000056:notes:120]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 28, 2024 | 171,078 |  |  | $ | 135.31 |  |
| Granted | 46,980 |  |  | $ | 261.84 |  |
| Vested | (97,142) |  |  | 117.35 |  |
| Forfeited | — |  |  | $ | — |  |
| Balance as of September 27, 2024 | 120,916 |  |  | $ | 198.90 |  |

[0001408710-25-000056:notes:121]
As of September 26, 2025, there was $28.6 million and $17.2 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.9 and 1.6 years, respectively.

[0001408710-25-000056:notes:122]
For the three months ended September 26, 2025 and September 27, 2024, the Company withheld an aggregate of 69,332 shares and 88,007 shares, respectively, upon the vesting of restricted share units and performance shares units, based upon the closing share price on the vesting date to settle employee tax withholding obligations. For the three months ended September 26, 2025 and September 27, 2024, the Company then remitted cash of $22.7 million and $20.2 million, respectively, to the appropriate taxing authorities and presented it as a financing activity within the unaudited condensed consolidated statements of cash flows. The payment was recorded as a reduction of additional paid-in capital.

[0001408710-25-000056:notes:123]
[same as prior period, unchanged from 0001408710-25-000023:notes:122]

[0001408710-25-000056:notes:124]
[same as prior period, unchanged from 0001408710-25-000023:notes:123]

[0001408710-25-000056:notes:125]
[same as prior period, unchanged from 0001408710-25-000023:notes:124]

[0001408710-25-000056:notes:126]
[same as prior period, unchanged from 0001408710-25-000023:notes:125]

[0001408710-25-000056:notes:127]
As of September 26, 2025 and June 27, 2025, 42,012 and 38,192 Warrant Shares, respectively, were vested and remained unexercised.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001408710-25-000056:notes:128]
[same as prior period, unchanged from 0001408710-25-000023:notes:126]

[0001408710-25-000056:notes:129]
[same as prior period, unchanged from 0001408710-25-000023:notes:127]

[0001408710-25-000056:notes:130]
For the three months ended September 26, 2025, Fabrinet issued 99,211 ordinary shares upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-25-000056:notes:131]
For the three months ended September 27, 2024, Fabrinet issued 122,397 ordinary shares upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-25-000056:notes:132]
[same as prior period, unchanged from 0001408710-25-000023:notes:130]

[0001408710-25-000056:notes:133]
[same as prior period, unchanged from 0001408710-25-000023:notes:131]

[0001408710-25-000056:notes:134]
[same as prior period, unchanged from 0001408710-25-000023:notes:132]

[0001408710-25-000056:notes:135]
During the three months ended September 26, 2025, 970 shares were repurchased under the program, at an average price per share (excluding other direct costs) of $276.22, for an aggregate purchase price of $0.3 million. As of September 26, 2025, the Company had a remaining authorization to repurchase up to $174.0 million worth of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001408710-25-000056:notes:136]
Accumulated other comprehensive income (loss)
The changes in AOCI for the three months ended September 26, 2025 and September 27, 2024 were as follows:

[0001408710-25-000056:notes:137]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  |  |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 27, 2025 | $ | 8,714 |  |  | $ | 1,334 |  |  |  |  | $ | 246 |  |  | $ | 10,294 |  |
| Other comprehensive income (loss) before reclassification | (811) |  |  | (2,800) |  |  |  |  | (89) |  |  | (3,700) |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | — |  |  | 662 |  |  |  |  | — |  |  | 662 |  |
| Tax effects | — |  |  | 76 |  |  |  |  | — |  |  | 76 |  |
| Other comprehensive income (loss) | $ | (811) |  |  | $ | (2,062) |  |  |  |  | $ | (89) |  |  | $ | (2,962) |  |
| Balance as of September 26, 2025 | $ | 7,903 |  |  | $ | (728) |  |  |  |  | $ | 157 |  |  | $ | 7,332 |  |

[0001408710-25-000056:notes:138]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  |  |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 28, 2024 | $ | (1,179) |  |  | $ | (980) |  |  |  |  | $ | (982) |  |  | $ | (3,141) |  |
| Other comprehensive income (loss) before reclassification | 6,818 |  |  | 13,246 |  |  |  |  | (352) |  |  | 19,712 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | — |  |  | (4,384) |  |  |  |  | — |  |  | (4,384) |  |
| Tax effects | — |  |  | (329) |  |  |  |  | — |  |  | (329) |  |
| Other comprehensive income (loss) | $ | 6,818 |  |  | $ | 8,533 |  |  |  |  | $ | (352) |  |  | $ | 14,999 |  |
| Balance as of September 27, 2024 | $ | 5,639 |  |  | $ | 7,553 |  |  |  |  | $ | (1,334) |  |  | $ | 11,858 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001408710-25-000056:notes:139]
Commitments and contingencies
Bank guarantees

[0001408710-25-000056:notes:140]
As of September 26, 2025 and June 27, 2025, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.4 million and $2.3 million, respectively, or Thai baht 77.3 million and 75.7 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the subsidiary's operations related to the Israeli Customs department.

[0001408710-25-000056:notes:141]
Purchase obligations

[0001408710-25-000056:notes:142]
Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001408710-25-000056:notes:143]
As of September 26, 2025, the Company had purchase obligations and other commitments to third parties of $1.54 billion.

[0001408710-25-000056:notes:144]
Capital expenditures

[0001408710-25-000056:notes:145]
In February 2025, the Company entered into a construction contract with a local contractor for construction of a new

[0001408710-25-000056:notes:146]
manufacturing building at the Company's Chonburi campus. The contract price is approximately $132.5 million (Thai baht

[0001408710-25-000056:notes:147]
4.45 billion).

[0001408710-25-000056:notes:148]
As of September 26, 2025, the Company had total capital expenditure commitments to third parties of $196.0 million.

[0001408710-25-000056:notes:149]
Indemnification of directors and officers

[0001408710-25-000056:notes:150]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001408710-25-000056:notes:151]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.

[0001408710-25-000056:notes:152]
Credit facility agreement

[0001408710-25-000056:notes:153]
On March 9, 2023, Fabrinet Thailand and the Parent Company (collectively, the “Borrowers”) and the Bank of Ayudhya Public Company Limited (the "Bank") entered into a credit facility agreement (the “2023 Credit Facility Agreement”), which provided a facility of $55.0 million.

[0001408710-25-000056:notes:154]
During the three months ended December 27, 2024, the Borrowers and the Bank amended the 2023 Credit Facility Agreement to reduce the facility to $30.0 million, which may be used for, among other things, an overdraft facility.

[0001408710-25-000056:notes:155]
As of September 26, 2025, there was no amount outstanding under the 2023 Credit Facility Agreement.

[0001408710-25-000056:notes:156]
Under the 2023 Credit Facility Agreement, the Borrowers are required to maintain a debt-to-equity ratio of less than or equal to 1.5 times for Fabrinet Thailand and 1.0 times for the Parent Company.

[0001408710-25-000056:notes:157]
As of September 26, 2025, the Borrowers were in compliance with all of their financial covenants under the 2023 Credit Facility Agreement.

[0001408710-25-000056:notes:158]
Litigation and claim

[0001408710-25-000056:notes:159]
On June 28, 2024, Ngan In Leng and First Laser Limited (collectively, the “Plaintiffs”) filed a complaint in the Fuzhou Intermediate People’s Court (the “Court”) in Fuzhou, China against Fujian Enterprises (Holdings) Co., Ltd. (“FEHC”), Jian An Investment Limited (“Jian”), and Casix, Inc. (“Casix”), the Company's wholly-owned subsidiary located in the PRC. The complaint alleges unjust enrichment related to a purported investment in Casix by the Plaintiffs in 1997, which predates the Company's acquisition of Casix from JDS Uniphase Corporation. The Plaintiffs have requested that the Court

[0001408710-25-000056:notes:160]
order FEHC to return the unjust enrichment to the Plaintiffs in the amount of RMB 400 million, with interest from March 1, 2000, and order Jian and Casix to bear joint and several liability for all payment obligations of FEHC.

[0001408710-25-000056:notes:161]
In September 2024, the Court dismissed the lawsuit in its entirety based on jurisdictional grounds. The Plaintiffs have since appealed the Court’s ruling to the High People's Court of Fujian Province (the "Appellate Court"). In their appeal, the Plaintiffs now claim that Casix is the primary obligor to return the alleged unjust enrichment to the Plaintiffs. On November 24, 2024, the Appellate Court agreed to hear the appeal. At this time, the Company is not able to quantify any potential liability in connection with this litigation because of the early stage of this litigation.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001408710-25-000056:notes:162]
Restructuring and other related costs
The Company recognizes severance-related charges depending on whether the termination benefits are provided under an ongoing benefit arrangement or under a one-time benefit arrangement. The Company recognizes the charges once the benefits have been communicated to employees.

[0001408710-25-000056:notes:163]
As of September 26, 2025, there was no restructuring liability balance.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001408710-25-000056:notes:164]
Business segments and geographic information
The Company manages its business activities on a consolidated basis and operates as a single operating segment. The Company’s chief operating decision maker (“CODM”) is Fabrinet’s Chief Executive Officer.

[0001408710-25-000056:notes:165]
The CODM utilizes GAAP and non-GAAP measures of profit and loss to evaluate the Company’s financial performance, allocate resources, make key operating decisions, and compare actual results to forecasts. The CODM reviews and utilizes functional expenses (cost of revenue, and selling, general and administrative expenses) at the consolidated level to manage the Company’s operations. Other items included in GAAP and non-GAAP net income are interest income, other income (expense), net and income tax expense, which are reflected in the consolidated statements of operations and comprehensive income. The measure of segment assets is reported on the consolidated balance sheets as total assets, although the CODM does not evaluate asset information for purposes of allocating resources or evaluating performance.

[0001408710-25-000056:notes:166]
The following table provides information about the Company's revenue, significant segment expenses and other segment expenses:

[0001408710-25-000056:notes:167]
|  |  |  | Three Months Ended |
| (in thousands of U.S. dollars, except per share data) |  |  |  |  | September 26,2025 |  | September 27,2024 |
| Revenues |  |  |  |  | $ | 978,128 |  |  | $ | 804,228 |  |
| Cost of revenues |  |  |  |  | (861,689) |  |  | (705,202) |  |
| Gross profit |  |  |  |  | 116,439 |  |  | 99,026 |  |
| Selling, general and administrative expenses |  |  |  |  | (22,246) |  |  | (22,031) |  |
| Restructuring and other related costs |  |  |  |  | — |  |  | (57) |  |
| Operating income |  |  |  |  | 94,193 |  |  | 76,938 |  |
| Interest income |  |  |  |  | 9,417 |  |  | 10,933 |  |
| Foreign exchange gain (loss), net |  |  |  |  | (2,060) |  |  | (7,095) |  |
| Other income (expense), net |  |  |  |  | (122) |  |  | (19) |  |
| Income before income taxes |  |  |  |  | 101,428 |  |  | 80,757 |  |
| Income tax expense |  |  |  |  | (5,502) |  |  | (3,363) |  |
| Net income |  |  |  |  | $ | 95,926 |  |  | $ | 77,394 |  |

[0001408710-25-000056:notes:168]
[same as prior period, unchanged from 0001408710-25-000023:notes:163]

[0001408710-25-000056:notes:169]
[same as prior period, unchanged from 0001408710-25-000023:notes:164]

[0001408710-25-000056:notes:170]
| (in thousands) |  | September 26,2025 |  | June 27,2025 |
| Long-Lived Assets: |  |  |  |  |
| Thailand |  | $ | 376,458 |  |  | $ | 338,127 |  |
| U.S. |  | 31,218 |  |  | 30,374 |  |
| China |  | 13,862 |  |  | 14,378 |  |
| Israel |  | 2,520 |  |  | 2,727 |  |
| Others |  | 686 |  |  | 802 |  |
| Total |  | $ | 424,744 |  |  | $ | 386,408 |  |

[0001408710-25-000056:notes:171]
[same as prior period, unchanged from 0001408710-25-000023:notes:166]

[0001408710-25-000056:notes:172]
The Company had three customers that each contributed to 10% or more of the Company's total trade accounts receivable as of September 26, 2025 and June 27, 2025 for both periods.

[0001408710-25-000056:notes:173]
During the three months ended September 26, 2025 and September 27, 2024, the Company had three customers and two customers, respectively, that each contributed 10% or more of the Company's revenues. Such customers together accounted for 51.5% and 52.6% of the Company revenues during the respective periods.
