# FN note change history — 0001193125-18-319643 → 0001193125-19-028336


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-02-05):
[0001193125-19-028336:note_history:1]
| 16. | Commitments and contingencies |
  (was, 2018-11-06, similarity 0.9118):
[0001193125-18-319643:note_history:1]
17. Commitments and contingencies

- added (2019-02-05):
[0001193125-19-028336:note_history:2]
As of December 28, 2018 and June 29, 2018, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business amounting to $1.5 million.

- changed (2019-02-05):
[0001193125-19-028336:note_history:3]
The Company leases a portion of its capital equipment, vehicles, and certain land and buildings for its facilities in Thailand, Cayman Islands, China, the United States and the United Kingdom under operating lease arrangements that expire in various years through 2023. Rental expense under these operating leases amounted to $0.9 million and $0.9 million for the six months ended December 28, 2018 and December 29, 2017, respectively.
  (was, 2018-11-06, similarity 0.9402):
[0001193125-18-319643:note_history:3]
The Company leases a portion of its capital equipment, vehicles,
 and certain land and buildings for its facilities in Thailand,
 Cayman Islands, China, the United States and the United Kingdom
 under operating lease arrangements that expire in various years
 through 2023. Rental expense under these operating leases amounted
 to $0.5 million and $0.5 million for the three months
 ended September 28, 2018 and September 29, 2017,
 respectively.

- changed (2019-02-05):
[0001193125-19-028336:note_history:4]
As of December 28, 2018, the future minimum lease payments due under 
non-cancelable
 operating leases during each fiscal year were as follows:
  (was, 2018-11-06, similarity 0.9815):
[0001193125-18-319643:note_history:4]
As of September 28, 2018, the future minimum lease payments
 due under non-cancelable
 operating leases during each fiscal year were as follows:

- changed (2019-02-05):
[0001193125-19-028336:note_history:5]
| (amount in thousands) |  |  |  |
| 2019 (remaining six months) |  | $ | 905 |  |
| 2020 |  |  | 1,724 |  |
| 2021 |  |  | 1,322 |  |
| 2022 |  |  | 1,194 |  |
| 2023 |  |  | 1,168 |  |
| Thereafter |  |  | 225 |  |
| Total minimum operating lease payments |  | $ | 6,538 |  |
  (was, 2018-11-06, similarity 0.9838):
[0001193125-18-319643:note_history:5]
| (amount in thousands) |  |  |  |
| 2019 (remaining nine months) |  | $ | 1,396 |  |
| 2020 |  |  | 1,721 |  |
| 2021 |  |  | 1,320 |  |
| 2022 |  |  | 1,204 |  |
| 2023 |  |  | 1,195 |  |
| Thereafter |  |  | 230 |  |
| Total minimum operating lease payments |  | $ | 7,066 |  |

- changed (2019-02-05):
[0001193125-19-028336:note_history:6]
As of December 28, 2018, the future minimum lease payments due under non-cancelable capital leases during each fiscal year were as follows:
  (was, 2018-11-06, similarity 0.9813):
[0001193125-18-319643:note_history:6]
As of September 28, 2018, the future minimum lease payments
 due under non-cancelable
 capital leases during each fiscal year were as follows:

- changed (2019-02-05):
[0001193125-19-028336:note_history:7]
| (amount in thousands) |  |  |  |
| 2019 (remaining six months) |  | $ | 212 |  |
| 2020 |  |  | 397 |  |
| 2021 |  |  | 102 |  |
| Total minimum capital lease payments |  | $ | 711 |  |
  (was, 2018-11-06, similarity 0.9366):
[0001193125-18-319643:note_history:7]
| (amount in thousands) |  |  |  |
| 2019 (remaining nine months) |  | $ | 333 |  |
| 2020 |  |  | 410 |  |
| 2021 |  |  | 105 |  |
| 2022 |  |  | — |  |
| Total minimum capital lease payments |  | $ | 848 |  |

- changed (2019-02-05):
[0001193125-19-028336:note_history:8]
As of December 28, 2018, the Company had an outstanding commitment to third parties of $4.6 million.
  (was, 2018-11-06, similarity 0.973):
[0001193125-18-319643:note_history:8]
As of September 28, 2018, the Company had an outstanding
 commitment to third parties of $4.9 million.

- removed (2019-02-05):
[0001193125-18-319643:note_history:9]
As of September 28, 2018 and June 29, 2018, there were
 outstanding bank guarantees given by a bank on behalf of our
 subsidiary in Thailand for electricity usage and other normal
 business amounting to $1.5 million.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-02-05):
[0001193125-19-028336:note_history:10]
The accompanying condensed consolidated financial statements for Fabrinet as of December 28, 2018 and for the three and six months ended December 28, 2018 and December 29, 2017 includes normal recurring adjustments, necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 
10-K
 for the year ended June 29, 2018.
  (was, 2018-11-06, similarity 0.9602):
[0001193125-18-319643:note_history:10]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of September 28, 2018 and for the
 three months ended September 28, 2018 and September 29,
 2017 includes normal recurring adjustments, necessary for a fair
 statement of the financial statements set forth herein, in
 accordance with accounting principles generally accepted in the
 United States of America (“U.S. GAAP”) for interim
 financial information and the rules and regulations of the
 Securities and Exchange Commission (“SEC”).
 Accordingly, such information does not include all of the
 information and footnotes required by U.S. GAAP for annual
 financial statements. For further information, please refer to the
 consolidated financial statements and footnotes thereto included in
 Fabrinet’s Annual Report on
 Form 10-K for the year
 ended June 29, 2018.

- changed (2019-02-05):
[0001193125-19-028336:note_history:11]
The balance sheet as of June 29, 2018 has been derived from the audited financial statements at that date but does not include all of the information and footnotes required by U.S. GAAP for complete financial statements. The results for the three and six months ended December 28, 2018 may not be indicative of results for the year ending June 28, 2019 or any future periods.
  (was, 2018-11-06, similarity 0.9425):
[0001193125-18-319643:note_history:11]
The balance sheet as of June 29, 2018 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three months
 ended September 28, 2018 may not be indicative of results for
 the year ending June 28, 2019 or any future periods.

- changed (2019-02-05):
[0001193125-19-028336:note_history:12]
The preparation of the Company’s condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements, and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that estimates or assumptions prove to differ from actual results, adjustments will be made in subsequent periods to reflect more current information.
  (was, 2018-11-06, similarity 0.9963):
[0001193125-18-319643:note_history:12]
The preparation of the Company’s unaudited condensed
 consolidated financial statements in conformity with U.S. GAAP
 requires management to make estimates and assumptions that affect
 the reported amounts of assets and liabilities and disclosure of
 contingent liabilities at the date of the financial statements, and
 the reported amount of total revenues and expenses during the year.
 The Company bases estimates on historical experience and various
 assumptions about the future that are believed to be reasonable
 based on available information. The Company’s reported
 financial position or results of operations may be materially
 different under different conditions or when using different
 estimates and assumptions, particularly with respect to significant
 accounting policies, which are discussed below. Significant
 assumptions are used in accounting for share-based compensation,
 allowance for doubtful accounts, income taxes, inventory
 obsolescence, goodwill and valuation of intangible assets related
 to business acquisition, among others. Due to the inherent
 uncertainty involved in making estimates, actual results reported
 in future periods may be different from these estimates. In the
 event that estimates or assumptions prove to differ from actual
 results, adjustments will be made in subsequent periods to reflect
 more current information.

- changed (2019-02-05):
[0001193125-19-028336:note_history:13]
The Company utilizes a 
52-53
 week fiscal year ending on the Friday in June closest to June 30. The three months ended December 28, 2018 and December 29, 2017 each consisted of 13 weeks. The six months ended December 28, 2018 and December 29, 2017 each consisted of 26 weeks. Fiscal year 2019 will be comprised of 52 weeks and will end on June 28, 2019.
  (was, 2018-11-06, similarity 0.7374):
[0001193125-18-319643:note_history:13]
The Company utilizes a 52-53 week fiscal
 year ending on the Friday in June closest to June 30. The three
 months ended September 28, 2018 and September 29, 2017
 each consisted of 13 weeks. Fiscal year 2019 will be comprised of
 52 weeks and will end on June 28, 2019.

- changed (2019-02-05):
[0001193125-19-028336:note_history:14]
Except for the adoption of the new revenue recognition accounting standard described below and as disclosed in Note 3—Revenues, the Company has consistently applied the accounting policies to all periods presented in these condensed consolidated financial statements.
  (was, 2018-11-06, similarity 0.9981):
[0001193125-18-319643:note_history:14]
Except for the adoption of the new revenue recognition accounting
 standard described below and as disclosed in Note 3—Revenue,
 the Company has consistently applied the accounting policies to all
 periods presented in these condensed consolidated financial
 statements.

- changed (2019-02-05):
[0001193125-19-028336:note_history:15]
The cumulative effect adjustment recorded was based on the timing difference of revenue recognition between ASC 605 and ASC 606 related to certain manufacturing contracts with vendor-managed inventory arrangements. Under ASC 605, revenue for such contracts was recognized at the earlier of when the inventory was consumed by the customers or if not consumed, on the expiration of time specified in the contract. On adoption of ASC 606, revenue is recognized when inventory is shipped to the customers.
  (was, 2018-11-06, similarity 0.998):
[0001193125-18-319643:note_history:15]
The cumulative effect adjustment recorded was based on the timing
 difference of revenue recognition between ASC 605 and ASC 606
 related to certain manufacturing contracts with vendor managed
 inventory arrangements. Under ASC 605, revenue for such
 contracts was recognized at the earlier of when the inventory was
 consumed by the customers or if not consumed, on the expiration of
 time specified in the contract. On adoption of ASC 606, revenue is
 recognized when inventory is shipped to the customers.

- changed (2019-02-05):
[0001193125-19-028336:note_history:16]
The following table shows the impact of adoption of ASC 606 on adoption date of June 29, 2018 on the condensed consolidated balance sheets:
  (was, 2018-11-06, similarity 0.9635):
[0001193125-18-319643:note_history:16]
The following table shows the impact of adoption of ASC 606 on
 adoption date of June 29, 2018 on the unaudited condensed
 consolidated balance sheets:

- changed (2019-02-05):
[0001193125-19-028336:note_history:17]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | Balance atJune 29, 2018 |  |  | Adjustment |  |  | Balance atJune 30, 2018 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract assets |  | $ | — |  |  | $ | 9,877 | (1) |  | $ | 9,877 |  |
| Inventory, net |  | $ | 257,687 |  |  | $ | (8,672 | )(2) |  | $ | 249,015 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 632,423 |  |  | $ | 1,205 | (3) |  | $ | 633,628 |  |
  (was, 2018-11-06, similarity 0.9976):
[0001193125-18-319643:note_history:17]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | Balance at June 29, 2018 |  |  | Adjustment |  |  | Balance at June 30, 2018 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract assets |  | $ | — |  |  | $ | 9,877 | (1) |  | $ | 9,877 |  |
| Inventory, net |  | $ | 257,687 |  |  | $ | (8,672 | )(2) |  | $ | 249,015 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 632,423 |  |  | $ | 1,205 | (3) |  | $ | 633,628 |  |

- changed (2019-02-05):
[0001193125-19-028336:note_history:18]
| (1) | Majority of adjustment relates to certain manufacturing contracts with vendor-managed inventory arrangements for which revenue was recognized on shipment. |
  (was, 2018-11-06, similarity 0.9939):
[0001193125-18-319643:note_history:18]
| (1) | Majority of adjustment relates to certain manufacturing contracts with vendor managed inventory arrangements for which revenue was recognized on shipment. |

- changed (2019-02-05):
[0001193125-19-028336:note_history:19]
| (2) | Adjustment relates to reduction of finished goods inventory for certain vendor-managed inventory arrangements. |
  (was, 2018-11-06, similarity 0.9917):
[0001193125-18-319643:note_history:19]
| (2) | Adjustment relates to reduction of finished goods inventory for certain vendor managed inventory arrangements. |

- changed (2019-02-05):
[0001193125-19-028336:note_history:20]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash and cash equivalents, short-term investments, derivatives, accounts receivable and contract assets.
  (was, 2018-11-06, similarity 0.9056):
[0001193125-18-319643:note_history:20]
Financial instruments that potentially subject the Company to
 concentrations of credit risk consist of cash and cash equivalents,
 marketable securities, derivatives, accounts receivable and
 contract assets.

- added (2019-02-05):
[0001193125-19-028336:note_history:21]
Cash, cash equivalents, and short-term investments are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. The Company seeks to mitigate its credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties. The Company limits its investments in short-term investments to term deposits and marketable securities to securities with a maturity not in excess of three years, and all marketable securities that the Company invests in are rated A1, 
P-1,
 F1, or better.

- changed (2019-02-05):
[0001193125-19-028336:note_history:22]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued ASU 
2018-13,
 “Fair Value Measurement (Topic 820), Disclosure Framework – Changes to the Disclosure Requirements for Fair Value Measurement." This ASU is intended to improve the effectiveness of disclosures in the notes to the financial statements including 1) the development of a framework that promotes consistent decisions by the Board about disclosure requirements and 2) the appropriate exercise of discretion by reporting entities. The amendment modifies the disclosure requirements on transferring between level 1 and level 2 and valuation processes of level 3 fair value measurements. The amendments in this update are effective for all entities for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company is currently evaluating the impact of the adoption of this update on its consolidated financial statements.
  (was, 2018-11-06, similarity 0.9995):
[0001193125-18-319643:note_history:22]
In August 2018, the Financial Accounting Standards Board
 (“FASB”) issued ASU 2018-13, “Fair
 Value Measurement (Topic 820), Disclosure Framework – Changes
 to the Disclosure Requirements for Fair Value Measurement. This ASU
 is intended to improve the effectiveness of disclosures in the
 notes to the financial statements including 1) the development of a
 framework that promotes consistent decisions by the Board about
 disclosure requirements and 2) the appropriate exercise of
 discretion by reporting entities. The amendment modifies the
 disclosure requirements on transferring between level 1 and level 2
 and valuation processes of level 3 fair value measurements. The
 amendments in this update are effective for all entities for fiscal
 years, and interim periods within those fiscal years, beginning
 after December 15, 2019. The Company is currently evaluating
 the impact of the adoption of this update on its consolidated
 financial statements.

- removed (2019-02-05):
[0001193125-18-319643:note_history:23]
Cash, cash equivalents, and marketable securities are maintained
 with several financial institutions. Deposits held with banks may
 exceed the amount of insurance provided on such deposits.
 Generally, these deposits may be redeemed upon demand and are
 maintained with financial institutions with reputable credit and
 therefore bear minimal credit risk. The Company seeks to mitigate
 its credit risks by spreading such risks across multiple
 counterparties and monitoring the risk profiles of these
 counterparties. The Company limits its investments in marketable
 securities to securities with a maturity not in excess of three
 years, and all marketable securities that the Company invests in
 are rated A1, P-1, F1, or
 better.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-02-05):
[0001193125-19-028336:note_history:24]
| Rate (1) |  | Conditions |  | Maturity |  |  | As ofDecember 28,2018 |  |  | As ofJune 29,2018 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |
| Current portion of long-term borrowing |  |  | $ | 3,250 |  |  | $ | 3,250 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.50% per annum |  | Repayable in quarterly installments |  |  | June 2023 |  |  | $ | 63,375 |  |  | $ | 64,188 |  |
|  |  |  |  |  |  |  |  |  | 63,375 |  |  |  | 64,188 |  |
| Less: Current portion |  |  |  |  |  |  |  |  | (3,250 | ) |  |  | (3,250 | ) |
| Non-current portion of long-term borrowings |  |  |  |  |  |  |  | $ | 60,125 |  |  | $ | 60,938 |  |

- changed (2019-02-05):
[0001193125-19-028336:note_history:25]
The movements of long-term borrowings for the six months ended December 28, 2018 and December 29, 2017 were as follows:
  (was, 2018-11-06, similarity 0.9189):
[0001193125-18-319643:note_history:25]
The movements of long-term borrowings for the three months ended
 September 28, 2018 and September 29, 2017 were as
 follows:

- changed (2019-02-05):
[0001193125-19-028336:note_history:26]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 28,2018 |  |  | December 29,2017 |  |
| Opening balance |  | $ | 64,188 |  |  | $ | 36,400 |  |
| Repayments during the period |  |  | (813 | ) |  |  | (6,800 | ) |
| Closing balance |  | $ | 63,375 |  |  | $ | 29,600 |  |
  (was, 2018-11-06, similarity 0.865):
[0001193125-18-319643:note_history:26]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 28, 2018 |  |  | September 29, 2017 |  |
| Opening balance |  | $ | 64,188 |  |  | $ | 36,400 |  |
| Repayments during the period |  |  | (813 | ) |  |  | (3,400 | ) |
| Closing balance |  | $ | 63,375 |  |  | $ | 33,000 |  |

- changed (2019-02-05):
[0001193125-19-028336:note_history:27]
As of December 28, 2018, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2018-11-06, similarity 0.9754):
[0001193125-18-319643:note_history:27]
As of September 28, 2018, future maturities of long-term
 borrowings during each fiscal year were as follows:

- changed (2019-02-05):
[0001193125-19-028336:note_history:28]
| (amount in thousands) |  |  |  |
| 2019 (remaining six months) |  | $ | 2,438 |  |
| 2020 |  |  | 3,250 |  |
| 2021 |  |  | 3,250 |  |
| 2022 |  |  | 3,250 |  |
| 2023 |  |  | 51,187 |  |
| Total |  | $ | 63,375 |  |
  (was, 2018-11-06, similarity 0.9781):
[0001193125-18-319643:note_history:28]
| (amount in thousands) |  |  |  |  |
| 2019 (remaining nine months) |  | $ | 2,438 |  |
| 2020 |  |  | 3,250 |  |
| 2021 |  |  | 3,250 |  |
| 2022 |  |  | 3,250 |  |
| 2023 |  |  | 51,187 |  |
| Total |  | $ | 63,375 |  |

- changed (2019-02-05):
[0001193125-19-028336:note_history:29]
On June 4, 2018, the Company entered into the Fifth Amendment to the Facility Agreement to (i) reduce the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) extend the termination date of the revolving commitments from May 22, 2019 to June 4, 2023, (iii) refinance the then-existing term loan and revolving loans under the Facility Agreement into a $65.0 million term loan and (iv) reduce the applicable interest rate margins and commitment fees. Term loans must be repaid in quarterly installments, beginning on June 30, 2018, with the remaining outstanding principal and accrued and unpaid interest being due and payable on June 4, 2023. After giving effect to the amendment, $65.0 million aggregate principal amount of term loans and no revolving loans were outstanding under the Facility Agreement as of June 28, 2018. In addition, the Fifth Amendment to the Facility Agreement contains an accordion feature permitting the Company to request an increase in the revolving loan facility to provide up to an aggregate of $200.0 million in additional commitments, subject to customary terms and conditions, and provided that no default or event of default exists at the time of such request. The Fifth Amendment is considered debt extinguishment of which the Company recognized interest expenses of $0.1 million from remaining unamortized debt issuance costs in consolidated statements of operations and comprehensive income. As of December 28, 2018 and June 29, 2018, $63.4 million and $64.2 million aggregate principal amount of term loans and no revolving loans were outstanding under the Facility Agreement.
  (was, 2018-11-06, similarity 0.9978):
[0001193125-18-319643:note_history:29]
On June 4, 2018, the Company entered into the Fifth Amendment
 to the Facility Agreement to (i) reduce the revolving
 commitments thereunder from $150.0 million to
 $25.0 million, (ii) extend the termination date of the
 revolving commitments from May 22, 2019 to June 4, 2023,
 (iii) refinance the then-existing term loan and revolving loans
 under the Facility Agreement into a $65.0 million term loan
 and (iv) reduce the applicable interest rate margins and
 commitment fees. Term loans must be repaid in quarterly
 installments, beginning on June 30, 2018, with the remaining
 outstanding principal and accrued and unpaid interest being due and
 payable on June 4, 2023. After giving effect to the amendment,
 $65.0 million aggregate principal amount of term loans and no
 revolving loans were outstanding under the Facility Agreement as of
 June 28, 2018. In addition, the Fifth Amendment to the
 Facility Agreement contains an accordion feature permitting the
 Company to request an increase in the revolving loan facility to
 provide up to an aggregate of $200.0 million in additional
 commitments, subject to customary terms and conditions, and
 provided that no default or event of default exists at the time of
 such request. The Fifth Amendment is considered debt extinguishment
 of which the Company recognized interest expenses of
 $0.1 million from remaining unamortized debt issuance costs in
 consolidated statements of operations and comprehensive income. As
 of September 28, 2018 and June 29, 2018,
 $63.4 million and $64.2 million aggregate principal
 amount of term loans and no revolving loans were outstanding under
 the Facility Agreement.

- changed (2019-02-05):
[0001193125-19-028336:note_history:30]
Moreover, the Fifth Amendment of Facility Agreement amends customary affirmative and negative covenants. Negative covenants include, among other things, limitations on liens, indebtedness, investments, mergers, sales of assets, changes in the nature of the business, dividends and distributions, affiliate transactions and capital expenditures. The Facility Agreement contains financial covenants requiring Fabrinet to maintain: (1) a minimum tangible net worth of not less than $338.0 million plus 50% of quarterly net income after June 30, 2018, exclusive of quarterly losses; (2) a minimum debt service coverage ratio of not less than 1.50:1.00; (3) a maximum total leverage ratio of not more than 2.50:1.00; and (4) a minimum quick ratio of not less than 1.10:1.00. Each of these financial covenants is calculated on a consolidated basis for the consecutive four fiscal quarter period then ended. As of December 28, 2018, the Company was in compliance with all covenants under the Facility Agreement.
  (was, 2018-11-06, similarity 0.9964):
[0001193125-18-319643:note_history:30]
Moreover, the Fifth Amendment of Facility Agreement amends
 customary affirmative and negative covenants. Negative covenants
 include, among other things, limitations on liens, indebtedness,
 investments, mergers, sales of assets, changes in the nature of the
 business, dividends and distributions, affiliate transactions and
 capital expenditures. The Facility Agreement contains financial
 covenants requiring Fabrinet to maintain: (1) a minimum
 tangible net worth of not less than $338.0 million plus 50% of
 quarterly net income after June 30, 2018, exclusive of
 quarterly losses; (2) a minimum debt service coverage ratio of
 not less than 1.50:1.00; (3) a maximum total leverage ratio of not
 more than 2.50:1.00; and (4) a minimum quick ratio of not less
 than 1.10:1.00. Each of these financial covenants is calculated on
 a consolidated basis for the consecutive four fiscal quarter period
 then ended. As of September 28, 2018, the Company was in
 compliance with all covenants under the Facility Agreement.

- changed (2019-02-05):
[0001193125-19-028336:note_history:31]
On July 25, 2018, the Company entered into the Swap Agreement, which the Company did not designate as a hedging instrument. The Swap Agreement was used to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. The terms of the Swap Agreement effectively convert the floating interest rate of the term loans under the Facility Agreement to the fixed interest rate of 2.86% per annum through maturity in June 2023. The swap transactions are due and settled monthly.
  (was, 2018-11-06, similarity 0.7546):
[0001193125-18-319643:note_history:31]
On July 25, 2018, the Company entered into Swap Agreement,
 which the Company did not designate as hedging instruments. The
 Swap Agreement was used to mitigate interest rate risk and improve
 the interest rate profile of the Company’s debt obligations.
 The terms of the Swap Agreement effectively converted the floating
 interest rate of the term loans under the Facility Agreement to the
 fixed interest rate of 2.86% per annum through maturity of the term
 loan in June 2023. The swap transactions are due and settled
 monthly. During the three months ended September 28, 2018, the
 Company included a net loss of $33 thousand from the
 settlement of the Swap Agreement as interest expenses in the
 unaudited condensed consolidated statements of operations and
 comprehensive income.

- changed (2019-02-05):
[0001193125-19-028336:note_history:32]
Undrawn available credit facilities classified by availability period of future borrowing as of December 28, 2018 and June 29, 2018 were as follows:
  (was, 2018-11-06, similarity 0.9819):
[0001193125-18-319643:note_history:32]
Undrawn available credit facilities classified by availability
 period of future borrowing as of September 28, 2018 and
 June 29, 2018 were as follows:

- changed (2019-02-05):
[0001193125-19-028336:note_history:33]
| (amount in thousands) |  | December 28,2018 |  |  | June 29,2018 |  |
| Expiring within one year |  | $ | — |  |  | $ | — |  |
| Expiring beyond one year |  | $ | 25,000 |  |  | $ | 25,000 |  |
  (was, 2018-11-06, similarity 0.9725):
[0001193125-18-319643:note_history:33]
| (amount in thousands) |  | September 28, 2018 |  |  | June 29, 2018 |  |
| Expiring within one year |  | $ | — |  |  | $ | — |  |
| Expiring beyond one year |  | $ | 25,000 |  |  | $ | 25,000 |  |

- removed (2019-02-05):
[0001193125-18-319643:note_history:34]
| Rate (1) |  | Conditions |  |  | Maturity |  |  | As of September 28, 2018 |  |  | As of June 29, 2018 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current portion of long-term borrowing |  |  | $ | 3,250 |  |  | $ | 3,250 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.50% per annum |  |  | Repayable in quarterly installments |  |  |  | June 2023 |  |  | $ | 63,375 |  |  | $ | 64,188 |  |
|  |  |  |  |  |  |  |  |  |  |  | 63,375 |  |  |  | 64,188 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (3,250 | ) |  |  | (3,250 | ) |
| Non-current portion of long-term borrowings |  |  |  |  |  |  |  |  |  | $ | 60,125 |  |  | $ | 60,938 |  |

- removed (2019-02-05):
[0001193125-18-319643:note_history:35]
On July 24, 2017, the Company entered into an interest rate
 swap agreement (the “Swap Agreement”), which the
 Company did not designate as hedging instruments. The Swap
 Agreement was used to mitigate interest rate risk and improve the
 interest rate profile of the Company’s debt obligations. The
 terms of the Swap Agreement effectively converted the floating
 interest rate of the term loans under the Facility Agreement to the
 fixed interest rate of 1.55% per annum through maturity of the term
 loan in May 2019. On June 4, 2018, the Company terminated the
 Swap Agreement in connection with entering into the Fifth Amendment
 to the Facility Agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-05):
[0001193125-19-028336:note_history:36]
The movements of long-term borrowings for the six months ended December 28, 2018 and December 29, 2017 were as follows:
  (was, 2018-11-06, similarity 0.9189):
[0001193125-18-319643:note_history:36]
The movements of long-term borrowings for the three months ended
 September 28, 2018 and September 29, 2017 were as
 follows:

- changed (2019-02-05):
[0001193125-19-028336:note_history:37]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 28,2018 |  |  | December 29,2017 |  |
| Opening balance |  | $ | 64,188 |  |  | $ | 36,400 |  |
| Repayments during the period |  |  | (813 | ) |  |  | (6,800 | ) |
| Closing balance |  | $ | 63,375 |  |  | $ | 29,600 |  |
  (was, 2018-11-06, similarity 0.865):
[0001193125-18-319643:note_history:37]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 28, 2018 |  |  | September 29, 2017 |  |
| Opening balance |  | $ | 64,188 |  |  | $ | 36,400 |  |
| Repayments during the period |  |  | (813 | ) |  |  | (3,400 | ) |
| Closing balance |  | $ | 63,375 |  |  | $ | 33,000 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-02-05):
[0001193125-19-028336:note_history:38]
| Rate (1) |  | Conditions |  | Maturity |  |  | As ofDecember 28,2018 |  |  | As ofJune 29,2018 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |
| Current portion of long-term borrowing |  |  | $ | 3,250 |  |  | $ | 3,250 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.50% per annum |  | Repayable in quarterly installments |  |  | June 2023 |  |  | $ | 63,375 |  |  | $ | 64,188 |  |
|  |  |  |  |  |  |  |  |  | 63,375 |  |  |  | 64,188 |  |
| Less: Current portion |  |  |  |  |  |  |  |  | (3,250 | ) |  |  | (3,250 | ) |
| Non-current portion of long-term borrowings |  |  |  |  |  |  |  | $ | 60,125 |  |  | $ | 60,938 |  |

- removed (2019-02-05):
[0001193125-18-319643:note_history:39]
| Rate (1) |  | Conditions |  |  | Maturity |  |  | As of September 28, 2018 |  |  | As of June 29, 2018 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current portion of long-term borrowing |  |  | $ | 3,250 |  |  | $ | 3,250 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.50% per annum |  |  | Repayable in quarterly installments |  |  |  | June 2023 |  |  | $ | 63,375 |  |  | $ | 64,188 |  |
|  |  |  |  |  |  |  |  |  |  |  | 63,375 |  |  |  | 64,188 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (3,250 | ) |  |  | (3,250 | ) |
| Non-current portion of long-term borrowings |  |  |  |  |  |  |  |  |  | $ | 60,125 |  |  | $ | 60,938 |  |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-05):
[0001193125-19-028336:note_history:40]
Undrawn available credit facilities classified by availability period of future borrowing as of December 28, 2018 and June 29, 2018 were as follows:
  (was, 2018-11-06, similarity 0.9819):
[0001193125-18-319643:note_history:40]
Undrawn available credit facilities classified by availability
 period of future borrowing as of September 28, 2018 and
 June 29, 2018 were as follows:

- changed (2019-02-05):
[0001193125-19-028336:note_history:41]
| (amount in thousands) |  | December 28,2018 |  |  | June 29,2018 |  |
| Expiring within one year |  | $ | — |  |  | $ | — |  |
| Expiring beyond one year |  | $ | 25,000 |  |  | $ | 25,000 |  |
  (was, 2018-11-06, similarity 0.9725):
[0001193125-18-319643:note_history:41]
| (amount in thousands) |  | September 28, 2018 |  |  | June 29, 2018 |  |
| Expiring within one year |  | $ | — |  |  | $ | — |  |
| Expiring beyond one year |  | $ | 25,000 |  |  | $ | 25,000 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-02-05):
[0001193125-19-028336:note_history:42]
As of December 28, 2018, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2018-11-06, similarity 0.9754):
[0001193125-18-319643:note_history:42]
As of September 28, 2018, future maturities of long-term
 borrowings during each fiscal year were as follows:

- changed (2019-02-05):
[0001193125-19-028336:note_history:43]
| (amount in thousands) |  |  |  |
| 2019 (remaining six months) |  | $ | 2,438 |  |
| 2020 |  |  | 3,250 |  |
| 2021 |  |  | 3,250 |  |
| 2022 |  |  | 3,250 |  |
| 2023 |  |  | 51,187 |  |
| Total |  | $ | 63,375 |  |
  (was, 2018-11-06, similarity 0.9781):
[0001193125-18-319643:note_history:43]
| (amount in thousands) |  |  |  |  |
| 2019 (remaining nine months) |  | $ | 2,438 |  |
| 2020 |  |  | 3,250 |  |
| 2021 |  |  | 3,250 |  |
| 2022 |  |  | 3,250 |  |
| 2023 |  |  | 51,187 |  |
| Total |  | $ | 63,375 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-02-05):
[0001193125-19-028336:note_history:44]
| (amount in thousands) |  | Three MonthsEndedDecember 28,2018 |  |  | As a % of TotalRevenues |  |  | Six MonthsEndedDecember 28,2018 |  |  | As a % of TotalRevenues |  |
| North America |  | $ | 182,698 |  |  |  | 45.3 | % |  | $ | 362,524 |  |  |  | 46.5 | % |
| Asia-Pacific |  |  | 166,711 |  |  |  | 41.4 |  |  |  | 318,658 |  |  |  | 40.8 |  |
| Europe |  |  | 53,671 |  |  |  | 13.3 |  |  |  | 99,075 |  |  |  | 12.7 |  |
|  |  | $ | 403,080 |  |  |  | 100.0 | % |  | $ | 780,257 |  |  |  | 100.0 | % |

- removed (2019-02-05):
[0001193125-18-319643:note_history:45]
| (amount in thousands) |  | Three Months Ended September 28, 2018 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 179,826 |  |  |  | 47.7 | % |
| Asia-Pacific |  |  | 151,947 |  |  |  | 40.3 |  |
| Europe |  |  | 45,404 |  |  |  | 12.0 |  |
|  |  | $ | 377,177 |  |  |  | 100.0 | % |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-02-05):
[0001193125-19-028336:note_history:46]
The Company manufactures products that are customized to customers’ specifications, however, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for overtime recognition are not met. On the evaluation of the contracts, the Company identified that it did not have contractual rights to bill profit for work in progress in the event of a contract termination which is expected to be infrequent. Further, in limited circumstances, substantive acceptance by the customer exists which results in the deferral of revenue until acceptance is formally received from the customer. Judgment may be required in determining if the acceptance clause is substantive.
  (was, 2018-11-06, similarity 0.9994):
[0001193125-18-319643:note_history:46]
The Company manufactures products that are customized to
 customers’ specifications, however, control of the products
 is typically transferred to the customer at the point in time the
 product is either shipped or delivered, depending on the terms of
 the arrangement, as the criteria for overtime recognition are not
 met. On the evaluation of the contracts the Company identified that
 it did not have contractual rights to bill profit for work in
 progress in the event of a contract termination which is expected
 to be infrequent. Further, in limited circumstances,
 substantive acceptance by the customer exists which results in the
 deferral of revenue until acceptance is formally received from the
 customer. Judgment may be required in determining if the acceptance
 clause is substantive.

- changed (2019-02-05):
[0001193125-19-028336:note_history:47]
Customers generally are obligated to purchase finished goods that the Company has manufactured according to their demand requirements. Materials that are not consumed by customers within a specified period of time, or are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under the Company’s contracts. Once materials are designated as either excess or obsolete inventory, customers are typically required to purchase such inventory from the Company even if the customer has chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.
  (was, 2018-11-06, similarity 0.9233):
[0001193125-18-319643:note_history:47]
Our customers generally are obligated to purchase finished goods
 that we have manufactured according to their demand requirements.
 Materials that are not consumed by our customers within a specified
 period of time, or are no longer required due to a product’s
 cancellation or end-of-life, are typically
 designated as excess or obsolete inventory under our contracts.
 Once materials are designated as either excess or obsolete
 inventory, our customers are typically required to purchase such
 inventory from us even if they have chosen to cancel production of
 the related products. The excess or obsolete inventory is shipped
 to the customer and revenue is recognized upon shipment.

- changed (2019-02-05):
[0001193125-19-028336:note_history:48]
A contract asset is recognized when the Company has recognized revenues, but not yet an invoice for payment. Contract assets are classified separately on the condensed consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. The following table summarizes the activity in the Company’s contract assets during the 
six-month
 period ended December 28, 2018:
  (was, 2018-11-06, similarity 0.9815):
[0001193125-18-319643:note_history:48]
A contract asset is recognized when the Company has recognized
 revenues, but not yet an invoice for payment. Contract assets are
 classified separately on the condensed consolidated balance sheets
 and transferred to accounts receivable when rights to payment
 become unconditional. The following table summarizes the activity
 in the Company’s contract assets during the three-month
 period ended September 29, 2018:

- changed (2019-02-05):
[0001193125-19-028336:note_history:49]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 30, 2018 |  | $ | — |  |
| Cumulative effect adjustment at June 30, 2018 |  |  | 9,877 |  |
| Revenue recognized |  |  | 58,484 |  |
| Amounts collected or invoiced |  |  | (55,025 | ) |
| Ending balance, December 28, 2018 |  | $ | 13,336 |  |
  (was, 2018-11-06, similarity 0.9871):
[0001193125-18-319643:note_history:49]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 30, 2018 |  | $ | — |  |
| Cumulative effect adjustment at June 30, 2018 |  |  | 9,877 |  |
| Revenue recognized |  |  | 27,954 |  |
| Amounts collected or invoiced |  |  | (27,674 | ) |
| Ending balance, September 28, 2018 |  | $ | 10,157 |  |

- changed (2019-02-05):
[0001193125-19-028336:note_history:50]
The Company continually evaluates whether advanced payment arrangements with customers result in the recognition of contract liabilities. No such liabilities existed as of December 28, 2018 or June 29, 2018. Separately, accounts receivable, net, represents receivables from contracts with customers.
  (was, 2018-11-06, similarity 0.9879):
[0001193125-18-319643:note_history:50]
The Company continually evaluates whether advanced payment
 arrangements with customers result in the recognition of contract
 liabilities. No such liabilities existed as of September 28,
 2018 or June 29, 2018. Separately, accounts receivable, net,
 represents receivables from contracts with customers.

- changed (2019-02-05):
[0001193125-19-028336:note_history:51]
The Company has elected the practical expedient to recognize the incremental costs of obtaining a contract as an expense when incurred if the amortization period of the asset that the Company otherwise would have recognized is one year or less. During the three and six months ended December 28, 2018, the Company did not have any incremental costs of obtaining a contract.
  (was, 2018-11-06, similarity 0.9383):
[0001193125-18-319643:note_history:51]
The Company has elected the practical expedient to recognize the
 incremental costs of obtaining a contract as an expense when
 incurred if the amortization period of the asset that the Company
 otherwise would have recognized is one year or less. During the
 three months ended September 28, 2018, the Company did not
 have any incremental costs of obtaining the contract.

- changed (2019-02-05):
[0001193125-19-028336:note_history:52]
In accordance with the new revenue standard requirements, the disclosure of the impact of adoption
 of ASC 606 
 on the Company’s condensed consolidated statements of operations and comprehensive income for the three and six months ended December 28, 2018 and condensed consolidated balance sheets as of December 28, 2018 was as follows:
  (was, 2018-11-06, similarity 0.8814):
[0001193125-18-319643:note_history:52]
In accordance with the new revenue standard requirements, the
 disclosure of the impact of adoption on the Company’s
 unaudited condensed consolidated statements of operations and
 comprehensive income for the three months ended September 28,
 2018 and unaudited condensed consolidated balance sheets as of
 September 28, 2018 was as follows:

- changed (2019-02-05):
[0001193125-19-028336:note_history:53]
Three and Six Months Ended December 28, 2018
  (was, 2018-11-06, similarity 0.8169):
[0001193125-18-319643:note_history:53]
Three Months Ended September 28, 2018

- added (2019-02-05):
[0001193125-19-028336:note_history:54]
|  |  | Impact of Adopting ASC 606 (Three months) |  |  | Impact of Adopting ASC 606 (Six months) |  |
| (amount in thousands) |  | As Reported |  |  | Adjustment |  |  | Balance without ASC606 Adoption |  |  | As Reported |  |  | Adjustment |  |  | Balance without ASC606 Adoption |  |
| Revenues |  | $ | 403,080 |  |  | $ | (3,179 | )(1) |  | $ | 399,901 |  |  | $ | 780,257 |  |  | $ | (3,459 | )(1) |  | $ | 776,798 |  |
| Cost of revenues |  | $ | (357,516 | ) |  | $ | 2,791 | (2) |  | $ | (354,725 | ) |  | $ | (694,417 | ) |  | $ | 3,040 | (2) |  | $ | (691,377 | ) |
| Gross profit |  | $ | 45,564 |  |  | $ | (388 | )(3) |  | $ | 45,176 |  |  | $ | 85,840 |  |  | $ | (419 | )(3) |  | $ | 85,421 |  |
| Net income |  | $ | 31,513 |  |  | $ | (388 | )(3) |  | $ | 31,125 |  |  | $ | 59,363 |  |  | $ | (419 | )(3) |  | $ | 58,944 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.86 |  |  | $ | (0.02 | ) |  | $ | (0.84 | ) |  | $ | 1.62 |  |  | $ | (0.02 | ) |  | $ | 1.60 |  |
| Diluted |  | $ | 0.84 |  |  | $ | (0.01 | ) |  | $ | (0.83 | ) |  | $ | 1.59 |  |  | $ | (0.01 | ) |  | $ | 1.58 |  |

- changed (2019-02-05):
[0001193125-19-028336:note_history:55]
| (1) | Adjustment relates to certain manufacturing contracts with vendor-managed inventory arrangements for which revenue was recognized at shipping. |
  (was, 2018-11-06, similarity 0.9934):
[0001193125-18-319643:note_history:55]
| (1) | Adjustment relates to certain manufacturing contracts with vendor managed inventory arrangements for which revenue was recognized at shipping. |

- changed (2019-02-05):
[0001193125-19-028336:note_history:56]
| (3) | Adjustment relates to net impact on net income upon adoption of ASC 606. |
  (was, 2018-11-06, similarity 0.974):
[0001193125-18-319643:note_history:56]
| (3) | Adjustment relates to net impact on income upon adoption of ASC 606. |

- changed (2019-02-05):
[0001193125-19-028336:note_history:57]
As of December 28, 2018
  (was, 2018-11-06, similarity 0.8649):
[0001193125-18-319643:note_history:57]
As of September 28, 2018

- changed (2019-02-05):
[0001193125-19-028336:note_history:58]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | As Reported |  |  | Adjustments |  |  | Balance withoutASC 606Adoption |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract assets |  | $ | 13,336 |  |  | $ | (13,336 | )(1) |  | $ | — |  |
| Inventory, net |  | $ | 277,893 |  |  | $ | 11,712 | (2) |  | $ | 289,605 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 692,991 |  |  | $ | (1,624 | )(3) |  | $ | 691,367 |  |
  (was, 2018-11-06, similarity 0.9856):
[0001193125-18-319643:note_history:58]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | As Reported |  |  | Adjustments |  |  | Balance without ASC 606 Adoption |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract assets |  | $ | 10,157 |  |  | $ | (10,157 | )(1) |  | $ | — |  |
| Inventory, net |  | $ | 278,397 |  |  | $ | 8,921 | (2) |  | $ | 287,318 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 661,478 |  |  | $ | (1,236 | )(3) |  | $ | 660,242 |  |

- changed (2019-02-05):
[0001193125-19-028336:note_history:59]
| (1) | Majority of adjustment relates to certain manufacturing contracts with vendor-managed inventory arrangements for which revenue was recognized on shipment. |
  (was, 2018-11-06, similarity 0.9939):
[0001193125-18-319643:note_history:59]
| (1) | Majority of adjustment relates to certain manufacturing contracts with vendor managed inventory arrangements for which revenue was recognized on shipment. |

- changed (2019-02-05):
[0001193125-19-028336:note_history:60]
| (2) | Adjustment relates to reduction of finished goods inventory for vendor-managed inventory. |
  (was, 2018-11-06, similarity 0.9899):
[0001193125-18-319643:note_history:60]
| (2) | Adjustment relates to reduction of finished goods inventory for vendor managed inventory. |

- changed (2019-02-05):
[0001193125-19-028336:note_history:61]
Revenue by Geographic Area
  (was, 2018-11-06, similarity 0.9811):
[0001193125-18-319643:note_history:61]
Revenue by Geographic Area:

- added (2019-02-05):
[0001193125-19-028336:note_history:62]
:

- added (2019-02-05):
[0001193125-19-028336:note_history:63]
Total revenues are attributed to a particular geographic area based on

- added (2019-02-05):
[0001193125-19-028336:note_history:64]
the bill-to-location of

- changed (2019-02-05):
[0001193125-19-028336:note_history:65]
the customers. The Company operates primarily in three geographic regions: North America, Asia-Pacific and Europe. The following table presents total revenues by geographic regions:
  (was, 2018-11-06, similarity 0.7921):
[0001193125-18-319643:note_history:65]
Total revenues are attributed to a particular geographic area based
 on the bill-to-location of
 the customers. The Company operates primarily in three geographic
 regions: North America, Asia-Pacific and Europe. The following
 table presents total revenues by geographic regions:

- added (2019-02-05):
[0001193125-19-028336:note_history:66]
| (amount in thousands) |  | Three MonthsEndedDecember 28,2018 |  |  | As a % of TotalRevenues |  |  | Six MonthsEndedDecember 28,2018 |  |  | As a % of TotalRevenues |  |
| North America |  | $ | 182,698 |  |  |  | 45.3 | % |  | $ | 362,524 |  |  |  | 46.5 | % |
| Asia-Pacific |  |  | 166,711 |  |  |  | 41.4 |  |  |  | 318,658 |  |  |  | 40.8 |  |
| Europe |  |  | 53,671 |  |  |  | 13.3 |  |  |  | 99,075 |  |  |  | 12.7 |  |
|  |  | $ | 403,080 |  |  |  | 100.0 | % |  | $ | 780,257 |  |  |  | 100.0 | % |

- changed (2019-02-05):
[0001193125-19-028336:note_history:67]
The following table sets forth revenues by end market.
  (was, 2018-11-06, similarity 0.9643):
[0001193125-18-319643:note_history:67]
The following table sets forth our revenues by end market.

- added (2019-02-05):
[0001193125-19-028336:note_history:68]
| (amount in thousands) |  | Three MonthsEndedDecember 28,2018 |  |  | As a % of TotalRevenues |  |  | Six MonthsEndedDecember 28,2018 |  |  | As a % of TotalRevenues |  |
| Optical communications |  | $ | 305,547 |  |  |  | 75.8 | % |  | $ | 586,315 |  |  |  | 75.1 | % |
| Lasers, sensors and other |  |  | 97,533 |  |  |  | 24.2 |  |  |  | 193,942 |  |  |  | 24.9 |  |
|  |  | $ | 403,080 |  |  |  | 100.0 | % |  | $ | 780,257 |  |  |  | 100.0 | % |

- removed (2019-02-05):
[0001193125-18-319643:note_history:69]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | As Reported |  |  | Adjustment |  |  | Balance without ASC 606 Adoption |  |
| Revenues |  | $ | 377,177 |  |  | $ | (280 | )(1) |  | $ | 376,897 |  |
| Cost of revenues |  | $ | (336,901 | ) |  | $ | 249 | (2) |  | $ | (336,652 | ) |
| Gross profit |  | $ | 40,276 |  |  | $ | (31 | )(3) |  | $ | 40,245 |  |
| Net income |  | $ | 27,850 |  |  | $ | (31 | )(3) |  | $ | 27,819 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.76 |  |  | $ | (0.00 | ) |  | $ | 0.76 |  |
| Diluted |  | $ | 0.75 |  |  | $ | (0.00 | ) |  | $ | 0.75 |  |

- removed (2019-02-05):
[0001193125-18-319643:note_history:70]
| (amount in thousands) |  | Three Months Ended September 28, 2018 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 179,826 |  |  |  | 47.7 | % |
| Asia-Pacific |  |  | 151,947 |  |  |  | 40.3 |  |
| Europe |  |  | 45,404 |  |  |  | 12.0 |  |
|  |  | $ | 377,177 |  |  |  | 100.0 | % |

- removed (2019-02-05):
[0001193125-18-319643:note_history:71]
| (amount in thousands) |  | Three Months Ended September 28, 2018 |  |  | As a % of Total Revenues |  |
| Optical communications |  | $ | 280,768 |  |  |  | 74.4 | % |
| Lasers, sensors and other |  |  | 96,409 |  |  |  | 25.6 |  |
| Total |  | $ | 377,177 |  |  |  | 100.0 | % |
