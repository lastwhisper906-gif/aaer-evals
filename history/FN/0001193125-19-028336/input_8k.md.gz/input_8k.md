# FN 8-K — 0001193125-19-027031 filed 2019-02-04

## item codes, every 8-K on or before 2019-02-05

- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2019-02-05

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-19-027031:8k_2_02:1]
EX-99.1
2
d702192dex991.htm
EX-99.1

[0001193125-19-027031:8k_2_02:2]
EX-99.1

[0001193125-19-027031:8k_2_02:3]
Exhibit 99.1

[0001193125-19-027031:8k_2_02:4]
Fabrinet Announces Second Quarter Fiscal Year 2019 Financial Results

[0001193125-19-027031:8k_2_02:5]
BANGKOK, Thailand – February 4, 2019 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and
precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its second quarter ended December 28, 2018.

[0001193125-19-027031:8k_2_02:6]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “We are pleased to have delivered record results in the fiscal second quarter, exceeding our
prior guidance with particular strength from products to the telecom market. We are optimistic that Q3 will represent a record third quarter for us in terms of both revenue and profitability, and that our strong market position will enable us to
extend our track record of success over the longer-term.”

[0001193125-19-027031:8k_2_02:7]
Second Quarter Fiscal Year 2019 Financial Highlights

[0001193125-19-027031:8k_2_02:8]
As of the first quarter of fiscal 2019, Fabrinet is reporting results under the new revenue recognition standard Accounting Standards Codification
Topic 606 (“ASC 606”), using the modified retrospective method. Financial results for reporting periods prior to fiscal year 2019 are presented as previously disclosed in conformity with the old revenue recognition standard
Accounting Standards Codification Topic 605 (“ASC 605”). A reconciliation to ASC 605 is included at the end of this press release.

[0001193125-19-027031:8k_2_02:9]
GAAP Results

[0001193125-19-027031:8k_2_02:10]
|  | • |  | Revenue for the second quarter of fiscal year 2019 was $403.1 million, compared to revenue of $337.1 million for the comparable period in fiscal year 2018. |

[0001193125-19-027031:8k_2_02:11]
|  | • |  | GAAP net income for the second quarter of fiscal year 2019 was $31.5 million, compared to GAAP net income of $19.3 million for the second quarter of fiscal year 2018. GAAP net income for the second quarter of fiscal year 2019 included a foreign exchange loss of $0.4 million, or $(0.01) per diluted share, compared to a foreign exchange loss of $1.3 million, or $(0.04) per diluted share, for the second quarter of fiscal year 2018. |

[0001193125-19-027031:8k_2_02:12]
|  | • |  | GAAP net income per diluted share for the second quarter of fiscal year 2019 was $0.84, compared to GAAP net income per diluted share of $0.51 for the second quarter of fiscal year 2018. |

[0001193125-19-027031:8k_2_02:13]
Non-GAAP
Results

[0001193125-19-027031:8k_2_02:14]
|  | • |  | Non-GAAP net income for the second quarter of fiscal year 2019 was $36.5 million, compared to non-GAAP net income of $27.3 million for the second quarter of fiscal year 2018. Non-GAAP net income for the second quarter of fiscal year 2019 included a foreign exchange loss of $0.4 million, or $(0.01) per diluted share, compared to a foreign exchange loss of $1.3 million, or $(0.04) per diluted share, for the second quarter of fiscal year 2018. |

[0001193125-19-027031:8k_2_02:15]
|  | • |  | Non-GAAP net income per diluted share for the second quarter of fiscal year 2019 was $0.97, compared to non-GAAP net income per diluted share of $0.72 for the same period in fiscal year 2018. |

[0001193125-19-027031:8k_2_02:16]
Share Repurchase Program Update

[0001193125-19-027031:8k_2_02:17]
There was no share repurchase activity during the three months ended December 28, 2018. As of December 28, 2018, Fabrinet had a remaining
authorization to purchase up to an additional $17.6 million worth of its ordinary shares.

[0001193125-19-027031:8k_2_02:18]
Business Outlook

[0001193125-19-027031:8k_2_02:19]
The guidance provided below for the third quarter of fiscal 2019 is based on ASC 605; however, we will report revenues for such quarter based on
ASC 606. As of the first quarter of fiscal 2019, Fabrinet is reporting results under ASC 606, which it is adopting for fiscal year 2019 on a modified retrospective method. A reconciliation to ASC 605 is included at the end of this
press release.

[0001193125-19-027031:8k_2_02:20]
Based on information available as of February 4, 2019, Fabrinet is issuing guidance for its third fiscal quarter of 2019 ending
March 29, 2019, as follows:

[0001193125-19-027031:8k_2_02:21]
|  | • |  | Fabrinet expects third quarter revenue to be in the range of $384 million to $392 million. |

[0001193125-19-027031:8k_2_02:22]
|  | • |  | GAAP net income per diluted share is expected to be in the range of $0.71 to $0.75, based on approximately 37.6 million fully diluted shares outstanding. |

[0001193125-19-027031:8k_2_02:23]
|  | • |  | Non-GAAP net income per diluted share is expected to be in the range of $0.86 to $0.90, based on approximately 37.6 million fully diluted shares outstanding. |

[0001193125-19-027031:8k_2_02:24]
Conference Call Information

[0001193125-19-027031:8k_2_02:25]
| What: |  | Fabrinet Second Quarter Fiscal-Year 2019 Financial Results Call |
| When: |  | Monday, February 4, 2019 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic (253) 237-1137, international Passcode: 2047796 |
| Replay: |  | (855) 859-2056, domestic (404) 537-3406, international Passcode: 2047796 |
| Webcast: |  | http://investor.fabrinet.com/ (live and replay) |

[0001193125-19-027031:8k_2_02:26]
This press release and any other information related to the call will also be posted on Fabrinet’s website at
http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-19-027031:8k_2_02:27]
About Fabrinet

[0001193125-19-027031:8k_2_02:28]
Fabrinet is a leading provider of
advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive
components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain
management, manufacturing, advanced packaging, integration, final assembly and test. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in
Thailand, the United States of America, the People’s Republic of China and the United Kingdom. For more information visit: www.fabrinet.com.

[0001193125-19-027031:8k_2_02:29]
Forward-Looking Statements

[0001193125-19-027031:8k_2_02:30]
Use of Non-GAAP Financials

[0001193125-19-027031:8k_2_02:31]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful
supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; depreciation of fair value uplift; severance payments; expenses related
to our CFO search; debt administration expense; amortization of intangibles; business combination expenses; loss (gain) on foreign currency contracts; amortization of debt issuance costs; restructuring charges; and ASC 606 adjustments. We have
excluded these items in order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to
evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP
financial measures.

[0001193125-19-027031:8k_2_02:32]
These non-GAAP financial measures are used to: (1) measure company performance against
historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001193125-19-027031:8k_2_02:33]
SOURCE: Fabrinet

[0001193125-19-027031:8k_2_02:34]
Investor Contact:

[0001193125-19-027031:8k_2_02:35]
Garo Toomajanian

[0001193125-19-027031:8k_2_02:36]
ir@fabrinet.com

[0001193125-19-027031:8k_2_02:37]
FABRINET

[0001193125-19-027031:8k_2_02:38]
CONDENSED CONSOLIDATED BALANCE SHEETS (unaudited)

[0001193125-19-027031:8k_2_02:39]
| (in thousands of U.S. dollars, except share data) |  | December 28,2018 |  |  | June 29,2018 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 230,996 |  |  | $ | 158,102 |  |
| Restricted cash in connection with business acquisition |  |  | — |  |  |  | 3,331 |  |
| Short-term investments |  |  | 151,508 |  |  |  | 174,269 |  |
| Trade accounts receivable, net |  |  | 261,519 |  |  |  | 246,912 |  |
| Contract assets |  |  | 13,336 |  |  |  | — |  |
| Inventory, net |  |  | 277,893 |  |  |  | 257,687 |  |
| Prepaid expenses |  |  | 9,809 |  |  |  | 8,061 |  |
| Other current assets |  |  | 5,044 |  |  |  | 5,948 |  |
| Total current assets |  |  | 950,105 |  |  |  | 854,310 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 212,314 |  |  |  | 219,640 |  |
| Intangibles, net |  |  | 4,283 |  |  |  | 4,880 |  |
| Goodwill |  |  | 3,698 |  |  |  | 3,828 |  |
| Deferred tax assets |  |  | 5,454 |  |  |  | 5,280 |  |
| Other non-current assets |  |  | 72 |  |  |  | 80 |  |
| Total non-current assets |  |  | 225,821 |  |  |  | 233,708 |  |
| Total Assets |  | $ | 1,175,926 |  |  | $ | 1,088,018 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Bank borrowings |  | $ | 3,250 |  |  | $ | 3,250 |  |
| Trade accounts payable |  |  | 248,253 |  |  |  | 220,159 |  |
| Capital lease liability, current portion |  |  | 409 |  |  |  | 451 |  |
| Income tax payable |  |  | 2,568 |  |  |  | 709 |  |
| Deferred liability in connection with business acquisition |  |  | — |  |  |  | 3,331 |  |
| Accrued payroll, bonus and related expenses |  |  | 16,327 |  |  |  | 13,476 |  |
| Accrued expenses |  |  | 9,106 |  |  |  | 9,013 |  |
| Other payables |  |  | 17,637 |  |  |  | 19,728 |  |
| Total current liabilities |  |  | 297,550 |  |  |  | 270,117 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term loan from bank |  |  | 60,125 |  |  |  | 60,938 |  |
| Deferred tax liability |  |  | 2,939 |  |  |  | 2,284 |  |
| Capital lease liability, non-current portion |  |  | 302 |  |  |  | 516 |  |
| Severance liabilities |  |  | 11,173 |  |  |  | 10,162 |  |
| Other non-current liabilities |  |  | 2,304 |  |  |  | 3,062 |  |
| Total non-current liabilities |  |  | 76,843 |  |  |  | 76,962 |  |
| Total Liabilities |  |  | 374,393 |  |  |  | 347,079 |  |
| Commitments and contingencies (Note 15) |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of December 28, 2018 and June 29, 2018) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 38,138,159 shares and 37,723,733 shares issued; and 36,849,056 shares and 36,434,630 shares outstanding as of December 28, 2018 and June 29, 2018, respectively) |  |  | 381 |  |  |  | 377 |  |
| Additional paid-in capital |  |  | 151,639 |  |  |  | 151,797 |  |
| Less: Treasury shares (1,289,103 shares and 1,289,103 shares as of December 28, 2018 and June 29, 2018, respectively) |  |  | (42,401 | ) |  |  | (42,401 | ) |
| Accumulated other comprehensive loss |  |  | (1,077 | ) |  |  | (1,257 | ) |
| Retained earnings |  |  | 692,991 |  |  |  | 632,423 |  |
| Total Shareholders’ Equity |  |  | 801,533 |  |  |  | 740,939 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 1,175,926 |  |  | $ | 1,088,018 |  |

[0001193125-19-027031:8k_2_02:40]
FABRINET

[0001193125-19-027031:8k_2_02:41]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME (unaudited)

[0001193125-19-027031:8k_2_02:42]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (in thousands of U.S. dollars, except per share amounts) |  | December 28,2018 |  |  | December 29,2017 |  |  | December 28,2018 |  |  | December 29,2017 |  |
| Revenues |  | $ | 403,080 |  |  | $ | 337,072 |  |  | $ | 780,257 |  |  | $ | 694,385 |  |
| Cost of revenues |  |  | (357,516 | ) |  |  | (299,906 | ) |  |  | (694,417 | ) |  |  | (616,887 | ) |
| Gross profit |  |  | 45,564 |  |  |  | 37,166 |  |  |  | 85,840 |  |  |  | 77,498 |  |
| Selling, general and administrative expenses |  |  | (12,727 | ) |  |  | (13,157 | ) |  |  | (27,164 | ) |  |  | (28,835 | ) |
| Expenses related to reduction in workforce |  |  | (319 | ) |  |  | (1,776 | ) |  |  | (404 | ) |  |  | (1,776 | ) |
| Operating income |  |  | 32,518 |  |  |  | 22,233 |  |  |  | 58,272 |  |  |  | 46,887 |  |
| Interest income |  |  | 1,182 |  |  |  | 596 |  |  |  | 2,626 |  |  |  | 1,405 |  |
| Interest expense |  |  | (1,616 | ) |  |  | (826 | ) |  |  | (2,250 | ) |  |  | (1,679 | ) |
| Foreign exchange (loss) gain, net |  |  | (421 | ) |  |  | (1,348 | ) |  |  | 2,647 |  |  |  | (3,282 | ) |
| Other income |  |  | 562 |  |  |  | 250 |  |  |  | 639 |  |  |  | 347 |  |
| Income before income taxes |  |  | 32,225 |  |  |  | 20,905 |  |  |  | 61,934 |  |  |  | 43,678 |  |
| Income tax expense |  |  | (712 | ) |  |  | (1,592 | ) |  |  | (2,571 | ) |  |  | (3,332 | ) |
| Net income |  |  | 31,513 |  |  |  | 19,313 |  |  |  | 59,363 |  |  |  | 40,346 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities |  |  | 598 |  |  |  | (462 | ) |  |  | 886 |  |  |  | (432 | ) |
| Change in net unrealized loss on derivative instruments |  |  | — |  |  |  | — |  |  |  | (1 | ) |  |  | (1 | ) |
| Change in foreign currency translation adjustment |  |  | (505 | ) |  |  | 44 |  |  |  | (705 | ) |  |  | 569 |  |
| Total other comprehensive income (loss), net of tax |  |  | 93 |  |  |  | (418 | ) |  |  | 180 |  |  |  | 136 |  |
| Net comprehensive income |  | $ | 31,606 |  |  | $ | 18,895 |  |  | $ | 59,543 |  |  | $ | 40,482 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.86 |  |  | $ | 0.52 |  |  | $ | 1.62 |  |  | $ | 1.08 |  |
| Diluted |  | $ | 0.84 |  |  | $ | 0.51 |  |  | $ | 1.59 |  |  | $ | 1.06 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |
| Basic |  |  | 36,841 |  |  |  | 37,477 |  |  |  | 36,733 |  |  |  | 37,462 |  |
| Diluted |  |  | 37,471 |  |  |  | 38,156 |  |  |  | 37,305 |  |  |  | 38,160 |  |

[0001193125-19-027031:8k_2_02:43]
FABRINET

[0001193125-19-027031:8k_2_02:44]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited)

[0001193125-19-027031:8k_2_02:45]
|  |  | Six Months Ended |  |
| (in thousands of U.S. dollars) |  | December 28,2018 |  |  | December 29,2017 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income for the period |  | $ | 59,363 |  |  | $ | 40,346 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 15,000 |  |  |  | 14,265 |  |
| Loss on disposal of property, plant and equipment |  |  | 528 |  |  |  | — |  |
| Loss on disposal of intangibles |  |  | 149 |  |  |  | — |  |
| Loss from sales and maturities of available-for-sale securities |  |  | 1,060 |  |  |  | 357 |  |
| Amortization of investment premium |  |  | (533 | ) |  |  | (163 | ) |
| Amortization of deferred debt issuance costs |  |  | — |  |  |  | 295 |  |
| Allowance for doubtful accounts |  |  | — |  |  |  | 5 |  |
| Unrealized (gain) loss on exchange rate and fair value of derivative instruments |  |  | (5,775 | ) |  |  | 1,740 |  |
| Share-based compensation |  |  | 8,949 |  |  |  | 12,378 |  |
| Deferred income tax |  |  | 481 |  |  |  | (153 | ) |
| Other non-cash expenses |  |  | 580 |  |  |  | 962 |  |
| Inventory obsolescence |  |  | 29 |  |  |  | 654 |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | (14,381 | ) |  |  | 5,707 |  |
| Contract assets |  |  | (3,459 | ) |  |  | — |  |
| Inventory |  |  | (28,909 | ) |  |  | (1,047 | ) |
| Other current assets and non-current assets |  |  | 2,128 |  |  |  | (6,801 | ) |
| Trade accounts payable |  |  | 29,276 |  |  |  | (33,626 | ) |
| Income tax payable |  |  | 1,859 |  |  |  | (791 | ) |
| Other current liabilities and non-current liabilities |  |  | 2,953 |  |  |  | 2,985 |  |
| Net cash provided by operating activities |  |  | 69,298 |  |  |  | 37,113 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of short-term investments |  |  | (82,141 | ) |  |  | (48,679 | ) |
| Proceeds from sales of short-term investments |  |  | 70,472 |  |  |  | 18,672 |  |
| Proceeds from maturities of short-term investments |  |  | 34,788 |  |  |  | 31,427 |  |
| Purchase of property, plant and equipment |  |  | (9,732 | ) |  |  | (21,405 | ) |
| Purchase of intangibles |  |  | (251 | ) |  |  | (689 | ) |
| Proceeds from disposal of property, plant and equipment |  |  | 5 |  |  |  | 35 |  |
| Net cash provided by (used in) investing activities |  |  | 13,141 |  |  |  | (20,639 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Proceeds of short-term loans from bank |  |  | — |  |  |  | 5,000 |  |
| Repayment of short-term loans from bank |  |  | — |  |  |  | (1,003 | ) |
| Repayment of long-term loans from bank |  |  | (813 | ) |  |  | (6,800 | ) |
| Repayment of capital lease liability |  |  | (255 | ) |  |  | (174 | ) |
| Repurchase of ordinary shares |  |  | — |  |  |  | (9,910 | ) |
| Proceeds from issuance of ordinary shares under employee share option plans |  |  | — |  |  |  | 990 |  |
| Release of restricted cash held in connection with business acquisition |  |  | (3,478 | ) |  |  | — |  |
| Withholding tax related to net share settlement of restricted share units |  |  | (9,103 | ) |  |  | (3,744 | ) |
| Net cash used in financing activities |  |  | (13,649 | ) |  |  | (15,641 | ) |
| Net increase in cash, cash equivalents and restricted cash |  |  | 68,790 |  |  |  | 833 |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 161,433 |  |  |  | 137,137 |  |
| Increase in cash, cash equivalents and restricted cash |  |  | 68,790 |  |  |  | 833 |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash |  |  | 773 |  |  |  | 284 |  |
| Cash, cash equivalents and restricted cash at end of period |  | $ | 230,996 |  |  | $ | 138,254 |  |
| Non-cash investing and financing activities |  |  |  |  |  |  |  |  |
| Construction, software-related and equipment-related payables |  | $ | 2,888 |  |  | $ | 5,658 |  |

[0001193125-19-027031:8k_2_02:46]
FABRINET

[0001193125-19-027031:8k_2_02:47]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited) (Continued)

[0001193125-19-027031:8k_2_02:48]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the condensed consolidated balance sheets that sum
to the total of the same amounts shown in the condensed consolidated statements of cash flows:

[0001193125-19-027031:8k_2_02:49]
| (amount in thousands) |  | As ofDecember 28,2018 |  |  | As ofDecember 29,2017 |  |
| Cash and cash equivalents |  | $ | 230,996 |  |  | $ | 134,831 |  |
| Restricted cash in connection with business acquisition (non-current assets) |  |  | — |  |  |  | 3,423 |  |
| Cash, cash equivalents and restricted cash |  | $ | 230,996 |  |  | $ | 138,254 |  |

[0001193125-19-027031:8k_2_02:50]
FABRINET

[0001193125-19-027031:8k_2_02:51]
RECONCILIATION OF ASC 605 TO ASC 606

[0001193125-19-027031:8k_2_02:52]
|  |  | Three Months EndedDecember 28, 2018 |  |
| (in thousands of U.S. dollars, except per share amounts) |  | ASC 605 |  |  | ASC 606 |  |  | Impact |  |
| Revenues |  | $ | 399,901 |  |  | $ | 403,080 |  |  | $ | (3,179 | ) |
| Cost of revenues |  |  | (353,341 | ) |  |  | (356,132 | ) |  |  | 2,791 |  |
| Gross profit |  |  | 46,560 |  |  |  | 46,948 |  |  |  | (388 | ) |
| Selling, general and administrative expenses |  |  | (9,426 | ) |  |  | (9,426 | ) |  |  | — |  |
| Operating income |  |  | 37,134 |  |  |  | 37,522 |  |  |  | (388 | ) |
| Interest income |  |  | 1,182 |  |  |  | 1,182 |  |  |  | — |  |
| Interest expense |  |  | (1,616 | ) |  |  | (1,616 | ) |  |  | — |  |
| Foreign exchange loss |  |  | (421 | ) |  |  | (421 | ) |  |  | — |  |
| Other income |  |  | 562 |  |  |  | 562 |  |  |  | — |  |
| Income before income taxes |  |  | 36,841 |  |  |  | 37,229 |  |  |  | (388 | ) |
| Income tax expense |  |  | (712 | ) |  |  | (712 | ) |  |  | — |  |
| Net income |  |  | 36,129 |  |  |  | 36,517 |  |  |  | (388 | ) |
| Other comprehensive income, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in net unrealized gain on available-for-sale securities |  |  | 598 |  |  |  | 598 |  |  |  | — |  |
| Change in foreign currency translation adjustment |  |  | (505 | ) |  |  | (505 | ) |  |  | — |  |
| Total other comprehensive income, net of tax |  |  | 93 |  |  |  | 93 |  |  |  | — |  |
| Net comprehensive income |  | $ | 36,222 |  |  | $ | 36,610 |  |  |  | (388 | ) |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.98 |  |  | $ | 0.99 |  |  | $ | (0.01 | ) |
| Diluted |  | $ | 0.96 |  |  | $ | 0.97 |  |  | $ | (0.01 | ) |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |
| Basic |  |  | 36,841 |  |  |  | 36,841 |  |  |  | — |  |
| Diluted |  |  | 37,471 |  |  |  | 37,471 |  |  |  | — |  |

[0001193125-19-027031:8k_2_02:53]
| FABRINET RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 28, 2018(ASC 606) |  |  | December 29, 2017(ASC 605) |  |  | December 28, 2018(ASC 606) |  |  | December 29, 2017(ASC 605) |  |
| (in thousands of U.S. dollars, except per share data) |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |
| GAAP measures |  |  | 31,513 |  |  |  | 0.84 |  |  |  | 19,313 |  |  |  | 0.51 |  |  |  | 59,363 |  |  |  | 1.59 |  |  |  | 40,346 |  |  |  | 1.06 |  |
| Items reconciling GAAP net (loss) income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,300 |  |  |  | 0.03 |  |  |  | 1,812 |  |  |  | 0.05 |  |  |  | 3,147 |  |  |  | 0.08 |  |  |  | 3,713 |  |  |  | 0.10 |  |
| Depreciation of fair value uplift |  |  | 84 |  |  |  | 0.00 |  |  |  | 86 |  |  |  | 0.00 |  |  |  | 173 |  |  |  | 0.00 |  |  |  | 153 |  |  |  | 0.00 |  |
| ASC 606 adoption impact on gross profit |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (31 | ) |  |  | (0.00 | ) |  |  | — |  |  |  | — |  |
| Total related to gross profit |  |  | 1,384 |  |  |  | 0.04 |  |  |  | 1,898 |  |  |  | 0.05 |  |  |  | 3,289 |  |  |  | 0.09 |  |  |  | 3,866 |  |  |  | 0.10 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 2,669 |  |  |  | 0.07 |  |  |  | 3,646 |  |  |  | 0.10 |  |  |  | 5,802 |  |  |  | 0.16 |  |  |  | 8,665 |  |  |  | 0.23 |  |
| Expenses related to CFO/CEO search |  |  | 382 |  |  |  | 0.01 |  |  |  | 204 |  |  |  | 0.01 |  |  |  | 572 |  |  |  | 0.02 |  |  |  | 204 |  |  |  | 0.01 |  |
| Amortization of intangibles |  |  | 176 |  |  |  | 0.00 |  |  |  | 208 |  |  |  | 0.01 |  |  |  | 368 |  |  |  | 0.01 |  |  |  | 377 |  |  |  | 0.01 |  |
| Business combination expenses |  |  | 58 |  |  |  | 0.00 |  |  |  | 11 |  |  |  | 0.00 |  |  |  | 240 |  |  |  | 0.01 |  |  |  | 117 |  |  |  | 0.00 |  |
| Severance payment |  |  | 16 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |  |  | 601 |  |  |  | 0.02 |  |  |  | — |  |  |  | — |  |
| Total related to selling, general and administrative expenses |  |  | 3,301 |  |  |  | 0.09 |  |  |  | 4,069 |  |  |  | 0.11 |  |  |  | 7,583 |  |  |  | 0.20 |  |  |  | 9,362 |  |  |  | 0.25 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other expenses in relation to reduction in workforce |  |  | 319 |  |  |  | 0.01 |  |  |  | 1,776 |  |  |  | 0.05 |  |  |  | 404 |  |  |  | 0.01 |  |  |  | 1,776 |  |  |  | 0.05 |  |
| Amortization of debt issuance costs |  |  | — |  |  |  | — |  |  |  | 267 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 540 |  |  |  | 0.01 |  |
| Total related to other incomes and other expenses |  |  | 319 |  |  |  | 0.01 |  |  |  | 2,043 |  |  |  | 0.05 |  |  |  | 404 |  |  |  | 0.01 |  |  |  | 2,316 |  |  |  | 0.06 |  |
| Total related to net income & EPS |  |  | 5,004 |  |  |  | 0.13 |  |  |  | 8,010 |  |  |  | 0.21 |  |  |  | 11,276 |  |  |  | 0.30 |  |  |  | 15,544 |  |  |  | 0.41 |  |
| Non-GAAP measures |  |  | 36,517 |  |  |  | 0.97 |  |  |  | 27,323 |  |  |  | 0.72 |  |  |  | 70,639 |  |  |  | 1.89 |  |  |  | 55,890 |  |  |  | 1.47 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 37,471 |  |  |  |  |  |  |  | 38,156 |  |  |  |  |  |  |  | 37,305 |  |  |  |  |  |  |  | 38,160 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 37,471 |  |  |  |  |  |  |  | 38,156 |  |  |  |  |  |  |  | 37,305 |  |  |  |  |  |  |  | 38,160 |  |

[0001193125-19-027031:8k_2_02:54]
FABRINET

[0001193125-19-027031:8k_2_02:55]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001193125-19-027031:8k_2_02:56]
| (amount in thousands) |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 28,2018 |  |  | December 27,2017 |  |  | December 28,2018 |  |  | December 29,2017 |  |
| Net cash provided by operating activities |  | $ | 34,705 |  |  | $ | 40,167 |  |  | $ | 69,298 |  |  | $ | 37,113 |  |
| Less: Purchase of property, plant and equipment |  |  | (4,322 | ) |  |  | (10,202 | ) |  |  | (9,732 | ) |  |  | (21,405 | ) |
| Non-GAAP free cash flow |  | $ | 30,383 |  |  | $ | 29,965 |  |  | $ | 59,566 |  |  | $ | 15,708 |  |

[0001193125-19-027031:8k_2_02:57]
FABRINET

[0001193125-19-027031:8k_2_02:58]
GUIDANCE FOR QUARTER ENDING MARCH 29, 2019

[0001193125-19-027031:8k_2_02:59]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-19-027031:8k_2_02:60]
|  |  | Diluted EPS |  |
| GAAP net income per diluted share: |  | $ | 0.71 to $0.75 |  |
| Related to cost of revenues: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.04 |  |
| Total related to gross profit |  |  | 0.04 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.09 |  |
| Expenses related to our CFO search |  |  | 0.01 |  |
| Total related to selling, general and administrative expenses |  |  | 0.10 |  |
| Related to other incomes and other expenses: |  |  |  |  |
| Other expenses in relation to reduction in workforce |  |  | 0.01 |  |
| Total related to other incomes and other expenses |  |  | 0.01 |  |
| Total related to net income & EPS |  |  | 0.15 |  |
| Non-GAAP net income per diluted share |  | $ | 0.86 to $0.90 |  |
