# FN MD&A — 0001193125-19-028336


## mdna

[0001193125-19-028336:mdna:1]
ITEM 2. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND
RESULTS OF OPERATIONS

[0001193125-19-028336:mdna:2]
[same as prior period, unchanged from 0001193125-18-319643:mdna:2]

[0001193125-19-028336:mdna:3]
[same as prior period, unchanged from 0001193125-18-319643:mdna:3]

[0001193125-19-028336:mdna:4]
|  | • |  | our expectation that the portion of our future revenues attributable to customers in regions outside of North America will be in line with the portion of those revenues for the six months ended December 28, 2018; |

[0001193125-19-028336:mdna:5]
[same as prior period, unchanged from 0001193125-18-319643:mdna:5]

[0001193125-19-028336:mdna:6]
[same as prior period, unchanged from 0001193125-18-319643:mdna:6]

[0001193125-19-028336:mdna:7]
[same as prior period, unchanged from 0001193125-18-319643:mdna:7]

[0001193125-19-028336:mdna:8]
|  | • |  | our intent to apply for, and our expectation that we will be granted, a renewal of our 20-years period Cayman Islands tax exemption; |

[0001193125-19-028336:mdna:9]
[same as prior period, unchanged from 0001193125-18-319643:mdna:8]

[0001193125-19-028336:mdna:10]
[same as prior period, unchanged from 0001193125-18-319643:mdna:9]

[0001193125-19-028336:mdna:11]
[same as prior period, unchanged from 0001193125-18-319643:mdna:10]

[0001193125-19-028336:mdna:12]
[same as prior period, unchanged from 0001193125-18-319643:mdna:11]

[0001193125-19-028336:mdna:13]
[same as prior period, unchanged from 0001193125-18-319643:mdna:12]

[0001193125-19-028336:mdna:14]
[same as prior period, unchanged from 0001193125-18-319643:mdna:13]

[0001193125-19-028336:mdna:15]
[same as prior period, unchanged from 0001193125-18-319643:mdna:14]

[0001193125-19-028336:mdna:16]
[same as prior period, unchanged from 0001193125-18-319643:mdna:15]

[0001193125-19-028336:mdna:17]
[same as prior period, unchanged from 0001193125-18-319643:mdna:16]

[0001193125-19-028336:mdna:18]
[same as prior period, unchanged from 0001193125-18-319643:mdna:17]

[0001193125-19-028336:mdna:19]
[same as prior period, unchanged from 0001193125-18-319643:mdna:18]

[0001193125-19-028336:mdna:20]
[same as prior period, unchanged from 0001193125-18-319643:mdna:19]

[0001193125-19-028336:mdna:21]
We provide advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment
manufacturers (“OEMs”) of complex products such as optical communication components, modules and sub-systems, industrial lasers, medical devices and sensors. We offer a broad range of advanced
optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, complex printed circuit board assembly, advanced packaging, integration, final
assembly and testing. Although we focus primarily on low-volume production of a wide variety of high complexity products, which we refer to as “low-volume, high-mix,” we also have the capability to accommodate high-volume production. Based on our experience with, and positive feedback we have received from our customers, we believe we are a global leader in
providing these services to the optical communications, industrial lasers and automotive markets.

[0001193125-19-028336:mdna:22]
[same as prior period, unchanged from 0001193125-18-319643:mdna:21]

[0001193125-19-028336:mdna:23]
[same as prior period, unchanged from 0001193125-18-319643:mdna:22]

[0001193125-19-028336:mdna:24]
[same as prior period, unchanged from 0001193125-18-319643:mdna:23]

[0001193125-19-028336:mdna:25]
[same as prior period, unchanged from 0001193125-18-319643:mdna:24]

[0001193125-19-028336:mdna:26]
[same as prior period, unchanged from 0001193125-18-319643:mdna:25]

[0001193125-19-028336:mdna:27]
[same as prior period, unchanged from 0001193125-18-319643:mdna:26]

[0001193125-19-028336:mdna:28]
The percentage of our revenues generated from a
bill-to location outside of North America decreased slightly from 54.9% in the three months ended December 29, 2017 to 54.7% in the three months ended December 28, 2018, and decreased from 55.5% in
the six months ended December 29, 2017 to 53.5% in the six months ended December 28, 2018, primarily because the increase in sales to our customers in North America was higher than the increase in sales to our customers outside of North
America. Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside North America will be in line with the portion of revenues
attributable to such customers during the six months ended December 28, 2018.

[0001193125-19-028336:mdna:29]
[same as prior period, unchanged from 0001193125-18-319643:mdna:28]

[0001193125-19-028336:mdna:30]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 28,2018 |  |  | December 29,2017 |  |  | December 28,2018 |  |  | December 29,2017 |  |
| North America |  |  | 45.3 | % |  |  | 45.1 | % |  |  | 46.5 | % |  |  | 44.5 | % |
| Asia-Pacific |  |  | 41.4 |  |  |  | 38.7 |  |  |  | 40.8 |  |  |  | 39.3 |  |
| Europe |  |  | 13.3 |  |  |  | 16.2 |  |  |  | 12.7 |  |  |  | 16.2 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-19-028336:mdna:31]
[same as prior period, unchanged from 0001193125-18-319643:mdna:30]

[0001193125-19-028336:mdna:32]
[same as prior period, unchanged from 0001193125-18-319643:mdna:31]

[0001193125-19-028336:mdna:33]
[same as prior period, unchanged from 0001193125-18-319643:mdna:32]

[0001193125-19-028336:mdna:34]
[same as prior period, unchanged from 0001193125-18-319643:mdna:33]

[0001193125-19-028336:mdna:35]
[same as prior period, unchanged from 0001193125-18-319643:mdna:34]

[0001193125-19-028336:mdna:36]
[same as prior period, unchanged from 0001193125-18-319643:mdna:35]

[0001193125-19-028336:mdna:37]
[same as prior period, unchanged from 0001193125-18-319643:mdna:36]

[0001193125-19-028336:mdna:38]
[same as prior period, unchanged from 0001193125-18-319643:mdna:37]

[0001193125-19-028336:mdna:39]
[same as prior period, unchanged from 0001193125-18-319643:mdna:38]

[0001193125-19-028336:mdna:40]
[same as prior period, unchanged from 0001193125-18-319643:mdna:39]

[0001193125-19-028336:mdna:41]
In addition, during
the six months ended December 28, 2018, $1.4 million share-based compensation expenses recorded in fiscal year 2018 for the remaining portion of performance share units granted to our executives were reversed due to the unlikelihood that
the performance targets would be achieved.

[0001193125-19-028336:mdna:42]
[same as prior period, unchanged from 0001193125-18-319643:mdna:41]

[0001193125-19-028336:mdna:43]
[same as prior period, unchanged from 0001193125-18-319643:mdna:42]

[0001193125-19-028336:mdna:44]
[same as prior period, unchanged from 0001193125-18-319643:mdna:43]

[0001193125-19-028336:mdna:45]
In order to manage the risks arising from fluctuations in foreign currency exchange rates, we use derivative instruments. We may enter into
exchange currency forward or put option contracts to manage foreign currency exposures associated with certain assets and liabilities and other forecasted foreign currency transactions and may designate these instruments as hedging instruments. The
forward and put option contracts generally have maturities of up to 12 months. All foreign currency exchange contracts are recognized in the condensed consolidated balance sheets at fair value. Gain or loss on our forward and put option contracts
generally offset the assets, liabilities, and transactions economically hedged.

[0001193125-19-028336:mdna:46]
[same as prior period, unchanged from 0001193125-18-319643:mdna:45]

[0001193125-19-028336:mdna:47]
|  |  | As of December 28, 2018 |  |  | As of June 29, 2018 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,495,411 |  |  | $ | 46,084 |  |  |  | 84.3 |  |  |  | 980,778 |  |  | $ | 29,568 |  |  |  | 60.7 |  |
| RMB |  |  | 26,427 |  |  |  | 3,850 |  |  |  | 7.0 |  |  |  | 18,455 |  |  |  | 2,789 |  |  |  | 5.7 |  |
| GBP |  |  | 3,769 |  |  |  | 4,770 |  |  |  | 8.7 |  |  |  | 12,514 |  |  |  | 16,392 |  |  |  | 33.6 |  |
| Total |  |  |  |  |  | $ | 54,704 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 48,749 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,840,234 |  |  | $ | 56,710 |  |  |  | 87.7 |  |  |  | 1,401,473 |  |  | $ | 42,251 |  |  |  | 84.5 |  |
| RMB |  |  | 31,130 |  |  |  | 4,535 |  |  |  | 7.0 |  |  |  | 19,893 |  |  |  | 3,007 |  |  |  | 6.0 |  |
| GBP |  |  | 2,729 |  |  |  | 3,454 |  |  |  | 5.3 |  |  |  | 3,615 |  |  |  | 4,735 |  |  |  | 9.5 |  |
| Total |  |  |  |  |  | $ | 64,699 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 49,993 |  |  |  | 100.0 |  |

[0001193125-19-028336:mdna:48]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other
current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and
offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of December 28, 2018 there were $8.0 million of foreign currency forward contracts and $15.0 million of foreign
currency option contracts outstanding on the Thai baht payables. As of June 29, 2018, there were $7.0 million in foreign currency forward contracts and $30.0 million of foreign currency option contracts outstanding on the Thai baht
payables.

[0001193125-19-028336:mdna:49]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities
represent trade accounts payable, accrued expenses, income tax payable and other payables. As of December 28, 2018 and June 29, 2018, we did not have any derivative contracts denominated in RMB.

[0001193125-19-028336:mdna:50]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable and
other payables. As of December 28, 2018 and June 29, 2018, we did not have any derivative contracts denominated in GBP.

[0001193125-19-028336:mdna:51]
For the
six months ended December 28, 2018 and December 29, 2017, we recorded loss of $7.0 thousand and $0.1 million, respectively, related to derivatives that are not designated as hedging instruments in the condensed consolidated
statements of operations and comprehensive income.

[0001193125-19-028336:mdna:52]
[same as prior period, unchanged from 0001193125-18-319643:mdna:51]

[0001193125-19-028336:mdna:53]
[same as prior period, unchanged from 0001193125-18-319643:mdna:52]

[0001193125-19-028336:mdna:54]
[same as prior period, unchanged from 0001193125-18-319643:mdna:53]

[0001193125-19-028336:mdna:55]
[same as prior period, unchanged from 0001193125-18-319643:mdna:54]

[0001193125-19-028336:mdna:56]
[same as prior period, unchanged from 0001193125-18-319643:mdna:55]

[0001193125-19-028336:mdna:57]
[same as prior period, unchanged from 0001193125-18-319643:mdna:56]

[0001193125-19-028336:mdna:58]
[same as prior period, unchanged from 0001193125-18-319643:mdna:57]

[0001193125-19-028336:mdna:59]
[same as prior period, unchanged from 0001193125-18-319643:mdna:58]

[0001193125-19-028336:mdna:60]
[same as prior period, unchanged from 0001193125-18-319643:mdna:59]

[0001193125-19-028336:mdna:61]
[same as prior period, unchanged from 0001193125-18-319643:mdna:60]

[0001193125-19-028336:mdna:62]
[same as prior period, unchanged from 0001193125-18-319643:mdna:61]

[0001193125-19-028336:mdna:63]
[same as prior period, unchanged from 0001193125-18-319643:mdna:62]

[0001193125-19-028336:mdna:64]
Our effective tax rate is a function of the mix of tax rates in the various jurisdictions in which we do business. We are domiciled in the
Cayman Islands. Under the current laws of the Cayman Islands, we are not subject to tax in the Cayman Islands on income or capital gains. We have received this undertaking for a 20-year period expiring
August 24, 2019. The earliest we can apply for a renewal with the office of the Clerk of the Cabinet is three months prior to the expiration date. Therefore, we intend to request a renewal with the office of the Clerk of the Cabinet for another
20 years in May 2019, which we believe is likely to be granted.

[0001193125-19-028336:mdna:65]
Throughout the period of our operations in Thailand, we have generally
received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption is currently available to us through June 2020 and June 2026 on income
generated from projects to manufacture certain products at our Pinehurst campus and Chonburi campus, respectively. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand
and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted (i.e., at least until June 2020 in the case of our Pinehurst
campus and until June 2026 in the case of our Chonburi campus). In March 2016, the Thailand Revenue Department announced a permanent decrease of corporate income tax rates to 20% for tax periods beginning on or after January 1, 2016. As a
result, corporate income tax rates for our Thai subsidiary are expected to remain at 20% from fiscal year 2017 onward.

[0001193125-19-028336:mdna:66]
The Tax Cuts and
Jobs Act, or the Tax Reform Act, was enacted on December 22, 2017 and provides for significant changes to U.S. tax law. Among other provisions, the Tax Reform Act reduces the U.S. corporate income tax rate to 21% effective in 2018. The Tax
Reform Act also contains a number of provisions that may impact us in future years. Since the Tax Reform Act was recently finalized and ongoing guidance and accounting interpretation is expected over the next twelve months, we have made certain
provisional accounting estimates, as permitted under Staff Accounting Bulletin No. 118. The U.S. Treasury Department, the IRS, and other standard-setting bodies could interpret or issue guidance on how provisions of the Tax Reform Act will be
applied or otherwise administered that is different from our interpretation. At December 28, 2018, we have completed our accounting for all of the enactment-date income tax effects of the Act and concluded that the impact to us is immaterial.

[0001193125-19-028336:mdna:67]
[same as prior period, unchanged from 0001193125-18-319643:mdna:66]

[0001193125-19-028336:mdna:68]
We prepare our condensed consolidated financial statements in conformity with U.S. GAAP, which requires us to make estimates and assumptions
that affect the reported amounts of assets and liabilities, the disclosure of contingent liabilities on the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the financial reporting
period. We continually evaluate these estimates and assumptions based on the most recently available information, our own historical experience and on various other assumptions that we believe to be reasonable under the circumstances. The evaluation
results form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Because the use of estimates is an integral component of the financial reporting process, actual
results could differ from those estimates. Some of our accounting policies require higher degrees of judgment than others in their application. We consider the policies discussed below to be critical to an understanding of our condensed consolidated
financial statements, as their application places the most significant demands on our management’s judgment.

[0001193125-19-028336:mdna:69]
Our critical accounting
policies are disclosed in our Annual Report on Form 10-K for the fiscal year ended June 29, 2018. The adoption of new accounting policies and the accounting standards are disclosed in Note 2 –
Accounting policies to the condensed consolidated financial statements. There were no changes to our accounting policies other than the adoption of Revenue from Contracts with Customers (Topic 606), which created Accounting Standards Codification
Topic 606 (“ASC 606”).

[0001193125-19-028336:mdna:70]
On June 30, 2018, we adopted ASC 606 using the modified retrospective method, which was applied to
those contracts which were not completed as of June 29, 2018. The modified retrospective method requires us to recognize the cumulative effect of the adoption of ASC 606, for all contracts with customers, to the opening balance of equity at
June 30, 2018. Accordingly, the comparative financial information as of June 29, 2018 has not been adjusted and continues to be reported under ASC 605, Revenue Recognition (“ASC 605”). Refer to Note 2 – Accounting
policies and Note 3 – Revenues to the condensed consolidated financial statements for further details.

[0001193125-19-028336:mdna:71]
[same as prior period, unchanged from 0001193125-18-319643:mdna:70]

[0001193125-19-028336:mdna:72]
[same as prior period, unchanged from 0001193125-18-319643:mdna:71]

[0001193125-19-028336:mdna:73]
The following table sets forth a summary of our condensed consolidated statements of operations and comprehensive income. Note that period-to-period comparisons of operating results should not be relied upon as indicative of future performance.

[0001193125-19-028336:mdna:74]
| (amount in thousands) |  | Three Months Ended |  |  | Six Months Ended |  |
|  | December 28,2018 |  |  | December 29,2017 |  |  | December 28,2018 |  |  | December 29,2017 |  |
| Revenues |  | $ | 403,080 |  |  | $ | 337,072 |  |  | $ | 780,257 |  |  | $ | 694,385 |  |
| Cost of revenues |  |  | (357,516 | ) |  |  | (299,906 | ) |  |  | (694,417 | ) |  |  | (616,887 | ) |
| Gross profit |  |  | 45,564 |  |  |  | 37,166 |  |  |  | 85,840 |  |  |  | 77,498 |  |
| Selling, general and administrative expenses |  |  | (12,727 | ) |  |  | (13,157 | ) |  |  | (27,164 | ) |  |  | (28,835 | ) |
| Expenses related to reduction in workforce |  |  | (319 | ) |  |  | (1,776 | ) |  |  | (404 | ) |  |  | (1,776 | ) |
| Operating income |  |  | 32,518 |  |  |  | 22,233 |  |  |  | 58,272 |  |  |  | 46,887 |  |
| Interest income |  |  | 1,182 |  |  |  | 596 |  |  |  | 2,626 |  |  |  | 1,405 |  |
| Interest expense |  |  | (1,616 | ) |  |  | (826 | ) |  |  | (2,250 | ) |  |  | (1,679 | ) |
| Foreign exchange (loss) gain, net |  |  | (421 | ) |  |  | (1,348 | ) |  |  | 2,647 |  |  |  | (3,282 | ) |
| Other income |  |  | 562 |  |  |  | 250 |  |  |  | 639 |  |  |  | 347 |  |
| Income before income taxes |  |  | 32,225 |  |  |  | 20,905 |  |  |  | 61,934 |  |  |  | 43,678 |  |
| Income tax expense |  |  | (712 | ) |  |  | (1,592 | ) |  |  | (2,571 | ) |  |  | (3,332 | ) |
| Net income |  |  | 31,513 |  |  |  | 19,313 |  |  |  | 59,363 |  |  |  | 40,346 |  |
| Other comprehensive income (loss), net of tax |  |  | 93 |  |  |  | (418 | ) |  |  | 180 |  |  |  | 136 |  |
| Net comprehensive income |  | $ | 31,606 |  |  | $ | 18,895 |  |  | $ | 59,543 |  |  | $ | 40,482 |  |

[0001193125-19-028336:mdna:75]
The following table sets forth a summary of our condensed consolidated statements of operations and comprehensive income as a
percentage of total revenues for the periods indicated.

[0001193125-19-028336:mdna:76]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 28,2018 |  |  | December 29,2017 |  |  | December 28,2018 |  |  | December 29,2017 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (88.7 | ) |  |  | (89.0 | ) |  |  | (89.0 | ) |  |  | (88.8 | ) |
| Gross profit |  |  | 11.3 |  |  |  | 11.0 |  |  |  | 11.0 |  |  |  | 11.2 |  |
| Selling, general and administrative expenses |  |  | (3.2 | ) |  |  | (3.9 | ) |  |  | (3.5 | ) |  |  | (4.1 | ) |
| Expenses related to reduction in workforce |  |  | (0.0 | ) |  |  | (0.5 | ) |  |  | (0.0 | ) |  |  | (0.3 | ) |
| Operating income |  |  | 8.1 |  |  |  | 6.6 |  |  |  | 7.5 |  |  |  | 6.8 |  |
| Interest income |  |  | 0.3 |  |  |  | 0.2 |  |  |  | 0.3 |  |  |  | 0.2 |  |
| Interest expense |  |  | (0.4 | ) |  |  | (0.3 | ) |  |  | (0.3 | ) |  |  | (0.2 | ) |
| Foreign exchange (loss) gain, net |  |  | (0.1 | ) |  |  | (0.4 | ) |  |  | 0.3 |  |  |  | (0.5 | ) |
| Other income |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.0 |  |
| Income before income taxes |  |  | 8.0 |  |  |  | 6.2 |  |  |  | 7.9 |  |  |  | 6.3 |  |
| Income tax expense |  |  | (0.2 | ) |  |  | (0.5 | ) |  |  | (0.3 | ) |  |  | (0.5 | ) |
| Net income |  |  | 7.8 |  |  |  | 5.7 |  |  |  | 7.6 |  |  |  | 5.8 |  |
| Other comprehensive income (loss), net of tax |  |  | 0.0 |  |  |  | (0.1 | ) |  |  | 0.0 |  |  |  | 0.1 |  |
| Net comprehensive income |  |  | 7.8 | % |  |  | 5.6 | % |  |  | 7.6 | % |  |  | 5.9 | % |

[0001193125-19-028336:mdna:77]
[same as prior period, unchanged from 0001193125-18-319643:mdna:76]

[0001193125-19-028336:mdna:78]
| (amount in thousands) |  | Three Months Ended |  |  | Six Months Ended |  |
|  | December 28,2018 |  |  | December 29,2017 |  |  | December 28,2018 |  |  | December 29,2017 |  |
| Optical communications |  | $ | 305,547 |  |  | $ | 241,889 |  |  | $ | 586,315 |  |  | $ | 517,501 |  |
| Lasers, sensors and other |  |  | 97,533 |  |  |  | 95,183 |  |  |  | 193,942 |  |  |  | 176,884 |  |
| Total |  | $ | 403,080 |  |  | $ | 337,072 |  |  | $ | 780,257 |  |  | $ | 694,385 |  |

[0001193125-19-028336:mdna:79]
[same as prior period, unchanged from 0001193125-18-319643:mdna:78]

[0001193125-19-028336:mdna:80]
Comparison of Three and Six Months Ended December 28, 2018 with Three and Six Months Ended
December 29, 2017

[0001193125-19-028336:mdna:81]
[same as prior period, unchanged from 0001193125-18-319643:mdna:80]

[0001193125-19-028336:mdna:82]
Our total revenues increased by $66.0 million, or 19.6%, to $403.1 million for the three months ended December 28, 2018,
compared with $337.1 million for the three months ended December 29, 2017. This increase was primarily due to an increase in our customers’ demand for both optical and non-optical communications
manufacturing services during the three months ended December 28, 2018. Revenues from optical and non-optical communications products increased by $63.7 million and $2.3 million, or 26.3% and
2.5%, respectively, for the three months ended December 28, 2018.

[0001193125-19-028336:mdna:83]
Our total revenues increased by $85.9 million, or 12.4%, to
$780.3 million for the six months ended December 28, 2018, compared with $694.4 million for the six months ended December 29, 2017. This increase was primarily due to an increase in our customers’ demand for both optical and
non-optical communications manufacturing services during the six months ended December 28, 2018. Revenues from optical and non-optical communications products
increased by $68.8 million and $17.1million, or 13.3% and 9.6%, respectively, for the six months ended December 28, 2018.

[0001193125-19-028336:mdna:84]
[same as prior period, unchanged from 0001193125-18-319643:mdna:82]

[0001193125-19-028336:mdna:85]
Our
cost of revenues increased by $57.6 million, or 19.2%, to $357.5 million, or 88.7% of total revenues, for the three months ended December 28, 2018, compared with $299.9 million, or 89.0% of total revenues, for the three months
ended December 29, 2017. This increase in cost of revenues was in line with the increase in sales volume.

[0001193125-19-028336:mdna:86]
Our cost of revenues
increased by $77.5 million, or 12.6%, to $694.4 million, or 89.0% of total revenues, for the six months ended December 28, 2018, compared with $616.9 million, or 88.8% of total revenues, for the six months ended December 29,
2017. This increase in cost of revenues was in line with the increase in sales volume.

[0001193125-19-028336:mdna:87]
[same as prior period, unchanged from 0001193125-18-319643:mdna:84]

[0001193125-19-028336:mdna:88]
Our gross profit increased by $8.4 million, or 22.6%, to $45.6 million, or 11.3% of total revenues, for the three months ended
December 28, 2018, compared with $37.2 million, or 11.0% of total revenues, for the three months ended December 29, 2017. The increase was primarily due to an increase in revenue and effective cost controls.

[0001193125-19-028336:mdna:89]
Our gross profit increased by $8.3 million, or 10.8%, to $85.8 million, or 11.0% of total revenues, for the six months ended
December 28, 2018, compared with $77.5 million, or 11.2% of total revenues, for the six months ended December 29, 2017. The increase was primarily due to an increase in revenues.

[0001193125-19-028336:mdna:90]
[same as prior period, unchanged from 0001193125-18-319643:mdna:86]

[0001193125-19-028336:mdna:91]
Our
SG&A expenses decreased by $0.4 million, or 3.3%, to $12.7 million, or 3.2% of total revenues, for the three months ended December 28, 2018, compared with $13.1 million, or 3.9% of total revenues, for the three months ended
December 29, 2017. The decrease was primarily due to (1) a decrease of executive and management expenses of $0.5 million relating to the Executive Chairman who stepped down at the end of June 2018; and (2) a decrease of
share-based compensation expenses of $0.9 million including $0.7 million from a reduction in restricted share-based compensation expenses and $0.2 million from reversal of performance share, partially offset by (1) an increase of
severance liabilities of $0.4 million; and (2) an increase of public company costs and other expenses of $0.7 million.

[0001193125-19-028336:mdna:92]
Our
SG&A expenses decreased by $1.6 million, or 5.8%, to $27.2 million, or 3.5% of total revenues, for the six months ended December 28, 2018, compared with $28.8 million, or 4.1% of total revenues, for the six months ended
December 29, 2017. The decrease was primarily due to (1) a decrease of share-based compensation expenses of $2.8 million including $0.8 million from a reduction in restricted share-based compensation expenses and $2.0 million
from the reversal of performance share units; (2) a decrease of sale and marketing expenses of $0.1 million, partially offset by (1) an increase of severance liabilities of $0.5 million; (2) an increase of consulting
expenses related to executive search of $0.6 million; and (3) an increase of expenses related to new subsidiary in Israel of $0.3 million.

[0001193125-19-028336:mdna:93]
[same as prior period, unchanged from 0001193125-18-319643:mdna:88]

[0001193125-19-028336:mdna:94]
Our operating income increased by $10.3 million to $32.5 million, or 8.1% of total revenues, for the three months ended
December 28, 2018, compared with $22.2 million, or 6.6% of total revenues, for the three months ended December 29, 2017. The increase was primarily due to an increase in gross profit and a decrease of SG&A expenses.

[0001193125-19-028336:mdna:95]
Our operating income increased by $11.4 million to $58.3 million, or 7.5% of total revenues, for the six months ended
December 28, 2018, compared with $46.9 million, or 6.8% of total revenues, for the six months ended December 29, 2017. The increase was primarily due to a decrease of SG&A expenses.

[0001193125-19-028336:mdna:96]
[same as prior period, unchanged from 0001193125-18-319643:mdna:90]

[0001193125-19-028336:mdna:97]
Our
interest income increased by $0.6 million, or 98.3%, to $1.2 million, or 0.3% of total revenues, for the three months ended December 28, 2018, compared with $0.6 million, or 0.2% of total revenues, for the three months ended
December 29, 2017. The increase was primarily due to the higher weighted average interest rate compared to the same period in the last year and an increase in the average balance of our outstanding cash.

[0001193125-19-028336:mdna:98]
Our interest income increased by $1.2 million, or 86.9%, to $2.6 million, or 0.3% of total revenues, for the six months ended
December 28, 2018, compared with $1.4 million, or 0.2% of total revenues, for the six months ended December 29, 2017. The increase was primarily due to the higher weighted average interest rate compared to the same period in the last
year and an increase in the average balance of our outstanding cash.

[0001193125-19-028336:mdna:99]
[same as prior period, unchanged from 0001193125-18-319643:mdna:92]

[0001193125-19-028336:mdna:100]
Our interest expense increased by $0.8 million to $1.6 million for the three months ended December 28, 2018, compared with
$0.8 million for the three months ended December 29, 2017. The increase was due to the unrealized loss of $0.8 million for mark-to-market of interest rate
swap related to our term loan.

[0001193125-19-028336:mdna:101]
Our interest expense increased by $0.6 million to $2.3 million for the six months ended
December 28, 2018, compared with $1.7 million for the six months ended December 29, 2017. The increase was due to the unrealized loss of $0.8 million for
mark-to-market of interest rate swap related to our term loan.

[0001193125-19-028336:mdna:102]
[same as prior period, unchanged from 0001193125-18-319643:mdna:94]

[0001193125-19-028336:mdna:103]
We recorded foreign exchange loss, net of $0.4 million for the three months ended December 28, 2018, compared with $1.3 million
loss for the three months ended December 29, 2017. We recorded foreign exchange gain, net of $2.6 million for the six months ended December 28, 2018, compared with $3.3 million loss for the six months ended December 29,
2017.

[0001193125-19-028336:mdna:104]
[same as prior period, unchanged from 0001193125-18-319643:mdna:96]

[0001193125-19-028336:mdna:105]
We recorded income before income taxes of $32.2 million and $61.9 million for the three and six months ended December 28, 2018,
compared with $20.9 million and $43.7 million for the three and six months ended December 29, 2017, respectively.

[0001193125-19-028336:mdna:106]
[same as prior period, unchanged from 0001193125-18-319643:mdna:98]

[0001193125-19-028336:mdna:107]
Our
provision for income tax reflects an effective tax rate of 4.2% and 6.3% for the three months ended December 28, 2018 and December 29, 2017, respectively. The decrease was primarily due to the fact that we had higher income from no tax
jurisdiction during the second quarter of fiscal year 2019 as compared to the same period in fiscal year 2018.

[0001193125-19-028336:mdna:108]
Our provision for income
tax reflects an effective tax rate of 5.1% and 6.3% for the six months ended December 28, 2018 and December 29, 2017, respectively. The decrease was primarily due to the fact that we had higher income from no tax jurisdiction during the
six months ended December 28, 2018 as compared to the same period in fiscal year 2018.

[0001193125-19-028336:mdna:109]
[same as prior period, unchanged from 0001193125-18-319643:mdna:100]

[0001193125-19-028336:mdna:110]
We recorded net income of $31.5 million, or 7.8% of total revenues, for the three months ended December 28, 2018, compared with
$19.3 million, or 5.7% of total revenues, for the three months ended December 29, 2017. The increase was primarily due to (1) an increase of gross profit of $8.4 million due to increase of revenue and effective cost control;
(2) net decrease of SG&A of $0.4 million; (3) a decrease of expenses related to reduction in workforce of $1.5 million; (4) net decrease of interest income and expense of $0.2 million; and (5) net decrease of
foreign exchange loss of $0.9 million.

[0001193125-19-028336:mdna:111]
We recorded net income of $59.4 million, or 7.6% of total revenues, for the six months
ended December 28, 2018, compared with $40.3 million, or 5.8% of total revenues, for the six months ended December 29, 2017. The increase was primarily due to (1) an increase of gross profit of $8.3 million due to increase
of revenue; (2) net decrease of SG&A of $1.7 million; (3) a decrease of expenses related to reduction in workforce of $1.4 million; (4) net increase of interest income and expense of $0.7 million; and (5) net
decrease of foreign exchange loss of $5.9 million.

[0001193125-19-028336:mdna:112]
[same as prior period, unchanged from 0001193125-18-319643:mdna:102]

[0001193125-19-028336:mdna:113]
We recorded other comprehensive income of $93 thousand, or 0.0% of total revenues, for the three months ended December 28, 2018,
compared with other comprehensive (loss) of $(0.4) million, or (0.1)% of total revenues, for the three months ended December 29, 2017.

[0001193125-19-028336:mdna:114]
We recorded other comprehensive income of $0.2 million, or 0.0% of total revenues, for the six months ended December 28, 2018,
compared with other comprehensive income of $0.1 million, or 0.1% of total revenues, for the six months ended December 29, 2017.

[0001193125-19-028336:mdna:115]
Liquidity
and Capital Resources

[0001193125-19-028336:mdna:116]
Cash Flows and Working Capital

[0001193125-19-028336:mdna:117]
We primarily finance our operations through cash flow from operations. As of December 28, 2018 and December 29, 2017, we had cash,
cash equivalents, and short-term investments of $382.5 million and $284.2 million, respectively, and outstanding debt of $63.4 million and $68.4 million, respectively.

[0001193125-19-028336:mdna:118]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of
three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents for the three and six months ended December 28, 2018 was 1.4% and 1.6% and for the three and six
months ended December 29, 2017 was 1.0%.

[0001193125-19-028336:mdna:119]
Our cash investments are made in accordance with an investment policy approved by the Audit
Committee of our board of directors. In general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years.
Our investments in fixed income securities are primarily classified as available-for-sale and are recorded at fair value. The cost of securities sold is based on the
specific identification method. Unrealized gains and losses on these securities are recorded as other comprehensive income (loss) and are reported as a separate component of shareholders’ equity.

[0001193125-19-028336:mdna:120]
During the six months ended December 28, 2018, we repaid a term loan of $0.8 million under our Facility Agreement; as a result, as
of December 28, 2018, we had a long-term borrowing of $63.4 million under our Facility Agreement. We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these
obligations. To better manage our cash on hand, we held investments in short-term marketable securities and certificates of deposit of $151.5 million as of December 28, 2018.

[0001193125-19-028336:mdna:121]
We believe that our current cash and cash equivalents, short-term investments, cash flow from operations, and funds available through our
credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II,
Item 1A of this Quarterly Report on Form 10-Q.

[0001193125-19-028336:mdna:122]
We also believe that our current
manufacturing capacity is sufficient to meet our anticipated production requirements for at least the next few quarters.

[0001193125-19-028336:mdna:123]
[same as prior period, unchanged from 0001193125-18-319643:mdna:112]

[0001193125-19-028336:mdna:124]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 28,2018 |  |  | December 29,2017 |  |
| Net cash provided by operating activities |  | $ | 69,298 |  |  | $ | 37,113 |  |
| Net cash provided by (used in) investing activities |  | $ | 13,141 |  |  | $ | (20,639 | ) |
| Net cash used in financing activities |  | $ | (13,649 | ) |  | $ | (15,641 | ) |
| Net increase in cash, cash equivalents and restricted cash |  | $ | 68,790 |  |  | $ | 833 |  |

[0001193125-19-028336:mdna:125]
[same as prior period, unchanged from 0001193125-18-319643:mdna:114]

[0001193125-19-028336:mdna:126]
Net cash provided by operating activities increased by $32.2 million, or 86.7%, to $69.3 million for the six months ended
December 28, 2018, compared with net cash provided in operating activities of $37.1 million for the six months ended December 29, 2017. This increase was primarily due to (1) an increase of net income of $19.0 million;
(2) a decrease of $62.9 million in payments to trade accounts payable due to better working capital management; and (3) an increase of income tax payable of $2.7 million. These increases were offset by (1) an increase of
$20.1 million from trade accounts receivable and an increase of inventory of $27.9 million primarily due to an increase of revenues; and (3) an increase of contract assets of $3.5 million.

[0001193125-19-028336:mdna:127]
[same as prior period, unchanged from 0001193125-18-319643:mdna:116]

[0001193125-19-028336:mdna:128]
Net
cash provided by investing activities increased by $33.8 million, or 163.7%, to $13.1 million for the six months ended December 28, 2018, compared with net cash used in investing activities of $20.6 million for the six months
ended December 29, 2017. This increase was primarily due to (1) net cash received from short-term investments of $21.7 million; and (2) a decrease of investments in property, plant and equipment of $11.7 million primarily
due to no new major investments.

[0001193125-19-028336:mdna:129]
[same as prior period, unchanged from 0001193125-18-319643:mdna:118]

[0001193125-19-028336:mdna:130]
Net cash used in financing activities decreased by $2.0 million, or 12.7%, to $13.6 million for the six months ended
December 28, 2018, compared with net cash used by financing activities of $15.6 million for the six months ended December 29, 2017. This decrease was primarily due to (1) a decrease of $2.0 million in net payments of loans
from bank; and (2) a decrease of $10.0 million in payments to repurchase of ordinary shares. These decreases were offset by (1) the release of restricted cash in connection with business acquisition of $3.5 million; (2) an
increase in withholding tax related to net share settlement of restricted share units of $5.4 million; and (3) a decrease in cash received from issuance of ordinary shares under employee share option plans of $1.0 million.

[0001193125-19-028336:mdna:131]
[same as prior period, unchanged from 0001193125-18-319643:mdna:120]

[0001193125-19-028336:mdna:132]
We have not entered into any financial guarantees or other commitments to guarantee the payment obligations of any third parties. In addition,
we have not entered into any derivative contracts that are not reflected in our condensed consolidated financial statements. Furthermore, we do not have any retained or contingent interest in assets transferred to an unconsolidated entity that
serves as credit, liquidity or market risk support to such entity. We also do not have any variable interest in any unconsolidated entity that provides financing, liquidity, market risk or credit support to us or engages in leasing, hedging or
research and development services with us.

[0001193125-19-028336:mdna:133]
[same as prior period, unchanged from 0001193125-18-319643:mdna:122]

[0001193125-19-028336:mdna:134]
See Note 2 of Notes to Condensed Consolidated Financial Statements for recent accounting pronouncements that could have an effect on us.
