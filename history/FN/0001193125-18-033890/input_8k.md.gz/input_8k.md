# FN 8-K — 0001193125-18-032203 filed 2018-02-05

## item codes, every 8-K on or before 2018-02-07

- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2018-02-07

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-18-032203:8k_2_02:1]
EX-99.1
2
d533419dex991.htm
EX-99.1

[0001193125-18-032203:8k_2_02:2]
EX-99.1

[0001193125-18-032203:8k_2_02:3]
Exhibit 99.1

[0001193125-18-032203:8k_2_02:4]
Fabrinet Announces Second Quarter Fiscal Year 2018 Financial Results

[0001193125-18-032203:8k_2_02:5]
BANGKOK, Thailand – February 5, 2018 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision
optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its second quarter ended December 29, 2017.

[0001193125-18-032203:8k_2_02:6]
Tom Mitchell, Executive Chairman of Fabrinet, said, “We are pleased to have exceeded both our revenue and net income guidance for the second quarter. We
are enthusiastic about the fresh perspective Seamus brings to our team for driving opportunities from all our end markets as we look forward.”

[0001193125-18-032203:8k_2_02:7]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “Having recently met with customers worldwide, I am looking forward to extending Fabrinet’s
track record of success. We believe that over the longer-term we remain well-positioned to drive balanced and profitable growth from our core optical communications market as well as other industries that can leverage our precision optical,
electro-mechanical and electronic manufacturing reputation.”

[0001193125-18-032203:8k_2_02:8]
Second Quarter Fiscal Year 2018 Financial Highlights

[0001193125-18-032203:8k_2_02:9]
GAAP Results

[0001193125-18-032203:8k_2_02:10]
|  | • |  | Revenue for the second quarter of fiscal year 2018, was $337.1 million, compared to revenue of $351.2 million for the comparable period in fiscal year 2017. |

[0001193125-18-032203:8k_2_02:11]
|  | • |  | GAAP net income for the second quarter of fiscal year 2018 was $19.3 million, compared to GAAP net income of $25.3 million for the second quarter of fiscal year 2017. GAAP net income for the second quarter of fiscal year 2018 included a foreign exchange loss of $1.3 million, or $0.04 per diluted share, compared to a foreign exchange gain of $1.9 million, or $0.05 per diluted share, for the second quarter of fiscal year 2017. |

[0001193125-18-032203:8k_2_02:12]
|  | • |  | GAAP net income per diluted share for the second quarter of fiscal year 2018 was $0.51, compared to GAAP net income per diluted share of $0.67 for the second quarter of fiscal year 2017. |

[0001193125-18-032203:8k_2_02:13]
Non-GAAP Results

[0001193125-18-032203:8k_2_02:14]
|  | • |  | Non-GAAP net income for the second quarter of fiscal year 2018 was $27.3 million, compared to non-GAAP net income of $34.5 million for the second quarter of fiscal year 2017. |

[0001193125-18-032203:8k_2_02:15]
|  | • |  | Non-GAAP net income per diluted share for the second quarter of fiscal year 2018 was $0.72, a decrease from non-GAAP net income per diluted share of $0.91 for the same period a year ago. Non-GAAP net income for the second quarter of fiscal year 2018 included a foreign exchange loss of $1.3 million, or $0.04 per diluted share. |

[0001193125-18-032203:8k_2_02:16]
Share Repurchase Program Increase

[0001193125-18-032203:8k_2_02:17]
Fabrinet also announced that its Board of Directors has approved the repurchase of up to an additional $30.0 million of Fabrinet’s ordinary shares,
bringing the aggregate authorization under Fabrinet’s existing share repurchase program to $60.0 million. Fabrinet repurchased approximately 316,000 shares of its ordinary shares at an average price of $31.36 during the second quarter.

[0001193125-18-032203:8k_2_02:18]
Business Outlook

[0001193125-18-032203:8k_2_02:19]
Based on information available as
of February 5, 2018, Fabrinet is issuing guidance for its third fiscal quarter ending March 30, 2018, as follows:

[0001193125-18-032203:8k_2_02:20]
|  | • |  | Fabrinet expects third quarter revenue to be in the range of $316 million to $324 million. |

[0001193125-18-032203:8k_2_02:21]
|  | • |  | GAAP net income per diluted share is expected to be in the range of $0.50 to $0.53, based on approximately 37.9 million fully diluted shares outstanding. |

[0001193125-18-032203:8k_2_02:22]
|  | • |  | Non-GAAP net income per diluted share is expected to be in the range of $0.70 to $0.73, based on approximately 37.9 million fully diluted shares outstanding. |

[0001193125-18-032203:8k_2_02:23]
Conference Call Information

[0001193125-18-032203:8k_2_02:24]
| What: |  | Fabrinet Second Quarter Fiscal Year 2018 Financial Results Conference Call |
| When: |  | Monday, February 5, 2018 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic |
|  |  | (253) 237-1137, international |
|  |  | Passcode: 1475796 |
| Replay: |  | (855) 859-2056, domestic |
|  |  | (404) 537-3406, international |
|  |  | Passcode: 1475796 |
| Webcast: |  | http://investor.fabrinet.com (live and replay) |

[0001193125-18-032203:8k_2_02:25]
This press release and any other information related to the call will also be posted on Fabrinet’s website at
http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-18-032203:8k_2_02:26]
About Fabrinet

[0001193125-18-032203:8k_2_02:27]
Fabrinet is a leading provider of
advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive
components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain
management, manufacturing, advanced packaging, integration, final assembly and test. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in
Thailand, the United States of America, the People’s Republic of China and the United Kingdom. For more information visit: www.fabrinet.com.

[0001193125-18-032203:8k_2_02:28]
Forward-Looking Statements

[0001193125-18-032203:8k_2_02:29]
Use of Non-GAAP Financials

[0001193125-18-032203:8k_2_02:30]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful
supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; depreciation of fair value uplift; executive separation costs; expenses
related to our CEO search; amortization of intangibles; business combination expenses; loss (gain) on foreign currency contracts; amortization of debt issuance costs; and restructuring charges. We have excluded these items in order to enhance
investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to
their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001193125-18-032203:8k_2_02:31]
These non-GAAP financial measures are used to: (1) measure company performance against historical results,
(2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001193125-18-032203:8k_2_02:32]
SOURCE: Fabrinet

[0001193125-18-032203:8k_2_02:33]
Investor Contact:

[0001193125-18-032203:8k_2_02:34]
Garo Toomajanian

[0001193125-18-032203:8k_2_02:35]
ir@fabrinet.com

[0001193125-18-032203:8k_2_02:36]
FABRINET

[0001193125-18-032203:8k_2_02:37]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-18-032203:8k_2_02:38]
| (in thousands of U.S. dollars, except share data) |  | December 29,2017 |  |  | June 30,2017 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 134,831 |  |  | $ | 133,825 |  |
| Marketable securities |  |  | 149,403 |  |  |  | 151,450 |  |
| Trade accounts receivable, net |  |  | 258,856 |  |  |  | 264,349 |  |
| Inventory, net |  |  | 239,169 |  |  |  | 238,665 |  |
| Prepaid expenses |  |  | 9,098 |  |  |  | 6,306 |  |
| Other current assets |  |  | 7,974 |  |  |  | 4,159 |  |
| Total current assets |  |  | 799,331 |  |  |  | 798,754 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Restricted cash in connection with business acquisition |  |  | 3,423 |  |  |  | 3,312 |  |
| Property, plant and equipment, net |  |  | 222,539 |  |  |  | 216,881 |  |
| Intangibles, net |  |  | 5,432 |  |  |  | 5,840 |  |
| Goodwill |  |  | 3,933 |  |  |  | 3,806 |  |
| Deferred tax assets |  |  | 3,056 |  |  |  | 2,905 |  |
| Deferred debt issuance costs on revolving loan and other non-current assets |  |  | 223 |  |  |  | 1,577 |  |
| Total non-current assets |  |  | 238,606 |  |  |  | 234,321 |  |
| Total Assets |  | $ | 1,037,937 |  |  | $ | 1,033,075 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Bank borrowings, net of unamortized debt issuance costs |  | $ | 52,443 |  |  | $ | 48,402 |  |
| Trade accounts payable |  |  | 182,166 |  |  |  | 215,262 |  |
| Fixed assets payable |  |  | 5,658 |  |  |  | 8,141 |  |
| Capital lease liability, current portion |  |  | 477 |  |  |  | 344 |  |
| Income tax payable |  |  | 1,185 |  |  |  | 1,976 |  |
| Accrued payroll, bonus and related expenses |  |  | 11,244 |  |  |  | 13,852 |  |
| Accrued expenses |  |  | 17,574 |  |  |  | 9,227 |  |
| Other payables |  |  | 11,089 |  |  |  | 14,068 |  |
| Total current liabilities |  |  | 281,836 |  |  |  | 311,272 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term loan from bank, non-current portion, net of unamortized debt issuance costs |  |  | 15,969 |  |  |  | 22,701 |  |
| Deferred tax liability |  |  | 1,989 |  |  |  | 1,981 |  |
| Capital lease liability, non-current portion |  |  | 756 |  |  |  | 1,024 |  |
| Deferred liability in connection with business acquisition |  |  | 3,423 |  |  |  | 3,312 |  |
| Severance liabilities |  |  | 9,264 |  |  |  | 8,488 |  |
| Other non-current liabilities |  |  | 2,930 |  |  |  | 2,723 |  |
| Total non-current liabilities |  |  | 34,331 |  |  |  | 40,229 |  |
| Total Liabilities |  |  | 316,167 |  |  |  | 351,501 |  |
| Commitments and contingencies (Note 16) |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of December 29, 2017 and June 30, 2017) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 37,597,301 shares and 37,340,496 shares issued, and 37,281,328 shares and 37,340,496 shares outstanding as of December 29, 2017 and June 30, 2017, respectively) |  |  | 376 |  |  |  | 373 |  |
| Additional paid-in capital |  |  | 142,914 |  |  |  | 133,293 |  |
| Less: Treasury stock at cost (315,973 shares and zero shares as of December 29, 2017 and June 30, 2017, respectively) |  |  | (9,910 | ) |  |  | — |  |
| Accumulated other comprehensive (loss) income |  |  | (212 | ) |  |  | (348 | ) |
| Retained earnings |  |  | 588,602 |  |  |  | 548,256 |  |
| Total Shareholders’ Equity |  |  | 721,770 |  |  |  | 681,574 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 1,037,937 |  |  | $ | 1,033,075 |  |

[0001193125-18-032203:8k_2_02:39]
FABRINET

[0001193125-18-032203:8k_2_02:40]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND

[0001193125-18-032203:8k_2_02:41]
COMPREHENSIVE INCOME

[0001193125-18-032203:8k_2_02:42]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (in thousands of U.S. dollars, except per share amounts) |  | December 29,2017 |  |  | December 30,2016 |  |  | December 29,2017 |  |  | December 30,2016 |  |
| Revenues |  | $ | 337,072 |  |  | $ | 351,156 |  |  | $ | 694,385 |  |  | $ | 683,199 |  |
| Cost of revenues |  |  | (299,906 | ) |  |  | (308,110 | ) |  |  | (616,887 | ) |  |  | (600,545 | ) |
| Gross profit |  |  | 37,166 |  |  |  | 43,046 |  |  |  | 77,498 |  |  |  | 82,654 |  |
| Selling, general and administrative expenses |  |  | (13,157 | ) |  |  | (17,651 | ) |  |  | (28,835 | ) |  |  | (33,483 | ) |
| Expenses related to reduction in workforce |  |  | (1,776 | ) |  |  | — |  |  |  | (1,776 | ) |  |  | — |  |
| Operating income |  |  | 22,233 |  |  |  | 25,395 |  |  |  | 46,887 |  |  |  | 49,171 |  |
| Interest income |  |  | 596 |  |  |  | 320 |  |  |  | 1,405 |  |  |  | 757 |  |
| Interest expense |  |  | (826 | ) |  |  | (555 | ) |  |  | (1,679 | ) |  |  | (1,876 | ) |
| Foreign exchange gain (loss), net |  |  | (1,348 | ) |  |  | 1,945 |  |  |  | (3,282 | ) |  |  | 3,602 |  |
| Other income |  |  | 250 |  |  |  | 147 |  |  |  | 347 |  |  |  | 289 |  |
| Income before income taxes |  |  | 20,905 |  |  |  | 27,252 |  |  |  | 43,678 |  |  |  | 51,943 |  |
| Income tax expense |  |  | (1,592 | ) |  |  | (1,960 | ) |  |  | (3,332 | ) |  |  | (3,885 | ) |
| Net income |  |  | 19,313 |  |  |  | 25,292 |  |  |  | 40,346 |  |  |  | 48,058 |  |
| Other comprehensive loss, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in net unrealized loss on marketable securities |  |  | (462 | ) |  |  | (353 | ) |  |  | (432 | ) |  |  | (540 | ) |
| Change in net unrealized loss on derivative instruments |  |  | — |  |  |  | — |  |  |  | (1 | ) |  |  | (158 | ) |
| Change in foreign currency translation adjustment |  |  | 44 |  |  |  | (1,903 | ) |  |  | 569 |  |  |  | (1,162 | ) |
| Total other comprehensive loss, net of tax |  |  | (418 | ) |  |  | (2,256 | ) |  |  | 136 |  |  |  | (1,860 | ) |
| Net comprehensive income |  | $ | 18,895 |  |  | $ | 23,036 |  |  | $ | 40,482 |  |  | $ | 46,198 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.52 |  |  | $ | 0.69 |  |  | $ | 1.08 |  |  | $ | 1.31 |  |
| Diluted |  | $ | 0.51 |  |  | $ | 0.67 |  |  | $ | 1.06 |  |  | $ | 1.28 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 37,477 |  |  |  | 36,848 |  |  |  | 37,462 |  |  |  | 36,626 |  |
| Diluted |  |  | 38,156 |  |  |  | 37,805 |  |  |  | 38,160 |  |  |  | 37,567 |  |

[0001193125-18-032203:8k_2_02:43]
FABRINET

[0001193125-18-032203:8k_2_02:44]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-18-032203:8k_2_02:45]
|  |  | Six Months Ended |  |
| (in thousands of U.S. dollars) |  | December 29,2017 |  |  | December 30,2016 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income for the period |  | $ | 40,346 |  |  | $ | 48,058 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 14,265 |  |  |  | 10,758 |  |
| Loss on disposal of property, plant and equipment |  |  | — |  |  |  | 19 |  |
| Loss from sales and maturities of available-for-sale securities |  |  | 357 |  |  |  | 15 |  |
| Amortization of investment (premium) discount |  |  | (163 | ) |  |  | 228 |  |
| Amortization of deferred debt issuance costs |  |  | 295 |  |  |  | 1,072 |  |
| Allowance for doubtful accounts (reversal) |  |  | 5 |  |  |  | (40 | ) |
| Unrealized loss (gain) on exchange rate and fair value of derivative instruments |  |  | 1,740 |  |  |  | (3,033 | ) |
| Share-based compensation |  |  | 12,378 |  |  |  | 14,208 |  |
| Deferred income tax |  |  | (153 | ) |  |  | 938 |  |
| Other non-cash expenses |  |  | 962 |  |  |  | 586 |  |
| Inventory obsolescence (reversal) |  |  | 654 |  |  |  | (100 | ) |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | 5,707 |  |  |  | (40,779 | ) |
| Inventory |  |  | (1,047 | ) |  |  | (29,286 | ) |
| Other current assets and non-current assets |  |  | (6,801 | ) |  |  | 4,747 |  |
| Trade accounts payable |  |  | (33,626 | ) |  |  | 11,026 |  |
| Income tax payable |  |  | (791 | ) |  |  | 448 |  |
| Other current liabilities and non-current liabilities |  |  | 2,985 |  |  |  | 887 |  |
| Net cash provided by operating activities |  |  | 37,113 |  |  |  | 19,752 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of marketable securities |  |  | (48,679 | ) |  |  | (83,405 | ) |
| Proceeds from sales of marketable securities |  |  | 18,672 |  |  |  | 15,682 |  |
| Proceeds from maturities of marketable securities |  |  | 31,427 |  |  |  | 38,142 |  |
| Payments in connection with business acquisition, net of cash acquired |  |  | — |  |  |  | (9,917 | ) |
| Purchase of property, plant and equipment |  |  | (21,405 | ) |  |  | (44,412 | ) |
| Purchase of intangibles |  |  | (689 | ) |  |  | (319 | ) |
| Proceeds from disposal of property, plant and equipment |  |  | 35 |  |  |  | 127 |  |
| Net cash used in investing activities |  |  | (20,639 | ) |  |  | (84,102 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Proceeds of short-term loans from banks |  |  | 5,000 |  |  |  | 15,744 |  |
| Repayment of short-term loans from bank |  |  | (1,003 | ) |  |  | — |  |
| Repayment of long-term loans from bank |  |  | (6,800 | ) |  |  | (9,800 | ) |
| Repayment of capital lease liability |  |  | (174 | ) |  |  | (92 | ) |
| Repurchase of ordinary shares |  |  | (9,910 | ) |  |  | — |  |
| Proceeds from issuance of ordinary shares under employee share option plans |  |  | 990 |  |  |  | 5,848 |  |
| Withholding tax related to net share settlement of restricted share units |  |  | (3,744 | ) |  |  | (1,008 | ) |
| Net cash (used in) provided by financing activities |  |  | (15,641 | ) |  |  | 10,692 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  |  | 833 |  |  |  | (53,658 | ) |
| Movement in cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 137,137 |  |  |  | 142,804 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash |  |  | 833 |  |  |  | (53,658 | ) |
| Effect of exchange rate on cash, cash equivalents and restricted cash |  |  | 284 |  |  |  | (401 | ) |
| Cash, cash equivalents and restricted cash at end of period |  | $ | 138,254 |  |  | $ | 88,745 |  |
| Non-cash investing and financing activities |  |  |  |  |  |  |  |  |
| Construction, software-related and equipment-related payables |  | $ | 5,658 |  |  | $ | 17,094 |  |

[0001193125-18-032203:8k_2_02:46]
FABRINET

[0001193125-18-032203:8k_2_02:47]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-18-032203:8k_2_02:48]
(Continued)

[0001193125-18-032203:8k_2_02:49]
The following table provides
a reconciliation of cash, cash equivalents and restricted cash reported within the unaudited condensed consolidated balance sheets that sum to the total of same amounts shown in the unaudited condensed consolidated statements of cash flows:

[0001193125-18-032203:8k_2_02:50]
| (amount in thousands) |  | As ofDecember 29,2017 |  |  | As ofDecember 30,2016 |  |
| Cash and cash equivalents |  | $ | 134,831 |  |  | $ | 85,619 |  |
| Restricted cash in connection with business acquisition (non-current assets) |  |  | 3,423 |  |  |  | 3,126 |  |
| Cash, cash equivalents and restricted cash |  | $ | 138,254 |  |  | $ | 88,745 |  |

[0001193125-18-032203:8k_2_02:51]
FABRINET

[0001193125-18-032203:8k_2_02:52]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-18-032203:8k_2_02:53]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 29,2017 |  |  | December 30,2016 |  |  | December 29,2017 |  |  | December 30,2016 |  |
| (in thousands of U.S. dollars, except per share data) |  | Netincome |  |  | Diluted EPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |
| GAAP measures |  |  | 19,313 |  |  |  | 0.51 |  |  |  | 25,292 |  |  |  | 0.67 |  |  |  | 40,346 |  |  |  | 1.06 |  |  |  | 48,058 |  |  |  | 1.28 |  |
| Items reconciling GAAP net (loss) income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,812 |  |  |  | 0.05 |  |  |  | 1,514 |  |  |  | 0.04 |  |  |  | 3,713 |  |  |  | 0.10 |  |  |  | 2,528 |  |  |  | 0.07 |  |
| Depreciation of fair value uplift |  |  | 86 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |  |  | 153 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |
| Cost resulting from a non-recurring warranty charge |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total related to gross profit |  |  | 1,898 |  |  |  | 0.05 |  |  |  | 1,514 |  |  |  | 0.04 |  |  |  | 3,866 |  |  |  | 0.10 |  |  |  | 2,528 |  |  |  | 0.07 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 3,646 |  |  |  | 0.10 |  |  |  | 7,083 |  |  |  | 0.19 |  |  |  | 8,665 |  |  |  | 0.23 |  |  |  | 11,680 |  |  |  | 0.31 |  |
| Executive separation costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 577 |  |  |  | 0.02 |  |
| Expenses related to CEO search |  |  | 204 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 204 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |
| Debt administration expenses |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Amortization of intangibles |  |  | 208 |  |  |  | 0.01 |  |  |  | 229 |  |  |  | 0.01 |  |  |  | 377 |  |  |  | 0.01 |  |  |  | 229 |  |  |  | 0.01 |  |
| Business combination expenses |  |  | 11 |  |  |  | 0.00 |  |  |  | 99 |  |  |  | 0.00 |  |  |  | 117 |  |  |  | 0.00 |  |  |  | 1,510 |  |  |  | 0.04 |  |
| Total related to selling, general and administrative expenses |  |  | 4,069 |  |  |  | 0.11 |  |  |  | 7,411 |  |  |  | 0.20 |  |  |  | 9,362 |  |  |  | 0.25 |  |  |  | 13,996 |  |  |  | 0.37 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss (gain) on foreign currency contracts |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,713 | ) |  |  | (0.05 | ) |
| Other expenses in relation to reduction in workforce |  |  | 1,776 |  |  |  | 0.05 |  |  |  | — |  |  |  | — |  |  |  | 1,776 |  |  |  | 0.05 |  |  |  | — |  |  |  | — |  |
| Amortization of debt issuance costs |  |  | 267 |  |  |  | 0.01 |  |  |  | 281 |  |  |  | 0.01 |  |  |  | 540 |  |  |  | 0.01 |  |  |  | 1,344 |  |  |  | 0.04 |  |
| Total related to other incomes and other expenses |  |  | 2,043 |  |  |  | 0.05 |  |  |  | 281 |  |  |  | 0.01 |  |  |  | 2,316 |  |  |  | 0.06 |  |  |  | (369 | ) |  |  | (0.01 | ) |
| Related to income tax expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-recurring income tax expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total related to income tax expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total related to net income & EPS |  |  | 8,010 |  |  |  | 0.21 |  |  |  | 9,206 |  |  |  | 0.24 |  |  |  | 15,544 |  |  |  | 0.41 |  |  |  | 16,155 |  |  |  | 0.43 |  |
| Non-GAAP measures |  |  | 27,323 |  |  |  | 0.72 |  |  |  | 34,498 |  |  |  | 0.91 |  |  |  | 55,890 |  |  |  | 1.47 |  |  |  | 64,213 |  |  |  | 1.71 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 38,156 |  |  |  |  |  |  |  | 37,805 |  |  |  |  |  |  |  | 38,160 |  |  |  |  |  |  |  | 37,567 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 38,156 |  |  |  |  |  |  |  | 37,805 |  |  |  |  |  |  |  | 38,160 |  |  |  |  |  |  |  | 37,567 |  |

[0001193125-18-032203:8k_2_02:54]
FABRINET

[0001193125-18-032203:8k_2_02:55]
GUIDANCE FOR QUARTER ENDING MARCH 30, 2018

[0001193125-18-032203:8k_2_02:56]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-18-032203:8k_2_02:57]
|  |  | Diluted |  |
|  |  | EPS |  |
| GAAP net income per diluted share: |  | $ | 0.50 to $0.53 |  |
| Related to cost of revenues: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.05 |  |
| Total related to gross profit |  |  | 0.05 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.13 |  |
| Business combination expenses |  |  | 0.01 |  |
| Total related to selling, general and administrative expenses |  |  | 0.14 |  |
| Related to other incomes and other expenses: |  |  |  |  |
| Amortization of debt issuance costs |  |  | 0.01 |  |
| Total related to net income & EPS |  |  | 0.20 |  |
| Non-GAAP net income per diluted share |  | $ | 0.70 to $0.73 |  |
