# FN note change history — 0001193125-17-335712 → 0001193125-18-033890


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2018-02-07):
[0001193125-18-033890:note_history:1]
As of December 29, 2017 and June 30, 2017, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $1.5 million as of both dates.

- changed (2018-02-07):
[0001193125-18-033890:note_history:2]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, New Jersey and the United Kingdom under operating
 lease arrangements that expire in various calendar years through
 2023. Rental expense under these operating leases amounted to
 $0.9 million and $0.8 million for the six months ended
 December 29, 2017 and December 30, 2016,
 respectively.
  (was, 2017-11-07, similarity 0.9393):
[0001193125-17-335712:note_history:2]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, New Jersey and the United Kingdom under operating
 lease arrangements that expire in various calendar years through
 2023. Rental expense under these operating leases amounted to
 $0.5 million and $0.4 million for the three months ended
 September 29, 2017 and September 30, 2016,
 respectively.

- changed (2018-02-07):
[0001193125-18-033890:note_history:3]
As of December 29, 2017, the future minimum lease payments due
 under non-cancelable
 operating leases during each fiscal year were as follows:
  (was, 2017-11-07, similarity 0.9815):
[0001193125-17-335712:note_history:3]
As of September 29, 2017, the future minimum lease payments
 due under non-cancelable
 operating leases during each fiscal year were as follows:

- changed (2018-02-07):
[0001193125-18-033890:note_history:4]
| (amount in thousands) |  |  |  |
| 2018 (remaining six months) |  | $ | 815 |  |
| 2019 |  |  | 1,164 |  |
| 2020 |  |  | 945 |  |
| 2021 |  |  | 543 |  |
| 2022 |  |  | 430 |  |
| Thereafter |  |  | 466 |  |
| Total minimum operating lease payments |  | $ | 4,363 |  |
  (was, 2017-11-07, similarity 0.9838):
[0001193125-17-335712:note_history:4]
| (amount in thousands) |  |  |  |
| 2018 (remaining nine months) |  | $ | 1,295 |  |
| 2019 |  |  | 1,177 |  |
| 2020 |  |  | 956 |  |
| 2021 |  |  | 553 |  |
| 2022 |  |  | 429 |  |
| Thereafter |  |  | 467 |  |
| Total minimum operating lease payments |  | $ | 4,877 |  |

- changed (2018-02-07):
[0001193125-18-033890:note_history:5]
In connection with the acquisition of Fabrinet UK, the Company
 assumed the capital lease commitments of certain machines and
 equipment, with various expiration dates until September 2020. The
 equipment can be purchased at the determined prices upon expiration
 of such contracts.
  (was, 2017-11-07, similarity 0.9982):
[0001193125-17-335712:note_history:5]
In connection with the acquisition of Fabrinet UK, the Company
 assumed the capital lease commitments of certain machine and
 equipment, with various expiration dates until September 2020. The
 equipment can be purchased at the determined prices upon expiration
 of such contracts.

- changed (2018-02-07):
[0001193125-18-033890:note_history:6]
As of December 29, 2017, the future minimum lease payments due
 under non-cancelable
 capital leases during each fiscal year were as follows:
  (was, 2017-11-07, similarity 0.9813):
[0001193125-17-335712:note_history:6]
As of September 29, 2017, the future minimum lease payments
 due under non-cancelable
 capital leases during each fiscal year were as follows:

- changed (2018-02-07):
[0001193125-18-033890:note_history:7]
| (amount in thousands) |  |  |  |
| 2018 (remaining six months) |  | $ | 239 |  |
| 2019 |  |  | 464 |  |
| 2020 |  |  | 422 |  |
| 2021 |  |  | 108 |  |
| Total minimum capital lease payments |  | $ | 1,233 |  |
  (was, 2017-11-07, similarity 0.9856):
[0001193125-17-335712:note_history:7]
| (amount in thousands) |  |  |  |
| 2018 (remaining nine months) |  | $ | 324 |  |
| 2019 |  |  | 458 |  |
| 2020 |  |  | 421 |  |
| 2021 |  |  | 107 |  |
| Total minimum capital lease payments |  | $ | 1,310 |  |

- changed (2018-02-07):
[0001193125-18-033890:note_history:8]
On December 23, 2016, the Company entered into an agreement to
 purchase a parcel of land in Chonburi, Thailand, to support the
 expansion of the Company’s production in Thailand. The
 aggregate purchase price is approximately $5.6 million, of
 which the first installment of $1.1 million was paid by the
 Company on January 10, 2017 and the remaining balance of the
 purchase price was paid by the Company on December 25,
 2017.
  (was, 2017-11-07, similarity 0.8853):
[0001193125-17-335712:note_history:8]
On December 23, 2016, the Company entered into an agreement to
 purchase a parcel of land in Chonburi, Thailand, to support the
 expansion of the Company’s production in Thailand. The
 aggregate purchase price is approximately $5.6 million, of
 which the first installment of $1.1 million was paid by the
 Company on January 10, 2017. The Company expects to pay the
 remaining balance of the purchase price on or before
 December 25, 2017.

- changed (2018-02-07):
[0001193125-18-033890:note_history:9]
As of December 29, 2017, the Company had an outstanding
 commitment to third parties of approximately $7.1 million.
  (was, 2017-11-07, similarity 0.7003):
[0001193125-17-335712:note_history:9]
As of September 29, 2017, the Company had an outstanding
 commitment to third parties of approximately $11.1 million, of
 which $4.5 million was from the commitment to purchase land in
 Chonburi, Thailand.

- removed (2018-02-07):
[0001193125-17-335712:note_history:10]
As of September 29, 2017 and June 30, 2017, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $1.5 million as of both dates.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-02-07):
[0001193125-18-033890:note_history:11]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of December 29, 2017 and for the
 three and six months ended December 29, 2017 and
 December 30, 2016 includes normal recurring adjustments,
 necessary for a fair presentation of the financial statements set
 forth herein, in accordance with accounting principles generally
 accepted in the United States of America (“U.S. GAAP”)
 for interim financial information and the rules and regulations of
 the Securities and Exchange Commission (“SEC”).
 Accordingly, such information does not include all of the
 information and footnotes required by U.S. GAAP for annual
 financial statements. For further information, please refer to the
 consolidated financial statements and footnotes thereto included in
 Fabrinet’s Annual Report on Form 10-K for the year ended June 30,
 2017.
  (was, 2017-11-07, similarity 0.9539):
[0001193125-17-335712:note_history:11]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of September 29, 2017 and for the
 three months ended September 29, 2017 and September 30,
 2016 includes normal recurring adjustments, necessary for a fair
 statement of the financial statements set forth herein, in
 accordance with accounting principles generally accepted in the
 United States of America (“U.S. GAAP”) for interim
 financial information and the rules and regulations of the
 Securities and Exchange Commission (“SEC”).
 Accordingly, such information does not include all of the
 information and footnotes required by U.S. GAAP for annual
 financial statements. For further information, please refer to the
 consolidated financial statements and footnotes thereto included in
 Fabrinet’s Annual Report on Form 10-K for the year ended June 30,
 2017.

- changed (2018-02-07):
[0001193125-18-033890:note_history:12]
The balance sheet as of June 30, 2017 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three and six
 months ended December 29, 2017 may not be indicative of
 results for the year ending June 29, 2018 or any future
 periods.
  (was, 2017-11-07, similarity 0.9425):
[0001193125-17-335712:note_history:12]
The balance sheet as of June 30, 2017 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three months
 ended September 29, 2017 may not be indicative of results for
 the year ending June 29, 2018 or any future periods.

- changed (2018-02-07):
[0001193125-18-033890:note_history:13]
On September 14, 2016, the Company acquired 100% shareholding
 in Global CEM Solutions, Ltd. and all of its subsidiaries
 (including Fabrinet UK), a privately-held group located
 in Wiltshire, United Kingdom. The unaudited condensed
 consolidated financial statements of the Company include the
 financial position, results of operations and the cash flows of
 Fabrinet UK commencing as of the acquisition date. See Note
 8—Business acquisition for further details on the accounting
 for this transaction.
  (was, 2017-11-07, similarity 0.9949):
[0001193125-17-335712:note_history:13]
On September 14, 2016, the Company acquired 100% shareholding
 in Global CEM Solutions, Ltd. and all of its subsidiaries
 (including Fabrinet UK), a privately-held group located
 in Wiltshire, United Kingdom . The unaudited condensed
 consolidated financial statements of the Company include the
 financial position, results of operations and the cash flows of
 Fabrinet UK commencing as of the acquisition date. See Note 8 -
 Business acquisition for further details on the accounting for this
 transaction.

- changed (2018-02-07):
[0001193125-18-033890:note_history:14]
The Company utilizes a 52-53 week fiscal year ending on the
 Friday in June closest to June 30. The three months ended
 December 29, 2017 and December 30, 2016 each consisted of
 13 weeks. The six months ended December 29, 2017 and
 December 30, 2016 consisted of 26 weeks and 27 weeks,
 respectively. Fiscal year 2018 will be comprised of 52 weeks and
 will end on June 29, 2018.
  (was, 2017-11-07, similarity 0.6288):
[0001193125-17-335712:note_history:14]
The Company utilizes a 52-53 week fiscal year ending on the
 Friday in June closest to June 30. The three months ended
 September 29, 2017 and September 30, 2016 consisted of 13
 weeks and 14 weeks, respectively. Fiscal year 2018 will be
 comprised of 52 weeks and will end on June 29, 2018.

- changed (2018-02-07):
[0001193125-18-033890:note_history:15]
Financial instruments that potentially subject the Company to
 concentrations of credit risk consist of cash and cash equivalents,
 marketable securities, derivatives and accounts receivable.
  (was, 2017-11-07, similarity 0.9974):
[0001193125-17-335712:note_history:15]
Financial instruments that potentially subject the Company to
 concentrations of credit risk consist of cash and cash equivalents,
 marketable securities, derivatives, and accounts receivable.

- changed (2018-02-07):
[0001193125-18-033890:note_history:16]
Cash, cash equivalents and marketable securities are maintained
 with several financial institutions. Deposits held with banks may
 exceed the amount of insurance provided on such deposits.
 Generally, these deposits may be redeemed upon demand and are
 maintained with financial institutions with reputable credit and
 therefore bear minimal credit risk. The Company seeks to mitigate
 its credit risks by spreading such risks across multiple
 counterparties and monitoring the risk profiles of these
 counterparties. The Company limits its investments in marketable
 securities to securities with a maturity not in excess of three
 years, and all marketable securities that the Company invests in
 are rated A1, P-1, F1, or
 better.
  (was, 2017-11-07, similarity 0.9993):
[0001193125-17-335712:note_history:16]
Cash, cash equivalents, and marketable securities are maintained
 with several financial institutions. Deposits held with banks may
 exceed the amount of insurance provided on such deposits.
 Generally, these deposits may be redeemed upon demand and are
 maintained with financial institutions with reputable credit and
 therefore bear minimal credit risk. The Company seeks to mitigate
 its credit risks by spreading such risks across multiple
 counterparties and monitoring the risk profiles of these
 counterparties. The Company limits its investments in marketable
 securities to securities with a maturity not in excess of three
 years, and all marketable securities that the Company invests in
 are rated A1, P-1, F1, or
 better.

- added (2018-02-07):
[0001193125-18-033890:note_history:17]
In November 2017, the Financial Accounting Standards Board
 (“FASB”) issued Accounting Standards Update
 (“ASU”) 2017-14, “Income Statement
 – Reporting Comprehensive Income (Topic 220), Revenue
 Recognition (Topic 605), and Revenue from Contracts with Customers
 (Topic 606): Amendments to SEC Paragraphs Pursuant to the Staff
 Accounting Bulletin (“SAB”) No. 116 and SEC
 Release No. 33-10403”. This ASU
 amended, superseded and added certain SEC paragraphs in Topic 220,
 Topic 605 and Topic 606 to reflect the August 2017 issuance of SEC
 Staff Accounting Bulletin (SAB) 116 and SEC Release No. 33-10403. The SEC staff
 issued SAB 116 to align its revenue guidance with Accounting
 Standards Codification (ASC) 606. For public business entities,
 this update is effective for fiscal years beginning after
 December 15, 2017, including interim periods within those
 fiscal years. Early application is permitted. The Company is
 currently evaluating the impact of the adoption of this update on
 its consolidated financial statements.

- changed (2018-02-07):
[0001193125-18-033890:note_history:18]
In September 2017, the FASB issued ASU 2017-13, “Revenue Recognition
 (Topic 605), Revenue from Contracts with Customers (Topic 606),
 Leases (Topic 840), and Leases (Topic 842): Amendments to SEC
 Paragraphs Pursuant to the Staff Announcement at the July 20,
 2017 EITF Meeting and Rescission of Prior SEC Staff Announcements
 and Observer Comments.” The amendment delays the mandatory
 adoption of Topic 606 and Topic 842 for certain entities, revises
 the guidance related to performance-based incentive fees in Topic
 605 and revises the guidance related to leases in Topic 840 and
 Topic 842. The revisions to the lease guidance eliminate language
 specific to certain sale-leaseback arrangements, guarantees of
 lease residual assets and loans made by lessees to owner-lessors.
 Also included is an amendment to Topic 842 to retain the guidance
 in Topic 840 covering the impact of changes in tax rates on
 investments in leveraged leases. This guidance, which is effective
 immediately, generally relates to the adoption of Topic 606 and
 Topic 842. The Company does not expect the amendments will impact
 its consolidated financial statements.
  (was, 2017-11-07, similarity 0.9561):
[0001193125-17-335712:note_history:18]
In September 2017, the Financial Accounting Standards Board
 (“FASB”) issued Accounting Standards Update
 (“ASU”) 2017-13, “Revenue Recognition
 (Topic 605), Revenue from Contracts with Customers (Topic 606),
 Leases (Topic 840), and Leases (Topic 842): Amendments to SEC
 Paragraphs Pursuant to the Staff Announcement at the July 20,
 2017 EITF Meeting and Rescission of Prior SEC Staff Announcements
 and Observer Comments.” The amendment delays the mandatory
 adoption of Topic 606 and Topic 842 for certain entities, revises
 the guidance related to performance-based incentive fees in Topic
 605 and revises the guidance related to leases in Topic 840 and
 Topic 842. The revisions to the lease guidance eliminate language
 specific to certain sale-leaseback arrangements, guarantees of
 lease residual assets and loans made by lessees to owner-lessors.
 Also included is an amendment to Topic 842 to retain the guidance
 in Topic 840 covering the impact of changes in tax rates on
 investments in leveraged leases. This guidance, which is effective
 immediately, generally relates to the adoption of Topic 606 and
 Topic 842. The Company does not expect the amendments will impact
 its consolidated financial statements.

- changed (2018-02-07):
[0001193125-18-033890:note_history:19]
In August 2017, the FASB issued ASU 2017-12, “Derivatives and
 Hedging (Topic 815): Targeted Improvements to Accounting for
 Hedging Activities.” The amendments better align an
 entity’s risk management activities and financial reporting
 for hedging relationships through changes to both the designation
 and measurement guidance for qualifying hedging relationships and
 the presentation of hedge results. To meet that objective, the
 amendments expand and refine hedge accounting for both nonfinancial
 and financial risk components and align the recognition and
 presentation of the effects of the hedging instrument and the
 hedged item in the financial statements. The amendments also make
 certain targeted improvements to simplify the application of hedge
 accounting guidance and ease the administrative burden of hedge
 documentation requirements and assessing hedge effectiveness. This
 ASU is the final version of Proposed Accounting Standards Update
 2016-310—Derivatives
 and Hedging (Topic 815): Targeted Improvements to Accounting for
 Hedging Activities, which has been deleted. During the first six
 months of fiscal year 2017, the Company adopted this update with no
 impact to the unaudited condensed consolidated financial
 statements.
  (was, 2017-11-07, similarity 0.9806):
[0001193125-17-335712:note_history:19]
In August 2017, the FASB issued ASU 2017-12, “Derivatives and
 Hedging (Topic 815): Targeted Improvements to Accounting for
 Hedging Activities.” The amendments better align an
 entity’s risk management activities and financial reporting
 for hedging relationships through changes to both the designation
 and measurement guidance for qualifying hedging relationships and
 the presentation of hedge results. To meet that objective, the
 amendments expand and refine hedge accounting for both nonfinancial
 and financial risk components and align the recognition and
 presentation of the effects of the hedging instrument and the
 hedged item in the financial statements. The amendments also make
 certain targeted improvements to simplify the application of hedge
 accounting guidance and ease the administrative burden of hedge
 documentation requirements and assessing hedge effectiveness. This
 ASU is the final version of Proposed Accounting Standards Update
 2016-310—Derivatives
 and Hedging (Topic 815): Targeted Improvements to Accounting for
 Hedging Activities, which has been deleted. In the first quarter of
 fiscal year 2017, the Company adopted this update with no impact to
 the unaudited condensed consolidated financial statements.

- changed (2018-02-07):
[0001193125-18-033890:note_history:20]
In November 2016, the FASB issued ASU 2016-18, “Statement of Cash
 Flows (Topic 230): Restricted Cash,” which requires the
 statement of cash flows to explain the change during the period in
 the total of cash, cash equivalents and restricted cash or
 restricted cash equivalents. The Company has early adopted this
 update in the second quarter of fiscal year 2017 on a retrospective
 basis. As of December 30, 2016, restricted cash in connection
 with business acquisition of $3.1 million was presented in the
 statement of cash flows as cash, cash equivalents and restricted
 cash.
  (was, 2017-11-07, similarity 0.9937):
[0001193125-17-335712:note_history:20]
In November 2016, the FASB issued ASU 2016-18, “Statement of Cash
 Flows (Topic 230): Restricted Cash,” which requires the
 statement of cash flows to explain the change during the period in
 the total of cash, cash equivalents and restricted cash or
 restricted cash equivalents. The Company has early adopted this
 update in the second quarter of fiscal year 2017 on a retrospective
 basis. As of September 30, 2016, restricted cash in connection
 with business acquisition of $3.3 million was presented in the
 statement of cash flows as cash, cash equivalents and restricted
 cash.

- changed (2018-02-07):
[0001193125-18-033890:note_history:21]
In March 2016, the FASB issued ASU 2016-09, “Compensation
 – Stock Compensation (Topic 718): Improvements to Employee
 Share-Based Payment Accounting.” This ASU simplifies several
 aspects of the accounting for share-based payment award
 transactions, including, the income tax consequences,
 classification of awards as either equity or liabilities and
 classification on the statement of cash flows. The amendments in
 this update are effective for annual periods beginning after
 December 15, 2016, and interim periods within those annual
 periods, for public companies. Early adoption is permitted for any
 entity in any interim or annual period. During the first six months
 of fiscal year 2018, the Company adopted this update with no impact
 to the unaudited condensed consolidated financial statements.
  (was, 2017-11-07, similarity 0.9696):
[0001193125-17-335712:note_history:21]
In March 2016, the FASB issued ASU 2016-09, “Compensation
 – Stock Compensation (Topic 718): Improvements to Employee
 Share-Based Payment Accounting.” This ASU simplifies several
 aspects of the accounting for share-based payment award
 transactions, including, the income tax consequences,
 classification of awards as either equity or liabilities and
 classification on the statement of cash flows. The amendments in
 this update are effective for annual periods beginning after
 December 15, 2016, and interim periods within those annual
 periods, for public companies. Early adoption is permitted for any
 entity in any interim or annual period. In the first quarter of
 fiscal year 2018, the Company adopted this update with no impact to
 the unaudited condensed consolidated financial statements.

- changed (2018-02-07):
[0001193125-18-033890:note_history:22]
In March 2016, the FASB issued ASU 2016-05, “Derivatives and
 Hedging (Topic 815),” to clarify that a change in the
 counterparty to a derivative instrument that has been designated as
 a hedging instrument under Topic 815, does not, in and of itself,
 require designation of the hedging relationship, provided that all
 other hedge accounting criteria continue to be met. This guidance
 is effective for public entities for financial statements issued
 for fiscal years beginning after December 15, 2016 and interim
 periods within those fiscal years. During the first six months of
 fiscal year 2018, the Company adopted this update with no impact to
 the unaudited condensed consolidated financial statements.
  (was, 2017-11-07, similarity 0.9652):
[0001193125-17-335712:note_history:22]
In March 2016, the FASB issued ASU 2016-05, “Derivatives and
 Hedging (Topic 815),” to clarify that a change in the
 counterparty to a derivative instrument that has been designated as
 a hedging instrument under Topic 815, does not, in and of itself,
 require designation of the hedging relationship, provided that all
 other hedge accounting criteria continue to be met. This guidance
 is effective for public entities for financial statements issued
 for fiscal years beginning after December 15, 2016 and interim
 periods within those fiscal years. In the first quarter of fiscal
 year 2018, the Company adopted this update with no impact to the
 unaudited condensed consolidated financial statements.

- removed (2018-02-07):
[0001193125-17-335712:note_history:23]
Where necessary, comparative figures have been reclassified to
 conform to the current period accounting policies and presentation
 adopted.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-07):
[0001193125-18-033890:note_history:24]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  |  | Maturity |  |  | As of December 29, 2017 |  |  | As of June 30, 2017 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR(1) + 1.75% per annum |  |  | Repayable in 1 to 6 months |  |  |  | January 2018(2) |  |  | $ | 39,000 |  |  | $ | 34,000 |  |
| Short-term loans from bank: |  |
| Bank Base rate +1.85% per annum |  |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  |  |  |  | — |  |  |  | 1,003 |  |
| Current portion of long-term borrowing |  |  |  | 13,600 |  |  |  | 13,600 |  |
|  |  |  |  | 52,600 |  |  |  | 48,603 |  |
| Less: Unamortized debt issuance costs |  |  |  | (157 | ) |  |  | (201 | ) |
|  |  |  |  |  |  |  |  |  |  | $ | 52,443 |  |  | $ | 48,402 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  |  | Repayable in quarterly installments |  |  |  | May 2019 |  |  | $ | 29,600 |  |  | $ | 36,400 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (13,600 | ) |  |  | (13,600 | ) |
| Unamortized debt issuance costs |  |  |  | (31 | ) |  |  | (99 | ) |
| Non-current portion |  |  |  |  |  |  |  |  |  | $ | 15,969 |  |  | $ | 22,701 |  |
  (was, 2017-11-07, similarity 0.8045):
[0001193125-17-335712:note_history:24]
|  |  |  |  |  |  | As of |  |  | As of |  |
| (amount in thousands) |  |  |  |  |  | September 29, |  |  | June 30, |  |
| Rate (1) |  | Conditions |  | Maturity |  | 2017 |  |  | 2017 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  | October 2017 (2) |  | $ | 34,000 |  |  | $ | 34,000 |  |
| Short-term loans from bank: |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank Base rate +1.85% per annum |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  | — |  |  |  | 1,003 |  |
| Current portion of long-term borrowing |  |  |  |  |  |  | 13,600 |  |  |  | 13,600 |  |
|  |  |  |  |  |  |  | 47,600 |  |  |  | 48,603 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (179 | ) |  |  | (201 | ) |
|  |  |  |  |  |  | $ | 47,421 |  |  | $ | 48,402 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  | Repayable in quarterly installments |  | May 2019 |  | $ | 33,000 |  |  | $ | 36,400 |  |
|  |  |  |  |  |  |  | 33,000 |  |  |  | 36,400 |  |
| Less: Current portion |  |  |  |  |  |  | (13,600 | ) |  |  | (13,600 | ) |
| Unamortized debt issuance costs |  |  |  |  |  |  | (62 | ) |  |  | (99 | ) |
| Non-current portion |  |  |  |  |  | $ | 19,338 |  |  | $ | 22,701 |  |

- changed (2018-02-07):
[0001193125-18-033890:note_history:25]
| (2) | In December 2017, the maturity date was extended to January 2018. |
  (was, 2017-11-07, similarity 0.8741):
[0001193125-17-335712:note_history:25]
| (2) | In September 2017, the maturity date was extended to October 2017. |

- changed (2018-02-07):
[0001193125-18-033890:note_history:26]
The movements of long-term loans for the six months ended
 December 29, 2017 and December 30, 2016 were as
 follows:
  (was, 2017-11-07, similarity 0.91):
[0001193125-17-335712:note_history:26]
The movement of long-term loans for the three months ended
 September 29, 2017 and September 30, 2016 were as
 follows:

- changed (2018-02-07):
[0001193125-18-033890:note_history:27]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 29, 2017 |  |  | December 30, 2016 |  |
| Opening balance |  | $ | 36,400 |  |  | $ | 54,500 |  |
| Repayments during the period |  |  | (6,800 | ) |  |  | (9,800 | ) |
| Closing balance |  | $ | 29,600 |  |  | $ | 44,700 |  |
  (was, 2017-11-07, similarity 0.887):
[0001193125-17-335712:note_history:27]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 29, 2017 |  |  | September 30, 2016 |  |
| Opening balance |  | $ | 36,400 |  |  | $ | 54,500 |  |
| Repayments during the period |  |  | (3,400 | ) |  |  | (4,900 | ) |
| Closing balance |  | $ | 33,000 |  |  | $ | 49,600 |  |

- changed (2018-02-07):
[0001193125-18-033890:note_history:28]
As of December 29, 2017, future maturities of long-term debt
 during each fiscal year were as follows:
  (was, 2017-11-07, similarity 0.9738):
[0001193125-17-335712:note_history:28]
As of September 29, 2017, future maturities of long-term debt
 during each fiscal year were as follows:

- changed (2018-02-07):
[0001193125-18-033890:note_history:29]
| (amount in thousands) |  |  |  |
| 2018 (remaining six months) |  | $ | 6,800 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 29,600 |  |
  (was, 2017-11-07, similarity 0.9774):
[0001193125-17-335712:note_history:29]
| (amount in thousands) |  |  |  |
| 2018 (remaining nine months) |  | $ | 10,200 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 33,000 |  |

- added (2018-02-07):
[0001193125-18-033890:note_history:30]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. On
 July 22, 2016, the Company entered into the Fourth Amendment
 to the Facility Agreement to change the timing of filing certain
 financial information with the bank. The Company fully drew
 down the term loan facility in fiscal year 2016. As of
 December 29, 2017, $39.0 million of the revolving
 borrowing and $29.6 million of the term loan borrowing was
 outstanding under the Facility Agreement, resulting in available
 credit facilities of $111.0 million. Borrowings under the
 revolving credit facility are classified as current liabilities in
 the unaudited condensed consolidated balance sheets as the Company
 has the periodic option to renew or pay, all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. During December 2017, the
 Company sent notices to the bank to renew the maturity date of its
 revolving borrowings. The bank approved the notices and extended
 the maturity to January 2018.

- changed (2018-02-07):
[0001193125-18-033890:note_history:31]
On July 24, 2017, the Company entered into an interest rate
 swap agreement (the “Swap Agreement”), which the
 Company did not designate as hedging instruments. The Swap
 Agreement was used to mitigate interest rate risk and improve the
 interest rate profile of the Company’s debt obligations. The
 terms of the Swap Agreement effectively convert the floating
 interest rate of the term loans under the Facility Agreement to the
 fixed interest rate of 1.55% per annum through maturity of the term
 loan in May 2019. The swap transactions are due and settled
 monthly. During the six months ended December 29, 2017,
 the Company included a net loss of $23.0 thousand from the
 settlement of the Swap Agreement as interest expenses in the
 unaudited condensed consolidated statements of operations and
 comprehensive income.
  (was, 2017-11-07, similarity 0.9721):
[0001193125-17-335712:note_history:31]
On July 24, 2017, the Company entered into an interest rate
 swap agreement (the “Swap Agreement”), which the
 Company did not designate as hedging instruments. The Swap
 Agreement was used to mitigate interest rate risk and improve the
 interest rate profile of the Company’s debt obligations. The
 terms of the Swap Agreement effectively convert the floating
 interest rate of the term loans under the Facility Agreement to the
 fixed interest rate of 1.55% per annum through maturity of the term
 loan in May 2019. The swap transactions are due and settled
 monthly. During the three month ended September 29, 2017,
 the Company included net loss of $20 thousand from the
 settlement of the Swap Agreement as interest expenses in the
 unaudited condensed consolidated statements of operations and
 comprehensive income.

- changed (2018-02-07):
[0001193125-18-033890:note_history:32]
The Facility Agreement contains customary affirmative and negative
 covenants. Negative covenants include, among other things,
 limitations on liens, indebtedness, investments, mergers, sales of
 assets, changes in the nature of the business, dividends and
 distributions, affiliate transactions and capital expenditures. The
 Facility Agreement contains financial covenants requiring Fabrinet
 to maintain: (1) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (2) a minimum debt service coverage ratio of
 not less than 1.50:1.00; (3) a maximum senior leverage ratio of not
 more than 2.50:1.00; and (4) a minimum quick ratio of not less
 than 1.10:1.00. Each of these financial covenants is calculated on
 a consolidated basis for the consecutive four fiscal quarter period
 then ended. As of December 29, 2017, the Company was in
 compliance with all covenants under the Facility Agreement.
  (was, 2017-11-07, similarity 0.9962):
[0001193125-17-335712:note_history:32]
The Facility Agreement contains customary affirmative and negative
 covenants. Negative covenants include, among other things,
 limitations on liens, indebtedness, investments, mergers, sales of
 assets, changes in the nature of the business, dividends and
 distributions, affiliate transactions and capital expenditures. The
 Facility Agreement contains financial covenants requiring Fabrinet
 to maintain: (1) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (2) a minimum debt service coverage ratio of
 not less than 1.50:1.00; (3) a maximum senior leverage ratio of not
 more than 2.50:1.00; and (4) a minimum quick ratio of not less
 than 1.10:1.00. Each of these financial covenants is calculated on
 a consolidated basis for the consecutive four fiscal quarter period
 then ended. As of September 29, 2017, the Company was in
 compliance with all covenants under the Facility Agreement.

- changed (2018-02-07):
[0001193125-18-033890:note_history:33]
In connection with the business acquisition in the first quarter of
 fiscal year 2017, the Company assumed a secured borrowing
 agreement. In the first quarter of fiscal year 2018, the Company
 fully repaid these short-term loans and sent a notification letter
 to the bank to terminate this secured borrowing agreement. As a
 result, the bank released secured trade accounts receivable and the
 way chattels mortgage over the plant and machine of Fabrinet
 UK.
  (was, 2017-11-07, similarity 0.9633):
[0001193125-17-335712:note_history:33]
In connection with the business acquisition in the first quarter of
 fiscal year 2017, the Company assumed a secured borrowing
 agreement. In the first quarter of fiscal year 2018, the Company
 fully repaid these short-term loans and sent a notification letter
 to the bank to terminate this secured borrowing agreement. As a
 result, the bank released secured trade accounts receivable and the
 way chattels mortgage over the plant and machine of Fabrinet UK
 (formerly known as Exception EMS).

- changed (2018-02-07):
[0001193125-18-033890:note_history:34]
Undrawn available credit facilities classified by availability
 period of future borrowing as of December 29, 2017 and
 June 30, 2017 were as follows:
  (was, 2017-11-07, similarity 0.9819):
[0001193125-17-335712:note_history:34]
Undrawn available credit facilities classified by availability
 period of future borrowing as of September 29, 2017 and
 June 30, 2017 were as follows:

- changed (2018-02-07):
[0001193125-18-033890:note_history:35]
| (amount in thousands) |  | December 29, 2017 |  |  | June 30, 2017 |  |
| Short-term |  | $ | — |  |  | $ | 1,965 |  |
| Long-term |  | $ | 111,000 |  |  | $ | 116,000 |  |
  (was, 2017-11-07, similarity 0.9817):
[0001193125-17-335712:note_history:35]
| (amount in thousands) |  | September 29, 2017 |  |  | June 30, 2017 |  |
| Short-term |  | $ | — |  |  | $ | 1,965 |  |
| Long-term |  | $ | 116,000 |  |  | $ | 116,000 |  |

- removed (2018-02-07):
[0001193125-17-335712:note_history:36]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. The
 Company fully drew down the term loan facility in fiscal year 2016.
 As of September 29, 2017, $34.0 million of the revolving
 borrowing and $33.0 million of the term loan borrowing was
 outstanding under the Facility Agreement, resulting in available
 credit facilities of $116.0 million. Borrowings under the
 revolving credit facility are classified as current liabilities in
 the unaudited condensed consolidated balance sheets as the Company
 has the periodic option to renew or pay, all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. During September 2017, the
 Company sent notices to the bank to renew the maturity date of its
 revolving borrowings. The bank approved the notices and extended
 the maturity to October 2017.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-07):
[0001193125-18-033890:note_history:37]
The movements of long-term loans for the six months ended
 December 29, 2017 and December 30, 2016 were as
 follows:
  (was, 2017-11-07, similarity 0.91):
[0001193125-17-335712:note_history:37]
The movement of long-term loans for the three months ended
 September 29, 2017 and September 30, 2016 were as
 follows:

- changed (2018-02-07):
[0001193125-18-033890:note_history:38]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 29, 2017 |  |  | December 30, 2016 |  |
| Opening balance |  | $ | 36,400 |  |  | $ | 54,500 |  |
| Repayments during the period |  |  | (6,800 | ) |  |  | (9,800 | ) |
| Closing balance |  | $ | 29,600 |  |  | $ | 44,700 |  |
  (was, 2017-11-07, similarity 0.887):
[0001193125-17-335712:note_history:38]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 29, 2017 |  |  | September 30, 2016 |  |
| Opening balance |  | $ | 36,400 |  |  | $ | 54,500 |  |
| Repayments during the period |  |  | (3,400 | ) |  |  | (4,900 | ) |
| Closing balance |  | $ | 33,000 |  |  | $ | 49,600 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-07):
[0001193125-18-033890:note_history:39]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  |  | Maturity |  |  | As of December 29, 2017 |  |  | As of June 30, 2017 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR(1) + 1.75% per annum |  |  | Repayable in 1 to 6 months |  |  |  | January 2018(2) |  |  | $ | 39,000 |  |  | $ | 34,000 |  |
| Short-term loans from bank: |  |
| Bank Base rate +1.85% per annum |  |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  |  |  |  | — |  |  |  | 1,003 |  |
| Current portion of long-term borrowing |  |  |  | 13,600 |  |  |  | 13,600 |  |
|  |  |  |  | 52,600 |  |  |  | 48,603 |  |
| Less: Unamortized debt issuance costs |  |  |  | (157 | ) |  |  | (201 | ) |
|  |  |  |  |  |  |  |  |  |  | $ | 52,443 |  |  | $ | 48,402 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  |  | Repayable in quarterly installments |  |  |  | May 2019 |  |  | $ | 29,600 |  |  | $ | 36,400 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (13,600 | ) |  |  | (13,600 | ) |
| Unamortized debt issuance costs |  |  |  | (31 | ) |  |  | (99 | ) |
| Non-current portion |  |  |  |  |  |  |  |  |  | $ | 15,969 |  |  | $ | 22,701 |  |
  (was, 2017-11-07, similarity 0.8045):
[0001193125-17-335712:note_history:39]
|  |  |  |  |  |  | As of |  |  | As of |  |
| (amount in thousands) |  |  |  |  |  | September 29, |  |  | June 30, |  |
| Rate (1) |  | Conditions |  | Maturity |  | 2017 |  |  | 2017 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  | October 2017 (2) |  | $ | 34,000 |  |  | $ | 34,000 |  |
| Short-term loans from bank: |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank Base rate +1.85% per annum |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  | — |  |  |  | 1,003 |  |
| Current portion of long-term borrowing |  |  |  |  |  |  | 13,600 |  |  |  | 13,600 |  |
|  |  |  |  |  |  |  | 47,600 |  |  |  | 48,603 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (179 | ) |  |  | (201 | ) |
|  |  |  |  |  |  | $ | 47,421 |  |  | $ | 48,402 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  | Repayable in quarterly installments |  | May 2019 |  | $ | 33,000 |  |  | $ | 36,400 |  |
|  |  |  |  |  |  |  | 33,000 |  |  |  | 36,400 |  |
| Less: Current portion |  |  |  |  |  |  | (13,600 | ) |  |  | (13,600 | ) |
| Unamortized debt issuance costs |  |  |  |  |  |  | (62 | ) |  |  | (99 | ) |
| Non-current portion |  |  |  |  |  | $ | 19,338 |  |  | $ | 22,701 |  |

- changed (2018-02-07):
[0001193125-18-033890:note_history:40]
| (2) | In December 2017, the maturity date was extended to January 2018. |
  (was, 2017-11-07, similarity 0.8741):
[0001193125-17-335712:note_history:40]
| (2) | In September 2017, the maturity date was extended to October 2017. |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-07):
[0001193125-18-033890:note_history:41]
Undrawn available credit facilities classified by availability
 period of future borrowing as of December 29, 2017 and
 June 30, 2017 were as follows:
  (was, 2017-11-07, similarity 0.9819):
[0001193125-17-335712:note_history:41]
Undrawn available credit facilities classified by availability
 period of future borrowing as of September 29, 2017 and
 June 30, 2017 were as follows:

- changed (2018-02-07):
[0001193125-18-033890:note_history:42]
| (amount in thousands) |  | December 29, 2017 |  |  | June 30, 2017 |  |
| Short-term |  | $ | — |  |  | $ | 1,965 |  |
| Long-term |  | $ | 111,000 |  |  | $ | 116,000 |  |
  (was, 2017-11-07, similarity 0.9817):
[0001193125-17-335712:note_history:42]
| (amount in thousands) |  | September 29, 2017 |  |  | June 30, 2017 |  |
| Short-term |  | $ | — |  |  | $ | 1,965 |  |
| Long-term |  | $ | 116,000 |  |  | $ | 116,000 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-02-07):
[0001193125-18-033890:note_history:43]
As of December 29, 2017, future maturities of long-term debt
 during each fiscal year were as follows:
  (was, 2017-11-07, similarity 0.9738):
[0001193125-17-335712:note_history:43]
As of September 29, 2017, future maturities of long-term debt
 during each fiscal year were as follows:

- changed (2018-02-07):
[0001193125-18-033890:note_history:44]
| (amount in thousands) |  |  |  |
| 2018 (remaining six months) |  | $ | 6,800 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 29,600 |  |
  (was, 2017-11-07, similarity 0.9774):
[0001193125-17-335712:note_history:44]
| (amount in thousands) |  |  |  |
| 2018 (remaining nine months) |  | $ | 10,200 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 33,000 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2018-02-07):
[0001193125-18-033890:note_history:45]
In February 2018, Fabrinet’s board of directors approved the
 repurchase of up to an additional $30.0 million of Fabrinet’s
 outstanding ordinary shares, bringing the aggregate authorization
 under Fabrinet’s existing share repurchase program to
 $60.0 million.

- removed (2018-02-07):
[0001193125-17-335712:note_history:46]
As part of the Company’s ongoing efforts to achieve greater
 efficiencies in all areas of its business, on October 30,
 2017, the Company implemented a reduction in workforce and incurred
 expenses of approximately $1.7 million, which represented
 severance and benefits costs incurred for the termination of
 approximately 204 employees in accordance with contractual
 obligations and local regulations. The Company will record this
 expense in the quarter ending December 29, 2017.
