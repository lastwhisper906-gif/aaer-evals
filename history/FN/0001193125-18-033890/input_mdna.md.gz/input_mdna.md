# FN MD&A — 0001193125-18-033890


## mdna

[0001193125-18-033890:mdna:1]
| ITEM 2. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001193125-18-033890:mdna:2]
[same as prior period, unchanged from 0001193125-17-335712:mdna:2]

[0001193125-18-033890:mdna:3]
[same as prior period, unchanged from 0001193125-17-335712:mdna:3]

[0001193125-18-033890:mdna:4]
|  | • |  | our expectation that the portion of our future revenues attributable to customers in regions outside of North America will continue to increase compared with the portion of those revenues for the six months ended December 29, 2017; |

[0001193125-18-033890:mdna:5]
[same as prior period, unchanged from 0001193125-17-335712:mdna:5]

[0001193125-18-033890:mdna:6]
[same as prior period, unchanged from 0001193125-17-335712:mdna:6]

[0001193125-18-033890:mdna:7]
[same as prior period, unchanged from 0001193125-17-335712:mdna:7]

[0001193125-18-033890:mdna:8]
[same as prior period, unchanged from 0001193125-17-335712:mdna:8]

[0001193125-18-033890:mdna:9]
[same as prior period, unchanged from 0001193125-17-335712:mdna:9]

[0001193125-18-033890:mdna:10]
[same as prior period, unchanged from 0001193125-17-335712:mdna:10]

[0001193125-18-033890:mdna:11]
[same as prior period, unchanged from 0001193125-17-335712:mdna:11]

[0001193125-18-033890:mdna:12]
[same as prior period, unchanged from 0001193125-17-335712:mdna:12]

[0001193125-18-033890:mdna:13]
[same as prior period, unchanged from 0001193125-17-335712:mdna:13]

[0001193125-18-033890:mdna:14]
[same as prior period, unchanged from 0001193125-17-335712:mdna:14]

[0001193125-18-033890:mdna:15]
[same as prior period, unchanged from 0001193125-17-335712:mdna:15]

[0001193125-18-033890:mdna:16]
[same as prior period, unchanged from 0001193125-17-335712:mdna:16]

[0001193125-18-033890:mdna:17]
[same as prior period, unchanged from 0001193125-17-335712:mdna:17]

[0001193125-18-033890:mdna:18]
[same as prior period, unchanged from 0001193125-17-335712:mdna:18]

[0001193125-18-033890:mdna:19]
[same as prior period, unchanged from 0001193125-17-335712:mdna:19]

[0001193125-18-033890:mdna:20]
[same as prior period, unchanged from 0001193125-17-335712:mdna:20]

[0001193125-18-033890:mdna:21]
[same as prior period, unchanged from 0001193125-17-335712:mdna:21]

[0001193125-18-033890:mdna:22]
[same as prior period, unchanged from 0001193125-17-335712:mdna:22]

[0001193125-18-033890:mdna:23]
[same as prior period, unchanged from 0001193125-17-335712:mdna:25]

[0001193125-18-033890:mdna:24]
[same as prior period, unchanged from 0001193125-17-335712:mdna:26]

[0001193125-18-033890:mdna:25]
[same as prior period, unchanged from 0001193125-17-335712:mdna:27]

[0001193125-18-033890:mdna:26]
[same as prior period, unchanged from 0001193125-17-335712:mdna:28]

[0001193125-18-033890:mdna:27]
The percentage of our revenues generated from a
bill-to location outside of North America remained flat in the three months ended December 30, 2016 as compared to the three months ended December 29, 2017, and increased from 52.6% in the six months
ended December 30, 2016 to 55.5% in the six months ended December 29, 2017, primarily because of an increase in sales to our customers in Asia-Pacific. We expect that the portion of our future revenues attributable to customers in regions
outside North America will continue to increase as compared with the portion of revenues attributable to such customers during the six months ended December 29, 2017.

[0001193125-18-033890:mdna:28]
[same as prior period, unchanged from 0001193125-17-335712:mdna:30]

[0001193125-18-033890:mdna:29]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 29,2017 |  |  | December 30,2016 |  |  | December 29,2017 |  |  | December 30,2016 |  |
| North America |  |  | 45.1 | % |  |  | 45.0 | % |  |  | 44.5 | % |  |  | 47.4 | % |
| Asia-Pacific |  |  | 38.7 |  |  |  | 38.9 |  |  |  | 39.3 |  |  |  | 36.8 |  |
| Europe |  |  | 16.2 |  |  |  | 16.1 |  |  |  | 16.2 |  |  |  | 15.8 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-18-033890:mdna:30]
[same as prior period, unchanged from 0001193125-17-335712:mdna:32]

[0001193125-18-033890:mdna:31]
[same as prior period, unchanged from 0001193125-17-335712:mdna:33]

[0001193125-18-033890:mdna:32]
[same as prior period, unchanged from 0001193125-17-335712:mdna:34]

[0001193125-18-033890:mdna:33]
[same as prior period, unchanged from 0001193125-17-335712:mdna:35]

[0001193125-18-033890:mdna:34]
[same as prior period, unchanged from 0001193125-17-335712:mdna:36]

[0001193125-18-033890:mdna:35]
Our infrastructure costs are comprised of depreciation, utilities, facilities management and overhead costs. Most of our facility leases are
long-term agreements. Our depreciation costs include buildings and fixed assets, primarily at our Pinehurst and Chonburi campuses in Thailand, and capital equipment located at each of our manufacturing locations.

[0001193125-18-033890:mdna:36]
We expect to incur incremental costs of revenue as a result of our planned expansion into new geographic markets, though we are not able to
determine the amount of these incremental expenses.

[0001193125-18-033890:mdna:37]
[same as prior period, unchanged from 0001193125-17-335712:mdna:39]

[0001193125-18-033890:mdna:38]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative and other support
personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other general expenses not related to cost of
revenues. In fiscal year 2018, we expect our SG&A expenses will increase on an absolute dollar basis and decrease as a percentage of revenue compared with fiscal year 2017, due to higher share-based compensation expenses as a result of
restricted share units and performance share units granted to executives in August 2017 and November 2017.

[0001193125-18-033890:mdna:39]
The compensation committee of
our board of directors approved a fiscal year 2018 executive incentive plan with quantitative objectives that are based solely on achieving certain revenue non-GAAP gross margin targets for our fiscal year
ending June 29, 2018. Bonuses under our fiscal year 2018 executive incentive plan are payable after the end of fiscal year 2018. In fiscal year 2017, the compensation committee approved a fiscal year 2017 executive incentive plan with quantitative
objectives that were based solely on achieving certain revenue and non-GAAP gross margin targets for our fiscal year ended June 30, 2017. In the three months ended September 29, 2017, the compensation
committee awarded bonuses to our executive employees for Company achievements of performance under our fiscal 2017 executive incentive plan. Discretionary merit-based bonus awards were also available to our
non-executive employees and were payable as of December 29, 2017.

[0001193125-18-033890:mdna:40]
[same as prior period, unchanged from 0001193125-17-335712:mdna:42]

[0001193125-18-033890:mdna:41]
[same as prior period, unchanged from 0001193125-17-335712:mdna:43]

[0001193125-18-033890:mdna:42]
As a
result of our international operations, we are exposed to foreign exchange risk arising from various currency exposures primarily with respect to the Thai baht. Although a majority of our total revenues is denominated in U.S. dollars, a substantial
portion of our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rate between the Thai baht and the U.S. dollar has fluctuated substantially in recent years and may continue to fluctuate substantially in
the future. We report our financial results in U.S. dollars and our results of operations have been and could in the future be negatively impacted if the Thai baht appreciates against the U.S. dollar. Smaller portions of our expenses are incurred in
a variety of other currencies, including RMB, GBP, Canadian dollars, Euros, and Japanese yen, the appreciation of which may also negatively impact our financial results.

[0001193125-18-033890:mdna:43]
[same as prior period, unchanged from 0001193125-17-335712:mdna:45]

[0001193125-18-033890:mdna:44]
We had foreign currency denominated assets and
liabilities in Thai baht, RMB and GBP as follows:

[0001193125-18-033890:mdna:45]
|  |  | As of December 29, 2017 |  |  | As of June 30, 2017 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 461,231 |  |  | $ | 14,114 |  |  |  | 52.3 |  |  |  | 395,123 |  |  | $ | 11,628 |  |  |  | 47.3 |  |
| RMB |  |  | 22,737 |  |  |  | 3,480 |  |  |  | 12.9 |  |  |  | 26,965 |  |  |  | 3,980 |  |  |  | 16.2 |  |
| GBP |  |  | 6,986 |  |  |  | 9,403 |  |  |  | 34.8 |  |  |  | 6,896 |  |  |  | 8,982 |  |  |  | 36.5 |  |
| Total |  |  |  |  |  | $ | 26,997 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 24,590 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,360,214 |  |  | $ | 41,622 |  |  |  | 82.7 |  |  |  | 1,875,338 |  |  | $ | 55,189 |  |  |  | 82.7 |  |
| RMB |  |  | 29,071 |  |  |  | 4,449 |  |  |  | 8.8 |  |  |  | 28,451 |  |  |  | 4,200 |  |  |  | 6.3 |  |
| GBP |  |  | 3,168 |  |  |  | 4,264 |  |  |  | 8.5 |  |  |  | 5,625 |  |  |  | 7,326 |  |  |  | 11.0 |  |
| Total |  |  |  |  |  | $ | 50,335 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 66,715 |  |  |  | 100.0 |  |

[0001193125-18-033890:mdna:46]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable,
deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency
contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of December 29, 2017 and June 30, 2017, there were $31.5 million and $1.0 million in forward
contracts, respectively, outstanding against forecasted Thai baht payables.

[0001193125-18-033890:mdna:47]
The RMB assets represent cash and cash equivalents, trade
accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of December 29, 2017 and June 30, 2017, we did not have any derivative
contracts denominated in RMB.

[0001193125-18-033890:mdna:48]
The GBP assets represent cash, trade accounts receivable and other current assets. The GBP liabilities
represent trade accounts payable and other payables. As of December 29, 2017 and June 30, 2017, we did not have any derivative contracts denominated in GBP.

[0001193125-18-033890:mdna:49]
For the six months ended December 29, 2017 and December 30, 2016, we recorded loss of $0.1 million and $1 thousand,
respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-18-033890:mdna:50]
[same as prior period, unchanged from 0001193125-17-335712:mdna:52]

[0001193125-18-033890:mdna:51]
[same as prior period, unchanged from 0001193125-17-335712:mdna:53]

[0001193125-18-033890:mdna:52]
[same as prior period, unchanged from 0001193125-17-335712:mdna:54]

[0001193125-18-033890:mdna:53]
[same as prior period, unchanged from 0001193125-17-335712:mdna:55]

[0001193125-18-033890:mdna:54]
[same as prior period, unchanged from 0001193125-17-335712:mdna:56]

[0001193125-18-033890:mdna:55]
[same as prior period, unchanged from 0001193125-17-335712:mdna:57]

[0001193125-18-033890:mdna:56]
[same as prior period, unchanged from 0001193125-17-335712:mdna:58]

[0001193125-18-033890:mdna:57]
Circular 142 regulates the conversion by a foreign-invested company of foreign currency into RMB by restricting how the
converted RMB may be used. Circular 142 requires that the registered capital of a foreign-invested enterprise settled in RMB converted from foreign currencies may only be used for purposes within the business scope approved by the applicable
governmental authority and may not be used for equity investments within the PRC. In addition, SAFE strengthened its oversight of the flow and use of the registered capital of foreign-invested enterprises settled in RMB converted from foreign
currencies. The use of such RMB capital may not be changed without SAFE’s approval and may not be used to repay RMB loans if the proceeds of such loans have not been used.

[0001193125-18-033890:mdna:58]
[same as prior period, unchanged from 0001193125-17-335712:mdna:61]

[0001193125-18-033890:mdna:59]
[same as prior period, unchanged from 0001193125-17-335712:mdna:62]

[0001193125-18-033890:mdna:60]
Furthermore, our transfer of funds to our subsidiaries in Thailand and the PRC are each
subject to approval by governmental authorities in case of an increase in registered capital, or subject to registration with governmental authorities in case of a shareholder loan. These limitations on the flow of funds between our subsidiaries and
us could restrict our ability to act in response to changing market conditions.

[0001193125-18-033890:mdna:61]
[same as prior period, unchanged from 0001193125-17-335712:mdna:64]

[0001193125-18-033890:mdna:62]
Our effective tax rate is a function of the mix of tax rates in the various jurisdictions in which we do business. We are domiciled in the
Cayman Islands. Under the current laws of the Cayman Islands, we are not subject to tax in the Cayman Islands on income or capital gains. We have received this undertaking for a 20-year period ending
August 24, 2019, and after the expiration date, we may request a renewal with the office of the Clerk of the Cabinet for another 20 years.

[0001193125-18-033890:mdna:63]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of
Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption is currently available to us through June 2020 on income generated from projects to manufacture certain products at our Pinehurst campus. Such
preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15
years from the date on which preferential tax treatment was granted. In March 2016, the Thailand Revenue Department announced a permanent decrease of corporate income tax rates to 20% for tax periods beginning on or after January 1, 2016. As a
result, corporate income tax rates for our Thai subsidiary remain at 20% from fiscal year 2017 onward.

[0001193125-18-033890:mdna:64]
On December 22, 2017, the Tax
Cuts and Jobs Act (the “TCJ Act”) was enacted into law. The TCJ Act provides for significant changes to the U.S. Internal Revenue Code of 1986, as amended (the “Code”), that impact corporate taxation requirements, such as the
reduction of the federal tax rate for corporations from 35% to 21% and changes or limitations to certain tax deductions. While we are able to make reasonable estimates of the impact of the reduction in corporate rate, the final impact of the TCJ Act
may differ from these estimates, due to, among other things, changes in our interpretations and assumptions, additional guidance that may be issued by the I.R.S., and actions we may take. We are continuing to gather additional information to
determine the final impact.

[0001193125-18-033890:mdna:65]
Critical Accounting Policies and Use of Estimates

[0001193125-18-033890:mdna:66]
We prepare our unaudited condensed consolidated financial statements in conformity with U.S. GAAP, which requires us to make estimates and
assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent liabilities on the date of the unaudited condensed consolidated financial statements and the reported amounts of revenues and expenses during the
financial reporting period. We continually evaluate these estimates and assumptions based on the most recently available information, our own historical experience and on various other assumptions that we believe to be reasonable under the
circumstances, the results form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Because the use of estimates is an integral component of the financial reporting
process, actual results could differ from those estimates. Some of our accounting policies require higher degrees of judgment than others in their application. We consider the policies discussed below to be critical to an understanding of our
unaudited condensed consolidated financial statements, as their application places the most significant demands on our management’s judgment.

[0001193125-18-033890:mdna:67]
[same as prior period, unchanged from 0001193125-17-335712:mdna:69]

[0001193125-18-033890:mdna:68]
[same as prior period, unchanged from 0001193125-17-335712:mdna:70]

[0001193125-18-033890:mdna:69]
[same as prior period, unchanged from 0001193125-17-335712:mdna:71]

[0001193125-18-033890:mdna:70]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands) |  | December 29,2017 |  |  | December 30,2016 |  |  | December 29,2017 |  |  | December 30,2016 |  |
| Revenues |  | $ | 337,072 |  |  | $ | 351,156 |  |  | $ | 694,385 |  |  | $ | 683,199 |  |
| Cost of revenues |  |  | (299,906 | ) |  |  | (308,110 | ) |  |  | (616,887 | ) |  |  | (600,545 | ) |
| Gross profit |  |  | 37,166 |  |  |  | 43,046 |  |  |  | 77,498 |  |  |  | 82,654 |  |
| Selling, general and administrative expenses |  |  | (13,157 | ) |  |  | (17,651 | ) |  |  | (28,835 | ) |  |  | (33,483 | ) |
| Expenses related to reduction in workforce |  |  | (1,776 | ) |  |  | — |  |  |  | (1,776 | ) |  |  | — |  |
| Operating income |  |  | 22,233 |  |  |  | 25,395 |  |  |  | 46,887 |  |  |  | 49,171 |  |
| Interest income |  |  | 596 |  |  |  | 320 |  |  |  | 1,405 |  |  |  | 757 |  |
| Interest expense |  |  | (826 | ) |  |  | (555 | ) |  |  | (1,679 | ) |  |  | (1,876 | ) |
| Foreign exchange (loss) gain, net |  |  | (1,348 | ) |  |  | 1,945 |  |  |  | (3,282 | ) |  |  | 3,602 |  |
| Other income |  |  | 250 |  |  |  | 147 |  |  |  | 347 |  |  |  | 289 |  |
| Income before income taxes |  |  | 20,905 |  |  |  | 27,252 |  |  |  | 43,678 |  |  |  | 51,943 |  |
| Income tax expense |  |  | (1,592 | ) |  |  | (1,960 | ) |  |  | (3,332 | ) |  |  | (3,885 | ) |
| Net income |  |  | 19,313 |  |  |  | 25,292 |  |  |  | 40,346 |  |  |  | 48,058 |  |
| Other comprehensive income (loss), net of tax |  |  | (418 | ) |  |  | (2,256 | ) |  |  | 136 |  |  |  | (1,860 | ) |
| Net comprehensive income |  | $ | 18,895 |  |  | $ | 23,036 |  |  | $ | 40,482 |  |  | $ | 46,198 |  |

[0001193125-18-033890:mdna:71]
[same as prior period, unchanged from 0001193125-17-335712:mdna:73]

[0001193125-18-033890:mdna:72]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 29,2017 |  |  | December 30,2016 |  |  | December 29,2017 |  |  | December 30,2016 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (89.0 | ) |  |  | (87.7 | ) |  |  | (88.8 | ) |  |  | (87.9 | ) |
| Gross profit |  |  | 11.0 |  |  |  | 12.3 |  |  |  | 11.2 |  |  |  | 12.1 |  |
| Selling, general and administrative expenses |  |  | (3.9 | ) |  |  | (5.0 | ) |  |  | (4.1 | ) |  |  | (4.9 | ) |
| Expenses related to reduction in workforce |  |  | (0.5 | ) |  |  | — |  |  |  | (0.3 | ) |  |  | — |  |
| Operating income |  |  | 6.6 |  |  |  | 7.3 |  |  |  | 6.8 |  |  |  | 7.2 |  |
| Interest income |  |  | 0.2 |  |  |  | 0.1 |  |  |  | 0.2 |  |  |  | 0.1 |  |
| Interest expense |  |  | (0.3 | ) |  |  | (0.2 | ) |  |  | (0.2 | ) |  |  | (0.3 | ) |
| Foreign exchange (loss) gain, net |  |  | (0.4 | ) |  |  | 0.6 |  |  |  | (0.5 | ) |  |  | 0.5 |  |
| Other income |  |  | 0.1 |  |  |  | 0.0 |  |  |  | 0.0 |  |  |  | 0.1 |  |
| Income before income taxes |  |  | 6.2 |  |  |  | 7.8 |  |  |  | 6.3 |  |  |  | 7.6 |  |
| Income tax expense |  |  | (0.5 | ) |  |  | (0.6 | ) |  |  | (0.5 | ) |  |  | (0.6 | ) |
| Net income |  |  | 5.7 |  |  |  | 7.2 |  |  |  | 5.8 |  |  |  | 7.0 |  |
| Other comprehensive income (loss), net of tax |  |  | (0.1 | ) |  |  | (0.6 | ) |  |  | 0.1 |  |  |  | (0.3 | ) |
| Net comprehensive income |  |  | 5.6 | % |  |  | 6.6 | % |  |  | 5.9 | % |  |  | 6.7 | % |

[0001193125-18-033890:mdna:73]
[same as prior period, unchanged from 0001193125-17-335712:mdna:75]

[0001193125-18-033890:mdna:74]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands) |  | December 29,2017 |  |  | December 30,2016 |  |  | December 29,2017 |  |  | December 30,2016 |  |
| Optical communications |  | $ | 241,889 |  |  | $ | 274,244 |  |  | $ | 517,501 |  |  | $ | 531,051 |  |
| Lasers, sensors and other |  |  | 95,183 |  |  |  | 76,912 |  |  |  | 176,884 |  |  |  | 152,148 |  |
| Total |  | $ | 337,072 |  |  | $ | 351,156 |  |  | $ | 694,385 |  |  | $ | 683,199 |  |

[0001193125-18-033890:mdna:75]
[same as prior period, unchanged from 0001193125-17-335712:mdna:77]

[0001193125-18-033890:mdna:76]
33

[0001193125-18-033890:mdna:77]
Comparison of Three and Six Months Ended December 29, 2017 with Three and Six Months Ended
December 30, 2016

[0001193125-18-033890:mdna:78]
[same as prior period, unchanged from 0001193125-17-335712:mdna:80]

[0001193125-18-033890:mdna:79]
Our total revenues decreased by $14.1 million, or 4.0%, to $337.1 million for the three months ended December 29, 2017, compared
with $351.2 million for the three months ended December 30, 2016. This decrease was primarily due to a decrease in our customers’ demand for optical communications manufacturing services partially offset by an increase in our
customers’ demand for non-optical communications manufacturing services. Revenues from optical communications manufacturing services represented 71.8% of our total revenues for the three months ended
December 29, 2017, compared to 78.1% for the three months ended December 30, 2016.

[0001193125-18-033890:mdna:80]
Our total revenues increased by
$11.2 million, or 1.6%, to $694.4 million for the six months ended December 29, 2017, compared with $683.2 million for the six months ended December 30, 2016. This increase was primarily due to an increase in our
customers’ demand for non-optical communications manufacturing services partially offset by a decrease in our customers’ demand for optical communications manufacturing services. Revenues from
optical communications manufacturing services represented 74.5% of our total revenues for the six months ended December 29, 2017, compared to 77.7% for the six months ended December 30, 2016.

[0001193125-18-033890:mdna:81]
[same as prior period, unchanged from 0001193125-17-335712:mdna:82]

[0001193125-18-033890:mdna:82]
Our
cost of revenues decreased by $8.2 million, or 2.7%, to $299.9 million, or 89.0% of total revenues, for the three months ended December 29, 2017, compared with $308.1 million, or 87.7% of total revenues, for the three months
ended December 30, 2016. The decrease in cost of revenues on an absolute dollar basis was primarily due to a decrease in sales volume. Cost of revenues also included share-based compensation expenses of $1.8 million for the three months
ended December 29, 2017, compared with $1.5 million for the three months ended December 30, 2016.

[0001193125-18-033890:mdna:83]
Our cost of revenues
increased by $16.3 million, or 2.7%, to $616.9 million, or 88.8% of total revenues, for the six months ended December 29, 2017, compared with $600.5 million, or 87.9% of total revenues, for the six months ended December 30,
2016. The increase in cost of revenues was primarily due to an increase in sales volume. Cost of revenues also included share-based compensation expenses of $3.7 million for the six months ended December 29, 2017, compared with
$2.5 million for the six months ended December 30, 2016.

[0001193125-18-033890:mdna:84]
[same as prior period, unchanged from 0001193125-17-335712:mdna:84]

[0001193125-18-033890:mdna:85]
Our gross profit decreased by $5.9 million, or 13.7%, to $37.2 million, or 11.0% of total revenues, for the three months ended
December 29, 2017, compared with $43.0 million, or 12.3% of total revenues, for the three months ended December 30, 2016.

[0001193125-18-033890:mdna:86]
Our gross profit decreased by $5.2 million, or 6.2%, to $77.5 million, or 11.2% of total revenues, for the six months ended
December 29, 2017, compared with $82.7 million, or 12.1% of total revenues, for the six months ended December 30, 2016.

[0001193125-18-033890:mdna:87]
[same as prior period, unchanged from 0001193125-17-335712:mdna:86]

[0001193125-18-033890:mdna:88]
Our
SG&A expenses decreased by $4.5 million, or 25.5%, to $13.2 million, or 3.9% of total revenues, for the three months ended December 29, 2017, compared with $17.7 million, or 5.0% of total revenues, for the three months ended
December 30, 2016. Our SG&A expenses decreased primarily due to lower incentive-based compensation.

[0001193125-18-033890:mdna:89]
Our SG&A expenses
decreased by $4.6 million, or 13.9%, to $28.8 million, or 4.1% of total revenues, for the six months ended December 29, 2017, compared with $33.5 million, or 4.9% of total revenues, for the six months ended December 30,
2016. Our SG&A expenses decreased primarily due to lower incentive-based compensation, and lower expenses relating to merger and acquisition activities.

[0001193125-18-033890:mdna:90]
[same as prior period, unchanged from 0001193125-17-335712:mdna:88]

[0001193125-18-033890:mdna:91]
Our
operating income decreased by $3.2 million to $22.2 million, or 6.6% of total revenues, for the three months ended December 29, 2017, compared with $25.4 million, or 7.3% of total revenues, for the three months ended
December 30, 2016.

[0001193125-18-033890:mdna:92]
Our operating income decreased by $2.3 million to $46.9 million, or 6.8% of total revenues, for the six
months ended December 29, 2017, compared with $49.2 million, or 7.2% of total revenues, for the six months ended December 30, 2016.

[0001193125-18-033890:mdna:93]
[same as prior period, unchanged from 0001193125-17-335712:mdna:90]

[0001193125-18-033890:mdna:94]
Our interest income increased by $0.3 million to $0.6 million, or 0.2% of total revenues, for the three months ended
December 29, 2017, compared with $0.3 million, or 0.1% of total revenues, for the three months ended December 30, 2016. Our interest income increased by $0.6 million to $1.4 million, or 0.2% of total revenues, for the six
months ended December 29, 2017, compared with $0.8 million, or 0.1% of total revenues, for the six months ended December 30, 2016. The increase was primarily due to a higher weighted average interest rate and an increase in the
average balance of our outstanding cash.

[0001193125-18-033890:mdna:95]
[same as prior period, unchanged from 0001193125-17-335712:mdna:92]

[0001193125-18-033890:mdna:96]
Our interest expense increased by $0.3 million to $0.8 million for the three months ended December 29, 2017, compared with
$0.5 million for the three months ended December 30, 2016. Our interest expense decreased by $0.2 million to $1.7 million for the six months ended December 29, 2017, compared with $1.9 million for the six months ended
December 30, 2016. The decrease was primarily due to a decrease in the average balance of our bank borrowings.

[0001193125-18-033890:mdna:97]
Foreign exchange
gain (loss), net.

[0001193125-18-033890:mdna:98]
Our foreign exchange gain, net, decreased by $3.3 million to foreign exchange (loss), net, of $(1.3) million,
or (0.4)% of total revenues, for the three months ended December 29, 2017, compared with foreign exchange gain, net, of $1.9 million, or 0.6% of total revenues, for the three months ended December 30, 2016. The decrease was primarily
due to the fluctuation of foreign currencies, particularly the depreciation of U.S. dollars against Thai baht.

[0001193125-18-033890:mdna:99]
Our foreign exchange gain,
net, decreased by $6.9 million to foreign exchange (loss), net, of $(3.3) million, or (0.5)% of total revenues, for the six months ended December 29, 2017, compared with foreign exchange gain, net, of $3.6 million, or 0.5% of total
revenues, for the six months ended December 30, 2016. The decrease was primarily due to the fluctuation of foreign currencies, particularly the depreciation of U.S. dollars against Thai baht.

[0001193125-18-033890:mdna:100]
[same as prior period, unchanged from 0001193125-17-335712:mdna:96]

[0001193125-18-033890:mdna:101]
We recorded income before income taxes of $20.9 million and $43.7 million for the three and six months ended December 29, 2017,
respectively, compared with $27.3 million and $51.9 million for the three and six months ended December 30, 2016, respectively.

[0001193125-18-033890:mdna:102]
[same as prior period, unchanged from 0001193125-17-335712:mdna:98]

[0001193125-18-033890:mdna:103]
Our
provision for income tax reflects an effective tax rate of 6.3% for the three months ended December 29, 2017, compared with an effective tax rate of 6.8% for the three months ended December 30, 2016. The decrease was primarily due to the
fact that we had higher income not subject to tax during the three months ended December 29, 2017 as compared to the same period in fiscal year 2017.

[0001193125-18-033890:mdna:104]
Our provision for income tax reflects an effective tax rate of 6.3% for the six months ended December 29, 2017, compared with an
effective tax rate of 6.7% for the six months ended December 30, 2016. The decrease was primarily due to the fact that we had higher income not subject to tax during the six months ended December 29, 2017 as compared to the same period in
fiscal year 2017.

[0001193125-18-033890:mdna:105]
[same as prior period, unchanged from 0001193125-17-335712:mdna:100]

[0001193125-18-033890:mdna:106]
We recorded net income of $19.3 million, or 5.7% of total revenues, for the three months ended December 29, 2017, compared with
$25.3 million, or 7.2% of total revenues, for the three months ended December 30, 2016.

[0001193125-18-033890:mdna:107]
We recorded net income of
$40.3 million, or 5.8% of total revenues, for the six months ended December 29, 2017, compared with $48.1 million, or 7.0% of total revenues, for the six months ended December 30, 2016.

[0001193125-18-033890:mdna:108]
Other comprehensive (loss) income.

[0001193125-18-033890:mdna:109]
We recorded other comprehensive (loss) of $(0.4) million, or (0.1)% of total revenues, for the three months ended December 29, 2017,
compared with other comprehensive (loss) of $(2.3) million, or (0.6)% of total revenues, for the three months ended December 30, 2016. The decrease was primarily due to the foreign currency translation adjustment of $1.9 million in
connection with the operations of Fabrinet UK.

[0001193125-18-033890:mdna:110]
We recorded other comprehensive income of $0.1 million, or 0.1% of total revenues, for
the six months ended December 29, 2017, compared with other comprehensive (loss) of $(1.9) million, or (0.3)% of total revenues, for the six months ended December 30, 2016. The increase was primarily due to the foreign currency translation
adjustment of $1.7 million in connection with the operations of Fabrinet UK.

[0001193125-18-033890:mdna:111]
[same as prior period, unchanged from 0001193125-17-335712:mdna:104]

[0001193125-18-033890:mdna:112]
Cash Flows and Working Capital

[0001193125-18-033890:mdna:113]
We
primarily finance our operations through cash flow from operations. As of December 29, 2017 and December 30, 2016, we had cash, cash equivalents, and marketable securities of $284.2 million and $256.1 million, respectively, and
outstanding debt of $68.4 million and $68.1 million, respectively.

[0001193125-18-033890:mdna:114]
Our cash and cash equivalents, which primarily consist of
cash on hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents for the three and six
months ended December 29, 2017 was 1.0%, and for the three and six months ended December 30, 2016 was 0.5% and 0.4%, respectively.

[0001193125-18-033890:mdna:115]
Our cash investments are made in accordance with an investment policy approved by the Audit Committee of our board of directors. In general,
our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed income securities are
primarily classified as available-for-sale and are recorded at fair value. The cost of securities sold is based on the specific identification method. Unrealized gains
and losses on these securities are recorded as other comprehensive income (loss) and are reported as a separate component of shareholders’ equity.

[0001193125-18-033890:mdna:116]
During the six months ended December 29, 2017, we repaid a term loan of $6.8 million under our Facility Agreement; as a result, as
of December 29, 2017, we had a long-term borrowing of $29.6 million and short-term borrowing of $39.0 million under our Facility Agreement. We anticipate that our internally generated working capital, along with our cash and cash
equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held investments in short-term marketable securities of $149.4 million as of December 29, 2017.

[0001193125-18-033890:mdna:117]
We believe that our current cash and cash equivalents, marketable securities, cash flow from operations, and funds available through our
credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II,
Item 1A of this Quarterly Report on Form 10-Q.

[0001193125-18-033890:mdna:118]
In December 2015, we began construction of a
new manufacturing facility at our Chonburi campus, which we substantially completed in the first quarter of fiscal year 2017. We began operations at this new facility in the fourth quarter of fiscal year 2017. We believe that our current
manufacturing capacity is sufficient to meet our anticipated production requirements for at least the next few quarters. We maintain a long-term loan associated with construction of production facilities at our Pinehurst campus in Thailand that will
come due within the next 12 months.

[0001193125-18-033890:mdna:119]
[same as prior period, unchanged from 0001193125-17-335712:mdna:112]

[0001193125-18-033890:mdna:120]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 29,2017 |  |  | December 30,2016 |  |
| Net cash provided by operating activities |  | $ | 37,113 |  |  | $ | 19,752 |  |
| Net cash used in investing activities |  | $ | (20,639 | ) |  | $ | (84,102 | ) |
| Net cash (used in) provided by financing activities |  | $ | (15,641 | ) |  | $ | 10,692 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | 833 |  |  | $ | (53,658 | ) |

[0001193125-18-033890:mdna:121]
[same as prior period, unchanged from 0001193125-17-335712:mdna:114]

[0001193125-18-033890:mdna:122]
Net cash provided by operating activities increased by $17.4 million, or 87.9%, to $37.1 million for the six months ended
December 29, 2017, compared with net cash provided by operating activities of $19.8 million for the six months ended December 30, 2016. This increase was due to net cash inflow from trade accounts receivable of $46.5 million and
inventory of $28.2 million, partially offset by net cash outflow from trade accounts payable of $44.7 million and other current assets and other non-current assets of $11.5 million as compared
with the six months ended December 30, 2016.

[0001193125-18-033890:mdna:123]
[same as prior period, unchanged from 0001193125-17-335712:mdna:116]

[0001193125-18-033890:mdna:124]
Net cash used in investing activities decreased by $63.5 million, or 75.5%, to $20.6 million for the six months ended
December 29, 2017, compared with net cash used in investing activities of $84.1 million for the six months ended December 30, 2016. This decrease was primarily due to (1) a net decrease in marketable securities of
$31.0 million, (2) a decrease in the purchase of property, plant and equipment and intangibles of $22.6 million, and (3) a decrease of $9.9 million in payments in connection with the acquisition of Fabrinet UK.

[0001193125-18-033890:mdna:125]
[same as prior period, unchanged from 0001193125-17-335712:mdna:118]

[0001193125-18-033890:mdna:126]
Net
cash for financing activities decreased by $26.3 million, or 246.3%, to net cash used in financing activities of $15.6 million for the six months ended December 29, 2017, compared with net cash provided by financing activities of
$10.7 million for the six months ended December 30, 2016. This decrease was primarily due to (1) an increase of $9.9 million in the repurchase of ordinary shares pursuant to our share repurchase program, (2) a decrease in
the proceeds from our revolving bank loan of $10.7 million, (3) a decrease in the proceeds from the issuance of ordinary shares under employee share option plans of $4.9 million, and (4) an increase in withholding tax related to
net share settlement of restricted share units of $2.7 million, compared with the same period last year. These were offset by a decrease in the repayment of long-term loans from bank of $3.0 million.

[0001193125-18-033890:mdna:127]
[same as prior period, unchanged from 0001193125-17-335712:mdna:120]

[0001193125-18-033890:mdna:128]
[same as prior period, unchanged from 0001193125-17-335712:mdna:121]

[0001193125-18-033890:mdna:129]
[same as prior period, unchanged from 0001193125-17-335712:mdna:122]

[0001193125-18-033890:mdna:130]
[same as prior period, unchanged from 0001193125-17-335712:mdna:123]
