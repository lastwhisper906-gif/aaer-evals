# FN notes — 0001193125-19-225268


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-19-225268:notes:1]
| 2. | Summary of significant accounting policies |

[0001193125-19-225268:notes:2]
Principles of consolidation

[0001193125-19-225268:notes:3]
The Company utilizes a 
52-53
 week fiscal year ending on the Friday in June closest to June 30. Fiscal year 2019 ended on June 28, 2019 and consisted of 52 weeks. Fiscal year 2018 ended on June 29, 2018 and consisted of 52 weeks. Fiscal year 2017 ended on June 30, 2017 and consisted of 53 weeks.

[0001193125-19-225268:notes:4]
The consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States (“U.S. GAAP”) and include Fabrinet and its subsidiaries. All inter-company accounts and transactions have been eliminated.

[0001193125-19-225268:notes:5]
On September 14, 2016, the Company acquired Global CEM Solutions, Ltd. and all of its subsidiaries (collectively, “Fabrinet UK”), a privately-held group located in Wiltshire, United Kingdom. The consolidated financial statements of the Company include the financial position, results of operations and the cash flows of Fabrinet UK commencing as of the acquisition date. See Note 11, Business acquisition for further details on the accounting for this transaction.

[0001193125-19-225268:notes:6]
Use of estimates

[0001193125-19-225268:notes:7]
The preparation of the Company’s consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements, and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, income taxes, inventory obsolescence and valuation of intangible assets related to a business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that estimates or assumptions prove to differ from actual results, adjustments will be made in subsequent periods to reflect more current information.

[0001193125-19-225268:notes:8]
Changes in Accounting Policies

[0001193125-19-225268:notes:9]
Except for the adoption of the new revenue recognition accounting standard disclosed in Note 3—Revenues from contracts with customers, the Company has consistently applied the accounting policies to all periods presented in these consolidated financial statements.

[0001193125-19-225268:notes:10]
Foreign currency transactions and translation

[0001193125-19-225268:notes:11]
The consolidated financial statements are presented in United States dollars (“$” or “USD”). The functional currency of Fabrinet and most of its subsidiaries is the USD.

[0001193125-19-225268:notes:12]
With respect to subsidiaries that use USD as their functional currency, transactions denominated in a currency other than USD are translated into USD at the rates of exchange in effect at the date of the transaction. Monetary assets and liabilities denominated in foreign currencies are translated into the functional currency at the exchange rate prevailing at the consolidated balance sheet dates. Transaction gains and losses are included in foreign exchange gain (loss) in the accompanying consolidated statements of operations and comprehensive income.

[0001193125-19-225268:notes:13]
Fabrinet translates the assets and liabilities of its subsidiaries that do not use USD as their functional currency into USD using exchange rates in effect at the end of each period. Revenue and expenses for such subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recognized in foreign currency translation adjustment included in accumulated other comprehensive loss (“AOCI”) in the Company’s consolidated balance sheets.

[0001193125-19-225268:notes:14]
Cash and cash equivalents

[0001193125-19-225268:notes:15]
All highly liquid investments with original maturities of three months or less at the date of purchase are classified as cash equivalents. Cash and cash equivalents consist of cash deposited in checking accounts, time deposits with maturities of less than three months, money market accounts, and short-term investments with maturities of three months or less at the date of purchase.

[0001193125-19-225268:notes:16]
Short-term investments

[0001193125-19-225268:notes:17]
Management determines the appropriate classification of its investments at the time of purchase and 
re-evaluates
 the designations at each balance sheet date. The Company may sell certain of the Company’s short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s short-term investments generally range from three months to three years. The Company’s short-term investments consist of investments in U.S. Treasury, fixed income securities, liquidity funds which invest in short-term debt securities and certificates of deposit and time deposits and have been classified and accounted for as

[0001193125-19-225268:notes:18]
available-for-sale.

[0001193125-19-225268:notes:19]
The Company’s investments in marketable securities are classified as

[0001193125-19-225268:notes:20]
available-for-sale

[0001193125-19-225268:notes:21]
securities and reported at fair value. Unrealized gains and losses related to changes in the fair value of securities are recognized in AOCI in the Company’s consolidated balance sheets. Changes in the fair value of

[0001193125-19-225268:notes:22]
securities impact the Company’s net income only when such securities are sold or other-than-temporary impairment is recognized. Realized gains and losses on the sale of securities are determined by specific identification of each security’s cost basis.

[0001193125-19-225268:notes:23]
The Company reviews its short-term investments on a regular basis to evaluate whether or not any security has experienced an other-than-temporary decline in fair value. The Company considers factors such as the length of time and extent to which the market value has been less than the cost, the financial condition and near-term prospects of the issue and the Company’s intent to sell, or whether it is more likely than not the Company will be required to sell the investment before recovery of the investment’s amortized cost basis. If the Company believes that an other-than-temporary decline exists in one of these securities, the Company will write down these investments to fair value.

[0001193125-19-225268:notes:24]
Trade accounts receivable

[0001193125-19-225268:notes:25]
Accounts receivable are carried at anticipated realizable value. The Company assesses the collectability of its accounts receivable based on specific customer circumstances, current economic trends, historical experience with collection and the age of past due receivables and provides an allowance for doubtful receivables based on a review of all outstanding amounts at the period end. Bad debts are 
written-off
 when identified.

[0001193125-19-225268:notes:26]
Unanticipated changes in the liquidity or financial position of the Company’s customers may require revision to the allowances for doubtful accounts.

[0001193125-19-225268:notes:27]
Contract assets

[0001193125-19-225268:notes:28]
A contract asset is recognized when the Company has recognized revenues prior to an invoice for payment. Contract assets are classified separately on the consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. The Company reviews for impairment of contract assets on a quarterly basis for any events or changes in circumstances that indicate that their carrying amount may not be recoverable.

[0001193125-19-225268:notes:29]
Contract liabilities

[0001193125-19-225268:notes:30]
A contract liability is recognized when the Company has advance payment arrangements with customers. The contract liabilities balance is normally recognized as revenue within six months.

[0001193125-19-225268:notes:31]
Inventory

[0001193125-19-225268:notes:32]
Inventory is stated at the lower of cost or market value. Cost is estimated using the standard costing method, computed on a 
first-in,

[0001193125-19-225268:notes:33]
first-out
 basis, with adjustments for variances to reflect actual costs not in excess of net realizable market value. Market value is the estimated selling price in the ordinary course of business, less the costs of completion and selling expenses. The Company assesses the valuation of inventory on a quarterly basis and writes down the value for estimated excess and obsolete inventory based upon estimates of future demand.

[0001193125-19-225268:notes:34]
Leases

[0001193125-19-225268:notes:35]
Operating leases

[0001193125-19-225268:notes:36]
Payments made under operating leases are expensed on a straight-line basis over the lease term.

[0001193125-19-225268:notes:37]
Capital lease

[0001193125-19-225268:notes:38]
Certain machines and equipment held under capital leases are classified as property, plant and equipment and amortized using the straight-line method over the terms of the lease contracts. The related obligations from the capital lease are recorded as liabilities in the consolidated balance sheets.

[0001193125-19-225268:notes:39]
Property, plant and equipment

[0001193125-19-225268:notes:40]
Land is stated at historical cost. Other property, plant and equipment, except for construction in process and machinery under installation, are stated at historical cost less accumulated depreciation. Repair and maintenance costs are expensed as incurred. Depreciation is calculated using the straight-line method to 
write-off
 the cost of each asset to its residual value over its estimated useful life as follows:

[0001193125-19-225268:notes:41]
| Land improvements |  |  | 10 years |  |
| Building and building improvements |  |  | 7 - 30 years |  |
| Leasehold improvements |  |  | Shorter of useful life or lease term |  |
| Manufacturing equipment |  |  | 3 - 7 years |  |
| Office equipment |  |  | 3 - 7 years |  |
| Motor vehicles |  |  | 3 - 5 years |  |
| Computer hardware |  |  | 3 - 5 years |  |

[0001193125-19-225268:notes:42]
Construction in process and machinery under installation is stated at historic cost and depreciation begins after it is constructed and fully installed and is ready for its intended use in the operations of the Company.

[0001193125-19-225268:notes:43]
Gains and losses on disposal are determined by comparing proceeds with carrying amounts and are included in other income in the consolidated statements of operations and comprehensive income.

[0001193125-19-225268:notes:44]
The Company reviews long-lived assets or asset groups for recoverability on a quarterly basis for any events or changes in circumstances that indicate that their carrying amount may not be recoverable. Recoverability of long-lived assets or asset groups is measured by comparing their carrying amount to the projected undiscounted cash flows that the long-lived assets or asset groups are expected to generate. If such assets are considered to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the property and equipment exceeds its fair value.

[0001193125-19-225268:notes:45]
Intangibles

[0001193125-19-225268:notes:46]
Intangibles are stated at historical cost less amortization. Amortization of customer relationships is calculated using the accelerated method as to reflect the pattern in which the economic benefits of the intangible assets are consumed. Amortization of other intangibles is calculated using the straight-line method.

[0001193125-19-225268:notes:47]
Intangible assets are reviewed for impairment quarterly or more frequently whenever changes or circumstances indicate the carrying amount of related assets may not be recoverable.

[0001193125-19-225268:notes:48]
Business acquisition

[0001193125-19-225268:notes:49]
For the acquisition of Fabrinet UK, the Company allocated the fair value of purchase consideration to the assets acquired and liabilities assumed based on their fair values at the acquisition date. The allocation of consideration to the individual net assets was finalized in the fourth quarter of fiscal year 2017.

[0001193125-19-225268:notes:50]
The acquired intangible assets, which consisted of customer relationships and backlog, were recorded as intangibles in the consolidated balance sheets. The fair value of the acquired intangible assets was determined based on the multi-period excess earnings method. The Company reviews intangibles for impairment whenever changes or circumstances indicate the carrying amount may not be recoverable.

[0001193125-19-225268:notes:51]
In connection with the acquisition of Fabrinet UK, $3.4 million of cash, net of foreign currency translation adjustment, for deferred consideration, was placed into an escrow account under the Company’s control. The Company contractually agreed to remit this deferred consideration to the sellers of Fabrinet UK, subject to the resolution of claims that the Company may make against the funds with respect to indemnification and other claims within 24 months from the closing date of the transaction. As of June 28, 2019, there were no balances of restricted cash and deferred consideration in connection with business acquisitions. As of June 29, 2018, the cash is presented as restricted cash in the consolidated balance sheets within current assets and the related liability is presented within current liabilities for the deferred consideration.

[0001193125-19-225268:notes:52]
Goodwill

[0001193125-19-225268:notes:53]
Goodwill arising from the acquisition is primarily attributable to the ability to expand future products and services and the assembled workforce. Goodwill is reviewed annually for impairment or more frequently whenever changes or circumstances indicate the carrying amount of goodwill may not be recoverable.

[0001193125-19-225268:notes:54]
Treasury shares

[0001193125-19-225268:notes:55]
Treasury share purchases are accounted for under the cost method whereby the entire cost of the acquired stock is recorded as treasury shares. Gains and losses in excess of par value on the subsequent reissuance of shares are credited or charged to additional 
paid-in
 capital in the consolidated balance sheets using the average-cost method.

[0001193125-19-225268:notes:56]
Borrowing costs

[0001193125-19-225268:notes:57]
Borrowing costs are accounted for on an accrual basis and are charged to the consolidated statements of operations and comprehensive income in the year incurred, except for interest costs on general and specific borrowings attributable to finance certain qualifying assets. Such costs to finance qualifying assets are capitalized during the period of time that is required to complete and prepare the assets for their intended use, as part of the cost of the assets. All other borrowing costs are expensed as incurred.

[0001193125-19-225268:notes:58]
Where funds are not borrowed for a specific acquisition, construction or production of assets, the capitalization rate used to determine the amount of interest to be capitalized is the weighted average interest rate applicable to the Company’s outstanding borrowings during the year. Where funds are borrowed specifically for the acquisition, construction or production of assets, the amount of borrowing costs eligible for capitalization on the respective assets is determined as the actual borrowing costs are incurred on that borrowing during the respective periods.

[0001193125-19-225268:notes:59]
Fair value of financial instruments

[0001193125-19-225268:notes:60]
Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. A fair value hierarchy is established which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs for the valuation of an asset or liability as of the measurement date. The three levels of inputs that may be used to measure fair value are defined as follows:

[0001193125-19-225268:notes:61]
Level 1 inputs are quoted prices (unadjusted) in active markets for identical assets or liabilities.

[0001193125-19-225268:notes:62]
Level 2 inputs for similar assets and liabilities in active markets other than quoted prices included within Level 1 that are observable for the asset or liability, either directly or indirectly, for substantially the full term of the asset or liability.

[0001193125-19-225268:notes:63]
Level 3 inputs that are significant to the fair value measurement and unobservable (i.e. supported by little or no market activity), which require the reporting entity to develop its own valuation techniques and assumptions.

[0001193125-19-225268:notes:64]
The Company utilizes the market approach to measure fair value for its financial assets and liabilities. The market approach uses prices and other relevant information generated by market transactions involving identical or comparable assets or liabilities.

[0001193125-19-225268:notes:65]
The carrying amounts of certain financial instruments, which include cash and cash equivalents, trade accounts receivable, contract assets, trade accounts payable, and contract liabilities, approximate their fair values due to their short maturities. The carrying amounts of borrowings approximate their fair values as the applicable interest rate is based on market interest rates. The particular recognition methods adopted are disclosed in the individual policy statements associated with each item.

[0001193125-19-225268:notes:66]
Derivatives

[0001193125-19-225268:notes:67]
The derivative assets and liabilities are recognized on the consolidated balance sheets as other current assets or other current liabilities and are measured at fair value.

[0001193125-19-225268:notes:68]
The Company applies hedge accounting to arrangements that qualify and are designated for cash flow or fair value hedge accounting treatment. Hedge accounting is discontinued prospectively if the hedging relationship ceases to be effective or the hedging or hedged items cease to exist as a result of maturity, sale, termination or cancellation.

[0001193125-19-225268:notes:69]
Derivatives designated and qualifying as hedges of the exposure to variability in expected future cash flows, or other types of forecasted transactions, are considered cash flow hedges which include forward currency contracts. In a cash flow hedging relationship, the effective portion of the change in the fair value of the hedging derivative is initially recorded in AOCI in the consolidated balance sheets, while any ineffective portion is recognized directly in earnings, as a component of foreign exchange gain (loss) in the consolidated statements of operations and comprehensive income. The portion of gain or loss on the derivative instrument remains in AOCI until the forecasted transaction is recognized in earnings.

[0001193125-19-225268:notes:70]
The Company also enters into derivative contracts that are intended to economically hedge certain of the Company’s risks. The changes in the fair value of the derivatives are recorded directly in earnings as a component of foreign exchange gain (loss) in the consolidated statements of operations and comprehensive income. In accordance with the fair value measurement guidance, the Company’s accounting policy is to measure the credit risk of its derivative financial instruments that are subject to master netting agreements on a net basis by counterparty portfolio. The Company executes derivative instruments with financial institutions that are credit-worthy, which the Company defines as institutions that hold an investment grade credit rating.

[0001193125-19-225268:notes:71]
Concentration of credit risk

[0001193125-19-225268:notes:72]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash and cash equivalents, short-term investments, derivatives and accounts receivable.

[0001193125-19-225268:notes:73]
Cash, cash equivalents and short-term investments are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. The Company seeks to mitigate its credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties. The Company limits its investments in marketable securities to securities with a maturity not in excess of three years, and all marketable securities that the Company invests in are rated A1, 
P-1,
 F1, or better.

[0001193125-19-225268:notes:74]
The Company performs ongoing credit evaluations for credit worthiness of its customers and usually does not require collateral from its customers. Management has implemented a program to closely monitor near term cash collection and credit exposures to mitigate any material losses.

[0001193125-19-225268:notes:75]
Revenue recognition

[0001193125-19-225268:notes:76]
The Company derives total revenues primarily from the assembly of products under supply agreements with its customers and the fabrication of customized optics and glass. The Company recognizes revenue relating to contracts that depict the transfer of promised goods or services to customers in an amount reflecting the consideration to which the Company expects to be entitled in exchange for such goods or services. In order to meet this requirement, the Company applies the following five steps: (1) identify the contract with a customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract, and (5) recognize revenue when a performance obligation is satisfied. Revenue is recognized net of any taxes collected from customers, which is subsequently remitted to governmental authorities.

[0001193125-19-225268:notes:77]
A performance obligation is a promise in a contract to transfer a distinct good or service to the customer. In contracts with multiple performance obligations, the Company identifies each performance obligation and evaluates whether the performance obligation is distinct within the context of the contract at contract inception. The majority of the Company’s contracts have a single performance obligation as the promise to transfer the individual goods or services is not separately identifiable from other promises in the contracts and, therefore, not distinct.

[0001193125-19-225268:notes:78]
Sales of finished goods

[0001193125-19-225268:notes:79]
The Company manufactures products that are customized to customers’ specifications; however, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for over time recognition are not met. On evaluation of the contracts, the Company identified that there were no contractual rights to bill profit for work in progress in the event of a contract termination, which is expected to be infrequent. Further, in limited circumstances, contracts provide for substantive acceptance by the customer, which results in the deferral of revenue until formal notice of acceptance is received from the customer. Judgment may be required in determining if an acceptance clause provides for substantive acceptance.

[0001193125-19-225268:notes:80]
Certain customers may request the Company to store finished products at the Company’s warehouse where customers bear risks of loss themselves. In these instances, the Company receives a written request from the customer asking the Company to hold the inventory at the Company’s warehouse and refrain from using the ordered goods to fulfill other customer orders. In these situations, revenue is only recognized when the completed goods are ready for shipment and transferred to the Company’s warehouse.

[0001193125-19-225268:notes:81]
Customers generally are obligated to purchase finished goods that the Company has manufactured according to their demand requirements. Materials that are not consumed by customers within a specified period of time, or are no longer required due to a product’s cancellation or

[0001193125-19-225268:notes:82]
end-of-life,

[0001193125-19-225268:notes:83]
are typically designated as excess or obsolete inventory under the Company’s contracts. Once materials are designated as either excess or obsolete inventory, customers are typically required to purchase such inventory from the Company even if the customer has chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

[0001193125-19-225268:notes:84]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. In determining the net consideration to which the Company expects to be entitled, the Company evaluates whether the price is subject to refund or adjustment. The Company generally does not grant return privileges, except for in the case of defective products during the warranty period. The Company generally provides a warranty of between one to five years on any given product. These standard warranties are assurance type warranties and do not offer any services in addition to the assurance that the product will continue to work as specified.

[0001193125-19-225268:notes:85]
The sales price is not considered to be fixed or determinable until all contingencies related to the sale have been resolved. The Company recognized revenue net of rebates and other similar allowances. Revenues are recognized only if these estimates can be reasonably and reliably determined. The Company bases its estimates on historical results taking into consideration the type of customer, the type of transaction and the specifics of each arrangement.

[0001193125-19-225268:notes:86]
Services

[0001193125-19-225268:notes:87]
The Company provides services for customers that are related to the Company’s manufacturing activities. In many cases, although the nature of work performed is service in nature, revenue is only recognizable on shipping of the product because the customer has specific requirements as to how many items can be shipped at any given point in time, i.e. at

[0001193125-19-225268:notes:88]
point-in-time.

[0001193125-19-225268:notes:89]
The related costs are expensed as incurred.

[0001193125-19-225268:notes:90]
Service revenues of $106.1 million, $73.5 million and $92.8 million were recognized in the consolidated statements of operations and comprehensive income for the years ended June 28, 2019, June 29, 2018 and June 30, 2017, respectively.

[0001193125-19-225268:notes:91]
Warranty provision

[0001193125-19-225268:notes:92]
Provisions for estimated expenses relating to product warranties are made at the time the products are sold using historical experience. Generally, this warranty is limited to workmanship and the Company’s liability is capped at the price of the product. The provisions will be adjusted when experience indicates an expected settlement will differ from initial estimates.

[0001193125-19-225268:notes:93]
Warranty cost allowances (reversal) of $0.07 million, ($0.02 million) and $1.0 million were recognized in the consolidated statements of operations and comprehensive income for the years ended June 28, 2019, June 29, 2018 and June 30, 2017, respectively.

[0001193125-19-225268:notes:94]
Share-based compensation

[0001193125-19-225268:notes:95]
Share-based compensation is recognized in the consolidated financial statements based on grant-date fair value. The value of the portion of the award that is ultimately expected to vest is recognized as expense ratably over the requisite service period. The Company estimates the fair value of share option awards utilizing the Black-Scholes-Merton option-pricing model (“BSM”), net of estimated forfeitures. For restricted share units and performance share units, the fair values are based on the market value of our ordinary shares on the date of grant.

[0001193125-19-225268:notes:96]
Employee contribution plan

[0001193125-19-225268:notes:97]
The Company operates a defined contribution plan, known as a provident fund, in its subsidiaries in Thailand and the United Kingdom. The assets of these plans are in separate trustee-administered funds. The provident fund is funded by matching payments from employees and by the subsidiaries on a monthly basis. Current contributions to the provident fund are accrued and paid to the fund manager on a monthly basis. The Company sponsors the Fabrinet U.S. 401(k) Retirement Plan (the “401(k) Plan”), a Defined Contribution Plan under ERISA, at its subsidiaries in the United States, which provides retirement benefits for its eligible employees through tax deferred salary deductions.

[0001193125-19-225268:notes:98]
Severance liabilities

[0001193125-19-225268:notes:99]
Under labor protection laws applicable in Thailand and the Company’s subsidiary in Thailand’s employment policy, all employees of such subsidiary with more than 120 days of service are entitled to severance pay on forced termination or retrenchment or in the event that the employee reaches the retirement age of 55. The entitlement to severance pay is determined according to an employee’s individual employment tenure with the Company and is subject to a maximum benefit of 400 days of salary unless otherwise agreed upon in an employee’s employment contract. For employees of other subsidiaries who have a specific termination date, the entitlement to severance pay is determined according to their employment tenure, until their designated termination date.

[0001193125-19-225268:notes:100]
The Company accounts for these severance liabilities on an actuarial basis using the Projected Unit Credit Method, using the long-term Thai government bond yield as a discount rate. There are no separate plan assets held in respect of these liabilities.

[0001193125-19-225268:notes:101]
The Company’s subsidiary in the United Kingdom operates a defined benefit pension plan that defines the pension benefit an employee will receive on retirement, usually dependent upon several factors including but not limited to age, length of service and remuneration. The defined benefit obligation is calculated using the projected unit credit method. Annually the Company engages independent actuaries to calculate the obligation. The present value is determined by discounting the estimated future payments using market yields on high quality corporate bonds that are denominated in sterling and that have terms approximating the estimated period of the future payments (discount rate). The plan assets are held separately from those of the Company in independently administered funds and are measured at fair value.

[0001193125-19-225268:notes:102]
Severance liabilities are recognized in the Company’s consolidated balance sheet under non-current liabilities. The related expenses, if incurred during the period, are recognized in the Company’s consolidated statements of operations and comprehensive income as selling, general and administrative expenses. Prior service cost is initially recognized to other comprehensive income (loss) at the date of plan amendment. Such prior service cost is amortized as expenses as a component of net periodic pension cost by the weighted average remaining years of service to full eligibility date of active employees.

[0001193125-19-225268:notes:103]
Annual leave

[0001193125-19-225268:notes:104]
Employee entitlements to annual leave are recognized when they accrue to the employee. On termination of employment, accrued employee entitlement to annual leave is paid in cash.

[0001193125-19-225268:notes:105]
Income taxes

[0001193125-19-225268:notes:106]
The Company uses the asset and liability method of accounting for income taxes, whereby deferred tax assets and liabilities are recognized for future tax consequences attributable to temporary differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using tax rates expected to apply to taxable income in the years in which those temporary differences are expected to reverse. The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date. Deferred tax assets are reduced by a valuation allowance if, based on the weight of the available evidence, it is more likely than not that some portion or all of the deferred tax assets will not be realized.

[0001193125-19-225268:notes:107]
Fabrinet’s subsidiaries are subject to income tax audits by the respective tax authorities in all of the jurisdictions in which they operate. The determination of tax liabilities in each of these jurisdictions requires the interpretation and application of complex and sometimes uncertain tax laws and regulations.

[0001193125-19-225268:notes:108]
The Company recognizes liabilities based on its estimate of whether, and the extent to which, additional tax liabilities are 
more-likely-than-not.
 If the Company ultimately determines that the payment of such a liability is not probable, then it reverses the liability and recognizes a tax benefit during the period in which the determination is made that the liability is no longer probable. The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that the Company makes certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on the Company’s tax provision in a future period.

[0001193125-19-225268:notes:109]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. A company shall reduce its deferred tax assets by a valuation allowance if, based on the weight of available evidence, it is “more likely than not” (i.e., a likelihood of greater than 50 percent) that some portion or all of the deferred tax assets will not be realized. The valuation allowance shall be sufficient to reduce the deferred tax asset to the amount that is more likely than not to be realized. The valuation allowance shall be monitored and considered from all available evidence, both positive and negative, to determine whether, based on the weight of that evidence, a valuation allowance for deferred tax assets is not needed.

[0001193125-19-225268:notes:110]
The accounting standard clarifies the accounting for uncertainty in income taxes recognized in an entity’s financial statements and prescribes a recognition threshold and measurement attributes for financial statement disclosure of tax positions taken or expected to be taken on a tax return.

[0001193125-19-225268:notes:111]
The Company recognizes a tax benefit in the financial statements for an uncertain tax position only if management’s assessment is that the position is “more likely than not” to be sustained upon examination by the tax jurisdiction based solely on the technical merits of the position. The term “tax position” refers to a position in a previously filed tax return or a position expected to be taken in a future tax return that is reflected in measuring current or deferred income tax assets and liabilities for interim or annual periods. The accounting interpretation also provides guidance on measurement methodology, derecognition thresholds, financial statement classification and disclosures, recognition of interest and penalties, and accounting for the cumulative-effect adjustment at the date of adoption.

[0001193125-19-225268:notes:112]
New Accounting Pronouncements—not yet adopted by the Company

[0001193125-19-225268:notes:113]
In May 2019, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 
2019-05,
 “Financial Instruments—Credit Losses (Topic 326)” The amendments in this Update provide entities that have certain instruments within the scope of Subtopic 
326-20,
 Financial Instruments—Credit Losses—Measured at Amortized Cost, with an option to irrevocably elect the fair value option in Subtopic 
825-10,
 Financial Instruments—Overall, applied on an

[0001193125-19-225268:notes:114]
instrument-by-instrument

[0001193125-19-225268:notes:115]
basis for eligible instruments, upon adoption of Topic 326. The fair value option election does not apply to

[0001193125-19-225268:notes:116]
held-to-maturity

[0001193125-19-225268:notes:117]
debt securities. An entity that elects the fair value option should subsequently apply the guidance in Subtopics 
820-10,
 Fair Value Measurement—Overall, and 
825-10.
 For public business entities, this update is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its consolidated financial statements.

[0001193125-19-225268:notes:118]
In April 2019, FASB issued ASU 
2019-04,
 “Financial Instruments—Credit Losses (Topic 326), Derivatives and Hedging (Topic 815), and Financial Instruments (Topic 825) Codification Improvements.” The amendments in this Update apply to all reporting entities within the scope of the affected accounting guidance. For public business entities, this update is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its consolidated financial statements.

[0001193125-19-225268:notes:119]
In August 2018, the FASB issued ASU 
2018-13,
 “Fair Value Measurement (Topic 820), Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement.” This ASU is intended to improve the effectiveness of disclosures in the notes to the financial statements, including (1) the development of a framework that promotes consistent decisions by the FASB about disclosure requirements and (2) the appropriate exercise of discretion by reporting entities. The amendment modifies the disclosure requirements on transferring between level 1 and level 2 and valuation processes of level 3 fair value measurements. The amendments in this update are effective for all entities for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company is currently evaluating the impact of the adoption of this update on its consolidated financial statements.

[0001193125-19-225268:notes:120]
In January 2017, the FASB issued ASU 
2017-04,
 “Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.” This amendment modified the concept of impairment assessment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. Public companies that are SEC filers should adopt the amendment for annual and any interim goodwill impairment tests in fiscal years beginning after December 15, 2019. Early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017. The Company does not expect the amendments will impact its consolidated financial statements.

[0001193125-19-225268:notes:121]
In February 2016, the FASB issued ASU 
2016-02,
 “Leases (Topic 842)”: The amendment requires the Company to establish the principles that lessees and lessors shall apply to report useful information to users of financial statements about the amount, timing, and uncertainty of cash flows arising from a lease: (1) a lease liability, which is a lessee’s obligation to make lease payments arising from a lease, measured on a discounted basis; and (2) a right of use asset, which is an asset that represents the lessee’s right to use, or control the use of, a specified asset for the lease term. For public companies, this update is effective in the fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. Early adoption is permitted. The FASB has issued three additional updates to the standard which (1) provide guidance on comparative reporting requirements for initial adoption and also provide additional guidance for lessors, on separating lease and 
non-lease
 components in a contract and allocating the consideration in the contract to the separate components (ASU 
2018-11);
 (2) provide guidance on transition disclosure in the annual period in which a change in accounting principle is made; and (3) narrow aspects of the guidance issued in the amendments in update 
2016-02
 on various matters (ASU 
2018-10).
 The effective date for all amendments is the same as ASU 
2016-02.

[0001193125-19-225268:notes:122]
The Company will adopt the new lease accounting standard (“ASC 842”) using the modified retrospective transition approach, effective on June 29, 2019. Accordingly, the Company’s comparative financial statements as of June 28, 2019 will not be adjusted. ASC 842 also provides practical expedients for the Company’s ongoing accounting. The Company plans to elect the short-term lease recognition exemption for its operating leases with term of less than 12 months, which will not require recognition of right of use assets or lease liabilities for these leases.

[0001193125-19-225268:notes:123]
The most significant impact of the adoption of ASC 842 is expected to be recognition of right of use assets and lease liabilities for the operating leases with a term of greater than 12 months, while the accounting for finance leases will remain substantially unchanged. ASC 842 will require the Company to provide significant new disclosures about its leasing activities in its interim financial information effective in the first quarter of fiscal year 2020. The Company has assessed the preliminary impact of adopting ASC 842 to the Company’s first quarter financial statements of fiscal year 2020 to be recognized right of use under 
non-current
 assets of $4.8 million, lease liabilities totaling $5.2 million, with $1.3 million under current liabilities and $3.9 million under 
non-current
 liabilities, and a decrease in retained earnings of $0.4 million.

[0001193125-19-225268:notes:124]
New Accounting Pronouncements—adopted by the Company

[0001193125-19-225268:notes:125]
In November 2017, the FASB issued ASU 
2017-14,
 “Income Statement—Reporting Comprehensive Income (Topic 220), Revenue Recognition (Topic 605), and Revenue from Contracts with Customers (Topic 606): Amendments to SEC Paragraphs Pursuant to the Staff Accounting Bulletin (“SAB”) No. 116 and SEC Release 
No. 33-10403”.
 This ASU amended, superseded and added certain SEC paragraphs in Topic 220, Topic 605 and Topic 606 to reflect the August 2017 issuance of SEC Staff Accounting Bulletin (SAB) 116 and SEC Release 
No. 33-10403.
 The SEC staff issued SAB 116 to align its revenue guidance with Accounting Standards Codification (ASC) 606. For public business entities, this update is effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years. Early application is permitted. The Company adopted this standard along with the implementation of ASC 606 effective June 30, 2018 with immaterial impact to the consolidated financial statements.

[0001193125-19-225268:notes:126]
In September 2017, the FASB issued ASU 
2017-13,
 “Revenue Recognition (Topic 605), Revenue from Contracts with Customers (Topic 606), Leases (Topic 840), and Leases (Topic 842): Amendments to SEC Paragraphs Pursuant to the Staff Announcement at the July 20, 2017 EITF Meeting and Rescission of Prior SEC Staff Announcements and Observer Comments.” The amendment delays the mandatory adoption of Topic 606 and Topic 842 for certain entities, revises the guidance related to performance-based incentive fees in Topic 605 and revises the guidance related to leases in Topic 840 and Topic 842. The revisions to the lease guidance eliminate language specific to certain sale-leaseback arrangements, guarantees of lease residual assets and loans made by lessees to owner-lessors. Also included is an amendment to Topic 842 to retain the guidance in Topic 840 covering the impact of changes in tax rates on investments in leveraged leases. This guidance, which is effective immediately, generally relates to the adoption of Topic 606 and Topic 842. The Company adopted this standard along with the implementation of ASC 606 effective June 30, 2018 with immaterial impact to the consolidated financial statements.

[0001193125-19-225268:notes:127]
In January 2017, the FASB issued ASU 
2017-03,
 “Accounting Changes and Error Corrections (Topic 250) and Investments—Equity Method and Joint Ventures (Topic 323): Accounting for Investments in Qualified Affordable Housing Projects: Amendments to SEC Paragraphs Pursuant to Staff Announcements at the September 22, 2016 and November 17, 2016 EITF Meetings.” The amendment provides guidance to the Company in relation to the disclosure of the impact that ASU 
2014-09,
 ASU 
2016-02
 and ASU 
2016-13
 will have on the Company’s financial statements when adopted. The Company adopted this standard along with the implementation of ASC 606 effective June 30, 2018 with immaterial impact to the consolidated financial statements.

[0001193125-19-225268:notes:128]
In August 2016, the FASB issued ASU 
2016-15,
 “Classification of Certain Cash Receipts and Cash Payments (a consensus of the Emerging Issues Task Force).” The amendments in this ASU provide guidance on the presentation of certain cash receipts and cash payments in the statement of cash flows in order to reduce diversity in existing practice. The amendments in ASU 
2016-15
 are effective for public business entities for fiscal years beginning after December 15, 2017, and interim periods within those fiscal years. Early adoption is permitted, including adoption in an interim period. The Company adopted this new update effective June 30, 2018 with no impact to the consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001193125-19-225268:notes:129]
| 3. | Revenues from contracts with customers |

[0001193125-19-225268:notes:130]
On June 30, 2018, the Company adopted Revenue from Contracts with Customers (Topic 606), under Accounting Standards Codification Topic 606 (“ASC 606”), and applied the modified retrospective method to those contracts which were not completed as of June 29, 2018. The modified retrospective method requires the Company to recognize the cumulative effect of the adoption of ASC 606, for all contracts with customers, to the opening balance of equity at June 30, 2018. Accordingly, the Company’s comparative financial information as of June 29, 2018 has not been adjusted and continues to be reported under ASC 605, Revenue Recognition (“ASC 605”).

[0001193125-19-225268:notes:131]
The cumulative effect adjustment recorded was based on the timing difference of revenue recognition between ASC 605 and ASC 606 and mostly related to certain manufacturing contracts with vendor-managed inventory arrangements. Under ASC 605, revenue for such contracts was recognized at the earlier of when the inventory was consumed by the customers or if not consumed, on the expiration of time specified in the contract. On adoption of ASC 606, revenue is recognized when inventory is shipped to customers.

[0001193125-19-225268:notes:132]
The following table shows the impact of adoption of ASC 606 on the adoption date of June 29, 2018 on the consolidated balance sheets:

[0001193125-19-225268:notes:133]
Consolidated Balance Sheets

[0001193125-19-225268:notes:134]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | Balance atJune 29, 2018 |  |  | Adjustment |  |  | Balance atJune 30, 2018 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract assets |  | $ | — |  |  | $ | 9,877 | (1) |  | $ | 9,877 |  |
| Inventory, net |  | $ | 257,687 |  |  | $ | (8,672 | )(2) |  | $ | 249,015 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 632,423 |  |  | $ | 1,205 | (3) |  | $ | 633,628 |  |

[0001193125-19-225268:notes:135]
| (1) | Majority of adjustment relates to certain manufacturing contracts with vendor-managed inventory arrangements for which revenue was recognized on shipment. |

[0001193125-19-225268:notes:136]
| (2) | Adjustment relates to reduction of finished goods inventory for certain vendor-managed inventory arrangements. |

[0001193125-19-225268:notes:137]
| (3) | Adjustment relates to cumulative effect adjustment upon adoption of ASC 606. |

[0001193125-19-225268:notes:138]
Contract Assets and Liabilities

[0001193125-19-225268:notes:139]
A contract asset is recognized when the Company has recognized revenues prior to an invoice for payment. Contract assets are classified separately on the consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. During the year ended June 28, 2019, the Company had no impairment for contract assets recognized.

[0001193125-19-225268:notes:140]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the year ended June 28, 2019:

[0001193125-19-225268:notes:141]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 30, 2018 |  | $ | — |  |
| Cumulative effect adjustment upon adoption of ASC 606 |  |  | 9,877 |  |
| Revenue recognized |  |  | 112,739 |  |
| Amounts collected or invoiced |  |  | (110,169 | ) |
| Ending balance, June 28, 2019 |  | $ | 12,447 |  |

[0001193125-19-225268:notes:142]
| (amount in thousands) |  | ContractLiabilities |  |
| Beginning balance, June 30, 2018 |  | $ | — |  |
| Additions during the year, net |  |  | 4,458 |  |
| Revenue recognized |  |  | (2,219 | ) |
| Ending balance, June 28, 2019 |  | $ | 2,239 |  |

[0001193125-19-225268:notes:143]
Contract Costs

[0001193125-19-225268:notes:144]
Consistent with the guidance in ASC

[0001193125-19-225268:notes:145]
340-40-25-1,

[0001193125-19-225268:notes:146]
the incremental costs of obtaining a contract with a customer are recognized as an asset (not expensed as incurred) if these costs are expected to be recovered. Incremental costs of obtaining a contract are those the Company would not have incurred if the contract had not been obtained (e.g., sales commissions or similar incentive payments linked directly to new or modified customer contracts). Costs that would have been incurred regardless of whether a customer contract was obtained (e.g., costs of pursuing the contact, legal advice, etc.) are expensed as incurred, unless those costs are explicitly chargeable to the customer. During the year ended June 28, 2019, the Company did not have any incremental costs of obtaining a contract.

[0001193125-19-225268:notes:147]
Shipping and Handling

[0001193125-19-225268:notes:148]
Shipping costs billed to customers are recorded as revenue. Shipping and handling expense related to costs incurred to deliver product are recognized within cost of goods sold. The Company accounts for shipping and handling activities that occur after control has transferred as a fulfillment cost, as opposed to a separate performance obligation, and the costs of shipping and handling are recognized concurrently with the related revenue.

[0001193125-19-225268:notes:149]
The impact of adoption of ASC 606 on the Company’s consolidated statements of operations and comprehensive income for the year ended June 28, 2019 and consolidated balance sheets as of June 28, 2019 was as follows:

[0001193125-19-225268:notes:150]
Consolidated Statement of Operations and Comprehensive Income

[0001193125-19-225268:notes:151]
For the Year Ended June 28, 2019

[0001193125-19-225268:notes:152]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | As Reported |  |  | Adjustment |  |  | BalancewithoutASC 606Adoption |  |
| Revenues |  | $ | 1,584,335 |  |  | $ | (2,560 | )(1) |  | $ | 1,581,775 |  |
| Cost of revenues |  | $ | (1,405,111 | ) |  | $ | 1,745 | (2) |  | $ | (1,403,366 | ) |
| Gross profit |  | $ | 179,224 |  |  | $ | (815 | )(3) |  | $ | 178,409 |  |
| Net income |  | $ | 120,955 |  |  | $ | (825 | )(3) |  | $ | 120,130 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.29 |  |  | $ | (0.02 | ) |  | $ | 3.27 |  |
| Diluted |  | $ | 3.23 |  |  | $ | (0.02 | ) |  | $ | 3.21 |  |

[0001193125-19-225268:notes:153]
| (1) | Adjustment relates to certain manufacturing contracts with vendor-managed inventory arrangements for which revenue was recognized at shipping. |

[0001193125-19-225268:notes:154]
| (2) | Adjustment relates to costs associated with revenue recognized. |

[0001193125-19-225268:notes:155]
| (3) | Adjustment relates to net impact on net income upon adoption of ASC 606. |

[0001193125-19-225268:notes:156]
As of June 28, 2019

[0001193125-19-225268:notes:157]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | As Reported |  |  | Adjustments |  |  | BalancewithoutASC 606Adoption |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract assets |  | $ | 12,447 |  |  | $ | (12,447 | )(1) |  | $ | — |  |
| Inventory, net |  | $ | 293,612 |  |  | $ | 10,417 | (2) |  | $ | 304,029 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract liabilities |  | $ | 2,239 |  |  | $ | (2,239 | )(3) |  | $ | — |  |
| Retained earnings |  | $ | 754,583 |  |  | $ | (2,030 | )(4) |  | $ | 752,553 |  |

[0001193125-19-225268:notes:158]
| (2) | Adjustment relates to reduction of finished goods inventory for vendor-managed inventory. |

[0001193125-19-225268:notes:159]
| (3) | Adjustment relates to advance payment arrangements with customers result in the recognition of contract liabilities. |

[0001193125-19-225268:notes:160]
| (4) | Adjustment relates to cumulative effect adjustment upon adoption of ASC 606. |

[0001193125-19-225268:notes:161]
Revenue by Geographic Area

[0001193125-19-225268:notes:162]
Total revenues are attributed to a particular geographic area based on

[0001193125-19-225268:notes:163]
the bill-to-location of

[0001193125-19-225268:notes:164]
customers. The Company operates primarily in three geographic regions: North America, Asia-Pacific and Europe. The following table presents total revenues by geographic regions:

[0001193125-19-225268:notes:165]
| (amount in thousands) |  | Year endedJune 28,2019 |  |  | As a %of TotalRevenues |  |  | Year endedJune 29,2018 |  |  | As a %of TotalRevenues |  |
| North America |  | $ | 756,278 |  |  |  | 47.7 | % |  | $ | 643,236 |  |  |  | 46.9 | % |
| Asia-Pacific |  |  | 608,386 |  |  |  | 38.4 |  |  |  | 519,203 |  |  |  | 37.8 |  |
| Europe |  |  | 219,671 |  |  |  | 13.9 |  |  |  | 209,486 |  |  |  | 15.3 |  |
|  |  | $ | 1,584,335 |  |  |  | 100.0 | % |  | $ | 1,371,925 |  |  |  | 100.0 | % |

[0001193125-19-225268:notes:166]
The following table sets forth revenues by end market.

[0001193125-19-225268:notes:167]
| (amount in thousands) |  | Year endedJune 28,2019 |  |  | As a %of TotalRevenues |  |  | Year endedJune 29,2018 |  |  | As a %of TotalRevenues |  |
| Optical communications |  | $ | 1,184,936 |  |  |  | 74.8 | % |  | $ | 1,000,256 |  |  |  | 72.9 | % |
| Lasers, sensors and other |  |  | 399,399 |  |  |  | 25.2 |  |  |  | 371,669 |  |  |  | 27.1 |  |
|  |  | $ | 1,584,335 |  |  |  | 100.0 | % |  | $ | 1,371,925 |  |  |  | 100.0 | % |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-19-225268:notes:168]
| 4. | Income taxes |

[0001193125-19-225268:notes:169]
Cayman Islands

[0001193125-19-225268:notes:170]
Fabrinet is domiciled in the Cayman Islands. Under the current laws of the Cayman Islands, Fabrinet is not subject to tax in the Cayman Islands on income or capital gains until March 6, 2039.

[0001193125-19-225268:notes:171]
Income of the Company exempted from corporate income tax in the Cayman Islands amounted to $104.6 million, $58.4 million and $64.2 million in the years ended June 28, 2019, June 29, 2018 and June 30, 2017, respectively.

[0001193125-19-225268:notes:172]
Thailand

[0001193125-19-225268:notes:173]
Fabrinet Thailand is where the majority of the Company’s operations and production takes place. The Company is not subject to tax from July 2012 through June 2020 on income generated from the manufacture of products at Pinehurst Building 6, and is not subject to tax from July 2018 through June 2026 on income generated from the manufacture of products at its Chonburi campus. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted (i.e., at least until June 2020 in the case of our Pinehurst campus and until June 2026 in the case of our Chonburi campus). Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001193125-19-225268:notes:174]
People’s Republic of China

[0001193125-19-225268:notes:175]
The corporate income tax rate for Casix is 25%.

[0001193125-19-225268:notes:176]
The United States

[0001193125-19-225268:notes:177]
The Tax Cuts and Jobs Act (“Tax Reform Act”) was enacted on December 22, 2017 and provided for significant changes to U.S. tax law. Among other provisions, the Tax Reform Act reduced the U.S. corporate income tax rate to 21% effective January 1, 2018. The subsidiaries in the U.S. were subject to an average Federal statutory tax rate of 27.6% for fiscal year 2018 and 21% for fiscal year 2019.

[0001193125-19-225268:notes:178]
The United Kingdom

[0001193125-19-225268:notes:179]
The corporate income tax rate for U.K. subsidiaries is 19%.

[0001193125-19-225268:notes:180]
The Company’s income tax expense consisted of the following:

[0001193125-19-225268:notes:181]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 28,2019 |  |  | June 29,2018 |  |  | June 30,2017 |  |
| Current |  | $ | 4,384 |  |  | $ | 5,457 |  |  | $ | 5,986 |  |
| Deferred |  |  | 894 |  |  |  | (1,595 | ) |  |  | 756 |  |
| Total income tax expense |  | $ | 5,278 |  |  | $ | 3,862 |  |  | $ | 6,742 |  |

[0001193125-19-225268:notes:182]
The reconciliation between the Company’s taxes that would arise by applying the statutory tax rate of the country of the Company’s principal operations, Thailand, to the Company’s effective tax charge is shown below:

[0001193125-19-225268:notes:183]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 28,2019 |  |  | June 29,2018 |  |  | June 302017 |  |
| Income before income taxes (1) |  | $ | 126,233 |  |  | $ | 88,029 |  |  | $ | 103,857 |  |
| Tax expense calculated at a statutory corporate income tax rate of 20% |  |  | 25,247 |  |  |  | 17,606 |  |  |  | 20,771 |  |
| Effect of income taxes from locations with tax rates different from Thailand |  |  | 977 |  |  |  | 2,657 |  |  |  | (48 | ) |
| Income not subject to tax (2) |  |  | (21,161 | ) |  |  | (12,824 | ) |  |  | (17,212 | ) |
| Income tax on unremitted earnings |  |  | 1,260 |  |  |  | 1,007 |  |  |  | 798 |  |
| Effect of different tax rate in relation to deferred tax utilization |  |  | — |  |  |  | 423 |  |  |  | — |  |
| Effect of foreign exchange rate adjustment |  |  | 603 |  |  |  | (134 | ) |  |  | 667 |  |
| Tax rebate from research and development application |  |  | (649 | ) |  |  | (454 | ) |  |  | (226 | ) |
| Provision for uncertain income tax position |  |  | (229 | ) |  |  | 277 |  |  |  | 260 |  |
| Utilization of loss carryforward |  |  | — |  |  |  | (3,224 | ) |  |  | — |  |
| (Reversal of) valuation allowance |  |  | — |  |  |  | (1,587 | ) |  |  | 1,517 |  |
| Others |  |  | (770 | ) |  |  | 115 |  |  |  | 215 |  |
| Corporate income tax expense |  | $ | 5,278 |  |  | $ | 3,862 |  |  | $ | 6,742 |  |

[0001193125-19-225268:notes:184]
| (1) | Income before income taxes was mostly generated from domestic income in the Cayman Islands. |

[0001193125-19-225268:notes:185]
| (2) | Income not subject to tax relates to income earned in the Cayman Islands and income subject to an investment promotion privilege for Pinehurst Building 6 and the Company’s Chonburi campus. Income not subject to tax per ordinary share on a diluted basis was $0.57, $0.34, and $0.45 for the years ended June 28, 2019, June 29, 2018, and June 30, 2017, respectively. |

[0001193125-19-225268:notes:186]
The Company’s deferred tax assets and deferred tax liabilities, net of valuation allowance, at each balance sheet date are as follows:

[0001193125-19-225268:notes:187]
|  |  | As of |  |
| (amount in thousands) |  | June 28,2019 |  |  | June 29,2018 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Depreciation |  | $ | 1,957 |  |  | $ | 2,151 |  |
| Severance liability |  |  | 2,012 |  |  |  | 1,518 |  |
| Reserves and allowance |  |  | 1,485 |  |  |  | 1,545 |  |
| Net operating loss carryforwards |  |  | 1,616 |  |  |  | 1,228 |  |
| Others |  |  | 13 |  |  |  | 277 |  |
| Total |  | $ | 7,083 |  |  | $ | 6,719 |  |

[0001193125-19-225268:notes:188]
|  |  | As of |  |
| (amount in thousands) |  | June 28,2019 |  |  | June 29,2018 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Temporary differences from intangibles and changes in the fair value of assets acquired |  | $ | (590 | ) |  | $ | (860 | ) |
| Deferred tax from unremitted earnings |  |  | (4,123 | ) |  |  | (2,863 | ) |
| Others |  |  | (252 | ) |  |  | — |  |
| Total |  |  | (4,965 | ) |  |  | (3,723 | ) |
| Net |  | $ | 2,118 |  |  | $ | 2,996 |  |

[0001193125-19-225268:notes:189]
During fiscal year 2018, one of the Company’s subsidiary in the United States generated taxable income sufficient for the utilization of loss carryforwards due to better operating performance and effective control of operating expenses and management determined that it was more likely than not that future taxable income would be sufficient to allow the benefit of the loss to be realized. As of June 29, 2018, the Company reversed certain deferred tax assets valuation allowance as management expected it was more likely than not that the Company would realize profits in subsequent fiscal years so that the loss carryforwards could be partially utilized. Consequently, as of June 28, 2019, the Company has assessed and established a partial valuation allowance for the deferred tax assets at the same level as in fiscal year 2018.

[0001193125-19-225268:notes:190]
The changes in the valuation allowances of deferred tax assets were as follows:

[0001193125-19-225268:notes:191]
| (amount in thousands) |  | Valuation allowances ofdeferred tax assets |  |
| Balance as of June 30, 2017 |  | $ | 6,399 |  |
| Reversal |  |  | (5,234 | ) |
| Balance as of June 29, 2018 |  |  | 1,165 |  |
| Additional |  |  | 126 |  |
| Balance as of June 28, 2019 |  | $ | 1,291 |  |

[0001193125-19-225268:notes:192]
During fiscal year 2019, the Company completed its assessment of the income tax effects resulting from the Tax Reform Act and concluded that no cumulative remeasurement adjustments were required.

[0001193125-19-225268:notes:193]
During fiscal year 2018, the Company made certain provisional accounting estimates, as permitted under Staff Accounting Bulletin No. 118, to account for the impact of the Tax Reform Act.

[0001193125-19-225268:notes:194]
As of June 29, 2018, the Company applied the new corporate tax rate to compute its current income tax and remeasured its deferred tax assets and liabilities for all U.S. subsidiaries to reflect the lower rate expected to apply when these provisional accounting estimates were utilized. The remeasurement resulted in (1) a reduction in current income tax expenses of $0.1 million and (2) a reduction in deferred tax assets of $0.4 million.

[0001193125-19-225268:notes:195]
Income tax liabilities have not been established for withholding tax and other taxes that would be payable on the unremitted earnings of Fabrinet Thailand. Such amounts of Fabrinet Thailand are permanently reinvested; unremitted earnings for Fabrinet Thailand totaled $109.7 million and $102.5 million as of June 28, 2019 and June 29, 2018, respectively. Unrecognized deferred tax liabilities for such unremitted earnings were $6.9 million and $5.8 million as of June 28, 2019 and June 29, 2018, respectively.

[0001193125-19-225268:notes:196]
Deferred tax liabilities of $1.3 million and $1.0 million have been established for withholding tax on the unremitted earnings of Casix for the years ended June 28, 2019 and June 29, 2018, respectively, which are included in 
non-current
 deferred tax liability in the consolidated balance sheets.

[0001193125-19-225268:notes:197]
Uncertain income tax positions

[0001193125-19-225268:notes:198]
Interest and penalties related to uncertain income tax positions are recognized in income tax expense. The Company had approximately $0.8 million and $0.9 million of accrued interest and penalties related to uncertain income tax positions on the consolidated balance sheets as of June 28, 2019 and June 29, 2018, respectively. The Company (reversed) recorded interest and penalties of $(0.1) million, $0.3 million and $0.3 million for the years ended June 28, 2019, June 29, 2018 and June 30, 2017, respectively, in the consolidated statements of operations and comprehensive income. With regard to the Thailand jurisdiction, tax years 2014 through 2018 remain open to examination by the local authorities.

[0001193125-19-225268:notes:199]
The following table indicates the changes to the Company’s uncertain income tax positions for the years ended June 28, 2019, June 29, 2018 and June 30, 2017 included in other 
non-current
 liabilities.

[0001193125-19-225268:notes:200]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 28,2019 |  |  | June 29,2018 |  |  | June 30,2017 |  |
| Beginning balance |  | $ | 1,445 |  |  | $ | 1,420 |  |  | $ | 1,420 |  |
| Additions during the year |  |  | 235 |  |  |  | 25 |  |  |  | — |  |
| Release of tax positions of prior years |  |  | (357 | ) |  |  | — |  |  |  | — |  |
| Ending balance |  | $ | 1,323 |  |  | $ | 1,445 |  |  | $ | 1,420 |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-19-225268:notes:201]
| 5. | Earnings per ordinary share |

[0001193125-19-225268:notes:202]
Basic earnings per ordinary share is computed by dividing reported net income by the weighted average number of ordinary shares outstanding during each period. Diluted earnings per ordinary share is computed by calculating the effect of potential dilutive ordinary shares outstanding during the year using the treasury

[0001193125-19-225268:notes:203]
stock method. Dilutive ordinary equivalent shares consist of share options, restricted share units and performance share units. The earnings per ordinary share was calculated as follows:

[0001193125-19-225268:notes:204]
|  |  | Years Ended |  |
| (amount in thousands except per share amounts) |  | June 28,2019 |  |  | June 29,2018 |  |  | June 30,2017 |  |
| Net income attributable to shareholders |  | $ | 120,955 |  |  | $ | 84,167 |  |  | $ | 97,115 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  | 36,798 |  |  |  | 37,257 |  |  |  | 36,927 |  |
| Incremental shares arising from the assumed exercise of share options and vesting of restricted share units and performance share units (thousands of shares) |  |  | 617 |  |  |  | 778 |  |  |  | 925 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 37,415 |  |  |  | 38,035 |  |  |  | 37,852 |  |
| Basic earnings per ordinary share |  | $ | 3.29 |  |  | $ | 2.26 |  |  | $ | 2.63 |  |
| Diluted earnings per ordinary share |  | $ | 3.23 |  |  | $ | 2.21 |  |  | $ | 2.57 |  |
| Outstanding performance share units excluded from the computation of diluted earnings per ordinary share (thousands of shares) (1) |  |  | 401 |  |  |  | 284 |  |  |  | — |  |

[0001193125-19-225268:notes:205]
| (1) | Outstanding performance share units were not included in the computation of diluted earnings per ordinary share because they are not expected to vest based on the Company’s current assessment of the related performance obligations. |

[0001193125-19-225268:notes:206]
As of June 28, 2019, June 29, 2018 and June 30, 2017, there were no anti-dilutive share options.


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001193125-19-225268:notes:207]
| 6. | Cash, cash equivalents and short-term investments |

[0001193125-19-225268:notes:208]
The Company’s cash, cash equivalents, and short-term investments can be analyzed as follows:

[0001193125-19-225268:notes:209]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | CarryingCost |  |  | UnrealizedGain/(Loss) |  |  | Cash andCashEquivalents |  |  | MarketableSecurities |  |  | OtherInvestments |  |
| As of June 28, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 178,019 |  |  | $ | — |  |  | $ | 178,019 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 2,820 |  |  |  | — |  |  |  | 2,820 |  |  |  | — |  |  |  | — |  |
| Liquidity funds |  |  | 20,552 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 20,552 |  |
| Certificates of deposit and time deposits |  |  | 35,028 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 35,028 |  |
| Corporate bonds and commercial papers |  |  | 130,959 |  |  |  | 297 |  |  |  | — |  |  |  | 131,256 |  |  |  | — |  |
| U.S. agency and U.S. treasury securities |  |  | 69,552 |  |  |  | 105 |  |  |  | — |  |  |  | 69,657 |  |  |  | — |  |
| Total |  | $ | 436,930 |  |  | $ | 402 |  |  | $ | 180,839 |  |  | $ | 200,913 |  |  | $ | 55,580 |  |
| As of June 29, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 146,778 |  |  | $ | — |  |  | $ | 146,778 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 11,324 |  |  |  | — |  |  |  | 11,324 |  |  |  | — |  |  |  | — |  |
| Liquidity funds |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Certificates of deposit and time deposits |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 128,441 |  |  |  | (736 | ) |  |  | — |  |  |  | 127,705 |  |  |  | — |  |
| U.S. agency and U.S. treasury securities |  |  | 43,734 |  |  |  | (324 | ) |  |  | — |  |  |  | 43,410 |  |  |  | — |  |
| Sovereign and municipal securities |  |  | 3,185 |  |  |  | (31 | ) |  |  | — |  |  |  | 3,154 |  |  |  | — |  |
| Total |  | $ | 333,462 |  |  | $ | (1,091 | ) |  | $ | 158,102 |  |  | $ | 174,269 |  |  | $ | — |  |

[0001193125-19-225268:notes:210]
The cash equivalents include short-term bank deposits, investments in money market funds, and marketable securities with maturities of three months or less at the date of purchase. The effective interest rate on short term bank deposits was 1.9% and 0.8% per annum for the years ended June 28, 2019 and June 29, 2018, respectively.

[0001193125-19-225268:notes:211]
As of June 28, 2019 and June 29, 2018, 58% and 49%, respectively, of our cash and cash equivalents were held by the Parent Company.

[0001193125-19-225268:notes:212]
The following table summarizes the cost and estimated fair value of marketable securities classified as

[0001193125-19-225268:notes:213]
securities based on stated effective maturities as of June 28, 2019:

[0001193125-19-225268:notes:214]
| (amount in thousands) |  | CarryingCost |  |  | Fair Value |  |
| Due within one year |  | $ | 69,746 |  |  | $ | 69,830 |  |
| Due between one to five years |  |  | 130,765 |  |  |  | 131,083 |  |
| Total |  | $ | 200,511 |  |  | $ | 200,913 |  |

[0001193125-19-225268:notes:215]
During the year ended June 28, 2019, the Company recognized a realized gain of $0.2 million from sales and maturities of

[0001193125-19-225268:notes:216]
securities.

[0001193125-19-225268:notes:217]
As of June 28, 2019 and June 29, 2018, the Company considered the declines in market value of its short-term investment portfolio to be temporary in nature and did not consider any of its securities other-than-temporarily impaired. The Company typically invests in highly-rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy requires investments generally to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. When evaluating an investment for other-than-temporary impairment, the Company reviews factors such as the length of time and extent to which fair value has been below its cost basis, the financial condition of the issuer and any changes thereto, changes in market interest rates, and the Company’s intent to sell, or whether it is more likely than not it will be required to sell, the investment before recovery of the investment’s cost basis. No impairment losses were recorded for the years ended June 28, 2019 and June 29, 2018.

[0001193125-19-225268:notes:218]
As of June 28, 2019 and June 29, 2018, cash, cash equivalents, and short-term investments included a bank deposit of $40.0 million held in various financial institutions located in the United States in order to support the availability of the Facility Agreement and comply with covenants. Under the terms and conditions of the Facility Agreement, the Company shall maintain cash, cash equivalents and/or marketable securities in an aggregate amount not less than $40.0 million in unencumbered deposits, and/or securities in accounts located in the United States at all times during the term of the Facility Agreement. As discussed in Note 15, the Company must comply with this covenant from and after the effective date of the Facility Agreement.


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-19-225268:notes:219]
| 7. | Fair Value |

[0001193125-19-225268:notes:220]
The following table provides details of the financial instruments measured at fair value on a recurring basis, including:

[0001193125-19-225268:notes:221]
|  |  | Fair Value Measurements at Reporting DateUsing |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 28, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 2,820 |  |  | $ | — |  |  | $ | 2,820 |  |
| Liquidity funds |  |  | — |  |  |  | 20,552 |  |  |  | — |  |  |  | 20,552 |  |
| Certificates of deposit and time deposits |  |  | — |  |  |  | 35,028 |  |  |  | — |  |  |  | 35,028 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 131,256 |  |  |  | — |  |  |  | 131,256 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 69,657 |  |  |  | — |  |  |  | 69,657 |  |
| Derivative assets |  |  | — |  |  |  | 2,201 | (1) |  |  | — |  |  |  | 2,201 |  |
| Total |  | $ | — |  |  | $ | 261,514 |  |  | $ | — |  |  | $ | 261,514 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 2,591 | (2) |  | $ | — |  |  | $ | 2,591 |  |
| Total |  | $ | — |  |  | $ | 2,591 |  |  | $ | — |  |  | $ | 2,591 |  |

[0001193125-19-225268:notes:222]
|  |  | Fair Value Measurements at Reporting DateUsing |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 29, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 11,324 |  |  | $ | — |  |  | $ | 11,324 |  |
| Liquidity funds |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Certificates of deposit and time deposits |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 127,705 |  |  |  | — |  |  |  | 127,705 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 43,410 |  |  |  | — |  |  |  | 43,410 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 3,154 |  |  |  | — |  |  |  | 3,154 |  |
| Derivative assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | — |  |  | $ | 185,593 |  |  | $ | — |  |  | $ | 185,593 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 1,745 | (3) |  | $ | — |  |  | $ | 1,745 |  |
| Total |  | $ | — |  |  | $ | 1,745 |  |  | $ | — |  |  | $ | 1,745 |  |

[0001193125-19-225268:notes:223]
| (1) | Foreign currency forward contracts with notional amount of $72.0 million and Canadian dollars 0.6 million. |

[0001193125-19-225268:notes:224]
| (2) | Interest rate swap agreement with an outstanding amount of $60.9 million. |

[0001193125-19-225268:notes:225]
| (3) | Foreign currency forward contracts with notional amount of $7.0 million and Canadian dollars 0.4 million. Foreign currency option contracts with notional amount of $30.0 million. |

[0001193125-19-225268:notes:226]
Derivative Financial Instruments

[0001193125-19-225268:notes:227]
As a result of foreign currency rate fluctuations, the U.S. dollar equivalent values of the Company’s foreign currency denominated assets and liabilities change. The Company uses foreign currency contracts to manage the foreign exchange risk associated with certain foreign currency denominated assets and liabilities and other foreign currency transactions. The Company minimizes the credit risk in derivative instruments by limiting its exposure to any single counterparty and by entering into derivative instruments only with counterparties that meet the Company’s minimum credit quality standard. As of June 28, 2019, the Company recognized the fair value of foreign currency forward contracts of $2.2 million as derivative assets in the consolidated balance sheets under other current assets and the Company recognized the fair value of interest rate swap agreement of $2.6 million as derivative liabilities in the consolidated balance sheets under other current liabilities. As of June 29, 2018, the Company recognized the fair value of foreign currency forward contracts of $1.7 million as derivative liabilities in the consolidated balance sheets under other current liabilities.

[0001193125-19-225268:notes:228]
As of June 28, 2019 and June 29, 2018, the Company had no foreign currency forward contracts designated as cash flow hedges. During the year ended June 30, 2017, the Company discontinued cash flow hedges and recognized a gain from unwinding foreign currency forward contracts of $0.3 million as foreign exchange gain, net in the consolidated statements of operations and comprehensive income.

[0001193125-19-225268:notes:229]
As of June 28, 2019, the Company had forty-five outstanding foreign currency forward contracts with an aggregate notional amount of $72.0 million and one foreign currency forward contract with notional amount of Canadian dollars 0.6 million with maturity dates from July through September 2019. These foreign currency forward contracts were not designated for hedge accounting and were used to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht and Canadian dollars. During the year ended June 28, 2019, the Company included unrealized gain of $4.8 million from changes in fair value of foreign currency contracts in earnings as foreign exchange gain (loss), net in the consolidated statements of operations and comprehensive income.

[0001193125-19-225268:notes:230]
As of June 29, 2018, the Company had five outstanding foreign currency forward contracts with notional amount of $7.0 million, four outstanding foreign currency option contracts with notional amount of $30.0 million and one foreign currency forward contract with notional amount of Canadian dollars 0.4 million with maturity dates from July through October 2018. These foreign currency forward and option contracts were not designated for hedge accounting and were used to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht and Canadian dollars. During the year ended June 29, 2018, the Company included unrealized loss of $1.7 million from changes in fair value of foreign currency contracts in earnings as foreign exchange loss, net in the consolidated statements of operations and comprehensive income.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001193125-19-225268:notes:231]
| 8. | Trade accounts receivable, net |

[0001193125-19-225268:notes:232]
| (amount in thousands) |  | As ofJune 28,2019 |  |  | As ofJune 29,2018 |  |
| Trade accounts receivable |  | $ | 260,698 |  |  | $ | 246,972 |  |
| Less: Allowance for doubtful account |  |  | (96 | ) |  |  | (60 | ) |
| Trade accounts receivable, net |  | $ | 260,602 |  |  | $ | 246,912 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-19-225268:notes:233]
| 9. | Inventory |

[0001193125-19-225268:notes:234]
| (amount in thousands) |  | As ofJune 28,2019 |  |  | As ofJune 29,2018 |  |
| Raw materials |  | $ | 115,008 |  |  | $ | 100,241 |  |
| Work in progress |  |  | 142,039 |  |  |  | 121,797 |  |
| Finished goods |  |  | 24,916 |  |  |  | 20,690 |  |
| Goods in transit |  |  | 13,645 |  |  |  | 17,516 |  |
|  |  |  | 295,608 |  |  |  | 260,244 |  |
| Less: Inventory obsolescence |  |  | (1,996 | ) |  |  | (2,557 | ) |
| Inventory, net |  | $ | 293,612 |  |  | $ | 257,687 |  |


## fn:RestrictedCashAndCashEquivalentsTextBlock

[0001193125-19-225268:notes:235]
| 10. | Restricted cash |

[0001193125-19-225268:notes:236]
As of June 28, 2019, the Company had an outstanding standby letter of credit of 6.0 million Euros related to the Company’s support of a customer with the transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. As of June 28, 2019, the standby letter of credit was backed by cash collateral of $7.4 million. As of June 29, 2018, the Company had a restricted cash balance of $3.3 million in connection with business acquisitions.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-19-225268:notes:237]
| 11. | Business acquisition |

[0001193125-19-225268:notes:238]
On September 14, 2016, the Company acquired 100% shareholding in Fabrinet UK for cash consideration of approximately $13.0 million, net of $0.5 million cash acquired. Fabrinet UK provides contract electronics manufacturing services to the global electronics industry with innovative solutions, adding value to the design, manufacture and testing of printed circuit board assemblies. Pursuant to the acquisition agreement, the Company placed $3.4 million of cash, net of foreign currency translation adjustment, for deferred consideration in an escrow account which is under the Company’s control. However, the Company contractually agreed to remit this deferred consideration to the sellers of Fabrinet UK, subject to the resolution of claims that the Company may make against the funds with respect to indemnification and other claims, within 24 months from the closing date of the transaction.

[0001193125-19-225268:notes:239]
The Company has accounted for this acquisition under the provisions of business combinations accounting, in accordance with Accounting Standards Codification Topic 805 – Business Combinations. Accordingly, the estimated fair value of the acquisition consideration was allocated to the assets acquired and the liabilities assumed based on their respective fair values on the acquisition date. The Company has made certain estimates and assumptions in determining the allocation of the acquisition consideration.

[0001193125-19-225268:notes:240]
The allocation of consideration to the individual net assets acquired was finalized in the fourth quarter of fiscal year 2017. As the functional currency of Fabrinet UK is pound sterling (“GBP”), for the year ended June 28, 2019, the Company recognized a $0.6 million loss from foreign currency translation adjustment in its consolidated statements of operations and comprehensive income, under other comprehensive (loss) income, net of tax.

[0001193125-19-225268:notes:241]
During the year ended June 30, 2017, the Company recorded a measurement period adjustment to recognized deferred tax liabilities of $1.2 million related to taxable temporary differences from intangibles and changes in the fair value of assets acquired. Therefore, goodwill which was previously reported at acquisition date of $2.7 million was changed to $3.9 million.

[0001193125-19-225268:notes:242]
The Company’s allocation of the total purchase price for the acquisition is summarized below:

[0001193125-19-225268:notes:243]
| (amount in thousands) |  | Purchasepriceallocation |  |
| Cash |  | $ | 474 |  |
| Accounts receivable |  |  | 4,064 |  |
| Inventory |  |  | 3,490 |  |
| Other current assets |  |  | 427 |  |
| Property, plant and equipment |  |  | 5,678 |  |
| Intangibles |  |  | 4,492 |  |
| Goodwill |  |  | 3,883 |  |
| Other non-current assets |  |  | 516 |  |
| Current liabilities |  |  | (6,796 | ) |
| Deferred tax liabilities |  |  | (1,148 | ) |
| Other non-current liabilities |  |  | (1,563 | ) |
| Total fair value of assets acquired and liabilities assumed |  | $ | 13,517 |  |
| Total purchase price, net of cash acquired |  | $ | 13,043 |  |

[0001193125-19-225268:notes:244]
In connection with the Company’s acquisition of Fabrinet UK, the Company assumed lease agreements for certain machine and equipment, which are accounted for as capital leases. As of June 28, 2019, the Company included approximately $0.9 million of capital lease assets and $0.5 million of capital lease liability in the consolidated balance sheets associated with these acquired lease agreements.

[0001193125-19-225268:notes:245]
During the year ended June 30, 2017, the Company incurred approximately $1.5 million in transaction costs related to the acquisition, which primarily consisted of legal, accounting and valuation-related expenses. These expenses were recorded in selling, general and administrative expense in the accompanying consolidated statements of operations and comprehensive income.

[0001193125-19-225268:notes:246]
During the year ended June 28, 2019 and June 29, 2018 there were no transaction costs related to the acquisition.

[0001193125-19-225268:notes:247]
Pro forma results of operations for the acquisition have not been presented as they were not material to the Company’s results of operations.

[0001193125-19-225268:notes:248]
Identifiable intangibles

[0001193125-19-225268:notes:249]
The acquired identifiable intangible assets include customer relationships and backlog. The fair value of the identified intangible assets was determined based on the multi-period excess earnings method, which applied the following key assumptions:

[0001193125-19-225268:notes:250]
| Risk free rate: |  | 30-year UK Government Bond adjusted by spot yield to reflect recent volatility |
| Long-term revenue growth: |  | 5.0% - 8.0% |
| Churn rate: |  | 10% |
| Operating margin: |  | 4.0% - 6.0% |

[0001193125-19-225268:notes:251]
Customer relationships represent the fair value of future projected revenues derived from the sale of products to existing customers of the acquired company. The fair value of $4.4 million will be amortized, using the accelerated method, over an estimated useful life of ten years.

[0001193125-19-225268:notes:252]
Backlog represents the fair value of sales orders backlog as of the valuation date. The fair value of $0.1 million will be amortized, using an accelerated amortization method, over the respective estimated useful life of three years.

[0001193125-19-225268:notes:253]
Goodwill arising from the acquisition is primarily attributable to the ability to expand future products and services and the assembled workforce. Goodwill is not deductible for tax purposes.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001193125-19-225268:notes:254]
| 12. | Property, plant and equipment, net |

[0001193125-19-225268:notes:255]
The components of property, plant and equipment, net were as follows:

[0001193125-19-225268:notes:256]
| (amount in thousands) |  | Land andLandImprovements |  |  | Building andBuildingImprovements |  |  | ManufacturingEquipment |  |  | OfficeEquipment |  |  | MotorVehicles |  |  | Computers |  |  | ConstructionandMachineryUnderInstallation |  |  | Total |  |
| As of June 28, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost |  | $ | 45,080 |  |  | $ | 142,909 |  |  | $ | 163,795 |  |  | $ | 5,029 |  |  | $ | 870 |  |  | $ | 13,987 |  |  | $ | 10,815 |  |  | $ | 382,485 |  |
| Less: Accumulated depreciation |  |  | (11 | ) |  |  | (44,736 | ) |  |  | (110,980 | ) |  |  | (3,656 | ) |  |  | (658 | ) |  |  | (10,900 | ) |  |  | — |  |  |  | (170,941 | ) |
| Less: Impairment reserve |  |  | — |  |  |  | — |  |  |  | (856 | ) |  |  | — |  |  |  | — |  |  |  | (2 | ) |  |  | — |  |  |  | (858 | ) |
| Net book value |  | $ | 45,069 |  |  | $ | 98,173 |  |  | $ | 51,959 |  |  | $ | 1,373 |  |  | $ | 212 |  |  | $ | 3,085 |  |  | $ | 10,815 |  |  | $ | 210,686 |  |
| As of June 29, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost |  | $ | 45,080 |  |  | $ | 139,342 |  |  | $ | 141,869 |  |  | $ | 7,582 |  |  | $ | 456 |  |  | $ | 21,250 |  |  | $ | 8,762 |  |  | $ | 364,341 |  |
| Less: Accumulated depreciation |  |  | (6 | ) |  |  | (38,265 | ) |  |  | (86,989 | ) |  |  | (4,454 | ) |  |  | (334 | ) |  |  | (14,653 | ) |  |  | — |  |  |  | (144,701 | ) |
| Net book value |  | $ | 45,074 |  |  | $ | 101,077 |  |  | $ | 54,880 |  |  | $ | 3,128 |  |  | $ | 122 |  |  | $ | 6,597 |  |  | $ | 8,762 |  |  | $ | 219,640 |  |

[0001193125-19-225268:notes:257]
On December 23, 2016, the Company entered into an agreement to purchase a parcel of land in Chonburi, Thailand to support the expansion of the Company’s production in Thailand. The aggregate purchase price was approximately $5.6 million, of which the first installment of $1.1 million was paid by the Company on January 10, 2017 and the remaining balance of the purchase price was fully paid on December 25, 2017.

[0001193125-19-225268:notes:258]
Leased assets included in manufacturing equipment comprise certain machine and equipment from capital lease agreements assumed from the acquisition of Fabrinet UK.

[0001193125-19-225268:notes:259]
| (amount in thousands) |  | As ofJune 28, 2019 |  |  | As ofJune 29, 2018 |  |
| Cost—Capital leases |  | $ | 2,034 |  |  |  | 2,481 |  |
| Less: Accumulated depreciation |  |  | (1,090 | ) |  |  | (1,043 | ) |
| Net book value |  | $ | 944 |  |  |  | 1,438 |  |

[0001193125-19-225268:notes:260]
Depreciation expense amounted to $28.7 million, $27.4 million and $22.5 million for the years ended June 28, 2019, June 29, 2018 and June 30, 2017, respectively, and has been allocated between cost of revenues and selling, general and administrative expenses in the consolidated statements of operations and comprehensive income.

[0001193125-19-225268:notes:261]
The cost of fully depreciated property, plant and equipment 
written-off
 during the years ended June 28, 2019, June 29, 2018 and June 30, 2017 amounted to $2.0 million, $3.5 million and $5.4 million, respectively.

[0001193125-19-225268:notes:262]
During the year ended June 28, 2019 the Company recognized impairment reserves for property, plant and equipment of $0.9 million. During the year ended June 29, 2018, no impairment was recognized for property, plant and equipment.

[0001193125-19-225268:notes:263]
During the year ended June 28, 2019 and June 29, 2018, the Company had no borrowing costs capitalized.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-19-225268:notes:264]
| 13. | Intangibles |

[0001193125-19-225268:notes:265]
The following tables present details of the Company’s intangibles:

[0001193125-19-225268:notes:266]
| (amount in thousands) |  | GrossCarryingAmount |  |  | AccumulatedAmortization |  |  | ForeignCurrencyTranslationAdjustment |  |  | Net |  |
| As of June 28, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 6,582 |  |  | $ | (4,868 | ) |  | $ | — |  |  | $ | 1,714 |  |
| Customer relationships |  |  | 4,373 |  |  |  | (2,096 | ) |  |  | (104 | ) |  |  | 2,173 |  |
| Backlog |  |  | 119 |  |  |  | (119 | ) |  |  | — |  |  |  | — |  |
| Total intangibles |  | $ | 11,074 |  |  | $ | (7,083 | ) |  | $ | (104 | ) |  | $ | 3,887 |  |

[0001193125-19-225268:notes:267]
| (amount in thousands) |  | GrossCarryingAmount |  |  | AccumulatedAmortization |  |  | ForeignCurrencyTranslationAdjustment |  |  | Net |  |
| As of June 29, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 6,269 |  |  | $ | (4,324 | ) |  | $ | — |  |  | $ | 1,945 |  |
| Customer relationships |  |  | 4,373 |  |  |  | (1,413 | ) |  |  | (42 | ) |  |  | 2,918 |  |
| Backlog |  |  | 119 |  |  |  | (101 | ) |  |  | (1 | ) |  |  | 17 |  |
| Total intangibles |  | $ | 10,761 |  |  | $ | (5,838 | ) |  | $ | (43 | ) |  | $ | 4,880 |  |

[0001193125-19-225268:notes:268]
In connection with the acquisition of Fabrinet UK, the Company recorded $4.4 million of customer relationships and $0.1 million of backlog in the consolidated balance sheets. As of June 28, 2019, the weighted-average remaining life of customer relationships was 5.4 years. As of June 29, 2018, the weighted-average remaining life of customer relationships and backlog was 6.1 years and 0.9 years, respectively.

[0001193125-19-225268:notes:269]
The Company recorded amortization expense relating to intangibles of $1.2 million, $1.7 million and $1.2 million for the years ended June 28, 2019, June 29, 2018 and June 30, 2017, respectively.

[0001193125-19-225268:notes:270]
As of June 28, 2019, the estimated future amortization of intangible assets during each fiscal year was as follows:

[0001193125-19-225268:notes:271]
| (amount in thousand) |  |  |  |
| 2020 |  | $ | 1,359 |  |
| 2021 |  |  | 952 |  |
| 2022 |  |  | 707 |  |
| 2023 |  |  | 445 |  |
| 2024 |  |  | 231 |  |
| Thereafter |  |  | 193 |  |
| Total |  | $ | 3,887 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-19-225268:notes:272]
| 14. | Goodwill |

[0001193125-19-225268:notes:273]
In connection with the acquisition of Fabrinet UK, the Company recorded $3.8 million of goodwill in the consolidated balance sheets.

[0001193125-19-225268:notes:274]
The changes in the carrying amount of goodwill were as follows:

[0001193125-19-225268:notes:275]
| (amount in thousands) |  | Goodwill |  |
| Balance as of June 29, 2018 |  | $ | 3,828 |  |
| Foreign currency translation adjustment |  |  | (123 | ) |
| Balance as of June 28, 2019 |  | $ | 3,705 |  |

[0001193125-19-225268:notes:276]
Goodwill is not deductible for tax purposes. Goodwill is reviewed annually for impairment or more frequently whenever changes or circumstances indicate the carrying amount of goodwill may not be recoverable. As of June 28, 2019, the Company performed the annual impairment test for goodwill, which indicated there was no goodwill impairment.


## us-gaap:DebtDisclosureTextBlock

[0001193125-19-225268:notes:277]
| 15. | Borrowings |

[0001193125-19-225268:notes:278]
The Company’s total borrowings, including short-term and long-term borrowings, consisted of the following:

[0001193125-19-225268:notes:279]
(
amount in thousands
)

[0001193125-19-225268:notes:280]
| Rate (1) |  | Conditions |  |  | Maturity |  |  | As of June 28, 2019 |  |  | As of June 29, 2018 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Current portion of long-term borrowing |  |  |  |  |  |  |  |  |  | $ | 3,250 |  |  | $ | 3,250 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.50% per annum |  |  | Repayablein quarterlyinstallments |  |  |  | June 2023 |  |  | $ | 60,938 |  |  | $ | 64,188 |  |
|  |  |  |  |  |  |  |  |  |  |  | 60,938 |  |  |  | 64,188 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (3,250 | ) |  |  | (3,250 | ) |
| Non-current portion of long-term borrowing |  |  |  |  |  |  |  |  |  | $ | 57,688 |  |  | $ | 60,938 |  |

[0001193125-19-225268:notes:281]
|  | (1) | LIBOR is London Interbank Offered Rate. |

[0001193125-19-225268:notes:282]
The movements of long-term borrowings were as follows for the years ended June 28, 2019 and June 29, 2018:

[0001193125-19-225268:notes:283]
|  |  | Years ended |  |
| (amount in thousands) |  | June 28,2019 |  |  | June 29,2018 |  |
| Opening net book amount |  | $ | 64,188 |  |  | $ | 36,400 |  |
| Additional loan during the period |  |  | — |  |  |  | 39,000 |  |
| Repayment during the period |  |  | (3,250 | ) |  |  | (11,212 | ) |
| Closing net book amount |  | $ | 60,938 |  |  | $ | 64,188 |  |

[0001193125-19-225268:notes:284]
As of June 28, 2019, the future maturities of long-term borrowings during each fiscal year were as follows:

[0001193125-19-225268:notes:285]
| (amount in thousand) |  |  |  |
| 2020 |  | $ | 3,250 |  |
| 2021 |  |  | 3,250 |  |
| 2022 |  |  | 3,250 |  |
| 2023 |  |  | 51,188 |  |
| Total |  | $ | 60,938 |  |

[0001193125-19-225268:notes:286]
Credit facilities:

[0001193125-19-225268:notes:287]
The Company entered into a syndicated senior credit facility agreement (the “Facility Agreement”) with a consortium of banks on May 22, 2014. The Facility Agreement, led by Bank of America, provided for a $200.0 million credit line, comprised of a $150.0 million revolving loan facility and a $50.0 million delayed draw term loan facility. The revolving loan facility contained an accordion feature permitting Fabrinet to request an increase in the facility up to $100.0 million subject to customary terms and conditions and provided that no default or event of default exists at the time of request.

[0001193125-19-225268:notes:288]
On February 26, 2015, the Company entered into the Second Amendment to the Facility Agreement, which extended the availability period for draws on the term loan facility from May 21, 2015 to July 31, 2015 and allowed the Company, upon the satisfaction of certain conditions, to designate from time to time one or more of its subsidiaries as borrowers under the Facility Agreement. On July 31, 2015, the Company entered into the Third Amendment to the Facility Agreement, which extended the availability period for draws on the term loan facility from July 31, 2015 to July 31, 2016. On July 22, 2016, the Company entered into the Fourth Amendment to the Facility Agreement to change the timing of filing certain financial information with the bank.

[0001193125-19-225268:notes:289]
On June 4, 2018, the Company entered into the Fifth Amendment to the Facility Agreement to (i) reduce the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) extend the termination date of the revolving commitments from May 22, 2019 to June 4, 2023, (iii) refinance the then-existing term loan and revolving loans under the Facility Agreement into a $65.0 million term loan, and (iv) reduce the applicable interest rate margins and commitment fees. Term loans must be repaid in quarterly installments, beginning on June 30, 2018, with the remaining outstanding principal and accrued and unpaid interest being due and payable on June 4, 2023. After giving effect to the amendment, $65.0 million aggregate principal amount of term loans and no revolving loans were outstanding under the Facility Agreement. In addition, the Fifth Amendment contains an accordion feature permitting the Company to request an increase in the revolving loan facility to provide up to an aggregate of $200.0 million in additional commitments, subject to customary terms and conditions, and provided that no default or event of default exists at the time of such request. As of June 28, 2019 and June 29, 2018, $60.9 million and $64.2 million aggregate principal amount of term loans, respectively, and no revolving loans were outstanding under the Facility Agreement.

[0001193125-19-225268:notes:290]
As a result of the Fifth Amendment, loans under the Facility Agreement bear interest, at Fabrinet’s option, at a rate per annum equal to a LIBOR rate plus a spread of 1.50% to 2.25%, or a base rate plus a spread of 0.50% to 1.25%, determined in accordance with the Facility Agreement in each case with such spread determined based on Fabrinet’s consolidated total leverage ratio for the preceding four fiscal quarter period.

[0001193125-19-225268:notes:291]
Interest is due and payable monthly in arrears for loans bearing interest at the base rate and at the end of an interest period (or at each three-month interval in the case of loans with interest periods greater than three months) in the case of loans bearing interest at the LIBOR rate.

[0001193125-19-225268:notes:292]
Fabrinet’s obligations under the Facility Agreement are guaranteed by certain existing and future material subsidiaries. In addition, the Facility Agreement is secured by Fabrinet’s present and future accounts receivable, deposit accounts and cash, and a pledge of the capital stock of certain of Fabrinet’s direct subsidiaries. Fabrinet is required to maintain at least $40.0 million of cash, cash equivalents, and marketable securities at financial institutions located in the United States. Further, Fabrinet is required to maintain any of its deposits accounts or securities accounts with balances in excess of $20.0 million in a jurisdiction where a control agreement, or the equivalent under the local law, can be effected.

[0001193125-19-225268:notes:293]
The Facility Agreement contains customary affirmative and negative covenants. Negative covenants include, among other things, limitations on liens, indebtedness, investments, mergers, sales of assets, changes in the nature of the business, dividends and distributions, affiliate transactions and capital expenditures. The Facility Agreement contains financial covenants requiring Fabrinet to maintain: (1) a minimum tangible net worth of not less than $338.0 million plus 50% of quarterly net income after June 30, 2018, exclusive of quarterly losses; (2) a minimum debt service coverage ratio of not less than 1.50:1.00; (3) a maximum total leverage ratio of not more than 2.50:1.00; and (4) a minimum quick ratio of not less than 1.10:1.00. Each of these financial covenants is calculated on a consolidated basis for the consecutive four fiscal quarter period then ended. As of June 28, 2019, the Company was in compliance with all covenants under the Facility Agreement.

[0001193125-19-225268:notes:294]
The Facility Agreement also contains customary events of default including, among other things, payment defaults, breaches of covenants or representations and warranties, cross-defaults with certain other indebtedness, bankruptcy and insolvency events and change in control of Fabrinet, subject to grace periods in certain instances. Upon an event of default, the lenders may terminate their commitments, declare all or a portion of the outstanding obligations payable by Fabrinet to be immediately due and payable and exercise other rights and remedies provided for under the Facility Agreement.

[0001193125-19-225268:notes:295]
Fabrinet intends to use the proceeds of the credit line to finance its future expansion in the United States and Thailand, and for general corporate purposes including mergers and acquisitions of complementary manufacturing businesses or technology, although Fabrinet has no current commitments with respect to any such acquisitions.

[0001193125-19-225268:notes:296]
On July 25, 2018, the Company entered into the Swap Agreement, which is used to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations by converting the floating interest rate of term loans under the Facility Agreement to a fixed interest rate of 2.86% per annum through maturity in June 2023. The Company has not designated the Swap Agreement as a hedging instrument. Swap transactions are due and settled monthly. During the year ended June 28, 2019, the Company included a net loss of $0.3 million from the Swap Agreement in interest expense in the consolidated statements of operations and comprehensive income.

[0001193125-19-225268:notes:297]
Short-term borrowings from bank

[0001193125-19-225268:notes:298]
In connection with the acquisition of Fabrinet UK in the first quarter of fiscal year 2017, the Company assumed a secured borrowing agreement. In the first quarter of fiscal year 2018, the Company fully repaid these short-term loans and sent a notification letter to the bank to terminate this secured borrowing agreement. As a result, the bank released secured trade accounts receivable and the way chattels mortgage over the plant and machine of Fabrinet UK.

[0001193125-19-225268:notes:299]
Undrawn available credit facilities classified by available period of future borrowing as of June 28, 2019 and June 29, 2018 were as follows:

[0001193125-19-225268:notes:300]
| (amount in thousands) |  | June 28,2019 |  |  | June 29,2018 |  |
| Expiring within one year |  | $ | — |  |  | $ | — |  |
| Expiring beyond one year |  | $ | 25,000 |  |  | $ | 25,000 |  |


## fn:AccruedSeveranceBenefitsDisclosureTextBlock

[0001193125-19-225268:notes:301]
| 16. | Severance liabilities |

[0001193125-19-225268:notes:302]
The following table provides information regarding severance liabilities:

[0001193125-19-225268:notes:303]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 28,2019 |  |  | June 29,2018 |  |
| Changes in severance liabilities |  |  |  |  |  |  |  |  |
| Balance, beginning of the fiscal year |  | $ | 10,390 |  |  | $ | 8,753 |  |
| Current service cost |  | $ | 2,345 |  |  | $ | 1,751 |  |
| Prior service cost |  |  | 2,537 |  |  |  | — |  |
| Interest cost |  |  | 352 |  |  |  | 301 |  |
| Benefit paid |  |  | (274 | ) |  |  | (3,260 | ) |
| Curtailment gain |  |  | — |  |  |  | 707 |  |
| Actuarial loss on obligation |  |  | 130 |  |  |  | 2,137 |  |
| Foreign currency translation |  |  | (7 | ) |  |  | 1 |  |
| Balance, end of the fiscal year |  | $ | 15,473 |  |  | $ | 10,390 |  |
| Changes in plan assets |  |  |  |  |  |  |  |  |
| Balance, beginning of the fiscal year |  | $ | 299 |  |  | $ | 302 |  |
| Actual return on plan assets |  | $ | (7) |  |  | $ | 4 |  |
| Employer contributions |  |  | 36 |  |  |  | 39 |  |
| Benefit paid |  |  | — |  |  |  | (48 | ) |
| Foreign currency translation |  |  | (11 | ) |  |  | 2 |  |
| Balance, end of the fiscal year |  | $ | 317 |  |  | $ | 299 |  |
| Underfunded status |  | $ | (15,156 | ) |  | $ | (10,091 | ) |

[0001193125-19-225268:notes:304]
|  | (1) | Prior service cost is the change in Projected Benefit Obligation resulting from changes to employee benefits from local law changes. |

[0001193125-19-225268:notes:305]
The amount recognized in the consolidated balance sheets under 
non-current
 liabilities and 
non-current
 assets were determined as follows:

[0001193125-19-225268:notes:306]
| (amount in thousands) |  | As ofJune 28,2019 |  |  | As ofJune 29,2018 |  |
| Non-current assets |  | $ | 53 |  |  | $ | 71 |  |
| Non-current liabilities |  | $ | 15,209 |  |  | $ | 10,162 |  |

[0001193125-19-225268:notes:307]
The following table provides information regarding accumulated benefit obligations:

[0001193125-19-225268:notes:308]
| (amount in thousands) |  | As ofJune 28,2019 |  |  | As ofJune 29,2018 |  |
| Accumulated benefit obligations |  | $ | 10,208 |  |  | $ | 6,943 |  |

[0001193125-19-225268:notes:309]
The following table sets forth the plan assets at fair value as of June 28, 2019.

[0001193125-19-225268:notes:310]
| (amount in thousands) |  |  |  |  | Fair value measurement as ofJune 28, 2019 |  |
|  |  | Total |  |  | SignificantObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Assets: |  |  |  |  |
| Other (1) |  | $ | 317 |  |  | $ | 183 |  |  | $ | 134 |  |
| Total Assets |  | $ | 317 |  |  | $ | 183 |  |  | $ | 134 |  |

[0001193125-19-225268:notes:311]
|  | (1) | The “Other” category represents the bid value of the trustees’ insurance policy held with Old Mutual Wealth and the value of assets held with Royal London. |

[0001193125-19-225268:notes:312]
The Trustees have chosen to invest in the following funds:

[0001193125-19-225268:notes:313]
| Fund |  | % ofTotal |  |
| Old Mutual Wealth Invesco Perpetual High Income |  |  | 43 | % |
| Old Mutual Wealth Creation Balanced Portfolio |  |  | 15 | % |
| Royal London Corporate Pension Services Limited |  |  | 42 | % |

[0001193125-19-225268:notes:314]
The Old Mutual Wealth assets are administered on unit-linked principles and allow access to a range of funds; these have been treated as Level 2 fair value measurement.

[0001193125-19-225268:notes:315]
The Royal London assets are administered on a deposit administration basis. This is similar to a with profits fund but with a lower exposure to the stock market. The policy is to majorly invest in UK Government bonds and Corporate bonds in which there is a constant rate of return reset annually. These assets are considered as unobservable inputs and have been treated as Level 3 fair value measurement.

[0001193125-19-225268:notes:316]
The principal actuarial assumptions used were as follows:

[0001193125-19-225268:notes:317]
Weighted average actuarial assumptions used to determine severance liabilities

[0001193125-19-225268:notes:318]
|  |  | Years Ended |  |
|  |  | June 28, 2019 |  | June 29, 2018 |  |  | June 30, 2017 |  |
| Discount rate |  | 2.3% - 3.2% |  |  | 2.5% - 3.7% |  |  |  | 1.9% - 3.6% |  |
| Future salary increases |  | 3.5% - 10.0% |  |  | 3.5% - 10.0% |  |  |  | 3.5% - 10.0% |  |

[0001193125-19-225268:notes:319]
Weighted average actuarial assumptions used to determine benefit costs

[0001193125-19-225268:notes:320]
|  |  | Years Ended |  |
|  |  | June 28, 2019 |  | June 29, 2018 |  |  | June 30, 2017 |  |
| Discount rate |  | 2.5% - 3.7% |  |  | 1.9% - 3.6% |  |  |  | 2.0% - 3.2% |  |
| Expected long-term rate of return on assets |  | 1.6% |  |  | 1.9% |  |  |  | 1.5% |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-19-225268:notes:321]
| 17. | Share-based compensation |

[0001193125-19-225268:notes:322]
In determining the grant date fair value of share option awards, the Company is required to make estimates of expected dividends to be issued, expected volatility of Fabrinet’s ordinary shares, expected forfeitures of the awards, risk free interest rates for the expected term of the awards and expected terms of the awards. Forfeitures are estimated at the time of grant and revised if necessary in subsequent periods if actual forfeitures differ from those estimates. The grant date fair value of restricted share units and performance share units is based on the market value of our ordinary shares on the date of grant.

[0001193125-19-225268:notes:323]
The effect of recording share-based compensation expense for the years ended June 28, 2019, June 29, 2018 and June 30, 2017 was as follows:

[0001193125-19-225268:notes:324]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 28,2019 |  |  | June 29,2018 |  |  | June 30,2017 |  |
| Share-based compensation expense by type of award: |  |  |  |  |
| Restricted share units |  | $ | 14,691 |  |  | $ | 17,143 |  |  | $ | 22,412 |  |
| Performance share units |  |  | 2,466 |  |  |  | 5,438 |  |  |  | 4,095 |  |
| Total share-based compensation expense |  |  | 17,157 |  |  |  | 22,581 |  |  |  | 26,507 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 17,157 |  |  | $ | 22,581 |  |  | $ | 26,507 |  |

[0001193125-19-225268:notes:325]
Share-based compensation expense was recorded in the consolidated statements of operations and comprehensive income as follows:

[0001193125-19-225268:notes:326]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 28,2019 |  |  | June 29,2018 |  |  | June 30,2017 |  |
| Cost of revenue |  | $ | 5,656 |  |  | $ | 6,784 |  |  | $ | 5,318 |  |
| Selling, general and administrative expense |  |  | 11,501 |  |  |  | 15,797 |  |  |  | 21,189 |  |
| Total share-based compensation expense |  | $ | 17,157 |  |  | $ | 22,581 |  |  | $ | 26,507 |  |

[0001193125-19-225268:notes:327]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the years ended June 28, 2019, June 29, 2018 and June 30, 2017.

[0001193125-19-225268:notes:328]
Share-based award activity

[0001193125-19-225268:notes:329]
Fabrinet maintains the following equity incentive plans: the Amended and Restated 2010 Performance Incentive Plan (the “2010 Plan”) and the 2017 Inducement Equity Incentive Plan (the “2017 Inducement Plan”). The 2010 Plan and 2017 Inducement Plan are collectively referred to as the “Equity Incentive Plans”.

[0001193125-19-225268:notes:330]
On December 14, 2017, Fabrinet’s shareholders adopted an amendment to the 2010 Plan to increase the number of ordinary shares authorized for issuance under the 2010 Plan by 2,100,000 shares. As of June 28, 2019, there were an aggregate of 764,261 restricted share units outstanding and 451,194 performance share units outstanding under the 2010 Plan. As of June 28, 2019, there were 1,832,949 ordinary shares available for future grant under the 2010 Plan.

[0001193125-19-225268:notes:331]
On November 2, 2017, Fabrinet adopted the 2017 Inducement Plan with a reserve of 160,000 ordinary shares authorized for future issuance solely for the granting of inducement share options and equity awards to new employees. The 2017 Inducement Plan was adopted without shareholder approval in reliance on the “employment inducement exemption” provided under the New York Stock Exchange Listed Company Manual. As of June 28, 2019, there were an aggregate of 36,490 restricted share units outstanding and 97,306 performance share units outstanding under the 2017 Inducement Plan. As of June 28, 2019, there were 14,041 ordinary shares available for future grant under the 2017 Inducement Plan.

[0001193125-19-225268:notes:332]
Share options

[0001193125-19-225268:notes:333]
Share options have been granted to directors and employees. Fabrinet’s board of directors has the authority to determine the type of option and the number of shares subject to an option. Options generally vest and become exercisable over four years and expire, if not exercised, within seven years of the grant date. In the case of a grantee’s first grant, 25 percent of the underlying shares vest 12 months after the vesting commencement date and 1/48 of the underlying shares vest monthly over each of the subsequent 36 months. In the case of any additional grants to a grantee, 1/48 of the underlying shares vest monthly over four years, commencing one month after the vesting commencement date.

[0001193125-19-225268:notes:334]
The following table summarizes share option activity under the 2010 Plan:

[0001193125-19-225268:notes:335]
|  |  | Number ofShares |  |  | Number ofExercisableOptions |  |  | Weighted-AverageExercise Price |  |  | Weighted-Average GrantDate Fair Value |  |
| Balance as of June 24, 2016 |  |  | 464,334 |  |  |  | 464,334 |  |  | $ | 15.95 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (367,641 | ) |  |  |  |  |  | $ | 16.02 |  |  |  |  |  |
| Forfeited |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Expired |  |  | (5 | ) |  |  |  |  |  | $ | 5.75 |  |  |  |  |  |
| Balance as of June 30, 2017 |  |  | 96,688 |  |  |  | 96,688 |  |  | $ | 15.70 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (92,288 | ) |  |  |  |  |  | $ | 16.02 |  |  |  |  |  |
| Forfeited |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Expired |  |  | (1,500 | ) |  |  |  |  |  | $ | 5.75 |  |  |  |  |  |
| Balance as of June 29, 2018 |  |  | 2,900 |  |  |  | 2,900 |  |  | $ | 15.16 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Forfeited |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Expired |  |  | (2,900 | ) |  |  |  |  |  | $ | 15.16 |  |  |  |  |  |
| Balance as of June 28, 2019 |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |

[0001193125-19-225268:notes:336]
The fair value of each share option grant was determined by the Company using the methods and assumptions discussed below. Each of these inputs is subjective and generally requires significant judgment and management estimate to determine.

[0001193125-19-225268:notes:337]
The total fair value of share options vested during the years ended June 28, 2019, June 29, 2018 and June 30, 2017 was nil. The total intrinsic value of options exercised during the years ended June 28, 2019, June 29, 2018 and June 30, 2017 was nil, $2.0 million and $8.9 million, respectively. In conjunction with these option exercises, there was no tax benefit realized by the Company due to the fact that it is exempted from income tax.

[0001193125-19-225268:notes:338]
Valuation Method
—The Company estimated the fair value of the Company’s ordinary shares to be used in the BSM by taking into consideration a number of assumptions, as discussed below.

[0001193125-19-225268:notes:339]
Expected Dividend
—The Company used zero as an annualized dividend yield since it did not anticipate paying any cash dividends in the near future.

[0001193125-19-225268:notes:340]
Expected Volatility
—The Company determined the expected volatility based on the Company’s historical volatility over the last four years.

[0001193125-19-225268:notes:341]
Risk-Free Interest Rate
—The Company based the risk-free interest rate on the implied yield currently available on U.S. Treasury 
zero-coupon
 issues with a remaining term equivalent to the expected term of the option.

[0001193125-19-225268:notes:342]
Expected Term
—Expected terms used in the BSM represent the periods that the company’s share options are expected to be outstanding and are determined based on the Company’s historical experience of similar awards, giving consideration to the contractual terms of the share options, vesting schedules and expectations of future employee behavior.

[0001193125-19-225268:notes:343]
Vesting Period
—Fabrinet’s share options generally vest and become exercisable over a four-year period, and expire seven years from the date of grant. For an initial grant, 25 percent of the underlying shares subject to an option vest 12 months after the vesting commencement date and 1/48 of the underlying shares vest monthly over each of the subsequent 36 months. In the case of any additional grants to an optionholder, 1/48 of the underlying shares subject to an option vest monthly over four years, commencing one month after the vesting commencement date.

[0001193125-19-225268:notes:344]
Fair Value
—The fair value of Fabrinet’s share options granted to employees was estimated using the weighted-average for each assumption of expected volatility, risk-free rate of return, and expected term.

[0001193125-19-225268:notes:345]
Restricted share units and performance share units

[0001193125-19-225268:notes:346]
Restricted share units and performance share units have been granted under the 2010 Plan and the 2017 Inducement Plan.

[0001193125-19-225268:notes:347]
Restricted share units granted to employees generally vest in equal installments over three or four years on each anniversary of the vesting commencement date. Restricted share units granted to 
non-employee
 directors generally cliff vest 100% on the first of January, approximately one year from the grant date, provided the director continues to serve through such date.

[0001193125-19-225268:notes:348]
Performance share units granted to executives will vest at the end of a 
two-year
 performance period based on the Company’s achievement of 
pre-defined
 performance criteria, which consist of revenue and gross margin targets. The actual number of performance share units that may vest at the end of the performance period ranges from 0% to 100% of the award grant.

[0001193125-19-225268:notes:349]
The Company has entered into an employment agreement, as amended on August 12, 2016, with one executive of the Company that provided for accelerated vesting of equity awards under certain circumstances. Pursuant to such agreement, because the executive’s employment with the Company continued through February 20, 2017, (1) all outstanding equity awards granted to the executive prior to August 2016 became 100% vested on February 20, 2017 and (2) certain restricted share units granted to the executive in August 2016 became 100% vested on February 20, 2017.

[0001193125-19-225268:notes:350]
The following table summarizes restricted share unit activity under the Equity Incentive Plans:

[0001193125-19-225268:notes:351]
|  |  | Number ofShares |  |  | Weighted-Average GrantDate Fair ValuePer Share |  |
| Balance as of June 24, 2016 |  |  | 1,181,402 |  |  | $ | 18.34 |  |
| Granted |  |  | 861,356 |  |  | $ | 38.95 |  |
| Issued |  |  | (853,535 | ) |  | $ | 21.16 |  |
| Forfeited |  |  | (130,618 | ) |  | $ | 29.31 |  |
| Balance as of June 30, 2017 |  |  | 1,058,605 |  |  | $ | 31.59 |  |
| Granted |  |  | 552,637 |  |  | $ | 35.95 |  |
| Issued |  |  | (436,867 | ) |  | $ | 27.81 |  |
| Forfeited |  |  | (100,795 | ) |  | $ | 33.62 |  |
| Balance as of June 29, 2018 |  |  | 1,073,580 |  |  | $ | 35.19 |  |
| Granted |  |  | 391,328 |  |  | $ | 50.02 |  |
| Issued |  |  | (515,482 | ) |  | $ | 34.18 |  |
| Forfeited |  |  | (148,675 | ) |  | $ | 38.42 |  |
| Balance as of June 28, 2019 |  |  | 800,751 |  |  | $ | 42.48 |  |
| Expected to vest as of June 28, 2019 |  |  | 718,687 |  |  | $ | 42.36 |  |

[0001193125-19-225268:notes:352]
The following table summarizes performance share unit activity under the Equity Incentive Plans:

[0001193125-19-225268:notes:353]
|  |  | Number ofShares |  |  | Weighted-Average GrantDate Fair ValuePer Share |  |
| Balance as of June 24, 2016 |  |  | — |  |  |  | — |  |
| Granted |  |  | 234,678 |  |  | $ | 40.48 |  |
| Issued |  |  | — |  |  |  | — |  |
| Forfeited |  |  | (7,410 | ) |  |  | — |  |
| Balance as of June 30, 2017 |  |  | 227,268 |  |  | $ | 40.48 |  |
| Granted |  |  | 378,624 |  |  | $ | 37.16 |  |
| Issued |  |  | — |  |  |  | — |  |
| Forfeited |  |  | — |  |  |  | — |  |
| Balance as of June 29, 2018 |  |  | 605,892 |  |  | $ | 38.41 |  |
| Granted |  |  | 201,994 |  |  | $ | 48.02 |  |
| Issued |  |  | (227,268 | ) |  | $ | 40.48 |  |
| Forfeited |  |  | (32,118 | ) |  | $ | 40.47 |  |
| Balance as of June 28, 2019 |  |  | 548,500 |  |  | $ | 40.97 |  |
| Expected to vest as of June 28, 2019 |  |  | 488,306 |  |  | $ | 40.93 |  |

[0001193125-19-225268:notes:354]
The fair value of restricted share units and performance share units is based on the market value of our ordinary shares on the date of grant.

[0001193125-19-225268:notes:355]
The total fair value of restricted share units and performance share units vested during the year ended June 28, 2019, June 29, 2018 and June 30, 2017 was $26.8 million, $12.2 million and $18.1 million, respectively. The aggregate intrinsic value of restricted share units and performance share units outstanding as of June 28, 2019 was $67.0 million.

[0001193125-19-225268:notes:356]
As of June 28, 2019, there was $12.7 million and $1.8 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.6 years and 1.2 years, respectively.

[0001193125-19-225268:notes:357]
For the years ended June 28, 2019 and June 29, 2018, the Company withheld an aggregate of 235,730 shares and 145,918 shares, respectively, upon the vesting of restricted share units, based upon the closing share price on the vesting date to settle the employees’ minimum statutory obligation for the applicable income and other employment taxes. For the years ended June 28, 2019 and June 29, 2018, the Company then remitted cash of $10.6 million and $5.5 million, respectively, to the appropriate taxing authorities, and presented it as a financing activity within the consolidated statements of cash flows. The payment had the effect on shares issued by the Company as it reduced the number of shares that would have been issued on the vesting date and was recorded as a reduction of additional 
paid-in
 capital.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-19-225268:notes:358]
| 18. | Employee benefit plans |

[0001193125-19-225268:notes:359]
The Company operates a defined contribution plan, known as a provident fund, in its subsidiaries in Thailand and the United Kingdom. The assets of these plans are in separate trustee-administered funds. The provident fund is funded by matching payments from employees and by the subsidiaries on a monthly basis. Current contributions to the provident fund are accrued and paid to the fund manager on a monthly basis. The Company’s contributions to the provident fund amounted to $4.8 million, $4.2 million and $3.6 million during the years ended June 28, 2019, June 29, 2018 and June 30, 2017, respectively.

[0001193125-19-225268:notes:360]
The Company sponsors the Fabrinet U.S. 401(k) Retirement Plan (“401(k) Plan”), a Defined Contribution Plan under ERISA, at its subsidiaries in the United States which provides retirement benefits for eligible employees through tax deferred salary deductions. The 401(k) Plan allows employees to contribute up to 80% of their annual compensation, subject to annual contributions limits established by the Internal Revenue Service. The Company provides for a 100% match of employees’ contributions to the 401(k) Plan up to the first 6% of annual compensation. All matching contributions are made in cash and vest immediately. The Company’s matching contributions to the 401(k) Plan were $0.8 million, $0.7 million and $0.6 million during the years ended June 28, 2019, June 29, 2018 and June 30, 2017, respectively.

[0001193125-19-225268:notes:361]
Executive incentive plan and employee performance bonuses

[0001193125-19-225268:notes:362]
For the years ended June 28, 2019 and June 29, 2018, the Company maintained an executive incentive plan with quantitative objectives, based on achieving certain revenue and 
non-GAAP
 gross margin targets. During the years ended June 28, 2019, June 29, 2018 and June 30, 2017, discretionary merit-based bonus awards were also available to Fabrinet’s 
non-executive
 employees.

[0001193125-19-225268:notes:363]
Bonus distributions to employees were $7.6 million, $4.0 million and $7.6 million for the years ended June 28, 2019, June 29, 2018 and June 30, 2017, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-19-225268:notes:364]
| 19. | Shareholders’ equity |

[0001193125-19-225268:notes:365]
Fabrinet’s authorized share capital is 500,000,000 ordinary shares, par value of $0.01 per ordinary share, and 5,000,000 preferred shares, par value of $0.01 per preferred share.

[0001193125-19-225268:notes:366]
For the year ended June 28, 2019, Fabrinet issued 507,020 ordinary shares upon the vesting of restricted share units and performance share units, net of shares withheld.

[0001193125-19-225268:notes:367]
For the year ended June 29, 2018, Fabrinet issued 92,288 ordinary shares upon the exercise of options, for cash consideration at a weighted average exercise price of $15.56 per share, and 290,949 ordinary shares upon the vesting of restricted share units, net of shares withheld.

[0001193125-19-225268:notes:368]
For the year ended June 30, 2017, Fabrinet issued 367,641 ordinary shares upon the exercise of options, for cash consideration at a weighted average exercise price of $16.02 per share, and 816,409 ordinary shares upon the vesting of restricted share units, net of shares withheld.

[0001193125-19-225268:notes:369]
All such issued shares are fully paid.

[0001193125-19-225268:notes:370]
In August 2017, the Company’s board of directors approved a share repurchase program to permit the Company to repurchase up to $30.0 million worth of its issued and outstanding ordinary shares in the open market in accordance with applicable rules and regulations. In February 2018 and May 2019, the Company’s board of directors approved the increase of $30.0 million and $50 million, respectively, to the original share repurchase authorization, bringing the aggregate authorization to $110.0 million.

[0001193125-19-225268:notes:371]
During the year ended June 28, 2019, 100,000 shares were repurchased under the program, at an average price per share of $53.78, totaling $5.4 million. As of June 28, 2019, the Company had a remaining authorization to purchase up to an additional $62.2 million worth of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-19-225268:notes:372]
| 20. | Accumulated other comprehensive income (loss) (“AOCI”) |

[0001193125-19-225268:notes:373]
The changes in AOCI by component for the years ended June 28, 2019 and June 29, 2018 were as follows:

[0001193125-19-225268:notes:374]
| (amount in thousands) |  | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  |  | Retirementbenefit plan -Prior servicecost |  |  | ForeignCurrencyTranslationAdjustment |  |  | Total |  |
| Balance as of June 30, 2017 |  | $ | (72 | ) |  | $ | 34 |  |  | $ | — |  |  | $ | (310 | ) |  | $ | (348 | ) |
| Other comprehensive income before reclassification |  |  | (655 | ) |  |  | — |  |  |  | — |  |  |  | 111 |  |  |  | (544 | ) |
| Amounts reclassified from AOCI |  |  | (364 | ) |  |  | (1 | ) |  |  | — |  |  |  | — |  |  |  | (365 | ) |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income |  |  | (1,019 | ) |  |  | (1 | ) |  |  | — |  |  |  | 111 |  |  |  | (909 | ) |
| Balance as of June 29, 2018 |  |  | (1,091 | ) |  |  | 33 |  |  |  | — |  |  |  | (199 | ) |  |  | (1,257 | ) |
| Other comprehensive income before reclassification |  |  | 1,845 |  |  |  | — |  |  |  | (2,537 | ) |  |  | (634 | ) |  |  | (1,326 | ) |
| Amounts reclassified from AOCI |  |  | 198 |  |  |  | (1 | ) |  |  | — |  |  |  | — |  |  |  | 197 |  |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income |  |  | 2,043 |  |  |  | (1 | ) |  |  | (2,537 | ) |  |  | (634 | ) |  |  | (1,129 | ) |
| Balance as of June 28, 2019 |  | $ | 952 |  |  | $ | 32 |  |  | $ | (2,537 | ) |  | $ | (833 | ) |  | $ | (2,386 | ) |

[0001193125-19-225268:notes:375]
The following table presents the 
pre-tax
 amounts reclassified from AOCI into the consolidated statements of operations and comprehensive income for the years ended June 28, 2019 and June 29, 2018, respectively.

[0001193125-19-225268:notes:376]
| (amount in thousands) |  |  |  | Years ended |  |
| AOCI components |  | Financial statementsline item |  | June 28,2019 |  |  | June 29,2018 |  |
| Unrealized gains (losses) on available-for-sale securities |  | Interest income |  | $ | 198 |  |  | $ | (364 | ) |
| Unrealized gains on derivative instruments |  | Selling, general and administrative expenses |  |  | (1 | ) |  |  | (1 | ) |
| Total amounts reclassified from AOCI |  |  |  | $ | 197 |  |  | $ | (365 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-19-225268:notes:377]
| 21. | Commitments and contingencies |

[0001193125-19-225268:notes:378]
Letter of credit and Bank guarantees

[0001193125-19-225268:notes:379]
As of June 28, 2019, the Company had an outstanding standby letter of credit of 6.0 million Euros related to the Company’s support of a customer with the transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. As of June 28, 2019, the standby letter of credit was backed by cash collateral of $7.4 million.

[0001193125-19-225268:notes:380]
As of June 28, 2019 and June 29, 2018, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business amounting to $1.6 million and $1.5 million, respectively.

[0001193125-19-225268:notes:381]
Operating lease commitments

[0001193125-19-225268:notes:382]
The Company leases a portion of its capital equipment, vehicle, and certain land and buildings for its facilities in Thailand, Cayman Islands, China, the United States and the United Kingdom under operating lease arrangements that expire in various years through 2023. Rental expense under these operating leases amounted to $1.9 million, $1.8 million and $1.7 million for the years ended June 28, 2019, June 29, 2018 and June 30, 2017, respectively.

[0001193125-19-225268:notes:383]
As of June 28, 2019, the future minimum lease payments due under 
non-cancelable
 operating leases during each fiscal year were as follows:

[0001193125-19-225268:notes:384]
| (amount in thousands) |  |  |  |
| 2020 |  | $ | 1,746 |  |
| 2021 |  |  | 1,342 |  |
| 2022 |  |  | 1,219 |  |
| 2023 |  |  | 1,172 |  |
| Thereafter |  |  | 230 |  |
| Total future minimum operating lease payments |  | $ | 5,709 |  |

[0001193125-19-225268:notes:385]
Capital lease commitments

[0001193125-19-225268:notes:386]
In connection with the acquisition of Fabrinet UK, the Company assumed the capital lease commitments of several machines and equipment, with various expiration dates until September 2020. The equipment can be purchased at the determined prices upon expiration of such contracts.

[0001193125-19-225268:notes:387]
As of June 28, 2019, the future minimum lease payments under 
non-cancelable
 capital leases during each fiscal year were as follows:

[0001193125-19-225268:notes:388]
| (amount in thousands) |  |  |  |
| 2020 |  | $ | 410 |  |
| 2021 |  |  | 103 |  |
| Total minimum capital lease payments |  |  | 513 |  |
| Less: Future finance charge on capital leases |  |  | (13 | ) |
| Present value of capital lease |  | $ | 500 |  |

[0001193125-19-225268:notes:389]
Representing capital lease liabilities

[0001193125-19-225268:notes:390]
| Current |  | $ | 398 |  |
| Non-current |  |  | 102 |  |
| Total capital lease liabilities |  | $ | 500 |  |

[0001193125-19-225268:notes:391]
As of June 28, 2019, the present value of capital lease during each fiscal year were as follows:

[0001193125-19-225268:notes:392]
| (amount in thousands) |  |  |  |
| 2020 |  | $ | 398 |  |
| 2021 |  |  | 102 |  |
| Total future minimum capital lease payments |  | $ | 500 |  |

[0001193125-19-225268:notes:393]
Purchase obligations

[0001193125-19-225268:notes:394]
Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001193125-19-225268:notes:395]
As of June 28, 2019, the Company had an outstanding commitment to third parties of $8.0 million.

[0001193125-19-225268:notes:396]
Indemnification of directors and officers

[0001193125-19-225268:notes:397]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001193125-19-225268:notes:398]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-19-225268:notes:399]
| 22. | Business segments and geographic information |

[0001193125-19-225268:notes:400]
Operating segments are defined as components of an enterprise for which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. The Company’s chief operating decision maker is Fabrinet’s chief executive officer. As of June 28, 2019, June 29, 2018 and June 30, 2017, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001193125-19-225268:notes:401]
Total revenues are attributed to a particular geographic area based on the

[0001193125-19-225268:notes:402]
bill-to-location

[0001193125-19-225268:notes:403]
of the customer. The Company operates primarily in three geographic regions: North America, Asia-Pacific and Europe. The following table presents total revenues by geographic regions:

[0001193125-19-225268:notes:404]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 28,2019 |  |  | June 29,2018 |  |  | June 30,2017 |  |
| North America |  | $ | 756,278 |  |  | $ | 643,236 |  |  | $ | 661,267 |  |
| Asia-Pacific |  |  | 608,386 |  |  |  | 519,203 |  |  |  | 539,317 |  |
| Europe |  |  | 219,671 |  |  |  | 209,486 |  |  |  | 219,906 |  |
| Total |  | $ | 1,584,335 |  |  | $ | 1,371,925 |  |  | $ | 1,420,490 |  |

[0001193125-19-225268:notes:405]
As of June 28, 2019 and June 29, 2018, the Company had approximately $31.4 million and $33.2 million, respectively, of long-lived assets based in North America, with the substantial remainder of assets based in Asia-Pacific.

[0001193125-19-225268:notes:406]
The following table presents revenues by end market:

[0001193125-19-225268:notes:407]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 28,2019 |  |  | June 29,2018 |  |  | June 30,2017 |  |
| Optical communications |  | $ | 1,184,936 |  |  | $ | 1,000,256 |  |  | $ | 1,108,637 |  |
| Lasers, sensors, and other |  |  | 399,399 |  |  |  | 371,669 |  |  |  | 311,853 |  |
| Total |  | $ | 1,584,335 |  |  | $ | 1,371,925 |  |  | $ | 1,420,490 |  |

[0001193125-19-225268:notes:408]
Significant customers

[0001193125-19-225268:notes:409]
Total revenues, by percentage, from individual customers representing 10% or more of total revenues in the respective periods were as follows:

[0001193125-19-225268:notes:410]
|  |  | Years Ended |  |
|  |  | June 28,2019 |  |  | June 29,2018 |  |  | June 30,2017 |  |
| Lumentum Operations LLC |  |  | 20 | % |  |  | 16 | % |  |  | 17 | % |

[0001193125-19-225268:notes:411]
Accounts receivable from individual customers representing 10% or more of accounts receivable as of June 28, 2019 and June 29, 2018, respectively, were as follows:

[0001193125-19-225268:notes:412]
|  |  | As ofJune 28,2019 |  |  | As ofJune 29,2018 |  |
| Lumentum Operations LLC |  |  | 23 | % |  |  | 18 | % |
| NeoPhotonics Corporation |  |  | * |  |  |  | 11 | % |
| Acacia Communications Inc. |  |  | 12 | % |  |  | * |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-19-225268:notes:413]
| 23. | Financial instruments |

[0001193125-19-225268:notes:414]
Objectives and significant terms and conditions

[0001193125-19-225268:notes:415]
The principal financial risks faced by the Company are foreign currency risk and interest rate risk. The Company borrows at floating rates of interest to finance its operations. A minority of sales and purchases and a majority of labor and overhead costs are entered into in foreign currencies. In order to manage the risks arising from fluctuations in currency exchange rates, the Company uses derivative instruments. Trading for speculative purposes is prohibited under Company policies.

[0001193125-19-225268:notes:416]
The Company enters into short-term foreign currency forward and option contracts to manage foreign currency exposures associated with certain assets, liabilities and other forecasted foreign currency transactions and may designate these instruments as hedging instruments. The foreign currency forward and option contracts generally have maturity of up to six months. All foreign currency exchange contracts are recognized on the consolidated balance sheets at fair value. Gain or loss on the Company’s derivative instruments generally offset the assets, liabilities and transactions economically hedged.

[0001193125-19-225268:notes:417]
Foreign currency risk

[0001193125-19-225268:notes:418]
The Company operates internationally and is exposed to foreign exchange risk arising from various currency exposures primarily with respect to the Thai baht, Chinese Renminbi (“RMB”) and GBP.

[0001193125-19-225268:notes:419]
As of June 28, 2019 and June 29, 2018, the Company had outstanding foreign currency assets and liabilities as follows:

[0001193125-19-225268:notes:420]
|  |  | As of June 28, 2019 |  |  | As of June 29, 2018 |  |
| (amount in thousands) |  | Currency |  |  | $ |  |  | Currency |  |  | $ |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 664,860 |  |  | $ | 21,628 |  |  |  | 980,778 |  |  | $ | 29,568 |  |
| RMB |  |  | 53,393 |  |  |  | 7,767 |  |  |  | 18,455 |  |  |  | 2,789 |  |
| GBP |  |  | 5,270 |  |  |  | 6,682 |  |  |  | 12,514 |  |  |  | 16,392 |  |
| Total |  |  |  |  |  | $ | 36,077 |  |  |  |  |  |  | $ | 48,749 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,961,972 |  |  | $ | 63,825 |  |  |  | 1,401,473 |  |  | $ | 42,251 |  |
| RMB |  |  | 26,373 |  |  |  | 3,836 |  |  |  | 19,893 |  |  |  | 3,007 |  |
| GBP |  |  | 2,598 |  |  |  | 3,294 |  |  |  | 3,615 |  |  |  | 4,735 |  |
| Total |  |  |  |  |  | $ | 70,955 |  |  |  |  |  |  | $ | 49,993 |  |

[0001193125-19-225268:notes:421]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. The Company manages its exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of June 28, 2019 there were $72.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 29, 2018, there were $7.0 million of foreign currency forward contracts and $30.0 million of foreign currency option contracts outstanding on the Thai baht payables.

[0001193125-19-225268:notes:422]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses and other payables. As of June 28, 2019 and June 29, 2018, there were no derivative contracts denominated in RMB.

[0001193125-19-225268:notes:423]
The GBP assets primarily represent cash, trade accounts receivable, inventory and property, plant and equipment. The GBP liabilities primarily represent trade accounts payable. As of June 28, 2019, there were no derivative contracts denominated in GBP.

[0001193125-19-225268:notes:424]
For fiscal year 2019, fiscal year 2018, and fiscal year 2017, the Company recorded unrealized gain of $4.8 million, unrealized loss of $1.7 million, and unrealized gain of $0.02 million, respectively, related to derivatives that are not designated as hedging instruments in its consolidated statements of operations and comprehensive income.

[0001193125-19-225268:notes:425]
Interest Rate Risk

[0001193125-19-225268:notes:426]
The Company’s principal interest bearing assets are time deposits and short-term investments with maturities of three years or less held with high quality financial institutions. The Company’s principal interest bearing liabilities are bank loans which bear interest at floating rates.

[0001193125-19-225268:notes:427]
On July 25, 2018, the Company entered into the Swap Agreement, which the Company did not designate as a hedging instrument. The Swap Agreement was used to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations by converting the floating interest rate of the term loans under the Facility Agreement to the fixed interest rate of 2.86% per annum through maturity of the term loan in June 2023. The swap transactions are due and settled monthly.


## us-gaap:SubsequentEventsTextBlock

[0001193125-19-225268:notes:428]
| 24. | Subsequent event |

[0001193125-19-225268:notes:429]
On July 8, 2019, the Company entered into a 16.2 million Euros standby letter of credit related to the Company’s support of a customer with the transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. The standby letter of credit was backed by cash collateral of $22.1 million.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001193125-19-225268:notes:430]
UNAUDITED QUARTERLY FINANCIAL INFORMATION

[0001193125-19-225268:notes:431]
The following table sets forth a summary of the Company’s quarterly financial information for each of the four quarters in the fiscal years ended June 28, 2019 and June 29, 2018:

[0001193125-19-225268:notes:432]
|  |  | Three Months Ended |  |
| (in thousands, except per share data) |  | Jun 28,2019 |  |  | Mar 29,2019 |  |  | Dec 28,2018 |  |  | Sep 28,2018 |  |  | Jun 29,2018 |  |  | Mar 30,2018 |  |  | Dec 29,2017 |  |  | Sep 29,2017 |  |
| Total revenues |  | $ | 405,127 |  |  | $ | 398,951 |  |  | $ | 403,080 |  |  | $ | 377,177 |  |  | $ | 345,327 |  |  | $ | 332,213 |  |  | $ | 337,072 |  |  | $ | 357,313 |  |
| Gross profit |  | $ | 46,626 |  |  | $ | 46,758 |  |  | $ | 45,564 |  |  | $ | 40,276 |  |  | $ | 38,981 |  |  | $ | 36,933 |  |  | $ | 37,166 |  |  | $ | 40,332 |  |
| Net income |  | $ | 32,957 |  |  | $ | 28,635 |  |  | $ | 31,513 |  |  | $ | 27,850 |  |  | $ | 22,768 |  |  | $ | 21,053 |  |  | $ | 19,313 |  |  | $ | 21,033 |  |
| Basic net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 0.89 |  |  | $ | 0.78 |  |  | $ | 0.86 |  |  | $ | 0.76 |  |  | $ | 0.62 |  |  | $ | 0.56 |  |  | $ | 0.52 |  |  | $ | 0.56 |  |
| Weighted-average shares used in basic net income per share calculations |  |  | 36,836 |  |  |  | 36,891 |  |  |  | 36,841 |  |  |  | 36,625 |  |  |  | 36,828 |  |  |  | 37,275 |  |  |  | 37,477 |  |  |  | 37,447 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 0.88 |  |  | $ | 0.76 |  |  | $ | 0.84 |  |  | $ | 0.75 |  |  | $ | 0.60 |  |  | $ | 0.55 |  |  | $ | 0.51 |  |  | $ | 0.55 |  |
| Weighted-average shares used in diluted net income per share calculations |  |  | 37,511 |  |  |  | 37,539 |  |  |  | 37,471 |  |  |  | 37,140 |  |  |  | 37,766 |  |  |  | 38,055 |  |  |  | 38,156 |  |  |  | 38,163 |  |


## fn:ScheduleOfAccountsReceivableByMajorCustomersByReportingSegmentsTableTextBlock

[0001193125-19-225268:notes:433]
|  | * | Represents less than 10% of total accounts receivable. |
