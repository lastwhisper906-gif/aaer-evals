# FN MD&A — 0001193125-19-225268


## mdna

[0001193125-19-225268:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS. |

[0001193125-19-225268:mdna:2]
|  | • |  | our goals and strategies; |

[0001193125-19-225268:mdna:3]
|  | • |  | our and our customers’ estimates regarding future revenues, operating results, expenses, capital requirements and liquidity; |

[0001193125-19-225268:mdna:4]
|  | • |  | our expectation that the portion of our future revenues attributable to customers in regions outside of North America will increase compared with the portion of those revenues for fiscal year 2019; |

[0001193125-19-225268:mdna:5]
|  | • |  | our expectation that we will incur incremental costs of revenue as a result of our planned expansion of our business into new geographic markets; |

[0001193125-19-225268:mdna:6]
|  | • |  | our expectation that our fiscal year 2020 selling, general and administrative (“SG&A”) expenses will increase compared to our fiscal year 2019 SG&A expenses; |

[0001193125-19-225268:mdna:7]
|  | • |  | our expectation that our employee costs will increase in Thailand and the People’s Republic of China (“PRC”), including as a result of a recent change in labor protection law in Thailand that increases the required severance payment compensation for employees with 20 or more years of service; |

[0001193125-19-225268:mdna:8]
|  | • |  | our future capital expenditures and our needs for additional financing; |

[0001193125-19-225268:mdna:9]
|  | • |  | the expansion of our manufacturing capacity, including into new geographies; |

[0001193125-19-225268:mdna:10]
|  | • |  | the growth rates of our existing markets and potential new markets; |

[0001193125-19-225268:mdna:11]
|  | • |  | our ability, and the ability of our customers and suppliers, to respond successfully to technological or industry developments; |

[0001193125-19-225268:mdna:12]
|  | • |  | our suppliers’ estimates regarding future costs; |

[0001193125-19-225268:mdna:13]
|  | • |  | our ability to increase our penetration of existing markets and to penetrate new markets; |

[0001193125-19-225268:mdna:14]
|  | • |  | our plans to diversify our sources of revenues; |

[0001193125-19-225268:mdna:15]
|  | • |  | our plans to execute acquisitions; |

[0001193125-19-225268:mdna:16]
|  | • |  | trends in the optical communications, industrial lasers, and sensors markets, including trends to outsource the production of components used in those markets; |

[0001193125-19-225268:mdna:17]
|  | • |  | our ability to attract and retain a qualified management team and other qualified personnel and advisors; and |

[0001193125-19-225268:mdna:18]
|  | • |  | competition in our existing and new markets. |

[0001193125-19-225268:mdna:19]
uncertainties, readers are cautioned not to place undue reliance on such forward-looking statements. “We,” “us” and “our” refer to Fabrinet and its subsidiaries.

[0001193125-19-225268:mdna:20]
Overview

[0001193125-19-225268:mdna:21]
We provide advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original
equipment manufacturers (“OEMs”) of complex products such as optical communication components, modules and sub-systems, industrial lasers, automotive components, medical devices and sensors. We offer
a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, complex printed circuit board assembly, advanced
packaging, integration, final assembly and testing. Although we focus primarily on low-volume production of a wide variety of high complexity products, which we refer to as
“low-volume, high-mix,” we also have the capability to accommodate high-volume production. Based on our experience with and positive feedback from our
customers, we believe we are a global leader in providing these services to the optical communications, industrial lasers and automotive markets.

[0001193125-19-225268:mdna:22]
Our customer base includes companies in complex industries that require advanced precision manufacturing capabilities such as optical communications, industrial lasers, automotive and sensors. The
products that we manufacture for our OEM customers include selective switching products; tunable transponders and transceivers; active optical cables; solid state, diode-pumped, gas and fiber lasers; and sensors. In many cases, we are the sole
outsourced manufacturing partner used by our customers for the products that we produce for them.

[0001193125-19-225268:mdna:23]
We also design and
fabricate application-specific crystals, lenses, prisms, mirrors, laser components, and substrates (collectively referred to as “customized optics”) and other custom and standard borosilicate, clear fused quartz, and synthetic fused silica
glass products (collectively referred to as “customized glass”). We incorporate our customized optics and glass into many of the products we manufacture for our OEM customers, and we also sell customized optics and glass in the merchant
market.

[0001193125-19-225268:mdna:24]
Fiscal years

[0001193125-19-225268:mdna:25]
We utilize a 52-53 week fiscal year ending on the Friday in June closest to June 30. Fiscal year 2019 ended on June 28, 2019 and consisted of 52 weeks.
Fiscal year 2018 ended on June 29, 2018 and consisted of 52 weeks. Fiscal year 2017 ended on June 30, 2017 and consisted of 53 weeks.

[0001193125-19-225268:mdna:26]
Revenues

[0001193125-19-225268:mdna:27]
We believe our
ability to expand our relationships with existing customers and attract new customers is due to a number of factors, including our broad range of complex engineering and manufacturing service offerings, flexible
low-cost manufacturing platform, process optimization capabilities, advanced supply chain management, excellent customer service and experienced management team. Although we expect the prices we charge for our
manufactured products to decrease over time (partly as a result of competitive market forces), we still believe we will be able to maintain favorable pricing for our services because of our ability to reduce cycle time, adjust our product mix by
focusing on more complicated products, improve product quality and yields, and reduce material costs for the products we manufacture. We believe these capabilities will enable us to help our OEM customers reduce their manufacturing costs while
maintaining or improving the design, quality, reliability and delivery times of their products.

[0001193125-19-225268:mdna:28]
Revenues, by percentage, from individual customers representing 10% or more of our
total revenues in the respective periods were as follows:

[0001193125-19-225268:mdna:29]
|  |  | Years Ended |  |
|  |  | June 28, 2019 |  |  | June 29, 2018 |  |  | June 30, 2017 |  |
| Lumentum Operations LLC |  |  | 20 | % |  |  | 16 | % |  |  | 17 | % |

[0001193125-19-225268:mdna:30]
Because we depend upon a small number of customers for a significant percentage of our total revenues, a
reduction in orders from, a loss of, or any other adverse actions by, any one of these customers would reduce our revenues and could have a material adverse effect on our business, operating results and share price. Moreover, our customer
concentration increases the concentration of our accounts receivable and payment default by any of our key customers will negatively impact our exposure. Many of our existing and potential customers have substantial debt burdens, have experienced
financial distress or have static or declining revenues, all of which may be exacerbated by the continued uncertainty in the global economies. Certain customers have gone out of business or have been acquired or announced their withdrawal from
segments of the optics market. We generate significant accounts payable and inventory for the services that we provide to our customers, which could expose us to substantial and potentially unrecoverable costs if we do not receive payment from our
customers. Therefore, any financial difficulties that our key customers experience could materially and adversely affect our operating results and financial condition by generating charges for inventory write-offs, provisions for doubtful accounts,
and increases in working capital requirements due to increased days inventory and in accounts receivable.

[0001193125-19-225268:mdna:31]
Furthermore,
reliance on a small number of customers gives those customers substantial purchasing power and leverage in negotiating contracts with us. In addition, although we enter into master supply agreements with our customers, the level of business to be
transacted under those agreements is not guaranteed. Instead, we are awarded business under those agreements on a project-by-project basis. Some of our customers have at
times significantly reduced or delayed the volume of manufacturing services that they order from us. If we are unable to maintain our relationships with our existing significant customers, our business, financial condition and operating results
could be harmed.

[0001193125-19-225268:mdna:32]
On June 30, 2018, we adopted Revenue from Contracts with Customers (Topic 606), which created
Accounting Standards Codification Topic 606 (“ASC 606”), using the modified retrospective method applied to those contracts which were not completed as of June 29, 2018. The modified retrospective method requires us to recognize the
cumulative effect of the adoption of ASC 606, for all contracts with customers, to the opening balance of equity at June 30, 2018. Accordingly, our comparative financial information as of June 29, 2018 has not been adjusted and continues
to be reported under ASC 605, Revenue Recognition (“ASC 605”).

[0001193125-19-225268:mdna:33]
In accordance with the new revenue standard
requirements, the impact of adoption of ASC 606 on our consolidated statements of operations and comprehensive income for the year ended June 28, 2019 was as follows:

[0001193125-19-225268:mdna:34]
| Consolidated Statement of Operations and Comprehensive Income |  |
| For the Year Ended June 28, 2019 |  |
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | As Reported |  |  | Adjustment |  |  | Balance withoutASC 606 Adoption |  |
| Revenues |  | $ | 1,584,335 |  |  | $ | (2,560 | ) (1) |  | $ | 1,581,775 |  |
| Cost of revenues |  | $ | (1,405,111 | ) |  | $ | 1,745 | (2) |  | $ | (1,403,366 | ) |
| Gross profit |  | $ | 179,224 |  |  | $ | (815 | ) (3) |  | $ | 178,409 |  |
| Net income |  | $ | 120,955 |  |  | $ | (825 | ) (3) |  | $ | 120,130 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.29 |  |  | $ | (0.02 | ) |  | $ | 3.27 |  |
| Diluted |  | $ | 3.23 |  |  | $ | (0.02 | ) |  | $ | 3.21 |  |

[0001193125-19-225268:mdna:35]
40

[0001193125-19-225268:mdna:36]
| (1) | Adjustment relates to certain manufacturing contracts with vendor-managed inventory arrangements for which revenue was recognized at shipping. |

[0001193125-19-225268:mdna:37]
| (2) | Adjustment relates to costs associated with revenue recognized. |

[0001193125-19-225268:mdna:38]
| (3) | Adjustment relates to net impact on net income upon adoption of ASC 606. |

[0001193125-19-225268:mdna:39]
Revenues by Geography

[0001193125-19-225268:mdna:40]
We generate revenues from three geographic regions: North America, Asia-Pacific, and Europe. Revenues are attributed to a particular geographic area based on the bill-to-location of our customers, notwithstanding that our customers may ultimately ship their products to end customers in a different geographic region. The substantial majority of our revenues are derived
from our manufacturing facilities in Asia-Pacific.

[0001193125-19-225268:mdna:41]
The percentage of our revenues generated from a bill-to-location outside of North America decreased from 53.1% in fiscal year 2018 to 52.3% in fiscal year 2019, which was partially due to a decrease in sales to our
customers in Europe by 1.4%. Based on the short and medium term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside of North America will increase as compared
with the portion of revenues attributable to such customers during fiscal year 2019.

[0001193125-19-225268:mdna:42]
The following table presents percentages
of total revenues by geographic regions:

[0001193125-19-225268:mdna:43]
|  |  | Years Ended |  |
|  |  | June 28, 2019 |  |  | June 29, 2018 |  |  | June 30, 2017 |  |
| North America |  |  | 47.7 | % |  |  | 46.9 | % |  |  | 46.6 | % |
| Asia-Pacific |  |  | 38.4 |  |  |  | 37.8 |  |  |  | 38.0 |  |
| Europe |  |  | 13.9 |  |  |  | 15.3 |  |  |  | 15.4 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-19-225268:mdna:44]
Our Contracts

[0001193125-19-225268:mdna:45]
We enter into supply agreements with our customers which generally have an initial term of up to three years, subject to automatic renewals for subsequent one-year
terms unless expressly terminated. Although there are no minimum purchase requirements in our supply agreements, our customers provide us with rolling forecasts of their demand requirements. Our supply agreements generally include provisions for
pricing and periodic review of pricing, consignment of our customer’s unique production equipment to us, and the sharing of benefits from cost-savings derived from our efforts. We are generally required to purchase materials, which may include
long lead-time materials and materials that are subject to minimum order quantities and/or non-cancelable or non-returnable terms, to meet the stated demands of our
customers. After procuring materials, we manufacture products for our customers based on purchase orders that contain terms regarding product quantities, delivery locations and delivery dates. Our customers generally are obligated to purchase
finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by our customers within a specified period of time, or are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under our contracts. Once materials are designated as either excess or obsolete inventory, our customers
are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

[0001193125-19-225268:mdna:46]
Cost of Revenues

[0001193125-19-225268:mdna:47]
The
key components of our cost of revenues are material costs, employee costs, and infrastructure-related costs. Material costs generally represent the majority of our cost of revenues. Several of the materials we require to manufacture products for our
customers are customized for their products and often sourced from a single

[0001193125-19-225268:mdna:48]
supplier or in some cases, our own subsidiaries. Shortages from sole-source suppliers due to yield loss, quality concerns and capacity constraints, among other factors, may increase our expenses
and negatively impact our gross profit margin or total revenues in a given quarter. Material costs include scrap material. Historically, scrap rate diminishes during a product’s life cycle due to process, fixturing and test improvement and
optimization.

[0001193125-19-225268:mdna:49]
A second significant element of our cost of revenues is employee costs, including indirect employee costs
related to design, configuration and optimization of manufacturing processes for our customers, quality testing, materials testing and other engineering services; and direct costs related to our manufacturing employees. Direct employee costs include
employee salaries, insurance and benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a
lesser extent, costs to recruit, train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand, the PRC and the United Kingdom, the fluctuation of the Thai baht, Chinese Renminbi (“RMB”) and
Pound Sterling (“GBP”) against our functional currency, the U.S. dollar, and our ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may
impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention and asset utilization.

[0001193125-19-225268:mdna:50]
Our infrastructure costs are comprised of depreciation, utilities, facilities management and overhead costs. Most of our facility leases
are long-term agreements. Our depreciation costs include buildings and fixed assets, primarily at our Pinehurst and Chonburi campuses in Thailand, and capital equipment located at each of our manufacturing locations.

[0001193125-19-225268:mdna:51]
During fiscal years 2019, 2018 and 2017, discretionary merit-based bonus awards were made to our
non-executive employees. Charges included in cost of revenues for bonus awards to non-executive employees were $3.9 million, $3.5 million and $3.2 million
for fiscal years 2019, 2018 and 2017, respectively.

[0001193125-19-225268:mdna:52]
Share-based compensation expense included in cost of revenues was
$5.7 million, $6.8 million and $5.3 million for fiscal years 2019, 2018 and 2017, respectively.

[0001193125-19-225268:mdna:53]
We expect to
incur incremental costs of revenue as a result of our planned expansion into new geographic markets, though we are not able to determine the amount of these incremental expenses.

[0001193125-19-225268:mdna:54]
Selling, General and Administrative Expenses

[0001193125-19-225268:mdna:55]
Our SG&A expenses
primarily consist of corporate employee costs for sales and marketing, general and administrative and other support personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal
and other professional fees, share-based compensation expense and other general expenses not related to cost of revenues. In fiscal year 2020, we expect our SG&A expenses will increase compared with our fiscal year 2019 SG&A expenses.

[0001193125-19-225268:mdna:56]
The compensation committee of our board of directors approved a fiscal year 2019 executive incentive plan with quantitative
objectives based solely on achieving certain revenue targets and non-U.S. GAAP gross margin targets for fiscal year 2019. Bonuses under the fiscal year 2019 executive incentive plan are payable after the end
of fiscal year 2019. In fiscal year 2018, the compensation committee approved a fiscal year 2018 executive incentive plan with quantitative objectives that were based solely on achieving certain revenue targets and
non-U.S. GAAP gross margin targets for fiscal year 2018. Because we did not achieve the targets under our fiscal year 2018 executive incentive plan, no bonuses were paid under such plan. Discretionary
merit-based bonus awards are also available to our non-executive employees and payable on a quarterly basis.

[0001193125-19-225268:mdna:57]
Charges included in SG&A expenses for bonus distributions to non-executive and executive employees were $3.7 million, $0.5 million and
$4.4 million for fiscal years 2019, 2018 and 2017, respectively.

[0001193125-19-225268:mdna:58]
Share-based compensation expense included in SG&A expenses was $11.5 million,
$15.8 million and $21.2 million for fiscal years 2019, 2018 and 2017, respectively.

[0001193125-19-225268:mdna:59]
Additional Financial Disclosures

[0001193125-19-225268:mdna:60]
Foreign Exchange

[0001193125-19-225268:mdna:61]
As a result of our international operations, we are exposed to foreign exchange risk arising from various currency exposures primarily with respect to the Thai baht. Although a majority of our total
revenues is denominated in U.S. dollars, a substantial portion of our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rate between the Thai baht and the U.S. dollar has fluctuated substantially in
recent years and may continue to fluctuate substantially in the future. We report our financial results in U.S. dollars and our results of operations have been and could in the future be negatively impacted if the Thai baht appreciates against the
U.S. dollar. Smaller portions of our expenses are incurred in a variety of other currencies, including RMB, GBP, Canadian dollars, Euros, and Japanese yen, the appreciation of which may also negatively impact our financial results.

[0001193125-19-225268:mdna:62]
In order to manage the risks arising from fluctuations in foreign currency exchange rates, we use derivative instruments. We may enter
into foreign currency exchange forward or option contracts to manage foreign currency exposures associated with certain assets and liabilities and other forecasted foreign currency transactions and may designate these instruments as hedging
instruments. The forward and option contracts generally have maturities of up to 12 months. All foreign currency exchange contracts are recognized in the consolidated balance sheets at fair value. Gain or loss on our forward and option contracts
generally offset the assets, liabilities, and transactions economically hedged.

[0001193125-19-225268:mdna:63]
We had foreign currency denominated assets
and liabilities in Thai baht, RMB and GBP as follows:

[0001193125-19-225268:mdna:64]
|  |  | As of June 28, 2019 |  |  | As of June 29, 2018 |  |
| (amount in thousands, except percentages) |  | ForeignCurrency |  |  | $ |  |  | % |  |  | ForeignCurrency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 664,860 |  |  | $ | 21,628 |  |  |  | 60.0 |  |  |  | 980,778 |  |  | $ | 29,568 |  |  |  | 60.7 |  |
| RMB |  |  | 53,393 |  |  |  | 7,767 |  |  |  | 21.5 |  |  |  | 18,455 |  |  |  | 2,789 |  |  |  | 5.7 |  |
| GBP |  |  | 5,270 |  |  |  | 6,682 |  |  |  | 18.5 |  |  |  | 12,514 |  |  |  | 16,392 |  |  |  | 33.6 |  |
| Total |  |  |  |  |  | $ | 36,077 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 48,749 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,961,972 |  |  | $ | 63,825 |  |  |  | 90.0 |  |  |  | 1,401,473 |  |  | $ | 42,251 |  |  |  | 84.5 |  |
| RMB |  |  | 26,373 |  |  |  | 3,836 |  |  |  | 5.4 |  |  |  | 19,893 |  |  |  | 3,007 |  |  |  | 6.0 |  |
| GBP |  |  | 2,598 |  |  |  | 3,294 |  |  |  | 4.6 |  |  |  | 3,615 |  |  |  | 4,735 |  |  |  | 9.5 |  |
| Total |  |  |  |  |  | $ | 70,955 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 49,993 |  |  |  | 100.0 |  |

[0001193125-19-225268:mdna:65]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other
current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and
offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of June 28, 2019 there were $72.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of
June 29, 2018 there were $7.0 million of foreign currency forward contracts and $30.0 million of foreign currency option contracts outstanding on the Thai baht payables.

[0001193125-19-225268:mdna:66]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities represent
trade accounts payable, accrued expenses, income tax payable and other payables. As of June 28, 2019 and June 29, 2018, we did not have any derivative contracts denominated in RMB.

[0001193125-19-225268:mdna:67]
The GBP assets represent cash, trade accounts receivable and other current assets. The
GBP liabilities represent trade accounts payable and other payables. As of June 28, 2019 and June 29, 2018, we did not have any derivative contracts denominated in GBP.

[0001193125-19-225268:mdna:68]
For fiscal years 2019 and 2018, we recorded an unrealized gain of $4.8 million and an unrealized loss of $1.7 million,
respectively, related to derivatives that are not designated as hedging instruments in the consolidated statements of operations and comprehensive income.

[0001193125-19-225268:mdna:69]
Currency Regulation and Dividend Distribution

[0001193125-19-225268:mdna:70]
Foreign exchange
regulation in the PRC is primarily governed by the following rules:

[0001193125-19-225268:mdna:71]
|  | • |  | Foreign Currency Administration Rules, as amended on August 5, 2008, or the Exchange Rules; |

[0001193125-19-225268:mdna:72]
|  | • |  | Administration Rules of the Settlement, Sale and Payment of Foreign Exchange (1996), or the Administration Rules; and |

[0001193125-19-225268:mdna:73]
|  | • |  | Notice on Perfecting Practices Concerning Foreign Exchange Settlement Regarding the Capital Contribution by Foreign-invested Enterprises, as promulgated by the State Administration of Foreign Exchange (“SAFE”), on August 29, 2008, or Circular 142. |

[0001193125-19-225268:mdna:74]
Under the Exchange Rules, RMB is freely convertible into foreign currencies for current account items, including the distribution of dividends, interest payments, trade and service-related foreign
exchange transactions. However, conversion of RMB for capital account items, such as direct investments, loans, security investments and repatriation of investments, is still subject to the approval of SAFE.

[0001193125-19-225268:mdna:75]
Under the Administration Rules, foreign-invested enterprises may only buy, sell, or remit foreign currencies at banks authorized to
conduct foreign exchange business after providing valid commercial documents and relevant supporting documents and, in the case of capital account item transactions, obtaining approval from SAFE. Capital investments by foreign-invested enterprises
outside of the PRC are also subject to limitations, which include approvals by the Ministry of Commerce, SAFE and the State Development and Reform Commission.

[0001193125-19-225268:mdna:76]
Circular 142 regulates the conversion by a foreign-invested company of foreign currency into RMB by restricting how the converted RMB may be used. Circular 142 requires that the registered capital of a
foreign-invested enterprise settled in RMB converted from foreign currencies may only be used for purposes within the business scope approved by the applicable governmental authority and may not be used for equity investments within the PRC. In
addition, SAFE strengthened its oversight of the flow and use of the registered capital of foreign-invested enterprises settled in RMB converted from foreign currencies. The use of such RMB capital may not be changed without SAFE’s approval and
may not be used to repay RMB loans if the proceeds of such loans have not been used.

[0001193125-19-225268:mdna:77]
On January 5, 2007, SAFE
promulgated the Detailed Rules for Implementing the Measures for the Administration on Individual Foreign Exchange, or the Implementation Rules. Under the Implementation Rules, PRC citizens who are granted share options by an overseas
publicly-listed company are required, through a PRC agent or PRC subsidiary of such overseas publicly-listed company, to register with SAFE and complete certain other procedures.

[0001193125-19-225268:mdna:78]
In addition, the General Administration of Taxation has issued circulars concerning employee share options. Under these circulars, our
employees working in the PRC who exercise share options will be subject to PRC individual income tax. Our PRC subsidiary has obligations to file documents related to employee share options with relevant tax authorities and withhold individual income
taxes of those employees who exercise their share options.

[0001193125-19-225268:mdna:79]
Furthermore, our transfer of funds to our subsidiaries in Thailand and the PRC are each
subject to approval by governmental authorities in case of an increase in registered capital, or subject to registration with governmental authorities in case of a shareholder loan. These limitations on the flow of funds between our subsidiaries and
us could restrict our ability to act in response to changing market conditions.

[0001193125-19-225268:mdna:80]
Income Tax

[0001193125-19-225268:mdna:81]
Our effective tax rate is a function of the mix of tax rates in the various jurisdictions in which we do business. We are domiciled in the
Cayman Islands. Under the current laws of the Cayman Islands, we are not subject to tax in the Cayman Islands on income or capital gains until March 6, 2039.

[0001193125-19-225268:mdna:82]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government
in the form of a corporate tax exemption is currently available to us through June 2020 and June 2026 on income generated from projects to manufacture certain products at our Pinehurst campus and Chonburi campus, respectively. Such preferential tax
treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date
on which preferential tax treatment was granted (i.e., at least until June 2020 in the case of our Pinehurst campus and until June 2026 in the case of our Chonburi campus). Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001193125-19-225268:mdna:83]
During fiscal year 2018, one of our subsidiaries in the United States generated taxable income sufficient for the utilization
of loss carryforwards due to better operating performance and effective control of operating expenses and management determined that it was more likely than not that future taxable income would be sufficient to allow the benefit of the loss to be
realized. As of June 29, 2018, we reversed certain deferred tax assets valuation allowance as management expected it was more likely than not that we would realize profits in subsequent fiscal years so that the loss carryforwards could be
partially utilized. Consequently, as of June 28, 2019, we have assessed and set up a partial valuation allowance for the deferred tax assets at the same level as in fiscal year 2018.

[0001193125-19-225268:mdna:84]
The Tax Cuts and Jobs Act (“Tax Reform Act”) was enacted on December 22, 2017 and provided for significant changes to U.S.
tax law. Among other provisions, the Tax Reform Act reduced the U.S. corporate income tax rate to 21% effective in 2018. Under the Tax Reform Act, our U.S. subsidiaries were subject to an average Federal statutory tax rate of 27.6% for fiscal year
2018. Beginning in July 2019 and effective for fiscal year 2019, our U.S. subsidiaries’ corporate income tax rate was 21%.

[0001193125-19-225268:mdna:85]
During fiscal year 2019, we completed our assessment of the income tax effects resulting from the Tax Reform Act and we concluded that no
cumulative remeasurement adjustments were required. During fiscal year 2018, we made certain provisional accounting estimates, as permitted under Staff Accounting Bulletin No. 118, to account for the impact of the Tax Reform Act. As of
June 29, 2018, we applied the new corporate tax rate to compute our current income tax and remeasured our deferred tax assets and liabilities for all U.S. subsidiaries as of June 29, 2018 to reflect the lower rate expected to apply when
these provisional accounting estimates were utilized. The remeasurement resulted in (1) a reduction in current income tax expenses of $0.1 million and (2) a reduction in deferred tax assets of $0.4 million.

[0001193125-19-225268:mdna:86]
Critical Accounting Policies and Use of Estimates

[0001193125-19-225268:mdna:87]
We prepare our consolidated financial statements in conformity with U.S. GAAP, which requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities, the
disclosure of contingent liabilities on the date of the consolidated financial statements and the reported amounts of revenues and expenses during the financial reporting period. We continually evaluate these estimates and assumptions based on the
most recently available information, our own historical experience and on various other assumptions that we believe to

[0001193125-19-225268:mdna:88]
be reasonable under the circumstances. The evaluation results form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other
sources. Because the use of estimates is an integral component of the financial reporting process, actual results could differ from those estimates. Some of our accounting policies require higher degrees of judgment than others in their application.
We consider the policies discussed below to be critical to an understanding of our consolidated financial statements, as their application places the most significant demands on our management’s judgment.

[0001193125-19-225268:mdna:89]
A quantitative sensitivity analysis is provided where such information is reasonably available, can be reliably estimated, and provides
material information to investors. The amounts used to assess sensitivity are included for illustrative purposes only and do not represent management’s predictions of variability.

[0001193125-19-225268:mdna:90]
Our critical accounting policies and the adoption of new accounting policies are disclosed in Note 2 – Summary of significant
accounting policies. There were no changes to our accounting policies other than the adoption of Revenue from Contracts with Customers (Topic 606), which resulted from Accounting Standards Codification Topic 606 (“ASC 606”).

[0001193125-19-225268:mdna:91]
Revenue Recognition

[0001193125-19-225268:mdna:92]
On June 30, 2018, we adopted ASC 606 using the modified retrospective method, which was applied to those contracts which were not completed as of June 29, 2018. The modified retrospective method
required us to recognize the cumulative effect of the adoption of ASC 606, for all contracts with customers, to the opening balance of equity at June 30, 2018.

[0001193125-19-225268:mdna:93]
We derive total revenues primarily from the assembly of products under supply agreements with our customers and the fabrication of customized optics and glass. We recognize revenue relating to contracts
that depict the transfer of promised goods or services to customers in an amount reflecting the consideration to which we expect to be entitled in exchange for such goods or services. In order to meet this requirement, we apply the following five
steps: (1) identify the contract with a customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract,
and (5) recognize revenue when a performance obligation is satisfied. Revenue is recognized net of any taxes collected from customers, which is subsequently remitted to governmental authorities.

[0001193125-19-225268:mdna:94]
A performance obligation is a promise in a contract to transfer a distinct good or service to the customer. In contracts with multiple
performance obligations, we identify each performance obligation and evaluate whether the performance obligation is distinct within the context of the contract at contract inception. The majority of our contracts have a single performance obligation
as the promise to transfer the individual goods or services is not separately identifiable from other promises in the contracts and, therefore, not distinct.

[0001193125-19-225268:mdna:95]
Sales of finished goods

[0001193125-19-225268:mdna:96]
We manufacture products that are customized
to customers’ specifications; however, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for over time
recognition are not met. On evaluation of the contracts, we identified that there were no contractual rights to bill profit for work in progress in the event of a contract termination, which is expected to be infrequent. Further, in limited
circumstances, contracts provide for substantive acceptance by the customer, which results in the deferral of revenue until formal notice of acceptance is received from the customer. Judgment may be required in determining if an acceptance clause
provides for substantive acceptance.

[0001193125-19-225268:mdna:97]
Certain customers may request us to store finished products at our warehouse where
customers bear risks of loss themselves. In these instances, we receive a written request from the customer asking us to hold the inventory at our warehouse and refrain from using the ordered goods to fulfill other customer orders. In these
situations, revenue is only recognized when the completed goods are ready for shipment and transferred to our warehouse.

[0001193125-19-225268:mdna:98]
Customers generally are obligated to purchase finished goods that we have manufactured
according to their demand requirements. Materials that are not consumed by customers within a specified period of time, or are no longer required due to a product’s cancellation or
end-of-life, are typically designated as excess or obsolete inventory under our contracts. Once materials are designated as either excess or obsolete inventory,
customers are typically required to purchase such inventory from us even if the customer has chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

[0001193125-19-225268:mdna:99]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or
as, the performance obligation is satisfied. In determining the net consideration to which we expect to be entitled, we evaluate whether the price is subject to refund or adjustment. We generally do not grant return privileges, except for in the
case of defective products during the warranty period. We generally provide a warranty of between one to five years on any given product. These standard warranties are assurance type warranties and do not offer any services in addition to the
assurance that the product will continue to work as specified.

[0001193125-19-225268:mdna:100]
The sales price is not considered to be fixed or determinable
until all contingencies related to the sale have been resolved. We recognized revenue net of rebates and other similar allowances. Revenues are recognized only if these estimates can be reasonably and reliably determined. We base our estimates on
historical results taking into consideration the type of customer, the type of transaction and the specifics of each arrangement.

[0001193125-19-225268:mdna:101]
Services

[0001193125-19-225268:mdna:102]
We provide services for customers that are related to our
manufacturing activities. In many cases, although the nature of work performed is service in nature, revenue is only recognizable on shipping of the product because the customer has specific requirements as to how many items can be shipped at any
given point in time, i.e. at point-in-time. The related costs are expensed as incurred.

[0001193125-19-225268:mdna:103]
Long-Lived Assets

[0001193125-19-225268:mdna:104]
We review property, plant and equipment for
impairment on a quarterly basis or when events or changes in circumstances indicate the carrying amount of an asset may not be recoverable. An impairment loss is recognized when the carrying amount of a long-lived asset or assets group exceeds its
fair value. Recoverability of property and equipment is measured by comparing its carrying amount to the projected undiscounted cash flows the property and equipment are expected to generate. If such assets are considered to be impaired, the
impairment loss recognized, if any, is the amount by which the carrying amount of the property and equipment exceeds its fair value.

[0001193125-19-225268:mdna:105]
Allowance for Doubtful Accounts

[0001193125-19-225268:mdna:106]
We perform ongoing credit
evaluations of our customers’ financial condition and make provisions for doubtful accounts based on the outcomes of these credit evaluations. We evaluate the collectability of our accounts receivable based on specific customer circumstances,
current economic trends, historical experience with collections, and the age of past due receivables. Unanticipated changes in the liquidity or financial position of our customers may require additional provisions for doubtful accounts. Under our
specific identification method, it is not practical to assess the sensitivity of our estimates.

[0001193125-19-225268:mdna:107]
Inventory Valuation

[0001193125-19-225268:mdna:108]
Our inventory is stated at the lower of cost (on a first-in, first-out basis) or market value. Our industry is characterized by rapid technological change, short-term customer commitments, and rapid changes in demand. We make provisions for estimated excess and obsolete
inventory based on regular reviews of inventory quantities

[0001193125-19-225268:mdna:109]
on hand on a quarterly basis and the latest forecasts of product demand and production requirements from our customers. If actual market conditions or our customers’ product demands are less
favorable than those projected, additional provisions may be required. In addition, unanticipated changes in liquidity or the financial positions of our customers or changes in economic conditions may require additional provisions for inventory due
to our customers’ inability to fulfill their contractual obligations. During fiscal year 2019 and fiscal year 2018, a change of 10% for excess and obsolete materials, based on product demand and production requirements from our customers, would
have affected our net income by approximately $0.2 million and $0.3 million, respectively.

[0001193125-19-225268:mdna:110]
Deferred Income
Taxes

[0001193125-19-225268:mdna:111]
Our deferred income tax assets represent temporary differences between the carrying amount and the tax basis of
existing assets and liabilities that will result in deductible and payable amounts in future years, including net operating loss carry forwards. Based on estimates, the carrying value of our net deferred tax assets assumes that it is more likely
than not that we will be able to generate sufficient future taxable income in certain tax jurisdictions to realize these deferred income tax assets. Our judgments regarding future profitability may change depending on future market conditions,
changes in U.S. or international tax laws, or other factors. If these estimates and related assumptions change in the future, we may be required to increase or decrease our valuation allowance against the deferred tax assets, resulting in additional
or lesser income tax expense. During fiscal year 2018, one of our subsidiaries in the United States generated taxable income sufficient for the utilization of loss carryforwards due to better operating performance and effective control of operating
expenses and management determined that it was more likely than not that future taxable income would be sufficient to allow the benefit of the loss to be realized. As of June 29, 2018, we reversed certain deferred tax assets valuation allowance
as management expected it was more likely than not that we would realize profits in subsequent fiscal years so that the loss carryforwards could be partially utilized. Consequently, as of June 28, 2019, we have assessed and set up a partial
valuation allowance for the deferred tax assets at the same level as in fiscal year 2018.

[0001193125-19-225268:mdna:112]
We assess tax positions in a
previously filed tax return or a position expected to be taken in a future tax return that is reflected in measuring current or deferred income tax assets and liabilities for interim or annual periods, based on the technical merits of the position.
We apply a “more likely than not” basis (i.e., a likelihood greater than 50 percent), in accordance with the authoritative guidance, and recognize a tax provision in the consolidated financial statements for an uncertain tax position that
would not be sustained.

[0001193125-19-225268:mdna:113]
Share-Based Compensation

[0001193125-19-225268:mdna:114]
Awards granted, including share options, restricted share units and performance share units are accounted for by recognizing the cost of
employee services received in exchange for awards of equity instruments, based on the fair value of those awards, in the consolidated financial statements over the requisite service period.

[0001193125-19-225268:mdna:115]
In determining the fair value of share option awards, we are required to make estimates of expected dividends to be issued, expected
volatility of our shares, expected forfeitures of the awards, risk free interest rates for the expected terms of the awards and expected terms of the awards.

[0001193125-19-225268:mdna:116]
For accounting purposes only, the fair value of each option grant is estimated using the Black-Scholes-Merton option pricing model, which takes into account the following factors: (1) the exercise
price of the options; (2) the fair value of the underlying ordinary shares; (3) the expected life of the options; (4) the expected volatility of the underlying ordinary shares; (5) the risk-free interest rate during the expected
life of the options; and (6) the expected dividend yield of the underlying ordinary shares. However, these fair values are inherently uncertain and highly subjective.

[0001193125-19-225268:mdna:117]
The exercise price of the options is stated in the option agreements. The expected life of the options involves estimates of the anticipated timing of the exercise of the vested options. The expected
volatility is based

[0001193125-19-225268:mdna:118]
on the historical volatility of our share price. We have applied the U.S. Treasury Bill interest rate with a maturity date similar to the expected life of our options as the risk-free interest
rate and assumed a dividend yield for periods when we paid dividends.

[0001193125-19-225268:mdna:119]
The fair value of restricted share units and
performance share units are based on the market value of our ordinary shares on the date of grant.

[0001193125-19-225268:mdna:120]
The determination of our
share-based compensation expense for both current and future periods requires the input of assumptions, including estimated forfeitures and the price volatility of the underlying ordinary shares. We estimate forfeitures based on past employee
retention rates and our expectations of future retention rates, and we will prospectively revise our forfeiture rates based on actual history. Our share-based compensation expense may change based on changes to our actual forfeitures.

[0001193125-19-225268:mdna:121]
Intangibles

[0001193125-19-225268:mdna:122]
Intangibles are stated at historical cost less amortization. Amortization of customer relationships is calculated using the accelerated method as to reflect the pattern in which the economic benefits of
the intangible assets are consumed. Amortization of other intangibles is calculated using the straight-line method.

[0001193125-19-225268:mdna:123]
Business acquisition

[0001193125-19-225268:mdna:124]
For the acquisition of Fabrinet UK, we allocated the fair value of purchase consideration to the assets acquired and liabilities assumed based on their fair values at the acquisition date. The allocation
of consideration to the individual net assets has been finalized.

[0001193125-19-225268:mdna:125]
The acquired intangible assets, which consist of customer
relationships and backlog, are recorded as intangibles in the consolidated balance sheets. The fair value of the acquired intangible assets was determined based on the multi-period excess earnings method. We review intangibles for impairment
whenever changes or circumstances indicate the carrying amount may not be recoverable.

[0001193125-19-225268:mdna:126]
Goodwill

[0001193125-19-225268:mdna:127]
Goodwill arising from the acquisition is primarily attributable to the ability to expand future products and services and the assembled
workforce. Goodwill is reviewed annually for impairment or more frequently whenever changes or circumstances indicate the carrying amount of goodwill may not be recoverable.

[0001193125-19-225268:mdna:128]
Results of Operations

[0001193125-19-225268:mdna:129]
The following table sets forth a summary of our consolidated statements of operations and comprehensive income. Note that
period-to-period comparisons of operating results should not be relied upon as indicative of future performance.

[0001193125-19-225268:mdna:130]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 28, 2019 |  |  | June 29, 2018 |  |  | June 30, 2017 |  |
| Revenues |  | $ | 1,584,335 |  |  | $ | 1,371,925 |  |  | $ | 1,420,490 |  |
| Cost of revenues |  |  | (1,405,111 | ) |  |  | (1,218,513 | ) |  |  | (1,249,030 | ) |
| Gross profit |  |  | 179,224 |  |  |  | 153,412 |  |  |  | 171,460 |  |
| Selling, general and administrative expenses |  |  | (55,067 | ) |  |  | (57,812 | ) |  |  | (65,626 | ) |
| Expenses related to reduction in workforce |  |  | (1,516 | ) |  |  | (1,776 | ) |  |  | — |  |
| Operating income |  |  | 122,641 |  |  |  | 93,824 |  |  |  | 105,834 |  |
| Interest income |  |  | 6,699 |  |  |  | 3,925 |  |  |  | 1,977 |  |
| Interest expense |  |  | (5,381 | ) |  |  | (3,606 | ) |  |  | (3,321 | ) |
| Foreign exchange gain (loss), net |  |  | 1,406 |  |  |  | (6,587 | ) |  |  | (1,142 | ) |
| Other income, net |  |  | 868 |  |  |  | 473 |  |  |  | 509 |  |
| Income before income taxes |  |  | 126,233 |  |  |  | 88,029 |  |  |  | 103,857 |  |
| Income tax expense |  |  | (5,278 | ) |  |  | (3,862 | ) |  |  | (6,742 | ) |
| Net income |  |  | 120,955 |  |  |  | 84,167 |  |  |  | 97,115 |  |
| Other comprehensive (loss) income, net of tax |  |  | (1,129 | ) |  |  | (909 | ) |  |  | (939 | ) |
| Net comprehensive income |  | $ | 119,826 |  |  | $ | 83,258 |  |  | $ | 96,176 |  |

[0001193125-19-225268:mdna:131]
The following table sets forth a summary of our consolidated statements of operations and comprehensive
income as a percentage of total revenues for the periods indicated.

[0001193125-19-225268:mdna:132]
|  |  | Years Ended |  |
|  |  | June 28, 2019 |  |  | June 29, 2018 |  |  | June 30, 2017 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (88.7 | ) |  |  | (88.8 | ) |  |  | (87.9 | ) |
| Gross profit |  |  | 11.3 |  |  |  | 11.2 |  |  |  | 12.1 |  |
| Selling, general and administrative expenses |  |  | (3.5 | ) |  |  | (4.2 | ) |  |  | (4.6 | ) |
| Expenses related to reduction in workforce |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | — |  |
| Operating income |  |  | 7.7 |  |  |  | 6.9 |  |  |  | 7.5 |  |
| Interest income |  |  | 0.4 |  |  |  | 0.3 |  |  |  | 0.1 |  |
| Interest expense |  |  | (0.3 | ) |  |  | (0.3 | ) |  |  | (0.2 | ) |
| Foreign exchange gain (loss), net |  |  | 0.1 |  |  |  | (0.5 | ) |  |  | (0.1 | ) |
| Other income, net |  |  | 0.0 |  |  |  | 0.1 |  |  |  | 0.0 |  |
| Income before income taxes |  |  | 7.9 |  |  |  | 6.5 |  |  |  | 7.3 |  |
| Income tax expense |  |  | (0.3 | ) |  |  | (0.3 | ) |  |  | (0.5 | ) |
| Net income |  |  | 7.6 |  |  |  | 6.2 |  |  |  | 6.8 |  |
| Other comprehensive (loss) income, net of tax |  |  | 0.0 |  |  |  | (0.1 | ) |  |  | (0.1 | ) |
| Net comprehensive income |  |  | 7.6 | % |  |  | 6.1 | % |  |  | 6.7 | % |

[0001193125-19-225268:mdna:133]
50

[0001193125-19-225268:mdna:134]
The following table sets forth our revenues by end market for the periods indicated.

[0001193125-19-225268:mdna:135]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 28, 2019 |  |  | June 29, 2018 |  |  | June 30, 2017 |  |
| Optical communications |  | $ | 1,184,936 |  |  | $ | 1,000,256 |  |  | $ | 1,108,637 |  |
| Lasers, sensors, and other |  |  | 399,399 |  |  |  | 371,669 |  |  |  | 311,853 |  |
| Total |  | $ | 1,584,335 |  |  | $ | 1,371,925 |  |  | $ | 1,420,490 |  |

[0001193125-19-225268:mdna:136]
We operate and internally manage a single operating segment. As such, discrete information with respect
to separate product lines and segments is not accumulated.

[0001193125-19-225268:mdna:137]
We utilize a 52-53 week
fiscal year ending on the Friday in June closest to June 30. Fiscal year 2019 ended on June 28, 2019 and consisted of 52 weeks. Fiscal year 2018 ended on June 29, 2018 and consisted of 52 weeks. Fiscal year 2017 ended on June 30,
2017 and consisted of 53 weeks.

[0001193125-19-225268:mdna:138]
Comparison of Fiscal Year 2019 with Fiscal Year 2018

[0001193125-19-225268:mdna:139]
Total revenues. Our total revenues increased by $212.4 million, or 15.5%, to $1.58 billion for fiscal year 2019, compared
with $1.37 billion for fiscal year 2018. This increase was primarily due to an increase in customers’ demand for optical communications manufacturing services, particularly telecom manufacturing services, for fiscal year 2019. Revenues
from optical communications products represented 74.8% of our total revenues for fiscal year 2019, compared with 72.9% for fiscal year 2018.

[0001193125-19-225268:mdna:140]
Cost of revenues. Our cost of revenues increased by $186.6 million, or 15.3%, to $1.41 billion, or 88.7% of total revenues, for fiscal year 2019, compared with $1.22 billion, or
88.8% of total revenues, for fiscal year 2018. The increase in cost of revenues was primarily due to a proportional increase in sales volume.

[0001193125-19-225268:mdna:141]
Gross profit. Our gross profit increased by $25.8 million, or 16.8%, to $179.2 million, or 11.3% of total revenues, for fiscal year 2019, compared with $153.4 million, or 11.2% of
total revenues, for fiscal year 2018. The increase in gross profit percentage in fiscal year 2019 was due to higher revenue and fixed costs leverage.

[0001193125-19-225268:mdna:142]
SG&A expenses. Our SG&A expenses decreased by $2.7 million, or 4.7%, to $55.1 million, or 3.5% of total revenues, for fiscal year 2019, compared with $57.8 million, or 4.2%
of total revenues, for fiscal year 2018. Our SG&A expenses decreased during fiscal year 2019, compared with fiscal year 2018, mainly due to (1) a decrease in share-based compensation expenses of $4.3 million because we did not expect
to achieve the pre-defined performance targets for vesting of certain performance-based restricted share units awarded under our 2017 Inducement Equity Incentive Plan and (2) a decrease in executive
severance payments of $2.1 million and a decrease in key executive benefits of $1.8 million in connection with the transition of the Executive Chairman of our board of directors to non-executive
Chairman during fiscal year 2018. The decrease was offset by (1) an increase of $2.4 million in executive cash bonuses under our fiscal year 2019 executive incentive plan due to our expectation that certain
pre-defined revenue targets and non-U.S. GAAP gross margin targets would be achieved; (2) an increase in severance payment of $1.0 million in connection with non-executive management separations; (3) an increase in public company cost of $0.6 million; and (4) an increase in severance liability expense of $0.4 million due to an increase in headcount as
well as a change in labor protection law in Thailand that increased the required severance payment compensation for employees with 20 or more years of service from 300 days of wage to 400 days of wage.

[0001193125-19-225268:mdna:143]
Operating income. Our operating income increased by $28.8 million to $122.6 million, or 7.7% of total revenues, for
fiscal year 2019, compared with $93.8 million, or 6.9% of total revenues, for fiscal year 2018.

[0001193125-19-225268:mdna:144]
Interest income.
Our interest income increased by $2.8 million to $6.7 million for fiscal year 2019, compared with $3.9 million for fiscal year 2018. The increase was primarily due to the higher weighted average

[0001193125-19-225268:mdna:145]
interest rate compared to the same period in the last year and an increase in the average balance of our outstanding cash and cash equivalents and short-term investments.

[0001193125-19-225268:mdna:146]
Interest expense. Our interest expense increased by $1.8 million to $5.4 million for fiscal year 2019, compared with
$3.6 million for fiscal year 2018. The increase was due to (1) unrealized loss of $2.6 million from mark-to-market of interest rate swap related to our
term loan; and (2) an increase of $0.5 million from the increase in the fixed interest rate from interest rate swap. The increase was offset by (1) the amortization and write off of deferred debt issuance costs from loan borrowing
paid up in fiscal year 2018 of $1.0 million; and (2) a decrease in loan commitment fee of $0.3 million.

[0001193125-19-225268:mdna:147]
Foreign exchange gain (loss), net. We recorded foreign exchange gain, net of $1.4 million for fiscal year 2019, compared with
foreign exchange loss, net of $6.6 million for fiscal year 2018. The foreign exchange gain for fiscal year 2019 was mainly due to unrealized gain of $4.8 million for
mark-to-market of forward contracts related to hedging of Thai baht spending, compared to unrealized loss of $2.6 million in fiscal year 2018. Moreover, we recorded
realized foreign exchange loss from receipts and payments of $4.6 million in fiscal year 2018.

[0001193125-19-225268:mdna:148]
Income before income
taxes. We recorded income before income taxes of $126.2 million for fiscal year 2019, compared with $88.0 million for fiscal year 2018.

[0001193125-19-225268:mdna:149]
Income tax expense. Our provision for income tax reflects an effective tax rate of 4.6% for fiscal year 2019 and 5.0% for fiscal year 2018.

[0001193125-19-225268:mdna:150]
Net income. We recorded net income of $121.0 million, or 7.6% of total revenues, for fiscal year 2019, compared with net
income of $84.2 million, or 6.2% of total revenues, for fiscal year 2018.

[0001193125-19-225268:mdna:151]
Other comprehensive loss. Our other
comprehensive loss increased by $0.2 million to $1.1 million for fiscal year 2019 compared with $0.9 million for fiscal year 2018.

[0001193125-19-225268:mdna:152]
Comparison of Fiscal Year 2018 with Fiscal Year 2017

[0001193125-19-225268:mdna:153]
Total
revenues. Our total revenues decreased by $48.6 million, or 3.4%, to $1.37 billion for fiscal year 2018, compared with $1.42 billion for fiscal year 2017. This decrease was primarily due to a decrease in customers’ demand for
optical communications manufacturing services, particularly telecom manufacturing services, for fiscal year 2018, driven by a slower growth rate in the data center market following a peak year in fiscal year 2017, partially offset by an increase in
customers’ demand for non-optical communications manufacturing services. Revenues from optical communications products represented 72.9% of our total revenues for fiscal year 2018, compared with 78.0% for
fiscal year 2017.

[0001193125-19-225268:mdna:154]
Cost of revenues. Our cost of revenues decreased by $30.5 million, or 2.4%, to
$1.22 billion, or 88.8% of total revenues, for fiscal year 2018, compared with $1.25 billion, or 87.9% of total revenues, for fiscal year 2017. The decrease in cost of revenues was primarily due to a proportional decrease in sales volume.

[0001193125-19-225268:mdna:155]
Gross profit. Our gross profit decreased by $18.0 million, or 10.5%, to $153.4 million, or 11.2% of total
revenues, for fiscal year 2018, compared with $171.5 million, or 12.1% of total revenues, for fiscal year 2017.

[0001193125-19-225268:mdna:156]
SG&A expenses. Our SG&A expenses decreased by $7.8 million, or 11.9%, to $57.8 million, or 4.2% of total
revenues, for fiscal year 2018, compared with $65.6 million, or 4.6% of total revenues, for fiscal year 2017. Our SG&A expenses decreased during fiscal year 2018, compared with fiscal year 2017, mainly due to (1) decreases in
incentive-based compensation of $9.2 million because we did not achieve the targets under our fiscal year 2018 executive incentive plan, and expenses related to merger and acquisition activities of $1.7 million because we did not acquire
any businesses during fiscal year 2018; partially offset by (2) an increase related to a payment of $2.1 million in severance during fiscal year 2018 to the Executive Chairman of our board of directors in connection with his transition to non-executive Chairman of our board of directors.

[0001193125-19-225268:mdna:157]
Operating income. Our operating income decreased by $12.0 million to
$93.8 million, or 6.8% of total revenues, for fiscal year 2018, compared with $105.8 million, or 7.5% of total revenues, for fiscal year 2017.

[0001193125-19-225268:mdna:158]
Interest income. Our interest income increased by $1.9 million to $3.9 million for fiscal year 2018, compared with $2.0 million for fiscal year 2017. The increase was primarily due
to an increase in our average outstanding cash and short-term investments balances and interest rates.

[0001193125-19-225268:mdna:159]
Interest expense.
Our interest expense increased by $0.3 million to $3.6 million for fiscal year 2018, compared with $3.3 million for fiscal year 2017. The increase was primarily due to an increase in the average interest rate.

[0001193125-19-225268:mdna:160]
Foreign exchange loss, net. We recorded foreign exchange loss, net of $6.6 million for fiscal year 2018, compared with
$1.1 million for fiscal year 2017. The increase was primarily due to the fluctuation of the Thai baht and RMB against our functional currency, the U.S. dollar.

[0001193125-19-225268:mdna:161]
Income before income taxes. We recorded income before income taxes of $88.0 million for fiscal year 2018, compared with $103.9 million for fiscal year 2017.

[0001193125-19-225268:mdna:162]
Income tax expense. Our provision for income tax reflects an effective tax rate of 5.0% for fiscal year 2018, compared with an
effective tax rate of 5.5% for fiscal year 2017. The decrease in income tax expense was primarily due to the fact that we had more income not subject to tax during fiscal year 2018 as compared with fiscal year 2017. The impact from the Tax Cuts and
Jobs Act resulted in a reduction in income tax expense of $0.1 million during fiscal year 2018.

[0001193125-19-225268:mdna:163]
Net income. We
recorded net income of $84.2 million, or 6.2% of total revenues, for fiscal year 2018, compared with net income of $97.1 million, or 6.8% of total revenues, for fiscal year 2017.

[0001193125-19-225268:mdna:164]
Other comprehensive (loss) income. Our other comprehensive loss remained flat at $0.9 million, or 0.1% of total revenues for
each of fiscal year 2018 and fiscal year 2017.

[0001193125-19-225268:mdna:165]
Liquidity and Capital Resources

[0001193125-19-225268:mdna:166]
Cash Flows and Working Capital

[0001193125-19-225268:mdna:167]
We primarily finance our operations through cash flow from operating activities. As of June 28, 2019 and June 29, 2018, we had cash, cash equivalents, and short-term investments of
$437.3 million and $332.4 million, respectively, and outstanding debt of $60.9 million and $64.2 million, respectively.

[0001193125-19-225268:mdna:168]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits and liquid investments with original maturities of three months or less, are placed with banks and other financial
institutions. The weighted average interest rate on our cash and cash equivalents for fiscal year 2019, fiscal year 2018 and fiscal year 2017 was 1.9%, 0.8% and 0.6%, respectively.

[0001193125-19-225268:mdna:169]
Our cash investments are made in accordance with an investment policy approved by the Audit Committee of our board of directors. In
general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed income securities
are primarily classified as available-for-sale and are recorded at fair value. The cost of securities sold is based on the specific identification method. Unrealized
gains and losses on these securities are recorded as other comprehensive income (loss) and are reported as a separate component of shareholders’ equity.

[0001193125-19-225268:mdna:170]
During fiscal year 2019, we repaid a term loan of $3.3 million under our Facility Agreement. As of June 28, 2019, we had long-term borrowing of $60.9 million under our Facility Agreement.
We anticipate that our

[0001193125-19-225268:mdna:171]
internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held investments in short-term
marketable securities, liquidity funds, certificates of deposit and time deposits of $256.5 million as of June 28, 2019.

[0001193125-19-225268:mdna:172]
We believe that our current cash, cash equivalents, marketable securities, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and
capital expenditure needs for at least the 12 months following the filing of this Annual Report on Form 10-K. Our ability to sustain our working capital position is subject to a number of risks that we discuss
in Item 1A of this Annual Report on Form 10-K.

[0001193125-19-225268:mdna:173]
We also believe that our current
manufacturing capacity is sufficient to meet our anticipated production requirements for at least the next few quarters.

[0001193125-19-225268:mdna:174]
The
following table shows our cash flows for the periods indicated:

[0001193125-19-225268:mdna:175]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 28, 2019 |  |  | June 29, 2018 |  |  | June 30, 2017 |  |
| Net cash provided by operating activities |  | $ | 147,394 |  |  | $ | 138,080 |  |  | $ | 70,934 |  |
| Net cash used in investing activities |  | $ | (98,067 | ) |  | $ | (58,649 | ) |  | $ | (90,556 | ) |
| Net cash (used in) provided by financing activities |  | $ | (23,223 | ) |  | $ | (54,106 | ) |  | $ | 13,432 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  | $ | 26,104 |  |  | $ | 25,325 |  |  | $ | (6,190 | ) |
| Cash, cash equivalents and restricted cash, beginning of period |  | $ | 161,433 |  |  | $ | 137,137 |  |  | $ | 142,804 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 188,241 |  |  | $ | 161,433 |  |  | $ | 137,137 |  |

[0001193125-19-225268:mdna:176]
Operating Activities

[0001193125-19-225268:mdna:177]
Net cash provided by operating activities increased by $9.3 million, or 6.7%, to $147.4 million for fiscal year 2019, compared
with net cash provided by operating activities of $138.1 million for fiscal year 2018 due to better working capital management. This increase was due to an increase in net income of $36.8 million and a decrease in cash paid to settle
accounts payable of $35.3 million. These increases in cash were offset by a decrease in cash receipts related to the timing of collection of trade accounts receivable of $31.3 million, an increase in gain on exchange rate and fair value of
derivative instruments of $11.2 million, an increase in ending inventories intended for sale in future quarters of $24.6 million and a decrease in share-based compensation of $5.4 million.

[0001193125-19-225268:mdna:178]
Net cash provided by operating activities increased by $67.1 million, or 94.7%, to $138.1 million for fiscal year 2018,
compared with net cash provided by operating activities of $70.9 million for fiscal year 2017 due to better working capital management. This increase was due to an increase in cash received from trade accounts receivable of $82.0 million
and a decrease in ending inventories of $34.4 million. These were offset by decreases in net income of $12.9 million and cash paid to trade accounts payable of $34.8 million.

[0001193125-19-225268:mdna:179]
Investing Activities

[0001193125-19-225268:mdna:180]
Net cash used in investing activities increased by $39.4 million, or 67.2 %, to $98.1 million for fiscal year 2019, compared with net cash used in investing activities of $58.6 million
for fiscal year 2018. The increase was primarily due to a net increase in investment in short-term investments of $56.0 million, offset by a decrease of $16.5 million in the purchase of property, plant and equipment and intangible assets.

[0001193125-19-225268:mdna:181]
Net cash used in investing activities decreased by $31.9 million, or 35.2 %, to $58.6 million for fiscal year
2018, compared with net cash used in investing activities of $90.6 million for fiscal year 2017. The decrease was

[0001193125-19-225268:mdna:182]
primarily due to a decrease of $34.4 million in the purchase of property, plant and equipment as the construction of our new facility in Chonburi, Thailand was completed in March 2017 and
there was no significant purchase of property, plant and equipment during fiscal year 2018, and a decrease of $9.9 million related to merger and acquisition activities because we did not acquire any businesses during fiscal year 2018. These
decreases were offset by a net increase in investment in marketable securities of $12.9 million.

[0001193125-19-225268:mdna:183]
Financing
Activities

[0001193125-19-225268:mdna:184]
Net cash used in financing activities decreased by $30.9 million, or 57.1%, to $23.2 million for
fiscal year 2019, compared with net cash provided by financing activities of $54.1 million for fiscal year 2018. This decrease was primarily due to a decrease in cash paid for the repurchase of ordinary shares of $37.0 million and a
decrease in cash paid for long-term loans of $8.0 million. These were offset by (1) an increase in cash paid for withholding tax related to net share settlement of restricted share units of $5.1 million, (2) a decrease in cash
received from short-term loans from bank of $5.0 million, and (3) the release of restricted cash in connection with a business acquisition of $3.5 million.

[0001193125-19-225268:mdna:185]
Net cash used in financing activities increased by $67.5 million, or 502.8%, to $54.1 million for fiscal year 2018, compared with net cash provided by financing activities of $13.4 million
for fiscal year 2017. This increase was primarily due to (1) an increase in cash paid for repurchase of ordinary shares of $42.4 million, (2) a decrease in cash received from short-term loans of $22.5 million, (3) an
increase in cash paid for withholding tax related to net share settlement of restricted share units of $4.1million, and (4) a decrease in cash received from the issuance of ordinary shares under our employee share option plans of
$4.5 million. These were offset by a decrease in repayment of long-term loans of $6.9 million.

[0001193125-19-225268:mdna:186]
Contractual Obligations

[0001193125-19-225268:mdna:187]
The following table sets forth certain of our contractual obligations as of June 28, 2019:

[0001193125-19-225268:mdna:188]
|  |  | Payments Due by Period |  |
| (amount in thousands) |  | Total |  |  | Less than 1year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than5 years |  |
| Long-term debt obligations |  | $ | 60,938 |  |  | $ | 3,250 |  |  | $ | 6,500 |  |  | $ | 51,188 |  |  | $ | — |  |
| Interest expense obligation (1) |  |  | 8,563 |  |  |  | 2,383 |  |  |  | 4,340 |  |  |  | 1,840 |  |  |  | — |  |
| Capital lease obligations |  |  | 500 |  |  |  | 398 |  |  |  | 102 |  |  |  | — |  |  |  | — |  |
| Operating lease obligations |  |  | 5,709 |  |  |  | 1,746 |  |  |  | 2,561 |  |  |  | 1,402 |  |  |  | — |  |
| Severance liabilities (2) |  |  | 15,473 |  |  |  | 840 |  |  |  | 2,255 |  |  |  | 2,260 |  |  |  | 10,118 |  |
| Provision for uncertain income tax position |  |  | 2,100 |  |  |  | 931 |  |  |  | 913 |  |  |  | 256 |  |  |  | — |  |
| Total |  | $ | 93,283 |  |  | $ | 9,548 |  |  | $ | 16,671 |  |  | $ | 56,946 |  |  | $ | 10,118 |  |

[0001193125-19-225268:mdna:189]
| (1) | Interest expense obligation reflects the interest rate on long-term debt obligation as of June 28, 2019. The interest rates ranged between 3.6% and 4.0%. For further discussion of long-term and short-term debt obligations, see Note 15 of our audited consolidated financial statements. |

[0001193125-19-225268:mdna:190]
| (2) | Severance liabilities as of June 28, 2019 are determined based on management assumptions. See Note 16 of our audited consolidated financial statements. |

[0001193125-19-225268:mdna:191]
As of June 28, 2019, our long-term debt obligations consisted of approximately
$60.9 million outstanding under a loan agreement. The loan prescribes maximum ratios of total leverage and minimum levels of debt service coverage ratios (i.e., earnings before interest expenses and depreciation and amortization plus cash on
hand minus short-term debts divided by current portion of long-term debts plus interest expenses). These financial ratio covenants could restrict our ability to incur additional indebtedness and limit our ability to use our cash. Our long-term debt
obligation also includes customary events of default.

[0001193125-19-225268:mdna:192]
As of June 28, 2019, we were in compliance with our long-term loan agreements.
Nonetheless, in the event of a default on these loans or a breach of a financial ratio covenant, the lenders may immediately cancel the loan agreements, deem the full amount of the outstanding indebtedness immediately due and payable; charge us
interest on a monthly basis on the full amount of the outstanding indebtedness and, if we cannot repay all of our outstanding obligations, sell the assets pledged as collateral for the loans in order to fulfill our obligations to the lenders. We may
also be held responsible for any damages and related expenses incurred by the lender as a result of any default.

[0001193125-19-225268:mdna:193]
We entered
into the Facility Agreement with a consortium of banks on May 22, 2014, which provided for a $200.0 million credit line, comprised of a $150.0 million revolving loan facility and a $50.0 million delayed draw term loan facility
with a maturity date of May 22, 2019. The revolving loan facility contained an accordion feature permitting us to request an increase in the facility up to $100.0 million subject to customary terms and conditions and provided that no
default or event of default exists at the time of request.

[0001193125-19-225268:mdna:194]
On February 26, 2015, we entered into the Second Amendment to
the Facility Agreement, which extended the availability period for draws on the term loan facility from May 21, 2015 to July 31, 2015 and allowed us, upon the satisfaction of certain conditions, to designate from time to time one or more
of Fabrinet’s subsidiaries as borrowers under the Facility Agreement. On July 31, 2015, we entered into the Third Amendment to the Facility Agreement, which extended the availability period for draws on the term loan facility from
July 31, 2015 to July 31, 2016. On July 22, 2016, we entered into the Fourth Amendment to the Facility Agreement to change the timing of filing certain financial information with the bank.

[0001193125-19-225268:mdna:195]
On June 4, 2018, we entered into the Fifth Amendment to the Facility Agreement to (1) reduce the revolving commitments
thereunder from $150.0 million to $25.0 million, (2) extend the termination date of the revolving commitments from May 22, 2019 to June 4, 2023, (3) refinance the then-existing term loan and revolving loans under the
Facility Agreement into a $65.0 million term loan that matures on June 4, 2023, and (4) reduce the applicable interest rate margins and commitment fees. The revolving loan facility contains an accordion feature permitting us to
request an increase in the facility up to $200.0 million subject to customary terms and conditions and provided that no default or event of default exists at the time of request. The revolving loan facility terminates and all amounts
outstanding are due and payable in full on June 4, 2023. The principal amount of any drawn term loans must be repaid according to the scheduled quarterly amortization payments, with final payment of all amounts outstanding, plus accrued
interest, being due June 4, 2023.

[0001193125-19-225268:mdna:196]
As of June 28, 2019, $60.9 million of the term loan was outstanding under
the Facility Agreement and there were available revolving credit facilities of $25.0 million.

[0001193125-19-225268:mdna:197]
As of June 28, 2019,
we also had certain operating lease arrangements in which the lease payments are calculated using the straight-line method. Our rental expenses under these leases were $1.9 million, $1.8 million and $1.7 million for fiscal year 2019,
fiscal year 2018 and fiscal year 2017, respectively.

[0001193125-19-225268:mdna:198]
Capital Expenditures

[0001193125-19-225268:mdna:199]
The following table sets forth our capital expenditures, which include amounts for which payments have been accrued, for the periods
indicated.

[0001193125-19-225268:mdna:200]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 28, 2019 |  |  | June 29, 2018 |  |  | June 30, 2017 |  |
| Capital expenditures |  | $ | 20,834 |  |  | $ | 30,535 |  |  | $ | 56,194 |  |

[0001193125-19-225268:mdna:201]
Our capital expenditures for fiscal year 2019, fiscal year 2018 and fiscal year 2017 principally related
to investment in our new facilities in Thailand and the United States. During fiscal year 2019, we purchased additional equipment to continue to support the expansion of our manufacturing facilities in Thailand. During

[0001193125-19-225268:mdna:202]
fiscal year 2018, we purchased additional equipment to continue to support the expansion of our manufacturing facilities in Thailand and the United Kingdom. During fiscal year 2017, we purchased
equipment and entered into an agreement to purchase an additional parcel of land in Chonburi, to support the expansion of our manufacturing operations in Thailand, which was fully paid for during fiscal year 2018. During fiscal year 2020, we expect
our capital expenditures to increase compared to fiscal year 2019 mainly related to investment in existing and new manufacturing facilities.

[0001193125-19-225268:mdna:203]
Off-Balance Sheet Commitments and Arrangements

[0001193125-19-225268:mdna:204]
As of June 28, 2019, we had an outstanding standby letter of credit of 6.0 million Euros related to our support of a customer
with the transfer of certain manufacturing operations from Berlin, Germany to our facilities in Thailand. As of June 28, 2019, the standby letter of credit was backed by cash collateral of $7.4 million.

[0001193125-19-225268:mdna:205]
Recent Accounting Pronouncements

[0001193125-19-225268:mdna:206]
See Note 2 of the Notes to Consolidated Financial Statements for recent accounting pronouncements that could have an effect on us.
