# FN 8-K — 0001193125-19-224520 filed 2019-08-19

## item codes, every 8-K on or before 2019-08-20

- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2019-08-20

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-19-224520:8k_2_02:1]
EX-99.1
2
d794174dex991.htm
EX-99.1

[0001193125-19-224520:8k_2_02:2]
EX-99.1

[0001193125-19-224520:8k_2_02:3]
Exhibit 99.1

[0001193125-19-224520:8k_2_02:4]
Fabrinet Announces Fourth Quarter and Fiscal Year 2019 Financial Results

[0001193125-19-224520:8k_2_02:5]
|  | • |  | Fiscal Year 2019 Revenue Increases 15% from Fiscal Year 2018 |

[0001193125-19-224520:8k_2_02:6]
|  | • |  | GAAP and Non-GAAP Net Income Grow 44% and 26%, Respectively |

[0001193125-19-224520:8k_2_02:7]
|  | • |  | Cash Flow From Operations of $147.4 Million Up 7% From Prior Year |

[0001193125-19-224520:8k_2_02:8]
BANGKOK, Thailand – August 19, 2019 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision
optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its fourth quarter and fiscal year ended June 28, 2019.

[0001193125-19-224520:8k_2_02:9]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “We are pleased with our strong revenue and earnings performance in the fourth quarter, which
represented quarterly records for the company. These results reflect the diversity of our customers and the markets that we serve.”

[0001193125-19-224520:8k_2_02:10]
Grady continued,
“These strong fourth quarter results also capped the best fiscal year in our history, as we generated record revenue, profitability and operating cash flows, on a full year basis. While we expect first quarter revenue and EPS to moderate from
our record fourth quarter performance, we remain optimistic that our leadership as a trusted manufacturing partner positions us for continued success in fiscal 2020 and beyond.”

[0001193125-19-224520:8k_2_02:11]
Fourth Quarter Fiscal Year 2019 Financial Highlights

[0001193125-19-224520:8k_2_02:12]
GAAP Results

[0001193125-19-224520:8k_2_02:13]
|  | • |  | Revenue for the fourth quarter of fiscal year 2019 was $405.1 million, compared to revenue of $345.3 million for the comparable period in fiscal year 2018. |

[0001193125-19-224520:8k_2_02:14]
|  | • |  | GAAP net income for the fourth quarter of fiscal year 2019 was $33.0 million, compared to GAAP net income of $22.8 million for the fourth quarter of fiscal year 2018. GAAP net income for the fourth quarter of fiscal year 2019 included a foreign exchange gain of $1.8 million, or $0.05 per diluted share, compared to a foreign exchange loss of ($0.9) million, or ($0.02) per diluted share, for the fourth quarter of fiscal year 2018. |

[0001193125-19-224520:8k_2_02:15]
|  | • |  | GAAP net income per diluted share for the fourth quarter of fiscal year 2019 was $0.88, compared to GAAP net income per diluted share of $0.60 for the fourth quarter of fiscal year 2018. |

[0001193125-19-224520:8k_2_02:16]
Non-GAAP
Results

[0001193125-19-224520:8k_2_02:17]
|  | • |  | Non-GAAP net income for the fourth quarter of fiscal year 2019 was $37.6 million, compared to non-GAAP net income of $30.7 million for the fourth quarter of fiscal year 2018. Non-GAAP net income for the fourth quarter of fiscal year 2019 included a foreign exchange gain of $1.8 million, or $0.05 per diluted share, compared to a foreign exchange loss of ($0.9) million, or ($0.02) per diluted share, for the fourth quarter of fiscal year 2018. |

[0001193125-19-224520:8k_2_02:18]
|  | • |  | Non-GAAP net income per diluted share for the fourth quarter of fiscal year 2019 was $1.00, compared to non-GAAP net income per diluted share of $0.81 for the same period a year ago. |

[0001193125-19-224520:8k_2_02:19]
Fiscal Year 2019 Financial Highlights

[0001193125-19-224520:8k_2_02:20]
GAAP Results

[0001193125-19-224520:8k_2_02:21]
|  | • |  | Revenue for fiscal year 2019 was $1,584.3 million, an increase of 15% compared to revenue of $1,371.9 million for fiscal year 2018. |

[0001193125-19-224520:8k_2_02:22]
|  | • |  | GAAP net income for fiscal year 2019 was $121.0 million, an increase of 44% compared to GAAP net income of $84.2 million for fiscal year 2018. GAAP net income for fiscal year 2019 included a foreign exchange gain of $1.4 million, or $0.04 per diluted share, compared to a foreign exchange loss of ($6.6) million, or ($0.17) per diluted share, for fiscal year 2018. |

[0001193125-19-224520:8k_2_02:23]
|  | • |  | GAAP net income per diluted share for fiscal year 2019 was $3.23, compared to GAAP net income per diluted share of $2.21 for fiscal year 2018. |

[0001193125-19-224520:8k_2_02:24]
Non-GAAP Results

[0001193125-19-224520:8k_2_02:25]
|  | • |  | Non-GAAP net income for fiscal year 2019 was $142.6 million, an increase of 26% compared to non-GAAP net income of $113.5 million for fiscal year 2018. Non-GAAP net income for fiscal year 2019 included a foreign exchange gain of $1.4 million, or $0.04 per diluted share, compared to a foreign exchange loss of ($6.6) million, or ($0.17) per diluted share, for fiscal year 2018. |

[0001193125-19-224520:8k_2_02:26]
|  | • |  | Non-GAAP net income per diluted share for fiscal year 2019 was $3.81, compared to non-GAAP net income per diluted share of $2.98 for fiscal year 2018. |

[0001193125-19-224520:8k_2_02:27]
Business
Outlook

[0001193125-19-224520:8k_2_02:28]
Based on information available as of August 19, 2019, Fabrinet is issuing guidance for its first quarter of fiscal year 2020 ending
September 27, 2019, as follows:

[0001193125-19-224520:8k_2_02:29]
|  | • |  | Fabrinet expects first quarter revenue to be in the range of $386 million to $394 million. |

[0001193125-19-224520:8k_2_02:30]
|  | • |  | GAAP net income per diluted share is expected to be in the range of $0.64 to $0.68, based on approximately 37.4 million fully diluted shares outstanding. |

[0001193125-19-224520:8k_2_02:31]
|  | • |  | Non-GAAP net income per diluted share is expected to be in the range of $0.80 to $0.84, based on approximately 37.4 million fully diluted shares outstanding. |

[0001193125-19-224520:8k_2_02:32]
Conference Call Information

[0001193125-19-224520:8k_2_02:33]
| What: |  | Fabrinet Fourth Quarter and Fiscal Year 2019 Financial Results Call |
| When: |  | Monday, August 19, 2019 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic (253) 237-1137, international Passcode: 5568615 |
| Replay: |  | (855) 859-2056, domestic (404) 537-3406, international Passcode: 5568615 |
| Webcast: |  | http://investor.fabrinet.com/ (live and replay) |

[0001193125-19-224520:8k_2_02:34]
This press release and any other information related to the call will also be posted on Fabrinet’s website at
http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-19-224520:8k_2_02:35]
About Fabrinet

[0001193125-19-224520:8k_2_02:36]
Fabrinet is a leading provider of
advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive
components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain
management, manufacturing, advanced packaging,

[0001193125-19-224520:8k_2_02:37]
integration, final assembly and test. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and
facilities in Thailand, the United States of America, the People’s Republic of China and the United Kingdom. For more information visit: www.fabrinet.com.

[0001193125-19-224520:8k_2_02:38]
Forward-Looking Statements

[0001193125-19-224520:8k_2_02:39]
Use of Non-GAAP Financials

[0001193125-19-224520:8k_2_02:40]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful
supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; depreciation of fair value uplift; ASC 606 adoption impact on gross
profit; severance payments; expenses related to our CFO/CEO search; amortization of intangibles; business combination expenses and consulting fee; amortization of debt issuance costs; and expenses related to reduction in workforce. We have excluded
these items in order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our
company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial
measures.

[0001193125-19-224520:8k_2_02:41]
These non-GAAP financial measures are used to: (1) measure company performance against historical
results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001193125-19-224520:8k_2_02:42]
SOURCE: Fabrinet

[0001193125-19-224520:8k_2_02:43]
Investor Contact:

[0001193125-19-224520:8k_2_02:44]
Garo Toomajanian

[0001193125-19-224520:8k_2_02:45]
ir@fabrinet.com

[0001193125-19-224520:8k_2_02:46]
FABRINET

[0001193125-19-224520:8k_2_02:47]
CONSOLIDATED BALANCE SHEETS

[0001193125-19-224520:8k_2_02:48]
| (in thousands of U.S. dollars, except share data and par value) |  | June 28,2019 |  |  | June 29,2018 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 180,839 |  |  | $ | 158,102 |  |
| Restricted cash in connection with business acquisition |  |  | — |  |  |  | 3,331 |  |
| Short-term investments |  |  | 256,493 |  |  |  | 174,269 |  |
| Trade accounts receivable, net |  |  | 260,602 |  |  |  | 246,912 |  |
| Contract assets |  |  | 12,447 |  |  |  | — |  |
| Inventory, net |  |  | 293,612 |  |  |  | 257,687 |  |
| Prepaid expenses |  |  | 8,827 |  |  |  | 8,061 |  |
| Other current assets |  |  | 11,015 |  |  |  | 5,948 |  |
| Total current assets |  |  | 1,023,835 |  |  |  | 854,310 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Long-term restricted cash |  |  | 7,402 |  |  |  | — |  |
| Property, plant and equipment, net |  |  | 210,686 |  |  |  | 219,640 |  |
| Intangibles, net |  |  | 3,887 |  |  |  | 4,880 |  |
| Goodwill |  |  | 3,705 |  |  |  | 3,828 |  |
| Deferred tax assets |  |  | 5,679 |  |  |  | 5,280 |  |
| Other non-current assets |  |  | 124 |  |  |  | 80 |  |
| Total non-current assets |  |  | 231,483 |  |  |  | 233,708 |  |
| Total Assets |  | $ | 1,255,318 |  |  | $ | 1,088,018 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Bank borrowings |  | $ | 3,250 |  |  | $ | 3,250 |  |
| Trade accounts payable |  |  | 257,617 |  |  |  | 220,159 |  |
| Contract liabilities |  |  | 2,239 |  |  |  | — |  |
| Capital lease liability, current portion |  |  | 398 |  |  |  | 451 |  |
| Income tax payable |  |  | 1,801 |  |  |  | 709 |  |
| Deferred liability in connection with business acquisition |  |  | — |  |  |  | 3,331 |  |
| Accrued payroll, bonus and related expenses |  |  | 16,510 |  |  |  | 13,476 |  |
| Accrued expenses |  |  | 8,997 |  |  |  | 9,013 |  |
| Other payables |  |  | 22,236 |  |  |  | 19,728 |  |
| Total current liabilities |  |  | 313,048 |  |  |  | 270,117 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term loan from bank |  |  | 57,688 |  |  |  | 60,938 |  |
| Deferred tax liability |  |  | 3,561 |  |  |  | 2,284 |  |
| Capital lease liability, non-current portion |  |  | 102 |  |  |  | 516 |  |
| Severance liabilities |  |  | 15,209 |  |  |  | 10,162 |  |
| Other non-current liabilities |  |  | 2,611 |  |  |  | 3,062 |  |
| Total non-current liabilities |  |  | 79,171 |  |  |  | 76,962 |  |
| Total Liabilities |  |  | 392,219 |  |  |  | 347,079 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of June 28, 2019 and June 29, 2018) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 38,230,753 shares and 37,723,733 shares issued as of June 28, 2019 and June 29, 2018, respectively; and 36,841,650 shares and 36,434,630 shares outstanding as of June 28, 2019 and June 29, 2018, respectively) |  |  | 382 |  |  |  | 377 |  |
| Additional paid-in capital |  |  | 158,299 |  |  |  | 151,797 |  |
| Less: Treasury shares (1,389,103 shares and 1,289,103 shares as of June 28, 2019 and June 29, 2018, respectively) |  |  | (47,779 | ) |  |  | (42,401 | ) |
| Accumulated other comprehensive loss |  |  | (2,386 | ) |  |  | (1,257 | ) |
| Retained earnings |  |  | 754,583 |  |  |  | 632,423 |  |
| Total Shareholders’ Equity |  |  | 863,099 |  |  |  | 740,939 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 1,255,318 |  |  | $ | 1,088,018 |  |

[0001193125-19-224520:8k_2_02:49]
FABRINET

[0001193125-19-224520:8k_2_02:50]
CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME

[0001193125-19-224520:8k_2_02:51]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
| (in thousands of U.S. dollars, except per share data) |  | June 28,2019 |  |  | June 29,2018 |  |  | June 28,2019 |  |  | June 29,2018 |  |
| Revenues |  | $ | 405,127 |  |  | $ | 345,327 |  |  | $ | 1,584,335 |  |  | $ | 1,371,925 |  |
| Cost of revenues |  |  | (358,501 | ) |  |  | (306,346 | ) |  |  | (1,405,111 | ) |  |  | (1,218,513 | ) |
| Gross profit |  |  | 46,626 |  |  |  | 38,981 |  |  |  | 179,224 |  |  |  | 153,412 |  |
| Selling, general and administrative expenses |  |  | (13,771 | ) |  |  | (16,559 | ) |  |  | (55,067 | ) |  |  | (57,812 | ) |
| Expenses related to reduction in workforce |  |  | (789 | ) |  |  | — |  |  |  | (1,516 | ) |  |  | (1,776 | ) |
| Operating income |  |  | 32,066 |  |  |  | 22,422 |  |  |  | 122,641 |  |  |  | 93,824 |  |
| Interest income |  |  | 1,929 |  |  |  | 1,371 |  |  |  | 6,699 |  |  |  | 3,925 |  |
| Interest expense |  |  | (1,708 | ) |  |  | (1,107 | ) |  |  | (5,381 | ) |  |  | (3,606 | ) |
| Foreign exchange gain (loss), net |  |  | 1,814 |  |  |  | (877 | ) |  |  | 1,406 |  |  |  | (6,587 | ) |
| Other income, net |  |  | 70 |  |  |  | 35 |  |  |  | 868 |  |  |  | 473 |  |
| Income before income taxes |  |  | 34,171 |  |  |  | 21,844 |  |  |  | 126,233 |  |  |  | 88,029 |  |
| Income tax expense |  |  | (1,214 | ) |  |  | 924 |  |  |  | (5,278 | ) |  |  | (3,862 | ) |
| Net income |  |  | 32,957 |  |  |  | 22,768 |  |  |  | 120,955 |  |  |  | 84,167 |  |
| Other comprehensive loss, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities |  |  | 644 |  |  |  | 29 |  |  |  | 2,043 |  |  |  | (1,019 | ) |
| Change in net unrealized gain (loss) on derivative instruments |  |  | 1 |  |  |  | — |  |  |  | (1 | ) |  |  | (1 | ) |
| Change in retirement benefits plan – prior service cost |  |  | (2,537 | ) |  |  | — |  |  |  | (2,537 | ) |  |  | — |  |
| Change in foreign currency translation adjustment |  |  | (415 | ) |  |  | (1,247 | ) |  |  | (634 | ) |  |  | 111 |  |
| Total other comprehensive loss, net of tax |  |  | (2,307 | ) |  |  | (1,218 | ) |  |  | (1,129 | ) |  |  | (909 | ) |
| Net comprehensive income |  |  | 30,650 |  |  |  | 21,550 |  |  | $ | 119,826 |  |  | $ | 83,258 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.89 |  |  | $ | 0.62 |  |  | $ | 3.29 |  |  | $ | 2.26 |  |
| Diluted |  | $ | 0.88 |  |  | $ | 0.60 |  |  | $ | 3.23 |  |  | $ | 2.21 |  |
| Weighted average number of ordinary shares outstanding(thousands of shares) |  |
| Basic |  |  | 36,836 |  |  |  | 36,828 |  |  |  | 36,798 |  |  |  | 37,257 |  |
| Diluted |  |  | 37,511 |  |  |  | 37,766 |  |  |  | 37,415 |  |  |  | 38,035 |  |

[0001193125-19-224520:8k_2_02:52]
FABRINET

[0001193125-19-224520:8k_2_02:53]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-19-224520:8k_2_02:54]
|  |  | Years Ended |  |
| (in thousands of U. S. dollars) |  | June 28,2019 |  |  | June 29,2018 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 120,955 |  |  | $ | 84,167 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 29,944 |  |  |  | 29,087 |  |
| (Gain) loss on disposal and impairment of property, plant and equipment |  |  | (4 | ) |  |  | 18 |  |
| Loss on disposal of intangibles |  |  | 149 |  |  |  | 447 |  |
| Loss from sales and maturities of available-for-sale securities |  |  | 135 |  |  |  | 364 |  |
| Amortization of investment discount |  |  | (592 | ) |  |  | (506 | ) |
| Amortization of deferred debt issuance costs |  |  | — |  |  |  | 994 |  |
| Allowance for doubtful accounts (reversal) |  |  | 36 |  |  |  | (23 | ) |
| Unrealized (gain) loss on exchange rate and fair value of derivative |  |  | (6,980 | ) |  |  | 4,222 |  |
| Share-based compensation |  |  | 17,157 |  |  |  | 22,581 |  |
| Deferred income tax |  |  | 879 |  |  |  | (2,074 | ) |
| Severance liabilities |  |  | 3,343 |  |  |  | 1,801 |  |
| Other non-cash expenses |  |  | (450 | ) |  |  | 332 |  |
| (Reversal of) Inventory obsolescence |  |  | (563 | ) |  |  | (436 | ) |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | (13,494 | ) |  |  | 17,852 |  |
| Contract assets |  |  | (2,570 | ) |  |  | — |  |
| Inventory |  |  | (44,035 | ) |  |  | (19,432 | ) |
| Other current assets and non-current assets |  |  | (186 | ) |  |  | (4,464 | ) |
| Trade accounts payable |  |  | 38,807 |  |  |  | 3,502 |  |
| Contract liabilities |  |  | 2,239 |  |  |  | — |  |
| Income tax payable |  |  | 1,092 |  |  |  | (1,267 | ) |
| Other current liabilities and non-current liabilities |  |  | 1,532 |  |  |  | 915 |  |
| Net cash provided by operating activities |  |  | 147,394 |  |  |  | 138,080 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of short-term investments |  |  | (233,080 | ) |  |  | (152,908 | ) |
| Proceeds from sales of short-term investments |  |  | 99,142 |  |  |  | 61,795 |  |
| Proceeds from maturities of short-term investments |  |  | 54,215 |  |  |  | 67,417 |  |
| Payments in connection with business acquisition, net of cash acquired |  |  | — |  |  |  | — |  |
| Purchase of property, plant and equipment |  |  | (18,661 | ) |  |  | (33,825 | ) |
| Proceeds from disposal of property, plant and equipment |  |  | 599 |  |  |  | 449 |  |
| Purchase of intangibles |  |  | (282 | ) |  |  | (1,577 | ) |
| Net cash used in investing activities |  |  | (98,067 | ) |  |  | (58,649 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Proceeds of short-term loan from bank |  |  | — |  |  |  | 5,000 |  |
| Repayment of short-term loan from bank |  |  | — |  |  |  | (1,003 | ) |
| Repayment of long-term loan from bank |  |  | (3,250 | ) |  |  | (11,212 | ) |
| Proceeds from issuance of ordinary shares under employee share option plan |  |  | — |  |  |  | 1,436 |  |
| Repayment of capital lease liability |  |  | (468 | ) |  |  | (417 | ) |
| Repurchase of ordinary shares |  |  | (5,378 | ) |  |  | (42,401 | ) |
| Release of restricted cash held in connection with business acquisition |  |  | (3,478 | ) |  |  | — |  |
| Withholding tax related to net share settlement of restricted share units |  |  | (10,649 | ) |  |  | (5,509 | ) |
| Net cash used in financing activities |  |  | (23,223 | ) |  |  | (54,106 | ) |
| Net increase in cash, cash equivalents and restricted cash |  | $ | 26,104 |  |  | $ | 25,325 |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  | $ | 161,433 |  |  | $ | 137,137 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash |  |  | 26,104 |  |  |  | 25,325 |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash |  |  | 704 |  |  |  | (1,029 | ) |
| Cash, cash equivalents and restricted cash at end of period |  | $ | 188,241 |  |  | $ | 161,433 |  |

[0001193125-19-224520:8k_2_02:55]
FABRINET

[0001193125-19-224520:8k_2_02:56]
CONSOLIDATED STATEMENTS OF CASH FLOWS (Continued)

[0001193125-19-224520:8k_2_02:57]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within
the consolidated balance sheets that sum to the total of same amounts shown in the consolidated statements of cash flows:

[0001193125-19-224520:8k_2_02:58]
| (amount in thousands) |  | As ofJune 28,2019 |  |  | As ofJune 29,2018 |  |
| Cash and cash equivalents |  | $ | 180,839 |  |  | $ | 158,102 |  |
| Restricted cash |  |  | 7,402 |  |  |  | 3,331 |  |
| Cash, cash equivalents and restricted cash |  | $ | 188,241 |  |  | $ | 161,433 |  |

[0001193125-19-224520:8k_2_02:59]
FABRINET

[0001193125-19-224520:8k_2_02:60]
RECONCILIATION OF ASC 605 TO ASC 606

[0001193125-19-224520:8k_2_02:61]
|  |  | Three Months EndedJune 28, 2019 |  |
| (in thousands of U.S. dollars, except per share data) |  | As reportedunderASC 606 |  |  | Adjustment |  |  | ASC 605 |  |
| Revenues |  | $ | 405,127 |  |  | $ | (1,894 | ) |  | $ | 403,233 |  |
| Cost of revenues |  |  | (357,144 | ) |  |  | 1,404 |  |  |  | (355,740 | ) |
| Gross profit |  |  | 47,983 |  |  |  | (490 | ) |  |  | 47,493 |  |
| Selling, general and administrative expenses |  |  | (11,267 | ) |  |  | — |  |  |  | (11,267 | ) |
| Operating income |  |  | 36,716 |  |  |  | (490 | ) |  |  | 36,226 |  |
| Interest income |  |  | 1,929 |  |  |  | (10 | ) |  |  | 1,919 |  |
| Interest expense |  |  | (1,708 | ) |  |  | — |  |  |  | (1,708 | ) |
| Foreign exchange gain, net |  |  | 1,814 |  |  |  | — |  |  |  | 1,814 |  |
| Other income, net |  |  | 70 |  |  |  | — |  |  |  | 70 |  |
| Income before income taxes |  |  | 38,821 |  |  |  | (500 | ) |  |  | 38,321 |  |
| Income tax expense |  |  | (1,214 | ) |  |  | — |  |  |  | (1,214 | ) |
| Net income |  |  | 37,607 |  |  |  | (500 | ) |  |  | 37,107 |  |
| Other comprehensive loss, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in net unrealized gain on available-for-sale securities |  |  | 644 |  |  |  | — |  |  |  | 644 |  |
| Change in net unrealized gain on derivative instruments |  |  | 1 |  |  |  | — |  |  |  | 1 |  |
| Change in retirement benefits plan - prior service cost |  |  | (2,537 | ) |  |  | — |  |  |  | (2,537 | ) |
| Change in foreign currency translation adjustment |  |  | (415 | ) |  |  | — |  |  |  | (415 | ) |
| Total other comprehensive loss, net of tax |  |  | (2,307 | ) |  |  | — |  |  |  | (2,307 | ) |
| Net comprehensive income |  | $ | 35,300 |  |  | $ | (500 | ) |  | $ | 34,800 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.02 |  |  | $ | (0.01 | ) |  | $ | 1.01 |  |
| Diluted |  | $ | 1.00 |  |  | $ | (0.01 | ) |  | $ | 0.99 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |
| Basic |  |  | 36,836 |  |  |  | — |  |  |  | 36,836 |  |
| Diluted |  |  | 37,511 |  |  |  | — |  |  |  | 37,511 |  |

[0001193125-19-224520:8k_2_02:62]
FABRINET

[0001193125-19-224520:8k_2_02:63]
RECONCILIATION OF ASC 605 TO ASC 606

[0001193125-19-224520:8k_2_02:64]
|  |  | Twelve Months EndedJune 28, 2019 |  |
| (in thousands of U.S. dollars, except per share data) |  | As reportedunderASC 606 |  |  | Adjustment |  |  | ASC 605 |  |
| Revenues |  | $ | 1,584,055 |  |  | $ | (2,560 | ) |  | $ | 1,581,495 |  |
| Cost of revenues |  |  | (1,398,866 | ) |  |  | 1,745 |  |  |  | (1,397,121 | ) |
| Gross profit |  |  | 185,189 |  |  |  | (815 | ) |  |  | 184,374 |  |
| Selling, general and administrative expenses |  |  | (40,909 | ) |  |  | — |  |  |  | (40,909 | ) |
| Operating income |  |  | 144,280 |  |  |  | (815 | ) |  |  | 143,465 |  |
| Interest income |  |  | 6,699 |  |  |  | (10 | ) |  |  | 6,689 |  |
| Interest expense |  |  | (5,381 | ) |  |  | — |  |  |  | (5,381 | ) |
| Foreign exchange gain, net |  |  | 1,406 |  |  |  | — |  |  |  | 1,406 |  |
| Other income, net |  |  | 868 |  |  |  | — |  |  |  | 868 |  |
| Income before income taxes |  |  | 147,872 |  |  |  | (825 | ) |  |  | 147,047 |  |
| Income tax expense |  |  | (5,278 | ) |  |  | — |  |  |  | (5,278 | ) |
| Net income |  |  | 142,594 |  |  |  | (825 | ) |  |  | 141,769 |  |
| Other comprehensive loss, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in net unrealized gain on available-for-sale securities |  |  | 2,043 |  |  |  | — |  |  |  | 2,043 |  |
| Change in net unrealized loss on derivative instruments |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |
| Change in retirement benefits plan - prior service cost |  |  | (2,537 | ) |  |  | — |  |  |  | (2,537 | ) |
| Change in foreign currency translation adjustment |  |  | (634 | ) |  |  | — |  |  |  | (634 | ) |
| Total other comprehensive loss, net of tax |  |  | (1,129 | ) |  |  | — |  |  |  | (1,129 | ) |
| Net comprehensive income |  | $ | 141,465 |  |  | $ | (825 | ) |  | $ | 140,640 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 3.88 |  |  | $ | (0.03 | ) |  | $ | 3.85 |  |
| Diluted |  | $ | 3.81 |  |  | $ | (0.02 | ) |  | $ | 3.79 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |
| Basic |  |  | 36,798 |  |  |  | — |  |  |  | 36,798 |  |
| Diluted |  |  | 37,415 |  |  |  | — |  |  |  | 37,415 |  |

[0001193125-19-224520:8k_2_02:65]
FABRINET

[0001193125-19-224520:8k_2_02:66]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-19-224520:8k_2_02:67]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | June 28, 2019 |  |  | June 29, 2018 |  |  | June 28, 2019 |  |  | June 29, 2018 |  |
| (in thousands of U.S. dollars, except per share data) |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |
| GAAP measures |  |  | 32,957 |  |  |  | 0.88 |  |  |  | 22,768 |  |  |  | 0.60 |  |  |  | 120,955 |  |  |  | 3.23 |  |  |  | 84,167 |  |  |  | 2.21 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1271 |  |  |  | 0.03 |  |  |  | 1,507 |  |  |  | 0.04 |  |  |  | 5,655 |  |  |  | 0.15 |  |  |  | 6,784 |  |  |  | 0.18 |  |
| Depreciation of fair value uplift |  |  | 86 |  |  |  | 0.00 |  |  |  | 89 |  |  |  | 0.00 |  |  |  | 341 |  |  |  | 0.01 |  |  |  | 330 |  |  |  | 0.01 |  |
| ASC 606 adoption impact on gross profit |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (31 | ) |  |  | (0.00 | ) |  |  | — |  |  |  | — |  |
| Total related to gross profit |  |  | 1,357 |  |  |  | 0.04 |  |  |  | 1,596 |  |  |  | 0.04 |  |  |  | 5,965 |  |  |  | 0.16 |  |  |  | 7,114 |  |  |  | 0.19 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 2,513 |  |  |  | 0.07 |  |  |  | 3,370 |  |  |  | 0.09 |  |  |  | 11,502 |  |  |  | 0.31 |  |  |  | 15,797 |  |  |  | 0.42 |  |
| Expenses related to CFO/CEO search |  |  | (567 | ) |  |  | (0.02 | ) |  |  | — |  |  |  | — |  |  |  | 290 |  |  |  | 0.01 |  |  |  | 204 |  |  |  | 0.01 |  |
| Amortization of intangibles |  |  | 163 |  |  |  | 0.00 |  |  |  | 199 |  |  |  | 0.01 |  |  |  | 694 |  |  |  | 0.02 |  |  |  | 780 |  |  |  | 0.02 |  |
| Business combination expenses and consulting fee |  |  | 224 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 552 |  |  |  | 0.01 |  |  |  | 117 |  |  |  | 0.00 |  |
| Severance payments |  |  | 171 |  |  |  | 0.00 |  |  |  | 2,142 |  |  |  | 0.06 |  |  |  | 1,120 |  |  |  | 0.03 |  |  |  | 2,142 |  |  |  | 0.06 |  |
| Total related to selling, general and administrative expenses |  |  | 2,504 |  |  |  | 0.07 |  |  |  | 5,711 |  |  |  | 0.15 |  |  |  | 14,158 |  |  |  | 0.38 |  |  |  | 19,040 |  |  |  | 0.50 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Expenses related to reduction in workforce |  |  | 789 |  |  |  | 0.02 |  |  |  | — |  |  |  | — |  |  |  | 1,516 |  |  |  | 0.04 |  |  |  | 1,776 |  |  |  | 0.05 |  |
| Amortization of debt issuance costs |  |  | — |  |  |  | — |  |  |  | 634 |  |  |  | 0.02 |  |  |  | — |  |  |  | — |  |  |  | 1,412 |  |  |  | 0.04 |  |
| Total related to other incomes and other expenses |  |  | 789 |  |  |  | 0.02 |  |  |  | 634 |  |  |  | 0.02 |  |  |  | 1,516 |  |  |  | 0.04 |  |  |  | 3,188 |  |  |  | 0.08 |  |
| Total related to net income & EPS |  |  | 4,650 |  |  |  | 0.12 |  |  |  | 7,941 |  |  |  | 0.21 |  |  |  | 21,639 |  |  |  | 0.58 |  |  |  | 29,342 |  |  |  | 0.77 |  |
| Non-GAAP measures |  |  | 37,607 |  |  |  | 1.00 |  |  |  | 30,709 |  |  |  | 0.81 |  |  |  | 142,594 |  |  |  | 3.81 |  |  |  | 113,509 |  |  |  | 2.98 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 37,511 |  |  |  |  |  |  |  | 37,766 |  |  |  |  |  |  |  | 37,415 |  |  |  |  |  |  |  | 38,035 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 37,511 |  |  |  |  |  |  |  | 37,766 |  |  |  |  |  |  |  | 37,415 |  |  |  |  |  |  |  | 38,035 |  |

[0001193125-19-224520:8k_2_02:68]
FABRINET

[0001193125-19-224520:8k_2_02:69]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001193125-19-224520:8k_2_02:70]
| (amount in thousands) |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | June 28,2019 |  |  | June 29,2018 |  |  | June 28,2019 |  |  | June 29,2018 |  |
| Net cash provided by operating activities |  | $ | 41,890 |  |  | $ | 48,286 |  |  | $ | 147,394 |  |  | $ | 138,080 |  |
| Less: Purchase of property, plant and equipment |  |  | (5,450 | ) |  |  | (5,557 | ) |  |  | (18,661 | ) |  |  | (33,825 | ) |
| Non-GAAP free cash flow |  | $ | 36,440 |  |  | $ | 42,729 |  |  | $ | 128,733 |  |  | $ | 104,255 |  |

[0001193125-19-224520:8k_2_02:71]
FABRINET

[0001193125-19-224520:8k_2_02:72]
GUIDANCE FOR QUARTER ENDING SEPTEMBER 27, 2019

[0001193125-19-224520:8k_2_02:73]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-19-224520:8k_2_02:74]
|  |  | DilutedEPS |  |
| GAAP net income per diluted share: |  | $ | 0.64 to $0.68 |  |
| Related to cost of revenues: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.04 |  |
| Total related to gross profit |  |  | 0.04 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.11 |  |
| Business combination expenses |  |  | 0.01 |  |
| Total related to selling, general and administrative expenses |  |  | 0.12 |  |
| Total related to net income & EPS |  |  | 0.16 |  |
| Non-GAAP net income per diluted share |  | $ | 0.80 to $0.84 |  |
