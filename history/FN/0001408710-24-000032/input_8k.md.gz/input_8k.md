# FN 8-K — 0001408710-24-000030 filed 2024-08-19

## item codes, every 8-K on or before 2024-08-20

- 2024-08-19 0001408710-24-000030 — 2.02, 5.02, 9.01
- 2024-06-14 0001408710-24-000023 — 5.02
- 2024-05-06 0001408710-24-000017 — 2.02, 9.01
- 2024-02-05 0001408710-24-000007 — 2.02, 9.01
- 2023-12-13 0001408710-23-000038 — 5.07
- 2023-11-06 0001408710-23-000034 — 2.02, 9.01
- 2023-08-21 0001408710-23-000026 — 2.02, 5.02, 9.01
- 2023-05-08 0001408710-23-000016 — 2.02, 5.02, 9.01
- 2023-02-06 0001408710-23-000006 — 2.02, 9.01
- 2022-12-13 0001408710-22-000062 — 5.07
- 2022-11-07 0001408710-22-000058 — 2.02, 9.01
- 2022-08-15 0001408710-22-000041 — 2.02, 5.02, 9.01
- 2022-05-02 0001408710-22-000026 — 2.02, 9.01
- 2022-01-31 0001408710-22-000016 — 2.02, 9.01
- 2022-01-19 0001408710-22-000010 — 5.02
- 2022-01-06 0001408710-22-000006 — 5.02
- 2021-12-10 0001408710-21-000051 — 5.07
- 2021-11-01 0001408710-21-000045 — 2.02, 9.01
- 2021-08-16 0001408710-21-000031 — 2.02, 5.02, 9.01
- 2021-05-03 0001408710-21-000019 — 2.02, 9.01
- 2021-02-01 0001408710-21-000008 — 2.02, 9.01
- 2020-12-11 0001193125-20-315861 — 5.07
- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2024-08-20

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001408710-24-000030:8k_2_02:1]
EX-99.1
2
fn-20240819xex991q424.htm
EX-99.1

[0001408710-24-000030:8k_2_02:2]
Document

[0001408710-24-000030:8k_2_02:3]
Exhibit 99.1

[0001408710-24-000030:8k_2_02:4]
Fabrinet Announces Fourth Quarter and Fiscal Year 2024 Financial Results

[0001408710-24-000030:8k_2_02:5]
•Record Fourth Quarter Revenue and Earnings Per Share Exceed Guidance

[0001408710-24-000030:8k_2_02:6]
BANGKOK, Thailand – August 19, 2024 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its fourth quarter and fiscal year ended June 28, 2024.

[0001408710-24-000030:8k_2_02:7]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “Our strong fourth quarter results capped a remarkable fiscal year, representing our fourth quarter in a row of record revenue, and record earnings per share, both of which were above our guidance ranges. We remain optimistic about our future, with numerous drivers that position us to extend our track record of success into fiscal year 2025.”

[0001408710-24-000030:8k_2_02:8]
Fourth Quarter Fiscal Year 2024 Financial Highlights

[0001408710-24-000030:8k_2_02:9]
GAAP Results

[0001408710-24-000030:8k_2_02:10]
•Revenue for the fourth quarter of fiscal year 2024 was $753.3 million, compared to $655.9 million for the fourth quarter of fiscal year 2023.

[0001408710-24-000030:8k_2_02:11]
•GAAP net income for the fourth quarter of fiscal year 2024 was $81.1 million, compared to $60.8 million for the fourth quarter of fiscal year 2023.

[0001408710-24-000030:8k_2_02:12]
•GAAP net income per diluted share for the fourth quarter of fiscal year 2024 was $2.22, compared to $1.65 for the fourth quarter of fiscal year 2023.

[0001408710-24-000030:8k_2_02:13]
Non-GAAP Results

[0001408710-24-000030:8k_2_02:14]
•Non-GAAP net income for the fourth quarter of fiscal year 2024 was $88.0 million, compared to $68.4 million for the fourth quarter of fiscal year 2023.

[0001408710-24-000030:8k_2_02:15]
•Non-GAAP net income per diluted share for the fourth quarter of fiscal year 2024 was $2.41, compared to $1.86 for the fourth quarter of fiscal year 2023.

[0001408710-24-000030:8k_2_02:16]
Fiscal Year 2024 Financial Highlights

[0001408710-24-000030:8k_2_02:17]
GAAP Results

[0001408710-24-000030:8k_2_02:18]
•Revenue for fiscal year 2024 was $2.88 billion, compared to $2.65 billion for fiscal year 2023.

[0001408710-24-000030:8k_2_02:19]
•GAAP net income for fiscal year 2024 was $296.2 million, compared to $247.9 million for fiscal year 2023.

[0001408710-24-000030:8k_2_02:20]
•GAAP net income per diluted share for fiscal year 2024 was $8.10, compared to $6.73 for fiscal year 2023.

[0001408710-24-000030:8k_2_02:21]
Non-GAAP Results

[0001408710-24-000030:8k_2_02:22]
•Non-GAAP net income for fiscal year 2024 was $324.6 million, compared to $282.7 million for fiscal year 2023.

[0001408710-24-000030:8k_2_02:23]
•Non-GAAP net income per diluted share for fiscal year 2024 was $8.88, compared to $7.67 for fiscal year 2023.

[0001408710-24-000030:8k_2_02:24]
Share Repurchase Program Expanded

[0001408710-24-000030:8k_2_02:25]
Fabrinet also announced that its Board of Directors has approved an expansion of its share repurchase program, authorizing the repurchase of up to an additional $139.5 million of Fabrinet’s ordinary shares. The addition brings the aggregate authorization under Fabrinet’s existing share repurchase program to $434.3 million, with $200.0 million currently remaining.

[0001408710-24-000030:8k_2_02:26]
Business Outlook

[0001408710-24-000030:8k_2_02:27]
Based on information available as of August 19, 2024, Fabrinet is issuing guidance for its first fiscal quarter ending September 27, 2024, as follows:

[0001408710-24-000030:8k_2_02:28]
•Fabrinet expects first quarter revenue to be in the range of $760 million to $780 million.

[0001408710-24-000030:8k_2_02:29]
•GAAP net income per diluted share is expected to be in the range of $2.10 to $2.17, based on approximately 36.5 million fully diluted shares outstanding.

[0001408710-24-000030:8k_2_02:30]
•Non-GAAP net income per diluted share is expected to be in the range of $2.33 to $2.40, based on approximately 36.5 million fully diluted shares outstanding.

[0001408710-24-000030:8k_2_02:31]
Guidance for non-GAAP net income per diluted share excludes share-based compensation expenses and certain non-recurring items. A reconciliation of non-GAAP net income per diluted share to the corresponding GAAP measure is available at the end of this press release.

[0001408710-24-000030:8k_2_02:32]
Conference Call Information

[0001408710-24-000030:8k_2_02:33]
| What: |  | Fabrinet Fourth Quarter Fiscal Year 2024 Financial Results Call |
| When: |  | August 19, 2024 |
| Time: |  | 5:00 p.m. ET |
| Live Call and Replay: |  | https://investor.fabrinet.com/events-and-presentations/events |

[0001408710-24-000030:8k_2_02:34]
A recorded version of this webcast will be available approximately two hours after the call and accessible at http://investor.fabrinet.com. The webcast will be archived on Fabrinet’s website for a period of one year.

[0001408710-24-000030:8k_2_02:35]
About Fabrinet

[0001408710-24-000030:8k_2_02:36]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China, and Israel. For more information visit: www.fabrinet.com.

[0001408710-24-000030:8k_2_02:37]
Forward-Looking Statements

[0001408710-24-000030:8k_2_02:38]
Non-GAAP Financial Measures

[0001408710-24-000030:8k_2_02:39]
In addition to reporting financial results in accordance with GAAP, we provide investors with certain non-GAAP financial measures. These non-GAAP financial measures are in addition to, and not a substitute for or superior to, measures of financial performance prepared in accordance with GAAP. We believe these non-GAAP financial measures provide investors with useful supplemental information to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, we use some of these non-GAAP financial measures to measure company performance for the purposes of determining employee incentive plan compensation.

[0001408710-24-000030:8k_2_02:40]
Non-GAAP gross profit, non-GAAP operating profit, non-GAAP net income and non-GAAP net income per diluted share exclude: share-based compensation expenses; amortization of intangibles; and amortization of deferred debt issuance costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations.

[0001408710-24-000030:8k_2_02:41]
Non-GAAP free cash flow is net cash provided by (used in) operating activities, minus capital expenditures (purchase of property, plant and equipment). We use free cash flow to measure our ability to generate additional cash from our business operations.

[0001408710-24-000030:8k_2_02:42]
There are a number of limitations related to the use of these non-GAAP financial measures versus their nearest GAAP equivalents. For example, other companies may calculate non-GAAP financial measures differently or may use other measures to evaluate their performance, all of which could reduce the usefulness of our non-GAAP financial measures as tools for comparison. We urge you to review the reconciliations of our non-GAAP financial measures to the most directly comparable GAAP financial measures, and not to rely on any single financial measure to evaluate our business.

[0001408710-24-000030:8k_2_02:43]
Investor Contact:

[0001408710-24-000030:8k_2_02:44]
Garo Toomajanian

[0001408710-24-000030:8k_2_02:45]
ir@fabrinet.com

[0001408710-24-000030:8k_2_02:46]
FABRINET

[0001408710-24-000030:8k_2_02:47]
CONSOLIDATED BALANCE SHEETS

[0001408710-24-000030:8k_2_02:48]
| (in thousands of U.S. dollars, except share data and par value) | June 28,2024 |  | June 30,2023 |
|  | (unaudited) |  |  |
| Assets |  |  |  |
| Current assets |  |  |  |
| Cash and cash equivalents | $ | 409,973 |  |  | $ | 231,368 |  |
| Short-term investments | 448,630 |  |  | 319,100 |  |
| Trade accounts receivable, net of allowance for expected credit losses of $1,629 and $965, respectively | 592,452 |  |  | 531,767 |  |
| Inventories | 463,206 |  |  | 519,576 |  |
| Prepaid expenses | 10,620 |  |  | 7,849 |  |
| Other current assets | 87,810 |  |  | 42,880 |  |
| Total current assets | 2,012,691 |  |  | 1,652,540 |  |
| Non-current assets |  |  |  |
| Property, plant and equipment, net | 307,240 |  |  | 310,350 |  |
| Intangibles, net | 2,321 |  |  | 2,394 |  |
| Operating right-of-use assets | 5,336 |  |  | 1,634 |  |
| Deferred tax assets | 10,446 |  |  | 12,095 |  |
| Other non-current assets | 485 |  |  | 635 |  |
| Total non-current assets | 325,828 |  |  | 327,108 |  |
| Total Assets | $ | 2,338,519 |  |  | $ | 1,979,648 |  |
| Liabilities and Shareholders’ Equity |  |  |  |
| Current liabilities |  |  |  |
| Long-term borrowings, current portion, net | $ | — |  |  | $ | 12,156 |  |
| Trade accounts payable | 441,835 |  |  | 381,129 |  |
| Fixed assets payable | 14,380 |  |  | 13,526 |  |
| Operating lease liabilities, current portion | 1,355 |  |  | 1,201 |  |
| Income tax payable | 3,937 |  |  | 6,024 |  |
| Accrued payroll, bonus and related expenses | 22,116 |  |  | 23,748 |  |
| Accrued expenses | 19,916 |  |  | 20,447 |  |
| Other payables | 54,403 |  |  | 23,654 |  |
| Total current liabilities | 557,942 |  |  | 481,885 |  |
| Non-current liabilities |  |  |  |
| Deferred tax liability | 4,895 |  |  | 4,799 |  |
| Operating lease liabilities, non-current portion | 3,635 |  |  | 66 |  |
| Severance liabilities | 24,093 |  |  | 22,159 |  |
| Other non-current liabilities | 2,209 |  |  | 2,081 |  |
| Total non-current liabilities | 34,832 |  |  | 29,105 |  |
| Total Liabilities | 592,774 |  |  | 510,990 |  |
| Shareholders’ equity |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of June 28, 2024 and June 30, 2023) | — |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 39,457,462 shares and 39,284,176 shares issued as of June 28, 2024 and June 30, 2023, respectively; and 36,145,242 shares and 36,183,682 shares outstanding as of June 28, 2024 and June 30, 2023, respectively) | 395 |  |  | 393 |  |
| Additional paid-in capital | 222,044 |  |  | 206,624 |  |
| Less: Treasury shares (3,312,220 shares and 3,100,494 shares as of June 28, 2024 and June 30, 2023, respectively) | (234,323) |  |  | (194,833) |  |
| Accumulated other comprehensive income (loss) | (3,141) |  |  | (8,115) |  |
| Retained earnings | 1,760,770 |  |  | 1,464,589 |  |
| Total Shareholders’ Equity | 1,745,745 |  |  | 1,468,658 |  |
| Total Liabilities and Shareholders’ Equity | $ | 2,338,519 |  |  | $ | 1,979,648 |  |

[0001408710-24-000030:8k_2_02:49]
FABRINET

[0001408710-24-000030:8k_2_02:50]
CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME

[0001408710-24-000030:8k_2_02:51]
|  | Three Months Ended |  | Year Ended |
| (in thousands of U.S. dollars, except per share data) | June 28,2024 |  | June 30,2023 |  | June 28,2024 |  | June 30,2023 |
|  | (unaudited) |  | (unaudited) |  | (unaudited) |  |  |
| Revenues | $ | 753,261 |  |  | $ | 655,871 |  |  | $ | 2,882,967 |  |  | $ | 2,645,237 |  |
| Cost of revenues | (660,812) |  |  | (573,576) |  |  | (2,526,849) |  |  | (2,308,964) |  |
| Gross profit | 92,449 |  |  | 82,295 |  |  | 356,118 |  |  | 336,273 |  |
| Selling, general and administrative expenses | (19,108) |  |  | (19,869) |  |  | (78,481) |  |  | (77,673) |  |
| Restructuring and other related costs | (32) |  |  | (1,024) |  |  | (32) |  |  | (6,896) |  |
| Operating income | 73,309 |  |  | 61,402 |  |  | 277,605 |  |  | 251,704 |  |
| Interest income | 11,049 |  |  | 4,024 |  |  | 33,204 |  |  | 11,234 |  |
| Interest expense | (17) |  |  | (293) |  |  | (124) |  |  | (1,472) |  |
| Foreign exchange gain (loss), net | 407 |  |  | 1,911 |  |  | 382 |  |  | (1,211) |  |
| Other income (expense), net | 227 |  |  | 19 |  |  | 287 |  |  | (159) |  |
| Income before income taxes | 84,975 |  |  | 67,063 |  |  | 311,354 |  |  | 260,096 |  |
| Income tax expense | (3,909) |  |  | (6,277) |  |  | (15,173) |  |  | (12,183) |  |
| Net income | 81,066 |  |  | 60,786 |  |  | 296,181 |  |  | 247,913 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities | (55) |  |  | 971 |  |  | 2,100 |  |  | 2,739 |  |
| Change in net unrealized gain (loss) on derivative instruments | 1,499 |  |  | (2,894) |  |  | 2,561 |  |  | 1,541 |  |
| Change in net retirement benefits plan – prior service cost | 59 |  |  | 135 |  |  | 330 |  |  | 473 |  |
| Change in foreign currency translation adjustment | 14 |  |  | (46) |  |  | (17) |  |  | (75) |  |
| Total other comprehensive income (loss), net of tax | 1,517 |  |  | (1,834) |  |  | 4,974 |  |  | 4,678 |  |
| Net comprehensive income | $ | 82,583 |  |  | $ | 58,952 |  |  | $ | 301,155 |  |  | $ | 252,591 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 2.24 |  |  | $ | 1.67 |  |  | $ | 8.17 |  |  | $ | 6.79 |  |
| Diluted | $ | 2.22 |  |  | $ | 1.65 |  |  | $ | 8.10 |  |  | $ | 6.73 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |
| Basic | 36,150 |  |  | 36,337 |  |  | 36,246 |  |  | 36,515 |  |
| Diluted | 36,533 |  |  | 36,737 |  |  | 36,564 |  |  | 36,855 |  |

[0001408710-24-000030:8k_2_02:52]
FABRINET

[0001408710-24-000030:8k_2_02:53]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001408710-24-000030:8k_2_02:54]
|  | Year Ended |
| (in thousands of U.S. dollars) | June 28,2024 |  | June 30,2023 |
|  | (unaudited) |  |  |
| Cash flows from operating activities |  |  |  |
| Net income | $ | 296,181 |  |  | $ | 247,913 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 49,017 |  |  | 43,832 |  |
| Non-cash restructuring charges and other related costs | — |  |  | 2,201 |  |
| (Gain) loss on disposal and impairment of property, plant and equipment | 62 |  |  | (1,506) |  |
| (Gain) loss from sales and maturities of available-for-sale securities | (1) |  |  | 92 |  |
| Amortization of discount (premium) of short-term investments | (3,399) |  |  | 280 |  |
| (Reversal of) allowance for expected credit losses | 664 |  |  | (307) |  |
| Unrealized loss (gain) on exchange rate and fair value of foreign currency forward contracts | (849) |  |  | 175 |  |
| Amortization of fair value at hedge inception of interest rate swaps | (220) |  |  | (587) |  |
| Share-based compensation | 28,374 |  |  | 28,127 |  |
| Deferred income tax | 1,672 |  |  | (3,484) |  |
| Other non-cash expenses | 311 |  |  | 632 |  |
| Changes in operating assets and liabilities |  |  |  |
| Trade accounts receivable | (61,279) |  |  | (76,917) |  |
| Inventories | 56,370 |  |  | 37,449 |  |
| Other current assets and non-current assets | (46,715) |  |  | (13,568) |  |
| Trade accounts payable | 60,040 |  |  | (58,596) |  |
| Income tax payable | (1,960) |  |  | 2,977 |  |
| Severance liabilities | 2,771 |  |  | 3,753 |  |
| Other current liabilities and non-current liabilities | 32,107 |  |  | 844 |  |
| Net cash provided by operating activities | 413,146 |  |  | 213,310 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of short-term investments | (435,905) |  |  | (217,005) |  |
| Proceeds from sales of short-term investments | 40,000 |  |  | 30,179 |  |
| Proceeds from maturities of short-term investments | 271,877 |  |  | 150,252 |  |
| Purchase of property, plant and equipment | (47,528) |  |  | (61,360) |  |
| Purchase of intangibles | (889) |  |  | (911) |  |
| Proceeds from disposal of property, plant and equipment | 2,694 |  |  | 128 |  |
| Net cash used in investing activities | (169,751) |  |  | (98,717) |  |
| Cash flows from financing activities |  |  |  |
| Repayment of long-term borrowings | (12,188) |  |  | (15,233) |  |
| Repayment of finance lease liability | — |  |  | (9) |  |
| Repurchase of ordinary shares | (39,490) |  |  | (47,575) |  |
| Withholding tax related to net share settlement of restricted share units | (13,175) |  |  | (18,167) |  |
| Net cash used in financing activities | (64,853) |  |  | (80,984) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | 178,542 |  |  | $ | 33,609 |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at the beginning of period | $ | 231,368 |  |  | $ | 198,365 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | 178,542 |  |  | 33,609 |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash | 63 |  |  | (606) |  |
| Cash, cash equivalents and restricted cash at the end of period | $ | 409,973 |  |  | $ | 231,368 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment related payables | $ | 14,380 |  |  | $ | 13,526 |  |

[0001408710-24-000030:8k_2_02:55]
FABRINET

[0001408710-24-000030:8k_2_02:56]
CONSOLIDATED STATEMENTS OF CASH FLOWS (Continued)

[0001408710-24-000030:8k_2_02:57]
| Supplemental disclosures | Year Ended |
| (in thousands of U.S. dollars) | June 28,2024 |  | June 30,2023 |
|  | (unaudited) |  |  |
| Cash paid for |  |  |  |
| Interest | $ | 312 |  |  | $ | 2,377 |  |
| Taxes | $ | 16,452 |  |  | $ | 14,158 |  |
| Cash received for interest | $ | 29,783 |  |  | $ | 11,048 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment related payables | $ | 14,380 |  |  | $ | 13,526 |  |

[0001408710-24-000030:8k_2_02:58]
FABRINET

[0001408710-24-000030:8k_2_02:59]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES (UNAUDITED)

[0001408710-24-000030:8k_2_02:60]
Reconciliation of GAAP Gross Profit and GAAP Gross Margin to Non-GAAP Gross Profit and Non-GAAP Gross Margin

[0001408710-24-000030:8k_2_02:61]
|  | Three Months Ended |  | Year Ended |
| (in thousands of U.S. dollars, except share data) | June 28,2024 |  | June 30,2023 |  | June 28,2024 |  | June 30,2023 |
| Revenues | $ | 753,261 |  |  |  |  | $ | 655,871 |  |  |  |  | $ | 2,882,967 |  |  |  |  | $ | 2,645,237 |  |  |  |
| Gross profit (GAAP) | $ | 92,449 |  |  | 12.3 | % |  | $ | 82,295 |  |  | 12.5 | % |  | $ | 356,118 |  |  | 12.4 | % |  | $ | 336,273 |  |  | 12.7 | % |
| Share-based compensation expenses | 1,776 |  |  |  |  | 1,636 |  |  |  |  | 7,203 |  |  |  |  | 6,664 |  |  |  |
| Gross profit (Non-GAAP) | $ | 94,225 |  |  | 12.5 | % |  | $ | 83,931 |  |  | 12.8 | % |  | $ | 363,321 |  |  | 12.6 | % |  | $ | 342,937 |  |  | 13.0 | % |

[0001408710-24-000030:8k_2_02:62]
Reconciliation of GAAP Operating Profit and GAAP Operating Margin to Non-GAAP Operating Profit and Non-GAAP Operating Margin

[0001408710-24-000030:8k_2_02:63]
|  | Three Months Ended |  | Year Ended |
| (in thousands of U.S. dollars, except share data) | June 28,2024 |  | June 30,2023 |  | June 28,2024 |  | June 30,2023 |
| Revenues | $ | 753,261 |  |  |  |  | $ | 655,871 |  |  |  |  | $ | 2,882,967 |  |  |  |  | $ | 2,645,237 |  |  |  |
| Operating profit (GAAP) | $ | 73,309 |  |  | 9.7 | % |  | $ | 61,402 |  |  | 9.4 | % |  | $ | 277,605 |  |  | 9.6 | % |  | $ | 251,704 |  |  | 9.5 | % |
| Share-based compensation expenses | 6,934 |  |  |  |  | 6,572 |  |  |  |  | 28,374 |  |  |  |  | 27,603 |  |  |  |
| Restructuring and other related costs | 32 |  |  |  |  | 1,024 |  |  |  |  | 32 |  |  |  |  | 6,896 |  |  |  |
| Amortization of intangibles | — |  |  |  |  | — |  |  |  |  | — |  |  |  |  | 224 |  |  |  |
| Operating profit (Non-GAAP) | $ | 80,275 |  |  | 10.7 | % |  | $ | 68,998 |  |  | 10.5 | % |  | $ | 306,011 |  |  | 10.6 | % |  | $ | 286,427 |  |  | 10.8 | % |

[0001408710-24-000030:8k_2_02:64]
FABRINET

[0001408710-24-000030:8k_2_02:65]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES (UNAUDITED)

[0001408710-24-000030:8k_2_02:66]
Reconciliation of GAAP Net Income and EPS to Non-GAAP Net Income and EPS

[0001408710-24-000030:8k_2_02:67]
|  | Three Months Ended |  | Year Ended |
|  | June 28,2024 |  | June 30,2023 |  | June 28,2024 |  | June 30,2023 |
| (in thousands of U.S. dollars, except share data) | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |
| GAAP measures | $ | 81,066 |  |  | $ | 2.22 |  |  | $ | 60,786 |  |  | $ | 1.65 |  |  | $ | 296,181 |  |  | $ | 8.10 |  |  | $ | 247,913 |  |  | $ | 6.73 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 1,776 |  |  | 0.05 |  |  | 1,636 |  |  | 0.05 |  |  | 7,203 |  |  | 0.20 |  |  | 6,664 |  |  | 0.18 |  |
| Total related to gross profit | 1,776 |  |  | 0.05 |  |  | 1,636 |  |  | 0.05 |  |  | 7,203 |  |  | 0.20 |  |  | 6,664 |  |  | 0.18 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 5,158 |  |  | 0.14 |  |  | 4,936 |  |  | 0.13 |  |  | 21,171 |  |  | 0.58 |  |  | 20,939 |  |  | 0.57 |  |
| Amortization of intangibles | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 224 |  |  | 0.01 |  |
| Total related to selling, general and administrative expenses | 5,158 |  |  | 0.14 |  |  | 4,936 |  |  | 0.13 |  |  | 21,171 |  |  | 0.58 |  |  | 21,163 |  |  | 0.58 |  |
| Related to other income and expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other related costs | 32 |  |  | 0.00 |  |  | 1,024 |  |  | 0.03 |  |  | 32 |  |  | 0.00 |  |  | 6,896 |  |  | 0.18 |  |
| Amortization of deferred debt issuance costs | 8 |  |  | 0.00 |  |  | 8 |  |  | 0.00 |  |  | 32 |  |  | 0.00 |  |  | 32 |  |  | 0.00 |  |
| Total related to other income and expense | 40 |  |  | 0.00 |  |  | 1,032 |  |  | 0.03 |  |  | 64 |  |  | 0.00 |  |  | 6,928 |  |  | 0.18 |  |
| Total related to net income & EPS | 6,974 |  |  | 0.19 |  |  | 7,604 |  |  | 0.21 |  |  | 28,438 |  |  | 0.78 |  |  | 34,755 |  |  | 0.94 |  |
| Non-GAAP measures | $ | 88,040 |  |  | $ | 2.41 |  |  | $ | 68,390 |  |  | $ | 1.86 |  |  | $ | 324,619 |  |  | $ | 8.88 |  |  | $ | 282,668 |  |  | $ | 7.67 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  | 36,533 |  |  |  |  | 36,737 |  |  |  |  | 36,564 |  |  |  |  | 36,855 |  |
| Non-GAAP diluted shares |  |  | 36,533 |  |  |  |  | 36,737 |  |  |  |  | 36,564 |  |  |  |  | 36,855 |  |

[0001408710-24-000030:8k_2_02:68]
FABRINET

[0001408710-24-000030:8k_2_02:69]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW (UNAUDITED)

[0001408710-24-000030:8k_2_02:70]
| (in thousands of U.S. dollars) |  | Three Months Ended |  | Year Ended |
|  |  | June 28,2024 |  | June 30,2023 |  | June 28,2024 |  | June 30,2023 |
| Net cash provided by operating activities |  | $ | 83,062 |  |  | $ | 71,088 |  |  | $ | 413,146 |  |  | $ | 213,310 |  |
| Less: Purchase of property, plant and equipment |  | (12,703) |  |  | (17,938) |  |  | (47,528) |  |  | (61,360) |  |
| Non-GAAP free cash flow |  | $ | 70,359 |  |  | $ | 53,150 |  |  | $ | 365,618 |  |  | $ | 151,950 |  |

[0001408710-24-000030:8k_2_02:71]
FABRINET

[0001408710-24-000030:8k_2_02:72]
GUIDANCE FOR QUARTER ENDING SEPTEMBER 27, 2024

[0001408710-24-000030:8k_2_02:73]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-24-000030:8k_2_02:74]
|  | DilutedEPS |
| GAAP net income per diluted share: | $2.10 to $2.17 |
| Related to cost of revenues: |  |
| Share-based compensation expenses | 0.07 |
| Total related to gross profit | 0.07 |
| Related to selling, general and administrative expenses: |  |
| Share-based compensation expenses | 0.15 |
| Severance payment and others | 0.01 |
| Total related to selling, general and administrative expenses | 0.16 |
| Total related to net income & EPS | 0.23 |
| Non-GAAP net income per diluted share | $2.33 to $2.40 |

## item 5.02 — body, verbatim

[0001408710-24-000030:8k_body:1]
Item 5.02    Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001408710-24-000030:8k_body:2]
Fiscal 2025 Executive Incentive Plan

[0001408710-24-000030:8k_body:3]
On August 13, 2024, the Compensation Committee (the “Compensation Committee”) of the board of directors of Fabrinet adopted an executive incentive plan (the “Cash Bonus Plan”) for the Company’s fiscal year ending June 27, 2025 (“fiscal 2025”). The Cash Bonus Plan is an incentive program designed to motivate participants to achieve the Company’s financial objectives, and to reward them for their achievements when those objectives are met. All of the Company’s executive officers pursuant to Section 16 of the Exchange Act are eligible to participate in the Cash Bonus Plan (individually, a “Participant,” and collectively, the “Participants”). The Cash Bonus Plan provides for target and maximum bonus amounts as set forth in the table below. The maximum bonus that a Participant may receive under the Cash Bonus Plan is 120% of such Participant’s target bonus.

[0001408710-24-000030:8k_body:4]
Name

[0001408710-24-000030:8k_body:5]
Fiscal 2025 Target Bonus

[0001408710-24-000030:8k_body:6]
Fiscal 2025 Maximum Bonus

[0001408710-24-000030:8k_body:7]
Seamus Grady

[0001408710-24-000030:8k_body:8]
$1,890,000

[0001408710-24-000030:8k_body:9]
$2,268,000

[0001408710-24-000030:8k_body:10]
Dr. Harpal Gill

[0001408710-24-000030:8k_body:11]
$1,430,000

[0001408710-24-000030:8k_body:12]
$1,716,000

[0001408710-24-000030:8k_body:13]
Csaba Sverha

[0001408710-24-000030:8k_body:14]
$625,000

[0001408710-24-000030:8k_body:15]
$750,000

[0001408710-24-000030:8k_body:16]
Edward Archer

[0001408710-24-000030:8k_body:17]
$442,000

[0001408710-24-000030:8k_body:18]
$530,400

[0001408710-24-000030:8k_body:19]
The amount of bonus actually paid to a Participant under the Cash Bonus Plan will be based 50% on the extent of achievement of a fiscal 2025 revenue metric and 50% on the extent of achievement of a fiscal 2025 non-GAAP operating margin metric. As achievement of each financial metric is considered independently from the other, the Company must meet a threshold for each metric in order for a Participant to receive any credit for that metric. If the Company achieves 100% of a target financial metric, bonuses would be paid out at 100% of the target amount with respect to that financial metric component. If the Company achieves 105% or more of a target financial metric, bonuses would be paid out at 120% of the target amount (which is the maximum) with respect to that financial metric component. Achievement of the revenue or non-GAAP operating margin metric for fiscal 2025 at a level between 100% and 105% of the target metric will result in a bonus amount for the applicable metric that is scaled from 100% to 120% of the target amount in a linear fashion. Achievement of the revenue or non-GAAP operating margin metric for fiscal 2025 at a level between 90% and 100% of the target metric will result in a bonus amount for the applicable metric that is scaled from 20% to 100% of the target amount in a linear fashion.

[0001408710-24-000030:8k_body:20]
Fiscal 2025 Salaries

[0001408710-24-000030:8k_body:21]
On August 13, 2024, the Compensation Committee approved an increase to the annual base salaries of the Company’s named executive officers set forth below, effective as of June 29, 2024, the first day of fiscal 2025.

[0001408710-24-000030:8k_body:22]
Name

[0001408710-24-000030:8k_body:23]
Title

[0001408710-24-000030:8k_body:24]
Previous Annual Base Salary

[0001408710-24-000030:8k_body:25]
Fiscal 2025 Annual Base Salary

[0001408710-24-000030:8k_body:26]
Change

[0001408710-24-000030:8k_body:27]
Seamus Grady

[0001408710-24-000030:8k_body:28]
Chief Executive Officer

[0001408710-24-000030:8k_body:29]
$1,250,000

[0001408710-24-000030:8k_body:30]
$1,350,000

[0001408710-24-000030:8k_body:31]
8.0%

[0001408710-24-000030:8k_body:32]
Dr. Harpal Gill

[0001408710-24-000030:8k_body:33]
President and Chief Operating Officer

[0001408710-24-000030:8k_body:34]
$1,060,000

[0001408710-24-000030:8k_body:35]
$1,100,000

[0001408710-24-000030:8k_body:36]
3.8%

[0001408710-24-000030:8k_body:37]
Csaba Sverha

[0001408710-24-000030:8k_body:38]
Executive Vice President, Chief Financial Officer

[0001408710-24-000030:8k_body:39]
$590,000

[0001408710-24-000030:8k_body:40]
$625,000

[0001408710-24-000030:8k_body:41]
5.9%

[0001408710-24-000030:8k_body:42]
Edward Archer

[0001408710-24-000030:8k_body:43]
Executive Vice President, Sales & Marketing

[0001408710-24-000030:8k_body:44]
$510,000

[0001408710-24-000030:8k_body:45]
$520,000

[0001408710-24-000030:8k_body:46]
2.0%

[0001408710-24-000030:8k_body:47]
Equity Award Grants

[0001408710-24-000030:8k_body:48]
On August 13, 2024, the Compensation Committee approved the grant, effective as of August 22, 2024 (the “Grant Date”), of the following dollar values of restricted share units (“RSUs”), performance share units (“PSUs”) and “stretch” PSUs (“Stretch PSUs”), rounded up to the nearest whole share, to the Company’s named executive officers as a component of their fiscal 2025 compensation:

[0001408710-24-000030:8k_body:49]
Name

[0001408710-24-000030:8k_body:50]
Grant Date Value of RSUs

[0001408710-24-000030:8k_body:51]
Grant Date Value of PSUs

[0001408710-24-000030:8k_body:52]
Grant Date Value of “Stretch” PSUs

[0001408710-24-000030:8k_body:53]
Seamus Grady

[0001408710-24-000030:8k_body:54]
$2,650,000

[0001408710-24-000030:8k_body:55]
$2,650,000

[0001408710-24-000030:8k_body:56]
$2,650,000

[0001408710-24-000030:8k_body:57]
Dr. Harpal Gill

[0001408710-24-000030:8k_body:58]
$1,700,000

[0001408710-24-000030:8k_body:59]
$1,700,000

[0001408710-24-000030:8k_body:60]
$1,700,000

[0001408710-24-000030:8k_body:61]
Csaba Sverha

[0001408710-24-000030:8k_body:62]
$1,000,000

[0001408710-24-000030:8k_body:63]
$1,000,000

[0001408710-24-000030:8k_body:64]
$1,000,000

[0001408710-24-000030:8k_body:65]
Edward Archer

[0001408710-24-000030:8k_body:66]
$800,000

[0001408710-24-000030:8k_body:67]
$800,000

[0001408710-24-000030:8k_body:68]
$800,000

[0001408710-24-000030:8k_body:69]
The grants will be made under the Company’s 2020 Equity Incentive Plan. The RSUs will be scheduled to vest in equal annual installments over a period of three years on each anniversary of the Grant Date, subject to the individual’s continued service with the Company through each such vesting date.

[0001408710-24-000030:8k_body:70]
The PSUs will vest, if at all, following a 2-year performance period, on the date the Compensation Committee certifies achievement of the performance criteria set forth below, subject to the individual’s continued service with the Company through such vesting date. Vesting of the PSUs will be based 50% on achievement of a cumulative fiscal 2025 and fiscal 2026 revenue goal (the “PSU Revenue Target”) and 50% on achievement of a cumulative fiscal 2025 and fiscal 2026 non-GAAP operating margin goal (the “PSU Operating Margin Target”). As achievement of each financial goal is considered independently from the other, the Company must meet a threshold for each goal in order for an individual to receive any credit for that goal. If the Company achieves 100% or more of a target financial goal, the PSUs will vest as to 100% of the PSUs allocated to that financial goal. Achievement of the PSU Revenue Target or the PSU Operating Margin Target at a level between 90% and 100% will result in a number of shares vesting for the applicable goal that is scaled from 20% to 100% of the PSUs allocated to that goal in a linear fashion.

[0001408710-24-000030:8k_body:71]
The Stretch PSUs will vest, if at all, following a 2-year performance period, on the date the Compensation Committee certifies achievement of the performance criteria set forth below, subject to the individual’s continued service with the Company through such vesting date. Vesting of the Stretch PSUs will be based 50% on achievement of a cumulative fiscal 2025 and fiscal 2026 revenue goal that is 5% higher than the PSU Revenue Target (the “Stretch PSU Revenue Target”) and 50% on achievement of a cumulative fiscal 2025 and fiscal 2026 non-GAAP operating margin goal that is 5% higher than the PSU Operating Margin Target (the “Stretch PSU Operating Margin Target”). As achievement of each financial goal is considered independently from the other, the Company must meet a threshold for each goal in order for an individual to receive any credit for that goal. The Company must exceed the PSU Revenue Target or the PSU Operating Margin Target in order for any of the Stretch PSUs to vest. If the Company achieves 100% or more of a target financial goal, the Stretch PSUs will vest as to 100% of the PSUs allocated to that financial goal. Achievement of the Stretch PSU Revenue Target at a level between its threshold PSU Revenue Target and 100% will result in a number of shares vesting for that goal that is scaled from 0% to 100% of the PSUs allocated to that goal in a linear fashion. Achievement of the Stretch PSU Operating Margin Target at a level between its threshold PSU Operating Margin Target and 100% will result in a number of shares vesting for that goal that is scaled from 0% to 100% of the PSUs allocated to that goal in a linear fashion.

[0001408710-24-000030:8k_body:72]
In the event of a change in control of Fabrinet, the awards of PSUs and Stretch PSUs described above that are then outstanding will be treated as follows. To the extent that the performance period has not yet been completed as of the change in control, (1) the performance period for any Company revenue goals will be shortened to end shortly before the change in control and achievement of revenue will be measured based on goals that are prorated for the shortened performance period, and (2) the performance period for any Company operating margin goals will be deemed to be the last four consecutive fiscal quarters of the Company completed before the change in control. Any PSUs for which such applicable goal is deemed achieved will be scheduled to vest subject to the individual’s continued service with Fabrinet through the last date of the award’s original performance period, and will be treated as a time-based award that may be eligible for certain vesting acceleration under Mr. Grady’s Change in Control and Severance Agreement or the Fabrinet Executive Change in Control and Severance Plan, as applicable, upon a qualifying termination during a specified change in control period.
