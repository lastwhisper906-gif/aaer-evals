# FN notes — 0001408710-24-000032


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001408710-24-000032:notes:1]
Portions of the registrant’s definitive proxy statement relating to its 2024 annual meeting of shareholders are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated. Such proxy statement will be filed with the U.S. Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001408710-24-000032:notes:2]
Summary of significant accounting policies
Principles of consolidation

[0001408710-24-000032:notes:3]
The Company utilizes a 52-53 week fiscal year ending on the last Friday in June. Fiscal years 2024, 2023, and 2022 ended on June 28, 2024, June 30, 2023, and June 24, 2022, respectively, and consisted of 52 weeks, 53 weeks and 52 weeks, respectively.

[0001408710-24-000032:notes:4]
The consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) and include Fabrinet and its subsidiaries. All inter-company accounts and transactions have been eliminated.

[0001408710-24-000032:notes:5]
Use of estimates

[0001408710-24-000032:notes:6]
The preparation of the Company’s consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information.

[0001408710-24-000032:notes:7]
Foreign currency transactions and translation

[0001408710-24-000032:notes:8]
The consolidated financial statements are presented in United States dollars (“$” or “USD”). The functional currency of Fabrinet and most of its subsidiaries is the USD.

[0001408710-24-000032:notes:9]
With respect to subsidiaries that use USD as their functional currency, transactions denominated in a currency other than USD are translated into USD at the rates of exchange in effect at the date of the transaction. Monetary assets and liabilities denominated in foreign currencies are translated into the functional currency at the exchange rate prevailing at the consolidated balance sheet dates. Transaction gains and losses are included in foreign exchange gain (loss) in the accompanying consolidated statements of operations and comprehensive income.

[0001408710-24-000032:notes:10]
Fabrinet translates the assets and liabilities of its subsidiaries that do not use USD as their functional currency into USD using exchange rates in effect at the end of each period. Revenue and expenses for such subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recognized in

[0001408710-24-000032:notes:11]
foreign currency translation adjustment included in accumulated other comprehensive income (loss) (“AOCI”) in the Company’s consolidated balance sheets.

[0001408710-24-000032:notes:12]
Cash and cash equivalents

[0001408710-24-000032:notes:13]
All highly liquid investments with original maturities of three months or less from the date of purchase are classified as cash equivalents. Cash and cash equivalents consist of cash deposited in checking accounts, time deposits with maturities of three months or less, money market accounts, and short-term investments with maturities of three months or less at the date of purchase.

[0001408710-24-000032:notes:14]
Short-term investments

[0001408710-24-000032:notes:15]
Management determines the appropriate classification of its investments at the time of purchase and re-evaluates the designations at each balance sheet date. The maturities of the Company’s short-term investments generally range from three months to three years.

[0001408710-24-000032:notes:16]
The short-term investments in debt securities are carried at either amortized cost or fair value. Investments in debt securities that the Company has the positive intent and ability to hold to maturity are carried at amortized cost and classified as held-to-maturity. Investments in debt securities that are not classified as held-to-maturity are carried at fair value and classified as available-for-sale with any unrealized gains and losses included in AOCI in the consolidated balance sheets. The Company determines realized gains or losses on sale of available-for-sale debt securities on a specific identification method and records such gains or losses as interest income in the consolidated statements of operations and comprehensive income.

[0001408710-24-000032:notes:17]
Held-to-maturity debt securities require the use of the current expected credit losses (“CECL”) impairment model to assess the expected credit loss. According to the CECL model, the Company requires the immediate recognition of estimated expected credit losses over the life of the financial instrument through the allowance for credit losses account. The allowance for credit losses is a valuation account that is deducted from, or added to, the amortized cost basis of the financial asset to present the net amount expected to be collected on the financial asset. In determining expected credit losses, the Company considers relevant qualitative factors including, but not limited to, term and structure of the instrument, credit rating by rating agencies and historic credit losses adjusted for current conditions and reasonable and supportable forecasts.

[0001408710-24-000032:notes:18]
Available-for-sale debt securities are required to be individually evaluated for impairment. A security is considered impaired if the fair value of the security is less than its amortized cost basis.

[0001408710-24-000032:notes:19]
An impairment is considered when (i) the Company has the intent to sell the security, (ii) it is more likely than not that the Company will be required to sell the security before recovery of the entire amortized cost basis, or (iii) the Company does not expect to recover the entire amortized cost basis of the security.

[0001408710-24-000032:notes:20]
If an impairment is considered based on condition (i) or (ii), the entire difference between the amortized cost and the fair value of the debt security is recognized as interest income and other income (expense), net in the consolidated statements of operations and comprehensive income.

[0001408710-24-000032:notes:21]
If an impairment is considered based on condition (iii), the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) is recognized in interest and other income (expense), net in the consolidated statements of operations and comprehensive income, and any remaining unrealized losses are included in AOCI in the consolidated balance sheets.

[0001408710-24-000032:notes:22]
Trade accounts receivable

[0001408710-24-000032:notes:23]
Accounts receivable are recorded and carried at the original invoiced amount less an allowance for any potential uncollectible amounts. The Company estimates expected credit losses for the allowance for expected credit losses based upon its assessment of various factors, including historical experience, the age of the accounts receivable balances, credit quality of its customers, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect the Company’s ability to collect from customers. The estimated credit loss allowance is recorded as selling, general and administrative expenses in the consolidated statements of operations and comprehensive income.

[0001408710-24-000032:notes:24]
Contract assets

[0001408710-24-000032:notes:25]
A contract asset is recognized when the Company has recognized revenues prior to generating an invoice for payment. Contract assets are recognized in the consolidated balance sheets under other current assets and transferred to accounts receivable when rights to payment become unconditional. The Company estimates expected credit losses for the

[0001408710-24-000032:notes:26]
allowance for contract assets based upon its assessment of various factors, including historical experience, the age of the contract assets balances, credit quality of its customers, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect the Company’s ability to collect from customers. The estimated credit loss allowance is recorded as selling, general and administrative expenses in the Company's consolidated statements of operations and comprehensive income.

[0001408710-24-000032:notes:27]
Contract liabilities

[0001408710-24-000032:notes:28]
A contract liability is recognized when the Company has advance payment arrangements with customers. The contract liabilities balance is normally recognized as revenue within six months.

[0001408710-24-000032:notes:29]
Inventory

[0001408710-24-000032:notes:30]
Inventory is stated at the lower of cost or market value. Cost is estimated using the standard costing method, computed on a first-in, first-out basis, with adjustments for variances to reflect actual costs not in excess of net realizable market value. Market value is the estimated selling price in the ordinary course of business, less the costs of completion and selling expenses. The Company assesses the valuation of inventory on a quarterly basis and writes down the value for estimated excess and obsolete inventory based upon estimates of future demand.

[0001408710-24-000032:notes:31]
Leases

[0001408710-24-000032:notes:32]
Operating leases

[0001408710-24-000032:notes:33]
The Company determines if an arrangement contains a lease at inception. The Company applies the guidance in ASC 842 to determine whether a contract is, or contains, a lease. A contract is or contains a lease if the contract conveys the right to control the use of identified property, plant, or equipment (an identified asset) for a period of time in exchange for consideration. Operating leases are included in operating lease right of use (“ROU”) assets and operating lease liabilities within the Company’s consolidated balance sheets. The Company rents certain real estate under agreements that are classified as operating leases.

[0001408710-24-000032:notes:34]
Operating lease ROU assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at commencement date. The Company's leases generally do not provide an implicit rate, nor is the implicit rate readily determinable. When the implicit rate is not readily determinable, the Company uses its incremental borrowing rate based on the information available at the lease commencement date in determining the present value of future payment. The operating lease ROU assets also include any lease payments made and exclude lease incentives and initial direct costs incurred. Variable lease payments are expensed as incurred and are not included within the ROU asset and lease liability calculation. Variable lease payments primarily include reimbursements of costs incurred by lessors for common area maintenance and utilities. The Company’s lease terms may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option.

[0001408710-24-000032:notes:35]
Leases with an initial term of 12 months or less are not recorded on the balance sheet. The Company recognizes lease expense for these leases on a straight-line basis over the lease term. The Company does not account for lease components (e.g., fixed payments including rent) separately from the non-lease components (e.g., common-area maintenance costs).

[0001408710-24-000032:notes:36]
Finance leases

[0001408710-24-000032:notes:37]
Finance leases are accounted for in a manner similar to financed purchases. The right-of-use asset is amortized to amortization expense. Interest expense is recorded in connection with the lease liability.

[0001408710-24-000032:notes:38]
Property, plant and equipment

[0001408710-24-000032:notes:39]
Land is stated at historical cost. Other property, plant and equipment, except for construction in process and machinery under installation, are stated at historical cost less accumulated depreciation. Repair and maintenance costs are expensed as incurred. Depreciation is calculated using the straight-line method to write-off the cost of each asset to its residual value over its estimated useful life as follows:

[0001408710-24-000032:notes:40]
| Land improvements |  | 10 years |
| Building and building improvements |  | 5-30 years |
| Leasehold improvements | Shorter of useful life or lease term |
| Manufacturing equipment |  | 3-7 years |
| Office equipment |  | 3-5 years |
| Motor vehicles |  | 3-5 years |
| Computer hardware |  | 3-5 years |

[0001408710-24-000032:notes:41]
Construction in process and machinery under installation is stated at historic cost and depreciation begins after it is constructed and fully installed and is ready for its intended use in the operations of the Company.

[0001408710-24-000032:notes:42]
Gains and losses on disposal are determined by comparing proceeds with carrying amounts and are included in other income in the consolidated statements of operations and comprehensive income.

[0001408710-24-000032:notes:43]
The Company reviews long-lived assets or asset groups for recoverability on a quarterly basis for any events or changes in circumstances that indicate that their carrying amount may not be recoverable. Recoverability of long-lived assets or asset groups is measured by comparing their carrying amount to the projected undiscounted cash flows that the long-lived assets or asset groups are expected to generate. If such assets are considered to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the long-lived assets exceeds its fair value.

[0001408710-24-000032:notes:44]
Intangibles

[0001408710-24-000032:notes:45]
Intangibles are stated at historical cost less amortization. Amortization of other intangibles is calculated using the straight-line method.

[0001408710-24-000032:notes:46]
Intangible assets are reviewed for impairment quarterly or more frequently whenever changes or circumstances indicate the carrying amount of related assets may not be recoverable.

[0001408710-24-000032:notes:47]
Goodwill

[0001408710-24-000032:notes:48]
Goodwill arising from acquisition is primarily attributable to the ability to expand future products and services and the assembled workforce. Goodwill is reviewed annually for impairment or more frequently whenever circumstances indicate that the carrying amount of a reporting unit may exceed its fair value. The impairment charge is based on that difference and is limited to the amount of goodwill allocated to that unit. The Company conducts impairment testing for goodwill at the reporting unit level. Reporting units may be operating segments as a whole, or an operation one level below an operating segment, referred to as a component. The Company has determined that its reporting unit is Fabrinet UK.

[0001408710-24-000032:notes:49]
The Company may initiate goodwill impairment testing by considering qualitative factors to determine whether it is more likely than not that a reportable unit carrying value is greater than its fair value. If the Company’s qualitative assessment indicates it is more likely than not that the fair value of a reporting unit exceeds its carrying value, no further analysis is required and goodwill is not impaired. Otherwise, the Company performs a quantitative goodwill impairment test to determine if goodwill is impaired. The quantitative test compares the fair value of a reporting unit with its carrying amount, including goodwill. If the fair value of the reportable segment exceeds the carrying value of the net assets associated with the segment, goodwill is not considered impaired. If the carrying value of the net assets associated with the reportable segment exceeds the fair value of the segment, the Company recognizes an impairment loss in an amount equal to the excess, not to exceed the carrying value of the reportable segment’s goodwill. The reporting unit’s carrying value used in an impairment test represents the assignment of various assets and liabilities, excluding certain corporate assets and liabilities, such as cash, investments, and debt.

[0001408710-24-000032:notes:50]
Goodwill is not deductible for tax purposes. Accordingly, if goodwill is impaired for financial reporting purposes, there is no impact on deferred taxes.

[0001408710-24-000032:notes:51]
Treasury shares

[0001408710-24-000032:notes:52]
Treasury share purchases are accounted for under the cost method whereby the entire cost of the acquired stock is recorded as treasury shares. Gains and losses in excess of par value on the subsequent reissuance of shares are credited or charged to additional paid-in capital in the consolidated balance sheets using the average-cost method.

[0001408710-24-000032:notes:53]
Borrowing costs

[0001408710-24-000032:notes:54]
Borrowing costs are accounted for on an accrual basis and are charged to the consolidated statements of operations and comprehensive income in the year incurred, except for interest costs on general and specific borrowings attributable to finance certain qualifying assets. Such costs to finance qualifying assets are capitalized during the period of time that is required to complete and prepare the assets for their intended use, as part of the cost of the assets. All other borrowing costs are expensed as incurred.

[0001408710-24-000032:notes:55]
Where funds are not borrowed for a specific acquisition, construction or production of assets, the capitalization rate used to determine the amount of interest to be capitalized is the weighted average interest rate applicable to the Company’s outstanding borrowings during the year. Where funds are borrowed specifically for the acquisition, construction or production of assets, the amount of borrowing costs eligible for capitalization on the respective assets is determined as the actual borrowing costs are incurred on that borrowing during the respective periods.

[0001408710-24-000032:notes:56]
Fair value of financial instruments

[0001408710-24-000032:notes:57]
Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. A fair value hierarchy is established which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs for the valuation of an asset or liability as of the measurement date. The three levels of inputs that may be used to measure fair value are defined as follows:

[0001408710-24-000032:notes:58]
Level 1 inputs are quoted prices (unadjusted) in active markets for identical assets or liabilities.

[0001408710-24-000032:notes:59]
Level 2 inputs for similar assets and liabilities in active markets other than quoted prices included within Level 1 that are observable for the asset or liability, either directly or indirectly, for substantially the full term of the asset or liability.

[0001408710-24-000032:notes:60]
Level 3 inputs that are significant to the fair value measurement and unobservable (i.e. supported by little or no market activity), which require the reporting entity to develop its own valuation techniques and assumptions.

[0001408710-24-000032:notes:61]
The Company utilizes the market approach to measure fair value for its financial assets and liabilities. The market approach uses prices and other relevant information generated by market transactions involving identical or comparable assets or liabilities.

[0001408710-24-000032:notes:62]
The carrying amounts of certain financial instruments, which include cash and cash equivalents, trade accounts receivable, contract assets, trade accounts payable, and contract liabilities, approximate their fair values due to their short maturities. The carrying amounts of borrowings approximate their fair values as the applicable interest rate is based on market interest rates. The particular recognition methods adopted are disclosed in the individual policy statements associated with each item.

[0001408710-24-000032:notes:63]
Derivatives

[0001408710-24-000032:notes:64]
The derivative assets and liabilities are measured at fair value and recognized on the consolidated balance sheets by offsetting the fair value amounts under master netting arrangements. For presentation in consolidated balance sheets, the Company may choose not to separate a derivative into its current and non-current portion as follows:

[0001408710-24-000032:notes:65]
•A derivative for which the fair value is a net liability is classified in total as current.

[0001408710-24-000032:notes:66]
•A derivative for which the fair value is a net asset and the current portion is an asset is classified in total as non-current. If the current portion is liability, it should be presented as current liability.

[0001408710-24-000032:notes:67]
For presentation in consolidated statements of cash flows are classified in the same line item as the underlying item.

[0001408710-24-000032:notes:68]
The Company applies hedge accounting to arrangements that qualify and are designated for cash flow or fair value hedge accounting treatment. Hedge accounting is discontinued prospectively if the hedging relationship ceases to be effective or the hedging or hedged items cease to exist as a result of maturity, sale, termination or cancellation.

[0001408710-24-000032:notes:69]
Derivatives designated and qualifying as hedges of the exposure to variability in expected future cash flows, or other types of forecasted transactions, are considered cash flow hedges which include foreign currency forward contracts and interest rate swap. In a cash flow hedging relationship, the change in the fair value of the hedging derivative is initially

[0001408710-24-000032:notes:70]
recorded in AOCI in the consolidated balance sheets, gain or loss on the derivative instrument is reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings. The reclassified amounts are presented in the same income statement line item as the earnings effect of the hedged item.

[0001408710-24-000032:notes:71]
In accordance with the fair value measurement guidance, the Company’s accounting policy is to measure the credit risk of its derivative financial instruments that are subject to master netting agreements on a net basis by counterparty portfolio. The Company executes derivative instruments with financial institutions that are credit-worthy, which the Company defines as institutions that hold an investment grade credit rating.

[0001408710-24-000032:notes:72]
Concentration of credit risk

[0001408710-24-000032:notes:73]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash and cash equivalents, short-term investments, derivatives, accounts receivable and contract assets.

[0001408710-24-000032:notes:74]
Cash, cash equivalents and short-term investments are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. The Company seeks to mitigate its credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties. The Company limits its short-term investments in marketable securities to securities with a maturity not in excess of three years and securities that are rated A1, P-1, F1, or better.

[0001408710-24-000032:notes:75]
The Company enters into derivative contracts with financial institutions with reputable credit and monitors the credit profiles of these counterparties.

[0001408710-24-000032:notes:76]
The Company performs ongoing credit evaluations for credit worthiness of its customers and usually does not require collateral from its customers. Management has implemented a program to closely monitor near term cash collection and credit exposures to mitigate any material losses.

[0001408710-24-000032:notes:77]
Revenue recognition

[0001408710-24-000032:notes:78]
The Company derives revenues primarily from the assembly of products under supply agreements with its customers and the fabrication of customized optics and glass. The Company recognizes revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the Company expects to be entitled in exchange for such goods or services. In order to meet this requirement, the Company applies the following five steps: (1) identify the contract with a customer, (2) identify the performance obligations under the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations under the contract, and (5) recognize revenue when a performance obligation is satisfied. Revenue is recognized net of any taxes collected from customers, which is subsequently remitted to governmental authorities.

[0001408710-24-000032:notes:79]
A performance obligation is a contractual promise to transfer a distinct good or service to the customer. In contracts with multiple performance obligations, the Company identifies each performance obligation and evaluates whether the performance obligation is distinct within the context of the contract at contract inception. The majority of the Company’s contracts have a single performance obligation, as the promise to transfer the individual goods or services is not separately identifiable from other promises under the contracts and, therefore, is not distinct.

[0001408710-24-000032:notes:80]
Sales of finished goods

[0001408710-24-000032:notes:81]
The Company manufactures products that are customized to customers’ specifications; however, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for over time recognition are not met. On evaluation of the contracts, the Company identified that there were no contractual rights to bill profit for work in progress in the event of a contract termination, which is expected to be infrequent. Further, in limited circumstances, contracts provide for substantive acceptance by the customer, which results in the deferral of revenue until formal notice of acceptance is received from the customer. Judgment may be required in determining if an acceptance clause provides for substantive acceptance.

[0001408710-24-000032:notes:82]
Certain customers may request the Company to store finished products at the Company’s warehouse where customers bear risks of loss themselves. In these instances, the Company receives a written request from the customer asking the Company to hold the inventory at the Company’s warehouse and refrain from using the ordered goods to fulfill other customer orders. In these situations, revenue is only recognized when the completed goods are ready for shipment and transferred to the Company’s warehouse.

[0001408710-24-000032:notes:83]
Customers generally are obligated to purchase finished goods that the Company has manufactured according to their demand requirements. Materials that are not consumed by customers within a specified period of time, or are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under the

[0001408710-24-000032:notes:84]
Company’s contracts. Once materials are designated as either excess or obsolete inventory, customers are typically required to purchase such inventory from the Company even if the customer has chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

[0001408710-24-000032:notes:85]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. In determining the net consideration to which the Company expects to be entitled, the Company evaluates whether the price is subject to refund or adjustment. The Company generally does not grant return privileges, except for in the case of defective products during the warranty period. The Company generally provides a warranty of between one to five years on any given product. These standard warranties are assurance-type warranties, and the Company does not offer any services in addition to the assurance that the product will continue to work as specified.

[0001408710-24-000032:notes:86]
The Company recognized revenue net of rebates and other similar allowances. Revenues are recognized only if these estimates can be reasonably and reliably determined. The Company estimates expected rebates and other similar allowances based on historical results taking into consideration the type of customer, the type of transaction and the specifics of each arrangement. The Company considers such estimated rebates and other similar allowances as variable consideration when allocating the transaction price to the extent it is probable that there will not be a significant reversal of cumulative revenue recognized. The estimate is primarily based on the most likely level of consideration to be paid to the customer under the specific terms of each arrangement.

[0001408710-24-000032:notes:87]
Services

[0001408710-24-000032:notes:88]
The Company provides services for customers that are related to the Company’s manufacturing activities. In many cases, although the nature of work performed is that of a service, revenue is only recognized upon shipment of the product because the customer has specific requirements as to how many items can be shipped at any given point in time, i.e. at point-in-time. The related costs are expensed as incurred.

[0001408710-24-000032:notes:89]
Service revenues of $122.6 million, $116.2 million and $140.4 million were recognized in the consolidated statements of operations and comprehensive income for the years ended June 28, 2024, June 30, 2023 and June 24, 2022, respectively.

[0001408710-24-000032:notes:90]
Contract Costs

[0001408710-24-000032:notes:91]
The incremental costs of obtaining a contract with a customer are recognized as an asset (not expensed as incurred) if such costs are expected to be recovered. Incremental costs of obtaining a contract are costs that the Company would not have incurred if the contract had not been obtained (e.g., sales commissions or similar incentive payments linked directly to new or modified customer contracts). Costs that would have been incurred regardless of whether a customer contract was obtained (e.g., costs of pursuing the contract, legal advice, etc.) are expensed as incurred, unless such costs are explicitly chargeable to the customer. During the years ended June 28, 2024, June 30, 2023 and June 24, 2022, the Company did not have any incremental costs of obtaining a contract.

[0001408710-24-000032:notes:92]
Shipping and Handling

[0001408710-24-000032:notes:93]
Shipping costs billed to customers are recorded as revenue. Shipping and handling expense related to costs incurred to deliver product are recognized within cost of goods sold. The Company accounts for shipping and handling activities that occur after control has transferred as a fulfillment cost, as opposed to a separate performance obligation, and the costs of shipping and handling are recognized concurrently with the related revenue.

[0001408710-24-000032:notes:94]
Warranty provision

[0001408710-24-000032:notes:95]
Provisions for estimated expenses relating to product warranties are made at the time the products are sold using historical experience. Generally, this warranty is limited to workmanship and the Company’s liability is capped at the price of the product. The provisions will be adjusted when experience indicates an expected settlement will differ from initial estimates.

[0001408710-24-000032:notes:96]
Warranty cost allowances were recognized in the consolidated statements of operations and comprehensive income for the years ended June 28, 2024, June 30, 2023 and June 24, 2022 with de minimis amount.

[0001408710-24-000032:notes:97]
Share-based compensation

[0001408710-24-000032:notes:98]
Share-based compensation is recognized in the consolidated financial statements based on grant-date fair value. The value of the portion of the award that is ultimately expected to vest is recognized as expense ratably over the requisite service period. For restricted share units and performance share units, the fair values are based on the market value of our ordinary shares on the date of grant.

[0001408710-24-000032:notes:99]
Employee contribution plan

[0001408710-24-000032:notes:100]
The Company operates a defined contribution plan, known as a provident fund, in its subsidiaries in Thailand and the United Kingdom. The assets of these plans are in separate trustee-administered funds. The provident fund is funded by matching payments from employees and by the subsidiaries on a monthly basis. Current contributions to the provident fund are accrued and paid to the fund manager on a monthly basis. The Company sponsors the Fabrinet U.S. 401(k) Retirement Plan, a Defined Contribution Plan under ERISA, at its subsidiaries in the United States, which provides retirement benefits for its eligible employees through tax deferred salary deductions.

[0001408710-24-000032:notes:101]
Severance liabilities

[0001408710-24-000032:notes:102]
Under labor protection laws applicable in Thailand and the Company’s subsidiary in Thailand’s employment policy, all employees of such subsidiary with more than 120 days of service are entitled to severance pay on forced termination or retrenchment or in the event that the employee reaches the retirement age of 55. The entitlement to severance pay is determined according to an employee’s individual employment tenure with the Company and is subject to a maximum benefit of 400 days of salary unless otherwise agreed upon in an employee’s employment contract. For employees of other subsidiaries who have a specific termination date, the entitlement to severance pay is determined according to their employment tenure, until their designated termination date.

[0001408710-24-000032:notes:103]
The Company accounts for these severance liabilities based on an actuarial valuation using the Projected Unit Credit Method, which apply the long-term Thai government bond yield as a discount rate. There are no separate plan assets held in respect to these liabilities.

[0001408710-24-000032:notes:104]
The Company’s subsidiary in the U.K. operates a defined benefit pension plan that defines the pension benefit an employee will receive on retirement, usually dependent upon several factors including but not limited to age, length of service and remuneration. The defined benefit obligation is calculated using the projected unit credit method. Annually the Company engages independent actuaries to calculate the obligation. The present value is determined by discounting the estimated future payments using market yields on high quality corporate bonds that are denominated in sterling and that have terms approximating the estimated period of the future payments (discount rate). The plan assets are held separately from those of the Company in independently administered funds and are measured at fair value.

[0001408710-24-000032:notes:105]
Severance liabilities are recognized in the Company’s consolidated balance sheet under non-current liabilities. The related expenses, if incurred during the period, are recognized in the Company’s consolidated statements of operations and comprehensive income as selling, general and administrative expenses. Prior service cost is initially recognized to other comprehensive income (loss) at the date of plan amendment. Such prior service cost is amortized as expenses as a component of net periodic pension cost using the weighted average remaining years of service to full eligibility date for active employees.

[0001408710-24-000032:notes:106]
Annual leave

[0001408710-24-000032:notes:107]
Employee entitlements to annual leave are recognized when earned by the employee. On termination of employment, accrued employee entitlement to annual leave is paid in cash.

[0001408710-24-000032:notes:108]
Income taxes

[0001408710-24-000032:notes:109]
The Company uses the asset and liability method of accounting for income taxes, whereby deferred tax assets and liabilities are recognized for future tax consequences attributable to temporary differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using tax rates expected to apply to taxable income in the years in which those temporary differences are expected to reverse. The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date. Deferred tax assets are reduced by a valuation allowance if, based on the weight of the available evidence, it is more likely than not that some portion or all of the deferred tax assets will not be realized.

[0001408710-24-000032:notes:110]
Fabrinet’s subsidiaries are subject to income tax audits by the respective tax authorities in all of the jurisdictions in which they operate. The determination of tax liabilities in each of these jurisdictions requires the interpretation and application of complex and sometimes uncertain tax laws and regulations. The Company recognizes liabilities based on its estimate of whether, and the extent to which, additional tax liabilities are more-likely-than-not. If the Company ultimately determines that the payment of such a liability is not probable, then it reverses the liability and recognizes a tax benefit during the period in which the determination is made that the liability is no longer probable. The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that the Company makes certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on the Company’s tax provision in a future period.

[0001408710-24-000032:notes:111]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. A company shall reduce its deferred tax assets by a valuation allowance if, based on the weight of available evidence, it is “more likely than not” (i.e., a likelihood of greater than 50 percent) that some portion or all of the deferred tax assets will not be realized. The valuation allowance shall be sufficient to reduce the deferred tax asset to the amount that is more likely than not to be realized. The valuation allowance shall be monitored and considered from all available evidence, both positive and negative, to determine whether, based on the weight of that evidence, a valuation allowance for deferred tax assets is not needed.

[0001408710-24-000032:notes:112]
The accounting standard clarifies the accounting for uncertainty in income taxes recognized in an entity’s financial statements and prescribes a recognition threshold and measurement attributes for financial statement disclosure of tax positions taken or expected to be taken on a tax return.

[0001408710-24-000032:notes:113]
The Company recognizes a tax benefit in the financial statements for an uncertain tax position only if management’s assessment is that the position is “more likely than not” to be sustained upon examination by the tax jurisdiction based solely on the technical merits of the position. The term “tax position” refers to a position in a previously filed tax return or a position expected to be taken in a future tax return that is reflected in measuring current or deferred income tax assets and liabilities for interim or annual periods. The accounting interpretation also provides guidance on measurement methodology, derecognition thresholds, financial statement classification and disclosures, recognition of interest and penalties, and accounting for the cumulative-effect adjustment at the date of adoption.

[0001408710-24-000032:notes:114]
Adoption of New Accounting Standards

[0001408710-24-000032:notes:115]
No new accounting standard was adopted during the year ended June 28, 2024.

[0001408710-24-000032:notes:116]
New Accounting Standards—not yet adopted by the Company

[0001408710-24-000032:notes:117]
In November 2023, the Financial Accounting Standards Board ("FASB") issued ASU 2023-07, “Segment Reporting (Topic 280), Improvements to Reportable Segment Disclosures,” which is intended to improve reportable segment disclosure requirements, primarily through additional disclosures about significant segment expenses. This ASU is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. This ASU will be effective for the Company in fiscal year 2025. The Company is currently assessing the impact to its disclosures.

[0001408710-24-000032:notes:118]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740), Improvements to Income Tax Disclosures,” which requires more detailed income tax disclosures. This ASU requires entities to disclose disaggregated information about their effective tax rate reconciliation as well as expanded information on income taxes paid by jurisdiction. This ASU is effective for all entities for fiscal years beginning after December 15, 2024, with early adoption permitted for annual financial statements that have not yet been issued or made available for issuance. This ASU will be effective for the Company in the first quarter of fiscal year 2026. The Company is currently assessing the impact to its disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001408710-24-000032:notes:119]
Revenues from contracts with customers
Contract Assets and Liabilities

[0001408710-24-000032:notes:120]
A contract asset is recognized when the Company has recognized revenues prior to an invoice for payment. Contract assets are recognized in the consolidated balance sheets under other current assets and transferred to accounts receivable when rights to payment become unconditional. No impairment for contract assets was recorded for the years ended June 28, 2024 and June 30, 2023.

[0001408710-24-000032:notes:121]
As of June 28, 2024 and June 30, 2023, the Company's contract assets were de minimis.

[0001408710-24-000032:notes:122]
A contract liability is recognized when the Company has advance payment arrangements with customers. Contract liabilities are recognized in the consolidated balance sheets under other payables. The contract liabilities balance is normally recognized as revenue within six months.

[0001408710-24-000032:notes:123]
The following tables summarize the activity in the Company’s contract liabilities during the years ended June 28, 2024 and June 30, 2023:

[0001408710-24-000032:notes:124]
| (in thousands) |  |  |  | Contract Liabilities |
| Balance as of June 24, 2022 |  |  |  | $ | 1,982 |  |
| Advance payment received during the year |  |  |  | 14,124 |  |
| Revenue recognized |  |  |  | (13,070) |  |
| Balance as of June 30, 2023 |  |  |  | 3,036 |  |
| Advance payment received during the year |  |  |  | 11,069 |  |
| Revenue recognized |  |  |  | (6,259) |  |
| Balance as of June 28, 2024 |  |  |  | $ | 7,846 |  |

[0001408710-24-000032:notes:125]
Revenue by Geographic Area and End Market

[0001408710-24-000032:notes:126]
Total revenues are attributed to a particular geographic area based on the bill-to-location of the Company’s customers. The Company operates primarily in three geographic regions: North America; Asia-Pacific and others; and Europe.

[0001408710-24-000032:notes:127]
The following table presents total revenues by geographic regions:

[0001408710-24-000032:notes:128]
| (in thousands, except percentages) | Year ended June 28,2024 |  | As a %of TotalRevenues |  | Year ended June 30,2023 |  | As a %of TotalRevenues |  | Year ended June 24,2022 |  | As a %of TotalRevenues |
| North America | $ | 1,053,141 |  |  | 36.5 | % |  | $ | 1,269,965 |  |  | 48.0 | % |  | $ | 1,114,504 |  |  | 49.3 | % |
| Asia-Pacific | 1,646,055 |  |  | 57.1 |  |  | 1,143,510 |  |  | 43.2 |  |  | 838,051 |  |  | 37.0 |  |
| Europe | 183,771 |  |  | 6.4 |  |  | 231,762 |  |  | 8.8 |  |  | 309,669 |  |  | 13.7 |  |
|  | $ | 2,882,967 |  |  | 100.0 | % |  | $ | 2,645,237 |  |  | 100.0 | % |  | $ | 2,262,224 |  |  | 100.0 | % |

[0001408710-24-000032:notes:129]
|  | Years Ended |
| (in thousands, except percentages) | June 28,2024 |  | June 30,2023 |  | June 24,2022 |
| North America |  |  |  |  |  |
| U.S. | 1,041,046 |  |  | 1,247,422 |  |  | 1,099,244 |  |
| Others (1) | 12,095 |  |  | 22,543 |  |  | 15,260 |  |
| Total revenue in North America | 1,053,141 |  |  | 1,269,965 |  |  | 1,114,504 |  |
| Asia-Pacific and others |  |  |  |  |  |
| Israel (2) | 1,049,730 |  |  | 341,025 |  |  | 101,058 |  |
| India | 269,304 |  |  | 325,478 |  |  | 278,117 |  |
| Malaysia | 117,929 |  |  | 162,599 |  |  | 212,286 |  |
| China | 65,497 |  |  | 73,094 |  |  | 55,201 |  |
| Hong Kong | 60,489 |  |  | 132,136 |  |  | 83,651 |  |
| Thailand | 47,339 |  |  | 58,850 |  |  | 36,489 |  |
| Japan | 25,094 |  |  | 41,105 |  |  | 60,121 |  |
| Others | 10,673 |  |  | 9,223 |  |  | 11,128 |  |
| Total revenue in Asia-Pacific and others | 1,646,055 |  |  | 1,143,510 |  |  | 838,051 |  |
| Europe |  |  |  |  |  |
| U.K. | 87,051 |  |  | 125,082 |  |  | 90,921 |  |
| Germany | 42,817 |  |  | 54,732 |  |  | 40,794 |  |
| Ireland | 599 |  |  | 647 |  |  | 133,225 |  |
| Others | 53,304 |  |  | 51,301 |  |  | 44,729 |  |
| Total revenue in Europe | $ | 183,771 |  |  | $ | 231,762 |  |  | $ | 309,669 |  |
| Total revenue | $ | 2,882,967 |  |  | $ | 2,645,237 |  |  | $ | 2,262,224 |  |

[0001408710-24-000032:notes:130]
(1)Others includes revenues from external customers based in our country of domicile, the Cayman Islands, which for each year presented is $0.

[0001408710-24-000032:notes:131]
(2)Due to increase in revenue from a significant customer.

[0001408710-24-000032:notes:132]
The following table presents revenues by end market and product category.


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001408710-24-000032:notes:133]
| (in thousands, except percentages) | Year ended June 28, 2024 |  | As a % of TotalRevenues |  | Year ended June 30, 2023 |  | As a % of TotalRevenues |  | Year ended June 24, 2022 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |  |  |  |  |
| Datacom | $ | 1,150,307 |  |  |  |  | $ | 520,796 |  |  |  |  | $ | 361,306 |  |  |  |
| Telecom | 1,138,708 |  |  |  |  | 1,487,551 |  |  |  |  | 1,421,493 |  |  |  |
| Total revenue - Optical communications | $ | 2,289,015 |  |  | 79.4 | % |  | $ | 2,008,347 |  |  | 75.9 | % |  | $ | 1,782,799 |  |  | 78.8 | % |
| Non-optical communications |  |  |  |  |  |  |  |  |  |  |  |
| Automotive | $ | 327,188 |  |  |  |  | $ | 368,581 |  |  |  |  | $ | 204,407 |  |  |  |
| Industrial laser | 122,722 |  |  |  |  | 125,415 |  |  |  |  | 149,357 |  |  |  |
| Others | 144,042 |  |  |  |  | 142,894 |  |  |  |  | 125,661 |  |  |  |
| Total revenue - Non-optical communications | $ | 593,952 |  |  | 20.6 | % |  | $ | 636,890 |  |  | 24.1 | % |  | $ | 479,425 |  |  | 21.2 | % |
| Total revenue | $ | 2,882,967 |  |  | 100.0 | % |  | $ | 2,645,237 |  |  | 100.0 | % |  | $ | 2,262,224 |  |  | 100.0 | % |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001408710-24-000032:notes:134]
Income taxes
Fabrinet’s effective tax rate is a function of the mix of tax rates in the various jurisdictions in which we conduct business. Fabrinet is domiciled in the Cayman Islands. Under the current laws of the Cayman Islands, Fabrinet is not subject to tax in the Cayman Islands on income or capital gains until March 6, 2039.

[0001408710-24-000032:notes:135]
The majority of the Company’s operations and production take place in Thailand. The Company was not subject to tax in Thailand from July 2012 through June 2020 on income generated from the manufacture of products at its Pinehurst campus Building 6, and is not subject to tax in Thailand from July 2018 through June 2026 on income generated from the manufacture of products at its Chonburi campus. After June 2020, 50% of the Company's income generated from products manufactured at its Pinehurst campus Building 6 will be exempted from tax in Thailand through June 2025. New preferential tax treatment is available to the Company for products manufactured at its Chonburi campus Building 9, where income generated will be tax exempt through 2031, capped at the Company’s actual investment amount. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted. Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001408710-24-000032:notes:136]
The corporate income tax rates for our subsidiaries in the PRC, the U.S., the U.K. and Israel are 25%, 21%, 25% and 23%, respectively. Our provision for income taxes is computed using the asset and liability method, under which deferred income taxes are recognized for differences between the financial statement and tax bases of assets and liabilities at currently enacted statutory tax rates for the years in which the differences are expected to reverse. The effect on deferred taxes of a change in tax rates is recognized in income in the period that includes the enactment.

[0001408710-24-000032:notes:137]
The Company’s income tax expense consisted of the following:

[0001408710-24-000032:notes:138]
|  | Years Ended |
| (in thousands) | June 28,2024 |  | June 30,2023 |  | June 24,2022 |
| Current | $ | 11,993 |  |  | $ | 15,044 |  |  | $ | 6,744 |  |
| Deferred | 3,180 |  |  | (2,861) |  |  | (158) |  |
| Total income tax expense | $ | 15,173 |  |  | $ | 12,183 |  |  | $ | 6,586 |  |

[0001408710-24-000032:notes:139]
The reconciliation between the Company’s taxes that would arise by applying the statutory tax rate of the country of the Company’s principal operations, Thailand, to the Company’s effective tax charge is shown below:

[0001408710-24-000032:notes:140]
|  | Years Ended |
| (in thousands) | June 28,2024 |  | June 30,2023 |  | June 24,2022 |
| Income before income taxes (1) | $ | 311,354 |  |  | $ | 260,096 |  |  | $ | 206,966 |  |
| Tax expense calculated at a statutory corporate income tax rate of 20% | 62,271 |  |  | 52,019 |  |  | 41,393 |  |
| Effect of income taxes from locations with tax rates different from Thailand | (945) |  |  | 659 |  |  | 681 |  |
| Income not subject to tax (2) | (62,940) |  |  | (43,679) |  |  | (35,982) |  |
| Income tax on unremitted earnings | 1,488 |  |  | 2,452 |  |  | 1,417 |  |
| Non-deductible expenses | 10,347 |  |  | 35 |  |  | 68 |  |
| Foreign operations | (534) |  |  | 1,968 |  |  | (1,165) |  |
| Tax rebate from research and development application | 17 |  |  | (124) |  |  | (873) |  |
| Provision for uncertain income tax position | 1,131 |  |  | (7) |  |  | 668 |  |
| Utilization of loss and tax credits carryforward | — |  |  | (80) |  |  | (194) |  |
| Changes in valuation allowance (3) | 3,759 |  |  | (1,608) |  |  | — |  |
| Others | 579 |  |  | 548 |  |  | 573 |  |
| Corporate income tax expense | $ | 15,173 |  |  | $ | 12,183 |  |  | $ | 6,586 |  |

[0001408710-24-000032:notes:141]
(1)Income before income taxes was primarily generated from domestic operations in the Cayman Islands amounted to $306.0 million, $196.5 million and $171.0 million for the years ended June 28, 2024, June 30, 2023 and June 24, 2022, respectively.

[0001408710-24-000032:notes:142]
(2)Income not subject to tax relates to income earned in the Cayman and Mauritius Islands and income subject to an investment promotion privilege in Thailand. Income not subject to tax per ordinary share on a diluted basis was $1.72, $1.19, and $0.96 for the years ended June 28, 2024, June 30, 2023, and June 24, 2022, respectively.

[0001408710-24-000032:notes:143]
(3)Changes in valuation allowances were due to adjustments based on management's assessment on the realizability of the related deferred tax assets.

[0001408710-24-000032:notes:144]
The Company’s deferred tax assets and deferred tax liabilities, net of valuation allowance, at each balance sheet date are as follows:

[0001408710-24-000032:notes:145]
|  | As of |
| (in thousands) | June 28,2024 |  | June 30,2023 |
| Deferred tax assets: |  |  |  |
| Depreciation | $ | 1,890 |  |  | $ | 1,999 |  |
| Severance liability | 4,496 |  |  | 4,058 |  |
| Reserves and allowance | 3,735 |  |  | 1,712 |  |
| Net operating loss carryforwards | 3,146 |  |  | 7,142 |  |
| Others | 792 |  |  | 1,008 |  |
| Total | 14,059 |  |  | 15,919 |  |
| Less: Valuation allowance | (3,613) |  |  | (3,824) |  |
| Net deferred tax assets | $ | 10,446 |  |  | $ | 12,095 |  |
| Deferred tax liabilities: |  |  |  |
| Temporary differences from intangibles and changes in the fair value of assets acquired | $ | (1,626) |  |  | $ | (1,711) |  |
| Deferred tax from unremitted earnings | (5,303) |  |  | (4,819) |  |
| Others | 2,034 |  |  | 1,731 |  |
| Total | (4,895) |  |  | (4,799) |  |
| Net | $ | 5,551 |  |  | $ | 7,296 |  |

[0001408710-24-000032:notes:146]
The changes in the valuation allowances of deferred tax assets were as follows:

[0001408710-24-000032:notes:147]
| (in thousands) | Valuation allowances ofdeferred tax assets |
| Balance as of June 25, 2021 | $ | 2,061 |  |
| Additional | 2,873 |  |
| Balance as of June 24, 2022 | 4,934 |  |
| Additional | 498 |  |
| Reduction | (1,608) |  |
| Balance as of June 30, 2023 | 3,824 |  |
| Additional | 3,613 |  |
| Reduction | (3,824) |  |
| Balance as of June 28, 2024 | $ | 3,613 |  |

[0001408710-24-000032:notes:148]
During fiscal year 2020, one of our subsidiaries in the U.K. also generated net operating loss and management expected that such subsidiary would continue to have net operating losses in the foreseeable future. Therefore, management believed it was more likely than not that all of the deferred tax assets of such subsidiary would not be utilized. Thus, a full valuation allowance of $1.6 million for the deferred tax assets was set up as of the end of fiscal year 2020. A full valuation allowance of $3.8 million, $4.9 million and $2.1 million were set up for the fiscal year ended June 30, 2023, June 24, 2022 and June 25, 2021, respectively. During fiscal year 2024, deferred tax assets and valuation allowance were released due to our cessation of operations in the U.K.

[0001408710-24-000032:notes:149]
During fiscal year 2023, the other subsidiary in the U.K. generated taxable income and was able to utilize loss carryforwards. Management determined that it was more likely than not that future taxable income would be sufficient to allow utilization of the deferred tax assets. Thus, a full valuation allowance of $1.6 million for the deferred tax assets was released as of June 30, 2023. In fiscal year 2024, due to our cessation of operations in the U.K., management believe that

[0001408710-24-000032:notes:150]
it will not generate sufficient taxable income to utilize the remaining deferred tax assets. Thus, a full valuation allowance of $1.0 million was recorded.

[0001408710-24-000032:notes:151]
During fiscal year 2024, our subsidiary in Israel continued to generate net operating loss and management expected that such subsidiary would continue to have net operating losses in the foreseeable future; therefore, management believed it was more likely than not that all of the deferred tax assets of such subsidiary would not be utilized. Thus, a full valuation allowance of $2.7 million for the deferred tax assets was set up as of the end of fiscal year 2024.

[0001408710-24-000032:notes:152]
Income tax liabilities have not been established for withholding tax and other taxes that would be payable on the unremitted earnings in Thailand, which are permanently reinvested. Unremitted earnings in Thailand totaled $144.4 million and $135.1 million as of June 28, 2024 and June 30, 2023, respectively. Unrecognized deferred tax liabilities for such unremitted earnings were $11.6 million and $12.3 million as of June 28, 2024 and June 30, 2023, respectively.

[0001408710-24-000032:notes:153]
Deferred tax liabilities of $1.5 million and $1.9 million have been established for withholding tax on the unremitted earnings in China for the years ended June 28, 2024 and June 30, 2023, respectively, which are included in non-current deferred tax liability in the consolidated balance sheets.

[0001408710-24-000032:notes:154]
Uncertain income tax positions

[0001408710-24-000032:notes:155]
Interest and penalties related to uncertain income tax positions are recognized in income tax expense. The Company had approximately $0.2 million of accrued interest and penalties related to uncertain income tax positions on the consolidated balance sheets as of June 28, 2024. The Company recorded interest and penalties of $0.1 million and  $0.1 million for the years ended June 30, 2023 and June 24, 2022, respectively, in the consolidated statements of operations and comprehensive income. The amount of interest and penalties reversed in fiscal 2024 provision for income taxes is $0.2 million. With regard to the Thailand jurisdiction, tax years 2018 through 2022 remain open to examination by the local authorities.

[0001408710-24-000032:notes:156]
The following table indicates the changes to the Company’s uncertain income tax positions for the years ended June 28, 2024, June 30, 2023 and June 24, 2022, excluding interest and penalties, were as follows:

[0001408710-24-000032:notes:157]
|  | Years Ended |
| (in thousands) | June 28,2024 |  | June 30,2023 |  | June 24,2022 |
| Beginning balance | $ | 1,288 |  |  | $ | 1,392 |  |  | $ | 807 |  |
| Additions during the year | 1,091 |  |  | 15 |  |  | 610 |  |
| Release of tax positions of prior years | (1,130) |  |  | (119) |  |  | (25) |  |
| Ending balance | $ | 1,249 |  |  | $ | 1,288 |  |  | $ | 1,392 |  |


## us-gaap:EarningsPerShareTextBlock

[0001408710-24-000032:notes:158]
Earnings per ordinary share
Basic earnings per ordinary share is computed by dividing reported net income by the weighted average number of ordinary shares outstanding during each period. Diluted earnings per ordinary share is computed by calculating the effect of potential dilutive ordinary shares outstanding during the year using the treasury stock method. Dilutive ordinary equivalent shares consist of share options, restricted share units and performance share units.

[0001408710-24-000032:notes:159]
Earnings per ordinary share was calculated as follows:

[0001408710-24-000032:notes:160]
|  | Years Ended |
| (in thousands, except per share data) | June 28,2024 |  | June 30,2023 |  | June 24,2022 |
| Net income attributable to shareholders | $ | 296,181 |  |  | $ | 247,913 |  |  | $ | 200,380 |  |
| Weighted-average number of ordinary shares outstanding | 36,246 |  |  | 36,515 |  |  | 36,876 |  |
| Incremental shares arising from the assumed exercise of share options and vesting of restricted share units and performance share units | 318 |  |  | 340 |  |  | 518 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share | 36,564 |  |  | 36,855 |  |  | 37,394 |  |
| Basic earnings per ordinary share | $ | 8.17 |  |  | $ | 6.79 |  |  | $ | 5.43 |  |
| Diluted earnings per ordinary share | $ | 8.10 |  |  | $ | 6.73 |  |  | $ | 5.36 |  |


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001408710-24-000032:notes:161]
Cash, cash equivalents and short-term investments
The Company’s cash, cash equivalents, and short-term investments by category is as follows:

[0001408710-24-000032:notes:162]
|  |  |  | Fair Value |
| (in thousands) | CarryingCost |  | UnrealizedGain/(Loss) |  | Cash andCashEquivalents |  | MarketableSecurities |  | OtherInvestments |
| As of June 28, 2024 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 409,938 |  |  | $ | — |  |  | $ | 409,938 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 35 |  |  | — |  |  | 35 |  |  | — |  |  | — |  |
| Certificates of deposit and time deposits | 134,288 |  |  | (5) |  |  | — |  |  | 134,283 |  |  | — |  |
| Corporate debt securities | 137,695 |  |  | (932) |  |  | — |  |  | 136,763 |  |  | — |  |
| U.S. agency and U.S. Treasury securities | 177,824 |  |  | (240) |  |  | — |  |  | 177,584 |  |  | — |  |
| Total | $ | 859,780 |  |  | $ | (1,177) |  |  | $ | 409,973 |  |  | $ | 448,630 |  |  | $ | — |  |
| As of June 30, 2023 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 230,967 |  |  | $ | — |  |  | $ | 230,967 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 401 |  |  | — |  |  | 401 |  |  | — |  |  | — |  |
| Liquidity funds | 41,104 |  |  | — |  |  | — |  |  | — |  |  | 41,104 |  |
| Certificate of deposits | 64,278 |  |  | 329 |  |  | — |  |  | 64,607 |  |  | — |  |
| Corporate debt securities | 161,453 |  |  | (3,375) |  |  | — |  |  | 158,078 |  |  | — |  |
| U.S. agency and U.S. Treasury securities | 55,542 |  |  | (231) |  |  | — |  |  | 55,311 |  |  | — |  |
| Total | $ | 553,745 |  |  | $ | (3,277) |  |  | $ | 231,368 |  |  | $ | 277,996 |  |  | $ | 41,104 |  |

[0001408710-24-000032:notes:163]
The cash equivalents include short-term bank deposits, investments in money market funds, and marketable securities with maturities of three months or less at the date of purchase. The effective interest rate on short term bank deposits was 4.4% and 2.4% per annum for the years ended June 28, 2024 and June 30, 2023, respectively.

[0001408710-24-000032:notes:164]
As of June 28, 2024, the Company had investments in certificates of deposit of $83.8 million and term deposit of $50.5 million which were classified as available-for-sale debt securities. As of June 30, 2023, the Company had investments in certificates of deposit of $44.6 million and term deposit of $20.0 million.

[0001408710-24-000032:notes:165]
As of June 28, 2024 and June 30, 2023, 74% and 69%, respectively, of our cash and cash equivalents were held by the Parent Company.

[0001408710-24-000032:notes:166]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of June 28, 2024 and June 30, 2023:

[0001408710-24-000032:notes:167]
|  | June 28, 2024 |  | June 30, 2023 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 110,671 |  |  | $ | 110,669 |  |  | $ | 172,992 |  |  | $ | 173,137 |  |
| Due between one to five years | 339,136 |  |  | 337,961 |  |  | 149,385 |  |  | 145,963 |  |
| Total | $ | 449,807 |  |  | $ | 448,630 |  |  | $ | 322,377 |  |  | $ | 319,100 |  |

[0001408710-24-000032:notes:168]
During the year ended June 28, 2024, the Company recognized a de minimis gain from sales of available-for-sale debt securities in interest income in the consolidated statements of operations and comprehensive income. During the year ended June 30, 2023, the Company recognized a realized loss of $0.1 million from sales of available-for-sale debt securities in interest income in the consolidated statements of operations and comprehensive income.

[0001408710-24-000032:notes:169]
As of June 28, 2024 and June 30, 2023, the Company considered the decline in market value of its available-for-sale debt securities by using the AFS debt security impairment model. The Company typically invests in highly-rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy requires investments generally to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. The Company assessed impairment at the individual security level according to the relevant accounting standard by comparing its fair value/market value with its amortized cost. The Company considered factors such as the failure of the issuer of the security to make scheduled interest and principal payments and any changes to the credit rating of the security by a rating agency. The credit rating of the Company's invested securities are still in compliance with the Company's investment policy. No impairment losses on available-for-sale debt securities were recorded for the year ended June 28, 2024 and June 30, 2023.


## us-gaap:FairValueDisclosuresTextBlock

[0001408710-24-000032:notes:170]
Fair value of financial instruments
Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. A fair value hierarchy is established, which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs for the valuation of an asset or liability as of the measurement date. The three levels of inputs that may be used to measure fair value are defined as follows:

[0001408710-24-000032:notes:171]
Level 2 inputs are inputs other than quoted prices included within Level 1 that are observable for assets or liabilities, either directly or indirectly. If the assets or liabilities have a specified (contractual) term, Level 2 inputs must be observable for substantially the full term of assets or liabilities.

[0001408710-24-000032:notes:172]
Level 3 inputs are unobservable inputs for assets or liabilities, which require the reporting entity to develop its own valuation techniques and assumptions.

[0001408710-24-000032:notes:173]
The following table provides details of the financial instruments measured at fair value on a recurring basis, including:

[0001408710-24-000032:notes:174]
|  | Fair Value Measurements at Reporting DateUsing |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of June 28, 2024 |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 35 |  |  | $ | — |  |  | $ | 35 |  |
| Certificates of deposit and time deposits | — |  |  | 134,283 |  |  | — |  |  | 134,283 |  |
| Corporate debt securities | — |  |  | 136,763 |  |  | — |  |  | 136,763 |  |
| U.S. agency and U.S. Treasury securities | — |  |  | 177,584 |  |  | — |  |  | 177,584 |  |
| Derivative assets - current portion | — |  |  | 15 |  | (1) | — |  |  | 15 |  |
| Total | $ | — |  |  | $ | 448,680 |  |  | $ | — |  |  | $ | 448,680 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative liabilities - current portion | $ | — |  |  | $ | (2,244) |  |  | $ | — |  |  | $ | (2,244) |  |
| Total | $ | — |  |  | $ | (2,244) |  | (2) | $ | — |  |  | $ | (2,244) |  |

[0001408710-24-000032:notes:175]
|  | Fair Value Measurements at Reporting DateUsing |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of June 30, 2023 |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 401 |  |  | $ | — |  |  | $ | 401 |  |
| Liquidity funds | — |  |  | 41,104 |  |  | — |  |  | 41,104 |  |
| Certificates of deposit and time deposits | — |  |  | 64,607 |  |  | — |  |  | 64,607 |  |
| Corporate debt securities | — |  |  | 158,078 |  |  | — |  |  | 158,078 |  |
| U.S. agency and U.S. Treasury securities | — |  |  | 55,311 |  |  | — |  |  | 55,311 |  |
| Derivative assets - current portion | — |  |  | 221 |  | (3) | — |  |  | 221 |  |
| Total | $ | — |  |  | $ | 319,722 |  |  | $ | — |  |  | $ | 319,722 |  |
| Liabilities |  |  |  |  |  |  |  |
| Derivative liabilities - current portion | $ | — |  |  | $ | (5,236) |  |  | $ | — |  |  | $ | (5,236) |  |
| Total | $ | — |  |  | $ | (5,236) |  | (4) | $ | — |  |  | $ | (5,236) |  |

[0001408710-24-000032:notes:176]
(1)Foreign currency forward contracts with an aggregate notional amount of $8.0 million.

[0001408710-24-000032:notes:177]
(2)Foreign currency forward contracts with an aggregate notional amount of $127.0 million and 0.4 million Canadian dollars.

[0001408710-24-000032:notes:178]
(3)Foreign currency forward contracts with an aggregate notional amount of $3.0 million and 0.2 million Canadian dollars and interest rate swap agreement with notional amount of $60.9 million.

[0001408710-24-000032:notes:179]
(4)Foreign currency forward contracts with an aggregate notional amount of $140.0 million.

[0001408710-24-000032:notes:180]
Derivative Financial Instruments

[0001408710-24-000032:notes:181]
The Company utilizes derivative financial instruments to hedge (i) foreign exchange risk associated with certain foreign currency denominated assets and liabilities and other foreign currency transactions, and (ii) interest rate risk associated with its long-term debt.

[0001408710-24-000032:notes:182]
The Company minimizes the credit risk associated with its derivative instruments by limiting the exposure to any single counterparty and by entering into derivative instruments only with counterparties that meet the Company’s minimum credit quality standard.

[0001408710-24-000032:notes:183]
Foreign Currency Forward and Option Contracts

[0001408710-24-000032:notes:184]
As a result of foreign currency rate fluctuations, the U.S. dollar equivalent values of the Company’s foreign currency denominated assets and liabilities fluctuate. The Company uses foreign currency forward and option contracts to manage the foreign exchange risk associated with a portion of its foreign currency denominated assets and liabilities and other foreign currency transactions. The Company enters into foreign currency forward and option contracts to hedge

[0001408710-24-000032:notes:185]
fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht and Canadian dollars with counterparties that meet the Company’s minimum credit quality standard.

[0001408710-24-000032:notes:186]
The Company may enter into foreign currency forward contracts with maturities of up to 12 months to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht, including inventory purchases, payroll and other operating expenses. The Company considers these forward contracts as dual-purpose hedges, that hedge both the foreign exchange fluctuation (i) from inception through the forecasted expenditure, and (ii) any subsequent revaluation of the account payable or accrual. The Company may designate the forward contracts that hedge the foreign exchange fluctuation from inception through the forecasted expenditure as cash flow hedges. The gain or loss on a derivative instrument designated and qualified as a cash flow hedging instrument is recorded as a component of other comprehensive income and reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings. The reclassified amounts are presented in the same income statement line item as the earnings effect of the hedged item. Once the forecasted transactions are recorded, the Company will discontinue the hedging relationship by de-designating the derivative instrument and recording subsequent changes in fair value through contract maturity to foreign exchange gain (loss), net in the consolidated statements of operations and comprehensive income as a natural hedge against the Thai baht denominated assets and liabilities.

[0001408710-24-000032:notes:187]
The Company may also enter into non-designated foreign currency forward and option contracts to provide an offset to the re-measurement of foreign currency denominated assets and liabilities and to hedge certain forecasted exposures. Changes in the fair value of these non-designated derivatives are recorded through foreign exchange gain (loss), net in the consolidated statements of operations and comprehensive income.

[0001408710-24-000032:notes:188]
As of June 28, 2024, the Company had 135 outstanding U.S. dollar foreign currency forward contracts against Thai baht with an aggregate notional amount of $135.0 million and with maturity dates ranging from July 2024 through January 2025, and one foreign currency contract with a notional amount of 0.4 million Canadian dollars and with a maturity date in September 2024.

[0001408710-24-000032:notes:189]
As of June 30, 2023, the Company had 143 outstanding U.S. dollar foreign currency forward contracts against Thai baht with an aggregate notional amount of $143.0 million and with maturity dates ranging from July 2023 through January 2024, and one foreign currency contract with a notional amount of 0.2 million Canadian dollars and with a maturity date in September 2023.

[0001408710-24-000032:notes:190]
As of June 28, 2024, the hedging relationship over foreign currency forward contracts which were designated for hedge accounting had been tested to be highly effective based on the performance of retrospective and prospective regression testing. As of June 28, 2024, the amount in AOCI that is expected to be reclassified into earnings within 12 months as loss was $1.2 million.

[0001408710-24-000032:notes:191]
During the year ended June 28, 2024 and June 30, 2023, the Company included an unrealized gain of $0.7 million and $0.4 million, respectively, from changes in fair value of foreign currency forward and option contracts which were not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the consolidated statements of operations and comprehensive income.

[0001408710-24-000032:notes:192]
Interest Rate Swap Agreements

[0001408710-24-000032:notes:193]
The Company entered into interest rate swap agreements to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. As of June 28, 2024, the Company had no outstanding interest rate swap agreements  and as of June 30, 2023, the Company had one outstanding interest rate swap agreement with a notional amount of $60.9 million.

[0001408710-24-000032:notes:194]
On July 25, 2018, Fabrinet Thailand entered into an interest rate swap agreement to effectively convert the floating interest rate of the term loan under the Company's previous syndicated senior credit facility agreement to a fixed interest rate of 2.86% per annum through the scheduled maturity of the term loan in June 2023 (see Note 13). The Company did not designate this interest rate swap for hedge accounting.

[0001408710-24-000032:notes:195]
On September 3, 2019, Fabrinet Thailand entered into a term loan agreement under a credit facility agreement with Bank of Ayudhya Public Company Limited, and on September 10, 2019, the Company repaid in full the outstanding term loan under the Company's previous syndicated senior credit facility agreement (see Note 13) In conjunction with the funding of the new term loan, the Company entered into a second interest rate swap agreement. The combination of both of these interest rate swaps effectively converts the floating interest rate of the Company’s term loan with Bank of Ayudhya Public Company Limited to a fixed interest rate of 4.36% per annum through the maturity of the term loan in June 2024.

[0001408710-24-000032:notes:196]
On September 27, 2019, the Company designated these two interest rate swaps as a cash flow hedge for the Company’s term loan under the credit facility agreement with Bank of Ayudhya Public Company Limited. The combination of these two interest rate swaps qualified for hedge accounting because the hedges were highly effective, and the Company had

[0001408710-24-000032:notes:197]
designated and documented contemporaneously the hedging relationships involving these interest rate swaps, one of which matured in June 2023. While the Company intends to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in earnings. From September 27, 2019, any gains or losses related to these interest rate swaps are recorded in AOCI in the consolidated balance sheets. The Company reclassifies a portion of the gains or losses from AOCI into earnings at each reporting period based on either the accrued interest amount or the interest payment.

[0001408710-24-000032:notes:198]
As of June 28, 2024, there is no amount in AOCI that is expected to be reclassified into earnings within 12 months.

[0001408710-24-000032:notes:199]
The following table provides a summary of the impact of derivative gain (loss) of the Company’s foreign currency forward contracts and interest rate swaps which were designated as cash flow hedges on the consolidated statements of operations and other comprehensive income:

[0001408710-24-000032:notes:200]
|  |  |  | Year Ended |
| (in thousands) | Financial statementsline item |  | June 28,2024 |  | June 30,2023 |
| Derivatives gain (loss) recognized in other comprehensive income (loss): |  |  |  |  |  |
| Foreign currency forward contracts | Other comprehensive income |  | $ | 3,007 |  |  | $ | 1,142 |  |
| Interest rate swaps | Other comprehensive income |  | (215) |  |  | 1,302 |  |
| Total derivatives loss (gain) recognized in other comprehensive income |  |  | $ | 2,792 |  |  | $ | 2,444 |  |
| Derivatives loss (gain) reclassified from accumulated other comprehensive income into earnings: |  |  |  |  |  |
| Foreign currency forward contracts | Cost of revenues |  | $ | 8,563 |  |  | $ | 7,995 |  |
| Foreign currency forward contracts | Selling, general and administrative expenses |  | 357 |  |  | 334 |  |
| Foreign currency forward contracts | Foreign exchange gain (loss), net |  | (9,103) |  |  | (8,644) |  |
| Interest rate swaps | Interest expense |  | (220) |  |  | (588) |  |
| Total derivatives (gain) loss reclassified from accumulated other comprehensive income into earnings |  |  | $ | (403) |  |  | $ | (903) |  |
| Change in net unrealized gain (loss) on derivative instruments |  |  | $ | 2,389 |  |  | $ | 1,541 |  |

[0001408710-24-000032:notes:201]
Fair value of derivatives

[0001408710-24-000032:notes:202]
The following table provides the fair values of the Company’s derivative financial instruments for the periods presented:

[0001408710-24-000032:notes:203]
|  | June 28,2024 |  | June 30,2023 |
| (in thousands) | DerivativeAssets |  | DerivativeLiabilities |  | DerivativeAssets |  | DerivativeLiabilities |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts | $ | — |  |  | $ | (1,088) |  |  | $ | 2 |  |  | $ | (1,256) |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward contracts | 15 |  |  | (1,156) |  |  | 4 |  |  | (3,980) |  |
| Interest rate swaps | — |  |  | — |  |  | 215 |  |  | — |  |
| Derivatives, gross balances | 15 |  |  | (2,244) |  |  | 221 |  |  | (5,236) |  |

[0001408710-24-000032:notes:204]
The Company presents its derivatives at gross fair values in the consolidated balance sheets.

[0001408710-24-000032:notes:205]
The Company recorded the fair value of derivative financial instruments in the consolidated balance sheets as follows:

[0001408710-24-000032:notes:206]
| Derivative Financial Instruments | Balance Sheet line item |
| Fair Value of Derivative Assets | Other current assets, Other non-current assets |
| Fair Value of Derivative Liabilities | Accrued expenses, Other non-current liabilities |


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001408710-24-000032:notes:207]
Trade accounts receivable, net

[0001408710-24-000032:notes:208]
| (in thousands) | As of June 28,2024 |  | As of June 30,2023 |
| Trade accounts receivable | $ | 594,081 |  |  | $ | 532,732 |  |
| Less: Allowance for expected credit losses | (1,629) |  |  | (965) |  |
| Trade accounts receivable, net | $ | 592,452 |  |  | $ | 531,767 |  |

[0001408710-24-000032:notes:209]
The following tables summarize the movement in the Company’s expected credit losses during the years ended June 28, 2024 and June 30, 2023:

[0001408710-24-000032:notes:210]
| (in thousands) |  |  |  | Expected credit Losses |
| Balance as of June 24, 2022 |  |  |  | $ | 1,271 |  |
| Provision during the year |  |  |  | 1,410 |  |
| Reversal during the year |  |  |  | (1,716) |  |
| Balance as of June 30, 2023 |  |  |  | 965 |  |
| Provision during the year |  |  |  | 2,164 |  |
| Reversal during the year |  |  |  | (1,500) |  |
| Balance as of June 28, 2024 |  |  |  | $ | 1,629 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001408710-24-000032:notes:211]
Inventories

[0001408710-24-000032:notes:212]
| (in thousands) | As of June 28,2024 |  | As of June 30,2023 |
| Raw materials | $ | 139,063 |  |  | $ | 157,379 |  |
| Work in progress | 266,112 |  |  | 305,627 |  |
| Finished goods | 39,121 |  |  | 28,608 |  |
| Goods in transit | 18,910 |  |  | 27,962 |  |
| Inventories | $ | 463,206 |  |  | $ | 519,576 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001408710-24-000032:notes:213]
Leases
The Company leases facilities under non-cancelable operating lease agreements. The Company leases a portion of its capital equipment and vehicles, certain land and buildings for its facilities in Thailand, the Cayman Islands, the PRC, the U.S., Israel and Singapore under operating lease arrangements that expire at various dates through 2034. Certain of these lease arrangements provide the Company the ability to extend the lease term following the expiration of the current term. However, the Company has excluded all lease extension options from its right of use (“ROU”) assets and lease liabilities as the Company is not reasonably assured that it will exercise these options. None of the lease agreements contain residual value guarantees provided by the lessee. The Company also has one intercompany lease transaction in the form of a lease of office and manufacturing space.

[0001408710-24-000032:notes:214]
As of June 28, 2024, the maturities of the Company’s operating lease liabilities were as follows:

[0001408710-24-000032:notes:215]
| (in thousands) |  |  |
| 2025 | $ | 1,609 |  |  |
| 2026 | 1,554 |  |  |
| 2027 | 783 |  |  |
| 2028 | 343 |  |  |
| 2029 | 327 |  |  |
| Thereafter | 1,305 |  |  |
| Total undiscounted lease payments | 5,921 |  |  |
| Less: imputed interest | (931) |  |  |
| Total present value of lease liabilities | $ | 4,990 |  | (1) |

[0001408710-24-000032:notes:216]
(1)Includes current portion of operating lease liabilities of $1.4 million.

[0001408710-24-000032:notes:217]
Rental expense related to the Company’s operating leases is recognized on a straight-line basis over the lease term.

[0001408710-24-000032:notes:218]
Rental expense for long-term leases for the years ended June 28, 2024, June 30, 2023 and June 24, 2022 was $2.4 million, $2.4 million and $2.2 million, respectively.

[0001408710-24-000032:notes:219]
Rental expense for short-term leases for the years ended June 28, 2024, June 30, 2023 and June 24, 2022 was $0.9 million, $0.8 million and $0.2 million, respectively.

[0001408710-24-000032:notes:220]
The following summarizes additional information related to the Company’s operating leases:

[0001408710-24-000032:notes:221]
|  | As of June 28, 2024 |  | As of June 30, 2023 |
| Weighted-average remaining lease term (in years) |  |  |  |
| Operating leases | 5.6 |  | 1.2 |
| Weighted-average discount rate |  |  |  |
| Operating leases | 5.6 | % |  | 3.4 | % |

[0001408710-24-000032:notes:222]
The following information represents supplemental disclosure for the statement of cash flows related to operating leases:

[0001408710-24-000032:notes:223]
| (in thousands) | Year Ended June 28, 2024 |  | Year Ended June 30, 2023 |  | Year Ended June 24, 2022 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |
| Operating cash flows from operating leases | $ | 3,027 |  |  | $ | 2,477 |  |  | $ | 2,533 |  |
| Financing cash flows from finance leases | $ | — |  |  | $ | 9 |  |  | $ | 7 |  |
| ROU assets obtained in exchange for lease liabilities | $ | 5,797 |  |  | $ | 312 |  |  | $ | 38 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001408710-24-000032:notes:224]
Property, plant and equipment, net
The components of property, plant and equipment, net were as follows:

[0001408710-24-000032:notes:225]
| (in thousands) | Land andLandImprovements |  | BuildingandBuildingImprovements |  | ManufacturingEquipment |  | OfficeEquipment |  | MotorVehicles |  | Computers |  | ConstructionandMachineryUnderInstallation |  | Total |
| As of June 28, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost | $ | 61,297 |  |  | $ | 208,731 |  |  | $ | 316,867 |  |  | $ | 6,500 |  |  | $ | 1,101 |  |  | $ | 27,660 |  |  | $ | 12,243 |  |  | $ | 634,399 |  |
| Less: Accumulated depreciation | (328) |  |  | (82,964) |  |  | (216,667) |  |  | (5,521) |  |  | (870) |  |  | (20,520) |  |  | — |  |  | (326,870) |  |
| Less: Impairment reserve | — |  |  | — |  |  | (289) |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (289) |  |
| Net book value | $ | 60,969 |  |  | $ | 125,767 |  |  | $ | 99,911 |  |  | $ | 979 |  |  | $ | 231 |  |  | $ | 7,140 |  |  | $ | 12,243 |  |  | $ | 307,240 |  |
| As of June 30, 2023 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost | $ | 60,424 |  |  | $ | 200,039 |  |  | $ | 289,390 |  |  | $ | 6,362 |  |  | $ | 1,081 |  |  | $ | 24,951 |  |  | $ | 15,450 |  |  | $ | 597,697 |  |
| Less: Accumulated depreciation | (71) |  |  | (73,558) |  |  | (189,284) |  |  | (5,136) |  |  | (852) |  |  | (17,873) |  |  | — |  |  | (286,774) |  |
| Less: Impairment reserve | — |  |  | — |  |  | (573) |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (573) |  |
| Net book value | $ | 60,353 |  |  | $ | 126,481 |  |  | $ | 99,533 |  |  | $ | 1,226 |  |  | $ | 229 |  |  | $ | 7,078 |  |  | $ | 15,450 |  |  | $ | 310,350 |  |

[0001408710-24-000032:notes:226]
Depreciation expense amounted to $48.2 million, $42.5 million and $37.2 million for the years ended June 28, 2024, June 30, 2023 and June 24, 2022, respectively, and has been allocated between cost of revenues and selling, general and administrative expenses in the consolidated statements of operations and comprehensive income.

[0001408710-24-000032:notes:227]
The cost of fully depreciated property, plant and equipment written-off during the years ended June 28, 2024, June 30, 2023 and June 24, 2022 amounted to $10.7 million, $16.5 million and $25.1 million, respectively.

[0001408710-24-000032:notes:228]
As of June 28, 2024, June 30, 2023 and June 24, 2022, the Company recognized impairment reserves for property, plant and equipment of $0.3 million, $0.6 million and $0.6 million, respectively.

[0001408710-24-000032:notes:229]
During the year ended June 28, 2024, no borrowing costs capitalized, and during the year ended June 30, 2023, the Company had a de minimis amount of borrowing costs capitalized. During year ended June 24, 2022, the Company had capitalized $0.9 million of borrowing cost.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001408710-24-000032:notes:230]
Intangibles
The following tables present details of the Company’s intangibles:

[0001408710-24-000032:notes:231]
| (in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  |  |  | Net |
| As of June 28, 2024 |  |  |  |  |  |  |  |
| Software | $ | 11,398 |  |  | $ | (9,077) |  |  |  |  | $ | 2,321 |  |

[0001408710-24-000032:notes:232]
| (in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  |  |  | Net |
| As of June 30, 2023 |  |  |  |  |  |  |  |
| Software | $ | 10,533 |  |  | $ | (8,139) |  |  |  |  | $ | 2,394 |  |

[0001408710-24-000032:notes:233]
The Company recorded amortization expense relating to intangibles of $1.0 million, $1.3 million and $1.6 million for the years ended June 28, 2024, June 30, 2023 and June 24, 2022, respectively.

[0001408710-24-000032:notes:234]
The weighted-average remaining life of software was:

[0001408710-24-000032:notes:235]
| (years) | As of June 28, 2024 |  | As of June 30, 2023 |
| Software | 2.1 |  | 3.1 |

[0001408710-24-000032:notes:236]
Based on the carrying amount of intangibles as of June 28, 2024, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001408710-24-000032:notes:237]
| (in thousands) |  |
| 2025 | $ | 1,058 |  |
| 2026 | 599 |  |
| 2027 | 401 |  |
| 2028 | 229 |  |
| 2029 | 34 |  |
| Total | $ | 2,321 |  |


## us-gaap:DebtDisclosureTextBlock

[0001408710-24-000032:notes:238]
Borrowings
The Company’s total borrowings, including current and non-current portions of long-term borrowings, consisted of the following:

[0001408710-24-000032:notes:239]
| (in thousands of U.S. dollars) |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  | Maturity |  | As of June 28, 2024 |  | As of June 30, 2023 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum(1) |  | Repayable inquarterly installments |  | June 2024 |  | $ | — |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  |  | — |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  |  | $ | — |  |  | 12,156 |  |

[0001408710-24-000032:notes:240]
(1)The Company entered into interest rate swaps that effectively fix a series of future interest payments on its term loans. Refer to Note 7.

[0001408710-24-000032:notes:241]
The movements of long-term borrowings were as follows for the years ended June 28, 2024 and June 30, 2023:

[0001408710-24-000032:notes:242]
|  | Years ended |
| (in thousands) | June 28,2024 |  | June 30,2023 |
| Opening balance | $ | 12,188 |  |  | $ | 27,421 |  |
| Repayments during the period | (12,188) |  |  | (15,233) |  |
| Closing balance | $ | — |  |  | $ | 12,188 |  |

[0001408710-24-000032:notes:243]
Credit facilities agreements:

[0001408710-24-000032:notes:244]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a credit facility agreement (the “2019 Credit Facility Agreement”), which provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million that may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the 2019 Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

[0001408710-24-000032:notes:245]
Under the 2019 Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a term loan agreement (the "Term Loan Agreement") pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company's previous syndicated senior credit facility agreement.

[0001408710-24-000032:notes:246]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. On March 9, 2023, the Borrower and the Bank amended the Term Loan Agreement to replace the interest rate reference from LIBOR to the Secured Overnight Financing Rate ("SOFR") effective from September 29, 2023. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again.  During the year ended June 28, 2024, the Company recorded $0.3 million of interest expense in connection with this term loan, including the impact from interest rate swaps.

[0001408710-24-000032:notes:247]
Any borrowings under the 2019 Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

[0001408710-24-000032:notes:248]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, and restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also

[0001408710-24-000032:notes:249]
required to maintain a debt service coverage ratio of at least 1.25 times and a debt to equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times.

[0001408710-24-000032:notes:250]
The events of default under the Term Loan Agreement include failure to timely pay amounts due under the Term Loan Agreement or the related finance documents, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

[0001408710-24-000032:notes:251]
As of June 28, 2024, the term loan was fully repaid.

[0001408710-24-000032:notes:252]
On March 9, 2023, Fabrinet Thailand and the Parent Company (the “Borrowers”) and the Bank entered into a credit facility agreement (the “2023 Credit Facility Agreement”), which provides a facility of $55.0 million.

[0001408710-24-000032:notes:253]
Any borrowings under the 2023 Credit Facility Agreement are secured by land and buildings owned by the Borrowers in the Pathumthani and Chonburi Provinces in Thailand.

[0001408710-24-000032:notes:254]
Under the 2023 Credit Facility Agreement, the Borrowers are required to maintain a loan to value of the mortgaged real property ratio of not greater than 60%. The Borrowers are also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times.

[0001408710-24-000032:notes:255]
As of June 28, 2024, there was no amount outstanding under the 2023 Credit Facility Agreement. 
As of June 28, 2024, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.


## fn:AccruedSeveranceBenefitsDisclosureTextBlock

[0001408710-24-000032:notes:256]
Severance liabilities
The following table provides information regarding severance liabilities:

[0001408710-24-000032:notes:257]
|  | Years Ended |
| (in thousands) | June 28,2024 |  | June 30,2023 |
| Changes in severance liabilities |  |  |  |
| Balance, beginning of the fiscal year | $ | 22,370 |  |  | $ | 18,588 |  |
| Current service cost | $ | 2,655 |  |  | $ | 2,349 |  |
| Interest cost | 747 |  |  | 683 |  |
| Benefit paid | (320) |  |  | (288) |  |
| Unrealized loss (gain) on exchange rate | (837) |  |  | (58) |  |
| Actuarial (gain) loss on obligation | (310) |  |  | 1,089 |  |
| Adjustment defined benefit obligation | (212) |  |  | — |  |
| Foreign currency translation | — |  |  | 7 |  |
| Balance, end of the fiscal year | $ | 24,093 |  |  | $ | 22,370 |  |
| Changes in plan assets |  |  |  |
| Balance, beginning of the fiscal year | $ | 349 |  |  | $ | 338 |  |
| Adjustment plan assets | (349) |  |  | — |  |
| Foreign currency translation | — |  |  | 11 |  |
| Balance, end of the fiscal year | $ | — |  |  | $ | 349 |  |
| Underfunded status | $ | (24,093) |  |  | $ | (22,021) |  |

[0001408710-24-000032:notes:258]
The following table sets forth our severance liabilities as of June 28, 2024:

[0001408710-24-000032:notes:259]
| (in thousands) |  |
| 2025 | $ | 2,140 |  |
| 2026 | 1,550 |  |
| 2027 | 1,631 |  |
| 2028 | 2,221 |  |
| 2029 | 2,342 |  |
| Thereafter | 14,209 |  |
| Total | $ | 24,093 |  |

[0001408710-24-000032:notes:260]
The amount recognized in the consolidated balance sheets under non-current liabilities and non-current assets were determined as follows:

[0001408710-24-000032:notes:261]
| (in thousands) | As of June 28,2024 |  | As of June 30,2023 |
| Non-current assets | $ | — |  |  | $ | 138 |  |
| Non-current liabilities | $ | 24,093 |  |  | $ | 22,159 |  |

[0001408710-24-000032:notes:262]
The following table provides information regarding accumulated benefit obligations:

[0001408710-24-000032:notes:263]
| (in thousands) | As of June 28,2024 |  | As of June 30,2023 |
| Accumulated benefit obligations | $ | 16,403 |  |  | $ | 15,168 |  |

[0001408710-24-000032:notes:264]
The principal actuarial assumptions used were as follows:

[0001408710-24-000032:notes:265]
Weighted average actuarial assumptions used to determine severance liabilities

[0001408710-24-000032:notes:266]
|  | Years Ended |
|  | June 28, 2024 |  | June 30, 2023 |  | June 24, 2022 |
| Discount rate | 3.9% - 5.5% |  | 3.5% - 5.4% |  | 2.1% - 3.9% |
| Future salary increases | 3.5% - 10.0% |  | 3.5% - 10.0% |  | 3.5% - 10.0% |

[0001408710-24-000032:notes:267]
Weighted average actuarial assumptions used to determine benefit costs

[0001408710-24-000032:notes:268]
|  | Years Ended |
|  | June 28, 2024 |  | June 30, 2023 |  | June 24, 2022 |
| Discount rate | 5.4% |  | 3.8% |  | 2.0% |
| Expected long-term rate of return on assets | 5.2% |  | 3.4% |  | 2.1% |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001408710-24-000032:notes:269]
Share-based compensation
Share-based compensation

[0001408710-24-000032:notes:270]
The grant date fair value of restricted share units and performance share units is based on the market value of Fabrinet's ordinary shares on the date of grant.

[0001408710-24-000032:notes:271]
The effect of recording share-based compensation expense for the years ended June 28, 2024, June 30, 2023 and June 24, 2022 was as follows:

[0001408710-24-000032:notes:272]
|  | Years Ended |
| (in thousands) | June 28,2024 |  | June 30,2023 |  | June 24,2022 |
| Share-based compensation expense by type of award: |  |  |  |  |  |
| Restricted share units | $ | 16,839 |  |  | $ | 16,979 |  |  | $ | 15,150 |  |
| Performance share units | 11,535 |  |  | 11,148 |  |  | 12,898 |  |
| Total share-based compensation expense | 28,374 |  |  | 28,127 |  |  | 28,048 |  |
| Tax effect on share-based compensation expense | — |  |  | — |  |  | — |  |
| Net effect on share-based compensation expense | $ | 28,374 |  |  | $ | 28,127 |  |  | $ | 28,048 |  |

[0001408710-24-000032:notes:273]
Share-based compensation expense was recorded in the consolidated statements of operations and comprehensive income as follows:

[0001408710-24-000032:notes:274]
|  | Years Ended |
| (in thousands) | June 28,2024 |  | June 30,2023 |  | June 24,2022 |
| Cost of revenue | $ | 7,203 |  |  | $ | 6,664 |  |  | $ | 5,967 |  |
| Selling, general and administrative expense | 21,171 |  |  | 20,939 |  |  | 22,081 |  |
| Restructuring and other related costs | — |  |  | 524 |  |  | — |  |
| Total share-based compensation expense | $ | 28,374 |  |  | $ | 28,127 |  |  | $ | 28,048 |  |

[0001408710-24-000032:notes:275]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the years ended June 28, 2024, June 30, 2023 and June 24, 2022.

[0001408710-24-000032:notes:276]
Share-based award activity

[0001408710-24-000032:notes:277]
On December 12, 2019, the Company’s shareholders approved Fabrinet’s 2020 Equity Incentive Plan (the “2020 Plan”). Upon the approval of the 2020 Plan, Fabrinet’s Amended and Restated 2010 Performance Incentive Plan (the “2010 Plan”) was simultaneously terminated. The 2020 Plan provides for the grant of equity awards thereunder with respect to (i) 1,700,000 ordinary shares, plus (ii) up to 1,300,000 ordinary shares that, as of immediately prior to the termination of the 2010 Plan, had been reserved but not issued pursuant to any awards granted under the 2010 Plan and are not subject to any awards thereunder. Upon termination of the 2010 Plan, 1,281,619 ordinary shares were reserved for issuance under the 2020 Plan pursuant to clause (ii) of the preceding sentence.

[0001408710-24-000032:notes:278]
As of June 28, 2024, there were 306,660 restricted share units outstanding, 171,078 performance share units outstanding and 1,746,068 ordinary shares available for future grant under the 2020 Plan.

[0001408710-24-000032:notes:279]
On November 2, 2017, the Company adopted the 2017 Inducement Equity Incentive Plan (the “2017 Inducement Plan”) with a reserve of 160,000 ordinary shares authorized for future issuance solely for the granting of inducement share options and equity awards to new employees. The 2017 Inducement Plan was adopted without shareholder approval in reliance on the “employment inducement exemption” provided under the New York Stock Exchange Listed Company Manual.

[0001408710-24-000032:notes:280]
As of June 28, 2024, there were no awards outstanding and 111,347 ordinary shares available for future grant under the 2017 Inducement Plan.

[0001408710-24-000032:notes:281]
The 2020 Plan, 2010 Plan and 2017 Inducement Plan are collectively referred to as the “Equity Incentive Plans.”

[0001408710-24-000032:notes:282]
The following table summarizes the number of equity awards outstanding and ordinary shares available for grant under each of the Equity Incentive Plans as of June 28, 2024:

[0001408710-24-000032:notes:283]
| (share units) | Restricted Share Units outstanding |  | Performance Share Units outstanding |  | Ordinary Shares available for future grant |
| 2020 Plan | 306,660 |  |  | 171,078 |  |  | 1,746,068 |  |
| 2017 Inducement Plan | — |  |  | — |  |  | 111,347 |  |
| Total | 306,660 |  |  | 171,078 |  |  | 1,857,415 |  |

[0001408710-24-000032:notes:284]
Restricted share units and performance share units

[0001408710-24-000032:notes:285]
Restricted share units and performance share units have been granted under the Equity Incentive Plans.

[0001408710-24-000032:notes:286]
Restricted share units granted to employees generally vest in equal installments over three or four years  on each anniversary of the vesting commencement date. Restricted share units granted to non-employee directors generally cliff vest 100% on the first of January, approximately one year from the grant date, provided the director continues to serve through such date.

[0001408710-24-000032:notes:287]
Performance share units granted to executives will vest, if at all, at the end of a two-year performance period based on the Company’s achievement of pre-defined performance criteria, which consist of revenue and non-GAAP operating margin targets. The actual number of performance share units that may vest at the end of the performance period ranges from 0% to 100% of the award grant.

[0001408710-24-000032:notes:288]
The following table summarizes restricted share unit activity under the Equity Incentive Plans:

[0001408710-24-000032:notes:289]
|  | Number ofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 25, 2021 | 641,875 |  |  | $ | 55.74 |  |
| Granted | 186,633 |  |  | $ | 101.25 |  |
| Vested | (323,326) |  |  | $ | 52.20 |  |
| Forfeited | (45,556) |  |  | $ | 71.53 |  |
| Balance as of June 24, 2022 | 459,626 |  |  | $ | 75.14 |  |
| Granted | 165,378 |  |  | $ | 117.35 |  |
| Vested | (233,607) |  |  | $ | 67.85 |  |
| Forfeited | (22,632) |  |  | $ | 94.69 |  |
| Balance as of June 30, 2023 | 368,765 |  |  | $ | 97.49 |  |
| Granted | 126,934 |  |  | $ | 165.54 |  |
| Vested | (171,304) |  |  | $ | 88.69 |  |
| Forfeited | (17,735) |  |  | $ | 124.52 |  |
| Balance as of June 28, 2024 | 306,660 |  |  | $ | 129.01 |  |
| Expected to vest as of June 28, 2024 | 274,066 |  |  | $ | 129.26 |  |

[0001408710-24-000032:notes:290]
The following table summarizes performance share unit activity under the Equity Incentive Plans:

[0001408710-24-000032:notes:291]
|  | Number ofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 25, 2021 | 427,028 |  |  | $ | 57.82 |  |
| Granted | 110,832 |  |  | $ | 101.05 |  |
| Vested | (190,213) |  |  | 48.65 |  |
| Forfeited | (61,765) |  |  | $ | 53.38 |  |
| Balance as of June 24, 2022 | 285,882 |  |  | $ | 81.64 |  |
| Granted | 97,142 |  |  | $ | 117.35 |  |
| Vested | (179,008) |  |  | $ | 70.05 |  |
| Forfeited | — |  |  | $ | — |  |
| Balance as of June 30, 2023 | 204,016 |  |  | $ | 108.81 |  |
| Granted | 73,936 |  |  | $ | 158.91 |  |
| Vested | (106,874) |  |  | 101.05 |  |
| Forfeited | — |  |  | $ | — |  |
| Balance as of June 28, 2024 | 171,078 |  |  | $ | 135.31 |  |
| Expected to vest as of June 28, 2024 | 171,078 |  |  | $ | 135.31 |  |

[0001408710-24-000032:notes:292]
The total fair value of restricted share units and performance share units vested during the years ended June 28, 2024, June 30, 2023 and June 24, 2022 was $26.0 million, $28.4 million and $24.2 million, respectively. The aggregate intrinsic value of restricted share units and performance share units outstanding as of June 28, 2024 was $116.9 million.

[0001408710-24-000032:notes:293]
As of June 28, 2024, there was $13.4 million and $6.8 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.5 years and 1.0 year, respectively.

[0001408710-24-000032:notes:294]
For the years ended June 28, 2024 and June 30, 2023, the Company withheld an aggregate of 104,892 shares and 177,139 shares, respectively, upon the vesting of restricted share units and performance shares units, based upon the closing share price on the vesting date to settle employee tax withholding obligations. For the years ended June 28, 2024 and June 30, 2023, the Company then remitted cash of $13.2 million and $18.2 million, respectively, to the appropriate taxing authorities, and presented it as a financing activity within the consolidated statements of cash flows. The payment was recorded as a reduction of additional paid-in capital.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001408710-24-000032:notes:295]
Employee benefit plans
Employee contribution plan

[0001408710-24-000032:notes:296]
The Company operates a defined contribution plan, known as a provident fund, in its subsidiaries in Thailand and the United Kingdom. The assets of these plans are in separate trustee-administered funds. The provident fund is funded by matching payments from employees and by the subsidiaries on a monthly basis. Current contributions to the provident fund are accrued and paid to the fund manager on a monthly basis. The Company’s contributions to the provident fund amounted to $7.0 million, $6.3 million and $6.1 million during the years ended June 28, 2024, June 30, 2023 and June 24, 2022, respectively.

[0001408710-24-000032:notes:297]
The Company sponsors the Fabrinet U.S. 401(k) Retirement Plan (“401(k) Plan”), a Defined Contribution Plan under ERISA, at its subsidiaries in the United States which provides retirement benefits for eligible employees through tax deferred salary deductions. The 401(k) Plan allows employees to contribute up to 80% of their annual compensation, subject to annual contributions limits established by the Internal Revenue Service. The Company provides for a 100% match of employees’ contributions to the 401(k) Plan up to the first 6% of annual compensation. All matching contributions are made in cash and vest immediately. The Company’s matching contributions to the 401(k) Plan were $1.0 million, $0.8 million and $0.7 million during the years ended June 28, 2024, June 30, 2023 and June 24, 2022, respectively.

[0001408710-24-000032:notes:298]
Executive incentive plan and employee performance bonuses

[0001408710-24-000032:notes:299]
For the years ended June 28, 2024 and June 30, 2023, the Company maintained an executive incentive plan with quantitative objectives, based on achieving certain revenue and non-U.S. GAAP operating margin or gross margin

[0001408710-24-000032:notes:300]
targets. During the years ended June 28, 2024, June 30, 2023 and June 24, 2022, discretionary merit-based bonus awards were also available to Fabrinet’s non-executive employees.

[0001408710-24-000032:notes:301]
Bonus distributions to employees were $13.5 million, $13.0 million and $11.0 million for the years ended June 28, 2024, June 30, 2023 and June 24, 2022, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001408710-24-000032:notes:302]
Shareholders’ equity
Share capital

[0001408710-24-000032:notes:303]
Fabrinet’s authorized share capital is 500,000,000 ordinary shares, par value of $0.01 per ordinary share, and 5,000,000 preferred shares, par value of $0.01 per preferred share.

[0001408710-24-000032:notes:304]
For the year ended June 28, 2024, Fabrinet issued 173,286 ordinary shares upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-24-000032:notes:305]
For the year ended June 30, 2023, Fabrinet issued 235,476 ordinary shares upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-24-000032:notes:306]
For the year ended June 24, 2022, Fabrinet issued 299,655 ordinary shares upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-24-000032:notes:307]
All such issued shares are fully paid.

[0001408710-24-000032:notes:308]
In August 2017, the Company’s board of directors approved a share repurchase program to permit the Company to repurchase up to $30.0 million worth of its issued and outstanding ordinary shares in the open market in accordance with applicable rules and regulations. In February 2018, May 2019, August 2020, August 2022, and August 2023, the Company’s board of directors approved an increase of $30.0 million, $50.0 million, $58.5 million, $78.7 million, and  $47.6 million, respectively, to the original share repurchase authorization, bringing the aggregate authorization to $294.8 million.

[0001408710-24-000032:notes:309]
During the year ended June 28, 2024, the Company repurchased 211,726 shares under the program at an average price per share (excluding other direct costs) of $186.49, totaling $39.5 million. As of June 28, 2024, the Company had a remaining authorization to repurchase up to $60.5 million of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001408710-24-000032:notes:310]
Accumulated other comprehensive income (loss) (“AOCI”)
The changes in AOCI for the years ended June 28, 2024 and June 30, 2023 were as follows:

[0001408710-24-000032:notes:311]
| (in thousands) | Unrealized Gains(Losses) onAvailable-for-saleSecurities |  | UnrealizedGains (Losses)on DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 24, 2022 | $ | (6,018) |  |  | $ | (5,082) |  |  | $ | (803) |  |  | $ | (890) |  |  | $ | (12,793) |  |
| Other comprehensive income (loss) before reclassification | 2,646 |  |  | 2,444 |  |  | — |  |  | (75) |  |  | 5,015 |  |
| Amounts reclassified from AOCI | 93 |  |  | (903) |  |  | 473 |  |  | — |  |  | (337) |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | 2,739 |  |  | 1,541 |  |  | 473 |  |  | (75) |  |  | 4,678 |  |
| Balance as of June 30, 2023 | (3,279) |  |  | (3,541) |  |  | (330) |  |  | (965) |  |  | (8,115) |  |
| Other comprehensive income (loss) before reclassification | 2,099 |  |  | 2,792 |  |  | — |  |  | (17) |  |  | 4,874 |  |
| Amounts reclassified from AOCI | 1 |  |  | (403) |  |  | 330 |  |  | — |  |  | (72) |  |
| Tax effects | — |  |  | 172 |  |  | — |  |  | — |  |  | 172 |  |
| Other comprehensive income (loss) | 2,100 |  |  | 2,561 |  |  | 330 |  |  | (17) |  |  | 4,974 |  |
| Balance as of June 28, 2024 | $ | (1,179) |  |  | $ | (980) |  |  | $ | — |  |  | $ | (982) |  |  | $ | (3,141) |  |

[0001408710-24-000032:notes:312]
The following table presents the pre-tax amounts reclassified from AOCI into the consolidated statements of operations and comprehensive income for the years ended June 28, 2024 and June 30, 2023, respectively.

[0001408710-24-000032:notes:313]
| (in thousands) |  |  |  | Years Ended |
| AOCI components |  | Financial statementsline item |  | June 28,2024 |  | June 30,2023 |
| Unrealized gains (losses) on available-for-sale securities |  | Interest income |  | $ | 1 |  |  | $ | 93 |  |
| Unrealized gains (losses) on derivative instruments |  | Cost of revenues |  | 8,563 |  |  | 7,995 |  |
| Unrealized gains (losses) on derivative instruments |  | Selling, general and administrative expenses |  | 357 |  |  | 334 |  |
| Unrealized gains (losses) on derivative instruments |  | Foreign exchange gain (loss), net |  | (9,103) |  |  | (8,644) |  |
| Unrealized gains (losses) on derivative instruments |  | Interest expense |  | (220) |  |  | (588) |  |
| Retirement benefit plan – Prior service cost |  | Selling, general and administrative expenses |  | 330 |  |  | 473 |  |
| Total amounts reclassified from AOCI |  |  |  | $ | (72) |  |  | $ | (337) |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001408710-24-000032:notes:314]
Commitments and contingencies
Bank guarantees

[0001408710-24-000032:notes:315]
As of June 28, 2024 and June 30, 2023, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.0 million and $1.5 million, respectively, or Thai Baht 73.2 million and Thai Baht 53.0 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the subsidiary's operations related to the Israeli Customs department.

[0001408710-24-000032:notes:316]
Purchase obligations

[0001408710-24-000032:notes:317]
Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001408710-24-000032:notes:318]
As of June 28, 2024, the Company had purchase obligations and other commitments to third parties of $933.3 million.

[0001408710-24-000032:notes:319]
Capital expenditure

[0001408710-24-000032:notes:320]
As of June 28, 2024, the Company had total capital expenditure commitments to third parties of $21.9 million.

[0001408710-24-000032:notes:321]
Indemnification of directors and officers

[0001408710-24-000032:notes:322]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001408710-24-000032:notes:323]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.

[0001408710-24-000032:notes:324]
Litigation and claim

[0001408710-24-000032:notes:325]
On June 28, 2024, Ngan In Leng and First Laser Limited (collectively, the “Plaintiffs”) filed a complaint in the Fuzhou

[0001408710-24-000032:notes:326]
Intermediate People’s Court (the “Court”) in Fuzhou, China against Fujian Enterprises (Holdings) Co., Ltd. (“FEHC”), Jian An Investment Limited (“Jian”), and Casix, Inc. (“Casix”), the Company's wholly-owned subsidiary located in the PRC. The complaint alleges unjust enrichment related to a purported investment in Casix by the Plaintiffs in 1997, which predates the Company's acquisition of Casix from JDS Uniphase Corporation. The Plaintiffs have requested that the Court order FEHC to return the unjust enrichment to the Plaintiffs in the amount of RMB 400 million, with interest from March 1, 2000, and order Jian and Casix to bear joint and several liability for all payment obligations of FEHC. At this time, the Company is not able to quantify any potential liability in connection with this litigation because the case is in its early stages.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001408710-24-000032:notes:327]
Restructuring and other related costs
Restructuring and other related costs may consist of severance-related charges, asset-related charges and other costs due to exit activities. The Company recognizes severance-related charges depending on whether the termination benefits are provided under an ongoing benefit arrangement or under a one-time benefit arrangement. The Company recognizes the charges once the benefits have been communicated to employees.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001408710-24-000032:notes:328]
Business segments and geographic information
Operating segments are defined as components of an enterprise that engage in business activities for which discrete financial information is available that is evaluated regularly by the chief operating decision maker (the “CODM”) in deciding how to allocate resources and in assessing performance. The Company’s CODM is Fabrinet’s Chief Executive Officer. As of June 28, 2024, June 30, 2023 and June 24, 2022, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete financial information with respect to separate product lines and does not have separate reportable segments.

[0001408710-24-000032:notes:329]
For the Company’s revenues by geographic region, see “Revenue by Geographic Area and End Market” in Note 3.

[0001408710-24-000032:notes:330]
The following table presents long-lived assets by the country in which they are based:

[0001408710-24-000032:notes:331]
|  |  | Years Ended |
| (in thousands) |  | June 28,2024 |  | June 30,2023 |  | June 24,2022 |
| Long-Lived Assets: |  |  |  |  |  |  |
| Thailand |  | $ | 261,141 |  |  | $ | 264,382 |  |  | $ | 240,750 |  |
| U.S. |  | 28,914 |  |  | 25,267 |  |  | 25,938 |  |
| China |  | 14,586 |  |  | 17,407 |  |  | 19,686 |  |
| Israel |  | 2,160 |  |  | 2,796 |  |  | 4,025 |  |
| Others |  | 439 |  |  | 498 |  |  | 1,878 |  |
| Total |  | 307,240 |  |  | 310,350 |  |  | 292,277 |  |

[0001408710-24-000032:notes:332]
Significant customers

[0001408710-24-000032:notes:333]
Total revenues, by percentage, from individual customers representing 10% or more of total revenues in the respective periods were as follows:

[0001408710-24-000032:notes:334]
|  | Years Ended |
|  | June 28,2024 |  | June 30,2023 |  | June 24,2022 |
| Nvidia Corporation | 35.1 | % |  | 12.5 | % |  | * |
| Cisco Systems Inc. | 13.4 | % |  | 15.6 | % |  | 25.4 | % |
| Lumentum Operations LLC | * |  | 15.4 | % |  | 10.3 | % |
| Infinera Corporation | * |  | 12.4 | % |  | 12.5 | % |

[0001408710-24-000032:notes:335]
*    Represents less than 10% of total revenues.

[0001408710-24-000032:notes:336]
Accounts receivable from individual customers representing 10% or more of accounts receivable as of June 28, 2024 and June 30, 2023, respectively, were as follows:

[0001408710-24-000032:notes:337]
|  | As of June 28,2024 |  | As of June 30,2023 |
| Nvidia Corporation | 22.7 | % |  | 14.0 | % |
| Infinera Corporation | 19.3 | % |  | 20.5 | % |
| Cisco Systems Inc. | 12.4 | % |  | * |
| Lumentum Operations LLC | * |  | 13.7 | % |

[0001408710-24-000032:notes:338]
*    Represents less than 10% of total accounts receivable.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001408710-24-000032:notes:339]
Financial instruments
Objectives and significant terms and conditions

[0001408710-24-000032:notes:340]
The principal financial risks faced by the Company are foreign currency risk and interest rate risk. The Company borrows at floating rates of interest to finance its operations. A minority of sales and purchases and a majority of labor and overhead costs are entered into in foreign currencies. In order to manage the risks arising from fluctuations in currency exchange rates, the Company uses derivative instruments. Trading for speculative purposes is prohibited under Company policies.

[0001408710-24-000032:notes:341]
The Company enters into short-term foreign currency forward and option contracts to manage foreign currency exposures associated with certain assets, liabilities and other forecasted foreign currency transactions and may designate these instruments as hedging instruments. The foreign currency forward and option contracts generally have maturities of up to twelve months. All foreign currency exchange contracts are recognized on the consolidated balance sheets at fair value. Gain or loss on the Company’s derivative instruments generally offset the assets, liabilities under master netting arrangement and transactions economically hedged.

[0001408710-24-000032:notes:342]
Foreign currency risk

[0001408710-24-000032:notes:343]
The Company operates internationally and is exposed to foreign exchange risk arising from various currency exposures primarily with respect to the Thai baht, RMB and GBP.

[0001408710-24-000032:notes:344]
Interest Rate Risk

[0001408710-24-000032:notes:345]
The Company’s principal interest bearing assets are time deposits and short-term investments with maturities of three years or less held with high quality financial institutions. The Company’s principal interest bearing liabilities are bank loans which bear interest at floating rates.

[0001408710-24-000032:notes:346]
The Company entered into interest rate swap agreements (the “Swap Agreements”) to manage this risk and increase the profile of the Company’s debt obligation. The terms of the Swap Agreements allow the Company to effectively convert the floating interest rate to a fixed interest rate. This locks the variable in interest expenses associated with our floating rate borrowings and results in fixed interest expenses, which is unsusceptible to market rate increase. The Company designated the Swap Agreements as a cash flow hedge, and they qualify for hedge accounting because the hedges are highly effective. While the Company intend to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in our earnings. From September 27, 2019, any gains or losses related to these outstanding interest rate swaps will be recorded in accumulated other comprehensive income in the consolidated balance sheets, with subsequent reclassification to interest expense when settled.


## us-gaap:SubsequentEventsTextBlock

[0001408710-24-000032:notes:347]
Subsequent Event
In August 2024, the Company’s board of directors approved the repurchase of up to an additional $139.5 million of the Company’s outstanding ordinary shares, bringing the aggregate authorization under the Company’s existing share repurchase program to $434.3 million, with $200.0 million currently remaining.
