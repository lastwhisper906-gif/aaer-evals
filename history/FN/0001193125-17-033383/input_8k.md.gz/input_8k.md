# FN 8-K — 0001193125-17-031868 filed 2017-02-06

## item codes, every 8-K on or before 2017-02-07

- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2017-02-07

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-031868:8k_2_02:1]
EX-99.1
2
d334406dex991.htm
EX-99.1

[0001193125-17-031868:8k_2_02:2]
EX-99.1

[0001193125-17-031868:8k_2_02:3]
Exhibit 99.1

[0001193125-17-031868:8k_2_02:4]
Fabrinet Announces Second Quarter Fiscal-Year 2017

[0001193125-17-031868:8k_2_02:5]
Financial Results

[0001193125-17-031868:8k_2_02:6]
Revenue and Earnings Exceed High-End of Guidance Ranges

[0001193125-17-031868:8k_2_02:7]
Tom Mitchell to Transition Following CEO Search

[0001193125-17-031868:8k_2_02:8]
BANGKOK, Thailand – February 6, 2017 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical,
electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for the second fiscal quarter ended December 30, 2016.

[0001193125-17-031868:8k_2_02:9]
Tom Mitchell, Chief Executive Officer of Fabrinet, said: “We exceeded our guidance for the second quarter, with revenue that grew 51% from a year ago. We
are enthusiastic about our continued business momentum, driven by on-going strength in the optical market and new customer programs. We’re also excited to see the beginning of the transfer of programs from our new product introduction facility
in Santa Clara to Thailand, and believe our growing NPI pipeline will support our growth in the years ahead.”

[0001193125-17-031868:8k_2_02:10]
Mr. Mitchell added, “On a
personal note, at my request, our board of directors has initiated a CEO succession plan. We have retained an executive search firm to assist in identifying and evaluating candidates. We have no set timeline for this process. I intend to continue to
play a leadership role in the Company after we appoint a new CEO.”

[0001193125-17-031868:8k_2_02:11]
Second Quarter Fiscal-Year 2017 Financial Highlights

[0001193125-17-031868:8k_2_02:12]
GAAP Results

[0001193125-17-031868:8k_2_02:13]
|  | • |  | Revenue for the second quarter of fiscal year 2017 was $351.2 million, an increase of 51% compared to revenue of $233.0 million for the comparable period in fiscal year 2016. |

[0001193125-17-031868:8k_2_02:14]
|  | • |  | GAAP net income for the second quarter of fiscal year 2017 was $25.3 million, compared to GAAP net income of $19.8 million in the second quarter of fiscal year 2016. |

[0001193125-17-031868:8k_2_02:15]
|  | • |  | GAAP net income per diluted share for the second quarter of fiscal year 2017 was $0.67, compared to GAAP net income per diluted share of $0.54 in the second quarter of fiscal year 2016. |

[0001193125-17-031868:8k_2_02:16]
Non-GAAP Results

[0001193125-17-031868:8k_2_02:17]
|  | • |  | Non-GAAP net income in the second quarter of fiscal 2017 was $34.5 million, an increase of 89% compared to non-GAAP net income of $18.2 million in the same period a year ago. |

[0001193125-17-031868:8k_2_02:18]
|  | • |  | Non-GAAP net income per diluted share in the second quarter of fiscal 2017 was $0.91, an increase from non-GAAP net income per diluted share of $0.50 in the same period a year ago. |

[0001193125-17-031868:8k_2_02:19]
Business Outlook

[0001193125-17-031868:8k_2_02:20]
Based on information available as of
February 6, 2017, Fabrinet is issuing guidance for the third quarter of fiscal-year 2017 ending March 31, 2017, as follows:

[0001193125-17-031868:8k_2_02:21]
|  | • |  | Fabrinet expects revenue for the third quarter to be in the range of $360 million to $364 million. |

[0001193125-17-031868:8k_2_02:22]
|  | • |  | GAAP net income per diluted share is expected to be in the range of $0.66 to $0.68, based on approximately 38.0 million fully diluted shares outstanding. |

[0001193125-17-031868:8k_2_02:23]
|  | • |  | Non-GAAP net income per diluted share is expected to be in the range of $0.87 to $0.89, based on approximately 38.0 million fully diluted shares outstanding. |

[0001193125-17-031868:8k_2_02:24]
Conference Call Information

[0001193125-17-031868:8k_2_02:25]
| What: |  | Fabrinet Second Quarter Fiscal-Year 2017 Financial Results Conference Call |
| When: |  | Monday, February 6, 2017 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic |
|  |  | (253) 237-1137, international |
|  |  | Passcode: 52651124 |
| Replay: |  | (855) 859-2056, domestic |
|  |  | (404) 537-3406, international |
|  |  | Passcode: 52651124 |
| Webcast: |  | http://investor.fabrinet.com (live and replay) |

[0001193125-17-031868:8k_2_02:26]
This press release and any other information related to the call also will be posted on Fabrinet’s website at
http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-17-031868:8k_2_02:27]
About Fabrinet

[0001193125-17-031868:8k_2_02:28]
Fabrinet is a leading provider of
advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, industrial lasers
and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging,
integration, final assembly and test. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the
People’s Republic of China and the United Kingdom. For more information visit: www.fabrinet.com.

[0001193125-17-031868:8k_2_02:29]
Forward-Looking Statements

[0001193125-17-031868:8k_2_02:30]
Use of Non-GAAP Financials

[0001193125-17-031868:8k_2_02:31]
The Company refers to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information
regarding the Company’s ongoing operational performance. Non-GAAP net income excludes share-based compensation expenses, executive separation costs, income or expense related to flooding, amortization of debt issuance costs, unrealized gain or
loss on foreign currency, business combination expenses, and amortization of intangible assets. We have excluded these items in order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures
has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in
conjunction with GAAP financial measures.

[0001193125-17-031868:8k_2_02:32]
These non-GAAP financial measures are used to: (1) measure company performance against historical results,
(2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial
measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001193125-17-031868:8k_2_02:33]
SOURCE: Fabrinet

[0001193125-17-031868:8k_2_02:34]
Investor Contact:

[0001193125-17-031868:8k_2_02:35]
Garo Toomajanian

[0001193125-17-031868:8k_2_02:36]
ir@fabrinet.com

[0001193125-17-031868:8k_2_02:37]
FABRINET

[0001193125-17-031868:8k_2_02:38]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-17-031868:8k_2_02:39]
| (in thousands of U.S. dollars, except share data) |  | December 30,2016 |  |  | June 24,2016 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 85,619 |  |  | $ | 142,804 |  |
| Marketable securities |  |  | 170,508 |  |  |  | 141,709 |  |
| Trade accounts receivable, net |  |  | 240,887 |  |  |  | 196,145 |  |
| Inventory, net |  |  | 214,375 |  |  |  | 181,499 |  |
| Deferred tax assets |  |  | — |  |  |  | 1,358 |  |
| Prepaid expenses |  |  | 2,407 |  |  |  | 3,114 |  |
| Other current assets |  |  | 4,604 |  |  |  | 6,662 |  |
| Total current assets |  |  | 718,400 |  |  |  | 673,291 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Restricted cash in connection with business acquisition |  |  | 3,126 |  |  |  | — |  |
| Property, plant and equipment, net |  |  | 213,987 |  |  |  | 178,410 |  |
| Intangibles, net |  |  | 5,048 |  |  |  | 499 |  |
| Goodwill |  |  | 2,529 |  |  |  | — |  |
| Deferred tax assets |  |  | 1,879 |  |  |  | 1,806 |  |
| Deferred debt issuance costs on revolving loan and other non-current assets |  |  | 950 |  |  |  | 1,851 |  |
| Total non-current assets |  |  | 227,519 |  |  |  | 182,566 |  |
| Total Assets |  | $ | 945,919 |  |  | $ | 855,857 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Bank borrowings, net of unamortized debt issuance costs |  | $ | 38,287 |  |  | $ | 24,307 |  |
| Trade accounts payable |  |  | 187,306 |  |  |  | 172,052 |  |
| Fixed assets payable |  |  | 17,094 |  |  |  | 20,628 |  |
| Capital lease liability, current portion |  |  | 362 |  |  |  | — |  |
| Income tax payable |  |  | 2,491 |  |  |  | 2,010 |  |
| Accrued payroll, bonus and related expenses |  |  | 11,365 |  |  |  | 12,300 |  |
| Accrued expenses |  |  | 13,712 |  |  |  | 8,072 |  |
| Other payables |  |  | 12,440 |  |  |  | 16,356 |  |
| Total current liabilities |  |  | 283,057 |  |  |  | 255,725 |  |
| Non-current liabilities |  |  |  |  |
| Long-term loan from bank, non-current portion, net of unamortized debt issuance costs |  |  | 29,412 |  |  |  | 36,100 |  |
| Deferred tax liability |  |  | — |  |  |  | 854 |  |
| Capital lease liability, non-current portion |  |  | 1,108 |  |  |  | — |  |
| Deferred liability in connection with business acquisition |  |  | 3,126 |  |  |  | — |  |
| Severance liabilities |  |  | 7,277 |  |  |  | 6,684 |  |
| Other non-current liabilities |  |  | 2,274 |  |  |  | 2,075 |  |
| Total non-current liabilities |  |  | 43,197 |  |  |  | 45,713 |  |
| Total Liabilities |  |  | 326,254 |  |  |  | 301,438 |  |
| Commitments and contingencies (Note 16) |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of December 30, 2016 and June 24, 2016) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 36,918,462 shares and 36,156,446 shares issued and outstanding as of December 30, 2016 and June 24, 2016, respectively) |  |  | 369 |  |  |  | 362 |  |
| Additional paid-in capital |  |  | 121,366 |  |  |  | 102,325 |  |
| Accumulated other comprehensive (loss) income |  |  | (1,269 | ) |  |  | 591 |  |
| Retained earnings |  |  | 499,199 |  |  |  | 451,141 |  |
| Total Shareholders’ Equity |  |  | 619,665 |  |  |  | 554,419 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 945,919 |  |  | $ | 855,857 |  |

[0001193125-17-031868:8k_2_02:40]
4

[0001193125-17-031868:8k_2_02:41]
FABRINET

[0001193125-17-031868:8k_2_02:42]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-17-031868:8k_2_02:43]
AND COMPREHENSIVE INCOME

[0001193125-17-031868:8k_2_02:44]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (in thousands of U.S. dollars, except per share amounts) |  | December 30,2016 |  |  | December 25,2015 |  |  | December 30,2016 |  |  | December 25,2015 |  |
| Revenues |  | $ | 351,156 |  |  | $ | 233,038 |  |  | $ | 683,199 |  |  | $ | 449,471 |  |
| Cost of revenues |  |  | (308,110 | ) |  |  | (204,545 | ) |  |  | (600,545 | ) |  |  | (394,967 | ) |
| Gross profit |  |  | 43,046 |  |  |  | 28,493 |  |  |  | 82,654 |  |  |  | 54,504 |  |
| Selling, general and administrative expenses |  |  | (17,651 | ) |  |  | (13,715 | ) |  |  | (33,483 | ) |  |  | (25,615 | ) |
| Other expense related to flooding |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (864 | ) |
| Operating income |  |  | 25,395 |  |  |  | 14,778 |  |  |  | 49,171 |  |  |  | 28,025 |  |
| Interest income |  |  | 320 |  |  |  | 455 |  |  |  | 757 |  |  |  | 897 |  |
| Interest expense |  |  | (555 | ) |  |  | (419 | ) |  |  | (1,876 | ) |  |  | (821 | ) |
| Foreign exchange gain (loss), net |  |  | 1,945 |  |  |  | 6,166 |  |  |  | 3,602 |  |  |  | (4,326 | ) |
| Other income |  |  | 147 |  |  |  | 106 |  |  |  | 289 |  |  |  | 209 |  |
| Income before income taxes |  |  | 27,252 |  |  |  | 21,086 |  |  |  | 51,943 |  |  |  | 23,984 |  |
| Income tax expense |  |  | (1,960 | ) |  |  | (1,283 | ) |  |  | (3,885 | ) |  |  | (2,578 | ) |
| Net income |  |  | 25,292 |  |  |  | 19,803 |  |  |  | 48,058 |  |  |  | 21,406 |  |
| Other comprehensive loss, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in net unrealized loss on marketable securities |  |  | (353 | ) |  |  | (310 | ) |  |  | (540 | ) |  |  | (223 | ) |
| Change in net unrealized loss on derivative instruments |  |  | — |  |  |  | — |  |  |  | (158 | ) |  |  | — |  |
| Change in foreign currency translation adjustment |  |  | (1,903 | ) |  |  | — |  |  |  | (1,162 | ) |  |  | — |  |
| Total other comprehensive loss, net of tax |  |  | (2,256 | ) |  |  | (310 | ) |  |  | (1,860 | ) |  |  | (223 | ) |
| Net comprehensive income |  | $ | 23,036 |  |  | $ | 19,493 |  |  | $ | 46,198 |  |  | $ | 21,183 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.69 |  |  | $ | 0.55 |  |  | $ | 1.31 |  |  | $ | 0.60 |  |
| Diluted |  | $ | 0.67 |  |  | $ | 0.54 |  |  | $ | 1.28 |  |  | $ | 0.59 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 36,848 |  |  |  | 35,812 |  |  |  | 36,626 |  |  |  | 35,695 |  |
| Diluted |  |  | 37,805 |  |  |  | 36,826 |  |  |  | 37,567 |  |  |  | 36,570 |  |

[0001193125-17-031868:8k_2_02:45]
5

[0001193125-17-031868:8k_2_02:46]
FABRINET

[0001193125-17-031868:8k_2_02:47]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-17-031868:8k_2_02:48]
|  |  | Six Months Ended |  |
| (in thousands of U.S. dollars) |  | December 30,2016 |  |  | December 25,2015 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income for the period |  | $ | 48,058 |  |  | $ | 21,406 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 10,758 |  |  |  | 8,294 |  |
| Loss (gain) on disposal of property, plant and equipment |  |  | 19 |  |  |  | (49 | ) |
| Loss from sales and maturities of available-for-sale securities |  |  | 15 |  |  |  | 124 |  |
| Amortization of investment premium |  |  | 228 |  |  |  | 457 |  |
| Amortization of deferred debt issuance costs |  |  | 1,072 |  |  |  | 358 |  |
| Reversal of allowance for doubtful accounts |  |  | (40 | ) |  |  | (7 | ) |
| Unrealized (gain) loss on exchange rate and fair value of derivative instruments |  |  | (3,033 | ) |  |  | 5,566 |  |
| Share-based compensation |  |  | 14,208 |  |  |  | 5,783 |  |
| Deferred income tax |  |  | 938 |  |  |  | 413 |  |
| Other non-cash expenses |  |  | 586 |  |  |  | 765 |  |
| Reversal of inventory obsolescence |  |  | (100 | ) |  |  | (478 | ) |
| Loss from written-off inventory due to flood loss |  |  | — |  |  |  | 233 |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | (40,779 | ) |  |  | (12,486 | ) |
| Inventory |  |  | (29,286 | ) |  |  | (10,004 | ) |
| Other current assets and non-current assets |  |  | 4,747 |  |  |  | 1,019 |  |
| Trade accounts payable |  |  | 11,026 |  |  |  | (405 | ) |
| Income tax payable |  |  | 448 |  |  |  | 320 |  |
| Other current liabilities and non-current liabilities |  |  | 887 |  |  |  | 2,395 |  |
| Net cash provided by operating activities |  |  | 19,752 |  |  |  | 23,704 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of marketable securities |  |  | (83,405 | ) |  |  | (53,258 | ) |
| Proceeds from sales of marketable securities |  |  | 15,682 |  |  |  | 25,709 |  |
| Proceeds from maturities of marketable securities |  |  | 38,142 |  |  |  | 34,460 |  |
| Payments in connection with business acquisition, net of cash acquired |  |  | (9,917 | ) |  |  | — |  |
| Purchase of property, plant and equipment |  |  | (44,412 | ) |  |  | (26,407 | ) |
| Purchase of intangibles |  |  | (319 | ) |  |  | (210 | ) |
| Proceeds from disposal of property, plant and equipment |  |  | 127 |  |  |  | 58 |  |
| Net cash used in investing activities |  |  | (84,102 | ) |  |  | (19,648 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Payment of debt issuance costs |  |  | — |  |  |  | (359 | ) |
| Proceeds of short-term loans from banks |  |  | 15,744 |  |  |  | 18,000 |  |
| Repayment of long-term loans from bank |  |  | (9,800 | ) |  |  | (3,000 | ) |
| Repayment of capital lease liability |  |  | (92 | ) |  |  | — |  |
| Proceeds from issuance of ordinary shares under employee share option plans |  |  | 5,848 |  |  |  | 2,025 |  |
| Withholding tax related to net share settlement of restricted share units |  |  | (1,008 | ) |  |  | (1,711 | ) |
| Net cash provided by financing activities |  |  | 10,692 |  |  |  | 14,955 |  |
| Net (decrease) increase in cash, cash equivalents and restricted cash |  |  | (53,658 | ) |  |  | 19,011 |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 142,804 |  |  |  | 112,978 |  |
| (Decrease) increase in cash, cash equivalents and restricted cash |  |  | (53,658 | ) |  |  | 19,011 |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash |  |  | (401 | ) |  |  | (630 | ) |
| Cash, cash equivalents and restricted cash at end of period |  | $ | 88,745 |  |  | $ | 131,359 |  |
| Non-cash investing and financing activities |  |  |  |  |  |  |  |  |
| Construction, software-related and equipment-related payables |  | $ | 17,094 |  |  | $ | 6,657 |  |

[0001193125-17-031868:8k_2_02:49]
FABRINET

[0001193125-17-031868:8k_2_02:50]
Reconciliation of GAAP measures to non-GAAP measures

[0001193125-17-031868:8k_2_02:51]
| (in thousands of U.S. dollars, except per share data) |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 30, 2016 |  |  | December 25, 2015 |  |  | December 30, 2016 |  |  | December 25, 2015 |  |
|  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |
| GAAP measures |  |  | 25,292 |  |  |  | 0.67 |  |  |  | 19,803 |  |  |  | 0.54 |  |  |  | 48,058 |  |  |  | 1.28 |  |  |  | 21,406 |  |  |  | 0.59 |  |
| Items reconciling GAAP net income (loss) & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,514 |  |  |  | 0.04 |  |  |  | 540 |  |  |  | 0.01 |  |  |  | 2,528 |  |  |  | 0.07 |  |  |  | 1,077 |  |  |  | 0.03 |  |
| Total related to gross profit |  |  | 1,514 |  |  |  | 0.04 |  |  |  | 540 |  |  |  | 0.01 |  |  |  | 2,528 |  |  |  | 0.07 |  |  |  | 1,077 |  |  |  | 0.03 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 7,083 |  |  |  | 0.19 |  |  |  | 2,570 |  |  |  | 0.07 |  |  |  | 11,680 |  |  |  | 0.31 |  |  |  | 4,706 |  |  |  | 0.13 |  |
| Executive separation cost |  |  | — |  |  |  | — |  |  |  | 552 |  |  |  | 0.01 |  |  |  | 577 |  |  |  | 0.02 |  |  |  | 552 |  |  |  | 0.01 |  |
| Amortization of intangible assets |  |  | 229 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 229 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |
| Business combination expenses |  |  | 99 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |  |  | 1,510 |  |  |  | 0.04 |  |  |  | — |  |  |  | — |  |
| Total related to selling, general and administrative expenses |  |  | 7,411 |  |  |  | 0.20 |  |  |  | 3,122 |  |  |  | 0.08 |  |  |  | 13,996 |  |  |  | 0.37 |  |  |  | 5,258 |  |  |  | 0.14 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Expenses/(income) related to flooding |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 864 |  |  |  | 0.02 |  |
| Amortization of debt issuance costs |  |  | 281 |  |  |  | 0.01 |  |  |  | 187 |  |  |  | 0.01 |  |  |  | 1,344 |  |  |  | 0.04 |  |  |  | 358 |  |  |  | 0.01 |  |
| (Gain)/loss on foreign currency |  |  | — |  |  |  | — |  |  |  | (5,418 | ) |  |  | (0.15 | ) |  |  | (1,713 | ) |  |  | (0.05 | ) |  |  | 5,479 |  |  |  | 0.15 |  |
| Total related to other incomes and other expenses |  |  | 281 |  |  |  | 0.01 |  |  |  | (5,231 | ) |  |  | (0.14 | ) |  |  | (369 | ) |  |  | (0.01 | ) |  |  | 6,701 |  |  |  | 0.18 |  |
| Total related to net income & EPS |  |  | 9,206 |  |  |  | 0.24 |  |  |  | (1,569 | ) |  |  | (0.04 | ) |  |  | 16,155 |  |  |  | 0.43 |  |  |  | 13,036 |  |  |  | 0.35 |  |
| Non-GAAP measures |  |  | 34,498 |  |  |  | 0.91 |  |  |  | 18,234 |  |  |  | 0.50 |  |  |  | 64,213 |  |  |  | 1.71 |  |  |  | 34,442 |  |  |  | 0.94 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 37,805 |  |  |  |  |  |  |  | 36,826 |  |  |  |  |  |  |  | 37,567 |  |  |  |  |  |  |  | 36,570 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 37,805 |  |  |  |  |  |  |  | 36,826 |  |  |  |  |  |  |  | 37,567 |  |  |  |  |  |  |  | 36,570 |  |

[0001193125-17-031868:8k_2_02:52]
7

[0001193125-17-031868:8k_2_02:53]
Fabrinet Guidance for Quarter Ending March 31, 2017

[0001193125-17-031868:8k_2_02:54]
Items reconciling GAAP EPS to non-GAAP EPS:

[0001193125-17-031868:8k_2_02:55]
|  |  | DilutedEPS |  |
| GAAP net income per diluted share: |  | $ | 0.66 to $0.68 |  |
| Related to cost of revenues: |  |  |  |  |
| Share-based compensation expenses |  | $ | 0.04 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |
| Share-based compensation expenses |  | $ | 0.15 |  |
| Business combination expenses |  | $ | 0.00 |  |
| Amortization of intangible assets |  | $ | 0.01 |  |
| Share-based compensation expenses |  | $ | 0.16 |  |
| Related to other incomes and other expenses: |  |  |  |  |
| Amortization of debt issuance costs |  | $ | 0.00 |  |
| Total related to net income & EPS |  | $ | 0.21 |  |
| Non-GAAP net income per diluted share |  | $ | 0.87 to $0.89 |  |

[0001193125-17-031868:8k_2_02:56]
8

## item 5.02 — body, verbatim

[0001193125-17-031868:8k_body:1]
Item 5.02

[0001193125-17-031868:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001193125-17-031868:8k_body:3]
The information set forth in Item 8.01 of this Current Report on Form 8-K is incorporated herein by reference.
