# FN notes — 0001193125-17-033383


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-17-033383:notes:1]
The following table summarizes the cost and estimated fair value of
 marketable securities classified as available-for-sale securities
 based on stated effective maturities as of December 30,
 2016:

[0001193125-17-033383:notes:2]
| (amount in thousands) |  | Carrying Cost |  |  | Fair Value |  |
| Due within one year |  | $ | 22,773 |  |  | $ | 22,763 |  |
| Due between one to three years |  |  | 147,876 |  |  |  | 147,745 |  |
| Total |  | $ | 170,649 |  |  | $ | 170,508 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-17-033383:notes:3]
| 16. | Commitments and contingencies |

[0001193125-17-033383:notes:4]
Bank guarantees

[0001193125-17-033383:notes:5]
As of December 30, 2016 and June 24, 2016, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $1.4 million and $0.8 million, respectively.

[0001193125-17-033383:notes:6]
Operating lease commitments

[0001193125-17-033383:notes:7]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, New Jersey and the United Kingdom under operating
 lease arrangements that expire in various calendar years through
 2023. Rental expense under these operating leases amounted to $0.8
 million and $0.6 million for the six months ended December 30,
 2016 and December 25, 2015, respectively.

[0001193125-17-033383:notes:8]
As of December 30, 2016, the future minimum lease payments due
 under non-cancelable operating leases during each fiscal year were
 as follows:

[0001193125-17-033383:notes:9]
| (amount in thousands) |  |  |  |
| 2017 (remaining six months) |  | $ | 867 |  |
| 2018 |  |  | 1,641 |  |
| 2019 |  |  | 1,104 |  |
| 2020 |  |  | 902 |  |
| 2021 |  |  | 503 |  |
| Thereafter |  |  | 850 |  |
| Total minimum operating lease payments |  | $ | 5,867 |  |

[0001193125-17-033383:notes:10]
Capital lease commitments

[0001193125-17-033383:notes:11]
In connection with the acquisition of Exception EMS, the Company
 assumed the capital lease commitments of several machines and
 equipment, with various expiration dates until September 2020. The
 equipment can be purchased at the determined prices upon expiration
 of such contracts.

[0001193125-17-033383:notes:12]
As of December 30, 2016, the future minimum lease payments due
 under non-cancelable capital leases during each fiscal year were as
 follows:

[0001193125-17-033383:notes:13]
| (amount in thousands) |  |  |  |
| 2017 (remaining six months) |  | $ | 180 |  |
| 2018 |  |  | 387 |  |
| 2019 |  |  | 419 |  |
| 2020 |  |  | 385 |  |
| 2021 |  |  | 99 |  |
| Total minimum capital lease payments |  | $ | 1,470 |  |

[0001193125-17-033383:notes:14]
Purchase obligations

[0001193125-17-033383:notes:15]
Purchase obligations represent legally-binding commitments to
 purchase inventory and other commitments made in the normal course
 of business to meet operational requirements. Although open
 purchase orders are considered enforceable and legally binding,
 their terms generally give the Company the option to cancel,
 reschedule and/or adjust its requirements based on its business
 needs prior to the delivery of goods or performance of services.
 Obligations to purchase inventory and other commitments are
 generally expected to be fulfilled within one year.

[0001193125-17-033383:notes:16]
On December 23, 2016, the Company entered into an agreement to
 purchase a parcel of land in Chonburi, Thailand, to support the
 expansion of the Company’s production in Thailand. The
 aggregate purchase price is approximately $5.6 million, of which
 the first installment of $1.1 million was paid by the Company on
 January 10, 2017. The Company expects to pay the remaining
 balance of the purchase price on or before December 25,
 2017.

[0001193125-17-033383:notes:17]
As of December 30, 2016, the Company had an outstanding
 commitment to third parties of approximately $11.9 million.

[0001193125-17-033383:notes:18]
Indemnification of directors and officers

[0001193125-17-033383:notes:19]
Cayman Islands law does not limit the extent to which a
 company’s memorandum and articles of association may provide
 for indemnification of directors and officers, except to the extent
 any such provision may be held by the Cayman Islands courts to be
 contrary to public policy, such as to provide indemnification
 against civil fraud or the consequences of committing a crime.
 Fabrinet’s amended and restated memorandum and articles of
 association provide for indemnification of directors and officers
 for actions, costs, charges, losses, damages and expenses incurred
 in their capacities as such, except that such indemnification does
 not extend to any matter in respect of any fraud or dishonesty that
 may attach to any of them.

[0001193125-17-033383:notes:20]
In accordance with Fabrinet’s form of indemnification
 agreement for its directors and officers, Fabrinet has agreed to
 indemnify its directors and officers against certain liabilities
 and expenses incurred by such persons in connection with claims by
 reason of their being such a director or officer. Fabrinet
 maintains a director and officer liability insurance policy that
 may enable it to recover a portion of any future amounts paid under
 the indemnification agreements.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-17-033383:notes:21]
[same as prior period, unchanged from 0001193125-16-764312:notes:20]

[0001193125-17-033383:notes:22]
[same as prior period, unchanged from 0001193125-16-764312:notes:21]

[0001193125-17-033383:notes:23]
In determining the grant date fair value of equity awards, the
 Company is required to determine the fair value of Fabrinet’s
 ordinary shares and make estimates of expected dividends to be
 issued, expected volatility of Fabrinet’s ordinary shares,
 expected forfeitures of the awards, risk free interest rates for
 the expected term of the awards, expected terms of the awards, and
 the vesting period of the respective awards. Forfeitures are
 estimated at the time of grant and revised if necessary in
 subsequent periods if actual forfeitures differ from those
 estimates.

[0001193125-17-033383:notes:24]
The effect of recording share-based compensation expense for the
 three and six months ended December 30, 2016 and
 December 25, 2015 was as follows:

[0001193125-17-033383:notes:25]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands) |  | December 30, 2016 |  |  | December 25, 2015 |  |  | December 30, 2016 |  |  | December 25, 2015 |  |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share options |  | $ | — |  |  | $ | 2 |  |  | $ | — |  |  | $ | 18 |  |
| Restricted share units |  |  | 7,633 |  |  |  | 3,108 |  |  |  | 12,453 |  |  |  | 5,765 |  |
| Performance share units |  |  | 964 |  |  |  | — |  |  |  | 1,755 |  |  |  | — |  |
| Total share-based compensation expense |  |  | 8,597 |  |  |  | 3,110 |  |  |  | 14,208 |  |  |  | 5,783 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 8,597 |  |  | $ | 3,110 |  |  | $ | 14,208 |  |  | $ | 5,783 |  |

[0001193125-17-033383:notes:26]
[same as prior period, unchanged from 0001193125-16-764312:notes:25]

[0001193125-17-033383:notes:27]
|  |  | Three Months ended |  |  | Six Months Ended |  |
| (amount in thousands) |  | December 30, 2016 |  |  | December 25, 2015 |  |  | December 30, 2016 |  |  | December 25, 2015 |  |
| Cost of revenue |  | $ | 1,514 |  |  | $ | 540 |  |  | $ | 2,528 |  |  | $ | 1,077 |  |
| Selling, general and administrative expense |  |  | 7,083 |  |  |  | 2,570 |  |  |  | 11,680 |  |  |  | 4,706 |  |
| Total share-based compensation expense |  | $ | 8,597 |  |  | $ | 3,110 |  |  | $ | 14,208 |  |  | $ | 5,783 |  |

[0001193125-17-033383:notes:28]
The Company did not capitalize any share-based compensation expense
 as part of any asset costs during the three and six months ended
 December 30, 2016 and December 25, 2015.

[0001193125-17-033383:notes:29]
[same as prior period, unchanged from 0001193125-16-764312:notes:28]

[0001193125-17-033383:notes:30]
Share options have been granted to directors and employees. As of
 December 30, 2016, there were no share options outstanding
 under Fabrinet’s Amended and Restated 1999 Share Option Plan
 (the “1999 Plan”). Additional option grants may not be
 made under the 1999 Plan.

[0001193125-17-033383:notes:31]
As of December 30, 2016, there were an aggregate of 99,263
 share options outstanding, 1,462,170 restricted share units
 outstanding and 234,678 performance share units outstanding under
 Fabrinet’s 2010 Performance Incentive Plan (the “2010
 Plan”). As of December 30, 2016, there were 1,230,956
 ordinary shares available for future grant under the 2010 Plan. The
 1999 Plan and 2010 Plan are collectively referred to as the
 “Share Option Plans.”

[0001193125-17-033383:notes:32]
[same as prior period, unchanged from 0001193125-16-764312:notes:31]

[0001193125-17-033383:notes:33]
[same as prior period, unchanged from 0001193125-16-764312:notes:32]

[0001193125-17-033383:notes:34]
[same as prior period, unchanged from 0001193125-16-764312:notes:33]

[0001193125-17-033383:notes:35]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price Per Share |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 24, 2016 |  |  | 464,334 |  |  |  | 464,334 |  |  | $ | 15.95 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (365,066 | ) |  |  |  |  |  | $ | 16.02 |  |  |  |  |  |
| Forfeited |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Expired |  |  | (5 | ) |  |  |  |  |  | $ | 5.75 |  |  |  |  |  |
| Balance as of December 30, 2016 |  |  | 99,263 |  |  |  | 99,263 |  |  | $ | 15.71 |  |  |  |  |  |

[0001193125-17-033383:notes:36]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price Per Share |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 26, 2015 |  |  | 792,019 |  |  |  | 758,451 |  |  | $ | 16.33 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (130,779 | ) |  |  |  |  |  | $ | 15.48 |  |  |  |  |  |
| Forfeited |  |  | (213 | ) |  |  |  |  |  | $ | 14.43 |  |  |  |  |  |
| Expired |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Balance as of December 25, 2015 |  |  | 661,027 |  |  |  | 660,035 |  |  | $ | 16.50 |  |  |  |  |  |

[0001193125-17-033383:notes:37]
The following summarizes information for share options outstanding
 as of December 30, 2016 under the Share Option Plans:

[0001193125-17-033383:notes:38]
|  |  | Range of Exercise Price |  |  | Number of Shares Underlying Options |  |  | Weighted- Average Remaining Contractual Life (years) |  |  | Aggregate Intrinsic Value (amount in thousands) |  |
|  |  |  | $14.12 – $15.05 |  |  |  | 55,238 |  |  |  | 1.31 |  |  |  |  |  |
|  |  |  | $15.16 – $16.83 |  |  |  | 36,975 |  |  |  | 0.96 |  |  |  |  |  |
|  |  |  | $18.60 – $26.16 |  |  |  | 7,050 |  |  |  | 1.92 |  |  |  |  |  |
| Options outstanding |  |  |  |  |  |  | 99,263 |  |  |  | 1.22 |  |  | $ | 2,441 |  |
| Options exercisable |  |  |  |  |  |  | 99,263 |  |  |  | 1.22 |  |  | $ | 2,441 |  |

[0001193125-17-033383:notes:39]
As of December 30, 2016, there was no unrecognized
 compensation cost under the Share Option Plans.

[0001193125-17-033383:notes:40]
[same as prior period, unchanged from 0001193125-16-764312:notes:38]

[0001193125-17-033383:notes:41]
[same as prior period, unchanged from 0001193125-16-764312:notes:39]

[0001193125-17-033383:notes:42]
[same as prior period, unchanged from 0001193125-16-764312:notes:40]

[0001193125-17-033383:notes:43]
The Company has entered into an employment agreement, as amended on
 August 12, 2016, with an executive of the Company that
 provides for accelerated vesting of equity awards under certain
 circumstances, including upon termination of employment. In
 addition, if the executive’s employment with the Company
 continues through and including February 20, 2017,
 (1) any outstanding equity awards granted to the executive
 prior to August 2016 will become 100% vested and (2) certain
 restricted share units granted to the executive in August 2016 will
 become 100% vested.

[0001193125-17-033383:notes:44]
[same as prior period, unchanged from 0001193125-16-764312:notes:42]

[0001193125-17-033383:notes:45]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 24, 2016 |  |  | 1,181,402 |  |  | $ | 18.34 |  |
| Granted |  |  | 741,973 |  |  | $ | 39.23 |  |
| Issued |  |  | (423,035 | ) |  | $ | 16.41 |  |
| Forfeited |  |  | (38,170 | ) |  | $ | 22.35 |  |
| Balance as of December 30, 2016 |  |  | 1,462,170 |  |  | $ | 29.40 |  |

[0001193125-17-033383:notes:46]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 26, 2015 |  |  | 1,140,927 |  |  | $ | 16.03 |  |
| Granted |  |  | 539,772 |  |  | $ | 19.57 |  |
| Issued |  |  | (388,425 | )(1) |  | $ | 15.27 |  |
| Forfeited |  |  | (15,415 | ) |  | $ | 18.39 |  |
| Balance as of December 25, 2015 |  |  | 1,276,859 |  |  | $ | 17.27 |  |

[0001193125-17-033383:notes:47]
| (1) | Includes 849 shares vested on December 1, 2015, but not settled as of December 25, 2015. |

[0001193125-17-033383:notes:48]
[same as prior period, unchanged from 0001193125-16-764312:notes:45]

[0001193125-17-033383:notes:49]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 24, 2016 |  |  | — |  |  |  | — |  |
| Granted |  |  | 234,678 |  |  | $ | 40.48 |  |
| Issued |  |  | — |  |  |  | — |  |
| Forfeited |  |  | — |  |  |  | — |  |
| Balance as of December 30, 2016 |  |  | 234,678 |  |  | $ | 40.48 |  |

[0001193125-17-033383:notes:50]
As of December 30, 2016, there was $32.3 million of
 unrecognized share-based compensation expense related to restricted
 share units and performance share units under the 2010 Plan that is
 expected to be recorded over a weighted-average period of 2.07
 years.

[0001193125-17-033383:notes:51]
For the six months ended December 30, 2016 and
 December 25, 2015, the Company withheld an aggregate of 26,085
 shares and 84,269 shares, respectively, upon the vesting of
 restricted share units, based upon the closing share price on the
 vesting date to settle the employees’ minimum statutory
 obligation for the applicable income and other employment taxes.
 For the six months ended December 30, 2016 and
 December 25, 2015, the Company then remitted cash of $1.0
 million and $1.7 million, respectively, to the appropriate taxing
 authorities, and presented it as a financing activity within the
 unaudited condensed consolidated statements of cash flows. The
 payment had the effect on shares issued by the Company as it
 reduced the number of shares that would have been issued on the
 vesting date and was recorded as a reduction of additional paid-in
 capital.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-17-033383:notes:52]
[same as prior period, unchanged from 0001193125-16-764312:notes:49]

[0001193125-17-033383:notes:53]
| (amount in thousands) |  | As of December 30, 2016 |  |  | As of June 24, 2016 |  |
| Raw materials |  | $ | 64,101 |  |  | $ | 58,199 |  |
| Work in progress |  |  | 114,352 |  |  |  | 94,762 |  |
| Finished goods |  |  | 27,008 |  |  |  | 21,593 |  |
| Goods in transit |  |  | 11,776 |  |  |  | 9,381 |  |
|  |  |  | 217,237 |  |  |  | 183,935 |  |
| Less: Inventory obsolescence |  |  | (2,862 | ) |  |  | (2,436 | ) |
| Inventory, net |  | $ | 214,375 |  |  | $ | 181,499 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-17-033383:notes:54]
New Accounting Pronouncements – adopted by the
 Company

[0001193125-17-033383:notes:55]
In November 2016, the FASB issued ASU 2016-18, “Statement of
 Cash Flows (Topic 230): Restricted Cash,” which requires the
 statement of cash flows to explain the change during the period in
 the total of cash, cash equivalents and restricted cash or
 restricted cash equivalents. The Company has early adopted this
 update in the second quarter of fiscal year 2017 on a retrospective
 basis but there was no impact to the presentation of the
 comparative period in the unaudited condensed consolidated
 financial statements.

[0001193125-17-033383:notes:56]
In November 2015, the FASB issued ASU 2015-17, “Balance Sheet
 Classification of Deferred Taxes,” which will require
 entities to present deferred tax assets (“DTAs”) and
 deferred tax liabilities (“DTLs”) as non-current in a
 classified balance sheet. The ASU simplifies the current guidance,
 which requires entities to separately present DTAs and DTLs as
 current and non-current in a classified balance sheet. The Company
 has early adopted this update in the first quarter of fiscal year
 2017. Accordingly, as of December 30, 2016, DTAs of $0.8
 million were classified to non-current assets in the unaudited
 condensed consolidated balance sheets. The Company adopted this
 update on a prospective basis and did not change the presentation
 of the comparative period.

[0001193125-17-033383:notes:57]
In September 2015, the FASB issued ASU 2015-16, “Business
 Combinations (Topic 805): Simplifying the Accounting for
 Measurement-Period Adjustments” which require an acquirer to
 recognize adjustments to provisional amounts that are identified
 during the measurement period in the reporting period in which the
 adjustment amounts are determined. The Company has adopted this
 update and applied it on a prospective basis.

[0001193125-17-033383:notes:58]
In July 2015, the FASB issued ASU 2015-11, “Inventory (Topic
 330): Simplifying the Measurement of Inventory.” The update
 provides the guidance that an entity, that measured inventory by
 using first-in, first-out or average cost, should measure inventory
 at the lower of cost and net realizable value. Subsequent
 measurement is unchanged for inventory measured using last-in,
 first-out or the retail inventory method. The Company has adopted
 this update with no impact to the unaudited condensed consolidated
 financial statements.

[0001193125-17-033383:notes:59]
In April 2015, the FASB issued ASU 2015-03, “Interest –
 Imputation of Interest (Subtopic 835-30): Simplifying the
 Presentation of Debt Issuance Costs.” The update requires
 debt issuance costs related to a recognized debt liability be
 presented in the balance sheet as a direct deduction from the
 carrying amount of the related debt liability instead of being
 presented as an asset. Debt disclosures will include the face
 amount of the debt liability and the effective interest rate. The
 update requires retrospective application and represents a change
 in accounting principle. Additionally, in August 2015, the FASB
 issued ASU 2015-15, “Interest – Imputation of Interest
 (Subtopic 835-30): Presentation and Subsequent Measurement of Debt
 Issuance Costs Associated with Line-of-Credit Arrangements”
 to amend ASU 2015-03. The Company has adopted this amendment
 retrospectively. As of December 30, 2016 and June 24,
 2016, debt issuance costs of $0.4 million and $0.6 million,
 respectively, related to a recognized debt liability are presented
 in the balance sheet as a direct reduction of the carrying amount
 of the related debts.

[0001193125-17-033383:notes:60]
In February 2015, the FASB issued ASU 2015-02, “Consolidation
 (Topic 810): Amendments to the Consolidation Analysis.” ASU
 No. 2015-02 amended the process that a reporting entity must
 perform to determine whether it should consolidate certain types of
 legal entities. The Company has adopted this update with no impact
 to the unaudited condensed consolidated financial statements.

[0001193125-17-033383:notes:61]
In January 2015, the FASB issued ASU 2015-01, “Income
 Statement – Extraordinary and Unusual Items (Subtopic
 225-20): Simplifying Income Statement Presentation by Eliminating
 the Concept of Extraordinary Items.” The objective of this
 amendment is to reduce the complexity in accounting standards by
 eliminating the concept of extraordinary items from U.S. GAAP. To
 meet for extraordinary classification the underlying event or
 transaction should (a) possess a high degree of abnormality
 and be of a type clearly unrelated to, or only incidentally related
 to, the ordinary and typical activities of the entity and
 (b) not reasonably be expected to recur in the foreseeable
 future. The Company has adopted this update with no impact to the
 unaudited condensed consolidated financial statements.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-17-033383:notes:62]
The changes in AOCI for the six months ended December 30, 2016
 were as follows:

[0001193125-17-033383:notes:63]
| (amount in thousands) |  | Unrealized net Gains (Losses) on Marketable Securities |  |  | Unrealized net Gains (Losses) on Derivative Instruments |  |  | Foreign Currency Translation Adjustment |  |  | Total |  |
| Balance as of June 24, 2016 |  | $ | 399 |  |  | $ | 192 |  |  | $ | — |  |  | $ | 591 |  |
| Other comprehensive income before reclassification adjustment |  |  | (525 | ) |  |  | — |  |  |  | (1,162 | ) |  |  | (1,687 | ) |
| Amounts reclassified out of AOCI to foreign exchange loss in the unaudited condensed consolidated statement of operations and comprehensive income |  |  | (15 | ) |  |  | (158 | ) |  |  | — |  |  |  | (173 | ) |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive loss |  | $ | (540 | ) |  | $ | (158 | ) |  | $ | (1,162 | ) |  | $ | (1,860 | ) |
| Balance as of December 30, 2016 |  | $ | (141 | ) |  | $ | 34 |  |  | $ | (1,162 | ) |  | $ | (1,269 | ) |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001193125-17-033383:notes:64]
The movements of long-term loans were as follows for the six months
 ended December 30, 2016 and December 25, 2015:

[0001193125-17-033383:notes:65]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 30, 2016 |  |  | December 25, 2015 |  |
| Opening balance |  | $ | 54,500 |  |  | $ | 10,500 |  |
| Repayments during the period |  |  | (9,800 | ) |  |  | (3,000 | ) |
| Closing balance |  | $ | 44,700 |  |  | $ | 7,500 |  |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock

[0001193125-17-033383:notes:66]
Undrawn available credit facilities classified by availability
 period of future borrowing as of December 30, 2016 and
 June 24, 2016 were as follows:

[0001193125-17-033383:notes:67]
| (amount in thousands) |  | December 30, 2016 |  |  | June 24, 2016 |  |
| Short-term |  | $ | 3,395 |  |  | $ | 1,414 |  |
| Long-term |  | $ | 136,800 |  |  | $ | 143,500 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-17-033383:notes:68]
bill-to-location of the customers. The Company operates primarily
 in three geographic regions: North America, Asia-Pacific and
 Europe. The following table presents total revenues by geographic
 regions:

[0001193125-17-033383:notes:69]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands) |  | December 30, 2016 |  |  | December 25, 2015 |  |  | December 30, 2016 |  |  | December 25, 2015 |  |
| North America |  | $ | 157,997 |  |  | $ | 124,154 |  |  | $ | 323,992 |  |  | $ | 230,597 |  |
| Asia-Pacific |  |  | 136,692 |  |  |  | 84,354 |  |  |  | 251,437 |  |  |  | 168,243 |  |
| Europe |  |  | 56,467 |  |  |  | 24,530 |  |  |  | 107,770 |  |  |  | 50,631 |  |
|  |  | $ | 351,156 |  |  | $ | 233,038 |  |  | $ | 683,199 |  |  | $ | 449,471 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-17-033383:notes:70]
[same as prior period, unchanged from 0001193125-16-764312:notes:65]

[0001193125-17-033383:notes:71]
[same as prior period, unchanged from 0001193125-16-764312:notes:66]

[0001193125-17-033383:notes:72]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of December 30, 2016 and for the
 three and six months ended December 30, 2016 and
 December 25, 2015 includes normal recurring adjustments,
 necessary for a fair statement of the financial statements set
 forth herein, in accordance with accounting principles generally
 accepted in the United States of America (“U.S. GAAP”)
 for interim financial information and the rules and regulations of
 the Securities and Exchange Commission (“SEC”).
 Accordingly, such information does not include all of the
 information and footnotes required by U.S. GAAP for annual
 financial statements. For further information, please refer to the
 consolidated financial statements and footnotes thereto included in
 Fabrinet’s Annual Report on Form 10-K for the year ended
 June 24, 2016.

[0001193125-17-033383:notes:73]
The balance sheet as of June 24, 2016 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three and six
 months ended December 30, 2016 may not be indicative of
 results for the year ending June 30, 2017 or any future
 periods.

[0001193125-17-033383:notes:74]
[same as prior period, unchanged from 0001193125-16-764312:notes:69]

[0001193125-17-033383:notes:75]
On September 14, 2016, the Company acquired 100% shareholding
 in Global CEM Solutions, Ltd. and all of its subsidiaries
 (including Exception EMS), a privately-held group located
 in Wiltshire, United Kingdom. The unaudited condensed
 consolidated financial statements of the Company include the
 financial position, results of operations and the cash flows of
 Exception EMS commencing as of the acquisition date. See Note
 8—Business acquisitions for further details on the accounting
 for this transaction.

[0001193125-17-033383:notes:76]
[same as prior period, unchanged from 0001193125-16-764312:notes:71]

[0001193125-17-033383:notes:77]
[same as prior period, unchanged from 0001193125-16-764312:notes:72]

[0001193125-17-033383:notes:78]
[same as prior period, unchanged from 0001193125-16-764312:notes:73]

[0001193125-17-033383:notes:79]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended
 December 30, 2016 and December 25, 2015 each consisted of
 13 weeks. The six months ended December 30, 2016 and
 December 25, 2015 consisted of 27 weeks and 26 weeks,
 respectively. Fiscal year 2017 will be comprised of 53 weeks and
 will end on June 30, 2017.

[0001193125-17-033383:notes:80]
[same as prior period, unchanged from 0001193125-16-764312:notes:75]

[0001193125-17-033383:notes:81]
Financial instruments that potentially subject the Company to
 concentrations of credit risk consist of cash and cash equivalents,
 marketable securities, derivatives and accounts receivable.

[0001193125-17-033383:notes:82]
Cash, cash equivalents and marketable securities are maintained
 with several financial institutions. Deposits held with banks may
 exceed the amount of insurance provided on such deposits.
 Generally, these deposits may be redeemed upon demand and are
 maintained with financial institutions with reputable credit and
 therefore bear minimal credit risk. The Company seeks to mitigate
 its credit risks by spreading such risks across multiple
 counterparties and monitoring the risk profiles of these
 counterparties. The Company limits its investments in marketable
 securities to securities with a maturity not in excess of three
 years, and all marketable securities that the Company invests in
 are rated A1, P-1, F1, or better.

[0001193125-17-033383:notes:83]
[same as prior period, unchanged from 0001193125-16-764312:notes:78]

[0001193125-17-033383:notes:84]
[same as prior period, unchanged from 0001193125-16-764312:notes:79]

[0001193125-17-033383:notes:85]
The derivatives assets and liabilities are recognized on the
 unaudited condensed consolidated balance sheets as other current
 assets or accrued expenses measured at fair value.

[0001193125-17-033383:notes:86]
[same as prior period, unchanged from 0001193125-16-764312:notes:81]

[0001193125-17-033383:notes:87]
Derivatives designated and qualifying as hedges of the exposure to
 variability in expected future cash flows, or other types of
 forecasted transactions, are considered cash flow hedges which
 include forward currency contracts. In a cash flow hedging
 relationship, the effective portion of the change in the fair value
 of the hedging derivative is initially recorded in accumulated
 other comprehensive income (loss) (“AOCI”), while any
 ineffective portion is recognized directly in earnings, as a
 component of other income (expense). The portion of gain or loss on
 the derivative instrument remains in AOCI until the forecasted
 transaction is recognized in earnings.

[0001193125-17-033383:notes:88]
The Company also enters into derivative contracts that are intended
 to economically hedge certain of the Company’s risks. The
 changes in the fair value of the derivatives are recorded directly
 in earnings as a component of other income (expense). In accordance
 with the fair value measurement guidance, the Company’s
 accounting policy is to measure the credit risk of its derivative
 financial instruments that are subject to master netting agreements
 on a net basis by counterparty portfolio. The Company executes
 derivative instruments with financial institutions that are
 credit-worthy, defined by us as institutions that hold an
 investment grade credit rating.

[0001193125-17-033383:notes:89]
[same as prior period, unchanged from 0001193125-16-764312:notes:84]

[0001193125-17-033383:notes:90]
For the acquisition of Exception EMS, the Company allocated the
 fair value of purchase consideration to the assets acquired and
 liabilities assumed based on their fair values at the acquisition
 date. The total consideration and the allocation of consideration
 to the individual net assets is preliminary, as there are remaining
 uncertainties to be resolved, including the settlement of the final
 net working capital adjustment and the finalization of the
 estimated fair value attributable to the acquired intangible
 assets.

[0001193125-17-033383:notes:91]
The acquired intangible assets, which consist of customer
 relationships and backlog, are recorded as intangibles in the
 unaudited condensed consolidated balance sheets. The fair value of
 the acquired intangible assets was determined based on the
 multi-period excess earnings method. The Company reviews
 intangibles for impairment whenever changes or circumstances
 indicate the carrying amount may not be recoverable.

[0001193125-17-033383:notes:92]
In connection with the business acquisition, $3.1 million of cash
 for deferred consideration, net of foreign currency translation
 adjustment, was placed into an escrow account which is under the
 Company’s control. However, the Company has contractually
 agreed to remit this deferred consideration to the sellers of
 Exception EMS, subject to the resolution of claims that the Company
 may make against the funds with respect to indemnification and
 other claims within 24 months from the closing date of the
 transaction. The cash is presented as restricted cash in the
 unaudited condensed consolidated balance sheets within non-current
 assets and the related liability is presented within non-current
 liabilities for the deferred consideration.

[0001193125-17-033383:notes:93]
[same as prior period, unchanged from 0001193125-16-764312:notes:88]

[0001193125-17-033383:notes:94]
[same as prior period, unchanged from 0001193125-16-764312:notes:89]

[0001193125-17-033383:notes:95]
[same as prior period, unchanged from 0001193125-16-764312:notes:90]

[0001193125-17-033383:notes:96]
[same as prior period, unchanged from 0001193125-16-764312:notes:91]

[0001193125-17-033383:notes:97]
[same as prior period, unchanged from 0001193125-16-764312:notes:92]

[0001193125-17-033383:notes:98]
In January 2017, the Financial Accounting Standards Board
 (“FASB”) issued Accounting Standards Update
 (“ASU”) 2017-04, “Intangibles – Goodwill
 and Other (Topic 350): Simplifying the Test for Goodwill
 Impairment.” This amendment modified the concept of
 impairment assessment from the condition that exists when the
 carrying amount of goodwill exceeds its implied fair value to the
 condition that exists when the carrying amount of a reporting unit
 exceeds its fair value. Public companies that are SEC filers should
 adopt the amendment for its annual and any interim goodwill
 impairment tests in fiscal years beginning after December 15,
 2019. Early adoption is permitted for interim or annual goodwill
 impairment tests performed on testing dates after January 1,
 2017. The Company is currently evaluating the impact of the
 adoption of this update on its consolidated financial
 statements.

[0001193125-17-033383:notes:99]
In January 2017, the FASB issued ASU 2017-03, “Accounting
 Changes and Error Corrections (Topic 250) and Investments –
 Equity Method and Joint Ventures (Topic 323): Amendments to SEC
 Paragraphs Pursuant to Staff Announcements at the
 September 22, 2016 and November 17, 2016 EITF
 Meetings.” The amendment provides guidance to the Company in
 relation to the disclosure of the impact that ASU 2014-09, ASU
 2016-02 and ASU 2016-13 will have on the Company’s financial
 statements when adopted. The Company is currently evaluating the
 impact of the adoption of this update on its consolidated financial
 statements.

[0001193125-17-033383:notes:100]
In January 2017, the FASB issued ASU 2017-01, “Business
 Combination (Topic 805): Clarifying the Definition of a
 Business.” This amendment clarifies the definition of a
 business to assist entities when evaluating whether transactions
 should be accounted for as acquisitions (or disposals) of assets or
 business. For public companies, this ASU is effective for annual
 periods beginning after December 15, 2017, including interim
 periods within those periods. Early adoption is permitted for the
 transactions that occur before the issuance date or effective date
 of the amendment, only when the transaction has not been reported
 in financial statements that have been issued or made available for
 issuance. The Company does not expect that the adoption of this
 update will have a material impact to its consolidated financial
 statements.

[0001193125-17-033383:notes:101]
In October 2016, the FASB issued ASU 2016-16, “Income Taxes
 (Topic 740): Intra-Entity Transfers of Assets Other Than
 Inventory,” which eliminates the exception for an
 intra-entity transfer of an asset other than inventory that
 prohibits the recognition of current and deferred income taxes
 until the asset has been sold to an outside party. The entity
 should recognize income tax consequences of an intra-entity
 transfer of assets other than inventory when the transfer occurs.
 For public entities, this update is effective for annual reporting
 periods beginning after December 15, 2017, including interim
 reporting periods within those annual reporting periods. Early
 adoption is permitted for all entities as of the beginning of an
 annual reporting period for which financial statements have not
 been issued or made available for issuance. The Company is
 currently evaluating the impact of the adoption of this update on
 its consolidated financial statements.

[0001193125-17-033383:notes:102]
In August 2016, the FASB issued ASU 2016-15, “Classification
 of Certain Cash Receipts and Cash Payments (a consensus of the
 Emerging Issues Task Force).” The amendments in this ASU
 provide guidance on the presentation of certain cash receipts and
 cash payments in the statement of cash flows in order to reduce
 diversity in existing practice. The amendments in ASU 2016-15 are
 effective for public business entities for fiscal years beginning
 after December 15, 2017, and interim periods within those
 fiscal years. Early adoption is permitted, including adoption in an
 interim period. The Company is currently evaluating the impact of
 the adoption of this update on its consolidated financial
 statements.

[0001193125-17-033383:notes:103]
In June 2016, the FASB issued ASU 2016-13, “Financial
 Instruments – Credit Losses (Topic 326): Measurement of
 Credit Losses on Financial Instruments.” The amendments in
 this ASU replace the incurred loss impairment methodology in
 current GAAP with a methodology that reflects expected credit
 losses and requires consideration of a broader range of reasonable
 and supportable information to inform credit loss estimates. The
 amendments are effective for fiscal years beginning after
 December 15, 2019, including interim periods within those
 fiscal years. Early adoption is permitted for fiscal years
 beginning after December 15, 2018, including interim periods
 within those fiscal years. The Company is currently evaluating the
 impact of the adoption of this update on its consolidated financial
 statements.

[0001193125-17-033383:notes:104]
In March 2016, the FASB issued ASU
 2016-09, “Compensation – Stock Compensation (Topic
 718): Improvements to Employee Share-Based Payment
 Accounting.” This ASU simplifies several aspects of the
 accounting for share-based payment award transactions, including
 the income tax consequences, classification of awards as either
 equity or liabilities and classification on the statement of cash
 flows. The amendments in this update are effective for annual
 periods beginning after December 15, 2016, and interim periods
 within those annual periods, for public companies. Early adoption
 is permitted for any entity in any interim or annual period. The
 Company is currently evaluating the impact of the adoption of this
 update on its consolidated financial statements.

[0001193125-17-033383:notes:105]
In March 2016, the FASB issued ASU 2016-05, “Derivatives and
 Hedging (Topic 815),” to clarify that a change in the
 counterparty to a derivative instrument that has been designated as
 a hedging instrument under Topic 815, does not, in and of itself,
 require a de-designation of the hedging relationship, provided that
 all other hedge accounting criteria continue to be met. This
 guidance is effective for public entities for financial statements
 issued for fiscal years beginning after December 15, 2016 and
 interim periods within those fiscal years. Early adoption is
 permitted. The Company is currently evaluating the impact of the
 adoption of this update on its consolidated financial
 statements.

[0001193125-17-033383:notes:106]
In February 2016, the FASB issued ASU 2016-02, “Lease (Topic
 842).” The core principle of Topic 842 is that a lessee
 should recognize the lease assets and liabilities that arise from
 leases in the statement of financial position. For public business
 entities, this update is effective for fiscal years beginning after
 December 15, 2018, including interim periods within those
 fiscal years. Early application is permitted. The Company is
 currently evaluating the impact of the adoption of this update on
 its consolidated financial statements.

[0001193125-17-033383:notes:107]
In January 2016, the FASB issued ASU 2016-01, “Financial
 Instruments – Overall (Subtopic 825-10): Recognition and
 Measurement of Financial Assets and Financial Liabilities.”
 This new guidance requires certain equity investments to be
 measured at fair value, use of the exit price notion and separate
 presentation of financial assets and financial liabilities by
 measurement category and form of financial asset on the balance
 sheet or the accompanying notes to the financial statements. The
 ASU on recognition and measurement will take effect for public
 companies for fiscal years beginning after December 15, 2017,
 including interim periods within those fiscal years. The
 Company is currently evaluating the impact of the adoption of this
 update on its consolidated financial statements.

[0001193125-17-033383:notes:108]
In August 2014, the FASB issued ASU 2014-15, “Presentation of
 Financial Statements – Going Concern (Subtopic 205-40):
 Disclosure of Uncertainties about an Entity’s Ability to
 Continue as a Going Concern.” The amendments require
 management to evaluate, for each annual and interim reporting
 period, an entity’s ability to continue as a going concern
 when relevant conditions and events, considered in the aggregate,
 indicate that it is probable that the entity will be unable to meet
 its obligations that become due within one year after the date that
 the financial statements are issued (or available to be issued).
 This ASU is effective for annual periods and interim reporting
 periods beginning after December 15, 2016. The Company does
 not expect that the adoption of this update will have an effect on
 its consolidated financial statements.

[0001193125-17-033383:notes:109]
In May 2014, the FASB issued ASU 2014-09, “Revenue from
 Contracts with Customers (Topic 606), issued as a new Topic,
 Accounting Standards Codification.” The core principle of
 this amendment is that an entity should recognize revenue to depict
 the transfer of promised goods or services to customers in an
 amount that reflects the consideration to which the entity expects
 to be entitled in exchange for those goods or services. This update
 is effective for public companies, as amended by ASU 2015-14, for
 annual reporting periods beginning after December 15, 2017,
 including interim periods within that reporting period. Earlier
 application of this guidance is permitted, but not before the
 original date of December 15, 2016, which can be adopted
 either retrospectively to each prior reporting period presented or
 as a cumulative-effect adjustment as of the date of adoption.
 Subsequently, in March 2016 and April 2016, the FASB issued ASU
 2016-08 and ASU 2016-10, respectively, to clarify the
 implementation guidance on principle versus agent considerations
 and address the potential diversity in practice at initial
 application and cost; and the complexity of applying Topic 606,
 both at transition and on an ongoing basis related to
 identification of performance obligations and licensing
 arrangements; and ASU 2016-12 and ASU 2016-20, in May 2016 and
 December 2016, respectively, to improve in certain aspects of Topic
 606 , with the same effective date as ASU 2015-14. The Company will
 adopt this standard during its fiscal year ending June 28,
 2018. In the current period, the Company is assessing the contracts
 with its customers to identify the impact to its consolidated
 financial statements. The process is still ongoing and the Company
 expects to make significant progress in the coming quarters.


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001193125-17-033383:notes:110]
[same as prior period, unchanged from 0001193125-16-764312:notes:103]

[0001193125-17-033383:notes:111]
[same as prior period, unchanged from 0001193125-16-764312:notes:104]

[0001193125-17-033383:notes:112]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Loss |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of December 30, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 81,867 |  |  | $ | — |  |  | $ | 81,867 |  |  | $ | — |  |
| Cash equivalents |  |  | 3,752 |  |  |  | — |  |  |  | 3,752 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 114,692 |  |  |  | (38 | ) |  |  | — |  |  |  | 114,654 |  |
| U.S. agency and U.S. treasury securities |  |  | 54,211 |  |  |  | (99 | ) |  |  | — |  |  |  | 54,112 |  |
| Sovereign and municipal securities |  |  | 1,746 |  |  |  | (4 | ) |  |  | — |  |  |  | 1,742 |  |
| Total |  | $ | 256,268 |  |  | $ | (141 | ) |  | $ | 85,619 |  |  | $ | 170,508 |  |

[0001193125-17-033383:notes:113]
[same as prior period, unchanged from 0001193125-16-764312:notes:106]

[0001193125-17-033383:notes:114]
All highly liquid investments with original maturities of three
 months or less at the date of purchase are classified as cash
 equivalents. Management determines the appropriate classification
 of its investments at the time of purchase and reevaluates the
 designations at each balance sheet date. The Company may sell
 certain of its marketable securities prior to their stated
 maturities for strategic reasons including, but not limited to,
 anticipation of credit deterioration and duration management. The
 maturities of the Company’s marketable securities generally
 range from three months to three years. The Company’s
 investments in marketable securities consist of investments in U.S.
 Treasury and fixed income securities and have been classified and
 accounted for as available-for-sale.

[0001193125-17-033383:notes:115]
During the six months ended December 30, 2016, the Company
 recognized a realized loss of $0.02 million from sales and
 maturities of available-for-sale securities.

[0001193125-17-033383:notes:116]
As of December 30, 2016, the Company considered the declines
 in market value of its marketable securities investment portfolio
 to be temporary in nature and did not consider any of its
 securities other-than-temporarily impaired. The Company typically
 invests in highly-rated securities, and its investment policy
 generally limits the amount of credit exposure to any one issuer.
 The policy requires investments generally to be investment grade,
 with the primary objective of minimizing the potential risk of
 principal loss. Fair values were determined for each individual
 security in the investment portfolio. When evaluating an investment
 for other-than-temporary impairment, the Company reviews factors
 such as the length of time and extent to which fair value has been
 below its cost basis, the financial condition of the issuer and any
 changes thereto, changes in market interest rates, and the
 Company’s intent to sell, or whether it is more likely than
 not it will be required to sell, the investment before recovery of
 the investment’s cost basis. No impairment losses were
 recorded for the six months ended December 30, 2016.

[0001193125-17-033383:notes:117]
As of December 30, 2016, cash, cash equivalents, and
 marketable securities included bank deposits of $40.0 million held
 in various financial institutions located in the United States in
 order to support the availability of the Facility Agreement (as
 defined in Note 11) and comply with covenants. As discussed in Note
 11, under the terms and conditions of the Facility Agreement, the
 Company shall maintain cash, cash equivalents and/or marketable
 securities in an aggregate amount not less than $40.0 million in
 unencumbered deposits, and/or securities in accounts located in the
 United States at all times during the term of the Facility
 Agreement. The Company must comply with the covenant from and after
 the effective date of the Facility Agreement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-17-033383:notes:118]
[same as prior period, unchanged from 0001193125-16-764312:notes:111]

[0001193125-17-033383:notes:119]
As of December 30, 2016 and June 24, 2016, the liability
 for uncertain tax positions including accrued interest and
 penalties was $1.9 million and $1.8 million, respectively. The
 Company expects the estimated amount of liability associated with
 its uncertain tax positions to decrease within the next
 12 months due to the lapse of the applicable statute of
 limitations in foreign tax jurisdictions.

[0001193125-17-033383:notes:120]
[same as prior period, unchanged from 0001193125-16-764312:notes:113]

[0001193125-17-033383:notes:121]
The effective tax rate for the Company for the three months ended
 December 30, 2016 and December 25, 2015 remained flat at
 6.8% of net income. The Company’s taxable income and income
 tax expenses for the three months ended December 30, 2016
 increased proportionately on an absolute dollars basis, compared
 with the three months ended December 25, 2015.

[0001193125-17-033383:notes:122]
The effective tax rate for the Company for the six months ended
 December 30, 2016 and December 25, 2015 remained flat at
 6.7% of net income. The Company’s taxable income and income
 tax expenses for the six months ended December 30, 2016
 increased proportionately on an absolute dollars basis, compared
 with the six months ended December 25, 2015.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001193125-17-033383:notes:123]
[same as prior period, unchanged from 0001193125-16-764312:notes:115]

[0001193125-17-033383:notes:124]
| (amount in thousands) |  | As of December 30, 2016 |  |  | As of June 24, 2016 |  |
| Trade accounts receivable |  | $ | 240,934 |  |  | $ | 196,178 |  |
| Less: allowance for doubtful account |  |  | (47 | ) |  |  | (33 | ) |
| Trade accounts receivable, net |  | $ | 240,887 |  |  | $ | 196,145 |  |

[0001193125-17-033383:notes:125]
As of December 30, 2016, trade accounts receivable of $6.5
 million were secured to short-term loans from bank (see Note
 11).


## us-gaap:ScheduleOfDebtTableTextBlock

[0001193125-17-033383:notes:126]
The Company’s total borrowings, including short-term and
 long-term borrowings, consisted of the following:

[0001193125-17-033383:notes:127]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  | As of December 30, 2016 |  |  | As of June 24, 2016 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  | January 2017 (2) |  | $ | 20,000 |  |  | $ | 6,500 |  |
| Short-term loans from bank: |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank of England base rate +1.85% per annum |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  | 3,377 |  |  |  | — |  |
| Bank of England base rate + 2.2% per annum(3) |  | Repayable on monthly basis |  | May 2017 |  |  | 55 |  |  |  | — |  |
| Current portion of long-term borrowing |  |  |  |  |  |  | 15,100 |  |  |  | 18,100 |  |
|  |  |  |  |  |  |  | 38,532 |  |  |  | 24,600 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (245 | ) |  |  | (293 | ) |
|  |  |  |  |  |  | $ | 38,287 |  |  | $ | 24,307 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments |  | March 2017 |  | $ | 1,500 |  |  | $ | 4,500 |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  | Repayable in quarterly installments |  | May 2019 |  |  | 43,200 |  |  |  | 50,000 |  |
|  |  |  |  |  |  |  | 44,700 |  |  |  | 54,500 |  |
| Less: Current portion |  |  |  |  |  |  | (15,100 | ) |  |  | (18,100 | ) |
| Unamortized debt issuance costs |  |  |  |  |  |  | (188 | ) |  |  | (300 | ) |
| Non-current portion |  |  |  |  |  | $ | 29,412 |  |  | $ | 36,100 |  |

[0001193125-17-033383:notes:128]
| (1) | LIBOR is London Interbank Offered Rate. |

[0001193125-17-033383:notes:129]
| (2) | In December 2016, the maturity date was extended to January 2017. |

[0001193125-17-033383:notes:130]
| (3) | As of December 30, 2016, the carrying amount of plant and machinery of Exception EMS secured to such loan was $4.3 million. Under the conditions stipulated in the loan agreement, this loan will be cross securitized, cross default and co-terminus with the short terms of loans of $3.4 million which are secured by accounts receivable. |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001193125-17-033383:notes:131]
As of December 30, 2016, future maturities of long-term debt
 during each fiscal year were as follows:

[0001193125-17-033383:notes:132]
| (amount in thousands) |  |  |  |
| 2017 (remaining six months) |  | $ | 8,300 |  |
| 2018 |  |  | 13,600 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 44,700 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-17-033383:notes:133]
Based on the carrying amount of intangibles as of December 30,
 2016, and assuming no future impairment of the underlying assets,
 the estimated future amortization during each fiscal year was as
 follows:

[0001193125-17-033383:notes:134]
| (amount in thousands) |  |  |  |
| 2017 (remaining six months) |  | $ | 602 |  |
| 2018 |  |  | 1,014 |  |
| 2019 |  |  | 904 |  |
| 2020 |  |  | 792 |  |
| 2021 |  |  | 633 |  |
| Thereafter |  |  | 1,103 |  |
| Total |  | $ | 5,048 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001193125-17-033383:notes:135]
The changes in the carrying amount of goodwill were as follows:

[0001193125-17-033383:notes:136]
| (amount in thousands) |  | Goodwill |  |
| Balance as of June 24, 2016 |  | $ | — |  |
| Addition in connection with business acquisition |  |  | 2,735 |  |
| Foreign currency translation adjustment |  |  | (206 | ) |
| Balance as of December 30, 2016 |  | $ | 2,529 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-17-033383:notes:137]
[same as prior period, unchanged from 0001193125-16-764312:notes:128]

[0001193125-17-033383:notes:138]
On September 14, 2016, the Company acquired 100% shareholding
 in Exception EMS, a privately-held group located in Wiltshire,
 United Kingdom, for cash consideration of approximately $13.0
 million, net of $0.5 million cash acquired. Exception EMS provides
 contract electronics manufacturing services to the global
 electronics industry with innovative solutions, adding value to the
 design, manufacture and testing of printed circuit board
 assemblies. Pursuant to the acquisition agreement, the Company has
 placed $3.1 million of cash, net of foreign currency translation
 adjustment, for deferred consideration in an escrow account which
 is under the Company’s control. However, the Company has
 contractually agreed to remit this deferred consideration to the
 sellers of Exception EMS, subject to the resolution of claims that
 the Company may make against the funds with respect to
 indemnification and other claims within 24 months from the closing
 date of the transaction.

[0001193125-17-033383:notes:139]
The Company has accounted for this acquisition under the provisions
 of business combinations accounting, in accordance with Accounting
 Standards Codification Topic 805 – Business Combinations.
 Accordingly, the estimated fair value of the acquisition
 consideration was allocated to the assets acquired and the
 liabilities assumed based on their respective fair values on the
 acquisition date. The Company has made certain estimates and
 assumptions in determining the allocation of the acquisition
 consideration.

[0001193125-17-033383:notes:140]
The total consideration and the allocation of consideration to the
 individual Exception EMS net assets is preliminary, as there are
 remaining uncertainties to be resolved, including the settlement of
 the final net working capital adjustment and the finalization of
 the estimated fair value attributable to the acquired intangible
 assets. As the functional currency of Exception EMS is pound
 sterling (“GBP”), for the six months ended
 December 30, 2016, the Company recognized a $1.2 million loss
 from foreign currency translation adjustment in its unaudited
 condensed consolidated statements of operations and comprehensive
 income.

[0001193125-17-033383:notes:141]
During the second quarter of fiscal year 2017, the Company recorded
 an adjustment to its initial preliminary purchase price allocation
 with respect to the assets acquired and liabilities assumed. This
 resulted in a change in goodwill which was previously reported at
 acquisition date of $3.0 million to $2.7 million.

[0001193125-17-033383:notes:142]
[same as prior period, unchanged from 0001193125-16-764312:notes:132]

[0001193125-17-033383:notes:143]
| (amount in thousands) |  | Purchase price allocation |  |
| Cash |  | $ | 474 |  |
| Accounts receivable |  |  | 4,064 |  |
| Inventory |  |  | 3,490 |  |
| Other current assets |  |  | 427 |  |
| Property, plant and equipment |  |  | 5,678 |  |
| Intangibles |  |  | 4,492 |  |
| Goodwill |  |  | 2,735 |  |
| Other non-current assets |  |  | 516 |  |
| Current liabilities |  |  | (6,796 | ) |
| Other non-current liabilities |  |  | (1,563 | ) |
| Total fair value of assets acquired and liabilities assumed |  | $ | 13,517 |  |
| Total purchase price, net of cash acquired |  | $ | 13,043 |  |

[0001193125-17-033383:notes:144]
In connection with the Company’s acquisition of Exception
 EMS, the Company assumed lease agreements for certain machine and
 equipment, which are accounted for as capital leases. As of
 December 30, 2016, the Company included approximately $1.9
 million of capital lease assets and $1.5 million of capital lease
 liability in the unaudited condensed consolidated balance sheets
 associated with these acquired lease agreements.

[0001193125-17-033383:notes:145]
During the six months ended December 30, 2016, the
 Company incurred approximately $1.5 million in transaction
 costs related to the acquisition, which primarily consisted of
 legal, accounting and valuation-related expenses. These expenses
 were recorded in selling, general and administrative expense in the
 accompanying unaudited condensed consolidated statements of
 operations and comprehensive income.

[0001193125-17-033383:notes:146]
[same as prior period, unchanged from 0001193125-16-764312:notes:136]

[0001193125-17-033383:notes:147]
[same as prior period, unchanged from 0001193125-16-764312:notes:137]

[0001193125-17-033383:notes:148]
[same as prior period, unchanged from 0001193125-16-764312:notes:138]

[0001193125-17-033383:notes:149]
Customer relationships represent the fair value of future projected
 revenues that was derived from the sale of products to existing
 customers of the acquired company. The fair value of $4.4 million
 will be amortized over the respective estimated remaining useful
 life of ten years.

[0001193125-17-033383:notes:150]
Backlog represents the fair value of sales orders backlog as of the
 valuation date. The fair value of $0.1 million will be amortized
 over the respective estimated remaining useful life of three
 years.

[0001193125-17-033383:notes:151]
[same as prior period, unchanged from 0001193125-16-764312:notes:141]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-17-033383:notes:152]
[same as prior period, unchanged from 0001193125-16-764312:notes:142]


## us-gaap:DebtDisclosureTextBlock

[0001193125-17-033383:notes:153]
| 11. | Borrowings |

[0001193125-17-033383:notes:154]
Under the long-term borrowing contract of a subsidiary, the loan is
 secured by certain property, plant and equipment of the subsidiary.
 The carrying amount of assets secured and pledged as collateral to
 such loan as of December 30, 2016 and June 24, 2016 was
 $46.4 million and $47.7 million, respectively. This subsidiary is
 also required to comply with maximum ratios of debt to equity and
 minimum levels of debt service coverage ratios, and Fabrinet must
 maintain an effective shareholding ratio. The carrying amounts of
 bank borrowings approximate their fair value.

[0001193125-17-033383:notes:155]
As of December 30, 2016 and June 24, 2016, the Company
 was in compliance with its bank borrowing agreements. In addition
 to financial ratios, certain of the Company’s credit
 facilities include customary events of default.

[0001193125-17-033383:notes:156]
Credit facilities:

[0001193125-17-033383:notes:157]
Fabrinet entered into a syndicated senior credit facility agreement
 (the “Facility Agreement”) with a consortium of banks
 on May 22, 2014. The Facility Agreement, led by Bank of
 America, provides for a $200.0 million credit line, comprised of a
 $150.0 million revolving loan facility and a $50.0 million delayed
 draw term loan facility. The revolving loan facility contains an
 accordion feature permitting Fabrinet to request an increase in the
 facility up to $100.0 million subject to customary terms and
 conditions and provided that no default or event of default exists
 at the time of request. The revolving loan facility will be
 terminated and all amounts outstanding will be due and payable in
 full on May 22, 2019. The principal amount of any drawn term
 loans must be repaid according to scheduled quarterly amortization
 payments, with final payment of all amounts outstanding, plus
 accrued interest, being due May 22, 2019.

[0001193125-17-033383:notes:158]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. As of
 December 30, 2016, $20.0 million of the revolving borrowing
 and $43.2 million of the term loan borrowing was outstanding under
 the Facility Agreement, resulting in available credit facilities of
 $136.8 million. Borrowings under the revolving credit facility are
 classified as current liabilities in the unaudited condensed
 consolidated balance sheets as the Company has the periodic option
 to renew or pay, all or a portion of, the outstanding balance at
 the end of the maturity date, which is in the range of one to six
 months, without premium or penalty, upon notice to the
 administrative agent. During December 2016, the Company sent
 notices to the bank to renew the maturity date of its revolving
 borrowings. The bank approved the notices and extended the maturity
 to January 2017.

[0001193125-17-033383:notes:159]
Loans under the Facility Agreement bear interest, at
 Fabrinet’s option, at a rate per annum equal to a LIBOR rate
 plus a spread of 1.75% to 2.50%, or a base rate plus a spread of
 0.75% to 1.50%, determined in accordance with the Facility
 Agreement in each case with such spread determined based on
 Fabrinet’s consolidated total leverage ratio for the
 preceding four fiscal quarter period. Interest is due and payable
 quarterly in arrears for loans bearing interest at the base rate
 and at the end of an interest period (or at each three-month
 interval in the case of loans with interest periods greater than
 three months) in the case of loans bearing interest at the LIBOR
 rate.

[0001193125-17-033383:notes:160]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or the
 equivalent under the local law, can be effected.

[0001193125-17-033383:notes:161]
The Facility Agreement contains customary affirmative and negative
 covenants. Negative covenants include, among other things,
 limitations on liens, indebtedness, investments, mergers, sales of
 assets, changes in the nature of the business, dividends and
 distributions, affiliate transactions and capital expenditures. The
 Facility Agreement contains financial covenants requiring Fabrinet
 to maintain: (1) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (2) a minimum debt service coverage ratio of
 not less than 1.50:1.00; (3) a maximum senior leverage ratio
 of not more than 2.50:1.00; and (4) a minimum quick ratio of
 not less than 1.10:1.00. Each of these financial covenants is
 calculated on a consolidated basis for the consecutive four fiscal
 quarter period then ended. As of December 30, 2016, the
 Company was in compliance with all covenants under the Facility
 Agreement.

[0001193125-17-033383:notes:162]
The Facility Agreement also contains customary events of default
 including, among other things, payment defaults, breaches of
 covenants or representations and warranties, cross-defaults with
 certain other indebtedness, bankruptcy and insolvency events and
 change in control of Fabrinet, subject to grace periods in certain
 instances. Upon an event of default, the lenders may terminate
 their commitments, declare all or a portion of the outstanding
 obligations payable by Fabrinet to be immediately due and payable
 and exercise other rights and remedies provided for under the
 Facility Agreement.

[0001193125-17-033383:notes:163]
Fabrinet intends to use the proceeds of the credit line to finance
 its future manufacturing facility in Thailand, and for general
 corporate purposes including mergers and acquisitions of
 complementary manufacturing businesses or technology, although
 Fabrinet has no current commitments with respect to any such
 acquisitions.

[0001193125-17-033383:notes:164]
Short-term loans from bank

[0001193125-17-033383:notes:165]
In connection with the acquisition of Exception EMS, the Company
 assumed a secured borrowing agreement that is secured by trade
 accounts receivable of Exception EMS. As of December 30, 2016,
 the carrying amount of trade accounts receivable secured to the
 loans was $6.5 million. The secured borrowing agreement contains
 certain covenants that Exception EMS is required to comply with:
 (1) the value of credit notes may not exceed 4% of the value
 of assigned debts measured on a monthly basis, and (2) rolling
 cash flow must be provided with the monthly management information.
 As of December 30, 2016, the subsidiary was in compliance with
 all covenants under the secured borrowing agreement.

[0001193125-17-033383:notes:166]
As of December 30, 2016, the Company drew down $3.4 million
 from this facility, which is recorded as short-term loans in the
 unaudited condensed consolidated balance sheets. The agreement
 bears interest for discount charge at 1.85% per annum above
 Bank of England base rate.

[0001193125-17-033383:notes:167]
As of December 30, 2016, Fabrinet had made a request to
 drawdown $14.0 million on its available outstanding revolving
 borrowing. The bank approved the request for drawdown and provided
 cash to settle this request to Fabrinet on January 3, 2017.
 Due to the settlement of the transaction taking place after the
 balance sheet date, the respective cash and loan amount are not
 recorded in the unaudited condensed consolidated balance sheet as
 of December 30, 2016.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-17-033383:notes:168]
[same as prior period, unchanged from 0001193125-16-764312:notes:157]

[0001193125-17-033383:notes:169]
[same as prior period, unchanged from 0001193125-16-764312:notes:158]

[0001193125-17-033383:notes:170]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net |  |
| As of December 30, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 4,470 |  |  | $ | (3,347 | ) |  | $ | — |  |  | $ | 1,123 |  |
| Customer relationships |  |  | 4,372 |  |  |  | (211 | ) |  |  | (329 | ) |  |  | 3,832 |  |
| Backlog |  |  | 120 |  |  |  | (18 | ) |  |  | (9 | ) |  |  | 93 |  |
| Total intangibles |  | $ | 8,962 |  |  | $ | (3,576 | ) |  | $ | (338 | ) |  | $ | 5,048 |  |

[0001193125-17-033383:notes:171]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net |  |
| As of June 24, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 3,786 |  |  | $ | (3,287 | ) |  | $ | — |  |  | $ | 499 |  |
| Customer relationships |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Backlog |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total intangibles |  | $ | 3,786 |  |  | $ | (3,287 | ) |  | $ | — |  |  | $ | 499 |  |

[0001193125-17-033383:notes:172]
In connection with the acquisition of Exception EMS, the Company
 recorded $4.4 million of customer relationships and $0.1 million of
 backlog. As of December 30, 2016, the weighted-average
 remaining life of customer relationships and backlog was 7.4 years
 and 2.2 years, respectively.

[0001193125-17-033383:notes:173]
The Company recorded amortization expense relating to intangibles
 of $0.3 million and $0.01 million for the three months ended
 December 30, 2016 and December 25, 2015, respectively,
 and $0.3 million and $0.02 million for the six months ended
 December 30, 2016 and December 25, 2015,
 respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-17-033383:notes:174]
[same as prior period, unchanged from 0001193125-16-764312:notes:162]

[0001193125-17-033383:notes:175]
[same as prior period, unchanged from 0001193125-16-764312:notes:163]

[0001193125-17-033383:notes:176]
[same as prior period, unchanged from 0001193125-16-764312:notes:164]

[0001193125-17-033383:notes:177]
For the six months ended December 30, 2016, Fabrinet issued
 365,066 ordinary shares upon the exercise of options, for cash
 consideration at a weighted-average exercise price of $16.02 per
 share, and 396,950 ordinary shares upon the vesting of restricted
 share units, net of shares withheld.

[0001193125-17-033383:notes:178]
[same as prior period, unchanged from 0001193125-16-764312:notes:166]


## us-gaap:EarningsPerShareTextBlock

[0001193125-17-033383:notes:179]
[same as prior period, unchanged from 0001193125-16-764312:notes:167]

[0001193125-17-033383:notes:180]
[same as prior period, unchanged from 0001193125-16-764312:notes:168]

[0001193125-17-033383:notes:181]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands except per share amounts) |  | December 30, 2016 |  |  | December 25, 2015 |  |  | December 30, 2016 |  |  | December 25, 2015 |  |
| Net income attributable to shareholders |  | $ | 25,292 |  |  | $ | 19,803 |  |  | $ | 48,058 |  |  | $ | 21,406 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  | 36,848 |  |  |  | 35,812 |  |  |  | 36,626 |  |  |  | 35,695 |  |
| Incremental shares arising from the assumed exercise of share options and vesting of restricted share units (thousands of shares) |  |  | 957 |  |  |  | 1,014 |  |  |  | 941 |  |  |  | 875 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 37,805 |  |  |  | 36,826 |  |  |  | 37,567 |  |  |  | 36,570 |  |
| Basic earnings per ordinary share |  | $ | 0.69 |  |  | $ | 0.55 |  |  | $ | 1.31 |  |  | $ | 0.60 |  |
| Diluted earnings per ordinary share |  | $ | 0.67 |  |  | $ | 0.54 |  |  | $ | 1.28 |  |  | $ | 0.59 |  |
| Outstanding share options excluded in the computation of diluted earnings per ordinary share (1) |  |  | — |  |  |  | 31,244 |  |  |  | — |  |  |  | 31,244 |  |

[0001193125-17-033383:notes:182]
[same as prior period, unchanged from 0001193125-16-764312:notes:170]


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001193125-17-033383:notes:183]
[same as prior period, unchanged from 0001193125-16-764312:notes:171]

[0001193125-17-033383:notes:184]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of December 30, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 3,752 |  |  | $ | — |  |  | $ | 3,752 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 114,654 |  |  |  | — |  |  |  | 114,654 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 54,112 |  |  |  | — |  |  |  | 54,112 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 1,742 |  |  |  | — |  |  |  | 1,742 |  |
| Total |  | $ | — |  |  | $ | 174,260 |  |  | $ | — |  |  | $ | 174,260 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 1 | (1) |  | $ | — |  |  | $ | 1 |  |
| Total |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |

[0001193125-17-033383:notes:185]
[same as prior period, unchanged from 0001193125-16-764312:notes:173]

[0001193125-17-033383:notes:186]
| (1) | Foreign currency forward contracts with notional amount of Canadian dollars 0.2 million. |

[0001193125-17-033383:notes:187]
[same as prior period, unchanged from 0001193125-16-764312:notes:175]

[0001193125-17-033383:notes:188]
[same as prior period, unchanged from 0001193125-16-764312:notes:176]


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-17-033383:notes:189]
[same as prior period, unchanged from 0001193125-16-764312:notes:177]

[0001193125-17-033383:notes:190]
[same as prior period, unchanged from 0001193125-16-764312:notes:178]

[0001193125-17-033383:notes:191]
[same as prior period, unchanged from 0001193125-16-764312:notes:179]

[0001193125-17-033383:notes:192]
[same as prior period, unchanged from 0001193125-16-764312:notes:180]

[0001193125-17-033383:notes:193]
[same as prior period, unchanged from 0001193125-16-764312:notes:181]

[0001193125-17-033383:notes:194]
[same as prior period, unchanged from 0001193125-16-764312:notes:182]

[0001193125-17-033383:notes:195]
[same as prior period, unchanged from 0001193125-16-764312:notes:183]

[0001193125-17-033383:notes:196]
As a result of foreign currency rate fluctuations, the U.S. dollar
 equivalent values of the Company’s foreign currency
 denominated assets and liabilities change. The Company uses foreign
 currency contracts to manage the foreign exchange risk associated
 with certain foreign currency denominated assets and liabilities
 and other foreign currency transactions. The Company minimizes the
 credit risk in derivative instruments by limiting its exposure to
 any single counterparty and by entering into derivative instruments
 only with counterparties that meet the Company’s minimum
 credit quality standard. As of December 30, 2016, the Company
 recognized the fair value of foreign currency forward contracts of
 $0.001 million as derivative liabilities in the unaudited condensed
 consolidated balance sheet. As of June 24, 2016, the Company
 recognized the fair value of foreign currency forward contracts of
 $0.2 million as derivative assets and $1.7 million as derivative
 liabilities in the unaudited condensed consolidated balance sheet
 under other current assets and accrued expenses, respectively.

[0001193125-17-033383:notes:197]
As of December 30, 2016, the Company had no foreign currency
 forward contracts designated as cash flow hedges. During the six
 months ended December 30, 2016, the Company discontinued cash
 flow hedges and recognized a gain from unwinding foreign currency
 forward contracts of $0.3 million in the unaudited condensed
 consolidated statements of operations and comprehensive income.

[0001193125-17-033383:notes:198]
As of December 30, 2016, the Company had one outstanding
 foreign currency forward contract with a notional amount of
 Canadian dollars 0.2 million, maturing in March 2017. This
 foreign currency forward contract was not designated for hedge
 accounting and was used to hedge fluctuations in the U.S. dollar
 value of forecasted transactions denominated in Canadian dollar.
 During the six months ended December 30, 2016, the Company
 included unrealized loss of $0.001 million from changes in the fair
 value of foreign currency contracts in earnings in the unaudited
 condensed consolidated statements of operations and comprehensive
 income.

[0001193125-17-033383:notes:199]
As of December 25, 2015, the Company had 32 outstanding
 foreign currency forward contracts with an aggregate notional
 amount of $181.5 million and Canadian dollars 0.4 million,
 maturing during December 2015 to December 2016. These foreign
 currency forward contracts were not designated for hedge accounting
 and were used to hedge fluctuations in the U.S. dollar value of
 forecasted transactions denominated in Thai baht and Canadian
 dollar. During the six months ended December 25, 2015, the
 Company included unrealized loss of $6.2 million from changes in
 the fair value of foreign currency contracts in earnings in the
 unaudited condensed consolidated statements of operations and
 comprehensive income.


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-17-033383:notes:200]
[same as prior period, unchanged from 0001193125-16-764312:notes:188]

[0001193125-17-033383:notes:201]
As of December 30, 2016, the Company recorded $2.7 million of
 goodwill, in connection with the acquisition of Exception EMS, in
 the unaudited condensed consolidated balance sheets.

[0001193125-17-033383:notes:202]
Goodwill is not deductible for tax purposes. Goodwill is reviewed
 annually for impairment or more frequently whenever changes or
 circumstances indicate the carrying amount of goodwill may not be
 recoverable.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-17-033383:notes:203]
[same as prior period, unchanged from 0001193125-16-764312:notes:191]

[0001193125-17-033383:notes:204]
Operating segments are defined as components of an enterprise for
 which separate financial information is available that is evaluated
 regularly by the chief operating decision maker in deciding how to
 allocate resources and in assessing performance. The
 Company’s chief operating decision maker is Fabrinet’s
 chief executive officer. As of December 30, 2016, the Company
 operated and internally managed a single operating segment.
 Accordingly, the Company does not accumulate discrete information
 with respect to separate product lines and does not have separate
 reportable segments.

[0001193125-17-033383:notes:205]
[same as prior period, unchanged from 0001193125-16-764312:notes:193]

[0001193125-17-033383:notes:206]
As of December 30, 2016 and December 25, 2015, the
 Company had approximately $35.9 million and $33.6 million of
 long-lived assets based in North America, with the substantial
 remainder of assets based in Asia-Pacific.

[0001193125-17-033383:notes:207]
[same as prior period, unchanged from 0001193125-16-764312:notes:195]

[0001193125-17-033383:notes:208]
The Company had two customers that each contributed to 10% or more
 of its total accounts receivable as of December 30, 2016 and
 June 24, 2016, respectively.


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001193125-17-033383:notes:209]
[same as prior period, unchanged from 0001193125-16-764312:notes:197]

[0001193125-17-033383:notes:210]
During the week of August 10, 2015, the Company’s
 subsidiary in China temporarily suspended production in its
 manufacturing facility due to flooding caused by Typhoon Soudelor
 and resumed operations on August 15, 2015. During the six
 months ended December 25, 2015, the Company recognized $0.9
 million of losses incurred from the event in the unaudited
 condensed consolidated statements of operations and comprehensive
 income. The Company received a final payment of $0.8 million from
 an insurer against the Company’s claim for flood damage
 during the three months ended March 25, 2016.
