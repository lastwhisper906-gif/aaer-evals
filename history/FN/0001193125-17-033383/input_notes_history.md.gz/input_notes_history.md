# FN note change history — 0001193125-16-764312 → 0001193125-17-033383


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-02-07):
[0001193125-17-033383:note_history:1]
As of December 30, 2016 and June 24, 2016, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $1.4 million and $0.8 million, respectively.
  (was, 2016-11-09, similarity 0.984):
[0001193125-16-764312:note_history:1]
As of September 30, 2016 and June 24, 2016, there were outstanding
 bank guarantees given by banks on behalf of Fabrinet Thailand for
 electricity usage and other normal business amounting to $0.8
 million and $0.8 million, respectively.

- changed (2017-02-07):
[0001193125-17-033383:note_history:2]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, New Jersey and the United Kingdom under operating
 lease arrangements that expire in various calendar years through
 2023. Rental expense under these operating leases amounted to $0.8
 million and $0.6 million for the six months ended December 30,
 2016 and December 25, 2015, respectively.
  (was, 2016-11-09, similarity 0.9393):
[0001193125-16-764312:note_history:2]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, New Jersey and the United Kingdom under operating
 lease arrangements that expire in various calendar years through
 2023. Rental expense under these operating leases amounted to $0.4
 million and $0.3 million for the three months ended September 30,
 2016 and September 25, 2015, respectively.

- changed (2017-02-07):
[0001193125-17-033383:note_history:3]
As of December 30, 2016, the future minimum lease payments due
 under non-cancelable operating leases during each fiscal year were
 as follows:
  (was, 2016-11-09, similarity 0.9815):
[0001193125-16-764312:note_history:3]
As of September 30, 2016, the future minimum lease payments due
 under non-cancelable operating leases during each fiscal year were
 as follows:

- changed (2017-02-07):
[0001193125-17-033383:note_history:4]
| (amount in thousands) |  |  |  |
| 2017 (remaining six months) |  | $ | 867 |  |
| 2018 |  |  | 1,641 |  |
| 2019 |  |  | 1,104 |  |
| 2020 |  |  | 902 |  |
| 2021 |  |  | 503 |  |
| Thereafter |  |  | 850 |  |
| Total minimum operating lease payments |  | $ | 5,867 |  |
  (was, 2016-11-09, similarity 0.9838):
[0001193125-16-764312:note_history:4]
| (amount in thousands) |  |  |  |
| 2017 (remaining nine months) |  | $ | 1,338 |  |
| 2018 |  |  | 1,685 |  |
| 2019 |  |  | 1,131 |  |
| 2020 |  |  | 922 |  |
| 2021 |  |  | 525 |  |
| Thereafter |  |  | 897 |  |
| Total minimum operating lease payments |  | $ | 6,498 |  |

- added (2017-02-07):
[0001193125-17-033383:note_history:5]
In connection with the acquisition of Exception EMS, the Company
 assumed the capital lease commitments of several machines and
 equipment, with various expiration dates until September 2020. The
 equipment can be purchased at the determined prices upon expiration
 of such contracts.

- changed (2017-02-07):
[0001193125-17-033383:note_history:6]
As of December 30, 2016, the future minimum lease payments due
 under non-cancelable capital leases during each fiscal year were as
 follows:
  (was, 2016-11-09, similarity 0.9813):
[0001193125-16-764312:note_history:6]
As of September 30, 2016, the future minimum lease payments due
 under non-cancelable capital leases during each fiscal year were as
 follows:

- changed (2017-02-07):
[0001193125-17-033383:note_history:7]
| (amount in thousands) |  |  |  |
| 2017 (remaining six months) |  | $ | 180 |  |
| 2018 |  |  | 387 |  |
| 2019 |  |  | 419 |  |
| 2020 |  |  | 385 |  |
| 2021 |  |  | 99 |  |
| Total minimum capital lease payments |  | $ | 1,470 |  |
  (was, 2016-11-09, similarity 0.9868):
[0001193125-16-764312:note_history:7]
| (amount in thousands) |  |  |  |
| 2017 (remaining nine months) |  | $ | 301 |  |
| 2018 |  |  | 416 |  |
| 2019 |  |  | 429 |  |
| 2020 |  |  | 376 |  |
| 2021 |  |  | 156 |  |
| Total minimum capital lease payments |  | $ | 1,678 |  |

- added (2017-02-07):
[0001193125-17-033383:note_history:8]
On December 23, 2016, the Company entered into an agreement to
 purchase a parcel of land in Chonburi, Thailand, to support the
 expansion of the Company’s production in Thailand. The
 aggregate purchase price is approximately $5.6 million, of which
 the first installment of $1.1 million was paid by the Company on
 January 10, 2017. The Company expects to pay the remaining
 balance of the purchase price on or before December 25,
 2017.

- changed (2017-02-07):
[0001193125-17-033383:note_history:9]
As of December 30, 2016, the Company had an outstanding
 commitment to third parties of approximately $11.9 million.
  (was, 2016-11-09, similarity 0.6561):
[0001193125-16-764312:note_history:9]
As of September 30, 2016, the Company had an outstanding commitment
 to third parties of approximately $30.1 million, mainly related to
 the construction of a new manufacturing building at the
 Company’s Chonburi campus.

- removed (2017-02-07):
[0001193125-16-764312:note_history:10]
In connection with the acquisition of Exception EMS, the Company
 assumed the capital lease commitments of certain machine and
 equipment, with various expiration dates until September 2020. The
 equipment can be purchased at the determined price upon
 expiration.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-02-07):
[0001193125-17-033383:note_history:11]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of December 30, 2016 and for the
 three and six months ended December 30, 2016 and
 December 25, 2015 includes normal recurring adjustments,
 necessary for a fair statement of the financial statements set
 forth herein, in accordance with accounting principles generally
 accepted in the United States of America (“U.S. GAAP”)
 for interim financial information and the rules and regulations of
 the Securities and Exchange Commission (“SEC”).
 Accordingly, such information does not include all of the
 information and footnotes required by U.S. GAAP for annual
 financial statements. For further information, please refer to the
 consolidated financial statements and footnotes thereto included in
 Fabrinet’s Annual Report on Form 10-K for the year ended
 June 24, 2016.
  (was, 2016-11-09, similarity 0.9539):
[0001193125-16-764312:note_history:11]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of September 30, 2016 and for the three
 months ended September 30, 2016 and September 25, 2015 includes
 normal recurring adjustments, necessary for a fair presentation of
 the financial statements set forth herein, in accordance with
 accounting principles generally accepted in the United States of
 America (“U.S. GAAP”) for interim financial information
 and the rules and regulations of the Securities and Exchange
 Commission (“SEC”). Accordingly, such information does
 not include all of the information and footnotes required by U.S.
 GAAP for annual financial statements. For further information,
 please refer to the consolidated financial statements and footnotes
 thereto included in Fabrinet’s Annual Report on Form 10-K for
 the year ended June 24, 2016.

- changed (2017-02-07):
[0001193125-17-033383:note_history:12]
The balance sheet as of June 24, 2016 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three and six
 months ended December 30, 2016 may not be indicative of
 results for the year ending June 30, 2017 or any future
 periods.
  (was, 2016-11-09, similarity 0.9425):
[0001193125-16-764312:note_history:12]
The balance sheet as of June 24, 2016 has been derived from the
 audited financial statements at that date but does not include all
 of the information and footnotes required by U.S. GAAP for complete
 financial statements. The results for the three months ended
 September 30, 2016 may not be indicative of results for the year
 ending June 30, 2017 or any future periods.

- changed (2017-02-07):
[0001193125-17-033383:note_history:13]
On September 14, 2016, the Company acquired 100% shareholding
 in Global CEM Solutions, Ltd. and all of its subsidiaries
 (including Exception EMS), a privately-held group located
 in Wiltshire, United Kingdom. The unaudited condensed
 consolidated financial statements of the Company include the
 financial position, results of operations and the cash flows of
 Exception EMS commencing as of the acquisition date. See Note
 8—Business acquisitions for further details on the accounting
 for this transaction.
  (was, 2016-11-09, similarity 0.9176):
[0001193125-16-764312:note_history:13]
On September 14, 2016, the Company acquired 100% of the shares
 of Global CEM Solutions, Ltd. and all of its subsidiaries, a
 privately-held group located in Wiltshire, United
 Kingdom (“Exception EMS”). The unaudited condensed
 consolidated financial statements of the Company include the
 financial position, results of operations and the cash flows of
 Exception EMS commencing as of the acquisition date. See Note 8 -
 Business acquisitions for further details on the accounting for
 this transaction.

- changed (2017-02-07):
[0001193125-17-033383:note_history:14]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended
 December 30, 2016 and December 25, 2015 each consisted of
 13 weeks. The six months ended December 30, 2016 and
 December 25, 2015 consisted of 27 weeks and 26 weeks,
 respectively. Fiscal year 2017 will be comprised of 53 weeks and
 will end on June 30, 2017.
  (was, 2016-11-09, similarity 0.7065):
[0001193125-16-764312:note_history:14]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended September 30,
 2016 and September 25, 2015 each consisted of 14 weeks and 13
 weeks, respectively. Fiscal year 2017 will be comprised of 53 weeks
 and will end on June 30, 2017.

- changed (2017-02-07):
[0001193125-17-033383:note_history:15]
Financial instruments that potentially subject the Company to
 concentrations of credit risk consist of cash and cash equivalents,
 marketable securities, derivatives and accounts receivable.
  (was, 2016-11-09, similarity 0.9974):
[0001193125-16-764312:note_history:15]
Financial instruments that potentially subject the Company to
 concentrations of credit risk consist of cash and cash equivalents,
 marketable securities, derivatives, and accounts receivable.

- changed (2017-02-07):
[0001193125-17-033383:note_history:16]
Cash, cash equivalents and marketable securities are maintained
 with several financial institutions. Deposits held with banks may
 exceed the amount of insurance provided on such deposits.
 Generally, these deposits may be redeemed upon demand and are
 maintained with financial institutions with reputable credit and
 therefore bear minimal credit risk. The Company seeks to mitigate
 its credit risks by spreading such risks across multiple
 counterparties and monitoring the risk profiles of these
 counterparties. The Company limits its investments in marketable
 securities to securities with a maturity not in excess of three
 years, and all marketable securities that the Company invests in
 are rated A1, P-1, F1, or better.
  (was, 2016-11-09, similarity 0.9993):
[0001193125-16-764312:note_history:16]
Cash, cash equivalents, and marketable securities are maintained
 with several financial institutions. Deposits held with banks may
 exceed the amount of insurance provided on such deposits.
 Generally, these deposits may be redeemed upon demand and are
 maintained with financial institutions with reputable credit and
 therefore bear minimal credit risk. The Company seeks to mitigate
 its credit risks by spreading such risks across multiple
 counterparties and monitoring the risk profiles of these
 counterparties. The Company limits its investments in marketable
 securities to securities with a maturity not in excess of three
 years, and all marketable securities that the Company invests in
 are rated A1, P-1, F1, or better.

- changed (2017-02-07):
[0001193125-17-033383:note_history:17]
The derivatives assets and liabilities are recognized on the
 unaudited condensed consolidated balance sheets as other current
 assets or accrued expenses measured at fair value.
  (was, 2016-11-09, similarity 0.9398):
[0001193125-16-764312:note_history:17]
The derivatives assets and liabilities are recognized on the
 consolidated balance sheets as other current assets or accrued
 expenses measured at fair value.

- changed (2017-02-07):
[0001193125-17-033383:note_history:18]
The Company also enters into derivative contracts that are intended
 to economically hedge certain of the Company’s risks. The
 changes in the fair value of the derivatives are recorded directly
 in earnings as a component of other income (expense). In accordance
 with the fair value measurement guidance, the Company’s
 accounting policy is to measure the credit risk of its derivative
 financial instruments that are subject to master netting agreements
 on a net basis by counterparty portfolio. The Company executes
 derivative instruments with financial institutions that are
 credit-worthy, defined by us as institutions that hold an
 investment grade credit rating.
  (was, 2016-11-09, similarity 0.9917):
[0001193125-16-764312:note_history:18]
The Company also enters into derivative contracts that are intended
 to economically hedge certain of the Company’s risks. The
 changes in the fair value of the derivatives are recorded directly
 in earnings as a component of other income (expense), net. In
 accordance with the fair value measurement guidance, the
 Company’s accounting policy is to measure the credit risk of
 its derivative financial instruments that are subject to master
 netting agreements on a net basis by counterparty portfolio. The
 Company executes derivative instruments with financial institutions
 that are credit-worthy, defined as institutions that hold an
 investment grade credit rating.

- changed (2017-02-07):
[0001193125-17-033383:note_history:19]
For the acquisition of Exception EMS, the Company allocated the
 fair value of purchase consideration to the assets acquired and
 liabilities assumed based on their fair values at the acquisition
 date. The total consideration and the allocation of consideration
 to the individual net assets is preliminary, as there are remaining
 uncertainties to be resolved, including the settlement of the final
 net working capital adjustment and the finalization of the
 estimated fair value attributable to the acquired intangible
 assets.
  (was, 2016-11-09, similarity 0.9962):
[0001193125-16-764312:note_history:19]
For the acquisition of Exception EMS, the Company allocated the
 fair value of purchase consideration to the assets acquired and
 liability assumed based on their fair values at the acquisition
 date. The total consideration and the allocation of consideration
 to the individual net assets is preliminary, as there are remaining
 uncertainties to be resolved, including the settlement of the final
 net working capital adjustment and the finalization of the
 estimated fair value attributable to the acquired intangible
 assets.

- changed (2017-02-07):
[0001193125-17-033383:note_history:20]
The acquired intangible assets, which consist of customer
 relationships and backlog, are recorded as intangibles in the
 unaudited condensed consolidated balance sheets. The fair value of
 the acquired intangible assets was determined based on the
 multi-period excess earnings method. The Company reviews
 intangibles for impairment whenever changes or circumstances
 indicate the carrying amount may not be recoverable.
  (was, 2016-11-09, similarity 0.9486):
[0001193125-16-764312:note_history:20]
The acquired intangible assets include customer relationships and
 backlog and are recorded as intangibles in the unaudited condensed
 consolidated balance sheets. The fair value of the acquired
 intangible assets was determined based on the multi-period excess
 earnings method. The Company reviews intangibles for impairment
 annually or whenever changes or circumstances indicate the carrying
 amount may not be recoverable.

- changed (2017-02-07):
[0001193125-17-033383:note_history:21]
In connection with the business acquisition, $3.1 million of cash
 for deferred consideration, net of foreign currency translation
 adjustment, was placed into an escrow account which is under the
 Company’s control. However, the Company has contractually
 agreed to remit this deferred consideration to the sellers of
 Exception EMS, subject to the resolution of claims that the Company
 may make against the funds with respect to indemnification and
 other claims within 24 months from the closing date of the
 transaction. The cash is presented as restricted cash in the
 unaudited condensed consolidated balance sheets within non-current
 assets and the related liability is presented within non-current
 liabilities for the deferred consideration.
  (was, 2016-11-09, similarity 0.7929):
[0001193125-16-764312:note_history:21]
In connection with the business acquisition, $3.4 million of cash
 for deferred consideration was placed into an escrow account which
 is under the Company controls. However, the Company has
 contractually agreed to remit this deferred consideration to the
 sellers of Exception EMS, subject to the resolution of claims that
 the Company may make against the funds with respect to
 indemnification and other claims within 24 months from the closing
 date of the transaction. The cash is presented as restricted cash
 in the unaudited condensed consolidated balance sheets and the
 related liability is presented within non-current liabilities for
 the deferred consideration.

- added (2017-02-07):
[0001193125-17-033383:note_history:22]
In January 2017, the Financial Accounting Standards Board
 (“FASB”) issued Accounting Standards Update
 (“ASU”) 2017-04, “Intangibles – Goodwill
 and Other (Topic 350): Simplifying the Test for Goodwill
 Impairment.” This amendment modified the concept of
 impairment assessment from the condition that exists when the
 carrying amount of goodwill exceeds its implied fair value to the
 condition that exists when the carrying amount of a reporting unit
 exceeds its fair value. Public companies that are SEC filers should
 adopt the amendment for its annual and any interim goodwill
 impairment tests in fiscal years beginning after December 15,
 2019. Early adoption is permitted for interim or annual goodwill
 impairment tests performed on testing dates after January 1,
 2017. The Company is currently evaluating the impact of the
 adoption of this update on its consolidated financial
 statements.

- added (2017-02-07):
[0001193125-17-033383:note_history:23]
In January 2017, the FASB issued ASU 2017-03, “Accounting
 Changes and Error Corrections (Topic 250) and Investments –
 Equity Method and Joint Ventures (Topic 323): Amendments to SEC
 Paragraphs Pursuant to Staff Announcements at the
 September 22, 2016 and November 17, 2016 EITF
 Meetings.” The amendment provides guidance to the Company in
 relation to the disclosure of the impact that ASU 2014-09, ASU
 2016-02 and ASU 2016-13 will have on the Company’s financial
 statements when adopted. The Company is currently evaluating the
 impact of the adoption of this update on its consolidated financial
 statements.

- added (2017-02-07):
[0001193125-17-033383:note_history:24]
In January 2017, the FASB issued ASU 2017-01, “Business
 Combination (Topic 805): Clarifying the Definition of a
 Business.” This amendment clarifies the definition of a
 business to assist entities when evaluating whether transactions
 should be accounted for as acquisitions (or disposals) of assets or
 business. For public companies, this ASU is effective for annual
 periods beginning after December 15, 2017, including interim
 periods within those periods. Early adoption is permitted for the
 transactions that occur before the issuance date or effective date
 of the amendment, only when the transaction has not been reported
 in financial statements that have been issued or made available for
 issuance. The Company does not expect that the adoption of this
 update will have a material impact to its consolidated financial
 statements.

- changed (2017-02-07):
[0001193125-17-033383:note_history:25]
In October 2016, the FASB issued ASU 2016-16, “Income Taxes
 (Topic 740): Intra-Entity Transfers of Assets Other Than
 Inventory,” which eliminates the exception for an
 intra-entity transfer of an asset other than inventory that
 prohibits the recognition of current and deferred income taxes
 until the asset has been sold to an outside party. The entity
 should recognize income tax consequences of an intra-entity
 transfer of assets other than inventory when the transfer occurs.
 For public entities, this update is effective for annual reporting
 periods beginning after December 15, 2017, including interim
 reporting periods within those annual reporting periods. Early
 adoption is permitted for all entities as of the beginning of an
 annual reporting period for which financial statements have not
 been issued or made available for issuance. The Company is
 currently evaluating the impact of the adoption of this update on
 its consolidated financial statements.
  (was, 2016-11-09, similarity 0.948):
[0001193125-16-764312:note_history:25]
In October 2016, the Financial Accounting Standards Board
 (“FASB”) issued Accounting Standards Update
 (“ASU”) 2016-16, “Income Taxes (Topic 740)
 – Intra-Entity Transfers of Assets Other Than
 Inventory,” which eliminates the exception for an
 intra-entity transfer of an asset other than inventory that
 prohibits the recognition of current and deferred income taxes
 until the asset has been sold to an outside party. The entity
 should recognize income tax consequences of an intra-entity
 transfer of assets other than inventory when the transfer occurs.
 For public entities, this update is effective for annual reporting
 periods beginning after December 15, 2017, including interim
 reporting periods within those annual reporting periods. Early
 adoption is permitted for all entities as of the beginning of an
 annual reporting period for which financial statements have not
 been issued or made available for issuance. The Company is
 currently evaluating the impact of the adoption of this update on
 its consolidated financial statements.

- changed (2017-02-07):
[0001193125-17-033383:note_history:26]
In March 2016, the FASB issued ASU
 2016-09, “Compensation – Stock Compensation (Topic
 718): Improvements to Employee Share-Based Payment
 Accounting.” This ASU simplifies several aspects of the
 accounting for share-based payment award transactions, including
 the income tax consequences, classification of awards as either
 equity or liabilities and classification on the statement of cash
 flows. The amendments in this update are effective for annual
 periods beginning after December 15, 2016, and interim periods
 within those annual periods, for public companies. Early adoption
 is permitted for any entity in any interim or annual period. The
 Company is currently evaluating the impact of the adoption of this
 update on its consolidated financial statements.
  (was, 2016-11-09, similarity 0.9993):
[0001193125-16-764312:note_history:26]
In March 2016, the FASB issued ASU
 2016-09, “Compensation – Stock Compensation (Topic
 718): Improvements to Employee Share-Based Payment
 Accounting.” This ASU simplifies several aspects of the
 accounting for share-based payment award transactions, including,
 the income tax consequences, classification of awards as either
 equity or liabilities and classification on the statement of cash
 flows. The amendments in this update are effective for annual
 periods beginning after December 15, 2016, and interim periods
 within those annual periods, for public companies. Early
 adoption is permitted for any entity in any interim or annual
 period. The Company is currently evaluating the impact of the
 adoption of this update on its consolidated financial
 statements.

- changed (2017-02-07):
[0001193125-17-033383:note_history:27]
In March 2016, the FASB issued ASU 2016-05, “Derivatives and
 Hedging (Topic 815),” to clarify that a change in the
 counterparty to a derivative instrument that has been designated as
 a hedging instrument under Topic 815, does not, in and of itself,
 require a de-designation of the hedging relationship, provided that
 all other hedge accounting criteria continue to be met. This
 guidance is effective for public entities for financial statements
 issued for fiscal years beginning after December 15, 2016 and
 interim periods within those fiscal years. Early adoption is
 permitted. The Company is currently evaluating the impact of the
 adoption of this update on its consolidated financial
 statements.
  (was, 2016-11-09, similarity 0.9963):
[0001193125-16-764312:note_history:27]
In March 2016, the FASB issued ASU 2016-05, “Derivatives and
 Hedging (Topic 815),” to clarify that a change in the
 counterparty to a derivative instrument that has been designated as
 a hedging instrument under Topic 815, does not, in and of itself,
 require designation of the hedging relationship, provided that all
 other hedge accounting criteria continue to be met. This guidance
 is effective for public entities for financial statements issued
 for fiscal years beginning after December 15, 2016 and interim
 periods within those fiscal years. Early adoption is permitted. The
 Company is currently evaluating the impact of the adoption of this
 update on its consolidated financial statements.

- added (2017-02-07):
[0001193125-17-033383:note_history:28]
In May 2014, the FASB issued ASU 2014-09, “Revenue from
 Contracts with Customers (Topic 606), issued as a new Topic,
 Accounting Standards Codification.” The core principle of
 this amendment is that an entity should recognize revenue to depict
 the transfer of promised goods or services to customers in an
 amount that reflects the consideration to which the entity expects
 to be entitled in exchange for those goods or services. This update
 is effective for public companies, as amended by ASU 2015-14, for
 annual reporting periods beginning after December 15, 2017,
 including interim periods within that reporting period. Earlier
 application of this guidance is permitted, but not before the
 original date of December 15, 2016, which can be adopted
 either retrospectively to each prior reporting period presented or
 as a cumulative-effect adjustment as of the date of adoption.
 Subsequently, in March 2016 and April 2016, the FASB issued ASU
 2016-08 and ASU 2016-10, respectively, to clarify the
 implementation guidance on principle versus agent considerations
 and address the potential diversity in practice at initial
 application and cost; and the complexity of applying Topic 606,
 both at transition and on an ongoing basis related to
 identification of performance obligations and licensing
 arrangements; and ASU 2016-12 and ASU 2016-20, in May 2016 and
 December 2016, respectively, to improve in certain aspects of Topic
 606 , with the same effective date as ASU 2015-14. The Company will
 adopt this standard during its fiscal year ending June 28,
 2018. In the current period, the Company is assessing the contracts
 with its customers to identify the impact to its consolidated
 financial statements. The process is still ongoing and the Company
 expects to make significant progress in the coming quarters.

- added (2017-02-07):
[0001193125-17-033383:note_history:29]
In November 2016, the FASB issued ASU 2016-18, “Statement of
 Cash Flows (Topic 230): Restricted Cash,” which requires the
 statement of cash flows to explain the change during the period in
 the total of cash, cash equivalents and restricted cash or
 restricted cash equivalents. The Company has early adopted this
 update in the second quarter of fiscal year 2017 on a retrospective
 basis but there was no impact to the presentation of the
 comparative period in the unaudited condensed consolidated
 financial statements.

- changed (2017-02-07):
[0001193125-17-033383:note_history:30]
In November 2015, the FASB issued ASU 2015-17, “Balance Sheet
 Classification of Deferred Taxes,” which will require
 entities to present deferred tax assets (“DTAs”) and
 deferred tax liabilities (“DTLs”) as non-current in a
 classified balance sheet. The ASU simplifies the current guidance,
 which requires entities to separately present DTAs and DTLs as
 current and non-current in a classified balance sheet. The Company
 has early adopted this update in the first quarter of fiscal year
 2017. Accordingly, as of December 30, 2016, DTAs of $0.8
 million were classified to non-current assets in the unaudited
 condensed consolidated balance sheets. The Company adopted this
 update on a prospective basis and did not change the presentation
 of the comparative period.
  (was, 2016-11-09, similarity 0.9318):
[0001193125-16-764312:note_history:30]
In November 2015, the FASB issued ASU 2015-17, “Balance Sheet
 Classification of Deferred Taxes,” which will require
 entities to present deferred tax assets (“DTAs”) and
 deferred tax liabilities (“DTLs”) as non-current in a
 classified balance sheet. The ASU simplifies the current guidance,
 which requires entities to separately present DTAs and DTLs as
 current and non-current in a classified balance sheet. The Company
 adopted of this update early. Accordingly, as of September 30,
 2016, DTAs of $1.2 million were classified to non-current in
 the unaudited condensed consolidated balance sheets. The Company
 adopted this update on a prospective basis and did not change the
 presentation of the comparative period.

- changed (2017-02-07):
[0001193125-17-033383:note_history:31]
In September 2015, the FASB issued ASU 2015-16, “Business
 Combinations (Topic 805): Simplifying the Accounting for
 Measurement-Period Adjustments” which require an acquirer to
 recognize adjustments to provisional amounts that are identified
 during the measurement period in the reporting period in which the
 adjustment amounts are determined. The Company has adopted this
 update and applied it on a prospective basis.
  (was, 2016-11-09, similarity 0.9963):
[0001193125-16-764312:note_history:31]
In September 2015, the FASB issued ASU 2015-16, “Business
 Combinations (Topic 805): Simplifying the Accounting for
 Measurement-Period Adjustments” which require an acquirer to
 recognize adjustments to provisional amounts that are identified
 during the measurement period in the reporting period in which the
 adjustment amounts are determined. The Company has adopted of this
 update and applied it on a prospective basis.

- changed (2017-02-07):
[0001193125-17-033383:note_history:32]
In July 2015, the FASB issued ASU 2015-11, “Inventory (Topic
 330): Simplifying the Measurement of Inventory.” The update
 provides the guidance that an entity, that measured inventory by
 using first-in, first-out or average cost, should measure inventory
 at the lower of cost and net realizable value. Subsequent
 measurement is unchanged for inventory measured using last-in,
 first-out or the retail inventory method. The Company has adopted
 this update with no impact to the unaudited condensed consolidated
 financial statements.
  (was, 2016-11-09, similarity 0.6391):
[0001193125-16-764312:note_history:32]
In July 2015, the FASB issued ASU 2015-11, “Inventory (Topic
 330): Simplifying the Measurement of Inventory.” The update
 provides the guidance that an entity, that measured inventory by
 using first-in, first-out or average cost, should measure inventory
 at the lower of cost and net realizable value. Subsequent
 measurement is unchanged for inventory measured using last-in,
 first-out or the retail inventory method. The update is effective
 for fiscal years beginning after December 15, 2016, including
 interim periods within these fiscal years. This update should be
 applied prospectively with earlier application permitted as of the
 beginning of an interim or annual reporting date. The Company is
 currently evaluating the impact of the adoption of this update on
 its consolidated financial statements.

- changed (2017-02-07):
[0001193125-17-033383:note_history:33]
In April 2015, the FASB issued ASU 2015-03, “Interest –
 Imputation of Interest (Subtopic 835-30): Simplifying the
 Presentation of Debt Issuance Costs.” The update requires
 debt issuance costs related to a recognized debt liability be
 presented in the balance sheet as a direct deduction from the
 carrying amount of the related debt liability instead of being
 presented as an asset. Debt disclosures will include the face
 amount of the debt liability and the effective interest rate. The
 update requires retrospective application and represents a change
 in accounting principle. Additionally, in August 2015, the FASB
 issued ASU 2015-15, “Interest – Imputation of Interest
 (Subtopic 835-30): Presentation and Subsequent Measurement of Debt
 Issuance Costs Associated with Line-of-Credit Arrangements”
 to amend ASU 2015-03. The Company has adopted this amendment
 retrospectively. As of December 30, 2016 and June 24,
 2016, debt issuance costs of $0.4 million and $0.6 million,
 respectively, related to a recognized debt liability are presented
 in the balance sheet as a direct reduction of the carrying amount
 of the related debts.
  (was, 2016-11-09, similarity 0.9968):
[0001193125-16-764312:note_history:33]
In April 2015, the FASB issued ASU 2015-03, “Interest –
 Imputation of Interest (Subtopic 835-30): Simplifying the
 Presentation of Debt Issuance Costs.” The update requires
 debt issuance costs related to a recognized debt liability be
 presented in the balance sheet as a direct deduction from the
 carrying amount of the related debt liability instead of being
 presented as an asset. Debt disclosures will include the face
 amount of the debt liability and the effective interest rate. The
 update requires retrospective application and represents a change
 in accounting principle. Additionally, in August 2015, the FASB
 issued ASU 2015-15, “Interest – Imputation of Interest
 (Subtopic 835-30): Presentation and Subsequent Measurement of Debt
 Issuance Costs Associated with Line-of-Credit Arrangements”
 to amend ASU 2015-03. The Company has adopted this amendment
 retrospectively. As of September 30, 2016 and June 24, 2016, debt
 issuance costs of $0.5 million and $0.6 million, respectively,
 related to a recognized debt liability are presented in the balance
 sheet as a direct reduction of the carrying amount of the related
 debts.

- removed (2017-02-07):
[0001193125-16-764312:note_history:34]
In May 2014, the FASB issued ASU 2014-09, “Revenue from
 Contracts with Customers (Topic 606), issued as a new Topic,
 Accounting Standards Codification.” The core principle of
 this amendment is that an entity should recognize revenue to depict
 the transfer of promised goods or services to customers in an
 amount that reflects the consideration to which the entity expects
 to be entitled in exchange for those goods or services. This update
 is effective for public companies, as amended by ASU 2015-14, for
 annual reporting periods beginning after December 15, 2017,
 including interim periods within that reporting period. Earlier
 application of this guidance is permitted, but not before the
 original date of December 15, 2016, which can be adopted either
 retrospectively to each prior reporting period presented or as a
 cumulative-effect adjustment as of the date of adoption.
 Subsequently, in March 2016 and April 2016, the FASB issued ASU
 2016-08 and ASU 2016-10, to clarify the implementation guidance on
 principle versus agent considerations and address the potential
 diversity in practice at initial application and cost; and the
 complexity of applying Topic 606, both at transition and on an
 ongoing basis related to identification of performance obligations
 and licensing arrangements; and ASU 2016-12, in May 2016, to
 improve in certain aspects of Topic 606, with the same effective
 date as ASU 2015-14. The Company will adopt this standard during
 its fiscal year ending June 28, 2018. In the current period, the
 Company is assessing the contracts with its customers to identify
 the impact to its consolidated financial statements. The process is
 still ongoing and the Company expects to make significant progress
 in the coming quarters.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-07):
[0001193125-17-033383:note_history:35]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  | As of December 30, 2016 |  |  | As of June 24, 2016 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  | January 2017 (2) |  | $ | 20,000 |  |  | $ | 6,500 |  |
| Short-term loans from bank: |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank of England base rate +1.85% per annum |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  | 3,377 |  |  |  | — |  |
| Bank of England base rate + 2.2% per annum(3) |  | Repayable on monthly basis |  | May 2017 |  |  | 55 |  |  |  | — |  |
| Current portion of long-term borrowing |  |  |  |  |  |  | 15,100 |  |  |  | 18,100 |  |
|  |  |  |  |  |  |  | 38,532 |  |  |  | 24,600 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (245 | ) |  |  | (293 | ) |
|  |  |  |  |  |  | $ | 38,287 |  |  | $ | 24,307 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments |  | March 2017 |  | $ | 1,500 |  |  | $ | 4,500 |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  | Repayable in quarterly installments |  | May 2019 |  |  | 43,200 |  |  |  | 50,000 |  |
|  |  |  |  |  |  |  | 44,700 |  |  |  | 54,500 |  |
| Less: Current portion |  |  |  |  |  |  | (15,100 | ) |  |  | (18,100 | ) |
| Unamortized debt issuance costs |  |  |  |  |  |  | (188 | ) |  |  | (300 | ) |
| Non-current portion |  |  |  |  |  | $ | 29,412 |  |  | $ | 36,100 |  |
  (was, 2016-11-09, similarity 0.8285):
[0001193125-16-764312:note_history:35]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  |  | Maturity |  |  | As of September 30, 2016 |  |  | As of June 24, 2016 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  |  | Repayable in 1 to 6 months |  |  |  | October 2016 (2) |  |  | $ | 20,000 |  |  | $ | 6,500 |  |
| Short-term loans from bank: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank Base rate +1.85% per annum |  |  | Repayable based on credit term of secured accounts receivables |  |  |  |  |  |  |  | 1,182 |  |  |  | — |  |
| Current portion of long-term borrowing |  |  |  |  |  |  |  |  |  |  | 16,600 |  |  |  | 18,100 |  |
|  |  |  |  |  |  |  |  |  |  |  | 37,782 |  |  |  | 24,600 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  |  |  |  |  | (266 | ) |  |  | (293 | ) |
|  |  |  |  |  |  |  |  |  |  | $ | 37,516 |  |  | $ | 24,307 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  |  | Repayable in quarterly installments |  |  |  | March 2017 |  |  | $ | 3,000 |  |  | $ | 4,500 |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  |  | Repayable in quarterly installments |  |  |  | May 2019 |  |  |  | 46,600 |  |  |  | 50,000 |  |
|  |  |  |  |  |  |  |  |  |  |  | 49,600 |  |  |  | 54,500 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (16,600 | ) |  |  | (18,100 | ) |
| Unamortized debt issuance costs |  |  |  |  |  |  |  |  |  |  | (241 | ) |  |  | (300 | ) |
| Non-current portion |  |  |  |  |  |  |  |  |  | $ | 32,759 |  |  | $ | 36,100 |  |

- changed (2017-02-07):
[0001193125-17-033383:note_history:36]
| (2) | In December 2016, the maturity date was extended to January 2017. |
  (was, 2016-11-09, similarity 0.8657):
[0001193125-16-764312:note_history:36]
| (2) | In October 2016, the maturity date was extended to November 2016. |

- added (2017-02-07):
[0001193125-17-033383:note_history:37]
| (3) | As of December 30, 2016, the carrying amount of plant and machinery of Exception EMS secured to such loan was $4.3 million. Under the conditions stipulated in the loan agreement, this loan will be cross securitized, cross default and co-terminus with the short terms of loans of $3.4 million which are secured by accounts receivable. |

- changed (2017-02-07):
[0001193125-17-033383:note_history:38]
Under the long-term borrowing contract of a subsidiary, the loan is
 secured by certain property, plant and equipment of the subsidiary.
 The carrying amount of assets secured and pledged as collateral to
 such loan as of December 30, 2016 and June 24, 2016 was
 $46.4 million and $47.7 million, respectively. This subsidiary is
 also required to comply with maximum ratios of debt to equity and
 minimum levels of debt service coverage ratios, and Fabrinet must
 maintain an effective shareholding ratio. The carrying amounts of
 bank borrowings approximate their fair value.
  (was, 2016-11-09, similarity 0.9937):
[0001193125-16-764312:note_history:38]
Under the long-term borrowing contract of a subsidiary, the loan is
 secured by certain property, plant and equipment of the subsidiary.
 The carrying amount of assets secured and pledged as collateral to
 such loan as of September 30, 2016 and June 24, 2016 was $47.0
 million and $47.7 million, respectively. This subsidiary is also
 required to comply with maximum ratios of debt to equity and
 minimum levels of debt service coverage ratios, and Fabrinet must
 maintain an effective shareholding ratio. The carrying amounts of
 bank borrowings approximate their fair value.

- changed (2017-02-07):
[0001193125-17-033383:note_history:39]
As of December 30, 2016 and June 24, 2016, the Company
 was in compliance with its bank borrowing agreements. In addition
 to financial ratios, certain of the Company’s credit
 facilities include customary events of default.
  (was, 2016-11-09, similarity 0.9834):
[0001193125-16-764312:note_history:39]
As of September 30, 2016 and June 24, 2016, the Company was in
 compliance with its bank borrowing agreements. In addition to
 financial ratios, certain of the Company’s credit facilities
 include customary events of default.

- changed (2017-02-07):
[0001193125-17-033383:note_history:40]
The movements of long-term loans were as follows for the six months
 ended December 30, 2016 and December 25, 2015:
  (was, 2016-11-09, similarity 0.9151):
[0001193125-16-764312:note_history:40]
The movements of long-term loans were as follows for the three
 months ended September 30, 2016 and September 25, 2015:

- changed (2017-02-07):
[0001193125-17-033383:note_history:41]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 30, 2016 |  |  | December 25, 2015 |  |
| Opening balance |  | $ | 54,500 |  |  | $ | 10,500 |  |
| Repayments during the period |  |  | (9,800 | ) |  |  | (3,000 | ) |
| Closing balance |  | $ | 44,700 |  |  | $ | 7,500 |  |
  (was, 2016-11-09, similarity 0.887):
[0001193125-16-764312:note_history:41]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 30, 2016 |  |  | September 25, 2015 |  |
| Opening balance |  | $ | 54,500 |  |  | $ | 10,500 |  |
| Repayments during the period |  |  | (4,900 | ) |  |  | (1,500 | ) |
| Closing balance |  | $ | 49,600 |  |  | $ | 9,000 |  |

- changed (2017-02-07):
[0001193125-17-033383:note_history:42]
As of December 30, 2016, future maturities of long-term debt
 during each fiscal year were as follows:
  (was, 2016-11-09, similarity 0.9738):
[0001193125-16-764312:note_history:42]
As of September 30, 2016, future maturities of long-term debt
 during each fiscal year were as follows:

- changed (2017-02-07):
[0001193125-17-033383:note_history:43]
| (amount in thousands) |  |  |  |
| 2017 (remaining six months) |  | $ | 8,300 |  |
| 2018 |  |  | 13,600 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 44,700 |  |
  (was, 2016-11-09, similarity 0.9802):
[0001193125-16-764312:note_history:43]
| (amount in thousands) |  |  |  |
| 2017 (remaining nine months) |  | $ | 13,200 |  |
| 2018 |  |  | 13,600 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 49,600 |  |

- changed (2017-02-07):
[0001193125-17-033383:note_history:44]
Fabrinet entered into a syndicated senior credit facility agreement
 (the “Facility Agreement”) with a consortium of banks
 on May 22, 2014. The Facility Agreement, led by Bank of
 America, provides for a $200.0 million credit line, comprised of a
 $150.0 million revolving loan facility and a $50.0 million delayed
 draw term loan facility. The revolving loan facility contains an
 accordion feature permitting Fabrinet to request an increase in the
 facility up to $100.0 million subject to customary terms and
 conditions and provided that no default or event of default exists
 at the time of request. The revolving loan facility will be
 terminated and all amounts outstanding will be due and payable in
 full on May 22, 2019. The principal amount of any drawn term
 loans must be repaid according to scheduled quarterly amortization
 payments, with final payment of all amounts outstanding, plus
 accrued interest, being due May 22, 2019.
  (was, 2016-11-09, similarity 0.6902):
[0001193125-16-764312:note_history:44]
Fabrinet entered into a syndicated senior credit facility agreement
 (the “Facility Agreement”) with a consortium of banks
 on May 22, 2014. The Facility Agreement, led by Bank of America,
 provides for a $200.0 million credit line, comprised of a $150.0
 million revolving loan facility and a $50.0 million delayed draw
 term loan facility. The revolving loan facility contains an
 accordion feature permitting Fabrinet to request an increase in the
 facility up to $100.0 million subject to customary terms and
 conditions and provided that no default or event of default exists
 at the time of request. The revolving loan facility terminates and
 all amounts outstanding are due and payable in full on May 22,
 2019. The principal amount of any drawn term loans must be repaid
 according to scheduled quarterly amortization payments, with final
 payment of all amounts outstanding, plus accrued interest, being
 due May 22, 2019.

- added (2017-02-07):
[0001193125-17-033383:note_history:45]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. As of
 December 30, 2016, $20.0 million of the revolving borrowing
 and $43.2 million of the term loan borrowing was outstanding under
 the Facility Agreement, resulting in available credit facilities of
 $136.8 million. Borrowings under the revolving credit facility are
 classified as current liabilities in the unaudited condensed
 consolidated balance sheets as the Company has the periodic option
 to renew or pay, all or a portion of, the outstanding balance at
 the end of the maturity date, which is in the range of one to six
 months, without premium or penalty, upon notice to the
 administrative agent. During December 2016, the Company sent
 notices to the bank to renew the maturity date of its revolving
 borrowings. The bank approved the notices and extended the maturity
 to January 2017.

- changed (2017-02-07):
[0001193125-17-033383:note_history:46]
The Facility Agreement contains customary affirmative and negative
 covenants. Negative covenants include, among other things,
 limitations on liens, indebtedness, investments, mergers, sales of
 assets, changes in the nature of the business, dividends and
 distributions, affiliate transactions and capital expenditures. The
 Facility Agreement contains financial covenants requiring Fabrinet
 to maintain: (1) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (2) a minimum debt service coverage ratio of
 not less than 1.50:1.00; (3) a maximum senior leverage ratio
 of not more than 2.50:1.00; and (4) a minimum quick ratio of
 not less than 1.10:1.00. Each of these financial covenants is
 calculated on a consolidated basis for the consecutive four fiscal
 quarter period then ended. As of December 30, 2016, the
 Company was in compliance with all covenants under the Facility
 Agreement.
  (was, 2016-11-09, similarity 0.9962):
[0001193125-16-764312:note_history:46]
The Facility Agreement contains customary affirmative and negative
 covenants. Negative covenants include, among other things,
 limitations on liens, indebtedness, investments, mergers, sales of
 assets, changes in the nature of the business, dividends and
 distributions, affiliate transactions and capital expenditures. The
 Facility Agreement contains financial covenants requiring Fabrinet
 to maintain: (1) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (2) a minimum debt service coverage ratio of not
 less than 1.50:1.00; (3) a maximum senior leverage ratio of not
 more than 2.50:1.00; and (4) a minimum quick ratio of not less than
 1.10:1.00. Each of these financial covenants is calculated on a
 consolidated basis for the consecutive four fiscal quarter period
 then ended. As of September 30, 2016, the Company was in compliance
 with all covenants under the Facility Agreement.

- changed (2017-02-07):
[0001193125-17-033383:note_history:47]
Fabrinet intends to use the proceeds of the credit line to finance
 its future manufacturing facility in Thailand, and for general
 corporate purposes including mergers and acquisitions of
 complementary manufacturing businesses or technology, although
 Fabrinet has no current commitments with respect to any such
 acquisitions.
  (was, 2016-11-09, similarity 0.9329):
[0001193125-16-764312:note_history:47]
Fabrinet intends to use the proceeds of the credit line to finance
 its future manufacturing buildings in the United States and
 Thailand, and for general corporate purposes including mergers and
 acquisitions of complementary manufacturing businesses or
 technology, although Fabrinet has no current commitments with
 respect to any such acquisitions.

- added (2017-02-07):
[0001193125-17-033383:note_history:48]
In connection with the acquisition of Exception EMS, the Company
 assumed a secured borrowing agreement that is secured by trade
 accounts receivable of Exception EMS. As of December 30, 2016,
 the carrying amount of trade accounts receivable secured to the
 loans was $6.5 million. The secured borrowing agreement contains
 certain covenants that Exception EMS is required to comply with:
 (1) the value of credit notes may not exceed 4% of the value
 of assigned debts measured on a monthly basis, and (2) rolling
 cash flow must be provided with the monthly management information.
 As of December 30, 2016, the subsidiary was in compliance with
 all covenants under the secured borrowing agreement.

- changed (2017-02-07):
[0001193125-17-033383:note_history:49]
As of December 30, 2016, the Company drew down $3.4 million
 from this facility, which is recorded as short-term loans in the
 unaudited condensed consolidated balance sheets. The agreement
 bears interest for discount charge at 1.85% per annum above
 Bank of England base rate.
  (was, 2016-11-09, similarity 0.7977):
[0001193125-16-764312:note_history:49]
As of September 30, 2016, the Company drew down from this facility
 of $1.2 million which is recorded as short-term loans in the
 unaudited condensed consolidated balance sheets. The agreement
 bears interest for discount charge at 1.85% per annum above based
 rate.

- changed (2017-02-07):
[0001193125-17-033383:note_history:50]
Undrawn available credit facilities classified by availability
 period of future borrowing as of December 30, 2016 and
 June 24, 2016 were as follows:
  (was, 2016-11-09, similarity 0.9819):
[0001193125-16-764312:note_history:50]
Undrawn available credit facilities classified by availability
 period of future borrowing as of September 30, 2016 and June 24,
 2016 were as follows:

- changed (2017-02-07):
[0001193125-17-033383:note_history:51]
| (amount in thousands) |  | December 30, 2016 |  |  | June 24, 2016 |  |
| Short-term |  | $ | 3,395 |  |  | $ | 1,414 |  |
| Long-term |  | $ | 136,800 |  |  | $ | 143,500 |  |
  (was, 2016-11-09, similarity 0.9817):
[0001193125-16-764312:note_history:51]
| (amount in thousands) |  | September 30, 2016 |  |  | June 24, 2016 |  |
| Short-term |  | $ | 2,999 |  |  | $ | 1,414 |  |
| Long-term |  | $ | 133,400 |  |  | $ | 143,500 |  |

- added (2017-02-07):
[0001193125-17-033383:note_history:52]
As of December 30, 2016, Fabrinet had made a request to
 drawdown $14.0 million on its available outstanding revolving
 borrowing. The bank approved the request for drawdown and provided
 cash to settle this request to Fabrinet on January 3, 2017.
 Due to the settlement of the transaction taking place after the
 balance sheet date, the respective cash and loan amount are not
 recorded in the unaudited condensed consolidated balance sheet as
 of December 30, 2016.

- removed (2017-02-07):
[0001193125-16-764312:note_history:53]
On February 26, 2015, the Company entered into the Second Amendment
 to the Facility Agreement. The amendment extended the availability
 period for draws on the term loan facility from May 21, 2015 to
 July 31, 2015. It also allowed the Company, upon the satisfaction
 of certain conditions, to designate from time to time one or more
 of its subsidiaries as borrowers under the Facility Agreement. On
 July 31, 2015, the Company entered into the Third Amendment to the
 Facility Agreement. The amendment extended the availability period
 for draws on the term loan facility from July 31, 2015 to July 31,
 2016. As of September 30, 2016, there were $20.0 million of the
 revolving borrowing and $46.6 million of the term loan borrowing
 outstanding under the Facility Agreement, resulting in available
 credit facilities of $133.4 million. Borrowings under the revolving
 credit facility are classified as current liabilities in the
 unaudited condensed consolidated balance sheets as the Company has
 the periodic option to renew or pay, all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. During October 2016, the
 Company sent notices to the bank to renew the maturity date of its
 revolving borrowings. The bank approved the notices and extended
 the maturity to November 2016.

- removed (2017-02-07):
[0001193125-16-764312:note_history:54]
In connection with the business acquisition, the Company assumed a
 secured borrowing agreement. The loans are secured by trade
 accounts receivable and the way of chattels mortgage over the plant
 and machine of Exception EMS. As of September 30, 2016, the
 carrying amount of trade accounts receivable and plant and machine
 secured to such loans were $5.5 million and $4.9 million,
 respectively The secured borrowing agreement contains certain
 covenants that the Company is required to comply with: (1) the
 value of credit notes may not exceed 4% of the value of assigned
 debts measured on a monthly basis, and (2) rolling cash flow must
 be provided with monthly management information. As of September
 30, 2016, the Company was in compliance with all covenants under
 the secured borrowing agreement.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-07):
[0001193125-17-033383:note_history:55]
The movements of long-term loans were as follows for the six months
 ended December 30, 2016 and December 25, 2015:
  (was, 2016-11-09, similarity 0.9151):
[0001193125-16-764312:note_history:55]
The movements of long-term loans were as follows for the three
 months ended September 30, 2016 and September 25, 2015:

- changed (2017-02-07):
[0001193125-17-033383:note_history:56]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 30, 2016 |  |  | December 25, 2015 |  |
| Opening balance |  | $ | 54,500 |  |  | $ | 10,500 |  |
| Repayments during the period |  |  | (9,800 | ) |  |  | (3,000 | ) |
| Closing balance |  | $ | 44,700 |  |  | $ | 7,500 |  |
  (was, 2016-11-09, similarity 0.887):
[0001193125-16-764312:note_history:56]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 30, 2016 |  |  | September 25, 2015 |  |
| Opening balance |  | $ | 54,500 |  |  | $ | 10,500 |  |
| Repayments during the period |  |  | (4,900 | ) |  |  | (1,500 | ) |
| Closing balance |  | $ | 49,600 |  |  | $ | 9,000 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-07):
[0001193125-17-033383:note_history:57]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  | As of December 30, 2016 |  |  | As of June 24, 2016 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  | January 2017 (2) |  | $ | 20,000 |  |  | $ | 6,500 |  |
| Short-term loans from bank: |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank of England base rate +1.85% per annum |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  | 3,377 |  |  |  | — |  |
| Bank of England base rate + 2.2% per annum(3) |  | Repayable on monthly basis |  | May 2017 |  |  | 55 |  |  |  | — |  |
| Current portion of long-term borrowing |  |  |  |  |  |  | 15,100 |  |  |  | 18,100 |  |
|  |  |  |  |  |  |  | 38,532 |  |  |  | 24,600 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (245 | ) |  |  | (293 | ) |
|  |  |  |  |  |  | $ | 38,287 |  |  | $ | 24,307 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments |  | March 2017 |  | $ | 1,500 |  |  | $ | 4,500 |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  | Repayable in quarterly installments |  | May 2019 |  |  | 43,200 |  |  |  | 50,000 |  |
|  |  |  |  |  |  |  | 44,700 |  |  |  | 54,500 |  |
| Less: Current portion |  |  |  |  |  |  | (15,100 | ) |  |  | (18,100 | ) |
| Unamortized debt issuance costs |  |  |  |  |  |  | (188 | ) |  |  | (300 | ) |
| Non-current portion |  |  |  |  |  | $ | 29,412 |  |  | $ | 36,100 |  |
  (was, 2016-11-09, similarity 0.8285):
[0001193125-16-764312:note_history:57]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  |  | Maturity |  |  | As of September 30, 2016 |  |  | As of June 24, 2016 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  |  | Repayable in 1 to 6 months |  |  |  | October 2016 (2) |  |  | $ | 20,000 |  |  | $ | 6,500 |  |
| Short-term loans from bank: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank Base rate +1.85% per annum |  |  | Repayable based on credit term of secured accounts receivables |  |  |  |  |  |  |  | 1,182 |  |  |  | — |  |
| Current portion of long-term borrowing |  |  |  |  |  |  |  |  |  |  | 16,600 |  |  |  | 18,100 |  |
|  |  |  |  |  |  |  |  |  |  |  | 37,782 |  |  |  | 24,600 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  |  |  |  |  | (266 | ) |  |  | (293 | ) |
|  |  |  |  |  |  |  |  |  |  | $ | 37,516 |  |  | $ | 24,307 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  |  | Repayable in quarterly installments |  |  |  | March 2017 |  |  | $ | 3,000 |  |  | $ | 4,500 |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  |  | Repayable in quarterly installments |  |  |  | May 2019 |  |  |  | 46,600 |  |  |  | 50,000 |  |
|  |  |  |  |  |  |  |  |  |  |  | 49,600 |  |  |  | 54,500 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (16,600 | ) |  |  | (18,100 | ) |
| Unamortized debt issuance costs |  |  |  |  |  |  |  |  |  |  | (241 | ) |  |  | (300 | ) |
| Non-current portion |  |  |  |  |  |  |  |  |  | $ | 32,759 |  |  | $ | 36,100 |  |

- changed (2017-02-07):
[0001193125-17-033383:note_history:58]
| (2) | In December 2016, the maturity date was extended to January 2017. |
  (was, 2016-11-09, similarity 0.8657):
[0001193125-16-764312:note_history:58]
| (2) | In October 2016, the maturity date was extended to November 2016. |

- added (2017-02-07):
[0001193125-17-033383:note_history:59]
| (3) | As of December 30, 2016, the carrying amount of plant and machinery of Exception EMS secured to such loan was $4.3 million. Under the conditions stipulated in the loan agreement, this loan will be cross securitized, cross default and co-terminus with the short terms of loans of $3.4 million which are secured by accounts receivable. |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-07):
[0001193125-17-033383:note_history:60]
Undrawn available credit facilities classified by availability
 period of future borrowing as of December 30, 2016 and
 June 24, 2016 were as follows:
  (was, 2016-11-09, similarity 0.9819):
[0001193125-16-764312:note_history:60]
Undrawn available credit facilities classified by availability
 period of future borrowing as of September 30, 2016 and June 24,
 2016 were as follows:

- changed (2017-02-07):
[0001193125-17-033383:note_history:61]
| (amount in thousands) |  | December 30, 2016 |  |  | June 24, 2016 |  |
| Short-term |  | $ | 3,395 |  |  | $ | 1,414 |  |
| Long-term |  | $ | 136,800 |  |  | $ | 143,500 |  |
  (was, 2016-11-09, similarity 0.9817):
[0001193125-16-764312:note_history:61]
| (amount in thousands) |  | September 30, 2016 |  |  | June 24, 2016 |  |
| Short-term |  | $ | 2,999 |  |  | $ | 1,414 |  |
| Long-term |  | $ | 133,400 |  |  | $ | 143,500 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-07):
[0001193125-17-033383:note_history:62]
As of December 30, 2016, future maturities of long-term debt
 during each fiscal year were as follows:
  (was, 2016-11-09, similarity 0.9738):
[0001193125-16-764312:note_history:62]
As of September 30, 2016, future maturities of long-term debt
 during each fiscal year were as follows:

- changed (2017-02-07):
[0001193125-17-033383:note_history:63]
| (amount in thousands) |  |  |  |
| 2017 (remaining six months) |  | $ | 8,300 |  |
| 2018 |  |  | 13,600 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 44,700 |  |
  (was, 2016-11-09, similarity 0.9802):
[0001193125-16-764312:note_history:63]
| (amount in thousands) |  |  |  |
| 2017 (remaining nine months) |  | $ | 13,200 |  |
| 2018 |  |  | 13,600 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 49,600 |  |
