# FN MD&A — 0001193125-17-033383


## mdna

[0001193125-17-033383:mdna:1]
[same as prior period, unchanged from 0001193125-16-764312:mdna:1]

[0001193125-17-033383:mdna:2]
[same as prior period, unchanged from 0001193125-16-764312:mdna:2]

[0001193125-17-033383:mdna:3]
[same as prior period, unchanged from 0001193125-16-764312:mdna:3]

[0001193125-17-033383:mdna:4]
|  | • |  | our expectation that the portion of our future revenues attributable to customers in regions outside of North America will increase compared with the portion of those revenues for the six months ended December 30, 2016; |

[0001193125-17-033383:mdna:5]
[same as prior period, unchanged from 0001193125-16-764312:mdna:5]

[0001193125-17-033383:mdna:6]
[same as prior period, unchanged from 0001193125-16-764312:mdna:6]

[0001193125-17-033383:mdna:7]
[same as prior period, unchanged from 0001193125-16-764312:mdna:7]

[0001193125-17-033383:mdna:8]
[same as prior period, unchanged from 0001193125-16-764312:mdna:8]

[0001193125-17-033383:mdna:9]
[same as prior period, unchanged from 0001193125-16-764312:mdna:9]

[0001193125-17-033383:mdna:10]
[same as prior period, unchanged from 0001193125-16-764312:mdna:10]

[0001193125-17-033383:mdna:11]
[same as prior period, unchanged from 0001193125-16-764312:mdna:11]

[0001193125-17-033383:mdna:12]
[same as prior period, unchanged from 0001193125-16-764312:mdna:12]

[0001193125-17-033383:mdna:13]
[same as prior period, unchanged from 0001193125-16-764312:mdna:13]

[0001193125-17-033383:mdna:14]
[same as prior period, unchanged from 0001193125-16-764312:mdna:14]

[0001193125-17-033383:mdna:15]
[same as prior period, unchanged from 0001193125-16-764312:mdna:15]

[0001193125-17-033383:mdna:16]
[same as prior period, unchanged from 0001193125-16-764312:mdna:16]

[0001193125-17-033383:mdna:17]
[same as prior period, unchanged from 0001193125-16-764312:mdna:17]

[0001193125-17-033383:mdna:18]
[same as prior period, unchanged from 0001193125-16-764312:mdna:18]

[0001193125-17-033383:mdna:19]
[same as prior period, unchanged from 0001193125-16-764312:mdna:19]

[0001193125-17-033383:mdna:20]
We provide advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment
manufacturers (“OEMs”) of complex products such as optical communication components, modules and sub-systems, industrial lasers, medical devices and sensors. We offer a broad range of advanced optical and electro-mechanical capabilities
across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, complex printed circuit board assembly, advanced packaging, integration, final assembly and test. Although, we focus primarily
on low-volume production of a wide variety of high complexity products, which we refer to as “low-volume, high-mix,” we also have the capability to accommodate high-volume production. Based on our experience with, and positive feedback we
have received from our customers, we believe we are a global leader in providing these services to the optical communications, industrial lasers and automotive markets.

[0001193125-17-033383:mdna:21]
[same as prior period, unchanged from 0001193125-16-764312:mdna:21]

[0001193125-17-033383:mdna:22]
[same as prior period, unchanged from 0001193125-16-764312:mdna:22]

[0001193125-17-033383:mdna:23]
[same as prior period, unchanged from 0001193125-16-764312:mdna:23]

[0001193125-17-033383:mdna:24]
On September 14, 2016, we acquired 100% shareholding in Global CEM Solutions Ltd. and all of its subsidiaries, a
privately-held group located in Wiltshire, United Kingdom (“Exception EMS”), for cash consideration of approximately $13.0 million, net of cash acquired. This is a strategic acquisition involving new geographies, new sectors and new
customers. Exception EMS provides contract electronics manufacturing services primarily to the European electronics market with innovative solutions, adding value to the design, manufacture and testing of printed circuit board assemblies. Its
customers include industrial, energy, aerospace and defense companies, with approximately 80% of its revenue derived from customers in Europe. See Note 8—business acquisitions to the unaudited condensed consolidated financial statements for
further details.

[0001193125-17-033383:mdna:25]
[same as prior period, unchanged from 0001193125-16-764312:mdna:25]

[0001193125-17-033383:mdna:26]
During
the week of August 10, 2015, our subsidiary in China temporarily suspended production in its manufacturing facility due to flooding caused by Typhoon Soudelor and resumed operations on August 15, 2015. During the six months ended
December 25, 2015, we recognized $0.9 million of losses incurred from the event in the unaudited condensed consolidated statements of operations and comprehensive income. We received a final payment of $0.8 million from an insurer against our
claim for flood damage during the three months ended March 25, 2016.

[0001193125-17-033383:mdna:27]
[same as prior period, unchanged from 0001193125-16-764312:mdna:27]

[0001193125-17-033383:mdna:28]
Our total revenues increased by $118.1 million, or 50.7%, to $351.2 million for the three months ended December 30, 2016, compared with
$233.0 million for the three months ended December 25, 2015. Our total revenues increased by $233.7 million, or 52.0%, to $683.2 million for the six months ended December 30, 2016, compared with $449.5 million for the six months ended
December 25, 2015. The increase was primarily due to (1) an increase in our customers’ demand for both optical and non-optical communications manufacturing services during the three and six months ended December 30, 2016,
(2) the positive impact from an additional week of revenue during the six months ended December 30, 2016 and (3) $6.2 million of revenue for the three months ended December 30, 2016 and $7.0 million of revenue for the six months
ended December 30, 2016 from companies we acquired in September 2016.

[0001193125-17-033383:mdna:29]
We believe our ability to expand our relationships with
existing customers and attract new customers is due to a number of factors, including our broad range of complex engineering and manufacturing service offerings, flexible low-cost manufacturing platform, process optimization capabilities, advanced
supply chain management, excellent customer service, and experienced management team. While we expect the prices we charge for our manufactured products to decrease over time (partly as a result of competitive market forces), we still believe we
will be able to maintain favorable pricing for our services because of our ability to reduce cycle time, adjust our product mix by focusing on more complicated products, improve product quality and yields, and reduce material costs for the products
we manufacture. We believe these capabilities have enabled us to help our OEM customers reduce their manufacturing costs while maintaining or improving the design, quality, reliability, and delivery times for their products.

[0001193125-17-033383:mdna:30]
[same as prior period, unchanged from 0001193125-16-764312:mdna:30]

[0001193125-17-033383:mdna:31]
[same as prior period, unchanged from 0001193125-16-764312:mdna:31]

[0001193125-17-033383:mdna:32]
The percentage of our revenues generated from a bill-to location outside of North America increased from 46.7% in the three months ended
December 25, 2015 to 55.0% in the three months ended December 30, 2016 and from 48.7% in the six months ended December 25, 2015 to 52.6% in the six months ended December 30, 2016, primarily because of an increase in sales to our
customers outside North America, partially due to an increase in sales to our customers in Europe due to the acquisition of Exception EMS in September 2016. We expect that the portion of our future revenues attributable to customers in regions
outside North America will continue to increase as compared with the portion of revenues attributable to such customers during the six months ended December 30, 2016.

[0001193125-17-033383:mdna:33]
[same as prior period, unchanged from 0001193125-16-764312:mdna:33]

[0001193125-17-033383:mdna:34]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 30,2016 |  |  | December 25,2015 |  |  | December 30,2016 |  |  | December 25,2015 |  |
| North America |  |  | 45.0 | % |  |  | 53.3 | % |  |  | 47.4 | % |  |  | 51.3 | % |
| Asia-Pacific |  |  | 38.9 |  |  |  | 36.2 |  |  |  | 36.8 |  |  |  | 37.4 |  |
| Europe |  |  | 16.1 |  |  |  | 10.5 |  |  |  | 15.8 |  |  |  | 11.3 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-17-033383:mdna:35]
[same as prior period, unchanged from 0001193125-16-764312:mdna:35]

[0001193125-17-033383:mdna:36]
We enter into supply agreements with our customers which generally have an initial term of up to three years, subject to automatic renewals for
subsequent one-year terms unless expressly terminated. Although there are no minimum purchase requirements in our supply agreements, our customers provide us with rolling forecasts of their demand requirements. Our supply agreements generally
include provisions for pricing and periodic review of pricing, consignment of our customer’s unique production equipment to us, and the sharing of benefits from cost-savings derived from our efforts. We are generally required to purchase
materials, which may include long lead-time materials and materials that are subject to minimum order

[0001193125-17-033383:mdna:37]
quantities and/or non-cancelable or non-returnable terms, to meet the stated demands of our customers. After procuring materials, we manufacture products for our customers based on purchase
orders that contain terms regarding product quantities, delivery locations and delivery dates. Our customers generally are obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not
consumed by our customers within a specified period of time, or are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under our contracts. Once materials are designated
as either excess or obsolete inventory, our customers are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products.

[0001193125-17-033383:mdna:38]
[same as prior period, unchanged from 0001193125-16-764312:mdna:37]

[0001193125-17-033383:mdna:39]
The key components of
our cost of revenues are material costs, employee costs, and infrastructure-related costs. Material costs generally represent the majority of our cost of revenues. Several of the materials we require to manufacture products for our customers are
customized for their products and often sourced from a single supplier or in some cases, our own subsidiaries. Shortages from sole-source suppliers due to yield loss, quality concerns and capacity constraints, among other factors, may increase our
expenses and negatively impact our gross profit margin or total revenues in a given quarter. Material costs include scrap material. Historically, scrap rate diminishes during a product’s life cycle due to process, fixturing and test improvement
and optimization.

[0001193125-17-033383:mdna:40]
A second significant element of our cost of revenues is employee costs, including indirect employee costs related to
design, configuration and optimization of manufacturing processes for our customers, quality testing, materials testing and other engineering services; and direct costs related to our manufacturing employees. Direct employee costs include employee
salaries, insurance and benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a lesser
extent, costs to recruit, train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand, the PRC and the United Kingdom, the fluctuation of the Thai baht, Chinese Renminbi (“RMB”) and
Pound Sterling (“GBP”) against our functional currency, the U.S. dollar, and our ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may
impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention and asset utilization.

[0001193125-17-033383:mdna:41]
Our infrastructure costs are comprised of depreciation, utilities, facilities management and overhead costs. Most of our facility leases are
long-term agreements. Our depreciation costs include buildings and fixed assets, primarily at our Pinehurst campus in Thailand, and capital equipment located at each of our manufacturing locations.

[0001193125-17-033383:mdna:42]
During the three and six months ended December 30, 2016 and December 25, 2015, discretionary merit-based bonus awards were made to
our non-executive employees. Charges included in cost of revenues for bonus awards to non-executive employees were $0.9 million and $0.7 million for the three months ended December 30, 2016 and December 25, 2015, respectively, and $
1.8 million and $1.5 million for the six months ended December 30, 2016 and December 25, 2015, respectively.

[0001193125-17-033383:mdna:43]
Share-based
compensation expense included in cost of revenues was $1.5 million and $0.5 million for the three months ended December 30, 2016 and December 25, 2015, respectively, and $2.5 million and $1.1 million for the six months ended
December 30, 2016 and December 25, 2015, respectively.

[0001193125-17-033383:mdna:44]
We expect to incur incremental costs of revenue as a result of our
planned expansion into new geographic markets, though we are not able to determine the amount of these incremental expenses.

[0001193125-17-033383:mdna:45]
Selling, General and Administrative Expenses

[0001193125-17-033383:mdna:46]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative and other support
personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other general expenses not related to cost of
revenues. In fiscal year 2017, we expect our SG&A expenses will increase on an absolute dollar basis and decrease as a percentage of revenue compared with fiscal year 2016, due to the acquisition of Exception EMS and higher share-based
compensation expenses as a result of restricted share units and performance share units granted to executives in August 2016.

[0001193125-17-033383:mdna:47]
The
compensation committee of our board of directors approved a fiscal year 2017 executive incentive plan with quantitative objectives, based on achieving certain revenue targets and gross margin targets for our fiscal year ending June 30, 2017.
Bonuses under our fiscal year 2017 executive incentive plan are payable after the end of fiscal year 2017. In fiscal year 2016, the compensation committee approved a fiscal year 2016 executive incentive plan with quantitative objectives, based on
achieving certain revenue and non-GAAP earnings per share targets for our fiscal year ended June 24, 2016, as well as qualitative objectives, based on achieving individual performance goals. In the three months ended September 30, 2016,
the compensation committee awarded bonuses to our executive employees for Company and individual achievements of performance under our fiscal 2016 executive incentive plan. Discretionary merit-based bonus awards were also available to our
non-executive employees and were payable as of December 30, 2016.

[0001193125-17-033383:mdna:48]
Charges included in SG&A expenses for bonus awards to
non-executive and executive employees were $1.2 million and $1.6 million for the three months ended December 30, 2016 and December 25, 2015, respectively, and $2.1 million and $2.2 million for the six months ended December 30, 2016
and December 25, 2015, respectively.

[0001193125-17-033383:mdna:49]
Share-based compensation expense included in SG&A expenses was $7.1 million and $2.6
million for the three months ended December 30, 2016 and December 25, 2015, respectively, and $11.7 million and $4.7 million for the six months ended December 30, 2016 and December 25, 2015, respectively.

[0001193125-17-033383:mdna:50]
[same as prior period, unchanged from 0001193125-16-764312:mdna:49]

[0001193125-17-033383:mdna:51]
[same as prior period, unchanged from 0001193125-16-764312:mdna:50]

[0001193125-17-033383:mdna:52]
As a result of our international operations, we are exposed to foreign exchange risk arising from various currency exposures
primarily with respect to the Thai baht. Although a majority of our total revenues is denominated in U.S. dollars, a substantial portion of our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rate
between the Thai baht and the U.S. dollar has fluctuated substantially in recent years and may continue to fluctuate substantially in the future. We report our financial results in U.S. dollars and our results of operations have been and could in
the future be negatively impacted if the Thai baht appreciates against the U.S. dollar. Smaller portions of our expenses are incurred in a variety of other currencies, including RMB, GBP, Canadian dollars, Euros, and Japanese yen, the appreciation
of which may also negatively impact our financial results.

[0001193125-17-033383:mdna:53]
In addition, we were exposed to foreign exchange risk in connection with the
long-term loan and cross currency swap arrangements we entered into with TMB Bank Public Company Limited (the “Bank”) in May 2011 for the construction of Pinehurst Building 6. The terms of the contract with the Bank provide the following
facilities: (1) a term loan facility for up to Thai baht 960 million (equal to $30.0 million) with a fixed interest rate of 5.28% per annum, (2) a hedging facility for currency interest rate swaps with a notional amount of $30.0
million, and (3) a settlement limit of Thai baht 65 million, subject to certain terms and conditions as set forth therein. Borrowings and interest under the term loan have been scheduled to be repaid on a quarterly basis between September
2011 and March 2017. As of December 30, 2016, we had outstanding borrowings under the term loan facility of $1.5 million. Under the terms of the cross currency swap arrangements, amounts drawn in Thai baht were converted to U.S. dollars for
repayment by us on a quarterly basis at the floating rate of London Interbank Offered Rate (LIBOR) plus 2.8% per annum.

[0001193125-17-033383:mdna:54]
In order to manage the risks arising from fluctuations in foreign currency exchange rates, we use
derivative instruments. We may enter into exchange currency forward or put option contracts to manage foreign currency exposures associated with certain assets and liabilities and other forecasted foreign currency transactions and may designate
these instruments as hedging instruments. The forward and put option contracts generally have maturities of up to 12 months. All foreign currency exchange contracts are recognized in the unaudited condensed consolidated balance sheet at fair value.
Gain or loss on our forward and put option contracts generally offset the assets, liabilities, and transactions economically hedged.

[0001193125-17-033383:mdna:55]
We
had foreign currency denominated assets and liabilities in Thai baht, RMB and GBP as follows:

[0001193125-17-033383:mdna:56]
|  |  | As of December 30, 2016 |  |  | As of June 24, 2016 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 552,392 |  |  | $ | 15,417 |  |  |  | 50.7 |  |  |  | 834,536 |  |  | $ | 23,594 |  |  |  | 91.3 |  |
| RMB |  |  | 17,572 |  |  |  | 2,533 |  |  |  | 8.3 |  |  |  | 14,835 |  |  |  | 2,255 |  |  |  | 8.7 |  |
| GBP |  |  | 10,142 |  |  |  | 12,465 |  |  |  | 41.0 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  |  |  |  |  | $ | 30,415 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 25,849 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,767,161 |  |  | $ | 49,321 |  |  |  | 78.3 |  |  |  | 1,517,782 |  |  | $ | 42,912 |  |  |  | 92.0 |  |
| RMB |  |  | 23,131 |  |  |  | 3,334 |  |  |  | 5.3 |  |  |  | 24,654 |  |  |  | 3,748 |  |  |  | 8.0 |  |
| GBP |  |  | 8,396 |  |  |  | 10,319 |  |  |  | 16.4 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  |  |  |  |  | $ | 62,974 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 46,660 |  |  |  | 100.0 |  |

[0001193125-17-033383:mdna:57]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other
current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and
offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of December 30, 2016, we did not have derivative contracts denominated in Thai baht. As of June 24, 2016, we had $84.5
million in forward contracts outstanding against forecasted Thai baht payables.

[0001193125-17-033383:mdna:58]
The RMB assets represent cash and cash equivalents,
accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of December 30, 2016 and June 24, 2016, we did not have any derivative
contracts denominated in RMB.

[0001193125-17-033383:mdna:59]
The GBP assets primarily represent cash, accounts receivable and fixed assets. The GBP liabilities
primarily represent short-term loans, trade accounts payable and other payables. As of December 30, 2016, we did not have any derivative contracts denominated in GBP.

[0001193125-17-033383:mdna:60]
For the six months ended December 30, 2016 and December 25, 2015, we recorded an unrealized loss of $0.001 million and $6.2 million,
respectively, for the changes in fair value of derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-17-033383:mdna:61]
[same as prior period, unchanged from 0001193125-16-764312:mdna:60]

[0001193125-17-033383:mdna:62]
[same as prior period, unchanged from 0001193125-16-764312:mdna:61]

[0001193125-17-033383:mdna:63]
[same as prior period, unchanged from 0001193125-16-764312:mdna:62]

[0001193125-17-033383:mdna:64]
[same as prior period, unchanged from 0001193125-16-764312:mdna:63]

[0001193125-17-033383:mdna:65]
[same as prior period, unchanged from 0001193125-16-764312:mdna:64]

[0001193125-17-033383:mdna:66]
[same as prior period, unchanged from 0001193125-16-764312:mdna:65]

[0001193125-17-033383:mdna:67]
[same as prior period, unchanged from 0001193125-16-764312:mdna:66]

[0001193125-17-033383:mdna:68]
[same as prior period, unchanged from 0001193125-16-764312:mdna:67]

[0001193125-17-033383:mdna:69]
On January 5, 2007, SAFE promulgated the Detailed Rules for Implementing the Measures for the Administration on Individual Foreign
Exchange, or the Implementation Rules. Under the Implementation Rules, PRC citizens who are granted share options by an overseas publicly-listed company are required, through a PRC agent or PRC subsidiary of such overseas publicly-listed company, to
register with SAFE and complete certain other procedures.

[0001193125-17-033383:mdna:70]
In addition, the General Administration of Taxation has issued circulars
concerning employee share options. Under these circulars, our employees working in the PRC who exercise share options will be subject to PRC individual income tax. Our PRC subsidiary has obligations to file documents related to employee share
options with relevant tax authorities and withhold individual income taxes of those employees who exercise their share options.

[0001193125-17-033383:mdna:71]
Furthermore, our transfer of funds to our subsidiaries in Thailand and the PRC are each subject to approval by governmental authorities in
case of an increase in registered capital, or subject to registration with governmental authorities in case of a shareholder loan. These limitations on the flow of funds between our subsidiaries and us could restrict our ability to act in response
to changing market conditions.

[0001193125-17-033383:mdna:72]
[same as prior period, unchanged from 0001193125-16-764312:mdna:71]

[0001193125-17-033383:mdna:73]
Our effective tax rate is a function of the mix of tax rates in the various jurisdictions in which we do business. We are domiciled in the
Cayman Islands. Under the current laws of the Cayman Islands, we are not subject to tax in the Cayman Islands on income or capital gains. We have received this undertaking for a 20-year period ending August 24, 2019, and after the expiration
date, we may request a renewal with the office of the Clerk of the Cabinet for another twenty years.

[0001193125-17-033383:mdna:74]
Throughout the period of our
operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption is currently available to us
through June 2020 on income generated from projects to manufacture certain products at our Pinehurst campus. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and
our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted. In March 2016, the Thailand Revenue Department announced a permanent
decrease of corporate income tax rates to 20% for tax periods beginning on or after January 1, 2016. As a result, corporate income tax rates for our Thai subsidiary remain at 20% from fiscal year 2017 onward.

[0001193125-17-033383:mdna:75]
[same as prior period, unchanged from 0001193125-16-764312:mdna:74]

[0001193125-17-033383:mdna:76]
We prepare our unaudited condensed consolidated financial statements in conformity with U.S. GAAP, which requires us to make estimates and
assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent liabilities on the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the financial
reporting period. We continually evaluate these estimates and assumptions based on the most recently available information, our own historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the
results form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Because the use of estimates is an integral component of the financial reporting process, actual
results could differ from those estimates. Some of our accounting policies require higher degrees of judgment than others in their application. We consider the policies discussed below to be critical to an understanding of our unaudited condensed
consolidated financial statements, as their application places the most significant demands on our management’s judgment.

[0001193125-17-033383:mdna:77]
Our
critical accounting policies are disclosed in our Annual Report on Form 10-K for the fiscal year ended June 24, 2016. The adoption of new accounting policies and the accounting standards are disclosed in Note 2 – Accounting policies to the
unaudited condensed consolidated financial statements.

[0001193125-17-033383:mdna:78]
[same as prior period, unchanged from 0001193125-16-764312:mdna:77]

[0001193125-17-033383:mdna:79]
[same as prior period, unchanged from 0001193125-16-764312:mdna:78]

[0001193125-17-033383:mdna:80]
| (amount in thousands) |  | Three Months Ended |  |  | Six Months Ended |  |
|  | December 30,2016 |  |  | December 25,2015 |  |  | December 30,2016 |  |  | December 25,2015 |  |
| Revenues |  | $ | 351,156 |  |  | $ | 233,038 |  |  | $ | 683,199 |  |  | $ | 449,471 |  |
| Cost of revenues |  |  | (308,110 | ) |  |  | (204,545 | ) |  |  | (600,545 | ) |  |  | (394,967 | ) |
| Gross profit |  |  | 43,046 |  |  |  | 28,493 |  |  |  | 82,654 |  |  |  | 54,504 |  |
| Selling, general and administrative expenses |  |  | (17,651 | ) |  |  | (13,715 | ) |  |  | (33,483 | ) |  |  | (25,615 | ) |
| Other expense related to flooding |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (864 | ) |
| Operating income |  |  | 25,395 |  |  |  | 14,778 |  |  |  | 49,171 |  |  |  | 28,025 |  |
| Interest income |  |  | 320 |  |  |  | 455 |  |  |  | 757 |  |  |  | 897 |  |
| Interest expense |  |  | (555 | ) |  |  | (419 | ) |  |  | (1,876 | ) |  |  | (821 | ) |
| Foreign exchange gain (loss), net |  |  | 1,945 |  |  |  | 6,166 |  |  |  | 3,602 |  |  |  | (4,326 | ) |
| Other income |  |  | 147 |  |  |  | 106 |  |  |  | 289 |  |  |  | 209 |  |
| Income before income taxes |  |  | 27,252 |  |  |  | 21,086 |  |  |  | 51,943 |  |  |  | 23,984 |  |
| Income tax expense |  |  | (1,960 | ) |  |  | (1,283 | ) |  |  | (3,885 | ) |  |  | (2,578 | ) |
| Net income |  |  | 25,292 |  |  |  | 19,803 |  |  |  | 48,058 |  |  |  | 21,406 |  |
| Other comprehensive loss, net of tax |  |  | (2,256 | ) |  |  | (310 | ) |  |  | (1,860 | ) |  |  | (223 | ) |
| Net comprehensive income |  | $ | 23,036 |  |  | $ | 19,493 |  |  | $ | 46,198 |  |  | $ | 21,183 |  |

[0001193125-17-033383:mdna:81]
38

[0001193125-17-033383:mdna:82]
[same as prior period, unchanged from 0001193125-16-764312:mdna:80]

[0001193125-17-033383:mdna:83]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 30,2016 |  |  | December 25,2015 |  |  | December 30,2016 |  |  | December 25,2015 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (87.7 | ) |  |  | (87.8 | ) |  |  | (87.9 | ) |  |  | (87.9 | ) |
| Gross profit |  |  | 12.3 |  |  |  | 12.2 |  |  |  | 12.1 |  |  |  | 12.1 |  |
| Selling, general and administrative expenses |  |  | (5.0 | ) |  |  | (5.9 | ) |  |  | (4.9 | ) |  |  | (5.7 | ) |
| Other expense related to flooding |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.2 | ) |
| Operating income |  |  | 7.3 |  |  |  | 6.3 |  |  |  | 7.2 |  |  |  | 6.2 |  |
| Interest income |  |  | 0.1 |  |  |  | 0.2 |  |  |  | 0.1 |  |  |  | 0.2 |  |
| Interest expense |  |  | (0.2 | ) |  |  | (0.2 | ) |  |  | (0.3 | ) |  |  | (0.2 | ) |
| Foreign exchange gain (loss), net |  |  | 0.6 |  |  |  | 2.7 |  |  |  | 0.5 |  |  |  | (1.0 | ) |
| Other income |  |  | 0.0 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Income before income taxes |  |  | 7.8 |  |  |  | 9.1 |  |  |  | 7.6 |  |  |  | 5.3 |  |
| Income tax expense |  |  | (0.6 | ) |  |  | (0.6 | ) |  |  | (0.6 | ) |  |  | (0.5 | ) |
| Net income |  |  | 7.2 |  |  |  | 8.5 |  |  |  | 7.0 |  |  |  | 4.8 |  |
| Other comprehensive loss, net of tax |  |  | (0.6 | ) |  |  | (0.1 | ) |  |  | (0.3 | ) |  |  | (0.1 | ) |
| Net comprehensive income |  |  | 6.6 | % |  |  | 8.4 | % |  |  | 6.7 | % |  |  | 4.7 | % |

[0001193125-17-033383:mdna:84]
[same as prior period, unchanged from 0001193125-16-764312:mdna:82]

[0001193125-17-033383:mdna:85]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands) |  | December 30,2016 |  |  | December 25,2015 |  |  | December 30,2016 |  |  | December 25,2015 |  |
| Optical communications |  | $ | 274,244 |  |  | $ | 168,694 |  |  | $ | 531,051 |  |  | $ | 323,456 |  |
| Lasers, sensors and other |  |  | 76,912 |  |  |  | 64,344 |  |  |  | 152,148 |  |  |  | 126,015 |  |
| Total |  | $ | 351,156 |  |  | $ | 233,038 |  |  | $ | 683,199 |  |  | $ | 449,471 |  |

[0001193125-17-033383:mdna:86]
[same as prior period, unchanged from 0001193125-16-764312:mdna:84]

[0001193125-17-033383:mdna:87]
Comparison of Three and Six Months Ended December 30, 2016 with Three and Six Months
Ended December 25, 2015

[0001193125-17-033383:mdna:88]
[same as prior period, unchanged from 0001193125-16-764312:mdna:86]

[0001193125-17-033383:mdna:89]
Our total revenues increased by $118.1 million, or 50.7%, to $351.2 million for the three months ended December 30, 2016, compared with
$233.0 million for the three months ended December 25, 2015. This increase was primarily due to an increase in our customers’ demand for both optical and non-optical communications manufacturing services during the three months ended
December 30, 2016 and $6.2 million of revenue from companies we acquired in September 2016. Revenues from optical communications products represented 78.1% of our total revenues for the three months ended December 30, 2016, compared to
72.4% for the three months ended December 25, 2015.

[0001193125-17-033383:mdna:90]
Our total revenues increased by $233.7 million, or 52.0%, to $683.2 million for
the six months ended December 30, 2016, compared with $449.5 million for the six months ended December 25, 2015. This increase was primarily due to (1) an increase in our customers’ demand for both optical and non-optical
communications manufacturing services during the six months ended December 30, 2016, (2) the positive impact from an additional week of revenue during the six months ended December 30, 2016 and (3) $7.0 million of revenue from
companies we acquired in September 2016. Revenues from optical communications products represented 77.7% of our total revenues for the six months ended December 30, 2016, compared to 72.0% for the six months ended December 25, 2015.

[0001193125-17-033383:mdna:91]
[same as prior period, unchanged from 0001193125-16-764312:mdna:88]

[0001193125-17-033383:mdna:92]
Our cost of revenues increased by $103.6 million, or 50.6%, to $308.1 million, or 87.7% of total revenues, for the three months ended
December 30, 2016, compared with $204.5 million, or 87.8% of total revenues, for the three months ended December 25, 2015. The increase in cost of revenues on an absolute dollars basis was primarily due to a proportional increase in sales
volume. The increase in cost of revenues also included an increase of $1.0 million in share-based compensation expenses, primarily due to the grant of a higher number of restricted share units.

[0001193125-17-033383:mdna:93]
Our cost of revenues increased by $205.6 million, or 52.0%, to $600.5 million, or 87.9% of total revenues, for the six months ended
December 30, 2016, compared with $395.0 million, or 87.9% of total revenues, for the six months ended December 25, 2015. The increase in cost of revenues on an absolute dollars basis was primarily due to a proportional increase in sales
volume. The increase in cost of revenues also included an increase of $1.5 million in share-based compensation expenses, primarily due to the grant of a higher number of restricted share units.

[0001193125-17-033383:mdna:94]
[same as prior period, unchanged from 0001193125-16-764312:mdna:90]

[0001193125-17-033383:mdna:95]
Our gross
profit increased by $14.6 million, or 51.1%, to $43.0 million, or 12.3% of total revenues, for the three months ended December 30, 2016, compared with $28.5 million, or 12.2% of total revenues, for the three months ended December 25, 2015.
Our gross profit increased by $28.2 million, or 51.7%, to $82.7 million, or 12.1% of total revenues, for the six months ended December 30, 2016, compared with $54.5 million, or 12.1% of total revenues, for the six months ended December 25,
2015.

[0001193125-17-033383:mdna:96]
[same as prior period, unchanged from 0001193125-16-764312:mdna:92]

[0001193125-17-033383:mdna:97]
Our SG&A expenses increased by $3.9 million, or 28.7%, to $17.7 million, or 5.0% of total revenues, for the three months ended
December 30, 2016, compared with $13.7 million, or 5.9% of total revenues, for the three months ended December 25, 2015. Our SG&A expenses increased in absolute dollars primarily due to an increase of $4.5 million in share-based
compensation expenses, partially due to the recognition of $2.8 million related to accelerated vesting of an executive equity award during the three months ended December 30, 2016, and an increase of $0.9 million in expenses related to our
subsidiary in the United Kingdom, offset by a decrease of $1.3 million in expenses related to our facility in the United States.

[0001193125-17-033383:mdna:98]
Our
SG&A expenses increased by $7.9 million, or 30.7%, to $33.5 million, or 4.9% of total revenues, for the six months ended December 30, 2016, compared with $25.6 million, or 5.7% of total revenues, for the six months ended December 25,
2015. Our SG&A expenses increased in absolute dollars primarily due to an increase of $1.5 million in expenses relating to merger and acquisition activities and an increase in share-based compensation expenses of $7.0 million, partially due to
the recognition of $2.8 million related to accelerated vesting of an executive equity award during the six months ended December 30, 2016, offset by a decrease of $1.5 million in expenses related to our facility in the United States.

[0001193125-17-033383:mdna:99]
[same as prior period, unchanged from 0001193125-16-764312:mdna:94]

[0001193125-17-033383:mdna:100]
In the three and six months ended December 30, 2016 and the three months ended December 25, 2015, we did not have any expenses
related to flooding. In the six months ended December 25, 2015, we recognized other expense related to flooding of $0.9 million, which mainly consisted of $0.6 million of repaired cost of equipment and $0.2 million of inventory losses.

[0001193125-17-033383:mdna:101]
[same as prior period, unchanged from 0001193125-16-764312:mdna:96]

[0001193125-17-033383:mdna:102]
Our
operating income increased by $10.6 million to $25.4 million, or 7.3% of total revenues, for the three months ended December 30, 2016, compared with $14.8 million, or 6.3% of total revenues, for the three months ended December 25, 2015.

[0001193125-17-033383:mdna:103]
Our operating income increased by $21.1 million to $49.2 million, or 7.2% of total revenues, for the six months ended December 30,
2016, compared with $28.0 million, or 6.2% of total revenues, for the six months ended December 25, 2015.

[0001193125-17-033383:mdna:104]
[same as prior period, unchanged from 0001193125-16-764312:mdna:98]

[0001193125-17-033383:mdna:105]
Our interest income decreased by $0.1 million to $0.3 million, or 0.1% of total revenues, for the three months ended December 30, 2016,
compared with $0.4 million, or 0.2% of total revenues, for the three months ended December 25, 2015. Our interest income decreased by $0.1 million to $0.8 million, or 0.1% of total revenues, for the six months ended December 30, 2016,
compared with $0.9 million, or 0.2% of total revenues, for the six months ended December 25, 2015. The decrease was primarily due to a decrease in the average of our outstanding cash balance.

[0001193125-17-033383:mdna:106]
[same as prior period, unchanged from 0001193125-16-764312:mdna:100]

[0001193125-17-033383:mdna:107]
Our
interest expense increased by $0.1 million to $0.5 million for the three months ended December 30, 2016, compared with $0.4 million for the three months ended December 25, 2015. Our interest expense increased by $1.1 million to $1.9
million for the six months ended December 30, 2016, compared with $0.8 million for the six months ended December 25, 2015. The increase was primarily due to an increase in the average balance of our outstanding bank borrowings.

[0001193125-17-033383:mdna:108]
[same as prior period, unchanged from 0001193125-16-764312:mdna:103]

[0001193125-17-033383:mdna:109]
Our foreign exchange gain, net, decreased by $4.2 million to $1.9 million, or 0.6% of total revenues, for the three months ended
December 30, 2016, compared with foreign exchange gain, net, of $6.2 million, or 2.7% of total revenues, for the three months ended December 25, 2015. The decrease was due to changes in the fair value of forward contracts as of
December 30, 2016 that were not designated as hedging instruments.

[0001193125-17-033383:mdna:110]
Our foreign exchange (loss), net, increased by $7.9 million to
foreign exchange gain, net, of $3.6 million, or 0.5% of total revenues, for the six months ended December 30, 2016, compared with foreign exchange (loss), net, of $(4.3) million, or (1.0)% of total revenues, for the six months ended
December 25, 2015. The increase was due to changes in the fair value of forward contracts as of December 30, 2016 that were not designated as hedging instruments.

[0001193125-17-033383:mdna:111]
[same as prior period, unchanged from 0001193125-16-764312:mdna:105]

[0001193125-17-033383:mdna:112]
We recorded income before income taxes of $27.3 million and $51.9 million for the three and six months ended December 30, 2016,
respectively, compared with $21.1 million and $24.0 million for the three and six months ended December 25, 2015, respectively.

[0001193125-17-033383:mdna:113]
[same as prior period, unchanged from 0001193125-16-764312:mdna:107]

[0001193125-17-033383:mdna:114]
Our
provision for income tax reflects an effective tax rate of 6.8% for both the three months ended December 30, 2016 and December 25, 2015. Even though our taxable income and income tax expenses for the three months ended December 30,
2016 increased, they increased proportionately on an absolute dollars basis, compared with the three months ended December 25, 2015 and did not impact the effective tax rate.

[0001193125-17-033383:mdna:115]
Our provision for income tax reflects an effective tax rate of 6.7% for both the six months ended December 30, 2016, and
December 25, 2015. Even though our taxable income and income tax expenses for the six months ended December 30, 2016 increased, they increased proportionately on an absolute dollars basis, compared with the six months ended
December 25, 2015 and did not impact the effective tax rate.

[0001193125-17-033383:mdna:116]
[same as prior period, unchanged from 0001193125-16-764312:mdna:109]

[0001193125-17-033383:mdna:117]
We recorded net income of $25.3 million, or 7.2% of total revenues, for the three months ended December 30, 2016, compared with $19.8
million, or 8.5% of total revenues, for the three months ended December 25, 2015.

[0001193125-17-033383:mdna:118]
We recorded net income of $48.1 million, or 7.0%
of total revenues, for the six months ended December 30, 2016, compared with $21.4 million, or 4.8% of total revenues, for the six months ended December 25, 2015.

[0001193125-17-033383:mdna:119]
Other comprehensive loss.

[0001193125-17-033383:mdna:120]
We recorded other comprehensive loss of $2.3 million, or 0.6% of total revenues, for the three months ended December 30, 2016, compared
with other comprehensive loss of $0.3 million, or 0.1% of total revenues, for the three months ended December 25, 2015. The increase was primarily due to the foreign currency translation adjustment of $1.9 million in connection with the
operations of Exception EMS.

[0001193125-17-033383:mdna:121]
We recorded other comprehensive loss of $1.9 million, or 0.3% of total revenues, for the six months ended
December 30, 2016, compared with other comprehensive loss of $0.2 million, or 0.1% of total revenues, for the six months ended December 25, 2015. The increase was primarily due to the foreign currency translation adjustment of $1.2 million
in connection with the operations of Exception EMS.

[0001193125-17-033383:mdna:122]
Liquidity and Capital Resources

[0001193125-17-033383:mdna:123]
[same as prior period, unchanged from 0001193125-16-764312:mdna:114]

[0001193125-17-033383:mdna:124]
We
primarily finance our operations through cash flow from operations. As of December 30, 2016 and December 25, 2015, we had cash, cash equivalents, and marketable securities of $256.1 million and $266.6 million, respectively, and outstanding
debt of $68.1 million and $55.5 million, respectively.

[0001193125-17-033383:mdna:125]
Our cash and cash equivalents, which primarily consist of cash on hand, demand
deposits, and liquid investments with maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents for the three and six months ended
December 30, 2016 was 0.5% and 0.4%, respectively, and for the three and six months ended December 25, 2015 was 1.2% and 0.6%, respectively.

[0001193125-17-033383:mdna:126]
Our cash investments are made in accordance with an investment policy approved by the Audit Committee of our Board of Directors. In general,
our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed income securities are primarily classified as available-for-sale
and are recorded at fair value. The cost of securities sold is based on the specific identification method. Unrealized gains and losses on these securities are recorded as other comprehensive income (loss) and are reported as a separate component of
shareholders’ equity.

[0001193125-17-033383:mdna:127]
During the six months ended December 30, 2016, we borrowed a revolving loan of $13.5 million and repaid a
term loan of $6.8 million under our Facility Agreement; as a result, as of December 30, 2016, we had a long-term borrowing of $43.2 million and short-term borrowing of $20.0 million under our Facility Agreement. We anticipate that our
internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held investments in short-term marketable securities of $170.5 million as of
December 30, 2016.

[0001193125-17-033383:mdna:128]
We believe that our current cash and cash equivalents, marketable securities, cash flow from operations, and
funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in
Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001193125-17-033383:mdna:129]
In December 2015, we began construction of a new manufacturing facility
at our Chonburi campus, which we substantially completed in the first quarter of fiscal year 2017. We continued renovating the facilities during the second quarter of fiscal year 2017 and expect to begin operations at this new facility in the third
quarter of fiscal year 2017. We believe that our current manufacturing capacity is sufficient to meet our anticipated production requirements for at least the next few quarters. We maintain a long-term loan associated with construction of production
facilities at our Pinehurst campus in Thailand that will come due within the next 12 months.

[0001193125-17-033383:mdna:130]
[same as prior period, unchanged from 0001193125-16-764312:mdna:121]

[0001193125-17-033383:mdna:131]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 30,2016 |  |  | December 25,2015 |  |
| Net cash provided by operating activities |  | $ | 19,752 |  |  | $ | 23,704 |  |
| Net cash used in investing activities |  | $ | (84,102 | ) |  | $ | (19,648 | ) |
| Net cash provided by financing activities |  | $ | 10,692 |  |  | $ | 14,955 |  |
| Net (decrease) increase in cash, cash equivalents and restricted cash |  | $ | (53,658 | ) |  | $ | 19,011 |  |

[0001193125-17-033383:mdna:132]
[same as prior period, unchanged from 0001193125-16-764312:mdna:123]

[0001193125-17-033383:mdna:133]
Net cash provided by operating activities decreased by $4.0 million, or 16.7%, to $19.8 million for the six months ended December 30,
2016, compared with net cash provided by operating activities of $23.7 million for the six months ended December 25, 2015. This decrease was due to a number of factors, including increases in accounts receivable of $28.3 million and inventory
of $19.3 million due to higher sales and customer demand, offset by an increase in net income of $26.7 million, and a decrease in payments to vendors of $11.4 million, as compared with the six months ended December 25, 2015.

[0001193125-17-033383:mdna:134]
[same as prior period, unchanged from 0001193125-16-764312:mdna:125]

[0001193125-17-033383:mdna:135]
Net
cash used in investing activities increased by $64.5 million, or 328.0%, to $84.1 million for the six months ended December 30, 2016, compared with net cash used in investing activities of $19.6 million for the six months ended
December 25, 2015. This increase was primarily due to an increase of $18.0 million in the purchase of property, plant and equipment primarily for our new facility in Chonburi, Thailand, a net increase of $36.5 million in marketable securities
and the net payment of $9.9 million in connection with the acquisition of Exception EMS.

[0001193125-17-033383:mdna:136]
[same as prior period, unchanged from 0001193125-16-764312:mdna:127]

[0001193125-17-033383:mdna:137]
Net cash provided by financing activities decreased by $4.3 million, or 28.5%, to $10.7 million for the six months ended December 30,
2016, compared with net cash provided by financing activities of $15.0 million for the six months ended December 25, 2015. This decrease was primarily due to an increase of $6.8 million in repayment of long-term loans from banks, offset by an
increase of $3.8 million in proceeds from the issuance of ordinary shares under our employee share option plans.

[0001193125-17-033383:mdna:138]
Off-Balance Sheet Commitments and
Arrangements

[0001193125-17-033383:mdna:139]
We have not entered into any financial guarantees or other commitments to guarantee the payment obligations of any third
parties. In addition, we have not entered into any derivative contracts that are not reflected in our unaudited condensed consolidated financial statements. Furthermore, we do not have any retained or contingent interest in assets transferred to an
unconsolidated entity that serves as credit, liquidity or market risk support to such entity. We also do not have any variable interest in any unconsolidated entity that provides financing, liquidity, market risk or credit support to us or engages
in leasing, hedging or research and development services with us.

[0001193125-17-033383:mdna:140]
[same as prior period, unchanged from 0001193125-16-764312:mdna:131]

[0001193125-17-033383:mdna:141]
[same as prior period, unchanged from 0001193125-16-764312:mdna:132]
