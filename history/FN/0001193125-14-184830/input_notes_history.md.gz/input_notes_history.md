# FN note change history — 0001193125-14-034881 → 0001193125-14-184830


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-05-06):
[0001193125-14-184830:note_history:1]
As of
 March 28, 2014 and June 28, 2013, there were outstanding
 bank guarantees given by banks on behalf of Fabrinet Thailand for
 electricity usage and other normal business amounting to $322 and
 $336, respectively.
  (was, 2014-02-04, similarity 0.9724):
[0001193125-14-034881:note_history:1]
As of
 December 27, 2013 and June 28, 2013, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $319 and $336, respectively.

- changed (2014-05-06):
[0001193125-14-184830:note_history:2]
The Company
 leases a portion of certain land and buildings for its facilities
 in China and New Jersey, under operating lease arrangements that
 expire in various calendar years through 2020. Rental expense under
 these operating leases amounted to $667 and $585 for the nine
 months ended March 28, 2014 and March 29, 2013,
 respectively.
  (was, 2014-02-04, similarity 0.8756):
[0001193125-14-034881:note_history:2]
The Company
 leases a portion of certain land and buildings for its facilities
 in China and New Jersey, under operating lease arrangements that
 expire in various calendar years through 2020. Rental expense under
 these operating leases amounted to $420 and $390 for the six months
 ended December 27, 2013 and December 28, 2012,
 respectively.

- changed (2014-05-06):
[0001193125-14-184830:note_history:3]
As of
 March 28, 2014, the future minimum lease payments due under
 non-cancelable leases were as follows at the end of each fiscal
 year below:
  (was, 2014-02-04, similarity 0.967):
[0001193125-14-034881:note_history:3]
As of
 December 27, 2013, the future minimum lease payments due under
 non-cancelable leases were as follows at the end of each fiscal
 year below:

- changed (2014-05-06):
[0001193125-14-184830:note_history:4]
As of
 March 28, 2014, there were no outstanding capital expenditure
 commitments.
  (was, 2014-02-04, similarity 0.9404):
[0001193125-14-034881:note_history:4]
As of
 December 27, 2013, there were no outstanding capital
 expenditure commitments.

- added (2014-05-06):
[0001193125-14-184830:note_history:5]
In the first
 week of October 2013, the Company authorized a customer to return a
 number of units of its product manufactured at the Company’s
 Pinehurst facility, due to functional failure. After investigation,
 the Company found that the affected products were produced during
 the first quarter of fiscal 2014. On March 28, 2014, the
 Company entered into a settlement agreement with the customer for
 the losses as a result of the product failure. The settled amount
 was $487 and recorded in the nine months ended March 28,
 2014.

- removed (2014-05-06):
[0001193125-14-034881:note_history:6]
In the first
 week of October 2013, the Company authorized a customer to return a
 number of units of its product manufactured at the Company’s
 Pinehurst facility, due to functional failure. After investigation,
 the Company found that the affected products were produced during
 the first quarter of fiscal 2014. While this may cause the Company
 to incur certain costs and expenses, the Company is still working
 with the customer to determine the extent and impact of the product
 failures. Accordingly, the Company cannot accurately estimate the
 costs and expenses that it may incur as a result of the product
 failures.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-05-06):
[0001193125-14-184830:note_history:7]
The condensed
 consolidated financial statements of Fabrinet included herein have
 been prepared on a basis consistent with the June 28, 2013
 audited consolidated financial statements and include all material
 adjustments, consisting of normal recurring adjustments, necessary
 to fairly present the information set forth therein. These
 condensed consolidated financial statements should be read in
 conjunction with the June 28, 2013 audited consolidated
 financial statements and notes thereto. The year-end condensed
 balance sheet data was derived from audited financial statements
 but does not include all disclosures required by accounting
 principles generally accepted in the United States of America
 (“U.S. GAAP”).
  (was, 2014-02-04, similarity 0.8992):
[0001193125-14-034881:note_history:7]
The condensed
 consolidated financial statements of Fabrinet included herein have
 been prepared on a basis consistent with the June 28, 2013
 audited consolidated financial statements and include all material
 adjustments, consisting of normal recurring adjustments, necessary
 to fairly present the information set forth therein. These
 condensed consolidated financial statements should be read in
 conjunction with the June 28, 2013 audited consolidated
 financial statements and notes thereto. The year-end condensed
 balance sheet data was derived from audited financial statements
 but does not include all disclosures required by accounting
 principles generally accepted in the United States of America
 (“U.S. GAAP”). Fabrinet’s results of operations
 for the three and six months ended December 27, 2013 and
 December 28, 2012 are not necessarily indicative of future
 operating results.

- changed (2014-05-06):
[0001193125-14-184830:note_history:8]
The Company
 utilizes a 52-53 week fiscal year ending on the Friday in June
 closest to June 30. The three months ended March 28, 2014
 and March 29, 2013 each consisted of 13 weeks. The nine months
 ended March 28, 2014 and March 29, 2013 each consisted of
 39 weeks. Fiscal year 2014 will be comprised of 52 weeks and will
 end on June 27, 2014.
  (was, 2014-02-04, similarity 0.8019):
[0001193125-14-034881:note_history:8]
The Company
 utilizes a 52-53 week fiscal year ending on the Friday in June
 closest to June 30. The three months ended December 27,
 2013 and December 28, 2012 each consisted of 13 weeks. The six
 months ended December 27, 2013 and December 28, 2012 each
 consisted of 26 weeks. Fiscal year 2014 will be comprised of 52
 weeks and will end on June 27, 2014.

- changed (2014-05-06):
[0001193125-14-184830:note_history:9]
As of
 March 28, 2014, the Company’s cash and cash equivalents
 were held in deposits and highly liquid investment products with
 maturities of three months or less with banks and other financial
 institutions having credit ratings of A minus or above. The Company
 had two customers that each contributed to 10% or more of its total
 accounts receivable as of March 28, 2014 and June 28,
 2013, respectively.
  (was, 2014-02-04, similarity 0.9664):
[0001193125-14-034881:note_history:9]
As of
 December 27, 2013, the Company’s cash and cash
 equivalents were held in deposits and highly liquid investment
 products with maturities of three months or less with banks and
 other financial institutions having credit ratings of A minus or
 above. The Company had two customers that each contributed to 10%
 or more of its total accounts receivable as of December 27,
 2013 and June 28, 2013, respectively.


## fn:LongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-06):
[0001193125-14-184830:note_history:10]
The movements of
 long-term loans were as follows for the nine months ended
 March 28, 2014 and March 29, 2013:
  (was, 2014-02-04, similarity 0.8867):
[0001193125-14-034881:note_history:10]
The movements
 of long-term loans were as follows for the six months ended
 December 27, 2013 and December 28, 2012:

- changed (2014-05-06):
[0001193125-14-184830:note_history:11]
|  |  | Nine Months Ended |  |
|  |  | March 28, 2014 |  |  | March 29, 2013 |  |
| Opening net book amount |  | $ | 28,911 |  |  | $ | 38,579 |  |
| Repayment during the period |  |  | (7,251 | ) |  |  | (7,251 | ) |
| Closing net book amount |  | $ | 21,660 |  |  | $ | 31,328 |  |
  (was, 2014-02-04, similarity 0.8879):
[0001193125-14-034881:note_history:11]
|  |  | Six Months Ended |  |
|  |  | December 27, 2013 |  |  | December 28, 2012 |  |
| Opening net book amount |  | $ | 28,911 |  |  | $ | 38,579 |  |
| Repayment during the period |  |  | (4,834 | ) |  |  | (4,834 | ) |
| Closing net book amount |  | $ | 24,077 |  |  | $ | 33,745 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-06):
[0001193125-14-184830:note_history:12]
|  |  | March 28, 2014 |  |  | June 28, 2013 |  |
| Long-term loans from bank |  | $ | 21,660 |  |  | $ | 28,911 |  |
| Total borrowings |  | $ | 21,660 |  |  | $ | 28,911 |  |
| Long-term loans from bank consisted of: |  |  |  |  |  |  |  |  |
| Current portion |  | $ | 9,660 |  |  | $ | 9,668 |  |
| Non-current portion |  | $ | 12,000 |  |  | $ | 19,243 |  |
  (was, 2014-02-04, similarity 0.9104):
[0001193125-14-034881:note_history:12]
|  |  | December 27, 2013 |  |  | June 28, 2013 |  |
| Long-term loans from bank |  | $ | 24,077 |  |  | $ | 28,911 |  |
| Total borrowings |  | $ | 24,077 |  |  | $ | 28,911 |  |
| Long-term loans from bank consisted of: |  |  |  |  |  |  |  |  |
| Current portion |  | $ | 9,668 |  |  | $ | 9,668 |  |
| Non-current portion |  |  | 14,409 |  |  |  | 19,243 |  |

- changed (2014-05-06):
[0001193125-14-184830:note_history:13]
As of
 March 28, 2014 and June 28, 2013, the Company had
 outstanding borrowings under long-term loan agreements with banks
 totaling $21,660 and $28,911, respectively, which consisted
 of:
  (was, 2014-02-04, similarity 0.9726):
[0001193125-14-034881:note_history:13]
As of
 December 27, 2013 and June 28, 2013, the Company had
 outstanding borrowings under long-term loan agreements with banks
 totaling $24,077 and $28,911, respectively, which consisted
 of:

- added (2014-05-06):
[0001193125-14-184830:note_history:14]
| Contract No. |  | Amount |  |  | Interest Rate (%) |  | Conditions |  | Repayment Term |
|  | March 28, 2014 |  |  | June 28, 2013 |  |  |  |  |
| 1 |  | $ | 18,000 |  |  | $ | 22,500 |  |  | LIBOR(1) + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | June 2012 to March 2017 |
| 2 |  |  | 3,660 |  |  |  | 6,411 |  |  | SIBOR(2) + 1.5% per annum |  | Repayable in quarterly installments within 8 years |  | May 2009 to February 2015 |
| Total |  | $ | 21,660 |  |  | $ | 28,911 |  |  |  |  |  |  |  |

- added (2014-05-06):
[0001193125-14-184830:note_history:15]
| (1) | LIBOR is London Interbank Offered Rate. |

- added (2014-05-06):
[0001193125-14-184830:note_history:16]
| (2) | SIBOR is Singapore Interbank Offered Rate. |

- changed (2014-05-06):
[0001193125-14-184830:note_history:17]
Certain of the
 long-term loans are secured by certain property, plant and
 equipment. The carrying amount of assets secured and pledged as
 collateral was $21,102 and $21,815 as of March 28, 2014 and
 June 28, 2013, respectively. The carrying amounts of
 borrowings approximate their fair value.
  (was, 2014-02-04, similarity 0.9761):
[0001193125-14-034881:note_history:17]
Certain of the
 long-term loans are secured by certain property, plant and
 equipment. The carrying amount of assets secured and pledged as
 collateral was $21,340 and $21,815 as of December 27, 2013 and
 June 28, 2013, respectively. The carrying amounts of
 borrowings approximate their fair value.

- changed (2014-05-06):
[0001193125-14-184830:note_history:18]
The long-term
 loans prescribe maximum ratios of debt to equity and minimum levels
 of debt service coverage ratios. As of March 28, 2014 and
 June 28, 2013, the Company was in compliance with its
 long-term loan agreements. In addition to financial ratios, certain
 of the Company’s packing credits and long-term loans include
 customary events of default.
  (was, 2014-02-04, similarity 0.981):
[0001193125-14-034881:note_history:18]
The long-term
 loans prescribe maximum ratios of debt to equity and minimum levels
 of debt service coverage ratios. As of December 27, 2013 and
 June 28, 2013, the Company was in compliance with its
 long-term loan agreements. In addition to financial ratios, certain
 of the Company’s packing credits and long-term loans include
 customary events of default.

- changed (2014-05-06):
[0001193125-14-184830:note_history:19]
The movements
 of long-term loans were as follows for the nine months ended
 March 28, 2014 and March 29, 2013:
  (was, 2014-02-04, similarity 0.8867):
[0001193125-14-034881:note_history:19]
The movements
 of long-term loans were as follows for the six months ended
 December 27, 2013 and December 28, 2012:

- changed (2014-05-06):
[0001193125-14-184830:note_history:20]
|  |  | Nine Months Ended |  |
|  |  | March 28, 2014 |  |  | March 29, 2013 |  |
| Opening net book amount |  | $ | 28,911 |  |  | $ | 38,579 |  |
| Repayment during the period |  |  | (7,251 | ) |  |  | (7,251 | ) |
| Closing net book amount |  | $ | 21,660 |  |  | $ | 31,328 |  |
  (was, 2014-02-04, similarity 0.8879):
[0001193125-14-034881:note_history:20]
|  |  | Six Months Ended |  |
|  |  | December 27, 2013 |  |  | December 28, 2012 |  |
| Opening net book amount |  | $ | 28,911 |  |  | $ | 38,579 |  |
| Repayment during the period |  |  | (4,834 | ) |  |  | (4,834 | ) |
| Closing net book amount |  | $ | 24,077 |  |  | $ | 33,745 |  |

- added (2014-05-06):
[0001193125-14-184830:note_history:21]
Subsequent to
 the quarter-end:

- added (2014-05-06):
[0001193125-14-184830:note_history:22]
|  | (a) | On April 25, 2014, a subsidiary entered into an amendment to the long-term loan contract No.1. Under the amendment of the contract, the long-term loan is secured by certain property, plant and equipment. The carrying amount of assets secured and pledged as collateral as of March 28, 2014 was $52,894. The subsidiary is also required to comply with the maximum ratios of debt to equity and minimum levels of debt service coverage ratios and Fabrinet must maintain effective shareholding ratio. |

- added (2014-05-06):
[0001193125-14-184830:note_history:23]
|  | (b) | On April 28, 2014, the subsidiary made an early repayment of long-term loan contract No.2 which included principal, interest expense and an early repayment fee of $3,707. As of March 28, 2014, this loan was classified in long-term loans from bank, current portion. |

- changed (2014-05-06):
[0001193125-14-184830:note_history:24]
As of
 March 28, 2014, future maturities of long-term debt were as
 follows at the end of each fiscal year below:
  (was, 2014-02-04, similarity 0.9577):
[0001193125-14-034881:note_history:24]
As of
 December 27, 2013, future maturities of long-term debt were as
 follows at the end of each fiscal year below:

- changed (2014-05-06):
[0001193125-14-184830:note_history:25]
Undrawn
 available credit facilities as of March 28, 2014 and
 June 28, 2013 were as follows:
  (was, 2014-02-04, similarity 0.8153):
[0001193125-14-034881:note_history:25]
Undrawn
 available credit facilities as of December 27, 2013 and
 June 28, 2013 totaled:

- changed (2014-05-06):
[0001193125-14-184830:note_history:26]
|  |  | March 28, 2014 |  |  | June 28, 2013 |  |
| Bank borrowings: |  |  |  |  |  |  |  |  |
| Short-term loans |  | $ | 5,228 |  |  | $ | 5,461 |  |
  (was, 2014-02-04, similarity 0.9617):
[0001193125-14-034881:note_history:26]
|  |  | December 27, 2013 |  |  | June 28, 2013 |  |
| Bank borrowings: |  |  |  |  |  |  |  |  |
| Short-term loans |  | $ | 5,181 |  |  | $ | 5,461 |  |

- removed (2014-05-06):
[0001193125-14-034881:note_history:27]
| Contract No. |  | Amount |  |  | Interest Rate Per Annum (%) |  | Conditions |  | Repayment Term |
|  | December 27, 2013 |  |  | June 28, 2013 |  |  |  |  |
| 1 |  | $ | 19,500 |  |  | $ | 22,500 |  |  | LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | June 2012 to March 2017 |
| 2 |  |  | 4,577 |  |  |  | 6,411 |  |  | SIBOR + 1.5% per annum |  | Repayable in quarterly installments within 8 years |  | May 2009 to February 2015 |
| Total |  | $ | 24,077 |  |  | $ | 28,911 |  |  |  |  |  |  |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-06):
[0001193125-14-184830:note_history:28]
As of
 March 28, 2014 and June 28, 2013, the Company had
 outstanding borrowings under long-term loan agreements with banks
 totaling $21,660 and $28,911, respectively, which consisted
 of:
  (was, 2014-02-04, similarity 0.9726):
[0001193125-14-034881:note_history:28]
As of
 December 27, 2013 and June 28, 2013, the Company had
 outstanding borrowings under long-term loan agreements with banks
 totaling $24,077 and $28,911, respectively, which consisted
 of:

- added (2014-05-06):
[0001193125-14-184830:note_history:29]
| Contract No. |  | Amount |  |  | Interest Rate (%) |  | Conditions |  | Repayment Term |
|  | March 28, 2014 |  |  | June 28, 2013 |  |  |  |  |
| 1 |  | $ | 18,000 |  |  | $ | 22,500 |  |  | LIBOR(1) + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | June 2012 to March 2017 |
| 2 |  |  | 3,660 |  |  |  | 6,411 |  |  | SIBOR(2) + 1.5% per annum |  | Repayable in quarterly installments within 8 years |  | May 2009 to February 2015 |
| Total |  | $ | 21,660 |  |  | $ | 28,911 |  |  |  |  |  |  |  |

- added (2014-05-06):
[0001193125-14-184830:note_history:30]
| (1) | LIBOR is London Interbank Offered Rate. |

- added (2014-05-06):
[0001193125-14-184830:note_history:31]
| (2) | SIBOR is Singapore Interbank Offered Rate. |

- removed (2014-05-06):
[0001193125-14-034881:note_history:32]
| Contract No. |  | Amount |  |  | Interest Rate Per Annum (%) |  | Conditions |  | Repayment Term |
|  | December 27, 2013 |  |  | June 28, 2013 |  |  |  |  |
| 1 |  | $ | 19,500 |  |  | $ | 22,500 |  |  | LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | June 2012 to March 2017 |
| 2 |  |  | 4,577 |  |  |  | 6,411 |  |  | SIBOR + 1.5% per annum |  | Repayable in quarterly installments within 8 years |  | May 2009 to February 2015 |
| Total |  | $ | 24,077 |  |  | $ | 28,911 |  |  |  |  |  |  |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-06):
[0001193125-14-184830:note_history:33]
|  |  | March 28, 2014 |  |  | June 28, 2013 |  |
| Long-term loans from bank |  | $ | 21,660 |  |  | $ | 28,911 |  |
| Total borrowings |  | $ | 21,660 |  |  | $ | 28,911 |  |
| Long-term loans from bank consisted of: |  |  |  |  |  |  |  |  |
| Current portion |  | $ | 9,660 |  |  | $ | 9,668 |  |
| Non-current portion |  | $ | 12,000 |  |  | $ | 19,243 |  |
  (was, 2014-02-04, similarity 0.9104):
[0001193125-14-034881:note_history:33]
|  |  | December 27, 2013 |  |  | June 28, 2013 |  |
| Long-term loans from bank |  | $ | 24,077 |  |  | $ | 28,911 |  |
| Total borrowings |  | $ | 24,077 |  |  | $ | 28,911 |  |
| Long-term loans from bank consisted of: |  |  |  |  |  |  |  |  |
| Current portion |  | $ | 9,668 |  |  | $ | 9,668 |  |
| Non-current portion |  |  | 14,409 |  |  |  | 19,243 |  |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-06):
[0001193125-14-184830:note_history:34]
Undrawn
 available credit facilities as of March 28, 2014 and
 June 28, 2013 were as follows:
  (was, 2014-02-04, similarity 0.8153):
[0001193125-14-034881:note_history:34]
Undrawn
 available credit facilities as of December 27, 2013 and
 June 28, 2013 totaled:

- changed (2014-05-06):
[0001193125-14-184830:note_history:35]
|  |  | March 28, 2014 |  |  | June 28, 2013 |  |
| Bank borrowings: |  |  |  |  |  |  |  |  |
| Short-term loans |  | $ | 5,228 |  |  | $ | 5,461 |  |
  (was, 2014-02-04, similarity 0.9617):
[0001193125-14-034881:note_history:35]
|  |  | December 27, 2013 |  |  | June 28, 2013 |  |
| Bank borrowings: |  |  |  |  |  |  |  |  |
| Short-term loans |  | $ | 5,181 |  |  | $ | 5,461 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-06):
[0001193125-14-184830:note_history:36]
As of
 March 28, 2014, future maturities of long-term debt were as
 follows at the end of each fiscal year below:
  (was, 2014-02-04, similarity 0.9577):
[0001193125-14-034881:note_history:36]
As of
 December 27, 2013, future maturities of long-term debt were as
 follows at the end of each fiscal year below:


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2014-05-06):
[0001193125-14-184830:note_history:37]
As discussed in
 the note 8, subsequent to the quarter-end;

- added (2014-05-06):
[0001193125-14-184830:note_history:38]
|  | (a) | On April 25, 2014, a subsidiary entered into an amendment to the long-term loan contract No.1. Under the amendment of the contract, the long-term loan is secured by certain property, plant and equipment. The carrying amount of assets secured and pledged as collateral as of March 28, 2014 was $52,894. The subsidiary is also required to comply with the maximum ratios of debt to equity and minimum levels of debt service coverage ratios and Fabrinet must maintain effective shareholding ratio. |

- added (2014-05-06):
[0001193125-14-184830:note_history:39]
|  | (b) | On April 28, 2014, the subsidiary made an early repayment of long-term loan contract No.2 which included principal, interest expense and early repayment fee of $3,707. As of March 28, 2014, this loan classified in long-term loans from bank, current portion. |

- removed (2014-05-06):
[0001193125-14-034881:note_history:40]
In January
 2014, the Company and its insurers settled on the Company’s
 owned and consigned equipment claim, and the Company received
 $38,613 from its insurers as full and final settlement of its
 claim.
