# FN notes — 0001193125-14-184830


## us-gaap:ScheduleOfEarningsPerShareDilutedByCommonClassTextBlock

[0001193125-14-184830:notes:1]
Diluted
 earnings per ordinary share is calculated as follows:

[0001193125-14-184830:notes:2]
|  |  | Three Months Ended |  |
|  |  | March 28, 2014 |  |  | March 29, 2013 |  |
| Net income used to determine diluted earnings per ordinary share |  | $ | 47,662 |  |  | $ | 21,126 |  |
| Weighted average number of ordinary shares outstanding (thousands of shares) |  |  | 35,078 |  |  |  | 34,596 |  |
| Adjustment for incremental shares arising from the assumed exercise of share options and vesting of restricted share units (thousands of shares) |  |  | 712 |  |  |  | 313 |  |
| Weighted average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 35,790 |  |  |  | 34,909 |  |
| Diluted earnings per ordinary share |  | $ | 1.33 |  |  | $ | 0.61 |  |

[0001193125-14-184830:notes:3]
|  |  | Nine Months Ended |  |
|  |  | March 28, 2014 |  |  | March 29, 2013 |  |
| Net income used to determine diluted earnings per ordinary share |  | $ | 81,398 |  |  | $ | 53,827 |  |
| Weighted average number of ordinary shares outstanding (thousands of shares) |  |  | 34,878 |  |  |  | 34,532 |  |
| Adjustment for incremental shares arising from the assumed exercise of share options and vesting of restricted share units (thousands of shares) |  |  | 626 |  |  |  | 262 |  |
| Weighted average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 35,504 |  |  |  | 34,794 |  |
| Diluted earnings per ordinary share |  | $ | 2.29 |  |  | $ | 1.55 |  |
| Outstanding share options excluded in the computation of diluted earnings per ordinary share* |  |  | 44,644 |  |  |  | 903,856 |  |

[0001193125-14-184830:notes:4]
| * | These share options were not included in the computation of diluted earnings per ordinary share for the three and nine months ended March 28, 2014 and March 29, 2013, respectively, because the exercise price of the options was greater than the average market price of the underlying shares. |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-14-184830:notes:5]
Based on the
 carrying amount of intangibles as of March 28, 2014, and
 assuming no future impairment of the underlying assets, the
 estimated future amortization at the end of each fiscal year below
 is as follows:

[0001193125-14-184830:notes:6]
| 2014 |  | $ | 21 |  |
| 2015 |  |  | 64 |  |
| 2016 |  |  | 5 |  |
| 2017 |  |  | 2 |  |
| Thereafter |  |  | 1 |  |
| Total amortization |  | $ | 93 |  |


## us-gaap:DebtDisclosureTextBlock

[0001193125-14-184830:notes:7]
| 8. |  | Borrowings |

[0001193125-14-184830:notes:8]
Bank borrowings
 and long-term debt was comprised of the following:

[0001193125-14-184830:notes:9]
|  |  | March 28, 2014 |  |  | June 28, 2013 |  |
| Long-term loans from bank |  | $ | 21,660 |  |  | $ | 28,911 |  |
| Total borrowings |  | $ | 21,660 |  |  | $ | 28,911 |  |
| Long-term loans from bank consisted of: |  |  |  |  |  |  |  |  |
| Current portion |  | $ | 9,660 |  |  | $ | 9,668 |  |
| Non-current portion |  | $ | 12,000 |  |  | $ | 19,243 |  |

[0001193125-14-184830:notes:10]
As of
 March 28, 2014 and June 28, 2013, the Company had
 outstanding borrowings under long-term loan agreements with banks
 totaling $21,660 and $28,911, respectively, which consisted
 of:

[0001193125-14-184830:notes:11]
| Contract No. |  | Amount |  |  | Interest Rate (%) |  | Conditions |  | Repayment Term |
|  | March 28, 2014 |  |  | June 28, 2013 |  |  |  |  |
| 1 |  | $ | 18,000 |  |  | $ | 22,500 |  |  | LIBOR(1) + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | June 2012 to March 2017 |
| 2 |  |  | 3,660 |  |  |  | 6,411 |  |  | SIBOR(2) + 1.5% per annum |  | Repayable in quarterly installments within 8 years |  | May 2009 to February 2015 |
| Total |  | $ | 21,660 |  |  | $ | 28,911 |  |  |  |  |  |  |  |

[0001193125-14-184830:notes:12]
| (1) | LIBOR is London Interbank Offered Rate. |

[0001193125-14-184830:notes:13]
| (2) | SIBOR is Singapore Interbank Offered Rate. |

[0001193125-14-184830:notes:14]
Certain of the
 long-term loans are secured by certain property, plant and
 equipment. The carrying amount of assets secured and pledged as
 collateral was $21,102 and $21,815 as of March 28, 2014 and
 June 28, 2013, respectively. The carrying amounts of
 borrowings approximate their fair value.

[0001193125-14-184830:notes:15]
The long-term
 loans prescribe maximum ratios of debt to equity and minimum levels
 of debt service coverage ratios. As of March 28, 2014 and
 June 28, 2013, the Company was in compliance with its
 long-term loan agreements. In addition to financial ratios, certain
 of the Company’s packing credits and long-term loans include
 customary events of default.

[0001193125-14-184830:notes:16]
The movements
 of long-term loans were as follows for the nine months ended
 March 28, 2014 and March 29, 2013:

[0001193125-14-184830:notes:17]
|  |  | Nine Months Ended |  |
|  |  | March 28, 2014 |  |  | March 29, 2013 |  |
| Opening net book amount |  | $ | 28,911 |  |  | $ | 38,579 |  |
| Repayment during the period |  |  | (7,251 | ) |  |  | (7,251 | ) |
| Closing net book amount |  | $ | 21,660 |  |  | $ | 31,328 |  |

[0001193125-14-184830:notes:18]
Subsequent to
 the quarter-end:

[0001193125-14-184830:notes:19]
|  | (a) | On April 25, 2014, a subsidiary entered into an amendment to the long-term loan contract No.1. Under the amendment of the contract, the long-term loan is secured by certain property, plant and equipment. The carrying amount of assets secured and pledged as collateral as of March 28, 2014 was $52,894. The subsidiary is also required to comply with the maximum ratios of debt to equity and minimum levels of debt service coverage ratios and Fabrinet must maintain effective shareholding ratio. |

[0001193125-14-184830:notes:20]
|  | (b) | On April 28, 2014, the subsidiary made an early repayment of long-term loan contract No.2 which included principal, interest expense and an early repayment fee of $3,707. As of March 28, 2014, this loan was classified in long-term loans from bank, current portion. |

[0001193125-14-184830:notes:21]
As of
 March 28, 2014, future maturities of long-term debt were as
 follows at the end of each fiscal year below:

[0001193125-14-184830:notes:22]
| 2014 |  | $ | 5,160 |  |
| 2015 |  |  | 6,000 |  |
| 2016 |  |  | 6,000 |  |
| 2017 |  |  | 4,500 |  |
| Total |  | $ | 21,660 |  |

[0001193125-14-184830:notes:23]
Credit
 facilities:

[0001193125-14-184830:notes:24]
Undrawn
 available credit facilities as of March 28, 2014 and
 June 28, 2013 were as follows:

[0001193125-14-184830:notes:25]
|  |  | March 28, 2014 |  |  | June 28, 2013 |  |
| Bank borrowings: |  |  |  |  |  |  |  |  |
| Short-term loans |  | $ | 5,228 |  |  | $ | 5,461 |  |


## us-gaap:ScheduleOfFutureMinimumRentalPaymentsForOperatingLeasesTableTextBlock

[0001193125-14-184830:notes:26]
As of
 March 28, 2014, the future minimum lease payments due under
 non-cancelable leases were as follows at the end of each fiscal
 year below:

[0001193125-14-184830:notes:27]
| 2014 |  |  | 247 |  |
| 2015 |  |  | 989 |  |
| 2016 |  |  | 943 |  |
| 2017 |  |  | 928 |  |
| 2018 |  |  | 928 |  |
| Thereafter |  |  | 720 |  |
| Total minimum operating lease payments |  | $ | 4,755 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-14-184830:notes:28]
|  |  | March 28, 2014 |  |  | June 28, 2013 |  |
| Raw materials |  | $ | 37,277 |  |  | $ | 34,572 |  |
| Work in progress |  |  | 54,152 |  |  |  | 43,806 |  |
| Finished goods |  |  | 10,735 |  |  |  | 7,342 |  |
| Goods in transit |  |  | 8,452 |  |  |  | 5,359 |  |
|  |  |  | 110,616 |  |  |  | 91,079 |  |
| Less: Inventory obsolescence |  |  | (2,790 | ) |  |  | (2,117 | ) |
| Inventory, net |  | $ | 107,826 |  |  | $ | 88,962 |  |


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0001193125-14-184830:notes:29]
The effect of
 recording share-based compensation expense for the three and nine
 months ended March 28, 2014 and March 29, 2013 was as
 follows:

[0001193125-14-184830:notes:30]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 28, 2014 |  |  | March 29, 2013 |  |  | March 28, 2014 |  |  | March 29, 2013 |  |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share options |  | $ | 172 |  |  | $ | 435 |  |  | $ | 710 |  |  | $ | 1,575 |  |
| Restricted share units |  |  | 1,306 |  |  |  | 902 |  |  |  | 3,828 |  |  |  | 2,394 |  |
| Total share-based compensation expense |  |  | 1,478 |  |  |  | 1,337 |  |  |  | 4,538 |  |  |  | 3,969 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 1,478 |  |  | $ | 1,337 |  |  | $ | 4,538 |  |  | $ | 3,969 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-14-184830:notes:31]
[same as prior period, unchanged from 0001193125-14-034881:notes:26]

[0001193125-14-184830:notes:32]
[same as prior period, unchanged from 0001193125-14-034881:notes:27]

[0001193125-14-184830:notes:33]
[same as prior period, unchanged from 0001193125-14-034881:notes:28]

[0001193125-14-184830:notes:34]
[same as prior period, unchanged from 0001193125-14-034881:notes:29]

[0001193125-14-184830:notes:35]
[same as prior period, unchanged from 0001193125-14-034881:notes:30]

[0001193125-14-184830:notes:36]
[same as prior period, unchanged from 0001193125-14-034881:notes:31]

[0001193125-14-184830:notes:37]
The following
 table sets forth the Company’s applicable assets and
 liabilities measured at fair value on a recurring basis as of
 March 28, 2014:

[0001193125-14-184830:notes:38]
|  |  | Fair Value Measurements at Reporting Date Using |  |
|  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |  | Total |  |
| Derivative assets (1) |  |  | — |  |  |  | 56 |  |  |  | — |  |  |  | 56 |  |
| Derivative liabilities(2) |  |  | — |  |  |  | 172 |  |  |  | — |  |  |  | 172 |  |
| Net liabilities measured at fair value |  | $ | — |  |  | $ | 116 |  |  | $ | — |  |  | $ | 116 |  |

[0001193125-14-184830:notes:39]
| (1) | Foreign currency options with notional amount of $23.0 million. |

[0001193125-14-184830:notes:40]
| (2) | Foreign currency forward contracts with notional amount of $6.0 million and CAD 1.7 million. |

[0001193125-14-184830:notes:41]
[same as prior period, unchanged from 0001193125-14-034881:notes:34]

[0001193125-14-184830:notes:42]
|  |  | Fair Value Measurements at Reporting Date Using |  |
|  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |  | Total |  |
| Derivative liabilities(3) |  |  | — |  |  |  | 766 |  |  |  | — |  |  |  | 766 |  |
| Net liabilities measured at fair value |  | $ | — |  |  | $ | 766 |  |  | $ | — |  |  | $ | 766 |  |

[0001193125-14-184830:notes:43]
| (3) | Foreign currency options with notional amount of $5.0 million and forward contracts with notional amount of $23.0 million and CAD 1.2 million. |

[0001193125-14-184830:notes:44]
The Company
 uses foreign currency forward contracts to manage the foreign
 exchange risk associated with certain foreign currency-denominated
 assets and liabilities. As a result of foreign currency
 fluctuations, the U.S. dollar equivalent values of its foreign
 currency-denominated assets and liabilities change. The Company has
 not designated such foreign currency forward contracts as hedging
 instruments under the accounting standard for derivatives and
 hedging. The forward exchange contracts and option contracts
 outstanding as of March 28, 2014 and June 28, 2013 had a
 maturity in one to six months duration. The Company minimizes the
 credit risk in derivative instruments by limiting its exposure to
 any single counterparty and by entering into derivative instruments
 only with counterparties that meet the Company’s minimum
 credit quality standard.

[0001193125-14-184830:notes:45]
The derivative
 assets and liabilities are classified in other current assets and
 accrued expenses, respectively, on the condensed consolidated
 balance sheet. The change in the fair value of the derivatives is
 recorded in foreign exchange (loss) gain on the condensed
 consolidated statement of operations.


## us-gaap:ScheduleOfCreditLossesForFinancingReceivablesCurrentTableTextBlock

[0001193125-14-184830:notes:46]
The activities
 and balances for allowance for doubtful accounts for the nine
 months ended March 28, 2014 and March 29, 2013 were as
 follows:

[0001193125-14-184830:notes:47]
|  |  | Balance at Beginning of Period |  |  | Credited to Income |  |  | Balance at End of Period |  |
| Nine months ended March 28, 2014 |  | $ | 109 |  |  | $ | (62 | ) |  | $ | 47 |  |
| Nine months ended March 29, 2013 |  | $ | 203 |  |  | $ | (94 | ) |  | $ | 109 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-14-184830:notes:48]
[same as prior period, unchanged from 0001193125-14-034881:notes:39]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-14-184830:notes:49]
[same as prior period, unchanged from 0001193125-14-034881:notes:40]

[0001193125-14-184830:notes:50]
[same as prior period, unchanged from 0001193125-14-034881:notes:41]

[0001193125-14-184830:notes:51]
[same as prior period, unchanged from 0001193125-14-034881:notes:42]

[0001193125-14-184830:notes:52]
For the nine
 months ended March 28, 2014, Fabrinet issued 311,474 ordinary
 shares upon the exercise of options, for cash consideration at a
 weighted average exercise price of $12.70 per share, and 158,325
 ordinary shares upon the vesting of restricted share units, net of
 shares withheld.

[0001193125-14-184830:notes:53]
For the nine
 months ended March 29, 2013, Fabrinet issued 87,123 ordinary
 shares upon the exercise of options, for cash consideration at a
 weighted average exercise price of $6.08 per share, and 68,383
 ordinary shares upon the vesting of restricted share units, net of
 shares withheld.

[0001193125-14-184830:notes:54]
[same as prior period, unchanged from 0001193125-14-034881:notes:45]


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-14-184830:notes:55]
[same as prior period, unchanged from 0001193125-14-034881:notes:46]

[0001193125-14-184830:notes:56]
[same as prior period, unchanged from 0001193125-14-034881:notes:47]

[0001193125-14-184830:notes:57]
The condensed
 consolidated financial statements of Fabrinet included herein have
 been prepared on a basis consistent with the June 28, 2013
 audited consolidated financial statements and include all material
 adjustments, consisting of normal recurring adjustments, necessary
 to fairly present the information set forth therein. These
 condensed consolidated financial statements should be read in
 conjunction with the June 28, 2013 audited consolidated
 financial statements and notes thereto. The year-end condensed
 balance sheet data was derived from audited financial statements
 but does not include all disclosures required by accounting
 principles generally accepted in the United States of America
 (“U.S. GAAP”).

[0001193125-14-184830:notes:58]
[same as prior period, unchanged from 0001193125-14-034881:notes:49]

[0001193125-14-184830:notes:59]
[same as prior period, unchanged from 0001193125-14-034881:notes:50]

[0001193125-14-184830:notes:60]
The Company
 utilizes a 52-53 week fiscal year ending on the Friday in June
 closest to June 30. The three months ended March 28, 2014
 and March 29, 2013 each consisted of 13 weeks. The nine months
 ended March 28, 2014 and March 29, 2013 each consisted of
 39 weeks. Fiscal year 2014 will be comprised of 52 weeks and will
 end on June 27, 2014.

[0001193125-14-184830:notes:61]
[same as prior period, unchanged from 0001193125-14-034881:notes:52]

[0001193125-14-184830:notes:62]
[same as prior period, unchanged from 0001193125-14-034881:notes:53]

[0001193125-14-184830:notes:63]
As of
 March 28, 2014, the Company’s cash and cash equivalents
 were held in deposits and highly liquid investment products with
 maturities of three months or less with banks and other financial
 institutions having credit ratings of A minus or above. The Company
 had two customers that each contributed to 10% or more of its total
 accounts receivable as of March 28, 2014 and June 28,
 2013, respectively.

[0001193125-14-184830:notes:64]
[same as prior period, unchanged from 0001193125-14-034881:notes:55]

[0001193125-14-184830:notes:65]
[same as prior period, unchanged from 0001193125-14-034881:notes:56]

[0001193125-14-184830:notes:66]
In July 2013,
 the Financial Accounting Standards Board (“FASB”)
 issued Accounting Standards Update (“ASU”)
 No. 2013-11 — Income Taxes (Topic 740) —
 Presentation of an Unrecognized Tax Benefit When a Net Operating
 Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward
 Exists. The guidance suggested that an unrecognized tax benefit or
 a portion of an unrecognized of tax benefit, should be presented in
 the financial statements as a reduction to a deferred tax assets
 for a net operating loss carryforward, a similar tax loss, or a tax
 loss creditforward, except as follows. To the extent a net
 operating loss carryforward, a similar tax loss, or a tax loss
 creditforward is not available at the reporting date under tax law
 of the applicable jurisdiction to settle any additional income
 taxes that would result from the disallowance of a tax position or
 the tax loss of the applicable jurisdiction does not required the
 entity to use, and the entity does not intended to use, the
 deferred tax assets for such purpose, the unrecognized tax benefit
 should be presented in the financial statement as a liabilities and
 should not be combined with deferred tax assets. The assessment of
 whether a deferred tax asset is available is based on the
 unrecognized tax benefit and deferred tax asset that exist at the
 reporting date and should be made presuming disallowance of the tax
 position at the reporting date. This guidance is effective for
 fiscal years, and interim periods within those years, beginning
 after December 15, 2013. The Company does not expect that the
 adoption of this guidance will have an effect on its consolidated
 financial statements.

[0001193125-14-184830:notes:67]
In April 2013,
 the FASB issued ASU No. 2013-07 – Presentation of
 Financial Statements (Topic 205) — Liquidation Basis of
 Accounting. The amendments require an entity to prepare its
 financial statements using the liquidation basis of accounting when
 liquidation is imminent. Liquidation is imminent when the
 likelihood is remote that the entity will return from liquidation
 and either (a) a plan for liquidation is approved by the
 person or persons with the authority to make such a plan effective
 and the likelihood is remote that the execution of the plan will be
 blocked by other parties, or (b) a plan for liquidation is
 being imposed by other forces (for example, involuntary
 bankruptcy). If a plan for liquidation was specified in the
 entity’s governing documents from the entity’s
 inception (for example, limited-life entities), the entity should
 apply the liquidation basis of accounting only if the approved plan
 for liquidation differs from the plan for liquidation that was
 specified at the entity’s inception. The amendments require
 financial statements prepared using the liquidation basis of
 accounting to present relevant information about an entity’s
 expected resources in liquidation by measuring and presenting
 assets at the amount of the expected cash proceeds from
 liquidation. The entity should include in its presentation of
 assets any items it had not previously recognized under U.S. GAAP
 but that it expects to either sell in liquidation or use in
 settling liabilities (for example, trademarks). An entity should
 recognize and measure its liabilities in accordance with U.S. GAAP
 that otherwise applies to those liabilities. The entity should not
 anticipate that it will be legally released from being the primary
 obligor under those liabilities, either judicially or by creditors.
 The entity also is required to accrue and separately present the
 costs that it expects to incur and the income that it expects to
 earn during the expected duration of the liquidation, including any
 costs associated with sale or settlement of those assets and
 liabilities. Additionally, the amendments require disclosures about
 an entity’s plan for liquidation, the methods and significant
 assumptions used to measure assets and liabilities, the type and
 amount of costs and income accrued, and the expected duration of
 the liquidation process. This guidance is effective for entities
 that determine liquidation is imminent during annual reporting
 periods beginning after December 15, 2013 and interim
 reporting periods therein. The Company does not expect that the
 adoption of this guidance will have an effect on its consolidated
 financial statements.

[0001193125-14-184830:notes:68]
In March 2013,
 the FASB issued ASU No. 2013-05 – Foreign Currency
 Matters (Topic 830) — Parents’ Accounting for the
 Cumulative Translation Adjustment upon Derecognition of Certain
 Subsidiaries or Groups of Assets within a Foreign Entity or of an
 Investment in a Foreign Entity. When a reporting entity (parent)
 ceases to have a controlling financial interest in a subsidiary or
 group of assets that is a nonprofit activity or a business (other
 than a sale of in substance real estate or conveyance of oil and
 gas mineral rights) within a foreign entity, the parent is required
 to apply the guidance in Subtopic 830-30 to release any related
 cumulative translation adjustment into net income. Accordingly, the
 cumulative translation adjustment should be released into net
 income only if the sale or transfer results in the complete or
 substantially complete liquidation of the foreign entity in which
 the subsidiary or group of assets had resided. For an equity method
 investment that is a foreign entity, the partial sale guidance in
 Section 830-30-40 still applies. As such, a pro rata portion
 of the cumulative translation adjustment should be released into
 net income upon a partial sale of such an equity method investment.
 However, this treatment does not apply to an equity method
 investment that is not a foreign entity. In those instances, the
 cumulative translation adjustment is released into net income only
 if the partial sale represents a complete or substantially complete
 liquidation of the foreign entity that contains the equity method
 investment. Additionally, the amendments in this Update clarify
 that the sale of an investment in a foreign entity includes both
 (1) events that result in the loss of a controlling financial
 interest in a foreign entity (that is, irrespective of any retained
 investment) and (2) events that result in an acquirer
 obtaining control of an acquiree in which it held an equity
 interest immediately before the acquisition date (sometimes also
 referred to as a step acquisition). Accordingly, the cumulative
 translation adjustment should be released into net income upon the
 occurrence of those events. This guidance is effective
 prospectively for fiscal years and interim reporting periods within
 those years beginning after December 15, 2013. The Company
 does not expect that the adoption of this guidance will have an
 effect on its consolidated financial statements.

[0001193125-14-184830:notes:69]
In February
 2013, the FASB issued ASU No. 2013-04 – Liabilities
 (Topic 405) — Obligations Resulting from Joint and Several
 Liability Arrangements for which the Total Amount of the Obligation
 is fixed at the Reporting Date. The guidance in this update
 requires an entity to measure obligations resulting from joint and
 several liability arrangements for which the total amount of the
 obligation within the scope of this guidance is fixed at the
 reporting date, as the sum of the following: (a) the amount
 the reporting entity agreed to pay on the basis of its arrangement
 among its co-obligors, and (b) any additional amount the
 reporting entity expects to pay on behalf of its co-obligors. The
 guidance also requires an entity to disclose the nature and amount
 of the obligation as well as other information about those
 obligations. This guidance is effective for fiscal years, and
 interim periods within those years, beginning after
 December 15, 2013. The Company does not expect that the
 adoption of this guidance will have an effect on its consolidated
 financial statements.

[0001193125-14-184830:notes:70]
In January
 2013, the FASB issued ASU No. 2013-01 – Balance Sheet
 (Topic 210) — Clarifying the Scope of Disclosure about
 Offsetting Assets and Liabilities. The amendments clarify that the
 scope of Update 2011-11 applies to derivatives accounted for in
 accordance with Topic 815, Derivatives and Hedging, including
 bifurcated embedded derivatives, repurchase agreements and reverse
 repurchase agreements, and securities borrowing and securities
 lending transactions that are either offset in accordance with
 Section 210-20-45 or Section 815-10-45 or subject to an
 enforceable master netting arrangement or similar agreement. This
 guidance is effective for fiscal years beginning on or after
 January 1, 2013, and interim periods within those annual
 periods. The Company adopted this guidance in the first quarter of
 fiscal year 2014. This guidance did not impact the Company’s
 presentation, financial position, or results of
 operations.

[0001193125-14-184830:notes:71]
In July 2012,
 the FASB issued ASU No. 2012-02 – Intangibles —
 Goodwill and Other (Topic 350) – Testing Indefinite-Lived
 Intangible Assets for Impairment. Under the amendments in ASU
 No. 2012-02, an entity has the option first to assess
 qualitative factors to determine whether the existence of events
 and circumstances indicates that it is more likely than not that
 the indefinite-lived intangible asset is impaired. If, after
 assessing the totality of events and circumstances, an entity
 concludes that it is not more likely than not that the
 indefinite-lived intangible asset is impaired, then the entity is
 not required to take further action. However, if an entity
 concludes otherwise, then it is required to determine the fair
 value of the indefinite-lived intangible asset and perform the
 quantitative impairment test by comparing the fair value with the
 carrying amount in accordance with Subtopic 350-30. This guidance
 is effective for fiscal years beginning after September 15,
 2012. The Company adopted this guidance in the first quarter of
 fiscal year 2014. This guidance did not impact the Company’s
 presentation, financial position, or results of
 operations.

[0001193125-14-184830:notes:72]
In December
 2011, the FASB issued ASU No. 2011-11 – Balance Sheet
 (Topic 210) – Disclosures about Offsetting Assets and
 Liabilities. The amendments in ASU No. 2011-11 will enhance
 disclosures required by U.S. GAAP by requiring improved information
 about financial instruments and derivative instruments that are
 either (1) offset in accordance with Section 210-20-45 or
 Section 815-10-45 or (2) subject to an enforceable master
 netting arrangement or similar agreement, irrespective of whether
 they are offset in accordance with Section 210-20-45 or
 Section 815-10-45. Information about offsetting and related
 arrangements will enable users of an entity’s financial
 statements to understand the effect of those arrangements on an
 entity’s financial position, including the effect or
 potential effect of rights of setoff associated with certain
 financial instruments and derivative instruments in the scope of
 ASU No. 2011-11. This guidance is effective for annual
 reporting periods beginning on or after January 1, 2013, and
 interim periods within those annual periods. The Company adopted
 this guidance in the first quarter of fiscal year 2014. This
 guidance did not impact the Company’s presentation, financial
 position, or results of operations.


## us-gaap:EarningsPerShareTextBlock

[0001193125-14-184830:notes:73]
[same as prior period, unchanged from 0001193125-14-034881:notes:67]

[0001193125-14-184830:notes:74]
[same as prior period, unchanged from 0001193125-14-034881:notes:68]

[0001193125-14-184830:notes:75]
|  |  | Three Months Ended |  |
|  |  | March 28, 2014 |  |  | March 29, 2013 |  |
| Net income attributable to shareholders |  | $ | 47,662 |  |  | $ | 21,126 |  |
| Weighted average number of ordinary shares outstanding (thousands of shares) |  |  | 35,078 |  |  |  | 34,596 |  |
| Basic earnings per ordinary share |  | $ | 1.36 |  |  | $ | 0.61 |  |

[0001193125-14-184830:notes:76]
|  |  | Nine Months Ended |  |
|  |  | March 28, 2014 |  |  | March 29, 2013 |  |
| Net income attributable to shareholders |  | $ | 81,398 |  |  | $ | 53,827 |  |
| Weighted average number of ordinary shares outstanding (thousands of shares) |  |  | 34,878 |  |  |  | 34,532 |  |
| Basic earnings per ordinary share |  | $ | 2.33 |  |  | $ | 1.56 |  |

[0001193125-14-184830:notes:77]
[same as prior period, unchanged from 0001193125-14-034881:notes:71]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-14-184830:notes:78]
[same as prior period, unchanged from 0001193125-14-034881:notes:72]

[0001193125-14-184830:notes:79]
The following
 tables present details of the Company’s
 intangibles:

[0001193125-14-184830:notes:80]
|  |  | March 28, 2014 |  |
|  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net |  |
| Software |  | $ | 3,459 |  |  | $ | (3,366 | ) |  | $ | 93 |  |
| Total intangibles |  | $ | 3,459 |  |  | $ | (3,366 | ) |  | $ | 93 |  |

[0001193125-14-184830:notes:81]
|  |  | June 28, 2013 |  |
|  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net |  |
| Software |  | $ | 3,458 |  |  | $ | (3,294 | ) |  | $ | 164 |  |
| Total intangibles |  | $ | 3,458 |  |  | $ | (3,294 | ) |  | $ | 164 |  |

[0001193125-14-184830:notes:82]
The Company
 recorded amortization expense relating to intangibles of $21 and
 $43 for the three months ended March 28, 2014 and
 March 29, 2013, respectively, and $72 and $185 for the nine
 months ended March 28, 2014 and March 29, 2013,
 respectively.


## us-gaap:SubsequentEventsTextBlock

[0001193125-14-184830:notes:83]
| 15. |  | Subsequent events |

[0001193125-14-184830:notes:84]
As discussed in
 the note 8, subsequent to the quarter-end;

[0001193125-14-184830:notes:85]
|  | (b) | On April 28, 2014, the subsidiary made an early repayment of long-term loan contract No.2 which included principal, interest expense and early repayment fee of $3,707. As of March 28, 2014, this loan classified in long-term loans from bank, current portion. |


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001193125-14-184830:notes:86]
[same as prior period, unchanged from 0001193125-14-034881:notes:76]

[0001193125-14-184830:notes:87]
The Company
 suspended production at all of its manufacturing facilities in
 Thailand from October 17, 2011 through November 14, 2011
 because of severe flooding in Thailand. The Company never resumed,
 and has permanently ceased, production at its Chokchai facility.
 The Company submitted claims for losses to its insurance companies,
 all of which have been settled as of March 28,
 2014.

[0001193125-14-184830:notes:88]
The Company
 recognized $38,614 and $45,211 as income related to flooding in the
 three and nine months ended March 28, 2014, respectively,
 towards full and final settlement of the Company’s owned and
 consigned equipment and inventory claims. This income was offset by
 the recognition of $463 of other expenses in connection with
 write-offs of advance payments to a customer due to flood
 losses.

[0001193125-14-184830:notes:89]
In the three
 months ended March 29, 2013, the Company received an interim
 payment of $11,419 from its insurers against the Company’s
 claims for owned inventory losses. In the nine months ended
 March 29, 2013, the Company received an interim payment of
 $11,419 from its insurers against the Company’s claims for
 owned inventory losses, an interim payment of $4,825 from its
 insurers against the Company’s claims for owned equipment
 losses, an interim payment of $4,741 against its claims for
 business interruption losses and a payment of $79 as full and final
 settlement of its claim for damage to its buildings at
 Pinehurst.

[0001193125-14-184830:notes:90]
During the nine
 months ended March 28, 2014, the Company made a cash payment
 of $5,250 and transferred equipment, with an aggregate value of
 $2,300, to a customer towards full and final settlement for any and
 all flood-related losses in accordance with the settlement
 agreement entered into during fiscal 2013 with such customer. In
 addition, during the nine months ended March 28, 2014, the
 Company fulfilled its obligations to a customer’s insurers by
 making a payment of $2,167 for full and final settlement of the
 Company’s liability to such insurer for damages to
 customer-owned inventory, which occurred during the flooding in
 accordance with the settlement agreement entered into during fiscal
 2013. The Company also made a cash payment of $95 towards the other
 flood-related settlements during the nine months ended
 March 28, 2014.

[0001193125-14-184830:notes:91]
During the nine
 months ended March 29, 2013, the Company entered into
 settlement agreements with three of its customers relating to the
 Company’s liability for the customers’ losses as a
 result of the flooding and made an initial aggregate payment of
 $8,059 to such customers.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-14-184830:notes:92]
[same as prior period, unchanged from 0001193125-14-034881:notes:81]

[0001193125-14-184830:notes:93]
As of
 March 28, 2014 and June 28, 2013, the liability for
 uncertain tax positions including accrued interest and penalties
 decreased to $379 and $1,835, respectively. The Company expects the
 estimated amount of liability associated with its uncertain tax
 positions to decrease within the next 12 months due to the
 lapse of the applicable statute of limitations in foreign tax
 jurisdictions.

[0001193125-14-184830:notes:94]
[same as prior period, unchanged from 0001193125-14-034881:notes:83]

[0001193125-14-184830:notes:95]
The effective
 tax rate for the Company for the three months ended March 28,
 2014 and March 29, 2013 was 1.5% and 4.2% of net income,
 respectively. The decrease in the effective tax rate for the three
 months ended March 28, 2014 was due to the fact that the
 Company had higher net income during the period, primarily as a
 result of income related to flooding of $38,151 that was not
 subject to income tax, as compared to the three months ended
 March 29, 2013.

[0001193125-14-184830:notes:96]
The effective
 tax rate for the Company for the nine months ended March 28,
 2014 and March 29, 2013 was 0.2% and 4.8% of net income,
 respectively. The decrease in the effective tax rate for the nine
 months ended March 28, 2014 was primarily due to the reversal
 of liability for uncertain tax positions, including accrued
 interest, of $1,538 and increase in deferred tax assets of $562 and
 also the fact that the Company had a higher net income during the
 period as a result of income related to flooding of $44,748 that
 was not subject to income tax, as compared to the reversal of
 liability for uncertain tax positions of $588 for the nine months
 ended March 29, 2013.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-14-184830:notes:97]
[same as prior period, unchanged from 0001193125-14-034881:notes:86]

[0001193125-14-184830:notes:98]
[same as prior period, unchanged from 0001193125-14-034881:notes:87]

[0001193125-14-184830:notes:99]
[same as prior period, unchanged from 0001193125-14-034881:notes:88]

[0001193125-14-184830:notes:100]
Share-based
 compensation expense was recorded in the condensed consolidated
 statements of operations as follows: cost of revenues of $290 and
 $275 for the three months ended March 28, 2014 and
 March 29, 2013, respectively, and $888 and $919 for the nine
 months ended March 28, 2014 and March 29, 2013,
 respectively; and SG&A expenses of $1,188 and $1,062 for the
 three months ended March 28, 2014 and March 29, 2013,
 respectively, and $3,650 and $3,050 for the nine months ended
 March 28, 2014 and March 29, 2013, respectively. The
 Company did not capitalize any share-based compensation expense as
 part of any asset costs during the three and nine months ended
 March 28, 2014 and March 29, 2013.

[0001193125-14-184830:notes:101]
[same as prior period, unchanged from 0001193125-14-034881:notes:90]

[0001193125-14-184830:notes:102]
Share options
 have been granted to directors and employees. As of March 28,
 2014, there were 15,040 share options outstanding under the Amended
 and Restated 1999 Share Option Plan (the “1999 Plan”).
 Additional option grants may not be made under the 1999
 Plan.

[0001193125-14-184830:notes:103]
On
 March 12, 2010, Fabrinet’s shareholders adopted the 2010
 Performance Incentive Plan (the “2010 Plan”). On
 December 20, 2010 and December 20, 2012, Fabrinet’s
 shareholders adopted amendments to the 2010 Plan to increase the
 number of ordinary shares authorized for issuance under the 2010
 Plan by 500,000 and 3,700,000 shares, respectively. A total of
 5,700,000 ordinary shares are authorized for issuance under the
 2010 Plan, plus any shares subject to share options under the 1999
 Plan outstanding as of June 24, 2010, that expire, are
 canceled or terminate after such date. As of March 28, 2014,
 there were an aggregate of 907,195 share options outstanding,
 838,634 restricted share units outstanding, and 3,444,100 ordinary
 shares available for future grant under the 2010 Plan.

[0001193125-14-184830:notes:104]
[same as prior period, unchanged from 0001193125-14-034881:notes:93]

[0001193125-14-184830:notes:105]
Fabrinet’s board of directors has the authority to
 determine the type of option and the number of shares subject to an
 option. Options generally vest and become exercisable over four
 years and expire, if not exercised, within seven years of the grant
 date. In the case of a grantee’s first grant, 25 percent of
 the underlying shares subject to an option vest 12 months after the
 vesting commencement date and 1/48 of the underlying shares vest
 monthly over each of the subsequent 36 months. In the case of
 any additional grants to a grantee, 1/48 of the underlying shares
 subject to an option vest monthly over four years, commencing one
 month after the vesting commencement date.

[0001193125-14-184830:notes:106]
[same as prior period, unchanged from 0001193125-14-034881:notes:95]

[0001193125-14-184830:notes:107]
|  |  | Number of Shares Underlying Options |  |  | Weighted-Average Exercise Price Per Share |  |
|  |  | Nine Months Ended |  |  | Nine Months Ended |  |
|  |  | March 28, 2014 |  |  | March 29, 2013 |  |  | March 28, 2014 |  |  | March 29, 2013 |  |
| Shares underlying options outstanding at beginning of the period |  |  | 104,078 |  |  |  | 189,540 |  |  | $ | 5.38 |  |  | $ | 5.18 |  |
| Granted |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (87,288 | ) |  |  | (77,747 | ) |  |  | 5.35 |  |  |  | 4.98 |  |
| Forfeited |  |  | (350 | ) |  |  | — |  |  |  | 6.11 |  |  |  | — |  |
| Expired |  |  | (1,400 | ) |  |  | — |  |  |  | 5.50 |  |  |  | — |  |
| Shares underlying options outstanding at end of the period |  |  | 15,040 |  |  |  | 111,793 |  |  | $ | 5.51 |  |  | $ | 5.32 |  |
| Shares underlying options exercisable at end of the period |  |  | 15,040 |  |  |  | 86,646 |  |  | $ | 5.51 |  |  | $ | 5.19 |  |

[0001193125-14-184830:notes:108]
The following
 summarizes information for share options outstanding as of
 March 28, 2014 under the 1999 Plan:

[0001193125-14-184830:notes:109]
|  |  | Number of Shares Underlying Options |  |  | Exercise Price Per Share |  |  | Weighted Average Remaining Contractual Life (years) |  |  | Aggregate Intrinsic Value |  |
|  |  |  | 525 |  |  |  | 4.25 |  |  |  | 0.42 |  |  |  |  |  |
|  |  |  | 500 |  |  |  | 4.75 |  |  |  | 0.67 |  |  |  |  |  |
|  |  |  | 2,100 |  |  |  | 5.00 |  |  |  | 0.88 |  |  |  |  |  |
|  |  |  | 1,400 |  |  |  | 5.25 |  |  |  | 1.11 |  |  |  |  |  |
|  |  |  | 10,465 |  |  |  | 5.75 |  |  |  | 2.38 |  |  |  |  |  |
|  |  |  | 50 |  |  |  | 6.25 |  |  |  | 3.11 |  |  |  |  |  |
| Options outstanding |  |  | 15,040 |  |  |  |  |  |  |  | 1.93 |  |  | $ | 224 |  |
| Options exercisable |  |  | 15,040 |  |  |  |  |  |  |  | 1.93 |  |  | $ | 224 |  |

[0001193125-14-184830:notes:110]
As of
 March 28, 2014, there is no estimated share-based compensation
 expense related to share options under the 1999 Plan that remains
 to be recorded and amortized.

[0001193125-14-184830:notes:111]
[same as prior period, unchanged from 0001193125-14-034881:notes:100]

[0001193125-14-184830:notes:112]
|  |  | Number of Shares Underlying Options |  |  | Weighted-Average Exercise Price Per Share |  |
|  |  | Nine Months Ended |  |  | Nine Months Ended |  |
|  |  | March 28, 2014 |  |  | March 29, 2013 |  |  | March 28, 2014 |  |  | March 29, 2013 |  |
| Shares underlying options outstanding at beginning of the period |  |  | 1,173,233 |  |  |  | 1,280,750 |  |  | $ | 16.25 |  |  | $ | 16.32 |  |
| Granted |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (224,186 | ) |  |  | (9,376 | ) |  |  | 15.56 |  |  |  | 15.16 |  |
| Forfeited |  |  | (12,404 | ) |  |  | (24,262 | ) |  |  | 16.46 |  |  |  | 17.52 |  |
| Expired |  |  | (29,448 | ) |  |  | (48,725 | ) |  |  | 17.47 |  |  |  | 17.00 |  |
| Shares underlying options outstanding at end of the period |  |  | 907,195 |  |  |  | 1,198,387 |  |  | $ | 16.38 |  |  | $ | 16.28 |  |
| Shares underlying options exercisable at end of the period |  |  | 625,636 |  |  |  | 593,742 |  |  | $ | 16.65 |  |  | $ | 16.48 |  |

[0001193125-14-184830:notes:113]
The following
 summarizes information for share options outstanding as of
 March 28, 2014 under the 2010 Plan:

[0001193125-14-184830:notes:114]
|  |  | Number of Shares Underlying Options |  |  | Exercise Price Per Share |  |  | Weighted Average Remaining Contractual Life (years) |  |  | Aggregate Intrinsic Value |  |
|  |  |  | 8,368 |  |  | $ | 13.77 |  |  |  | 3.41 |  |  |  |  |  |
|  |  |  | 465,143 |  |  |  | 16.83 |  |  |  | 3.55 |  |  |  |  |  |
|  |  |  | 30,000 |  |  |  | 15.05 |  |  |  | 3.61 |  |  |  |  |  |
|  |  |  | 26,844 |  |  |  | 25.50 |  |  |  | 3.80 |  |  |  |  |  |
|  |  |  | 7,400 |  |  |  | 26.16 |  |  |  | 3.85 |  |  |  |  |  |
|  |  |  | 10,400 |  |  |  | 23.62 |  |  |  | 4.10 |  |  |  |  |  |
|  |  |  | 109,560 |  |  |  | 15.16 |  |  |  | 4.39 |  |  |  |  |  |
|  |  |  | 215,159 |  |  |  | 14.12 |  |  |  | 4.62 |  |  |  |  |  |
|  |  |  | 26,510 |  |  |  | 19.36 |  |  |  | 4.87 |  |  |  |  |  |
|  |  |  | 5,550 |  |  |  | 18.60 |  |  |  | 4.93 |  |  |  |  |  |
|  |  |  | 2,261 |  |  |  | 12.83 |  |  |  | 5.12 |  |  |  |  |  |
| Options outstanding |  |  | 907,195 |  |  |  |  |  |  |  | 3.97 |  |  | $ | 3,839 |  |
| Options exercisable |  |  | 625,636 |  |  |  |  |  |  |  | 3.87 |  |  | $ | 2,502 |  |

[0001193125-14-184830:notes:115]
As of
 March 28, 2014, $289 of estimated share-based compensation
 expense related to share options under the 2010 Plan remains to be
 recorded. That cost is expected to be recorded over an estimated
 amortization period of 1.30 years.

[0001193125-14-184830:notes:116]
[same as prior period, unchanged from 0001193125-14-034881:notes:105]

[0001193125-14-184830:notes:117]
Restricted
 share units are one type of share-based award that may be granted
 under the 2010 Plan. Restricted share units granted to non-employee
 directors generally cliff vest 100% on the first of January,
 following the next annual meeting of shareholders, approximately
 one year from the grant date, provided the director continues to
 serve through such date. Restricted share units granted to
 employees generally vest in four equal installments over four years
 on each anniversary of the vesting commencement date.

[0001193125-14-184830:notes:118]
[same as prior period, unchanged from 0001193125-14-034881:notes:107]

[0001193125-14-184830:notes:119]
|  |  | Number of Shares Underlying Restricted Share Units |  |  | Weighted-Average Grant Date Fair Value Per Share |  |
|  |  | Nine Months Ended |  |  | Nine Months Ended |  |
|  |  | March 28, 2014 |  |  | March 29, 2013 |  |  | March 28, 2014 |  |  | March 29, 2013 |  |
| Unvested balance at beginning of the period |  |  | 545,668 |  |  |  | 168,275 |  |  | $ | 12.81 |  |  | $ | 14.44 |  |
| Granted |  |  | 475,838 |  |  |  | 453,110 |  |  |  | 15.31 |  |  |  | 12.38 |  |
| Issued |  |  | (170,468 | ) |  |  | (70,313 | ) |  |  | 12.93 |  |  |  | 14.13 |  |
| Forfeited |  |  | (12,404 | ) |  |  | (4,325 | ) |  |  | 14.60 |  |  |  | 13.12 |  |
| Unvested balance at end of the period |  |  | 838,634 |  |  |  | 546,747 |  |  | $ | 14.18 |  |  | $ | 12.78 |  |

[0001193125-14-184830:notes:120]
As of
 March 28, 2014, $6,214 of estimated share-based compensation
 expense related to restricted share units under the 2010 Plan
 remains to be recorded. That cost is expected to be recorded over
 an estimated amortization period of 2.99 years.

[0001193125-14-184830:notes:121]
For the nine
 months ended March 28, 2014, the Company withheld an aggregate
 of 12,143 shares upon the vesting of restricted share units, based
 upon the closing share price on the vesting date to settle the
 employees’ minimum statutory obligation for the applicable
 income and other employment taxes. During the nine months ended
 March 28, 2014, the Company then remitted cash of $198 to the
 appropriate taxing authorities, and presented it in a financing
 activity within the condensed consolidated statements of cash
 flows. The payment had the effect on shares issued by the Company
 as it reduced the number of shares that would have been issued on
 the vesting date and was recorded as a reduction of additional
 paid-in capital.


## us-gaap:RevenueFromExternalCustomersByGeographicAreasTableTextBlock

[0001193125-14-184830:notes:122]
The following
 tables present total revenues by geographic regions:

[0001193125-14-184830:notes:123]
|  |  | Three Months Ended |  |
|  |  | March 28, 2014 |  |  | March 29, 2013 |  |
| North America |  | $ | 84,842 |  |  | $ | 72,333 |  |
| Asia-Pacific |  |  | 53,680 |  |  |  | 52,627 |  |
| Europe |  |  | 29,135 |  |  |  | 30,597 |  |
|  |  | $ | 167,657 |  |  | $ | 155,557 |  |
|  |  | Nine Months Ended |  |
|  |  | March 28, 2014 |  |  | March 29, 2013 |  |
| North America |  | $ | 247,993 |  |  | $ | 225,084 |  |
| Asia-Pacific |  |  | 171,373 |  |  |  | 163,371 |  |
| Europe |  |  | 98,404 |  |  |  | 93,153 |  |
|  |  | $ | 517,770 |  |  | $ | 481,608 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-14-184830:notes:124]
[same as prior period, unchanged from 0001193125-14-034881:notes:114]

[0001193125-14-184830:notes:125]
Operating
 segments are defined as components of an enterprise for which
 separate financial information is available that is evaluated
 regularly by the chief operating decision maker in deciding how to
 allocate resources and in assessing performance. The
 Company’s chief operating decision maker is Fabrinet’s
 chief executive officer. As of March 28, 2014, the Company
 operated and internally managed a single operating segment.
 Accordingly, the Company does not accumulate discrete information
 with respect to separate product lines and does not have separate
 reportable segments.

[0001193125-14-184830:notes:126]
The Company
 operates primarily in three geographic regions: North America,
 Asia-Pacific and Europe. The following tables present total
 revenues by geographic regions:

[0001193125-14-184830:notes:127]
Total revenues
 are attributed to a particular geographic area based on the bill-to
 location of the customer. As of March 28, 2014, the Company
 had approximately $311 of long-lived assets based in North America,
 with the substantial remainder of assets based in
 Asia-Pacific.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-14-184830:notes:128]
| 12. |  | Commitments and contingencies |

[0001193125-14-184830:notes:129]
Bank
 guarantees

[0001193125-14-184830:notes:130]
As of
 March 28, 2014 and June 28, 2013, there were outstanding
 bank guarantees given by banks on behalf of Fabrinet Thailand for
 electricity usage and other normal business amounting to $322 and
 $336, respectively.

[0001193125-14-184830:notes:131]
Operating
 lease commitments

[0001193125-14-184830:notes:132]
The Company
 leases a portion of certain land and buildings for its facilities
 in China and New Jersey, under operating lease arrangements that
 expire in various calendar years through 2020. Rental expense under
 these operating leases amounted to $667 and $585 for the nine
 months ended March 28, 2014 and March 29, 2013,
 respectively.

[0001193125-14-184830:notes:133]
Purchase
 obligations

[0001193125-14-184830:notes:134]
Purchase
 obligations represent legally-binding commitments to purchase
 inventory and other commitments made in the normal course of
 business to meet operational requirements. Although open purchase
 orders are considered enforceable and legally binding, their terms
 generally give the Company the option to cancel, reschedule and/or
 adjust its requirements based on its business needs prior to the
 delivery of goods or performance of services. Obligations to
 purchase inventory and other commitments are generally expected to
 be fulfilled within one year.

[0001193125-14-184830:notes:135]
As of
 March 28, 2014, there were no outstanding capital expenditure
 commitments.

[0001193125-14-184830:notes:136]
Indemnification of directors and
 officers

[0001193125-14-184830:notes:137]
Cayman Islands
 law does not limit the extent to which a company’s memorandum
 and articles of association may provide for indemnification of
 directors and officers, except to the extent any such provision may
 be held by the Cayman Islands courts to be contrary to public
 policy, such as to provide indemnification against civil fraud or
 the consequences of committing a crime. Fabrinet’s amended
 and restated memorandum and articles of association provide for
 indemnification of directors and officers for actions, costs,
 charges, losses, damages and expenses incurred in their capacities
 as such, except that such indemnification does not extend to any
 matter in respect of any fraud or dishonesty that may attach to any
 of them.

[0001193125-14-184830:notes:138]
In accordance
 with Fabrinet’s form of indemnification agreement for its
 directors and officers, Fabrinet has agreed to indemnify its
 directors and officers against certain liabilities and expenses
 incurred by such persons in connection with claims by reason of
 their being such a director or officer. Fabrinet maintains a
 director and officer liability insurance policy that may enable it
 to recover a portion of any future amounts paid under the
 indemnification agreements.

[0001193125-14-184830:notes:139]
Contingent
 liability

[0001193125-14-184830:notes:140]
In the first
 week of October 2013, the Company authorized a customer to return a
 number of units of its product manufactured at the Company’s
 Pinehurst facility, due to functional failure. After investigation,
 the Company found that the affected products were produced during
 the first quarter of fiscal 2014. On March 28, 2014, the
 Company entered into a settlement agreement with the customer for
 the losses as a result of the product failure. The settled amount
 was $487 and recorded in the nine months ended March 28,
 2014.


## fn:AllowanceForDoubtfulAccountsTextBlock

[0001193125-14-184830:notes:141]
[same as prior period, unchanged from 0001193125-14-034881:notes:130]
