# FN 8-K — 0001193125-14-182534 filed 2014-05-05

## item codes, every 8-K on or before 2014-05-06

- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2014-05-06

- none on or before 2014-05-06

## item 2.02 — earnings release, exhibit 99.1

[0001193125-14-182534:8k_2_02:1]
EX-99.1
2
d721108dex991.htm
EX-99.1

[0001193125-14-182534:8k_2_02:2]
EX-99.1

[0001193125-14-182534:8k_2_02:3]
Exhibit 99.1

[0001193125-14-182534:8k_2_02:4]
Fabrinet Announces Third Quarter 2014 Financial Results

[0001193125-14-182534:8k_2_02:5]
BANGKOK, Thailand – May 5, 2014 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical,
electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for the third quarter ended March 28, 2014.

[0001193125-14-182534:8k_2_02:6]
Fabrinet reported total revenue of $167.7 million for the third quarter of fiscal 2014, an increase of 7.8% compared to total revenue of $155.6 million for
the comparable period in fiscal 2013. GAAP net income for the third quarter of fiscal 2014 was $47.7 million, or $1.33 per diluted share, compared to GAAP net income of $21.1 million, or $0.61 per diluted share, in the third quarter of fiscal 2013.
Non-GAAP net income in the third quarter of fiscal 2014 was $12.3 million, or $0.34 per diluted share, an increase of 6.6% compared to non-GAAP net income of $11.5 million, or $0.33 per diluted share, in the same period a year ago.

[0001193125-14-182534:8k_2_02:7]
Tom Mitchell, Chief Executive Officer of Fabrinet, said, “The third quarter was another period of solid execution for the company, with revenue and
non-GAAP earnings per share demonstrating growth over the prior year. With industry demand showing signs of improving, I am confident that we will continue to execute on our vision of providing world-class service to our customers and delivering
profitable growth for our shareholders.”

[0001193125-14-182534:8k_2_02:8]
Business Outlook

[0001193125-14-182534:8k_2_02:9]
Based on information available as of May 5, 2014, Fabrinet is issuing guidance for the fourth quarter of fiscal 2014 as follows:

[0001193125-14-182534:8k_2_02:10]
Fabrinet expects fourth quarter revenue to be in the range of $169 million to $173 million. GAAP net income per share is expected to be in the range of $0.29
to $0.31 with expected non-GAAP net income per share of $0.33 to $0.35, based on approximately 36 million fully diluted shares outstanding.

[0001193125-14-182534:8k_2_02:11]
Conference Call Information

[0001193125-14-182534:8k_2_02:12]
| What: |  | Fabrinet Third Quarter 2014 Financial Results Conference Call |
| When: |  | Monday, May 5, 2014 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic |
|  |  | (253) 237-1137, international |
|  |  | Passcode: 27086704 |
| Replay: |  | (855) 859-2056, domestic |
|  |  | (404) 537-3406, international |
|  |  | Passcode: 27086704 |
| Webcast: |  | http://investor.fabrinet.com (live and replay) |

[0001193125-14-182534:8k_2_02:13]
This press release and any other information related to the call will also be posted on Fabrinet’s website at
http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-14-182534:8k_2_02:14]
Investor Conferences

[0001193125-14-182534:8k_2_02:15]
Management will be presenting at
the JP Morgan TMT Conference in Boston on Monday, May 19, 2014.

[0001193125-14-182534:8k_2_02:16]
About Fabrinet

[0001193125-14-182534:8k_2_02:17]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original
equipment manufacturers of complex products, such as optical communication components, modules and subsystems, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire
manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and test. Fabrinet focuses on production of high complexity products in any mix and any volume.
Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the People’s Republic of China and the United States. For more information visit: www.fabrinet.com.

[0001193125-14-182534:8k_2_02:18]
Forward-Looking Statements

[0001193125-14-182534:8k_2_02:19]
Use of Non-GAAP Financials

[0001193125-14-182534:8k_2_02:20]
The Company refers to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information
regarding the Company’s ongoing operational performance. Non-GAAP net income excludes share-based compensation expenses, income related to flooding, executive separation costs and follow-on offering expenses. We have excluded these items in
order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP
financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001193125-14-182534:8k_2_02:21]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our
competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure company
performance for the purposes of determining employee incentive plan compensation.

[0001193125-14-182534:8k_2_02:22]
SOURCE: Fabrinet

[0001193125-14-182534:8k_2_02:23]
Investor Contact:

[0001193125-14-182534:8k_2_02:24]
Jennifer Predmore

[0001193125-14-182534:8k_2_02:25]
215-428-1797

[0001193125-14-182534:8k_2_02:26]
ir@fabrinet.com

[0001193125-14-182534:8k_2_02:27]
Fabrinet

[0001193125-14-182534:8k_2_02:28]
Consolidated Balance Sheets

[0001193125-14-182534:8k_2_02:29]
As of March 28, 2014
and June 28, 2013

[0001193125-14-182534:8k_2_02:30]
| (in thousands of U.S. dollars, except share data) |  | March 28,2014 |  |  | June 28,2013 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 233,664 |  |  | $ | 149,716 |  |
| Trade accounts receivable, net |  |  | 118,500 |  |  |  | 118,475 |  |
| Inventory, net |  |  | 107,826 |  |  |  | 88,962 |  |
| Deferred tax assets |  |  | 1,779 |  |  |  | 1,937 |  |
| Prepaid expenses |  |  | 2,097 |  |  |  | 1,931 |  |
| Other current assets |  |  | 2,357 |  |  |  | 3,505 |  |
| Total current assets |  |  | 466,223 |  |  |  | 364,526 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 98,782 |  |  |  | 97,206 |  |
| Intangibles, net |  |  | 93 |  |  |  | 164 |  |
| Deferred tax assets |  |  | 2,905 |  |  |  | 2,905 |  |
| Deposits and other non-current assets |  |  | 91 |  |  |  | 107 |  |
| Total non-current assets |  |  | 101,871 |  |  |  | 100,382 |  |
| Total assets |  | $ | 568,094 |  |  | $ | 464,908 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Long-term loans from bank, current portion |  | $ | 9,660 |  |  | $ | 9,668 |  |
| Trade accounts payable |  |  | 101,531 |  |  |  | 77,139 |  |
| Income tax payable |  |  | 699 |  |  |  | 1,825 |  |
| Deferred tax liability |  |  | 2,191 |  |  |  | 2,481 |  |
| Accrued payroll, bonus and related expenses |  |  | 9,182 |  |  |  | 6,220 |  |
| Accrued expenses |  |  | 3,872 |  |  |  | 3,121 |  |
| Other payables |  |  | 8,834 |  |  |  | 5,163 |  |
| Liabilities to third parties due to flood losses |  |  | — |  |  |  | 9,812 |  |
| Total current liabilities |  |  | 135,969 |  |  |  | 115,429 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term loans from bank, non-current portion |  |  | 12,000 |  |  |  | 19,243 |  |
| Severance liabilities |  |  | 4,539 |  |  |  | 4,382 |  |
| Other non-current liabilities |  |  | 573 |  |  |  | 536 |  |
| Total non-current liabilities |  |  | 17,112 |  |  |  | 24,161 |  |
| Total liabilities |  |  | 153,081 |  |  |  | 139,590 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of March 28, 2014 and June 28, 2013) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 35,104,766 shares and 34,634,967 shares issued and outstanding as of March 28, 2014 and June 28, 2013, respectively) |  |  | 351 |  |  |  | 346 |  |
| Additional paid-in capital |  |  | 79,393 |  |  |  | 71,101 |  |
| Retained earnings |  |  | 335,269 |  |  |  | 253,871 |  |
| Total shareholders’ equity |  |  | 415,013 |  |  |  | 325,318 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 568,094 |  |  | $ | 464,908 |  |

[0001193125-14-182534:8k_2_02:31]
Fabrinet

[0001193125-14-182534:8k_2_02:32]
Consolidated Statements of Operations

[0001193125-14-182534:8k_2_02:33]
For the three
and nine months ended March 28, 2014 and March 29, 2013

[0001193125-14-182534:8k_2_02:34]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (in thousands of U.S. dollars, except share data) |  | March28,2014 |  |  | March29,2013 |  |  | March28,2014 |  |  | March29,2013 |  |
| Revenues |  | $ | 167,657 |  |  | $ | 155,557 |  |  | $ | 517,770 |  |  | $ | 481,608 |  |
| Cost of revenues |  |  | (150,374 | ) |  |  | (139,302 | ) |  |  | (461,312 | ) |  |  | (429,261 | ) |
| Gross profit |  |  | 17,283 |  |  |  | 16,255 |  |  |  | 56,458 |  |  |  | 52,347 |  |
| Selling, general and administrative expenses |  |  | (7,352 | ) |  |  | (6,801 | ) |  |  | (20,959 | ) |  |  | (18,447 | ) |
| Income related to flooding, net |  |  | 38,151 |  |  |  | 11,419 |  |  |  | 44,748 |  |  |  | 21,064 |  |
| Operating income |  |  | 48,082 |  |  |  | 20,873 |  |  |  | 80,247 |  |  |  | 54,964 |  |
| Interest income |  |  | 560 |  |  |  | 302 |  |  |  | 1,262 |  |  |  | 761 |  |
| Interest expense |  |  | (172 | ) |  |  | (239 | ) |  |  | (566 | ) |  |  | (788 | ) |
| Foreign exchange (loss) gain, net |  |  | (254 | ) |  |  | 978 |  |  |  | 46 |  |  |  | 1,085 |  |
| Other income |  |  | 173 |  |  |  | 139 |  |  |  | 544 |  |  |  | 512 |  |
| Income before income taxes |  |  | 48,389 |  |  |  | 22,053 |  |  |  | 81,533 |  |  |  | 56,534 |  |
| Income tax expense |  |  | (727 | ) |  |  | (927 | ) |  |  | (135 | ) |  |  | (2,707 | ) |
| Net income |  | $ | 47,662 |  |  | $ | 21,126 |  |  | $ | 81,398 |  |  | $ | 53,827 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 1.36 |  |  | $ | 0.61 |  |  | $ | 2.33 |  |  | $ | 1.56 |  |
| Diluted |  | $ | 1.33 |  |  | $ | 0.61 |  |  | $ | 2.29 |  |  | $ | 1.55 |  |
| Weighted average number of ordinary shares outstanding |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (thousands of shares) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 35,078 |  |  |  | 34,596 |  |  |  | 34,878 |  |  |  | 34,532 |  |
| Diluted |  |  | 35,790 |  |  |  | 34,909 |  |  |  | 35,504 |  |  |  | 34,794 |  |

[0001193125-14-182534:8k_2_02:35]
Fabrinet

[0001193125-14-182534:8k_2_02:36]
Consolidated Statements of Cash Flows

[0001193125-14-182534:8k_2_02:37]
For the nine
months ended March 28, 2014 and March 29, 2013

[0001193125-14-182534:8k_2_02:38]
|  |  | Nine Months Ended |  |
| (in thousands of U. S. dollars) |  | March 28,2014 |  |  | March 29,2013 |  |
| Cash flows from operating activities |  |
| Net income for the period |  | $ | 81,398 |  |  | $ | 53,827 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 7,685 |  |  |  | 7,512 |  |
| Amortization of intangibles |  |  | 72 |  |  |  | 185 |  |
| Gain on disposal of property, plant and equipment |  |  | (1 | ) |  |  | (23 | ) |
| Income related to flooding |  |  | (45,211 | ) |  |  | (21,064 | ) |
| Proceeds from insurers for business interruption losses related to flooding |  |  | — |  |  |  | 4,741 |  |
| Proceeds from insurers for inventory losses related to flooding |  |  | 7,416 |  |  |  | 11,419 |  |
| Reversal of allowance for doubtful accounts |  |  | (62 | ) |  |  | (94 | ) |
| Unrealized loss (gain) on exchange rate and fair value of derivative |  |  | 1,027 |  |  |  | (1,566 | ) |
| Share-based compensation |  |  | 4,538 |  |  |  | 3,969 |  |
| Deferred income tax |  |  | (132 | ) |  |  | 1,615 |  |
| Other non-cash expenses |  |  | 255 |  |  |  | 598 |  |
| Reversal of uncertain tax positions |  |  | (1,538 | ) |  |  | — |  |
| Inventory obsolescence (reversal of) |  |  | 673 |  |  |  | (589 | ) |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | 37 |  |  |  | 3,421 |  |
| Inventory |  |  | (19,537 | ) |  |  | 8,945 |  |
| Other current assets and non-current assets |  |  | (889 | ) |  |  | (2,775 | ) |
| Trade accounts payable |  |  | 24,392 |  |  |  | (11,671 | ) |
| Income tax payable |  |  | 351 |  |  |  | 818 |  |
| Other current liabilities and non-current liabilities |  |  | 5,642 |  |  |  | 48 |  |
| Liabilities to third parties due to flood losses |  |  | (7,512 | ) |  |  | (8,059 | ) |
| Net cash provided by operating activities |  |  | 58,604 |  |  |  | 51,257 |  |
| Cash flows from investing activities |  |  |  |  |  |
| Purchase of property, plant and equipment |  |  | (7,280 | ) |  |  | (8,634 | ) |
| Purchase of Intangibles |  |  | (1 | ) |  |  | (1 | ) |
| Proceeds from disposal of property, plant and equipment |  |  | 1 |  |  |  | 25 |  |
| Proceeds from insurers in settlement of claims related to flood damage |  |  | 37,795 |  |  |  | 4,904 |  |
| Net cash provided by (used in) investing activities |  |  | 30,515 |  |  |  | (3,706 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Repayment of long-term loans from bank |  |  | (7,251 | ) |  |  | (7,251 | ) |
| Proceeds from issuance of ordinary shares under employee share option plans |  |  | 3,956 |  |  |  | 528 |  |
| Withholding tax related to net share settlement of restricted share units |  |  | (198 | ) |  |  | (21 | ) |
| Net cash used in financing activities |  |  | (3,493 | ) |  |  | (6,744 | ) |
| Net increase in cash and cash equivalents |  | $ | 85,626 |  |  | $ | 40,807 |  |

[0001193125-14-182534:8k_2_02:39]
Fabrinet

[0001193125-14-182534:8k_2_02:40]
Consolidated Statements of Cash Flows

[0001193125-14-182534:8k_2_02:41]
For the nine
months ended March 28, 2014 and March 29, 2013

[0001193125-14-182534:8k_2_02:42]
|  |  | Nine Months Ended |  |
| (in thousands of U.S. dollars) |  | March 28,2014 |  |  | March 29,2013 |  |
| Movement in cash and cash equivalents |  |  |  |  |  |  |  |  |
| Cash and cash equivalents at beginning of period |  | $ | 149,716 |  |  | $ | 115,507 |  |
| Increase in cash and cash equivalents |  |  | 85,626 |  |  |  | 40,807 |  |
| Effect of exchange rate on cash and cash equivalents |  |  | (1,678 | ) |  |  | 1,165 |  |
| Cash and cash equivalents at end of period |  | $ | 233,664 |  |  | $ | 157,479 |  |

[0001193125-14-182534:8k_2_02:43]
Fabrinet

[0001193125-14-182534:8k_2_02:44]
Reconciliation of GAAP measures to non-GAAP measures

[0001193125-14-182534:8k_2_02:45]
(in thousands of U.S. dollars, except per share data)

[0001193125-14-182534:8k_2_02:46]
(unaudited)

[0001193125-14-182534:8k_2_02:47]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 28, |  |  | March 28, |  |  | March 29, |  |  | March 29, |  |  | March 28, |  |  | March 28, |  |  | March 29, |  |  | March 29, |  |
|  |  | 2014 |  |  | 2014 |  |  | 2013 |  |  | 2013 |  |  | 2014 |  |  | 2014 |  |  | 2013 |  |  | 2013 |  |
|  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |
| GAAP measures |  |  | 47,662 |  |  |  | 1.33 |  |  |  | 21,126 |  |  |  | 0.61 |  |  |  | 81,398 |  |  |  | 2.29 |  |  |  | 53,827 |  |  |  | 1.55 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 290 |  |  |  | 0.01 |  |  |  | 275 |  |  |  | 0.01 |  |  |  | 888 |  |  |  | 0.03 |  |  |  | 919 |  |  |  | 0.03 |  |
| Total related to gross profit |  |  | 290 |  |  |  | 0.01 |  |  |  | 275 |  |  |  | 0.01 |  |  |  | 888 |  |  |  | 0.03 |  |  |  | 919 |  |  |  | 0.03 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,188 |  |  |  | 0.03 |  |  |  | 1,062 |  |  |  | 0.03 |  |  |  | 3,650 |  |  |  | 0.10 |  |  |  | 3,050 |  |  |  | 0.09 |  |
| Executive separation cost |  |  | 547 |  |  |  | 0.02 |  |  |  | — |  |  |  | — |  |  |  | 547 |  |  |  | 0.02 |  |  |  | — |  |  |  | — |  |
| Follow-on offering expenses |  |  | — |  |  |  | — |  |  |  | 472 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 472 |  |  |  | 0.01 |  |
| Total related to selling, general and administrative expenses |  |  | 1,735 |  |  |  | 0.05 |  |  |  | 1,534 |  |  |  | 0.04 |  |  |  | 4,197 |  |  |  | 0.12 |  |  |  | 3,522 |  |  |  | 0.10 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income related to flooding, net |  |  | (38,151 | ) |  |  | (1.07 | ) |  |  | (11,419 | ) |  |  | (0.32 | ) |  |  | (44,004 | ) |  |  | (1.24 | ) |  |  | (21,064 | ) |  |  | (0.60 | ) |
| Unrealized loss on exchange, net of interest income incurred from income related to flooding |  |  | 744 |  |  |  | 0.02 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total related to other incomes and other expenses |  |  | (37,407 | ) |  |  | (1.05 | ) |  |  | (11,419 | ) |  |  | (0.32 | ) |  |  | (44,004 | ) |  |  | (1.24 | ) |  |  | (21,064 | ) |  |  | (0.60 | ) |
| Related to income tax expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 907 |  |  |  | 0.03 |  |
| Total related to income tax expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 907 |  |  |  | 0.03 |  |
| Total related to net income & EPS |  |  | (35,382 | ) |  |  | (0.99 | ) |  |  | (9,610 | ) |  |  | (0.27 | ) |  |  | (38,919 | ) |  |  | (1.09 | ) |  |  | (15,716 | ) |  |  | (0.45 | ) |
| Non-GAAP measures |  |  | 12,280 |  |  |  | 0.34 |  |  |  | 11,516 |  |  |  | 0.33 |  |  |  | 42,479 |  |  |  | 1.20 |  |  |  | 38,111 |  |  |  | 1.08 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 35,790 |  |  |  |  |  |  |  | 34,909 |  |  |  |  |  |  |  | 35,504 |  |  |  |  |  |  |  | 34,794 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 35,790 |  |  |  |  |  |  |  | 35,225 |  |  |  |  |  |  |  | 35,504 |  |  |  |  |  |  |  | 35,132 |  |
