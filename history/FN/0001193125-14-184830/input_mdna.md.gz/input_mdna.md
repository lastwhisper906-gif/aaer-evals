# FN MD&A — 0001193125-14-184830


## mdna

[0001193125-14-184830:mdna:1]
[same as prior period, unchanged from 0001193125-14-034881:mdna:1]

[0001193125-14-184830:mdna:2]
[same as prior period, unchanged from 0001193125-14-034881:mdna:2]

[0001193125-14-184830:mdna:3]
[same as prior period, unchanged from 0001193125-14-034881:mdna:3]

[0001193125-14-184830:mdna:4]
|  | • |  | our expectation that the portion of our future revenues attributable to customers in regions outside of North America will remain flat as compared to the portion of our revenues that came from customers in regions outside of North America for the nine months ended March 28, 2014; |

[0001193125-14-184830:mdna:5]
[same as prior period, unchanged from 0001193125-14-034881:mdna:5]

[0001193125-14-184830:mdna:6]
[same as prior period, unchanged from 0001193125-14-034881:mdna:6]

[0001193125-14-184830:mdna:7]
|  | • |  | our expectation that our fiscal 2014 Selling, General and Administrative (SG&A) expenses will increase on an absolute dollar basis and remain flat as a percentage of revenue compared to fiscal 2013; |

[0001193125-14-184830:mdna:8]
[same as prior period, unchanged from 0001193125-14-034881:mdna:8]

[0001193125-14-184830:mdna:9]
[same as prior period, unchanged from 0001193125-14-034881:mdna:9]

[0001193125-14-184830:mdna:10]
[same as prior period, unchanged from 0001193125-14-034881:mdna:10]

[0001193125-14-184830:mdna:11]
[same as prior period, unchanged from 0001193125-14-034881:mdna:11]

[0001193125-14-184830:mdna:12]
[same as prior period, unchanged from 0001193125-14-034881:mdna:12]

[0001193125-14-184830:mdna:13]
[same as prior period, unchanged from 0001193125-14-034881:mdna:13]

[0001193125-14-184830:mdna:14]
[same as prior period, unchanged from 0001193125-14-034881:mdna:14]

[0001193125-14-184830:mdna:15]
[same as prior period, unchanged from 0001193125-14-034881:mdna:15]

[0001193125-14-184830:mdna:16]
[same as prior period, unchanged from 0001193125-14-034881:mdna:16]

[0001193125-14-184830:mdna:17]
[same as prior period, unchanged from 0001193125-14-034881:mdna:17]

[0001193125-14-184830:mdna:18]
[same as prior period, unchanged from 0001193125-14-034881:mdna:18]

[0001193125-14-184830:mdna:19]
[same as prior period, unchanged from 0001193125-14-034881:mdna:19]

[0001193125-14-184830:mdna:20]
[same as prior period, unchanged from 0001193125-14-034881:mdna:20]

[0001193125-14-184830:mdna:21]
[same as prior period, unchanged from 0001193125-14-034881:mdna:21]

[0001193125-14-184830:mdna:22]
[same as prior period, unchanged from 0001193125-14-034881:mdna:22]

[0001193125-14-184830:mdna:23]
[same as prior period, unchanged from 0001193125-14-034881:mdna:23]

[0001193125-14-184830:mdna:24]
[same as prior period, unchanged from 0001193125-14-034881:mdna:24]

[0001193125-14-184830:mdna:25]
We suspended production at all of our manufacturing facilities in Thailand from October 17, 2011 through November 14, 2011 because of severe flooding in Thailand. We never resumed, and have
permanently ceased, production at our Chokchai facility. We submitted claims for losses to our insurance companies, all of which have been settled as of March 28, 2014.

[0001193125-14-184830:mdna:26]
We recognized $38.6 million and $45.2 million as income related to flooding in the three and nine months ended March 28, 2014, respectively, towards full and final settlement of our owned and
consigned equipment and inventory claims. This income was offset by the recognition of $0.5 million of other expenses in connection with write-offs of advance payments to a customer due to flood losses.

[0001193125-14-184830:mdna:27]
In the three months ended March 29, 2013, we received an interim payment of $11.4 million from our insurers against our claims for
owned inventory losses. In the nine months ended March 29, 2013, we received an interim payment of $11.4 million from our insurers against our claims for owned inventory losses, an interim payment of $4.8 million from our insurers against our
claims for owned equipment losses, an interim payment of $4.7 million against our claims for business interruption losses and a payment of $0.1 million as full and final settlement of our claim for damage to our buildings at Pinehurst.

[0001193125-14-184830:mdna:28]
During the nine months ended March 28, 2014, we made a cash payment of $5.2 million and transferred equipment, with an aggregate
value of $2.3 million, to a customer towards full and final settlement for any and all flood-related losses to this customer in accordance with the settlement agreement entered into during fiscal 2013 with such customer. In addition, during the nine
months ended March 28, 2014, we fulfilled ours obligations to a customer’s insurers by making a payment of $2.2 million for full and final settlement of our liability to such insurer for damages to customer-owned inventory, which occurred
during the flooding in accordance with the settlement agreement entered into during fiscal 2013 with such insurer. We also made a cash payment of $0.1 million towards the other flood-related settlements during the nine months ended March 28,
2014.

[0001193125-14-184830:mdna:29]
During the nine months ended March 29, 2013, we entered into settlement agreements with
three of our customers relating to our liability for the customers’ losses as a result of the flooding and made an initial aggregate payment of $8.1 million to such customers.

[0001193125-14-184830:mdna:30]
[same as prior period, unchanged from 0001193125-14-034881:mdna:29]

[0001193125-14-184830:mdna:31]
Our total revenues increased by $12.1 million, or 7.8%, to $167.7
million for the three months ended March 28, 2014, as compared to $155.6 million for the three months ended March 29, 2013. Our total revenues increased by $36.2 million, or 7.5%, to $517.8 million for the nine months ended March 28,
2014, as compared to $481.6 million for the nine months ended March 29, 2013. The increases were primarily due to an increase in customers demand for our optical communications manufacturing services during the three and nine months ended
March 28, 2014.

[0001193125-14-184830:mdna:32]
We believe our ability to expand our relationships with existing customers and attract new customers is
due to a number of factors, including our broad range of complex engineering and manufacturing service offerings, flexible low-cost manufacturing platform, process optimization capabilities, advanced supply chain management, excellent customer
service and experienced management team. While we expect the prices we charge for the products we manufacture for our customers to decrease over time due in part to competitive market forces, we believe we will be able to maintain favorable pricing
for our services due to our ability to reduce cycle time, adjust our product mix by focusing on more complicated products, improve product quality and yields, and reduce material costs for the products we manufacture. We believe these capabilities
have enabled us to help our OEM customers reduce their manufacturing costs while maintaining or improving the design, quality, reliability and delivery times for their products.

[0001193125-14-184830:mdna:33]
[same as prior period, unchanged from 0001193125-14-034881:mdna:32]

[0001193125-14-184830:mdna:34]
We generate revenues from three geographic regions: North America, Asia-Pacific and Europe. Revenues are attributed to a particular geographic area based on the bill-to location of our customers,
notwithstanding that our customers may ultimately ship their products to end customers in a different geographic region. Virtually all of our revenues are derived from our manufacturing facilities in Asia-Pacific.

[0001193125-14-184830:mdna:35]
The percentage of our revenues generated from the bill-to location outside of North America decreased from 53.5% in the three months
ended March 29, 2013 to 49.4% in the three months ended March 28, 2014 and from 53.3% in the nine months ended March 29, 2013 to 52.1% in the nine months ended March 28, 2014, primarily as a result of an decrease in sales volume
attributable to our customers in regions outside of North America. We expect that the portion of our future revenues attributable to customers in regions outside North America will remain flat as compared to the nine months ended March 28,
2014.

[0001193125-14-184830:mdna:36]
The following table presents percentages of total revenues by geographic regions:

[0001193125-14-184830:mdna:37]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 28,2014 |  |  | March 29,2013 |  |  | March 28,2014 |  |  | March 29,2013 |  |
| North America |  |  | 50.6 | % |  |  | 46.5 | % |  |  | 47.9 | % |  |  | 46.7 | % |
| Asia-Pacific |  |  | 32.0 |  |  |  | 33.8 |  |  |  | 33.1 |  |  |  | 33.9 |  |
| Europe |  |  | 17.4 |  |  |  | 19.7 |  |  |  | 19.0 |  |  |  | 19.4 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-14-184830:mdna:38]
[same as prior period, unchanged from 0001193125-14-034881:mdna:37]

[0001193125-14-184830:mdna:39]
[same as prior period, unchanged from 0001193125-14-034881:mdna:38]

[0001193125-14-184830:mdna:40]
[same as prior period, unchanged from 0001193125-14-034881:mdna:39]

[0001193125-14-184830:mdna:41]
[same as prior period, unchanged from 0001193125-14-034881:mdna:40]

[0001193125-14-184830:mdna:42]
[same as prior period, unchanged from 0001193125-14-034881:mdna:41]

[0001193125-14-184830:mdna:43]
Our
infrastructure costs are comprised of depreciation, utilities, and facilities management and overhead costs. Most of our facility leases are long-term agreements. Our depreciation costs are comprised of buildings and fixed assets, primarily at our
Pinehurst campus in Thailand, and capital equipment located at each of our manufacturing locations.

[0001193125-14-184830:mdna:44]
During the three and nine
months ended March 28, 2014, discretionary merit-based bonus awards were made to our non-executive employees. Charges included in cost of revenues for bonus distributions to non-executive employees were $0.5 million and $0.5 million for the
three months ended March 28, 2014 and March 29, 2013, respectively, and $1.6 million and $1.5 million for the nine months ended March 28, 2014 and March 29, 2013, respectively.

[0001193125-14-184830:mdna:45]
Share-based compensation expense included in cost of revenues was $0.3 million and $0.3 million for the three months ended March 28,
2014 and March 29, 2013, respectively, and $0.9 million and $0.9 million for the nine months ended March 28, 2014 and March 29, 2013, respectively.

[0001193125-14-184830:mdna:46]
We expect to incur significant incremental costs of revenue as a result of our continued diversification into the industrial lasers and sensors markets and other end-markets outside of the optical
communications market or our further development of customized optics and glass manufacturing capabilities. We also expect to incur incremental costs of revenue as a result of our planned expansion into new geographic markets, though we are not able
to determine the amount of these incremental expenses.

[0001193125-14-184830:mdna:47]
Selling, General and Administrative Expenses

[0001193125-14-184830:mdna:48]
Our selling, general and administrative expenses, or SG&A expenses, primarily consist of corporate employee costs for sales and
marketing, general and administrative and other support personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation
expense, and other general expenses not related to cost of revenues. In fiscal 2014, we expect our SG&A expenses will increase on an absolute dollar basis and remain flat as a percentage of revenue compared to fiscal 2013.

[0001193125-14-184830:mdna:49]
The compensation committee of our board of directors approved a fiscal 2014 executive incentive plan with quantitative objectives, based
on achieving certain revenue and gross margin percentage targets for our fiscal year ending June 27, 2014, as well as qualitative objectives, based on achieving individual performance goals. Bonuses under our fiscal 2014 executive incentive
plan are payable after the end of fiscal 2014. In fiscal 2013, the compensation committee approved a fiscal 2013 executive incentive plan with quantitative objectives, based on achieving certain revenue and earnings per share targets for our fiscal
year ended June 28, 2013. No bonuses were earned under our fiscal 2013 executive incentive plan. However, the compensation committee awarded discretionary bonuses to our executive employees in the three months ended September 27, 2013.

[0001193125-14-184830:mdna:50]
Charges included in SG&A expenses for bonus distributions to non-executive and executive
employees were $0.7 million and $0.5 million for the three months ended March 28, 2014 and March 29, 2013, respectively, and $2.2 million and $1.1 million for the nine months ended March 28, 2014 and March 29, 2013, respectively.

[0001193125-14-184830:mdna:51]
Share-based compensation expense included in SG&A expenses was $1.2 million and $1.1 million for the three months ended
March 28, 2014 and March 29, 2013, respectively, and $3.7 million and $3.1 million for the nine months ended March 28, 2014 and March 29, 2013, respectively.

[0001193125-14-184830:mdna:52]
[same as prior period, unchanged from 0001193125-14-034881:mdna:51]

[0001193125-14-184830:mdna:53]
[same as prior period, unchanged from 0001193125-14-034881:mdna:52]

[0001193125-14-184830:mdna:54]
[same as prior period, unchanged from 0001193125-14-034881:mdna:53]

[0001193125-14-184830:mdna:55]
[same as prior period, unchanged from 0001193125-14-034881:mdna:54]

[0001193125-14-184830:mdna:56]
In addition, we are exposed to foreign exchange risk in connection with the credit facility and cross currency swap arrangements we
entered into with TMB Bank Public Company Limited (the “Bank”) in May 2011 for the construction of Pinehurst Building 6. The terms of the contract with the Bank provide the following facilities: (1) a term loan facility for up to Thai
baht 960 million (equal to $30.0 million) with a fixed interest rate of 5.28% per annum, (2) a hedging facility for currency interest rate swaps with a notional amount of $30.0 million, and (3) a settlement limit of Thai baht
65 million, subject to certain terms and conditions as set forth therein. As of March 30, 2012, we had drawn down the entire $30.0 million available under the term loan facility. Borrowings and interest under the term loan are scheduled to
be repaid on a quarterly basis between September 2011 and March 2017. As of March 28, 2014, we had outstanding borrowings under the term loan facility of $18.0 million. Under the terms of the cross currency swap arrangement, amounts drawn in
Thai baht were converted to U.S. dollars for repayment by us on a quarterly basis at the floating rate of 3-month U.S. LIBOR plus 2.8% per annum.

[0001193125-14-184830:mdna:57]
[same as prior period, unchanged from 0001193125-14-034881:mdna:56]

[0001193125-14-184830:mdna:58]
As of March 28, 2014 and June 28, 2013, we had outstanding foreign currency assets
and liabilities in Thai baht and RMB as follows:

[0001193125-14-184830:mdna:59]
|  |  | March 28, 2014 |  |  | June 28, 2013 |  |
|  |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
|  |  | (in thousands, except percentages) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,873,337 |  |  |  | 57,606 |  |  |  | 75.5 |  |  |  | 567,561 |  |  |  | 18,232 |  |  |  | 51.6 |  |
| RMB |  |  | 99,936 |  |  |  | 18,692 |  |  |  | 24.5 |  |  |  | 105,680 |  |  |  | 17,104 |  |  |  | 48.4 |  |
|  |  |  |  |  |  |  | 76,298 |  |  |  | 100.0 |  |  |  |  |  |  |  | 35,336 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 855,148 |  |  |  | 26,296 |  |  |  | 88.4 |  |  |  | 585,364 |  |  |  | 18,804 |  |  |  | 88.4 |  |
| RMB |  |  | 21,292 |  |  |  | 3,463 |  |  |  | 11.6 |  |  |  | 15,308 |  |  |  | 2,478 |  |  |  | 11.6 |  |
|  |  |  |  |  |  |  | 29,759 |  |  |  | 100.0 |  |  |  |  |  |  |  | 21,282 |  |  |  | 100.0 |  |

[0001193125-14-184830:mdna:60]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other
current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and
liabilities denominated in the same currency in accordance with management’s policy. As of March 28, 2014, there were $6.0 million in selling forward contracts and $23.0 million in put option contracts outstanding on the Thai baht payables
and as of June 28, 2013, there were $23.0 million in selling forward contracts and $5.0 million in put option contracts outstanding on the Thai baht payables.

[0001193125-14-184830:mdna:61]
The RMB assets represent cash and cash equivalents, accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses and other payables. As of
March 28, 2014 and June 28, 2013, we did not have any selling RMB to U.S. dollar forward contracts.

[0001193125-14-184830:mdna:62]
As of
March 28, 2014, unrealized loss from the fair market value of derivatives amounted to $0.1 million, and as of June 28, 2013, unrealized gain from the fair market value of derivatives amounted to $0.8 million.

[0001193125-14-184830:mdna:63]
[same as prior period, unchanged from 0001193125-14-034881:mdna:62]

[0001193125-14-184830:mdna:64]
[same as prior period, unchanged from 0001193125-14-034881:mdna:63]

[0001193125-14-184830:mdna:65]
[same as prior period, unchanged from 0001193125-14-034881:mdna:64]

[0001193125-14-184830:mdna:66]
[same as prior period, unchanged from 0001193125-14-034881:mdna:65]

[0001193125-14-184830:mdna:67]
|  | • |  | Notice on Perfecting Practices Concerning Foreign Exchange Settlement Regarding the Capital Contribution by Foreign-invested Enterprises, as promulgated by the State Administration of Foreign Exchange, or State Administration of Foreign Exchange (SAFE), on August 29, 2008, or Circular 142. |

[0001193125-14-184830:mdna:68]
[same as prior period, unchanged from 0001193125-14-034881:mdna:67]

[0001193125-14-184830:mdna:69]
[same as prior period, unchanged from 0001193125-14-034881:mdna:68]

[0001193125-14-184830:mdna:70]
[same as prior period, unchanged from 0001193125-14-034881:mdna:69]

[0001193125-14-184830:mdna:71]
[same as prior period, unchanged from 0001193125-14-034881:mdna:70]

[0001193125-14-184830:mdna:72]
[same as prior period, unchanged from 0001193125-14-034881:mdna:71]

[0001193125-14-184830:mdna:73]
[same as prior period, unchanged from 0001193125-14-034881:mdna:72]

[0001193125-14-184830:mdna:74]
[same as prior period, unchanged from 0001193125-14-034881:mdna:73]

[0001193125-14-184830:mdna:75]
[same as prior period, unchanged from 0001193125-14-034881:mdna:74]

[0001193125-14-184830:mdna:76]
[same as prior period, unchanged from 0001193125-14-034881:mdna:75]

[0001193125-14-184830:mdna:77]
[same as prior period, unchanged from 0001193125-14-034881:mdna:76]

[0001193125-14-184830:mdna:78]
[same as prior period, unchanged from 0001193125-14-034881:mdna:77]

[0001193125-14-184830:mdna:79]
[same as prior period, unchanged from 0001193125-14-034881:mdna:78]

[0001193125-14-184830:mdna:80]
Our critical accounting policies are disclosed in our Annual Report on Form 10-K for the fiscal year ended June 28, 2013. There were no material changes to our critical accounting policies during the
three and nine months ended March 28, 2014.

[0001193125-14-184830:mdna:81]
[same as prior period, unchanged from 0001193125-14-034881:mdna:80]

[0001193125-14-184830:mdna:82]
[same as prior period, unchanged from 0001193125-14-034881:mdna:81]

[0001193125-14-184830:mdna:83]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 28,2014 |  |  | March 29,2013 |  |  | March 28,2014 |  |  | March 29,2013 |  |
|  |  | (in thousands) |  |
| Revenues |  | $ | 167,657 |  |  | $ | 155,557 |  |  | $ | 517,770 |  |  | $ | 481,608 |  |
| Cost of revenues |  |  | (150,374 | ) |  |  | (139,302 | ) |  |  | (461,312 | ) |  |  | (429,261 | ) |
| Gross profit |  |  | 17,283 |  |  |  | 16,255 |  |  |  | 56,458 |  |  |  | 52,347 |  |
| Selling, general and administrative expenses |  |  | (7,352 | ) |  |  | (6,801 | ) |  |  | (20,959 | ) |  |  | (18,447 | ) |
| Income related to flooding, net |  |  | 38,151 |  |  |  | 11,419 |  |  |  | 44,748 |  |  |  | 21,064 |  |
| Operating income |  |  | 48,082 |  |  |  | 20,873 |  |  |  | 80,247 |  |  |  | 54,964 |  |
| Interest income |  |  | 560 |  |  |  | 302 |  |  |  | 1,262 |  |  |  | 761 |  |
| Interest expense |  |  | (172 | ) |  |  | (239 | ) |  |  | (566 | ) |  |  | (788 | ) |
| Foreign exchange (loss) gain, net |  |  | (254 | ) |  |  | 978 |  |  |  | 46 |  |  |  | 1,085 |  |
| Other income |  |  | 173 |  |  |  | 139 |  |  |  | 544 |  |  |  | 512 |  |
| Income before income taxes |  |  | 48,389 |  |  |  | 22,053 |  |  |  | 81,533 |  |  |  | 56,534 |  |
| Income tax expense |  |  | (727 | ) |  |  | (927 | ) |  |  | (135 | ) |  |  | (2,707 | ) |
| Net income |  | $ | 47,662 |  |  | $ | 21,126 |  |  | $ | 81,398 |  |  | $ | 53,827 |  |

[0001193125-14-184830:mdna:84]
[same as prior period, unchanged from 0001193125-14-034881:mdna:83]

[0001193125-14-184830:mdna:85]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 28,2014 |  |  | March 29,2013 |  |  | March 28,2014 |  |  | March 29,2013 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (89.7 | ) |  |  | (89.6 | ) |  |  | (89.1 | ) |  |  | (89.1 | ) |
| Gross profit |  |  | 10.3 |  |  |  | 10.4 |  |  |  | 10.9 |  |  |  | 10.9 |  |
| Selling, general and administrative expenses |  |  | (4.4 | ) |  |  | (4.4 | ) |  |  | (4.0 | ) |  |  | (3.8 | ) |
| Income related to flooding, net |  |  | 22.8 |  |  |  | 7.3 |  |  |  | 8.6 |  |  |  | 4.4 |  |
| Operating income |  |  | 28.7 |  |  |  | 13.4 |  |  |  | 15.5 |  |  |  | 11.4 |  |
| Interest income |  |  | 0.3 |  |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.2 |  |
| Interest expense |  |  | (0.1 | ) |  |  | (0.2 | ) |  |  | (0.1 | ) |  |  | (0.2 | ) |
| Foreign exchange (loss) gain, net |  |  | (0.2 | ) |  |  | 0.6 |  |  |  | 0.0 |  |  |  | 0.2 |  |
| Other income |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |
| Income before income taxes |  |  | 28.8 |  |  |  | 14.2 |  |  |  | 15.7 |  |  |  | 11.7 |  |
| Income tax expense |  |  | (0.4 | ) |  |  | (0.6 | ) |  |  | 0.0 |  |  |  | (0.6 | ) |
| Net income |  |  | 28.4 | % |  |  | 13.6 | % |  |  | 15.7 | % |  |  | 11.2 | % |

[0001193125-14-184830:mdna:86]
[same as prior period, unchanged from 0001193125-14-034881:mdna:85]

[0001193125-14-184830:mdna:87]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 28,2014 |  |  | March 29,2013 |  |  | March 28,2014 |  |  | March 29,2013 |  |
|  |  | (in thousands) |  |
| Optical communications |  | $ | 119,770 |  |  | $ | 108,214 |  |  | $ | 374,040 |  |  | $ | 337,715 |  |
| Lasers, sensors and other |  |  | 47,887 |  |  |  | 47,343 |  |  |  | 143,730 |  |  |  | 143,893 |  |
| Total |  | $ | 167,657 |  |  | $ | 155,557 |  |  | $ | 517,770 |  |  | $ | 481,608 |  |

[0001193125-14-184830:mdna:88]
[same as prior period, unchanged from 0001193125-14-034881:mdna:87]

[0001193125-14-184830:mdna:89]
28

[0001193125-14-184830:mdna:90]
Comparison of Three and Nine Months Ended March 28, 2014 to Three and Nine Months Ended
March 29, 2013

[0001193125-14-184830:mdna:91]
[same as prior period, unchanged from 0001193125-14-034881:mdna:90]

[0001193125-14-184830:mdna:92]
Our total revenues increased by $12.1 million, or 7.8%, to $167.7 million for the three months ended March 28, 2014, as compared to $155.6 million for the three months ended March 29, 2013. This
increase was primarily due to an increase in customers demand for our optical communications manufacturing services during the three months ended March 28, 2014. Revenues from optical communications products represented 71.4% of our total
revenues for the three months ended March 28, 2014, as compared to 69.6% for the three months ended March 29, 2013.

[0001193125-14-184830:mdna:93]
Our total revenues increased by $36.2 million, or 7.5%, to $517.8 million for the nine months ended March 28, 2014, as compared to
$481.6 million for the nine months ended March 29, 2013. This increase was primarily due to an increase in customer demand for our optical communications manufacturing services during the nine months ended March 28, 2014. Revenues from
optical communications products represented 72.2% of our total revenues for the nine months ended March 28, 2014, as compared to 70.1% for the nine months ended March 29, 2013.

[0001193125-14-184830:mdna:94]
[same as prior period, unchanged from 0001193125-14-034881:mdna:93]

[0001193125-14-184830:mdna:95]
Our cost of revenues increased by $11.1 million, or 8.0%, to $150.4 million, or 89.7% of total revenues, for the three months ended March 28, 2014, as compared to $139.3 million, or 89.6% of total
revenues, for the three months ended March 29, 2013. This increase was primarily due to an increase in production costs which were in-line with an increase in revenues during the three months ended March 28, 2014. Cost of revenues also
included share-based compensation expense of $0.3 million for the three months ended March 28, 2014, as compared to $0.3 million for the three months ended March 29, 2013.

[0001193125-14-184830:mdna:96]
Our cost of revenues increased by $32.1 million, or 7.5%, to $461.3 million, or 89.1% of total revenues, for the nine months ended
March 28, 2014, as compared to $429.3 million, or 89.1% of total revenues, for the nine months ended March 29, 2013. This increase was primarily due to an increase in production costs which were in-line with an increase in revenues during
the nine months ended March 28, 2014. Cost of revenues also included share-based compensation expense of $0.9 million for the nine months ended March 28, 2014, as compared to $0.9 million for the nine months ended March 29, 2013.

[0001193125-14-184830:mdna:97]
[same as prior period, unchanged from 0001193125-14-034881:mdna:96]

[0001193125-14-184830:mdna:98]
Our gross profit increased by $1.0 million, or 6.3%, to $17.3 million, or 10.3% of total revenues, for the three months ended March 28, 2014, as compared to $16.3 million, or 10.4% of total revenues,
for the three months ended March 29, 2013. Our gross profit increased by $4.1 million, or 7.9% to $56.5 million, or 10.9% of total revenues, for the nine months ended March 28, 2014, as compared to $52.3 million, or 10.9% of total
revenues, for the nine months ended March 29, 2013.

[0001193125-14-184830:mdna:99]
The slight decrease in gross profit margin during the three and nine
months ended March 28, 2014, as compared to the three and nine months ended March 29, 2013, was related to an increase in production costs during the three and nine months ended March 28, 2014.

[0001193125-14-184830:mdna:100]
[same as prior period, unchanged from 0001193125-14-034881:mdna:99]

[0001193125-14-184830:mdna:101]
Our SG&A expenses increased by $0.6 million, or 8.1%, to $7.4 million, or 4.4% of total revenues, for the three months ended March 28, 2014, as compared to $6.8 million, or 4.4% of total
revenues, for the three months ended March 29, 2013. Our SG&A expenses increased in absolute dollars and remained flat as a percentage of revenue due primarily to the $0.5 million in severance and related payments to an executive who left
the Company in March 2014. We also recorded share-based compensation charges of $1.2 million for the three months ended March 28, 2014, as compared to $1.1 million for the three months ended March 29, 2013.

[0001193125-14-184830:mdna:102]
Our SG&A expenses increased by $2.5 million, or 13.6%, to $21.0 million, or 4.1% of total revenues, for the nine months ended
March 28, 2014, as compared to $18.4 million, or 3.8% of total revenues, for the nine months ended March 29, 2013. Our SG&A expenses increased in absolute dollars and as a percentage of revenues due primarily to a $1.7 million increase in
accrued executive bonuses, salaries and other benefits and the recognition of $0.2 million in expenses in connection with our efforts to grow our business and the $0.5 million in severance and related payments to an executive who left from the
Company in March 2014, for the nine months ended March 28, 2014, as compared to the nine months ended March 29, 2013. We also recorded share-based compensation charges of $3.7 million for the nine months ended March 28, 2014, as
compared to $3.1 million for the nine months ended March 29, 2013.

[0001193125-14-184830:mdna:103]
[same as prior period, unchanged from 0001193125-14-034881:mdna:102]

[0001193125-14-184830:mdna:104]
In the three months ended March 28, 2014, we recognized income related to flooding of $38.6 million towards full and final settlement
of our owned and consigned equipment and inventory claims. This income was off-set by a recognition of $0.5 million of other expenses in connection with write-offs of advance payment to a customer due to flood losses. In the three months ended
March 29, 2013, we recognized income related to flooding of $11.4 million as a result of an interim payment from our insurers against our claim for owned inventory losses.

[0001193125-14-184830:mdna:105]
In the nine months ended March 28, 2014, we recognized income related to flooding of $45.2 million towards full and final settlement
of our owned and consigned equipment and inventory claims. This income was off-set by a recognition of $0.5 million of other expenses in connection with write-offs of advance payment to a customer due to flood losses. In the nine months ended
March 29, 2013, we recognized income related to flooding of $21.0 million, which consisted of an interim payment from our insurers of $11.4 million against our claims for owned inventory losses, an interim payment from our insurers of $4.8
million against our claims for owned equipment losses, an interim payment of $4.7 million against our claims for business interruption losses and a payment of $0.1 million in full and final settlement of our claim for damage to our buildings at
Pinehurst.

[0001193125-14-184830:mdna:106]
[same as prior period, unchanged from 0001193125-14-034881:mdna:105]

[0001193125-14-184830:mdna:107]
Our operating income increased by $27.2 million to $48.1 million, or 28.7% of total revenues, for the three months ended March 28, 2014, as compared to $20.9 million, or 13.4% of total revenues, for
the three months ended March 29, 2013.

[0001193125-14-184830:mdna:108]
Our operating income increased by $25.3 million to $80.2 million, or 15.5% of
total revenues, for the nine months ended March 28, 2014, as compared to $55.0 million, or 11.4% of total revenues, for the nine months ended March 29, 2013.

[0001193125-14-184830:mdna:109]
[same as prior period, unchanged from 0001193125-14-034881:mdna:108]

[0001193125-14-184830:mdna:110]
Our interest income increased by $0.3 million to $0.6
million for the three months ended March 28, 2014, as compared to $0.3 million for the three months ended March 29, 2013. Our interest income increased by $0.5 million to $1.3 million for the nine months ended March 28, 2014, as
compared to $0.8 million for the nine months ended March 29, 2013. This increase was due to increase in cash and cash equivalent balances and an increase in interest rates.

[0001193125-14-184830:mdna:111]
[same as prior period, unchanged from 0001193125-14-034881:mdna:110]

[0001193125-14-184830:mdna:112]
Our interest expense remained flat at $0.2 million for the three months ended March 28, 2014, as compared to $0.2 million for the three months ended March 29, 2013. Our interest expense
decreased by $0.2 million to $0.6 million for the nine months ended March 28, 2014, as compared to $0.8 million for the nine months ended March 29, 2013. This decrease was due to repayment of long-term loan balances during the period.

[0001193125-14-184830:mdna:113]
[same as prior period, unchanged from 0001193125-14-034881:mdna:112]

[0001193125-14-184830:mdna:114]
We recorded income before income taxes of $48.4 million and $81.5 million for the three and nine months ended March 28, 2014, respectively, as compared to income before income taxes of $22.1 million
and $56.5 million for the three and nine months ended March 29, 2013, respectively.

[0001193125-14-184830:mdna:115]
[same as prior period, unchanged from 0001193125-14-034881:mdna:114]

[0001193125-14-184830:mdna:116]
Our provision for income tax reflects an effective tax rate of 1.5% for the three months ended March 28, 2014, as
compared to an effective tax rate of 4.2% for the three months ended March 29, 2013. The decrease in effective tax rate for the three months ended March 28, 2014 was primarily due to the fact that we had a higher portion of net income
during the period, primarily from income related to flooding of $38.2 million that was not subject to income tax, as compared to the three months ended March 29, 2013.

[0001193125-14-184830:mdna:117]
Our provision for income tax reflects an effective tax rate of 0.2% for the nine months ended March 28, 2014, as compared to an effective tax rate of 4.8% for the nine months ended March 29,
2013. The decrease in effective tax rate for the nine months ended March 28, 2014 was primarily due to the reversal of liability for uncertain tax positions, including accrued interest of $1.5 million and increase in deferred tax assets of $0.6
million and the fact that we had a higher portion of net income during the period, primarily from income related to flooding of $44.7 million that was is not subject to income tax, as compared to the reversal of liability for uncertain tax positions
of $0.6 million for the nine months ended March 29, 2013.

[0001193125-14-184830:mdna:118]
[same as prior period, unchanged from 0001193125-14-034881:mdna:117]

[0001193125-14-184830:mdna:119]
We recorded net income of $47.7 million, or 28.4% of total revenues, for the three months ended March 28, 2014, as compared to $21.1 million, or 13.6% of total revenues, for the three months ended
March 29, 2013.

[0001193125-14-184830:mdna:120]
We recorded net income of $81.4 million, or 15.7% of total revenues, for the nine months ended
March 28, 2014, as compared to $53.8 million, or 11.2% of total revenues, for the nine months ended March 29, 2013.

[0001193125-14-184830:mdna:121]
Liquidity
and Capital Resources

[0001193125-14-184830:mdna:122]
[same as prior period, unchanged from 0001193125-14-034881:mdna:121]

[0001193125-14-184830:mdna:123]
We have primarily financed our operations through cash flow from operations. As of March 28, 2014, we had approximately $233.7
million in cash and cash equivalents and approximately $21.7 million of outstanding debt. As of March 29, 2013, we had approximately $157.5 million in cash and cash equivalents and approximately $31.3 million of outstanding debt.

[0001193125-14-184830:mdna:124]
Our cash and cash equivalents primarily consist of cash on hand, demand deposits and liquid investments with original maturities of three
months or less which are placed with banks and other financial institutions. The weighted average interest rate on our cash and cash equivalents was 1.1% and 1.0%, for the three and nine months ended March 28, 2014, respectively, and 0.9% and
0.9%, for the three and nine months ended March 29, 2013, respectively.

[0001193125-14-184830:mdna:125]
As of March 28, 2014, we submitted claims
for losses to our insurance companies for flood related losses, all of which have been settled as of March 28, 2014. We recognized $38.6 million and $45.2 million as income related to flooding in the three and nine months ended March 28,
2014, respectively, towards full and final settlement of our owned and consigned equipment and inventory claims. This income was offset by the recognition of $0.5 million of other expense in connection with write-offs of advance payments to a
customer due to flood losses.

[0001193125-14-184830:mdna:126]
In the three months ended March 29, 2013, we received an interim payment of $11.4 million
from its insurers against our claims for owned inventory losses. In the nine months ended March 29, 2013, we received an interim payment of $11.4 million from our insurers against our claims for owned inventory losses, an interim payment of
$4.8 million from our insurers against our claims for owned equipment losses, an interim payment of $4.7 million against our claims for business interruption losses and a payment of $0.1 million as full and final settlement of our claim for damage
to our buildings at Pinehurst.

[0001193125-14-184830:mdna:127]
During the nine months ended March 28, 2014, we made a cash payment of $5.2 million and
transferred equipment, with an aggregate value of $2.3 million, to a customer towards full and final settlement for any and all flood-related losses incurred by this customer in accordance with the settlement agreement entered into during fiscal
2013 with such customer. In addition, during the nine months ended March 28, 2014, we fulfilled our obligations to a customer’s insurers by making a payment of $2.2 million for full and final settlement of our liability to such insurer for
damages to customer-owned inventory, which occurred during the flooding in accordance with a settlement agreement entered into during fiscal 2013 with such insurer. We also made a cash payment of $0.1 million towards the other flood-related
settlements during the nine months ended March 28, 2014.

[0001193125-14-184830:mdna:128]
During the nine months ended March 29, 2013, we entered
into settlement agreements with three of our customers relating to our liability for the customers’ losses as a result of the flooding and made an initial aggregate payment of $8.1 million to such customers.

[0001193125-14-184830:mdna:129]
We believe that our current cash and cash equivalents, and cash flow from operations will be sufficient to meet our working capital and
capital expenditure needs for the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001193125-14-184830:mdna:130]
We believe that our current manufacturing capacity is sufficient to meet anticipated production requirements for at least the next 12
months. We maintain a long-term credit facility associated with construction of production facilities at our Pinehurst campus in Thailand that will come due within the next 36 months. We anticipate that our internally generated working capital,
along with our cash and cash equivalents will be adequate to repay this obligation.

[0001193125-14-184830:mdna:131]
[same as prior period, unchanged from 0001193125-14-034881:mdna:130]

[0001193125-14-184830:mdna:132]
|  |  | Nine Months Ended |  |
|  |  | March 28,2014 |  |  | March 29,2013 |  |
|  |  | (in thousands) |  |
| Net cash provided by operating activities |  | $ | 58,604 |  |  | $ | 51,257 |  |
| Net cash provided by (used in) investing activities |  |  | 30,515 |  |  |  | (3,706 | ) |
| Net cash used in financing activities |  |  | (3,493 | ) |  |  | (6,744 | ) |
| Net increase in cash and cash equivalents |  |  | 85,626 |  |  |  | 40,807 |  |
| Cash and cash equivalents, beginning of period |  |  | 149,716 |  |  |  | 115,507 |  |
| Cash and cash equivalents, end of period |  |  | 233,664 |  |  |  | 157,479 |  |

[0001193125-14-184830:mdna:133]
[same as prior period, unchanged from 0001193125-14-034881:mdna:132]

[0001193125-14-184830:mdna:134]
Net cash provided by operating activities increased by $7.3 million, or 14.3%, to $58.6 million for the nine months ended March 28, 2014, as compared to net cash provided by operating activities of
$51.3 million for the nine months ended March 29, 2013. This increase was primarily due to an increase in net income from operations and a decrease in cash payment to vendors which were offset by a decrease in proceeds from insurers for
business interruption and inventory losses related to flooding.

[0001193125-14-184830:mdna:135]
[same as prior period, unchanged from 0001193125-14-034881:mdna:134]

[0001193125-14-184830:mdna:136]
Net cash provided by investing activities increased by $34.2 million, or 923.4%, to $30.5 million for the nine months ended March 28,
2014, as compared to net cash used in investing activities $3.7 million for the nine months ended March 29, 2013. This increase in net cash provided by investing activities was primarily due to an increase in proceeds from insurers for
flood-related losses of equipment.

[0001193125-14-184830:mdna:137]
[same as prior period, unchanged from 0001193125-14-034881:mdna:136]

[0001193125-14-184830:mdna:138]
Net cash used in financing activities decreased by $3.3 million, or 48.2%, to $3.5 million for the nine months ended March 28, 2014,
as compared to $6.7 million for the nine months ended March 29, 2013. This decrease in net cash used in financing activities was primarily due to an increase in proceeds from employee share option exercises.

[0001193125-14-184830:mdna:139]
[same as prior period, unchanged from 0001193125-14-034881:mdna:138]

[0001193125-14-184830:mdna:140]
We have not entered into any financial guarantees or other commitments to guarantee the payment obligations of any third parties. In addition, we have not entered into any derivative contracts that are
not reflected in our condensed consolidated financial statements. Furthermore, we do not have any retained or contingent interest in assets transferred to an unconsolidated entity that serves as credit, liquidity or market risk support to such
entity. We also do not have any variable interest in any unconsolidated entity that provides financing, liquidity, market risk or credit support to us or engages in leasing, hedging or research and development services with us.

[0001193125-14-184830:mdna:141]
[same as prior period, unchanged from 0001193125-14-034881:mdna:140]

[0001193125-14-184830:mdna:142]
See Note 2 of Notes to Unaudited Condensed Consolidated Financial Statements for recent accounting pronouncements that could have an effect on us.
