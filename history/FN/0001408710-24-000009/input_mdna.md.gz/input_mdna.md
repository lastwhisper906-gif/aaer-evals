# FN MD&A — 0001408710-24-000009


## mdna

[0001408710-24-000009:mdna:1]
[same as prior period, unchanged from 0001408710-23-000036:mdna:1]

[0001408710-24-000009:mdna:2]
[same as prior period, unchanged from 0001408710-23-000036:mdna:2]

[0001408710-24-000009:mdna:3]
[same as prior period, unchanged from 0001408710-23-000036:mdna:3]

[0001408710-24-000009:mdna:4]
[same as prior period, unchanged from 0001408710-23-000036:mdna:4]

[0001408710-24-000009:mdna:5]
•our expectation that the portion of our revenues attributable to customers in regions outside of North America for the remainder of fiscal year 2024 will be in line with the portion of revenues attributable to such customers during the six months ended December 29, 2023;

[0001408710-24-000009:mdna:6]
[same as prior period, unchanged from 0001408710-23-000036:mdna:6]

[0001408710-24-000009:mdna:7]
[same as prior period, unchanged from 0001408710-23-000036:mdna:7]

[0001408710-24-000009:mdna:8]
[same as prior period, unchanged from 0001408710-23-000036:mdna:8]

[0001408710-24-000009:mdna:9]
[same as prior period, unchanged from 0001408710-23-000036:mdna:9]

[0001408710-24-000009:mdna:10]
[same as prior period, unchanged from 0001408710-23-000036:mdna:10]

[0001408710-24-000009:mdna:11]
[same as prior period, unchanged from 0001408710-23-000036:mdna:11]

[0001408710-24-000009:mdna:12]
[same as prior period, unchanged from 0001408710-23-000036:mdna:12]

[0001408710-24-000009:mdna:13]
[same as prior period, unchanged from 0001408710-23-000036:mdna:13]

[0001408710-24-000009:mdna:14]
[same as prior period, unchanged from 0001408710-23-000036:mdna:14]

[0001408710-24-000009:mdna:15]
[same as prior period, unchanged from 0001408710-23-000036:mdna:15]

[0001408710-24-000009:mdna:16]
[same as prior period, unchanged from 0001408710-23-000036:mdna:16]

[0001408710-24-000009:mdna:17]
[same as prior period, unchanged from 0001408710-23-000036:mdna:17]

[0001408710-24-000009:mdna:18]
•trends in the optical communications, automotive, and industrial lasers markets, including trends to outsource the production of components used in those markets;

[0001408710-24-000009:mdna:19]
[same as prior period, unchanged from 0001408710-23-000036:mdna:19]

[0001408710-24-000009:mdna:20]
[same as prior period, unchanged from 0001408710-23-000036:mdna:20]

[0001408710-24-000009:mdna:21]
[same as prior period, unchanged from 0001408710-23-000036:mdna:22]

[0001408710-24-000009:mdna:22]
We provide advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers (“OEMs”) of complex products, such as optical communication components, modules and sub-systems, automotive components, industrial lasers, medical devices and sensors. We offer a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, complex printed circuit board assembly, advanced packaging, integration, final assembly, and testing. We focus primarily on low-volume production of a wide variety of high complexity products, which we refer to as “low-volume, high-mix.” We also have the capability to accommodate high-volume production. Based on our extensive experience and the positive feedback we have received from our customers, we believe we are a global leader in providing these services to the optical communications, automotive, and industrial lasers markets.

[0001408710-24-000009:mdna:23]
Our customer base includes companies in complex industries that require advanced precision manufacturing capabilities such as optical communications, automotive, industrial lasers, and sensors. The products that we manufacture for our OEM customers include selective switching products; tunable lasers, transponders and transceivers; active optical cables; solid state, diode-pumped, gas and fiber lasers; and sensors. In many cases, we are the sole outsourced manufacturing partner used by our customers for the products that we manufacture for them.

[0001408710-24-000009:mdna:24]
[same as prior period, unchanged from 0001408710-23-000036:mdna:25]

[0001408710-24-000009:mdna:25]
[same as prior period, unchanged from 0001408710-23-000036:mdna:26]

[0001408710-24-000009:mdna:26]
[same as prior period, unchanged from 0001408710-23-000036:mdna:27]

[0001408710-24-000009:mdna:27]
[same as prior period, unchanged from 0001408710-23-000036:mdna:28]

[0001408710-24-000009:mdna:28]
[same as prior period, unchanged from 0001408710-23-000036:mdna:29]

[0001408710-24-000009:mdna:29]
We generate revenues from three geographic regions: North America, Asia-Pacific and others, and Europe. Revenues are attributed to a particular geographic area based on the bill-to location of our customers, notwithstanding that the products may be shipped to a different geographic region. The substantial majority of our revenues are derived from our manufacturing facilities in Asia-Pacific.

[0001408710-24-000009:mdna:30]
The percentage of our revenues generated from a bill-to location outside of North America increased from 51.5% in the three months ended December 30, 2022 to 66.1% in the three months ended December 29, 2023, primarily because of an increase in revenue from a customer in Israel and a decrease in sales to our customers in North America.

[0001408710-24-000009:mdna:31]
The percentage of our revenues generated from a bill-to location outside of North America increased from 49.2% in the six months ended December 30, 2022 to 64.2% in the six months ended December 29, 2023, primarily because of an increase in revenue from a customer in Israel and a decrease in sales to our customers in North America.

[0001408710-24-000009:mdna:32]
Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside North America for the remainder of fiscal year 2024 will be in line with the portion of revenues attributable to such customers during the six months ended December 29, 2023.

[0001408710-24-000009:mdna:33]
[same as prior period, unchanged from 0001408710-23-000036:mdna:33]

[0001408710-24-000009:mdna:34]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29, 2023 |  | December 30, 2022 |  | December 29, 2023 |  | December 30, 2022 |
| North America | 33.9 | % |  | 48.5 | % |  | 35.8 | % |  | 50.8 | % |
| Asia-Pacific and others | 60.3 |  |  | 43.1 |  |  | 57.3 |  |  | 40.5 |  |
| Europe | 5.8 |  |  | 8.4 |  |  | 6.9 |  |  | 8.7 |  |
|  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001408710-24-000009:mdna:35]
[same as prior period, unchanged from 0001408710-23-000036:mdna:35]

[0001408710-24-000009:mdna:36]
[same as prior period, unchanged from 0001408710-23-000036:mdna:36]

[0001408710-24-000009:mdna:37]
[same as prior period, unchanged from 0001408710-23-000036:mdna:37]

[0001408710-24-000009:mdna:38]
[same as prior period, unchanged from 0001408710-23-000036:mdna:38]

[0001408710-24-000009:mdna:39]
[same as prior period, unchanged from 0001408710-23-000036:mdna:39]

[0001408710-24-000009:mdna:40]
[same as prior period, unchanged from 0001408710-23-000036:mdna:40]

[0001408710-24-000009:mdna:41]
[same as prior period, unchanged from 0001408710-23-000036:mdna:41]

[0001408710-24-000009:mdna:42]
[same as prior period, unchanged from 0001408710-23-000036:mdna:42]

[0001408710-24-000009:mdna:43]
[same as prior period, unchanged from 0001408710-23-000036:mdna:43]

[0001408710-24-000009:mdna:44]
[same as prior period, unchanged from 0001408710-23-000036:mdna:44]

[0001408710-24-000009:mdna:45]
[same as prior period, unchanged from 0001408710-23-000036:mdna:45]

[0001408710-24-000009:mdna:46]
[same as prior period, unchanged from 0001408710-23-000036:mdna:46]

[0001408710-24-000009:mdna:47]
[same as prior period, unchanged from 0001408710-23-000036:mdna:47]

[0001408710-24-000009:mdna:48]
[same as prior period, unchanged from 0001408710-23-000036:mdna:48]

[0001408710-24-000009:mdna:49]
[same as prior period, unchanged from 0001408710-23-000036:mdna:49]

[0001408710-24-000009:mdna:50]
|  | As of December 29, 2023 |  | As of June 30, 2023 |
| (in thousands, except percentages) | ForeignCurrency |  | $ |  | % |  | ForeignCurrency |  | $ |  | % |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 894,290 |  |  | $ | 26,134 |  |  | 71.4 | % |  | 754,443 |  |  | $ | 21,198 |  |  | 60.9 | % |
| RMB | 41,864 |  |  | 5,911 |  |  | 16.1 |  |  | 66,501 |  |  | 9,203 |  |  | 26.4 |  |
| GBP | 3,578 |  |  | 4,584 |  |  | 12.5 |  |  | 3,487 |  |  | 4,401 |  |  | 12.7 |  |
| Total |  |  | $ | 36,629 |  |  | 100.0 | % |  |  |  | $ | 34,802 |  |  | 100.0 | % |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 3,479,164 |  |  | $ | 101,670 |  |  | 90.6 | % |  | 2,956,730 |  |  | $ | 83,078 |  |  | 88.8 | % |
| RMB | 74,691 |  |  | 10,546 |  |  | 9.4 |  |  | 74,652 |  |  | 10,331 |  |  | 11.0 |  |
| GBP | 34 |  |  | 43 |  |  | 0.0 |  |  | 114 |  |  | 144 |  |  | 0.2 |  |
| Total |  |  | $ | 112,259 |  |  | 100.0 | % |  |  |  | $ | 93,553 |  |  | 100.0 | % |

[0001408710-24-000009:mdna:51]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy As of December 29, 2023, there was $126.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 30, 2023, there was $143.0 million of foreign currency forward contracts outstanding on the Thai baht payables.

[0001408710-24-000009:mdna:52]
The RMB assets represent cash and cash equivalents, trade accounts receivable, and other receivables. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable, accrued payroll, bonus and related expenses and other payables. As of December 29, 2023 and June 30, 2023, we did not have any derivative contracts denominated in RMB.

[0001408710-24-000009:mdna:53]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable and other payables. As of December 29, 2023 and June 30, 2023, we did not have any derivative contracts denominated in GBP.

[0001408710-24-000009:mdna:54]
For the three months ended December 29, 2023 and December 30, 2022, we recorded a gain of $2.6 million and $4.2 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-24-000009:mdna:55]
For the six months ended December 29, 2023 and December 30, 2022, we recorded a gain of $2.9 million and $4.0 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-24-000009:mdna:56]
[same as prior period, unchanged from 0001408710-23-000036:mdna:55]

[0001408710-24-000009:mdna:57]
[same as prior period, unchanged from 0001408710-23-000036:mdna:56]

[0001408710-24-000009:mdna:58]
[same as prior period, unchanged from 0001408710-23-000036:mdna:57]

[0001408710-24-000009:mdna:59]
[same as prior period, unchanged from 0001408710-23-000036:mdna:58]

[0001408710-24-000009:mdna:60]
[same as prior period, unchanged from 0001408710-23-000036:mdna:59]

[0001408710-24-000009:mdna:61]
[same as prior period, unchanged from 0001408710-23-000036:mdna:60]

[0001408710-24-000009:mdna:62]
[same as prior period, unchanged from 0001408710-23-000036:mdna:61]

[0001408710-24-000009:mdna:63]
[same as prior period, unchanged from 0001408710-23-000036:mdna:62]

[0001408710-24-000009:mdna:64]
[same as prior period, unchanged from 0001408710-23-000036:mdna:63]

[0001408710-24-000009:mdna:65]
[same as prior period, unchanged from 0001408710-23-000036:mdna:80]

[0001408710-24-000009:mdna:66]
[same as prior period, unchanged from 0001408710-23-000036:mdna:64]

[0001408710-24-000009:mdna:67]
[same as prior period, unchanged from 0001408710-23-000036:mdna:65]

[0001408710-24-000009:mdna:68]
[same as prior period, unchanged from 0001408710-23-000036:mdna:66]

[0001408710-24-000009:mdna:69]
[same as prior period, unchanged from 0001408710-23-000036:mdna:67]

[0001408710-24-000009:mdna:70]
[same as prior period, unchanged from 0001408710-23-000036:mdna:68]

[0001408710-24-000009:mdna:71]
As of December 29, 2023, the corporate income tax rates for our subsidiaries in the PRC, the U.S., the U.K. and Israel are 25%, 21%, 25% and 23%, respectively.

[0001408710-24-000009:mdna:72]
[same as prior period, unchanged from 0001408710-23-000036:mdna:70]

[0001408710-24-000009:mdna:73]
[same as prior period, unchanged from 0001408710-23-000036:mdna:72]

[0001408710-24-000009:mdna:74]
[same as prior period, unchanged from 0001408710-23-000036:mdna:73]

[0001408710-24-000009:mdna:75]
Our critical accounting policies are disclosed in our Annual Report on Form 10-K for the fiscal year ended June 30, 2023. The adoption of new accounting policies and accounting standards are disclosed in Note 2 to the unaudited condensed consolidated financial statements. There were no changes to our accounting policies.

[0001408710-24-000009:mdna:76]
[same as prior period, unchanged from 0001408710-23-000036:mdna:75]

[0001408710-24-000009:mdna:77]
[same as prior period, unchanged from 0001408710-23-000036:mdna:76]

[0001408710-24-000009:mdna:78]
| (in thousands) | Three Months Ended |  | Six Months Ended |
| December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |
| Revenues | $ | 712,694 |  |  | $ | 668,656 |  |  | $ | 1,398,171 |  |  | $ | 1,324,085 |  |
| Cost of revenues | (624,364) |  |  | (583,441) |  |  | (1,225,437) |  |  | (1,156,114) |  |
| Gross profit | 88,330 |  |  | 85,215 |  |  | 172,734 |  |  | 167,971 |  |
| Selling, general and administrative expenses | (19,316) |  |  | (18,930) |  |  | (39,745) |  |  | (39,495) |  |
| Operating income | 69,014 |  |  | 66,285 |  |  | 132,989 |  |  | 128,476 |  |
| Interest income | 7,748 |  |  | 2,334 |  |  | 13,646 |  |  | 3,893 |  |
| Interest expense | (36) |  |  | (389) |  |  | (81) |  |  | (780) |  |
| Foreign exchange gain (loss), net | (3,788) |  |  | (3,904) |  |  | (3,373) |  |  | (1,819) |  |
| Other income (expense), net | (35) |  |  | (68) |  |  | (115) |  |  | (209) |  |
| Income before income taxes | 72,903 |  |  | 64,258 |  |  | 143,066 |  |  | 129,561 |  |
| Income tax expense | (3,793) |  |  | (1,101) |  |  | (8,867) |  |  | (1,789) |  |
| Net income | 69,110 |  |  | 63,157 |  |  | 134,199 |  |  | 127,772 |  |
| Other comprehensive income (loss), net of tax | 11,699 |  |  | 12,344 |  |  | 12,312 |  |  | 10,079 |  |
| Net comprehensive income | $ | 80,809 |  |  | $ | 75,501 |  |  | $ | 146,511 |  |  | $ | 137,851 |  |

[0001408710-24-000009:mdna:79]
[same as prior period, unchanged from 0001408710-23-000036:mdna:78]

[0001408710-24-000009:mdna:80]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |
| Revenues | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenues | (87.6) |  |  | (87.3) |  |  | (87.6) |  |  | (87.3) |  |
| Gross profit | 12.4 |  |  | 12.7 |  |  | 12.4 |  |  | 12.7 |  |
| Selling, general and administrative expenses | (2.7) |  |  | (2.8) |  |  | (2.9) |  |  | (3.0) |  |
| Operating income | 9.7 |  |  | 9.9 |  |  | 9.5 |  |  | 9.7 |  |
| Interest income | 1.1 |  |  | 0.4 |  |  | 1.0 |  |  | 0.3 |  |
| Interest expense | 0.0 |  |  | (0.1) |  |  | 0.0 |  |  | (0.1) |  |
| Foreign exchange gain (loss), net | (0.6) |  |  | (0.6) |  |  | (0.3) |  |  | (0.1) |  |
| Other income (expense), net | 0.0 |  |  | 0.0 |  |  | 0.0 |  |  | 0.0 |  |
| Income before income taxes | 10.2 |  |  | 9.6 |  |  | 10.2 |  |  | 9.8 |  |
| Income tax expense | (0.5) |  |  | (0.2) |  |  | (0.6) |  |  | (0.1) |  |
| Net income | 9.7 |  |  | 9.4 |  |  | 9.6 |  |  | 9.7 |  |
| Other comprehensive income (loss), net of tax | 1.6 |  |  | 1.9 |  |  | 0.9 |  |  | 0.7 |  |
| Net comprehensive income | 11.3 | % |  | 11.3 | % |  | 10.5 | % |  | 10.4 | % |

[0001408710-24-000009:mdna:81]
36

[0001408710-24-000009:mdna:82]
[same as prior period, unchanged from 0001408710-23-000036:mdna:81]

[0001408710-24-000009:mdna:83]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands) | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |
| Optical communications | $ | 567,934 |  |  | $ | 506,056 |  |  | $ | 1,101,191 |  |  | $ | 1,003,617 |  |
| Automotive, lasers and other | 144,760 |  |  | 162,600 |  |  | 296,980 |  |  | 320,468 |  |
| Total | $ | 712,694 |  |  | $ | 668,656 |  |  | $ | 1,398,171 |  |  | $ | 1,324,085 |  |

[0001408710-24-000009:mdna:84]
[same as prior period, unchanged from 0001408710-23-000036:mdna:83]

[0001408710-24-000009:mdna:85]
Comparison of Three and Six Months Ended December 29, 2023 with Three and Six Months Ended December 30, 2022

[0001408710-24-000009:mdna:86]
[same as prior period, unchanged from 0001408710-23-000036:mdna:85]

[0001408710-24-000009:mdna:87]
Our revenues increased by $44.0 million, or 6.6%, to $712.7 million for the three months ended December 29, 2023, compared with $668.7 million for the three months ended December 30, 2022. This increase was primarily due to an increase in our key customers’ demand for optical communications products. Revenues from optical communications products, which represented $567.9 million, or 79.7%, of our revenues for the three months ended December 29, 2023, increased by $61.9 million, or 12.2%, compared to the same period in the prior fiscal year, mainly due to an increase in revenues from data communication products, primarily for artificial intelligence applications, offset by a decline in revenues from telecommunication products as inventory absorption within the telecommunication market continued during the three months ended December 29, 2023. Revenues from non-optical communications products, which represented $144.8 million, or 20.3%, of our revenues for the three months ended December 29, 2023, decreased by $17.8 million, or 11.0%, compared to the same period in the prior fiscal year, primarily due to a decline in revenues from automotive products.

[0001408710-24-000009:mdna:88]
Our revenues increased by $74.1 million, or 5.6%, to $1,398.2 million for the six months ended December 29, 2023 (26-week), compared with $1,324.1 million for the six months ended December 30, 2022 (27-week). This increase was primarily due to an increase in our key customers’ demand for optical communications products. Revenues from optical communications products, which represented $1,101.2 million, or 78.8%, of our revenues for the six months ended December 29, 2023, increased by $97.6 million, or 9.7%, compared to the same period in the prior fiscal year, mainly due to an increase in revenues from data communication products, primarily for artificial intelligence applications, offset by a decline in revenues from telecommunication products as inventory absorption within the telecommunication market continued during the six months ended December 29, 2023. Revenues from non-optical communications products, which represented $297.0 million, or 21.2%, of our revenues for the six months ended December 29, 2023, decreased by $23.5 million, or 7.3%, compared to the same period in the prior fiscal year, primarily due to inventory absorption related to certain programs in the automotive market.

[0001408710-24-000009:mdna:89]
[same as prior period, unchanged from 0001408710-23-000036:mdna:87]

[0001408710-24-000009:mdna:90]
Our cost of revenues increased by $41.0 million, or 7.0%, to $624.4 million, or 87.6% of revenues, for the three months ended December 29, 2023, compared with $583.4 million, or 87.3% of revenues, for the three months ended December 30, 2022. The increase was in line with the increase in sales volume.

[0001408710-24-000009:mdna:91]
Our cost of revenues increased by $69.3 million, or 6.0%, to $1,225.4 million, or 87.6% of revenues, for the six months ended December 29, 2023, compared with $1,156.1 million, or 87.3% of revenues, for the six months ended December 30, 2022. This increase was in line with the increase in sales volume.

[0001408710-24-000009:mdna:92]
[same as prior period, unchanged from 0001408710-23-000036:mdna:89]

[0001408710-24-000009:mdna:93]
Our gross profit increased by $3.1 million, or 3.6%, to $88.3 million, or 12.4% of revenues, for the three months ended December 29, 2023, compared with $85.2 million, or 12.7% of revenues, for the three months ended December 30, 2022. The increase was primarily due to an increase in sales volume.

[0001408710-24-000009:mdna:94]
Our gross profit increased by $4.7 million, or 2.8%, to $172.7 million, or 12.4% of revenues, for the six months ended December 29, 2023, compared with $168.0 million, or 12.7% of revenues, for the six months ended December 30, 2022. The increase was primarily due to an increase in sales volume.

[0001408710-24-000009:mdna:95]
[same as prior period, unchanged from 0001408710-23-000036:mdna:91]

[0001408710-24-000009:mdna:96]
Our SG&A expenses increased by $0.4 million, or 2.1%, to $19.3 million, or 2.7% of revenues, for the three months ended December 29, 2023, compared with $18.9 million, or 2.8% of revenues, for the three months ended December 30, 2022. The increase was primarily due to (1) a net increase in allowance for expected credit losses of $0.6 million, (2) an increase in sales and marketing expenses of $0.4 million and (3) an increase in share-based compensation expenses of $0.2 million, offset by lower compensation related expense of $0.8 million.

[0001408710-24-000009:mdna:97]
Our SG&A expenses increased by $0.2 million, or 0.5%, to $39.7 million, or 2.9% of revenues, for the six months ended December 29, 2023, compared with $39.5 million, or 3.0% of revenues, for the six months ended December 30, 2022. The increase was primarily due to a net increase in allowance for expected credit losses of $1.5 million, offset by (1) lower compensation related expenses of $0.8 million, (2) a decrease in customer relationships amortization of $0.2 million and (3) a decrease in legal and consulting fees of $0.2 million.

[0001408710-24-000009:mdna:98]
[same as prior period, unchanged from 0001408710-23-000036:mdna:93]

[0001408710-24-000009:mdna:99]
Our operating income increased by $2.7 million, or 4.1%, to $69.0 million, or 9.7% of revenues, for the three months ended December 29, 2023, compared with $66.3 million, or 9.9% of revenues, for the three months ended December 30, 2022. The increase was primarily due to an increase in revenues.

[0001408710-24-000009:mdna:100]
Our operating income increased by $4.5 million, or 3.5%, to $133.0 million, or 9.5% of revenues, for the six months ended December 29, 2023, compared with $128.5 million, or 9.7% of revenues, for the six months ended December 30, 2022. The increase was primarily due to an increase in revenues.

[0001408710-24-000009:mdna:101]
[same as prior period, unchanged from 0001408710-23-000036:mdna:95]

[0001408710-24-000009:mdna:102]
Our interest income increased by $5.4 million, or 234.8%, to $7.7 million, or 1.1% of revenues, for the three months ended December 29, 2023, compared with $2.3 million, or 0.4% of revenues, for the three months ended December 30, 2022. The increase was primarily due to a higher weighted average interest rate and higher average cash balance and short-term investment from $462.0 million to $717.0 million during the three months ended December 29, 2023 compared to the same period in the prior fiscal year.

[0001408710-24-000009:mdna:103]
Our interest income increased by $9.7 million, or 248.7%, to $13.6 million, or 1.0% of revenues, for the six months ended December 29, 2023, compared with $3.9 million, or 0.3% of revenues, for the six months ended December 30, 2022. The increase was primarily due to a higher weighted average interest rate and higher average cash balance and short-term investment from $440.0 million to $645.0 million during the six months ended December 29, 2023 compared to same period in the prior fiscal year.

[0001408710-24-000009:mdna:104]
[same as prior period, unchanged from 0001408710-23-000036:mdna:97]

[0001408710-24-000009:mdna:105]
Our interest expense decreased by $0.4 million for the three months ended December 29, 2023, compared with the three months ended December 30, 2022. The decrease was primarily due to a decrease in the amount of an outstanding long-term loan.

[0001408710-24-000009:mdna:106]
Our interest expense decreased by $0.7 million for the six months ended December 29, 2023, compared with $0.8 million for the six months ended December 30, 2022. The decrease was primarily due to a decrease in the amount of an outstanding long-term loan.

[0001408710-24-000009:mdna:107]
[same as prior period, unchanged from 0001408710-23-000036:mdna:99]

[0001408710-24-000009:mdna:108]
We recorded foreign exchange loss, net of $3.8 million, or 0.6% of revenues, for the three months ended December 29, 2023, compared with foreign exchange loss, net of $3.9 million, or 0.6% of revenues for the three months ended December 30, 2022. The decrease in foreign exchange loss was mainly due to (1) lower unrealized loss from revaluation of outstanding Thai baht assets and liabilities of $1.7 million, and (2) lower unrealized loss from revaluation of currencies other than Thai baht of $0.3 million, offset by (1) lower unrealized gain from mark-to-market forward contracts of $1.7 million, (2) lower foreign exchange gain, totaling $0.1 million from our subsidiaries in the PRC and the U.K., and (3) higher realized loss from payment/receipt of $0.1 million.

[0001408710-24-000009:mdna:109]
We recorded foreign exchange loss, net of $3.4 million, or 0.3% of revenues, for the six months ended December 29, 2023, compared with foreign exchange loss, net of $1.8 million, or 0.1% for the six months ended December 30, 2022. The increase in foreign exchange loss was mainly due to (1) lower unrealized gain from mark-to-market forward contracts of $1.1 million, (2) realized loss from payment/receipt of $0.7 million, and (3) higher unrealized loss from revaluation of currencies other than Thai baht of $0.2 million, offset by (1) lower unrealized loss from revaluation of outstanding Thai baht assets and liabilities of $0.2 million, and (2) foreign exchange gain, totaling $0.2 million from our subsidiaries in the PRC and the U.K.

[0001408710-24-000009:mdna:110]
[same as prior period, unchanged from 0001408710-23-000036:mdna:101]

[0001408710-24-000009:mdna:111]
We recorded income before income taxes of $72.9 million for the three months ended December 29, 2023, compared with $64.3 million for the three months ended December 30, 2022.

[0001408710-24-000009:mdna:112]
We recorded income before income taxes of $143.1 million for the six months ended December 29, 2023, compared with $129.6 million for the six months ended December 30, 2022.

[0001408710-24-000009:mdna:113]
[same as prior period, unchanged from 0001408710-23-000036:mdna:103]

[0001408710-24-000009:mdna:114]
Our provision for income tax reflects effective tax rates of 5.2% and 1.7% for the three months ended December 29, 2023 and December 30, 2022, respectively. The increase was due to an increase in income subject to tax during the three months ended December 29, 2023 as compared to the three months ended December 30, 2022. In addition, our subsidiary in the U.K. generated taxable income and was able to utilize loss carryforwards. Management determined that it was more likely than not that future taxable income would be sufficient to allow utilization of the deferred tax assets. Thus, a full valuation allowance of $1.6 million for the deferred tax assets was released during the three months ended December 30, 2022.

[0001408710-24-000009:mdna:115]
Our provision for income tax reflects effective tax rates of 6.2% and 1.4% for the six months ended December 29, 2023 and December 30, 2022, respectively. The increase was primarily due to an increase in income subject to tax during the six months ended December 29, 2023 as compared to the six months ended December 30, 2022. In addition, a full valuation allowance of $2.1 million for deferred tax assets was set up during the six months ended December 29, 2023 due to management's belief that our subsidiary in Israel would continue to have losses in the foreseeable future such that the deferred tax assets of such subsidiary would not be utilized while a full valuation allowance of $1.6 million from the subsidiary in U.K. was released during the six months ended December 30, 2022.

[0001408710-24-000009:mdna:116]
[same as prior period, unchanged from 0001408710-23-000036:mdna:105]

[0001408710-24-000009:mdna:117]
We recorded net income of $69.1 million, or 9.7% of revenues, for the three months ended December 29, 2023, compared with $63.2 million, or 9.4% of revenues, for the three months ended December 30, 2022.

[0001408710-24-000009:mdna:118]
We recorded net income of $134.2 million, or 9.6% of revenues, for the six months ended December 29, 2023, compared with $127.8 million, or 9.7% of revenues, for the six months ended December 30, 2022.

[0001408710-24-000009:mdna:119]
[same as prior period, unchanged from 0001408710-23-000036:mdna:107]

[0001408710-24-000009:mdna:120]
We recorded other comprehensive income of $11.7 million, or 1.6% of revenues, for the three months ended December 29, 2023, compared with other comprehensive income of $12.3 million, or 1.9% of revenues, for the three months ended December 30, 2022. The change was mainly due to (1) lower unrealized gain from mark-to-market of forward contracts and interest rate swap agreements of $2.2 million, and (2) higher unrealized loss from foreign currency translation adjustment of $0.1 million, offset by (1) higher unrealized gain from mark-to-market of available-for-sale debt securities of $1.8 million, and (2) lower gain from retirement benefits plan of $0.1 million.

[0001408710-24-000009:mdna:121]
We recorded other comprehensive income of $12.3 million, or 0.9% of revenues, for the six months ended December 29, 2023, compared with other comprehensive income of $10.1 million, or 0.7% of revenues, for the six months ended December 30, 2022. The change was mainly due to unrealized gain from mark-to-market of available-for-sale debt securities of $4.2 million for the six months ended December 29, 2023, offset by (1) lower unrealized gain from mark-to-market of forward contracts and interest rate swap agreements of $1.6 million for the six months ended December 29, 2023, (2) unrealized loss from foreign currency translation adjustment of $0.3 million, and (3) lower gain from retirement benefits plan of $0.1 million

[0001408710-24-000009:mdna:122]
[same as prior period, unchanged from 0001408710-23-000036:mdna:109]

[0001408710-24-000009:mdna:123]
[same as prior period, unchanged from 0001408710-23-000036:mdna:110]

[0001408710-24-000009:mdna:124]
We primarily finance our operations through cash flow from operations. As of December 29, 2023 and December 30, 2022, we had cash, cash equivalents, and short-term investments of $740.6 million and $527.6 million, respectively, and outstanding debt of $6.1 million and $18.3 million, respectively.

[0001408710-24-000009:mdna:125]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents was 4.3% and 4.2% for the three and six months ended December 29, 2023, respectively, and 2.0% and 1.8% for the three and six months ended December 30, 2022, respectively.

[0001408710-24-000009:mdna:126]
Our cash investments are made in accordance with an investment policy approved by the audit committee of our board of directors. In general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed income securities are primarily classified as

[0001408710-24-000009:mdna:127]
available-for-sale and are recorded at fair value. The cost of securities sold is based on the specific identification method. Unrealized gains and losses on these securities are recorded as other comprehensive income (loss) and are reported as a separate component of shareholders’ equity.

[0001408710-24-000009:mdna:128]
During the six months ended December 29, 2023, we repaid $6.1 million of the term loan under our 2019 Credit Facility Agreement. As a result, as of December 29, 2023, we had a long-term borrowing of $6.1 million under our 2019 Credit Facility Agreement (see Note 10 of Notes to Unaudited Condensed Consolidated Financial Statements for further details). We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held short-term investments of $406.5 million as of December 29, 2023.

[0001408710-24-000009:mdna:129]
We believe that our current cash and cash equivalents, short-term investments, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001408710-24-000009:mdna:130]
[same as prior period, unchanged from 0001408710-23-000036:mdna:117]

[0001408710-24-000009:mdna:131]
[same as prior period, unchanged from 0001408710-23-000036:mdna:118]

[0001408710-24-000009:mdna:132]
|  | Six Months Ended |
| (in thousands) | December 29, 2023 |  | December 30, 2022 |
| Net cash provided by operating activities | $ | 229,214 |  |  | $ | 105,100 |  |
| Net cash used in investing activities | $ | (101,853) |  |  | $ | (21,580) |  |
| Net cash used in financing activities | $ | (24,818) |  |  | $ | (31,045) |  |
| Net increase in cash, cash equivalents and restricted cash | $ | 102,543 |  |  | $ | 52,475 |  |

[0001408710-24-000009:mdna:133]
[same as prior period, unchanged from 0001408710-23-000036:mdna:120]

[0001408710-24-000009:mdna:134]
Cash provided by operating activities is net income adjusted for certain non-cash items and changes in certain assets and liabilities. The increase in cash provided by operating activities during the six months ended December 29, 2023 as compared to the six months ended December 30, 2022 was primarily driven by efficient cash-favorable working capital changes mainly from inventory management.

[0001408710-24-000009:mdna:135]
[same as prior period, unchanged from 0001408710-23-000036:mdna:122]

[0001408710-24-000009:mdna:136]
Investing cash flows consist primarily of investment purchases, sales, maturities, and disposals; and capital expenditures. The increase in cash used in investing activities for the six months ended December 29, 2023 as compared to cash provided in investing activities for the six months ended December 30, 2022 was primarily due to an increase in investment purchases.

[0001408710-24-000009:mdna:137]
[same as prior period, unchanged from 0001408710-23-000036:mdna:124]

[0001408710-24-000009:mdna:138]
Financing cash flows consist primarily of repayment of long-term debt, share repurchases, and withholding tax related to net share settlement of restricted share units. The decrease in cash used in financing activities for the six months ended December 29, 2023 as compared to the six months ended December 30, 2022 was primarily due to a decrease in withholding tax related to net share settlement of restricted share units, and lower repayment of long-term borrowings due to one fewer installment from one fewer week in the first quarter of fiscal year 2024 compared to fiscal year 2023, offset by a higher volume of share repurchases.

[0001408710-24-000009:mdna:139]
[same as prior period, unchanged from 0001408710-23-000036:mdna:126]

[0001408710-24-000009:mdna:140]
[same as prior period, unchanged from 0001408710-23-000036:mdna:127]
