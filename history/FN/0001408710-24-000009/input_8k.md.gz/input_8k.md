# FN 8-K — 0001408710-24-000007 filed 2024-02-05

## item codes, every 8-K on or before 2024-02-06

- 2024-02-05 0001408710-24-000007 — 2.02, 9.01
- 2023-12-13 0001408710-23-000038 — 5.07
- 2023-11-06 0001408710-23-000034 — 2.02, 9.01
- 2023-08-21 0001408710-23-000026 — 2.02, 5.02, 9.01
- 2023-05-08 0001408710-23-000016 — 2.02, 5.02, 9.01
- 2023-02-06 0001408710-23-000006 — 2.02, 9.01
- 2022-12-13 0001408710-22-000062 — 5.07
- 2022-11-07 0001408710-22-000058 — 2.02, 9.01
- 2022-08-15 0001408710-22-000041 — 2.02, 5.02, 9.01
- 2022-05-02 0001408710-22-000026 — 2.02, 9.01
- 2022-01-31 0001408710-22-000016 — 2.02, 9.01
- 2022-01-19 0001408710-22-000010 — 5.02
- 2022-01-06 0001408710-22-000006 — 5.02
- 2021-12-10 0001408710-21-000051 — 5.07
- 2021-11-01 0001408710-21-000045 — 2.02, 9.01
- 2021-08-16 0001408710-21-000031 — 2.02, 5.02, 9.01
- 2021-05-03 0001408710-21-000019 — 2.02, 9.01
- 2021-02-01 0001408710-21-000008 — 2.02, 9.01
- 2020-12-11 0001193125-20-315861 — 5.07
- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2024-02-06

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001408710-24-000007:8k_2_02:1]
EX-99.1
2
fn-20240205xex991q224.htm
EX-99.1

[0001408710-24-000007:8k_2_02:2]
Document

[0001408710-24-000007:8k_2_02:3]
Exhibit 99.1

[0001408710-24-000007:8k_2_02:4]
Fabrinet Announces Second Quarter Fiscal Year 2024 Financial Results

[0001408710-24-000007:8k_2_02:5]
•Exceeds Guidance Ranges with Record Revenue and Net Income Per Share

[0001408710-24-000007:8k_2_02:6]
BANGKOK, Thailand – February 5, 2024 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its second fiscal quarter ended December 29, 2023.

[0001408710-24-000007:8k_2_02:7]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “Our strong second quarter results exceeded our guidance ranges and also represented record levels for revenue and net income per share. We continued to see strong datacom revenue growth, which helped drive our overall top line performance. We remain confident that newer datacom programs will significantly contribute to our results as we look ahead. Telecom revenue moderated by a smaller amount than anticipated in the quarter, and we are optimistic that the impact of ongoing inventory adjustments in the telecom market could continue to diminish. With continued business momentum, we are well-positioned to extend our track record of strong execution into the third quarter.”

[0001408710-24-000007:8k_2_02:8]
Second Quarter Fiscal Year 2024 Financial Highlights

[0001408710-24-000007:8k_2_02:9]
GAAP Results

[0001408710-24-000007:8k_2_02:10]
•Revenue for the second quarter of fiscal year 2024 was $712.7 million, compared to $668.7 million for the second quarter of fiscal year 2023.

[0001408710-24-000007:8k_2_02:11]
•GAAP net income for the second quarter of fiscal year 2024 was $69.1 million, compared to $63.2 million for the second quarter of fiscal year 2023.

[0001408710-24-000007:8k_2_02:12]
•GAAP net income per diluted share for the second quarter of fiscal year 2024 was $1.89, compared to $1.71 for the second quarter of fiscal year 2023.

[0001408710-24-000007:8k_2_02:13]
Non-GAAP Results

[0001408710-24-000007:8k_2_02:14]
•Non-GAAP net income for the second quarter of fiscal year 2024 was $76.1 million, compared to $70.0 million for the second quarter of fiscal year 2023.

[0001408710-24-000007:8k_2_02:15]
•Non-GAAP net income per diluted share for the second quarter of fiscal year 2024 was $2.08, compared to $1.90 for the second quarter of fiscal year 2023.

[0001408710-24-000007:8k_2_02:16]
Business Outlook

[0001408710-24-000007:8k_2_02:17]
Based on information available as of February 5, 2024, Fabrinet is issuing guidance for its third fiscal quarter ending March 29, 2024, as follows:

[0001408710-24-000007:8k_2_02:18]
•Fabrinet expects third quarter revenue to be in the range of $705 million to $725 million.

[0001408710-24-000007:8k_2_02:19]
•GAAP net income per diluted share is expected to be in the range of $1.89 to $1.96, based on approximately 36.6 million fully diluted shares outstanding.

[0001408710-24-000007:8k_2_02:20]
•Non-GAAP net income per diluted share is expected to be in the range of $2.08 to $2.15, based on approximately 36.6 million fully diluted shares outstanding.

[0001408710-24-000007:8k_2_02:21]
Guidance for non-GAAP net income per diluted share excludes share-based compensation expenses and certain non-recurring items. A reconciliation of non-GAAP net income per diluted share to the corresponding GAAP measure is available at the end of this press release.

[0001408710-24-000007:8k_2_02:22]
Conference Call Information

[0001408710-24-000007:8k_2_02:23]
| What: |  | Fabrinet Second Quarter Fiscal Year 2024 Financial Results Call |
| When: |  | February 5, 2024 |
| Time: |  | 5:00 p.m. ET |
| Live Call and Replay: |  | https://investor.fabrinet.com/events-and-presentations/events |

[0001408710-24-000007:8k_2_02:24]
A recorded version of this webcast will be available approximately two hours after the call and accessible at http://investor.fabrinet.com. The webcast will be archived on Fabrinet’s website for a period of one year.

[0001408710-24-000007:8k_2_02:25]
About Fabrinet

[0001408710-24-000007:8k_2_02:26]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China, and Israel. For more information visit: www.fabrinet.com.

[0001408710-24-000007:8k_2_02:27]
Forward-Looking Statements

[0001408710-24-000007:8k_2_02:28]
Use of Non-GAAP Financials

[0001408710-24-000007:8k_2_02:29]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; amortization of intangibles; and amortization of deferred debt issuance costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001408710-24-000007:8k_2_02:30]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, some of these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001408710-24-000007:8k_2_02:31]
Investor Contact:

[0001408710-24-000007:8k_2_02:32]
Garo Toomajanian

[0001408710-24-000007:8k_2_02:33]
ir@fabrinet.com

[0001408710-24-000007:8k_2_02:34]
FABRINET

[0001408710-24-000007:8k_2_02:35]
CONDENSED CONSOLIDATED BALANCE SHEETS (unaudited)

[0001408710-24-000007:8k_2_02:36]
| (in thousands of U.S. dollars, except share data and par value) | December 29,2023 |  | June 30,2023 |
| Assets |  |  |  |
| Current assets |  |  |  |
| Cash and cash equivalents | $ | 334,053 |  |  | $ | 231,368 |  |
| Short-term investments | 406,540 |  |  | 319,100 |  |
| Trade accounts receivable, net of allowance for expected credit losses of $2,741 and $965, respectively | 584,614 |  |  | 531,767 |  |
| Inventories | 414,758 |  |  | 519,576 |  |
| Prepaid expenses | 5,952 |  |  | 7,849 |  |
| Other current assets | 60,446 |  |  | 42,880 |  |
| Total current assets | 1,806,363 |  |  | 1,652,540 |  |
| Non-current assets |  |  |  |
| Property, plant and equipment, net | 306,019 |  |  | 310,350 |  |
| Intangibles, net | 2,549 |  |  | 2,394 |  |
| Operating right-of-use assets | 5,767 |  |  | 1,634 |  |
| Deferred tax assets | 11,804 |  |  | 12,095 |  |
| Other non-current assets | 636 |  |  | 635 |  |
| Total non-current assets | 326,775 |  |  | 327,108 |  |
| Total Assets | $ | 2,133,138 |  |  | $ | 1,979,648 |  |
| Liabilities and Shareholders’ Equity |  |  |  |
| Current liabilities |  |  |  |
| Long-term borrowings, current portion, net | $ | 6,078 |  |  | $ | 12,156 |  |
| Trade accounts payable | 376,556 |  |  | 381,129 |  |
| Fixed assets payable | 12,983 |  |  | 13,526 |  |
| Operating lease liabilities, current portion | 1,425 |  |  | 1,201 |  |
| Income tax payable | 7,581 |  |  | 6,024 |  |
| Accrued payroll, bonus and related expenses | 20,174 |  |  | 23,748 |  |
| Accrued expenses | 16,119 |  |  | 20,447 |  |
| Other payables | 45,861 |  |  | 23,654 |  |
| Total current liabilities | 486,777 |  |  | 481,885 |  |
| Non-current liabilities |  |  |  |
| Deferred tax liability | 4,546 |  |  | 4,799 |  |
| Operating lease liability, non-current portion | 3,956 |  |  | 66 |  |
| Severance liabilities | 24,505 |  |  | 22,159 |  |
| Other non-current liabilities | 1,972 |  |  | 2,081 |  |
| Total non-current liabilities | 34,979 |  |  | 29,105 |  |
| Total Liabilities | 521,756 |  |  | 510,990 |  |
| Shareholders’ equity |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of December 29, 2023 and June 30, 2023) | — |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 39,435,354 shares and 39,284,176 shares issued as of December 29, 2023 and June 30, 2023, respectively; and 36,296,621 shares and 36,183,682 shares outstanding as of December 29, 2023 and June 30, 2023, respectively) | 394 |  |  | 393 |  |
| Additional paid-in capital | 209,208 |  |  | 206,624 |  |
| Less: Treasury shares (3,138,733 shares and 3,100,494 shares as of December 29, 2023 and June 30, 2023, respectively) | (201,205) |  |  | (194,833) |  |
| Accumulated other comprehensive income (loss) | 4,197 |  |  | (8,115) |  |
| Retained earnings | 1,598,788 |  |  | 1,464,589 |  |
| Total Shareholders’ Equity | 1,611,382 |  |  | 1,468,658 |  |
| Total Liabilities and Shareholders’ Equity | $ | 2,133,138 |  |  | $ | 1,979,648 |  |

[0001408710-24-000007:8k_2_02:37]
FABRINET

[0001408710-24-000007:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME (unaudited)

[0001408710-24-000007:8k_2_02:39]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands of U.S. dollars, except per share data) | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |
| Revenues | $ | 712,694 |  |  | $ | 668,656 |  |  | $ | 1,398,171 |  |  | $ | 1,324,085 |  |
| Cost of revenues | (624,364) |  |  | (583,441) |  |  | (1,225,437) |  |  | (1,156,114) |  |
| Gross profit | 88,330 |  |  | 85,215 |  |  | 172,734 |  |  | 167,971 |  |
| Selling, general and administrative expenses | (19,316) |  |  | (18,930) |  |  | (39,745) |  |  | (39,495) |  |
| Operating income | 69,014 |  |  | 66,285 |  |  | 132,989 |  |  | 128,476 |  |
| Interest income | 7,748 |  |  | 2,334 |  |  | 13,646 |  |  | 3,893 |  |
| Interest expense | (36) |  |  | (389) |  |  | (81) |  |  | (780) |  |
| Foreign exchange gain (loss), net | (3,788) |  |  | (3,904) |  |  | (3,373) |  |  | (1,819) |  |
| Other income (expense), net | (35) |  |  | (68) |  |  | (115) |  |  | (209) |  |
| Income before income taxes | 72,903 |  |  | 64,258 |  |  | 143,066 |  |  | 129,561 |  |
| Income tax expense | (3,793) |  |  | (1,101) |  |  | (8,867) |  |  | (1,789) |  |
| Net income | 69,110 |  |  | 63,157 |  |  | 134,199 |  |  | 127,772 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities | 2,946 |  |  | 1,183 |  |  | 3,894 |  |  | (278) |  |
| Change in net unrealized gain (loss) on derivative instruments | 8,951 |  |  | 11,188 |  |  | 8,390 |  |  | 9,970 |  |
| Change in net retirement benefits plan – prior service cost | 8 |  |  | 57 |  |  | 134 |  |  | 225 |  |
| Change in foreign currency translation adjustment | (206) |  |  | (84) |  |  | (106) |  |  | 162 |  |
| Total other comprehensive income (loss), net of tax | 11,699 |  |  | 12,344 |  |  | 12,312 |  |  | 10,079 |  |
| Net comprehensive income | $ | 80,809 |  |  | $ | 75,501 |  |  | $ | 146,511 |  |  | $ | 137,851 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 1.90 |  |  | $ | 1.73 |  |  | $ | 3.70 |  |  | $ | 3.50 |  |
| Diluted | $ | 1.89 |  |  | $ | 1.71 |  |  | $ | 3.67 |  |  | $ | 3.47 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |
| Basic | 36,328 |  |  | 36,589 |  |  | 36,292 |  |  | 36,558 |  |
| Diluted | 36,639 |  |  | 36,939 |  |  | 36,560 |  |  | 36,848 |  |

[0001408710-24-000007:8k_2_02:40]
FABRINET

[0001408710-24-000007:8k_2_02:41]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited)

[0001408710-24-000007:8k_2_02:42]
|  | Six Months Ended |
| (in thousands of U.S. dollars) | December 29,2023 |  | December 30,2022 |
| Cash flows from operating activities |  |  |  |
| Net income for the period | $ | 134,199 |  |  | $ | 127,772 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 24,186 |  |  | 21,596 |  |
| (Gain) loss on disposal and impairment of property, plant and equipment and intangibles | (111) |  |  | (337) |  |
| (Gain) loss from sales and maturities of available-for-sale securities | (1) |  |  | 92 |  |
| Amortization of discount (premium) of short-term investments | (1,397) |  |  | 565 |  |
| (Reversal of) allowance for expected credit losses | 1,776 |  |  | 251 |  |
| Unrealized loss (gain) on exchange rate and fair value of foreign currency forward contracts | 3,287 |  |  | 3,086 |  |
| Amortization of fair value at hedge inception of interest rate swaps | (154) |  |  | (346) |  |
| Share-based compensation | 14,714 |  |  | 14,498 |  |
| Deferred income tax | 1,117 |  |  | (1,338) |  |
| Other non-cash expenses | 90 |  |  | (305) |  |
| Changes in operating assets and liabilities |  |  |  |
| Trade accounts receivable | (53,873) |  |  | (80,054) |  |
| Inventories | 104,818 |  |  | 20,475 |  |
| Other current assets and non-current assets | (16,360) |  |  | (11,837) |  |
| Trade accounts payable | (6,980) |  |  | (4,176) |  |
| Income tax payable | 1,531 |  |  | (577) |  |
| Severance liabilities | 1,395 |  |  | 1,269 |  |
| Other current liabilities and non-current liabilities | 20,977 |  |  | 14,466 |  |
| Net cash provided by operating activities | 229,214 |  |  | 105,100 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of short-term investments | (164,971) |  |  | (74,482) |  |
| Proceeds from sales of short-term investments | 10,000 |  |  | 30,000 |  |
| Proceeds from maturities of short-term investments | 72,824 |  |  | 46,925 |  |
| Purchase of property, plant and equipment | (21,236) |  |  | (23,643) |  |
| Purchase of intangibles | (518) |  |  | (412) |  |
| Proceeds from disposal of property, plant and equipment | 2,048 |  |  | 32 |  |
| Net cash used in investing activities | (101,853) |  |  | (21,580) |  |
| Cash flows from financing activities |  |  |  |
| Repayment of long-term borrowings | (6,094) |  |  | (9,140) |  |
| Repayment of finance lease liability | — |  |  | (5) |  |
| Repurchase of ordinary shares | (6,372) |  |  | (5,104) |  |
| Withholding tax related to net share settlement of restricted share units | (12,352) |  |  | (16,796) |  |
| Net cash used in financing activities | (24,818) |  |  | (31,045) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | 102,543 |  |  | $ | 52,475 |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at the beginning of period | $ | 231,368 |  |  | $ | 198,365 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | 102,543 |  |  | 52,475 |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash | 142 |  |  | (11) |  |
| Cash, cash equivalents and restricted cash at the end of period | $ | 334,053 |  |  | $ | 250,829 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment-related payables | $ | 12,983 |  |  | $ | 18,920 |  |

[0001408710-24-000007:8k_2_02:43]
FABRINET

[0001408710-24-000007:8k_2_02:44]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-24-000007:8k_2_02:45]
|  | Three Months Ended |  | Six Months Ended |
|  | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |
| (in thousands of U.S. dollars, except share data) | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |
| GAAP measures | $ | 69,110 |  |  | $ | 1.89 |  |  | $ | 63,157 |  |  | $ | 1.71 |  |  | $ | 134,199 |  |  | $ | 3.67 |  |  | $ | 127,772 |  |  | $ | 3.47 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 1,701 |  |  | 0.05 |  |  | 1,660 |  |  | 0.05 |  |  | 3,866 |  |  | 0.11 |  |  | 3,576 |  |  | 0.10 |  |
| Total related to gross profit | 1,701 |  |  | 0.05 |  |  | 1,660 |  |  | 0.05 |  |  | 3,866 |  |  | 0.11 |  |  | 3,576 |  |  | 0.10 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 5,280 |  |  | 0.14 |  |  | 5,115 |  |  | 0.14 |  |  | 10,848 |  |  | 0.30 |  |  | 10,922 |  |  | 0.29 |  |
| Amortization of intangibles | — |  |  | — |  |  | 71 |  |  | 0.00 |  |  | — |  |  | — |  |  | 154 |  |  | 0.01 |  |
| Total related to selling, general and administrative expenses | 5,280 |  |  | 0.14 |  |  | 5,186 |  |  | 0.14 |  |  | 10,848 |  |  | 0.30 |  |  | 11,076 |  |  | 0.30 |  |
| Related to other income and expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of deferred debt issuance costs | 8 |  |  | 0.00 |  |  | 8 |  |  | 0.00 |  |  | 16 |  |  | 0.00 |  |  | 16 |  |  | 0.00 |  |
| Total related to other income and expense | 8 |  |  | 0.00 |  |  | 8 |  |  | 0.00 |  |  | 16 |  |  | 0.00 |  |  | 16 |  |  | 0.00 |  |
| Total related to net income & EPS | 6,989 |  |  | 0.19 |  |  | 6,854 |  |  | 0.19 |  |  | 14,730 |  |  | 0.41 |  |  | 14,668 |  |  | 0.40 |  |
| Non-GAAP measures | $ | 76,099 |  |  | $ | 2.08 |  |  | $ | 70,011 |  |  | $ | 1.90 |  |  | $ | 148,929 |  |  | $ | 4.08 |  |  | $ | 142,440 |  |  | $ | 3.87 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  | 36,639 |  |  |  |  | 36,939 |  |  |  |  | 36,560 |  |  |  |  | 36,848 |  |
| Non-GAAP diluted shares |  |  | 36,639 |  |  |  |  | 36,939 |  |  |  |  | 36,560 |  |  |  |  | 36,848 |  |

[0001408710-24-000007:8k_2_02:46]
FABRINET

[0001408710-24-000007:8k_2_02:47]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001408710-24-000007:8k_2_02:48]
| (in thousands) |  | Three Months Ended |  | Six Months Ended |
|  |  | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |
| Net cash provided by operating activities |  | $ | 84,165 |  |  | $ | 44,466 |  |  | $ | 229,214 |  |  | $ | 105,100 |  |
| Less: Purchase of property, plant and equipment |  | (9,801) |  |  | (13,385) |  |  | (21,236) |  |  | (23,643) |  |
| Non-GAAP free cash flow |  | $ | 74,364 |  |  | $ | 31,081 |  |  | $ | 207,978 |  |  | $ | 81,457 |  |

[0001408710-24-000007:8k_2_02:49]
FABRINET

[0001408710-24-000007:8k_2_02:50]
GUIDANCE FOR QUARTER ENDING MARCH 29, 2024

[0001408710-24-000007:8k_2_02:51]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-24-000007:8k_2_02:52]
|  | DilutedEPS |
| GAAP net income per diluted share: | $1.89 to $1.96 |
| Related to cost of revenues: |  |
| Share-based compensation expenses | 0.05 |
| Total related to gross profit | 0.05 |
| Related to selling, general and administrative expenses: |  |
| Share-based compensation expenses | 0.14 |
| Total related to selling, general and administrative expenses | 0.14 |
| Total related to net income & EPS | 0.19 |
| Non-GAAP net income per diluted share | $2.08 to $2.15 |
