# FN notes — 0001408710-24-000009


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001408710-24-000009:notes:1]
[same as prior period, unchanged from 0001408710-23-000036:notes:1]

[0001408710-24-000009:notes:2]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of December 29, 2023 and for the three and six months ended December 29, 2023 and December 30, 2022 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 30, 2023.

[0001408710-24-000009:notes:3]
[same as prior period, unchanged from 0001408710-23-000036:notes:3]

[0001408710-24-000009:notes:4]
The results for the three and six months ended December 29, 2023 may not be indicative of results for the year ending June 28, 2024 or any future periods.

[0001408710-24-000009:notes:5]
[same as prior period, unchanged from 0001408710-23-000036:notes:5]

[0001408710-24-000009:notes:6]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisitions, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information.

[0001408710-24-000009:notes:7]
[same as prior period, unchanged from 0001408710-23-000036:notes:7]

[0001408710-24-000009:notes:8]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  December 29, 2023 and December 30, 2022 consisted of 13 weeks. The six months ended December 29, 2023 and December 30, 2022 consisted of 26 and 27 weeks, respectively. Fiscal year 2024 will comprise 52 weeks and will end on June 28, 2024.

[0001408710-24-000009:notes:9]
[same as prior period, unchanged from 0001408710-23-000036:notes:9]

[0001408710-24-000009:notes:10]
No new accounting standard was adopted during the first half of fiscal year 2024.

[0001408710-24-000009:notes:11]
New Accounting Standards—not yet adopted by the Company

[0001408710-24-000009:notes:12]
In November 2023, the Financial Accounting Standards Board ("FASB") issued ASU 2023-07, “Segment Reporting (Topic 280), Improvements to Reportable Segment Disclosures,” which is intended to improve reportable segment disclosure requirements, primarily through additional disclosures about significant segment expenses. This ASU is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. This ASU will be effective for the Company in the first quarter of fiscal year 2025. The Company is currently assessing the impact to its disclosures.
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740), Improvements to Income Tax Disclosures,” which requires more detailed income tax disclosures. This ASU requires entities to disclose disaggregated information about their effective tax rate reconciliation as well as expanded information on income taxes paid by jurisdiction. This ASU is effective for all entities for fiscal years beginning after December 15, 2024, with early adoption permitted for annual financial statements that have not yet been issued or made available for issuance. This ASU will be effective for the Company in the first quarter of fiscal year 2026. The Company is currently assessing the impact to its disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001408710-24-000009:notes:13]
[same as prior period, unchanged from 0001408710-23-000036:notes:11]

[0001408710-24-000009:notes:14]
[same as prior period, unchanged from 0001408710-23-000036:notes:12]

[0001408710-24-000009:notes:15]
[same as prior period, unchanged from 0001408710-23-000036:notes:13]

[0001408710-24-000009:notes:16]
| (in thousands, except percentages) | Three Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |  | Six Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 238,288 |  |  |  |  | $ | 493,147 |  |  |  |
| Others (1) | 3,331 |  |  |  |  | 6,791 |  |  |  |
| Total revenue in North America | 241,619 |  |  | 33.9 | % |  | 499,938 |  |  | 35.8 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel (2) | 267,038 |  |  |  |  | 477,714 |  |  |  |
| India | 75,033 |  |  |  |  | 145,810 |  |  |  |
| Malaysia | 36,626 |  |  |  |  | 69,945 |  |  |  |
| China | 21,262 |  |  |  |  | 41,522 |  |  |  |
| Hong Kong | 12,150 |  |  |  |  | 27,938 |  |  |  |
| Thailand | 10,403 |  |  |  |  | 23,430 |  |  |  |
| Japan | 5,826 |  |  |  |  | 12,636 |  |  |  |
| Others | 1,570 |  |  |  |  | 2,735 |  |  |  |
| Total revenue in Asia-Pacific and others | 429,908 |  |  | 60.3 | % |  | 801,730 |  |  | 57.3 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 18,870 |  |  |  |  | 48,644 |  |  |  |
| Germany | 10,395 |  |  |  |  | 23,175 |  |  |  |
| Others | 11,902 |  |  |  |  | 24,684 |  |  |  |
| Total revenue in Europe | $ | 41,167 |  |  | 5.8 | % |  | $ | 96,503 |  |  | 6.9 | % |
| Total revenue | $ | 712,694 |  |  | 100.0 | % |  | $ | 1,398,171 |  |  | 100.0 | % |

[0001408710-24-000009:notes:17]
| (in thousands, except percentages) | Three Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |  | Six Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 319,918 |  |  |  |  | $ | 664,998 |  |  |  |
| Others (1) | 4,033 |  |  |  |  | 7,657 |  |  |  |
| Total revenue in North America | 323,951 |  |  | 48.5 | % |  | 672,655 |  |  | 50.8 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 82,178 |  |  |  |  | 162,211 |  |  |  |
| Israel | 59,893 |  |  |  |  | 97,170 |  |  |  |
| Malaysia | 50,390 |  |  |  |  | 99,714 |  |  |  |
| Hong Kong | 39,723 |  |  |  |  | 72,195 |  |  |  |
| China | 26,480 |  |  |  |  | 49,544 |  |  |  |
| Thailand | 16,098 |  |  |  |  | 28,714 |  |  |  |
| Japan | 11,737 |  |  |  |  | 22,085 |  |  |  |
| Others | 1,901 |  |  |  |  | 5,061 |  |  |  |
| Total revenue in Asia-Pacific and others | 288,400 |  |  | 43.1 | % |  | 536,694 |  |  | 40.5 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 30,316 |  |  |  |  | 63,148 |  |  |  |
| Germany | 13,129 |  |  |  |  | 26,443 |  |  |  |
| Others | 12,860 |  |  |  |  | 25,145 |  |  |  |
| Total revenue in Europe | $ | 56,305 |  |  | 8.4 | % |  | $ | 114,736 |  |  | 8.7 | % |
| Total revenue | $ | 668,656 |  |  | 100.0 | % |  | $ | 1,324,085 |  |  | 100.0 | % |

[0001408710-24-000009:notes:18]
[same as prior period, unchanged from 0001408710-23-000036:notes:15]

[0001408710-24-000009:notes:19]
[same as prior period, unchanged from 0001408710-23-000036:notes:16]

[0001408710-24-000009:notes:20]
[same as prior period, unchanged from 0001408710-23-000036:notes:17]

[0001408710-24-000009:notes:21]
| (in thousands, except percentages) | Three Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |  | Six Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |
| Optical communications | $ | 567,934 |  |  | 79.7 | % |  | $ | 1,101,191 |  |  | 78.8 | % |
| Automotive, lasers and other | 144,760 |  |  | 20.3 | % |  | 296,980 |  |  | 21.2 | % |
| Total | $ | 712,694 |  |  | 100.0 | % |  | $ | 1,398,171 |  |  | 100.0 | % |

[0001408710-24-000009:notes:22]
| (in thousands, except percentages) | Three Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |  | Six Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |
| Optical communications | $ | 506,056 |  |  | 75.7 | % |  | $ | 1,003,617 |  |  | 75.8 | % |
| Automotive, lasers and other | 162,600 |  |  | 24.3 | % |  | 320,468 |  |  | 24.2 | % |
| Total | $ | 668,656 |  |  | 100.0 | % |  | $ | 1,324,085 |  |  | 100.0 | % |

[0001408710-24-000009:notes:23]
[same as prior period, unchanged from 0001408710-23-000036:notes:19]

[0001408710-24-000009:notes:24]
A contract asset is recognized when the Company has recognized revenues, but has not yet issued an invoice to its customer for payment. Contract assets are recognized in the unaudited condensed consolidated balance sheets under other current assets and transferred to accounts receivable when rights to payment become unconditional.

[0001408710-24-000009:notes:25]
As of December 29, 2023 and June 30, 2023, the Company's contract assets are de minimis.

[0001408710-24-000009:notes:26]
[same as prior period, unchanged from 0001408710-23-000036:notes:22]

[0001408710-24-000009:notes:27]
The following tables summarize the activity in the Company’s contract liabilities during the six months ended December 29, 2023:

[0001408710-24-000009:notes:28]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 30, 2023 | $ | 3,036 |  |
| Advance payments received during the period | 7,610 |  |
| Revenue recognized | (4,325) |  |
| Ending balance, December 29, 2023 | $ | 6,321 |  |


## us-gaap:EarningsPerShareTextBlock

[0001408710-24-000009:notes:29]
[same as prior period, unchanged from 0001408710-23-000036:notes:25]

[0001408710-24-000009:notes:30]
[same as prior period, unchanged from 0001408710-23-000036:notes:26]

[0001408710-24-000009:notes:31]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands, except per share data) | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |
| Net income attributable to shareholders | $ | 69,110 |  |  | $ | 63,157 |  |  | $ | 134,199 |  |  | $ | 127,772 |  |
| Weighted-average number of ordinary shares outstanding | 36,328 |  |  | 36,589 |  |  | 36,292 |  |  | 36,558 |  |
| Incremental shares arising from the assumed vesting of restricted share units and performance share units | 311 |  |  | 350 |  |  | 268 |  |  | 290 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share | 36,639 |  |  | 36,939 |  |  | 36,560 |  |  | 36,848 |  |
| Basic earnings per ordinary share | $ | 1.90 |  |  | $ | 1.73 |  |  | $ | 3.70 |  |  | $ | 3.50 |  |
| Diluted earnings per ordinary share | $ | 1.89 |  |  | $ | 1.71 |  |  | $ | 3.67 |  |  | $ | 3.47 |  |


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001408710-24-000009:notes:32]
[same as prior period, unchanged from 0001408710-23-000036:notes:28]

[0001408710-24-000009:notes:33]
|  |  |  | Fair Value |
| (in thousands) | CarryingCost |  | UnrealizedGain/(Loss) |  | Cash andCashEquivalents |  | MarketableSecurities |  | OtherInvestments |
| As of December 29, 2023 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 332,881 |  |  | $ | — |  |  | $ | 332,881 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 1,172 |  |  | — |  |  | 1,172 |  |  | — |  |  | — |  |
| Liquidity funds | 31,736 |  |  | — |  |  | — |  |  | — |  |  | 31,736 |  |
| Certificates of deposit and time deposits | 134,777 |  |  | 1,519 |  |  | — |  |  | 136,296 |  |  | — |  |
| Corporate debt securities | 122,554 |  |  | (1,158) |  |  | — |  |  | 121,396 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 116,856 |  |  | 256 |  |  | — |  |  | 117,112 |  |  | — |  |
| Total | $ | 739,976 |  |  | $ | 617 |  |  | $ | 334,053 |  |  | $ | 374,804 |  |  | $ | 31,736 |  |
| As of June 30, 2023 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 230,967 |  |  | $ | — |  |  | $ | 230,967 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 401 |  |  | — |  |  | 401 |  |  | — |  |  | — |  |
| Liquidity funds | 41,104 |  |  | — |  |  | — |  |  | — |  |  | 41,104 |  |
| Certificates of deposit and time deposits | 64,278 |  |  | 329 |  |  | — |  |  | 64,607 |  |  | — |  |
| Corporate debt securities | 161,453 |  |  | (3,375) |  |  | — |  |  | 158,078 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 55,542 |  |  | (231) |  |  | — |  |  | 55,311 |  |  | — |  |
| Total | $ | 553,745 |  |  | $ | (3,277) |  |  | $ | 231,368 |  |  | $ | 277,996 |  |  | $ | 41,104 |  |

[0001408710-24-000009:notes:34]
[same as prior period, unchanged from 0001408710-23-000036:notes:30]

[0001408710-24-000009:notes:35]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of December 29, 2023 and June 30, 2023:

[0001408710-24-000009:notes:36]
|  | December 29, 2023 |  | June 30, 2023 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 200,139 |  |  | $ | 201,672 |  |  | $ | 172,992 |  |  | $ | 173,137 |  |
| Due between one to five years | 205,784 |  |  | 204,868 |  |  | 149,385 |  |  | 145,963 |  |
| Total | $ | 405,923 |  |  | $ | 406,540 |  |  | $ | 322,377 |  |  | $ | 319,100 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001408710-24-000009:notes:37]
[same as prior period, unchanged from 0001408710-23-000036:notes:33]

[0001408710-24-000009:notes:38]
[same as prior period, unchanged from 0001408710-23-000036:notes:34]

[0001408710-24-000009:notes:39]
[same as prior period, unchanged from 0001408710-23-000036:notes:35]

[0001408710-24-000009:notes:40]
[same as prior period, unchanged from 0001408710-23-000036:notes:36]

[0001408710-24-000009:notes:41]
[same as prior period, unchanged from 0001408710-23-000036:notes:37]

[0001408710-24-000009:notes:42]
[same as prior period, unchanged from 0001408710-23-000036:notes:38]

[0001408710-24-000009:notes:43]
|  | Fair Value Measurements at Reporting Date Using |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of December 29, 2023 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 1,172 |  |  |  | $ | — |  |  | $ | 1,172 |  |
| Liquidity funds | — |  |  | 31,736 |  |  |  | — |  |  | 31,736 |  |
| Certificates of deposit and time deposits | — |  |  | 136,296 |  |  |  | — |  |  | 136,296 |  |
| Corporate debt securities | — |  |  | 121,396 |  |  |  | — |  |  | 121,396 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 117,112 |  |  |  | — |  |  | 117,112 |  |
| Derivative assets – current portion | — |  |  | 4,391 |  | (1) |  | — |  |  | 4,391 |  |
| Total | $ | — |  |  | $ | 412,103 |  |  |  | $ | — |  |  | $ | 412,103 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | (1) |  |  |  | $ | — |  |  | $ | (1) |  |
| Total | $ | — |  |  | $ | (1) |  | (2) |  | $ | — |  |  | $ | (1) |  |

[0001408710-24-000009:notes:44]
[same as prior period, unchanged from 0001408710-23-000036:notes:40]

[0001408710-24-000009:notes:45]
(1)Foreign currency forward contracts with an aggregate notional amount of $125.0 million and 0.3 million Canadian dollars and an interest rate swap agreement with a notional amount of $60.9 million.

[0001408710-24-000009:notes:46]
(2)Foreign currency forward contracts with an aggregate notional amount of $1.0 million.

[0001408710-24-000009:notes:47]
[same as prior period, unchanged from 0001408710-23-000036:notes:43]

[0001408710-24-000009:notes:48]
[same as prior period, unchanged from 0001408710-23-000036:notes:44]

[0001408710-24-000009:notes:49]
[same as prior period, unchanged from 0001408710-23-000036:notes:45]

[0001408710-24-000009:notes:50]
[same as prior period, unchanged from 0001408710-23-000036:notes:46]

[0001408710-24-000009:notes:51]
[same as prior period, unchanged from 0001408710-23-000036:notes:47]

[0001408710-24-000009:notes:52]
[same as prior period, unchanged from 0001408710-23-000036:notes:48]

[0001408710-24-000009:notes:53]
[same as prior period, unchanged from 0001408710-23-000036:notes:49]

[0001408710-24-000009:notes:54]
[same as prior period, unchanged from 0001408710-23-000036:notes:50]

[0001408710-24-000009:notes:55]
[same as prior period, unchanged from 0001408710-23-000036:notes:51]

[0001408710-24-000009:notes:56]
As of December 29, 2023, the Company had 126 outstanding U.S. dollar foreign currency forward contracts against Thai baht, with an aggregate notional amount of $126.0 million and maturity dates ranging from January 2024 through July 2024 and one outstanding Canadian dollar foreign currency forward contract with a notional amount of 0.3 million Canadian dollars and a maturity date in March 2024.

[0001408710-24-000009:notes:57]
As of June 30, 2023, the Company had 143 outstanding U.S. dollar foreign currency forward contracts against Thai baht with an aggregate notional amount of $143.0 million and maturity dates ranging from July 2023 through January 2024, and one outstanding Canadian dollar foreign currency forward contract with a notional amount of 0.2 million Canadian dollars and a maturity date in September 2023.

[0001408710-24-000009:notes:58]
As of December 29, 2023, the hedging relationship over foreign currency forward contracts designated for hedge accounting was determined to be highly effective based on the performance of retrospective and prospective regression testing. As of December 29, 2023, the amount in accumulated other comprehensive income (“AOCI”) expected to be reclassified into earnings within 12 months was a gain of $3.9 million.

[0001408710-24-000009:notes:59]
[same as prior period, unchanged from 0001408710-23-000036:notes:55]

[0001408710-24-000009:notes:60]
During the three and six months ended December 29, 2023, the Company included an unrealized gain of $2.6 million and $2.9 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-24-000009:notes:61]
During the three and six months ended December 30, 2022, the Company included an unrealized gain of $4.2 million and $4.0 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for

[0001408710-24-000009:notes:62]
hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-24-000009:notes:63]
[same as prior period, unchanged from 0001408710-23-000036:notes:57]

[0001408710-24-000009:notes:64]
The Company has entered into interest rate swap agreements to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. As of December 29, 2023 and June 30, 2023, the Company had one outstanding interest rate swap agreement with a notional amount of $60.9 million.

[0001408710-24-000009:notes:65]
On July 25, 2018, Fabrinet Thailand entered into an interest rate swap agreement to effectively convert the floating interest rate of the term loan under the Company's previous syndicated senior credit facility agreement to a fixed interest rate of 2.86% per annum through the scheduled maturity of the term loan in June 2023 (see Note 10). The Company did not designate this interest rate swap for hedge accounting.

[0001408710-24-000009:notes:66]
On September 3, 2019, Fabrinet Thailand entered into a term loan agreement under a credit facility agreement with Bank of Ayudhya Public Company Limited, and on September 10, 2019, the Company repaid in full the outstanding term loan under the Company's previous syndicated senior credit facility agreement (see Note 10). In conjunction with the funding of the new term loan, the Company entered into a second interest rate swap agreement. The combination of both of these interest rate swaps effectively converts the floating interest rate of the Company’s term loan with Bank of Ayudhya Public Company Limited to a fixed interest rate of 4.36% per annum through the maturity of the term loan in June 2024.

[0001408710-24-000009:notes:67]
On September 27, 2019, the Company designated these two interest rate swaps as a cash flow hedge for the Company’s term loan under the credit facility agreement with Bank of Ayudhya Public Company Limited. The combination of these two interest rate swaps qualified for hedge accounting because the hedges were highly effective, and the Company had designated and documented contemporaneously the hedging relationships involving these interest rate swaps, one of which matured in June 2023. While the Company intends to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in earnings. From September 27, 2019, any gains or losses related to these interest rate swaps are recorded in AOCI in the unaudited condensed consolidated balance sheets. The Company reclassifies a portion of the gains or losses from AOCI into earnings at each reporting period based on either the accrued interest amount or the interest payment.

[0001408710-24-000009:notes:68]
As of December 29, 2023, the amount in AOCI that is expected to be reclassified into earnings within 12 months was a gain of $0.1 million.

[0001408710-24-000009:notes:69]
[same as prior period, unchanged from 0001408710-23-000036:notes:63]

[0001408710-24-000009:notes:70]
[same as prior period, unchanged from 0001408710-23-000036:notes:64]

[0001408710-24-000009:notes:71]
|  |  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) | Financialstatementsline item |  | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |
| Derivatives gain (loss) recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Othercomprehensiveincome |  | $ | 11,119 |  |  | $ | 14,754 |  |  | $ | 9,554 |  |  | $ | 11,762 |  |
| Interest rate swaps | Othercomprehensiveincome |  | (75) |  |  | 310 |  |  | (153) |  |  | 826 |  |
| Total derivatives gain (loss) recognized in other comprehensive income (loss) |  |  | $ | 11,044 |  |  | $ | 15,064 |  |  | $ | 9,401 |  |  | $ | 12,588 |  |
| Derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings: |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Cost of revenues |  | $ | 4,783 |  |  | $ | 5,534 |  |  | $ | 8,455 |  |  | $ | 9,328 |  |
| Foreign currency forward contracts | SG&A |  | 199 |  |  | 230 |  |  | 354 |  |  | 390 |  |
| Foreign currency forward contracts | Foreign exchange loss, net |  | (7,205) |  |  | (9,485) |  |  | (10,420) |  |  | (11,990) |  |
| Interest rate swaps | Interest expense |  | (65) |  |  | (155) |  |  | (154) |  |  | (346) |  |
| Total derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings |  |  | $ | (2,288) |  |  | $ | (3,876) |  |  | $ | (1,765) |  |  | $ | (2,618) |  |
| Change in net unrealized gain (loss) on derivatives instruments |  |  | $ | 8,756 |  |  | $ | 11,188 |  |  | $ | 7,636 |  |  | $ | 9,970 |  |

[0001408710-24-000009:notes:72]
[same as prior period, unchanged from 0001408710-23-000036:notes:66]

[0001408710-24-000009:notes:73]
[same as prior period, unchanged from 0001408710-23-000036:notes:67]

[0001408710-24-000009:notes:74]
|  | December 29,2023 |  | June 30,2023 |
| (in thousands) | DerivativeAssets |  | DerivativeLiabilities |  | DerivativeAssets |  | DerivativeLiabilities |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts | $ | 328 |  |  | $ | (1) |  |  | $ | 2 |  |  | $ | (1,256) |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward contracts | 4,001 |  |  | — |  |  | 4 |  |  | (3,980) |  |
| Interest rate swaps | 62 |  |  | — |  |  | 215 |  |  | — |  |
| Derivatives, gross balances | $ | 4,391 |  |  | $ | (1) |  |  | $ | 221 |  |  | $ | (5,236) |  |

[0001408710-24-000009:notes:75]
[same as prior period, unchanged from 0001408710-23-000036:notes:69]

[0001408710-24-000009:notes:76]
[same as prior period, unchanged from 0001408710-23-000036:notes:70]


## us-gaap:InventoryDisclosureTextBlock

[0001408710-24-000009:notes:77]
[same as prior period, unchanged from 0001408710-23-000036:notes:71]

[0001408710-24-000009:notes:78]
| (in thousands) | As of December 29,2023 |  | As of June 30,2023 |
| Raw materials | $ | 87,803 |  |  | $ | 157,379 |  |
| Work in progress | 249,874 |  |  | 305,627 |  |
| Finished goods | 48,879 |  |  | 28,608 |  |
| Goods in transit | 28,202 |  |  | 27,962 |  |
| Total inventories | $ | 414,758 |  |  | $ | 519,576 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001408710-24-000009:notes:79]
[same as prior period, unchanged from 0001408710-23-000036:notes:73]

[0001408710-24-000009:notes:80]
[same as prior period, unchanged from 0001408710-23-000036:notes:74]

[0001408710-24-000009:notes:81]
As of December 29, 2023, the maturities of the Company’s operating lease liabilities were as follows:

[0001408710-24-000009:notes:82]
| (in thousands) |  |  |
| 2024 (remaining six months) | $ | 994 |  |  |
| 2025 | 1,190 |  |  |
| 2026 | 1,118 |  |  |
| 2027 | 1,143 |  |  |
| 2028 | 1,143 |  |  |
| Thereafter | 287 |  |  |
| Total undiscounted lease payments | 5,875 |  |  |
| Less imputed interest | (494) |  |  |
| Total present value of lease liabilities | $ | 5,381 |  | (1) |

[0001408710-24-000009:notes:83]
(1)Includes current portion of operating lease liabilities of $1.4 million.

[0001408710-24-000009:notes:84]
[same as prior period, unchanged from 0001408710-23-000036:notes:78]

[0001408710-24-000009:notes:85]
Rental expense for long-term leases for the three and six months ended December 29, 2023 was $0.5 million and $1.1 million, respectively, and for the three and six months ended December 30, 2022 was $0.6 million and $1.2 million, respectively.

[0001408710-24-000009:notes:86]
Rental expense for short-term leases for the three and six months ended December 29, 2023 was $0.3 million and $0.7 million, respectively, and for the three and six months ended December 30, 2022 was de minimis.

[0001408710-24-000009:notes:87]
[same as prior period, unchanged from 0001408710-23-000036:notes:81]

[0001408710-24-000009:notes:88]
|  | As ofDecember 29, 2023 |  | As ofJune 30, 2023 |
| Weighted-average remaining lease term (in years) | 4.4 |  | 1.2 |
| Weighted-average discount rate | 4.0 | % |  | 3.4 | % |

[0001408710-24-000009:notes:89]
The following table presents supplemental disclosure for the unaudited condensed consolidated statements of cash flows related to operating and finance leases for the three and six months ended December 29, 2023 and December 30, 2022:

[0001408710-24-000009:notes:90]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands) | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |
| Operating cash flows from operating leases | $ | 785 |  |  | $ | 661 |  |  | $ | 1,744 |  |  | $ | 1,302 |  |
| Financing cash flows from finance leases | $ | — |  |  | $ | 3 |  |  | $ | — |  |  | $ | 5 |  |
| ROU assets obtained in exchange for lease liabilities | $ | 118 |  |  | $ | 69 |  |  | $ | 5,054 |  |  | $ | 69 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001408710-24-000009:notes:91]
[same as prior period, unchanged from 0001408710-23-000036:notes:85]

[0001408710-24-000009:notes:92]
| (in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  |  |  | Net |
| As of December 29, 2023 |  |  |  |  |  |  |  |
| Software | $ | 11,165 |  |  | $ | (8,616) |  |  |  |  | $ | 2,549 |  |

[0001408710-24-000009:notes:93]
[same as prior period, unchanged from 0001408710-23-000036:notes:87]

[0001408710-24-000009:notes:94]
The Company recorded amortization expense relating to intangibles of $0.3 million and $0.4 million for the three months ended December 29, 2023 and December 30, 2022, respectively, and $0.6 million and $0.8 million for the six months ended December 29, 2023 and December 30, 2022, respectively.

[0001408710-24-000009:notes:95]
[same as prior period, unchanged from 0001408710-23-000036:notes:89]

[0001408710-24-000009:notes:96]
| (years) | As ofDecember 29, 2023 |  | As ofJune 30, 2023 |
| Software | 2.4 |  | 3.1 |

[0001408710-24-000009:notes:97]
Based on the carrying amount of intangibles as of December 29, 2023, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001408710-24-000009:notes:98]
| (in thousands) |  |
| 2024 (remaining six months) | $ | 496 |  |
| 2025 | 831 |  |
| 2026 | 586 |  |
| 2027 | 391 |  |
| 2028 | 219 |  |
| Thereafter | 26 |  |
| Total | $ | 2,549 |  |


## us-gaap:DebtDisclosureTextBlock

[0001408710-24-000009:notes:99]
Borrowings 
The Company’s total borrowings, including current and non-current portions of long-term borrowings, consisted of the following:

[0001408710-24-000009:notes:100]
| (in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofDecember 29, 2023 |  | As ofJune 30, 2023 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 6,094 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (16) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 6,078 |  |  | $ | 12,156 |  |

[0001408710-24-000009:notes:101]
(1)The Company has entered into interest rate swaps that effectively fix a series of future interest payments on its term loans. Refer to Note 6.

[0001408710-24-000009:notes:102]
The movements of long-term borrowings for the six months ended December 29, 2023 and December 30, 2022 were as follows:

[0001408710-24-000009:notes:103]
|  | Six Months Ended |
| (in thousands) | December 29,2023 |  | December 30,2022 |
| Opening balance | $ | 12,188 |  |  | $ | 27,421 |  |
| Repayments during the period | (6,094) |  |  | (9,140) |  |
| Closing balance | $ | 6,094 |  |  | $ | 18,281 |  |

[0001408710-24-000009:notes:104]
Credit facility agreements:

[0001408710-24-000009:notes:105]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a credit facility agreement (the “2019 Credit Facility Agreement”), which provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million that may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the 2019 Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

[0001408710-24-000009:notes:106]
Under the 2019 Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a term loan agreement (the "Term Loan Agreement") pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company's previous syndicated senior credit facility agreement.

[0001408710-24-000009:notes:107]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. On March 9, 2023, the Borrower and the Bank amended the Term Loan Agreement to replace the interest rate reference from LIBOR to the Secured Overnight Financing Rate ("SOFR") effective from September 29, 2023. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three and six months ended December 29, 2023, the Company recorded $0.1 million and $0.2 million, respectively, of interest expense in connection with this term loan, including the impact from interest rate swaps.

[0001408710-24-000009:notes:108]
Any borrowings under the 2019 Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

[0001408710-24-000009:notes:109]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, and restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any

[0001408710-24-000009:notes:110]
payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of December 29, 2023, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

[0001408710-24-000009:notes:111]
The events of default under the Term Loan Agreement include failure to timely pay amounts due under the Term Loan Agreement or the related finance documents, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

[0001408710-24-000009:notes:112]
As of December 29, 2023, there was $6.1 million outstanding under the term loan.

[0001408710-24-000009:notes:113]
On March 9, 2023, Fabrinet Thailand and the Parent Company (the “Borrowers”) and the Bank entered into a credit facility agreement (the “2023 Credit Facility Agreement”), which provides a facility of $55.0 million.

[0001408710-24-000009:notes:114]
Any borrowings under the 2023 Credit Facility Agreement are secured by land and buildings owned by the Borrowers in the Pathumthani and Chonburi Provinces in Thailand.

[0001408710-24-000009:notes:115]
Under the 2023 Credit Facility Agreement, the Borrowers are required to maintain a loan to value of the mortgaged real property ratio of not greater than 60%. The Borrowers are also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times.

[0001408710-24-000009:notes:116]
As of December 29, 2023, there was no amount outstanding under the 2023 Credit Facility Agreement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001408710-24-000009:notes:117]
Income taxes
As of December 29, 2023 and June 30, 2023, the liability for uncertain tax positions including accrued interest and penalties was $2.5 million and $1.5 million, respectively. The Company expects the estimated amount of liability associated with its uncertain tax positions to decrease within the next 12 months following the closure of tax audit in certain jurisdictions for fiscal year 2019 and fiscal year 2020.

[0001408710-24-000009:notes:118]
[same as prior period, unchanged from 0001408710-23-000036:notes:113]

[0001408710-24-000009:notes:119]
The effective tax rate for the Company for the three months ended December 29, 2023 and December 30, 2022 was 5.2% and 1.7%, respectively, of net income. The increase was due to an increase in income subject to tax during the three months ended December 29, 2023 as compared to the three months ended December 30, 2022. In addition, our subsidiary in the U.K. generated taxable income and was able to utilize loss carryforwards. Management determined that it was more likely than not that future taxable income would be sufficient to allow utilization of the deferred tax assets. Thus, a full valuation allowance of $1.6 million for the deferred tax assets was released during the three months ended December 30, 2022.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001408710-24-000009:notes:120]
[same as prior period, unchanged from 0001408710-23-000036:notes:115]

[0001408710-24-000009:notes:121]
The grant date fair value of restricted share units and performance share units is based on the market value of Fabrinet's ordinary shares on the date of grant.

[0001408710-24-000009:notes:122]
The effect of recording share-based compensation expense for the three and six months ended December 29, 2023 and December 30, 2022 was as follows:

[0001408710-24-000009:notes:123]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands) | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |
| Restricted share units | $ | 4,088 |  |  | $ | 3,999 |  |  | $ | 8,967 |  |  | $ | 8,900 |  |
| Performance share units | 2,893 |  |  | 2,776 |  |  | 5,747 |  |  | 5,598 |  |
| Total share-based compensation expense | 6,981 |  |  | 6,775 |  |  | 14,714 |  |  | 14,498 |  |
| Tax effect on share-based compensation expense | — |  |  | — |  |  | — |  |  | — |  |
| Net effect on share-based compensation expense | $ | 6,981 |  |  | $ | 6,775 |  |  | $ | 14,714 |  |  | $ | 14,498 |  |

[0001408710-24-000009:notes:124]
[same as prior period, unchanged from 0001408710-23-000036:notes:119]

[0001408710-24-000009:notes:125]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands) | December 29,2023 |  | December 30,2022 |  | December 29,2023 |  | December 30,2022 |
| Cost of revenue | $ | 1,701 |  |  | $ | 1,660 |  |  | $ | 3,866 |  |  | $ | 3,576 |  |
| Selling, general and administrative expense | 5,280 |  |  | 5,115 |  |  | 10,848 |  |  | 10,922 |  |
| Total share-based compensation expense | $ | 6,981 |  |  | $ | 6,775 |  |  | $ | 14,714 |  |  | $ | 14,498 |  |

[0001408710-24-000009:notes:126]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the three and six months ended December 29, 2023 and December 30, 2022.

[0001408710-24-000009:notes:127]
[same as prior period, unchanged from 0001408710-23-000036:notes:122]

[0001408710-24-000009:notes:128]
[same as prior period, unchanged from 0001408710-23-000036:notes:123]

[0001408710-24-000009:notes:129]
[same as prior period, unchanged from 0001408710-23-000036:notes:124]

[0001408710-24-000009:notes:130]
[same as prior period, unchanged from 0001408710-23-000036:notes:125]

[0001408710-24-000009:notes:131]
The following table summarizes the number of equity awards outstanding and ordinary shares available for grant under each of the Equity Incentive Plans as of December 29, 2023:

[0001408710-24-000009:notes:132]
| (share units) | Restricted Share Units outstanding |  | Performance Share Units outstanding |  | Ordinary Shares available for future grant |
| 2020 Plan | 327,764 |  |  | 171,078 |  |  | 1,758,843 |  |
| 2017 Inducement Plan | — |  |  | — |  |  | 111,347 |  |
| Total | 327,764 |  |  | 171,078 |  |  | 1,870,190 |  |

[0001408710-24-000009:notes:133]
[same as prior period, unchanged from 0001408710-23-000036:notes:128]

[0001408710-24-000009:notes:134]
[same as prior period, unchanged from 0001408710-23-000036:notes:129]

[0001408710-24-000009:notes:135]
[same as prior period, unchanged from 0001408710-23-000036:notes:130]

[0001408710-24-000009:notes:136]
[same as prior period, unchanged from 0001408710-23-000036:notes:131]

[0001408710-24-000009:notes:137]
[same as prior period, unchanged from 0001408710-23-000036:notes:132]

[0001408710-24-000009:notes:138]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 30, 2023 | 368,765 |  |  | $ | 97.49 |  |
| Granted | 114,159 |  |  | $ | 160.54 |  |
| Vested | (145,067) |  |  | $ | 86.07 |  |
| Forfeited | (10,093) |  |  | $ | 120.71 |  |
| Balance as of December 29, 2023 | 327,764 |  |  | $ | 123.79 |  |

[0001408710-24-000009:notes:139]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 24, 2022 | 459,626 |  |  | $ | 75.14 |  |
| Granted | 148,830 |  |  | $ | 119.14 |  |
| Vested | (189,375) |  |  | $ | 64.23 |  |
| Forfeited | (15,028) |  |  | $ | 89.86 |  |
| Balance as of December 30, 2022 | 404,053 |  |  | $ | 95.91 |  |

[0001408710-24-000009:notes:140]
[same as prior period, unchanged from 0001408710-23-000036:notes:135]

[0001408710-24-000009:notes:141]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 30, 2023 | 204,016 |  |  | $ | 108.81 |  |
| Granted | 73,936 |  |  | $ | 158.91 |  |
| Vested | (106,874) |  |  | $ | 101.05 |  |
| Forfeited | — |  |  | $ | — |  |
| Balance as of December 29, 2023 | 171,078 |  |  | $ | 135.31 |  |

[0001408710-24-000009:notes:142]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 24, 2022 | 285,882 |  |  | $ | 81.64 |  |
| Granted | 97,142 |  |  | $ | 117.35 |  |
| Vested | (179,008) |  |  | 70.05 |  |
| Forfeited | — |  |  | $ | — |  |
| Balance as of December 30, 2022 | 204,016 |  |  | $ | 108.81 |  |

[0001408710-24-000009:notes:143]
As of December 29, 2023, there was $19.6 million and $12.6 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.7 and 1.3 years, respectively.

[0001408710-24-000009:notes:144]
For the six months ended December 29, 2023 and December 30, 2022, the Company withheld an aggregate of 100,763 shares and 165,502 shares, respectively, upon the vesting of restricted share units and performance shares units, based upon the closing share price on the vesting date to settle employee tax withholding obligations. For the six months ended December 29, 2023 and December 30, 2022, the Company then remitted cash of $12.4 million and $16.8 million, respectively, to the appropriate taxing authorities and presented it as a financing activity within the unaudited condensed consolidated statements of cash flows. The payment was recorded as a reduction of additional paid-in capital.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001408710-24-000009:notes:145]
[same as prior period, unchanged from 0001408710-23-000036:notes:141]

[0001408710-24-000009:notes:146]
[same as prior period, unchanged from 0001408710-23-000036:notes:142]

[0001408710-24-000009:notes:147]
For the three and six months ended December 29, 2023, Fabrinet issued 4,384 and 151,178 ordinary shares, respectively, upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-24-000009:notes:148]
For the three and six months ended December 30, 2022, Fabrinet issued 6,034 and 202,881 ordinary shares, respectively, upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-24-000009:notes:149]
[same as prior period, unchanged from 0001408710-23-000036:notes:145]

[0001408710-24-000009:notes:150]
[same as prior period, unchanged from 0001408710-23-000036:notes:146]

[0001408710-24-000009:notes:151]
[same as prior period, unchanged from 0001408710-23-000036:notes:147]

[0001408710-24-000009:notes:152]
During the six months ended December 29, 2023, 38,239 shares were repurchased under the program, at an average price per share (excluding other direct costs) of $166.61, for an aggregate purchase price of $6.4 million. As of December 29, 2023, the Company had a remaining authorization to repurchase up to $93.6 million worth of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001408710-24-000009:notes:153]
Accumulated other comprehensive income (loss)
The changes in AOCI for the six months ended December 29, 2023 and December 30, 2022 were as follows:

[0001408710-24-000009:notes:154]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 30, 2023 | $ | (3,279) |  |  | $ | (3,541) |  |  | $ | (330) |  |  | $ | (965) |  |  | $ | (8,115) |  |
| Other comprehensive income (loss) before reclassification | 3,893 |  |  | 9,401 |  |  | — |  |  | (106) |  |  | 13,188 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | 1 |  |  | (1,765) |  |  | 158 |  |  | — |  |  | (1,606) |  |
| Tax effects | — |  |  | 754 |  |  | (24) |  |  | — |  |  | 730 |  |
| Other comprehensive income (loss) | $ | 3,894 |  |  | $ | 8,390 |  |  | $ | 134 |  |  | $ | (106) |  |  | $ | 12,312 |  |
| Balance as of December 29, 2023 | $ | 615 |  |  | $ | 4,849 |  |  | $ | (196) |  |  | $ | (1,071) |  |  | $ | 4,197 |  |

[0001408710-24-000009:notes:155]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 24, 2022 | $ | (6,018) |  |  | $ | (5,082) |  |  | $ | (803) |  |  | $ | (890) |  |  | $ | (12,793) |  |
| Other comprehensive income (loss) before reclassification | (371) |  |  | 12,588 |  |  | — |  |  | 162 |  |  | 12,379 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | 93 |  |  | (2,618) |  |  | 225 |  |  | — |  |  | (2,300) |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | $ | (278) |  |  | $ | 9,970 |  |  | $ | 225 |  |  | $ | 162 |  |  | $ | 10,079 |  |
| Balance as of December 30, 2022 | $ | (6,296) |  |  | $ | 4,888 |  |  | $ | (578) |  |  | $ | (728) |  |  | $ | (2,714) |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001408710-24-000009:notes:156]
Commitments and contingencies
Bank guarantees

[0001408710-24-000009:notes:157]
As of December 29, 2023 and June 30, 2023, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.1 million and $1.5 million, respectively, or Thai baht 73.2 million and 53.0 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the subsidiary's operations related to the Israeli Customs department.

[0001408710-24-000009:notes:158]
Purchase obligations

[0001408710-24-000009:notes:159]
Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001408710-24-000009:notes:160]
As of December 29, 2023, the Company had purchase obligations and other commitments to third parties of $1.00 billion.

[0001408710-24-000009:notes:161]
Capital expenditures

[0001408710-24-000009:notes:162]
As of December 29, 2023, the Company had total capital expenditure commitments to third parties of $13.1 million.

[0001408710-24-000009:notes:163]
Indemnification of directors and officers

[0001408710-24-000009:notes:164]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001408710-24-000009:notes:165]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001408710-24-000009:notes:166]
Business segments and geographic information
Operating segments are defined as components of an enterprise that engage in business activities for which discrete financial information is available that is evaluated regularly by the chief operating decision maker (the “CODM”) in deciding how to allocate resources and in assessing performance. The Company’s CODM is Fabrinet’s Chief Executive Officer. As of December 29, 2023, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001408710-24-000009:notes:167]
[same as prior period, unchanged from 0001408710-23-000036:notes:163]

[0001408710-24-000009:notes:168]
[same as prior period, unchanged from 0001408710-23-000036:notes:164]

[0001408710-24-000009:notes:169]
| (in thousands) |  | December 29,2023 |  | June 30,2023 |
| Long-Lived Assets: |  |  |  |  |
| Thailand |  | $ | 260,005 |  |  | $ | 264,382 |  |
| U.S. |  | 27,115 |  |  | 25,267 |  |
| China |  | 15,798 |  |  | 17,407 |  |
| Israel |  | 2,638 |  |  | 2,796 |  |
| Others |  | 463 |  |  | 498 |  |
| Total |  | $ | 306,019 |  |  | $ | 310,350 |  |

[0001408710-24-000009:notes:170]
[same as prior period, unchanged from 0001408710-23-000036:notes:166]

[0001408710-24-000009:notes:171]
The Company had two and three customers that each contributed to 10% or more of the Company's total trade accounts receivable as of December 29, 2023 and June 30, 2023, respectively.
