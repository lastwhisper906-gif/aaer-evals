# FN note change history — 0001408710-23-000036 → 0001408710-24-000009


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-02-06):
[0001408710-24-000009:note_history:1]
As of December 29, 2023 and June 30, 2023, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.1 million and $1.5 million, respectively, or Thai baht 73.2 million and 53.0 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the subsidiary's operations related to the Israeli Customs department.
  (was, 2023-11-07, similarity 0.9783):
[0001408710-23-000036:note_history:1]
As of September 29, 2023 and June 30, 2023, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.0 million and $1.5 million, respectively, or Thai baht 73.2 million and 53.0 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the operations related to the Israeli Customs department.

- changed (2024-02-06):
[0001408710-24-000009:note_history:2]
As of December 29, 2023, the Company had purchase obligations and other commitments to third parties of $1.00 billion.
  (was, 2023-11-07, similarity 0.9772):
[0001408710-23-000036:note_history:2]
As of September 29, 2023, the Company had purchase obligations and other commitments to third parties of $1.22 billion.

- changed (2024-02-06):
[0001408710-24-000009:note_history:3]
As of December 29, 2023, the Company had total capital expenditure commitments to third parties of $13.1 million.
  (was, 2023-11-07, similarity 0.9761):
[0001408710-23-000036:note_history:3]
As of September 29, 2023, the Company had total capital expenditure commitments to third parties of $12.3 million.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-02-06):
[0001408710-24-000009:note_history:4]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of December 29, 2023 and for the three and six months ended December 29, 2023 and December 30, 2022 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 30, 2023.
  (was, 2023-11-07, similarity 0.9669):
[0001408710-23-000036:note_history:4]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of September 29, 2023 and for the three months ended September 29, 2023 and September 30, 2022 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 30, 2023.

- changed (2024-02-06):
[0001408710-24-000009:note_history:5]
The results for the three and six months ended December 29, 2023 may not be indicative of results for the year ending June 28, 2024 or any future periods.
  (was, 2023-11-07, similarity 0.9537):
[0001408710-23-000036:note_history:5]
The results for the three months ended September 29, 2023 may not be indicative of results for the year ending June 28, 2024 or any future periods.

- changed (2024-02-06):
[0001408710-24-000009:note_history:6]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisitions, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information.
  (was, 2023-11-07, similarity 0.9878):
[0001408710-23-000036:note_history:6]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information.

- changed (2024-02-06):
[0001408710-24-000009:note_history:7]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  December 29, 2023 and December 30, 2022 consisted of 13 weeks. The six months ended December 29, 2023 and December 30, 2022 consisted of 26 and 27 weeks, respectively. Fiscal year 2024 will comprise 52 weeks and will end on June 28, 2024.
  (was, 2023-11-07, similarity 0.6808):
[0001408710-23-000036:note_history:7]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  September 29, 2023 and September 30, 2022 consisted of 13 and 14 weeks, respectively. Fiscal year 2024 will comprise 52 weeks and will end on June 28, 2024.

- changed (2024-02-06):
[0001408710-24-000009:note_history:8]
No new accounting standard was adopted during the first half of fiscal year 2024.
  (was, 2023-11-07, similarity 0.915):
[0001408710-23-000036:note_history:8]
No new accounting standard was adopted in the first quarter of fiscal year 2024.

- added (2024-02-06):
[0001408710-24-000009:note_history:9]
New Accounting Standards—not yet adopted by the Company

- added (2024-02-06):
[0001408710-24-000009:note_history:10]
In November 2023, the Financial Accounting Standards Board ("FASB") issued ASU 2023-07, “Segment Reporting (Topic 280), Improvements to Reportable Segment Disclosures,” which is intended to improve reportable segment disclosure requirements, primarily through additional disclosures about significant segment expenses. This ASU is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. This ASU will be effective for the Company in the first quarter of fiscal year 2025. The Company is currently assessing the impact to its disclosures.
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740), Improvements to Income Tax Disclosures,” which requires more detailed income tax disclosures. This ASU requires entities to disclose disaggregated information about their effective tax rate reconciliation as well as expanded information on income taxes paid by jurisdiction. This ASU is effective for all entities for fiscal years beginning after December 15, 2024, with early adoption permitted for annual financial statements that have not yet been issued or made available for issuance. This ASU will be effective for the Company in the first quarter of fiscal year 2026. The Company is currently assessing the impact to its disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-06):
[0001408710-24-000009:note_history:11]
| (in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofDecember 29, 2023 |  | As ofJune 30, 2023 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 6,094 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (16) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 6,078 |  |  | $ | 12,156 |  |
  (was, 2023-11-07, similarity 0.9927):
[0001408710-23-000036:note_history:11]
| (in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofSeptember 29, 2023 |  | As ofJune 30, 2023 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 9,141 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (24) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 9,117 |  |  | $ | 12,156 |  |

- changed (2024-02-06):
[0001408710-24-000009:note_history:12]
The movements of long-term borrowings for the six months ended December 29, 2023 and December 30, 2022 were as follows:
  (was, 2023-11-07, similarity 0.9189):
[0001408710-23-000036:note_history:12]
The movements of long-term borrowings for the three months ended September 29, 2023 and September 30, 2022 were as follows:

- changed (2024-02-06):
[0001408710-24-000009:note_history:13]
|  | Six Months Ended |
| (in thousands) | December 29,2023 |  | December 30,2022 |
| Opening balance | $ | 12,188 |  |  | $ | 27,421 |  |
| Repayments during the period | (6,094) |  |  | (9,140) |  |
| Closing balance | $ | 6,094 |  |  | $ | 18,281 |  |
  (was, 2023-11-07, similarity 0.8883):
[0001408710-23-000036:note_history:13]
|  | Three Months Ended |
| (in thousands) | September 29,2023 |  | September 30,2022 |
| Opening balance | $ | 12,188 |  |  | $ | 27,421 |  |
| Repayments during the period | (3,047) |  |  | (6,094) |  |
| Closing balance | $ | 9,141 |  |  | $ | 21,327 |  |

- changed (2024-02-06):
[0001408710-24-000009:note_history:14]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. On March 9, 2023, the Borrower and the Bank amended the Term Loan Agreement to replace the interest rate reference from LIBOR to the Secured Overnight Financing Rate ("SOFR") effective from September 29, 2023. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three and six months ended December 29, 2023, the Company recorded $0.1 million and $0.2 million, respectively, of interest expense in connection with this term loan, including the impact from interest rate swaps.
  (was, 2023-11-07, similarity 0.7729):
[0001408710-23-000036:note_history:14]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. On March 9, 2023, the Borrower and the Bank amended the Term Loan Agreement to replace the interest rate reference from LIBOR to the Secured Overnight Financing Rate ("SOFR") effective from September 29, 2023. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three months ended September 29, 2023, the Company recorded $0.1 million of interest expense in connection with this term loan, including the impact from interest rate swaps.

- changed (2024-02-06):
[0001408710-24-000009:note_history:15]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, and restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any
  (was, 2023-11-07, similarity 0.8897):
[0001408710-23-000036:note_history:15]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, and restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of September 29, 2023, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

- added (2024-02-06):
[0001408710-24-000009:note_history:16]
payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of December 29, 2023, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

- changed (2024-02-06):
[0001408710-24-000009:note_history:17]
As of December 29, 2023, there was $6.1 million outstanding under the term loan.
  (was, 2023-11-07, similarity 0.9655):
[0001408710-23-000036:note_history:17]
As of September 29, 2023, there was $9.1 million outstanding under the term loan.

- changed (2024-02-06):
[0001408710-24-000009:note_history:18]
As of December 29, 2023, there was no amount outstanding under the 2023 Credit Facility Agreement.
  (was, 2023-11-07, similarity 0.9721):
[0001408710-23-000036:note_history:18]
As of September 29, 2023, there was no amount outstanding under the 2023 Credit Facility Agreement.

- removed (2024-02-06):
[0001408710-23-000036:note_history:19]
As of September 29, 2023, future maturities of long-term borrowings during each fiscal year were as follows:

- removed (2024-02-06):
[0001408710-23-000036:note_history:20]
| (in thousands) |  |
| 2024 (remaining nine months) | $ | 9,141 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-06):
[0001408710-24-000009:note_history:21]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of December 29, 2023 and June 30, 2023:
  (was, 2023-11-07, similarity 0.9829):
[0001408710-23-000036:note_history:21]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of September 29, 2023 and June 30, 2023:

- changed (2024-02-06):
[0001408710-24-000009:note_history:22]
|  | December 29, 2023 |  | June 30, 2023 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 200,139 |  |  | $ | 201,672 |  |  | $ | 172,992 |  |  | $ | 173,137 |  |
| Due between one to five years | 205,784 |  |  | 204,868 |  |  | 149,385 |  |  | 145,963 |  |
| Total | $ | 405,923 |  |  | $ | 406,540 |  |  | $ | 322,377 |  |  | $ | 319,100 |  |
  (was, 2023-11-07, similarity 0.9884):
[0001408710-23-000036:note_history:22]
|  | September 29, 2023 |  | June 30, 2023 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 185,691 |  |  | $ | 186,414 |  |  | $ | 172,992 |  |  | $ | 173,137 |  |
| Due between one to five years | 179,066 |  |  | 176,014 |  |  | 149,385 |  |  | 145,963 |  |
| Total | $ | 364,757 |  |  | $ | 362,428 |  |  | $ | 322,377 |  |  | $ | 319,100 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-06):
[0001408710-24-000009:note_history:23]
The movements of long-term borrowings for the six months ended December 29, 2023 and December 30, 2022 were as follows:
  (was, 2023-11-07, similarity 0.9189):
[0001408710-23-000036:note_history:23]
The movements of long-term borrowings for the three months ended September 29, 2023 and September 30, 2022 were as follows:

- changed (2024-02-06):
[0001408710-24-000009:note_history:24]
|  | Six Months Ended |
| (in thousands) | December 29,2023 |  | December 30,2022 |
| Opening balance | $ | 12,188 |  |  | $ | 27,421 |  |
| Repayments during the period | (6,094) |  |  | (9,140) |  |
| Closing balance | $ | 6,094 |  |  | $ | 18,281 |  |
  (was, 2023-11-07, similarity 0.8883):
[0001408710-23-000036:note_history:24]
|  | Three Months Ended |
| (in thousands) | September 29,2023 |  | September 30,2022 |
| Opening balance | $ | 12,188 |  |  | $ | 27,421 |  |
| Repayments during the period | (3,047) |  |  | (6,094) |  |
| Closing balance | $ | 9,141 |  |  | $ | 21,327 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-02-06):
[0001408710-24-000009:note_history:25]
| (in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofDecember 29, 2023 |  | As ofJune 30, 2023 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 6,094 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (16) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 6,078 |  |  | $ | 12,156 |  |
  (was, 2023-11-07, similarity 0.9927):
[0001408710-23-000036:note_history:25]
| (in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofSeptember 29, 2023 |  | As ofJune 30, 2023 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 9,141 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (24) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 9,117 |  |  | $ | 12,156 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2024-02-06):
[0001408710-23-000036:note_history:26]
As of September 29, 2023, future maturities of long-term borrowings during each fiscal year were as follows:

- removed (2024-02-06):
[0001408710-23-000036:note_history:27]
| (in thousands) |  |
| 2024 (remaining nine months) | $ | 9,141 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-02-06):
[0001408710-24-000009:note_history:28]
| (in thousands, except percentages) | Three Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |  | Six Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 238,288 |  |  |  |  | $ | 493,147 |  |  |  |
| Others (1) | 3,331 |  |  |  |  | 6,791 |  |  |  |
| Total revenue in North America | 241,619 |  |  | 33.9 | % |  | 499,938 |  |  | 35.8 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel (2) | 267,038 |  |  |  |  | 477,714 |  |  |  |
| India | 75,033 |  |  |  |  | 145,810 |  |  |  |
| Malaysia | 36,626 |  |  |  |  | 69,945 |  |  |  |
| China | 21,262 |  |  |  |  | 41,522 |  |  |  |
| Hong Kong | 12,150 |  |  |  |  | 27,938 |  |  |  |
| Thailand | 10,403 |  |  |  |  | 23,430 |  |  |  |
| Japan | 5,826 |  |  |  |  | 12,636 |  |  |  |
| Others | 1,570 |  |  |  |  | 2,735 |  |  |  |
| Total revenue in Asia-Pacific and others | 429,908 |  |  | 60.3 | % |  | 801,730 |  |  | 57.3 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 18,870 |  |  |  |  | 48,644 |  |  |  |
| Germany | 10,395 |  |  |  |  | 23,175 |  |  |  |
| Others | 11,902 |  |  |  |  | 24,684 |  |  |  |
| Total revenue in Europe | $ | 41,167 |  |  | 5.8 | % |  | $ | 96,503 |  |  | 6.9 | % |
| Total revenue | $ | 712,694 |  |  | 100.0 | % |  | $ | 1,398,171 |  |  | 100.0 | % |
  (was, 2023-11-07, similarity 0.9888):
[0001408710-23-000036:note_history:28]
| (in thousands, except percentages) | Three Months EndedSeptember 29, 2023 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 30, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 254,859 |  |  |  |  | $ | 345,080 |  |  |  |
| Others (1) | 3,460 |  |  |  |  | 3,624 |  |  |  |
| Total revenue in North America | 258,319 |  |  | 37.7 | % |  | 348,704 |  |  | 53.2 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel (2) | 210,676 |  |  |  |  | 37,277 |  |  |  |
| India | 70,777 |  |  |  |  | 80,033 |  |  |  |
| Malaysia | 33,319 |  |  |  |  | 49,324 |  |  |  |
| China | 20,260 |  |  |  |  | 23,064 |  |  |  |
| Hong Kong | 15,788 |  |  |  |  | 32,472 |  |  |  |
| Thailand | 13,027 |  |  |  |  | 12,616 |  |  |  |
| Japan | 6,810 |  |  |  |  | 10,348 |  |  |  |
| Others | 1,165 |  |  |  |  | 3,160 |  |  |  |
| Total revenue in Asia-Pacific and others | 371,822 |  |  | 54.2 | % |  | 248,294 |  |  | 37.9 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 29,774 |  |  |  |  | 32,832 |  |  |  |
| Germany | 12,780 |  |  |  |  | 13,314 |  |  |  |
| Others | 12,782 |  |  |  |  | 12,285 |  |  |  |
| Total revenue in Europe | $ | 55,336 |  |  | 8.1 | % |  | $ | 58,431 |  |  | 8.9 | % |
| Total revenue | $ | 685,477 |  |  | 100.0 | % |  | $ | 655,429 |  |  | 100.0 | % |

- added (2024-02-06):
[0001408710-24-000009:note_history:29]
| (in thousands, except percentages) | Three Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |  | Six Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 319,918 |  |  |  |  | $ | 664,998 |  |  |  |
| Others (1) | 4,033 |  |  |  |  | 7,657 |  |  |  |
| Total revenue in North America | 323,951 |  |  | 48.5 | % |  | 672,655 |  |  | 50.8 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 82,178 |  |  |  |  | 162,211 |  |  |  |
| Israel | 59,893 |  |  |  |  | 97,170 |  |  |  |
| Malaysia | 50,390 |  |  |  |  | 99,714 |  |  |  |
| Hong Kong | 39,723 |  |  |  |  | 72,195 |  |  |  |
| China | 26,480 |  |  |  |  | 49,544 |  |  |  |
| Thailand | 16,098 |  |  |  |  | 28,714 |  |  |  |
| Japan | 11,737 |  |  |  |  | 22,085 |  |  |  |
| Others | 1,901 |  |  |  |  | 5,061 |  |  |  |
| Total revenue in Asia-Pacific and others | 288,400 |  |  | 43.1 | % |  | 536,694 |  |  | 40.5 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 30,316 |  |  |  |  | 63,148 |  |  |  |
| Germany | 13,129 |  |  |  |  | 26,443 |  |  |  |
| Others | 12,860 |  |  |  |  | 25,145 |  |  |  |
| Total revenue in Europe | $ | 56,305 |  |  | 8.4 | % |  | $ | 114,736 |  |  | 8.7 | % |
| Total revenue | $ | 668,656 |  |  | 100.0 | % |  | $ | 1,324,085 |  |  | 100.0 | % |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-02-06):
[0001408710-24-000009:note_history:30]
A contract asset is recognized when the Company has recognized revenues, but has not yet issued an invoice to its customer for payment. Contract assets are recognized in the unaudited condensed consolidated balance sheets under other current assets and transferred to accounts receivable when rights to payment become unconditional.
  (was, 2023-11-07, similarity 0.9226):
[0001408710-23-000036:note_history:30]
A contract asset is recognized when the Company has recognized revenues prior to an invoice for payment. Contract assets are recognized in the unaudited condensed consolidated balance sheets under other current assets and transferred to accounts receivable when rights to payment become unconditional.

- changed (2024-02-06):
[0001408710-24-000009:note_history:31]
As of December 29, 2023 and June 30, 2023, the Company's contract assets are de minimis.
  (was, 2023-11-07, similarity 0.8966):
[0001408710-23-000036:note_history:31]
As of September 29, 2023 and June 30, 2023, the contract assets are de minimis.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-02-06):
[0001408710-24-000009:note_history:32]
| (in thousands, except percentages) | Three Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |  | Six Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 238,288 |  |  |  |  | $ | 493,147 |  |  |  |
| Others (1) | 3,331 |  |  |  |  | 6,791 |  |  |  |
| Total revenue in North America | 241,619 |  |  | 33.9 | % |  | 499,938 |  |  | 35.8 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel (2) | 267,038 |  |  |  |  | 477,714 |  |  |  |
| India | 75,033 |  |  |  |  | 145,810 |  |  |  |
| Malaysia | 36,626 |  |  |  |  | 69,945 |  |  |  |
| China | 21,262 |  |  |  |  | 41,522 |  |  |  |
| Hong Kong | 12,150 |  |  |  |  | 27,938 |  |  |  |
| Thailand | 10,403 |  |  |  |  | 23,430 |  |  |  |
| Japan | 5,826 |  |  |  |  | 12,636 |  |  |  |
| Others | 1,570 |  |  |  |  | 2,735 |  |  |  |
| Total revenue in Asia-Pacific and others | 429,908 |  |  | 60.3 | % |  | 801,730 |  |  | 57.3 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 18,870 |  |  |  |  | 48,644 |  |  |  |
| Germany | 10,395 |  |  |  |  | 23,175 |  |  |  |
| Others | 11,902 |  |  |  |  | 24,684 |  |  |  |
| Total revenue in Europe | $ | 41,167 |  |  | 5.8 | % |  | $ | 96,503 |  |  | 6.9 | % |
| Total revenue | $ | 712,694 |  |  | 100.0 | % |  | $ | 1,398,171 |  |  | 100.0 | % |
  (was, 2023-11-07, similarity 0.9888):
[0001408710-23-000036:note_history:32]
| (in thousands, except percentages) | Three Months EndedSeptember 29, 2023 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 30, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 254,859 |  |  |  |  | $ | 345,080 |  |  |  |
| Others (1) | 3,460 |  |  |  |  | 3,624 |  |  |  |
| Total revenue in North America | 258,319 |  |  | 37.7 | % |  | 348,704 |  |  | 53.2 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel (2) | 210,676 |  |  |  |  | 37,277 |  |  |  |
| India | 70,777 |  |  |  |  | 80,033 |  |  |  |
| Malaysia | 33,319 |  |  |  |  | 49,324 |  |  |  |
| China | 20,260 |  |  |  |  | 23,064 |  |  |  |
| Hong Kong | 15,788 |  |  |  |  | 32,472 |  |  |  |
| Thailand | 13,027 |  |  |  |  | 12,616 |  |  |  |
| Japan | 6,810 |  |  |  |  | 10,348 |  |  |  |
| Others | 1,165 |  |  |  |  | 3,160 |  |  |  |
| Total revenue in Asia-Pacific and others | 371,822 |  |  | 54.2 | % |  | 248,294 |  |  | 37.9 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 29,774 |  |  |  |  | 32,832 |  |  |  |
| Germany | 12,780 |  |  |  |  | 13,314 |  |  |  |
| Others | 12,782 |  |  |  |  | 12,285 |  |  |  |
| Total revenue in Europe | $ | 55,336 |  |  | 8.1 | % |  | $ | 58,431 |  |  | 8.9 | % |
| Total revenue | $ | 685,477 |  |  | 100.0 | % |  | $ | 655,429 |  |  | 100.0 | % |

- added (2024-02-06):
[0001408710-24-000009:note_history:33]
| (in thousands, except percentages) | Three Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |  | Six Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 319,918 |  |  |  |  | $ | 664,998 |  |  |  |
| Others (1) | 4,033 |  |  |  |  | 7,657 |  |  |  |
| Total revenue in North America | 323,951 |  |  | 48.5 | % |  | 672,655 |  |  | 50.8 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 82,178 |  |  |  |  | 162,211 |  |  |  |
| Israel | 59,893 |  |  |  |  | 97,170 |  |  |  |
| Malaysia | 50,390 |  |  |  |  | 99,714 |  |  |  |
| Hong Kong | 39,723 |  |  |  |  | 72,195 |  |  |  |
| China | 26,480 |  |  |  |  | 49,544 |  |  |  |
| Thailand | 16,098 |  |  |  |  | 28,714 |  |  |  |
| Japan | 11,737 |  |  |  |  | 22,085 |  |  |  |
| Others | 1,901 |  |  |  |  | 5,061 |  |  |  |
| Total revenue in Asia-Pacific and others | 288,400 |  |  | 43.1 | % |  | 536,694 |  |  | 40.5 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 30,316 |  |  |  |  | 63,148 |  |  |  |
| Germany | 13,129 |  |  |  |  | 26,443 |  |  |  |
| Others | 12,860 |  |  |  |  | 25,145 |  |  |  |
| Total revenue in Europe | $ | 56,305 |  |  | 8.4 | % |  | $ | 114,736 |  |  | 8.7 | % |
| Total revenue | $ | 668,656 |  |  | 100.0 | % |  | $ | 1,324,085 |  |  | 100.0 | % |

- changed (2024-02-06):
[0001408710-24-000009:note_history:34]
| (in thousands, except percentages) | Three Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |  | Six Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |
| Optical communications | $ | 567,934 |  |  | 79.7 | % |  | $ | 1,101,191 |  |  | 78.8 | % |
| Automotive, lasers and other | 144,760 |  |  | 20.3 | % |  | 296,980 |  |  | 21.2 | % |
| Total | $ | 712,694 |  |  | 100.0 | % |  | $ | 1,398,171 |  |  | 100.0 | % |
  (was, 2023-11-07, similarity 0.9314):
[0001408710-23-000036:note_history:34]
| (in thousands, except percentages) | Three Months EndedSeptember 29, 2023 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 30, 2022 |  | As a % of TotalRevenues |
| Optical communications | $ | 533,257 |  |  | 77.8 | % |  | $ | 497,561 |  |  | 75.9 | % |
| Automotive, lasers and other | 152,220 |  |  | 22.2 | % |  | 157,868 |  |  | 24.1 | % |
| Total | $ | 685,477 |  |  | 100.0 | % |  | $ | 655,429 |  |  | 100.0 | % |

- added (2024-02-06):
[0001408710-24-000009:note_history:35]
| (in thousands, except percentages) | Three Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |  | Six Months EndedDecember 30, 2022 |  | As a % of TotalRevenues |
| Optical communications | $ | 506,056 |  |  | 75.7 | % |  | $ | 1,003,617 |  |  | 75.8 | % |
| Automotive, lasers and other | 162,600 |  |  | 24.3 | % |  | 320,468 |  |  | 24.2 | % |
| Total | $ | 668,656 |  |  | 100.0 | % |  | $ | 1,324,085 |  |  | 100.0 | % |

- changed (2024-02-06):
[0001408710-24-000009:note_history:36]
A contract asset is recognized when the Company has recognized revenues, but has not yet issued an invoice to its customer for payment. Contract assets are recognized in the unaudited condensed consolidated balance sheets under other current assets and transferred to accounts receivable when rights to payment become unconditional.
  (was, 2023-11-07, similarity 0.9226):
[0001408710-23-000036:note_history:36]
A contract asset is recognized when the Company has recognized revenues prior to an invoice for payment. Contract assets are recognized in the unaudited condensed consolidated balance sheets under other current assets and transferred to accounts receivable when rights to payment become unconditional.

- changed (2024-02-06):
[0001408710-24-000009:note_history:37]
As of December 29, 2023 and June 30, 2023, the Company's contract assets are de minimis.
  (was, 2023-11-07, similarity 0.8966):
[0001408710-23-000036:note_history:37]
As of September 29, 2023 and June 30, 2023, the contract assets are de minimis.

- changed (2024-02-06):
[0001408710-24-000009:note_history:38]
The following tables summarize the activity in the Company’s contract liabilities during the six months ended December 29, 2023:
  (was, 2023-11-07, similarity 0.9478):
[0001408710-23-000036:note_history:38]
The following tables summarize the activity in the Company’s contract liabilities during the three months ended September 29, 2023:

- changed (2024-02-06):
[0001408710-24-000009:note_history:39]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 30, 2023 | $ | 3,036 |  |
| Advance payments received during the period | 7,610 |  |
| Revenue recognized | (4,325) |  |
| Ending balance, December 29, 2023 | $ | 6,321 |  |
  (was, 2023-11-07, similarity 0.981):
[0001408710-23-000036:note_history:39]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 30, 2023 | $ | 3,036 |  |
| Advance payment received during the period | 1,497 |  |
| Revenue recognized | (3,285) |  |
| Ending balance, September 29, 2023 | $ | 1,248 |  |
