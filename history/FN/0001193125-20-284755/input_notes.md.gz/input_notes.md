# FN notes — 0001193125-20-284755


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-20-284755:notes:1]
[same as prior period, unchanged from 0001193125-20-133708:notes:1]

[0001193125-20-284755:notes:2]
[same as prior period, unchanged from 0001193125-20-133708:notes:2]

[0001193125-20-284755:notes:3]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as 
of
 September 25, 2020 and for the three months ended September 25, 2020 and September 27, 2019 includes normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 
10-K
 for the year ended June 26, 2020.

[0001193125-20-284755:notes:4]
The balance sheet as 
of
 June 26, 2020 has been derived from the audited financial statements at that date but does not include all of the information and footnotes required by U.S. GAAP for complete financial statements.

[0001193125-20-284755:notes:5]
The results for the three months ended September 25, 2020 may not be indicative of results for the year ending June 25, 2021 or any future periods.

[0001193125-20-284755:notes:6]
Use of Estimates

[0001193125-20-284755:notes:7]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements, and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information. Additionally, the extent to which the evolving 
COVID-19
 pandemic impacts the Company’s unaudited condensed consolidated financial statements will depend on a number of factors, including the magnitude and duration of the pandemic. These estimates may change, as new events occur and additional information is obtained, as well as other factors related to the 
COVID-19
 pandemic that could result in material impacts to our unaudited condensed consolidated financial statements in future reporting periods.

[0001193125-20-284755:notes:8]
[same as prior period, unchanged from 0001193125-20-133708:notes:8]

[0001193125-20-284755:notes:9]
The Company utilizes a 
52-53
 week fiscal year ending on the Friday in June closest to June 30. The three months ended September 25, 2020 and September 27, 2019 each consisted of 13 weeks. Fiscal year 
2021 
will be comprised of 52 weeks and will end on June 25, 2021.

[0001193125-20-284755:notes:10]
[same as prior period, unchanged from 0001193125-20-133708:notes:11]

[0001193125-20-284755:notes:11]
For presentation purposes, certain prior period amounts have been reclassified to conform to the current period presentation.

[0001193125-20-284755:notes:12]
As of June 26, 2020, the derivative assets and liabilities were measured at fair value and recognized by offsetting the fair value amounts under master netting arrangements. Also, the Company chose not to separate a derivative into current and 
non-current
 portions as follows:

[0001193125-20-284755:notes:13]
|  | (i) | A derivative for which the fair value is a net liability is classified in total as a current liability. |

[0001193125-20-284755:notes:14]
|  | (ii) | A derivative for which the fair value is a net asset and the current portion is an asset is classified in total as a non-current asset. If the current portion is a liability, it is presented as a current liability. |

[0001193125-20-284755:notes:15]
As of September 25, 2020, the derivative assets and liabilities were measured at fair value, but the gross fair value amount is presented in the unaudited condensed consolidated balance sheets. Additionally, a classification of current and 
non-current
 portion is determined by the maturity date of that derivative (e.g., a derivative that matures within one year is classified as current).

[0001193125-20-284755:notes:16]
The reclassifications have been made to the consolidated balance sheet as of June 26, 2020 as shown in the following table:

[0001193125-20-284755:notes:17]
|  |  | June 26, 2020 |  |
| (amount in thousands) |  | As previously reported |  |  | Reclassification |  |  | After reclassification |  |
| Consolidated Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current assets |  | $ | 13,915 |  |  | $ | 593 |  |  | $ | 14,508 |  |
| Current liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 12,104 |  |  | $ | (3,125 | ) |  | $ | 8,979 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other non-current liabilities |  | $ | 1,937 |  |  | $ | 3,718 |  |  | $ | 5,655 |  |

[0001193125-20-284755:notes:18]
Adoption of New Accounting Standards

[0001193125-20-284755:notes:19]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 
2016-13,
 “Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments.” This standard requires the measurement and recognition of expected credit losses for financial assets held at amortized cost. The standard replaces the existing incurred loss impairment model with an expected loss methodology, which will result in more timely recognition of credit losses. The new standard also expands the required quantitative and qualitative disclosures surrounding expected credit losses.

[0001193125-20-284755:notes:20]
On June 27, 2020, the Company adopted Accounting Standards Codification (“ASC”) 326 using the modified retrospective transition approach. The modified retrospective method requires the Company to recognize the cumulative effect of the adoption of ASC 326, to the opening accumulated retained earnings. Accordingly, the Company’s comparative financial statements as of June 26, 2020 have not been adjusted. The Company implemented internal controls to enable the preparation of financial information upon adoption.

[0001193125-20-284755:notes:21]
Management estimates the expected credit losses of financial assets using relevant available information from internal and external sources relating to historical credit loss experience, current conditions and reasonable forecasts over a financial asset’s contractual term. Adjustments to historical loss information are made from qualitative and quantitative factors if economic conditions on the reporting date reflect stronger or weaker economic performance than the historical data implies based on management’s expectations of economic conditions on certain indicators of the Company, industry and economy. The Company reviews factors such as past collection experience, age of the accounts receivable and contract assets balance, significant trends in current balances, internal operations and macroeconomic conditions. In addition, the Company modified its impairment model to the Current Expected Credit Losses (“CECL”) model for

[0001193125-20-284755:notes:22]
available-for-sale

[0001193125-20-284755:notes:23]
(“AFS”) debt securities and discontinued using the concept of “other than temporary” impairment on these AFS debt securities. CECL on the AFS debt securities are recognized in interest income and other income (expense), net on the Company’s unaudited condensed consolidated statements of operations and comprehensive income, and any remaining unrealized losses, are included in accumulated other comprehensive loss (“AOCI”) in the unaudited condensed consolidated balance sheet.

[0001193125-20-284755:notes:24]
As of June 27, 2020, the Company recorded a cumulative adjustment from CECL in the amount of $0.1 million, net of tax impact, to accumulated retained earnings in the unaudited condensed consolidated balance sheet.

[0001193125-20-284755:notes:25]
On June 27, 2020, the Company also adopted ASC 820, “Disclosure Framework – Changes to the Disclosure Requirements for Fair Value Measurement.” This standard is intended to improve the effectiveness of disclosures in the notes to the financial statements, including (1) the development of a framework that promotes consistent decisions by the FASB about disclosure requirements and (2) the appropriate exercise of discretion by reporting entities. The amendment modifies the disclosure requirements on transferring between level 1 and level 2 and valuation processes of level 3 fair value measurements. The Company adopted this standard with no impact on its unaudited condensed consolidated financial statements.

[0001193125-20-284755:notes:26]
Changes in Accounting Policies

[0001193125-20-284755:notes:27]
Except for the adoption of ASC 326, the Company has consistently applied the accounting policies to all periods presented in these unaudited condensed consolidated financial statements.

[0001193125-20-284755:notes:28]
Short-term investments

[0001193125-20-284755:notes:29]
Management determines the appropriate classification of its investments at the time of purchase and 
re-evaluates
 the designations at each balance sheet date. The Company may sell certain of the Company’s short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s short-term investments generally range from three months to three years. The Company’s short-term investments, which consist of investments in U.S. Treasury, fixed income securities, liquidity funds that invest in short-term debt securities and certificates of deposit and time deposits, have been classified and accounted for as AFS. The AFS investments are carried at estimated fair value with any unrealized gains and losses, included in AOCI in the Company’s unaudited condensed consolidated balance sheet. The Company determines realized gains or losses on sale of marketable securities on a specific identification method and records such gains or losses as interest income and other income (expense), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-20-284755:notes:30]
AFS debt securities are required to be individually evaluated for impairment. A security is considered impaired if the fair value of the security is less than its amortized cost basis.

[0001193125-20-284755:notes:31]
An impairment is considered other than temporary if (i) the Company has the intent to sell the security, (ii) it is more likely than not that the Company will be required to sell the security before recovery of the entire amortized cost basis, or (iii) the Company does not expect to recover the entire amortized cost basis of the security.

[0001193125-20-284755:notes:32]
If an impairment is considered other than temporary based on condition (i) or (ii), the entire difference between the amortized cost and the fair value of the debt security is recognized as interest income and other income (expense), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-20-284755:notes:33]
If an impairment is considered other than temporary based on condition (iii), the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) is recognized in interest and other income (expense), net in the unaudited condensed consolidated statements of operations and comprehensive income, and any remaining unrealized losses are included in AOCI in the unaudited condensed consolidated balance sheet.

[0001193125-20-284755:notes:34]
Trade accounts receivable

[0001193125-20-284755:notes:35]
Accounts receivable are recorded and carried at the original invoiced amount less an allowance for any potential uncollectible amounts. The Company makes estimates of expected credit losses for the allowance for doubtful accounts based upon its assessment of various factors, including historical experience, the age of the accounts receivable balances, credit quality of its customers, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect the Company’s ability to collect from customers. The estimated credit loss allowance is recorded as selling, general and administrative expenses in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-20-284755:notes:36]
Contract assets

[0001193125-20-284755:notes:37]
A contract asset is recognized when the Company has recognized revenues prior to generating an invoice for payment. Contract assets are classified separately within the unaudited condensed consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. The Company makes estimates of expected credit losses for the allowance for contract assets based upon its assessment of various factors, including historical experience, the age of the contract assets balances, credit quality of its customers, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect the Company’s ability to collect from customers. The estimated credit loss allowance is recorded as selling, general and administrative expenses in its unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-20-284755:notes:38]
Concentration of credit risk

[0001193125-20-284755:notes:39]
[same as prior period, unchanged from 0001193125-20-133708:notes:16]

[0001193125-20-284755:notes:40]
[same as prior period, unchanged from 0001193125-20-133708:notes:17]

[0001193125-20-284755:notes:41]
The Company enters into derivative contracts with financial institutions with reputable credit and monitors the credit profiles of these counterparties.

[0001193125-20-284755:notes:42]
[same as prior period, unchanged from 0001193125-20-133708:notes:19]

[0001193125-20-284755:notes:43]
New Accounting Pronouncements – not yet adopted by the Company

[0001193125-20-284755:notes:44]
In December 2019, the FASB issued ASU 
2019-12,
 “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.” The amendments in this update simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify U.S. GAAP for other areas of Topic 740 by clarifying and amending existing guidance. For public business entities, the amendments in this update are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2020. This ASU will be effective for the Company in the first quarter of fiscal year 2022. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its unaudited condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001193125-20-284755:notes:45]
[same as prior period, unchanged from 0001193125-20-133708:notes:33]

[0001193125-20-284755:notes:46]
Revenue by Geographic Area and End Market

[0001193125-20-284755:notes:47]
Revenues are attributed to a particular geographic area based on

[0001193125-20-284755:notes:48]
the bill-to-location of

[0001193125-20-284755:notes:49]
the Company’s customers. The Company operates in three geographic regions: North America, Asia-Pacific and Europe.

[0001193125-20-284755:notes:50]
The following table presents total revenues by geographic region:

[0001193125-20-284755:notes:51]
| (amount in thousands, except percentages) |  | Three Months Ended September 25, 2020 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 207,402 |  |  |  | 47.5 | % |
| Asia-Pacific |  |  | 145,646 |  |  |  | 33.4 |  |
| Europe |  |  | 83,591 |  |  |  | 19.1 |  |
|  |  | $ | 436,639 |  |  |  | 100.0 | % |

[0001193125-20-284755:notes:52]
| (amount in thousands, except percentages) |  | Three Months Ended September 27, 2019 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 200,947 |  |  |  | 50.3 | % |
| Asia-Pacific |  |  | 118,423 |  |  |  | 29.7 |  |
| Europe |  |  | 79,926 |  |  |  | 20.0 |  |
|  |  | $ | 399,296 |  |  |  | 100.0 | % |

[0001193125-20-284755:notes:53]
| (amount in thousands, except percentages) |  | Three Months Ended September 25, 2020 |  |  | As a % of Total Revenues |  |
| Optical communications |  | $ | 343,917 |  |  |  | 78.8 | % |
| Lasers, sensors and other |  |  | 92,722 |  |  |  | 21.2 |  |
| Total |  | $ | 436,639 |  |  |  | 100.0 | % |

[0001193125-20-284755:notes:54]
| (amount in thousands, except percentages) |  | Three Months Ended September 27, 2019 |  |  | As a % of Total Revenues |  |
| Optical communications |  | $ | 302,379 |  |  |  | 75.7 | % |
| Lasers, sensors and other |  |  | 96,917 |  |  |  | 24.3 |  |
| Total |  | $ | 399,296 |  |  |  | 100.0 | % |

[0001193125-20-284755:notes:55]
Contract Assets and Liabilities

[0001193125-20-284755:notes:56]
A contract asset is recognized when the Company has recognized revenues prior to generating an invoice for payment. Contract assets are classified separately within the unaudited condensed consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional.

[0001193125-20-284755:notes:57]
[same as prior period, unchanged from 0001193125-20-133708:notes:45]

[0001193125-20-284755:notes:58]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the three months ended September 25, 2020:

[0001193125-20-284755:notes:59]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 26, 2020 |  | $ | 13,256 |  |
| Revenue recognized |  |  | 17,444 |  |
| Amounts collected or invoiced |  |  | (18,943 | ) |
| Ending balance, September 25, 2020 |  | $ | 11,757 |  |

[0001193125-20-284755:notes:60]
| (amount in thousands) |  | Contract Liabilities |  |
| Beginning balance, June 26, 2020 |  | $ | 1,556 |  |
| Additions advance payment received during the period |  |  | 4,308 |  |
| Revenue recognized |  |  | (4,898 | ) |
| Ending balance, September 25, 2020 |  | $ | 966 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001193125-20-284755:notes:61]
The following table presents revenues by end market.


## us-gaap:EarningsPerShareTextBlock

[0001193125-20-284755:notes:62]
[same as prior period, unchanged from 0001193125-20-133708:notes:63]

[0001193125-20-284755:notes:63]
Basic earnings per ordinary share is computed by dividing reported net income by the weighted-average number of ordinary shares outstanding during each period. Diluted earnings per ordinary share is computed by calculating the effect of potential dilutive ordinary shares outstanding during the period using the treasury stock method. Dilutive ordinary equivalent shares consist of restricted share units and performance share units.

[0001193125-20-284755:notes:64]
Earnings per ordinary share was calculated as follows:

[0001193125-20-284755:notes:65]
|  |  | Three Months Ended |  |
| (amount in thousands except per share amounts) |  | September 25, 2020 |  |  | September 27, 2019 |  |
| Net income attributable to shareholders |  | $ | 33,051 |  |  | $ | 25,957 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  | 36,818 |  |  |  | 36,913 |  |
| Incremental shares arising from the assumed vesting of restricted share units and performance share units (thousands of shares) |  |  | 565 |  |  |  | 616 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 37,383 |  |  |  | 37,529 |  |
| Basic earnings per ordinary share |  | $ | 0.90 |  |  | $ | 0.70 |  |
| Diluted earnings per ordinary share |  | $ | 0.88 |  |  | $ | 0.69 |  |
| Outstanding performance share units excluded from the computation of diluted earnings per ordinary share (thousands of shares) (1) |  |  | 61 |  |  |  | 50 |  |

[0001193125-20-284755:notes:66]
[same as prior period, unchanged from 0001193125-20-133708:notes:66]


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001193125-20-284755:notes:67]
[same as prior period, unchanged from 0001193125-20-133708:notes:67]

[0001193125-20-284755:notes:68]
The Company’s cash, cash equivalents, and short-term investments are as follows:

[0001193125-20-284755:notes:69]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Gain/ (Loss) |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |  | Other Investments |  |
| As of September 25, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 175,550 |  |  | $ | — |  |  | $ | 175,550 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 13,651 |  |  |  | — |  |  |  | 13,651 |  |  |  | — |  |  |  | — |  |
| Liquidity funds |  |  | 41,151 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 41,151 |  |
| Certificates of deposit and time deposits |  |  | 22,300 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 22,300 |  |
| Corporate debt securities |  |  | 192,509 |  |  |  | 739 |  |  |  | — |  |  |  | 193,248 |  |  |  | — |  |
| U.S. agency and U.S. treasury securities |  |  | 50,113 |  |  |  | 426 |  |  |  | — |  |  |  | 50,539 |  |  |  | — |  |
| Total |  | $ | 495,274 |  |  | $ | 1,165 |  |  | $ | 189,201 |  |  | $ | 243,787 |  |  | $ | 63,451 |  |
| As of June 26, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 218,117 |  |  | $ | — |  |  | $ | 218,117 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 7,313 |  |  |  | — |  |  |  | 7,313 |  |  |  | — |  |  |  | — |  |
| Liquidity funds |  |  | 41,051 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 41,051 |  |
| Certificates of deposit and time deposits |  |  | 11,800 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 11,800 |  |
| Corporate debt securities |  |  | 159,220 |  |  |  | 948 |  |  |  | — |  |  |  | 160,168 |  |  |  | — |  |
| U.S. agency and U.S. treasury securities |  |  | 49,130 |  |  |  | 544 |  |  |  | — |  |  |  | 49,674 |  |  |  | — |  |
| Total |  | $ | 486,631 |  |  | $ | 1,492 |  |  | $ | 225,430 |  |  | $ | 209,842 |  |  | $ | 52,851 |  |

[0001193125-20-284755:notes:70]
All highly liquid investments with original maturities of three months or less at the date of purchase are classified as cash equivalents. Management determines the appropriate classification of its investments at the time of purchase and 
re-evaluates
 the designations at each balance sheet date. The Company may sell certain of its short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s short-term investments generally range from three months to three years.

[0001193125-20-284755:notes:71]
The following table summarizes the cost and estimated fair value of short-term investments classified as

[0001193125-20-284755:notes:72]
securities based on stated effective maturities as 
of
 September 25, 2020:

[0001193125-20-284755:notes:73]
|  |  | September 25, 2020 |  |  | June 26, 2020 |  |
| (amount in thousands) |  | Carrying Cost |  |  | Fair Value |  |  | Carrying Cost |  |  | Fair Value |  |
| Due within one year |  | $ | 104,723 |  |  | $ | 104,756 |  |  | $ | 76,127 |  |  | $ | 76,196 |  |
| Due between one to five years |  |  | 137,899 |  |  |  | 139,031 |  |  |  | 132,223 |  |  |  | 133,646 |  |
| Total |  | $ | 242,622 |  |  | $ | 243,787 |  |  | $ | 208,350 |  |  | $ | 209,842 |  |

[0001193125-20-284755:notes:74]
As of September 25, 2020, the Company considered the declines in market value of its short-term investments portfolio to be temporary in nature and did not consider any of its securities other-than-temporarily impaired.


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-20-284755:notes:75]
[same as prior period, unchanged from 0001193125-20-133708:notes:75]

[0001193125-20-284755:notes:76]
Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. A fair value hierarchy is established which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs for the valuation of an asset or liability as of the measurement date. The three levels of inputs that may be used to measure fair value are defined as follows:

[0001193125-20-284755:notes:77]
[same as prior period, unchanged from 0001193125-20-133708:notes:77]

[0001193125-20-284755:notes:78]
[same as prior period, unchanged from 0001193125-20-133708:notes:78]

[0001193125-20-284755:notes:79]
[same as prior period, unchanged from 0001193125-20-133708:notes:79]

[0001193125-20-284755:notes:80]
[same as prior period, unchanged from 0001193125-20-133708:notes:80]

[0001193125-20-284755:notes:81]
[same as prior period, unchanged from 0001193125-20-133708:notes:81]

[0001193125-20-284755:notes:82]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of September 25, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 13,651 |  |  | $ | — |  |  | $ | 13,651 |  |
| Liquidity funds |  |  | — |  |  |  | 41,151 |  |  |  | — |  |  |  | 41,151 |  |
| Certificates of deposit and time deposits |  |  | — |  |  |  | 22,300 |  |  |  | — |  |  |  | 22,300 |  |
| Corporate debt securities |  |  | — |  |  |  | 193,248 |  |  |  | — |  |  |  | 193,248 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 50,539 |  |  |  | — |  |  |  | 50,539 |  |
| Derivative assets |  |  | — |  |  |  | 694 | (1) |  |  | — |  |  |  | 694 |  |
| Total |  | $ | — |  |  | $ | 321,583 |  |  | $ | — |  |  | $ | 321,583 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion |  | $ | — |  |  | $ | 2,426 |  |  | $ | — |  |  | $ | 2,426 |  |
| Derivative liabilities – non-current portion |  |  | — |  |  |  | 3,305 |  |  |  | — |  |  |  | 3,305 |  |
| Total |  | $ | — |  |  | $ | 5,731 | (2) |  | $ | — |  |  | $ | 5,731 |  |

[0001193125-20-284755:notes:83]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 26, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 7,313 |  |  | $ | — |  |  | $ | 7,313 |  |
| Liquidity funds |  |  | — |  |  |  | 41,051 |  |  |  | — |  |  |  | 41,051 |  |
| Certificates of deposit and time deposits |  |  | — |  |  |  | 11,800 |  |  |  | — |  |  |  | 11,800 |  |
| Corporate debt securities |  |  | — |  |  |  | 160,168 |  |  |  | — |  |  |  | 160,168 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 49,674 |  |  |  | — |  |  |  | 49,674 |  |
| Derivative assets |  |  | — |  |  |  | 2,823 | (3) |  |  | — |  |  |  | 2,823 |  |
| Total |  | $ | — |  |  | $ | 272,829 |  |  | $ | — |  |  | $ | 272,829 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion |  | $ | — |  |  | $ | 2,148 |  |  | $ | — |  |  | $ | 2,148 |  |
| Derivative liabilities – non-current portion |  |  | — |  |  |  | 3,718 |  |  |  | — |  |  |  | 3,718 |  |
| Total |  | $ | — |  |  | $ | 5,866 | (4) |  | $ | — |  |  | $ | 5,866 |  |

[0001193125-20-284755:notes:84]
| (1) | Foreign currency forward contracts with a notional amount of $130.0 million and Canadian dollars of 0.8 million. |

[0001193125-20-284755:notes:85]
| (2) | Two interest rate swap agreements with an aggregate notional amount of $125.1 million. |

[0001193125-20-284755:notes:86]
| (3) | Foreign currency forward contracts with a notional amount of $125.0 million and Canadian dollars of 0.6 million, and option contract with a notional amount of $1.0 million. |

[0001193125-20-284755:notes:87]
| (4) | Interest rate swap agreements with an aggregate notional amount of $125.1 million. |

[0001193125-20-284755:notes:88]
Derivative Financial Instruments

[0001193125-20-284755:notes:89]
[same as prior period, unchanged from 0001193125-20-133708:notes:88]

[0001193125-20-284755:notes:90]
[same as prior period, unchanged from 0001193125-20-133708:notes:89]

[0001193125-20-284755:notes:91]
[same as prior period, unchanged from 0001193125-20-133708:notes:90]

[0001193125-20-284755:notes:92]
As a result of foreign currency rate fluctuations, the U.S. dollar equivalent values of the Company’s foreign currency denominated assets and liabilities fluctuate. The Company uses foreign currency forward and option contracts to manage the foreign exchange risk associated with a portion of its foreign currency denominated assets and liabilities and other foreign currency transactions. The Company enters into foreign currency forward and option contracts to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht and Canadian dollars with counterparties that meet the Company’s minimum credit quality standard.

[0001193125-20-284755:notes:93]
The Company may enter into foreign currency forward contracts with maturities of up to 12 months to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht, including inventory purchases, payroll and other operating expenses. The Company considers these forward contracts as dual-purpose hedges, that hedge both the foreign exchange fluctuation (i) from inception through the forecasted expenditure, and (ii) any subsequent revaluation of the account payable or accrual. The Company may designate the forward contracts that hedge the foreign exchange fluctuation from inception through the forecasted expenditure as cash flow hedges. The gain or loss on a derivative instrument designated and qualified as a cash flow hedging instrument is recorded as a component of other comprehensive income and reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings. The reclassified amounts are presented in the same income statement line item as the earnings effect of the hedged item. Once the forecasted transactions are recorded, the Company will discontinue the hedging relationship by 
de-designating
 the derivative instrument and recording subsequent changes in fair value through contract maturity to foreign exchange gain (loss), net in the

[0001193125-20-284755:notes:94]
unaudited condensed

[0001193125-20-284755:notes:95]
consolidated statements of operations and comprehensive income as a natural hedge against the Thai baht denominated assets and liabilities.

[0001193125-20-284755:notes:96]
[same as prior period, unchanged from 0001193125-20-133708:notes:93]

[0001193125-20-284755:notes:97]
As of September 25, 2020, the Company had

[0001193125-20-284755:notes:98]
130 
outstanding U.S. dollar foreign currency forward contracts against Thai baht, with an aggregate notional amount of
 $130.0

[0001193125-20-284755:notes:99]
million and maturity dates ranging from October 2020 through April 2021 and one outstanding Canadian dollar foreign currency forward contract with a notional amount of Canadian dollars of 0.8 million and a maturity date in December 2020.

[0001193125-20-284755:notes:100]
As of September 25, 2020, the hedging relationship over foreign currency forward contracts that were designated for hedge accounting was determined to be highly effective based on the performance of retrospective and prospective regression testing. As of September 25, 2020, the amount in AOCI that is expected to be reclassified into earnings within 12 months was a loss

[0001193125-20-284755:notes:101]
of $0.5 million
.

[0001193125-20-284755:notes:102]
During the three months ended September 25, 2020, the Company recorded an unrealized loss of $1.5

[0001193125-20-284755:notes:103]
million from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange loss, net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-20-284755:notes:104]
As 
of
 September 27, 2019, the Company had 61 outstanding foreign currency forward contracts with an aggregate notional amount of $74.0 million 
and
 maturity dates

[0001193125-20-284755:notes:105]
ran
ging

[0001193125-20-284755:notes:106]
from October 2019 through January 2020. These foreign currency forward contracts were not designated for hedge accounting and were used to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht. During the three months

[0001193125-20-284755:notes:107]
ended September 27, 2019, the Company recorded unrealized loss of $1.9 million from changes in the fair value of foreign currency contracts in earnings as foreign exchange gain, net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-20-284755:notes:108]
Interest Rate Swap Agreements

[0001193125-20-284755:notes:109]
The Company entered into interest rate swap agreements to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. As 
of
 September 25, 2020

[0001193125-20-284755:notes:110]
and June 26, 2020
, the Company had two outstanding interest rate swap agreements with an aggregate notional amount of $125.1 million.

[0001193125-20-284755:notes:111]
On July 25, 2018, Fabrinet Thailand entered into an interest rate swap agreement to effectively convert the floating interest rate of its term loan under the Bank of America Credit Facility Agreement to a fixed interest rate of 2.86% per annum through the scheduled maturity of the term loan in June 2023 (see Note 
12
). The Company did not designate this interest rate swap for hedge accounting.

[0001193125-20-284755:notes:112]
On September 3, 2019, the Company entered into a new term loan agreement under a Credit Facility Agreement with the Bank of Ayudhya Public Company Limited (the “Bank”) (see Note 
12
) and on September 10, 2019, repaid in full the outstanding term loan under the Bank of America Credit Facility (see Note 1
2
). In conjunction with the funding of the new term loan, the Company entered into a second interest rate swap agreement. The combination of both of these interest rate swaps effectively convert the floating interest rate of the Company’s new term loan with the Bank to a fixed interest rate of 4.36% per annum through the maturity of the term loan in June 2024.

[0001193125-20-284755:notes:113]
On September 27, 2019, the Company designated these two interest rate swaps as a cash flow hedge for the Company’s term loan under the Credit Facility Agreement with the Bank. The combination of these two interest rate swaps qualified for hedge accounting because the hedges are highly effective, and the Company has designated and documented contemporaneously the hedging relationships involving these interest rate swaps. While we intend to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in our earnings. From September 27, 2019, any gains or losses related to these interest rate swaps will be recorded in accumulated other comprehensive income in the unaudited condensed consolidated balance sheets. The Company will reclassify a portion of the gains or losses from accumulated other comprehensive income into earnings at each reporting period based on either the accrued interest amount or the interest payment.

[0001193125-20-284755:notes:114]
As 
of
 September 25, 2020, the amount in accumulated other comprehensive income that is

[0001193125-20-284755:notes:115]
expected to be reclassified into earnings within 12 months is 
a ga
in of

[0001193125-20-284755:notes:116]
$0.5 
million
.

[0001193125-20-284755:notes:117]
Prior to September 27, 2019, these interest rate swaps were not designated as cash flow hedges and all changes in the fair value of these interest rate swaps were reflected in earnings. During the three months ended September 27, 2019, the Company recorded unrealized loss of $1.7 million from changes in the fair value of these interest rate swaps as interest expense in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-20-284755:notes:118]
[same as prior period, unchanged from 0001193125-20-133708:notes:110]

[0001193125-20-284755:notes:119]
|  |  |  |  |  | Three Months Ended |  |
| (amount in thousands) |  | Financial statements line item |  |  | September 25, 2020 |  |  | September 27, 2019 |  |
| Derivatives gain (loss) recognized in other comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  |  | Other comprehensive income |  |  | $ | (2,340 | ) |  | $ | — |  |
| Interest rate swaps |  |  | Other comprehensive income |  |  |  | 357 |  |  |  | 39 |  |
| Total derivatives gain (loss) recognized in other comprehensive income |  |  |  |  |  | $ | (1,983 | ) |  | $ | 39 |  |
| Derivatives loss (gain) reclassified from accumulated other comprehensive income into earnings: |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  |  | Cost of revenues |  |  | $ | (2,057 | ) |  | $ | — |  |
| Foreign currency forward contracts |  |  | SG&A |  |  |  | (87 | ) |  |  | — |  |
| Foreign currency forward contracts |  |  | Foreign exchange loss, net |  |  |  | 1,278 |  |  |  | — |  |
| Interest rate swaps |  |  | Interest expense |  |  |  | (359 | ) |  |  | — |  |
| Total derivatives (gain) loss reclassified from accumulated other comprehensive income into earnings |  |  |  |  |  | $ | (1,225 | ) |  | $ | — |  |
| Change in net unrealized gain (loss) on derivatives instruments |  |  |  |  |  | $ | (3,208 | ) |  | $ | — |  |

[0001193125-20-284755:notes:120]
Fair Value of derivatives

[0001193125-20-284755:notes:121]
[same as prior period, unchanged from 0001193125-20-133708:notes:113]

[0001193125-20-284755:notes:122]
|  |  | September 25, 2020 |  |  | June 26, 2020 |  |
| (amount in thousands) |  | Derivative Assets |  |  | Derivative Liabilities |  |  | Derivative Assets |  |  | Derivative Liabilities |  |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts |  | $ | 447 |  |  | $ | (134 | ) |  | $ | 9 |  |  | $ | (611 | ) |
| Interest rate swaps |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts |  |  | 247 |  |  |  | (781 | ) |  |  | 2,814 |  |  |  | (83 | ) |
| Interest rate swaps |  |  | — |  |  |  | (4,816 | ) |  |  | — |  |  |  | (5,172 | ) |
| Derivatives, gross balances |  |  | 694 |  |  |  | (5,731 | ) |  |  | 2,823 |  |  |  | (5,866 | ) |

[0001193125-20-284755:notes:123]
[same as prior period, unchanged from 0001193125-20-133708:notes:115]

[0001193125-20-284755:notes:124]
The Company’s netting arrangements allow net settlements under certain conditions. The Company’s derivative instruments are typically settled monthly or quarterly.

[0001193125-20-284755:notes:125]
[same as prior period, unchanged from 0001193125-20-133708:notes:117]

[0001193125-20-284755:notes:126]
|  |  | Derivative Financial Instruments |  | Balance Sheet line item |
|  |  | Fair Value of Derivative Assets |  | Other current assets |
|  |  | Fair Value of Derivative Liabilities |  | Accrued expenses |
|  |  | Fair Value of Derivative Liabilities |  | Other non-current liabilities |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-20-284755:notes:127]
| 7. | Inventories |

[0001193125-20-284755:notes:128]
| (amount in thousands) |  | As of September 25, 2020 |  |  | As of June 26, 2020 |  |
| Raw materials |  | $ | 153,511 |  |  | $ | 141,522 |  |
| Work in progress |  |  | 149,441 |  |  |  | 136,344 |  |
| Finished goods |  |  | 21,619 |  |  |  | 17,950 |  |
| Goods in transit |  |  | 14,858 |  |  |  | 13,970 |  |
| Inventories |  | $ | 339,429 |  |  | $ | 309,786 |  |


## fn:ScheduleOfOtherReceivableTextBlock

[0001193125-20-284755:notes:129]
| 8. | Other receivable |

[0001193125-20-284755:notes:130]
On October 1, 2019, the Company provided funds in the amount of $24.3 million to a customer to support the customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. 
As

[0001193125-20-284755:notes:131]
of

[0001193125-20-284755:notes:132]
September

[0001193125-20-284755:notes:133]
25, 2020, the Company recorded the $
24.3
 million funds as other receivable in the unaudited condensed consolidated balance

[0001193125-20-284755:notes:134]
sheet. The Company entered into the Amendment on October 1, 2020 to extend the payment terms of this amount and accrued interest and amend certain terms and conditions. (See Note 19)


## fn:RestrictedCashAndCashEquivalentsTextBlock

[0001193125-20-284755:notes:135]
| 9. | Restricted cash |

[0001193125-20-284755:notes:136]
As 
of
 September 25, 2020 and June 26, 2020, the Company had one outstanding standby letter of credit of 6.0 million Euros, related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. As 
of
 September 25, 2020 and June 26, 2020, the standby letter of credit w
as
 backed by cash collateral of $7.4 million
.


## us-gaap:LesseeOperatingLeaseLiabilityMaturityTableTextBlock

[0001193125-20-284755:notes:137]
As 
of
 Septe
m
ber 25, 2020, the m
a
turities of the Company’s operating lease liabilities w
e
re as follows:

[0001193125-20-284755:notes:138]
| (amount in thousands) |  | As of September 25, 2020 |  |
| 2021 |  | $ | 1,786 |  |
| 2022 |  |  | 2,381 |  |
| 2023 |  |  | 2,265 |  |
| 2024 |  |  | 990 |  |
| 2025 |  |  | 19 |  |
| Total undiscounted lease payments |  |  | 7,441 |  |
| Less imputed interest |  |  | (437 | ) |
| Total present value of lease liabilities |  | $ | 7,004 | (1) |

[0001193125-20-284755:notes:139]
| (1) | Included current portion of operating lease liabilities for the period ended September 25, 2020. |


## fn:ScheduleOfAdditionalInformationRelatedToOperatingAndFinanceLeaseTableTextBlock

[0001193125-20-284755:notes:140]
The following summarizes additional information related to the Company’s operating leases:

[0001193125-20-284755:notes:141]
|  |  | As of September 25, 2020 |  |  | As of June 26, 2020 |  |
| Weighted-average remaining lease term (in years) |  |  | 3.3 |  |  |  | 3.3 |  |
| Weighted-average discount rate |  |  | 3.7 | % |  |  | 3.7 | % |


## fn:ScheduleOfSupplementalCashFlowInformationRelatedToOperatingLeaseTableTextBlock

[0001193125-20-284755:notes:142]
The following table presents supplemental disclosure for the unaudited condensed consolidated statement of cash flows related to operating and finance leases for the three months ended September 25, 2020 and September 27, 2019:

[0001193125-20-284755:notes:143]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 25, 2020 |  |  | September 27, 2019 |  |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |  |
| Operating cash flows from operating leases |  | $ | 594 |  |  | $ | 458 |  |
| Financing cash flows from finance leases |  | $ | 100 |  |  | $ | 109 |  |
| ROU assets obtained in exchange for lease liabilities |  | $ | 7,228 |  |  | $ | 6,185 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-20-284755:notes:144]
| 11. | Intangibles |

[0001193125-20-284755:notes:145]
[same as prior period, unchanged from 0001193125-20-133708:notes:145]

[0001193125-20-284755:notes:146]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net |  |
| As of September 25, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 8,486 |  |  | $ | (5,826 | ) |  | $ | — |  |  | $ | 2,660 |  |
| Customer relationships |  |  | 4,373 |  |  |  | (2,825 | ) |  |  | (61 | ) |  |  | 1,487 |  |
| Backlog |  |  | 119 |  |  |  | (119 | ) |  |  | — |  |  |  | — |  |
| Total intangibles |  | $ | 12,978 |  |  | $ | (8,770 | ) |  | $ | (61 | ) |  | $ | 4,147 |  |

[0001193125-20-284755:notes:147]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Foreign Currency Translation Adjustment |  |  | Net |  |
| As of June 26, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 8,317 |  |  | $ | (5,577 | ) |  | $ | — |  |  | $ | 2,740 |  |
| Customer relationships |  |  | 4,373 |  |  |  | (2,691 | ) |  |  | (110 | ) |  |  | 1,572 |  |
| Backlog |  |  | 119 |  |  |  | (119 | ) |  |  | — |  |  |  | — |  |
| Total intangibles |  | $ | 12,809 |  |  | $ | (8,387 | ) |  | $ | (110 | ) |  | $ | 4,312 |  |

[0001193125-20-284755:notes:148]
The Company recorded amortization expense relating to intangibles of $0.2 million and $0.3 million for the three months ended September 25, 2020 and September 27, 2019, respectively.

[0001193125-20-284755:notes:149]
The weighted-average remaining life of customer relationships was:

[0001193125-20-284755:notes:150]
| (years) |  | As of September 25, 2020 |  |  | As of June 26, 2020 |  |
| Customer relationships |  |  | 4.4 |  |  |  | 4.6 |  |

[0001193125-20-284755:notes:151]
Based on the carrying amount of intangibles as 
of 
September 25, 2020, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001193125-20-284755:notes:152]
| (amount in thousands) |  |  |  |
| 2021 (remaining nine months) |  | $ | 1,030 |  |
| 2022 |  |  | 1,129 |  |
| 2023 |  |  | 873 |  |
| 2024 |  |  | 642 |  |
| 2025 |  |  | 354 |  |
| Thereafter |  |  | 119 |  |
| Total |  | $ | 4,147 |  |


## us-gaap:DebtDisclosureTextBlock

[0001193125-20-284755:notes:153]
| 12. | Borrowings |

[0001193125-20-284755:notes:154]
The Company’s total borrowings, including current and 
non-current
 portions of long-term borrowings, consisted of the following:

[0001193125-20-284755:notes:155]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  |  | Maturity |  |  | As of September 25, 2020 |  |  | As of June 26, 2020 |  |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  |  |  |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  |  |  |  |  |  |  |  | (32 | ) |  |  | (32 | ) |
| Long-term borrowings, current portion, net |  |  |  |  |  |  |  |  |  |  | $ | 12,156 |  |  |  | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) |  |  | Repayable in quarterly installments |  |  |  |  | June 2024 |  |  | $ | 48,750 |  |  | $ | 51,797 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  |  | (12,188 | ) |  |  | (12,188 | ) |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  |  |  |  | (87 | ) |  |  | (95 | ) |
| Long-term borrowings, non-current portion, net |  |  |  |  |  |  | $ | 36,475 |  |  | $ | 39,514 |  |

[0001193125-20-284755:notes:156]
| (1) | We have entered into interest rate swaps that effectively fix a series of our future interest payments on our term loans. Refer to Note 6. |

[0001193125-20-284755:notes:157]
The movements of long-term borrowings for the three months ended September 25, 2020 and September 27, 2019 were as follows:

[0001193125-20-284755:notes:158]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 25, 2020 |  |  | September 27, 2019 |  |
| Opening balance |  | $ | 51,797 |  |  | $ | 60,938 |  |
| Borrowings during the period |  |  | — |  |  |  | 60,938 |  |
| Repayments during the period |  |  | (3,047 | ) |  |  | (60,938 | ) |
| Closing balance |  | $ | 48,750 |  |  | $ | 60,938 |  |

[0001193125-20-284755:notes:159]
As
 of
 September 25, 2020, future maturities of long-term borrowings during each fiscal year were as follows:

[0001193125-20-284755:notes:160]
| (amount in thousands) |  |  |  |
| 2021 (remaining nine months) |  | $ | 9,140 |  |
| 2022 |  |  | 12,188 |  |
| 2023 |  |  | 15,234 |  |
| 2024 |  |  | 12,188 |  |
| Total |  | $ | 48,750 |  |

[0001193125-20-284755:notes:161]
Credit facility agreements:

[0001193125-20-284755:notes:162]
Bank of Ayudhya Public Company Limited

[0001193125-20-284755:notes:163]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as 
of
 September 27, 2019) and $160.9 million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

[0001193125-20-284755:notes:164]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a Term Loan Agreement pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the

[0001193125-20-284755:notes:165]
Company’s previous syndicated senior credit facility

[0001193125-20-284755:notes:166]
agreement.

[0001193125-20-284755:notes:167]
The term loan accrues interest at 
3-month LIBOR plus 1.35%
 and is repayable in quarterly installments of $
3.0
 million, commencing on September 30, 2019. The term loan will mature on 
June 30, 2024
. The Borrower m
a
y prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be

[0001193125-20-284755:notes:168]
re-borrowed.

[0001193125-20-284755:notes:169]
During the three months ended September 25, 2020, the Company recorded $
0.2
 million of interest expense in connection with this term loan.

[0001193125-20-284755:notes:170]
Any borrowings under the Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

[0001193125-20-284755:notes:171]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt to equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of September 25, 2020, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

[0001193125-20-284755:notes:172]
The events of default in the Term Loan Agreement include failure to pay amounts due under the Term Loan Agreement or the related finance documents when due, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

[0001193125-20-284755:notes:173]
At September 25, 2020, there was $48.8 million outstanding under the term loan.

[0001193125-20-284755:notes:174]
Bank of America, N.A.

[0001193125-20-284755:notes:175]
On May 22, 2014, the Company and 
a
 consortium of banks, entered into a syndicated senior credit facility agreement led by Bank of America (the “Bank of America Facility Agreement”). The Bank of America Facility Agreement provided for a $200.0 million credit line, comprised of a $150.0 million revolving loan facility and a $50.0 million delayed draw term loan facility.

[0001193125-20-284755:notes:176]
From time to time,

[0001193125-20-284755:notes:177]
the Company

[0001193125-20-284755:notes:178]
amended the Bank of America Facility Agreement, before repaying all outstanding amounts under the agreement and terminating such agreement on September 10, 2019.

[0001193125-20-284755:notes:179]
The most recent amendment on June 4, 2018 (i) reduced the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) refinanced the outstanding amounts under the revolving loan and term loan facilities into a $65.0 million term loan which was to be repaid in quarterly installments through the maturity date of June 4, 2023; and (iii) reduced the interest rate margins and commitment fees. The term loan bore interest, at the Company’s option, at a rate per annum equal to a LIBOR rate plus a spread of 1.50% to 2.25%, or a base rate plus a spread of 0.50% to 1.25%. During the three months ended September 27, 2019
,
 the Company recorded $0.5 million of interest expense in connection with this term loan.

[0001193125-20-284755:notes:180]
On September 10, 2019, the Company fully repaid $61.0 million in principal, accrued interest and other fees under the agreement. The early termination of this agreement did not trigger any early termination fees.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-20-284755:notes:181]
| 13. | Income taxes |

[0001193125-20-284755:notes:182]
As of September
 25, 2020 and June 26, 2020, the liability for uncertain tax positions including accrued interest and penalties was $1.5 million. The Company expects the estimated amount of liability associated with its uncertain tax positions to decrease within the next 12 months due to the lapse of the applicable statute of limitations in foreign tax jurisdictions.

[0001193125-20-284755:notes:183]
The Company files income tax returns in the United States and foreign tax jurisdictions. The tax years from 2015 to 2019 remain open to examination by U.S. federal and state, and foreign tax authorities. The Company’s income tax is recognized based on the best estimate of the expected annual effective tax rate for the full financial year of each entity in the Company, adjusted for discrete items arising in that quarter. If the Company’s estimated annual effective tax rate changes, the Company makes a cumulative adjustment in that quarter.

[0001193125-20-284755:notes:184]
The effective tax rate for the Company for the three months ended September 25, 2020 and September 27, 2019 was 4.5% and 5.0%, respectively, of net income. The decrease was primarily due to the fact that the Company had lower income subject to tax during the first quarter of fiscal year 2021 as compared to the same period in fiscal year 2020.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-20-284755:notes:185]
| 14. | Share-based compensation |

[0001193125-20-284755:notes:186]
[same as prior period, unchanged from 0001193125-20-133708:notes:190]

[0001193125-20-284755:notes:187]
[same as prior period, unchanged from 0001193125-20-133708:notes:191]

[0001193125-20-284755:notes:188]
The effect of recording share-based compensation expense for the three months ended September 25, 2020 and September 27, 2019 was as follows:

[0001193125-20-284755:notes:189]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 25, 2020 |  |  | September 27, 2019 |  |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |  |
| Restricted share units |  | $ | 5,249 |  |  | $ | 4,398 |  |
| Performance share units |  |  | 778 |  |  |  | 1,597 |  |
| Total share-based compensation expense |  |  | 6,027 |  |  |  | 5,995 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 6,027 |  |  | $ | 5,995 |  |

[0001193125-20-284755:notes:190]
[same as prior period, unchanged from 0001193125-20-133708:notes:194]

[0001193125-20-284755:notes:191]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 25, 2020 |  |  | September 27, 2019 |  |
| Cost of revenue |  | $ | 1,825 |  |  | $ | 1,720 |  |
| Selling, general and administrative expense |  |  | 4,202 |  |  |  | 4,275 |  |
| Total share-based compensation expense |  | $ | 6,027 |  |  | $ | 5,995 |  |

[0001193125-20-284755:notes:192]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the three months ended September 25, 2020 and September 27, 2019.

[0001193125-20-284755:notes:193]
[same as prior period, unchanged from 0001193125-20-133708:notes:197]

[0001193125-20-284755:notes:194]
On December 12, 2019, the Company’s shareholders approved Fabrinet’s 2020 Equity Incentive Plan (the “2020 Plan”). Upon the approval of the 2020 Plan, Fabrinet’s Amended and Restated 2010 Performance Incentive Plan (the “2010 Plan”) was simultaneously terminated. The 2020 Plan provides for the grant of equity awards thereunder with respect to (i) 1,700,000 ordinary shares, plus (ii) up to 1,300,000 ordinary shares that, as

[0001193125-20-284755:notes:195]
immediately prior

[0001193125-20-284755:notes:196]
to the termination of the 2010 Plan, had been reserved but not issued pursuant to any awards granted under the 2010 Plan and are not subject to any awards thereunder. Upon termination of the 2010 Plan, 1,281,619 ordinary shares were reserved for issuance under the 2020 Plan pursuant to clause (ii) of the preceding sentence.

[0001193125-20-284755:notes:197]
As of September
 25, 2020, there were 222,502 restricted share units outstanding, 
182,844
 performance share units outstanding and 
2,572,597
 ordinary shares available for future grant under the 
2020
 Plan.

[0001193125-20-284755:notes:198]
As of September
 25, 2020, there were 459,110 restricted share units outstanding and 238,474 
performance 
share units outstanding under the 2010 Plan. No ordinary shares are available for future grant under the 2010 Plan.

[0001193125-20-284755:notes:199]
On November 2, 2017, the Company adopted the 2017 Inducem
e
nt Equity Incentive Plan (the “2017 Inducement Plan”) with a reserve of 160,000 ordinary shares authorized for future issuance solely for the granting of inducement share options and equity awards to new employees. The 2017 Inducement Plan was adopted without shareholder approval in reliance on the “employment inducement exemption” provided under the New York Stock Exchange Listed Company Manual. 
As of September
 25, 2020, there were 12,164 restricted share units outstanding

[0001193125-20-284755:notes:200]
and

[0001193125-20-284755:notes:201]
111,347 ordinary shares available for future grant under the 2017 Inducement Plan.

[0001193125-20-284755:notes:202]
The 
2020 Plan, 
2010 Plan
 and
 2017 Inducement Plan are collectively referred to as the “Equity Incentive Plans.”

[0001193125-20-284755:notes:203]
[same as prior period, unchanged from 0001193125-20-133708:notes:205]

[0001193125-20-284755:notes:204]
Restricted share units and performance share units have been granted under the Equity Incentive Plans.

[0001193125-20-284755:notes:205]
[same as prior period, unchanged from 0001193125-20-133708:notes:207]

[0001193125-20-284755:notes:206]
Performance share units granted to executives will vest, if at all, at the end of a 
two-year
 performance period based on the Company’s achievement of 
pre-defined
 performance criteria, which consist of revenue and 
non-GAAP
 operating margin targets. The actual number of performance share units that may vest at the end of the performance period ranges from 0% to 100% of the award grant.

[0001193125-20-284755:notes:207]
[same as prior period, unchanged from 0001193125-20-133708:notes:209]

[0001193125-20-284755:notes:208]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 26, 2020 |  |  | 797,757 |  |  | $ | 46.88 |  |
| Granted |  |  | 171,946 |  |  | $ | 70.05 |  |
| Issued |  |  | (268,728 | ) |  | $ | 43.84 |  |
| Forfeited |  |  | (7,199 | ) |  | $ | 50.40 |  |
| Balance as of September 25, 2020 |  |  | 693,776 |  |  | $ | 53.76 |  |

[0001193125-20-284755:notes:209]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 28, 2019 |  |  | 800,751 |  |  | $ | 42.48 |  |
| Granted |  |  | 292,321 |  |  | $ | 48.39 |  |
| Issued |  |  | (240,595 | ) |  | $ | 39.62 |  |
| Forfeited |  |  | (21,577 | ) |  | $ | 42.00 |  |
| Balance as of September 27, 2019 |  |  | 830,900 |  |  | $ | 45.40 |  |

[0001193125-20-284755:notes:210]
[same as prior period, unchanged from 0001193125-20-133708:notes:212]

[0001193125-20-284755:notes:211]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 26, 2020 |  |  | 440,140 |  |  | $ | 48.37 |  |
| Granted |  |  | 179,008 |  |  | $ | 70.05 |  |
| Issued |  |  | (82,185 | ) |  | $ | 48.02 |  |
| Forfeited |  |  | (115,645 | ) |  | $ | 48.02 |  |
| Balance as of September 25, 2020 |  |  | 421,318 |  |  | $ | 57.74 |  |

[0001193125-20-284755:notes:212]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 28, 2019 |  |  | 548,500 |  |  | $ | 40.97 |  |
| Granted |  |  | 238,474 |  |  | $ | 48.39 |  |
| Issued |  |  | — |  |  |  | — |  |
| Forfeited |  |  | (350,670 | ) |  | $ | 36.99 |  |
| Balance as of September 27, 2019 |  |  | 436,304 |  |  | $ | 48.22 |  |

[0001193125-20-284755:notes:213]
The fair value of restricted share units and performance share units is based on the market value of our ordinary shares on the date of grant.

[0001193125-20-284755:notes:214]
As of September
 25, 2020, there was $18.7 million and $14.6 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.7 years and 1.6 years, respectively.

[0001193125-20-284755:notes:215]
For the three months ended September 25, 2020 and September 27, 2019, the Company withheld an aggregate of 142,221 shares and 82,220 shares, respectively, upon the vesting of restricted share units, based upon the closing share price on the vesting date to settle

[0001193125-20-284755:notes:216]
employee obligations

[0001193125-20-284755:notes:217]
for the applicable income and other employment taxes. For the three months ended September 25, 2020 and September 27, 2019, the Company then remitted cash of $9.9 million and $4.1 million, respectively, to the appropriate taxing authorities, and presented it as a financing activity within the unaudited condensed consolidated statements of cash flows. The payment was recorded as a reduction of additional 
paid-in
 capital.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-20-284755:notes:218]
| 15. | Shareholders’ equity |

[0001193125-20-284755:notes:219]
[same as prior period, unchanged from 0001193125-20-133708:notes:218]

[0001193125-20-284755:notes:220]
Fabrinet’s authorized share capital is 500,000,000 ordinary shares, par value of $0.01 per ordinary share, and 5,000,000 preferred shares, par value of $0.01 per preferred share.

[0001193125-20-284755:notes:221]
For the three months ended September 25, 2020, Fabrinet issued 208,692 ordinary shares upon the vesting of restricted share units, net of shares withheld.

[0001193125-20-284755:notes:222]
For the three months ended September 27, 2019, Fabrinet issued 158,375 ordinary shares upon the vesting of restricted share units, net of shares withheld.

[0001193125-20-284755:notes:223]
[same as prior period, unchanged from 0001193125-20-133708:notes:222]

[0001193125-20-284755:notes:224]
[same as prior period, unchanged from 0001193125-20-133708:notes:223]

[0001193125-20-284755:notes:225]
In August 2017

[0001193125-20-284755:notes:226]
, the Company’s board of directors approved a share repurchase 
program 
to permit the Company to repurchase up to $30.0 million worth of its issued and outstanding ordinary shares in the open market in accordance with applicable rules and regulations. In February 2018, May 2019 and August 2020, the Company’s board of directors approved an increase of $30.0 million, $50.0 million and $58.5 million, respectively, to the original share repurchase authorization, bringing the aggregate authorization to $168.5 million. During the three months ended September 25, 2020, no shares were repurchased under the program. 
As of September
 25, 2020, the Company had a remaining authorization to purchase up to an additional $100.0 million worth of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase

[0001193125-20-284755:notes:227]
program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-20-284755:notes:228]
| 16. | Accumulated other comprehensive income (loss) |

[0001193125-20-284755:notes:229]
The changes in AOCI for the three months ended September 25, 2020 and September 27, 2019 were as follows:

[0001193125-20-284755:notes:230]
| (amount in thousands) |  | Unrealized net (Losses)/Gains on Available-for-sale Securities |  |  | Unrealized net (Losses)/Gains on Derivative Instruments |  |  | Retirement benefit plan - Prior service cost |  |  | Foreign Currency Translation Adjustment |  |  | Total |  |
| Balance as of June 26, 2020 |  | $ | 1,490 |  |  | $ | 602 |  |  |  | (2,009 | ) |  | $ | (1,230 | ) |  | $ | (1,147 | ) |
| Other comprehensive income before reclassification adjustment |  |  | (325 | ) |  |  | (1,983 | ) |  |  | — |  |  |  | 603 |  |  |  | (1,705 | ) |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income |  |  | — |  |  |  | (1,225 | ) |  |  | 173 |  |  |  | — |  |  |  | (1,052 | ) |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income (loss) |  | $ | (325 | ) |  | $ | (3,208 | ) |  |  | 173 |  |  | $ | 603 |  |  | $ | (2,757 | ) |
| Balance as of September 25, 2020 |  | $ | 1,165 |  |  | $ | (2,606 | ) |  |  | (1,836 | ) |  | $ | (627 | ) |  | $ | (3,904 | ) |
| (amount in thousands) |  | Unrealized net (Losses)/Gains on Available-for-sale Securities |  |  | Unrealized net (Losses)/Gains on Derivative Instruments |  |  | Retirement benefit plan - Prior service cost |  |  | Foreign Currency Translation Adjustment |  |  | Total |  |
| Balance as of June 28, 2019 |  | $ | 952 |  |  | $ | 32 |  |  | $ | (2,537 | ) |  | $ | (833 | ) |  | $ | (2,386 | ) |
| Other comprehensive income before reclassification adjustment |  |  | (32 | ) |  |  | 39 |  |  |  | 83 |  |  |  | (369 | ) |  |  | (279 | ) |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income |  |  | 67 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 67 |  |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income (loss) |  | $ | 35 |  |  | $ | 39 |  |  | $ | 83 |  |  | $ | (369 | ) |  | $ | (212 | ) |
| Balance as of September 27, 2019 |  | $ | 987 |  |  | $ | 71 |  |  | $ | (2,454 | ) |  | $ | (1,202 | ) |  | $ | (2,598 | ) |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-20-284755:notes:231]
| 17. | Commitments and contingencies |

[0001193125-20-284755:notes:232]
Letter of credit and Bank guarantees

[0001193125-20-284755:notes:233]
As of September 25, 2020 and June 26, 2020, the Company had one outstanding standby letter of credit of 6.0 million Euros related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. As of September 25, 2020 and June 26, 2020, the standby letter of credit was backed by cash collateral of $7.4 million.

[0001193125-20-284755:notes:234]
As of September 25, 2020 and June 26, 2020, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business expenses totaling to $1.6 million and $1.6 million, respectively, and there were other bank guarantees given by a bank on behalf of our subsidiaries in China and the U.K. to support their operations. As of September 25, 2020 and June 26, 2020, these bank guarantees were not material.

[0001193125-20-284755:notes:235]
Purchase obligations

[0001193125-20-284755:notes:236]
Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001193125-20-284755:notes:237]
As of September
 25, 2020, the Company had an outstanding commitment to third parties of $10.0 million.

[0001193125-20-284755:notes:238]
Indemnification of directors and officers

[0001193125-20-284755:notes:239]
Cayman Islands law does not limit the extent to which a company’s 
memorandum 
and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001193125-20-284755:notes:240]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-20-284755:notes:241]
| 18. | Business segments and geographic information |

[0001193125-20-284755:notes:242]
Operating segments are defined as 
components 
of an enterprise for which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. The Company’s chief operating decision maker is Fabrinet’s Chief Executive Officer. 
As of September
 25, 2020, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001193125-20-284755:notes:243]
For the

[0001193125-20-284755:notes:244]
Company’s

[0001193125-20-284755:notes:245]
revenues by geographic region, see “Revenue by Geographic Area and End Market” in Note 3.

[0001193125-20-284755:notes:246]
As of September
 25, 2020 and Sep
t
ember 27, 2019, the Company had approximately $29.2 million and $30.8 million, respectively, of long-lived assets based in North America, with the substantial remainder of assets based in Asia-Pacific and Europe.

[0001193125-20-284755:notes:247]
[same as prior period, unchanged from 0001193125-20-133708:notes:247]

[0001193125-20-284755:notes:248]
The Company had two customers and three customers

[0001193125-20-284755:notes:249]
that each contributed to 10% or more of its total trade accounts receivable as of September 25, 2020 and June 26, 2020, respectively.


## us-gaap:SubsequentEventsTextBlock

[0001193125-20-284755:notes:250]
| 19. | Subsequent events |

[0001193125-20-284755:notes:251]
On October 1, 2020, the Company extended the payment terms of $24.3 million in funds it had advanced to a customer and accrued interest from September 30, 2020 to April 1, 2021, and reduced the interest rate effective from October 1, 2020. The extension is due to the customer’s agreement to transfer additional manufacturing operations to the Company’s facilities in Thailand beginning in November 2020. These funds will be offset by amount due to this customer for the purchases of certain inventories. (See Note 8)

[0001193125-20-284755:notes:252]
The Company has also committed to purchase $26.0 million worth of inventories from the customer.
