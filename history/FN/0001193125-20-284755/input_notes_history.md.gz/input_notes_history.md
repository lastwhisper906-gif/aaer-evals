# FN note change history — 0001193125-20-133708 → 0001193125-20-284755


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-11-03):
[0001193125-20-284755:note_history:1]
As of September 25, 2020 and June 26, 2020, the Company had one outstanding standby letter of credit of 6.0 million Euros related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. As of September 25, 2020 and June 26, 2020, the standby letter of credit was backed by cash collateral of $7.4 million.
  (was, 2020-05-05, similarity 0.9605):
[0001193125-20-133708:note_history:1]
As of March 27, 2020 and June 28, 2019, the Company had one outstanding standby letter of credit of 6.0 million Euros, related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. As of March 27, 2020 and June 28, 2019, the standby letter of credit was backed by cash collateral of $7.4 million.

- added (2020-11-03):
[0001193125-20-284755:note_history:2]
As of September 25, 2020 and June 26, 2020, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business expenses totaling to $1.6 million and $1.6 million, respectively, and there were other bank guarantees given by a bank on behalf of our subsidiaries in China and the U.K. to support their operations. As of September 25, 2020 and June 26, 2020, these bank guarantees were not material.

- changed (2020-11-03):
[0001193125-20-284755:note_history:3]
Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2020-05-05, similarity 0.9635):
[0001193125-20-133708:note_history:3]
binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- changed (2020-11-03):
[0001193125-20-284755:note_history:4]
As of September
 25, 2020, the Company had an outstanding commitment to third parties of $10.0 million.
  (was, 2020-05-05, similarity 0.7458):
[0001193125-20-133708:note_history:4]
As of March 27, 2020, the Company had purchase obligations to third parties of $15.2 million.

- removed (2020-11-03):
[0001193125-20-133708:note_history:5]
As of March 27, 2020 and June 28, 2019, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business 
expenses

- removed (2020-11-03):
[0001193125-20-133708:note_history:6]
totaling 
$1.5 million and $1.6 million, respectively, and there were other bank guarantees given by a bank on behalf of our subsidiaries in China and the United Kingdom to support their operations of

- removed (2020-11-03):
[0001193125-20-133708:note_history:7]
de minimis amounts.

- removed (2020-11-03):
[0001193125-20-133708:note_history:8]
Purchase obligations represent legally


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-11-03):
[0001193125-20-284755:note_history:9]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as 
of
 September 25, 2020 and for the three months ended September 25, 2020 and September 27, 2019 includes normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 
10-K
 for the year ended June 26, 2020.
  (was, 2020-05-05, similarity 0.9523):
[0001193125-20-133708:note_history:9]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of March 27, 2020 and for the three and nine months ended March 27, 2020 and March 29, 2019 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 
10-K
 for the year ended June 28, 2019.

- changed (2020-11-03):
[0001193125-20-284755:note_history:10]
The results for the three months ended September 25, 2020 may not be indicative of results for the year ending June 25, 2021 or any future periods.
  (was, 2020-05-05, similarity 0.9319):
[0001193125-20-133708:note_history:10]
The results for the three and nine months ended March 27, 2020 may not be indicative of results for the year ending June 26, 2020 or any future periods.

- changed (2020-11-03):
[0001193125-20-284755:note_history:11]
Use of Estimates
  (was, 2020-05-05, similarity 0.9697):
[0001193125-20-133708:note_history:11]
Use of 
e
stimates

- added (2020-11-03):
[0001193125-20-284755:note_history:12]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements, and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information. Additionally, the extent to which the evolving 
COVID-19
 pandemic impacts the Company’s unaudited condensed consolidated financial statements will depend on a number of factors, including the magnitude and duration of the pandemic. These estimates may change, as new events occur and additional information is obtained, as well as other factors related to the 
COVID-19
 pandemic that could result in material impacts to our unaudited condensed consolidated financial statements in future reporting periods.

- changed (2020-11-03):
[0001193125-20-284755:note_history:13]
The Company utilizes a 
52-53
 week fiscal year ending on the Friday in June closest to June 30. The three months ended September 25, 2020 and September 27, 2019 each consisted of 13 weeks. Fiscal year 
2021 
will be comprised of 52 weeks and will end on June 25, 2021.
  (was, 2020-05-05, similarity 0.7181):
[0001193125-20-133708:note_history:13]
week fiscal year ending on the Friday in June closest to June 30. The three months ended March 27, 2020 and March 29, 2019 each consisted of 13 weeks. The nine months ended March 27, 2020 and March 29, 2019 each consisted of 39 weeks. Fiscal year 2020 will be comprised of 52 weeks and will end on June 26, 2020.

- changed (2020-11-03):
[0001193125-20-284755:note_history:14]
For presentation purposes, certain prior period amounts have been reclassified to conform to the current period presentation.
  (was, 2020-05-05, similarity 0.7143):
[0001193125-20-133708:note_history:14]
For presentation purposes, certain prior period amounts have been reclassified to conform to the current period presentation. These reclassifications do not affect the Company’s net income, cash flows or stockholders’ equity.

- added (2020-11-03):
[0001193125-20-284755:note_history:15]
As of June 26, 2020, the derivative assets and liabilities were measured at fair value and recognized by offsetting the fair value amounts under master netting arrangements. Also, the Company chose not to separate a derivative into current and 
non-current
 portions as follows:

- added (2020-11-03):
[0001193125-20-284755:note_history:16]
|  | (i) | A derivative for which the fair value is a net liability is classified in total as a current liability. |

- added (2020-11-03):
[0001193125-20-284755:note_history:17]
|  | (ii) | A derivative for which the fair value is a net asset and the current portion is an asset is classified in total as a non-current asset. If the current portion is a liability, it is presented as a current liability. |

- added (2020-11-03):
[0001193125-20-284755:note_history:18]
As of September 25, 2020, the derivative assets and liabilities were measured at fair value, but the gross fair value amount is presented in the unaudited condensed consolidated balance sheets. Additionally, a classification of current and 
non-current
 portion is determined by the maturity date of that derivative (e.g., a derivative that matures within one year is classified as current).

- added (2020-11-03):
[0001193125-20-284755:note_history:19]
The reclassifications have been made to the consolidated balance sheet as of June 26, 2020 as shown in the following table:

- added (2020-11-03):
[0001193125-20-284755:note_history:20]
|  |  | June 26, 2020 |  |
| (amount in thousands) |  | As previously reported |  |  | Reclassification |  |  | After reclassification |  |
| Consolidated Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Other current assets |  | $ | 13,915 |  |  | $ | 593 |  |  | $ | 14,508 |  |
| Current liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Accrued expenses |  | $ | 12,104 |  |  | $ | (3,125 | ) |  | $ | 8,979 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |  |  |  |  |
| Other non-current liabilities |  | $ | 1,937 |  |  | $ | 3,718 |  |  | $ | 5,655 |  |

- added (2020-11-03):
[0001193125-20-284755:note_history:21]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 
2016-13,
 “Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments.” This standard requires the measurement and recognition of expected credit losses for financial assets held at amortized cost. The standard replaces the existing incurred loss impairment model with an expected loss methodology, which will result in more timely recognition of credit losses. The new standard also expands the required quantitative and qualitative disclosures surrounding expected credit losses.

- added (2020-11-03):
[0001193125-20-284755:note_history:22]
On June 27, 2020, the Company adopted Accounting Standards Codification (“ASC”) 326 using the modified retrospective transition approach. The modified retrospective method requires the Company to recognize the cumulative effect of the adoption of ASC 326, to the opening accumulated retained earnings. Accordingly, the Company’s comparative financial statements as of June 26, 2020 have not been adjusted. The Company implemented internal controls to enable the preparation of financial information upon adoption.

- added (2020-11-03):
[0001193125-20-284755:note_history:23]
Management estimates the expected credit losses of financial assets using relevant available information from internal and external sources relating to historical credit loss experience, current conditions and reasonable forecasts over a financial asset’s contractual term. Adjustments to historical loss information are made from qualitative and quantitative factors if economic conditions on the reporting date reflect stronger or weaker economic performance than the historical data implies based on management’s expectations of economic conditions on certain indicators of the Company, industry and economy. The Company reviews factors such as past collection experience, age of the accounts receivable and contract assets balance, significant trends in current balances, internal operations and macroeconomic conditions. In addition, the Company modified its impairment model to the Current Expected Credit Losses (“CECL”) model for

- added (2020-11-03):
[0001193125-20-284755:note_history:24]
available-for-sale

- added (2020-11-03):
[0001193125-20-284755:note_history:25]
(“AFS”) debt securities and discontinued using the concept of “other than temporary” impairment on these AFS debt securities. CECL on the AFS debt securities are recognized in interest income and other income (expense), net on the Company’s unaudited condensed consolidated statements of operations and comprehensive income, and any remaining unrealized losses, are included in accumulated other comprehensive loss (“AOCI”) in the unaudited condensed consolidated balance sheet.

- added (2020-11-03):
[0001193125-20-284755:note_history:26]
As of June 27, 2020, the Company recorded a cumulative adjustment from CECL in the amount of $0.1 million, net of tax impact, to accumulated retained earnings in the unaudited condensed consolidated balance sheet.

- changed (2020-11-03):
[0001193125-20-284755:note_history:27]
On June 27, 2020, the Company also adopted ASC 820, “Disclosure Framework – Changes to the Disclosure Requirements for Fair Value Measurement.” This standard is intended to improve the effectiveness of disclosures in the notes to the financial statements, including (1) the development of a framework that promotes consistent decisions by the FASB about disclosure requirements and (2) the appropriate exercise of discretion by reporting entities. The amendment modifies the disclosure requirements on transferring between level 1 and level 2 and valuation processes of level 3 fair value measurements. The Company adopted this standard with no impact on its unaudited condensed consolidated financial statements.
  (was, 2020-05-05, similarity 0.6578):
[0001193125-20-133708:note_history:27]
In August 2018, the FASB issued ASU 
2018-13,
 “Fair Value Measurement (Topic 820), Disclosure Framework—Changes to the Disclosure Requirements for Fair Value Measurement.” ASU 
2018-13
 is intended to improve the effectiveness of disclosures in the notes to the financial statements, including (1) the development of a framework that promotes consistent decisions by the FASB about disclosure requirements and (2) the appropriate exercise of discretion by reporting entities. The amendment modifies the disclosure requirements on transferring between level 1 and level 2 and valuation processes of level 3 fair value measurements. This update is effective for all entities for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. This ASU will be effective for the Company in the first quarter of fiscal 2021. The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.

- changed (2020-11-03):
[0001193125-20-284755:note_history:28]
Changes in Accounting Policies
  (was, 2020-05-05, similarity 0.9677):
[0001193125-20-133708:note_history:28]
Changes in 
a
ccounting 
p
olicies

- changed (2020-11-03):
[0001193125-20-284755:note_history:29]
Except for the adoption of ASC 326, the Company has consistently applied the accounting policies to all periods presented in these unaudited condensed consolidated financial statements.
  (was, 2020-05-05, similarity 0.7733):
[0001193125-20-133708:note_history:29]
Except for the adoption of the new lease accounting standard and the derivatives and hedging standard described below, the Company has consistently applied 
its
 accounting policies to all periods presented in these unaudited condensed consolidated financial statements.

- added (2020-11-03):
[0001193125-20-284755:note_history:30]
Short-term investments

- added (2020-11-03):
[0001193125-20-284755:note_history:31]
Management determines the appropriate classification of its investments at the time of purchase and 
re-evaluates
 the designations at each balance sheet date. The Company may sell certain of the Company’s short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s short-term investments generally range from three months to three years. The Company’s short-term investments, which consist of investments in U.S. Treasury, fixed income securities, liquidity funds that invest in short-term debt securities and certificates of deposit and time deposits, have been classified and accounted for as AFS. The AFS investments are carried at estimated fair value with any unrealized gains and losses, included in AOCI in the Company’s unaudited condensed consolidated balance sheet. The Company determines realized gains or losses on sale of marketable securities on a specific identification method and records such gains or losses as interest income and other income (expense), net in the unaudited condensed consolidated statements of operations and comprehensive income.

- added (2020-11-03):
[0001193125-20-284755:note_history:32]
AFS debt securities are required to be individually evaluated for impairment. A security is considered impaired if the fair value of the security is less than its amortized cost basis.

- added (2020-11-03):
[0001193125-20-284755:note_history:33]
An impairment is considered other than temporary if (i) the Company has the intent to sell the security, (ii) it is more likely than not that the Company will be required to sell the security before recovery of the entire amortized cost basis, or (iii) the Company does not expect to recover the entire amortized cost basis of the security.

- added (2020-11-03):
[0001193125-20-284755:note_history:34]
If an impairment is considered other than temporary based on condition (i) or (ii), the entire difference between the amortized cost and the fair value of the debt security is recognized as interest income and other income (expense), net in the unaudited condensed consolidated statements of operations and comprehensive income.

- added (2020-11-03):
[0001193125-20-284755:note_history:35]
If an impairment is considered other than temporary based on condition (iii), the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) is recognized in interest and other income (expense), net in the unaudited condensed consolidated statements of operations and comprehensive income, and any remaining unrealized losses are included in AOCI in the unaudited condensed consolidated balance sheet.

- added (2020-11-03):
[0001193125-20-284755:note_history:36]
Trade accounts receivable

- added (2020-11-03):
[0001193125-20-284755:note_history:37]
Accounts receivable are recorded and carried at the original invoiced amount less an allowance for any potential uncollectible amounts. The Company makes estimates of expected credit losses for the allowance for doubtful accounts based upon its assessment of various factors, including historical experience, the age of the accounts receivable balances, credit quality of its customers, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect the Company’s ability to collect from customers. The estimated credit loss allowance is recorded as selling, general and administrative expenses in the unaudited condensed consolidated statements of operations and comprehensive income.

- added (2020-11-03):
[0001193125-20-284755:note_history:38]
Contract assets

- added (2020-11-03):
[0001193125-20-284755:note_history:39]
A contract asset is recognized when the Company has recognized revenues prior to generating an invoice for payment. Contract assets are classified separately within the unaudited condensed consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. The Company makes estimates of expected credit losses for the allowance for contract assets based upon its assessment of various factors, including historical experience, the age of the contract assets balances, credit quality of its customers, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect the Company’s ability to collect from customers. The estimated credit loss allowance is recorded as selling, general and administrative expenses in its unaudited condensed consolidated statements of operations and comprehensive income.

- changed (2020-11-03):
[0001193125-20-284755:note_history:40]
Concentration of credit risk
  (was, 2020-05-05, similarity 0.9825):
[0001193125-20-133708:note_history:40]
C
oncentration of credit risk

- changed (2020-11-03):
[0001193125-20-284755:note_history:41]
In December 2019, the FASB issued ASU 
2019-12,
 “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.” The amendments in this update simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify U.S. GAAP for other areas of Topic 740 by clarifying and amending existing guidance. For public business entities, the amendments in this update are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2020. This ASU will be effective for the Company in the first quarter of fiscal year 2022. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its unaudited condensed consolidated financial statements.
  (was, 2020-05-05, similarity 0.9907):
[0001193125-20-133708:note_history:41]
In December 2019, the FASB issued ASU 
2019-12,
 “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.” The amendments in this update simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify U.S. GAAP for other areas of Topic 740 by clarifying and amending existing guidance. For public business entities, the amendments in this update are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2020. This ASU will be effective for the Company in the first quarter of fiscal 2022. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.

- removed (2020-11-03):
[0001193125-20-133708:note_history:42]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements, and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisitions, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information.

- removed (2020-11-03):
[0001193125-20-133708:note_history:43]
The Company utilizes a 
52
 to 
53
-

- removed (2020-11-03):
[0001193125-20-133708:note_history:44]
On June 29, 2019, the Company adopted the new lease accounting standard, Accounting Standards Codification (“ASC”) Topic 842, which provides guidance for the recognition and disclosure of lease arrangements. The Company adopted ASC 842 using the modified retrospective transition approach. Accordingly, the Company’s comparative financial statements as of June 28, 2019 have not been adjusted. ASC 842 also provides practical expedients for the Company’s ongoing accounting. The Company elected the short-term lease recognition exemption for its operating leases with a term of less than 12 months, which will not require recognition of right of use (“ROU”) assets or lease liabilities for these leases.

- removed (2020-11-03):
[0001193125-20-133708:note_history:45]
For periods prior to adoption of ASC 842, the Company is required to present disclosures in accordance with ASC Topic 840. Future minimum lease payments due under non-cancelable operating leases as of June 28, 2019 were as follows:

- removed (2020-11-03):
[0001193125-20-133708:note_history:46]
| (amount in thousands) |  |  |  |
| 2020 |  | $ | 1,746 |  |
| 2021 |  |  | 1,342 |  |
| 2022 |  |  | 1,219 |  |
| 2023 |  |  | 1,172 |  |
| Thereafter |  |  | 230 |  |
| Total future minimum operating lease payments |  | $ | 5,709 |  |

- removed (2020-11-03):
[0001193125-20-133708:note_history:47]
The most significant impact of the adoption of ASC 842 was the recognition of ROU assets and lease liabilities for operating leases with a term of greater than 12 months, while the accounting for finance leases will remain substantially unchanged. See Note 11 for further details.

- removed (2020-11-03):
[0001193125-20-133708:note_history:48]
On June 29, 2019, the Company also adopted Accounting Standards Update (“ASU”) 
2017-12,
 “Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities.” ASU 
2017-12
 simplifies existing hedge accounting guidance in order to better portray the economic impact of risk management activities in the financial statements, including eliminating the separate measurement and presentation of hedge ineffectiveness. Prior to the adoption of ASU 
2017-12,
 the Company was required to separately measure and reflect the amount by which the hedging instrument did not offset the changes in the fair value or cash flows of hedged items, and to record the ineffective portion as earnings. Upon the adoption of ASU 
2017-12,
 the Company no longer recognizes hedge ineffectiveness as earnings, but instead records the entire changes in the fair value of the hedged instruments as other comprehensive income. Amounts recorded as other comprehensive income are subsequently reclassified to earnings in the same income statement line item that is used to present the earnings effect of the hedged item when the hedged item affects earnings. See Note 6 for further details.

- removed (2020-11-03):
[0001193125-20-133708:note_history:49]
In March 2020, the Financial Accounting Standards Board (“FASB”) issued ASU 
2020-04,
 “Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting,” which temporarily simplifies the accounting for contract modifications, including hedging relationships, due to the transition from LIBOR and other interbank offered rates to alternative reference interest rates. For example, entities can elect not to remeasure the contracts at the modification date or reassess a previous accounting determination if certain conditions are met. Additionally, entities can elect to continue applying hedge accounting for hedging relationships affected by reference rate reform if certain conditions are met. The new standard was effective upon issuance and generally can be applied to applicable contract modifications through December 31, 2022. This ASU was effective for the Company in the third quarter of fiscal 2020 with no impact to the Company’s unaudited condensed consolidated financial statements.

- removed (2020-11-03):
[0001193125-20-133708:note_history:50]
In January 2017, the FASB issued ASU 
2017-04,
 “Intangibles—Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.” ASU 
2017-04
 modifies the concept of impairment assessment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. Public companies that are SEC filers should adopt the amendment for annual and any interim goodwill impairment tests in fiscal years beginning after December 15, 2019. Early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017. This ASU will be effective for the Company in the first quarter of fiscal 2021. The Company does not expect this update will impact its condensed consolidated financial statements.

- removed (2020-11-03):
[0001193125-20-133708:note_history:51]
In June 2016, the FASB issued ASU 
2016-13,
 “Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments,” which establishes a new credit impairment model for financial assets measured at amortized cost and 
available-for-sale
 debt securities. The FASB issued subsequent amendments to Topic 326, including ASU 
2018-19, 
 ASU 
2019-04,
 ASU 
2019-05,
 ASU 
2019-11
 and ASU 
2020-02,
 which provided further

- removed (2020-11-03):
[0001193125-20-133708:note_history:52]
guidance and transition relief. For public business entities, this 
update 
is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. This ASU will be effective for the Company in the first quarter of fiscal 2021. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-03):
[0001193125-20-284755:note_history:53]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  |  | Maturity |  |  | As of September 25, 2020 |  |  | As of June 26, 2020 |  |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  |  |  |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  |  |  |  |  |  |  |  | (32 | ) |  |  | (32 | ) |
| Long-term borrowings, current portion, net |  |  |  |  |  |  |  |  |  |  | $ | 12,156 |  |  |  | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) |  |  | Repayable in quarterly installments |  |  |  |  | June 2024 |  |  | $ | 48,750 |  |  | $ | 51,797 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  |  | (12,188 | ) |  |  | (12,188 | ) |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  |  |  |  | (87 | ) |  |  | (95 | ) |
| Long-term borrowings, non-current portion, net |  |  |  |  |  |  | $ | 36,475 |  |  | $ | 39,514 |  |
  (was, 2020-05-05, similarity 0.8969):
[0001193125-20-133708:note_history:53]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  |  | Maturity |  |  | As of March 27, 2020 |  |  | As of June 28, 2019 |  |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  | $ | 12,188 |  |  | $ | 3,250 |  |
| Less: Unamortized debt issuance costs – current portion |  |  | (32 | ) |  |  | — |  |
| Long-term borrowings, current portion, net |  |  |  |  |  | $ | 12,156 |  |  | $ | 3,250 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1-month LIBOR +1.50% per annum (1) |  |  | Repayable in quarterly installments |  |  |  | June 2023 |  |  | $ | — |  |  | $ | 60,938 |  |
| 3-month LIBOR +1.35% per annum (1) |  |  | Repayable in quarterly installments |  |  |  | June 2024 |  |  |  | 54,844 |  |  |  | — |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (12,188 | ) |  |  | (3,250 | ) |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  |  |  | (103 | ) |  |  | — |  |
| Long-term borrowings, non-current portion, net |  |  |  |  |  | $ | 42,553 |  |  | $ | 57,688 |  |

- changed (2020-11-03):
[0001193125-20-284755:note_history:54]
The movements of long-term borrowings for the three months ended September 25, 2020 and September 27, 2019 were as follows:
  (was, 2020-05-05, similarity 0.8756):
[0001193125-20-133708:note_history:54]
The movements of long-term borrowings for the nine months ended March 27, 2020 and March 29, 2019 were as follows:

- added (2020-11-03):
[0001193125-20-284755:note_history:55]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 25, 2020 |  |  | September 27, 2019 |  |
| Opening balance |  | $ | 51,797 |  |  | $ | 60,938 |  |
| Borrowings during the period |  |  | — |  |  |  | 60,938 |  |
| Repayments during the period |  |  | (3,047 | ) |  |  | (60,938 | ) |
| Closing balance |  | $ | 48,750 |  |  | $ | 60,938 |  |

- changed (2020-11-03):
[0001193125-20-284755:note_history:56]
As
 of
 September 25, 2020, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2020-05-05, similarity 0.95):
[0001193125-20-133708:note_history:56]
As of March 27, 2020, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2020-11-03):
[0001193125-20-284755:note_history:57]
| (amount in thousands) |  |  |  |
| 2021 (remaining nine months) |  | $ | 9,140 |  |
| 2022 |  |  | 12,188 |  |
| 2023 |  |  | 15,234 |  |
| 2024 |  |  | 12,188 |  |
| Total |  | $ | 48,750 |  |
  (was, 2020-05-05, similarity 0.9241):
[0001193125-20-133708:note_history:57]
| (amount in thousands) |  |  |  |
| 2020 (remaining three months) |  | $ | 3,046 |  |
| 2021 |  |  | 12,188 |  |
| 2022 |  |  | 15,234 |  |
| 2023 |  |  | 12,188 |  |
| 2024 |  |  | 12,188 |  |
| Total |  | $ | 54,844 |  |

- changed (2020-11-03):
[0001193125-20-284755:note_history:58]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as 
of
 September 27, 2019) and $160.9 million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.
  (was, 2020-05-05, similarity 0.8686):
[0001193125-20-133708:note_history:58]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai 
b
aht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities.

- changed (2020-11-03):
[0001193125-20-284755:note_history:59]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a Term Loan Agreement pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the
  (was, 2020-05-05, similarity 0.8007):
[0001193125-20-133708:note_history:59]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a Term Loan Agreement pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million.

- added (2020-11-03):
[0001193125-20-284755:note_history:60]
Company’s previous syndicated senior credit facility

- added (2020-11-03):
[0001193125-20-284755:note_history:61]
agreement.

- added (2020-11-03):
[0001193125-20-284755:note_history:62]
The term loan accrues interest at 
3-month LIBOR plus 1.35%
 and is repayable in quarterly installments of $
3.0
 million, commencing on September 30, 2019. The term loan will mature on 
June 30, 2024
. The Borrower m
a
y prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be

- added (2020-11-03):
[0001193125-20-284755:note_history:63]
re-borrowed.

- changed (2020-11-03):
[0001193125-20-284755:note_history:64]
During the three months ended September 25, 2020, the Company recorded $
0.2
 million of interest expense in connection with this term loan.
  (was, 2020-05-05, similarity 0.8311):
[0001193125-20-133708:note_history:64]
During the three and nine months ended March 27, 2020, the Company recorded $0.5 million and $1.1 million, respectively, of interest expense in connection with this term loan.

- changed (2020-11-03):
[0001193125-20-284755:note_history:65]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt to equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of September 25, 2020, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.
  (was, 2020-05-05, similarity 0.9853):
[0001193125-20-133708:note_history:65]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt to equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. At March 27, 2020, the Company was in compliance with all of its covenants under the Term Loan Agreement.

- changed (2020-11-03):
[0001193125-20-284755:note_history:66]
At September 25, 2020, there was $48.8 million outstanding under the term loan.
  (was, 2020-05-05, similarity 0.9265):
[0001193125-20-133708:note_history:66]
At March 27, 2020, there was $54.8 million outstanding under the term loan.

- changed (2020-11-03):
[0001193125-20-284755:note_history:67]
On May 22, 2014, the Company and 
a
 consortium of banks, entered into a syndicated senior credit facility agreement led by Bank of America (the “Bank of America Facility Agreement”). The Bank of America Facility Agreement provided for a $200.0 million credit line, comprised of a $150.0 million revolving loan facility and a $50.0 million delayed draw term loan facility.
  (was, 2020-05-05, similarity 0.9986):
[0001193125-20-133708:note_history:67]
On May 22, 2014, the Company and a consortium of banks entered into a 
syndicated 
senior credit facility agreement led by Bank of America (the “Bank of America Facility Agreement”). The Bank of America Facility Agreement provided for a $200.0 million credit line, comprised of a $150.0 million revolving loan facility and a $50.0 million delayed draw term loan facility.

- added (2020-11-03):
[0001193125-20-284755:note_history:68]
From time to time,

- added (2020-11-03):
[0001193125-20-284755:note_history:69]
the Company

- changed (2020-11-03):
[0001193125-20-284755:note_history:70]
amended the Bank of America Facility Agreement, before repaying all outstanding amounts under the agreement and terminating such agreement on September 10, 2019.
  (was, 2020-05-05, similarity 0.9091):
[0001193125-20-133708:note_history:70]
From time to time, 
the Company
 amended the Bank of America Facility Agreement, before repaying all outstanding amounts under the agreement and terminating such agreement on September 10, 2019.

- changed (2020-11-03):
[0001193125-20-284755:note_history:71]
The most recent amendment on June 4, 2018 (i) reduced the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) refinanced the outstanding amounts under the revolving loan and term loan facilities into a $65.0 million term loan which was to be repaid in quarterly installments through the maturity date of June 4, 2023; and (iii) reduced the interest rate margins and commitment fees. The term loan bore interest, at the Company’s option, at a rate per annum equal to a LIBOR rate plus a spread of 1.50% to 2.25%, or a base rate plus a spread of 0.50% to 1.25%. During the three months ended September 27, 2019
,
 the Company recorded $0.5 million of interest expense in connection with this term loan.
  (was, 2020-05-05, similarity 0.8835):
[0001193125-20-133708:note_history:71]
The most recent amendment on June 4, 2018 (i) reduced the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) refinanced the outstanding amounts under the revolving loan and term loan facilities into a $65.0 million term loan which was to be repaid in quarterly installments through the maturity date of June 4, 2023, and (iii) reduced the interest rate margins and commitment fees. The term loan bore interest, at the Company’s option, at a rate per annum equal to a LIBOR rate plus a spread of 1.50% to 2.25%, or a base rate plus a spread of 0.50% to 1.25%. During the nine months ended March 27, 2020 and March 29, 2019, the Company recorded $0.5 million and $1.8 million, respectively, of interest expense in connection with this term loan.

- changed (2020-11-03):
[0001193125-20-284755:note_history:72]
On September 10, 2019, the Company fully repaid $61.0 million in principal, accrued interest and other fees under the agreement. The early termination of this agreement did not trigger any early termination fees.
  (was, 2020-05-05, similarity 0.6591):
[0001193125-20-133708:note_history:72]
On September 10, 2019, the Company fully repaid $61.0 million in principal, accrued interest and other fees under the agreement. The early termination of this agreement did not trigger any early termination fees. At March 27, 2020, there were no amounts outstanding under the Bank of America Facility Agreement. At June 28, 2019, there was $60.9 million 
outstanding 
under the Bank of America Facility Agreement, related to the term loan.

- removed (2020-11-03):
[0001193125-20-133708:note_history:73]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27, 2020 |  |  | March 29, 2019 |  |
| Opening balance |  | $ | 60,938 |  |  | $ | 64,188 |  |
| Borrowings during the period |  |  | 60,938 |  |  |  | — |  |
| Repayments during the period |  |  | (67,032 | ) |  |  | (2,438 | ) |
| Closing balance |  | $ | 54,844 |  |  | $ | 61,750 |  |

- removed (2020-11-03):
[0001193125-20-133708:note_history:74]
The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

- removed (2020-11-03):
[0001193125-20-133708:note_history:75]
The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company’s previous credit facility agreement with Bank of America, N.A.

- removed (2020-11-03):
[0001193125-20-133708:note_history:76]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be 
re-borrowed.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-03):
[0001193125-20-284755:note_history:77]
The movements of long-term borrowings for the three months ended September 25, 2020 and September 27, 2019 were as follows:
  (was, 2020-05-05, similarity 0.8756):
[0001193125-20-133708:note_history:77]
The movements of long-term borrowings for the nine months ended March 27, 2020 and March 29, 2019 were as follows:

- added (2020-11-03):
[0001193125-20-284755:note_history:78]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 25, 2020 |  |  | September 27, 2019 |  |
| Opening balance |  | $ | 51,797 |  |  | $ | 60,938 |  |
| Borrowings during the period |  |  | — |  |  |  | 60,938 |  |
| Repayments during the period |  |  | (3,047 | ) |  |  | (60,938 | ) |
| Closing balance |  | $ | 48,750 |  |  | $ | 60,938 |  |

- removed (2020-11-03):
[0001193125-20-133708:note_history:79]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27, 2020 |  |  | March 29, 2019 |  |
| Opening balance |  | $ | 60,938 |  |  | $ | 64,188 |  |
| Borrowings during the period |  |  | 60,938 |  |  |  | — |  |
| Repayments during the period |  |  | (67,032 | ) |  |  | (2,438 | ) |
| Closing balance |  | $ | 54,844 |  |  | $ | 61,750 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-03):
[0001193125-20-284755:note_history:80]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  |  | Maturity |  |  | As of September 25, 2020 |  |  | As of June 26, 2020 |  |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  |  |  |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  |  |  |  |  |  |  |  | (32 | ) |  |  | (32 | ) |
| Long-term borrowings, current portion, net |  |  |  |  |  |  |  |  |  |  | $ | 12,156 |  |  |  | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) |  |  | Repayable in quarterly installments |  |  |  |  | June 2024 |  |  | $ | 48,750 |  |  | $ | 51,797 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  |  | (12,188 | ) |  |  | (12,188 | ) |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  |  |  |  | (87 | ) |  |  | (95 | ) |
| Long-term borrowings, non-current portion, net |  |  |  |  |  |  | $ | 36,475 |  |  | $ | 39,514 |  |
  (was, 2020-05-05, similarity 0.8969):
[0001193125-20-133708:note_history:80]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Rate |  | Conditions |  |  | Maturity |  |  | As of March 27, 2020 |  |  | As of June 28, 2019 |  |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  | $ | 12,188 |  |  | $ | 3,250 |  |
| Less: Unamortized debt issuance costs – current portion |  |  | (32 | ) |  |  | — |  |
| Long-term borrowings, current portion, net |  |  |  |  |  | $ | 12,156 |  |  | $ | 3,250 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1-month LIBOR +1.50% per annum (1) |  |  | Repayable in quarterly installments |  |  |  | June 2023 |  |  | $ | — |  |  | $ | 60,938 |  |
| 3-month LIBOR +1.35% per annum (1) |  |  | Repayable in quarterly installments |  |  |  | June 2024 |  |  |  | 54,844 |  |  |  | — |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (12,188 | ) |  |  | (3,250 | ) |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  |  |  | (103 | ) |  |  | — |  |
| Long-term borrowings, non-current portion, net |  |  |  |  |  | $ | 42,553 |  |  | $ | 57,688 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-11-03):
[0001193125-20-284755:note_history:81]
As
 of
 September 25, 2020, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2020-05-05, similarity 0.95):
[0001193125-20-133708:note_history:81]
As of March 27, 2020, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2020-11-03):
[0001193125-20-284755:note_history:82]
| (amount in thousands) |  |  |  |
| 2021 (remaining nine months) |  | $ | 9,140 |  |
| 2022 |  |  | 12,188 |  |
| 2023 |  |  | 15,234 |  |
| 2024 |  |  | 12,188 |  |
| Total |  | $ | 48,750 |  |
  (was, 2020-05-05, similarity 0.9241):
[0001193125-20-133708:note_history:82]
| (amount in thousands) |  |  |  |
| 2020 (remaining three months) |  | $ | 3,046 |  |
| 2021 |  |  | 12,188 |  |
| 2022 |  |  | 15,234 |  |
| 2023 |  |  | 12,188 |  |
| 2024 |  |  | 12,188 |  |
| Total |  | $ | 54,844 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-11-03):
[0001193125-20-284755:note_history:83]
The following table presents total revenues by geographic region:
  (was, 2020-05-05, similarity 0.9767):
[0001193125-20-133708:note_history:83]
The following tables present total revenues by geographic region

- changed (2020-11-03):
[0001193125-20-284755:note_history:84]
| (amount in thousands, except percentages) |  | Three Months Ended September 25, 2020 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 207,402 |  |  |  | 47.5 | % |
| Asia-Pacific |  |  | 145,646 |  |  |  | 33.4 |  |
| Europe |  |  | 83,591 |  |  |  | 19.1 |  |
|  |  | $ | 436,639 |  |  |  | 100.0 | % |
  (was, 2020-05-05, similarity 0.702):
[0001193125-20-133708:note_history:84]
| (amount in thousands, except percentages) |  | Three Months Ended March 27, 2020 |  |  | As a % of Total Revenues |  |  | Nine Months Ended March 27, 2020 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 206,751 |  |  |  | 50.3 | % |  | $ | 631,096 |  |  |  | 51.0 | % |
| Asia-Pacific |  |  | 141,639 |  |  |  | 34.4 |  |  |  | 401,209 |  |  |  | 32.5 |  |
| Europe |  |  | 62,820 |  |  |  | 15.3 |  |  |  | 204,418 |  |  |  | 16.5 |  |
| Total |  | $ | 411,210 |  |  |  | 100.0 | % |  | $ | 1,236,723 |  |  |  | 100.0 | % |

- changed (2020-11-03):
[0001193125-20-284755:note_history:85]
| (amount in thousands, except percentages) |  | Three Months Ended September 27, 2019 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 200,947 |  |  |  | 50.3 | % |
| Asia-Pacific |  |  | 118,423 |  |  |  | 29.7 |  |
| Europe |  |  | 79,926 |  |  |  | 20.0 |  |
|  |  | $ | 399,296 |  |  |  | 100.0 | % |
  (was, 2020-05-05, similarity 0.702):
[0001193125-20-133708:note_history:85]
| (amount in thousands, except percentages) |  | Three Months Ended March 29, 2019 |  |  | As a % of Total Revenues |  |  | Nine Months Ended March 29, 2019 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 195,504 |  |  |  | 49.0 | % |  | $ | 558,028 |  |  |  | 47.3 | % |
| Asia-Pacific |  |  | 151,263 |  |  |  | 37.9 |  |  |  | 469,921 |  |  |  | 39.9 |  |
| Europe |  |  | 52,184 |  |  |  | 13.1 |  |  |  | 151,259 |  |  |  | 12.8 |  |
| Total |  | $ | 398,951 |  |  |  | 100.0 | % |  | $ | 1,179,208 |  |  |  | 100.0 | % |

- removed (2020-11-03):
[0001193125-20-133708:note_history:86]
:


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-11-03):
[0001193125-20-284755:note_history:87]
Revenue by Geographic Area and End Market
  (was, 2020-05-05, similarity 0.7761):
[0001193125-20-133708:note_history:87]
Revenue by geographic area

- added (2020-11-03):
[0001193125-20-284755:note_history:88]
Revenues are attributed to a particular geographic area based on

- added (2020-11-03):
[0001193125-20-284755:note_history:89]
the bill-to-location of

- changed (2020-11-03):
[0001193125-20-284755:note_history:90]
the Company’s customers. The Company operates in three geographic regions: North America, Asia-Pacific and Europe.
  (was, 2020-05-05, similarity 0.7059):
[0001193125-20-133708:note_history:90]
Total revenues are attributed to a particular geographic area based on the
 bill-to-location
 of the Company’s customers. The Company operates in three geographic regions: North America, Asia-Pacific and Europe.

- changed (2020-11-03):
[0001193125-20-284755:note_history:91]
The following table presents total revenues by geographic region:
  (was, 2020-05-05, similarity 0.9767):
[0001193125-20-133708:note_history:91]
The following tables present total revenues by geographic region

- changed (2020-11-03):
[0001193125-20-284755:note_history:92]
| (amount in thousands, except percentages) |  | Three Months Ended September 25, 2020 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 207,402 |  |  |  | 47.5 | % |
| Asia-Pacific |  |  | 145,646 |  |  |  | 33.4 |  |
| Europe |  |  | 83,591 |  |  |  | 19.1 |  |
|  |  | $ | 436,639 |  |  |  | 100.0 | % |
  (was, 2020-05-05, similarity 0.702):
[0001193125-20-133708:note_history:92]
| (amount in thousands, except percentages) |  | Three Months Ended March 27, 2020 |  |  | As a % of Total Revenues |  |  | Nine Months Ended March 27, 2020 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 206,751 |  |  |  | 50.3 | % |  | $ | 631,096 |  |  |  | 51.0 | % |
| Asia-Pacific |  |  | 141,639 |  |  |  | 34.4 |  |  |  | 401,209 |  |  |  | 32.5 |  |
| Europe |  |  | 62,820 |  |  |  | 15.3 |  |  |  | 204,418 |  |  |  | 16.5 |  |
| Total |  | $ | 411,210 |  |  |  | 100.0 | % |  | $ | 1,236,723 |  |  |  | 100.0 | % |

- changed (2020-11-03):
[0001193125-20-284755:note_history:93]
| (amount in thousands, except percentages) |  | Three Months Ended September 27, 2019 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 200,947 |  |  |  | 50.3 | % |
| Asia-Pacific |  |  | 118,423 |  |  |  | 29.7 |  |
| Europe |  |  | 79,926 |  |  |  | 20.0 |  |
|  |  | $ | 399,296 |  |  |  | 100.0 | % |
  (was, 2020-05-05, similarity 0.702):
[0001193125-20-133708:note_history:93]
| (amount in thousands, except percentages) |  | Three Months Ended March 29, 2019 |  |  | As a % of Total Revenues |  |  | Nine Months Ended March 29, 2019 |  |  | As a % of Total Revenues |  |
| North America |  | $ | 195,504 |  |  |  | 49.0 | % |  | $ | 558,028 |  |  |  | 47.3 | % |
| Asia-Pacific |  |  | 151,263 |  |  |  | 37.9 |  |  |  | 469,921 |  |  |  | 39.9 |  |
| Europe |  |  | 52,184 |  |  |  | 13.1 |  |  |  | 151,259 |  |  |  | 12.8 |  |
| Total |  | $ | 398,951 |  |  |  | 100.0 | % |  | $ | 1,179,208 |  |  |  | 100.0 | % |

- changed (2020-11-03):
[0001193125-20-284755:note_history:94]
| (amount in thousands, except percentages) |  | Three Months Ended September 25, 2020 |  |  | As a % of Total Revenues |  |
| Optical communications |  | $ | 343,917 |  |  |  | 78.8 | % |
| Lasers, sensors and other |  |  | 92,722 |  |  |  | 21.2 |  |
| Total |  | $ | 436,639 |  |  |  | 100.0 | % |
  (was, 2020-05-05, similarity 0.6296):
[0001193125-20-133708:note_history:94]
| (amount in thousands, except percentages) |  | Three Months Ended March 27, 2020 |  |  | As a % of Total Revenues |  |  | Nine Months Ended March 27, 2020 |  |  | As a % of Total Revenues |  |
| Optical communications |  | $ | 308,566 |  |  |  | 75.0 | % |  | $ | 933,013 |  |  |  | 75.4 | % |
| Lasers, sensors and other |  |  | 102,644 |  |  |  | 25.0 |  |  |  | 303,710 |  |  |  | 24.6 |  |
| Total |  | $ | 411,210 |  |  |  | 100.0 | % |  | $ | 1,236,723 |  |  |  | 100.0 | % |

- changed (2020-11-03):
[0001193125-20-284755:note_history:95]
| (amount in thousands, except percentages) |  | Three Months Ended September 27, 2019 |  |  | As a % of Total Revenues |  |
| Optical communications |  | $ | 302,379 |  |  |  | 75.7 | % |
| Lasers, sensors and other |  |  | 96,917 |  |  |  | 24.3 |  |
| Total |  | $ | 399,296 |  |  |  | 100.0 | % |
  (was, 2020-05-05, similarity 0.6296):
[0001193125-20-133708:note_history:95]
| (amount in thousands, except percentages) |  | Three Months Ended March 29, 2019 |  |  | As a % of Total Revenues |  |  | Nine Months Ended March 29, 2019 |  |  | As a % of Total Revenues |  |
| Optical communications |  | $ | 298,139 |  |  |  | 74.7 | % |  | $ | 884,454 |  |  |  | 75.0 | % |
| Lasers, sensors and other |  |  | 100,812 |  |  |  | 25.3 |  |  |  | 294,754 |  |  |  | 25.0 |  |
| Total |  | $ | 398,951 |  |  |  | 100.0 | % |  | $ | 1,179,208 |  |  |  | 100.0 | % |

- changed (2020-11-03):
[0001193125-20-284755:note_history:96]
A contract asset is recognized when the Company has recognized revenues prior to generating an invoice for payment. Contract assets are classified separately within the unaudited condensed consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional.
  (was, 2020-05-05, similarity 0.8559):
[0001193125-20-133708:note_history:96]
A contract asset is recognized when the Company has recognized revenues prior to generating an invoice for payment. Contract assets are classified separately within the unaudited condensed consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. During the nine months ended March 27, 2020, the Company had no impairment for contract assets recognized.

- changed (2020-11-03):
[0001193125-20-284755:note_history:97]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the three months ended September 25, 2020:
  (was, 2020-05-05, similarity 0.9408):
[0001193125-20-133708:note_history:97]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the nine months ended March 27, 2020:

- changed (2020-11-03):
[0001193125-20-284755:note_history:98]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 26, 2020 |  | $ | 13,256 |  |
| Revenue recognized |  |  | 17,444 |  |
| Amounts collected or invoiced |  |  | (18,943 | ) |
| Ending balance, September 25, 2020 |  | $ | 11,757 |  |
  (was, 2020-05-05, similarity 0.9721):
[0001193125-20-133708:note_history:98]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 28, 2019 |  | $ | 12,447 |  |
| Revenue recognized |  |  | 58,037 |  |
| Amounts collected or invoiced |  |  | (54,071 | ) |
| Ending balance, March 27, 2020 |  | $ | 16,413 |  |

- changed (2020-11-03):
[0001193125-20-284755:note_history:99]
| (amount in thousands) |  | Contract Liabilities |  |
| Beginning balance, June 26, 2020 |  | $ | 1,556 |  |
| Additions advance payment received during the period |  |  | 4,308 |  |
| Revenue recognized |  |  | (4,898 | ) |
| Ending balance, September 25, 2020 |  | $ | 966 |  |
  (was, 2020-05-05, similarity 0.9538):
[0001193125-20-133708:note_history:99]
| (amount in thousands) |  | Contract Liabilities |  |
| Beginning balance, June 28, 2019 |  | $ | 2,239 |  |
| Advance payment received during the period |  |  | 6,857 |  |
| Revenue recognized |  |  | (7,155 | ) |
| Ending balance, March 27, 2020 |  | $ | 1,941 |  |

- removed (2020-11-03):
[0001193125-20-133708:note_history:100]
The Company derives revenues primarily from the assembly of products under supply agreements with its customers and the fabrication of customized optics and glass. The Company recognizes revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the Company expects to be entitled in exchange for such goods or services. In order to meet this requirement, the Company applies the following five steps: (1) identify the contract with a customer, (2) identify the performance obligations under the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations under the contract, and (5) recognize revenue when a performance obligation is satisfied. Revenue is recognized net of any taxes collected from customers, which is subsequently remitted to governmental authorities.

- removed (2020-11-03):
[0001193125-20-133708:note_history:101]
A performance obligation is a contractual promise to transfer a distinct good or service to the customer. In contracts with multiple performance obligations, the Company identifies each performance obligation and evaluates whether the performance obligation is distinct within the context of the contract at contract inception. The majority of the Company’s contracts have a single performance obligation, as the promise to transfer the individual goods or services is not separately identifiable from other promises under the contracts and, therefore, is not distinct.

- removed (2020-11-03):
[0001193125-20-133708:note_history:102]
The Company manufactures products that are customized to customers’ specifications. However, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for recognizing revenue over time are not met. Based on a review of its contracts, the Company determined that it does not have contractual rights to bill profit for work in progress in the event of a contract termination, an event which is expected to be infrequent. Further, in limited circumstances, substantive acceptance by the customer will result in the deferral of revenue until acceptance is formally received from the customer. Judgment may be required in determining if the acceptance clause provides for substantive acceptance.

- removed (2020-11-03):
[0001193125-20-133708:note_history:103]
Certain customers may request the Company to store finished products purchased by them at the Company’s warehouse. In these instances, the Company receives a written request from the customer asking the Company to hold the inventory at the Company’s warehouse, and the ordered goods cannot be used to fulfill other customer orders. In these situations, revenue is only recognized when the goods are completed and ready for shipment and transferred to the Company’s warehouse.

- removed (2020-11-03):
[0001193125-20-133708:note_history:104]
Our customers generally are obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by our customers within a specified period of time, or that are no longer required due to a product’s cancellation or 
end-of-life,
 are typically designated as excess or obsolete inventory under our contracts. After materials are designated as either excess or obsolete inventory, our customers are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

- removed (2020-11-03):
[0001193125-20-133708:note_history:105]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. In determining the transaction price, the Company evaluates whether the price is subject to refund or adjustment to determine the net consideration to which the Company expects to be entitled. The Company generally does not grant return privileges other than for defective products during the warranty period. The Company generally provides a warranty of between one to five years on the product.

- removed (2020-11-03):
[0001193125-20-133708:note_history:106]
The Company has applied the practical expedient to not adjust the amount of revenue to be recognized due to the effects of a significant financing component when the Company expects, at contract inception, that the period between the transfer of goods and/or services and the payment for those goods and/or services will be less than one year.

- removed (2020-11-03):
[0001193125-20-133708:note_history:107]
Warranty provision

- removed (2020-11-03):
[0001193125-20-133708:note_history:108]
Provisions for estimated expenses relating to pr
o
duct warranties are made at the time the products are sold using historical experience. Generally, this warranty is limited to workmanship, and the Company’s liability is capped at the price of the product. The provisions will be adjusted when experience indicates an expected settlement will differ from initial estimates.

- removed (2020-11-03):
[0001193125-20-133708:note_history:109]
Contract costs

- removed (2020-11-03):
[0001193125-20-133708:note_history:110]
The incremental costs of obtaining a contract with a customer are recognized as an asset (not expensed as incurred) if such costs are expected to be recovered. Incremental costs of obtaining a contract are costs that the Company would not have incurred if the contract had not been obtained (e.g., sales commissions or similar incentive payments linked directly to new or modified customer contracts). Costs that would have been incurred regardless of whether a customer contract was obtained (e.g., costs of pursuing the contact, legal advice, etc.) are expensed as incurred, unless such costs are explicitly chargeable to the customer. During the nine months ended

- removed (2020-11-03):
[0001193125-20-133708:note_history:111]
March 27, 2020, the Company did not have any incremental costs of obtaining a contract.

- removed (2020-11-03):
[0001193125-20-133708:note_history:112]
Shipping and handling

- removed (2020-11-03):
[0001193125-20-133708:note_history:113]
Shipping costs billed to customers are recorded as revenue. Shipping and handling expense related to costs incurred to deliver product are recognized within cost of goods sold. The Company accounts for shipping and handling activities that occur after control has transferred as a fulfillment cost as opposed to a separate performance obligation, and the costs of shipping and handling are recognized concurrently with the related revenue.

- removed (2020-11-03):
[0001193125-20-133708:note_history:114]
:

- removed (2020-11-03):
[0001193125-20-133708:note_history:115]
The following tables set forth our revenues by end market:


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2020-11-03):
[0001193125-20-284755:note_history:116]
On October 1, 2020, the Company extended the payment terms of $24.3 million in funds it had advanced to a customer and accrued interest from September 30, 2020 to April 1, 2021, and reduced the interest rate effective from October 1, 2020. The extension is due to the customer’s agreement to transfer additional manufacturing operations to the Company’s facilities in Thailand beginning in November 2020. These funds will be offset by amount due to this customer for the purchases of certain inventories. (See Note 8)

- added (2020-11-03):
[0001193125-20-284755:note_history:117]
The Company has also committed to purchase $26.0 million worth of inventories from the customer.

- removed (2020-11-03):
[0001193125-20-133708:note_history:118]
The outbreak of a novel strain of coronavirus 
(“COVID-19”)
 was recognized as a pandemic by the World Health Organization on March 11, 2020. The outbreak has spread globally, including to Thailand, the United States, UK and Europe.

- removed (2020-11-03):
[0001193125-20-133708:note_history:119]
The implications of 
COVID-19
 on the Company’s business remain uncertain. Measures taken by governmental authorities and private actors to limit the spread of 
COVID-19
 may interfere with the ability of the Company’s employees, suppliers and other business providers to carry out their assigned tasks or supply materials at ordinary levels of performance. While the Company’s operations are impacted as a result of this pandemic, the Company has not experienced a direct, materially adverse financial impact. The future impact of this pandemic on the Company’s business, financial condition, results of operations and cash flows cannot be predicted. The Company continues to monitor developments with the spread of 
COVID-19,
 actions taken by governmental authorities and private actors, and impacts to the Company’s suppliers and customers. The Company continues to work to minimize disruptions to its supply chain and manufacturing capabilities, and to ensure the safety of its employees. While the Company’s operations are impacted as a result of this pandemic, including as a result of restrictions on employees’ ability to travel and requirements that portions of the Company’s workforce work from home, the Company has not experienced a direct, materially adverse financial impact.

- removed (2020-11-03):
[0001193125-20-133708:note_history:120]
The Company is not currently aware of any business interruption or loss contingencies related to 
COVID-19
 that would require recognition in the third quarter of fiscal 2020.
