# FN 8-K — 0001193125-20-283944 filed 2020-11-02

## item codes, every 8-K on or before 2020-11-03

- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2020-11-03

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-20-283944:8k_2_02:1]
EX-99.1
2
d47648dex991.htm
EX-99.1

[0001193125-20-283944:8k_2_02:2]
EX-99.1

[0001193125-20-283944:8k_2_02:3]
Exhibit 99.1

[0001193125-20-283944:8k_2_02:4]
Fabrinet Announces First Quarter Fiscal Year 2021 Financial Results

[0001193125-20-283944:8k_2_02:5]
|  | • |  | Record First Quarter Revenue of $436.6 Million Exceeds Guidance |

[0001193125-20-283944:8k_2_02:6]
|  | • |  | Record Net Income per Share Exceeds Guidance |

[0001193125-20-283944:8k_2_02:7]
|  | • |  | GAAP Net Income per Share Increases 28% and Non-GAAP Net Income per Share Increases 22% Year-over-Year |

[0001193125-20-283944:8k_2_02:8]
BANGKOK, Thailand – November 2, 2020 – Fabrinet (NYSE:
FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its first fiscal
quarter ended September 25, 2020.

[0001193125-20-283944:8k_2_02:9]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “We have a lot to be optimistic about, as numerous
drivers contributed to our growth and outperformance in the first quarter. Our strategy is working as strength from newer programs offsets the softness we see in certain markets.”

[0001193125-20-283944:8k_2_02:10]
Grady continued, “We believe that we can grow faster than the markets we serve by focusing on attracting new customers, winning new projects at existing
customers, and pursuing new programs that leverage our advanced precision manufacturing capabilities.”

[0001193125-20-283944:8k_2_02:11]
First Quarter Fiscal Year 2021 Financial
Highlights

[0001193125-20-283944:8k_2_02:12]
GAAP Results

[0001193125-20-283944:8k_2_02:13]
|  | • |  | Revenue for the first quarter of fiscal year 2021 was $436.6 million, compared to $399.3 million in the first quarter of fiscal year 2020. |

[0001193125-20-283944:8k_2_02:14]
|  | • |  | GAAP net income for the first quarter of fiscal year 2021 was $33.1 million, compared to GAAP net income of $26.0 million for the first quarter of fiscal year 2020. |

[0001193125-20-283944:8k_2_02:15]
|  | • |  | GAAP net income per diluted share for the first quarter of fiscal year 2021 was $0.88, compared to GAAP net income per diluted share of $0.69 for the first quarter of fiscal year 2020. |

[0001193125-20-283944:8k_2_02:16]
Non-GAAP
Results

[0001193125-20-283944:8k_2_02:17]
|  | • |  | Non-GAAP net income for the first quarter of fiscal year 2021 was $39.3 million, compared to non-GAAP net income of $32.2 million for the first quarter of fiscal year 2020. |

[0001193125-20-283944:8k_2_02:18]
|  | • |  | Non-GAAP net income per diluted share for the first quarter of fiscal year 2021 was $1.05, compared to non-GAAP net income per diluted share of $0.86 for the first quarter of fiscal year 2020. |

[0001193125-20-283944:8k_2_02:19]
Business Outlook

[0001193125-20-283944:8k_2_02:20]
Based on information available as of
November 2, 2020, Fabrinet is issuing guidance for its second fiscal quarter ending December 25, 2020, as follows:

[0001193125-20-283944:8k_2_02:21]
|  | • |  | Fabrinet expects second quarter revenue to be in the range of $420 million to $440 million. |

[0001193125-20-283944:8k_2_02:22]
|  | • |  | GAAP net income per diluted share is expected to be in the range of $0.84 to $0.91, based on approximately 37.7 million fully diluted shares outstanding. |

[0001193125-20-283944:8k_2_02:23]
|  | • |  | Non-GAAP net income per diluted share is expected to be in the range of $1.00 to $1.07, based on approximately 37.7 million fully diluted shares outstanding. |

[0001193125-20-283944:8k_2_02:24]
Conference Call Information

[0001193125-20-283944:8k_2_02:25]
| What: |  | Fabrinet First Quarter Fiscal Year 2021 Financial Results Call |
| When: |  | Monday, November 2, 2020 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic |
|  |  | (253) 237-1137, international |
|  |  | Passcode: 9490738 |
| Replay: |  | (855) 859-2056, domestic |
|  |  | (404) 537-3406, international |
|  |  | Passcode: 9490738 |
| Webcast: |  | http://investor.fabrinet.com/ (live and replay) |

[0001193125-20-283944:8k_2_02:26]
This press release and any other information related to the call will also be posted on Fabrinet’s website at
http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-20-283944:8k_2_02:27]
About Fabrinet

[0001193125-20-283944:8k_2_02:28]
Fabrinet is a leading provider of
advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive
components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain
management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities
in Thailand, the United States of America, the People’s Republic of China, Israel and the United Kingdom. For more information visit: www.fabrinet.com.

[0001193125-20-283944:8k_2_02:29]
Forward-Looking Statements

[0001193125-20-283944:8k_2_02:30]
optical communications, industrial lasers and sensors markets than we forecast; difficulties expanding into additional markets, such as the semiconductor processing, biotechnology, metrology and
materials processing markets; increased competition in the optical manufacturing services markets; difficulties in delivering products and services that compete effectively from a price and performance perspective; our reliance on a small number of
customers and suppliers; difficulties in managing our operating costs; difficulties in managing and operating our business across multiple countries (including Thailand, the People’s Republic of China, Israel, the U.S. and the U.K.); and other
important factors as described in reports and documents we file from time to time with the Securities and Exchange Commission (SEC), including the factors described under the section captioned “Risk Factors” in our Annual Report on Form 10-K, filed with the SEC on August 18, 2020. We disclaim any obligation to update information contained in these forward-looking statements whether as a result of new information, future events, or otherwise.

[0001193125-20-283944:8k_2_02:31]
Use of Non-GAAP Financials

[0001193125-20-283944:8k_2_02:32]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful
supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; depreciation of fair value uplift; amortization of intangibles; and
amortization of deferred debt issuance costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has
material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these
non-GAAP financial measures in conjunction with GAAP financial measures.

[0001193125-20-283944:8k_2_02:33]
These
non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater
transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the
purposes of determining employee incentive plan compensation.

[0001193125-20-283944:8k_2_02:34]
SOURCE: Fabrinet

[0001193125-20-283944:8k_2_02:35]
Investor Contact:

[0001193125-20-283944:8k_2_02:36]
Garo Toomajanian

[0001193125-20-283944:8k_2_02:37]
ir@fabrinet.com

[0001193125-20-283944:8k_2_02:38]
FABRINET

[0001193125-20-283944:8k_2_02:39]
CONDENSED CONSOLIDATED BALANCE SHEETS (unaudited)

[0001193125-20-283944:8k_2_02:40]
| (in thousands of U.S. dollars, except share data and par value) |  | September 25,2020 |  |  | June 26,2020 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 189,201 |  |  | $ | 225,430 |  |
| Short-term restricted cash |  |  | 7,402 |  |  |  | 7,402 |  |
| Short-term investments |  |  | 307,238 |  |  |  | 262,693 |  |
| Trade accounts receivable, net of allowance for doubtful accounts of $186 and $336, respectively |  |  | 289,162 |  |  |  | 272,665 |  |
| Contract assets |  |  | 11,757 |  |  |  | 13,256 |  |
| Inventories |  |  | 339,429 |  |  |  | 309,786 |  |
| Other receivable |  |  | 24,310 |  |  |  | 24,310 |  |
| Prepaid expenses |  |  | 4,095 |  |  |  | 5,399 |  |
| Other current assets |  |  | 7,827 |  |  |  | 14,508 |  |
| Total current assets |  |  | 1,180,421 |  |  |  | 1,135,449 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 227,623 |  |  |  | 228,274 |  |
| Intangibles, net |  |  | 4,147 |  |  |  | 4,312 |  |
| Operating right-of-use assets |  |  | 7,228 |  |  |  | 8,068 |  |
| Deferred tax assets |  |  | 5,766 |  |  |  | 5,675 |  |
| Other non-current assets |  |  | 221 |  |  |  | 202 |  |
| Total non-current assets |  |  | 244,985 |  |  |  | 246,531 |  |
| Total Assets |  | $ | 1,425,406 |  |  | $ | 1,381,980 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion, net |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Trade accounts payable |  |  | 284,173 |  |  |  | 251,603 |  |
| Fixed assets payable |  |  | 9,616 |  |  |  | 15,127 |  |
| Contract liabilities |  |  | 966 |  |  |  | 1,556 |  |
| Operating lease liabilities, current portion |  |  | 2,098 |  |  |  | 1,979 |  |
| Income tax payable |  |  | 2,940 |  |  |  | 2,242 |  |
| Accrued payroll, bonus and related expenses |  |  | 18,881 |  |  |  | 19,265 |  |
| Accrued expenses |  |  | 10,077 |  |  |  | 8,979 |  |
| Other payables |  |  | 14,542 |  |  |  | 21,514 |  |
| Total current liabilities |  |  | 355,449 |  |  |  | 334,421 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term borrowings, non-current portion, net |  |  | 36,475 |  |  |  | 39,514 |  |
| Deferred tax liability |  |  | 4,927 |  |  |  | 4,729 |  |
| Operating lease liability, non-current portion |  |  | 4,906 |  |  |  | 5,873 |  |
| Severance liabilities |  |  | 17,609 |  |  |  | 17,379 |  |
| Other non-current liabilities |  |  | 5,337 |  |  |  | 5,655 |  |
| Total non-current liabilities |  |  | 69,254 |  |  |  | 73,150 |  |
| Total Liabilities |  |  | 424,703 |  |  |  | 407,571 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding at September 25, 2020 and June 26, 2020) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 38,680,659 shares and 38,471,967 shares issued at September 25, 2020 and June 26, 2020, respectively; and 36,936,556 shares and 36,727,864 shares outstanding at September 25, 2020 and June 26, 2020, respectively) |  |  | 387 |  |  |  | 385 |  |
| Additional paid-in capital |  |  | 171,715 |  |  |  | 175,610 |  |
| Less: Treasury shares (1,744,103 shares and 1,744,103 shares at September 25, 2020 and June 26, 2020, respectively) |  |  | (68,501 | ) |  |  | (68,501 | ) |
| Accumulated other comprehensive loss |  |  | (3,904 | ) |  |  | (1,147 | ) |
| Retained earnings |  |  | 901,006 |  |  |  | 868,062 |  |
| Total Shareholders’ Equity |  |  | 1,000,703 |  |  |  | 974,409 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 1,425,406 |  |  | $ | 1,381,980 |  |

[0001193125-20-283944:8k_2_02:41]
FABRINET

[0001193125-20-283944:8k_2_02:42]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME

[0001193125-20-283944:8k_2_02:43]
(unaudited)

[0001193125-20-283944:8k_2_02:44]
|  |  | Three Months Ended |  |
| (in thousands of U.S. dollars, except per share data) |  | September 25, 2020 |  |  | September 27, 2019 |  |
| Revenues |  | $ | 436,639 |  |  | $ | 399,296 |  |
| Cost of revenues |  |  | (386,159 | ) |  |  | (353,309 | ) |
| Gross profit |  |  | 50,480 |  |  |  | 45,987 |  |
| Selling, general and administrative expenses |  |  | (16,863 | ) |  |  | (16,000 | ) |
| Operating income |  |  | 33,617 |  |  |  | 29,987 |  |
| Interest income |  |  | 1,104 |  |  |  | 2,098 |  |
| Interest expense |  |  | (251 | ) |  |  | (2,393 | ) |
| Foreign exchange gain (loss), net |  |  | 128 |  |  |  | (1,953 | ) |
| Other income (expense), net |  |  | 121 |  |  |  | 377 |  |
| Income before income taxes |  |  | 34,719 |  |  |  | 28,116 |  |
| Income tax expense |  |  | (1,668 | ) |  |  | (2,159 | ) |
| Net income |  |  | 33,051 |  |  |  | 25,957 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities |  |  | (325 | ) |  |  | 35 |  |
| Change in net unrealized gain (loss) on derivative instruments |  |  | (3,208 | ) |  |  | 39 |  |
| Change in net retirement benefits plan – prior service cost |  |  | 173 |  |  |  | 83 |  |
| Change in foreign currency translation adjustment |  |  | 603 |  |  |  | (369 | ) |
| Total other comprehensive income (loss), net of tax |  |  | (2,757 | ) |  |  | (212 | ) |
| Net comprehensive income |  | $ | 30,294 |  |  | $ | 25,745 |  |
| Earnings per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.90 |  |  | $ | 0.70 |  |
| Diluted |  | $ | 0.88 |  |  | $ | 0.69 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |
| Basic |  |  | 36,818 |  |  |  | 36,913 |  |
| Diluted |  |  | 37,383 |  |  |  | 37,529 |  |

[0001193125-20-283944:8k_2_02:45]
FABRINET

[0001193125-20-283944:8k_2_02:46]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited)

[0001193125-20-283944:8k_2_02:47]
|  |  | Three Months Ended |  |
| (in thousands of U.S. dollars) |  | September 25,2020 |  |  | September 27,2019 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income for the period |  | $ | 33,051 |  |  | $ | 25,957 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 8,570 |  |  |  | 7,465 |  |
| (Gain) loss on disposal of property, plant and equipment |  |  | (19 | ) |  |  | 8 |  |
| (Gain) loss from sales and maturities of available-for-sale securities |  |  | — |  |  |  | (67 | ) |
| Amortization of investment discount |  |  | 481 |  |  |  | 65 |  |
| Amortization of deferred debt issuance costs |  |  | 8 |  |  |  | 2 |  |
| (Reversal of) allowance for doubtful accounts |  |  | (257 | ) |  |  | (5 | ) |
| Unrealized (gain) loss on exchange rate and fair value of foreign currency forward contracts |  |  | (890 | ) |  |  | 1,479 |  |
| Unrealized loss (gain) on fair value of interest rate swaps |  |  | — |  |  |  | 1,671 |  |
| Amortization of fair value at hedge inception of interest rate swaps |  |  | (359 | ) |  |  | — |  |
| Share-based compensation |  |  | 6,027 |  |  |  | 5,995 |  |
| Deferred income tax |  |  | 56 |  |  |  | 705 |  |
| Other non-cash expenses |  |  | 96 |  |  |  | 53 |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | (16,497 | ) |  |  | (12,967 | ) |
| Contract assets |  |  | 1,499 |  |  |  | 827 |  |
| Inventories |  |  | (29,643 | ) |  |  | (27,898 | ) |
| Other current assets and non-current assets |  |  | 7,812 |  |  |  | 4,225 |  |
| Trade accounts payable |  |  | 33,546 |  |  |  | (5,263 | ) |
| Contract liabilities |  |  | (590 | ) |  |  | 27 |  |
| Income tax payable |  |  | 871 |  |  |  | 733 |  |
| Severance liabilities |  |  | 745 |  |  |  | 811 |  |
| Other current liabilities and non-current liabilities |  |  | (10,001 | ) |  |  | (1,176 | ) |
| Net cash provided by operating activities |  |  | 34,506 |  |  |  | 2,647 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of short-term investments |  |  | (79,103 | ) |  |  | (62,880 | ) |
| Proceeds from sales of short-term investments |  |  | — |  |  |  | 49,472 |  |
| Proceeds from maturities of short-term investments |  |  | 33,750 |  |  |  | 31,673 |  |
| Purchase of property, plant and equipment |  |  | (12,572 | ) |  |  | (6,343 | ) |
| Purchase of intangibles |  |  | (530 | ) |  |  | (246 | ) |
| Proceeds from disposal of property, plant and equipment |  |  | 21 |  |  |  | — |  |
| Net cash (used in) provided by investing activities |  |  | (58,434 | ) |  |  | 11,676 |  |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Payment of debt issuance costs |  |  | — |  |  |  | (153 | ) |
| Proceeds from long-term borrowings |  |  | — |  |  |  | 60,938 |  |
| Repayment of long-term borrowings |  |  | (3,047 | ) |  |  | (60,938 | ) |
| Repayment of finance lease liability |  |  | (100 | ) |  |  | (109 | ) |
| Withholding tax related to net share settlement of restricted share units |  |  | (9,920 | ) |  |  | (4,144 | ) |
| Net cash used in financing activities |  |  | (13,067 | ) |  |  | (4,406 | ) |
| Net (decrease) increase in cash, cash equivalents and restricted cash |  |  | (36,995 | ) |  |  | 9,917 |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at the beginning of period |  |  | 232,832 |  |  |  | 188,241 |  |
| (Decrease) increase in cash, cash equivalents and restricted cash |  |  | (36,995 | ) |  |  | 9,917 |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash |  |  | 766 |  |  |  | (41 | ) |
| Cash, cash equivalents and restricted cash at the end of period |  | $ | 196,603 |  |  | $ | 198,117 |  |
| Non-cash investing and financing activities |  |  |  |  |  |  |  |  |
| Construction, software and equipment-related payables |  | $ | 9,616 |  |  | $ | 9,816 |  |

[0001193125-20-283944:8k_2_02:48]
FABRINET

[0001193125-20-283944:8k_2_02:49]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited) (Continued)

[0001193125-20-283944:8k_2_02:50]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the unaudited condensed consolidated balance
sheets that sum to the total of the same amounts shown in the unaudited condensed consolidated statements of cash flows:

[0001193125-20-283944:8k_2_02:51]
|  |  | As of |  |
| (amount in thousands) |  | September 25,2020 |  |  | September 27,2019 |  |
| Cash and cash equivalents |  | $ | 189,201 |  |  | $ | 168,535 |  |
| Restricted cash |  |  | 7,402 |  |  |  | 29,582 |  |
| Cash, cash equivalents and restricted cash |  | $ | 196,603 |  |  | $ | 198,117 |  |

[0001193125-20-283944:8k_2_02:52]
FABRINET

[0001193125-20-283944:8k_2_02:53]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-20-283944:8k_2_02:54]
|  |  | Three Months Ended |  |
|  |  | September 25, 2020 |  |  | September 27, 2019 |  |
| (in thousands of U.S. dollars, except per share data) |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |
| GAAP measures |  | $ | 33,051 |  |  | $ | 0.88 |  |  | $ | 25,957 |  |  | $ | 0.69 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,825 |  |  |  | 0.05 |  |  |  | 1,720 |  |  |  | 0.05 |  |
| Depreciation of fair value uplift |  |  | 84 |  |  |  | 0.00 |  |  |  | 79 |  |  |  | 0.00 |  |
| Total related to gross profit |  |  | 1,909 |  |  |  | 0.05 |  |  |  | 1,799 |  |  |  | 0.05 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 4,202 |  |  |  | 0.11 |  |  |  | 4,275 |  |  |  | 0.11 |  |
| Amortization of intangibles |  |  | 131 |  |  |  | 0.00 |  |  |  | 143 |  |  |  | 0.00 |  |
| Total related to selling, general and administrative expenses |  |  | 4,333 |  |  |  | 0.12 |  |  |  | 4,418 |  |  |  | 0.12 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of deferred debt issuance costs |  |  | 8 |  |  |  | 0.00 |  |  |  | 2 |  |  |  | 0.00 |  |
| Total related to other incomes and other expenses |  |  | 8 |  |  |  | 0.00 |  |  |  | 2 |  |  |  | 0.00 |  |
| Total related to net income & EPS |  |  | 6,250 |  |  |  | 0.17 |  |  |  | 6,219 |  |  |  | 0.17 |  |
| Non-GAAP measures |  | $ | 39,301 |  |  | $ | 1.05 |  |  | $ | 32,176 |  |  | $ | 0.86 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 37,383 |  |  |  |  |  |  |  | 37,529 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 37,383 |  |  |  |  |  |  |  | 37,529 |  |

[0001193125-20-283944:8k_2_02:55]
FABRINET

[0001193125-20-283944:8k_2_02:56]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001193125-20-283944:8k_2_02:57]
| (amount in thousands) |  | Three Months Ended |  |
|  |  | September 25, 2020 |  |  | September 27, 2019 |  |
| Net cash provided by operating activities |  | $ | 34,506 |  |  | $ | 2,647 |  |
| Less: Purchase of property, plant and equipment |  |  | (12,572 | ) |  |  | (6,343 | ) |
| Non-GAAP free cash flow |  | $ | 21,934 |  |  | $ | (3,696 | ) |

[0001193125-20-283944:8k_2_02:58]
FABRINET

[0001193125-20-283944:8k_2_02:59]
GUIDANCE FOR QUARTER ENDING DECEMBER 25, 2020

[0001193125-20-283944:8k_2_02:60]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-20-283944:8k_2_02:61]
|  |  | DilutedEPS |  |
| GAAP net income per diluted share: |  | $ | 0.84 to $0.91 |  |
| Related to cost of revenues: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.04 |  |
| Total related to gross profit |  |  | 0.04 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.12 |  |
| Total related to selling, general and administrative expenses |  |  | 0.12 |  |
| Total related to net income & EPS |  |  | 0.16 |  |
| Non-GAAP net income per diluted share |  | $ | 1.00 to $1.07 |  |
