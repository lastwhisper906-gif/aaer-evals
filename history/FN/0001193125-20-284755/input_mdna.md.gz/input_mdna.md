# FN MD&A — 0001193125-20-284755


## mdna

[0001193125-20-284755:mdna:1]
[same as prior period, unchanged from 0001193125-20-133708:mdna:1]

[0001193125-20-284755:mdna:2]
|  | • |  | our goals and strategies; |

[0001193125-20-284755:mdna:3]
|  | • |  | our and our customers’ estimates regarding future revenues, operating results, expenses, capital requirements and liquidity; |

[0001193125-20-284755:mdna:4]
|  | • |  | our belief that we will be able to maintain favorable pricing on our services; |

[0001193125-20-284755:mdna:5]
|  | • |  | our expectation that the portion of our revenues attributable to customers in regions outside of North America for the remainder of fiscal year 2021 will be in line with the portion of those revenues for the three months ended September 25, 2020; |

[0001193125-20-284755:mdna:6]
|  | • |  | our expectation that we will incur incremental costs of revenue as a result of our planned expansion of our business into new geographic markets; |

[0001193125-20-284755:mdna:7]
|  | • |  | our expectation that our fiscal year 2021 selling, general and administrative (“SG&A”) expenses will increase as a percentage of revenue compared to fiscal year 2020 SG&A expenses; |

[0001193125-20-284755:mdna:8]
|  | • |  | our expectation that our employee costs will increase in Thailand and the People’s Republic of China (“PRC”); |

[0001193125-20-284755:mdna:9]
|  | • |  | our future capital expenditures and our needs for additional financing; |

[0001193125-20-284755:mdna:10]
|  | • |  | the expansion of our manufacturing capacity, including into new geographies; |

[0001193125-20-284755:mdna:11]
|  | • |  | the growth rates of our existing markets and potential new markets; |

[0001193125-20-284755:mdna:12]
|  | • |  | our ability, and the ability of our customers and suppliers, to respond successfully to technological or industry developments; |

[0001193125-20-284755:mdna:13]
|  | • |  | our expectations regarding the potential impact of the COVID-19 pandemic on our business, financial condition and results of operations; |

[0001193125-20-284755:mdna:14]
|  | • |  | our suppliers’ estimates regarding future costs; |

[0001193125-20-284755:mdna:15]
|  | • |  | our ability to increase our penetration of existing markets and to penetrate new markets; |

[0001193125-20-284755:mdna:16]
|  | • |  | our plans to diversify our sources of revenues; |

[0001193125-20-284755:mdna:17]
|  | • |  | our plans to execute acquisitions; |

[0001193125-20-284755:mdna:18]
|  | • |  | trends in the optical communications, industrial lasers, and sensors markets, including trends to outsource the production of components used in those markets; |

[0001193125-20-284755:mdna:19]
|  | • |  | our ability to attract and retain a qualified management team and other qualified personnel and advisors; and |

[0001193125-20-284755:mdna:20]
|  | • |  | competition in our existing and new markets. |

[0001193125-20-284755:mdna:21]
These forward-looking statements are subject to certain risks and uncertainties that could cause our actual results to differ materially from those reflected in the forward-looking statements. Factors that could cause or contribute to such

[0001193125-20-284755:mdna:22]
[same as prior period, unchanged from 0001193125-20-133708:mdna:21]

[0001193125-20-284755:mdna:23]
[same as prior period, unchanged from 0001193125-20-133708:mdna:22]

[0001193125-20-284755:mdna:24]
[same as prior period, unchanged from 0001193125-20-133708:mdna:23]

[0001193125-20-284755:mdna:25]
[same as prior period, unchanged from 0001193125-20-133708:mdna:24]

[0001193125-20-284755:mdna:26]
[same as prior period, unchanged from 0001193125-20-133708:mdna:25]

[0001193125-20-284755:mdna:27]
[same as prior period, unchanged from 0001193125-20-133708:mdna:26]

[0001193125-20-284755:mdna:28]
The global 
COVID-19
 pandemic has impacted us in several ways and created various challenges. At the onset of the pandemic, our PRC subsidiary, which manufactures custom optics components for us and other customers at its facility in Fuzhou, China, experienced a prolonged temporary closure following its customary 
eight-day
 Chinese Lunar New Year holiday in January 2020. In accordance with the Chinese government’s official efforts to mitigate the spread of 
COVID-19,
 our PRC subsidiary, along with other businesses in various parts of the country, delayed resumption of operations following the holiday closures for approximately two weeks. Furthermore, because of the restrictions in place on travel in China during this period, many of our employees were unable to return from their holiday travel as planned, resulting in fewer than 90% of our employees being able to return to work at our PRC subsidiary before early March. Our other global manufacturing facilities also have been affected by various government restrictions put in place to slow the spread of 
COVID-19.
 In Thailand, the government declared a national state of emergency effective March 26, 2020 and required the closure of various businesses, in particular retail establishments, and passed measures restricting movement and activities in Thailand. While our operations in Thailand have not been suspended, we have implemented a number of safety protocols to allow our operations in our facilities there to continue in accordance with government regulations. With the exception of our facility in Santa Clara, California, which closed for approximately one week beginning in late March before reopening in early April as a previously classified “essential business,” our facilities in the U.S., including in New Jersey, and in the U.K. have remained open while adhering to the local government restrictions and orders implemented in March 2020, including

[0001193125-20-284755:mdna:29]
“shelter-in-place”

[0001193125-20-284755:mdna:30]
orders and social distancing guidelines.

[0001193125-20-284755:mdna:31]
The health and well-being of our employees continues to be our top priority. Over the last few quarters, we have implemented significant precautionary measures throughout our worldwide operations to ensure our employees and their families remain safe, such as mandatory temperature detection at building entrances, rigorous and regular facility and equipment disinfection, and mandatory personal protective equipment protocols, including (1) the wearing of face masks throughout our factories at all times, (2) distributing our employees across shifts to better maintain safe personal distances, (3) isolating incoming parts and materials for a week or more prior to unpacking, or applying extreme heat to them to kill potential viruses, (4) directing our 
non-factory
 personnel to work remotely, and (5) restricting all 
non-employee
 visits to our campuses.

[0001193125-20-284755:mdna:32]
During the three months ended September 25, 2020, we also continued to experience a shift in the demand for our services, with some customers canceling, decreasing or delaying orders and other customers accelerating and increasing orders. However, the most significant effect of the 
COVID-19
 pandemic on our operations has been the disruption of our supply chain, including significant fluctuations in the availability of parts and materials necessary to manufacture products for our customers. While we were able to mitigate some of these issues by quickly identifying and securing alternative sources, these mitigation efforts, combined with our employee safety initiatives, negatively impacted our gross margins due to the associated costs and expenses.

[0001193125-20-284755:mdna:33]
Given the unprecedented global, human, and economic impact of the 
COVID-19
 pandemic, the extraordinary economic short-term uncertainty; and the evolving and differing national strategies for dealing with 
COVID-19,
 it is extremely challenging to provide a forward-looking disclosure. Despite the uncertainty and concern about the global economy and the health of various industries, we believe it is important to share our considerations as we continue to assess the impacts of 
COVID-19
 as they relate to our business in the future:

[0001193125-20-284755:mdna:34]
|  | • |  | With work-from-home protocols in place around the world, global demand for internet bandwidth has grown and we believe it will continue to grow. Because the next-generation telecom and datacom products we manufacture for our customers are important to expand network capacity, we believe this will have a positive impact on our business in the long-term. |

[0001193125-20-284755:mdna:35]
|  | • |  | While we believe that the long-term growth outlook for the markets we serve has not been significantly impacted, in the short-term we are likely to continue to see regional downward demand adjustments, especially if the COVID-19 outbreak intensifies or returns in various geographic areas as happened at the end of our third quarter in fiscal 2020. Moreover, we believe the markets for other products we manufacture, such as the industrial lasers and automotive markets, are likely to see reduced demand in a prolonged economic downturn. |

[0001193125-20-284755:mdna:36]
|  | • |  | We expect we will continue to experience disruptions in our supply chain and the availability of parts and materials will continue to fluctuate, especially if the COVID-19 outbreak intensifies or returns in various geographic areas. However, we believe we can mitigate these disruptions by continuing to identify and secure alternative sources. |

[0001193125-20-284755:mdna:37]
|  | • |  | A significant portion of our costs are variable and, because of this, we can adjust manufacturing costs relatively quickly to respond to the changing demand of our customers. However, because parts and materials account for the largest portion of our costs, in combination with the supply chain issues noted above and, to a lesser extent, the expenses associated with the safety and health protocols we have implemented across our global operations, our gross margins will continue to be negatively affected for the foreseeable future, and at least into the first half of fiscal 2021. |

[0001193125-20-284755:mdna:38]
|  | • |  | The safety and health of our employees is and will remain a key priority, and we will continue to follow robust safety protocols in all of our facilities. |

[0001193125-20-284755:mdna:39]
|  | • |  | Given our $496.4 million in cash, cash equivalents and short-term investments, and our total debt of approximately $48.6 million, as of September 25, 2020, we believe we are in a solid position from a capital and financial resources perspective. We expect that current cash and cash equivalent balances and short-term investments, and cash flows that are generated from operations will be sufficient to meet our domestic and international working capital needs and other capital and liquidity requirements for at least the next 12 months. |

[0001193125-20-284755:mdna:40]
[same as prior period, unchanged from 0001193125-20-133708:mdna:37]

[0001193125-20-284755:mdna:41]
[same as prior period, unchanged from 0001193125-20-133708:mdna:38]

[0001193125-20-284755:mdna:42]
32

[0001193125-20-284755:mdna:43]
[same as prior period, unchanged from 0001193125-20-133708:mdna:40]

[0001193125-20-284755:mdna:44]
[same as prior period, unchanged from 0001193125-20-133708:mdna:41]

[0001193125-20-284755:mdna:45]
The percentage of our revenues generated from a 
bill-to
 location outside of North America increased from 49.7% in the three months ended September 27, 2019 to 52.5% in the three months ended September 25, 2020, primarily because the increase in sales to our customers in North America was lower than the increase in sales to our customers outside of North America. Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside North America for the remainder of fiscal year 2021 will be in line with the portion of revenues attributable to such customers during the three months ended September 25, 2020.

[0001193125-20-284755:mdna:46]
[same as prior period, unchanged from 0001193125-20-133708:mdna:43]

[0001193125-20-284755:mdna:47]
|  |  | Three Months Ended |  |
|  |  | September 25,2020 |  |  | September 27,2019 |  |
| North America |  |  | 47.5 | % |  |  | 50.3 | % |
| Asia-Pacific |  |  | 33.4 |  |  |  | 29.7 |  |
| Europe |  |  | 19.1 |  |  |  | 20.0 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-20-284755:mdna:48]
[same as prior period, unchanged from 0001193125-20-133708:mdna:45]

[0001193125-20-284755:mdna:49]
We enter into supply agreements with our customers which generally have an initial term of up to three years, subject to automatic renewals for subsequent 
one-year
 terms unless expressly terminated. Although there are no minimum purchase requirements in our supply agreements, our customers provide us with rolling forecasts of their demand requirements. Our supply agreements generally include provisions for pricing and periodic review of pricing, consignment of our customer’s unique production equipment to us, and the sharing of benefits from cost-savings derived from our efforts. We are generally required to purchase materials, which may include long lead-time materials and materials that are subject to minimum order quantities and/or 
non-cancelable
 or 
non-returnable
 terms, to meet the stated demands of our customers. After procuring materials, we manufacture products for our customers based on purchase orders that contain terms regarding product quantities, delivery locations and delivery dates. Our customers generally are obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by our customers within a specified period of time, or are no longer required due to a product’s cancellation or

[0001193125-20-284755:mdna:50]
end-of-life,

[0001193125-20-284755:mdna:51]
are typically designated as excess or obsolete inventory under our contracts. Once materials are designated as either excess or obsolete inventory, our customers are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

[0001193125-20-284755:mdna:52]
[same as prior period, unchanged from 0001193125-20-133708:mdna:47]

[0001193125-20-284755:mdna:53]
[same as prior period, unchanged from 0001193125-20-133708:mdna:48]

[0001193125-20-284755:mdna:54]
A second significant element of our cost of revenues is employee costs, including indirect employee costs related to design, configuration and optimization of manufacturing processes for our customers, quality testing, materials testing and other engineering services; and direct costs related to our manufacturing employees. Direct employee costs include employee salaries, insurance and benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a lesser extent, costs to recruit, train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand, the PRC and the United Kingdom, the fluctuation of the Thai baht, Chinese Renminbi (“RMB”) and Pound Sterling (“GBP”) against our functional currency, the U.S. dollar, and our ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention and asset utilization.

[0001193125-20-284755:mdna:55]
[same as prior period, unchanged from 0001193125-20-133708:mdna:51]

[0001193125-20-284755:mdna:56]
[same as prior period, unchanged from 0001193125-20-133708:mdna:52]

[0001193125-20-284755:mdna:57]
[same as prior period, unchanged from 0001193125-20-133708:mdna:53]

[0001193125-20-284755:mdna:58]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative and other support personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other general expenses not related to cost of revenues. In fiscal year 2021, we expect our SG&A expenses will increase as a percentage of revenue compared with our fiscal year 2020 SG&A expenses.

[0001193125-20-284755:mdna:59]
The compensation committee of our board of directors approved a fiscal year 2021 executive incentive plan with quantitative objectives that are based solely on achieving certain revenue targets and 
non-GAAP
 operating margin targets for our fiscal year ending June 25, 2021. Bonuses under the fiscal year 2021 executive incentive plan are payable after the end of fiscal year 2021. In fiscal year 2020, the compensation committee of our board of directors approved a fiscal year 2020 executive incentive plan with quantitative objectives based solely on achieving certain revenue targets and 
non-GAAP
 operating margin targets for fiscal year 2020.

[0001193125-20-284755:mdna:60]
[same as prior period, unchanged from 0001193125-20-133708:mdna:56]

[0001193125-20-284755:mdna:61]
[same as prior period, unchanged from 0001193125-20-133708:mdna:57]

[0001193125-20-284755:mdna:62]
[same as prior period, unchanged from 0001193125-20-133708:mdna:58]

[0001193125-20-284755:mdna:63]
In order to manage the risks arising from fluctuations in foreign currency exchange rates, we use derivative instruments. We may enter into exchange currency forward or put option contracts to manage foreign currency exposures associated with certain assets and liabilities and other forecasted foreign currency transactions and may designate these instruments as hedging instruments. The forward and put option contracts generally have maturities of up to 12 months. All foreign currency exchange contracts are recognized in the unaudited condensed consolidated balance sheets at fair value. Gains or losses on our forward and put option contracts generally offset the assets, liabilities, and transactions economically hedged.

[0001193125-20-284755:mdna:64]
[same as prior period, unchanged from 0001193125-20-133708:mdna:60]

[0001193125-20-284755:mdna:65]
|  |  | As of September 25, 2020 |  |  | As of June 26, 2020 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 484,800 |  |  | $ | 15,376 |  |  |  | 40.5 |  |  |  | 667,955 |  |  | $ | 21,617 |  |  |  | 41.8 |  |
| RMB |  |  | 99,204 |  |  |  | 14,563 |  |  |  | 38.4 |  |  |  | 158,060 |  |  |  | 22,402 |  |  |  | 43.3 |  |
| GBP |  |  | 6,278 |  |  |  | 8,011 |  |  |  | 21.1 |  |  |  | 6,220 |  |  |  | 7,726 |  |  |  | 14.9 |  |
| Total |  |  |  |  |  | $ | 37,950 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 51,745 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,921,377 |  |  | $ | 60,938 |  |  |  | 89.3 |  |  |  | 2,102,392 |  |  | $ | 68,039 |  |  |  | 89.5 |  |
| RMB |  |  | 34,332 |  |  |  | 5,040 |  |  |  | 7.4 |  |  |  | 42,586 |  |  |  | 6,036 |  |  |  | 8.0 |  |
| GBP |  |  | 1,800 |  |  |  | 2,297 |  |  |  | 3.3 |  |  |  | 1,545 |  |  |  | 1,919 |  |  |  | 2.5 |  |
| Total |  |  |  |  |  | $ | 68,275 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 75,994 |  |  |  | 100.0 |  |

[0001193125-20-284755:mdna:66]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of September 25, 2020, there was $130.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 26, 2020, there was $126.0 million of foreign currency forward contracts outstanding on the Thai baht payables.

[0001193125-20-284755:mdna:67]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of September 25, 2020 and June 26, 2020, we did not have any derivative contracts denominated in RMB.

[0001193125-20-284755:mdna:68]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable and other payables. As of September 25, 2020 and June 26, 2020, we did not have any derivative contracts denominated in GBP.

[0001193125-20-284755:mdna:69]
For the three months ended September 25, 2020 and September 27, 2019, we recorded losses of $1.5 million and $1.9 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-20-284755:mdna:70]
[same as prior period, unchanged from 0001193125-20-133708:mdna:65]

[0001193125-20-284755:mdna:71]
[same as prior period, unchanged from 0001193125-20-133708:mdna:66]

[0001193125-20-284755:mdna:72]
|  | • |  | Foreign Currency Administration Rules, as amended on August 5, 2008, or the Exchange Rules; |

[0001193125-20-284755:mdna:73]
|  | • |  | Administration Rules of the Settlement, Sale and Payment of Foreign Exchange (1996), or the Administration Rules; and |

[0001193125-20-284755:mdna:74]
|  | • |  | Notice on Perfecting Practices Concerning Foreign Exchange Settlement Regarding the Capital Contribution by Foreign-invested Enterprises, as promulgated by the State Administration of Foreign Exchange (“SAFE”), on August 29, 2008, or Circular 142. |

[0001193125-20-284755:mdna:75]
[same as prior period, unchanged from 0001193125-20-133708:mdna:70]

[0001193125-20-284755:mdna:76]
[same as prior period, unchanged from 0001193125-20-133708:mdna:71]

[0001193125-20-284755:mdna:77]
Circular 142 regulates the conversion by a foreign-invested company of foreign currency into RMB by restricting how the converted RMB may be used. Circular 142 requires that the registered capital of a foreign-invested enterprise settled in RMB converted from foreign currencies may only be used for purposes within the business scope approved by the applicable governmental authority and may not be used for equity investments within the PRC. In addition, SAFE strengthened its oversight of the flow and use of the registered capital of foreign-invested enterprises settled in RMB converted from foreign currencies. The use of such RMB capital may not be changed without SAFE’s approval and may not be used to repay RMB loans if the proceeds of such loans have not been used.

[0001193125-20-284755:mdna:78]
[same as prior period, unchanged from 0001193125-20-133708:mdna:74]

[0001193125-20-284755:mdna:79]
[same as prior period, unchanged from 0001193125-20-133708:mdna:75]

[0001193125-20-284755:mdna:80]
[same as prior period, unchanged from 0001193125-20-133708:mdna:76]

[0001193125-20-284755:mdna:81]
[same as prior period, unchanged from 0001193125-20-133708:mdna:77]

[0001193125-20-284755:mdna:82]
[same as prior period, unchanged from 0001193125-20-133708:mdna:78]

[0001193125-20-284755:mdna:83]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption on income generated from projects to manufacture certain products at our Chonburi campus is currently available to us through June 2026. Similar preferential tax treatment was available to us through June 2020 with respect to products manufactured at our Pinehurst campus. After June 2020, 50% of our income generated from products manufactured at our Pinehurst campus will be exempted from tax through June 2025. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted. Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001193125-20-284755:mdna:84]
[same as prior period, unchanged from 0001193125-20-133708:mdna:80]

[0001193125-20-284755:mdna:85]
[same as prior period, unchanged from 0001193125-20-133708:mdna:81]

[0001193125-20-284755:mdna:86]
[same as prior period, unchanged from 0001193125-20-133708:mdna:82]

[0001193125-20-284755:mdna:87]
Our critical accounting policies are disclosed in our Annual Report on Form 
10-K
 for the fiscal year ended June 26, 2020. The adoption of new accounting policies and accounting standards are disclosed in Note 2 to the unaudited condensed consolidated financial statements. There were no changes to our accounting policies other than the adoption of ASC 326, “Financial Instruments—Credit Losses: Measurement of Credit Losses on Financial Instruments”.

[0001193125-20-284755:mdna:88]
[same as prior period, unchanged from 0001193125-20-133708:mdna:84]

[0001193125-20-284755:mdna:89]
The following table sets forth a summary of our unaudited condensed consolidated statements of operations and comprehensive income. Note that

[0001193125-20-284755:mdna:90]
period-to-period

[0001193125-20-284755:mdna:91]
comparisons of operating results should not be relied upon as indicative of future performance.

[0001193125-20-284755:mdna:92]
| (amount in thousands) |  | Three Months Ended |  |
|  | September 25,2020 |  |  | September 27,2019 |  |
| Revenues |  | $ | 436,639 |  |  | $ | 399,296 |  |
| Cost of revenues |  |  | (386,159 | ) |  |  | (353,309 | ) |
| Gross profit |  |  | 50,480 |  |  |  | 45,987 |  |
| Selling, general and administrative expenses |  |  | (16,863 | ) |  |  | (16,000 | ) |
| Operating income |  |  | 33,617 |  |  |  | 29,987 |  |
| Interest income |  |  | 1,104 |  |  |  | 2,098 |  |
| Interest expense |  |  | (251 | ) |  |  | (2,393 | ) |
| Foreign exchange gain (loss), net |  |  | 128 |  |  |  | (1,953 | ) |
| Other income (expense), net |  |  | 121 |  |  |  | 377 |  |
| Income before income taxes |  |  | 34,719 |  |  |  | 28,116 |  |
| Income tax expense |  |  | (1,668 | ) |  |  | (2,159 | ) |
| Net income |  |  | 33,051 |  |  |  | 25,957 |  |
| Other comprehensive income (loss), net of tax |  |  | (2,757 | ) |  |  | (212 | ) |
| Net comprehensive income |  | $ | 30,294 |  |  | $ | 25,745 |  |

[0001193125-20-284755:mdna:93]
The following table sets forth a summary of our unaudited condensed consolidated statements of operations and comprehensive income as a percentage of revenues for the periods indicated.

[0001193125-20-284755:mdna:94]
|  |  | Three Months Ended |  |
|  |  | September 25,2020 |  |  | September 27,2019 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (88.4 | ) |  |  | (88.5 | ) |
| Gross profit |  |  | 11.6 |  |  |  | 11.5 |  |
| Selling, general and administrative expenses |  |  | (3.9 | ) |  |  | (4.0 | ) |
| Operating income |  |  | 7.7 |  |  |  | 7.5 |  |
| Interest income |  |  | 0.3 |  |  |  | 0.5 |  |
| Interest expense |  |  | (0.1 | ) |  |  | (0.6 | ) |
| Foreign exchange gain (loss), net |  |  | 0.0 |  |  |  | (0.5 | ) |
| Other income (expense), net |  |  | 0.0 |  |  |  | 0.1 |  |
| Income before income taxes |  |  | 7.9 |  |  |  | 7.0 |  |
| Income tax expense |  |  | (0.4 | ) |  |  | (0.5 | ) |
| Net income |  |  | 7.5 |  |  |  | 6.5 |  |
| Other comprehensive income (loss), net of tax |  |  | (0.6 | ) |  |  | (0.1 | ) |
| Net comprehensive income |  |  | 6.9 | % |  |  | 6.4 | % |

[0001193125-20-284755:mdna:95]
[same as prior period, unchanged from 0001193125-20-133708:mdna:89]

[0001193125-20-284755:mdna:96]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 25,2020 |  |  | September 27,2019 |  |
| Optical communications |  | $ | 343,917 |  |  | $ | 302,379 |  |
| Lasers, sensors and other |  |  | 92,722 |  |  |  | 96,917 |  |
| Total |  | $ | 436,639 |  |  | $ | 399,296 |  |

[0001193125-20-284755:mdna:97]
[same as prior period, unchanged from 0001193125-20-133708:mdna:91]

[0001193125-20-284755:mdna:98]
Comparison of Three Months Ended September 25, 2020 with Three Months Ended September 27, 2019

[0001193125-20-284755:mdna:99]
Revenues.

[0001193125-20-284755:mdna:100]
Our revenues increased by $37.3 million, or 9.4%, to $436.6 million for the three months ended September 25, 2020, compared with $399.3 million for the three months ended September 27, 2019. This increase was due to an increase in our key customers’ demand for optical communications manufacturing services during the three months ended September 25, 2020. Revenues from optical communications products increased by $41.5 million, or 13.7%, for the three months ended September 25, 2020.

[0001193125-20-284755:mdna:101]
Cost of revenues.

[0001193125-20-284755:mdna:102]
Our cost of revenues increased by $32.9 million, or 9.3%, to $386.2 million, or 88.4% of revenues, for the three months ended September 25, 2020, compared with $353.3 million, or 88.5% of revenues, for the three months ended September 27, 2019. The increase in cost of revenues on an absolute dollar basis was in line with the increase in revenue.

[0001193125-20-284755:mdna:103]
Gross profit.

[0001193125-20-284755:mdna:104]
Our gross profit increased by $4.5 million, or 9.8%, to $50.5 million, or 11.6% of revenues, for the three months ended September 25, 2020, compared with $46.0 million, or 11.5% of revenues, for the three months ended September 27, 2019. The increase was primarily due to a more favorable product mix.

[0001193125-20-284755:mdna:105]
SG&A expenses.

[0001193125-20-284755:mdna:106]
Our SG&A expenses increased by $0.9 million, or 5.4%, to $16.9 million, or 3.9% of revenues, for the three months ended September 25, 2020, compared with $16.0 million, or 4.0% of revenues, for the three months ended September 27, 2019. The increase was primarily due to an increase in 
start-up
 costs for our subsidiary in Israel of $0.8 million.

[0001193125-20-284755:mdna:107]
[same as prior period, unchanged from 0001193125-20-133708:mdna:110]

[0001193125-20-284755:mdna:108]
Our operating income increased by $3.6 million to $33.6 million, or 7.7% of revenues, for the three months ended September 25, 2020, compared with $30.0 million, or 7.5% of revenues, for the three months ended September 27, 2019. The increase was primarily due to an increase in revenues.

[0001193125-20-284755:mdna:109]
Interest income.

[0001193125-20-284755:mdna:110]
Our interest income decreased by $1.0 million, or 47.4%, to $1.1 million, or 0.3% of revenues, for the three months ended September 27, 2019, compared with $2.1 million, or 0.5% of revenues, for the three months ended September 27, 2019. The decrease was primarily due to a lower weighted average interest rate during the three months ended September 25, 2020 compared to same period in fiscal year 2020.

[0001193125-20-284755:mdna:111]
Interest expense.

[0001193125-20-284755:mdna:112]
Our interest expense decreased by $2.1 million to $0.3 million for the three months ended September 25, 2020, compared with $2.4 million for the three months ended September 27, 2019. The decrease was primarily due to lower unrealized loss from

[0001193125-20-284755:mdna:113]
mark-to-market

[0001193125-20-284755:mdna:114]
of interest rate swaps recognized to earnings as a result of applying cash flow hedge accounting during the three months ended September 25, 2020.

[0001193125-20-284755:mdna:115]
Foreign exchange gain (loss), net.

[0001193125-20-284755:mdna:116]
We recorded foreign exchange gain, net of $0.1 million for the three months ended September 25, 2020, compared with foreign exchange loss, net of $2.0 million for the three months ended September 27, 2019. The increase in foreign exchange gain was mainly due to an unrealized foreign exchange gain from revaluation of outstanding Thai baht assets and liabilities of $2.0 million for the three months ended September 25, 2020, as compared to an unrealized foreign exchange loss from revaluation of outstanding Thai baht assets and liabilities of $0.2 million for the three months ended September 27, 2019. Moreover, there was a reduction of foreign exchange gain (loss) volatility from the application of cash flow hedge which was implemented on December 28, 2019. Unrealized foreign exchange loss from

[0001193125-20-284755:mdna:117]
marking-to-market

[0001193125-20-284755:mdna:118]
of foreign exchange forward contracts after cash flow hedge application was $1.5 million for the three months ended September 25, 2020, as compared to unrealized foreign exchange loss from

[0001193125-20-284755:mdna:119]
marking-to-market

[0001193125-20-284755:mdna:120]
of foreign exchange forward contracts of $1.9 million for the three months ended September 27, 2019.

[0001193125-20-284755:mdna:121]
Income before income taxes.

[0001193125-20-284755:mdna:122]
We recorded income before income taxes of $34.7 million for the three months ended September 25, 2020, compared with $28.1 million for the three months ended September 27, 2019.

[0001193125-20-284755:mdna:123]
[same as prior period, unchanged from 0001193125-20-133708:mdna:127]

[0001193125-20-284755:mdna:124]
Our provision for income tax reflects an effective tax rate of 4.5% and 5.6% for the three months ended September 25, 2020 and September 27, 2019, respectively. The decrease was primarily due to the fact that we had lower income subject to tax during the first quarter of fiscal year 2021 as compared to the same period in fiscal year 2020.

[0001193125-20-284755:mdna:125]
Net income.

[0001193125-20-284755:mdna:126]
We recorded net income of $33.1 million, or 7.6% of revenues, for the three months ended September 25, 2020, compared with $26.0 million, or 6.5% of revenues, for the three months ended September 27, 2019.

[0001193125-20-284755:mdna:127]
Other comprehensive income (loss).

[0001193125-20-284755:mdna:128]
We recorded other comprehensive loss of $2.8 million, or 0.6% of revenues, for the three months ended September 25, 2020, compared with other comprehensive loss of $0.2 million, or 0.1% of revenues, for the three months ended September 27, 2019. The increase in other comprehensive loss was mainly due to the implementation of cash flow hedge for foreign exchange forward contracts on December 28, 2019; therefore, unrealized foreign exchange loss of $3.2 million was recognized into other comprehensive income (loss), as compared to the three months ended September 27, 2019, other comprehensive loss comprised of unrealized foreign exchange loss of $0.4 million from foreign currency translation adjustment.

[0001193125-20-284755:mdna:129]
[same as prior period, unchanged from 0001193125-20-133708:mdna:137]

[0001193125-20-284755:mdna:130]
[same as prior period, unchanged from 0001193125-20-133708:mdna:138]

[0001193125-20-284755:mdna:131]
We primarily finance our operations through cash flow from operations. As of September 25, 2020 and September 27, 2019, we had cash, cash equivalents, and short-term investments of $496.4 million and $406.8 million, respectively, and outstanding debt of $48.6 million and $60.9 million, respectively.

[0001193125-20-284755:mdna:132]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents for the three months ended September 25, 2020 and September 27, 2019 was 0.9% and 2.0%, respectively.

[0001193125-20-284755:mdna:133]
Our cash investments are made in accordance with an investment policy approved by the audit committee of our board of directors. In general, our investment policy requires that securities purchased be rated A1, 
P-1,
 F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed income securities are primarily classified as

[0001193125-20-284755:mdna:134]
available-for-sale

[0001193125-20-284755:mdna:135]
and are recorded at fair value. The cost of securities sold is based on the specific identification method. Unrealized gains and losses on these securities are recorded as other comprehensive income (loss) and are reported as a separate component of shareholders’ equity.

[0001193125-20-284755:mdna:136]
During the three months ended September 25, 2020, we repaid $3.0 million of the term loan under the Credit Facility Agreement with the Bank of Ayudhya Public Company Limited. As a result, as of September 25, 2020, we had a long-term borrowing of $48.6 million under our credit facility agreement. (See Note 12 for further details.) We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held short-term investments of $307.2 million as of September 25, 2020.

[0001193125-20-284755:mdna:137]
We believe that our current cash and cash equivalents, marketable securities, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 
10-Q.

[0001193125-20-284755:mdna:138]
[same as prior period, unchanged from 0001193125-20-133708:mdna:144]

[0001193125-20-284755:mdna:139]
[same as prior period, unchanged from 0001193125-20-133708:mdna:145]

[0001193125-20-284755:mdna:140]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 25,2020 |  |  | September 27,2019 |  |
| Net cash provided by operating activities |  | $ | 34,506 |  |  | $ | 2,647 |  |
| Net cash (used in) provided by investing activities |  | $ | (58,434 | ) |  | $ | 11,676 |  |
| Net cash used in financing activities |  | $ | (13,067 | ) |  | $ | (4,406 | ) |
| Net (decrease) increase in cash, cash equivalents and restricted cash |  | $ | (36,995 | ) |  | $ | 9,917 |  |

[0001193125-20-284755:mdna:141]
[same as prior period, unchanged from 0001193125-20-133708:mdna:147]

[0001193125-20-284755:mdna:142]
Net cash provided by operating activities increased by $31.9 million, or 1,203.6%, to $34.5 million for the three months ended September 25, 2020, compared with net cash provided by operating activities of $2.6 million for the three months ended September 27, 2019. This increase was primarily due to (1) a decrease of $38.8 million in payments to trade accounts payable and (2) an increase in net income of $7.1 million offset by (1) a decrease in change of other current liabilities and 
non-current
 liabilities of $8.8 million, (2) a decrease in cash receipts related to the timing of collection of trade accounts receivable of $3.5 million, (3) an increase in unrealized gain on exchange rate and fair value of foreign currency forwards contracts and interest rate swaps of $4.0 million, (4) a decrease in change in inventories of $1.7 million and (5) an increase in change in other current assets and 
non-current
 assets of $3.6 million.

[0001193125-20-284755:mdna:143]
[same as prior period, unchanged from 0001193125-20-133708:mdna:149]

[0001193125-20-284755:mdna:144]
Net cash used in investing activities increased by $70.1 million, or 600.5%, to $58.4 million for the three months ended September 25, 2020, compared with net cash provided by investing activities of $11.7 million for the three months ended September 27, 2019. This increase was primarily due to (1) an increase in purchases of short-term investments, net of proceeds from sales and maturities of $63.6 million and (2) an increase in the purchase of property, plant and equipment and intangibles of $6.5 million.

[0001193125-20-284755:mdna:145]
[same as prior period, unchanged from 0001193125-20-133708:mdna:151]

[0001193125-20-284755:mdna:146]
Net cash used in financing activities increased by $8.7 million, or 196.6%, to $13.1 million for the three months ended September 25, 2020, compared with net cash used in financing activities of $4.4 million for the three months ended September 27, 2019. This increase was primarily due to (1) an increase in withholding tax related to net share settlement of restricted share units of $5.8 million and (2) an increase of $3.0 million in repayment of loans to a bank.

[0001193125-20-284755:mdna:147]
[same as prior period, unchanged from 0001193125-20-133708:mdna:153]

[0001193125-20-284755:mdna:148]
As of September 25, 2020, we had one outstanding standby letter of credit of 6.0 million Euros related to our support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to our facilities in Thailand. As of September 25, 2020, the standby letter of credit was backed by cash collateral of $7.4 million.

[0001193125-20-284755:mdna:149]
[same as prior period, unchanged from 0001193125-20-133708:mdna:155]

[0001193125-20-284755:mdna:150]
See Note 2 of Notes to Unaudited Condensed Consolidated Financial Statements for recent accounting pronouncements that could have an effect on us.
