# FN MD&A — 0001408710-22-000018


## mdna

[0001408710-22-000018:mdna:1]
[same as prior period, unchanged from 0001408710-21-000047:mdna:1]

[0001408710-22-000018:mdna:2]
[same as prior period, unchanged from 0001408710-21-000047:mdna:2]

[0001408710-22-000018:mdna:3]
[same as prior period, unchanged from 0001408710-21-000047:mdna:3]

[0001408710-22-000018:mdna:4]
[same as prior period, unchanged from 0001408710-21-000047:mdna:4]

[0001408710-22-000018:mdna:5]
•our expectation that the portion of our revenues attributable to customers in regions outside of North America for the remainder of fiscal year 2022 will be in line with the portion of those revenues for the six months ended December 24, 2021;

[0001408710-22-000018:mdna:6]
[same as prior period, unchanged from 0001408710-21-000047:mdna:6]

[0001408710-22-000018:mdna:7]
[same as prior period, unchanged from 0001408710-21-000047:mdna:7]

[0001408710-22-000018:mdna:8]
[same as prior period, unchanged from 0001408710-21-000047:mdna:8]

[0001408710-22-000018:mdna:9]
[same as prior period, unchanged from 0001408710-21-000047:mdna:9]

[0001408710-22-000018:mdna:10]
[same as prior period, unchanged from 0001408710-21-000047:mdna:10]

[0001408710-22-000018:mdna:11]
[same as prior period, unchanged from 0001408710-21-000047:mdna:11]

[0001408710-22-000018:mdna:12]
[same as prior period, unchanged from 0001408710-21-000047:mdna:12]

[0001408710-22-000018:mdna:13]
[same as prior period, unchanged from 0001408710-21-000047:mdna:13]

[0001408710-22-000018:mdna:14]
[same as prior period, unchanged from 0001408710-21-000047:mdna:14]

[0001408710-22-000018:mdna:15]
[same as prior period, unchanged from 0001408710-21-000047:mdna:15]

[0001408710-22-000018:mdna:16]
[same as prior period, unchanged from 0001408710-21-000047:mdna:16]

[0001408710-22-000018:mdna:17]
[same as prior period, unchanged from 0001408710-21-000047:mdna:17]

[0001408710-22-000018:mdna:18]
[same as prior period, unchanged from 0001408710-21-000047:mdna:18]

[0001408710-22-000018:mdna:19]
[same as prior period, unchanged from 0001408710-21-000047:mdna:19]

[0001408710-22-000018:mdna:20]
[same as prior period, unchanged from 0001408710-21-000047:mdna:20]

[0001408710-22-000018:mdna:21]
[same as prior period, unchanged from 0001408710-21-000047:mdna:21]

[0001408710-22-000018:mdna:22]
We provide advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers (“OEMs”) of complex products such as optical communication components, modules and sub-systems, industrial lasers, automotive components, medical devices and sensors. We offer a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, complex printed circuit board assembly, advanced packaging, integration, final assembly and testing. Although we focus primarily on low-volume production of a wide variety of high complexity products, which we refer to as “low-volume, high-mix,” we also have the capability to accommodate high-volume production. Based on our extensive experience, and the positive feedback we have received from our customers, we believe we are a global leader in providing these services to the optical communications, industrial lasers and automotive markets.

[0001408710-22-000018:mdna:23]
Our customer base includes companies in complex industries that require advanced precision manufacturing capabilities such as optical communications, industrial lasers, automotive and sensors. The products that we manufacture for our OEM customers include selective switching products; tunable transponders and transceivers; active optical cables; solid state, diode-pumped, gas and fiber lasers; and sensors. In many cases, we are the sole outsourced manufacturing partner used by our customers for the products that we manufacture for them.

[0001408710-22-000018:mdna:24]
[same as prior period, unchanged from 0001408710-21-000047:mdna:24]

[0001408710-22-000018:mdna:25]
[same as prior period, unchanged from 0001408710-21-000047:mdna:25]

[0001408710-22-000018:mdna:26]
[same as prior period, unchanged from 0001408710-21-000047:mdna:26]

[0001408710-22-000018:mdna:27]
During the three months ended December 24, 2021, several countries where we have manufacturing facilities, including Thailand, the PRC, the U.S. and the U.K., experienced a surge in the number of COVID-19 cases. We have responded by taking additional precautionary measures based on recommendations from local authorities. These precautionary measures include implementing leaves of absence for affected employees and their close contacts, stringent contact tracing, enhanced safe distancing measures, and arrangements for the vaccination of our employees in Thailand. Although we did not experience any significant disruptions in our operations or decrease in customer demand during the three months ended December 24, 2021, any worsening of the pandemic may result in more stringent recommendations or requirements being implemented by local authorities, such as shutting down our manufacturing facilities, which would have a significant negative impact on our operations.

[0001408710-22-000018:mdna:28]
[same as prior period, unchanged from 0001408710-21-000047:mdna:28]

[0001408710-22-000018:mdna:29]
[same as prior period, unchanged from 0001408710-21-000047:mdna:29]

[0001408710-22-000018:mdna:30]
[same as prior period, unchanged from 0001408710-21-000047:mdna:30]

[0001408710-22-000018:mdna:31]
[same as prior period, unchanged from 0001408710-21-000047:mdna:31]

[0001408710-22-000018:mdna:32]
•While we believe the long-term growth outlook for the markets we serve has not been significantly impacted, in the short-term we are likely to continue to see regional downward demand adjustments, especially if the COVID-19 pandemic intensifies or returns in various geographic areas as was the case at the end of our third quarter in fiscal year 2020.

[0001408710-22-000018:mdna:33]
•In the near term, we expect to continue experiencing disruptions in our supply chain and fluctuations in the availability of parts and materials, especially if the COVID-19 pandemic intensifies or returns in various geographic areas. These disruptions and shortages have impacted, and will continue to impact, our ability to generate revenue. However, we believe we can partially mitigate these disruptions and shortages by continuing to identify and secure alternative supply chain sources.

[0001408710-22-000018:mdna:34]
[same as prior period, unchanged from 0001408710-21-000047:mdna:34]

[0001408710-22-000018:mdna:35]
•The safety and health of our employees is and will remain a key priority, and we will continue to follow robust safety protocols in all of our facilities. To this end, we arranged for the vaccination of our employees in Thailand in the first quarter of fiscal year 2022.

[0001408710-22-000018:mdna:36]
•Given our $519.9 million in cash, cash equivalents and short-term investments, and our total debt of approximately $33.5 million as of December 24, 2021, we believe we are in a solid position from a capital and financial resources perspective. We expect that our current cash and cash equivalent balances and short-term investments, and cash flows generated from operations will be sufficient to meet our domestic and international working capital needs and other capital and liquidity requirements for at least the next 12 months.

[0001408710-22-000018:mdna:37]
[same as prior period, unchanged from 0001408710-21-000047:mdna:37]

[0001408710-22-000018:mdna:38]
[same as prior period, unchanged from 0001408710-21-000047:mdna:38]

[0001408710-22-000018:mdna:39]
[same as prior period, unchanged from 0001408710-21-000047:mdna:39]

[0001408710-22-000018:mdna:40]
[same as prior period, unchanged from 0001408710-21-000047:mdna:40]

[0001408710-22-000018:mdna:41]
The percentage of our revenues generated from a bill-to location outside of North America increased from 50.5% in the three months ended December 25, 2020 to 56.4% in the three months ended December 24, 2021, primarily because the increase in sales to our customers outside of North America was greater than the increase in sales to our customers in North America.

[0001408710-22-000018:mdna:42]
The percentage of our revenues generated from a bill-to location outside of North America increased from 51.5% in the six months ended December 25, 2020 to 55.5% in the six months ended December 24, 2021, primarily because the increase in sales to our customers outside of North America was greater than the increase in sales to our customers in North America.

[0001408710-22-000018:mdna:43]
Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside North America for the remainder of fiscal year 2022 will be in line with the portion of revenues attributable to such customers during the six months ended December 24, 2021.

[0001408710-22-000018:mdna:44]
[same as prior period, unchanged from 0001408710-21-000047:mdna:43]

[0001408710-22-000018:mdna:45]
|  | Three Months Ended |  | Six Months Ended |
|  | December 24, 2021 |  | December 25, 2020 |  | December 24, 2021 |  | December 25, 2020 |
| North America | 43.6 | % |  | 49.5 | % |  | 44.5 | % |  | 48.5 | % |
| Asia-Pacific and others | 39.2 |  |  | 33.9 |  |  | 38.6 |  |  | 33.6 |  |
| Europe | 17.2 |  |  | 16.6 |  |  | 16.9 |  |  | 17.9 |  |
|  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001408710-22-000018:mdna:46]
[same as prior period, unchanged from 0001408710-21-000047:mdna:45]

[0001408710-22-000018:mdna:47]
[same as prior period, unchanged from 0001408710-21-000047:mdna:46]

[0001408710-22-000018:mdna:48]
[same as prior period, unchanged from 0001408710-21-000047:mdna:47]

[0001408710-22-000018:mdna:49]
[same as prior period, unchanged from 0001408710-21-000047:mdna:48]

[0001408710-22-000018:mdna:50]
[same as prior period, unchanged from 0001408710-21-000047:mdna:49]

[0001408710-22-000018:mdna:51]
[same as prior period, unchanged from 0001408710-21-000047:mdna:50]

[0001408710-22-000018:mdna:52]
[same as prior period, unchanged from 0001408710-21-000047:mdna:51]

[0001408710-22-000018:mdna:53]
[same as prior period, unchanged from 0001408710-21-000047:mdna:52]

[0001408710-22-000018:mdna:54]
[same as prior period, unchanged from 0001408710-21-000047:mdna:53]

[0001408710-22-000018:mdna:55]
[same as prior period, unchanged from 0001408710-21-000047:mdna:54]

[0001408710-22-000018:mdna:56]
[same as prior period, unchanged from 0001408710-21-000047:mdna:55]

[0001408710-22-000018:mdna:57]
[same as prior period, unchanged from 0001408710-21-000047:mdna:56]

[0001408710-22-000018:mdna:58]
[same as prior period, unchanged from 0001408710-21-000047:mdna:57]

[0001408710-22-000018:mdna:59]
[same as prior period, unchanged from 0001408710-21-000047:mdna:58]

[0001408710-22-000018:mdna:60]
[same as prior period, unchanged from 0001408710-21-000047:mdna:59]

[0001408710-22-000018:mdna:61]
|  | As of December 24, 2021 |  | As of June 25, 2021 |
| (amount in thousands, except percentages) | Currency |  | $ |  | % |  | Currency |  | $ |  | % |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 754,974 |  |  | $ | 22,516 |  |  | 62.4 | % |  | 1,472,249 |  |  | $ | 46,312 |  |  | 67.5 | % |
| RMB | 41,251 |  |  | 6,477 |  |  | 17.9 |  |  | 98,056 |  |  | 15,145 |  |  | 22.1 |  |
| GBP | 5,309 |  |  | 7,116 |  |  | 19.7 |  |  | 5,111 |  |  | 7,119 |  |  | 10.4 |  |
| Total |  |  | $ | 36,109 |  |  | 100.0 | % |  |  |  | $ | 68,576 |  |  | 100.0 | % |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 2,770,964 |  |  | $ | 82,641 |  |  | 85.5 | % |  | 2,250,514 |  |  | $ | 70,793 |  |  | 87.7 | % |
| RMB | 70,196 |  |  | 11,021 |  |  | 11.4 |  |  | 40,112 |  |  | 6,195 |  |  | 7.7 |  |
| GBP | 2,256 |  |  | 3,023 |  |  | 3.1 |  |  | 2,656 |  |  | 3,699 |  |  | 4.6 |  |
| Total |  |  | $ | 96,685 |  |  | 100.0 | % |  |  |  | $ | 80,687 |  |  | 100.0 | % |

[0001408710-22-000018:mdna:62]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of December 24, 2021, there was $135.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 25, 2021, there was $130.0 million of foreign currency forward contracts outstanding on the Thai baht payables.

[0001408710-22-000018:mdna:63]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of December 24, 2021 and June 25, 2021, we did not have any derivative contracts denominated in RMB.

[0001408710-22-000018:mdna:64]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable and other payables. As of December 24, 2021 and June 25, 2021, we did not have any derivative contracts denominated in GBP.

[0001408710-22-000018:mdna:65]
For the three months ended December 24, 2021 and December 25, 2020, we recorded gain of $1.1 million and $1.8 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-22-000018:mdna:66]
For the six months ended December 24, 2021 and December 25, 2020, we recorded gain of $0.5 million and $0.3 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-22-000018:mdna:67]
[same as prior period, unchanged from 0001408710-21-000047:mdna:65]

[0001408710-22-000018:mdna:68]
[same as prior period, unchanged from 0001408710-21-000047:mdna:66]

[0001408710-22-000018:mdna:69]
•Foreign Currency Administration Rules, as amended on August 5, 2008 (the “Exchange Rules”);

[0001408710-22-000018:mdna:70]
•Administration Rules of the Settlement, Sale and Payment of Foreign Exchange (1996) (the “Administration Rules”); and

[0001408710-22-000018:mdna:71]
•Notice on Perfecting Practices Concerning Foreign Exchange Settlement Regarding the Capital Contribution by Foreign-invested Enterprises, as promulgated by the State Administration of Foreign Exchange (“SAFE”), on August 29, 2008 (“Circular 142”).

[0001408710-22-000018:mdna:72]
[same as prior period, unchanged from 0001408710-21-000047:mdna:70]

[0001408710-22-000018:mdna:73]
[same as prior period, unchanged from 0001408710-21-000047:mdna:71]

[0001408710-22-000018:mdna:74]
[same as prior period, unchanged from 0001408710-21-000047:mdna:72]

[0001408710-22-000018:mdna:75]
On January 5, 2007, SAFE promulgated the Detailed Rules for Implementing the Measures for the Administration on Individual Foreign Exchange(the “Implementation Rules”). Under the Implementation Rules, PRC citizens who are granted share options by an overseas publicly-listed company are required, through a PRC agent or PRC subsidiary of such overseas publicly-listed company, to register with SAFE and complete certain other procedures.

[0001408710-22-000018:mdna:76]
In addition, the General Administration of Taxation has issued circulars concerning employee share options. Under these circulars, our employees working in the PRC who exercise share options will be subject to PRC individual income tax. Our

[0001408710-22-000018:mdna:77]
PRC subsidiary has obligations to file documents related to employee share options with relevant tax authorities and withhold individual income taxes of those employees who exercise their share options.

[0001408710-22-000018:mdna:78]
[same as prior period, unchanged from 0001408710-21-000047:mdna:75]

[0001408710-22-000018:mdna:79]
[same as prior period, unchanged from 0001408710-21-000047:mdna:76]

[0001408710-22-000018:mdna:80]
[same as prior period, unchanged from 0001408710-21-000047:mdna:77]

[0001408710-22-000018:mdna:81]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption on income generated from projects to manufacture certain products at our Chonburi campus is currently available to us through June 2026. Similar preferential tax treatment was available to us through June 2020 with respect to products manufactured at our Pinehurst campus Building 6. After June 2020, 50% of our income generated from products manufactured at our Pinehurst campus is exempted from tax through June 2025. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted. Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001408710-22-000018:mdna:82]
The corporate income tax rate for our subsidiaries in the PRC, the U.S., the U.K. and Israel are 25%, 21%, 19% and 23%, respectively.

[0001408710-22-000018:mdna:83]
[same as prior period, unchanged from 0001408710-21-000047:mdna:80]

[0001408710-22-000018:mdna:84]
[same as prior period, unchanged from 0001408710-21-000047:mdna:81]

[0001408710-22-000018:mdna:85]
[same as prior period, unchanged from 0001408710-21-000047:mdna:82]

[0001408710-22-000018:mdna:86]
[same as prior period, unchanged from 0001408710-21-000047:mdna:83]

[0001408710-22-000018:mdna:87]
[same as prior period, unchanged from 0001408710-21-000047:mdna:84]

[0001408710-22-000018:mdna:88]
| (amount in thousands) | Three Months Ended |  | Six Months Ended |
| December 24,2021 |  | December 25,2020 |  | December 24,2021 |  | December 25,2020 |
| Revenues | $ | 566,633 |  |  | $ | 453,827 |  |  | $ | 1,109,955 |  |  | $ | 890,466 |  |
| Cost of revenues | (497,262) |  |  | (400,806) |  |  | (976,987) |  |  | (786,965) |  |
| Gross profit | 69,371 |  |  | 53,021 |  |  | 132,968 |  |  | 103,501 |  |
| Selling, general and administrative expenses | (17,791) |  |  | (17,156) |  |  | (38,378) |  |  | (34,019) |  |
| Expenses related to reduction in workforce | (135) |  |  | — |  |  | (135) |  |  | — |  |
| Operating income | 51,445 |  |  | 35,865 |  |  | 94,455 |  |  | 69,482 |  |
| Interest income | 295 |  |  | 1,111 |  |  | 1,056 |  |  | 2,215 |  |
| Interest expense | (238) |  |  | (265) |  |  | (274) |  |  | (516) |  |
| Foreign exchange gain (loss), net | (364) |  |  | (533) |  |  | 1,408 |  |  | (405) |  |
| Other income (expense), net | (1,055) |  |  | 158 |  |  | (1,315) |  |  | 279 |  |
| Income before income taxes | 50,083 |  |  | 36,336 |  |  | 95,330 |  |  | 71,055 |  |
| Income tax expense | (1,204) |  |  | (952) |  |  | (1,800) |  |  | (2,620) |  |
| Net income | 48,879 |  |  | 35,384 |  |  | 93,530 |  |  | 68,435 |  |
| Other comprehensive income (loss), net of tax | 2,473 |  |  | 2,247 |  |  | 1,077 |  |  | (510) |  |
| Net comprehensive income | $ | 51,352 |  |  | $ | 37,631 |  |  | $ | 94,607 |  |  | $ | 67,925 |  |

[0001408710-22-000018:mdna:89]
[same as prior period, unchanged from 0001408710-21-000047:mdna:86]

[0001408710-22-000018:mdna:90]
|  | Three Months Ended |  | Six Months Ended |
|  | December 24,2021 |  | December 25,2020 |  | December 24,2021 |  | December 25,2020 |
| Revenues | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenues | (87.8) |  |  | (88.3) |  |  | (88.0) |  |  | (88.4) |  |
| Gross profit | 12.2 |  |  | 11.7 |  |  | 12.0 |  |  | 11.6 |  |
| Selling, general and administrative expenses | (3.1) |  |  | (3.8) |  |  | (3.5) |  |  | (3.8) |  |
| Expenses related to reduction in workforce | 0.0 |  |  | — |  |  | 0.0 |  |  | — |  |
| Operating income | 9.1 |  |  | 7.9 |  |  | 8.5 |  |  | 7.8 |  |
| Interest income | 0.1 |  |  | 0.2 |  |  | 0.1 |  |  | 0.3 |  |
| Interest expense | (0.1) |  |  | 0.0 |  |  | 0.1 |  |  | (0.1) |  |
| Foreign exchange gain (loss), net | (0.1) |  |  | (0.1) |  |  | 0.1 |  |  | 0.1 |  |
| Other income (expense), net | (0.2) |  |  | 0.0 |  |  | (0.2) |  |  | (0.1) |  |
| Income before income taxes | 8.8 |  |  | 8.0 |  |  | 8.6 |  |  | 8.0 |  |
| Income tax expense | (0.2) |  |  | (0.2) |  |  | (0.2) |  |  | (0.3) |  |
| Net income | 8.6 |  |  | 7.8 |  |  | 8.4 |  |  | 7.7 |  |
| Other comprehensive income (loss), net of tax | 0.5 |  |  | 0.5 |  |  | 0.1 |  |  | (0.1) |  |
| Net comprehensive income | 9.1 | % |  | 8.3 | % |  | 8.5 | % |  | 7.6 | % |

[0001408710-22-000018:mdna:91]
38

[0001408710-22-000018:mdna:92]
[same as prior period, unchanged from 0001408710-21-000047:mdna:89]

[0001408710-22-000018:mdna:93]
|  | Three Months Ended |  | Six Months Ended |
| (amount in thousands) | December 24,2021 |  | December 25,2020 |  | December 24,2021 |  | December 25,2020 |
| Optical communications | $ | 450,783 |  |  | $ | 347,840 |  |  | $ | 878,084 |  |  | $ | 691,757 |  |
| Lasers, sensors and other | 115,850 |  |  | 105,987 |  |  | 231,871 |  |  | 198,709 |  |
| Total | $ | 566,633 |  |  | $ | 453,827 |  |  | $ | 1,109,955 |  |  | $ | 890,466 |  |

[0001408710-22-000018:mdna:94]
[same as prior period, unchanged from 0001408710-21-000047:mdna:91]

[0001408710-22-000018:mdna:95]
Comparison of Three and Six Months Ended December 24, 2021 with Three and Six Months Ended December 25, 2020

[0001408710-22-000018:mdna:96]
[same as prior period, unchanged from 0001408710-21-000047:mdna:93]

[0001408710-22-000018:mdna:97]
Our revenues increased by $112.8 million, or 24.9%, to $566.6 million for the three months ended December 24, 2021, compared with $453.8 million for the three months ended December 25, 2020. This increase was due to an increase in our key customers’ demand for optical communications manufacturing services during the three months ended December 24, 2021. Revenues from optical communications products increased by $102.9 million, or 29.6%, for the three months ended December 24, 2021.

[0001408710-22-000018:mdna:98]
Our revenues increased by $219.5 million, or 24.6%, to $1,110.0 million for the six months ended December 24, 2021, compared with $890.5 million for the six months ended December 25, 2020. This increase was due to an increase in our key customers’ demand for optical communications manufacturing services during the six months ended December 24, 2021. Revenues from optical communications products increased by $186.3 million, or 26.9%, for the six months ended December 24, 2021.

[0001408710-22-000018:mdna:99]
[same as prior period, unchanged from 0001408710-21-000047:mdna:95]

[0001408710-22-000018:mdna:100]
Our cost of revenues increased by $96.5 million, or 24.1%, to $497.3 million, or 87.8% of revenues, for the three months ended December 24, 2021, compared with $400.8 million, or 88.3% of revenues, for the three months ended December 25, 2020. This increase in cost of revenues on an absolute dollar basis was in line with the increase in sales volume.

[0001408710-22-000018:mdna:101]
Our cost of revenues increased by $190.0 million, or 24.1%, to $977.0 million, or 88.0% of revenues, for the six months ended December 24, 2021, compared with $787.0 million, or 88.4% of revenues, for the six months ended December 25, 2020. This increase in cost of revenues on an absolute dollar basis was in line with the increase in sales volume.

[0001408710-22-000018:mdna:102]
[same as prior period, unchanged from 0001408710-21-000047:mdna:97]

[0001408710-22-000018:mdna:103]
Our gross profit increased by $16.4 million, or 30.8%, to $69.4 million, or 12.2% of revenues, for the three months ended December 24, 2021, compared with $53.0 million, or 11.7% of revenues, for the three months ended December 25, 2020. The increase was primarily due to an increase in sales volume.

[0001408710-22-000018:mdna:104]
Our gross profit increased by $29.5 million, or 28.5%, to $133.0 million, or 12.0% of revenues, for the six months ended December 24, 2021, compared with $103.5 million, or 11.6% of revenues, for the six months ended December 25, 2020. The increase was primarily due to an increase in sales volume.

[0001408710-22-000018:mdna:105]
[same as prior period, unchanged from 0001408710-21-000047:mdna:99]

[0001408710-22-000018:mdna:106]
Our SG&A expenses increased by $0.6 million, or 3.7%, to $17.8 million, or 3.1% of revenues, for the three months ended December 24, 2021, compared with $17.2 million, or 3.8% of revenues, for the three months ended December 25, 2020. The increase was primarily due to (1) an increase in share-based compensation expenses of $1.0 million and (2) an increase in research and development expenses of $0.4 million, offset by a decrease in start-up cost for our subsidiary in Israel of $0.7 million.

[0001408710-22-000018:mdna:107]
Our SG&A expenses increased by $4.4 million, or 12.8%, to $38.4 million, or 3.5% of revenues, for the six months ended December 24, 2021, compared with $34.0 million, or 3.8% of revenues, for the six months ended December 25, 2020. The increase was primarily due to (1) an increase in share-based compensation expenses of $4.1 million, mainly due to higher achievement of our targets for performance-based awards, (2) an increase in research and development expenses of $0.8

[0001408710-22-000018:mdna:108]
million, (3) an increase in insurance expenses of $0.4 million, and (4) the reversal of allowance for doubtful debt of $0.3 million in the same period of fiscal year 2021, offset by a decrease in start-up cost for our subsidiary in Israel of $1.3 million.

[0001408710-22-000018:mdna:109]
[same as prior period, unchanged from 0001408710-21-000047:mdna:101]

[0001408710-22-000018:mdna:110]
Our operating income increased by $15.6 million to $51.4 million, or 9.1% of revenues, for the three months ended December 24, 2021, compared with $35.9 million, or 7.9% of revenues, for the three months ended December 25, 2020. The increase was primarily due to an increase in revenues.

[0001408710-22-000018:mdna:111]
Our operating income increased by $25.0 million to $94.5 million, or 8.5% of revenues, for the six months ended December 24, 2021, compared with $69.5 million, or 7.8% of revenues, for the six months ended December 25, 2020. The increase was primarily due to an increase in revenues.

[0001408710-22-000018:mdna:112]
[same as prior period, unchanged from 0001408710-21-000047:mdna:103]

[0001408710-22-000018:mdna:113]
Our interest income decreased by $0.8 million, or 73.4%, to $0.3 million, or 0.1% of revenues, for the three months ended December 24, 2021, compared with $1.1 million, or 0.2% of revenues, for the three months ended December 25, 2020. The decrease was primarily due to a lower weighted average interest rate during the three months ended December 24, 2021 compared to same period in the prior fiscal year.

[0001408710-22-000018:mdna:114]
Our interest income decreased by $1.2 million, or 52.3%, to $1.1 million, or 0.1% of revenues, for the six months ended December 24, 2021, compared with $2.2 million, or 0.3% of revenues, for the six months ended December 25, 2020. The decrease was primarily due to a lower weighted average interest rate during the six months ended December 24, 2021 compared to same period in the prior fiscal year.

[0001408710-22-000018:mdna:115]
[same as prior period, unchanged from 0001408710-21-000047:mdna:105]

[0001408710-22-000018:mdna:116]
Our interest expense decreased by $27.0 thousand to $0.2 million for the three months ended December 24, 2021, compared with $0.3 million for the three months ended December 25, 2020. The decrease was primarily due to interest expense capitalized to a new manufacturing building at our Chonburi campus of $0.1 million and lower loan principal settlement of $27.0 thousand during the three months ended December 24, 2021, offset by lower amortization of the fair value of interest rate swaps of $0.1 million.

[0001408710-22-000018:mdna:117]
Our interest expense decreased by $0.2 million to $0.3 million for the six months ended December 24, 2021, compared with $0.5 million for the six months ended December 25, 2020. The decrease was primarily due to interest expense capitalized to a new manufacturing building at our Chonburi campus of $0.4 million and lower loan principal settlement of $52.8 thousand during the six months ended December 24, 2021, offset by lower amortization of the fair value of interest rate swaps of $0.2 million.

[0001408710-22-000018:mdna:118]
[same as prior period, unchanged from 0001408710-21-000047:mdna:108]

[0001408710-22-000018:mdna:119]
We recorded foreign exchange loss, net of $0.4 million for the three months ended December 24, 2021, compared with foreign exchange loss, net of $0.5 million for the three months ended December 25, 2020. The decrease in foreign exchange loss was mainly due to (1) higher realized gain from payment/receipt of $0.5 million for the three months ended December 24, 2021, as compared to realized loss from payment/receipt of $0.6 million for the three months ended December 25, 2020, (2) lower unrealized loss from revaluation of outstanding Thai baht assets and liabilities of $1.6 million for the three months ended December 24, 2021, as compared to unrealized loss from revaluation of outstanding Thai baht assets and liabilities of $2.6 million for the three months ended December 25, 2020, and (3) lower unrealized loss from revaluation of other currencies of $0.1 million for the three months ended December 24, 2021, as compared to unrealized loss from revaluation of other currencies of $0.2 million for the three months ended December 25, 2020, partially offset by (1) higher foreign exchange loss from our subsidiaries in the PRC and the U.K. totaling $0.3 million for the three months ended December 24, 2021, as compared to foreign exchange gain totaling $1.1 million from our subsidiaries in the PRC and the U.K. for the three months ended December 25, 2020, and (2) lower unrealized gain from the mark-to-market forward contracts of $1.1 million for the three months ended December 24, 2021, as compared to unrealized gain from mark-to-market forward contracts of $1.8 million for the three months ended December 25, 2020.

[0001408710-22-000018:mdna:120]
We recorded foreign exchange gain, net of $1.4 million for the six months ended December 24, 2021, compared with foreign exchange loss, net of $0.4 million for the six months ended December 25, 2020. The increase in foreign exchange gain was mainly due to (1) higher realized gain from payment/receipt of $0.8 million for the six months ended December 24, 2021, as compared to realized loss from payment/receipt of $1.0 million for the six months ended December 25, 2020, (2) higher unrealized gain from revaluation of outstanding Thai baht assets and liabilities of $0.6 million for the six months ended

[0001408710-22-000018:mdna:121]
December 24, 2021, as compared to unrealized loss from revaluation of outstanding Thai baht assets and liabilities of $0.6 million for the six months ended December 25, 2020, and (3) higher unrealized gain from mark-to-market forward contracts of $0.5 million for the six months ended December 24, 2021, as compared to unrealized gain from mark-to-market forward contracts of $0.3 million for the six months ended December 25, 2020, partially offset by higher foreign exchange loss from our subsidiaries in the PRC and the U.K. totaling $0.4 million for the six months ended December 24, 2021, as compared to foreign exchange gain totaling $1.1 million from our subsidiaries in the PRC and the U.K. for the six months ended December 25, 2020.

[0001408710-22-000018:mdna:122]
[same as prior period, unchanged from 0001408710-21-000047:mdna:110]

[0001408710-22-000018:mdna:123]
We recorded income before income taxes of $50.1 million and $95.3 million for the three and six months ended December 24, 2021, respectively, compared with $36.3 million and $71.1 million for the three and six months ended December 25, 2020, respectively.

[0001408710-22-000018:mdna:124]
[same as prior period, unchanged from 0001408710-21-000047:mdna:112]

[0001408710-22-000018:mdna:125]
Our provision for income tax reflects effective tax rates of 2.4% and 2.6% for the three months ended December 24, 2021 and December 25, 2020, respectively. The decrease was primarily due to the fact that we had more income not subject to tax during the second quarter of fiscal year 2022 as compared to the same period in fiscal year 2021.

[0001408710-22-000018:mdna:126]
Our provision for income tax reflects effective tax rates of 1.9% and 3.7% for the six months ended December 24, 2021 and December 25, 2020, respectively. The decrease was primarily due to the fact that we had more income not subject to tax during the first six months of fiscal year 2022 as compared to the same period in fiscal year 2021.

[0001408710-22-000018:mdna:127]
[same as prior period, unchanged from 0001408710-21-000047:mdna:114]

[0001408710-22-000018:mdna:128]
We recorded net income of $48.9 million, or 8.6% of revenues, for the three months ended December 24, 2021, compared with $35.4 million, or 7.8% of revenues, for the three months ended December 25, 2020.

[0001408710-22-000018:mdna:129]
We recorded net income of $93.5 million, or 8.4% of revenues, for the six months ended December 24, 2021, compared with $68.4 million, or 7.7% of revenues, for the six months ended December 25, 2020.

[0001408710-22-000018:mdna:130]
[same as prior period, unchanged from 0001408710-21-000047:mdna:116]

[0001408710-22-000018:mdna:131]
We recorded other comprehensive gain of $2.5 million, or 0.5% of revenues, for the three months ended December 24, 2021, compared with other comprehensive gain of $2.2 million, or 0.5% of revenues, for the three months ended December 25, 2020. The increase in other comprehensive income was mainly due to unrealized gain from mark-to-market of forward contracts and interest rate swap agreements of $3.3 million for the three months ended December 24, 2021, as compared to unrealized gain from mark-to-market of forward contracts and interest rate swap agreements of $2.4 million for the three months ended December 25, 2020, partially offset by (1) unrealized loss from mark-to-market of available-for-sale debt securities of $0.9 million for the three months ended December 24, 2021, as compared to unrealized loss from mark-to-market of available-for-sale debt securities of $40.0 thousand for the three months ended December 25, 2020, and (2) unrealized loss from foreign currency translation adjustment of $1.0 thousand  for the three months ended December 24, 2021, as compared to unrealized loss from foreign currency translation adjustment of $0.1 million for the three months ended December 25, 2020.

[0001408710-22-000018:mdna:132]
We recorded other comprehensive gain of $1.1 million, or 0.1% of revenues, for the six months ended December 24, 2021, compared with other comprehensive loss of $0.5 million, or 0.1% of revenues, for the six months ended December 25, 2020. The increase in other comprehensive income was mainly due to unrealized gain from mark-to-market of forward contracts and interest rate swap agreements of $2.1 million for the six months ended December 24, 2021, as compared to unrealized loss from mark-to-market of forward contracts and interest rate swap agreements of $0.8 million for the six months ended December 25, 2020, partially offset by (1) unrealized loss from mark-to-market of available-for-sale debt securities of $1.1 million for the six months ended December 24, 2021, as compared to unrealized loss from mark-to-market of available-for-sale debt securities of $0.4 million for the six months ended December 25, 2020, and (2) unrealized loss from foreign currency translation adjustment of $0.2 million for the six months ended December 24, 2021, as compared to unrealized gain from foreign currency translation adjustment of $0.4 million for the six months ended December 25, 2020.

[0001408710-22-000018:mdna:133]
[same as prior period, unchanged from 0001408710-21-000047:mdna:118]

[0001408710-22-000018:mdna:134]
[same as prior period, unchanged from 0001408710-21-000047:mdna:119]

[0001408710-22-000018:mdna:135]
We primarily finance our operations through cash flow from operations. As of December 24, 2021 and December 25, 2020, we had cash, cash equivalents, and short-term investments of $519.9 million and $481.0 million, respectively, and outstanding debt of $33.5 million and $45.7 million, respectively.

[0001408710-22-000018:mdna:136]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents was 0.3% and 0.5% for the three and six months ended December 24, 2021, respectively, and 0.9% for the three and six months ended December 25, 2020, respectively.

[0001408710-22-000018:mdna:137]
[same as prior period, unchanged from 0001408710-21-000047:mdna:122]

[0001408710-22-000018:mdna:138]
During the six months ended December 24, 2021, we repaid $6.1 million of the term loan under our credit facility agreement with the Bank of Ayudhya Public Company Limited. As a result, as of December 24, 2021, we had a long-term borrowing of $33.5 million under such credit facility agreement. (See Note 10 for further details.) We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held short-term investments of $243.3 million as of December 24, 2021.

[0001408710-22-000018:mdna:139]
We believe that our current cash and cash equivalents, short-term investments, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001408710-22-000018:mdna:140]
[same as prior period, unchanged from 0001408710-21-000047:mdna:125]

[0001408710-22-000018:mdna:141]
[same as prior period, unchanged from 0001408710-21-000047:mdna:126]

[0001408710-22-000018:mdna:142]
|  | Six Months Ended |
| (amount in thousands) | December 24, 2021 |  | December 25, 2020 |
| Net cash provided by operating activities | $ | 57,568 |  |  | $ | 41,314 |  |
| Net cash used in investing activities | $ | (53,777) |  |  | $ | (24,346) |  |
| Net cash used in financing activities | $ | (29,773) |  |  | $ | (23,629) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | (25,982) |  |  | $ | (6,661) |  |

[0001408710-22-000018:mdna:143]
[same as prior period, unchanged from 0001408710-21-000047:mdna:128]

[0001408710-22-000018:mdna:144]
Net cash provided by operating activities of $57.6 million for the six months ended December 24, 2021 was primarily due to (1) net income of $93.5 million, (2) an increase in trade accounts payable of $44.1 million, (3) depreciation and amortization of $19.1 million, and (4) share-based compensation of $16.0 million; offset by (1) an increase in inventories of $62.7 million, (2) trade account receivable of $48.0 million and (3) other assets of $5.6 million.

[0001408710-22-000018:mdna:145]
Net cash provided by operating activities of $41.3 million for the six months ended December 25, 2020 was primarily due to (1) net income $68.4 million, (2) an increase in trade accounts payable of $45.2 million, (3) other liabilities of $20.1 million, (4) depreciation and amortization of $17.7 million, and (5) share-based compensation of $11.9 million; offset by (1) an increase in inventories of $62.2 million, (2) trade accounts receivable of $45.4 million, and (3) other assets of $12.0 million.

[0001408710-22-000018:mdna:146]
[same as prior period, unchanged from 0001408710-21-000047:mdna:131]

[0001408710-22-000018:mdna:147]
Net cash used in investing activities of $53.8 million for the six months ended December 24, 2021 was primarily due to (1) the purchase of property, plant and equipment of $51.9 million, mainly related to a new manufacturing building at our Chonburi campus of $15.8 million, (2) a net purchase of short-term investments of $1.6 million, and (3) the purchase of intangibles assets of $0.4 million.

[0001408710-22-000018:mdna:148]
Net cash used in investing activities of $24.3 million for the six months ended December 25, 2020 was primarily due to (1) the purchase of property, plant and equipment of $22.7 million, (2) the purchase of intangibles assets of $1.3 million, and (3) a net purchase of short-term investments of $0.4 million.

[0001408710-22-000018:mdna:149]
[same as prior period, unchanged from 0001408710-21-000047:mdna:134]

[0001408710-22-000018:mdna:150]
Net cash used in financing activities of $29.8 million for the six months ended December 24, 2021 was primarily due to (1) cash paid for withholding tax related to net share settlement of restricted share units of $19.5 million, (2) repayment of bank loans of $6.1 million, and (3) repurchase of ordinary shares of $4.2 million.

[0001408710-22-000018:mdna:151]
Net cash used in financing activities of $23.6 million for the six months ended December 25, 2020 was primarily due to (1) cash paid for withholding tax related to net share settlement of restricted share units of $10.4 million, (2) repurchase of ordinary shares of $7.1 million, and (3) repayment of loans to banks of $6.1 million.

[0001408710-22-000018:mdna:152]
[same as prior period, unchanged from 0001408710-21-000047:mdna:137]

[0001408710-22-000018:mdna:153]
[same as prior period, unchanged from 0001408710-21-000047:mdna:138]
