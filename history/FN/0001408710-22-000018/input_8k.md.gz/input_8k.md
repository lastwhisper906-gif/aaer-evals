# FN 8-K — 0001408710-22-000016 filed 2022-01-31

## item codes, every 8-K on or before 2022-02-01

- 2022-01-31 0001408710-22-000016 — 2.02, 9.01
- 2022-01-19 0001408710-22-000010 — 5.02
- 2022-01-06 0001408710-22-000006 — 5.02
- 2021-12-10 0001408710-21-000051 — 5.07
- 2021-11-01 0001408710-21-000045 — 2.02, 9.01
- 2021-08-16 0001408710-21-000031 — 2.02, 5.02, 9.01
- 2021-05-03 0001408710-21-000019 — 2.02, 9.01
- 2021-02-01 0001408710-21-000008 — 2.02, 9.01
- 2020-12-11 0001193125-20-315861 — 5.07
- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2022-02-01

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001408710-22-000016:8k_2_02:1]
EX-99.1
2
fn-20220131xex991q222.htm
EX-99.1

[0001408710-22-000016:8k_2_02:2]
Document

[0001408710-22-000016:8k_2_02:3]
Exhibit 99.1

[0001408710-22-000016:8k_2_02:4]
Fabrinet Announces Second Quarter Fiscal Year 2022 Financial Results

[0001408710-22-000016:8k_2_02:5]
•Record Second Quarter Revenue of $566.6 Million Exceeds Guidance

[0001408710-22-000016:8k_2_02:6]
•Record GAAP and Non-GAAP Net Income per Share Exceed Guidance

[0001408710-22-000016:8k_2_02:7]
BANGKOK, Thailand – January 31, 2022 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its second fiscal quarter ended December 24, 2021.

[0001408710-22-000016:8k_2_02:8]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “We had an excellent second quarter with revenue and non-GAAP EPS that exceeded our guidance ranges. Our team continues to effectively manage ongoing supply chain constraints, and with continued strong demand trends, our outlook remains very positive.”

[0001408710-22-000016:8k_2_02:9]
Second Quarter Fiscal Year 2022 Financial Highlights

[0001408710-22-000016:8k_2_02:10]
GAAP Results

[0001408710-22-000016:8k_2_02:11]
•Revenue for the second quarter of fiscal year 2022 was $566.6 million, compared to $453.8 million in the second quarter of fiscal year 2021.

[0001408710-22-000016:8k_2_02:12]
•GAAP net income for the second quarter of fiscal year 2022 was $48.9 million, compared to GAAP net income of $35.4 million for the second quarter of fiscal year 2021.

[0001408710-22-000016:8k_2_02:13]
•GAAP net income per diluted share for the second quarter of fiscal year 2022 was $1.30, compared to GAAP net income per diluted share of $0.94 for the second quarter of fiscal year 2021.

[0001408710-22-000016:8k_2_02:14]
Non-GAAP Results

[0001408710-22-000016:8k_2_02:15]
•Non-GAAP net income for the second quarter of fiscal year 2022 was $56.2 million, compared to non-GAAP net income of $41.5 million for the second quarter of fiscal year 2021.

[0001408710-22-000016:8k_2_02:16]
•Non-GAAP net income per diluted share for the second quarter of fiscal year 2022 was $1.50, compared to non-GAAP net income per diluted share of $1.10 for the second quarter of fiscal year 2021.

[0001408710-22-000016:8k_2_02:17]
Business Outlook

[0001408710-22-000016:8k_2_02:18]
Based on information available as of January 31, 2022, Fabrinet is issuing guidance for its third fiscal quarter ending

[0001408710-22-000016:8k_2_02:19]
March 25, 2022, as follows:

[0001408710-22-000016:8k_2_02:20]
•Fabrinet expects third quarter revenue to be in the range of $560 million to $580 million.

[0001408710-22-000016:8k_2_02:21]
•GAAP net income per diluted share is expected to be in the range of $1.30 to $1.37, based on approximately 37.6 million fully diluted shares outstanding.

[0001408710-22-000016:8k_2_02:22]
•Non-GAAP net income per diluted share is expected to be in the range of $1.48 to $1.55, based on approximately 37.6 million fully diluted shares outstanding.

[0001408710-22-000016:8k_2_02:23]
Conference Call Information

[0001408710-22-000016:8k_2_02:24]
| What: |  | Fabrinet Second Quarter Fiscal Year 2022 Financial Results Call |
| When: |  | Monday, January 31, 2022 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic(253) 237-1137, internationalConference ID: 9373655 |
| Replay: |  | (855) 859-2056, domestic(404) 537-3406, internationalConference ID: 9373655 |
| Webcast: |  | http://investor.fabrinet.com/ (live and replay) |

[0001408710-22-000016:8k_2_02:25]
A recorded version of this webcast will be available approximately two hours after the call and accessible at http://investor.fabrinet.com. The webcast will be archived on Fabrinet’s website for a period of one year.

[0001408710-22-000016:8k_2_02:26]
About Fabrinet

[0001408710-22-000016:8k_2_02:27]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China, Israel and the

[0001408710-22-000016:8k_2_02:28]
United Kingdom. For more information visit: www.fabrinet.com.

[0001408710-22-000016:8k_2_02:29]
Forward-Looking Statements

[0001408710-22-000016:8k_2_02:30]
Use of Non-GAAP Financials

[0001408710-22-000016:8k_2_02:31]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; depreciation of fair value uplift; amortization of intangibles; severance payment and others; other expenses in relation to reduction in workforce; and amortization of deferred debt issuance costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001408710-22-000016:8k_2_02:32]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001408710-22-000016:8k_2_02:33]
Investor Contact:

[0001408710-22-000016:8k_2_02:34]
Garo Toomajanian

[0001408710-22-000016:8k_2_02:35]
ir@fabrinet.com

[0001408710-22-000016:8k_2_02:36]
FABRINET

[0001408710-22-000016:8k_2_02:37]
CONDENSED CONSOLIDATED BALANCE SHEETS (unaudited)

[0001408710-22-000016:8k_2_02:38]
| (in thousands of U.S. dollars, except share data and par value) | December 24,2021 |  | June 25,2021 |
| Assets |  |  |  |
| Current assets |  |  |  |
| Cash and cash equivalents | $ | 276,531 |  |  | $ | 302,969 |  |
| Short-term restricted cash | 157 |  |  | — |  |
| Short-term investments | 243,339 |  |  | 244,963 |  |
| Trade accounts receivable, net of allowance for doubtful accounts of $70 and $100, respectively | 384,725 |  |  | 336,547 |  |
| Contract assets | 13,148 |  |  | 11,878 |  |
| Inventories | 484,873 |  |  | 422,133 |  |
| Prepaid expenses | 8,765 |  |  | 11,398 |  |
| Other current assets | 28,449 |  |  | 22,619 |  |
| Total current assets | 1,439,987 |  |  | 1,352,507 |  |
| Non-current assets |  |  |  |
| Long-term restricted cash | 157 |  |  | 154 |  |
| Property, plant and equipment, net | 290,683 |  |  | 241,129 |  |
| Intangibles, net | 3,878 |  |  | 4,371 |  |
| Operating right-of-use assets | 5,478 |  |  | 6,699 |  |
| Deferred tax assets | 10,025 |  |  | 9,428 |  |
| Other non-current assets | 587 |  |  | 1,834 |  |
| Total non-current assets | 310,808 |  |  | 263,615 |  |
| Total Assets | $ | 1,750,795 |  |  | $ | 1,616,122 |  |
| Liabilities and Shareholders’ Equity |  |  |  |
| Current liabilities |  |  |  |
| Long-term borrowings, current portion, net | $ | 12,156 |  |  | $ | 12,156 |  |
| Trade accounts payable | 391,176 |  |  | 346,555 |  |
| Fixed assets payable | 28,740 |  |  | 19,206 |  |
| Contract liabilities | 1,894 |  |  | 1,680 |  |
| Operating lease liabilities, current portion | 2,631 |  |  | 2,593 |  |
| Income tax payable | 2,200 |  |  | 3,612 |  |
| Accrued payroll, bonus and related expenses | 18,382 |  |  | 20,464 |  |
| Accrued expenses | 19,826 |  |  | 17,134 |  |
| Other payables | 23,032 |  |  | 20,958 |  |
| Total current liabilities | 500,037 |  |  | 444,358 |  |
| Non-current liabilities |  |  |  |
| Long-term borrowings, non-current portion, net | 21,279 |  |  | 27,358 |  |
| Deferred tax liability | 5,082 |  |  | 5,107 |  |
| Operating lease liability, non-current portion | 2,581 |  |  | 3,850 |  |
| Severance liabilities | 19,834 |  |  | 19,485 |  |
| Other non-current liabilities | 2,791 |  |  | 3,444 |  |
| Total non-current liabilities | 51,567 |  |  | 59,244 |  |
| Total Liabilities | 551,604 |  |  | 503,602 |  |
| Commitments and contingencies |  |  |  |
| Shareholders’ equity |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of December 24, 2021 and June 25, 2021) | — |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 39,008,996 shares and 38,749,045 shares issued at December 24, 2021 and June 25, 2021, respectively; and 36,987,138 shares and 36,765,456 shares outstanding at December 24, 2021 and June 25, 2021, respectively) | 390 |  |  | 388 |  |
| Additional paid-in capital | 185,940 |  |  | 189,445 |  |
| Less: Treasury shares (2,021,858 shares and 1,983,589 shares as of December 24, 2021 and June 25, 2021 respectively) | (91,776) |  |  | (87,343) |  |
| Accumulated other comprehensive income (loss) | (5,189) |  |  | (6,266) |  |
| Retained earnings | 1,109,826 |  |  | 1,016,296 |  |
| Total Shareholders’ Equity | 1,199,191 |  |  | 1,112,520 |  |
| Total Liabilities and Shareholders’ Equity | $ | 1,750,795 |  |  | $ | 1,616,122 |  |

[0001408710-22-000016:8k_2_02:39]
FABRINET

[0001408710-22-000016:8k_2_02:40]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME (unaudited)

[0001408710-22-000016:8k_2_02:41]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands of U.S. dollars, except per share data) | December 24,2021 |  | December 25,2020 |  | December 24,2021 |  | December 25,2020 |
| Revenues | $ | 566,633 |  |  | $ | 453,827 |  |  | $ | 1,109,955 |  |  | $ | 890,466 |  |
| Cost of revenues | (497,262) |  |  | (400,806) |  |  | (976,987) |  |  | (786,965) |  |
| Gross profit | 69,371 |  |  | 53,021 |  |  | 132,968 |  |  | 103,501 |  |
| Selling, general and administrative expenses | (17,791) |  |  | (17,156) |  |  | (38,378) |  |  | (34,019) |  |
| Expenses related to reduction in workforce | (135) |  |  | — |  |  | (135) |  |  | — |  |
| Operating income | 51,445 |  |  | 35,865 |  |  | 94,455 |  |  | 69,482 |  |
| Interest income | 295 |  |  | 1,111 |  |  | 1,056 |  |  | 2,215 |  |
| Interest expense | (238) |  |  | (265) |  |  | (274) |  |  | (516) |  |
| Foreign exchange gain (loss), net | (364) |  |  | (533) |  |  | 1,408 |  |  | (405) |  |
| Other income (expense), net | (1,055) |  |  | 158 |  |  | (1,315) |  |  | 279 |  |
| Income before income taxes | 50,083 |  |  | 36,336 |  |  | 95,330 |  |  | 71,055 |  |
| Income tax expense | (1,204) |  |  | (952) |  |  | (1,800) |  |  | (2,620) |  |
| Net income | 48,879 |  |  | 35,384 |  |  | 93,530 |  |  | 68,435 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities | (947) |  |  | (42) |  |  | (1,160) |  |  | (367) |  |
| Change in net unrealized gain (loss) on derivative instruments | 3,294 |  |  | 2,385 |  |  | 2,077 |  |  | (823) |  |
| Change in net retirement benefits plan – prior service cost | 126 |  |  | 50 |  |  | 324 |  |  | 223 |  |
| Change in foreign currency translation adjustment | — |  |  | (146) |  |  | (164) |  |  | 457 |  |
| Total other comprehensive income (loss), net of tax | 2,473 |  |  | 2,247 |  |  | 1,077 |  |  | (510) |  |
| Net comprehensive income (loss) | $ | 51,352 |  |  | $ | 37,631 |  |  | $ | 94,607 |  |  | $ | 67,925 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 1.32 |  |  | $ | 0.96 |  |  | $ | 2.53 |  |  | $ | 1.86 |  |
| Diluted | $ | 1.30 |  |  | $ | 0.94 |  |  | $ | 2.50 |  |  | $ | 1.83 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |
| Basic | 37,017 |  |  | 36,936 |  |  | 36,947 |  |  | 36,877 |  |
| Diluted | 37,552 |  |  | 37,551 |  |  | 37,440 |  |  | 37,467 |  |

[0001408710-22-000016:8k_2_02:42]
FABRINET

[0001408710-22-000016:8k_2_02:43]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited)

[0001408710-22-000016:8k_2_02:44]
|  | Six Months Ended |
| (in thousands of U.S. dollars) | December 24,2021 |  | December 25,2020 |
| Cash flows from operating activities |  |  |  |
| Net income for the period | $ | 93,530 |  |  | $ | 68,435 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 19,114 |  |  | 17,650 |  |
| Gain on disposal of property, plant and equipment | (135) |  |  | (24) |  |
| Gain from sales and maturities of available-for-sale securities | (13) |  |  | (86) |  |
| Amortization of investment discount | 2,079 |  |  | 1,003 |  |
| Amortization of deferred debt issuance costs | 16 |  |  | 16 |  |
| (Reversal of) allowance for doubtful accounts | (30) |  |  | (321) |  |
| Unrealized gain on exchange rate and fair value of foreign currency forward contracts | (673) |  |  | (290) |  |
| Amortization of fair value at hedge inception of interest rate swaps | (513) |  |  | (695) |  |
| Share-based compensation | 15,978 |  |  | 11,878 |  |
| Deferred income tax | (986) |  |  | (461) |  |
| Other non-cash expenses | 268 |  |  | (657) |  |
| Changes in operating assets and liabilities |  |  |  |
| Trade accounts receivable | (48,046) |  |  | (45,410) |  |
| Contract assets | (1,270) |  |  | (2,967) |  |
| Inventories | (62,740) |  |  | (62,211) |  |
| Other current assets and non-current assets | (5,568) |  |  | (11,983) |  |
| Trade accounts payable | 44,078 |  |  | 45,179 |  |
| Contract liabilities | 214 |  |  | 248 |  |
| Income tax payable | (1,323) |  |  | 548 |  |
| Severance liabilities | 1,708 |  |  | 1,350 |  |
| Other current liabilities and non-current liabilities | 1,880 |  |  | 20,112 |  |
| Net cash provided by operating activities | 57,568 |  |  | 41,314 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of short-term investments | (78,786) |  |  | (126,701) |  |
| Proceeds from sales of short-term investments | 19,463 |  |  | 57,486 |  |
| Proceeds from maturities of short-term investments | 57,721 |  |  | 68,807 |  |
| Purchase of property, plant and equipment | (51,917) |  |  | (22,693) |  |
| Purchase of intangibles | (446) |  |  | (1,271) |  |
| Proceeds from disposal of property, plant and equipment | 188 |  |  | 26 |  |
| Net cash used in investing activities | (53,777) |  |  | (24,346) |  |
| Cash flows from financing activities |  |  |  |
| Repayment of long-term borrowings | (6,094) |  |  | (6,094) |  |
| Repayment of finance lease liability | — |  |  | (100) |  |
| Repurchase of ordinary shares | (4,198) |  |  | (7,074) |  |
| Withholding tax related to net share settlement of restricted share units | (19,481) |  |  | (10,361) |  |
| Net cash used in financing activities | (29,773) |  |  | (23,629) |  |
| Net decrease in cash, cash equivalents and restricted cash | $ | (25,982) |  |  | $ | (6,661) |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at the beginning of period | $ | 303,123 |  |  | $ | 232,832 |  |
| Decrease in cash, cash equivalents and restricted cash | (25,982) |  |  | (6,661) |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash | (296) |  |  | 605 |  |
| Cash, cash equivalents and restricted cash at the end of period | $ | 276,845 |  |  | $ | 226,776 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment-related payables | $ | 28,740 |  |  | $ | 7,748 |  |

[0001408710-22-000016:8k_2_02:45]
FABRINET

[0001408710-22-000016:8k_2_02:46]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited) (Continued)

[0001408710-22-000016:8k_2_02:47]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the unaudited condensed consolidated balance sheets that sum to the total of the same amounts shown in the unaudited condensed consolidated statements of cash flows:

[0001408710-22-000016:8k_2_02:48]
| (amount in thousands) | As ofDecember 24, 2021 |  | As ofDecember 25, 2020 |
| Cash and cash equivalents | $ | 276,531 |  |  | $ | 219,221 |  |
| Restricted cash | 314 |  |  | 7,555 |  |
| Cash, cash equivalents and restricted cash | $ | 276,845 |  |  | $ | 226,776 |  |

[0001408710-22-000016:8k_2_02:49]
FABRINET

[0001408710-22-000016:8k_2_02:50]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-22-000016:8k_2_02:51]
|  | Three Months Ended |  | Six Months Ended |
|  | December 24,2021 |  | December 25,2020 |  | December 24,2021 |  | December 25,2020 |
| (in thousands of U.S. dollars, except share data and par value) | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |
| GAAP measures | $ | 48,879 |  |  | $ | 1.30 |  |  | $ | 35,384 |  |  | $ | 0.94 |  |  | $ | 93,530 |  |  | $ | 2.50 |  |  | $ | 68,435 |  |  | $ | 1.83 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 1,421 |  |  | 0.04 |  |  | 1,592 |  |  | 0.04 |  |  | 3,396 |  |  | 0.09 |  |  | 3,417 |  |  | 0.09 |  |
| Depreciation of fair value uplift | — |  |  | — |  |  | 83 |  |  | 0.00 |  | 92 |  |  | 0.00 |  | 167 |  |  | 0.00 |
| Total related to gross profit | 1,421 |  |  | 0.04 |  |  | 1,675 |  |  | 0.04 |  |  | 3,488 |  |  | 0.09 |  |  | 3,584 |  |  | 0.10 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 5,265 |  |  | 0.14 |  |  | 4,259 |  |  | 0.11 |  |  | 12,582 |  |  | 0.33 |  |  | 8,461 |  |  | 0.23 |  |
| Amortization of intangibles | 108 |  |  | 0.00 |  |  | 124 |  |  | 0.00 |  |  | 227 |  |  | 0.01 |  |  | 255 |  |  | 0.01 |  |
| Severance payment and others | 355 |  |  | 0.01 |  |  | — |  |  | — |  |  | 355 |  |  | 0.01 |  |  | — |  |  | — |  |
| Total related to selling, general and administrative expenses | 5,728 |  |  | 0.15 |  |  | 4,383 |  |  | 0.12 |  |  | 13,164 |  |  | 0.35 |  |  | 8,716 |  |  | 0.23 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other expenses in relation to reduction in workforce | 135 |  |  | 0.00 |  | — |  |  | — |  |  | 135 |  |  | 0.01 |  | — |  |  | — |  |
| Amortization of deferred debt issuance costs | 8 |  |  | 0.00 |  | 8 |  |  | 0.00 |  | 16 |  |  | 0.00 |  | 16 |  |  | 0.00 |
| Total related to other incomes and other expenses | 143 |  |  | 0.00 |  | 8 |  |  | 0.00 |  | 151 |  |  | 0.01 |  | 16 |  |  | 0.00 |
| Total related to net income & EPS | 7,292 |  |  | 0.19 |  |  | 6,066 |  |  | 0.16 |  |  | 16,803 |  |  | 0.45 |  |  | 12,316 |  |  | 0.33 |  |
| Non-GAAP measures | $ | 56,171 |  |  | $ | 1.50 |  |  | $ | 41,450 |  |  | $ | 1.10 |  |  | $ | 110,333 |  |  | $ | 2.95 |  |  | $ | 80,751 |  |  | $ | 2.16 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  | 37,552 |  |  |  |  | 37,551 |  |  |  |  | 37,440 |  |  |  | 37,467 |
| Non-GAAP diluted shares |  |  | 37,552 |  |  |  |  | 37,551 |  |  |  |  | 37,440 |  |  |  | 37,467 |

[0001408710-22-000016:8k_2_02:52]
FABRINET

[0001408710-22-000016:8k_2_02:53]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001408710-22-000016:8k_2_02:54]
| (amount in thousands) |  | Three Months Ended |  | Six Months Ended |
|  |  | December 24,2021 |  | December 25,2020 |  | December 24,2021 |  | December 25,2020 |
| Net cash provided by operating activities |  | $ | 18,553 |  |  | $ | 6,808 |  |  | $ | 57,568 |  |  | $ | 41,314 |  |
| Less: Purchase of property, plant and equipment |  | (17,301) |  |  | (10,121) |  |  | (51,917) |  |  | (22,693) |  |
| Non-GAAP free cash flow |  | $ | 1,252 |  |  | $ | (3,313) |  |  | $ | 5,651 |  |  | $ | 18,621 |  |

[0001408710-22-000016:8k_2_02:55]
FABRINET

[0001408710-22-000016:8k_2_02:56]
GUIDANCE FOR QUARTER ENDING MARCH 25, 2022

[0001408710-22-000016:8k_2_02:57]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-22-000016:8k_2_02:58]
|  | DilutedEPS |
| GAAP net income per diluted share: | $1.30 to $1.37 |
| Related to cost of revenues: |  |
| Share-based compensation expenses | 0.04 |
| Total related to gross profit | 0.04 |
| Related to selling, general and administrative expenses: |  |
| Share-based compensation expenses | 0.14 |
| Total related to selling, general and administrative expenses | 0.14 |
| Total related to net income & EPS | 0.18 |
| Non-GAAP net income per diluted share | $1.48 to $1.55 |
