# FN notes — 0001408710-22-000018


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001408710-22-000018:notes:1]
[same as prior period, unchanged from 0001408710-21-000047:notes:1]

[0001408710-22-000018:notes:2]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of December 24, 2021 and for the three and six months ended December 24, 2021 and December 25, 2020 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 25, 2021.

[0001408710-22-000018:notes:3]
[same as prior period, unchanged from 0001408710-21-000047:notes:3]

[0001408710-22-000018:notes:4]
The results for the three and six months ended December 24, 2021 may not be indicative of results for the year ending June 24, 2022 or any future periods.

[0001408710-22-000018:notes:5]
[same as prior period, unchanged from 0001408710-21-000047:notes:5]

[0001408710-22-000018:notes:6]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information. Additionally, the extent to which the evolving COVID-19 pandemic impacts the Company’s unaudited condensed consolidated financial statements will depend on a number of factors, including the magnitude and duration of the pandemic. These estimates may change as new events occur and additional information is obtained, as well as based upon the occurrence of other factors related to the COVID-19 pandemic that could result in material impacts to the Company's unaudited condensed consolidated financial statements in future reporting periods.

[0001408710-22-000018:notes:7]
[same as prior period, unchanged from 0001408710-21-000047:notes:7]

[0001408710-22-000018:notes:8]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  December 24, 2021 and December 25, 2020 each consisted of 13 weeks. The six months ended December 24, 2021 and December 25, 2020 each consisted of 26 weeks. Fiscal year 2022 will be comprised of 52 weeks and will end on June 24, 2022.

[0001408710-22-000018:notes:9]
[same as prior period, unchanged from 0001408710-21-000047:notes:9]

[0001408710-22-000018:notes:10]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2019-12, “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.” The amendments in this update simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify U.S. GAAP for other areas of Topic 740 by clarifying and amending existing guidance. The Company adopted this standard in the first quarter of fiscal year 2022 with no material impact on its unaudited condensed consolidated financial statements.

[0001408710-22-000018:notes:11]
New Accounting Pronouncements – not yet adopted by the Company

[0001408710-22-000018:notes:12]
In November 2021, the Financial Accounting Standards Board issued ASU 2021-10, “Government Assistance (Topic 832), Disclosures by Business Entities about Government Assistance,” which requires annual disclosures that increase the transparency of transactions involving government assistance, including (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The amendments in this update are effective for all entities within the ASU's scope for financial statements issued for annual periods beginning after December 15, 2021. This ASU will be effective for the Company in the first quarter of fiscal year 2023. Early adoption is permitted.  The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001408710-22-000018:notes:13]
[same as prior period, unchanged from 0001408710-21-000047:notes:11]

[0001408710-22-000018:notes:14]
[same as prior period, unchanged from 0001408710-21-000047:notes:12]

[0001408710-22-000018:notes:15]
[same as prior period, unchanged from 0001408710-21-000047:notes:13]

[0001408710-22-000018:notes:16]
| (amount in thousands, except percentages) | Three Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |  | Six Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 243,720 |  |  |  |  | 488,994 |  |  |  |
| Others (1) | 3,557 |  |  |  |  | 4,873 |  |  |  |
| Total revenue in North America | 247,277 |  |  | 43.6 | % |  | 493,867 |  |  | 44.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 74,121 |  |  |  |  | 139,054 |  |  |  |
| Malaysia | 60,369 |  |  |  |  | 112,118 |  |  |  |
| Hong Kong | 23,206 |  |  |  |  | 44,237 |  |  |  |
| Israel | 22,801 |  |  |  |  | 50,434 |  |  |  |
| Japan | 15,832 |  |  |  |  | 30,809 |  |  |  |
| China | 14,146 |  |  |  |  | 27,781 |  |  |  |
| Others | 11,565 |  |  |  |  | 23,790 |  |  |  |
| Total revenue in Asia-Pacific and others | 222,040 |  |  | 39.2 | % |  | 428,223 |  |  | 38.6 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 54,900 |  |  |  |  | 104,384 |  |  |  |
| U.K. | 22,941 |  |  |  |  | 42,519 |  |  |  |
| Germany | 8,985 |  |  |  |  | 17,410 |  |  |  |
| Others | 10,490 |  |  |  |  | 23,552 |  |  |  |
| Total revenue in Europe | $ | 97,316 |  |  | 17.2 | % |  | $ | 187,865 |  |  | 16.9 | % |
| Total revenue | $ | 566,633 |  |  | 100.0 | % |  | $ | 1,109,955 |  |  | 100.0 | % |

[0001408710-22-000018:notes:17]
| (amount in thousands, except percentages) | Three Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |  | Six Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 224,046 |  |  |  |  | 430,996 |  |  |  |
| Others (1) | 626 |  |  |  |  | 1,078 |  |  |  |
| Total revenue in North America | 224,672 |  |  | 49.5 | % |  | 432,074 |  |  | 48.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Malaysia | 34,546 |  |  |  |  | 80,188 |  |  |  |
| India | 28,865 |  |  |  |  | 28,885 |  |  |  |
| Israel | 27,102 |  |  |  |  | 57,217 |  |  |  |
| Hong Kong | 18,092 |  |  |  |  | 41,598 |  |  |  |
| Japan | 17,309 |  |  |  |  | 37,642 |  |  |  |
| China | 12,563 |  |  |  |  | 26,340 |  |  |  |
| Others | 15,257 |  |  |  |  | 27,510 |  |  |  |
| Total revenue in Asia-Pacific and others | 153,734 |  |  | 33.9 | % |  | 299,380 |  |  | 33.6 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 48,954 |  |  |  |  | 102,730 |  |  |  |
| U.K. | 10,004 |  |  |  |  | 25,315 |  |  |  |
| Germany | 6,253 |  |  |  |  | 12,052 |  |  |  |
| Others | 10,210 |  |  |  |  | 18,915 |  |  |  |
| Total revenue in Europe | $ | 75,421 |  |  | 16.6 | % |  | $ | 159,012 |  |  | 17.9 | % |
| Total revenue | $ | 453,827 |  |  | 100.0 | % |  | $ | 890,466 |  |  | 100.0 | % |

[0001408710-22-000018:notes:18]
(1)Others includes revenues from external customers based in our country of domicile, the Cayman Islands, which for each year presented is $0.

[0001408710-22-000018:notes:19]
[same as prior period, unchanged from 0001408710-21-000047:notes:16]

[0001408710-22-000018:notes:20]
| (amount in thousands, except percentages) | Three Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |  | Six Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |
| Optical communications | $ | 450,783 |  |  | 79.6 | % |  | $ | 878,084 |  |  | 79.1 | % |
| Lasers, sensors and other | 115,850 |  |  | 20.4 | % |  | 231,871 |  |  | 20.9 | % |
| Total | $ | 566,633 |  |  | 100.0 | % |  | $ | 1,109,955 |  |  | 100.0 | % |

[0001408710-22-000018:notes:21]
| (amount in thousands, except percentages) | Three Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |  | Six Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |
| Optical communications | $ | 347,840 |  |  | 76.6 | % |  | $ | 691,757 |  |  | 77.7 | % |
| Lasers, sensors and other | 105,987 |  |  | 23.4 | % |  | 198,709 |  |  | 22.3 | % |
| Total | $ | 453,827 |  |  | 100.0 | % |  | $ | 890,466 |  |  | 100.0 | % |

[0001408710-22-000018:notes:22]
[same as prior period, unchanged from 0001408710-21-000047:notes:18]

[0001408710-22-000018:notes:23]
[same as prior period, unchanged from 0001408710-21-000047:notes:19]

[0001408710-22-000018:notes:24]
[same as prior period, unchanged from 0001408710-21-000047:notes:20]

[0001408710-22-000018:notes:25]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the six months ended December 24, 2021:

[0001408710-22-000018:notes:26]
| (amount in thousands) | ContractAssets |
| Beginning balance, June 25, 2021 | $ | 11,878 |  |
| Revenue recognized | 26,241 |  |
| Amounts collected or invoiced | (24,971) |  |
| Ending balance, December 24, 2021 | $ | 13,148 |  |

[0001408710-22-000018:notes:27]
| (amount in thousands) | ContractLiabilities |
| Beginning balance, June 25, 2021 | $ | 1,680 |  |
| Advance payment received during the period | 3,281 |  |
| Revenue recognized | (3,067) |  |
| Ending balance, December 24, 2021 | $ | 1,894 |  |


## us-gaap:EarningsPerShareTextBlock

[0001408710-22-000018:notes:28]
[same as prior period, unchanged from 0001408710-21-000047:notes:24]

[0001408710-22-000018:notes:29]
[same as prior period, unchanged from 0001408710-21-000047:notes:25]

[0001408710-22-000018:notes:30]
|  | Three Months Ended |  | Six Months Ended |
| (amount in thousands except per share amounts) | December 24,2021 |  | December 25,2020 |  | December 24,2021 |  | December 25,2020 |
| Net income attributable to shareholders | $ | 48,879 |  |  | $ | 35,384 |  |  | $ | 93,530 |  |  | $ | 68,435 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) | 37,017 |  |  | 36,936 |  |  | 36,947 |  |  | 36,877 |  |
| Incremental shares arising from the assumed vesting of restricted share units and performance share units (thousands of shares) | 535 |  |  | 615 |  |  | 493 |  |  | 590 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) | 37,552 |  |  | 37,551 |  |  | 37,440 |  |  | 37,467 |  |
| Basic earnings per ordinary share | $ | 1.32 |  |  | $ | 0.96 |  |  | $ | 2.53 |  |  | $ | 1.86 |  |
| Diluted earnings per ordinary share | $ | 1.30 |  |  | $ | 0.94 |  |  | $ | 2.50 |  |  | $ | 1.83 |  |
| Outstanding performance share units excluded from the computation of diluted earnings per ordinary share (thousands of shares)(1) | — |  |  | 91 |  |  | — |  |  | 91 |  |

[0001408710-22-000018:notes:31]
[same as prior period, unchanged from 0001408710-21-000047:notes:27]


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001408710-22-000018:notes:32]
[same as prior period, unchanged from 0001408710-21-000047:notes:28]

[0001408710-22-000018:notes:33]
|  |  |  | Fair Value |
| (amount in thousands) | CarryingCost |  | UnrealizedGain/(Loss) |  | Cash andCashEquivalents |  | MarketableSecurities |  | OtherInvestments |
| As of December 24, 2021 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 235,561 |  |  | $ | — |  |  | $ | 235,561 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 40,970 |  |  | — |  |  | 40,970 |  |  | — |  |  | — |  |
| Liquidity funds | 31,329 |  |  | — |  |  | — |  |  | — |  |  | 31,329 |  |
| Corporate debt securities | 193,822 |  |  | (822) |  |  | — |  |  | 193,000 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 19,038 |  |  | (28) |  |  | — |  |  | 19,010 |  |  | — |  |
| Total | $ | 520,720 |  |  | $ | (850) |  |  | $ | 276,531 |  |  | $ | 212,010 |  |  | $ | 31,329 |  |
| As of June 25, 2021 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 222,664 |  |  | $ | — |  |  | $ | 222,664 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 80,305 |  |  | — |  |  | 80,305 |  |  | — |  |  | — |  |
| Liquidity funds | 30,000 |  |  | 1,226 |  |  | — |  |  | — |  |  | 31,226 |  |
| Certificates of deposit and time deposits | 10,500 |  |  | — |  |  | — |  |  | — |  |  | 10,500 |  |
| Corporate debt securities | 171,626 |  |  | 164 |  |  | — |  |  | 171,790 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 31,301 |  |  | 146 |  |  | — |  |  | 31,447 |  |  | — |  |
| Total | $ | 546,396 |  |  | $ | 1,536 |  |  | $ | 302,969 |  |  | $ | 203,237 |  |  | $ | 41,726 |  |

[0001408710-22-000018:notes:34]
All highly liquid investments with original maturities of three months or less at the date of purchase are classified as cash equivalents. Management determines the appropriate classification of its investments at the time of purchase and reevaluates the designations at each balance sheet date. The Company may sell certain of its short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s short-term investments generally range from three months to three years.

[0001408710-22-000018:notes:35]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of December 24, 2021 and June 25, 2021:

[0001408710-22-000018:notes:36]
|  | December 24, 2021 |  | June 25, 2021 |
| (amount in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 64,111 |  |  | $ | 64,088 |  |  | $ | 30,000 |  |  | $ | 31,226 |  |
| Due between one to five years | 180,078 |  |  | 179,251 |  |  | 202,927 |  |  | 203,237 |  |
| Total | $ | 244,189 |  |  | $ | 243,339 |  |  | $ | 232,927 |  |  | $ | 234,463 |  |

[0001408710-22-000018:notes:37]
As of December 24, 2021, the Company considered the decline in market value of its available-for-sale debt securities by using the AFS debt security impairment model. The Company typically invests in highly-rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy requires investments generally to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. The Company assesses impairment at the individual security level according to applicable accounting standards by comparing fair value/market value with amortized cost. The Company considered factors such as the failure of the issuer of the security to make scheduled interest and principal payments and any changes to the credit rating of the security by a rating agency. The credit ratings of the Company's invested securities are still in compliance with the Company's investment policy. No impairment losses on available-for-sale debt securities were recorded for the three months ended December 24, 2021.

[0001408710-22-000018:notes:38]
The following table summarizes the carrying cost of short-term investments classified as held-to-maturity securities based on stated effective maturities as of December 24, 2021 and June 25, 2021:

[0001408710-22-000018:notes:39]
| (amount in thousands) | As of December 24, 2021 |  | As of June 25, 2021 |
| Due within one year | $ | — |  | (1) | $ | 10,500 |  |
| Due between one to five years | — |  |  | — |  |
| Total | $ | — |  |  | $ | 10,500 |  |

[0001408710-22-000018:notes:40]
[same as prior period, unchanged from 0001408710-21-000047:notes:37]


## us-gaap:FairValueDisclosuresTextBlock

[0001408710-22-000018:notes:41]
[same as prior period, unchanged from 0001408710-21-000047:notes:38]

[0001408710-22-000018:notes:42]
[same as prior period, unchanged from 0001408710-21-000047:notes:39]

[0001408710-22-000018:notes:43]
[same as prior period, unchanged from 0001408710-21-000047:notes:40]

[0001408710-22-000018:notes:44]
[same as prior period, unchanged from 0001408710-21-000047:notes:41]

[0001408710-22-000018:notes:45]
[same as prior period, unchanged from 0001408710-21-000047:notes:42]

[0001408710-22-000018:notes:46]
[same as prior period, unchanged from 0001408710-21-000047:notes:43]

[0001408710-22-000018:notes:47]
|  | Fair Value Measurements at Reporting Date Using |
| (amount in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of December 24, 2021 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 40,970 |  |  |  | $ | — |  |  | $ | 40,970 |  |
| Liquidity funds | — |  |  | 31,329 |  |  |  | — |  |  | 31,329 |  |
| Corporate debt securities | — |  |  | 193,000 |  |  |  | — |  |  | 193,000 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 19,010 |  |  |  | — |  |  | 19,010 |  |
| Derivative assets – current portion | — |  |  | 177 |  | (1) |  | — |  |  | 177 |  |
| Total | $ | — |  |  | $ | 284,486 |  |  |  | $ | — |  |  | $ | 284,486 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | (4,206) |  |  |  | $ | — |  |  | $ | (4,206) |  |
| Derivative liabilities – non-current portion | — |  |  | (1,055) |  |  |  | — |  |  | (1,055) |  |
| Total | $ | — |  |  | $ | (5,261) |  | (2) |  | $ | — |  |  | $ | (5,261) |  |

[0001408710-22-000018:notes:48]
|  | Fair Value Measurements at Reporting Date Using |
| (amount in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of June 25, 2021 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 80,305 |  |  |  | $ | — |  |  | $ | 80,305 |  |
| Liquidity funds | — |  |  | 31,226 |  |  |  | — |  |  | 31,226 |  |
| Corporate debt securities | — |  |  | 171,790 |  |  |  | — |  |  | 171,790 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 31,447 |  |  |  | — |  |  | 31,447 |  |
| Derivative assets – current portion | — |  |  | 1 |  | (3) |  | — |  |  | 1 |  |
| Total | $ | — |  |  | $ | 314,769 |  |  |  | $ | — |  |  | $ | 314,769 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | 5,654 |  |  |  | $ | — |  |  | $ | 5,654 |  |
| Derivative liabilities – non-current portion | — |  |  | 1,977 |  |  |  | — |  |  | 1,977 |  |
| Total | $ | — |  |  | $ | 7,631 |  | (4) |  | $ | — |  |  | $ | 7,631 |  |

[0001408710-22-000018:notes:49]
(1)Foreign currency forward contracts with a notional amount of $27.0 million.

[0001408710-22-000018:notes:50]
(2)Foreign currency forward contracts with a notional amount of $108.0 million and of 0.4 million Canadian dollars and two interest rate swap agreements with an aggregate notional amount of $125.1 million.

[0001408710-22-000018:notes:51]
(3)Foreign currency forward contracts with an aggregate notional amount of $2.0 million.

[0001408710-22-000018:notes:52]
(4)Foreign currency forward contracts with an aggregate notional amount of $128.0 million and of 0.4 million Canadian dollars and two interest rate swap agreements with an aggregate notional amount of $125.1 million.

[0001408710-22-000018:notes:53]
[same as prior period, unchanged from 0001408710-21-000047:notes:49]

[0001408710-22-000018:notes:54]
[same as prior period, unchanged from 0001408710-21-000047:notes:50]

[0001408710-22-000018:notes:55]
[same as prior period, unchanged from 0001408710-21-000047:notes:51]

[0001408710-22-000018:notes:56]
[same as prior period, unchanged from 0001408710-21-000047:notes:52]

[0001408710-22-000018:notes:57]
[same as prior period, unchanged from 0001408710-21-000047:notes:53]

[0001408710-22-000018:notes:58]
The Company may enter into foreign currency forward contracts with maturities of up to 12 months to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht, including inventory purchases, payroll and other operating expenses. The Company considers these forward contracts as dual-purpose hedges, that hedge the foreign exchange fluctuation (i) from inception through the forecasted expenditure, and (ii) any subsequent revaluation of the account payable or accrual. The Company may designate the forward contracts that hedge the foreign exchange fluctuation from inception through the forecasted expenditure as cash flow hedges. The gain or loss on a derivative instrument designated and qualified as a cash flow hedging instrument is recorded as a component of other comprehensive income and reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings. The reclassified amounts are presented in the same income statement line item as the earnings effect of the hedged item. Once the forecasted transactions are recorded, the Company will discontinue the hedging relationship by de-designating the derivative instrument and recording subsequent changes in fair value through contract maturity to foreign exchange gain (loss), net in the consolidated statements of operations and comprehensive income as a natural hedge against the Thai baht denominated assets and liabilities.

[0001408710-22-000018:notes:59]
The Company may also enter into non-designated foreign currency forward and option contracts to provide an offset to the re-measurement of foreign currency denominated assets and liabilities and to hedge certain forecasted exposures.

[0001408710-22-000018:notes:60]
Changes in the fair value of these non-designated derivatives are recorded as foreign exchange gain (loss), net in the consolidated statements of operations and comprehensive income.

[0001408710-22-000018:notes:61]
As of December 24, 2021, the Company had 135 outstanding U.S. dollar foreign currency forward contracts against Thai baht, with an aggregate notional amount of $135.0 million and maturity dates ranging from January 2022 through July 2022 and one outstanding Canadian dollar foreign currency forward contract with an aggregate notional amount of 0.4 million Canadian dollars and a maturity date in March 2022.

[0001408710-22-000018:notes:62]
[same as prior period, unchanged from 0001408710-21-000047:notes:57]

[0001408710-22-000018:notes:63]
As of December 24, 2021, the hedging relationship over foreign currency forward contracts that were designated for hedge accounting was determined to be highly effective based on the performance of retrospective and prospective regression testing. As of December 24, 2021, the amount in accumulated other comprehensive income (“AOCI”) that is expected to be reclassified into earnings within 12 months was a loss of $1.1 million.

[0001408710-22-000018:notes:64]
[same as prior period, unchanged from 0001408710-21-000047:notes:59]

[0001408710-22-000018:notes:65]
During the three and six months ended December 24, 2021, the Company recorded an unrealized gain of $1.1 million and $0.5 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting, in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-22-000018:notes:66]
During the three and six months ended December 25, 2020, the Company recorded an unrealized gain of $1.8 million and $0.3 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting, in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-22-000018:notes:67]
[same as prior period, unchanged from 0001408710-21-000047:notes:62]

[0001408710-22-000018:notes:68]
The Company entered into interest rate swap agreements to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. As of December 24, 2021 and June 25, 2021, the Company had two outstanding interest rate swap agreements with an aggregate notional amount of $125.1 million.

[0001408710-22-000018:notes:69]
On July 25, 2018, Fabrinet Thailand entered into an interest rate swap agreement to effectively convert the floating interest rate of its term loan under a credit facility agreement with Bank of America to a fixed interest rate of 2.86% per annum through the scheduled maturity of the term loan in June 2023 (see Note 10). The Company did not designate this interest rate swap for hedge accounting.

[0001408710-22-000018:notes:70]
On September 3, 2019, the Company entered into a new term loan agreement under a credit facility agreement with the Bank of Ayudhya Public Company Limited (the “Bank”) (see Note 10) and on September 10, 2019, the Company repaid in full the outstanding term loan under the Bank of America credit facility agreement (see Note 10). In conjunction with the funding of the new term loan, the Company entered into a second interest rate swap agreement. The combination of both of these interest rate swaps effectively converts the floating interest rate of the Company’s new term loan with the Bank to a fixed interest rate of 4.36% per annum through the maturity of the term loan in June 2024.

[0001408710-22-000018:notes:71]
On September 27, 2019, the Company designated these two interest rate swaps as a cash flow hedge for the Company’s term loan under the credit facility agreement with the Bank. The combination of these two interest rate swaps qualified for hedge accounting because the hedges are highly effective, and the Company has designated and documented contemporaneously the hedging relationships involving these interest rate swaps. While the Company intends to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in earnings. From September 27, 2019, any gains or losses related to these interest rate swaps will be recorded in AOCI in the unaudited condensed consolidated balance sheets. The Company will reclassify a portion of the gains or losses from AOCI into earnings at each reporting period based on either the accrued interest amount or the interest payment.

[0001408710-22-000018:notes:72]
As of December 24, 2021, the amount in AOCI that is expected to be reclassified into earnings within 12 months was a loss of $0.9 million.

[0001408710-22-000018:notes:73]
As of June 25, 2021, the amount in AOCI that is expected to be reclassified into earnings within 12 months was a loss of $0.8 million.

[0001408710-22-000018:notes:74]
[same as prior period, unchanged from 0001408710-21-000047:notes:69]

[0001408710-22-000018:notes:75]
|  |  |  | Three Months Ended |  | Six Months Ended |
| (amount in thousands) | Financialstatementsline item |  | December 24,2021 |  | December 25,2020 |  | December 24,2021 |  | December 25,2020 |
| Derivatives gain (loss)recognized in othercomprehensive income (loss): |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Othercomprehensiveincome |  | $ | 3,685 |  |  | $ | 3,149 |  |  | $ | 1,549 |  |  | $ | 809 |  |
| Interest rate swaps | Othercomprehensiveincome |  | 595 |  |  | 386 |  |  | 1,003 |  |  | 743 |  |
| Total derivatives gain (loss) recognized in other comprehensive income (loss) |  |  | $ | 4,280 |  |  | $ | 3,535 |  |  | $ | 2,552 |  |  | $ | 1,552 |  |
| Derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings: |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Cost of revenues |  | $ | 2,984 |  |  | $ | 337 |  |  | $ | 5,099 |  |  | $ | (1,720) |  |
| Foreign currency forward contracts | SG&A |  | 124 |  |  | 14 |  |  | 212 |  |  | (73) |  |
| Foreign currency forward contracts | Foreign exchange loss, net |  | (3,849) |  |  | (1,165) |  |  | (5,273) |  |  | 113 |  |
| Interest rate swaps | Interest expense |  | (245) |  |  | (336) |  |  | (513) |  |  | (695) |  |
| Total derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings |  |  | $ | (986) |  |  | $ | (1,150) |  |  | $ | (475) |  |  | $ | (2,375) |  |
| Change in net unrealized gain (loss) on derivatives instruments |  |  | $ | 3,294 |  |  | $ | 2,385 |  |  | $ | 2,077 |  |  | $ | (823) |  |

[0001408710-22-000018:notes:76]
[same as prior period, unchanged from 0001408710-21-000047:notes:71]

[0001408710-22-000018:notes:77]
[same as prior period, unchanged from 0001408710-21-000047:notes:72]

[0001408710-22-000018:notes:78]
|  | December 24,2021 |  | June 25,2021 |
| (amount in thousands) | DerivativeAssets |  | DerivativeLiabilities |  | DerivativeAssets |  | DerivativeLiabilities |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts | $ | — |  |  | $ | (1,425) |  |  | $ | — |  |  | $ | (1,379) |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward contracts | 177 |  |  | (1,290) |  |  | 1 |  |  | (2,703) |  |
| Interest rate swaps | — |  |  | (2,546) |  |  | — |  |  | (3,549) |  |
| Derivatives, gross balances | $ | 177 |  |  | $ | (5,261) |  |  | $ | 1 |  |  | $ | (7,631) |  |

[0001408710-22-000018:notes:79]
[same as prior period, unchanged from 0001408710-21-000047:notes:74]

[0001408710-22-000018:notes:80]
[same as prior period, unchanged from 0001408710-21-000047:notes:75]


## us-gaap:InventoryDisclosureTextBlock

[0001408710-22-000018:notes:81]
[same as prior period, unchanged from 0001408710-21-000047:notes:76]

[0001408710-22-000018:notes:82]
| (amount in thousands) | As of December 24,2021 |  | As of June 25,2021 |
| Raw materials | $ | 236,915 |  |  | $ | 196,345 |  |
| Work in progress | 198,496 |  |  | 174,654 |  |
| Finished goods | 16,237 |  |  | 15,471 |  |
| Goods in transit | 33,225 |  |  | 35,663 |  |
| Inventories | $ | 484,873 |  |  | $ | 422,133 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001408710-22-000018:notes:83]
Leases
The Company leases facilities under non-cancelable operating lease agreements. The Company leases a portion of its capital equipment and vehicles, certain land and buildings for its facilities in Thailand, the Cayman Islands, the PRC, the U.S., the U.K., Israel and Singapore under operating lease arrangements that expire at various dates through 2025. Certain of these lease arrangements provide the Company the ability to extend the lease from one to five years following the expiration of the current term. However, the Company has excluded all lease extension options from its right of use (“ROU”) assets and lease liabilities as the Company is not reasonably assured that it will exercise these options. None of the lease agreements contain residual value guarantees provided by the lessee. The Company also has one intercompany lease transaction in the form of a lease of office and manufacturing space.

[0001408710-22-000018:notes:84]
[same as prior period, unchanged from 0001408710-21-000047:notes:80]

[0001408710-22-000018:notes:85]
As of December 24, 2021, the maturities of the Company’s operating lease liabilities were as follows:

[0001408710-22-000018:notes:86]
| (amount in thousands) |  |  |
| 2022 (remaining six months) | $ | 1,391 |  |  |
| 2023 | 2,702 |  |  |
| 2024 | 1,267 |  |  |
| 2025 | 42 |  |  |
| Total undiscounted lease payments | 5,402 |  |  |
| Less imputed interest | (190) |  |  |
| Total present value of lease liabilities | $ | 5,212 |  | (1) |

[0001408710-22-000018:notes:87]
(1)Included current portion of operating lease liabilities of $2.6 million.

[0001408710-22-000018:notes:88]
Rental expense related to the Company’s operating leases is recognized on a straight-line basis over the lease term. Rental expense for long-term leases for the three and six months ended December 24, 2021 was $0.7 million and $1.4 million, respectively, and for the three and six months ended December 25, 2020 was $0.6 million and $1.2 million, respectively. Rental expense for short-term leases for the three and six months ended December 24, 2021 was $0.1 million for both periods, and for the three and six months ended December 25, 2020 was $0.1 million and $0.2 million, respectively.

[0001408710-22-000018:notes:89]
[same as prior period, unchanged from 0001408710-21-000047:notes:86]

[0001408710-22-000018:notes:90]
|  | As ofDecember 24, 2021 |  | As ofJune 25, 2021 |
| Weighted-average remaining lease term (in years) | 2.2 |  | 2.7 |
| Weighted-average discount rate | 3.4 | % |  | 3.5 | % |

[0001408710-22-000018:notes:91]
The following table presents supplemental disclosure for the unaudited condensed consolidated statement of cash flows related to operating and finance leases for the three and six months ended December 24, 2021 and December 25, 2020:

[0001408710-22-000018:notes:92]
|  | Three Months Ended |  | Six Months Ended |
| (amount in thousands) | December 24,2021 |  | December 25,2020 |  | December 24,2021 |  | December 25,2020 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |
| Operating cash flows from operating leases | $ | 709 |  |  | $ | 667 |  |  | $ | 1,398 |  |  | $ | 1,261 |  |
| Financing cash flows from finance leases | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 100 |  |
| ROU assets obtained in exchange for lease liabilities | $ | — |  |  | $ | 306 |  |  | $ | 38 |  |  | $ | 370 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001408710-22-000018:notes:93]
[same as prior period, unchanged from 0001408710-21-000047:notes:90]

[0001408710-22-000018:notes:94]
| (amount in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  | ForeignCurrencyTranslationAdjustment |  | Net |
| As of December 24, 2021 |  |  |  |  |  |  |  |
| Software | $ | 10,067 |  |  | $ | (7,157) |  |  | $ | — |  |  | $ | 2,910 |  |
| Customer relationships | 4,373 |  |  | (3,414) |  |  | 9 |  |  | 968 |  |
| Backlog | 119 |  |  | (119) |  |  | — |  |  | — |  |
| Total intangibles | $ | 14,559 |  |  | $ | (10,690) |  |  | $ | 9 |  |  | $ | 3,878 |  |

[0001408710-22-000018:notes:95]
[same as prior period, unchanged from 0001408710-21-000047:notes:92]

[0001408710-22-000018:notes:96]
The Company recorded amortization expense relating to intangibles of $0.4 million and $0.5 million for the three months ended December 24, 2021 and December 25, 2020, respectively, and $0.8 million and $0.7 million for the six months ended December 24, 2021 and December 25, 2020, respectively.

[0001408710-22-000018:notes:97]
[same as prior period, unchanged from 0001408710-21-000047:notes:94]

[0001408710-22-000018:notes:98]
| (years) | As ofDecember 24, 2021 |  | As ofJune 25, 2021 |
| Customer relationships | 3.5 |  | 3.9 |

[0001408710-22-000018:notes:99]
Based on the carrying amount of intangibles as of December 24, 2021, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001408710-22-000018:notes:100]
| (amount in thousands) |  |
| 2022 (remaining six months) | $ | 779 |  |
| 2023 | 1,236 |  |
| 2024 | 995 |  |
| 2025 | 508 |  |
| 2026 | 349 |  |
| Thereafter | 11 |  |
| Total | $ | 3,878 |  |


## us-gaap:DebtDisclosureTextBlock

[0001408710-22-000018:notes:101]
Borrowings 
The Company’s total borrowings, including current and non-current portions of long-term borrowings, consisted of the following:

[0001408710-22-000018:notes:102]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofDecember 24, 2021 |  | As ofJune 25, 2021 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 33,515 |  |  | $ | 39,609 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  | (48) |  |  | (63) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 21,279 |  |  | $ | 27,358 |  |

[0001408710-22-000018:notes:103]
(1)We have entered into interest rate swaps that effectively fix a series of our future interest payments on our term loans. Refer to Note 6.

[0001408710-22-000018:notes:104]
The movements of long-term borrowings for the six months ended December 24, 2021 and December 25, 2020 were as follows:

[0001408710-22-000018:notes:105]
|  | Six Months Ended |
| (amount in thousands) | December 24,2021 |  | December 25,2020 |
| Opening balance | $ | 39,609 |  |  | $ | 51,797 |  |
| Borrowings during the period | — |  |  | — |  |
| Repayments during the period | (6,094) |  |  | (6,094) |  |
| Closing balance | $ | 33,515 |  |  | $ | 45,703 |  |

[0001408710-22-000018:notes:106]
As of December 24, 2021, future maturities of long-term borrowings during each fiscal year were as follows:

[0001408710-22-000018:notes:107]
| (amount in thousands) |  |
| 2022 (remaining six months) | $ | 6,094 |  |
| 2023 | 15,234 |  |
| 2024 | 9,140 |  |
| 2025 | 3,047 |  |
| Total | $ | 33,515 |  |

[0001408710-22-000018:notes:108]
Credit facility agreements:

[0001408710-22-000018:notes:109]
Bank of Ayudhya Public Company Limited

[0001408710-22-000018:notes:110]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a credit facility agreement (the “Credit Facility Agreement”), which provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million that may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

[0001408710-22-000018:notes:111]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a term loan agreement (the "Term Loan Agreement") pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company’s previous syndicated senior credit facility agreement.

[0001408710-22-000018:notes:112]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three and six months ended December 24, 2021, the Company recorded $0.6 million and $1.1 million, respectively, of interest expense in connection with this term loan, including impact from interest rate swaps. During the three and six months ended December 24, 2021, $0.1 million and $0.4 million, respectively, of these interest expenses were capitalized in a new manufacturing building at our Chonburi campus.

[0001408710-22-000018:notes:113]
Any borrowings under the Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

[0001408710-22-000018:notes:114]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of December 24, 2021, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

[0001408710-22-000018:notes:115]
The events of default under the Term Loan Agreement include failure to timely pay amounts due under the Term Loan Agreement or the related finance documents, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

[0001408710-22-000018:notes:116]
As of December 24, 2021, there was $33.5 million outstanding under the term loan.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001408710-22-000018:notes:117]
Income taxes
As of December 24, 2021 and June 25, 2021, the liability for uncertain tax positions including accrued interest and penalties was $1.3 million and $0.9 million, respectively. The Company expects the estimated amount of liability associated with its uncertain tax positions to increase within the next 12 months due to additional provisions on uncertain tax positions from one of its subsidiaries and interest on these positions.

[0001408710-22-000018:notes:118]
The Company files income tax returns in the United States and foreign tax jurisdictions. The tax years from 2015 to 2021 remain open to examination by U.S. federal and state, and foreign tax authorities. The Company’s income tax is recognized based on the best estimate of the expected annual effective tax rate for the full financial year of each entity in the Company, adjusted for discrete items arising in that quarter. If the Company’s estimated annual effective tax rate changes, the Company makes a cumulative adjustment in that quarter.

[0001408710-22-000018:notes:119]
The effective tax rate for the Company for the three months ended December 24, 2021 and December 25, 2020 was 2.4% and 2.6%, respectively, of net income. The decrease was primarily due to the fact that the Company had more income not subject to tax during the second quarter of fiscal year 2022 as compared to the same period in fiscal year 2021.

[0001408710-22-000018:notes:120]
The effective tax rate for the Company for the six months ended December 24, 2021 and December 25, 2020 was 1.9% and 3.7%, respectively, of net income. The decrease was primarily due to the fact that the Company had more income not subject to tax during the first six months of fiscal year 2022 as compared to the same period in fiscal year 2021.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001408710-22-000018:notes:121]
[same as prior period, unchanged from 0001408710-21-000047:notes:118]

[0001408710-22-000018:notes:122]
[same as prior period, unchanged from 0001408710-21-000047:notes:119]

[0001408710-22-000018:notes:123]
The effect of recording share-based compensation expense for the three and six months ended December 24, 2021 and December 25, 2020 was as follows:

[0001408710-22-000018:notes:124]
|  | Three Months Ended |  | Six Months Ended |
| (amount in thousands) | December 24,2021 |  | December 25,2020 |  | December 24,2021 |  | December 25,2020 |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |
| Restricted share units | $ | 3,671 |  |  | $ | 4,175 |  |  | $ | 8,595 |  |  | $ | 9,424 |  |
| Performance share units | 3,015 |  |  | 1,676 |  |  | 7,383 |  |  | 2,454 |  |
| Total share-based compensation expense | 6,686 |  |  | 5,851 |  |  | 15,978 |  |  | 11,878 |  |
| Tax effect on share-based compensation expense | — |  |  | — |  |  | — |  |  | — |  |
| Net effect on share-based compensation expense | $ | 6,686 |  |  | $ | 5,851 |  |  | $ | 15,978 |  |  | $ | 11,878 |  |

[0001408710-22-000018:notes:125]
[same as prior period, unchanged from 0001408710-21-000047:notes:122]

[0001408710-22-000018:notes:126]
|  | Three Months Ended |  | Six Months Ended |
| (amount in thousands) | December 24,2021 |  | December 25,2020 |  | December 24,2021 |  | December 25,2020 |
| Cost of revenue | $ | 1,421 |  |  | $ | 1,592 |  |  | $ | 3,396 |  |  | $ | 3,417 |  |
| Selling, general and administrative expense | 5,265 |  |  | 4,259 |  |  | 12,582 |  |  | 8,461 |  |
| Total share-based compensation expense | $ | 6,686 |  |  | $ | 5,851 |  |  | $ | 15,978 |  |  | $ | 11,878 |  |

[0001408710-22-000018:notes:127]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the three and six months ended December 24, 2021 and December 25, 2020.

[0001408710-22-000018:notes:128]
[same as prior period, unchanged from 0001408710-21-000047:notes:125]

[0001408710-22-000018:notes:129]
[same as prior period, unchanged from 0001408710-21-000047:notes:126]

[0001408710-22-000018:notes:130]
As of December 24, 2021, there were 323,164 restricted share units outstanding, 295,550 performance share units outstanding and 2,242,349 ordinary shares available for future grant under the 2020 Plan.

[0001408710-22-000018:notes:131]
As of December 24, 2021, there were 171,943 restricted share units outstanding under the 2010 Plan. No ordinary shares are available for future grant under the 2010 Plan.

[0001408710-22-000018:notes:132]
On November 2, 2017, the Company adopted the 2017 Inducement Equity Incentive Plan (the “2017 Inducement Plan”) with a reserve of 160,000 ordinary shares authorized for future issuance solely for the granting of inducement share options and equity awards to new employees. The 2017 Inducement Plan was adopted without shareholder approval in reliance on the “employment inducement exemption” provided under the New York Stock Exchange Listed Company Manual. As of December 24, 2021, there were 12,164 restricted share units outstanding and 111,347 ordinary shares available for future grant under the 2017 Inducement Plan.

[0001408710-22-000018:notes:133]
[same as prior period, unchanged from 0001408710-21-000047:notes:130]

[0001408710-22-000018:notes:134]
[same as prior period, unchanged from 0001408710-21-000047:notes:131]

[0001408710-22-000018:notes:135]
[same as prior period, unchanged from 0001408710-21-000047:notes:132]

[0001408710-22-000018:notes:136]
[same as prior period, unchanged from 0001408710-21-000047:notes:133]

[0001408710-22-000018:notes:137]
[same as prior period, unchanged from 0001408710-21-000047:notes:134]

[0001408710-22-000018:notes:138]
[same as prior period, unchanged from 0001408710-21-000047:notes:135]

[0001408710-22-000018:notes:139]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 25, 2021 | 641,875 |  |  | $ | 55.74 |  |
| Granted | 154,893 |  |  | $ | 102.70 |  |
| Issued | (271,396) |  |  | $ | 50.74 |  |
| Forfeited | (18,101) |  |  | $ | 68.49 |  |
| Balance as of December 24, 2021 | 507,271 |  |  | $ | 72.29 |  |

[0001408710-22-000018:notes:140]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 26, 2020 | 797,757 |  |  | $ | 46.88 |  |
| Granted | 216,776 |  |  | $ | 69.48 |  |
| Issued | (292,874) |  |  | $ | 43.75 |  |
| Forfeited | (13,997) |  |  | $ | 54.23 |  |
| Balance as of December 25, 2020 | 707,662 |  |  | $ | 54.95 |  |

[0001408710-22-000018:notes:141]
[same as prior period, unchanged from 0001408710-21-000047:notes:138]

[0001408710-22-000018:notes:142]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 25, 2021 | 427,028 |  |  | $ | 57.82 |  |
| Granted | 110,832 |  |  | $ | 101.05 |  |
| Issued | (190,213) |  |  | $ | 48.65 |  |
| Forfeited | (52,097) |  |  | $ | 48.65 |  |
| Balance as of December 24, 2021 | 295,550 |  |  | $ | 81.55 |  |

[0001408710-22-000018:notes:143]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 26, 2020 | 440,140 |  |  | $ | 48.37 |  |
| Granted | 184,718 |  |  | $ | 69.85 |  |
| Issued | (82,185) |  |  | 48.02 |  |
| Forfeited | (115,645) |  |  | $ | 48.02 |  |
| Balance as of December 25, 2020 | 427,028 |  |  | $ | 57.82 |  |

[0001408710-22-000018:notes:144]
The fair value of restricted share units and performance share units is based on the market value of the Company's ordinary shares on the date of grant.

[0001408710-22-000018:notes:145]
As of December 24, 2021, there was $16.7 million and $12.6 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.5 and 1.3, respectively.

[0001408710-22-000018:notes:146]
For the six months ended December 24, 2021 and December 25, 2020, the Company withheld an aggregate of 201,658 shares and 148,958 shares, respectively, upon the vesting of restricted share units, based upon the closing share price on the vesting date to settle employee obligations for the applicable income and other employment taxes. For the six months ended December 24, 2021 and December 25, 2020, the Company then remitted cash of $19.5 million and $10.4 million, respectively, to the appropriate taxing authorities, and presented it as a financing activity within the unaudited condensed consolidated statements of cash flows. The payment was recorded as a reduction of additional paid-in capital.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001408710-22-000018:notes:147]
[same as prior period, unchanged from 0001408710-21-000047:notes:144]

[0001408710-22-000018:notes:148]
[same as prior period, unchanged from 0001408710-21-000047:notes:145]

[0001408710-22-000018:notes:149]
For the three and six months ended December 24, 2021, Fabrinet issued 8,153 and 259,951 ordinary shares, respectively, upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-22-000018:notes:150]
For the three and six months ended December 25, 2020, Fabrinet issued 17,409 and 226,101 ordinary shares, respectively, upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-22-000018:notes:151]
[same as prior period, unchanged from 0001408710-21-000047:notes:148]

[0001408710-22-000018:notes:152]
[same as prior period, unchanged from 0001408710-21-000047:notes:149]

[0001408710-22-000018:notes:153]
In August 2017, the Company’s board of directors approved a share repurchase program to permit the Company to repurchase up to $30.0 million worth of its issued and outstanding ordinary shares in the open market in accordance with applicable rules and regulations. In February 2018, May 2019 and August 2020, the Company’s board of directors approved an increase of $30.0 million, $50.0 million and $58.5 million, respectively, to the original share repurchase authorization, bringing the aggregate authorization to $168.5 million. During the three and six months ended December 24, 2021, the Company repurchased 38,269 shares under the program at an average price per share (excluding other direct costs) of $115.82, totaling $4.4 million. As of December 24, 2021, the Company had a remaining authorization to repurchase up to an additional $76.7 million worth of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001408710-22-000018:notes:154]
Accumulated other comprehensive income (loss)
The changes in AOCI for the six months ended December 24, 2021 and December 25, 2020 were as follows:

[0001408710-22-000018:notes:155]
| (amount in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 25, 2021 | $ | 308 |  |  | $ | (4,504) |  |  | $ | (1,425) |  |  | $ | (645) |  |  | $ | (6,266) |  |
| Other comprehensive income before reclassification adjustment | (1,173) |  |  | 2,552 |  |  | — |  |  | (164) |  |  | 1,215 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | 13 |  |  | (475) |  |  | 324 |  |  | — |  |  | (138) |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | $ | (1,160) |  |  | $ | 2,077 |  |  | $ | 324 |  |  | $ | (164) |  |  | $ | 1,077 |  |
| Balance as of December 24, 2021 | $ | (852) |  |  | $ | (2,427) |  |  | $ | (1,101) |  |  | $ | (809) |  |  | $ | (5,189) |  |

[0001408710-22-000018:notes:156]
| (amount in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 26, 2020 | $ | 1,490 |  |  | $ | 602 |  |  | $ | (2,009) |  |  | $ | (1,230) |  |  | $ | (1,147) |  |
| Other comprehensive income before reclassification adjustment | (289) |  |  | 1,552 |  |  | — |  |  | 457 |  |  | 1,720 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | (78) |  |  | (2,375) |  |  | 223 |  |  | — |  |  | (2,230) |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | $ | (367) |  |  | $ | (823) |  |  | $ | 223 |  |  | $ | 457 |  |  | $ | (510) |  |
| Balance as of December 25, 2020 | $ | 1,123 |  |  | $ | (221) |  |  | $ | (1,786) |  |  | $ | (773) |  |  | $ | (1,657) |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001408710-22-000018:notes:157]
Commitments and contingencies
Bank guarantees

[0001408710-22-000018:notes:158]
As of December 24, 2021 and June 25, 2021, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling to $1.5 million and $1.6 million, respectively, or Thai Baht 50.2 million. As of December 24, 2021 and June 25, 2021, the Company had an outstanding bank guarantee on behalf of its subsidiary in the PRC to support the subsidiary's operations totaling Renminbi 2.0 million and Renminbi 1.0 million, respectively, which bank guarantee was backed by cash collateral of $0.3 million and $0.2 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in the U.K. to support its operations.

[0001408710-22-000018:notes:159]
Purchase obligations

[0001408710-22-000018:notes:160]
Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001408710-22-000018:notes:161]
As of December 24, 2021, the Company had a purchase obligation and other commitments to third parties of $1,301.7 million.

[0001408710-22-000018:notes:162]
Capital expenditures

[0001408710-22-000018:notes:163]
In December 2020, the Company entered into a construction contract with a local contractor for construction of a new manufacturing building at the Company’s Chonburi campus. The contract price is approximately $50.3 million.

[0001408710-22-000018:notes:164]
In June 2021, the Company entered into an agreement to purchase a parcel of land in Pathumthani, Thailand to expand the Company's Pinehurst campus. The aggregate purchase price was approximately $13.2 million or Thai Baht 418.8 million, which was paid in two installments: (1) a 10% deposit on May 14, 2021; and (2) the remainder on June 29, 2021.

[0001408710-22-000018:notes:165]
As of December 24, 2021, the Company had total capital expenditure commitments to third parties of $19.9 million, comprised of the construction contract of the new manufacturing building at Chonburi campus of $2.9 million and other commitments of $17.0 million.

[0001408710-22-000018:notes:166]
Indemnification of directors and officers

[0001408710-22-000018:notes:167]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001408710-22-000018:notes:168]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001408710-22-000018:notes:169]
Business segments and geographic information
Operating segments are defined as components of an enterprise for which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. The Company’s chief operating decision maker is Fabrinet’s Chief Executive Officer. As of December 24, 2021, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001408710-22-000018:notes:170]
[same as prior period, unchanged from 0001408710-21-000047:notes:168]

[0001408710-22-000018:notes:171]
[same as prior period, unchanged from 0001408710-21-000047:notes:169]

[0001408710-22-000018:notes:172]
| (amount in thousands) |  | December 24,2021 |  | June 25,2021 |
| Long-Lived Assets: |  |  |  |  |
| Thailand |  | $ | 238,668 |  |  | $ | 190,843 |  |
| U.S. |  | 26,421 |  |  | 27,403 |  |
| China |  | 18,746 |  |  | 14,977 |  |
| Israel |  | 4,622 |  |  | 5,271 |  |
| U.K. |  | 1,666 |  |  | 2,223 |  |
| Cayman Island |  | 560 |  |  | 412 |  |
|  |  | $ | 290,683 |  |  | $ | 241,129 |  |

[0001408710-22-000018:notes:173]
[same as prior period, unchanged from 0001408710-21-000047:notes:171]

[0001408710-22-000018:notes:174]
The Company had two and three customers that each contributed to 10% or more of the Company's total trade accounts receivable as of December 24, 2021 and June 25, 2021, respectively.
