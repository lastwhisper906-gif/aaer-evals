# FN note change history — 0001408710-21-000047 → 0001408710-22-000018


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2022-02-01):
[0001408710-22-000018:note_history:1]
As of December 24, 2021 and June 25, 2021, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling to $1.5 million and $1.6 million, respectively, or Thai Baht 50.2 million. As of December 24, 2021 and June 25, 2021, the Company had an outstanding bank guarantee on behalf of its subsidiary in the PRC to support the subsidiary's operations totaling Renminbi 2.0 million and Renminbi 1.0 million, respectively, which bank guarantee was backed by cash collateral of $0.3 million and $0.2 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in the U.K. to support its operations.

- changed (2022-02-01):
[0001408710-22-000018:note_history:2]
As of December 24, 2021, the Company had a purchase obligation and other commitments to third parties of $1,301.7 million.
  (was, 2021-11-02, similarity 0.9774):
[0001408710-21-000047:note_history:2]
As of September 24, 2021, the Company had a purchase obligation and other commitments to third parties of $992.8 million.

- changed (2022-02-01):
[0001408710-22-000018:note_history:3]
Capital expenditures
  (was, 2021-11-02, similarity 0.9744):
[0001408710-21-000047:note_history:3]
Capital expenditure

- changed (2022-02-01):
[0001408710-22-000018:note_history:4]
As of December 24, 2021, the Company had total capital expenditure commitments to third parties of $19.9 million, comprised of the construction contract of the new manufacturing building at Chonburi campus of $2.9 million and other commitments of $17.0 million.
  (was, 2021-11-02, similarity 0.9776):
[0001408710-21-000047:note_history:4]
As of September 24, 2021, the Company had total capital expenditure commitments to third parties of $31.0 million, comprised of the construction contract of new manufacturing building at Chonburi campus of $20.1 million and other commitments of $10.9 million.

- removed (2022-02-01):
[0001408710-21-000047:note_history:5]
As of September 24, 2021 and June 25, 2021, there were outstanding bank guarantees on behalf of our subsidiary in Thailand for electricity usage and other normal business expenses totaling to $1.5 million and $1.6 million, respectively, or Thai Baht 50.2 million. As of September 24, 2021 and June 25, 2021, the Company had an outstanding bank guarantee of its subsidiary in the PRC to support the subsidiary's operations totaling Renminbi 1.0 million, which was backed by cash collateral of $0.2 million. In addition, there were other immaterial bank guarantees on behalf of our subsidiary in the U.K. to support its operations.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-02-01):
[0001408710-22-000018:note_history:6]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of December 24, 2021 and for the three and six months ended December 24, 2021 and December 25, 2020 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 25, 2021.
  (was, 2021-11-02, similarity 0.9665):
[0001408710-21-000047:note_history:6]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of September 24, 2021 and for the three months ended September 24, 2021 and September 25, 2020 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 25, 2021.

- changed (2022-02-01):
[0001408710-22-000018:note_history:7]
The results for the three and six months ended December 24, 2021 may not be indicative of results for the year ending June 24, 2022 or any future periods.
  (was, 2021-11-02, similarity 0.9537):
[0001408710-21-000047:note_history:7]
The results for the three months ended September 24, 2021 may not be indicative of results for the year ending June 24, 2022 or any future periods.

- changed (2022-02-01):
[0001408710-22-000018:note_history:8]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information. Additionally, the extent to which the evolving COVID-19 pandemic impacts the Company’s unaudited condensed consolidated financial statements will depend on a number of factors, including the magnitude and duration of the pandemic. These estimates may change as new events occur and additional information is obtained, as well as based upon the occurrence of other factors related to the COVID-19 pandemic that could result in material impacts to the Company's unaudited condensed consolidated financial statements in future reporting periods.
  (was, 2021-11-02, similarity 0.9982):
[0001408710-21-000047:note_history:8]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information. Additionally, the extent to which the evolving COVID-19 pandemic impacts the Company’s unaudited condensed consolidated financial statements will depend on a number of factors, including the magnitude and duration of the pandemic. These estimates may change, as new events occur and additional information is obtained, as well as upon the occurrence of other factors related to the COVID-19 pandemic that could result in material impacts to the Company's unaudited condensed consolidated financial statements in future reporting periods.

- changed (2022-02-01):
[0001408710-22-000018:note_history:9]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  December 24, 2021 and December 25, 2020 each consisted of 13 weeks. The six months ended December 24, 2021 and December 25, 2020 each consisted of 26 weeks. Fiscal year 2022 will be comprised of 52 weeks and will end on June 24, 2022.
  (was, 2021-11-02, similarity 0.7374):
[0001408710-21-000047:note_history:9]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended September 24, 2021 and September 25, 2020 each consisted of 13 weeks. Fiscal year 2022 will be comprised of 52 weeks and will end on June 24, 2022.

- added (2022-02-01):
[0001408710-22-000018:note_history:10]
New Accounting Pronouncements – not yet adopted by the Company

- added (2022-02-01):
[0001408710-22-000018:note_history:11]
In November 2021, the Financial Accounting Standards Board issued ASU 2021-10, “Government Assistance (Topic 832), Disclosures by Business Entities about Government Assistance,” which requires annual disclosures that increase the transparency of transactions involving government assistance, including (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The amendments in this update are effective for all entities within the ASU's scope for financial statements issued for annual periods beginning after December 15, 2021. This ASU will be effective for the Company in the first quarter of fiscal year 2023. Early adoption is permitted.  The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-01):
[0001408710-22-000018:note_history:12]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofDecember 24, 2021 |  | As ofJune 25, 2021 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 33,515 |  |  | $ | 39,609 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  | (48) |  |  | (63) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 21,279 |  |  | $ | 27,358 |  |
  (was, 2021-11-02, similarity 0.9953):
[0001408710-21-000047:note_history:12]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofSeptember 24, 2021 |  | As ofJune 25, 2021 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterlyinstallments |  | June 2024 |  | $ | 36,562 |  |  | $ | 39,609 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  | (55) |  |  | (63) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 24,319 |  |  | $ | 27,358 |  |

- changed (2022-02-01):
[0001408710-22-000018:note_history:13]
The movements of long-term borrowings for the six months ended December 24, 2021 and December 25, 2020 were as follows:
  (was, 2021-11-02, similarity 0.9189):
[0001408710-21-000047:note_history:13]
The movements of long-term borrowings for the three months ended September 24, 2021 and September 25, 2020 were as follows:

- changed (2022-02-01):
[0001408710-22-000018:note_history:14]
|  | Six Months Ended |
| (amount in thousands) | December 24,2021 |  | December 25,2020 |
| Opening balance | $ | 39,609 |  |  | $ | 51,797 |  |
| Borrowings during the period | — |  |  | — |  |
| Repayments during the period | (6,094) |  |  | (6,094) |  |
| Closing balance | $ | 33,515 |  |  | $ | 45,703 |  |
  (was, 2021-11-02, similarity 0.9115):
[0001408710-21-000047:note_history:14]
|  | Three Months Ended |
| (amount in thousands) | September 24,2021 |  | September 25,2020 |
| Opening balance | $ | 39,609 |  |  | $ | 51,797 |  |
| Borrowings during the period | — |  |  | — |  |
| Repayments during the period | (3,047) |  |  | (3,047) |  |
| Closing balance | $ | 36,562 |  |  | $ | 48,750 |  |

- changed (2022-02-01):
[0001408710-22-000018:note_history:15]
As of December 24, 2021, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2021-11-02, similarity 0.9754):
[0001408710-21-000047:note_history:15]
As of September 24, 2021, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2022-02-01):
[0001408710-22-000018:note_history:16]
| (amount in thousands) |  |
| 2022 (remaining six months) | $ | 6,094 |  |
| 2023 | 15,234 |  |
| 2024 | 9,140 |  |
| 2025 | 3,047 |  |
| Total | $ | 33,515 |  |
  (was, 2021-11-02, similarity 0.9835):
[0001408710-21-000047:note_history:16]
| (amount in thousands) |  |
| 2022 (remaining 9 months) | $ | 9,141 |  |
| 2023 | 15,233 |  |
| 2024 | 9,141 |  |
| 2025 | 3,047 |  |
| Total | $ | 36,562 |  |

- changed (2022-02-01):
[0001408710-22-000018:note_history:17]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a term loan agreement (the "Term Loan Agreement") pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company’s previous syndicated senior credit facility agreement.
  (was, 2021-11-02, similarity 0.6818):
[0001408710-21-000047:note_history:17]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a term loan agreement (the "Term Loan Agreement") pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original

- changed (2022-02-01):
[0001408710-22-000018:note_history:18]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three and six months ended December 24, 2021, the Company recorded $0.6 million and $1.1 million, respectively, of interest expense in connection with this term loan, including impact from interest rate swaps. During the three and six months ended December 24, 2021, $0.1 million and $0.4 million, respectively, of these interest expenses were capitalized in a new manufacturing building at our Chonburi campus.
  (was, 2021-11-02, similarity 0.6386):
[0001408710-21-000047:note_history:18]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three months ended September 24, 2021 and September 25, 2020, the Company recorded $0.3 million and $0.2 million, respectively, of interest expense in connection with this term loan.

- changed (2022-02-01):
[0001408710-22-000018:note_history:19]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of December 24, 2021, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.
  (was, 2021-11-02, similarity 0.9949):
[0001408710-21-000047:note_history:19]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, and restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.5 times. As of September 24, 2021, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

- changed (2022-02-01):
[0001408710-22-000018:note_history:20]
The events of default under the Term Loan Agreement include failure to timely pay amounts due under the Term Loan Agreement or the related finance documents, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.
  (was, 2021-11-02, similarity 0.9847):
[0001408710-21-000047:note_history:20]
The events of default under the Term Loan Agreement include failure to pay amounts due under the Term Loan Agreement or the related finance documents when due, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

- changed (2022-02-01):
[0001408710-22-000018:note_history:21]
As of December 24, 2021, there was $33.5 million outstanding under the term loan.
  (was, 2021-11-02, similarity 0.9655):
[0001408710-21-000047:note_history:21]
As of September 24, 2021, there was $36.6 million outstanding under the term loan.

- removed (2022-02-01):
[0001408710-21-000047:note_history:22]
principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Bank of America credit facility agreement.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-01):
[0001408710-22-000018:note_history:23]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of December 24, 2021 and June 25, 2021:
  (was, 2021-11-02, similarity 0.9829):
[0001408710-21-000047:note_history:23]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of September 24, 2021 and June 25, 2021:

- changed (2022-02-01):
[0001408710-22-000018:note_history:24]
|  | December 24, 2021 |  | June 25, 2021 |
| (amount in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 64,111 |  |  | $ | 64,088 |  |  | $ | 30,000 |  |  | $ | 31,226 |  |
| Due between one to five years | 180,078 |  |  | 179,251 |  |  | 202,927 |  |  | 203,237 |  |
| Total | $ | 244,189 |  |  | $ | 243,339 |  |  | $ | 232,927 |  |  | $ | 234,463 |  |
  (was, 2021-11-02, similarity 0.9887):
[0001408710-21-000047:note_history:24]
|  | September 24, 2021 |  | June 25, 2021 |
| (amount in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 69,219 |  |  | $ | 69,211 |  |  | $ | 30,000 |  |  | $ | 31,226 |  |
| Due between one to five years | 189,186 |  |  | 189,290 |  |  | 202,927 |  |  | 203,237 |  |
| Total | $ | 258,405 |  |  | $ | 258,501 |  |  | $ | 232,927 |  |  | $ | 234,463 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-01):
[0001408710-22-000018:note_history:25]
The movements of long-term borrowings for the six months ended December 24, 2021 and December 25, 2020 were as follows:
  (was, 2021-11-02, similarity 0.9189):
[0001408710-21-000047:note_history:25]
The movements of long-term borrowings for the three months ended September 24, 2021 and September 25, 2020 were as follows:

- changed (2022-02-01):
[0001408710-22-000018:note_history:26]
|  | Six Months Ended |
| (amount in thousands) | December 24,2021 |  | December 25,2020 |
| Opening balance | $ | 39,609 |  |  | $ | 51,797 |  |
| Borrowings during the period | — |  |  | — |  |
| Repayments during the period | (6,094) |  |  | (6,094) |  |
| Closing balance | $ | 33,515 |  |  | $ | 45,703 |  |
  (was, 2021-11-02, similarity 0.9115):
[0001408710-21-000047:note_history:26]
|  | Three Months Ended |
| (amount in thousands) | September 24,2021 |  | September 25,2020 |
| Opening balance | $ | 39,609 |  |  | $ | 51,797 |  |
| Borrowings during the period | — |  |  | — |  |
| Repayments during the period | (3,047) |  |  | (3,047) |  |
| Closing balance | $ | 36,562 |  |  | $ | 48,750 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-01):
[0001408710-22-000018:note_history:27]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofDecember 24, 2021 |  | As ofJune 25, 2021 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 33,515 |  |  | $ | 39,609 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  | (48) |  |  | (63) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 21,279 |  |  | $ | 27,358 |  |
  (was, 2021-11-02, similarity 0.9953):
[0001408710-21-000047:note_history:27]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofSeptember 24, 2021 |  | As ofJune 25, 2021 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterlyinstallments |  | June 2024 |  | $ | 36,562 |  |  | $ | 39,609 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  | (55) |  |  | (63) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 24,319 |  |  | $ | 27,358 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-02-01):
[0001408710-22-000018:note_history:28]
As of December 24, 2021, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2021-11-02, similarity 0.9754):
[0001408710-21-000047:note_history:28]
As of September 24, 2021, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2022-02-01):
[0001408710-22-000018:note_history:29]
| (amount in thousands) |  |
| 2022 (remaining six months) | $ | 6,094 |  |
| 2023 | 15,234 |  |
| 2024 | 9,140 |  |
| 2025 | 3,047 |  |
| Total | $ | 33,515 |  |
  (was, 2021-11-02, similarity 0.9835):
[0001408710-21-000047:note_history:29]
| (amount in thousands) |  |
| 2022 (remaining 9 months) | $ | 9,141 |  |
| 2023 | 15,233 |  |
| 2024 | 9,141 |  |
| 2025 | 3,047 |  |
| Total | $ | 36,562 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-02-01):
[0001408710-22-000018:note_history:30]
| (amount in thousands, except percentages) | Three Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |  | Six Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 243,720 |  |  |  |  | 488,994 |  |  |  |
| Others (1) | 3,557 |  |  |  |  | 4,873 |  |  |  |
| Total revenue in North America | 247,277 |  |  | 43.6 | % |  | 493,867 |  |  | 44.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 74,121 |  |  |  |  | 139,054 |  |  |  |
| Malaysia | 60,369 |  |  |  |  | 112,118 |  |  |  |
| Hong Kong | 23,206 |  |  |  |  | 44,237 |  |  |  |
| Israel | 22,801 |  |  |  |  | 50,434 |  |  |  |
| Japan | 15,832 |  |  |  |  | 30,809 |  |  |  |
| China | 14,146 |  |  |  |  | 27,781 |  |  |  |
| Others | 11,565 |  |  |  |  | 23,790 |  |  |  |
| Total revenue in Asia-Pacific and others | 222,040 |  |  | 39.2 | % |  | 428,223 |  |  | 38.6 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 54,900 |  |  |  |  | 104,384 |  |  |  |
| U.K. | 22,941 |  |  |  |  | 42,519 |  |  |  |
| Germany | 8,985 |  |  |  |  | 17,410 |  |  |  |
| Others | 10,490 |  |  |  |  | 23,552 |  |  |  |
| Total revenue in Europe | $ | 97,316 |  |  | 17.2 | % |  | $ | 187,865 |  |  | 16.9 | % |
| Total revenue | $ | 566,633 |  |  | 100.0 | % |  | $ | 1,109,955 |  |  | 100.0 | % |
  (was, 2021-11-02, similarity 0.951):
[0001408710-21-000047:note_history:30]
| (amount in thousands, except percentages) | Three Months EndedSeptember 24, 2021 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 25, 2020 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 245,274 |  |  |  |  | 206,950 |  |  |  |
| Others | 1,316 |  |  |  |  | 452 |  |  |  |
| Total revenue in North America | 246,590 |  |  | 45.4 | % |  | 207,402 |  |  | 47.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 64,932 |  |  | (1) |  | 19 |  |  |  |
| Malaysia | 51,749 |  |  |  |  | 43,911 |  |  |  |
| Israel | 27,634 |  |  |  |  | 30,115 |  |  |  |
| Hong Kong | 21,031 |  |  |  |  | 23,505 |  |  |  |
| Japan | 14,977 |  |  |  |  | 20,332 |  |  |  |
| China | 13,635 |  |  |  |  | 13,787 |  |  |  |
| Others | 12,225 |  |  |  |  | 13,977 |  |  |  |
| Total revenue in Asia-Pacific and others | 206,183 |  |  | 37.9 | % |  | 145,646 |  |  | 33.4 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 49,484 |  |  |  |  | 53,611 |  |  |  |
| U.K. | 19,578 |  |  |  |  | 15,311 |  |  |  |
| Germany | 8,425 |  |  |  |  | 5,799 |  |  |  |
| Others | 13,062 |  |  |  |  | 8,870 |  |  |  |
| Total revenue in Europe | $ | 90,549 |  |  | 16.7 | % |  | $ | 83,591 |  |  | 19.1 | % |
| Total revenue | $ | 543,322 |  |  | 100.0 | % |  | $ | 436,639 |  |  | 100.0 | % |

- added (2022-02-01):
[0001408710-22-000018:note_history:31]
| (amount in thousands, except percentages) | Three Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |  | Six Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 224,046 |  |  |  |  | 430,996 |  |  |  |
| Others (1) | 626 |  |  |  |  | 1,078 |  |  |  |
| Total revenue in North America | 224,672 |  |  | 49.5 | % |  | 432,074 |  |  | 48.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Malaysia | 34,546 |  |  |  |  | 80,188 |  |  |  |
| India | 28,865 |  |  |  |  | 28,885 |  |  |  |
| Israel | 27,102 |  |  |  |  | 57,217 |  |  |  |
| Hong Kong | 18,092 |  |  |  |  | 41,598 |  |  |  |
| Japan | 17,309 |  |  |  |  | 37,642 |  |  |  |
| China | 12,563 |  |  |  |  | 26,340 |  |  |  |
| Others | 15,257 |  |  |  |  | 27,510 |  |  |  |
| Total revenue in Asia-Pacific and others | 153,734 |  |  | 33.9 | % |  | 299,380 |  |  | 33.6 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 48,954 |  |  |  |  | 102,730 |  |  |  |
| U.K. | 10,004 |  |  |  |  | 25,315 |  |  |  |
| Germany | 6,253 |  |  |  |  | 12,052 |  |  |  |
| Others | 10,210 |  |  |  |  | 18,915 |  |  |  |
| Total revenue in Europe | $ | 75,421 |  |  | 16.6 | % |  | $ | 159,012 |  |  | 17.9 | % |
| Total revenue | $ | 453,827 |  |  | 100.0 | % |  | $ | 890,466 |  |  | 100.0 | % |

- added (2022-02-01):
[0001408710-22-000018:note_history:32]
(1)Others includes revenues from external customers based in our country of domicile, the Cayman Islands, which for each year presented is $0.

- removed (2022-02-01):
[0001408710-21-000047:note_history:33]
(1)Due to change in bill-to-location for certain customer.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2022-02-01):
[0001408710-22-000018:note_history:34]
Contract Assets and Liabilities

- added (2022-02-01):
[0001408710-22-000018:note_history:35]
A contract asset is recognized when the Company has recognized revenues prior to generating an invoice for payment. Contract assets are classified separately within the unaudited condensed consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional.

- added (2022-02-01):
[0001408710-22-000018:note_history:36]
A contract liability is recognized when the Company has advance payment arrangements with customers. The contract liabilities balance is normally recognized as revenue within six months.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-02-01):
[0001408710-22-000018:note_history:37]
| (amount in thousands, except percentages) | Three Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |  | Six Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 243,720 |  |  |  |  | 488,994 |  |  |  |
| Others (1) | 3,557 |  |  |  |  | 4,873 |  |  |  |
| Total revenue in North America | 247,277 |  |  | 43.6 | % |  | 493,867 |  |  | 44.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 74,121 |  |  |  |  | 139,054 |  |  |  |
| Malaysia | 60,369 |  |  |  |  | 112,118 |  |  |  |
| Hong Kong | 23,206 |  |  |  |  | 44,237 |  |  |  |
| Israel | 22,801 |  |  |  |  | 50,434 |  |  |  |
| Japan | 15,832 |  |  |  |  | 30,809 |  |  |  |
| China | 14,146 |  |  |  |  | 27,781 |  |  |  |
| Others | 11,565 |  |  |  |  | 23,790 |  |  |  |
| Total revenue in Asia-Pacific and others | 222,040 |  |  | 39.2 | % |  | 428,223 |  |  | 38.6 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 54,900 |  |  |  |  | 104,384 |  |  |  |
| U.K. | 22,941 |  |  |  |  | 42,519 |  |  |  |
| Germany | 8,985 |  |  |  |  | 17,410 |  |  |  |
| Others | 10,490 |  |  |  |  | 23,552 |  |  |  |
| Total revenue in Europe | $ | 97,316 |  |  | 17.2 | % |  | $ | 187,865 |  |  | 16.9 | % |
| Total revenue | $ | 566,633 |  |  | 100.0 | % |  | $ | 1,109,955 |  |  | 100.0 | % |
  (was, 2021-11-02, similarity 0.951):
[0001408710-21-000047:note_history:37]
| (amount in thousands, except percentages) | Three Months EndedSeptember 24, 2021 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 25, 2020 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 245,274 |  |  |  |  | 206,950 |  |  |  |
| Others | 1,316 |  |  |  |  | 452 |  |  |  |
| Total revenue in North America | 246,590 |  |  | 45.4 | % |  | 207,402 |  |  | 47.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 64,932 |  |  | (1) |  | 19 |  |  |  |
| Malaysia | 51,749 |  |  |  |  | 43,911 |  |  |  |
| Israel | 27,634 |  |  |  |  | 30,115 |  |  |  |
| Hong Kong | 21,031 |  |  |  |  | 23,505 |  |  |  |
| Japan | 14,977 |  |  |  |  | 20,332 |  |  |  |
| China | 13,635 |  |  |  |  | 13,787 |  |  |  |
| Others | 12,225 |  |  |  |  | 13,977 |  |  |  |
| Total revenue in Asia-Pacific and others | 206,183 |  |  | 37.9 | % |  | 145,646 |  |  | 33.4 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 49,484 |  |  |  |  | 53,611 |  |  |  |
| U.K. | 19,578 |  |  |  |  | 15,311 |  |  |  |
| Germany | 8,425 |  |  |  |  | 5,799 |  |  |  |
| Others | 13,062 |  |  |  |  | 8,870 |  |  |  |
| Total revenue in Europe | $ | 90,549 |  |  | 16.7 | % |  | $ | 83,591 |  |  | 19.1 | % |
| Total revenue | $ | 543,322 |  |  | 100.0 | % |  | $ | 436,639 |  |  | 100.0 | % |

- added (2022-02-01):
[0001408710-22-000018:note_history:38]
| (amount in thousands, except percentages) | Three Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |  | Six Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 224,046 |  |  |  |  | 430,996 |  |  |  |
| Others (1) | 626 |  |  |  |  | 1,078 |  |  |  |
| Total revenue in North America | 224,672 |  |  | 49.5 | % |  | 432,074 |  |  | 48.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Malaysia | 34,546 |  |  |  |  | 80,188 |  |  |  |
| India | 28,865 |  |  |  |  | 28,885 |  |  |  |
| Israel | 27,102 |  |  |  |  | 57,217 |  |  |  |
| Hong Kong | 18,092 |  |  |  |  | 41,598 |  |  |  |
| Japan | 17,309 |  |  |  |  | 37,642 |  |  |  |
| China | 12,563 |  |  |  |  | 26,340 |  |  |  |
| Others | 15,257 |  |  |  |  | 27,510 |  |  |  |
| Total revenue in Asia-Pacific and others | 153,734 |  |  | 33.9 | % |  | 299,380 |  |  | 33.6 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 48,954 |  |  |  |  | 102,730 |  |  |  |
| U.K. | 10,004 |  |  |  |  | 25,315 |  |  |  |
| Germany | 6,253 |  |  |  |  | 12,052 |  |  |  |
| Others | 10,210 |  |  |  |  | 18,915 |  |  |  |
| Total revenue in Europe | $ | 75,421 |  |  | 16.6 | % |  | $ | 159,012 |  |  | 17.9 | % |
| Total revenue | $ | 453,827 |  |  | 100.0 | % |  | $ | 890,466 |  |  | 100.0 | % |

- added (2022-02-01):
[0001408710-22-000018:note_history:39]
(1)Others includes revenues from external customers based in our country of domicile, the Cayman Islands, which for each year presented is $0.

- changed (2022-02-01):
[0001408710-22-000018:note_history:40]
| (amount in thousands, except percentages) | Three Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |  | Six Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |
| Optical communications | $ | 450,783 |  |  | 79.6 | % |  | $ | 878,084 |  |  | 79.1 | % |
| Lasers, sensors and other | 115,850 |  |  | 20.4 | % |  | 231,871 |  |  | 20.9 | % |
| Total | $ | 566,633 |  |  | 100.0 | % |  | $ | 1,109,955 |  |  | 100.0 | % |
  (was, 2021-11-02, similarity 0.774):
[0001408710-21-000047:note_history:40]
| (amount in thousands, except percentages) | Three Months EndedSeptember 24, 2021 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 25, 2020 |  | As a % of TotalRevenues |
| Optical communications | $ | 427,301 |  |  | 78.6 | % |  | $ | 343,917 |  |  | 78.8 | % |
| Lasers, sensors and other | 116,021 |  |  | 21.4 | % |  | 92,722 |  |  | 21.2 | % |
| Total | $ | 543,322 |  |  | 100.0 | % |  | $ | 436,639 |  |  | 100.0 | % |

- added (2022-02-01):
[0001408710-22-000018:note_history:41]
| (amount in thousands, except percentages) | Three Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |  | Six Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |
| Optical communications | $ | 347,840 |  |  | 76.6 | % |  | $ | 691,757 |  |  | 77.7 | % |
| Lasers, sensors and other | 105,987 |  |  | 23.4 | % |  | 198,709 |  |  | 22.3 | % |
| Total | $ | 453,827 |  |  | 100.0 | % |  | $ | 890,466 |  |  | 100.0 | % |

- changed (2022-02-01):
[0001408710-22-000018:note_history:42]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the six months ended December 24, 2021:
  (was, 2021-11-02, similarity 0.955):
[0001408710-21-000047:note_history:42]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the three months ended September 24, 2021:

- changed (2022-02-01):
[0001408710-22-000018:note_history:43]
| (amount in thousands) | ContractAssets |
| Beginning balance, June 25, 2021 | $ | 11,878 |  |
| Revenue recognized | 26,241 |  |
| Amounts collected or invoiced | (24,971) |  |
| Ending balance, December 24, 2021 | $ | 13,148 |  |
  (was, 2021-11-02, similarity 0.9874):
[0001408710-21-000047:note_history:43]
| (amount in thousands) | ContractAssets |
| Beginning balance, June 25, 2021 | $ | 11,878 |  |
| Revenue recognized | 13,197 |  |
| Amounts collected or invoiced | (11,955) |  |
| Ending balance, September 24, 2021 | $ | 13,120 |  |

- changed (2022-02-01):
[0001408710-22-000018:note_history:44]
| (amount in thousands) | ContractLiabilities |
| Beginning balance, June 25, 2021 | $ | 1,680 |  |
| Advance payment received during the period | 3,281 |  |
| Revenue recognized | (3,067) |  |
| Ending balance, December 24, 2021 | $ | 1,894 |  |
  (was, 2021-11-02, similarity 0.9838):
[0001408710-21-000047:note_history:44]
| (amount in thousands) | ContractLiabilities |
| Beginning balance, June 25, 2021 | $ | 1,680 |  |
| Advance payment received during the period | 1,941 |  |
| Revenue recognized | (1,866) |  |
| Ending balance, September 24, 2021 | $ | 1,755 |  |

- removed (2022-02-01):
[0001408710-21-000047:note_history:45]
(1)Due to change in bill-to-location for certain customer.
