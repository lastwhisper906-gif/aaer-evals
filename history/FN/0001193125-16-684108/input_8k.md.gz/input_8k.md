# FN 8-K — 0001193125-16-681934 filed 2016-08-15

## item codes, every 8-K on or before 2016-08-17

- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2016-08-17

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-681934:8k_2_02:1]
EX-99.1
2
d242649dex991.htm
EX-99.1

[0001193125-16-681934:8k_2_02:2]
EX-99.1

[0001193125-16-681934:8k_2_02:3]
Exhibit 99.1

[0001193125-16-681934:8k_2_02:4]
Fabrinet Announces Fourth Quarter and Fiscal-Year 2016 Financial Results

[0001193125-16-681934:8k_2_02:5]
BANGKOK, Thailand – August 15, 2016 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical,
electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its fourth quarter and fiscal year ended June 24, 2016.

[0001193125-16-681934:8k_2_02:6]
Tom Mitchell, Chief Executive Officer of Fabrinet, said, “Strong revenue growth of 34% exceeded our expectations for the fourth quarter. These results
capped a year of significant growth for Fabrinet, which was driven by a combination of momentum in the optical industry, growing contributions from new customers, and increasing demand for our advanced packaging and precision assembly capabilities.
We believe that we are in a strong position to serve the industry’s growth as we scale our Fabrinet West New Product Introduction facility and complete construction of the first building at our new campus in Thailand. As a result of these
factors, we are entering fiscal 2017 with optimism, as reflected in our guidance for the first quarter.”

[0001193125-16-681934:8k_2_02:7]
Fourth Quarter Fiscal-Year 2016
Financial Highlights

[0001193125-16-681934:8k_2_02:8]
GAAP Results

[0001193125-16-681934:8k_2_02:9]
|  | • |  | Revenue was $276.4 million for the fourth quarter of fiscal year 2016, an increase of 34% compared to total revenue of $206.5 million for the comparable period in fiscal year 2015. |

[0001193125-16-681934:8k_2_02:10]
|  | • |  | GAAP net income for the fourth quarter of fiscal year 2016 was $19.7 million, compared to GAAP net income of $13.0 million in the fourth quarter of fiscal year 2015. |

[0001193125-16-681934:8k_2_02:11]
|  | • |  | GAAP net income per diluted share for the fourth quarter of fiscal year 2016 was $0.53, compared to GAAP net income per diluted share of $0.36 in the fourth quarter of fiscal year 2015. |

[0001193125-16-681934:8k_2_02:12]
Non-GAAP Results

[0001193125-16-681934:8k_2_02:13]
|  | • |  | Non-GAAP net income in the fourth quarter of fiscal 2016 was $22.4 million, an increase of 54% compared to non-GAAP net income of $14.5 million in the same period a year ago. |

[0001193125-16-681934:8k_2_02:14]
|  | • |  | Non-GAAP net income per diluted share in the fourth quarter of fiscal 2016 was $0.60, an increase from non-GAAP net income per diluted share of $0.40 in the same period a year ago. |

[0001193125-16-681934:8k_2_02:15]
Fiscal-Year 2016 Financial Highlights

[0001193125-16-681934:8k_2_02:16]
GAAP Results

[0001193125-16-681934:8k_2_02:17]
|  | • |  | Revenue was $976.7 million for fiscal year 2016, an increase of 26% compared to total revenue of $773.6 million for fiscal year 2015. |

[0001193125-16-681934:8k_2_02:18]
|  | • |  | GAAP net income for fiscal year 2016 was $61.9 million, compared to GAAP net income of $43.6 million in fiscal year 2015. |

[0001193125-16-681934:8k_2_02:19]
|  | • |  | GAAP net income per diluted share for fiscal year 2016 was $1.68, compared to GAAP net income per diluted share of $1.21 in fiscal year 2015. |

[0001193125-16-681934:8k_2_02:20]
Non-GAAP Results

[0001193125-16-681934:8k_2_02:21]
|  | • |  | Non-GAAP net income in fiscal 2016 was $77.7 million, an increase of 38% compared to non-GAAP net income of $56.4 million in fiscal year 2015. |

[0001193125-16-681934:8k_2_02:22]
|  | • |  | Non-GAAP net income per diluted share in fiscal 2016 was $2.11, an increase from non-GAAP net income per diluted share of $1.57 in fiscal year 2015. |

[0001193125-16-681934:8k_2_02:23]
Business Outlook

[0001193125-16-681934:8k_2_02:24]
Based on information available as of August 15, 2016, Fabrinet is issuing guidance for the first quarter of fiscal 2017 ending September 30, 2016, as follows:

[0001193125-16-681934:8k_2_02:25]
|  | • |  | Fabrinet expects first quarter revenue to be in the range of $306 million to $310 million. |

[0001193125-16-681934:8k_2_02:26]
|  | • |  | GAAP net income per diluted share is expected to be in the range of $0.62 to $0.64, based on approximately 37.6 million fully diluted shares outstanding. |

[0001193125-16-681934:8k_2_02:27]
|  | • |  | Non-GAAP net income per diluted share is expected to be in the range of $0.70 to $0.72, based on approximately 37.6 million fully diluted shares outstanding. |

[0001193125-16-681934:8k_2_02:28]
Conference Call Information

[0001193125-16-681934:8k_2_02:29]
| What: |  | Fabrinet Fourth Quarter and Fiscal-Year 2016 Financial Results Conference Call |
| When: |  | Monday, August 15, 2016 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic |
|  |  | (253) 237-1137, international |
|  |  | Passcode: 53883033 |
| Replay: |  | (855) 859-2056, domestic |
|  |  | (404) 537-3406, international |
|  |  | Passcode: 53883033 |
| Webcast: |  | http://investor.fabrinet.com (live and replay) |

[0001193125-16-681934:8k_2_02:30]
This press release and any other information related to the call will also be posted on Fabrinet’s website at
http:// investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-16-681934:8k_2_02:31]
About Fabrinet

[0001193125-16-681934:8k_2_02:32]
Fabrinet is a leading provider of
advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, industrial lasers
and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging,
integration, final assembly and test. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the People’s Republic of China
and the United States of America. For more information visit: www.fabrinet.com.

[0001193125-16-681934:8k_2_02:33]
Forward-Looking Statements

[0001193125-16-681934:8k_2_02:34]
competition in the optical manufacturing services markets; difficulties in delivering products and services that compete effectively from a price and performance perspective; our reliance on a
small number of customers and suppliers; difficulties in managing our operating costs; difficulties in managing and operating our business across multiple countries (including the U.S., Thailand and the People’s Republic of China); delays in
construction of our new manufacturing building in Thailand; and other important factors as described in reports and documents we file from time to time with the Securities and Exchange Commission (SEC), including the factors described under the
section captioned “Risk Factors” in our Quarterly Report on Form 10-Q, filed on May 3, 2016. We disclaim any obligation to update information contained in these forward-looking statements whether as a result of new information, future
events, or otherwise.

[0001193125-16-681934:8k_2_02:35]
Use of Non-GAAP Financials

[0001193125-16-681934:8k_2_02:36]
The Company refers to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information
regarding the Company’s ongoing operational performance. Non-GAAP net income excludes share-based compensation expenses, executive separation costs, investigation costs, income related to flooding, expenses related to reduction in workforce,
amortization of debt issuance costs, unrealized gain or loss on foreign currency and one time cost resulting from a non-recurring warranty charge. We have excluded these items in order to enhance investors’ understanding of our underlying
operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material
limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001193125-16-681934:8k_2_02:37]
These non-GAAP financial measures are used to: (1)
measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision
making. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001193125-16-681934:8k_2_02:38]
SOURCE: Fabrinet

[0001193125-16-681934:8k_2_02:39]
Investor Contact:

[0001193125-16-681934:8k_2_02:40]
Garo Toomajanian

[0001193125-16-681934:8k_2_02:41]
ir@fabrinet.com

[0001193125-16-681934:8k_2_02:42]
FABRINET

[0001193125-16-681934:8k_2_02:43]
CONSOLIDATED BALANCE SHEETS

[0001193125-16-681934:8k_2_02:44]
| (in thousands of U.S. dollars, except share data) |  | As ofJune 24,2016 |  |  | As ofJune 26,2015 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 142,804 |  |  | $ | 112,978 |  |
| Marketable securities |  |  | 141,709 |  |  |  | 142,866 |  |
| Trade accounts receivable, net |  |  | 196,145 |  |  |  | 134,952 |  |
| Inventory, net |  |  | 181,499 |  |  |  | 130,613 |  |
| Deferred tax assets |  |  | 1,358 |  |  |  | 1,662 |  |
| Prepaid expenses |  |  | 3,114 |  |  |  | 2,135 |  |
| Other current assets |  |  | 6,662 |  |  |  | 1,833 |  |
| Total current assets |  |  | 673,291 |  |  |  | 527,039 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 178,410 |  |  |  | 140,654 |  |
| Intangibles, net |  |  | 499 |  |  |  | 137 |  |
| Deferred tax assets |  |  | 1,806 |  |  |  | 2,249 |  |
| Deferred debt issuance costs |  |  | 2,444 |  |  |  | 2,424 |  |
| Total non-current assets |  |  | 183,159 |  |  |  | 145,464 |  |
| Total assets |  | $ | 856,450 |  |  | $ | 672,503 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Bank borrowings, including revolving loan and current portion of long-term loans from banks |  | $ | 24,600 |  |  | $ | 36,000 |  |
| Trade accounts payable |  |  | 172,052 |  |  |  | 115,319 |  |
| Fixed assets related payable |  |  | 20,628 |  |  |  | 6,026 |  |
| Income tax payable |  |  | 2,010 |  |  |  | 1,470 |  |
| Accrued payroll, bonus and related expenses |  |  | 12,300 |  |  |  | 9,804 |  |
| Accrued expenses |  |  | 8,072 |  |  |  | 6,405 |  |
| Other payables |  |  | 16,356 |  |  |  | 6,024 |  |
| Total current liabilities |  |  | 256,018 |  |  |  | 181,048 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term loan from bank, non-current portion |  |  | 36,400 |  |  |  | 4,500 |  |
| Deferred tax liability |  |  | 854 |  |  |  | 737 |  |
| Severance liabilities |  |  | 6,684 |  |  |  | 5,477 |  |
| Other non-current liabilities |  |  | 2,075 |  |  |  | 1,797 |  |
| Total non-current liabilities |  |  | 46,013 |  |  |  | 12,511 |  |
| Total liabilities |  |  | 302,031 |  |  |  | 193,559 |  |
| Commitments and contingencies (Note 17) |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of June 24, 2016 and June 26, 2015) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 36,156,446 share and 35,437,654 shares issued and outstanding as of June 24, 2016 and June 26, 2015, respectively) |  |  | 362 |  |  |  | 354 |  |
| Additional paid-in capital |  |  | 102,325 |  |  |  | 89,390 |  |
| Accumulated other comprehensive income (loss) |  |  | 591 |  |  |  | (44 | ) |
| Retained earnings |  |  | 451,141 |  |  |  | 389,244 |  |
| Total shareholders’ equity |  |  | 554,419 |  |  |  | 478,944 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 856,450 |  |  | $ | 672,503 |  |

[0001193125-16-681934:8k_2_02:45]
4

[0001193125-16-681934:8k_2_02:46]
FABRINET

[0001193125-16-681934:8k_2_02:47]
CONSOLIDATED STATEMENT OF OPERATIONS AND COMPREHENSIVE INCOME

[0001193125-16-681934:8k_2_02:48]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | June 24, |  |  | June 26, |  |  | June 24, |  |  | June 26, |  |
| (in thousands of U.S. dollars) |  | 2016 |  |  | 2015 |  |  | 2016 |  |  | 2015 |  |
| Revenues |  | $ | 276,388 |  |  | $ | 206,456 |  |  | $ | 976,747 |  |  | $ | 773,587 |  |
| Cost of revenues |  |  | (242,546 | ) |  |  | (181,907 | ) |  |  | (857,224 | ) |  |  | (685,814 | ) |
| Gross profit |  |  | 33,842 |  |  |  | 24,549 |  |  |  | 119,523 |  |  |  | 87,773 |  |
| Selling, general and administrative expenses |  |  | (11,839 | ) |  |  | (10,739 | ) |  |  | (49,753 | ) |  |  | (39,460 | ) |
| Income related to flooding |  |  | — |  |  |  | — |  |  |  | 36 |  |  |  | — |  |
| Expenses related to reduction in workforce |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,153 | ) |
| Operating income |  |  | 22,003 |  |  |  | 13,810 |  |  |  | 69,806 |  |  |  | 47,160 |  |
| Interest income |  |  | 425 |  |  |  | 297 |  |  |  | 1,535 |  |  |  | 1,253 |  |
| Interest expense |  |  | (413 | ) |  |  | (241 | ) |  |  | (1,569 | ) |  |  | (616 | ) |
| Foreign exchange (loss) gain, net |  |  | (670 | ) |  |  | 91 |  |  |  | (1,916 | ) |  |  | (19 | ) |
| Other income |  |  | 110 |  |  |  | (46 | ) |  |  | 376 |  |  |  | (152 | ) |
| Income before income taxes |  |  | 21,455 |  |  |  | 13,911 |  |  |  | 68,232 |  |  |  | 47,626 |  |
| Income taxes |  |  | (1,786 | ) |  |  | (876 | ) |  |  | (6,335 | ) |  |  | (3,984 | ) |
| Net income |  |  | 19,669 |  |  |  | 13,035 |  |  |  | 61,897 |  |  |  | 43,642 |  |
| Other comprehensive (loss) income |  |  | (156 | ) |  |  | (70 | ) |  |  | 635 |  |  |  | (44 | ) |
| Net other comprehensive income |  | $ | 19,513 |  |  | $ | 12,965 |  |  | $ | 62,532 |  |  | $ | 43,598 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.55 |  |  | $ | 0.37 |  |  | $ | 1.73 |  |  | $ | 1.23 |  |
| Diluted |  | $ | 0.53 |  |  | $ | 0.36 |  |  | $ | 1.68 |  |  | $ | 1.21 |  |
| Weighted average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 36,075 |  |  |  | 35,431 |  |  |  | 35,857 |  |  |  | 35,354 |  |
| Diluted |  |  | 37,259 |  |  |  | 36,320 |  |  |  | 36,872 |  |  |  | 35,984 |  |

[0001193125-16-681934:8k_2_02:49]
5

[0001193125-16-681934:8k_2_02:50]
FABRINET

[0001193125-16-681934:8k_2_02:51]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-16-681934:8k_2_02:52]
|  |  | Twelve Months Ended |  |
| (in thousands of U. S. dollars) |  | June 24,2016 |  |  | June 26,2015 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income for the year |  | $ | 61,897 |  |  | $ | 43,642 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 17,357 |  |  |  | 12,947 |  |
| Gain on disposal of property, plant and equipment |  |  | (73 | ) |  |  | (42 | ) |
| Loss from sales and maturities of marketable securities |  |  | 194 |  |  |  | 120 |  |
| Amortization of investment premium |  |  | 798 |  |  |  | 985 |  |
| Amortization of deferred debt issuance costs |  |  | 758 |  |  |  | 527 |  |
| Income related to flooding |  |  | (828 | ) |  |  | — |  |
| Proceeds from insurers in settlement of claim related to flood damage |  |  | 272 |  |  |  | — |  |
| (Reversal of) allowance for doubtful accounts |  |  | (17 | ) |  |  | 13 |  |
| Unrealized loss on exchange rate and fair value of derivative |  |  | 1,905 |  |  |  | 671 |  |
| Share-based compensation |  |  | 9,927 |  |  |  | 8,027 |  |
| Deferred income tax |  |  | 864 |  |  |  | (878 | ) |
| Other non-cash expenses |  |  | 1,744 |  |  |  | 1,722 |  |
| Reversal of uncertain tax positions |  |  | — |  |  |  | — |  |
| (Reversal of) inventory obsolescence |  |  | (521 | ) |  |  | 397 |  |
| Loss from written-off inventory due to flood loss |  |  | 233 |  |  |  | — |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | (61,013 | ) |  |  | (33,797 | ) |
| Inventory |  |  | (50,598 | ) |  |  | (6,440 | ) |
| Other current assets and non-current assets |  |  | (5,901 | ) |  |  | (283 | ) |
| Trade accounts payable |  |  | 56,308 |  |  |  | 20,466 |  |
| Income tax payable |  |  | 573 |  |  |  | 446 |  |
| Other current liabilities and non-current liabilities |  |  | 13,209 |  |  |  | 4,106 |  |
| Liabilities to third parties due to flood losses |  |  | — |  |  |  | — |  |
| Net cash provided by operating activities |  |  | 47,088 |  |  |  | 52,629 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of marketable securities |  |  | (108,341 | ) |  |  | (203,407 | ) |
| Proceeds from sales of marketable securities |  |  | 41,836 |  |  |  | 29,036 |  |
| Proceeds from maturities of marketable securities |  |  | 67,113 |  |  |  | 30,356 |  |
| Purchase of property, plant and equipment |  |  | (40,616 | ) |  |  | (51,398 | ) |
| Gain on cash settlement of hedged forward contracts |  |  | 34 |  |  |  | — |  |
| Proceeds from disposal of property, plant and equipment |  |  | 194 |  |  |  | 48 |  |
| Purchase of intangibles |  |  | (379 | ) |  |  | (134 | ) |
| Proceeds from insurers in settlement of claims related to flood damage |  |  | 556 |  |  |  | — |  |
| Net cash used in investing activities |  |  | (39,603 | ) |  |  | (195,499 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Payment of debt issuance costs |  |  | (654 | ) |  |  | (1,946 | ) |
| Proceeds of short-term loan from bank |  |  | 18,000 |  |  |  | 30,000 |  |
| Repayment of short-term loan from bank |  |  | (41,500 | ) |  |  | — |  |
| Proceed of long-term loan from bank |  |  | 50,000 |  |  |  | — |  |
| Repayment of long-term loan from bank |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Proceeds from issuance of ordinary shares under employee share option plan |  |  | 5,479 |  |  |  | 835 |  |
| Withholding tax related to net share settlement of restricted share units |  |  | (2,463 | ) |  |  | (352 | ) |
| Net cash provided by financing activities |  |  | 22,862 |  |  |  | 22,537 |  |
| Net increase (decrease) in cash and cash equivalents |  | $ | 30,347 |  |  | $ | (120,333 | ) |
| Movement in cash and cash equivalents |  |  |  |  |  |  |  |  |
| Cash and cash equivalents at beginning of period |  | $ | 112,978 |  |  | $ | 233,477 |  |
| Increase (decrease) in cash and cash equivalents |  |  | 30,347 |  |  |  | (120,333 | ) |
| Effect of exchange rate on cash and cash equivalents |  |  | (521 | ) |  |  | (166 | ) |
| Cash and cash equivalents at end of period |  | $ | 142,804 |  |  | $ | 112,978 |  |

[0001193125-16-681934:8k_2_02:53]
Fabrinet

[0001193125-16-681934:8k_2_02:54]
Reconciliation of GAAP measures to non-GAAP measures

[0001193125-16-681934:8k_2_02:55]
| (in thousands of U.S. dollars, except per share data) |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  | June 24, 2016 |  |  | June 26, 2015 |  |  | June 24, 2016 |  |  | June 26, 2015 |  |
|  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |
| GAAP measures |  |  | 19,669 |  |  |  | 0.53 |  |  |  | 13,035 |  |  |  | 0.36 |  |  |  | 61,897 |  |  |  | 1.68 |  |  |  | 43,642 |  |  |  | 1.21 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 385 |  |  |  | 0.01 |  |  |  | 344 |  |  |  | 0.01 |  |  |  | 1,979 |  |  |  | 0.05 |  |  |  | 1,451 |  |  |  | 0.04 |  |
| Cost resulting from a non-recurring warranty charge |  |  | 1,000 |  |  |  | 0.03 |  |  |  | — |  |  |  | — |  |  |  | 1,000 |  |  |  | 0.03 |  |  |  | — |  |  |  | — |  |
| Total related to gross profit |  |  | 1,385 |  |  |  | 0.04 |  |  |  | 344 |  |  |  | 0.01 |  |  |  | 2,979 |  |  |  | 0.08 |  |  |  | 1,451 |  |  |  | 0.04 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,760 |  |  |  | 0.05 |  |  |  | 1,878 |  |  |  | 0.05 |  |  |  | 7,948 |  |  |  | 0.21 |  |  |  | 6,577 |  |  |  | 0.18 |  |
| Executive separation cost |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,360 |  |  |  | 0.04 |  |  |  | — |  |  |  | — |  |
| Investigation cost |  |  | — |  |  |  | — |  |  |  | (858 | ) |  |  | (0.02 | ) |  |  | — |  |  |  | — |  |  |  | 3,242 |  |  |  | 0.09 |  |
| Total related to selling, general and administrative expenses |  |  | 1,760 |  |  |  | 0.05 |  |  |  | 1,020 |  |  |  | 0.03 |  |  |  | 9,308 |  |  |  | 0.25 |  |  |  | 9,819 |  |  |  | 0.27 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income related to flooding |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (36 | ) |  |  | (0.00 | ) |  |  | — |  |  |  | — |  |
| Expenses related to reduction in workforce |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,153 |  |  |  | 0.03 |  |
| Amortization of debt issuance costs |  |  | 203 |  |  |  | 0.01 |  |  |  | 150 |  |  |  | 0.00 |  |  |  | 745 |  |  |  | 0.02 |  |  |  | 527 |  |  |  | 0.02 |  |
| (Gain) loss on foreign currency |  |  | (581 | ) |  |  | (0.02 | ) |  |  | — |  |  |  | — |  |  |  | 1,715 |  |  |  | 0.05 |  |  |  | — |  |  |  | — |  |
| Total related to other incomes and other expenses |  |  | (378 | ) |  |  | (0.01 | ) |  |  | 150 |  |  |  | 0.00 |  |  |  | 2,424 |  |  |  | 0.07 |  |  |  | 1,680 |  |  |  | 0.05 |  |
| Related to income tax expense (benefit): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense (benefit) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,119 |  |  |  | 0.03 |  |  |  | (187 | ) |  |  | (0.01 | ) |
| Total related to income tax expense (benefit) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,119 |  |  |  | 0.03 |  |  |  | (187 | ) |  |  | (0.01 | ) |
| Total related to net income & EPS |  |  | 2,767 |  |  |  | 0.07 |  |  |  | 1,514 |  |  |  | 0.04 |  |  |  | 15,830 |  |  |  | 0.43 |  |  |  | 12,763 |  |  |  | 0.35 |  |
| Non-GAAP measures |  |  | 22,436 |  |  |  | 0.60 |  |  |  | 14,549 |  |  |  | 0.40 |  |  |  | 77,727 |  |  |  | 2.11 |  |  |  | 56,405 |  |  |  | 1.57 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 37,258 |  |  |  |  |  |  |  | 36,320 |  |  |  |  |  |  |  | 36,872 |  |  |  |  |  |  |  | 35,984 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 37,258 |  |  |  |  |  |  |  | 36,320 |  |  |  |  |  |  |  | 36,872 |  |  |  |  |  |  |  | 35,984 |  |

[0001193125-16-681934:8k_2_02:56]
7

[0001193125-16-681934:8k_2_02:57]
Fabrinet Guidance for Quarter Ending September 30, 2016

[0001193125-16-681934:8k_2_02:58]
Items reconciling GAAP EPS to non-GAAP EPS:

[0001193125-16-681934:8k_2_02:59]
|  |  | DilutedEPS |  |
| GAAP net income per diluted share: |  | $ | 0.62 to $0.64 |  |
| Related to cost of revenues: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.03 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |
| Expenses related to M&A activities |  |  | 0.00 |  |
| Executive separation cost |  |  | 0.02 |  |
| Share-based compensation expenses |  |  | 0.07 |  |
|  |  |  | 0.09 |  |
| Related to other incomes and other expenses: |  |  |  |  |
| Amortization of debt issuance costs |  |  | 0.01 |  |
| (Gain)/loss on foreign currency |  |  | (0.05) |  |
| Total related to other incomes and other expenses |  |  | (0.04) |  |
| Total related to net income & EPS |  |  | 0.08 |  |
| Non-GAAP net income per diluted share |  | $ | 0.70 to $0.72 |  |

[0001193125-16-681934:8k_2_02:60]
8
