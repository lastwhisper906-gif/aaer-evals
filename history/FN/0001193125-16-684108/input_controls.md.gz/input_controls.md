# FN 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001193125-16-684108:item_9a:1]
| ITEM 9A. | CONTROLS AND PROCEDURES. |

[0001193125-16-684108:item_9a:2]
Evaluation
of Disclosure Controls and Procedures

[0001193125-16-684108:item_9a:3]
Our management, with the participation of our Chief Executive Officer
(“CEO”) and Chief Financial Officer (“CFO”), evaluated the effectiveness of our disclosure controls and procedures (as defined in Rule 13a-15(e) and 15d-15(e) of the Securities Exchange Act of 1934, as amended (“Exchange
Act”)), as of the end of the period covered by this Annual Report on Form 10-K. Based on their evaluation, our management concluded that our disclosure controls and procedures were effective to provide reasonable assurance that the information
we are required to disclose in reports we file or submit under the Exchange Act, (i) is recorded, processed, summarized and reported within the time periods specified in the rules and forms of the U.S. Securities and Exchange Commission, and
(ii) is accumulated and communicated to Fabrinet’s management, including our CEO and CFO, as appropriate, to allow timely decisions regarding required disclosure.

[0001193125-16-684108:item_9a:4]
Changes in Internal Control over Financial Reporting

[0001193125-16-684108:item_9a:5]
There were no changes
in our internal control over financial reporting that occurred during the quarter ended June 24, 2016, that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001193125-16-684108:item_9a:6]
Management’s Annual Report on Internal Control over Financial Reporting

[0001193125-16-684108:item_9a:7]
Management is responsible for establishing and maintaining adequate internal control over financial reporting of the Company as defined in
Rule 13a-15(f) and 15d-15(f) under the Exchange Act. Internal control

[0001193125-16-684108:item_9a:8]
94

[0001193125-16-684108:item_9a:9]
over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes
in accordance with U.S. generally accepted accounting principles.

[0001193125-16-684108:item_9a:10]
Our internal control over financial reporting includes
those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately, and fairly reflect the transactions and dispositions of the assets of the Company; (ii) provide reasonable assurance that
transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the Company are being made only in accordance with authorizations
of management and directors of the Company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the Company’s assets that could have a material effect on the
financial statements.

[0001193125-16-684108:item_9a:11]
Because of its inherent limitations, internal control over financial reporting may not prevent or
detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or
procedures may deteriorate. Management has assessed the effectiveness of our internal control over financial reporting as of June 24, 2016. In making this assessment, management used the criteria described in Internal Control—Integrated
Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (“COSO”).

[0001193125-16-684108:item_9a:12]
Based on their assessment, management concluded that we maintained effective internal control over financial reporting as of the end of
fiscal year 2016, based on the criteria in Internal Control—Integrated Framework (2013) issued by COSO. The effectiveness of our internal control over financial reporting as of June 24, 2016 has been audited by PricewaterhouseCoopers
ABAS Ltd., an independent registered public accounting firm, as stated in their report which appears herein.
