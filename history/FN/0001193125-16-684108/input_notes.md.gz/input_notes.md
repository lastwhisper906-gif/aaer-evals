# FN notes — 0001193125-16-684108


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-16-684108:notes:1]
The following
 table summarizes the cost and estimated fair value of marketable
 securities classified as available-for-sale securities based on
 stated effective maturities as of June 24, 2016:

[0001193125-16-684108:notes:2]
| (amount in thousands) |  | Carrying Cost |  |  | Fair Value |  |
| Due within one year |  | $ | 19,609 |  |  | $ | 19,628 |  |
| Due between one to three years |  |  | 121,701 |  |  |  | 122,081 |  |
| Total |  | $ | 141,310 |  |  | $ | 141,709 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001193125-16-684108:notes:3]
Cash and
 cash equivalents

[0001193125-16-684108:notes:4]
All highly
 liquid investments with original maturities of three months or less
 at the date of purchase are classified as cash equivalents. Cash
 and cash equivalents consist of cash deposited in checking
 accounts, time deposits with maturities of less than three months,
 money market accounts, and marketable securities with maturities of
 three months or less at the date of purchase.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-16-684108:notes:5]
| 17. | Commitments and contingencies |

[0001193125-16-684108:notes:6]
Bank
 guarantees

[0001193125-16-684108:notes:7]
As of
 June 24, 2016 and June 26, 2015, there were outstanding
 bank guarantees given by bank on behalf of our subsidiary in
 Thailand for electricity usage and other normal business amounting
 to $0.8 million.

[0001193125-16-684108:notes:8]
Operating
 lease commitments

[0001193125-16-684108:notes:9]
The Company
 leases a portion of its capital equipment, vehicle, and certain
 land and buildings for its facilities in Thailand, Cayman Islands,
 China and the United States under operating lease arrangements that
 expire in various years through 2021. Rental expense under these
 operating leases amounted to $1.2 million, $1.1 million and $0.8
 million for the years ended June 24, 2016, June 26,
 2015 and June 27, 2014, respectively.

[0001193125-16-684108:notes:10]
As of
 June 24, 2016, the future minimum lease payments due under
 non-cancelable operating leases during each fiscal year were as
 follows:

[0001193125-16-684108:notes:11]
| (amount in thousands) |  |  |  |
| 2017 |  | $ | 1,347 |  |
| 2018 |  |  | 1,275 |  |
| 2019 |  |  | 718 |  |
| 2020 |  |  | 510 |  |
| 2021 |  |  | 113 |  |
| Total future minimum operating lease payments |  | $ | 3,963 |  |

[0001193125-16-684108:notes:12]
Purchase
 obligations

[0001193125-16-684108:notes:13]
Purchase
 obligations represent legally-binding commitments to purchase
 inventory and other commitments made in the normal course of
 business to meet operational requirements. Although open purchase
 orders are considered enforceable and legally binding, their terms
 generally give the Company the option to cancel, reschedule and/or
 adjust its requirements based on its business needs prior to the
 delivery of goods or performance of services. Obligations to
 purchase inventory and other commitments are generally expected to
 be fulfilled within one year.

[0001193125-16-684108:notes:14]
As of
 June 24, 2016, the Company had an outstanding commitment to
 third parties of $22.2 million, mainly related to the construction
 of a new manufacturing building at the Company’s Chonburi
 Campus.

[0001193125-16-684108:notes:15]
Indemnification of directors and
 officers

[0001193125-16-684108:notes:16]
Cayman Islands
 law does not limit the extent to which a company’s memorandum
 and articles of association may provide for indemnification of
 directors and officers, except to the extent any such provision may
 be held by the Cayman Islands courts to be contrary to public
 policy, such as to provide indemnification against civil fraud or
 the consequences of committing a crime. Fabrinet’s amended
 and restated memorandum and articles of association provide for
 indemnification of directors and officers for actions, costs,
 charges, losses, damages and expenses incurred in their capacities
 as such, except that such indemnification does not extend to any
 matter in respect of any fraud or dishonesty that may attach to any
 of them.

[0001193125-16-684108:notes:17]
In accordance
 with Fabrinet’s form of indemnification agreement for its
 directors and officers, Fabrinet has agreed to indemnify its
 directors and officers against certain liabilities and expenses
 incurred by such persons in connection with claims by reason of
 their being such a director or officer. Fabrinet maintains a
 director and officer liability insurance policy that may enable it
 to recover a portion of any future amounts paid under the
 indemnification agreements.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-16-684108:notes:18]
| 13. | Share-based compensation |

[0001193125-16-684108:notes:19]
Share-based
 compensation

[0001193125-16-684108:notes:20]
In determining the fair
 value of share option awards, the Company is required to make
 estimates of expected dividends to be issued, expected volatility
 of Fabrinet’s ordinary shares, expected forfeitures of the
 awards, risk free interest rates for the expected term of the
 awards and expected terms of the awards. Forfeitures are estimated
 at the time of grant and revised if necessary in subsequent periods
 if actual forfeitures differ from those estimates. The fair value
 of restricted share units is based on the market value of our
 ordinary shares on the date of grant.

[0001193125-16-684108:notes:21]
The effect of recording
 share-based compensation expense for the years ended June 24,
 2016, June 26, 2015 and June 27, 2014 was as
 follows:

[0001193125-16-684108:notes:22]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 24, 2016 |  |  | June 26, 2015 |  |  | June 27, 2014 |  |
| Share-based compensation expense by type of award: |  |  |  |  |
| Share options |  | $ | 16 |  |  | $ | 226 |  |  | $ | 802 |  |
| Restricted share units |  |  | 9,911 |  |  |  | 7,801 |  |  |  | 4,745 |  |
| Total share-based compensation expense |  |  | 9,927 |  |  |  | 8,027 |  |  |  | 5,547 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 9,927 |  |  | $ | 8,027 |  |  | $ | 5,547 |  |

[0001193125-16-684108:notes:23]
Share-based compensation
 expense was recorded in the consolidated statements of operations
 and comprehensive income as follows:

[0001193125-16-684108:notes:24]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 24, 2016 |  |  | June 26, 2015 |  |  | June 27, 2014 |  |
| Cost of revenue |  | $ | 1,979 |  |  | $ | 1,450 |  |  | $ | 1,182 |  |
| Selling, general and administrative expense |  |  | 7,948 |  |  |  | 6,577 |  |  |  | 4,365 |  |
| Total share-based compensation expense |  | $ | 9,927 |  |  | $ | 8,027 |  |  | $ | 5,547 |  |

[0001193125-16-684108:notes:25]
The Company did not
 capitalize any share-based compensation expense as part of any
 asset costs during the years ended June 24,
 2016, June 26, 2015 and June 27,
 2014.

[0001193125-16-684108:notes:26]
Share-based award
 activity

[0001193125-16-684108:notes:27]
Share options have been
 granted to directors and employees. As of June 24, 2016, there
 were five share options outstanding under the Amended and Restated
 1999 Share Option Plan (“1999 Plan”). Additional option
 grants may not be made under the 1999 Plan.

[0001193125-16-684108:notes:28]
As of June 24, 2016,
 there were an aggregate of 464,329 share options and 1,181,402
 restricted share units outstanding. As of June 24, 2016, there
 were 2,207,607 ordinary shares available for future grant under
 Fabrinet’s 2010 Performance Incentive Plan (“2010
 Plan”). The 1999 Plan and 2010 Plan are collectively referred
 to as the “Share Option Plans”.

[0001193125-16-684108:notes:29]
Share
 options

[0001193125-16-684108:notes:30]
Fabrinet’s board of
 directors has the authority to determine the type of option and the
 number of shares subject to an option. Options generally vest and
 become exercisable over four years and expire, if not exercised,
 within seven years of the grant date. In the case of a
 grantee’s first grant, 25 percent of the underlying shares
 subject to an option vest 12 months after the vesting commencement
 date and 1/48 of the underlying shares vest monthly over each of
 the subsequent 36 months. In the case of any additional grants to a
 grantee, 1/48 of the underlying shares subject to an option vest
 monthly over four years, commencing one month after the vesting
 commencement date.

[0001193125-16-684108:notes:31]
The following table
 summarizes share options activity:

[0001193125-16-684108:notes:32]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 28, 2013 |  |  | 1,277,311 |  |  |  | 750,949 |  |  | $ | 15.37 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (351,435 | ) |  |  |  |  |  | $ | 13.00 |  |  |  |  |  |
| Forfeited |  |  | (26,276 | ) |  |  |  |  |  | $ | 15.54 |  |  |  |  |  |
| Expired |  |  | (33,710 | ) |  |  |  |  |  | $ | 16.93 |  |  |  |  |  |
| Balance as of June 27, 2014 |  |  | 865,890 |  |  |  | 666,305 |  |  | $ | 16.27 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (56,968 | ) |  |  |  |  |  | $ | 14.67 |  |  |  |  |  |
| Forfeited |  |  | (8,347 | ) |  |  |  |  |  | $ | 15.90 |  |  |  |  |  |
| Expired |  |  | (8,556 | ) |  |  |  |  |  | $ | 21.44 |  |  |  |  |  |
| Balance as of June 26, 2015 |  |  | 792,019 |  |  |  | 758,451 |  |  | $ | 16.33 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (325,530 | ) |  |  |  |  |  | $ | 16.83 |  |  |  |  |  |
| Forfeited |  |  | (755 | ) |  |  |  |  |  | $ | 17.10 |  |  |  |  |  |
| Expired |  |  | (1,400 | ) |  |  |  |  |  | $ | 23.62 |  |  |  |  |  |
| Balance as of June 24, 2016 |  |  | 464,334 |  |  |  | 464,334 |  |  | $ | 15.95 |  |  |  |  |  |
| Expected to vest as of June 24, 2016 |  |  | 464,334 |  |  |  |  |  |  | $ | 15.95 |  |  |  |  |  |

[0001193125-16-684108:notes:33]
The fair value of each
 share options grant was determined by the Company using the methods
 and assumptions discussed below. Each of these inputs is subjective
 and generally requires significant judgment and management estimate
 to determine.

[0001193125-16-684108:notes:34]
The total fair value of
 shares vested during the years ended June 24,
 2016, June 26, 2015 and June 27, 2014 was $0.2
 million, $1.1 million and $2.0 million, respectively. The total
 intrinsic value of options exercised during the years ended
 June 24, 2016 June 26, 2015 and June 27, 2014
 was $3.6 million, $0.2 million and $2.2 million, respectively. In
 conjunction with these exercises, there was no tax benefit realized
 by the Company due to the fact that it is exempted from income tax.
 The amount of cash received from the exercise of share options was
 $5.5 million during the year ended June 24,
 2016.

[0001193125-16-684108:notes:35]
Valuation
 Method—The Company estimated the fair value of the
 Company’s ordinary shares to be used in the BSM by taking
 into consideration a number of assumptions, as discussed
 below.

[0001193125-16-684108:notes:36]
Expected
 Dividend—The Company used zero as an annualized dividend
 yield since it did not anticipate paying any cash dividends in the
 near future.

[0001193125-16-684108:notes:37]
Expected
 Volatility—The Company determined the expected volatility
 based on the Company’s historical volatility over the last
 four years.

[0001193125-16-684108:notes:38]
Risk-Free Interest
 Rate—The Company based the risk-free interest rate on the
 implied yield currently available on U.S. Treasury zero-coupon
 issues with a remaining term equivalent to the expected term of the
 option.

[0001193125-16-684108:notes:39]
Expected
 Term—Expected terms used in the BSM represent the periods
 that the company’s share options are expected to be
 outstanding and are determined based on the Company’s
 historical experience of similar awards, giving consideration to
 the contractual terms of the share options, vesting schedules and
 expectations of future employee behavior.

[0001193125-16-684108:notes:40]
Vesting
 Period—Fabrinet’s share options generally vest and
 become exercisable over a four-year period, and expire seven years
 from the date of grant. For an initial grant, 25 percent of the
 underlying shares subject to an option vest 12 months after the
 vesting commencement date and 1/48 of the underlying shares vest
 monthly over each of the subsequent 36 months. In the case of any
 additional grants to an optionee, 1/48 of the underlying shares
 subject to an option vest monthly over four years, commencing one
 month after the vesting commencement date.

[0001193125-16-684108:notes:41]
Fair Value—The
 fair value of Fabrinet’s share options granted to employees
 was estimated using the weighted-average for each assumption of
 expected volatility, risk-free rate of return, and expected
 term.

[0001193125-16-684108:notes:42]
The following table
 summarizes information for share options outstanding as of
 June 24, 2016 under the share options plan:

[0001193125-16-684108:notes:43]
|  |  | Number of Shares Underlying Options |  |  | Exercise Price Per Share |  |  | Weighted Average Remaining Contractual Life (years) |  |  | Aggregate Intrinsic Value (amount in thousands) |  |
|  |  |  | 5 |  |  | $ | 5.75 |  |  |  | 0.40 |  |  |  |  |  |
|  |  |  | 255,428 |  |  | $ | 16.83 |  |  |  | 1.30 |  |  |  |  |  |
|  |  |  | 30,000 |  |  | $ | 15.05 |  |  |  | 1.36 |  |  |  |  |  |
|  |  |  | 5,900 |  |  | $ | 25.50 |  |  |  | 1.56 |  |  |  |  |  |
|  |  |  | 2,400 |  |  | $ | 26.16 |  |  |  | 1.61 |  |  |  |  |  |
|  |  |  | 9,943 |  |  | $ | 15.16 |  |  |  | 2.15 |  |  |  |  |  |
|  |  |  | 155,066 |  |  | $ | 14.12 |  |  |  | 2.38 |  |  |  |  |  |
|  |  |  | 5,550 |  |  | $ | 18.60 |  |  |  | 2.68 |  |  |  |  |  |
|  |  |  | 42 |  |  | $ | 12.83 |  |  |  | 2.87 |  |  |  |  |  |
| Options outstanding |  |  | 464,334 |  |  |  |  |  |  |  | 1.71 |  |  | $ | 8,830 |  |
| Options exercisable |  |  | 464,334 |  |  |  |  |  |  |  | 1.71 |  |  | $ | 8,830 |  |
| Expected to vest as of June 24, 2016 |  |  | 464,334 |  |  |  |  |  |  |  | 1.71 |  |  | $ | 8,830 |  |

[0001193125-16-684108:notes:44]
As of June 24, 2016,
 there was no unrecognized compensation cost under the Share Option
 Plans.

[0001193125-16-684108:notes:45]
Restricted share
 units

[0001193125-16-684108:notes:46]
Restricted share units are
 one type of share-based award that may be granted under the 2010
 Plan. Restricted share units granted to non-employee directors
 generally cliff vest 100% on the first of January, approximately
 one year from the grant date, provided the director continues to
 serve through such date. Restricted share units granted to
 employees generally vest in four equal installments over four years
 on each anniversary of the vesting commencement
 date.

[0001193125-16-684108:notes:47]
On May 24, 2015, the
 Company entered into an amended and restated employment agreement
 with an executive of the Company that provides for accelerated
 vesting of equity awards under certain circumstances. Under the
 agreement, any equity award granted to the executive after
 February 20, 2017, shall vest over a period not longer than
 two years following the applicable grant date. If the
 executive’s employment with the Company continues through and
 including February 20, 2017, any outstanding equity award
 grants before February 20, 2017 will become 100%
 vested.

[0001193125-16-684108:notes:48]
The following table
 summarizes restricted share unit activity:

[0001193125-16-684108:notes:49]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 28, 2013 |  |  | 545,668 |  |  | $ | 12.81 |  |
| Granted |  |  | 479,894 |  |  | $ | 15.37 |  |
| Issued |  |  | (184,773 | ) |  | $ | 12.98 |  |
| Forfeited |  |  | (78,494 | ) |  | $ | 14.25 |  |
| Balance as of June 27, 2014 |  |  | 762,295 |  |  | $ | 14.23 |  |
| Granted |  |  | 666,582 |  |  | $ | 17.53 |  |
| Issued |  |  | (247,593 | ) |  | $ | 14.44 |  |
| Forfeited |  |  | (40,357 | ) |  | $ | 16.68 |  |
| Balance as of June 26, 2015 |  |  | 1,140,927 |  |  | $ | 16.03 |  |
| Granted |  |  | 654,589 |  |  | $ | 21.15 |  |
| Issued |  |  | (507,621 | ) |  | $ | 15.60 |  |
| Forfeited |  |  | (106,493 | ) |  | $ | 18.34 |  |
| Balance as of June 24, 2016 |  |  | 1,181,402 |  |  | $ | 18.34 |  |
| Expected to vest as of June 24, 2016 |  |  | 1,076,704 |  |  | $ | 18.65 |  |

[0001193125-16-684108:notes:50]
The fair value of
 restricted share units is based on the market value of our ordinary
 shares on the date of grant.

[0001193125-16-684108:notes:51]
The total fair value of
 restricted share units vested during the year ended June 24,
 2016, June 26, 2015 and June 27, 2014 was $7.9
 million, $3.6 million and $2.4 million, respectively. The aggregate
 intrinsic value of restricted share units outstanding as of
 June 24, 2016 was $41.3 million.

[0001193125-16-684108:notes:52]
As of June 24, 2016,
 there was $8.8 million of unrecognized share-based compensation
 expense related to restricted share units under the 2010 Plan that
 is expected to be recorded over a weighted-average period of 2.72
 years.

[0001193125-16-684108:notes:53]
For the years ended
 June 24, 2016 and June 26, 2015, the Company withheld an
 aggregate of 114,359 shares and 19,679 shares, respectively, upon
 the vesting of restricted share units, based upon the closing share
 price on the vesting date to settle the employees’ minimum
 statutory obligation for the applicable income and other employment
 taxes. For fiscal year 2016 and fiscal year 2015, the Company then
 remitted cash of $2.5 million and $0.4 million, respectively, to
 the appropriate taxing authorities, and presented it as a financing
 activity within the consolidated statements of cash flows. The
 payment had the effect on shares issued by the Company as it
 reduced the number of shares that would have been issued on the
 vesting date and was recorded as a reduction of additional paid-in
 capital.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-16-684108:notes:54]
| 8. | Inventory |

[0001193125-16-684108:notes:55]
| (amount in thousands) |  | As of June 24, 2016 |  |  | As of June 26, 2015 |  |
| Raw materials |  | $ | 58,199 |  |  | $ | 46,065 |  |
| Work in progress |  |  | 94,762 |  |  |  | 69,174 |  |
| Finished goods |  |  | 21,593 |  |  |  | 11,843 |  |
| Goods in transit |  |  | 9,381 |  |  |  | 6,488 |  |
|  |  |  | 183,935 |  |  |  | 133,570 |  |
| Less: Inventory obsolescence |  |  | (2,436 | ) |  |  | (2,957 | ) |
| Inventory, net |  | $ | 181,499 |  |  | $ | 130,613 |  |


## us-gaap:InventoryPolicyTextBlock

[0001193125-16-684108:notes:56]
Inventory

[0001193125-16-684108:notes:57]
Inventory is
 stated at the lower of cost or market value. Cost is estimated
 using the standard costing method, computed on a first-in,
 first-out basis, with adjustments for variances to reflect actual
 costs not in excess of net realizable market value. Market value is
 the estimated selling price in the ordinary course of business,
 less the costs of completion and selling expenses. The Company
 assesses the valuation of inventory on a quarterly basis and writes
 down the value for estimated excess and obsolete inventory based
 upon estimates of future demand.


## us-gaap:ReclassificationOutOfAccumulatedOtherComprehensiveIncomeTableTextBlock

[0001193125-16-684108:notes:58]
The following
 table presents the pre-tax amounts reclassified from AOCI into the
 consolidated statements of operations and comprehensive income for
 the year ended June 24, 2016 and June 26, 2015,
 respectively (amounts in thousands).

[0001193125-16-684108:notes:59]
|  |  |  |  | Years ended |  |
| AOCI components |  | Financial statements line item |  | June 24, 2016 |  |  | June 26, 2015 |  |
| Unrealized (losses) gains on marketable securities |  | Interest income |  | $ | (194 | ) |  | $ | 149 |  |
| Unrealized gains on derivative instruments |  | Cost of revenues |  |  | 471 |  |  |  | — |  |
|  |  | Selling, general and administrative expenses |  |  | 19 |  |  |  | — |  |
| Total amounts reclassified from AOCI |  |  |  | $ | 296 |  |  | $ | 149 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-16-684108:notes:60]
The changes in
 AOCI by component for the years ended June 24, 2016 and
 June 26, 2015 were as follows:

[0001193125-16-684108:notes:61]
| (amount in thousands) |  | Unrealized net (Losses)/Gains on Marketable Securities |  |  | Unrealized net (Losses)/Gains on Derivative Instruments |  |  | Total |  |
| Balance as of June 27, 2014 |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Other comprehensive income before reclassification |  |  | (193 | ) |  |  | — |  |  |  | (193 | ) |
| Amounts reclassified from AOCI |  |  | 149 |  |  |  | — |  |  |  | 149 |  |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income |  |  | (44 | ) |  |  | — |  |  |  | (44 | ) |
| Balance as of June 26, 2015 |  |  | (44 | ) |  |  | — |  |  |  | (44 | ) |
| Other comprehensive income before reclassification |  |  | 637 |  |  |  | (298 | ) |  |  | 339 |  |
| Amounts reclassified from AOCI |  |  | (194 | ) |  |  | 490 |  |  |  | 296 |  |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income |  |  | 443 |  |  |  | 192 |  |  |  | 635 |  |
| Balance as of June 24, 2016 |  | $ | 399 |  |  | $ | 192 |  |  | $ | 591 |  |


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001193125-16-684108:notes:62]
The
 Company’s income tax expense consisted of the
 following:

[0001193125-16-684108:notes:63]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 24, 2016 |  |  | June 26, 2015 |  |  | June 27, 2014 |  |
| Current |  | $ | 5,413 |  |  | $ | 4,191 |  |  | $ | 2,304 |  |
| Deferred |  |  | 922 |  |  |  | (207 | ) |  |  | (865 | ) |
| Total income tax expense |  | $ | 6,335 |  |  | $ | 3,984 |  |  | $ | 1,439 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001193125-16-684108:notes:64]
The movements
 of long-term loans were as follows for the years ended
 June 24, 2016 and June 26, 2015:

[0001193125-16-684108:notes:65]
|  |  | Years ended |  |
| (amount in thousands) |  | June 24, 2016 |  |  | June 26, 2015 |  |
| Opening net book amount |  | $ | 10,500 |  |  | $ | 16,500 |  |
| Additional loan during the period |  |  | 50,000 |  |  |  | — |  |
| Repayment during the period |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Closing net book amount |  | $ | 54,500 |  |  | $ | 10,500 |  |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock

[0001193125-16-684108:notes:66]
Undrawn
 available credit facilities classified by available period of
 future borrowing as of June 24, 2016 and June 26, 2015
 were as follows:

[0001193125-16-684108:notes:67]
| (amount in thousands) |  | June 24, 2016 |  |  | June 26, 2015 |  |
| Short-term |  | $ | 1,414 |  |  | $ | 1,480 |  |
| Long-term |  | $ | 143,500 |  |  | $ | 170,000 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-16-684108:notes:68]
The Company
 operates primarily in three geographic regions: North America,
 Asia-Pacific and Europe. The following table presents total
 revenues by geographic regions:

[0001193125-16-684108:notes:69]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 24, 2016 |  |  | June 26, 2015 |  |  | June 27, 2014 |  |
| North America |  | $ | 525,161 |  |  | $ | 370,836 |  |  | $ | 326,647 |  |
| Asia-Pacific |  |  | 351,033 |  |  |  | 309,941 |  |  |  | 230,314 |  |
| Europe |  |  | 100,553 |  |  |  | 92,810 |  |  |  | 120,893 |  |
| Total |  | $ | 976,747 |  |  | $ | 773,587 |  |  | $ | 677,854 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-16-684108:notes:70]
| 2. | Summary of significant accounting policies |

[0001193125-16-684108:notes:71]
Principles of
 consolidation

[0001193125-16-684108:notes:72]
The Company utilizes a
 52-53 week fiscal year ending on the Friday in June closest to
 June 30. Fiscal year 2016, fiscal year 2015 and fiscal year
 2014 ended on June 24, 2016, June 26, 2015 and
 June 27, 2014, respectively, and each consisted of 52
 weeks.

[0001193125-16-684108:notes:73]
The consolidated financial
 statements have been prepared in accordance with accounting
 principles generally accepted in the United States (“U.S.
 GAAP”) and include Fabrinet and its subsidiaries. All
 inter-company accounts and transactions have been
 eliminated.

[0001193125-16-684108:notes:74]
Where necessary,
 comparative figures have been reclassified to conform to the
 current year presentation.

[0001193125-16-684108:notes:75]
Use of
 estimates

[0001193125-16-684108:notes:76]
The preparation of the
 Company’s consolidated financial statements in conformity
 with U.S. GAAP requires management to make estimates and
 assumptions that affect the reported amounts of assets and
 liabilities and disclosure of contingent liabilities at the date of
 the financial statements, and the reported amount of total revenues
 and expense during the year. The Company bases estimates on
 historical experience and various assumptions about the future that
 are believed to be reasonable based on available information. The
 Company’s reported financial position or results of
 operations may be materially different under different conditions
 or when using different estimates and assumptions, particularly
 with respect to significant accounting policies, which are
 discussed below. Significant assumptions are used in accounting for
 share-based compensation, allowance for doubtful accounts, income
 taxes, and inventory obsolescence, among others. Due to the
 inherent uncertainty involved in making estimates, actual results
 reported in future periods may be different from these estimates.
 In the event that estimates or assumptions prove to differ from
 actual results, adjustments will be made in subsequent periods to
 reflect more current information.

[0001193125-16-684108:notes:77]
Foreign currency
 transactions and translation

[0001193125-16-684108:notes:78]
The consolidated financial
 statements are presented in United States dollars (“$”
 or “USD”).

[0001193125-16-684108:notes:79]
The functional currency of
 Fabrinet and its subsidiaries is the USD. Transactions in
 currencies other than the functional currency are translated into
 the functional currency at the rates of exchange in effect at the
 date of the transaction. Monetary assets and liabilities
 denominated in foreign currencies are translated into the
 functional currency at the exchange rate prevailing at the
 consolidated balance sheet dates. Transaction gains and losses are
 included in other income (expense) in the accompanying consolidated
 statements of operations and comprehensive
 income.

[0001193125-16-684108:notes:80]
Cash and cash
 equivalents

[0001193125-16-684108:notes:81]
All highly liquid
 investments with original maturities of three months or less at the
 date of purchase are classified as cash equivalents. Cash and cash
 equivalents consist of cash deposited in checking accounts, time
 deposits with maturities of less than three months, money market
 accounts, and marketable securities with maturities of three months
 or less at the date of purchase.

[0001193125-16-684108:notes:82]
Marketable
 securities

[0001193125-16-684108:notes:83]
Management determines the
 appropriate classification of its investments at the time of
 purchase and reevaluates the designations at each balance sheet
 date. The Company may sell certain of the Company’s
 marketable securities prior to their stated maturities for
 strategic reasons including, but not limited to, anticipation of
 credit deterioration and duration management. The maturities of the
 Company’s marketable securities generally range from three
 months to three years. The Company’s marketable securities
 consist of investment in U.S. Treasury and fixed income securities
 and have been classified and accounted for as
 available-for-sale.

[0001193125-16-684108:notes:84]
The Company’s
 investments in marketable securities are classified as
 available-for-sale securities and reported at fair value.
 Unrealized gains and losses related to changes in the fair value of
 securities are recognized in accumulated other comprehensive
 income, net of tax, in the Company’s consolidated balance
 sheets. Changes in the fair value of available-for-sale securities
 impact the Company’s net income only when such securities are
 sold or other-than-temporary impairment is recognized. Realized
 gains and losses on the sale of securities are determined by
 specific identification of each security’s cost
 basis.

[0001193125-16-684108:notes:85]
The Company reviews its
 marketable securities on a regular basis to evaluate whether or not
 any security has experienced an other-than-temporary decline in
 fair value. The Company considers factors such as the length of
 time and extent to which the market value has been less than the
 cost, the financial condition and near-term prospects of the issue
 and the Company’s intent to sell, or whether it is more
 likely than not the Company will be required to sell the investment
 before recovery of the investment’s amortized cost basis. If
 the Company believes that an other-than-temporary decline exists in
 one of these securities, the Company will write down these
 investments to fair value.

[0001193125-16-684108:notes:86]
Trade accounts
 receivable

[0001193125-16-684108:notes:87]
Accounts receivable are
 carried at anticipated realizable value. The Company assesses the
 collectability of its accounts receivable based on specific
 customer circumstances, current economic trends, historical
 experience with collection and the age of past due receivables and
 provides an allowance for doubtful receivables based on a review of
 all outstanding amounts at the period end. Bad debts are
 written-off when identified.

[0001193125-16-684108:notes:88]
Unanticipated changes in
 the liquidity or financial position of the Company’s
 customers may require revision to the allowances for doubtful
 accounts.

[0001193125-16-684108:notes:89]
Inventory is stated at the
 lower of cost or market value. Cost is estimated using the standard
 costing method, computed on a first-in, first-out basis, with
 adjustments for variances to reflect actual costs not in excess of
 net realizable market value. Market value is the estimated selling
 price in the ordinary course of business, less the costs of
 completion and selling expenses. The Company assesses the valuation
 of inventory on a quarterly basis and writes down the value for
 estimated excess and obsolete inventory based upon estimates of
 future demand.

[0001193125-16-684108:notes:90]
Leases

[0001193125-16-684108:notes:91]
Payments made under
 operating leases are expensed on a straight-line basis over the
 lease term.

[0001193125-16-684108:notes:92]
Property, plant and
 equipment

[0001193125-16-684108:notes:93]
Land is stated at
 historical cost. Other property, plant and equipment, except for
 construction in process and machinery under installation, are
 stated at historical cost less accumulated depreciation.
 Depreciation is calculated using the straight-line method to
 write-off the cost of each asset to its residual value over its
 estimated useful life as follows:

[0001193125-16-684108:notes:94]
| Building and building improvements |  |  | 10 - 30 years |  |
| Leasehold improvements |  |  | Shorter of useful life or lease term |  |
| Manufacturing equipment |  |  | 3 - 5 years |  |
| Office equipment |  |  | 3 - 5 years |  |
| Motor vehicles |  |  | 5 years |  |
| Computer hardware |  |  | 3 - 5 years |  |

[0001193125-16-684108:notes:95]
Construction in process and
 machinery under installation is stated at historic cost and
 depreciation begins after it is constructed and fully installed and
 is ready for its intended use in the operations of the
 Company.

[0001193125-16-684108:notes:96]
Gains and losses on
 disposal are determined by comparing proceeds with carrying amounts
 and are included in operating income in the consolidated statements
 of operations and comprehensive income.

[0001193125-16-684108:notes:97]
The Company tests
 long-lived assets or asset groups for recoverability when events or
 changes in circumstances indicate that their carrying amount may
 not be recoverable. Recoverability of long-lived assets or asset
 groups is measured by comparing their carrying amount to the
 projected undiscounted cash flows that the long-lived assets or
 asset groups are expected to generate. If such assets are
 considered to be impaired, the impairment loss recognized, if any,
 is the amount by which the carrying amount of the property and
 equipment exceeds its fair value.

[0001193125-16-684108:notes:98]
Intangibles

[0001193125-16-684108:notes:99]
Intangibles are stated at
 historical cost less amortization. Amortization is calculated using
 the straight-line method.

[0001193125-16-684108:notes:100]
Borrowing
 costs

[0001193125-16-684108:notes:101]
Borrowing costs are
 accounted for on an accrual basis and are charged to the
 consolidated statements of operations and comprehensive income in
 the year incurred, except for interest costs on general and
 specific borrowings attributable to finance certain qualifying
 assets. Such costs to finance qualifying assets are capitalized
 during the period of time that is required to complete and prepare
 the assets for their intended use, as part of the cost of the
 assets. All other borrowing costs are expensed as
 incurred.

[0001193125-16-684108:notes:102]
Where funds are not
 borrowed for acquisition, construction or production of assets, the
 capitalization rate used to determine the amount of interest to be
 capitalized is the weighted average interest rate applicable to the
 Company’s outstanding borrowings during the year. Where funds
 are borrowed specifically for the acquisition, construction or
 production of assets, the amount of borrowing costs eligible for
 capitalization on the respective assets is determined as the actual
 borrowing costs are incurred on that borrowing during the
 respective periods.

[0001193125-16-684108:notes:103]
Fair value of
 financial instruments

[0001193125-16-684108:notes:104]
Fair value is defined as
 the exchange price that would be received for an asset or paid to
 transfer a liability (an exit price) in the principal or most
 advantageous market for the asset or liability in an orderly
 transaction between market participants on the measurement date. A
 fair value hierarchy is established which requires an entity to
 maximize the use of observable inputs and minimize the use of
 unobservable inputs for the valuation of an asset or liability as
 of the measurement date. The three levels of inputs that may be
 used to measure fair value are defined as
 follows:

[0001193125-16-684108:notes:105]
Level 1 inputs are quoted
 prices (unadjusted) in active markets for identical assets or
 liabilities.

[0001193125-16-684108:notes:106]
Level 2 inputs for similar
 assets and liabilities in active markets other than quoted prices
 included within Level 1 that are observable for the asset or
 liability, either directly or indirectly, for substantially the
 full term of the asset or liability.

[0001193125-16-684108:notes:107]
Level 3 inputs that are
 significant to the fair value measurement and unobservable (i.e.
 supported by little or no market activity), which require the
 reporting entity to develop its own valuation techniques and
 assumptions.

[0001193125-16-684108:notes:108]
The Company utilizes the
 market approach to measure fair value for its financial assets and
 liabilities. The market approach uses prices and other relevant
 information generated by market transactions involving identical or
 comparable assets or liabilities.

[0001193125-16-684108:notes:109]
The carrying amounts of
 certain financial instruments, which include cash and cash
 equivalents, trade accounts receivable, and trade accounts payable,
 approximate their fair values due to their short maturities. The
 carrying amounts of borrowings approximate their fair values as the
 applicable interest rate is based on market interest rates. The
 particular recognition methods adopted are disclosed in the
 individual policy statements associated with each
 item.

[0001193125-16-684108:notes:110]
Derivatives

[0001193125-16-684108:notes:111]
Derivatives assets and
 liabilities are recognized on the consolidated balance sheets as
 other current assets or accrued expenses, and are measured at fair
 value.

[0001193125-16-684108:notes:112]
The Company applies hedge
 accounting to arrangements that qualify and are designated for cash
 flow hedge accounting treatment. Hedge accounting is discontinued
 prospectively if the hedging relationship ceases to be effective or
 the hedging or hedged items cease to exist as a result of maturity,
 sale, termination or cancellation.

[0001193125-16-684108:notes:113]
Derivatives designated and
 qualified as hedges of the exposure to variability in expected
 future cash flows, or other types of forecasted transactions, are
 considered cash flow hedges which include forward currency
 contracts. In a cash flow hedging relationship, the effective
 portion of the change in the fair value of the hedging derivative
 is initially recorded in accumulated other comprehensive income
 (loss) (“AOCI”), while any ineffective portion is
 recognized directly in earnings, as a component of other income
 (expense). The portion of gain or loss on the derivative instrument
 remains in AOCI until the forecasted transaction is recognized in
 earnings. The gain or loss on cash settlement of the hedging
 derivatives are presented based on the underlying transaction being
 hedged.

[0001193125-16-684108:notes:114]
The Company also enters
 into derivative contracts to economically hedge the foreign
 currency risk that does not qualify for hedge accounting. The
 changes in the fair value of these derivatives are recorded
 directly in earnings as a component of other income (expense), net.
 In accordance with the fair value measurement guidance, the
 Company’s accounting policy is to measure the credit risk of
 our derivative financial instruments that are subject to master
 netting agreements on a net basis by counterparty portfolio. The
 Company executes derivative instruments with financial institutions
 that are credit-worthy, defined as institutions that hold an
 investment grade credit rating.

[0001193125-16-684108:notes:115]
Concentration of
 credit risk

[0001193125-16-684108:notes:116]
Financial instruments that
 potentially subject the Company to concentrations of credit risk
 consist of cash, cash equivalents, marketable securities,
 derivatives, and accounts receivable.

[0001193125-16-684108:notes:117]
Cash, cash equivalents, and
 marketable securities are maintained with several financial
 institutions. Deposits held with banks may exceed the amount of
 insurance provided on such deposits. Generally, these deposits may
 be redeemed upon demand and are maintained with financial
 institutions with reputable credit and therefore bear minimal
 credit risk. The Company seeks to mitigate its credit risks by
 spreading such risks across multiple counterparties and monitoring
 the risk profiles of these counterparties. The Company limits its
 investments in marketable securities to securities with a maturity
 not in excess of three years, and all marketable securities that
 the Company invests in are rated A1, P-1, F1, or
 better.

[0001193125-16-684108:notes:118]
The Company performs
 ongoing credit evaluations for credit worthiness of its customers
 and usually does not require collateral from its customers.
 Management has implemented a program to closely monitor near term
 cash collection and credit exposures to mitigate any material
 losses.

[0001193125-16-684108:notes:119]
Revenue
 recognition

[0001193125-16-684108:notes:120]
The Company derives total
 revenues primarily from the assembly of products under supply
 agreements with its customers and the fabrication of customized
 optics and glass. Revenues represent the invoiced value of
 products, net of trade discounts and allowances, and exclude goods
 and services tax. The Company recognizes revenues when realized or
 realizable and earned. The Company considers revenues realized or
 realizable and earned when there is persuasive evidence of an
 arrangement, delivery has occurred, the sales price is fixed or
 determinable, and collectability is reasonably assured. Delivery
 does not occur until products have been shipped or services have
 been provided to the customer, risk of loss has transferred to the
 customer and customer acceptance has been obtained, customer
 acceptance provisions have lapsed, or the Company has objective
 evidence that the criteria specified in the customer acceptance
 provisions have been satisfied. In situations where a formal
 acceptance is required but the acceptance only relates to whether
 the product meets its published specifications, revenues are
 generally recognized upon shipment provided all other revenue
 recognition criteria are met. The sales price is not considered to
 be fixed or determinable until all contingencies related to the
 sale have been resolved. The Company reduces revenues for rebates
 and other similar allowances. Revenues are recognized only if these
 estimates can be reasonably and reliably determined. The Company
 bases its estimates utilizing historical results taking into
 consideration the type of customer, the type of transaction and the
 specifics of each arrangement. In addition to the aforementioned
 general policies, the following are the specific revenue
 recognition policies for each major category of
 revenues.

[0001193125-16-684108:notes:121]
Services

[0001193125-16-684108:notes:122]
The Company provides
 services for its customers that range from process design to
 product manufacturing. The Company recognizes service revenues when
 the services have been performed. The related costs are expensed as
 incurred.

[0001193125-16-684108:notes:123]
Services revenue of $31.7
 million, $32.3 million and $25.5 million were recognized in the
 consolidated statements of operations and comprehensive income for
 the years ended June 24, 2016, June 26, 2015 and
 June 27, 2014, respectively.

[0001193125-16-684108:notes:124]
Sales of
 goods

[0001193125-16-684108:notes:125]
Revenues from sales of
 goods are generally recognized when the product is shipped to the
 customer and when there are no unfulfilled obligations that affect
 the customer’s final acceptance of the arrangement. Any cost
 of warranties and remaining obligations that are inconsequential or
 perfunctory are accrued when the corresponding revenues are
 recognized.

[0001193125-16-684108:notes:126]
Certain customers may
 request the Company to store finished products purchased by
 them at the Company’s warehouse. In these instances, the
 Company receives a written request from the customer asking the
 Company to hold the inventory at the Company’s warehouse and
 the ordered goods are segregated in the Company’s warehouse
 from other inventory and cannot be used to fulfil other customer
 orders. In these situations, revenue is only recognized when
 persuasive evidence of the sales arrangement exists, the goods are
 completed and ready for shipment, pricing is fixed or determinable,
 collection is reasonably assured, and title and risk of loss have
 passed to the customer.

[0001193125-16-684108:notes:127]
Warranty
 provision

[0001193125-16-684108:notes:128]
Provisions for estimated
 expenses relating to product warranties are made at the time the
 products are sold using historical experience. Generally, this
 warranty is limited to workmanship and the Company’s
 liability is capped at the price of the product. The provisions
 will be adjusted when experience indicates an expected settlement
 will differ from initial estimates.

[0001193125-16-684108:notes:129]
Warranty cost allowances of
 $0.1 million, $0.03 million and $0.02 million were recognized in
 the consolidated statements of operations and comprehensive income
 for the years ended June 24, 2016, June 26, 2015 and
 June 27, 2014, respectively.

[0001193125-16-684108:notes:130]
Shipping and handling
 costs

[0001193125-16-684108:notes:131]
The Company records costs
 related to shipping and handling in cost of revenues for all
 periods presented.

[0001193125-16-684108:notes:132]
Share-based compensation is
 recognized in the consolidated financial statements based on
 grant-date fair value. The value of the portion of the award that
 is ultimately expected to vest is recognized as expense ratably
 over the requisite service period. The Company estimates the fair
 value of share option awards utilizing the Black-Scholes-Merton
 option-pricing model (“BSM”), net of estimated
 forfeitures. For restricted share units, the fair value is based on
 the market value of our ordinary shares on the date of
 grant.

[0001193125-16-684108:notes:133]
Employee contribution
 plan

[0001193125-16-684108:notes:134]
The Company operates a
 defined contribution plan, known as a provident fund, in its
 subsidiary in Thailand. The assets of this plan are in a separate
 trustee-administered fund. The provident fund is funded by matching
 payments from employees and by the subsidiary on a monthly basis.
 Current contributions to the provident fund are accrued and paid to
 the fund manager on a monthly basis. The Company sponsors the
 Fabrinet U.S. 401(k) Retirement Plan (the “401(k)
 Plan”), a Defined Contribution Plan under ERISA, at its
 subsidiaries in the United States, which provides retirement
 benefits for its eligible employees through tax deferred salary
 deductions.

[0001193125-16-684108:notes:135]
Severance
 liabilities

[0001193125-16-684108:notes:136]
Under labor protection laws
 applicable in Thailand and the Company’s subsidiary in
 Thailand’s employment policy, all employees of such
 subsidiary with more than 120 days of service are entitled to
 severance pay on forced termination or retrenchment or in the event
 that the employee reaches the retirement age of 55. The entitlement
 to severance pay is determined according to an employee’s
 individual employment tenure with the Company and is subject to a
 maximum benefit of 10 months of salary unless otherwise agreed upon
 in an employee’s employment contract. For employees of other
 subsidiaries who have a specific termination date, the entitlement
 to severance pay is determined according to their employment
 tenure, until their designated termination date.

[0001193125-16-684108:notes:137]
The Company accounts for
 these severance liabilities on an actuarial basis using the
 Projected Unit Credit Method, using the long-term Thai government
 bond yield as a discount rate. There are no separate plan assets
 held in respect of these liabilities.

[0001193125-16-684108:notes:138]
Annual
 leave

[0001193125-16-684108:notes:139]
Employee entitlements to
 annual leave are recognized when they accrue to the employee. On
 termination of employment, accrued employee entitlement to annual
 leave is paid in cash.

[0001193125-16-684108:notes:140]
Income
 taxes

[0001193125-16-684108:notes:141]
The Company uses the asset
 and liability method of accounting for income taxes, whereby
 deferred tax assets and liabilities are recognized for future tax
 consequences attributable to temporary differences between the
 financial statement carrying amounts of existing assets and
 liabilities and their respective tax bases. Deferred tax assets and
 liabilities are measured using tax rates expected to apply to
 taxable income in the years in which those temporary differences
 are expected to reverse. The effect of a change in tax rates on
 deferred tax assets and liabilities is recognized in income in the
 period that includes the enactment date. Deferred tax assets are
 reduced by a valuation allowance if, based on the weight of the
 available evidence, it is more likely than not that some portion or
 all of the deferred tax assets will not be
 realized.

[0001193125-16-684108:notes:142]
Fabrinet’s
 subsidiaries are subject to income tax audits by the respective tax
 authorities in all of the jurisdictions in which they operate. The
 determination of tax liabilities in each of these jurisdictions
 requires the interpretation and application of complex and
 sometimes uncertain tax laws and regulations. The Company
 recognizes liabilities based on its estimate of whether, and the
 extent to which, additional tax liabilities are probable. If the
 Company ultimately determines that the payment of such a liability
 is not probable, then it reverses the liability and recognizes a
 tax benefit during the period in which the determination is made
 that the liability is no longer probable. The recognition and
 measurement of current taxes payable or refundable and deferred tax
 assets and liabilities requires that the Company makes certain
 estimates and judgments. Changes to these estimates or a change in
 judgment may have a material impact on the Company’s tax
 provision in a future period.

[0001193125-16-684108:notes:143]
The authoritative guidance
 provides for recognition of deferred tax assets if the realization
 of such deferred tax assets is more likely than not to occur based
 on an evaluation of both positive and negative evidence and the
 relative weight of the evidence. The Company has determined that it
 is more likely than not that deferred tax asset attributable to a
 subsidiary in the United States will not be realized, primarily due
 to uncertainties related to its ability to utilize its net
 operating loss carryforward before they expire. Accordingly, the
 Company has established a valuation allowance for such deferred tax
 asset. If there is a change in the Company’s ability to
 realize its deferred tax assets for which a valuation allowance has
 been established, then its tax provision may decrease in the period
 in which it determines that realization is more likely than not.
 Likewise, if the Company determines that it is not more likely than
 not that its deferred tax assets will be realized, then a valuation
 allowance may be established for such deferred tax assets and the
 Company’s tax provision may increase in the period in which
 it makes the determination.

[0001193125-16-684108:notes:144]
The accounting standard
 clarifies the accounting for uncertainty in income taxes recognized
 in an entity’s financial statements and prescribes a
 recognition threshold and measurement attributes for financial
 statement disclosure of tax positions taken or expected to be taken
 on a tax return.

[0001193125-16-684108:notes:145]
The Company recognizes a
 tax benefit in the financial statements for an uncertain tax
 position only if management’s assessment is that the position
 is “more likely than not” (i.e., a likelihood greater
 than 50 percent) to be allowed by the tax jurisdiction based
 solely on the technical merits of the position. The term “tax
 position” refers to a position in a previously filed tax
 return or a position expected to be taken in a future tax return
 that is reflected in measuring current or deferred income tax
 assets and liabilities for interim or annual periods. The
 accounting interpretation also provides guidance on measurement
 methodology, derecognition thresholds, financial statement
 classification and disclosures, recognition of interest and
 penalties, and accounting for the cumulative-effect adjustment at
 the date of adoption.

[0001193125-16-684108:notes:146]
New Accounting
 Pronouncements—not yet adopted by the
 Company

[0001193125-16-684108:notes:147]
In June 2016, the Financial
 Accounting Standards Board (“FASB”) issued Accounting
 Standards Update (“ASU”) 2016-13, “Financial
 Instruments—Credit Losses (Topic 326): Measurement of Credit
 Losses on Financial Instruments.” The amendments in this ASU
 replace the incurred loss impairment methodology in current GAAP
 with a methodology that reflects expected credit losses and
 requires consideration of a broader range of reasonable and
 supportable information to inform credit loss estimates. The
 amendments are effective for fiscal years beginning after
 December 15, 2019, including interim periods within those
 fiscal years. Early adoption is permitted for fiscal years
 beginning after December 15, 2018, including interim periods
 within those fiscal years. The Company is currently evaluating the
 impact of adoption of this update on its consolidated financial
 statements.

[0001193125-16-684108:notes:148]
In March 2016, the FASB
 issued ASU 2016-09, “Compensation—Stock
 Compensation (Topic 718): Improvements to Employee Share-Based
 Payment Accounting”. This ASU simplifies several aspects of
 the accounting for share-based payment award transactions,
 including, the income tax consequences, classification of awards as
 either equity or liabilities and classification on the statement of
 cash flows. For public business entities, the amendments in this
 update are effective for annual periods beginning after
 December 15, 2016, and interim periods within those annual
 periods, for public companies. Early adoption is permitted in any
 interim or annual period. The Company is currently evaluating the
 impact of adoption of this update on its consolidated financial
 statements.

[0001193125-16-684108:notes:149]
In March 2016, the FASB
 issued ASU 2016-05, “Derivatives and Hedging (Topic 815):
 Effect of Derivative Contract Novations on Existing Hedge
 Accounting Relationships”, to clarify that a change in the
 counterparty to a derivative instrument that has been designated as
 a hedging instrument under Topic 815, does not, in and of itself,
 require designation of the hedging relationship, provided that all
 other hedge accounting criteria continue to be met. This guidance
 is effective for public companies for financial statements issued
 for fiscal years beginning after December 15, 2016 and interim
 periods within those fiscal years. Early adoption is permitted,
 including adoption in an interim period. The Company is currently
 evaluating the impact of adoption of this update on its
 consolidated financial statements.

[0001193125-16-684108:notes:150]
In February 2016, the FASB
 issued ASU 2016-02, “Lease (Topic 842)”. The core
 principle of Topic 842 is that a lessee should recognize the lease
 assets and liabilities that arise from leases in the balance sheet.
 For public companies, this update is effective for fiscal years
 beginning after December 15, 2018, including interim periods
 within those fiscal years. Early application is permitted. The
 Company is currently evaluating the impact of adoption of this
 update on its consolidated financial statements.

[0001193125-16-684108:notes:151]
In January 2016, the FASB
 issued ASU 2016-01, “Financial Instruments—Overall
 (Subtopic 825-10): Recognition and Measurement of Financial Assets
 and Financial Liabilities”. This new guidance requires
 certain equity investments to be measured at fair value, use of the
 exit price notion and separate presentation of financial assets and
 financial liabilities by measurement category and form of financial
 asset on the balance sheet or the accompanying notes to the
 financial statements. The ASU on recognition and measurement will
 take effect for public companies for fiscal years beginning after
 December 15, 2017, including interim periods within those
 fiscal years. The Company is currently evaluating the impact
 of adoption of this update on its consolidated financial
 statements.

[0001193125-16-684108:notes:152]
In November 2015, the FASB
 issued ASU 2015-17, “Income Taxes (Topic 740): Balance Sheet
 Classification of Deferred Taxes”, which will require
 entities to present deferred tax assets (“DTA”) and
 deferred tax liabilities (“DTL”) as non-current in a
 classified balance sheet. The ASU simplifies the current guidance,
 which requires entities to separately present DTA and DTL as
 current and non-current in a classified balance sheet. For public
 companies, the amendments in this ASU are effective for financial
 statements issued for annual periods beginning after
 December 15, 2016, and interim periods within those annual
 periods. The Company has not yet adopted this update and does not
 expect that adoption will have a material effect on its
 consolidated financial statements.

[0001193125-16-684108:notes:153]
In July 2015, the FASB
 issued ASU 2015-11, “Inventory (Topic 330): Simplifying the
 Measurement of Inventory”. The update provides the guidance
 that an entity, that measured inventory by using first-in,
 first-out or average cost, should measure inventory at the lower of
 cost and net realizable value. Subsequent measurement is unchanged
 for inventory measured using last-in, first-out or the retail
 inventory method. For public companies, this update is effective
 for fiscal years beginning after December 15, 2016, including
 interim periods within these fiscal years. This update should be
 applied prospectively with earlier application permitted as of the
 beginning of an interim or annual reporting period. The Company is
 currently evaluating the impact of adoption of this update on its
 consolidated financial statements.

[0001193125-16-684108:notes:154]
In April 2015, the FASB
 issued ASU 2015-03, “Interest—Imputation of Interest
 (Subtopic 835-30): Simplifying the Presentation of Debt Issuance
 Costs”. The update requires debt issuance costs related to a
 recognized debt liability be presented in the balance sheet as a
 direct deduction from the carrying amount of the related debt
 liability instead of being presented as an asset. Debt disclosures
 will include the face amount of the debt liability and the
 effective interest rate. The update requires retrospective
 application and represents a change in accounting principle. In
 August 2015, the FASB issued ASU 2015-15 to address a presentation
 and subsequent measurement of debt issuance costs associated with
 line-of-credit arrangement. For public companies, the update is
 effective for fiscal years beginning after December 15, 2015.
 Early adoption is permitted for financial statements that have not
 been previously issued. The Company has not yet adopted this update
 and does not expect that adoption will have a material effect on
 its consolidated financial statements.

[0001193125-16-684108:notes:155]
In February 2015, the FASB
 issued ASU 2015-02, “Consolidation (Topic 810): Amendments to
 the Consolidation Analysis”. ASU No. 2015-02 amended the
 process that a reporting entity must perform to determine whether
 it should consolidate certain types of legal entities. For public
 companies, this amendment is effective for fiscal years, and for
 interim periods within those fiscal years beginning after
 December 15, 2015. Early adoption is permitted, including
 adoption in an interim period. The Company is currently evaluating
 the impact of adoption of this update on its consolidated financial
 statements.

[0001193125-16-684108:notes:156]
In January 2015, the FASB
 issued ASU No. 2015-01, “Income
 Statement—Extraordinary and Unusual Items (Subtopic 225-20):
 Simplifying Income Statement Presentation by Eliminating the
 Concept of Extraordinary Items”. The objective of this
 amendment is to reduce the complexity in accounting standards by
 eliminating the concept of extraordinary items from U.S. GAAP. The
 following criteria must both be met for extraordinary
 classification: (a) the underlying event or transaction should
 possess a high degree of abnormality and be of a type clearly
 unrelated to, or only incidentally related to, the ordinary and
 typical activities of the entity; and (b) the underlying event
 or transaction should not reasonably be expected to recur in the
 foreseeable future. This amendment is effective for fiscal years
 and interim periods beginning after December 15, 2015. Early
 adoption is permitted provided that the guidance is applied from
 the beginning of the fiscal year of adoption. The Company does not
 expect that adoption of this update will have an effect on its
 consolidated financial statements.

[0001193125-16-684108:notes:157]
In August 2014, the FASB
 issued ASU No. 2014-15, “Presentation of Financial
 Statements—Going Concern (Subtopic 205-40): Disclosure of
 Uncertainties about an Entity’s Ability to Continue as a
 Going Concern”. The amendments require management to
 evaluate, for each annual and interim reporting period, an
 entity’s ability to continue as a going concern when relevant
 conditions and events, considered in the aggregate, indicate that
 it is probable that the entity will be unable to meet its
 obligations that become due within one year after the date that the
 financial statements are issued (or available to be issued). This
 update is effective for annual periods and interim reporting
 periods beginning after December 15, 2016. Early adoption is
 permitted. The Company does not expect that adoption of this update
 will have an effect on its consolidated financial
 statements.

[0001193125-16-684108:notes:158]
In June 2014, the FASB
 issued ASU No. 2014-12, “Compensation—Stock
 Compensation (Topic 718): Accounting for Share-Based Payments When
 the Terms of an Award Provide That a Performance Target Could Be
 Achieved After the Requisite Service Period”. This ASU
 requires that a performance target that affects vesting, and that
 could be achieved after the requisite service period, be treated as
 a performance condition. As such, the performance target should not
 be reflected in estimating the grant date fair value of the award.
 Compensation cost should be recognized in the period in when
 performance target will probably be achieved and should be
 attributable to the period(s) for which the requisite service has
 already been rendered. This update is required to be adopted by all
 public companies for annual periods and interim reporting periods
 beginning after December 15, 2015, with early adoption
 permitted. The Company does not expect that adoption of this update
 will have an effect on its consolidated financial
 statements.

[0001193125-16-684108:notes:159]
In May 2014, the FASB
 issued ASU 2014-09, “Revenue from Contracts with Customers
 (Topic 606), issued as a new Topic, Accounting Standards
 Codification”. The core principle of this amendment is that
 an entity should recognize revenue to depict the transfer of
 promised goods or services to customers in an amount that reflects
 the consideration to which the entity expects to be entitled in
 exchange for those goods or services. This update is effective for
 public companies, as amended by ASU 2015-14, for annual reporting periods
 beginning after December 15, 2017, including interim periods
 within that reporting period. Earlier application of this guidance
 is permitted but not before the original date of December 15,
 2016, which can be adopted either retrospectively to each prior
 reporting period presented or as a cumulative-effect adjustment as
 of the date of adoption. Subsequently in March 2016 and April 2016,
 the FASB issued ASU 2016-08 and ASU 2016-10, to clarify the
 implementation guidance on principle versus agent considerations
 and address the potential diversity in practice at initial
 application and cost, and the complexity of applying Topic 606,
 both at transition and on an ongoing basis related to
 identification of performance obligations and licensing
 arrangements; and ASU 2016-12, in May 2016, to improve in certain
 aspects of Topic 606, with the same effective date as ASU 2015-14.
 The Company has not yet elected a transition method and is
 currently evaluating the impact of adoption of these updates on its
 consolidated financial statements.


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001193125-16-684108:notes:160]
| 5. | Cash, cash equivalents and marketable securities |

[0001193125-16-684108:notes:161]
The
 Company’s cash, cash equivalents,
 and marketable securities can be analyzed as
 follows:

[0001193125-16-684108:notes:162]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Gain |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of June 24, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 136,754 |  |  | $ | — |  |  | $ | 136,754 |  |  | $ | — |  |
| Cash equivalents |  |  | 6,050 |  |  |  | — |  |  |  | 6,050 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 112,128 |  |  |  | 394 |  |  |  | — |  |  |  | 112,522 |  |
| U.S. agency and U.S. treasury securities |  |  | 28,028 |  |  |  | 2 |  |  |  | — |  |  |  | 28,030 |  |
| Sovereign and municipal securities |  |  | 1,154 |  |  |  | 3 |  |  |  | — |  |  |  | 1,157 |  |
| Total |  | $ | 284,114 |  |  | $ | 399 |  |  | $ | 142,804 |  |  | $ | 141,709 |  |
|  |  |  |  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized (Loss)/Gain |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of June 26, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 105,548 |  |  | $ | — |  |  | $ | 105,548 |  |  | $ | — |  |
| Cash equivalents |  |  | 7,430 |  |  |  | — |  |  |  | 7,430 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 120,144 |  |  |  | (43 | ) |  |  | — |  |  |  | 120,101 |  |
| U.S. agency and U.S. treasury securities |  |  | 21,029 |  |  |  | (2 | ) |  |  | — |  |  |  | 21,027 |  |
| Sovereign and municipal securities |  |  | 1,737 |  |  |  | 1 |  |  |  | — |  |  |  | 1,738 |  |
| Total |  | $ | 255,888 |  |  | $ | (44 | ) |  | $ | 112,978 |  |  | $ | 142,866 |  |

[0001193125-16-684108:notes:163]
The cash
 equivalents include short-term bank deposits, investments in money
 market funds, and marketable securities with maturities of three
 months or less at the date of purchase. The effective interest rate
 on short term bank deposits was 0.7% and 0.7% per annum for
 the years ended June 24, 2016 and June 26, 2015,
 respectively.

[0001193125-16-684108:notes:164]
As of
 June 24, 2016, 66.0% of our cash and cash equivalents were
 held by the Parent Company.

[0001193125-16-684108:notes:165]
During the year
 ended June 24, 2016, the net realized loss from changes in
 fair value of marketable securities recognized by the Company was
 $0.2 million.

[0001193125-16-684108:notes:166]
As of
 June 24, 2016, the Company considered the declines in market
 value of its marketable securities investment portfolio to be
 temporary in nature and did not consider any of its securities
 other-than-temporarily impaired. The Company typically invests in
 highly-rated securities, and its investment policy generally limits
 the amount of credit exposure to any one issuer. The policy
 requires investments generally to be investment grade, with the
 primary objective of minimizing the potential risk of principal
 loss. Fair values were determined for each individual security in
 the investment portfolio. When evaluating an investment for
 other-than-temporary impairment, the Company reviews factors such
 as the length of time and extent to which fair value has been below
 its cost basis, the financial condition of the issuer and any
 changes thereto, changes in market interest rates, and the
 Company’s intent to sell, or whether it is more likely than
 not it will be required to sell, the investment before recovery of
 the investment’s cost basis. No impairment losses were
 recorded for the year ended June 24, 2016.

[0001193125-16-684108:notes:167]
As of
 June 24, 2016, cash, cash equivalents, and marketable
 securities included bank deposits of $40.0 million held in various
 financial institutions located in the United States in order to
 support the availability of the Facility Agreement and comply with
 covenants. Under the terms and conditions of the Facility
 Agreement, the Company shall maintain cash, cash equivalents and/or
 marketable securities in an aggregate amount not less than $40.0
 million in unencumbered deposits, and/or securities in accounts
 located in the United States at all times during the term of the
 Facility Agreement. As discussed in Note 11, the Company must
 comply with this covenant from and after the effective date of the
 Facility Agreement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-16-684108:notes:168]
| 3. | Income taxes |

[0001193125-16-684108:notes:169]
Cayman
 Islands

[0001193125-16-684108:notes:170]
Fabrinet is
 domiciled in the Cayman Islands. Under the current laws of the
 Cayman Islands, Fabrinet is not subject to tax in the Cayman
 Islands on income or capital gains. Fabrinet has received this
 undertaking for a 20-year period ending August 24, 2019, and
 after the expiration date, Fabrinet can make a request for renewal
 with the office of the Clerk of the Cabinet for another 20
 years.

[0001193125-16-684108:notes:171]
Income of the
 Company exempted from corporate income tax in the Cayman Islands
 amounted to $41.0 million, $27.0 million and $73.0 million in the
 years ended June 24, 2016, June 26, 2015 and
 June 27, 2014, respectively.

[0001193125-16-684108:notes:172]
Thailand

[0001193125-16-684108:notes:173]
Fabrinet
 Thailand is where the majority of the Company’s operations
 and production takes place. The Company is not subject to tax for
 the period from July 2010 through June 2015 on income generated
 from the manufacture of products at Pinehurst Building 5, and from
 July 2012 through June 2020 on income generated from the
 manufacture of products at Pinehurst Building 6. Such preferential
 tax treatment is contingent on, among other things, the export of
 the Company’s customers’ products out of Thailand and
 the Company’s agreement not to move its manufacturing
 facilities out of its current province in Thailand for at least 15
 years from the date on which preferential tax treatment was
 granted. In December 2011, the Thailand Revenue Department
 announced a reduction in corporate income tax rates for tax periods
 beginning on or after January 1, 2012. As a result of the
 announcement, enacted corporate income tax rates for Fabrinet
 Thailand were reduced from 23% in fiscal year 2013 to 20% in fiscal
 years 2014 through 2016. Additionally, in March 2016, the Thailand
 Revenue Department announced the permanent decrease of corporate
 income tax rates to 20% for tax periods beginning on or after
 January 1, 2016. As a result, corporate income tax rates for
 Fabrinet Thailand remain at 20% from fiscal year 2017
 onwards.

[0001193125-16-684108:notes:174]
People’s Republic of China

[0001193125-16-684108:notes:175]
Casix had
 been granted a tax privilege to reduce its corporate income tax
 rate from 25% to 15%, but the privilege expired on
 December 31, 2013. As a result, the corporate income tax rate
 for Casix has been 25% since January 2014.

[0001193125-16-684108:notes:176]
The
 reconciliation between the Company’s taxes that would arise
 by applying the statutory tax rate of the country of the
 Company’s principal operations, Thailand, to the
 Company’s effective tax charge is shown below:

[0001193125-16-684108:notes:177]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 24, 2016 |  |  | June 26, 2015 |  |  | June 27, 2014 |  |
| Income before income taxes (1) |  | $ | 68,232 |  |  | $ | 47,626 |  |  | $ | 93,170 |  |
| Tax expense calculated at a statutory corporate income tax rate of 20% (2015 and 2014: 20%) |  |  | 13,646 |  |  |  | 9,525 |  |  |  | 18,634 |  |
| Effect of income taxes from locations with tax rates different from Thailand |  |  | (6,631 | ) |  |  | 1,134 |  |  |  | (2 | ) |
| Income not subject to tax (2) |  |  | (2,289 | ) |  |  | (7,094 | ) |  |  | (15,648 | ) |
| Income tax on unremitted earnings (reversal of) |  |  | 741 |  |  |  | 1,263 |  |  |  | (259 | ) |
| Effect of different tax rate in relation to deferred tax utilization (3) |  |  | 894 |  |  |  | (221 | ) |  |  | (662 | ) |
| Effect of foreign exchange rate adjustment |  |  | 375 |  |  |  | (365 | ) |  |  | (380 | ) |
| Tax rebate from research and development application |  |  | (145 | ) |  |  | (102 | ) |  |  | — |  |
| Reversal of reserve fixed assets damaged from flooding |  |  | — |  |  |  | — |  |  |  | (251 | ) |
| Others |  |  | (256 | ) |  |  | (156 | ) |  |  | 7 |  |
| Corporate income tax expense |  | $ | 6,335 |  |  | $ | 3,984 |  |  | $ | 1,439 |  |

[0001193125-16-684108:notes:178]
| (1) | Income before income taxes was mostly generated from domestic income in the Cayman Islands. |

[0001193125-16-684108:notes:179]
| (2) | Income not subject to tax relates to income earned in the Cayman Islands and income subject to an investment promotion privilege for Building 5 and Building 6. Income not subject to tax per ordinary share on a diluted basis (in dollars) was $0.06, $0.20 and $0.44 for the years ended June 24, 2016, June 26, 2015 and June 27, 2014, respectively. |

[0001193125-16-684108:notes:180]
| (3) | The balances were effect of different tax rate in relation to the rate recognized deferred taxes during the fiscal year and the rate when deferred taxes will be utilized in the following fiscal years. |

[0001193125-16-684108:notes:181]
The
 Company’s deferred tax assets and deferred tax liabilities,
 net of valuation allowance, at each balance sheet date are as
 follows:

[0001193125-16-684108:notes:182]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 24, 2016 |  |  | June 26, 2015 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Depreciation |  | $ | 846 |  |  | $ | 1,057 |  |
| Severance liability |  |  | 955 |  |  |  | 1,192 |  |
| Reserve and allowance |  |  | 1,376 |  |  |  | 1,648 |  |
| Others |  |  | (13 | ) |  |  | 14 |  |
| Total |  | $ | 3,164 |  |  | $ | 3,911 |  |
|  |  | Years Ended |  |
| (amount in thousands) |  | June 24, 2016 |  |  | June 26, 2015 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Depreciation |  | $ | 833 |  |  | $ | — |  |
| Deferred tax from unremitted earning |  |  | (1,687 | ) |  |  | (737 | ) |
| Total |  |  | (854 | ) |  |  | (737 | ) |
| Net |  | $ | 2,310 |  |  | $ | 3,174 |  |

[0001193125-16-684108:notes:183]
Current
 deferred income tax assets and liabilities and non-current deferred
 income tax assets and liabilities are offset when the income taxes
 relate to the same tax jurisdiction. The following amounts are
 shown in the consolidated balance sheets:

[0001193125-16-684108:notes:184]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 24, 2016 |  |  | June 26, 2015 |  |
| Deferred income tax assets—current |  | $ | 1,358 |  |  | $ | 1,662 |  |
| Deferred income tax liabilities—current |  |  | — |  |  |  | — |  |
| Current deferred income tax—net |  |  | 1,358 |  |  |  | 1,662 |  |
| Deferred income tax assets—non current |  |  | 6,687 |  |  |  | 3,253 |  |
| Less: Valuation allowance |  |  | (4,881 | ) |  |  | (1,004 | ) |
| Deferred income tax liabilities—non current |  |  | (854 | ) |  |  | (737 | ) |
| Non-current deferred income tax—net |  |  | 952 |  |  |  | 1,512 |  |
| Net deferred income tax assets |  | $ | 2,310 |  |  | $ | 3,174 |  |

[0001193125-16-684108:notes:185]
As of
 June 24, 2016 and June 26, 2015, the Company recognized
 deferred tax assets of $4.9 million and $1.0 million, respectively,
 from tax on net operating loss carrying forward of Fabrinet West.
 Utilization of the tax net operating losses carrying forward may be
 subject to substantial limitations according to the
 subsidiary’s future operation, which may result in the
 reduced utilization of a portion of the Company’s net
 operating losses.

[0001193125-16-684108:notes:186]
Income tax
 liabilities have not been established for withholding tax and other
 taxes that would be payable on the unremitted earnings of Fabrinet
 Thailand. Such amounts of Fabrinet Thailand are permanently
 reinvested; unremitted earnings for Fabrinet Thailand totaled $68.8
 million and $50.9 million as of June 24, 2016 and
 June 26, 2015, respectively. Unrecognized deferred tax
 liabilities for such unremitted earnings were $4.2 million and $2.6
 million as of June 24, 2016 and June 26, 2015,
 respectively.

[0001193125-16-684108:notes:187]
Deferred tax
 liabilities of $0.7 million and $0.7 million have been established
 for withholding tax on the unremitted earnings of Casix, which are
 included in non-current deferred tax liability as of June 24,
 2016 and June 26, 2015, respectively.

[0001193125-16-684108:notes:188]
Uncertain income tax positions

[0001193125-16-684108:notes:189]
Interest and
 penalties related to uncertain tax positions are recognized in
 income tax expense. The Company had approximately $0.4 million and
 $0.2 million of accrued interest and penalties related to uncertain
 tax positions on the consolidated balance sheets as of
 June 24, 2016 and June 26, 2015, respectively. The
 Company recorded (reversed) interest and penalties of $0.2 million,
 $0.1 million, $(0.6 million) for the years ended June 24,
 2016, June 26, 2015 and June 27, 2014, respectively,
 in the consolidated statements of operations and comprehensive
 income. With regard to the Thailand jurisdiction, tax years 2011
 through 2015 remain open to examination by the local
 authorities.

[0001193125-16-684108:notes:190]
The following
 table indicates the changes to the Company’s uncertain income
 tax positions for the years ended June 24,
 2016, June 26, 2015 and June 27, 2014 included in
 other non-current liabilities.

[0001193125-16-684108:notes:191]
| (amount in thousands) |  | As of June 24, 2016 |  |  | As of June 26, 2015 |  |  | As of June 27, 2014 |  |
| Beginning balance |  | $ | 1,420 |  |  | $ | 868 |  |  | $ | 1,167 |  |
| Additions during the year |  |  | — |  |  |  | 552 |  |  |  | 510 |  |
| Reductions for tax positions of prior years |  |  | — |  |  |  | — |  |  |  | (809 | ) |
| Ending balance |  | $ | 1,420 |  |  | $ | 1,420 |  |  | $ | 868 |  |


## us-gaap:ScheduleOfAssumptionsUsedTableTextBlock

[0001193125-16-684108:notes:192]
The principal
 actuarial assumptions used were as follows:

[0001193125-16-684108:notes:193]
|  |  | Years Ended |  |
|  |  | June 24, 2016 |  | June 26, 2015 |  |  | June 27, 2014 |  |
| Discount rate |  | 2.0% - 3.2% |  |  | 4.0% |  |  |  | 4.9% |  |
| Future salary increases |  | 4.1% - 10.0% |  |  | 4.2% |  |  |  | 4.2% |  |


## us-gaap:ScheduleOfCreditLossesForFinancingReceivablesCurrentTableTextBlock

[0001193125-16-684108:notes:194]
The activities
 and balances for allowance for doubtful accounts were as
 follows:

[0001193125-16-684108:notes:195]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 24, 2016 |  |  | June 26, 2015 |  |  | June 27, 2014 |  |
| Balance, beginning of fiscal year |  | $ | 50 |  |  | $ | 37 |  |  | $ | 109 |  |
| Charged to consolidated statements of operations and comprehensive income |  |  | (17 | ) |  |  | 13 |  |  |  | (72 | ) |
| Balance, end of fiscal year |  | $ | 33 |  |  | $ | 50 |  |  | $ | 37 |  |


## us-gaap:ScheduleOfDebtTableTextBlock

[0001193125-16-684108:notes:196]
The
 Company’s total borrowings, including revolving and long-term
 borrowings, consisted of the following (dollars in
 thousands):

[0001193125-16-684108:notes:197]
| Rate (1) |  | Conditions |  |  | Maturity |  |  | As of June 24, 2016 |  |  | As of June 26, 2015 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  |  | Repayable in 1 to 6 months |  |  |  | July 2016 | (2) |  | $ | 6,500 |  |  | $ | 30,000 |  |
| Current portion of long-term borrowing |  |  |  |  |  |  |  |  |  |  | 18,100 |  |  |  | 6,000 |  |
|  |  |  |  |  |  |  |  |  |  | $ | 24,600 |  |  | $ | 36,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.80% per annum |  |  | Repayable in quarterly installments |  |  |  | March 2017 |  |  | $ | 4,500 |  |  | $ | 10,500 |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  |  | Repayable in quarterly installments |  |  |  | May 2019 |  |  |  | 50,000 |  |  |  | — |  |
|  |  |  |  |  |  |  |  |  |  |  | 54,500 |  |  |  | 10,500 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (18,100 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  |  |  |  |  |  |  |  | $ | 36,400 |  |  | $ | 4,500 |  |

[0001193125-16-684108:notes:198]
|  | (1) | LIBOR is London Interbank Offered Rate. |

[0001193125-16-684108:notes:199]
|  | (2) | In July 2016, the maturity date of this revolving borrowing was extended to mature in August 2016. |


## us-gaap:ScheduleOfDefinedBenefitPlansDisclosuresTextBlock

[0001193125-16-684108:notes:200]
The following
 table provides the information of the severance
 liabilities:

[0001193125-16-684108:notes:201]
| (amount in thousands) |  | As of June 24, 2016 |  |  | As of June 26, 2015 |  |
| Balance, beginning of the fiscal year |  | $ | 5,477 |  |  | $ | 4,453 |  |
| Charged to selling, general and administrative expenses in the consolidated statements of operations and comprehensive income |  |  | 1,207 |  |  |  | 1,024 |  |
| Balance, end of the fiscal year |  | $ | 6,684 |  |  | $ | 5,477 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001193125-16-684108:notes:202]
As of
 June 24, 2016, the future maturities of long-term debt during
 each fiscal year were as follows:

[0001193125-16-684108:notes:203]
| (amount in thousand) |  |  |  |
| 2017 |  | $ | 18,100 |  |
| 2018 |  |  | 13,600 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 54,500 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001193125-16-684108:notes:204]
Total revenues,
 by percentage, from individual customers representing 10% or more
 of total revenues in the respective periods were as
 follows:

[0001193125-16-684108:notes:205]
|  |  | Years Ended |  |
|  |  | June 24, 2016 |  |  | June 26, 2015 |  |  | June 27, 2014 |  |
| Lumentum Operations LLC |  |  | 20 | % |  |  | 20 | % |  |  | 24 | % |
| Oclaro, Inc. |  |  | * | (1) |  |  | 10 | % |  |  | 22 | % |

[0001193125-16-684108:notes:206]
|  | (1) | Less than 10% of total revenue. |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-16-684108:notes:207]
As of
 June 24, 2016, the estimated future amortization of intangible
 assets during each fiscal year was as follows:

[0001193125-16-684108:notes:208]
| (amount in thousand) |  |  |  |
| 2017 |  | $ | 114 |  |
| 2018 |  |  | 113 |  |
| 2019 |  |  | 113 |  |
| 2020 |  |  | 109 |  |
| 2021 |  |  | 50 |  |
| Total |  | $ | 499 |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-16-684108:notes:209]
| 16. | Accumulated other comprehensive income (loss) |


## us-gaap:DebtDisclosureTextBlock

[0001193125-16-684108:notes:210]
| 11. | Borrowings |

[0001193125-16-684108:notes:211]
The long-term
 loan of a subsidiary is secured by certain property, plant and
 equipment. The carrying amount of assets secured and pledged as
 collateral as of June 24, 2016 and June 26, 2015 was
 $47.7 million and $50.0 million, respectively. This subsidiary is
 also required to comply with the maximum ratios of debt to equity
 and minimum levels of debt service coverage ratios, and Fabrinet
 must maintain an effective shareholding ratio. The carrying amounts
 of bank borrowings approximate their fair value.

[0001193125-16-684108:notes:212]
As of
 June 24, 2016 and June 26, 2015, the Company was in
 compliance with its long-term bank borrowing agreement. In addition
 to financial ratios, certain of the Company’s credit
 facilities include customary events of default.

[0001193125-16-684108:notes:213]
Credit
 facilities:

[0001193125-16-684108:notes:214]
The Company
 entered into a syndicated senior credit facility agreement (the
 “Facility Agreement”) with a consortium of banks on
 May 22, 2014. The Facility Agreement, led by Bank of America,
 provides for a $200.0 million credit line, comprised of a $150.0
 million revolving loan facility and a $50.0 million delayed draw
 term loan facility. The revolving loan facility contains an
 accordion feature permitting Fabrinet to request an increase in the
 facility up to $100.0 million subject to customary terms and
 conditions and provided that no default or event of default exists
 at the time of request. The revolving loan facility terminates and
 all amounts outstanding are due and payable in full on May 22,
 2019. The principal amount of any drawn term loans must be repaid
 according to the scheduled quarterly amortization payments, with
 final payment of all amounts outstanding, plus accrued interest,
 being due on May 22, 2019.

[0001193125-16-684108:notes:215]
On
 February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allows the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. As of
 June 24, 2016, there were the $6.5 million of revolving
 borrowing and $50.0 million of term loan borrowing outstanding
 under the Facility Agreement, resulting in available credit
 facilities of $143.5 million. Borrowings under the revolving credit
 facility are classified as current liabilities in the audited
 consolidated balance sheet as the Company has the periodic option
 to renew or pay, all or a portion of, the outstanding balance at
 the end of the maturity date, which is in the range of one to six
 months, without premium or penalty, upon notice to the
 administrative agent. Subsequent to the balance sheet date, the
 Company sent a notice to the bank to renew the maturity date of
 this revolving borrowing. The bank approved the notice and extended
 the maturity to August 2016.

[0001193125-16-684108:notes:216]
Loans under
 the Facility Agreement bear interest, at Fabrinet’s option,
 at a rate per annum equal to a LIBOR rate plus a spread of 1.75% to
 2.50%, or a base rate, determined in accordance with the Facility
 Agreement, plus a spread of 0.75% to 1.50%, in each case with such
 spread determined based on Fabrinet’s consolidated total
 leverage ratio for the preceding four fiscal quarter period.
 Interest is due and payable quarterly in arrears for loans bearing
 interest at the base rate and at the end of an interest period (or
 at each three-month interval in the case of loans with interest
 periods greater than three months) in the case of loans bearing
 interest at the LIBOR rate.

[0001193125-16-684108:notes:217]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or the
 equivalent under the local law, can be effected. The Facility
 Agreement contains customary affirmative and negative covenants.
 Negative covenants include, among other things, limitations on
 liens, indebtedness, investments, mergers, sales of assets, changes
 in the nature of the business, dividends and distributions,
 affiliate transactions and capital expenditures. The Facility
 Agreement contains financial covenants requiring Fabrinet to
 maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage
 ratio of not more than 2.50:1.00; and (iv) a minimum quick
 ratio of not less than 1.10:1.00. Each of these financial covenants
 is calculated on a consolidated basis for the consecutive four
 fiscal quarter period then ended. As of June 24, 2016, the
 Company was in compliance with all covenants under the Facility
 Agreement.

[0001193125-16-684108:notes:218]
The Facility
 Agreement also contains customary events of default including,
 among other things, payment defaults, breaches of covenants or
 representations and warranties, cross-defaults with certain other
 indebtedness, bankruptcy and insolvency events and change in
 control of Fabrinet, subject to grace periods in certain instances.
 Upon an event of default, the lenders may terminate their
 commitments, declare all or a portion of the outstanding
 obligations payable by Fabrinet to be immediately due and payable
 and exercise other rights and remedies provided for under the
 Facility Agreement.

[0001193125-16-684108:notes:219]
Fabrinet
 intends to use the proceeds of the credit line to finance its
 future expansion in the United States and Thailand, and for general
 corporate purposes including mergers and acquisitions of
 complementary manufacturing businesses or technology, although
 Fabrinet has no current commitments with respect to any such
 acquisitions.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-16-684108:notes:220]
| 19. | Financial instruments |

[0001193125-16-684108:notes:221]
Objectives and significant terms and
 conditions

[0001193125-16-684108:notes:222]
The principal
 financial risks faced by the Company are foreign currency risk and
 interest rate risk. The Company borrows at floating rates of
 interest to finance its operations. A minority of sales and
 purchases and a majority of labor and overhead costs are entered
 into in foreign currencies. In order to manage the risks arising
 from fluctuations in currency exchange rates, the Company uses
 derivative instruments. Trading for speculative purposes is
 prohibited under Company policies.

[0001193125-16-684108:notes:223]
The Company
 enters into short-term foreign currency forward and option
 contracts to manage foreign currency exposures associated with
 certain assets, liabilities and other forecasted foreign currency
 transactions and may designate these instruments as hedging
 instruments. The foreign currency forward and option contracts
 generally have maturity of up to six months. All foreign currency
 exchange contracts are recognized on the consolidated balance
 sheets at fair value. Gain or loss on the Company’s
 derivative instruments generally offset the assets, liabilities and
 transactions economically hedged.

[0001193125-16-684108:notes:224]
Foreign
 currency risk

[0001193125-16-684108:notes:225]
The Company
 operates internationally and is exposed to foreign exchange risk
 arising from various currency exposures primarily with respect to
 the Thai baht and Chinese Renminbi (“RMB”).

[0001193125-16-684108:notes:226]
As of
 June 24, 2016 and June 26, 2015, the Company had
 outstanding foreign currency assets and liabilities as
 follows:

[0001193125-16-684108:notes:227]
|  |  | As of June 24, 2016 |  |  | As of June 26, 2015 |  |
| (amount in thousands) |  | Currency |  |  | $ |  |  | Currency |  |  | $ |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 834,536 |  |  | $ | 23,594 |  |  |  | 377,785 |  |  | $ | 11,596 |  |
| RMB |  |  | 14,835 |  |  |  | 2,255 |  |  |  | 67,455 |  |  |  | 11,029 |  |
| Total |  |  |  |  |  | $ | 25,849 |  |  |  |  |  |  | $ | 22,625 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,517,782 |  |  | $ | 42,912 |  |  |  | 860,425 |  |  | $ | 26,410 |  |
| RMB |  |  | 24,654 |  |  |  | 3,748 |  |  |  | 20,461 |  |  |  | 3,347 |  |
| Total |  |  |  |  |  | $ | 46,660 |  |  |  |  |  |  | $ | 29,757 |  |

[0001193125-16-684108:notes:228]
The Thai baht
 assets represent cash and cash equivalents, accounts receivable,
 deposits and other current assets. The Thai baht liabilities
 represent trade accounts payable, accrued expenses and other
 payables. The Company manages its exposure to fluctuations in
 foreign exchange rates by the use of foreign currency contracts and
 offsetting assets and liabilities denominated in the same currency
 in accordance with management’s policy. As of June 24,
 2016 and June 26, 2015, there was $84.5 million in forward
 contracts and $41.0 million in options contracts, respectively,
 outstanding on the Thai baht payables.

[0001193125-16-684108:notes:229]
The RMB assets
 represent cash and cash equivalents, accounts receivable and other
 current assets. The RMB liabilities represent trade accounts
 payable, accrued expenses and other payables. As of June 24,
 2016 and June 26, 2015, there were no selling RMB to U.S.
 dollar forward contracts outstanding.

[0001193125-16-684108:notes:230]
For fiscal year
 2016 and fiscal year 2015, we recorded unrealized loss of $1.8
 million and $0.4 million, respectively, related to derivatives that
 are not designated as hedging instruments in our consolidated
 statements of operations and comprehensive income.

[0001193125-16-684108:notes:231]
Interest
 Rate Risk

[0001193125-16-684108:notes:232]
The
 Company’s principal interest bearing assets are time deposits
 and short-term investments with maturities of three months or less
 held with high quality financial institutions. The Company’s
 principal interest bearing liabilities are bank loans which bear
 interest at floating rates.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-16-684108:notes:233]
| 10. | Intangibles |

[0001193125-16-684108:notes:234]
The following
 tables present details of the Company’s
 intangibles:

[0001193125-16-684108:notes:235]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net |  |
| As of June 24, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 3,786 |  |  | $ | (3,287 | ) |  | $ | 499 |  |
| Total intangibles |  | $ | 3,786 |  |  | $ | (3,287 | ) |  | $ | 499 |  |
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net |  |
| As of June 26, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 3,357 |  |  | $ | (3,220 | ) |  | $ | 137 |  |
| Total intangibles |  | $ | 3,357 |  |  | $ | (3,220 | ) |  | $ | 137 |  |

[0001193125-16-684108:notes:236]
The Company
 recorded amortization expense relating to intangibles of $0.1
 million for each of the years ended June 24,
 2016, June 26, 2015 and June 27, 2014,
 respectively.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-16-684108:notes:237]
| 14. | Employee benefit plans |

[0001193125-16-684108:notes:238]
Employee
 contribution plan

[0001193125-16-684108:notes:239]
The Company
 operates a defined contribution plan, known as a provident fund, in
 its subsidiary in Thailand. The assets of this plan are in a
 separate trustee-administered fund. The provident fund is funded by
 matching payments from employees and by the subsidiary on a monthly
 basis. Current contributions to the provident fund are accrued and
 paid to the fund manager on a monthly basis. The Company’s
 contributions to the provident fund amounted to $2.8 million, $2.3
 million and $2.1 million during the years ended June 24,
 2016, June 26, 2015 and June 27, 2014,
 respectively.

[0001193125-16-684108:notes:240]
The Company
 sponsors the Fabrinet U.S. 401(k) Retirement Plan (“401(k)
 Plan”), a Defined Contribution Plan under ERISA, at its
 subsidiaries in the United States which provides retirement
 benefits for eligible employees through tax deferred salary
 deductions. The 401(k) Plan allows employees to contribute up
 to 80% of their annual compensation, subject to annual
 contributions limits established by the Internal Revenue Service.
 The Company provides for a 100% match of employees’
 contributions to the 401(k) Plan up to the first 6% of annual
 compensation. All matching contributions are made in cash and vest
 immediately. The Company’s matching contributions to the
 401(k) Plan were $0.5 million, $0.3 million and $0.2 million during
 the years ended June 24, 2016, June 26, 2015 and
 June 27, 2014, respectively.

[0001193125-16-684108:notes:241]
Executive
 incentive plan and employee performance bonuses

[0001193125-16-684108:notes:242]
For the years
 ended June 24, 2016 and June 26, 2015, the Company
 maintained an executive incentive plan with quantitative
 objectives, based on achieving certain revenue and non-GAAP
 earnings per share targets as well as qualitative objectives, based
 on achieving individual performance goals for the applicable fiscal
 year. For the year ended June 27, 2014, the Company maintained
 an executive incentive plan with quantitative objectives, based on
 achieving certain revenue and gross margin targets as well as
 qualitative objectives, based on achieving individual performance
 goals for the fiscal year. During the years ended June 24,
 2016, June 26, 2015 and June 27, 2014, discretionary
 merit-based bonus awards were also available to Fabrinet’s
 non-executive employees.

[0001193125-16-684108:notes:243]
Bonus
 distributions to employees were $7.5 million, $6.0 million and $5.1
 million for the years ended June 24, 2016, June 26,
 2015 and June 27, 2014, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001193125-16-684108:notes:244]
| 9. | Property, plant and equipment, net |

[0001193125-16-684108:notes:245]
The components
 of property, plant and equipment, net were as follows:

[0001193125-16-684108:notes:246]
| (amount in thousands) |  | Land |  |  | Building and Building Improvement |  |  | Manufacturing Equipment |  |  | Office Equipment |  |  | Motor Vehicles |  |  | Computers |  |  | Construction and Machinery Under Installation |  |  | Total |  |
| As of June 24, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost |  | $ | 39,048 |  |  | $ | 95,386 |  |  | $ | 96,041 |  |  | $ | 5,826 |  |  | $ | 443 |  |  | $ | 15,578 |  |  | $ | 23,248 |  |  | $ | 275,570 |  |
| Less: Accumulated depreciation |  |  | — |  |  |  | (25,438 | ) |  |  | (56,564 | ) |  |  | (3,500 | ) |  |  | (366 | ) |  |  | (11,292 | ) |  |  | — |  |  |  | (97,160 | ) |
| Net book value |  | $ | 39,048 |  |  | $ | 69,948 |  |  | $ | 39,477 |  |  | $ | 2,326 |  |  | $ | 77 |  |  | $ | 4,286 |  |  | $ | 23,248 |  |  | $ | 178,410 |  |
| As of June 26, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost |  | $ | 26,672 |  |  | $ | 86,926 |  |  | $ | 79,825 |  |  | $ | 5,378 |  |  | $ | 528 |  |  | $ | 13,196 |  |  | $ | 10,198 |  |  | $ | 222,723 |  |
| Less: Accumulated depreciation |  |  | — |  |  |  | (21,016 | ) |  |  | (47,017 | ) |  |  | (3,343 | ) |  |  | (458 | ) |  |  | (10,235 | ) |  |  | — |  |  |  | (82,069 | ) |
| Net book value |  | $ | 26,672 |  |  | $ | 65,910 |  |  | $ | 32,808 |  |  | $ | 2,035 |  |  | $ | 70 |  |  | $ | 2,961 |  |  | $ | 10,198 |  |  | $ | 140,654 |  |

[0001193125-16-684108:notes:247]
During the year
 ended June 24, 2016, the Company purchased a parcel of land in
 Chonburi, Thailand, with an aggregate purchase price of
 approximately $12.4 million, to support the expansion of its
 production capacity and capabilities in Thailand. During the year
 ended June 26, 2015, one of Fabrinet’s subsidiaries
 purchased a building and the associated land located in Santa
 Clara, California, for an aggregate purchase price of $25.5
 million, to expand the Company’s manufacturing facilities in
 the United States.

[0001193125-16-684108:notes:248]
Depreciation
 expense amounted to $17.3 million, $12.9 million and $10.6 million
 for the years ended June 24, 2016, June 26, 2015 and
 June 27, 2014, respectively, and have been allocated between
 cost of revenues and selling, general and administrative expenses
 in the consolidated statements of operations and comprehensive
 income. During the year ended June 27, 2014, the Company
 wrote-off all assets damaged from flood and reversed all asset
 impairment reserve as the Company fully settled with insurance
 companies for the Company’s damaged assets claim.

[0001193125-16-684108:notes:249]
The cost of
 fully depreciated property, plant and equipment written-off during
 the years ended June 24, 2016, June 26, 2015 and
 June 27, 2014 amounted to $2.0 million, $1.1 million and $2.6
 million, respectively.

[0001193125-16-684108:notes:250]
During the year
 ended June 24, 2016, the Company capitalized $0.1 million of
 interest expense in construction in progress of its new
 manufacturing building at Chonburi Campus. There was no interest
 expense capitalized in construction in progress during the year
 ended June 26, 2015.


## us-gaap:ScheduleOfAmountsRecognizedInBalanceSheetTableTextBlock

[0001193125-16-684108:notes:251]
The amount
 recognized in the consolidated balance sheets under non-current
 liabilities was determined as follows:

[0001193125-16-684108:notes:252]
| (amount in thousands) |  | As of June 24, 2016 |  |  | As of June 26, 2015 |  |
| Present value of defined benefit obligation |  | $ | 6,684 |  |  | $ | 5,477 |  |
| Total |  | $ | 6,684 |  |  | $ | 5,477 |  |


## us-gaap:ScheduleOfNetBenefitCostsTableTextBlock

[0001193125-16-684108:notes:253]
The amount
 recognized in the consolidated statements of operations and
 comprehensive income was as follows:

[0001193125-16-684108:notes:254]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 24, 2016 |  |  | June 26, 2015 |  |  | June 27, 2014 |  |
| Current service cost |  | $ | 842 |  |  | $ | 360 |  |  | $ | 368 |  |
| Interest cost |  |  | 203 |  |  |  | 203 |  |  |  | 207 |  |
| Benefit paid |  |  | (11 | ) |  |  | (10 | ) |  |  | (223 | ) |
| Actuarial loss (gain) on obligation |  |  | 173 |  |  |  | 471 |  |  |  | (281 | ) |
| Total |  | $ | 1,207 |  |  | $ | 1,024 |  |  | $ | 71 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-16-684108:notes:255]
| 15. | Shareholders’ equity |

[0001193125-16-684108:notes:256]
Fabrinet’s
 authorized share capital is 500,000,000 ordinary shares, par value
 of $0.01 per ordinary share, and 5,000,000 preferred shares, par
 value of $0.01 per preferred share.

[0001193125-16-684108:notes:257]
For the year
 ended June 24, 2016, Fabrinet issued 325,530 ordinary shares
 upon the exercise of options, for cash consideration at a weighted
 average exercise price of $16.83 per share, and 393,262 ordinary
 shares upon the vesting of restricted share units, net of shares
 withheld.

[0001193125-16-684108:notes:258]
For the year
 ended June 26, 2015, Fabrinet issued 56,968 ordinary shares
 upon the exercise of options, for cash consideration at a weighted
 average exercise price of $14.67 per share, and 227,914 ordinary
 shares upon the vesting of restricted share units, net of shares
 withheld.

[0001193125-16-684108:notes:259]
For the year
 ended June 27, 2014, Fabrinet issued 351,435 ordinary shares
 upon the exercise of options, for cash consideration at a weighted
 average exercise price of $13.00 per share, and 166,370 ordinary
 shares upon the vesting of restricted share units, net of shares
 withheld.

[0001193125-16-684108:notes:260]
All such issued
 shares are fully paid.


## us-gaap:EarningsPerShareTextBlock

[0001193125-16-684108:notes:261]
| 4. | Earnings per ordinary share |

[0001193125-16-684108:notes:262]
Basic earnings
 per ordinary share is computed by dividing reported net income by
 the weighted average number of ordinary shares outstanding during
 each period. Diluted earnings per ordinary share is computed by
 dividing reported net income by the weighted average number of
 ordinary shares and dilutive ordinary equivalent shares outstanding
 during each period. Dilutive ordinary equivalent shares consist of
 share options and restricted share units. The earnings per ordinary
 share was calculated as follows:

[0001193125-16-684108:notes:263]
|  |  | Years Ended |  |
| (amount in thousands except per share amounts) |  | June 24, 2016 |  |  | June 26, 2015 |  |  | June 27, 2014 |  |
| Net income attributable to shareholders |  | $ | 61,897 |  |  | $ | 43,642 |  |  | $ | 91,731 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  | 35,857 |  |  |  | 35,354 |  |  |  | 34,938 |  |
| Incremental shares arising from the assumed exercise of share options and vesting of restricted share units (thousands of shares) |  |  | 1,015 |  |  |  | 630 |  |  |  | 651 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 36,872 |  |  |  | 35,984 |  |  |  | 35,589 |  |
| Basic earnings per ordinary share |  | $ | 1.73 |  |  | $ | 1.23 |  |  | $ | 2.63 |  |
| Diluted earnings per ordinary share |  | $ | 1.68 |  |  | $ | 1.21 |  |  | $ | 2.58 |  |
| Outstanding share options excluded in the computation of diluted earnings per ordinary share (1) |  |  | — |  |  |  | 39,544 |  |  |  | 44,369 |  |

[0001193125-16-684108:notes:264]
| (1) | These share options were not included in the computation of diluted earnings per ordinary share because the exercise price of the options was greater than the average market price of the underlying shares. |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001193125-16-684108:notes:265]
The following
 tables provide details of the financial instruments measured at
 fair value on a recurring basis, including:

[0001193125-16-684108:notes:266]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 24, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 6,050 |  |  | $ | — |  |  | $ | 6,050 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 112,522 |  |  |  | — |  |  |  | 112,522 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 28,030 |  |  |  | — |  |  |  | 28,030 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 1,157 |  |  |  | — |  |  |  | 1,157 |  |
| Derivative assets |  |  | — |  |  |  | 158 | (1) |  |  | — |  |  |  | 158 |  |
| Total |  | $ | — |  |  | $ | 147,917 |  |  | $ | — |  |  | $ | 147,917 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 1,754 | (2) |  | $ | — |  |  | $ | 1,754 |  |
| Total |  | $ | — |  |  | $ | 1,754 |  |  | $ | — |  |  | $ | 1,754 |  |

[0001193125-16-684108:notes:267]
| (1) | Foreign currency forward contract with notional amount of $7.0 million. |

[0001193125-16-684108:notes:268]
| (2) | Foreign currency forward contract with notional amount of $77.5 million and Canadian dollars 0.6 million. |

[0001193125-16-684108:notes:269]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 26, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 7,430 |  |  | $ | — |  |  | $ | 7,430 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 120,101 |  |  |  | — |  |  |  | 120,101 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 21,027 |  |  |  | — |  |  |  | 21,027 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 1,738 |  |  |  | — |  |  |  | 1,738 |  |
| Derivative assets |  |  | — |  |  |  | 4 | (1) |  |  | — |  |  |  | 4 |  |
| Total |  | $ | — |  |  | $ | 150,300 |  |  | $ | — |  |  | $ | 150,300 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 371 | (2) |  | $ | — |  |  | $ | 371 |  |
| Total |  | $ | — |  |  | $ | 371 |  |  | $ | — |  |  | $ | 371 |  |

[0001193125-16-684108:notes:270]
| (1) | Foreign currency options with notional amount of $3.0 million and forward contracts with notional amount of Canadian dollars 0.4 million. |

[0001193125-16-684108:notes:271]
| (2) | Foreign currency options with notional amount of $38.0 million. |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-16-684108:notes:272]
| 6. | Fair Value |

[0001193125-16-684108:notes:273]
Derivative Financial
 Instruments

[0001193125-16-684108:notes:274]
As a result of foreign
 currency rate fluctuations, the U.S. dollar equivalent values of
 the Company’s foreign currency denominated assets and
 liabilities change. The Company uses foreign currency contracts to
 manage the foreign exchange risk associated with certain foreign
 currency denominated assets and liabilities and other foreign
 currency transactions. The Company minimizes the credit risk in
 derivative instruments by limiting its exposure to any single
 counterparty and by entering into derivative instruments only with
 counterparties that meet the Company’s minimum credit quality
 standard. As of June 24, 2016, the Company recognized the fair
 value of foreign currency forward contracts of $0.2 million as
 derivative assets and $1.7 million as derivative liabilities. As of
 June 26, 2015, the Company recognized the fair value of
 foreign currency forward contracts and options of $0.4 million as
 derivative liabilities in the consolidated balance
 sheets.

[0001193125-16-684108:notes:275]
As of June 24, 2016,
 the Company hedges forecasted foreign currency transactions related
 to the construction costs of a new manufacturing building at the
 Company’s Chonburi Campus with certain forward contracts,
 designated as cash flow hedges. The Company had two outstanding
 forward contracts with notional amount of $7.0 million, which
 mature during August 2016 and September 2016. The Company included
 unrealized gain of $0.2 million from changes in fair value of these
 foreign currency forward contracts, designated as hedging
 instrument in AOCI in the consolidated balance sheets. As of
 June 24, 2016, gain of $0.01 million in AOCI is expected to be
 reclassified as earning within the next 12 months. During the year
 ended June 24, 2016, there was no ineffective portion or
 discontinued cash flow hedges recognized in the consolidated
 statements of operations and comprehensive income. As of
 June 26, 2015, the Company had no foreign currency forward
 contracts designated as cash flow hedges.

[0001193125-16-684108:notes:276]
As of June 24, 2016,
 the Company had 14 outstanding foreign currency forward contracts
 with notional amount of $77.5 million and Canadian dollars
 0.6 million, which matured during July to December 2016. These
 foreign currency forward contracts were not designated for hedge
 accounting and were used to hedge fluctuations in the U.S. dollar
 value of forecasted transactions denominated in Thai baht and
 Canadian dollar. During the year ended June 24, 2016, the
 Company included unrealized loss of $1.8 million from changes in
 fair value of foreign currency contracts in the consolidated
 statements of operations and comprehensive
 income.

[0001193125-16-684108:notes:277]
As of June 26, 2015,
 the Company had 42 outstanding foreign currency forward contracts
 and options with notional amount of $41.0 million and Canadian
 dollars 0.4 million, which matured during June to December
 2015. These foreign currency forward contracts and options were not
 designated for hedge accounting and were used to hedge fluctuations
 in the U.S. dollar value of forecasted transactions denominated in
 Thai baht and Canadian dollar. During the year ended June 26,
 2015, the Company included unrealized loss of $0.4 million from
 changes in fair value of foreign currency contracts in the
 consolidated statements of operations and comprehensive
 income.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001193125-16-684108:notes:278]
UNAUDITED
 QUARTERLY FINANCIAL INFORMATION

[0001193125-16-684108:notes:279]
The following
 tables set forth a summary of the Company’s quarterly
 financial information for each of the four quarters in the fiscal
 years ended June 24, 2016 and June 26, 2015:

[0001193125-16-684108:notes:280]
|  |  | Three Months Ended |  |
| (in thousands, except per share data) |  | Jun 24, 2016 |  |  | Mar 25, 2016 |  |  | Dec 25, 2015 |  |  | Sep 25, 2015 |  |  | Jun 26, 2015 |  |  | Mar 27, 2015 |  |  | Dec 26, 2014 |  |  | Sep 26, 2014 |  |
| Total revenues |  | $ | 276,388 |  |  | $ | 250,888 |  |  | $ | 233,038 |  |  | $ | 216,433 |  |  | $ | 206,456 |  |  | $ | 189,453 |  |  | $ | 188,353 |  |  | $ | 189,325 |  |
| Gross profit |  | $ | 33,842 |  |  | $ | 31,177 |  |  | $ | 28,493 |  |  | $ | 26,011 |  |  | $ | 24,549 |  |  | $ | 21,657 |  |  | $ | 21,061 |  |  | $ | 20,506 |  |
| Net income |  | $ | 19,669 |  |  | $ | 20,822 |  |  | $ | 19,803 |  |  | $ | 1,603 |  |  | $ | 13,035 |  |  | $ | 10,845 |  |  | $ | 8,726 |  |  | $ | 11,036 |  |
| Basic net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 0.55 |  |  | $ | 0.58 |  |  | $ | 0.55 |  |  | $ | 0.05 |  |  | $ | 0.37 |  |  | $ | 0.31 |  |  | $ | 0.25 |  |  | $ | 0.31 |  |
| Weighted-average shares used in basic net income per share calculations |  |  | 36,075 |  |  |  | 35,964 |  |  |  | 35,812 |  |  |  | 35,579 |  |  |  | 35,431 |  |  |  | 35,406 |  |  |  | 35,349 |  |  |  | 35,230 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 0.53 |  |  | $ | 0.56 |  |  | $ | 0.54 |  |  | $ | 0.04 |  |  | $ | 0.36 |  |  | $ | 0.30 |  |  | $ | 0.24 |  |  | $ | 0.31 |  |
| Weighted-average shares used in diluted net income per share calculations |  |  | 37,258 |  |  |  | 37,089 |  |  |  | 36,826 |  |  |  | 36,315 |  |  |  | 36,320 |  |  |  | 36,110 |  |  |  | 35,917 |  |  |  | 35,587 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001193125-16-684108:notes:281]
The following
 table presents revenues by end market:

[0001193125-16-684108:notes:282]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 24, 2016 |  |  | June 26, 2015 |  |  | June 27, 2014 |  |
| Optical communications |  | $ | 727,580 |  |  | $ | 553,245 |  |  | $ | 484,071 |  |
| Lasers, sensors, and other |  |  | 249,167 |  |  |  | 220,342 |  |  |  | 193,783 |  |
| Total |  | $ | 976,747 |  |  | $ | 773,587 |  |  | $ | 677,854 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-16-684108:notes:283]
| 18. | Business segments and geographic information |

[0001193125-16-684108:notes:284]
Operating
 segments are defined as components of an enterprise for which
 separate financial information is available that is evaluated
 regularly by the chief operating decision maker in deciding how to
 allocate resources and in assessing performance. The
 Company’s chief operating decision maker is Fabrinet’s
 chief executive officer. As of June 24,
 2016, June 26, 2015 and June 27, 2014, the Company
 operated and internally managed a single operating segment.
 Accordingly, the Company does not accumulate discrete information
 with respect to separate product lines and does not have separate
 reportable segments.

[0001193125-16-684108:notes:285]
Total revenues
 are attributed to a particular geographic area based on the
 bill-to-location of the customer. The Company operates primarily in
 three geographic regions: North America, Asia-Pacific and Europe.
 The following table presents total revenues by geographic
 regions:

[0001193125-16-684108:notes:286]
As of
 June 24, 2016 and June 26, 2015, the Company had
 approximately $34.7 million and $31.8 million, respectively, of
 long-lived assets based in North America, with the substantial
 remainder of assets based in Asia-Pacific.

[0001193125-16-684108:notes:287]
Significant customers

[0001193125-16-684108:notes:288]
Accounts
 receivable from individual customers representing 10% or more of
 accounts receivable as of June 24, 2016, June 26,
 2015 and June 27, 2014, respectively, were as
 follows:

[0001193125-16-684108:notes:289]
|  |  | Years Ended |  |
|  |  | June 24, 2016 |  |  | June 26, 2015 |  |  | June 27, 2014 |  |
| Lumentum Operations LLC |  |  | 18 | % |  |  | 19 | % |  |  | 23 | % |
| Valeo |  |  | 11 | % |  |  | 11 | % |  |  | 10 | % |
| Oclaro, Inc. |  |  | * | (1) |  |  | * | (1) |  |  | 14 | % |

[0001193125-16-684108:notes:290]
|  | (1) | Less than 10% of total accounts receivable. |


## us-gaap:SubsequentEventsTextBlock

[0001193125-16-684108:notes:291]
| 22. | Subsequent event |

[0001193125-16-684108:notes:292]
Separation agreement

[0001193125-16-684108:notes:293]
During August
 2016, the Company incurred severance expenses of approximately $0.7
 million in connection with a separation agreement which the Company
 entered into with an employee who resigned in July 2016.


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001193125-16-684108:notes:294]
| 20. | Income related to flooding |

[0001193125-16-684108:notes:295]
During the
 week of August 10, 2015, the Company’s subsidiary in
 China temporarily suspended production in its manufacturing
 facility due to flooding caused by Typhoon Soudelor and resumed
 operations on August 15, 2015. During the year ended
 June 24, 2016, the Company recognized income related to
 flooding of $0.04 million, which consisted of a $0.90 million final
 payment from an insurer against the Company’s claim for flood
 damage, offset by expenses in relation to flood of $0.86 million,
 which mainly consisted of $0.6 million of repaired cost of
 equipment and $0.2 million of inventory losses.

[0001193125-16-684108:notes:296]
During the
 year ended June 27, 2014, the Company recognized income
 related to severe flooding during fiscal year 2012 of $44.7
 million, which mainly consisted of a $45.2 million final payment
 from the Company’s insurers against its claims for owned and
 consigned equipment and inventory, offset by $0.5 million of other
 expenses from write-offs of advance payments to a customer due to
 flood-related losses in Thailand.


## fn:ExpensesRelatedToReductionInWorkforceDisclosureTextBlock

[0001193125-16-684108:notes:297]
| 21. | Expenses related to reduction in workforce |

[0001193125-16-684108:notes:298]
As part of the
 Company’s ongoing efforts to achieve greater efficiencies in
 all areas of its business, during the year ended June 26,
 2015, the Company implemented a reduction in workforce and incurred
 expenses of approximately $1.2 million which represented severance
 and benefits costs incurred for the termination of approximately
 100 employees in accordance with contractual obligations and local
 regulations.


## fn:AccruedSeveranceBenefitsDisclosureTextBlock

[0001193125-16-684108:notes:299]
| 12. | Severance liabilities |


## fn:AllowanceForDoubtfulAccountsTextBlock

[0001193125-16-684108:notes:300]
| 7. | Allowance for doubtful accounts |
