# FN notes — 0001408710-24-000040


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001408710-24-000040:notes:1]
[same as prior period, unchanged from 0001408710-24-000019:notes:167]


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001408710-24-000040:notes:2]
[same as prior period, unchanged from 0001408710-24-000019:notes:1]

[0001408710-24-000040:notes:3]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of September 27, 2024 and for the three months ended September 27, 2024 and September 29, 2023 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 28, 2024.

[0001408710-24-000040:notes:4]
The balance sheet as of June 28, 2024 has been derived from the audited financial statements at that date but does not include all of the information and footnotes required by U.S. GAAP for complete financial statements.

[0001408710-24-000040:notes:5]
The results for the three months ended September 27, 2024 may not be indicative of results for the year ending June 27, 2025 or any future periods.

[0001408710-24-000040:notes:6]
[same as prior period, unchanged from 0001408710-24-000019:notes:5]

[0001408710-24-000040:notes:7]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for expected credit losses, income taxes, and inventory obsolescence. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information.

[0001408710-24-000040:notes:8]
[same as prior period, unchanged from 0001408710-24-000019:notes:7]

[0001408710-24-000040:notes:9]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended September 27, 2024 and September 29, 2023 consisted of 13 weeks. Fiscal year 2025 will comprise 52 weeks and will end on June 27, 2025.

[0001408710-24-000040:notes:10]
[same as prior period, unchanged from 0001408710-24-000019:notes:9]

[0001408710-24-000040:notes:11]
No new accounting standard was adopted during the three months ended September 27, 2024.

[0001408710-24-000040:notes:12]
[same as prior period, unchanged from 0001408710-24-000019:notes:11]

[0001408710-24-000040:notes:13]
In November 2023, the Financial Accounting Standards Board ("FASB") issued ASU 2023-07, “Segment Reporting (Topic 280), Improvements to Reportable Segment Disclosures,” which is intended to improve reportable segment disclosure requirements, primarily through additional disclosures about significant segment expenses. This ASU is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. This ASU is effective for the Company's annual periods beginning June 29, 2024, and interim periods beginning June 28, 2025, and will be applied retrospectively to all prior periods presented in the financial statements. The Company is currently evaluating the ASU to determine its impact on the Company's disclosures.
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740), Improvements to Income Tax Disclosures,” which requires more detailed income tax disclosures. This ASU requires entities to disclose disaggregated information about their effective tax rate reconciliation as well as expanded information on income taxes paid by jurisdiction. This ASU is effective for all entities for fiscal years beginning after December 15, 2024, with early adoption permitted for annual financial statements that have not yet been issued or made available for issuance. This ASU will be effective for the Company in the first quarter of fiscal year 2026. The Company is currently assessing the impact to its disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001408710-24-000040:notes:14]
[same as prior period, unchanged from 0001408710-24-000019:notes:13]

[0001408710-24-000040:notes:15]
[same as prior period, unchanged from 0001408710-24-000019:notes:14]

[0001408710-24-000040:notes:16]
[same as prior period, unchanged from 0001408710-24-000019:notes:15]

[0001408710-24-000040:notes:17]
| (in thousands, except percentages) | Three Months EndedSeptember 27, 2024 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 29, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 307,820 |  |  |  |  | $ | 254,859 |  |  |  |
| Others (1) | 1,658 |  |  |  |  | 3,460 |  |  |  |
| Total revenue in North America | 309,478 |  |  | 38.5 | % |  | 258,319 |  |  | 37.7 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 290,953 |  |  |  |  | 210,676 |  |  |  |
| India | 76,830 |  |  |  |  | 70,777 |  |  |  |
| Hong Kong | 18,547 |  |  |  |  | 15,788 |  |  |  |
| China | 11,872 |  |  |  |  | 20,260 |  |  |  |
| Thailand | 11,121 |  |  |  |  | 13,027 |  |  |  |
| Singapore | 10,763 |  |  |  |  | 683 |  |  |  |
| Malaysia | 7,498 |  |  |  |  | 33,319 |  |  |  |
| Others | 9,054 |  |  |  |  | 7,292 |  |  |  |
| Total revenue in Asia-Pacific and others | 436,638 |  |  | 54.3 | % |  | 371,822 |  |  | 54.2 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 32,450 |  |  |  |  | 29,774 |  |  |  |
| Germany | 9,344 |  |  |  |  | 12,780 |  |  |  |
| Others | 16,318 |  |  |  |  | 12,782 |  |  |  |
| Total revenue in Europe | $ | 58,112 |  |  | 7.2 | % |  | $ | 55,336 |  |  | 8.1 | % |
| Total revenue | $ | 804,228 |  |  | 100.0 | % |  | $ | 685,477 |  |  | 100.0 | % |

[0001408710-24-000040:notes:18]
[same as prior period, unchanged from 0001408710-24-000019:notes:18]

[0001408710-24-000040:notes:19]
[same as prior period, unchanged from 0001408710-24-000019:notes:20]

[0001408710-24-000040:notes:20]
| (in thousands, except percentages) | Three Months EndedSeptember 27, 2024 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 29, 2023 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 328,881 |  |  |  |  | $ | 242,043 |  |  |  |
| Telecom | 297,434 |  |  |  |  | 291,214 |  |  |  |
| Total revenue - Optical communications | $ | 626,315 |  |  | 77.9 | % |  | $ | 533,257 |  |  | 77.8 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 102,741 |  |  |  |  | $ | 88,358 |  |  |  |
| Industrial laser | 35,326 |  |  |  |  | 29,915 |  |  |  |
| Others | 39,846 |  |  |  |  | 33,947 |  |  |  |
| Total revenue - Non-optical communications | $ | 177,913 |  |  | 22.1 | % |  | $ | 152,220 |  |  | 22.2 | % |
| Total revenue | $ | 804,228 |  |  | 100.0 | % |  | $ | 685,477 |  |  | 100.0 | % |

[0001408710-24-000040:notes:21]
[same as prior period, unchanged from 0001408710-24-000019:notes:23]

[0001408710-24-000040:notes:22]
[same as prior period, unchanged from 0001408710-24-000019:notes:24]

[0001408710-24-000040:notes:23]
As of September 27, 2024 and June 28, 2024, the Company's contract assets were de minimis.

[0001408710-24-000040:notes:24]
[same as prior period, unchanged from 0001408710-24-000019:notes:26]

[0001408710-24-000040:notes:25]
The following tables summarize the activity in the Company’s contract liabilities during the three months ended September 27, 2024:

[0001408710-24-000040:notes:26]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 28, 2024 | $ | 7,846 |  |
| Advance payments received during the period | 2,627 |  |
| Revenue recognized | (1,550) |  |
| Ending balance, September 27, 2024 | $ | 8,923 |  |


## us-gaap:EarningsPerShareTextBlock

[0001408710-24-000040:notes:27]
[same as prior period, unchanged from 0001408710-24-000019:notes:29]

[0001408710-24-000040:notes:28]
[same as prior period, unchanged from 0001408710-24-000019:notes:30]

[0001408710-24-000040:notes:29]
|  |  |  | Three Months Ended |
| (in thousands, except per share data) |  |  |  |  | September 27,2024 |  | September 29,2023 |
| Net income attributable to shareholders |  |  |  |  | $ | 77,394 |  |  | $ | 65,089 |  |
| Weighted-average number of ordinary shares outstanding |  |  |  |  | 36,203 |  |  | 36,256 |  |
| Incremental shares arising from the assumed vesting of restricted share units and performance share units |  |  |  |  | 205 |  |  | 225 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share |  |  |  |  | 36,408 |  |  | 36,481 |  |
| Basic earnings per ordinary share |  |  |  |  | $ | 2.14 |  |  | $ | 1.80 |  |
| Diluted earnings per ordinary share |  |  |  |  | $ | 2.13 |  |  | $ | 1.78 |  |


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001408710-24-000040:notes:30]
[same as prior period, unchanged from 0001408710-24-000019:notes:32]

[0001408710-24-000040:notes:31]
|  |  |  | Fair Value |
| (in thousands) | CarryingCost |  | UnrealizedGain/(Loss) |  | Cash andCashEquivalents |  | MarketableSecurities |  | OtherInvestments |
| As of September 27, 2024 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 400,236 |  |  | $ | — |  |  | $ | 400,236 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 448 |  |  | — |  |  | 448 |  |  | — |  |  | — |  |
| Certificates of deposit and time deposits | 144,527 |  |  | 1,193 |  |  | — |  |  | 145,720 |  |  | — |  |
| Corporate debt securities | 144,356 |  |  | 2,767 |  |  | — |  |  | 147,123 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 213,669 |  |  | 1,681 |  |  | — |  |  | 215,350 |  |  | — |  |
| Total | $ | 903,236 |  |  | $ | 5,641 |  |  | $ | 400,684 |  |  | $ | 508,193 |  |  | $ | — |  |
| As of June 28, 2024 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 409,938 |  |  | $ | — |  |  | $ | 409,938 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 35 |  |  | — |  |  | 35 |  |  | — |  |  | — |  |
| Certificates of deposit and time deposits | 134,288 |  |  | (5) |  |  | — |  |  | 134,283 |  |  | — |  |
| Corporate debt securities | 137,695 |  |  | (932) |  |  | — |  |  | 136,763 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 177,824 |  |  | (240) |  |  | — |  |  | 177,584 |  |  | — |  |
| Total | $ | 859,780 |  |  | $ | (1,177) |  |  | $ | 409,973 |  |  | $ | 448,630 |  |  | $ | — |  |

[0001408710-24-000040:notes:32]
[same as prior period, unchanged from 0001408710-24-000019:notes:34]

[0001408710-24-000040:notes:33]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of September 27, 2024 and June 28, 2024:

[0001408710-24-000040:notes:34]
|  | September 27, 2024 |  | June 28, 2024 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 112,061 |  |  | $ | 113,287 |  |  | $ | 110,671 |  |  | $ | 110,669 |  |
| Due between one to five years | 390,491 |  |  | 394,906 |  |  | 339,136 |  |  | 337,961 |  |
| Total | $ | 502,552 |  |  | $ | 508,193 |  |  | $ | 449,807 |  |  | $ | 448,630 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001408710-24-000040:notes:35]
[same as prior period, unchanged from 0001408710-24-000019:notes:37]

[0001408710-24-000040:notes:36]
[same as prior period, unchanged from 0001408710-24-000019:notes:38]

[0001408710-24-000040:notes:37]
[same as prior period, unchanged from 0001408710-24-000019:notes:39]

[0001408710-24-000040:notes:38]
[same as prior period, unchanged from 0001408710-24-000019:notes:40]

[0001408710-24-000040:notes:39]
[same as prior period, unchanged from 0001408710-24-000019:notes:41]

[0001408710-24-000040:notes:40]
[same as prior period, unchanged from 0001408710-24-000019:notes:42]

[0001408710-24-000040:notes:41]
|  | Fair Value Measurements at Reporting Date Using |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of September 27, 2024 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 448 |  |  |  | $ | — |  |  | $ | 448 |  |
| Certificates of deposit and time deposits | — |  |  | 145,720 |  |  |  | — |  |  | 145,720 |  |
| Corporate debt securities | — |  |  | 147,123 |  |  |  | — |  |  | 147,123 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 215,350 |  |  |  | — |  |  | 215,350 |  |
| Derivative assets – current portion | — |  |  | 11,023 |  | (1) |  | — |  |  | 11,023 |  |
| Total | $ | — |  |  | $ | 519,664 |  |  |  | $ | — |  |  | $ | 519,664 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | (1) |  |  |  | $ | — |  |  | $ | (1) |  |
| Total | $ | — |  |  | $ | (1) |  | (2) |  | $ | — |  |  | $ | (1) |  |

[0001408710-24-000040:notes:42]
|  | Fair Value Measurements at Reporting Date Using |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of June 28, 2024 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 35 |  |  |  | $ | — |  |  | $ | 35 |  |
| Certificates of deposit and time deposits | — |  |  | 134,283 |  |  |  | — |  |  | 134,283 |  |
| Corporate debt securities | — |  |  | 136,763 |  |  |  | — |  |  | 136,763 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 177,584 |  |  |  | — |  |  | 177,584 |  |
| Derivative assets – current portion | — |  |  | 15 |  | (3) |  | — |  |  | 15 |  |
| Total | $ | — |  |  | $ | 448,680 |  |  |  | $ | — |  |  | $ | 448,680 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | (2,244) |  |  |  | $ | — |  |  | $ | (2,244) |  |
| Total | $ | — |  |  | $ | (2,244) |  | (4) |  | $ | — |  |  | $ | (2,244) |  |

[0001408710-24-000040:notes:43]
(1)Foreign currency forward contracts with an aggregate notional amount of $129.0 million and 0.4 million Canadian dollars.

[0001408710-24-000040:notes:44]
(2)Foreign currency forward contract with a notional amount of $1.0 million.

[0001408710-24-000040:notes:45]
(3)Foreign currency forward contracts with an aggregate notional amount of $8.0 million.

[0001408710-24-000040:notes:46]
(4)Foreign currency forward contracts with an aggregate notional amount of $127.0 million and 0.4 million Canadian dollars.

[0001408710-24-000040:notes:47]
[same as prior period, unchanged from 0001408710-24-000019:notes:49]

[0001408710-24-000040:notes:48]
[same as prior period, unchanged from 0001408710-24-000019:notes:50]

[0001408710-24-000040:notes:49]
[same as prior period, unchanged from 0001408710-24-000019:notes:51]

[0001408710-24-000040:notes:50]
[same as prior period, unchanged from 0001408710-24-000019:notes:52]

[0001408710-24-000040:notes:51]
[same as prior period, unchanged from 0001408710-24-000019:notes:53]

[0001408710-24-000040:notes:52]
[same as prior period, unchanged from 0001408710-24-000019:notes:54]

[0001408710-24-000040:notes:53]
[same as prior period, unchanged from 0001408710-24-000019:notes:55]

[0001408710-24-000040:notes:54]
As of September 27, 2024, the Company had 130 outstanding U.S. dollar foreign currency forward contracts against Thai baht, with an aggregate notional amount of $130.0 million and maturity dates ranging from October 2024 through April 2025 and one outstanding Canadian dollar foreign currency forward contract with a notional amount of 0.4 million Canadian dollars and a maturity date in December 2024.

[0001408710-24-000040:notes:55]
As of June 28, 2024, the Company had 135 outstanding U.S. dollar foreign currency forward contracts against Thai baht with an aggregate notional amount of $135.0 million and maturity dates ranging from July 2024 through January 2025, and one foreign currency contract with a notional amount of 0.4 million Canadian dollars and a maturity date in September 2024.

[0001408710-24-000040:notes:56]
As of September 27, 2024, the hedging relationship over foreign currency forward contracts designated for hedge accounting was determined to be highly effective based on the performance of retrospective and prospective regression testing. As of September 27, 2024, the amount in accumulated other comprehensive income (“AOCI”) expected to be reclassified into earnings within 12 months was a gain of $7.7 million.

[0001408710-24-000040:notes:57]
As of June 28, 2024, the hedging relationship over foreign currency forward contracts designated for hedge accounting had been tested to be highly effective based on the performance of retrospective and prospective regression testing. As of June 28, 2024, the amount in AOCI expected to be reclassified into earnings within 12 months as loss was $1.2 million.

[0001408710-24-000040:notes:58]
During the three months ended September 27, 2024 and September 29, 2023, the Company included unrealized gain of $4.1 million and $0.3 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-24-000040:notes:59]
[same as prior period, unchanged from 0001408710-24-000019:notes:70]

[0001408710-24-000040:notes:60]
|  |  |  |  |  | Three Months Ended |
| (in thousands) | Financialstatementsline item |  |  |  |  |  | September 27,2024 |  | September 29,2023 |
| Derivatives gain (loss) recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Othercomprehensiveincome |  |  |  |  |  | $ | 13,246 |  |  | $ | (1,565) |  |
| Interest rate swaps | Othercomprehensiveincome |  |  |  |  |  | — |  |  | (78) |  |
| Total derivatives gain (loss) recognized in other comprehensive income (loss) |  |  |  |  |  |  | $ | 13,246 |  |  | $ | (1,643) |  |
| Derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings: |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Cost of revenues |  |  |  |  |  | $ | 1,419 |  |  | $ | 3,672 |  |
| Foreign currency forward contracts | SG&A |  |  |  |  |  | 106 |  |  | 155 |  |
| Foreign currency forward contracts | Foreign exchange loss, net |  |  |  |  |  | (5,909) |  |  | (3,215) |  |
| Interest rate swaps | Interest expense |  |  |  |  |  | — |  |  | (89) |  |
| Total derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings |  |  |  |  |  |  | $ | (4,384) |  |  | $ | 523 |  |
| Change in net unrealized gain (loss) on derivatives instruments |  |  |  |  |  |  | $ | 8,862 |  |  | $ | (1,120) |  |

[0001408710-24-000040:notes:61]
[same as prior period, unchanged from 0001408710-24-000019:notes:72]

[0001408710-24-000040:notes:62]
[same as prior period, unchanged from 0001408710-24-000019:notes:73]

[0001408710-24-000040:notes:63]
|  | September 27,2024 |  | June 28,2024 |
| (in thousands) | DerivativeAssets |  | DerivativeLiabilities |  | DerivativeAssets |  | DerivativeLiabilities |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts | $ | 3,318 |  |  | $ | — |  |  | $ | — |  |  | $ | (1,088) |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward contracts | 7,705 |  |  | (1) |  |  | 15 |  |  | (1,156) |  |
| Derivatives, gross balances | $ | 11,023 |  |  | $ | (1) |  |  | $ | 15 |  |  | $ | (2,244) |  |

[0001408710-24-000040:notes:64]
[same as prior period, unchanged from 0001408710-24-000019:notes:75]

[0001408710-24-000040:notes:65]
[same as prior period, unchanged from 0001408710-24-000019:notes:76]


## us-gaap:InventoryDisclosureTextBlock

[0001408710-24-000040:notes:66]
[same as prior period, unchanged from 0001408710-24-000019:notes:77]

[0001408710-24-000040:notes:67]
| (in thousands) | As of September 27,2024 |  | As of June 28,2024 |
| Raw materials | $ | 98,608 |  |  | $ | 139,063 |  |
| Work in progress | 276,777 |  |  | 266,112 |  |
| Finished goods | 41,433 |  |  | 39,121 |  |
| Goods in transit | 23,587 |  |  | 18,910 |  |
| Total inventories | $ | 440,405 |  |  | $ | 463,206 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001408710-24-000040:notes:68]
Leases
The Company leases facilities under non-cancelable operating lease agreements. The Company leases a portion of its capital equipment and vehicles, certain land and buildings for its facilities in Thailand, the Cayman Islands, the PRC, the U.S., Israel and Singapore under operating lease arrangements that expire at various dates through 2034. Certain of these lease arrangements provide the Company the ability to extend the lease term following the expiration of the current term. However, the Company has excluded all lease extension options from its right of use (“ROU”) assets and lease liabilities as the Company is not reasonably assured that it will exercise these options. None of the lease agreements contain residual value guarantees provided by the lessee. The Company also has one intercompany lease transaction in the form of a lease of office and manufacturing space.

[0001408710-24-000040:notes:69]
[same as prior period, unchanged from 0001408710-24-000019:notes:80]

[0001408710-24-000040:notes:70]
As of September 27, 2024, the maturities of the Company’s operating lease liabilities were as follows:

[0001408710-24-000040:notes:71]
| (in thousands) |  |  |
| 2025 (remaining nine months) | $ | 1,266 |  |  |
| 2026 | 1,651 |  |  |
| 2027 | 814 |  |  |
| 2028 | 363 |  |  |
| 2029 | 330 |  |  |
| Thereafter | 1,305 |  |  |
| Total undiscounted lease payments | 5,729 |  |  |
| Less imputed interest | (879) |  |  |
| Total present value of lease liabilities | $ | 4,850 |  | (1) |

[0001408710-24-000040:notes:72]
(1)Includes current portion of operating lease liabilities of $1.4 million.

[0001408710-24-000040:notes:73]
[same as prior period, unchanged from 0001408710-24-000019:notes:84]

[0001408710-24-000040:notes:74]
Rental expense for long-term leases for the three months ended September 27, 2024 and September 29, 2023 was $0.5 million, for both periods.

[0001408710-24-000040:notes:75]
Rental expense for short-term leases for the three months ended September 27, 2024 and September 29, 2023 was de minimis, and $0.4 million, respectively.

[0001408710-24-000040:notes:76]
[same as prior period, unchanged from 0001408710-24-000019:notes:87]

[0001408710-24-000040:notes:77]
|  | As ofSeptember 27, 2024 |  | As ofJune 28, 2024 |
| Weighted-average remaining lease term (in years) | 5.5 |  | 5.6 |
| Weighted-average discount rate | 5.6 | % |  | 5.6 | % |

[0001408710-24-000040:notes:78]
The following table presents supplemental disclosure for the unaudited condensed consolidated statements of cash flows related to operating and finance leases for the three months ended September 27, 2024 and September 29, 2023:

[0001408710-24-000040:notes:79]
|  |  |  | Three Months Ended |
| (in thousands) |  |  |  |  | September 27,2024 |  | September 29,2023 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |
| Operating cash flows from operating leases |  |  |  |  | $ | 745 |  |  | $ | 959 |  |
| ROU assets obtained in exchange for lease liabilities |  |  |  |  | $ | 159 |  |  | $ | 4,936 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001408710-24-000040:notes:80]
[same as prior period, unchanged from 0001408710-24-000019:notes:91]

[0001408710-24-000040:notes:81]
| (in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  |  |  | Net |
| As of September 27, 2024 |  |  |  |  |  |  |  |
| Software | $ | 11,532 |  |  | $ | (9,331) |  |  |  |  | $ | 2,201 |  |

[0001408710-24-000040:notes:82]
| (in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  |  |  | Net |
| As of June 28, 2024 |  |  |  |  |  |  |  |
| Software | $ | 11,398 |  |  | $ | (9,077) |  |  |  |  | $ | 2,321 |  |

[0001408710-24-000040:notes:83]
The Company recorded amortization expense relating to intangibles of $0.3 million and $0.2 million for the three months ended September 27, 2024 and September 29, 2023, respectively.

[0001408710-24-000040:notes:84]
[same as prior period, unchanged from 0001408710-24-000019:notes:95]

[0001408710-24-000040:notes:85]
| (years) | As ofSeptember 27, 2024 |  | As ofJune 28, 2024 |
| Software | 1.8 |  | 2.1 |

[0001408710-24-000040:notes:86]
Based on the carrying amount of intangibles as of September 27, 2024, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001408710-24-000040:notes:87]
| (in thousands) |  |
| 2025 (remaining nine months) | $ | 652 |  |
| 2026 | 673 |  |
| 2027 | 472 |  |
| 2028 | 300 |  |
| 2029 | 100 |  |
| Thereafter | 4 |  |
| Total | $ | 2,201 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001408710-24-000040:notes:88]
Income taxes
As of September 27, 2024 and June 28, 2024, the liability for uncertain tax positions including accrued interest and penalties was $2.0 million and $1.3 million, respectively. The Company expects the estimated amount of liability associated with its uncertain tax positions to increase within the next 12 months due to additional provisions associated with uncertain tax positions from one of the Company's subsidiaries and interest on these positions.

[0001408710-24-000040:notes:89]
The Company files income tax returns in the United States and foreign tax jurisdictions. The tax years from 2017 to 2023 remain open to examination by U.S. federal and state, and foreign tax authorities. The Company’s income tax is recognized based on the best estimate of the expected annual effective tax rate for the full financial year of each entity in the Company, adjusted for discrete items arising in that quarter. If the Company’s estimated annual effective tax rate changes, the Company makes a cumulative adjustment in that quarter.

[0001408710-24-000040:notes:90]
The effective tax rate for the Company for the three months ended September 27, 2024 and September 29, 2023 was 4.2% and 7.2%, respectively, of net income. The decrease was due to a full valuation allowance of $2.1 million for deferred tax assets that was set up during the three months ended September 29, 2023 for the Company's subsidiary in Israel.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001408710-24-000040:notes:91]
[same as prior period, unchanged from 0001408710-24-000019:notes:121]

[0001408710-24-000040:notes:92]
[same as prior period, unchanged from 0001408710-24-000019:notes:122]

[0001408710-24-000040:notes:93]
The effect of recording share-based compensation expense for the three months ended September 27, 2024 and September 29, 2023 was as follows:

[0001408710-24-000040:notes:94]
|  |  |  | Three Months Ended |
| (in thousands) |  |  |  |  | September 27,2024 |  | September 29,2023 |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |
| Restricted share units |  |  |  |  | $ | 5,713 |  |  | $ | 4,879 |  |
| Performance share units |  |  |  |  | 2,969 |  |  | 2,854 |  |
| Total share-based compensation expense |  |  |  |  | 8,682 |  |  | 7,733 |  |
| Tax effect on share-based compensation expense |  |  |  |  | — |  |  | — |  |
| Net effect on share-based compensation expense |  |  |  |  | $ | 8,682 |  |  | $ | 7,733 |  |

[0001408710-24-000040:notes:95]
[same as prior period, unchanged from 0001408710-24-000019:notes:125]

[0001408710-24-000040:notes:96]
|  |  |  | Three Months Ended |
| (in thousands) |  |  |  |  | September 27,2024 |  | September 29,2023 |
| Cost of revenue |  |  |  |  | $ | 2,898 |  |  | $ | 2,165 |  |
| Selling, general and administrative expense |  |  |  |  | 5,784 |  |  | 5,568 |  |
| Total share-based compensation expense |  |  |  |  | $ | 8,682 |  |  | $ | 7,733 |  |

[0001408710-24-000040:notes:97]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the three months ended September 27, 2024 and September 29, 2023.

[0001408710-24-000040:notes:98]
[same as prior period, unchanged from 0001408710-24-000019:notes:128]

[0001408710-24-000040:notes:99]
[same as prior period, unchanged from 0001408710-24-000019:notes:129]

[0001408710-24-000040:notes:100]
[same as prior period, unchanged from 0001408710-24-000019:notes:130]

[0001408710-24-000040:notes:101]
[same as prior period, unchanged from 0001408710-24-000019:notes:131]

[0001408710-24-000040:notes:102]
The following table summarizes the number of equity awards outstanding and ordinary shares available for grant under each of the Equity Incentive Plans as of September 27, 2024:

[0001408710-24-000040:notes:103]
| (share units) | Restricted Share Units outstanding |  | Performance Share Units outstanding |  | Ordinary Shares available for future grant |
| 2020 Plan | 280,753 |  |  | 120,916 |  |  | 1,607,040 |  |
| 2017 Inducement Plan | — |  |  | — |  |  | 111,347 |  |
| Total | 280,753 |  |  | 120,916 |  |  | 1,718,387 |  |

[0001408710-24-000040:notes:104]
[same as prior period, unchanged from 0001408710-24-000019:notes:134]

[0001408710-24-000040:notes:105]
[same as prior period, unchanged from 0001408710-24-000019:notes:135]

[0001408710-24-000040:notes:106]
[same as prior period, unchanged from 0001408710-24-000019:notes:136]

[0001408710-24-000040:notes:107]
[same as prior period, unchanged from 0001408710-24-000019:notes:137]

[0001408710-24-000040:notes:108]
[same as prior period, unchanged from 0001408710-24-000019:notes:138]

[0001408710-24-000040:notes:109]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 28, 2024 | 306,660 |  |  | $ | 129.01 |  |
| Granted | 92,048 |  |  | $ | 261.84 |  |
| Vested | (113,262) |  |  | $ | 112.98 |  |
| Forfeited | (4,693) |  |  | $ | 138.88 |  |
| Balance as of September 27, 2024 | 280,753 |  |  | $ | 178.86 |  |

[0001408710-24-000040:notes:110]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 30, 2023 | 368,765 |  |  | $ | 97.49 |  |
| Granted | 95,393 |  |  | $ | 158.91 |  |
| Vested | (139,438) |  |  | $ | 85.02 |  |
| Forfeited | (4,709) |  |  | $ | 108.19 |  |
| Balance as of September 29, 2023 | 320,011 |  |  | $ | 121.07 |  |

[0001408710-24-000040:notes:111]
[same as prior period, unchanged from 0001408710-24-000019:notes:141]

[0001408710-24-000040:notes:112]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 28, 2024 | 171,078 |  |  | $ | 135.31 |  |
| Granted | 46,980 |  |  | $ | 261.84 |  |
| Vested | (97,142) |  |  | $ | 117.35 |  |
| Forfeited | — |  |  | $ | — |  |
| Balance as of September 27, 2024 | 120,916 |  |  | $ | 198.90 |  |

[0001408710-24-000040:notes:113]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 30, 2023 | 204,016 |  |  | $ | 108.81 |  |
| Granted | 73,936 |  |  | $ | 158.91 |  |
| Vested | (106,874) |  |  | 101.05 |  |
| Forfeited | — |  |  | $ | — |  |
| Balance as of September 29, 2023 | 171,078 |  |  | $ | 135.31 |  |

[0001408710-24-000040:notes:114]
As of September 27, 2024, there was $29.5 million and $16.2 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 3.0 and 1.5 years, respectively.

[0001408710-24-000040:notes:115]
For the three months ended September 27, 2024 and September 29, 2023, the Company withheld an aggregate of 88,007 shares and 99,518 shares, respectively, upon the vesting of restricted share units and performance shares units, based upon the closing share price on the vesting date to settle employee tax withholding obligations. For the three months ended September 27, 2024 and September 29, 2023, the Company then remitted cash of $20.2 million and $12.1 million, respectively, to the appropriate taxing authorities and presented it as a financing activity within the unaudited condensed consolidated statements of cash flows. The payment was recorded as a reduction of additional paid-in capital.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001408710-24-000040:notes:116]
[same as prior period, unchanged from 0001408710-24-000019:notes:146]

[0001408710-24-000040:notes:117]
[same as prior period, unchanged from 0001408710-24-000019:notes:147]

[0001408710-24-000040:notes:118]
For the three months ended September 27, 2024, Fabrinet issued 122,397 ordinary shares upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-24-000040:notes:119]
For the three months ended September 29, 2023, Fabrinet issued 146,794 ordinary shares upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-24-000040:notes:120]
[same as prior period, unchanged from 0001408710-24-000019:notes:150]

[0001408710-24-000040:notes:121]
[same as prior period, unchanged from 0001408710-24-000019:notes:151]

[0001408710-24-000040:notes:122]
In August 2017, the Company’s board of directors approved a share repurchase program to permit the Company to repurchase up to $30.0 million worth of its issued and outstanding ordinary shares in the open market in accordance with applicable rules and regulations. In February 2018, May 2019, August 2020, August 2022, August 2023, and August 2024, the Company’s board of directors approved an increase of $30.0 million, $50.0 million, $58.5 million, $78.7 million, $47.6 million, and $139.5 million, respectively, to the original share repurchase authorization, bringing the aggregate authorization to $434.3 million.

[0001408710-24-000040:notes:123]
During the three months ended September 27, 2024, the Company did not repurchase any shares. As of September 27, 2024, the Company had a remaining authorization to repurchase up to $200.0 million worth of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001408710-24-000040:notes:124]
Accumulated other comprehensive income (loss)
The changes in AOCI for the three months ended September 27, 2024 and September 29, 2023 were as follows:

[0001408710-24-000040:notes:125]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  |  |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 28, 2024 | $ | (1,179) |  |  | $ | (980) |  |  |  |  | $ | (982) |  |  | $ | (3,141) |  |
| Other comprehensive income (loss) before reclassification | 6,818 |  |  | 13,246 |  |  |  |  | (352) |  |  | 19,712 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | — |  |  | (4,384) |  |  |  |  | — |  |  | (4,384) |  |
| Tax effects | — |  |  | (329) |  |  |  |  | — |  |  | (329) |  |
| Other comprehensive income (loss) | $ | 6,818 |  |  | $ | 8,533 |  |  |  |  | $ | (352) |  |  | $ | 14,999 |  |
| Balance as of September 27, 2024 | $ | 5,639 |  |  | $ | 7,553 |  |  |  |  | $ | (1,334) |  |  | $ | 11,858 |  |

[0001408710-24-000040:notes:126]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 30, 2023 | $ | (3,279) |  |  | $ | (3,541) |  |  | $ | (330) |  |  | $ | (965) |  |  | $ | (8,115) |  |
| Other comprehensive income (loss) before reclassification | 948 |  |  | (1,643) |  |  | — |  |  | 100 |  |  | (595) |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | — |  |  | 523 |  |  | 90 |  |  | — |  |  | 613 |  |
| Tax effects | — |  |  | 559 |  |  | 36 |  |  | — |  |  | 595 |  |
| Other comprehensive income (loss) | $ | 948 |  |  | $ | (561) |  |  | $ | 126 |  |  | $ | 100 |  |  | $ | 613 |  |
| Balance as of September 29, 2023 | $ | (2,331) |  |  | $ | (4,102) |  |  | $ | (204) |  |  | $ | (865) |  |  | $ | (7,502) |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001408710-24-000040:notes:127]
Commitments and contingencies
Bank guarantees

[0001408710-24-000040:notes:128]
As of September 27, 2024 and June 28, 2024, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.3 million and $2.0 million, respectively, or Thai baht 75.7 million and 73.2 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the subsidiary's operations related to the Israeli Customs department.

[0001408710-24-000040:notes:129]
Purchase obligations

[0001408710-24-000040:notes:130]
Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001408710-24-000040:notes:131]
As of September 27, 2024, the Company had purchase obligations and other commitments to third parties of $1.11 billion.

[0001408710-24-000040:notes:132]
Capital expenditures

[0001408710-24-000040:notes:133]
As of September 27, 2024, the Company had total capital expenditure commitments to third parties of $21.3 million.

[0001408710-24-000040:notes:134]
Indemnification of directors and officers

[0001408710-24-000040:notes:135]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001408710-24-000040:notes:136]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.

[0001408710-24-000040:notes:137]
Credit facility agreement

[0001408710-24-000040:notes:138]
On March 9, 2023, Fabrinet Thailand and the Parent Company (collectively, the “Borrowers”) and the Bank of Ayudhya Public Company Limited (the "Bank") entered into a credit facility agreement (the “2023 Credit Facility Agreement”), which provided a facility of $55.0 million.

[0001408710-24-000040:notes:139]
During the three months ended September 27, 2024, the Borrowers and the Bank agreed to amend the 2023 Credit Facility Agreement to reduce the facility to $30.0 million, which may be used for, among other things, an overdraft facility. The Company expects to finalize the amendment to the 2023 Credit Facility Agreement during the three months ending December 27, 2024.

[0001408710-24-000040:notes:140]
As of September 27, 2024, there was no amount outstanding under the 2023 Credit Facility Agreement.

[0001408710-24-000040:notes:141]
Under the 2023 Credit Facility Agreement, the Borrowers are required to maintain a debt-to-equity ratio of less than or equal to 1.5 times for Fabrinet Thailand and 1.0 times for the Parent Company.

[0001408710-24-000040:notes:142]
As of September 27, 2024, the Borrowers were in compliance with all of their financial covenants under the 2023 Credit Facility Agreement.

[0001408710-24-000040:notes:143]
Litigation and claim

[0001408710-24-000040:notes:144]
On June 28, 2024, Ngan In Leng and First Laser Limited (collectively, the “Plaintiffs”) filed a complaint in the Fuzhou Intermediate People’s Court (the “Court”) in Fuzhou, China against Fujian Enterprises (Holdings) Co., Ltd. (“FEHC”), Jian An Investment Limited (“Jian”), and Casix, Inc. (“Casix”), the Company's wholly-owned subsidiary located in the PRC. The complaint alleges unjust enrichment related to a purported investment in Casix by the Plaintiffs in 1997, which predates the Company's acquisition of Casix from JDS Uniphase Corporation. The Plaintiffs have requested that the Court order FEHC to return the unjust enrichment to the Plaintiffs in the amount of RMB 400 million, with interest from March 1, 2000, and order Jian and Casix to bear joint and several liability for all payment obligations of FEHC.

[0001408710-24-000040:notes:145]
In September 2024, the Court dismissed the lawsuit in its entirety based on jurisdictional grounds. The Plaintiffs have since appealed the Court's ruling to the High People's Court of Fujian Province (the "Appellate Court"). In their appeal, the Plaintiffs now claim that Casix is the primary obligor to return the alleged unjust enrichment to the Plaintiffs. The matter is currently pending before the Appellate Court. At this time, the Company is not able to quantify any potential liability in connection with this litigation due to its pending status and preliminary nature.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001408710-24-000040:notes:146]
Business segments and geographic information
Operating segments are defined as components of an enterprise that engage in business activities for which discrete financial information is available that is evaluated regularly by the chief operating decision maker (the “CODM”) in deciding how to allocate resources and in assessing performance. The Company’s CODM is Fabrinet’s Chief Executive Officer. As of September 27, 2024, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001408710-24-000040:notes:147]
[same as prior period, unchanged from 0001408710-24-000019:notes:169]

[0001408710-24-000040:notes:148]
[same as prior period, unchanged from 0001408710-24-000019:notes:170]

[0001408710-24-000040:notes:149]
| (in thousands) |  | September 27,2024 |  | June 28,2024 |
| Long-Lived Assets: |  |  |  |  |
| Thailand |  | $ | 265,900 |  |  | $ | 261,141 |  |
| U.S. |  | 28,631 |  |  | 28,914 |  |
| China |  | 14,459 |  |  | 14,586 |  |
| Israel |  | 1,818 |  |  | 2,160 |  |
| Others |  | 433 |  |  | 439 |  |
| Total |  | $ | 311,241 |  |  | $ | 307,240 |  |

[0001408710-24-000040:notes:150]
[same as prior period, unchanged from 0001408710-24-000019:notes:172]

[0001408710-24-000040:notes:151]
The Company had three customers that each contributed to 10% or more of the Company's total trade accounts receivable as of September 27, 2024 and June 28, 2024.
