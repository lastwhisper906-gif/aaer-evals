# FN MD&A — 0001408710-24-000040


## mdna

[0001408710-24-000040:mdna:1]
[same as prior period, unchanged from 0001408710-24-000019:mdna:1]

[0001408710-24-000040:mdna:2]
[same as prior period, unchanged from 0001408710-24-000019:mdna:2]

[0001408710-24-000040:mdna:3]
[same as prior period, unchanged from 0001408710-24-000019:mdna:3]

[0001408710-24-000040:mdna:4]
[same as prior period, unchanged from 0001408710-24-000019:mdna:4]

[0001408710-24-000040:mdna:5]
•our expectation that the portion of our revenues attributable to customers in regions outside of North America for the remainder of fiscal year 2025 will be in line with the portion of revenues attributable to such customers during the three months ended September 27, 2024;

[0001408710-24-000040:mdna:6]
[same as prior period, unchanged from 0001408710-24-000019:mdna:6]

[0001408710-24-000040:mdna:7]
•our expectation that our fiscal year 2025 selling, general and administrative (“SG&A”) expenses will increase compared to our fiscal year 2024 SG&A expenses;

[0001408710-24-000040:mdna:8]
[same as prior period, unchanged from 0001408710-24-000019:mdna:8]

[0001408710-24-000040:mdna:9]
[same as prior period, unchanged from 0001408710-24-000019:mdna:9]

[0001408710-24-000040:mdna:10]
[same as prior period, unchanged from 0001408710-24-000019:mdna:10]

[0001408710-24-000040:mdna:11]
[same as prior period, unchanged from 0001408710-24-000019:mdna:11]

[0001408710-24-000040:mdna:12]
[same as prior period, unchanged from 0001408710-24-000019:mdna:12]

[0001408710-24-000040:mdna:13]
[same as prior period, unchanged from 0001408710-24-000019:mdna:13]

[0001408710-24-000040:mdna:14]
[same as prior period, unchanged from 0001408710-24-000019:mdna:14]

[0001408710-24-000040:mdna:15]
[same as prior period, unchanged from 0001408710-24-000019:mdna:15]

[0001408710-24-000040:mdna:16]
[same as prior period, unchanged from 0001408710-24-000019:mdna:16]

[0001408710-24-000040:mdna:17]
[same as prior period, unchanged from 0001408710-24-000019:mdna:17]

[0001408710-24-000040:mdna:18]
•trends in the optical communications, automotive, industrial lasers and other markets, including trends to outsource the production of components used in those markets;

[0001408710-24-000040:mdna:19]
[same as prior period, unchanged from 0001408710-24-000019:mdna:19]

[0001408710-24-000040:mdna:20]
[same as prior period, unchanged from 0001408710-24-000019:mdna:20]

[0001408710-24-000040:mdna:21]
[same as prior period, unchanged from 0001408710-24-000019:mdna:21]

[0001408710-24-000040:mdna:22]
We provide advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers (“OEMs”) of complex products such as optical communication components, modules and sub-systems, industrial lasers, automotive components, medical devices and sensors. We offer a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, complex printed circuit board assembly, advanced packaging, integration, final assembly and testing. We are capable of producing a wide variety of high complexity products in any mix and any volume. Based on our extensive experience and the positive feedback we have received from our customers, we believe we are a global leader in providing these services to the optical communications, automotive, and industrial lasers markets.

[0001408710-24-000040:mdna:23]
Our customer base includes companies in complex industries that require advanced precision manufacturing capabilities such as optical communications, automotive, industrial lasers, medical, and sensors. The products that we manufacture for our OEM customers include selective switching products; tunable lasers, transponders and transceivers; active optical cables; solid state, diode-pumped, gas and fiber lasers; and sensors. In many cases, we are the sole outsourced manufacturing partner used by our customers for the products that we manufacture for them.

[0001408710-24-000040:mdna:24]
[same as prior period, unchanged from 0001408710-24-000019:mdna:24]

[0001408710-24-000040:mdna:25]
[same as prior period, unchanged from 0001408710-24-000019:mdna:25]

[0001408710-24-000040:mdna:26]
[same as prior period, unchanged from 0001408710-24-000019:mdna:26]

[0001408710-24-000040:mdna:27]
[same as prior period, unchanged from 0001408710-24-000019:mdna:27]

[0001408710-24-000040:mdna:28]
[same as prior period, unchanged from 0001408710-24-000019:mdna:28]

[0001408710-24-000040:mdna:29]
[same as prior period, unchanged from 0001408710-24-000019:mdna:29]

[0001408710-24-000040:mdna:30]
The percentage of our revenues generated from a bill-to location outside of North America decreased from 62.3% in the three months ended September 29, 2023 to 61.5% in the three months ended September 27, 2024, primarily because of an increase in revenue from a customer in Israel and a decrease in sales to our customers in Germany.

[0001408710-24-000040:mdna:31]
Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside North America for the remainder of fiscal year 2025 will be in line with the portion of revenues attributable to such customers during the three months ended September 27, 2024.

[0001408710-24-000040:mdna:32]
[same as prior period, unchanged from 0001408710-24-000019:mdna:34]

[0001408710-24-000040:mdna:33]
|  |  |  | Three Months Ended |
|  |  |  |  |  | September 27, 2024 |  | September 29, 2023 |
| North America |  |  |  |  | 38.5 | % |  | 37.7 | % |
| Asia-Pacific and others |  |  |  |  | 54.3 |  |  | 54.2 |  |
| Europe |  |  |  |  | 7.2 |  |  | 8.1 |  |
|  |  |  |  |  | 100.0 | % |  | 100.0 | % |

[0001408710-24-000040:mdna:34]
[same as prior period, unchanged from 0001408710-24-000019:mdna:36]

[0001408710-24-000040:mdna:35]
We enter into supply agreements with our customers which generally have an initial term of up to three years, subject to automatic renewals for subsequent one-year terms unless expressly terminated. Although there are no minimum purchase requirements in our supply agreements, our customers provide us with rolling forecasts of their demand requirements. Our supply agreements generally include provisions for pricing and periodic review of pricing, consignment of our customer’s unique production equipment to us, and the sharing of benefits from cost-savings derived from our efforts. We are generally required to purchase materials, which may include long lead-time materials and materials that are subject to minimum order quantities and/or non-cancelable or non-returnable terms, to meet the stated demands of our customers. After procuring materials, we manufacture products for our customers based on purchase orders that contain terms regarding product quantities, delivery locations and delivery dates. Our customers generally are obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by our customers within a specified period of time, or that are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under our contracts. Once materials are designated as either excess or obsolete inventory, our customers are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and recognized as an offset against cost of revenue upon shipment.

[0001408710-24-000040:mdna:36]
[same as prior period, unchanged from 0001408710-24-000019:mdna:38]

[0001408710-24-000040:mdna:37]
[same as prior period, unchanged from 0001408710-24-000019:mdna:39]

[0001408710-24-000040:mdna:38]
A second significant element of our cost of revenues is employee costs, including indirect employee costs related to design, configuration and optimization of manufacturing processes for our customers, quality testing, materials testing and other engineering services, and direct costs related to our manufacturing employees. Direct employee costs include employee salaries, insurance and benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a lesser extent, costs to recruit, train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand and the PRC, the fluctuation of the Thai baht, and Chinese Renminbi ("RMB") against our functional currency, the U.S. dollar, and our ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention and asset utilization.

[0001408710-24-000040:mdna:39]
[same as prior period, unchanged from 0001408710-24-000019:mdna:41]

[0001408710-24-000040:mdna:40]
[same as prior period, unchanged from 0001408710-24-000019:mdna:42]

[0001408710-24-000040:mdna:41]
[same as prior period, unchanged from 0001408710-24-000019:mdna:43]

[0001408710-24-000040:mdna:42]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative and other support personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other general expenses not related to cost of revenues. In fiscal year 2025, we expect our SG&A expenses will increase compared with our fiscal year 2024 SG&A expenses, mainly due to increases in employee costs.

[0001408710-24-000040:mdna:43]
The compensation committee of our board of directors approved a fiscal year 2025 executive incentive plan with quantitative objectives based solely on achieving certain revenue targets and non-GAAP operating margin targets for fiscal year 2025. Bonuses under the fiscal year 2025 executive incentive plan are payable after the end of fiscal year 2025. In fiscal year 2024, the compensation committee approved a fiscal year 2024 executive incentive plan with quantitative objectives that were based solely on achieving certain revenue targets and non-GAAP operating margin targets for fiscal year 2024.

[0001408710-24-000040:mdna:44]
[same as prior period, unchanged from 0001408710-24-000019:mdna:46]

[0001408710-24-000040:mdna:45]
[same as prior period, unchanged from 0001408710-24-000019:mdna:47]

[0001408710-24-000040:mdna:46]
[same as prior period, unchanged from 0001408710-24-000019:mdna:48]

[0001408710-24-000040:mdna:47]
[same as prior period, unchanged from 0001408710-24-000019:mdna:49]

[0001408710-24-000040:mdna:48]
[same as prior period, unchanged from 0001408710-24-000019:mdna:50]

[0001408710-24-000040:mdna:49]
|  | As of September 27, 2024 |  | As of June 28, 2024 |
| (in thousands, except percentages) | ForeignCurrency |  | $ |  | % |  | ForeignCurrency |  | $ |  | % |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 796,503 |  |  | 24,546 |  |  | 67.8 | % |  | 1,046,000 |  |  | 28,385 |  |  | 72.5 | % |
| RMB | 47,818 |  |  | 6,821 |  |  | 18.8 |  |  | 42,852 |  |  | 6,013 |  |  | 15.4 |  |
| GBP | 3,614 |  |  | 4,839 |  |  | 13.4 |  |  | 3,778 |  |  | 4,773 |  |  | 12.1 |  |
| Total |  |  | $ | 36,206 |  |  | 100.0 | % |  |  |  | $ | 39,171 |  |  | 100.0 | % |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 3,418,672 |  |  | 105,352 |  |  | 88.3 | % |  | 3,263,391 |  |  | 88,559 |  |  | 87.4 | % |
| RMB | 85,094 |  |  | 12,139 |  |  | 10.2 |  |  | 78,418 |  |  | 11,003 |  |  | 10.9 |  |
| GBP | 1,363 |  |  | 1,825 |  |  | 1.5 |  |  | 1,359 |  |  | 1,717 |  |  | 1.7 |  |
| Total |  |  | $ | 119,316 |  |  | 100.0 | % |  |  |  | $ | 101,279 |  |  | 100.0 | % |

[0001408710-24-000040:mdna:50]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable, accrued employee benefits and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of September 27, 2024, there was $130.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 28, 2024, there was $135.0 million of foreign currency forward contracts outstanding on the Thai baht payables.

[0001408710-24-000040:mdna:51]
The RMB assets represent cash and cash equivalents, trade accounts receivable, other receivables, and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable, accrued payroll, bonus and related expenses, and other payables. As of September 27, 2024 and June 28, 2024, we did not have any derivative contracts denominated in RMB.

[0001408710-24-000040:mdna:52]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable, accrued expenses, and other payables. As of September 27, 2024 and June 28, 2024, we did not have any derivative contracts denominated in GBP.

[0001408710-24-000040:mdna:53]
For the three months ended September 27, 2024 and September 29, 2023, we recorded unrealized gain of $4.1 million and $0.3 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-24-000040:mdna:54]
[same as prior period, unchanged from 0001408710-24-000019:mdna:57]

[0001408710-24-000040:mdna:55]
[same as prior period, unchanged from 0001408710-24-000019:mdna:58]

[0001408710-24-000040:mdna:56]
[same as prior period, unchanged from 0001408710-24-000019:mdna:59]

[0001408710-24-000040:mdna:57]
[same as prior period, unchanged from 0001408710-24-000019:mdna:60]

[0001408710-24-000040:mdna:58]
[same as prior period, unchanged from 0001408710-24-000019:mdna:61]

[0001408710-24-000040:mdna:59]
[same as prior period, unchanged from 0001408710-24-000019:mdna:62]

[0001408710-24-000040:mdna:60]
[same as prior period, unchanged from 0001408710-24-000019:mdna:63]

[0001408710-24-000040:mdna:61]
[same as prior period, unchanged from 0001408710-24-000019:mdna:64]

[0001408710-24-000040:mdna:62]
[same as prior period, unchanged from 0001408710-24-000019:mdna:65]

[0001408710-24-000040:mdna:63]
In addition, the General Administration of Taxation has issued circulars concerning employee share options. Under these circulars, our employees working in the PRC who exercise share options will be subject to PRC individual income tax. Our

[0001408710-24-000040:mdna:64]
PRC subsidiary has obligations to file documents related to employee share options with relevant tax authorities and withhold individual income taxes of those employees who exercise their share options.

[0001408710-24-000040:mdna:65]
[same as prior period, unchanged from 0001408710-24-000019:mdna:67]

[0001408710-24-000040:mdna:66]
[same as prior period, unchanged from 0001408710-24-000019:mdna:68]

[0001408710-24-000040:mdna:67]
[same as prior period, unchanged from 0001408710-24-000019:mdna:69]

[0001408710-24-000040:mdna:68]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption on income generated from projects to manufacture certain products at our Chonburi campus is currently available to us through June 2026. Similar preferential tax treatment was available to us through June 2020 with respect to products manufactured at our Pinehurst campus Building 6. After June 2020, 50% of our income generated from products manufactured at our Pinehurst campus will be exempted from tax through June 2025. Preferential tax treatment is available to us for products manufactured at our Chonburi campus Building 9, where income generated will be tax exempt through 2031, capped at our actual investment amount. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted. Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001408710-24-000040:mdna:69]
As of September 27, 2024, the corporate income tax rates for our subsidiaries in the PRC, the U.S., the U.K. and Israel are 25%, 21%, 25% and 23%, respectively.

[0001408710-24-000040:mdna:70]
[same as prior period, unchanged from 0001408710-24-000019:mdna:72]

[0001408710-24-000040:mdna:71]
[same as prior period, unchanged from 0001408710-24-000019:mdna:73]

[0001408710-24-000040:mdna:72]
[same as prior period, unchanged from 0001408710-24-000019:mdna:74]

[0001408710-24-000040:mdna:73]
Our critical accounting policies are disclosed in our Annual Report on Form 10-K for the fiscal year ended June 28, 2024. The adoption of new accounting policies and accounting standards are disclosed in Note 2 to the unaudited condensed consolidated financial statements. There were no changes to our accounting policies.

[0001408710-24-000040:mdna:74]
[same as prior period, unchanged from 0001408710-24-000019:mdna:76]

[0001408710-24-000040:mdna:75]
[same as prior period, unchanged from 0001408710-24-000019:mdna:77]

[0001408710-24-000040:mdna:76]
| (in thousands) |  |  | Three Months Ended |
|  |  |  |  | September 27,2024 |  | September 29,2023 |
| Revenues |  |  |  |  | $ | 804,228 |  |  | $ | 685,477 |  |
| Cost of revenues |  |  |  |  | (705,202) |  |  | (601,073) |  |
| Gross profit |  |  |  |  | 99,026 |  |  | 84,404 |  |
| Selling, general and administrative expenses |  |  |  |  | (22,031) |  |  | (20,429) |  |
| Restructuring and other related costs |  |  |  |  | (57) |  |  | — |  |
| Operating income |  |  |  |  | 76,938 |  |  | 63,975 |  |
| Interest income |  |  |  |  | 10,933 |  |  | 5,898 |  |
| Interest expense |  |  |  |  | — |  |  | (45) |  |
| Foreign exchange gain (loss), net |  |  |  |  | (7,095) |  |  | 415 |  |
| Other income (expense), net |  |  |  |  | (19) |  |  | (80) |  |
| Income before income taxes |  |  |  |  | 80,757 |  |  | 70,163 |  |
| Income tax expense |  |  |  |  | (3,363) |  |  | (5,074) |  |
| Net income |  |  |  |  | 77,394 |  |  | 65,089 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  | 14,999 |  |  | 613 |  |
| Net comprehensive income |  |  |  |  | $ | 92,393 |  |  | $ | 65,702 |  |

[0001408710-24-000040:mdna:77]
[same as prior period, unchanged from 0001408710-24-000019:mdna:79]

[0001408710-24-000040:mdna:78]
|  |  |  | Three Months Ended |
|  |  |  |  |  | September 27,2024 |  | September 29,2023 |
| Revenues |  |  |  |  | 100.0 | % |  | 100.0 | % |
| Cost of revenues |  |  |  |  | (87.7) |  |  | (87.7) |  |
| Gross profit |  |  |  |  | 12.3 |  |  | 12.3 |  |
| Selling, general and administrative expenses |  |  |  |  | (2.7) |  |  | (3.0) |  |
| Restructuring and other related costs |  |  |  |  | 0.0 |  |  | — |  |
| Operating income |  |  |  |  | 9.6 |  |  | 9.3 |  |
| Interest income |  |  |  |  | 1.3 |  |  | 0.8 |  |
| Interest expense |  |  |  |  | — |  |  | 0.0 |  |
| Foreign exchange gain (loss), net |  |  |  |  | (0.9) |  |  | 0.1 |  |
| Other income (expense), net |  |  |  |  | 0.0 |  |  | 0.0 |  |
| Income before income taxes |  |  |  |  | 10.0 |  |  | 10.2 |  |
| Income tax expense |  |  |  |  | (0.4) |  |  | (0.7) |  |
| Net income |  |  |  |  | 9.6 |  |  | 9.5 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  | 1.9 |  |  | 0.1 |  |
| Net comprehensive income |  |  |  |  | 11.5 | % |  | 9.6 | % |

[0001408710-24-000040:mdna:79]
[same as prior period, unchanged from 0001408710-24-000019:mdna:32]

[0001408710-24-000040:mdna:80]
[same as prior period, unchanged from 0001408710-24-000019:mdna:82]

[0001408710-24-000040:mdna:81]
| (in thousands, except percentages) | Three Months EndedSeptember 27, 2024 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 29, 2023 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 328,881 |  |  |  |  | $ | 242,043 |  |  |  |
| Telecom | 297,434 |  |  |  |  | 291,214 |  |  |  |
| Total revenue - Optical communications | $ | 626,315 |  |  | 77.9 | % |  | $ | 533,257 |  |  | 77.8 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 102,741 |  |  |  |  | $ | 88,358 |  |  |  |
| Industrial laser | 35,326 |  |  |  |  | 29,915 |  |  |  |
| Others | 39,846 |  |  |  |  | 33,947 |  |  |  |
| Total revenue - Non-optical communications | $ | 177,913 |  |  | 22.1 | % |  | $ | 152,220 |  |  | 22.2 | % |
| Total revenue | $ | 804,228 |  |  | 100.0 | % |  | $ | 685,477 |  |  | 100.0 | % |

[0001408710-24-000040:mdna:82]
Comparison of Three Months Ended September 27, 2024 with Three Months Ended September 29, 2023

[0001408710-24-000040:mdna:83]
[same as prior period, unchanged from 0001408710-24-000019:mdna:86]

[0001408710-24-000040:mdna:84]
Our revenues increased by $118.7 million, or 17.3%, to $804.2 million for the three months ended September 27, 2024, compared with $685.5 million for the three months ended September 29, 2023. This increase was primarily due to an increase in our key customers’ demand for optical communications products. Revenues from optical communications products, which represented $626.3 million, or 77.9%, of our revenues for the three months ended September 27, 2024, increased by $93.1 million, or 17.5%, compared to the same period in the prior fiscal year, mainly due to an increase in revenues from data communication products, primarily for artificial intelligence applications, and an increase in revenues from telecommunication products during the three months ended September 27, 2024. Revenues from non-optical communications products, which represented $177.9 million, or 22.1%, of our revenues for the three months ended September 27, 2024, increased by $25.7 million, or 16.9%, compared to the same period in the prior fiscal year, primarily due to growth in automotive revenue, as short-term inventory absorption issues have substantially subsided.

[0001408710-24-000040:mdna:85]
[same as prior period, unchanged from 0001408710-24-000019:mdna:90]

[0001408710-24-000040:mdna:86]
Our cost of revenues increased by $104.1 million, or 17.3%, to $705.2 million, or 87.7% of revenues, for the three months ended September 27, 2024, compared with $601.1 million, or 87.7% of revenues, for the three months ended September 29, 2023. The increase was in line with the increase in sales volume.

[0001408710-24-000040:mdna:87]
[same as prior period, unchanged from 0001408710-24-000019:mdna:93]

[0001408710-24-000040:mdna:88]
Our gross profit increased by $14.6 million, or 17.3%, to $99.0 million, or 12.3% of revenues, for the three months ended September 27, 2024, compared with $84.4 million, or 12.3% of revenues, for the three months ended September 29, 2023. The increase was primarily due to an increase in sales volume.

[0001408710-24-000040:mdna:89]
[same as prior period, unchanged from 0001408710-24-000019:mdna:96]

[0001408710-24-000040:mdna:90]
Our SG&A expenses increased by $1.6 million, or 7.8%, to $22.0 million, or 2.7% of revenues, for the three months ended September 27, 2024, compared with $20.4 million, or 3.0% of revenues, for the three months ended September 29, 2023. The increase was primarily due to (1) an increase in severance expenses of $0.7 million, (2) an increase in executive compensation related expenses of $0.5 million and (3) an increase in legal expenses of $0.4 million.

[0001408710-24-000040:mdna:91]
[same as prior period, unchanged from 0001408710-24-000019:mdna:99]

[0001408710-24-000040:mdna:92]
Our operating income increased by $12.9 million, or 20.2%, to $76.9 million, or 9.6% of revenues, for the three months ended September 27, 2024, compared with $64.0 million, or 9.3% of revenues, for the three months ended September 29, 2023. The increase was primarily due to an increase in revenues.

[0001408710-24-000040:mdna:93]
[same as prior period, unchanged from 0001408710-24-000019:mdna:104]

[0001408710-24-000040:mdna:94]
Our interest income increased by $5.0 million, or 84.7%, to $10.9 million, or 1.3% of revenues, for the three months ended September 27, 2024, compared with $5.9 million, or 0.8% of revenues, for the three months ended September 29, 2023. The increase was primarily due to a higher weighted average interest rate and an increase in average cash balance and short-term investment from $572.0 million to $877.0 million during the three months ended September 27, 2024 compared to the same period in the prior fiscal year.

[0001408710-24-000040:mdna:95]
[same as prior period, unchanged from 0001408710-24-000019:mdna:107]

[0001408710-24-000040:mdna:96]
Our interest expense decreased for the three months ended September 27, 2024, compared with the three months ended September 29, 2023, due to the full repayment of our long-term loan balance.

[0001408710-24-000040:mdna:97]
[same as prior period, unchanged from 0001408710-24-000019:mdna:110]

[0001408710-24-000040:mdna:98]
We recorded foreign exchange loss, net of $7.1 million, or 0.9% of revenues, for the three months ended September 27, 2024, compared with foreign exchange gain, net of $0.4 million, or 0.1% of revenues, for the three months ended September 29, 2023. The foreign exchange loss was mainly due to (1) unrealized loss from revaluation of outstanding Thai baht assets and liabilities of $11.2 million, and (2) higher realized loss from payment/receipt of $0.7 million and (3) higher unrealized loss from revaluation of currencies other than Thai baht of $0.4 million, offset by (1) higher unrealized gain from mark-to-market forward contracts of $3.8 million, and (2) foreign exchange gain, totaling $1.0 million from our subsidiaries in the PRC and the U.K.

[0001408710-24-000040:mdna:99]
[same as prior period, unchanged from 0001408710-24-000019:mdna:113]

[0001408710-24-000040:mdna:100]
We recorded income before income taxes of $80.8 million for the three months ended September 27, 2024, compared with $70.2 million for the three months ended September 29, 2023.

[0001408710-24-000040:mdna:101]
[same as prior period, unchanged from 0001408710-24-000019:mdna:116]

[0001408710-24-000040:mdna:102]
Our provision for income tax reflects effective tax rates of 4.2% and 7.2% for the three months ended September 27, 2024 and September 29, 2023, respectively. The decrease was due to a full valuation allowance of $2.1 million for deferred tax assets that was set up during the three months ended September 29, 2023 for the Company's subsidiary in Israel.

[0001408710-24-000040:mdna:103]
[same as prior period, unchanged from 0001408710-24-000019:mdna:119]

[0001408710-24-000040:mdna:104]
We recorded net income of $77.4 million, or 9.6% of revenues, for the three months ended September 27, 2024, compared with $65.1 million, or 9.5% of revenues, for the three months ended September 29, 2023.

[0001408710-24-000040:mdna:105]
[same as prior period, unchanged from 0001408710-24-000019:mdna:122]

[0001408710-24-000040:mdna:106]
We recorded other comprehensive income of $15.0 million, or 1.9% of revenues, for the three months ended September 27, 2024, compared with other comprehensive income of $0.6 million, or 0.1% of revenues, for the three months ended September 29, 2023. The change was mainly due to (1) higher unrealized gain from mark-to-market of forward contracts and interest rate swap agreements of $9.1 million, and (2) unrealized gain from mark-to-market of available-for-sale debt securities of $5.9 million, offset by (1) unrealized loss from foreign currency translation adjustment of $0.5 million, and (2) lower gain from retirement benefits plan of $0.1 million.

[0001408710-24-000040:mdna:107]
[same as prior period, unchanged from 0001408710-24-000019:mdna:126]

[0001408710-24-000040:mdna:108]
[same as prior period, unchanged from 0001408710-24-000019:mdna:127]

[0001408710-24-000040:mdna:109]
We primarily finance our operations through cash flow from operating activities. As of September 27, 2024 and September 29, 2023, we had cash, cash equivalents, and short-term investments of $908.9 million and $670.8 million, respectively, and no outstanding debt and outstanding debt of $9.1 million, respectively.

[0001408710-24-000040:mdna:110]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents was 4.6% and 4.1% for the three months ended September 27, 2024 and September 29, 2023, respectively.

[0001408710-24-000040:mdna:111]
Our cash investments are made in accordance with an investment policy approved by the audit committee of our board of directors. In general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed income securities are primarily classified as available-for-sale and are recorded at fair value. The cost of securities sold is based on the specific identification method.

[0001408710-24-000040:mdna:112]
Unrealized gains and losses on these securities are recorded as other comprehensive income (loss) and are reported as a separate component of shareholders’ equity.

[0001408710-24-000040:mdna:113]
As of September 29, 2023, we had long-term borrowing under our credit facility agreement of $9.1 million. As of September 27, 2024, we had no outstanding balance under our credit facility agreement. To better manage our cash on hand, we held short-term investments of $508.2 million as of September 27, 2024.

[0001408710-24-000040:mdna:114]
We believe that our current cash and cash equivalents, short-term investments, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001408710-24-000040:mdna:115]
[same as prior period, unchanged from 0001408710-24-000019:mdna:133]

[0001408710-24-000040:mdna:116]
[same as prior period, unchanged from 0001408710-24-000019:mdna:134]

[0001408710-24-000040:mdna:117]
|  | Three Months Ended |
| (in thousands) | September 27, 2024 |  | September 29, 2023 |
| Net cash provided by operating activities | $ | 83,182 |  |  | $ | 145,049 |  |
| Net cash used in investing activities | $ | (71,994) |  |  | $ | (53,080) |  |
| Net cash used in financing activities | $ | (20,220) |  |  | $ | (15,194) |  |
| Net increase in cash and cash equivalents | $ | (9,032) |  |  | $ | 76,775 |  |

[0001408710-24-000040:mdna:118]
[same as prior period, unchanged from 0001408710-24-000019:mdna:136]

[0001408710-24-000040:mdna:119]
Cash provided by operating activities is net income adjusted for certain non-cash items and changes in certain assets and liabilities. The decrease in cash provided by operating activities during the three months ended September 27, 2024 as compared to the three months ended September 29, 2023 was primarily driven by less efficient cash-favorable working capital changes mainly from trade accounts receivable.

[0001408710-24-000040:mdna:120]
[same as prior period, unchanged from 0001408710-24-000019:mdna:138]

[0001408710-24-000040:mdna:121]
Investing cash flows consist primarily of investment purchases, sales, maturities, and disposals; and capital expenditures. The increase in cash used in investing activities for the three months ended September 27, 2024 as compared to cash used in investing activities for the three months ended September 29, 2023 was primarily due to an increase in investment purchases and higher capital expenditures.

[0001408710-24-000040:mdna:122]
[same as prior period, unchanged from 0001408710-24-000019:mdna:140]

[0001408710-24-000040:mdna:123]
Financing cash flows consist primarily of repayment of long-term debt, share repurchases, and withholding tax related to net share settlement of restricted share units. The increase in cash used in financing activities for the three months ended September 27, 2024 as compared to the three months ended September 29, 2023 was due to an increase in withholding tax related to net share settlement of restricted share units, offset by lower repayment of long-term borrowings.

[0001408710-24-000040:mdna:124]
[same as prior period, unchanged from 0001408710-24-000019:mdna:143]

[0001408710-24-000040:mdna:125]
[same as prior period, unchanged from 0001408710-24-000019:mdna:144]
