# FN note change history — 0001408710-24-000019 → 0001408710-24-000040


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-11-05):
[0001408710-24-000040:note_history:1]
As of September 27, 2024 and June 28, 2024, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.3 million and $2.0 million, respectively, or Thai baht 75.7 million and 73.2 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the subsidiary's operations related to the Israeli Customs department.
  (was, 2024-05-07, similarity 0.9849):
[0001408710-24-000019:note_history:1]
As of March 29, 2024 and June 30, 2023, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.0 million and $1.5 million, respectively, or Thai baht 73.2 million and 53.0 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the subsidiary's operations related to the Israeli Customs department.

- changed (2024-11-05):
[0001408710-24-000040:note_history:2]
As of September 27, 2024, the Company had purchase obligations and other commitments to third parties of $1.11 billion.
  (was, 2024-05-07, similarity 0.9444):
[0001408710-24-000019:note_history:2]
As of March 29, 2024, the Company had purchase obligations and other commitments to third parties of $850.9 million.

- changed (2024-11-05):
[0001408710-24-000040:note_history:3]
As of September 27, 2024, the Company had total capital expenditure commitments to third parties of $21.3 million.
  (was, 2024-05-07, similarity 0.9515):
[0001408710-24-000019:note_history:3]
As of March 29, 2024, the Company had total capital expenditure commitments to third parties of $27.7 million.

- added (2024-11-05):
[0001408710-24-000040:note_history:4]
Credit facility agreement

- added (2024-11-05):
[0001408710-24-000040:note_history:5]
On March 9, 2023, Fabrinet Thailand and the Parent Company (collectively, the “Borrowers”) and the Bank of Ayudhya Public Company Limited (the "Bank") entered into a credit facility agreement (the “2023 Credit Facility Agreement”), which provided a facility of $55.0 million.

- added (2024-11-05):
[0001408710-24-000040:note_history:6]
During the three months ended September 27, 2024, the Borrowers and the Bank agreed to amend the 2023 Credit Facility Agreement to reduce the facility to $30.0 million, which may be used for, among other things, an overdraft facility. The Company expects to finalize the amendment to the 2023 Credit Facility Agreement during the three months ending December 27, 2024.

- added (2024-11-05):
[0001408710-24-000040:note_history:7]
As of September 27, 2024, there was no amount outstanding under the 2023 Credit Facility Agreement.

- added (2024-11-05):
[0001408710-24-000040:note_history:8]
Under the 2023 Credit Facility Agreement, the Borrowers are required to maintain a debt-to-equity ratio of less than or equal to 1.5 times for Fabrinet Thailand and 1.0 times for the Parent Company.

- added (2024-11-05):
[0001408710-24-000040:note_history:9]
As of September 27, 2024, the Borrowers were in compliance with all of their financial covenants under the 2023 Credit Facility Agreement.

- added (2024-11-05):
[0001408710-24-000040:note_history:10]
Litigation and claim

- added (2024-11-05):
[0001408710-24-000040:note_history:11]
On June 28, 2024, Ngan In Leng and First Laser Limited (collectively, the “Plaintiffs”) filed a complaint in the Fuzhou Intermediate People’s Court (the “Court”) in Fuzhou, China against Fujian Enterprises (Holdings) Co., Ltd. (“FEHC”), Jian An Investment Limited (“Jian”), and Casix, Inc. (“Casix”), the Company's wholly-owned subsidiary located in the PRC. The complaint alleges unjust enrichment related to a purported investment in Casix by the Plaintiffs in 1997, which predates the Company's acquisition of Casix from JDS Uniphase Corporation. The Plaintiffs have requested that the Court order FEHC to return the unjust enrichment to the Plaintiffs in the amount of RMB 400 million, with interest from March 1, 2000, and order Jian and Casix to bear joint and several liability for all payment obligations of FEHC.

- added (2024-11-05):
[0001408710-24-000040:note_history:12]
In September 2024, the Court dismissed the lawsuit in its entirety based on jurisdictional grounds. The Plaintiffs have since appealed the Court's ruling to the High People's Court of Fujian Province (the "Appellate Court"). In their appeal, the Plaintiffs now claim that Casix is the primary obligor to return the alleged unjust enrichment to the Plaintiffs. The matter is currently pending before the Appellate Court. At this time, the Company is not able to quantify any potential liability in connection with this litigation due to its pending status and preliminary nature.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-11-05):
[0001408710-24-000040:note_history:13]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of September 27, 2024 and for the three months ended September 27, 2024 and September 29, 2023 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 28, 2024.
  (was, 2024-05-07, similarity 0.9534):
[0001408710-24-000019:note_history:13]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of March 29, 2024 and for the three and nine months ended March 29, 2024 and March 31, 2023 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 30, 2023.

- changed (2024-11-05):
[0001408710-24-000040:note_history:14]
The results for the three months ended September 27, 2024 may not be indicative of results for the year ending June 27, 2025 or any future periods.
  (was, 2024-05-07, similarity 0.9319):
[0001408710-24-000019:note_history:14]
The results for the three and nine months ended March 29, 2024 may not be indicative of results for the year ending June 28, 2024 or any future periods.

- changed (2024-11-05):
[0001408710-24-000040:note_history:15]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for expected credit losses, income taxes, and inventory obsolescence. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information.
  (was, 2024-05-07, similarity 0.964):
[0001408710-24-000019:note_history:15]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisitions, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information.

- changed (2024-11-05):
[0001408710-24-000040:note_history:16]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended September 27, 2024 and September 29, 2023 consisted of 13 weeks. Fiscal year 2025 will comprise 52 weeks and will end on June 27, 2025.
  (was, 2024-05-07, similarity 0.6604):
[0001408710-24-000019:note_history:16]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  March 29, 2024 and March 31, 2023 consisted of 13 weeks. The nine months ended March 29, 2024 and March 31, 2023 consisted of 39 and 40 weeks, respectively. Fiscal year 2024 will comprise 52 weeks and will end on June 28, 2024.

- changed (2024-11-05):
[0001408710-24-000040:note_history:17]
No new accounting standard was adopted during the three months ended September 27, 2024.
  (was, 2024-05-07, similarity 0.8931):
[0001408710-24-000019:note_history:17]
No new accounting standard was adopted during the nine months ended March 29, 2024.

- changed (2024-11-05):
[0001408710-24-000040:note_history:18]
In November 2023, the Financial Accounting Standards Board ("FASB") issued ASU 2023-07, “Segment Reporting (Topic 280), Improvements to Reportable Segment Disclosures,” which is intended to improve reportable segment disclosure requirements, primarily through additional disclosures about significant segment expenses. This ASU is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. This ASU is effective for the Company's annual periods beginning June 29, 2024, and interim periods beginning June 28, 2025, and will be applied retrospectively to all prior periods presented in the financial statements. The Company is currently evaluating the ASU to determine its impact on the Company's disclosures.
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740), Improvements to Income Tax Disclosures,” which requires more detailed income tax disclosures. This ASU requires entities to disclose disaggregated information about their effective tax rate reconciliation as well as expanded information on income taxes paid by jurisdiction. This ASU is effective for all entities for fiscal years beginning after December 15, 2024, with early adoption permitted for annual financial statements that have not yet been issued or made available for issuance. This ASU will be effective for the Company in the first quarter of fiscal year 2026. The Company is currently assessing the impact to its disclosures.
  (was, 2024-05-07, similarity 0.8732):
[0001408710-24-000019:note_history:18]
In November 2023, the Financial Accounting Standards Board ("FASB") issued ASU 2023-07, “Segment Reporting (Topic 280), Improvements to Reportable Segment Disclosures,” which is intended to improve reportable segment disclosure requirements, primarily through additional disclosures about significant segment expenses. This ASU is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. This ASU will be effective for the Company in the first quarter of fiscal year 2025. The Company is currently assessing the impact to its disclosures.
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740), Improvements to Income Tax Disclosures,” which requires more detailed income tax disclosures. This ASU requires entities to disclose disaggregated information about their effective tax rate reconciliation as well as expanded information on income taxes paid by jurisdiction. This ASU is effective for all entities for fiscal years beginning after December 15, 2024, with early adoption permitted for annual financial statements that have not yet been issued or made available for issuance. This ASU will be effective for the Company in the first quarter of fiscal year 2026. The Company is currently assessing the impact to its disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2024-11-05):
[0001408710-24-000019:note_history:19]
Borrowings 
The Company’s total borrowings, including current and non-current portions of long-term borrowings, consisted of the following:

- removed (2024-11-05):
[0001408710-24-000019:note_history:20]
| (in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofMarch 29, 2024 |  | As ofJune 30, 2023 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 3,047 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (8) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 3,039 |  |  | $ | 12,156 |  |

- removed (2024-11-05):
[0001408710-24-000019:note_history:21]
(1)The Company has entered into interest rate swaps that effectively fix a series of future interest payments on its term loans. Refer to Note 6.

- removed (2024-11-05):
[0001408710-24-000019:note_history:22]
The movements of long-term borrowings for the nine months ended March 29, 2024 and March 31, 2023 were as follows:

- removed (2024-11-05):
[0001408710-24-000019:note_history:23]
|  | Nine Months Ended |
| (in thousands) | March 29,2024 |  | March 31,2023 |
| Opening balance | $ | 12,188 |  |  | $ | 27,421 |  |
| Repayments during the period | (9,141) |  |  | (12,187) |  |
| Closing balance | $ | 3,047 |  |  | $ | 15,234 |  |

- removed (2024-11-05):
[0001408710-24-000019:note_history:24]
Credit facility agreements:

- removed (2024-11-05):
[0001408710-24-000019:note_history:25]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a credit facility agreement (the “2019 Credit Facility Agreement”), which provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million that may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the 2019 Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

- removed (2024-11-05):
[0001408710-24-000019:note_history:26]
Under the 2019 Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a term loan agreement (the "Term Loan Agreement") pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company's previous syndicated senior credit facility agreement.

- removed (2024-11-05):
[0001408710-24-000019:note_history:27]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. On March 9, 2023, the Borrower and the Bank amended the Term Loan Agreement to replace the interest rate reference from LIBOR to the Secured Overnight Financing Rate ("SOFR") effective from September 29, 2023. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three and nine months ended March 29, 2024, the Company recorded $0.1 million and $0.3 million, respectively, of interest expense in connection with this term loan, including the impact from interest rate swaps.

- removed (2024-11-05):
[0001408710-24-000019:note_history:28]
Any borrowings under the 2019 Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

- removed (2024-11-05):
[0001408710-24-000019:note_history:29]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, and restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any

- removed (2024-11-05):
[0001408710-24-000019:note_history:30]
payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of March 29, 2024, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

- removed (2024-11-05):
[0001408710-24-000019:note_history:31]
The events of default under the Term Loan Agreement include failure to timely pay amounts due under the Term Loan Agreement or the related finance documents, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

- removed (2024-11-05):
[0001408710-24-000019:note_history:32]
As of March 29, 2024, there was $3.0 million outstanding under the term loan.

- removed (2024-11-05):
[0001408710-24-000019:note_history:33]
On March 9, 2023, Fabrinet Thailand and the Parent Company (the “Borrowers”) and the Bank entered into a credit facility agreement (the “2023 Credit Facility Agreement”), which provides a facility of $55.0 million.

- removed (2024-11-05):
[0001408710-24-000019:note_history:34]
Any borrowings under the 2023 Credit Facility Agreement are secured by land and buildings owned by the Borrowers in the Pathumthani and Chonburi Provinces in Thailand.

- removed (2024-11-05):
[0001408710-24-000019:note_history:35]
Under the 2023 Credit Facility Agreement, the Borrowers are required to maintain a loan to value of the mortgaged real property ratio of not greater than 60%. The Borrowers are also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times.

- removed (2024-11-05):
[0001408710-24-000019:note_history:36]
As of March 29, 2024, there was no amount outstanding under the 2023 Credit Facility Agreement.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-11-05):
[0001408710-24-000040:note_history:37]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of September 27, 2024 and June 28, 2024:
  (was, 2024-05-07, similarity 0.9655):
[0001408710-24-000019:note_history:37]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of March 29, 2024 and June 30, 2023:

- added (2024-11-05):
[0001408710-24-000040:note_history:38]
|  | September 27, 2024 |  | June 28, 2024 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 112,061 |  |  | $ | 113,287 |  |  | $ | 110,671 |  |  | $ | 110,669 |  |
| Due between one to five years | 390,491 |  |  | 394,906 |  |  | 339,136 |  |  | 337,961 |  |
| Total | $ | 502,552 |  |  | $ | 508,193 |  |  | $ | 449,807 |  |  | $ | 448,630 |  |

- removed (2024-11-05):
[0001408710-24-000019:note_history:39]
|  | March 29, 2024 |  | June 30, 2023 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 101,042 |  |  | $ | 101,379 |  |  | $ | 172,992 |  |  | $ | 173,137 |  |
| Due between one to five years | 308,995 |  |  | 307,536 |  |  | 149,385 |  |  | 145,963 |  |
| Total | $ | 410,037 |  |  | $ | 408,915 |  |  | $ | 322,377 |  |  | $ | 319,100 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2024-11-05):
[0001408710-24-000019:note_history:40]
The movements of long-term borrowings for the nine months ended March 29, 2024 and March 31, 2023 were as follows:

- removed (2024-11-05):
[0001408710-24-000019:note_history:41]
|  | Nine Months Ended |
| (in thousands) | March 29,2024 |  | March 31,2023 |
| Opening balance | $ | 12,188 |  |  | $ | 27,421 |  |
| Repayments during the period | (9,141) |  |  | (12,187) |  |
| Closing balance | $ | 3,047 |  |  | $ | 15,234 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2024-11-05):
[0001408710-24-000019:note_history:42]
The Company’s total borrowings, including current and non-current portions of long-term borrowings, consisted of the following:

- removed (2024-11-05):
[0001408710-24-000019:note_history:43]
| (in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofMarch 29, 2024 |  | As ofJune 30, 2023 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 3,047 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (8) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 3,039 |  |  | $ | 12,156 |  |

- removed (2024-11-05):
[0001408710-24-000019:note_history:44]
(1)The Company has entered into interest rate swaps that effectively fix a series of future interest payments on its term loans. Refer to Note 6.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-11-05):
[0001408710-24-000040:note_history:45]
| (in thousands, except percentages) | Three Months EndedSeptember 27, 2024 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 29, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 307,820 |  |  |  |  | $ | 254,859 |  |  |  |
| Others (1) | 1,658 |  |  |  |  | 3,460 |  |  |  |
| Total revenue in North America | 309,478 |  |  | 38.5 | % |  | 258,319 |  |  | 37.7 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 290,953 |  |  |  |  | 210,676 |  |  |  |
| India | 76,830 |  |  |  |  | 70,777 |  |  |  |
| Hong Kong | 18,547 |  |  |  |  | 15,788 |  |  |  |
| China | 11,872 |  |  |  |  | 20,260 |  |  |  |
| Thailand | 11,121 |  |  |  |  | 13,027 |  |  |  |
| Singapore | 10,763 |  |  |  |  | 683 |  |  |  |
| Malaysia | 7,498 |  |  |  |  | 33,319 |  |  |  |
| Others | 9,054 |  |  |  |  | 7,292 |  |  |  |
| Total revenue in Asia-Pacific and others | 436,638 |  |  | 54.3 | % |  | 371,822 |  |  | 54.2 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 32,450 |  |  |  |  | 29,774 |  |  |  |
| Germany | 9,344 |  |  |  |  | 12,780 |  |  |  |
| Others | 16,318 |  |  |  |  | 12,782 |  |  |  |
| Total revenue in Europe | $ | 58,112 |  |  | 7.2 | % |  | $ | 55,336 |  |  | 8.1 | % |
| Total revenue | $ | 804,228 |  |  | 100.0 | % |  | $ | 685,477 |  |  | 100.0 | % |
  (was, 2024-05-07, similarity 0.9089):
[0001408710-24-000019:note_history:45]
| (in thousands, except percentages) | Three Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 268,475 |  |  |  |  | $ | 761,622 |  |  |  |
| Others (1) | 3,401 |  |  |  |  | 10,192 |  |  |  |
| Total revenue in North America | 271,876 |  |  | 37.2 | % |  | 771,814 |  |  | 36.3 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel (2) | 275,022 |  |  |  |  | 752,736 |  |  |  |
| India | 63,055 |  |  |  |  | 208,865 |  |  |  |
| Malaysia | 30,993 |  |  |  |  | 100,938 |  |  |  |
| Hong Kong | 15,147 |  |  |  |  | 43,085 |  |  |  |
| Thailand | 13,059 |  |  |  |  | 36,489 |  |  |  |
| China | 12,309 |  |  |  |  | 53,831 |  |  |  |
| Japan | 5,772 |  |  |  |  | 18,408 |  |  |  |
| Others | 1,655 |  |  |  |  | 4,390 |  |  |  |
| Total revenue in Asia-Pacific and others | 417,012 |  |  | 57.0 | % |  | 1,218,742 |  |  | 57.2 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 18,164 |  |  |  |  | 66,808 |  |  |  |
| Germany | 10,148 |  |  |  |  | 33,323 |  |  |  |
| Others | 14,335 |  |  |  |  | 39,019 |  |  |  |
| Total revenue in Europe | $ | 42,647 |  |  | 5.8 | % |  | $ | 139,150 |  |  | 6.5 | % |
| Total revenue | $ | 731,535 |  |  | 100.0 | % |  | $ | 2,129,706 |  |  | 100.0 | % |

- removed (2024-11-05):
[0001408710-24-000019:note_history:46]
| (in thousands, except percentages) | Three Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 310,100 |  |  |  |  | $ | 975,098 |  |  |  |
| Others (1) | 6,035 |  |  |  |  | 13,693 |  |  |  |
| Total revenue in North America | 316,135 |  |  | 47.5 | % |  | 988,791 |  |  | 49.7 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 85,731 |  |  |  |  | 247,942 |  |  |  |
| Israel | 85,562 |  |  |  |  | 182,732 |  |  |  |
| Hong Kong | 37,120 |  |  |  |  | 109,315 |  |  |  |
| Malaysia | 30,688 |  |  |  |  | 130,402 |  |  |  |
| Thailand | 16,706 |  |  |  |  | 45,420 |  |  |  |
| China | 11,194 |  |  |  |  | 60,738 |  |  |  |
| Japan | 10,044 |  |  |  |  | 32,129 |  |  |  |
| Others | 2,896 |  |  |  |  | 7,957 |  |  |  |
| Total revenue in Asia-Pacific and others | 279,941 |  |  | 42.1 | % |  | 816,635 |  |  | 41.1 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 40,292 |  |  |  |  | 103,440 |  |  |  |
| Germany | 14,532 |  |  |  |  | 40,975 |  |  |  |
| Others | 14,381 |  |  |  |  | 39,525 |  |  |  |
| Total revenue in Europe | $ | 69,205 |  |  | 10.4 | % |  | $ | 183,940 |  |  | 9.2 | % |
| Total revenue | $ | 665,281 |  |  | 100.0 | % |  | $ | 1,989,366 |  |  | 100.0 | % |

- removed (2024-11-05):
[0001408710-24-000019:note_history:47]
(2)Due to increase in revenue from a significant customer.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-11-05):
[0001408710-24-000040:note_history:48]
As of September 27, 2024 and June 28, 2024, the Company's contract assets were de minimis.
  (was, 2024-05-07, similarity 0.915):
[0001408710-24-000019:note_history:48]
As of March 29, 2024 and June 30, 2023, the Company's contract assets are de minimis.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-11-05):
[0001408710-24-000040:note_history:49]
| (in thousands, except percentages) | Three Months EndedSeptember 27, 2024 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 29, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 307,820 |  |  |  |  | $ | 254,859 |  |  |  |
| Others (1) | 1,658 |  |  |  |  | 3,460 |  |  |  |
| Total revenue in North America | 309,478 |  |  | 38.5 | % |  | 258,319 |  |  | 37.7 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 290,953 |  |  |  |  | 210,676 |  |  |  |
| India | 76,830 |  |  |  |  | 70,777 |  |  |  |
| Hong Kong | 18,547 |  |  |  |  | 15,788 |  |  |  |
| China | 11,872 |  |  |  |  | 20,260 |  |  |  |
| Thailand | 11,121 |  |  |  |  | 13,027 |  |  |  |
| Singapore | 10,763 |  |  |  |  | 683 |  |  |  |
| Malaysia | 7,498 |  |  |  |  | 33,319 |  |  |  |
| Others | 9,054 |  |  |  |  | 7,292 |  |  |  |
| Total revenue in Asia-Pacific and others | 436,638 |  |  | 54.3 | % |  | 371,822 |  |  | 54.2 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 32,450 |  |  |  |  | 29,774 |  |  |  |
| Germany | 9,344 |  |  |  |  | 12,780 |  |  |  |
| Others | 16,318 |  |  |  |  | 12,782 |  |  |  |
| Total revenue in Europe | $ | 58,112 |  |  | 7.2 | % |  | $ | 55,336 |  |  | 8.1 | % |
| Total revenue | $ | 804,228 |  |  | 100.0 | % |  | $ | 685,477 |  |  | 100.0 | % |
  (was, 2024-05-07, similarity 0.9089):
[0001408710-24-000019:note_history:49]
| (in thousands, except percentages) | Three Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 268,475 |  |  |  |  | $ | 761,622 |  |  |  |
| Others (1) | 3,401 |  |  |  |  | 10,192 |  |  |  |
| Total revenue in North America | 271,876 |  |  | 37.2 | % |  | 771,814 |  |  | 36.3 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel (2) | 275,022 |  |  |  |  | 752,736 |  |  |  |
| India | 63,055 |  |  |  |  | 208,865 |  |  |  |
| Malaysia | 30,993 |  |  |  |  | 100,938 |  |  |  |
| Hong Kong | 15,147 |  |  |  |  | 43,085 |  |  |  |
| Thailand | 13,059 |  |  |  |  | 36,489 |  |  |  |
| China | 12,309 |  |  |  |  | 53,831 |  |  |  |
| Japan | 5,772 |  |  |  |  | 18,408 |  |  |  |
| Others | 1,655 |  |  |  |  | 4,390 |  |  |  |
| Total revenue in Asia-Pacific and others | 417,012 |  |  | 57.0 | % |  | 1,218,742 |  |  | 57.2 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 18,164 |  |  |  |  | 66,808 |  |  |  |
| Germany | 10,148 |  |  |  |  | 33,323 |  |  |  |
| Others | 14,335 |  |  |  |  | 39,019 |  |  |  |
| Total revenue in Europe | $ | 42,647 |  |  | 5.8 | % |  | $ | 139,150 |  |  | 6.5 | % |
| Total revenue | $ | 731,535 |  |  | 100.0 | % |  | $ | 2,129,706 |  |  | 100.0 | % |

- added (2024-11-05):
[0001408710-24-000040:note_history:50]
| (in thousands, except percentages) | Three Months EndedSeptember 27, 2024 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 29, 2023 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 328,881 |  |  |  |  | $ | 242,043 |  |  |  |
| Telecom | 297,434 |  |  |  |  | 291,214 |  |  |  |
| Total revenue - Optical communications | $ | 626,315 |  |  | 77.9 | % |  | $ | 533,257 |  |  | 77.8 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 102,741 |  |  |  |  | $ | 88,358 |  |  |  |
| Industrial laser | 35,326 |  |  |  |  | 29,915 |  |  |  |
| Others | 39,846 |  |  |  |  | 33,947 |  |  |  |
| Total revenue - Non-optical communications | $ | 177,913 |  |  | 22.1 | % |  | $ | 152,220 |  |  | 22.2 | % |
| Total revenue | $ | 804,228 |  |  | 100.0 | % |  | $ | 685,477 |  |  | 100.0 | % |

- changed (2024-11-05):
[0001408710-24-000040:note_history:51]
As of September 27, 2024 and June 28, 2024, the Company's contract assets were de minimis.
  (was, 2024-05-07, similarity 0.915):
[0001408710-24-000019:note_history:51]
As of March 29, 2024 and June 30, 2023, the Company's contract assets are de minimis.

- changed (2024-11-05):
[0001408710-24-000040:note_history:52]
The following tables summarize the activity in the Company’s contract liabilities during the three months ended September 27, 2024:
  (was, 2024-05-07, similarity 0.9312):
[0001408710-24-000019:note_history:52]
The following tables summarize the activity in the Company’s contract liabilities during the nine months ended March 29, 2024:

- changed (2024-11-05):
[0001408710-24-000040:note_history:53]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 28, 2024 | $ | 7,846 |  |
| Advance payments received during the period | 2,627 |  |
| Revenue recognized | (1,550) |  |
| Ending balance, September 27, 2024 | $ | 8,923 |  |
  (was, 2024-05-07, similarity 0.9713):
[0001408710-24-000019:note_history:53]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 30, 2023 | $ | 3,036 |  |
| Advance payments received during the period | 9,131 |  |
| Revenue recognized | (5,301) |  |
| Ending balance, March 29, 2024 | $ | 6,866 |  |

- removed (2024-11-05):
[0001408710-24-000019:note_history:54]
| (in thousands, except percentages) | Three Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 310,100 |  |  |  |  | $ | 975,098 |  |  |  |
| Others (1) | 6,035 |  |  |  |  | 13,693 |  |  |  |
| Total revenue in North America | 316,135 |  |  | 47.5 | % |  | 988,791 |  |  | 49.7 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 85,731 |  |  |  |  | 247,942 |  |  |  |
| Israel | 85,562 |  |  |  |  | 182,732 |  |  |  |
| Hong Kong | 37,120 |  |  |  |  | 109,315 |  |  |  |
| Malaysia | 30,688 |  |  |  |  | 130,402 |  |  |  |
| Thailand | 16,706 |  |  |  |  | 45,420 |  |  |  |
| China | 11,194 |  |  |  |  | 60,738 |  |  |  |
| Japan | 10,044 |  |  |  |  | 32,129 |  |  |  |
| Others | 2,896 |  |  |  |  | 7,957 |  |  |  |
| Total revenue in Asia-Pacific and others | 279,941 |  |  | 42.1 | % |  | 816,635 |  |  | 41.1 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 40,292 |  |  |  |  | 103,440 |  |  |  |
| Germany | 14,532 |  |  |  |  | 40,975 |  |  |  |
| Others | 14,381 |  |  |  |  | 39,525 |  |  |  |
| Total revenue in Europe | $ | 69,205 |  |  | 10.4 | % |  | $ | 183,940 |  |  | 9.2 | % |
| Total revenue | $ | 665,281 |  |  | 100.0 | % |  | $ | 1,989,366 |  |  | 100.0 | % |

- removed (2024-11-05):
[0001408710-24-000019:note_history:55]
(2)Due to increase in revenue from a significant customer.

- removed (2024-11-05):
[0001408710-24-000019:note_history:56]
| (in thousands, except percentages) | Three Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 305,478 |  |  |  |  | $ | 835,642 |  |  |  |
| Telecom | 285,970 |  |  |  |  | 856,997 |  |  |  |
| Total revenue - Optical communications | $ | 591,448 |  |  | 80.9 | % |  | $ | 1,692,639 |  |  | 79.5 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 73,636 |  |  |  |  | $ | 241,166 |  |  |  |
| Industrial laser | 30,319 |  |  |  |  | 90,582 |  |  |  |
| Others | 36,132 |  |  |  |  | 105,319 |  |  |  |
| Total revenue - Non-optical communications | $ | 140,087 |  |  | 19.1 | % |  | $ | 437,067 |  |  | 20.5 | % |
| Total revenue | $ | 731,535 |  |  | 100.0 | % |  | $ | 2,129,706 |  |  | 100.0 | % |

- removed (2024-11-05):
[0001408710-24-000019:note_history:57]
| (in thousands, except percentages) | Three Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 122,385 |  |  |  |  | $ | 328,271 |  |  |  |
| Telecom | 380,230 |  |  |  |  | 1,177,961 |  |  |  |
| Total revenue - Optical communications | $ | 502,615 |  |  | 75.5 | % |  | $ | 1,506,232 |  |  | 75.7 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 94,107 |  |  |  |  | $ | 275,704 |  |  |  |
| Industrial laser | 31,040 |  |  |  |  | 97,396 |  |  |  |
| Others | 37,519 |  |  |  |  | 110,034 |  |  |  |
| Total revenue - Non-optical communications | $ | 162,666 |  |  | 24.5 | % |  | $ | 483,134 |  |  | 24.3 | % |
| Total revenue | $ | 665,281 |  |  | 100.0 | % |  | $ | 1,989,366 |  |  | 100.0 | % |
