# FN 8-K — 0001408710-24-000038 filed 2024-11-04

## item codes, every 8-K on or before 2024-11-05

- 2024-11-04 0001408710-24-000038 — 2.02, 9.01
- 2024-08-19 0001408710-24-000030 — 2.02, 5.02, 9.01
- 2024-06-14 0001408710-24-000023 — 5.02
- 2024-05-06 0001408710-24-000017 — 2.02, 9.01
- 2024-02-05 0001408710-24-000007 — 2.02, 9.01
- 2023-12-13 0001408710-23-000038 — 5.07
- 2023-11-06 0001408710-23-000034 — 2.02, 9.01
- 2023-08-21 0001408710-23-000026 — 2.02, 5.02, 9.01
- 2023-05-08 0001408710-23-000016 — 2.02, 5.02, 9.01
- 2023-02-06 0001408710-23-000006 — 2.02, 9.01
- 2022-12-13 0001408710-22-000062 — 5.07
- 2022-11-07 0001408710-22-000058 — 2.02, 9.01
- 2022-08-15 0001408710-22-000041 — 2.02, 5.02, 9.01
- 2022-05-02 0001408710-22-000026 — 2.02, 9.01
- 2022-01-31 0001408710-22-000016 — 2.02, 9.01
- 2022-01-19 0001408710-22-000010 — 5.02
- 2022-01-06 0001408710-22-000006 — 5.02
- 2021-12-10 0001408710-21-000051 — 5.07
- 2021-11-01 0001408710-21-000045 — 2.02, 9.01
- 2021-08-16 0001408710-21-000031 — 2.02, 5.02, 9.01
- 2021-05-03 0001408710-21-000019 — 2.02, 9.01
- 2021-02-01 0001408710-21-000008 — 2.02, 9.01
- 2020-12-11 0001193125-20-315861 — 5.07
- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2024-11-05

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001408710-24-000038:8k_2_02:1]
EX-99.1
2
fn-20241104xex991q125.htm
EX-99.1

[0001408710-24-000038:8k_2_02:2]
Document

[0001408710-24-000038:8k_2_02:3]
Exhibit 99.1

[0001408710-24-000038:8k_2_02:4]
Fabrinet Announces First Quarter Fiscal Year 2025 Financial Results

[0001408710-24-000038:8k_2_02:5]
•Record First Quarter Revenue Exceeds Guidance Range

[0001408710-24-000038:8k_2_02:6]
BANGKOK, Thailand – November 4, 2024 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its fiscal first quarter ended September 27, 2024.

[0001408710-24-000038:8k_2_02:7]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “We started fiscal year 2025 with significant momentum across our business. Record revenue of $804 million increased 17% from a year ago and was above our guidance range. We saw revenue growth from every product area, including our first telecom revenue growth in several quarters. Strong margins coupled with our revenue performance helped produce earnings per share at the upper end of our guidance range. We are optimistic that our strong business momentum and execution will extend into the fiscal second quarter as we continue to expand on our leadership in the market.”

[0001408710-24-000038:8k_2_02:8]
First Quarter Fiscal Year 2025 Financial Highlights

[0001408710-24-000038:8k_2_02:9]
GAAP Results

[0001408710-24-000038:8k_2_02:10]
•Revenue for the first quarter of fiscal year 2025 was $804.2 million, compared to $685.5 million for the first quarter of fiscal year 2024.

[0001408710-24-000038:8k_2_02:11]
•GAAP net income for the first quarter of fiscal year 2025 was $77.4 million, compared to $65.1 million for the first quarter of fiscal year 2024.

[0001408710-24-000038:8k_2_02:12]
•GAAP net income per diluted share for the first quarter of fiscal year 2025 was $2.13, compared to $1.78 for the first quarter of fiscal year 2024.

[0001408710-24-000038:8k_2_02:13]
Non-GAAP Results

[0001408710-24-000038:8k_2_02:14]
•Non-GAAP net income for the first quarter of fiscal year 2025 was $86.9 million, compared to $72.8 million for the first quarter of fiscal year 2024.

[0001408710-24-000038:8k_2_02:15]
•Non-GAAP net income per diluted share for the first quarter of fiscal year 2025 was $2.39, compared to $2.00 for the first quarter of fiscal year 2024.

[0001408710-24-000038:8k_2_02:16]
Business Outlook

[0001408710-24-000038:8k_2_02:17]
Based on information available as of November 4, 2024, Fabrinet is issuing guidance for its second fiscal quarter ending December 27, 2024, as follows:

[0001408710-24-000038:8k_2_02:18]
•Fabrinet expects second quarter revenue to be in the range of $800 million to $820 million.

[0001408710-24-000038:8k_2_02:19]
•GAAP net income per diluted share is expected to be in the range of $2.20 to $2.28, based on approximately 36.4 million fully diluted shares outstanding.

[0001408710-24-000038:8k_2_02:20]
•Non-GAAP net income per diluted share is expected to be in the range of $2.44 to $2.52, based on approximately 36.4 million fully diluted shares outstanding.

[0001408710-24-000038:8k_2_02:21]
Guidance for non-GAAP net income per diluted share excludes share-based compensation expenses and certain non-recurring items. A reconciliation of non-GAAP net income per diluted share to the corresponding GAAP measure is available at the end of this press release.

[0001408710-24-000038:8k_2_02:22]
Conference Call Information

[0001408710-24-000038:8k_2_02:23]
| What: |  | Fabrinet First Quarter Fiscal Year 2025 Financial Results Call |
| When: |  | November 4, 2024 |
| Time: |  | 5:00 p.m. ET |
| Live Call and Replay: |  | https://investor.fabrinet.com/events-and-presentations/events |

[0001408710-24-000038:8k_2_02:24]
A recorded version of this webcast will be available approximately two hours after the call and accessible at http://investor.fabrinet.com. The webcast will be archived on Fabrinet’s website for a period of one year.

[0001408710-24-000038:8k_2_02:25]
About Fabrinet

[0001408710-24-000038:8k_2_02:26]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China, and Israel. For more information visit: www.fabrinet.com.

[0001408710-24-000038:8k_2_02:27]
Forward-Looking Statements

[0001408710-24-000038:8k_2_02:28]
Non-GAAP Financial Measures

[0001408710-24-000038:8k_2_02:29]
In addition to reporting financial results in accordance with GAAP, we provide investors with certain non-GAAP financial measures. These non-GAAP financial measures are in addition to, and not a substitute for or superior to, measures of financial performance prepared in accordance with GAAP. We believe these non-GAAP financial measures provide investors with useful supplemental information to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, we use some of these non-GAAP financial measures to measure company performance for the purposes of determining employee incentive plan compensation.

[0001408710-24-000038:8k_2_02:30]
Non-GAAP gross profit, non-GAAP operating profit, non-GAAP net income and non-GAAP net income per diluted share exclude: share-based compensation expenses; severance payment and others; restructuring and other related costs; and amortization of deferred debt issuance costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations.

[0001408710-24-000038:8k_2_02:31]
Non-GAAP free cash flow is net cash provided by (used in) operating activities, minus capital expenditures (purchase of property, plant and equipment). We use free cash flow to measure our ability to generate additional cash from our business operations.

[0001408710-24-000038:8k_2_02:32]
There are a number of limitations related to the use of these non-GAAP financial measures versus their nearest GAAP equivalents. For example, other companies may calculate non-GAAP financial measures differently or may use other measures to evaluate their performance, all of which could reduce the usefulness of our non-GAAP financial measures as tools for comparison. We urge you to review the reconciliations of our non-GAAP financial measures to the most directly comparable GAAP financial measures, and not to rely on any single financial measure to evaluate our business.

[0001408710-24-000038:8k_2_02:33]
Investor Contact:

[0001408710-24-000038:8k_2_02:34]
Garo Toomajanian

[0001408710-24-000038:8k_2_02:35]
ir@fabrinet.com

[0001408710-24-000038:8k_2_02:36]
FABRINET

[0001408710-24-000038:8k_2_02:37]
CONSOLIDATED BALANCE SHEETS

[0001408710-24-000038:8k_2_02:38]
| (in thousands of U.S. dollars, except share data and par value) | September 27,2024 |  | June 28,2024 |
|  | (unaudited) |  |  |
| Assets |  |  |  |
| Current assets |  |  |  |
| Cash and cash equivalents | $ | 400,684 |  |  | $ | 409,973 |  |
| Short-term investments | 508,193 |  |  | 448,630 |  |
| Trade accounts receivable, net of allowance for expected credit losses of $1,954 and $1,629, respectively | 662,692 |  |  | 592,452 |  |
| Inventories | 440,405 |  |  | 463,206 |  |
| Prepaid expenses | 9,426 |  |  | 10,620 |  |
| Other current assets | 87,538 |  |  | 87,810 |  |
| Total current assets | 2,108,938 |  |  | 2,012,691 |  |
| Non-current assets |  |  |  |
| Property, plant and equipment, net | 311,241 |  |  | 307,240 |  |
| Intangibles, net | 2,201 |  |  | 2,321 |  |
| Operating right-of-use assets | 5,133 |  |  | 5,336 |  |
| Deferred tax assets | 10,902 |  |  | 10,446 |  |
| Other non-current assets | 598 |  |  | 485 |  |
| Total non-current assets | 330,075 |  |  | 325,828 |  |
| Total Assets | $ | 2,439,013 |  |  | $ | 2,338,519 |  |
| Liabilities and Shareholders’ Equity |  |  |  |
| Current liabilities |  |  |  |
| Trade accounts payable | 427,892 |  |  | 441,835 |  |
| Fixed assets payable | 10,166 |  |  | 14,380 |  |
| Operating lease liabilities, current portion | 1,416 |  |  | 1,355 |  |
| Income tax payable | 4,377 |  |  | 3,937 |  |
| Accrued payroll, bonus and related expenses | 26,658 |  |  | 22,116 |  |
| Accrued expenses | 30,519 |  |  | 19,916 |  |
| Other payables | 74,950 |  |  | 54,403 |  |
| Total current liabilities | 575,978 |  |  | 557,942 |  |
| Non-current liabilities |  |  |  |
| Deferred tax liability | 2,023 |  |  | 4,895 |  |
| Operating lease liability, non-current portion | 3,434 |  |  | 3,635 |  |
| Severance liabilities | 28,053 |  |  | 24,093 |  |
| Other non-current liabilities | 2,925 |  |  | 2,209 |  |
| Total non-current liabilities | 36,435 |  |  | 34,832 |  |
| Total Liabilities | 612,413 |  |  | 592,774 |  |
| Shareholders’ equity |  |  |  |
| Preferred shares ($5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of September 27, 2024 and June 28, 2024) | — |  |  | — |  |
| Ordinary shares ($500,000,000 shares authorized, $0.01 par value; 39,579,859 shares and 39,457,462 shares issued as of September 27, 2024 and June 28, 2024, respectively; and 36,267,639 shares and 36,145,242 shares outstanding as of September 27, 2024 and June 28, 2024, respectively) | 396 |  |  | 395 |  |
| Additional paid-in capital | 210,505 |  |  | 222,044 |  |
| Less: Treasury shares (3,312,220 shares as of September 27, 2024 and June 28, 2024) | (234,323) |  |  | (234,323) |  |
| Accumulated other comprehensive income (loss) | 11,858 |  |  | (3,141) |  |
| Retained earnings | 1,838,164 |  |  | 1,760,770 |  |
| Total Shareholders’ Equity | 1,826,600 |  |  | 1,745,745 |  |
| Total Liabilities and Shareholders’ Equity | $ | 2,439,013 |  |  | $ | 2,338,519 |  |

[0001408710-24-000038:8k_2_02:39]
FABRINET

[0001408710-24-000038:8k_2_02:40]
CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME (UNAUDITED)

[0001408710-24-000038:8k_2_02:41]
|  |  |  | Three Months Ended |
| (in thousands of U.S. dollars, except per share data) |  |  |  |  | September 27,2024 |  | September 29,2023 |
| Revenues |  |  |  |  | $ | 804,228 |  |  | $ | 685,477 |  |
| Cost of revenues |  |  |  |  | (705,202) |  |  | (601,073) |  |
| Gross profit |  |  |  |  | 99,026 |  |  | 84,404 |  |
| Selling, general and administrative expenses |  |  |  |  | (22,031) |  |  | (20,429) |  |
| Restructuring and other related costs |  |  |  |  | (57) |  |  | — |  |
| Operating income |  |  |  |  | 76,938 |  |  | 63,975 |  |
| Interest income |  |  |  |  | 10,933 |  |  | 5,898 |  |
| Interest expense |  |  |  |  | — |  |  | (45) |  |
| Foreign exchange gain (loss), net |  |  |  |  | (7,095) |  |  | 415 |  |
| Other income (expense), net |  |  |  |  | (19) |  |  | (80) |  |
| Income before income taxes |  |  |  |  | 80,757 |  |  | 70,163 |  |
| Income tax expense |  |  |  |  | (3,363) |  |  | (5,074) |  |
| Net income |  |  |  |  | 77,394 |  |  | 65,089 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities |  |  |  |  | 6,818 |  |  | 948 |  |
| Change in net unrealized gain (loss) on derivative instruments |  |  |  |  | 8,533 |  |  | (561) |  |
| Change in net retirement benefits plan – prior service cost |  |  |  |  | — |  |  | 126 |  |
| Change in foreign currency translation adjustment |  |  |  |  | (352) |  |  | 100 |  |
| Total other comprehensive income (loss), net of tax |  |  |  |  | 14,999 |  |  | 613 |  |
| Net comprehensive income |  |  |  |  | $ | 92,393 |  |  | $ | 65,702 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic |  |  |  |  | $ | 2.14 |  |  | $ | 1.80 |  |
| Diluted |  |  |  |  | $ | 2.13 |  |  | $ | 1.78 |  |
| Weighted-average number of ordinary shares outstanding (in thousands of shares) |  |  |  |  |  |  |  |
| Basic |  |  |  |  | 36,203 |  |  | 36,256 |  |
| Diluted |  |  |  |  | 36,408 |  |  | 36,481 |  |

[0001408710-24-000038:8k_2_02:42]
FABRINET

[0001408710-24-000038:8k_2_02:43]
CONSOLIDATED STATEMENTS OF CASH FLOWS (UNAUDITED)

[0001408710-24-000038:8k_2_02:44]
|  | Three Months Ended |
| (in thousands of U.S. dollars) | September 27,2024 |  | September 29,2023 |
| Cash flows from operating activities |  |  |  |
| Net income for the period | $ | 77,394 |  |  | $ | 65,089 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 12,752 |  |  | 11,961 |  |
| (Gain) loss on disposal of property, plant and equipment and intangibles | 10 |  |  | 12 |  |
| Amortization of discount (premium) of short-term investments | (1,087) |  |  | (596) |  |
| (Reversal of) allowance for expected credit losses | 325 |  |  | 803 |  |
| Unrealized loss (gain) on exchange rate and fair value of foreign currency forward contracts | 6,204 |  |  | (52) |  |
| Amortization of fair value at hedge inception of interest rate swaps | — |  |  | (88) |  |
| Share-based compensation | 8,682 |  |  | 7,733 |  |
| Deferred income tax expense (benefit) | (2,721) |  |  | 1,377 |  |
| Other non-cash expenses | 9 |  |  | 222 |  |
| Changes in operating assets and liabilities |  |  |  |
| Trade accounts receivable | (69,396) |  |  | (4,138) |  |
| Inventories | 22,801 |  |  | 79,481 |  |
| Other current assets and non-current assets | 1,205 |  |  | 3,238 |  |
| Trade accounts payable | (17,412) |  |  | (24,397) |  |
| Income tax payable | 467 |  |  | 963 |  |
| Accrued expenses | 21,902 |  |  | 2,668 |  |
| Other payables | 18,236 |  |  | 543 |  |
| Severance liabilities | 639 |  |  | 706 |  |
| Other current liabilities and non-current liabilities | 3,172 |  |  | (476) |  |
| Net cash provided by operating activities | 83,182 |  |  | 145,049 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of short-term investments | (95,572) |  |  | (77,692) |  |
| Proceeds from maturities of short-term investments | 43,914 |  |  | 35,909 |  |
| Purchase of property, plant and equipment | (20,250) |  |  | (11,435) |  |
| Purchase of intangibles | (122) |  |  | (180) |  |
| Proceeds from disposal of property, plant and equipment | 36 |  |  | 318 |  |
| Net cash used in investing activities | (71,994) |  |  | (53,080) |  |
| Cash flows from financing activities |  |  |  |
| Repayment of long-term borrowings | — |  |  | (3,047) |  |
| Withholding tax related to net share settlement of restricted share units | (20,220) |  |  | (12,147) |  |
| Net cash used in financing activities | (20,220) |  |  | (15,194) |  |
| Net increase (decrease) in cash and cash equivalents | $ | (9,032) |  |  | $ | 76,775 |  |
| Movement in cash and cash equivalents |  |  |  |
| Cash and cash equivalents at the beginning of period | $ | 409,973 |  |  | $ | 231,368 |  |
| Increase (decrease) in cash and cash equivalents | (9,032) |  |  | 76,775 |  |
| Effect of exchange rate on cash and cash equivalents | (257) |  |  | 195 |  |
| Cash and cash equivalents at the end of period | $ | 400,684 |  |  | $ | 308,338 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment-related payables | $ | 10,166 |  |  | $ | 9,313 |  |

[0001408710-24-000038:8k_2_02:45]
FABRINET

[0001408710-24-000038:8k_2_02:46]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES (UNAUDITED)

[0001408710-24-000038:8k_2_02:47]
Reconciliation of GAAP Gross Profit and GAAP Gross Margin to Non-GAAP Gross Profit and Non-GAAP Gross Margin

[0001408710-24-000038:8k_2_02:48]
|  |  |  | Three Months Ended |
| (in thousands of U.S. dollars) |  |  |  |  | September 27,2024 |  | September 29,2023 |
| Revenues |  |  |  |  |  |  |  |  | $ | 804,228 |  |  |  |  | $ | 685,477 |  |  |  |
| Gross profit (GAAP) |  |  |  |  |  |  |  |  | $ | 99,026 |  |  | 12.3 | % |  | $ | 84,404 |  |  | 12.3 | % |
| Share-based compensation expenses |  |  |  |  |  |  |  |  | 2,898 |  |  |  |  | 2,165 |  |  |  |
| Gross profit (Non-GAAP) |  |  |  |  |  |  |  |  | $ | 101,924 |  |  | 12.7 | % |  | $ | 86,569 |  |  | 12.6 | % |

[0001408710-24-000038:8k_2_02:49]
Reconciliation of GAAP Operating Profit and GAAP Operating Margin to Non-GAAP Operating Profit and Non-GAAP Operating Margin

[0001408710-24-000038:8k_2_02:50]
|  |  |  | Three Months Ended |
| (in thousands of U.S. dollars) |  |  |  |  | September 27,2024 |  | September 29,2023 |
| Revenues |  |  |  |  |  |  |  |  | $ | 804,228 |  |  |  |  | $ | 685,477 |  |  |  |
| Operating profit (GAAP) |  |  |  |  |  |  |  |  | $ | 76,938 |  |  | 9.6 | % |  | $ | 63,975 |  |  | 9.3 | % |
| Share-based compensation expenses |  |  |  |  |  |  |  |  | 8,682 |  |  |  |  | 7,733 |  |  |  |
| Severance payment and others |  |  |  |  |  |  |  |  | 730 |  |  |  |  | — |  |  |  |
| Restructuring and other related costs |  |  |  |  |  |  |  |  | 57 |  |  |  |  | — |  |  |  |
| Operating profit (Non-GAAP) |  |  |  |  |  |  |  |  | $ | 86,407 |  |  | 10.7 | % |  | $ | 71,708 |  |  | 10.5 | % |

[0001408710-24-000038:8k_2_02:51]
FABRINET

[0001408710-24-000038:8k_2_02:52]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES (UNAUDITED)

[0001408710-24-000038:8k_2_02:53]
Reconciliation of GAAP Net Income and EPS to Non-GAAP Net Income and EPS

[0001408710-24-000038:8k_2_02:54]
|  |  |  | Three Months Ended |
|  |  |  |  |  | September 27,2024 |  | September 29,2023 |
| (in thousands of U.S. dollars, except per share data) |  |  |  |  |  |  |  |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |
| GAAP measures |  |  |  |  |  |  |  |  | $ | 77,394 |  |  | $ | 2.13 |  |  | $ | 65,089 |  |  | $ | 1.78 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  |  |  |  |  |  |  | 2,898 |  |  | 0.08 |  |  | 2,165 |  |  | 0.06 |  |
| Total related to cost of revenues |  |  |  |  |  |  |  |  | 2,898 |  |  | 0.08 |  |  | 2,165 |  |  | 0.06 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  |  |  |  |  |  |  | 5,784 |  |  | 0.16 |  |  | 5,568 |  |  | 0.16 |  |
| Severance payment and others |  |  |  |  |  |  |  |  | 730 |  |  | 0.02 |  |  | — |  |  | — |  |
| Total related to selling, general and administrative expenses |  |  |  |  |  |  |  |  | 6,514 |  |  | 0.18 |  |  | 5,568 |  |  | 0.16 |  |
| Related to other income and expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other related costs |  |  |  |  |  |  |  |  | 57 |  |  | 0.00 |  |  | — |  |  | — |  |
| Amortization of deferred debt issuance costs |  |  |  |  |  |  |  |  | — |  |  | — |  |  | 8 |  |  | 0.00 |  |
| Total related to other income and expense |  |  |  |  |  |  |  |  | 57 |  |  | 0.00 |  |  | 8 |  |  | 0.00 |  |
| Total related to net income & EPS |  |  |  |  |  |  |  |  | 9,469 |  |  | 0.26 |  |  | 7,741 |  |  | 0.22 |  |
| Non-GAAP measures |  |  |  |  |  |  |  |  | $ | 86,863 |  |  | $ | 2.39 |  |  | $ | 72,830 |  |  | $ | 2.00 |  |
| Shares used in computing diluted net income per share (in thousands of shares) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  |  |  |  |  | 36,408 |  |  |  |  | 36,481 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  |  |  |  |  | 36,408 |  |  |  |  | 36,481 |  |

[0001408710-24-000038:8k_2_02:55]
FABRINET

[0001408710-24-000038:8k_2_02:56]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW (UNAUDITED)

[0001408710-24-000038:8k_2_02:57]
| (in thousands of U.S. dollars) |  |  |  | Three Months Ended |
|  |  |  |  |  |  | September 27,2024 |  | September 29,2023 |
| Net cash provided by operating activities |  |  |  |  |  | $ | 83,182 |  |  | $ | 145,049 |  |
| Less: Purchase of property, plant and equipment |  |  |  |  |  | (20,250) |  |  | (11,435) |  |
| Non-GAAP free cash flow |  |  |  |  |  | $ | 62,932 |  |  | $ | 133,614 |  |

[0001408710-24-000038:8k_2_02:58]
FABRINET

[0001408710-24-000038:8k_2_02:59]
GUIDANCE FOR QUARTER ENDING DECEMBER 27, 2024

[0001408710-24-000038:8k_2_02:60]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-24-000038:8k_2_02:61]
|  | DilutedEPS |
| GAAP net income per diluted share | $2.20 to $2.28 |
| Related to cost of revenues: |  |
| Share-based compensation expenses | 0.08 |
| Total related to cost of revenues | 0.08 |
| Related to selling, general and administrative expenses: |  |
| Share-based compensation expenses | 0.16 |
| Total related to selling, general and administrative expenses | 0.16 |
| Total related to net income & EPS | 0.24 |
| Non-GAAP net income per diluted share | $2.44 to $2.52 |
