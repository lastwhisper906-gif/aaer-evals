# FN MD&A — 0001193125-16-764312


## mdna

[0001193125-16-764312:mdna:1]
[same as prior period, unchanged from 0001193125-16-574999:mdna:1]

[0001193125-16-764312:mdna:2]
[same as prior period, unchanged from 0001193125-16-574999:mdna:2]

[0001193125-16-764312:mdna:3]
[same as prior period, unchanged from 0001193125-16-574999:mdna:3]

[0001193125-16-764312:mdna:4]
|  | • |  | our expectation that the portion of our future revenues attributable to customers in regions outside of North America will continue to decrease compared with the portion of those revenues for the three months ended September 30, 2016; |

[0001193125-16-764312:mdna:5]
[same as prior period, unchanged from 0001193125-16-574999:mdna:5]

[0001193125-16-764312:mdna:6]
|  | • |  | our expectation that our fiscal year 2017 selling, general and administrative (“SG&A”) expenses will increase on an absolute dollar basis and decrease as a percentage of revenue compared to fiscal year 2016; |

[0001193125-16-764312:mdna:7]
[same as prior period, unchanged from 0001193125-16-574999:mdna:7]

[0001193125-16-764312:mdna:8]
[same as prior period, unchanged from 0001193125-16-574999:mdna:8]

[0001193125-16-764312:mdna:9]
[same as prior period, unchanged from 0001193125-16-574999:mdna:9]

[0001193125-16-764312:mdna:10]
[same as prior period, unchanged from 0001193125-16-574999:mdna:10]

[0001193125-16-764312:mdna:11]
[same as prior period, unchanged from 0001193125-16-574999:mdna:11]

[0001193125-16-764312:mdna:12]
[same as prior period, unchanged from 0001193125-16-574999:mdna:12]

[0001193125-16-764312:mdna:13]
[same as prior period, unchanged from 0001193125-16-574999:mdna:13]

[0001193125-16-764312:mdna:14]
[same as prior period, unchanged from 0001193125-16-574999:mdna:14]

[0001193125-16-764312:mdna:15]
|  | • |  | our plans to execute acquisitions; |

[0001193125-16-764312:mdna:16]
[same as prior period, unchanged from 0001193125-16-574999:mdna:15]

[0001193125-16-764312:mdna:17]
[same as prior period, unchanged from 0001193125-16-574999:mdna:16]

[0001193125-16-764312:mdna:18]
[same as prior period, unchanged from 0001193125-16-574999:mdna:17]

[0001193125-16-764312:mdna:19]
[same as prior period, unchanged from 0001193125-16-574999:mdna:18]

[0001193125-16-764312:mdna:20]
We provide advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment
manufacturers (“OEMs”) of complex products such as optical communication components, modules and sub-systems, industrial lasers, medical devices and sensors. We offer a broad range of advanced optical and electro-mechanical capabilities
across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, complex printed circuit board assembly, advanced packaging, integration, final assembly and testing. Although, we focus
primarily on low-volume production of a wide variety of high complexity products, which we refer to as “low-volume, high-mix,” we also have the capability to accommodate high-volume production. Based on our experience with, and positive
feedback we have received from our customers, we believe we are a global leader in providing these services to the optical communications, industrial lasers and automotive markets.

[0001193125-16-764312:mdna:21]
Our customer base includes companies in complex industries that require advanced precision manufacturing capabilities such as optical
communications, industrial lasers, automotive and sensors. The products that we manufacture for our OEM customers include selective switching products; tunable transponders and transceivers; active optical cables; solid state, diode-pumped, gas and
fiber lasers; and sensors. In many cases, we are the sole outsourced manufacturing partner used by our customers for the products that we produce for them.

[0001193125-16-764312:mdna:22]
[same as prior period, unchanged from 0001193125-16-574999:mdna:21]

[0001193125-16-764312:mdna:23]
Business
acquisition

[0001193125-16-764312:mdna:24]
On September 14, 2016, we acquired 100% shareholding in Global CEM Solutions, Limited and all of its subsidiaries
(“Exception EMS”), a privately-held group located in Wiltshire, United Kingdom, for cash consideration of approximately $13.0 million, net of cash acquired. This is strategic acquisition involving new geographies, new sectors and new
customers. Exception EMS provides contract electronics manufacturing services primarily to the European electronics market with innovative solutions, adding value to the design, manufacture and testing of printed circuit board assemblies. Its
customers include industrial, energy, aerospace and defense companies, with approximately 80% of its revenue derived from customers in Europe. See Note 8 - business acquisitions to the unaudited condensed consolidated financial statements for
further details.

[0001193125-16-764312:mdna:25]
Flooding

[0001193125-16-764312:mdna:26]
During
the week of August 10, 2015, our subsidiary in China temporarily suspended production in its manufacturing facility due to flooding caused by Typhoon Soudelor and resumed operations on August 15, 2015. During the three months ended September 25,
2015, we recognized $0.9 million of losses incurred from the event in the unaudited condensed consolidated statements of operations and comprehensive income. We received a final payment of $0.8 million from an insurer against our claim for flood
damage during the three months ended March 25, 2016.

[0001193125-16-764312:mdna:27]
[same as prior period, unchanged from 0001193125-16-574999:mdna:26]

[0001193125-16-764312:mdna:28]
Our total revenues increased by $115.6 million, or 53.4%, to $332.0 million for the three months ended September 30, 2016, compared with $216.4
million for the three months ended September 25, 2015. The increase was primarily due to (1) an increase in our customers’ demand for both optical and non-optical communications manufacturing services during the three months ended September 30,
2016, (2) the positive impact from an additional week of revenue during the three months ended September 30, 2016 and (3) $0.8 million of revenue from companies we acquired during the three months ended September 30, 2016.

[0001193125-16-764312:mdna:29]
We believe our ability to expand our relationships with existing customers and attract new customers is due to a number of factors, including
our broad range of complex engineering and manufacturing service offerings, flexible low-cost manufacturing platform, process optimization capabilities, advanced supply chain management, excellent customer service, and experienced management team.
While we expect the prices we charge for our manufactured products to decrease over time (partly as a result of competitive market forces), we still believe we will be able to maintain favorable pricing for our services because of our ability to
reduce cycle time, adjust our product mix by focusing on more complicated products, improve product quality and yields, and reduce material costs for the products we manufacture. We believe these capabilities have enabled us to help our OEM
customers reduce their manufacturing costs while maintaining or improving the design, quality, reliability, and delivery times for their products.

[0001193125-16-764312:mdna:30]
[same as prior period, unchanged from 0001193125-16-574999:mdna:29]

[0001193125-16-764312:mdna:31]
We generate
revenues from three geographic regions: North America, Asia-Pacific and Europe. Revenues are attributed to a particular geographic area based on the bill-to location of our customers, notwithstanding that our customers may ultimately ship their
products to end customers in a different geographic region. The majority of our revenues are derived from our manufacturing facilities in Asia-Pacific.

[0001193125-16-764312:mdna:32]
The percentage of our revenues generated from a bill-to location outside of North America decreased from 50.8% in the three months ended
September 25, 2015 to 50.0% in the three months ended September 30, 2016, primarily because of a decrease in sales to our customers in Asia-Pacific. We expect that the portion of our future revenues attributable to customers in regions outside North
America will continue to decrease as compared with the portion of revenues attributable to such customers during the three months ended September 30, 2016.

[0001193125-16-764312:mdna:33]
[same as prior period, unchanged from 0001193125-16-574999:mdna:32]

[0001193125-16-764312:mdna:34]
|  |  | Three Months Ended |  |
|  |  | September 30,2016 |  |  | September 25,2015 |  |
| North America |  |  | 50.0 | % |  |  | 49.2 | % |
| Asia-Pacific |  |  | 34.6 |  |  |  | 38.8 |  |
| Europe |  |  | 15.4 |  |  |  | 12.0 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-16-764312:mdna:35]
[same as prior period, unchanged from 0001193125-16-574999:mdna:34]

[0001193125-16-764312:mdna:36]
[same as prior period, unchanged from 0001193125-16-574999:mdna:35]

[0001193125-16-764312:mdna:37]
[same as prior period, unchanged from 0001193125-16-574999:mdna:36]

[0001193125-16-764312:mdna:38]
The key components of our cost of revenues are material costs, employee costs, and infrastructure-related costs. Material costs generally
represent the majority of our cost of revenues. Several of the materials we require to manufacture products for our customers are customized for their products and often sourced from a single supplier or in some cases, our own subsidiaries.
Shortages from sole-source suppliers due to yield loss, quality concerns and capacity constraints, among other factors, may increase our expenses and negatively impact our gross profit margin or total revenues in a given quarter. Material costs
include scrap material. Historically, scrap rate diminishes during a product’s life cycle due to process, fixturing and test improvement and optimization.

[0001193125-16-764312:mdna:39]
A second significant element of our cost of revenues is employee costs, including indirect employee costs related to design, configuration and
optimization of manufacturing processes for our customers, quality testing, materials testing and other engineering services; and direct costs related to our manufacturing employees. Direct employee costs include employee salaries, insurance and
benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a lesser extent, costs to recruit,
train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand and the PRC, the fluctuation of the Thai baht and Chinese Renminbi (“RMB”) against our functional currency, the U.S. dollar, and our
ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to
mitigate these cost increases through improvements in employee productivity, employee retention and asset utilization.

[0001193125-16-764312:mdna:40]
Our infrastructure
costs are comprised of depreciation, utilities, facilities management and overhead costs. Most of our facility leases are long-term agreements. Our depreciation costs include buildings and fixed assets, primarily at our Pinehurst campus in Thailand,
and capital equipment located at each of our manufacturing locations.

[0001193125-16-764312:mdna:41]
During the three months ended September 30, 2016 and September 25,
2015, discretionary merit-based bonus awards were made to our non-executive employees. Charges included in cost of revenues for bonus awards to non-executive employees were $0.9 million and $0.7 million for the three months ended September 30, 2016
and September 25, 2015, respectively.

[0001193125-16-764312:mdna:42]
Share-based compensation expense included in cost of revenues was $1.0 million and $0.5 million for
the three months ended September 30, 2016 and September 25, 2015, respectively.

[0001193125-16-764312:mdna:43]
We expect to incur incremental costs of revenue as a
result of our planned expansion into new geographic markets, though we are not able to determine the amount of these incremental expenses.

[0001193125-16-764312:mdna:44]
Selling,
General and Administrative Expenses

[0001193125-16-764312:mdna:45]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing,
general and administrative and other support personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other
general expenses not related to cost of revenues. In fiscal year 2017, we expect our SG&A expenses will increase on an absolute dollar basis and decrease as a percentage of revenue compared with fiscal year 2016, due to the acquisition of
Exception EMS and higher share-based compensation expenses as a result of restricted share units and performance share units granted to executives in August 2016.

[0001193125-16-764312:mdna:46]
The compensation committee of our board of directors approved a fiscal year 2017 executive incentive plan with quantitative objectives, based
on achieving certain revenue targets and gross margin targets for our fiscal year ending June 30, 2017. Bonuses under our fiscal year 2017 executive incentive plan are payable after the end of fiscal year 2017. In fiscal year 2016, the compensation
committee approved a fiscal year 2016 executive incentive plan with quantitative objectives, based on achieving certain revenue and non-GAAP earnings per share targets for our fiscal year ended June 24, 2016, as well as qualitative objectives, based
on achieving individual performance goals. In the three months ended September 30, 2016, the compensation committee awarded bonuses to our executive employees for Company and individual achievements of performance under our fiscal 2016 executive
incentive plan. Discretionary merit-based bonus awards were also available to our non-executive employees and were payable as of September 30, 2016.

[0001193125-16-764312:mdna:47]
Charges included in SG&A expenses for bonus awards to non-executive and executive employees were $0.9 million and $0.6 million for the
three months ended September 30, 2016 and September 25, 2015, respectively.

[0001193125-16-764312:mdna:48]
Share-based compensation expense included in SG&A
expenses was $4.6 million and $2.1 million for the three months ended September 30, 2016 and September 25, 2015, respectively.

[0001193125-16-764312:mdna:49]
[same as prior period, unchanged from 0001193125-16-574999:mdna:49]

[0001193125-16-764312:mdna:50]
[same as prior period, unchanged from 0001193125-16-574999:mdna:50]

[0001193125-16-764312:mdna:51]
As a result of
our international operations, we are exposed to foreign exchange risk arising from various currency exposures primarily with respect to the Thai baht. Although a majority of our total revenues is denominated in U.S. dollars, a substantial portion of
our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rate between the Thai baht and the U.S. dollar has fluctuated substantially in recent years and may continue to fluctuate substantially in the future.
We report our financial results in U.S. dollars and our results of operations have been and may continue to be negatively impacted owing to appreciation of the Thai baht against the U.S. dollar. Smaller portions of our expenses are incurred in a
variety of other currencies, including RMB, Pound sterling (“GBP”), Canadian dollars, Euros, and Japanese yen, the appreciation of which may also negatively impact our financial results.

[0001193125-16-764312:mdna:52]
In addition, we are exposed to foreign exchange risk in connection with the long-term loan and cross currency swap arrangements we entered
into with TMB Bank Public Company Limited (the “Bank”) in May 2011 for the construction of Pinehurst Building 6. The terms of the contract with the Bank provide the following facilities: (1) a term loan facility for up to Thai baht
960 million (equal to $30.0 million) with a fixed interest rate of 5.28% per annum, (2) a hedging facility for currency interest rate swaps with a notional amount of $30.0 million, and (3) a settlement limit of Thai baht
65 million, subject to certain terms and conditions as set forth therein. Borrowings and interest under the term loan have been scheduled to be repaid on a quarterly basis between September 2011 and March 2017. As of September 30, 2016, we had
outstanding borrowings under the term loan facility of $3.0 million. Under the terms of the cross currency swap arrangements, amounts drawn in Thai baht were converted to U.S. dollars for repayment by us on a quarterly basis at the floating rate of
London Interbank Offered Rate (LIBOR) plus 2.8% per annum.

[0001193125-16-764312:mdna:53]
In order to manage the risks arising from fluctuations in foreign
currency exchange rates, we use derivative instruments. We may enter into exchange currency forward or put option contracts to manage foreign currency exposures associated with certain assets and liabilities and other forecasted foreign currency
transactions and may designate these instruments as hedging instruments. The forward and put option contracts generally have maturities of up to 12 months. All foreign currency exchange contracts are recognized in the unaudited condensed
consolidated balance sheet at fair value. Gain or loss on our forward and put option contracts generally offset the assets, liabilities, and transactions economically hedged.

[0001193125-16-764312:mdna:54]
We had foreign currency denominated assets and liabilities in Thai baht, RMB and GBP as follows:

[0001193125-16-764312:mdna:55]
|  |  | As of September 30, 2016 |  |  | As of June 24, 2016 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 456,782 |  |  | $ | 13,164 |  |  |  | 68.8 |  |  |  | 834,536 |  |  | $ | 23,594 |  |  |  | 91.3 |  |
| RMB |  |  | 12,830 |  |  |  | 1,921 |  |  |  | 10.0 |  |  |  | 14,835 |  |  |  | 2,255 |  |  |  | 8.7 |  |
| GBP |  |  | 3,130 |  |  |  | 4,057 |  |  |  | 21.2 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  |  |  |  |  | $ | 19,142 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 25,840 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,884,630 |  |  | $ | 54,312 |  |  |  | 87.6 |  |  |  | 1,517,782 |  |  | $ | 42,912 |  |  |  | 92.0 |  |
| RMB |  |  | 22,241 |  |  |  | 3,331 |  |  |  | 5.4 |  |  |  | 24,654 |  |  |  | 3,748 |  |  |  | 8.0 |  |
| GBP |  |  | 3,340 |  |  |  | 4,328 |  |  |  | 7.0 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  |  |  |  |  | $ | 61,971 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 46,660 |  |  |  | 100.0 |  |

[0001193125-16-764312:mdna:56]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other
current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and
offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of September 30, 2016 and June 24, 2016, there were $42.5 million and $84.5 million in forward contracts, respectively, outstanding
against forecasted Thai baht payables.

[0001193125-16-764312:mdna:57]
The RMB assets represent cash and cash equivalents, accounts receivable and other current assets.
The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of September 30, 2016 and June 24, 2016, we did not have any derivative contracts denominated in RMB.

[0001193125-16-764312:mdna:58]
The GBP assets represent cash and accounts receivable. The GBP liabilities represent trade
accounts payable and other payables. As of September 30, 2016, we did not have any derivative contracts denominated in GBP.

[0001193125-16-764312:mdna:59]
For the three
months ended September 30, 2016 and September 25, 2015, we recorded loss of $0.1 million and $12.1 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of
operations and comprehensive income.

[0001193125-16-764312:mdna:60]
[same as prior period, unchanged from 0001193125-16-574999:mdna:59]

[0001193125-16-764312:mdna:61]
[same as prior period, unchanged from 0001193125-16-574999:mdna:60]

[0001193125-16-764312:mdna:62]
[same as prior period, unchanged from 0001193125-16-574999:mdna:61]

[0001193125-16-764312:mdna:63]
[same as prior period, unchanged from 0001193125-16-574999:mdna:62]

[0001193125-16-764312:mdna:64]
[same as prior period, unchanged from 0001193125-16-574999:mdna:63]

[0001193125-16-764312:mdna:65]
[same as prior period, unchanged from 0001193125-16-574999:mdna:64]

[0001193125-16-764312:mdna:66]
[same as prior period, unchanged from 0001193125-16-574999:mdna:65]

[0001193125-16-764312:mdna:67]
[same as prior period, unchanged from 0001193125-16-574999:mdna:66]

[0001193125-16-764312:mdna:68]
On January 5, 2007, SAFE promulgated the Detailed Rules for Implementing the Measures for the Administration on Individual Foreign Exchange,
or the Implementation Rules. Under the Implementation Rules, PRC citizens who are granted share options by an overseas publicly-listed company are required, through a PRC agent or PRC subsidiary of such overseas publicly-listed company, to register
with SAFE and complete certain other procedures.

[0001193125-16-764312:mdna:69]
In addition, the General Administration of Taxation has issued circulars concerning
employee share options. Under these circulars, our employees working in the PRC who exercise share options will be subject to PRC individual income tax. Our PRC subsidiary has obligations to file documents related to employee share options with
relevant tax authorities and withhold individual income taxes of those employees who exercise their share options.

[0001193125-16-764312:mdna:70]
Furthermore, our
transfer of funds to our subsidiaries in Thailand and the PRC are each subject to approval by governmental authorities in case of an increase in registered capital, or subject to registration with governmental authorities in case of a shareholder
loan. These limitations on the flow of funds between our subsidiaries and us could restrict our ability to act in response to changing market conditions.

[0001193125-16-764312:mdna:71]
[same as prior period, unchanged from 0001193125-16-574999:mdna:70]

[0001193125-16-764312:mdna:72]
Our effective tax rate
is a function of the mix of tax rates in the various jurisdictions in which we do business. We are domiciled in the Cayman Islands. Under the current laws of the Cayman Islands, we are not subject to tax in the Cayman Islands on income or capital
gains. We have received this undertaking for a 20-year period ending August 24, 2019, and after the expiration date, we may request a renewal with the office of the Clerk of the Cabinet for another twenty years.

[0001193125-16-764312:mdna:73]
Throughout the period of our operations in Thailand, we have generally received income tax and
other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption is currently available to us through June 2020 on income generated from projects to manufacture
certain products at Pinehurst campus. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our
current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted. In March 2016, the Thailand Revenue Department announced a permanent decrease of corporate income tax rates to 20% for tax periods
beginning on or after January 1, 2016. As a result, corporate income tax rates for our Thai subsidiary remain at 20% from fiscal year 2017 onward.

[0001193125-16-764312:mdna:74]
Critical Accounting Policies and Use of Estimates

[0001193125-16-764312:mdna:75]
We prepare our condensed consolidated financial statements in conformity with U.S. GAAP, which requires us to make estimates and assumptions
that affect the reported amounts of assets and liabilities, the disclosure of contingent liabilities on the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the financial reporting
period. We continually evaluate these estimates and assumptions based on the most recently available information, our own historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results
form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Because the use of estimates is an integral component of the financial reporting process, actual results could
differ from those estimates. Some of our accounting policies require higher degrees of judgment than others in their application. We consider the policies discussed below to be critical to an understanding of our condensed consolidated financial
statements, as their application places the most significant demands on our management’s judgment.

[0001193125-16-764312:mdna:76]
Our critical accounting policies
are disclosed in our Annual Report on Form 10-K for the fiscal year ended June 24, 2016.

[0001193125-16-764312:mdna:77]
[same as prior period, unchanged from 0001193125-16-574999:mdna:76]

[0001193125-16-764312:mdna:78]
The following table sets forth a summary of our unaudited condensed consolidated statements of operations and comprehensive income. Note that
period-to-period comparisons of operating results should not be relied upon as indicative of future performance.

[0001193125-16-764312:mdna:79]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 30,2016 |  |  | September 25,2015 |  |
| Revenues |  | $ | 332,043 |  |  | $ | 216,433 |  |
| Cost of revenues |  |  | (292,435 | ) |  |  | (190,422 | ) |
| Gross profit |  |  | 39,608 |  |  |  | 26,011 |  |
| Selling, general and administrative expenses |  |  | (15,832 | ) |  |  | (11,900 | ) |
| Other expense related to flooding |  |  | — |  |  |  | (864 | ) |
| Operating income |  |  | 23,776 |  |  |  | 13,247 |  |
| Interest income |  |  | 437 |  |  |  | 442 |  |
| Interest expense |  |  | (1,322 | ) |  |  | (402 | ) |
| Foreign exchange gain (loss), net |  |  | 1,657 |  |  |  | (10,492 | ) |
| Other income |  |  | 143 |  |  |  | 103 |  |
| Income before income taxes |  |  | 24,691 |  |  |  | 2,898 |  |
| Income tax expense |  |  | (1,925 | ) |  |  | (1,295 | ) |
| Net income |  |  | 22,766 |  |  |  | 1,603 |  |
| Other comprehensive income, net of tax |  |  | 396 |  |  |  | 87 |  |
| Net comprehensive income |  | $ | 23,162 |  |  | $ | 1,690 |  |

[0001193125-16-764312:mdna:80]
The following table sets forth a summary of our unaudited condensed consolidated statements of operations and
comprehensive income as a percentage of total revenues for the periods indicated.

[0001193125-16-764312:mdna:81]
|  |  | Three Months Ended |  |
|  |  | September 30,2016 |  |  | September 25,2015 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (88.1 | ) |  |  | (88.0 | ) |
| Gross profit |  |  | 11.9 |  |  |  | 12.0 |  |
| Selling, general and administrative expenses |  |  | (4.8 | ) |  |  | (5.5 | ) |
| Other expense related to flooding |  |  | — |  |  |  | (0.4 | ) |
| Operating income |  |  | 7.1 |  |  |  | 6.1 |  |
| Interest income |  |  | 0.1 |  |  |  | 0.2 |  |
| Interest expense |  |  | (0.4 | ) |  |  | (0.2 | ) |
| Foreign exchange gain (loss), net |  |  | 0.5 |  |  |  | (4.9 | ) |
| Other income |  |  | 0.1 |  |  |  | 0.1 |  |
| Income before income taxes |  |  | 7.4 |  |  |  | 1.3 |  |
| Income tax expense |  |  | (0.6 | ) |  |  | (0.6 | ) |
| Net income |  |  | 6.9 |  |  |  | 0.7 |  |
| Other comprehensive income, net of tax |  |  | 0.1 |  |  |  | 0.1 |  |
| Net comprehensive income |  |  | 7.0 | % |  |  | 0.8 | % |

[0001193125-16-764312:mdna:82]
[same as prior period, unchanged from 0001193125-16-574999:mdna:81]

[0001193125-16-764312:mdna:83]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 30,2016 |  |  | September 25,2015 |  |
| Optical communications |  | $ | 256,807 |  |  | $ | 154,762 |  |
| Lasers, sensors and other |  |  | 75,236 |  |  |  | 61,671 |  |
| Total |  | $ | 332,043 |  |  | $ | 216,433 |  |

[0001193125-16-764312:mdna:84]
[same as prior period, unchanged from 0001193125-16-574999:mdna:83]

[0001193125-16-764312:mdna:85]
Comparison of Three Months Ended September 30, 2016 with Three Months Ended September 25,
2015

[0001193125-16-764312:mdna:86]
[same as prior period, unchanged from 0001193125-16-574999:mdna:85]

[0001193125-16-764312:mdna:87]
Our total revenues increased by $115.6 million, or 53.4%, to $332.0 million for the three months ended September 30, 2016, compared with $216.4
million for the three months ended September 25, 2015. This increase was primarily due to (1) an increase in our customers’ demand for both optical and non-optical communications manufacturing services during the three months ended September
30, 2016, (2) the positive impact of an additional week of revenue during the three months ended September 30, 2016 and (3) $0.8 million of revenue from companies which we acquired during the three months ended September 30, 2016. Revenues from
optical communications products represented 77.3% of our total revenues for the three months ended September 30, 2016, compared to 71.5% for the three months ended September 25, 2015.

[0001193125-16-764312:mdna:88]
[same as prior period, unchanged from 0001193125-16-574999:mdna:88]

[0001193125-16-764312:mdna:89]
Our
cost of revenues increased by $102.0 million, or 53.6%, to $292.4 million, or 88.1% of total revenues, for the three months ended September 30, 2016, compared with $190.4 million, or 88.0% of total revenues, for the three months ended
September 25, 2015. This increase in cost of revenues was primarily due to an increase in sales volume, partially offset by a more favorable product mix. Cost of revenues also included share-based compensation expense of $1.0 million for the
three months ended September 30, 2016, compared with $0.5 million for the three months ended September 25, 2015.

[0001193125-16-764312:mdna:90]
[same as prior period, unchanged from 0001193125-16-574999:mdna:91]

[0001193125-16-764312:mdna:91]
Our gross profit increased by $13.6 million, or 52.3%, to $39.6 million, or 11.9% of total revenues, for the three months ended
September 30, 2016, compared with $26.0 million, or 12.0% of total revenues, for the three months ended September 25, 2015.

[0001193125-16-764312:mdna:92]
[same as prior period, unchanged from 0001193125-16-574999:mdna:94]

[0001193125-16-764312:mdna:93]
Our
SG&A expenses increased by $3.9 million, or 33.0%, to $15.8 million, or 4.8% of total revenues, for the three months ended September 30, 2016, compared with $11.9 million, or 5.5% of total revenues, for the three months ended
September 25, 2015. Our SG&A expenses increased in absolute dollars due primarily to an increase in expenses relating to merger and acquisition activities of $1.1 million and severance and related payments of $0.6 million to an executive
who left the Company in July 2016. We also recorded share-based compensation charges of $4.6 million for the three months ended September 30, 2016, compared with $2.1 million for the three months ended September 25, 2015.

[0001193125-16-764312:mdna:94]
Other expense related to flooding.

[0001193125-16-764312:mdna:95]
In the three months ended September 30, 2016, we did not have any expenses related to flooding. In the three months ended September 25,
2015, we recognized other expense related to flooding of $0.9 million, which mainly consisted of $0.6 million of repaired cost of equipment and $0.2 million of inventory losses.

[0001193125-16-764312:mdna:96]
[same as prior period, unchanged from 0001193125-16-574999:mdna:102]

[0001193125-16-764312:mdna:97]
Our
operating income increased by $10.5 million to $23.8 million, or 7.2% of total revenues, for the three months ended September 30, 2016, compared with $13.2 million, or 6.1% of total revenues, for the three months ended September 25, 2015.

[0001193125-16-764312:mdna:98]
[same as prior period, unchanged from 0001193125-16-574999:mdna:105]

[0001193125-16-764312:mdna:99]
Our interest income remained flat at $0.4 million, or 0.1% of total revenues, for the three months ended September 30, 2016, compared with
$0.4 million, or 0.2% of total revenues, for the three months ended September 25, 2015.

[0001193125-16-764312:mdna:100]
[same as prior period, unchanged from 0001193125-16-574999:mdna:108]

[0001193125-16-764312:mdna:101]
Our interest expense increased by $0.9 million to $1.3 million for the three months ended September 30, 2016, compared with $0.4 million
for the three months ended September 25, 2015.

[0001193125-16-764312:mdna:102]
The increase was primarily due to increase in average balance of our bank borrowings.

[0001193125-16-764312:mdna:103]
[same as prior period, unchanged from 0001193125-16-574999:mdna:111]

[0001193125-16-764312:mdna:104]
Our foreign exchange gain, net, increased by $12.1 million to foreign exchange gain, net, of $1.7 million, or 0.5% of total revenues, for the
three months ended September 30, 2016, compared with foreign exchange loss, net, of $10.5 million, or 4.9% of total revenues, for the three months ended September 25, 2015. The increase was due to changes in the fair value of forward contracts as of
September 30, 2016 that were not designated as hedging instruments.

[0001193125-16-764312:mdna:105]
[same as prior period, unchanged from 0001193125-16-574999:mdna:113]

[0001193125-16-764312:mdna:106]
We recorded income before income taxes of $24.7 million for the three months ended September 30, 2016, compared with $2.9 million for the
three months ended September 25, 2015.

[0001193125-16-764312:mdna:107]
[same as prior period, unchanged from 0001193125-16-574999:mdna:115]

[0001193125-16-764312:mdna:108]
Our provision for income tax reflects an effective tax rate of 6.7% for each of the three months ended September 30, 2016 and
September 25, 2015. The effective tax rate remained flat, and our taxable income and income tax expenses for the three months ended September 30, 2016 increased proportionately on an absolute dollars basis, compared with the three months ended
September 25, 2015.

[0001193125-16-764312:mdna:109]
[same as prior period, unchanged from 0001193125-16-574999:mdna:118]

[0001193125-16-764312:mdna:110]
We recorded net income of $22.8 million, or 6.9% of total revenues, for the three months ended September 30, 2016, compared with $1.6
million, or 0.7% of total revenues, for the three months ended September 25, 2015.

[0001193125-16-764312:mdna:111]
Other comprehensive (loss) income.

[0001193125-16-764312:mdna:112]
We recorded other comprehensive loss of $0.3 million, or 0.1% of total revenues, for the three months ended September 30, 2016, compared
with other comprehensive income of $0.1 million, or 0.1% of total revenues, for the three months ended September 25, 2015.

[0001193125-16-764312:mdna:113]
Liquidity and Capital
Resources

[0001193125-16-764312:mdna:114]
[same as prior period, unchanged from 0001193125-16-574999:mdna:125]

[0001193125-16-764312:mdna:115]
We primarily finance our operations through cash flow from operations. As of September 30, 2016 and September 25, 2015, we had cash, cash
equivalents, and marketable securities of $253.6 million and $247.6 million, respectively, and outstanding debt of $70.8 million and $39.0 million, respectively.

[0001193125-16-764312:mdna:116]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of
three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents for the three months ended September 30, 2016 and September 25, 2015 was 0.5% and 1.0%, respectively.

[0001193125-16-764312:mdna:117]
Our cash investments are made in accordance with an investment policy approved by the Audit Committee of our Board of Directors. In
general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed income securities are primarily classified as
available-for-sale and are recorded at fair value. The cost of securities sold is based on the specific identification method. Unrealized gains and losses on these securities are recorded as other comprehensive income (loss) and are reported as a
separate component of shareholders’ equity.

[0001193125-16-764312:mdna:118]
During the three months ended September 30, 2016, we borrowed a revolving loan of $13.5
million and repaid a term loan of $3.4 million under our Facility Agreement; as a result, as of September 30, 2016, we had a long-term borrowing of $46.6 million and short-term borrowing of $20.0 million under our Facility Agreement. To better
manage our cash on hand, we held investments in short-term marketable securities of $147.7 million as of September 30, 2016.

[0001193125-16-764312:mdna:119]
We believe
that our current cash and cash equivalents, marketable securities, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for the next 12 months. Our
ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001193125-16-764312:mdna:120]
In December 2015, we began construction of a new manufacturing facility at our Chonburi campus, which we substantially completed in the first
quarter of fiscal year 2017. We expect to begin operations at this new facility in the second quarter of fiscal year 2017. We believe that our current manufacturing capacity is sufficient to meet our anticipated production requirements for at least
the next few quarters. We maintain a long-term loan associated with construction of production facilities at our Pinehurst campus in Thailand that will come due within the next 12 months. We also have a sufficient credit facility in place to fund
the amount needed to construct a new building at our Chonburi campus. We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations.

[0001193125-16-764312:mdna:121]
[same as prior period, unchanged from 0001193125-16-574999:mdna:132]

[0001193125-16-764312:mdna:122]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 30,2016 |  |  | September 25,2015 |  |
| Net cash (used in) provided by operating activities |  | $ | (1,002 | ) |  | $ | 4,539 |  |
| Net cash used in investing activities |  | $ | (46,650 | ) |  | $ | (20,402 | ) |
| Net cash provided by (used in) financing activities |  | $ | 10,441 |  |  | $ | (1,184 | ) |
| Net decrease in cash and cash equivalents |  | $ | (37,211 | ) |  | $ | (17,047 | ) |

[0001193125-16-764312:mdna:123]
[same as prior period, unchanged from 0001193125-16-574999:mdna:134]

[0001193125-16-764312:mdna:124]
Net cash used in operating activities decreased by $5.5 million, or 122.1%, to $1.0 million for the three months ended September 30, 2016,
compared with net cash provided by operating activities of $4.5 million for the three months ended September 25, 2015. This decrease was due to a number of factors, including an increase in net income of $22.0 million, offset by increases in
accounts receivable of $6.2 million and inventory of $8.7 million due to higher sales and customer demand, the impact of unrealized (gain) loss on the exchange rate and fair value of derivative instruments of $10.6 million and a decrease of other
liabilities of $7.8 million, as compared with the three months ended September 25, 2015.

[0001193125-16-764312:mdna:125]
[same as prior period, unchanged from 0001193125-16-574999:mdna:136]

[0001193125-16-764312:mdna:126]
Net cash used in investing activities increased by $26.2 million, or 128.7%, to $46.6 million for the three months ended September 30,
2016, compared with net cash used in investing activities of $20.4 million for the three months ended September 25, 2015. This increase was primarily due to the payment of $13.0 million for the acquisition of Exception EMS during the three
months ended September 30, 2016 and an increase in the purchase of property, plant and equipment of $18.7 million, majority was for the new facility in Thailand, offset by a net decrease in marketable securities of $3.1 million.

[0001193125-16-764312:mdna:127]
[same as prior period, unchanged from 0001193125-16-574999:mdna:138]

[0001193125-16-764312:mdna:128]
Net
cash provided by financing activities increased by $11.6 million, or 981.8%, to $10.4 million for the three months ended September 30, 2016, compared with net cash used in financing activities of $1.2 million for the three months ended
September 25, 2015. This increase was primarily due to proceeds from revolving loan from bank of $13.5 million under our Facility Agreement during the three months ended September 30, 2016.

[0001193125-16-764312:mdna:129]
[same as prior period, unchanged from 0001193125-16-574999:mdna:140]

[0001193125-16-764312:mdna:130]
[same as prior period, unchanged from 0001193125-16-574999:mdna:141]

[0001193125-16-764312:mdna:131]
[same as prior period, unchanged from 0001193125-16-574999:mdna:142]

[0001193125-16-764312:mdna:132]
[same as prior period, unchanged from 0001193125-16-574999:mdna:143]
