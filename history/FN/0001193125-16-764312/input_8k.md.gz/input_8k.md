# FN 8-K — 0001193125-16-761705 filed 2016-11-07

## item codes, every 8-K on or before 2016-11-09

- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2016-11-09

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-761705:8k_2_02:1]
EX-99.1
2
d487699dex991.htm
EX-99.1

[0001193125-16-761705:8k_2_02:2]
EX-99.1

[0001193125-16-761705:8k_2_02:3]
Exhibit 99.1

[0001193125-16-761705:8k_2_02:4]
Fabrinet Announces First Quarter Fiscal-Year 2017 Financial Results

[0001193125-16-761705:8k_2_02:5]
BANGKOK, Thailand – November 7, 2016 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical,
electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for the first fiscal quarter ended September 30, 2016.

[0001193125-16-761705:8k_2_02:6]
Tom Mitchell, Chief Executive Officer of Fabrinet, said: “We are off to a strong start in fiscal 2017 with first quarter revenue that exceeded our
expectations and grew more than 50% from a year ago. We are benefiting from positive trends in the optical industry, including increasing activity from new and existing customer programs. We believe we are in a strong position to serve industry
demand with new capacity from the first building at our new campus in Chonburi, Thailand, and our growing new product introduction (NPI) operation in Santa Clara. Our recent acquisition of Exception EMS, U.K. extends our NPI capabilities while
diversifying our customer base. With continued momentum, we are optimistic we can again deliver strong growth in the second quarter, as reflected in our business outlook.”

[0001193125-16-761705:8k_2_02:7]
First Quarter Fiscal-Year 2017 Financial Highlights

[0001193125-16-761705:8k_2_02:8]
GAAP Results

[0001193125-16-761705:8k_2_02:9]
|  | • |  | Revenue for the first quarter of fiscal year 2017, which was a 14-week quarter, was $332.0 million, an increase of 53% compared to revenue of $216.4 million for the comparable period in fiscal year 2016, which was a 13-week quarter. |

[0001193125-16-761705:8k_2_02:10]
|  | • |  | GAAP net income for the first quarter of fiscal year 2017 was $22.8 million, compared to GAAP net income of $1.6 million in the first quarter of fiscal year 2016, which was impacted by a $(10.9) million unrealized foreign exchange loss for the mark-to-market adjustment of forward contracts. |

[0001193125-16-761705:8k_2_02:11]
|  | • |  | GAAP net income per diluted share for the first quarter of fiscal year 2017 was $0.61, compared to GAAP net income per diluted share of $0.04 in the first quarter of fiscal year 2016. |

[0001193125-16-761705:8k_2_02:12]
Non-GAAP Results

[0001193125-16-761705:8k_2_02:13]
|  | • |  | Non-GAAP net income in the first quarter of fiscal 2017 was $29.7 million, an increase of 83% compared to non-GAAP net income of $16.2 million in the same period a year ago. |

[0001193125-16-761705:8k_2_02:14]
|  | • |  | Non-GAAP net income per diluted share in the first quarter of fiscal 2017 was $0.80, an increase from non-GAAP net income per diluted share of $0.45 in the same period a year ago. |

[0001193125-16-761705:8k_2_02:15]
Business Outlook

[0001193125-16-761705:8k_2_02:16]
Based on information available as of
November 7, 2016, Fabrinet is issuing guidance for the second quarter of fiscal-year 2017 ending December 30, 2016, as follows:

[0001193125-16-761705:8k_2_02:17]
|  | • |  | Fabrinet expects revenue for the second quarter, which is a 13-week quarter, to be in the range of $332 million to $336 million. |

[0001193125-16-761705:8k_2_02:18]
|  | • |  | GAAP net income per diluted share is expected to be in the range of $0.65 to $0.67, based on approximately 37.8 million fully diluted shares outstanding. |

[0001193125-16-761705:8k_2_02:19]
|  | • |  | Non-GAAP net income per diluted share is expected to be in the range of $0.78 to $0.80, based on approximately 37.8 million fully diluted shares outstanding. |

[0001193125-16-761705:8k_2_02:20]
Conference Call Information

[0001193125-16-761705:8k_2_02:21]
| What: | Fabrinet First Quarter Fiscal-Year 2017 Financial Results Conference Call |

[0001193125-16-761705:8k_2_02:22]
| When: | Monday, November 7, 2016 |

[0001193125-16-761705:8k_2_02:23]
| Time: | 5:00 p.m. ET |

[0001193125-16-761705:8k_2_02:24]
| Live Call: | (888) 357-3694, domestic |

[0001193125-16-761705:8k_2_02:25]
(253) 237-1137, international

[0001193125-16-761705:8k_2_02:26]
Passcode: 1372730

[0001193125-16-761705:8k_2_02:27]
| Replay: | (855) 859-2056, domestic |

[0001193125-16-761705:8k_2_02:28]
(404) 537-3406, international

[0001193125-16-761705:8k_2_02:29]
Passcode: 1372730

[0001193125-16-761705:8k_2_02:30]
| Webcast: | http://investor.fabrinet.com (live and replay) |

[0001193125-16-761705:8k_2_02:31]
This press release and any other information related to
the call also will be posted on Fabrinet’s website at http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period
of one year.

[0001193125-16-761705:8k_2_02:32]
About Fabrinet

[0001193125-16-761705:8k_2_02:33]
Fabrinet is a leading
provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems,
industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced
packaging, integration, final assembly and test. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of
America, the People’s Republic of China and the United Kingdom. For more information visit: www.fabrinet.com.

[0001193125-16-761705:8k_2_02:34]
Forward-Looking Statements

[0001193125-16-761705:8k_2_02:35]
Use of Non-GAAP Financials

[0001193125-16-761705:8k_2_02:36]
The Company refers to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information
regarding the Company’s ongoing operational performance. Non-GAAP net income excludes share-based compensation expenses, executive separation costs, investigation costs, income related to flooding, expenses related to reduction in workforce,
amortization of debt issuance costs, unrealized gain or loss on foreign currency, business combination expenses and one time cost resulting from a non-recurring warranty charge. We have excluded these items in order to enhance investors’
understanding of our

[0001193125-16-761705:8k_2_02:37]
underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP
financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001193125-16-761705:8k_2_02:38]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our
competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure company
performance for the purposes of determining employee incentive plan compensation.

[0001193125-16-761705:8k_2_02:39]
SOURCE: Fabrinet

[0001193125-16-761705:8k_2_02:40]
Investor Contact:

[0001193125-16-761705:8k_2_02:41]
Garo Toomajanian

[0001193125-16-761705:8k_2_02:42]
ir@fabrinet.com

[0001193125-16-761705:8k_2_02:43]
3

[0001193125-16-761705:8k_2_02:44]
FABRINET

[0001193125-16-761705:8k_2_02:45]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-16-761705:8k_2_02:46]
| (in thousands of U.S. dollars, except share data) |  | September 30,2016 |  |  | June 24,2016 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 105,860 |  |  | $ | 142,804 |  |
| Marketable securities |  |  | 147,702 |  |  |  | 141,709 |  |
| Trade accounts receivable, net |  |  | 212,684 |  |  |  | 196,145 |  |
| Inventory, net |  |  | 205,484 |  |  |  | 181,499 |  |
| Deferred tax assets |  |  | — |  |  |  | 1,358 |  |
| Prepaid expenses |  |  | 3,511 |  |  |  | 3,114 |  |
| Other current assets |  |  | 5,210 |  |  |  | 6,662 |  |
| Total current assets |  |  | 680,451 |  |  |  | 673,291 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Restricted cash in connection with business acquisition |  |  | 3,379 |  |  |  | — |  |
| Property, plant and equipment, net |  |  | 205,845 |  |  |  | 178,410 |  |
| Intangibles, net |  |  | 5,091 |  |  |  | 499 |  |
| Goodwill |  |  | 2,994 |  |  |  | — |  |
| Deferred tax assets |  |  | 2,503 |  |  |  | 1,806 |  |
| Deferred debt issuance costs on revolving loan and other non-current assets |  |  | 1,040 |  |  |  | 1,851 |  |
| Total non-current assets |  |  | 220,852 |  |  |  | 182,566 |  |
| Total Assets |  | $ | 901,303 |  |  | $ | 855,857 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Bank borrowings, net of unamortized debt issuance costs |  | $ | 37,516 |  |  | $ | 24,307 |  |
| Trade accounts payable |  |  | 179,741 |  |  |  | 172,052 |  |
| Fixed assets payable |  |  | 19,694 |  |  |  | 20,628 |  |
| Capital lease liability, current portion |  |  | 122 |  |  |  | — |  |
| Income tax payable |  |  | 3,077 |  |  |  | 2,010 |  |
| Accrued payroll, bonus and related expenses |  |  | 12,417 |  |  |  | 12,300 |  |
| Accrued expenses |  |  | 6,462 |  |  |  | 8,072 |  |
| Other payables |  |  | 10,214 |  |  |  | 16,356 |  |
| Total current liabilities |  |  | 269,243 |  |  |  | 255,725 |  |
| Non-current liabilities |  |  |  |  |
| Long-term loan from bank, non-current portion, net of unamortized debt issuance costs |  |  | 32,759 |  |  |  | 36,100 |  |
| Deferred tax liability |  |  | — |  |  |  | 854 |  |
| Capital lease liability, non-current portion |  |  | 1,556 |  |  |  | — |  |
| Deferred liability in connection with business acquisition |  |  | 3,379 |  |  |  | — |  |
| Severance liabilities |  |  | 7,154 |  |  |  | 6,684 |  |
| Other non-current liabilities |  |  | 2,179 |  |  |  | 2,075 |  |
| Total non-current liabilities |  |  | 47,027 |  |  |  | 45,713 |  |
| Total Liabilities |  |  | 316,270 |  |  |  | 301,438 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of September 30, 2016 and June 24, 2016) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 36,700,468 shares and 36,156,446 shares issued and outstanding as of September 30, 2016 and June 24, 2016, respectively) |  |  | 367 |  |  |  | 362 |  |
| Additional paid-in capital |  |  | 109,772 |  |  |  | 102,325 |  |
| Accumulated other comprehensive income |  |  | 987 |  |  |  | 591 |  |
| Retained earnings |  |  | 473,907 |  |  |  | 451,141 |  |
| Total Shareholders’ Equity |  |  | 585,033 |  |  |  | 554,419 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 901,303 |  |  | $ | 855,857 |  |

[0001193125-16-761705:8k_2_02:47]
FABRINET

[0001193125-16-761705:8k_2_02:48]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND

[0001193125-16-761705:8k_2_02:49]
COMPREHENSIVE INCOME

[0001193125-16-761705:8k_2_02:50]
|  |  | Three Months Ended |  |
| (in thousands of U.S. dollars, except per share amounts) |  | September 30,2016 |  |  | September 25,2015 |  |
| Revenues |  | $ | 332,043 |  |  | $ | 216,433 |  |
| Cost of revenues |  |  | (292,435 | ) |  |  | (190,422 | ) |
| Gross profit |  |  | 39,608 |  |  |  | 26,011 |  |
| Selling, general and administrative expenses |  |  | (15,832 | ) |  |  | (11,900 | ) |
| Other expense related to flooding |  |  | — |  |  |  | (864 | ) |
| Operating income |  |  | 23,776 |  |  |  | 13,247 |  |
| Interest income |  |  | 437 |  |  |  | 442 |  |
| Interest expense |  |  | (1,322 | ) |  |  | (402 | ) |
| Foreign exchange gain (loss), net |  |  | 1,657 |  |  |  | (10,492 | ) |
| Other income |  |  | 143 |  |  |  | 103 |  |
| Income before income taxes |  |  | 24,691 |  |  |  | 2,898 |  |
| Income tax expense |  |  | (1,925 | ) |  |  | (1,295 | ) |
| Net income |  |  | 22,766 |  |  |  | 1,603 |  |
| Other comprehensive income, net of tax: |  |  |  |  |  |  |  |  |
| Change in net unrealized (loss) gains on marketable securities |  |  | (187 | ) |  |  | 87 |  |
| Change in net unrealized loss on derivative instruments |  |  | (158 | ) |  |  | — |  |
| Change in foreign exchange currency translation adjustment |  |  | 741 |  |  |  | — |  |
| Total other comprehensive income, net of tax |  |  | 396 |  |  |  | 87 |  |
| Net comprehensive income |  | $ | 23,162 |  |  | $ | 1,690 |  |
| Earnings per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.63 |  |  | $ | 0.05 |  |
| Diluted |  | $ | 0.61 |  |  | $ | 0.04 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |  |
| Basic |  |  | 36,404 |  |  |  | 35,579 |  |
| Diluted |  |  | 37,330 |  |  |  | 36,315 |  |

[0001193125-16-761705:8k_2_02:51]
5

[0001193125-16-761705:8k_2_02:52]
FABRINET

[0001193125-16-761705:8k_2_02:53]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-16-761705:8k_2_02:54]
|  |  | Three Months Ended |  |
| (in thousands of U.S. dollars) |  | September 30,2016 |  |  | September 25,2015 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income for the period |  | $ | 22,766 |  |  | $ | 1,603 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 5,113 |  |  |  | 4,063 |  |
| Gain on disposal of property, plant and equipment |  |  | (40 | ) |  |  | (26 | ) |
| Loss from sales and maturities of available-for-sale securities |  |  | 100 |  |  |  | 92 |  |
| Amortization of investment premium |  |  | 166 |  |  |  | 298 |  |
| Amortization of deferred debt issuance costs |  |  | 908 |  |  |  | 171 |  |
| Allowance for doubtful accounts (reversal of) |  |  | 3 |  |  |  | (4 | ) |
| Unrealized (gain) loss on exchange rate and fair value of derivative instruments |  |  | (1,913 | ) |  |  | 10,855 |  |
| Share-based compensation |  |  | 5,611 |  |  |  | 2,673 |  |
| Deferred income tax |  |  | 311 |  |  |  | 157 |  |
| Other non-cash expenses |  |  | 453 |  |  |  | 386 |  |
| (Reversal of) inventory obsolescence |  |  | (62 | ) |  |  | 150 |  |
| Loss from written-off inventory due to flood loss |  |  | — |  |  |  | 233 |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | (11,876 | ) |  |  | (4,948 | ) |
| Inventory |  |  | (21,290 | ) |  |  | (13,150 | ) |
| Other current assets and non-current assets |  |  | 3,285 |  |  |  | (668 | ) |
| Trade accounts payable |  |  | 3,103 |  |  |  | 3,053 |  |
| Income tax payable |  |  | 1,035 |  |  |  | 707 |  |
| Other current liabilities and non-current liabilities |  |  | (8,675 | ) |  |  | (1,106 | ) |
| Net cash (used in) provided by operating activities |  |  | (1,002 | ) |  |  | 4,539 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of marketable securities |  |  | (32,737 | ) |  |  | (38,773 | ) |
| Proceeds from sales of marketable securities |  |  | 13,061 |  |  |  | 16,687 |  |
| Proceeds from maturities of marketable securities |  |  | 13,230 |  |  |  | 12,528 |  |
| Payments in connection with business acquisition, net of cash acquired |  |  | (9,664 | ) |  |  | — |  |
| Restricted cash in connection with business acquisition |  |  | (3,379 | ) |  |  | — |  |
| Purchase of property, plant and equipment |  |  | (27,090 | ) |  |  | (8,452 | ) |
| Purchase of intangibles |  |  | (178 | ) |  |  | (68 | ) |
| Deposits for land purchase |  |  | — |  |  |  | (2,352 | ) |
| Proceeds from disposal of property, plant and equipment |  |  | 107 |  |  |  | 28 |  |
| Net cash used in investing activities |  |  | (46,650 | ) |  |  | (20,402 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Payment of debt issuance costs |  |  | — |  |  |  | (353 | ) |
| Proceeds from revolving loans |  |  | 13,500 |  |  |  | — |  |
| Repayment of long-term loans from bank |  |  | (4,900 | ) |  |  | (1,500 | ) |
| Proceeds from issuance of ordinary shares under employee share option plans |  |  | 2,708 |  |  |  | 1,547 |  |
| Withholding tax related to net share settlement of restricted share units |  |  | (867 | ) |  |  | (878 | ) |
| Net cash provided by (used in) financing activities |  |  | 10,441 |  |  |  | (1,184 | ) |
| Net decrease in cash and cash equivalents |  |  | (37,211 | ) |  |  | (17,047 | ) |
| Movement in cash and cash equivalents |  |  |  |  |  |  |  |  |
| Cash and cash equivalents at beginning of period |  |  | 142,804 |  |  |  | 112,978 |  |
| Decrease in cash and cash equivalents |  |  | (37,211 | ) |  |  | (17,047 | ) |
| Effect of exchange rate on cash and cash equivalents |  |  | 267 |  |  |  | (466 | ) |
| Cash and cash equivalents at end of period |  | $ | 105,860 |  |  | $ | 95,465 |  |
| Non-cash investing and financing activities |  |  |  |  |  |  |  |  |
| Construction and equipment-related payables |  | $ | 19,694 |  |  | $ | 5,123 |  |

[0001193125-16-761705:8k_2_02:55]
6

[0001193125-16-761705:8k_2_02:56]
FABRINET

[0001193125-16-761705:8k_2_02:57]
Reconciliation of GAAP measures to non-GAAP measures

[0001193125-16-761705:8k_2_02:58]
| (in thousands of U.S. dollars, except per share data) |  | Three Months Ended |  |
|  |  | September 30, 2016 |  |  | September 25, 2015 |  |
|  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |
| GAAP measures |  |  | 22,766 |  |  |  | 0.61 |  |  |  | 1,603 |  |  |  | 0.04 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,014 |  |  |  | 0.03 |  |  |  | 537 |  |  |  | 0.01 |  |
| Total related to gross profit |  |  | 1,014 |  |  |  | 0.03 |  |  |  | 537 |  |  |  | 0.01 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 4,598 |  |  |  | 0.12 |  |  |  | 2,136 |  |  |  | 0.06 |  |
| Executive separation cost |  |  | 577 |  |  |  | 0.02 |  |  |  | — |  |  |  | — |  |
| Business combination expenses |  |  | 1,411 |  |  |  | 0.04 |  |  |  | — |  |  |  | — |  |
| Total related to selling, general and administrative expenses |  |  | 6,586 |  |  |  | 0.18 |  |  |  | 2,136 |  |  |  | 0.06 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Expenses related to flooding |  |  | — |  |  |  | — |  |  |  | 864 |  |  |  | 0.02 |  |
| Amortization of debt issuance costs |  |  | 1,063 |  |  |  | 0.03 |  |  |  | 171 |  |  |  | 0.01 |  |
| (Gain)/loss on foreign currency |  |  | (1,713 | ) |  |  | (0.05 | ) |  |  | 10,897 |  |  |  | 0.30 |  |
| Total related to other incomes and other expenses |  |  | (650 | ) |  |  | (0.02 | ) |  |  | 11,932 |  |  |  | 0.33 |  |
| Total related to net income & EPS |  |  | 6,950 |  |  |  | 0.19 |  |  |  | 14,605 |  |  |  | 0.40 |  |
| Non-GAAP measures |  |  | 29,716 |  |  |  | 0.80 |  |  |  | 16,208 |  |  |  | 0.45 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 37,330 |  |  |  |  |  |  |  | 36,315 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 37,330 |  |  |  |  |  |  |  | 36,315 |  |

[0001193125-16-761705:8k_2_02:59]
Fabrinet Guidance for Quarter Ending December 30, 2016

[0001193125-16-761705:8k_2_02:60]
Items reconciling GAAP EPS to non-GAAP EPS:

[0001193125-16-761705:8k_2_02:61]
|  |  | DilutedEPS |  |
| GAAP net income per diluted share: |  | $ | 0.65 to $0.67 |  |
| Related to cost of revenues: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.03 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.09 |  |
| Related to other incomes and other expenses: |  |  |  |  |
| Amortization of debt issuance costs |  |  | 0.01 |  |
| Total related to net income & EPS |  |  | 0.13 |  |
| Non-GAAP net income per diluted share |  | $ | 0.78 to $0.80 |  |

[0001193125-16-761705:8k_2_02:62]
8
