# FN note change history — 0001193125-16-574999 → 0001193125-16-764312


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-11-09):
[0001193125-16-764312:note_history:1]
As of September 30, 2016 and June 24, 2016, there were outstanding
 bank guarantees given by banks on behalf of Fabrinet Thailand for
 electricity usage and other normal business amounting to $0.8
 million and $0.8 million, respectively.
  (was, 2016-05-03, similarity 0.9677):
[0001193125-16-574999:note_history:1]
As of March 25, 2016 and June 26, 2015, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $0.8 million and $0.8 million, respectively.

- changed (2016-11-09):
[0001193125-16-764312:note_history:2]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, New Jersey and the United Kingdom under operating
 lease arrangements that expire in various calendar years through
 2023. Rental expense under these operating leases amounted to $0.4
 million and $0.3 million for the three months ended September 30,
 2016 and September 25, 2015, respectively.
  (was, 2016-05-03, similarity 0.8625):
[0001193125-16-574999:note_history:2]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, and New Jersey under operating lease arrangements
 that expire in various calendar years through 2020. Rental expense
 under these operating leases amounted to $0.9 million and $0.8
 million for the nine months ended March 25, 2016 and
 March 27, 2015, respectively.

- changed (2016-11-09):
[0001193125-16-764312:note_history:3]
As of September 30, 2016, the future minimum lease payments due
 under non-cancelable operating leases during each fiscal year were
 as follows:
  (was, 2016-05-03, similarity 0.9225):
[0001193125-16-574999:note_history:3]
As of March 25, 2016, the future minimum lease payments due
 under non-cancelable leases during each fiscal year were as
 follows:

- changed (2016-11-09):
[0001193125-16-764312:note_history:4]
| (amount in thousands) |  |  |  |
| 2017 (remaining nine months) |  | $ | 1,338 |  |
| 2018 |  |  | 1,685 |  |
| 2019 |  |  | 1,131 |  |
| 2020 |  |  | 922 |  |
| 2021 |  |  | 525 |  |
| Thereafter |  |  | 897 |  |
| Total minimum operating lease payments |  | $ | 6,498 |  |
  (was, 2016-05-03, similarity 0.9415):
[0001193125-16-574999:note_history:4]
| (amount in thousands) |  |  |  |
| 2016 |  | $ | 289 |  |
| 2017 |  |  | 1,039 |  |
| 2018 |  |  | 1,040 |  |
| 2019 |  |  | 581 |  |
| 2020 |  |  | 372 |  |
| Thereafter |  |  | 18 |  |
| Total minimum operating lease payments |  | $ | 3,339 |  |

- added (2016-11-09):
[0001193125-16-764312:note_history:5]
Capital lease commitments

- added (2016-11-09):
[0001193125-16-764312:note_history:6]
In connection with the acquisition of Exception EMS, the Company
 assumed the capital lease commitments of certain machine and
 equipment, with various expiration dates until September 2020. The
 equipment can be purchased at the determined price upon
 expiration.

- added (2016-11-09):
[0001193125-16-764312:note_history:7]
As of September 30, 2016, the future minimum lease payments due
 under non-cancelable capital leases during each fiscal year were as
 follows:

- added (2016-11-09):
[0001193125-16-764312:note_history:8]
| (amount in thousands) |  |  |  |
| 2017 (remaining nine months) |  | $ | 301 |  |
| 2018 |  |  | 416 |  |
| 2019 |  |  | 429 |  |
| 2020 |  |  | 376 |  |
| 2021 |  |  | 156 |  |
| Total minimum capital lease payments |  | $ | 1,678 |  |

- changed (2016-11-09):
[0001193125-16-764312:note_history:9]
As of September 30, 2016, the Company had an outstanding commitment
 to third parties of approximately $30.1 million, mainly related to
 the construction of a new manufacturing building at the
 Company’s Chonburi campus.
  (was, 2016-05-03, similarity 0.966):
[0001193125-16-574999:note_history:9]
As of March 25, 2016, the Company had an outstanding
 commitment to third parties of approximately $35.4 million, mainly
 related to the construction of a new manufacturing building at the
 Company’s Chonburi campus.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-11-09):
[0001193125-16-764312:note_history:10]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of September 30, 2016 and for the three
 months ended September 30, 2016 and September 25, 2015 includes
 normal recurring adjustments, necessary for a fair presentation of
 the financial statements set forth herein, in accordance with
 accounting principles generally accepted in the United States of
 America (“U.S. GAAP”) for interim financial information
 and the rules and regulations of the Securities and Exchange
 Commission (“SEC”). Accordingly, such information does
 not include all of the information and footnotes required by U.S.
 GAAP for annual financial statements. For further information,
 please refer to the consolidated financial statements and footnotes
 thereto included in Fabrinet’s Annual Report on Form 10-K for
 the year ended June 24, 2016.
  (was, 2016-05-03, similarity 0.9348):
[0001193125-16-574999:note_history:10]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of March 25, 2016 and for the three
 and nine months ended March 25, 2016 and March 27, 2015
 includes only normal recurring adjustments, necessary for a fair
 statement of the financial statements set forth herein, in
 accordance with accounting principles generally accepted in the
 United States of America (“U.S. GAAP”) for interim
 financial information and rules and regulations of the Securities
 and Exchange Commission (“SEC”). Accordingly, such
 information does not include all of the information and footnotes
 required by U.S. GAAP for annual financial statements. For further
 information, please refer to the consolidated financial statements
 and footnotes thereto included in Fabrinet’s Annual Report on
 Form 10-K for the year ended June 26, 2015.

- changed (2016-11-09):
[0001193125-16-764312:note_history:11]
The balance sheet as of June 24, 2016 has been derived from the
 audited financial statements at that date but does not include all
 of the information and footnotes required by U.S. GAAP for complete
 financial statements. The results for the three months ended
 September 30, 2016 may not be indicative of results for the year
 ending June 30, 2017 or any future periods.
  (was, 2016-05-03, similarity 0.6897):
[0001193125-16-574999:note_history:11]
The balance sheet as of June 26, 2015 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three and nine
 months ended March 25, 2016 and March 27, 2015 may not be
 indicative of results for the year ending June 24, 2016 or any
 future periods.

- added (2016-11-09):
[0001193125-16-764312:note_history:12]
Where necessary, comparative figures have been reclassified to
 conform to the current period accounting policies and presentation
 adopted.

- added (2016-11-09):
[0001193125-16-764312:note_history:13]
On September 14, 2016, the Company acquired 100% of the shares
 of Global CEM Solutions, Ltd. and all of its subsidiaries, a
 privately-held group located in Wiltshire, United
 Kingdom (“Exception EMS”). The unaudited condensed
 consolidated financial statements of the Company include the
 financial position, results of operations and the cash flows of
 Exception EMS commencing as of the acquisition date. See Note 8 -
 Business acquisitions for further details on the accounting for
 this transaction.

- changed (2016-11-09):
[0001193125-16-764312:note_history:14]
The preparation of the Company’s condensed consolidated
 financial statements in conformity with U.S. GAAP requires
 management to make estimates and assumptions that affect the
 reported amounts of assets and liabilities and disclosure of
 contingent liabilities at the date of the financial statements, and
 the reported amount of total revenues and expenses during the year.
 The Company bases estimates on historical experience and various
 assumptions about the future that are believed to be reasonable
 based on available information. The Company’s reported
 financial position or results of operations may be materially
 different under different conditions or when using different
 estimates and assumptions, particularly with respect to significant
 accounting policies, which are discussed below. Significant
 assumptions are used in accounting for share-based compensation,
 allowance for doubtful accounts, income taxes, inventory
 obsolescence and valuation of intangible assets related to business
 acquisition, among others. Due to the inherent uncertainty involved
 in making estimates, actual results reported in future periods may
 be different from these estimates. In the event that estimates or
 assumptions prove to differ from actual results, adjustments will
 be made in subsequent periods to reflect more current
 information.
  (was, 2016-05-03, similarity 0.7295):
[0001193125-16-574999:note_history:14]
The preparation of the Company’s condensed consolidated
 financial statements in conformity with U.S. GAAP requires
 management to make estimates and assumptions that affect the
 reported amounts of assets and liabilities and disclosure of
 contingent liabilities at the date of the financial statements, and
 the reported amount of total revenues and expenses during the year.
 The Company bases estimates on historical experience and various
 assumptions about the future that are believed to be reasonable
 based on available information. The Company’s reported
 financial position or results of operations may be materially
 different under different conditions or when using different
 estimates and assumptions, particularly with respect to significant
 accounting policies, which are discussed below. Significant
 assumptions are used in accounting for share-based compensation,
 allowance for doubtful accounts, income taxes, and inventory
 obsolescence, among others. Due to the inherent uncertainty
 involved in making estimates, actual results reported in future
 periods may be different from these estimates. In the event that
 estimates or assumptions prove to differ from actual results,
 adjustments will be made in subsequent periods to reflect more
 current information.

- changed (2016-11-09):
[0001193125-16-764312:note_history:15]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended September 30,
 2016 and September 25, 2015 each consisted of 14 weeks and 13
 weeks, respectively. Fiscal year 2017 will be comprised of 53 weeks
 and will end on June 30, 2017.
  (was, 2016-05-03, similarity 0.7741):
[0001193125-16-574999:note_history:15]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended
 March 25, 2016 and March 27, 2015 each consisted of 13
 weeks. The nine months ended March 25, 2016 and March 27,
 2015 each consisted of 39 weeks. Fiscal year 2016 will be comprised
 of 52 weeks and will end on June 24, 2016.

- changed (2016-11-09):
[0001193125-16-764312:note_history:16]
The derivatives assets and liabilities are recognized on the
 consolidated balance sheets as other current assets or accrued
 expenses measured at fair value.
  (was, 2016-05-03, similarity 0.9703):
[0001193125-16-574999:note_history:16]
The derivatives assets and liabilities are recognized on the
 consolidated balance sheets as other current assets or accrued
 expenses at fair value.

- changed (2016-11-09):
[0001193125-16-764312:note_history:17]
Derivatives designated and qualifying as hedges of the exposure to
 variability in expected future cash flows, or other types of
 forecasted transactions, are considered cash flow hedges which
 include forward currency contracts. In a cash flow hedging
 relationship, the effective portion of the change in the fair value
 of the hedging derivative is initially recorded in accumulated
 other comprehensive income (loss) (“AOCI”), while any
 ineffective portion is recognized directly in earnings, as a
 component of other income (expense). The portion of gain or loss on
 the derivative instrument remains in AOCI until the forecasted
 transaction is recognized in earnings.
  (was, 2016-05-03, similarity 0.9589):
[0001193125-16-574999:note_history:17]
Derivatives designated and qualifying as hedges of the exposure to
 variability in expected future cash flows, or other types of
 forecasted transactions, are considered cash flow hedges which
 include forward currency contracts. In a cash flow hedging
 relationship, the effective portion of the change in the fair value
 of the hedging derivative is initially recorded in accumulated
 other comprehensive income (loss), while any ineffective portion is
 recognized directly in earnings, as a component of other income
 (expense). The portion of gain or loss on the derivative instrument
 remains in accumulated other comprehensive (loss) income until the
 forecasted transaction is recognized in earnings.

- changed (2016-11-09):
[0001193125-16-764312:note_history:18]
The Company also enters into derivative contracts that are intended
 to economically hedge certain of the Company’s risks. The
 changes in the fair value of the derivatives are recorded directly
 in earnings as a component of other income (expense), net. In
 accordance with the fair value measurement guidance, the
 Company’s accounting policy is to measure the credit risk of
 its derivative financial instruments that are subject to master
 netting agreements on a net basis by counterparty portfolio. The
 Company executes derivative instruments with financial institutions
 that are credit-worthy, defined as institutions that hold an
 investment grade credit rating.
  (was, 2016-05-03, similarity 0.9955):
[0001193125-16-574999:note_history:18]
The Company also enters into derivative contracts that are intended
 to economically hedge certain of the Company’s risks. The
 changes in the fair value of the derivatives are recorded directly
 in earnings as a component of other income (expense), net. In
 accordance with the fair value measurement guidance, the
 Company’s accounting policy is to measure the credit risk of
 our derivative financial instruments that are subject to master
 netting agreements on a net basis by counterparty portfolio. The
 Company executes derivative instruments with financial institutions
 that are credit-worthy, defined as institutions that hold an
 investment grade credit rating.

- added (2016-11-09):
[0001193125-16-764312:note_history:19]
Business acquisition

- added (2016-11-09):
[0001193125-16-764312:note_history:20]
For the acquisition of Exception EMS, the Company allocated the
 fair value of purchase consideration to the assets acquired and
 liability assumed based on their fair values at the acquisition
 date. The total consideration and the allocation of consideration
 to the individual net assets is preliminary, as there are remaining
 uncertainties to be resolved, including the settlement of the final
 net working capital adjustment and the finalization of the
 estimated fair value attributable to the acquired intangible
 assets.

- added (2016-11-09):
[0001193125-16-764312:note_history:21]
The acquired intangible assets include customer relationships and
 backlog and are recorded as intangibles in the unaudited condensed
 consolidated balance sheets. The fair value of the acquired
 intangible assets was determined based on the multi-period excess
 earnings method. The Company reviews intangibles for impairment
 annually or whenever changes or circumstances indicate the carrying
 amount may not be recoverable.

- added (2016-11-09):
[0001193125-16-764312:note_history:22]
In connection with the business acquisition, $3.4 million of cash
 for deferred consideration was placed into an escrow account which
 is under the Company controls. However, the Company has
 contractually agreed to remit this deferred consideration to the
 sellers of Exception EMS, subject to the resolution of claims that
 the Company may make against the funds with respect to
 indemnification and other claims within 24 months from the closing
 date of the transaction. The cash is presented as restricted cash
 in the unaudited condensed consolidated balance sheets and the
 related liability is presented within non-current liabilities for
 the deferred consideration.

- added (2016-11-09):
[0001193125-16-764312:note_history:23]
Goodwill

- added (2016-11-09):
[0001193125-16-764312:note_history:24]
Goodwill arising from the acquisition is primarily attributable to
 the ability to expand future products and services and the
 assembled workforce. Goodwill is reviewed annually for impairment
 or more frequently whenever changes or circumstances indicate the
 carrying amount of goodwill may not be recoverable.

- added (2016-11-09):
[0001193125-16-764312:note_history:25]
Capital lease

- added (2016-11-09):
[0001193125-16-764312:note_history:26]
Certain machine and equipment held under capital leases are
 classified as property, plant and equipment and amortized using the
 straight-line method over the terms of the lease contracts. The
 related obligations from the capital lease are recorded as
 liabilities in the unaudited condensed consolidated balance
 sheets.

- added (2016-11-09):
[0001193125-16-764312:note_history:27]
In October 2016, the Financial Accounting Standards Board
 (“FASB”) issued Accounting Standards Update
 (“ASU”) 2016-16, “Income Taxes (Topic 740)
 – Intra-Entity Transfers of Assets Other Than
 Inventory,” which eliminates the exception for an
 intra-entity transfer of an asset other than inventory that
 prohibits the recognition of current and deferred income taxes
 until the asset has been sold to an outside party. The entity
 should recognize income tax consequences of an intra-entity
 transfer of assets other than inventory when the transfer occurs.
 For public entities, this update is effective for annual reporting
 periods beginning after December 15, 2017, including interim
 reporting periods within those annual reporting periods. Early
 adoption is permitted for all entities as of the beginning of an
 annual reporting period for which financial statements have not
 been issued or made available for issuance. The Company is
 currently evaluating the impact of the adoption of this update on
 its consolidated financial statements.

- added (2016-11-09):
[0001193125-16-764312:note_history:28]
In August 2016, the FASB issued ASU 2016-15, “Classification
 of Certain Cash Receipts and Cash Payments (a consensus of the
 Emerging Issues Task Force).” The amendments in this ASU
 provide guidance on the presentation of certain cash receipts and
 cash payments in the statement of cash flows in order to reduce
 diversity in existing practice. The amendments in ASU 2016-15 are
 effective for public business entities for fiscal years beginning
 after December 15, 2017, and interim periods within those fiscal
 years. Early adoption is permitted, including adoption in an
 interim period. The Company is currently evaluating the impact of
 the adoption of this update on its consolidated financial
 statements.

- added (2016-11-09):
[0001193125-16-764312:note_history:29]
In June 2016, the FASB issued ASU 2016-13, “Financial
 Instruments – Credit Losses (Topic 326): Measurement of
 Credit Losses on Financial Instruments.” The amendments
 in this ASU replace the incurred loss impairment methodology in
 current GAAP with a methodology that reflects expected credit
 losses and requires consideration of a broader range of reasonable
 and supportable information to inform credit loss estimates. The
 amendments are effective for fiscal years beginning after
 December 15, 2019, including interim periods within those
 fiscal years. Early adoption is permitted for fiscal years
 beginning after December 15, 2018, including interim periods
 within those fiscal years. The Company is currently evaluating the
 impact of the adoption of this update on its consolidated financial
 statements.

- changed (2016-11-09):
[0001193125-16-764312:note_history:30]
In March 2016, the FASB issued ASU
 2016-09, “Compensation – Stock Compensation (Topic
 718): Improvements to Employee Share-Based Payment
 Accounting.” This ASU simplifies several aspects of the
 accounting for share-based payment award transactions, including,
 the income tax consequences, classification of awards as either
 equity or liabilities and classification on the statement of cash
 flows. The amendments in this update are effective for annual
 periods beginning after December 15, 2016, and interim periods
 within those annual periods, for public companies. Early
 adoption is permitted for any entity in any interim or annual
 period. The Company is currently evaluating the impact of the
 adoption of this update on its consolidated financial
 statements.
  (was, 2016-05-03, similarity 0.9312):
[0001193125-16-574999:note_history:30]
In March 2016, the Financial Accounting Standards Board
 (“FASB”) issued Accounting Standards Update
 (“ASU”) 2016-09, “Compensation - Stock
 Compensation (Topic 718): Improvements to Employee Share-Based
 Payment Accounting”. This ASU simplifies several aspects of
 the accounting for share-based payment award transactions,
 including, the income tax consequences, classification of awards as
 either equity or liabilities and classification on the statement of
 cash flows. The amendments in this update are effective for annual
 periods beginning after December 15, 2016, and interim periods
 within those annual periods, for public companies. Early adoption
 is permitted for any entity in any interim or annual period. The
 Company is currently evaluating the impact of adoption of this
 update on its consolidated financial statements.

- changed (2016-11-09):
[0001193125-16-764312:note_history:31]
In March 2016, the FASB issued ASU 2016-05, “Derivatives and
 Hedging (Topic 815),” to clarify that a change in the
 counterparty to a derivative instrument that has been designated as
 a hedging instrument under Topic 815, does not, in and of itself,
 require designation of the hedging relationship, provided that all
 other hedge accounting criteria continue to be met. This guidance
 is effective for public entities for financial statements issued
 for fiscal years beginning after December 15, 2016 and interim
 periods within those fiscal years. Early adoption is permitted. The
 Company is currently evaluating the impact of the adoption of this
 update on its consolidated financial statements.
  (was, 2016-05-03, similarity 0.9955):
[0001193125-16-574999:note_history:31]
In March 2016, the FASB issued ASU 2016-05, “Derivatives and
 Hedging (Topic 815)”, to clarify that a change in the
 counterparty to a derivative instrument that has been designated as
 a hedging instrument under Topic 815, does not, in and of itself,
 require designation of the hedging relationship, provided that all
 other hedge accounting criteria continue to be met. This guidance
 is effective for public entities for financial statements issued
 for fiscal years beginning after December 15, 2016 and interim
 periods within those fiscal years. Early adoption is permitted. The
 Company is currently evaluating the impact of adoption of this
 update on its consolidated financial statements.

- changed (2016-11-09):
[0001193125-16-764312:note_history:32]
In February 2016, the FASB issued ASU 2016-02, “Lease (Topic
 842).” The core principle of Topic 842 is that a lessee
 should recognize the lease assets and liabilities that arise from
 leases in the statement of financial position. For public business
 entities, this update is effective for fiscal years beginning after
 December 15, 2018, including interim periods within those fiscal
 years. Early application is permitted. The Company is currently
 evaluating the impact of the adoption of this update on its
 consolidated financial statements.
  (was, 2016-05-03, similarity 0.9942):
[0001193125-16-574999:note_history:32]
In February 2016, the FASB issued ASU 2016-02, “Lease (Topic
 842)”. The core principle of Topic 842 is that a lessee
 should recognize the lease assets and liabilities that arise from
 leases in the statement of financial position. For public business
 entities, this update is effective for fiscal years beginning after
 December 15, 2018, including interim periods within those
 fiscal years. Early application is permitted. The Company is
 currently evaluating the impact of adoption of this update on its
 consolidated financial statements.

- changed (2016-11-09):
[0001193125-16-764312:note_history:33]
In January 2016, the FASB issued ASU 2016-01, “Financial
 Instruments – Overall (Subtopic 825-10): Recognition and
 Measurement of Financial Assets and Financial Liabilities.”
 This new guidance requires certain equity investments to be
 measured at fair value, use of the exit price notion and separate
 presentation of financial assets and financial liabilities by
 measurement category and form of financial asset on the balance
 sheet or the accompanying notes to the financial statements. The
 ASU on recognition and measurement will take effect for public
 companies for fiscal years beginning after December 15, 2017,
 including interim periods within those fiscal years. The
 Company is currently evaluating the impact of the adoption of this
 update on its consolidated financial statements.
  (was, 2016-05-03, similarity 0.9948):
[0001193125-16-574999:note_history:33]
In January 2016, the FASB issued ASU 2016-01, “Financial
 Instruments - Overall (Subtopic 825-10): Recognition and
 Measurement of Financial Assets and Financial Liabilities”.
 This new guidance requires certain equity investments to be
 measured at fair value, use of the exit price notion and separate
 presentation of financial assets and financial liabilities by
 measurement category and form of financial asset on the balance
 sheet or the accompanying notes to the financial statements. The
 ASU on recognition and measurement will take effect for public
 companies for fiscal years beginning after December 15, 2017,
 including interim periods within those fiscal years. The
 Company is currently evaluating the impact of adoption of this
 update on its consolidated financial statements.

- changed (2016-11-09):
[0001193125-16-764312:note_history:34]
In July 2015, the FASB issued ASU 2015-11, “Inventory (Topic
 330): Simplifying the Measurement of Inventory.” The update
 provides the guidance that an entity, that measured inventory by
 using first-in, first-out or average cost, should measure inventory
 at the lower of cost and net realizable value. Subsequent
 measurement is unchanged for inventory measured using last-in,
 first-out or the retail inventory method. The update is effective
 for fiscal years beginning after December 15, 2016, including
 interim periods within these fiscal years. This update should be
 applied prospectively with earlier application permitted as of the
 beginning of an interim or annual reporting date. The Company is
 currently evaluating the impact of the adoption of this update on
 its consolidated financial statements.
  (was, 2016-05-03, similarity 0.9962):
[0001193125-16-574999:note_history:34]
In July 2015, the FASB issued ASU 2015-11, “Inventory (Topic
 330): Simplifying the Measurement of Inventory”. The update
 provides the guidance that an entity, that measured inventory by
 using first-in, first-out or average cost, should measure inventory
 at the lower of cost and net realizable value. Subsequent
 measurement is unchanged for inventory measured using last-in,
 first-out or the retail inventory method. The update is effective
 for fiscal years beginning after December 15, 2016, including
 interim periods within these fiscal years. This update should be
 applied prospectively with earlier application permitted as of the
 beginning of an interim or annual reporting date. The Company is
 currently evaluating the impact of adoption of this update on its
 consolidated financial statements.

- changed (2016-11-09):
[0001193125-16-764312:note_history:35]
In August 2014, the FASB issued ASU 2014-15, “Presentation of
 Financial Statements – Going Concern (Subtopic 205-40):
 Disclosure of Uncertainties about an Entity’s Ability to
 Continue as a Going Concern.” The amendments require
 management to evaluate, for each annual and interim reporting
 period, an entity’s ability to continue as a going concern
 when relevant conditions and events, considered in the aggregate,
 indicate that it is probable that the entity will be unable to meet
 its obligations that become due within one year after the date that
 the financial statements are issued (or available to be issued).
 This ASU is effective for annual periods and interim reporting
 periods beginning after December 15, 2016. The Company does not
 expect that the adoption of this update will have an effect on its
 consolidated financial statements.
  (was, 2016-05-03, similarity 0.9964):
[0001193125-16-574999:note_history:35]
In August 2014, the FASB issued ASU No. 2014-15,
 “Presentation of Financial Statements – Going Concern
 (Subtopic 205-40): Disclosure of Uncertainties about an
 Entity’s Ability to Continue as a Going Concern”. The
 amendments require management to evaluate, for each annual and
 interim reporting period, an entity’s ability to continue as
 a going concern when relevant conditions and events, considered in
 the aggregate, indicate that it is probable that the entity will be
 unable to meet its obligations that become due within one year
 after the date that the financial statements are issued (or
 available to be issued). This ASU is effective for annual periods
 and interim reporting periods beginning after December 15,
 2016. The Company does not expect that the adoption of this update
 will have an effect on its consolidated financial statements.

- added (2016-11-09):
[0001193125-16-764312:note_history:36]
In May 2014, the FASB issued ASU 2014-09, “Revenue from
 Contracts with Customers (Topic 606), issued as a new Topic,
 Accounting Standards Codification.” The core principle of
 this amendment is that an entity should recognize revenue to depict
 the transfer of promised goods or services to customers in an
 amount that reflects the consideration to which the entity expects
 to be entitled in exchange for those goods or services. This update
 is effective for public companies, as amended by ASU 2015-14, for
 annual reporting periods beginning after December 15, 2017,
 including interim periods within that reporting period. Earlier
 application of this guidance is permitted, but not before the
 original date of December 15, 2016, which can be adopted either
 retrospectively to each prior reporting period presented or as a
 cumulative-effect adjustment as of the date of adoption.
 Subsequently, in March 2016 and April 2016, the FASB issued ASU
 2016-08 and ASU 2016-10, to clarify the implementation guidance on
 principle versus agent considerations and address the potential
 diversity in practice at initial application and cost; and the
 complexity of applying Topic 606, both at transition and on an
 ongoing basis related to identification of performance obligations
 and licensing arrangements; and ASU 2016-12, in May 2016, to
 improve in certain aspects of Topic 606, with the same effective
 date as ASU 2015-14. The Company will adopt this standard during
 its fiscal year ending June 28, 2018. In the current period, the
 Company is assessing the contracts with its customers to identify
 the impact to its consolidated financial statements. The process is
 still ongoing and the Company expects to make significant progress
 in the coming quarters.

- added (2016-11-09):
[0001193125-16-764312:note_history:37]
New Accounting Pronouncements – adopted by the
 Company

- added (2016-11-09):
[0001193125-16-764312:note_history:38]
In November 2015, the FASB issued ASU 2015-17, “Balance Sheet
 Classification of Deferred Taxes,” which will require
 entities to present deferred tax assets (“DTAs”) and
 deferred tax liabilities (“DTLs”) as non-current in a
 classified balance sheet. The ASU simplifies the current guidance,
 which requires entities to separately present DTAs and DTLs as
 current and non-current in a classified balance sheet. The Company
 adopted of this update early. Accordingly, as of September 30,
 2016, DTAs of $1.2 million were classified to non-current in
 the unaudited condensed consolidated balance sheets. The Company
 adopted this update on a prospective basis and did not change the
 presentation of the comparative period.

- added (2016-11-09):
[0001193125-16-764312:note_history:39]
In September 2015, the FASB issued ASU 2015-16, “Business
 Combinations (Topic 805): Simplifying the Accounting for
 Measurement-Period Adjustments” which require an acquirer to
 recognize adjustments to provisional amounts that are identified
 during the measurement period in the reporting period in which the
 adjustment amounts are determined. The Company has adopted of this
 update and applied it on a prospective basis.

- added (2016-11-09):
[0001193125-16-764312:note_history:40]
In April 2015, the FASB issued ASU 2015-03, “Interest –
 Imputation of Interest (Subtopic 835-30): Simplifying the
 Presentation of Debt Issuance Costs.” The update requires
 debt issuance costs related to a recognized debt liability be
 presented in the balance sheet as a direct deduction from the
 carrying amount of the related debt liability instead of being
 presented as an asset. Debt disclosures will include the face
 amount of the debt liability and the effective interest rate. The
 update requires retrospective application and represents a change
 in accounting principle. Additionally, in August 2015, the FASB
 issued ASU 2015-15, “Interest – Imputation of Interest
 (Subtopic 835-30): Presentation and Subsequent Measurement of Debt
 Issuance Costs Associated with Line-of-Credit Arrangements”
 to amend ASU 2015-03. The Company has adopted this amendment
 retrospectively. As of September 30, 2016 and June 24, 2016, debt
 issuance costs of $0.5 million and $0.6 million, respectively,
 related to a recognized debt liability are presented in the balance
 sheet as a direct reduction of the carrying amount of the related
 debts.

- added (2016-11-09):
[0001193125-16-764312:note_history:41]
In February 2015, the FASB issued ASU 2015-02, “Consolidation
 (Topic 810): Amendments to the Consolidation Analysis.” ASU
 No. 2015-02 amended the process that a reporting entity must
 perform to determine whether it should consolidate certain types of
 legal entities. The Company has adopted this update with no impact
 to the unaudited condensed consolidated financial statements.

- added (2016-11-09):
[0001193125-16-764312:note_history:42]
In January 2015, the FASB issued ASU 2015-01, “Income
 Statement – Extraordinary and Unusual Items (Subtopic
 225-20): Simplifying Income Statement Presentation by Eliminating
 the Concept of Extraordinary Items.” The objective of this
 amendment is to reduce the complexity in accounting standards by
 eliminating the concept of extraordinary items from U.S. GAAP. To
 meet for extraordinary classification the underlying event or
 transaction should (a) possess a high degree of abnormality and be
 of a type clearly unrelated to, or only incidentally related to,
 the ordinary and typical activities of the entity and (b) not
 reasonably be expected to recur in the foreseeable future. The
 Company has adopted this update with no impact to the unaudited
 condensed consolidated financial statements.

- removed (2016-11-09):
[0001193125-16-574999:note_history:43]
In March 2016, the FASB issued ASU 2016-08, “Revenue from
 Contracts with Customers (Topic 606): Principal versus Agent
 Considerations (Reporting Revenue Gross versus Net)” to
 clarify the implementation guidance on principal versus agent
 considerations. The effective date and transition requirements for
 this amendments are the same as ASU 2014-09, which defers by one
 year. The Company is currently evaluating the impact of adoption of
 this update on its consolidated financial statements.

- removed (2016-11-09):
[0001193125-16-574999:note_history:44]
In November 2015, the FASB issued ASU 2015-17, “Balance Sheet
 Classification of Deferred Taxes”, which will require
 entities to present deferred tax assets (“DTAs”) and
 deferred tax liabilities (“DTLs”) as non-current in a
 classified balance sheet. The ASU simplifies the current guidance,
 which requires entities to separately present DTAs and DTLs as
 current and non-current in a classified balance sheet. For public
 business entities, the amendments in this ASU are effective for
 financial statements issued for annual periods beginning after
 December 15, 2016, and interim periods within those annual
 periods. The Company is currently evaluating the impact of adoption
 of this update on its consolidated financial statements.

- removed (2016-11-09):
[0001193125-16-574999:note_history:45]
In August 2015, the FASB issued ASU 2015-15, “Interest
 – Imputation of Interest (Subtopic 835-30): Presentation and
 Subsequent Measurement of Debt Issuance Costs Associated with
 Line-of-Credit Arrangements”. This ASU amended ASU 2015-03
 regarding debt issuance costs related to the line-of-credit
 arrangement. The Company does not anticipate that the adoption of
 this update will have an effect on its consolidated financial
 statements.

- removed (2016-11-09):
[0001193125-16-574999:note_history:46]
In April 2015, the FASB issued ASU 2015-03, “Interest -
 Imputation of Interest (Subtopic 835-30): Simplifying the
 Presentation of Debt Issuance Costs”. The update requires
 debt issuance costs related to a recognized debt liability be
 presented in the balance sheet as a direct deduction from the
 carrying amount of the related debt liability instead of being
 presented as an asset. Debt disclosures will include the face
 amount of the debt liability and the effective interest rate. The
 update requires retrospective application and represents a change
 in accounting principle. The update is effective for fiscal years
 beginning after December 15, 2015. Early adoption is permitted
 for financial statements that have not been previously issued. The
 Company is currently evaluating the impact of adoption of this
 update on its consolidated financial statements.

- removed (2016-11-09):
[0001193125-16-574999:note_history:47]
In February 2015, the FASB issued ASU 2015-02, “Consolidation
 (Topic 810): Amendments to the Consolidation Analysis”. ASU
 No. 2015-02 amended the process that a reporting entity must
 perform to determine whether it should consolidate certain types of
 legal entities. ASU No. 2015-02 is effective for fiscal years,
 and for interim periods within those fiscal years beginning after
 December 15, 2015. Early adoption is permitted, including
 adoption in an interim period. The Company is currently evaluating
 the impact of adoption of this update on its consolidated financial
 statements.

- removed (2016-11-09):
[0001193125-16-574999:note_history:48]
In January 2015, the FASB issued ASU No. 2015-01,
 “Income Statement – Extraordinary and Unusual Items
 (Subtopic 225-20): Simplifying Income Statement Presentation by
 Eliminating the Concept of Extraordinary Items”. The
 objective of this amendment is to reduce the complexity in
 accounting standards by eliminating the concept of extraordinary
 items from U.S. GAAP. The following criteria must both be met for
 extraordinary classification: (a) the underlying event or
 transaction should possess a high degree of abnormality and be of a
 type clearly unrelated to, or only incidentally related to, the
 ordinary and typical activities of the entity; and (b) the
 underlying event or transaction should not reasonably be expected
 to recur in the foreseeable future. This amendment is effective for
 fiscal years and interim periods beginning after December 15,
 2015. Early adoption is permitted provided that the guidance is
 applied from the beginning of the fiscal year of adoption. The
 Company does not expect that the adoption of this update will have
 an effect on its consolidated financial statements.

- removed (2016-11-09):
[0001193125-16-574999:note_history:49]
In June 2014, the FASB issued ASU No. 2014-12,
 “Compensation – Stock Compensation (Topic 718):
 Accounting for Share-Based Payments When the Terms of an Award
 Provide That a Performance Target Could Be Achieved After the
 Requisite Service Period”. This ASU requires that a
 performance target that affects vesting, and that could be achieved
 after the requisite service period, be treated as a performance
 condition. As such, the performance target should not be reflected
 in estimating the grant date fair value of the award. Compensation
 cost should be recognized in the period in when performance target
 will probably be achieved and should represent attributable to the
 period(s) for which the requisite service has already been
 rendered. This update is required to be adopted by all public
 companies for annual periods and interim reporting periods
 beginning after December 15, 2015, with early adoption
 permitted. The Company does not expect that the adoption of this
 update will have an effect on its consolidated financial
 statements.

- removed (2016-11-09):
[0001193125-16-574999:note_history:50]
In May 2014, the FASB issued ASU 2014-09, “Revenue from
 Contracts with Customers (Topic 606), issued as a new Topic,
 Accounting Standards Codification”. The core principle of
 this amendment is that an entity should recognize revenue to depict
 the transfer of promised goods or services to customers in an
 amount that reflects the consideration to which the entity expects
 to be entitled in exchange for those goods or services. This ASU is
 effective, as amended by ASU 2015-14, for annual reporting periods
 beginning after December 15, 2017, including interim periods
 within that reporting period. Earlier application of this guidance
 is permitted by not before the original date of December 15,
 2016, which can be adopted either retrospectively to each prior
 reporting period presented or as a cumulative-effect adjustment as
 of the date of adoption. In April 2016, the FASB issued ASU
 2016-10, with the same effective date as ASU 2015-14, to address
 the potential diversity in practice at initial application and
 cost; and the complexity of applying Topic 606, both at transition
 and on an ongoing basis related to identification of performance
 obligations and licensing arrangements. The Company is currently
 evaluating the impact of adoption of this update on its
 consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-09):
[0001193125-16-764312:note_history:51]
The Company’s total borrowings, including short-term and
 long-term borrowings, consisted of the following:
  (was, 2016-05-03, similarity 0.9194):
[0001193125-16-574999:note_history:51]
The Company’s total borrowings, including revolving and
 long-term borrowings, consisted of the following:

- added (2016-11-09):
[0001193125-16-764312:note_history:52]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  |  | Maturity |  |  | As of September 30, 2016 |  |  | As of June 24, 2016 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  |  | Repayable in 1 to 6 months |  |  |  | October 2016 (2) |  |  | $ | 20,000 |  |  | $ | 6,500 |  |
| Short-term loans from bank: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank Base rate +1.85% per annum |  |  | Repayable based on credit term of secured accounts receivables |  |  |  |  |  |  |  | 1,182 |  |  |  | — |  |
| Current portion of long-term borrowing |  |  |  |  |  |  |  |  |  |  | 16,600 |  |  |  | 18,100 |  |
|  |  |  |  |  |  |  |  |  |  |  | 37,782 |  |  |  | 24,600 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  |  |  |  |  | (266 | ) |  |  | (293 | ) |
|  |  |  |  |  |  |  |  |  |  | $ | 37,516 |  |  | $ | 24,307 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  |  | Repayable in quarterly installments |  |  |  | March 2017 |  |  | $ | 3,000 |  |  | $ | 4,500 |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  |  | Repayable in quarterly installments |  |  |  | May 2019 |  |  |  | 46,600 |  |  |  | 50,000 |  |
|  |  |  |  |  |  |  |  |  |  |  | 49,600 |  |  |  | 54,500 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (16,600 | ) |  |  | (18,100 | ) |
| Unamortized debt issuance costs |  |  |  |  |  |  |  |  |  |  | (241 | ) |  |  | (300 | ) |
| Non-current portion |  |  |  |  |  |  |  |  |  | $ | 32,759 |  |  | $ | 36,100 |  |

- changed (2016-11-09):
[0001193125-16-764312:note_history:53]
| (1) | LIBOR is London Interbank Offered Rate. |
  (was, 2016-05-03, similarity 0.98):
[0001193125-16-574999:note_history:53]
|  | (1) | LIBOR is London Interbank Offered Rate. |

- changed (2016-11-09):
[0001193125-16-764312:note_history:54]
| (2) | In October 2016, the maturity date was extended to November 2016. |
  (was, 2016-05-03, similarity 0.6353):
[0001193125-16-574999:note_history:54]
|  | (2) | In April 2016, the maturity date of these revolving borrowings were extended to mature in May 2016. |

- changed (2016-11-09):
[0001193125-16-764312:note_history:55]
Under the long-term borrowing contract of a subsidiary, the loan is
 secured by certain property, plant and equipment of the subsidiary.
 The carrying amount of assets secured and pledged as collateral to
 such loan as of September 30, 2016 and June 24, 2016 was $47.0
 million and $47.7 million, respectively. This subsidiary is also
 required to comply with maximum ratios of debt to equity and
 minimum levels of debt service coverage ratios, and Fabrinet must
 maintain an effective shareholding ratio. The carrying amounts of
 bank borrowings approximate their fair value.
  (was, 2016-05-03, similarity 0.9705):
[0001193125-16-574999:note_history:55]
Under the long-term borrowing contract of a subsidiary, the loan is
 secured by certain property, plant and equipment. The carrying
 amount of assets secured and pledged as collateral to such loan as
 of March 25, 2016 and June 26, 2015 was $48.2 million and
 $50.0 million, respectively. This subsidiary is also required to
 comply with maximum ratios of debt to equity and minimum levels of
 debt service coverage ratios, and Fabrinet must maintain an
 effective shareholding ratio. The carrying amounts of bank
 borrowings approximate their fair value.

- changed (2016-11-09):
[0001193125-16-764312:note_history:56]
As of September 30, 2016 and June 24, 2016, the Company was in
 compliance with its bank borrowing agreements. In addition to
 financial ratios, certain of the Company’s credit facilities
 include customary events of default.
  (was, 2016-05-03, similarity 0.637):
[0001193125-16-574999:note_history:56]
As of March 25, 2016 and June 26, 2015, the Company was
 in compliance with its long-term bank borrowing agreement. In
 addition to financial ratios, certain of the Company’s credit
 facilities include customary events of default.

- changed (2016-11-09):
[0001193125-16-764312:note_history:57]
The movements of long-term loans were as follows for the three
 months ended September 30, 2016 and September 25, 2015:
  (was, 2016-05-03, similarity 0.8696):
[0001193125-16-574999:note_history:57]
The movements of long-term loans were as follows for the nine
 months ended March 25, 2016 and March 27, 2015:

- changed (2016-11-09):
[0001193125-16-764312:note_history:58]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 30, 2016 |  |  | September 25, 2015 |  |
| Opening balance |  | $ | 54,500 |  |  | $ | 10,500 |  |
| Repayments during the period |  |  | (4,900 | ) |  |  | (1,500 | ) |
| Closing balance |  | $ | 49,600 |  |  | $ | 9,000 |  |
  (was, 2016-05-03, similarity 0.632):
[0001193125-16-574999:note_history:58]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 25, 2016 |  |  | March 27, 2015 |  |
| Opening book amount |  | $ | 10,500 |  |  | $ | 16,500 |  |
| Repayments during the period |  |  | (4,500 | ) |  |  | (4,500 | ) |
| Closing book amount |  | $ | 6,000 |  |  | $ | 12,000 |  |

- changed (2016-11-09):
[0001193125-16-764312:note_history:59]
As of September 30, 2016, future maturities of long-term debt
 during each fiscal year were as follows:
  (was, 2016-05-03, similarity 0.9468):
[0001193125-16-574999:note_history:59]
As of March 25, 2016, future maturities of long-term debt
 during each fiscal year were as follows:

- changed (2016-11-09):
[0001193125-16-764312:note_history:60]
| (amount in thousands) |  |  |  |
| 2017 (remaining nine months) |  | $ | 13,200 |  |
| 2018 |  |  | 13,600 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 49,600 |  |
  (was, 2016-05-03, similarity 0.8131):
[0001193125-16-574999:note_history:60]
| (amount in thousands) |  |  |  |
| 2016 |  | $ | 1,500 |  |
| 2017 |  |  | 4,500 |  |
| Total |  | $ | 6,000 |  |

- added (2016-11-09):
[0001193125-16-764312:note_history:61]
On February 26, 2015, the Company entered into the Second Amendment
 to the Facility Agreement. The amendment extended the availability
 period for draws on the term loan facility from May 21, 2015 to
 July 31, 2015. It also allowed the Company, upon the satisfaction
 of certain conditions, to designate from time to time one or more
 of its subsidiaries as borrowers under the Facility Agreement. On
 July 31, 2015, the Company entered into the Third Amendment to the
 Facility Agreement. The amendment extended the availability period
 for draws on the term loan facility from July 31, 2015 to July 31,
 2016. As of September 30, 2016, there were $20.0 million of the
 revolving borrowing and $46.6 million of the term loan borrowing
 outstanding under the Facility Agreement, resulting in available
 credit facilities of $133.4 million. Borrowings under the revolving
 credit facility are classified as current liabilities in the
 unaudited condensed consolidated balance sheets as the Company has
 the periodic option to renew or pay, all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. During October 2016, the
 Company sent notices to the bank to renew the maturity date of its
 revolving borrowings. The bank approved the notices and extended
 the maturity to November 2016.

- changed (2016-11-09):
[0001193125-16-764312:note_history:62]
The Facility Agreement contains customary affirmative and negative
 covenants. Negative covenants include, among other things,
 limitations on liens, indebtedness, investments, mergers, sales of
 assets, changes in the nature of the business, dividends and
 distributions, affiliate transactions and capital expenditures. The
 Facility Agreement contains financial covenants requiring Fabrinet
 to maintain: (1) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (2) a minimum debt service coverage ratio of not
 less than 1.50:1.00; (3) a maximum senior leverage ratio of not
 more than 2.50:1.00; and (4) a minimum quick ratio of not less than
 1.10:1.00. Each of these financial covenants is calculated on a
 consolidated basis for the consecutive four fiscal quarter period
 then ended. As of September 30, 2016, the Company was in compliance
 with all covenants under the Facility Agreement.
  (was, 2016-05-03, similarity 0.916):
[0001193125-16-574999:note_history:62]
The Facility Agreement contains customary affirmative and negative
 covenants. Negative covenants include, among other things,
 limitations on liens, indebtedness, investments, mergers, sales of
 assets, changes in the nature of the business, dividends and
 distributions, affiliate transactions and capital expenditures. The
 Facility Agreement contains financial covenants requiring Fabrinet
 to maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage
 ratio of not more than 2.50:1.00; and (iv) a minimum quick
 ratio of not less than 1.10:1.00. Each of these financial covenants
 is calculated on a consolidated basis for the consecutive four
 fiscal quarter period then ended. As of March 25, 2016, the
 Company was in compliance with all covenants under the Facility
 Agreement.

- added (2016-11-09):
[0001193125-16-764312:note_history:63]
Short-term loans from bank

- added (2016-11-09):
[0001193125-16-764312:note_history:64]
In connection with the business acquisition, the Company assumed a
 secured borrowing agreement. The loans are secured by trade
 accounts receivable and the way of chattels mortgage over the plant
 and machine of Exception EMS. As of September 30, 2016, the
 carrying amount of trade accounts receivable and plant and machine
 secured to such loans were $5.5 million and $4.9 million,
 respectively The secured borrowing agreement contains certain
 covenants that the Company is required to comply with: (1) the
 value of credit notes may not exceed 4% of the value of assigned
 debts measured on a monthly basis, and (2) rolling cash flow must
 be provided with monthly management information. As of September
 30, 2016, the Company was in compliance with all covenants under
 the secured borrowing agreement.

- added (2016-11-09):
[0001193125-16-764312:note_history:65]
As of September 30, 2016, the Company drew down from this facility
 of $1.2 million which is recorded as short-term loans in the
 unaudited condensed consolidated balance sheets. The agreement
 bears interest for discount charge at 1.85% per annum above based
 rate.

- changed (2016-11-09):
[0001193125-16-764312:note_history:66]
Undrawn available credit facilities classified by availability
 period of future borrowing as of September 30, 2016 and June 24,
 2016 were as follows:
  (was, 2016-05-03, similarity 0.9446):
[0001193125-16-574999:note_history:66]
Undrawn available credit facilities classified by available period
 of future borrowing as of March 25, 2016 and June 26,
 2015 were as follows:

- changed (2016-11-09):
[0001193125-16-764312:note_history:67]
| (amount in thousands) |  | September 30, 2016 |  |  | June 24, 2016 |  |
| Short-term |  | $ | 2,999 |  |  | $ | 1,414 |  |
| Long-term |  | $ | 133,400 |  |  | $ | 143,500 |  |
  (was, 2016-05-03, similarity 0.963):
[0001193125-16-574999:note_history:67]
| (amount in thousands) |  | March 25, 2016 |  |  | June 26, 2015 |  |
| Short-term |  | $ | 1,415 |  |  | $ | 1,480 |  |
| Long-term |  | $ | 156,000 |  |  | $ | 170,000 |  |

- removed (2016-11-09):
[0001193125-16-574999:note_history:68]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  |  | As of March 25, 2016 |  |  | As of June 26, 2015 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  |  | April 2016 | (2) |  | $ | 44,000 |  |  | $ | 30,000 |  |
| Current portion of long-term borrowing |  |  |  | 6,000 |  |  |  | 6,000 |  |
|  |  |  | $ | 50,000 |  |  | $ | 36,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  |  | March 2017 |  |  | $ | 6,000 |  |  | $ | 10,500 |  |
| Less: Current portion |  |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  | $ | — |  |  | $ | 4,500 |  |

- removed (2016-11-09):
[0001193125-16-574999:note_history:69]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. As of
 March 25, 2016, the outstanding revolving borrowing under the
 Facility Agreement was $44.0 million, resulting in available credit
 facilities of $156.0 million. Borrowings under the revolving credit
 facility are classified as current liabilities in the unaudited
 condensed consolidated balance sheets as the Company has the
 periodic option to renew or pay, all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. During April 2016, the Company
 sent notices to the bank to renew the maturity date of its
 revolving borrowings. The bank approved the notices and extended
 the maturity to May 2016.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-09):
[0001193125-16-764312:note_history:70]
The movements of long-term loans were as follows for the three
 months ended September 30, 2016 and September 25, 2015:
  (was, 2016-05-03, similarity 0.8696):
[0001193125-16-574999:note_history:70]
The movements of long-term loans were as follows for the nine
 months ended March 25, 2016 and March 27, 2015:

- changed (2016-11-09):
[0001193125-16-764312:note_history:71]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 30, 2016 |  |  | September 25, 2015 |  |
| Opening balance |  | $ | 54,500 |  |  | $ | 10,500 |  |
| Repayments during the period |  |  | (4,900 | ) |  |  | (1,500 | ) |
| Closing balance |  | $ | 49,600 |  |  | $ | 9,000 |  |
  (was, 2016-05-03, similarity 0.632):
[0001193125-16-574999:note_history:71]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 25, 2016 |  |  | March 27, 2015 |  |
| Opening book amount |  | $ | 10,500 |  |  | $ | 16,500 |  |
| Repayments during the period |  |  | (4,500 | ) |  |  | (4,500 | ) |
| Closing book amount |  | $ | 6,000 |  |  | $ | 12,000 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-09):
[0001193125-16-764312:note_history:72]
The Company’s total borrowings, including short-term and
 long-term borrowings, consisted of the following:
  (was, 2016-05-03, similarity 0.9194):
[0001193125-16-574999:note_history:72]
The Company’s total borrowings, including revolving and
 long-term borrowings, consisted of the following:

- added (2016-11-09):
[0001193125-16-764312:note_history:73]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  |  | Maturity |  |  | As of September 30, 2016 |  |  | As of June 24, 2016 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  |  | Repayable in 1 to 6 months |  |  |  | October 2016 (2) |  |  | $ | 20,000 |  |  | $ | 6,500 |  |
| Short-term loans from bank: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank Base rate +1.85% per annum |  |  | Repayable based on credit term of secured accounts receivables |  |  |  |  |  |  |  | 1,182 |  |  |  | — |  |
| Current portion of long-term borrowing |  |  |  |  |  |  |  |  |  |  | 16,600 |  |  |  | 18,100 |  |
|  |  |  |  |  |  |  |  |  |  |  | 37,782 |  |  |  | 24,600 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  |  |  |  |  | (266 | ) |  |  | (293 | ) |
|  |  |  |  |  |  |  |  |  |  | $ | 37,516 |  |  | $ | 24,307 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  |  | Repayable in quarterly installments |  |  |  | March 2017 |  |  | $ | 3,000 |  |  | $ | 4,500 |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  |  | Repayable in quarterly installments |  |  |  | May 2019 |  |  |  | 46,600 |  |  |  | 50,000 |  |
|  |  |  |  |  |  |  |  |  |  |  | 49,600 |  |  |  | 54,500 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (16,600 | ) |  |  | (18,100 | ) |
| Unamortized debt issuance costs |  |  |  |  |  |  |  |  |  |  | (241 | ) |  |  | (300 | ) |
| Non-current portion |  |  |  |  |  |  |  |  |  | $ | 32,759 |  |  | $ | 36,100 |  |

- changed (2016-11-09):
[0001193125-16-764312:note_history:74]
| (1) | LIBOR is London Interbank Offered Rate. |
  (was, 2016-05-03, similarity 0.98):
[0001193125-16-574999:note_history:74]
|  | (1) | LIBOR is London Interbank Offered Rate. |

- changed (2016-11-09):
[0001193125-16-764312:note_history:75]
| (2) | In October 2016, the maturity date was extended to November 2016. |
  (was, 2016-05-03, similarity 0.6353):
[0001193125-16-574999:note_history:75]
|  | (2) | In April 2016, the maturity date of these revolving borrowings were extended to mature in May 2016. |

- removed (2016-11-09):
[0001193125-16-574999:note_history:76]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  |  | As of March 25, 2016 |  |  | As of June 26, 2015 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  |  | April 2016 | (2) |  | $ | 44,000 |  |  | $ | 30,000 |  |
| Current portion of long-term borrowing |  |  |  | 6,000 |  |  |  | 6,000 |  |
|  |  |  | $ | 50,000 |  |  | $ | 36,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  |  | March 2017 |  |  | $ | 6,000 |  |  | $ | 10,500 |  |
| Less: Current portion |  |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  | $ | — |  |  | $ | 4,500 |  |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-09):
[0001193125-16-764312:note_history:77]
Undrawn available credit facilities classified by availability
 period of future borrowing as of September 30, 2016 and June 24,
 2016 were as follows:
  (was, 2016-05-03, similarity 0.9446):
[0001193125-16-574999:note_history:77]
Undrawn available credit facilities classified by available period
 of future borrowing as of March 25, 2016 and June 26,
 2015 were as follows:

- changed (2016-11-09):
[0001193125-16-764312:note_history:78]
| (amount in thousands) |  | September 30, 2016 |  |  | June 24, 2016 |  |
| Short-term |  | $ | 2,999 |  |  | $ | 1,414 |  |
| Long-term |  | $ | 133,400 |  |  | $ | 143,500 |  |
  (was, 2016-05-03, similarity 0.963):
[0001193125-16-574999:note_history:78]
| (amount in thousands) |  | March 25, 2016 |  |  | June 26, 2015 |  |
| Short-term |  | $ | 1,415 |  |  | $ | 1,480 |  |
| Long-term |  | $ | 156,000 |  |  | $ | 170,000 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-11-09):
[0001193125-16-764312:note_history:79]
As of September 30, 2016, future maturities of long-term debt
 during each fiscal year were as follows:
  (was, 2016-05-03, similarity 0.9468):
[0001193125-16-574999:note_history:79]
As of March 25, 2016, future maturities of long-term debt
 during each fiscal year were as follows:

- changed (2016-11-09):
[0001193125-16-764312:note_history:80]
| (amount in thousands) |  |  |  |
| 2017 (remaining nine months) |  | $ | 13,200 |  |
| 2018 |  |  | 13,600 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 49,600 |  |
  (was, 2016-05-03, similarity 0.8131):
[0001193125-16-574999:note_history:80]
| (amount in thousands) |  |  |  |
| 2016 |  | $ | 1,500 |  |
| 2017 |  |  | 4,500 |  |
| Total |  | $ | 6,000 |  |
