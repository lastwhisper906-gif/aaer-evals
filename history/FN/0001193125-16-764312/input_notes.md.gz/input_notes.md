# FN notes — 0001193125-16-764312


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-16-764312:notes:1]
The following table summarizes the cost and estimated fair value of
 marketable securities classified as available-for-sale securities
 based on stated effective maturities as of September 30, 2016:

[0001193125-16-764312:notes:2]
| (amount in thousands) |  | Carrying Cost |  |  | Fair Value |  |
| Due within one year |  | $ | 16,828 |  |  | $ | 16,830 |  |
| Due between one to three years |  |  | 130,662 |  |  |  | 130,872 |  |
| Total |  | $ | 147,490 |  |  | $ | 147,702 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-16-764312:notes:3]
| 16. | Commitments and contingencies |

[0001193125-16-764312:notes:4]
Bank guarantees

[0001193125-16-764312:notes:5]
As of September 30, 2016 and June 24, 2016, there were outstanding
 bank guarantees given by banks on behalf of Fabrinet Thailand for
 electricity usage and other normal business amounting to $0.8
 million and $0.8 million, respectively.

[0001193125-16-764312:notes:6]
Operating lease commitments

[0001193125-16-764312:notes:7]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, New Jersey and the United Kingdom under operating
 lease arrangements that expire in various calendar years through
 2023. Rental expense under these operating leases amounted to $0.4
 million and $0.3 million for the three months ended September 30,
 2016 and September 25, 2015, respectively.

[0001193125-16-764312:notes:8]
As of September 30, 2016, the future minimum lease payments due
 under non-cancelable operating leases during each fiscal year were
 as follows:

[0001193125-16-764312:notes:9]
| (amount in thousands) |  |  |  |
| 2017 (remaining nine months) |  | $ | 1,338 |  |
| 2018 |  |  | 1,685 |  |
| 2019 |  |  | 1,131 |  |
| 2020 |  |  | 922 |  |
| 2021 |  |  | 525 |  |
| Thereafter |  |  | 897 |  |
| Total minimum operating lease payments |  | $ | 6,498 |  |

[0001193125-16-764312:notes:10]
Capital lease commitments

[0001193125-16-764312:notes:11]
In connection with the acquisition of Exception EMS, the Company
 assumed the capital lease commitments of certain machine and
 equipment, with various expiration dates until September 2020. The
 equipment can be purchased at the determined price upon
 expiration.

[0001193125-16-764312:notes:12]
As of September 30, 2016, the future minimum lease payments due
 under non-cancelable capital leases during each fiscal year were as
 follows:

[0001193125-16-764312:notes:13]
| (amount in thousands) |  |  |  |
| 2017 (remaining nine months) |  | $ | 301 |  |
| 2018 |  |  | 416 |  |
| 2019 |  |  | 429 |  |
| 2020 |  |  | 376 |  |
| 2021 |  |  | 156 |  |
| Total minimum capital lease payments |  | $ | 1,678 |  |

[0001193125-16-764312:notes:14]
Purchase obligations

[0001193125-16-764312:notes:15]
Purchase obligations represent legally-binding commitments to
 purchase inventory and other commitments made in the normal course
 of business to meet operational requirements. Although open
 purchase orders are considered enforceable and legally binding,
 their terms generally give the Company the option to cancel,
 reschedule and/or adjust its requirements based on its business
 needs prior to the delivery of goods or performance of
 services. Obligations to purchase inventory and other
 commitments are generally expected to be fulfilled within one
 year.

[0001193125-16-764312:notes:16]
As of September 30, 2016, the Company had an outstanding commitment
 to third parties of approximately $30.1 million, mainly related to
 the construction of a new manufacturing building at the
 Company’s Chonburi campus.

[0001193125-16-764312:notes:17]
Indemnification of directors and officers

[0001193125-16-764312:notes:18]
Cayman Islands law does not limit the extent to which a
 company’s memorandum and articles of association may provide
 for indemnification of directors and officers, except to the extent
 any such provision may be held by the Cayman Islands courts to be
 contrary to public policy, such as to provide indemnification
 against civil fraud or the consequences of committing a crime.
 Fabrinet’s amended and restated memorandum and articles of
 association provide for indemnification of directors and officers
 for actions, costs, charges, losses, damages and expenses incurred
 in their capacities as such, except that such indemnification does
 not extend to any matter in respect of any fraud or dishonesty that
 may attach to any of them.

[0001193125-16-764312:notes:19]
In accordance with Fabrinet’s form of indemnification
 agreement for its directors and officers, Fabrinet has agreed to
 indemnify its directors and officers against certain liabilities
 and expenses incurred by such persons in connection with claims by
 reason of their being such a director or officer. Fabrinet
 maintains a director and officer liability insurance policy that
 may enable it to recover a portion of any future amounts paid under
 the indemnification agreements.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-16-764312:notes:20]
| 13. | Share-based compensation |

[0001193125-16-764312:notes:21]
[same as prior period, unchanged from 0001193125-16-574999:notes:33]

[0001193125-16-764312:notes:22]
[same as prior period, unchanged from 0001193125-16-574999:notes:34]

[0001193125-16-764312:notes:23]
The effect of recording share-based compensation expense for the
 three months ended September 30, 2016 and September 25, 2015 was as
 follows:

[0001193125-16-764312:notes:24]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 30, 2016 |  |  | September 25, 2015 |  |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |  |
| Share options |  | $ | — |  |  | $ | 16 |  |
| Restricted share units |  |  | 4,820 |  |  |  | 2,657 |  |
| Performance share units |  |  | 791 |  |  |  | — |  |
| Total share-based compensation expense |  |  | 5,611 |  |  |  | 2,673 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 5,611 |  |  | $ | 2,673 |  |

[0001193125-16-764312:notes:25]
[same as prior period, unchanged from 0001193125-16-574999:notes:37]

[0001193125-16-764312:notes:26]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 30, 2016 |  |  | September 25, 2015 |  |
| Cost of revenue |  | $ | 1,014 |  |  | $ | 537 |  |
| Selling, general and administrative expense |  |  | 4,597 |  |  |  | 2,136 |  |
| Total share-based compensation expense |  | $ | 5,611 |  |  | $ | 2,673 |  |

[0001193125-16-764312:notes:27]
The Company did not capitalize any share-based compensation expense
 as part of any asset costs during the three months ended September
 30, 2016 and September 25, 2015.

[0001193125-16-764312:notes:28]
[same as prior period, unchanged from 0001193125-16-574999:notes:40]

[0001193125-16-764312:notes:29]
Share options have been granted to directors and employees. As of
 September 30, 2016, there were 5 share options outstanding under
 Fabrinet’s Amended and Restated 1999 Share Option Plan (the
 “1999 Plan”). Additional option grants may not be made
 under the 1999 Plan.

[0001193125-16-764312:notes:30]
As of September 30, 2016, there were an aggregate of 306,012 share
 options outstanding, 1,321,464 restricted share units outstanding
 and 234,678 performance share units outstanding under
 Fabrinet’s 2010 Performance Incentive Plan (the “2010
 Plan”). As of September 30, 2016, there were 1,404,646
 ordinary shares available for future grant under the 2010 Plan. The
 1999 Plan and 2010 Plan are collectively referred to as the
 “Share Option Plans.”

[0001193125-16-764312:notes:31]
[same as prior period, unchanged from 0001193125-16-574999:notes:43]

[0001193125-16-764312:notes:32]
Fabrinet’s board of directors has the authority to determine
 the type of option and the number of shares subject to an option.
 Options generally vest and become exercisable over four years and
 expire, if not exercised, within seven years of the grant date. In
 the case of a grantee’s first grant, 25 percent of the
 underlying shares vest 12 months after the vesting commencement
 date and 1/48 of the underlying shares vest monthly over each of
 the subsequent 36 months. In the case of any additional grants
 to a grantee, 1/48 of the underlying shares vest monthly over four
 years, commencing one month after the vesting commencement
 date.

[0001193125-16-764312:notes:33]
[same as prior period, unchanged from 0001193125-16-574999:notes:45]

[0001193125-16-764312:notes:34]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price Per Share |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 24, 2016 |  |  | 464,334 |  |  |  | 464,334 |  |  | $ | 15.95 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (158,317 | ) |  |  |  |  |  | $ | 17.10 |  |  |  |  |  |
| Forfeited |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Expired |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Balance as of September 30, 2016 |  |  | 306,017 |  |  |  | 306,017 |  |  | $ | 15.36 |  |  |  |  |  |
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price Per Share |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 26, 2015 |  |  | 792,019 |  |  |  | 758,451 |  |  | $ | 16.33 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (98,759 | ) |  |  |  |  |  | $ | 15.67 |  |  |  |  |  |
| Forfeited |  |  | (213 | ) |  |  |  |  |  | $ | 14.43 |  |  |  |  |  |
| Expired |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Balance as of September 25, 2015 |  |  | 693,047 |  |  |  | 680,798 |  |  | $ | 16.42 |  |  |  |  |  |

[0001193125-16-764312:notes:35]
The following summarizes information for share options outstanding
 as of September 30, 2016 under the Share Option Plans:

[0001193125-16-764312:notes:36]
|  |  | Range of Exercise Price |  |  | Number of Shares Underlying Options |  |  | Weighted- Average Remaining Contractual Life (years) |  |  | Aggregate Intrinsic Value (amount in thousands) |  |
|  |  |  | $5.75 – $15.05 |  |  |  | 185,092 |  |  |  | 1.94 |  |  |  |  |  |
|  |  |  | $15.16 – $16.83 |  |  |  | 112,375 |  |  |  | 1.09 |  |  |  |  |  |
|  |  |  | $18.60 – $26.16 |  |  |  | 8,550 |  |  |  | 2.02 |  |  |  |  |  |
| Options outstanding |  |  |  |  |  |  | 306,017 |  |  |  | 1.63 |  |  | $ | 8,945 |  |
| Options exercisable |  |  |  |  |  |  | 306,017 |  |  |  | 1.63 |  |  | $ | 8,945 |  |

[0001193125-16-764312:notes:37]
As of September 30, 2016, there was no unrecognized compensation
 cost under the Share Option Plan.

[0001193125-16-764312:notes:38]
Restricted share units and performance share units

[0001193125-16-764312:notes:39]
Restricted share units and performance share units are types of
 share-based awards that may be granted under the 2010 Plan.
 Restricted share units granted to non-employee directors generally
 cliff vest 100% on the first of January, approximately one year
 from the grant date, provided the director continues to serve
 through such date. Restricted share units granted to employees
 generally vest in equal installments over three or four years on
 each anniversary of the vesting commencement date.

[0001193125-16-764312:notes:40]
Performance share units granted to executives will vest at the end
 of a two-year performance period based on the Company’s
 achievement of pre-defined performance criteria, which consist of
 revenue and gross margin targets. The actual number
 of performance share units that may vest at the end of the
 performance period ranges from 0% to 100% of the award grant.

[0001193125-16-764312:notes:41]
The Company has entered into an employment agreement, as amended on
 August 12, 2016, with an executive of the Company that provides for
 accelerated vesting of equity awards under certain circumstances,
 including upon termination of employment. In addition, if the
 executive’s employment with the Company continues through and
 including February 20, 2017, (1) any outstanding equity awards
 granted to the executive prior to August 2016 will become 100%
 vested and (2) certain restricted share units granted to the
 executive in August 2016 will become 100% vested.

[0001193125-16-764312:notes:42]
[same as prior period, unchanged from 0001193125-16-574999:notes:54]

[0001193125-16-764312:notes:43]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 24, 2016 |  |  | 1,181,402 |  |  | $ | 18.34 |  |
| Granted |  |  | 568,283 |  |  | $ | 39.53 |  |
| Issued |  |  | (408,874 | )(1) |  | $ | 16.23 |  |
| Forfeited |  |  | (19,347 | ) |  | $ | 19.12 |  |
| Balance as of September 30, 2016 |  |  | 1,321,464 |  |  | $ | 28.10 |  |
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 26, 2015 |  |  | 1,140,927 |  |  | $ | 16.02 |  |
| Granted |  |  | 499,896 |  |  | $ | 19.34 |  |
| Issued |  |  | (286,374 | ) |  | $ | 14.69 |  |
| Forfeited |  |  | (6,587 | ) |  | $ | 18.11 |  |
| Balance as of September 26, 2015 |  |  | 1,347,862 |  |  | $ | 17.09 |  |

[0001193125-16-764312:notes:44]
| (1) | Includes 875 shares vested on September 30, 2016, but not settled. |

[0001193125-16-764312:notes:45]
The following summarizes performance share unit activity under the
 2010 Plan:

[0001193125-16-764312:notes:46]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 24, 2016 |  |  | — |  |  |  | — |  |
| Granted |  |  | 234,678 |  |  | $ | 40.48 |  |
| Issued |  |  | — |  |  |  | — |  |
| Forfeited |  |  | — |  |  |  | — |  |
| Balance as of September 30, 2016 |  |  | 234,678 |  |  | $ | 40.48 |  |

[0001193125-16-764312:notes:47]
As of September 30, 2016, there was $35.3 million of unrecognized
 share-based compensation expense related to restricted share units
 under the 2010 Plan that is expected to be recorded over a
 weighted-average period of 2.77 years.

[0001193125-16-764312:notes:48]
For the three months ended September 30, 2016 and September 25,
 2015, the Company withheld an aggregate of 22,294 shares and 46,016
 shares, respectively, upon the vesting of restricted share units,
 based upon the closing share price on the vesting date to settle
 the employees’ minimum statutory obligation for the
 applicable income and other employment taxes. For the three months
 ended September 30, 2016 and September 25 2015, the Company
 then remitted cash of $0.9 million and $0.9 million, respectively,
 to the appropriate taxing authorities, and presented it in a
 financing activity within the unaudited condensed consolidated
 statements of cash flows. The payment had the effect on shares
 issued by the Company as it reduced the number of shares that would
 have been issued on the vesting date and was recorded as a
 reduction of additional paid-in capital.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-16-764312:notes:49]
[same as prior period, unchanged from 0001193125-16-574999:notes:9]

[0001193125-16-764312:notes:50]
| (amount in thousands) |  | As of September 30, 2016 |  |  | As of June 24, 2016 |  |
| Raw materials |  | $ | 66,759 |  |  | $ | 58,199 |  |
| Work in progress |  |  | 106,702 |  |  |  | 94,762 |  |
| Finished goods |  |  | 23,007 |  |  |  | 21,593 |  |
| Goods in transit |  |  | 12,491 |  |  |  | 9,381 |  |
|  |  |  | 208,959 |  |  |  | 183,935 |  |
| Less: Inventory obsolescence |  |  | (3,475 | ) |  |  | (2,436 | ) |
| Inventory, net |  | $ | 205,484 |  |  | $ | 181,499 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-16-764312:notes:51]
New Accounting Pronouncements – adopted by the
 Company

[0001193125-16-764312:notes:52]
In November 2015, the FASB issued ASU 2015-17, “Balance Sheet
 Classification of Deferred Taxes,” which will require
 entities to present deferred tax assets (“DTAs”) and
 deferred tax liabilities (“DTLs”) as non-current in a
 classified balance sheet. The ASU simplifies the current guidance,
 which requires entities to separately present DTAs and DTLs as
 current and non-current in a classified balance sheet. The Company
 adopted of this update early. Accordingly, as of September 30,
 2016, DTAs of $1.2 million were classified to non-current in
 the unaudited condensed consolidated balance sheets. The Company
 adopted this update on a prospective basis and did not change the
 presentation of the comparative period.

[0001193125-16-764312:notes:53]
In September 2015, the FASB issued ASU 2015-16, “Business
 Combinations (Topic 805): Simplifying the Accounting for
 Measurement-Period Adjustments” which require an acquirer to
 recognize adjustments to provisional amounts that are identified
 during the measurement period in the reporting period in which the
 adjustment amounts are determined. The Company has adopted of this
 update and applied it on a prospective basis.

[0001193125-16-764312:notes:54]
In April 2015, the FASB issued ASU 2015-03, “Interest –
 Imputation of Interest (Subtopic 835-30): Simplifying the
 Presentation of Debt Issuance Costs.” The update requires
 debt issuance costs related to a recognized debt liability be
 presented in the balance sheet as a direct deduction from the
 carrying amount of the related debt liability instead of being
 presented as an asset. Debt disclosures will include the face
 amount of the debt liability and the effective interest rate. The
 update requires retrospective application and represents a change
 in accounting principle. Additionally, in August 2015, the FASB
 issued ASU 2015-15, “Interest – Imputation of Interest
 (Subtopic 835-30): Presentation and Subsequent Measurement of Debt
 Issuance Costs Associated with Line-of-Credit Arrangements”
 to amend ASU 2015-03. The Company has adopted this amendment
 retrospectively. As of September 30, 2016 and June 24, 2016, debt
 issuance costs of $0.5 million and $0.6 million, respectively,
 related to a recognized debt liability are presented in the balance
 sheet as a direct reduction of the carrying amount of the related
 debts.

[0001193125-16-764312:notes:55]
In February 2015, the FASB issued ASU 2015-02, “Consolidation
 (Topic 810): Amendments to the Consolidation Analysis.” ASU
 No. 2015-02 amended the process that a reporting entity must
 perform to determine whether it should consolidate certain types of
 legal entities. The Company has adopted this update with no impact
 to the unaudited condensed consolidated financial statements.

[0001193125-16-764312:notes:56]
In January 2015, the FASB issued ASU 2015-01, “Income
 Statement – Extraordinary and Unusual Items (Subtopic
 225-20): Simplifying Income Statement Presentation by Eliminating
 the Concept of Extraordinary Items.” The objective of this
 amendment is to reduce the complexity in accounting standards by
 eliminating the concept of extraordinary items from U.S. GAAP. To
 meet for extraordinary classification the underlying event or
 transaction should (a) possess a high degree of abnormality and be
 of a type clearly unrelated to, or only incidentally related to,
 the ordinary and typical activities of the entity and (b) not
 reasonably be expected to recur in the foreseeable future. The
 Company has adopted this update with no impact to the unaudited
 condensed consolidated financial statements.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-16-764312:notes:57]
The changes in AOCI for the three months ended September 30, 2016
 were as follows:

[0001193125-16-764312:notes:58]
| (amount in thousands) |  | Unrealized net Gains (Losses) on Marketable Securities |  |  | Unrealized net Gains (Losses) on Derivative Instruments |  |  | Foreign Currency Translation Adjustment |  |  | Total |  |
| Balance as of June 24, 2016 |  | $ | 399 |  |  | $ | 192 |  |  | $ | — |  |  | $ | 591 |  |
| Other comprehensive income before reclassification adjustment |  |  | (87 | ) |  |  | — |  |  |  | 741 |  |  |  | 654 |  |
| Amounts reclassified out of AOCI to foreign exchange loss in the unaudited condensed consolidated statement of operations and comprehensive income |  |  | (100 | ) |  |  | (158 | ) |  |  | — |  |  |  | (258 | ) |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive loss |  | $ | (187 | ) |  | $ | (158 | ) |  |  | 741 |  |  | $ | 396 |  |
| Balance as of September 30, 2016 |  | $ | 212 |  |  | $ | 34 |  |  | $ | 741 |  |  | $ | 987 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001193125-16-764312:notes:59]
The movements of long-term loans were as follows for the three
 months ended September 30, 2016 and September 25, 2015:

[0001193125-16-764312:notes:60]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 30, 2016 |  |  | September 25, 2015 |  |
| Opening balance |  | $ | 54,500 |  |  | $ | 10,500 |  |
| Repayments during the period |  |  | (4,900 | ) |  |  | (1,500 | ) |
| Closing balance |  | $ | 49,600 |  |  | $ | 9,000 |  |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock

[0001193125-16-764312:notes:61]
Undrawn available credit facilities classified by availability
 period of future borrowing as of September 30, 2016 and June 24,
 2016 were as follows:

[0001193125-16-764312:notes:62]
| (amount in thousands) |  | September 30, 2016 |  |  | June 24, 2016 |  |
| Short-term |  | $ | 2,999 |  |  | $ | 1,414 |  |
| Long-term |  | $ | 133,400 |  |  | $ | 143,500 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-16-764312:notes:63]
[same as prior period, unchanged from 0001193125-16-574999:notes:7]

[0001193125-16-764312:notes:64]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 30, 2016 |  |  | September 25, 2015 |  |
| North America |  | $ | 165,995 |  |  | $ | 106,443 |  |
| Asia-Pacific |  |  | 114,745 |  |  |  | 83,890 |  |
| Europe |  |  | 51,303 |  |  |  | 26,100 |  |
|  |  | $ | 332,043 |  |  | $ | 216,433 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-16-764312:notes:65]
[same as prior period, unchanged from 0001193125-16-574999:notes:91]

[0001193125-16-764312:notes:66]
Basis of presentation

[0001193125-16-764312:notes:67]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of September 30, 2016 and for the three
 months ended September 30, 2016 and September 25, 2015 includes
 normal recurring adjustments, necessary for a fair presentation of
 the financial statements set forth herein, in accordance with
 accounting principles generally accepted in the United States of
 America (“U.S. GAAP”) for interim financial information
 and the rules and regulations of the Securities and Exchange
 Commission (“SEC”). Accordingly, such information does
 not include all of the information and footnotes required by U.S.
 GAAP for annual financial statements. For further information,
 please refer to the consolidated financial statements and footnotes
 thereto included in Fabrinet’s Annual Report on Form 10-K for
 the year ended June 24, 2016.

[0001193125-16-764312:notes:68]
The balance sheet as of June 24, 2016 has been derived from the
 audited financial statements at that date but does not include all
 of the information and footnotes required by U.S. GAAP for complete
 financial statements. The results for the three months ended
 September 30, 2016 may not be indicative of results for the year
 ending June 30, 2017 or any future periods.

[0001193125-16-764312:notes:69]
Where necessary, comparative figures have been reclassified to
 conform to the current period accounting policies and presentation
 adopted.

[0001193125-16-764312:notes:70]
On September 14, 2016, the Company acquired 100% of the shares
 of Global CEM Solutions, Ltd. and all of its subsidiaries, a
 privately-held group located in Wiltshire, United
 Kingdom (“Exception EMS”). The unaudited condensed
 consolidated financial statements of the Company include the
 financial position, results of operations and the cash flows of
 Exception EMS commencing as of the acquisition date. See Note 8 -
 Business acquisitions for further details on the accounting for
 this transaction.

[0001193125-16-764312:notes:71]
[same as prior period, unchanged from 0001193125-16-574999:notes:92]

[0001193125-16-764312:notes:72]
The preparation of the Company’s condensed consolidated
 financial statements in conformity with U.S. GAAP requires
 management to make estimates and assumptions that affect the
 reported amounts of assets and liabilities and disclosure of
 contingent liabilities at the date of the financial statements, and
 the reported amount of total revenues and expenses during the year.
 The Company bases estimates on historical experience and various
 assumptions about the future that are believed to be reasonable
 based on available information. The Company’s reported
 financial position or results of operations may be materially
 different under different conditions or when using different
 estimates and assumptions, particularly with respect to significant
 accounting policies, which are discussed below. Significant
 assumptions are used in accounting for share-based compensation,
 allowance for doubtful accounts, income taxes, inventory
 obsolescence and valuation of intangible assets related to business
 acquisition, among others. Due to the inherent uncertainty involved
 in making estimates, actual results reported in future periods may
 be different from these estimates. In the event that estimates or
 assumptions prove to differ from actual results, adjustments will
 be made in subsequent periods to reflect more current
 information.

[0001193125-16-764312:notes:73]
[same as prior period, unchanged from 0001193125-16-574999:notes:94]

[0001193125-16-764312:notes:74]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended September 30,
 2016 and September 25, 2015 each consisted of 14 weeks and 13
 weeks, respectively. Fiscal year 2017 will be comprised of 53 weeks
 and will end on June 30, 2017.

[0001193125-16-764312:notes:75]
[same as prior period, unchanged from 0001193125-16-574999:notes:96]

[0001193125-16-764312:notes:76]
[same as prior period, unchanged from 0001193125-16-574999:notes:97]

[0001193125-16-764312:notes:77]
[same as prior period, unchanged from 0001193125-16-574999:notes:98]

[0001193125-16-764312:notes:78]
[same as prior period, unchanged from 0001193125-16-574999:notes:99]

[0001193125-16-764312:notes:79]
[same as prior period, unchanged from 0001193125-16-574999:notes:100]

[0001193125-16-764312:notes:80]
The derivatives assets and liabilities are recognized on the
 consolidated balance sheets as other current assets or accrued
 expenses measured at fair value.

[0001193125-16-764312:notes:81]
[same as prior period, unchanged from 0001193125-16-574999:notes:102]

[0001193125-16-764312:notes:82]
Derivatives designated and qualifying as hedges of the exposure to
 variability in expected future cash flows, or other types of
 forecasted transactions, are considered cash flow hedges which
 include forward currency contracts. In a cash flow hedging
 relationship, the effective portion of the change in the fair value
 of the hedging derivative is initially recorded in accumulated
 other comprehensive income (loss) (“AOCI”), while any
 ineffective portion is recognized directly in earnings, as a
 component of other income (expense). The portion of gain or loss on
 the derivative instrument remains in AOCI until the forecasted
 transaction is recognized in earnings.

[0001193125-16-764312:notes:83]
The Company also enters into derivative contracts that are intended
 to economically hedge certain of the Company’s risks. The
 changes in the fair value of the derivatives are recorded directly
 in earnings as a component of other income (expense), net. In
 accordance with the fair value measurement guidance, the
 Company’s accounting policy is to measure the credit risk of
 its derivative financial instruments that are subject to master
 netting agreements on a net basis by counterparty portfolio. The
 Company executes derivative instruments with financial institutions
 that are credit-worthy, defined as institutions that hold an
 investment grade credit rating.

[0001193125-16-764312:notes:84]
Business acquisition

[0001193125-16-764312:notes:85]
For the acquisition of Exception EMS, the Company allocated the
 fair value of purchase consideration to the assets acquired and
 liability assumed based on their fair values at the acquisition
 date. The total consideration and the allocation of consideration
 to the individual net assets is preliminary, as there are remaining
 uncertainties to be resolved, including the settlement of the final
 net working capital adjustment and the finalization of the
 estimated fair value attributable to the acquired intangible
 assets.

[0001193125-16-764312:notes:86]
The acquired intangible assets include customer relationships and
 backlog and are recorded as intangibles in the unaudited condensed
 consolidated balance sheets. The fair value of the acquired
 intangible assets was determined based on the multi-period excess
 earnings method. The Company reviews intangibles for impairment
 annually or whenever changes or circumstances indicate the carrying
 amount may not be recoverable.

[0001193125-16-764312:notes:87]
In connection with the business acquisition, $3.4 million of cash
 for deferred consideration was placed into an escrow account which
 is under the Company controls. However, the Company has
 contractually agreed to remit this deferred consideration to the
 sellers of Exception EMS, subject to the resolution of claims that
 the Company may make against the funds with respect to
 indemnification and other claims within 24 months from the closing
 date of the transaction. The cash is presented as restricted cash
 in the unaudited condensed consolidated balance sheets and the
 related liability is presented within non-current liabilities for
 the deferred consideration.

[0001193125-16-764312:notes:88]
Goodwill

[0001193125-16-764312:notes:89]
Goodwill arising from the acquisition is primarily attributable to
 the ability to expand future products and services and the
 assembled workforce. Goodwill is reviewed annually for impairment
 or more frequently whenever changes or circumstances indicate the
 carrying amount of goodwill may not be recoverable.

[0001193125-16-764312:notes:90]
Capital lease

[0001193125-16-764312:notes:91]
Certain machine and equipment held under capital leases are
 classified as property, plant and equipment and amortized using the
 straight-line method over the terms of the lease contracts. The
 related obligations from the capital lease are recorded as
 liabilities in the unaudited condensed consolidated balance
 sheets.

[0001193125-16-764312:notes:92]
[same as prior period, unchanged from 0001193125-16-574999:notes:105]

[0001193125-16-764312:notes:93]
In October 2016, the Financial Accounting Standards Board
 (“FASB”) issued Accounting Standards Update
 (“ASU”) 2016-16, “Income Taxes (Topic 740)
 – Intra-Entity Transfers of Assets Other Than
 Inventory,” which eliminates the exception for an
 intra-entity transfer of an asset other than inventory that
 prohibits the recognition of current and deferred income taxes
 until the asset has been sold to an outside party. The entity
 should recognize income tax consequences of an intra-entity
 transfer of assets other than inventory when the transfer occurs.
 For public entities, this update is effective for annual reporting
 periods beginning after December 15, 2017, including interim
 reporting periods within those annual reporting periods. Early
 adoption is permitted for all entities as of the beginning of an
 annual reporting period for which financial statements have not
 been issued or made available for issuance. The Company is
 currently evaluating the impact of the adoption of this update on
 its consolidated financial statements.

[0001193125-16-764312:notes:94]
In August 2016, the FASB issued ASU 2016-15, “Classification
 of Certain Cash Receipts and Cash Payments (a consensus of the
 Emerging Issues Task Force).” The amendments in this ASU
 provide guidance on the presentation of certain cash receipts and
 cash payments in the statement of cash flows in order to reduce
 diversity in existing practice. The amendments in ASU 2016-15 are
 effective for public business entities for fiscal years beginning
 after December 15, 2017, and interim periods within those fiscal
 years. Early adoption is permitted, including adoption in an
 interim period. The Company is currently evaluating the impact of
 the adoption of this update on its consolidated financial
 statements.

[0001193125-16-764312:notes:95]
In June 2016, the FASB issued ASU 2016-13, “Financial
 Instruments – Credit Losses (Topic 326): Measurement of
 Credit Losses on Financial Instruments.” The amendments
 in this ASU replace the incurred loss impairment methodology in
 current GAAP with a methodology that reflects expected credit
 losses and requires consideration of a broader range of reasonable
 and supportable information to inform credit loss estimates. The
 amendments are effective for fiscal years beginning after
 December 15, 2019, including interim periods within those
 fiscal years. Early adoption is permitted for fiscal years
 beginning after December 15, 2018, including interim periods
 within those fiscal years. The Company is currently evaluating the
 impact of the adoption of this update on its consolidated financial
 statements.

[0001193125-16-764312:notes:96]
In March 2016, the FASB issued ASU
 2016-09, “Compensation – Stock Compensation (Topic
 718): Improvements to Employee Share-Based Payment
 Accounting.” This ASU simplifies several aspects of the
 accounting for share-based payment award transactions, including,
 the income tax consequences, classification of awards as either
 equity or liabilities and classification on the statement of cash
 flows. The amendments in this update are effective for annual
 periods beginning after December 15, 2016, and interim periods
 within those annual periods, for public companies. Early
 adoption is permitted for any entity in any interim or annual
 period. The Company is currently evaluating the impact of the
 adoption of this update on its consolidated financial
 statements.

[0001193125-16-764312:notes:97]
In March 2016, the FASB issued ASU 2016-05, “Derivatives and
 Hedging (Topic 815),” to clarify that a change in the
 counterparty to a derivative instrument that has been designated as
 a hedging instrument under Topic 815, does not, in and of itself,
 require designation of the hedging relationship, provided that all
 other hedge accounting criteria continue to be met. This guidance
 is effective for public entities for financial statements issued
 for fiscal years beginning after December 15, 2016 and interim
 periods within those fiscal years. Early adoption is permitted. The
 Company is currently evaluating the impact of the adoption of this
 update on its consolidated financial statements.

[0001193125-16-764312:notes:98]
In February 2016, the FASB issued ASU 2016-02, “Lease (Topic
 842).” The core principle of Topic 842 is that a lessee
 should recognize the lease assets and liabilities that arise from
 leases in the statement of financial position. For public business
 entities, this update is effective for fiscal years beginning after
 December 15, 2018, including interim periods within those fiscal
 years. Early application is permitted. The Company is currently
 evaluating the impact of the adoption of this update on its
 consolidated financial statements.

[0001193125-16-764312:notes:99]
In January 2016, the FASB issued ASU 2016-01, “Financial
 Instruments – Overall (Subtopic 825-10): Recognition and
 Measurement of Financial Assets and Financial Liabilities.”
 This new guidance requires certain equity investments to be
 measured at fair value, use of the exit price notion and separate
 presentation of financial assets and financial liabilities by
 measurement category and form of financial asset on the balance
 sheet or the accompanying notes to the financial statements. The
 ASU on recognition and measurement will take effect for public
 companies for fiscal years beginning after December 15, 2017,
 including interim periods within those fiscal years. The
 Company is currently evaluating the impact of the adoption of this
 update on its consolidated financial statements.

[0001193125-16-764312:notes:100]
In July 2015, the FASB issued ASU 2015-11, “Inventory (Topic
 330): Simplifying the Measurement of Inventory.” The update
 provides the guidance that an entity, that measured inventory by
 using first-in, first-out or average cost, should measure inventory
 at the lower of cost and net realizable value. Subsequent
 measurement is unchanged for inventory measured using last-in,
 first-out or the retail inventory method. The update is effective
 for fiscal years beginning after December 15, 2016, including
 interim periods within these fiscal years. This update should be
 applied prospectively with earlier application permitted as of the
 beginning of an interim or annual reporting date. The Company is
 currently evaluating the impact of the adoption of this update on
 its consolidated financial statements.

[0001193125-16-764312:notes:101]
In August 2014, the FASB issued ASU 2014-15, “Presentation of
 Financial Statements – Going Concern (Subtopic 205-40):
 Disclosure of Uncertainties about an Entity’s Ability to
 Continue as a Going Concern.” The amendments require
 management to evaluate, for each annual and interim reporting
 period, an entity’s ability to continue as a going concern
 when relevant conditions and events, considered in the aggregate,
 indicate that it is probable that the entity will be unable to meet
 its obligations that become due within one year after the date that
 the financial statements are issued (or available to be issued).
 This ASU is effective for annual periods and interim reporting
 periods beginning after December 15, 2016. The Company does not
 expect that the adoption of this update will have an effect on its
 consolidated financial statements.

[0001193125-16-764312:notes:102]
In May 2014, the FASB issued ASU 2014-09, “Revenue from
 Contracts with Customers (Topic 606), issued as a new Topic,
 Accounting Standards Codification.” The core principle of
 this amendment is that an entity should recognize revenue to depict
 the transfer of promised goods or services to customers in an
 amount that reflects the consideration to which the entity expects
 to be entitled in exchange for those goods or services. This update
 is effective for public companies, as amended by ASU 2015-14, for
 annual reporting periods beginning after December 15, 2017,
 including interim periods within that reporting period. Earlier
 application of this guidance is permitted, but not before the
 original date of December 15, 2016, which can be adopted either
 retrospectively to each prior reporting period presented or as a
 cumulative-effect adjustment as of the date of adoption.
 Subsequently, in March 2016 and April 2016, the FASB issued ASU
 2016-08 and ASU 2016-10, to clarify the implementation guidance on
 principle versus agent considerations and address the potential
 diversity in practice at initial application and cost; and the
 complexity of applying Topic 606, both at transition and on an
 ongoing basis related to identification of performance obligations
 and licensing arrangements; and ASU 2016-12, in May 2016, to
 improve in certain aspects of Topic 606, with the same effective
 date as ASU 2015-14. The Company will adopt this standard during
 its fiscal year ending June 28, 2018. In the current period, the
 Company is assessing the contracts with its customers to identify
 the impact to its consolidated financial statements. The process is
 still ongoing and the Company expects to make significant progress
 in the coming quarters.


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001193125-16-764312:notes:103]
[same as prior period, unchanged from 0001193125-16-574999:notes:127]

[0001193125-16-764312:notes:104]
[same as prior period, unchanged from 0001193125-16-574999:notes:128]

[0001193125-16-764312:notes:105]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Gain/(Loss) |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of September 30, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 105,675 |  |  | $ | — |  |  | $ | 105,675 |  |  | $ | — |  |
| Cash equivalents |  |  | 185 |  |  |  | — |  |  |  | 185 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 116,926 |  |  |  | 235 |  |  |  | — |  |  |  | 117,161 |  |
| U.S. agency and U.S. treasury securities |  |  | 29,411 |  |  |  | (23 | ) |  |  | — |  |  |  | 29,388 |  |
| Sovereign and municipal securities |  |  | 1,153 |  |  |  | — |  |  |  | — |  |  |  | 1,153 |  |
| Total |  | $ | 253,350 |  |  | $ | 212 |  |  | $ | 105,860 |  |  | $ | 147,702 |  |

[0001193125-16-764312:notes:106]
|  |  |  |  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Gain |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of June 24, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 136,754 |  |  | $ | — |  |  | $ | 136,754 |  |  | $ | — |  |
| Cash equivalents |  |  | 6,050 |  |  |  | — |  |  |  | 6,050 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 112,128 |  |  |  | 394 |  |  |  | — |  |  |  | 112,522 |  |
| U.S. agency and U.S. treasury securities |  |  | 28,028 |  |  |  | 2 |  |  |  | — |  |  |  | 28,030 |  |
| Sovereign and municipal securities |  |  | 1,154 |  |  |  | 3 |  |  |  | — |  |  |  | 1,157 |  |
| Total |  | $ | 284,114 |  |  | $ | 399 |  |  | $ | 142,804 |  |  | $ | 141,709 |  |

[0001193125-16-764312:notes:107]
[same as prior period, unchanged from 0001193125-16-574999:notes:131]

[0001193125-16-764312:notes:108]
During the three months ended September 30, 2016, the Company
 recognized a realized loss of $0.1 million from sales and
 maturities of available-for-sale securities.

[0001193125-16-764312:notes:109]
As of September 30, 2016, the Company considered the declines in
 market value of its marketable securities investment portfolio to
 be temporary in nature and did not consider any of its securities
 other-than-temporarily impaired. The Company typically invests in
 highly-rated securities, and its investment policy generally limits
 the amount of credit exposure to any one issuer. The policy
 requires investments generally to be investment grade, with the
 primary objective of minimizing the potential risk of principal
 loss. Fair values were determined for each individual security in
 the investment portfolio. When evaluating an investment for
 other-than-temporary impairment, the Company reviews factors such
 as the length of time and extent to which fair value has been below
 its cost basis, the financial condition of the issuer and any
 changes thereto, changes in market interest rates, and the
 Company’s intent to sell, or whether it is more likely than
 not it will be required to sell, the investment before recovery of
 the investment’s cost basis. No impairment losses were
 recorded for the three months ended September 30, 2016.

[0001193125-16-764312:notes:110]
As of September 30, 2016, cash, cash equivalents, and marketable
 securities included bank deposits of $40.0 million held in various
 financial institutions located in the United States in order to
 support the availability of the Facility Agreement (as defined in
 Note 11) and comply with covenants. As discussed in Note 11, under
 the terms and conditions of the Facility Agreement, the Company
 shall maintain cash, cash equivalents and/or marketable securities
 in an aggregate amount not less than $40.0 million in unencumbered
 deposits, and/or securities in accounts located in the United
 States at all times during the term of the Facility Agreement. The
 Company must comply with the covenant from and after the effective
 date of the Facility Agreement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-16-764312:notes:111]
| 12. | Income taxes |

[0001193125-16-764312:notes:112]
As of September 30, 2016 and June 24, 2016, the liability for
 uncertain tax positions including accrued interest and penalties
 was $1.9 million and $1.8 million, respectively. The Company
 expects the estimated amount of liability associated with its
 uncertain tax positions to decrease within the next 12 months
 due to the lapse of the applicable statute of limitations in
 foreign tax jurisdictions.

[0001193125-16-764312:notes:113]
The Company files income tax returns in the United States and
 foreign tax jurisdictions. The tax years from 2012 to 2016 remain
 open to examination by U.S. federal and state tax authorities, and
 foreign tax authorities. The Company’s income tax is
 recognized based on the best estimate of the expected annual
 effective tax rate for the full financial year of each entity in
 the Company, adjusted for discrete items arising in that quarter.
 If the Company’s estimated annual effective tax rate changes,
 the Company makes a cumulative adjustment in that quarter.

[0001193125-16-764312:notes:114]
The effective tax rate for the Company for the three months ended
 September 30, 2016 and September 25, 2015 remained flat at
 6.7% of net income. The Company’s taxable income and income
 tax expenses for the three months ended September 30, 2016
 increased proportionately on an absolute dollars basis, compared
 with the three months ended September 25, 2015.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001193125-16-764312:notes:115]
| 6. | Trade accounts receivable, net |

[0001193125-16-764312:notes:116]
| (amount in thousands) |  | As of September 30, 2016 |  |  | As of June 24, 2016 |  |
| Trade accounts receivable |  | $ | 212,774 |  |  | $ | 196,178 |  |
| Less: Allowance for doubtful account |  |  | (90 | ) |  |  | (33 | ) |
| Trade accounts receivable, net |  | $ | 212,684 |  |  | $ | 196,145 |  |

[0001193125-16-764312:notes:117]
As of September 30, 2016, trade accounts receivable of $1.7 million
 were secured to short-term loans from bank (see Note 11).


## us-gaap:ScheduleOfDebtTableTextBlock

[0001193125-16-764312:notes:118]
The Company’s total borrowings, including short-term and
 long-term borrowings, consisted of the following:

[0001193125-16-764312:notes:119]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  |  | Maturity |  |  | As of September 30, 2016 |  |  | As of June 24, 2016 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  |  | Repayable in 1 to 6 months |  |  |  | October 2016 (2) |  |  | $ | 20,000 |  |  | $ | 6,500 |  |
| Short-term loans from bank: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank Base rate +1.85% per annum |  |  | Repayable based on credit term of secured accounts receivables |  |  |  |  |  |  |  | 1,182 |  |  |  | — |  |
| Current portion of long-term borrowing |  |  |  |  |  |  |  |  |  |  | 16,600 |  |  |  | 18,100 |  |
|  |  |  |  |  |  |  |  |  |  |  | 37,782 |  |  |  | 24,600 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  |  |  |  |  | (266 | ) |  |  | (293 | ) |
|  |  |  |  |  |  |  |  |  |  | $ | 37,516 |  |  | $ | 24,307 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  |  | Repayable in quarterly installments |  |  |  | March 2017 |  |  | $ | 3,000 |  |  | $ | 4,500 |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  |  | Repayable in quarterly installments |  |  |  | May 2019 |  |  |  | 46,600 |  |  |  | 50,000 |  |
|  |  |  |  |  |  |  |  |  |  |  | 49,600 |  |  |  | 54,500 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (16,600 | ) |  |  | (18,100 | ) |
| Unamortized debt issuance costs |  |  |  |  |  |  |  |  |  |  | (241 | ) |  |  | (300 | ) |
| Non-current portion |  |  |  |  |  |  |  |  |  | $ | 32,759 |  |  | $ | 36,100 |  |

[0001193125-16-764312:notes:120]
| (1) | LIBOR is London Interbank Offered Rate. |

[0001193125-16-764312:notes:121]
| (2) | In October 2016, the maturity date was extended to November 2016. |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001193125-16-764312:notes:122]
As of September 30, 2016, future maturities of long-term debt
 during each fiscal year were as follows:

[0001193125-16-764312:notes:123]
| (amount in thousands) |  |  |  |
| 2017 (remaining nine months) |  | $ | 13,200 |  |
| 2018 |  |  | 13,600 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 49,600 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-16-764312:notes:124]
Based on the carrying amount of intangibles as of September 30,
 2016, and assuming no future impairment of the underlying assets,
 the estimated future amortization during each fiscal year was as
 follows:

[0001193125-16-764312:notes:125]
| (amount in thousands) |  |  |  |
| 2017 (remaining nine months) |  | $ | 461 |  |
| 2018 |  |  | 614 |  |
| 2019 |  |  | 614 |  |
| 2020 |  |  | 585 |  |
| 2021 |  |  | 517 |  |
| Thereafter |  |  | 2,300 |  |
| Total |  | $ | 5,091 |  |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001193125-16-764312:notes:126]
The changes in the carrying amount of goodwill were as follows;

[0001193125-16-764312:notes:127]
| (amount in thousands) |  | Goodwill |  |
| Balance as of June 24, 2016 |  | $ | — |  |
| Addition in connection with business acquisition |  |  | 2,994 |  |
| Balance as of September 30, 2016 |  | $ | 2,994 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-16-764312:notes:128]
| 8. | Business acquisition |

[0001193125-16-764312:notes:129]
On September 14, 2016, the Company acquired 100% of the shares
 of Exception EMS, a privately-held group located in Wiltshire,
 United Kingdom, for cash consideration of approximately $13.0
 million, net of $0.5 million cash acquired. Exception EMS provides
 contract electronics manufacturing services to the global
 electronics industry with innovative solutions, adding value to the
 design, manufacture and testing of printed circuit board
 assemblies. Pursuant to the acquisition agreement, the Company has
 placed $3.4 million of cash for deferred consideration in an escrow
 account which is under the Company controls. However, the Company
 has contractually agreed to remit this deferred consideration to
 the sellers of Exception EMS, subject to the resolution of claims
 that the Company may make against the funds with respect to
 indemnification and other claims, within 24 months from the closing
 date of the transaction.

[0001193125-16-764312:notes:130]
The Company has concluded it is the accounting acquirer for in the
 transaction and accounted for the acquisition under the provisions
 of business combinations accounting, in accordance with Accounting
 Standards Codification Topic 805 – Business Combinations.
 Accordingly, the estimated fair value of the acquisition
 consideration was allocated to the assets acquired and the
 liabilities assumed based on their respective fair values on the
 acquisition date. The Company has made certain estimates and
 assumptions in determining the allocation of the acquisition
 consideration.

[0001193125-16-764312:notes:131]
The total consideration and the allocation of consideration to the
 individual Exception EMS net assets is preliminary, as there are
 remaining uncertainties to be resolved, including the settlement of
 the final net working capital adjustment and the finalization of
 the estimated fair value attributable to the acquired intangible
 assets. As the functional currency of Exception EMS is Pound
 sterling, as of September 30, 2016, the Company recognized $0.7
 million of foreign exchange currency translation adjustment in its
 unaudited condensed consolidated statements of operations and
 comprehensive income.

[0001193125-16-764312:notes:132]
The Company’s preliminary allocation of the total purchase
 price for the acquisition is summarized below:

[0001193125-16-764312:notes:133]
| (amount in thousands) |  | Purchase price allocation |  |
| Cash |  | $ | 474 |  |
| Accounts receivable |  |  | 4,698 |  |
| Inventory |  |  | 2,633 |  |
| Other current assets |  |  | 425 |  |
| Property, plant and equipment |  |  | 5,660 |  |
| Intangibles |  |  | 4,472 |  |
| Goodwill |  |  | 2,994 |  |
| Other non-current assets |  |  | 509 |  |
| Current liabilities |  |  | (6,792 | ) |
| Other non-current liabilities |  |  | (1,556 | ) |
| Total fair value of assets acquired and liabilities assumed |  | $ | 13,517 |  |
| Total purchase price, net of cash acquired |  | $ | 13,043 |  |

[0001193125-16-764312:notes:134]
In connection with the Company’s acquisition of Exception
 EMS, the Company assumed lease agreements for certain machine and
 equipment, which are accounted for as capital leases. As of
 September 30, 2016, the Company included approximately
 $2.2 million of capital lease assets and $1.7 million of
 capital lease liability in the unaudited condensed consolidated
 balance sheets associated with these acquired lease agreements.

[0001193125-16-764312:notes:135]
During the three months ended September 30, 2016,
 the Company incurred approximately $1.1 million, in
 transaction costs related to the acquisition, which primarily
 consisted of legal, accounting and valuation-related expenses.
 These expenses were recorded in selling, general and administrative
 expense in the accompanying unaudited condensed consolidated
 statements of operations and comprehensive income.

[0001193125-16-764312:notes:136]
Pro forma results of operations for the acquisition have not been
 presented as they were not material to the Company’s results
 of operations.

[0001193125-16-764312:notes:137]
Identifiable intangibles

[0001193125-16-764312:notes:138]
The acquired intangible assets include customer relationships and
 backlog. The fair value of the identified intangible assets was
 determined based on the multi-period excess earnings method.

[0001193125-16-764312:notes:139]
Customer relationships represent the fair value of future projected
 revenues that was derived from the sale of products to existing
 customers of the acquired company. The fair value $4.4 million of
 customer relationships will be amortized over the respective
 estimated remaining useful life of ten years.

[0001193125-16-764312:notes:140]
Backlog represents the fair value of sales orders backlog as of the
 valuation date. The fair value $0.1 million of backlog will be
 amortized over the respective estimated remaining useful life of
 three years.

[0001193125-16-764312:notes:141]
Goodwill arising from the acquisition is primarily attributable to
 the ability to expand future products and services and the
 assembled workforce. Goodwill is not deductible for tax
 purposes.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-16-764312:notes:142]
| 15. | Accumulated other comprehensive income |


## us-gaap:DebtDisclosureTextBlock

[0001193125-16-764312:notes:143]
| 11. | Borrowings |

[0001193125-16-764312:notes:144]
Under the long-term borrowing contract of a subsidiary, the loan is
 secured by certain property, plant and equipment of the subsidiary.
 The carrying amount of assets secured and pledged as collateral to
 such loan as of September 30, 2016 and June 24, 2016 was $47.0
 million and $47.7 million, respectively. This subsidiary is also
 required to comply with maximum ratios of debt to equity and
 minimum levels of debt service coverage ratios, and Fabrinet must
 maintain an effective shareholding ratio. The carrying amounts of
 bank borrowings approximate their fair value.

[0001193125-16-764312:notes:145]
As of September 30, 2016 and June 24, 2016, the Company was in
 compliance with its bank borrowing agreements. In addition to
 financial ratios, certain of the Company’s credit facilities
 include customary events of default.

[0001193125-16-764312:notes:146]
Credit facilities:

[0001193125-16-764312:notes:147]
Fabrinet entered into a syndicated senior credit facility agreement
 (the “Facility Agreement”) with a consortium of banks
 on May 22, 2014. The Facility Agreement, led by Bank of America,
 provides for a $200.0 million credit line, comprised of a $150.0
 million revolving loan facility and a $50.0 million delayed draw
 term loan facility. The revolving loan facility contains an
 accordion feature permitting Fabrinet to request an increase in the
 facility up to $100.0 million subject to customary terms and
 conditions and provided that no default or event of default exists
 at the time of request. The revolving loan facility terminates and
 all amounts outstanding are due and payable in full on May 22,
 2019. The principal amount of any drawn term loans must be repaid
 according to scheduled quarterly amortization payments, with final
 payment of all amounts outstanding, plus accrued interest, being
 due May 22, 2019.

[0001193125-16-764312:notes:148]
On February 26, 2015, the Company entered into the Second Amendment
 to the Facility Agreement. The amendment extended the availability
 period for draws on the term loan facility from May 21, 2015 to
 July 31, 2015. It also allowed the Company, upon the satisfaction
 of certain conditions, to designate from time to time one or more
 of its subsidiaries as borrowers under the Facility Agreement. On
 July 31, 2015, the Company entered into the Third Amendment to the
 Facility Agreement. The amendment extended the availability period
 for draws on the term loan facility from July 31, 2015 to July 31,
 2016. As of September 30, 2016, there were $20.0 million of the
 revolving borrowing and $46.6 million of the term loan borrowing
 outstanding under the Facility Agreement, resulting in available
 credit facilities of $133.4 million. Borrowings under the revolving
 credit facility are classified as current liabilities in the
 unaudited condensed consolidated balance sheets as the Company has
 the periodic option to renew or pay, all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. During October 2016, the
 Company sent notices to the bank to renew the maturity date of its
 revolving borrowings. The bank approved the notices and extended
 the maturity to November 2016.

[0001193125-16-764312:notes:149]
Loans under the Facility Agreement bear interest, at
 Fabrinet’s option, at a rate per annum equal to a LIBOR rate
 plus a spread of 1.75% to 2.50%, or a base rate plus a spread of
 0.75% to 1.50%, determined in accordance with the Facility
 Agreement in each case with such spread determined based on
 Fabrinet’s consolidated total leverage ratio for the
 preceding four fiscal quarter period. Interest is due and payable
 quarterly in arrears for loans bearing interest at the base rate
 and at the end of an interest period (or at each three-month
 interval in the case of loans with interest periods greater than
 three months) in the case of loans bearing interest at the LIBOR
 rate.

[0001193125-16-764312:notes:150]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or the
 equivalent under the local law, can be effected.

[0001193125-16-764312:notes:151]
The Facility Agreement contains customary affirmative and negative
 covenants. Negative covenants include, among other things,
 limitations on liens, indebtedness, investments, mergers, sales of
 assets, changes in the nature of the business, dividends and
 distributions, affiliate transactions and capital expenditures. The
 Facility Agreement contains financial covenants requiring Fabrinet
 to maintain: (1) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (2) a minimum debt service coverage ratio of not
 less than 1.50:1.00; (3) a maximum senior leverage ratio of not
 more than 2.50:1.00; and (4) a minimum quick ratio of not less than
 1.10:1.00. Each of these financial covenants is calculated on a
 consolidated basis for the consecutive four fiscal quarter period
 then ended. As of September 30, 2016, the Company was in compliance
 with all covenants under the Facility Agreement.

[0001193125-16-764312:notes:152]
The Facility Agreement also contains customary events of default
 including, among other things, payment defaults, breaches of
 covenants or representations and warranties, cross-defaults with
 certain other indebtedness, bankruptcy and insolvency events and
 change in control of Fabrinet, subject to grace periods in certain
 instances. Upon an event of default, the lenders may terminate
 their commitments, declare all or a portion of the outstanding
 obligations payable by Fabrinet to be immediately due and payable
 and exercise other rights and remedies provided for under the
 Facility Agreement.

[0001193125-16-764312:notes:153]
Fabrinet intends to use the proceeds of the credit line to finance
 its future manufacturing buildings in the United States and
 Thailand, and for general corporate purposes including mergers and
 acquisitions of complementary manufacturing businesses or
 technology, although Fabrinet has no current commitments with
 respect to any such acquisitions.

[0001193125-16-764312:notes:154]
Short-term loans from bank

[0001193125-16-764312:notes:155]
In connection with the business acquisition, the Company assumed a
 secured borrowing agreement. The loans are secured by trade
 accounts receivable and the way of chattels mortgage over the plant
 and machine of Exception EMS. As of September 30, 2016, the
 carrying amount of trade accounts receivable and plant and machine
 secured to such loans were $5.5 million and $4.9 million,
 respectively The secured borrowing agreement contains certain
 covenants that the Company is required to comply with: (1) the
 value of credit notes may not exceed 4% of the value of assigned
 debts measured on a monthly basis, and (2) rolling cash flow must
 be provided with monthly management information. As of September
 30, 2016, the Company was in compliance with all covenants under
 the secured borrowing agreement.

[0001193125-16-764312:notes:156]
As of September 30, 2016, the Company drew down from this facility
 of $1.2 million which is recorded as short-term loans in the
 unaudited condensed consolidated balance sheets. The agreement
 bears interest for discount charge at 1.85% per annum above based
 rate.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-16-764312:notes:157]
| 9. | Intangibles |

[0001193125-16-764312:notes:158]
[same as prior period, unchanged from 0001193125-16-574999:notes:2]

[0001193125-16-764312:notes:159]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net |  |
| As of September 30, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 3,915 |  |  | $ | (3,296 | ) |  | $ | 619 |  |
| Customer relationships |  |  | 4,372 |  |  |  | — |  |  |  | 4,372 |  |
| Backlog |  |  | 100 |  |  |  | — |  |  |  | 100 |  |
| Total intangibles |  | $ | 8,387 |  |  | $ | (3,296 | ) |  | $ | 5,091 |  |
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net |  |
| As of June 24, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 3,786 |  |  | $ | (3,287 | ) |  | $ | 499 |  |
| Customer relationships |  |  | — |  |  |  | — |  |  |  | — |  |
| Backlog |  |  | — |  |  |  | — |  |  |  | — |  |
| Total intangibles |  | $ | 3,786 |  |  | $ | (3,287 | ) |  | $ | 499 |  |

[0001193125-16-764312:notes:160]
In connection with the acquisition of Exception EMS, the Company
 recorded $4.4 million of customer relationships and $0.1 million of
 backlog with the weighted-average life of 7.6 years and 2.3 years,
 respectively.

[0001193125-16-764312:notes:161]
The Company recorded amortization expense relating to intangibles
 of $0.03 million and $0.01 million for the three months ended
 September 30, 2016 and September 25, 2015, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-16-764312:notes:162]
| 14. | Shareholders’ equity |

[0001193125-16-764312:notes:163]
[same as prior period, unchanged from 0001193125-16-574999:notes:145]

[0001193125-16-764312:notes:164]
[same as prior period, unchanged from 0001193125-16-574999:notes:146]

[0001193125-16-764312:notes:165]
For the three months ended September 30, 2016, Fabrinet issued
 158,317 ordinary shares upon the exercise of options, for cash
 consideration at a weighted-average exercise price of $17.10 per
 share, and 385,705 ordinary shares upon the vesting of restricted
 share units, net of shares withheld.

[0001193125-16-764312:notes:166]
[same as prior period, unchanged from 0001193125-16-574999:notes:149]


## us-gaap:EarningsPerShareTextBlock

[0001193125-16-764312:notes:167]
[same as prior period, unchanged from 0001193125-16-574999:notes:120]

[0001193125-16-764312:notes:168]
Basic earnings per ordinary share is computed by dividing reported
 net income by the weighted-average number of ordinary shares
 outstanding during each period. Diluted earnings per ordinary share
 is computed by calculating the effect of potential dilutive
 ordinary shares outstanding during the period using the treasury
 stock method. Dilutive ordinary equivalent shares consist of share
 options, restricted share units and performance share units.
 Earnings per ordinary share was calculated as follows:

[0001193125-16-764312:notes:169]
|  |  | Three Months Ended |  |
| (amount in thousands except per share amounts) |  | September 30, 2016 |  |  | September 25, 2015 |  |
| Net income attributable to shareholders |  | $ | 22,766 |  |  | $ | 1,603 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  | 36,404 |  |  |  | 35,579 |  |
| Incremental shares arising from the assumed exercise of share options and vesting of restricted share units (thousands of shares) |  |  | 926 |  |  |  | 736 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 37,330 |  |  |  | 36,315 |  |
| Basic earnings per ordinary share |  | $ | 0.63 |  |  | $ | 0.05 |  |
| Diluted earnings per ordinary share |  | $ | 0.61 |  |  | $ | 0.04 |  |
| Outstanding share options excluded in the computation of diluted earnings per ordinary share (1) |  |  | — |  |  |  | 62,304 |  |

[0001193125-16-764312:notes:170]
| (1) | These share options were not included in the computation of diluted earnings per ordinary share because the exercise price of the options was greater than the average market price of the underlying shares. |


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001193125-16-764312:notes:171]
The following table provides details of the financial instruments
 measured at fair value on a recurring basis, including:

[0001193125-16-764312:notes:172]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of September 30, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 185 |  |  | $ | — |  |  | $ | 185 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 117,161 |  |  |  | — |  |  |  | 117,161 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 29,388 |  |  |  | — |  |  |  | 29,388 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 1,153 |  |  |  | — |  |  |  | 1,153 |  |
| Total |  | $ | — |  |  | $ | 147,887 |  |  | $ | — |  |  | $ | 147,887 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 49 | (1) |  | $ | — |  |  | $ | 49 |  |
| Total |  | $ | — |  |  | $ | 49 |  |  | $ | — |  |  | $ | 49 |  |

[0001193125-16-764312:notes:173]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 24, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 6,050 |  |  | $ | — |  |  | $ | 6,050 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 112,522 |  |  |  | — |  |  |  | 112,522 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 28,030 |  |  |  | — |  |  |  | 28,030 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 1,157 |  |  |  | — |  |  |  | 1,157 |  |
| Derivative assets |  |  | — |  |  |  | 158 | (2) |  |  | — |  |  |  | 158 |  |
| Total |  | $ | — |  |  | $ | 147,917 |  |  | $ | — |  |  | $ | 147,917 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 1,754 | (3) |  | $ | — |  |  | $ | 1,754 |  |
| Total |  | $ | — |  |  | $ | 1,754 |  |  | $ | — |  |  | $ | 1,754 |  |

[0001193125-16-764312:notes:174]
| (1) | Foreign currency forward contracts with notional amount of $42.5 million and Canadian dollars 0.4 million. |

[0001193125-16-764312:notes:175]
| (2) | Foreign currency forward contracts with notional amount of $7.0 million. |

[0001193125-16-764312:notes:176]
| (3) | Foreign currency forward contracts with notional amount of $77.5 million and Canadian dollars 0.6 million. |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-16-764312:notes:177]
[same as prior period, unchanged from 0001193125-16-574999:notes:71]

[0001193125-16-764312:notes:178]
[same as prior period, unchanged from 0001193125-16-574999:notes:72]

[0001193125-16-764312:notes:179]
[same as prior period, unchanged from 0001193125-16-574999:notes:73]

[0001193125-16-764312:notes:180]
[same as prior period, unchanged from 0001193125-16-574999:notes:74]

[0001193125-16-764312:notes:181]
[same as prior period, unchanged from 0001193125-16-574999:notes:75]

[0001193125-16-764312:notes:182]
[same as prior period, unchanged from 0001193125-16-574999:notes:76]

[0001193125-16-764312:notes:183]
[same as prior period, unchanged from 0001193125-16-574999:notes:83]

[0001193125-16-764312:notes:184]
As a result of foreign currency rate fluctuations, the U.S. dollar
 equivalent values of the Company’s foreign currency
 denominated assets and liabilities change. The Company uses foreign
 currency contracts to manage the foreign exchange risk associated
 with certain foreign currency denominated assets and liabilities
 and other foreign currency transactions. The Company minimizes the
 credit risk in derivative instruments by limiting its exposure to
 any single counterparty and by entering into derivative instruments
 only with counterparties that meet the Company’s minimum
 credit quality standard. As of September 30, 2016, the Company
 recognized the fair value of foreign currency forward contracts of
 $0.05 million as derivative liabilities in the unaudited condensed
 consolidated balance sheet. As of June 24, 2016, the Company
 recognized the fair value of foreign currency forward contracts of
 $0.2 million as derivative assets and $1.7 million as derivative
 liabilities in the unaudited condensed consolidated balance
 sheets.

[0001193125-16-764312:notes:185]
As of September 30, 2016, the Company had no foreign currency
 forward contract, designated as cash flow hedges. During the three
 months ended September 30, 2016, the Company discontinued cash flow
 hedges and recognized a gain from unwinding these forward contracts
 of $0.3 million in the unaudited condensed consolidated statements
 of operations and comprehensive income. A gain of $0.01 million in
 AOCI for the three months ended September 30, 2016 is expected to
 be reclassified into the earnings within the next 12 months.

[0001193125-16-764312:notes:186]
As of September 30, 2016, the Company had nine outstanding foreign
 currency forward contracts with notional amount of $42.5 million
 and Canadian dollars 0.4 million, maturing during October to
 December 2016. These foreign currency forward contracts were not
 designated for hedge accounting and were used to hedge fluctuations
 in the U.S. dollar value of forecasted transactions denominated in
 Thai baht and Canadian dollar. During the three months ended
 September 30, 2016, the Company included unrealized loss of
 $0.05 million from changes in the fair value of foreign currency
 contracts in earnings in the unaudited condensed consolidated
 statements of operations and comprehensive income.

[0001193125-16-764312:notes:187]
As of September 25, 2015, the Company had 42 outstanding foreign
 currency options with notional amount of $11.0 million and forward
 contracts with notional amount of $169.5 million, Canadian dollars
 1.0 million and Japanese yen of 0.1 million, maturing during
 September 2015 to December 2016. These foreign currency forward
 contracts and options were not designated for hedge accounting and
 were used to hedge fluctuations in the U.S. dollar value of
 forecasted transactions denominated in Thai baht and Canadian
 dollar. During the three months ended September 25, 2015, the
 Company included unrealized gain of $12.1 million from changes in
 the fair value of foreign currency contracts in earnings in the
 unaudited condensed consolidated statements of operations and
 comprehensive income.


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-16-764312:notes:188]
| 10. | Goodwill |

[0001193125-16-764312:notes:189]
In connection with the acquisition of Exception EMS, the Company
 recorded $3.0 million of goodwill in the unaudited condensed
 consolidated balance sheets.

[0001193125-16-764312:notes:190]
Goodwill is not deductible for tax purposes. Goodwill will not be
 amortized but is reviewed annually for impairment or more
 frequently whenever changes or circumstances indicate the carrying
 amount of goodwill may not be recoverable.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-16-764312:notes:191]
| 17. | Business segments and geographic information |

[0001193125-16-764312:notes:192]
Operating segments are defined as components of an enterprise for
 which separate financial information is available that is evaluated
 regularly by the chief operating decision maker in deciding how to
 allocate resources and in assessing performance. The
 Company’s chief operating decision maker is Fabrinet’s
 chief executive officer. As of September 30, 2016, the Company
 operated and internally managed a single operating segment.
 Accordingly, the Company does not accumulate discrete information
 with respect to separate product lines and does not have separate
 reportable segments.

[0001193125-16-764312:notes:193]
[same as prior period, unchanged from 0001193125-16-574999:notes:62]

[0001193125-16-764312:notes:194]
As of September 30, 2016 and September 25, 2015, the Company had
 approximately $36.4 million and $33.9 million of long-lived assets
 based in North America, with the substantial remainder of assets
 based in Asia-Pacific and Europe.

[0001193125-16-764312:notes:195]
[same as prior period, unchanged from 0001193125-16-574999:notes:64]

[0001193125-16-764312:notes:196]
The Company had one and two customers that each contributed to 10%
 or more of its total account receivable as of September 30,
 2016 and June 24, 2016, respectively.


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001193125-16-764312:notes:197]
| 18. | Other expense related to flooding |

[0001193125-16-764312:notes:198]
During the week of August 10, 2015, the Company’s subsidiary
 in China temporarily suspended production in its manufacturing
 facility due to flooding caused by Typhoon Soudelor and resumed
 operations on August 15, 2015. During the three months ended
 September 25, 2015, the Company recognized $0.9 million of losses
 incurred from the event in the unaudited condensed consolidated
 statements of operations and comprehensive income. The Company
 received a final payment of $0.8 million from an insurer against
 the Company’s claim for flood damage during the three months
 ended March 25, 2016.
