# FN 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001193125-15-296113:item_9a:1]
| ITEM 9A. | CONTROLS AND PROCEDURES. |

[0001193125-15-296113:item_9a:2]
Evaluation
of Disclosure Controls and Procedures

[0001193125-15-296113:item_9a:3]
Our management is responsible for establishing and maintaining disclosure controls
and procedures designed to ensure that the information we are required to disclose in reports we file or submit under the Securities Exchange Act of 1934, as amended (“Exchange Act”), (i) is recorded, processed, summarized, and
reported within time periods specified in the rules and forms of the Securities and Exchange Commission, and (ii) is accumulated and communicated to Fabrinet’s management, including our Chief Executive Officer (“CEO”) and Chief
Financial Officer (“CFO”), as appropriate, to allow timely decisions regarding required disclosure.

[0001193125-15-296113:item_9a:4]
Our management,
including our CEO and CFO, evaluated the effectiveness of our disclosure controls and procedures (as defined in Rule 13a-15(e) of the Exchange Act), as of the end of the period covered by this Annual Report on Form 10-K. Based on their evaluation,
our management concluded that, as of June 26, 2015, the Company’s disclosure controls and procedures were effective.

[0001193125-15-296113:item_9a:5]
Changes in
Internal Control over Financial Reporting

[0001193125-15-296113:item_9a:6]
We have implemented policies and procedures with respect to significant customer
contracts review and designed and implemented a new training program and a series of follow-up training programs concerning revenue recognition under U.S. GAAP that included engaging an external technical accounting consultant with extensive U.S.
GAAP experiences to conduct a comprehensive review of significant customer contracts on a regular basis. These changes have materially affected, or are reasonably likely to materially affect, our internal

[0001193125-15-296113:item_9a:7]
94

[0001193125-15-296113:item_9a:8]
control over financial reporting for the quarter and year ended June 26, 2015. As part of our ongoing process improvement and compliance efforts, we have performed testing procedures on the
Company’s internal controls implemented during fiscal year 2015.

[0001193125-15-296113:item_9a:9]
Management’s Annual Report on Internal Control over Financial
Reporting

[0001193125-15-296113:item_9a:10]
Management is responsible for establishing and maintaining adequate internal control over financial reporting of
the Company as defined in Rule 13a-15(f) under the Exchange Act. Internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial
statements for external purposes in accordance with generally accepted accounting principles (“GAAP”).

[0001193125-15-296113:item_9a:11]
Our internal
control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately, and fairly reflect the transactions and dispositions of the assets of the Company;
(ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the Company are being
made only in accordance with authorizations of management and directors of the Company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the Company’s
assets that could have a material effect on the financial statements.

[0001193125-15-296113:item_9a:12]
Because of its inherent limitations, internal control
over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree
of compliance with the policies or procedures may deteriorate. Management has assessed the effectiveness of our internal control over financial reporting as of June 26, 2015. In making this assessment, management used the criteria described in
Internal Control—Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001193125-15-296113:item_9a:13]
Based on their assessment, management concluded that we maintained effective internal control over financial reporting at June 26, 2015, based on the criteria in Internal Control—Integrated
Framework issued by COSO. The effectiveness of our internal control over financial reporting as of June 26, 2015 has been audited by PricewaterhouseCoopers ABAS Ltd., an independent registered public accounting firm, as stated in their report
which appears herein.

[0001193125-15-296113:item_9a:14]
Remediation of Prior Year Material Weakness

[0001193125-15-296113:item_9a:15]
As disclosed in our Item 9A of the Annual Report on Form 10-K for the fiscal year ended June 27, 2014, we identified a material
weakness in our internal control over financial reporting such that our disclosure controls and procedures and internal control over financial reporting were not effective. The material weakness related to us not appling appropriate U.S. GAAP
knowledge and expertise when assessing the terms of volume supply arrangements with respect to when the title and risk of loss transfers to our customers.

[0001193125-15-296113:item_9a:16]
Throughout fiscal year 2015, our management, under the supervision of our CEO and CFO, undertook the following actions intended to remedy this material weakness, and to improve our control processes and
procedures with respect to revenue recognition:

[0001193125-15-296113:item_9a:17]
|  | • |  | We conducted mandatory revenue recognition training for our management staff using third-party accounting experts. Management staff also attended follow-up training held by technical accounting specialists from large accounting firms and other professional organizations to maintain up-to-date knowledge on U.S. GAAP accounting principles with respect to the application of our policies concerning revenue recognition. |

[0001193125-15-296113:item_9a:18]
95

[0001193125-15-296113:item_9a:19]
|  | • |  | We implemented procedures to ensure that significant customer contracts, both those in effect at the commencement of the fiscal year and those entered into during the year, are subject to a comprehensive review by appropriate management staff to ensure that the financial accounting for such contracts is in compliance with U.S. GAAP and that the contracts properly reflect our current business practices. |

[0001193125-15-296113:item_9a:20]
|  | • |  | In addition, we engaged an external technical accounting consultant with extensive U.S. GAAP experience to conduct a comprehensive review of all contracts discussed above to ensure the correct application of U.S. GAAP standards and principles related to relevant technical accounting topics, especially for the revenue recognition and cut-off criteria. |

[0001193125-15-296113:item_9a:21]
Management has committed to maintaining a strong internal control environment and believes that these remediation efforts represent
significant improvements in our controls and would have remediated the material weaknesses found in fiscal year 2014.

[0001193125-15-296113:item_9a:22]
Management evaluated the operating effectiveness of the remediation procedures throughout the fiscal year 2015. As of June 26, 2015,
the controls and procedures implemented have been tested and determined to be operating effectively, to allow management to conclude that the material weakness has been remediated.
