# FN note change history — 0001193125-15-031475 → 0001193125-15-172043


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-05-05):
[0001193125-15-172043:note_history:1]
As of March 27, 2015 and June 27, 2014, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $0.8 million and $0.3 million, respectively.
  (was, 2015-02-03, similarity 0.97):
[0001193125-15-031475:note_history:1]
As of December 26, 2014 and June 27, 2014, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $0.8 million and $0.3 million, respectively.

- added (2015-05-05):
[0001193125-15-172043:note_history:2]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in Cayman Islands,
 China, and New Jersey under operating lease arrangements that
 expire in various calendar years through 2020. Rental expense under
 these operating leases amounted to $0.8 million and $0.7 million
 for the nine months ended March 27, 2015 and March 28,
 2014, respectively.

- changed (2015-05-05):
[0001193125-15-172043:note_history:3]
As of March 27, 2015, the future minimum lease payments due
 under non-cancelable leases were as follows at the end of each
 fiscal year below:
  (was, 2015-02-03, similarity 0.9559):
[0001193125-15-031475:note_history:3]
As of December 26, 2014, the future minimum lease payments due
 under non-cancelable leases are as follows at the end of each
 fiscal year below:

- changed (2015-05-05):
[0001193125-15-172043:note_history:4]
As of March 27, 2015, the Company had an outstanding
 commitment to third parties of $2.5 million.
  (was, 2015-02-03, similarity 0.9503):
[0001193125-15-031475:note_history:4]
As of December 26, 2014, the Company had an outstanding
 commitment to third parties of $5.9 million.

- removed (2015-05-05):
[0001193125-15-031475:note_history:5]
The Company leases a portion of its capital equipment and certain
 land and buildings for its facilities in China and New Jersey under
 operating lease arrangements that expire in various calendar years
 through 2020. Rental expense under these operating leases amounted
 to $0.5 million and $0.4 million for the six months ended
 December 26, 2014 and December 27, 2013,
 respectively.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2015-05-05):
[0001193125-15-172043:note_history:6]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of March 27, 2015 and for the three
 and nine months ended March 27, 2015 and March 28, 2014
 includes only normal recurring adjustments, necessary for a fair
 statement of the financial statements set forth herein, in
 accordance with accounting principles generally accepted in the
 United States of America (“U.S. GAAP”) for interim
 financial information and rules and regulations of the Securities
 and Exchange Commission (“SEC”). Accordingly, such
 information does not include all of the information and footnotes
 required by U.S. GAAP for annual financial statements. For further
 information, please refer to the consolidated financial statements
 and footnotes thereto included in the Company’s Annual Report
 on Form 10-K for the year ended June 27, 2014.

- added (2015-05-05):
[0001193125-15-172043:note_history:7]
The balance sheet as of June 27, 2014 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three and nine
 months ended March 27, 2015 and March 28, 2014 may not be
 indicative of results for the year ending June 26, 2015 or any
 future periods.

- added (2015-05-05):
[0001193125-15-172043:note_history:8]
Use of Estimates

- changed (2015-05-05):
[0001193125-15-172043:note_history:9]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended
 March 27, 2015 and March 28, 2014 each consisted of 13
 weeks. The nine months ended March 27, 2015 and March 28,
 2014 each consisted of 39 weeks. Fiscal year 2015 will be comprised
 of 52 weeks and will end on June 26, 2015.
  (was, 2015-02-03, similarity 0.8019):
[0001193125-15-031475:note_history:9]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended
 December 26, 2014 and December 27, 2013 each consisted of
 13 weeks. The six months ended December 26, 2014 and
 December 27, 2013 each consisted of 26 weeks. Fiscal year 2015
 will be comprised of 52 weeks and will end on June 26,
 2015.

- changed (2015-05-05):
[0001193125-15-172043:note_history:10]
Financial instruments that potentially subject the Company to
 concentrations of credit risk consist of cash and cash equivalents,
 marketable securities, derivatives, and accounts receivable.
  (was, 2015-02-03, similarity 0.9974):
[0001193125-15-031475:note_history:10]
Financial instruments that potentially subject the Company to
 concentrations of credit risk consist of cash and cash equivalents,
 marketable securities, derivatives and accounts receivable.

- changed (2015-05-05):
[0001193125-15-172043:note_history:11]
Cash, cash equivalents, and marketable securities are maintained
 with several financial institutions. Deposits held with banks may
 exceed the amount of insurance provided on such deposits.
 Generally, these deposits may be redeemed upon demand and are
 maintained with financial institutions with reputable credit and
 therefore bear minimal credit risk. The Company seeks to mitigate
 its credit risks by spreading such risks across multiple
 counterparties and monitoring the risk profiles of these
 counterparties. The Company limits its investments in marketable
 securities to securities with a maturity not in excess of three
 years, and all marketable securities that the Company invests in
 are rated A1, P-1, F1, or better.
  (was, 2015-02-03, similarity 0.9993):
[0001193125-15-031475:note_history:11]
Cash, cash equivalents and marketable securities are maintained
 with several financial institutions. Deposits held with banks may
 exceed the amount of insurance provided on such deposits.
 Generally, these deposits may be redeemed upon demand and are
 maintained with financial institutions with reputable credit and
 therefore bear minimal credit risk. The Company seeks to mitigate
 its credit risks by spreading such risks across multiple
 counterparties and monitoring the risk profiles of these
 counterparties. The Company limits its investments in marketable
 securities to securities with a maturity not in excess of three
 years, and all marketable securities that the Company invests in
 are rated A1, P-1, F1, or better.

- added (2015-05-05):
[0001193125-15-172043:note_history:12]
Certain customers may request the Company to store finished
 products purchased by them at the Company’s warehouse. In
 these instances, the Company receives a written request from the
 customer asking the Company to hold the inventory at the
 Company’s warehouse and the ordered goods are segregated in
 the Company’s warehouse from other inventory and cannot be
 used to fulfil other customer orders. In these situations revenue
 is only recognized when persuasive evidence of the sales
 arrangement exists, the goods are completed and ready for shipment,
 pricing is fixed or determinable, collection is reasonable assured,
 and title and risk of loss have passed to the customer.

- added (2015-05-05):
[0001193125-15-172043:note_history:13]
In April 2015, the Financial Accounting Standards Board (FASB)
 issued Accounting Standards Update (ASU) 2015-03, “Interest -
 Imputation of Interest (Subtopic 835-30): Simplifying the
 Presentation of Debt Issuance Costs”. The update requires
 debt issuance costs related to a recognized debt liability be
 presented in the balance sheet as a direct deduction from the
 carrying amount of the related debt liability instead of being
 presented as an asset. Debt disclosures will include the face
 amount of the debt liability and the effective interest rate. The
 update requires retrospective application and represents a change
 in accounting principle. The update is effective for fiscal years
 beginning after December 15, 2015. Early adoption is permitted
 for financial statements that have not been previously issued. The
 Company is currently evaluating the impact of adoption of this
 update on its consolidated financial statements.

- added (2015-05-05):
[0001193125-15-172043:note_history:14]
In February 2015, the FASB issued ASU 2015-02, “Consolidation
 (Topic 810): Amendments to the Consolidation Analysis”. ASU
 No. 2015-02 amended the process that a reporting entity must
 perform to determine whether it should consolidate certain types of
 legal entities. ASU No. 2015-02 is effective for fiscal years,
 and for interim periods within those fiscal years beginning after
 December 15, 2015. Early adoption is permitted, including
 adoption in an interim period. The Company is currently evaluating
 the impact of adoption of this update on its consolidated financial
 statements.

- added (2015-05-05):
[0001193125-15-172043:note_history:15]
In January 2015, the FASB issued ASU No. 2015-01,
 “Income Statement – Extraordinary and Unusual Items
 (Subtopic 225-20): Simplifying Income Statement Presentation by
 Eliminating the Concept of Extraordinary Items”. The
 objective of this amendment is to reduce the complexity in
 accounting standards by eliminating the concept of extraordinary
 items from U.S. GAAP. Presently, an event or transaction is
 presumed to be an ordinary and usual activity of the reporting
 entity unless evidence clearly supports its classification as an
 extraordinary item. The following criteria must both be met for
 extraordinary classification: (a) the underlying event or
 transaction should possess a high degree of abnormality and be of a
 type clearly unrelated to, or only incidentally related to, the
 ordinary and typical activities of the entity; and (b) the
 underlying event or transaction should not reasonably be expected
 to recur in the foreseeable future. This amendment is effective for
 fiscal years and interim periods beginning after December 15,
 2015. Early adoption is permitted provided that the guidance is
 applied from the beginning of the fiscal year of adoption. The
 Company does not expect that the adoption of this update will have
 an effect on its consolidated financial statements.

- removed (2015-05-05):
[0001193125-15-031475:note_history:16]
The condensed consolidated financial statements of Fabrinet
 included herein have been prepared on a basis consistent with the
 June 27, 2014 audited consolidated financial statements and
 include all material adjustments, consisting of normal recurring
 adjustments, necessary to fairly present the information set forth
 therein. These condensed consolidated financial statements should
 be read in conjunction with the June 27, 2014 audited
 consolidated financial statements and notes thereto. The year-end
 condensed balance sheet data was derived from audited financial
 statements but does not include all disclosures required by
 accounting principles generally accepted in the United States
 (“U.S. GAAP”).

- removed (2015-05-05):
[0001193125-15-031475:note_history:17]
Certain customers may request the Company to store finished
 products on their behalf. In these situations revenue is only
 recognized when the goods are completed
 and ready for shipment, and title and risk of loss have passed to
 the customer. The Company receives a written request from the
 customer asking the Company to hold the inventory at the Company
 warehouse, and the ordered goods are segregated in the Company
 warehouse from other inventory and cannot be used to fulfill other
 customer orders.

- removed (2015-05-05):
[0001193125-15-031475:note_history:18]
In January 2015, the Financial Accounting Standards Board (FASB)
 issued Accounting Standard Update (ASU) No. 2015-01,
 “Income Statement – Extraordinary and Unusual Items
 (Subtopic 225-20): Simplifying Income Statement presentation by
 Eliminating the Concept of Extraordinary Items”. The
 objective of this amendments are to reduce the complexity of
 extraordinary items concept by the concept of extraordinary items,
 subtopic 225-20. Presently, an event or transaction is presumed to
 be an ordinary and usual activity of the reporting entity unless
 evidence clearly supports its classification as an extraordinary
 item. The criteria that must both be met for extraordinary
 classification: (a) unusual nature with high degree of
 abnormality and be of a type clearly unrelated to, or only
 incidentally related to the ordinary and typical activities of the
 entity; and (b) infrequency of occurrence of the event which
 should not reasonably be expected to recur in the foreseeable
 future. This amendments are effective for fiscal years and interim
 periods beginning after December 15, 2015. Early adoption is
 permitted provided that the guidance is applied from the beginning
 of the fiscal year of adoption. The Company does not expect that
 the adoption of this update will have an effect on its consolidated
 financial statements.

- removed (2015-05-05):
[0001193125-15-031475:note_history:19]
Recently Adopted Accounting Pronouncements

- removed (2015-05-05):
[0001193125-15-031475:note_history:20]
In July 2013, the FASB issued ASU No. 2013-11, “Income
 Taxes (Topic 740): Presentation of an Unrecognized Tax Benefit When
 a Net Operating Loss Carryforward, a Similar Tax Loss, or a Tax
 Credit Carryforward Exists”. This ASU provides guidance for
 netting of unrecognized tax benefits (UTBs) against a deferred tax
 asset for a loss or other carryforward that would apply in
 settlement of the uncertain tax positions. Under this new guidance,
 UTBs will be netted against all available same-jurisdiction loss or
 other tax carryforwards that would be utilized, rather than only
 against carryforwards that are created by the UTBs. This guidance
 is effective for fiscal years, and interim periods within those
 years, beginning after December 15, 2013. The Company adopted
 this ASU in the first quarter of fiscal year 2015. Adoption of this
 guidance did not have a material impact on the Company’s
 unaudited condensed consolidated financial statements.

- removed (2015-05-05):
[0001193125-15-031475:note_history:21]
In April 2013, the FASB issued ASU No. 2013-07,
 “Presentation of Financial Statements (Topic 205):
 Liquidation Basis of Accounting”. The amendments require an
 entity to prepare its financial statements using the liquidation
 basis of accounting when liquidation is imminent. The amendments
 require financial statements prepared using the liquidation basis
 of accounting to present relevant information about an
 entity’s expected resources in liquidation by measuring and
 presenting assets at the amount of the expected cash proceeds from
 liquidation. This guidance is effective for entities that determine
 liquidation is imminent during annual reporting periods beginning
 after December 15, 2013 and interim reporting periods therein.
 The Company adopted this ASU in the first quarter of fiscal year
 2015. Adoption of this guidance did not have a material impact on
 the Company’s unaudited condensed consolidated financial
 statements.

- removed (2015-05-05):
[0001193125-15-031475:note_history:22]
In March 2013, the FASB issued ASU No. 2013-05, “Foreign
 Currency Matters (Topic 830): Parents’ Accounting for the
 Cumulative Translation Adjustment upon Derecognition of Certain
 Subsidiaries or Groups of Assets within a Foreign Entity or of an
 Investment in a Foreign Entity”. This ASU permits an entity
 to release cumulative translation adjustments into net income when
 a reporting entity (parent) ceases to have a controlling financial
 interest in a subsidiary or group of assets that is a business
 within a foreign entity. Accordingly, the cumulative translation
 adjustment should be released into net income only if the sale or
 transfer results in the complete or substantially complete
 liquidation of the foreign entity in which the subsidiary or group
 of assets had resided, or, if a controlling financial interest is
 no longer held. The guidance is effective for fiscal years
 beginning after December 15, 2013, with early adoption being
 permitted. The Company adopted this ASU in the first quarter of
 fiscal year 2015. Adoption of this guidance did not have a material
 impact on the Company’s unaudited condensed consolidated
 financial statements.

- removed (2015-05-05):
[0001193125-15-031475:note_history:23]
In February 2013, the FASB issued ASU No. 2013-04,
 “Liabilities (Topic 405): Obligations Resulting from
 Joint and Several Liability Arrangements for which the Total Amount
 of the Obligation is Fixed at the Reporting Date”. The
 guidance in this update requires an entity to measure obligations
 resulting from joint and several liability arrangements for which
 the total amount of the obligation within the scope of this
 guidance is fixed at the reporting date, as the sum of the
 following: (a) the amount the reporting entity agreed to pay
 on the basis of its arrangement among its co-obligors, and
 (b) any additional amount the reporting entity expects to pay
 on behalf of its co-obligors. The guidance also requires an entity
 to disclose the nature and amount of the obligation as well as
 other information about those obligations. This guidance is
 effective for fiscal years, and interim periods within those years,
 beginning after December 15, 2013. The Company adopted this
 ASU in the first quarter of fiscal year 2015. Adoption of this
 guidance did not have a material impact on the Company’s
 unaudited condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-05):
[0001193125-15-172043:note_history:24]
The Company’s total borrowing, including revolving and
 long-term borrowings, consisted of the following:
  (was, 2015-02-03, similarity 0.6509):
[0001193125-15-031475:note_history:24]
Bank borrowing and long-term debt was comprised of the
 following:

- added (2015-05-05):
[0001193125-15-172043:note_history:25]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  |  | As of March 27, 2015 |  |  | As of June 27, 2014 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  |  | April 2015 | (2) |  | $ | 30,000 |  |  | $ | — |  |
| Current portion of long-term borrowing |  |  |  | 6,000 |  |  |  | 6,000 |  |
|  |  |  | $ | 36,000 |  |  | $ | 6,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  |  | March 2017 |  |  | $ | 12,000 |  |  | $ | 16,500 |  |
| Less: Current portion |  |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  | $ | 6,000 |  |  | $ | 10,500 |  |

- added (2015-05-05):
[0001193125-15-172043:note_history:26]
| (2) | On April 16, 2015, the Company sent a notice to the bank to renew the maturity date of this revolving borrowing. The bank approved the notice and extended the maturity date to May 18, 2015. |

- changed (2015-05-05):
[0001193125-15-172043:note_history:27]
On April 25, 2014, a subsidiary entered into an amendment to
 the bank borrowing agreement. Under the amendment of the contract,
 the long-term loan is secured by certain property, plant and
 equipment. The carrying amount of assets secured and pledged as
 collateral as of March 27, 2015 and June 27, 2014 was
 $50.6 million and $52.3 million, respectively. This subsidiary is
 also required to comply with the maximum ratios of debt to equity
 and minimum levels of debt service coverage ratios, and Fabrinet
 must maintain an effective shareholding ratio. The carrying amounts
 of bank borrowings approximate their fair value.
  (was, 2015-02-03, similarity 0.9423):
[0001193125-15-031475:note_history:27]
On April 25, 2014, a subsidiary entered into an amendment to
 the bank borrowing agreement. Under the amendment of the contract,
 the long-term loan is secured by certain property, plant and
 equipment. The carrying amount of assets secured and pledged as
 collateral as of December 26, 2014 and June 27, 2014 was
 $51.1 million and $52.3 million, respectively. This
 subsidiary is also required to comply with the maximum ratios of
 debt to equity and minimum levels of debt service coverage ratios
 and Fabrinet must maintain effective shareholding ratio. The
 carrying amounts of bank borrowings approximate their fair
 value.

- changed (2015-05-05):
[0001193125-15-172043:note_history:28]
As of March 27, 2015 and June 27, 2014, the Company was
 in compliance with its long-term bank borrowing agreement. In
 addition to financial ratios, certain of the Company’s credit
 facilities include customary events of default.
  (was, 2015-02-03, similarity 0.9701):
[0001193125-15-031475:note_history:28]
As of December 26, 2014 and June 27, 2014, the Company
 was in compliance with its long-term bank borrowing agreement. In
 addition to financial ratios, certain of the Company’s credit
 facilities include customary events of default.

- changed (2015-05-05):
[0001193125-15-172043:note_history:29]
The movements of long-term loans were as follows for the nine
 months ended March 27, 2015 and March 28, 2014:
  (was, 2015-02-03, similarity 0.8867):
[0001193125-15-031475:note_history:29]
The movements of long-term loans were as follows for the six months
 ended December 26, 2014 and December 27, 2013:

- changed (2015-05-05):
[0001193125-15-172043:note_history:30]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27, 2015 |  |  | March 28, 2014 |  |
| Opening net book amount |  | $ | 16,500 |  |  | $ | 28,911 |  |
| Repayment during the period |  |  | (4,500 | ) |  |  | (7,251 | ) |
| Closing net book amount |  | $ | 12,000 |  |  | $ | 21,660 |  |
  (was, 2015-02-03, similarity 0.8978):
[0001193125-15-031475:note_history:30]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 26, 2014 |  |  | December 27, 2013 |  |
| Opening net book amount |  | $ | 16,500 |  |  | $ | 28,911 |  |
| Repayment during the period |  |  | (3,000 | ) |  |  | (4,834 | ) |
| Closing net book amount |  | $ | 13,500 |  |  | $ | 24,077 |  |

- changed (2015-05-05):
[0001193125-15-172043:note_history:31]
As of March 27, 2015, future maturities of long-term debt were
 as follows at the end of each fiscal year below:
  (was, 2015-02-03, similarity 0.9577):
[0001193125-15-031475:note_history:31]
As of December 26, 2014, future maturities of long-term debt
 were as follows at the end of each fiscal year below:

- changed (2015-05-05):
[0001193125-15-172043:note_history:32]
Fabrinet entered into a syndicated senior credit facility agreement
 (the “Facility Agreement”) with a consortium of banks
 on May 22, 2014. The Facility Agreement, led by Bank of
 America, provides for a $200.0 million credit line, comprised of a
 $150.0 million revolving loan facility and a $50.0 million delayed
 draw term loan facility. The revolving loan facility contains an
 accordion feature permitting Fabrinet to request an increase in the
 facility up to $100.0 million subject to customary terms and
 conditions and provided that no default or event of default exists
 at the time of request. The revolving loan facility terminates and
 all amounts outstanding are due and payable in full on May 22,
 2019. The principal amount of any drawn term loans must be repaid
 according to the scheduled quarterly amortization payments, with
 final payment of all amounts outstanding, plus accrued interest,
 being due May 22, 2019.
  (was, 2015-02-03, similarity 0.9585):
[0001193125-15-031475:note_history:32]
Fabrinet entered into a syndicated senior credit facility agreement
 (the “Facility Agreement”) with a consortium of banks
 on May 22, 2014. The Facility Agreement, led by Bank of
 America, provides for a $200.0 million credit line, comprised
 of a $150.0 million revolving loan facility and a
 $50.0 million delayed draw term loan facility. The revolving
 loan facility contains an accordion feature permitting Fabrinet to
 request an increase in the facility up to $100.0 million subject to
 customary terms and conditions and provided that no default or
 event of default exists at the time of request. The revolving loan
 facility terminates and all amounts outstanding are due and payable
 in full on May 22, 2019. The principal amount of any drawn
 term loans must be repaid according to the scheduled quarterly
 amortization payments, with final payment of all amounts
 outstanding, plus accrued interest, being due May 22, 2019. As
 of December 26, 2014, no amounts were outstanding under the
 Facility Agreement.

- added (2015-05-05):
[0001193125-15-172043:note_history:33]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allows the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. As of March 27, 2015, the
 outstanding revolving borrowing under the Facility Agreement was
 $30.0 million, resulting in available credit facilities of $170.0
 million. Borrowings under the revolving credit facility are
 classified as current liabilities in the unaudited condensed
 consolidated balance sheet as the Company has the periodic option
 to renew, or pay all or a portion of, the outstanding balance at
 the end of the maturity date, which is in the range of 1 to 6
 months, without premium or penalty, upon notice to the
 administrative agent. On April 16, 2015, the Company sent a
 notice to the bank to renew the maturity date of this revolving
 borrowing. The bank approved the notice and extended the maturity
 date to May 18, 2015.

- changed (2015-05-05):
[0001193125-15-172043:note_history:34]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or the
 equivalent under the local law, can be effected. The Facility
 Agreement contains customary affirmative and negative covenants.
 Negative covenants include, among other things, limitations on
 liens, indebtedness, investments, mergers, sales of assets, changes
 in the nature of the business, dividends and distributions,
 affiliate transactions and capital expenditures. The Facility
 Agreement contains financial covenants requiring Fabrinet to
 maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage
 ratio of not more than 2.50:1.00; and (iv) a minimum quick
 ratio of not less than 1.10:1.00. Each of these financial covenants
 is calculated on a consolidated basis for the consecutive four
 fiscal quarter period then ended. As of March 27, 2015, the
 Company was in compliance with all covenants under the Facility
 Agreement.
  (was, 2015-02-03, similarity 0.9961):
[0001193125-15-031475:note_history:34]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or
 the equivalent under the local law, can be effected. The Facility
 Agreement contains customary affirmative and negative covenants.
 Negative covenants include, among other things, limitations on
 liens, indebtedness, investments, mergers, sales of assets, changes
 in the nature of the business, dividends and distributions,
 affiliate transactions and capital expenditures. The Facility
 Agreement contains financial covenants requiring Fabrinet to
 maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage
 ratio of not more than 2.50:1.00; and (iv) a minimum quick
 ratio of not less than 1.10:1.00. Each of these financial covenants
 is calculated on a consolidated basis for the consecutive four
 fiscal quarter period then ended. As of December 26, 2014, the
 Company was in compliance with all covenants under the Facility
 Agreement.

- changed (2015-05-05):
[0001193125-15-172043:note_history:35]
The Facility Agreement also contains customary events of default
 including, among other things, payment defaults, breaches of
 covenants or representations and warranties, cross-defaults with
 certain other indebtedness, bankruptcy and insolvency events and
 change in control of Fabrinet, subject to grace periods in certain
 instances. Upon an event of default, the lenders may terminate
 their commitments, declare all or a portion of the outstanding
 obligations payable by Fabrinet to be immediately due and payable
 and exercise other rights and remedies provided for under the
 Facility Agreement.
  (was, 2015-02-03, similarity 0.9438):
[0001193125-15-031475:note_history:35]
The Facility Agreement also contains customary events of default
 including, among other things, payment defaults, breaches of
 covenants or representations and warranties, cross-defaults with
 certain other indebtedness, bankruptcy and insolvency events and
 change in control of Fabrinet, subject to grace periods in certain
 instances. Upon an event of default, the lenders may terminate
 their commitments, declare all or a portion of the outstanding
 obligations payable by Fabrinet to be immediately due and payable
 and exercise other rights and remedies provided for under the
 Facility Agreement. The undrawn credit facility of
 $200.0 million became available on July 15, 2014.

- changed (2015-05-05):
[0001193125-15-172043:note_history:36]
Fabrinet intends to use the proceeds of the credit line to finance
 its future manufacturing buildings in the United States and
 Thailand, and for general corporate purposes including mergers and
 acquisitions of complementary manufacturing businesses or
 technology, although Fabrinet has no current commitments with
 respect to any such acquisitions.
  (was, 2015-02-03, similarity 0.9568):
[0001193125-15-031475:note_history:36]
Fabrinet intends to use the proceeds of the credit line to finance
 its future manufacturing building in Thailand, and for general
 corporate purposes including mergers and acquisitions of
 complementary manufacturing businesses or technology, although
 Fabrinet has no current commitments with respect to any such
 acquisitions.

- changed (2015-05-05):
[0001193125-15-172043:note_history:37]
Undrawn available credit facilities as of March 27, 2015 and
 June 27, 2014 were as follows:
  (was, 2015-02-03, similarity 0.9455):
[0001193125-15-031475:note_history:37]
Undrawn available credit facilities as of December 26, 2014
 and June 27, 2014 were as follows:

- changed (2015-05-05):
[0001193125-15-172043:note_history:38]
| (amount in thousands) |  | March 27, 2015 |  |  | June 27, 2014 |  |
| Short-term |  | $ | 1,535 |  |  | $ | 1,539 |  |
| Long-term |  | $ | 170,000 |  |  | $ | — |  |
  (was, 2015-02-03, similarity 0.9665):
[0001193125-15-031475:note_history:38]
| (amount in thousands) |  | December 26, 2014 |  |  | June 27, 2014 |  |
| Short-term |  | $ | 1,520 |  |  | $ | 1,539 |  |
| Long-term |  | $ | 200,000 |  |  | $ | — |  |

- removed (2015-05-05):
[0001193125-15-031475:note_history:39]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Term |  | As of December 26, 2014 |  |  | As of June 27, 2014 |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | June 2012 – March 2017 |  | $ | 13,500 |  |  | $ | 16,500 |  |
| Less: Current portion |  |  |  |  |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  |  |  |  | $ | 7,500 |  |  | $ | 10,500 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-05-05):
[0001193125-15-172043:note_history:40]
The movements of long-term loans were as follows for the nine
 months ended March 27, 2015 and March 28, 2014:

- added (2015-05-05):
[0001193125-15-172043:note_history:41]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27, 2015 |  |  | March 28, 2014 |  |
| Opening net book amount |  | $ | 16,500 |  |  | $ | 28,911 |  |
| Repayment during the period |  |  | (4,500 | ) |  |  | (7,251 | ) |
| Closing net book amount |  | $ | 12,000 |  |  | $ | 21,660 |  |

- removed (2015-05-05):
[0001193125-15-031475:note_history:42]
Bank borrowing and long-term debt was comprised of the
 following:

- removed (2015-05-05):
[0001193125-15-031475:note_history:43]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Term |  | As of December 26, 2014 |  |  | As of June 27, 2014 |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | June 2012 – March 2017 |  | $ | 13,500 |  |  | $ | 16,500 |  |
| Less: Current portion |  |  |  |  |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  |  |  |  | $ | 7,500 |  |  | $ | 10,500 |  |

- removed (2015-05-05):
[0001193125-15-031475:note_history:44]
| (1) | LIBOR is London Interbank Offered Rate. |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-05-05):
[0001193125-15-172043:note_history:45]
The Company’s total borrowing, including revolving and
 long-term borrowings, consisted of the following:

- added (2015-05-05):
[0001193125-15-172043:note_history:46]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  |  | As of March 27, 2015 |  |  | As of June 27, 2014 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  |  | April 2015 | (2) |  | $ | 30,000 |  |  | $ | — |  |
| Current portion of long-term borrowing |  |  |  | 6,000 |  |  |  | 6,000 |  |
|  |  |  | $ | 36,000 |  |  | $ | 6,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  |  | March 2017 |  |  | $ | 12,000 |  |  | $ | 16,500 |  |
| Less: Current portion |  |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  | $ | 6,000 |  |  | $ | 10,500 |  |

- added (2015-05-05):
[0001193125-15-172043:note_history:47]
| (1) | LIBOR is London Interbank Offered Rate. |

- added (2015-05-05):
[0001193125-15-172043:note_history:48]
| (2) | On April 16, 2015, the Company sent a notice to the bank to renew the maturity date of this revolving borrowing. The bank approved the notice and extended the maturity date to May 18, 2015. |

- removed (2015-05-05):
[0001193125-15-031475:note_history:49]
The movements of long-term loans were as follows for the six months
 ended December 26, 2014 and December 27, 2013:

- removed (2015-05-05):
[0001193125-15-031475:note_history:50]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 26, 2014 |  |  | December 27, 2013 |  |
| Opening net book amount |  | $ | 16,500 |  |  | $ | 28,911 |  |
| Repayment during the period |  |  | (3,000 | ) |  |  | (4,834 | ) |
| Closing net book amount |  | $ | 13,500 |  |  | $ | 24,077 |  |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-05):
[0001193125-15-172043:note_history:51]
Undrawn available credit facilities as of March 27, 2015 and
 June 27, 2014 were as follows:
  (was, 2015-02-03, similarity 0.9455):
[0001193125-15-031475:note_history:51]
Undrawn available credit facilities as of December 26, 2014
 and June 27, 2014 were as follows:

- changed (2015-05-05):
[0001193125-15-172043:note_history:52]
| (amount in thousands) |  | March 27, 2015 |  |  | June 27, 2014 |  |
| Short-term |  | $ | 1,535 |  |  | $ | 1,539 |  |
| Long-term |  | $ | 170,000 |  |  | $ | — |  |
  (was, 2015-02-03, similarity 0.9665):
[0001193125-15-031475:note_history:52]
| (amount in thousands) |  | December 26, 2014 |  |  | June 27, 2014 |  |
| Short-term |  | $ | 1,520 |  |  | $ | 1,539 |  |
| Long-term |  | $ | 200,000 |  |  | $ | — |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-05):
[0001193125-15-172043:note_history:53]
As of March 27, 2015, future maturities of long-term debt were
 as follows at the end of each fiscal year below:
  (was, 2015-02-03, similarity 0.9577):
[0001193125-15-031475:note_history:53]
As of December 26, 2014, future maturities of long-term debt
 were as follows at the end of each fiscal year below:


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2015-05-05):
[0001193125-15-172043:note_history:54]
Certain customers may request the Company to store finished
 products purchased by them at the Company’s warehouse. In
 these instances, the Company receives a written request from the
 customer asking the Company to hold the inventory at the
 Company’s warehouse and the ordered goods are segregated in
 the Company’s warehouse from other inventory and cannot be
 used to fulfil other customer orders. In these situations revenue
 is only recognized when persuasive evidence of the sales
 arrangement exists, the goods are completed and ready for shipment,
 pricing is fixed or determinable, collection is reasonable assured,
 and title and risk of loss have passed to the customer.

- removed (2015-05-05):
[0001193125-15-031475:note_history:55]
Certain customers may request the Company to store finished
 products on their behalf. In these situations revenue is only
 recognized when the goods are completed
 and ready for shipment, and title and risk of loss have passed to
 the customer. The Company receives a written request from the
 customer asking the Company to hold the inventory at the Company
 warehouse, and the ordered goods are segregated in the Company
 warehouse from other inventory and cannot be used to fulfill other
 customer orders.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2015-05-05):
[0001193125-15-031475:note_history:56]
| 19. | Subsequent events |

- removed (2015-05-05):
[0001193125-15-031475:note_history:57]
New subsidiaries

- removed (2015-05-05):
[0001193125-15-031475:note_history:58]
On January 6, 2015 the Company incorporated Fabrilink SEZC, a
 100% wholly owned subsidiary, in the Cayman Islands. On
 January 16, 2015, the Company incorporated Fabrinet West, Inc.
 and Fabritek, Inc., 100% wholly owned subsidiaries, in California,
 United States.

- removed (2015-05-05):
[0001193125-15-031475:note_history:59]
Lease commitment

- removed (2015-05-05):
[0001193125-15-031475:note_history:60]
On January 26, 2015, the Company entered into a commercial
 lease agreement for a period of five years for office space of
 approximately 1,730 square feet at Cayman Enterprise City,
 HSBC House, 68 West Bay Road, Grand Cayman KY1-1003, Cayman
 Islands. Monthly service fee of the premises is $14,475 per
 month.

- removed (2015-05-05):
[0001193125-15-031475:note_history:61]
Capital expenditure commitment

- removed (2015-05-05):
[0001193125-15-031475:note_history:62]
On January 20, 2015, the Company entered into a building
 remodel project contract for a facility in Thailand of
 approximately $3.7 million.
