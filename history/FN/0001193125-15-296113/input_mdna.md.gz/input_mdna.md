# FN MD&A — 0001193125-15-296113


## mdna

[0001193125-15-296113:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS. |

[0001193125-15-296113:mdna:2]
|  | • |  | our goals and strategies; |

[0001193125-15-296113:mdna:3]
|  | • |  | our and our customers’ estimates regarding future revenues, operating results, expenses, capital requirements and liquidity; |

[0001193125-15-296113:mdna:4]
|  | • |  | our expectation that the portion of our future revenues attributable to customers in regions outside of North America will decrease compared with the portion of those revenues for the year ended June 26, 2015; |

[0001193125-15-296113:mdna:5]
|  | • |  | our expectation that we will incur significant incremental costs of revenue as a result of our continued diversification into the industrial lasers and sensors markets and other end-markets outside of the optical communications market or our further development of customized optics and glass manufacturing capabilities; |

[0001193125-15-296113:mdna:6]
|  | • |  | our expectation that we will incur incremental costs of revenue as a result of our planned expansion into new geographic markets; |

[0001193125-15-296113:mdna:7]
|  | • |  | our expectation that our fiscal year 2016 selling, general and administrative (SG&A) expenses will increase on an absolute dollar basis and as a percentage of revenue compared with fiscal year 2015; |

[0001193125-15-296113:mdna:8]
|  | • |  | our expectation that, in addition to incremental costs associated with growing our business generally, we will incur additional SG&A expenses as a result of expanding our business in the United States; |

[0001193125-15-296113:mdna:9]
|  | • |  | our expectation that our employee costs will increase in Thailand and the People’s Republic of China (PRC); |

[0001193125-15-296113:mdna:10]
|  | • |  | our future capital expenditures and our needs for additional financing; |

[0001193125-15-296113:mdna:11]
|  | • |  | the expansion of our manufacturing capacity, including into new geographies; |

[0001193125-15-296113:mdna:12]
|  | • |  | the growth rates of our existing markets and potential new markets; |

[0001193125-15-296113:mdna:13]
|  | • |  | our ability, and the ability of our customers and suppliers, to respond successfully to technological or industry developments; |

[0001193125-15-296113:mdna:14]
|  | • |  | our suppliers’ estimates regarding future costs; |

[0001193125-15-296113:mdna:15]
|  | • |  | our ability to increase our penetration of existing markets and to penetrate new markets; |

[0001193125-15-296113:mdna:16]
|  | • |  | our plans to diversify our sources of revenues; |

[0001193125-15-296113:mdna:17]
|  | • |  | trends in the optical communications, industrial lasers, and sensors markets, including trends to outsource the production of components used in those markets; |

[0001193125-15-296113:mdna:18]
|  | • |  | our ability to attract and retain a qualified management team and other qualified personnel and advisors; and |

[0001193125-15-296113:mdna:19]
|  | • |  | competition in our existing and new markets. |

[0001193125-15-296113:mdna:20]
Overview

[0001193125-15-296113:mdna:21]
We provide
advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers (OEMs) of complex products such as optical communication components, modules and sub-systems, industrial
lasers, medical devices, and sensors. We offer a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, complex
printed circuit board assembly, advanced packaging, integration, final assembly and test. Although we focus primarily on low-volume production of a wide variety of high complexity products, which we refer to as “low-volume, high-mix”, we
also have the capability to accommodate high-volume production. Based on our experience, and the positive feedback we have received from our customers, we believe we are a global leader in providing these services to the optical communications,
industrial lasers, automotive, medical, and sensors markets.

[0001193125-15-296113:mdna:22]
Our customer base includes companies in complex industries that
require advanced precision manufacturing capabilities such as optical communications, industrial lasers, automotive, and sensors. The products that we manufacture for our OEM customers include selective switching products; tunable transponders and
transceivers; active optical cables; solid state, diode-pumped, gas and fiber lasers; and sensors. In many cases, we are the sole outsourced manufacturing partner used by our customers for the products that we produce for them.

[0001193125-15-296113:mdna:23]
We also design and fabricate application-specific crystals, lenses, prisms, mirrors, laser components, and substrates (collectively
referred to as “customized optics”), and other custom and standard borosilicate, clear fused quartz, and synthetic fused silica glass products (collectively referred to as “customized glass”). We incorporate our customized optics
and glass into many of the products we manufacture for our OEM customers, and we also sell customized optics and glass in the merchant market.

[0001193125-15-296113:mdna:24]
Audit Committee Investigation

[0001193125-15-296113:mdna:25]
During the fourth quarter of fiscal year 2014, we discovered violations of our policies and procedures relating to finished goods held in our warehouse on behalf of our customers (we refer to finished
goods held in our warehouse on behalf of our customers as consignment goods or consignment inventory and, when the finished goods are sold, we refer to the related revenue as consignment revenue). Specifically, we identified violations related to
certain employees in one business unit colluding to cause the improper recognition of revenues for certain goods by recording consignment revenues on goods before such goods were finished.

[0001193125-15-296113:mdna:26]
In connection with the above, the Audit Committee of our Board of Directors initiated an investigation concerning various accounting
cut-off issues in fiscal year 2014, specifically the transfer of unfinished goods to consignment inventory and other inventory cut-off issues. The investigation found certain process deficiencies concerning the potential to invoice unfinished goods
held under consignment arrangements and the need for certain remedial measures. The investigation did not find executive officer involvement in the identified violations.

[0001193125-15-296113:mdna:27]
We developed remedial steps to address these significant deficiencies and improve our
internal control over our financial reporting. Specifically, throughout fiscal year 2015, we implemented the following remedial measures for the deficiencies identified in the investigation:

[0001193125-15-296113:mdna:28]
|  | 1. | Dismissed an employee involved in the violations. |

[0001193125-15-296113:mdna:29]
|  | 2. | Provided training to staff from all departments at the manager level and above on: |

[0001193125-15-296113:mdna:30]
|  | a. | Our Code of Business Conduct, which provided guidance and further clarity to our employees on our policies and procedures related to the conduct of business; and |

[0001193125-15-296113:mdna:31]
|  | b. | Our revenue recognition policies, using the services of a third party advisor. This training focused on the scope and application of the Company’s policies concerning revenue recognition and related cut-off procedures. |

[0001193125-15-296113:mdna:32]
|  | 3. | Evaluated existing inventory procedures and enhanced such procedures, or where necessary, designed and implemented new procedures, including: |

[0001193125-15-296113:mdna:33]
|  | a. | The segregation and storage of consignment inventory in a secure designated warehouse; and |

[0001193125-15-296113:mdna:34]
|  | b. | Physical check of finished goods when our production division delivers products to the designated warehouse. |

[0001193125-15-296113:mdna:35]
Impact of the Findings of the Investigation on the Financial Statements and Internal Controls

[0001193125-15-296113:mdna:36]
Based on an analysis prepared by the Company, it was determined that the potential exposure relating to the control deficiencies
identified during the investigation were not material to our consolidated financial statements. Further, the Company assessed these control deficiencies to be significant deficiencies rather than material weaknesses on the basis that there was no
executive officer involvement in the violations, the potential misstatements were not material to the financial statements and the Audit Committee was actively involved in the investigation.

[0001193125-15-296113:mdna:37]
As of June 26, 2015, based on an assessment performed by management and taking into account the above mentioned remediation
measures, the Company determined that these significant deficiencies had been remediated.

[0001193125-15-296113:mdna:38]
Consignment Revenue Recognition

[0001193125-15-296113:mdna:39]
Subsequent to completion of the Audit Committee’s investigation, the Company evaluated its accounting practices surrounding
consignment inventory and consignment revenue. Based on that evaluation, the Company determined that for certain volume supply agreements with our customers, not all of the revenue recognition criteria prescribed by U.S. GAAP and Staff Accounting
Bulletin No. 104 had been met at the time revenue was recorded. Specifically, the Company misapplied the guidance when assessing the terms of these agreements with respect to when title and risk of loss transfers to our customers. As a result,
the Company determined that certain sales previously recognized did not qualify for revenue recognition in the periods in which they were recognized. The Company evaluated the impact of the errors on both a quantitative and qualitative basis under
the guidance of Financial Accounting Standard Board’s Accounting Standard Codification (“ASC”) 250, Accounting Changes and Error Corrections and determined that the errors did not have a material impact to the previously issued
consolidated financial statements. Accordingly, previously issued financial statements for fiscal years 2013 and 2012 have not been revised or restated. The Company assessed the control implications and concluded that the deficiency constituted a
material weakness in internal control over financial reporting for the fiscal year 2014.

[0001193125-15-296113:mdna:40]
Throughout fiscal year 2015, the Company undertook the following actions to remedy this
material weakness.

[0001193125-15-296113:mdna:41]
|  | • |  | We conducted mandatory revenue recognition training for our management staff using third-party accounting experts. Management staff also attended follow-up training held by technical accounting specialists from large accounting firms and other professional organizations to maintain up-to-date knowledge on U.S. GAAP accounting principles with respect to the application of our policies concerning revenue recognition. |

[0001193125-15-296113:mdna:42]
|  | • |  | We implemented procedures to ensure that significant customer contracts, both contracts in effect at the commencement of the fiscal year and those entered into during the year, are subject to a comprehensive review by appropriate management staff to ensure that the financial accounting for such contracts is in compliance with U.S. GAAP and that the contracts properly reflected our current business practices. |

[0001193125-15-296113:mdna:43]
|  | • |  | In addition, we engaged an external technical accounting consultant with extensive U.S. GAAP experience to conduct a comprehensive review of all contracts discussed above to ensure the correct application of U.S. GAAP standards and principles related to relevant technical accounting topics, especially for the revenue recognition and the cut-off criteria. |

[0001193125-15-296113:mdna:44]
Management evaluated the operating effectiveness of the remediation procedures throughout the fiscal year 2015. As of June 26, 2015,
the controls and procedures implemented have been tested, and management has determined that such internal controls and procedures are operating effectively to allow management to conclude that the material weakness has been remediated (refer
Item 9A for additional information).

[0001193125-15-296113:mdna:45]
Typhoon Soudelor Storm Damage

[0001193125-15-296113:mdna:46]
During the week of August 10, 2015, we temporarily suspended production in the manufacturing facility of our subsidiary in China due
to storm damage caused by Typhoon Soudelor. We expect to resume production at the facility in August 2015. While we are currently estimating our liabilities and expenses for the quarter ending September 25, 2015 in relation to this matter, our
financial statements for the year ended June 26, 2015 were not affected.

[0001193125-15-296113:mdna:47]
Thailand Flooding

[0001193125-15-296113:mdna:48]
We suspended production at all of our manufacturing facilities in Thailand from October 17, 2011 through November 14, 2011 due
to severe flooding in Thailand. We never resumed, and have permanently ceased, production at our Chokchai facility. We submitted claims for losses to our insurance companies, all of which were settled as of the end of fiscal year 2014.

[0001193125-15-296113:mdna:49]
In fiscal year 2014, we received from our insurers a final payment of $45.2 million against our claims for owned and customer-owned
equipment and inventory, which we recognized as income related to flooding. This income was offset by $0.5 million of other expenses from write-offs of advance payments to a customer due to flood-related losses.

[0001193125-15-296113:mdna:50]
During fiscal year 2014, we fulfilled our obligations to a customer in accordance with a settlement agreement entered into during the
third quarter of fiscal year 2013 by making a final cash payment of $5.3 million and transferring equipment with an aggregate value of $2.3 million to such customer. In addition, we fulfilled our obligations to a customer’s insurers in
accordance with a settlement agreement entered into during the fourth quarter of fiscal 2013 by making a payment of $2.3 million.

[0001193125-15-296113:mdna:51]
Revenues

[0001193125-15-296113:mdna:52]
Our total revenues increased by $95.7 million, or 14.1%, to $773.6 million for fiscal year 2015, compared with $677.9
million for fiscal year 2014. This increase was primarily due to i) an increase in our customers’

[0001193125-15-296113:mdna:53]
demand for both optical and non-optical communications manufacturing service during the year ended June 26, 2015 and ii) the consignment revenues recognition during the fiscal year 2015 of
$16.5 million.

[0001193125-15-296113:mdna:54]
We believe our ability to expand our relationships with existing customers and attract new customers is due to
a number of factors, including our broad range of complex engineering and manufacturing service offerings, flexible low-cost manufacturing platform, process optimization capabilities, advanced supply chain management, excellent customer service and
experienced management team. Although we expect the prices we charge for our manufactured products to decrease over time (partly as a result of competitive market forces), we still believe we will be able to maintain favorable pricing for our
services because of our ability to reduce cycle time, adjust our product mix by focusing on more complicated products, improve product quality and yields, and reduce material costs for the products we manufacture. We believe these capabilities will
enable us to help our OEM customers reduce their manufacturing costs while maintaining or improving the design, quality, reliability, and delivery times of their products.

[0001193125-15-296113:mdna:55]
Revenues, by percentage, from individual customers representing 10% or more of our total revenues in the respective periods were as follows:

[0001193125-15-296113:mdna:56]
|  |  | Years Ended |  |
|  |  | June 26, 2015 |  |  | June 27, 2014 |  |  | June 28, 2013 |  |
| JDS Uniphase Corporation |  |  | 20 | % |  |  | 24 | % |  |  | 22 | % |
| Oclaro, Inc. |  |  | 10 | % |  |  | 22 | % |  |  | 25 | % |

[0001193125-15-296113:mdna:57]
During fiscal year 2015, fiscal year 2014 and fiscal year 2013, we had two customers that each
contributed 10% or more of our total revenues, and such customers together accounted for 30%, 46%, and 47%, respectively, of our total revenues during the respective periods.

[0001193125-15-296113:mdna:58]
Because we depend upon a small number of customers for a significant percentage of our total revenues, a reduction in orders from, a loss of, or any other adverse actions by, any one of these customers
would reduce our revenues and could have a material adverse effect on our business, operating results and share price. Moreover, our customer concentration increases the concentration of our accounts receivable and payment default by any of our key
customers will negatively impact our exposure. Many of our existing and potential customers have substantial debt burdens, have experienced financial distress or have static or declining revenues, all of which may be exacerbated by the continued
uncertainty in the global economies. Certain customers have gone out of business or have been acquired or announced their withdrawal from segments of the optics market. We generate significant accounts payable and inventory for the services that we
provide to our customers, which could expose us to substantial and potentially unrecoverable costs if we do not receive payment from our customers. Therefore, any financial difficulties that our key customers experience could materially and
adversely affect our operating results and financial condition by generating charges for inventory write-offs, provisions for doubtful accounts, and increases in working capital requirements due to increased days inventory and in accounts
receivable.

[0001193125-15-296113:mdna:59]
Furthermore, reliance on a small number of customers gives those customers substantial purchasing power and
leverage in negotiating contracts with us. In addition, although we enter into master supply agreements with our customers, the level of business to be transacted under those agreements is not guaranteed. Instead, we are awarded business under those
agreements on a project-by-project basis. Some of our customers have at times significantly reduced or delayed the volume of manufacturing services that they order from us. If we are unable to maintain our relationships with our existing significant
customers, our business, financial condition and operating results could be harmed.

[0001193125-15-296113:mdna:60]
Revenues by Geography

[0001193125-15-296113:mdna:61]
We generate revenues from three geographic regions: North America, Asia-Pacific, and Europe. Revenues are attributed
to a particular geographic area based on the bill-to-location of our customers, notwithstanding that our customers may ultimately ship their products to end customers in a different geographic region. Virtually all of our revenues are derived from
our manufacturing facilities in Asia-Pacific.

[0001193125-15-296113:mdna:62]
The percentage of our revenues generated from a bill-to-location outside of North America,
consisting of Asia-Pacific and Europe, increased from 51.8% in fiscal year 2014 to 52.1% in fiscal year 2015, primarily because of an increase in sales volumes of our customers in those regions. We expect that the portion of our future revenues
attributable to customers in regions outside of North America will decrease as compared with the fiscal year 2015.

[0001193125-15-296113:mdna:63]
The
following table presents percentages of total revenues by geographic regions:

[0001193125-15-296113:mdna:64]
|  |  | Years Ended |  |
|  |  | June 26, 2015 |  |  | June 27, 2014 |  |  | June 28, 2013 |  |
| North America |  |  | 47.9 | % |  |  | 48.2 | % |  |  | 46.7 | % |
| Asia-Pacific |  |  | 40.1 |  |  |  | 34.0 |  |  |  | 34.0 |  |
| Europe |  |  | 12.0 |  |  |  | 17.8 |  |  |  | 19.3 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-15-296113:mdna:65]
Our Contracts

[0001193125-15-296113:mdna:66]
We enter into supply agreements with our customers which generally have an initial term of up to three years, subject to automatic renewals for subsequent one-year terms unless expressly terminated.
Although there are no minimum purchase requirements in our supply agreements, our customers do provide us with rolling forecasts of their demand requirements. Our supply agreements generally include provisions for pricing and periodic review of
pricing, consignment of our customer’s unique production equipment to us, and the sharing of benefits from cost-savings derived from our efforts. We are generally required to purchase materials, which may include long lead-time materials and
materials that are subject to minimum order quantities and/or non-cancelable or non-returnable terms, to meet the stated demands of our customers. After procuring materials, we manufacture products for our customers based on purchase orders that
contain terms regarding product quantities, delivery locations and delivery dates. Our customers are generally obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by
our customers within a specified period of time, or are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under our contracts. Once materials are designated as either
excess or obsolete inventory, our customers are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products.

[0001193125-15-296113:mdna:67]
Cost of Revenues

[0001193125-15-296113:mdna:68]
The key components of our cost of revenues are material
costs, employee costs, and infrastructure-related costs. Material costs generally represent the majority of our cost of revenues. Several of the materials we require to manufacture products for our customers are customized for their products and
often sourced from a single supplier or in some cases, our own subsidiaries. Shortages from sole-source suppliers due to yield loss, quality concerns, and capacity constraints, among other factors, may increase our expenses and negatively impact our
gross profit margin or total revenues in a given quarter. Material costs include scrap material. Historically, scrap rate diminishes during a product’s life cycle due to process, fixturing and test improvement, and optimization.

[0001193125-15-296113:mdna:69]
A second significant element of cost of revenues is employee costs, including indirect employee costs related to design; configuration
and optimization of manufacturing processes for our customers, quality testing; materials testing and other engineering services; and direct costs related to our manufacturing employees. Direct employee costs include employee salaries, insurance and
benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a lesser extent, costs to recruit,
train, and retain employees. Our cost of revenues are significantly impacted by salary levels in Thailand and the PRC; the fluctuation of the Thai Baht and Chinese Renminbi (RMB) against our functional currency, the U.S. dollar; and our ability to
retain our

[0001193125-15-296113:mdna:70]
employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may impact our ability to sustain our competitive advantage and may
reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention, and asset utilization.

[0001193125-15-296113:mdna:71]
Our infrastructure costs are comprised of depreciation, utilities, facilities management, and overhead costs. Most of our facility leases are long-term agreements. Our depreciation costs include buildings
and fixed assets, primarily at our Pinehurst Campus in Thailand, and capital equipment located at each of our manufacturing locations.

[0001193125-15-296113:mdna:72]
During fiscal year 2015, fiscal year 2014, and fiscal year 2013, discretionary merit-based bonus awards were provided to our non-executive employees. Charges included in cost of revenues for bonus
distributions to such employees were $2.4 million, $1.9 million and $2.0 million for fiscal year 2015, fiscal year 2014, and fiscal year 2013, respectively.

[0001193125-15-296113:mdna:73]
Share-based compensation expense included in cost of revenues was $1.5 million, $1.2 million and $1.1 million for fiscal year 2015, fiscal year 2014, and fiscal year 2013, respectively.

[0001193125-15-296113:mdna:74]
We expect to incur significant incremental costs of revenue as a result of our continued diversification into the industrial lasers,
automotive, and sensors markets, and other end-markets outside of the optical communications market or our further development of customized optics and glass manufacturing capabilities. We also expect to incur incremental costs of revenue as a
result of our planned expansion into new geographic markets, though we are not able to determine the amount of these incremental expenses.

[0001193125-15-296113:mdna:75]
Selling, General and Administrative Expenses

[0001193125-15-296113:mdna:76]
Our selling, general and administrative expenses (SG&A) primarily consist of corporate employee costs for sales and marketing, general and administrative, and other support personnel, including
research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense, and other general expenses not related to cost of revenues. In fiscal year
2016, we expect our SG&A expenses will increase on an absolute dollar basis and as a percentage of revenue compared with fiscal year 2015, due to the startup expenses of our facility in the United States.

[0001193125-15-296113:mdna:77]
The compensation committee of our board of directors approved a fiscal year 2015 executive incentive plan with quantitative objectives,
based on achieving certain revenue and non-GAAP earnings per share targets for our fiscal year ended June 26, 2015, as well as qualitative objectives, based on achieving individual performance goals. Bonuses under our fiscal year 2015 executive
incentive plan are payable after the end of fiscal year 2015. In fiscal year 2014, the compensation committee approved a fiscal year 2014 executive incentive plan with quantitative objectives, based on achieving certain revenue and gross margin
percentage targets for our fiscal year ended June 27, 2014, as well as qualitative objectives, based on achieving individual performance goals. In the three months ended December 26, 2014, the compensation committee awarded bonuses to our
executive employees for Company and individual achievements of performance under our fiscal year 2014 executive incentive plan. Discretionary merit-based bonus awards were also available to our non-executive employees and were payable as of
June 26, 2015.

[0001193125-15-296113:mdna:78]
Charges included in SG&A expenses for bonus distributions to non-executive and executive employees
were $3.6 million, $3.1 million and $1.7 million for fiscal year 2015, fiscal year 2014, and fiscal year 2013, respectively.

[0001193125-15-296113:mdna:79]
Share-based compensation expense included in SG&A expenses was $6.6 million, $4.4 million and $4.0 million for fiscal year 2015,
fiscal year 2014, and fiscal year 2013, respectively.

[0001193125-15-296113:mdna:80]
In addition to incremental costs associated with growing our business
generally, we expect to incur additional SG&A expenses as a result of expanding our business in the United States.

[0001193125-15-296113:mdna:81]
Additional Financial Disclosures

[0001193125-15-296113:mdna:82]
Foreign Exchange

[0001193125-15-296113:mdna:83]
As a result of our international operations, we are exposed to foreign exchange risk arising from various currency exposures primarily with respect to the Thai Baht. Although a majority of our total
revenues is denominated in U.S. dollars, a substantial portion of our payroll plus certain other operating expenses are incurred and paid in Thai Baht. The exchange rates between the Thai Baht and the U.S. dollar have fluctuated substantially in
recent years and may continue to fluctuate substantially in the future. We report our financial results in U.S. dollars and our results of operations have been and may continue to be negatively impacted owing to appreciation of the Thai Baht against
the U.S. dollar. Smaller portions of our expenses are incurred in a variety of other currencies, including RMB, Canadian dollars, Euros, and Japanese yen, the appreciation of which may also negatively impact our financial results.

[0001193125-15-296113:mdna:84]
In addition, we are exposed to foreign exchange risk in connection with the credit facility and cross currency swap arrangements we
entered into with TMB Bank Public Company Limited (the “Bank”) in May 2011 for the construction of Pinehurst Building 6. The terms of the contract with the Bank provide the following facilities: (1) a term loan facility for up to Thai
Baht 960 million (equal to $30.0 million) with a fixed interest rate of 5.28% per annum, (2) a hedging facility for currency interest rate swaps with a notional amount of $30.0 million, and (3) a settlement limit of Thai Baht
65 million, subject to certain terms and conditions as set forth therein. As of March 30, 2012, we had drawn down the entire $30.0 million available under the term loan facility. Borrowings and interest under the term loan have been
scheduled to be repaid on a quarterly basis between September 2011 and March 2017. As of June 26, 2015 and June 27, 2014, we had outstanding borrowings under the term loan facility of $10.5 million and $16.5 million, respectively. Under
the terms of the cross currency swap arrangement amounts drawn in Thai Baht were converted to U.S. dollars for repayment by us on a quarterly basis at the floating rate of 3-month London Interbank Offered Rate (LIBOR) plus 2.8% per annum.

[0001193125-15-296113:mdna:85]
In order to manage the risks arising from fluctuations in foreign currency exchange rates, we use derivative financial
instruments. We may enter into short-term forward foreign currency contracts or put option contracts to help manage currency exposures associated with certain assets and liabilities, primarily short-term obligations. The forward exchange contracts
and put option contracts generally had original maturities of one to six months. All foreign currency exchange contracts are recognized on the consolidated balance sheets at fair value. As we do not apply hedge accounting to these instruments, the
change in the fair value of the derivatives are recorded in foreign exchange (loss) gain, net on the consolidated statements of operations and comprehensive income. The gains and losses on our forward contracts and put option contracts generally
offset losses and gains on the assets, liabilities, and transactions economically hedged and, accordingly, generally do not subject us to the risk of significant accounting losses.

[0001193125-15-296113:mdna:86]
We had foreign currency assets and liabilities in Thai Baht and RMB as follows:

[0001193125-15-296113:mdna:87]
|  |  | As of June 26, 2015 |  |  | As of June 27, 2014 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai Baht |  |  | 377,785 |  |  | $ | 11,596 |  |  |  | 51.3 |  |  |  | 1,536,887 |  |  | $ | 47,318 |  |  |  | 79.6 |  |
| RMB |  |  | 67,455 |  |  |  | 11,029 |  |  |  | 48.7 |  |  |  | 74,813 |  |  |  | 12,156 |  |  |  | 20.4 |  |
| Total |  |  |  |  |  | $ | 22,625 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 59,474 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai Baht |  |  | 860,425 |  |  | $ | 26,410 |  |  |  | 88.8 |  |  |  | 735,490 |  |  | $ | 22,644 |  |  |  | 81.1 |  |
| RMB |  |  | 20,461 |  |  |  | 3,347 |  |  |  | 11.2 |  |  |  | 32,512 |  |  |  | 5,283 |  |  |  | 18.9 |  |
| Total |  |  |  |  |  | $ | 29,757 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 27,927 |  |  |  | 100.0 |  |

[0001193125-15-296113:mdna:88]
The Thai Baht assets represent cash and cash equivalents, trade accounts receivable,
deposits and other current assets. The Thai Baht liabilities represent trade accounts payable, accrued expenses, and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and
offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of June 26, 2015 and June 27, 2014, there were $41.0 million and $15.0 million, respectively, in put option contracts
outstanding on the Thai Baht payables.

[0001193125-15-296113:mdna:89]
The RMB assets represent cash and cash equivalents, accounts receivable, and other
current assets. The RMB liabilities represent trade accounts payable, accrued expenses and other payables. As of June 26, 2015 and June 27, 2014, we did not have any selling RMB to U.S. dollar forward contracts.

[0001193125-15-296113:mdna:90]
As of June 26, 2015 and June 27, 2014, unrealized loss from fair market value of derivatives amounted to $0.4 million and
unrealized gain from fair market value of derivatives amounted $0.1 million, respectively.

[0001193125-15-296113:mdna:91]
Currency Regulation and
Dividend Distribution

[0001193125-15-296113:mdna:92]
Foreign exchange regulation in the PRC is primarily governed by the following rules:

[0001193125-15-296113:mdna:93]
|  | • |  | Foreign Currency Administration Rules, as amended on August 5, 2008, or the Exchange Rules; |

[0001193125-15-296113:mdna:94]
|  | • |  | Administration Rules of the Settlement, Sale and Payment of Foreign Exchange (1996), or the Administration Rules; and |

[0001193125-15-296113:mdna:95]
|  | • |  | Notice on Perfecting Practices Concerning Foreign Exchange Settlement Regarding the Capital Contribution by Foreign-invested Enterprises, as promulgated by the State Administration of Foreign Exchange, or State Administration of Foreign Exchange (SAFE), on August 29, 2008, or Circular 142. |

[0001193125-15-296113:mdna:96]
Under the Exchange Rules, RMB is freely convertible into foreign currencies for current account items, including the distribution of dividends, interest payments, and trade and service-related foreign
exchange transactions. However, conversion of RMB for capital account items, such as direct investments, loans, security investments and repatriation of investments, is still subject to the approval of SAFE.

[0001193125-15-296113:mdna:97]
Under the Administration Rules, foreign-invested enterprises may only buy, sell, or remit foreign currencies at banks authorized to
conduct foreign exchange business after providing valid commercial documents and relevant supporting documents and, in the case of capital account item transactions, obtaining approval from SAFE. Capital investments by foreign-invested enterprises
outside of the PRC are also subject to limitations, which include approvals by the Ministry of Commerce, SAFE, and the State Development and Reform Commission.

[0001193125-15-296113:mdna:98]
Circular 142 regulates the conversion by a foreign-invested company of foreign currency into RMB by restricting how the converted RMB may be used. Circular 142 requires that the registered capital of a
foreign-invested enterprise settled in RMB converted from foreign currencies may only be used for purposes within the business scope approved by the applicable governmental authority and may not be used for equity investments within the PRC. In
addition, SAFE strengthened its oversight of the flow and use of the registered capital of foreign-invested enterprises settled in RMB converted from foreign currencies. The use of such RMB capital may not be changed without SAFE’s approval and
may not be used to repay RMB loans if the proceeds of such loans have not been used.

[0001193125-15-296113:mdna:99]
On January 5, 2007, SAFE
promulgated the Detailed Rules for Implementing the Measures for the Administration on Individual Foreign Exchange, or the Implementation Rules. Under the Implementation Rules, PRC citizens who are granted share options by an overseas
publicly-listed company are required, through a PRC agent or PRC subsidiary of such overseas publicly-listed company, to register with SAFE and complete certain other procedures.

[0001193125-15-296113:mdna:100]
In addition, the General Administration of Taxation has issued circulars concerning employee
share options. Under these circulars, our employees working in the PRC who exercise share options will be subject to PRC individual income tax. Our PRC subsidiary is obligated to file documents related to employee share options with relevant tax
authorities and withhold individual income taxes of those employees who exercise their share options.

[0001193125-15-296113:mdna:101]
Furthermore, our
transfer of funds to our subsidiaries in Thailand and the PRC are each subject to approval by governmental authorities in the case of an increase in registered capital, or subject to registration with governmental authorities in case of a
shareholder loan. These limitations on the flow of funds between our subsidiaries and us could restrict our ability to act in response to changing market conditions.

[0001193125-15-296113:mdna:102]
Income Tax

[0001193125-15-296113:mdna:103]
Our effective tax rate is a function of the mix of tax
rates in the various jurisdictions in which we do business. We are domiciled in the Cayman Islands. Under the current laws of the Cayman Islands, we are not subject to tax in the Cayman Islands on income or capital gains. We have received this
undertaking for a 20-year period ending August 24, 2019, and after the expiration date we may request a renewal with the office of the Clerk of the Cabinet for another twenty years.

[0001193125-15-296113:mdna:104]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board
of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption is currently available to us through June 2020 on income generated from the manufacture of products at Pinehurst Building 6. Such
preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15
years. Additionally, in December 2011, the Thailand Revenue Department announced a reduction in corporate income tax rates for tax periods beginning on or after January 1, 2012. As a result of the announcement, corporate income tax rates
for our Thai subsidiary will be reduced from 23% in fiscal year 2013 to 20% in fiscal year 2014, fiscal year 2015, and fiscal year 2016.

[0001193125-15-296113:mdna:105]
Our subsidiary in China had been granted a tax privilege to reduce its corporate income tax rate from 25% to 15% but the privilege expired on December 31, 2013.

[0001193125-15-296113:mdna:106]
Critical Accounting Policies and Use of Estimates

[0001193125-15-296113:mdna:107]
We prepare our consolidated financial statements in conformity with U.S. GAAP which requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure
of contingent liabilities on the date of the consolidated financial statements and the reported amounts of revenues and expenses during the financial reporting period. We continually evaluate these estimates and assumptions based on the most
recently available information, our own historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results form the basis for making judgments about the carrying values of assets and
liabilities that are not readily apparent from other sources. Because the use of estimates is an integral component of the financial reporting process, actual results could differ from those estimates. Some of our accounting policies require higher
degrees of judgment than others in their application. We consider the policies discussed below to be critical to an understanding of our consolidated financial statements, as their application places the most significant demands on our
management’s judgment.

[0001193125-15-296113:mdna:108]
A quantitative sensitivity analysis is provided where such information is reasonably available,
can be reliably estimated, and provides material information to investors. The amounts used to assess sensitivity are included for illustrative purposes only and do not represent management’s predictions of variability.

[0001193125-15-296113:mdna:109]
Revenue Recognition

[0001193125-15-296113:mdna:110]
We recognize revenue when it is realized or realizable and earned. We consider revenue realized or realizable and earned when there is
persuasive evidence of an arrangement, delivery has occurred, the sales price is fixed or determinable, and collectability is reasonably assured. Delivery does not occur until products have been shipped or services have been provided, risk of loss
has transferred and in cases where formal acceptance is required, customer acceptance has been obtained or customer acceptance provisions have lapsed. In situations where a formal acceptance is required but the acceptance only relates to whether the
product meets its published specifications, revenue is recognized upon shipment provided all other revenue recognition criteria are met. The sales price is not considered to be fixed or determinable until all contingencies related to the sale have
been resolved.

[0001193125-15-296113:mdna:111]
We reduce revenue for rebates and other similar allowances. Revenue is recognized only if these estimates can
be reliably determined. Our estimates are based on historical results taking into consideration the type of customer, the type of transaction, and the specifics of each arrangement.

[0001193125-15-296113:mdna:112]
In addition to the aforementioned general policies, certain customers may request us to store finished products purchased by them at the
Company’s warehouse. In these instances, we receive a written request from the customer asking us to hold the inventory at our warehouse and the ordered goods are segregated in our warehouse from other inventory and cannot be used to fulfil
other customer orders. In these situations revenue is only recognized when persuasive evidence of the sales arrangement exists, the goods are completed and ready for shipment, pricing is fixed or determinable, collection is reasonable assured, and
title and risk of loss have passed to the customer.

[0001193125-15-296113:mdna:113]
Income Related to Flooding

[0001193125-15-296113:mdna:114]
We estimated flood-related losses to consigned equipment and inventory based on discussions with our customers regarding their assessments
of the damage to, and valuation of, the consigned assets that were under our care, custody and control at our Chokchai facility. For assets owned by us, flood-related losses were estimated based on the net book value of the assets written-off as a
result of the flood.

[0001193125-15-296113:mdna:115]
In fiscal year 2014, we recognized $45.2 million as income related to flooding, which consisted of a
payment from our insurers against our claims for owned and consigned equipment and inventory, offset by $0.5 million of other expenses from write-offs of advance payments to a customer due to flood-related losses.

[0001193125-15-296113:mdna:116]
Long-Lived Assets

[0001193125-15-296113:mdna:117]
We review property, plant and equipment for impairment when events or changes in circumstances indicate the carrying amount of an asset may not be recoverable. An impairment loss is recognized when the
carrying amount of a long-lived asset or assets group exceeds its fair value. Recoverability of property and equipment is measured by comparing its carrying amount to the projected undiscounted cash flows the property and equipment are expected to
generate. If such assets are considered to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the property and equipment exceeds its fair value.

[0001193125-15-296113:mdna:118]
Allowance for Doubtful Accounts

[0001193125-15-296113:mdna:119]
We perform ongoing credit evaluations of our customers’ financial condition and make provisions for doubtful accounts based on the outcomes of these credit evaluations. We evaluate the collectability
of our accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections, and the age of past due receivables. Unanticipated changes in the liquidity or financial position of our customers
may require additional provisions for doubtful accounts. Under our specific identification method it is not practical to assess the sensitivity of our estimates.

[0001193125-15-296113:mdna:120]
Inventory Valuation

[0001193125-15-296113:mdna:121]
Our inventory is stated at the lower of cost (on a first-in, first-out basis) or market value. Our industry is characterized by rapid
technological change, short-term customer commitments, and rapid changes in demand. We make provisions for estimated excess and obsolete inventory based on regular reviews of inventory quantities on hand and the latest forecasts of product demand
and production requirements from our customers. If actual market conditions or our customers’ product demands are less favorable than those projected, additional provisions may be required. In addition, unanticipated changes in liquidity or the
financial positions of our customers or changes in economic conditions may require additional provisions for inventory due to our customers’ inability to fulfill their contractual obligations. During fiscal year 2015 and fiscal year 2014, a
change of 10% for excess and obsolete materials, based on product demand and production requirements from our customers, would have decreased by decrease our net income by approximately $0.3 million and $0.3 million, respectively.

[0001193125-15-296113:mdna:122]
Deferred Income Taxes

[0001193125-15-296113:mdna:123]
Our deferred income tax assets represent temporary differences between the carrying amount and the tax basis of existing assets and liabilities that will result in deductible and payable amounts in future
years, including net operating loss carryforwards. Based on estimates, the carrying value of our net deferred tax assets assumes that it is more likely than not that we will be able to generate sufficient future taxable income in certain tax
jurisdictions to realize these deferred income tax assets. Our judgments regarding future profitability may change owing to future market conditions, changes in U.S. or international tax laws, or other factors. If these estimates and related
assumptions change in the future, we may be required to increase or decrease our valuation allowance against the deferred tax assets, resulting in additional or lesser income tax expense. As of June 26, 2015 we have determined that it is more
likely than not that deferred tax asset attributable to a subsidiary in the United States will not be realized, primarily due to uncertainties related to the subsidiary’s ability to utilize its operating loss carryforward before they expire.
Accordingly, we have established a valuation allowance for such deferred tax asset of $1.0 million. As of June 27, 2014, we assessed all of our deferred tax assets as more likely than not to be realizable and, accordingly, did not have a
valuation allowance against our deferred tax assets.

[0001193125-15-296113:mdna:124]
We assess tax positions in a previously filed tax return or a position
expected to be taken in a future tax return that is reflected in measuring current or deferred income tax assets and liabilities for interim or annual periods, based on the technical merits of the position. We apply a “more likely than
not” basis (i.e., a likelihood greater than 50 percent), in accordance with the authoritative guidance, and recognize a tax provision in the consolidated financial statements for an uncertain tax position that would not be sustained.

[0001193125-15-296113:mdna:125]
Share-Based Compensation

[0001193125-15-296113:mdna:126]
Awards granted are accounted for by recognizing the cost of employee services received in exchange for awards of equity instruments, based on the fair value of those awards, in the consolidated financial
statements. In determining the fair value of awards, we are required to make estimates of the fair value of our ordinary shares, expected dividends to be issued, expected volatility of our shares, expected forfeitures of the awards, risk free
interest rates for the expected terms of the awards, expected terms of the awards, and the vesting period of the respective awards.

[0001193125-15-296113:mdna:127]
The determination of our share-based compensation expense for both current and future periods requires the input of assumptions, including estimated forfeitures and the price volatility of the underlying
ordinary shares. We estimate forfeitures based on past employee retention rates and our expectations of future retention rates, and we will prospectively revise our forfeiture rates based on actual history. Our share-based compensation expense may
change based on changes to our actual forfeitures.

[0001193125-15-296113:mdna:128]
For accounting purposes only, the fair value of each option grant is
estimated using the Black-Scholes-Merton option pricing model, which takes into account the following factors: (i) the exercise price of the options;

[0001193125-15-296113:mdna:129]
(ii) the estimated fair value of the underlying ordinary shares; (iii) the expected life of the options; (iv) the expected volatility of the underlying ordinary shares;
(v) the risk-free interest rate during the expected life of the options; and (vi) the expected dividend yield of the underlying ordinary shares. However, these fair values are inherently uncertain and highly subjective.

[0001193125-15-296113:mdna:130]
The exercise price of the options is stated in the option agreements. The expected life of the options involves estimates of the
anticipated timing of the exercise of the vested options. The expected volatility is based on the historical volatility of the capital stock of comparable publicly-traded companies. We have applied the U.S. Treasury Bill interest rate with a
maturity date similar to the expected life of our options as the risk-free interest rate and assumed a dividend yield for periods when we paid dividends.

[0001193125-15-296113:mdna:131]
Results of Operations

[0001193125-15-296113:mdna:132]
The following table sets forth a summary of our
consolidated statements of operations and comprehensive income. Note that period-to-period comparisons of operating results should not be relied upon as indicative of future performance.

[0001193125-15-296113:mdna:133]
|  |  | Years Ended |  |
|  |  | June 26, 2015 |  |  | June 27, 2014 |  |  | June 28, 2013 |  |
| Revenues |  | $ | 773,587 |  |  | $ | 677,854 |  |  | $ | 641,542 |  |
| Cost of revenues |  |  | (685,814 | ) |  |  | (603,621 | ) |  |  | (572,124 | ) |
| Gross profit |  |  | 87,773 |  |  |  | 74,233 |  |  |  | 69,418 |  |
| Selling, general and administrative expenses |  |  | (39,460 | ) |  |  | (27,664 | ) |  |  | (23,787 | ) |
| Income related to flooding |  |  | — |  |  |  | 44,748 |  |  |  | 27,211 |  |
| Expenses related to reduction in workforce |  |  | (1,153 | ) |  |  | — |  |  |  | (2,052 | ) |
| Operating income |  |  | 47,160 |  |  |  | 91,317 |  |  |  | 70,790 |  |
| Interest income |  |  | 1,253 |  |  |  | 1,793 |  |  |  | 1,083 |  |
| Interest expense |  |  | (616 | ) |  |  | (713 | ) |  |  | (1,010 | ) |
| Foreign exchange (loss) gain, net |  |  | (19 | ) |  |  | (24 | ) |  |  | 354 |  |
| Other (expense) income |  |  | (152 | ) |  |  | 797 |  |  |  | 692 |  |
| Income before income taxes |  |  | 47,626 |  |  |  | 93,170 |  |  |  | 71,909 |  |
| Income tax expense |  |  | (3,984 | ) |  |  | (1,439 | ) |  |  | (2,940 | ) |
| Net income |  |  | 43,642 |  |  |  | 91,731 |  |  |  | 68,969 |  |
| Other comprehensive loss |  |  | (44 | ) |  |  | — |  |  |  | — |  |
| Net comprehensive income |  | $ | 43,598 |  |  | $ | 91,731 |  |  | $ | 68,969 |  |

[0001193125-15-296113:mdna:134]
48

[0001193125-15-296113:mdna:135]
The following table sets forth a summary of our consolidated statements of operations and
comprehensive income as a percentage of total revenues for the periods indicated.

[0001193125-15-296113:mdna:136]
|  |  | Years Ended |  |
|  |  | June 26, 2015 |  |  | June 27, 2014 |  |  | June 28, 2013 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (88.6 | ) |  |  | (89.1 | ) |  |  | (89.2 | ) |
| Gross profit |  |  | 11.4 |  |  |  | 10.9 |  |  |  | 10.8 |  |
| Selling, general and administrative expenses |  |  | (5.1 | ) |  |  | (4.1 | ) |  |  | (3.7 | ) |
| Income related to flooding |  |  | — |  |  |  | 6.6 |  |  |  | 4.2 |  |
| Expenses related to reduction in workforce |  |  | (0.2 | ) |  |  | — |  |  |  | (0.3 | ) |
| Operating income |  |  | 6.1 |  |  |  | 13.4 |  |  |  | 11.0 |  |
| Interest income |  |  | 0.2 |  |  |  | 0.3 |  |  |  | 0.2 |  |
| Interest expense |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | (0.2 | ) |
| Foreign exchange (loss) gain, net |  |  | (0.0 | ) |  |  | (0.0 | ) |  |  | 0.1 |  |
| Other (expense) income |  |  | (0.0 | ) |  |  | 0.1 |  |  |  | 0.1 |  |
| Income before income taxes |  |  | 6.2 |  |  |  | 13.7 |  |  |  | 11.2 |  |
| Income tax expense |  |  | (0.5 | ) |  |  | (0.2 | ) |  |  | (0.5 | ) |
| Net income |  |  | 5.6 |  |  |  | 13.5 |  |  |  | 10.7 |  |
| Other comprehensive loss |  |  | (0.0 | ) |  |  | — |  |  |  | — |  |
| Net comprehensive income |  |  | 5.6 | % |  |  | 13.5 | % |  |  | 10.7 | % |

[0001193125-15-296113:mdna:137]
The following table sets forth our revenues by end market for the periods indicated. As necessary,
comparative figures have been adjusted to conform with changes in presentation in the current year.

[0001193125-15-296113:mdna:138]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26, 2015 |  |  | June 27, 2014 |  |  | June 28, 2013 |  |
| Optical communications |  | $ | 553,245 |  |  | $ | 484,071 |  |  | $ | 449,790 |  |
| Lasers, sensors, and other |  |  | 220,342 |  |  |  | 193,783 |  |  |  | 191,752 |  |
| Total |  | $ | 773,587 |  |  | $ | 677,854 |  |  | $ | 641,542 |  |

[0001193125-15-296113:mdna:139]
We operate and internally manage a single operating segment. As such, discrete information with respect
to separate product lines and segments is not accumulated.

[0001193125-15-296113:mdna:140]
Comparison of Fiscal Year 2015 with Fiscal Year 2014

[0001193125-15-296113:mdna:141]
Total revenues. Our total revenues increased by $95.7 million, or 14.1%, to $773.6 million for fiscal year
2015, compared with $677.9 million for fiscal year 2014. This increase was due to i) an increase in customer’s demand for both optical and non-optical communication manufacturing services during fiscal year 2015 and ii) the consignment revenues
recognition during fiscal year 2015 of $16.5 million. Revenues from optical communications products represented 71.5% of our total revenues for fiscal year 2015, compared with 71.4% for fiscal year 2014.

[0001193125-15-296113:mdna:142]
Cost of revenues. Our cost of revenues increased by $82.2 million, or 13.6%, to $685.8 million, or 88.6% of total revenues, for
fiscal year 2015, compared with $603.6 million, or 89.1% of total revenues, for fiscal year 2014. The increase in cost of revenues on an absolute dollar basis was primarily due to an increase in sales volume, partially offset by a favorable product
mix. Cost of revenues also included non-cash share-based compensation expense of $1.5 million for fiscal year 2015, compared with $1.2 million for fiscal year 2014.

[0001193125-15-296113:mdna:143]
Gross profit. Our gross profit increased by $13.5 million, or 18.2%, to $87.8
million, or 11.4% of total revenues, for fiscal year 2015, compared with $74.2 million, or 11.0% of total revenues, for fiscal year 2014. The slight increase in gross profit margin during fiscal year 2015, compared with fiscal year 2014, was
primarily related to an increase in revenues resulting from increases in both optical and non-optical products sales volume, as well as a favorable product mix.

[0001193125-15-296113:mdna:144]
SG&A expenses. Our SG&A expenses increased by $11.8 million, or 42.6%, to $39.5 million, or 5.1% of total revenues, for fiscal year 2015, compared with $27.7 million, or 4.1% of total
revenues, for fiscal year 2014. Our SG&A expenses increased both in absolute dollars and as a percentage of revenue during fiscal year 2015, compared with fiscal year 2014, mainly due to; (i) an increase of $2.8 million in costs related to
the Audit committee’s internal investigation; (ii) an increase of $1.3 million in accrued executive salaries and other benefits; (iii) an increase of $2.2 million in share-based compensation; (iv) an increase of $2.9 million in
pre-operating expenses of our subsidiary’s new facility in the United States; (v) an increase of $0.7 million in post-retirement benefit in fiscal year 2015 due to an increase in the number of employees; and (vi) an increase of $0.9
million in expenses related to business development.

[0001193125-15-296113:mdna:145]
Income related to flooding. In fiscal year 2014, we recognized
income related to flooding of $45.2 million, which consisted of a payment from our insurers against our claim for owned and customer-owned equipment and inventory, offset by $0.5 million of other expenses from write-offs of advance payments to a
customer due to flood-related losses.

[0001193125-15-296113:mdna:146]
Expenses related to reduction in workforce. During fiscal year 2015, we
implemented a reduction in workforce and incurred expenses of approximately $1.2 million, which represented severance and benefits costs associated with the termination of approximately 100 employees in accordance with contractual obligations and
local regulations.

[0001193125-15-296113:mdna:147]
Operating income. Our operating income decreased by $44.2 million to $47.2 million, or 6.1% of
total revenues, for fiscal year 2015, compared with $91.3 million, or 13.5% of total revenues, for fiscal year 2014.

[0001193125-15-296113:mdna:148]
Interest income. Our interest income decreased by $0.5 million to $1.3 million for fiscal year 2015, compared with $1.8 million
for fiscal year 2014. This decrease was due to a decrease in interest rates of bank deposits and the short-term investment in marketable securities.

[0001193125-15-296113:mdna:149]
Interest expense. Our interest expense decreased by $0.1 million to $0.6 million for fiscal year 2015, compared with $0.7 million for fiscal year 2014. This decrease was due to decreases in our
average long-term loan balances resulting from principal repayments during the fiscal year 2014.

[0001193125-15-296113:mdna:150]
Income before income
taxes. We recorded income before income taxes of $47.6 million for fiscal year 2015, compared with $93.2 million for fiscal year 2014.

[0001193125-15-296113:mdna:151]
Income tax expense. Our provision for income tax reflects an effective tax rate of 8.3% for fiscal year 2015, compared with an effective tax rate of 1.5% for fiscal year 2014. The increase was
primarily due to the fact that the income tax rate of our subsidiary in China increased from 15% to 25% commencing the quarter ended March 28, 2014 due to the expiration of a tax privilege, as well as the reversal of liability for uncertain tax
positions, including accrued interest of $1.5 million during the fiscal year 2014 and the fact that we had higher taxable income during fiscal year 2015, as compared with fiscal year 2014 due to the income related to flooding of $44.7 million that
was not subjected to income tax.

[0001193125-15-296113:mdna:152]
Net income. We recorded net income of $43.6 million, or 5.6% of total revenues, for
fiscal year 2015, compared with net income of $91.7 million, or 13.5% of total revenues, for fiscal year 2014.

[0001193125-15-296113:mdna:153]
Other
comprehensive loss. We recorded other comprehensive loss related to accumulated net unrealized loss on available-for-sale investments of $0.04 million for the fiscal year 2015.

[0001193125-15-296113:mdna:154]
Comparison of Fiscal Year 2014 with Fiscal Year 2013

[0001193125-15-296113:mdna:155]
Total revenues. Our total revenues increased by $36.3 million, or 5.7%, to $677.9 million for fiscal year 2014, compared with
$641.5 million for fiscal year 2013. This increase was primarily due to an increase in optical communication products sales volume. Revenues from optical communications products represented 71.4% of our total revenues for fiscal year 2014, compared
with 70.1% for fiscal year 2013.

[0001193125-15-296113:mdna:156]
Cost of revenues. Our cost of revenues increased by $31.5 million, or 5.5%, to $603.6
million, or 89.1% of total revenues, for fiscal year 2014, compared with $572.1 million, or 89.2% of total revenues, for fiscal year 2013. The increase in cost of revenues on an absolute dollar basis was primarily due to an increase in sales volume
and a proportional increase in cost of revenues. Cost of revenues also included non-cash share-based compensation expense of $1.2 million for fiscal year 2014, compared with $1.1 million for fiscal year 2013.

[0001193125-15-296113:mdna:157]
Gross profit. Our gross profit increased by $4.8 million, or 6.9%, to $74.2 million, or 11.0% of total revenues, for fiscal year
2014, compared with $69.4 million, or 10.8% of total revenues, for fiscal year 2013. The slight increase in gross profit margin during fiscal year 2014, compared with fiscal year 2013, was primarily related to an increase in revenues resulting from
increases in both optical and non-optical products sales volume.

[0001193125-15-296113:mdna:158]
SG&A expenses. Our SG&A expenses increased by
$3.9 million, or 16.3%, to $27.7 million, or 4.1% of total revenues, for fiscal year 2014, compared with $23.8 million, or 3.7% of total revenues, for fiscal year 2013. Our SG&A expenses increased both in absolute dollars and as a percentage of
revenue during fiscal year 2014, compared with fiscal year 2013, mainly due to: (i) a $1.8 million increase in accrued executive bonuses, salaries, and other benefits; (ii) the recognition of $0.5 million in severance and related payments
to an executive who left the Company in March 2014; (iii) a $0.7 million increase in severance liability expense in fiscal year 2014 due to an increase in the number of employees; and (iv) a $0.4 million increase in share-based
compensation charges.

[0001193125-15-296113:mdna:159]
Income related to flooding. In fiscal year 2014, we recognized income related to flooding of
$45.2 million, which consisted of a payment from our insurers against our claims for owned and customer-owned equipment and inventory, offset by the recognition of $0.5 million from write-offs of advance payments to a customer due to flood-related
losses. In fiscal year 2013, we recognized $27.2 million of income related to flooding, which consisted of an interim payment from our insurers of $16.2 million against our claims for owned inventory losses and owned equipment losses, a payment of
$13.1 million from our insurers in full and final settlement of our claims for business interruption losses and a payment of $0.1 million from our insurers in full and final settlement of our claim for damage to our buildings at Pinehurst, which was
offset by the recognition of $2.2 million in additional liabilities to third parties due to flood losses.

[0001193125-15-296113:mdna:160]
Expenses related
to reduction in workforce. During fiscal year 2013, we implemented a reduction in workforce and incurred expenses of approximately $2.1 million, which represented severance and benefits costs associated with the termination of approximately 180
employees in accordance with contractual obligations and local regulations.

[0001193125-15-296113:mdna:161]
Operating income. Our operating income
increased by $20.5 million to $91.3 million, or 13.5% of total revenues, for fiscal year 2014, compared with $70.8 million, or 11.0% of total revenues, for fiscal year 2013.

[0001193125-15-296113:mdna:162]
Interest income. Our interest income increased by $0.7 million to $1.8 million for fiscal year 2014, compared with $1.1 million for fiscal year 2013. This increase was due to increases in cash and
cash equivalent balances and an increase in interest rates.

[0001193125-15-296113:mdna:163]
Interest expense. Our interest expense decreased by $0.3
million to $0.7 million for fiscal year 2014, compared with $1.0 million for fiscal year 2013. This decrease was due to decreases in our average long-term loan balances resulting from repayments during the year.

[0001193125-15-296113:mdna:164]
Income before income taxes. We recorded income before income taxes of $93.2 million
for fiscal year 2014, compared with $71.9 million for fiscal year 2013.

[0001193125-15-296113:mdna:165]
Income tax expense. Our provision for income
tax reflects an effective tax rate of 1.5% for fiscal year 2014, compared with an effective tax rate of 4.1% for fiscal year 2013. The decrease was primarily due to the reversal of liability for uncertain tax positions in fiscal year 2014, including
accrued interest of $1.5 million, an increase in deferred tax assets of $0.6 million and the fact that we had lower taxable income during fiscal year 2014 because the income related to flooding of $44.7 million in fiscal year 2014 was not subjected
to income tax, as compared with $27.2 million of income related to flooding during fiscal year 2013 that was not subject to income tax and the reversal of liability for uncertain tax positions of $0.6 million for fiscal year 2013.

[0001193125-15-296113:mdna:166]
Net income. We recorded net income of $91.7 million, or 13.5% of total revenues, for fiscal year 2014, compared with a net income
of $69.0 million, or 10.7% of total revenues, for fiscal year 2013.

[0001193125-15-296113:mdna:167]
Liquidity and Capital Resources

[0001193125-15-296113:mdna:168]
We primarily finance our operations through cash flow from operations activities. As of June 26, 2015, June 27, 2014, and
June 28, 2013, we had cash, cash equivalents, and marketable securities of $255.8 million, $233.5 million, and $149.7 million, respectively, and outstanding debt of $40.5 million, $16.5 million, and $28.9 million, respectively.

[0001193125-15-296113:mdna:169]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits and liquid investments with original maturities
of three months or less, are placed with banks and other financial institutions. The weighted average interest rate on our cash and cash equivalents for fiscal year 2015, fiscal year 2014, and fiscal year 2013 was 0.7%, 1.0% and 0.9%, respectively.

[0001193125-15-296113:mdna:170]
Our cash investments are made in accordance with an investment policy approved by the Audit Committee of our Board of
Directors. In general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed income securities are primarily classified
as available-for-sale securities and are recorded at fair value. The cost of securities sold is based on the specific identification method. Unrealized gains and losses on these securities are recorded as other comprehensive income (loss) and are
reported as a separate component of shareholders’ equity.

[0001193125-15-296113:mdna:171]
For fiscal year 2015, we borrowed $ 30.0 million under
our Facility Agreement in order to purchase land and a building in the United States. In addition to better manage our cash on hand, we invested in short-term marketable securities of $ 203.4 million.

[0001193125-15-296113:mdna:172]
As of June 27, 2014, we had settled all insurance claims for flood-related losses. We recognized $45.2 million of income related to
flooding in fiscal year 2014, which consisted of a payment from our insurers against our claims for owned and customer-owned equipment and inventory, offset by the recognition of $0.5 million of other expense from write-offs of advance payments to a
customer due to flood-related losses.

[0001193125-15-296113:mdna:173]
For fiscal year 2013, we recognized $29.4 million of income related to flooding, which
consisted of an interim payment from our insurers of $16.2 million against our claims for owned inventory losses and owned equipment losses, a payment from our insurer of $13.1 million in full and final settlement of our claim for business
interruption losses, and a payment from our insurer of $0.1 million in full and final settlement of our claim for damage to our buildings at Pinehurst. For fiscal year 2013, we recognized additional expenses of $2.2 million related to liabilities to
third parties due to flood losses.

[0001193125-15-296113:mdna:174]
During fiscal year 2014, we fulfilled our obligations to a customer in accordance with a
settlement agreement entered into during the third quarter of fiscal year 2013 by making a final cash payment of $5.3 million and transferring equipment with an aggregate value of $2.3 million to a customer. In addition, we

[0001193125-15-296113:mdna:175]
fulfilled our obligations to a customer’s insurers in accordance with a settlement agreement entered into during the fourth quarter of fiscal year 2013 by making a final payment of $2.3
million.

[0001193125-15-296113:mdna:176]
During fiscal year 2013, we entered into a settlement agreement with three of our customers relating to our
liability for the customers’ losses as a result of the flooding and made an initial aggregate payment of $8.1 million to such customers.

[0001193125-15-296113:mdna:177]
We believe that our current cash, cash equivalents, marketable securities, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and
capital expenditure needs for the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Item 1A of this Annual Report on Form 10-K.

[0001193125-15-296113:mdna:178]
We believe that our current manufacturing capacity, including our new facility in the United States, is sufficient to meet anticipated
production requirements for at least the next 12 months. We maintain a long-term credit facility associated with construction of production facilities at our Pinehurst campus in Thailand that will come due within the next 21 months, and we
anticipate that our internally generated working capital, together with our cash and cash equivalents will be adequate to repay this obligation.

[0001193125-15-296113:mdna:179]
The following table shows our cash flows for the periods indicated:

[0001193125-15-296113:mdna:180]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26, 2015 |  |  | June 27, 2014 |  |  | June 28, 2013 |  |
| Net cash provided by operating activities |  | $ | 52,629 |  |  | $ | 66,550 |  |  | $ | 48,750 |  |
| Net cash (used in) provided by investing activities |  | $ | (195,499 | ) |  | $ | 26,988 |  |  | $ | (5,862 | ) |
| Net cash provided by (used in) financing activities |  | $ | 22,537 |  |  | $ | (8,171 | ) |  | $ | (9,128 | ) |
| Net (decrease) increase in cash and cash equivalents |  | $ | (120,333 | ) |  | $ | 85,367 |  |  | $ | 33,760 |  |
| Cash and cash equivalents, beginning of period |  | $ | 233,477 |  |  | $ | 149,716 |  |  | $ | 115,507 |  |
| Cash and cash equivalents, end of period |  | $ | 112,978 |  |  | $ | 233,477 |  |  | $ | 149,716 |  |

[0001193125-15-296113:mdna:181]
Operating Activities

[0001193125-15-296113:mdna:182]
Net cash provided by operating activities decreased by $13.9 million, or 20.9%, to $52.6 million for fiscal year 2015, compared with net
cash provided by operating activities of $66.6 million for fiscal year 2014. This decrease was primarily due to a decrease of $51.2 million in cash collection from customers, off-set with a decrease of $2.8 million in cash payment to vendor and a
decrease of $29.6 million in inventory as a result of higher customer demand during fiscal year 2015.

[0001193125-15-296113:mdna:183]
Net cash provided by
operating activities increased by $17.8 million, or 36.5%, to $66.6 million for fiscal year 2014, compared with net cash provided by operating activities of $48.8 million for fiscal year 2013. The increase was primarily due to an increase in net
income from operations, a decrease of $34.5 million in flood-related liabilities to third parties, as we fulfilled our payment obligations to our customers under settlement agreements entered into during fiscal year 2014 and fiscal year 2013, a
decrease of $26.6 million in cash payment to vendor, and an increase of $12.6 million in cash collection from customers which were offset by an increase of $50.3 million in inventory.

[0001193125-15-296113:mdna:184]
Investing Activities

[0001193125-15-296113:mdna:185]
Net cash used in investing activities increased by $222.5 million, or 824.4%, to $195.5 million for fiscal year 2015, compared with net cash provided by investing activities of $27.0 million for fiscal
year 2014. The increase in net cash used in investing activities was primarily due to an increase of $144.0 million in short-term investment in marketable securities, an increase of $40.6 million in purchase of property, plant, and equipment to
support new facility in the United States, and a decrease of $37.8 million in proceeds against claims related to flood damage to consigned and owned equipment.

[0001193125-15-296113:mdna:186]
Net cash provided by investing activities increased by $32.9 million, or 560.4%, to $27.0
million for fiscal year 2014, compared with net cash used in investing activities of $5.9 million for fiscal year 2013. The increase in net cash provided by investing activities was primarily due to the receipt of $37.8 million in proceeds against
claims related to flood damage to consigned and owned equipment.

[0001193125-15-296113:mdna:187]
Financing Activities

[0001193125-15-296113:mdna:188]
Net cash provided by financing activities increased by $30.7 million, or 375.8%, to $22.5 million for fiscal year 2015, compared with net
cash used in financing activities of $8.2 million for fiscal year 2014. This increase was primarily due to an increase in proceeds from a revolving loan of $30.0 million to purchase land and a building for a new facility in the United States and a
decrease in repayment of a long-term loan from a bank of $6.0 million, off-set with the payment of debt issuance costs of $1.9 million and a decrease in proceeds from the issuance of ordinary shares under employee share option plans of $3.7 million.

[0001193125-15-296113:mdna:189]
Net cash used in financing activities decreased by $1.0 million, or 10.5%, to $8.2 million for fiscal year 2014, compared
with net cash used in financing activities of $9.1 million for fiscal year 2013. This decrease was primarily due to an increase of $4.0 million from the proceeds from issuance of ordinary shares under employee share option plans, offset by an
increase of $2.7 million from the early repayment of long-term loans for Pinehurst Building 5.

[0001193125-15-296113:mdna:190]
Contractual Obligations

[0001193125-15-296113:mdna:191]
The following table sets forth certain of our contractual obligations as of June 26, 2015:

[0001193125-15-296113:mdna:192]
|  |  | Payments Due by Period |  |
| (amount in thousands) |  | Total |  |  | Less than 1year |  |  | 1-3 years |  |  | 3-5 years |  |  | More than 5years |  |
| Long-term debt obligations |  | $ | 10,500 |  |  | $ | 6,000 |  |  | $ | 4,500 |  |  | $ | — |  |  | $ | — |  |
| Interest expense obligation (1) |  |  | 329 |  |  |  | 259 |  |  |  | 70 |  |  |  | — |  |  |  | — |  |
| Operating lease obligations |  |  | 3,891 |  |  |  | 1,153 |  |  |  | 1,958 |  |  |  | 780 |  |  |  | — |  |
| Severance liabilities (2) |  |  | 5,477 |  |  |  | 389 |  |  |  | 379 |  |  |  | 513 |  |  |  | 4,196 |  |
| Provision for uncertain income tax position |  |  | 1,575 |  |  |  | — |  |  |  | 459 |  |  |  | 564 |  |  |  | 552 |  |
| Total |  | $ | 21,772 |  |  | $ | 7,801 |  |  | $ | 7,366 |  |  | $ | 1,857 |  |  | $ | 4,748 |  |

[0001193125-15-296113:mdna:193]
| (1) | Interest expense obligation reflects the interest rate on long-term debt obligation as of June 26, 2015. The interest rate was 3.1%. For further discussion of long-term and short-term debt obligations, see Note 11 of our audited consolidated financial statements. |

[0001193125-15-296113:mdna:194]
| (2) | Severance liabilities as of June 26, 2015 are determined based on management assumptions, see Note 12 of our audited consolidated financial statements. |

[0001193125-15-296113:mdna:195]
As of June 26, 2015, our long-term debt obligations consisted of approximately $10.5 million outstanding under a loan agreement. The loan is secured by certain property, plant and equipment and
prescribes maximum ratios of debt to equity and minimum levels of debt service coverage ratios (i.e., earnings before interest expenses and depreciation and amortization plus cash on hand minus short-term debts divided by current portion of
long-term debts plus interest expenses). These financial ratio covenants could restrict our ability to incur additional indebtedness and limit our ability to use our cash. Our long-term debt obligation also include customary events of default.

[0001193125-15-296113:mdna:196]
As of June 26, 2015, we were in compliance with our long-term loan agreements. Nonetheless, in the event of a default on
these loans or a breach of a financial ratio covenant, the lenders may immediately cancel the loan agreements, deem the full amount of the outstanding indebtedness immediately due and payable; charge us

[0001193125-15-296113:mdna:197]
interest on a monthly basis on the full amount of the outstanding indebtedness and, if we cannot repay all of our outstanding obligations, sell the assets pledged as collateral for the loans in
order to fulfill our obligations to the lenders. We may also be held responsible for any damages and related expenses incurred by the lender as a result of any default.

[0001193125-15-296113:mdna:198]
We entered into a syndicated senior credit facility agreement (the “Facility Agreement”) with a consortium of banks on May 22, 2014. The Facility Agreement, led by Bank of America, provides
for a $200.0 million credit line, comprised of a $150.0 million revolving loan facility and a $50.0 million delayed draw term loan facility. The revolving loan facility contains an accordion feature permitting us to request an increase in the
facility up to $100.0 million subject to customary terms and conditions and provided that no default or event of default exists at the time of request. The revolving loan facility terminates and all amounts outstanding are due and payable in full on
May 22, 2019. The principal amount of any drawn term loans must be repaid according to the scheduled quarterly amortization payments, with final payment of all amounts outstanding, plus accrued interest, being due May 22, 2019.

[0001193125-15-296113:mdna:199]
On February 26, 2015, we entered into the Second Amendment to the Facility Agreement. The amendment extended the availability period
for draws on the term loan facility from May 21, 2015 to July 31, 2015. It also allows us, upon the satisfaction of certain conditions, to designate from time to time one or more of Fabrinet’s subsidiaries as borrowers under the
Facility Agreement. On July 31, 2015, we entered into the Third Amendment to the Facility Agreement. The amendment extended the availability period for draws on the term loan facility from July 31, 2015 to July 31, 2016.

[0001193125-15-296113:mdna:200]
As of June 26, 2015, the outstanding revolving borrowing under the Facility Agreement was $30.0 million, resulting in available
credit facilities of $170.0 million.

[0001193125-15-296113:mdna:201]
As of June 26, 2015, we also had certain operating lease arrangements in which the
lease payments are calculated based on specified formulas. Our rental expenses under these leases were $1.1 million, $0.8 million, and $0.8 million for fiscal year 2015, fiscal year 2014, and fiscal year 2013, respectively.

[0001193125-15-296113:mdna:202]
Capital Expenditures

[0001193125-15-296113:mdna:203]
The following table sets forth our capital expenditures, which include amounts for which payments have been accrued, for the periods
indicated.

[0001193125-15-296113:mdna:204]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26, 2015 |  |  | June 27, 2014 |  |  | June 28, 2013 |  |
| Capital expenditures |  | $ | 56,130 |  |  | $ | 10,604 |  |  | $ | 9,284 |  |

[0001193125-15-296113:mdna:205]
Our capital expenditures for fiscal year 2014 and fiscal year 2013 principally consisted of investment in
equipment for our manufacturing facilities. During fiscal year 2015, our capital expenditures consisted of purchase of property and equipment. During fiscal year 2016, we expect to purchase additional equipment for our new manufacturing facility in
the United States.

[0001193125-15-296113:mdna:206]
Off-Balance Sheet Commitments and Arrangements

[0001193125-15-296113:mdna:207]
As of June 26, 2015, we did not have any off-balance sheet arrangements as defined in Item 303(a)(4)(ii) of SEC Regulation S-K.

[0001193125-15-296113:mdna:208]
Recent Accounting Pronouncements

[0001193125-15-296113:mdna:209]
See Note 2 of the Notes to Consolidated Financial Statements for recent accounting pronouncements that could have an effect on us.
