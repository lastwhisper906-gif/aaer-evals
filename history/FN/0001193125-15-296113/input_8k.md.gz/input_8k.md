# FN 8-K — 0001193125-15-293289 filed 2015-08-17

## item codes, every 8-K on or before 2015-08-19

- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2015-08-19

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-293289:8k_2_02:1]
EX-99.1
2
d63819dex991.htm
EX-99.1

[0001193125-15-293289:8k_2_02:2]
EX-99.1

[0001193125-15-293289:8k_2_02:3]
Exhibit 99.1

[0001193125-15-293289:8k_2_02:4]
Fabrinet Announces Fourth Quarter and Fiscal-Year 2015 Financial Results

[0001193125-15-293289:8k_2_02:5]
BANGKOK, Thailand – August 17, 2015 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical,
electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for the fourth quarter and fiscal year ended June 26, 2015.

[0001193125-15-293289:8k_2_02:6]
Fabrinet reported total revenue of $206.5 million for the fourth quarter of fiscal year 2015, its highest quarterly revenue to-date and an increase of 29%
compared to total revenue of $160.1 million for the comparable period in fiscal year 2014. GAAP net income for the fourth quarter of fiscal year 2015 was $13.0 million, or $0.36 per diluted share, compared to GAAP net income of $10.3 million, or
$0.29 per diluted share, in the fourth quarter of fiscal year 2014. Non-GAAP net income in the fourth quarter of fiscal 2015 was $14.5 million, or $0.40 per diluted share, an increase of 20% compared to non-GAAP net income of $12.1 million, or $0.34
per diluted share, in the same period a year ago.

[0001193125-15-293289:8k_2_02:7]
For fiscal year 2015, Fabrinet reported total revenue of $773.6 million, an increase of 14% compared to
total revenue of $677.9 million for fiscal year 2014. GAAP net income for fiscal year 2015 was $43.6 million, or $1.21 per diluted share, compared to GAAP net income of $91.7 million, or $2.58 per diluted share, in fiscal year 2014. GAAP net income
in fiscal 2014 was positively impacted by $44.0 million, or $1.24 per diluted share, due to the collection of insurance proceeds. Non-GAAP net income in fiscal year 2015 was $56.4 million, or $1.57 per diluted share, an increase of 3% compared to
non-GAAP net income of $54.6 million, or $1.53 per diluted share, in fiscal year 2014.

[0001193125-15-293289:8k_2_02:8]
Tom Mitchell, Chief Executive Officer of Fabrinet, said, “We
ended fiscal 2015 on a strong note with record revenue and growth across all our market segments. As we start fiscal 2016, I am confident that our initiatives to expand our new product introduction and advanced packaging capabilities, combined with
our focus on total customer satisfaction and world-class quality will enable us to deliver another year of profitable growth in fiscal 2016.”

[0001193125-15-293289:8k_2_02:9]
Business Outlook

[0001193125-15-293289:8k_2_02:10]
Based on information available as of
August 17, 2015, Fabrinet is issuing guidance for the first quarter of fiscal 2016 as follows:

[0001193125-15-293289:8k_2_02:11]
Fabrinet expects first quarter revenue to be in the
range of $206 million to $210 million. GAAP net income per diluted share is expected to be in the range of $0.33 to $0.35 with expected non-GAAP net income per diluted share of $0.41 to $0.43, based on approximately 36.5 million fully diluted
shares outstanding.

[0001193125-15-293289:8k_2_02:12]
Conference Call Information

[0001193125-15-293289:8k_2_02:13]
| What: |  | Fabrinet Fourth Quarter and Fiscal-Year 2015 Financial Results Conference Call |
| When: |  | Monday, August 17, 2015 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic |
|  |  | (253) 237-1137, international |
|  |  | Passcode: 82275347 |
| Replay: |  | (855) 859-2056, domestic |
|  |  | (404) 537-3406, international |
|  |  | Passcode: 82275347 |
| Webcast: |  | http://investor.fabrinet.com (live and replay) |

[0001193125-15-293289:8k_2_02:14]
This press release and any other information related to the call will also be posted on Fabrinet’s website at
http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-15-293289:8k_2_02:15]
About Fabrinet

[0001193125-15-293289:8k_2_02:16]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original
equipment manufacturers of complex products, such as optical communication components, modules and subsystems, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire
manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and test. Fabrinet focuses on production of high complexity products in any mix and any volume.
Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the People’s Republic of China and the United States. For more information visit: www.fabrinet.com.

[0001193125-15-293289:8k_2_02:17]
Forward-Looking Statements

[0001193125-15-293289:8k_2_02:18]
Use of Non-GAAP Financials

[0001193125-15-293289:8k_2_02:19]
The Company refers to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information
regarding the Company’s ongoing operational performance. Non-GAAP net income excludes share-based compensation expenses, follow-on offering expenses, executive separation cost, investigation cost and income related to flooding. We have excluded
these items in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their
corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001193125-15-293289:8k_2_02:20]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our
competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure company
performance for the purposes of determining employee incentive plan compensation.

[0001193125-15-293289:8k_2_02:21]
SOURCE: Fabrinet

[0001193125-15-293289:8k_2_02:22]
Investor Contact:

[0001193125-15-293289:8k_2_02:23]
John Marchetti

[0001193125-15-293289:8k_2_02:24]
203-990-0148

[0001193125-15-293289:8k_2_02:25]
ir@fabrinet.com

[0001193125-15-293289:8k_2_02:26]
Fabrinet

[0001193125-15-293289:8k_2_02:27]
Consolidated Balance Sheets

[0001193125-15-293289:8k_2_02:28]
As of June 26, 2015 and June 27, 2014

[0001193125-15-293289:8k_2_02:29]
| (in thousands of U.S. dollars, except share data) |  | June 26,2015 |  |  | June 27,2014 |  |
| Assets |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 112,978 |  |  | $ | 233,477 |  |
| Marketable securities |  |  | 142,866 |  |  |  | — |  |
| Trade accounts receivable, net |  |  | 134,952 |  |  |  | 101,168 |  |
| Inventory, net |  |  | 130,613 |  |  |  | 124,570 |  |
| Deferred tax assets |  |  | 1,662 |  |  |  | 1,561 |  |
| Prepaid expenses |  |  | 2,135 |  |  |  | 1,691 |  |
| Other current assets |  |  | 1,833 |  |  |  | 2,010 |  |
| Total current assets |  |  | 527,039 |  |  |  | 464,477 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 140,654 |  |  |  | 97,244 |  |
| Intangibles, net |  |  | 137 |  |  |  | 72 |  |
| Deferred tax assets |  |  | 2,249 |  |  |  | 1,775 |  |
| Deferred debt issuance costs |  |  | 2,424 |  |  |  | 989 |  |
| Total non-current assets |  |  | 145,464 |  |  |  | 100,080 |  |
| Total assets |  | $ | 672,503 |  |  | $ | 564,557 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Bank borrowings, including revolving loan and current portion of long-term loans from banks |  | $ | 36,000 |  |  | $ | 6,000 |  |
| Trade accounts payable |  |  | 115,319 |  |  |  | 94,853 |  |
| Income tax payable |  |  | 1,470 |  |  |  | 1,024 |  |
| Accrued payroll, bonus and related expenses |  |  | 9,804 |  |  |  | 8,612 |  |
| Accrued expenses |  |  | 6,405 |  |  |  | 4,345 |  |
| Other payables |  |  | 12,050 |  |  |  | 5,795 |  |
| Total current liabilities |  |  | 181,048 |  |  |  | 120,629 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term loans from bank, non-current portion |  |  | 4,500 |  |  |  | 10,500 |  |
| Deferred tax liability |  |  | 737 |  |  |  | 1,040 |  |
| Severance liabilities |  |  | 5,477 |  |  |  | 4,453 |  |
| Other non-current liabilities |  |  | 1,797 |  |  |  | 1,099 |  |
| Total non-current liabilities |  |  | 12,511 |  |  |  | 17,092 |  |
| Total liabilities |  |  | 193,559 |  |  |  | 137,721 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of June 26, 2015 and June 27, 2014) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 35,437,654 shares and 35,152,772 shares issued and outstanding as of June 26, 2015 and June 27, 2014, respectively) |  |  | 354 |  |  |  | 352 |  |
| Additional paid-in capital |  |  | 89,390 |  |  |  | 80,882 |  |
| Retained earnings |  |  | 389,244 |  |  |  | 345,602 |  |
| Accumulated other comprehensive loss |  |  | (44 | ) |  |  | — |  |
| Total shareholders’ equity |  |  | 478,944 |  |  |  | 426,836 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 672,503 |  |  | $ | 564,557 |  |

[0001193125-15-293289:8k_2_02:30]
Fabrinet

[0001193125-15-293289:8k_2_02:31]
Consolidated Statements of Operations and Comprehensive Income

[0001193125-15-293289:8k_2_02:32]
For the three and twelve months ended June 26, 2015 and June 27, 2014

[0001193125-15-293289:8k_2_02:33]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | June 26, |  |  | June 27, |  |  | June 26, |  |  | June 27, |  |
| (in thousands of U.S. dollars, except share data) |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Revenues |  | $ | 206,456 |  |  | $ | 160,084 |  |  | $ | 773,587 |  |  | $ | 677,854 |  |
| Cost of revenues |  |  | (181,907 | ) |  |  | (142,309 | ) |  |  | (685,814 | ) |  |  | (603,621 | ) |
| Gross profit |  |  | 24,549 |  |  |  | 17,775 |  |  |  | 87,773 |  |  |  | 74,233 |  |
| Selling, general and administrative expenses |  |  | (10,739 | ) |  |  | (6,705 | ) |  |  | (39,460 | ) |  |  | (27,664 | ) |
| Income related to flooding |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 44,748 |  |
| Restructuring charge |  |  | — |  |  |  | — |  |  |  | (1,153 | ) |  |  | — |  |
| Operating income |  |  | 13,810 |  |  |  | 11,070 |  |  |  | 47,160 |  |  |  | 91,317 |  |
| Interest income |  |  | 297 |  |  |  | 531 |  |  |  | 1,253 |  |  |  | 1,793 |  |
| Interest expense |  |  | (241 | ) |  |  | (147 | ) |  |  | (616 | ) |  |  | (713 | ) |
| Foreign exchange gain (loss), net |  |  | 91 |  |  |  | (70 | ) |  |  | (19 | ) |  |  | (24 | ) |
| Other (expense) income |  |  | (46 | ) |  |  | 253 |  |  |  | (152 | ) |  |  | 797 |  |
| Income before income taxes |  |  | 13,911 |  |  |  | 11,637 |  |  |  | 47,626 |  |  |  | 93,170 |  |
| Income tax expense |  |  | (876 | ) |  |  | (1,304 | ) |  |  | (3,984 | ) |  |  | (1,439 | ) |
| Net income |  |  | 13,035 |  |  |  | 10,333 |  |  |  | 43,642 |  |  |  | 91,731 |  |
| Other comprehensive loss, before tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in fair value of marketable securities |  |  | (150 | ) |  |  | — |  |  |  | (193 | ) |  |  | — |  |
| Less: Reclassification adjustment for net loss realized and included in net income |  |  | 80 |  |  |  | — |  |  |  | 149 |  |  |  | — |  |
| Total change in unrealized loss on marketable securities, before tax |  |  | (70 | ) |  |  | — |  |  |  | (44 | ) |  |  | — |  |
| Income tax expense related to items of other comprehensive loss |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total other comprehensive loss, net of tax |  |  | (70 | ) |  |  | — |  |  |  | (44 | ) |  |  | — |  |
| Net comprehensive income |  | $ | 12,965 |  |  | $ | 10,333 |  |  | $ | 43,598 |  |  | $ | 91,731 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.37 |  |  | $ | 0.29 |  |  | $ | 1.23 |  |  | $ | 2.63 |  |
| Diluted |  | $ | 0.36 |  |  | $ | 0.29 |  |  | $ | 1.21 |  |  | $ | 2.58 |  |
| Weighted average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 35,431 |  |  |  | 35,117 |  |  |  | 35,354 |  |  |  | 34,938 |  |
| Diluted |  |  | 36,320 |  |  |  | 35,843 |  |  |  | 35,984 |  |  |  | 35,589 |  |

[0001193125-15-293289:8k_2_02:34]
Fabrinet

[0001193125-15-293289:8k_2_02:35]
Consolidated Statements of Cash Flows

[0001193125-15-293289:8k_2_02:36]
For the twelve
months ended June 26, 2015 and June 27, 2014

[0001193125-15-293289:8k_2_02:37]
|  |  | Twelve Months Ended |  |
| (in thousands of U. S. dollars) |  | June 26,2015 |  |  | June 27,2014 |  |
| Cash flows from operating activities |  |
| Net income for the year |  | $ | 43,642 |  |  | $ | 91,731 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 12,878 |  |  |  | 10,565 |  |
| Amortization of intangibles |  |  | 69 |  |  |  | 93 |  |
| Gain on disposal of property, plant and equipment |  |  | (42 | ) |  |  | (28 | ) |
| Loss from sales and maturities of marketable securities |  |  | 120 |  |  |  | — |  |
| Amortization of investment premium |  |  | 985 |  |  |  | — |  |
| Amortization of deferred debt issuance costs |  |  | 527 |  |  |  | — |  |
| Income related to flooding |  |  | — |  |  |  | (45,211 | ) |
| Proceeds from insurers for inventory losses related to flooding |  |  | — |  |  |  | 7,416 |  |
| Allowance for doubtful accounts (reversal of) |  |  | 13 |  |  |  | (72 | ) |
| Unrealized loss on exchange rate and fair value of derivative |  |  | 671 |  |  |  | 722 |  |
| Share-based compensation |  |  | 8,027 |  |  |  | 5,547 |  |
| Deferred income tax |  |  | (878 | ) |  |  | 65 |  |
| Other non-cash expenses |  |  | 1,722 |  |  |  | 634 |  |
| Reversal of uncertain tax position |  |  | — |  |  |  | (1,538 | ) |
| Inventory obsolescence |  |  | 397 |  |  |  | 443 |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | (33,797 | ) |  |  | 17,379 |  |
| Inventory |  |  | (6,440 | ) |  |  | (36,051 | ) |
| Other current assets and non-current assets |  |  | (283 | ) |  |  | (1,035 | ) |
| Trade accounts payable |  |  | 20,466 |  |  |  | 17,714 |  |
| Income tax payable |  |  | 446 |  |  |  | 737 |  |
| Other current liabilities and non-current liabilities |  |  | 4,106 |  |  |  | 4,951 |  |
| Liabilities to third parties due to flood losses |  |  | — |  |  |  | (7,512 | ) |
| Net cash provided by operating activities |  |  | 52,629 |  |  |  | 66,550 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of marketable securities |  |  | (203,407 | ) |  |  | — |  |
| Proceeds from sales of marketable securities |  |  | 29,036 |  |  |  | — |  |
| Proceeds from maturities of marketable securities |  |  | 30,356 |  |  |  | — |  |
| Purchase of property, plant and equipment |  |  | (51,398 | ) |  |  | (10,835 | ) |
| Purchase of intangibles |  |  | (134 | ) |  |  | (1 | ) |
| Proceeds from disposal of property, plant and equipment |  |  | 48 |  |  |  | 29 |  |
| Proceeds from insurers in settlement of claims related to flood damage |  |  | — |  |  |  | 37,795 |  |
| Net cash (used in) provided by investing activities |  |  | (195,499 | ) |  |  | 26,988 |  |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Payment of debt issuance costs |  |  | (1,946 | ) |  |  | — |  |
| Proceeds from revolving loans |  |  | 30,000 |  |  |  | — |  |
| Repayment of long-term loans from bank |  |  | (6,000 | ) |  |  | (12,411 | ) |
| Proceeds from issuance of ordinary shares under employee share option plans |  |  | 835 |  |  |  | 4,567 |  |
| Withholding tax related to net share settlement of restricted share units |  |  | (352 | ) |  |  | (327 | ) |
| Net cash provided by (used in) financing activities |  |  | 22,537 |  |  |  | (8,171 | ) |
| Net (decrease) increase in cash and cash equivalents |  | $ | (120,333 | ) |  | $ | 85,367 |  |

[0001193125-15-293289:8k_2_02:38]
Fabrinet

[0001193125-15-293289:8k_2_02:39]
Consolidated Statements of Cash Flows (continued)

[0001193125-15-293289:8k_2_02:40]
For
the twelve months ended June 26, 2015 and June 27, 2014

[0001193125-15-293289:8k_2_02:41]
|  |  | Twelve Months Ended |  |
| (in thousands of U. S. dollars) |  | June 26,2015 |  |  | June 27,2014 |  |
| Movement in cash and cash equivalents |  |  |  |  |  |  |  |  |
| Cash and cash equivalents at beginning of period |  | $ | 233,477 |  |  | $ | 149,716 |  |
| (Decrease) increase in cash and cash equivalents |  |  | (120,333 | ) |  |  | 85,367 |  |
| Effect of exchange rate on cash and cash equivalents |  |  | (166 | ) |  |  | (1,606 | ) |
| Cash and cash equivalents at end of period |  | $ | 112,978 |  |  | $ | 233,477 |  |

[0001193125-15-293289:8k_2_02:42]
Fabrinet

[0001193125-15-293289:8k_2_02:43]
Reconciliation of GAAP measures to non-GAAP measures

[0001193125-15-293289:8k_2_02:44]
(in thousands of U.S. dollars, except per share data)

[0001193125-15-293289:8k_2_02:45]
(unaudited)

[0001193125-15-293289:8k_2_02:46]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | June 26, |  |  | June 26, |  |  | June 27, |  |  | June 27, |  |  | June 26, |  |  | June 26, |  |  | June 27, |  |  | June 27, |  |
|  |  | 2015 |  |  | 2015 |  |  | 2014 |  |  | 2014 |  |  | 2015 |  |  | 2015 |  |  | 2014 |  |  | 2014 |  |
|  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |
| GAAP measures |  |  | 13,035 |  |  |  | 0.36 |  |  |  | 10,333 |  |  |  | 0.29 |  |  |  | 43,642 |  |  |  | 1.21 |  |  |  | 91,731 |  |  |  | 2.58 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 344 |  |  |  | 0.01 |  |  |  | 294 |  |  |  | 0.01 |  |  |  | 1,451 |  |  |  | 0.04 |  |  |  | 1,182 |  |  |  | 0.03 |  |
| Total related to gross profit |  |  | 344 |  |  |  | 0.01 |  |  |  | 294 |  |  |  | 0.01 |  |  |  | 1,451 |  |  |  | 0.04 |  |  |  | 1,182 |  |  |  | 0.03 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,878 |  |  |  | 0.05 |  |  |  | 715 |  |  |  | 0.02 |  |  |  | 6,577 |  |  |  | 0.18 |  |  |  | 4,365 |  |  |  | 0.12 |  |
| Executive separation cost |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 547 |  |  |  | 0.02 |  |
| Follow-on offering expenses |  |  | — |  |  |  | — |  |  |  | 344 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 344 |  |  |  | 0.01 |  |
| Investigation costs |  |  | (858 | ) |  |  | (0.02 | ) |  |  | 400 |  |  |  | 0.01 |  |  |  | 3,242 |  |  |  | 0.09 |  |  |  | 400 |  |  |  | 0.01 |  |
| Total related to selling, general and administrative expenses |  |  | 1,020 |  |  |  | 0.03 |  |  |  | 1,459 |  |  |  | 0.04 |  |  |  | 9,819 |  |  |  | 0.27 |  |  |  | 5,656 |  |  |  | 0.16 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income related to flooding |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (44,748 | ) |  |  | (1.26 | ) |
| Unrealized loss on exchange, net of interest incurred from income related to flooding |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 744 |  |  |  | 0.02 |  |
| Expenses related to reduction in workforce |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,153 |  |  |  | 0.03 |  |  |  | — |  |  |  | — |  |
| Amortization of debt issuance costs |  |  | 150 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |  |  | 527 |  |  |  | 0.02 |  |  |  | — |  |  |  | — |  |
| Total related to other incomes and other expenses |  |  | 150 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |  |  | 1,680 |  |  |  | 0.05 |  |  |  | (44,004 | ) |  |  | (1.24 | ) |
| Related to income tax expense |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (187 | ) |  |  | (0.01 | ) |  |  | — |  |  |  | — |  |
| Total related to income tax expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (187 | ) |  |  | (0.01 | ) |  |  | — |  |  |  | — |  |
| Total related to net income & EPS |  |  | 1,514 |  |  |  | 0.04 |  |  |  | 1,753 |  |  |  | 0.05 |  |  |  | 12,763 |  |  |  | 0.35 |  |  |  | (37,166 | ) |  |  | (1.05 | ) |
| Non-GAAP measures |  |  | 14,549 |  |  |  | 0.40 |  |  |  | 12,086 |  |  |  | 0.34 |  |  |  | 56,405 |  |  |  | 1.57 |  |  |  | 54,565 |  |  |  | 1.53 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 36,320 |  |  |  |  |  |  |  | 35,843 |  |  |  |  |  |  |  | 35,984 |  |  |  |  |  |  |  | 35,589 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 36,320 |  |  |  |  |  |  |  | 35,843 |  |  |  |  |  |  |  | 35,984 |  |  |  |  |  |  |  | 35,589 |  |
