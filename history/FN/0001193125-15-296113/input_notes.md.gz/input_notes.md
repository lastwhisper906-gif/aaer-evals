# FN notes — 0001193125-15-296113


## us-gaap:ScheduleOfEffectiveIncomeTaxRateReconciliationTableTextBlock

[0001193125-15-296113:notes:1]
The
 reconciliation between the Company’s taxes that would arise
 by applying the statutory tax rate of the country of the
 Company’s principal operations, Thailand, to the
 Company’s effective tax charge is shown below:

[0001193125-15-296113:notes:2]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26, 2015 |  |  | June 27, 2014 |  |  | June 28, 2013 |  |
| Income before income taxes (1) |  | $ | 47,626 |  |  | $ | 93,170 |  |  | $ | 71,909 |  |
| Tax expense calculated at a statutory corporate income tax rate of 20% (2014: 20% and 2013: 23%) |  |  | 9,525 |  |  |  | 18,634 |  |  |  | 16,539 |  |
| Effect of income taxes from locations with tax rates different from Thailand |  |  | 1,134 |  |  |  | (2 | ) |  |  | (457 | ) |
| Income not subject to tax (2) |  |  | (7,094 | ) |  |  | (15,648 | ) |  |  | (12,728 | ) |
| Income tax on unremitted earnings (reversal of) |  |  | 1,263 |  |  |  | (259 | ) |  |  | 466 |  |
| Effect of different tax rate in relation to deferred tax utilization (3) |  |  | (221 | ) |  |  | (662 | ) |  |  | (303 | ) |
| Effect of foreign exchange rate adjustment |  |  | (365 | ) |  |  | (380 | ) |  |  | (90 | ) |
| Tax rebate from research and development application |  |  | (102 | ) |  |  | — |  |  |  | — |  |
| Insurance proceeds from equipment claim due to flooding |  |  | — |  |  |  | — |  |  |  | (516 | ) |
| Reversal of reserve fixed assets damaged from flooding |  |  | — |  |  |  | (251 | ) |  |  | — |  |
| Others |  |  | (156 | ) |  |  | 7 |  |  |  | 29 |  |
| Corporate income tax expense |  | $ | 3,984 |  |  | $ | 1,439 |  |  | $ | 2,940 |  |

[0001193125-15-296113:notes:3]
| (1) | Income before income taxes was mostly generated from domestic income in the Cayman Islands. |

[0001193125-15-296113:notes:4]
| (2) | Income not subject to tax relates to income earned in the Cayman Islands, income subject to an investment promotion privilege for Building 5 and Building 6. Income not subject to tax per ordinary share on a diluted basis (in dollars) was $0.20, $0.44 and $0.37 for the years ended June 26, 2015, June 27, 2014 and June 28, 2013, respectively. |

[0001193125-15-296113:notes:5]
| (3) | The balances were effect of different tax rate in relation to the rate recognized deferred taxes in fiscal year 2015 and the rate when deferred taxes will be utilized in the following fiscal years. |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-15-296113:notes:6]
| 10. | Intangibles |

[0001193125-15-296113:notes:7]
The following
 tables present details of the Company’s
 intangibles:

[0001193125-15-296113:notes:8]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net |  |
| As of June 26, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 3,357 |  |  | $ | (3,220 | ) |  | $ | 137 |  |
| Total intangibles |  | $ | 3,357 |  |  | $ | (3,220 | ) |  | $ | 137 |  |

[0001193125-15-296113:notes:9]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net |  |
| As of June 27, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 3,458 |  |  | $ | (3,386 | ) |  | $ | 72 |  |
| Total intangibles |  | $ | 3,458 |  |  | $ | (3,386 | ) |  | $ | 72 |  |

[0001193125-15-296113:notes:10]
The Company
 recorded amortization expense relating to intangibles of $0.1
 million, $0.1 million and $0.2 million for the years ended
 June 26, 2015, June 27, 2014, and June 28,
 2013, respectively.

[0001193125-15-296113:notes:11]
Based on the
 carrying amount of intangibles as of June 26, 2015, and
 assuming no future impairment of the underlying assets, the
 estimated future amortization at the end of each fiscal year in
 June is as follows:

[0001193125-15-296113:notes:12]
| (amount in thousand) |  |  |  |
| 2016 |  | $ | 32 |  |
| 2017 |  |  | 28 |  |
| 2018 |  |  | 27 |  |
| 2019 |  |  | 27 |  |
| 2020 |  |  | 23 |  |
| Total |  | $ | 137 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001193125-15-296113:notes:13]
| 9. | Property, plant and equipment, net |

[0001193125-15-296113:notes:14]
The components
 of property, plant and equipment, net were as follows:

[0001193125-15-296113:notes:15]
| (amount in thousands) |  | Land |  |  | Building and Building Improvement |  |  | Manufacturing Equipment |  |  | Office Equipment |  |  | Motor Vehicles |  |  | Computers |  |  | Construction and Machinery Under Installation |  |  | Total |  |
| As of June 26, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost |  | $ | 26,672 |  |  | $ | 86,926 |  |  | $ | 79,825 |  |  | $ | 5,378 |  |  | $ | 528 |  |  | $ | 13,196 |  |  | $ | 10,198 |  |  | $ | 222,723 |  |
| Less: Accumulated depreciation |  |  | — |  |  |  | (21,016 | ) |  |  | (47,017 | ) |  |  | (3,343 | ) |  |  | (458 | ) |  |  | (10,235 | ) |  |  | — |  |  |  | (82,069 | ) |
| Net book value |  | $ | 26,672 |  |  | $ | 65,910 |  |  | $ | 32,808 |  |  | $ | 2,035 |  |  | $ | 70 |  |  | $ | 2,961 |  |  | $ | 10,198 |  |  | $ | 140,654 |  |
| As of June 27, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost |  | $ | 14,353 |  |  | $ | 73,353 |  |  | $ | 60,354 |  |  | $ | 5,376 |  |  | $ | 615 |  |  | $ | 12,044 |  |  | $ | 1,369 |  |  | $ | 167,464 |  |
| Less: Accumulated depreciation |  |  | — |  |  |  | (17,580 | ) |  |  | (39,100 | ) |  |  | (3,266 | ) |  |  | (608 | ) |  |  | (9,666 | ) |  |  | — |  |  |  | (70,220 | ) |
| Net book value |  | $ | 14,353 |  |  | $ | 55,773 |  |  | $ | 21,254 |  |  | $ | 2,110 |  |  | $ | 7 |  |  | $ | 2,378 |  |  | $ | 1,369 |  |  | $ | 97,244 |  |

[0001193125-15-296113:notes:16]
On
 February 24, 2015, one of Fabrinet’s subsidiaries
 purchased a building of approximately 74,000 square feet and the
 associated 4.05 acres of land located in Santa Clara, California,
 for the purpose of expanding the Company’s manufacturing
 facilities in the United States. The purchase price of the land and
 building was $12.3 million and $13.2 million,
 respectively.

[0001193125-15-296113:notes:17]
Depreciation
 expense amounted to $12.9 million, $10.6 million, and $10.0 million
 for the years ended June 26, 2015, June 27, 2014 and
 June 28, 2013, respectively and have been allocated between
 cost of revenues and selling, general and administrative expenses
 in the consolidated statements of operations and comprehensive
 income. During fiscal year 2014, we wrote-off all assets damaged
 from flood and reversed all asset impairment reserve due to we
 fully settled with insurance companies for our damaged assets
 claim.

[0001193125-15-296113:notes:18]
The cost of
 fully depreciated property, plant and equipment written-off during
 the years ended June 26, 2015, June 27, 2014, and
 June 28, 2013 amounted to $1.1 million, $2.6 million and $0.3
 million, respectively.

[0001193125-15-296113:notes:19]
There was no
 interest expense capitalized in construction in progress during the
 years ended June 26, 2015 and June 27, 2014,
 respectively.


## us-gaap:ScheduleOfAmountsRecognizedInBalanceSheetTableTextBlock

[0001193125-15-296113:notes:20]
The amount
 recognized in the consolidated balance sheets under non-current
 liabilities was determined as follows:

[0001193125-15-296113:notes:21]
| (amount in thousands) |  | As of June 26, 2015 |  |  | As of June 27, 2014 |  |
| Present value of defined benefit obligation |  | $ | 5,477 |  |  | $ | 4,453 |  |
| Total |  | $ | 5,477 |  |  | $ | 4,453 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-15-296113:notes:22]
The Company
 operates primarily in three geographic regions: North America,
 Asia-Pacific, and Europe. The following table presents total
 revenues by geographic regions:

[0001193125-15-296113:notes:23]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26, 2015 |  |  | June 27, 2014 |  |  | June 28, 2013 |  |
| North America |  | $ | 370,836 |  |  | $ | 326,647 |  |  | $ | 299,510 |  |
| Asia-Pacific |  |  | 309,941 |  |  |  | 230,314 |  |  |  | 218,393 |  |
| Europe |  |  | 92,810 |  |  |  | 120,893 |  |  |  | 123,639 |  |
| Total |  | $ | 773,587 |  |  | $ | 677,854 |  |  | $ | 641,542 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0001193125-15-296113:notes:24]
Total revenues,
 by percentage, from individual customers representing 10% or more
 of total revenues in the respective periods were as
 follows:

[0001193125-15-296113:notes:25]
|  |  | Years Ended |  |
|  |  | June 26, 2015 |  |  | June 27, 2014 |  |  | June 28, 2013 |  |
| JDS Uniphase Corporation |  |  | 20 | % |  |  | 24 | % |  |  | 22 | % |
| Oclaro, Inc. |  |  | 10 | % |  |  | 22 | % |  |  | 25 | % |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-15-296113:notes:26]
| 8. | Inventory |

[0001193125-15-296113:notes:27]
| (amount in thousands) |  | As of June 26, 2015 |  |  | As of June 27, 2014 |  |
| Raw materials |  | $ | 46,065 |  |  | $ | 40,885 |  |
| Work in progress |  |  | 69,174 |  |  |  | 56,376 |  |
| Finished goods |  |  | 11,843 |  |  |  | 22,970 |  |
| Goods in transit |  |  | 6,488 |  |  |  | 6,899 |  |
|  |  |  | 133,570 |  |  |  | 127,130 |  |
| Less: Inventory obsolescence |  |  | (2,957 | ) |  |  | (2,560 | ) |
| Inventory, net |  | $ | 130,613 |  |  | $ | 124,570 |  |


## us-gaap:DebtDisclosureTextBlock

[0001193125-15-296113:notes:28]
| 11. | Borrowings |

[0001193125-15-296113:notes:29]
The
 Company’s total borrowing, including revolving and long-term
 borrowings, consisted of the following:

[0001193125-15-296113:notes:30]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  |  | As of June 26, 2015 |  |  | As of June 27, 2014 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  |  | July 2015 | (2) |  | $ | 30,000 |  |  | $ | — |  |
| Current portion of long-term borrowing |  |  |  |  |  |  |  |  | 6,000 |  |  |  | 6,000 |  |
|  |  |  | $ | 36,000 |  |  | $ | 6,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  |  | March 2017 |  |  | $ | 10,500 |  |  | $ | 16,500 |  |
| Less: Current portion |  |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  | $ | 4,500 |  |  | $ | 10,500 |  |

[0001193125-15-296113:notes:31]
|  | (1) | LIBOR is London Interbank Offered Rate. |

[0001193125-15-296113:notes:32]
|  | (2) | On July 14, 2015, the Company sent a notice to the bank to renew the maturity date of this revolving borrowing. The bank approved the notice and extended the maturity date to August 20, 2015. |

[0001193125-15-296113:notes:33]
On
 April 25, 2014, a subsidiary of the Company entered into an
 amendment to the bank borrowing agreement. Under the amendment of
 the contract, the long-term loan is secured by certain property,
 plant and equipment. The carrying amount of assets secured and
 pledged as collateral as of June 26, 2015 and June 27,
 2014 was $50.0 million and $52.3 million, respectively. This
 subsidiary is also required to comply with the maximum ratios of
 debt to equity and minimum levels of debt service coverage ratios,
 and Fabrinet must maintain an effective shareholding ratio. The
 carrying amounts of bank borrowings approximate their fair
 value.

[0001193125-15-296113:notes:34]
As of
 June 26, 2015 and June 27, 2014, the Company was in
 compliance with its long-term bank borrowing agreement. In addition
 to financial ratios, certain of the Company’s credit
 facilities include customary events of default.

[0001193125-15-296113:notes:35]
The movements
 of long-term loans were as follows for years ended June 26,
 2015 and June 27, 2014:

[0001193125-15-296113:notes:36]
|  |  | Years ended |  |
| (amount in thousands) |  | June 26, 2015 |  |  | June 27, 2014 |  |
| Opening net book amount |  | $ | 16,500 |  |  | $ | 28,911 |  |
| Repayment during the period |  |  | (6,000 | ) |  |  | (12,411 | ) |
| Closing net book amount |  | $ | 10,500 |  |  | $ | 16,500 |  |

[0001193125-15-296113:notes:37]
As of
 June 26, 2015, future maturities of long-term debt were as
 follows at the end of each fiscal year below:

[0001193125-15-296113:notes:38]
| (amount in thousands) |  |  |  |
| 2016 |  | $ | 6,000 |  |
| 2017 |  |  | 4,500 |  |
| Total |  | $ | 10,500 |  |

[0001193125-15-296113:notes:39]
Credit
 facilities:

[0001193125-15-296113:notes:40]
Fabrinet
 entered into a syndicated senior credit facility agreement (the
 “Facility Agreement”) with a consortium of banks on
 May 22, 2014. The Facility Agreement, led by Bank of America,
 provides for a $200.0 million credit line, comprised of a $150.0
 million revolving loan facility and a $50.0 million delayed draw
 term loan facility. The revolving loan facility contains an
 accordion feature permitting Fabrinet to request an increase in the
 facility up to $100.0 million subject to customary terms and
 conditions and provided that no default or event of default exists
 at the time of request. The revolving loan facility terminates and
 all amounts outstanding are due and payable in full on May 22,
 2019. The principal amount of any drawn term loans must be repaid
 according to the scheduled quarterly amortization payments, with
 final payment of all amounts outstanding, plus accrued interest,
 being due May 22, 2019.

[0001193125-15-296113:notes:41]
On
 February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allows the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. As of
 June 26, 2015, the outstanding revolving borrowing under the
 Facility Agreement was $30.0 million, resulting in available credit
 facilities of $170.0 million. Borrowings under the revolving credit
 facility are classified as current liabilities in the audited
 consolidated balance sheet as the Company has the periodic option
 to renew, or pay all or a portion of, the outstanding balance at
 the end of the maturity date, which is in the range of 1 to 6
 months, without premium or penalty, upon notice to the
 administrative agent. On July 14, 2015, the Company sent a
 notice to the bank to renew the maturity date of this revolving
 borrowing. The bank approved the notice and extended the maturity
 date to August 20, 2015.

[0001193125-15-296113:notes:42]
Loans under
 the Facility Agreement bear interest, at Fabrinet’s option,
 at a rate per annum equal to a LIBOR rate plus a spread of 1.75% to
 2.50%, or a base rate, determined in accordance with the Facility
 Agreement, plus a spread of 0.75% to 1.50%, in each case with such
 spread determined based on Fabrinet’s consolidated total
 leverage ratio for the preceding four fiscal quarter period.
 Interest is due and payable quarterly in arrears for loans bearing
 interest at the base rate and at the end of an interest period (or
 at each three-month interval in the case of loans with interest
 periods greater than three months) in the case of loans bearing
 interest at the LIBOR rate.

[0001193125-15-296113:notes:43]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or the
 equivalent under the local law, can be effected. The Facility
 Agreement contains customary affirmative and negative covenants.
 Negative covenants include, among other things, limitations on
 liens, indebtedness, investments, mergers, sales of assets, changes
 in the nature of the business, dividends and distributions,
 affiliate transactions and capital expenditures. The Facility
 Agreement contains financial covenants requiring Fabrinet to
 maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage
 ratio of not more than 2.50:1.00; and (iv) a minimum quick
 ratio of not less than 1.10:1.00. Each of these financial covenants
 is calculated on a consolidated basis for the consecutive four
 fiscal quarter period then ended. As of June 26, 2015, the
 Company was in compliance with all covenants under the Facility
 Agreement.

[0001193125-15-296113:notes:44]
The Facility
 Agreement also contains customary events of default including,
 among other things, payment defaults, breaches of covenants or
 representations and warranties, cross-defaults with certain other
 indebtedness, bankruptcy and insolvency events and change in
 control of Fabrinet, subject to grace periods in certain instances.
 Upon an event of default, the lenders may terminate their
 commitments, declare all or a portion of the outstanding
 obligations payable by Fabrinet to be immediately due and payable
 and exercise other rights and remedies provided for under the
 Facility Agreement.

[0001193125-15-296113:notes:45]
Fabrinet
 intends to use the proceeds of the credit line to finance its
 future manufacturing buildings in the United States and Thailand,
 and for general corporate purposes including mergers and
 acquisitions of complementary manufacturing businesses or
 technology, although Fabrinet has no current commitments with
 respect to any such acquisitions.

[0001193125-15-296113:notes:46]
Undrawn
 available credit facilities classified by available period of
 future borrowing as of June 26, 2015 and June 27, 2014
 were as follows:

[0001193125-15-296113:notes:47]
| (amount in thousands) |  | June 26, 2015 |  |  | June 27, 2014 |  |
| Short-term |  | $ | 1,480 |  |  | $ | 1,539 |  |
| Long-term |  | $ | 170,000 |  |  | $ | — |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-15-296113:notes:48]
| 13. | Share-based compensation |

[0001193125-15-296113:notes:49]
Share-based compensation

[0001193125-15-296113:notes:50]
In
 determining the grant date fair value of equity awards, the Company
 is required to make estimates of the fair value of Fabrinet’s
 ordinary shares, expected dividends to be issued, expected
 volatility of Fabrinet’s ordinary shares, expected
 forfeitures of the awards, risk free interest rates for the
 expected term of the awards, expected terms of the awards, and the
 vesting period of the respective awards. Forfeitures are estimated
 at the time of grant and revised if necessary in subsequent periods
 if actual forfeitures differ from those estimates.

[0001193125-15-296113:notes:51]
The effect of
 recording share-based compensation expense for the years ended
 June 26, 2015, June 27, 2014 and June 28, 2013
 was as follows:

[0001193125-15-296113:notes:52]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26, 2015 |  |  | June 27, 2014 |  |  | June 28, 2013 |  |
| Share-based compensation expense by type of award: |  |  |  |  |
| Share options |  | $ | 226 |  |  | $ | 802 |  |  | $ | 1,864 |  |
| Restricted share units |  |  | 7,801 |  |  |  | 4,745 |  |  |  | 3,236 |  |
| Total share-based compensation expense |  |  | 8,027 |  |  |  | 5,547 |  |  |  | 5,100 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 8,027 |  |  | $ | 5,547 |  |  | $ | 5,100 |  |

[0001193125-15-296113:notes:53]
Share-based
 compensation expense was recorded in the consolidated statements of
 operations and comprehensive income as follows:

[0001193125-15-296113:notes:54]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26, 2015 |  |  | June 27, 2014 |  |  | June 28, 2013 |  |
| Cost of revenue |  | $ | 1,450 |  |  | $ | 1,182 |  |  | $ | 1,105 |  |
| Selling, general and administrative expense |  |  | 6,577 |  |  |  | 4,365 |  |  |  | 3,995 |  |
| Total share-based compensation expense |  | $ | 8,027 |  |  | $ | 5,547 |  |  | $ | 5,100 |  |

[0001193125-15-296113:notes:55]
The Company
 did not capitalize any share-based compensation expense as part of
 any asset costs during the years ended June 26,
 2015, June 27, 2014 and June 28, 2013.

[0001193125-15-296113:notes:56]
Share-based award activity

[0001193125-15-296113:notes:57]
Share options
 have been granted to directors and employees. As of June 26,
 2015, there were 6,590 share options outstanding under the Amended
 and Restated 1999 Share Option Plan (the “1999 Plan”).
 Additional option grants may not be made under the 1999
 Plan.

[0001193125-15-296113:notes:58]
In March
 2010, Fabrinet’s shareholders adopted the 2010 Performance
 Incentive Plan (the “2010 Plan”). On December 20,
 2010 and December 20, 2012, the 2010 Plan was amended to
 increase the number of shares reserved for issuance. As of
 June 26, 2015, there were an aggregate of 785,429 share
 options outstanding, 1,140,927 restricted share units outstanding
 and 2,939,135 ordinary shares available for future grant under the
 2010 Plan. The 1999 Plan and 2010 Plan are collectively referred to
 as the “Share Option Plans”.

[0001193125-15-296113:notes:59]
Share
 options

[0001193125-15-296113:notes:60]
Fabrinet’s board of directors has the authority to
 determine the type of option and the number of shares subject to an
 option. Options generally vest and become exercisable over four
 years and expire, if not exercised, within 7 years of the grant
 date. In the case of a grantee’s first grant, 25 percent of
 the underlying shares subject to an option vest 12 months after the
 vesting commencement date and 1/48 of the underlying shares vest
 monthly over each of the subsequent 36 months. In the case of any
 additional grants to a grantee, 1/48 of the underlying shares
 subject to an option vest monthly over four years, commencing one
 month after the vesting commencement date.

[0001193125-15-296113:notes:61]
The following
 table summarizes share options activity:

[0001193125-15-296113:notes:62]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 29, 2012 |  |  | 1,470,290 |  |  |  | 532,646 |  |  | $ | 14.88 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (94,188 | ) |  |  |  |  |  | $ | 5.96 |  |  |  |  |  |
| Forfeited |  |  | (44,443 | ) |  |  |  |  |  | $ | 17.33 |  |  |  |  |  |
| Expired |  |  | (54,348 | ) |  |  |  |  |  | $ | 16.97 |  |  |  |  |  |
| Balance as of June 28, 2013 |  |  | 1,277,311 |  |  |  | 750,949 |  |  | $ | 15.37 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (351,435 | ) |  |  |  |  |  | $ | 13.00 |  |  |  |  |  |
| Forfeited |  |  | (26,276 | ) |  |  |  |  |  | $ | 15.54 |  |  |  |  |  |
| Expired |  |  | (33,710 | ) |  |  |  |  |  | $ | 16.93 |  |  |  |  |  |
| Balance as of June 27, 2014 |  |  | 865,890 |  |  |  | 666,305 |  |  | $ | 16.27 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (56,968 | ) |  |  |  |  |  | $ | 14.67 |  |  |  |  |  |
| Forfeited |  |  | (8,347 | ) |  |  |  |  |  | $ | 15.90 |  |  |  |  |  |
| Expired |  |  | (8,556 | ) |  |  |  |  |  | $ | 21.44 |  |  |  |  |  |
| Balance as of June 26, 2015 |  |  | 792,019 |  |  |  | 758,451 |  |  | $ | 16.33 |  |  |  |  |  |
| Expected to vest as of June 26, 2015 |  |  | 789,048 |  |  |  |  |  |  | $ | 16.33 |  |  |  |  |  |

[0001193125-15-296113:notes:63]
The fair
 value of each grant of stock options was determined by the Company
 using the methods and assumptions discussed below. Each of these
 inputs is subjective and generally requires significant judgment
 and management estimate to determine.

[0001193125-15-296113:notes:64]
The total
 fair value of shares vested during the years ended June 26,
 2015, June 27, 2014, and June 28, 2013 was $1.1
 million, $2.0 million, and $2.4 million, respectively. The total
 intrinsic value of options exercised during the years ended
 June 26, 2015, June 27, 2014, and June 28, 2013
 was $0.2 million, $2.2 million, and $0.8 million, respectively. In
 conjunction with these exercises, there was no tax benefit realized
 by the Company due to the fact that it is exempted from income tax.
 The amount of cash received from the exercise of share options was
 $0.8 million during the year ended June 26, 2015.

[0001193125-15-296113:notes:65]
Valuation
 Method—The Company estimated the fair value of the
 Company’s ordinary shares to be used in the
 Black-Scholes-Merton (“BSM”) option-pricing formula by
 taking into consideration a number of assumptions.

[0001193125-15-296113:notes:66]
Expected
 Dividend—The Company used zero as an annualized dividend
 yield since it did not anticipate paying any cash dividends in the
 near future.

[0001193125-15-296113:notes:67]
Expected
 Volatility—The Company determined the expected volatility
 based on the Company’s historical volatility over the last 4
 years.

[0001193125-15-296113:notes:68]
Risk-Free
 Interest Rate—The Company based the risk-free interest
 rate on the implied yield currently available on U.S. Treasury
 zero-coupon issues with a remaining term equivalent to the expected
 term of the option.

[0001193125-15-296113:notes:69]
Expected
 Term—Expected terms used in the BSM option-pricing
 formula represent the periods that the company’s share
 options are expected to be outstanding and are determined based on
 the Company’s historical experience of similar awards, giving
 consideration to the contractual terms of the share options,
 vesting schedules and expectations of future employee
 behavior.

[0001193125-15-296113:notes:70]
Vesting
 Period—Fabrinet’s share options generally vest and
 become exercisable over a four-year period, and expire seven years
 from the date of grant. For an initial grant, 25 percent of the
 underlying shares subject to an option vest 12 months after the
 vesting commencement date and 1/48 of the underlying shares vest
 monthly over each of the subsequent 36 months. In the case of any
 additional grants to an optionee, 1/48 of the underlying shares
 subject to an option vest monthly over four years, commencing one
 month after the vesting commencement date.

[0001193125-15-296113:notes:71]
Fair
 Value—The fair value of Fabrinet’s share options
 granted to employees was estimated using the weighted-average
 assumptions of expected volatility, risk-free rate of return, and
 expected term.

[0001193125-15-296113:notes:72]
The following
 summarizes information for share options outstanding as of
 June 26, 2015 under the share options plan:

[0001193125-15-296113:notes:73]
|  |  | Number of Shares Underlying Options |  |  | Exercise Price Per Share |  |  | Weighted Average Remaining Contractual Life (years) |  |  | Aggregate Intrinsic Value (amount in thousands) |  |
|  |  |  | 6,590 |  |  | $ | 5.75 |  |  |  | 1.14 |  |  |  |  |  |
|  |  |  | 8,368 |  |  | $ | 13.77 |  |  |  | 2.16 |  |  |  |  |  |
|  |  |  | 416,526 |  |  | $ | 16.83 |  |  |  | 2.30 |  |  |  |  |  |
|  |  |  | 30,000 |  |  | $ | 15.05 |  |  |  | 2.36 |  |  |  |  |  |
|  |  |  | 23,844 |  |  | $ | 25.50 |  |  |  | 2.55 |  |  |  |  |  |
|  |  |  | 7,400 |  |  | $ | 26.16 |  |  |  | 2.61 |  |  |  |  |  |
|  |  |  | 8,300 |  |  | $ | 23.62 |  |  |  | 2.86 |  |  |  |  |  |
|  |  |  | 66,989 |  |  | $ | 15.16 |  |  |  | 3.15 |  |  |  |  |  |
|  |  |  | 193,521 |  |  | $ | 14.12 |  |  |  | 3.38 |  |  |  |  |  |
|  |  |  | 22,760 |  |  | $ | 19.36 |  |  |  | 3.62 |  |  |  |  |  |
|  |  |  | 5,550 |  |  | $ | 18.60 |  |  |  | 3.68 |  |  |  |  |  |
|  |  |  | 2,171 |  |  | $ | 12.83 |  |  |  | 3.87 |  |  |  |  |  |
| Options outstanding |  |  | 792,019 |  |  |  |  |  |  |  | 2.69 |  |  | $ | 3,010 |  |
| Options exercisable |  |  | 758,451 |  |  |  |  |  |  |  | 2.66 |  |  | $ | 2,843 |  |
| Expected to vest as of June 26, 2015 |  |  | 789,048 |  |  |  |  |  |  |  | 2.69 |  |  | $ | 2,995 |  |

[0001193125-15-296113:notes:74]
As of
 June 26, 2015, there was $0.01 million of unrecognized
 compensation cost related to share options under the Share Option
 Plans that is expected to be recognized over a weighted-average
 period of 0.41 years.

[0001193125-15-296113:notes:75]
Restricted
 share units

[0001193125-15-296113:notes:76]
Restricted
 share units are one type of share-based award that may be granted
 under the 2010 Plan. Restricted share units granted to non-employee
 directors generally cliff vest 100% on the first of January,
 approximately one year from the grant date, provided the director
 continues to serve through such date. Restricted share units
 granted to employees generally vest in four equal installments over
 four years on each anniversary of the vesting commencement
 date.

[0001193125-15-296113:notes:77]
On
 May 24, 2015 the Company entered into an amended and restated
 employment agreement with an executive of the Company that provides
 for accelerated vesting of equity awards under certain
 circumstances. Under the agreement, any equity award granted to the
 executive after February 20, 2017, shall vest over a period
 not longer than 2 years following the applicable grant date. If the
 executive’s employment with the Company continues through and
 including February 20, 2017, any then outstanding equity award
 grants will become 100% vested. During the year the modification
 was made for the executive, the Company recalculated the
 share-based compensation expense, and the impact of this
 modification to the consolidated financial statements was $0.04
 million.

[0001193125-15-296113:notes:78]
The following
 table summarizes restricted share unit activity:

[0001193125-15-296113:notes:79]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 29, 2012 |  |  | 168,275 |  |  | $ | 14.44 |  |
| Granted |  |  | 468,387 |  |  | $ | 12.42 |  |
| Issued |  |  | (71,880 | ) |  | $ | 14.10 |  |
| Forfeited |  |  | (19,114 | ) |  | $ | 12.78 |  |
| Balance as of June 28, 2013 |  |  | 545,668 |  |  | $ | 12.81 |  |
| Granted |  |  | 479,894 |  |  | $ | 15.37 |  |
| Issued |  |  | (184,773 | ) |  | $ | 12.98 |  |
| Forfeited |  |  | (78,494 | ) |  | $ | 14.25 |  |
| Balance as of June 27, 2014 |  |  | 762,295 |  |  | $ | 14.23 |  |
| Granted |  |  | 666,582 |  |  | $ | 17.53 |  |
| Issued |  |  | (247,593 | ) |  | $ | 14.44 |  |
| Forfeited |  |  | (40,357 | ) |  | $ | 16.68 |  |
| Balance as of June 26, 2015 |  |  | 1,140,927 |  |  | $ | 16.03 |  |
| Expected to vest as of June 26, 2015 |  |  | 1,039,544 |  |  | $ | 16.02 |  |

[0001193125-15-296113:notes:80]
The total
 fair value of restricted share units vested during the year ended
 June 26, 2015, June 27, 2014, and June 28, 2013
 was $3.6 million, $2.4, million and $1.0 million, respectively. The
 aggregate intrinsic value of restricted share units outstanding as
 of June 26, 2015 was $22.7 million.

[0001193125-15-296113:notes:81]
As of
 June 26, 2015, there was $8.0 million of unrecognized
 share-based compensation expense related to restricted share units
 under the 2010 Plan that is expected to be recorded over a
 weighted-average period of 2.55 years.

[0001193125-15-296113:notes:82]
For the years
 ended June 26, 2015 and June 27, 2014, the Company
 withheld an aggregate of 19,679 shares and 18,403 shares,
 respectively, upon the vesting of restricted share units, based
 upon the closing share price on the vesting date to settle the
 employees’ minimum statutory obligation for the applicable
 income and other employment taxes. For fiscal year 2015 and fiscal
 year 2014, the Company then remitted cash of $0.4 million and $0.3
 million, respectively, to the appropriate taxing authorities, and
 presented it in a financing activity within the consolidated
 statements of cash flows. The payment had the effect on shares
 issued by the Company as it reduced the number of shares that would
 have been issued on the vesting date and was recorded as a
 reduction of additional paid-in capital.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-15-296113:notes:83]
| 18. | Business segments and geographic information |

[0001193125-15-296113:notes:84]
Operating
 segments are defined as components of an enterprise for which
 separate financial information is available that is evaluated
 regularly by the chief operating decision maker in deciding how to
 allocate resources and in assessing performance. The
 Company’s chief operating decision maker is Fabrinet’s
 chief executive officer. As of June 26,
 2015, June 27, 2014, and June 28, 2013, the Company
 operated and internally managed a single operating segment.
 Accordingly, the Company does not accumulate discrete information
 with respect to separate product lines and does not have separate
 reportable segments.

[0001193125-15-296113:notes:85]
Total revenues
 are attributed to a particular geographic area based on the
 bill-to-location of the customer. The Company operates primarily in
 three geographic regions: North America, Asia-Pacific, and Europe.
 The following table presents total revenues by geographic
 regions:

[0001193125-15-296113:notes:86]
As of
 June 26, 2015 and June 27, 2014, the Company had
 approximately $31.8 million and $0.3 million of long-lived assets
 based in North America, with the substantial remainder of assets
 based in Asia-Pacific.

[0001193125-15-296113:notes:87]
The following
 table presents revenues by end market:

[0001193125-15-296113:notes:88]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26, 2015 |  |  | June 27, 2014 |  |  | June 28, 2013 |  |
| Optical communications |  | $ | 553,245 |  |  | $ | 484,071 |  |  | $ | 449,790 |  |
| Lasers, sensors, and other |  |  | 220,342 |  |  |  | 193,783 |  |  |  | 191,752 |  |
| Total |  | $ | 773,587 |  |  | $ | 677,854 |  |  | $ | 641,542 |  |

[0001193125-15-296113:notes:89]
Significant customers

[0001193125-15-296113:notes:90]
Accounts
 receivable from individual customers that were equal to or greater
 than 10% of accounts receivable as of June 26,
 2015, June 27, 2014, and June 28, 2013,
 respectively, were as follows:

[0001193125-15-296113:notes:91]
|  |  | Years Ended |  |
|  |  | June 26, 2015 |  |  | June 27, 2014 |  |  | June 28, 2013 |  |
| JDS Uniphase Corporation |  |  | 19 | % |  |  | 23 | % |  |  | 17 | % |
| Valeo |  |  | 11 | % |  |  | 10 | % |  |  | * | (1) |
| Oclaro, Inc. (1) |  |  | * | (1) |  |  | 14 | % |  |  | 31 | % |

[0001193125-15-296113:notes:92]
|  | (1) | Less than 10% of total revenue / total accounts receivable. |


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-15-296113:notes:93]
Principles of consolidation

[0001193125-15-296113:notes:94]
The Company
 utilizes a 52-53 week fiscal year ending on the Friday in June
 closest to June 30. Fiscal year 2015, fiscal year 2014, and
 fiscal year 2013 ended on June 26, 2015, June 27,
 2014 and June 28, 2013, respectively, and consisted of 52
 weeks, 52 weeks and 52 weeks, respectively.

[0001193125-15-296113:notes:95]
The
 consolidated financial statements have been prepared in accordance
 with accounting principles generally accepted in the United States
 (“U.S. GAAP”) and include Fabrinet and its subsidiaries
 listed in Note 1 above. All inter-company accounts and transactions
 have been eliminated.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-15-296113:notes:96]
The following
 table summarizes the cost and estimated fair value of marketable
 securities classified as available-for-sale securities based on
 stated effective maturities as of June 26, 2015:

[0001193125-15-296113:notes:97]
| (amount in thousands) |  | Carrying Cost |  |  | Fair Value |  |
| Due within one year |  | $ | 30,461 |  |  | $ | 30,458 |  |
| Due between one to three years |  |  | 112,449 |  |  |  | 112,408 |  |
| Total |  | $ | 142,910 |  |  | $ | 142,866 |  |


## us-gaap:ScheduleOfDeferredTaxAssetsAndLiabilitiesTableTextBlock

[0001193125-15-296113:notes:98]
The
 Company’s deferred tax assets and deferred tax liabilities,
 net of valuation allowance, at each balance sheet date are as
 follows:

[0001193125-15-296113:notes:99]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26, 2015 |  |  | June 27, 2014 |  |
| Deferred tax assets: |  |  |  |  |  |  |  |  |
| Depreciation |  | $ | 1,057 |  |  | $ | 979 |  |
| Severance liability |  |  | 1,192 |  |  |  | 796 |  |
| Reserve and allowance |  |  | 1,648 |  |  |  | 1,561 |  |
| Others |  |  | 14 |  |  |  | — |  |
| Total |  |  | 3,911 |  |  |  | 3,336 |  |

[0001193125-15-296113:notes:100]
| Deferred tax liabilities: |  |  |  |  |  |  |  |  |
| Deferred tax from unremitted earning |  |  | (737 | ) |  |  | (1,040 | ) |
| Total |  |  | (737 | ) |  |  | (1,040 | ) |
| Net |  | $ | 3,174 |  |  | $ | 2,296 |  |

[0001193125-15-296113:notes:101]
Current
 deferred income tax assets and liabilities and non-current deferred
 income tax assets and liabilities are offset when the income taxes
 relate to the same tax jurisdiction. The following amounts are
 shown in the consolidated balance sheets:

[0001193125-15-296113:notes:102]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26, 2015 |  |  | June 27, 2014 |  |
| Deferred income tax assets—current |  | $ | 1,662 |  |  | $ | 1,561 |  |
| Deferred income tax liabilities—current |  |  | — |  |  |  | — |  |
| Current deferred income tax—net |  |  | 1,662 |  |  |  | 1,561 |  |
| Deferred income tax assets—non current |  |  | 3,253 |  |  |  | 1,775 |  |
| Deferred income tax liabilities—non current |  |  | (737 | ) |  |  | (1,040 | ) |
| Less: Valuation allowance |  |  | (1,004 | ) |  |  | — |  |
| Non-current deferred income tax—net |  |  | 1,512 |  |  |  | 735 |  |
| Net deferred income tax assets |  | $ | 3,174 |  |  | $ | 2,296 |  |


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001193125-15-296113:notes:103]
| 19. | Financial instruments |

[0001193125-15-296113:notes:104]
Objectives and significant terms and
 conditions

[0001193125-15-296113:notes:105]
The principal
 financial risks faced by the Company are foreign currency risk and
 interest rate risk. The Company borrows at floating rates of
 interest to finance its operations. A minority of sales and
 purchases and a majority of labor and overhead costs are entered
 into in foreign currencies. In order to manage the risks arising
 from fluctuations in currency exchange rates, the Company uses
 derivative financial instruments. Trading for speculative purposes
 is prohibited under Company policies.

[0001193125-15-296113:notes:106]
The Company
 enters into short-term forward foreign currency contracts and
 option contracts to help manage currency exposures associated with
 certain assets and liabilities. The forward exchange contracts and
 option contracts have generally ranged from one to six months in
 original maturity, and no forward exchange contract or option
 contract has an original maturity greater than one year. All
 foreign currency exchange contracts and option contracts are
 recognized on the consolidated balance sheets at fair value. As the
 Company does not apply hedge accounting to these instruments, the
 derivatives are recorded at fair value through earnings.

[0001193125-15-296113:notes:107]
The gains and
 losses on the Company’s derivative financial instruments
 generally offset losses and gains on the assets, liabilities and
 transactions economically hedged, and accordingly, generally do not
 subject the Company to risk of significant accounting
 losses.

[0001193125-15-296113:notes:108]
Foreign
 currency risk

[0001193125-15-296113:notes:109]
The Company
 operates internationally and is exposed to foreign exchange risk
 arising from various currency exposures primarily with respect to
 the Thai Baht and the Chinese Renminbi (RMB).

[0001193125-15-296113:notes:110]
As of
 June 26, 2015 and June 27, 2014, the Company had
 outstanding foreign currency assets and liabilities as
 follows:

[0001193125-15-296113:notes:111]
|  |  | As of June 26, 2015 |  |  | As of June 27, 2014 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | Currency |  |  | $ |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai Baht |  |  | 377,785 |  |  | $ | 11,596 |  |  |  | 1,536,887 |  |  | $ | 47,318 |  |
| RMB |  |  | 67,455 |  |  |  | 11,029 |  |  |  | 74,813 |  |  |  | 12,156 |  |
| Total |  |  |  |  |  | $ | 22,625 |  |  |  |  |  |  | $ | 59,474 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai Baht |  |  | 860,425 |  |  | $ | 26,410 |  |  |  | 735,490 |  |  | $ | 22,644 |  |
| RMB |  |  | 20,461 |  |  |  | 3,347 |  |  |  | 32,512 |  |  |  | 5,283 |  |
| Total |  |  |  |  |  | $ | 29,757 |  |  |  |  |  |  | $ | 27,927 |  |

[0001193125-15-296113:notes:112]
The Thai Baht
 assets represent cash and cash equivalents, accounts receivable,
 deposits and other current assets. The Thai Baht liabilities
 represent trade accounts payable, accrued expenses and other
 payables. The Company manages its exposure to fluctuations in
 foreign exchange rates by the use of foreign currency contracts and
 offsetting assets and liabilities denominated in the same currency
 in accordance with management’s policy. As of June 26,
 2015, there was $41.0 million in option contracts outstanding on
 the Thai Baht payables and as of June 27, 2014, there were
 $15.0 million in options contracts outstanding on the Thai Baht
 payables.

[0001193125-15-296113:notes:113]
The RMB assets
 represent cash and cash equivalents, accounts receivable and other
 current assets. The RMB liabilities represent trade accounts
 payable, accrued expenses and other payables. As of June 26,
 2015 and June 27, 2014, there were no selling RMB to U.S.
 dollar forward contracts outstanding.

[0001193125-15-296113:notes:114]
As of
 June 26, 2015 and June 27, 2014, unrealized loss from
 fair market value of derivatives amounted to $0.4 million and
 unrealized gain from fair market value of derivatives amounted to
 $0.1 million, respectively.

[0001193125-15-296113:notes:115]
Interest
 Rate Risk

[0001193125-15-296113:notes:116]
The
 Company’s principal interest bearing assets are time deposits
 and short-term investments less than three months held with high
 quality financial institutions. The Company’s principal
 interest bearing liabilities are bank loans which bear interest at
 floating rates.


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-15-296113:notes:117]
| 6. | Fair Value |

[0001193125-15-296113:notes:118]
The following
 table provides details of the financial instruments measured at
 fair value on a recurring basis, including:

[0001193125-15-296113:notes:119]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 26, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 7,430 |  |  | $ | — |  |  | $ | 7,430 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 120,101 |  |  |  | — |  |  |  | 120,101 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 21,027 |  |  |  | — |  |  |  | 21,027 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 1,738 |  |  |  | — |  |  |  | 1,738 |  |
| Derivative assets |  |  | — |  |  |  | 4 | (1) |  |  | — |  |  |  | 4 |  |
| Total |  | $ | — |  |  | $ | 150,300 |  |  | $ | — |  |  | $ | 150,300 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 371 | (2) |  | $ | — |  |  | $ | 371 |  |
| Total |  | $ | — |  |  | $ | 371 |  |  | $ | — |  |  | $ | 371 |  |

[0001193125-15-296113:notes:120]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 27, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 19,194 |  |  | $ | — |  |  | $ | 19,194 |  |
| Derivative assets |  |  | — |  |  |  | 135 | (3) |  |  | — |  |  |  | 135 |  |
| Total |  | $ | — |  |  | $ | 19,329 |  |  | $ | — |  |  | $ | 19,329 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 1 | (4) |  | $ | — |  |  | $ | 1 |  |
| Total |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |

[0001193125-15-296113:notes:121]
| (1) | Foreign currency options with notional amount of $3.0 million and forward contracts with notional amount of Canadian dollars 0.4 million. |

[0001193125-15-296113:notes:122]
| (2) | Foreign currency options with notional amount of $41.0 million. |

[0001193125-15-296113:notes:123]
| (3) | Foreign currency options with notional amount of $15.0 million. |

[0001193125-15-296113:notes:124]
| (4) | Foreign currency forward contracts with notional amount of Canadian dollars 0.9 million. |

[0001193125-15-296113:notes:125]
Derivative
 Financial Instruments

[0001193125-15-296113:notes:126]
The Company
 uses foreign currency exchange contracts to manage the foreign
 exchange risk associated with certain foreign currency-denominated
 assets and liabilities and does not use derivatives for speculative
 purposes. As a result of foreign currency fluctuations, the U.S.
 dollar equivalent values of its foreign currency-denominated assets
 and liabilities change. The Company has not designated such foreign
 currency exchange contracts as hedging instruments under the
 accounting standard for derivatives and hedging. The forward
 exchange contracts and option contracts outstanding as of
 June 26, 2015 and June 27, 2014 had a maturity in one to
 six months duration. The Company minimizes the credit risk in
 derivative instruments by limiting its exposure to any single
 counterparty and by entering into derivative instruments only with
 counterparties that meet the Company’s minimum credit quality
 standard.

[0001193125-15-296113:notes:127]
The derivative
 assets and liabilities are classified in other assets and accrued
 expenses, respectively, on the audited consolidated balance sheets.
 The change in fair value of derivatives is recorded in foreign
 exchange gain (loss) on the audited consolidated of operations and
 comprehensive income.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-15-296113:notes:128]
| 2. | Summary of significant accounting policies |

[0001193125-15-296113:notes:129]
Use of
 estimates

[0001193125-15-296113:notes:130]
The preparation
 of the Company’s consolidated financial statements in
 conformity with U.S. GAAP requires management to make estimates and
 assumptions that affect the reported amounts of assets and
 liabilities and disclosure of contingent liabilities at the date of
 the financial statements, and the reported amount of total revenues
 and expense during the year. The Company bases estimates on
 historical experience and various assumptions about the future that
 are believed to be reasonable based on available information. The
 Company’s reported financial position or results of
 operations may be materially different under different conditions
 or when using different estimates and assumptions, particularly
 with respect to significant accounting policies, which are
 discussed below. Significant assumptions are used in accounting for
 share-based compensation, allowance for doubtful accounts, income
 taxes, and inventory obsolescence, among others. Due to the
 inherent uncertainty involved in making estimates, actual results
 reported in future periods may be different from these estimates.
 In the event that estimates or assumptions prove to differ from
 actual results, adjustments will be made in subsequent periods to
 reflect more current information.

[0001193125-15-296113:notes:131]
Foreign
 currency transactions and translation

[0001193125-15-296113:notes:132]
The
 consolidated financial statements are presented in United States
 Dollars (“$” or “USD”).

[0001193125-15-296113:notes:133]
The functional
 currency of Fabrinet and its subsidiaries is the USD. Transactions
 in currencies other than the functional currency are translated
 into the functional currency at the rates of exchange in effect at
 the date of the transaction. Monetary assets and liabilities
 denominated in foreign currencies are translated into the
 functional currency at the exchange rate prevailing at the balance
 sheet dates. Transaction gains and losses are included in other
 income and expense, net, in the accompanying consolidated
 statements of operations.

[0001193125-15-296113:notes:134]
Cash and
 cash equivalents

[0001193125-15-296113:notes:135]
All highly
 liquid investments with original maturities of three months or less
 at the date of purchase are classified as cash equivalents. Cash
 and cash equivalents consist of cash deposited in checking
 accounts, time deposits with maturities of less than three months,
 money market accounts, and marketable securities with maturities of
 three months or less at the date of purchase.

[0001193125-15-296113:notes:136]
Marketable securities

[0001193125-15-296113:notes:137]
Management
 determines the appropriate classification of its investments at the
 time of purchase and reevaluates the designations at each balance
 sheet date. The Company may sell certain of its marketable
 securities prior to their stated maturities for strategic reasons
 including, but not limited to, anticipation of credit deterioration
 and duration management. The maturities of the Company’s
 marketable securities generally range from three months to three
 years. The Company’s marketable securities consist of
 investment in U.S. Treasuries and fixed income securities and have
 been classified and accounted for as available-for-sale.

[0001193125-15-296113:notes:138]
The
 Company’s investments in marketable securities are primary
 classified as available-for-sale securities and reported at fair
 value. Unrealized gains and losses related to changes in the fair
 value of securities are recognized in accumulated other
 comprehensive income, net of tax, in the Company’s
 consolidated balance sheets. Changes in the fair value of
 available-for-sale securities impact the Company’s net income
 only when such securities are sold or other-than-temporary
 impairment is recognized. Realized gains and losses on the sale of
 securities are determined by specific identification of each
 security’s cost basis.

[0001193125-15-296113:notes:139]
The Company
 reviews its marketable securities on a regular basis to evaluate
 whether or not any security has experienced an other-than-temporary
 decline in fair value. The Company considers factors such as the
 length of time and extent to which the market value has been less
 than the cost, the financial condition and near-term prospects of
 the issue and the Company’s intent to sell, or whether it is
 more likely than not the Company will be required to sell the
 investment before recovery of the investment’s amortized cost
 basis. If the Company believes that an other-than-temporary decline
 exists in one of these securities, the Company will write down
 these investments to fair value.

[0001193125-15-296113:notes:140]
Trade
 accounts receivable

[0001193125-15-296113:notes:141]
Accounts
 receivable are carried at anticipated realizable value. The Company
 assesses the collectability of its accounts receivable based on
 specific customer circumstances, current economic trends,
 historical experience with collection and the age of past due
 receivables and provides an allowance for doubtful receivables
 based on a review of all outstanding amounts at the period end. Bad
 debts are written-off when identified.

[0001193125-15-296113:notes:142]
Unanticipated
 changes in the liquidity or financial position of the
 Company’s customers may require revision to the allowances
 for doubtful accounts.

[0001193125-15-296113:notes:143]
Inventory

[0001193125-15-296113:notes:144]
Inventory is
 stated at the lower of cost or market value. Cost is estimated
 using the standard costing method, computed on a first-in,
 first-out basis, with adjustments for variances to reflect actual
 costs not in excess of net realizable market value. Market value is
 the estimated selling price in the ordinary course of business,
 less the costs of completion and selling expenses. The Company
 assesses the valuation of inventory on a quarterly basis and writes
 down the value for estimated excess and obsolete inventory based
 upon estimates of future demand.

[0001193125-15-296113:notes:145]
Leases

[0001193125-15-296113:notes:146]
Payments made
 under operating leases are expensed on a straight-line basis over
 the lease term.

[0001193125-15-296113:notes:147]
Property,
 plant and equipment

[0001193125-15-296113:notes:148]
Land is stated
 at historical cost. Other property, plant and equipment, except for
 construction in process and machinery under installation, are
 stated at historical cost less accumulated depreciation.
 Depreciation is calculated on the straight-line method to write-off
 the cost of each asset to its residual value over its estimated
 useful life as follows:

[0001193125-15-296113:notes:149]
| Building and building improvements |  |  | 10 - 30 years |  |
| Leasehold improvements |  |  | Shorter of useful life or lease term |  |
| Manufacturing equipment |  |  | 3 - 5 years |  |
| Office equipment |  |  | 3 - 5 years |  |
| Motor vehicles |  |  | 5 years |  |
| Computer hardware |  |  | 3 - 5 years |  |

[0001193125-15-296113:notes:150]
Construction in
 process and machinery under installation is stated at historic cost
 and depreciation begins after it is constructed and fully installed
 and is used in the operations of the Company.

[0001193125-15-296113:notes:151]
Gains and
 losses on disposal are determined by comparing proceeds with
 carrying amounts and are included in operating income in the
 consolidated statements of operations and comprehensive
 income.

[0001193125-15-296113:notes:152]
The Company
 tests long-lived assets or asset groups for recoverability when
 events or changes in circumstances indicate that their carrying
 amount may not be recoverable. Recoverability of long-lived assets
 or asset groups is measured by comparing their carrying amount to
 the projected undiscounted cash flows that the long-lived assets or
 asset groups are expected to generate. If such assets are
 considered to be impaired, the impairment loss recognized, if any,
 is the amount by which the carrying amount of the property and
 equipment exceeds its fair value.

[0001193125-15-296113:notes:153]
Borrowing
 costs

[0001193125-15-296113:notes:154]
Borrowing costs
 are accounted for on an accrual basis and are charged to the
 consolidated statements of operations and comprehensive income in
 the year incurred, except for interest costs on borrowings to
 finance certain qualifying assets. Such costs to finance qualifying
 assets are capitalized during the period of time that is required
 to complete and prepare the assets for their intended use, as part
 of the cost of the assets. All other borrowing costs are expensed
 as incurred.

[0001193125-15-296113:notes:155]
The
 capitalization rate used to determine the amount of interest to be
 capitalized is the weighted average interest rate applicable to the
 Company’s outstanding borrowings during the year. Where funds
 are borrowed specifically for the acquisition, construction or
 production of assets, the amount of borrowing costs eligible for
 capitalization on the respective assets is determined as the actual
 borrowing costs are incurred on that borrowing during the
 respective periods.

[0001193125-15-296113:notes:156]
Fair
 value of financial instruments

[0001193125-15-296113:notes:157]
Fair value is
 defined as the exchange price that would be received for an asset
 or paid to transfer a liability (an exit price) in the principal or
 most advantageous market for the asset or liability in an orderly
 transaction between market participants on the measurement date. A
 fair value hierarchy is established which requires an entity to
 maximize the use of observable inputs and minimize the use of
 unobservable inputs for the valuation of an asset or liability as
 of the measurement date. The three levels of inputs that may be
 used to measure fair value are defined as follows:

[0001193125-15-296113:notes:158]
Level 1 inputs
 are quoted prices (unadjusted) in active markets for identical
 assets or liabilities.

[0001193125-15-296113:notes:159]
Level 2 inputs
 for similar assets and liabilities in active markets other than
 quoted prices included within Level 1 that are observable for the
 asset or liability, either directly or indirectly, for
 substantially the full term of the asset or liability.

[0001193125-15-296113:notes:160]
Level 3 inputs
 that are significant to the fair value measurement and unobservable
 (i.e. supported by little or no market activity), which require the
 reporting entity to develop its own valuation techniques and
 assumptions.

[0001193125-15-296113:notes:161]
The Company
 utilizes the market approach to measure fair value for its
 financial assets and liabilities. The market approach uses prices
 and other relevant information generated by market transactions
 involving identical or comparable assets or liabilities.

[0001193125-15-296113:notes:162]
The carrying
 amounts of certain financial instruments, which include cash and
 cash equivalents, trade accounts receivable, and trade accounts
 payable, approximate their fair values due to their short
 maturities. The carrying amounts of borrowings approximate their
 fair values as the applicable interest rate is based on market
 interest rates. The particular recognition methods adopted are
 disclosed in the individual policy statements associated with each
 item.

[0001193125-15-296113:notes:163]
Derivatives

[0001193125-15-296113:notes:164]
The derivatives
 assets and liabilities are recognized on the consolidated balance
 sheets as other current assets or accrued expenses at fair value,
 based on the free-standing derivative instrument. The accounting
 for changes in the fair value of a derivative depends on the
 intended use of the derivative and the resulting designation and
 can either be designated as (1) a hedge of the fair value of a
 recognized asset or liability or of an unrecognized firm commitment
 (“fair value” hedge), (2) a hedge of a forecasted
 transaction or the variability of cash flows to be received or paid
 related to a recognized asset or liability (“cash flow”
 hedge) or (3) held for trading or not designated for hedge
 accounting (“free-standing derivative
 instrument”).

[0001193125-15-296113:notes:165]
The Company
 does not have any derivatives designated as either fair value or
 cash flow hedges. Accordingly, the change in the fair value of the
 derivatives is recorded in foreign exchange (loss) gain on the
 consolidated statement of operations and comprehensive
 income.

[0001193125-15-296113:notes:166]
Concentration of credit risk

[0001193125-15-296113:notes:167]
Financial
 instruments that potentially subject the Company to concentrations
 of credit risk consist of cash, cash equivalents, marketable
 securities, derivatives, and accounts receivable.

[0001193125-15-296113:notes:168]
Cash, cash
 equivalents, and marketable securities are maintained with several
 financial institutions. Deposits held with banks may exceed the
 amount of insurance provided on such deposits. Generally, these
 deposits may be redeemed upon demand and are maintained with
 financial institutions with reputable credit and therefore bear
 minimal credit risk. The Company seeks to mitigate its credit risks
 by spreading such risks across multiple counterparties and
 monitoring the risk profiles of these counterparties. The Company
 limits its investments in marketable securities to securities with
 a maturity not in excess of three years, and all marketable
 securities that the Company invests in are rated A1, P-1, F1, or
 better.

[0001193125-15-296113:notes:169]
The Company
 performs ongoing credit evaluations for credit worthiness of its
 customers and usually does not require collateral from its
 customers. Management has implemented a program to closely monitor
 near term cash collection and credit exposures to mitigate any
 material losses.

[0001193125-15-296113:notes:170]
Revenue
 recognition

[0001193125-15-296113:notes:171]
The Company
 derives total revenues primarily from the assembly of products
 under supply agreements with its customers and the fabrication of
 customized optics and glass. Revenues represent the invoiced value
 of products, net of trade discounts and allowances, and exclude
 goods and services tax. The Company recognizes revenues when
 realized or realizable and earned. The Company considers revenues
 realized or realizable and earned when there is persuasive evidence
 of an arrangement, delivery has occurred, the sales price is fixed
 or determinable, and collectability is reasonably assured. Delivery
 does not occur until products have been shipped or services have
 been provided to the customer, risk of loss has transferred to the
 customer and customer acceptance has been obtained, customer
 acceptance provisions have lapsed, or the Company has objective
 evidence that the criteria specified in the customer acceptance
 provisions have been satisfied. In situations where a formal
 acceptance is required but the acceptance only relates to whether
 the product meets its published specifications, revenues are
 generally recognized upon shipment provided all other revenue
 recognition criteria are met. The sales price is not considered to
 be fixed or determinable until all contingencies related to the
 sale have been resolved. The Company reduces revenues for rebates
 and other similar allowances. Revenues are recognized only if these
 estimates can be reasonably and reliably determined. The Company
 bases its estimates on historical results taking into consideration
 the type of customer, the type of transaction and the specifics of
 each arrangement. In addition to the aforementioned general
 policies, the following are the specific revenue recognition
 policies for each major category of revenues.

[0001193125-15-296113:notes:172]
Services

[0001193125-15-296113:notes:173]
The Company
 provides services for its customers that range from process design
 to product manufacturing. The Company recognizes service revenues
 when the services have been performed. The related costs are
 expensed as incurred.

[0001193125-15-296113:notes:174]
Services
 revenue of $32.3 million, $25.5 million, and $24.1 million were
 recognized in the consolidated statements of operations and
 comprehensive income for the years ended June 26,
 2015, June 27, 2014 and June 28, 2013,
 respectively.

[0001193125-15-296113:notes:175]
Sales of
 goods

[0001193125-15-296113:notes:176]
Revenues from
 sales of goods are generally recognized when the product is shipped
 to the customer and when there are no unfulfilled obligations that
 affect the customer’s final acceptance of the arrangement.
 Any cost of warranties and remaining obligations that are
 inconsequential or perfunctory are accrued when the corresponding
 revenues are recognized.

[0001193125-15-296113:notes:177]
Certain
 customers may request the Company to store finished products
 purchased by them at the Company’s warehouse. In these
 instances, the Company receives a written request from the customer
 asking the Company to hold the inventory at the Company’s
 warehouse and the ordered goods are segregated in the
 Company’s warehouse from other inventory and cannot be used
 to fulfil other customer orders. In these situations revenue is
 only recognized when persuasive evidence of the sales arrangement
 exists, the goods are completed and ready for shipment, pricing is
 fixed or determinable, collection is reasonably assured, and title
 and risk of loss have passed to the customer.

[0001193125-15-296113:notes:178]
Warranty
 provision

[0001193125-15-296113:notes:179]
Provisions for
 estimated expenses relating to product warranties are made at the
 time the products are sold using historical experience. Generally,
 this warranty is limited to workmanship and the Company’s
 liability is capped at the price of the product. The provisions
 will be adjusted when experience indicates an expected settlement
 will differ from initial estimates.

[0001193125-15-296113:notes:180]
Warranty cost
 allowances of $0.03 million, $0.02 million, and $0.02 million were
 recognized in the consolidated statements of operations and
 comprehensive income for the years ended June 26,
 2015, June 27, 2014 and June 28, 2013,
 respectively.

[0001193125-15-296113:notes:181]
Shipping
 and handling costs

[0001193125-15-296113:notes:182]
The Company
 records costs related to shipping and handling in cost of revenues
 for all periods presented.

[0001193125-15-296113:notes:183]
Share-based
 compensation is recognized in the consolidated financial statements
 based on grant-date fair value. The value of the portion of the
 award that is ultimately expected to vest is recognized as expense
 ratably over the requisite service period. The Company estimates
 the fair value of share-based awards utilizing the
 Black-Scholes-Merton (“BSM”) option-pricing model net
 of estimated forfeitures.

[0001193125-15-296113:notes:184]
Employee
 contribution plan

[0001193125-15-296113:notes:185]
The Company
 operates a defined contribution plan, known as a provident fund, in
 Fabrinet Thailand. The assets of this plan are in a separate
 trustee-administered fund. The provident fund is funded by matching
 payments from employees and by the subsidiary on a monthly basis.
 Current contributions to the provident fund are accrued and paid to
 the fund manager on a monthly basis. The Company sponsors the
 Fabrinet U.S. 401(k) Retirement Plan (the “401(k)
 Plan”), a Defined Contribution Plan under ERISA, at Fabrinet
 USA, Inc., FBN New Jersey Manufacturing, Inc., and Fabrinet West
 Inc., its subsidiaries, which provides retirement benefits for its
 eligible employees through tax deferred salary
 deductions.

[0001193125-15-296113:notes:186]
Severance
 liabilities

[0001193125-15-296113:notes:187]
Under labor
 protection laws applicable in Thailand and under the Fabrinet
 Thailand employment policy, all employees of Fabrinet Thailand with
 more than 120 days of service are entitled to severance pay on
 forced termination or retrenchment or in the event that the
 employee reaches the retirement age of 55. The entitlement to
 severance pay is determined according to an employee’s
 individual employment tenure with the Company and is subject to a
 maximum benefit of 10 months of salary unless otherwise agreed upon
 in an employee’s employment contract. The Company accounts
 for this severance liability on an actuarial basis using the
 Projected Unit Credit Method, using the long-term Thai government
 bond yield as a discount rate. There are no separate plan assets
 held in respect of this liability.

[0001193125-15-296113:notes:188]
Annual
 leave

[0001193125-15-296113:notes:189]
Employee
 entitlements to annual leave are recognized when they accrue to the
 employee. On termination of employment, accrued employee
 entitlement to annual leave is paid in cash.

[0001193125-15-296113:notes:190]
Income
 taxes

[0001193125-15-296113:notes:191]
The Company
 uses the asset and liability method of accounting for income taxes,
 whereby deferred tax assets and liabilities are recognized for
 future tax consequences attributable to temporary differences
 between the financial statement carrying amounts of existing assets
 and liabilities and their respective tax bases. Deferred tax assets
 and liabilities are measured using tax rates expected to apply to
 taxable income in the years in which those temporary differences
 are expected to reverse. The effect of a change in tax rates on
 deferred tax assets and liabilities is recognized in income in the
 period that includes the enactment date. Deferred tax assets are
 reduced by a valuation allowance if, based on the weight of the
 available evidence, it is more likely than not that some portion or
 all of the deferred tax assets will not be realized.

[0001193125-15-296113:notes:192]
Fabrinet’s subsidiaries are subject to income tax audits
 by the respective tax authorities in all of the jurisdictions in
 which they operate. The determination of tax liabilities in each of
 these jurisdictions requires the interpretation and application of
 complex and sometimes uncertain tax laws and regulations. The
 Company recognizes liabilities based on its estimate of whether,
 and the extent to which, additional tax liabilities are probable.
 If the Company ultimately determines that the payment of such a
 liability is not probable, then it reverses the liability and
 recognizes a tax benefit during the period in which the
 determination is made that the liability is no longer probable. The
 recognition and measurement of current taxes payable or refundable
 and deferred tax assets and liabilities requires that the Company
 makes certain estimates and judgments. Changes to these estimates
 or a change in judgment may have a material impact on the
 Company’s tax provision in a future period.

[0001193125-15-296113:notes:193]
The
 authoritative guidance provides for recognition of deferred tax
 assets if the realization of such deferred tax assets is more
 likely than not to occur based on an evaluation of both positive
 and negative evidence and the relative weight of the evidence. The
 Company has determined that it is more likely than not that
 deferred tax asset attributable to a subsidiary in the United
 States will not be realized, primarily due to uncertainties related
 to its ability to utilize its net operating loss carryforward
 before they expire. Accordingly, the Company has established a
 valuation allowance for such deferred tax asset. If there is a
 change in the Company’s ability to realize its deferred tax
 assets for which a valuation allowance has been established, then
 its tax provision may decrease in the period in which it determines
 that realization is more likely than not. Likewise, if the Company
 determines that it is not more likely than not that its deferred
 tax assets will be realized, then a valuation allowance may be
 established for such deferred tax assets and the Company’s
 tax provision may increase in the period in which it makes the
 determination.

[0001193125-15-296113:notes:194]
The accounting
 standard clarifies the accounting for uncertainty in income taxes
 recognized in an entity’s financial statements and prescribes
 a recognition threshold and measurement attributes for financial
 statement disclosure of tax positions taken or expected to be taken
 on a tax return.

[0001193125-15-296113:notes:195]
The Company
 recognizes a tax benefit in the financial statements for an
 uncertain tax position only if management’s assessment is
 that the position is “more likely than not” (i.e., a
 likelihood greater than 50 percent) to be allowed by the tax
 jurisdiction based solely on the technical merits of the position.
 The term “tax position” refers to a position in a
 previously filed tax return or a position expected to be taken in a
 future tax return that is reflected in measuring current or
 deferred income tax assets and liabilities for interim or annual
 periods. The accounting interpretation also provides guidance on
 measurement methodology, derecognition thresholds, financial
 statement classification and disclosures, recognition of interest
 and penalties, and accounting for the cumulative-effect adjustment
 at the date of adoption.

[0001193125-15-296113:notes:196]
New
 Accounting Pronouncements—not yet adopted by the
 Company

[0001193125-15-296113:notes:197]
In July 2015,
 Financial Accounting Standards Board (“FASB”) issued
 Accounting Standards Update (“ASU”) 2015-11,
 “Inventory (Topic 330): Simplifying the Measurement of
 Inventory”. The update provides the guidance that an entity,
 that measured inventory by using first-in, first-out or average
 cost, should measure inventory at the lower of cost and net
 realizable value. Net realizable value is the estimated selling
 prices in the ordinary course of business, less reasonably
 predictable costs of completion, disposal, and transportation.
 Subsequent measurement is unchanged for inventory measured using
 last-in, first-out or the retail inventory method. The update is
 effective for fiscal years beginning after December 15, 2016,
 including interim periods within these fiscal years. This update
 should be applied prospectively with earlier application permitted
 as of the beginning of an interim or annual reporting date. The
 Company is currently evaluating the impact of adoption of this
 update on its consolidated financial statements.

[0001193125-15-296113:notes:198]
In April 2015,
 the FASB issued ASU 2015-03, “Interest—Imputation of
 Interest (Subtopic 835-30): Simplifying the Presentation of Debt
 Issuance Costs”. The update requires debt issuance costs
 related to a recognized debt liability be presented in the balance
 sheet as a direct deduction from the carrying amount of the related
 debt liability instead of being presented as an asset. Debt
 disclosures will include the face amount of the debt liability and
 the effective interest rate. The update requires retrospective
 application and represents a change in accounting principle. The
 update is effective for fiscal years beginning after
 December 15, 2015. Early adoption is permitted for financial
 statements that have not been previously issued. The Company is
 currently evaluating the impact of adoption of this update on its
 consolidated financial statements.

[0001193125-15-296113:notes:199]
In February
 2015, the FASB issued ASU 2015-02, “Consolidation (Topic
 810): Amendments to the Consolidation Analysis”. ASU
 No. 2015-02 amended the process that a reporting entity must
 perform to determine whether it should consolidate certain types of
 legal entities. ASU No. 2015-02 is effective for fiscal years,
 and for interim periods within those fiscal years beginning after
 December 15, 2015. Early adoption is permitted, including
 adoption in an interim period. The Company is currently evaluating
 the impact of adoption of this update on its consolidated financial
 statements.

[0001193125-15-296113:notes:200]
In January
 2015, the FASB issued ASU No. 2015-01, “Income
 Statement—Extraordinary and Unusual Items (Subtopic 225-20):
 Simplifying Income Statement Presentation by Eliminating the
 Concept of Extraordinary Items”. The objective of this
 amendment is to reduce the complexity in accounting standards by
 eliminating the concept of extraordinary items from U.S. GAAP.
 Presently, an event or transaction is presumed to be an ordinary
 and usual activity of the reporting entity unless evidence clearly
 supports its classification as an extraordinary item. The following
 criteria must both be met for extraordinary classification:
 (a) the underlying event or transaction should possess a high
 degree of abnormality and be of a type clearly unrelated to, or
 only incidentally related to, the ordinary and typical activities
 of the entity; and (b) the underlying event or transaction
 should not reasonably be expected to recur in the foreseeable
 future. This amendment is effective for fiscal years and interim
 periods beginning after December 15, 2015. Early adoption is
 permitted provided that the guidance is applied from the beginning
 of the fiscal year of adoption. The Company does not expect that
 the adoption of this update will have an effect on its consolidated
 financial statements.

[0001193125-15-296113:notes:201]
In August 2014,
 The Financial Accounting Standards Board (FASB) issued Accounting
 Standard Update (ASU) no. 2014-15, “Presentation of Financial
 Statements—Going Concern (Subtopic 205-40): Disclosure of
 Uncertainties about an Entity’s Ability to Continue as a
 Going Concern”. The amendments require management to evaluate
 an entity’s ability to continue as a going concern; when
 relevant conditions and events, considered in the aggregate,
 indicate that it is probable that the entity will be unable to meet
 its obligations that become due within one year after the date that
 the financial statements are issued (or available to be issued).
 This applies to all entities and effective for fiscal beginning
 after December 15, 2016 and for annual periods and interim
 periods thereafter. The Company does not expect that the adoption
 of this guidance will have an effect on its consolidated financial
 statements.

[0001193125-15-296113:notes:202]
In June 2014,
 the FASB issued ASU No. 2014-12,
 “Compensation—Stock Compensation (Topic 718),
 Accounting for Share-Based Payments when the terms of an award
 provide that a performance target could be achieved after the
 requisite service period”. This ASU requires that a
 performance target that affects vesting, and that could be achieved
 after the requisite service period, be treated as a performance
 condition. As such, the performance target should not be reflected
 in estimating the grant date fair value of the award. This update
 further clarifies that compensation cost should be recognized in
 the period in which it becomes probable that the performance target
 will be achieved and should represent the compensation cost
 attributable to the period(s) for which the requisite service has
 already been rendered. The Company is currently evaluating the
 impact of adoption of this new guidance on its consolidated
 financial statements.

[0001193125-15-296113:notes:203]
In May 2014,
 the FASB issued ASU No. 2014-09, “Revenue from Contracts
 with Customers (Topic 606), issued as a new Topic, Accounting
 Standards Codification”. The core principle of this amendment
 is that an entity should recognize revenue to depict the transfer
 of promised goods or services to customers in an amount that
 reflects the consideration to which the entity expects to be
 entitled in exchange for those goods or services. This new guidance
 is effective for annual reporting periods beginning after
 December 15, 2016, including interim periods within that
 reporting period, with earlier adoption not being permitted. This
 new guidance can be adopted either retrospectively to each prior
 reporting period presented or as a cumulative-effect adjustment as
 of the date of adoption. The Company is currently assessing impact
 of adoption of this new guidance on its consolidated financial
 statements.


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001193125-15-296113:notes:204]
The
 Company’s income tax expense consisted of the
 following:

[0001193125-15-296113:notes:205]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26, 2015 |  |  | June 27, 2014 |  |  | June 28, 2013 |  |
| Current |  | $ | 4,191 |  |  | $ | 2,304 |  |  | $ | 239 |  |
| Deferred |  |  | (207 | ) |  |  | (865 | ) |  |  | 2,701 |  |
| Total income tax expense |  | $ | 3,984 |  |  | $ | 1,439 |  |  | $ | 2,940 |  |


## us-gaap:ScheduleOfQuarterlyFinancialInformationTableTextBlock

[0001193125-15-296113:notes:206]
The following
 tables set forth a summary of the Company’s quarterly
 financial information for each of the four quarters in the fiscal
 years ended June 26, 2015 and June 27, 2014:

[0001193125-15-296113:notes:207]
|  |  | Three Months Ended |  |
| (in thousands, except per share data) |  | Jun 26, 2015 |  |  | Mar 27, 2015 |  |  | Dec 26, 2014 |  |  | Sep 26, 2014 |  |  | Jun 27, 2014 |  |  | Mar 28, 2014 |  |  | Dec 27, 2013 |  |  | Sep 27, 2013 |  |
| Total revenues |  | $ | 206,456 |  |  | $ | 189,453 |  |  | $ | 188,353 |  |  | $ | 189,325 |  |  | $ | 160,084 |  |  | $ | 167,657 |  |  | $ | 178,562 |  |  | $ | 171,551 |  |
| Gross profit |  | $ | 24,549 |  |  | $ | 21,657 |  |  | $ | 21,061 |  |  | $ | 20,506 |  |  | $ | 17,775 |  |  | $ | 17,283 |  |  | $ | 20,530 |  |  | $ | 18,645 |  |
| Net income |  | $ | 13,035 |  |  | $ | 10,845 |  |  | $ | 8,726 |  |  | $ | 11,036 |  |  | $ | 10,333 |  |  | $ | 47,662 |  |  | $ | 14,539 |  |  | $ | 19,197 |  |
| Basic net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 0.37 |  |  | $ | 0.31 |  |  | $ | 0.25 |  |  | $ | 0.31 |  |  | $ | 0.29 |  |  | $ | 1.36 |  |  | $ | 0.42 |  |  | $ | 0.55 |  |
| Weighted-average shares used in basic net income per share calculations |  |  | 35,431 |  |  |  | 35,406 |  |  |  | 35,349 |  |  |  | 35,230 |  |  |  | 35,117 |  |  |  | 35,078 |  |  |  | 34,882 |  |  |  | 34,674 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 0.36 |  |  | $ | 0.30 |  |  | $ | 0.24 |  |  | $ | 0.31 |  |  | $ | 0.29 |  |  | $ | 1.33 |  |  | $ | 0.41 |  |  | $ | 0.55 |  |
| Weighted-average shares used in diluted net income per share calculations |  |  | 36,320 |  |  |  | 36,110 |  |  |  | 35,917 |  |  |  | 35,587 |  |  |  | 35,843 |  |  |  | 35,790 |  |  |  | 35,583 |  |  |  | 35,138 |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-15-296113:notes:208]
| 4. | Earnings per ordinary share |

[0001193125-15-296113:notes:209]
Basic earnings
 per ordinary share is computed by dividing reported net income by
 the weighted average number of ordinary shares outstanding during
 each period. Diluted earnings per ordinary share is computed by
 dividing reported net income by the weighted average number of
 ordinary shares and dilutive ordinary equivalent shares outstanding
 during each period. Dilutive ordinary equivalent shares consist of
 share options and restricted share units. The earnings per ordinary
 share was calculated as follows:

[0001193125-15-296113:notes:210]
|  |  | Years Ended |  |
| (amount in thousands except per share amounts) |  | June 26, 2015 |  |  | June 27, 2014 |  |  | June 28, 2013 |  |
| Net income attributable to shareholders |  | $ | 43,642 |  |  | $ | 91,731 |  |  | $ | 68,969 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  | 35,354 |  |  |  | 34,938 |  |  |  | 34,557 |  |
| Incremental shares arising from the assumed exercise of share options and vesting of restricted share units (thousands of shares) |  |  | 630 |  |  |  | 651 |  |  |  | 289 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 35,984 |  |  |  | 35,589 |  |  |  | 34,846 |  |
| Basic earnings per ordinary share |  | $ | 1.23 |  |  | $ | 2.63 |  |  | $ | 2.00 |  |
| Diluted earnings per ordinary share |  | $ | 1.21 |  |  | $ | 2.58 |  |  | $ | 1.98 |  |
| Outstanding share options excluded in the computation of diluted earnings per ordinary share (1) |  |  | 39,544 |  |  |  | 44,369 |  |  |  | 1,129,933 |  |

[0001193125-15-296113:notes:211]
| (1) | These share options were not included in the computation of diluted earnings per ordinary share for fiscal year 2015, fiscal year 2014, and fiscal year 2013, respectively, because the exercise price of the options was greater than the average market price of the underlying shares. |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-15-296113:notes:212]
| 16. | Accumulated other comprehensive loss |

[0001193125-15-296113:notes:213]
The
 Company’s accumulated other comprehensive loss consists of
 the accumulated net unrealized loss and the reclassification
 adjustment for net loss realized and included in other expense in
 net income on available-for-sale securities. For the year ended
 June 26, 2015, the changes in accumulated other comprehensive
 loss, net of tax were as follows:

[0001193125-15-296113:notes:214]
| (amount in thousands) |  | Unrealized Loss on Available-for-Sale Securities |  |
| Balance as of June 27, 2014 |  | $ | — |  |
| Other comprehensive loss before reclassification adjustment |  |  | (193 | ) |
| Less: Reclassification adjustment for net loss realized and included in other expense in net income |  |  | 149 |  |
| Net current-period other comprehensive loss |  | $ | (44 | ) |
| Balance as of June 26, 2015 |  | $ | (44 | ) |


## us-gaap:ScheduleOfUnrecognizedTaxBenefitsRollForwardTableTextBlock

[0001193125-15-296113:notes:215]
The following
 table indicates the changes to the Company’s uncertain income
 tax positions for the years ended June 26,
 2015, June 27, 2014, and June 28, 2013 included in
 other non-current liabilities.

[0001193125-15-296113:notes:216]
| (amount in thousands) |  | As of June 26, 2015 |  |  | As of June 27, 2014 |  |  | As of June 28, 2013 |  |
| Beginning balance |  | $ | 868 |  |  | $ | 1,167 |  |  | $ | 1,124 |  |
| Additions during the year |  |  | 552 |  |  |  | 510 |  |  |  | 358 |  |
| Reductions for tax positions of prior years |  |  | — |  |  |  | (809 | ) |  |  | (315 | ) |
| Ending balance |  | $ | 1,420 |  |  | $ | 868 |  |  | $ | 1,167 |  |


## us-gaap:ScheduleOfAssumptionsUsedTableTextBlock

[0001193125-15-296113:notes:217]
The principal
 actuarial assumptions used were as follows:

[0001193125-15-296113:notes:218]
|  |  | Years Ended |  |
|  |  | June 26, 2015 |  |  | June 27, 2014 |  |  | June 28, 2013 |  |
| Discount rate |  |  | 4.0 | % |  |  | 4.9 | % |  |  | 5.1 | % |
| Future salary increases |  |  | 4.2 | % |  |  | 4.2 | % |  |  | 4.4 | % |


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001193125-15-296113:notes:219]
| 5. | Cash, cash equivalents and marketable securities |

[0001193125-15-296113:notes:220]
The
 Company’s cash, cash equivalents,
 and marketable securities can be analyzed as
 follows:

[0001193125-15-296113:notes:221]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized (Loss)/Gain |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of June 26, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | — |  |  | $ | — |  |  | $ | 105,548 |  |  | $ | — |  |
| Cash equivalents |  |  | 7,430 |  |  |  | — |  |  |  | 7,430 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 120,144 |  |  |  | (43 | ) |  |  | — |  |  |  | 120,101 |  |
| U.S. agency and U.S. treasury securities |  |  | 21,029 |  |  |  | (2 | ) |  |  | — |  |  |  | 21,027 |  |
| Sovereign and municipal securities |  |  | 1,737 |  |  |  | 1 |  |  |  | — |  |  |  | 1,738 |  |
| Total |  | $ | 150,340 |  |  | $ | (44 | ) |  | $ | 112,978 |  |  | $ | 142,866 |  |

[0001193125-15-296113:notes:222]
|  |  |  |  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized (Loss)/Gain |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of June 27, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | — |  |  | $ | — |  |  | $ | 214,283 |  |  | $ | — |  |
| Cash equivalents |  |  | — |  |  |  | — |  |  |  | 19,194 |  |  |  | — |  |
| Total |  | $ | — |  |  | $ | — |  |  | $ | 233,477 |  |  | $ | — |  |

[0001193125-15-296113:notes:223]
The cash
 equivalents include short term bank deposits, investments in money
 market funds, and marketable securities with maturities of less
 than three months. The effective interest rate on short term bank
 deposits was 0.66% and 1.01% per annum for the years ended
 June 26, 2015 and June 27, 2014, respectively.

[0001193125-15-296113:notes:224]
As of
 June 26, 2015, 66.4% of our cash and cash equivalents were
 held by the Parent Company.

[0001193125-15-296113:notes:225]
During the year
 ended June 26, 2015, the net realized loss recognized by the
 Company was $0.1 million.

[0001193125-15-296113:notes:226]
As of
 June 26, 2015, the Company considered the declines in market
 value of its marketable securities investment portfolio to be
 temporary in nature and did not consider any of its securities
 other-than-temporarily impaired. The Company typically invests in
 highly-rated securities, and its investment policy generally limits
 the amount of credit exposure to any one issuer. The policy
 requires investments generally to be investment grade, with the
 primary objective of minimizing the potential risk of principal
 loss. Fair values were determined for each individual security in
 the investment portfolio. When evaluating an investment for
 other-than-temporary impairment, the Company reviews factors such
 as the length of time and extent to which fair value has been below
 its cost basis, the financial condition of the issuer and any
 changes thereto, changes in market interest rates, and the
 Company’s intent to sell, or whether it is more likely than
 not it will be required to sell, the investment before recovery of
 the investment’s cost basis. No impairment losses were
 recorded for the year ended June 26, 2015.

[0001193125-15-296113:notes:227]
As of
 June 26, 2015, cash, cash equivalents, and marketable
 securities included bank deposits of $40.0 million held in various
 financial institutions located in the United States in order to
 support the availability of the Facility Agreement and comply with
 covenants. Under the terms and conditions of the Facility
 Agreement, the Company shall maintain cash, cash equivalents and/or
 marketable securities in an aggregate amount not less than $40.0
 million in unencumbered deposits, and/or securities in accounts
 located in the United States at all times during the term of the
 Facility Agreement. As discussed in Note 11, the Company must
 comply with this covenant from and after the effective date of the
 Facility Agreement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-15-296113:notes:228]
| 3. | Income taxes |

[0001193125-15-296113:notes:229]
Cayman
 Islands

[0001193125-15-296113:notes:230]
Fabrinet is
 domiciled in the Cayman Islands. Under the current laws of Cayman
 Islands, Fabrinet is not subject to tax in the Cayman Islands on
 income or capital gains. Fabrinet has received this undertaking for
 a 20-year period ending August 24, 2019, and after the
 expiration date, Fabrinet can make a request for renewal with the
 office of the Clerk of the Cabinet for another 20 years.

[0001193125-15-296113:notes:231]
Income of the
 Company exempted from corporate income tax in the Cayman Islands
 amounted to $27.0 million, $73.0 million and $50.3 in the years
 ended June 26, 2015, June 27, 2014 and June 28,
 2013, respectively.

[0001193125-15-296113:notes:232]
Thailand

[0001193125-15-296113:notes:233]
Fabrinet Co.,
 Ltd. is where the majority of the Company’s operations and
 production takes place. The Company is not subject to tax for the
 period from July 2010 through June 2015 on income generated from
 the manufacture of products at Pinehurst Building 5, and from July
 2012 through June 2020 on income generated from the manufacture of
 products at Pinehurst Building 6. Such preferential tax treatment
 is contingent on, among other things, the export of the
 Company’s customers’ products out of Thailand and the
 Company’s agreement not to move Fabrinet Thailand’s
 manufacturing facilities out of its current province in Thailand
 for at least 15 years. In addition, in December 2011, the
 Thailand Revenue Department announced a reduction in corporate
 income tax rates for tax periods beginning on or after
 January 1, 2012. As a result of the announcement, enacted
 corporate income tax rates for Fabrinet Thailand were reduced from
 23% in fiscal year 2013 to 20% in fiscal year 2014, fiscal year
 2015, and fiscal year 2016.

[0001193125-15-296113:notes:234]
People’s Republic of China

[0001193125-15-296113:notes:235]
Casix had
 been granted a tax privilege to reduce its corporate income tax
 rate from 25% to 15%, but the privilege expired on
 December 31, 2013. As a result, the corporate income tax rate
 for Casix has been 25% since January 2014.

[0001193125-15-296113:notes:236]
As of
 June 26, 2015, the Company recognized deferred tax assets of
 $1.0 million from tax net operating loss carrying forward of a
 subsidiary of the Company. Utilization of the tax net operating
 losses carrying forward may be subject to substantial limitations
 according to the subsidiary’s future operation, which may
 result in the reduced utilization of a portion of the
 Company’s net operating losses.

[0001193125-15-296113:notes:237]
Income tax
 liabilities have not been established for withholding tax and other
 taxes that would be payable on the unremitted earnings of Fabrinet
 Thailand. Such amounts of Fabrinet Thailand are permanently
 reinvested; unremitted earnings for Fabrinet Thailand totaled $50.9
 million and $37.2 million as of June 26, 2015 and
 June 27, 2014, respectively. Unrecognized deferred tax
 liabilities for such unremitted earnings were $2.6 million and $2.6
 million as of June 26, 2015 and June 27, 2014,
 respectively.

[0001193125-15-296113:notes:238]
Deferred tax
 liabilities of $0.7 million and $1.0 million have been established
 for withholding tax on the unremitted earnings of Casix, which
 included in non-current deferred tax liability as of June 26,
 2015 and June 27, 2014, respectively.

[0001193125-15-296113:notes:239]
Uncertain income tax positions

[0001193125-15-296113:notes:240]
Interest and
 penalties related to uncertain tax positions are recognized in
 income tax expense. The Company had approximately $0.2 million and
 $0.04 million of accrued interest and penalties related to
 uncertain tax positions on the consolidated balance sheets as of
 June 26, 2015 and June 27, 2014, respectively. The
 Company recorded (reversed) interest and penalties of $0.1 million,
 ($0.6 million) and ($0.1 million) for the years ended June 26,
 2015, June 27, 2014 and June 28, 2013, respectively,
 in the consolidated statements of operations and comprehensive
 income. With regard to the Thailand jurisdiction, tax years 2010
 through 2014 remain open to examination by the local
 authorities.


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001193125-15-296113:notes:241]
| 20. | Income related to flooding |

[0001193125-15-296113:notes:242]
The Company
 suspended production at all of its manufacturing facilities in
 Thailand from October 17, 2011 through November 14, 2011
 due to severe flooding in Thailand. The Company never resumed, and
 has permanently ceased, production at its Chokchai facility. The
 Company submitted claims for losses to its insurance companies, all
 of which were settled as of the end of fiscal year 2014.

[0001193125-15-296113:notes:243]
In fiscal year
 2014, the Company received from its insurer a final payment of
 $45.2 million against its claim for owned and consigned equipment
 and inventory, which the Company recognized as income related to
 flooding. This income was offset by $0.5 million of other expenses
 from write-offs of advance payments to a customer due to
 flood-related losses.

[0001193125-15-296113:notes:244]
During fiscal
 year 2014, the Company fulfilled its obligations to a customer in
 accordance with the a settlement agreement entered into during the
 third quarter of fiscal year 2013 by making a final cash payment of
 $5.3 million and transferring equipment with an aggregate value of
 $2.3 million to such customer. In addition, the Company fulfilled
 its obligations to a customer’s insurers in accordance with a
 settlement agreement entered into during the fourth quarter of
 fiscal 2013 by making a payment of $2.3 million.


## us-gaap:ScheduleOfDefinedBenefitPlansDisclosuresTextBlock

[0001193125-15-296113:notes:245]
The following
 table provides the information of the severance
 liabilities:

[0001193125-15-296113:notes:246]
| (amount in thousands) |  | As of June 26, 2015 |  |  | As of June 27, 2014 |  |
| Balance, beginning of the fiscal year |  | $ | 4,453 |  |  | $ | 4,382 |  |
| Charged to consolidated statements of operations |  |  | 1,024 |  |  |  | 71 |  |
| Balance, end of the fiscal year |  | $ | 5,477 |  |  | $ | 4,453 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-15-296113:notes:247]
| 15. | Shareholders’ equity |

[0001193125-15-296113:notes:248]
Fabrinet’s
 authorized share capital is 500,000,000 ordinary shares, par value
 of $0.01 per ordinary share, and 5,000,000 preferred shares, par
 value of $0.01 per preferred share.

[0001193125-15-296113:notes:249]
In the year
 ended June 26, 2015, Fabrinet issued 56,968 ordinary shares
 upon the exercise of options, for cash consideration at a weighted
 average exercise price of $14.67 per share, and 227,914 ordinary
 shares upon the vesting of restricted share units, net of shares
 withheld.

[0001193125-15-296113:notes:250]
In the year
 ended June 27, 2014, Fabrinet issued 351,435 ordinary shares
 upon the exercise of options, for cash consideration at a weighted
 average exercise price of $13.00 per share, and 166,370 ordinary
 shares upon the vesting of restricted share units, net of shares
 withheld.

[0001193125-15-296113:notes:251]
In the year
 ended June 28, 2013, Fabrinet issued 94,188 ordinary shares
 upon the exercise of options, for cash consideration at a weighted
 average exercise price of $5.96 per share, and 69,950 ordinary
 shares upon the vesting of restricted share units, net of shares
 withheld.

[0001193125-15-296113:notes:252]
All such issued
 shares are fully paid.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001193125-15-296113:notes:253]
UNAUDITED QUARTERLY FINANCIAL
 INFORMATION


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-15-296113:notes:254]
| 17. | Commitments and contingencies |

[0001193125-15-296113:notes:255]
Bank
 guarantees

[0001193125-15-296113:notes:256]
As of
 June 26, 2015 and June 27, 2014, there were outstanding
 bank guarantees given by banks on behalf of Fabrinet Thailand for
 electricity usage and other normal business amounting to $0.8
 million and $0.3 million, respectively.

[0001193125-15-296113:notes:257]
Operating
 lease commitments

[0001193125-15-296113:notes:258]
The Company
 leases a portion of its capital equipment, vehicle, and certain
 land and buildings for its facilities in Cayman Islands, China, and
 New Jersey under operating lease arrangements that expire in
 various years through 2020. Rental expense under these operating
 leases amounted to $1.1 million, $0.8 million, and $0.8 million for
 the years ended June 26, 2015, June 27, 2014, and
 June 28, 2013, respectively.

[0001193125-15-296113:notes:259]
As of
 June 26, 2015, the future minimum lease payments due under
 non-cancelable leases are as follows at the end of each fiscal year
 below:

[0001193125-15-296113:notes:260]
| (amount in thousands) |  |  |  |
| 2016 |  | $ | 1,153 |  |
| 2017 |  |  | 979 |  |
| 2018 |  |  | 979 |  |
| 2019 |  |  | 489 |  |
| 2020 |  |  | 291 |  |
| Total minimum operating lease payments |  | $ | 3,891 |  |

[0001193125-15-296113:notes:261]
Purchase
 obligations

[0001193125-15-296113:notes:262]
Purchase
 obligations represent legally-binding commitments to purchase
 inventory and other commitments made in the normal course of
 business to meet operational requirements. Although open purchase
 orders are considered enforceable and legally binding, their terms
 generally give the Company the option to cancel, reschedule and/or
 adjust its requirements based on its business needs prior to the
 delivery of goods or performance of services. Obligations to
 purchase inventory and other commitments are generally expected to
 be fulfilled within one year.

[0001193125-15-296113:notes:263]
As of
 June 26, 2015, the Company had an outstanding commitment to
 third parties of $4.3 million.

[0001193125-15-296113:notes:264]
Indemnification of directors and
 officers

[0001193125-15-296113:notes:265]
Cayman Islands
 law does not limit the extent to which a company’s memorandum
 and articles of association may provide for indemnification of
 directors and officers, except to the extent any such provision may
 be held by the Cayman Islands courts to be contrary to public
 policy, such as to provide indemnification against civil fraud or
 the consequences of committing a crime. Fabrinet’s amended
 and restated memorandum and articles of association provide for
 indemnification of directors and officers for actions, costs,
 charges, losses, damages and expenses incurred in their capacities
 as such, except that such indemnification does not extend to any
 matter in respect of any fraud or dishonesty that may attach to any
 of them.

[0001193125-15-296113:notes:266]
In accordance
 with Fabrinet’s form of indemnification agreement for its
 directors and officers, Fabrinet has agreed to indemnify its
 directors and officers against certain liabilities and expenses
 incurred by such persons in connection with claims by reason of
 their being such a director or officer. Fabrinet maintains a
 director and officer liability insurance policy that may enable it
 to recover a portion of any future amounts paid under the
 indemnification agreements.

[0001193125-15-296113:notes:267]
Contingent
 liability

[0001193125-15-296113:notes:268]
In the first
 week of October 2013, the Company authorized a customer to return a
 number of units of its product manufactured at the Company’s
 Pinehurst facility, due to functional failure. After investigation,
 the Company found that the affected products were produced during
 the first quarter of fiscal year 2014. On March 28, 2014, the
 Company entered into a settlement agreement with the customer for
 the losses as a result of the product failure. The settled amount
 was $0.5 million and recorded in the consolidated statement of
 operations and comprehensive income for the year ended
 June 27, 2014. There was no additional expense recorded during
 the year ended June 26, 2015 due to this case.


## us-gaap:SubsequentEventsTextBlock

[0001193125-15-296113:notes:269]
| 23. | Subsequent events |

[0001193125-15-296113:notes:270]
During the
 week of August 10, 2015, the Company temporary suspended
 production in the manufacturing facility of its subsidiary in China
 due to storm damage caused by Typhoon Soudelor. The Company expects
 to resume production at the facility in August 2015. While the
 Company is currently estimating its liabilities and expenses for
 the quarter ending September 25, 2015 in relation to this
 matter, the financial statements for the year ended June 26,
 2015 were not affected.


## us-gaap:ScheduleOfCreditLossesForFinancingReceivablesCurrentTableTextBlock

[0001193125-15-296113:notes:271]
The activities
 and balances for allowance for doubtful accounts were as
 follows:

[0001193125-15-296113:notes:272]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26, 2015 |  |  | June 27, 2014 |  |  | June 28, 2013 |  |
| Balance, beginning of period |  | $ | 37 |  |  | $ | 109 |  |  | $ | 203 |  |
| Charged to Expense/(Credited to Income) |  |  | 13 |  |  |  | (72 | ) |  |  | (94 | ) |
| Balance, end of period |  | $ | 50 |  |  | $ | 37 |  |  | $ | 109 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-15-296113:notes:273]
| 14. | Employee benefit plans |

[0001193125-15-296113:notes:274]
The Company
 operates a defined contribution plan, known as a provident fund, in
 its Thailand subsidiary. The assets of this plan are in a separate
 trustee-administered fund. The provident fund is funded by matching
 payments from employees and by the subsidiary on a monthly basis.
 Current contributions to the provident fund are accrued and paid to
 the fund manager on a monthly basis. The Company’s
 contributions to the provident fund amounted to $2.3 million, $2.1
 million, and $2.2 million in the years ended June 26,
 2015, June 27, 2014, and June 28, 2013,
 respectively.

[0001193125-15-296113:notes:275]
The Company
 sponsors the Fabrinet U.S. 401(k) Retirement Plan (the
 “401(k) Plan”), a Defined Contribution Plan under
 ERISA, at its Fabrinet USA, Inc., FBN New Jersey Manufacturing,
 Inc., and Fabrinet West, Inc. subsidiaries, which provides
 retirement benefits for its eligible employees through tax deferred
 salary deductions. The 401(k) Plan allows employees to
 contribute up to 80% of their annual compensation, subject to
 annual contributions limits established by the Internal Revenue
 Service. The Company provides for a 100% match of employees’
 contributions to the 401(k) Plan up to the first 6% of annual
 compensation. All matching contributions are made in cash and vest
 immediately. The Company’s matching contributions to the
 401(k) Plan were $0.3 million, $0.2 million, and $0.2 million in
 the years ended June 26, 2015, June 27, 2014, and
 June 28, 2013, respectively.

[0001193125-15-296113:notes:276]
Executive
 incentive plan and employee performance bonuses

[0001193125-15-296113:notes:277]
For the year
 ended June 26, 2015, the Company maintained an executive
 incentive plan with quantitative objectives, based on achieving
 certain revenue and non-GAAP earnings per share targets as well as
 qualitative objectives, based on achieving individual performance
 goal for the fiscal year. For the year ended June 27, 2014,
 the Company maintained an executive incentive plan with
 quantitative objectives, based on achieving certain revenue and
 gross margin percentage target as well as qualitative objectives,
 based on achieving individual performance goals for the fiscal
 year. For the year ended June 28, 2013, the Company maintained
 an executive incentive plan with quantitative objectives, based on
 achieving certain revenue and earnings per share milestones for the
 fiscal years. During the years ended June 26,
 2015, June 27, 2014, and June 28, 2013,
 discretionary merit-based bonus awards were also available to
 Fabrinet’s non-executive employees.

[0001193125-15-296113:notes:278]
Bonus
 distributions to employees were $6.0 million, $5.1 million, and
 $3.7 million for the years ended June 26,
 2015, June 27, 2014, and June 28, 2013,
 respectively.


## us-gaap:ScheduleOfNetBenefitCostsTableTextBlock

[0001193125-15-296113:notes:279]
The amount
 recognized in the consolidated statements of operations and
 comprehensive income was as follows:

[0001193125-15-296113:notes:280]
|  |  | Years Ended |  |
| (amount in thousands) |  | June 26, 2015 |  |  | June 27, 2014 |  |  | June 28, 2013 |  |
| Current service cost |  | $ | 360 |  |  | $ | 368 |  |  | $ | 722 |  |
| Interest cost |  |  | 203 |  |  |  | 207 |  |  |  | 211 |  |
| Benefit paid |  |  | (10 | ) |  |  | (223 | ) |  |  | (4 | ) |
| Actuarial loss (gain) on obligation |  |  | 471 |  |  |  | (281 | ) |  |  | (967 | ) |
| Total |  | $ | 1,024 |  |  | $ | 71 |  |  | $ | (38 | ) |


## fn:SubsidiaryDisclosureTextBlock

[0001193125-15-296113:notes:281]
| 22. | Principal subsidiaries |

[0001193125-15-296113:notes:282]
Fabrinet’s subsidiaries are:

[0001193125-15-296113:notes:283]
| Name |  | Business |  | Country of Incorporation |  | Percent interest |  |
| Fabrinet Co., Ltd. |  | Manufacturing and assembly |  | Thailand |  |  | 99.99 |  |
| Fabrinet USA, Inc. |  | Marketing and administrative support services |  | United States of America (California) |  |  | 100 |  |
| FBN New Jersey Manufacturing, Inc. |  | Manufacturing and assembly |  | United States of America (Delaware) |  |  | 100 |  |
| Fabrinet China Holdings |  | Holding company |  | Mauritius Island |  |  | 100 |  |
| CASIX Inc. (a wholly-owned subsidiary of Fabrinet China Holdings) |  | Manufacturing and assembly |  | People’s Republic of China |  |  | 100 |  |
| Fabrinet Pte., Ltd. |  | Sales and administrative support services and supply chain sourcing center |  | Singapore |  |  | 100 |  |
| Fabrilink SEZC |  | Administrative support service |  | The Cayman Islands |  |  | 100 |  |
| Fabrinet West, Inc. |  | Manufacturing and assembly |  | United States of America (California) |  |  | 100 |  |
| Fabritek, Inc. |  | Rental service |  | United States of America (California) |  |  | 100 |  |


## fn:AllowanceForDoubtfulAccountsTextBlock

[0001193125-15-296113:notes:284]
| 7. | Allowance for doubtful accounts |


## fn:ExpensesRelatedToReductionInWorkforceDisclosureTextBlock

[0001193125-15-296113:notes:285]
| 21. | Expenses related to reduction in workforce |

[0001193125-15-296113:notes:286]
As part of the
 Company’s ongoing efforts to achieve greater efficiencies in
 all areas of its business, during the year ended June 26, 2015
 and June 28, 2013, the Company implemented a reduction in
 workforce and incurred expenses of approximately $1.2 million and
 $2.1 million, respectively, which represented severance and
 benefits costs incurred for the termination of approximately 100
 employees and 180 employees, respectively, in accordance with
 contractual obligations and local regulations.


## fn:AccruedSeveranceBenefitsDisclosureTextBlock

[0001193125-15-296113:notes:287]
| 12. | Severance liabilities |
