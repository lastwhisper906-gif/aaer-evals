# FN 8-K — 0001408710-22-000041 filed 2022-08-15

## item codes, every 8-K on or before 2022-08-16

- 2022-08-15 0001408710-22-000041 — 2.02, 5.02, 9.01
- 2022-05-02 0001408710-22-000026 — 2.02, 9.01
- 2022-01-31 0001408710-22-000016 — 2.02, 9.01
- 2022-01-19 0001408710-22-000010 — 5.02
- 2022-01-06 0001408710-22-000006 — 5.02
- 2021-12-10 0001408710-21-000051 — 5.07
- 2021-11-01 0001408710-21-000045 — 2.02, 9.01
- 2021-08-16 0001408710-21-000031 — 2.02, 5.02, 9.01
- 2021-05-03 0001408710-21-000019 — 2.02, 9.01
- 2021-02-01 0001408710-21-000008 — 2.02, 9.01
- 2020-12-11 0001193125-20-315861 — 5.07
- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2022-08-16

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001408710-22-000041:8k_2_02:1]
EX-99.1
2
fn-20220815xex991q422.htm
EX-99.1

[0001408710-22-000041:8k_2_02:2]
Document

[0001408710-22-000041:8k_2_02:3]
Exhibit 99.1

[0001408710-22-000041:8k_2_02:4]
Fabrinet Announces Fourth Quarter and Fiscal Year 2022 Financial Results

[0001408710-22-000041:8k_2_02:5]
•Record Fourth Quarter Revenue of $587.9 Million and Fiscal Year 2022 Revenue of $2.26 Billion

[0001408710-22-000041:8k_2_02:6]
•Record Fourth Quarter GAAP and Non-GAAP Net Income per Share Exceeded Guidance

[0001408710-22-000041:8k_2_02:7]
BANGKOK, Thailand – August 15, 2022 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its fourth quarter and fiscal year ended June 24, 2022.

[0001408710-22-000041:8k_2_02:8]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “We delivered strong fourth quarter results with revenue at the upper end of our guidance range and net income per share that exceeded our guidance. With strong ongoing demand trends, we are optimistic that we can continue to execute well and extend our track record of success in fiscal 2023 and beyond.”

[0001408710-22-000041:8k_2_02:9]
Fourth Quarter Fiscal Year 2022 Financial Highlights

[0001408710-22-000041:8k_2_02:10]
GAAP Results

[0001408710-22-000041:8k_2_02:11]
•Revenue for the fourth quarter of fiscal year 2022 was $587.9 million, compared to $509.6 million for the fourth quarter of fiscal year 2021.

[0001408710-22-000041:8k_2_02:12]
•GAAP net income for the fourth quarter of fiscal year 2022 was $56.2 million, compared to $42.4 million for the fourth quarter of fiscal year 2021.

[0001408710-22-000041:8k_2_02:13]
•GAAP net income per diluted share for the fourth quarter of fiscal year 2022 was $1.51, compared to $1.13 for the fourth quarter of fiscal year 2021.

[0001408710-22-000041:8k_2_02:14]
Non-GAAP Results

[0001408710-22-000041:8k_2_02:15]
•Non-GAAP net income for the fourth quarter of fiscal year 2022 was $62.6 million, compared to $49.4 million for the fourth quarter of fiscal year 2021.

[0001408710-22-000041:8k_2_02:16]
•Non-GAAP net income per diluted share for the fourth quarter of fiscal year 2022 was $1.68, compared to $1.31 for the fourth quarter of fiscal year 2021.

[0001408710-22-000041:8k_2_02:17]
Fiscal Year 2022 Financial Highlights

[0001408710-22-000041:8k_2_02:18]
GAAP Results

[0001408710-22-000041:8k_2_02:19]
•Revenue for fiscal year 2022 was $2.26 billion, compared to $1.88 billion for fiscal year 2021.

[0001408710-22-000041:8k_2_02:20]
•GAAP net income for fiscal year 2022 was $200.4 million, compared to $148.3 million for fiscal year 2021.

[0001408710-22-000041:8k_2_02:21]
•GAAP net income per diluted share for fiscal year 2022 was $5.36, compared to $3.95 for fiscal year 2021.

[0001408710-22-000041:8k_2_02:22]
Non-GAAP Results

[0001408710-22-000041:8k_2_02:23]
•Non-GAAP net income for fiscal year 2022 was $229.2 million, compared to $175.5 million for fiscal year 2021.

[0001408710-22-000041:8k_2_02:24]
•Non-GAAP net income per diluted share for fiscal year 2022 was $6.13, compared to $4.67 for fiscal year 2021.

[0001408710-22-000041:8k_2_02:25]
Share Repurchase Program Expanded

[0001408710-22-000041:8k_2_02:26]
Fabrinet also announced that its Board of Directors has approved the repurchase of up to an additional $78.7 million of Fabrinet’s ordinary shares, bringing the aggregate authorization under Fabrinet’s existing share repurchase program to $247.2 million, with $100.0 million currently remaining.

[0001408710-22-000041:8k_2_02:27]
Business Outlook

[0001408710-22-000041:8k_2_02:28]
Based on information available as of August 15, 2022, Fabrinet is issuing guidance for its first quarter of fiscal year 2023, a 14-week quarter ending September 30, 2022, as follows:

[0001408710-22-000041:8k_2_02:29]
•Fabrinet expects first quarter revenue to be in the range of $620 million to $640 million.

[0001408710-22-000041:8k_2_02:30]
•GAAP net income per diluted share is expected to be in the range of $1.51 to $1.58, based on approximately 37.6 million fully diluted shares outstanding.

[0001408710-22-000041:8k_2_02:31]
•Non-GAAP net income per diluted share is expected to be in the range of $1.72 to $1.79, based on approximately 37.6 million fully diluted shares outstanding.

[0001408710-22-000041:8k_2_02:32]
Conference Call Information

[0001408710-22-000041:8k_2_02:33]
| What: |  | Fabrinet Fourth Quarter Fiscal Year 2022 Financial Results Call |
| When: |  | August 15, 2022 |
| Time: |  | 5:00 p.m. ET |
| Live Call and Replay: |  | https://investor.fabrinet.com/events-and-presentations/events |

[0001408710-22-000041:8k_2_02:34]
A recorded version of this webcast will be available approximately two hours after the call and accessible at http://investor.fabrinet.com. The webcast will be archived on Fabrinet’s website for a period of one year.

[0001408710-22-000041:8k_2_02:35]
About Fabrinet

[0001408710-22-000041:8k_2_02:36]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China, Israel and the

[0001408710-22-000041:8k_2_02:37]
United Kingdom. For more information visit: www.fabrinet.com.

[0001408710-22-000041:8k_2_02:38]
Forward-Looking Statements

[0001408710-22-000041:8k_2_02:39]
Use of Non-GAAP Financials

[0001408710-22-000041:8k_2_02:40]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; depreciation of fair value uplift; amortization of intangibles; severance payment and others; other expenses in relation to reduction in workforce; and amortization of deferred debt issuance costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001408710-22-000041:8k_2_02:41]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001408710-22-000041:8k_2_02:42]
Investor Contact:

[0001408710-22-000041:8k_2_02:43]
Garo Toomajanian

[0001408710-22-000041:8k_2_02:44]
ir@fabrinet.com

[0001408710-22-000041:8k_2_02:45]
FABRINET

[0001408710-22-000041:8k_2_02:46]
CONSOLIDATED BALANCE SHEETS

[0001408710-22-000041:8k_2_02:47]
| (in thousands of U.S. dollars, except share data and par value) | June 24,2022 |  | June 25,2021 |
| Assets |  |  |  |
| Current assets |  |  |  |
| Cash and cash equivalents | $ | 197,996 |  |  | $ | 302,969 |  |
| Short-term restricted cash | 220 |  |  | — |  |
| Short-term investments | 280,157 |  |  | 244,963 |  |
| Trade accounts receivable, net of allowance for doubtful accounts of $1,271 and $100, respectively | 439,330 |  |  | 336,547 |  |
| Contract assets | 13,464 |  |  | 11,878 |  |
| Inventories | 557,145 |  |  | 422,133 |  |
| Prepaid expenses | 11,626 |  |  | 11,398 |  |
| Other current assets | 25,233 |  |  | 22,619 |  |
| Total current assets | 1,525,171 |  |  | 1,352,507 |  |
| Non-current assets |  |  |  |
| Long-term restricted cash | 149 |  |  | 154 |  |
| Property, plant and equipment, net | 292,277 |  |  | 241,129 |  |
| Intangibles, net | 3,508 |  |  | 4,371 |  |
| Operating right-of-use assets | 4,084 |  |  | 6,699 |  |
| Deferred tax assets | 9,800 |  |  | 9,428 |  |
| Other non-current assets | 652 |  |  | 1,834 |  |
| Total non-current assets | 310,470 |  |  | 263,615 |  |
| Total Assets | $ | 1,835,641 |  |  | $ | 1,616,122 |  |
| Liabilities and Shareholders’ Equity |  |  |  |
| Current liabilities |  |  |  |
| Long-term borrowings, current portion, net | $ | 12,156 |  |  | $ | 12,156 |  |
| Trade accounts payable | 439,684 |  |  | 346,555 |  |
| Fixed assets payable | 9,085 |  |  | 19,206 |  |
| Contract liabilities | 1,982 |  |  | 1,680 |  |
| Capital lease liability, current portion | 10 |  |  | — |  |
| Operating lease liabilities, current portion | 2,319 |  |  | 2,593 |  |
| Income tax payable | 2,898 |  |  | 3,612 |  |
| Accrued payroll, bonus and related expenses | 20,374 |  |  | 20,464 |  |
| Accrued expenses | 24,758 |  |  | 17,134 |  |
| Other payables | 25,221 |  |  | 20,958 |  |
| Total current liabilities | 538,487 |  |  | 444,358 |  |
| Non-current liabilities |  |  |  |
| Long-term borrowings, non-current portion, net | 15,202 |  |  | 27,358 |  |
| Deferred tax liability | 6,001 |  |  | 5,107 |  |
| Capital lease liability, non-current portion | 75 |  |  | — |  |
| Operating lease liabilities, non-current portion | 1,476 |  |  | 3,850 |  |
| Severance liabilities | 18,384 |  |  | 19,485 |  |
| Other non-current liabilities | 2,334 |  |  | 3,444 |  |
| Total non-current liabilities | 43,472 |  |  | 59,244 |  |
| Total Liabilities | 581,959 |  |  | 503,602 |  |
| Commitments and contingencies |  |  |  |
| Shareholders’ equity |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of June 24, 2022 and June 25, 2021) | — |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 39,048,700 shares and 38,749,045 shares issued as of June 24, 2022 and June 25, 2021, respectively; and 36,436,683 shares and 36,765,456 shares outstanding as of June 24, 2022 and June 25, 2021, respectively) | 390 |  |  | 388 |  |
| Additional paid-in capital | 196,667 |  |  | 189,445 |  |
| Less: Treasury shares (2,612,017 shares and 1,983,589 shares as of June 24, 2022 and June 25, 2021, respectively) | (147,258) |  |  | (87,343) |  |
| Accumulated other comprehensive loss | (12,793) |  |  | (6,266) |  |
| Retained earnings | 1,216,676 |  |  | 1,016,296 |  |
| Total Shareholders’ Equity | 1,253,682 |  |  | 1,112,520 |  |
| Total Liabilities and Shareholders’ Equity | $ | 1,835,641 |  |  | $ | 1,616,122 |  |

[0001408710-22-000041:8k_2_02:48]
FABRINET

[0001408710-22-000041:8k_2_02:49]
CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME

[0001408710-22-000041:8k_2_02:50]
|  | Three Months Ended |  | Year Ended |
| (in thousands of U.S. dollars, except per share data) | June 24,2022 |  | June 25,2021 |  | June 24,2022 |  | June 25,2021 |
| Revenues | $ | 587,874 |  |  | $ | 509,567 |  |  | $ | 2,262,224 |  |  | $ | 1,879,350 |  |
| Cost of revenues | (512,941) |  |  | (448,483) |  |  | (1,983,630) |  |  | (1,657,987) |  |
| Gross profit | 74,933 |  |  | 61,084 |  |  | 278,594 |  |  | 221,363 |  |
| Selling, general and administrative expenses | (18,529) |  |  | (17,489) |  |  | (73,941) |  |  | (70,567) |  |
| Expenses related to reduction in workforce | — |  |  | — |  |  | (135) |  |  | (43) |  |
| Operating income | 56,404 |  |  | 43,595 |  |  | 204,518 |  |  | 150,753 |  |
| Interest income | 735 |  |  | 627 |  |  | 2,205 |  |  | 3,783 |  |
| Interest expense | (85) |  |  | (302) |  |  | (432) |  |  | (1,100) |  |
| Foreign exchange gain (loss), net | 1,304 |  |  | 284 |  |  | 2,302 |  |  | 508 |  |
| Other income (expense), net | (276) |  |  | (3,863) |  |  | (1,627) |  |  | (3,460) |  |
| Income before income taxes | 58,082 |  |  | 40,341 |  |  | 206,966 |  |  | 150,484 |  |
| Income tax expense | (1,893) |  |  | 2,072 |  |  | (6,586) |  |  | (2,143) |  |
| Net income | 56,189 |  |  | 42,413 |  |  | 200,380 |  |  | 148,341 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities | (2,711) |  |  | (245) |  |  | (6,326) |  |  | (1,182) |  |
| Change in net unrealized gain (loss) on derivative instruments | (3,321) |  |  | 717 |  |  | (578) |  |  | (5,106) |  |
| Change in net retirement benefits plan – prior service cost | 174 |  |  | 163 |  |  | 622 |  |  | 584 |  |
| Change in foreign currency translation adjustment | (47) |  |  | 38 |  |  | (245) |  |  | 585 |  |
| Total other comprehensive income (loss), net of tax | (5,905) |  |  | 673 |  |  | (6,527) |  |  | (5,119) |  |
| Net comprehensive income | $ | 50,284 |  |  | $ | 43,086 |  |  | $ | 193,853 |  |  | $ | 143,222 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 1.53 |  |  | $ | 1.15 |  |  | $ | 5.43 |  |  | $ | 4.02 |  |
| Diluted | $ | 1.51 |  |  | $ | 1.13 |  |  | $ | 5.36 |  |  | $ | 3.95 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |
| Basic | 36,668 |  |  | 36,857 |  |  | 36,876 |  |  | 36,872 |  |
| Diluted | 37,222 |  |  | 37,676 |  |  | 37,394 |  |  | 37,555 |  |

[0001408710-22-000041:8k_2_02:51]
FABRINET

[0001408710-22-000041:8k_2_02:52]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001408710-22-000041:8k_2_02:53]
|  | Year Ended |
| (in thousands of U.S. dollars) | June 24,2022 |  | June 25,2021 |
| Cash flows from operating activities |  |  |  |
| Net income for the period | $ | 200,380 |  |  | $ | 148,341 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 38,738 |  |  | 36,252 |  |
| Gain on disposal of property, plant and equipment | (101) |  |  | 13 |  |
| Gain from sales and maturities of available-for-sale securities | 13 |  |  | (187) |  |
| Amortization of discount (premium) of short-term investment | 3,691 |  |  | 2,093 |  |
| Amortization of deferred debt issuance costs | 32 |  |  | 32 |  |
| (Reversal of) allowance for doubtful accounts | 1,171 |  |  | (343) |  |
| Unrealized gain on exchange rate and fair value of foreign currency forward contracts | (2,832) |  |  | (859) |  |
| Amortization of fair value at hedge inception of interest rate swaps | (937) |  |  | (1,299) |  |
| Share-based compensation | 28,048 |  |  | 25,462 |  |
| Deferred income tax | (191) |  |  | (3,473) |  |
| Other non-cash expenses | 1,390 |  |  | (450) |  |
| Changes in operating assets and liabilities |  |  |  |
| Trade accounts receivable | (103,970) |  |  | (63,810) |  |
| Contract assets | (1,586) |  |  | 1,378 |  |
| Inventories | (135,011) |  |  | (112,349) |  |
| Other current assets and non-current assets | (6,425) |  |  | (10,753) |  |
| Trade accounts payable | 93,499 |  |  | 96,312 |  |
| Contract liabilities | 302 |  |  | 124 |  |
| Income tax payable | (761) |  |  | 1,353 |  |
| Severance liabilities | 1,033 |  |  | 3,181 |  |
| Other current liabilities and non-current liabilities | 7,763 |  |  | 1,139 |  |
| Net cash provided by operating activities | 124,246 |  |  | 122,157 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of short-term investments | (198,318) |  |  | (244,330) |  |
| Proceeds from sales of short-term investments | 19,463 |  |  | 79,439 |  |
| Proceeds from maturities of short-term investments | 133,632 |  |  | 179,532 |  |
| Funds repayment from customer to support transfer of manufacturing operations | — |  |  | 24,310 |  |
| Purchase of property, plant and equipment | (89,588) |  |  | (46,060) |  |
| Purchase of intangibles | (995) |  |  | (1,915) |  |
| Proceeds from disposal of property, plant and equipment | 263 |  |  | 90 |  |
| Net cash used in investing activities | (135,543) |  |  | (8,934) |  |
| Cash flows from financing activities |  |  |  |
| Repayment of long-term borrowings | (12,188) |  |  | (12,188) |  |
| Repayment of finance lease liabilities | (7) |  |  | (100) |  |
| Repurchase of ordinary shares | (59,915) |  |  | (18,842) |  |
| Withholding tax related to net share settlement of restricted share units | (20,824) |  |  | (11,624) |  |
| Net cash used in financing activities | (92,934) |  |  | (42,754) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | (104,231) |  |  | $ | 70,469 |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at the beginning of period | $ | 303,123 |  |  | $ | 232,832 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | (104,231) |  |  | 70,469 |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash | (527) |  |  | (178) |  |
| Cash, cash equivalents and restricted cash at the end of period | $ | 198,365 |  |  | $ | 303,123 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment-related payables | $ | 9,085 |  |  | $ | 19,206 |  |

[0001408710-22-000041:8k_2_02:54]
FABRINET

[0001408710-22-000041:8k_2_02:55]
CONSOLIDATED STATEMENTS OF CASH FLOWS (Continued)

[0001408710-22-000041:8k_2_02:56]
|  | Year Ended |
| Supplemental disclosures | June 24,2022 |  | June 25,2021 |
| Cash paid for |  |  |  |
| Interest | $ | 2,244 |  |  | $ | 2,438 |  |
| Taxes | $ | 9,296 |  |  | $ | 7,945 |  |
| Cash received for interest | $ | 1,603 |  |  | $ | 4,445 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment related payables | $ | 9,085 |  |  | $ | 19,206 |  |

[0001408710-22-000041:8k_2_02:57]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the consolidated balance sheets that sum to the total of the same amounts shown in the consolidated statements of cash flows:

[0001408710-22-000041:8k_2_02:58]
|  | As of |
| (amount in thousands) | June 24,2022 |  | June 25,2021 |
| Cash and cash equivalents | $ | 197,996 |  |  | $ | 302,969 |  |
| Restricted cash | 369 |  |  | 154 |  |
| Cash, cash equivalents and restricted cash | $ | 198,365 |  |  | $ | 303,123 |  |

[0001408710-22-000041:8k_2_02:59]
FABRINET

[0001408710-22-000041:8k_2_02:60]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-22-000041:8k_2_02:61]
|  | Three Months Ended |  | Year Ended |
|  | June 24,2022 |  | June 25,2021 |  | June 24,2022 |  | June 25,2021 |
| (in thousands of U.S. dollars, except share data) | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |
| GAAP measures | $ | 56,189 |  |  | $ | 1.51 |  |  | $ | 42,413 |  |  | $ | 1.13 |  |  | $ | 200,380 |  |  | $ | 5.36 |  |  | $ | 148,341 |  |  | $ | 3.95 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 1,388 |  |  | 0.04 |  |  | 1,380 |  |  | 0.04 |  |  | 5,967 |  |  | 0.16 |  |  | 6,185 |  |  | 0.16 |  |
| Depreciation of fair value uplift | — |  |  | — |  |  | 91 |  |  | 0.00 |  | 92 |  |  | 0.00 |  | 347 |  |  | 0.01 |
| Total related to gross profit | 1,388 |  |  | 0.04 |  |  | 1,471 |  |  | 0.04 |  |  | 6,059 |  |  | 0.16 |  |  | 6,532 |  |  | 0.17 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 4,959 |  |  | 0.13 |  |  | 5,340 |  |  | 0.14 |  |  | 22,081 |  |  | 0.59 |  |  | 19,277 |  |  | 0.52 |  |
| Amortization of intangibles | 94 |  |  | 0.00 |  |  | 124 |  |  | 0.00 |  |  | 422 |  |  | 0.01 |  |  | 506 |  |  | 0.01 |  |
| Severance payment and others | — |  |  | — |  |  | — |  |  | — |  |  | 105 |  |  | 0.00 |  |  | 755 |  |  | 0.02 |  |
| Total related to selling, general and administrative expenses | 5,053 |  |  | 0.13 |  |  | 5,464 |  |  | 0.14 |  |  | 22,608 |  |  | 0.60 |  |  | 20,538 |  |  | 0.55 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other expenses in relation to reduction in workforce | — |  |  | — |  |  | — |  |  | — |  | 135 |  |  | 0.01 |  | 43 |  |  | 0.00 |
| Amortization of deferred debt issuance costs | 8 |  |  | 0.00 |  | 8 |  |  | 0.00 |  | 32 |  |  | 0.00 |  | 32 |  |  | 0.00 |
| Total related to other incomes and other expenses | 8 |  |  | 0.00 |  | 8 |  |  | 0.00 |  | 167 |  |  | 0.01 |  | 75 |  |  | 0.00 |
| Total related to net income & EPS | 6,449 |  |  | 0.17 |  |  | 6,943 |  |  | 0.18 |  |  | 28,834 |  |  | 0.77 |  |  | 27,145 |  |  | 0.72 |  |
| Non-GAAP measures | $ | 62,638 |  |  | $ | 1.68 |  |  | $ | 49,356 |  |  | $ | 1.31 |  |  | $ | 229,214 |  |  | $ | 6.13 |  |  | $ | 175,486 |  |  | $ | 4.67 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  | 37,222 |  |  |  |  | 37,676 |  |  |  |  | 37,394 |  |  |  | 37,555 |
| Non-GAAP diluted shares |  |  | 37,222 |  |  |  |  | 37,676 |  |  |  |  | 37,394 |  |  |  | 37,555 |

[0001408710-22-000041:8k_2_02:62]
FABRINET

[0001408710-22-000041:8k_2_02:63]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001408710-22-000041:8k_2_02:64]
| (amount in thousands) |  | Three Months Ended |  | Year Ended |
|  |  | June 24,2022 |  | June 25,2021 |  | June 24,2022 |  | June 25,2021 |
| Net cash provided by operating activities |  | $ | 16,349 |  |  | $ | 42,841 |  |  | $ | 124,246 |  |  | $ | 122,157 |  |
| Less: Purchase of property, plant and equipment |  | (14,261) |  |  | (12,791) |  |  | (89,588) |  |  | (46,060) |  |
| Non-GAAP free cash flow |  | $ | 2,088 |  |  | $ | 30,050 |  |  | $ | 34,658 |  |  | $ | 76,097 |  |

[0001408710-22-000041:8k_2_02:65]
FABRINET

[0001408710-22-000041:8k_2_02:66]
GUIDANCE FOR QUARTER ENDING SEPTEMBER 30, 2022

[0001408710-22-000041:8k_2_02:67]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-22-000041:8k_2_02:68]
|  | DilutedEPS |
| GAAP net income per diluted share: | $1.51 to $1.58 |
| Related to cost of revenues: |  |
| Share-based compensation expenses | 0.06 |
| Total related to gross profit | 0.06 |
| Related to selling, general and administrative expenses: |  |
| Share-based compensation expenses | 0.15 |
| Total related to selling, general and administrative expenses | 0.15 |
| Total related to net income & EPS | 0.21 |
| Non-GAAP net income per diluted share | $1.72 to $1.79 |

## item 5.02 — body, verbatim

[0001408710-22-000041:8k_body:1]
Item 5.02    Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001408710-22-000041:8k_body:2]
Fiscal 2023 Executive Incentive Plan

[0001408710-22-000041:8k_body:3]
On August 9, 2022, the Compensation Committee (the “Compensation Committee”) of the board of directors of Fabrinet adopted an executive incentive plan (the “Cash Bonus Plan”) for the Company’s fiscal year ending June 30, 2023 (“fiscal 2023”). The Cash Bonus Plan is an incentive program designed to motivate participants to achieve the Company’s financial objectives, and to reward them for their achievements when those objectives are met. All of the Company’s executive officers pursuant to Section 16 of the Exchange Act are eligible to participate in the Cash Bonus Plan (individually, a “Participant,” and collectively, the “Participants”). The Cash Bonus Plan provides for target and maximum bonus amounts as set forth in the table below. The maximum bonus that a Participant may receive under the Cash Bonus Plan is 120% of such Participant’s target bonus.

[0001408710-22-000041:8k_body:4]
Name

[0001408710-22-000041:8k_body:5]
Fiscal 2023 Target Bonus

[0001408710-22-000041:8k_body:6]
Fiscal 2023 Maximum Bonus

[0001408710-22-000041:8k_body:7]
Seamus Grady

[0001408710-22-000041:8k_body:8]
$1,495,000

[0001408710-22-000041:8k_body:9]
$1,794,000

[0001408710-22-000041:8k_body:10]
Dr. Harpal Gill

[0001408710-22-000041:8k_body:11]
$1,352,390

[0001408710-22-000041:8k_body:12]
$1,622,868

[0001408710-22-000041:8k_body:13]
Csaba Sverha

[0001408710-22-000041:8k_body:14]
$488,750

[0001408710-22-000041:8k_body:15]
$586,500

[0001408710-22-000041:8k_body:16]
Edward Archer

[0001408710-22-000041:8k_body:17]
$400,000

[0001408710-22-000041:8k_body:18]
$480,000

[0001408710-22-000041:8k_body:19]
The amount of bonus actually paid to a Participant under the Cash Bonus Plan will be based 50% on the extent of achievement of a fiscal 2023 revenue metric and 50% on the extent of achievement of a fiscal 2023 non-GAAP operating margin metric. As achievement of each financial metric is considered independently from the other, the Company must meet a threshold for each metric in order for a Participant to receive any credit for that metric. If the Company achieves 100% of a target financial metric, bonuses would be paid out at 100% of the target amount with respect to that financial metric component. If the Company achieves 105% or more of a target financial metric, bonuses would be paid out at 120% of the target amount (which is the maximum) with respect to that financial metric component. Achievement of the revenue or non-GAAP operating margin metric for fiscal 2023 at a level between 100% and 105% of the target metric will result in a bonus amount for the applicable metric that is scaled from 100% to 120% of the target amount in a linear fashion. Achievement of the revenue or non-GAAP operating margin metric for fiscal 2023 at a level between 90% and 100% of the target metric will result in a bonus amount for the applicable metric that is scaled from 20% to 100% of the target amount in a linear fashion.

[0001408710-22-000041:8k_body:20]
Fiscal 2023 Salaries

[0001408710-22-000041:8k_body:21]
On August 9, 2022, the Compensation Committee approved an increase to the annual base salaries of the Company’s named executive officers set forth below, effective as of June 25, 2022, the first day of fiscal 2023.

[0001408710-22-000041:8k_body:22]
Name

[0001408710-22-000041:8k_body:23]
Title

[0001408710-22-000041:8k_body:24]
Previous Annual Base Salary

[0001408710-22-000041:8k_body:25]
Fiscal 2023 Annual Base Salary

[0001408710-22-000041:8k_body:26]
Change

[0001408710-22-000041:8k_body:27]
Seamus Grady

[0001408710-22-000041:8k_body:28]
Chief Executive Officer

[0001408710-22-000041:8k_body:29]
$1,025,000

[0001408710-22-000041:8k_body:30]
$1,150,000

[0001408710-22-000041:8k_body:31]
12.2%

[0001408710-22-000041:8k_body:32]
Dr. Harpal Gill

[0001408710-22-000041:8k_body:33]
President and Chief Operating Officer

[0001408710-22-000041:8k_body:34]
$1,010,000

[0001408710-22-000041:8k_body:35]
$1,040,300

[0001408710-22-000041:8k_body:36]
3.0%

[0001408710-22-000041:8k_body:37]
Csaba Sverha

[0001408710-22-000041:8k_body:38]
Executive Vice President, Chief Financial Officer

[0001408710-22-000041:8k_body:39]
$500,000

[0001408710-22-000041:8k_body:40]
$575,000

[0001408710-22-000041:8k_body:41]
15.0%

[0001408710-22-000041:8k_body:42]
Edward Archer

[0001408710-22-000041:8k_body:43]
Executive Vice President, Sales & Marketing

[0001408710-22-000041:8k_body:44]
$460,000

[0001408710-22-000041:8k_body:45]
$500,000

[0001408710-22-000041:8k_body:46]
8.7%

[0001408710-22-000041:8k_body:47]
Equity Award Grants

[0001408710-22-000041:8k_body:48]
On August 9, 2022, the Compensation Committee approved the grant, effective as of August 18, 2022 (the “Grant Date”), of the following dollar values of restricted share units (“RSUs”), performance share units (“PSUs”) and “stretch” PSUs (“Stretch PSUs”), rounded down to the nearest whole share, to the Company’s named executive officers as a component of their fiscal 2023 compensation:

[0001408710-22-000041:8k_body:49]
Name

[0001408710-22-000041:8k_body:50]
Grant Date Value of RSUs

[0001408710-22-000041:8k_body:51]
Grant Date Value of PSUs

[0001408710-22-000041:8k_body:52]
Grant Date Value of “Stretch” PSUs

[0001408710-22-000041:8k_body:53]
Seamus Grady

[0001408710-22-000041:8k_body:54]
$2,500,000

[0001408710-22-000041:8k_body:55]
$2,500,000

[0001408710-22-000041:8k_body:56]
$2,500,000

[0001408710-22-000041:8k_body:57]
Dr. Harpal Gill

[0001408710-22-000041:8k_body:58]
$1,675,000

[0001408710-22-000041:8k_body:59]
$1,600,000

[0001408710-22-000041:8k_body:60]
$1,600,000

[0001408710-22-000041:8k_body:61]
Csaba Sverha

[0001408710-22-000041:8k_body:62]
$850,000

[0001408710-22-000041:8k_body:63]
$850,000

[0001408710-22-000041:8k_body:64]
$850,000

[0001408710-22-000041:8k_body:65]
Edward Archer

[0001408710-22-000041:8k_body:66]
$750,000

[0001408710-22-000041:8k_body:67]
$750,000

[0001408710-22-000041:8k_body:68]
$750,000

[0001408710-22-000041:8k_body:69]
The grants will be made under the Company’s 2020 Equity Incentive Plan. The RSUs will be scheduled to vest in equal annual installments over a period of three years on each anniversary of the Grant Date, subject to the individual’s continued service with the Company through each such vesting date.

[0001408710-22-000041:8k_body:70]
The PSUs will vest, if at all, following a 2-year performance period, on the date the Compensation Committee certifies achievement of the performance criteria set forth below, subject to the individual’s continued service with the Company through such vesting date. Vesting of the PSUs will be based 50% on achievement of a cumulative fiscal 2023 and fiscal 2024 revenue goal (the “PSU Revenue Target”) and 50% on achievement of a cumulative fiscal 2023 and fiscal 2024 non-GAAP operating margin goal (the “PSU Operating Margin Target”). As achievement of each financial goal is considered independently from the other, the Company must meet a threshold for each goal in order for an individual to receive any credit for that goal. If the Company achieves 100% or more of a target financial goal, the PSUs will vest as to 100% of the PSUs allocated to that financial goal. Achievement of the PSU Revenue Target or the PSU Operating Margin Target at a level between 90% and 100% will result in a number of shares vesting for the applicable goal that is scaled from 20% to 100% of the PSUs allocated to that goal in a linear fashion.

[0001408710-22-000041:8k_body:71]
The Stretch PSUs will vest, if at all, following a 2-year performance period, on the date the Compensation Committee certifies achievement of the performance criteria set forth below, subject to the individual’s continued service with the Company through such vesting date. Vesting of the Stretch PSUs will be based 50% on achievement of a cumulative fiscal 2023 and fiscal 2024 revenue goal that is 5% higher than the PSU Revenue Target (the “Stretch PSU Revenue Target”) and 50% on achievement of a cumulative fiscal 2023 and fiscal 2024 non-GAAP operating margin goal that is 5% higher than the PSU Operating Margin Target (the “Stretch PSU Operating Margin Target”). As achievement of each financial goal is considered independently from the other, the Company must meet a threshold for each goal in order for an individual to receive any credit for that goal. The Company must exceed the PSU Revenue Target or the PSU Operating Margin Target in order for any of the Stretch PSUs to vest. If the Company achieves 100% or more of a target financial goal, the Stretch PSUs will vest as to 100% of the PSUs allocated to that financial goal. Achievement of the Stretch PSU Revenue Target at a level between its threshold PSU Revenue Target and 100% will result in a number of shares vesting for that goal that is scaled from 0% to 100% of the PSUs allocated to that goal in a linear fashion. Achievement of the Stretch PSU Operating Margin Target at a level between its threshold PSU Operating Margin Target and 100% will result in a number of shares vesting for that goal that is scaled from 0% to 100% of the PSUs allocated to that goal in a linear fashion.

[0001408710-22-000041:8k_body:72]
In the event of a change in control of Fabrinet, the awards of PSUs and Stretch PSUs described above that are then outstanding will be treated as follows. To the extent that the performance period has not yet been completed as of the change in control, (1) the performance period for any Company revenue goals will be shortened to end shortly before the change in control and achievement of revenue will be measured based on goals that are prorated for the shortened performance period, and (2) the performance period for any Company operating margin goals will be deemed to be the last four consecutive fiscal quarters of the Company completed before the change in control. Any PSUs for which such applicable goal is deemed achieved will be scheduled to vest subject to the individual’s continued service with Fabrinet through the last date of the award’s original performance period, and will be treated as a time-based award that may be eligible for certain vesting acceleration under Mr. Grady’s Change in Control and Severance Agreement or the Fabrinet Executive Change in Control and Severance Plan, as applicable, upon a qualifying termination during a specified change in control period.
