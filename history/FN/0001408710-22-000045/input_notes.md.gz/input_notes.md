# FN notes — 0001408710-22-000045


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001408710-22-000045:notes:1]
Portions of the registrant’s definitive proxy statement relating to its 2022 annual meeting of shareholders are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated. Such proxy statement will be filed with the U.S. Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001408710-22-000045:notes:2]
Summary of significant accounting policies
Principles of consolidation

[0001408710-22-000045:notes:3]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. Fiscal years 2022, 2021, and 2020 ended on June 24, 2022, June 25, 2021, and June 26, 2020, respectively, and each were 52-week years. Fiscal year 2023 will end on June 30, 2023 and be a 53-week year. The additional week in a 53-week year is added to the first quarter, making such quarter consist of 14 weeks.

[0001408710-22-000045:notes:4]
The consolidated financial statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) and include Fabrinet and its subsidiaries. All inter-company accounts and transactions have been eliminated.

[0001408710-22-000045:notes:5]
Use of estimates

[0001408710-22-000045:notes:6]
The preparation of the Company’s consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements, and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisitions, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information. Additionally, the extent to which the evolving COVID-19 pandemic impacts the Company’s consolidated financial statements will depend on a number of factors, including the magnitude and duration of the pandemic. These estimates may change, as new events occur and additional information is obtained, as well as other factors related to COVID-19 that could result in material impacts to our consolidated financial statements in future reporting periods.

[0001408710-22-000045:notes:7]
Foreign currency transactions and translation

[0001408710-22-000045:notes:8]
The consolidated financial statements are presented in United States dollars (“$” or “USD”). The functional currency of Fabrinet and most of its subsidiaries is the USD.

[0001408710-22-000045:notes:9]
With respect to subsidiaries that use USD as their functional currency, transactions denominated in a currency other than USD are translated into USD at the rates of exchange in effect at the date of the transaction. Monetary assets and liabilities denominated in foreign currencies are translated into the functional currency at the exchange rate prevailing at the consolidated balance sheet dates. Transaction gains and losses are included in foreign exchange gain (loss) in the accompanying consolidated statements of operations and comprehensive income.

[0001408710-22-000045:notes:10]
Fabrinet translates the assets and liabilities of its subsidiaries that do not use USD as their functional currency into USD using exchange rates in effect at the end of each period. Revenue and expenses for such subsidiaries are translated using rates that approximate those in effect during the period. Gains and losses from these translations are recognized in foreign currency translation adjustment included in accumulated other comprehensive income (loss) (“AOCI”) in the Company’s consolidated balance sheets.

[0001408710-22-000045:notes:11]
Cash and cash equivalents

[0001408710-22-000045:notes:12]
All highly liquid investments with original maturities of three months or less from the date of purchase are classified as cash equivalents. Cash and cash equivalents consist of cash deposited in checking accounts, time deposits with maturities of less than three months, money market accounts, and short-term investments with maturities of three months or less at the date of purchase.

[0001408710-22-000045:notes:13]
Short-term investments

[0001408710-22-000045:notes:14]
Management determines the appropriate classification of its investments at the time of purchase and re-evaluates the designations at each balance sheet date. The maturities of the Company’s short-term investments generally range from three months to three years.

[0001408710-22-000045:notes:15]
The short-term investments in debt securities are carried at either amortized cost or fair value. Investments in debt securities that the Company has the positive intent and ability to hold to maturity are carried at amortized cost and

[0001408710-22-000045:notes:16]
classified as held-to-maturity. Investments in debt securities that are not classified as held-to-maturity are carried at fair value and classified as available-for-sale with any unrealized gains and losses included in AOCI in the consolidated balance sheets. The Company determines realized gains or losses on sale of available-for-sale debt securities on a specific identification method and records such gains or losses as interest income in the consolidated statements of operations and comprehensive income.

[0001408710-22-000045:notes:17]
Held-to-maturity debt securities require the use of the current expected credit losses (“CECL”) impairment model to assess the expected credit loss. According to the CECL model, the Company requires the immediate recognition of estimated expected credit losses over the life of the financial instrument through the allowance for credit losses account. The allowance for credit losses is a valuation account that is deducted from, or added to, the amortized cost basis of the financial asset to present the net amount expected to be collected on the financial asset. In determining expected credit losses, the Company considers relevant qualitative factors including, but not limited to, term and structure of the instrument, credit rating by rating agencies and historic credit losses adjusted for current conditions and reasonable and supportable forecasts.

[0001408710-22-000045:notes:18]
Available-for-sale debt securities are required to be individually evaluated for impairment. A security is considered impaired if the fair value of the security is less than its amortized cost basis.

[0001408710-22-000045:notes:19]
An impairment is considered when (i) the Company has the intent to sell the security, (ii) it is more likely than not that the Company will be required to sell the security before recovery of the entire amortized cost basis, or (iii) the Company does not expect to recover the entire amortized cost basis of the security.

[0001408710-22-000045:notes:20]
If an impairment is considered based on condition (i) or (ii), the entire difference between the amortized cost and the fair value of the debt security is recognized as interest income and other income (expense), net in the consolidated statements of operations and comprehensive income.

[0001408710-22-000045:notes:21]
If an impairment is considered based on condition (iii), the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) is recognized in interest and other income (expense), net in the consolidated statements of operations and comprehensive income, and any remaining unrealized losses are included in AOCI in the consolidated balance sheets.

[0001408710-22-000045:notes:22]
Trade accounts receivable

[0001408710-22-000045:notes:23]
Accounts receivable are recorded and carried at the original invoiced amount less an allowance for any potential uncollectible amounts. The Company estimates expected credit losses for the allowance for doubtful accounts based upon its assessment of various factors, including historical experience, the age of the accounts receivable balances, credit quality of its customers, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect the Company’s ability to collect from customers. The estimated credit loss allowance is recorded as selling, general and administrative expenses in the consolidated statements of operations and comprehensive income.

[0001408710-22-000045:notes:24]
Contract assets

[0001408710-22-000045:notes:25]
A contract asset is recognized when the Company has recognized revenues prior to generating an invoice for payment. Contract assets are classified separately within the consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. The Company estimates expected credit losses for the allowance for contract assets based upon its assessment of various factors, including historical experience, the age of the contract assets balances, credit quality of its customers, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect the Company’s ability to collect from customers. The estimated credit loss allowance is recorded as selling, general and administrative expenses in the Company's consolidated statements of operations and comprehensive income.

[0001408710-22-000045:notes:26]
Contract liabilities

[0001408710-22-000045:notes:27]
A contract liability is recognized when the Company has advance payment arrangements with customers. The contract liabilities balance is normally recognized as revenue within six months.

[0001408710-22-000045:notes:28]
Inventory

[0001408710-22-000045:notes:29]
Inventory is stated at the lower of cost or market value. Cost is estimated using the standard costing method, computed on a first-in, first-out basis, with adjustments for variances to reflect actual costs not in excess of net realizable market value. Market value is the estimated selling price in the ordinary course of business, less the costs of completion and

[0001408710-22-000045:notes:30]
selling expenses. The Company assesses the valuation of inventory on a quarterly basis and writes down the value for estimated excess and obsolete inventory based upon estimates of future demand.

[0001408710-22-000045:notes:31]
Leases

[0001408710-22-000045:notes:32]
Operating leases

[0001408710-22-000045:notes:33]
The Company determines if an arrangement contains a lease at inception. The Company applies the guidance in ASC 842 to determine whether a contract is, or contains, a lease. A contract is or contains a lease if the contract conveys the right to control the use of identified property, plant, or equipment (an identified asset) for a period of time in exchange for consideration. Operating leases are included in operating lease right of use (“ROU”) assets and operating lease liabilities within the Company’s consolidated balance sheets. The Company rents certain real estate under agreements that are classified as operating leases.

[0001408710-22-000045:notes:34]
Operating lease ROU assets and operating lease liabilities are recognized based on the present value of the future minimum lease payments over the lease term at commencement date. As most of the Company’s leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the lease commencement date in determining the present value of future payments. The operating lease ROU assets also include any lease payments made and exclude lease incentives and initial direct costs incurred. Variable lease payments are expensed as incurred and are not included within the ROU asset and lease liability calculation. Variable lease payments primarily include reimbursements of costs incurred by lessors for common area maintenance and utilities. The Company’s lease terms may include options to extend or terminate the lease when it is reasonably certain that the Company will exercise that option.

[0001408710-22-000045:notes:35]
Leases with an initial term of 12 months or less are not recorded on the balance sheet. The Company recognizes lease expense for these leases on a straight-line basis over the lease term. The Company does not account for lease components (e.g., fixed payments including rent) separately from the non-lease components (e.g., common-area maintenance costs).

[0001408710-22-000045:notes:36]
Finance leases

[0001408710-22-000045:notes:37]
Finance leases are accounted for in a manner similar to financed purchases. The right-of-use asset is amortized to amortization expense. Interest expense is recorded in connection with the lease liability.

[0001408710-22-000045:notes:38]
Property, plant and equipment

[0001408710-22-000045:notes:39]
Land is stated at historical cost. Other property, plant and equipment, except for construction in process and machinery under installation, are stated at historical cost less accumulated depreciation. Repair and maintenance costs are expensed as incurred. Depreciation is calculated using the straight-line method to write-off the cost of each asset to its residual value over its estimated useful life as follows:

[0001408710-22-000045:notes:40]
| Land improvements |  | 10 years |
| Building and building improvements |  | 5-30 years |
| Leasehold improvements | Shorter of useful life or lease term |
| Manufacturing equipment |  | 3-7 years |
| Office equipment |  | 3-5 years |
| Motor vehicles |  | 3-5 years |
| Computer hardware |  | 3-5 years |

[0001408710-22-000045:notes:41]
Construction in process and machinery under installation is stated at historic cost and depreciation begins after it is constructed and fully installed and is ready for its intended use in the operations of the Company.

[0001408710-22-000045:notes:42]
Gains and losses on disposal are determined by comparing proceeds with carrying amounts and are included in other income in the consolidated statements of operations and comprehensive income.

[0001408710-22-000045:notes:43]
The Company reviews long-lived assets or asset groups for recoverability on a quarterly basis for any events or changes in circumstances that indicate that their carrying amount may not be recoverable. Recoverability of long-lived assets or asset groups is measured by comparing their carrying amount to the projected undiscounted cash flows that the long-lived assets or asset groups are expected to generate. If such assets are considered to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the long-lived assets exceeds its fair value.

[0001408710-22-000045:notes:44]
Intangibles

[0001408710-22-000045:notes:45]
Intangibles are stated at historical cost less amortization. Amortization of customer relationships is calculated using the accelerated method as to reflect the pattern in which the economic benefits of the intangible assets are consumed. Amortization of other intangibles is calculated using the straight-line method.

[0001408710-22-000045:notes:46]
Intangible assets are reviewed for impairment quarterly or more frequently whenever changes or circumstances indicate the carrying amount of related assets may not be recoverable.

[0001408710-22-000045:notes:47]
Goodwill

[0001408710-22-000045:notes:48]
Goodwill arising from acquisition is primarily attributable to the ability to expand future products and services and the assembled workforce. Goodwill is reviewed annually for impairment or more frequently whenever circumstances indicate that the carrying amount of a reporting unit may exceed its fair value. The impairment charge is based on that difference and is limited to the amount of goodwill allocated to that unit. The Company conducts impairment testing for goodwill at the reporting unit level. Reporting units may be operating segments as a whole, or an operation one level below an operating segment, referred to as a component. The Company has determined that its reporting unit is Fabrinet UK.

[0001408710-22-000045:notes:49]
The Company may initiate goodwill impairment testing by considering qualitative factors to determine whether it is more likely than not that a reportable segment’s carrying value is greater than its fair value. If the Company’s qualitative assessment indicates it is more likely than not that the fair value of a reporting unit exceeds its carrying value, no further analysis is required and goodwill is not impaired. Otherwise, the Company performs a quantitative goodwill impairment test to determine if goodwill is impaired. The quantitative test compares the fair value of a reporting unit with its carrying amount, including goodwill. If the fair value of the reportable segment exceeds the carrying value of the net assets associated with the segment, goodwill is not considered impaired. If the carrying value of the net assets associated with the reportable segment exceeds the fair value of the segment, the Company recognizes an impairment loss in an amount equal to the excess, not to exceed the carrying value of the reportable segment’s goodwill. The reporting unit’s carrying value used in an impairment test represents the assignment of various assets and liabilities, excluding certain corporate assets and liabilities, such as cash, investments, and debt.

[0001408710-22-000045:notes:50]
Goodwill is not deductible for tax purposes. Accordingly, if goodwill is impaired for financial reporting purposes, there is no impact on deferred taxes.

[0001408710-22-000045:notes:51]
Treasury shares

[0001408710-22-000045:notes:52]
Treasury share purchases are accounted for under the cost method whereby the entire cost of the acquired stock is recorded as treasury shares. Gains and losses in excess of par value on the subsequent reissuance of shares are credited or charged to additional paid-in capital in the consolidated balance sheets using the average-cost method.

[0001408710-22-000045:notes:53]
Borrowing costs

[0001408710-22-000045:notes:54]
Borrowing costs are accounted for on an accrual basis and are charged to the consolidated statements of operations and comprehensive income in the year incurred, except for interest costs on general and specific borrowings attributable to finance certain qualifying assets. Such costs to finance qualifying assets are capitalized during the period of time that is required to complete and prepare the assets for their intended use, as part of the cost of the assets. All other borrowing costs are expensed as incurred.

[0001408710-22-000045:notes:55]
Where funds are not borrowed for a specific acquisition, construction or production of assets, the capitalization rate used to determine the amount of interest to be capitalized is the weighted average interest rate applicable to the Company’s outstanding borrowings during the year. Where funds are borrowed specifically for the acquisition, construction or production of assets, the amount of borrowing costs eligible for capitalization on the respective assets is determined as the actual borrowing costs are incurred on that borrowing during the respective periods.

[0001408710-22-000045:notes:56]
Fair value of financial instruments

[0001408710-22-000045:notes:57]
Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. A fair value hierarchy is established which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs for the valuation of an asset or liability as of the measurement date. The three levels of inputs that may be used to measure fair value are defined as follows:

[0001408710-22-000045:notes:58]
Level 1 inputs are quoted prices (unadjusted) in active markets for identical assets or liabilities.

[0001408710-22-000045:notes:59]
Level 2 inputs for similar assets and liabilities in active markets other than quoted prices included within Level 1 that are observable for the asset or liability, either directly or indirectly, for substantially the full term of the asset or liability.

[0001408710-22-000045:notes:60]
Level 3 inputs that are significant to the fair value measurement and unobservable (i.e. supported by little or no market activity), which require the reporting entity to develop its own valuation techniques and assumptions.

[0001408710-22-000045:notes:61]
The Company utilizes the market approach to measure fair value for its financial assets and liabilities. The market approach uses prices and other relevant information generated by market transactions involving identical or comparable assets or liabilities.

[0001408710-22-000045:notes:62]
The carrying amounts of certain financial instruments, which include cash and cash equivalents, trade accounts receivable, contract assets, trade accounts payable, and contract liabilities, approximate their fair values due to their short maturities. The carrying amounts of borrowings approximate their fair values as the applicable interest rate is based on market interest rates. The particular recognition methods adopted are disclosed in the individual policy statements associated with each item.

[0001408710-22-000045:notes:63]
Derivatives

[0001408710-22-000045:notes:64]
The derivative assets and liabilities are measured at fair value and recognized on the consolidated balance sheets by offsetting the fair value amounts under master netting arrangements. For presentation in consolidated balance sheets, the Company may choose not to separate a derivative into its current and non-current portion as follows:

[0001408710-22-000045:notes:65]
•A derivative for which the fair value is a net liability is classified in total as current.

[0001408710-22-000045:notes:66]
•A derivative for which the fair value is a net asset and the current portion is an asset is classified in total as non-current. If the current portion is liability, it should be presented as current liability.

[0001408710-22-000045:notes:67]
For presentation in consolidated statements of cash flows are classified in the same line item as the underlying item.

[0001408710-22-000045:notes:68]
The Company applies hedge accounting to arrangements that qualify and are designated for cash flow or fair value hedge accounting treatment. Hedge accounting is discontinued prospectively if the hedging relationship ceases to be effective or the hedging or hedged items cease to exist as a result of maturity, sale, termination or cancellation.

[0001408710-22-000045:notes:69]
Derivatives designated and qualifying as hedges of the exposure to variability in expected future cash flows, or other types of forecasted transactions, are considered cash flow hedges which include foreign currency forward contracts and interest rate swap. In a cash flow hedging relationship, the change in the fair value of the hedging derivative is initially recorded in AOCI in the consolidated balance sheets, gain or loss on the derivative instrument is reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings. The reclassified amounts are presented in the same income statement line item as the earnings effect of the hedged item.

[0001408710-22-000045:notes:70]
In accordance with the fair value measurement guidance, the Company’s accounting policy is to measure the credit risk of its derivative financial instruments that are subject to master netting agreements on a net basis by counterparty portfolio. The Company executes derivative instruments with financial institutions that are credit-worthy, which the Company defines as institutions that hold an investment grade credit rating.

[0001408710-22-000045:notes:71]
Concentration of credit risk

[0001408710-22-000045:notes:72]
Financial instruments that potentially subject the Company to concentrations of credit risk consist of cash and cash equivalents, short-term investments, derivatives, accounts receivable and contract assets.

[0001408710-22-000045:notes:73]
Cash, cash equivalents and short-term investments are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. The Company seeks to mitigate its credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties. The Company limits its short-term investments in marketable securities to securities with a maturity not in excess of three years and securities that are rated A1, P-1, F1, or better.

[0001408710-22-000045:notes:74]
The Company enters into derivative contracts with financial institutions with reputable credit and monitors the credit profiles of these counterparties.

[0001408710-22-000045:notes:75]
The Company performs ongoing credit evaluations for credit worthiness of its customers and usually does not require collateral from its customers. Management has implemented a program to closely monitor near term cash collection and credit exposures to mitigate any material losses.

[0001408710-22-000045:notes:76]
Revenue recognition

[0001408710-22-000045:notes:77]
The Company derives revenues primarily from the assembly of products under supply agreements with its customers and the fabrication of customized optics and glass. The Company recognizes revenue relating to contracts with customers that depicts the transfer of promised goods or services to customers in an amount reflecting the consideration to which the Company expects to be entitled in exchange for such goods or services. In order to meet this requirement, the Company applies the following five steps: (1) identify the contract with a customer, (2) identify the performance obligations under the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations under the contract, and (5) recognize revenue when a performance obligation is satisfied. Revenue is recognized net of any taxes collected from customers, which is subsequently remitted to governmental authorities.

[0001408710-22-000045:notes:78]
A performance obligation is a contractual promise to transfer a distinct good or service to the customer. In contracts with multiple performance obligations, the Company identifies each performance obligation and evaluates whether the performance obligation is distinct within the context of the contract at contract inception. The majority of the Company’s contracts have a single performance obligation, as the promise to transfer the individual goods or services is not separately identifiable from other promises under the contracts and, therefore, is not distinct.

[0001408710-22-000045:notes:79]
Sales of finished goods

[0001408710-22-000045:notes:80]
The Company manufactures products that are customized to customers’ specifications; however, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for over time recognition are not met. On evaluation of the contracts, the Company identified that there were no contractual rights to bill profit for work in progress in the event of a contract termination, which is expected to be infrequent. Further, in limited circumstances, contracts provide for substantive acceptance by the customer, which results in the deferral of revenue until formal notice of acceptance is received from the customer. Judgment may be required in determining if an acceptance clause provides for substantive acceptance.

[0001408710-22-000045:notes:81]
Certain customers may request the Company to store finished products at the Company’s warehouse where customers bear risks of loss themselves. In these instances, the Company receives a written request from the customer asking the Company to hold the inventory at the Company’s warehouse and refrain from using the ordered goods to fulfill other customer orders. In these situations, revenue is only recognized when the completed goods are ready for shipment and transferred to the Company’s warehouse.

[0001408710-22-000045:notes:82]
Customers generally are obligated to purchase finished goods that the Company has manufactured according to their demand requirements. Materials that are not consumed by customers within a specified period of time, or are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under the Company’s contracts. Once materials are designated as either excess or obsolete inventory, customers are typically required to purchase such inventory from the Company even if the customer has chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

[0001408710-22-000045:notes:83]
A contract’s transaction price is allocated to each distinct performance obligation and recognized as revenue when, or as, the performance obligation is satisfied. In determining the net consideration to which the Company expects to be entitled, the Company evaluates whether the price is subject to refund or adjustment. The Company generally does not grant return privileges, except for in the case of defective products during the warranty period. The Company generally provides a warranty of between one to five years on any given product. These standard warranties are assurance-type warranties, and the Company does not offer any services in addition to the assurance that the product will continue to work as specified.

[0001408710-22-000045:notes:84]
The Company recognized revenue net of rebates and other similar allowances. Revenues are recognized only if these estimates can be reasonably and reliably determined. The Company estimates expected rebates and other similar allowances based on historical results taking into consideration the type of customer, the type of transaction and the specifics of each arrangement. The Company considers such estimated rebates and other similar allowances as variable consideration when allocating the transaction price to the extent it is probable that there will not be a significant reversal of cumulative revenue recognized. The estimate is primarily based on the most likely level of consideration to be paid to the customer under the specific terms of each arrangement.

[0001408710-22-000045:notes:85]
Services

[0001408710-22-000045:notes:86]
The Company provides services for customers that are related to the Company’s manufacturing activities. In many cases, although the nature of work performed is that of a service, revenue is only recognized upon shipment of the product because the customer has specific requirements as to how many items can be shipped at any given point in time, i.e. at point-in-time. The related costs are expensed as incurred.

[0001408710-22-000045:notes:87]
Service revenues of $140.4 million, $108.5 million and $90.5 million were recognized in the consolidated statements of operations and comprehensive income for the years ended June 24, 2022, June 25, 2021 and June 26, 2020, respectively.

[0001408710-22-000045:notes:88]
Contract Costs

[0001408710-22-000045:notes:89]
The incremental costs of obtaining a contract with a customer are recognized as an asset (not expensed as incurred) if such costs are expected to be recovered. Incremental costs of obtaining a contract are costs that the Company would not have incurred if the contract had not been obtained (e.g., sales commissions or similar incentive payments linked directly to new or modified customer contracts). Costs that would have been incurred regardless of whether a customer contract was obtained (e.g., costs of pursuing the contract, legal advice, etc.) are expensed as incurred, unless such costs are explicitly chargeable to the customer. During the years ended June 24, 2022 and June 25, 2021, the Company did not have any incremental costs of obtaining a contract.

[0001408710-22-000045:notes:90]
Shipping and Handling

[0001408710-22-000045:notes:91]
Shipping costs billed to customers are recorded as revenue. Shipping and handling expense related to costs incurred to deliver product are recognized within cost of goods sold. The Company accounts for shipping and handling activities that occur after control has transferred as a fulfillment cost, as opposed to a separate performance obligation, and the costs of shipping and handling are recognized concurrently with the related revenue.

[0001408710-22-000045:notes:92]
Warranty provision

[0001408710-22-000045:notes:93]
Provisions for estimated expenses relating to product warranties are made at the time the products are sold using historical experience. Generally, this warranty is limited to workmanship and the Company’s liability is capped at the price of the product. The provisions will be adjusted when experience indicates an expected settlement will differ from initial estimates.

[0001408710-22-000045:notes:94]
Warranty cost allowances were recognized in the consolidated statements of operations and comprehensive income for the years ended June 24, 2022, June 25, 2021 and June 26, 2020 with de minimis amount.

[0001408710-22-000045:notes:95]
Share-based compensation

[0001408710-22-000045:notes:96]
Share-based compensation is recognized in the consolidated financial statements based on grant-date fair value. The value of the portion of the award that is ultimately expected to vest is recognized as expense ratably over the requisite service period. For restricted share units and performance share units, the fair values are based on the market value of our ordinary shares on the date of grant.

[0001408710-22-000045:notes:97]
Employee contribution plan

[0001408710-22-000045:notes:98]
The Company operates a defined contribution plan, known as a provident fund, in its subsidiaries in Thailand and the United Kingdom. The assets of these plans are in separate trustee-administered funds. The provident fund is funded by matching payments from employees and by the subsidiaries on a monthly basis. Current contributions to the provident fund are accrued and paid to the fund manager on a monthly basis. The Company sponsors the Fabrinet U.S. 401(k) Retirement Plan, a Defined Contribution Plan under ERISA, at its subsidiaries in the United States, which provides retirement benefits for its eligible employees through tax deferred salary deductions.

[0001408710-22-000045:notes:99]
Severance liabilities

[0001408710-22-000045:notes:100]
Under labor protection laws applicable in Thailand and the Company’s subsidiary in Thailand’s employment policy, all employees of such subsidiary with more than 120 days of service are entitled to severance pay on forced termination or retrenchment or in the event that the employee reaches the retirement age of 55. The entitlement to severance pay is determined according to an employee’s individual employment tenure with the Company and is subject to a maximum benefit of 400 days of salary unless otherwise agreed upon in an employee’s employment contract. For employees of other subsidiaries who have a specific termination date, the entitlement to severance pay is determined according to their employment tenure, until their designated termination date.

[0001408710-22-000045:notes:101]
The Company accounts for these severance liabilities based on an actuarial valuation using the Projected Unit Credit Method, which apply the long-term Thai government bond yield as a discount rate. There are no separate plan assets held in respect to these liabilities.

[0001408710-22-000045:notes:102]
The Company’s subsidiary in the U.K. operates a defined benefit pension plan that defines the pension benefit an employee will receive on retirement, usually dependent upon several factors including but not limited to age, length of service and remuneration. The defined benefit obligation is calculated using the projected unit credit method. Annually

[0001408710-22-000045:notes:103]
the Company engages independent actuaries to calculate the obligation. The present value is determined by discounting the estimated future payments using market yields on high quality corporate bonds that are denominated in sterling and that have terms approximating the estimated period of the future payments (discount rate). The plan assets are held separately from those of the Company in independently administered funds and are measured at fair value.

[0001408710-22-000045:notes:104]
Severance liabilities are recognized in the Company’s consolidated balance sheet under non-current liabilities. The related expenses, if incurred during the period, are recognized in the Company’s consolidated statements of operations and comprehensive income as selling, general and administrative expenses. Prior service cost is initially recognized to other comprehensive income (loss) at the date of plan amendment. Such prior service cost is amortized as expenses as a component of net periodic pension cost using the weighted average remaining years of service to full eligibility date for active employees.

[0001408710-22-000045:notes:105]
Annual leave

[0001408710-22-000045:notes:106]
Employee entitlements to annual leave are recognized when earned by the employee. On termination of employment, accrued employee entitlement to annual leave is paid in cash.

[0001408710-22-000045:notes:107]
Income taxes

[0001408710-22-000045:notes:108]
The Company uses the asset and liability method of accounting for income taxes, whereby deferred tax assets and liabilities are recognized for future tax consequences attributable to temporary differences between the financial statement carrying amounts of existing assets and liabilities and their respective tax bases. Deferred tax assets and liabilities are measured using tax rates expected to apply to taxable income in the years in which those temporary differences are expected to reverse. The effect of a change in tax rates on deferred tax assets and liabilities is recognized in income in the period that includes the enactment date. Deferred tax assets are reduced by a valuation allowance if, based on the weight of the available evidence, it is more likely than not that some portion or all of the deferred tax assets will not be realized.

[0001408710-22-000045:notes:109]
Fabrinet’s subsidiaries are subject to income tax audits by the respective tax authorities in all of the jurisdictions in which they operate. The determination of tax liabilities in each of these jurisdictions requires the interpretation and application of complex and sometimes uncertain tax laws and regulations. The Company recognizes liabilities based on its estimate of whether, and the extent to which, additional tax liabilities are more-likely-than-not. If the Company ultimately determines that the payment of such a liability is not probable, then it reverses the liability and recognizes a tax benefit during the period in which the determination is made that the liability is no longer probable. The recognition and measurement of current taxes payable or refundable and deferred tax assets and liabilities requires that the Company makes certain estimates and judgments. Changes to these estimates or a change in judgment may have a material impact on the Company’s tax provision in a future period.

[0001408710-22-000045:notes:110]
The authoritative guidance provides for recognition of deferred tax assets if the realization of such deferred tax assets is more likely than not to occur based on an evaluation of both positive and negative evidence and the relative weight of the evidence. A company shall reduce its deferred tax assets by a valuation allowance if, based on the weight of available evidence, it is “more likely than not” (i.e., a likelihood of greater than 50 percent) that some portion or all of the deferred tax assets will not be realized. The valuation allowance shall be sufficient to reduce the deferred tax asset to the amount that is more likely than not to be realized. The valuation allowance shall be monitored and considered from all available evidence, both positive and negative, to determine whether, based on the weight of that evidence, a valuation allowance for deferred tax assets is not needed.

[0001408710-22-000045:notes:111]
The accounting standard clarifies the accounting for uncertainty in income taxes recognized in an entity’s financial statements and prescribes a recognition threshold and measurement attributes for financial statement disclosure of tax positions taken or expected to be taken on a tax return.

[0001408710-22-000045:notes:112]
The Company recognizes a tax benefit in the financial statements for an uncertain tax position only if management’s assessment is that the position is “more likely than not” to be sustained upon examination by the tax jurisdiction based solely on the technical merits of the position. The term “tax position” refers to a position in a previously filed tax return or a position expected to be taken in a future tax return that is reflected in measuring current or deferred income tax assets and liabilities for interim or annual periods. The accounting interpretation also provides guidance on measurement methodology, derecognition thresholds, financial statement classification and disclosures, recognition of interest and penalties, and accounting for the cumulative-effect adjustment at the date of adoption.

[0001408710-22-000045:notes:113]
New Accounting Pronouncements—adopted by the Company

[0001408710-22-000045:notes:114]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2019-12, “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.” The amendments in this update

[0001408710-22-000045:notes:115]
simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify U.S. GAAP for other areas of Topic 740 by clarifying and amending existing guidance. The Company adopted this standard in the first quarter of fiscal year 2022 with no material impact on the Company's consolidated financial statements.

[0001408710-22-000045:notes:116]
New Accounting Pronouncements—not yet adopted by the Company

[0001408710-22-000045:notes:117]
In November 2021, FASB issued ASU 2021-10, “Government Assistance (Topic 832), Disclosures by Business Entities about Government Assistance,” which requires annual disclosures that increase the transparency of transactions involving government assistance, including (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The amendments in this update are effective for all entities within the ASU's scope for financial statements issued for annual periods beginning after December 15, 2021. This ASU will be effective for the Company in the first quarter of fiscal year 2023. Early adoption is permitted. The Company assessed the preliminary impact from the adoption of this update and expected no material impact on the Company's consolidated financial statements.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001408710-22-000045:notes:118]
In December 2019, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2019-12, “Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes.” The amendments in this update simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740. The amendments also improve consistent application of and simplify U.S. GAAP for other areas of Topic 740 by clarifying and amending existing guidance. The Company adopted this standard in the first quarter of fiscal year 2022 with no material impact on the Company's consolidated financial statements.In November 2021, FASB issued ASU 2021-10, “Government Assistance (Topic 832), Disclosures by Business Entities about Government Assistance,” which requires annual disclosures that increase the transparency of transactions involving government assistance, including (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The amendments in this update are effective for all entities within the ASU's scope for financial statements issued for annual periods beginning after December 15, 2021. This ASU will be effective for the Company in the first quarter of fiscal year 2023. Early adoption is permitted. The Company assessed the preliminary impact from the adoption of this update and expected no material impact on the Company's consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001408710-22-000045:notes:119]
Revenues from contracts with customers
Contract Assets and Liabilities

[0001408710-22-000045:notes:120]
A contract asset is recognized when the Company has recognized revenues prior to an invoice for payment. Contract assets are classified separately on the consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. No impairment for contract assets was recorded for the years ended June 24, 2022 and June 25, 2021.

[0001408710-22-000045:notes:121]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the years ended June 24, 2022 and June 25, 2021:

[0001408710-22-000045:notes:122]
| (amount in thousands) |  |  |  | Contract Assets |
| Balance as of June 26, 2020 |  |  |  | $ | 13,256 |  |
| Revenue recognized |  |  |  | 65,182 |  |
| Amounts collected or invoiced |  |  |  | (66,560) |  |
| Balance as of June 25, 2021 |  |  |  | 11,878 |  |
| Revenue recognized |  |  |  | 61,086 |  |
| Amounts collected or invoiced |  |  |  | (59,500) |  |
| Balance as of June 24, 2022 |  |  |  | $ | 13,464 |  |

[0001408710-22-000045:notes:123]
| (amount in thousands) |  |  |  | Contract Liabilities |
| Balance as of June 26, 2020 |  |  |  | $ | 1,556 |  |
| Advance payment received during the year |  |  |  | 18,360 |  |
| Revenue recognized |  |  |  | (18,236) |  |
| Balance as of June 25, 2021 |  |  |  | 1,680 |  |
| Advance payment received during the year |  |  |  | 5,927 |  |
| Revenue recognized |  |  |  | (5,625) |  |
| Balance as of June 24, 2022 |  |  |  | $ | 1,982 |  |

[0001408710-22-000045:notes:124]
Revenue by Geographic Area and End Market

[0001408710-22-000045:notes:125]
Total revenues are attributed to a particular geographic area based on the bill-to-location of the Company’s customers. The Company operates primarily in three geographic regions: North America; Asia-Pacific and others; and Europe.

[0001408710-22-000045:notes:126]
The following table presents total revenues by geographic regions:

[0001408710-22-000045:notes:127]
| (amount in thousands, except percentages) | Year ended June 24,2022 |  | As a %of TotalRevenues |  | Year ended June 25,2021 |  | As a %of TotalRevenues |  | Year ended June 26,2020 |  | As a %of TotalRevenues |
| North America | $ | 1,114,504 |  |  | 49.3 | % |  | $ | 887,536 |  |  | 47.2 | % |  | $ | 830,888 |  |  | 50.6 | % |
| Asia-Pacific | 838,051 |  |  | 37.0 |  |  | 668,597 |  |  | 35.6 |  |  | 552,923 |  |  | 33.7 |  |
| Europe | 309,669 |  |  | 13.7 |  |  | 323,217 |  |  | 17.2 |  |  | 258,025 |  |  | 15.7 |  |
|  | $ | 2,262,224 |  |  | 100.0 | % |  | $ | 1,879,350 |  |  | 100.0 | % |  | $ | 1,641,836 |  |  | 100.0 | % |

[0001408710-22-000045:notes:128]
|  | Years Ended |
| (amount in thousands) | June 24,2022 |  | June 25,2021 |  | June 26,2020 |
| North America |  |  |  |  |  |
| U.S. | 1,099,244 |  |  | 884,862 |  |  | 829,567 |  |
| Others (1) | 15,260 |  |  | 2,674 |  |  | 1,321 |  |
| Total revenue in North America | 1,114,504 |  |  | 887,536 |  |  | 830,888 |  |
| Asia-Pacific and others |  |  |  |  |  |
| India | 278,117 |  |  | 152,249 |  |  | 91 |  |
| Malaysia | 212,286 |  |  | 157,213 |  |  | 190,574 |  |
| Israel | 101,058 |  |  | 107,584 |  |  | 315 |  |
| Hong Kong | 83,651 |  |  | 87,235 |  |  | 92,655 |  |
| Japan | 60,121 |  |  | 69,779 |  |  | 101,588 |  |
| China | 55,201 |  |  | 51,597 |  |  | 48,192 |  |
| Thailand | 36,489 |  |  | 27,081 |  |  | 98,330 |  |
| Others | 11,128 |  |  | 15,859 |  |  | 21,178 |  |
| Total revenue in Asia-Pacific and others | 838,051 |  |  | 668,597 |  |  | 552,923 |  |
| Europe |  |  |  |  |  |
| Ireland | 133,225 |  |  | 193,103 |  |  | 110,747 |  |
| U.K. | 90,921 |  |  | 60,516 |  |  | 67,589 |  |
| Germany | 40,794 |  |  | 28,163 |  |  | 45,628 |  |
| Others | 44,729 |  |  | 41,435 |  |  | 34,061 |  |
| Total revenue in Europe | $ | 309,669 |  |  | $ | 323,217 |  |  | $ | 258,025 |  |
| Total revenue | $ | 2,262,224 |  |  | $ | 1,879,350 |  |  | $ | 1,641,836 |  |

[0001408710-22-000045:notes:129]
(1)Others includes revenues from external customers based in our country of domicile, the Cayman Islands, which for each year presented is $0.

[0001408710-22-000045:notes:130]
The following table presents revenues by end market.

[0001408710-22-000045:notes:131]
| (amount in thousands, except percentages) | Year ended June 24,2022 |  | As a %of TotalRevenues |  | Year ended June 25,2021 |  | As a %of TotalRevenues |  | Year ended June 26,2020 |  | As a %of TotalRevenues |
| Optical communications | $ | 1,782,799 |  |  | 78.8 | % |  | $ | 1,441,338 |  |  | 76.7 | % |  | $ | 1,248,174 |  |  | 76.0 | % |
| Lasers, sensors and other | 479,425 |  |  | 21.2 |  |  | 438,012 |  |  | 23.3 |  |  | 393,662 |  |  | 24.0 |  |
| Total | $ | 2,262,224 |  |  | 100.0 | % |  | $ | 1,879,350 |  |  | 100.0 | % |  | $ | 1,641,836 |  |  | 100.0 | % |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001408710-22-000045:notes:132]
Income taxes
Fabrinet's effective tax rate is a function of the mix of tax rates in the various jurisdictions in which we conduct business. Fabrinet is domiciled in the Cayman Islands. Under the current laws of the Cayman Islands, Fabrinet is not subject to tax in the Cayman Islands on income or capital gains until March 6, 2039. Income of the Company exempted from corporate income tax in the Cayman Islands amounted to $171.0 million, $115.8 million and $101.9 million for the years ended June 24, 2022, June 25, 2021 and June 26, 2020, respectively.

[0001408710-22-000045:notes:133]
The majority of the Company’s operations and production take place in Thailand. The Company was not subject to tax in Thailand from July 2012 through June 2020 on income generated from the manufacture of products at its Pinehurst campus Building 6, and is not subject to tax in Thailand from July 2018 through June 2026 on income generated from the manufacture of products at its Chonburi campus. After June 2020, 50% of the Company's income generated from products manufactured at its Pinehurst campus Building 6 will be exempted from tax in Thailand through June 2025. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of

[0001408710-22-000045:notes:134]
Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted. Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001408710-22-000045:notes:135]
The corporate income tax rates for our subsidiaries in the PRC, the U.S., the U.K. and Israel are 25%, 21%, 19% and 23%, respectively. At Spring Budget 2021, the UK government announced an increase in the corporation tax main rate from 19% to 25% effective April 1, 2023. Our provision for income taxes is computed using the asset and liability method, under which deferred income taxes are recognized for differences between the financial statement and tax bases of assets and liabilities at currently enacted statutory tax rates for the years in which the differences are expected to reverse. The effect on deferred taxes of a change in tax rates is recognized in income in the period that includes the enactment.

[0001408710-22-000045:notes:136]
The Company’s income tax expense consisted of the following:

[0001408710-22-000045:notes:137]
|  | Years Ended |
| (amount in thousands) | June 24,2022 |  | June 25,2021 |  | June 26,2020 |
| Current | $ | 6,744 |  |  | $ | 6,355 |  |  | $ | 6,274 |  |
| Deferred | (158) |  |  | (4,212) |  |  | (511) |  |
| Total income tax expense | $ | 6,586 |  |  | $ | 2,143 |  |  | $ | 5,763 |  |

[0001408710-22-000045:notes:138]
The reconciliation between the Company’s taxes that would arise by applying the statutory tax rate of the country of the Company’s principal operations, Thailand, to the Company’s effective tax charge is shown below:

[0001408710-22-000045:notes:139]
|  | Years Ended |
| (amount in thousands) | June 24,2022 |  | June 25,2021 |  | June 26,2020 |
| Income before income taxes (1) | $ | 206,966 |  |  | $ | 150,484 |  |  | $ | 119,242 |  |
| Tax expense calculated at a statutory corporate income tax rate of 20% | 41,393 |  |  | 30,097 |  |  | 23,848 |  |
| Effect of income taxes from locations with tax rates different from Thailand | 681 |  |  | 198 |  |  | 577 |  |
| Income not subject to tax (2) | (35,982) |  |  | (24,853) |  |  | (22,232) |  |
| Income tax on unremitted earnings | 1,417 |  |  | 1,395 |  |  | 1,221 |  |
| Effect of foreign exchange rate adjustment | (1,165) |  |  | (2,855) |  |  | 382 |  |
| Tax rebate from research and development application | (873) |  |  | (728) |  |  | (1,228) |  |
| Provision for uncertain income tax position | 668 |  |  | (403) |  |  | (641) |  |
| Utilization of loss and tax credits carryforward | (194) |  |  | (610) |  |  | — |  |
| Changes in valuation allowance (3) | — |  |  | (2,146) |  |  | 1,806 |  |
| Others (4) | 641 |  |  | 2,048 |  |  | 2,030 |  |
| Corporate income tax expense | $ | 6,586 |  |  | $ | 2,143 |  |  | $ | 5,763 |  |

[0001408710-22-000045:notes:140]
(1)Income before income taxes was mostly generated from domestic income in the Cayman Islands.

[0001408710-22-000045:notes:141]
(2)Income not subject to tax relates to income earned in the Cayman and Mauritius Islands and income subject to an investment promotion privilege for Pinehurst Building 6 and the Company’s Chonburi campus. Income not subject to tax per ordinary share on a diluted basis was $0.96, $0.63, and $0.55 for the years ended June 24, 2022, June 25, 2021, and June 26, 2020, respectively.

[0001408710-22-000045:notes:142]
(3)Changes in valuation allowances were due to adjustments based on management's assessment on the realizability of the related deferred tax assets.

[0001408710-22-000045:notes:143]
(4)Others includes $1.2 million of deferred tax assets for a UK subsidiary from temporary differences from prior years, and $1.2 million of deferred tax assets due to the change in UK tax rate. These amounts were fully offset with a corresponding valuation allowance.

[0001408710-22-000045:notes:144]
The Company’s deferred tax assets and deferred tax liabilities, net of valuation allowance, at each balance sheet date are as follows:

[0001408710-22-000045:notes:145]
|  | As of |
| (amount in thousands) | June 24,2022 |  | June 25,2021 |
| Deferred tax assets: |  |  |  |
| Depreciation | $ | 1,579 |  |  | $ | 1,565 |  |
| Severance liability | 3,345 |  |  | 3,491 |  |
| Reserves and allowance | 1,711 |  |  | 1,751 |  |
| Net operating loss carryforwards | 7,025 |  |  | 3,646 |  |
| Others | 1,074 |  |  | 1,036 |  |
| Total | 14,734 |  |  | 11,489 |  |
| Less: Valuation allowance | (4,934) |  |  | (2,061) |  |
| Net deferred tax assets | $ | 9,800 |  |  | $ | 9,428 |  |
| Deferred tax liabilities: |  |  |  |
| Temporary differences from intangibles and changes in the fair value of assets acquired | $ | (1,816) |  |  | $ | (1,202) |  |
| Deferred tax from unremitted earnings | (5,550) |  |  | (5,072) |  |
| Others | 1,365 |  |  | 1,167 |  |
| Total | (6,001) |  |  | (5,107) |  |
| Net | $ | 3,799 |  |  | $ | 4,321 |  |

[0001408710-22-000045:notes:146]
The changes in the valuation allowances of deferred tax assets were as follows:

[0001408710-22-000045:notes:147]
| (amount in thousands) | Valuation allowances ofdeferred tax assets |
| Balance as of June 28, 2019 | $ | 1,291 |  |
| Additional | 2,437 |  |
| Balance as of June 26, 2020 | 3,728 |  |
| Additional | 479 |  |
| Reduction | (2,146) |  |
| Balance as of June 25, 2021 | 2,061 |  |
| Additional | 2,873 |  |
| Balance as of June 24, 2022 | $ | 4,934 |  |

[0001408710-22-000045:notes:148]
During fiscal year 2020, one of our subsidiaries in the U.S. generated net operating loss and management expected that such subsidiary would continue to have net operating losses in the foreseeable future; therefore, management believed it was more likely than not that all of the deferred tax assets of such subsidiary would not be utilized. Thus, a full valuation allowance of $2.1 million for the deferred tax assets was set up as of the end of fiscal year 2020.

[0001408710-22-000045:notes:149]
During fiscal year 2021, our subsidiaries in the U.S. generated taxable income sufficient for the utilization of loss carryforwards due to better operating performance and effective control of operating expenses and management determined that it was more likely than not that future taxable income would be sufficient to allow utilization of the deferred tax assets. Thus, a full valuation allowance of $2.1 million for the deferred tax assets was released as of June 25, 2021 and no valuation allowances for deferred tax assets of our subsidiaries in the U.S. have been set up as of June 24, 2022.

[0001408710-22-000045:notes:150]
During fiscal year 2020, our subsidiary in the U.K. also generated net operating loss and management expected that such subsidiary would continue to have net operating losses in the foreseeable future. Therefore, management believed it was more likely than not that all of the deferred tax assets of such subsidiary would not be utilized. Thus, a full valuation allowance of $1.6 million for the deferred tax assets was set up as of the end of fiscal year 2020. A full valuation allowance of $2.1 million and $4.9 million were set up for the fiscal year ended June 25, 2021 and June 24, 2022, respectively.

[0001408710-22-000045:notes:151]
Income tax liabilities have not been established for withholding tax and other taxes that would be payable on the unremitted earnings in Thailand, which are permanently reinvested. Unremitted earnings in Thailand totaled $135.5 million and $126.8 million as of June 24, 2022 and June 25, 2021, respectively. Unrecognized deferred tax liabilities for such unremitted earnings were $11.3 million and $12.2 million as of June 24, 2022 and June 25, 2021, respectively.

[0001408710-22-000045:notes:152]
Deferred tax liabilities of $1.5 million and $1.3 million have been established for withholding tax on the unremitted earnings in China for the years ended June 24, 2022 and June 25, 2021, respectively, which are included in non-current deferred tax liability in the consolidated balance sheets.

[0001408710-22-000045:notes:153]
Uncertain income tax positions

[0001408710-22-000045:notes:154]
Interest and penalties related to uncertain income tax positions are recognized in income tax expense. The Company had approximately $0.1 million of accrued interest and penalties related to uncertain income tax positions on the consolidated balance sheets as of June 24, 2022. The Company recorded interest and penalties of $0.4 million and  $0.1 million for the years ended June 25, 2021 and June 26, 2020, respectively, in the consolidated statements of operations and comprehensive income. The amount of interest and penalties reversed in fiscal 2022 provision for income taxes is not material. With regard to the Thailand jurisdiction, tax years 2015 through 2021 remain open to examination by the local authorities.

[0001408710-22-000045:notes:155]
The following table indicates the changes to the Company’s uncertain income tax positions for the years ended June 24, 2022, June 25, 2021 and June 26, 2020, excluding interest and penalties, were as follows:

[0001408710-22-000045:notes:156]
|  | Years Ended |
| (amount in thousands) | June 24,2022 |  | June 25,2021 |  | June 26,2020 |
| Beginning balance | $ | 807 |  |  | $ | 970 |  |  | $ | 1,323 |  |
| Additions during the year | 610 |  |  | 389 |  |  | 157 |  |
| Release of tax positions of prior years | (25) |  |  | (552) |  |  | (510) |  |
| Ending balance | $ | 1,392 |  |  | $ | 807 |  |  | $ | 970 |  |


## us-gaap:EarningsPerShareTextBlock

[0001408710-22-000045:notes:157]
Earnings per ordinary share
Basic earnings per ordinary share is computed by dividing reported net income by the weighted average number of ordinary shares outstanding during each period. Diluted earnings per ordinary share is computed by calculating the effect of potential dilutive ordinary shares outstanding during the year using the treasury stock method. Dilutive ordinary equivalent shares consist of share options, restricted share units and performance share units.

[0001408710-22-000045:notes:158]
Earnings per ordinary share was calculated as follows:

[0001408710-22-000045:notes:159]
|  | Years Ended |
| (amount in thousands except per share amounts) | June 24,2022 |  | June 25,2021 |  | June 26,2020 |
| Net income attributable to shareholders | $ | 200,380 |  |  | $ | 148,341 |  |  | $ | 113,479 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) | 36,876 |  |  | 36,872 |  |  | 36,908 |  |
| Incremental shares arising from the assumed exercise of share options and vesting of restricted share units and performance share units (thousands of shares) | 518 |  |  | 683 |  |  | 757 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) | 37,394 |  |  | 37,555 |  |  | 37,665 |  |
| Basic earnings per ordinary share | $ | 5.43 |  |  | $ | 4.02 |  |  | $ | 3.07 |  |
| Diluted earnings per ordinary share | $ | 5.36 |  |  | $ | 3.95 |  |  | $ | 3.01 |  |
| Outstanding performance share units excluded from the computation of diluted earnings per ordinary share (thousands of shares)(1) | — |  |  | 53 |  |  | 99 |  |

[0001408710-22-000045:notes:160]
(1)These performance share units were not included in the computation of diluted earnings per ordinary share because they are not expected to vest based on the Company’s current assessment of the related performance obligations.


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001408710-22-000045:notes:161]
Cash, cash equivalents and short-term investments
The Company’s cash, cash equivalents, and short-term investments by category is as follows:

[0001408710-22-000045:notes:162]
|  |  |  | Fair Value |
| (amount in thousands) | CarryingCost |  | UnrealizedGain/(Loss) |  | Cash andCashEquivalents |  | MarketableSecurities |  | OtherInvestments |
| As of June 24, 2022 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 187,630 |  |  | $ | — |  |  | $ | 187,630 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 10,367 |  |  | (1) |  |  | 10,366 |  |  | — |  |  | — |  |
| Liquidity funds | 31,477 |  |  | — |  |  | — |  |  | — |  |  | 31,477 |  |
| Corporate debt securities | 234,689 |  |  | (5,671) |  |  | — |  |  | 229,018 |  |  | — |  |
| U.S. agency and U.S. Treasury securities | 20,007 |  |  | (345) |  |  | — |  |  | 19,662 |  |  | — |  |
| Total | $ | 484,170 |  |  | $ | (6,017) |  |  | $ | 197,996 |  |  | $ | 248,680 |  |  | $ | 31,477 |  |
| As of June 25, 2021 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 222,664 |  |  | $ | — |  |  | $ | 222,664 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 80,305 |  |  | — |  |  | 80,305 |  |  | — |  |  | — |  |
| Liquidity funds | 30,000 |  |  | 1,226 |  |  | — |  |  | — |  |  | 31,226 |  |
| Certificate of deposits | 10,500 |  |  | — |  |  | — |  |  | — |  |  | 10,500 |  |
| Corporate debt securities | 171,626 |  |  | 164 |  |  | — |  |  | 171,790 |  |  | — |  |
| U.S. agency and U.S. Treasury securities | 31,301 |  |  | 146 |  |  | — |  |  | 31,447 |  |  | — |  |
| Total | $ | 546,396 |  |  | $ | 1,536 |  |  | $ | 302,969 |  |  | $ | 203,237 |  |  | $ | 41,726 |  |

[0001408710-22-000045:notes:163]
The cash equivalents include short-term bank deposits, investments in money market funds, and marketable securities with maturities of three months or less at the date of purchase. The effective interest rate on short term bank deposits was 0.5% and 0.7% per annum for the years ended June 24, 2022 and June 25, 2021, respectively.

[0001408710-22-000045:notes:164]
As of June 24, 2022, the Company had no investments in certificates of deposit classified as held-to-maturity debt securities. As of June 25, 2021, the Company had $10.5 million of investments in certificate of deposits classified as held-to-maturity debt securities. All investments mature within one year. Held-to-maturity debt securities are recorded at amortized cost, which approximates fair value. No unrecognized gains and losses were recorded during the years ended June 24, 2022 and June 25, 2021.

[0001408710-22-000045:notes:165]
As of June 24, 2022 and June 25, 2021, 59% and 65%, respectively, of our cash and cash equivalents were held by the Parent Company.

[0001408710-22-000045:notes:166]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of June 24, 2022 and June 25, 2021:

[0001408710-22-000045:notes:167]
|  | June 24, 2022 |  | June 25, 2021 |
| (amount in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 101,976 |  |  | $ | 101,400 |  |  | $ | 30,000 |  |  | $ | 31,226 |  |
| Due between one to five years | 184,197 |  |  | 178,757 |  |  | 202,927 |  |  | 203,237 |  |
| Total | $ | 286,173 |  |  | $ | 280,157 |  |  | $ | 232,927 |  |  | $ | 234,463 |  |

[0001408710-22-000045:notes:168]
The following table summarizes the carrying cost of short-term investments classified as held-to-maturity securities based on stated effective maturities as of June 24, 2022 and June 25, 2021:

[0001408710-22-000045:notes:169]
| (amount in thousands) | As of June 24, 2022 |  | As of June 25, 2021 |
| Due within one year (1) | $ | — |  |  | $ | 10,500 |  |
| Due between one to five years | — |  |  | — |  |
| Total | $ | — |  |  | $ | 10,500 |  |

[0001408710-22-000045:notes:170]
(1)Short-term investments classified as held-to-maturity securities as of June 25, 2021 matured in July 2021.

[0001408710-22-000045:notes:171]
During the year ended June 24, 2022, the Company recognized a realized gain of a de minimis amount from sales of available-for-sale debt securities in interest income in the consolidated statements of operations and comprehensive income. During the year ended June 25, 2021, the Company recognized a realized gain of $0.4 million from sales of available-for-sale debt securities in interest income in the consolidated statements of operations and comprehensive income.

[0001408710-22-000045:notes:172]
As of June 24, 2022, the Company considered the decline in market value of its available-for-sale debt securities by using the AFS debt security impairment model. The Company typically invests in highly-rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy requires investments generally to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. The Company assessed impairment at the individual security level according to the relevant accounting standard by comparing its fair value/market value with its amortized cost. The Company considered factors such as the failure of the issuer of the security to make scheduled interest and principal payments and any changes to the credit rating of the security by a rating agency. The credit rating of the Company's invested securities are still in compliance with the Company's investment policy. No impairment losses on available-for-sale debt securities were recorded for the year ended June 24, 2022.

[0001408710-22-000045:notes:173]
As of June 24, 2022, the Company evaluated the expected credit loss for held-to-maturity debt securities at the individual security level within the scope of CECL model by considering historical information and current and future economic conditions and events. Additionally, the Company considered qualitative factors such as term and structure of the instrument and credit ratings by rating agencies in determining if a zero-credit loss expectation is supportable. The credit rating of the Company's invested securities are still in compliance with the Company's investment policy. No impairment losses on held-to-maturity debt securities were recorded for the year ended June 24, 2022.

[0001408710-22-000045:notes:174]
As of June 25, 2021, the Company considered the decline in market value of its available-for-sale and held-to-maturity debt securities to be temporary in nature and did not consider any of its securities other-than-temporarily impaired. When evaluating an investment for other-than-temporary impairment, the Company reviews factors such as the length of time and extent to which fair value has been below its cost basis, the financial condition of the issuer and any changes thereto, changes in market interest rates, and the Company’s intent to sell, or whether it is more likely than not it will be required to sell, the investment before recovery of the investment’s cost basis. No impairment losses were recorded for the year ended June 25, 2021.


## us-gaap:FairValueDisclosuresTextBlock

[0001408710-22-000045:notes:175]
Fair value of financial instruments
Fair value is defined as the exchange price that would be received for an asset or paid to transfer a liability (an exit price) in the principal or most advantageous market for the asset or liability in an orderly transaction between market participants on the measurement date. A fair value hierarchy is established, which requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs for the valuation of an asset or liability as of the measurement date. The three levels of inputs that may be used to measure fair value are defined as follows:

[0001408710-22-000045:notes:176]
Level 2 inputs are inputs other than quoted prices included within Level 1 that are observable for assets or liabilities, either directly or indirectly. If the assets or liabilities have a specified (contractual) term, Level 2 inputs must be observable for substantially the full term of assets or liabilities.

[0001408710-22-000045:notes:177]
Level 3 inputs are unobservable inputs for assets or liabilities, which require the reporting entity to develop its own valuation techniques and assumptions.

[0001408710-22-000045:notes:178]
The following table provides details of the financial instruments measured at fair value on a recurring basis, including:

[0001408710-22-000045:notes:179]
|  | Fair Value Measurements at Reporting DateUsing |
| (amount in thousands) | Level 1 |  | Level 2 |  |  | Level 3 |  | Total |
| As of June 24, 2022 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 10,366 |  |  |  | $ | — |  |  | $ | 10,366 |  |
| Liquidity funds | — |  |  | 31,477 |  |  |  | — |  |  | 31,477 |  |
| Corporate debt securities | — |  |  | 229,018 |  |  |  | — |  |  | 229,018 |  |
| U.S. agency and U.S. Treasury securities | — |  |  | 19,662 |  |  |  | — |  |  | 19,662 |  |
| Derivative assets - current portion | — |  |  | 110 |  | (1) |  | — |  |  | 110 |  |
| Total | $ | — |  |  | $ | 290,633 |  |  |  | $ | — |  |  | $ | 290,633 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities - current portion | $ | — |  |  | $ | (7,345) |  |  |  | $ | — |  |  | $ | (7,345) |  |
| Derivative liabilities - non-current portion | — |  |  | (234) |  |  |  | — |  |  | (234) |  |
| Total | $ | — |  |  | $ | (7,579) |  | (2) |  | $ | — |  |  | $ | (7,579) |  |

[0001408710-22-000045:notes:180]
|  | Fair Value Measurements at Reporting DateUsing |
| (amount in thousands) | Level 1 |  | Level 2 |  |  | Level 3 |  | Total |
| As of June 25, 2021 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 80,305 |  |  |  | $ | — |  |  | $ | 80,305 |  |
| Liquidity funds | — |  |  | 31,226 |  |  |  | — |  |  | 31,226 |  |
| Corporate debt securities | — |  |  | 171,790 |  |  |  | — |  |  | 171,790 |  |
| U.S. agency and U.S. Treasury securities | — |  |  | 31,447 |  |  |  | — |  |  | 31,447 |  |
| Derivative assets - current portion | — |  |  | 1 |  | (3) |  | — |  |  | 1 |  |
| Total | $ | — |  |  | $ | 314,769 |  |  |  | $ | — |  |  | $ | 314,769 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities - current portion | $ | — |  |  | $ | (5,654) |  |  |  | $ | — |  |  | $ | (5,654) |  |
| Derivative liabilities - non-current portion | — |  |  | (1,977) |  |  |  | — |  |  | (1,977) |  |
| Total | $ | — |  |  | $ | (7,631) |  | (4) |  | $ | — |  |  | $ | (7,631) |  |

[0001408710-22-000045:notes:181]
(1)Interest rate swap agreement with notional amount of $64.2 million.

[0001408710-22-000045:notes:182]
(2)Foreign currency forward contracts with an aggregate notional amount of $135.0 million and 0.5 million Canadian dollars and interest rate swap agreement with a notional amount of $60.9 million.

[0001408710-22-000045:notes:183]
(3)Foreign currency forward contract with an aggregate notional amount of $2.0 million.

[0001408710-22-000045:notes:184]
(4)Foreign currency forward contracts with an aggregate notional amount of $128.0 million and 0.4 million Canadian dollars and two interest rate swap agreements with an aggregate notional amount of $125.1 million.

[0001408710-22-000045:notes:185]
Derivative Financial Instruments

[0001408710-22-000045:notes:186]
The Company utilizes derivative financial instruments to hedge (i) foreign exchange risk associated with certain foreign currency denominated assets and liabilities and other foreign currency transactions, and (ii) interest rate risk associated with its long-term debt.

[0001408710-22-000045:notes:187]
The Company minimizes the credit risk associated with its derivative instruments by limiting the exposure to any single counterparty and by entering into derivative instruments only with counterparties that meet the Company’s minimum credit quality standard.

[0001408710-22-000045:notes:188]
Foreign Currency Forward and Option Contracts

[0001408710-22-000045:notes:189]
As a result of foreign currency rate fluctuations, the U.S. dollar equivalent values of the Company’s foreign currency denominated assets and liabilities fluctuate. The Company uses foreign currency forward and option contracts to manage the foreign exchange risk associated with a portion of its foreign currency denominated assets and liabilities and other foreign currency transactions. The Company enters into foreign currency forward and option contracts to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht and Canadian dollars with counterparties that meet the Company’s minimum credit quality standard.

[0001408710-22-000045:notes:190]
The Company may enter into foreign currency forward contracts with maturities of up to 12 months to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht, including inventory purchases, payroll and other operating expenses. The Company considers these forward contracts as dual-purpose hedges, that hedge both the foreign exchange fluctuation (i) from inception through the forecasted expenditure, and (ii) any subsequent revaluation of the account payable or accrual. The Company may designate the forward contracts that hedge the foreign exchange fluctuation from inception through the forecasted expenditure as cash flow hedges. The gain or loss on a derivative instrument designated and qualified as a cash flow hedging instrument is recorded as a component of other comprehensive income and reclassified into earnings in the same period or periods during which the hedged forecasted transaction affects earnings. The reclassified amounts are presented in the same income statement line item as the earnings effect of the hedged item. Once the forecasted transactions are recorded, the Company will discontinue the hedging relationship by de-designating the derivative instrument and recording subsequent changes in fair value through contract maturity to foreign exchange gain (loss), net in the consolidated statements of operations and comprehensive income as a natural hedge against the Thai baht denominated assets and liabilities.

[0001408710-22-000045:notes:191]
The Company may also enter into non-designated foreign currency forward and option contracts to provide an offset to the re-measurement of foreign currency denominated assets and liabilities and to hedge certain forecasted exposures. Changes in the fair value of these non-designated derivatives are recorded through foreign exchange gain (loss), net in the consolidated statements of operations and comprehensive income.

[0001408710-22-000045:notes:192]
As of June 24, 2022, the Company had 135 outstanding U.S. dollar foreign currency forward contracts against Thai baht with an aggregate notional amount of $135.0 million and with maturity dates ranging from July 2022 through January 2023, and one foreign currency contract with a notional amount of 0.5 million Canadian dollars and with a maturity date in September 2022.

[0001408710-22-000045:notes:193]
As of June 25, 2021, the Company had 130 outstanding U.S. dollar foreign currency forward contracts against Thai baht with an aggregate notional amount of $130.0 million and with maturity dates ranging from July 2021 through January 2022, and two foreign currency contracts with an aggregate notional amount of 0.4 million Canadian dollars and with maturity dates in September 2021.

[0001408710-22-000045:notes:194]
As of June 24, 2022, the hedging relationship over foreign currency forward contracts which were designated for hedge accounting had been tested to be highly effective based on the performance of retrospective and prospective regression testing. As of June 24, 2022, the amount in AOCI that is expected to be reclassified into earnings within 12 months as loss was $4.8 million.

[0001408710-22-000045:notes:195]
During the year ended June 24, 2022 and June 25, 2021, the Company included an unrealized loss of $0.8 million and $1.5 million, respectively, from changes in fair value of foreign currency forward and option contracts which were not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the consolidated statements of operations and comprehensive income.

[0001408710-22-000045:notes:196]
Interest Rate Swap Agreements

[0001408710-22-000045:notes:197]
The Company entered into interest rate swap agreements to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. As of June 24, 2022 and June 25, 2021, the Company had two outstanding interest rate swap agreements with an aggregate notional amount of $125.1 million.

[0001408710-22-000045:notes:198]
On July 25, 2018, Fabrinet Thailand entered into an interest rate swap agreement to effectively convert the floating interest rate of its term loan under the credit facility agreement with Bank of America Credit Facility Agreement to a fixed interest rate of 2.86% per annum through the scheduled maturity of the term loan in June 2023 (see Note 13). The Company did not designate this interest rate swap for hedge accounting.

[0001408710-22-000045:notes:199]
On September 3, 2019, the Company entered into a new term loan agreement under a Credit Facility Agreement with the Bank of Ayudhya Public Company Limited (the “Bank”) (see Note 13) and on September 10, 2019, the Company repaid in full the outstanding term loan under the Bank of America Credit Facility (see Note 13). In conjunction with the funding of the new term loan, the Company entered into a second interest rate swap agreement. The combination of both

[0001408710-22-000045:notes:200]
of these interest rate swaps effectively converts the floating interest rate of the Company’s new term loan with the Bank to a fixed interest rate of 4.36% per annum through the maturity of the term loan in June 2024.

[0001408710-22-000045:notes:201]
On September 27, 2019, the Company designated these two interest rate swaps as a cash flow hedge for the Company’s term loan under the Credit Facility Agreement with the Bank. The combination of these two interest rate swaps qualified for hedge accounting because the hedges are highly effective, and the Company has designated and documented contemporaneously the hedging relationships involving these interest rate swaps. While the Company intends to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in earnings. From September 27, 2019, any gains or losses related to these interest rate swaps will be recorded in AOCI in the consolidated balance sheets. The Company will reclassify a portion of the gains or losses from AOCI into earnings at each reporting period based on either the accrued interest amount or the interest payment.

[0001408710-22-000045:notes:202]
As of June 24, 2022, the amount in AOCI that is expected to be reclassified into earnings within 12 months as loss is $0.5 million.

[0001408710-22-000045:notes:203]
The following table provides a summary of the impact of derivative gain (loss) of the Company’s foreign currency forward contracts and interest rate swaps which were designated as cash flow hedges on the consolidated statements of operations and other comprehensive income:

[0001408710-22-000045:notes:204]
|  |  |  | Year Ended |
| (amount in thousands) | Financial statementsline item |  | June 24,2022 |  | June 25,2021 |
| Derivatives gain (loss) recognized in other comprehensive income (loss): |  |  |  |  |  |
| Foreign currency forward contracts | Other comprehensive income |  | $ | (2,304) |  |  | $ | (6,194) |  |
| Interest rate swaps | Other comprehensive income |  | 2,461 |  |  | 1,624 |  |
| Total derivatives loss (gain) recognized in other comprehensive income |  |  | $ | 157 |  |  | $ | (4,570) |  |
| Derivatives loss (gain) reclassified from accumulated other comprehensive income into earnings: |  |  |  |  |  |
| Foreign currency forward contracts | Cost of revenues |  | $ | 7,283 |  |  | $ | (966) |  |
| Foreign currency forward contracts | Selling, general and administrative expenses |  | 303 |  |  | (40) |  |
| Foreign currency forward contracts | Foreign exchange gain (loss), net |  | (7,384) |  |  | 1,769 |  |
| Interest rate swaps | Interest expense |  | (937) |  |  | (1,299) |  |
| Total derivatives (gain) loss reclassified from accumulated other comprehensive income into earnings |  |  | $ | (735) |  |  | $ | (536) |  |
| Change in net unrealized gain (loss) on derivative instruments |  |  | $ | (578) |  |  | $ | (5,106) |  |

[0001408710-22-000045:notes:205]
Fair value of derivatives

[0001408710-22-000045:notes:206]
The following table provides the fair values of the Company’s derivative financial instruments for the periods presented:

[0001408710-22-000045:notes:207]
|  | June 24,2022 |  | June 25,2021 |
| (amount in thousands) | DerivativeAssets |  | DerivativeLiabilities |  | DerivativeAssets |  | DerivativeLiabilities |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts | $ | — |  |  | $ | (1,561) |  |  | $ | — |  |  | $ | (1,379) |  |
| Interest rate swaps | — |  |  | — |  |  | — |  |  | — |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward contracts | — |  |  | (4,821) |  |  | 1 |  |  | (2,703) |  |
| Interest rate swaps | 110 |  |  | (1,197) |  |  | — |  |  | (3,549) |  |
| Derivatives, gross balances | 110 |  |  | (7,579) |  |  | 1 |  |  | (7,631) |  |

[0001408710-22-000045:notes:208]
The Company presents its derivatives at gross fair values in the consolidated balance sheets.

[0001408710-22-000045:notes:209]
The Company recorded the fair value of derivative financial instruments in the consolidated balance sheets as follows:

[0001408710-22-000045:notes:210]
| Derivative Financial Instruments | Balance Sheet Line Item |
| Fair Value of Derivative Assets | Other current assets |
| Fair Value of Derivative Liabilities | Accrued expenses |
| Fair Value of Derivative Liabilities | Other non-current liabilities |


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001408710-22-000045:notes:211]
Trade accounts receivable, net

[0001408710-22-000045:notes:212]
| (amount in thousands) | As of June 24,2022 |  | As of June 25,2021 |
| Trade accounts receivable | $ | 440,601 |  |  | $ | 336,647 |  |
| Less: Allowance for doubtful account | (1,271) |  |  | (100) |  |
| Trade accounts receivable, net | $ | 439,330 |  |  | $ | 336,547 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001408710-22-000045:notes:213]
Inventories

[0001408710-22-000045:notes:214]
| (amount in thousands) | As of June 24,2022 |  | As of June 25,2021 |
| Raw materials | $ | 275,730 |  |  | $ | 196,345 |  |
| Work in progress | 217,638 |  |  | 174,654 |  |
| Finished goods | 15,203 |  |  | 15,471 |  |
| Goods in transit | 48,574 |  |  | 35,663 |  |
| Inventories | $ | 557,145 |  |  | $ | 422,133 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001408710-22-000045:notes:215]
Leases
The Company leases facilities under non-cancelable operating lease agreements. The Company leases a portion of its capital equipment and vehicles, certain land and buildings for its facilities in Thailand, the Cayman Islands, the PRC, the U.S., the U.K., Israel and Singapore under operating lease arrangements that expire at various dates through 2025. Certain of these lease arrangements provide the Company the ability to extend the lease from one to five years following the expiration of the current term. However, the Company may exclude lease extension options from its right of use ("ROU") assets and lease liabilities as the Company is not reasonably assured that it will exercise these options. None of the lease agreements contain residual value guarantees provided by the lessee. The Company also has one intercompany lease transaction in the form of a lease of office and manufacturing space.

[0001408710-22-000045:notes:216]
As of June 24, 2022, the maturities of the Company’s operating lease liabilities were as follows:

[0001408710-22-000045:notes:217]
| (amount in thousands) |  |  |
| 2023 | $ | 2,405 |  |  |
| 2024 | 1,460 |  |  |
| 2025 | 39 |  |  |
| Total undiscounted lease payments | 3,904 |  |  |
| Less imputed interest | (109) |  |  |
| Total present value of lease liabilities | $ | 3,795 |  | (1) |

[0001408710-22-000045:notes:218]
(1)Includes current portion of operating lease liabilities of $2.3 million.

[0001408710-22-000045:notes:219]
Rental expense related to the Company’s operating leases is recognized on a straight-line basis over the lease term. Rental expense for long-term leases for the years ended June 24, 2022, June 25, 2021 and June 26, 2020 was $2.2

[0001408710-22-000045:notes:220]
million, $2.6 million and $2.1 million, respectively. Rental expense for short-term leases for the years ended June 24, 2022, June 25, 2021 and June 26, 2020 was $0.2 million, $0.3 million and a de minimis amount, respectively.

[0001408710-22-000045:notes:221]
As of June 24, 2022, the Company had one finance lease agreement with a de minimis amount.

[0001408710-22-000045:notes:222]
The following summarizes additional information related to the Company’s operating leases:

[0001408710-22-000045:notes:223]
|  | As of June 24, 2022 |
| Weighted-average remaining lease term (in years) |  |
| Operating leases | 1.8 |
| Weighted-average discount rate |  |
| Operating leases | 3.4 | % |

[0001408710-22-000045:notes:224]
The following information represents supplemental disclosure for the statement of cash flows related to operating leases:

[0001408710-22-000045:notes:225]
| (amount in thousands) | Year Ended June 24, 2022 |
| Cash paid for amounts included in the measurement of lease liabilities |  |
| Operating cash flows from operating leases | $ | 2,533 |  |
| Financing cash flows from finance leases | $ | 7 |  |
| ROU assets obtained in exchange for lease liabilities | $ | 38 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001408710-22-000045:notes:226]
Property, plant and equipment, net
The components of property, plant and equipment, net were as follows:

[0001408710-22-000045:notes:227]
| (amount in thousands) | Land andLandImprovements |  | BuildingandBuildingImprovements |  | ManufacturingEquipment |  | OfficeEquipment |  | MotorVehicles |  | Computers |  | ConstructionandMachineryUnderInstallation |  | Total |
| As of June 24, 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost | $ | 58,489 |  |  | $ | 201,403 |  |  | $ | 255,972 |  |  | $ | 6,330 |  |  | $ | 1,053 |  |  | $ | 21,329 |  |  | $ | 7,962 |  |  | $ | 552,538 |  |
| Less: Accumulated depreciation | (35) |  |  | (65,943) |  |  | (171,870) |  |  | (5,273) |  |  | (830) |  |  | (15,737) |  |  | — |  |  | (259,688) |  |
| Less: Impairment reserve | — |  |  | — |  |  | (573) |  |  | — |  |  | — |  |  | — |  |  | — |  |  | (573) |  |
| Net book value | $ | 58,454 |  |  | $ | 135,460 |  |  | $ | 83,529 |  |  | $ | 1,057 |  |  | $ | 223 |  |  | $ | 5,592 |  |  | $ | 7,962 |  |  | $ | 292,277 |  |
| As of June 25, 2021 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost | $ | 45,125 |  |  | $ | 163,375 |  |  | $ | 213,981 |  |  | $ | 9,243 |  |  | $ | 627 |  |  | $ | 29,621 |  |  | $ | 9,377 |  |  | $ | 471,349 |  |
| Less: Accumulated depreciation | (26) |  |  | (58,791) |  |  | (141,997) |  |  | (6,376) |  |  | (509) |  |  | (21,715) |  |  | — |  |  | (229,414) |  |
| Less: Impairment reserve | — |  |  | — |  |  | (804) |  |  | — |  |  | — |  |  | (2) |  |  | — |  |  | (806) |  |
| Net book value | $ | 45,099 |  |  | $ | 104,584 |  |  | $ | 71,180 |  |  | $ | 2,867 |  |  | $ | 118 |  |  | $ | 7,904 |  |  | $ | 9,377 |  |  | $ | 241,129 |  |

[0001408710-22-000045:notes:228]
Leased assets included in manufacturing equipment comprise certain machine and equipment from finance lease agreements of Fabrinet UK.

[0001408710-22-000045:notes:229]
| (amount in thousands) | As of June 24, 2022 |  | As of June 25, 2021 |
| Cost—Finance leases | $ | 1,839 |  |  | $ | 1,747 |  |
| Less: Accumulated depreciation | (1,755) |  |  | (1,747) |  |
| Net book value | $ | 84 |  |  | $ | — |  |

[0001408710-22-000045:notes:230]
Depreciation expense amounted to $37.2 million, $34.7 million and $29.7 million for the years ended June 24, 2022, June 25, 2021 and June 26, 2020, respectively, and has been allocated between cost of revenues and selling, general and administrative expenses in the consolidated statements of operations and comprehensive income.

[0001408710-22-000045:notes:231]
The cost of fully depreciated property, plant and equipment written-off during the years ended June 24, 2022, June 25, 2021 and June 26, 2020 amounted to $25.1 million, $16.3 million and $2.9 million, respectively.

[0001408710-22-000045:notes:232]
During the fiscal year 2022, the Company wrote off impairment reserves of $0.2 million due to the disposal of property, plant and equipment. During the fiscal years 2021 and 2020, the Company recognized impairment reserves for property, plant and equipment of $0.8 million.

[0001408710-22-000045:notes:233]
The Company had borrowing cost capitalized of $0.9 million for the years ended June 24, 2022, and the Company had no borrowing costs capitalized for the years ended June 25, 2021 and June 26, 2020.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001408710-22-000045:notes:234]
Intangibles
The following tables present details of the Company’s intangibles:

[0001408710-22-000045:notes:235]
| (amount in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  | ForeignCurrencyTranslationAdjustment |  | Net |
| As of June 24, 2022 |  |  |  |  |  |  |  |
| Software | $ | 10,484 |  |  | $ | (7,681) |  |  | $ | — |  |  | $ | 2,803 |  |
| Customer relationships | 4,373 |  |  | (3,610) |  |  | (58) |  |  | 705 |  |
| Backlog | 119 |  |  | (119) |  |  | — |  |  | — |  |
| Total intangibles | $ | 14,976 |  |  | $ | (11,410) |  |  | $ | (58) |  |  | $ | 3,508 |  |

[0001408710-22-000045:notes:236]
| (amount in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  | ForeignCurrencyTranslationAdjustment |  | Net |
| As of June 25, 2021 |  |  |  |  |  |  |  |
| Software | $ | 9,767 |  |  | $ | (6,632) |  |  | $ | — |  |  | $ | 3,135 |  |
| Customer relationships | 4,373 |  |  | (3,195) |  |  | 58 |  |  | 1,236 |  |
| Backlog | 119 |  |  | (119) |  |  | — |  |  | — |  |
| Total intangibles | $ | 14,259 |  |  | $ | (9,946) |  |  | $ | 58 |  |  | $ | 4,371 |  |

[0001408710-22-000045:notes:237]
The Company recorded amortization expense relating to intangibles of $1.6 million, $1.5 million and $1.3 million for the years ended June 24, 2022, June 25, 2021 and June 26, 2020, respectively.

[0001408710-22-000045:notes:238]
The weighted-average remaining life of customer relationships was:

[0001408710-22-000045:notes:239]
| (years) | As of June 24, 2022 |  | As of June 25, 2021 |
| Customer relationships | 3.1 |  | 3.9 |

[0001408710-22-000045:notes:240]
Based on the carrying amount of intangibles as of June 24, 2022, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001408710-22-000045:notes:241]
| (amount in thousand) |  |
| 2023 | $ | 1,691 |  |
| 2024 | 898 |  |
| 2025 | 628 |  |
| 2026 | 283 |  |
| 2027 | 8 |  |
| Total | $ | 3,508 |  |


## us-gaap:DebtDisclosureTextBlock

[0001408710-22-000045:notes:242]
Borrowings
The Company’s total borrowings, including current and non-current portions of long-term borrowings, consisted of the following:

[0001408710-22-000045:notes:243]
(amount in thousands)

[0001408710-22-000045:notes:244]
| Rate |  | Conditions |  | Maturity |  | As of June 24, 2022 |  | As of June 25, 2021 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs—current portion |  |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  |  | $ | 12,156 |  |  | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum(1) |  | Repayable inquarterly installments |  | June 2024 |  | 27,421 |  |  | 39,609 |  |
| Less: Current portion |  |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs—non-current portion |  |  |  |  |  | (31) |  |  | (63) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  |  | $ | 15,202 |  |  | $ | 27,358 |  |

[0001408710-22-000045:notes:245]
(1)We have entered into interest rate swaps that effectively fix a series of our future interest payments on our term loans. Refer to Note 7.

[0001408710-22-000045:notes:246]
The movements of long-term borrowings were as follows for the years ended June 24, 2022 and June 25, 2021:

[0001408710-22-000045:notes:247]
|  | Years ended |
| (amount in thousands) | June 24,2022 |  | June 25,2021 |
| Opening balance | $ | 39,609 |  |  | $ | 51,797 |  |
| Borrowings during the period | — |  |  | — |  |
| Repayments during the period | (12,188) |  |  | (12,188) |  |
| Closing balance | $ | 27,421 |  |  | $ | 39,609 |  |

[0001408710-22-000045:notes:248]
As of June 24, 2022, the future maturities of long-term borrowings during each fiscal year were as follows:

[0001408710-22-000045:notes:249]
| (amount in thousand) |  |
| 2023 | $ | 12,187 |  |
| 2024 | 12,187 |  |
| 2025 | 3,047 |  |
| Total | $ | 27,421 |  |

[0001408710-22-000045:notes:250]
Credit facilities agreements:

[0001408710-22-000045:notes:251]
Bank of Ayudhya Public Company Limited

[0001408710-22-000045:notes:252]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

[0001408710-22-000045:notes:253]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a Term Loan Agreement pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the BofA Facility Agreement.

[0001408710-22-000045:notes:254]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be re-borrowed. During the year ended June 24, 2022, the Company recorded $2.3 million of interest expense in connection with this term loan, including impact from interest rate swaps. $0.9 million of these interest expenses were capitalized during the year ended June 24, 2022 in a new manufacturing building at the Company's Chonburi campus.

[0001408710-22-000045:notes:255]
Any borrowings under the Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

[0001408710-22-000045:notes:256]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt to equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of June 24, 2022, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

[0001408710-22-000045:notes:257]
The events of default in the Term Loan Agreement include failure to pay amounts due under the Term Loan Agreement or the related finance documents when due, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

[0001408710-22-000045:notes:258]
As of June 24, 2022, there was $27.4 million outstanding under the term loan.


## fn:AccruedSeveranceBenefitsDisclosureTextBlock

[0001408710-22-000045:notes:259]
Severance liabilities
The following table provides information regarding severance liabilities:

[0001408710-22-000045:notes:260]
|  | Years Ended |
| (amount in thousands) | June 24,2022 |  | June 25,2021 |
| Changes in severance liabilities |  |  |  |
| Balance, beginning of the fiscal year | $ | 19,782 |  |  | $ | 17,673 |  |
| Current service cost | $ | 2,318 |  |  | $ | 2,177 |  |
| Interest cost | 518 |  |  | 515 |  |
| Benefit paid | (322) |  |  | (1,198) |  |
| Unrealized loss (gain) on exchange rate | (2,133) |  |  | (550) |  |
| Actuarial (gain) loss on obligation | (1,542) |  |  | 1,129 |  |
| Foreign currency translation | (33) |  |  | 36 |  |
| Balance, end of the fiscal year | $ | 18,588 |  |  | $ | 19,782 |  |
| Changes in plan assets |  |  |  |
| Balance, beginning of the fiscal year | $ | 356 |  |  | $ | 294 |  |
| Actual return on plan assets | $ | (13) |  |  | $ | 19 |  |
| Employer contributions | 38 |  |  | 43 |  |
| Benefit paid | — |  |  | (34) |  |
| Foreign currency translation | (43) |  |  | 34 |  |
| Balance, end of the fiscal year | $ | 338 |  |  | $ | 356 |  |
| Underfunded status | $ | (18,250) |  |  | $ | (19,426) |  |

[0001408710-22-000045:notes:261]
The following table sets forth our severance liabilities as of June 24, 2022:

[0001408710-22-000045:notes:262]
| (amount in thousand) |  |
| 2023 | $ | 1,318 |  |
| 2024 | 1,239 |  |
| 2025 | 1,835 |  |
| 2026 | 1,266 |  |
| 2027 | 1,497 |  |
| Thereafter | 11,433 |  |
| Total | $ | 18,588 |  |

[0001408710-22-000045:notes:263]
The amount recognized in the consolidated balance sheets under non-current liabilities and non-current assets were determined as follows:

[0001408710-22-000045:notes:264]
| (amount in thousands) | As of June 24,2022 |  | As of June 25,2021 |
| Non-current assets | $ | 134 |  |  | $ | 59 |  |
| Non-current liabilities | $ | 18,384 |  |  | $ | 19,485 |  |

[0001408710-22-000045:notes:265]
The following table provides information regarding accumulated benefit obligations:

[0001408710-22-000045:notes:266]
| (amount in thousands) | As of June 24,2022 |  | As of June 25,2021 |
| Accumulated benefit obligations | $ | 13,018 |  |  | $ | 13,581 |  |

[0001408710-22-000045:notes:267]
The following table sets forth the plan assets at fair value as of June 24, 2022 and June 25, 2021.

[0001408710-22-000045:notes:268]
| (amount in thousands) |  |  | Fair value measurement as of June 24, 2022 |
|  | Total |  | SignificantObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Assets: |  |  |  |  |  |
| Other(1) | $ | 338 |  |  | $ | 208 |  |  | $ | 130 |  |
| Total Assets | $ | 338 |  |  | $ | 208 |  |  | $ | 130 |  |

[0001408710-22-000045:notes:269]
(1)The “Other” category represents the value of assets with Quilter and Royal London.

[0001408710-22-000045:notes:270]
| (amount in thousands) |  |  | Fair value measurement as of June 25, 2021 |
|  | Total |  | SignificantObservableInputs(Level 2) |  | SignificantUnobservableInputs(Level 3) |
| Assets: |  |  |  |  |  |
| Other(2) | $ | 356 |  |  | $ | 211 |  |  | $ | 145 |  |
| Total Assets | $ | 356 |  |  | $ | 211 |  |  | $ | 145 |  |

[0001408710-22-000045:notes:271]
(2)    The “Other” category represents the value of assets with Old Mutual Wealth and Royal London.

[0001408710-22-000045:notes:272]
The Trustees have chosen to invest in the following funds:

[0001408710-22-000045:notes:273]
|  | % of Total |
| Fund | As of June 24,2022 |  | As of June 25,2021 |
| Old Mutual Wealth Creation Balanced Portfolio | — | % |  | 59 | % |
| Quilter Creation Balanced Portfolio | 62 | % |  | — | % |
| Royal London Deposit Administration | 38 | % |  | 41 | % |

[0001408710-22-000045:notes:274]
The Quilter and Old Mutual Wealth assets are administered on unit-linked principles and allow access to a range of funds; these have been treated as Level 2.

[0001408710-22-000045:notes:275]
The Royal London assets are administered on a deposit administration basis. This is similar to a with profits fund but with a lower exposure to the stock market. The policy is invested in a mix of backing assets with a smoothed regular bonus rate being declared every year, which stabilizes the rate of return over the longer term. These have been treated as Level 3.

[0001408710-22-000045:notes:276]
The principal actuarial assumptions used were as follows:

[0001408710-22-000045:notes:277]
Weighted average actuarial assumptions used to determine severance liabilities

[0001408710-22-000045:notes:278]
|  | Years Ended |
|  | June 24, 2022 |  | June 25, 2021 |  | June 26, 2020 |
| Discount rate | 2.1% - 3.9% |  | 0.2% - 2.9% |  | 0.4% - 3.1% |
| Future salary increases | 3.5% - 10.0% |  | 3.5% - 10.0% |  | 3.5% - 10.0% |

[0001408710-22-000045:notes:279]
Weighted average actuarial assumptions used to determine benefit costs

[0001408710-22-000045:notes:280]
|  | Years Ended |
|  | June 24, 2022 |  | June 25, 2021 |  | June 26, 2020 |
| Discount rate | 0.2% - 2.9% |  | 0.4% - 3.1% |  | 2.3% - 3.2% |
| Expected long-term rate of return on assets | 2.1% |  | 2.3% |  | 2.1% |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001408710-22-000045:notes:281]
Share-based compensation
Share-based compensation

[0001408710-22-000045:notes:282]
The grant date fair value of restricted share units and performance share units is based on the closing price of our ordinary shares on the date of grant.

[0001408710-22-000045:notes:283]
The effect of recording share-based compensation expense for the years ended June 24, 2022, June 25, 2021 and June 26, 2020 was as follows:

[0001408710-22-000045:notes:284]
|  | Years Ended |
| (amount in thousands) | June 24,2022 |  | June 25,2021 |  | June 26,2020 |
| Share-based compensation expense by type of award: |  |  |  |  |  |
| Restricted share units | $ | 15,150 |  |  | $ | 16,725 |  |  | $ | 16,555 |  |
| Performance share units | 12,898 |  |  | 8,737 |  |  | 5,648 |  |
| Total share-based compensation expense | 28,048 |  |  | 25,462 |  |  | 22,203 |  |
| Tax effect on share-based compensation expense | — |  |  | — |  |  | — |  |
| Net effect on share-based compensation expense | $ | 28,048 |  |  | $ | 25,462 |  |  | $ | 22,203 |  |

[0001408710-22-000045:notes:285]
Share-based compensation expense was recorded in the consolidated statements of operations and comprehensive income as follows:

[0001408710-22-000045:notes:286]
|  | Years Ended |
| (amount in thousands) | June 24,2022 |  | June 25,2021 |  | June 26,2020 |
| Cost of revenue | $ | 5,967 |  |  | $ | 6,185 |  |  | $ | 6,098 |  |
| Selling, general and administrative expense | 22,081 |  |  | 19,277 |  |  | 16,105 |  |
| Total share-based compensation expense | $ | 28,048 |  |  | $ | 25,462 |  |  | $ | 22,203 |  |

[0001408710-22-000045:notes:287]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the years ended June 24, 2022, June 25, 2021 and June 26, 2020.

[0001408710-22-000045:notes:288]
Share-based award activity

[0001408710-22-000045:notes:289]
On December 12, 2019, the Company’s shareholders approved Fabrinet’s 2020 Equity Incentive Plan (the “2020 Plan”). Upon the approval of the 2020 Plan, Fabrinet’s Amended and Restated 2010 Performance Incentive Plan (the “2010 Plan”) was simultaneously terminated. The 2020 Plan provides for the grant of equity awards thereunder with respect to (i) 1,700,000 ordinary shares, plus (ii) up to 1,300,000 ordinary shares that, as of immediately prior to the termination of the 2010 Plan, had been reserved but not issued pursuant to any awards granted under the 2010 Plan and are not subject to any awards thereunder. Upon termination of the 2010 Plan, 1,281,619 ordinary shares were reserved for issuance under the 2020 Plan pursuant to clause (ii) of the preceding sentence.

[0001408710-22-000045:notes:290]
As of June 24, 2022, there were 310,242 restricted share units outstanding, 285,882 performance share units outstanding and 2,210,609 ordinary shares available for future grant under the 2020 Plan.

[0001408710-22-000045:notes:291]
As of June 24, 2022, there were 149,384 restricted share units outstanding under the 2010 Plan. No ordinary shares are available for future grant under the 2010 Plan.

[0001408710-22-000045:notes:292]
On November 2, 2017, the Company adopted the 2017 Inducement Equity Incentive Plan (the “2017 Inducement Plan”) with a reserve of 160,000 ordinary shares authorized for future issuance solely for the granting of inducement share options and equity awards to new employees. The 2017 Inducement Plan was adopted without shareholder approval in reliance on the “employment inducement exemption” provided under the New York Stock Exchange Listed Company Manual. As of June 24, 2022, there were no awards outstanding and 111,347 ordinary shares available for future grant under the 2017 Inducement Plan.

[0001408710-22-000045:notes:293]
The 2020 Plan, 2010 Plan and 2017 Inducement Plan are collectively referred to as the “Equity Incentive Plans.”

[0001408710-22-000045:notes:294]
Restricted share units and performance share units

[0001408710-22-000045:notes:295]
Restricted share units and performance share units have been granted under the Equity Incentive Plans.

[0001408710-22-000045:notes:296]
Restricted share units granted to employees generally vest in equal installments over three or four years on each anniversary of the vesting commencement date. Restricted share units granted to non-employee directors generally cliff vest 100% on the first of January, approximately one year from the grant date, provided the director continues to serve through such date.

[0001408710-22-000045:notes:297]
Performance share units granted to executives will vest, if at all, at the end of a two-year performance period based on the Company’s achievement of pre-defined performance criteria, which consist of revenue and non-U.S. GAAP gross margin or operating margin targets. The actual number of performance share units that may vest at the end of the performance period ranges from 0% to 100% of the award grant.

[0001408710-22-000045:notes:298]
The following table summarizes restricted share unit activity under the Equity Incentive Plans:

[0001408710-22-000045:notes:299]
|  | Number ofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 28, 2019 | 800,751 |  |  | $ | 42.48 |  |
| Granted | 367,088 |  |  | $ | 50.87 |  |
| Issued | (335,355) |  |  | $ | 40.98 |  |
| Forfeited | (34,727) |  |  | $ | 44.59 |  |
| Balance as of June 26, 2020 | 797,757 |  |  | $ | 46.88 |  |
| Granted | 230,759 |  |  | $ | 70.53 |  |
| Issued | (358,508) |  |  | $ | 45.39 |  |
| Forfeited | (28,133) |  |  | $ | 57.86 |  |
| Balance as of June 25, 2021 | 641,875 |  |  | $ | 55.74 |  |
| Granted | 186,633 |  |  | $ | 101.25 |  |
| Issued | (323,326) |  |  | $ | 52.20 |  |
| Forfeited | (45,556) |  |  | $ | 71.53 |  |
| Balance as of June 24, 2022 | 459,626 |  |  | $ | 75.14 |  |
| Expected to vest as of June 24, 2022 | 402,103 |  |  | $ | 75.75 |  |

[0001408710-22-000045:notes:300]
The following table summarizes performance share unit activity under the Equity Incentive Plans:

[0001408710-22-000045:notes:301]
|  | Number ofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 28, 2019 | 548,500 |  |  | $ | 40.97 |  |
| Granted | 242,310 |  |  | $ | 48.65 |  |
| Issued | — |  |  | — |  |
| Forfeited | (350,670) |  |  | $ | 36.99 |  |
| Balance as of June 26, 2020 | 440,140 |  |  | $ | 48.37 |  |
| Granted | 184,718 |  |  | $ | 69.85 |  |
| Issued | (82,185) |  |  | $ | 48.02 |  |
| Forfeited | (115,645) |  |  | $ | 48.02 |  |
| Balance as of June 25, 2021 | 427,028 |  |  | $ | 57.82 |  |
| Granted | 110,832 |  |  | $ | 101.05 |  |
| Issued | (190,213) |  |  | 48.65 |  |
| Forfeited | (61,765) |  |  | $ | 53.38 |  |
| Balance as of June 24, 2022 | 285,882 |  |  | $ | 81.64 |  |
| Expected to vest as of June 24, 2022 | 285,882 |  |  | $ | 81.64 |  |

[0001408710-22-000045:notes:302]
The fair value of restricted share units and performance share units is based on the market value of our ordinary shares on the date of grant.

[0001408710-22-000045:notes:303]
The total fair value of restricted share units and performance share units vested during the years ended June 24, 2022, June 25, 2021 and June 26, 2020 was $24.2 million, $22.1 million and $13.7 million, respectively. The aggregate intrinsic value of restricted share units and performance share units outstanding as of June 24, 2022 was $62.0 million.

[0001408710-22-000045:notes:304]
As of June 24, 2022, there was $11.2 million and $6.4 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.5 years and 1.0 year, respectively.

[0001408710-22-000045:notes:305]
For the years ended June 24, 2022 and June 25, 2021, the Company withheld an aggregate of 213,884 shares and 163,615 shares, respectively, upon the vesting of restricted share units, based upon the closing share price on the vesting date to settle employee tax withholding obligations. For the years ended June 24, 2022 and June 25, 2021, the Company then remitted cash of $20.8 million and $11.6 million, respectively, to the appropriate taxing authorities, and presented it as a financing activity within the consolidated statements of cash flows. The payment had the effect of reducing the number of shares that the Company would have issued on the vesting date and was recorded as a reduction of additional paid-in capital.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001408710-22-000045:notes:306]
Employee benefit plans
Employee contribution plan

[0001408710-22-000045:notes:307]
The Company operates a defined contribution plan, known as a provident fund, in its subsidiaries in Thailand and the United Kingdom. The assets of these plans are in separate trustee-administered funds. The provident fund is funded by matching payments from employees and by the subsidiaries on a monthly basis. Current contributions to the provident fund are accrued and paid to the fund manager on a monthly basis. The Company’s contributions to the provident fund amounted to $6.1 million, $6.0 million and $5.5 million during the years ended June 24, 2022, June 25, 2021 and June 26, 2020, respectively.

[0001408710-22-000045:notes:308]
The Company sponsors the Fabrinet U.S. 401(k) Retirement Plan (“401(k) Plan”), a Defined Contribution Plan under ERISA, at its subsidiaries in the United States which provides retirement benefits for eligible employees through tax deferred salary deductions. The 401(k) Plan allows employees to contribute up to 80% of their annual compensation, subject to annual contributions limits established by the Internal Revenue Service. The Company provides for a 100% match of employees’ contributions to the 401(k) Plan up to the first 6% of annual compensation. All matching contributions are made in cash and vest immediately. The Company’s matching contributions to the 401(k) Plan were $0.7 million, $0.8 million and $0.7 million during the years ended June 24, 2022, June 25, 2021 and June 26, 2020, respectively.

[0001408710-22-000045:notes:309]
Executive incentive plan and employee performance bonuses

[0001408710-22-000045:notes:310]
For the years ended June 24, 2022 and June 25, 2021, the Company maintained an executive incentive plan with quantitative objectives, based on achieving certain revenue and non-U.S. GAAP operating margin or gross margin targets. During the years ended June 24, 2022, June 25, 2021 and June 26, 2020, discretionary merit-based bonus awards were also available to Fabrinet’s non-executive employees.

[0001408710-22-000045:notes:311]
Bonus distributions to employees were $9.3 million, $8.9 million and $8.7 million for the years ended June 24, 2022, June 25, 2021 and June 26, 2020, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001408710-22-000045:notes:312]
Shareholders’ equity
Share capital

[0001408710-22-000045:notes:313]
Fabrinet’s authorized share capital is 500,000,000 ordinary shares, par value of $0.01 per ordinary share, and 5,000,000 preferred shares, par value of $0.01 per preferred share.

[0001408710-22-000045:notes:314]
For the year ended June 24, 2022, Fabrinet issued 299,655 ordinary shares upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-22-000045:notes:315]
For the year ended June 25, 2021, Fabrinet issued 277,078 ordinary shares upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-22-000045:notes:316]
For the year ended June 26, 2020, Fabrinet issued 241,214 ordinary shares upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-22-000045:notes:317]
All such issued shares are fully paid.

[0001408710-22-000045:notes:318]
In August 2017, the Company’s board of directors approved a share repurchase program to permit the Company to repurchase up to $30.0 million worth of its issued and outstanding ordinary shares in the open market in accordance with applicable rules and regulations. In February 2018, May 2019 and August 2020, the Company’s board of directors approved an increase of $30.0 million, $50.0 million and 58.5 million, respectively, to the original share repurchase authorization, bringing the aggregate authorization to $168.5 million.

[0001408710-22-000045:notes:319]
During the year ended June 24, 2022, the Company repurchased 628,428 shares under the program at an average price per share (excluding other direct costs) of $95.32, totaling $59.9 million. As of June 24, 2022, the Company had a remaining authorization to repurchase up to $21.3 million of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001408710-22-000045:notes:320]
Accumulated other comprehensive income (loss) (“AOCI”)
The changes in AOCI for the years ended June 24, 2022 and June 25, 2021 were as follows:

[0001408710-22-000045:notes:321]
| (amount in thousands) | Unrealized Gains(Losses) onAvailable-for-saleSecurities |  | UnrealizedGains (Losses)on DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 26, 2020 | $ | 1,490 |  |  | $ | 602 |  |  | $ | (2,009) |  |  | $ | (1,230) |  |  | $ | (1,147) |  |
| Other comprehensive income before reclassification | (1,003) |  |  | (4,570) |  |  | — |  |  | 585 |  |  | (4,988) |  |
| Amounts reclassified from AOCI | (179) |  |  | (536) |  |  | 584 |  |  | — |  |  | (131) |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income | (1,182) |  |  | (5,106) |  |  | 584 |  |  | 585 |  |  | (5,119) |  |
| Balance as of June 25, 2021 | 308 |  |  | (4,504) |  |  | (1,425) |  |  | (645) |  |  | (6,266) |  |
| Other comprehensive income before reclassification | (6,339) |  |  | 157 |  |  | — |  |  | (245) |  |  | (6,427) |  |
| Amounts reclassified from AOCI | 13 |  |  | (735) |  |  | 622 |  |  | — |  |  | (100) |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income | (6,326) |  |  | (578) |  |  | 622 |  |  | (245) |  |  | (6,527) |  |
| Balance as of June 24, 2022 | $ | (6,018) |  |  | $ | (5,082) |  |  | $ | (803) |  |  | $ | (890) |  |  | $ | (12,793) |  |

[0001408710-22-000045:notes:322]
The following table presents the pre-tax amounts reclassified from AOCI into the consolidated statements of operations and comprehensive income for the years ended June 24, 2022 and June 25, 2021, respectively.

[0001408710-22-000045:notes:323]
| (amount in thousands) |  |  |  | Years Ended |
| AOCI components |  | Financial statementsline item |  | June 24,2022 |  | June 25,2021 |
| Unrealized gains (losses) on available-for-sale securities |  | Interest income |  | $ | 13 |  |  | $ | (179) |  |
| Unrealized gains(losses)on derivative instruments |  | Cost of revenues |  | 7,283 |  |  | (966) |  |
| Unrealized gains(losses)on derivative instruments |  | Selling, general and administrative expenses |  | 303 |  |  | (40) |  |
| Unrealized gains(losses)on derivative instruments |  | Foreign exchange loss, net |  | (7,384) |  |  | 1,769 |  |
| Unrealized gains(losses)on derivative instruments |  | Interest expense |  | (937) |  |  | (1,299) |  |
| Retirement benefit plan – Prior service cost |  | Selling, general and administrative expenses |  | 622 |  |  | 584 |  |
| Total amounts reclassified from AOCI |  |  |  | $ | (100) |  |  | $ | (131) |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001408710-22-000045:notes:324]
Commitments and contingencies
Letter of Credit and Bank guarantees

[0001408710-22-000045:notes:325]
As of June 24, 2022, the Company had an outstanding letter of credit totaling $0.2 million on behalf of the Company's subsidiary in the PRC to support the subsidiary's operations.

[0001408710-22-000045:notes:326]
As of June 24, 2022 and June 25, 2021, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $1.4 million and $1.6 million, respectively, or Thai Baht 50.2 million and an outstanding bank guarantee on behalf of the Company's subsidiary in the PRC to support the subsidiary's operations totaling Renminbi 1.0 million, which bank guarantee was backed by cash collateral of $0.1 million and $0.2 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in the U.K. to support its operations.

[0001408710-22-000045:notes:327]
Purchase obligations

[0001408710-22-000045:notes:328]
Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001408710-22-000045:notes:329]
As of June 24, 2022, the Company had purchase obligations and other commitments to third parties of $1.51 billion.

[0001408710-22-000045:notes:330]
Capital expenditure

[0001408710-22-000045:notes:331]
As of June 24, 2022, the Company had total capital expenditure commitments to third parties of $24.8 million.

[0001408710-22-000045:notes:332]
Indemnification of directors and officers

[0001408710-22-000045:notes:333]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001408710-22-000045:notes:334]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001408710-22-000045:notes:335]
Business segments and geographic information
Operating segments are defined as components of an enterprise that engage in business activities for which discrete financial information is available that is evaluated regularly by the chief operating decision maker (the “CODM”) in deciding how to allocate resources and in assessing performance. The Company’s CODM is Fabrinet’s Chief Executive Officer. As of June 24, 2022, June 25, 2021 and June 26, 2020, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001408710-22-000045:notes:336]
For the Company’s revenues by geographic region, see “Revenue by Geographic Area and End Market” in Note 3.

[0001408710-22-000045:notes:337]
The following table presents long-lived assets by the country in which they are based:

[0001408710-22-000045:notes:338]
|  |  | Years Ended |
| (amount in thousands) |  | June 24,2022 |  | June 25,2021 |  | June 26,2020 |
| Long-Lived Assets: |  |  |  |  |  |  |
| Thailand |  | $ | 240,750 |  |  | $ | 190,843 |  |  | $ | 175,738 |  |
| U.S. |  | 25,938 |  |  | 27,403 |  |  | 29,507 |  |
| China |  | 19,686 |  |  | 14,977 |  |  | 14,476 |  |
| Israel |  | 4,025 |  |  | 5,271 |  |  | 5,224 |  |
| U.K. |  | 1,281 |  |  | 2,223 |  |  | 2,956 |  |
| Cayman Islands |  | 597 |  |  | 412 |  |  | 373 |  |
|  |  | 292,277 |  |  | 241,129 |  |  | 228,274 |  |

[0001408710-22-000045:notes:339]
Significant customers

[0001408710-22-000045:notes:340]
Total revenues, by percentage, from individual customers representing 10% or more of total revenues in the respective periods were as follows:

[0001408710-22-000045:notes:341]
|  | Years Ended |
|  | June 24,2022 |  | June 25,2021 |  | June 26,2020 |
| Cisco Systems Inc. (1) | 25.4 | % |  | 10.7 | % |  | * |
| Lumentum Operations LLC | 10.3 | % |  | 13.6 | % |  | 19.0 | % |
| Infinera Corporation | 12.5 | % |  | 11.6 | % |  | 10.0 | % |
| Acacia Communications Inc. | * |  | * |  | 10.2 | % |

[0001408710-22-000045:notes:342]
*Represents less than 10% of total revenues.

[0001408710-22-000045:notes:343]
(1)Inclusive of revenue from Acacia Communications, Inc. from March 1, 2021

[0001408710-22-000045:notes:344]
Accounts receivable from individual customers representing 10% or more of accounts receivable as of June 24, 2022 and June 25, 2021, respectively, were as follows:

[0001408710-22-000045:notes:345]
|  | As of June 24,2022 |  | As of June 25,2021 |
| Infinera Corporation | 17.3 | % |  | 18.6 | % |
| Lumentum Operations LLC | 12.0 | % |  | 11.6 | % |
| Cisco Systems Inc. (1) | 20.1 | % |  | 15.0 | % |

[0001408710-22-000045:notes:346]
(1)Includes of Acacia Communications Inc. as of June 24, 2022


## fn:ScheduleOfAccountsReceivableByMajorCustomersByReportingSegmentsTableTextBlock

[0001408710-22-000045:notes:347]
(1)Includes of Acacia Communications Inc. as of June 24, 2022.


## us-gaap:FinancialInstrumentsDisclosureTextBlock

[0001408710-22-000045:notes:348]
Financial instruments
Objectives and significant terms and conditions

[0001408710-22-000045:notes:349]
The principal financial risks faced by the Company are foreign currency risk and interest rate risk. The Company borrows at floating rates of interest to finance its operations. A minority of sales and purchases and a majority of labor and overhead costs are entered into in foreign currencies. In order to manage the risks arising from fluctuations in currency exchange rates, the Company uses derivative instruments. Trading for speculative purposes is prohibited under Company policies.

[0001408710-22-000045:notes:350]
The Company enters into short-term foreign currency forward and option contracts to manage foreign currency exposures associated with certain assets, liabilities and other forecasted foreign currency transactions and may designate these instruments as hedging instruments. The foreign currency forward and option contracts generally have maturities of up to twelve months. All foreign currency exchange contracts are recognized on the consolidated balance sheets at fair value. Gain or loss on the Company’s derivative instruments generally offset the assets, liabilities under master netting arrangement and transactions economically hedged.

[0001408710-22-000045:notes:351]
Foreign currency risk

[0001408710-22-000045:notes:352]
The Company operates internationally and is exposed to foreign exchange risk arising from various currency exposures primarily with respect to the Thai baht, RMB and GBP.

[0001408710-22-000045:notes:353]
For the Company’s foreign currency assets and liabilities, see “Additional Financial Disclosures” in Item 7.

[0001408710-22-000045:notes:354]
Interest Rate Risk

[0001408710-22-000045:notes:355]
The Company’s principal interest bearing assets are time deposits and short-term investments with maturities of three years or less held with high quality financial institutions. The Company’s principal interest bearing liabilities are bank loans which bear interest at floating rates.

[0001408710-22-000045:notes:356]
The Company entered into interest rate swap agreements (the “Swap Agreements”) to manage this risk and increase the profile of the Company’s debt obligation. The terms of the Swap Agreements allow the Company to effectively convert the floating interest rate to a fixed interest rate. This locks the variable in interest expenses associated with our floating rate borrowings and results in fixed interest expenses, which is unsusceptible to market rate increase. The Company designated the Swap Agreements as a cash flow hedge, and they qualify for hedge accounting because the hedges are highly effective. While the Company intend to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in our earnings. From September 27, 2019, any gains or losses related to these outstanding interest rate swaps will be recorded in accumulated other comprehensive income in the consolidated balance sheets, with subsequent reclassification to interest expense when settled.


## us-gaap:SubsequentEventsTextBlock

[0001408710-22-000045:notes:357]
Subsequent EventIn August 2022, the Company’s board of directors approved the repurchase of up to an additional $78.7 million of the Company’s outstanding ordinary shares, bringing the aggregate authorization under the Company’s existing share repurchase program to $247.2 million, with $100.0 million currently remaining.
