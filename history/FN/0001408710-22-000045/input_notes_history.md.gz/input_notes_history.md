# FN note change history — 0001408710-22-000018 → 0001408710-22-000028


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-05-03):
[0001408710-22-000028:note_history:1]
As of March 25, 2022 and June 25, 2021, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling to $1.5 million and $1.6 million, respectively, or Thai Baht 50.2 million. As of March 25, 2022 and June 25, 2021, the Company had an outstanding bank guarantee on behalf of its subsidiary in the PRC to support the subsidiary's operations totaling Renminbi 1.0 million, which bank guarantee was backed by cash collateral of $0.2 million. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in the U.K. to support its operations.
  (was, 2022-02-01, similarity 0.9312):
[0001408710-22-000018:note_history:1]
As of December 24, 2021 and June 25, 2021, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling to $1.5 million and $1.6 million, respectively, or Thai Baht 50.2 million. As of December 24, 2021 and June 25, 2021, the Company had an outstanding bank guarantee on behalf of its subsidiary in the PRC to support the subsidiary's operations totaling Renminbi 2.0 million and Renminbi 1.0 million, respectively, which bank guarantee was backed by cash collateral of $0.3 million and $0.2 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in the U.K. to support its operations.

- changed (2022-05-03):
[0001408710-22-000028:note_history:2]
As of March 25, 2022, the Company had a purchase obligation and other commitments to third parties of $1,414.6 million.
  (was, 2022-02-01, similarity 0.9585):
[0001408710-22-000018:note_history:2]
As of December 24, 2021, the Company had a purchase obligation and other commitments to third parties of $1,301.7 million.

- added (2022-05-03):
[0001408710-22-000028:note_history:3]
As of March 25, 2022, the Company had total capital expenditure commitments to third parties of $17.7 million.

- removed (2022-05-03):
[0001408710-22-000018:note_history:4]
In December 2020, the Company entered into a construction contract with a local contractor for construction of a new manufacturing building at the Company’s Chonburi campus. The contract price is approximately $50.3 million.

- removed (2022-05-03):
[0001408710-22-000018:note_history:5]
In June 2021, the Company entered into an agreement to purchase a parcel of land in Pathumthani, Thailand to expand the Company's Pinehurst campus. The aggregate purchase price was approximately $13.2 million or Thai Baht 418.8 million, which was paid in two installments: (1) a 10% deposit on May 14, 2021; and (2) the remainder on June 29, 2021.

- removed (2022-05-03):
[0001408710-22-000018:note_history:6]
As of December 24, 2021, the Company had total capital expenditure commitments to third parties of $19.9 million, comprised of the construction contract of the new manufacturing building at Chonburi campus of $2.9 million and other commitments of $17.0 million.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-05-03):
[0001408710-22-000028:note_history:7]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of March 25, 2022 and for the three and nine months ended March 25, 2022 and March 26, 2021 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 25, 2021.
  (was, 2022-02-01, similarity 0.9548):
[0001408710-22-000018:note_history:7]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of December 24, 2021 and for the three and six months ended December 24, 2021 and December 25, 2020 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 25, 2021.

- changed (2022-05-03):
[0001408710-22-000028:note_history:8]
The results for the three and nine months ended March 25, 2022 may not be indicative of results for the year ending June 24, 2022 or any future periods.
  (was, 2022-02-01, similarity 0.951):
[0001408710-22-000018:note_history:8]
The results for the three and six months ended December 24, 2021 may not be indicative of results for the year ending June 24, 2022 or any future periods.

- changed (2022-05-03):
[0001408710-22-000028:note_history:9]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  March 25, 2022 and March 26, 2021 each consisted of 13 weeks. The nine months ended March 25, 2022 and March 26, 2021 each consisted of 39 weeks. Fiscal year 2022 will be comprised of 52 weeks and will end on June 24, 2022.
  (was, 2022-02-01, similarity 0.8019):
[0001408710-22-000018:note_history:9]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  December 24, 2021 and December 25, 2020 each consisted of 13 weeks. The six months ended December 24, 2021 and December 25, 2020 each consisted of 26 weeks. Fiscal year 2022 will be comprised of 52 weeks and will end on June 24, 2022.

- changed (2022-05-03):
[0001408710-22-000028:note_history:10]
In November 2021, FASB issued ASU 2021-10, “Government Assistance (Topic 832), Disclosures by Business Entities about Government Assistance,” which requires annual disclosures that increase the transparency of transactions involving government assistance, including (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The amendments in this update are effective for all entities within the ASU's scope for financial statements issued for annual periods beginning after December 15, 2021. This ASU will be effective for the Company in the first quarter of fiscal year 2023. Early adoption is permitted.  The Company is currently evaluating the impact of the adoption of this update on its consolidated financial statements.
  (was, 2022-02-01, similarity 0.9684):
[0001408710-22-000018:note_history:10]
In November 2021, the Financial Accounting Standards Board issued ASU 2021-10, “Government Assistance (Topic 832), Disclosures by Business Entities about Government Assistance,” which requires annual disclosures that increase the transparency of transactions involving government assistance, including (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The amendments in this update are effective for all entities within the ASU's scope for financial statements issued for annual periods beginning after December 15, 2021. This ASU will be effective for the Company in the first quarter of fiscal year 2023. Early adoption is permitted.  The Company is currently evaluating the impact of the adoption of this update on its condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-05-03):
[0001408710-22-000028:note_history:11]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofMarch 25, 2022 |  | As ofJune 25, 2021 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 30,468 |  |  | $ | 39,609 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs, non-current portion |  |  |  |  | (39) |  |  | (63) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 18,241 |  |  | $ | 27,358 |  |

- changed (2022-05-03):
[0001408710-22-000028:note_history:12]
The movements of long-term borrowings for the nine months ended March 25, 2022 and March 26, 2021 were as follows:
  (was, 2022-02-01, similarity 0.892):
[0001408710-22-000018:note_history:12]
The movements of long-term borrowings for the six months ended December 24, 2021 and December 25, 2020 were as follows:

- changed (2022-05-03):
[0001408710-22-000028:note_history:13]
|  | Nine Months Ended |
| (amount in thousands) | March 25,2022 |  | March 26,2021 |
| Opening balance | $ | 39,609 |  |  | $ | 51,797 |  |
| Borrowings during the period | — |  |  | — |  |
| Repayments during the period | (9,141) |  |  | (9,141) |  |
| Closing balance | $ | 30,468 |  |  | $ | 42,656 |  |
  (was, 2022-02-01, similarity 0.908):
[0001408710-22-000018:note_history:13]
|  | Six Months Ended |
| (amount in thousands) | December 24,2021 |  | December 25,2020 |
| Opening balance | $ | 39,609 |  |  | $ | 51,797 |  |
| Borrowings during the period | — |  |  | — |  |
| Repayments during the period | (6,094) |  |  | (6,094) |  |
| Closing balance | $ | 33,515 |  |  | $ | 45,703 |  |

- changed (2022-05-03):
[0001408710-22-000028:note_history:14]
As of March 25, 2022, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2022-02-01, similarity 0.9548):
[0001408710-22-000018:note_history:14]
As of December 24, 2021, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2022-05-03):
[0001408710-22-000028:note_history:15]
| (amount in thousands) |  |
| 2022 (remaining three months) | $ | 3,047 |  |
| 2023 | 15,233 |  |
| 2024 | 9,141 |  |
| 2025 | 3,047 |  |
| Total | $ | 30,468 |  |
  (was, 2022-02-01, similarity 0.9675):
[0001408710-22-000018:note_history:15]
| (amount in thousands) |  |
| 2022 (remaining six months) | $ | 6,094 |  |
| 2023 | 15,234 |  |
| 2024 | 9,140 |  |
| 2025 | 3,047 |  |
| Total | $ | 33,515 |  |

- changed (2022-05-03):
[0001408710-22-000028:note_history:16]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three and nine months ended March 25, 2022, the Company recorded $0.6 million and $1.7 million, respectively, of interest expense in connection with this term loan, including impact from interest rate swaps. $0.3 million and $0.6 million of these interest expenses were capitalized during the three and nine months ended March 25, 2022, respectively, in a new manufacturing building at the Company's Chonburi campus.
  (was, 2022-02-01, similarity 0.8394):
[0001408710-22-000018:note_history:16]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three and six months ended December 24, 2021, the Company recorded $0.6 million and $1.1 million, respectively, of interest expense in connection with this term loan, including impact from interest rate swaps. During the three and six months ended December 24, 2021, $0.1 million and $0.4 million, respectively, of these interest expenses were capitalized in a new manufacturing building at our Chonburi campus.

- changed (2022-05-03):
[0001408710-22-000028:note_history:17]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of March 25, 2022, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.
  (was, 2022-02-01, similarity 0.9939):
[0001408710-22-000018:note_history:17]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of December 24, 2021, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

- changed (2022-05-03):
[0001408710-22-000028:note_history:18]
As of March 25, 2022, there was $30.5 million outstanding under the term loan.
  (was, 2022-02-01, similarity 0.9362):
[0001408710-22-000018:note_history:18]
As of December 24, 2021, there was $33.5 million outstanding under the term loan.

- removed (2022-05-03):
[0001408710-22-000018:note_history:19]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofDecember 24, 2021 |  | As ofJune 25, 2021 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 33,515 |  |  | $ | 39,609 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  | (48) |  |  | (63) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 21,279 |  |  | $ | 27,358 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-03):
[0001408710-22-000028:note_history:20]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of March 25, 2022 and June 25, 2021:
  (was, 2022-02-01, similarity 0.9679):
[0001408710-22-000018:note_history:20]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of December 24, 2021 and June 25, 2021:

- added (2022-05-03):
[0001408710-22-000028:note_history:21]
|  | March 25, 2022 |  | June 25, 2021 |
| (amount in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 68,455 |  |  | $ | 68,383 |  |  | $ | 30,000 |  |  | $ | 31,226 |  |
| Due between one to five years | 180,697 |  |  | 177,469 |  |  | 202,927 |  |  | 203,237 |  |
| Total | $ | 249,152 |  |  | $ | 245,852 |  |  | $ | 232,927 |  |  | $ | 234,463 |  |

- removed (2022-05-03):
[0001408710-22-000018:note_history:22]
|  | December 24, 2021 |  | June 25, 2021 |
| (amount in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 64,111 |  |  | $ | 64,088 |  |  | $ | 30,000 |  |  | $ | 31,226 |  |
| Due between one to five years | 180,078 |  |  | 179,251 |  |  | 202,927 |  |  | 203,237 |  |
| Total | $ | 244,189 |  |  | $ | 243,339 |  |  | $ | 232,927 |  |  | $ | 234,463 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-03):
[0001408710-22-000028:note_history:23]
The movements of long-term borrowings for the nine months ended March 25, 2022 and March 26, 2021 were as follows:
  (was, 2022-02-01, similarity 0.892):
[0001408710-22-000018:note_history:23]
The movements of long-term borrowings for the six months ended December 24, 2021 and December 25, 2020 were as follows:

- changed (2022-05-03):
[0001408710-22-000028:note_history:24]
|  | Nine Months Ended |
| (amount in thousands) | March 25,2022 |  | March 26,2021 |
| Opening balance | $ | 39,609 |  |  | $ | 51,797 |  |
| Borrowings during the period | — |  |  | — |  |
| Repayments during the period | (9,141) |  |  | (9,141) |  |
| Closing balance | $ | 30,468 |  |  | $ | 42,656 |  |
  (was, 2022-02-01, similarity 0.908):
[0001408710-22-000018:note_history:24]
|  | Six Months Ended |
| (amount in thousands) | December 24,2021 |  | December 25,2020 |
| Opening balance | $ | 39,609 |  |  | $ | 51,797 |  |
| Borrowings during the period | — |  |  | — |  |
| Repayments during the period | (6,094) |  |  | (6,094) |  |
| Closing balance | $ | 33,515 |  |  | $ | 45,703 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-05-03):
[0001408710-22-000028:note_history:25]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofMarch 25, 2022 |  | As ofJune 25, 2021 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 30,468 |  |  | $ | 39,609 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs, non-current portion |  |  |  |  | (39) |  |  | (63) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 18,241 |  |  | $ | 27,358 |  |

- removed (2022-05-03):
[0001408710-22-000018:note_history:26]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofDecember 24, 2021 |  | As ofJune 25, 2021 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 33,515 |  |  | $ | 39,609 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  | (48) |  |  | (63) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 21,279 |  |  | $ | 27,358 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-03):
[0001408710-22-000028:note_history:27]
As of March 25, 2022, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2022-02-01, similarity 0.9548):
[0001408710-22-000018:note_history:27]
As of December 24, 2021, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2022-05-03):
[0001408710-22-000028:note_history:28]
| (amount in thousands) |  |
| 2022 (remaining three months) | $ | 3,047 |  |
| 2023 | 15,233 |  |
| 2024 | 9,141 |  |
| 2025 | 3,047 |  |
| Total | $ | 30,468 |  |
  (was, 2022-02-01, similarity 0.9675):
[0001408710-22-000018:note_history:28]
| (amount in thousands) |  |
| 2022 (remaining six months) | $ | 6,094 |  |
| 2023 | 15,234 |  |
| 2024 | 9,140 |  |
| 2025 | 3,047 |  |
| Total | $ | 33,515 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-03):
[0001408710-22-000028:note_history:29]
| (amount in thousands, except percentages) | Three Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 292,475 |  |  |  |  | 781,469 |  |  |  |
| Others (1) | 4,123 |  |  |  |  | 8,996 |  |  |  |
| Total revenue in North America | 296,598 |  |  | 52.5 | % |  | 790,465 |  |  | 47.2 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 70,956 |  |  |  |  | 210,009 |  |  |  |
| Malaysia | 51,188 |  |  |  |  | 163,306 |  |  |  |
| Hong Kong | 17,338 |  |  |  |  | 61,575 |  |  |  |
| Israel | 16,883 |  |  |  |  | 67,318 |  |  |  |
| Japan | 16,449 |  |  |  |  | 47,258 |  |  |  |
| China | 12,843 |  |  |  |  | 40,624 |  |  |  |
| Others | 10,559 |  |  |  |  | 34,349 |  |  |  |
| Total revenue in Asia-Pacific and others | 196,216 |  |  | 34.8 | % |  | 624,439 |  |  | 37.3 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 28,640 |  |  |  |  | 133,024 |  |  |  |
| U.K. | 21,632 |  |  |  |  | 64,151 |  |  |  |
| Germany | 10,688 |  |  |  |  | 28,098 |  |  |  |
| Others | 10,621 |  |  |  |  | 34,173 |  |  |  |
| Total revenue in Europe | $ | 71,581 |  |  | 12.7 | % |  | $ | 259,446 |  |  | 15.5 | % |
| Total revenue | $ | 564,395 |  |  | 100.0 | % |  | $ | 1,674,350 |  |  | 100.0 | % |
  (was, 2022-02-01, similarity 0.9851):
[0001408710-22-000018:note_history:29]
| (amount in thousands, except percentages) | Three Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |  | Six Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 243,720 |  |  |  |  | 488,994 |  |  |  |
| Others (1) | 3,557 |  |  |  |  | 4,873 |  |  |  |
| Total revenue in North America | 247,277 |  |  | 43.6 | % |  | 493,867 |  |  | 44.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 74,121 |  |  |  |  | 139,054 |  |  |  |
| Malaysia | 60,369 |  |  |  |  | 112,118 |  |  |  |
| Hong Kong | 23,206 |  |  |  |  | 44,237 |  |  |  |
| Israel | 22,801 |  |  |  |  | 50,434 |  |  |  |
| Japan | 15,832 |  |  |  |  | 30,809 |  |  |  |
| China | 14,146 |  |  |  |  | 27,781 |  |  |  |
| Others | 11,565 |  |  |  |  | 23,790 |  |  |  |
| Total revenue in Asia-Pacific and others | 222,040 |  |  | 39.2 | % |  | 428,223 |  |  | 38.6 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 54,900 |  |  |  |  | 104,384 |  |  |  |
| U.K. | 22,941 |  |  |  |  | 42,519 |  |  |  |
| Germany | 8,985 |  |  |  |  | 17,410 |  |  |  |
| Others | 10,490 |  |  |  |  | 23,552 |  |  |  |
| Total revenue in Europe | $ | 97,316 |  |  | 17.2 | % |  | $ | 187,865 |  |  | 16.9 | % |
| Total revenue | $ | 566,633 |  |  | 100.0 | % |  | $ | 1,109,955 |  |  | 100.0 | % |

- changed (2022-05-03):
[0001408710-22-000028:note_history:30]
| (amount in thousands, except percentages) | Three Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 230,177 |  |  |  |  | 661,410 |  |  |  |
| Others (1) | 618 |  |  |  |  | 1,459 |  |  |  |
| Total revenue in North America | 230,795 |  |  | 48.2 | % |  | 662,869 |  |  | 48.4 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Malaysia | 22,910 |  |  |  |  | 107,700 |  |  |  |
| India | 56,719 |  |  |  |  | 85,535 |  |  |  |
| Israel | 25,796 |  |  |  |  | 82,915 |  |  |  |
| Hong Kong | 21,524 |  |  |  |  | 63,397 |  |  |  |
| Japan | 18,582 |  |  |  |  | 56,223 |  |  |  |
| Others | 21,770 |  |  |  |  | 71,477 |  |  |  |
| Total revenue in Asia-Pacific and others | 167,301 |  |  | 34.9 | % |  | 467,247 |  |  | 34.1 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 47,096 |  |  |  |  | 149,696 |  |  |  |
| U.K. | 15,298 |  |  |  |  | 40,742 |  |  |  |
| Germany | 7,543 |  |  |  |  | 19,596 |  |  |  |
| Others | 11,284 |  |  |  |  | 29,633 |  |  |  |
| Total revenue in Europe | $ | 81,221 |  |  | 16.9 | % |  | $ | 239,667 |  |  | 17.5 | % |
| Total revenue | $ | 479,317 |  |  | 100.0 | % |  | $ | 1,369,783 |  |  | 100.0 | % |
  (was, 2022-02-01, similarity 0.9682):
[0001408710-22-000018:note_history:30]
| (amount in thousands, except percentages) | Three Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |  | Six Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 224,046 |  |  |  |  | 430,996 |  |  |  |
| Others (1) | 626 |  |  |  |  | 1,078 |  |  |  |
| Total revenue in North America | 224,672 |  |  | 49.5 | % |  | 432,074 |  |  | 48.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Malaysia | 34,546 |  |  |  |  | 80,188 |  |  |  |
| India | 28,865 |  |  |  |  | 28,885 |  |  |  |
| Israel | 27,102 |  |  |  |  | 57,217 |  |  |  |
| Hong Kong | 18,092 |  |  |  |  | 41,598 |  |  |  |
| Japan | 17,309 |  |  |  |  | 37,642 |  |  |  |
| China | 12,563 |  |  |  |  | 26,340 |  |  |  |
| Others | 15,257 |  |  |  |  | 27,510 |  |  |  |
| Total revenue in Asia-Pacific and others | 153,734 |  |  | 33.9 | % |  | 299,380 |  |  | 33.6 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 48,954 |  |  |  |  | 102,730 |  |  |  |
| U.K. | 10,004 |  |  |  |  | 25,315 |  |  |  |
| Germany | 6,253 |  |  |  |  | 12,052 |  |  |  |
| Others | 10,210 |  |  |  |  | 18,915 |  |  |  |
| Total revenue in Europe | $ | 75,421 |  |  | 16.6 | % |  | $ | 159,012 |  |  | 17.9 | % |
| Total revenue | $ | 453,827 |  |  | 100.0 | % |  | $ | 890,466 |  |  | 100.0 | % |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-03):
[0001408710-22-000028:note_history:31]
Revenues are attributed to a particular geographic area based on the bill-to-location of the Company’s customers. The Company operates in three geographic regions: North America; Asia-Pacific and others; and Europe.
  (was, 2022-02-01, similarity 0.993):
[0001408710-22-000018:note_history:31]
Revenues are attributed to a particular geographic area based on the bill-to-location of the Company’s customers. The Company operates in three geographic regions: North America, Asia-Pacific and others and Europe.

- changed (2022-05-03):
[0001408710-22-000028:note_history:32]
| (amount in thousands, except percentages) | Three Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 292,475 |  |  |  |  | 781,469 |  |  |  |
| Others (1) | 4,123 |  |  |  |  | 8,996 |  |  |  |
| Total revenue in North America | 296,598 |  |  | 52.5 | % |  | 790,465 |  |  | 47.2 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 70,956 |  |  |  |  | 210,009 |  |  |  |
| Malaysia | 51,188 |  |  |  |  | 163,306 |  |  |  |
| Hong Kong | 17,338 |  |  |  |  | 61,575 |  |  |  |
| Israel | 16,883 |  |  |  |  | 67,318 |  |  |  |
| Japan | 16,449 |  |  |  |  | 47,258 |  |  |  |
| China | 12,843 |  |  |  |  | 40,624 |  |  |  |
| Others | 10,559 |  |  |  |  | 34,349 |  |  |  |
| Total revenue in Asia-Pacific and others | 196,216 |  |  | 34.8 | % |  | 624,439 |  |  | 37.3 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 28,640 |  |  |  |  | 133,024 |  |  |  |
| U.K. | 21,632 |  |  |  |  | 64,151 |  |  |  |
| Germany | 10,688 |  |  |  |  | 28,098 |  |  |  |
| Others | 10,621 |  |  |  |  | 34,173 |  |  |  |
| Total revenue in Europe | $ | 71,581 |  |  | 12.7 | % |  | $ | 259,446 |  |  | 15.5 | % |
| Total revenue | $ | 564,395 |  |  | 100.0 | % |  | $ | 1,674,350 |  |  | 100.0 | % |
  (was, 2022-02-01, similarity 0.9851):
[0001408710-22-000018:note_history:32]
| (amount in thousands, except percentages) | Three Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |  | Six Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 243,720 |  |  |  |  | 488,994 |  |  |  |
| Others (1) | 3,557 |  |  |  |  | 4,873 |  |  |  |
| Total revenue in North America | 247,277 |  |  | 43.6 | % |  | 493,867 |  |  | 44.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 74,121 |  |  |  |  | 139,054 |  |  |  |
| Malaysia | 60,369 |  |  |  |  | 112,118 |  |  |  |
| Hong Kong | 23,206 |  |  |  |  | 44,237 |  |  |  |
| Israel | 22,801 |  |  |  |  | 50,434 |  |  |  |
| Japan | 15,832 |  |  |  |  | 30,809 |  |  |  |
| China | 14,146 |  |  |  |  | 27,781 |  |  |  |
| Others | 11,565 |  |  |  |  | 23,790 |  |  |  |
| Total revenue in Asia-Pacific and others | 222,040 |  |  | 39.2 | % |  | 428,223 |  |  | 38.6 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 54,900 |  |  |  |  | 104,384 |  |  |  |
| U.K. | 22,941 |  |  |  |  | 42,519 |  |  |  |
| Germany | 8,985 |  |  |  |  | 17,410 |  |  |  |
| Others | 10,490 |  |  |  |  | 23,552 |  |  |  |
| Total revenue in Europe | $ | 97,316 |  |  | 17.2 | % |  | $ | 187,865 |  |  | 16.9 | % |
| Total revenue | $ | 566,633 |  |  | 100.0 | % |  | $ | 1,109,955 |  |  | 100.0 | % |

- changed (2022-05-03):
[0001408710-22-000028:note_history:33]
| (amount in thousands, except percentages) | Three Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 230,177 |  |  |  |  | 661,410 |  |  |  |
| Others (1) | 618 |  |  |  |  | 1,459 |  |  |  |
| Total revenue in North America | 230,795 |  |  | 48.2 | % |  | 662,869 |  |  | 48.4 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Malaysia | 22,910 |  |  |  |  | 107,700 |  |  |  |
| India | 56,719 |  |  |  |  | 85,535 |  |  |  |
| Israel | 25,796 |  |  |  |  | 82,915 |  |  |  |
| Hong Kong | 21,524 |  |  |  |  | 63,397 |  |  |  |
| Japan | 18,582 |  |  |  |  | 56,223 |  |  |  |
| Others | 21,770 |  |  |  |  | 71,477 |  |  |  |
| Total revenue in Asia-Pacific and others | 167,301 |  |  | 34.9 | % |  | 467,247 |  |  | 34.1 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 47,096 |  |  |  |  | 149,696 |  |  |  |
| U.K. | 15,298 |  |  |  |  | 40,742 |  |  |  |
| Germany | 7,543 |  |  |  |  | 19,596 |  |  |  |
| Others | 11,284 |  |  |  |  | 29,633 |  |  |  |
| Total revenue in Europe | $ | 81,221 |  |  | 16.9 | % |  | $ | 239,667 |  |  | 17.5 | % |
| Total revenue | $ | 479,317 |  |  | 100.0 | % |  | $ | 1,369,783 |  |  | 100.0 | % |
  (was, 2022-02-01, similarity 0.9682):
[0001408710-22-000018:note_history:33]
| (amount in thousands, except percentages) | Three Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |  | Six Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 224,046 |  |  |  |  | 430,996 |  |  |  |
| Others (1) | 626 |  |  |  |  | 1,078 |  |  |  |
| Total revenue in North America | 224,672 |  |  | 49.5 | % |  | 432,074 |  |  | 48.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Malaysia | 34,546 |  |  |  |  | 80,188 |  |  |  |
| India | 28,865 |  |  |  |  | 28,885 |  |  |  |
| Israel | 27,102 |  |  |  |  | 57,217 |  |  |  |
| Hong Kong | 18,092 |  |  |  |  | 41,598 |  |  |  |
| Japan | 17,309 |  |  |  |  | 37,642 |  |  |  |
| China | 12,563 |  |  |  |  | 26,340 |  |  |  |
| Others | 15,257 |  |  |  |  | 27,510 |  |  |  |
| Total revenue in Asia-Pacific and others | 153,734 |  |  | 33.9 | % |  | 299,380 |  |  | 33.6 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 48,954 |  |  |  |  | 102,730 |  |  |  |
| U.K. | 10,004 |  |  |  |  | 25,315 |  |  |  |
| Germany | 6,253 |  |  |  |  | 12,052 |  |  |  |
| Others | 10,210 |  |  |  |  | 18,915 |  |  |  |
| Total revenue in Europe | $ | 75,421 |  |  | 16.6 | % |  | $ | 159,012 |  |  | 17.9 | % |
| Total revenue | $ | 453,827 |  |  | 100.0 | % |  | $ | 890,466 |  |  | 100.0 | % |

- changed (2022-05-03):
[0001408710-22-000028:note_history:34]
The following table presents revenues by end market:
  (was, 2022-02-01, similarity 0.9808):
[0001408710-22-000018:note_history:34]
The following table presents revenues by end market.

- changed (2022-05-03):
[0001408710-22-000028:note_history:35]
| (amount in thousands, except percentages) | Three Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |
| Optical communications | $ | 440,003 |  |  | 78.0 | % |  | $ | 1,318,087 |  |  | 78.7 | % |
| Lasers, sensors and other | 124,392 |  |  | 22.0 | % |  | 356,263 |  |  | 21.3 | % |
| Total | $ | 564,395 |  |  | 100.0 | % |  | $ | 1,674,350 |  |  | 100.0 | % |
  (was, 2022-02-01, similarity 0.9156):
[0001408710-22-000018:note_history:35]
| (amount in thousands, except percentages) | Three Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |  | Six Months EndedDecember 24, 2021 |  | As a % of TotalRevenues |
| Optical communications | $ | 450,783 |  |  | 79.6 | % |  | $ | 878,084 |  |  | 79.1 | % |
| Lasers, sensors and other | 115,850 |  |  | 20.4 | % |  | 231,871 |  |  | 20.9 | % |
| Total | $ | 566,633 |  |  | 100.0 | % |  | $ | 1,109,955 |  |  | 100.0 | % |

- changed (2022-05-03):
[0001408710-22-000028:note_history:36]
| (amount in thousands, except percentages) | Three Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |
| Optical communications | $ | 361,739 |  |  | 75.5 | % |  | $ | 1,053,496 |  |  | 76.9 | % |
| Lasers, sensors and other | 117,578 |  |  | 24.5 | % |  | 316,287 |  |  | 23.1 | % |
| Total | $ | 479,317 |  |  | 100.0 | % |  | $ | 1,369,783 |  |  | 100.0 | % |
  (was, 2022-02-01, similarity 0.9156):
[0001408710-22-000018:note_history:36]
| (amount in thousands, except percentages) | Three Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |  | Six Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |
| Optical communications | $ | 347,840 |  |  | 76.6 | % |  | $ | 691,757 |  |  | 77.7 | % |
| Lasers, sensors and other | 105,987 |  |  | 23.4 | % |  | 198,709 |  |  | 22.3 | % |
| Total | $ | 453,827 |  |  | 100.0 | % |  | $ | 890,466 |  |  | 100.0 | % |

- changed (2022-05-03):
[0001408710-22-000028:note_history:37]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the nine months ended March 25, 2022:
  (was, 2022-02-01, similarity 0.9507):
[0001408710-22-000018:note_history:37]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the six months ended December 24, 2021:

- changed (2022-05-03):
[0001408710-22-000028:note_history:38]
| (amount in thousands) | ContractAssets |
| Beginning balance, June 25, 2021 | $ | 11,878 |  |
| Revenue recognized | 37,195 |  |
| Amounts collected or invoiced | (35,505) |  |
| Ending balance, March 25, 2022 | $ | 13,568 |  |
  (was, 2022-02-01, similarity 0.9771):
[0001408710-22-000018:note_history:38]
| (amount in thousands) | ContractAssets |
| Beginning balance, June 25, 2021 | $ | 11,878 |  |
| Revenue recognized | 26,241 |  |
| Amounts collected or invoiced | (24,971) |  |
| Ending balance, December 24, 2021 | $ | 13,148 |  |

- changed (2022-05-03):
[0001408710-22-000028:note_history:39]
| (amount in thousands) | ContractLiabilities |
| Beginning balance, June 25, 2021 | $ | 1,680 |  |
| Advance payment received during the period | 4,898 |  |
| Revenue recognized | (4,655) |  |
| Ending balance, March 25, 2022 | $ | 1,923 |  |
  (was, 2022-02-01, similarity 0.9744):
[0001408710-22-000018:note_history:39]
| (amount in thousands) | ContractLiabilities |
| Beginning balance, June 25, 2021 | $ | 1,680 |  |
| Advance payment received during the period | 3,281 |  |
| Revenue recognized | (3,067) |  |
| Ending balance, December 24, 2021 | $ | 1,894 |  |
