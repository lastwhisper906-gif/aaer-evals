# FN MD&A — 0001193125-15-364290


## mdna

[0001193125-15-364290:mdna:1]
[same as prior period, unchanged from 0001193125-15-172043:mdna:1]

[0001193125-15-364290:mdna:2]
[same as prior period, unchanged from 0001193125-15-172043:mdna:2]

[0001193125-15-364290:mdna:3]
[same as prior period, unchanged from 0001193125-15-172043:mdna:3]

[0001193125-15-364290:mdna:4]
|  | • |  | our expectation that the portion of our future revenues attributable to customers in regions outside of North America will increase compared with the portion of those revenues for the three months ended September 25, 2015; |

[0001193125-15-364290:mdna:5]
[same as prior period, unchanged from 0001193125-15-172043:mdna:5]

[0001193125-15-364290:mdna:6]
[same as prior period, unchanged from 0001193125-15-172043:mdna:6]

[0001193125-15-364290:mdna:7]
|  | • |  | our expectation that our fiscal year 2016 selling, general and administrative (SG&A) expenses will increase on an absolute dollar basis and as a percentage of revenue compared to fiscal year 2015; |

[0001193125-15-364290:mdna:8]
|  | • |  | our expectation that, in addition to incremental costs associated with growing our business generally, we will incur additional SG&A expenses as a result of expanding our business operations in the United States; |

[0001193125-15-364290:mdna:9]
[same as prior period, unchanged from 0001193125-15-172043:mdna:9]

[0001193125-15-364290:mdna:10]
[same as prior period, unchanged from 0001193125-15-172043:mdna:10]

[0001193125-15-364290:mdna:11]
[same as prior period, unchanged from 0001193125-15-172043:mdna:11]

[0001193125-15-364290:mdna:12]
[same as prior period, unchanged from 0001193125-15-172043:mdna:12]

[0001193125-15-364290:mdna:13]
[same as prior period, unchanged from 0001193125-15-172043:mdna:13]

[0001193125-15-364290:mdna:14]
[same as prior period, unchanged from 0001193125-15-172043:mdna:14]

[0001193125-15-364290:mdna:15]
[same as prior period, unchanged from 0001193125-15-172043:mdna:15]

[0001193125-15-364290:mdna:16]
[same as prior period, unchanged from 0001193125-15-172043:mdna:16]

[0001193125-15-364290:mdna:17]
[same as prior period, unchanged from 0001193125-15-172043:mdna:17]

[0001193125-15-364290:mdna:18]
[same as prior period, unchanged from 0001193125-15-172043:mdna:18]

[0001193125-15-364290:mdna:19]
[same as prior period, unchanged from 0001193125-15-172043:mdna:19]

[0001193125-15-364290:mdna:20]
[same as prior period, unchanged from 0001193125-15-172043:mdna:20]

[0001193125-15-364290:mdna:21]
We provide advanced optical
packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers (OEMs) of complex products such as optical communication components, modules and sub-systems, industrial lasers, medical
devices, and sensors. We offer a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, complex printed circuit
board assembly, advanced packaging, integration, final assembly, and test. Although, we focus primarily on low-volume production of a wide variety of high complexity products, which we refer to as “low-volume, high-mix”, we also have the
capability to accommodate high-volume production. Based on our experience with, and positive feedback we have received from our customers, we believe we are a global leader in providing these services to the optical communications, industrial
lasers, automotive, medical, and sensors markets.

[0001193125-15-364290:mdna:22]
Our customer base includes companies in complex industries that require advanced
precision manufacturing capabilities such as optical communications, industrial lasers, automotive, and sensors. The products that we manufacture for our OEM customers include selective switching products; tunable transponders and transceivers;
active optical cables; solid state, diode-pumped, gas and fiber lasers; and sensors. In many cases, we are the sole outsourced manufacturing partner used by our customers for the products that we produce for them.

[0001193125-15-364290:mdna:23]
We also design and fabricate application-specific crystals, lenses, prisms, mirrors, laser components, and substrates (collectively referred
to as “customized optics”) and other custom and standard borosilicate, clear fused quartz, and synthetic fused silica glass products (collectively referred to as “customized glass”). We incorporate our customized optics and glass
into many of the products we manufacture for our OEM customers, and we also sell customized optics and glass in the merchant market.

[0001193125-15-364290:mdna:24]
China Flooding

[0001193125-15-364290:mdna:25]
During the week of August 10, 2015, our subsidiary in China temporarily suspended production in its manufacturing facility due to
flooding caused by Typhoon Soudelor. The subsidiary resumed operations on August 15, 2015. During the three months ended September 25, 2015, we recognized $0.9 million of losses incurred from the event in the unaudited condensed
consolidated statements of operations and comprehensive income and submitted claims to our insurers for inventory and equipment losses attributable to the effects of the flooding.

[0001193125-15-364290:mdna:26]
A number of exclusions and limitations in the insurance policies (such as coinsurance, facilities location sub-limits and policy covenants)
may reduce the aggregate amount that we will ultimately recover from our insurers. Based on the information that we have at this time, we believe that we will ultimately recover a majority of our losses.

[0001193125-15-364290:mdna:27]
The following is a summary of all known losses incurred from this event and recognized in the unaudited condensed consolidated statements of
operations and comprehensive income for the three months ended September 25, 2015.

[0001193125-15-364290:mdna:28]
| (amount in thousands) |  |  |  |
| Loss from inventory |  | $ | 233 |  |
| Repaired costs of equipment |  |  | 567 |  |
| Flood protection and salvage expenses |  |  | 64 |  |
| Total |  | $ | 864 |  |

[0001193125-15-364290:mdna:29]
[same as prior period, unchanged from 0001193125-15-172043:mdna:45]

[0001193125-15-364290:mdna:30]
Our total revenues increased by $27.1 million, or 14.3%, to $216.4 million for the three months ended September 25, 2015, compared with
$189.3 million for the three months ended September 26, 2014. The increase was primarily due to (i) an increase in our customers’ demand for both optical and non-optical communications manufacturing services during the three months
ended September 25, 2015 and (ii) our inability to recognize $13.2 million of consignment revenue during the three months ended September 26, 2014 because of certain consignment revenue recognition issues previously disclosed. We
refer to finished goods held in our warehouse on behalf of our customers as a consignment goods or consignment inventory, and when the finished goods are sold, we refer to the related revenue as consignment revenue.

[0001193125-15-364290:mdna:31]
We believe our ability to expand our relationships with existing customers and attract new
customers is due to a number of factors, including our broad range of complex engineering and manufacturing service offerings, flexible low-cost manufacturing platform, process optimization capabilities, advanced supply chain management, excellent
customer service, and experienced management team. While we expect the prices we charge for our manufactured products to decrease over time (partly as a result of competitive market forces), we still believe we will be able to maintain favorable
pricing for our services because of our ability to reduce cycle time, adjust our product mix by focusing on more complicated products, improve product quality and yields, and reduce material costs for the products we manufacture. We believe these
capabilities have enabled us to help our OEM customers reduce their manufacturing costs while maintaining or improving the design, quality, reliability, and delivery times for their products.

[0001193125-15-364290:mdna:32]
[same as prior period, unchanged from 0001193125-15-172043:mdna:48]

[0001193125-15-364290:mdna:33]
[same as prior period, unchanged from 0001193125-15-172043:mdna:49]

[0001193125-15-364290:mdna:34]
The percentage of our revenues generated from a bill-to location outside of North America decreased from 51.9% in the three months ended
September 26, 2014 to 50.8% in the three months ended September 25, 2015, primarily because of a decrease in sales to our customers in the Asia-Pacific region. We expect that the portion of our future revenues attributable to customers in
regions outside North America will decrease as compared with the three months ended September 25, 2015.

[0001193125-15-364290:mdna:35]
The following table presents
percentages of total revenues by geographic regions:

[0001193125-15-364290:mdna:36]
|  |  | Three Months Ended |  |
|  |  | September 25,2015 |  |  | September 26,2014 |  |
| North America |  |  | 49.2 | % |  |  | 48.1 | % |
| Asia-Pacific |  |  | 38.8 |  |  |  | 41.1 |  |
| Europe |  |  | 12.0 |  |  |  | 10.8 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-15-364290:mdna:37]
[same as prior period, unchanged from 0001193125-15-172043:mdna:53]

[0001193125-15-364290:mdna:38]
[same as prior period, unchanged from 0001193125-15-172043:mdna:54]

[0001193125-15-364290:mdna:39]
[same as prior period, unchanged from 0001193125-15-172043:mdna:55]

[0001193125-15-364290:mdna:40]
The key components of
our cost of revenues are material costs, employee costs, and infrastructure-related costs. Material costs generally represent the majority of our cost of revenues. Several of the materials we require to manufacture products for our customers are
customized for their products and often sourced from a single supplier or in some cases, our own subsidiaries. Shortages from sole-source suppliers due to yield loss, quality concerns, and capacity constraints, among other factors, may increase our
expenses and negatively impact our gross profit margin or total revenues in a given quarter. Material costs include scrap material. Historically, scrap rate diminishes during a product’s life cycle due to process, fixturing and test
improvement, and optimization.

[0001193125-15-364290:mdna:41]
A second significant element of our cost of revenues is employee costs, including indirect
employee costs related to design, configuration and optimization of manufacturing processes for our customers, quality testing, materials testing and other engineering services; and direct costs related to our manufacturing employees. Direct
employee costs include employee salaries, insurance and benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support
our growth and, to a lesser extent, costs to recruit, train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand and the PRC; the fluctuation of the Thai baht and Chinese Renminbi (RMB) against our
functional currency, the U.S. dollar; and our ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may impact our ability to sustain our competitive advantage
and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention, and asset utilization.

[0001193125-15-364290:mdna:42]
Our infrastructure costs are comprised of depreciation, utilities, facilities management, and overhead costs. Most of our facility leases are
long-term agreements. Our depreciation costs include buildings and fixed assets, primarily at our Pinehurst campus in Thailand, and capital equipment located at each of our manufacturing locations.

[0001193125-15-364290:mdna:43]
During the three months ended September 25, 2015, discretionary merit-based bonus awards were made to our non-executive employees.
Charges included in cost of revenues for bonus distributions to non-executive employees were $0.7 million and $0.6 million for the three months ended September 25, 2015 and September 26, 2014, respectively.

[0001193125-15-364290:mdna:44]
Share-based compensation expense included in cost of revenues was $0.5 million and $0.4 million for the three months ended September 25,
2015 and September 26, 2014, respectively.

[0001193125-15-364290:mdna:45]
We expect to incur significant incremental costs of revenue as a result of our continued
diversification into the industrial lasers, automotive, and sensors markets and other end-markets outside of the optical communications market or our further development of customized optics and glass manufacturing capabilities. We also expect to
incur incremental costs of revenue as a result of our planned expansion into new geographic markets, though we are not able to determine the amount of these incremental expenses.

[0001193125-15-364290:mdna:46]
Selling, General and Administrative Expenses

[0001193125-15-364290:mdna:47]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative, and other support
personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense, and other general expenses not related to cost of
revenues. In fiscal year 2016, we expect our SG&A expenses will increase on an absolute dollar basis and as a percentage of revenue compared with fiscal year 2015 due to the startup expenses of our new manufacturing facility in the United
States.

[0001193125-15-364290:mdna:48]
The compensation committee of our board of directors approved a fiscal year 2016 executive incentive plan with quantitative
objectives, based on achieving certain revenue and non-GAAP earnings per share targets for our fiscal year ending June 24, 2016, as well as qualitative objectives, based on achieving individual performance goals. Bonuses under our fiscal year
2016 executive incentive plan are payable after the end of fiscal year 2016. In fiscal year 2015, the compensation committee approved a fiscal year 2015 executive incentive plan with quantitative objectives, based on achieving certain revenue and
non-GAAP earnings per share targets for our fiscal year ended June 26, 2015, as well as qualitative objectives, based on achieving individual performance goals. In the three months ended September 25, 2015, the compensation committee
awarded bonuses to our executive employees for Company and individual achievements of performance under our fiscal 2015 executive incentive plan. Discretionary merit-based bonus awards were also available to our non-executive employees and were
payable as of September 25, 2015.

[0001193125-15-364290:mdna:49]
Charges included in SG&A expenses for bonus distributions to non-executive and executive
employees were $0.6 million and $0.7 million for the three months ended September 25, 2015 and September 26, 2014, respectively.

[0001193125-15-364290:mdna:50]
Share-based compensation expense included in SG&A expenses was $2.1 million and $1.5 million for the three months ended September 25,
2015 and September 26, 2014, respectively.

[0001193125-15-364290:mdna:51]
In addition to incremental costs associated with growing our business generally, we
expect to incur additional SG&A expenses as a result of expanding our business operations in the United States.

[0001193125-15-364290:mdna:52]
[same as prior period, unchanged from 0001193125-15-172043:mdna:67]

[0001193125-15-364290:mdna:53]
[same as prior period, unchanged from 0001193125-15-172043:mdna:68]

[0001193125-15-364290:mdna:54]
As a result of
our international operations, we are exposed to foreign exchange risk arising from various currency exposures primarily with respect to the Thai baht. Although a majority of our total revenues is denominated in U.S. dollars, a substantial portion of
our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rates between the Thai baht and the U.S. dollar have fluctuated substantially in recent years and may continue to fluctuate substantially in the
future. We report our financial results in U.S. dollars and our results of operations have been and may continue to be negatively impacted owing to appreciation of the Thai baht against the U.S. dollar. Smaller portions of our expenses are incurred
in a variety of other currencies, including RMB, Canadian dollars, Euros, and Japanese yen, the appreciation of which may also negatively impact our financial results.

[0001193125-15-364290:mdna:55]
In addition, we are exposed to foreign exchange risk in connection with the credit facility and cross currency swap arrangements we entered
into with TMB Bank Public Company Limited (the “Bank”) in May 2011 for the construction of Pinehurst Building 6. The terms of the contract with the Bank provide the following facilities: (1) a term loan facility for up to Thai baht
960 million (equal to $30.0 million) with a fixed interest rate of 5.28% per annum, (2) a hedging facility for currency interest rate swaps with a notional amount of $30.0 million, and (3) a settlement limit of Thai baht
65 million, subject to certain terms and conditions as set forth therein. Borrowings and interest under the term loan have been scheduled to be repaid on a quarterly basis between September 2011 and March 2017. As of September 25, 2015, we
had outstanding borrowings under the term loan facility of $9.0 million. Under the terms of the cross currency swap arrangement amounts drawn in Thai baht were converted to U.S. dollars for repayment by us on a quarterly basis at the floating rate
of 3-month London Interbank Offered Rate (LIBOR) plus 2.8% per annum.

[0001193125-15-364290:mdna:56]
In order to manage the risks arising from fluctuations in
foreign currency exchange rates, we use derivative financial instruments. We may enter into forward exchange currency contracts or put option contracts to help manage currency exposures associated with certain assets and liabilities, primarily
short-term obligations. The forward exchange contracts and put option contracts generally have original maturities of one to eighteen months. All foreign currency exchange contracts are recognized on the unaudited condensed consolidated balance
sheet at fair value. As we do not apply hedge accounting to these instruments, the change in the fair value of the derivatives is recorded in foreign exchange (loss) gain, net on the condensed consolidated statements of operations and comprehensive
income. The gains and losses on our forward exchange contracts and put option contracts generally offset losses and gains on the assets, liabilities, and transactions economically hedged.

[0001193125-15-364290:mdna:57]
We had foreign currency assets and liabilities in Thai baht and RMB as follows:

[0001193125-15-364290:mdna:58]
|  |  | As of September 25, 2015 |  |  | As of June 26, 2015 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 359,333 |  |  | $ | 9,915 |  |  |  | 46.0 |  |  |  | 377,785 |  |  | $ | 11,596 |  |  |  | 51.3 |  |
| RMB |  |  | 74,206 |  |  |  | 11,634 |  |  |  | 54.0 |  |  |  | 67,455 |  |  |  | 11,029 |  |  |  | 48.7 |  |
| Total |  |  |  |  |  | $ | 21,549 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 22,625 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,038,167 |  |  | $ | 28,647 |  |  |  | 84.6 |  |  |  | 860,425 |  |  | $ | 26,410 |  |  |  | 88.8 |  |
| RMB |  |  | 33,139 |  |  |  | 5,195 |  |  |  | 15.4 |  |  |  | 20,461 |  |  |  | 3,347 |  |  |  | 11.2 |  |
| Total |  |  |  |  |  | $ | 33,842 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 29,757 |  |  |  | 100.0 |  |

[0001193125-15-364290:mdna:59]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other
current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and
liabilities denominated in the same currency in accordance with management’s policy. As of September 25, 2015, there were $169.5 million in forward contracts and $11.0 million in put option contracts outstanding on the Thai baht
payables. As of June 26, 2015, there were $41.0 million in put option contracts outstanding on the Thai baht payables.

[0001193125-15-364290:mdna:60]
The RMB
assets represent cash and cash equivalents, accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses and other payables. As of September 25, 2015 and June 26, 2015, we did not
have any selling RMB to U.S. dollar forward or put option contracts.

[0001193125-15-364290:mdna:61]
We have not designated the foreign currency and option contracts as
hedging instruments under the accounting standard for derivatives and hedging. Accordingly, for the three months ended September 25, 2015 and June 26, 2015, we recorded an amount of $12.1 million and $0.4 million, respectively, for the
unrealized loss from the changes in the fair market value of the derivatives in our condensed consolidated statements of operations and comprehensive income.

[0001193125-15-364290:mdna:62]
[same as prior period, unchanged from 0001193125-15-172043:mdna:78]

[0001193125-15-364290:mdna:63]
[same as prior period, unchanged from 0001193125-15-172043:mdna:79]

[0001193125-15-364290:mdna:64]
[same as prior period, unchanged from 0001193125-15-172043:mdna:80]

[0001193125-15-364290:mdna:65]
[same as prior period, unchanged from 0001193125-15-172043:mdna:81]

[0001193125-15-364290:mdna:66]
[same as prior period, unchanged from 0001193125-15-172043:mdna:82]

[0001193125-15-364290:mdna:67]
Under the Exchange Rules, RMB is freely convertible into foreign currencies for current account items, including the distribution of
dividends, interest payments, trade and service-related foreign exchange transactions. However, conversion of RMB for capital account items, such as direct investments, loans, security investments, and repatriation of investments, is still subject
to the approval of SAFE.

[0001193125-15-364290:mdna:68]
Under the Administration Rules, foreign-invested enterprises may only buy, sell, or remit foreign currencies at
banks authorized to conduct foreign exchange business after providing valid commercial documents and relevant supporting documents and, in the case of capital account item transactions, obtaining approval from SAFE. Capital investments by
foreign-invested enterprises outside of the PRC are also subject to limitations, which include approvals by the Ministry of Commerce, SAFE, and the State Development and Reform Commission.

[0001193125-15-364290:mdna:69]
Circular 142 regulates the conversion by a foreign-invested company of foreign currency into RMB by restricting how the converted RMB may be
used. Circular 142 requires that the registered capital of a foreign-invested enterprise settled in RMB converted from foreign currencies may only be used for purposes within the business scope approved by the applicable governmental authority and
may not be used for equity investments within the PRC. In addition, SAFE strengthened its oversight of the flow and use of the registered capital of foreign-invested enterprises settled in RMB converted from foreign currencies. The use of such RMB
capital may not be changed without SAFE’s approval and may not be used to repay RMB loans if the proceeds of such loans have not been used.

[0001193125-15-364290:mdna:70]
[same as prior period, unchanged from 0001193125-15-172043:mdna:86]

[0001193125-15-364290:mdna:71]
[same as prior period, unchanged from 0001193125-15-172043:mdna:87]

[0001193125-15-364290:mdna:72]
[same as prior period, unchanged from 0001193125-15-172043:mdna:88]

[0001193125-15-364290:mdna:73]
[same as prior period, unchanged from 0001193125-15-172043:mdna:89]

[0001193125-15-364290:mdna:74]
[same as prior period, unchanged from 0001193125-15-172043:mdna:90]

[0001193125-15-364290:mdna:75]
Throughout the period of our operations in Thailand, we have generally received income tax and
other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption is currently available to us through June 2020 on income generated from the manufacture of products
at Pinehurst Building 6. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in
Thailand for at least 15 years. Additionally, in December 2011, the Thailand Revenue Department announced a reduction in corporate income tax rates for tax periods beginning on or after January 1, 2012. As a result of the announcement,
corporate income tax rates for our Thai subsidiary were reduced from 23% in fiscal year 2013 to 20% in fiscal year 2014, fiscal year 2015, and fiscal year 2016.

[0001193125-15-364290:mdna:76]
[same as prior period, unchanged from 0001193125-15-172043:mdna:93]

[0001193125-15-364290:mdna:77]
[same as prior period, unchanged from 0001193125-15-172043:mdna:94]

[0001193125-15-364290:mdna:78]
Our critical accounting policies
are disclosed in our Annual Report on Form 10-K for the fiscal year ended June 26, 2015.

[0001193125-15-364290:mdna:79]
[same as prior period, unchanged from 0001193125-15-172043:mdna:96]

[0001193125-15-364290:mdna:80]
[same as prior period, unchanged from 0001193125-15-172043:mdna:97]

[0001193125-15-364290:mdna:81]
| (amount in thousands) |  | Three Months Ended |  |
|  | September 25,2015 |  |  | September 26,2014 |  |
| Revenues |  | $ | 216,433 |  |  | $ | 189,325 |  |
| Cost of revenues |  |  | (190,422 | ) |  |  | (168,819 | ) |
| Gross profit |  |  | 26,011 |  |  |  | 20,506 |  |
| Selling, general and administrative expenses |  |  | (11,900 | ) |  |  | (8,737 | ) |
| Other expenses in relation to flood |  |  | (864 | ) |  |  | — |  |
| Operating income |  |  | 13,247 |  |  |  | 11,769 |  |
| Interest income |  |  | 442 |  |  |  | 374 |  |
| Interest expense |  |  | (402 | ) |  |  | (133 | ) |
| Foreign exchange loss, net |  |  | (10,492 | ) |  |  | (106 | ) |
| Other income |  |  | 103 |  |  |  | 103 |  |
| Income before income taxes |  |  | 2,898 |  |  |  | 12,007 |  |
| Income tax expense |  |  | (1,295 | ) |  |  | (971 | ) |
| Net income |  |  | 1,603 |  |  |  | 11,036 |  |
| Other comprehensive income |  |  | 87 |  |  |  | — |  |
| Net comprehensive income |  | $ | 1,690 |  |  | $ | 11,036 |  |

[0001193125-15-364290:mdna:82]
The following table sets forth a summary of our unaudited condensed consolidated statements of
operations and comprehensive income as a percentage of total revenues for the periods indicated.

[0001193125-15-364290:mdna:83]
|  |  | Three Months Ended |  |
|  |  | September 25,2015 |  |  | September 26,2014 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (88.0 | ) |  |  | (89.2 | ) |
| Gross profit |  |  | 12.0 |  |  |  | 10.8 |  |
| Selling, general and administrative expenses |  |  | (5.5 | ) |  |  | (4.6 | ) |
| Other expenses in relation to flood |  |  | (0.4 | ) |  |  | — |  |
| Operating income |  |  | 6.1 |  |  |  | 6.2 |  |
| Interest income |  |  | 0.2 |  |  |  | 0.2 |  |
| Interest expense |  |  | (0.2 | ) |  |  | (0.1 | ) |
| Foreign exchange loss, net |  |  | (4.9 | ) |  |  | (0.1 | ) |
| Other income |  |  | 0.1 |  |  |  | 0.1 |  |
| Income before income taxes |  |  | 1.3 |  |  |  | 6.3 |  |
| Income tax expense |  |  | (0.6 | ) |  |  | (0.5 | ) |
| Net income |  |  | 0.7 |  |  |  | 5.8 |  |
| Other comprehensive income |  |  | 0.1 |  |  |  | — |  |
| Net comprehensive income |  |  | 0.8 | % |  |  | 5.8 | % |

[0001193125-15-364290:mdna:84]
[same as prior period, unchanged from 0001193125-15-172043:mdna:101]

[0001193125-15-364290:mdna:85]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 25,2015 |  |  | September 26,2014 |  |
| Optical communications |  | $ | 154,762 |  |  | $ | 135,256 |  |
| Lasers, sensors and other |  |  | 61,671 |  |  |  | 54,069 |  |
| Total |  | $ | 216,433 |  |  | $ | 189,325 |  |

[0001193125-15-364290:mdna:86]
[same as prior period, unchanged from 0001193125-15-172043:mdna:103]

[0001193125-15-364290:mdna:87]
Comparison of Three Months Ended September 25, 2015 with Three Months Ended
September 26, 2014

[0001193125-15-364290:mdna:88]
[same as prior period, unchanged from 0001193125-15-172043:mdna:106]

[0001193125-15-364290:mdna:89]
Our total revenues increased by $27.1 million, or 14.3%, to $216.4 million for the three months ended September 25, 2015, compared with
$189.3 million for the three months ended September 26, 2014. This increase was primarily due to (i) an increase in customers’ demand for both optical and non-optical communications manufacturing services during the three months ended
September 25, 2015 and (ii) our inability to recognize $13.2 million of consignment revenue during the three months ended September 26, 2014 because of certain consignment revenue recognition issues previously disclosed. Revenues from
optical communications products represented 71.5% of our total revenues for the three months ended September 25, 2015, compared to 71.4% for the three months ended September 26, 2014.

[0001193125-15-364290:mdna:90]
[same as prior period, unchanged from 0001193125-15-172043:mdna:109]

[0001193125-15-364290:mdna:91]
Our
cost of revenues increased by $21.6 million, or 12.8%, to $190.4 million, or 88.0% of total revenues, for the three months ended September 25, 2015, compared with $168.8 million, or 89.2% of total revenues, for the three months ended
September 26, 2014. The increase in cost of revenues on an absolute dollar basis was primarily due to an increase in sales volume, partially offset by a more favorable product mix. Cost of revenues also included share-based compensation expense
of $0.5 million for the three months ended September 25, 2015, compared with $0.4 million for the three months ended September 26, 2014.

[0001193125-15-364290:mdna:92]
[same as prior period, unchanged from 0001193125-15-172043:mdna:112]

[0001193125-15-364290:mdna:93]
Our gross
profit increased by $5.5 million, or 26.9%, to $26.0 million, or 12.0% of total revenues, for the three months ended September 25, 2015, compared with $20.5 million, or 10.8% of total revenues, for the three months ended September 26,
2014.

[0001193125-15-364290:mdna:94]
The improvement in gross profit margin during the three months ended September 25, 2015,
compared with the three months ended September 26, 2014, was related to a more favorable product mix during the three months ended September 25, 2015.

[0001193125-15-364290:mdna:95]
[same as prior period, unchanged from 0001193125-15-172043:mdna:115]

[0001193125-15-364290:mdna:96]
Our
SG&A expenses increased by $3.2 million, or 36.2%, to $11.9 million, or 5.5% of total revenues, for the three months ended September 25, 2015, compared with $8.7 million, or 4.6% of total revenues, for the three months ended
September 26, 2014. Our SG&A expenses increased in absolute dollars and as a percentage of revenue due primarily to an increase in expenses relating to our new manufacturing facility in the United States of $2.7 million, an increase in
sales and marketing expenses of $0.7 million, and an increase executive salaries and other benefits of $0.4 million. We also recorded share-based compensation charges of $2.1 million for the three months ended September 25, 2015, compared with
$1.5 million for the three months ended September 26, 2014.

[0001193125-15-364290:mdna:97]
Other expenses in relation to flood.

[0001193125-15-364290:mdna:98]
Other expenses in relation to flood for the three months ended September 25, 2015 reflects the impact of the flooding that occurred at our
subsidiary in China in August 2015. It mainly consisted of $0.6 million of repaired cost of equipment and $0.2 million of inventory losses.

[0001193125-15-364290:mdna:99]
[same as prior period, unchanged from 0001193125-15-172043:mdna:123]

[0001193125-15-364290:mdna:100]
Our
operating income increased by $1.5 million to $13.2 million, or 6.1% of total revenues, for the three months ended September 25, 2015, compared with $11.8 million, or 6.2% of total revenues, for the three months ended September 26, 2014.

[0001193125-15-364290:mdna:101]
[same as prior period, unchanged from 0001193125-15-172043:mdna:126]

[0001193125-15-364290:mdna:102]
Our interest income remained flat at $0.4 million, or 0.2% of total revenues, for the three months ended September 25, 2015 and the three
months ended September 26, 2014.

[0001193125-15-364290:mdna:103]
Foreign exchange loss, net.

[0001193125-15-364290:mdna:104]
Our foreign exchange loss, net, increased by $10.4 million, or 4.9% of total revenues, for the three months ended September 25, 2015,
compared with $0.1 million, or 0.1% of total revenues, for the three months ended September 26, 2014. This increase was due to the unrealized losses from changes in the fair value of outstanding derivatives as of September 25, 2015.

[0001193125-15-364290:mdna:105]
[same as prior period, unchanged from 0001193125-15-172043:mdna:128]

[0001193125-15-364290:mdna:106]
Our
interest expense increased by $0.3 million to $0.4 million for the three months ended September 25, 2015, compared with $0.1 million for the three months ended September 26, 2014. This increase was due to an increase in the average balance
of our bank borrowings resulting from the additional drawdown under our revolving loan taken during the third quarter of fiscal year 2015, as well as the amortization of additional deferred debt issuance costs.

[0001193125-15-364290:mdna:107]
[same as prior period, unchanged from 0001193125-15-172043:mdna:130]

[0001193125-15-364290:mdna:108]
We recorded income before income taxes of $2.9 million for the three months ended September 25, 2015, compared with income before income
taxes of $12.0 million for the three months ended September 26, 2014.

[0001193125-15-364290:mdna:109]
[same as prior period, unchanged from 0001193125-15-172043:mdna:132]

[0001193125-15-364290:mdna:110]
Our provision for income tax reflects an effective tax rate of 44.7% for the three months ended September 25, 2015, compared with an
effective tax rate of 8.1% for the three months ended September 26, 2014. The increase was primarily due to the fact that we had lower taxable income during the three months ended September 25, 2015 as compared to the three months ended
September 26, 2014 because of the unrealized losses from the changes in the fair value of derivatives.

[0001193125-15-364290:mdna:111]
[same as prior period, unchanged from 0001193125-15-172043:mdna:135]

[0001193125-15-364290:mdna:112]
We recorded net income of $1.6 million, or 0.7% of total revenues, for the three months ended September 25, 2015, compared with $11.0
million, or 5.8% of total revenues, for the three months ended September 26, 2014.

[0001193125-15-364290:mdna:113]
[same as prior period, unchanged from 0001193125-15-172043:mdna:138]

[0001193125-15-364290:mdna:114]
We recorded other comprehensive income of $0.1 million related to net unrealized gain on available-for-sale investments for the three months
ended September 25, 2015.

[0001193125-15-364290:mdna:115]
[same as prior period, unchanged from 0001193125-15-172043:mdna:140]

[0001193125-15-364290:mdna:116]
[same as prior period, unchanged from 0001193125-15-172043:mdna:141]

[0001193125-15-364290:mdna:117]
We
primarily finance our operations through cash flow from operations. As of September 25, 2015 and September 26, 2014, we had cash, cash equivalents, and marketable securities of $247.6 million and $244.7 million, respectively, and
outstanding debt of $39.0 million and $15.0 million, respectively.

[0001193125-15-364290:mdna:118]
Our cash and cash equivalents, which primarily consist of cash on
hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents for the three months ended
September 25, 2015 and September 26, 2014 was 1.0% and 0.6%, respectively.

[0001193125-15-364290:mdna:119]
[same as prior period, unchanged from 0001193125-15-172043:mdna:144]

[0001193125-15-364290:mdna:120]
As of
September 25, 2015, we had a short-term borrowing of $30.0 million under our Facility Agreement in order to purchase land and a building in the United States. In addition to better manage our cash on hand, we invested in short-term marketable
securities of $152.1 million.

[0001193125-15-364290:mdna:121]
We believe that our current cash and cash equivalents, marketable securities, cash flow from operations,
and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss
in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001193125-15-364290:mdna:122]
We believe that our current manufacturing capacity, including our
new facility in the United States, is sufficient to meet our anticipated production requirements for at least the next 12 months. We maintain a long-term credit facility associated with construction of production facilities at our Pinehurst campus
in Thailand that will come due within the next 18 months. We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay this obligation.

[0001193125-15-364290:mdna:123]
[same as prior period, unchanged from 0001193125-15-172043:mdna:149]

[0001193125-15-364290:mdna:124]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 25,2015 |  |  | September 26,2014 |  |
| Net cash provided by operating activities |  | $ | 4,539 |  |  | $ | 15,833 |  |
| Net cash used in investing activities |  | $ | (20,402 | ) |  | $ | (1,464 | ) |
| Net cash used in financing activities |  | $ | (1,184 | ) |  | $ | (3,257 | ) |
| Net (decrease) increase in cash and cash equivalents |  | $ | (17,047 | ) |  | $ | 11,112 |  |
| Cash and cash equivalent, beginning of period |  | $ | 112,978 |  |  | $ | 233,477 |  |
| Cash and cash equivalents, end of period |  | $ | 95,465 |  |  | $ | 244,683 |  |

[0001193125-15-364290:mdna:125]
[same as prior period, unchanged from 0001193125-15-172043:mdna:151]

[0001193125-15-364290:mdna:126]
Net cash provided by operating activities decreased by $11.3 million, or 71.3%, to $4.5 million for the three months ended September 25,
2015, compared with net cash provided by operating activities of $15.8 million for the three months ended September 26, 2014. This decrease was due to a number of factors, including an increase in the changes in inventory of $8.5 million to
support customer demands in the subsequent quarter and a decrease in changes in accounts payable of $3.8 million, offset by an increase in collections from customers of $1.8 million.

[0001193125-15-364290:mdna:127]
[same as prior period, unchanged from 0001193125-15-172043:mdna:153]

[0001193125-15-364290:mdna:128]
Net cash used in investing activities increased by $18.9 million, or 1,293.6%, to $20.4 million for the three months ended September 25,
2015, compared with net cash used in investing activities of $1.5 million for the three months ended September 26, 2014. This increase was primarily due to a net increase of $9.6 million in available-for-sale securities and an increase of $6.9
million in purchase of property, plant, and equipment primarily to support our manufacturing operations in the United States, as well as a $2.4 million deposit toward the purchase of land for a new manufacturing campus in Thailand.

[0001193125-15-364290:mdna:129]
[same as prior period, unchanged from 0001193125-15-172043:mdna:155]

[0001193125-15-364290:mdna:130]
Net
cash used in financing activities decreased by $2.1 million, or 63.6%, to $1.2 million for the three months ended September 25, 2015, compared with net cash used in financing activities of $3.3 million for the three months ended
September 26, 2014. This decrease was primarily due to an increase of $1.5 million in proceeds from the issuance of ordinary shares under employee share option plans and a decrease of $1.2 million in the payment of debt issuance costs under our
credit facility agreement, offset by an increase of $0.7 million in withholding taxes related to net share settlement of restricted share units.

[0001193125-15-364290:mdna:131]
[same as prior period, unchanged from 0001193125-15-172043:mdna:157]

[0001193125-15-364290:mdna:132]
[same as prior period, unchanged from 0001193125-15-172043:mdna:158]

[0001193125-15-364290:mdna:133]
[same as prior period, unchanged from 0001193125-15-172043:mdna:159]

[0001193125-15-364290:mdna:134]
[same as prior period, unchanged from 0001193125-15-172043:mdna:160]
