# FN notes — 0001193125-15-364290


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-15-364290:notes:1]
| 8. | Intangibles |

[0001193125-15-364290:notes:2]
The following tables present details of the Company’s
 intangibles:

[0001193125-15-364290:notes:3]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net |  |
| As of September 25, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 3,425 |  |  | $ | (3,230 | ) |  | $ | 195 |  |
| Total intangibles |  | $ | 3,425 |  |  | $ | (3,230 | ) |  | $ | 195 |  |

[0001193125-15-364290:notes:4]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net |  |
| As of June 26, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 3,357 |  |  | $ | (3,220 | ) |  | $ | 137 |  |
| Total intangibles |  | $ | 3,357 |  |  | $ | (3,220 | ) |  | $ | 137 |  |

[0001193125-15-364290:notes:5]
The Company recorded amortization expense relating to intangibles
 of $0.01 million and $0.02 million for the three months ended
 September 25, 2015 and September 26, 2014,
 respectively.

[0001193125-15-364290:notes:6]
Based on the carrying amount of intangibles as of
 September 25, 2015, and assuming no future impairment of the
 underlying assets, the estimated future amortization at the end of
 each fiscal year in June is as follows:

[0001193125-15-364290:notes:7]
| (amount in thousands) |  |  |  |
| 2016 |  | $ | 53 |  |
| 2017 |  |  | 37 |  |
| 2018 |  |  | 36 |  |
| 2019 |  |  | 36 |  |
| 2020 |  |  | 32 |  |
| Thereafter |  |  | 1 |  |
| Total |  | $ | 195 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-15-364290:notes:8]
The Company operates primarily in three geographic regions: North
 America, Asia-Pacific and Europe. The following table presents
 total revenues by geographic regions:

[0001193125-15-364290:notes:9]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 25, 2015 |  |  | September 26, 2014 |  |
| North America |  | $ | 106,443 |  |  | $ | 91,043 |  |
| Asia-Pacific |  |  | 83,890 |  |  |  | 77,802 |  |
| Europe |  |  | 26,100 |  |  |  | 20,480 |  |
|  |  | $ | 216,433 |  |  | $ | 189,325 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-15-364290:notes:10]
[same as prior period, unchanged from 0001193125-15-172043:notes:90]

[0001193125-15-364290:notes:11]
| (amount in thousands) |  | As of September 25, 2015 |  |  | As of June 26, 2015 |  |
| Raw materials |  | $ | 53,372 |  |  | $ | 46,065 |  |
| Work in progress |  |  | 72,294 |  |  |  | 69,174 |  |
| Finished goods |  |  | 15,318 |  |  |  | 11,843 |  |
| Goods in transit |  |  | 5,503 |  |  |  | 6,488 |  |
|  |  |  | 146,487 |  |  |  | 133,570 |  |
| Less: Inventory obsolescence |  |  | (3,107 | ) |  |  | (2,957 | ) |
| Inventory, net |  | $ | 143,380 |  |  | $ | 130,613 |  |


## us-gaap:DebtDisclosureTextBlock

[0001193125-15-364290:notes:12]
| 9. | Borrowings |

[0001193125-15-364290:notes:13]
The Company’s total borrowing, including revolving and
 long-term borrowings, consisted of the following:

[0001193125-15-364290:notes:14]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  | As of September 25, 2015 |  |  | As of June 26, 2015 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  | October 2015(2) |  | $ | 30,000 |  |  | $ | 30,000 |  |
| Current portion of long-term borrowing |  |  |  |  | 6,000 |  |  |  | 6,000 |  |
|  |  |  |  |  |  | $ | 36,000 |  |  | $ | 36,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | March 2017 |  | $ | 9,000 |  |  | $ | 10,500 |  |
| Less: Current portion |  |  |  |  |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  |  |  |  | $ | 3,000 |  |  | $ | 4,500 |  |

[0001193125-15-364290:notes:15]
| (1) | LIBOR is London Interbank Offered Rate. |

[0001193125-15-364290:notes:16]
| (2) | On October 16, 2015, the maturity date of this revolving borrowing was extended to November 23, 2015. |

[0001193125-15-364290:notes:17]
Under the long-term borrowing contract of a subsidiary, the loan is
 secured by certain property, plant and equipment. The carrying
 amount of assets secured and pledged as collateral as of
 September 25, 2015 and June 26, 2015 was $49.4 million
 and $50.0 million, respectively. This subsidiary is also required
 to comply with the maximum ratios of debt to equity and minimum
 levels of debt service coverage ratios, and Fabrinet must maintain
 an effective shareholding ratio. The carrying amounts of bank
 borrowings approximate their fair value.

[0001193125-15-364290:notes:18]
As of September 25, 2015 and June 26, 2015, the Company
 was in compliance with its long-term bank borrowing agreement. In
 addition to financial ratios, certain of the Company’s credit
 facilities include customary events of default.

[0001193125-15-364290:notes:19]
The movements of long-term loans were as follows for the three
 months ended September 25, 2015 and September 26,
 2014:

[0001193125-15-364290:notes:20]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 25, 2015 |  |  | September 26, 2014 |  |
| Opening net book amount |  | $ | 10,500 |  |  | $ | 16,500 |  |
| Repayment during the period |  |  | (1,500 | ) |  |  | (1,500 | ) |
| Closing net book amount |  | $ | 9,000 |  |  | $ | 15,000 |  |

[0001193125-15-364290:notes:21]
As of September 25, 2015, future maturities of long-term debt
 were as follows at the end of each fiscal year below:

[0001193125-15-364290:notes:22]
| (amount in thousands) |  |  |  |
| 2016 |  | $ | 4,500 |  |
| 2017 |  |  | 4,500 |  |
| Total |  | $ | 9,000 |  |

[0001193125-15-364290:notes:23]
Credit facilities:

[0001193125-15-364290:notes:24]
Fabrinet entered into a syndicated senior credit facility agreement
 (the “Facility Agreement”) with a consortium of banks
 on May 22, 2014. The Facility Agreement, led by Bank of
 America, provides for a $200.0 million credit line, comprised of a
 $150.0 million revolving loan facility and a $50.0 million delayed
 draw term loan facility. The revolving loan facility contains an
 accordion feature permitting Fabrinet to request an increase in the
 facility up to $100.0 million subject to customary terms and
 conditions and provided that no default or event of default exists
 at the time of request. The revolving loan facility terminates and
 all amounts outstanding are due and payable in full on May 22,
 2019. The principal amount of any drawn term loans must be repaid
 according to the scheduled quarterly amortization payments, with
 final payment of all amounts outstanding, plus accrued interest,
 being due May 22, 2019.

[0001193125-15-364290:notes:25]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allows the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. As of
 September 25, 2015, the outstanding revolving borrowing under
 the Facility Agreement was $30.0 million, resulting in available
 credit facilities of $170.0 million. Borrowings under the revolving
 credit facility are classified as current liabilities in the
 unaudited condensed consolidated balance sheet as the Company has
 the periodic option to renew, or pay all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. On October 16, 2015, the
 Company sent a notice to the bank to renew the maturity date of
 this revolving borrowing. The bank approved the notice and extended
 the maturity date to November 23, 2015.

[0001193125-15-364290:notes:26]
Loans under the Facility Agreement bear interest, at
 Fabrinet’s option, at a rate per annum equal to a LIBOR rate
 plus a spread of 1.75% to 2.50%, or a base rate plus a spread of
 0.75% to 1.50%, determined in accordance with the Facility
 Agreement in each case with such spread determined based on
 Fabrinet’s consolidated total leverage ratio for the
 preceding four fiscal quarter period. Interest is due and payable
 quarterly in arrears for loans bearing interest at the base rate
 and at the end of an interest period (or at each three-month
 interval in the case of loans with interest periods greater than
 three months) in the case of loans bearing interest at the LIBOR
 rate.

[0001193125-15-364290:notes:27]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or
 the equivalent under the local law, can be effected. The Facility
 Agreement contains customary affirmative and negative covenants.
 Negative covenants include, among other things, limitations on
 liens, indebtedness, investments, mergers, sales of assets, changes
 in the nature of the business, dividends and distributions,
 affiliate transactions and capital expenditures. The Facility
 Agreement contains financial covenants requiring Fabrinet to
 maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage
 ratio of not more than 2.50:1.00; and (iv) a minimum quick
 ratio of not less than 1.10:1.00. Each of these financial covenants
 is calculated on a consolidated basis for the consecutive four
 fiscal quarter period then ended. As of September 25, 2015,
 the Company was in compliance with all covenants under the Facility
 Agreement.

[0001193125-15-364290:notes:28]
The Facility Agreement also contains customary events of default
 including, among other things, payment defaults, breaches of
 covenants or representations and warranties, cross-defaults with
 certain other indebtedness, bankruptcy and insolvency events and
 change in control of Fabrinet, subject to grace periods in certain
 instances. Upon an event of default, the lenders may terminate
 their commitments, declare all or a portion of the outstanding
 obligations payable by Fabrinet to be immediately due and payable
 and exercise other rights and remedies provided for under the
 Facility Agreement.

[0001193125-15-364290:notes:29]
Fabrinet intends to use the proceeds of the credit line to finance
 its future manufacturing buildings in the United States and
 Thailand, and for general corporate purposes including mergers and
 acquisitions of complementary manufacturing businesses or
 technology, although Fabrinet has no current commitments with
 respect to any such acquisitions.

[0001193125-15-364290:notes:30]
Undrawn available credit facilities classified by available period
 of future borrowing as of September 25, 2015 and June 26,
 2015 were as follows:

[0001193125-15-364290:notes:31]
| (amount in thousands) |  | September 25, 2015 |  |  | June 26, 2015 |  |
| Short-term |  | $ | 1,380 |  |  | $ | 1,480 |  |
| Long-term |  | $ | 170,000 |  |  | $ | 170,000 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-15-364290:notes:32]
| 11. | Share-based compensation |

[0001193125-15-364290:notes:33]
[same as prior period, unchanged from 0001193125-15-172043:notes:120]

[0001193125-15-364290:notes:34]
[same as prior period, unchanged from 0001193125-15-172043:notes:121]

[0001193125-15-364290:notes:35]
The effect of recording share-based compensation expense for the
 three months ended September 25, 2015 and September 26,
 2014 was as follows:

[0001193125-15-364290:notes:36]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 25, 2015 |  |  | September 26, 2014 |  |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |  |
| Share options |  | $ | 16 |  |  | $ | 120 |  |
| Restricted share units |  |  | 2,657 |  |  |  | 1,747 |  |
| Total share-based compensation expense |  |  | 2,673 |  |  |  | 1,867 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 2,673 |  |  | $ | 1,867 |  |

[0001193125-15-364290:notes:37]
Share-based compensation expense was recorded in the condensed
 consolidated statements of operations and comprehensive income as
 follows:

[0001193125-15-364290:notes:38]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 25, 2015 |  |  | September 26, 2014 |  |
| Cost of revenue |  | $ | 537 |  |  | $ | 368 |  |
| Selling, general and administrative expense |  |  | 2,136 |  |  |  | 1,499 |  |
| Total share-based compensation expense |  | $ | 2,673 |  |  | $ | 1,867 |  |

[0001193125-15-364290:notes:39]
The Company did not capitalize any share-based compensation expense
 as part of any asset costs during the three months ended
 September 25, 2015 and September 26, 2014.

[0001193125-15-364290:notes:40]
[same as prior period, unchanged from 0001193125-15-172043:notes:123]

[0001193125-15-364290:notes:41]
Share options have been granted to directors and employees. As of
 September 25, 2015, there were 1,860 share options outstanding
 under Fabrinet’s Amended and Restated 1999 Share Option Plan
 (the “1999 Plan”). Additional option grants may not be
 made under the 1999 Plan.

[0001193125-15-364290:notes:42]
As of September 25, 2015, there were an aggregate of 691,187
 share options outstanding, 1,347,862 restricted share units
 outstanding, and 2,492,055 ordinary shares available for future
 grant under Fabrinet’s 2010 Performance Incentive Plan (the
 “2010 Plan”). The 1999 Plan and 2010 Plan are
 collectively referred to as the “Share Option
 Plans”.

[0001193125-15-364290:notes:43]
[same as prior period, unchanged from 0001193125-15-172043:notes:126]

[0001193125-15-364290:notes:44]
[same as prior period, unchanged from 0001193125-15-172043:notes:127]

[0001193125-15-364290:notes:45]
The following summarizes share option activity:

[0001193125-15-364290:notes:46]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 26, 2015 |  |  | 792,019 |  |  |  | 758,451 |  |  | $ | 16.33 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (98,759 | ) |  |  |  |  |  | $ | 15.67 |  |  |  |  |  |
| Forfeited |  |  | (213 | ) |  |  |  |  |  | $ | 14.43 |  |  |  |  |  |
| Expired |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Balance as of September 25, 2015 |  |  | 693,047 |  |  |  | 680,798 |  |  | $ | 16.42 |  |  |  |  |  |
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 27, 2014 |  |  | 865,890 |  |  |  | 666,305 |  |  | $ | 16.27 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (525 | ) |  |  |  |  |  | $ | 4.25 |  |  |  |  |  |
| Forfeited |  |  | (1,503 | ) |  |  |  |  |  | $ | 17.82 |  |  |  |  |  |
| Expired |  |  | (972 | ) |  |  |  |  |  | $ | 23.29 |  |  |  |  |  |
| Balance as of September 26, 2014 |  |  | 862,890 |  |  |  | 731,906 |  |  | $ | 16.26 |  |  |  |  |  |

[0001193125-15-364290:notes:47]
The following summarizes information for share options outstanding
 as of September 25, 2015 under the Share Option Plans:

[0001193125-15-364290:notes:48]
|  |  | Number of Shares Underlying Options |  |  | Exercise Price Per Share |  |  | Weighted- Average Remaining Contractual Life (years) |  |  | Aggregate Intrinsic Value (amount in thousands) |  |
|  |  |  | 1,860 |  |  | $ | 5.75 |  |  |  | 1.27 |  |  |  |  |  |
|  |  |  | 8,368 |  |  | $ | 13.77 |  |  |  | 1.91 |  |  |  |  |  |
|  |  |  | 356,648 |  |  | $ | 16.83 |  |  |  | 2.05 |  |  |  |  |  |
|  |  |  | 30,000 |  |  | $ | 15.05 |  |  |  | 2.11 |  |  |  |  |  |
|  |  |  | 23,844 |  |  | $ | 25.50 |  |  |  | 2.30 |  |  |  |  |  |
|  |  |  | 7,400 |  |  | $ | 26.16 |  |  |  | 2.36 |  |  |  |  |  |
|  |  |  | 8,300 |  |  | $ | 23.62 |  |  |  | 2.61 |  |  |  |  |  |
|  |  |  | 36,251 |  |  | $ | 15.16 |  |  |  | 2.90 |  |  |  |  |  |
|  |  |  | 191,121 |  |  | $ | 14.12 |  |  |  | 3.13 |  |  |  |  |  |
|  |  |  | 22,760 |  |  | $ | 19.36 |  |  |  | 3.38 |  |  |  |  |  |
|  |  |  | 5,550 |  |  | $ | 18.60 |  |  |  | 3.43 |  |  |  |  |  |
|  |  |  | 945 |  |  | $ | 12.83 |  |  |  | 3.62 |  |  |  |  |  |
| Options outstanding |  |  | 693,047 |  |  |  |  |  |  |  | 2.47 |  |  | $ | 2,085 |  |
| Options exercisable |  |  | 680,798 |  |  |  |  |  |  |  | 2.45 |  |  | $ | 2,036 |  |

[0001193125-15-364290:notes:49]
As of September 25, 2015, there was $0.001 million of
 unrecognized compensation expense related to share options under
 the Share Option Plans that is expected to be recognized over a
 weighted-average period of 0.23 years.

[0001193125-15-364290:notes:50]
[same as prior period, unchanged from 0001193125-15-172043:notes:129]

[0001193125-15-364290:notes:51]
[same as prior period, unchanged from 0001193125-15-172043:notes:130]

[0001193125-15-364290:notes:52]
On May 24, 2015 the Company entered into an amended and
 restated employment agreement with an executive of the Company that
 provides for accelerated vesting of equity awards under certain
 circumstances. Under the agreement, any equity award granted to the
 executive after February 20, 2017, shall vest over a period
 not longer than two years following the applicable grant date. If
 the executive’s employment with the Company continues through
 and including February 20, 2017, any then outstanding equity
 award grants will become 100% vested.

[0001193125-15-364290:notes:53]
The following summarizes restricted share unit activity under the
 2010 Plan:

[0001193125-15-364290:notes:54]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 26, 2015 |  |  | 1,140,927 |  |  | $ | 16.02 |  |
| Granted |  |  | 499,896 |  |  | $ | 19.34 |  |
| Issued |  |  | (286,374 | ) |  | $ | 14.69 |  |
| Forfeited |  |  | (6,587 | ) |  | $ | 18.11 |  |
| Balance as of September 25, 2015 |  |  | 1,347,862 |  |  | $ | 17.09 |  |

[0001193125-15-364290:notes:55]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 27, 2014 |  |  | 762,295 |  |  | $ | 14.23 |  |
| Granted |  |  | — |  |  |  | — |  |
| Issued |  |  | (177,288 | )(1) |  | $ | 13.56 |  |
| Forfeited |  |  | (4,046 | ) |  | $ | 13.73 |  |
| Balance as of September 26, 2014 |  |  | 580,961 |  |  | $ | 14.44 |  |

[0001193125-15-364290:notes:56]
| (1) | Included 283 shares vested on September 24, 2014, but not settled as of September 26, 2014. |

[0001193125-15-364290:notes:57]
As of September 25, 2015, there was $13.7 million of
 unrecognized share-based compensation expense related to restricted
 share units under the 2010 Plan that is expected to be recorded
 over a weighted-average period of 3.17 years.

[0001193125-15-364290:notes:58]
For the three months ended September 25, 2015 and
 September 26, 2014, the Company withheld an aggregate of
 46,016 shares and 10,547 shares, respectively, upon the vesting of
 restricted share units, based upon the closing share price on the
 vesting date to settle the employees’ minimum statutory
 obligation for the applicable income and other employment taxes.
 For the three months ended September 25, 2015 and
 September 26, 2014, the Company then remitted cash of $0.9
 million and $0.2 million, respectively, to the appropriate taxing
 authorities, and presented it in a financing activity within the
 unaudited condensed consolidated statements of cash flows. The
 payment had the effect on shares issued by the Company as it
 reduced the number of shares that would have been issued on the
 vesting date and was recorded as a reduction of additional paid-in
 capital.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-15-364290:notes:59]
| 15. | Business segments and geographic information |

[0001193125-15-364290:notes:60]
Operating segments are defined as components of an enterprise for
 which separate financial information is available that is evaluated
 regularly by the chief operating decision maker in deciding how to
 allocate resources and in assessing performance. The
 Company’s chief operating decision maker is Fabrinet’s
 chief executive officer. As of September 25, 2015 and
 September 26, 2014, the Company operated and internally
 managed a single operating segment. Accordingly, the Company does
 not accumulate discrete information with respect to separate
 product lines and does not have separate reportable segments.

[0001193125-15-364290:notes:61]
[same as prior period, unchanged from 0001193125-15-172043:notes:81]

[0001193125-15-364290:notes:62]
As of September 25, 2015 and September 26, 2014, the
 Company had approximately $33.9 million and $0.2 million of
 long-lived assets based in North America, with the substantial
 remainder of assets based in Asia-Pacific.

[0001193125-15-364290:notes:63]
[same as prior period, unchanged from 0001193125-15-172043:notes:83]

[0001193125-15-364290:notes:64]
The Company had two customers that each contributed to 10% or more
 of its total account receivable as of September 25, 2015 and
 June 26, 2015, respectively.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-15-364290:notes:65]
The following table summarizes the cost and estimated fair value of
 marketable securities classified as available-for-sale securities
 based on stated effective maturities as of September 25,
 2015:

[0001193125-15-364290:notes:66]
| (amount in thousands) |  | Carrying Cost |  |  | Fair Value |  |
| Due within one year |  | $ | 28,323 |  |  | $ | 28,326 |  |
| Due between one to three years |  |  | 123,755 |  |  |  | 123,795 |  |
| Total |  | $ | 152,078 |  |  | $ | 152,121 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001193125-15-364290:notes:67]
[same as prior period, unchanged from 0001193125-15-172043:notes:1]

[0001193125-15-364290:notes:68]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of September 25, 2015 and for the
 three months ended September 25, 2015 and September 26,
 2014 includes only normal recurring adjustments, necessary for a
 fair statement of the financial statements set forth herein, in
 accordance with accounting principles generally accepted in the
 United States of America (“U.S. GAAP”) for interim
 financial information and rules and regulations of the Securities
 and Exchange Commission (“SEC”). Accordingly, such
 information does not include all of the information and footnotes
 required by U.S. GAAP for annual financial statements. For further
 information, please refer to the consolidated financial statements
 and footnotes thereto included in Fabrinet’s Annual Report on
 Form 10-K for the year ended June 26, 2015.

[0001193125-15-364290:notes:69]
The balance sheet as of June 26, 2015 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three months
 ended September 25, 2015 and September 26, 2014 may not
 be indicative of results for the year ending June 24, 2016 or
 any future periods.


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-15-364290:notes:70]
[same as prior period, unchanged from 0001193125-15-172043:notes:140]

[0001193125-15-364290:notes:71]
[same as prior period, unchanged from 0001193125-15-172043:notes:141]

[0001193125-15-364290:notes:72]
[same as prior period, unchanged from 0001193125-15-172043:notes:142]

[0001193125-15-364290:notes:73]
[same as prior period, unchanged from 0001193125-15-172043:notes:143]

[0001193125-15-364290:notes:74]
[same as prior period, unchanged from 0001193125-15-172043:notes:144]

[0001193125-15-364290:notes:75]
[same as prior period, unchanged from 0001193125-15-172043:notes:145]

[0001193125-15-364290:notes:76]
The following table provides details of the financial instruments
 measured at fair value on a recurring basis, including:

[0001193125-15-364290:notes:77]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of September 25, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 8,511 |  |  | $ | — |  |  | $ | 8,511 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 134,532 |  |  |  | — |  |  |  | 134,532 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 15,855 |  |  |  | — |  |  |  | 15,855 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 1,734 |  |  |  | — |  |  |  | 1,734 |  |
| Total |  | $ | — |  |  | $ | 160,632 |  |  | $ | — |  |  | $ | 160,632 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 12,109 | (1) |  | $ | — |  |  | $ | 12,109 |  |
| Total |  | $ | — |  |  | $ | 12,109 |  |  | $ | — |  |  | $ | 12,109 |  |
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 26, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 7,430 |  |  | $ | — |  |  | $ | 7,430 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 120,101 |  |  |  | — |  |  |  | 120,101 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 21,027 |  |  |  | — |  |  |  | 21,027 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 1,738 |  |  |  | — |  |  |  | 1,738 |  |
| Derivative assets |  |  | — |  |  |  | 4 | (2) |  |  | — |  |  |  | 4 |  |
| Total |  | $ | — |  |  | $ | 150,300 |  |  | $ | — |  |  | $ | 150,300 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 371 | (3) |  | $ | — |  |  | $ | 371 |  |
| Total |  | $ | — |  |  | $ | 371 |  |  | $ | — |  |  | $ | 371 |  |

[0001193125-15-364290:notes:78]
| (1) | Foreign currency options with notional amount of $11.0 million and forward contracts with notional amount of $169.5 million, Canadian Dollars 1.0 million and Japanese Yen 0.1 million. |

[0001193125-15-364290:notes:79]
| (2) | Foreign currency options with notional amount of $3.0 million and forward contracts with notional amount of Canadian Dollars 0.4 million. |

[0001193125-15-364290:notes:80]
| (3) | Foreign currency options with notional amount of $41.0 million. |

[0001193125-15-364290:notes:81]
[same as prior period, unchanged from 0001193125-15-172043:notes:146]

[0001193125-15-364290:notes:82]
The Company uses foreign currency contracts to manage the foreign
 exchange risk associated with certain foreign currency-denominated
 assets and liabilities. As a result of foreign currency
 fluctuations, the U.S. dollar equivalent values of the
 Company’s foreign currency-denominated assets and liabilities
 change. The Company minimizes the credit risk in derivative
 instruments by limiting its exposure to any single counterparty and
 by entering into derivative instruments only with counterparties
 that meet the Company’s minimum credit quality standard.

[0001193125-15-364290:notes:83]
The derivative assets and liabilities are classified in other
 current assets and accrued expenses, respectively, on the unaudited
 condensed consolidated balance sheets. As of September 25,
 2015 and June 26, 2015, the forward exchange contracts and
 option contracts outstanding had a maturity in one to eighteen
 months duration. The Company has not designated the foreign
 currency contracts as hedging instruments under the accounting
 standard for derivatives and hedging.

[0001193125-15-364290:notes:84]
The effects of derivative instruments which are not designated as
 hedging instruments on the Company’s unaudited condensed
 consolidated statements of operations and comprehensive income were
 loss from foreign currency forward contracts of $11.3 million
 and put option contracts of $0.8 million for the three months ended
 September 25, 2015, and loss from foreign currency forward
 contracts of $0.01 million and gain from foreign currency put
 option contracts of $0.2 million for the three months ended
 September 26, 2014.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-15-364290:notes:85]
[same as prior period, unchanged from 0001193125-15-172043:notes:48]

[0001193125-15-364290:notes:86]
[same as prior period, unchanged from 0001193125-15-172043:notes:49]

[0001193125-15-364290:notes:87]
The preparation of the Company’s condensed consolidated
 financial statements in conformity with U.S. GAAP requires
 management to make estimates and assumptions that affect the
 reported amounts of assets and liabilities and disclosure of
 contingent liabilities at the date of the financial statements, and
 the reported amount of total revenues and expenses during the year.
 The Company bases estimates on historical experience and various
 assumptions about the future that are believed to be reasonable
 based on available information. The Company’s reported
 financial position or results of operations may be materially
 different under different conditions or when using different
 estimates and assumptions, particularly with respect to significant
 accounting policies, which are discussed below. Significant
 assumptions are used in accounting for share-based compensation,
 allowance for doubtful accounts, income taxes, and inventory
 obsolescence, among others. Due to the inherent uncertainty
 involved in making estimates, actual results reported in future
 periods may be different from these estimates. In the event that
 estimates or assumptions prove to differ from actual results,
 adjustments will be made in subsequent periods to reflect more
 current information.

[0001193125-15-364290:notes:88]
[same as prior period, unchanged from 0001193125-15-172043:notes:51]

[0001193125-15-364290:notes:89]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended
 September 25, 2015 and September 26, 2014 each consisted
 of 13 weeks. Fiscal year 2016 will be comprised of 52 weeks and
 will end on June 24, 2016.

[0001193125-15-364290:notes:90]
[same as prior period, unchanged from 0001193125-15-172043:notes:53]

[0001193125-15-364290:notes:91]
[same as prior period, unchanged from 0001193125-15-172043:notes:54]

[0001193125-15-364290:notes:92]
[same as prior period, unchanged from 0001193125-15-172043:notes:55]

[0001193125-15-364290:notes:93]
[same as prior period, unchanged from 0001193125-15-172043:notes:56]

[0001193125-15-364290:notes:94]
[same as prior period, unchanged from 0001193125-15-172043:notes:59]

[0001193125-15-364290:notes:95]
In August 2015, the Financial Accounting Standards Board
 (“FASB”) issued Accounting Standards Update
 (“ASU”) 2015-15, “Interest – Imputation of
 Interest (Subtopic 835-30): Presentation and Subsequent Measurement
 of Debt Issuance Costs Associated with Line-of-Credit
 Arrangements”. This ASU amended the presentation or
 subsequent measurement of debt issuance costs related to the
 line-of-credit arrangement. The Company is currently evaluating the
 impact of adoption of this update on its consolidated financial
 statements.

[0001193125-15-364290:notes:96]
In August 2015, the FASB issued ASU 2015-14, “Revenue from
 Contracts with Customers (Topic 666): Deferral of the Effective
 Date”. This amendment deferred the effective date of ASU
 2014-09 for all entities by one year. The Company is currently
 evaluating the impact of adoption of this update on its
 consolidated financial statements.

[0001193125-15-364290:notes:97]
In July 2015, the FASB issued ASU 2015-11, “Inventory (Topic
 330): Simplifying the Measurement of Inventory”. The update
 provides the guidance that an entity, that measured inventory by
 using first-in, first-out or average cost, should measure inventory
 at the lower of cost and net realizable value. Net realizable value
 is the estimated selling prices in the ordinary course of business,
 less reasonably predictable costs of completion, disposal, and
 transportation. Subsequent measurement is unchanged for inventory
 measured using last-in, first-out or the retail inventory method.
 The update is effective for fiscal years beginning after
 December 15, 2016, including interim periods within these
 fiscal years. This update should be applied prospectively with
 earlier application permitted as of the beginning of an interim or
 annual reporting date. The Company is currently evaluating the
 impact of adoption of this update on its consolidated financial
 statements.

[0001193125-15-364290:notes:98]
In April 2015, the FASB issued ASU 2015-03, “Interest -
 Imputation of Interest (Subtopic 835-30): Simplifying the
 Presentation of Debt Issuance Costs”. The update requires
 debt issuance costs related to a recognized debt liability be
 presented in the balance sheet as a direct deduction from the
 carrying amount of the related debt liability instead of being
 presented as an asset. Debt disclosures will include the face
 amount of the debt liability and the effective interest rate. The
 update requires retrospective application and represents a change
 in accounting principle. The update is effective for fiscal years
 beginning after December 15, 2015. Early adoption is permitted
 for financial statements that have not been previously issued. The
 Company is currently evaluating the impact of adoption of this
 update on its consolidated financial statements.

[0001193125-15-364290:notes:99]
In February 2015, the FASB issued ASU 2015-02, “Consolidation
 (Topic 810): Amendments to the Consolidation Analysis”. ASU
 No. 2015-02 amended the process that a reporting entity must
 perform to determine whether it should consolidate certain types of
 legal entities. ASU No. 2015-02 is effective for fiscal years,
 and for interim periods within those fiscal years beginning after
 December 15, 2015. Early adoption is permitted, including
 adoption in an interim period. The Company is currently evaluating
 the impact of adoption of this update on its consolidated financial
 statements.

[0001193125-15-364290:notes:100]
In January 2015, the FASB issued ASU No. 2015-01,
 “Income Statement – Extraordinary and Unusual Items
 (Subtopic 225-20): Simplifying Income Statement Presentation by
 Eliminating the Concept of Extraordinary Items”. The
 objective of this amendment is to reduce the complexity in
 accounting standards by eliminating the concept of extraordinary
 items from U.S. GAAP. Presently, an event or transaction is
 presumed to be an ordinary and usual activity of the reporting
 entity unless evidence clearly supports its classification as an
 extraordinary item. The following criteria must both be met for
 extraordinary classification: (a) the underlying event or
 transaction should possess a high degree of abnormality and be of a
 type clearly unrelated to, or only incidentally related to, the
 ordinary and typical activities of the entity; and (b) the
 underlying event or transaction should not reasonably be expected
 to recur in the foreseeable future. This amendment is effective for
 fiscal years and interim periods beginning after December 15,
 2015. Early adoption is permitted provided that the guidance is
 applied from the beginning of the fiscal year of adoption. The
 Company does not expect that the adoption of this update will have
 an effect on its consolidated financial statements.

[0001193125-15-364290:notes:101]
In August 2014, the FASB issued ASU No. 2014-15,
 “Presentation of Financial Statements – Going Concern
 (Subtopic 205-40): Disclosure of Uncertainties about an
 Entity’s Ability to Continue as a Going Concern”. The
 amendments require management to evaluate, for each annual and
 interim reporting period, an entity’s ability to continue as
 a going concern when relevant conditions and events, considered in
 the aggregate, indicate that it is probable that the entity will be
 unable to meet its obligations that become due within one year
 after the date that the financial statements are issued (or
 available to be issued). This ASU is effective for annual periods
 and interim reporting periods beginning after December 15,
 2016. The Company does not expect that the adoption of this update
 will have an effect on its consolidated financial statements.

[0001193125-15-364290:notes:102]
In June 2014, the FASB issued ASU No. 2014-12,
 “Compensation – Stock Compensation (Topic 718):
 Accounting for Share-Based
 Payments When the Terms of an Award Provide That a Performance
 Target Could Be Achieved After the Requisite Service Period”.
 This ASU requires that a performance target that affects vesting,
 and that could be achieved after the requisite service period, be
 treated as a performance condition. As such, the performance target
 should not be reflected in estimating the grant date fair value of
 the award. This update further clarifies that compensation cost
 should be recognized in the period in which it becomes probable
 that the performance target will be achieved and should represent
 the compensation cost attributable to the period(s) for which the
 requisite service has already been rendered. This update is
 required to be adopted by all public companies for annual periods
 and interim reporting periods beginning after December 15,
 2015. Early adoption of this ASU is permitted. The Company is
 currently evaluating the impact of adoption of this update on its
 consolidated financial statements.

[0001193125-15-364290:notes:103]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue
 from Contracts with Customers (Topic 606), issued as a new Topic,
 Accounting Standards Codification”. The core principle of
 this amendment is that an entity should recognize revenue to depict
 the transfer of promised goods or services to customers in an
 amount that reflects the consideration to which the entity expects
 to be entitled in exchange for those goods or services. This ASU is
 effective for annual reporting periods beginning after
 December 15, 2016, including interim periods within that
 reporting period, with earlier adoption not being permitted. This
 ASU can be adopted either retrospectively to each prior reporting
 period presented or as a cumulative-effect adjustment as of the
 date of adoption. The Company is currently evaluating the impact of
 adoption of this update on its consolidated financial
 statements.


## us-gaap:ScheduleOfOtherNonoperatingIncomeExpenseTableTextBlock

[0001193125-15-364290:notes:104]
The following is a summary of all known losses incurred from this
 event and recognized in the unaudited condensed consolidated
 statements of operations and comprehensive income for the three
 months ended September 25, 2015.

[0001193125-15-364290:notes:105]
| (amount in thousands) |  |  |  |
| Loss from inventory |  | $ | 233 |  |
| Repaired costs of equipment |  |  | 567 |  |
| Flood protection and salvage expenses |  |  | 64 |  |
| Total |  | $ | 864 |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-15-364290:notes:106]
[same as prior period, unchanged from 0001193125-15-172043:notes:39]

[0001193125-15-364290:notes:107]
[same as prior period, unchanged from 0001193125-15-172043:notes:40]

[0001193125-15-364290:notes:108]
|  |  | Three Months Ended |  |
| (amount in thousands except per share amounts) |  | September 25, 2015 |  |  | September 26, 2014 |  |
| Net income attributable to shareholders |  | $ | 1,603 |  |  | $ | 11,036 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  | 35,579 |  |  |  | 35,230 |  |
| Incremental shares arising from the assumed exercise of share options and vesting of restricted share units (thousands of shares) |  |  | 736 |  |  |  | 357 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 36,315 |  |  |  | 35,587 |  |
| Basic earnings per ordinary share |  | $ | 0.05 |  |  | $ | 0.31 |  |
| Diluted earnings per ordinary share |  | $ | 0.04 |  |  | $ | 0.31 |  |
| Outstanding share options excluded in the computation of diluted earnings per ordinary share (1) |  |  | 62,304 |  |  |  | 645,450 |  |

[0001193125-15-364290:notes:109]
| (1) | These share options were not included in the computation of diluted earnings per ordinary share for three months ended September 25, 2015 and September 26, 2014, respectively, because the exercise price of the options was greater than the average market price of the underlying shares. |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-15-364290:notes:110]
| 13. | Accumulated other comprehensive income |

[0001193125-15-364290:notes:111]
The changes in accumulated other comprehensive income, net of tax,
 for the three months ended September 25, 2015 were as
 follows:

[0001193125-15-364290:notes:112]
| (amount in thousands) |  | Unrealized (Loss)/Gain on Marketable Securities |  |
| Balance as of June 26, 2015 |  | $ | (44 | ) |
| Other comprehensive income before reclassification adjustment |  |  | (18 | ) |
| Less: Reclassification adjustment for net income realized and included in other expense in net income |  |  | 105 |  |
| Net current-period other comprehensive income |  | $ | 87 |  |
| Balance as of September 25, 2015 |  | $ | 43 |  |


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001193125-15-364290:notes:113]
[same as prior period, unchanged from 0001193125-15-172043:notes:66]

[0001193125-15-364290:notes:114]
The Company’s cash, cash equivalents,
 and marketable securities can be analyzed as follows:

[0001193125-15-364290:notes:115]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Gain |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of September 25, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | — |  |  | $ | — |  |  | $ | 86,954 |  |  | $ | — |  |
| Cash equivalents |  |  | 8,511 |  |  |  | — |  |  |  | 8,511 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 134,507 |  |  |  | 25 |  |  |  | — |  |  |  | 134,532 |  |
| U.S. agency and U.S. treasury securities |  |  | 15,839 |  |  |  | 16 |  |  |  | — |  |  |  | 15,855 |  |
| Sovereign and municipal securities |  |  | 1,732 |  |  |  | 2 |  |  |  | — |  |  |  | 1,734 |  |
| Total |  | $ | 160,589 |  |  | $ | 43 |  |  | $ | 95,465 |  |  | $ | 152,121 |  |
|  |  |  |  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized (Loss)/Gain |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of June 26, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | — |  |  | $ | — |  |  | $ | 105,548 |  |  | $ | — |  |
| Cash equivalents |  |  | 7,430 |  |  |  | — |  |  |  | 7,430 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 120,144 |  |  |  | (43 | ) |  |  | — |  |  |  | 120,101 |  |
| U.S. agency and U.S. treasury securities |  |  | 21,029 |  |  |  | (2 | ) |  |  | — |  |  |  | 21,027 |  |
| Sovereign and municipal securities |  |  | 1,737 |  |  |  | 1 |  |  |  | — |  |  |  | 1,738 |  |
| Total |  | $ | 150,340 |  |  | $ | (44 | ) |  | $ | 112,978 |  |  | $ | 142,866 |  |

[0001193125-15-364290:notes:116]
All highly liquid investments with original maturities of three
 months or less at the date of purchase are classified as cash
 equivalents. Management determines the appropriate classification
 of its investments at the time of purchase and reevaluates the
 designations at each balance sheet date. The Company may sell
 certain of its marketable securities prior to their stated
 maturities for strategic reasons including, but not limited to,
 anticipation of credit deterioration and duration management. The
 maturities of the Company’s marketable securities generally
 range from three months to three years. The Company’s
 investments in marketable securities consist of investments in U.S.
 Treasuries and fixed income securities and have been classified and
 accounted for as available-for-sale.

[0001193125-15-364290:notes:117]
During the three months ended September 25, 2015, the net
 realized loss recognized by the Company was $0.1 million.

[0001193125-15-364290:notes:118]
As of September 25, 2015, the Company considered the declines
 in market value of its marketable securities investment portfolio
 to be temporary in nature and did not consider any of its
 securities other-than-temporarily impaired. The Company typically
 invests in highly-rated securities, and its investment policy
 generally limits the amount of credit exposure to any one issuer.
 The policy requires investments generally to be investment grade,
 with the primary objective of minimizing the potential risk of
 principal loss. Fair values were determined for each individual
 security in the investment portfolio. When evaluating an investment
 for other-than-temporary impairment, the Company reviews factors
 such as the length of time and extent to which fair value has been
 below its cost basis, the financial condition of the issuer and any
 changes thereto, changes in market interest rates, and the
 Company’s intent to sell, or whether it is more likely than
 not it will be required to sell, the investment before recovery of
 the investment’s cost basis. No impairment losses were
 recorded for the three months ended September 25, 2015.

[0001193125-15-364290:notes:119]
As of September 25, 2015, cash, cash equivalents, and
 marketable securities included bank deposits of $40.0 million held
 in various financial institutions located in the United States in
 order to support the availability of the Facility Agreement (as
 defined in Note 9) and comply with covenants. Under the terms and
 conditions of the Facility Agreement, the Company shall maintain
 cash, cash equivalents and/or marketable securities in an aggregate
 amount not less than $40.0 million in unencumbered deposits, and/or
 securities in accounts located in the United States at all times
 during the term of the Facility Agreement. As discussed in Note 9,
 the Company must comply with this covenant from and after the
 effective date of the Facility Agreement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-15-364290:notes:120]
| 10. | Income taxes |

[0001193125-15-364290:notes:121]
As of September 25, 2015 and June 26, 2015, the liability
 for uncertain tax positions including accrued interest and
 penalties was $1.5 million and $1.6 million, respectively. The
 Company expects the estimated amount of liability associated with
 its uncertain tax positions to decrease within the next
 12 months due to the lapse of the applicable statute of
 limitations in foreign tax jurisdictions.

[0001193125-15-364290:notes:122]
The Company files income tax returns in the United States and
 foreign tax jurisdictions. The tax years from 2011 to 2015 remain
 open to examination by U.S. federal and state tax authorities, and
 foreign tax authorities. The Company’s income tax is
 recognized based on the best estimate of the expected annual
 effective tax rate for the full financial year of each entity in
 the Company, adjusted for discrete items arising in that quarter.
 If the Company’s estimated annual effective tax rate changes,
 the Company makes a cumulative adjustment in that quarter.

[0001193125-15-364290:notes:123]
The effective tax rate for the Company for the three months ended
 September 25, 2015 and September 26, 2014 was 44.7% and
 8.1% of net income, respectively. The increase in the effective tax
 rate for the three months ended September 25, 2015 was
 primarily due to the fact that the Company had lower taxable income
 during the three months ended September 25, 2015 as compared
 to the three months ended September 26, 2014 because of an
 increase in unrealized losses from changes in the fair value of
 derivatives during the three months ended September 25,
 2015.


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001193125-15-364290:notes:124]
| 16. | Other expenses in relation to flood |

[0001193125-15-364290:notes:125]
During the week of August 10, 2015, the Company’s
 subsidiary in China temporarily suspended production in its
 manufacturing facility due to flooding caused by Typhoon Soudelor.
 The subsidiary resumed operations on August 15, 2015. During
 the three months ended September 25, 2015, the Company
 recognized $0.9 million of losses incurred from the event in the
 unaudited condensed consolidated statements of operations and
 comprehensive income and submitted claims to its insurers for
 inventory and equipment losses attributable to the effects of the
 flooding.

[0001193125-15-364290:notes:126]
A number of exclusions and limitations in the insurance policies
 (such as coinsurance, facilities location sub-limits and policy
 covenants) may reduce the aggregate amount that the Company will
 ultimately recover from its insurers. Based on the information that
 the Company has at this time, the Company believes that it will
 ultimately recover a majority of its losses. The Company will
 recognize insurance recoveries if and when they become realizable
 and probable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-15-364290:notes:127]
| 12. | Shareholders’ equity |

[0001193125-15-364290:notes:128]
[same as prior period, unchanged from 0001193125-15-172043:notes:105]

[0001193125-15-364290:notes:129]
[same as prior period, unchanged from 0001193125-15-172043:notes:106]

[0001193125-15-364290:notes:130]
For the three months ended September 25, 2015, Fabrinet issued
 98,759 ordinary shares upon the exercise of options, for cash
 consideration at a weighted-average exercise price of $15.67 per
 share, and 240,358 ordinary shares upon the vesting of restricted
 share units, net of shares withheld.

[0001193125-15-364290:notes:131]
For the three months ended September 26, 2014, Fabrinet issued
 525 ordinary shares upon the exercise of options, for cash
 consideration at a weighted-average exercise price of $4.25 per
 share, and 166,458 ordinary shares upon the vesting of restricted
 share units, net of shares withheld.

[0001193125-15-364290:notes:132]
[same as prior period, unchanged from 0001193125-15-172043:notes:109]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-15-364290:notes:133]
| 14. | Commitments and contingencies |

[0001193125-15-364290:notes:134]
Bank guarantees

[0001193125-15-364290:notes:135]
As of September 25, 2015 and June 26, 2015, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $0.7 million and $0.8 million, respectively.

[0001193125-15-364290:notes:136]
Operating lease commitments

[0001193125-15-364290:notes:137]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, and New Jersey under operating lease arrangements
 that expire in various calendar years through 2020. Rental expense
 under these operating leases amounted to $0.3 million and $0.2
 million for the three months ended September 25, 2015 and
 September 26, 2014, respectively.

[0001193125-15-364290:notes:138]
As of September 25, 2015, the future minimum lease payments
 due under non-cancelable leases were as follows at the end of each
 fiscal year below:

[0001193125-15-364290:notes:139]
| (amount in thousands) |  |  |  |
| 2016 |  | $ | 827 |  |
| 2017 |  |  | 949 |  |
| 2018 |  |  | 948 |  |
| 2019 |  |  | 479 |  |
| 2020 |  |  | 290 |  |
| Total minimum operating lease payments |  | $ | 3,493 |  |

[0001193125-15-364290:notes:140]
Purchase obligations

[0001193125-15-364290:notes:141]
Purchase obligations represent legally-binding commitments to
 purchase inventory and other commitments made in the normal course
 of business to meet operational requirements. Although open
 purchase orders are considered enforceable and legally binding,
 their terms generally give the Company the option to cancel,
 reschedule and/or adjust its requirements based on its business
 needs prior to the delivery of goods or performance of services.
 Obligations to purchase inventory and other commitments are
 generally expected to be fulfilled within one year.

[0001193125-15-364290:notes:142]
As of September 25, 2015, the Company had an outstanding
 commitment to third parties of $4.1 million.

[0001193125-15-364290:notes:143]
Purchase of land

[0001193125-15-364290:notes:144]
On September 2, 2015, the Company entered into an agreement to
 purchase a parcel of land in Chonburi, Thailand, to support the
 expansion of the Company’s production in Thailand. The
 aggregate purchase price is approximately $11.8 million, of which
 $2.4 million has been deposited by the Company into escrow. The
 Company will pay the balance of the purchase price at the close of
 escrow, which is expected to occur on or before December 22,
 2015. The Company recorded this deposit as deposits and non-current
 assets on the unaudited condensed balance sheet as of
 September 25, 2015.

[0001193125-15-364290:notes:145]
Indemnification of directors and officers

[0001193125-15-364290:notes:146]
Cayman Islands law does not limit the extent to which a
 company’s memorandum and articles of association may provide
 for indemnification of directors and officers, except to the extent
 any such provision may be held by the Cayman Islands courts to be
 contrary to public policy, such as to provide indemnification
 against civil fraud or the consequences of committing a crime.
 Fabrinet’s amended and restated memorandum and articles of
 association provide for indemnification of directors and officers
 for actions, costs, charges, losses, damages and expenses incurred
 in their capacities as such, except that such indemnification does
 not extend to any matter in respect of any fraud or dishonesty that
 may attach to any of them.

[0001193125-15-364290:notes:147]
In accordance with Fabrinet’s form of indemnification
 agreement for its directors and officers, Fabrinet has agreed to
 indemnify its directors and officers against certain liabilities
 and expenses incurred by such persons in connection with claims by
 reason of their being such a director or officer. Fabrinet
 maintains a director and officer liability insurance policy that
 may enable it to recover a portion of any future amounts paid under
 the indemnification agreements.


## us-gaap:SubsequentEventsTextBlock

[0001193125-15-364290:notes:148]
| 17. | Subsequent event |

[0001193125-15-364290:notes:149]
Executive officer separation agreement

[0001193125-15-364290:notes:150]
On September 29, 2015, the Company entered into a Separation
 Agreement and Release (the “Separation Agreement”) with
 an executive officer who resigned from the Company effective
 December 31, 2015 (the “Separation Date”). During
 the period from October 1, 2015 through the Separation Date,
 the officer will continue as an employee and provide certain
 transition services. In connection with the Separation Agreement,
 the Company will incur severance expenses of approximately $0.7
 million during the second quarter of fiscal year 2016.

[0001193125-15-364290:notes:151]
Capital expenditure commitment

[0001193125-15-364290:notes:152]
In October 2015, the Company entered into a construction contract
 with local contractor for construction of new manufacturing
 building at the Company’s Chonburi campus. The contract price
 is approximately of $30.4 million.


## us-gaap:ScheduleOfCreditLossesForFinancingReceivablesCurrentTableTextBlock

[0001193125-15-364290:notes:153]
[same as prior period, unchanged from 0001193125-15-172043:notes:95]

[0001193125-15-364290:notes:154]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 25, 2015 |  |  | September 26, 2014 |  |
| Balance, beginning of period |  | $ | 50 |  |  | $ | 37 |  |
| Credited to income |  |  | (4 | ) |  |  | (1 | ) |
| Balance, end of period |  | $ | 46 |  |  | $ | 36 |  |


## fn:AllowanceForDoubtfulAccountsTextBlock

[0001193125-15-364290:notes:155]
[same as prior period, unchanged from 0001193125-15-172043:notes:155]
