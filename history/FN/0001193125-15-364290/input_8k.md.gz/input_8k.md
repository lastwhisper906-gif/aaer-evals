# FN 8-K — 0001193125-15-362448 filed 2015-11-02

## item codes, every 8-K on or before 2015-11-03

- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2015-11-03

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-362448:8k_2_02:1]
EX-99.1
2
d53575dex991.htm
EX-99.1

[0001193125-15-362448:8k_2_02:2]
EX-99.1

[0001193125-15-362448:8k_2_02:3]
Exhibit 99.1

[0001193125-15-362448:8k_2_02:4]
Fabrinet Announces First Quarter Fiscal-Year 2016 Financial Results

[0001193125-15-362448:8k_2_02:5]
BANGKOK, Thailand – November 2, 2015 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical,
electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for the first fiscal quarter, ended September 25, 2015.

[0001193125-15-362448:8k_2_02:6]
Tom Mitchell, Chief Executive Officer of Fabrinet, said, “We are off to a strong start in fiscal 2016 with first quarter revenue and non-GAAP
profitability that exceeded our expectations. In addition to beginning production at our new product introduction and advanced packaging facility in Santa Clara, we recently broke ground on the first building of what will become a second
manufacturing campus in Thailand. We expect this added space to enable us to continue scaling our business as our current facilities reach capacity levels. With overall manufacturing space at our new campus that will ultimately represent a more than
doubling of capacity, we are setting the stage for continued profitable growth as we look ahead.”

[0001193125-15-362448:8k_2_02:7]
First Quarter Fiscal-Year 2016 Financial
Highlights

[0001193125-15-362448:8k_2_02:8]
GAAP Results

[0001193125-15-362448:8k_2_02:9]
|  | • |  | Revenue was $216.4 million for first quarter of fiscal year 2016, an increase of 14% compared to total revenue of $189.3 million for the comparable period in fiscal year 2015. |

[0001193125-15-362448:8k_2_02:10]
|  | • |  | GAAP net income for the first quarter of fiscal year 2016 was $1.6 million, compared to GAAP net income of $11.0 million in the first quarter of fiscal year 2015. The decrease in GAAP net income was primarily due to a $(10.9) million unrealized foreign exchange loss for the mark-to-market adjustment of forward contracts entered into to partially hedge against future variable costs. |

[0001193125-15-362448:8k_2_02:11]
|  | • |  | GAAP net income for the first quarter of fiscal year 2016 was $0.04 per diluted share, compared to GAAP net income of $0.31 per diluted share, in the first quarter of fiscal year 2015. |

[0001193125-15-362448:8k_2_02:12]
Non-GAAP Results

[0001193125-15-362448:8k_2_02:13]
|  | • |  | Non-GAAP net income in the first quarter of fiscal 2016 was $16.2 million, an increase of 12% compared to non-GAAP net income of $14.5 million in the same period a year ago. |

[0001193125-15-362448:8k_2_02:14]
|  | • |  | Non-GAAP net income in the first quarter of fiscal 2016 was $0.45 per diluted share, an increase from non-GAAP net income of $0.41 per diluted share, in the same period a year ago. |

[0001193125-15-362448:8k_2_02:15]
Business Outlook

[0001193125-15-362448:8k_2_02:16]
Based on information available as of
November 2, 2015, Fabrinet is issuing guidance for the second quarter of fiscal 2016 as follows:

[0001193125-15-362448:8k_2_02:17]
|  | • |  | Fabrinet expects second quarter revenue to be in the range of $218 million to $222 million. |

[0001193125-15-362448:8k_2_02:18]
|  | • |  | GAAP net income per diluted share is expected to be in the range of $0.41 to $0.43, based on approximately 36.6 million fully diluted shares outstanding. |

[0001193125-15-362448:8k_2_02:19]
|  | • |  | Non-GAAP net income per diluted share is expected to be in the range of $0.45 to $0.47, based on approximately 36.6 million fully diluted shares outstanding. |

[0001193125-15-362448:8k_2_02:20]
Conference Call Information

[0001193125-15-362448:8k_2_02:21]
| What: |  | Fabrinet First Quarter Fiscal-Year 2016 Financial Results Conference Call |
| When: |  | Monday, November 2, 2015 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic |
|  |  | (253) 237-1137, international |
|  |  | Passcode: 58777039 |
| Replay: |  | (855) 859-2056, domestic |
|  |  | (404) 537-3406, international |
|  |  | Passcode: 58777039 |
| Webcast: |  | http://investor.fabrinet.com (live and replay) |

[0001193125-15-362448:8k_2_02:22]
This press release and any other information related to the call will also be posted on Fabrinet’s website
at http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-15-362448:8k_2_02:23]
About Fabrinet

[0001193125-15-362448:8k_2_02:24]
Fabrinet is a leading provider of
advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, industrial lasers
and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging,
integration, final assembly and test. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the People’s Republic of China
and the United States. For more information visit: www.fabrinet.com.

[0001193125-15-362448:8k_2_02:25]
Forward-Looking Statements

[0001193125-15-362448:8k_2_02:26]
Use of Non-GAAP Financials

[0001193125-15-362448:8k_2_02:27]
The Company refers to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information
regarding the Company’s ongoing operational performance. Non-GAAP net income excludes share-based compensation expenses, investigation cost, expenses related to flooding, amortization of debt issuance costs and unrealized loss on foreign
currency. We have excluded these items in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without
reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001193125-15-362448:8k_2_02:28]
These non-GAAP financial measures are used to: (1) measure company performance against historical results,
(2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial
measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001193125-15-362448:8k_2_02:29]
SOURCE: Fabrinet

[0001193125-15-362448:8k_2_02:30]
Investor Contact:

[0001193125-15-362448:8k_2_02:31]
Garo Toomajanian

[0001193125-15-362448:8k_2_02:32]
ir@fabrinet.com

[0001193125-15-362448:8k_2_02:33]
Fabrinet

[0001193125-15-362448:8k_2_02:34]
Unaudited Condensed Consolidated Balance Sheets

[0001193125-15-362448:8k_2_02:35]
As of
September 25, 2015 and June 26, 2015

[0001193125-15-362448:8k_2_02:36]
| (in thousands of U.S. dollars, except share data) |  | September 25, 2015 |  |  | June 26, 2015 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 95,465 |  |  | $ | 112,978 |  |
| Marketable securities |  |  | 152,121 |  |  |  | 142,866 |  |
| Trade accounts receivable, net |  |  | 139,715 |  |  |  | 134,952 |  |
| Inventory, net |  |  | 143,380 |  |  |  | 130,613 |  |
| Deferred tax assets |  |  | 1,619 |  |  |  | 1,662 |  |
| Prepaid expenses |  |  | 2,404 |  |  |  | 2,135 |  |
| Other current assets |  |  | 1,739 |  |  |  | 1,833 |  |
| Total current assets |  |  | 536,443 |  |  |  | 527,039 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 144,148 |  |  |  | 140,654 |  |
| Intangibles, net |  |  | 195 |  |  |  | 137 |  |
| Deferred tax assets |  |  | 2,249 |  |  |  | 2,249 |  |
| Deferred debt issuance costs |  |  | 2,542 |  |  |  | 2,360 |  |
| Deposits and other non-current assets |  |  | 2,623 |  |  |  | 64 |  |
| Total non-current assets |  |  | 151,757 |  |  |  | 145,464 |  |
| Total assets |  | $ | 688,200 |  |  | $ | 672,503 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Bank borrowings, including revolving loan and current portion of long-term loan from banks |  | $ | 36,000 |  |  | $ | 36,000 |  |
| Trade accounts payable |  |  | 117,978 |  |  |  | 115,319 |  |
| Income tax payable |  |  | 2,120 |  |  |  | 1,470 |  |
| Accrued payroll, bonus and related expenses |  |  | 8,488 |  |  |  | 9,804 |  |
| Accrued expenses |  |  | 16,427 |  |  |  | 6,405 |  |
| Other payables |  |  | 12,089 |  |  |  | 12,050 |  |
| Total current liabilities |  |  | 193,102 |  |  |  | 181,048 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term loans from bank, non-current portion |  |  | 3,000 |  |  |  | 4,500 |  |
| Deferred tax liability |  |  | 851 |  |  |  | 737 |  |
| Severance liabilities |  |  | 5,424 |  |  |  | 5,477 |  |
| Other non-current liabilities |  |  | 1,847 |  |  |  | 1,797 |  |
| Total non-current liabilities |  |  | 11,122 |  |  |  | 12,511 |  |
| Total liabilities |  |  | 204,224 |  |  |  | 193,559 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of September 25, 2015 and June 26, 2015) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 35,776,771 shares and 35,437,654 shares issued and outstanding as of September 25, 2015 and June 26, 2015, respectively) |  |  | 358 |  |  |  | 354 |  |
| Additional paid-in capital |  |  | 92,728 |  |  |  | 89,390 |  |
| Retained earnings |  |  | 390,847 |  |  |  | 389,244 |  |
| Accumulated other comprehensive income (loss) |  |  | 43 |  |  |  | (44 | ) |
| Total shareholders’ equity |  |  | 483,976 |  |  |  | 478,944 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 688,200 |  |  | $ | 672,503 |  |

[0001193125-15-362448:8k_2_02:37]
Fabrinet

[0001193125-15-362448:8k_2_02:38]
Unaudited Condensed Consolidated Statements of Operations and Comprehensive Income

[0001193125-15-362448:8k_2_02:39]
For the three months ended September 25, 2015 and September 26, 2014

[0001193125-15-362448:8k_2_02:40]
|  |  | Three Months Ended |  |
|  |  | September 25, |  |  | September 26, |  |
| (in thousands of U.S. dollars, except share data) |  | 2015 |  |  | 2014 |  |
| Revenues |  | $ | 216,433 |  |  | $ | 189,325 |  |
| Cost of revenues |  |  | (190,422 | ) |  |  | (168,819 | ) |
| Gross profit |  |  | 26,011 |  |  |  | 20,506 |  |
| Selling, general and administrative expenses |  |  | (11,900 | ) |  |  | (8,737 | ) |
| Other expenses in relation to flood |  |  | (864 | ) |  |  | — |  |
| Operating income |  |  | 13,247 |  |  |  | 11,769 |  |
| Interest income |  |  | 442 |  |  |  | 374 |  |
| Interest expense |  |  | (402 | ) |  |  | (133 | ) |
| Foreign exchange loss, net |  |  | (10,492 | ) |  |  | (106 | ) |
| Other income |  |  | 103 |  |  |  | 103 |  |
| Income before income taxes |  |  | 2,898 |  |  |  | 12,007 |  |
| Income tax expense |  |  | (1,295 | ) |  |  | (971 | ) |
| Net income |  |  | 1,603 |  |  |  | 11,036 |  |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |
| Change in fair value of marketable securities |  |  | (18 | ) |  |  | — |  |
| Less: Reclassification adjustment for net loss realized and included in net income |  |  | 105 |  |  |  | — |  |
| Total change in unrealized gain on marketable securities, before tax |  |  | 87 |  |  |  | — |  |
| Income tax expense related to items of other comprehensive income |  |  | — |  |  |  | — |  |
| Total other comprehensive income, net of tax |  |  | 87 |  |  |  | — |  |
| Net comprehensive income |  | $ | 1,690 |  |  | $ | 11,036 |  |
| Earnings per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.05 |  |  | $ | 0.31 |  |
| Diluted |  | $ | 0.04 |  |  | $ | 0.31 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |  |
| Basic |  |  | 35,579 |  |  |  | 35,230 |  |
| Diluted |  |  | 36,315 |  |  |  | 35,587 |  |

[0001193125-15-362448:8k_2_02:41]
Fabrinet

[0001193125-15-362448:8k_2_02:42]
Unaudited Condensed Consolidated Statements of Cash Flows

[0001193125-15-362448:8k_2_02:43]
For the three months ended September 25, 2015 and September 26, 2014

[0001193125-15-362448:8k_2_02:44]
|  |  | Three Months Ended |  |
|  |  | September 25, |  |  | September 26, |  |
| (in thousands of U.S. dollars) |  | 2015 |  |  | 2014 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income for the period |  | $ | 1,603 |  |  | $ | 11,036 |  |
| Adjustments to reconcile net income to net cash provided by operating activities Depreciation |  |  | 4,053 |  |  |  | 2,887 |  |
| Amortization of intangibles |  |  | 10 |  |  |  | 21 |  |
| Gain on disposal of property, plant and equipment |  |  | (26 | ) |  |  | (46 | ) |
| Loss from sales and maturities of available-for-sale securities |  |  | 92 |  |  |  | — |  |
| Amortization of investment premium |  |  | 298 |  |  |  | — |  |
| Amortization of deferred debt issuance costs |  |  | 171 |  |  |  | — |  |
| Reversal of allowance for doubtful accounts |  |  | (4 | ) |  |  | (1 | ) |
| Unrealized loss (gain) on exchange rate and fair value of derivative |  |  | 10,855 |  |  |  | (62 | ) |
| Share-based compensation |  |  | 2,673 |  |  |  | 1,867 |  |
| Deferred income tax |  |  | 157 |  |  |  | 6 |  |
| Other non-cash expenses |  |  | 386 |  |  |  | 360 |  |
| Inventory obsolescence |  |  | 150 |  |  |  | 515 |  |
| Loss from written-off inventory |  |  | 233 |  |  |  | — |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | (4,948 | ) |  |  | (6,745 | ) |
| Inventory |  |  | (13,150 | ) |  |  | (4,617 | ) |
| Other current assets and non-current assets |  |  | (668 | ) |  |  | (396 | ) |
| Trade accounts payable |  |  | 3,053 |  |  |  | 6,860 |  |
| Income tax payable |  |  | 707 |  |  |  | 460 |  |
| Other current liabilities and non-current liabilities |  |  | (1,106 | ) |  |  | 3,688 |  |
| Net cash provided by operating activities |  |  | 4,539 |  |  |  | 15,833 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of marketable securities |  |  | (38,773 | ) |  |  | — |  |
| Proceeds from sales of marketable securities |  |  | 16,687 |  |  |  | — |  |
| Proceeds from maturities of marketable securities |  |  | 12,528 |  |  |  | — |  |
| Purchase of property, plant and equipment |  |  | (8,452 | ) |  |  | (1,510 | ) |
| Purchase of intangibles |  |  | (68 | ) |  |  | — |  |
| Deposits for land purchase |  |  | (2,352 | ) |  |  | — |  |
| Proceeds from disposal of property, plant and equipment |  |  | 28 |  |  |  | 46 |  |
| Net cash used in investing activities |  |  | (20,402 | ) |  |  | (1,464 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Payment of debt issuance costs |  |  | (353 | ) |  |  | (1,570 | ) |
| Repayment of long-term loans from bank |  |  | (1,500 | ) |  |  | (1,500 | ) |
| Proceeds from issuance of ordinary shares under employee share option plans |  |  | 1,547 |  |  |  | 2 |  |
| Withholding tax related to net share settlement of restricted share units |  |  | (878 | ) |  |  | (189 | ) |
| Net cash used in financing activities |  |  | (1,184 | ) |  |  | (3,257 | ) |
| Net (decrease) increase in cash and cash equivalents |  |  | (17,047 | ) |  |  | 11,112 |  |
| Movement in cash and cash equivalents |  |  |  |  |  |  |  |  |
| Cash and cash equivalents at beginning of period |  |  | 112,978 |  |  |  | 233,477 |  |
| (Decrease) increase in cash and cash equivalents |  |  | (17,047 | ) |  |  | 11,112 |  |
| Effect of exchange rate on cash and cash equivalents |  |  | (466 | ) |  |  | 94 |  |
| Cash and cash equivalents at end of period |  | $ | 95,465 |  |  | $ | 244,683 |  |

[0001193125-15-362448:8k_2_02:45]
Fabrinet

[0001193125-15-362448:8k_2_02:46]
Reconciliation of GAAP measures to non-GAAP measures

[0001193125-15-362448:8k_2_02:47]
(in thousands of U.S. dollars, except per share data)

[0001193125-15-362448:8k_2_02:48]
(unaudited)

[0001193125-15-362448:8k_2_02:49]
|  |  | Three Months Ended |  |
|  |  | September 25, |  |  | September 25, |  |  | September 26, |  |  | September 26, |  |
|  |  | 2015 |  |  | 2015 |  |  | 2014 |  |  | 2014 |  |
|  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |
| GAAP measures |  |  | 1,603 |  |  |  | 0.04 |  |  |  | 11,036 |  |  |  | 0.31 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 537 |  |  |  | 0.01 |  |  |  | 368 |  |  |  | 0.01 |  |
| Total related to gross profit |  |  | 537 |  |  |  | 0.01 |  |  |  | 368 |  |  |  | 0.01 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 2,136 |  |  |  | 0.06 |  |  |  | 1,499 |  |  |  | 0.04 |  |
| Investigation cost |  |  | — |  |  |  | — |  |  |  | 1,600 |  |  |  | 0.05 |  |
| Total related to selling, general and administrative expenses |  |  | 2,136 |  |  |  | 0.06 |  |  |  | 3,099 |  |  |  | 0.09 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Expenses related to flooding |  |  | 864 |  |  |  | 0.02 |  |  |  | — |  |  |  | — |  |
| Amortization of debt issuance costs |  |  | 171 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |
| Unrealized loss on foreign currency |  |  | 10,897 |  |  |  | 0.30 |  |  |  | — |  |  |  | — |  |
| Total related to other incomes and other expenses |  |  | 11,932 |  |  |  | 0.33 |  |  |  | — |  |  |  | — |  |
| Total related to net income & EPS |  |  | 14,605 |  |  |  | 0.40 |  |  |  | 3,467 |  |  |  | 0.10 |  |
| Non-GAAP measures |  |  | 16,208 |  |  |  | 0.45 |  |  |  | 14,503 |  |  |  | 0.41 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 36,315 |  |  |  |  |  |  |  | 35,587 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 36,315 |  |  |  |  |  |  |  | 35,587 |  |
