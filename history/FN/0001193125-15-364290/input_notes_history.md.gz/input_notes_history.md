# FN note change history — 0001193125-15-172043 → 0001193125-15-364290


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-11-03):
[0001193125-15-364290:note_history:1]
As of September 25, 2015 and June 26, 2015, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $0.7 million and $0.8 million, respectively.
  (was, 2015-05-05, similarity 0.9677):
[0001193125-15-172043:note_history:1]
As of March 27, 2015 and June 27, 2014, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $0.8 million and $0.3 million, respectively.

- changed (2015-11-03):
[0001193125-15-364290:note_history:2]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, and New Jersey under operating lease arrangements
 that expire in various calendar years through 2020. Rental expense
 under these operating leases amounted to $0.3 million and $0.2
 million for the three months ended September 25, 2015 and
 September 26, 2014, respectively.
  (was, 2015-05-05, similarity 0.888):
[0001193125-15-172043:note_history:2]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in Cayman Islands,
 China, and New Jersey under operating lease arrangements that
 expire in various calendar years through 2020. Rental expense under
 these operating leases amounted to $0.8 million and $0.7 million
 for the nine months ended March 27, 2015 and March 28,
 2014, respectively.

- changed (2015-11-03):
[0001193125-15-364290:note_history:3]
As of September 25, 2015, the future minimum lease payments
 due under non-cancelable leases were as follows at the end of each
 fiscal year below:
  (was, 2015-05-05, similarity 0.9635):
[0001193125-15-172043:note_history:3]
As of March 27, 2015, the future minimum lease payments due
 under non-cancelable leases were as follows at the end of each
 fiscal year below:

- changed (2015-11-03):
[0001193125-15-364290:note_history:4]
| (amount in thousands) |  |  |  |
| 2016 |  | $ | 827 |  |
| 2017 |  |  | 949 |  |
| 2018 |  |  | 948 |  |
| 2019 |  |  | 479 |  |
| 2020 |  |  | 290 |  |
| Total minimum operating lease payments |  | $ | 3,493 |  |
  (was, 2015-05-05, similarity 0.9307):
[0001193125-15-172043:note_history:4]
| (amount in thousands) |  |  |  |
| 2015 |  | $ | 291 |  |
| 2016 |  |  | 1,118 |  |
| 2017 |  |  | 1,103 |  |
| 2018 |  |  | 1,103 |  |
| 2019 |  |  | 615 |  |
| Thereafter |  |  | 452 |  |
| Total minimum operating lease payments |  | $ | 4,682 |  |

- changed (2015-11-03):
[0001193125-15-364290:note_history:5]
As of September 25, 2015, the Company had an outstanding
 commitment to third parties of $4.1 million.
  (was, 2015-05-05, similarity 0.9451):
[0001193125-15-172043:note_history:5]
As of March 27, 2015, the Company had an outstanding
 commitment to third parties of $2.5 million.

- added (2015-11-03):
[0001193125-15-364290:note_history:6]
Purchase of land

- added (2015-11-03):
[0001193125-15-364290:note_history:7]
On September 2, 2015, the Company entered into an agreement to
 purchase a parcel of land in Chonburi, Thailand, to support the
 expansion of the Company’s production in Thailand. The
 aggregate purchase price is approximately $11.8 million, of which
 $2.4 million has been deposited by the Company into escrow. The
 Company will pay the balance of the purchase price at the close of
 escrow, which is expected to occur on or before December 22,
 2015. The Company recorded this deposit as deposits and non-current
 assets on the unaudited condensed balance sheet as of
 September 25, 2015.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-11-03):
[0001193125-15-364290:note_history:8]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of September 25, 2015 and for the
 three months ended September 25, 2015 and September 26,
 2014 includes only normal recurring adjustments, necessary for a
 fair statement of the financial statements set forth herein, in
 accordance with accounting principles generally accepted in the
 United States of America (“U.S. GAAP”) for interim
 financial information and rules and regulations of the Securities
 and Exchange Commission (“SEC”). Accordingly, such
 information does not include all of the information and footnotes
 required by U.S. GAAP for annual financial statements. For further
 information, please refer to the consolidated financial statements
 and footnotes thereto included in Fabrinet’s Annual Report on
 Form 10-K for the year ended June 26, 2015.
  (was, 2015-05-05, similarity 0.9415):
[0001193125-15-172043:note_history:8]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of March 27, 2015 and for the three
 and nine months ended March 27, 2015 and March 28, 2014
 includes only normal recurring adjustments, necessary for a fair
 statement of the financial statements set forth herein, in
 accordance with accounting principles generally accepted in the
 United States of America (“U.S. GAAP”) for interim
 financial information and rules and regulations of the Securities
 and Exchange Commission (“SEC”). Accordingly, such
 information does not include all of the information and footnotes
 required by U.S. GAAP for annual financial statements. For further
 information, please refer to the consolidated financial statements
 and footnotes thereto included in the Company’s Annual Report
 on Form 10-K for the year ended June 27, 2014.

- changed (2015-11-03):
[0001193125-15-364290:note_history:9]
The balance sheet as of June 26, 2015 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three months
 ended September 25, 2015 and September 26, 2014 may not
 be indicative of results for the year ending June 24, 2016 or
 any future periods.
  (was, 2015-05-05, similarity 0.6729):
[0001193125-15-172043:note_history:9]
The balance sheet as of June 27, 2014 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three and nine
 months ended March 27, 2015 and March 28, 2014 may not be
 indicative of results for the year ending June 26, 2015 or any
 future periods.

- changed (2015-11-03):
[0001193125-15-364290:note_history:10]
The preparation of the Company’s condensed consolidated
 financial statements in conformity with U.S. GAAP requires
 management to make estimates and assumptions that affect the
 reported amounts of assets and liabilities and disclosure of
 contingent liabilities at the date of the financial statements, and
 the reported amount of total revenues and expenses during the year.
 The Company bases estimates on historical experience and various
 assumptions about the future that are believed to be reasonable
 based on available information. The Company’s reported
 financial position or results of operations may be materially
 different under different conditions or when using different
 estimates and assumptions, particularly with respect to significant
 accounting policies, which are discussed below. Significant
 assumptions are used in accounting for share-based compensation,
 allowance for doubtful accounts, income taxes, and inventory
 obsolescence, among others. Due to the inherent uncertainty
 involved in making estimates, actual results reported in future
 periods may be different from these estimates. In the event that
 estimates or assumptions prove to differ from actual results,
 adjustments will be made in subsequent periods to reflect more
 current information.
  (was, 2015-05-05, similarity 0.9996):
[0001193125-15-172043:note_history:10]
The preparation of the Company’s condensed consolidated
 financial statements in conformity with U.S. GAAP requires
 management to make estimates and assumptions that affect the
 reported amounts of assets and liabilities and disclosure of
 contingent liabilities at the date of the financial statements, and
 the reported amount of total revenues and expense during the year.
 The Company bases estimates on historical experience and various
 assumptions about the future that are believed to be reasonable
 based on available information. The Company’s reported
 financial position or results of operations may be materially
 different under different conditions or when using different
 estimates and assumptions, particularly with respect to significant
 accounting policies, which are discussed below. Significant
 assumptions are used in accounting for share-based compensation,
 allowance for doubtful accounts, income taxes, and inventory
 obsolescence, among others. Due to the inherent uncertainty
 involved in making estimates, actual results reported in future
 periods may be different from these estimates. In the event that
 estimates or assumptions prove to differ from actual results,
 adjustments will be made in subsequent periods to reflect more
 current information.

- changed (2015-11-03):
[0001193125-15-364290:note_history:11]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended
 September 25, 2015 and September 26, 2014 each consisted
 of 13 weeks. Fiscal year 2016 will be comprised of 52 weeks and
 will end on June 24, 2016.
  (was, 2015-05-05, similarity 0.7817):
[0001193125-15-172043:note_history:11]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended
 March 27, 2015 and March 28, 2014 each consisted of 13
 weeks. The nine months ended March 27, 2015 and March 28,
 2014 each consisted of 39 weeks. Fiscal year 2015 will be comprised
 of 52 weeks and will end on June 26, 2015.

- added (2015-11-03):
[0001193125-15-364290:note_history:12]
In August 2015, the Financial Accounting Standards Board
 (“FASB”) issued Accounting Standards Update
 (“ASU”) 2015-15, “Interest – Imputation of
 Interest (Subtopic 835-30): Presentation and Subsequent Measurement
 of Debt Issuance Costs Associated with Line-of-Credit
 Arrangements”. This ASU amended the presentation or
 subsequent measurement of debt issuance costs related to the
 line-of-credit arrangement. The Company is currently evaluating the
 impact of adoption of this update on its consolidated financial
 statements.

- added (2015-11-03):
[0001193125-15-364290:note_history:13]
In August 2015, the FASB issued ASU 2015-14, “Revenue from
 Contracts with Customers (Topic 666): Deferral of the Effective
 Date”. This amendment deferred the effective date of ASU
 2014-09 for all entities by one year. The Company is currently
 evaluating the impact of adoption of this update on its
 consolidated financial statements.

- added (2015-11-03):
[0001193125-15-364290:note_history:14]
In July 2015, the FASB issued ASU 2015-11, “Inventory (Topic
 330): Simplifying the Measurement of Inventory”. The update
 provides the guidance that an entity, that measured inventory by
 using first-in, first-out or average cost, should measure inventory
 at the lower of cost and net realizable value. Net realizable value
 is the estimated selling prices in the ordinary course of business,
 less reasonably predictable costs of completion, disposal, and
 transportation. Subsequent measurement is unchanged for inventory
 measured using last-in, first-out or the retail inventory method.
 The update is effective for fiscal years beginning after
 December 15, 2016, including interim periods within these
 fiscal years. This update should be applied prospectively with
 earlier application permitted as of the beginning of an interim or
 annual reporting date. The Company is currently evaluating the
 impact of adoption of this update on its consolidated financial
 statements.

- changed (2015-11-03):
[0001193125-15-364290:note_history:15]
In April 2015, the FASB issued ASU 2015-03, “Interest -
 Imputation of Interest (Subtopic 835-30): Simplifying the
 Presentation of Debt Issuance Costs”. The update requires
 debt issuance costs related to a recognized debt liability be
 presented in the balance sheet as a direct deduction from the
 carrying amount of the related debt liability instead of being
 presented as an asset. Debt disclosures will include the face
 amount of the debt liability and the effective interest rate. The
 update requires retrospective application and represents a change
 in accounting principle. The update is effective for fiscal years
 beginning after December 15, 2015. Early adoption is permitted
 for financial statements that have not been previously issued. The
 Company is currently evaluating the impact of adoption of this
 update on its consolidated financial statements.
  (was, 2015-05-05, similarity 0.9447):
[0001193125-15-172043:note_history:15]
In April 2015, the Financial Accounting Standards Board (FASB)
 issued Accounting Standards Update (ASU) 2015-03, “Interest -
 Imputation of Interest (Subtopic 835-30): Simplifying the
 Presentation of Debt Issuance Costs”. The update requires
 debt issuance costs related to a recognized debt liability be
 presented in the balance sheet as a direct deduction from the
 carrying amount of the related debt liability instead of being
 presented as an asset. Debt disclosures will include the face
 amount of the debt liability and the effective interest rate. The
 update requires retrospective application and represents a change
 in accounting principle. The update is effective for fiscal years
 beginning after December 15, 2015. Early adoption is permitted
 for financial statements that have not been previously issued. The
 Company is currently evaluating the impact of adoption of this
 update on its consolidated financial statements.

- removed (2015-11-03):
[0001193125-15-172043:note_history:16]
Revenue recognition

- removed (2015-11-03):
[0001193125-15-172043:note_history:17]
Certain customers may request the Company to store finished
 products purchased by them at the Company’s warehouse. In
 these instances, the Company receives a written request from the
 customer asking the Company to hold the inventory at the
 Company’s warehouse and the ordered goods are segregated in
 the Company’s warehouse from other inventory and cannot be
 used to fulfil other customer orders. In these situations revenue
 is only recognized when persuasive evidence of the sales
 arrangement exists, the goods are completed and ready for shipment,
 pricing is fixed or determinable, collection is reasonable assured,
 and title and risk of loss have passed to the customer.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-03):
[0001193125-15-364290:note_history:18]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  | As of September 25, 2015 |  |  | As of June 26, 2015 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  | October 2015(2) |  | $ | 30,000 |  |  | $ | 30,000 |  |
| Current portion of long-term borrowing |  |  |  |  | 6,000 |  |  |  | 6,000 |  |
|  |  |  |  |  |  | $ | 36,000 |  |  | $ | 36,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | March 2017 |  | $ | 9,000 |  |  | $ | 10,500 |  |
| Less: Current portion |  |  |  |  |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  |  |  |  | $ | 3,000 |  |  | $ | 4,500 |  |
  (was, 2015-05-05, similarity 0.8994):
[0001193125-15-172043:note_history:18]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  |  | As of March 27, 2015 |  |  | As of June 27, 2014 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  |  | April 2015 | (2) |  | $ | 30,000 |  |  | $ | — |  |
| Current portion of long-term borrowing |  |  |  | 6,000 |  |  |  | 6,000 |  |
|  |  |  | $ | 36,000 |  |  | $ | 6,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  |  | March 2017 |  |  | $ | 12,000 |  |  | $ | 16,500 |  |
| Less: Current portion |  |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  | $ | 6,000 |  |  | $ | 10,500 |  |

- added (2015-11-03):
[0001193125-15-364290:note_history:19]
| (2) | On October 16, 2015, the maturity date of this revolving borrowing was extended to November 23, 2015. |

- added (2015-11-03):
[0001193125-15-364290:note_history:20]
Under the long-term borrowing contract of a subsidiary, the loan is
 secured by certain property, plant and equipment. The carrying
 amount of assets secured and pledged as collateral as of
 September 25, 2015 and June 26, 2015 was $49.4 million
 and $50.0 million, respectively. This subsidiary is also required
 to comply with the maximum ratios of debt to equity and minimum
 levels of debt service coverage ratios, and Fabrinet must maintain
 an effective shareholding ratio. The carrying amounts of bank
 borrowings approximate their fair value.

- changed (2015-11-03):
[0001193125-15-364290:note_history:21]
As of September 25, 2015 and June 26, 2015, the Company
 was in compliance with its long-term bank borrowing agreement. In
 addition to financial ratios, certain of the Company’s credit
 facilities include customary events of default.
  (was, 2015-05-05, similarity 0.9679):
[0001193125-15-172043:note_history:21]
As of March 27, 2015 and June 27, 2014, the Company was
 in compliance with its long-term bank borrowing agreement. In
 addition to financial ratios, certain of the Company’s credit
 facilities include customary events of default.

- changed (2015-11-03):
[0001193125-15-364290:note_history:22]
The movements of long-term loans were as follows for the three
 months ended September 25, 2015 and September 26,
 2014:
  (was, 2015-05-05, similarity 0.8696):
[0001193125-15-172043:note_history:22]
The movements of long-term loans were as follows for the nine
 months ended March 27, 2015 and March 28, 2014:

- changed (2015-11-03):
[0001193125-15-364290:note_history:23]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 25, 2015 |  |  | September 26, 2014 |  |
| Opening net book amount |  | $ | 10,500 |  |  | $ | 16,500 |  |
| Repayment during the period |  |  | (1,500 | ) |  |  | (1,500 | ) |
| Closing net book amount |  | $ | 9,000 |  |  | $ | 15,000 |  |
  (was, 2015-05-05, similarity 0.8867):
[0001193125-15-172043:note_history:23]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27, 2015 |  |  | March 28, 2014 |  |
| Opening net book amount |  | $ | 16,500 |  |  | $ | 28,911 |  |
| Repayment during the period |  |  | (4,500 | ) |  |  | (7,251 | ) |
| Closing net book amount |  | $ | 12,000 |  |  | $ | 21,660 |  |

- changed (2015-11-03):
[0001193125-15-364290:note_history:24]
As of September 25, 2015, future maturities of long-term debt
 were as follows at the end of each fiscal year below:
  (was, 2015-05-05, similarity 0.9533):
[0001193125-15-172043:note_history:24]
As of March 27, 2015, future maturities of long-term debt were
 as follows at the end of each fiscal year below:

- changed (2015-11-03):
[0001193125-15-364290:note_history:25]
| (amount in thousands) |  |  |  |
| 2016 |  | $ | 4,500 |  |
| 2017 |  |  | 4,500 |  |
| Total |  | $ | 9,000 |  |
  (was, 2015-05-05, similarity 0.9158):
[0001193125-15-172043:note_history:25]
| (amount in thousands) |  |  |  |
| 2015 |  | $ | 1,500 |  |
| 2016 |  |  | 6,000 |  |
| 2017 |  |  | 4,500 |  |
| Total |  | $ | 12,000 |  |

- changed (2015-11-03):
[0001193125-15-364290:note_history:26]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allows the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. As of
 September 25, 2015, the outstanding revolving borrowing under
 the Facility Agreement was $30.0 million, resulting in available
 credit facilities of $170.0 million. Borrowings under the revolving
 credit facility are classified as current liabilities in the
 unaudited condensed consolidated balance sheet as the Company has
 the periodic option to renew, or pay all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. On October 16, 2015, the
 Company sent a notice to the bank to renew the maturity date of
 this revolving borrowing. The bank approved the notice and extended
 the maturity date to November 23, 2015.
  (was, 2015-05-05, similarity 0.6854):
[0001193125-15-172043:note_history:26]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allows the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. As of March 27, 2015, the
 outstanding revolving borrowing under the Facility Agreement was
 $30.0 million, resulting in available credit facilities of $170.0
 million. Borrowings under the revolving credit facility are
 classified as current liabilities in the unaudited condensed
 consolidated balance sheet as the Company has the periodic option
 to renew, or pay all or a portion of, the outstanding balance at
 the end of the maturity date, which is in the range of 1 to 6
 months, without premium or penalty, upon notice to the
 administrative agent. On April 16, 2015, the Company sent a
 notice to the bank to renew the maturity date of this revolving
 borrowing. The bank approved the notice and extended the maturity
 date to May 18, 2015.

- changed (2015-11-03):
[0001193125-15-364290:note_history:27]
Loans under the Facility Agreement bear interest, at
 Fabrinet’s option, at a rate per annum equal to a LIBOR rate
 plus a spread of 1.75% to 2.50%, or a base rate plus a spread of
 0.75% to 1.50%, determined in accordance with the Facility
 Agreement in each case with such spread determined based on
 Fabrinet’s consolidated total leverage ratio for the
 preceding four fiscal quarter period. Interest is due and payable
 quarterly in arrears for loans bearing interest at the base rate
 and at the end of an interest period (or at each three-month
 interval in the case of loans with interest periods greater than
 three months) in the case of loans bearing interest at the LIBOR
 rate.
  (was, 2015-05-05, similarity 0.919):
[0001193125-15-172043:note_history:27]
Loans under the Facility Agreement bear interest, at
 Fabrinet’s option, at a rate per annum equal to a LIBOR rate
 plus a spread of 1.75% to 2.50%, or a base rate, determined in
 accordance with the Facility Agreement, plus a spread of 0.75% to
 1.50%, in each case with such spread determined based on
 Fabrinet’s consolidated total leverage ratio for the
 preceding four fiscal quarter period. Interest is due and payable
 quarterly in arrears for loans bearing interest at the base rate
 and at the end of an interest period (or at each three-month
 interval in the case of loans with interest periods greater than
 three months) in the case of loans bearing interest at the LIBOR
 rate.

- changed (2015-11-03):
[0001193125-15-364290:note_history:28]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or
 the equivalent under the local law, can be effected. The Facility
 Agreement contains customary affirmative and negative covenants.
 Negative covenants include, among other things, limitations on
 liens, indebtedness, investments, mergers, sales of assets, changes
 in the nature of the business, dividends and distributions,
 affiliate transactions and capital expenditures. The Facility
 Agreement contains financial covenants requiring Fabrinet to
 maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage
 ratio of not more than 2.50:1.00; and (iv) a minimum quick
 ratio of not less than 1.10:1.00. Each of these financial covenants
 is calculated on a consolidated basis for the consecutive four
 fiscal quarter period then ended. As of September 25, 2015,
 the Company was in compliance with all covenants under the Facility
 Agreement.
  (was, 2015-05-05, similarity 0.9569):
[0001193125-15-172043:note_history:28]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or the
 equivalent under the local law, can be effected. The Facility
 Agreement contains customary affirmative and negative covenants.
 Negative covenants include, among other things, limitations on
 liens, indebtedness, investments, mergers, sales of assets, changes
 in the nature of the business, dividends and distributions,
 affiliate transactions and capital expenditures. The Facility
 Agreement contains financial covenants requiring Fabrinet to
 maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage
 ratio of not more than 2.50:1.00; and (iv) a minimum quick
 ratio of not less than 1.10:1.00. Each of these financial covenants
 is calculated on a consolidated basis for the consecutive four
 fiscal quarter period then ended. As of March 27, 2015, the
 Company was in compliance with all covenants under the Facility
 Agreement.

- changed (2015-11-03):
[0001193125-15-364290:note_history:29]
Undrawn available credit facilities classified by available period
 of future borrowing as of September 25, 2015 and June 26,
 2015 were as follows:
  (was, 2015-05-05, similarity 0.7189):
[0001193125-15-172043:note_history:29]
Undrawn available credit facilities as of March 27, 2015 and
 June 27, 2014 were as follows:

- changed (2015-11-03):
[0001193125-15-364290:note_history:30]
| (amount in thousands) |  | September 25, 2015 |  |  | June 26, 2015 |  |
| Short-term |  | $ | 1,380 |  |  | $ | 1,480 |  |
| Long-term |  | $ | 170,000 |  |  | $ | 170,000 |  |
  (was, 2015-05-05, similarity 0.9556):
[0001193125-15-172043:note_history:30]
| (amount in thousands) |  | March 27, 2015 |  |  | June 27, 2014 |  |
| Short-term |  | $ | 1,535 |  |  | $ | 1,539 |  |
| Long-term |  | $ | 170,000 |  |  | $ | — |  |

- removed (2015-11-03):
[0001193125-15-172043:note_history:31]
| (2) | On April 16, 2015, the Company sent a notice to the bank to renew the maturity date of this revolving borrowing. The bank approved the notice and extended the maturity date to May 18, 2015. |

- removed (2015-11-03):
[0001193125-15-172043:note_history:32]
On April 25, 2014, a subsidiary entered into an amendment to
 the bank borrowing agreement. Under the amendment of the contract,
 the long-term loan is secured by certain property, plant and
 equipment. The carrying amount of assets secured and pledged as
 collateral as of March 27, 2015 and June 27, 2014 was
 $50.6 million and $52.3 million, respectively. This subsidiary is
 also required to comply with the maximum ratios of debt to equity
 and minimum levels of debt service coverage ratios, and Fabrinet
 must maintain an effective shareholding ratio. The carrying amounts
 of bank borrowings approximate their fair value.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-03):
[0001193125-15-364290:note_history:33]
The movements of long-term loans were as follows for the three
 months ended September 25, 2015 and September 26,
 2014:
  (was, 2015-05-05, similarity 0.8696):
[0001193125-15-172043:note_history:33]
The movements of long-term loans were as follows for the nine
 months ended March 27, 2015 and March 28, 2014:

- changed (2015-11-03):
[0001193125-15-364290:note_history:34]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 25, 2015 |  |  | September 26, 2014 |  |
| Opening net book amount |  | $ | 10,500 |  |  | $ | 16,500 |  |
| Repayment during the period |  |  | (1,500 | ) |  |  | (1,500 | ) |
| Closing net book amount |  | $ | 9,000 |  |  | $ | 15,000 |  |
  (was, 2015-05-05, similarity 0.8867):
[0001193125-15-172043:note_history:34]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27, 2015 |  |  | March 28, 2014 |  |
| Opening net book amount |  | $ | 16,500 |  |  | $ | 28,911 |  |
| Repayment during the period |  |  | (4,500 | ) |  |  | (7,251 | ) |
| Closing net book amount |  | $ | 12,000 |  |  | $ | 21,660 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-03):
[0001193125-15-364290:note_history:35]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  | As of September 25, 2015 |  |  | As of June 26, 2015 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  | October 2015(2) |  | $ | 30,000 |  |  | $ | 30,000 |  |
| Current portion of long-term borrowing |  |  |  |  | 6,000 |  |  |  | 6,000 |  |
|  |  |  |  |  |  | $ | 36,000 |  |  | $ | 36,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | March 2017 |  | $ | 9,000 |  |  | $ | 10,500 |  |
| Less: Current portion |  |  |  |  |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  |  |  |  | $ | 3,000 |  |  | $ | 4,500 |  |
  (was, 2015-05-05, similarity 0.8994):
[0001193125-15-172043:note_history:35]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  |  | As of March 27, 2015 |  |  | As of June 27, 2014 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  |  | April 2015 | (2) |  | $ | 30,000 |  |  | $ | — |  |
| Current portion of long-term borrowing |  |  |  | 6,000 |  |  |  | 6,000 |  |
|  |  |  | $ | 36,000 |  |  | $ | 6,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  |  | March 2017 |  |  | $ | 12,000 |  |  | $ | 16,500 |  |
| Less: Current portion |  |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  | $ | 6,000 |  |  | $ | 10,500 |  |

- added (2015-11-03):
[0001193125-15-364290:note_history:36]
| (2) | On October 16, 2015, the maturity date of this revolving borrowing was extended to November 23, 2015. |

- removed (2015-11-03):
[0001193125-15-172043:note_history:37]
| (2) | On April 16, 2015, the Company sent a notice to the bank to renew the maturity date of this revolving borrowing. The bank approved the notice and extended the maturity date to May 18, 2015. |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-03):
[0001193125-15-364290:note_history:38]
Undrawn available credit facilities classified by available period
 of future borrowing as of September 25, 2015 and June 26,
 2015 were as follows:
  (was, 2015-05-05, similarity 0.7189):
[0001193125-15-172043:note_history:38]
Undrawn available credit facilities as of March 27, 2015 and
 June 27, 2014 were as follows:

- changed (2015-11-03):
[0001193125-15-364290:note_history:39]
| (amount in thousands) |  | September 25, 2015 |  |  | June 26, 2015 |  |
| Short-term |  | $ | 1,380 |  |  | $ | 1,480 |  |
| Long-term |  | $ | 170,000 |  |  | $ | 170,000 |  |
  (was, 2015-05-05, similarity 0.9556):
[0001193125-15-172043:note_history:39]
| (amount in thousands) |  | March 27, 2015 |  |  | June 27, 2014 |  |
| Short-term |  | $ | 1,535 |  |  | $ | 1,539 |  |
| Long-term |  | $ | 170,000 |  |  | $ | — |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-03):
[0001193125-15-364290:note_history:40]
As of September 25, 2015, future maturities of long-term debt
 were as follows at the end of each fiscal year below:
  (was, 2015-05-05, similarity 0.9533):
[0001193125-15-172043:note_history:40]
As of March 27, 2015, future maturities of long-term debt were
 as follows at the end of each fiscal year below:

- changed (2015-11-03):
[0001193125-15-364290:note_history:41]
| (amount in thousands) |  |  |  |
| 2016 |  | $ | 4,500 |  |
| 2017 |  |  | 4,500 |  |
| Total |  | $ | 9,000 |  |
  (was, 2015-05-05, similarity 0.9158):
[0001193125-15-172043:note_history:41]
| (amount in thousands) |  |  |  |
| 2015 |  | $ | 1,500 |  |
| 2016 |  |  | 6,000 |  |
| 2017 |  |  | 4,500 |  |
| Total |  | $ | 12,000 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2015-11-03):
[0001193125-15-172043:note_history:42]
Revenue recognition

- removed (2015-11-03):
[0001193125-15-172043:note_history:43]
Certain customers may request the Company to store finished
 products purchased by them at the Company’s warehouse. In
 these instances, the Company receives a written request from the
 customer asking the Company to hold the inventory at the
 Company’s warehouse and the ordered goods are segregated in
 the Company’s warehouse from other inventory and cannot be
 used to fulfil other customer orders. In these situations revenue
 is only recognized when persuasive evidence of the sales
 arrangement exists, the goods are completed and ready for shipment,
 pricing is fixed or determinable, collection is reasonable assured,
 and title and risk of loss have passed to the customer.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2015-11-03):
[0001193125-15-364290:note_history:44]
| 17. | Subsequent event |

- added (2015-11-03):
[0001193125-15-364290:note_history:45]
Executive officer separation agreement

- added (2015-11-03):
[0001193125-15-364290:note_history:46]
On September 29, 2015, the Company entered into a Separation
 Agreement and Release (the “Separation Agreement”) with
 an executive officer who resigned from the Company effective
 December 31, 2015 (the “Separation Date”). During
 the period from October 1, 2015 through the Separation Date,
 the officer will continue as an employee and provide certain
 transition services. In connection with the Separation Agreement,
 the Company will incur severance expenses of approximately $0.7
 million during the second quarter of fiscal year 2016.

- added (2015-11-03):
[0001193125-15-364290:note_history:47]
Capital expenditure commitment

- added (2015-11-03):
[0001193125-15-364290:note_history:48]
In October 2015, the Company entered into a construction contract
 with local contractor for construction of new manufacturing
 building at the Company’s Chonburi campus. The contract price
 is approximately of $30.4 million.
