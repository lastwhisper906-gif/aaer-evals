# FN MD&A — 0001408710-25-000039


## mdna

[0001408710-25-000039:mdna:1]
ITEM 7.MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS.

[0001408710-25-000039:mdna:2]
•our goals and strategies;

[0001408710-25-000039:mdna:3]
•our and our customers’ estimates regarding future revenues, operating results, expenses, capital requirements and liquidity;

[0001408710-25-000039:mdna:4]
•our belief that we will be able to maintain favorable pricing on our services;

[0001408710-25-000039:mdna:5]
•our expectation that the portion of our future revenues attributable to customers in regions outside of North America will increase compared with the portion of those revenues for fiscal year 2025;

[0001408710-25-000039:mdna:6]
•our expectation that our fiscal year 2026 selling, general and administrative (“SG&A”) expenses will increase compared to our fiscal year 2025 SG&A expenses;

[0001408710-25-000039:mdna:7]
•our expectation that our employee costs will increase in Thailand and the PRC;

[0001408710-25-000039:mdna:8]
•our future capital expenditures, including the expansion of our manufacturing capacity;

[0001408710-25-000039:mdna:9]
•the growth rates of our existing markets and potential new markets;

[0001408710-25-000039:mdna:10]
•our ability, and the ability of our customers and suppliers, to respond successfully to technological or industry developments;

[0001408710-25-000039:mdna:11]
•our expectations regarding the potential impact of macroeconomic conditions and international political instability on our business, financial condition and operating results;

[0001408710-25-000039:mdna:12]
•our suppliers’ estimates regarding future costs;

[0001408710-25-000039:mdna:13]
•our ability to increase our penetration of existing markets and to penetrate new markets;

[0001408710-25-000039:mdna:14]
•our plans to diversify our sources of revenues;

[0001408710-25-000039:mdna:15]
•our plans to execute acquisitions;

[0001408710-25-000039:mdna:16]
•trends in the optical communications, automotive, industrial lasers and other markets, including trends to outsource the production of components used in those markets;

[0001408710-25-000039:mdna:17]
•our ability to attract and retain a qualified management team and other qualified personnel and advisors; and

[0001408710-25-000039:mdna:18]
•competition in our existing and new markets.

[0001408710-25-000039:mdna:19]
Overview

[0001408710-25-000039:mdna:20]
For an overview of our business, see PART I – ITEM 1. BUSINESS.

[0001408710-25-000039:mdna:21]
Fiscal Years

[0001408710-25-000039:mdna:22]
We utilize a 52-53 week fiscal year ending on the last Friday in June. Our fiscal years 2025, 2024, and 2023 ended on June 27, 2025, June 28, 2024, and June 30, 2023, and consisted of 52 weeks, 52 weeks and 53 weeks, respectively.

[0001408710-25-000039:mdna:23]
Revenues

[0001408710-25-000039:mdna:24]
We believe we are able to expand our relationships with existing customers and attract new customers due to, among other factors, our broad range of complex engineering and manufacturing service offerings, flexible low-cost manufacturing platform, process optimization capabilities, advanced supply chain management, excellent customer service, and experienced management team. Although we expect the prices we charge for our manufactured products to decrease over time (partly as a result of competitive market forces), we believe we will be able to continue to maintain favorable pricing for our services because of our ability to reduce cycle time, adjust our product mix by focusing on more complicated products, improve product quality and yields, and reduce material costs for the products we manufacture. We believe these capabilities have enabled us to help our OEM customers reduce their manufacturing costs while maintaining or improving the design, quality, reliability, and delivery times for their products.

[0001408710-25-000039:mdna:25]
Revenues, by percentage, from individual customers representing 10% or more of our revenues is set forth in Note 20 of our audited consolidated financial statements. Because we depend upon a small number of customers for a significant percentage of our total revenues, a reduction in orders from, a loss of, or any other adverse actions by, any one of these customers would reduce our revenues and could have a material adverse effect on our business, operating results and share price. Moreover, our customer concentration increases the concentration of our accounts receivable and our exposure to payment default by any of our key customers. Many of our existing and potential customers have substantial debt burdens, have experienced financial distress or have static or declining revenues. Certain customers have gone out of business or have been acquired or announced their withdrawal from segments of the optics market. We generate significant accounts payable and inventory for the services that we provide to our customers, which could expose us to substantial and potentially unrecoverable costs if we do not receive payment from our customers. Therefore, any financial difficulties that our key customers experience could materially and adversely affect our operating results and financial condition by generating charges for inventory write-offs, provisions for expected credit losses, and increases in working capital requirements due to increased days inventory and in accounts receivable.

[0001408710-25-000039:mdna:26]
Furthermore, reliance on a small number of customers gives those customers substantial purchasing power and leverage in negotiating contracts with us. In addition, although we enter into master supply agreements with our customers, the level of business to be transacted under those agreements is not guaranteed. Instead, we are awarded business under those agreements on a project-by-project basis. Some of our customers have at times significantly reduced or delayed the volume of manufacturing services that they order from us. If we are unable to maintain our relationships with our existing significant customers, our business, financial condition and operating results could be harmed.

[0001408710-25-000039:mdna:27]
Revenues by Geography

[0001408710-25-000039:mdna:28]
We generate revenues from three geographic regions: North America, Asia-Pacific and others, and Europe. Revenues are attributed to a particular geographic area based on the bill-to location of our customers, notwithstanding that the products may be shipped to a different geographic region. The substantial majority of our revenues are derived from our manufacturing facilities in Asia-Pacific.

[0001408710-25-000039:mdna:29]
The percentage of our revenues generated from a bill-to location outside of North America decreased from 63.5% in fiscal year 2024 to 56.6% in fiscal year 2025, primarily because of an increase in revenue from sales to our customers in North America. Based on the short- and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside of North America will increase as compared with the portion of revenues attributable to such customers during fiscal year 2025.

[0001408710-25-000039:mdna:30]
The following table presents percentages of total revenues by geographic regions:

[0001408710-25-000039:mdna:31]
|  | Years Ended |
|  | June 27, 2025 |  | June 28, 2024 |  | June 30, 2023 |
| North America | 43.4 | % |  | 36.5 | % |  | 48.0 | % |
| Asia-Pacific | 48.4 |  |  | 57.1 |  |  | 43.2 |  |
| Europe | 8.2 |  |  | 6.4 |  |  | 8.8 |  |
|  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001408710-25-000039:mdna:32]
Our Contracts

[0001408710-25-000039:mdna:33]
We enter into supply agreements with our customers which generally have an initial term of up to three years, subject to automatic renewals for subsequent one-year terms unless expressly terminated. Although there are no minimum purchase requirements in our supply agreements, our customers provide us with rolling forecasts of their demand requirements. Our supply agreements generally include provisions for pricing and periodic review of pricing, consignment of our customer’s unique production equipment to us, and the sharing of benefits from cost-savings derived from our efforts. We are generally required to purchase materials, which may include long lead-time materials and materials that are subject to minimum order quantities and/or non-cancelable or non-returnable terms, to meet the stated demands of our customers. After procuring materials, we manufacture products for our customers based on purchase orders that contain terms regarding product quantities, delivery locations and delivery dates. Our customers generally are obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by our customers within a specified period of time, or that are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under our contracts. Once materials are designated as either excess or obsolete inventory, our customers are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and recognized as an offset against cost of revenue upon shipment.

[0001408710-25-000039:mdna:34]
Cost of Revenues

[0001408710-25-000039:mdna:35]
The key components of our cost of revenues are material costs, employee costs, and infrastructure-related costs. Material costs generally represent the majority of our cost of revenues. Several of the materials we require to manufacture products for our customers are customized for their products and often sourced from a single supplier or in some cases, our own subsidiaries. Shortages from sole-source suppliers due to yield loss, quality concerns and capacity constraints, among other factors, may increase our expenses and negatively impact our gross profit margin or total revenues in a given quarter. Material costs include scrap material. Historically, scrap rate diminishes during a product’s life cycle due to process, fixturing and test improvement and optimization.

[0001408710-25-000039:mdna:36]
A second significant element of our cost of revenues is employee costs, including indirect employee costs related to design, configuration and optimization of manufacturing processes for our customers, quality testing, materials testing and other engineering services; and direct costs related to our manufacturing employees. Direct employee costs include employee salaries, insurance and benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a lesser extent, costs to recruit, train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand and the PRC, the fluctuation of the Thai baht and RMB against our functional currency, the U.S. dollar, and our ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention and asset utilization.

[0001408710-25-000039:mdna:37]
Our infrastructure costs are comprised of depreciation, utilities, facilities management and overhead costs. Most of our facility leases are long-term agreements. Our depreciation costs include buildings and fixed assets, primarily at our Pinehurst and Chonburi campuses in Thailand, and capital equipment located at each of our manufacturing locations.

[0001408710-25-000039:mdna:38]
During fiscal years 2025, 2024 and 2023, discretionary merit-based bonus awards were made to our non-executive employees. Charges included in cost of revenues for bonus awards to non-executive employees were $7.7 million, $7.1 million and $6.8 million for fiscal years 2025, 2024 and 2023, respectively.

[0001408710-25-000039:mdna:39]
Share-based compensation expense included in cost of revenues was $10.5 million, $7.2 million and $6.7 million for fiscal years 2025, 2024 and 2023, respectively.

[0001408710-25-000039:mdna:40]
Selling, General and Administrative Expenses

[0001408710-25-000039:mdna:41]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative and other support personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other general expenses not related to cost of revenues. In fiscal year 2026, we expect our SG&A expenses will increase compared with our fiscal year 2025 SG&A expenses, mainly due to increased investment in information technology hardware and increased compensation-related expenses.

[0001408710-25-000039:mdna:42]
The compensation committee of our board of directors approved a fiscal year 2025 executive incentive plan with quantitative objectives based solely on achieving certain revenue targets and non-U.S. GAAP operating margin targets for fiscal year 2025. Bonuses under the fiscal year 2025 executive incentive plan are payable after the end of fiscal year 2025. In fiscal year 2024, the compensation committee approved a fiscal year 2024 executive incentive plan with quantitative objectives that were based solely on achieving certain revenue targets and non-U.S. GAAP operating margin targets for fiscal year 2024. In August 2024, the compensation committee awarded bonuses to our executive employees for Company achievements of performance under our fiscal year 2024 executive incentive plan. Discretionary merit-based bonus awards are also available to our non-executive employees and payable on a quarterly basis.

[0001408710-25-000039:mdna:43]
Charges included in SG&A expenses for bonus distributions to non-executive and executive employees were $6.8 million, $6.4 million and $6.1 million for fiscal years 2025, 2024 and 2023, respectively.

[0001408710-25-000039:mdna:44]
Share-based compensation expense included in SG&A expenses was $22.5 million, $21.2 million and $20.9 million for fiscal years 2025, 2024 and 2023, respectively.

[0001408710-25-000039:mdna:45]
Additional Financial Disclosures

[0001408710-25-000039:mdna:46]
Foreign Exchange

[0001408710-25-000039:mdna:47]
As a result of our international operations, we are exposed to foreign exchange risk arising from various currency exposures, and primarily with respect to the Thai baht. Although a majority of our total revenues is denominated in U.S. dollars, a substantial portion of our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rate between the Thai baht and the U.S. dollar has fluctuated substantially in recent years and may continue to fluctuate substantially in the future. We report our financial results in U.S. dollars and our results of operations have been and could in the future be negatively impacted if the Thai baht appreciates against the U.S. dollar. Smaller portions of our expenses are incurred in a variety of other currencies, including RMB, GBP, Canadian dollars, Euros, and Japanese yen, the appreciation of which may also negatively impact our financial results.

[0001408710-25-000039:mdna:48]
In order to manage the risks arising from fluctuations in foreign currency exchange rates, we use derivative instruments. We may enter into foreign currency exchange forward or put option contracts to manage foreign currency exposures associated with certain assets and liabilities and other forecasted foreign currency transactions and may designate these instruments as hedging instruments. The forward and put option contracts generally have maturities of up to 12 months. All foreign currency exchange contracts are recognized in the consolidated balance sheets at fair value. Gains or losses on our forward and put option contracts generally present gross amount in the assets, liabilities, and transactions economically hedged.

[0001408710-25-000039:mdna:49]
We had foreign currency denominated assets and liabilities in Thai baht, RMB and GBP as follows:

[0001408710-25-000039:mdna:50]
|  | As of June 27, 2025 |  | As of June 28, 2024 |
| (in thousands, except percentages) | ForeignCurrency |  | $ |  | % |  | ForeignCurrency |  | $ |  | % |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 1,812,680 |  |  | $ | 55,689 |  |  | 86.3 |  |  | 1,046,000 |  |  | $ | 28,385 |  |  | 72.5 |  |
| RMB | 43,637 |  |  | 6,092 |  |  | 9.4 |  |  | 42,852 |  |  | 6,013 |  |  | 15.4 |  |
| GBP | 2,031 |  |  | 2,790 |  |  | 4.3 |  |  | 3,778 |  |  | 4,773 |  |  | 12.1 |  |
| Total |  |  | $ | 64,571 |  |  | 100.0 |  |  |  |  | $ | 39,171 |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 4,434,661 |  |  | $ | 136,242 |  |  | 91.5 |  |  | 3,263,391 |  |  | $ | 88,559 |  |  | 87.4 |  |
| RMB | 89,583 |  |  | 12,507 |  |  | 8.4 |  |  | 78,418 |  |  | 11,003 |  |  | 10.9 |  |
| GBP | 106 |  |  | 146 |  |  | 0.1 |  |  | 1,359 |  |  | 1,717 |  |  | 1.7 |  |
| Total |  |  | $ | 148,895 |  |  | 100.0 |  |  |  |  | $ | 101,279 |  |  | 100.0 |  |

[0001408710-25-000039:mdna:51]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable, accrued employee benefits and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of June 27, 2025, there was $165.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 28, 2024, there was $135.0 million of foreign currency forward contracts outstanding on the Thai baht payables.

[0001408710-25-000039:mdna:52]
The RMB assets represent cash and cash equivalents, trade accounts receivable, other receivables, and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable, accrued payroll, bonus and related expenses, and other payables. As of June 27, 2025 and June 28, 2024, we did not have any derivative contracts denominated in RMB.

[0001408710-25-000039:mdna:53]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable, accrued expenses, and other payables. As of June 27, 2025 and June 28, 2024, we did not have any derivative contracts denominated in GBP.

[0001408710-25-000039:mdna:54]
For fiscal years 2025 and 2024, we recorded an unrealized gain of $1.9 million and $0.7 million, respectively, related to derivatives that are not designated as hedging instruments in the consolidated statements of operations and comprehensive income.

[0001408710-25-000039:mdna:55]
Currency Regulation and Dividend Distribution

[0001408710-25-000039:mdna:56]
Foreign exchange regulation in the PRC is primarily governed by the following rules:

[0001408710-25-000039:mdna:57]
•Foreign Currency Administration Rules, as amended on August 5, 2008, or the Exchange Rules;

[0001408710-25-000039:mdna:58]
•Administration Rules of the Settlement, Sale and Payment of Foreign Exchange (1996), or the Administration Rules; and

[0001408710-25-000039:mdna:59]
•Notice on Perfecting Practices Concerning Foreign Exchange Settlement Regarding the Capital Contribution by Foreign-invested Enterprises, as promulgated by the State Administration of Foreign Exchange (“SAFE”), on August 29, 2008, or Circular 142.

[0001408710-25-000039:mdna:60]
Under the Exchange Rules, RMB is freely convertible into foreign currencies for current account items, including the distribution of dividends, interest payments, trade and service-related foreign exchange transactions. However, conversion of RMB for capital account items, such as direct investments, loans, security investments and repatriation of investments, is still subject to the approval of SAFE.

[0001408710-25-000039:mdna:61]
Under the Administration Rules, foreign-invested enterprises may only buy, sell, or remit foreign currencies at banks authorized to conduct foreign exchange business after providing valid commercial documents and relevant supporting

[0001408710-25-000039:mdna:62]
documents and, in the case of capital account item transactions, obtaining approval from SAFE. Capital investments by foreign-invested enterprises outside of the PRC are also subject to limitations, which include approvals by the Ministry of Commerce, SAFE and the State Development and Reform Commission.

[0001408710-25-000039:mdna:63]
Circular 142 regulates the conversion by a foreign-invested company of foreign currency into RMB by restricting how the converted RMB may be used. Circular 142 requires that the registered capital of a foreign-invested enterprise settled in RMB converted from foreign currencies may only be used for purposes within the business scope approved by the applicable governmental authority and may not be used for equity investments within the PRC. In addition, SAFE strengthened its oversight of the flow and use of the registered capital of foreign-invested enterprises settled in RMB converted from foreign currencies. The use of such RMB capital may not be changed without SAFE’s approval and may not be used to repay RMB loans if the proceeds of such loans have not been used.

[0001408710-25-000039:mdna:64]
On January 5, 2007, SAFE promulgated the Detailed Rules for Implementing the Measures for the Administration on Individual Foreign Exchange, or the Implementation Rules. Under the Implementation Rules, PRC citizens who are granted share options by an overseas publicly-listed company are required, through a PRC agent or PRC subsidiary of such overseas publicly-listed company, to register with SAFE and complete certain other procedures.

[0001408710-25-000039:mdna:65]
In addition, the General Administration of Taxation has issued circulars concerning employee share options. Under these circulars, our employees working in the PRC who exercise share options will be subject to PRC individual income tax. Our PRC subsidiary has obligations to file documents related to employee share options with relevant tax authorities and withhold individual income taxes of those employees who exercise their share options.

[0001408710-25-000039:mdna:66]
Furthermore, our transfer of funds to our subsidiaries in Thailand and the PRC are each subject to approval by governmental authorities in case of an increase in registered capital, or subject to registration with governmental authorities in case of a shareholder loan. These limitations on the flow of funds between our subsidiaries and us could restrict our ability to act in response to changing market conditions.

[0001408710-25-000039:mdna:67]
Income Tax

[0001408710-25-000039:mdna:68]
Our effective tax rate is a function of the mix of tax rates in the various jurisdictions in which we do business. We are domiciled in the Cayman Islands. Under the current laws of the Cayman Islands, we are not subject to tax in the Cayman Islands on income or capital gains until March 6, 2039.

[0001408710-25-000039:mdna:69]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption on income generated from projects to manufacture certain products at our Chonburi campus is currently available to us through June 2026. Similar preferential tax treatment was available to us through June 2020 with respect to products manufactured at our Pinehurst campus Building 6. Between June 2020 and June 2025, 50% of our income generated from products manufactured at our Pinehurst campus was exempted from tax. Preferential tax treatment is available to us for products manufactured at our Chonburi campus Building 9, where income generated will be tax exempt through 2031, capped at our actual investment amount. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted. Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001408710-25-000039:mdna:70]
The corporate income tax rates for our subsidiaries in the PRC, the U.S., the U.K. and Israel are 25%, 21%, 25% and 23%, respectively.

[0001408710-25-000039:mdna:71]
Critical Accounting Policies and Use of Estimates

[0001408710-25-000039:mdna:72]
We prepare our consolidated financial statements in conformity with U.S. GAAP, which requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent liabilities on the date of the consolidated financial statements and the reported amounts of revenues and expenses during the financial reporting period. We continually evaluate these estimates and assumptions based on the most recently available information, our own historical experience and on various other assumptions that we believe to be reasonable under the circumstances. The results of these estimates form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Because the use of estimates is an integral component of the financial reporting process, actual results could differ from those estimates. Some of our accounting policies require higher degrees of judgment than others in their application. We consider the policies discussed below to be critical to an understanding of our consolidated financial statements, as their application places the most significant demands on our management’s judgment.

[0001408710-25-000039:mdna:73]
A quantitative sensitivity analysis is provided where such information is reasonably available, can be reliably estimated, and provides material information to investors. The amounts used to assess sensitivity are included for illustrative purposes only and do not represent management’s predictions of variability.

[0001408710-25-000039:mdna:74]
Our critical accounting policies and the adoption of new accounting policies are disclosed in Note 2 – Summary of significant accounting policies. There were no changes to our accounting policies.

[0001408710-25-000039:mdna:75]
Revenue Recognition

[0001408710-25-000039:mdna:76]
We derive total revenues primarily from the assembly of products under supply agreements with our customers and the fabrication of customized optics and glass. We recognize revenue relating to contracts that depict the transfer of promised goods or services to customers in an amount reflecting the consideration to which we expect to be entitled in exchange for such goods or services. In order to meet this requirement, we apply the following five steps: (1) identify the contract with a customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract, and (5) recognize revenue when a performance obligation is satisfied. Revenue is recognized net of any taxes collected from customers, which is subsequently remitted to governmental authorities.

[0001408710-25-000039:mdna:77]
A performance obligation is a contractual promise to transfer a distinct good or service to the customer. In contracts with multiple performance obligations, we identify each performance obligation and evaluate whether such obligation is distinct within the context of the contract at contract inception. The majority of our contracts have a single performance obligation, as the promise to transfer the individual goods or services is not separately identifiable from other promises under the contracts and, therefore, is not distinct.

[0001408710-25-000039:mdna:78]
Management uses judgment to identify performance obligations within a contract and to determine whether multiple promised goods or services in a contract should be accounted for separately or as a group. Judgment is also used in interpreting commercial terms and determining when transfer of control occurs. Moreover, judgment is used to estimate the contract’s transaction price and allocate it to each performance obligation. Any material changes in the identification of performance obligations, determination and allocation of the transaction price to performance obligations, and determination of when transfer of control occurs to the customer, could impact the timing and amount of revenue recognition, which could have a material effect on our financial condition and results of operations.

[0001408710-25-000039:mdna:79]
Long-Lived Assets

[0001408710-25-000039:mdna:80]
We review property, plant and equipment for impairment on a quarterly basis or when events or changes in circumstances indicate the carrying amount of an asset may not be recoverable. An impairment loss is recognized when the carrying amount of a long-lived asset or assets group exceeds its fair value. Recoverability of property and equipment is measured by comparing carrying amount to the projected undiscounted cash flows the property and equipment are expected to generate. If such assets are considered to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the property and equipment exceeds its fair value. The estimate of projected cash flows involves numerous assumptions which require significant judgment by us, including, but not limited to, future use of the assets for our operations versus sale or disposal of the assets, future selling prices for our products, and future production and sales volumes. In addition, significant judgment is required in determining the groups of assets for which impairment tests are separately performed.

[0001408710-25-000039:mdna:81]
Allowance for Expected Credit Losses

[0001408710-25-000039:mdna:82]
We perform ongoing credit evaluations of our customers’ financial condition and make provisions for expected credit losses based on the outcomes of these credit evaluations. We evaluate the collectability of our accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections, and the age of past due receivables. Changes in circumstances, such as an unexpected material adverse change in a major customer’s ability to meet its financial obligation to us or its payment trends, may require us to further adjust estimates of the recoverability of amounts due to us, which could have a material adverse effect on our business, financial condition and results of operations.

[0001408710-25-000039:mdna:83]
Inventory Valuation

[0001408710-25-000039:mdna:84]
Our inventory is stated at the lower of cost (on a first-in, first-out basis) or market value. Our industry is characterized by rapid technological change, short-term customer commitments, and rapid changes in demand. We make provisions for estimated excess and obsolete inventory based on regular reviews of inventory quantities on hand on a quarterly basis and the latest forecasts of product demand and production requirements from our customers. If actual market conditions or our customers’ product demands are less favorable than those projected, additional provisions may be required. In addition, unanticipated changes in liquidity or the financial positions of our customers or changes in economic conditions may require additional provisions for inventory due to our customers’ inability to fulfill their contractual obligations. As the market conditions or our customers’ product demands are inherently difficult to predict, the actual volumes may vary significantly from

[0001408710-25-000039:mdna:85]
projected volumes. Differences in forecasted volume used in calculating excess and obsolete inventory can result in a material adverse effect on our business, financial condition and results of operations. During fiscal year 2025 and fiscal year 2024, a change of 10% for excess and obsolete materials, based on product demand and production requirements from our customers, would have affected our net income by approximately $0.6 million for both years.

[0001408710-25-000039:mdna:86]
Deferred Income Taxes

[0001408710-25-000039:mdna:87]
Our deferred income tax assets represent temporary differences between the carrying amount and the tax basis of existing assets and liabilities that will result in deductible and payable amounts in future years, including net operating loss carry forwards. Based on estimates, the carrying value of our net deferred tax assets assumes that it is more likely than not that we will be able to generate sufficient future taxable income in certain tax jurisdictions to realize these deferred income tax assets. Our judgments regarding future profitability may change depending on future market conditions, changes in U.S. or international tax laws, or other factors. If these estimates and related assumptions change in the future, we may be required to increase or decrease our valuation allowance against the deferred tax assets, resulting in additional or lesser income tax expense.

[0001408710-25-000039:mdna:88]
During fiscal year 2020, one of our subsidiaries in the U.K. also generated net operating loss and management expected that such subsidiary would continue to have net operating losses in the foreseeable future. Therefore, management believed it was more likely than not that all of the deferred tax assets of such subsidiary would not be utilized. Thus, a full valuation allowance of $1.6 million for the deferred tax assets was set up as of the end of fiscal year 2020. A full valuation allowance of $3.8 million, $4.9 million and $2.1 million was set up for the fiscal year ended June 30, 2023, June 24, 2022 and June 25, 2021, respectively. During fiscal year 2024, deferred tax assets and valuation allowance were released due to our cessation of operations in the U.K.

[0001408710-25-000039:mdna:89]
During fiscal year 2023, the other subsidiary in the U.K. generated taxable income and was able to utilize loss carryforwards. Management determined that it was more likely than not that future taxable income would be sufficient to allow utilization of the deferred tax assets. Thus, a full valuation allowance of $1.6 million for the deferred tax assets was released as of June 30, 2023. In fiscal year 2024, due to the planned closure of this entity, management believed that it would not generate sufficient taxable income to utilize the remaining deferred tax assets. Thus, a full valuation allowance of $1.0 million was recorded. In fiscal year 2025, the remaining deferred tax assets and valuation allowance were written off after the application to dissolve the entity was filed in the U.K.

[0001408710-25-000039:mdna:90]
During fiscal year 2024, our subsidiary in Israel generated net operating loss and management expected that such subsidiary would continue to have net operating losses in the foreseeable future. Therefore, management believed it was more likely than not that all of the deferred tax assets of such subsidiary would not be utilized. Thus, a full valuation allowance of $2.7 million for the deferred tax assets was set up as of the end of fiscal year 2024. The full valuation allowance of $2.7 million continued to be recorded for the fiscal year ended June 27, 2025.

[0001408710-25-000039:mdna:91]
Results of Operations

[0001408710-25-000039:mdna:92]
The following table sets forth a summary of our consolidated statements of operations and comprehensive income. Note that period-to-period comparisons of operating results should not be relied upon as indicative of future performance.

[0001408710-25-000039:mdna:93]
|  | Years Ended |
| (in thousands) | June 27, 2025 |  | June 28, 2024 |  | June 30, 2023 |
| Revenues | $ | 3,419,327 |  |  | $ | 2,882,967 |  |  | $ | 2,645,237 |  |
| Cost of revenues | (3,005,978) |  |  | (2,526,849) |  |  | (2,308,964) |  |
| Gross profit | 413,349 |  |  | 356,118 |  |  | 336,273 |  |
| Selling, general and administrative expenses | (87,466) |  |  | (78,481) |  |  | (77,673) |  |
| Restructuring and other related costs | (1,436) |  |  | (32) |  |  | (6,896) |  |
| Operating income | 324,447 |  |  | 277,605 |  |  | 251,704 |  |
| Interest income | 40,162 |  |  | 33,204 |  |  | 11,234 |  |
| Interest expense | — |  |  | (124) |  |  | (1,472) |  |
| Foreign exchange gain (loss), net | (9,251) |  |  | 382 |  |  | (1,211) |  |
| Other income (expense), net | (178) |  |  | 287 |  |  | (159) |  |
| Income before income taxes | 355,180 |  |  | 311,354 |  |  | 260,096 |  |
| Income tax expense | (22,653) |  |  | (15,173) |  |  | (12,183) |  |
| Net income | 332,527 |  |  | 296,181 |  |  | 247,913 |  |
| Other comprehensive income (loss), net of tax | 13,435 |  |  | 4,974 |  |  | 4,678 |  |
| Net comprehensive income | $ | 345,962 |  |  | $ | 301,155 |  |  | $ | 252,591 |  |

[0001408710-25-000039:mdna:94]
The following table sets forth a summary of our consolidated statements of operations and comprehensive income as a percentage of total revenues for the periods indicated.

[0001408710-25-000039:mdna:95]
|  | Years Ended |
|  | June 27, 2025 |  | June 28, 2024 |  | June 30, 2023 |
| Revenues | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenues | (87.9) |  |  | (87.6) |  |  | (87.3) |  |
| Gross profit | 12.1 |  |  | 12.4 |  |  | 12.7 |  |
| Selling, general and administrative expenses | (2.6) |  |  | (2.8) |  |  | (2.9) |  |
| Restructuring and other related costs | (0.1) |  |  | 0.0 |  |  | (0.3) |  |
| Operating income | 9.4 |  |  | 9.6 |  |  | 9.5 |  |
| Interest income | 1.2 |  |  | 1.2 |  |  | 0.4 |  |
| Interest expense | — |  |  | 0.0 |  |  | (0.1) |  |
| Foreign exchange gain (loss), net | (0.3) |  |  | 0.0 |  |  | 0.0 |  |
| Other income (expense), net | 0.0 |  |  | 0.0 |  |  | 0.0 |  |
| Income before income taxes | 10.3 |  |  | 10.8 |  |  | 9.8 |  |
| Income tax expense | (0.7) |  |  | (0.5) |  |  | (0.4) |  |
| Net income | 9.6 |  |  | 10.3 |  |  | 9.4 |  |
| Other comprehensive income (loss), net of tax | 0.4 |  |  | 0.2 |  |  | 0.2 |  |
| Net comprehensive income | 10.0 | % |  | 10.5 | % |  | 9.6 | % |

[0001408710-25-000039:mdna:96]
43

[0001408710-25-000039:mdna:97]
The following table sets forth our revenues by end market and product category for the periods indicated.

[0001408710-25-000039:mdna:98]
| (in thousands, except percentages) | Year ended June 27, 2025 |  | As a % of TotalRevenues |  | Year ended June 28, 2024 |  | As a % of TotalRevenues |  | Year ended June 30, 2023 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |  |  |  |  |
| Datacom | $ | 1,155,944 |  |  |  |  | $ | 1,150,307 |  |  |  |  | $ | 520,796 |  |  |  |
| Telecom | 1,463,411 |  |  |  |  | 1,138,708 |  |  |  |  | 1,487,551 |  |  |  |
| Total revenue - Optical communications | $ | 2,619,355 |  |  | 76.6 | % |  | $ | 2,289,015 |  |  | 79.4 | % |  | $ | 2,008,347 |  |  | 75.9 | % |
| Non-optical communications |  |  |  |  |  |  |  |  |  |  |  |
| Automotive | $ | 464,369 |  |  |  |  | $ | 327,188 |  |  |  |  | $ | 368,581 |  |  |  |
| Industrial laser | 153,068 |  |  |  |  | 122,722 |  |  |  |  | 125,415 |  |  |  |
| Others | 182,535 |  |  |  |  | 144,042 |  |  |  |  | 142,894 |  |  |  |
| Total revenue - Non-optical communications | $ | 799,972 |  |  | 23.4 | % |  | $ | 593,952 |  |  | 20.6 | % |  | $ | 636,890 |  |  | 24.1 | % |
| Total revenue | $ | 3,419,327 |  |  | 100.0 | % |  | $ | 2,882,967 |  |  | 100.0 | % |  | $ | 2,645,237 |  |  | 100.0 | % |

[0001408710-25-000039:mdna:99]
Comparison of Fiscal Year 2025 with Fiscal Year 2024

[0001408710-25-000039:mdna:100]
Revenues. Our revenues increased by $536.3 million, or 18.6%, to $3,419.3 million for fiscal year 2025, compared with $2,883.0 million for fiscal year 2024. This increase was primarily due to an increase in our key customers’ demand for both optical communications products and non-optical communications products. Revenues from optical communications products, which represented $2,619.4 million, or 76.6%, of our revenues for fiscal year 2025, increased by $330.3 million, or 14.4%, compared to the prior fiscal year, mainly due to an increase in revenues from telecommunication products, as inventory absorption issues substantially subsided during fiscal year 2025. Revenues from non-optical communications products, which represented $800.0 million, or 23.4%, of our revenues for fiscal year 2025, increased by $206.0 million, or 34.7%, compared to prior fiscal year, primarily due to growth in automotive revenue as short-term inventory absorption issues substantially subsided during fiscal year 2025.

[0001408710-25-000039:mdna:101]
Cost of revenues. Our cost of revenues increased by $479.2 million, or 19.0%, to $3,006.0 million, or 87.9% of revenues, for fiscal year 2025, compared with $2,526.8 million, or 87.6% of revenues, for fiscal year 2024. The increase was in line with the increase in sales volume.

[0001408710-25-000039:mdna:102]
Gross profit. Our gross profit increased by $57.2 million, or 16.1%, to $413.3 million, or 12.1% of revenues, for fiscal year 2025, compared with $356.1 million, or 12.4% of revenues, for fiscal year 2024. The increase was primarily due to sales volume and product mix.

[0001408710-25-000039:mdna:103]
SG&A expenses. Our SG&A expenses increased by $9.0 million, or 11.5%, to $87.5 million, or 2.6% of revenues, for fiscal year 2025, compared with $78.5 million, or 2.8% of revenues, for fiscal year 2024. Our SG&A expenses increased during fiscal year 2025, compared with fiscal year 2024, mainly due to (1) an increase in executive compensation related expenses of $3.3 million, (2) an increase in legal and consulting fees of $1.6 million, (3) an increase in R&D expenses of $1.4 million, (4) an increase in share-based compensation expenses of $1.4 million, (5) an increase in information technology related expenses of $1.3 million, mainly from network, security system and new hardware costs, (6) recognizing an actuarial loss on obligation of $0.9 million in fiscal year 2025 compared with recognizing an actuarial gain on obligation of $0.4 million in fiscal year 2024, and (7) an increase in severance expenses of $0.7 million, offset by (1) a net decrease in allowance for expected credit losses of $1.1 million, (2) a decrease in sales and marketing expenses of $0.5 million, and (3) a net realized gain from financial instruments of $0.5 million.

[0001408710-25-000039:mdna:104]
Restructuring and other related costs. We recorded $1.4 million in restructuring costs for fiscal year 2025, due to restructuring of operations in our subsidiary in Thailand. We recorded a de minimis amount of restructuring costs for fiscal year 2024.

[0001408710-25-000039:mdna:105]
Operating income. Our operating income increased by $46.8 million, or 16.9%, to $324.4 million, or 9.5% of revenues, for fiscal year 2025, compared with $277.6 million, or 9.6% of revenues, for fiscal year 2024.

[0001408710-25-000039:mdna:106]
Interest income. Our interest income increased by $7.0 million, or 21.1% to $40.2 million, or 1.2% of revenues, for fiscal year 2025, compared with $33.2 million, or 1.2% for fiscal year 2024. The increase was primarily due to a higher average cash balance and short-term investment of $919.0 million in fiscal year 2025, compared with $722.0 million in fiscal year 2024.

[0001408710-25-000039:mdna:107]
Interest expense. Our interest expense decreased for fiscal year 2025, compared with fiscal year 2024, due to full repayment of our long-term loan balance.

[0001408710-25-000039:mdna:108]
Foreign exchange gain (loss), net. We recorded foreign exchange loss, net of $9.3 million for fiscal year 2025, compared with foreign exchange gain, net of $0.4 million for fiscal year 2024. The foreign exchange loss was mainly due to (1) unrealized loss from revaluation of outstanding Thai baht assets and liabilities of $8.0 million, (2) higher unrealized loss from revaluation of currencies other than Thai baht of $1.1 million, (3) higher realized loss from payment/receipt of $1.0 million, and (4) foreign exchange loss totaling $0.8 million from our subsidiaries in the PRC and the U.K., offset by higher unrealized gain from mark-to-market of forward contracts of $1.2 million.

[0001408710-25-000039:mdna:109]
Income before income taxes. We recorded income before income taxes of $355.2 million for fiscal year 2025, compared with $311.4 million for fiscal year 2024.

[0001408710-25-000039:mdna:110]
Income tax expense. Our provision for income tax reflects an effective tax rate of 6.4% and 4.9% for fiscal year 2025 and fiscal year 2024, respectively. The increase was primarily due to higher income subject to tax and IRS audit assessment in fiscal year 2025, offset by a full valuation allowance for deferred tax assets set up in fiscal year 2024.

[0001408710-25-000039:mdna:111]
Net income. We recorded net income of $332.5 million, or 9.7% of revenues, for fiscal year 2025, compared with net income of $296.2 million, or 10.3% of revenues, for fiscal year 2024.

[0001408710-25-000039:mdna:112]
Other comprehensive income (loss). We recorded other comprehensive income of $13.4 million, or 0.4% of revenues, for fiscal year 2025, compared with other comprehensive income of $5.0 million, or 0.2% of revenues, for fiscal year 2024. The increase in other comprehensive income was mainly due to (1) higher unrealized gain from mark-to-market of available-for-sale debt securities of $7.8 million, and (2) unrealized gain from foreign currency translation adjustment of $1.2 million, offset by (1) lower gain from retirement benefits plan of $0.3 million, and (2) lower unrealized gain from mark-to-market of forward contracts of $0.3 million.

[0001408710-25-000039:mdna:113]
Comparison of Fiscal Year 2024 with Fiscal Year 2023

[0001408710-25-000039:mdna:114]
Revenues. Our revenues increased by $237.8 million, or 9.0%, to $2,883.0 million for fiscal year 2024, compared with $2,645.2 million for fiscal year 2023. This increase was primarily due to an increase in our key customers’ demand for optical communication products. Revenues from optical communications products, which represented $2,289.0 million, or 79.4%, of our revenues for fiscal year 2024, increased by $280.7 million, or 14.0%, compared to prior fiscal year, mainly due to an increase in revenues from data communication products, primarily for artificial intelligence applications, offset by a decline in revenues from telecommunication products as inventory absorption within the telecommunication market continued during fiscal year 2024. Revenues from non-optical communications products, which represented $594.0 million, or 20.6%, of our revenues for fiscal year 2024, decreased by $42.9 million, or 6.7%, compared to prior fiscal year, primarily due to inventory absorption related to certain programs in the automotive market.

[0001408710-25-000039:mdna:115]
Cost of revenues. Our cost of revenues increased by $217.8 million, or 9.4%, to $2,526.8 million, or 87.6% of revenues, for fiscal year 2024, compared with $2,309.0 million, or 87.3% of revenues, for fiscal year 2023. The increase in cost of revenues was primarily due to a proportional increase in sales volume.

[0001408710-25-000039:mdna:116]
Gross profit. Our gross profit increased by $19.8 million, or 5.9%, to $356.1 million, or 12.4% of revenues, for fiscal year 2024, compared with $336.3 million, or 12.7% of revenues, for fiscal year 2023. The increase was primarily due to sales volume and product mix.

[0001408710-25-000039:mdna:117]
SG&A expenses. Our SG&A expenses increased by $0.8 million, or 1.0%, to $78.5 million, or 2.8% of revenues, for fiscal year 2024, compared with $77.7 million, or 2.9% of revenues, for fiscal year 2023. Our SG&A expenses increased during fiscal year 2024, compared with fiscal year 2023, mainly due to (1) an increase in sales and marketing expenses of $1.0 million; (2) a net increase in allowance for expected credit losses of $0.9 million; (3) an increase in information technology repair and maintenance expenses of $0.5 million; (4) an increase in R&D expenses of $0.3 million; and (5) an increase in share-based compensation expenses of $0.2 million; offset by (1) recognizing an actuarial gain on obligation of $0.4 million in fiscal year 2024, compared with recognizing an actuarial loss on obligation of $1.1 million in fiscal year 2023; (2) a decrease in legal and consulting fees of $0.4 million; and (3) a decrease in customer relationships amortization of $0.2 million.

[0001408710-25-000039:mdna:118]
Restructuring and other related costs. We recorded a de minimis amount of restructuring costs for fiscal year 2024. We recorded restructuring and other related costs for fiscal year 2023 of $6.9 million.

[0001408710-25-000039:mdna:119]
Operating income. Our operating income increased by $25.9 million, or 10.3%, to $277.6 million, or 9.6% of revenues, for fiscal year 2024, compared with $251.7 million, or 9.5% of revenues, for fiscal year 2023.

[0001408710-25-000039:mdna:120]
Interest income. Our interest income increased by $22.0 million, or 196.4% to $33.2 million, or 1.2% for fiscal year 2024, compared with $11.2 million, or 0.4% for fiscal year 2023. The increase was primarily due to a higher weighted average interest rate in fiscal year 2024, and a higher average cash balance and short-term investment of $722.0 million in fiscal year 2024, compared with $468.0 million in fiscal year 2023.

[0001408710-25-000039:mdna:121]
Interest expense. Our interest expense decreased by $1.4 million to $0.1 million for fiscal year 2024, compared with $1.5 million for fiscal year 2023. The decrease was primarily due to a decrease in the long-term balance.

[0001408710-25-000039:mdna:122]
Foreign exchange gain (loss), net. We recorded foreign exchange gain, net of $0.4 million for fiscal year 2024, compared with foreign exchange loss, net of $1.2 million for fiscal year 2023. The foreign exchange gain was mainly due to (1) lower realized loss from payment/receipt of $1.0 million, (2) unrealized gain from revaluation of outstanding Thai baht assets and liabilities of $0.9 million, and (3) higher unrealized gain from mark-to-market of forward contracts of $0.3 million, offset by (1) unrealized loss from revaluation of currencies other than Thai baht of $0.5 million, and (2) lower foreign exchange gain, totaling $0.1 million from our subsidiaries in the PRC and the U.K.

[0001408710-25-000039:mdna:123]
Income before income taxes. We recorded income before income taxes of $311.4 million for fiscal year 2024, compared with $260.1 million for fiscal year 2023.

[0001408710-25-000039:mdna:124]
Income tax expense. Our provision for income tax reflects an effective tax rate of 4.9% and 4.7% for fiscal year 2024 and fiscal year 2023, respectively. The increase was primarily due to a full valuation allowance of $3.8 million for deferred tax assets set up in fiscal year 2024.

[0001408710-25-000039:mdna:125]
Net income. We recorded net income of $296.2 million, or 10.3% of revenues, for fiscal year 2024, compared with net income of $247.9 million, or 9.4% of revenues, for fiscal year 2023.

[0001408710-25-000039:mdna:126]
Other comprehensive income (loss). We recorded other comprehensive income of $5.0 million, or 0.2% of revenues, for fiscal year 2024, compared with other comprehensive income of $4.7 million, or 0.2% of revenues, for fiscal year 2023. The increase in other comprehensive income was mainly due to higher unrealized gain from mark-to-market of forward contracts and interest rate swap agreement of $1.0 million, offset by (1) lower unrealized gain from mark-to-market of available-for-sale debt securities of $0.6 million, and (2) lower gain from retirement benefits plan of $0.1 million.

[0001408710-25-000039:mdna:127]
Liquidity and Capital Resources

[0001408710-25-000039:mdna:128]
Cash Flows and Working Capital

[0001408710-25-000039:mdna:129]
We primarily finance our operations through cash flow from operating activities. As of June 27, 2025 and June 28, 2024, we had cash, cash equivalents, and short-term investments of $934.2 million and $858.6 million, respectively, and no outstanding debt.

[0001408710-25-000039:mdna:130]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted average interest rate on our cash and cash equivalents for fiscal year 2025, fiscal year 2024 and fiscal year 2023 was 4.2%, 4.4% and 2.4%, respectively.

[0001408710-25-000039:mdna:131]
Our cash investments are made in accordance with an investment policy approved by the audit committee of our board of directors. In general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed income securities are primarily classified as available-for-sale and held-to-maturity. Investments in debt securities that we have the positive intent and ability to hold to maturity are carried at amortized cost and classified as held-to-maturity. Investments in debt securities that are not classified as held-to-maturity are carried at fair value and classified as available-for-sale with any unrealized gains and losses included in AOCI in the consolidated balance sheets. We determine realized gains or losses on sale of available-for-sale debt securities on a specific identification method and record such gains or losses as interest income in the consolidated statements of operations and comprehensive income.

[0001408710-25-000039:mdna:132]
We believe that our current cash and cash equivalents, short-term investments, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the

[0001408710-25-000039:mdna:133]
next 12 months following the filing of this Annual Report on Form 10-K. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Item 1A of this Annual Report on Form 10-K.

[0001408710-25-000039:mdna:134]
We also believe that our current manufacturing capacity is sufficient to meet our anticipated production requirements for at least the next few quarters. In February 2025, we began construction of a new manufacturing facility of approximately 2.0 million square feet at our Chonburi campus. The total expected cost of the project is approximately $132.5 million (Thai baht 4.45 billion).

[0001408710-25-000039:mdna:135]
The following table shows our cash flows for the periods indicated:

[0001408710-25-000039:mdna:136]
|  | Years Ended |
| (in thousands) | June 27, 2025 |  | June 28, 2024 |  | June 30, 2023 |
| Net cash provided by operating activities | $ | 328,365 |  |  | $ | 413,146 |  |  | $ | 213,310 |  |
| Net cash used in investing activities | $ | (286,296) |  |  | $ | (169,751) |  |  | $ | (98,717) |  |
| Net cash used in financing activities | $ | (147,008) |  |  | $ | (64,853) |  |  | $ | (80,984) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | (104,939) |  |  | $ | 178,542 |  |  | $ | 33,609 |  |
| Cash, cash equivalents and restricted cash, beginning of period | $ | 409,973 |  |  | $ | 231,368 |  |  | $ | 198,365 |  |
| Cash, cash equivalents and restricted cash, end of period | $ | 306,425 |  |  | $ | 409,973 |  |  | $ | 231,368 |  |

[0001408710-25-000039:mdna:137]
Operating Activities

[0001408710-25-000039:mdna:138]
Cash provided by operating activities is net income adjusted for certain non-cash items and changes in certain assets and liabilities. The decrease in cash provided by operating activities for fiscal year 2025 as compared to fiscal year 2024 was primarily due to (1) a change in inventories of $174.2 million due to new products and higher sales volume, and (2) an increase in trade receivables of $104.4 million, offset by (1) an increase in trade payables of $134.2 million, (2) an increase in net income of $36.3 million, (3) a change in other current and non-current assets of $13.1 million, and (4) an increase in accrued expenses of $11.6 million.

[0001408710-25-000039:mdna:139]
Investing Activities

[0001408710-25-000039:mdna:140]
Investing cash flows consist primarily of investment purchases, sales, maturities, and disposals; and capital expenditures. The increase in cash used in investing activities for fiscal year 2025 as compared to cash used in investing activities for fiscal year 2024 was primarily due to (1) an increase related to the commencement of construction of a new manufacturing building at our Chonburi campus, (2) an increase in capital expenditures to support certain customers, and (3) a decrease in proceeds of investment.

[0001408710-25-000039:mdna:141]
Financing Activities

[0001408710-25-000039:mdna:142]
Financing cash flows consist primarily of repayment of long-term debt, share repurchases, and withholding tax related to net share settlement of restricted share units. The increase in cash used in financing activities for fiscal year 2025 as compared to the fiscal year 2024 was primarily due to an increase in share repurchases and higher withholding tax related to net share settlement of restricted share units, offset by lower repayment of long-term borrowings.

[0001408710-25-000039:mdna:143]
Material Cash Requirements for Contractual Obligations

[0001408710-25-000039:mdna:144]
Operating Lease

[0001408710-25-000039:mdna:145]
As of June 27, 2025, we have certain operating lease arrangements under which the lease payments are calculated using the straight-line method. Our rental expenses under these leases to be paid within one year and after one year are $2.1 million and $4.4 million, respectively.

[0001408710-25-000039:mdna:146]
Capital Expenditures

[0001408710-25-000039:mdna:147]
The following table sets forth our capital expenditures, which include amounts for which payments have been accrued, for the periods indicated.

[0001408710-25-000039:mdna:148]
|  | Years Ended |
| (in thousands) | June 27, 2025 |  | June 28, 2024 |  | June 30, 2023 |
| Capital expenditures | $ | 130,658 |  |  | $ | 49,270 |  |  | $ | 66,712 |  |

[0001408710-25-000039:mdna:149]
During fiscal year 2025, we invested in a new manufacturing building at our Chonburi campus and equipment for expansion of our manufacturing facilities in Thailand. We expect our capital expenditures for fiscal year 2026 to decrease

[0001408710-25-000039:mdna:150]
compared to fiscal year 2025, mainly due to the new manufacturing building expenditures having been recognized while capital expenditures on equipment for expansion of our manufacturing facilities continue.

[0001408710-25-000039:mdna:151]
Recent Accounting Pronouncements

[0001408710-25-000039:mdna:152]
See Note 2 of the Notes to Consolidated Financial Statements for recent accounting pronouncements that could have an effect on us.
