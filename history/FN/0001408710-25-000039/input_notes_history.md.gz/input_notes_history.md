# FN note change history — 0001408710-25-000008 → 0001408710-25-000023


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-05-06):
[0001408710-25-000023:note_history:1]
As of March 28, 2025 and June 28, 2024, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.2 million and $2.0 million, respectively, or Thai baht 75.7 million and 73.2 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the subsidiary's operations related to the Israeli Customs department.
  (was, 2025-02-04, similarity 0.986):
[0001408710-25-000008:note_history:1]
As of December 27, 2024 and June 28, 2024, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.2 million and $2.0 million, respectively, or Thai baht 75.7 million and 73.2 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the subsidiary's operations related to the Israeli Customs department.

- changed (2025-05-06):
[0001408710-25-000023:note_history:2]
As of March 28, 2025, the Company had purchase obligations and other commitments to third parties of $1.27 billion.
  (was, 2025-02-04, similarity 0.9581):
[0001408710-25-000008:note_history:2]
As of December 27, 2024, the Company had purchase obligations and other commitments to third parties of $1.27 billion.

- added (2025-05-06):
[0001408710-25-000023:note_history:3]
In February 2025, the Company entered into a construction contract with a local contractor for construction of a new

- added (2025-05-06):
[0001408710-25-000023:note_history:4]
manufacturing building at the Company's Chonburi campus. The contract price is approximately $132.5 million (Thai baht

- added (2025-05-06):
[0001408710-25-000023:note_history:5]
4.45 billion).

- changed (2025-05-06):
[0001408710-25-000023:note_history:6]
As of March 28, 2025, the Company had total capital expenditure commitments to third parties of $174.3 million.
  (was, 2025-02-04, similarity 0.9561):
[0001408710-25-000008:note_history:6]
As of December 27, 2024, the Company had total capital expenditure commitments to third parties of $45.2 million.

- changed (2025-05-06):
[0001408710-25-000023:note_history:7]
As of March 28, 2025, there was no amount outstanding under the 2023 Credit Facility Agreement.
  (was, 2025-02-04, similarity 0.9486):
[0001408710-25-000008:note_history:7]
As of December 27, 2024, there was no amount outstanding under the 2023 Credit Facility Agreement.

- changed (2025-05-06):
[0001408710-25-000023:note_history:8]
As of March 28, 2025, the Borrowers were in compliance with all of their financial covenants under the 2023 Credit Facility Agreement.
  (was, 2025-02-04, similarity 0.9644):
[0001408710-25-000008:note_history:8]
As of December 27, 2024, the Borrowers were in compliance with all of their financial covenants under the 2023 Credit Facility Agreement.

- added (2025-05-06):
[0001408710-25-000023:note_history:9]
In September 2024, the Court dismissed the lawsuit in its entirety based on jurisdictional grounds. The Plaintiffs have since appealed the Court’s ruling to the High People's Court of Fujian Province (the "Appellate Court"). In their appeal, the Plaintiffs now claim that Casix is the primary obligor to return the alleged unjust enrichment to the Plaintiffs. On November 24, 2024, the Appellate Court agreed to hear the appeal. At this time, the Company is not able to quantify any potential liability in connection with this litigation because of the early stage of this litigation.

- removed (2025-05-06):
[0001408710-25-000008:note_history:10]
In September 2024, the Court dismissed the lawsuit in its entirety based on jurisdictional grounds. The Plaintiffs have since appealed the Court’s ruling to the High People's Court of Fujian Province (the "Appellate Court"). In their appeal, the

- removed (2025-05-06):
[0001408710-25-000008:note_history:11]
Plaintiffs now claim that Casix is the primary obligor to return the alleged unjust enrichment to the Plaintiffs. On November 24, 2024, the Appellate Court agreed to hear the appeal. At this time, the Company is not able to quantify any potential liability in connection with this litigation due to its pending status and preliminary nature.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-05-06):
[0001408710-25-000023:note_history:12]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of March 28, 2025 and for the three and nine months ended March 28, 2025 and March 29, 2024 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 28, 2024.
  (was, 2025-02-04, similarity 0.9554):
[0001408710-25-000008:note_history:12]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of December 27, 2024 and for the three and six months ended December 27, 2024 and December 29, 2023 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 28, 2024.

- changed (2025-05-06):
[0001408710-25-000023:note_history:13]
The results for the three and nine months ended March 28, 2025 may not be indicative of results for the year ending June 27, 2025 or any future periods.
  (was, 2025-02-04, similarity 0.951):
[0001408710-25-000008:note_history:13]
The results for the three and six months ended December 27, 2024 may not be indicative of results for the year ending June 27, 2025 or any future periods.

- changed (2025-05-06):
[0001408710-25-000023:note_history:14]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, the fair value of warrant shares at grant date, allowance for expected credit losses, income taxes, and inventory obsolescence. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information.
  (was, 2025-02-04, similarity 0.9817):
[0001408710-25-000008:note_history:14]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for expected credit losses, income taxes, and inventory obsolescence. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information.

- changed (2025-05-06):
[0001408710-25-000023:note_history:15]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended March 28, 2025 and March 29, 2024 consisted of 13 weeks. The nine months ended March 28, 2025 and March 29, 2024 consisted of 39 weeks. Fiscal year 2025 will comprise 52 weeks and will end on June 27, 2025.
  (was, 2025-02-04, similarity 0.677):
[0001408710-25-000008:note_history:15]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended December 27, 2024 and December 29, 2023 consisted of 13 weeks. Fiscal year 2025 will comprise 52 weeks and will end on June 27, 2025.

- changed (2025-05-06):
[0001408710-25-000023:note_history:16]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740), Improvements to Income Tax Disclosures,” which requires more detailed income tax disclosures. This ASU requires entities to disclose disaggregated information about their effective tax rate reconciliation as well as expanded information on income taxes paid by jurisdiction. This ASU is effective for all entities for fiscal years beginning after December 15, 2024, with early adoption permitted for annual financial statements that have not yet been issued or made available for issuance. This ASU will be effective for the Company beginning in fiscal year 2026. The Company is currently assessing the impact to its disclosures.
  (was, 2025-02-04, similarity 0.9956):
[0001408710-25-000008:note_history:16]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740), Improvements to Income Tax Disclosures,” which requires more detailed income tax disclosures. This ASU requires entities to disclose disaggregated information about their effective tax rate reconciliation as well as expanded information on income taxes paid by jurisdiction. This ASU is effective for all entities for fiscal years beginning after December 15, 2024, with early adoption permitted for annual financial statements that have not yet been issued or made available for issuance. This ASU will be effective for the Company beginning with fiscal year 2026. The Company is currently assessing the impact to its disclosures.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-05-06):
[0001408710-25-000023:note_history:17]
The following table summarizes the cost and estimated fair value of debt securities classified as available-for-sale securities based on stated effective maturities as of March 28, 2025 and June 28, 2024:

- added (2025-05-06):
[0001408710-25-000023:note_history:18]
|  | March 28, 2025 |  | June 28, 2024 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 234,076 |  |  | $ | 236,659 |  |  | $ | 110,671 |  |  | $ | 110,669 |  |
| Due between one to five years | 401,226 |  |  | 407,113 |  |  | 339,136 |  |  | 337,961 |  |
| Total | $ | 635,302 |  |  | $ | 643,772 |  |  | $ | 449,807 |  |  | $ | 448,630 |  |

- removed (2025-05-06):
[0001408710-25-000008:note_history:19]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of December 27, 2024 and June 28, 2024:

- removed (2025-05-06):
[0001408710-25-000008:note_history:20]
|  | December 27, 2024 |  | June 28, 2024 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 122,647 |  |  | $ | 124,479 |  |  | $ | 110,671 |  |  | $ | 110,669 |  |
| Due between one to five years | 403,191 |  |  | 406,490 |  |  | 339,136 |  |  | 337,961 |  |
| Total | $ | 525,838 |  |  | $ | 530,969 |  |  | $ | 449,807 |  |  | $ | 448,630 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-06):
[0001408710-25-000023:note_history:21]
| (in thousands, except percentages) | Three Months EndedMarch 28, 2025 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 28, 2025 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 401,769 |  |  |  |  | $ | 1,080,701 |  |  |  |
| Others (1) | 1,357 |  |  |  |  | 4,306 |  |  |  |
| Total revenue in North America | 403,126 |  |  | 46.2 | % |  | 1,085,007 |  |  | 43.2 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 226,406 |  |  |  |  | 758,030 |  |  |  |
| India | 86,027 |  |  |  |  | 238,486 |  |  |  |
| Hong Kong | 26,773 |  |  |  |  | 65,735 |  |  |  |
| Thailand | 15,995 |  |  |  |  | 41,185 |  |  |  |
| China | 14,694 |  |  |  |  | 40,216 |  |  |  |
| Singapore | 10,704 |  |  |  |  | 33,948 |  |  |  |
| Japan | 10,425 |  |  |  |  | 27,980 |  |  |  |
| Malaysia | 8,224 |  |  |  |  | 23,287 |  |  |  |
| Others | 589 |  |  |  |  | 1,790 |  |  |  |
| Total revenue in Asia-Pacific and others | 399,837 |  |  | 45.9 | % |  | 1,230,657 |  |  | 49.0 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 36,905 |  |  |  |  | 108,617 |  |  |  |
| Germany | 11,822 |  |  |  |  | 32,033 |  |  |  |
| Others | 20,109 |  |  |  |  | 53,321 |  |  |  |
| Total revenue in Europe | $ | 68,836 |  |  | 7.9 | % |  | $ | 193,971 |  |  | 7.8 | % |
| Total revenue | $ | 871,799 |  |  | 100.0 | % |  | $ | 2,509,635 |  |  | 100.0 | % |
  (was, 2025-02-04, similarity 0.9373):
[0001408710-25-000008:note_history:21]
| (in thousands, except percentages) | Three Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 371,112 |  |  |  |  | $ | 678,932 |  |  |  |
| Others (1) | 1,291 |  |  |  |  | 2,949 |  |  |  |
| Total revenue in North America | 372,403 |  |  | 44.7 | % |  | 681,881 |  |  | 41.6 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 240,671 |  |  |  |  | 531,624 |  |  |  |
| India | 75,629 |  |  |  |  | 152,459 |  |  |  |
| Hong Kong | 20,415 |  |  |  |  | 38,962 |  |  |  |
| Thailand | 14,069 |  |  |  |  | 25,190 |  |  |  |
| China | 13,650 |  |  |  |  | 25,522 |  |  |  |
| Singapore | 12,481 |  |  |  |  | 23,244 |  |  |  |
| Japan | 8,976 |  |  |  |  | 17,555 |  |  |  |
| Malaysia | 7,565 |  |  |  |  | 15,063 |  |  |  |
| Others | 726 |  |  |  |  | 1,201 |  |  |  |
| Total revenue in Asia-Pacific and others | 394,182 |  |  | 47.3 | % |  | 830,820 |  |  | 50.7 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 39,262 |  |  |  |  | 71,712 |  |  |  |
| Germany | 10,867 |  |  |  |  | 20,211 |  |  |  |
| Others | 16,894 |  |  |  |  | 33,212 |  |  |  |
| Total revenue in Europe | $ | 67,023 |  |  | 8.0 | % |  | $ | 125,135 |  |  | 7.7 | % |
| Total revenue | $ | 833,608 |  |  | 100.0 | % |  | $ | 1,637,836 |  |  | 100.0 | % |

- changed (2025-05-06):
[0001408710-25-000023:note_history:22]
| (in thousands, except percentages) | Three Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 268,475 |  |  |  |  | $ | 761,622 |  |  |  |
| Others (1) | 3,401 |  |  |  |  | 10,192 |  |  |  |
| Total revenue in North America | 271,876 |  |  | 37.2 | % |  | 771,814 |  |  | 36.3 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 275,022 |  |  |  |  | 752,736 |  |  |  |
| India | 63,055 |  |  |  |  | 208,865 |  |  |  |
| Malaysia | 30,993 |  |  |  |  | 100,938 |  |  |  |
| Hong Kong | 15,147 |  |  |  |  | 43,085 |  |  |  |
| Thailand | 13,059 |  |  |  |  | 36,489 |  |  |  |
| China | 12,309 |  |  |  |  | 53,831 |  |  |  |
| Japan | 5,772 |  |  |  |  | 18,408 |  |  |  |
| Others | 1,655 |  |  |  |  | 4,390 |  |  |  |
| Total revenue in Asia-Pacific and others | 417,012 |  |  | 57.0 | % |  | 1,218,742 |  |  | 57.2 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 18,164 |  |  |  |  | 66,808 |  |  |  |
| Germany | 10,148 |  |  |  |  | 33,323 |  |  |  |
| Others | 14,335 |  |  |  |  | 39,019 |  |  |  |
| Total revenue in Europe | $ | 42,647 |  |  | 5.8 | % |  | $ | 139,150 |  |  | 6.5 | % |
| Total revenue | $ | 731,535 |  |  | 100.0 | % |  | $ | 2,129,706 |  |  | 100.0 | % |
  (was, 2025-02-04, similarity 0.9524):
[0001408710-25-000008:note_history:22]
| (in thousands, except percentages) | Three Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |  | Six Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 238,288 |  |  |  |  | $ | 493,147 |  |  |  |
| Others (1) | 3,331 |  |  |  |  | 6,791 |  |  |  |
| Total revenue in North America | 241,619 |  |  | 33.9 | % |  | 499,938 |  |  | 35.8 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 267,038 |  |  |  |  | 477,714 |  |  |  |
| India | 75,033 |  |  |  |  | 145,810 |  |  |  |
| Malaysia | 36,626 |  |  |  |  | 69,945 |  |  |  |
| China | 21,262 |  |  |  |  | 41,522 |  |  |  |
| Hong Kong | 12,150 |  |  |  |  | 27,938 |  |  |  |
| Thailand | 10,403 |  |  |  |  | 23,430 |  |  |  |
| Japan | 5,826 |  |  |  |  | 12,636 |  |  |  |
| Others | 1,570 |  |  |  |  | 2,735 |  |  |  |
| Total revenue in Asia-Pacific and others | 429,908 |  |  | 60.3 | % |  | 801,730 |  |  | 57.3 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 18,870 |  |  |  |  | 48,644 |  |  |  |
| Germany | 10,395 |  |  |  |  | 23,175 |  |  |  |
| Others | 11,902 |  |  |  |  | 24,684 |  |  |  |
| Total revenue in Europe | $ | 41,167 |  |  | 5.8 | % |  | $ | 96,503 |  |  | 6.9 | % |
| Total revenue | $ | 712,694 |  |  | 100.0 | % |  | $ | 1,398,171 |  |  | 100.0 | % |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-06):
[0001408710-25-000023:note_history:23]
As of March 28, 2025 and June 28, 2024, the Company's contract assets were de minimis.
  (was, 2025-02-04, similarity 0.9412):
[0001408710-25-000008:note_history:23]
As of December 27, 2024 and June 28, 2024, the Company's contract assets were de minimis.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-05-06):
[0001408710-25-000023:note_history:24]
| (in thousands, except percentages) | Three Months EndedMarch 28, 2025 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 28, 2025 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 401,769 |  |  |  |  | $ | 1,080,701 |  |  |  |
| Others (1) | 1,357 |  |  |  |  | 4,306 |  |  |  |
| Total revenue in North America | 403,126 |  |  | 46.2 | % |  | 1,085,007 |  |  | 43.2 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 226,406 |  |  |  |  | 758,030 |  |  |  |
| India | 86,027 |  |  |  |  | 238,486 |  |  |  |
| Hong Kong | 26,773 |  |  |  |  | 65,735 |  |  |  |
| Thailand | 15,995 |  |  |  |  | 41,185 |  |  |  |
| China | 14,694 |  |  |  |  | 40,216 |  |  |  |
| Singapore | 10,704 |  |  |  |  | 33,948 |  |  |  |
| Japan | 10,425 |  |  |  |  | 27,980 |  |  |  |
| Malaysia | 8,224 |  |  |  |  | 23,287 |  |  |  |
| Others | 589 |  |  |  |  | 1,790 |  |  |  |
| Total revenue in Asia-Pacific and others | 399,837 |  |  | 45.9 | % |  | 1,230,657 |  |  | 49.0 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 36,905 |  |  |  |  | 108,617 |  |  |  |
| Germany | 11,822 |  |  |  |  | 32,033 |  |  |  |
| Others | 20,109 |  |  |  |  | 53,321 |  |  |  |
| Total revenue in Europe | $ | 68,836 |  |  | 7.9 | % |  | $ | 193,971 |  |  | 7.8 | % |
| Total revenue | $ | 871,799 |  |  | 100.0 | % |  | $ | 2,509,635 |  |  | 100.0 | % |
  (was, 2025-02-04, similarity 0.9373):
[0001408710-25-000008:note_history:24]
| (in thousands, except percentages) | Three Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 371,112 |  |  |  |  | $ | 678,932 |  |  |  |
| Others (1) | 1,291 |  |  |  |  | 2,949 |  |  |  |
| Total revenue in North America | 372,403 |  |  | 44.7 | % |  | 681,881 |  |  | 41.6 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 240,671 |  |  |  |  | 531,624 |  |  |  |
| India | 75,629 |  |  |  |  | 152,459 |  |  |  |
| Hong Kong | 20,415 |  |  |  |  | 38,962 |  |  |  |
| Thailand | 14,069 |  |  |  |  | 25,190 |  |  |  |
| China | 13,650 |  |  |  |  | 25,522 |  |  |  |
| Singapore | 12,481 |  |  |  |  | 23,244 |  |  |  |
| Japan | 8,976 |  |  |  |  | 17,555 |  |  |  |
| Malaysia | 7,565 |  |  |  |  | 15,063 |  |  |  |
| Others | 726 |  |  |  |  | 1,201 |  |  |  |
| Total revenue in Asia-Pacific and others | 394,182 |  |  | 47.3 | % |  | 830,820 |  |  | 50.7 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 39,262 |  |  |  |  | 71,712 |  |  |  |
| Germany | 10,867 |  |  |  |  | 20,211 |  |  |  |
| Others | 16,894 |  |  |  |  | 33,212 |  |  |  |
| Total revenue in Europe | $ | 67,023 |  |  | 8.0 | % |  | $ | 125,135 |  |  | 7.7 | % |
| Total revenue | $ | 833,608 |  |  | 100.0 | % |  | $ | 1,637,836 |  |  | 100.0 | % |

- changed (2025-05-06):
[0001408710-25-000023:note_history:25]
| (in thousands, except percentages) | Three Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 268,475 |  |  |  |  | $ | 761,622 |  |  |  |
| Others (1) | 3,401 |  |  |  |  | 10,192 |  |  |  |
| Total revenue in North America | 271,876 |  |  | 37.2 | % |  | 771,814 |  |  | 36.3 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 275,022 |  |  |  |  | 752,736 |  |  |  |
| India | 63,055 |  |  |  |  | 208,865 |  |  |  |
| Malaysia | 30,993 |  |  |  |  | 100,938 |  |  |  |
| Hong Kong | 15,147 |  |  |  |  | 43,085 |  |  |  |
| Thailand | 13,059 |  |  |  |  | 36,489 |  |  |  |
| China | 12,309 |  |  |  |  | 53,831 |  |  |  |
| Japan | 5,772 |  |  |  |  | 18,408 |  |  |  |
| Others | 1,655 |  |  |  |  | 4,390 |  |  |  |
| Total revenue in Asia-Pacific and others | 417,012 |  |  | 57.0 | % |  | 1,218,742 |  |  | 57.2 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 18,164 |  |  |  |  | 66,808 |  |  |  |
| Germany | 10,148 |  |  |  |  | 33,323 |  |  |  |
| Others | 14,335 |  |  |  |  | 39,019 |  |  |  |
| Total revenue in Europe | $ | 42,647 |  |  | 5.8 | % |  | $ | 139,150 |  |  | 6.5 | % |
| Total revenue | $ | 731,535 |  |  | 100.0 | % |  | $ | 2,129,706 |  |  | 100.0 | % |
  (was, 2025-02-04, similarity 0.9524):
[0001408710-25-000008:note_history:25]
| (in thousands, except percentages) | Three Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |  | Six Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 238,288 |  |  |  |  | $ | 493,147 |  |  |  |
| Others (1) | 3,331 |  |  |  |  | 6,791 |  |  |  |
| Total revenue in North America | 241,619 |  |  | 33.9 | % |  | 499,938 |  |  | 35.8 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 267,038 |  |  |  |  | 477,714 |  |  |  |
| India | 75,033 |  |  |  |  | 145,810 |  |  |  |
| Malaysia | 36,626 |  |  |  |  | 69,945 |  |  |  |
| China | 21,262 |  |  |  |  | 41,522 |  |  |  |
| Hong Kong | 12,150 |  |  |  |  | 27,938 |  |  |  |
| Thailand | 10,403 |  |  |  |  | 23,430 |  |  |  |
| Japan | 5,826 |  |  |  |  | 12,636 |  |  |  |
| Others | 1,570 |  |  |  |  | 2,735 |  |  |  |
| Total revenue in Asia-Pacific and others | 429,908 |  |  | 60.3 | % |  | 801,730 |  |  | 57.3 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 18,870 |  |  |  |  | 48,644 |  |  |  |
| Germany | 10,395 |  |  |  |  | 23,175 |  |  |  |
| Others | 11,902 |  |  |  |  | 24,684 |  |  |  |
| Total revenue in Europe | $ | 41,167 |  |  | 5.8 | % |  | $ | 96,503 |  |  | 6.9 | % |
| Total revenue | $ | 712,694 |  |  | 100.0 | % |  | $ | 1,398,171 |  |  | 100.0 | % |

- added (2025-05-06):
[0001408710-25-000023:note_history:26]
| (in thousands, except percentages) | Three Months EndedMarch 28, 2025 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 28, 2025 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 251,105 |  |  |  |  | $ | 879,087 |  |  |  |
| Telecom | 406,126 |  |  |  |  | 1,051,609 |  |  |  |
| Total revenue - Optical communications | $ | 657,231 |  |  | 75.4 | % |  | $ | 1,930,696 |  |  | 76.9 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 129,468 |  |  |  |  | $ | 336,456 |  |  |  |
| Industrial laser | 40,464 |  |  |  |  | 113,332 |  |  |  |
| Others | 44,636 |  |  |  |  | 129,151 |  |  |  |
| Total revenue - Non-optical communications | $ | 214,568 |  |  | 24.6 | % |  | $ | 578,939 |  |  | 23.1 | % |
| Total revenue | $ | 871,799 |  |  | 100.0 | % |  | $ | 2,509,635 |  |  | 100.0 | % |

- added (2025-05-06):
[0001408710-25-000023:note_history:27]
| (in thousands, except percentages) | Three Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 305,478 |  |  |  |  | $ | 835,642 |  |  |  |
| Telecom | 285,970 |  |  |  |  | 856,997 |  |  |  |
| Total revenue - Optical communications | $ | 591,448 |  |  | 80.9 | % |  | $ | 1,692,639 |  |  | 79.5 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 73,636 |  |  |  |  | $ | 241,166 |  |  |  |
| Industrial laser | 30,319 |  |  |  |  | 90,582 |  |  |  |
| Others | 36,132 |  |  |  |  | 105,319 |  |  |  |
| Total revenue - Non-optical communications | $ | 140,087 |  |  | 19.1 | % |  | $ | 437,067 |  |  | 20.5 | % |
| Total revenue | $ | 731,535 |  |  | 100.0 | % |  | $ | 2,129,706 |  |  | 100.0 | % |

- changed (2025-05-06):
[0001408710-25-000023:note_history:28]
As of March 28, 2025 and June 28, 2024, the Company's contract assets were de minimis.
  (was, 2025-02-04, similarity 0.9412):
[0001408710-25-000008:note_history:28]
As of December 27, 2024 and June 28, 2024, the Company's contract assets were de minimis.

- changed (2025-05-06):
[0001408710-25-000023:note_history:29]
The following tables summarize the activity in the Company’s contract liabilities during the nine months ended March 28, 2025:
  (was, 2025-02-04, similarity 0.9426):
[0001408710-25-000008:note_history:29]
The following tables summarize the activity in the Company’s contract liabilities during the six months ended December 27, 2024:

- changed (2025-05-06):
[0001408710-25-000023:note_history:30]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 28, 2024 | $ | 7,846 |  |
| Advance payments received during the period | 11,534 |  |
| Revenue recognized | (10,455) |  |
| Ending balance, March 28, 2025 | $ | 8,925 |  |
  (was, 2025-02-04, similarity 0.9736):
[0001408710-25-000008:note_history:30]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 28, 2024 | $ | 7,846 |  |
| Advance payments received during the period | 5,615 |  |
| Revenue recognized | (4,845) |  |
| Ending balance, December 27, 2024 | $ | 8,616 |  |

- added (2025-05-06):
[0001408710-25-000023:note_history:31]
Customer Warrant

- added (2025-05-06):
[0001408710-25-000023:note_history:32]
Warrants issued to customers are accounted for as equity instruments and measured in accordance with ASC 718, Compensation – Stock Compensation. For awards granted to a customer which are not in exchange for distinct goods or services, the fair value of the awards earned based on service or performance conditions is recorded as a reduction of the transaction price, in accordance with ASC 606, Revenue from Contracts with Customers.

- added (2025-05-06):
[0001408710-25-000023:note_history:33]
To determine the fair value of warrants in accordance with ASC 718, the Company uses the Black-Scholes option pricing model, based in part on assumptions for which management is required to use judgment. Based on the fair value of the awards, the Company determines the amount of warrant expense based on the customer’s achievement of vesting conditions, which is recorded as a reduction of revenues on the unaudited condensed consolidated statement of operations. The dilutive impact of customer warrants is determined using the treasury stock method.

- added (2025-05-06):
[0001408710-25-000023:note_history:34]
For the three and nine months ended March 28, 2025, the Company recognized $3.9 million as a reduction to revenue on the unaudited condensed consolidated statements of operations.

- removed (2025-05-06):
[0001408710-25-000008:note_history:35]
| (in thousands, except percentages) | Three Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 299,101 |  |  |  |  | $ | 627,982 |  |  |  |
| Telecom | 348,049 |  |  |  |  | 645,483 |  |  |  |
| Total revenue - Optical communications | $ | 647,150 |  |  | 77.6 | % |  | $ | 1,273,465 |  |  | 77.8 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 104,247 |  |  |  |  | $ | 206,988 |  |  |  |
| Industrial laser | 37,542 |  |  |  |  | 72,868 |  |  |  |
| Others | 44,669 |  |  |  |  | 84,515 |  |  |  |
| Total revenue - Non-optical communications | $ | 186,458 |  |  | 22.4 | % |  | $ | 364,371 |  |  | 22.2 | % |
| Total revenue | $ | 833,608 |  |  | 100.0 | % |  | $ | 1,637,836 |  |  | 100.0 | % |

- removed (2025-05-06):
[0001408710-25-000008:note_history:36]
| (in thousands, except percentages) | Three Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |  | Six Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 288,121 |  |  |  |  | $ | 530,164 |  |  |  |
| Telecom | 279,813 |  |  |  |  | 571,027 |  |  |  |
| Total revenue - Optical communications | $ | 567,934 |  |  | 79.7 | % |  | $ | 1,101,191 |  |  | 78.8 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 79,172 |  |  |  |  | $ | 167,530 |  |  |  |
| Industrial laser | 30,348 |  |  |  |  | 60,263 |  |  |  |
| Others | 35,240 |  |  |  |  | 69,187 |  |  |  |
| Total revenue - Non-optical communications | $ | 144,760 |  |  | 20.3 | % |  | $ | 296,980 |  |  | 21.2 | % |
| Total revenue | $ | 712,694 |  |  | 100.0 | % |  | $ | 1,398,171 |  |  | 100.0 | % |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2025-05-06):
[0001408710-25-000008:note_history:37]
Subsequent event
In January 2025, the Company’s board of directors approved the repurchase of up to an additional $100.0 million of the Company’s outstanding ordinary shares, bringing the aggregate authorization under the Company’s existing share repurchase program to $534.3 million.
