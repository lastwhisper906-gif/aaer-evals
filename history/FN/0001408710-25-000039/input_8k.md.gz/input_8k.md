# FN 8-K — 0001408710-25-000036 filed 2025-08-18

## item codes, every 8-K on or before 2025-08-19

- 2025-08-18 0001408710-25-000036 — 2.02, 5.02, 9.01
- 2025-05-27 0001408710-25-000027 — 5.02
- 2025-05-05 0001408710-25-000021 — 2.02, 9.01
- 2025-03-13 0001408710-25-000010 — 1.01, 3.02, 7.01, 9.01
- 2025-02-03 0001408710-25-000006 — 2.02, 9.01
- 2024-12-20 0001408710-24-000044 — 5.02
- 2024-12-13 0001408710-24-000042 — 5.07
- 2024-11-04 0001408710-24-000038 — 2.02, 9.01
- 2024-08-19 0001408710-24-000030 — 2.02, 5.02, 9.01
- 2024-06-14 0001408710-24-000023 — 5.02
- 2024-05-06 0001408710-24-000017 — 2.02, 9.01
- 2024-02-05 0001408710-24-000007 — 2.02, 9.01
- 2023-12-13 0001408710-23-000038 — 5.07
- 2023-11-06 0001408710-23-000034 — 2.02, 9.01
- 2023-08-21 0001408710-23-000026 — 2.02, 5.02, 9.01
- 2023-05-08 0001408710-23-000016 — 2.02, 5.02, 9.01
- 2023-02-06 0001408710-23-000006 — 2.02, 9.01
- 2022-12-13 0001408710-22-000062 — 5.07
- 2022-11-07 0001408710-22-000058 — 2.02, 9.01
- 2022-08-15 0001408710-22-000041 — 2.02, 5.02, 9.01
- 2022-05-02 0001408710-22-000026 — 2.02, 9.01
- 2022-01-31 0001408710-22-000016 — 2.02, 9.01
- 2022-01-19 0001408710-22-000010 — 5.02
- 2022-01-06 0001408710-22-000006 — 5.02
- 2021-12-10 0001408710-21-000051 — 5.07
- 2021-11-01 0001408710-21-000045 — 2.02, 9.01
- 2021-08-16 0001408710-21-000031 — 2.02, 5.02, 9.01
- 2021-05-03 0001408710-21-000019 — 2.02, 9.01
- 2021-02-01 0001408710-21-000008 — 2.02, 9.01
- 2020-12-11 0001193125-20-315861 — 5.07
- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2025-08-19

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001408710-25-000036:8k_2_02:1]
EX-99.1
2
fn-2025818xex991q425.htm
EX-99.1

[0001408710-25-000036:8k_2_02:2]
Document

[0001408710-25-000036:8k_2_02:3]
Exhibit 99.1

[0001408710-25-000036:8k_2_02:4]
Fabrinet Announces Fourth Quarter and Fiscal Year 2025 Financial Results

[0001408710-25-000036:8k_2_02:5]
•Record Fourth Quarter Revenue Exceeds Guidance Range

[0001408710-25-000036:8k_2_02:6]
•Record Fiscal Year 2025 Revenue Increases 19% Year-over-year

[0001408710-25-000036:8k_2_02:7]
BANGKOK, Thailand – August 18, 2025 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its fourth quarter and fiscal year ended June 27, 2025.

[0001408710-25-000036:8k_2_02:8]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “Our fourth quarter was exceptional, capping off a remarkable year with strong momentum. We achieved record quarterly revenue of $910 million, exceeding our guidance range. Through excellent execution, our non-GAAP EPS also reached a new all-time high. For all of fiscal year 2025, we achieved record revenue of $3.4 billion, an increase of 19% from the prior year. We’re encouraged by the growing demand across all areas of our business and remain optimistic that these favorable trends will carry into the first quarter and beyond.”

[0001408710-25-000036:8k_2_02:9]
Fourth Quarter Fiscal Year 2025 Financial Highlights

[0001408710-25-000036:8k_2_02:10]
GAAP Results

[0001408710-25-000036:8k_2_02:11]
•Revenue for the fourth quarter of fiscal year 2025 was $909.7 million, compared to $753.3 million for the fourth quarter of fiscal year 2024.

[0001408710-25-000036:8k_2_02:12]
•GAAP net income for the fourth quarter of fiscal year 2025 was $87.2 million, compared to $81.1 million for the fourth quarter of fiscal year 2024.

[0001408710-25-000036:8k_2_02:13]
•GAAP net income per diluted share for the fourth quarter of fiscal year 2025 was $2.42, compared to $2.22 for the fourth quarter of fiscal year 2024.

[0001408710-25-000036:8k_2_02:14]
Non-GAAP Results

[0001408710-25-000036:8k_2_02:15]
•Non-GAAP net income for the fourth quarter of fiscal year 2025 was $95.6 million, compared to $88.0 million for the fourth quarter of fiscal year 2024.

[0001408710-25-000036:8k_2_02:16]
•Non-GAAP net income per diluted share for the fourth quarter of fiscal year 2025 was $2.65, compared to $2.41 for the fourth quarter of fiscal year 2024.

[0001408710-25-000036:8k_2_02:17]
Fiscal Year 2025 Financial Highlights

[0001408710-25-000036:8k_2_02:18]
GAAP Results

[0001408710-25-000036:8k_2_02:19]
•Revenue for fiscal year 2025 was $3.42 billion, compared to $2.88 billion for fiscal year 2024.

[0001408710-25-000036:8k_2_02:20]
•GAAP net income for fiscal year 2025 was $332.5 million, compared to $296.2 million for fiscal year 2024.

[0001408710-25-000036:8k_2_02:21]
•GAAP net income per diluted share for fiscal year 2025 was $9.17, compared to $8.10 for fiscal year 2024.

[0001408710-25-000036:8k_2_02:22]
Non-GAAP Results

[0001408710-25-000036:8k_2_02:23]
•Non-GAAP net income for fiscal year 2025 was $368.8 million, compared to $324.6 million for fiscal year 2024.

[0001408710-25-000036:8k_2_02:24]
•Non-GAAP net income per diluted share for fiscal year 2025 was $10.17, compared to $8.88 for fiscal year 2024.

[0001408710-25-000036:8k_2_02:25]
Business Outlook

[0001408710-25-000036:8k_2_02:26]
Based on information available as of August 18, 2025, Fabrinet is issuing guidance for its first fiscal quarter ending September 26, 2025, as follows:

[0001408710-25-000036:8k_2_02:27]
•Fabrinet expects first quarter revenue to be in the range of $910 million to $950 million.

[0001408710-25-000036:8k_2_02:28]
•GAAP net income per diluted share is expected to be in the range of $2.48 to $2.63, based on approximately 36.1 million fully diluted shares outstanding.

[0001408710-25-000036:8k_2_02:29]
•Non-GAAP net income per diluted share is expected to be in the range of $2.75 to $2.90, based on approximately 36.1 million fully diluted shares outstanding.

[0001408710-25-000036:8k_2_02:30]
Guidance for non-GAAP net income per diluted share excludes share-based compensation expenses and certain non-recurring items. A reconciliation of non-GAAP net income per diluted share to the corresponding GAAP measure is available at the end of this press release.

[0001408710-25-000036:8k_2_02:31]
Conference Call Information

[0001408710-25-000036:8k_2_02:32]
| What: |  | Fabrinet Fourth Quarter Fiscal Year 2025 Financial Results Call |
| When: |  | August 18, 2025 |
| Time: |  | 5:00 p.m. ET |
| Live Call and Replay: |  | https://investor.fabrinet.com/events-and-presentations/events |

[0001408710-25-000036:8k_2_02:33]
A recorded version of this webcast will be available approximately two hours after the call and accessible at http://investor.fabrinet.com. The webcast will be archived on Fabrinet’s website for a period of one year.

[0001408710-25-000036:8k_2_02:34]
About Fabrinet

[0001408710-25-000036:8k_2_02:35]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China, and Israel. For more information visit: www.fabrinet.com.

[0001408710-25-000036:8k_2_02:36]
Forward-Looking Statements

[0001408710-25-000036:8k_2_02:37]
Non-GAAP Financial Measures

[0001408710-25-000036:8k_2_02:38]
In addition to reporting financial results in accordance with GAAP, we provide investors with certain non-GAAP financial measures. These non-GAAP financial measures are in addition to, and not a substitute for or superior to, measures of financial performance prepared in accordance with GAAP. We believe these non-GAAP financial measures provide investors with useful supplemental information to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, we use some of these non-GAAP financial measures to measure company performance for the purposes of determining employee incentive plan compensation.

[0001408710-25-000036:8k_2_02:39]
Non-GAAP gross profit, non-GAAP operating profit, non-GAAP net income and non-GAAP net income per diluted share exclude: share-based compensation expenses; severance payment and others; restructuring and other related costs; legal and

[0001408710-25-000036:8k_2_02:40]
litigation costs; and amortization of deferred debt issuance costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations.

[0001408710-25-000036:8k_2_02:41]
Non-GAAP free cash flow is net cash provided by (used in) operating activities, minus capital expenditures (purchase of property, plant and equipment). We use free cash flow to measure our ability to generate additional cash from our business operations.

[0001408710-25-000036:8k_2_02:42]
There are a number of limitations related to the use of these non-GAAP financial measures versus their nearest GAAP equivalents. For example, other companies may calculate non-GAAP financial measures differently or may use other measures to evaluate their performance, all of which could reduce the usefulness of our non-GAAP financial measures as tools for comparison. We urge you to review the reconciliations of our non-GAAP financial measures to the most directly comparable GAAP financial measures, and not to rely on any single financial measure to evaluate our business.

[0001408710-25-000036:8k_2_02:43]
Investor Contact:

[0001408710-25-000036:8k_2_02:44]
Garo Toomajanian

[0001408710-25-000036:8k_2_02:45]
ir@fabrinet.com

[0001408710-25-000036:8k_2_02:46]
FABRINET

[0001408710-25-000036:8k_2_02:47]
CONSOLIDATED BALANCE SHEETS

[0001408710-25-000036:8k_2_02:48]
| (in thousands of U.S. dollars, except share data and par value) | June 27,2025 |  | June 28,2024 |
|  | (unaudited) |  |  |
| Assets |  |  |  |
| Current assets |  |  |  |
| Cash and cash equivalents | $ | 306,425 |  |  | $ | 409,973 |  |
| Short-term investments | 627,819 |  |  | 448,630 |  |
| Trade accounts receivable, net of allowance for expected credit losses of $1,344 and $1,629, respectively | 758,894 |  |  | 592,452 |  |
| Inventories | 581,015 |  |  | 463,206 |  |
| Prepaid expenses | 38,476 |  |  | 10,620 |  |
| Other current assets | 116,210 |  |  | 87,810 |  |
| Total current assets | 2,428,839 |  |  | 2,012,691 |  |
| Non-current assets |  |  |  |
| Property, plant and equipment, net | 380,640 |  |  | 307,240 |  |
| Intangibles, net | 2,156 |  |  | 2,321 |  |
| Operating right-of-use assets | 5,768 |  |  | 5,336 |  |
| Deferred tax assets | 13,406 |  |  | 10,446 |  |
| Other non-current assets | 623 |  |  | 485 |  |
| Total non-current assets | 402,593 |  |  | 325,828 |  |
| Total Assets | $ | 2,831,432 |  |  | $ | 2,338,519 |  |
| Liabilities and Shareholders’ Equity |  |  |  |
| Current liabilities |  |  |  |
| Trade accounts payable | 637,417 |  |  | 441,835 |  |
| Fixed assets payable | 40,781 |  |  | 14,380 |  |
| Operating lease liabilities, current portion | 1,792 |  |  | 1,355 |  |
| Income tax payable | 7,939 |  |  | 3,937 |  |
| Accrued payroll, bonus and related expenses | 24,566 |  |  | 22,116 |  |
| Accrued expenses | 30,630 |  |  | 19,916 |  |
| Other payables | 66,717 |  |  | 54,403 |  |
| Total current liabilities | 809,842 |  |  | 557,942 |  |
| Non-current liabilities |  |  |  |
| Deferred tax liability | 1,595 |  |  | 4,895 |  |
| Operating lease liabilities, non-current portion | 3,679 |  |  | 3,635 |  |
| Severance liabilities | 31,225 |  |  | 24,093 |  |
| Other non-current liabilities | 3,279 |  |  | 2,209 |  |
| Total non-current liabilities | 39,778 |  |  | 34,832 |  |
| Total Liabilities | 849,620 |  |  | 592,774 |  |
| Shareholders’ equity |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of June 27, 2025 and June 28, 2024) | — |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 39,602,152 shares and 39,457,462 shares issued as of June 27, 2025 and June 28, 2024, respectively; and 35,728,074 shares and 36,145,242 shares outstanding as of June 27, 2025 and June 28, 2024, respectively) | 396 |  |  | 395 |  |
| Additional paid-in capital | 237,881 |  |  | 222,044 |  |
| Less: Treasury shares (3,874,078 shares and 3,312,220 shares as of June 27, 2025 and June 28, 2024, respectively) | (360,056) |  |  | (234,323) |  |
| Accumulated other comprehensive income (loss) | 10,294 |  |  | (3,141) |  |
| Retained earnings | 2,093,297 |  |  | 1,760,770 |  |
| Total Shareholders’ Equity | 1,981,812 |  |  | 1,745,745 |  |
| Total Liabilities and Shareholders’ Equity | $ | 2,831,432 |  |  | $ | 2,338,519 |  |

[0001408710-25-000036:8k_2_02:49]
FABRINET

[0001408710-25-000036:8k_2_02:50]
CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME

[0001408710-25-000036:8k_2_02:51]
|  | Three Months Ended |  | Year Ended |
| (in thousands of U.S. dollars, except per share data) | June 27,2025 |  | June 28,2024 |  | June 27,2025 |  | June 28,2024 |
|  | (unaudited) |  | (unaudited) |  | (unaudited) |  |  |
| Revenues | $ | 909,692 |  |  | $ | 753,261 |  |  | $ | 3,419,327 |  |  | $ | 2,882,967 |  |
| Cost of revenues | (798,401) |  |  | (660,812) |  |  | (3,005,978) |  |  | (2,526,849) |  |
| Gross profit | 111,291 |  |  | 92,449 |  |  | 413,349 |  |  | 356,118 |  |
| Selling, general and administrative expenses | (22,166) |  |  | (19,108) |  |  | (87,466) |  |  | (78,481) |  |
| Restructuring and other related costs | (69) |  |  | (32) |  |  | (1,436) |  |  | (32) |  |
| Operating income | 89,056 |  |  | 73,309 |  |  | 324,447 |  |  | 277,605 |  |
| Interest income | 7,770 |  |  | 11,049 |  |  | 40,162 |  |  | 33,204 |  |
| Interest expense | — |  |  | (17) |  |  | — |  |  | (124) |  |
| Foreign exchange gain (loss), net | (3,523) |  |  | 407 |  |  | (9,251) |  |  | 382 |  |
| Other income (expense), net | (67) |  |  | 227 |  |  | (178) |  |  | 287 |  |
| Income before income taxes | 93,236 |  |  | 84,975 |  |  | 355,180 |  |  | 311,354 |  |
| Income tax expense | (6,029) |  |  | (3,909) |  |  | (22,653) |  |  | (15,173) |  |
| Net income | 87,207 |  |  | 81,066 |  |  | 332,527 |  |  | 296,181 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities | 246 |  |  | (55) |  |  | 9,893 |  |  | 2,100 |  |
| Change in net unrealized gain (loss) on derivative instruments | 1,407 |  |  | 1,499 |  |  | 2,314 |  |  | 2,561 |  |
| Change in net retirement benefits plan – prior service cost | — |  |  | 59 |  |  | — |  |  | 330 |  |
| Change in foreign currency translation adjustment | 92 |  |  | 14 |  |  | 1,228 |  |  | (17) |  |
| Total other comprehensive income (loss), net of tax | 1,745 |  |  | 1,517 |  |  | 13,435 |  |  | 4,974 |  |
| Net comprehensive income | $ | 88,952 |  |  | $ | 82,583 |  |  | $ | 345,962 |  |  | $ | 301,155 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 2.44 |  |  | $ | 2.24 |  |  | $ | 9.23 |  |  | $ | 8.17 |  |
| Diluted | $ | 2.42 |  |  | $ | 2.22 |  |  | $ | 9.17 |  |  | $ | 8.10 |  |
| Weighted-average number of ordinary shares outstanding (in thousands of shares) |  |  |  |  |  |  |  |
| Basic | 35,788 |  |  | 36,150 |  |  | 36,017 |  |  | 36,246 |  |
| Diluted | 36,084 |  |  | 36,533 |  |  | 36,267 |  |  | 36,564 |  |

[0001408710-25-000036:8k_2_02:52]
FABRINET

[0001408710-25-000036:8k_2_02:53]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001408710-25-000036:8k_2_02:54]
|  | Year Ended |
| (in thousands of U.S. dollars) | June 27,2025 |  | June 28,2024 |
|  | (unaudited) |  |  |
| Cash flows from operating activities |  |  |  |
| Net income | $ | 332,527 |  |  | $ | 296,181 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 53,433 |  |  | 49,017 |  |
| (Gain) loss on disposal of property, plant and equipment and intangibles | (70) |  |  | 62 |  |
| Amortization of discount (premium) of short-term investments | (4,563) |  |  | (3,399) |  |
| (Reversal of) allowance for expected credit losses | (285) |  |  | 664 |  |
| Unrealized loss (gain) on exchange rate and fair value of foreign currency forward contracts | 4,963 |  |  | (849) |  |
| Amortization of fair value at hedge inception of interest rate swaps | — |  |  | (220) |  |
| Share-based compensation | 33,004 |  |  | 28,374 |  |
| Customer warrant | 4,109 |  |  | — |  |
| Deferred income tax expense (benefit) | (5,726) |  |  | 1,672 |  |
| Other non-cash expenses | 131 |  |  | 310 |  |
| Changes in operating assets and liabilities |  |  |  |
| Trade accounts receivable | (165,657) |  |  | (61,279) |  |
| Inventories | (117,809) |  |  | 56,370 |  |
| Other current assets and non-current assets | (33,595) |  |  | (46,715) |  |
| Trade accounts payable | 194,236 |  |  | 60,040 |  |
| Income tax payable | 4,029 |  |  | (1,960) |  |
| Accrued expenses | 13,036 |  |  | 1,398 |  |
| Other payables | 11,522 |  |  | 30,959 |  |
| Severance liabilities | 3,799 |  |  | 2,771 |  |
| Other current liabilities and non-current liabilities | 1,281 |  |  | (250) |  |
| Net cash provided by operating activities | 328,365 |  |  | 413,146 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of short-term investments | (444,149) |  |  | (435,905) |  |
| Proceeds from sales of short-term investments | — |  |  | 40,000 |  |
| Proceeds from maturities of short-term investments | 279,417 |  |  | 271,877 |  |
| Purchase of property, plant and equipment | (121,078) |  |  | (47,528) |  |
| Purchase of intangibles | (738) |  |  | (889) |  |
| Proceeds from disposal of property, plant and equipment | 252 |  |  | 2,694 |  |
| Net cash used in investing activities | (286,296) |  |  | (169,751) |  |
| Cash flows from financing activities |  |  |  |
| Repayment of long-term borrowings | — |  |  | (12,188) |  |
| Repurchase of ordinary shares | (125,733) |  |  | (39,490) |  |
| Withholding tax related to net share settlement of restricted share units | (21,275) |  |  | (13,175) |  |
| Net cash used in financing activities | (147,008) |  |  | (64,853) |  |
| Net increase (decrease) in cash and cash equivalents | $ | (104,939) |  |  | $ | 178,542 |  |
| Movement in cash and cash equivalents |  |  |  |
| Cash and cash equivalents at the beginning of period | $ | 409,973 |  |  | $ | 231,368 |  |
| Increase (decrease) in cash and cash equivalents | (104,939) |  |  | 178,542 |  |
| Effect of exchange rate on cash and cash equivalents | 1,391 |  |  | 63 |  |
| Cash and cash equivalents at the end of period | $ | 306,425 |  |  | $ | 409,973 |  |

[0001408710-25-000036:8k_2_02:55]
FABRINET

[0001408710-25-000036:8k_2_02:56]
CONSOLIDATED STATEMENTS OF CASH FLOWS (Continued)

[0001408710-25-000036:8k_2_02:57]
| Supplemental disclosures | Year Ended |
| (in thousands of U.S. dollars) | June 27,2025 |  | June 28,2024 |
|  | (unaudited) |  |  |
| Cash paid for |  |  |  |
| Interest | $ | — |  |  | $ | 312 |  |
| Taxes | $ | 24,302 |  |  | $ | 16,452 |  |
| Cash received for interest | $ | 33,718 |  |  | $ | 29,783 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment related payables | $ | 40,781 |  |  | $ | 14,380 |  |

[0001408710-25-000036:8k_2_02:58]
FABRINET

[0001408710-25-000036:8k_2_02:59]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES (UNAUDITED)

[0001408710-25-000036:8k_2_02:60]
Reconciliation of GAAP Gross Profit and GAAP Gross Margin to Non-GAAP Gross Profit and Non-GAAP Gross Margin

[0001408710-25-000036:8k_2_02:61]
|  | Three Months Ended |  | Year Ended |
| (in thousands of U.S. dollars) | June 27,2025 |  | June 28,2024 |  | June 27,2025 |  | June 28,2024 |
| Revenues | $ | 909,692 |  |  |  |  | $ | 753,261 |  |  |  |  | $ | 3,419,327 |  |  |  |  | $ | 2,882,967 |  |  |  |
| Gross profit (GAAP) | $ | 111,291 |  |  | 12.2 | % |  | $ | 92,449 |  |  | 12.3 | % |  | $ | 413,349 |  |  | 12.1 | % |  | $ | 356,118 |  |  | 12.4 | % |
| Share-based compensation expenses | 2,573 |  |  |  |  | 1,776 |  |  |  |  | 10,456 |  |  |  |  | 7,203 |  |  |  |
| Gross profit (Non-GAAP) | $ | 113,864 |  |  | 12.5 | % |  | $ | 94,225 |  |  | 12.5 | % |  | $ | 423,805 |  |  | 12.4 | % |  | $ | 363,321 |  |  | 12.6 | % |

[0001408710-25-000036:8k_2_02:62]
Reconciliation of GAAP Operating Profit and GAAP Operating Margin to Non-GAAP Operating Profit and Non-GAAP Operating Margin

[0001408710-25-000036:8k_2_02:63]
|  | Three Months Ended |  | Year Ended |
| (in thousands of U.S. dollars) | June 27,2025 |  | June 28,2024 |  | June 27,2025 |  | June 28,2024 |
| Revenues | $ | 909,692 |  |  |  |  | $ | 753,261 |  |  |  |  | $ | 3,419,327 |  |  |  |  | $ | 2,882,967 |  |  |  |
| Operating profit (GAAP) | $ | 89,056 |  |  | 9.8 | % |  | $ | 73,309 |  |  | 9.7 | % |  | $ | 324,447 |  |  | 9.5 | % |  | $ | 277,605 |  |  | 9.6 | % |
| Share-based compensation expenses | 8,101 |  |  |  |  | 6,934 |  |  |  |  | 33,004 |  |  |  |  | 28,374 |  |  |  |
| Restructuring and other related costs | 69 |  |  |  |  | 32 |  |  |  |  | 1,436 |  |  |  |  | 32 |  |  |  |
| Legal and litigation costs | 250 |  |  |  |  | — |  |  |  |  | 1,077 |  |  |  |  | — |  |  |  |
| Severance payment and others | — |  |  |  |  | — |  |  |  |  | 748 |  |  |  |  | — |  |  |  |
| Operating profit (Non-GAAP) | $ | 97,476 |  |  | 10.7 | % |  | $ | 80,275 |  |  | 10.7 | % |  | $ | 360,712 |  |  | 10.5 | % |  | $ | 306,011 |  |  | 10.6 | % |

[0001408710-25-000036:8k_2_02:64]
FABRINET

[0001408710-25-000036:8k_2_02:65]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES (UNAUDITED)

[0001408710-25-000036:8k_2_02:66]
Reconciliation of GAAP Net Income and EPS to Non-GAAP Net Income and EPS

[0001408710-25-000036:8k_2_02:67]
|  | Three Months Ended |  | Year Ended |
|  | June 27,2025 |  | June 28,2024 |  | June 27,2025 |  | June 28,2024 |
| (in thousands of U.S. dollars, except per share data) | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |
| GAAP measures | $ | 87,207 |  |  | $ | 2.42 |  |  | $ | 81,066 |  |  | $ | 2.22 |  |  | $ | 332,527 |  |  | $ | 9.17 |  |  | $ | 296,181 |  |  | $ | 8.10 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 2,573 |  |  | 0.07 |  |  | 1,776 |  |  | 0.05 |  |  | 10,456 |  |  | 0.29 |  |  | 7,203 |  |  | 0.20 |  |
| Total related to cost of revenues | 2,573 |  |  | 0.07 |  |  | 1,776 |  |  | 0.05 |  |  | 10,456 |  |  | 0.29 |  |  | 7,203 |  |  | 0.20 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 5,528 |  |  | 0.15 |  |  | 5,158 |  |  | 0.14 |  |  | 22,548 |  |  | 0.62 |  |  | 21,171 |  |  | 0.58 |  |
| Legal and litigation costs | 250 |  |  | 0.01 |  |  | — |  |  | — |  |  | 1,077 |  |  | 0.03 |  |  | — |  |  | — |  |
| Severance payment and others | — |  |  | — |  |  | — |  |  | — |  |  | 748 |  |  | 0.02 |  |  | — |  |  | — |  |
| Total related to selling, general and administrative expenses | 5,778 |  |  | 0.16 |  |  | 5,158 |  |  | 0.14 |  |  | 24,373 |  |  | 0.67 |  |  | 21,171 |  |  | 0.59 |  |
| Related to other income and expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other related costs | 69 |  |  | 0.00 |  |  | 32 |  |  | 0.00 |  |  | 1,436 |  |  | 0.04 |  |  | 32 |  |  | 0.00 |  |
| Amortization of deferred debt issuance costs | — |  |  | — |  |  | 8 |  |  | 0.00 |  |  | — |  |  | — |  |  | 32 |  |  | 0.00 |  |
| Total related to other income and expense | 69 |  |  | 0.00 |  |  | 40 |  |  | 0.00 |  |  | 1,436 |  |  | 0.04 |  |  | 64 |  |  | 0.00 |  |
| Total related to net income & EPS | 8,420 |  |  | 0.23 |  |  | 6,974 |  |  | 0.19 |  |  | 36,265 |  |  | 1.00 |  |  | 28,438 |  |  | 0.78 |  |
| Non-GAAP measures | $ | 95,627 |  |  | $ | 2.65 |  |  | $ | 88,040 |  |  | $ | 2.41 |  |  | $ | 368,792 |  |  | $ | 10.17 |  |  | $ | 324,619 |  |  | $ | 8.88 |  |
| Shares used in computing diluted net income per share (in thousands of shares) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  | 36,084 |  |  |  |  | 36,533 |  |  |  |  | 36,267 |  |  |  |  | 36,564 |  |
| Non-GAAP diluted shares |  |  | 36,084 |  |  |  |  | 36,533 |  |  |  |  | 36,267 |  |  |  |  | 36,564 |  |

[0001408710-25-000036:8k_2_02:68]
FABRINET

[0001408710-25-000036:8k_2_02:69]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW (UNAUDITED)

[0001408710-25-000036:8k_2_02:70]
| (in thousands of U.S. dollars) |  | Three Months Ended |  | Year Ended |
|  |  | June 27,2025 |  | June 28,2024 |  | June 27,2025 |  | June 28,2024 |
| Net cash provided by operating activities |  | $ | 55,093 |  |  | $ | 83,062 |  |  | $ | 328,365 |  |  | $ | 413,146 |  |
| Less: Purchase of property, plant and equipment |  | (50,410) |  |  | (12,703) |  |  | (121,078) |  |  | (47,528) |  |
| Non-GAAP free cash flow |  | $ | 4,683 |  |  | $ | 70,359 |  |  | $ | 207,287 |  |  | $ | 365,618 |  |

[0001408710-25-000036:8k_2_02:71]
FABRINET

[0001408710-25-000036:8k_2_02:72]
GUIDANCE FOR QUARTER ENDING SEPTEMBER 26, 2025

[0001408710-25-000036:8k_2_02:73]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-25-000036:8k_2_02:74]
|  | DilutedEPS |
| GAAP net income per diluted share | $2.48 to $2.63 |
| Related to cost of revenues: |  |
| Share-based compensation expenses | 0.10 |
| Total related to cost of revenues | 0.10 |
| Related to selling, general and administrative expenses: |  |
| Share-based compensation expenses | 0.17 |
| Total related to selling, general and administrative expenses | 0.17 |
| Total related to net income & EPS | 0.27 |
| Non-GAAP net income per diluted share | $2.75 to $2.90 |

## item 5.02 — body, verbatim

[0001408710-25-000036:8k_body:1]
Item 5.02    Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001408710-25-000036:8k_body:2]
Fiscal 2026 Executive Incentive Plan

[0001408710-25-000036:8k_body:3]
On August 12, 2025, the Compensation Committee (the “Compensation Committee”) of the board of directors of Fabrinet adopted an executive incentive plan (the “Cash Bonus Plan”) for the Company’s fiscal year ending June 26, 2026 (“fiscal 2026”). The Cash Bonus Plan is an incentive program designed to motivate participants to achieve the Company’s financial objectives, and to reward them for their achievements when those objectives are met. All of the Company’s executive officers pursuant to Section 16 of the Exchange Act are eligible to participate in the Cash Bonus Plan (individually, a “Participant,” and collectively, the “Participants”). The Cash Bonus Plan provides for target and maximum bonus amounts as set forth in the table below. The maximum bonus that a Participant may receive under the Cash Bonus Plan is 120% of such Participant’s target bonus.

[0001408710-25-000036:8k_body:4]
Name

[0001408710-25-000036:8k_body:5]
Fiscal 2026 Target Bonus

[0001408710-25-000036:8k_body:6]
Fiscal 2026 Maximum Bonus

[0001408710-25-000036:8k_body:7]
Seamus Grady

[0001408710-25-000036:8k_body:8]
$1,932,000

[0001408710-25-000036:8k_body:9]
$2,318,400

[0001408710-25-000036:8k_body:10]
Dr. Harpal Gill

[0001408710-25-000036:8k_body:11]
$1,462,500

[0001408710-25-000036:8k_body:12]
$1,755,000

[0001408710-25-000036:8k_body:13]
Csaba Sverha

[0001408710-25-000036:8k_body:14]
THB 24,380,400

[0001408710-25-000036:8k_body:15]
THB 29,256,480

[0001408710-25-000036:8k_body:16]
Edward Archer

[0001408710-25-000036:8k_body:17]
$459,000

[0001408710-25-000036:8k_body:18]
$550,800

[0001408710-25-000036:8k_body:19]
The amount of bonus actually paid to a Participant under the Cash Bonus Plan will be based 50% on the extent of achievement of a fiscal 2026 revenue metric and 50% on the extent of achievement of a fiscal 2026 non-GAAP operating margin metric. As achievement of each financial metric is considered independently from the other, the Company must meet a threshold for each metric in order for a Participant to receive any credit for that metric. If the Company achieves 100% of a target financial metric, bonuses would be paid out at 100% of the target amount with respect to that financial metric component. If the Company achieves 105% or more of a target financial metric, bonuses would be paid out at 120% of the target amount (which is the maximum) with respect to that financial metric component. Achievement of the revenue or non-GAAP operating margin metric for fiscal 2026 at a level between 100% and 105% of the target metric will result in a bonus amount for the applicable metric that is scaled from 100% to 120% of the target amount in a linear fashion. Achievement of the revenue or non-GAAP operating margin metric for fiscal 2026 at a level between 90% and 100% of the target metric will result in a bonus amount for the applicable metric that is scaled from 20% to 100% of the target amount in a linear fashion.

[0001408710-25-000036:8k_body:20]
Fiscal 2026 Salaries

[0001408710-25-000036:8k_body:21]
On August 12, 2025, the Compensation Committee approved an increase to the annual base salaries of the Company’s

[0001408710-25-000036:8k_body:22]
named executive officers set forth below, effective as of June 28, 2026, the first day of fiscal 2026.

[0001408710-25-000036:8k_body:23]
Name

[0001408710-25-000036:8k_body:24]
Title

[0001408710-25-000036:8k_body:25]
Previous Annual Base Salary

[0001408710-25-000036:8k_body:26]
Fiscal 2026 Annual Base Salary

[0001408710-25-000036:8k_body:27]
Change

[0001408710-25-000036:8k_body:28]
Seamus Grady

[0001408710-25-000036:8k_body:29]
Chief Executive Officer

[0001408710-25-000036:8k_body:30]
$1,350,000

[0001408710-25-000036:8k_body:31]
$1,380,000

[0001408710-25-000036:8k_body:32]
2.2%

[0001408710-25-000036:8k_body:33]
Dr. Harpal Gill

[0001408710-25-000036:8k_body:34]
President and Chief Operating Officer

[0001408710-25-000036:8k_body:35]
$1,100,000

[0001408710-25-000036:8k_body:36]
$1,125,000

[0001408710-25-000036:8k_body:37]
2.3%

[0001408710-25-000036:8k_body:38]
Csaba Sverha

[0001408710-25-000036:8k_body:39]
Executive Vice President, Chief Financial Officer

[0001408710-25-000036:8k_body:40]
$625,000(1)

[0001408710-25-000036:8k_body:41]
THB 24,380,400

[0001408710-25-000036:8k_body:42]
5.6%(2)

[0001408710-25-000036:8k_body:43]
Edward Archer

[0001408710-25-000036:8k_body:44]
Executive Vice President, Sales & Marketing

[0001408710-25-000036:8k_body:45]
$520,000

[0001408710-25-000036:8k_body:46]
$540,000

[0001408710-25-000036:8k_body:47]
3.8%

[0001408710-25-000036:8k_body:48]
(1)    Mr. Sverha’s fiscal 2025 salary was paid in his home currency of Thai baht using the Fabrinet Corporate Group USD to THB Exchange Rate, which was the Bank of Thailand’s middle rate (midpoint of the bid and ask rates) as of June 28, 2024, of 36.94 Thai baht to 1.0 U.S. dollar. This resulted in a fiscal 2025 salary for Mr. Sverha of THB 23,087,500.

[0001408710-25-000036:8k_body:49]
(2)     Percentage increase is based on Mr. Sverha’s previous annual base salary in Thai baht.

[0001408710-25-000036:8k_body:50]
Equity Award Grants

[0001408710-25-000036:8k_body:51]
On August 12, 2025, the Compensation Committee approved the grant, effective as of August 21, 2025 (the “Grant Date”), of the following dollar values of restricted share units (“RSUs”), performance share units (“PSUs”) and “stretch” PSUs (“Stretch PSUs”), rounded up to the nearest whole share, to the Company’s named executive officers as a component of their fiscal 2026 compensation:

[0001408710-25-000036:8k_body:52]
Name

[0001408710-25-000036:8k_body:53]
Grant Date Value of RSUs

[0001408710-25-000036:8k_body:54]
Grant Date Value of PSUs

[0001408710-25-000036:8k_body:55]
Grant Date Value of “Stretch” PSUs

[0001408710-25-000036:8k_body:56]
Seamus Grady

[0001408710-25-000036:8k_body:57]
$3,150,000

[0001408710-25-000036:8k_body:58]
$3,150,000

[0001408710-25-000036:8k_body:59]
$3,150,000

[0001408710-25-000036:8k_body:60]
Dr. Harpal Gill

[0001408710-25-000036:8k_body:61]
$1,730,000

[0001408710-25-000036:8k_body:62]
$1,730,000

[0001408710-25-000036:8k_body:63]
$1,730,000

[0001408710-25-000036:8k_body:64]
Csaba Sverha

[0001408710-25-000036:8k_body:65]
$1,040,000

[0001408710-25-000036:8k_body:66]
$1,040,000

[0001408710-25-000036:8k_body:67]
$1,040,000

[0001408710-25-000036:8k_body:68]
Edward Archer

[0001408710-25-000036:8k_body:69]
$840,000

[0001408710-25-000036:8k_body:70]
$840,000

[0001408710-25-000036:8k_body:71]
$840,000

[0001408710-25-000036:8k_body:72]
The grants will be made under the Company’s 2020 Equity Incentive Plan. The RSUs will be scheduled to vest in equal annual installments over a period of three years on each anniversary of the Grant Date, subject to the individual’s continued service with the Company through each such vesting date.

[0001408710-25-000036:8k_body:73]
The PSUs will vest, if at all, following a 2-year performance period, on the date the Compensation Committee certifies achievement of the performance criteria set forth below, subject to the individual’s continued service with the Company through such vesting date. Vesting of the PSUs will be based 50% on achievement of a cumulative fiscal 2026 and fiscal 2027 revenue goal (the “PSU Revenue Target”) and 50% on achievement of a cumulative fiscal 2026 and fiscal 2027 non-GAAP operating margin goal (the “PSU Operating Margin Target”). As achievement of each financial goal is considered independently from the other, the Company must meet a threshold for each goal in order for an individual to receive any credit for that goal. If the Company achieves 100% or more of a target financial goal, the PSUs will vest as to 100% of the PSUs allocated to that financial goal. Achievement of the PSU Revenue Target or the PSU Operating Margin Target at a level between 90% and 100% will result in a number of shares vesting for the applicable goal that is scaled from 20% to 100% of the PSUs allocated to that goal in a linear fashion.

[0001408710-25-000036:8k_body:74]
The Stretch PSUs will vest, if at all, following a 2-year performance period, on the date the Compensation Committee certifies achievement of the performance criteria set forth below, subject to the individual’s continued service with the Company through such vesting date. Vesting of the Stretch PSUs will be based 50% on achievement of a cumulative fiscal 2026 and fiscal 2027 revenue goal that is 5% higher than the PSU Revenue Target (the “Stretch PSU Revenue Target”) and 50% on achievement of a cumulative fiscal 2026 and fiscal 2027 non-GAAP operating margin goal that is 5% higher than the PSU Operating Margin Target (the “Stretch PSU Operating Margin Target”). As achievement of each financial goal is considered independently from the other, the Company must meet a threshold for each goal in order for an individual to receive any credit for that goal. The Company must exceed the PSU Revenue Target or the PSU Operating Margin Target in order for any of the Stretch PSUs to vest. If the Company achieves 100% or more of a target financial goal, the Stretch PSUs will vest as to 100% of the PSUs allocated to that financial goal. Achievement of the Stretch PSU Revenue Target at a level between its threshold PSU Revenue Target and 100% will result in a number of shares vesting for that goal that is scaled from 0% to 100% of the PSUs allocated to that goal in a linear fashion. Achievement of the Stretch PSU Operating Margin Target at a level between its threshold PSU Operating Margin Target and 100% will result in a number of shares vesting for that goal that is scaled from 0% to 100% of the PSUs allocated to that goal in a linear fashion.

[0001408710-25-000036:8k_body:75]
In the event of a change in control of Fabrinet, the awards of PSUs and Stretch PSUs described above that are then outstanding will be treated as follows. To the extent that the performance period has not yet been completed as of the change in control, (1) the performance period for any Company revenue goals will be shortened to end shortly before the change in control and achievement of revenue will be measured based on goals that are prorated for the shortened performance period, and (2) the performance period for any Company operating margin goals will be deemed to be the last four consecutive fiscal quarters of the Company completed before the change in control. Any PSUs for which such applicable goal is deemed achieved will be scheduled to vest subject to the individual’s continued service with Fabrinet through the last date of the award’s original performance period, and will be treated as a time-based award that may be eligible for certain vesting acceleration under Mr. Grady’s Change in Control and Severance Agreement or the Fabrinet Executive Change in Control and Severance Plan, as applicable, upon a qualifying termination during a specified change in control period.
