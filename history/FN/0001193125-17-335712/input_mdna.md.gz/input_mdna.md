# FN MD&A — 0001193125-17-335712


## mdna

[0001193125-17-335712:mdna:1]
[same as prior period, unchanged from 0001193125-17-164153:mdna:1]

[0001193125-17-335712:mdna:2]
[same as prior period, unchanged from 0001193125-17-164153:mdna:2]

[0001193125-17-335712:mdna:3]
[same as prior period, unchanged from 0001193125-17-164153:mdna:3]

[0001193125-17-335712:mdna:4]
|  | • |  | our expectation that the portion of our future revenues attributable to customers in regions outside of North America will continue to increase compared with the portion of those revenues for the three months ended September 29, 2017; |

[0001193125-17-335712:mdna:5]
[same as prior period, unchanged from 0001193125-17-164153:mdna:5]

[0001193125-17-335712:mdna:6]
|  | • |  | our expectation that our fiscal year 2018 selling, general and administrative (“SG&A”) expenses will increase on an absolute dollar basis and decrease as a percentage of revenue compared to fiscal year 2017; |

[0001193125-17-335712:mdna:7]
[same as prior period, unchanged from 0001193125-17-164153:mdna:7]

[0001193125-17-335712:mdna:8]
[same as prior period, unchanged from 0001193125-17-164153:mdna:8]

[0001193125-17-335712:mdna:9]
[same as prior period, unchanged from 0001193125-17-164153:mdna:9]

[0001193125-17-335712:mdna:10]
[same as prior period, unchanged from 0001193125-17-164153:mdna:10]

[0001193125-17-335712:mdna:11]
[same as prior period, unchanged from 0001193125-17-164153:mdna:11]

[0001193125-17-335712:mdna:12]
[same as prior period, unchanged from 0001193125-17-164153:mdna:12]

[0001193125-17-335712:mdna:13]
[same as prior period, unchanged from 0001193125-17-164153:mdna:13]

[0001193125-17-335712:mdna:14]
[same as prior period, unchanged from 0001193125-17-164153:mdna:14]

[0001193125-17-335712:mdna:15]
[same as prior period, unchanged from 0001193125-17-164153:mdna:15]

[0001193125-17-335712:mdna:16]
[same as prior period, unchanged from 0001193125-17-164153:mdna:16]

[0001193125-17-335712:mdna:17]
[same as prior period, unchanged from 0001193125-17-164153:mdna:17]

[0001193125-17-335712:mdna:18]
[same as prior period, unchanged from 0001193125-17-164153:mdna:18]

[0001193125-17-335712:mdna:19]
[same as prior period, unchanged from 0001193125-17-164153:mdna:19]

[0001193125-17-335712:mdna:20]
We provide advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment
manufacturers (“OEMs”) of complex products such as optical communication components, modules and sub-systems, industrial lasers, medical devices and sensors. We offer a broad range of advanced
optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, complex printed circuit board assembly, advanced packaging, integration, final
assembly and test. Although, we focus primarily on low-volume production of a wide variety of high complexity products, which we refer to as “low-volume, high-mix,” we also have the capability to accommodate high-volume production. Based on our experience with, and positive feedback we have received from our customers, we believe we are a global leader in
providing these services to the optical communications, industrial lasers and automotive markets.

[0001193125-17-335712:mdna:21]
Our customer base includes companies in
complex industries that require advanced precision manufacturing capabilities such as optical communications, industrial lasers, automotive and sensors. The products that we manufacture for our OEM customers include selective switching products;
tunable transponders and transceivers; active optical cables; solid state, diode-pumped, gas and fiber lasers; and sensors. In many cases, we are the sole outsourced manufacturing partner used by our customers for the products that we produce for
them.

[0001193125-17-335712:mdna:22]
We also design and fabricate application-specific crystals, lenses, prisms, mirrors, laser components, and substrates (collectively
referred to as “customized optics”) and other custom and standard borosilicate, clear fused quartz, and synthetic fused silica glass products (collectively referred to as “customized glass”). We incorporate our customized optics
and glass into many of the products we manufacture for our OEM customers, and we also sell customized optics and glass in the merchant market.

[0001193125-17-335712:mdna:23]
Business acquisition

[0001193125-17-335712:mdna:24]
On
September 14, 2016, we acquired 100% shareholding in Global CEM Solutions, Limited and all of its subsidiaries (“Exception EMS”), a privately-held group located in Wiltshire, United Kingdom, for cash consideration of
approximately $13.0 million, net of cash acquired. We subsequently changed the name of Exception EMS to Fabrinet UK Ltd. (“Fabrinet UK”). Fabrinet UK provides contract electronics manufacturing services primarily to the European
electronics market with innovative solutions, adding value to the design, manufacture and testing of printed circuit board assemblies. Its customers include industrial, energy, aerospace and defense companies, with approximately 80% of its revenue
derived from customers in Europe. See Note 8 - Business acquisition to the unaudited condensed consolidated financial statements for further details.

[0001193125-17-335712:mdna:25]
[same as prior period, unchanged from 0001193125-17-164153:mdna:27]

[0001193125-17-335712:mdna:26]
We believe our ability to
expand our relationships with existing customers and attract new customers is due to a number of factors, including our broad range of complex engineering and manufacturing service offerings, flexible low-cost
manufacturing platform, process optimization capabilities, advanced supply chain management, excellent customer service, and experienced management team. While we expect the prices we charge for our manufactured products to decrease over time
(partly as a result of competitive market forces), we still believe we will be able to maintain favorable pricing for our services because of our ability to reduce cycle time, adjust our product mix by focusing on more complicated products, improve
product quality and yields, and reduce material costs for the products we manufacture. We believe these capabilities have enabled us to help our OEM customers reduce their manufacturing costs while maintaining or improving the design, quality,
reliability, and delivery times for their products.

[0001193125-17-335712:mdna:27]
[same as prior period, unchanged from 0001193125-17-164153:mdna:30]

[0001193125-17-335712:mdna:28]
We generate revenues from three geographic regions: North America, Asia-Pacific and Europe. Revenues are attributed to a particular geographic
area based on the bill-to location of our customers, notwithstanding that our customers may ultimately ship their products to end customers in a different geographic region. The majority of our revenues are
derived from our manufacturing facilities in Asia-Pacific.

[0001193125-17-335712:mdna:29]
The percentage of our revenues generated from a
bill-to location outside of North America increased from 50.0% in the three months ended September 30, 2016 to 56.1% in the three months ended September 29, 2017, primarily because of an increase in
sales to our customers in Asia-Pacific. We expect that the portion of our future revenues attributable to customers in regions outside North America will continue to increase as compared with the portion of revenues attributable to such customers
during the three months ended September 29, 2017.

[0001193125-17-335712:mdna:30]
[same as prior period, unchanged from 0001193125-17-164153:mdna:33]

[0001193125-17-335712:mdna:31]
|  |  | Three Months Ended |  |
|  |  | September 29,2017 |  |  | September 30,2016 |  |
| North America |  |  | 43.9 | % |  |  | 50.0 | % |
| Asia-Pacific |  |  | 40.0 |  |  |  | 34.6 |  |
| Europe |  |  | 16.1 |  |  |  | 15.4 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-17-335712:mdna:32]
[same as prior period, unchanged from 0001193125-17-164153:mdna:35]

[0001193125-17-335712:mdna:33]
We enter into supply agreements with our customers which generally have an initial term of up to three years, subject to automatic renewals for
subsequent one-year terms unless expressly terminated. Although there are no minimum purchase requirements in our supply agreements, our customers provide us with rolling forecasts of their demand
requirements. Our supply agreements generally include provisions for pricing and periodic review of pricing, consignment of our customer’s unique production equipment to us, and the sharing of benefits from cost-savings derived from our
efforts. We are generally required to purchase materials, which may include long lead-time materials and materials that are subject to minimum order quantities and/or non-cancelable or non-returnable terms, to meet the stated demands of our customers. After procuring materials, we manufacture products for our customers based on purchase orders that contain terms regarding product quantities,
delivery locations and delivery dates. Our customers generally are obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by our customers within a specified period of
time, or are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under our contracts. Once
materials are designated as either excess or obsolete inventory, our customers are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products.

[0001193125-17-335712:mdna:34]
[same as prior period, unchanged from 0001193125-17-164153:mdna:38]

[0001193125-17-335712:mdna:35]
[same as prior period, unchanged from 0001193125-17-164153:mdna:39]

[0001193125-17-335712:mdna:36]
[same as prior period, unchanged from 0001193125-17-164153:mdna:40]

[0001193125-17-335712:mdna:37]
Our infrastructure costs are comprised of depreciation, utilities, facilities management and
overhead costs. Most of our facility leases are long-term agreements. Our depreciation costs include buildings and fixed assets, primarily at our Pinehurst campus in Thailand, and capital equipment located at each of our manufacturing locations.

[0001193125-17-335712:mdna:38]
We expect to incur incremental costs of revenue as a result of our planned expansion into new geographic markets, though we are not able
to determine the amount of these incremental expenses.

[0001193125-17-335712:mdna:39]
[same as prior period, unchanged from 0001193125-17-164153:mdna:45]

[0001193125-17-335712:mdna:40]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative and other support
personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other general expenses not related to cost of
revenues. In fiscal year 2018, we expect our SG&A expenses will increase on an absolute dollar basis and decrease as a percentage of revenue compared with fiscal year 2017 due to higher share-based compensation expenses as a result of restricted
share units and performance share units granted to executives in August 2017.

[0001193125-17-335712:mdna:41]
The compensation committee of our board of directors
approved a fiscal year 2018 executive incentive plan with quantitative objectives that are based solely on achieving certain revenue targets and non-GAAP gross margin targets for our fiscal year ending June
29, 2018. Bonuses under the fiscal year 2018 executive incentive plan are payable after the end of fiscal year 2018. In fiscal year 2017, the compensation committee approved a fiscal year 2017 executive incentive plan with quantitative objectives
that are based solely on achieving certain revenue targets and non-GAAP gross margin targets for our fiscal year ended June 30, 2017. In the three months ended September 29, 2017, the compensation
committee awarded bonuses to our executive employees for Company achievements of performance under the fiscal 2017 executive incentive plan. Discretionary merit-based bonus awards were also available to our
non-executive employees and were payable as of September 29, 2017.

[0001193125-17-335712:mdna:42]
[same as prior period, unchanged from 0001193125-17-164153:mdna:50]

[0001193125-17-335712:mdna:43]
[same as prior period, unchanged from 0001193125-17-164153:mdna:51]

[0001193125-17-335712:mdna:44]
As a
result of our international operations, we are exposed to foreign exchange risk arising from various currency exposures primarily with respect to the Thai baht. Although a majority of our total revenues is denominated in U.S. dollars, a substantial
portion of our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rate between the Thai baht and the U.S. dollar has fluctuated substantially in recent years and may continue to fluctuate substantially in
the future. We report our financial results in U.S. dollars and our results of operations have been and may continue to be negatively impacted owing to appreciation of the Thai baht against the U.S. dollar. Smaller portions of our expenses are
incurred in a variety of other currencies, including RMB, GBP, Canadian dollars, Euros, and Japanese yen, the appreciation of which may also negatively impact our financial results.

[0001193125-17-335712:mdna:45]
In order to manage the risks arising from fluctuations in foreign currency exchange rates, we use derivative instruments. We may enter into
exchange currency forward or put option contracts to manage foreign currency exposures associated with certain assets and liabilities and other forecasted foreign currency transactions and may designate these instruments as hedging instruments. The
forward and put option contracts generally have maturities of up to 12 months. All foreign currency exchange contracts are recognized in the unaudited condensed consolidated balance sheet at fair value. Gain or loss on our forward and put option
contracts generally offset the assets, liabilities, and transactions economically hedged.

[0001193125-17-335712:mdna:46]
[same as prior period, unchanged from 0001193125-17-164153:mdna:54]

[0001193125-17-335712:mdna:47]
|  |  | As of September 29, 2017 |  |  | As of June 30, 2017 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 454,042 |  |  | $ | 13,606 |  |  |  | 53.7 |  |  |  | 395,123 |  |  | $ | 11,628 |  |  |  | 47.3 |  |
| RMB |  |  | 21,100 |  |  |  | 3,179 |  |  |  | 12.6 |  |  |  | 26,965 |  |  |  | 3,980 |  |  |  | 16.2 |  |
| GBP |  |  | 6,363 |  |  |  | 8,541 |  |  |  | 33.7 |  |  |  | 6,896 |  |  |  | 8,982 |  |  |  | 36.5 |  |
| Total |  |  |  |  |  | $ | 25,326 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 24,590 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,785,719 |  |  | $ | 53,513 |  |  |  | 84.3 |  |  |  | 1,875,338 |  |  | $ | 55,189 |  |  |  | 82.7 |  |
| RMB |  |  | 33,350 |  |  |  | 5,025 |  |  |  | 7.9 |  |  |  | 28,451 |  |  |  | 4,200 |  |  |  | 6.3 |  |
| GBP |  |  | 3,669 |  |  |  | 4,925 |  |  |  | 7.8 |  |  |  | 5,625 |  |  |  | 7,326 |  |  |  | 11.0 |  |
| Total |  |  |  |  |  | $ | 63,463 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 66,715 |  |  |  | 100.0 |  |

[0001193125-17-335712:mdna:48]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other
current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and
offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of September 29, 2017 and June 30, 2017, there were $26.0 million and $1.0 million in forward contracts,
respectively, outstanding against forecasted Thai baht payables.

[0001193125-17-335712:mdna:49]
The RMB assets represent cash and cash equivalents, trade accounts
receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of September 29, 2017 and June 30, 2017, we did not have any derivative contracts
denominated in RMB.

[0001193125-17-335712:mdna:50]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent
trade accounts payable and other payables. As of September 29, 2017 and June 30, 2017, we did not have any derivative contracts denominated in GBP.

[0001193125-17-335712:mdna:51]
For the three months ended September 29, 2017 and September 30, 2016, we recorded loss of $10 thousand and $0.1 million,
respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001193125-17-335712:mdna:52]
[same as prior period, unchanged from 0001193125-17-164153:mdna:60]

[0001193125-17-335712:mdna:53]
[same as prior period, unchanged from 0001193125-17-164153:mdna:61]

[0001193125-17-335712:mdna:54]
[same as prior period, unchanged from 0001193125-17-164153:mdna:62]

[0001193125-17-335712:mdna:55]
[same as prior period, unchanged from 0001193125-17-164153:mdna:63]

[0001193125-17-335712:mdna:56]
[same as prior period, unchanged from 0001193125-17-164153:mdna:64]

[0001193125-17-335712:mdna:57]
[same as prior period, unchanged from 0001193125-17-164153:mdna:65]

[0001193125-17-335712:mdna:58]
Under the Administration Rules,
foreign-invested enterprises may only buy, sell, or remit foreign currencies at banks authorized to conduct foreign exchange business after providing valid commercial documents and relevant supporting documents and, in the case of capital account
item transactions, obtaining approval from SAFE. Capital investments by foreign-invested enterprises outside of the PRC are also subject to limitations, which include approvals by the Ministry of Commerce, SAFE and the State Development and Reform
Commission.

[0001193125-17-335712:mdna:59]
Circular 142 regulates the conversion by a foreign-invested company of foreign currency into RMB by restricting how the
converted RMB may be used. Circular 142 requires that the registered capital of a foreign-invested enterprise settled in RMB converted from foreign currencies may only be used for purposes within the business scope approved by

[0001193125-17-335712:mdna:60]
the applicable governmental authority and may not be used for equity investments within the PRC. In addition, SAFE strengthened its oversight of the flow and use of the registered capital of
foreign-invested enterprises settled in RMB converted from foreign currencies. The use of such RMB capital may not be changed without SAFE’s approval and may not be used to repay RMB loans if the proceeds of such loans have not been used.

[0001193125-17-335712:mdna:61]
[same as prior period, unchanged from 0001193125-17-164153:mdna:69]

[0001193125-17-335712:mdna:62]
[same as prior period, unchanged from 0001193125-17-164153:mdna:70]

[0001193125-17-335712:mdna:63]
[same as prior period, unchanged from 0001193125-17-164153:mdna:71]

[0001193125-17-335712:mdna:64]
[same as prior period, unchanged from 0001193125-17-164153:mdna:72]

[0001193125-17-335712:mdna:65]
Our effective tax rate is a function of the mix of tax rates in the various jurisdictions in which we do business. We are domiciled in the
Cayman Islands. Under the current laws of the Cayman Islands, we are not subject to tax in the Cayman Islands on income or capital gains. We have received this undertaking for a 20-year period ending
August 24, 2019, and after the expiration date, we may request a renewal with the office of the Clerk of the Cabinet for another twenty years.

[0001193125-17-335712:mdna:66]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of
Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption is currently available to us through June 2020 on income generated from projects to manufacture certain products at our Pinehurst campus. Such
preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15
years from the date on which preferential tax treatment was granted. In March 2016, the Thailand Revenue Department announced a permanent decrease of corporate income tax rates to 20% for tax periods beginning on or after January 1, 2016. As a
result, corporate income tax rates for our Thai subsidiary are expected to remain at 20% from fiscal year 2017 onward.

[0001193125-17-335712:mdna:67]
Critical Accounting Policies
and Use of Estimates

[0001193125-17-335712:mdna:68]
We prepare our unaudited condensed consolidated financial statements in conformity with U.S. GAAP, which requires
us to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent liabilities on the date of the unaudited condensed consolidated financial statements and the reported amounts of revenues
and expenses during the financial reporting period. We continually evaluate these estimates and assumptions based on the most recently available information, our own historical experience and on various other assumptions that we believe to be
reasonable under the circumstances, the results form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Because the use of estimates is an integral component of the
financial reporting process, actual results could differ from those estimates. Some of our accounting policies require higher degrees of judgment than others in their application. We consider the policies discussed below to be critical to an
understanding of our unaudited condensed consolidated financial statements, as their application places the most significant demands on our management’s judgment.

[0001193125-17-335712:mdna:69]
Our critical accounting policies are disclosed in our Annual Report on Form 10-K for the fiscal year
ended June 30, 2017. The adoption of new accounting policies and the accounting standards are disclosed in Note 2 – Accounting policies to the unaudited condensed consolidated financial statements.

[0001193125-17-335712:mdna:70]
[same as prior period, unchanged from 0001193125-17-164153:mdna:79]

[0001193125-17-335712:mdna:71]
The following table sets forth a summary of our unaudited condensed consolidated statements of operations and comprehensive income. Note that period-to-period comparisons of operating results should not be relied upon as indicative of future performance.

[0001193125-17-335712:mdna:72]
| (amount in thousands) |  | Three Months Ended |  |
|  | September 29,2017 |  |  | September 30,2016 |  |
| Revenues |  | $ | 357,313 |  |  | $ | 332,043 |  |
| Cost of revenues |  |  | (316,981 | ) |  |  | (292,435 | ) |
| Gross profit |  |  | 40,332 |  |  |  | 39,608 |  |
| Selling, general and administrative expenses |  |  | (15,678 | ) |  |  | (15,832 | ) |
| Operating income |  |  | 24,654 |  |  |  | 23,776 |  |
| Interest income |  |  | 809 |  |  |  | 437 |  |
| Interest expense |  |  | (853 | ) |  |  | (1,322 | ) |
| Foreign exchange (loss) gain, net |  |  | (1,934 | ) |  |  | 1,657 |  |
| Other income |  |  | 97 |  |  |  | 143 |  |
| Income before income taxes |  |  | 22,773 |  |  |  | 24,691 |  |
| Income tax expense |  |  | (1,740 | ) |  |  | (1,925 | ) |
| Net income |  |  | 21,033 |  |  |  | 22,766 |  |
| Other comprehensive income, net of tax |  |  | 554 |  |  |  | 396 |  |
| Net comprehensive income |  | $ | 21,587 |  |  | $ | 23,162 |  |

[0001193125-17-335712:mdna:73]
The following table sets forth a summary of our unaudited condensed consolidated statements of operations and comprehensive
income as a percentage of total revenues for the periods indicated.

[0001193125-17-335712:mdna:74]
|  |  | Three Months Ended |  |
|  |  | September 29,2017 |  |  | September 30,2016 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (88.7 | ) |  |  | (88.1 | ) |
| Gross profit |  |  | 11.3 |  |  |  | 11.9 |  |
| Selling, general and administrative expenses |  |  | (4.4 | ) |  |  | (4.8 | ) |
| Operating income |  |  | 6.9 |  |  |  | 7.1 |  |
| Interest income |  |  | 0.2 |  |  |  | 0.1 |  |
| Interest expense |  |  | (0.2 | ) |  |  | (0.4 | ) |
| Foreign exchange (loss) gain, net |  |  | (0.5 | ) |  |  | 0.5 |  |
| Other income |  |  | 0.0 |  |  |  | 0.1 |  |
| Income before income taxes |  |  | 6.4 |  |  |  | 7.4 |  |
| Income tax expense |  |  | (0.5 | ) |  |  | (0.6 | ) |
| Net income |  |  | 5.9 |  |  |  | 6.9 |  |
| Other comprehensive income, net of tax |  |  | 0.2 |  |  |  | 0.1 |  |
| Net comprehensive income |  |  | 6.1 | % |  |  | 7.0 | % |

[0001193125-17-335712:mdna:75]
[same as prior period, unchanged from 0001193125-17-164153:mdna:85]

[0001193125-17-335712:mdna:76]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 29,2017 |  |  | September 30,2016 |  |
| Optical communications |  | $ | 275,613 |  |  | $ | 256,807 |  |
| Lasers, sensors and other |  |  | 81,700 |  |  |  | 75,236 |  |
| Total |  | $ | 357,313 |  |  | $ | 332,043 |  |

[0001193125-17-335712:mdna:77]
[same as prior period, unchanged from 0001193125-17-164153:mdna:87]

[0001193125-17-335712:mdna:78]
34

[0001193125-17-335712:mdna:79]
Comparison of Three Months Ended September 29, 2017 with Three Months Ended September 30, 2016

[0001193125-17-335712:mdna:80]
[same as prior period, unchanged from 0001193125-17-164153:mdna:89]

[0001193125-17-335712:mdna:81]
Our total revenues increased by $25.3 million, or 7.6%, to $357.3 million for the three months ended September 29, 2017,
compared with $332.0 million for the three months ended September 30, 2016. This increase was primarily due to an increase in our customers’ demand for both optical and non-optical
communications manufacturing services during the three months ended September 29, 2017. Revenues from optical communications products represented 77.1% of our total revenues for the three months ended September 29, 2017, compared to 77.3%
for the three months ended September 30, 2016. We expect revenues from optical communications products, particularly telecom-related products, to decrease in the near term, which we expect will result in an overall decrease in our revenues for
the quarter ending December 29, 2017 as compared to the quarter ended September 29, 2017.

[0001193125-17-335712:mdna:82]
[same as prior period, unchanged from 0001193125-17-164153:mdna:92]

[0001193125-17-335712:mdna:83]
Our cost of revenues increased by $24.5 million, or 8.4%, to $317.0 million, or 88.7% of total revenues, for the three months ended
September 29, 2017, compared with $292.4 million, or 88.1% of total revenues, for the three months ended September 30, 2016. This increase in cost of revenues was primarily due to an increase in sales volume. Cost of revenues also
included share-based compensation expense of $1.9 million for the three months ended September 29, 2017, compared with $1.0 million for the three months ended September 30, 2016.

[0001193125-17-335712:mdna:84]
[same as prior period, unchanged from 0001193125-17-164153:mdna:95]

[0001193125-17-335712:mdna:85]
Our gross
profit increased by $0.7 million, or 1.8%, to $40.3 million, or 11.3% of total revenues, for the three months ended September 29, 2017, compared with $39.6 million, or 11.9% of total revenues, for the three months ended
September 30, 2016.

[0001193125-17-335712:mdna:86]
[same as prior period, unchanged from 0001193125-17-164153:mdna:97]

[0001193125-17-335712:mdna:87]
Our SG&A expenses decreased by $0.2 million, or 1.0%, to $15.7 million, or 4.4% of total revenues, for the three months ended
September 29, 2017, compared with $15.8 million, or 4.8% of total revenues, for the three months ended September 30, 2016. Our SG&A expenses decreased in absolute dollars due primarily to a decrease in expenses relating to merger
and acquisition activities of $1.4 million that were incurred during the three months ended September 30, 2016. These were offset primarily by increases in share-based compensation of $0.4 million and expenses for software maintenance
of $0.2 million.

[0001193125-17-335712:mdna:88]
[same as prior period, unchanged from 0001193125-17-164153:mdna:102]

[0001193125-17-335712:mdna:89]
Our operating income increased by $0.9 million to $24.7 million, or 6.9% of total revenues, for the three months ended
September 29, 2017, compared with $23.8 million, or 7.1% of total revenues, for the three months ended September 30, 2016.

[0001193125-17-335712:mdna:90]
[same as prior period, unchanged from 0001193125-17-164153:mdna:105]

[0001193125-17-335712:mdna:91]
Our
interest income increased by $0.4 million, or 85.1%, to $0.8 million, or 0.2% of total revenues, for the three months ended September 29, 2017, compared with $0.4 million, or 0.1% of total revenues, for the three months ended
September 30, 2016. The increase was primarily due to the higher weighted average interest rate compared to the same period in the last year and an increase in the average balance of our outstanding cash.

[0001193125-17-335712:mdna:92]
Interest expense.

[0001193125-17-335712:mdna:93]
Our
interest expense decreased by $0.4 million to $0.9 million for the three months ended September 29, 2017, compared with $1.3 million for the three months ended September 30, 2016. The decrease was primarily due to a decrease
in the average balance of our bank borrowings.

[0001193125-17-335712:mdna:94]
Foreign exchange (loss) gain, net.

[0001193125-17-335712:mdna:95]
Our foreign exchange (loss) gain, net, decreased by $3.6 million to foreign exchange (loss), net, of $(1.9) million, or (0.5)% of total
revenues, for the three months ended September 29, 2017, compared with foreign exchange gain, net, of $1.7 million, or 0.5% of total revenues, for the three months ended September 30, 2016. The decrease was primarily due to the
fluctuation of foreign currencies, particularly the depreciation of USD against Thai baht.

[0001193125-17-335712:mdna:96]
[same as prior period, unchanged from 0001193125-17-164153:mdna:113]

[0001193125-17-335712:mdna:97]
We recorded income before income taxes of $22.8 million for the three months ended September 29, 2017, compared with
$24.7 million for the three months ended September 30, 2016.

[0001193125-17-335712:mdna:98]
[same as prior period, unchanged from 0001193125-17-164153:mdna:115]

[0001193125-17-335712:mdna:99]
Our provision for income tax reflects an effective tax rate of 6.3% and 6.7% for the three months ended September 29, 2017 and
September 30, 2016, respectively. The decrease was primarily due to the fact that we had higher income not subject to tax during the first quarter of fiscal year 2018 as compared to the same period in fiscal year 2017.

[0001193125-17-335712:mdna:100]
[same as prior period, unchanged from 0001193125-17-164153:mdna:118]

[0001193125-17-335712:mdna:101]
We recorded
net income of $21.0 million, or 5.9% of total revenues, for the three months ended September 29, 2017, compared with $22.8 million, or 6.9% of total revenues, for the three months ended September 30, 2016.

[0001193125-17-335712:mdna:102]
Other comprehensive income.

[0001193125-17-335712:mdna:103]
We recorded other comprehensive income of $0.6 million, or 0.2% of total revenues, for the three months ended September 29, 2017,
compared with other comprehensive income of $0.4 million, or 0.1% of total revenues, for the three months ended September 30, 2016.

[0001193125-17-335712:mdna:104]
[same as prior period, unchanged from 0001193125-17-164153:mdna:124]

[0001193125-17-335712:mdna:105]
Cash Flows and
Working Capital

[0001193125-17-335712:mdna:106]
We primarily finance our operations through cash flow from operations. As of September 29, 2017 and
September 30, 2016, we had cash, cash equivalents, and marketable securities of $263.3 million and $253.6 million, respectively, and outstanding debt of $67.0 million and $70.8 million, respectively.

[0001193125-17-335712:mdna:107]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of
three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents for the three months ended As of September 29, 2017 and September 30, 2016 was 0.9% and 0.5%,
respectively.

[0001193125-17-335712:mdna:108]
Our cash investments are made in accordance with an investment policy approved by the Audit Committee of our board of
directors. In general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed
income securities are primarily classified as available-for-sale and are recorded at fair value. The cost of securities sold is based on the specific identification
method. Unrealized gains and losses on these securities are recorded as other comprehensive income (loss) and are reported as a separate component of shareholders’ equity.

[0001193125-17-335712:mdna:109]
During the three months ended September 29, 2017, we repaid a term loan of $3.4 million under our Facility Agreement; as a result,
as of September 29, 2017, we had a long-term borrowing of $33.0 million and short-term borrowing of $34.0 million under our Facility Agreement. We anticipate that our internally generated working capital, along with our cash and cash
equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held investments in short-term marketable securities of $151.6 million as of September 29, 2017.

[0001193125-17-335712:mdna:110]
We believe that our current cash and cash equivalents, marketable securities, cash flow from operations, and funds available through our
credit facility will be sufficient to meet our working capital and capital expenditure needs for the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of
this Quarterly Report on Form 10-Q.

[0001193125-17-335712:mdna:111]
In December 2015, we began construction of a new
manufacturing facility at our Chonburi campus, which we substantially completed in the first quarter of fiscal year 2017. We began operations at this new facility in the fourth quarter of fiscal year 2017. We believe that our current manufacturing
capacity is sufficient to meet our anticipated production requirements for at least the next few quarters. We maintain a long-term loan associated with construction of production facilities at our Pinehurst campus in Thailand that will come due
within the next 12 months.

[0001193125-17-335712:mdna:112]
[same as prior period, unchanged from 0001193125-17-164153:mdna:132]

[0001193125-17-335712:mdna:113]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 29,2017 |  |  | September 30,2016 |  |
| Net cash used in operating activities |  | $ | (3,054 | ) |  | $ | (1,002 | ) |
| Net cash used in investing activities |  | $ | (12,055 | ) |  | $ | (43,271 | ) |
| Net cash (used in) provided by financing activities |  | $ | (7,106 | ) |  | $ | 10,441 |  |
| Net decrease in cash, cash equivalents and restricted cash |  | $ | (22,215 | ) |  | $ | (33,832 | ) |

[0001193125-17-335712:mdna:114]
[same as prior period, unchanged from 0001193125-17-164153:mdna:134]

[0001193125-17-335712:mdna:115]
Net cash used in operating activities increased by $2.1 million, or 204.8%, to $3.1 million for the three months ended
September 29, 2017, compared with net cash used in operating activities of $1.0 million for the three months ended September 30, 2016. This increase was due to a number of factors, including decreases in net income of
$1.7 million, trade accounts payable of $14.4 million, and other current assets and other non-current assets of $10.5 million. These were offset by (1) an increase in depreciation and
amortization of $2.3 million, (2) an increase of $1.3 million in share-based compensation expense due to an increase in the number of shares subject to equity awards granted in August 2017, (3) an increase in loss on exchange rate of
$3.9 million from the fluctuation of foreign currency, particularly the depreciation of USD against THB, (4) an increase of $13.3 million in other current liabilities and non-current
liabilities, and (5) a decrease of $5.3 million in inventory, as compared with the three months ended September 30, 2016.

[0001193125-17-335712:mdna:116]
[same as prior period, unchanged from 0001193125-17-164153:mdna:136]

[0001193125-17-335712:mdna:117]
Net
cash used in investing activities decreased by $31.2 million, or 72.1%, to $12.1 million for the three months ended September 29, 2017, compared with net cash used in investing activities of $43.3 million for the three months
ended September 30, 2016. This decrease was primarily due to (1) a decrease of $9.7 million in payments in connection with the acquisition of Fabrinet UK, (2) a decrease in the purchase of property, plant and equipment of
$15.9 million, and (3) a net decrease in marketable securities of $6.2 million.

[0001193125-17-335712:mdna:118]
[same as prior period, unchanged from 0001193125-17-164153:mdna:138]

[0001193125-17-335712:mdna:119]
Net cash for financing activities decreased by $17.5 million, or 168.1%, to net cash used in financing activities of $(7.1) million for
the three months ended September 29, 2017, compared with net cash provided by financing activities of $10.4 million for the three months ended September 30, 2016. This decrease was primarily due to a decrease in the proceeds from
revolving loan from bank of $13.5 million, and an increase in withholding tax related to net share settlement of restricted share units of $2.7 million compared with the same period last year.

[0001193125-17-335712:mdna:120]
[same as prior period, unchanged from 0001193125-17-164153:mdna:140]

[0001193125-17-335712:mdna:121]
[same as prior period, unchanged from 0001193125-17-164153:mdna:141]

[0001193125-17-335712:mdna:122]
[same as prior period, unchanged from 0001193125-17-164153:mdna:142]

[0001193125-17-335712:mdna:123]
[same as prior period, unchanged from 0001193125-17-164153:mdna:143]
