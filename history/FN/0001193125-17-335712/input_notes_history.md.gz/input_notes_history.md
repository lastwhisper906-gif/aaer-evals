# FN note change history — 0001193125-17-164153 → 0001193125-17-335712


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2017-11-07):
[0001193125-17-335712:note_history:1]
As of September 29, 2017 and June 30, 2017, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $1.5 million as of both dates.

- changed (2017-11-07):
[0001193125-17-335712:note_history:2]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, New Jersey and the United Kingdom under operating
 lease arrangements that expire in various calendar years through
 2023. Rental expense under these operating leases amounted to
 $0.5 million and $0.4 million for the three months ended
 September 29, 2017 and September 30, 2016,
 respectively.
  (was, 2017-05-09, similarity 0.8987):
[0001193125-17-164153:note_history:2]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, New Jersey and the United Kingdom under operating
 lease arrangements that expire in various calendar years through
 2023. Rental expense under these operating leases amounted to $1.2
 million and $0.9 million for the nine months ended March 31,
 2017 and March 25, 2016, respectively.

- changed (2017-11-07):
[0001193125-17-335712:note_history:3]
As of September 29, 2017, the future minimum lease payments
 due under non-cancelable
 operating leases during each fiscal year were as follows:
  (was, 2017-05-09, similarity 0.9627):
[0001193125-17-164153:note_history:3]
As of March 31, 2017, the future minimum lease payments due
 under non-cancelable operating leases during each fiscal year were
 as follows:

- changed (2017-11-07):
[0001193125-17-335712:note_history:4]
| (amount in thousands) |  |  |  |
| 2018 (remaining nine months) |  | $ | 1,295 |  |
| 2019 |  |  | 1,177 |  |
| 2020 |  |  | 956 |  |
| 2021 |  |  | 553 |  |
| 2022 |  |  | 429 |  |
| Thereafter |  |  | 467 |  |
| Total minimum operating lease payments |  | $ | 4,877 |  |
  (was, 2017-05-09, similarity 0.9839):
[0001193125-17-164153:note_history:4]
| (amount in thousands) |  |  |  |
| 2017 (remaining three months) |  | $ | 439 |  |
| 2018 |  |  | 1,663 |  |
| 2019 |  |  | 1,116 |  |
| 2020 |  |  | 911 |  |
| 2021 |  |  | 510 |  |
| Thereafter |  |  | 897 |  |
| Total minimum operating lease payments |  | $ | 5,536 |  |

- added (2017-11-07):
[0001193125-17-335712:note_history:5]
In connection with the acquisition of Fabrinet UK, the Company
 assumed the capital lease commitments of certain machine and
 equipment, with various expiration dates until September 2020. The
 equipment can be purchased at the determined prices upon expiration
 of such contracts.

- changed (2017-11-07):
[0001193125-17-335712:note_history:6]
As of September 29, 2017, the future minimum lease payments
 due under non-cancelable
 capital leases during each fiscal year were as follows:
  (was, 2017-05-09, similarity 0.9621):
[0001193125-17-164153:note_history:6]
As of March 31, 2017, the future minimum lease payments due
 under non-cancelable capital leases during each fiscal year were as
 follows:

- changed (2017-11-07):
[0001193125-17-335712:note_history:7]
| (amount in thousands) |  |  |  |
| 2018 (remaining nine months) |  | $ | 324 |  |
| 2019 |  |  | 458 |  |
| 2020 |  |  | 421 |  |
| 2021 |  |  | 107 |  |
| Total minimum capital lease payments |  | $ | 1,310 |  |
  (was, 2017-05-09, similarity 0.937):
[0001193125-17-164153:note_history:7]
| (amount in thousands) |  |  |  |
| 2017 (remaining three months) |  | $ | 92 |  |
| 2018 |  |  | 393 |  |
| 2019 |  |  | 426 |  |
| 2020 |  |  | 391 |  |
| 2021 |  |  | 101 |  |
| Total minimum capital lease payments |  | $ | 1,403 |  |

- changed (2017-11-07):
[0001193125-17-335712:note_history:8]
As of September 29, 2017, the Company had an outstanding
 commitment to third parties of approximately $11.1 million, of
 which $4.5 million was from the commitment to purchase land in
 Chonburi, Thailand.
  (was, 2017-05-09, similarity 0.6803):
[0001193125-17-164153:note_history:8]
As of March 31, 2017, the Company had an outstanding
 commitment to third parties of approximately $12.1 million.

- removed (2017-11-07):
[0001193125-17-164153:note_history:9]
Collateral assets

- removed (2017-11-07):
[0001193125-17-164153:note_history:10]
As of March 31, 2017 and June 24, 2016, certain property,
 plant and equipment of a subsidiary of $45.9 million and $47.7
 million were pledged as collateral to overdraft facilities, letter
 of guarantee and foreign exchange lines, respectively. In April
 2017, the bank released certain property, plant and equipment of
 the subsidiary which had been secured and pledged as collateral to
 such items.

- removed (2017-11-07):
[0001193125-17-164153:note_history:11]
As of March 31, 2017 and June 24, 2016, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $1.5 million and $0.8 million, respectively.

- removed (2017-11-07):
[0001193125-17-164153:note_history:12]
In connection with the acquisition of Exception EMS, the Company
 assumed the capital lease commitments of several machines and
 equipment, with various expiration dates until September 2020. The
 equipment can be purchased at the determined prices upon expiration
 of such contracts.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-11-07):
[0001193125-17-335712:note_history:13]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of September 29, 2017 and for the
 three months ended September 29, 2017 and September 30,
 2016 includes normal recurring adjustments, necessary for a fair
 statement of the financial statements set forth herein, in
 accordance with accounting principles generally accepted in the
 United States of America (“U.S. GAAP”) for interim
 financial information and the rules and regulations of the
 Securities and Exchange Commission (“SEC”).
 Accordingly, such information does not include all of the
 information and footnotes required by U.S. GAAP for annual
 financial statements. For further information, please refer to the
 consolidated financial statements and footnotes thereto included in
 Fabrinet’s Annual Report on Form 10-K for the year ended June 30,
 2017.
  (was, 2017-05-09, similarity 0.9402):
[0001193125-17-164153:note_history:13]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of March 31, 2017 and for the three
 and nine months ended March 31, 2017 and March 25, 2016
 includes normal recurring adjustments, necessary for a fair
 statement of the financial information set forth herein, in
 accordance with accounting principles generally accepted in the
 United States of America (“U.S. GAAP”) for interim
 financial information and the rules and regulations of the
 Securities and Exchange Commission (“SEC”).
 Accordingly, such information does not include all of the
 information and footnotes required by U.S. GAAP for annual
 financial statements. For further information, please refer to the
 consolidated financial statements and footnotes thereto included in
 Fabrinet’s Annual Report on Form 10-K for the year ended
 June 24, 2016.

- changed (2017-11-07):
[0001193125-17-335712:note_history:14]
The balance sheet as of June 30, 2017 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three months
 ended September 29, 2017 may not be indicative of results for
 the year ending June 29, 2018 or any future periods.
  (was, 2017-05-09, similarity 0.7032):
[0001193125-17-164153:note_history:14]
The balance sheet as of June 24, 2016 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three and nine
 months ended March 31, 2017 may not be indicative of results
 for the year ending June 30, 2017 or any future periods.

- changed (2017-11-07):
[0001193125-17-335712:note_history:15]
On September 14, 2016, the Company acquired 100% shareholding
 in Global CEM Solutions, Ltd. and all of its subsidiaries
 (including Fabrinet UK), a privately-held group located
 in Wiltshire, United Kingdom . The unaudited condensed
 consolidated financial statements of the Company include the
 financial position, results of operations and the cash flows of
 Fabrinet UK commencing as of the acquisition date. See Note 8 -
 Business acquisition for further details on the accounting for this
 transaction.
  (was, 2017-05-09, similarity 0.7085):
[0001193125-17-164153:note_history:15]
On September 14, 2016, the Company acquired 100% shareholding
 in Global CEM Solutions, Ltd. and all of its subsidiaries
 (including Exception EMS), a privately-held group located
 in Wiltshire, United Kingdom. The unaudited condensed
 consolidated financial statements of the Company include the
 financial position, results of operations and the cash flows of
 Exception EMS commencing as of the acquisition date. See Note 8 -
 Business acquisitions for further details on the accounting for
 this transaction.

- changed (2017-11-07):
[0001193125-17-335712:note_history:16]
The preparation of the Company’s unaudited condensed
 consolidated financial statements in conformity with U.S. GAAP
 requires management to make estimates and assumptions that affect
 the reported amounts of assets and liabilities and disclosure of
 contingent liabilities at the date of the financial statements, and
 the reported amount of total revenues and expenses during the year.
 The Company bases estimates on historical experience and various
 assumptions about the future that are believed to be reasonable
 based on available information. The Company’s reported
 financial position or results of operations may be materially
 different under different conditions or when using different
 estimates and assumptions, particularly with respect to significant
 accounting policies, which are discussed below. Significant
 assumptions are used in accounting for share-based compensation,
 allowance for doubtful accounts, income taxes, inventory
 obsolescence, goodwill and valuation of intangible assets related
 to business acquisition, among others. Due to the inherent
 uncertainty involved in making estimates, actual results reported
 in future periods may be different from these estimates. In the
 event that estimates or assumptions prove to differ from actual
 results, adjustments will be made in subsequent periods to reflect
 more current information.
  (was, 2017-05-09, similarity 0.7155):
[0001193125-17-164153:note_history:16]
The preparation of the Company’s unaudited condensed
 consolidated financial statements in conformity with U.S. GAAP
 requires management to make estimates and assumptions that affect
 the reported amounts of assets and liabilities and disclosure of
 contingent liabilities at the date of the financial statements, and
 the reported amount of total revenues and expenses during the year.
 The Company bases estimates on historical experience and various
 assumptions about the future that are believed to be reasonable
 based on available information. The Company’s reported
 financial position or results of operations may be materially
 different under different conditions or when using different
 estimates and assumptions, particularly with respect to significant
 accounting policies, which are discussed below. Significant
 assumptions are used in accounting for share-based compensation,
 allowance for doubtful accounts, income taxes, inventory
 obsolescence and valuation of intangible assets related to business
 acquisition, among others. Due to the inherent uncertainty involved
 in making estimates, actual results reported in future periods may
 be different from these estimates. In the event that estimates or
 assumptions prove to differ from actual results, adjustments will
 be made in subsequent periods to reflect more current
 information.

- changed (2017-11-07):
[0001193125-17-335712:note_history:17]
The Company utilizes a 52-53 week fiscal year ending on the
 Friday in June closest to June 30. The three months ended
 September 29, 2017 and September 30, 2016 consisted of 13
 weeks and 14 weeks, respectively. Fiscal year 2018 will be
 comprised of 52 weeks and will end on June 29, 2018.
  (was, 2017-05-09, similarity 0.7973):
[0001193125-17-164153:note_history:17]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended
 March 31, 2017 and March 25, 2016 each consisted of 13
 weeks. The nine months ended March 31, 2017 and March 25,
 2016 consisted of 40 weeks and 39 weeks, respectively. Fiscal year
 2017 will be comprised of 53 weeks and will end on June 30,
 2017.

- changed (2017-11-07):
[0001193125-17-335712:note_history:18]
Financial instruments that potentially subject the Company to
 concentrations of credit risk consist of cash and cash equivalents,
 marketable securities, derivatives, and accounts receivable.
  (was, 2017-05-09, similarity 0.9974):
[0001193125-17-164153:note_history:18]
Financial instruments that potentially subject the Company to
 concentrations of credit risk consist of cash and cash equivalents,
 marketable securities, derivatives and accounts receivable.

- changed (2017-11-07):
[0001193125-17-335712:note_history:19]
Cash, cash equivalents, and marketable securities are maintained
 with several financial institutions. Deposits held with banks may
 exceed the amount of insurance provided on such deposits.
 Generally, these deposits may be redeemed upon demand and are
 maintained with financial institutions with reputable credit and
 therefore bear minimal credit risk. The Company seeks to mitigate
 its credit risks by spreading such risks across multiple
 counterparties and monitoring the risk profiles of these
 counterparties. The Company limits its investments in marketable
 securities to securities with a maturity not in excess of three
 years, and all marketable securities that the Company invests in
 are rated A1, P-1, F1, or
 better.
  (was, 2017-05-09, similarity 0.9993):
[0001193125-17-164153:note_history:19]
Cash, cash equivalents and marketable securities are maintained
 with several financial institutions. Deposits held with banks may
 exceed the amount of insurance provided on such deposits.
 Generally, these deposits may be redeemed upon demand and are
 maintained with financial institutions with reputable credit and
 therefore bear minimal credit risk. The Company seeks to mitigate
 its credit risks by spreading such risks across multiple
 counterparties and monitoring the risk profiles of these
 counterparties. The Company limits its investments in marketable
 securities to securities with a maturity not in excess of three
 years, and all marketable securities that the Company invests in
 are rated A1, P-1, F1, or better.

- added (2017-11-07):
[0001193125-17-335712:note_history:20]
In September 2017, the Financial Accounting Standards Board
 (“FASB”) issued Accounting Standards Update
 (“ASU”) 2017-13, “Revenue Recognition
 (Topic 605), Revenue from Contracts with Customers (Topic 606),
 Leases (Topic 840), and Leases (Topic 842): Amendments to SEC
 Paragraphs Pursuant to the Staff Announcement at the July 20,
 2017 EITF Meeting and Rescission of Prior SEC Staff Announcements
 and Observer Comments.” The amendment delays the mandatory
 adoption of Topic 606 and Topic 842 for certain entities, revises
 the guidance related to performance-based incentive fees in Topic
 605 and revises the guidance related to leases in Topic 840 and
 Topic 842. The revisions to the lease guidance eliminate language
 specific to certain sale-leaseback arrangements, guarantees of
 lease residual assets and loans made by lessees to owner-lessors.
 Also included is an amendment to Topic 842 to retain the guidance
 in Topic 840 covering the impact of changes in tax rates on
 investments in leveraged leases. This guidance, which is effective
 immediately, generally relates to the adoption of Topic 606 and
 Topic 842. The Company does not expect the amendments will impact
 its consolidated financial statements.

- added (2017-11-07):
[0001193125-17-335712:note_history:21]
In August 2017, the FASB issued ASU 2017-12, “Derivatives and
 Hedging (Topic 815): Targeted Improvements to Accounting for
 Hedging Activities.” The amendments better align an
 entity’s risk management activities and financial reporting
 for hedging relationships through changes to both the designation
 and measurement guidance for qualifying hedging relationships and
 the presentation of hedge results. To meet that objective, the
 amendments expand and refine hedge accounting for both nonfinancial
 and financial risk components and align the recognition and
 presentation of the effects of the hedging instrument and the
 hedged item in the financial statements. The amendments also make
 certain targeted improvements to simplify the application of hedge
 accounting guidance and ease the administrative burden of hedge
 documentation requirements and assessing hedge effectiveness. This
 ASU is the final version of Proposed Accounting Standards Update
 2016-310—Derivatives
 and Hedging (Topic 815): Targeted Improvements to Accounting for
 Hedging Activities, which has been deleted. In the first quarter of
 fiscal year 2017, the Company adopted this update with no impact to
 the unaudited condensed consolidated financial statements.

- changed (2017-11-07):
[0001193125-17-335712:note_history:22]
In January 2017, the FASB issued ASU 2017-04, “Intangibles –
 Goodwill and Other (Topic 350): Simplifying the Test for Goodwill
 Impairment.” This amendment modified the concept of
 impairment assessment from the condition that exists when the
 carrying amount of goodwill exceeds its implied fair value to the
 condition that exists when the carrying amount of a reporting unit
 exceeds its fair value. Public companies that are SEC filers should
 adopt the amendment for its annual and any interim goodwill
 impairment tests in fiscal years beginning after December 15,
 2019. Early adoption is permitted for interim or annual goodwill
 impairment tests performed on testing dates after January 1,
 2017. The Company is currently evaluating the impact of the
 adoption of this update on its consolidated financial
 statements.
  (was, 2017-05-09, similarity 0.9403):
[0001193125-17-164153:note_history:22]
In January 2017, the Financial Accounting Standards Board
 (“FASB”) issued Accounting Standards Update
 (“ASU”) 2017-04, “Intangibles – Goodwill
 and Other (Topic 350): Simplifying the Test for Goodwill
 Impairment.” This amendment modified the concept of
 impairment assessment from the condition that exists when the
 carrying amount of goodwill exceeds its implied fair value to the
 condition that exists when the carrying amount of a reporting unit
 exceeds its fair value. Public companies that are SEC filers should
 adopt the amendment for its annual and any interim goodwill
 impairment tests in fiscal years beginning after December 15,
 2019. Early adoption is permitted for interim or annual goodwill
 impairment tests performed on testing dates after January 1,
 2017. The Company is currently evaluating the impact of the
 adoption of this update on its consolidated financial
 statements.

- changed (2017-11-07):
[0001193125-17-335712:note_history:23]
In January 2017, the FASB issued ASU 2017-01, “Business Combination
 (Topic 805): Clarifying the Definition of a Business.” This
 amendment clarifies the definition of a business to assist entities
 when evaluating whether transactions should be accounted for as
 acquisitions (or disposals) of assets or business. For public
 companies, this ASU is effective for annual periods beginning after
 December 15, 2017, including interim periods within those
 periods. Early adoption is permitted for the transactions that
 occur before the issuance date or effective date of the amendment,
 only when the transaction has not been reported in financial
 statements that have been issued or made available for issuance.
 The Company does not expect that the adoption of this update will
 have a material impact on its consolidated financial
 statements.
  (was, 2017-05-09, similarity 0.9976):
[0001193125-17-164153:note_history:23]
In January 2017, the FASB issued ASU 2017-01, “Business
 Combination (Topic 805): Clarifying the Definition of a
 Business.” This amendment clarifies the definition of a
 business to assist entities when evaluating whether transactions
 should be accounted for as acquisitions (or disposals) of assets or
 business. For public companies, this ASU is effective for annual
 periods beginning after December 15, 2017, including interim
 periods within those periods. Early adoption is permitted for the
 transactions that occur before the issuance date or effective date
 of the amendment, only when the transaction has not been reported
 in financial statements that have been issued or made available for
 issuance. The Company does not expect that the adoption of this
 update will have a material impact to its consolidated financial
 statements.

- changed (2017-11-07):
[0001193125-17-335712:note_history:24]
In May 2014, the FASB issued ASU 2014-09, “Revenue from Contracts
 with Customers (Topic 606), issued as a new Topic, Accounting
 Standards Codification.” The core principle of this amendment
 is that an entity should recognize revenue to depict the transfer
 of promised goods or services to customers in an amount that
 reflects the consideration to which the entity expects to be
 entitled in exchange for those goods or services. This update is
 effective for public companies, as amended by ASU 2015-14, for annual reporting periods
 beginning after December 15, 2017, including interim periods
 within that reporting period. Earlier application of this guidance
 is permitted, but not before the original date of December 15,
 2016, which can be adopted either retrospectively to each prior
 reporting period presented or as a cumulative-effect adjustment as
 of the date of adoption. Subsequently, in March 2016 and April
 2016, the FASB issued ASU 2016-08 and ASU 2016-10, respectively, to clarify the
 implementation guidance on principle versus agent considerations
 and address the potential diversity in practice at initial
 application and cost; and the complexity of applying Topic 606,
 both at transition and on an ongoing basis related to
 identification of performance obligations and licensing
 arrangements; and ASU 2016-12 and ASU 2016-20 in May 2016 and December 2016,
 respectively, to improve certain aspects of Topic 606, with the
 same effective date as ASU 2015-14. The Company will adopt this
 standard during its fiscal year ending June 28, 2019. In the
 current period, the Company is assessing the contracts with its
 customers to identify the impact to its consolidated financial
 statements. The process is still ongoing and the Company expects to
 make significant progress in the coming quarters.
  (was, 2017-05-09, similarity 0.9991):
[0001193125-17-164153:note_history:24]
In May 2014, the FASB issued ASU 2014-09, “Revenue from
 Contracts with Customers (Topic 606), issued as a new Topic,
 Accounting Standards Codification.” The core principle of
 this amendment is that an entity should recognize revenue to depict
 the transfer of promised goods or services to customers in an
 amount that reflects the consideration to which the entity expects
 to be entitled in exchange for those goods or services. This update
 is effective for public companies, as amended by ASU 2015-14, for
 annual reporting periods beginning after December 15, 2017,
 including interim periods within that reporting period. Earlier
 application of this guidance is permitted, but not before the
 original date of December 15, 2016, which can be adopted
 either retrospectively to each prior reporting period presented or
 as a cumulative-effect adjustment as of the date of adoption.
 Subsequently, in March 2016 and April 2016, the FASB issued ASU
 2016-08 and ASU 2016-10, respectively, to clarify the
 implementation guidance on principle versus agent considerations
 and address the potential diversity in practice at initial
 application and cost; and the complexity of applying Topic 606,
 both at transition and on an ongoing basis related to
 identification of performance obligations and licensing
 arrangements; and ASU 2016-12 and ASU 2016-20, in May 2016 and
 December 2016, respectively, to improve in certain aspects of Topic
 606, with the same effective date as ASU 2015-14. The Company will
 adopt this standard during its fiscal year ending June 28,
 2019. In the current period, the Company is assessing the contracts
 with its customers to identify the impact to its consolidated
 financial statements. The process is still ongoing and the Company
 expects to make significant progress in the coming quarters.

- changed (2017-11-07):
[0001193125-17-335712:note_history:25]
In November 2016, the FASB issued ASU 2016-18, “Statement of Cash
 Flows (Topic 230): Restricted Cash,” which requires the
 statement of cash flows to explain the change during the period in
 the total of cash, cash equivalents and restricted cash or
 restricted cash equivalents. The Company has early adopted this
 update in the second quarter of fiscal year 2017 on a retrospective
 basis. As of September 30, 2016, restricted cash in connection
 with business acquisition of $3.3 million was presented in the
 statement of cash flows as cash, cash equivalents and restricted
 cash.
  (was, 2017-05-09, similarity 0.7039):
[0001193125-17-164153:note_history:25]
In November 2016, the FASB issued ASU 2016-18, “Statement of
 Cash Flows (Topic 230): Restricted Cash,” which requires the
 statement of cash flows to explain the change during the period in
 the total of cash, cash equivalents and restricted cash or
 restricted cash equivalents. The Company has early adopted this
 update in the second quarter of fiscal year 2017 on a retrospective
 basis but there was no impact to the presentation of the
 comparative period in the unaudited condensed consolidated
 financial statements.

- added (2017-11-07):
[0001193125-17-335712:note_history:26]
In March 2016, the FASB issued ASU 2016-09, “Compensation
 – Stock Compensation (Topic 718): Improvements to Employee
 Share-Based Payment Accounting.” This ASU simplifies several
 aspects of the accounting for share-based payment award
 transactions, including, the income tax consequences,
 classification of awards as either equity or liabilities and
 classification on the statement of cash flows. The amendments in
 this update are effective for annual periods beginning after
 December 15, 2016, and interim periods within those annual
 periods, for public companies. Early adoption is permitted for any
 entity in any interim or annual period. In the first quarter of
 fiscal year 2018, the Company adopted this update with no impact to
 the unaudited condensed consolidated financial statements.

- changed (2017-11-07):
[0001193125-17-335712:note_history:27]
In March 2016, the FASB issued ASU 2016-05, “Derivatives and
 Hedging (Topic 815),” to clarify that a change in the
 counterparty to a derivative instrument that has been designated as
 a hedging instrument under Topic 815, does not, in and of itself,
 require designation of the hedging relationship, provided that all
 other hedge accounting criteria continue to be met. This guidance
 is effective for public entities for financial statements issued
 for fiscal years beginning after December 15, 2016 and interim
 periods within those fiscal years. In the first quarter of fiscal
 year 2018, the Company adopted this update with no impact to the
 unaudited condensed consolidated financial statements.
  (was, 2017-05-09, similarity 0.8512):
[0001193125-17-164153:note_history:27]
In March 2016, the FASB issued ASU 2016-05, “Derivatives and
 Hedging (Topic 815),” to clarify that a change in the
 counterparty to a derivative instrument that has been designated as
 a hedging instrument under Topic 815, does not, in and of itself,
 require a de-designation of the hedging relationship, provided that
 all other hedge accounting criteria continue to be met. This
 guidance is effective for public entities for financial statements
 issued for fiscal years beginning after December 15, 2016 and
 interim periods within those fiscal years. Early adoption is
 permitted. The Company is currently evaluating the impact of the
 adoption of this update on its consolidated financial
 statements.

- removed (2017-11-07):
[0001193125-17-164153:note_history:28]
Derivatives

- removed (2017-11-07):
[0001193125-17-164153:note_history:29]
The derivatives assets and liabilities are recognized on the
 unaudited condensed consolidated balance sheets as other current
 assets or accrued expenses and are measured at fair value.

- removed (2017-11-07):
[0001193125-17-164153:note_history:30]
The Company applies hedge accounting to arrangements that qualify
 and are designated for cash flow or fair value hedge accounting
 treatment. Hedge accounting is discontinued prospectively if the
 hedging relationship ceases to be effective or the hedging or
 hedged items cease to exist as a result of maturity, sale,
 termination or cancellation.

- removed (2017-11-07):
[0001193125-17-164153:note_history:31]
Derivatives designated and qualifying as hedges of the exposure to
 variability in expected future cash flows, or other types of
 forecasted transactions, are considered cash flow hedges which
 include forward currency contracts. In a cash flow hedging
 relationship, the effective portion of the change in the fair value
 of the hedging derivative is initially recorded in accumulated
 other comprehensive income (loss) (“AOCI”), while any
 ineffective portion is recognized directly in earnings, as a
 component of other income (expense). The portion of gain or loss on
 the derivative instrument remains in AOCI until the forecasted
 transaction is recognized in earnings.

- removed (2017-11-07):
[0001193125-17-164153:note_history:32]
The Company also enters into derivative contracts that are intended
 to economically hedge certain of the Company’s risks. The
 changes in the fair value of the derivatives are recorded directly
 in earnings as a component of other income (expense). In accordance
 with the fair value measurement guidance, the Company’s
 accounting policy is to measure the credit risk of its derivative
 financial instruments that are subject to master netting agreements
 on a net basis by counterparty portfolio. The Company executes
 derivative instruments with financial institutions that are
 credit-worthy, defined by us as institutions that hold an
 investment grade credit rating.

- removed (2017-11-07):
[0001193125-17-164153:note_history:33]
Business acquisition

- removed (2017-11-07):
[0001193125-17-164153:note_history:34]
For the acquisition of Exception EMS, the Company allocated the
 fair value of purchase consideration to the assets acquired and
 liabilities assumed based on their fair values at the acquisition
 date. The total consideration and the allocation of consideration
 to the individual net assets are preliminary, pending the
 finalization of the estimated fair value attributable to the
 acquired customer relationships.

- removed (2017-11-07):
[0001193125-17-164153:note_history:35]
The acquired intangible assets, which consist of customer
 relationships and backlog, are recorded within intangibles, net in
 the unaudited condensed consolidated balance sheets. The fair value
 of the acquired intangible assets was determined based on the
 multi-period excess earnings method. The Company reviews definite
 lived intangibles for impairment whenever changes or circumstances
 indicate the carrying amount may not be recoverable.

- removed (2017-11-07):
[0001193125-17-164153:note_history:36]
In connection with the business acquisition, $3.2 million of cash
 for deferred consideration, net of foreign currency translation
 adjustment, was placed into an escrow account which is under the
 Company’s control. However, the Company has contractually
 agreed to remit this deferred consideration to the sellers of
 Exception EMS, subject to the resolution of claims that the Company
 may make against the funds with respect to indemnification and
 other claims within 24 months from the closing date of the
 transaction. The cash is presented as restricted cash in the
 unaudited condensed consolidated balance sheets within non-current
 assets and the related liability is presented within non-current
 liabilities for the deferred consideration.

- removed (2017-11-07):
[0001193125-17-164153:note_history:37]
Goodwill

- removed (2017-11-07):
[0001193125-17-164153:note_history:38]
Goodwill arising from the acquisition is primarily attributable to
 the ability to expand future products and services and the
 assembled workforce. Goodwill is reviewed annually for impairment
 or more frequently whenever changes or circumstances indicate the
 carrying amount of goodwill may not be recoverable.

- removed (2017-11-07):
[0001193125-17-164153:note_history:39]
Capital lease

- removed (2017-11-07):
[0001193125-17-164153:note_history:40]
Certain machine and equipment held under capital leases are
 classified as property, plant and equipment and amortized using the
 straight-line method over the terms of the lease contracts. The
 related obligations from the capital lease are recorded as
 liabilities in the unaudited condensed consolidated balance
 sheets.

- removed (2017-11-07):
[0001193125-17-164153:note_history:41]
In October 2016, the FASB issued ASU 2016-16, “Income Taxes
 (Topic 740): Intra-Entity Transfers of Assets Other Than
 Inventory,” which eliminates the exception for an
 intra-entity transfer of an asset other than inventory that
 prohibits the recognition of current and deferred income taxes
 until the asset has been sold to an outside party. The entity
 should recognize income tax consequences of an intra-entity
 transfer of assets other than inventory when the transfer occurs.
 For public entities, this update is effective for annual reporting
 periods beginning after December 15, 2017, including interim
 reporting periods within those annual reporting periods. Early
 adoption is permitted for all entities as of the beginning of an
 annual reporting period for which financial statements have not
 been issued or made available for issuance. The Company is
 currently evaluating the impact of the adoption of this update on
 its consolidated financial statements.

- removed (2017-11-07):
[0001193125-17-164153:note_history:42]
In June 2016, the FASB issued ASU 2016-13, “Financial
 Instruments – Credit Losses (Topic 326): Measurement of
 Credit Losses on Financial Instruments.” The amendments in
 this ASU replace the incurred loss impairment methodology in
 current GAAP with a methodology that reflects expected credit
 losses and requires consideration of a broader range of reasonable
 and supportable information to inform credit loss estimates. The
 amendments are effective for fiscal years beginning after
 December 15, 2019, including interim periods within those
 fiscal years. Early adoption is permitted for fiscal years
 beginning after December 15, 2018, including interim periods
 within those fiscal years. The Company is currently evaluating the
 impact of the adoption of this update on its consolidated financial
 statements.

- removed (2017-11-07):
[0001193125-17-164153:note_history:43]
In March 2016, the FASB issued ASU
 2016-09, “Compensation – Stock Compensation (Topic
 718): Improvements to Employee Share-Based Payment
 Accounting.” This ASU simplifies several aspects of the
 accounting for share-based payment award transactions, including
 the income tax consequences, classification of awards as either
 equity or liabilities and classification on the statement of cash
 flows. The amendments in this update are effective for annual
 periods beginning after December 15, 2016, and interim periods
 within those annual periods, for public companies. Early adoption
 is permitted for any entity in any interim or annual period. The
 Company is currently evaluating the impact of the adoption of this
 update on its consolidated financial statements.

- removed (2017-11-07):
[0001193125-17-164153:note_history:44]
In August 2014, the FASB issued ASU 2014-15, “Presentation of
 Financial Statements – Going Concern (Subtopic 205-40):
 Disclosure of Uncertainties about an Entity’s Ability to
 Continue as a Going Concern.” The amendments require
 management to evaluate, for each annual and interim reporting
 period, an entity’s ability to continue as a going concern
 when relevant conditions and events, considered in the aggregate,
 indicate that it is probable that the entity will be unable to meet
 its obligations that become due within one year after the date that
 the financial statements are issued (or available to be issued).
 This ASU is effective for annual periods and interim reporting
 periods ending after December 15, 2016. The Company does not
 expect that the adoption of this update will have an effect on its
 consolidated financial statements.

- removed (2017-11-07):
[0001193125-17-164153:note_history:45]
In November 2015, the FASB issued ASU 2015-17, “Balance Sheet
 Classification of Deferred Taxes,” which will require
 entities to present deferred tax assets (“DTAs”) and
 deferred tax liabilities (“DTLs”) as non-current in a
 classified balance sheet. The ASU simplifies the current guidance,
 which requires entities to separately present DTAs and DTLs as
 current and non-current in a classified balance sheet. The Company
 has early adopted this update in the first quarter of fiscal year
 2017. The Company adopted this update on a prospective basis and
 did not change the presentation of the comparative period.

- removed (2017-11-07):
[0001193125-17-164153:note_history:46]
In September 2015, the FASB issued ASU 2015-16, “Business
 Combinations (Topic 805): Simplifying the Accounting for
 Measurement-Period Adjustments” which require an acquirer to
 recognize adjustments to provisional amounts that are identified
 during the measurement period in the reporting period in which the
 adjustment amounts are determined. The Company adopted this update
 in the first quarter of fiscal year 2017 and applied it on a
 prospective basis. See Footnote 8 – Business acquisition, for
 further disclosure on measurement period adjustments recorded in
 the nine months ended March 31, 2017.

- removed (2017-11-07):
[0001193125-17-164153:note_history:47]
In July 2015, the FASB issued ASU 2015-11, “Inventory (Topic
 330): Simplifying the Measurement of Inventory.” The update
 provides the guidance that an entity, that measured inventory by
 using first-in, first-out or average cost, should measure inventory
 at the lower of cost and net realizable value. Subsequent
 measurement is unchanged for inventory measured using last-in,
 first-out or the retail inventory method. The Company adopted this
 update in the first quarter of fiscal year 2017 with no impact to
 the unaudited condensed consolidated financial statements.

- removed (2017-11-07):
[0001193125-17-164153:note_history:48]
In April 2015, the FASB issued ASU 2015-03, “Interest –
 Imputation of Interest (Subtopic 835-30): Simplifying the
 Presentation of Debt Issuance Costs.” The update requires
 debt issuance costs related to a recognized debt liability be
 presented in the balance sheet as a direct deduction from the
 carrying amount of the related debt liability instead of being
 presented as an asset. Debt disclosures will include the face
 amount of the debt liability and the effective interest rate. The
 update requires retrospective application and represents a change
 in accounting principle. Additionally, in August 2015, the FASB
 issued ASU 2015-15, “Interest – Imputation of Interest
 (Subtopic 835-30): Presentation and Subsequent Measurement of Debt
 Issuance Costs Associated with Line-of-Credit Arrangements”
 to amend ASU 2015-03. The Company adopted this amendment
 retrospectively in the first quarter of fiscal year 2017. As of
 March 31, 2017 and June 24, 2016, debt issuance costs of
 $0.4 million and $0.6 million, respectively, related to a
 recognized debt liability are presented in the balance sheet as a
 direct reduction of the carrying amount of the related debts.

- removed (2017-11-07):
[0001193125-17-164153:note_history:49]
In February 2015, the FASB issued ASU 2015-02, “Consolidation
 (Topic 810): Amendments to the Consolidation Analysis.” ASU
 No. 2015-02 amended the process that a reporting entity must
 perform to determine whether it should consolidate certain types of
 legal entities. In the first quarter of fiscal year 2017, the
 Company adopted this update with no impact to the unaudited
 condensed consolidated financial statements.

- removed (2017-11-07):
[0001193125-17-164153:note_history:50]
In January 2015, the FASB issued ASU 2015-01, “Income
 Statement – Extraordinary and Unusual Items (Subtopic
 225-20): Simplifying Income Statement Presentation by Eliminating
 the Concept of Extraordinary Items.” The objective of this
 amendment is to reduce the complexity in accounting standards by
 eliminating the concept of extraordinary items from U.S. GAAP. To
 meet for extraordinary classification the underlying event or
 transaction should (a) possess a high degree of abnormality
 and be of a type clearly unrelated to, or only incidentally related
 to, the ordinary and typical activities of the entity and
 (b) not reasonably be expected to recur in the foreseeable
 future. In the first quarter of fiscal year 2017, the Company
 adopted this update with no impact to the unaudited condensed
 consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-07):
[0001193125-17-335712:note_history:51]
|  |  |  |  |  |  | As of |  |  | As of |  |
| (amount in thousands) |  |  |  |  |  | September 29, |  |  | June 30, |  |
| Rate (1) |  | Conditions |  | Maturity |  | 2017 |  |  | 2017 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  | October 2017 (2) |  | $ | 34,000 |  |  | $ | 34,000 |  |
| Short-term loans from bank: |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank Base rate +1.85% per annum |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  | — |  |  |  | 1,003 |  |
| Current portion of long-term borrowing |  |  |  |  |  |  | 13,600 |  |  |  | 13,600 |  |
|  |  |  |  |  |  |  | 47,600 |  |  |  | 48,603 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (179 | ) |  |  | (201 | ) |
|  |  |  |  |  |  | $ | 47,421 |  |  | $ | 48,402 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  | Repayable in quarterly installments |  | May 2019 |  | $ | 33,000 |  |  | $ | 36,400 |  |
|  |  |  |  |  |  |  | 33,000 |  |  |  | 36,400 |  |
| Less: Current portion |  |  |  |  |  |  | (13,600 | ) |  |  | (13,600 | ) |
| Unamortized debt issuance costs |  |  |  |  |  |  | (62 | ) |  |  | (99 | ) |
| Non-current portion |  |  |  |  |  | $ | 19,338 |  |  | $ | 22,701 |  |
  (was, 2017-05-09, similarity 0.7162):
[0001193125-17-164153:note_history:51]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  | As of |  |  | As of |  |
|  |  |  |  |  |  |  | March 31, |  |  | June 24, |  |
| Rate (1) |  | Conditions |  | Maturity |  |  | 2017 |  |  | 2016 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  |  | April 2017 (2) |  |  | $ | 34,000 |  |  | $ | 6,500 |  |
| Short-term borrowings from bank: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank of England base rate +1.85% per annum |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  |  |  | 1,257 |  |  |  | — |  |
| Bank of England base rate + 2.2% per annum (3) |  | Repayable on monthly basis |  |  | May 2017 |  |  |  | 23 |  |  |  | — |  |
| Current portion of long-term borrowing |  |  |  |  |  |  |  |  | 13,600 |  |  |  | 18,100 |  |
|  |  |  |  |  |  |  |  |  | 48,880 |  |  |  | 24,600 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  |  |  | (222 | ) |  |  | (293 | ) |
|  |  |  |  |  |  |  |  | $ | 48,658 |  |  | $ | 24,307 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments |  |  | March 2017 |  |  | $ | — | (4) |  | $ | 4,500 |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  | Repayable in quarterly installments |  |  | May 2019 |  |  |  | 39,800 |  |  |  | 50,000 |  |
|  |  |  |  |  |  |  |  |  | 39,800 |  |  |  | 54,500 |  |
| Less: Current portion |  |  |  |  |  |  |  |  | (13,600 | ) |  |  | (18,100 | ) |
| Unamortized debt issuance costs |  |  |  |  |  |  |  |  | (141 | ) |  |  | (300 | ) |
| Non-current portion |  |  |  |  |  |  |  | $ | 26,059 |  |  | $ | 36,100 |  |

- changed (2017-11-07):
[0001193125-17-335712:note_history:52]
| (2) | In September 2017, the maturity date was extended to October 2017. |
  (was, 2017-05-09, similarity 0.8462):
[0001193125-17-164153:note_history:52]
| (2) | In March 2017, the maturity date was extended to April 2017. |

- changed (2017-11-07):
[0001193125-17-335712:note_history:53]
The movement of long-term loans for the three months ended
 September 29, 2017 and September 30, 2016 were as
 follows:
  (was, 2017-05-09, similarity 0.6794):
[0001193125-17-164153:note_history:53]
The movement of long-term borrowings was as follows for the nine
 months ended March 31, 2017 and March 25, 2016:

- added (2017-11-07):
[0001193125-17-335712:note_history:54]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 29, 2017 |  |  | September 30, 2016 |  |
| Opening balance |  | $ | 36,400 |  |  | $ | 54,500 |  |
| Repayments during the period |  |  | (3,400 | ) |  |  | (4,900 | ) |
| Closing balance |  | $ | 33,000 |  |  | $ | 49,600 |  |

- changed (2017-11-07):
[0001193125-17-335712:note_history:55]
As of September 29, 2017, future maturities of long-term debt
 during each fiscal year were as follows:
  (was, 2017-05-09, similarity 0.8866):
[0001193125-17-164153:note_history:55]
As of March 31, 2017, future maturities of long-term
 borrowings during each fiscal year were as follows:

- changed (2017-11-07):
[0001193125-17-335712:note_history:56]
| (amount in thousands) |  |  |  |
| 2018 (remaining nine months) |  | $ | 10,200 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 33,000 |  |
  (was, 2017-05-09, similarity 0.9038):
[0001193125-17-164153:note_history:56]
| (amount in thousands) |  |  |  |
| 2017 (remaining three months) |  | $ | 3,400 |  |
| 2018 |  |  | 13,600 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 39,800 |  |

- changed (2017-11-07):
[0001193125-17-335712:note_history:57]
Fabrinet entered into a syndicated senior credit facility agreement
 (the “Facility Agreement”) with a consortium of banks
 on May 22, 2014. The Facility Agreement, led by Bank of
 America, provides for a $200.0 million credit line, comprised
 of a $150.0 million revolving loan facility and a
 $50.0 million delayed draw term loan facility. The revolving
 loan facility contains an accordion feature permitting Fabrinet to
 request an increase in the facility up to $100.0 million
 subject to customary terms and conditions and provided that no
 default or event of default exists at the time of request. The
 revolving loan facility terminates and all amounts outstanding are
 due and payable in full on May 22, 2019. The principal amount
 of any drawn term loans must be repaid according to scheduled
 quarterly amortization payments, with final payment of all amounts
 outstanding, plus accrued interest, being due May 22,
 2019.
  (was, 2017-05-09, similarity 0.8709):
[0001193125-17-164153:note_history:57]
Fabrinet entered into a syndicated senior credit facility agreement
 (the “Facility Agreement”) with a consortium of banks
 on May 22, 2014. The Facility Agreement, led by Bank of
 America, provides for a $200.0 million credit line, comprised of a
 $150.0 million revolving loan facility and a $50.0 million delayed
 draw term loan facility. The revolving loan facility contains an
 accordion feature permitting Fabrinet to request an increase in the
 facility up to $100.0 million subject to customary terms and
 conditions and provided that no default or event of default exists
 at the time of request. The revolving loan facility will be
 terminated and all amounts outstanding will be due and payable in
 full on May 22, 2019. The principal amount of any drawn term
 loans must be repaid according to scheduled quarterly amortization
 payments, with final payment of all amounts outstanding, plus
 accrued interest, being due May 22, 2019.

- added (2017-11-07):
[0001193125-17-335712:note_history:58]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. The
 Company fully drew down the term loan facility in fiscal year 2016.
 As of September 29, 2017, $34.0 million of the revolving
 borrowing and $33.0 million of the term loan borrowing was
 outstanding under the Facility Agreement, resulting in available
 credit facilities of $116.0 million. Borrowings under the
 revolving credit facility are classified as current liabilities in
 the unaudited condensed consolidated balance sheets as the Company
 has the periodic option to renew or pay, all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. During September 2017, the
 Company sent notices to the bank to renew the maturity date of its
 revolving borrowings. The bank approved the notices and extended
 the maturity to October 2017.

- added (2017-11-07):
[0001193125-17-335712:note_history:59]
On July 24, 2017, the Company entered into an interest rate
 swap agreement (the “Swap Agreement”), which the
 Company did not designate as hedging instruments. The Swap
 Agreement was used to mitigate interest rate risk and improve the
 interest rate profile of the Company’s debt obligations. The
 terms of the Swap Agreement effectively convert the floating
 interest rate of the term loans under the Facility Agreement to the
 fixed interest rate of 1.55% per annum through maturity of the term
 loan in May 2019. The swap transactions are due and settled
 monthly. During the three month ended September 29, 2017,
 the Company included net loss of $20 thousand from the
 settlement of the Swap Agreement as interest expenses in the
 unaudited condensed consolidated statements of operations and
 comprehensive income.

- changed (2017-11-07):
[0001193125-17-335712:note_history:60]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material of
 its subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or
 the equivalent under the local law, can be effected.
  (was, 2017-05-09, similarity 0.9973):
[0001193125-17-164153:note_history:60]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material of
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or the
 equivalent under the local law, can be effected.

- changed (2017-11-07):
[0001193125-17-335712:note_history:61]
The Facility Agreement contains customary affirmative and negative
 covenants. Negative covenants include, among other things,
 limitations on liens, indebtedness, investments, mergers, sales of
 assets, changes in the nature of the business, dividends and
 distributions, affiliate transactions and capital expenditures. The
 Facility Agreement contains financial covenants requiring Fabrinet
 to maintain: (1) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (2) a minimum debt service coverage ratio of
 not less than 1.50:1.00; (3) a maximum senior leverage ratio of not
 more than 2.50:1.00; and (4) a minimum quick ratio of not less
 than 1.10:1.00. Each of these financial covenants is calculated on
 a consolidated basis for the consecutive four fiscal quarter period
 then ended. As of September 29, 2017, the Company was in
 compliance with all covenants under the Facility Agreement.
  (was, 2017-05-09, similarity 0.9223):
[0001193125-17-164153:note_history:61]
The Facility Agreement contains customary affirmative and negative
 covenants. Negative covenants include, among other things,
 limitations on liens, indebtedness, investments, mergers, sales of
 assets, changes in the nature of the business, dividends and
 distributions, affiliate transactions and capital expenditures. The
 Facility Agreement contains financial covenants requiring Fabrinet
 to maintain: (1) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (2) a minimum debt service coverage ratio of
 not less than 1.50:1.00; (3) a maximum senior leverage ratio
 of not more than 2.50:1.00; and (4) a minimum quick ratio of
 not less than 1.10:1.00. Each of these financial covenants is
 calculated on a consolidated basis for the consecutive four fiscal
 quarter period then ended. As of March 31, 2017, the Company
 was in compliance with all covenants under the Facility
 Agreement.

- changed (2017-11-07):
[0001193125-17-335712:note_history:62]
Fabrinet intends to use the proceeds of the credit line to finance
 its future manufacturing buildings in the United States and
 Thailand, and for general corporate purposes including mergers and
 acquisitions of complementary manufacturing businesses or
 technology, although Fabrinet has no current commitments with
 respect to any such acquisitions.
  (was, 2017-05-09, similarity 0.9329):
[0001193125-17-164153:note_history:62]
Fabrinet intends to use the proceeds of the credit line to finance
 its future manufacturing facility in Thailand, and for general
 corporate purposes including mergers and acquisitions of
 complementary manufacturing businesses or technology, although
 Fabrinet has no current commitments with respect to any such
 acquisitions.

- changed (2017-11-07):
[0001193125-17-335712:note_history:63]
Short-term loans from bank
  (was, 2017-05-09, similarity 0.8421):
[0001193125-17-164153:note_history:63]
Short-term borrowings from bank

- added (2017-11-07):
[0001193125-17-335712:note_history:64]
In connection with the business acquisition in the first quarter of
 fiscal year 2017, the Company assumed a secured borrowing
 agreement. In the first quarter of fiscal year 2018, the Company
 fully repaid these short-term loans and sent a notification letter
 to the bank to terminate this secured borrowing agreement. As a
 result, the bank released secured trade accounts receivable and the
 way chattels mortgage over the plant and machine of Fabrinet UK
 (formerly known as Exception EMS).

- changed (2017-11-07):
[0001193125-17-335712:note_history:65]
Undrawn available credit facilities classified by availability
 period of future borrowing as of September 29, 2017 and
 June 30, 2017 were as follows:
  (was, 2017-05-09, similarity 0.9635):
[0001193125-17-164153:note_history:65]
Undrawn available credit facilities classified by availability
 period of future borrowing as of March 31, 2017 and
 June 24, 2016 were as follows:

- changed (2017-11-07):
[0001193125-17-335712:note_history:66]
| (amount in thousands) |  | September 29, 2017 |  |  | June 30, 2017 |  |
| Short-term |  | $ | — |  |  | $ | 1,965 |  |
| Long-term |  | $ | 116,000 |  |  | $ | 116,000 |  |
  (was, 2017-05-09, similarity 0.9556):
[0001193125-17-164153:note_history:66]
| (amount in thousands) |  | March 31, 2017 |  |  | June 24, 2016 |  |
| Short-term |  | $ | 4,799 |  |  | $ | 1,414 |  |
| Long-term |  | $ | 126,200 |  |  | $ | 143,500 |  |

- removed (2017-11-07):
[0001193125-17-164153:note_history:67]
| (3) | As of March 31, 2017, the carrying amount of plant and machinery of Exception EMS secured to such loan was $0.8 million. Under the conditions stipulated in the loan agreement, this loan will be cross securitized, cross default and co-terminus with the short terms loans of $1.3 million which are secured by accounts receivable. |

- removed (2017-11-07):
[0001193125-17-164153:note_history:68]
| (4) | In March 2017, a subsidiary fully repaid the long term borrowing. The carrying amount of assets secured and pledged as collateral to such loan as of March 31, 2017 and June 24, 2016 was $45.9 million and $47.7 million, respectively. In April 2017, the bank released certain property, plant and equipment of the subsidiary which had been secured and pledged as collateral to such loans. |

- removed (2017-11-07):
[0001193125-17-164153:note_history:69]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 31, 2017 |  |  | March 25, 2016 |  |
| Opening balance |  | $ | 54,500 |  |  | $ | 10,500 |  |
| Repayments during the period |  |  | (14,700 | ) |  |  | (4,500 | ) |
| Closing balance |  | $ | 39,800 |  |  | $ | 6,000 |  |

- removed (2017-11-07):
[0001193125-17-164153:note_history:70]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. As of
 March 31, 2017, $34.0 million of the revolving borrowing and
 $39.8 million of the term loan borrowing was outstanding under the
 Facility Agreement, resulting in available credit facilities for
 long-term borrowing of $126.2 million. Borrowings under the
 revolving credit facility are classified as current liabilities in
 the unaudited condensed consolidated balance sheets as the Company
 has the periodic option to renew or pay, all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. During March 2017, the Company
 sent notices to the bank to renew the maturity date of its
 revolving borrowings. The bank approved the notices and extended
 the maturity to April 2017.

- removed (2017-11-07):
[0001193125-17-164153:note_history:71]
In connection with the acquisition of Exception EMS, the Company
 assumed a secured borrowing agreement that is secured by trade
 accounts receivable of Exception EMS. As of March 31, 2017,
 the carrying amount of trade accounts receivable secured to the
 loans was $5.6 million. The secured borrowing agreement contains
 certain covenants that Exception EMS is required to comply with:
 (1) the value of credit notes may not exceed 4% of the value
 of assigned debts measured on a monthly basis, and (2) rolling
 cash flow must be provided to the financial institution along with
 monthly management information. As of March 31, 2017, the
 subsidiary was in compliance with all covenants under the secured
 borrowing agreement.

- removed (2017-11-07):
[0001193125-17-164153:note_history:72]
As of March 31, 2017, the Company drew down $1.3 million from
 this facility, which is recorded as short-term loans in the
 unaudited condensed consolidated balance sheets. The agreement
 bears interest for discount charge at 1.85% per annum above
 Bank of England base rate.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-07):
[0001193125-17-335712:note_history:73]
The movement of long-term loans for the three months ended
 September 29, 2017 and September 30, 2016 were as
 follows:
  (was, 2017-05-09, similarity 0.6794):
[0001193125-17-164153:note_history:73]
The movement of long-term borrowings was as follows for the nine
 months ended March 31, 2017 and March 25, 2016:

- added (2017-11-07):
[0001193125-17-335712:note_history:74]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 29, 2017 |  |  | September 30, 2016 |  |
| Opening balance |  | $ | 36,400 |  |  | $ | 54,500 |  |
| Repayments during the period |  |  | (3,400 | ) |  |  | (4,900 | ) |
| Closing balance |  | $ | 33,000 |  |  | $ | 49,600 |  |

- removed (2017-11-07):
[0001193125-17-164153:note_history:75]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 31, 2017 |  |  | March 25, 2016 |  |
| Opening balance |  | $ | 54,500 |  |  | $ | 10,500 |  |
| Repayments during the period |  |  | (14,700 | ) |  |  | (4,500 | ) |
| Closing balance |  | $ | 39,800 |  |  | $ | 6,000 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-07):
[0001193125-17-335712:note_history:76]
|  |  |  |  |  |  | As of |  |  | As of |  |
| (amount in thousands) |  |  |  |  |  | September 29, |  |  | June 30, |  |
| Rate (1) |  | Conditions |  | Maturity |  | 2017 |  |  | 2017 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  | October 2017 (2) |  | $ | 34,000 |  |  | $ | 34,000 |  |
| Short-term loans from bank: |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank Base rate +1.85% per annum |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  | — |  |  |  | 1,003 |  |
| Current portion of long-term borrowing |  |  |  |  |  |  | 13,600 |  |  |  | 13,600 |  |
|  |  |  |  |  |  |  | 47,600 |  |  |  | 48,603 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  | (179 | ) |  |  | (201 | ) |
|  |  |  |  |  |  | $ | 47,421 |  |  | $ | 48,402 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  | Repayable in quarterly installments |  | May 2019 |  | $ | 33,000 |  |  | $ | 36,400 |  |
|  |  |  |  |  |  |  | 33,000 |  |  |  | 36,400 |  |
| Less: Current portion |  |  |  |  |  |  | (13,600 | ) |  |  | (13,600 | ) |
| Unamortized debt issuance costs |  |  |  |  |  |  | (62 | ) |  |  | (99 | ) |
| Non-current portion |  |  |  |  |  | $ | 19,338 |  |  | $ | 22,701 |  |
  (was, 2017-05-09, similarity 0.7162):
[0001193125-17-164153:note_history:76]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  | As of |  |  | As of |  |
|  |  |  |  |  |  |  | March 31, |  |  | June 24, |  |
| Rate (1) |  | Conditions |  | Maturity |  |  | 2017 |  |  | 2016 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  |  | April 2017 (2) |  |  | $ | 34,000 |  |  | $ | 6,500 |  |
| Short-term borrowings from bank: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bank of England base rate +1.85% per annum |  | Repayable based on credit terms of secured accounts receivable |  |  |  |  |  |  | 1,257 |  |  |  | — |  |
| Bank of England base rate + 2.2% per annum (3) |  | Repayable on monthly basis |  |  | May 2017 |  |  |  | 23 |  |  |  | — |  |
| Current portion of long-term borrowing |  |  |  |  |  |  |  |  | 13,600 |  |  |  | 18,100 |  |
|  |  |  |  |  |  |  |  |  | 48,880 |  |  |  | 24,600 |  |
| Less: Unamortized debt issuance costs |  |  |  |  |  |  |  |  | (222 | ) |  |  | (293 | ) |
|  |  |  |  |  |  |  |  | $ | 48,658 |  |  | $ | 24,307 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments |  |  | March 2017 |  |  | $ | — | (4) |  | $ | 4,500 |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.75% per annum |  | Repayable in quarterly installments |  |  | May 2019 |  |  |  | 39,800 |  |  |  | 50,000 |  |
|  |  |  |  |  |  |  |  |  | 39,800 |  |  |  | 54,500 |  |
| Less: Current portion |  |  |  |  |  |  |  |  | (13,600 | ) |  |  | (18,100 | ) |
| Unamortized debt issuance costs |  |  |  |  |  |  |  |  | (141 | ) |  |  | (300 | ) |
| Non-current portion |  |  |  |  |  |  |  | $ | 26,059 |  |  | $ | 36,100 |  |

- changed (2017-11-07):
[0001193125-17-335712:note_history:77]
| (2) | In September 2017, the maturity date was extended to October 2017. |
  (was, 2017-05-09, similarity 0.8462):
[0001193125-17-164153:note_history:77]
| (2) | In March 2017, the maturity date was extended to April 2017. |

- removed (2017-11-07):
[0001193125-17-164153:note_history:78]
The Company’s total borrowings, including short-term and
 long-term borrowings, consisted of the following:

- removed (2017-11-07):
[0001193125-17-164153:note_history:79]
| (3) | As of March 31, 2017, the carrying amount of plant and machinery of Exception EMS secured to such loan was $0.8 million. Under the conditions stipulated in the loan agreement, this loan will be cross securitized, cross default and co-terminus with the short terms loans of $1.3 million which are secured by accounts receivable. |

- removed (2017-11-07):
[0001193125-17-164153:note_history:80]
| (4) | In March 2017, a subsidiary fully repaid the long term borrowing. The carrying amount of assets secured and pledged as collateral to such loan as of March 31, 2017 and June 24, 2016 was $45.9 million and $47.7 million, respectively. In April 2017, the bank released certain property, plant and equipment of the subsidiary which had been secured and pledged as collateral to such loans. |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-07):
[0001193125-17-335712:note_history:81]
Undrawn available credit facilities classified by availability
 period of future borrowing as of September 29, 2017 and
 June 30, 2017 were as follows:
  (was, 2017-05-09, similarity 0.9635):
[0001193125-17-164153:note_history:81]
Undrawn available credit facilities classified by availability
 period of future borrowing as of March 31, 2017 and
 June 24, 2016 were as follows:

- changed (2017-11-07):
[0001193125-17-335712:note_history:82]
| (amount in thousands) |  | September 29, 2017 |  |  | June 30, 2017 |  |
| Short-term |  | $ | — |  |  | $ | 1,965 |  |
| Long-term |  | $ | 116,000 |  |  | $ | 116,000 |  |
  (was, 2017-05-09, similarity 0.9556):
[0001193125-17-164153:note_history:82]
| (amount in thousands) |  | March 31, 2017 |  |  | June 24, 2016 |  |
| Short-term |  | $ | 4,799 |  |  | $ | 1,414 |  |
| Long-term |  | $ | 126,200 |  |  | $ | 143,500 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-11-07):
[0001193125-17-335712:note_history:83]
As of September 29, 2017, future maturities of long-term debt
 during each fiscal year were as follows:
  (was, 2017-05-09, similarity 0.8866):
[0001193125-17-164153:note_history:83]
As of March 31, 2017, future maturities of long-term
 borrowings during each fiscal year were as follows:

- changed (2017-11-07):
[0001193125-17-335712:note_history:84]
| (amount in thousands) |  |  |  |
| 2018 (remaining nine months) |  | $ | 10,200 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 33,000 |  |
  (was, 2017-05-09, similarity 0.9038):
[0001193125-17-164153:note_history:84]
| (amount in thousands) |  |  |  |
| 2017 (remaining three months) |  | $ | 3,400 |  |
| 2018 |  |  | 13,600 |  |
| 2019 |  |  | 22,800 |  |
| Total |  | $ | 39,800 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2017-11-07):
[0001193125-17-335712:note_history:85]
| 19. | Subsequent event |

- added (2017-11-07):
[0001193125-17-335712:note_history:86]
As part of the Company’s ongoing efforts to achieve greater
 efficiencies in all areas of its business, on October 30,
 2017, the Company implemented a reduction in workforce and incurred
 expenses of approximately $1.7 million, which represented
 severance and benefits costs incurred for the termination of
 approximately 204 employees in accordance with contractual
 obligations and local regulations. The Company will record this
 expense in the quarter ending December 29, 2017.
