# FN 8-K — 0001193125-17-334331 filed 2017-11-06

## item codes, every 8-K on or before 2017-11-07

- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2017-11-07

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-334331:8k_2_02:1]
EX-99.1
2
d488934dex991.htm
EX-99.1

[0001193125-17-334331:8k_2_02:2]
EX-99.1

[0001193125-17-334331:8k_2_02:3]
Exhibit 99.1

[0001193125-17-334331:8k_2_02:4]
Fabrinet Announces First Quarter Fiscal Year 2018 Financial Results

[0001193125-17-334331:8k_2_02:5]
BANGKOK, Thailand – November 6, 2017 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision
optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its first quarter ended September 29, 2017.

[0001193125-17-334331:8k_2_02:6]
Tom Mitchell, Executive Chairman of Fabrinet, said, “Our first quarter revenue was within our guidance range. Growth from datacom and non-optical communications products were healthy compared to a year ago, with new programs and advanced technologies including silicon photonics and QSFP28 as notable contributors. However, tempered demand for
telecom products resulted in a flat performance in that category compared to a year ago.”

[0001193125-17-334331:8k_2_02:7]
“We believe our strategy to drive our growth by
attracting new customers and winning new programs from existing customers, while supporting increased production of existing programs continues to be successful,” added Mr. Mitchell. “We are optimistic that by continuing to execute on
this strategy we can continue to drive profitable growth as we look ahead.”

[0001193125-17-334331:8k_2_02:8]
First Quarter Fiscal Year 2018 Financial Highlights

[0001193125-17-334331:8k_2_02:9]
GAAP Results

[0001193125-17-334331:8k_2_02:10]
|  | • |  | Revenue for the first quarter of fiscal year 2018, a 13-week quarter, was $357.3 million, an increase of 8% compared to revenue of $332.0 for the comparable period in fiscal year 2017, a 14-week quarter. |

[0001193125-17-334331:8k_2_02:11]
|  | • |  | GAAP net income for the first quarter of fiscal year 2018 was $21.0 million, compared to GAAP net income of $22.8 million for the first quarter of fiscal year 2017. GAAP net income for the first quarter of fiscal year 2018 included a foreign exchange loss of $1.9 million, or $0.05 per diluted share. |

[0001193125-17-334331:8k_2_02:12]
|  | • |  | GAAP net income per diluted share for the first quarter of fiscal year 2018 was $0.55, compared to GAAP net income per diluted share of $0.61 for the first quarter of fiscal year 2017. |

[0001193125-17-334331:8k_2_02:13]
Non-GAAP Results

[0001193125-17-334331:8k_2_02:14]
|  | • |  | Non-GAAP net income for the first quarter of fiscal year 2018 was $28.6 million, compared to non-GAAP net income of $29.7 million for the same period a year ago. |

[0001193125-17-334331:8k_2_02:15]
|  | • |  | Non-GAAP net income per diluted share for the first quarter of fiscal year 2018 was $0.75, a decrease from non-GAAP net income per diluted share of $0.80 for the same period a year ago. Non-GAAP net income for the first quarter of fiscal year 2018 included a foreign exchange loss of $1.9 million, or $0.05 per diluted share. |

[0001193125-17-334331:8k_2_02:16]
Business Outlook

[0001193125-17-334331:8k_2_02:17]
Based on information
available as of November 6, 2017, Fabrinet is issuing guidance for its second fiscal quarter ending December 29, 2017, as follows:

[0001193125-17-334331:8k_2_02:18]
|  | • |  | Fabrinet expects second quarter revenue to be in the range of $328 million to $332 million. |

[0001193125-17-334331:8k_2_02:19]
|  | • |  | GAAP net income per diluted share is expected to be in the range of $0.43 to $0.45, based on approximately 38.2 million fully diluted shares outstanding. |

[0001193125-17-334331:8k_2_02:20]
|  | • |  | Non-GAAP net income per diluted share is expected to be in the range of $0.69 to $0.71, based on approximately 38.2 million fully diluted shares outstanding. |

[0001193125-17-334331:8k_2_02:21]
Conference Call Information

[0001193125-17-334331:8k_2_02:22]
| What: |  | Fabrinet First Quarter Fiscal Year 2018 Financial Results Conference Call |
| When: |  | Monday, November 6, 2017 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic |
|  |  | (253) 237-1137, international |
|  |  | Passcode: 9499299 |
| Replay: |  | (855) 859-2056, domestic |
|  |  | (404) 537-3406, international |
|  |  | Passcode: 9499299 |
| Webcast: |  | http://investor.fabrinet.com (live and replay) |

[0001193125-17-334331:8k_2_02:23]
This press release and any other information related to the call will also be posted on Fabrinet’s website at
http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-17-334331:8k_2_02:24]
About Fabrinet

[0001193125-17-334331:8k_2_02:25]
Fabrinet is a leading provider of
advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive
components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain
management, manufacturing, advanced packaging, integration, final assembly and test. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in
Thailand, the United States of America, the People’s Republic of China and the United Kingdom. For more information visit: www.fabrinet.com.

[0001193125-17-334331:8k_2_02:26]
Forward-Looking Statements

[0001193125-17-334331:8k_2_02:27]
Use of Non-GAAP Financials

[0001193125-17-334331:8k_2_02:28]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful
supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; depreciation of fair value uplift; executive separation costs;
amortization of intangibles; business combination expenses; gain on foreign currency contracts; amortization of debt issuance costs; and restructuring charges. We have excluded these items in order to enhance investors’ understanding of our
underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial
measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001193125-17-334331:8k_2_02:29]
These non-GAAP financial measures are used to: (1) measure company performance against historical results,
(2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001193125-17-334331:8k_2_02:30]
SOURCE: Fabrinet

[0001193125-17-334331:8k_2_02:31]
Investor Contact:

[0001193125-17-334331:8k_2_02:32]
Garo Toomajanian

[0001193125-17-334331:8k_2_02:33]
ir@fabrinet.com

[0001193125-17-334331:8k_2_02:34]
FABRINET

[0001193125-17-334331:8k_2_02:35]
UNAUDITED CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-17-334331:8k_2_02:36]
| (in thousands of U.S. dollars, except share data) |  | September 29,2017 |  |  | June 30,2017 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 111,631 |  |  | $ | 133,825 |  |
| Marketable securities |  |  | 151,635 |  |  |  | 151,450 |  |
| Trade accounts receivable, net |  |  | 275,418 |  |  |  | 264,349 |  |
| Inventory, net |  |  | 255,104 |  |  |  | 238,665 |  |
| Prepaid expenses |  |  | 7,894 |  |  |  | 6,306 |  |
| Other current assets |  |  | 7,667 |  |  |  | 4,159 |  |
| Total current assets |  |  | 809,349 |  |  |  | 798,754 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Restricted cash in connection with business acquisition |  |  | 3,414 |  |  |  | 3,312 |  |
| Property, plant and equipment, net |  |  | 217,985 |  |  |  | 216,881 |  |
| Intangibles, net |  |  | 5,657 |  |  |  | 5,840 |  |
| Goodwill |  |  | 3,923 |  |  |  | 3,806 |  |
| Deferred tax assets |  |  | 2,730 |  |  |  | 2,905 |  |
| Deferred debt issuance costs on revolving loan and other non-current assets |  |  | 1,497 |  |  |  | 1,577 |  |
| Total non-current assets |  |  | 235,206 |  |  |  | 234,321 |  |
| Total Assets |  | $ | 1,044,555 |  |  | $ | 1,033,075 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Bank borrowings, net of unamortized debt issuance costs |  | $ | 47,421 |  |  | $ | 48,402 |  |
| Trade accounts payable |  |  | 203,685 |  |  |  | 215,262 |  |
| Fixed assets payable |  |  | 4,658 |  |  |  | 8,141 |  |
| Capital lease liability, current portion |  |  | 343 |  |  |  | 344 |  |
| Income tax payable |  |  | 2,469 |  |  |  | 1,976 |  |
| Accrued payroll, bonus and related expenses |  |  | 14,538 |  |  |  | 13,852 |  |
| Accrued expenses |  |  | 14,858 |  |  |  | 9,227 |  |
| Other payables |  |  | 12,042 |  |  |  | 14,068 |  |
| Total current liabilities |  |  | 300,014 |  |  |  | 311,272 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term loan from bank, non-current portion, net of unamortized debt issuance costs |  |  | 19,338 |  |  |  | 22,701 |  |
| Deferred tax liability |  |  | 1,510 |  |  |  | 1,981 |  |
| Capital lease liability, non-current portion |  |  | 967 |  |  |  | 1,024 |  |
| Deferred liability in connection with business acquisition |  |  | 3,414 |  |  |  | 3,312 |  |
| Severance liabilities |  |  | 9,058 |  |  |  | 8,488 |  |
| Other non-current liabilities |  |  | 2,791 |  |  |  | 2,723 |  |
| Total non-current liabilities |  |  | 37,078 |  |  |  | 40,229 |  |
| Total Liabilities |  |  | 337,092 |  |  |  | 351,501 |  |
| Commitments and contingencies (Note 16) |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no outstanding as of September 29, 2017 and June 30, 2017) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 37,572,302 shares and 37,340,496 shares issued and outstanding as of September 29, 2017 and June 30, 2017, respectively) |  |  | 376 |  |  |  | 373 |  |
| Additional paid-in capital |  |  | 137,593 |  |  |  | 133,293 |  |
| Accumulated other comprehensive income (loss) |  |  | 206 |  |  |  | (348 | ) |
| Retained earnings |  |  | 569,288 |  |  |  | 548,256 |  |
| Total Shareholders’ Equity |  |  | 707,463 |  |  |  | 681,574 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 1,044,555 |  |  | $ | 1,033,075 |  |

[0001193125-17-334331:8k_2_02:37]
FABRINET

[0001193125-17-334331:8k_2_02:38]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND

[0001193125-17-334331:8k_2_02:39]
COMPREHENSIVE INCOME

[0001193125-17-334331:8k_2_02:40]
|  |  | Three Months Ended |  |
| (in thousands of U.S. dollars, except per share amounts) |  | September 29,2017 |  |  | September 30,2016 |  |
| Revenues |  | $ | 357,313 |  |  | $ | 332,043 |  |
| Cost of revenues |  |  | (316,981 | ) |  |  | (292,435 | ) |
| Gross profit |  |  | 40,332 |  |  |  | 39,608 |  |
| Selling, general and administrative expenses |  |  | (15,678 | ) |  |  | (15,832 | ) |
| Operating income |  |  | 24,654 |  |  |  | 23,776 |  |
| Interest income |  |  | 809 |  |  |  | 437 |  |
| Interest expense |  |  | (853 | ) |  |  | (1,322 | ) |
| Foreign exchange (loss) gain, net |  |  | (1,934 | ) |  |  | 1,657 |  |
| Other income |  |  | 97 |  |  |  | 143 |  |
| Income before income taxes |  |  | 22,773 |  |  |  | 24,691 |  |
| Income tax expense |  |  | (1,740 | ) |  |  | (1,925 | ) |
| Net income |  |  | 21,033 |  |  |  | 22,766 |  |
| Other comprehensive income, net of tax: |  |  |  |  |  |  |  |  |
| Change in net unrealized gains (loss) on marketable securities |  |  | 29 |  |  |  | (187 | ) |
| Change in net unrealized loss on derivative instruments |  |  | (1 | ) |  |  | (158 | ) |
| Change in foreign currency translation adjustment |  |  | 526 |  |  |  | 741 |  |
| Total other comprehensive income, net of tax |  |  | 554 |  |  |  | 396 |  |
| Net comprehensive income |  | $ | 21,587 |  |  | $ | 23,162 |  |
| Earnings per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.56 |  |  | $ | 0.63 |  |
| Diluted |  | $ | 0.55 |  |  | $ | 0.61 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |
| Basic |  |  | 37,447 |  |  |  | 36,404 |  |
| Diluted |  |  | 38,163 |  |  |  | 37,330 |  |

[0001193125-17-334331:8k_2_02:41]
FABRINET

[0001193125-17-334331:8k_2_02:42]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-17-334331:8k_2_02:43]
|  |  | Three Months Ended |  |
| (in thousands of U.S. dollars) |  | September 29,2017 |  |  | September 30,2016 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income for the period |  | $ | 21,033 |  |  | $ | 22,766 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 7,419 |  |  |  | 5,113 |  |
| Gain on disposal of property, plant and equipment |  |  | (131 | ) |  |  | (40 | ) |
| Loss from sales and maturities of available-for-sale securities |  |  | 353 |  |  |  | 100 |  |
| Amortization of investment (premium) discount |  |  | (216 | ) |  |  | 166 |  |
| Amortization of deferred debt issuance costs |  |  | 150 |  |  |  | 908 |  |
| (Reversal of) allowance for doubtful accounts |  |  | (1 | ) |  |  | 3 |  |
| Unrealized loss (gain) on exchange rate and fair value of derivative instruments |  |  | 2,026 |  |  |  | (1,913 | ) |
| Share-based compensation |  |  | 6,920 |  |  |  | 5,611 |  |
| Deferred income tax |  |  | (307 | ) |  |  | 311 |  |
| Other non-cash expenses |  |  | 629 |  |  |  | 453 |  |
| Reversal of inventory obsolescence |  |  | (292 | ) |  |  | (62 | ) |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | (11,122 | ) |  |  | (11,876 | ) |
| Inventory |  |  | (16,032 | ) |  |  | (21,290 | ) |
| Other current assets and non-current assets |  |  | (7,263 | ) |  |  | 3,285 |  |
| Trade accounts payable |  |  | (11,323 | ) |  |  | 3,103 |  |
| Income tax payable |  |  | 493 |  |  |  | 1,035 |  |
| Other current liabilities and non-current liabilities |  |  | 4,610 |  |  |  | (8,675 | ) |
| Net cash used in operating activities |  |  | (3,054 | ) |  |  | (1,002 | ) |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of marketable securities |  |  | (26,969 | ) |  |  | (32,737 | ) |
| Proceeds from sales of marketable securities |  |  | 11,730 |  |  |  | 13,061 |  |
| Proceeds from maturities of marketable securities |  |  | 14,947 |  |  |  | 13,230 |  |
| Payments in connection with business acquisition, net of cash acquired |  |  | — |  |  |  | (9,664 | ) |
| Purchase of property, plant and equipment |  |  | (11,203 | ) |  |  | (27,090 | ) |
| Purchase of intangibles |  |  | (702 | ) |  |  | (178 | ) |
| Proceeds from disposal of property, plant and equipment |  |  | 142 |  |  |  | 107 |  |
| Net cash used in investing activities |  |  | (12,055 | ) |  |  | (43,271 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Proceeds from revolving loans |  |  | — |  |  |  | 13,500 |  |
| Repayment of short-term loans from bank |  |  | (992 | ) |  |  | — |  |
| Repayment of long-term loans from bank |  |  | (3,400 | ) |  |  | (4,900 | ) |
| Repayment of capital lease liability |  |  | (95 | ) |  |  | — |  |
| Proceeds from issuance of ordinary shares under employee share option plans |  |  | 931 |  |  |  | 2,708 |  |
| Withholding tax related to net share settlement of restricted share units |  |  | (3,550 | ) |  |  | (867 | ) |
| Net cash (used in) provided by financing activities |  |  | (7,106 | ) |  |  | 10,441 |  |
| Net decrease in cash, cash equivalents and restricted cash |  |  | (22,215 | ) |  |  | (33,832 | ) |
| Movement in cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 137,137 |  |  |  | 142,804 |  |
| Decrease in cash, cash equivalents and restricted cash |  |  | (22,215 | ) |  |  | (33,832 | ) |
| Effect of exchange rate on cash, cash equivalents and restricted cash |  |  | 123 |  |  |  | 267 |  |
| Cash, cash equivalents and restricted cash at end of period |  | $ | 115,045 |  |  | $ | 109,239 |  |
| Non-cash investing and financing activities |  |  |  |  |  |  |  |  |
| Construction, software related and equipment-related payables |  | $ | 4,658 |  |  | $ | 19,694 |  |

[0001193125-17-334331:8k_2_02:44]
FABRINET

[0001193125-17-334331:8k_2_02:45]
UNAUDITED CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-17-334331:8k_2_02:46]
(Continued)

[0001193125-17-334331:8k_2_02:47]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within
the unaudited condensed consolidated balance sheets that sum to the total of same amounts shown in the unaudited condensed consolidated statements of cash flows:

[0001193125-17-334331:8k_2_02:48]
| (amount in thousands) |  | As ofSeptember 29,2017 |  |  | As ofSeptember 30,2016 |  |
| Cash and cash equivalents |  | $ | 111,631 |  |  | $ | 105,860 |  |
| Restricted cash in connection with business acquisition (non-current assets) |  |  | 3,414 |  |  |  | 3,379 |  |
| Cash, cash equivalents and restricted cash |  | $ | 115,045 |  |  | $ | 109,239 |  |

[0001193125-17-334331:8k_2_02:49]
FABRINET

[0001193125-17-334331:8k_2_02:50]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-17-334331:8k_2_02:51]
|  |  | Three Months Ended |  |
|  |  | September 29, 2017 |  |  | September 30, 2016 |  |
| (in thousands of U.S. dollars, except per share data) |  | Netincome |  |  | Diluted EPS |  |  | Netincome |  |  | DilutedEPS |  |
| GAAP measures |  | $ | 21,033 |  |  | $ | 0.55 |  |  | $ | 22,766 |  |  | $ | 0.61 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,901 |  |  |  | 0.05 |  |  |  | 1,014 |  |  |  | 0.03 |  |
| Depreciation of fair value uplift |  |  | 67 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |
| Total related to gross profit |  |  | 1,968 |  |  |  | 0.05 |  |  |  | 1,014 |  |  |  | 0.03 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 5,019 |  |  |  | 0.13 |  |  |  | 4,598 |  |  |  | 0.12 |  |
| Executive separation costs |  |  | — |  |  |  | — |  |  |  | 577 |  |  |  | 0.02 |  |
| Amortization of intangibles |  |  | 169 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |
| Business combination expenses |  |  | 106 |  |  |  | 0.00 |  |  |  | 1,411 |  |  |  | 0.04 |  |
| Total related to selling, general and administrative expenses |  |  | 5,294 |  |  |  | 0.14 |  |  |  | 6,586 |  |  |  | 0.18 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on foreign currency contracts |  |  | — |  |  |  | — |  |  |  | (1,713 | ) |  |  | (0.05 | ) |
| Amortization of debt issuance costs |  |  | 273 |  |  |  | 0.01 |  |  |  | 1,063 |  |  |  | 0.03 |  |
| Total related to other incomes and other expenses |  |  | 273 |  |  |  | 0.01 |  |  |  | (650 | ) |  |  | (0.02 | ) |
| Total related to net income & EPS |  |  | 7,535 |  |  |  | 0.20 |  |  |  | 6,950 |  |  |  | 0.19 |  |
| Non-GAAP measures |  | $ | 28,568 |  |  | $ | 0.75 |  |  | $ | 29,716 |  |  | $ | 0.80 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 38,163 |  |  |  |  |  |  |  | 37,330 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 38,163 |  |  |  |  |  |  |  | 37,330 |  |

[0001193125-17-334331:8k_2_02:52]
FABRINET

[0001193125-17-334331:8k_2_02:53]
GUIDANCE FOR QUARTER ENDING DECEMBER 29, 2017

[0001193125-17-334331:8k_2_02:54]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-17-334331:8k_2_02:55]
|  |  | Diluted |
|  |  | EPS |
| GAAP net income per diluted share: |  | $0.43 to $0.45 |
| Related to cost of revenues: |  |  |
| Share-based compensation expenses |  | 0.05 |
| Total related to gross profit |  | 0.05 |
| Related to selling, general and administrative expenses: |  |  |
| Share-based compensation expenses |  | 0.14 |
| Restructuring charges |  | 0.05 |
| Business combination expenses |  | 0.01 |
| Total related to selling, general and administrative expenses |  | 0.20 |
| Related to other incomes and other expenses: |  |  |
| Amortization of debt issuance costs |  | 0.01 |
| Total related to net income & EPS |  | 0.26 |
| Non-GAAP net income per diluted share |  | $0.69 to $0.71 |
