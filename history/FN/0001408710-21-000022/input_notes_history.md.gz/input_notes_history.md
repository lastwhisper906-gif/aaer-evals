# FN note change history — 0001408710-21-000011 → 0001408710-21-000022


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-05-04):
[0001408710-21-000022:note_history:1]
As of March 26, 2021, the Company had no outstanding standby letter of credit.
  (was, 2021-02-02, similarity 0.6098):
[0001408710-21-000011:note_history:1]
As of December 25, 2020, the Company had an outstanding commitment to third parties of $515.5 million.

- changed (2021-05-04):
[0001408710-21-000022:note_history:2]
As of June 26, 2020, the Company had one outstanding standby letter of credit of 6.0 million Euros related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. The standby letter of credit was backed by cash collateral of $7.4 million. This standby letter of credit expired on December 31, 2020 and the corresponding cash collateral was released in January 2021.
  (was, 2021-02-02, similarity 0.947):
[0001408710-21-000011:note_history:2]
As of December 25, 2020 and June 26, 2020, the Company had one outstanding standby letter of credit of 6.0 million Euros related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. As of December 25, 2020 and June 26, 2020, the standby letter of credit was backed by cash collateral of $7.4 million.  This standby letter of credit expired on December 31, 2020 and the corresponding cash collateral was released in January 2021.

- changed (2021-05-04):
[0001408710-21-000022:note_history:3]
As of March 26, 2021 and June 26, 2020, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business expenses totaling to $1.6 million or Thai Baht 50.2 million and there were other bank guarantees given by a bank on behalf of our subsidiaries in the PRC and the U.K. to support their operations. As of March 26, 2021, the Company had an outstanding bank guarantee of its subsidiary in the PRC to support the subsidiary's operations totaling Renminbi 1.0 million. The bank guarantee was backed by cash collateral of $0.2 million. The bank guarantee given on behalf of our subsidiaries in the U.K. was not material. As of June 26, 2020, these bank guarantees were immaterial.
  (was, 2021-02-02, similarity 0.6642):
[0001408710-21-000011:note_history:3]
As of December 25, 2020 and June 26, 2020, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business expenses totaling to $1.7 million and $1.6 million, respectively, and there were other bank guarantees given by a bank on behalf of our subsidiaries in China and the U.K. to support their operations. As of December 25, 2020, the Company had an outstanding bank guarantee of its subsidiary in China to support the subsidiary's operations of Renmibi 1.0 million. The bank guarantee was backed by cash collateral of $0.2 million. As of June 26, 2020, these bank guarantees were not material.

- changed (2021-05-04):
[0001408710-21-000022:note_history:4]
Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.
  (was, 2021-02-02, similarity 0.9982):
[0001408710-21-000011:note_history:4]
Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

- changed (2021-05-04):
[0001408710-21-000022:note_history:5]
As of March 26, 2021, the Company had a purchase obligation and other commitments to third parties of $661.2 million.
  (was, 2021-02-02, similarity 0.794):
[0001408710-21-000011:note_history:5]
As of December 25, 2020, the Company had an outstanding commitment to third parties of $10.1 million.

- added (2021-05-04):
[0001408710-21-000022:note_history:6]
As of March 26, 2021, the Company had a purchase obligation and other commitments to third parties of $62.1 million.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-05-04):
[0001408710-21-000022:note_history:7]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of March 26, 2021 and for the three and nine  months ended March 26, 2021 and March 27, 2020 includes normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 26, 2020.
  (was, 2021-02-02, similarity 0.9549):
[0001408710-21-000011:note_history:7]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of December 25, 2020 and for the three and six months ended December 25, 2020 and December 27, 2019 includes normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 26, 2020.

- changed (2021-05-04):
[0001408710-21-000022:note_history:8]
The results for the three and nine  months ended March 26, 2021 may not be indicative of results for the year ending June 25, 2021 or any future periods.
  (was, 2021-02-02, similarity 0.951):
[0001408710-21-000011:note_history:8]
The results for the three and six months ended December 25, 2020 may not be indicative of results for the year ending June 25, 2021 or any future periods.

- changed (2021-05-04):
[0001408710-21-000022:note_history:9]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended March 26, 2021 and March 27, 2020 each consisted of 13 weeks. The nine months ended March 26, 2021 and March 27, 2020 each consisted of 39 weeks. Fiscal year 2021 will be comprised of 52 weeks and will end on June 25, 2021.
  (was, 2021-02-02, similarity 0.8019):
[0001408710-21-000011:note_history:9]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended December 25, 2020 and December 27, 2019 each consisted of 13 weeks. The six months ended December 25, 2020 and December 27, 2019 each consisted of 26 weeks. Fiscal year 2021 will be comprised of 52 weeks and will end on June 25, 2021.

- changed (2021-05-04):
[0001408710-21-000022:note_history:10]
As of March 26, 2021, the derivative assets and liabilities were measured at fair value, but the gross fair value amount is presented in the unaudited condensed consolidated balance sheets. Additionally, a classification of current and non-current portion is determined by the maturity date of that derivative (e.g., a derivative that matures within one year is classified as current).
  (was, 2021-02-02, similarity 0.9829):
[0001408710-21-000011:note_history:10]
As of December 25, 2020, the derivative assets and liabilities were measured at fair value, but the gross fair value amount is presented in the unaudited condensed consolidated balance sheets. Additionally, a classification of current and non-current portion is determined by the maturity date of that derivative (e.g., a derivative that matures within one year is classified as current).

- changed (2021-05-04):
[0001408710-21-000022:note_history:11]
Management estimates the expected credit losses of financial assets using relevant available information from internal and external sources relating to historical credit loss experience, current conditions and reasonable forecasts over a financial asset’s contractual term. Adjustments to historical loss information are made from qualitative and quantitative factors if economic conditions on the reporting date reflect stronger or weaker economic performance than the historical data implies based on management’s expectations of economic conditions on certain indicators of the Company, industry and economy. The Company reviews factors such as past collection experience, age of the accounts receivable and contract assets balance, significant trends in current balances, internal operations and macroeconomic conditions. In addition, the Company modified its impairment model to the Current Expected Credit Losses (“CECL”) model for available-for-sale (“AFS”) debt securities and discontinued using the concept of “other than temporary” impairment on these AFS debt
  (was, 2021-02-02, similarity 0.9437):
[0001408710-21-000011:note_history:11]
Management estimates the expected credit losses of financial assets using relevant available information from internal and external sources relating to historical credit loss experience, current conditions and reasonable forecasts over a financial asset’s contractual term. Adjustments to historical loss information are made from qualitative and quantitative factors if economic conditions on the reporting date reflect stronger or weaker economic performance than the historical data implies based on management’s expectations of economic conditions on certain indicators of the Company, industry and economy. The Company reviews factors such as past collection experience, age of the accounts receivable and contract assets balance, significant trends in current balances, internal operations and macroeconomic conditions. In addition, the Company modified its impairment model to the Current Expected Credit Losses (“CECL”) model for available-for-sale

- changed (2021-05-04):
[0001408710-21-000022:note_history:12]
securities. CECL on the AFS debt securities are recognized in interest income and other income (expense), net on the Company’s unaudited condensed consolidated statements of operations and comprehensive income, and any remaining unrealized losses, are included in accumulated other comprehensive income (loss) (“AOCI”) in the unaudited condensed consolidated balance sheet.
  (was, 2021-02-02, similarity 0.8674):
[0001408710-21-000011:note_history:12]
(“AFS”) debt securities and discontinued using the concept of “other than temporary” impairment on these AFS debt securities. CECL on the AFS debt securities are recognized in interest income and other income (expense), net on the Company’s unaudited condensed consolidated statements of operations and comprehensive income, and any remaining unrealized losses, are included in accumulated other comprehensive income (loss) (“AOCI”) in the unaudited condensed consolidated balance sheet.

- added (2021-05-04):
[0001408710-21-000022:note_history:13]
On January 1, 2021, FASB issued ASU 2021-01, “Reference Rate Reform (Topic 848).” This standard requires the measurement and recognition of expected credit losses for financial assets held at amortized cost. The amendments in this update clarify that certain optional expedients and exceptions in Topic 848 for contract modifications and hedge accounting apply to derivatives that are affected by the discounting transition. The Company immediately adopted this standard with no impact on its unaudited condensed consolidated financial statements.

- changed (2021-05-04):
[0001408710-21-000022:note_history:14]
Except for the adoption of ASC 326, ASC 820 and ASC 848, the Company has consistently applied the accounting policies to all periods presented in these unaudited condensed consolidated financial statements.
  (was, 2021-02-02, similarity 0.9579):
[0001408710-21-000011:note_history:14]
Except for the adoption of ASC 326, the Company has consistently applied the accounting policies to all periods presented in these unaudited condensed consolidated financial statements.

- changed (2021-05-04):
[0001408710-21-000022:note_history:15]
Management determines the appropriate classification of its investments at the time of purchase and re-evaluates the designations at each balance sheet date. The Company may sell certain of the Company’s short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s short-term investments generally range from three months to three years. The Company’s short-term investments, which consist of investments in U.S. Treasury, fixed income securities, liquidity funds that invest in short-term debt securities and certificates of deposit and time deposits, have been classified and accounted for as AFS. The AFS investments are carried at estimated fair value with any unrealized gains and losses, included in AOCI in the Company’s unaudited condensed consolidated balance sheet. The Company determines realized gains or losses on sale of marketable securities on a specific identification method and records such gains or losses as interest income and other income (expense), net in the unaudited condensed consolidated statements of operations and comprehensive income.
  (was, 2021-02-02, similarity 0.9967):
[0001408710-21-000011:note_history:15]
Management determines the appropriate classification of its investments at the time of purchase and re-evaluates the designations at each balance sheet date. The Company may sell certain of the Company’s short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s short-term investments generally range from three and six months to three years. The Company’s short-term investments, which consist of investments in U.S. Treasury, fixed income securities, liquidity funds that invest in short-term debt securities and certificates of deposit and time deposits, have been classified and accounted for as AFS. The AFS investments are carried at estimated fair value with any unrealized gains and losses, included in AOCI in the Company’s unaudited condensed consolidated balance sheet. The Company determines realized gains or losses on sale of marketable securities on a specific identification method and records such gains or losses as interest income and other income (expense), net in the unaudited condensed consolidated statements of operations and comprehensive income.

- changed (2021-05-04):
[0001408710-21-000022:note_history:16]
Accounts receivable are recorded and carried at the original invoiced amount less an allowance for any potential uncollectible amounts. The Company makes estimates of expected credit losses for the allowance for doubtful accounts based upon its assessment of various factors, including historical experience, the age of the accounts receivable balances, credit quality of its customers, current economic conditions, reasonable and supportable forecasts of future economic
  (was, 2021-02-02, similarity 0.7696):
[0001408710-21-000011:note_history:16]
Accounts receivable are recorded and carried at the original invoiced amount less an allowance for any potential uncollectible amounts. The Company makes estimates of expected credit losses for the allowance for doubtful accounts based upon its assessment of various factors, including historical experience, the age of the accounts receivable balances, credit quality of its customers, current economic conditions, reasonable and supportable forecasts of future economic conditions, and other factors that may affect the Company’s ability to collect from customers. The estimated credit loss allowance is recorded as selling, general and administrative expenses in the unaudited condensed consolidated statements of operations and comprehensive income.

- added (2021-05-04):
[0001408710-21-000022:note_history:17]
conditions, and other factors that may affect the Company’s ability to collect from customers. The estimated credit loss allowance is recorded as selling, general and administrative expenses in the unaudited condensed consolidated statements of operations and comprehensive income.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-04):
[0001408710-21-000022:note_history:18]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofMarch 26, 2021 |  | As ofJune 26, 2020 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 42,656 |  |  | $ | 51,797 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  | (71) |  |  | (95) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 30,397 |  |  | $ | 39,514 |  |
  (was, 2021-02-02, similarity 0.9923):
[0001408710-21-000011:note_history:18]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofDecember 25, 2020 |  | As ofJune 26, 2020 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 45,703 |  |  | $ | 51,797 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  | (79) |  |  | (95) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 33,436 |  |  | $ | 39,514 |  |

- changed (2021-05-04):
[0001408710-21-000022:note_history:19]
The movements of long-term borrowings for the nine months ended March 26, 2021 and March 27, 2020 were as follows:
  (was, 2021-02-02, similarity 0.892):
[0001408710-21-000011:note_history:19]
The movements of long-term borrowings for the six months ended December 25, 2020 and December 27, 2019 were as follows:

- changed (2021-05-04):
[0001408710-21-000022:note_history:20]
|  | Nine Months Ended |
| (amount in thousands) | March 26,2021 |  | March 27,2020 |
| Opening balance | $ | 51,797 |  |  | $ | 60,938 |  |
| Borrowings during the period | — |  |  | 60,938 |  |
| Repayments during the period | (9,141) |  |  | (67,032) |  |
| Closing balance | $ | 42,656 |  |  | $ | 54,844 |  |
  (was, 2021-02-02, similarity 0.908):
[0001408710-21-000011:note_history:20]
|  | Six Months Ended |
| (amount in thousands) | December 25,2020 |  | December 27,2019 |
| Opening balance | $ | 51,797 |  |  | $ | 60,938 |  |
| Borrowings during the period | — |  |  | 60,938 |  |
| Repayments during the period | (6,094) |  |  | (63,985) |  |
| Closing balance | $ | 45,703 |  |  | $ | 57,891 |  |

- changed (2021-05-04):
[0001408710-21-000022:note_history:21]
As of March 26, 2021, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2021-02-02, similarity 0.9548):
[0001408710-21-000011:note_history:21]
As of December 25, 2020, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2021-05-04):
[0001408710-21-000022:note_history:22]
| (amount in thousands) |  |
| 2021 (remaining three months) | $ | 6,094 |  |
| 2022 | 12,187 |  |
| 2023 | 12,187 |  |
| 2024 | 12,188 |  |
| Total | $ | 42,656 |  |
  (was, 2021-02-02, similarity 0.9675):
[0001408710-21-000011:note_history:22]
| (amount in thousands) |  |
| 2021 (remaining six months) | $ | 9,141 |  |
| 2022 | 12,187 |  |
| 2023 | 12,187 |  |
| 2024 | 12,188 |  |
| Total | $ | 45,703 |  |

- changed (2021-05-04):
[0001408710-21-000022:note_history:23]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of September 27,
2019) and $160.9 million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.
  (was, 2021-02-02, similarity 0.9951):
[0001408710-21-000011:note_history:23]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of December 27, 2019) and $160.9 million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

- changed (2021-05-04):
[0001408710-21-000022:note_history:24]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three and nine  months ended March 26, 2021, the Company recorded $0.2 million and $0.6 million, respectively, of interest expense in connection with this term loan.
  (was, 2021-02-02, similarity 0.6718):
[0001408710-21-000011:note_history:24]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be re-borrowed. During the three and six months ended December 25, 2020, the Company recorded $0.2 million and $0.4 million, respectively, of interest expense in connection with this term loan.

- changed (2021-05-04):
[0001408710-21-000022:note_history:25]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of March 26, 2021, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.
  (was, 2021-02-02, similarity 0.9901):
[0001408710-21-000011:note_history:25]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt to equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of December 25, 2020, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

- changed (2021-05-04):
[0001408710-21-000022:note_history:26]
As of March 26, 2021, there was $42.7 million outstanding under the term loan.
  (was, 2021-02-02, similarity 0.8986):
[0001408710-21-000011:note_history:26]
At December 25, 2020, there was $45.7 million outstanding under the term loan.

- changed (2021-05-04):
[0001408710-21-000022:note_history:27]
The most recent amendment on June 4, 2018 (i) reduced the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) refinanced the outstanding amounts under the revolving loan and term loan facilities into a $65.0 million term loan which was to be repaid in quarterly installments through the maturity date of June 04, 2023; and (iii) reduced the interest rate margins and commitment fees. The term loan bore interest, at the Company’s option, at a rate per annum equal to a LIBOR rate plus a spread of 1.50% to 2.25%, or a base rate plus a spread of 0.50% to 1.25%. During the three months ended March 27, 2020, the Company had no interest expense related to this term loan. During the nine months ended March 27, 2020, the Company recorded $0.5 million of interest expense in connection with this term loan.
  (was, 2021-02-02, similarity 0.8148):
[0001408710-21-000011:note_history:27]
The most recent amendment on June 4, 2018 (i) reduced the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) refinanced the outstanding amounts under the revolving loan and term loan facilities into a $65.0 million term loan which was to be repaid in quarterly installments through the maturity date of June 04, 2023; and (iii) reduced the interest rate margins and commitment fees. The term loan bore interest, at the Company’s option, at a rate per annum equal to a LIBOR rate plus a spread of 1.50% to 2.25%, or a base rate plus a spread of 0.50% to 1.25%. During the three and six months ended December 27, 2019, the Company recorded $0.5 million of interest expense in connection with this term loan for both periods.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-04):
[0001408710-21-000022:note_history:28]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of March 26, 2021 and June 26, 2020:
  (was, 2021-02-02, similarity 0.9679):
[0001408710-21-000011:note_history:28]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of December 25, 2020 and June 26, 2020:

- added (2021-05-04):
[0001408710-21-000022:note_history:29]
|  | March 26, 2021 |  | June 26, 2020 |
| (amount in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 62,641 |  |  | $ | 62,638 |  |  | $ | 76,127 |  |  | $ | 76,196 |  |
| Due between one to five years | 126,696 |  |  | 127,254 |  |  | 132,223 |  |  | 133,646 |  |
| Total | $ | 189,337 |  |  | $ | 189,892 |  |  | $ | 208,350 |  |  | $ | 209,842 |  |

- removed (2021-05-04):
[0001408710-21-000011:note_history:30]
|  | December 25, 2020 |  | June 26, 2020 |
| (amount in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 82,493 |  |  | $ | 82,508 |  |  | $ | 76,127 |  |  | $ | 76,196 |  |
| Due between one to five years | 116,454 |  |  | 117,564 |  |  | 132,223 |  |  | 133,646 |  |
| Total | $ | 198,947 |  |  | $ | 200,072 |  |  | $ | 208,350 |  |  | $ | 209,842 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-04):
[0001408710-21-000022:note_history:31]
The movements of long-term borrowings for the nine months ended March 26, 2021 and March 27, 2020 were as follows:
  (was, 2021-02-02, similarity 0.892):
[0001408710-21-000011:note_history:31]
The movements of long-term borrowings for the six months ended December 25, 2020 and December 27, 2019 were as follows:

- changed (2021-05-04):
[0001408710-21-000022:note_history:32]
|  | Nine Months Ended |
| (amount in thousands) | March 26,2021 |  | March 27,2020 |
| Opening balance | $ | 51,797 |  |  | $ | 60,938 |  |
| Borrowings during the period | — |  |  | 60,938 |  |
| Repayments during the period | (9,141) |  |  | (67,032) |  |
| Closing balance | $ | 42,656 |  |  | $ | 54,844 |  |
  (was, 2021-02-02, similarity 0.908):
[0001408710-21-000011:note_history:32]
|  | Six Months Ended |
| (amount in thousands) | December 25,2020 |  | December 27,2019 |
| Opening balance | $ | 51,797 |  |  | $ | 60,938 |  |
| Borrowings during the period | — |  |  | 60,938 |  |
| Repayments during the period | (6,094) |  |  | (63,985) |  |
| Closing balance | $ | 45,703 |  |  | $ | 57,891 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-04):
[0001408710-21-000022:note_history:33]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofMarch 26, 2021 |  | As ofJune 26, 2020 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 42,656 |  |  | $ | 51,797 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  | (71) |  |  | (95) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 30,397 |  |  | $ | 39,514 |  |
  (was, 2021-02-02, similarity 0.9923):
[0001408710-21-000011:note_history:33]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofDecember 25, 2020 |  | As ofJune 26, 2020 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 45,703 |  |  | $ | 51,797 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  | (79) |  |  | (95) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 33,436 |  |  | $ | 39,514 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-04):
[0001408710-21-000022:note_history:34]
As of March 26, 2021, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2021-02-02, similarity 0.9548):
[0001408710-21-000011:note_history:34]
As of December 25, 2020, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2021-05-04):
[0001408710-21-000022:note_history:35]
| (amount in thousands) |  |
| 2021 (remaining three months) | $ | 6,094 |  |
| 2022 | 12,187 |  |
| 2023 | 12,187 |  |
| 2024 | 12,188 |  |
| Total | $ | 42,656 |  |
  (was, 2021-02-02, similarity 0.9675):
[0001408710-21-000011:note_history:35]
| (amount in thousands) |  |
| 2021 (remaining six months) | $ | 9,141 |  |
| 2022 | 12,187 |  |
| 2023 | 12,187 |  |
| 2024 | 12,188 |  |
| Total | $ | 45,703 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-05-04):
[0001408710-21-000022:note_history:36]
| (amount in thousands, except percentages) | Three Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 230,177 |  |  |  |  | 661,410 |  |  |  |
| Others | 618 |  |  |  |  | 1,459 |  |  |  |
| Total revenue in North America | 230,795 |  |  | 48.2 | % |  | 662,869 |  |  | 48.4 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Malaysia | 22,910 |  |  |  |  | 107,700 |  |  |  |
| India | 56,719 |  |  |  |  | 85,535 |  |  |  |
| Israel | 25,796 |  |  |  |  | 82,915 |  |  |  |
| Hong Kong | 21,524 |  |  |  |  | 63,397 |  |  |  |
| Japan | 18,582 |  |  |  |  | 56,223 |  |  |  |
| Others | 21,770 |  |  |  |  | 71,477 |  |  |  |
| Total revenue in Asia-Pacific and others | 167,301 |  |  | 34.9 | % |  | 467,247 |  |  | 34.1 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 47,096 |  |  |  |  | 149,696 |  |  |  |
| U.K. | 15,298 |  |  |  |  | 40,742 |  |  |  |
| Germany | 7,543 |  |  |  |  | 19,596 |  |  |  |
| Others | 11,284 |  |  |  |  | 29,633 |  |  |  |
| Total revenue in Europe | $ | 81,221 |  |  | 16.9 | % |  | $ | 239,667 |  |  | 17.5 | % |
| Total revenue | $ | 479,317 |  |  | 100.0 | % |  | $ | 1,369,783 |  |  | 100.0 | % |

- added (2021-05-04):
[0001408710-21-000022:note_history:37]
| (amount in thousands, except percentages) | Three Months EndedMarch 27, 2020 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 27, 2020 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 206,329 |  |  |  |  | 630,023 |  |  |  |
| Others | 422 |  |  |  |  | 1,073 |  |  |  |
| Total revenue in North America | 206,751 |  |  | 50.3 | % |  | 631,096 |  |  | 51.0 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Malaysia | 52,414 |  |  |  |  | 136,698 |  |  |  |
| Japan | 24,985 |  |  |  |  | 78,362 |  |  |  |
| Hong Kong | 20,710 |  |  |  |  | 70,410 |  |  |  |
| Israel | 25,530 |  |  |  |  | 69,310 |  |  |  |
| China | 8,126 |  |  |  |  | 34,882 |  |  |  |
| Others | 9,874 |  |  |  |  | 11,547 |  |  |  |
| Total revenue in Asia-Pacific and others | 141,639 |  |  | 34.4 | % |  | 401,209 |  |  | 32.5 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 26,716 |  |  |  |  | 84,034 |  |  |  |
| U.K. | 22,297 |  |  |  |  | 52,941 |  |  |  |
| Germany | 5,600 |  |  |  |  | 41,207 |  |  |  |
| Others | 8,207 |  |  |  |  | 26,236 |  |  |  |
| Total revenue in Europe | $ | 62,820 |  |  | 15.3 | % |  | $ | 204,418 |  |  | 16.5 | % |
| Total revenue | $ | 411,210 |  |  | 100.0 | % |  | $ | 1,236,723 |  |  | 100.0 | % |

- removed (2021-05-04):
[0001408710-21-000011:note_history:38]
| (amount in thousands, except percentages) | Three Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |  | Six Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |
| North America | $ | 224,672 |  |  | 49.5 | % |  | $ | 432,074 |  |  | 48.5 | % |
| Asia-Pacific | 153,734 |  |  | 33.9 |  |  | 299,380 |  |  | 33.6 |  |
| Europe | 75,421 |  |  | 16.6 |  |  | 159,012 |  |  | 17.9 |  |
|  | $ | 453,827 |  |  | 100.0 | % |  | $ | 890,466 |  |  | 100.0 | % |

- removed (2021-05-04):
[0001408710-21-000011:note_history:39]
| (amount in thousands, except percentages) | Three Months EndedDecember 27, 2019 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2019 |  | As a % of TotalRevenues |
| North America | $ | 223,398 |  |  | 52.4 | % |  | $ | 424,345 |  |  | 51.4 | % |
| Asia-Pacific | 141,147 |  |  | 33.1 |  |  | 259,570 |  |  | 31.4 |  |
| Europe | 61,672 |  |  | 14.5 |  |  | 141,598 |  |  | 17.2 |  |
|  | $ | 426,217 |  |  | 100.0 | % |  | $ | 825,513 |  |  | 100.0 | % |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-05-04):
[0001408710-21-000022:note_history:40]
Revenues are attributed to a particular geographic area based on the bill-to-location of the Company’s customers. The Company operates in three geographic regions: North America, Asia-Pacific and others and Europe.
  (was, 2021-02-02, similarity 0.9736):
[0001408710-21-000011:note_history:40]
Revenues are attributed to a particular geographic area based on the bill-to-location of the Company’s customers. The Company operates in three geographic regions: North America, Asia-Pacific and Europe.

- added (2021-05-04):
[0001408710-21-000022:note_history:41]
| (amount in thousands, except percentages) | Three Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 230,177 |  |  |  |  | 661,410 |  |  |  |
| Others | 618 |  |  |  |  | 1,459 |  |  |  |
| Total revenue in North America | 230,795 |  |  | 48.2 | % |  | 662,869 |  |  | 48.4 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Malaysia | 22,910 |  |  |  |  | 107,700 |  |  |  |
| India | 56,719 |  |  |  |  | 85,535 |  |  |  |
| Israel | 25,796 |  |  |  |  | 82,915 |  |  |  |
| Hong Kong | 21,524 |  |  |  |  | 63,397 |  |  |  |
| Japan | 18,582 |  |  |  |  | 56,223 |  |  |  |
| Others | 21,770 |  |  |  |  | 71,477 |  |  |  |
| Total revenue in Asia-Pacific and others | 167,301 |  |  | 34.9 | % |  | 467,247 |  |  | 34.1 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 47,096 |  |  |  |  | 149,696 |  |  |  |
| U.K. | 15,298 |  |  |  |  | 40,742 |  |  |  |
| Germany | 7,543 |  |  |  |  | 19,596 |  |  |  |
| Others | 11,284 |  |  |  |  | 29,633 |  |  |  |
| Total revenue in Europe | $ | 81,221 |  |  | 16.9 | % |  | $ | 239,667 |  |  | 17.5 | % |
| Total revenue | $ | 479,317 |  |  | 100.0 | % |  | $ | 1,369,783 |  |  | 100.0 | % |

- added (2021-05-04):
[0001408710-21-000022:note_history:42]
| (amount in thousands, except percentages) | Three Months EndedMarch 27, 2020 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 27, 2020 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 206,329 |  |  |  |  | 630,023 |  |  |  |
| Others | 422 |  |  |  |  | 1,073 |  |  |  |
| Total revenue in North America | 206,751 |  |  | 50.3 | % |  | 631,096 |  |  | 51.0 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Malaysia | 52,414 |  |  |  |  | 136,698 |  |  |  |
| Japan | 24,985 |  |  |  |  | 78,362 |  |  |  |
| Hong Kong | 20,710 |  |  |  |  | 70,410 |  |  |  |
| Israel | 25,530 |  |  |  |  | 69,310 |  |  |  |
| China | 8,126 |  |  |  |  | 34,882 |  |  |  |
| Others | 9,874 |  |  |  |  | 11,547 |  |  |  |
| Total revenue in Asia-Pacific and others | 141,639 |  |  | 34.4 | % |  | 401,209 |  |  | 32.5 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 26,716 |  |  |  |  | 84,034 |  |  |  |
| U.K. | 22,297 |  |  |  |  | 52,941 |  |  |  |
| Germany | 5,600 |  |  |  |  | 41,207 |  |  |  |
| Others | 8,207 |  |  |  |  | 26,236 |  |  |  |
| Total revenue in Europe | $ | 62,820 |  |  | 15.3 | % |  | $ | 204,418 |  |  | 16.5 | % |
| Total revenue | $ | 411,210 |  |  | 100.0 | % |  | $ | 1,236,723 |  |  | 100.0 | % |

- changed (2021-05-04):
[0001408710-21-000022:note_history:43]
| (amount in thousands, except percentages) | Three Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |
| Optical communications | $ | 361,739 |  |  | 75.5 | % |  | $ | 1,053,496 |  |  | 76.9 | % |
| Lasers, sensors and other | 117,578 |  |  | 24.5 | % |  | 316,287 |  |  | 23.1 | % |
| Total | $ | 479,317 |  |  | 100.0 | % |  | $ | 1,369,783 |  |  | 100.0 | % |
  (was, 2021-02-02, similarity 0.8662):
[0001408710-21-000011:note_history:43]
| (amount in thousands, except percentages) | Three Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |  | Six Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |
| Optical communications | $ | 347,840 |  |  | 76.6 | % |  | $ | 691,757 |  |  | 77.7 | % |
| Lasers, sensors and other | 105,987 |  |  | 23.4 |  |  | 198,709 |  |  | 22.3 |  |
| Total | $ | 453,827 |  |  | 100.0 | % |  | $ | 890,466 |  |  | 100.0 | % |

- changed (2021-05-04):
[0001408710-21-000022:note_history:44]
| (amount in thousands, except percentages) | Three Months EndedMarch 27, 2020 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 27, 2020 |  | As a % of TotalRevenues |
| Optical communications | $ | 308,566 |  |  | 75.0 | % |  | $ | 933,013 |  |  | 75.4 | % |
| Lasers, sensors and other | 102,644 |  |  | 25.0 | % |  | 303,710 |  |  | 24.6 | % |
| Total | $ | 411,210 |  |  | 100.0 | % |  | $ | 1,236,723 |  |  | 100.0 | % |
  (was, 2021-02-02, similarity 0.8662):
[0001408710-21-000011:note_history:44]
| (amount in thousands, except percentages) | Three Months EndedDecember 27, 2019 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2019 |  | As a % of TotalRevenues |
| Optical communications | $ | 322,068 |  |  | 75.6 | % |  | $ | 624,447 |  |  | 75.6 | % |
| Lasers, sensors and other | 104,149 |  |  | 24.4 |  |  | 201,066 |  |  | 24.4 |  |
| Total | $ | 426,217 |  |  | 100.0 | % |  | $ | 825,513 |  |  | 100.0 | % |

- changed (2021-05-04):
[0001408710-21-000022:note_history:45]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the nine months ended March 26, 2021:
  (was, 2021-02-02, similarity 0.9507):
[0001408710-21-000011:note_history:45]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the six months ended December 25, 2020:

- changed (2021-05-04):
[0001408710-21-000022:note_history:46]
| (amount in thousands) | ContractAssets |
| Beginning balance, June 26, 2020 | $ | 13,256 |  |
| Revenue recognized | 50,841 |  |
| Amounts collected or invoiced | (46,967) |  |
| Ending balance, March 26, 2021 | $ | 17,130 |  |
  (was, 2021-02-02, similarity 0.9771):
[0001408710-21-000011:note_history:46]
| (amount in thousands) | ContractAssets |
| Beginning balance, June 26, 2020 | $ | 13,256 |  |
| Revenue recognized | 35,464 |  |
| Amounts collected or invoiced | (32,497) |  |
| Ending balance, December 25, 2020 | $ | 16,223 |  |

- changed (2021-05-04):
[0001408710-21-000022:note_history:47]
| (amount in thousands) | ContractLiabilities |
| Beginning balance, June 26, 2020 | $ | 1,556 |  |
| Advance payment received during the period | 16,414 |  |
| Revenue recognized | (16,561) |  |
| Ending balance, March 26, 2021 | $ | 1,409 |  |
  (was, 2021-02-02, similarity 0.9522):
[0001408710-21-000011:note_history:47]
| (amount in thousands) | ContractLiabilities |
| Beginning balance, June 26, 2020 | $ | 1,556 |  |
| Additions advance payment received during the period | 14,597 |  |
| Revenue recognized | (14,349) |  |
| Ending balance, December 25, 2020 | $ | 1,804 |  |

- removed (2021-05-04):
[0001408710-21-000011:note_history:48]
| (amount in thousands, except percentages) | Three Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |  | Six Months EndedDecember 25, 2020 |  | As a % of TotalRevenues |
| North America | $ | 224,672 |  |  | 49.5 | % |  | $ | 432,074 |  |  | 48.5 | % |
| Asia-Pacific | 153,734 |  |  | 33.9 |  |  | 299,380 |  |  | 33.6 |  |
| Europe | 75,421 |  |  | 16.6 |  |  | 159,012 |  |  | 17.9 |  |
|  | $ | 453,827 |  |  | 100.0 | % |  | $ | 890,466 |  |  | 100.0 | % |

- removed (2021-05-04):
[0001408710-21-000011:note_history:49]
| (amount in thousands, except percentages) | Three Months EndedDecember 27, 2019 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2019 |  | As a % of TotalRevenues |
| North America | $ | 223,398 |  |  | 52.4 | % |  | $ | 424,345 |  |  | 51.4 | % |
| Asia-Pacific | 141,147 |  |  | 33.1 |  |  | 259,570 |  |  | 31.4 |  |
| Europe | 61,672 |  |  | 14.5 |  |  | 141,598 |  |  | 17.2 |  |
|  | $ | 426,217 |  |  | 100.0 | % |  | $ | 825,513 |  |  | 100.0 | % |
