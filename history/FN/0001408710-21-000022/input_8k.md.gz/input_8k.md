# FN 8-K — 0001408710-21-000019 filed 2021-05-03

## item codes, every 8-K on or before 2021-05-04

- 2021-05-03 0001408710-21-000019 — 2.02, 9.01
- 2021-02-01 0001408710-21-000008 — 2.02, 9.01
- 2020-12-11 0001193125-20-315861 — 5.07
- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2021-05-04

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001408710-21-000019:8k_2_02:1]
EX-99.1
2
fn-20210503xex991q3.htm
EX-99.1

[0001408710-21-000019:8k_2_02:2]
Document

[0001408710-21-000019:8k_2_02:3]
EX-99.1

[0001408710-21-000019:8k_2_02:4]
Exhibit 99.1

[0001408710-21-000019:8k_2_02:5]
Fabrinet Announces Third Quarter Fiscal Year 2021 Financial Results

[0001408710-21-000019:8k_2_02:6]
•Record Third Quarter Revenue of $479.3 Million Exceeds Guidance

[0001408710-21-000019:8k_2_02:7]
BANGKOK, Thailand – May 3, 2021 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its third fiscal quarter ended March 26, 2021.

[0001408710-21-000019:8k_2_02:8]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “For the third quarter in a row, we delivered record revenue that exceeded our guidance. Notably, we saw sequential revenue growth from all the end markets that we track combined with improving operating margins, both of which helped generate record net income.”

[0001408710-21-000019:8k_2_02:9]
Grady continued, “Based on our current outlook and continued demand, we expect another record performance in the fourth quarter and we remain well-positioned to continue to deliver strong results over the longer-term.”

[0001408710-21-000019:8k_2_02:10]
Third Quarter Fiscal Year 2021 Financial Highlights

[0001408710-21-000019:8k_2_02:11]
GAAP Results

[0001408710-21-000019:8k_2_02:12]
•Revenue for the third quarter of fiscal year 2021 was $479.3 million, compared to $411.2 million in the third quarter of fiscal year 2020.

[0001408710-21-000019:8k_2_02:13]
•GAAP net income for the third quarter of fiscal year 2021 was $37.5 million, compared to GAAP net income of $28.3 million for the third quarter of fiscal year 2020.

[0001408710-21-000019:8k_2_02:14]
•GAAP net income per diluted share for the third quarter of fiscal year 2021 was $1.00, compared to GAAP net income per diluted share of $0.75 for the third quarter of fiscal year 2020.

[0001408710-21-000019:8k_2_02:15]
Non-GAAP Results

[0001408710-21-000019:8k_2_02:16]
•Non-GAAP net income for the third quarter of fiscal year 2021 was $45.4 million, compared to non-GAAP net income of $34.8 million for the third quarter of fiscal year 2020.

[0001408710-21-000019:8k_2_02:17]
•Non-GAAP net income per diluted share for the third quarter of fiscal year 2021 was $1.21, compared to non-GAAP net income per diluted share of $0.92 for the third quarter of fiscal year 2020.

[0001408710-21-000019:8k_2_02:18]
Business Outlook

[0001408710-21-000019:8k_2_02:19]
Based on information available as of May 3, 2021, Fabrinet is issuing guidance for its fourth fiscal quarter ending June 25, 2021, as follows:

[0001408710-21-000019:8k_2_02:20]
•Fabrinet expects fourth quarter revenue to be in the range of $475 million to $495 million.

[0001408710-21-000019:8k_2_02:21]
•GAAP net income per diluted share is expected to be in the range of $1.02 to $1.09, based on approximately 37.6 million fully diluted shares outstanding.

[0001408710-21-000019:8k_2_02:22]
•Non-GAAP net income per diluted share is expected to be in the range of $1.18 to $1.25, based on approximately 37.6 million fully diluted shares outstanding.

[0001408710-21-000019:8k_2_02:23]
EX-99.1

[0001408710-21-000019:8k_2_02:24]
Conference Call Information

[0001408710-21-000019:8k_2_02:25]
| What: |  | Fabrinet Third Quarter Fiscal Year 2021 Financial Results Call |
| When: |  | Monday, May 3, 2021 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic(253) 237-1137, internationalPasscode: 2790505 |
| Replay: |  | (855) 859-2056, domestic(404) 537-3406, internationalPasscode: 2790505 |
| Webcast: |  | http://investor.fabrinet.com/ (live and replay) |

[0001408710-21-000019:8k_2_02:26]
This press release and any other information related to the call will also be posted on Fabrinet’s website at http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001408710-21-000019:8k_2_02:27]
About Fabrinet

[0001408710-21-000019:8k_2_02:28]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China, Israel and the United Kingdom. For more information visit: www.fabrinet.com.

[0001408710-21-000019:8k_2_02:29]
Forward-Looking Statements

[0001408710-21-000019:8k_2_02:30]
EX-99.1

[0001408710-21-000019:8k_2_02:31]
Use of Non-GAAP Financials

[0001408710-21-000019:8k_2_02:32]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; depreciation of fair value uplift; amortization of intangibles; and amortization of deferred debt issuance costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001408710-21-000019:8k_2_02:33]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001408710-21-000019:8k_2_02:34]
SOURCE: Fabrinet

[0001408710-21-000019:8k_2_02:35]
Investor Contact:

[0001408710-21-000019:8k_2_02:36]
Garo Toomajanian

[0001408710-21-000019:8k_2_02:37]
ir@fabrinet.com

[0001408710-21-000019:8k_2_02:38]
EX-99.1

[0001408710-21-000019:8k_2_02:39]
FABRINET

[0001408710-21-000019:8k_2_02:40]
CONDENSED CONSOLIDATED BALANCE SHEETS (unaudited)

[0001408710-21-000019:8k_2_02:41]
| (in thousands of U.S. dollars, except share data and par value) | March 26,2021 |  | June 26,2020 |
| Assets |  |  |  |
| Current assets |  |  |  |
| Cash and cash equivalents | $ | 247,011 |  |  | $ | 225,430 |  |
| Short-term restricted cash | — |  |  | 7,402 |  |
| Short-term investments | 261,736 |  |  | 262,693 |  |
| Trade accounts receivable, net of allowance for doubtful accounts of $126 and $336 respectively | 309,079 |  |  | 272,665 |  |
| Contract assets | 17,130 |  |  | 13,256 |  |
| Inventories | 353,283 |  |  | 309,786 |  |
| Other receivable | 24,310 |  |  | 24,310 |  |
| Prepaid expenses | 10,653 |  |  | 5,399 |  |
| Other current assets | 31,967 |  |  | 14,508 |  |
| Total current assets | 1,255,169 |  |  | 1,135,449 |  |
| Non-current assets |  |  |  |
| Long-term restricted cash | 153 |  |  | — |  |
| Property, plant and equipment, net | 228,767 |  |  | 228,274 |  |
| Intangibles, net | 4,576 |  |  | 4,312 |  |
| Operating right-of-use assets | 6,744 |  |  | 8,068 |  |
| Deferred tax assets | 6,195 |  |  | 5,675 |  |
| Other non-current assets | 226 |  |  | 202 |  |
| Total non-current assets | 246,661 |  |  | 246,531 |  |
| Total Assets | 1,501,830 |  |  | 1,381,980 |  |
| Liabilities and Shareholders’ Equity |  |  |  |
| Current liabilities |  |  |  |
| Long-term borrowings, current portion, net | 12,156 |  |  | 12,156 |  |
| Trade accounts payable | 275,705 |  |  | 251,603 |  |
| Fixed assets payable | 11,060 |  |  | 15,127 |  |
| Contract liabilities | 1,409 |  |  | 1,556 |  |
| Operating lease liabilities, current portion | 2,390 |  |  | 1,979 |  |
| Income tax payable | 2,882 |  |  | 2,242 |  |
| Accrued payroll, bonus and related expenses | 21,639 |  |  | 19,265 |  |
| Accrued expenses | 12,651 |  |  | 8,979 |  |
| Other payables | 26,348 |  |  | 21,514 |  |
| Total current liabilities | 366,240 |  |  | 334,421 |  |
| Non-current liabilities |  |  |  |
| Long-term borrowings, non-current portion, net | 30,397 |  |  | 39,514 |  |
| Deferred tax liability | 4,855 |  |  | 4,729 |  |
| Operating lease liability, non-current portion | 4,098 |  |  | 5,873 |  |
| Severance liabilities | 19,006 |  |  | 17,379 |  |
| Other non-current liabilities | 3,728 |  |  | 5,655 |  |
| Total non-current liabilities | 62,084 |  |  | 73,150 |  |
| Total Liabilities | 428,324 |  |  | 407,571 |  |
| Shareholders’ equity |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of March 26, 2021 and June 26, 2020) | — |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 38,741,166 shares and 38,471,967 shares issued at March 26, 2021 and June 26, 2020, respectively; and 36,880,160 shares and 36,727,864 shares outstanding at March 26, 2021 and June 26, 2020, respectively) | 388 |  |  | 385 |  |
| Additional paid-in capital | 182,987 |  |  | 175,610 |  |
| Less: Treasury shares (1,861,006 shares and 1,744,103 shares as of March 26, 2021 and June 26, 2020, respectively) | (76,813) |  |  | (68,501) |  |
| Accumulated other comprehensive income (loss) | (6,939) |  |  | (1,147) |  |
| Retained earnings | 973,883 |  |  | 868,062 |  |
| Total Shareholders’ Equity | 1,073,506 |  |  | 974,409 |  |
| Total Liabilities and Shareholders’ Equity | $ | 1,501,830 |  |  | $ | 1,381,980 |  |

[0001408710-21-000019:8k_2_02:42]
EX-99.1

[0001408710-21-000019:8k_2_02:43]
FABRINET

[0001408710-21-000019:8k_2_02:44]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME

[0001408710-21-000019:8k_2_02:45]
(unaudited)

[0001408710-21-000019:8k_2_02:46]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands of U.S. dollars, except per share data) | March 26,2021 |  | March 27,2020 |  | March 26,2021 |  | March 27,2020 |
| Revenues | $ | 479,317 |  |  | $ | 411,210 |  |  | $ | 1,369,783 |  |  | $ | 1,236,723 |  |
| Cost of revenues | (422,539) |  |  | (366,874) |  |  | (1,209,504) |  |  | (1,097,242) |  |
| Gross profit | 56,778 |  |  | 44,336 |  |  | 160,279 |  |  | 139,481 |  |
| Selling, general and administrative expenses | (19,059) |  |  | (17,111) |  |  | (53,078) |  |  | (50,189) |  |
| Expenses related to reduction in workforce | (43) |  |  | — |  |  | (43) |  |  | (16) |  |
| Operating income | 37,676 |  |  | 27,225 |  |  | 107,158 |  |  | 89,276 |  |
| Interest income | 941 |  |  | 2,042 |  |  | 3,156 |  |  | 6,080 |  |
| Interest expense | (282) |  |  | (238) |  |  | (798) |  |  | (2,812) |  |
| Foreign exchange gain (loss), net | 629 |  |  | (8) |  |  | 224 |  |  | (2,949) |  |
| Other income (expense), net | 124 |  |  | 203 |  |  | 403 |  |  | 977 |  |
| Income before income taxes | 39,088 |  |  | 29,224 |  |  | 110,143 |  |  | 90,572 |  |
| Income tax expense | (1,595) |  |  | (957) |  |  | (4,215) |  |  | (5,117) |  |
| Net income | 37,493 |  |  | 28,267 |  |  | 105,928 |  |  | 85,455 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities | (570) |  |  | (1,356) |  |  | (937) |  |  | (1,403) |  |
| Change in net unrealized gain (loss) on derivative instruments | (5,000) |  |  | (6,569) |  |  | (5,823) |  |  | (6,719) |  |
| Change in net retirement benefits plan – prior service cost | 198 |  |  | 294 |  |  | 421 |  |  | 478 |  |
| Change in foreign currency translation adjustment | 90 |  |  | (600) |  |  | 547 |  |  | (353) |  |
| Total other comprehensive income (loss), net of tax | (5,282) |  |  | (8,231) |  |  | (5,792) |  |  | (7,997) |  |
| Net comprehensive income (loss) | $ | 32,211 |  |  | $ | 20,036 |  |  | $ | 100,136 |  |  | $ | 77,458 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 1.02 |  |  | $ | 0.76 |  |  | $ | 2.87 |  |  | $ | 2.31 |  |
| Diluted | $ | 1.00 |  |  | $ | 0.75 |  |  | $ | 2.82 |  |  | $ | 2.27 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |
| Basic | 36,875 |  |  | 36,987 |  |  | 36,876 |  |  | 36,970 |  |
| Diluted | 37,609 |  |  | 37,797 |  |  | 37,514 |  |  | 37,696 |  |

[0001408710-21-000019:8k_2_02:47]
EX-99.1

[0001408710-21-000019:8k_2_02:48]
FABRINET

[0001408710-21-000019:8k_2_02:49]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited)

[0001408710-21-000019:8k_2_02:50]
|  | Nine Months Ended |
| (in thousands of U.S. dollars) | March 26,2021 |  | March 27,2020 |
| Cash flows from operating activities |  |  |  |
| Net income for the period | $ | 105,928 |  |  | $ | 85,455 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 26,781 |  |  | 23,115 |  |
| (Gain) loss on disposal of property, plant and equipment | (24) |  |  | 444 |  |
| (Gain) loss from sales and maturities of available-for-sale securities | (187) |  |  | (93) |  |
| Amortization of investment discount | 1,479 |  |  | (624) |  |
| Amortization of deferred debt issuance costs | 24 |  |  | 18 |  |
| (Reversal of) allowance for doubtful accounts | (317) |  |  | (17) |  |
| Unrealized (gain) loss on exchange rate and fair value of foreign currency forward contracts | (825) |  |  | 942 |  |
| Unrealized loss (gain) on fair value of interest rate swaps | — |  |  | 1,672 |  |
| Amortization of fair value at hedge inception of interest rate swaps | (1,009) |  |  | (838) |  |
| Share-based compensation | 18,742 |  |  | 18,301 |  |
| Deferred income tax | (382) |  |  | 1,335 |  |
| Other non-cash expenses | (614) |  |  | (559) |  |
| Changes in operating assets and liabilities |  |  |  |
| Trade accounts receivable | (36,437) |  |  | (23,136) |  |
| Contract assets | (3,874) |  |  | (3,966) |  |
| Inventories | (43,497) |  |  | 3,404 |  |
| Other current assets and non-current assets | (22,919) |  |  | 5,830 |  |
| Trade accounts payable | 25,589 |  |  | (15,571) |  |
| Contract liabilities | (147) |  |  | (298) |  |
| Income tax payable | 911 |  |  | 1,056 |  |
| Severance liabilities | 2,204 |  |  | 2,266 |  |
| Other current liabilities and non-current liabilities | 3,731 |  |  | 5,712 |  |
| Net cash provided by operating activities | 75,157 |  |  | 104,448 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of short-term investments | (183,041) |  |  | (123,980) |  |
| Proceeds from sales of short-term investments | 84,049 |  |  | 48,808 |  |
| Proceeds from maturities of short-term investments | 97,721 |  |  | 97,358 |  |
| Funds provided to customer to support transfer of manufacturing operations | — |  |  | (24,310) |  |
| Purchase of property, plant and equipment | (29,061) |  |  | (27,482) |  |
| Purchase of intangibles | (1,961) |  |  | (797) |  |
| Proceeds from disposal of property, plant and equipment | 38 |  |  | 1,482 |  |
| Net cash used in investing activities | (32,255) |  |  | (28,921) |  |
| Cash flows from financing activities |  |  |  |
| Payment of debt issuance costs | — |  |  | (153) |  |
| Proceeds from long-term borrowings | — |  |  | 60,938 |  |
| Repayment of long-term borrowings | (9,141) |  |  | (67,032) |  |
| Repayment of finance lease liability | (100) |  |  | (304) |  |
| Repurchase of ordinary shares | (8,312) |  |  | (20,722) |  |
| Withholding tax related to net share settlement of restricted share units | (11,362) |  |  | (4,727) |  |
| Net cash used in financing activities | (28,915) |  |  | (32,000) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | 13,987 |  |  | 43,527 |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at the beginning of period | 232,832 |  |  | 188,241 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | 13,987 |  |  | 43,527 |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash | 345 |  |  | (228) |  |
| Cash, cash equivalents and restricted cash at the end of period | 247,164 |  |  | 231,540 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment-related payables | $ | 11,060 |  |  | $ | 11,906 |  |

[0001408710-21-000019:8k_2_02:51]
EX-99.1

[0001408710-21-000019:8k_2_02:52]
FABRINET

[0001408710-21-000019:8k_2_02:53]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited) (Continued)

[0001408710-21-000019:8k_2_02:54]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the unaudited condensed consolidated balance sheets that sum to the total of the same amounts shown in the unaudited condensed consolidated statements of cash flows:

[0001408710-21-000019:8k_2_02:55]
|  | As of |
| (amount in thousands) | March 26,2021 |  | March 27,2020 |
| Cash and cash equivalents | $ | 247,011 |  |  | $ | 224,138 |  |
| Restricted cash | 153 |  |  | 7,402 |  |
| Cash, cash equivalents and restricted cash | $ | 247,164 |  |  | $ | 231,540 |  |

[0001408710-21-000019:8k_2_02:56]
EX-99.1

[0001408710-21-000019:8k_2_02:57]
FABRINET

[0001408710-21-000019:8k_2_02:58]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-21-000019:8k_2_02:59]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 26,2021 |  | March 27,2020 |  | March 26,2021 |  | March 27,2020 |
| (in thousands of U.S. dollars, except per share data) | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |
| GAAP measures | $ | 37,493 |  |  | $ | 1.00 |  |  | $ | 28,267 |  |  | $ | 0.75 |  |  | $ | 105,928 |  |  | $ | 2.82 |  |  | $ | 85,455 |  |  | $ | 2.27 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 1,388 |  |  | 0.04 |  |  | 1,489 |  |  | 0.04 |  |  | 4,805 |  |  | 0.13 |  |  | 4,800 |  |  | 0.13 |  |
| Depreciation of fair value uplift | 89 |  |  | 0.00 |  |  | 86 |  |  | 0.00 |  |  | 256 |  |  | 0.00 |  |  | 247 |  |  | 0.00 |  |
| Total related to gross profit | 1,477 |  |  | 0.04 |  |  | 1,575 |  |  | 0.04 |  |  | 5,061 |  |  | 0.13 |  |  | 5,047 |  |  | 0.13 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 5,476 |  |  | 0.15 |  |  | 4,629 |  |  | 0.12 |  |  | 13,937 |  |  | 0.37 |  |  | 13,501 |  |  | 0.36 |  |
| Amortization of intangibles | 127 |  |  | 0.00 |  |  | 145 |  |  | 0.00 |  |  | 382 |  |  | 0.01 |  |  | 431 |  |  | 0.01 |  |
| Severance payment | 755 |  |  | 0.02 |  |  | 150 |  |  | 0.00 |  |  | 755 |  |  | 0.02 |  |  | 150 |  |  | 0.00 |  |
| Total related to selling, general and administrative expenses | 6,358 |  |  | 0.17 |  |  | 4,924 |  |  | 0.13 |  |  | 15,074 |  |  | 0.40 |  |  | 14,082 |  |  | 0.37 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other expenses in relation to reduction in workforce | 43 |  |  | 0.00 |  |  | — |  |  | — |  |  | 43 |  |  | 0.00 |  |  | 16 |  |  | 0.00 |  |
| Amortization of deferred debt issuance costs | 8 |  |  | 0.00 |  |  | 8 |  |  | 0.00 |  |  | 24 |  |  | 0.00 |  |  | 18 |  |  | 0.00 |  |
| Total related to other incomes and other expenses | 51 |  |  | — |  |  | 8 |  |  | — |  |  | 67 |  |  | — |  |  | 34 |  |  | — |  |
| Total related to net income & EPS | 7,886 |  |  | 0.21 |  |  | 6,507 |  |  | 0.17 |  |  | 20,202 |  |  | 0.54 |  |  | 19,163 |  |  | 0.51 |  |
| Non-GAAP measures | $ | 45,379 |  |  | $ | 1.21 |  |  | $ | 34,774 |  |  | $ | 0.92 |  |  | $ | 126,130 |  |  | $ | 3.36 |  |  | $ | 104,618 |  |  | $ | 2.78 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  | 37,609 |  |  |  |  | 37,797 |  |  |  |  | 37,514 |  |  |  | 37,696 |
| Non-GAAP diluted shares |  |  | 37,609 |  |  |  |  | 37,797 |  |  |  |  | 37,514 |  |  |  | 37,696 |

[0001408710-21-000019:8k_2_02:60]
EX-99.1

[0001408710-21-000019:8k_2_02:61]
FABRINET

[0001408710-21-000019:8k_2_02:62]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001408710-21-000019:8k_2_02:63]
| (amount in thousands) | Three Months Ended |  | Nine Months Ended |
|  | March 26,2021 |  | March 27,2020 |  | March 26,2021 |  | March 27,2020 |
| Net cash provided by operating activities | $ | 33,843 |  |  | $ | 51,838 |  |  | $ | 75,157 |  |  | $ | 104,448 |  |
| Less: Purchase of property, plant and equipment | (6,368) |  |  | (12,071) |  |  | (29,061) |  |  | (27,482) |  |
| Non-GAAP free cash flow | $ | 27,475 |  |  | $ | 39,767 |  |  | $ | 46,096 |  |  | $ | 76,966 |  |

[0001408710-21-000019:8k_2_02:64]
FABRINET

[0001408710-21-000019:8k_2_02:65]
GUIDANCE FOR QUARTER ENDING JUNE 25, 2021

[0001408710-21-000019:8k_2_02:66]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-21-000019:8k_2_02:67]
|  | DilutedEPS |
| GAAP net income per diluted share: | $1.02 to $1.09 |
| Related to cost of revenues: |  |
| Share-based compensation expenses | 0.04 |
| Total related to gross profit | 0.04 |
| Related to selling, general and administrative expenses: |  |
| Share-based compensation expenses | 0.12 |
| Total related to selling, general and administrative expenses | 0.12 |
| Total related to net income & EPS | 0.16 |
| Non-GAAP net income per diluted share | $1.18 to $1.25 |
