# FN MD&A — 0001408710-21-000022


## mdna

[0001408710-21-000022:mdna:1]
[same as prior period, unchanged from 0001408710-21-000011:mdna:1]

[0001408710-21-000022:mdna:2]
[same as prior period, unchanged from 0001408710-21-000011:mdna:2]

[0001408710-21-000022:mdna:3]
[same as prior period, unchanged from 0001408710-21-000011:mdna:3]

[0001408710-21-000022:mdna:4]
[same as prior period, unchanged from 0001408710-21-000011:mdna:4]

[0001408710-21-000022:mdna:5]
•our expectation that the portion of our revenues attributable to customers in regions outside of North America for the remainder of fiscal year 2021 will be in line with the portion of those revenues for the nine months ended March 26, 2021;

[0001408710-21-000022:mdna:6]
[same as prior period, unchanged from 0001408710-21-000011:mdna:6]

[0001408710-21-000022:mdna:7]
[same as prior period, unchanged from 0001408710-21-000011:mdna:7]

[0001408710-21-000022:mdna:8]
•our expectation that our employee costs will increase in Thailand and the PRC;

[0001408710-21-000022:mdna:9]
[same as prior period, unchanged from 0001408710-21-000011:mdna:9]

[0001408710-21-000022:mdna:10]
[same as prior period, unchanged from 0001408710-21-000011:mdna:10]

[0001408710-21-000022:mdna:11]
[same as prior period, unchanged from 0001408710-21-000011:mdna:11]

[0001408710-21-000022:mdna:12]
[same as prior period, unchanged from 0001408710-21-000011:mdna:12]

[0001408710-21-000022:mdna:13]
[same as prior period, unchanged from 0001408710-21-000011:mdna:13]

[0001408710-21-000022:mdna:14]
[same as prior period, unchanged from 0001408710-21-000011:mdna:14]

[0001408710-21-000022:mdna:15]
[same as prior period, unchanged from 0001408710-21-000011:mdna:15]

[0001408710-21-000022:mdna:16]
[same as prior period, unchanged from 0001408710-21-000011:mdna:16]

[0001408710-21-000022:mdna:17]
[same as prior period, unchanged from 0001408710-21-000011:mdna:17]

[0001408710-21-000022:mdna:18]
[same as prior period, unchanged from 0001408710-21-000011:mdna:18]

[0001408710-21-000022:mdna:19]
[same as prior period, unchanged from 0001408710-21-000011:mdna:19]

[0001408710-21-000022:mdna:20]
[same as prior period, unchanged from 0001408710-21-000011:mdna:20]

[0001408710-21-000022:mdna:21]
[same as prior period, unchanged from 0001408710-21-000011:mdna:21]

[0001408710-21-000022:mdna:22]
[same as prior period, unchanged from 0001408710-21-000011:mdna:22]

[0001408710-21-000022:mdna:23]
[same as prior period, unchanged from 0001408710-21-000011:mdna:23]

[0001408710-21-000022:mdna:24]
[same as prior period, unchanged from 0001408710-21-000011:mdna:24]

[0001408710-21-000022:mdna:25]
[same as prior period, unchanged from 0001408710-21-000011:mdna:25]

[0001408710-21-000022:mdna:26]
The global COVID-19 pandemic has impacted us in several ways and created various challenges. At the onset of the pandemic, our PRC subsidiary, which manufactures custom optics components for us and other customers at its facility in Fuzhou, China, experienced a prolonged temporary closure following its customary eight-day Chinese Lunar New Year holiday in January 2020. In accordance with the Chinese government’s official efforts to mitigate the spread of COVID-19, our PRC subsidiary, along with other businesses in various parts of the country, delayed resumption of operations following the holiday closures for approximately two weeks. Furthermore, because of the restrictions in place on travel in the PRC during this period, many of our employees were unable to return from their holiday travel as planned, resulting in fewer than 90% of our employees being able to return to work at our PRC subsidiary before early March 2020. Our other global manufacturing facilities also have been affected by various government restrictions put in place to slow the spread of COVID-19. While our operations in Thailand have not been suspended, we have implemented a number of safety protocols to allow our operations in our facilities there to continue in accordance with government regulations. With the exception of our facility in Santa Clara, California, which closed for approximately one week beginning in late March 2020 before reopening in early April 2020 as a previously classified “essential business,” our facilities in the U.S., including in New Jersey, and in the U.K. have remained open while adhering to the local government restrictions including social distancing guidelines. During the three months ended March 26, 2021, several countries such as Thailand, the PRC, the U.S., and the U.K., where we have manufacturing facilities, experienced a surge in the number of COVID-19 cases. Although we did not experience any significant disruptions in our operations or decrease in customer demand during the three months ended March 26, 2021, any further worsening of the pandemic may have a negative impact on our operations.

[0001408710-21-000022:mdna:27]
The health and well-being of our employees continues to be our top priority. Early last year, we implemented significant precautionary measures throughout our worldwide operations to ensure our employees and their families remain safe, such as mandatory temperature detection at building entrances, rigorous and regular facility and equipment disinfection, and mandatory personal protective equipment protocols, including (1) the wearing of face masks throughout our factories at all times, (2) distributing our employees across shifts to better maintain safe personal distances, (3) isolating incoming parts and materials for a week or more prior to unpacking, or applying extreme heat to them to kill potential viruses, (4) directing our non-factory personnel to work remotely, and (5) restricting all non-employee visits to our campuses.

[0001408710-21-000022:mdna:28]
[same as prior period, unchanged from 0001408710-21-000011:mdna:29]

[0001408710-21-000022:mdna:29]
[same as prior period, unchanged from 0001408710-21-000011:mdna:30]

[0001408710-21-000022:mdna:30]
[same as prior period, unchanged from 0001408710-21-000011:mdna:31]

[0001408710-21-000022:mdna:31]
[same as prior period, unchanged from 0001408710-21-000011:mdna:32]

[0001408710-21-000022:mdna:32]
[same as prior period, unchanged from 0001408710-21-000011:mdna:33]

[0001408710-21-000022:mdna:33]
[same as prior period, unchanged from 0001408710-21-000011:mdna:34]

[0001408710-21-000022:mdna:34]
•Given our $508.7 million in cash, cash equivalents and short-term investments, and our total debt of approximately $42.7 million, as of March 26, 2021, we believe we are in a solid position from a capital and financial resources perspective. We expect that current cash and cash equivalent balances and short-term investments, and cash flows that are generated from operations will be sufficient to meet our domestic and international working capital needs and other capital and liquidity requirements for at least the next 12 months.

[0001408710-21-000022:mdna:35]
[same as prior period, unchanged from 0001408710-21-000011:mdna:36]

[0001408710-21-000022:mdna:36]
[same as prior period, unchanged from 0001408710-21-000011:mdna:37]

[0001408710-21-000022:mdna:37]
[same as prior period, unchanged from 0001408710-21-000011:mdna:38]

[0001408710-21-000022:mdna:38]
We generate revenues from three geographic regions: North America, Asia-Pacific and others and Europe. Revenues are attributed to a particular geographic area based on the bill-to location of our customers, notwithstanding that our customers may ultimately ship their products to end customers in a different geographic region. The majority of our revenues are derived from our manufacturing facilities in Asia-Pacific.

[0001408710-21-000022:mdna:39]
The percentage of our revenues generated from a bill-to location outside of North America increased from 49.7% in the three months ended March 27, 2020 to 51.8% in the three months ended March 26, 2021, primarily because the increase in sales to our customers outside of North America was greater than the increase in sales to our customers in North America.

[0001408710-21-000022:mdna:40]
The percentage of our revenues generated from a bill-to location outside of North America increased from 49.0% in the nine months ended March 27, 2020 to 51.6% in the nine months ended March 26, 2021, primarily because the increase in sales to our customers outside of North America was greater than the increase in sales to our customers in North America.

[0001408710-21-000022:mdna:41]
Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside North America for the remainder of fiscal year 2021 will be in line with the portion of revenues attributable to such customers during the nine months ended March 26, 2021.

[0001408710-21-000022:mdna:42]
[same as prior period, unchanged from 0001408710-21-000011:mdna:43]

[0001408710-21-000022:mdna:43]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 26, 2021 |  | March 27, 2020 |  | March 26, 2021 |  | March 27, 2020 |
| North America | 48.2 | % |  | 50.3 | % |  | 48.4 | % |  | 51.0 | % |
| Asia-Pacific and others | 34.9 |  |  | 34.4 |  |  | 34.1 |  |  | 32.5 |  |
| Europe | 16.9 |  |  | 15.3 |  |  | 17.5 |  |  | 16.5 |  |
|  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001408710-21-000022:mdna:44]
[same as prior period, unchanged from 0001408710-21-000011:mdna:45]

[0001408710-21-000022:mdna:45]
[same as prior period, unchanged from 0001408710-21-000011:mdna:46]

[0001408710-21-000022:mdna:46]
[same as prior period, unchanged from 0001408710-21-000011:mdna:47]

[0001408710-21-000022:mdna:47]
[same as prior period, unchanged from 0001408710-21-000011:mdna:48]

[0001408710-21-000022:mdna:48]
A second significant element of our cost of revenues is employee costs, including indirect employee costs related to design, configuration and optimization of manufacturing processes for our customers, quality testing, materials testing and other engineering services; and direct costs related to our manufacturing employees. Direct employee costs include employee salaries, insurance and benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a lesser extent, costs to recruit, train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand, the PRC and the U.K., the fluctuation of the Thai baht, Chinese Renminbi (“RMB”) and Pound Sterling (“GBP”) against our functional currency, the U.S. dollar, and our ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention and asset utilization.

[0001408710-21-000022:mdna:49]
[same as prior period, unchanged from 0001408710-21-000011:mdna:50]

[0001408710-21-000022:mdna:50]
[same as prior period, unchanged from 0001408710-21-000011:mdna:51]

[0001408710-21-000022:mdna:51]
[same as prior period, unchanged from 0001408710-21-000011:mdna:52]

[0001408710-21-000022:mdna:52]
[same as prior period, unchanged from 0001408710-21-000011:mdna:53]

[0001408710-21-000022:mdna:53]
[same as prior period, unchanged from 0001408710-21-000011:mdna:54]

[0001408710-21-000022:mdna:54]
[same as prior period, unchanged from 0001408710-21-000011:mdna:55]

[0001408710-21-000022:mdna:55]
[same as prior period, unchanged from 0001408710-21-000011:mdna:56]

[0001408710-21-000022:mdna:56]
[same as prior period, unchanged from 0001408710-21-000011:mdna:57]

[0001408710-21-000022:mdna:57]
In order to manage the risks arising from fluctuations in foreign currency exchange rates, we use derivative instruments. We may enter into exchange currency forward or put option contracts to manage foreign currency exposures associated with certain assets and liabilities and other forecasted foreign currency transactions and may designate these instruments as hedging instruments. The forward and put option contracts generally have maturities of up to 12 months. All foreign currency exchange contracts are recognized in the unaudited condensed consolidated balance sheets at fair value. Gains or losses on our forward and put option contracts generally present gross amount in the assets, liabilities, and transactions economically hedged.

[0001408710-21-000022:mdna:58]
[same as prior period, unchanged from 0001408710-21-000011:mdna:59]

[0001408710-21-000022:mdna:59]
|  | As of March 26, 2021 |  | As of June 26, 2020 |
| (amount in thousands, except percentages) | Currency |  | $ |  | % |  | Currency |  | $ |  | % |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 1,112,572 |  |  | $ | 35,705 |  |  | 59.7 | % |  | 667,955 |  |  | $ | 21,617 |  |  | 41.8 | % |
| RMB | 104,656 |  |  | 16,008 |  |  | 26.8 |  |  | 158,060 |  |  | 22,402 |  |  | 43.3 |  |
| GBP | 5,899 |  |  | 8,116 |  |  | 13.5 |  |  | 6,220 |  |  | 7,726 |  |  | 14.9 |  |
| Total |  |  | $ | 59,829 |  |  | 100.0 | % |  |  |  | $ | 51,745 |  |  | 100.0 | % |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 2,140,166 |  |  | $ | 68,683 |  |  | 89.5 | % |  | 2,102,392 |  |  | $ | 68,039 |  |  | 89.5 | % |
| RMB | 28,321 |  |  | 4,332 |  |  | 5.6 |  |  | 42,586 |  |  | 6,036 |  |  | 8.0 |  |
| GBP | 2,715 |  |  | 3,735 |  |  | 4.9 |  |  | 1,545 |  |  | 1,919 |  |  | 2.5 |  |
| Total |  |  | $ | 76,750 |  |  | 100.0 | % |  |  |  | $ | 75,994 |  |  | 100.0 | % |

[0001408710-21-000022:mdna:60]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of March 26, 2021, there was $135.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 26, 2020, there was $125.0 million of foreign currency forward contracts outstanding and one foreign currency option contract with notional amount of $1.0 million on the Thai baht payables.

[0001408710-21-000022:mdna:61]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of March 26, 2021 and June 26, 2020, we did not have any derivative contracts denominated in RMB.

[0001408710-21-000022:mdna:62]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable and other payables. As of March 26, 2021 and June 26, 2020, we did not have any derivative contracts denominated in GBP.

[0001408710-21-000022:mdna:63]
For the three months ended March 26, 2021 and March 27, 2020, we recorded loss of $2.0 million and $2.1 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-21-000022:mdna:64]
For the nine months ended March 26, 2021 and March 27, 2020, we recorded loss of $1.7 million and $4.0 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-21-000022:mdna:65]
[same as prior period, unchanged from 0001408710-21-000011:mdna:66]

[0001408710-21-000022:mdna:66]
[same as prior period, unchanged from 0001408710-21-000011:mdna:67]

[0001408710-21-000022:mdna:67]
[same as prior period, unchanged from 0001408710-21-000011:mdna:68]

[0001408710-21-000022:mdna:68]
[same as prior period, unchanged from 0001408710-21-000011:mdna:69]

[0001408710-21-000022:mdna:69]
[same as prior period, unchanged from 0001408710-21-000011:mdna:70]

[0001408710-21-000022:mdna:70]
[same as prior period, unchanged from 0001408710-21-000011:mdna:71]

[0001408710-21-000022:mdna:71]
[same as prior period, unchanged from 0001408710-21-000011:mdna:72]

[0001408710-21-000022:mdna:72]
[same as prior period, unchanged from 0001408710-21-000011:mdna:73]

[0001408710-21-000022:mdna:73]
[same as prior period, unchanged from 0001408710-21-000011:mdna:74]

[0001408710-21-000022:mdna:74]
[same as prior period, unchanged from 0001408710-21-000011:mdna:75]

[0001408710-21-000022:mdna:75]
[same as prior period, unchanged from 0001408710-21-000011:mdna:76]

[0001408710-21-000022:mdna:76]
[same as prior period, unchanged from 0001408710-21-000011:mdna:77]

[0001408710-21-000022:mdna:77]
[same as prior period, unchanged from 0001408710-21-000011:mdna:78]

[0001408710-21-000022:mdna:78]
[same as prior period, unchanged from 0001408710-21-000011:mdna:79]

[0001408710-21-000022:mdna:79]
[same as prior period, unchanged from 0001408710-21-000011:mdna:80]

[0001408710-21-000022:mdna:80]
The corporate income tax rate for our subsidiaries in the PRC and the U.K. is 25% and 19%, respectively.

[0001408710-21-000022:mdna:81]
[same as prior period, unchanged from 0001408710-21-000011:mdna:82]

[0001408710-21-000022:mdna:82]
[same as prior period, unchanged from 0001408710-21-000011:mdna:83]

[0001408710-21-000022:mdna:83]
[same as prior period, unchanged from 0001408710-21-000011:mdna:84]

[0001408710-21-000022:mdna:84]
[same as prior period, unchanged from 0001408710-21-000011:mdna:85]

[0001408710-21-000022:mdna:85]
[same as prior period, unchanged from 0001408710-21-000011:mdna:86]

[0001408710-21-000022:mdna:86]
| (amount in thousands) | Three Months Ended |  | Nine Months Ended |
| March 26,2021 |  | March 27,2020 |  | March 26,2021 |  | March 27,2020 |
| Revenues | $ | 479,317 |  |  | $ | 411,210 |  |  | $ | 1,369,783 |  |  | $ | 1,236,723 |  |
| Cost of revenues | (422,539) |  |  | (366,874) |  |  | (1,209,504) |  |  | (1,097,242) |  |
| Gross profit | 56,778 |  |  | 44,336 |  |  | 160,279 |  |  | 139,481 |  |
| Selling, general and administrative expenses | (19,059) |  |  | (17,111) |  |  | (53,078) |  |  | (50,189) |  |
| Expenses related to reduction in workforce | (43) |  |  | — |  |  | (43) |  |  | (16) |  |
| Operating income | 37,676 |  |  | 27,225 |  |  | 107,158 |  |  | 89,276 |  |
| Interest income | 941 |  |  | 2,042 |  |  | 3,156 |  |  | 6,080 |  |
| Interest expense | (282) |  |  | (238) |  |  | (798) |  |  | (2,812) |  |
| Foreign exchange gain (loss), net | 629 |  |  | (8) |  |  | 224 |  |  | (2,949) |  |
| Other income (expense), net | 124 |  |  | 203 |  |  | 403 |  |  | 977 |  |
| Income before income taxes | 39,088 |  |  | 29,224 |  |  | 110,143 |  |  | 90,572 |  |
| Income tax expense | (1,595) |  |  | (957) |  |  | (4,215) |  |  | (5,117) |  |
| Net income | 37,493 |  |  | 28,267 |  |  | 105,928 |  |  | 85,455 |  |
| Other comprehensive income (loss), net of tax | (5,282) |  |  | (8,231) |  |  | (5,792) |  |  | (7,997) |  |
| Net comprehensive income | $ | 32,211 |  |  | $ | 20,036 |  |  | $ | 100,136 |  |  | $ | 77,458 |  |

[0001408710-21-000022:mdna:87]
[same as prior period, unchanged from 0001408710-21-000011:mdna:88]

[0001408710-21-000022:mdna:88]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 26,2021 |  | March 27,2020 |  | March 26,2021 |  | March 27,2020 |
| Revenues | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenues | (88.2) |  |  | (89.2) |  |  | (88.3) |  |  | (88.7) |  |
| Gross profit | 11.8 |  |  | 10.8 |  |  | 11.7 |  |  | 11.3 |  |
| Selling, general and administrative expenses | (4.0) |  |  | (4.2) |  |  | (3.9) |  |  | (4.1) |  |
| Expenses related to reduction in workforce | 0.0 |  |  | — |  |  | 0.0 |  |  | (0.0) |  |
| Operating income | 7.8 |  |  | 6.6 |  |  | 7.8 |  |  | 7.2 |  |
| Interest income | 0.2 |  |  | 0.5 |  |  | 0.2 |  |  | 0.5 |  |
| Interest expense | 0.0 |  |  | 0.0 |  |  | 0.0 |  |  | (0.2) |  |
| Foreign exchange gain (loss), net | 0.1 |  |  | (0.0) |  |  | 0.0 |  |  | (0.2) |  |
| Other income (expense), net | 0.0 |  |  | 0.0 |  |  | 0.0 |  |  | 0.0 |  |
| Income before income taxes | 8.1 |  |  | 7.1 |  |  | 8.0 |  |  | 7.3 |  |
| Income tax expense | (0.3) |  |  | (0.2) |  |  | (0.3) |  |  | (0.4) |  |
| Net income | 7.8 |  |  | 6.9 |  |  | 7.7 |  |  | 6.9 |  |
| Other comprehensive income (loss), net of tax | (1.1) |  |  | (2.0) |  |  | (0.4) |  |  | (0.6) |  |
| Net comprehensive income | 6.7 | % |  | 4.9 | % |  | 7.3 | % |  | 6.3 | % |

[0001408710-21-000022:mdna:89]
39

[0001408710-21-000022:mdna:90]
[same as prior period, unchanged from 0001408710-21-000011:mdna:91]

[0001408710-21-000022:mdna:91]
|  | Three Months Ended |  | Nine Months Ended |
| (amount in thousands) | March 26,2021 |  | March 27,2020 |  | March 26,2021 |  | March 27,2020 |
| Optical communications | $ | 361,739 |  |  | $ | 308,566 |  |  | $ | 1,053,496 |  |  | $ | 933,013 |  |
| Lasers, sensors and other | 117,578 |  |  | 102,644 |  |  | 316,287 |  |  | 303,710 |  |
| Total | $ | 479,317 |  |  | $ | 411,210 |  |  | $ | 1,369,783 |  |  | $ | 1,236,723 |  |

[0001408710-21-000022:mdna:92]
[same as prior period, unchanged from 0001408710-21-000011:mdna:93]

[0001408710-21-000022:mdna:93]
Comparison of Three and Nine Months Ended March 26, 2021 with Three and Nine Months Ended March 27, 2020

[0001408710-21-000022:mdna:94]
[same as prior period, unchanged from 0001408710-21-000011:mdna:95]

[0001408710-21-000022:mdna:95]
Our revenues increased by $68.1 million, or 16.6%, to $479.3 million for the three months ended March 26, 2021, compared with $411.2 million for the three months ended March 27, 2020. This increase was due to an increase in our key customers’ demand for optical communications manufacturing services and from newer programs during the three months ended March 26, 2021. Revenues from optical communications products increased by $53.2 million, or 17.2%, for the three months ended March 26, 2021.

[0001408710-21-000022:mdna:96]
Our revenues increased by $133.1 million, or 10.8%, to $1,369.8 million for the nine months ended March 26, 2021, compared with $1,236.7 million for the nine months ended March 27, 2020. This increase was due to an increase in our key customers’ demand for optical communications manufacturing services and from newer programs during the nine months ended March 26, 2021. Revenues from optical communications products increased by $120.5 million, or 12.9%, for the nine months ended March 26, 2021.

[0001408710-21-000022:mdna:97]
[same as prior period, unchanged from 0001408710-21-000011:mdna:98]

[0001408710-21-000022:mdna:98]
Our cost of revenues increased by $55.7 million, or 15.2%, to $422.5 million, or 88.2% of revenues, for the three months ended March 26, 2021, compared with $366.9 million, or 89.2% of revenues, for the three months ended March 27, 2020. This increase in cost of revenues on an absolute dollar basis was in line with the increase in sales volume.

[0001408710-21-000022:mdna:99]
Our cost of revenues increased by $112.3 million, or 10.2%, to $1,209.5 million, or 88.3% of revenues, for the nine months ended March 26, 2021, compared with $1,097.2 million, or 88.7% of revenues, for the nine months ended March 27, 2020. This increase in cost of revenues on an absolute dollar basis was in line with the increase in sales volume.

[0001408710-21-000022:mdna:100]
[same as prior period, unchanged from 0001408710-21-000011:mdna:101]

[0001408710-21-000022:mdna:101]
Our gross profit increased by $12.4 million, or 28.1%, to $56.8 million, or 11.8% of revenues, for the three months ended March 26, 2021, compared with $44.3 million, or 10.8% of revenues, for the three months ended March 27, 2020. The increase was primarily due to an increase in sales volume.

[0001408710-21-000022:mdna:102]
Our gross profit increased by $20.8 million, or 14.9%, to $160.3 million, or 11.7% of revenues, for the nine months ended March 26, 2021, compared with $139.5 million, or 11.3% of revenues, for the nine months ended March 27, 2020. The increase was primarily due to an increase in sales volume.

[0001408710-21-000022:mdna:103]
[same as prior period, unchanged from 0001408710-21-000011:mdna:104]

[0001408710-21-000022:mdna:104]
Our SG&A expenses increased by $1.9 million, or 11.4%, to $19.1 million, or 4.0% of revenues, for the three months ended March 26, 2021, compared with $17.1 million, or 4.2% of revenues, for the three months ended March 27, 2020. The increase was primarily due to (1) an increase in share-based compensation expenses of $0.8 million, (2) a severance payment in the amount of $0.8 million related to a senior management retirement, (3) an increase in insurance expense of $0.2 million, and (4) an increase in start-up costs related to our subsidiary in Israel of $0.2 million.

[0001408710-21-000022:mdna:105]
Our SG&A expenses increased by $2.9 million, or 5.8%, to $53.1 million, or 3.9% of revenues, for the nine months ended March 26, 2021, compared with $50.2 million, or 4.1% of revenues, for the nine months ended March 27, 2020. The increase was primarily due to (1) an increase in start-up costs for our subsidiary in Israel of $1.4 million, (2) a severance payment in the amount of $0.8 million related to a senior management retirement, (3) an increase in share-based compensation

[0001408710-21-000022:mdna:106]
expenses of $0.4 million, and (4) an increase in insurance expense of $0.3 million, offset by a decrease in executive compensation and benefits of $0.4 million.

[0001408710-21-000022:mdna:107]
[same as prior period, unchanged from 0001408710-21-000011:mdna:107]

[0001408710-21-000022:mdna:108]
Our operating income increased by $10.5 million to $37.7 million, or 7.8% of revenues, for the three months ended March 26, 2021, compared with $27.2 million, or 6.6% of revenues, for the three months ended March 27, 2020. The increase was primarily due to an increase in revenues.

[0001408710-21-000022:mdna:109]
Our operating income increased by $17.9 million to $107.2 million, or 7.8% of revenues, for the nine months ended March 26, 2021, compared with $89.3 million, or 7.2% of revenues, for the nine months ended March 27, 2020. The increase was primarily due to an increase in revenues.

[0001408710-21-000022:mdna:110]
[same as prior period, unchanged from 0001408710-21-000011:mdna:110]

[0001408710-21-000022:mdna:111]
Our interest income decreased by $1.1 million, or 53.9%, to $0.9 million, or 0.2% of revenues, for the three months ended March 26, 2021, compared with $2.0 million, or 0.5% of revenues, for the three months ended March 27, 2020. The decrease was primarily due to a lower weighted average interest rate during the three months ended March 26, 2021 compared to same period in fiscal year 2020.

[0001408710-21-000022:mdna:112]
Our interest income decreased by $2.9 million, or 48.1%, to $3.2 million, or 0.2% of revenues, for the nine months ended March 26, 2021, compared with $6.1 million, or 0.5% of revenues, for the nine months ended March 27, 2020. The decrease was primarily due to a lower weighted average interest rate during the nine months ended March 26, 2021 compared to same period in fiscal year 2020.

[0001408710-21-000022:mdna:113]
[same as prior period, unchanged from 0001408710-21-000011:mdna:113]

[0001408710-21-000022:mdna:114]
Our interest expense increased by $0.04 million to $0.3 million for the three months ended March 26, 2021, compared with $0.2 million for the three months ended March 27, 2020. The increase was primarily due to lower amortization of the fair value of interest rate swaps during the three months ended March 26, 2021, compared with the three months ended March 27, 2020.

[0001408710-21-000022:mdna:115]
Our interest expense decreased by $2.0 million to $0.8 million for the nine months ended March 26, 2021, compared with $2.8 million for the nine months ended March 27, 2020. The decrease was primarily due to lower unrealized loss from mark-to-market of interest rate swaps recognized to earnings during the nine months ended March 26, 2021, due to the implementation of cash flow hedge accounting on the interest rate swaps on September 27, 2019.

[0001408710-21-000022:mdna:116]
[same as prior period, unchanged from 0001408710-21-000011:mdna:116]

[0001408710-21-000022:mdna:117]
We recorded foreign exchange gain, net of $0.6 million for the three months ended March 26, 2021, compared with foreign exchange loss, net of $8.0 thousand for the three months ended March 27, 2020. The increase in foreign exchange gain was mainly due to (1) lower foreign exchange loss from subsidiary in the PRC and a foreign exchange gain from our subsidiary in the U.K., totaling $0.1 million for the three months ended March 26, 2021, as compared to foreign exchange loss totaling $0.7 million from our subsidiaries in the PRC and the U.K. for the three months ended March 27, 2020, (2) lower realized foreign exchange loss from payment/receipt of $0.1 million for the three months ended March 26, 2021, as compared to realized foreign exchange loss from payment/receipt of $0.6 million for the three months ended March 27, 2020, and (3) lower unrealized loss from mark-to-market forward contracts of $2.0 million for the three months ended March 26, 2021, as compared to unrealized loss from mark-to-market forward contracts of $2.1 million for the three months ended March 27, 2020, partially offset with lower unrealized gain from revaluation of outstanding Thai baht assets and liabilities of $2.5 million for the three months ended March 26, 2021, as compared to unrealized gain from revaluation of outstanding Thai baht assets and liabilities of $3.3 million for the three months ended March 27, 2020.

[0001408710-21-000022:mdna:118]
We recorded foreign exchange gain, net of $0.2 million for the nine months ended March 26, 2021, compared with foreign exchange loss, net of $2.9 million for the nine months ended March 27, 2020. The increase in foreign exchange gain was mainly due to (1) a reduction of foreign exchange gain (loss) volatility from the application of cash flow hedge which was implemented on December 28, 2019 (unrealized foreign exchange loss from marking-to-market of foreign currency forward contracts after cash flow hedge application was $1.7 million for the nine months ended March 26, 2021, as compared to unrealized foreign exchange loss from marking-to-market of foreign currency forward contracts of $4.0 million for the nine months ended March 27, 2020), (2) foreign exchange gain of $1.2 million from our subsidiaries in the PRC and in the U.K. for the nine months ended March 26, 2021, as compared to foreign exchange loss of $0.7 million from our subsidiaries in the PRC and the U.K. for the nine months ended March 27, 2020, and (3) lower realized foreign exchange loss from payment/receipt of

[0001408710-21-000022:mdna:119]
$1.1 million for the nine months ended March 26, 2021, as compared to realized foreign exchange loss from payment/receipt of $1.6 million for the nine months ended March 27, 2020, partially offset with lower unrealized gain from revaluation of outstanding Thai baht assets and liabilities of $1.9 million for the nine months ended March 26, 2021, as compared to unrealized gain from revaluation of outstanding Thai baht assets and liabilities of $3.3 million for the nine months ended March 27, 2020.

[0001408710-21-000022:mdna:120]
[same as prior period, unchanged from 0001408710-21-000011:mdna:119]

[0001408710-21-000022:mdna:121]
We recorded income before income taxes of $39.1 million and $110.1 million for the three and nine months ended March 26, 2021, respectively, compared with $29.2 million and $90.6 million for the three and nine months ended March 27, 2020, respectively.

[0001408710-21-000022:mdna:122]
[same as prior period, unchanged from 0001408710-21-000011:mdna:121]

[0001408710-21-000022:mdna:123]
Our provision for income tax reflects an effective tax rate of 4.0% and 2.4% for the three months ended March 26, 2021 and March 27, 2020, respectively. The increase was primarily due to the fact that we had more income subject to tax during the third quarter of fiscal year 2021 as compared to the same period in fiscal year 2020.

[0001408710-21-000022:mdna:124]
Our provision for income tax reflects an effective tax rate of 3.8% and 4.2% for the nine months ended March 26, 2021 and March 27, 2020, respectively. The decrease was primarily due to the fact that we had less income subject to tax during the first nine months of fiscal year 2021 as compared to the same period in fiscal year 2020.

[0001408710-21-000022:mdna:125]
[same as prior period, unchanged from 0001408710-21-000011:mdna:124]

[0001408710-21-000022:mdna:126]
We recorded net income of $37.5 million, or 7.8% of revenues, for the three months ended March 26, 2021, compared with $28.3 million, or 6.9% of revenues, for the three months ended March 27, 2020.

[0001408710-21-000022:mdna:127]
We recorded net income of $105.9 million, or 7.7% of revenues, for the nine months ended March 26, 2021, compared with $85.5 million, or 6.9% of revenues, for the nine months ended March 27, 2020.

[0001408710-21-000022:mdna:128]
[same as prior period, unchanged from 0001408710-21-000011:mdna:127]

[0001408710-21-000022:mdna:129]
We recorded other comprehensive loss of $5.3 million, or 1.1% of revenues, for the three months ended March 26, 2021, compared with other comprehensive loss of $8.2 million, or 2.0% of revenues, for the three months ended March 27, 2020. The decrease in other comprehensive loss was mainly due to (1) unrealized gain from mark-to-market of interest rate swap agreement of $0.1 million for the three months ended March 26, 2021, as compared to unrealized loss from mark-to-market of interest rate swap agreement of $1.6 million for the three months ended March 27, 2020, and (2) unrealized loss from mark-to-market of available-for-sale debt securities of $0.6 million for the three months ended March 26, 2021, as compared to unrealized loss from mark-to-market of available-for-sale debt securities of $1.4 million for the three months ended March 27, 2020.

[0001408710-21-000022:mdna:130]
We recorded other comprehensive loss of $5.8 million, or 0.4% of revenues, for the nine months ended March 26, 2021, compared with other comprehensive loss of $8.0 million, or 0.6% of revenues, for the nine months ended March 27, 2020. The decrease in other comprehensive loss was mainly due to (1) unrealized gain from mark-to-market of interest rate swap agreement of $0.2 million for the nine months ended March 26, 2021, as compared to unrealized loss from mark-to-market of interest rate swap agreement of $1.8 million for the nine months ended March 27, 2020, (2) gain in foreign currency translation adjustment of $0.5 million for the nine months ended March 26, 2021, as compared to loss in foreign currency translation adjustment of $0.4 million for the nine months ended March 27, 2020, and (3) unrealized loss from mark-to-market of available-for-sale debt securities of $0.9 million for the nine months ended March 26, 2021, as compared to unrealized loss from mark-to-market of available-for-sale debt securities of $1.4 million for the nine months ended March 27, 2020, offset with unrealized loss from mark-to-market of foreign currency forward contracts of $6.0 million for the nine months ended March 26, 2021, as compared to unrealized loss from mark-to-market of foreign currency forward contracts of $4.9 million for the nine months ended March 27, 2020.

[0001408710-21-000022:mdna:131]
[same as prior period, unchanged from 0001408710-21-000011:mdna:130]

[0001408710-21-000022:mdna:132]
[same as prior period, unchanged from 0001408710-21-000011:mdna:131]

[0001408710-21-000022:mdna:133]
We primarily finance our operations through cash flow from operations. As of March 26, 2021 and March 27, 2020, we had cash, cash equivalents, and short-term investments of $508.7 million and $457.8 million, respectively, and outstanding debt of $42.7 million and $54.8 million, respectively.

[0001408710-21-000022:mdna:134]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents was 0.7% and 0.8% for the three and nine months ended March 26, 2021, respectively, and 1.9% and 2.0% for the three and nine months ended March 27, 2020, respectively.

[0001408710-21-000022:mdna:135]
[same as prior period, unchanged from 0001408710-21-000011:mdna:134]

[0001408710-21-000022:mdna:136]
During the nine months ended March 26, 2021, we repaid $9.1 million of the term loan under our credit facility agreement with the Bank of Ayudhya Public Company Limited. As a result, as of March 26, 2021, we had a long-term borrowing of $42.7 million under such credit facility agreement. (See Note 12 for further details.) We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held short-term investments of $261.7 million as of March 26, 2021.

[0001408710-21-000022:mdna:137]
In December 2020, we entered into a construction contract with a local contractor for construction of a new manufacturing building at our campus in Chonburi, Thailand. The contract price is approximately $50.3 million, and construction will be financed by our cash and cash equivalents. We believe that our current cash and cash equivalents, marketable securities, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001408710-21-000022:mdna:138]
[same as prior period, unchanged from 0001408710-21-000011:mdna:137]

[0001408710-21-000022:mdna:139]
[same as prior period, unchanged from 0001408710-21-000011:mdna:138]

[0001408710-21-000022:mdna:140]
|  | Nine Months Ended |
| (amount in thousands) | March 26, 2021 |  | March 27, 2020 |
| Net cash provided by operating activities | $ | 75,157 |  |  | $ | 104,448 |  |
| Net cash used in investing activities | $ | (32,255) |  |  | $ | (28,921) |  |
| Net cash used in financing activities | $ | (28,915) |  |  | $ | (32,000) |  |
| Net increase in cash, cash equivalents and restricted cash | $ | 13,987 |  |  | $ | 43,527 |  |

[0001408710-21-000022:mdna:141]
[same as prior period, unchanged from 0001408710-21-000011:mdna:140]

[0001408710-21-000022:mdna:142]
Net cash provided by operating activities decreased by $29.3 million, or 28.0%, to $75.2 million for the nine months ended March 26, 2021, compared with net cash provided by operating activities of $104.4 million for the nine months ended March 27, 2020. This decrease was primarily due to (1) a change of increase in inventories of $46.9 million to support the new business, (2) a decrease in change of other current assets and non-current assets of $28.7 million, (3) a decrease in cash receipts related to the timing of collection of trade accounts receivable of $13.3 million, and (4) a change of increase in other current liabilities and non-current liabilities of $2.0 million due to unrealized loss of mark-to-market of interest rate swap agreement, offset by (1) a decrease of $41.2 million in payments to trade accounts payable and (2) an increase in net income of $20.5 million.

[0001408710-21-000022:mdna:143]
[same as prior period, unchanged from 0001408710-21-000011:mdna:142]

[0001408710-21-000022:mdna:144]
Net cash used in investing activities increased by $3.3 million, or 11.5%, to $32.3 million for the nine months ended March 26, 2021, compared with net cash used in investing activities of $28.9 million for the nine months ended March 27, 2020. This increase was primarily due to (1) an increase in purchases of short-term investments, net of proceeds from sales and maturities of $23.4 million, (2) an increase in the purchase of property, plant and equipment and intangibles of $2.7 million, and (3) a decrease in the proceeds from disposal of property, plant and equipment of $1.4 million, offset by funds provided to our customer in the amount of $24.3 million to support the customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand in the second quarter of fiscal year 2020.

[0001408710-21-000022:mdna:145]
[same as prior period, unchanged from 0001408710-21-000011:mdna:144]

[0001408710-21-000022:mdna:146]
Net cash used in financing activities decreased by $3.1 million, or 9.6%, to $28.9 million for the nine months ended March 26, 2021, compared with net cash used in financing activities of $32.0 million for the nine months ended March 27, 2020. This decrease was primarily due to (1) a decrease of $12.4 million in payments to repurchase ordinary shares and (2) a decrease of $0.3 million in finance lease liabilities and debt issuance costs, offset by (1) an increase in withholding tax related to net share settlement of restricted share units of $6.6 million and (2) an increase of $3.0 million in net repayment of loans to a bank.

[0001408710-21-000022:mdna:147]
[same as prior period, unchanged from 0001408710-21-000011:mdna:148]

[0001408710-21-000022:mdna:148]
[same as prior period, unchanged from 0001408710-21-000011:mdna:149]
