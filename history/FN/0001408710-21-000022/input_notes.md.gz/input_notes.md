# FN notes — 0001408710-21-000022


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001408710-21-000022:notes:1]
[same as prior period, unchanged from 0001408710-21-000011:notes:1]

[0001408710-21-000022:notes:2]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of March 26, 2021 and for the three and nine  months ended March 26, 2021 and March 27, 2020 includes normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 26, 2020.

[0001408710-21-000022:notes:3]
[same as prior period, unchanged from 0001408710-21-000011:notes:3]

[0001408710-21-000022:notes:4]
The results for the three and nine  months ended March 26, 2021 may not be indicative of results for the year ending June 25, 2021 or any future periods.

[0001408710-21-000022:notes:5]
[same as prior period, unchanged from 0001408710-21-000011:notes:5]

[0001408710-21-000022:notes:6]
[same as prior period, unchanged from 0001408710-21-000011:notes:6]

[0001408710-21-000022:notes:7]
[same as prior period, unchanged from 0001408710-21-000011:notes:7]

[0001408710-21-000022:notes:8]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended March 26, 2021 and March 27, 2020 each consisted of 13 weeks. The nine months ended March 26, 2021 and March 27, 2020 each consisted of 39 weeks. Fiscal year 2021 will be comprised of 52 weeks and will end on June 25, 2021.

[0001408710-21-000022:notes:9]
[same as prior period, unchanged from 0001408710-21-000011:notes:9]

[0001408710-21-000022:notes:10]
[same as prior period, unchanged from 0001408710-21-000011:notes:10]

[0001408710-21-000022:notes:11]
[same as prior period, unchanged from 0001408710-21-000011:notes:11]

[0001408710-21-000022:notes:12]
[same as prior period, unchanged from 0001408710-21-000011:notes:12]

[0001408710-21-000022:notes:13]
[same as prior period, unchanged from 0001408710-21-000011:notes:13]

[0001408710-21-000022:notes:14]
As of March 26, 2021, the derivative assets and liabilities were measured at fair value, but the gross fair value amount is presented in the unaudited condensed consolidated balance sheets. Additionally, a classification of current and non-current portion is determined by the maturity date of that derivative (e.g., a derivative that matures within one year is classified as current).

[0001408710-21-000022:notes:15]
[same as prior period, unchanged from 0001408710-21-000011:notes:15]

[0001408710-21-000022:notes:16]
[same as prior period, unchanged from 0001408710-21-000011:notes:16]

[0001408710-21-000022:notes:17]
[same as prior period, unchanged from 0001408710-21-000011:notes:17]

[0001408710-21-000022:notes:18]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13, “Financial Instruments—Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments.” This standard requires the measurement and recognition of expected credit losses for financial assets held at amortized cost. The standard replaces the existing incurred loss impairment model with an expected loss methodology, which will result in more timely recognition of credit losses. The new standard also expands the required quantitative and qualitative disclosures surrounding expected credit losses.

[0001408710-21-000022:notes:19]
[same as prior period, unchanged from 0001408710-21-000011:notes:19]

[0001408710-21-000022:notes:20]
Management estimates the expected credit losses of financial assets using relevant available information from internal and external sources relating to historical credit loss experience, current conditions and reasonable forecasts over a financial asset’s contractual term. Adjustments to historical loss information are made from qualitative and quantitative factors if economic conditions on the reporting date reflect stronger or weaker economic performance than the historical data implies based on management’s expectations of economic conditions on certain indicators of the Company, industry and economy. The Company reviews factors such as past collection experience, age of the accounts receivable and contract assets balance, significant trends in current balances, internal operations and macroeconomic conditions. In addition, the Company modified its impairment model to the Current Expected Credit Losses (“CECL”) model for available-for-sale (“AFS”) debt securities and discontinued using the concept of “other than temporary” impairment on these AFS debt

[0001408710-21-000022:notes:21]
securities. CECL on the AFS debt securities are recognized in interest income and other income (expense), net on the Company’s unaudited condensed consolidated statements of operations and comprehensive income, and any remaining unrealized losses, are included in accumulated other comprehensive income (loss) (“AOCI”) in the unaudited condensed consolidated balance sheet.

[0001408710-21-000022:notes:22]
[same as prior period, unchanged from 0001408710-21-000011:notes:22]

[0001408710-21-000022:notes:23]
[same as prior period, unchanged from 0001408710-21-000011:notes:23]

[0001408710-21-000022:notes:24]
On January 1, 2021, FASB issued ASU 2021-01, “Reference Rate Reform (Topic 848).” This standard requires the measurement and recognition of expected credit losses for financial assets held at amortized cost. The amendments in this update clarify that certain optional expedients and exceptions in Topic 848 for contract modifications and hedge accounting apply to derivatives that are affected by the discounting transition. The Company immediately adopted this standard with no impact on its unaudited condensed consolidated financial statements.

[0001408710-21-000022:notes:25]
[same as prior period, unchanged from 0001408710-21-000011:notes:24]

[0001408710-21-000022:notes:26]
Except for the adoption of ASC 326, ASC 820 and ASC 848, the Company has consistently applied the accounting policies to all periods presented in these unaudited condensed consolidated financial statements.

[0001408710-21-000022:notes:27]
[same as prior period, unchanged from 0001408710-21-000011:notes:26]

[0001408710-21-000022:notes:28]
Management determines the appropriate classification of its investments at the time of purchase and re-evaluates the designations at each balance sheet date. The Company may sell certain of the Company’s short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s short-term investments generally range from three months to three years. The Company’s short-term investments, which consist of investments in U.S. Treasury, fixed income securities, liquidity funds that invest in short-term debt securities and certificates of deposit and time deposits, have been classified and accounted for as AFS. The AFS investments are carried at estimated fair value with any unrealized gains and losses, included in AOCI in the Company’s unaudited condensed consolidated balance sheet. The Company determines realized gains or losses on sale of marketable securities on a specific identification method and records such gains or losses as interest income and other income (expense), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-21-000022:notes:29]
[same as prior period, unchanged from 0001408710-21-000011:notes:28]

[0001408710-21-000022:notes:30]
[same as prior period, unchanged from 0001408710-21-000011:notes:29]

[0001408710-21-000022:notes:31]
[same as prior period, unchanged from 0001408710-21-000011:notes:30]

[0001408710-21-000022:notes:32]
[same as prior period, unchanged from 0001408710-21-000011:notes:31]

[0001408710-21-000022:notes:33]
[same as prior period, unchanged from 0001408710-21-000011:notes:32]

[0001408710-21-000022:notes:34]
Accounts receivable are recorded and carried at the original invoiced amount less an allowance for any potential uncollectible amounts. The Company makes estimates of expected credit losses for the allowance for doubtful accounts based upon its assessment of various factors, including historical experience, the age of the accounts receivable balances, credit quality of its customers, current economic conditions, reasonable and supportable forecasts of future economic

[0001408710-21-000022:notes:35]
conditions, and other factors that may affect the Company’s ability to collect from customers. The estimated credit loss allowance is recorded as selling, general and administrative expenses in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-21-000022:notes:36]
[same as prior period, unchanged from 0001408710-21-000011:notes:34]

[0001408710-21-000022:notes:37]
[same as prior period, unchanged from 0001408710-21-000011:notes:35]

[0001408710-21-000022:notes:38]
[same as prior period, unchanged from 0001408710-21-000011:notes:36]

[0001408710-21-000022:notes:39]
[same as prior period, unchanged from 0001408710-21-000011:notes:37]

[0001408710-21-000022:notes:40]
[same as prior period, unchanged from 0001408710-21-000011:notes:38]

[0001408710-21-000022:notes:41]
[same as prior period, unchanged from 0001408710-21-000011:notes:39]

[0001408710-21-000022:notes:42]
[same as prior period, unchanged from 0001408710-21-000011:notes:40]

[0001408710-21-000022:notes:43]
[same as prior period, unchanged from 0001408710-21-000011:notes:41]

[0001408710-21-000022:notes:44]
[same as prior period, unchanged from 0001408710-21-000011:notes:42]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001408710-21-000022:notes:45]
[same as prior period, unchanged from 0001408710-21-000011:notes:43]

[0001408710-21-000022:notes:46]
Revenues are attributed to a particular geographic area based on the bill-to-location of the Company’s customers. The Company operates in three geographic regions: North America, Asia-Pacific and others and Europe.

[0001408710-21-000022:notes:47]
[same as prior period, unchanged from 0001408710-21-000011:notes:45]

[0001408710-21-000022:notes:48]
| (amount in thousands, except percentages) | Three Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 230,177 |  |  |  |  | 661,410 |  |  |  |
| Others | 618 |  |  |  |  | 1,459 |  |  |  |
| Total revenue in North America | 230,795 |  |  | 48.2 | % |  | 662,869 |  |  | 48.4 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Malaysia | 22,910 |  |  |  |  | 107,700 |  |  |  |
| India | 56,719 |  |  |  |  | 85,535 |  |  |  |
| Israel | 25,796 |  |  |  |  | 82,915 |  |  |  |
| Hong Kong | 21,524 |  |  |  |  | 63,397 |  |  |  |
| Japan | 18,582 |  |  |  |  | 56,223 |  |  |  |
| Others | 21,770 |  |  |  |  | 71,477 |  |  |  |
| Total revenue in Asia-Pacific and others | 167,301 |  |  | 34.9 | % |  | 467,247 |  |  | 34.1 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 47,096 |  |  |  |  | 149,696 |  |  |  |
| U.K. | 15,298 |  |  |  |  | 40,742 |  |  |  |
| Germany | 7,543 |  |  |  |  | 19,596 |  |  |  |
| Others | 11,284 |  |  |  |  | 29,633 |  |  |  |
| Total revenue in Europe | $ | 81,221 |  |  | 16.9 | % |  | $ | 239,667 |  |  | 17.5 | % |
| Total revenue | $ | 479,317 |  |  | 100.0 | % |  | $ | 1,369,783 |  |  | 100.0 | % |

[0001408710-21-000022:notes:49]
| (amount in thousands, except percentages) | Three Months EndedMarch 27, 2020 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 27, 2020 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | 206,329 |  |  |  |  | 630,023 |  |  |  |
| Others | 422 |  |  |  |  | 1,073 |  |  |  |
| Total revenue in North America | 206,751 |  |  | 50.3 | % |  | 631,096 |  |  | 51.0 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Malaysia | 52,414 |  |  |  |  | 136,698 |  |  |  |
| Japan | 24,985 |  |  |  |  | 78,362 |  |  |  |
| Hong Kong | 20,710 |  |  |  |  | 70,410 |  |  |  |
| Israel | 25,530 |  |  |  |  | 69,310 |  |  |  |
| China | 8,126 |  |  |  |  | 34,882 |  |  |  |
| Others | 9,874 |  |  |  |  | 11,547 |  |  |  |
| Total revenue in Asia-Pacific and others | 141,639 |  |  | 34.4 | % |  | 401,209 |  |  | 32.5 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland | 26,716 |  |  |  |  | 84,034 |  |  |  |
| U.K. | 22,297 |  |  |  |  | 52,941 |  |  |  |
| Germany | 5,600 |  |  |  |  | 41,207 |  |  |  |
| Others | 8,207 |  |  |  |  | 26,236 |  |  |  |
| Total revenue in Europe | $ | 62,820 |  |  | 15.3 | % |  | $ | 204,418 |  |  | 16.5 | % |
| Total revenue | $ | 411,210 |  |  | 100.0 | % |  | $ | 1,236,723 |  |  | 100.0 | % |

[0001408710-21-000022:notes:50]
[same as prior period, unchanged from 0001408710-21-000011:notes:48]

[0001408710-21-000022:notes:51]
| (amount in thousands, except percentages) | Three Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 26, 2021 |  | As a % of TotalRevenues |
| Optical communications | $ | 361,739 |  |  | 75.5 | % |  | $ | 1,053,496 |  |  | 76.9 | % |
| Lasers, sensors and other | 117,578 |  |  | 24.5 | % |  | 316,287 |  |  | 23.1 | % |
| Total | $ | 479,317 |  |  | 100.0 | % |  | $ | 1,369,783 |  |  | 100.0 | % |

[0001408710-21-000022:notes:52]
| (amount in thousands, except percentages) | Three Months EndedMarch 27, 2020 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 27, 2020 |  | As a % of TotalRevenues |
| Optical communications | $ | 308,566 |  |  | 75.0 | % |  | $ | 933,013 |  |  | 75.4 | % |
| Lasers, sensors and other | 102,644 |  |  | 25.0 | % |  | 303,710 |  |  | 24.6 | % |
| Total | $ | 411,210 |  |  | 100.0 | % |  | $ | 1,236,723 |  |  | 100.0 | % |

[0001408710-21-000022:notes:53]
[same as prior period, unchanged from 0001408710-21-000011:notes:51]

[0001408710-21-000022:notes:54]
[same as prior period, unchanged from 0001408710-21-000011:notes:52]

[0001408710-21-000022:notes:55]
[same as prior period, unchanged from 0001408710-21-000011:notes:53]

[0001408710-21-000022:notes:56]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the nine months ended March 26, 2021:

[0001408710-21-000022:notes:57]
| (amount in thousands) | ContractAssets |
| Beginning balance, June 26, 2020 | $ | 13,256 |  |
| Revenue recognized | 50,841 |  |
| Amounts collected or invoiced | (46,967) |  |
| Ending balance, March 26, 2021 | $ | 17,130 |  |

[0001408710-21-000022:notes:58]
| (amount in thousands) | ContractLiabilities |
| Beginning balance, June 26, 2020 | $ | 1,556 |  |
| Advance payment received during the period | 16,414 |  |
| Revenue recognized | (16,561) |  |
| Ending balance, March 26, 2021 | $ | 1,409 |  |


## us-gaap:EarningsPerShareTextBlock

[0001408710-21-000022:notes:59]
[same as prior period, unchanged from 0001408710-21-000011:notes:57]

[0001408710-21-000022:notes:60]
[same as prior period, unchanged from 0001408710-21-000011:notes:58]

[0001408710-21-000022:notes:61]
|  | Three Months Ended |  | Nine Months Ended |
| (amount in thousands except per share amounts) | March 26,2021 |  | March 27,2020 |  | March 26,2021 |  | March 27,2020 |
| Net income attributable to shareholders | $ | 37,493 |  |  | $ | 28,267 |  |  | $ | 105,928 |  |  | $ | 85,455 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) | 36,875 |  |  | 36,987 |  |  | 36,876 |  |  | 36,970 |  |
| Incremental shares arising from the assumed vesting of restricted share units and performance share units (thousands of shares) | 734 |  |  | 810 |  |  | 638 |  |  | 726 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) | 37,609 |  |  | 37,797 |  |  | 37,514 |  |  | 37,696 |  |
| Basic earnings per ordinary share | $ | 1.02 |  |  | $ | 0.76 |  |  | $ | 2.87 |  |  | $ | 2.31 |  |
| Diluted earnings per ordinary share | $ | 1.00 |  |  | $ | 0.75 |  |  | $ | 2.82 |  |  | $ | 2.27 |  |
| Outstanding performance share units excluded from the computation of diluted earnings per ordinary share (thousands of shares)(1) | 76 |  |  | 50 |  |  | 76 |  |  | 50 |  |

[0001408710-21-000022:notes:62]
[same as prior period, unchanged from 0001408710-21-000011:notes:60]


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001408710-21-000022:notes:63]
[same as prior period, unchanged from 0001408710-21-000011:notes:61]

[0001408710-21-000022:notes:64]
|  |  |  | Fair Value |
| (amount in thousands) | CarryingCost |  | UnrealizedGain/(Loss) |  | Cash andCashEquivalents |  | MarketableSecurities |  | OtherInvestments |
| As of March 26, 2021 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 239,096 |  |  | $ | — |  |  | $ | 239,096 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 7,915 |  |  | — |  |  | 7,915 |  |  | — |  |  | — |  |
| Liquidity funds | 51,344 |  |  | — |  |  | — |  |  | — |  |  | 51,344 |  |
| Certificates of deposit and time deposits | 20,500 |  |  | — |  |  | — |  |  | — |  |  | 20,500 |  |
| Corporate debt securities | 158,048 |  |  | 302 |  |  | — |  |  | 158,350 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 31,289 |  |  | 253 |  |  | — |  |  | 31,542 |  |  | — |  |
| Total | $ | 508,192 |  |  | $ | 555 |  |  | $ | 247,011 |  |  | $ | 189,892 |  |  | $ | 71,844 |  |
| As of June 26, 2020 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 218,117 |  |  | $ | — |  |  | $ | 218,117 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 7,313 |  |  | — |  |  | 7,313 |  |  | — |  |  | — |  |
| Liquidity funds | 41,051 |  |  | — |  |  | — |  |  | — |  |  | 41,051 |  |
| Certificates of deposit and time deposits | 11,800 |  |  | — |  |  | — |  |  | — |  |  | 11,800 |  |
| Corporate debt securities | 159,220 |  |  | 948 |  |  | — |  |  | 160,168 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 49,130 |  |  | 544 |  |  | — |  |  | 49,674 |  |  | — |  |
| Total | $ | 486,631 |  |  | $ | 1,492 |  |  | $ | 225,430 |  |  | $ | 209,842 |  |  | $ | 52,851 |  |

[0001408710-21-000022:notes:65]
All highly liquid investments with original maturities of three months or less at the date of purchase are classified as cash equivalents. Management determines the appropriate classification of its investments at the time of purchase and reevaluates the designations at each balance sheet date. The Company may sell certain of its short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s short-term investments generally range from three months to three years.

[0001408710-21-000022:notes:66]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of March 26, 2021 and June 26, 2020:

[0001408710-21-000022:notes:67]
|  | March 26, 2021 |  | June 26, 2020 |
| (amount in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 62,641 |  |  | $ | 62,638 |  |  | $ | 76,127 |  |  | $ | 76,196 |  |
| Due between one to five years | 126,696 |  |  | 127,254 |  |  | 132,223 |  |  | 133,646 |  |
| Total | $ | 189,337 |  |  | $ | 189,892 |  |  | $ | 208,350 |  |  | $ | 209,842 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001408710-21-000022:notes:68]
[same as prior period, unchanged from 0001408710-21-000011:notes:66]

[0001408710-21-000022:notes:69]
[same as prior period, unchanged from 0001408710-21-000011:notes:67]

[0001408710-21-000022:notes:70]
[same as prior period, unchanged from 0001408710-21-000011:notes:68]

[0001408710-21-000022:notes:71]
[same as prior period, unchanged from 0001408710-21-000011:notes:69]

[0001408710-21-000022:notes:72]
[same as prior period, unchanged from 0001408710-21-000011:notes:70]

[0001408710-21-000022:notes:73]
[same as prior period, unchanged from 0001408710-21-000011:notes:71]

[0001408710-21-000022:notes:74]
|  | Fair Value Measurements at Reporting Date Using |
| (amount in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of March 26, 2021 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 7,915 |  |  |  | $ | — |  |  | $ | 7,915 |  |
| Liquidity funds | — |  |  | 51,344 |  |  |  | — |  |  | 51,344 |  |
| Certificates of deposit and time deposits | — |  |  | 20,500 |  |  |  | — |  |  | 20,500 |  |
| Corporate debt securities | — |  |  | 158,350 |  |  |  | — |  |  | 158,350 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 31,542 |  |  |  | — |  |  | 31,542 |  |
| Derivative assets – current portion | — |  |  | 167 |  | (1) |  | — |  |  | 167 |  |
| Total | $ | — |  |  | $ | 269,818 |  |  |  | $ | — |  |  | $ | 269,818 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | 4,889 |  |  |  | $ | — |  |  | $ | 4,889 |  |
| Derivative liabilities – non-current portion | — |  |  | 2,423 |  |  |  | — |  |  | 2,423 |  |
| Total | $ | — |  |  | $ | 7,312 |  | (2) |  | $ | — |  |  | $ | 7,312 |  |

[0001408710-21-000022:notes:75]
[same as prior period, unchanged from 0001408710-21-000011:notes:73]

[0001408710-21-000022:notes:76]
(1)Foreign currency forward contracts with a notional amount of $22.0 million.

[0001408710-21-000022:notes:77]
(2)Foreign currency forward contracts with a notional amount of $113.0 million and Canadian dollars of 0.8 million and two interest rate swap agreements with a notional amount of $125.1 million.

[0001408710-21-000022:notes:78]
[same as prior period, unchanged from 0001408710-21-000011:notes:76]

[0001408710-21-000022:notes:79]
[same as prior period, unchanged from 0001408710-21-000011:notes:77]

[0001408710-21-000022:notes:80]
[same as prior period, unchanged from 0001408710-21-000011:notes:78]

[0001408710-21-000022:notes:81]
[same as prior period, unchanged from 0001408710-21-000011:notes:79]

[0001408710-21-000022:notes:82]
[same as prior period, unchanged from 0001408710-21-000011:notes:80]

[0001408710-21-000022:notes:83]
[same as prior period, unchanged from 0001408710-21-000011:notes:81]

[0001408710-21-000022:notes:84]
[same as prior period, unchanged from 0001408710-21-000011:notes:82]

[0001408710-21-000022:notes:85]
[same as prior period, unchanged from 0001408710-21-000011:notes:83]

[0001408710-21-000022:notes:86]
[same as prior period, unchanged from 0001408710-21-000011:notes:84]

[0001408710-21-000022:notes:87]
[same as prior period, unchanged from 0001408710-21-000011:notes:85]

[0001408710-21-000022:notes:88]
As of March 26, 2021, the Company had 135 outstanding U.S. dollar foreign currency forward contracts against Thai baht, with an aggregate notional amount of $135.0 million and maturity dates ranging from April 2021 through October 2021 and two outstanding Canadian dollar foreign currency forward contracts with an aggregate notional amount of 0.8 million Canadian dollars and a maturity date in June 2021.

[0001408710-21-000022:notes:89]
As of June 26, 2020, the Company had 125 outstanding U.S. dollar foreign currency forward contracts against Thai baht with an aggregate notional amount of $125.0 million, one foreign currency contract with a notional amount of 0.6 million Canadian dollars and one foreign currency option contract with notional amount of $1.0 million with maturity dates ranging from July 2020 through January 2021.

[0001408710-21-000022:notes:90]
As of March 26, 2021, the hedging relationship over foreign currency forward contracts that were designated for hedge accounting was determined to be highly effective based on the performance of retrospective and prospective regression testing. As of March 26, 2021, the amount in AOCI that is expected to be reclassified into earnings within 12 months was a loss of $3.3 million.

[0001408710-21-000022:notes:91]
During the three and nine  months ended March 26, 2021, the Company recorded an unrealized loss of $2.0 million and $1.7 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-21-000022:notes:92]
During the three and nine  months ended March 27, 2020, the Company recorded an unrealized loss of $2.1 million and $4.0 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-21-000022:notes:93]
[same as prior period, unchanged from 0001408710-21-000011:notes:91]

[0001408710-21-000022:notes:94]
The Company entered into interest rate swap agreements to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. As of March 26, 2021 and June 26, 2020, the Company had two outstanding interest rate swap agreements with an aggregate notional amount of $125.1 million.

[0001408710-21-000022:notes:95]
On July 25, 2018, Fabrinet Thailand entered into an interest rate swap agreement to effectively convert the floating interest rate of its term loan under the Bank of America Credit Facility Agreement to a fixed interest rate of 2.86% per annum through the scheduled maturity of the term loan in June 2023 (see Note 12). The Company did not designate this interest rate swap for hedge accounting.

[0001408710-21-000022:notes:96]
On September 3, 2019, the Company entered into a new term loan agreement under a Credit Facility Agreement with the Bank of Ayudhya Public Company Limited (the “Bank”) (see Note 12) and on September 10, 2019, repaid in full the outstanding term loan under the Bank of America Credit Facility (see Note 12). In conjunction with the funding of the new term loan, the Company entered into a second interest rate swap agreement. The combination of both of these interest rate swaps effectively converts the floating interest rate of the Company’s new term loan with the Bank to a fixed interest rate of 4.36% per annum through the maturity of the term loan in June 2024.

[0001408710-21-000022:notes:97]
On September 27, 2019, the Company designated these two interest rate swaps as a cash flow hedge for the Company’s term loan under the Credit Facility Agreement with the Bank. The combination of these two interest rate swaps qualified for hedge accounting because the hedges are highly effective, and the Company has designated and documented contemporaneously the hedging relationships involving these interest rate swaps. While the Company intends to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in earnings. From September 27, 2019, any gains or losses related to these interest rate swaps will be recorded in AOCI in the unaudited condensed consolidated balance sheets. The Company will reclassify a portion of the gains or losses from AOCI into earnings at each reporting period based on either the accrued interest amount or the interest payment.

[0001408710-21-000022:notes:98]
As of March 26, 2021, the amount in AOCI that is expected to be reclassified into earnings within 12 months is a loss of $0.7 million.

[0001408710-21-000022:notes:99]
Prior to September 27, 2019, these interest rate swaps were not designated as cash flow hedges and all changes in the fair value of these interest rate swaps were reflected in earnings. During the three and nine  months ended March 27, 2020, the Company recorded unrealized loss of nil and $1.7 million, respectively, from changes in the fair value of these interest rate swaps as interest expense in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-21-000022:notes:100]
[same as prior period, unchanged from 0001408710-21-000011:notes:98]

[0001408710-21-000022:notes:101]
|  |  |  | Three Months Ended |  | Nine Months Ended |
| (amount in thousands) | Financialstatementsline item |  | March 26,2021 |  | March 27,2020 |  | March 26,2021 |  | March 27,2020 |
| Derivatives gain (loss)recognized in othercomprehensive income (loss): |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Othercomprehensiveincome |  | $ | (6,098) |  |  | $ | (6,609) |  |  | $ | (5,289) |  |  | $ | (6,609) |  |
| Interest rate swaps | Othercomprehensiveincome |  | 453 |  |  | (1,239) |  |  | 1,196 |  |  | (956) |  |
| Total derivatives gain (loss) recognized in other comprehensive income (loss) |  |  | $ | (5,645) |  |  | $ | (7,848) |  |  | $ | (4,093) |  |  | $ | (7,565) |  |
| Derivatives loss (gain) reclassified from accumulated other comprehensive income (loss) into earnings: |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Cost of revenues |  | $ | (1,470) |  |  | $ | 14 |  |  | $ | (3,190) |  |  | $ | 14 |  |
| Foreign currency forward contracts | SG&A |  | (62) |  |  | 1 |  |  | (135) |  |  | 1 |  |
| Foreign currency forward contracts | Foreign exchange loss, net |  | 2,491 |  |  | 1,669 |  |  | 2,604 |  |  | 1,669 |  |
| Interest rate swaps | Interest expense |  | (314) |  |  | (405) |  |  | (1,009) |  |  | (838) |  |
| Total derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings |  |  | $ | 645 |  |  | $ | 1,279 |  |  | $ | (1,730) |  |  | $ | 846 |  |
| Change in net unrealized gain (loss) on derivatives instruments |  |  | $ | (5,000) |  |  | $ | (6,569) |  |  | $ | (5,823) |  |  | $ | (6,719) |  |

[0001408710-21-000022:notes:102]
[same as prior period, unchanged from 0001408710-21-000011:notes:100]

[0001408710-21-000022:notes:103]
[same as prior period, unchanged from 0001408710-21-000011:notes:101]

[0001408710-21-000022:notes:104]
|  | March 26,2021 |  | June 26,2020 |
| (amount in thousands) | DerivativeAssets |  | DerivativeLiabilities |  | DerivativeAssets |  | DerivativeLiabilities |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts | $ | 166 |  |  | $ | (90) |  |  | $ | 9 |  |  | $ | (611) |  |
| Interest rate swaps | — |  |  | — |  |  | — |  |  | — |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward contracts | 1 |  |  | (3,246) |  |  | 2,814 |  |  | (83) |  |
| Interest rate swaps | — |  |  | (3,976) |  |  | — |  |  | (5,172) |  |
| Derivatives, gross balances | $ | 167 |  |  | $ | (7,312) |  |  | $ | 2,823 |  |  | $ | (5,866) |  |

[0001408710-21-000022:notes:105]
[same as prior period, unchanged from 0001408710-21-000011:notes:103]

[0001408710-21-000022:notes:106]
[same as prior period, unchanged from 0001408710-21-000011:notes:104]


## us-gaap:InventoryDisclosureTextBlock

[0001408710-21-000022:notes:107]
[same as prior period, unchanged from 0001408710-21-000011:notes:105]

[0001408710-21-000022:notes:108]
| (amount in thousands) | As of March 26,2021 |  | As of June 26,2020 |
| Raw materials | $ | 129,570 |  |  | $ | 141,522 |  |
| Work in progress | 178,964 |  |  | 136,344 |  |
| Finished goods | 24,034 |  |  | 17,950 |  |
| Goods in transit | 20,715 |  |  | 13,970 |  |
| Inventories | $ | 353,283 |  |  | $ | 309,786 |  |


## fn:ScheduleOfOtherReceivableTextBlock

[0001408710-21-000022:notes:109]
Other receivableOn October 1, 2019, the Company provided funds in the amount of $24.3 million to a customer to support the customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. On October 1, 2020, the Company extended the payment terms of the funds and the accrued interest from September 30, 2020 to April 1, 2021, and reduced the interest rate effective from October 1, 2020. The extension was granted in connection with the customer’s agreement to transfer additional manufacturing operations to the Company’s facilities in Thailand beginning in November 2020. These funds will be offset by the amount due to this customer for the purchases of certain inventories. As of March 26, 2021, the Company recorded the $24.3 million funds as other receivable in the unaudited condensed consolidated balance sheet. The funds were repaid on April 1, 2021.


## fn:RestrictedCashAndCashEquivalentsTextBlock

[0001408710-21-000022:notes:110]
Restricted cashAs of March 26, 2021, the Company had long-term restricted cash of Renminbi 1.0 million related to bank guarantees of its subsidiary in the PRC to support the subsidiary's operations. The bank guarantee was backed by cash collateral of $0.2 million.As of June 26, 2020, the Company had one outstanding standby letter of credit of 6.0 million Euros, related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. The standby letter of credit was backed by cash collateral of $7.4 million. This standby letter of credit expired on December 31, 2020 and the corresponding cash collateral was released in January 2021.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001408710-21-000022:notes:111]
LeasesThe Company leases facilities under non-cancelable operating lease agreements. The Company leases a portion of its capital equipment and vehicles, certain land and buildings for its facilities in Thailand, the Cayman Islands, the PRC, the U.S., the U.K. and Israel under operating lease arrangements that expire at various dates through 2025. Certain of these lease arrangements provide the Company the ability to extend the lease from one to five years following the expiration of the current term. However, the Company has excluded all lease extension options from its ROU assets and lease liabilities as the Company is not reasonably assured that it will exercise these options. None of the lease agreements contain residual value guarantees provided by the lessee. The Company also has one intercompany lease transaction in the form of a lease of office and manufacturing space between Fabritek and Fabrinet West.
Operating leases

[0001408710-21-000022:notes:112]
As of March 26, 2021, the maturities of the Company’s operating lease liabilities were as follows:

[0001408710-21-000022:notes:113]
| (amount in thousands) | As of March 26,2021 |  |
| 2021 (remaining three months) | $ | 650 |  |  |
| 2022 | 2,585 |  |  |
| 2023 | 2,468 |  |  |
| 2024 | 1,092 |  |  |
| 2025 | 41 |  |  |
| Total undiscounted lease payments | 6,836 |  |  |
| Less imputed interest | (348) |  |  |
| Total present value of lease liabilities | $ | 6,488 |  | (1) |

[0001408710-21-000022:notes:114]
(1)Included current portion of operating lease liabilities for the period ended March 26, 2021.

[0001408710-21-000022:notes:115]
Rental expense related to the Company’s operating leases is recognized on a straight-line basis over the lease term. Rental expense for long-term leases for the three and nine  months ended March 26, 2021 was $0.7 million and $1.9 million, respectively, and for the three and nine  months ended March 27, 2020 was $0.5 million and $1.5 million, respectively. Rental expense for short-term leases for the three and nine  months ended March 26, 2021 was $0.1 million and $0.3 million, respectively, and for the three and nine  months ended March 27, 2020 was immaterial.

[0001408710-21-000022:notes:116]
[same as prior period, unchanged from 0001408710-21-000011:notes:116]

[0001408710-21-000022:notes:117]
|  | As ofMarch 26, 2021 |  | As ofJune 26, 2020 |
| Weighted-average remaining lease term (in years) | 2.9 |  | 3.3 |
| Weighted-average discount rate | 3.7 | % |  | 3.7 | % |

[0001408710-21-000022:notes:118]
The following table presents supplemental disclosure for the unaudited condensed consolidated statement of cash flows related to operating and finance leases for the three and nine months ended March 26, 2021 and March 27, 2020:

[0001408710-21-000022:notes:119]
|  | Three Months Ended |  | Nine Months Ended |
| (amount in thousands) | March 26,2021 |  | March 27,2020 |  | March 26,2021 |  | March 27,2020 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |
| Operating cash flows from operating leases | $ | 628 |  |  | $ | 770 |  |  | $ | 1,889 |  |  | $ | 1,794 |  |
| Financing cash flows from finance leases | $ | — |  |  | $ | 115 |  |  | $ | 100 |  |  | $ | 304 |  |
| ROU assets obtained in exchange for lease liabilities | $ | 60 |  |  | $ | 55 |  |  | $ | 1,916 |  |  | $ | 7,175 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001408710-21-000022:notes:120]
[same as prior period, unchanged from 0001408710-21-000011:notes:120]

[0001408710-21-000022:notes:121]
| (amount in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  | ForeignCurrencyTranslationAdjustment |  | Net |
| As of March 26, 2021 |  |  |  |  |  |  |  |
| Software | $ | 9,611 |  |  | $ | (6,376) |  |  | $ | — |  |  | $ | 3,235 |  |
| Customer relationships | 4,373 |  |  | (3,077) |  |  | 45 |  |  | 1,341 |  |
| Backlog | 119 |  |  | (119) |  |  | — |  |  | — |  |
| Total intangibles | $ | 14,103 |  |  | $ | (9,572) |  |  | $ | 45 |  |  | $ | 4,576 |  |

[0001408710-21-000022:notes:122]
[same as prior period, unchanged from 0001408710-21-000011:notes:122]

[0001408710-21-000022:notes:123]
The Company recorded amortization expense relating to intangibles of $0.5 million and $0.3 million for the three months ended March 26, 2021 and March 27, 2020, respectively, and $1.2 million and $0.9 million for the nine months ended March 26, 2021 and March 27, 2020, respectively.

[0001408710-21-000022:notes:124]
[same as prior period, unchanged from 0001408710-21-000011:notes:124]

[0001408710-21-000022:notes:125]
| (years) | As ofMarch 26, 2021 |  | As ofJune 26, 2020 |
| Customer relationships | 4.1 |  | 4.6 |

[0001408710-21-000022:notes:126]
Based on the carrying amount of intangibles as of March 26, 2021, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001408710-21-000022:notes:127]
| (amount in thousands) |  |
| 2021 (remaining three months) | $ | 409 |  |
| 2022 | 1,437 |  |
| 2023 | 1,148 |  |
| 2024 | 818 |  |
| 2025 | 543 |  |
| Thereafter | 221 |  |
| Total | $ | 4,576 |  |


## us-gaap:DebtDisclosureTextBlock

[0001408710-21-000022:notes:128]
Borrowings 
The Company’s total borrowings, including current and non-current portions of long-term borrowings, consisted of the following:

[0001408710-21-000022:notes:129]
| (amount in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofMarch 26, 2021 |  | As ofJune 26, 2020 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs – current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 42,656 |  |  | $ | 51,797 |  |
| Less: Current portion |  |  |  |  | (12,188) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs – non-current portion |  |  |  |  | (71) |  |  | (95) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 30,397 |  |  | $ | 39,514 |  |

[0001408710-21-000022:notes:130]
(1)We have entered into interest rate swaps that effectively fix a series of our future interest payments on our term loans. Refer to Note 6.

[0001408710-21-000022:notes:131]
The movements of long-term borrowings for the nine months ended March 26, 2021 and March 27, 2020 were as follows:

[0001408710-21-000022:notes:132]
|  | Nine Months Ended |
| (amount in thousands) | March 26,2021 |  | March 27,2020 |
| Opening balance | $ | 51,797 |  |  | $ | 60,938 |  |
| Borrowings during the period | — |  |  | 60,938 |  |
| Repayments during the period | (9,141) |  |  | (67,032) |  |
| Closing balance | $ | 42,656 |  |  | $ | 54,844 |  |

[0001408710-21-000022:notes:133]
As of March 26, 2021, future maturities of long-term borrowings during each fiscal year were as follows:

[0001408710-21-000022:notes:134]
| (amount in thousands) |  |
| 2021 (remaining three months) | $ | 6,094 |  |
| 2022 | 12,187 |  |
| 2023 | 12,187 |  |
| 2024 | 12,188 |  |
| Total | $ | 42,656 |  |

[0001408710-21-000022:notes:135]
Credit facility agreements:

[0001408710-21-000022:notes:136]
Bank of Ayudhya Public Company Limited

[0001408710-21-000022:notes:137]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a Credit Facility Agreement (the “Credit Facility Agreement”). The Credit Facility Agreement provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of September 27,
2019) and $160.9 million which may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

[0001408710-21-000022:notes:138]
Under the Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a Term Loan Agreement pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company’s previous syndicated senior credit facility agreement.

[0001408710-21-000022:notes:139]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three and nine  months ended March 26, 2021, the Company recorded $0.2 million and $0.6 million, respectively, of interest expense in connection with this term loan.

[0001408710-21-000022:notes:140]
Any borrowings under the Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

[0001408710-21-000022:notes:141]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of March 26, 2021, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

[0001408710-21-000022:notes:142]
The events of default in the Term Loan Agreement include failure to pay amounts due under the Term Loan Agreement or the related finance documents when due, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

[0001408710-21-000022:notes:143]
As of March 26, 2021, there was $42.7 million outstanding under the term loan.

[0001408710-21-000022:notes:144]
Bank of America, N.A.

[0001408710-21-000022:notes:145]
On May 22, 2014, the Company and a consortium of banks, entered into a syndicated senior credit facility agreement led by Bank of America (the “Bank of America Facility Agreement”). The Bank of America Facility Agreement provided for a $200.0 million credit line, comprised of a $150.0 million revolving loan facility and a $50.0 million delayed draw term loan facility.

[0001408710-21-000022:notes:146]
From time to time, the Company amended the Bank of America Facility Agreement, before repaying all outstanding amounts under the agreement and terminating such agreement on September 10, 2019.

[0001408710-21-000022:notes:147]
The most recent amendment on June 4, 2018 (i) reduced the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) refinanced the outstanding amounts under the revolving loan and term loan facilities into a $65.0 million term loan which was to be repaid in quarterly installments through the maturity date of June 04, 2023; and (iii) reduced the interest rate margins and commitment fees. The term loan bore interest, at the Company’s option, at a rate per annum equal to a LIBOR rate plus a spread of 1.50% to 2.25%, or a base rate plus a spread of 0.50% to 1.25%. During the three months ended March 27, 2020, the Company had no interest expense related to this term loan. During the nine months ended March 27, 2020, the Company recorded $0.5 million of interest expense in connection with this term loan.

[0001408710-21-000022:notes:148]
On September 10, 2019, the Company fully repaid $61.0 million in principal, accrued interest and other fees under the agreement. The early termination of this agreement did not trigger any early termination fees.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001408710-21-000022:notes:149]
Income taxes
As of March 26, 2021 and June 26, 2020, the liability for uncertain tax positions including accrued interest and penalties was $0.8 million and $1.5 million, respectively. The Company expects the estimated amount of liability associated with its uncertain tax positions to increase within the next 12 months due to interest on these positions.

[0001408710-21-000022:notes:150]
[same as prior period, unchanged from 0001408710-21-000011:notes:150]

[0001408710-21-000022:notes:151]
The effective tax rate for the Company for the three months ended March 26, 2021 and March 27, 2020 was 4.0% and 2.4%, respectively, of net income. The increase was primarily due to the fact that the Company had higher income subject to tax during the third quarter of fiscal year 2021 as compared to the same period in fiscal year 2020.

[0001408710-21-000022:notes:152]
The effective tax rate for the Company for the nine months ended March 26, 2021 and March 27, 2020 was 3.8% and 4.2%, respectively, of net income. The decrease was primarily due to the fact that the Company had lower income subject to tax during the first nine months of fiscal year 2021 as compared to the same period in fiscal year 2020.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001408710-21-000022:notes:153]
[same as prior period, unchanged from 0001408710-21-000011:notes:153]

[0001408710-21-000022:notes:154]
[same as prior period, unchanged from 0001408710-21-000011:notes:154]

[0001408710-21-000022:notes:155]
The effect of recording share-based compensation expense for the three and nine  months ended March 26, 2021 and March 27, 2020 was as follows:

[0001408710-21-000022:notes:156]
|  | Three Months Ended |  | Nine Months Ended |
| (amount in thousands) | March 26,2021 |  | March 27,2020 |  | March 26,2021 |  | March 27,2020 |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |
| Restricted share units | $ | 3,953 |  |  | $ | 4,094 |  |  | $ | 13,377 |  |  | $ | 12,678 |  |
| Performance share units | 2,911 |  |  | 2,024 |  |  | 5,365 |  |  | 5,623 |  |
| Total share-based compensation expense | 6,864 |  |  | 6,118 |  |  | 18,742 |  |  | 18,301 |  |
| Tax effect on share-based compensation expense | — |  |  | — |  |  | — |  |  | — |  |
| Net effect on share-based compensation expense | $ | 6,864 |  |  | $ | 6,118 |  |  | $ | 18,742 |  |  | $ | 18,301 |  |

[0001408710-21-000022:notes:157]
[same as prior period, unchanged from 0001408710-21-000011:notes:157]

[0001408710-21-000022:notes:158]
|  | Three Months Ended |  | Nine Months Ended |
| (amount in thousands) | March 26,2021 |  | March 27,2020 |  | March 26,2021 |  | March 27,2020 |
| Cost of revenue | $ | 1,388 |  |  | $ | 1,489 |  |  | $ | 4,805 |  |  | $ | 4,800 |  |
| Selling, general and administrative expense | 5,476 |  |  | 4,629 |  |  | 13,937 |  |  | 13,501 |  |
| Total share-based compensation expense | $ | 6,864 |  |  | $ | 6,118 |  |  | $ | 18,742 |  |  | $ | 18,301 |  |

[0001408710-21-000022:notes:159]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the three and nine  months ended March 26, 2021 and March 27, 2020.

[0001408710-21-000022:notes:160]
[same as prior period, unchanged from 0001408710-21-000011:notes:160]

[0001408710-21-000022:notes:161]
[same as prior period, unchanged from 0001408710-21-000011:notes:161]

[0001408710-21-000022:notes:162]
As of March 26, 2021, there were 234,734 restricted share units outstanding, 188,554 performance share units outstanding and 2,515,947 ordinary shares available for future grant under the 2020 Plan.

[0001408710-21-000022:notes:163]
As of March 26, 2021, there were 402,651 restricted share units outstanding and 238,474 performance share units outstanding under the 2010 Plan. No ordinary shares are available for future grant under the 2010 Plan.

[0001408710-21-000022:notes:164]
On November 2, 2017, the Company adopted the 2017 Inducement Equity Incentive Plan (the “2017 Inducement Plan”) with a reserve of 160,000 ordinary shares authorized for future issuance solely for the granting of inducement share options and equity awards to new employees. The 2017 Inducement Plan was adopted without shareholder approval in reliance on the “employment inducement exemption” provided under the New York Stock Exchange Listed Company Manual. As of March 26, 2021, there were 12,164 restricted share units outstanding and 111,347 ordinary shares available for future grant under the 2017 Inducement Plan.

[0001408710-21-000022:notes:165]
[same as prior period, unchanged from 0001408710-21-000011:notes:165]

[0001408710-21-000022:notes:166]
[same as prior period, unchanged from 0001408710-21-000011:notes:166]

[0001408710-21-000022:notes:167]
[same as prior period, unchanged from 0001408710-21-000011:notes:167]

[0001408710-21-000022:notes:168]
[same as prior period, unchanged from 0001408710-21-000011:notes:168]

[0001408710-21-000022:notes:169]
[same as prior period, unchanged from 0001408710-21-000011:notes:169]

[0001408710-21-000022:notes:170]
[same as prior period, unchanged from 0001408710-21-000011:notes:170]

[0001408710-21-000022:notes:171]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 26, 2020 | 797,757 |  |  | $ | 46.88 |  |
| Granted | 222,886 |  |  | $ | 69.97 |  |
| Issued | (347,662) |  |  | $ | 45.18 |  |
| Forfeited | (23,432) |  |  | $ | 57.71 |  |
| Balance as of March 26, 2021 | 649,549 |  |  | $ | 55.33 |  |

[0001408710-21-000022:notes:172]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 28, 2019 | 800,751 |  |  | $ | 42.48 |  |
| Granted | 343,792 |  |  | $ | 50.32 |  |
| Issued | (321,659) |  |  | $ | 40.82 |  |
| Forfeited | (28,457) |  |  | $ | 42.80 |  |
| Balance as of March 27, 2020 | 794,427 |  |  | $ | 46.54 |  |

[0001408710-21-000022:notes:173]
[same as prior period, unchanged from 0001408710-21-000011:notes:173]

[0001408710-21-000022:notes:174]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 26, 2020 | 440,140 |  |  | $ | 48.37 |  |
| Granted | 184,718 |  |  | $ | 69.85 |  |
| Issued | (82,185) |  |  | $ | 48.02 |  |
| Forfeited | (115,645) |  |  | $ | 48.02 |  |
| Balance as of March 26, 2021 | 427,028 |  |  | $ | 57.82 |  |

[0001408710-21-000022:notes:175]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 28, 2019 | 548,500 |  |  | $ | 40.97 |  |
| Granted | 242,310 |  |  | $ | 48.65 |  |
| Issued | — |  |  | — |  |
| Forfeited | (350,670) |  |  | $ | 36.99 |  |
| Balance as of March 27, 2020 | 440,140 |  |  | $ | 48.37 |  |

[0001408710-21-000022:notes:176]
[same as prior period, unchanged from 0001408710-21-000011:notes:176]

[0001408710-21-000022:notes:177]
As of March 26, 2021, there was $13.2 million and $9.8 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.4 years and 1.2 years, respectively.

[0001408710-21-000022:notes:178]
For the nine months ended March 26, 2021 and March 27, 2020, the Company withheld an aggregate of 160,648 shares and 91,481 shares, respectively, upon the vesting of restricted share units, based upon the closing share price on the vesting date to settle employee obligations for the applicable income and other employment taxes. For the nine months ended March 26, 2021 and March 27, 2020, the Company then remitted cash of $11.4 million and $4.7 million, respectively, to the appropriate taxing authorities, and presented it as a financing activity within the unaudited condensed consolidated statements of cash flows. The payment was recorded as a reduction of additional paid-in capital.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001408710-21-000022:notes:179]
[same as prior period, unchanged from 0001408710-21-000011:notes:179]

[0001408710-21-000022:notes:180]
[same as prior period, unchanged from 0001408710-21-000011:notes:180]

[0001408710-21-000022:notes:181]
For the three and nine  months ended March 26, 2021, Fabrinet issued 43,098 and 269,199 ordinary shares upon the vesting of restricted share units, net of shares withheld.

[0001408710-21-000022:notes:182]
For the three and nine  months ended March 27, 2020, Fabrinet issued 52,041 and 230,178 ordinary shares upon the vesting of restricted share units, net of shares withheld.

[0001408710-21-000022:notes:183]
[same as prior period, unchanged from 0001408710-21-000011:notes:183]

[0001408710-21-000022:notes:184]
[same as prior period, unchanged from 0001408710-21-000011:notes:184]

[0001408710-21-000022:notes:185]
In August 2017, the Company’s board of directors approved a share repurchase program to permit the Company to repurchase up to $30.0 million worth of its issued and outstanding ordinary shares in the open market in accordance with applicable rules and regulations. In February 2018, May 2019 and August 2020, the Company’s board of directors approved an increase of $30.0 million, $50.0 million and $58.5 million, respectively, to the original share repurchase authorization, bringing the aggregate authorization to $168.5 million. During the three months ended March 26, 2021, the Company repurchased 15,354 shares under the program at an average price per share of $80.64, totaling $1.2 million. During the nine months ended March 26, 2021, the Company repurchased 116,903 shares under the program at an average price per share of $71.09, totaling $8.3 million. As of March 26, 2021, the Company had a remaining authorization to purchase up to an additional $91.7 million worth of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001408710-21-000022:notes:186]
Accumulated other comprehensive income (loss)
The changes in AOCI for the nine months ended March 26, 2021 and March 27, 2020 were as follows:

[0001408710-21-000022:notes:187]
| (amount in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 26, 2020 | $ | 1,490 |  |  | $ | 602 |  |  | $ | (2,009) |  |  | $ | (1,230) |  |  | $ | (1,147) |  |
| Other comprehensive income before reclassification adjustment | (1,116) |  |  | (4,093) |  |  | — |  |  | 547 |  |  | (4,662) |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | 179 |  |  | (1,730) |  |  | 421 |  |  | — |  |  | (1,130) |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | $ | (937) |  |  | $ | (5,823) |  |  | $ | 421 |  |  | $ | 547 |  |  | $ | (5,792) |  |
| Balance as of March 26, 2021 | $ | 553 |  |  | $ | (5,221) |  |  | $ | (1,588) |  |  | $ | (683) |  |  | $ | (6,939) |  |

[0001408710-21-000022:notes:188]
| (amount in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 28, 2019 | $ | 952 |  |  | $ | 32 |  |  | $ | (2,537) |  |  | $ | (833) |  |  | $ | (2,386) |  |
| Other comprehensive income before reclassification adjustment | (1,310) |  |  | (7,565) |  |  | 478 |  |  | (353) |  |  | (8,750) |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | (93) |  |  | 846 |  |  | — |  |  | — |  |  | 753 |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | $ | (1,403) |  |  | $ | (6,719) |  |  | $ | 478 |  |  | $ | (353) |  |  | $ | (7,997) |  |
| Balance as of March 27, 2020 | $ | (451) |  |  | $ | (6,687) |  |  | $ | (2,059) |  |  | $ | (1,186) |  |  | $ | (10,383) |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001408710-21-000022:notes:189]
Commitments and contingencies
Letter of credit and Bank guarantees

[0001408710-21-000022:notes:190]
As of March 26, 2021, the Company had no outstanding standby letter of credit.

[0001408710-21-000022:notes:191]
As of June 26, 2020, the Company had one outstanding standby letter of credit of 6.0 million Euros related to the Company’s support of a customer’s transfer of certain manufacturing operations from Berlin, Germany to the Company’s facilities in Thailand. The standby letter of credit was backed by cash collateral of $7.4 million. This standby letter of credit expired on December 31, 2020 and the corresponding cash collateral was released in January 2021.

[0001408710-21-000022:notes:192]
As of March 26, 2021 and June 26, 2020, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business expenses totaling to $1.6 million or Thai Baht 50.2 million and there were other bank guarantees given by a bank on behalf of our subsidiaries in the PRC and the U.K. to support their operations. As of March 26, 2021, the Company had an outstanding bank guarantee of its subsidiary in the PRC to support the subsidiary's operations totaling Renminbi 1.0 million. The bank guarantee was backed by cash collateral of $0.2 million. The bank guarantee given on behalf of our subsidiaries in the U.K. was not material. As of June 26, 2020, these bank guarantees were immaterial.

[0001408710-21-000022:notes:193]
Purchase obligations

[0001408710-21-000022:notes:194]
Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001408710-21-000022:notes:195]
As of March 26, 2021, the Company had a purchase obligation and other commitments to third parties of $661.2 million.

[0001408710-21-000022:notes:196]
Capital expenditure

[0001408710-21-000022:notes:197]
In December 2020, the Company entered into a construction contract with a local contractor for construction of a new manufacturing building at the Company’s Chonburi campus. The contract price is approximately $50.3 million.

[0001408710-21-000022:notes:198]
As of March 26, 2021, the Company had a purchase obligation and other commitments to third parties of $62.1 million.

[0001408710-21-000022:notes:199]
Indemnification of directors and officers

[0001408710-21-000022:notes:200]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001408710-21-000022:notes:201]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001408710-21-000022:notes:202]
Business segments and geographic information
Operating segments are defined as components of an enterprise for which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. The Company’s chief operating decision maker is Fabrinet’s Chief Executive Officer. As of March 26, 2021, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001408710-21-000022:notes:203]
[same as prior period, unchanged from 0001408710-21-000011:notes:202]

[0001408710-21-000022:notes:204]
The following table presents long-lived assets by the country in which they are based:

[0001408710-21-000022:notes:205]
| (amount in thousands) |  | March 26,2021 |  | June 26,2020 |
| Long-Lived Assets: |  |  |  |  |
| Thailand |  | $ | 178,191 |  |  | $ | 175,738 |  |
| U.S. |  | 28,017 |  |  | 29,507 |  |
| China |  | 14,426 |  |  | 14,476 |  |
| Israel |  | 5,314 |  |  | 5,224 |  |
| U.K. |  | 2,417 |  |  | 2,956 |  |
| Cayman Islands |  | 402 |  |  | 373 |  |
|  |  | $ | 228,767 |  |  | $ | 228,274 |  |

[0001408710-21-000022:notes:206]
[same as prior period, unchanged from 0001408710-21-000011:notes:204]

[0001408710-21-000022:notes:207]
The Company had three customers that each contributed to 10% or more of the Company's total trade accounts receivable as of March 26, 2021 and June 26, 2020.
