# FN MD&A — 0001408710-26-000008


## mdna

[0001408710-26-000008:mdna:1]
[same as prior period, unchanged from 0001408710-25-000056:mdna:1]

[0001408710-26-000008:mdna:2]
[same as prior period, unchanged from 0001408710-25-000056:mdna:2]

[0001408710-26-000008:mdna:3]
[same as prior period, unchanged from 0001408710-25-000056:mdna:3]

[0001408710-26-000008:mdna:4]
[same as prior period, unchanged from 0001408710-25-000056:mdna:4]

[0001408710-26-000008:mdna:5]
•our expectation that the portion of our revenues attributable to customers in regions outside of North America for the remainder of fiscal year 2026 will be in line with the portion of revenues attributable to such customers during the six months ended December 26, 2025;

[0001408710-26-000008:mdna:6]
[same as prior period, unchanged from 0001408710-25-000056:mdna:6]

[0001408710-26-000008:mdna:7]
[same as prior period, unchanged from 0001408710-25-000056:mdna:7]

[0001408710-26-000008:mdna:8]
[same as prior period, unchanged from 0001408710-25-000056:mdna:8]

[0001408710-26-000008:mdna:9]
[same as prior period, unchanged from 0001408710-25-000056:mdna:9]

[0001408710-26-000008:mdna:10]
[same as prior period, unchanged from 0001408710-25-000056:mdna:10]

[0001408710-26-000008:mdna:11]
[same as prior period, unchanged from 0001408710-25-000056:mdna:11]

[0001408710-26-000008:mdna:12]
[same as prior period, unchanged from 0001408710-25-000056:mdna:12]

[0001408710-26-000008:mdna:13]
[same as prior period, unchanged from 0001408710-25-000056:mdna:13]

[0001408710-26-000008:mdna:14]
[same as prior period, unchanged from 0001408710-25-000056:mdna:14]

[0001408710-26-000008:mdna:15]
[same as prior period, unchanged from 0001408710-25-000056:mdna:15]

[0001408710-26-000008:mdna:16]
[same as prior period, unchanged from 0001408710-25-000056:mdna:16]

[0001408710-26-000008:mdna:17]
[same as prior period, unchanged from 0001408710-25-000056:mdna:17]

[0001408710-26-000008:mdna:18]
[same as prior period, unchanged from 0001408710-25-000056:mdna:18]

[0001408710-26-000008:mdna:19]
[same as prior period, unchanged from 0001408710-25-000056:mdna:19]

[0001408710-26-000008:mdna:20]
[same as prior period, unchanged from 0001408710-25-000056:mdna:20]

[0001408710-26-000008:mdna:21]
[same as prior period, unchanged from 0001408710-25-000056:mdna:21]

[0001408710-26-000008:mdna:22]
[same as prior period, unchanged from 0001408710-25-000056:mdna:22]

[0001408710-26-000008:mdna:23]
[same as prior period, unchanged from 0001408710-25-000056:mdna:23]

[0001408710-26-000008:mdna:24]
[same as prior period, unchanged from 0001408710-25-000056:mdna:24]

[0001408710-26-000008:mdna:25]
[same as prior period, unchanged from 0001408710-25-000056:mdna:25]

[0001408710-26-000008:mdna:26]
[same as prior period, unchanged from 0001408710-25-000056:mdna:26]

[0001408710-26-000008:mdna:27]
The percentage of our revenues generated from a bill-to location outside of North America decreased from 55.3% in the three months ended December 27, 2024 to 53.1% in the three months ended December 26, 2025, primarily because of an increase in revenue from customers in the United States.

[0001408710-26-000008:mdna:28]
The percentage of our revenues generated from a bill-to location outside of North America decreased from 58.4% in the six months ended December 27, 2024 to 54.9% in the six months ended December 26, 2025, primarily because of an increase in revenue from customers in the United States.

[0001408710-26-000008:mdna:29]
Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside North America for the remainder of fiscal year 2026 will be in line with the portion of revenues attributable to such customers during the six months ended December 26, 2025.

[0001408710-26-000008:mdna:30]
[same as prior period, unchanged from 0001408710-25-000056:mdna:29]

[0001408710-26-000008:mdna:31]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26, 2025 |  | December 27, 2024 |  | December 26, 2025 |  | December 27, 2024 |
| North America | 46.9 | % |  | 44.7 | % |  | 45.1 | % |  | 41.6 | % |
| Asia-Pacific and others | 43.4 |  |  | 47.3 |  |  | 45.2 |  |  | 50.7 |  |
| Europe | 9.7 |  |  | 8.0 |  |  | 9.7 |  |  | 7.7 |  |
|  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001408710-26-000008:mdna:32]
[same as prior period, unchanged from 0001408710-25-000056:mdna:31]

[0001408710-26-000008:mdna:33]
[same as prior period, unchanged from 0001408710-25-000056:mdna:32]

[0001408710-26-000008:mdna:34]
[same as prior period, unchanged from 0001408710-25-000056:mdna:33]

[0001408710-26-000008:mdna:35]
[same as prior period, unchanged from 0001408710-25-000056:mdna:34]

[0001408710-26-000008:mdna:36]
A second significant element of our cost of revenues is employee costs, including indirect employee costs related to design, configuration and optimization of manufacturing processes for our customers, quality testing, materials testing and other engineering services, and direct costs related to our manufacturing employees. Direct employee costs include employee salaries, insurance and benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a lesser extent, costs to recruit, train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand and the PRC, the fluctuation of the Thai baht and RMB against our functional currency, the U.S. dollar, and our ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention and asset utilization.

[0001408710-26-000008:mdna:37]
[same as prior period, unchanged from 0001408710-25-000056:mdna:36]

[0001408710-26-000008:mdna:38]
[same as prior period, unchanged from 0001408710-25-000056:mdna:37]

[0001408710-26-000008:mdna:39]
[same as prior period, unchanged from 0001408710-25-000056:mdna:38]

[0001408710-26-000008:mdna:40]
[same as prior period, unchanged from 0001408710-25-000056:mdna:39]

[0001408710-26-000008:mdna:41]
[same as prior period, unchanged from 0001408710-25-000056:mdna:40]

[0001408710-26-000008:mdna:42]
[same as prior period, unchanged from 0001408710-25-000056:mdna:41]

[0001408710-26-000008:mdna:43]
[same as prior period, unchanged from 0001408710-25-000056:mdna:42]

[0001408710-26-000008:mdna:44]
[same as prior period, unchanged from 0001408710-25-000056:mdna:43]

[0001408710-26-000008:mdna:45]
[same as prior period, unchanged from 0001408710-25-000056:mdna:44]

[0001408710-26-000008:mdna:46]
|  | As of December 26, 2025 |  | As of June 27, 2025 |
| (in thousands, except percentages) | ForeignCurrency |  | $ |  | % |  | ForeignCurrency |  | $ |  | % |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 953,442 |  |  | 30,687 |  |  | 69.2 | % |  | 1,812,680 |  |  | 55,689 |  |  | 86.3 | % |
| RMB | 78,323 |  |  | 11,132 |  |  | 25.1 |  |  | 43,637 |  |  | 6,092 |  |  | 9.4 |  |
| GBP | 1,886 |  |  | 2,548 |  |  | 5.7 |  |  | 2,031 |  |  | 2,790 |  |  | 4.3 |  |
| Total |  |  | $ | 44,367 |  |  | 100.0 | % |  |  |  | $ | 64,571 |  |  | 100.0 | % |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 4,977,955 |  |  | 160,217 |  |  | 91.7 | % |  | 4,434,661 |  |  | 136,242 |  |  | 91.5 | % |
| RMB | 101,029 |  |  | 14,359 |  |  | 8.2 |  |  | 89,583 |  |  | 12,507 |  |  | 8.4 |  |
| GBP | 132 |  |  | 179 |  |  | 0.1 |  |  | 106 |  |  | 146 |  |  | 0.1 |  |
| Total |  |  | $ | 174,755 |  |  | 100.0 | % |  |  |  | $ | 148,895 |  |  | 100.0 | % |

[0001408710-26-000008:mdna:47]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable, accrued employee benefits and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of December 26, 2025, there was $200.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 27, 2025, there was $165.0 million of foreign currency forward contracts outstanding on the Thai baht payables.

[0001408710-26-000008:mdna:48]
The RMB assets represent cash and cash equivalents, trade accounts receivable, other receivables, and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable, accrued payroll, bonus and related expenses, and other payables. As of December 26, 2025 and June 27, 2025, we did not have any derivative contracts denominated in RMB.

[0001408710-26-000008:mdna:49]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable, accrued expenses, and other payables. As of December 26, 2025 and June 27, 2025, we did not have any derivative contracts denominated in GBP.

[0001408710-26-000008:mdna:50]
For the three months ended December 26, 2025 and December 27, 2024, we recorded an unrealized gain of $1.2 million and unrealized loss of $5.1 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-26-000008:mdna:51]
For the six months ended December 26, 2025 and December 27, 2024, we recorded an unrealized loss of $0.1 million and $1.0 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-26-000008:mdna:52]
[same as prior period, unchanged from 0001408710-25-000056:mdna:50]

[0001408710-26-000008:mdna:53]
[same as prior period, unchanged from 0001408710-25-000056:mdna:51]

[0001408710-26-000008:mdna:54]
[same as prior period, unchanged from 0001408710-25-000056:mdna:52]

[0001408710-26-000008:mdna:55]
[same as prior period, unchanged from 0001408710-25-000056:mdna:53]

[0001408710-26-000008:mdna:56]
[same as prior period, unchanged from 0001408710-25-000056:mdna:54]

[0001408710-26-000008:mdna:57]
[same as prior period, unchanged from 0001408710-25-000056:mdna:55]

[0001408710-26-000008:mdna:58]
[same as prior period, unchanged from 0001408710-25-000056:mdna:56]

[0001408710-26-000008:mdna:59]
[same as prior period, unchanged from 0001408710-25-000056:mdna:57]

[0001408710-26-000008:mdna:60]
[same as prior period, unchanged from 0001408710-25-000056:mdna:58]

[0001408710-26-000008:mdna:61]
[same as prior period, unchanged from 0001408710-25-000056:mdna:59]

[0001408710-26-000008:mdna:62]
[same as prior period, unchanged from 0001408710-25-000056:mdna:60]

[0001408710-26-000008:mdna:63]
[same as prior period, unchanged from 0001408710-25-000056:mdna:61]

[0001408710-26-000008:mdna:64]
[same as prior period, unchanged from 0001408710-25-000056:mdna:62]

[0001408710-26-000008:mdna:65]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption on income generated from projects to manufacture certain products at our Chonburi campus is currently available to us through June 2026. Preferential tax treatment is available to us for products manufactured at our Chonburi campus Building 9, where income generated will be tax exempt through 2031, capped at our actual investment amount. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted. Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001408710-26-000008:mdna:66]
As of December 26, 2025, the corporate income tax rates for our subsidiaries in the PRC, the U.S., the U.K. and Israel are 25%, 21%, 25% and 23%, respectively.

[0001408710-26-000008:mdna:67]
[same as prior period, unchanged from 0001408710-25-000056:mdna:66]

[0001408710-26-000008:mdna:68]
[same as prior period, unchanged from 0001408710-25-000056:mdna:67]

[0001408710-26-000008:mdna:69]
[same as prior period, unchanged from 0001408710-25-000056:mdna:68]

[0001408710-26-000008:mdna:70]
[same as prior period, unchanged from 0001408710-25-000056:mdna:69]

[0001408710-26-000008:mdna:71]
[same as prior period, unchanged from 0001408710-25-000056:mdna:70]

[0001408710-26-000008:mdna:72]
[same as prior period, unchanged from 0001408710-25-000056:mdna:71]

[0001408710-26-000008:mdna:73]
| (in thousands) | Three Months Ended |  | Six Months Ended |
| December 26,2025 |  | December 27,2024 |  | December 26,2025 |  | December 27,2024 |
| Revenues | $ | 1,132,888 |  |  | $ | 833,608 |  |  | $ | 2,111,016 |  |  | $ | 1,637,836 |  |
| Cost of revenues | (995,206) |  |  | (732,759) |  |  | (1,856,895) |  |  | (1,437,961) |  |
| Gross profit | 137,682 |  |  | 100,849 |  |  | 254,121 |  |  | 199,875 |  |
| Selling, general and administrative expenses | (23,281) |  |  | (21,206) |  |  | (45,527) |  |  | (43,237) |  |
| Restructuring and other related costs | — |  |  | (46) |  |  | — |  |  | (103) |  |
| Operating income | 114,401 |  |  | 79,597 |  |  | 208,594 |  |  | 156,535 |  |
| Interest income | 8,555 |  |  | 11,314 |  |  | 17,972 |  |  | 22,247 |  |
| Foreign exchange gain (loss), net | (3,214) |  |  | 4,042 |  |  | (5,274) |  |  | (3,053) |  |
| Other income (expense), net | (17) |  |  | (62) |  |  | (139) |  |  | (81) |  |
| Income before income taxes | 119,725 |  |  | 94,891 |  |  | 221,153 |  |  | 175,648 |  |
| Income tax expense | (7,097) |  |  | (8,255) |  |  | (12,599) |  |  | (11,618) |  |
| Net income | 112,628 |  |  | 86,636 |  |  | 208,554 |  |  | 164,030 |  |
| Other comprehensive income (loss), net of tax | 7,107 |  |  | (9,509) |  |  | 4,145 |  |  | 5,490 |  |
| Net comprehensive income | $ | 119,735 |  |  | $ | 77,127 |  |  | $ | 212,699 |  |  | $ | 169,520 |  |

[0001408710-26-000008:mdna:74]
[same as prior period, unchanged from 0001408710-25-000056:mdna:73]

[0001408710-26-000008:mdna:75]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26,2025 |  | December 27,2024 |  | December 26,2025 |  | December 27,2024 |
| Revenues | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenues | (87.8) |  |  | (87.9) |  |  | (88.0) |  |  | (87.8) |  |
| Gross profit | 12.2 |  |  | 12.1 |  |  | 12.0 |  |  | 12.2 |  |
| Selling, general and administrative expenses | (2.1) |  |  | (2.6) |  |  | (2.1) |  |  | (2.6) |  |
| Restructuring and other related costs | — |  |  | (0.0) |  |  | — |  |  | (0.0) |  |
| Operating income | 10.1 |  |  | 9.5 |  |  | 9.9 |  |  | 9.6 |  |
| Interest income | 0.8 |  |  | 1.4 |  |  | 0.9 |  |  | 1.3 |  |
| Foreign exchange gain (loss), net | (0.3) |  |  | 0.5 |  |  | (0.3) |  |  | (0.2) |  |
| Other income (expense), net | (0.0) |  |  | (0.0) |  |  | (0.0) |  |  | (0.0) |  |
| Income before income taxes | 10.6 |  |  | 11.4 |  |  | 10.5 |  |  | 10.7 |  |
| Income tax expense | (0.6) |  |  | (1.0) |  |  | (0.6) |  |  | (0.7) |  |
| Net income | 10.0 |  |  | 10.4 |  |  | 9.9 |  |  | 10.0 |  |
| Other comprehensive income (loss), net of tax | 0.6 |  |  | (1.1) |  |  | 0.2 |  |  | 0.3 |  |
| Net comprehensive income | 10.6 | % |  | 9.3 | % |  | 10.1 | % |  | 10.3 | % |

[0001408710-26-000008:mdna:76]
36

[0001408710-26-000008:mdna:77]
[same as prior period, unchanged from 0001408710-25-000056:mdna:76]

[0001408710-26-000008:mdna:78]
| (in thousands, except percentages) | Three Months EndedDecember 26, 2025 |  | As a % of TotalRevenues |  | Six Months EndedDecember 26, 2025 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Telecom | $ | 412,248 |  |  |  |  | $ | 747,968 |  |  |  |
| Datacom | 278,142 |  |  |  |  | 551,238 |  |  |  |
| Datacenter interconnect (1) | 142,200 |  |  |  |  | 280,280 |  |  |  |
| Total revenue - Optical communications | $ | 832,590 |  |  | 73.5 | % |  | $ | 1,579,486 |  |  | 74.8 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 116,956 |  |  |  |  | $ | 238,904 |  |  |  |
| Industrial laser | 41,432 |  |  |  |  | 81,111 |  |  |  |
| High-performance computing (2) | 85,556 |  |  |  |  | 100,959 |  |  |  |
| Others | 56,354 |  |  |  |  | 110,556 |  |  |  |
| Total revenue - Non-optical communications | $ | 300,298 |  |  | 26.5 | % |  | $ | 531,530 |  |  | 25.2 | % |
| Total revenue | $ | 1,132,888 |  |  | 100.0 | % |  | $ | 2,111,016 |  |  | 100.0 | % |

[0001408710-26-000008:mdna:79]
| (in thousands, except percentages) | Three Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 299,101 |  |  |  |  | $ | 627,982 |  |  |  |
| Telecom | 248,010 |  |  |  |  | 473,637 |  |  |  |
| Datacenter interconnect (1) | 100,039 |  |  |  |  | 171,846 |  |  |  |
| Total revenue - Optical communications | $ | 647,150 |  |  | 77.6 | % |  | $ | 1,273,465 |  |  | 77.8 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 104,247 |  |  |  |  | $ | 206,988 |  |  |  |
| Industrial laser | 37,542 |  |  |  |  | 72,868 |  |  |  |
| Others | 44,669 |  |  |  |  | 84,515 |  |  |  |
| Total revenue - Non-optical communications | $ | 186,458 |  |  | 22.4 | % |  | $ | 364,371 |  |  | 22.2 | % |
| Total revenue | $ | 833,608 |  |  | 100.0 | % |  | $ | 1,637,836 |  |  | 100.0 | % |

[0001408710-26-000008:mdna:80]
[same as prior period, unchanged from 0001408710-25-000056:mdna:78]

[0001408710-26-000008:mdna:81]
[same as prior period, unchanged from 0001408710-25-000056:mdna:79]

[0001408710-26-000008:mdna:82]
Comparison of Three and Six Months Ended December 26, 2025 with Three and Six Months Ended December 27, 2024

[0001408710-26-000008:mdna:83]
[same as prior period, unchanged from 0001408710-25-000056:mdna:81]

[0001408710-26-000008:mdna:84]
Our revenues increased by $299.3 million, or 35.9%, to $1,132.9 million for the three months ended December 26, 2025, compared with $833.6 million for the three months ended December 27, 2024. This increase was primarily due to an increase in our key customers’ demand for both optical communications products and non-optical communications products. Revenues from optical communications products, which represented $832.6 million, or 73.5%, of our revenues for the three months ended December 26, 2025, increased by $185.4 million, or 28.7%, compared to the same period in the prior fiscal year, mainly due to an increase in revenues from telecommunication products and datacenter interconnect products, and partially offset with a decrease in revenues from data communication products during the three months ended December 26, 2025. Revenues from non-optical communications products, which represented $300.3 million, or 26.5%, of our revenues for the three months ended December 26, 2025, increased by $113.8 million, or 61.1%, compared to the same period in the prior fiscal year, primarily due to high demand for high-performance computing, and growth in automotive revenue, as short-term inventory absorption issues have substantially subsided.

[0001408710-26-000008:mdna:85]
Our revenues increased by $473.2 million, or 28.9%, to $2,111.0 million for the six months ended December 26, 2025, compared with $1,637.8 million for the six months ended December 27, 2024. This increase was primarily due to an increase in our key customers’ demand for both optical communications products and non-optical communications products. Revenues from optical communications products, which represented $1,579.5 million, or 74.8%, of our revenues for the six months ended December 26, 2025, increased by $306.0 million, or 24.0%, compared to the same period in the prior fiscal year, mainly due to an increase in revenues from telecommunication products and datacenter interconnect products, and partially offset with a decrease in revenues from data communication products during the six months ended December 26, 2025. Revenues from non-optical communications products, which represented $531.5 million, or 25.2%, of our revenues for the six months ended December 26, 2025, increased by $167.2 million, or 45.9%, compared to the same period in the prior fiscal year, primarily due to high demand for high-performance computing, and growth in automotive revenue, as short-term inventory absorption issues have substantially subsided.

[0001408710-26-000008:mdna:86]
[same as prior period, unchanged from 0001408710-25-000056:mdna:83]

[0001408710-26-000008:mdna:87]
Our cost of revenues increased by $262.4 million, or 35.8%, to $995.2 million, or 87.8% of revenues, for the three months ended December 26, 2025, compared with $732.8 million, or 87.9% of revenues, for the three months ended December 27, 2024. The increase was in line with the increase in sales volume.

[0001408710-26-000008:mdna:88]
Our cost of revenues increased by $418.9 million, or 29.1%, to $1,856.9 million, or 88.0% of revenues, for the six months ended December 26, 2025, compared with $1,438.0 million, or 87.8% of revenues, for the six months ended December 27, 2024. This increase was in line with the increase in sales volume.

[0001408710-26-000008:mdna:89]
[same as prior period, unchanged from 0001408710-25-000056:mdna:85]

[0001408710-26-000008:mdna:90]
Our gross profit increased by $36.9 million, or 36.6%, to $137.7 million, or 12.2% of revenues, for the three months ended December 26, 2025, compared with $100.8 million, or 12.1% of revenues, for the three months ended December 27, 2024. The increase was primarily due to an increase in sales volume.

[0001408710-26-000008:mdna:91]
Our gross profit increased by $54.2 million, or 27.1%, to $254.1 million, or 12.0% of revenues, for the six months ended December 26, 2025, compared with $199.9 million, or 12.2% of revenues, for the six months ended December 27, 2024. The increase was primarily due to an increase in sales volume.

[0001408710-26-000008:mdna:92]
[same as prior period, unchanged from 0001408710-25-000056:mdna:87]

[0001408710-26-000008:mdna:93]
Our SG&A expenses increased by $2.1 million, or 9.9%, to $23.3 million, or 2.1% of revenues, for the three months ended December 26, 2025, compared with $21.2 million, or 2.6% of revenues, for the three months ended December 27, 2024. The increase was primarily due to (1) a net increase in the allowance for expected credit losses of $0.6 million, (2) an increase in information technology related expenses of $0.5 million, mainly from network, security system and new hardware costs, (3) an increase in a net realized loss from financial instruments of $0.5 million, (4) an increase in executive compensation related expenses of $0.4 million, and (5) an increase in share-based compensation expenses of $0.4 million, offset by a decrease from the true-up of other employee benefits of $0.3 million.

[0001408710-26-000008:mdna:94]
Our SG&A expenses increased by $2.3 million, or 5.3%, to $45.5 million, or 2.1% of revenues, for the six months ended December 26, 2025, compared with $43.2 million, or 2.6% of revenues, for the six months ended December 27, 2024. The increase was primarily due to (1) an increase in information technology related expenses of $1.1 million, mainly from network, security system and new hardware costs, (2) an increase in executive compensation related expenses of $0.7 million, (3) an increase in consultant expenses of $0.4 million, (4) a net increase in the allowance for expected credit losses of $0.3 million, (5) an increase in a net realized loss from financial instruments of $0.3 million, and (6) an increase in share-based compensation expenses of $0.2 million, offset by a decrease in severance expenses of $0.7 million.

[0001408710-26-000008:mdna:95]
[same as prior period, unchanged from 0001408710-25-000056:mdna:89]

[0001408710-26-000008:mdna:96]
Our operating income increased by $34.8 million, or 43.7%, to $114.4 million, or 10.1% of revenues, for the three months ended December 26, 2025, compared with $79.6 million, or 9.5% of revenues, for the three months ended December 27, 2024. The increase was primarily due to an increase in revenues.

[0001408710-26-000008:mdna:97]
Our operating income increased by $52.1 million, or 33.3%, to $208.6 million, or 9.9% of revenues, for the six months ended December 26, 2025, compared with $156.5 million, or 9.6% of revenues, for the six months ended December 27, 2024. The increase was primarily due to an increase in revenues.

[0001408710-26-000008:mdna:98]
[same as prior period, unchanged from 0001408710-25-000056:mdna:91]

[0001408710-26-000008:mdna:99]
Our interest income decreased by $2.7 million, or 23.9%, to $8.6 million, or 0.8% of revenues, for the three months ended December 26, 2025, compared with $11.3 million, or 1.4% of revenues, for the three months ended December 27, 2024. The decrease was primarily due to a decrease in average cash balance and short-term investment and a decrease of weighted average interest income rate following to global interest rate trend from 4.2% to 3.8% during the three months ended December 26, 2025 compared to the same period in the prior fiscal year.

[0001408710-26-000008:mdna:100]
Our interest income decreased by $4.2 million, or 18.9%, to $18.0 million, or 0.9% of revenues, for the six months ended December 26, 2025, compared with $22.2 million, or 1.3% of revenues, for the six months ended December 27, 2024. The decrease was primarily due to a decrease of weighted average interest income rate following to global interest rate trend from 4.4% to 3.9% during the six months ended December 26, 2025 compared to same period in the prior fiscal year.

[0001408710-26-000008:mdna:101]
[same as prior period, unchanged from 0001408710-25-000056:mdna:93]

[0001408710-26-000008:mdna:102]
We recorded foreign exchange loss, net of $3.2 million, or 0.3% of revenues, for the three months ended December 26, 2025, compared with foreign exchange gain, net of $4.0 million, or 0.5% of revenues, for the three months ended December 27, 2024. The foreign exchange loss was mainly due to (1) unrealized loss from revaluation of outstanding Thai baht assets and liabilities of $12.3 million, (2) unrealized loss from revaluation of currencies other than Thai baht of $1.6 million, and (3) higher realized loss from payment/receipt of $0.1 million, offset by (1) unrealized gain from mark-to-market forward contracts of $6.3 million, and (2) lower foreign exchange loss, totaling $0.5 million from our subsidiaries in the PRC and the U.K.

[0001408710-26-000008:mdna:103]
We recorded foreign exchange loss, net of $5.3 million, or 0.3% of revenues, for the six months ended December 26, 2025, compared with foreign exchange loss, net of $3.1 million, or 0.2% or revenues, for the six months ended December 27, 2024. The increase in foreign exchange loss was mainly due to (1) higher in realized loss from payment/receipt of $1.5 million, (2) higher unrealized loss from revaluation of outstanding Thai baht assets and liabilities of $1.4 million, and (3) foreign exchange loss, totaling $0.2 million from our subsidiaries in the PRC and the U.K, offset by lower unrealized loss from mark-to-market forward contracts of $0.9 million.

[0001408710-26-000008:mdna:104]
[same as prior period, unchanged from 0001408710-25-000056:mdna:95]

[0001408710-26-000008:mdna:105]
We recorded income before income taxes of $119.7 million for the three months ended December 26, 2025, compared with $94.9 million for the three months ended December 27, 2024.

[0001408710-26-000008:mdna:106]
We recorded income before income taxes of $221.2 million for the six months ended December 26, 2025, compared with $175.6 million for the six months ended December 27, 2024.

[0001408710-26-000008:mdna:107]
[same as prior period, unchanged from 0001408710-25-000056:mdna:97]

[0001408710-26-000008:mdna:108]
Our provision for income tax reflects effective tax rates of 5.9% and 8.7% for the three months ended December 26, 2025 and December 27, 2024, respectively. The decrease was due to an increase in income not subject to tax.

[0001408710-26-000008:mdna:109]
Our provision for income tax reflects effective tax rates of 5.7% and 6.6% for the six months ended December 26, 2025 and December 27, 2024, respectively. The decrease was due to an increase in income not subject to tax.

[0001408710-26-000008:mdna:110]
[same as prior period, unchanged from 0001408710-25-000056:mdna:99]

[0001408710-26-000008:mdna:111]
We recorded net income of $112.6 million, or 10.0% of revenues, for the three months ended December 26, 2025, compared with $86.6 million, or 10.4% of revenues, for the three months ended December 27, 2024.

[0001408710-26-000008:mdna:112]
We recorded net income of $208.6 million, or 9.9% of revenues, for the six months ended December 26, 2025, compared with $164.0 million, or 10.0% of revenues, for the six months ended December 27, 2024.

[0001408710-26-000008:mdna:113]
[same as prior period, unchanged from 0001408710-25-000056:mdna:101]

[0001408710-26-000008:mdna:114]
We recorded other comprehensive income of $7.1 million, or 0.6% of revenues, for the three months ended December 26, 2025, compared with other comprehensive loss of $9.5 million, or 1.1% of revenues, for the three months ended December 27, 2024. The change was mainly due to (1) unrealized gain from mark-to-market of forward contracts of $14.0 million, and (2) unrealized gain from mark-to-market of available-for-sale debt securities of $3.0 million, offset by lower unrealized gain from foreign currency translation adjustment of $0.4 million.

[0001408710-26-000008:mdna:115]
We recorded other comprehensive income of $4.1 million, or 0.2% of revenues, for the six months ended December 26, 2025, compared with other comprehensive income of $5.5 million, or 0.3% of revenues, for the six months ended December 27, 2024. The change was mainly due to (1) lower unrealized gain from mark-to-market of available-for-sale debt securities of $4.7 million, and (2) unrealized loss from foreign currency translation adjustment of $0.1 million, offset by unrealized gain from mark-to-market of forward contracts of $3.4 million.

[0001408710-26-000008:mdna:116]
[same as prior period, unchanged from 0001408710-25-000056:mdna:103]

[0001408710-26-000008:mdna:117]
[same as prior period, unchanged from 0001408710-25-000056:mdna:104]

[0001408710-26-000008:mdna:118]
We primarily finance our operations through cash flow from operating activities. As of December 26, 2025 and December 27, 2024, we had cash, cash equivalents, and short-term investments of $960.8 million and $934.6 million, respectively, and no outstanding debt.

[0001408710-26-000008:mdna:119]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents was 3.8% and 3.9% for the three and six months ended December 26, 2025, respectively, and 4.2% and 4.4% for the three and six months ended December 27, 2024, respectively.

[0001408710-26-000008:mdna:120]
Our cash investments are made in accordance with an investment policy approved by the audit committee of our board of directors. In general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed income securities are primarily classified as available-for-sale and are recorded at fair value. The cost of securities sold is based on the specific identification method. Unrealized gains and losses on these securities are recorded as other comprehensive income (loss) and are reported as a separate component of shareholders’ equity.

[0001408710-26-000008:mdna:121]
We believe that our current cash and cash equivalents, short-term investments, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q. We also believe that our current manufacturing capacity is sufficient to meet our anticipated production requirements for at least the next few quarters. In February 2025, we began construction of a new manufacturing facility of approximately 2.0 million square feet at our Chonburi campus. The total expected cost of the project is approximately $132.5 million (Thai baht 4.45 billion).

[0001408710-26-000008:mdna:122]
[same as prior period, unchanged from 0001408710-25-000056:mdna:110]

[0001408710-26-000008:mdna:123]
|  | Six Months Ended |
| (in thousands) | December 26, 2025 |  | December 27, 2024 |
| Net cash provided by operating activities | $ | 148,827 |  |  | $ | 199,086 |  |
| Net cash used in investing activities | $ | (106,117) |  |  | $ | (116,074) |  |
| Net cash used in financing activities | $ | (28,702) |  |  | $ | (89,414) |  |
| Net increase(decrease) in cash, cash equivalents and restricted cash | $ | 14,008 |  |  | $ | (6,402) |  |

[0001408710-26-000008:mdna:124]
[same as prior period, unchanged from 0001408710-25-000056:mdna:112]

[0001408710-26-000008:mdna:125]
Cash provided by operating activities is net income adjusted for certain non-cash items and changes in certain assets and liabilities. The decrease in cash provided by operating activities during the six months ended December 26, 2025 as compared to the six months ended December 27, 2024 was primarily due to more efficient cash-favorable working capital changes mainly from an increase in inventories to support higher demand in the next quarter, partially offset by a decrease in trade receivables due to timing of collection and an increase in trade payables aligned with the increasing volume of inventories.

[0001408710-26-000008:mdna:126]
[same as prior period, unchanged from 0001408710-25-000056:mdna:114]

[0001408710-26-000008:mdna:127]
Investing cash flows consist primarily of investment purchases, sales, maturities, and disposals; and capital expenditures. The decrease in cash used in investing activities for the six months ended December 26, 2025 as compared to cash used in investing activities for the six months ended December 27, 2024 was primarily due to a decrease in net purchase of investment, offset by (1) an increase related to the construction of a new manufacturing building at our Chonburi campus, and (2) an increase in capital expenditures to support certain customers.

[0001408710-26-000008:mdna:128]
[same as prior period, unchanged from 0001408710-25-000056:mdna:116]

[0001408710-26-000008:mdna:129]
Financing cash flows consist primarily of repayment of long-term debt, share repurchases, and withholding tax related to net share settlement of restricted share units. The decrease in cash used in financing activities for the six months ended December 26, 2025 as compared to the six months ended December 27, 2024 was due to a decrease in share repurchases, offset by an increase in withholding tax related to net share settlement of restricted share units.

[0001408710-26-000008:mdna:130]
[same as prior period, unchanged from 0001408710-25-000056:mdna:118]

[0001408710-26-000008:mdna:131]
[same as prior period, unchanged from 0001408710-25-000056:mdna:119]
