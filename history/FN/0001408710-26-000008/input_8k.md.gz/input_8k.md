# FN 8-K — 0001408710-26-000006 filed 2026-02-02

## item codes, every 8-K on or before 2026-02-03

- 2026-02-02 0001408710-26-000006 — 2.02, 9.01
- 2025-12-12 0001408710-25-000058 — 5.07
- 2025-11-03 0001408710-25-000054 — 2.02, 9.01
- 2025-10-17 0001408710-25-000047 — 5.02, 9.01
- 2025-10-16 0001408710-25-000044 — 5.02, 9.01
- 2025-08-18 0001408710-25-000036 — 2.02, 5.02, 9.01
- 2025-05-27 0001408710-25-000027 — 5.02
- 2025-05-05 0001408710-25-000021 — 2.02, 9.01
- 2025-03-13 0001408710-25-000010 — 1.01, 3.02, 7.01, 9.01
- 2025-02-03 0001408710-25-000006 — 2.02, 9.01
- 2024-12-20 0001408710-24-000044 — 5.02
- 2024-12-13 0001408710-24-000042 — 5.07
- 2024-11-04 0001408710-24-000038 — 2.02, 9.01
- 2024-08-19 0001408710-24-000030 — 2.02, 5.02, 9.01
- 2024-06-14 0001408710-24-000023 — 5.02
- 2024-05-06 0001408710-24-000017 — 2.02, 9.01
- 2024-02-05 0001408710-24-000007 — 2.02, 9.01
- 2023-12-13 0001408710-23-000038 — 5.07
- 2023-11-06 0001408710-23-000034 — 2.02, 9.01
- 2023-08-21 0001408710-23-000026 — 2.02, 5.02, 9.01
- 2023-05-08 0001408710-23-000016 — 2.02, 5.02, 9.01
- 2023-02-06 0001408710-23-000006 — 2.02, 9.01
- 2022-12-13 0001408710-22-000062 — 5.07
- 2022-11-07 0001408710-22-000058 — 2.02, 9.01
- 2022-08-15 0001408710-22-000041 — 2.02, 5.02, 9.01
- 2022-05-02 0001408710-22-000026 — 2.02, 9.01
- 2022-01-31 0001408710-22-000016 — 2.02, 9.01
- 2022-01-19 0001408710-22-000010 — 5.02
- 2022-01-06 0001408710-22-000006 — 5.02
- 2021-12-10 0001408710-21-000051 — 5.07
- 2021-11-01 0001408710-21-000045 — 2.02, 9.01
- 2021-08-16 0001408710-21-000031 — 2.02, 5.02, 9.01
- 2021-05-03 0001408710-21-000019 — 2.02, 9.01
- 2021-02-01 0001408710-21-000008 — 2.02, 9.01
- 2020-12-11 0001193125-20-315861 — 5.07
- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2026-02-03

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001408710-26-000006:8k_2_02:1]
EX-99.1
2
fn-2026202xex991q226.htm
EX-99.1

[0001408710-26-000006:8k_2_02:2]
Document

[0001408710-26-000006:8k_2_02:3]
Exhibit 99.1

[0001408710-26-000006:8k_2_02:4]
Fabrinet Announces Second Quarter Fiscal Year 2026 Financial Results

[0001408710-26-000006:8k_2_02:5]
•Record Second Quarter Revenue and Earnings Per Share Above Guidance Ranges

[0001408710-26-000006:8k_2_02:6]
BANGKOK, Thailand – February 2, 2026 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its second fiscal quarter ended December 26, 2025.

[0001408710-26-000006:8k_2_02:7]
Seamus Grady, Chairman and Chief Executive Officer of Fabrinet, said, “We delivered an exceptional second quarter with record revenue and earnings that significantly exceeded our guidance ranges. Multiple large, key strategic programs across our business all contributed to our outstanding performance. At the same time, excellent execution and strong operating leverage generated record earnings per share that was also above our guidance range. We are confident that the same drivers that helped produce these results will extend into the third quarter, as reflected in our strong guidance.”

[0001408710-26-000006:8k_2_02:8]
Second Quarter Fiscal Year 2026 Financial Highlights

[0001408710-26-000006:8k_2_02:9]
GAAP Results

[0001408710-26-000006:8k_2_02:10]
•Revenue for the second quarter of fiscal year 2026 was $1,132.9 million, compared to $833.6 million for the second quarter of fiscal year 2025.

[0001408710-26-000006:8k_2_02:11]
•GAAP net income for the second quarter of fiscal year 2026 was $112.6 million, compared to $86.6 million for the second quarter of fiscal year 2025.

[0001408710-26-000006:8k_2_02:12]
•GAAP net income per diluted share for the second quarter of fiscal year 2026 was $3.11, compared to $2.38 for the second quarter of fiscal year 2025.

[0001408710-26-000006:8k_2_02:13]
Non-GAAP Results

[0001408710-26-000006:8k_2_02:14]
•Non-GAAP net income for the second quarter of fiscal year 2026 was $121.6 million, compared to $95.1 million for the second quarter of fiscal year 2025.

[0001408710-26-000006:8k_2_02:15]
•Non-GAAP net income per diluted share for the second quarter of fiscal year 2026 was $3.36, compared to $2.61 for the second quarter of fiscal year 2025.

[0001408710-26-000006:8k_2_02:16]
Business Outlook

[0001408710-26-000006:8k_2_02:17]
Based on information available as of February 2, 2026, Fabrinet is issuing guidance for its third fiscal quarter ending March 27, 2026, as follows:

[0001408710-26-000006:8k_2_02:18]
•Fabrinet expects third quarter revenue to be in the range of $1.15 billion to $1.20 billion.

[0001408710-26-000006:8k_2_02:19]
•GAAP net income per diluted share is expected to be in the range of $3.22 to $3.37, based on approximately 36.3 million fully diluted shares outstanding.

[0001408710-26-000006:8k_2_02:20]
•Non-GAAP net income per diluted share is expected to be in the range of $3.45 to $3.60, based on approximately 36.3 million fully diluted shares outstanding.

[0001408710-26-000006:8k_2_02:21]
Guidance for non-GAAP net income per diluted share excludes share-based compensation expenses and certain non-recurring items. A reconciliation of non-GAAP net income per diluted share to the corresponding GAAP measure is available at the end of this press release.

[0001408710-26-000006:8k_2_02:22]
Conference Call Information

[0001408710-26-000006:8k_2_02:23]
| What: |  | Fabrinet Second Quarter Fiscal Year 2026 Financial Results Call |
| When: |  | February 2, 2026 |
| Time: |  | 5:00 p.m. ET |
| Live Call and Replay: |  | https://investor.fabrinet.com/events-and-presentations/events |

[0001408710-26-000006:8k_2_02:24]
A recorded version of this webcast will be available approximately two hours after the call and accessible at http://investor.fabrinet.com. The webcast will be archived on Fabrinet’s website for a period of one year.

[0001408710-26-000006:8k_2_02:25]
About Fabrinet

[0001408710-26-000006:8k_2_02:26]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China, and Israel. For more information visit: www.fabrinet.com.

[0001408710-26-000006:8k_2_02:27]
Forward-Looking Statements

[0001408710-26-000006:8k_2_02:28]
Non-GAAP Financial Measures

[0001408710-26-000006:8k_2_02:29]
In addition to reporting financial results in accordance with GAAP, we provide investors with certain non-GAAP financial measures. These non-GAAP financial measures are in addition to, and not a substitute for or superior to, measures of financial performance prepared in accordance with GAAP. We believe these non-GAAP financial measures provide investors with useful supplemental information to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, we use some of these non-GAAP financial measures to measure company performance for the purposes of determining employee incentive plan compensation.

[0001408710-26-000006:8k_2_02:30]
Non-GAAP gross profit, non-GAAP operating profit, non-GAAP net income and non-GAAP net income per diluted share exclude: share-based compensation expenses; severance payment and others; restructuring and other related costs; and legal and litigation costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations.

[0001408710-26-000006:8k_2_02:31]
Non-GAAP free cash flow is net cash provided by (used in) operating activities, minus capital expenditures (purchase of property, plant and equipment). We use free cash flow to measure our ability to generate additional cash from our business operations.

[0001408710-26-000006:8k_2_02:32]
There are a number of limitations related to the use of these non-GAAP financial measures versus their nearest GAAP equivalents. For example, other companies may calculate non-GAAP financial measures differently or may use other measures to evaluate their performance, all of which could reduce the usefulness of our non-GAAP financial measures as tools for comparison. We urge you to review the reconciliations of our non-GAAP financial measures to the most directly comparable GAAP financial measures, and not to rely on any single financial measure to evaluate our business.

[0001408710-26-000006:8k_2_02:33]
Investor Contact:

[0001408710-26-000006:8k_2_02:34]
Garo Toomajanian

[0001408710-26-000006:8k_2_02:35]
ir@fabrinet.com

[0001408710-26-000006:8k_2_02:36]
FABRINET

[0001408710-26-000006:8k_2_02:37]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001408710-26-000006:8k_2_02:38]
| (in thousands of U.S. dollars, except share data and par value) | December 26,2025 |  | June 27,2025 |
|  | (unaudited) |  |  |
| Assets |  |  |  |
| Current assets |  |  |  |
| Cash and cash equivalents | $ | 319,855 |  |  | $ | 306,425 |  |
| Short-term investments | 640,918 |  |  | 627,819 |  |
| Trade accounts receivable, net of allowance for expected credit losses of $1,296 and $1,344, respectively | 801,671 |  |  | 758,894 |  |
| Inventories | 798,910 |  |  | 581,015 |  |
| Prepaid expenses | 33,516 |  |  | 38,476 |  |
| Other current assets | 178,931 |  |  | 116,210 |  |
| Total current assets | 2,773,801 |  |  | 2,428,839 |  |
| Non-current assets |  |  |  |
| Long-term restricted cash | 682 |  |  | — |  |
| Property, plant and equipment, net | 460,142 |  |  | 380,640 |  |
| Intangibles, net | 2,233 |  |  | 2,156 |  |
| Operating right-of-use assets | 4,888 |  |  | 5,768 |  |
| Deferred tax assets | 15,471 |  |  | 13,406 |  |
| Other non-current assets | 11,381 |  |  | 623 |  |
| Total non-current assets | 494,797 |  |  | 402,593 |  |
| Total Assets | $ | 3,268,598 |  |  | $ | 2,831,432 |  |
| Liabilities and Shareholders’ Equity |  |  |  |
| Current liabilities |  |  |  |
| Trade accounts payable | 783,681 |  |  | 637,417 |  |
| Fixed assets payable | 53,874 |  |  | 40,781 |  |
| Operating lease liabilities, current portion | 1,691 |  |  | 1,792 |  |
| Income tax payable | 7,998 |  |  | 7,939 |  |
| Accrued payroll, bonus and related expenses | 25,726 |  |  | 24,566 |  |
| Accrued expenses | 25,026 |  |  | 30,630 |  |
| Severance liabilities, current portion | 2,087 |  |  | — |  |
| Other payables | 136,534 |  |  | 66,717 |  |
| Total current liabilities | 1,036,617 |  |  | 809,842 |  |
| Non-current liabilities |  |  |  |
| Deferred tax liability | 2,359 |  |  | 1,595 |  |
| Operating lease liability, non-current portion | 3,194 |  |  | 3,679 |  |
| Severance liabilities | 32,406 |  |  | 31,225 |  |
| Other non-current liabilities | 9,236 |  |  | 3,279 |  |
| Total non-current liabilities | 47,195 |  |  | 39,778 |  |
| Total Liabilities | 1,083,812 |  |  | 849,620 |  |
| Shareholders’ equity |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of December 26, 2025 and June 27, 2025) | — |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 39,709,931 shares and 39,602,152 shares issued as of December 26, 2025 and June 27, 2025, respectively; and 35,822,444 shares and 35,728,074 shares outstanding as of December 26, 2025 and June 27, 2025, respectively) | 397 |  |  | 396 |  |
| Additional paid-in capital | 233,235 |  |  | 237,881 |  |
| Less: Treasury shares (3,887,487 shares and 3,874,078 shares as of December 26, 2025 and June 27, 2025, respectively) | (365,136) |  |  | (360,056) |  |
| Accumulated other comprehensive income (loss) | 14,439 |  |  | 10,294 |  |
| Retained earnings | 2,301,851 |  |  | 2,093,297 |  |
| Total Shareholders’ Equity | 2,184,786 |  |  | 1,981,812 |  |
| Total Liabilities and Shareholders’ Equity | $ | 3,268,598 |  |  | $ | 2,831,432 |  |

[0001408710-26-000006:8k_2_02:39]
FABRINET

[0001408710-26-000006:8k_2_02:40]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME (UNAUDITED)

[0001408710-26-000006:8k_2_02:41]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands of U.S. dollars, except per share data) | December 26,2025 |  | December 27,2024 |  | December 26,2025 |  | December 27,2024 |
| Revenues | $ | 1,132,888 |  |  | $ | 833,608 |  |  | $ | 2,111,016 |  |  | $ | 1,637,836 |  |
| Cost of revenues | (995,206) |  |  | (732,759) |  |  | (1,856,895) |  |  | (1,437,961) |  |
| Gross profit | 137,682 |  |  | 100,849 |  |  | 254,121 |  |  | 199,875 |  |
| Selling, general and administrative expenses | (23,281) |  |  | (21,206) |  |  | (45,527) |  |  | (43,237) |  |
| Restructuring and other related costs | — |  |  | (46) |  |  | — |  |  | (103) |  |
| Operating income | 114,401 |  |  | 79,597 |  |  | 208,594 |  |  | 156,535 |  |
| Interest income | 8,555 |  |  | 11,314 |  |  | 17,972 |  |  | 22,247 |  |
| Foreign exchange gain (loss), net | (3,214) |  |  | 4,042 |  |  | (5,274) |  |  | (3,053) |  |
| Other income (expense), net | (17) |  |  | (62) |  |  | (139) |  |  | (81) |  |
| Income before income taxes | 119,725 |  |  | 94,891 |  |  | 221,153 |  |  | 175,648 |  |
| Income tax expense | (7,097) |  |  | (8,255) |  |  | (12,599) |  |  | (11,618) |  |
| Net income | 112,628 |  |  | 86,636 |  |  | 208,554 |  |  | 164,030 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities | 2,452 |  |  | (521) |  |  | 1,641 |  |  | 6,297 |  |
| Change in net unrealized gain (loss) on derivative instruments | 4,626 |  |  | (9,416) |  |  | 2,564 |  |  | (883) |  |
| Change in foreign currency translation adjustment | 29 |  |  | 428 |  |  | (60) |  |  | 76 |  |
| Total other comprehensive income (loss), net of tax | 7,107 |  |  | (9,509) |  |  | 4,145 |  |  | 5,490 |  |
| Net comprehensive income | $ | 119,735 |  |  | $ | 77,127 |  |  | $ | 212,699 |  |  | $ | 169,520 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 3.14 |  |  | $ | 2.40 |  |  | $ | 5.83 |  |  | $ | 4.53 |  |
| Diluted | $ | 3.11 |  |  | $ | 2.38 |  |  | $ | 5.77 |  |  | $ | 4.51 |  |
| Weighted-average number of ordinary shares outstanding (in thousands of shares) |  |  |  |  |  |  |  |
| Basic | 35,828 |  |  | 36,163 |  |  | 35,800 |  |  | 36,183 |  |
| Diluted | 36,253 |  |  | 36,402 |  |  | 36,175 |  |  | 36,405 |  |

[0001408710-26-000006:8k_2_02:42]
FABRINET

[0001408710-26-000006:8k_2_02:43]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (UNAUDITED)

[0001408710-26-000006:8k_2_02:44]
|  | Six Months Ended |
| (in thousands of U.S. dollars) | December 26,2025 |  | December 27,2024 |
| Cash flows from operating activities |  |  |  |
| Net income for the period | $ | 208,554 |  |  | $ | 164,030 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 30,965 |  |  | 25,796 |  |
| (Gain) loss on disposal of property, plant and equipment and intangibles | (13) |  |  | (37) |  |
| Amortization of discount (premium) of short-term investments | (2,417) |  |  | (2,225) |  |
| Inventory obsolescence impairment | 3,142 |  |  | — |  |
| (Reversal of) allowance for expected credit losses | (48) |  |  | (384) |  |
| Unrealized loss (gain) on exchange rate and fair value of foreign currency forward contracts | 3,919 |  |  | 1,345 |  |
| Share-based compensation | 17,828 |  |  | 17,120 |  |
| Customer warrant | 1,149 |  |  | — |  |
| Deferred income tax expense (benefit) | (1,054) |  |  | (3,493) |  |
| Other non-cash expenses | 176 |  |  | 30 |  |
| Changes in operating assets and liabilities |  |  |  |
| Trade accounts receivable | (42,829) |  |  | (87,178) |  |
| Inventories | (221,037) |  |  | (25,953) |  |
| Other current assets and non-current assets | (68,064) |  |  | 9,536 |  |
| Trade accounts payable | 147,211 |  |  | 88,272 |  |
| Income tax payable | 59 |  |  | 4,304 |  |
| Accrued expenses | (3,041) |  |  | 8,124 |  |
| Other payables | 70,648 |  |  | 186 |  |
| Severance liabilities | 1,816 |  |  | 1,565 |  |
| Other current liabilities and non-current liabilities | 1,863 |  |  | (1,952) |  |
| Net cash provided by operating activities | 148,827 |  |  | 199,086 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of short-term investments | (179,628) |  |  | (155,936) |  |
| Proceeds from maturities of short-term investments | 170,589 |  |  | 82,129 |  |
| Purchase of property, plant and equipment | (96,874) |  |  | (42,150) |  |
| Purchase of intangibles | (229) |  |  | (227) |  |
| Proceeds from disposal of property, plant and equipment | 25 |  |  | 110 |  |
| Net cash used in investing activities | (106,117) |  |  | (116,074) |  |
| Cash flows from financing activities |  |  |  |
| Repurchase of ordinary shares | (5,080) |  |  | (68,700) |  |
| Withholding tax related to net share settlement of restricted share units | (23,622) |  |  | (20,714) |  |
| Net cash used in financing activities | (28,702) |  |  | (89,414) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | 14,008 |  |  | $ | (6,402) |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at the beginning of period | $ | 306,425 |  |  | $ | 409,973 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | 14,008 |  |  | (6,402) |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash | 104 |  |  | 91 |  |
| Cash, cash equivalents and restricted cash at the end of period | $ | 320,537 |  |  | $ | 403,662 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment-related payables | $ | 53,874 |  |  | $ | 20,594 |  |

[0001408710-26-000006:8k_2_02:45]
FABRINET

[0001408710-26-000006:8k_2_02:46]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (UNAUDITED)

[0001408710-26-000006:8k_2_02:47]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the consolidated balance sheets that sum to the total of the same amounts shown in the consolidated statements of cash flows:

[0001408710-26-000006:8k_2_02:48]
|  | As of |
| (in thousands of U.S. dollars) | December 26,2025 |  | December 27,2024 |
| Cash and cash equivalents | $ | 319,855 |  |  | $ | 403,662 |  |
| Restricted cash | 682 |  |  | — |  |
| Cash, cash equivalents and restricted cash | $ | 320,537 |  |  | $ | 403,662 |  |

[0001408710-26-000006:8k_2_02:49]
FABRINET

[0001408710-26-000006:8k_2_02:50]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES (UNAUDITED)

[0001408710-26-000006:8k_2_02:51]
Reconciliation of GAAP Gross Profit and GAAP Gross Margin to Non-GAAP Gross Profit and Non-GAAP Gross Margin

[0001408710-26-000006:8k_2_02:52]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands of U.S. dollars) | December 26,2025 |  | December 27,2024 |  | December 26,2025 |  | December 27,2024 |
| Revenues | $ | 1,132,888 |  |  |  |  | $ | 833,608 |  |  |  |  | $ | 2,111,016 |  |  |  |  | $ | 1,637,836 |  |  |  |
| Gross profit (GAAP) | $ | 137,682 |  |  | 12.2 | % |  | $ | 100,849 |  |  | 12.1 | % |  | $ | 254,121 |  |  | 12.0 | % |  | $ | 199,875 |  |  | 12.2 | % |
| Share-based compensation expenses | 2,644 |  |  |  |  | 2,764 |  |  |  |  | 6,163 |  |  |  |  | 5,662 |  |  |  |
| Gross profit (Non-GAAP) | $ | 140,326 |  |  | 12.4 | % |  | $ | 103,613 |  |  | 12.4 | % |  | $ | 260,284 |  |  | 12.3 | % |  | $ | 205,537 |  |  | 12.5 | % |

[0001408710-26-000006:8k_2_02:53]
Reconciliation of GAAP Operating Profit and GAAP Operating Margin to Non-GAAP Operating Profit and Non-GAAP Operating Margin

[0001408710-26-000006:8k_2_02:54]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands of U.S. dollars) | December 26,2025 |  | December 27,2024 |  | December 26,2025 |  | December 27,2024 |
| Revenues | $ | 1,132,888 |  |  |  |  | $ | 833,608 |  |  |  |  | $ | 2,111,016 |  |  |  |  | $ | 1,637,836 |  |  |  |
| Operating profit (GAAP) | $ | 114,401 |  |  | 10.1 | % |  | $ | 79,597 |  |  | 9.5 | % |  | $ | 208,594 |  |  | 9.9 | % |  | $ | 156,535 |  |  | 9.6 | % |
| Share-based compensation expenses | 8,757 |  |  |  |  | 8,438 |  |  |  |  | 17,828 |  |  |  |  | 17,120 |  |  |  |
| Legal and litigation costs | 254 |  |  |  |  | — |  |  |  |  | 510 |  |  |  |  | — |  |  |  |
| Severance payment and others | — |  |  |  |  | 18 |  |  |  |  | 72 |  |  |  |  | 748 |  |  |  |
| Restructuring and other related costs | — |  |  |  |  | 46 |  |  |  |  | — |  |  |  |  | 103 |  |  |  |
| Operating profit (Non-GAAP) | $ | 123,412 |  |  | 10.9 | % |  | $ | 88,099 |  |  | 10.6 | % |  | $ | 227,004 |  |  | 10.8 | % |  | $ | 174,506 |  |  | 10.7 | % |

[0001408710-26-000006:8k_2_02:55]
FABRINET

[0001408710-26-000006:8k_2_02:56]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES (UNAUDITED)

[0001408710-26-000006:8k_2_02:57]
Reconciliation of GAAP Net Income and EPS to Non-GAAP Net Income and EPS

[0001408710-26-000006:8k_2_02:58]
|  | Three Months Ended |  | Six Months Ended |
|  | December 26,2025 |  | December 27,2024 |  | December 26,2025 |  | December 27,2024 |
| (in thousands of U.S. dollars, except per share data) | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |
| GAAP measures | $ | 112,628 |  |  | $ | 3.11 |  |  | $ | 86,636 |  |  | $ | 2.38 |  |  | $ | 208,554 |  |  | $ | 5.77 |  |  | $ | 164,030 |  |  | $ | 4.51 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 2,644 |  |  | 0.07 |  |  | 2,764 |  |  | 0.08 |  |  | 6,163 |  |  | 0.17 |  |  | 5,662 |  |  | 0.16 |  |
| Total related to cost of revenues | 2,644 |  |  | 0.07 |  |  | 2,764 |  |  | 0.08 |  |  | 6,163 |  |  | 0.17 |  |  | 5,662 |  |  | 0.16 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 6,113 |  |  | 0.17 |  |  | 5,674 |  |  | 0.15 |  |  | 11,665 |  |  | 0.32 |  |  | 11,458 |  |  | 0.31 |  |
| Legal and litigation costs | 254 |  |  | 0.01 |  |  | — |  |  | — |  |  | 510 |  |  | 0.01 |  |  | — |  |  | — |  |
| Severance payment and others | — |  |  | — |  |  | 18 |  |  | 0.00 |  |  | 72 |  |  | 0.00 |  |  | 748 |  |  | 0.02 |  |
| Total related to selling, general and administrative expenses | 6,367 |  |  | 0.18 |  |  | 5,692 |  |  | 0.15 |  |  | 12,247 |  |  | 0.33 |  |  | 12,206 |  |  | 0.33 |  |
| Related to other income and expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other related costs | — |  |  | — |  |  | 46 |  |  | 0.00 |  |  | — |  |  | — |  |  | 103 |  |  | 0.00 |  |
| Total related to other income and expense | — |  |  | — |  |  | 46 |  |  | 0.00 |  |  | — |  |  | — |  |  | 103 |  |  | 0.00 |  |
| Total related to net income & EPS | 9,011 |  |  | 0.25 |  |  | 8,502 |  |  | 0.23 |  |  | 18,410 |  |  | 0.50 |  |  | 17,971 |  |  | 0.49 |  |
| Non-GAAP measures | $ | 121,639 |  |  | $ | 3.36 |  |  | $ | 95,138 |  |  | $ | 2.61 |  |  | $ | 226,964 |  |  | $ | 6.27 |  |  | $ | 182,001 |  |  | $ | 5.00 |  |
| Shares used in computing diluted net income per share (in thousands of shares) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  | 36,253 |  |  |  |  | 36,402 |  |  |  |  | 36,175 |  |  |  |  | 36,405 |  |
| Non-GAAP diluted shares |  |  | 36,253 |  |  |  |  | 36,402 |  |  |  |  | 36,175 |  |  |  |  | 36,405 |  |

[0001408710-26-000006:8k_2_02:59]
FABRINET

[0001408710-26-000006:8k_2_02:60]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW (UNAUDITED)

[0001408710-26-000006:8k_2_02:61]
| (in thousands of U.S. dollars) |  | Three Months Ended |  | Six Months Ended |
|  |  | December 26,2025 |  | December 27,2024 |  | December 26,2025 |  | December 27,2024 |
| Net cash provided by operating activities |  | $ | 46,259 |  |  | $ | 115,904 |  |  | $ | 148,827 |  |  | $ | 199,086 |  |
| Less: Purchase of property, plant and equipment |  | (51,608) |  |  | (21,900) |  |  | (96,874) |  |  | (42,150) |  |
| Non-GAAP free cash flow |  | $ | (5,349) |  |  | $ | 94,004 |  |  | $ | 51,953 |  |  | $ | 156,936 |  |

[0001408710-26-000006:8k_2_02:62]
FABRINET

[0001408710-26-000006:8k_2_02:63]
GUIDANCE FOR QUARTER ENDING MARCH 27, 2026

[0001408710-26-000006:8k_2_02:64]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-26-000006:8k_2_02:65]
|  | DilutedEPS |
| GAAP net income per diluted share | $3.22 to $3.37 |
| Related to cost of revenues: |  |
| Share-based compensation expenses | 0.07 |
| Total related to cost of revenues | 0.07 |
| Related to selling, general and administrative expenses: |  |
| Share-based compensation expenses | 0.16 |
| Total related to selling, general and administrative expenses | 0.16 |
| Total related to net income & EPS | 0.23 |
| Non-GAAP net income per diluted share | $3.45 to $3.60 |
