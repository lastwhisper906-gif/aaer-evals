# FN notes — 0001408710-26-000008


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001408710-26-000008:notes:1]
[same as prior period, unchanged from 0001408710-25-000056:notes:1]

[0001408710-26-000008:notes:2]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of December 26, 2025 and for the three and six months ended December 26, 2025 and December 27, 2024 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 27, 2025.

[0001408710-26-000008:notes:3]
[same as prior period, unchanged from 0001408710-25-000056:notes:3]

[0001408710-26-000008:notes:4]
The results for the three and six months ended December 26, 2025 may not be indicative of results for the year ending June 26, 2026 or any future periods.

[0001408710-26-000008:notes:5]
[same as prior period, unchanged from 0001408710-25-000056:notes:5]

[0001408710-26-000008:notes:6]
[same as prior period, unchanged from 0001408710-25-000056:notes:6]

[0001408710-26-000008:notes:7]
[same as prior period, unchanged from 0001408710-25-000056:notes:7]

[0001408710-26-000008:notes:8]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended December 26, 2025 and December 27, 2024 consisted of 13 weeks. Fiscal year 2026 will comprise 52 weeks and will end on June 26, 2026.

[0001408710-26-000008:notes:9]
[same as prior period, unchanged from 0001408710-25-000056:notes:9]

[0001408710-26-000008:notes:10]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740), Improvements to Income Tax Disclosures,” which requires more detailed income tax disclosures. This ASU requires entities to disclose disaggregated information about their effective tax rate reconciliation as well as expanded information on income taxes paid by jurisdiction. This ASU is effective for all entities for fiscal years beginning after December 15, 2024, with early adoption permitted for annual financial statements that have not yet been issued or made available for issuance. This ASU will be effective for the Company beginning in fiscal year 2026. The Company is currently assessing the impact to its disclosures.

[0001408710-26-000008:notes:11]
In November 2024, the FASB issued ASU 2024-03, “Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), Disaggregation of Income Statement Expenses,” which requires additional disclosure, in notes to financial statements, of specified information about certain costs and expenses in the same tabular format disclosure as the other disaggregation requirements in the amendments in this ASU. This ASU is effective for all entities for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027, with early adoption permitted. This ASU is effective for the Company's annual periods beginning June 26, 2027, and interim periods beginning July 1, 2028, and will be applied retrospectively to all prior periods presented in the financial statements. The Company is currently evaluating the ASU to determine its impact on the Company's disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001408710-26-000008:notes:12]
[same as prior period, unchanged from 0001408710-25-000056:notes:14]

[0001408710-26-000008:notes:13]
[same as prior period, unchanged from 0001408710-25-000056:notes:15]

[0001408710-26-000008:notes:14]
[same as prior period, unchanged from 0001408710-25-000056:notes:16]

[0001408710-26-000008:notes:15]
| (in thousands, except percentages) | Three Months EndedDecember 26, 2025 |  | As a % of TotalRevenues |  | Six Months EndedDecember 26, 2025 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 528,135 |  |  |  |  | $ | 947,960 |  |  |  |
| Others (1) | 2,694 |  |  |  |  | 4,886 |  |  |  |
| Total revenue in North America | 530,829 |  |  | 46.9 | % |  | 952,846 |  |  | 45.1 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 231,742 |  |  |  |  | 464,244 |  |  |  |
| India | 110,074 |  |  |  |  | 210,643 |  |  |  |
| Hong Kong | 41,060 |  |  |  |  | 77,583 |  |  |  |
| Malaysia | 37,221 |  |  |  |  | 59,984 |  |  |  |
| Thailand | 25,102 |  |  |  |  | 45,123 |  |  |  |
| China | 16,936 |  |  |  |  | 35,057 |  |  |  |
| Singapore | 18,032 |  |  |  |  | 37,752 |  |  |  |
| Japan | 10,839 |  |  |  |  | 21,420 |  |  |  |
| Others | 855 |  |  |  |  | 1,989 |  |  |  |
| Total revenue in Asia-Pacific and others | 491,861 |  |  | 43.4 | % |  | 953,795 |  |  | 45.2 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 62,267 |  |  |  |  | 115,195 |  |  |  |
| Finland | 17,014 |  |  |  |  | 29,539 |  |  |  |
| Germany | 11,314 |  |  |  |  | 23,032 |  |  |  |
| Others | 19,603 |  |  |  |  | 36,609 |  |  |  |
| Total revenue in Europe | $ | 110,198 |  |  | 9.7 | % |  | $ | 204,375 |  |  | 9.7 | % |
| Total revenue | $ | 1,132,888 |  |  | 100.0 | % |  | $ | 2,111,016 |  |  | 100.0 | % |

[0001408710-26-000008:notes:16]
| (in thousands, except percentages) | Three Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 371,112 |  |  |  |  | $ | 678,932 |  |  |  |
| Others (1) | 1,291 |  |  |  |  | 2,949 |  |  |  |
| Total revenue in North America | 372,403 |  |  | 44.7 | % |  | 681,881 |  |  | 41.6 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 240,671 |  |  |  |  | 531,624 |  |  |  |
| India | 75,629 |  |  |  |  | 152,459 |  |  |  |
| Hong Kong | 20,415 |  |  |  |  | 38,962 |  |  |  |
| Thailand | 14,069 |  |  |  |  | 25,190 |  |  |  |
| China | 13,650 |  |  |  |  | 25,522 |  |  |  |
| Singapore | 12,481 |  |  |  |  | 23,244 |  |  |  |
| Japan | 8,976 |  |  |  |  | 17,555 |  |  |  |
| Malaysia | 7,565 |  |  |  |  | 15,063 |  |  |  |
| Others | 726 |  |  |  |  | 1,201 |  |  |  |
| Total revenue in Asia-Pacific and others | 394,182 |  |  | 47.3 | % |  | 830,820 |  |  | 50.7 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 39,262 |  |  |  |  | 71,712 |  |  |  |
| Germany | 10,867 |  |  |  |  | 20,211 |  |  |  |
| Others | 16,894 |  |  |  |  | 33,212 |  |  |  |
| Total revenue in Europe | $ | 67,023 |  |  | 8.0 | % |  | $ | 125,135 |  |  | 7.7 | % |
| Total revenue | $ | 833,608 |  |  | 100.0 | % |  | $ | 1,637,836 |  |  | 100.0 | % |

[0001408710-26-000008:notes:17]
[same as prior period, unchanged from 0001408710-25-000056:notes:18]

[0001408710-26-000008:notes:18]
[same as prior period, unchanged from 0001408710-25-000056:notes:19]

[0001408710-26-000008:notes:19]
| (in thousands, except percentages) | Three Months EndedDecember 26, 2025 |  | As a % of TotalRevenues |  | Six Months EndedDecember 26, 2025 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Telecom | $ | 412,248 |  |  |  |  | $ | 747,968 |  |  |  |
| Datacom | 278,142 |  |  |  |  | 551,238 |  |  |  |
| Datacenter interconnect (1) | 142,200 |  |  |  |  | 280,280 |  |  |  |
| Total revenue - Optical communications | $ | 832,590 |  |  | 73.5 | % |  | $ | 1,579,486 |  |  | 74.8 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 116,956 |  |  |  |  | $ | 238,904 |  |  |  |
| Industrial laser | 41,432 |  |  |  |  | 81,111 |  |  |  |
| High-performance computing (2) | 85,556 |  |  |  |  | 100,959 |  |  |  |
| Others | 56,354 |  |  |  |  | 110,556 |  |  |  |
| Total revenue - Non-optical communications | $ | 300,298 |  |  | 26.5 | % |  | $ | 531,530 |  |  | 25.2 | % |
| Total revenue | $ | 1,132,888 |  |  | 100.0 | % |  | $ | 2,111,016 |  |  | 100.0 | % |

[0001408710-26-000008:notes:20]
| (in thousands, except percentages) | Three Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 299,101 |  |  |  |  | $ | 627,982 |  |  |  |
| Telecom | 248,010 |  |  |  |  | 473,637 |  |  |  |
| Datacenter interconnect (1) | 100,039 |  |  |  |  | 171,846 |  |  |  |
| Total revenue - Optical communications | $ | 647,150 |  |  | 77.6 | % |  | $ | 1,273,465 |  |  | 77.8 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 104,247 |  |  |  |  | $ | 206,988 |  |  |  |
| Industrial laser | 37,542 |  |  |  |  | 72,868 |  |  |  |
| Others | 44,669 |  |  |  |  | 84,515 |  |  |  |
| Total revenue - Non-optical communications | $ | 186,458 |  |  | 22.4 | % |  | $ | 364,371 |  |  | 22.2 | % |
| Total revenue | $ | 833,608 |  |  | 100.0 | % |  | $ | 1,637,836 |  |  | 100.0 | % |

[0001408710-26-000008:notes:21]
[same as prior period, unchanged from 0001408710-25-000056:notes:21]

[0001408710-26-000008:notes:22]
[same as prior period, unchanged from 0001408710-25-000056:notes:22]

[0001408710-26-000008:notes:23]
[same as prior period, unchanged from 0001408710-25-000056:notes:23]

[0001408710-26-000008:notes:24]
[same as prior period, unchanged from 0001408710-25-000056:notes:24]

[0001408710-26-000008:notes:25]
As of December 26, 2025 and June 27, 2025, the Company's contract assets were de minimis.

[0001408710-26-000008:notes:26]
[same as prior period, unchanged from 0001408710-25-000056:notes:26]

[0001408710-26-000008:notes:27]
The following tables summarize the activity in the Company’s contract liabilities during the six months ended December 26, 2025:

[0001408710-26-000008:notes:28]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 27, 2025 | $ | 14,467 |  |
| Advance payments received during the period | 17,855 |  |
| Revenue recognized | (14,883) |  |
| Ending balance, December 26, 2025 | $ | 17,439 |  |

[0001408710-26-000008:notes:29]
[same as prior period, unchanged from 0001408710-25-000056:notes:29]

[0001408710-26-000008:notes:30]
[same as prior period, unchanged from 0001408710-25-000056:notes:30]

[0001408710-26-000008:notes:31]
[same as prior period, unchanged from 0001408710-25-000056:notes:31]

[0001408710-26-000008:notes:32]
For the three months ended December 26, 2025, the Company recognized $0.8 million as a reduction to revenue on the unaudited condensed consolidated statements of operations.

[0001408710-26-000008:notes:33]
For the six months ended December 26, 2025, the Company recognized $1.1 million as a reduction to revenue on the unaudited condensed consolidated statements of operations.


## us-gaap:EarningsPerShareTextBlock

[0001408710-26-000008:notes:34]
[same as prior period, unchanged from 0001408710-25-000056:notes:33]

[0001408710-26-000008:notes:35]
[same as prior period, unchanged from 0001408710-25-000056:notes:34]

[0001408710-26-000008:notes:36]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands, except per share data) | December 26,2025 |  | December 27,2024 |  | December 26,2025 |  | December 27,2024 |
| Net income attributable to shareholders | $ | 112,628 |  |  | $ | 86,636 |  |  | $ | 208,554 |  |  | $ | 164,030 |  |
| Weighted-average number of ordinary shares outstanding | 35,828 |  |  | 36,163 |  |  | 35,800 |  |  | 36,183 |  |
| Incremental shares arising from the assumed vesting of restricted share units and performance share units | 227 |  |  | 239 |  |  | 206 |  |  | 222 |  |
| Incremental shares arising from the assumed vesting of customer warrant | 198 |  |  | — |  |  | 169 |  |  | — |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share | 36,253 |  |  | 36,402 |  |  | 36,175 |  |  | 36,405 |  |
| Basic earnings per ordinary share | $ | 3.14 |  |  | $ | 2.40 |  |  | $ | 5.83 |  |  | $ | 4.53 |  |
| Diluted earnings per ordinary share | $ | 3.11 |  |  | $ | 2.38 |  |  | $ | 5.77 |  |  | $ | 4.51 |  |
| Outstanding performance share units excluded from the computation of diluted earnings per ordinary share (1) | 1 |  |  | — |  |  | 1 |  |  | — |  |

[0001408710-26-000008:notes:37]
[same as prior period, unchanged from 0001408710-25-000056:notes:36]


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001408710-26-000008:notes:38]
[same as prior period, unchanged from 0001408710-25-000056:notes:37]

[0001408710-26-000008:notes:39]
|  |  |  | Fair Value |
| (in thousands) | CarryingCost |  | UnrealizedGain/(Loss) |  | Cash andCashEquivalents |  | Short-term Investments |  | OtherInvestments |
| As of December 26, 2025 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 308,348 |  |  | $ | — |  |  | $ | 308,348 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 11,510 |  |  | (3) |  |  | 11,507 |  |  | — |  |  | — |  |
| Certificates of deposit and time deposits | 108,054 |  |  | 308 |  |  | — |  |  | 108,362 |  |  | — |  |
| Corporate debt securities | 224,744 |  |  | 8,967 |  |  | — |  |  | 233,711 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 297,759 |  |  | 1,086 |  |  | — |  |  | 298,845 |  |  | — |  |
| Total | $ | 950,415 |  |  | $ | 10,358 |  |  | $ | 319,855 |  |  | $ | 640,918 |  |  | $ | — |  |
| As of June 27, 2025 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 295,242 |  |  | $ | — |  |  | $ | 295,242 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 11,183 |  |  | — |  |  | 11,183 |  |  | — |  |  | — |  |
| Certificates of deposit and time deposits | 144,730 |  |  | 1,022 |  |  | — |  |  | 145,752 |  |  | — |  |
| Corporate debt securities | 183,076 |  |  | 6,897 |  |  | — |  |  | 189,973 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 291,295 |  |  | 799 |  |  | — |  |  | 292,094 |  |  | — |  |
| Total | $ | 925,526 |  |  | $ | 8,718 |  |  | $ | 306,425 |  |  | $ | 627,819 |  |  | $ | — |  |

[0001408710-26-000008:notes:40]
All highly liquid investments with original maturities of three months or less at the date of purchase are classified as cash equivalents. Management determines the appropriate classification of its investments at the time of purchase. The Company may sell certain of its short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s short-term investments generally range from three months to three years.

[0001408710-26-000008:notes:41]
The following table summarizes the cost and estimated fair value of debt securities classified as available-for-sale securities based on stated effective maturities as of December 26, 2025 and June 27, 2025:

[0001408710-26-000008:notes:42]
|  | December 26, 2025 |  | June 27, 2025 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 108,054 |  |  | $ | 108,362 |  |  | $ | 128,958 |  |  | $ | 129,977 |  |
| Due between one to five years | 522,503 |  |  | 532,556 |  |  | 490,143 |  |  | 497,842 |  |
| Total | $ | 630,557 |  |  | $ | 640,918 |  |  | $ | 619,101 |  |  | $ | 627,819 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001408710-26-000008:notes:43]
[same as prior period, unchanged from 0001408710-25-000056:notes:43]

[0001408710-26-000008:notes:44]
[same as prior period, unchanged from 0001408710-25-000056:notes:44]

[0001408710-26-000008:notes:45]
[same as prior period, unchanged from 0001408710-25-000056:notes:45]

[0001408710-26-000008:notes:46]
[same as prior period, unchanged from 0001408710-25-000056:notes:46]

[0001408710-26-000008:notes:47]
[same as prior period, unchanged from 0001408710-25-000056:notes:47]

[0001408710-26-000008:notes:48]
[same as prior period, unchanged from 0001408710-25-000056:notes:48]

[0001408710-26-000008:notes:49]
|  | Fair Value Measurements at Reporting Date Using |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of December 26, 2025 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 11,507 |  |  |  | $ | — |  |  | $ | 11,507 |  |
| Certificates of deposit and time deposits | — |  |  | 108,362 |  |  |  | — |  |  | 108,362 |  |
| Corporate debt securities | — |  |  | 233,711 |  |  |  | — |  |  | 233,711 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 298,845 |  |  |  | — |  |  | 298,845 |  |
| Derivative assets – current portion | — |  |  | 5,394 |  | (1) |  | — |  |  | 5,394 |  |
| Total | $ | — |  |  | $ | 657,819 |  |  |  | $ | — |  |  | $ | 657,819 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | (29) |  | (2) |  | $ | — |  |  | $ | (29) |  |
| Total | $ | — |  |  | $ | (29) |  |  |  | $ | — |  |  | $ | (29) |  |

[0001408710-26-000008:notes:50]
[same as prior period, unchanged from 0001408710-25-000056:notes:50]

[0001408710-26-000008:notes:51]
(1)Foreign currency forward contracts with an aggregate notional amount of $189.0 million and 0.4 million Canadian dollars.

[0001408710-26-000008:notes:52]
(2)Foreign currency forward contracts with an aggregate notional amount of $11.0 million.

[0001408710-26-000008:notes:53]
[same as prior period, unchanged from 0001408710-25-000056:notes:53]

[0001408710-26-000008:notes:54]
[same as prior period, unchanged from 0001408710-25-000056:notes:54]

[0001408710-26-000008:notes:55]
[same as prior period, unchanged from 0001408710-25-000056:notes:55]

[0001408710-26-000008:notes:56]
[same as prior period, unchanged from 0001408710-25-000056:notes:56]

[0001408710-26-000008:notes:57]
[same as prior period, unchanged from 0001408710-25-000056:notes:57]

[0001408710-26-000008:notes:58]
[same as prior period, unchanged from 0001408710-25-000056:notes:58]

[0001408710-26-000008:notes:59]
As a result of foreign currency rate fluctuations, the U.S. dollar equivalent values of the Company’s foreign currency denominated assets and liabilities fluctuate. The Company uses foreign currency forward and option contracts to manage the foreign exchange risk associated with a portion of its foreign currency denominated assets and liabilities and other

[0001408710-26-000008:notes:60]
foreign currency transactions. The Company enters into foreign currency forward and option contracts to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht and Canadian dollars with counterparties that meet the Company’s minimum credit quality standard.

[0001408710-26-000008:notes:61]
[same as prior period, unchanged from 0001408710-25-000056:notes:60]

[0001408710-26-000008:notes:62]
[same as prior period, unchanged from 0001408710-25-000056:notes:61]

[0001408710-26-000008:notes:63]
As of December 26, 2025, the Company had 200 outstanding U.S. dollar foreign currency forward contracts against Thai baht, with an aggregate notional amount of $200.0 million and maturity dates ranging from December 2025 through July 2026 and one outstanding Canadian dollar foreign currency forward contract with a notional amount of 0.4 million Canadian dollars and a maturity date in March 2026.

[0001408710-26-000008:notes:64]
[same as prior period, unchanged from 0001408710-25-000056:notes:63]

[0001408710-26-000008:notes:65]
As of December 26, 2025, the hedging relationship over foreign currency forward contracts designated for hedge accounting was determined to be highly effective based on the performance of retrospective and prospective regression testing. As of December 26, 2025, the amount in accumulated other comprehensive income (“AOCI”) expected to be reclassified into earnings within 12 months was a gain of $4.3 million.

[0001408710-26-000008:notes:66]
[same as prior period, unchanged from 0001408710-25-000056:notes:65]

[0001408710-26-000008:notes:67]
During the three and six months ended December 26, 2025, the Company included an unrealized gain of $1.2 million and unrealized loss of $0.1 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-26-000008:notes:68]
During the three and six months ended December 27, 2024, the Company included unrealized loss of $5.1 million and $1.0 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-26-000008:notes:69]
[same as prior period, unchanged from 0001408710-25-000056:notes:67]

[0001408710-26-000008:notes:70]
|  |  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) | Financialstatementsline item |  | December 26,2025 |  | December 27,2024 |  | December 26,2025 |  | December 27,2024 |
| Derivatives gain (loss) recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Othercomprehensiveincome (loss) |  | $ | 5,309 |  |  | $ | (13,303) |  |  | $ | 2,509 |  |  | $ | (57) |  |
| Total derivatives gain (loss) recognized in other comprehensive income (loss) |  |  | $ | 5,309 |  |  | $ | (13,303) |  |  | $ | 2,509 |  |  | $ | (57) |  |
| Derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings: |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Cost of revenues |  | $ | 478 |  |  | $ | (5,905) |  |  | $ | (773) |  |  | $ | (4,486) |  |
| Foreign currency forward contracts | SG&A |  | 36 |  |  | (451) |  |  | (59) |  |  | (345) |  |
| Foreign currency forward contracts | Foreign exchange gain (loss), net |  | (947) |  |  | 9,842 |  |  | 1,061 |  |  | 3,933 |  |
| Total derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings |  |  | $ | (433) |  |  | $ | 3,486 |  |  | $ | 229 |  |  | $ | (898) |  |
| Change in net unrealized gain (loss) on derivatives instruments |  |  | $ | 4,876 |  |  | $ | (9,817) |  |  | $ | 2,738 |  |  | $ | (955) |  |

[0001408710-26-000008:notes:71]
[same as prior period, unchanged from 0001408710-25-000056:notes:69]

[0001408710-26-000008:notes:72]
[same as prior period, unchanged from 0001408710-25-000056:notes:70]

[0001408710-26-000008:notes:73]
|  | December 26,2025 |  | June 27,2025 |
| (in thousands) | DerivativeAssets |  | DerivativeLiabilities |  | DerivativeAssets |  | DerivativeLiabilities |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts | $ | 1,095 |  |  | $ | — |  |  | $ | 1,303 |  |  | $ | (12) |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward contracts | 4,299 |  |  | (29) |  |  | 1,658 |  |  | (93) |  |
| Derivatives, gross balances | $ | 5,394 |  |  | $ | (29) |  |  | $ | 2,961 |  |  | $ | (105) |  |

[0001408710-26-000008:notes:74]
[same as prior period, unchanged from 0001408710-25-000056:notes:72]

[0001408710-26-000008:notes:75]
| Derivative Financial Instruments | Balance Sheet line item |
| Fair Value of Derivative Assets | Other current assets |
| Fair Value of Derivative Liabilities | Accrued expenses |


## us-gaap:InventoryDisclosureTextBlock

[0001408710-26-000008:notes:76]
[same as prior period, unchanged from 0001408710-25-000056:notes:74]

[0001408710-26-000008:notes:77]
| (in thousands) | As of December 26,2025 |  | As of June 27,2025 |
| Raw materials | $ | 229,604 |  |  | $ | 145,128 |  |
| Work in progress | 469,925 |  |  | 377,736 |  |
| Finished goods | 70,584 |  |  | 33,016 |  |
| Goods in transit | 28,797 |  |  | 25,135 |  |
| Total inventories | $ | 798,910 |  |  | $ | 581,015 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001408710-26-000008:notes:78]
[same as prior period, unchanged from 0001408710-25-000056:notes:76]

[0001408710-26-000008:notes:79]
[same as prior period, unchanged from 0001408710-25-000056:notes:77]

[0001408710-26-000008:notes:80]
As of December 26, 2025, the maturities of the Company’s operating lease liabilities, by fiscal year, were as follows:

[0001408710-26-000008:notes:81]
| (in thousands) |  |  |
| 2026 (remaining six months) | $ | 1,123 |  |  |
| 2027 | 1,407 |  |  |
| 2028 | 931 |  |  |
| 2029 | 853 |  |  |
| 2030 | 449 |  |  |
| Thereafter | 979 |  |  |
| Total undiscounted lease payments | 5,742 |  |  |
| Less imputed interest | (857) |  |  |
| Total present value of lease liabilities | $ | 4,885 |  | (1) |

[0001408710-26-000008:notes:82]
(1)    Includes current portion of operating lease liabilities of $1.7 million.

[0001408710-26-000008:notes:83]
[same as prior period, unchanged from 0001408710-25-000056:notes:81]

[0001408710-26-000008:notes:84]
Rental expense for long-term leases for the three and six months ended December 26, 2025 was $0.6 million and $1.1 million, respectively, and for the three and six months ended December 27, 2024 was $0.4 million and $0.9 million, respectively.

[0001408710-26-000008:notes:85]
Rental expense for short-term leases for the three and six months ended December 26, 2025 and December 27, 2024 was de minimis.

[0001408710-26-000008:notes:86]
[same as prior period, unchanged from 0001408710-25-000056:notes:84]

[0001408710-26-000008:notes:87]
|  | As ofDecember 26, 2025 |  | As ofJune 27, 2025 |
| Weighted-average remaining lease term (in years) | 4.9 |  | 5.5 |
| Weighted-average discount rate | 6.8 | % |  | 6.6 | % |

[0001408710-26-000008:notes:88]
The following table presents supplemental disclosure for the unaudited condensed consolidated statements of cash flows related to operating leases for the three and six months ended December 26, 2025 and December 27, 2024:

[0001408710-26-000008:notes:89]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands) | December 26,2025 |  | December 27,2024 |  | December 26,2025 |  | December 27,2024 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |
| Operating cash flows from operating leases | $ | 607 |  |  | $ | 501 |  |  | $ | 1,214 |  |  | $ | 1,245 |  |
| ROU assets obtained in exchange for lease liabilities | $ | 75 |  |  | $ | 1,778 |  |  | $ | 182 |  |  | $ | 1,937 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001408710-26-000008:notes:90]
[same as prior period, unchanged from 0001408710-25-000056:notes:88]

[0001408710-26-000008:notes:91]
| (in thousands) | As ofDecember 26, 2025 |  | As ofJune 27, 2025 |  |  |
| Software |  |  |  |  |  |
| Gross carrying amount | $ | 12,689 |  |  | $ | 12,159 |  |  |  |
| Accumulated amortization | (10,456) |  |  | (10,003) |  |  |  |
| Net | $ | 2,233 |  |  | $ | 2,156 |  |  |  |

[0001408710-26-000008:notes:92]
The Company recorded amortization expense relating to intangibles of $0.2 million for the three months ended December 26, 2025 and December 27, 2024 for both periods, and $0.4 million and $0.5 million for the six months ended December 26, 2025 and December 27, 2024, respectively.

[0001408710-26-000008:notes:93]
[same as prior period, unchanged from 0001408710-25-000056:notes:91]

[0001408710-26-000008:notes:94]
| (years) | As ofDecember 26, 2025 |  | As ofJune 27, 2025 |
| Software | 3.1 |  | 3.6 |

[0001408710-26-000008:notes:95]
Based on the carrying amount of intangibles as of December 26, 2025, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001408710-26-000008:notes:96]
| (in thousands) |  |
| 2026 (remaining six months) | $ | 417 |  |
| 2027 | 696 |  |
| 2028 | 525 |  |
| 2029 | 325 |  |
| 2030 | 192 |  |
| Thereafter | 78 |  |
| Total | $ | 2,233 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001408710-26-000008:notes:97]
Income taxes
As of December 26, 2025 and June 27, 2025, the liability for uncertain tax positions including accrued interest and penalties was $4.0 million and $2.2 million, respectively.

[0001408710-26-000008:notes:98]
The Company files income tax returns in the United States and foreign tax jurisdictions. The tax years from 2018 to 2024 remain open to examination by U.S. federal and state, and foreign tax authorities. The Company is currently under examination by the U.S. Internal Revenue Service for fiscal year 2022 and the IRS completed the examination of the US subsidiaries for fiscal year 2022 and fiscal year 2023 in the fiscal year 2025. The Company’s income tax is recognized based on the best estimate of the expected annual effective tax rate for the full financial year of each entity in the Company, adjusted for discrete items arising in that quarter. If the Company’s estimated annual effective tax rate changes, the Company makes a cumulative adjustment in that quarter.

[0001408710-26-000008:notes:99]
The effective tax rate for the Company for the three months ended December 26, 2025 and December 27, 2024 was 5.9% and 8.7%, respectively, of net income. The decrease was due to an increase in income not subject to tax.

[0001408710-26-000008:notes:100]
The effective tax rate for the Company for the six months ended December 26, 2025 and December 27, 2024 was 5.7% and 6.6%, respectively, of net income. The decrease was due to an increase in income not subject to tax.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001408710-26-000008:notes:101]
[same as prior period, unchanged from 0001408710-25-000056:notes:97]

[0001408710-26-000008:notes:102]
[same as prior period, unchanged from 0001408710-25-000056:notes:98]

[0001408710-26-000008:notes:103]
The effect of recording share-based compensation expense for the three and six months ended December 26, 2025 and December 27, 2024 was as follows:

[0001408710-26-000008:notes:104]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands) | December 26,2025 |  | December 27,2024 |  | December 26,2025 |  | December 27,2024 |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |
| Restricted share units | $ | 5,336 |  |  | $ | 5,430 |  |  | $ | 11,703 |  |  | $ | 11,143 |  |
| Performance share units | 3,421 |  |  | 3,008 |  |  | 6,125 |  |  | 5,977 |  |
| Total share-based compensation expense | 8,757 |  |  | 8,438 |  |  | 17,828 |  |  | 17,120 |  |
| Tax effect on share-based compensation expense | — |  |  | — |  |  | — |  |  | — |  |
| Net effect on share-based compensation expense | $ | 8,757 |  |  | $ | 8,438 |  |  | $ | 17,828 |  |  | $ | 17,120 |  |

[0001408710-26-000008:notes:105]
[same as prior period, unchanged from 0001408710-25-000056:notes:101]

[0001408710-26-000008:notes:106]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands) | December 26,2025 |  | December 27,2024 |  | December 26,2025 |  | December 27,2024 |
| Cost of revenue | $ | 2,644 |  |  | $ | 2,764 |  |  | $ | 6,163 |  |  | $ | 5,662 |  |
| Selling, general and administrative expense | 6,113 |  |  | 5,674 |  |  | 11,665 |  |  | 11,458 |  |
| Total share-based compensation expense | $ | 8,757 |  |  | $ | 8,438 |  |  | $ | 17,828 |  |  | $ | 17,120 |  |

[0001408710-26-000008:notes:107]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the three and six months ended December 26, 2025 and December 27, 2024.

[0001408710-26-000008:notes:108]
[same as prior period, unchanged from 0001408710-25-000056:notes:104]

[0001408710-26-000008:notes:109]
[same as prior period, unchanged from 0001408710-25-000056:notes:105]

[0001408710-26-000008:notes:110]
On November 2, 2017, the Company adopted the 2017 Inducement Equity Incentive Plan (the “2017 Inducement Plan”) with a reserve of 160,000 ordinary shares authorized for future issuance solely for the granting of inducement share options and equity awards to new employees. The 2017 Inducement Plan was adopted without shareholder approval in reliance on the “employment inducement exemption” provided under the New York Stock Exchange Listed Company Manual.

[0001408710-26-000008:notes:111]
[same as prior period, unchanged from 0001408710-25-000056:notes:108]

[0001408710-26-000008:notes:112]
The following table summarizes the number of equity awards outstanding and ordinary shares available for grant under each of the Equity Incentive Plans as of December 26, 2025:

[0001408710-26-000008:notes:113]
| (share units) | Restricted Share Units outstanding |  | Performance Share Units outstanding |  | Ordinary Shares available for future grant |
| 2020 Plan | 225,573 |  |  | 94,391 |  |  | 1,460,797 |  |
| 2017 Inducement Plan | — |  |  | — |  |  | 111,347 |  |
| Total | 225,573 |  |  | 94,391 |  |  | 1,572,144 |  |

[0001408710-26-000008:notes:114]
[same as prior period, unchanged from 0001408710-25-000056:notes:111]

[0001408710-26-000008:notes:115]
[same as prior period, unchanged from 0001408710-25-000056:notes:112]

[0001408710-26-000008:notes:116]
[same as prior period, unchanged from 0001408710-25-000056:notes:113]

[0001408710-26-000008:notes:117]
[same as prior period, unchanged from 0001408710-25-000056:notes:114]

[0001408710-26-000008:notes:118]
[same as prior period, unchanged from 0001408710-25-000056:notes:115]

[0001408710-26-000008:notes:119]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 27, 2025 | 263,014 |  |  | $ | 187.00 |  |
| Granted | 74,043 |  |  | $ | 294.89 |  |
| Vested | (105,195) |  |  | $ | 164.64 |  |
| Forfeited | (6,289) |  |  | $ | 209.90 |  |
| Balance as of December 26, 2025 | 225,573 |  |  | $ | 233.10 |  |

[0001408710-26-000008:notes:120]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 28, 2024 | 306,660 |  |  | $ | 129.01 |  |
| Granted | 107,026 |  |  | $ | 260.95 |  |
| Vested | (120,452) |  |  | $ | 114.39 |  |
| Forfeited | (7,494) |  |  | $ | 151.56 |  |
| Balance as of December 27, 2024 | 285,740 |  |  | $ | 184.00 |  |

[0001408710-26-000008:notes:121]
[same as prior period, unchanged from 0001408710-25-000056:notes:118]

[0001408710-26-000008:notes:122]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 27, 2025 | 120,916 |  |  | $ | 198.90 |  |
| Granted | 48,806 |  |  | $ | 277.04 |  |
| Vested | (73,936) |  |  | $ | 158.91 |  |
| Forfeited | (1,395) |  |  | $ | 261.84 |  |
| Balance as of December 26, 2025 | 94,391 |  |  | $ | 269.70 |  |

[0001408710-26-000008:notes:123]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 28, 2024 | 171,078 |  |  | $ | 135.31 |  |
| Granted | 46,980 |  |  | $ | 261.84 |  |
| Vested | (97,142) |  |  | 117.35 |  |
| Forfeited | — |  |  | $ | — |  |
| Balance as of December 27, 2024 | 120,916 |  |  | $ | 198.90 |  |

[0001408710-26-000008:notes:124]
As of December 26, 2025, there was $25.8 million and $14.2 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.8 and 1.4 years, respectively.

[0001408710-26-000008:notes:125]
For the six months ended December 26, 2025 and December 27, 2024, the Company withheld an aggregate of 71,352 shares and 89,868 shares, respectively, upon the vesting of restricted share units and performance shares units, based upon the closing share price on the vesting date to settle employee tax withholding obligations. For the six months ended December 26, 2025 and December 27, 2024, the Company then remitted cash of $23.6 million and $20.7 million, respectively, to the appropriate taxing authorities and presented it as a financing activity within the unaudited condensed consolidated statements of cash flows. The payment was recorded as a reduction of additional paid-in capital.

[0001408710-26-000008:notes:126]
[same as prior period, unchanged from 0001408710-25-000056:notes:123]

[0001408710-26-000008:notes:127]
[same as prior period, unchanged from 0001408710-25-000056:notes:124]

[0001408710-26-000008:notes:128]
[same as prior period, unchanged from 0001408710-25-000056:notes:125]

[0001408710-26-000008:notes:129]
[same as prior period, unchanged from 0001408710-25-000056:notes:126]

[0001408710-26-000008:notes:130]
As of December 26, 2025 and June 27, 2025, 49,652 and 38,192 Warrant Shares, respectively, were vested and remained unexercised.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001408710-26-000008:notes:131]
[same as prior period, unchanged from 0001408710-25-000056:notes:128]

[0001408710-26-000008:notes:132]
[same as prior period, unchanged from 0001408710-25-000056:notes:129]

[0001408710-26-000008:notes:133]
For the three and six months ended December 26, 2025, Fabrinet issued 8,568 and 107,779 ordinary shares, respectively, upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-26-000008:notes:134]
For the three and six months ended December 27, 2024, Fabrinet issued 5,329 and 127,726 ordinary shares, respectively, upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-26-000008:notes:135]
[same as prior period, unchanged from 0001408710-25-000056:notes:132]

[0001408710-26-000008:notes:136]
[same as prior period, unchanged from 0001408710-25-000056:notes:133]

[0001408710-26-000008:notes:137]
[same as prior period, unchanged from 0001408710-25-000056:notes:134]

[0001408710-26-000008:notes:138]
During the six months ended December 26, 2025, 13,409 shares were repurchased under the program, at an average price per share (excluding other direct costs) of $378.87, for an aggregate purchase price of $5.1 million. As of December 26, 2025, the Company had a remaining authorization to repurchase up to $169.2 million worth of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001408710-26-000008:notes:139]
Accumulated other comprehensive income (loss)
The changes in AOCI for the six months ended December 26, 2025 and December 27, 2024 were as follows:

[0001408710-26-000008:notes:140]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  |  |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 27, 2025 | $ | 8,714 |  |  | $ | 1,334 |  |  |  |  | $ | 246 |  |  | $ | 10,294 |  |
| Other comprehensive income (loss) before reclassification | 1,641 |  |  | 2,509 |  |  |  |  | (60) |  |  | 4,090 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | — |  |  | 229 |  |  |  |  | — |  |  | 229 |  |
| Tax effects | — |  |  | (174) |  |  |  |  | — |  |  | (174) |  |
| Other comprehensive income (loss) | $ | 1,641 |  |  | $ | 2,564 |  |  |  |  | $ | (60) |  |  | $ | 4,145 |  |
| Balance as of December 26, 2025 | $ | 10,355 |  |  | $ | 3,898 |  |  |  |  | $ | 186 |  |  | $ | 14,439 |  |

[0001408710-26-000008:notes:141]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  |  |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 28, 2024 | $ | (1,179) |  |  | $ | (980) |  |  |  |  | $ | (982) |  |  | $ | (3,141) |  |
| Other comprehensive income (loss) before reclassification | 6,297 |  |  | (57) |  |  |  |  | 76 |  |  | 6,316 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | — |  |  | (898) |  |  |  |  | — |  |  | (898) |  |
| Tax effects | — |  |  | 72 |  |  |  |  | — |  |  | 72 |  |
| Other comprehensive income (loss) | $ | 6,297 |  |  | $ | (883) |  |  |  |  | $ | 76 |  |  | $ | 5,490 |  |
| Balance as of December 27, 2024 | $ | 5,118 |  |  | $ | (1,863) |  |  |  |  | $ | (906) |  |  | $ | 2,349 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001408710-26-000008:notes:142]
Commitments and contingencies
Bank guarantees

[0001408710-26-000008:notes:143]
As of December 26, 2025 and June 27, 2025, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.5 million and $2.3 million, respectively, or Thai baht 77.3 million and 75.7 million, respectively. As of December 26, 2025, the Company had an outstanding bank guarantee on behalf of its subsidiary in China to support the subsidiary's operations of Chinese Renminbi ("RMB") 4.8 million and the bank guarantee was backed by cash collateral of $0.7 million. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the subsidiary's operations.

[0001408710-26-000008:notes:144]
Purchase obligations

[0001408710-26-000008:notes:145]
Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001408710-26-000008:notes:146]
As of December 26, 2025, the Company had purchase obligations and other commitments to third parties of $1.94 billion.

[0001408710-26-000008:notes:147]
Capital expenditures

[0001408710-26-000008:notes:148]
In February 2025, the Company entered into a construction contract with a local contractor for construction of a new manufacturing building at the Company's Chonburi campus. The contract price is approximately $132.5 million (Thai baht 4.45 billion).

[0001408710-26-000008:notes:149]
As of December 26, 2025, the Company had total capital expenditure commitments to third parties of $193.7 million.

[0001408710-26-000008:notes:150]
Indemnification of directors and officers

[0001408710-26-000008:notes:151]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001408710-26-000008:notes:152]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.

[0001408710-26-000008:notes:153]
Credit facility agreement

[0001408710-26-000008:notes:154]
On March 9, 2023, Fabrinet Thailand and the Parent Company (collectively, the “Borrowers”) and the Bank of Ayudhya Public Company Limited (the "Bank") entered into a credit facility agreement (the “2023 Credit Facility Agreement”), which provided a facility of $55.0 million.

[0001408710-26-000008:notes:155]
During the three months ended December 27, 2024, the Borrowers and the Bank amended the 2023 Credit Facility Agreement to reduce the facility to $30.0 million, which may be used for, among other things, an overdraft facility. The Credit Facility will mature on August 20, 2039.

[0001408710-26-000008:notes:156]
As of December 26, 2025, there was no amount outstanding under the 2023 Credit Facility Agreement.

[0001408710-26-000008:notes:157]
Under the 2023 Credit Facility Agreement, the Borrowers are required to maintain a debt-to-equity ratio of less than or equal to 1.5 times for Fabrinet Thailand and 1.0 times for the Parent Company.

[0001408710-26-000008:notes:158]
As of December 26, 2025, the Borrowers were in compliance with all of their financial covenants under the 2023 Credit Facility Agreement.

[0001408710-26-000008:notes:159]
Litigation and claim

[0001408710-26-000008:notes:160]
On June 28, 2024, Ngan In Leng and First Laser Limited (collectively, the “Plaintiffs”) filed a complaint in the Fuzhou Intermediate People’s Court (the “Court”) in Fuzhou, China against Fujian Enterprises (Holdings) Co., Ltd. (“FEHC”), Jian An Investment Limited (“Jian”), and Casix, Inc. (“Casix”), the Company's wholly-owned subsidiary located in the PRC. The complaint alleged unjust enrichment related to a purported investment in Casix by the Plaintiffs in 1997, which predates the Company's acquisition of Casix from JDS Uniphase Corporation. The Plaintiffs requested that the Court order FEHC to return the unjust enrichment to the Plaintiffs in the amount of RMB 400 million, with interest from March 1, 2000, and order Jian and Casix to bear joint and several liability for all payment obligations of FEHC.

[0001408710-26-000008:notes:161]
In September 2024, the Court dismissed the complaint in its entirety based on jurisdictional grounds. The Plaintiffs subsequently appealed the Court’s ruling to the High People's Court of Fujian Province (the "Appellate Court"). In their appeal, the Plaintiffs claimed that Casix is the primary obligor to return the alleged unjust enrichment to the Plaintiffs. In November 2025, the Appellate Court upheld the Court's ruling and dismissed the lawsuit on jurisdictional grounds.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001408710-26-000008:notes:162]
[same as prior period, unchanged from 0001408710-25-000056:notes:162]

[0001408710-26-000008:notes:163]
As of December 26, 2025, there was no restructuring liability balance.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001408710-26-000008:notes:164]
[same as prior period, unchanged from 0001408710-25-000056:notes:164]

[0001408710-26-000008:notes:165]
[same as prior period, unchanged from 0001408710-25-000056:notes:165]

[0001408710-26-000008:notes:166]
[same as prior period, unchanged from 0001408710-25-000056:notes:166]

[0001408710-26-000008:notes:167]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands of U.S. dollars, except per share data) | December 26,2025 |  | December 27,2024 |  | December 26,2025 |  | December 27,2024 |
| Revenues | $ | 1,132,888 |  |  | $ | 833,608 |  |  | $ | 2,111,016 |  |  | $ | 1,637,836 |  |
| Cost of revenues | (995,206) |  |  | (732,759) |  |  | (1,856,895) |  |  | (1,437,961) |  |
| Gross profit | 137,682 |  |  | 100,849 |  |  | 254,121 |  |  | 199,875 |  |
| Selling, general and administrative expenses | (23,281) |  |  | (21,206) |  |  | (45,527) |  |  | (43,237) |  |
| Restructuring and other related costs | — |  |  | (46) |  |  | — |  |  | (103) |  |
| Operating income | 114,401 |  |  | 79,597 |  |  | 208,594 |  |  | 156,535 |  |
| Interest income | 8,555 |  |  | 11,314 |  |  | 17,972 |  |  | 22,247 |  |
| Foreign exchange gain (loss), net | (3,214) |  |  | 4,042 |  |  | (5,274) |  |  | (3,053) |  |
| Other income (expense), net | (17) |  |  | (62) |  |  | (139) |  |  | (81) |  |
| Income before income taxes | 119,725 |  |  | 94,891 |  |  | 221,153 |  |  | 175,648 |  |
| Income tax expense | (7,097) |  |  | (8,255) |  |  | (12,599) |  |  | (11,618) |  |
| Net income | $ | 112,628 |  |  | $ | 86,636 |  |  | $ | 208,554 |  |  | $ | 164,030 |  |

[0001408710-26-000008:notes:168]
[same as prior period, unchanged from 0001408710-25-000056:notes:168]

[0001408710-26-000008:notes:169]
[same as prior period, unchanged from 0001408710-25-000056:notes:169]

[0001408710-26-000008:notes:170]
| (in thousands) |  | December 26,2025 |  | June 27,2025 |
| Long-Lived Assets: |  |  |  |  |
| Thailand |  | $ | 414,396 |  |  | $ | 338,127 |  |
| U.S. |  | 33,399 |  |  | 30,374 |  |
| China |  | 14,242 |  |  | 14,378 |  |
| Israel |  | 2,354 |  |  | 2,727 |  |
| Others |  | 639 |  |  | 802 |  |
| Total |  | $ | 465,030 |  |  | $ | 386,408 |  |

[0001408710-26-000008:notes:171]
[same as prior period, unchanged from 0001408710-25-000056:notes:171]

[0001408710-26-000008:notes:172]
The Company had two and three customers that each contributed to 10% or more of the Company's total trade accounts receivable as of December 26, 2025 and June 27, 2025, respectively.

[0001408710-26-000008:notes:173]
During the six months ended December 26, 2025 and December 27, 2024, the Company had three and two customers, respectively, that each contributed 10% or more of the Company's revenues. Such customers together accounted for 48.9% and 50.5% of the Company revenues during the respective periods.
