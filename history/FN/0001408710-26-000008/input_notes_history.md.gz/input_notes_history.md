# FN note change history — 0001408710-25-000056 → 0001408710-26-000008


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2026-02-03):
[0001408710-26-000008:note_history:1]
As of December 26, 2025 and June 27, 2025, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.5 million and $2.3 million, respectively, or Thai baht 77.3 million and 75.7 million, respectively. As of December 26, 2025, the Company had an outstanding bank guarantee on behalf of its subsidiary in China to support the subsidiary's operations of Chinese Renminbi ("RMB") 4.8 million and the bank guarantee was backed by cash collateral of $0.7 million. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the subsidiary's operations.

- changed (2026-02-03):
[0001408710-26-000008:note_history:2]
As of December 26, 2025, the Company had purchase obligations and other commitments to third parties of $1.94 billion.
  (was, 2025-11-04, similarity 0.9772):
[0001408710-25-000056:note_history:2]
As of September 26, 2025, the Company had purchase obligations and other commitments to third parties of $1.54 billion.

- changed (2026-02-03):
[0001408710-26-000008:note_history:3]
In February 2025, the Company entered into a construction contract with a local contractor for construction of a new manufacturing building at the Company's Chonburi campus. The contract price is approximately $132.5 million (Thai baht 4.45 billion).
  (was, 2025-11-04, similarity 0.6459):
[0001408710-25-000056:note_history:3]
manufacturing building at the Company's Chonburi campus. The contract price is approximately $132.5 million (Thai baht

- changed (2026-02-03):
[0001408710-26-000008:note_history:4]
As of December 26, 2025, the Company had total capital expenditure commitments to third parties of $193.7 million.
  (was, 2025-11-04, similarity 0.9761):
[0001408710-25-000056:note_history:4]
As of September 26, 2025, the Company had total capital expenditure commitments to third parties of $196.0 million.

- changed (2026-02-03):
[0001408710-26-000008:note_history:5]
During the three months ended December 27, 2024, the Borrowers and the Bank amended the 2023 Credit Facility Agreement to reduce the facility to $30.0 million, which may be used for, among other things, an overdraft facility. The Credit Facility will mature on August 20, 2039.
  (was, 2025-11-04, similarity 0.9025):
[0001408710-25-000056:note_history:5]
During the three months ended December 27, 2024, the Borrowers and the Bank amended the 2023 Credit Facility Agreement to reduce the facility to $30.0 million, which may be used for, among other things, an overdraft facility.

- changed (2026-02-03):
[0001408710-26-000008:note_history:6]
As of December 26, 2025, there was no amount outstanding under the 2023 Credit Facility Agreement.
  (was, 2025-11-04, similarity 0.9721):
[0001408710-25-000056:note_history:6]
As of September 26, 2025, there was no amount outstanding under the 2023 Credit Facility Agreement.

- changed (2026-02-03):
[0001408710-26-000008:note_history:7]
As of December 26, 2025, the Borrowers were in compliance with all of their financial covenants under the 2023 Credit Facility Agreement.
  (was, 2025-11-04, similarity 0.9805):
[0001408710-25-000056:note_history:7]
As of September 26, 2025, the Borrowers were in compliance with all of their financial covenants under the 2023 Credit Facility Agreement.

- changed (2026-02-03):
[0001408710-26-000008:note_history:8]
On June 28, 2024, Ngan In Leng and First Laser Limited (collectively, the “Plaintiffs”) filed a complaint in the Fuzhou Intermediate People’s Court (the “Court”) in Fuzhou, China against Fujian Enterprises (Holdings) Co., Ltd. (“FEHC”), Jian An Investment Limited (“Jian”), and Casix, Inc. (“Casix”), the Company's wholly-owned subsidiary located in the PRC. The complaint alleged unjust enrichment related to a purported investment in Casix by the Plaintiffs in 1997, which predates the Company's acquisition of Casix from JDS Uniphase Corporation. The Plaintiffs requested that the Court order FEHC to return the unjust enrichment to the Plaintiffs in the amount of RMB 400 million, with interest from March 1, 2000, and order Jian and Casix to bear joint and several liability for all payment obligations of FEHC.
  (was, 2025-11-04, similarity 0.8359):
[0001408710-25-000056:note_history:8]
On June 28, 2024, Ngan In Leng and First Laser Limited (collectively, the “Plaintiffs”) filed a complaint in the Fuzhou Intermediate People’s Court (the “Court”) in Fuzhou, China against Fujian Enterprises (Holdings) Co., Ltd. (“FEHC”), Jian An Investment Limited (“Jian”), and Casix, Inc. (“Casix”), the Company's wholly-owned subsidiary located in the PRC. The complaint alleges unjust enrichment related to a purported investment in Casix by the Plaintiffs in 1997, which predates the Company's acquisition of Casix from JDS Uniphase Corporation. The Plaintiffs have requested that the Court

- changed (2026-02-03):
[0001408710-26-000008:note_history:9]
In September 2024, the Court dismissed the complaint in its entirety based on jurisdictional grounds. The Plaintiffs subsequently appealed the Court’s ruling to the High People's Court of Fujian Province (the "Appellate Court"). In their appeal, the Plaintiffs claimed that Casix is the primary obligor to return the alleged unjust enrichment to the Plaintiffs. In November 2025, the Appellate Court upheld the Court's ruling and dismissed the lawsuit on jurisdictional grounds.
  (was, 2025-11-04, similarity 0.6628):
[0001408710-25-000056:note_history:9]
In September 2024, the Court dismissed the lawsuit in its entirety based on jurisdictional grounds. The Plaintiffs have since appealed the Court’s ruling to the High People's Court of Fujian Province (the "Appellate Court"). In their appeal, the Plaintiffs now claim that Casix is the primary obligor to return the alleged unjust enrichment to the Plaintiffs. On November 24, 2024, the Appellate Court agreed to hear the appeal. At this time, the Company is not able to quantify any potential liability in connection with this litigation because of the early stage of this litigation.

- removed (2026-02-03):
[0001408710-25-000056:note_history:10]
As of September 26, 2025 and June 27, 2025, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.4 million and $2.3 million, respectively, or Thai baht 77.3 million and 75.7 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the subsidiary's operations related to the Israeli Customs department.

- removed (2026-02-03):
[0001408710-25-000056:note_history:11]
In February 2025, the Company entered into a construction contract with a local contractor for construction of a new

- removed (2026-02-03):
[0001408710-25-000056:note_history:12]
4.45 billion).

- removed (2026-02-03):
[0001408710-25-000056:note_history:13]
order FEHC to return the unjust enrichment to the Plaintiffs in the amount of RMB 400 million, with interest from March 1, 2000, and order Jian and Casix to bear joint and several liability for all payment obligations of FEHC.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-02-03):
[0001408710-26-000008:note_history:14]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of December 26, 2025 and for the three and six months ended December 26, 2025 and December 27, 2024 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 27, 2025.
  (was, 2025-11-04, similarity 0.9669):
[0001408710-25-000056:note_history:14]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of September 26, 2025 and for the three months ended September 26, 2025 and September 27, 2024 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 27, 2025.

- changed (2026-02-03):
[0001408710-26-000008:note_history:15]
The results for the three and six months ended December 26, 2025 may not be indicative of results for the year ending June 26, 2026 or any future periods.
  (was, 2025-11-04, similarity 0.9537):
[0001408710-25-000056:note_history:15]
The results for the three months ended September 26, 2025 may not be indicative of results for the year ending June 26, 2026 or any future periods.

- changed (2026-02-03):
[0001408710-26-000008:note_history:16]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended December 26, 2025 and December 27, 2024 consisted of 13 weeks. Fiscal year 2026 will comprise 52 weeks and will end on June 26, 2026.
  (was, 2025-11-04, similarity 0.9692):
[0001408710-25-000056:note_history:16]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended September 26, 2025 and September 27, 2024 consisted of 13 weeks. Fiscal year 2026 will comprise 52 weeks and will end on June 26, 2026.

- changed (2026-02-03):
[0001408710-26-000008:note_history:17]
In November 2024, the FASB issued ASU 2024-03, “Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), Disaggregation of Income Statement Expenses,” which requires additional disclosure, in notes to financial statements, of specified information about certain costs and expenses in the same tabular format disclosure as the other disaggregation requirements in the amendments in this ASU. This ASU is effective for all entities for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027, with early adoption permitted. This ASU is effective for the Company's annual periods beginning June 26, 2027, and interim periods beginning July 1, 2028, and will be applied retrospectively to all prior periods presented in the financial statements. The Company is currently evaluating the ASU to determine its impact on the Company's disclosures.
  (was, 2025-11-04, similarity 0.8918):
[0001408710-25-000056:note_history:17]
In November 2024, the FASB issued ASU 2024-03, “Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), Disaggregation of Income Statement Expenses,” which requires additional notes to financial statements. This ASU requires entities to include certain current disclosures in the same tabular format disclosure as the other disaggregation requirements in the amendments in this ASU. This ASU is effective for all entities for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027, with early adoption permitted. This ASU is effective for the Company's annual periods beginning June 26, 2027, and interim periods beginning July 1, 2028, and will be applied retrospectively to all prior periods presented in the financial statements. The Company is currently evaluating the ASU to determine its impact on the Company's disclosures.

- removed (2026-02-03):
[0001408710-25-000056:note_history:18]
In July 2025, the FASB issued ASU 2025-05, “Financial Instruments – Credit Losses (Topic 326), Measurement of Credit Losses for Account Receivable and Contract Assets,” which requires the Company to consider available information that is relevant to assessing the collectibility of cash flows when developing an estimate of expected credit losses. The historical credit loss experience of financial assets with similar risk characteristics generally provides a basis for the Company's assessment of expected credit losses. However, the Company is required to consider adjustments to that information to reflect the extent to which management expects current conditions and reasonable and supportable forecasts to differ from the conditions that existed for the period over which historical information was evaluated. Those adjustments may be qualitative in nature and should reflect current conditions and forecasted changes related to relevant data (such as changes in unemployment rates, property values, commodity values, delinquency, or other factors that are associated with credit losses on the financial asset or in the group of financial assets). In addition, under current guidance, an entity would not consider collection activity after the balance sheet date when developing its estimate of expected credit losses. This ASU is effective for all entities for fiscal years beginning after December 15, 2025, and interim reporting periods within those fiscal year reporting periods, with early adoption permitted. The Company will adopt this guidance for its annual reporting period beginning June 27, 2026, and interim reporting periods within that annual reporting period, and does not expect the adoption to have a material impact on its consolidated financial statements.

- removed (2026-02-03):
[0001408710-25-000056:note_history:19]
In September 2025, the FASB issued ASU 2025-06, “Intangibles—Goodwill and Other—Internal-Use Software (Subtopic 350-40), Targeted Improvements to the Accounting for Internal-Use Software,” which requires the Company to remove all references to software development project stages so that the guidance is neutral to different software development methods, including methods that entities may use to develop software in the future. This ASU is effective for all entities for fiscal years beginning after December 15, 2027, and interim reporting periods within those fiscal year reporting periods, with early adoption permitted. The Company will adopt this guidance for its annual reporting period beginning July 1, 2028, and interim reporting periods within that annual reporting period, and does not expect the adoption to have a material impact on its consolidated financial statements.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-02-03):
[0001408710-26-000008:note_history:20]
The following table summarizes the cost and estimated fair value of debt securities classified as available-for-sale securities based on stated effective maturities as of December 26, 2025 and June 27, 2025:
  (was, 2025-11-04, similarity 0.9873):
[0001408710-25-000056:note_history:20]
The following table summarizes the cost and estimated fair value of debt securities classified as available-for-sale securities based on stated effective maturities as of September 26, 2025 and June 27, 2025:

- changed (2026-02-03):
[0001408710-26-000008:note_history:21]
|  | December 26, 2025 |  | June 27, 2025 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 108,054 |  |  | $ | 108,362 |  |  | $ | 128,958 |  |  | $ | 129,977 |  |
| Due between one to five years | 522,503 |  |  | 532,556 |  |  | 490,143 |  |  | 497,842 |  |
| Total | $ | 630,557 |  |  | $ | 640,918 |  |  | $ | 619,101 |  |  | $ | 627,819 |  |
  (was, 2025-11-04, similarity 0.9884):
[0001408710-25-000056:note_history:21]
|  | September 26, 2025 |  | June 27, 2025 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 116,496 |  |  | $ | 116,499 |  |  | $ | 128,958 |  |  | $ | 129,977 |  |
| Due between one to five years | 539,368 |  |  | 547,272 |  |  | 490,143 |  |  | 497,842 |  |
| Total | $ | 655,864 |  |  | $ | 663,771 |  |  | $ | 619,101 |  |  | $ | 627,819 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-02-03):
[0001408710-26-000008:note_history:22]
| (in thousands, except percentages) | Three Months EndedDecember 26, 2025 |  | As a % of TotalRevenues |  | Six Months EndedDecember 26, 2025 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 528,135 |  |  |  |  | $ | 947,960 |  |  |  |
| Others (1) | 2,694 |  |  |  |  | 4,886 |  |  |  |
| Total revenue in North America | 530,829 |  |  | 46.9 | % |  | 952,846 |  |  | 45.1 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 231,742 |  |  |  |  | 464,244 |  |  |  |
| India | 110,074 |  |  |  |  | 210,643 |  |  |  |
| Hong Kong | 41,060 |  |  |  |  | 77,583 |  |  |  |
| Malaysia | 37,221 |  |  |  |  | 59,984 |  |  |  |
| Thailand | 25,102 |  |  |  |  | 45,123 |  |  |  |
| China | 16,936 |  |  |  |  | 35,057 |  |  |  |
| Singapore | 18,032 |  |  |  |  | 37,752 |  |  |  |
| Japan | 10,839 |  |  |  |  | 21,420 |  |  |  |
| Others | 855 |  |  |  |  | 1,989 |  |  |  |
| Total revenue in Asia-Pacific and others | 491,861 |  |  | 43.4 | % |  | 953,795 |  |  | 45.2 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 62,267 |  |  |  |  | 115,195 |  |  |  |
| Finland | 17,014 |  |  |  |  | 29,539 |  |  |  |
| Germany | 11,314 |  |  |  |  | 23,032 |  |  |  |
| Others | 19,603 |  |  |  |  | 36,609 |  |  |  |
| Total revenue in Europe | $ | 110,198 |  |  | 9.7 | % |  | $ | 204,375 |  |  | 9.7 | % |
| Total revenue | $ | 1,132,888 |  |  | 100.0 | % |  | $ | 2,111,016 |  |  | 100.0 | % |
  (was, 2025-11-04, similarity 0.9553):
[0001408710-25-000056:note_history:22]
| (in thousands, except percentages) | Three Months EndedSeptember 26, 2025 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 27, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 419,825 |  |  |  |  | $ | 307,820 |  |  |  |
| Others (1) | 2,192 |  |  |  |  | 1,658 |  |  |  |
| Total revenue in North America | 422,017 |  |  | 43.1 | % |  | 309,478 |  |  | 38.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 232,502 |  |  |  |  | 290,953 |  |  |  |
| India | 100,569 |  |  |  |  | 76,830 |  |  |  |
| Hong Kong | 36,523 |  |  |  |  | 18,547 |  |  |  |
| Malaysia | 22,763 |  |  |  |  | 7,498 |  |  |  |
| Thailand | 20,021 |  |  |  |  | 11,121 |  |  |  |
| Singapore | 19,720 |  |  |  |  | 10,763 |  |  |  |
| China | 18,121 |  |  |  |  | 11,872 |  |  |  |
| Japan | 10,581 |  |  |  |  | 8,579 |  |  |  |
| Others | 1,134 |  |  |  |  | 475 |  |  |  |
| Total revenue in Asia-Pacific and others | 461,934 |  |  | 47.2 | % |  | 436,638 |  |  | 54.3 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 52,928 |  |  |  |  | 32,450 |  |  |  |
| Finland | 12,525 |  |  |  |  | 294 |  |  |  |
| Germany | 11,718 |  |  |  |  | 9,344 |  |  |  |
| Others | 17,006 |  |  |  |  | 16,024 |  |  |  |
| Total revenue in Europe | $ | 94,177 |  |  | 9.7 | % |  | $ | 58,112 |  |  | 7.2 | % |
| Total revenue | $ | 978,128 |  |  | 100.0 | % |  | $ | 804,228 |  |  | 100.0 | % |

- added (2026-02-03):
[0001408710-26-000008:note_history:23]
| (in thousands, except percentages) | Three Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 371,112 |  |  |  |  | $ | 678,932 |  |  |  |
| Others (1) | 1,291 |  |  |  |  | 2,949 |  |  |  |
| Total revenue in North America | 372,403 |  |  | 44.7 | % |  | 681,881 |  |  | 41.6 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 240,671 |  |  |  |  | 531,624 |  |  |  |
| India | 75,629 |  |  |  |  | 152,459 |  |  |  |
| Hong Kong | 20,415 |  |  |  |  | 38,962 |  |  |  |
| Thailand | 14,069 |  |  |  |  | 25,190 |  |  |  |
| China | 13,650 |  |  |  |  | 25,522 |  |  |  |
| Singapore | 12,481 |  |  |  |  | 23,244 |  |  |  |
| Japan | 8,976 |  |  |  |  | 17,555 |  |  |  |
| Malaysia | 7,565 |  |  |  |  | 15,063 |  |  |  |
| Others | 726 |  |  |  |  | 1,201 |  |  |  |
| Total revenue in Asia-Pacific and others | 394,182 |  |  | 47.3 | % |  | 830,820 |  |  | 50.7 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 39,262 |  |  |  |  | 71,712 |  |  |  |
| Germany | 10,867 |  |  |  |  | 20,211 |  |  |  |
| Others | 16,894 |  |  |  |  | 33,212 |  |  |  |
| Total revenue in Europe | $ | 67,023 |  |  | 8.0 | % |  | $ | 125,135 |  |  | 7.7 | % |
| Total revenue | $ | 833,608 |  |  | 100.0 | % |  | $ | 1,637,836 |  |  | 100.0 | % |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-02-03):
[0001408710-26-000008:note_history:24]
As of December 26, 2025 and June 27, 2025, the Company's contract assets were de minimis.
  (was, 2025-11-04, similarity 0.9682):
[0001408710-25-000056:note_history:24]
As of September 26, 2025 and June 27, 2025, the Company's contract assets were de minimis.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-02-03):
[0001408710-26-000008:note_history:25]
| (in thousands, except percentages) | Three Months EndedDecember 26, 2025 |  | As a % of TotalRevenues |  | Six Months EndedDecember 26, 2025 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 528,135 |  |  |  |  | $ | 947,960 |  |  |  |
| Others (1) | 2,694 |  |  |  |  | 4,886 |  |  |  |
| Total revenue in North America | 530,829 |  |  | 46.9 | % |  | 952,846 |  |  | 45.1 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 231,742 |  |  |  |  | 464,244 |  |  |  |
| India | 110,074 |  |  |  |  | 210,643 |  |  |  |
| Hong Kong | 41,060 |  |  |  |  | 77,583 |  |  |  |
| Malaysia | 37,221 |  |  |  |  | 59,984 |  |  |  |
| Thailand | 25,102 |  |  |  |  | 45,123 |  |  |  |
| China | 16,936 |  |  |  |  | 35,057 |  |  |  |
| Singapore | 18,032 |  |  |  |  | 37,752 |  |  |  |
| Japan | 10,839 |  |  |  |  | 21,420 |  |  |  |
| Others | 855 |  |  |  |  | 1,989 |  |  |  |
| Total revenue in Asia-Pacific and others | 491,861 |  |  | 43.4 | % |  | 953,795 |  |  | 45.2 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 62,267 |  |  |  |  | 115,195 |  |  |  |
| Finland | 17,014 |  |  |  |  | 29,539 |  |  |  |
| Germany | 11,314 |  |  |  |  | 23,032 |  |  |  |
| Others | 19,603 |  |  |  |  | 36,609 |  |  |  |
| Total revenue in Europe | $ | 110,198 |  |  | 9.7 | % |  | $ | 204,375 |  |  | 9.7 | % |
| Total revenue | $ | 1,132,888 |  |  | 100.0 | % |  | $ | 2,111,016 |  |  | 100.0 | % |
  (was, 2025-11-04, similarity 0.9553):
[0001408710-25-000056:note_history:25]
| (in thousands, except percentages) | Three Months EndedSeptember 26, 2025 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 27, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 419,825 |  |  |  |  | $ | 307,820 |  |  |  |
| Others (1) | 2,192 |  |  |  |  | 1,658 |  |  |  |
| Total revenue in North America | 422,017 |  |  | 43.1 | % |  | 309,478 |  |  | 38.5 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 232,502 |  |  |  |  | 290,953 |  |  |  |
| India | 100,569 |  |  |  |  | 76,830 |  |  |  |
| Hong Kong | 36,523 |  |  |  |  | 18,547 |  |  |  |
| Malaysia | 22,763 |  |  |  |  | 7,498 |  |  |  |
| Thailand | 20,021 |  |  |  |  | 11,121 |  |  |  |
| Singapore | 19,720 |  |  |  |  | 10,763 |  |  |  |
| China | 18,121 |  |  |  |  | 11,872 |  |  |  |
| Japan | 10,581 |  |  |  |  | 8,579 |  |  |  |
| Others | 1,134 |  |  |  |  | 475 |  |  |  |
| Total revenue in Asia-Pacific and others | 461,934 |  |  | 47.2 | % |  | 436,638 |  |  | 54.3 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 52,928 |  |  |  |  | 32,450 |  |  |  |
| Finland | 12,525 |  |  |  |  | 294 |  |  |  |
| Germany | 11,718 |  |  |  |  | 9,344 |  |  |  |
| Others | 17,006 |  |  |  |  | 16,024 |  |  |  |
| Total revenue in Europe | $ | 94,177 |  |  | 9.7 | % |  | $ | 58,112 |  |  | 7.2 | % |
| Total revenue | $ | 978,128 |  |  | 100.0 | % |  | $ | 804,228 |  |  | 100.0 | % |

- added (2026-02-03):
[0001408710-26-000008:note_history:26]
| (in thousands, except percentages) | Three Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 371,112 |  |  |  |  | $ | 678,932 |  |  |  |
| Others (1) | 1,291 |  |  |  |  | 2,949 |  |  |  |
| Total revenue in North America | 372,403 |  |  | 44.7 | % |  | 681,881 |  |  | 41.6 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 240,671 |  |  |  |  | 531,624 |  |  |  |
| India | 75,629 |  |  |  |  | 152,459 |  |  |  |
| Hong Kong | 20,415 |  |  |  |  | 38,962 |  |  |  |
| Thailand | 14,069 |  |  |  |  | 25,190 |  |  |  |
| China | 13,650 |  |  |  |  | 25,522 |  |  |  |
| Singapore | 12,481 |  |  |  |  | 23,244 |  |  |  |
| Japan | 8,976 |  |  |  |  | 17,555 |  |  |  |
| Malaysia | 7,565 |  |  |  |  | 15,063 |  |  |  |
| Others | 726 |  |  |  |  | 1,201 |  |  |  |
| Total revenue in Asia-Pacific and others | 394,182 |  |  | 47.3 | % |  | 830,820 |  |  | 50.7 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 39,262 |  |  |  |  | 71,712 |  |  |  |
| Germany | 10,867 |  |  |  |  | 20,211 |  |  |  |
| Others | 16,894 |  |  |  |  | 33,212 |  |  |  |
| Total revenue in Europe | $ | 67,023 |  |  | 8.0 | % |  | $ | 125,135 |  |  | 7.7 | % |
| Total revenue | $ | 833,608 |  |  | 100.0 | % |  | $ | 1,637,836 |  |  | 100.0 | % |

- changed (2026-02-03):
[0001408710-26-000008:note_history:27]
| (in thousands, except percentages) | Three Months EndedDecember 26, 2025 |  | As a % of TotalRevenues |  | Six Months EndedDecember 26, 2025 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Telecom | $ | 412,248 |  |  |  |  | $ | 747,968 |  |  |  |
| Datacom | 278,142 |  |  |  |  | 551,238 |  |  |  |
| Datacenter interconnect (1) | 142,200 |  |  |  |  | 280,280 |  |  |  |
| Total revenue - Optical communications | $ | 832,590 |  |  | 73.5 | % |  | $ | 1,579,486 |  |  | 74.8 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 116,956 |  |  |  |  | $ | 238,904 |  |  |  |
| Industrial laser | 41,432 |  |  |  |  | 81,111 |  |  |  |
| High-performance computing (2) | 85,556 |  |  |  |  | 100,959 |  |  |  |
| Others | 56,354 |  |  |  |  | 110,556 |  |  |  |
| Total revenue - Non-optical communications | $ | 300,298 |  |  | 26.5 | % |  | $ | 531,530 |  |  | 25.2 | % |
| Total revenue | $ | 1,132,888 |  |  | 100.0 | % |  | $ | 2,111,016 |  |  | 100.0 | % |
  (was, 2025-11-04, similarity 0.919):
[0001408710-25-000056:note_history:27]
| (in thousands, except percentages) | Three Months EndedSeptember 26, 2025 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 27, 2024 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Telecom | $ | 335,720 |  |  |  |  | $ | 225,627 |  |  |  |
| Datacom | 273,096 |  |  |  |  | 328,881 |  |  |  |
| Datacenter interconnect (1) | 138,080 |  |  |  |  | 71,807 |  |  |  |
| Total revenue - Optical communications | $ | 746,896 |  |  | 76.4 | % |  | $ | 626,315 |  |  | 77.9 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 121,948 |  |  |  |  | $ | 102,741 |  |  |  |
| Industrial laser | 39,679 |  |  |  |  | 35,326 |  |  |  |
| High-performance computing (2) | 15,403 |  |  |  |  | — |  |  |  |
| Others | 54,202 |  |  |  |  | 39,846 |  |  |  |
| Total revenue - Non-optical communications | $ | 231,232 |  |  | 23.6 | % |  | $ | 177,913 |  |  | 22.1 | % |
| Total revenue | $ | 978,128 |  |  | 100.0 | % |  | $ | 804,228 |  |  | 100.0 | % |

- added (2026-02-03):
[0001408710-26-000008:note_history:28]
| (in thousands, except percentages) | Three Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 299,101 |  |  |  |  | $ | 627,982 |  |  |  |
| Telecom | 248,010 |  |  |  |  | 473,637 |  |  |  |
| Datacenter interconnect (1) | 100,039 |  |  |  |  | 171,846 |  |  |  |
| Total revenue - Optical communications | $ | 647,150 |  |  | 77.6 | % |  | $ | 1,273,465 |  |  | 77.8 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 104,247 |  |  |  |  | $ | 206,988 |  |  |  |
| Industrial laser | 37,542 |  |  |  |  | 72,868 |  |  |  |
| Others | 44,669 |  |  |  |  | 84,515 |  |  |  |
| Total revenue - Non-optical communications | $ | 186,458 |  |  | 22.4 | % |  | $ | 364,371 |  |  | 22.2 | % |
| Total revenue | $ | 833,608 |  |  | 100.0 | % |  | $ | 1,637,836 |  |  | 100.0 | % |

- changed (2026-02-03):
[0001408710-26-000008:note_history:29]
As of December 26, 2025 and June 27, 2025, the Company's contract assets were de minimis.
  (was, 2025-11-04, similarity 0.9682):
[0001408710-25-000056:note_history:29]
As of September 26, 2025 and June 27, 2025, the Company's contract assets were de minimis.

- changed (2026-02-03):
[0001408710-26-000008:note_history:30]
The following tables summarize the activity in the Company’s contract liabilities during the six months ended December 26, 2025:
  (was, 2025-11-04, similarity 0.9478):
[0001408710-25-000056:note_history:30]
The following tables summarize the activity in the Company’s contract liabilities during the three months ended September 26, 2025:

- changed (2026-02-03):
[0001408710-26-000008:note_history:31]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 27, 2025 | $ | 14,467 |  |
| Advance payments received during the period | 17,855 |  |
| Revenue recognized | (14,883) |  |
| Ending balance, December 26, 2025 | $ | 17,439 |  |
  (was, 2025-11-04, similarity 0.9834):
[0001408710-25-000056:note_history:31]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 27, 2025 | $ | 14,467 |  |
| Advance payments received during the period | 4,074 |  |
| Revenue recognized | (8,765) |  |
| Ending balance, September 26, 2025 | $ | 9,776 |  |

- changed (2026-02-03):
[0001408710-26-000008:note_history:32]
For the three months ended December 26, 2025, the Company recognized $0.8 million as a reduction to revenue on the unaudited condensed consolidated statements of operations.
  (was, 2025-11-04, similarity 0.9849):
[0001408710-25-000056:note_history:32]
For the three months ended September 26, 2025, the Company recognized $0.3 million as a reduction to revenue on the unaudited condensed consolidated statements of operations.

- added (2026-02-03):
[0001408710-26-000008:note_history:33]
For the six months ended December 26, 2025, the Company recognized $1.1 million as a reduction to revenue on the unaudited condensed consolidated statements of operations.
