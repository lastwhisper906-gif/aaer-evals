# FN notes — 0001408710-23-000036


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001408710-23-000036:notes:1]
[same as prior period, unchanged from 0001408710-23-000018:notes:1]

[0001408710-23-000036:notes:2]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of September 29, 2023 and for the three months ended September 29, 2023 and September 30, 2022 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 30, 2023.

[0001408710-23-000036:notes:3]
The balance sheet as of June 30, 2023 has been derived from the audited financial statements at that date but does not include all of the information and footnotes required by U.S. GAAP for complete financial statements.

[0001408710-23-000036:notes:4]
The results for the three months ended September 29, 2023 may not be indicative of results for the year ending June 28, 2024 or any future periods.

[0001408710-23-000036:notes:5]
[same as prior period, unchanged from 0001408710-23-000018:notes:5]

[0001408710-23-000036:notes:6]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information.

[0001408710-23-000036:notes:7]
[same as prior period, unchanged from 0001408710-23-000018:notes:7]

[0001408710-23-000036:notes:8]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  September 29, 2023 and September 30, 2022 consisted of 13 and 14 weeks, respectively. Fiscal year 2024 will comprise 52 weeks and will end on June 28, 2024.

[0001408710-23-000036:notes:9]
Adoption of New Accounting Standards

[0001408710-23-000036:notes:10]
No new accounting standard was adopted in the first quarter of fiscal year 2024.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001408710-23-000036:notes:11]
[same as prior period, unchanged from 0001408710-23-000018:notes:10]

[0001408710-23-000036:notes:12]
[same as prior period, unchanged from 0001408710-23-000018:notes:11]

[0001408710-23-000036:notes:13]
[same as prior period, unchanged from 0001408710-23-000018:notes:12]

[0001408710-23-000036:notes:14]
| (in thousands, except percentages) | Three Months EndedSeptember 29, 2023 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 30, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 254,859 |  |  |  |  | $ | 345,080 |  |  |  |
| Others (1) | 3,460 |  |  |  |  | 3,624 |  |  |  |
| Total revenue in North America | 258,319 |  |  | 37.7 | % |  | 348,704 |  |  | 53.2 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel (2) | 210,676 |  |  |  |  | 37,277 |  |  |  |
| India | 70,777 |  |  |  |  | 80,033 |  |  |  |
| Malaysia | 33,319 |  |  |  |  | 49,324 |  |  |  |
| China | 20,260 |  |  |  |  | 23,064 |  |  |  |
| Hong Kong | 15,788 |  |  |  |  | 32,472 |  |  |  |
| Thailand | 13,027 |  |  |  |  | 12,616 |  |  |  |
| Japan | 6,810 |  |  |  |  | 10,348 |  |  |  |
| Others | 1,165 |  |  |  |  | 3,160 |  |  |  |
| Total revenue in Asia-Pacific and others | 371,822 |  |  | 54.2 | % |  | 248,294 |  |  | 37.9 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 29,774 |  |  |  |  | 32,832 |  |  |  |
| Germany | 12,780 |  |  |  |  | 13,314 |  |  |  |
| Others | 12,782 |  |  |  |  | 12,285 |  |  |  |
| Total revenue in Europe | $ | 55,336 |  |  | 8.1 | % |  | $ | 58,431 |  |  | 8.9 | % |
| Total revenue | $ | 685,477 |  |  | 100.0 | % |  | $ | 655,429 |  |  | 100.0 | % |

[0001408710-23-000036:notes:15]
[same as prior period, unchanged from 0001408710-23-000018:notes:15]

[0001408710-23-000036:notes:16]
(2)Due to increase in revenue from a significant customer.

[0001408710-23-000036:notes:17]
[same as prior period, unchanged from 0001408710-23-000018:notes:17]

[0001408710-23-000036:notes:18]
| (in thousands, except percentages) | Three Months EndedSeptember 29, 2023 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 30, 2022 |  | As a % of TotalRevenues |
| Optical communications | $ | 533,257 |  |  | 77.8 | % |  | $ | 497,561 |  |  | 75.9 | % |
| Automotive, lasers and other | 152,220 |  |  | 22.2 | % |  | 157,868 |  |  | 24.1 | % |
| Total | $ | 685,477 |  |  | 100.0 | % |  | $ | 655,429 |  |  | 100.0 | % |

[0001408710-23-000036:notes:19]
[same as prior period, unchanged from 0001408710-23-000018:notes:20]

[0001408710-23-000036:notes:20]
A contract asset is recognized when the Company has recognized revenues prior to an invoice for payment. Contract assets are recognized in the unaudited condensed consolidated balance sheets under other current assets and transferred to accounts receivable when rights to payment become unconditional.

[0001408710-23-000036:notes:21]
As of September 29, 2023 and June 30, 2023, the contract assets are de minimis.

[0001408710-23-000036:notes:22]
A contract liability is recognized when the Company has advance payment arrangements with customers. Contract liabilities are recognized in the unaudited condensed consolidated balance sheets under other payables. The contract liabilities balance is normally recognized as revenue within six months.

[0001408710-23-000036:notes:23]
The following tables summarize the activity in the Company’s contract liabilities during the three months ended September 29, 2023:

[0001408710-23-000036:notes:24]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 30, 2023 | $ | 3,036 |  |
| Advance payment received during the period | 1,497 |  |
| Revenue recognized | (3,285) |  |
| Ending balance, September 29, 2023 | $ | 1,248 |  |


## us-gaap:EarningsPerShareTextBlock

[0001408710-23-000036:notes:25]
[same as prior period, unchanged from 0001408710-23-000018:notes:26]

[0001408710-23-000036:notes:26]
[same as prior period, unchanged from 0001408710-23-000018:notes:27]

[0001408710-23-000036:notes:27]
|  |  |  | Three Months Ended |
| (in thousands, except per share data) |  |  |  |  | September 29,2023 |  | September 30,2022 |
| Net income attributable to shareholders |  |  |  |  | $ | 65,089 |  |  | $ | 64,615 |  |
| Weighted-average number of ordinary shares outstanding |  |  |  |  | 36,256 |  |  | 36,528 |  |
| Incremental shares arising from the assumed vesting of restricted share units and performance share units |  |  |  |  | 225 |  |  | 230 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share |  |  |  |  | 36,481 |  |  | 36,758 |  |
| Basic earnings per ordinary share |  |  |  |  | $ | 1.80 |  |  | $ | 1.77 |  |
| Diluted earnings per ordinary share |  |  |  |  | $ | 1.78 |  |  | $ | 1.76 |  |


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001408710-23-000036:notes:28]
[same as prior period, unchanged from 0001408710-23-000018:notes:29]

[0001408710-23-000036:notes:29]
|  |  |  | Fair Value |
| (in thousands) | CarryingCost |  | UnrealizedGain/(Loss) |  | Cash andCashEquivalents |  | MarketableSecurities |  | OtherInvestments |
| As of September 29, 2023 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 306,108 |  |  | $ | — |  |  | $ | 306,108 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 2,230 |  |  | — |  |  | 2,230 |  |  | — |  |  | — |  |
| Liquidity funds | 41,723 |  |  | — |  |  | — |  |  | — |  |  | 41,723 |  |
| Certificates of deposit and time deposits | 84,278 |  |  | 826 |  |  | — |  |  | 85,104 |  |  | — |  |
| Corporate debt securities | 145,138 |  |  | (3,007) |  |  | — |  |  | 142,131 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 93,618 |  |  | (148) |  |  | — |  |  | 93,470 |  |  | — |  |
| Total | $ | 673,095 |  |  | $ | (2,329) |  |  | $ | 308,338 |  |  | $ | 320,705 |  |  | $ | 41,723 |  |
| As of June 30, 2023 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 230,967 |  |  | $ | — |  |  | $ | 230,967 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 401 |  |  | — |  |  | 401 |  |  | — |  |  | — |  |
| Liquidity funds | 41,104 |  |  | — |  |  | — |  |  | — |  |  | 41,104 |  |
| Certificates of deposit and time deposits | 64,278 |  |  | 329 |  |  | — |  |  | 64,607 |  |  | — |  |
| Corporate debt securities | 161,453 |  |  | (3,375) |  |  | — |  |  | 158,078 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 55,542 |  |  | (231) |  |  | — |  |  | 55,311 |  |  | — |  |
| Total | $ | 553,745 |  |  | $ | (3,277) |  |  | $ | 231,368 |  |  | $ | 277,996 |  |  | $ | 41,104 |  |

[0001408710-23-000036:notes:30]
[same as prior period, unchanged from 0001408710-23-000018:notes:31]

[0001408710-23-000036:notes:31]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of September 29, 2023 and June 30, 2023:

[0001408710-23-000036:notes:32]
|  | September 29, 2023 |  | June 30, 2023 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 185,691 |  |  | $ | 186,414 |  |  | $ | 172,992 |  |  | $ | 173,137 |  |
| Due between one to five years | 179,066 |  |  | 176,014 |  |  | 149,385 |  |  | 145,963 |  |
| Total | $ | 364,757 |  |  | $ | 362,428 |  |  | $ | 322,377 |  |  | $ | 319,100 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001408710-23-000036:notes:33]
[same as prior period, unchanged from 0001408710-23-000018:notes:34]

[0001408710-23-000036:notes:34]
[same as prior period, unchanged from 0001408710-23-000018:notes:35]

[0001408710-23-000036:notes:35]
[same as prior period, unchanged from 0001408710-23-000018:notes:36]

[0001408710-23-000036:notes:36]
[same as prior period, unchanged from 0001408710-23-000018:notes:37]

[0001408710-23-000036:notes:37]
[same as prior period, unchanged from 0001408710-23-000018:notes:38]

[0001408710-23-000036:notes:38]
[same as prior period, unchanged from 0001408710-23-000018:notes:39]

[0001408710-23-000036:notes:39]
|  | Fair Value Measurements at Reporting Date Using |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of September 29, 2023 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 2,230 |  |  |  | $ | — |  |  | $ | 2,230 |  |
| Liquidity funds | — |  |  | 41,723 |  |  |  | — |  |  | 41,723 |  |
| Certificates of deposit and time deposits | — |  |  | 85,104 |  |  |  | — |  |  | 85,104 |  |
| Corporate debt securities | — |  |  | 142,131 |  |  |  | — |  |  | 142,131 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 93,470 |  |  |  | — |  |  | 93,470 |  |
| Derivative assets – current portion | — |  |  | 148 |  | (1) |  | — |  |  | 148 |  |
| Total | $ | — |  |  | $ | 364,806 |  |  |  | $ | — |  |  | $ | 364,806 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | (6,812) |  |  |  | $ | — |  |  | $ | (6,812) |  |
| Total | $ | — |  |  | $ | (6,812) |  | (2) |  | $ | — |  |  | $ | (6,812) |  |

[0001408710-23-000036:notes:40]
|  | Fair Value Measurements at Reporting Date Using |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of June 30, 2023 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 401 |  |  |  | $ | — |  |  | $ | 401 |  |
| Liquidity funds | — |  |  | 41,104 |  |  |  | — |  |  | 41,104 |  |
| Certificates of deposit and time deposits | — |  |  | 64,607 |  |  |  | — |  |  | 64,607 |  |
| Corporate debt securities | — |  |  | 158,078 |  |  |  | — |  |  | 158,078 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 55,311 |  |  |  | — |  |  | 55,311 |  |
| Derivative assets – current portion | — |  |  | 221 |  | (3) |  | — |  |  | 221 |  |
| Total | $ | — |  |  | $ | 319,722 |  |  |  | $ | — |  |  | $ | 319,722 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | (5,236) |  |  |  | $ | — |  |  | $ | (5,236) |  |
| Total | $ | — |  |  | $ | (5,236) |  | (4) |  | $ | — |  |  | $ | (5,236) |  |

[0001408710-23-000036:notes:41]
(1)Foreign currency forward contracts with an aggregate notional amount of $3.0 million and an interest rate swap agreement with a notional amount of $60.9 million.

[0001408710-23-000036:notes:42]
(2)Foreign currency forward contracts with an aggregate notional amount of $142.0 million and 0.2 million Canadian dollars.

[0001408710-23-000036:notes:43]
(3)Foreign currency forward contracts with an aggregate notional amount of $3.0 million and 0.2 million Canadian dollars and an interest rate swap agreement with a notional amount of $60.9 million.

[0001408710-23-000036:notes:44]
(4)Foreign currency forward contracts with an aggregate notional amount of $140.0 million.

[0001408710-23-000036:notes:45]
[same as prior period, unchanged from 0001408710-23-000018:notes:47]

[0001408710-23-000036:notes:46]
[same as prior period, unchanged from 0001408710-23-000018:notes:48]

[0001408710-23-000036:notes:47]
[same as prior period, unchanged from 0001408710-23-000018:notes:49]

[0001408710-23-000036:notes:48]
[same as prior period, unchanged from 0001408710-23-000018:notes:50]

[0001408710-23-000036:notes:49]
[same as prior period, unchanged from 0001408710-23-000018:notes:51]

[0001408710-23-000036:notes:50]
[same as prior period, unchanged from 0001408710-23-000018:notes:52]

[0001408710-23-000036:notes:51]
[same as prior period, unchanged from 0001408710-23-000018:notes:53]

[0001408710-23-000036:notes:52]
As of September 29, 2023, the Company had 145 outstanding U.S. dollar foreign currency forward contracts against Thai baht, with an aggregate notional amount of $145.0 million and maturity dates ranging from October 2023 through April 2024 and one outstanding Canadian dollar foreign currency forward contract with a notional amount of 0.2 million Canadian dollars and a maturity date in December 2023.

[0001408710-23-000036:notes:53]
As of June 30, 2023, the Company had 143 outstanding U.S. dollar foreign currency forward contracts against Thai baht with an aggregate notional amount of $143.0 million and maturity dates ranging from July 2023 through January 2024, and one foreign currency contract with a notional amount of 0.2 million Canadian dollars and with a maturity date in September 2023.

[0001408710-23-000036:notes:54]
As of September 29, 2023, the hedging relationship over foreign currency forward contracts designated for hedge accounting was determined to be highly effective based on the performance of retrospective and prospective regression testing. As of September 29, 2023, the amount in accumulated other comprehensive income (“AOCI”) expected to be reclassified into earnings within 12 months was a loss of $4.9 million.

[0001408710-23-000036:notes:55]
As of June 30, 2023, the hedging relationship over foreign currency forward contracts designated for hedge accounting had been tested to be highly effective based on the performance of retrospective and prospective regression testing. As of June 30, 2023, the amount in AOCI expected to be reclassified into earnings within 12 months was a loss of $4.0 million.

[0001408710-23-000036:notes:56]
During the three months ended September 29, 2023 and September 30, 2022, the Company included an unrealized gain of $0.3 million and unrealized loss of $0.2 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-23-000036:notes:57]
[same as prior period, unchanged from 0001408710-23-000018:notes:60]

[0001408710-23-000036:notes:58]
The Company entered into interest rate swap agreements to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. As of September 29, 2023 and June 30, 2023, the Company had one outstanding interest rate swap agreement with a notional amount of $60.9 million.

[0001408710-23-000036:notes:59]
On July 25, 2018, Fabrinet Thailand entered into an interest rate swap agreement to effectively convert the floating interest rate of the term loan under the Company's previous syndicated senior credit facility agreement to a fixed interest rate of 2.86% per annum through the scheduled maturity of the term loan in June 2023 (see Note 10). The Company did not designate this interest rate swap for hedge accounting.

[0001408710-23-000036:notes:60]
On September 3, 2019, Fabrinet Thailand entered into a term loan agreement under a credit facility agreement with Bank of Ayudhya Public Company Limited, and on September 10, 2019, the Company repaid in full the outstanding term loan under the Company's previous syndicated senior credit facility agreement (see Note 10). In conjunction with the funding of the new term loan, the Company entered into a second interest rate swap agreement. The combination of both of these interest rate swaps effectively converts the floating interest rate of the Company’s term loan with Bank of Ayudhya Public Company Limited to a fixed interest rate of 4.36% per annum through the maturity of the term loan in June 2024.

[0001408710-23-000036:notes:61]
On September 27, 2019, the Company designated these two interest rate swaps as a cash flow hedge for the Company’s term loan under the credit facility agreement with Bank of Ayudhya Public Company Limited. The combination of these two interest rate swaps qualified for hedge accounting because the hedges are highly effective, and the Company has designated and documented contemporaneously the hedging relationships involving these interest rate swaps. While the Company intends to continue to meet the conditions for hedge accounting, if hedges do not qualify as highly effective, the changes in the fair value of the derivatives used as hedges would be reflected in earnings. From September 27, 2019, any gains or losses related to these interest rate swaps are recorded in AOCI in the unaudited condensed consolidated balance sheets. The Company reclassifies a portion of the gains or losses from AOCI into earnings at each reporting period based on either the accrued interest amount or the interest payment.

[0001408710-23-000036:notes:62]
As of September 29, 2023, the amount in AOCI that is expected to be reclassified into earnings within 12 months was a gain of $0.3 million.

[0001408710-23-000036:notes:63]
As of June 30, 2023, the amount in AOCI that is expected to be reclassified into earnings within 12 months was a gain of $0.4 million.

[0001408710-23-000036:notes:64]
[same as prior period, unchanged from 0001408710-23-000018:notes:67]

[0001408710-23-000036:notes:65]
|  |  |  |  |  | Three Months Ended |
| (in thousands) | Financialstatementsline item |  |  |  |  |  | September 29,2023 |  | September 30,2022 |
| Derivatives gain (loss) recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Othercomprehensiveincome |  |  |  |  |  | $ | (1,565) |  |  | $ | (2,992) |  |
| Interest rate swaps | Othercomprehensiveincome |  |  |  |  |  | (78) |  |  | 516 |  |
| Total derivatives gain (loss) recognized in other comprehensive income (loss) |  |  |  |  |  |  | $ | (1,643) |  |  | $ | (2,476) |  |
| Derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings: |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Cost of revenues |  |  |  |  |  | $ | 3,672 |  |  | $ | 3,794 |  |
| Foreign currency forward contracts | SG&A |  |  |  |  |  | 155 |  |  | 160 |  |
| Foreign currency forward contracts | Foreign exchange loss, net |  |  |  |  |  | (3,215) |  |  | (2,505) |  |
| Interest rate swaps | Interest expense |  |  |  |  |  | (89) |  |  | (191) |  |
| Total derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings |  |  |  |  |  |  | $ | 523 |  |  | $ | 1,258 |  |
| Change in net unrealized gain (loss) on derivatives instruments |  |  |  |  |  |  | $ | (1,120) |  |  | $ | (1,218) |  |

[0001408710-23-000036:notes:66]
[same as prior period, unchanged from 0001408710-23-000018:notes:69]

[0001408710-23-000036:notes:67]
[same as prior period, unchanged from 0001408710-23-000018:notes:70]

[0001408710-23-000036:notes:68]
|  | September 29,2023 |  | June 30,2023 |
| (in thousands) | DerivativeAssets |  | DerivativeLiabilities |  | DerivativeAssets |  | DerivativeLiabilities |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts | $ | — |  |  | $ | (1,910) |  |  | $ | 2 |  |  | $ | (1,256) |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward contracts | 12 |  |  | (4,902) |  |  | 4 |  |  | (3,980) |  |
| Interest rate swaps | 136 |  |  | — |  |  | 215 |  |  | — |  |
| Derivatives, gross balances | $ | 148 |  |  | $ | (6,812) |  |  | $ | 221 |  |  | $ | (5,236) |  |

[0001408710-23-000036:notes:69]
[same as prior period, unchanged from 0001408710-23-000018:notes:72]

[0001408710-23-000036:notes:70]
[same as prior period, unchanged from 0001408710-23-000018:notes:73]


## us-gaap:InventoryDisclosureTextBlock

[0001408710-23-000036:notes:71]
[same as prior period, unchanged from 0001408710-23-000018:notes:74]

[0001408710-23-000036:notes:72]
| (in thousands) | As of September 29,2023 |  | As of June 30,2023 |
| Raw materials | $ | 119,200 |  |  | $ | 157,379 |  |
| Work in progress | 248,919 |  |  | 305,627 |  |
| Finished goods | 47,916 |  |  | 28,608 |  |
| Goods in transit | 24,060 |  |  | 27,962 |  |
| Total inventories | $ | 440,095 |  |  | $ | 519,576 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001408710-23-000036:notes:73]
Leases
The Company leases facilities under non-cancelable operating lease agreements. The Company leases a portion of its capital equipment and vehicles, certain land and buildings for its facilities in Thailand, the Cayman Islands, the PRC, the U.S., the U.K., Israel and Singapore under operating lease arrangements that expire at various dates through 2029. Certain of these lease arrangements provide the Company the ability to extend the lease from one to five years following the expiration of the current term. However, the Company has excluded all lease extension options from its right of use (“ROU”) assets and lease liabilities as the Company is not reasonably assured that it will exercise these options. None of the lease agreements contain residual value guarantees provided by the lessee. The Company also has one intercompany lease transaction in the form of a lease of office and manufacturing space.

[0001408710-23-000036:notes:74]
[same as prior period, unchanged from 0001408710-23-000018:notes:77]

[0001408710-23-000036:notes:75]
As of September 29, 2023, the maturities of the Company’s operating lease liabilities were as follows:

[0001408710-23-000036:notes:76]
| (in thousands) |  |  |
| 2024 (remaining nine months) | $ | 1,465 |  |  |
| 2025 | 1,136 |  |  |
| 2026 | 1,068 |  |  |
| 2027 | 1,093 |  |  |
| 2028 | 1,119 |  |  |
| Thereafter | 283 |  |  |
| Total undiscounted lease payments | 6,164 |  |  |
| Less imputed interest | (525) |  |  |
| Total present value of lease liabilities | $ | 5,639 |  | (1) |

[0001408710-23-000036:notes:77]
[same as prior period, unchanged from 0001408710-23-000018:notes:80]

[0001408710-23-000036:notes:78]
[same as prior period, unchanged from 0001408710-23-000018:notes:81]

[0001408710-23-000036:notes:79]
Rental expense for long-term leases for the three months ended September 29, 2023 and September 30, 2022 was $0.5 million and $0.6 million, respectively.

[0001408710-23-000036:notes:80]
Rental expense for short-term leases for the three months ended September 29, 2023 was $0.4 million and September 30, 2022 was immaterial.

[0001408710-23-000036:notes:81]
[same as prior period, unchanged from 0001408710-23-000018:notes:85]

[0001408710-23-000036:notes:82]
|  | As ofSeptember 29, 2023 |  | As ofJune 30, 2023 |
| Weighted-average remaining lease term (in years) | 4.5 |  | 1.2 |
| Weighted-average discount rate | 3.9 | % |  | 3.4 | % |

[0001408710-23-000036:notes:83]
The following table presents supplemental disclosure for the unaudited condensed consolidated statement of cash flows related to operating and finance leases for the three months ended September 29, 2023 and September 30, 2022:

[0001408710-23-000036:notes:84]
|  |  |  | Three Months Ended |
| (in thousands) |  |  |  |  | September 29,2023 |  | September 30,2022 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |
| Operating cash flows from operating leases |  |  |  |  | $ | 959 |  |  | $ | 641 |  |
| Financing cash flows from finance leases |  |  |  |  | $ | — |  |  | $ | 2 |  |
| ROU assets obtained in exchange for lease liabilities |  |  |  |  | $ | 4,936 |  |  | $ | — |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001408710-23-000036:notes:85]
[same as prior period, unchanged from 0001408710-23-000018:notes:89]

[0001408710-23-000036:notes:86]
| (in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  |  |  | Net |
| As of September 29, 2023 |  |  |  |  |  |  |  |
| Software | $ | 10,968 |  |  | $ | (8,370) |  |  |  |  | $ | 2,598 |  |

[0001408710-23-000036:notes:87]
| (in thousands) | GrossCarryingAmount |  | AccumulatedAmortization |  |  |  | Net |
| As of June 30, 2023 |  |  |  |  |  |  |  |
| Software | $ | 10,533 |  |  | $ | (8,139) |  |  |  |  | $ | 2,394 |  |

[0001408710-23-000036:notes:88]
The Company recorded amortization expense relating to intangibles of $0.2 million and $0.4 million for the three months ended September 29, 2023 and September 30, 2022, respectively.

[0001408710-23-000036:notes:89]
[same as prior period, unchanged from 0001408710-23-000018:notes:94]

[0001408710-23-000036:notes:90]
| (years) | As ofSeptember 29, 2023 |  | As ofJune 30, 2023 |
| Software | 2.6 |  | 3.1 |

[0001408710-23-000036:notes:91]
Based on the carrying amount of intangibles as of September 29, 2023, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001408710-23-000036:notes:92]
| (in thousands) |  |
| 2024 (remaining nine months) | $ | 1,206 |  |
| 2025 | 640 |  |
| 2026 | 435 |  |
| 2027 | 244 |  |
| 2028 | 73 |  |
| Total | $ | 2,598 |  |


## us-gaap:DebtDisclosureTextBlock

[0001408710-23-000036:notes:93]
Borrowings 
The Company’s total borrowings, including current and non-current portions of long-term borrowings, consisted of the following:

[0001408710-23-000036:notes:94]
| (in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofSeptember 29, 2023 |  | As ofJune 30, 2023 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 9,141 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (24) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 9,117 |  |  | $ | 12,156 |  |

[0001408710-23-000036:notes:95]
(1)The Company has entered into interest rate swaps that effectively fix a series of future interest payments on its term loans. Refer to Note 6.

[0001408710-23-000036:notes:96]
The movements of long-term borrowings for the three months ended September 29, 2023 and September 30, 2022 were as follows:

[0001408710-23-000036:notes:97]
|  | Three Months Ended |
| (in thousands) | September 29,2023 |  | September 30,2022 |
| Opening balance | $ | 12,188 |  |  | $ | 27,421 |  |
| Repayments during the period | (3,047) |  |  | (6,094) |  |
| Closing balance | $ | 9,141 |  |  | $ | 21,327 |  |

[0001408710-23-000036:notes:98]
As of September 29, 2023, future maturities of long-term borrowings during each fiscal year were as follows:

[0001408710-23-000036:notes:99]
| (in thousands) |  |
| 2024 (remaining nine months) | $ | 9,141 |  |

[0001408710-23-000036:notes:100]
Credit facility agreements:

[0001408710-23-000036:notes:101]
On August 20, 2019, Fabrinet Thailand (the “Borrower”) and Bank of Ayudhya Public Company Limited (the “Bank”) entered into a credit facility agreement (the “2019 Credit Facility Agreement”), which provides for a facility of 110.0 million Thai baht (approximately $3.6 million based on the applicable exchange rate as of September 27, 2019) and $160.9 million that may be used for, among other things, an overdraft facility, short-term loans against promissory notes, a letter of guarantee facility, a term loan facility and foreign exchange facilities. The Bank may approve any request for extension of credit under the 2019 Credit Facility Agreement and may increase or decrease any facility amount in its sole discretion.

[0001408710-23-000036:notes:102]
Under the 2019 Credit Facility Agreement, on August 20, 2019, the Borrower and the Bank entered into a term loan agreement (the "Term Loan Agreement") pursuant to which the Borrower drew down on September 3, 2019 a term loan in the original principal amount of $60.9 million. The proceeds from the term loan, together with cash on hand, were used to repay outstanding obligations under the Company's previous syndicated senior credit facility agreement.

[0001408710-23-000036:notes:103]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. On March 9, 2023, the Borrower and the Bank amended the Term Loan Agreement to replace the interest rate reference from LIBOR to the Secured Overnight Financing Rate ("SOFR") effective from September 29, 2023. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three months ended September 29, 2023, the Company recorded $0.1 million of interest expense in connection with this term loan, including the impact from interest rate swaps.

[0001408710-23-000036:notes:104]
Any borrowings under the 2019 Credit Facility Agreement, including those borrowings under the Term Loan Agreement, are guaranteed by Fabrinet and secured by land and buildings owned by the Borrower in the Pathumthani and Chonburi Provinces in Thailand.

[0001408710-23-000036:notes:105]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, and restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of September 29, 2023, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

[0001408710-23-000036:notes:106]
The events of default under the Term Loan Agreement include failure to timely pay amounts due under the Term Loan Agreement or the related finance documents, failure to comply with the covenants under the Term Loan Agreement or the related finance documents, cross default with other indebtedness of the Borrower, events of bankruptcy or insolvency in respect of the Borrower, and the occurrence of any event or series of events that in the opinion of the Bank has or is reasonably likely to have a material adverse effect.

[0001408710-23-000036:notes:107]
As of September 29, 2023, there was $9.1 million outstanding under the term loan.

[0001408710-23-000036:notes:108]
On March 9, 2023, Fabrinet Thailand and the Parent Company (the “Borrowers”) and the Bank entered into a credit facility agreement (the “2023 Credit Facility Agreement”), which provides a facility of $55.0 million.

[0001408710-23-000036:notes:109]
Any borrowings under the 2023 Credit Facility Agreement are secured by land and buildings owned by the Borrowers in the Pathumthani and Chonburi Provinces in Thailand.

[0001408710-23-000036:notes:110]
Under the 2023 Credit Facility Agreement, the Borrowers are required to maintain a loan to value of the mortgaged real property ratio of not greater than 60%. The Borrowers are also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times.

[0001408710-23-000036:notes:111]
As of September 29, 2023, there was no amount outstanding under the 2023 Credit Facility Agreement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001408710-23-000036:notes:112]
Income taxes
As of September 29, 2023 and June 30, 2023, the liability for uncertain tax positions including accrued interest and penalties was $1.4 million and $1.5 million, respectively. The Company expects the estimated amount of liability associated with its uncertain tax positions to increase within the next 12 months due to additional provisions on uncertain tax positions from one of the subsidiaries and interest on these positions.

[0001408710-23-000036:notes:113]
The Company files income tax returns in the United States and foreign tax jurisdictions. The tax years from 2016 to 2022 remain open to examination by U.S. federal and state, and foreign tax authorities. The Company’s income tax is recognized based on the best estimate of the expected annual effective tax rate for the full financial year of each entity in the Company, adjusted for discrete items arising in that quarter. If the Company’s estimated annual effective tax rate changes, the Company makes a cumulative adjustment in that quarter.

[0001408710-23-000036:notes:114]
The effective tax rate for the Company for the three months ended September 29, 2023 and September 30, 2022 was 7.2% and 1.1%, respectively, of net income. The increase was due to an increase in income subject to tax during the three months ended September 29, 2023 as compared to the three months ended September 30, 2022. In addition, a full valuation allowance of $2.1 million for deferred tax assets was set up during the three months ended September 29, 2023 due to management's belief that the Company's subsidiary in Israel would continue to have losses in the foreseeable future such that the deferred tax assets of such subsidiary would not be utilized.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001408710-23-000036:notes:115]
[same as prior period, unchanged from 0001408710-23-000018:notes:122]

[0001408710-23-000036:notes:116]
[same as prior period, unchanged from 0001408710-23-000018:notes:123]

[0001408710-23-000036:notes:117]
The effect of recording share-based compensation expense for the three months ended September 29, 2023 and September 30, 2022 was as follows:

[0001408710-23-000036:notes:118]
|  |  |  | Three Months Ended |
| (in thousands) |  |  |  |  | September 29,2023 |  | September 30,2022 |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |
| Restricted share units |  |  |  |  | $ | 4,879 |  |  | $ | 4,901 |  |
| Performance share units |  |  |  |  | 2,854 |  |  | 2,822 |  |
| Total share-based compensation expense |  |  |  |  | 7,733 |  |  | 7,723 |  |
| Tax effect on share-based compensation expense |  |  |  |  | — |  |  | — |  |
| Net effect on share-based compensation expense |  |  |  |  | $ | 7,733 |  |  | $ | 7,723 |  |

[0001408710-23-000036:notes:119]
[same as prior period, unchanged from 0001408710-23-000018:notes:126]

[0001408710-23-000036:notes:120]
|  |  |  | Three Months Ended |
| (in thousands) |  |  |  |  | September 29,2023 |  | September 30,2022 |
| Cost of revenue |  |  |  |  | $ | 2,165 |  |  | $ | 1,915 |  |
| Selling, general and administrative expense |  |  |  |  | 5,568 |  |  | 5,808 |  |
| Total share-based compensation expense |  |  |  |  | $ | 7,733 |  |  | $ | 7,723 |  |

[0001408710-23-000036:notes:121]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the three months ended September 29, 2023 and September 30, 2022.

[0001408710-23-000036:notes:122]
[same as prior period, unchanged from 0001408710-23-000018:notes:129]

[0001408710-23-000036:notes:123]
[same as prior period, unchanged from 0001408710-23-000018:notes:130]

[0001408710-23-000036:notes:124]
On November 2, 2017, the Company adopted the 2017 Inducement Equity Incentive Plan (the “2017 Inducement Plan”) with a reserve of 160,000 ordinary shares authorized for future issuance solely for the granting of inducement share options and equity awards to new employees. The 2017 Inducement Plan was adopted without shareholder approval in reliance on the “employment inducement exemption” provided under the New York Stock Exchange Listed Company Manual.

[0001408710-23-000036:notes:125]
[same as prior period, unchanged from 0001408710-23-000018:notes:134]

[0001408710-23-000036:notes:126]
The following table summarizes the number of equity awards outstanding and ordinary shares available for grant under each of the Equity Incentive Plans as of September 29, 2023:

[0001408710-23-000036:notes:127]
| (share units) | Restricted Share Units outstanding |  | Performance Share Units outstanding |  | Ordinary Shares available for future grant |
| 2020 Plan | 320,011 |  |  | 171,078 |  |  | 1,777,609 |  |
| 2017 Inducement Plan | — |  |  | — |  |  | 111,347 |  |
| Total | 320,011 |  |  | 171,078 |  |  | 1,888,956 |  |

[0001408710-23-000036:notes:128]
[same as prior period, unchanged from 0001408710-23-000018:notes:137]

[0001408710-23-000036:notes:129]
[same as prior period, unchanged from 0001408710-23-000018:notes:138]

[0001408710-23-000036:notes:130]
[same as prior period, unchanged from 0001408710-23-000018:notes:139]

[0001408710-23-000036:notes:131]
[same as prior period, unchanged from 0001408710-23-000018:notes:140]

[0001408710-23-000036:notes:132]
[same as prior period, unchanged from 0001408710-23-000018:notes:141]

[0001408710-23-000036:notes:133]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 30, 2023 | 368,765 |  |  | $ | 97.49 |  |
| Granted | 95,393 |  |  | $ | 158.91 |  |
| Vested | (139,438) |  |  | $ | 85.02 |  |
| Forfeited | (4,709) |  |  | $ | 108.19 |  |
| Balance as of September 29, 2023 | 320,011 |  |  | $ | 121.07 |  |

[0001408710-23-000036:notes:134]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 24, 2022 | 459,626 |  |  | $ | 75.14 |  |
| Granted | 122,743 |  |  | $ | 117.35 |  |
| Vested | (180,824) |  |  | $ | 64.19 |  |
| Forfeited | (9,446) |  |  | $ | 90.47 |  |
| Balance as of September 30, 2022 | 392,099 |  |  | $ | 93.03 |  |

[0001408710-23-000036:notes:135]
[same as prior period, unchanged from 0001408710-23-000018:notes:144]

[0001408710-23-000036:notes:136]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 30, 2023 | 204,016 |  |  | $ | 108.81 |  |
| Granted | 73,936 |  |  | $ | 158.91 |  |
| Vested | (106,874) |  |  | $ | 101.05 |  |
| Forfeited | — |  |  | $ | — |  |
| Balance as of September 29, 2023 | 171,078 |  |  | $ | 135.31 |  |

[0001408710-23-000036:notes:137]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 24, 2022 | 285,882 |  |  | $ | 81.64 |  |
| Granted | 97,142 |  |  | $ | 117.35 |  |
| Vested | (179,008) |  |  | 70.05 |  |
| Forfeited | — |  |  | $ | — |  |
| Balance as of September 30, 2022 | 204,016 |  |  | $ | 108.81 |  |

[0001408710-23-000036:notes:138]
[same as prior period, unchanged from 0001408710-23-000018:notes:147]

[0001408710-23-000036:notes:139]
As of September 29, 2023, there was $21.3 million and $15.5 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.9 and 1.5 years, respectively.

[0001408710-23-000036:notes:140]
For the three months ended September 29, 2023 and September 30, 2022, the Company withheld an aggregate of 99,518 shares and 162,985 shares, respectively, upon the vesting of restricted share units and performance shares units, based upon the closing share price on the vesting date to settle employee tax withholding obligations. For the three months ended September 29, 2023 and September 30, 2022, the Company then remitted cash of $12.1 million and $16.5 million, respectively, to the appropriate taxing authorities and presented it as a financing activity within the unaudited condensed consolidated statements of cash flows. The payment was recorded as a reduction of additional paid-in capital.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001408710-23-000036:notes:141]
[same as prior period, unchanged from 0001408710-23-000018:notes:150]

[0001408710-23-000036:notes:142]
[same as prior period, unchanged from 0001408710-23-000018:notes:151]

[0001408710-23-000036:notes:143]
For the three months ended September 29, 2023, Fabrinet issued 146,794 ordinary shares upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-23-000036:notes:144]
For the three months ended September 30, 2022, Fabrinet issued 196,847 ordinary shares upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-23-000036:notes:145]
[same as prior period, unchanged from 0001408710-23-000018:notes:154]

[0001408710-23-000036:notes:146]
[same as prior period, unchanged from 0001408710-23-000018:notes:155]

[0001408710-23-000036:notes:147]
In August 2017, the Company’s board of directors approved a share repurchase program to permit the Company to repurchase up to $30.0 million worth of its issued and outstanding ordinary shares in the open market in accordance with applicable rules and regulations. In February 2018, May 2019, August 2020, August 2022, and August 2023, the Company’s board of directors approved an increase of $30.0 million, $50.0 million, $58.5 million, $78.7 million, and  $47.6 million, respectively, to the original share repurchase authorization, bringing the aggregate authorization to $294.8 million.

[0001408710-23-000036:notes:148]
During the three months ended September 29, 2023, the Company did not repurchase any shares. As of September 29, 2023, the Company had a remaining authorization to repurchase up to $100.0 million worth of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001408710-23-000036:notes:149]
Accumulated other comprehensive income (loss)
The changes in AOCI for the three months ended September 29, 2023 and September 30, 2022 were as follows:

[0001408710-23-000036:notes:150]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 30, 2023 | $ | (3,279) |  |  | $ | (3,541) |  |  | $ | (330) |  |  | $ | (965) |  |  | $ | (8,115) |  |
| Other comprehensive income (loss) before reclassification | 948 |  |  | (1,643) |  |  | — |  |  | 100 |  |  | (595) |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | — |  |  | 523 |  |  | 90 |  |  | — |  |  | 613 |  |
| Tax effects | — |  |  | 559 |  |  | 36 |  |  | — |  |  | 595 |  |
| Other comprehensive income (loss) | $ | 948 |  |  | $ | (561) |  |  | $ | 126 |  |  | $ | 100 |  |  | $ | 613 |  |
| Balance as of September 29, 2023 | $ | (2,331) |  |  | $ | (4,102) |  |  | $ | (204) |  |  | $ | (865) |  |  | $ | (7,502) |  |

[0001408710-23-000036:notes:151]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 24, 2022 | $ | (6,018) |  |  | $ | (5,082) |  |  | $ | (803) |  |  | $ | (890) |  |  | $ | (12,793) |  |
| Other comprehensive income (loss) before reclassification | (1,553) |  |  | (2,476) |  |  | — |  |  | 246 |  |  | (3,783) |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | 92 |  |  | 1,258 |  |  | 168 |  |  | — |  |  | 1,518 |  |
| Tax effects | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Other comprehensive income (loss) | $ | (1,461) |  |  | $ | (1,218) |  |  | $ | 168 |  |  | $ | 246 |  |  | $ | (2,265) |  |
| Balance as of September 30, 2022 | $ | (7,479) |  |  | $ | (6,300) |  |  | $ | (635) |  |  | $ | (644) |  |  | $ | (15,058) |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001408710-23-000036:notes:152]
Commitments and contingencies
Bank guarantees

[0001408710-23-000036:notes:153]
As of September 29, 2023 and June 30, 2023, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.0 million and $1.5 million, respectively, or Thai baht 73.2 million and 53.0 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the operations related to the Israeli Customs department.

[0001408710-23-000036:notes:154]
Purchase obligations

[0001408710-23-000036:notes:155]
Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001408710-23-000036:notes:156]
As of September 29, 2023, the Company had purchase obligations and other commitments to third parties of $1.22 billion.

[0001408710-23-000036:notes:157]
Capital expenditures

[0001408710-23-000036:notes:158]
As of September 29, 2023, the Company had total capital expenditure commitments to third parties of $12.3 million.

[0001408710-23-000036:notes:159]
Indemnification of directors and officers

[0001408710-23-000036:notes:160]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001408710-23-000036:notes:161]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001408710-23-000036:notes:162]
Business segments and geographic information
Operating segments are defined as components of an enterprise that engage in business activities for which discrete financial information is available that is evaluated regularly by the chief operating decision maker (the “CODM”) in deciding how to allocate resources and in assessing performance. The Company’s CODM is Fabrinet’s Chief Executive Officer. As of September 29, 2023, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001408710-23-000036:notes:163]
[same as prior period, unchanged from 0001408710-23-000018:notes:173]

[0001408710-23-000036:notes:164]
[same as prior period, unchanged from 0001408710-23-000018:notes:174]

[0001408710-23-000036:notes:165]
| (in thousands) |  | September 29,2023 |  | June 30,2023 |
| Long-Lived Assets: |  |  |  |  |
| Thailand |  | $ | 261,117 |  |  | $ | 264,382 |  |
| U.S. |  | 25,538 |  |  | 25,267 |  |
| China |  | 16,531 |  |  | 17,407 |  |
| Israel |  | 2,998 |  |  | 2,796 |  |
| Others |  | 481 |  |  | 498 |  |
| Total |  | $ | 306,665 |  |  | $ | 310,350 |  |

[0001408710-23-000036:notes:166]
[same as prior period, unchanged from 0001408710-23-000018:notes:176]

[0001408710-23-000036:notes:167]
The Company had three customers that each contributed to 10% or more of the Company's total trade accounts receivable as of September 29, 2023 and June 30, 2023.
