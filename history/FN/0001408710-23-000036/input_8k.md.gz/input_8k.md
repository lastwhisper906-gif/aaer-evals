# FN 8-K — 0001408710-23-000034 filed 2023-11-06

## item codes, every 8-K on or before 2023-11-07

- 2023-11-06 0001408710-23-000034 — 2.02, 9.01
- 2023-08-21 0001408710-23-000026 — 2.02, 5.02, 9.01
- 2023-05-08 0001408710-23-000016 — 2.02, 5.02, 9.01
- 2023-02-06 0001408710-23-000006 — 2.02, 9.01
- 2022-12-13 0001408710-22-000062 — 5.07
- 2022-11-07 0001408710-22-000058 — 2.02, 9.01
- 2022-08-15 0001408710-22-000041 — 2.02, 5.02, 9.01
- 2022-05-02 0001408710-22-000026 — 2.02, 9.01
- 2022-01-31 0001408710-22-000016 — 2.02, 9.01
- 2022-01-19 0001408710-22-000010 — 5.02
- 2022-01-06 0001408710-22-000006 — 5.02
- 2021-12-10 0001408710-21-000051 — 5.07
- 2021-11-01 0001408710-21-000045 — 2.02, 9.01
- 2021-08-16 0001408710-21-000031 — 2.02, 5.02, 9.01
- 2021-05-03 0001408710-21-000019 — 2.02, 9.01
- 2021-02-01 0001408710-21-000008 — 2.02, 9.01
- 2020-12-11 0001193125-20-315861 — 5.07
- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2023-11-07

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001408710-23-000034:8k_2_02:1]
EX-99.1
2
fn-20231106xex991q124.htm
EX-99.1

[0001408710-23-000034:8k_2_02:2]
Document

[0001408710-23-000034:8k_2_02:3]
Exhibit 99.1

[0001408710-23-000034:8k_2_02:4]
Fabrinet Announces First Quarter Fiscal Year 2024 Financial Results

[0001408710-23-000034:8k_2_02:5]
•Record Revenue and Net Income Per Share Exceed Guidance Ranges

[0001408710-23-000034:8k_2_02:6]
BANGKOK, Thailand – November 6, 2023 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its first fiscal quarter ended September 29, 2023.

[0001408710-23-000034:8k_2_02:7]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “We had a very strong start to the year with revenue and net income per share that were above our guidance ranges, and also marked new quarterly records. Industry-wide inventory adjustments continue to affect certain programs, but these declines were more than offset by quickly ramping new programs. We continue to carefully manage costs, which resulted in strong bottom-line results. We expect to extend our strong execution into the second quarter, as reflected in our guidance.”

[0001408710-23-000034:8k_2_02:8]
First Quarter Fiscal Year 2024 Financial Highlights

[0001408710-23-000034:8k_2_02:9]
GAAP Results

[0001408710-23-000034:8k_2_02:10]
•Revenue for the first quarter of fiscal year 2024, a thirteen-week quarter, was $685.5 million, compared to $655.4 million for the first quarter of fiscal year 2023, a fourteen-week quarter.

[0001408710-23-000034:8k_2_02:11]
•GAAP net income for the first quarter of fiscal year 2024 was $65.1 million, compared to $64.6 million for the first quarter of fiscal year 2023.

[0001408710-23-000034:8k_2_02:12]
•GAAP net income per diluted share for the first quarter of fiscal year 2024 was $1.78, compared to $1.76 for the first quarter of fiscal year 2023.

[0001408710-23-000034:8k_2_02:13]
Non-GAAP Results

[0001408710-23-000034:8k_2_02:14]
•Non-GAAP net income for the first quarter of fiscal year 2024 was $72.8 million, compared to $72.4 million for the first quarter of fiscal year 2023.

[0001408710-23-000034:8k_2_02:15]
•Non-GAAP net income per diluted share for the first quarter of fiscal year 2024 was $2.00, compared to $1.97 for the first quarter of fiscal year 2023.

[0001408710-23-000034:8k_2_02:16]
Business Outlook

[0001408710-23-000034:8k_2_02:17]
Based on information available as of November 6, 2023, Fabrinet is issuing guidance for its second fiscal quarter ending December 29, 2023, as follows:

[0001408710-23-000034:8k_2_02:18]
•Fabrinet expects second quarter revenue to be in the range of $680 million to $700 million.

[0001408710-23-000034:8k_2_02:19]
•GAAP net income per diluted share is expected to be in the range of $1.78 to $1.85, based on approximately 36.5 million fully diluted shares outstanding.

[0001408710-23-000034:8k_2_02:20]
•Non-GAAP net income per diluted share is expected to be in the range of $1.98 to $2.05, based on approximately 36.5 million fully diluted shares outstanding.

[0001408710-23-000034:8k_2_02:21]
Guidance for non-GAAP net income per diluted share excludes share-based compensation expenses and certain non-recurring items. A reconciliation of non-GAAP net income per diluted share to the corresponding GAAP measure is available at the end of this press release.

[0001408710-23-000034:8k_2_02:22]
Conference Call Information

[0001408710-23-000034:8k_2_02:23]
| What: |  | Fabrinet First Quarter Fiscal Year 2024 Financial Results Call |
| When: |  | November 6, 2023 |
| Time: |  | 5:00 p.m. ET |
| Live Call and Replay: |  | https://investor.fabrinet.com/events-and-presentations/events |

[0001408710-23-000034:8k_2_02:24]
A recorded version of this webcast will be available approximately two hours after the call and accessible at http://investor.fabrinet.com. The webcast will be archived on Fabrinet’s website for a period of one year.

[0001408710-23-000034:8k_2_02:25]
About Fabrinet

[0001408710-23-000034:8k_2_02:26]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China, and Israel. For more information visit: www.fabrinet.com.

[0001408710-23-000034:8k_2_02:27]
Forward-Looking Statements

[0001408710-23-000034:8k_2_02:28]
Use of Non-GAAP Financials

[0001408710-23-000034:8k_2_02:29]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; amortization of intangibles; and amortization of deferred debt issuance costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001408710-23-000034:8k_2_02:30]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, some of these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001408710-23-000034:8k_2_02:31]
Investor Contact:

[0001408710-23-000034:8k_2_02:32]
Garo Toomajanian

[0001408710-23-000034:8k_2_02:33]
ir@fabrinet.com

[0001408710-23-000034:8k_2_02:34]
FABRINET

[0001408710-23-000034:8k_2_02:35]
CONDENSED CONSOLIDATED BALANCE SHEETS (unaudited)

[0001408710-23-000034:8k_2_02:36]
| (in thousands of U.S. dollars, except share data and par value) | September 29,2023 |  | June 30,2023 |
| Assets |  |  |  |
| Current assets |  |  |  |
| Cash and cash equivalents | $ | 308,338 |  |  | $ | 231,368 |  |
| Short-term investments | 362,428 |  |  | 319,100 |  |
| Trade accounts receivable, net of allowance for doubtful accounts of $1,768 and $965, respectively | 535,006 |  |  | 531,767 |  |
| Inventories | 440,095 |  |  | 519,576 |  |
| Prepaid expenses | 6,328 |  |  | 7,849 |  |
| Other current assets | 39,766 |  |  | 42,880 |  |
| Total current assets | 1,691,961 |  |  | 1,652,540 |  |
| Non-current assets |  |  |  |
| Property, plant and equipment, net | 306,665 |  |  | 310,350 |  |
| Intangibles, net | 2,598 |  |  | 2,394 |  |
| Operating right-of-use assets | 6,024 |  |  | 1,634 |  |
| Deferred tax assets | 11,363 |  |  | 12,095 |  |
| Other non-current assets | 610 |  |  | 635 |  |
| Total non-current assets | 327,260 |  |  | 327,108 |  |
| Total Assets | $ | 2,019,221 |  |  | $ | 1,979,648 |  |
| Liabilities and Shareholders’ Equity |  |  |  |
| Current liabilities |  |  |  |
| Long-term borrowings, current portion, net | $ | 9,117 |  |  | $ | 12,156 |  |
| Trade accounts payable | 357,106 |  |  | 381,129 |  |
| Fixed assets payable | 9,313 |  |  | 13,526 |  |
| Operating lease liabilities, current portion | 1,587 |  |  | 1,201 |  |
| Income tax payable | 7,013 |  |  | 6,024 |  |
| Accrued payroll, bonus and related expenses | 22,976 |  |  | 23,748 |  |
| Accrued expenses | 24,034 |  |  | 20,447 |  |
| Other payables | 24,287 |  |  | 23,654 |  |
| Total current liabilities | 455,433 |  |  | 481,885 |  |
| Non-current liabilities |  |  |  |
| Deferred tax liability | 5,117 |  |  | 4,799 |  |
| Operating lease liability, non-current portion | 4,052 |  |  | 66 |  |
| Severance liabilities | 22,269 |  |  | 22,159 |  |
| Other non-current liabilities | 2,181 |  |  | 2,081 |  |
| Total non-current liabilities | 33,619 |  |  | 29,105 |  |
| Total Liabilities | 489,052 |  |  | 510,990 |  |
| Shareholders’ equity |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of September 29, 2023 and June 30, 2023) | — |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 39,430,970 shares and 39,284,176 shares issued at September 29, 2023 and June 30, 2023, respectively; and 36,330,476 shares and 36,183,682 shares outstanding at September 29, 2023 and June 30, 2023, respectively) | 394 |  |  | 393 |  |
| Additional paid-in capital | 202,432 |  |  | 206,624 |  |
| Less: Treasury shares (3,100,494 shares as of September 29, 2023 and June 30, 2023) | (194,833) |  |  | (194,833) |  |
| Accumulated other comprehensive income (loss) | (7,502) |  |  | (8,115) |  |
| Retained earnings | 1,529,678 |  |  | 1,464,589 |  |
| Total Shareholders’ Equity | 1,530,169 |  |  | 1,468,658 |  |
| Total Liabilities and Shareholders’ Equity | $ | 2,019,221 |  |  | $ | 1,979,648 |  |

[0001408710-23-000034:8k_2_02:37]
FABRINET

[0001408710-23-000034:8k_2_02:38]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME (unaudited)

[0001408710-23-000034:8k_2_02:39]
|  |  |  | Three Months Ended |
| (in thousands of U.S. dollars, except per share data) |  |  |  |  | September 29,2023 |  | September 30,2022 |
| Revenues |  |  |  |  | $ | 685,477 |  |  | $ | 655,429 |  |
| Cost of revenues |  |  |  |  | (601,073) |  |  | (572,673) |  |
| Gross profit |  |  |  |  | 84,404 |  |  | 82,756 |  |
| Selling, general and administrative expenses |  |  |  |  | (20,429) |  |  | (20,565) |  |
| Operating income |  |  |  |  | 63,975 |  |  | 62,191 |  |
| Interest income |  |  |  |  | 5,898 |  |  | 1,559 |  |
| Interest expense |  |  |  |  | (45) |  |  | (391) |  |
| Foreign exchange gain (loss), net |  |  |  |  | 415 |  |  | 2,085 |  |
| Other income (expense), net |  |  |  |  | (80) |  |  | (141) |  |
| Income before income taxes |  |  |  |  | 70,163 |  |  | 65,303 |  |
| Income tax expense |  |  |  |  | (5,074) |  |  | (688) |  |
| Net income |  |  |  |  | 65,089 |  |  | 64,615 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities |  |  |  |  | 948 |  |  | (1,461) |  |
| Change in net unrealized gain (loss) on derivative instruments |  |  |  |  | (561) |  |  | (1,218) |  |
| Change in net retirement benefits plan – prior service cost |  |  |  |  | 126 |  |  | 168 |  |
| Change in foreign currency translation adjustment |  |  |  |  | 100 |  |  | 246 |  |
| Total other comprehensive income (loss), net of tax |  |  |  |  | 613 |  |  | (2,265) |  |
| Net comprehensive income |  |  |  |  | $ | 65,702 |  |  | $ | 62,350 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic |  |  |  |  | $ | 1.80 |  |  | $ | 1.77 |  |
| Diluted |  |  |  |  | $ | 1.78 |  |  | $ | 1.76 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |
| Basic |  |  |  |  | 36,256 |  |  | 36,528 |  |
| Diluted |  |  |  |  | 36,481 |  |  | 36,758 |  |

[0001408710-23-000034:8k_2_02:40]
FABRINET

[0001408710-23-000034:8k_2_02:41]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited)

[0001408710-23-000034:8k_2_02:42]
|  | Three Months Ended |
| (in thousands of U.S. dollars) | September 29,2023 |  | September 30,2022 |
| Cash flows from operating activities |  |  |  |
| Net income for the period | $ | 65,089 |  |  | $ | 64,615 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 11,961 |  |  | 11,055 |  |
| (Gain) loss on disposal and impairment of property, plant and equipment and intangibles | 12 |  |  | (9) |  |
| (Gain) loss from sales and maturities of available-for-sale securities | — |  |  | 92 |  |
| Amortization of discount (premium) of short-term investments | (596) |  |  | 442 |  |
| (Reversal of) allowance for doubtful accounts | 803 |  |  | (91) |  |
| Unrealized loss (gain) on exchange rate and fair value of foreign currency forward contracts | (52) |  |  | (386) |  |
| Amortization of fair value at hedge inception of interest rate swaps | (88) |  |  | (191) |  |
| Share-based compensation | 7,733 |  |  | 7,723 |  |
| Deferred income tax | 1,377 |  |  | (219) |  |
| Other non-cash expenses | 222 |  |  | (439) |  |
| Changes in operating assets and liabilities |  |  |  |
| Trade accounts receivable | (4,138) |  |  | (24,476) |  |
| Inventories | 79,481 |  |  | 28,808 |  |
| Other current assets and non-current assets | 3,238 |  |  | (10,661) |  |
| Trade accounts payable | (24,397) |  |  | (29,774) |  |
| Income tax payable | 963 |  |  | (276) |  |
| Severance liabilities | 706 |  |  | 617 |  |
| Other current liabilities and non-current liabilities | 2,735 |  |  | 13,804 |  |
| Net cash provided by operating activities | 145,049 |  |  | 60,634 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of short-term investments | (77,692) |  |  | (25,609) |  |
| Proceeds from sales of short-term investments | — |  |  | 30,000 |  |
| Proceeds from maturities of short-term investments | 35,909 |  |  | 29,236 |  |
| Purchase of property, plant and equipment | (11,435) |  |  | (10,258) |  |
| Purchase of intangibles | (180) |  |  | (11) |  |
| Proceeds from disposal of property, plant and equipment | 318 |  |  | 9 |  |
| Net cash used in investing activities | (53,080) |  |  | 23,367 |  |
| Cash flows from financing activities |  |  |  |
| Repayment of long-term borrowings | (3,047) |  |  | (6,094) |  |
| Repayment of finance lease liability | — |  |  | (2) |  |
| Repurchase of ordinary shares | — |  |  | (4,900) |  |
| Withholding tax related to net share settlement of restricted share units | (12,147) |  |  | (16,489) |  |
| Net cash used in financing activities | (15,194) |  |  | (27,485) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | 76,775 |  |  | $ | 56,516 |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at the beginning of period | $ | 231,368 |  |  | $ | 198,365 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | 76,775 |  |  | 56,516 |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash | 195 |  |  | 520 |  |
| Cash, cash equivalents and restricted cash at the end of period | $ | 308,338 |  |  | $ | 255,401 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment-related payables | $ | 9,313 |  |  | $ | 12,541 |  |

[0001408710-23-000034:8k_2_02:43]
FABRINET

[0001408710-23-000034:8k_2_02:44]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited) (Continued)

[0001408710-23-000034:8k_2_02:45]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the condensed consolidated balance sheets that sum to the total of the same amounts shown in the condensed consolidated statements of cash flows:

[0001408710-23-000034:8k_2_02:46]
|  | As of |
| (in thousands) | September 29,2023 |  | September 30,2022 |
| Cash and cash equivalents | $ | 308,338 |  |  | $ | 255,260 |  |
| Restricted cash | — |  |  | 141 |  |
| Cash, cash equivalents and restricted cash | $ | 308,338 |  |  | $ | 255,401 |  |

[0001408710-23-000034:8k_2_02:47]
FABRINET

[0001408710-23-000034:8k_2_02:48]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-23-000034:8k_2_02:49]
|  |  |  | Three Months Ended |
|  |  |  |  |  | September 29,2023 |  | September 30,2022 |
| (in thousands of U.S. dollars, except share data) |  |  |  |  |  |  |  |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |
| GAAP measures |  |  |  |  |  |  |  |  | $ | 65,089 |  |  | $ | 1.78 |  |  | $ | 64,615 |  |  | $ | 1.76 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  |  |  |  |  |  |  | 2,165 |  |  | 0.06 |  |  | 1,915 |  |  | 0.05 |  |
| Total related to gross profit |  |  |  |  |  |  |  |  | 2,165 |  |  | 0.06 |  |  | 1,915 |  |  | 0.05 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  |  |  |  |  |  |  | 5,568 |  |  | 0.16 |  |  | 5,808 |  |  | 0.16 |  |
| Amortization of intangibles |  |  |  |  |  |  |  |  | — |  |  | — |  |  | 83 |  |  | 0.00 |  |
| Total related to selling, general and administrative expenses |  |  |  |  |  |  |  |  | 5,568 |  |  | 0.16 |  |  | 5,891 |  |  | 0.16 |  |
| Related to other income and expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of deferred debt issuance costs |  |  |  |  |  |  |  |  | 8 |  |  | 0.00 |  |  | 8 |  |  | 0.00 |  |
| Total related to other income and expense |  |  |  |  |  |  |  |  | 8 |  |  | 0.00 |  |  | 8 |  |  | 0.00 |  |
| Total related to net income & EPS |  |  |  |  |  |  |  |  | 7,741 |  |  | 0.22 |  |  | 7,814 |  |  | 0.21 |  |
| Non-GAAP measures |  |  |  |  |  |  |  |  | $ | 72,830 |  |  | $ | 2.00 |  |  | $ | 72,429 |  |  | $ | 1.97 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  |  |  |  |  | 36,481 |  |  |  |  | 36,758 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  |  |  |  |  | 36,481 |  |  |  |  | 36,758 |  |

[0001408710-23-000034:8k_2_02:50]
FABRINET

[0001408710-23-000034:8k_2_02:51]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001408710-23-000034:8k_2_02:52]
| (in thousands) |  |  |  | Three Months Ended |
|  |  |  |  |  |  | September 29,2023 |  | September 30,2022 |
| Net cash provided by operating activities |  |  |  |  |  | $ | 145,049 |  |  | $ | 60,634 |  |
| Less: Purchase of property, plant and equipment |  |  |  |  |  | (11,435) |  |  | (10,258) |  |
| Non-GAAP free cash flow |  |  |  |  |  | $ | 133,614 |  |  | $ | 50,376 |  |

[0001408710-23-000034:8k_2_02:53]
FABRINET

[0001408710-23-000034:8k_2_02:54]
GUIDANCE FOR QUARTER ENDING DECEMBER 29, 2023

[0001408710-23-000034:8k_2_02:55]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-23-000034:8k_2_02:56]
|  | DilutedEPS |
| GAAP net income per diluted share: | $1.78 to $1.85 |
| Related to cost of revenues: |  |
| Share-based compensation expenses | 0.05 |
| Total related to gross profit | 0.05 |
| Related to selling, general and administrative expenses: |  |
| Share-based compensation expenses | 0.15 |
| Total related to selling, general and administrative expenses | 0.15 |
| Total related to net income & EPS | 0.20 |
| Non-GAAP net income per diluted share | $1.98 to $2.05 |
