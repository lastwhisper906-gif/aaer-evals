# FN MD&A — 0001408710-23-000036


## mdna

[0001408710-23-000036:mdna:1]
[same as prior period, unchanged from 0001408710-23-000018:mdna:1]

[0001408710-23-000036:mdna:2]
[same as prior period, unchanged from 0001408710-23-000018:mdna:2]

[0001408710-23-000036:mdna:3]
[same as prior period, unchanged from 0001408710-23-000018:mdna:3]

[0001408710-23-000036:mdna:4]
[same as prior period, unchanged from 0001408710-23-000018:mdna:4]

[0001408710-23-000036:mdna:5]
•our expectation that the portion of our revenues attributable to customers in regions outside of North America for the remainder of fiscal year 2024 will be in line with the portion of revenues attributable to such customers during the three months ended September 29, 2023;

[0001408710-23-000036:mdna:6]
[same as prior period, unchanged from 0001408710-23-000018:mdna:6]

[0001408710-23-000036:mdna:7]
•our expectation that our fiscal year 2024 selling, general and administrative (“SG&A”) expenses will increase compared to our fiscal year 2023 SG&A expenses;

[0001408710-23-000036:mdna:8]
[same as prior period, unchanged from 0001408710-23-000018:mdna:8]

[0001408710-23-000036:mdna:9]
[same as prior period, unchanged from 0001408710-23-000018:mdna:9]

[0001408710-23-000036:mdna:10]
[same as prior period, unchanged from 0001408710-23-000018:mdna:10]

[0001408710-23-000036:mdna:11]
[same as prior period, unchanged from 0001408710-23-000018:mdna:11]

[0001408710-23-000036:mdna:12]
[same as prior period, unchanged from 0001408710-23-000018:mdna:12]

[0001408710-23-000036:mdna:13]
•our expectations regarding the potential impact of macroeconomic conditions and international political instability on our business, financial condition and operating results;

[0001408710-23-000036:mdna:14]
[same as prior period, unchanged from 0001408710-23-000018:mdna:14]

[0001408710-23-000036:mdna:15]
[same as prior period, unchanged from 0001408710-23-000018:mdna:15]

[0001408710-23-000036:mdna:16]
[same as prior period, unchanged from 0001408710-23-000018:mdna:16]

[0001408710-23-000036:mdna:17]
[same as prior period, unchanged from 0001408710-23-000018:mdna:17]

[0001408710-23-000036:mdna:18]
•trends in the optical communications, automotive markets, and industrial lasers, including trends to outsource the production of components used in those markets;

[0001408710-23-000036:mdna:19]
[same as prior period, unchanged from 0001408710-23-000018:mdna:19]

[0001408710-23-000036:mdna:20]
[same as prior period, unchanged from 0001408710-23-000018:mdna:20]

[0001408710-23-000036:mdna:21]
28

[0001408710-23-000036:mdna:22]
[same as prior period, unchanged from 0001408710-23-000018:mdna:22]

[0001408710-23-000036:mdna:23]
We provide advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers (“OEMs”) of complex products such as optical communication components, modules and sub-systems, automotive components, industrial lasers, medical devices and sensors. We offer a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, complex printed circuit board assembly, advanced packaging, integration, final assembly and testing. We focus primarily on low-volume production of a wide variety of high complexity products, which we refer to as “low-volume, high-mix.” We also have the capability to accommodate high-volume production. Based on our extensive experience and the positive feedback we have received from our customers, we believe we are a global leader in providing these services to the optical communications, automotive markets, and industrial lasers.

[0001408710-23-000036:mdna:24]
Our customer base includes companies in complex industries that require advanced precision manufacturing capabilities such as optical communications, automotive, industrial lasers, and sensors. The products that we manufacture for our OEM customers include selective switching products; tunable transponders and transceivers; active optical cables; solid state, diode-pumped, gas and fiber lasers; and sensors. In many cases, we are the sole outsourced manufacturing partner used by our customers for the products that we manufacture for them.

[0001408710-23-000036:mdna:25]
[same as prior period, unchanged from 0001408710-23-000018:mdna:25]

[0001408710-23-000036:mdna:26]
[same as prior period, unchanged from 0001408710-23-000018:mdna:32]

[0001408710-23-000036:mdna:27]
[same as prior period, unchanged from 0001408710-23-000018:mdna:33]

[0001408710-23-000036:mdna:28]
We expect that disruptions in our supply chain and fluctuations in the availability of parts and materials will continue to have an adverse impact on our ability to generate revenue, despite strong demand from our customers. Furthermore, in some cases, our efforts to identify and secure alternative supply chain sources have resulted in our customers or their end customers requiring requalification and validation of components, a process that can often be lengthy and has negatively impacted the timing of our revenue. In addition, we expect the near-term inventory correction that our optical communications customers are experiencing to persist, which will have an adverse impact on our ability to generate revenue.

[0001408710-23-000036:mdna:29]
[same as prior period, unchanged from 0001408710-23-000018:mdna:35]

[0001408710-23-000036:mdna:30]
We generate revenues from three geographic regions: North America, Asia-Pacific and others, and Europe. Revenues are attributed to a particular geographic area based on the bill-to-location of our customers, notwithstanding that the products may be shipped to a different geographic region. The substantial majority of our revenues are derived from our manufacturing facilities in Asia-Pacific.

[0001408710-23-000036:mdna:31]
The percentage of our revenues generated from a bill-to location outside of North America increased from 46.8% in the three months ended September 30, 2022 to 62.3% in the three months ended September 29, 2023, primarily because of the increase in sales to our customers outside of North America and decrease in sales to our customers in North America.

[0001408710-23-000036:mdna:32]
Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside North America for the remainder of fiscal year 2024 will be in line with the portion of revenues attributable to such customers during the three months ended September 29, 2023.

[0001408710-23-000036:mdna:33]
[same as prior period, unchanged from 0001408710-23-000018:mdna:40]

[0001408710-23-000036:mdna:34]
|  |  |  | Three Months Ended |
|  |  |  |  |  | September 29, 2023 |  | September 30, 2022 |
| North America |  |  |  |  | 37.7 | % |  | 53.2 | % |
| Asia-Pacific and others |  |  |  |  | 54.2 |  |  | 37.9 |  |
| Europe |  |  |  |  | 8.1 |  |  | 8.9 |  |
|  |  |  |  |  | 100.0 | % |  | 100.0 | % |

[0001408710-23-000036:mdna:35]
[same as prior period, unchanged from 0001408710-23-000018:mdna:42]

[0001408710-23-000036:mdna:36]
We enter into supply agreements with our customers which generally have an initial term of up to three years, subject to automatic renewals for subsequent one-year terms unless expressly terminated. Although there are no minimum purchase requirements in our supply agreements, our customers provide us with rolling forecasts of their demand requirements. Our supply agreements generally include provisions for pricing and periodic review of pricing, consignment of our customer’s unique production equipment to us, and the sharing of benefits from cost-savings derived from our efforts. We are generally required to purchase materials, which may include long lead-time materials and materials that are subject to minimum order quantities and/or non-cancelable or non-returnable terms, to meet the stated demands of our customers. After procuring materials, we manufacture products for our customers based on purchase orders that contain terms regarding product quantities, delivery locations and delivery dates. Our customers generally are obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by our customers within a specified period of time, or that are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under our contracts. Once materials are designated as either excess or obsolete inventory, our customers are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

[0001408710-23-000036:mdna:37]
[same as prior period, unchanged from 0001408710-23-000018:mdna:45]

[0001408710-23-000036:mdna:38]
[same as prior period, unchanged from 0001408710-23-000018:mdna:46]

[0001408710-23-000036:mdna:39]
A second significant element of our cost of revenues is employee costs, including indirect employee costs related to design, configuration and optimization of manufacturing processes for our customers, quality testing, materials testing and other engineering services, and direct costs related to our manufacturing employees. Direct employee costs include employee salaries, insurance and benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a lesser extent, costs to recruit, train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand, the PRC and the United Kingdom, the fluctuation of the Thai baht, Chinese Renminbi ("RMB") and pound sterling ("GBP") against our functional currency, the U.S. dollar, and our ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention and asset utilization.

[0001408710-23-000036:mdna:40]
[same as prior period, unchanged from 0001408710-23-000018:mdna:48]

[0001408710-23-000036:mdna:41]
[same as prior period, unchanged from 0001408710-23-000018:mdna:49]

[0001408710-23-000036:mdna:42]
[same as prior period, unchanged from 0001408710-23-000018:mdna:50]

[0001408710-23-000036:mdna:43]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative and other support personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other general expenses not related to cost of revenues. In fiscal year 2024, we expect our SG&A expenses will increase compared with our fiscal year 2023 SG&A expenses, mainly due to an increase in employee costs, sales and marketing cost and investing in information technology hardware.

[0001408710-23-000036:mdna:44]
The compensation committee of our board of directors approved a fiscal year 2024 executive incentive plan with quantitative objectives based solely on achieving certain revenue targets and non-GAAP operating margin targets for fiscal year 2024. Bonuses under the fiscal year 2024 executive incentive plan are payable after the end of fiscal year 2024. In fiscal year 2023, the compensation committee approved a fiscal year 2023 executive incentive plan with quantitative objectives that were based solely on achieving certain revenue targets and non-GAAP operating margin targets for fiscal year 2023.

[0001408710-23-000036:mdna:45]
[same as prior period, unchanged from 0001408710-23-000018:mdna:53]

[0001408710-23-000036:mdna:46]
[same as prior period, unchanged from 0001408710-23-000018:mdna:54]

[0001408710-23-000036:mdna:47]
[same as prior period, unchanged from 0001408710-23-000018:mdna:55]

[0001408710-23-000036:mdna:48]
[same as prior period, unchanged from 0001408710-23-000018:mdna:56]

[0001408710-23-000036:mdna:49]
[same as prior period, unchanged from 0001408710-23-000018:mdna:57]

[0001408710-23-000036:mdna:50]
|  | As of September 29, 2023 |  | As of June 30, 2023 |
| (in thousands, except percentages) | ForeignCurrency |  | $ |  | % |  | ForeignCurrency |  | $ |  | % |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 815,248 |  |  | $ | 22,299 |  |  | 65.4 | % |  | 754,443 |  |  | $ | 21,198 |  |  | 60.9 | % |
| RMB | 46,709 |  |  | 6,506 |  |  | 19.1 |  |  | 66,501 |  |  | 9,203 |  |  | 26.4 |  |
| GBP | 4,122 |  |  | 5,283 |  |  | 15.5 |  |  | 3,487 |  |  | 4,401 |  |  | 12.7 |  |
| Total |  |  | $ | 34,088 |  |  | 100.0 | % |  |  |  | $ | 34,802 |  |  | 100.0 | % |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 3,181,857 |  |  | $ | 87,031 |  |  | 89.1 | % |  | 2,956,730 |  |  | $ | 83,078 |  |  | 88.8 | % |
| RMB | 76,503 |  |  | 10,655 |  |  | 10.9 |  |  | 74,652 |  |  | 10,331 |  |  | 11.0 |  |
| GBP | 23 |  |  | 28 |  |  | 0.0 |  |  | 114 |  |  | 144 |  |  | 0.2 |  |
| Total |  |  | $ | 97,714 |  |  | 100.0 | % |  |  |  | $ | 93,553 |  |  | 100.0 | % |

[0001408710-23-000036:mdna:51]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy As of September 29, 2023, there was $145.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 30, 2023, there was $143.0 million of foreign currency forward contracts outstanding on the Thai baht payables.

[0001408710-23-000036:mdna:52]
The RMB assets represent cash and cash equivalents, trade accounts receivable, and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable, accrued payroll, bonus and related expenses and other payables. As of September 29, 2023 and June 30, 2023, we did not have any derivative contracts denominated in RMB.

[0001408710-23-000036:mdna:53]
The GBP assets represent cash and trade accounts receivable. The GBP liabilities represent trade accounts payable and other payables. As of September 29, 2023 and June 30, 2023, we did not have any derivative contracts denominated in GBP.

[0001408710-23-000036:mdna:54]
For the three months ended September 29, 2023 and September 30, 2022, we recorded a gain of $0.3 million and loss of $0.2 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-23-000036:mdna:55]
[same as prior period, unchanged from 0001408710-23-000018:mdna:64]

[0001408710-23-000036:mdna:56]
[same as prior period, unchanged from 0001408710-23-000018:mdna:65]

[0001408710-23-000036:mdna:57]
[same as prior period, unchanged from 0001408710-23-000018:mdna:66]

[0001408710-23-000036:mdna:58]
[same as prior period, unchanged from 0001408710-23-000018:mdna:67]

[0001408710-23-000036:mdna:59]
[same as prior period, unchanged from 0001408710-23-000018:mdna:68]

[0001408710-23-000036:mdna:60]
[same as prior period, unchanged from 0001408710-23-000018:mdna:69]

[0001408710-23-000036:mdna:61]
[same as prior period, unchanged from 0001408710-23-000018:mdna:70]

[0001408710-23-000036:mdna:62]
[same as prior period, unchanged from 0001408710-23-000018:mdna:71]

[0001408710-23-000036:mdna:63]
[same as prior period, unchanged from 0001408710-23-000018:mdna:72]

[0001408710-23-000036:mdna:64]
[same as prior period, unchanged from 0001408710-23-000018:mdna:73]

[0001408710-23-000036:mdna:65]
[same as prior period, unchanged from 0001408710-23-000018:mdna:74]

[0001408710-23-000036:mdna:66]
[same as prior period, unchanged from 0001408710-23-000018:mdna:75]

[0001408710-23-000036:mdna:67]
[same as prior period, unchanged from 0001408710-23-000018:mdna:76]

[0001408710-23-000036:mdna:68]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption on income generated from projects to manufacture certain products at our Chonburi campus is currently available to us through June 2026. Similar preferential tax treatment was available to us through June 2020 with respect to products manufactured at our Pinehurst campus Building 6. After June 2020, 50% of our income generated from products manufactured at our Pinehurst campus will be exempted from tax through June 2025. New preferential tax treatment is available to us for products manufactured at our Chonburi campus Building 9, where income generated will be tax exempt through 2031, capped at our actual investment amount. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted. Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001408710-23-000036:mdna:69]
As of September 29, 2023, the corporate income tax rates for our subsidiaries in the PRC, the U.S., the U.K. and Israel are 25%, 21%, 25% and 23%, respectively.

[0001408710-23-000036:mdna:70]
Our deferred income tax assets represent temporary differences between the carrying amount and the tax basis of existing assets and liabilities that will result in deductible and payable amounts in future years, including net operating loss carry forwards. Based on estimates, the carrying value of our net deferred tax assets assumes that it is more likely than not that we will be able to generate sufficient future taxable income in certain tax jurisdictions to realize these deferred income tax assets. Our judgments regarding future profitability may change depending on future market conditions, changes in U.S. or international tax laws, or other factors. If these estimates and related assumptions change in the future, we may be required to increase or decrease our valuation allowance against the deferred tax assets, resulting in additional or lesser income tax expense.

[0001408710-23-000036:mdna:71]
Our subsidiary in Israel generates losses since inception and management expected that such subsidiary would continue to have net operating losses in the foreseeable future; therefore, management believed it was more likely than not that all of the deferred tax assets of such subsidiary would not be utilized. Thus, a full valuation allowance of $2.1 million for the deferred tax assets was set up as of September 29, 2023.

[0001408710-23-000036:mdna:72]
[same as prior period, unchanged from 0001408710-23-000018:mdna:80]

[0001408710-23-000036:mdna:73]
We prepare our unaudited condensed consolidated financial statements in conformity with U.S. GAAP, which requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent liabilities on the date of the unaudited condensed consolidated financial statements and the reported amounts of revenues and expenses during the financial reporting period. We continually evaluate these estimates and assumptions based on the most recently available information, our own historical experience and on various other assumptions that we believe to be reasonable under the circumstances. The results of these estimates form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Because the use of estimates is an integral component of the financial reporting process, actual results could differ from those estimates. Some of our accounting policies require higher degrees of judgment than others in their application. We consider the policies discussed below to be critical to an understanding of our unaudited condensed consolidated financial statements, as their application places the most significant demands on our management’s judgment.

[0001408710-23-000036:mdna:74]
Our critical accounting policies are disclosed in our Annual Report on Form10-K for the fiscal year ended June 30, 2023. The adoption of new accounting policies and accounting standards are disclosed in Note 2 to the unaudited condensed consolidated financial statements. There were no changes to our accounting policies.

[0001408710-23-000036:mdna:75]
[same as prior period, unchanged from 0001408710-23-000018:mdna:83]

[0001408710-23-000036:mdna:76]
[same as prior period, unchanged from 0001408710-23-000018:mdna:84]

[0001408710-23-000036:mdna:77]
| (in thousands) |  |  | Three Months Ended |
|  |  |  |  | September 29,2023 |  | September 30,2022 |
| Revenues |  |  |  |  | $ | 685,477 |  |  | $ | 655,429 |  |
| Cost of revenues |  |  |  |  | (601,073) |  |  | (572,673) |  |
| Gross profit |  |  |  |  | 84,404 |  |  | 82,756 |  |
| Selling, general and administrative expenses |  |  |  |  | (20,429) |  |  | (20,565) |  |
| Operating income |  |  |  |  | 63,975 |  |  | 62,191 |  |
| Interest income |  |  |  |  | 5,898 |  |  | 1,559 |  |
| Interest expense |  |  |  |  | (45) |  |  | (391) |  |
| Foreign exchange gain (loss), net |  |  |  |  | 415 |  |  | 2,085 |  |
| Other income (expense), net |  |  |  |  | (80) |  |  | (141) |  |
| Income before income taxes |  |  |  |  | 70,163 |  |  | 65,303 |  |
| Income tax expense |  |  |  |  | (5,074) |  |  | (688) |  |
| Net income |  |  |  |  | 65,089 |  |  | 64,615 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  | 613 |  |  | (2,265) |  |
| Net comprehensive income |  |  |  |  | $ | 65,702 |  |  | $ | 62,350 |  |

[0001408710-23-000036:mdna:78]
[same as prior period, unchanged from 0001408710-23-000018:mdna:86]

[0001408710-23-000036:mdna:79]
|  |  |  | Three Months Ended |
|  |  |  |  |  | September 29,2023 |  | September 30,2022 |
| Revenues |  |  |  |  | 100.0 | % |  | 100.0 | % |
| Cost of revenues |  |  |  |  | (87.7) |  |  | (87.4) |  |
| Gross profit |  |  |  |  | 12.3 |  |  | 12.6 |  |
| Selling, general and administrative expenses |  |  |  |  | (3.0) |  |  | (3.1) |  |
| Operating income |  |  |  |  | 9.3 |  |  | 9.5 |  |
| Interest income |  |  |  |  | 0.8 |  |  | 0.3 |  |
| Interest expense |  |  |  |  | 0.0 |  |  | (0.1) |  |
| Foreign exchange gain (loss), net |  |  |  |  | 0.1 |  |  | 0.3 |  |
| Other income (expense), net |  |  |  |  | 0.0 |  |  | 0.0 |  |
| Income before income taxes |  |  |  |  | 10.2 |  |  | 10.0 |  |
| Income tax expense |  |  |  |  | (0.7) |  |  | (0.1) |  |
| Net income |  |  |  |  | 9.5 |  |  | 9.9 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  | 0.1 |  |  | (0.4) |  |
| Net comprehensive income |  |  |  |  | 9.6 | % |  | 9.5 | % |

[0001408710-23-000036:mdna:80]
34

[0001408710-23-000036:mdna:81]
[same as prior period, unchanged from 0001408710-23-000018:mdna:88]

[0001408710-23-000036:mdna:82]
|  |  |  | Three Months Ended |
| (in thousands) |  |  |  |  | September 29,2023 |  | September 30,2022 |
| Optical communications |  |  |  |  | $ | 533,257 |  |  | $ | 497,561 |  |
| Automotive, lasers and other |  |  |  |  | 152,220 |  |  | 157,868 |  |
| Total |  |  |  |  | $ | 685,477 |  |  | $ | 655,429 |  |

[0001408710-23-000036:mdna:83]
[same as prior period, unchanged from 0001408710-23-000018:mdna:90]

[0001408710-23-000036:mdna:84]
Comparison of Three Months Ended September 29, 2023 with Three Months Ended September 30, 2022

[0001408710-23-000036:mdna:85]
[same as prior period, unchanged from 0001408710-23-000018:mdna:92]

[0001408710-23-000036:mdna:86]
Our revenues increased by $30.1 million, or 4.6%, to $685.5 million for the three months ended September 29, 2023 (a thirteen-week quarter), compared with $655.4 million for the three months ended September 30, 2022 (a fourteen-week quarter). This increase was primarily due to an increase in our key customers’ demand for optical communications products. Revenues from optical communications products, which represented $533.3 million, or 77.8%, of our revenues for the three months ended September 29, 2023, increased by $35.7 million, or 7.2%, compared to the same period in the prior fiscal year, mainly due to an increase in revenues from data communication products, primarily for artificial intelligence applications, offset by a decline in revenues from telecommunication products as inventory absorption within the telecommunication market continued during the three months ended September 29, 2023. Revenues from non-optical communications products, which represented $152.2 million, or 22.2%, of our revenues for the three months ended September 29, 2023, decreased by $5.6 million, or 3.6%, compared to the same period in the prior fiscal year, primarily due to a decline in revenues from industrial laser products and other non-optical communications products, partially offset by an increase in revenues from automotive products.

[0001408710-23-000036:mdna:87]
[same as prior period, unchanged from 0001408710-23-000018:mdna:95]

[0001408710-23-000036:mdna:88]
Our cost of revenues increased by $28.4 million, or 5.0%, to $601.1 million, or 87.7% of revenues, for the three months ended September 29, 2023, compared with $572.7 million, or 87.4% of revenues, for the three months ended September 30, 2022. The increase was in line with the increase in sales volume.

[0001408710-23-000036:mdna:89]
[same as prior period, unchanged from 0001408710-23-000018:mdna:98]

[0001408710-23-000036:mdna:90]
Our gross profit increased by $1.6 million, or 1.9%, to $84.4 million, or 12.3% of revenues, for the three months ended September 29, 2023, compared with $82.8 million, or 12.6% of revenues, for the three months ended September 30, 2022. The increase was primarily due to an increase in sales volume.

[0001408710-23-000036:mdna:91]
[same as prior period, unchanged from 0001408710-23-000018:mdna:101]

[0001408710-23-000036:mdna:92]
Our SG&A expenses decreased by $0.2 million, or 1.0%, to $20.4 million, or 3.0% of revenues, for the three months ended September 29, 2023, compared with $20.6 million, or 3.1% of revenues, for the three months ended September 30, 2022. The decrease was primarily due to (1) a decrease in executive benefits of $0.3 million and (2) a decrease in share-based compensation expenses of $0.2 million, offset by (1) an increase in sales and marketing expenses of $0.2 million and (2) an increase in insurance expenses of $0.1 million.

[0001408710-23-000036:mdna:93]
[same as prior period, unchanged from 0001408710-23-000018:mdna:106]

[0001408710-23-000036:mdna:94]
Our operating income increased by $1.8 million, or 2.9%, to $64.0 million, or 9.3% of revenues, for the three months ended September 29, 2023, compared with $62.2 million, or 9.5% of revenues, for the three months ended September 30, 2022. The increase was primarily due to an increase in revenues.

[0001408710-23-000036:mdna:95]
[same as prior period, unchanged from 0001408710-23-000018:mdna:109]

[0001408710-23-000036:mdna:96]
Our interest income increased by $4.3 million, or 268.8%, to $5.9 million, or 0.8% of revenues, for the three months ended September 29, 2023, compared with $1.6 million, or 0.3% of revenues, for the three months ended September 30, 2022. The increase was primarily due to a higher weighted average interest rate during the three months ended September 29, 2023 compared to the same period in the prior fiscal year.

[0001408710-23-000036:mdna:97]
[same as prior period, unchanged from 0001408710-23-000018:mdna:112]

[0001408710-23-000036:mdna:98]
Our interest expense decreased by $0.4 million for the three months ended September 29, 2023, compared with the three months ended September 30, 2022. The decrease was primarily due to a decrease in the amount of an outstanding long-term loan.

[0001408710-23-000036:mdna:99]
[same as prior period, unchanged from 0001408710-23-000018:mdna:115]

[0001408710-23-000036:mdna:100]
We recorded foreign exchange gain, net of $0.4 million, or 0.1% of revenues, for the three months ended September 29, 2023, compared with foreign exchange gain, net of $2.1 million, or 0.3% of revenues for the three months ended September 30, 2022. The decrease in foreign exchange gain was mainly due to (1) lower unrealized gain from revaluation of outstanding Thai baht assets and liabilities of $1.5 million, (2) realized loss from payment/receipt of $0.7 million, and (3) unrealized loss from revaluation of currencies other than Thai baht of $0.5 million, offset by (1) unrealized gain from mark-to-market forward contracts of $0.6 million, and (2) lower foreign exchange loss, totaling $0.4 million from our subsidiaries in the PRC and the U.K.

[0001408710-23-000036:mdna:101]
[same as prior period, unchanged from 0001408710-23-000018:mdna:118]

[0001408710-23-000036:mdna:102]
We recorded income before income taxes of $70.2 million for the three months ended September 29, 2023, compared with $65.3 million for the three months ended September 30, 2022.

[0001408710-23-000036:mdna:103]
[same as prior period, unchanged from 0001408710-23-000018:mdna:121]

[0001408710-23-000036:mdna:104]
Our provision for income tax reflects effective tax rates of 7.2% and 1.1% for the three months ended September 29, 2023 and September 30, 2022, respectively. The increase was due to an increase in income subject to tax during the three months ended September 29, 2023 as compared to the three months ended September 30, 2022. In addition, a full valuation allowance of $2.1 million for deferred tax assets was set up during the three months ended September 29, 2023 due to management's belief that our subsidiary in Israel would continue to have losses in the foreseeable future such that the deferred tax assets of such subsidiary would not be utilized.

[0001408710-23-000036:mdna:105]
[same as prior period, unchanged from 0001408710-23-000018:mdna:124]

[0001408710-23-000036:mdna:106]
We recorded net income of $65.1 million, or 9.5% of revenues, for the three months ended September 29, 2023, compared with $64.6 million, or 9.9% of revenues, for the three months ended September 30, 2022.

[0001408710-23-000036:mdna:107]
[same as prior period, unchanged from 0001408710-23-000018:mdna:127]

[0001408710-23-000036:mdna:108]
We recorded other comprehensive income of $0.6 million, or 0.1% of revenues, for the three months ended September 29, 2023, compared with other comprehensive loss of $2.3 million, or 0.4% of revenues, for the three months ended September 30, 2022. The change was mainly due to (1) unrealized gain from mark-to-market of available-for-sale debt securities of $2.4 million, and (2) lower unrealized loss from mark-to-market of forward contracts and interest rate swap agreement of $0.7 million, offset by (1) lower unrealized gain from foreign currency translation adjustment of $0.1 million, and (2) lower gain from retirement benefits plan of $0.1 million.

[0001408710-23-000036:mdna:109]
[same as prior period, unchanged from 0001408710-23-000018:mdna:130]

[0001408710-23-000036:mdna:110]
[same as prior period, unchanged from 0001408710-23-000018:mdna:131]

[0001408710-23-000036:mdna:111]
We primarily finance our operations through cash flow from operations. As of September 29, 2023 and September 30, 2022, we had cash, cash equivalents, and short-term investments of $670.8 million and $499.8 million, respectively, and outstanding debt of $9.1 million and $21.3 million, respectively.

[0001408710-23-000036:mdna:112]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents was 4.1% and 1.5% for the three months ended September 29, 2023 and September 30, 2022, respectively.

[0001408710-23-000036:mdna:113]
Our cash investments are made in accordance with an investment policy approved by the audit committee of our board of directors. In general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed income securities are primarily classified as available-for-sale and are recorded at fair value. The cost of securities sold is based on the specific identification method.

[0001408710-23-000036:mdna:114]
Unrealized gains and losses on these securities are recorded as other comprehensive income (loss) and are reported as a separate component of shareholders’ equity.

[0001408710-23-000036:mdna:115]
During the three months ended September 29, 2023, we repaid $3.0 million of the term loan under our 2019 Credit Facility Agreement. As a result, as of September 29, 2023, we had a long-term borrowing of $9.1 million under our 2019 Credit Facility Agreement (see Note 10 of Notes to Unaudited Condensed Consolidated Financial Statements for further details). We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held short-term investments of $362.4 million as of September 29, 2023.

[0001408710-23-000036:mdna:116]
We believe that our current cash and cash equivalents, short-term investments, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001408710-23-000036:mdna:117]
[same as prior period, unchanged from 0001408710-23-000018:mdna:137]

[0001408710-23-000036:mdna:118]
[same as prior period, unchanged from 0001408710-23-000018:mdna:138]

[0001408710-23-000036:mdna:119]
|  | Three Months Ended |
| (in thousands) | September 29, 2023 |  | September 30, 2022 |
| Net cash provided by operating activities | $ | 145,049 |  |  | $ | 60,634 |  |
| Net cash provided by (used in) investing activities | $ | (53,080) |  |  | $ | 23,367 |  |
| Net cash used in financing activities | $ | (15,194) |  |  | $ | (27,485) |  |
| Net increase in cash, cash equivalents and restricted cash | $ | 76,775 |  |  | $ | 56,516 |  |

[0001408710-23-000036:mdna:120]
[same as prior period, unchanged from 0001408710-23-000018:mdna:140]

[0001408710-23-000036:mdna:121]
Cash provided by operating activities is net income adjusted for certain non-cash items and changes in certain assets and liabilities. The increase in cash provided by operating activities during the three months ended September 29, 2023 as compared to the three months ended September 30, 2022 was primarily driven by efficient cash-favorable working capital changes.

[0001408710-23-000036:mdna:122]
[same as prior period, unchanged from 0001408710-23-000018:mdna:142]

[0001408710-23-000036:mdna:123]
Investing cash flows consist primarily of investment purchases, sales, maturities, and disposals; and capital expenditures. Cash used in investing activities for the three months ended September 29, 2023 as compared to cash provided in investing activities for the three months ended September 30, 2022 was primarily due to an increase of investment purchases, offset by an increase in proceeds from maturities of short-term investments.

[0001408710-23-000036:mdna:124]
[same as prior period, unchanged from 0001408710-23-000018:mdna:144]

[0001408710-23-000036:mdna:125]
Financing cash flows consist primarily of repayment of long-term debt, share repurchases, and withholding tax related to net share settlement of restricted share units. Cash used in financing activities was lower for the three months ended September 29, 2023 as compared to the three months ended September 30, 2022 primarily due to no share repurchases and a decrease in withholding tax related to net share settlement of restricted share units, and lower of the repayment of long-term borrowings due to one fewer installment from one fewer week in the first quarter of fiscal year 2024 compared to fiscal year 2023.

[0001408710-23-000036:mdna:126]
[same as prior period, unchanged from 0001408710-23-000018:mdna:146]

[0001408710-23-000036:mdna:127]
[same as prior period, unchanged from 0001408710-23-000018:mdna:147]
