# FN note change history — 0001408710-23-000018 → 0001408710-23-000036


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0001408710-23-000036:note_history:1]
As of September 29, 2023 and June 30, 2023, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.0 million and $1.5 million, respectively, or Thai baht 73.2 million and 53.0 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the operations related to the Israeli Customs department.
  (was, 2023-05-09, similarity 0.9754):
[0001408710-23-000018:note_history:1]
As of March 31, 2023 and June 24, 2022, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $1.6 million and $1.4 million, respectively, or Thai baht 53.0 million and 50.2 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the operations related to the Customs department.

- changed (2023-11-07):
[0001408710-23-000036:note_history:2]
As of September 29, 2023, the Company had purchase obligations and other commitments to third parties of $1.22 billion.
  (was, 2023-05-09, similarity 0.9401):
[0001408710-23-000018:note_history:2]
As of March 31, 2023, the Company had a purchase obligation and other commitments to third parties of $1.09 billion.

- changed (2023-11-07):
[0001408710-23-000036:note_history:3]
As of September 29, 2023, the Company had total capital expenditure commitments to third parties of $12.3 million.
  (was, 2023-05-09, similarity 0.9515):
[0001408710-23-000018:note_history:3]
As of March 31, 2023, the Company had total capital expenditure commitments to third parties of $18.3 million.

- removed (2023-11-07):
[0001408710-23-000018:note_history:4]
As of June 24, 2022, there was an outstanding bank guarantee on behalf of the Company's subsidiary in the PRC to support the subsidiary's operations totaling Renminbi 1.0 million, which bank guarantee was backed by cash collateral of $0.1 million. This bank guarantee was released in December 2022. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in the U.K. to support its operations.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0001408710-23-000036:note_history:5]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of September 29, 2023 and for the three months ended September 29, 2023 and September 30, 2022 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 30, 2023.
  (was, 2023-05-09, similarity 0.9534):
[0001408710-23-000018:note_history:5]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of March 31, 2023 and for the three and nine months ended March 31, 2023 and March 25, 2022 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 24, 2022.

- changed (2023-11-07):
[0001408710-23-000036:note_history:6]
The results for the three months ended September 29, 2023 may not be indicative of results for the year ending June 28, 2024 or any future periods.
  (was, 2023-05-09, similarity 0.9319):
[0001408710-23-000018:note_history:6]
The results for the three and nine months ended March 31, 2023 may not be indicative of results for the year ending June 30, 2023 or any future periods.

- changed (2023-11-07):
[0001408710-23-000036:note_history:7]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information.
  (was, 2023-05-09, similarity 0.8406):
[0001408710-23-000018:note_history:7]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, allowance for doubtful accounts, allowance for expected credit losses, income taxes, inventory obsolescence, goodwill and valuation of intangible assets related to business acquisition, among others. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information. Additionally, the extent to which the evolving COVID-19 pandemic impacts the Company’s unaudited condensed consolidated financial statements will depend on a number of factors, including the magnitude and duration of the pandemic. These estimates may change, as new events occur and additional information is obtained, or based upon the occurrence of other factors related to the COVID-19 pandemic that could result in material impacts to the Company's unaudited condensed consolidated financial statements in future reporting periods.

- changed (2023-11-07):
[0001408710-23-000036:note_history:8]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  September 29, 2023 and September 30, 2022 consisted of 13 and 14 weeks, respectively. Fiscal year 2024 will comprise 52 weeks and will end on June 28, 2024.
  (was, 2023-05-09, similarity 0.7189):
[0001408710-23-000018:note_history:8]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended  March 31, 2023 and March 25, 2022 consisted of 13 weeks. The nine months ended  March 31, 2023 and March 25, 2022 consisted of 40 weeks and 39 weeks, respectively. Fiscal year 2023 will comprise 53 weeks and will end on June 30, 2023.

- added (2023-11-07):
[0001408710-23-000036:note_history:9]
Adoption of New Accounting Standards

- added (2023-11-07):
[0001408710-23-000036:note_history:10]
No new accounting standard was adopted in the first quarter of fiscal year 2024.

- removed (2023-11-07):
[0001408710-23-000018:note_history:11]
Adoption of New Accounting Standards
In November 2021, the Financial Accounting Standard Board issued Accounting Standards Update ("ASU") 2021-10, “Government Assistance (Topic 832), Disclosures by Business Entities about Government Assistance,” which requires annual disclosures that increase the transparency of transactions involving government assistance, including (1) the types of transactions, (2) the accounting for those transactions, and (3) the effect of those transactions on an entity’s financial statements. The amendments in this update are effective for all entities within the ASU's scope for financial statements issued for annual periods beginning after December 15, 2021. The Company adopted this standard in the first quarter of fiscal year 2023 with no material impact on its unaudited condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0001408710-23-000036:note_history:12]
| (in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofSeptember 29, 2023 |  | As ofJune 30, 2023 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 9,141 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (24) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 9,117 |  |  | $ | 12,156 |  |
  (was, 2023-05-09, similarity 0.6652):
[0001408710-23-000018:note_history:12]
| (in thousands of U.S. dollars) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofMarch 31, 2023 |  | As ofJune 24, 2022 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 15,234 |  |  | $ | 27,421 |  |
| Less: Current portion |  |  |  |  | (12,187) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs, non-current portion |  |  |  |  | (8) |  |  | (31) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 3,039 |  |  | $ | 15,202 |  |

- changed (2023-11-07):
[0001408710-23-000036:note_history:13]
The movements of long-term borrowings for the three months ended September 29, 2023 and September 30, 2022 were as follows:
  (was, 2023-05-09, similarity 0.8756):
[0001408710-23-000018:note_history:13]
The movements of long-term borrowings for the nine months ended March 31, 2023 and March 25, 2022 were as follows:

- changed (2023-11-07):
[0001408710-23-000036:note_history:14]
|  | Three Months Ended |
| (in thousands) | September 29,2023 |  | September 30,2022 |
| Opening balance | $ | 12,188 |  |  | $ | 27,421 |  |
| Repayments during the period | (3,047) |  |  | (6,094) |  |
| Closing balance | $ | 9,141 |  |  | $ | 21,327 |  |
  (was, 2023-05-09, similarity 0.9337):
[0001408710-23-000018:note_history:14]
|  | Nine Months Ended |
| (in thousands) | March 31,2023 |  | March 25,2022 |
| Opening balance | $ | 27,421 |  |  | $ | 39,609 |  |
| Repayments during the period | (12,187) |  |  | (9,141) |  |
| Closing balance | $ | 15,234 |  |  | $ | 30,468 |  |

- changed (2023-11-07):
[0001408710-23-000036:note_history:15]
As of September 29, 2023, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2023-05-09, similarity 0.95):
[0001408710-23-000018:note_history:15]
As of March 31, 2023, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2023-11-07):
[0001408710-23-000036:note_history:16]
| (in thousands) |  |
| 2024 (remaining nine months) | $ | 9,141 |  |
  (was, 2023-05-09, similarity 0.7451):
[0001408710-23-000018:note_history:16]
| (in thousands) |  |
| 2023 (remaining three months) | $ | 3,047 |  |
| 2024 | 12,187 |  |
| Total | $ | 15,234 |  |

- changed (2023-11-07):
[0001408710-23-000036:note_history:17]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. On March 9, 2023, the Borrower and the Bank amended the Term Loan Agreement to replace the interest rate reference from LIBOR to the Secured Overnight Financing Rate ("SOFR") effective from September 29, 2023. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed again. During the three months ended September 29, 2023, the Company recorded $0.1 million of interest expense in connection with this term loan, including the impact from interest rate swaps.
  (was, 2023-05-09, similarity 0.8544):
[0001408710-23-000018:note_history:17]
The term loan accrues interest at 3-month LIBOR plus 1.35% and is repayable in quarterly installments of $3.0 million, commencing on September 30, 2019. On March 9, 2023, the Borrower and the Bank amended the Term Loan Agreement to replace the interest rate reference from LIBOR to the Secured Overnight Financing Rate ("SOFR") effective from September 29, 2023. The term loan will mature on June 30, 2024. The Borrower may prepay the term loan in whole or in part at any time without premium or penalty. Any portion of the term loan repaid or prepaid may not be borrowed

- changed (2023-11-07):
[0001408710-23-000036:note_history:18]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, and restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of September 29, 2023, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.
  (was, 2023-05-09, similarity 0.9935):
[0001408710-23-000018:note_history:18]
The Term Loan Agreement contains affirmative and negative covenants applicable to the Borrower, including delivery of financial statements and other information, compliance with laws, maintenance of insurance, and restrictions on granting security interests or liens on its assets, disposing of its assets, incurring indebtedness and making acquisitions. While the term loan is outstanding, the Borrower is required to maintain a loan to value of the mortgaged real property ratio of not greater than 65%. If the loan to value ratio is not maintained, the Borrower will be required to provide additional security or prepay a portion of the term loan in order to restore the required ratio. The Company is also required to maintain a debt service coverage ratio of at least 1.25 times and a debt-to-equity ratio of less than or equal to 1.0 times. In the case of any payment of a dividend by the Company, its debt service coverage ratio must be at least 1.50 times. As of March 31, 2023, the Company was in compliance with all of its financial covenants under the Term Loan Agreement.

- changed (2023-11-07):
[0001408710-23-000036:note_history:19]
As of September 29, 2023, there was $9.1 million outstanding under the term loan.
  (was, 2023-05-09, similarity 0.9296):
[0001408710-23-000018:note_history:19]
As of March 31, 2023, there was $15.2 million outstanding under the term loan.

- changed (2023-11-07):
[0001408710-23-000036:note_history:20]
As of September 29, 2023, there was no amount outstanding under the 2023 Credit Facility Agreement.
  (was, 2023-05-09, similarity 0.8795):
[0001408710-23-000018:note_history:20]
As of March 31, 2023, there was no amount outstanding under the 2023 Credit Facility.

- removed (2023-11-07):
[0001408710-23-000018:note_history:21]
again. During the three and nine months ended March 31, 2023, the Company recorded $0.6 million and $1.7 million, respectively, of interest expense in connection with this term loan, including the impact from interest rate swaps.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0001408710-23-000036:note_history:22]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of September 29, 2023 and June 30, 2023:
  (was, 2023-05-09, similarity 0.9655):
[0001408710-23-000018:note_history:22]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of March 31, 2023 and June 24, 2022:

- added (2023-11-07):
[0001408710-23-000036:note_history:23]
|  | September 29, 2023 |  | June 30, 2023 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 185,691 |  |  | $ | 186,414 |  |  | $ | 172,992 |  |  | $ | 173,137 |  |
| Due between one to five years | 179,066 |  |  | 176,014 |  |  | 149,385 |  |  | 145,963 |  |
| Total | $ | 364,757 |  |  | $ | 362,428 |  |  | $ | 322,377 |  |  | $ | 319,100 |  |

- removed (2023-11-07):
[0001408710-23-000018:note_history:24]
|  | March 31, 2023 |  | June 24, 2022 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 150,720 |  |  | $ | 150,547 |  |  | $ | 101,976 |  |  | $ | 101,400 |  |
| Due between one to five years | 161,498 |  |  | 157,433 |  |  | 184,197 |  |  | 178,757 |  |
| Total | $ | 312,218 |  |  | $ | 307,980 |  |  | $ | 286,173 |  |  | $ | 280,157 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0001408710-23-000036:note_history:25]
The movements of long-term borrowings for the three months ended September 29, 2023 and September 30, 2022 were as follows:
  (was, 2023-05-09, similarity 0.8756):
[0001408710-23-000018:note_history:25]
The movements of long-term borrowings for the nine months ended March 31, 2023 and March 25, 2022 were as follows:

- changed (2023-11-07):
[0001408710-23-000036:note_history:26]
|  | Three Months Ended |
| (in thousands) | September 29,2023 |  | September 30,2022 |
| Opening balance | $ | 12,188 |  |  | $ | 27,421 |  |
| Repayments during the period | (3,047) |  |  | (6,094) |  |
| Closing balance | $ | 9,141 |  |  | $ | 21,327 |  |
  (was, 2023-05-09, similarity 0.9337):
[0001408710-23-000018:note_history:26]
|  | Nine Months Ended |
| (in thousands) | March 31,2023 |  | March 25,2022 |
| Opening balance | $ | 27,421 |  |  | $ | 39,609 |  |
| Repayments during the period | (12,187) |  |  | (9,141) |  |
| Closing balance | $ | 15,234 |  |  | $ | 30,468 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0001408710-23-000036:note_history:27]
| (in thousands) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofSeptember 29, 2023 |  | As ofJune 30, 2023 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 9,141 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (24) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 9,117 |  |  | $ | 12,156 |  |
  (was, 2023-05-09, similarity 0.6652):
[0001408710-23-000018:note_history:27]
| (in thousands of U.S. dollars) |  |  |  |  |  |  |  |
| Rate | Conditions |  | Maturity |  | As ofMarch 31, 2023 |  | As ofJune 24, 2022 |
| Long-term borrowings, current portion, net: |  |  |  |  |  |  |  |
| Long-term borrowings, current portion |  |  |  |  | $ | 12,188 |  |  | $ | 12,188 |  |
| Less: Unamortized debt issuance costs, current portion |  |  |  |  | (32) |  |  | (32) |  |
| Long-term borrowings, current portion, net |  |  |  |  | $ | 12,156 |  |  | $ | 12,156 |  |
| Long-term borrowings, non-current portion, net: |  |  |  |  |  |  |  |
| Term loan borrowings: |  |  |  |  |  |  |  |
| 3-month LIBOR +1.35% per annum (1) | Repayable inquarterly installments |  | June 2024 |  | $ | 15,234 |  |  | $ | 27,421 |  |
| Less: Current portion |  |  |  |  | (12,187) |  |  | (12,188) |  |
| Less: Unamortized debt issuance costs, non-current portion |  |  |  |  | (8) |  |  | (31) |  |
| Long-term borrowings, non-current portion, net |  |  |  |  | $ | 3,039 |  |  | $ | 15,202 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0001408710-23-000036:note_history:28]
As of September 29, 2023, future maturities of long-term borrowings during each fiscal year were as follows:
  (was, 2023-05-09, similarity 0.95):
[0001408710-23-000018:note_history:28]
As of March 31, 2023, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2023-11-07):
[0001408710-23-000036:note_history:29]
| (in thousands) |  |
| 2024 (remaining nine months) | $ | 9,141 |  |
  (was, 2023-05-09, similarity 0.7451):
[0001408710-23-000018:note_history:29]
| (in thousands) |  |
| 2023 (remaining three months) | $ | 3,047 |  |
| 2024 | 12,187 |  |
| Total | $ | 15,234 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0001408710-23-000036:note_history:30]
| (in thousands, except percentages) | Three Months EndedSeptember 29, 2023 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 30, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 254,859 |  |  |  |  | $ | 345,080 |  |  |  |
| Others (1) | 3,460 |  |  |  |  | 3,624 |  |  |  |
| Total revenue in North America | 258,319 |  |  | 37.7 | % |  | 348,704 |  |  | 53.2 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel (2) | 210,676 |  |  |  |  | 37,277 |  |  |  |
| India | 70,777 |  |  |  |  | 80,033 |  |  |  |
| Malaysia | 33,319 |  |  |  |  | 49,324 |  |  |  |
| China | 20,260 |  |  |  |  | 23,064 |  |  |  |
| Hong Kong | 15,788 |  |  |  |  | 32,472 |  |  |  |
| Thailand | 13,027 |  |  |  |  | 12,616 |  |  |  |
| Japan | 6,810 |  |  |  |  | 10,348 |  |  |  |
| Others | 1,165 |  |  |  |  | 3,160 |  |  |  |
| Total revenue in Asia-Pacific and others | 371,822 |  |  | 54.2 | % |  | 248,294 |  |  | 37.9 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 29,774 |  |  |  |  | 32,832 |  |  |  |
| Germany | 12,780 |  |  |  |  | 13,314 |  |  |  |
| Others | 12,782 |  |  |  |  | 12,285 |  |  |  |
| Total revenue in Europe | $ | 55,336 |  |  | 8.1 | % |  | $ | 58,431 |  |  | 8.9 | % |
| Total revenue | $ | 685,477 |  |  | 100.0 | % |  | $ | 655,429 |  |  | 100.0 | % |
  (was, 2023-05-09, similarity 0.8045):
[0001408710-23-000018:note_history:30]
| (in thousands, except percentages) | Three Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 292,475 |  |  |  |  | $ | 781,469 |  |  |  |
| Others (1) | 4,123 |  |  |  |  | 8,996 |  |  |  |
| Total revenue in North America | 296,598 |  |  | 52.5 | % |  | 790,465 |  |  | 47.2 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 70,956 |  |  |  |  | 210,009 |  |  |  |
| Malaysia | 51,188 |  |  |  |  | 163,306 |  |  |  |
| Hong Kong | 17,338 |  |  |  |  | 61,575 |  |  |  |
| Israel | 16,883 |  |  |  |  | 67,318 |  |  |  |
| Japan | 16,449 |  |  |  |  | 47,258 |  |  |  |
| China | 12,843 |  |  |  |  | 40,624 |  |  |  |
| Others | 10,559 |  |  |  |  | 34,349 |  |  |  |
| Total revenue in Asia-Pacific and others | 196,216 |  |  | 34.8 | % |  | 624,439 |  |  | 37.3 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland (2) | 28,640 |  |  |  |  | 133,024 |  |  |  |
| U.K. | 21,632 |  |  |  |  | 64,151 |  |  |  |
| Germany | 10,688 |  |  |  |  | 28,098 |  |  |  |
| Others | 10,621 |  |  |  |  | 34,173 |  |  |  |
| Total revenue in Europe | $ | 71,581 |  |  | 12.7 | % |  | $ | 259,446 |  |  | 15.5 | % |
| Total revenue | $ | 564,395 |  |  | 100.0 | % |  | $ | 1,674,350 |  |  | 100.0 | % |

- added (2023-11-07):
[0001408710-23-000036:note_history:31]
(2)Due to increase in revenue from a significant customer.

- removed (2023-11-07):
[0001408710-23-000018:note_history:32]
| (in thousands, except percentages) | Three Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 310,100 |  |  |  |  | $ | 975,098 |  |  |  |
| Others (1) | 6,035 |  |  |  |  | 13,693 |  |  |  |
| Total revenue in North America | 316,135 |  |  | 47.5 | % |  | 988,791 |  |  | 49.7 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 85,731 |  |  |  |  | 247,942 |  |  |  |
| Israel | 85,562 |  |  |  |  | 182,732 |  |  |  |
| Hong Kong | 37,120 |  |  |  |  | 109,315 |  |  |  |
| Malaysia | 30,688 |  |  |  |  | 130,402 |  |  |  |
| Thailand | 16,706 |  |  |  |  | 45,420 |  |  |  |
| China | 11,194 |  |  |  |  | 60,738 |  |  |  |
| Japan | 10,044 |  |  |  |  | 32,129 |  |  |  |
| Others | 2,896 |  |  |  |  | 7,957 |  |  |  |
| Total revenue in Asia-Pacific and others | 279,941 |  |  | 42.1 | % |  | 816,635 |  |  | 41.1 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 40,292 |  |  |  |  | 103,440 |  |  |  |
| Germany | 14,532 |  |  |  |  | 40,975 |  |  |  |
| Ireland (2) | 176 |  |  |  |  | 438 |  |  |  |
| Others | 14,205 |  |  |  |  | 39,087 |  |  |  |
| Total revenue in Europe | $ | 69,205 |  |  | 10.4 | % |  | $ | 183,940 |  |  | 9.2 | % |
| Total revenue | $ | 665,281 |  |  | 100.0 | % |  | $ | 1,989,366 |  |  | 100.0 | % |

- removed (2023-11-07):
[0001408710-23-000018:note_history:33]
(2)Due to change in bill-to-location for a certain customer.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0001408710-23-000036:note_history:34]
A contract asset is recognized when the Company has recognized revenues prior to an invoice for payment. Contract assets are recognized in the unaudited condensed consolidated balance sheets under other current assets and transferred to accounts receivable when rights to payment become unconditional.
  (was, 2023-05-09, similarity 0.8752):
[0001408710-23-000018:note_history:34]
A contract asset is recognized when the Company has recognized revenues prior to generating an invoice for payment. Contract assets are classified separately within the unaudited condensed consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional.

- added (2023-11-07):
[0001408710-23-000036:note_history:35]
As of September 29, 2023 and June 30, 2023, the contract assets are de minimis.

- changed (2023-11-07):
[0001408710-23-000036:note_history:36]
A contract liability is recognized when the Company has advance payment arrangements with customers. Contract liabilities are recognized in the unaudited condensed consolidated balance sheets under other payables. The contract liabilities balance is normally recognized as revenue within six months.
  (was, 2023-05-09, similarity 0.767):
[0001408710-23-000018:note_history:36]
A contract liability is recognized when the Company has advance payment arrangements with customers. The contract liabilities balance is normally recognized as revenue within six months.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-11-07):
[0001408710-23-000036:note_history:37]
| (in thousands, except percentages) | Three Months EndedSeptember 29, 2023 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 30, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 254,859 |  |  |  |  | $ | 345,080 |  |  |  |
| Others (1) | 3,460 |  |  |  |  | 3,624 |  |  |  |
| Total revenue in North America | 258,319 |  |  | 37.7 | % |  | 348,704 |  |  | 53.2 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel (2) | 210,676 |  |  |  |  | 37,277 |  |  |  |
| India | 70,777 |  |  |  |  | 80,033 |  |  |  |
| Malaysia | 33,319 |  |  |  |  | 49,324 |  |  |  |
| China | 20,260 |  |  |  |  | 23,064 |  |  |  |
| Hong Kong | 15,788 |  |  |  |  | 32,472 |  |  |  |
| Thailand | 13,027 |  |  |  |  | 12,616 |  |  |  |
| Japan | 6,810 |  |  |  |  | 10,348 |  |  |  |
| Others | 1,165 |  |  |  |  | 3,160 |  |  |  |
| Total revenue in Asia-Pacific and others | 371,822 |  |  | 54.2 | % |  | 248,294 |  |  | 37.9 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 29,774 |  |  |  |  | 32,832 |  |  |  |
| Germany | 12,780 |  |  |  |  | 13,314 |  |  |  |
| Others | 12,782 |  |  |  |  | 12,285 |  |  |  |
| Total revenue in Europe | $ | 55,336 |  |  | 8.1 | % |  | $ | 58,431 |  |  | 8.9 | % |
| Total revenue | $ | 685,477 |  |  | 100.0 | % |  | $ | 655,429 |  |  | 100.0 | % |
  (was, 2023-05-09, similarity 0.8045):
[0001408710-23-000018:note_history:37]
| (in thousands, except percentages) | Three Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 292,475 |  |  |  |  | $ | 781,469 |  |  |  |
| Others (1) | 4,123 |  |  |  |  | 8,996 |  |  |  |
| Total revenue in North America | 296,598 |  |  | 52.5 | % |  | 790,465 |  |  | 47.2 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 70,956 |  |  |  |  | 210,009 |  |  |  |
| Malaysia | 51,188 |  |  |  |  | 163,306 |  |  |  |
| Hong Kong | 17,338 |  |  |  |  | 61,575 |  |  |  |
| Israel | 16,883 |  |  |  |  | 67,318 |  |  |  |
| Japan | 16,449 |  |  |  |  | 47,258 |  |  |  |
| China | 12,843 |  |  |  |  | 40,624 |  |  |  |
| Others | 10,559 |  |  |  |  | 34,349 |  |  |  |
| Total revenue in Asia-Pacific and others | 196,216 |  |  | 34.8 | % |  | 624,439 |  |  | 37.3 | % |
| Europe |  |  |  |  |  |  |  |
| Ireland (2) | 28,640 |  |  |  |  | 133,024 |  |  |  |
| U.K. | 21,632 |  |  |  |  | 64,151 |  |  |  |
| Germany | 10,688 |  |  |  |  | 28,098 |  |  |  |
| Others | 10,621 |  |  |  |  | 34,173 |  |  |  |
| Total revenue in Europe | $ | 71,581 |  |  | 12.7 | % |  | $ | 259,446 |  |  | 15.5 | % |
| Total revenue | $ | 564,395 |  |  | 100.0 | % |  | $ | 1,674,350 |  |  | 100.0 | % |

- added (2023-11-07):
[0001408710-23-000036:note_history:38]
(2)Due to increase in revenue from a significant customer.

- changed (2023-11-07):
[0001408710-23-000036:note_history:39]
| (in thousands, except percentages) | Three Months EndedSeptember 29, 2023 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 30, 2022 |  | As a % of TotalRevenues |
| Optical communications | $ | 533,257 |  |  | 77.8 | % |  | $ | 497,561 |  |  | 75.9 | % |
| Automotive, lasers and other | 152,220 |  |  | 22.2 | % |  | 157,868 |  |  | 24.1 | % |
| Total | $ | 685,477 |  |  | 100.0 | % |  | $ | 655,429 |  |  | 100.0 | % |
  (was, 2023-05-09, similarity 0.6301):
[0001408710-23-000018:note_history:39]
| (in thousands, except percentages) | Three Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |
| Optical communications | $ | 502,615 |  |  | 75.5 | % |  | $ | 1,506,232 |  |  | 75.7 | % |
| Lasers, sensors and other | 162,666 |  |  | 24.5 | % |  | 483,134 |  |  | 24.3 | % |
| Total | $ | 665,281 |  |  | 100.0 | % |  | $ | 1,989,366 |  |  | 100.0 | % |

- changed (2023-11-07):
[0001408710-23-000036:note_history:40]
A contract asset is recognized when the Company has recognized revenues prior to an invoice for payment. Contract assets are recognized in the unaudited condensed consolidated balance sheets under other current assets and transferred to accounts receivable when rights to payment become unconditional.
  (was, 2023-05-09, similarity 0.8752):
[0001408710-23-000018:note_history:40]
A contract asset is recognized when the Company has recognized revenues prior to generating an invoice for payment. Contract assets are classified separately within the unaudited condensed consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional.

- added (2023-11-07):
[0001408710-23-000036:note_history:41]
As of September 29, 2023 and June 30, 2023, the contract assets are de minimis.

- changed (2023-11-07):
[0001408710-23-000036:note_history:42]
A contract liability is recognized when the Company has advance payment arrangements with customers. Contract liabilities are recognized in the unaudited condensed consolidated balance sheets under other payables. The contract liabilities balance is normally recognized as revenue within six months.
  (was, 2023-05-09, similarity 0.767):
[0001408710-23-000018:note_history:42]
A contract liability is recognized when the Company has advance payment arrangements with customers. The contract liabilities balance is normally recognized as revenue within six months.

- changed (2023-11-07):
[0001408710-23-000036:note_history:43]
The following tables summarize the activity in the Company’s contract liabilities during the three months ended September 29, 2023:
  (was, 2023-05-09, similarity 0.8614):
[0001408710-23-000018:note_history:43]
The following tables summarize the activity in the Company’s contract assets and contract liabilities during the nine months ended March 31, 2023:

- changed (2023-11-07):
[0001408710-23-000036:note_history:44]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 30, 2023 | $ | 3,036 |  |
| Advance payment received during the period | 1,497 |  |
| Revenue recognized | (3,285) |  |
| Ending balance, September 29, 2023 | $ | 1,248 |  |
  (was, 2023-05-09, similarity 0.9712):
[0001408710-23-000018:note_history:44]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 24, 2022 | $ | 1,982 |  |
| Advance payment received during the period | 13,073 |  |
| Revenue recognized | (11,806) |  |
| Ending balance, March 31, 2023 | $ | 3,249 |  |

- removed (2023-11-07):
[0001408710-23-000018:note_history:45]
| (in thousands, except percentages) | Three Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 31, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 310,100 |  |  |  |  | $ | 975,098 |  |  |  |
| Others (1) | 6,035 |  |  |  |  | 13,693 |  |  |  |
| Total revenue in North America | 316,135 |  |  | 47.5 | % |  | 988,791 |  |  | 49.7 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| India | 85,731 |  |  |  |  | 247,942 |  |  |  |
| Israel | 85,562 |  |  |  |  | 182,732 |  |  |  |
| Hong Kong | 37,120 |  |  |  |  | 109,315 |  |  |  |
| Malaysia | 30,688 |  |  |  |  | 130,402 |  |  |  |
| Thailand | 16,706 |  |  |  |  | 45,420 |  |  |  |
| China | 11,194 |  |  |  |  | 60,738 |  |  |  |
| Japan | 10,044 |  |  |  |  | 32,129 |  |  |  |
| Others | 2,896 |  |  |  |  | 7,957 |  |  |  |
| Total revenue in Asia-Pacific and others | 279,941 |  |  | 42.1 | % |  | 816,635 |  |  | 41.1 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 40,292 |  |  |  |  | 103,440 |  |  |  |
| Germany | 14,532 |  |  |  |  | 40,975 |  |  |  |
| Ireland (2) | 176 |  |  |  |  | 438 |  |  |  |
| Others | 14,205 |  |  |  |  | 39,087 |  |  |  |
| Total revenue in Europe | $ | 69,205 |  |  | 10.4 | % |  | $ | 183,940 |  |  | 9.2 | % |
| Total revenue | $ | 665,281 |  |  | 100.0 | % |  | $ | 1,989,366 |  |  | 100.0 | % |

- removed (2023-11-07):
[0001408710-23-000018:note_history:46]
(2)Due to change in bill-to-location for a certain customer.

- removed (2023-11-07):
[0001408710-23-000018:note_history:47]
| (in thousands, except percentages) | Three Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 25, 2022 |  | As a % of TotalRevenues |
| Optical communications | $ | 440,003 |  |  | 78.0 | % |  | $ | 1,318,087 |  |  | 78.7 | % |
| Lasers, sensors and other | 124,392 |  |  | 22.0 | % |  | 356,263 |  |  | 21.3 | % |
| Total | $ | 564,395 |  |  | 100.0 | % |  | $ | 1,674,350 |  |  | 100.0 | % |

- removed (2023-11-07):
[0001408710-23-000018:note_history:48]
| (in thousands) | ContractAssets |
| Beginning balance, June 24, 2022 | $ | 13,464 |  |
| Revenue recognized | 57,617 |  |
| Amounts collected or invoiced | (50,000) |  |
| Ending balance, March 31, 2023 | $ | 21,081 |  |
