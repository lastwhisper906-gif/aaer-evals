# FN MD&A — 0001408710-25-000023


## mdna

[0001408710-25-000023:mdna:1]
[same as prior period, unchanged from 0001408710-25-000008:mdna:1]

[0001408710-25-000023:mdna:2]
[same as prior period, unchanged from 0001408710-25-000008:mdna:2]

[0001408710-25-000023:mdna:3]
[same as prior period, unchanged from 0001408710-25-000008:mdna:3]

[0001408710-25-000023:mdna:4]
[same as prior period, unchanged from 0001408710-25-000008:mdna:4]

[0001408710-25-000023:mdna:5]
•our expectation that the portion of our revenues attributable to customers in regions outside of North America for the remainder of fiscal year 2025 will be in line with the portion of revenues attributable to such customers during the nine months ended March 28, 2025;

[0001408710-25-000023:mdna:6]
[same as prior period, unchanged from 0001408710-25-000008:mdna:6]

[0001408710-25-000023:mdna:7]
[same as prior period, unchanged from 0001408710-25-000008:mdna:7]

[0001408710-25-000023:mdna:8]
[same as prior period, unchanged from 0001408710-25-000008:mdna:8]

[0001408710-25-000023:mdna:9]
[same as prior period, unchanged from 0001408710-25-000008:mdna:9]

[0001408710-25-000023:mdna:10]
[same as prior period, unchanged from 0001408710-25-000008:mdna:10]

[0001408710-25-000023:mdna:11]
[same as prior period, unchanged from 0001408710-25-000008:mdna:11]

[0001408710-25-000023:mdna:12]
[same as prior period, unchanged from 0001408710-25-000008:mdna:12]

[0001408710-25-000023:mdna:13]
[same as prior period, unchanged from 0001408710-25-000008:mdna:13]

[0001408710-25-000023:mdna:14]
[same as prior period, unchanged from 0001408710-25-000008:mdna:14]

[0001408710-25-000023:mdna:15]
[same as prior period, unchanged from 0001408710-25-000008:mdna:15]

[0001408710-25-000023:mdna:16]
[same as prior period, unchanged from 0001408710-25-000008:mdna:16]

[0001408710-25-000023:mdna:17]
[same as prior period, unchanged from 0001408710-25-000008:mdna:17]

[0001408710-25-000023:mdna:18]
[same as prior period, unchanged from 0001408710-25-000008:mdna:18]

[0001408710-25-000023:mdna:19]
[same as prior period, unchanged from 0001408710-25-000008:mdna:19]

[0001408710-25-000023:mdna:20]
[same as prior period, unchanged from 0001408710-25-000008:mdna:20]

[0001408710-25-000023:mdna:21]
[same as prior period, unchanged from 0001408710-25-000008:mdna:21]

[0001408710-25-000023:mdna:22]
[same as prior period, unchanged from 0001408710-25-000008:mdna:22]

[0001408710-25-000023:mdna:23]
[same as prior period, unchanged from 0001408710-25-000008:mdna:23]

[0001408710-25-000023:mdna:24]
[same as prior period, unchanged from 0001408710-25-000008:mdna:24]

[0001408710-25-000023:mdna:25]
[same as prior period, unchanged from 0001408710-25-000008:mdna:25]

[0001408710-25-000023:mdna:26]
[same as prior period, unchanged from 0001408710-25-000008:mdna:26]

[0001408710-25-000023:mdna:27]
[same as prior period, unchanged from 0001408710-25-000008:mdna:28]

[0001408710-25-000023:mdna:28]
[same as prior period, unchanged from 0001408710-25-000008:mdna:29]

[0001408710-25-000023:mdna:29]
The percentage of our revenues generated from a bill-to location outside of North America decreased from 62.8% in the three months ended March 29, 2024 to 53.8% in the three months ended March 28, 2025, primarily because of an increase in revenue from a customer in the United States.

[0001408710-25-000023:mdna:30]
The percentage of our revenues generated from a bill-to location outside of North America decreased from 63.7% in the nine months ended March 29, 2024 to 56.8% in the nine months ended March 28, 2025, primarily because of an increase in revenue from a customer in the United States.

[0001408710-25-000023:mdna:31]
Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside North America for the remainder of fiscal year 2025 will be in line with the portion of revenues attributable to such customers during the nine months ended March 28, 2025.

[0001408710-25-000023:mdna:32]
[same as prior period, unchanged from 0001408710-25-000008:mdna:33]

[0001408710-25-000023:mdna:33]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28, 2025 |  | March 29, 2024 |  | March 28, 2025 |  | March 29, 2024 |
| North America | 46.2 | % |  | 37.2 | % |  | 43.2 | % |  | 36.3 | % |
| Asia-Pacific and others | 45.9 |  |  | 57.0 |  |  | 49.0 |  |  | 57.2 |  |
| Europe | 7.9 |  |  | 5.8 |  |  | 7.8 |  |  | 6.5 |  |
|  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001408710-25-000023:mdna:34]
[same as prior period, unchanged from 0001408710-25-000008:mdna:35]

[0001408710-25-000023:mdna:35]
[same as prior period, unchanged from 0001408710-25-000008:mdna:36]

[0001408710-25-000023:mdna:36]
[same as prior period, unchanged from 0001408710-25-000008:mdna:37]

[0001408710-25-000023:mdna:37]
[same as prior period, unchanged from 0001408710-25-000008:mdna:38]

[0001408710-25-000023:mdna:38]
[same as prior period, unchanged from 0001408710-25-000008:mdna:39]

[0001408710-25-000023:mdna:39]
[same as prior period, unchanged from 0001408710-25-000008:mdna:40]

[0001408710-25-000023:mdna:40]
[same as prior period, unchanged from 0001408710-25-000008:mdna:41]

[0001408710-25-000023:mdna:41]
[same as prior period, unchanged from 0001408710-25-000008:mdna:42]

[0001408710-25-000023:mdna:42]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative and other support personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other general expenses not related to

[0001408710-25-000023:mdna:43]
cost of revenues. In fiscal year 2025, we expect our SG&A expenses will increase compared with our fiscal year 2024 SG&A expenses, mainly due to increases in employee costs, legal expenses and research and development ("R&D") expenses.

[0001408710-25-000023:mdna:44]
[same as prior period, unchanged from 0001408710-25-000008:mdna:44]

[0001408710-25-000023:mdna:45]
[same as prior period, unchanged from 0001408710-25-000008:mdna:45]

[0001408710-25-000023:mdna:46]
[same as prior period, unchanged from 0001408710-25-000008:mdna:46]

[0001408710-25-000023:mdna:47]
[same as prior period, unchanged from 0001408710-25-000008:mdna:47]

[0001408710-25-000023:mdna:48]
[same as prior period, unchanged from 0001408710-25-000008:mdna:48]

[0001408710-25-000023:mdna:49]
[same as prior period, unchanged from 0001408710-25-000008:mdna:49]

[0001408710-25-000023:mdna:50]
|  | As of March 28, 2025 |  | As of June 28, 2024 |
| (in thousands, except percentages) | ForeignCurrency |  | $ |  | % |  | ForeignCurrency |  | $ |  | % |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 1,145,359 |  |  | 33,796 |  |  | 80.9 | % |  | 1,046,000 |  |  | 28,385 |  |  | 72.5 | % |
| RMB | 35,054 |  |  | 4,885 |  |  | 11.7 |  |  | 42,852 |  |  | 6,013 |  |  | 15.4 |  |
| GBP | 2,400 |  |  | 3,106 |  |  | 7.4 |  |  | 3,778 |  |  | 4,773 |  |  | 12.1 |  |
| Total |  |  | $ | 41,787 |  |  | 100.0 | % |  |  |  | $ | 39,171 |  |  | 100.0 | % |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 4,087,353 |  |  | 120,606 |  |  | 91.5 | % |  | 3,263,391 |  |  | 88,559 |  |  | 87.4 | % |
| RMB | 79,458 |  |  | 11,074 |  |  | 8.4 |  |  | 78,418 |  |  | 11,003 |  |  | 10.9 |  |
| GBP | 111 |  |  | 144 |  |  | 0.1 |  |  | 1,359 |  |  | 1,717 |  |  | 1.7 |  |
| Total |  |  | $ | 131,824 |  |  | 100.0 | % |  |  |  | $ | 101,279 |  |  | 100.0 | % |

[0001408710-25-000023:mdna:51]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable, accrued employee benefits and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of March 28, 2025, there was $155.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 28, 2024, there was $135.0 million of foreign currency forward contracts outstanding on the Thai baht payables.

[0001408710-25-000023:mdna:52]
The RMB assets represent cash and cash equivalents, trade accounts receivable, other receivables, and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable, accrued payroll, bonus and related expenses, and other payables. As of March 28, 2025 and June 28, 2024, we did not have any derivative contracts denominated in RMB.

[0001408710-25-000023:mdna:53]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable, accrued expenses, and other payables. As of March 28, 2025 and June 28, 2024, we did not have any derivative contracts denominated in GBP.

[0001408710-25-000023:mdna:54]
For the three months ended March 28, 2025 and March 29, 2024, we recorded unrealized gain of $1.6 million and unrealized loss of $3.7 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-25-000023:mdna:55]
For the nine months ended March 28, 2025 and March 29, 2024, we recorded unrealized gain of $0.6 million and unrealized loss $0.8 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-25-000023:mdna:56]
[same as prior period, unchanged from 0001408710-25-000008:mdna:56]

[0001408710-25-000023:mdna:57]
[same as prior period, unchanged from 0001408710-25-000008:mdna:57]

[0001408710-25-000023:mdna:58]
[same as prior period, unchanged from 0001408710-25-000008:mdna:58]

[0001408710-25-000023:mdna:59]
[same as prior period, unchanged from 0001408710-25-000008:mdna:59]

[0001408710-25-000023:mdna:60]
[same as prior period, unchanged from 0001408710-25-000008:mdna:60]

[0001408710-25-000023:mdna:61]
[same as prior period, unchanged from 0001408710-25-000008:mdna:61]

[0001408710-25-000023:mdna:62]
[same as prior period, unchanged from 0001408710-25-000008:mdna:62]

[0001408710-25-000023:mdna:63]
[same as prior period, unchanged from 0001408710-25-000008:mdna:63]

[0001408710-25-000023:mdna:64]
[same as prior period, unchanged from 0001408710-25-000008:mdna:64]

[0001408710-25-000023:mdna:65]
[same as prior period, unchanged from 0001408710-25-000008:mdna:65]

[0001408710-25-000023:mdna:66]
[same as prior period, unchanged from 0001408710-25-000008:mdna:66]

[0001408710-25-000023:mdna:67]
[same as prior period, unchanged from 0001408710-25-000008:mdna:67]

[0001408710-25-000023:mdna:68]
[same as prior period, unchanged from 0001408710-25-000008:mdna:68]

[0001408710-25-000023:mdna:69]
[same as prior period, unchanged from 0001408710-25-000008:mdna:69]

[0001408710-25-000023:mdna:70]
As of March 28, 2025, the corporate income tax rates for our subsidiaries in the PRC, the U.S., the U.K. and Israel are 25%, 21%, 25% and 23%, respectively.

[0001408710-25-000023:mdna:71]
[same as prior period, unchanged from 0001408710-25-000008:mdna:71]

[0001408710-25-000023:mdna:72]
[same as prior period, unchanged from 0001408710-25-000008:mdna:72]

[0001408710-25-000023:mdna:73]
[same as prior period, unchanged from 0001408710-25-000008:mdna:73]

[0001408710-25-000023:mdna:74]
[same as prior period, unchanged from 0001408710-25-000008:mdna:74]

[0001408710-25-000023:mdna:75]
[same as prior period, unchanged from 0001408710-25-000008:mdna:75]

[0001408710-25-000023:mdna:76]
[same as prior period, unchanged from 0001408710-25-000008:mdna:76]

[0001408710-25-000023:mdna:77]
| (in thousands) | Three Months Ended |  | Nine Months Ended |
| March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
| Revenues | $ | 871,799 |  |  | $ | 731,535 |  |  | $ | 2,509,635 |  |  | $ | 2,129,706 |  |
| Cost of revenues | (769,616) |  |  | (640,600) |  |  | (2,207,577) |  |  | (1,866,037) |  |
| Gross profit | 102,183 |  |  | 90,935 |  |  | 302,058 |  |  | 263,669 |  |
| Selling, general and administrative expenses | (22,063) |  |  | (19,628) |  |  | (65,300) |  |  | (59,373) |  |
| Restructuring and other related costs | (1,264) |  |  | — |  |  | (1,367) |  |  | — |  |
| Operating income | 78,856 |  |  | 71,307 |  |  | 235,391 |  |  | 204,296 |  |
| Interest income | 10,145 |  |  | 8,509 |  |  | 32,392 |  |  | 22,155 |  |
| Interest expense | — |  |  | (26) |  |  | — |  |  | (107) |  |
| Foreign exchange gain (loss), net | (2,675) |  |  | 3,348 |  |  | (5,728) |  |  | (25) |  |
| Other income (expense), net | (30) |  |  | 175 |  |  | (111) |  |  | 60 |  |
| Income before income taxes | 86,296 |  |  | 83,313 |  |  | 261,944 |  |  | 226,379 |  |
| Income tax expense | (5,006) |  |  | (2,397) |  |  | (16,624) |  |  | (11,264) |  |
| Net income | 81,290 |  |  | 80,916 |  |  | 245,320 |  |  | 215,115 |  |
| Other comprehensive income (loss), net of tax | 6,200 |  |  | (8,855) |  |  | 11,690 |  |  | 3,457 |  |
| Net comprehensive income | $ | 87,490 |  |  | $ | 72,061 |  |  | $ | 257,010 |  |  | $ | 218,572 |  |

[0001408710-25-000023:mdna:78]
[same as prior period, unchanged from 0001408710-25-000008:mdna:78]

[0001408710-25-000023:mdna:79]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
| Revenues | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenues | (88.3) |  |  | (87.6) |  |  | (88.0) |  |  | (87.6) |  |
| Gross profit | 11.7 |  |  | 12.4 |  |  | 12.0 |  |  | 12.4 |  |
| Selling, general and administrative expenses | (2.5) |  |  | (2.7) |  |  | (2.6) |  |  | (2.8) |  |
| Restructuring and other related costs | (0.1) |  |  | — |  |  | 0.0 |  |  | — |  |
| Operating income | 9.0 |  |  | 9.7 |  |  | 9.4 |  |  | 9.6 |  |
| Interest income | 1.2 |  |  | 1.2 |  |  | 1.3 |  |  | 1.0 |  |
| Interest expense | — |  |  | 0.0 |  |  | — |  |  | 0.0 |  |
| Foreign exchange gain (loss), net | (0.3) |  |  | 0.5 |  |  | (0.2) |  |  | 0.0 |  |
| Other income (expense), net | 0.0 |  |  | 0.0 |  |  | 0.0 |  |  | 0.0 |  |
| Income before income taxes | 10.0 |  |  | 11.4 |  |  | 10.4 |  |  | 10.6 |  |
| Income tax expense | (0.6) |  |  | (0.3) |  |  | (0.7) |  |  | (0.5) |  |
| Net income | 9.3 |  |  | 11.1 |  |  | 9.8 |  |  | 10.1 |  |
| Other comprehensive income (loss), net of tax | 0.7 |  |  | (1.2) |  |  | 0.5 |  |  | 0.2 |  |
| Net comprehensive income | 10.0 | % |  | 9.9 | % |  | 10.2 | % |  | 10.3 | % |

[0001408710-25-000023:mdna:80]
34

[0001408710-25-000023:mdna:81]
[same as prior period, unchanged from 0001408710-25-000008:mdna:81]

[0001408710-25-000023:mdna:82]
| (in thousands, except percentages) | Three Months EndedMarch 28, 2025 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 28, 2025 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 251,105 |  |  |  |  | $ | 879,087 |  |  |  |
| Telecom | 406,126 |  |  |  |  | 1,051,609 |  |  |  |
| Total revenue - Optical communications | $ | 657,231 |  |  | 75.4 | % |  | $ | 1,930,696 |  |  | 76.9 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 129,468 |  |  |  |  | $ | 336,456 |  |  |  |
| Industrial laser | 40,464 |  |  |  |  | 113,332 |  |  |  |
| Others | 44,636 |  |  |  |  | 129,151 |  |  |  |
| Total revenue - Non-optical communications | $ | 214,568 |  |  | 24.6 | % |  | $ | 578,939 |  |  | 23.1 | % |
| Total revenue | $ | 871,799 |  |  | 100.0 | % |  | $ | 2,509,635 |  |  | 100.0 | % |

[0001408710-25-000023:mdna:83]
| (in thousands, except percentages) | Three Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 305,478 |  |  |  |  | $ | 835,642 |  |  |  |
| Telecom | 285,970 |  |  |  |  | 856,997 |  |  |  |
| Total revenue - Optical communications | $ | 591,448 |  |  | 80.9 | % |  | $ | 1,692,639 |  |  | 79.5 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 73,636 |  |  |  |  | $ | 241,166 |  |  |  |
| Industrial laser | 30,319 |  |  |  |  | 90,582 |  |  |  |
| Others | 36,132 |  |  |  |  | 105,319 |  |  |  |
| Total revenue - Non-optical communications | $ | 140,087 |  |  | 19.1 | % |  | $ | 437,067 |  |  | 20.5 | % |
| Total revenue | $ | 731,535 |  |  | 100.0 | % |  | $ | 2,129,706 |  |  | 100.0 | % |

[0001408710-25-000023:mdna:84]
Comparison of Three and Nine Months Ended March 28, 2025 with Three and Nine Months Ended March 29, 2024

[0001408710-25-000023:mdna:85]
[same as prior period, unchanged from 0001408710-25-000008:mdna:85]

[0001408710-25-000023:mdna:86]
Our revenues increased by $140.3 million, or 19.2%, to $871.8 million for the three months ended March 28, 2025, compared with $731.5 million for the three months ended March 29, 2024. This increase was primarily due to an increase in our key customers’ demand for both optical communications products and non-optical communications products. Revenues from optical communications products, which represented $657.2 million, or 75.4%, of our revenues for the three months ended March 28, 2025, increased by $65.8 million, or 11.1%, compared to the same period in the prior fiscal year, mainly due to an increase in revenues from data communication products, primarily for artificial intelligence applications, and an increase in revenues from telecommunication products during the three months ended March 28, 2025. Revenues from non-optical communications products, which represented $214.6 million, or 24.6%, of our revenues for the three months ended March 28, 2025, increased by $74.5 million, or 53.2%, compared to the same period in the prior fiscal year, primarily due to growth in automotive revenue, as short-term inventory absorption issues have substantially subsided.

[0001408710-25-000023:mdna:87]
Our revenues increased by $379.9 million, or 17.8%, to $2,509.6 million for the nine months ended March 28, 2025, compared with $2,129.7 million for the nine months ended March 29, 2024. This increase was primarily due to an increase in our key customers’ demand for both optical communications products and non-optical communications products. Revenues from optical communications products, which represented $1,930.7 million, or 76.9%, of our revenues for the nine months ended March 28, 2025, increased by $238.1 million, or 14.1%, compared to the same period in the prior fiscal year, mainly due to an increase in revenues from data communication products, primarily for artificial intelligence applications, and an increase in revenues from telecommunication products during the nine months ended March 28, 2025. Revenues from non-optical communications products, which represented $578.9 million, or 23.1%, of our revenues for the nine months ended March 28, 2025, increased by $141.9 million, or 32.5%, compared to the same period in the prior fiscal year, primarily due to growth in automotive revenue, as short-term inventory absorption issues have substantially subsided.

[0001408710-25-000023:mdna:88]
[same as prior period, unchanged from 0001408710-25-000008:mdna:88]

[0001408710-25-000023:mdna:89]
Our cost of revenues increased by $129.0 million, or 20.1%, to $769.6 million, or 88.3% of revenues, for the three months ended March 28, 2025, compared with $640.6 million, or 87.6% of revenues, for the three months ended March 29, 2024. The increase was in line with the increase in sales volume.

[0001408710-25-000023:mdna:90]
Our cost of revenues increased by $341.6 million, or 18.3%, to $2,207.6 million, or 88.0% of revenues, for the nine months ended March 28, 2025, compared with $1,866.0 million, or 87.6% of revenues, for the nine months ended March 29, 2024. This increase was in line with the increase in sales volume.

[0001408710-25-000023:mdna:91]
[same as prior period, unchanged from 0001408710-25-000008:mdna:91]

[0001408710-25-000023:mdna:92]
Our gross profit increased by $11.3 million, or 12.4%, to $102.2 million, or 11.7% of revenues, for the three months ended March 28, 2025, compared with $90.9 million, or 12.4% of revenues, for the three months ended March 29, 2024. The increase was primarily due to an increase in sales volume.

[0001408710-25-000023:mdna:93]
Our gross profit increased by $38.4 million, or 14.6%, to $302.1 million, or 12.0% of revenues, for the nine months ended March 28, 2025, compared with $263.7 million, or 12.4% of revenues, for the nine months ended March 29, 2024. The increase was primarily due to an increase in sales volume.

[0001408710-25-000023:mdna:94]
[same as prior period, unchanged from 0001408710-25-000008:mdna:94]

[0001408710-25-000023:mdna:95]
Our SG&A expenses increased by $2.5 million, or 12.8%, to $22.1 million, or 2.5% of revenues, for the three months ended March 28, 2025, compared with $19.6 million, or 2.7% of revenues, for the three months ended March 29, 2024. The increase was primarily due to (1) an increase in legal expenses of $0.8 million, (2) an increase in executive compensation related expenses of $0.4 million, (3) an increase in information technology related expenses of $0.4 million, mainly from network, security system and new hardware costs, (4) an increase in share-based compensation expenses of $0.4 million, (5) an increase in R&D expenses of $0.3 million, and (6) an increase in a net realized loss from financial instruments of $0.3 million, offset by a net decrease in allowance for expected credit losses of $0.1 million.

[0001408710-25-000023:mdna:96]
Our SG&A expenses increased by $5.9 million, or 9.9%, to $65.3 million, or 2.6% of revenues, for the nine months ended March 28, 2025, compared with $59.4 million, or 2.8% of revenues, for the nine months ended March 29, 2024. The increase was primarily due to (1) an increase in executive compensation related expenses of $3.1 million, (2) an increase in legal expenses of $1.5 million, (3) an increase in information technology related expenses of $1.1 million, mainly from network, security system and new hardware costs, (4) an increase in share-based compensation expenses of $1.0 million, (5) an increase in R&D expenses of $1.0 million, and (6) an increase in severance expenses of $0.7 million, offset by (1) a net decrease in allowance for expected credit losses of $2.1 million and (2) a decrease in a net realized gain from financial instruments of $0.4 million.

[0001408710-25-000023:mdna:97]
Restructuring and other related costs

[0001408710-25-000023:mdna:98]
We recorded restructuring and other related costs for the three and nine months ended March 28, 2025 of $1.3 million, and $1.4 million, respectively, due to restructuring of operations in our subsidiary in Thailand. We had no restructuring costs for the three and nine months ended March 29, 2024.

[0001408710-25-000023:mdna:99]
[same as prior period, unchanged from 0001408710-25-000008:mdna:97]

[0001408710-25-000023:mdna:100]
Our operating income increased by $7.6 million, or 10.7%, to $78.9 million, or 9.0% of revenues, for the three months ended March 28, 2025, compared with $71.3 million, or 9.7% of revenues, for the three months ended March 29, 2024. The increase was primarily due to an increase in revenues.

[0001408710-25-000023:mdna:101]
Our operating income increased by $31.1 million, or 15.2%, to $235.4 million, or 9.4% of revenues, for the nine months ended March 28, 2025, compared with $204.3 million, or 9.6% of revenues, for the nine months ended March 29, 2024. The increase was primarily due to an increase in revenues.

[0001408710-25-000023:mdna:102]
[same as prior period, unchanged from 0001408710-25-000008:mdna:100]

[0001408710-25-000023:mdna:103]
Our interest income increased by $1.6 million, or 18.8%, to $10.1 million, or 1.2% of revenues, for the three months ended March 28, 2025, compared with $8.5 million, or 1.2% of revenues, for the three months ended March 29, 2024. The increase was primarily due to an increase in average cash balance and short-term investment during the three months ended March 28, 2025 compared to the same period in the prior fiscal year.

[0001408710-25-000023:mdna:104]
Our interest income increased by $10.3 million, or 46.6%, to $32.4 million, or 1.3% of revenues, for the nine months ended March 28, 2025, compared with $22.1 million, or 1.0% of revenues, for the nine months ended March 29, 2024. The

[0001408710-25-000023:mdna:105]
increase was primarily due to an increase in average cash balance and short-term investment during the nine months ended March 28, 2025 compared to same period in the prior fiscal year.

[0001408710-25-000023:mdna:106]
[same as prior period, unchanged from 0001408710-25-000008:mdna:103]

[0001408710-25-000023:mdna:107]
Our interest expense decreased for the three and nine months ended March 28, 2025, compared with the three and nine months ended March 29, 2024, due to the full repayment of our long-term loan balance.

[0001408710-25-000023:mdna:108]
[same as prior period, unchanged from 0001408710-25-000008:mdna:105]

[0001408710-25-000023:mdna:109]
We recorded foreign exchange loss, net of $2.7 million, or 0.3% of revenues, for the three months ended March 28, 2025, compared with foreign exchange gain, net of $3.3 million, or 0.5% of revenues, for the three months ended March 29, 2024. The foreign exchange loss was mainly due to (1) unrealized loss from revaluation of outstanding Thai baht assets and liabilities of $9.1 million, (2) unrealized loss from revaluation of currencies other than Thai baht of $2.3 million, and (3) increase in foreign exchange loss, totaling $0.8 million from our subsidiaries in the PRC and the U.K., offset by (1) unrealized gain from mark-to-market forward contracts of $5.3 million, and (2) realized gain from payment/receipt of $0.9 million.

[0001408710-25-000023:mdna:110]
We recorded foreign exchange loss, net of $5.7 million, or 0.2% of revenues, for the nine months ended March 28, 2025, compared with foreign exchange loss, net of $25.0 thousand, or 0.0% or revenues, for the nine months ended March 29, 2024. The increase in foreign exchange loss was mainly due to (1) unrealized loss from revaluation of outstanding Thai baht assets and liabilities of $6.3 million, (2) foreign exchange loss, totaling $0.8 million from our subsidiaries in the PRC and the U.K., and (3) unrealized loss from revaluation of currencies other than Thai baht of $0.7 million, offset by (1) unrealized gain from mark-to-market forward contracts of $1.4 million, and (2) decrease in realized loss from payment/receipt of $0.7 million.

[0001408710-25-000023:mdna:111]
[same as prior period, unchanged from 0001408710-25-000008:mdna:108]

[0001408710-25-000023:mdna:112]
We recorded income before income taxes of $86.3 million for the three months ended March 28, 2025, compared with $83.3 million for the three months ended March 29, 2024.

[0001408710-25-000023:mdna:113]
We recorded income before income taxes of $261.9 million for the nine months ended March 28, 2025, compared with $226.4 million for the nine months ended March 29, 2024.

[0001408710-25-000023:mdna:114]
[same as prior period, unchanged from 0001408710-25-000008:mdna:111]

[0001408710-25-000023:mdna:115]
Our provision for income tax reflects effective tax rates of 5.8% and 2.9% for the three months ended March 28, 2025 and March 29, 2024, respectively. The increase was due to higher income subject to tax and a discrete expense related to continuing assessment of potential tax exposures.

[0001408710-25-000023:mdna:116]
Our provision for income tax reflects effective tax rates of 6.3% and 5.0% for the nine months ended March 28, 2025 and March 29, 2024, respectively. The increase was due to higher income subject to tax and a discrete expense related to continuing assessment of potential tax exposures during the nine months ended March 28, 2025, offset by a full valuation allowance for deferred tax assets that was set up during the nine months ended March 29, 2024 for our subsidiary in Israel.

[0001408710-25-000023:mdna:117]
[same as prior period, unchanged from 0001408710-25-000008:mdna:114]

[0001408710-25-000023:mdna:118]
We recorded net income of $81.3 million, or 9.3% of revenues, for the three months ended March 28, 2025, compared with $80.9 million, or 11.1% of revenues, for the three months ended March 29, 2024.

[0001408710-25-000023:mdna:119]
We recorded net income of $245.3 million, or 9.8% of revenues, for the nine months ended March 28, 2025, compared with $215.1 million, or 10.1% of revenues, for the nine months ended March 29, 2024.

[0001408710-25-000023:mdna:120]
[same as prior period, unchanged from 0001408710-25-000008:mdna:117]

[0001408710-25-000023:mdna:121]
We recorded other comprehensive income of $6.2 million, or 0.7% of revenues, for the three months ended March 28, 2025, compared with other comprehensive loss of $8.9 million, or 1.2% of revenues, for the three months ended March 29, 2024. The change was mainly due to (1) unrealized gain from mark-to-market of forward contracts and interest rate swap agreements of $9.1 million, (2) unrealized gain from mark-to-market of available-for-sale debt securities of $5.1 million, and (3) an increase in unrealized gain from foreign currency translation adjustment of $1.0 million, offset by lower gain from a retirement benefits plan of $0.1 million.

[0001408710-25-000023:mdna:122]
We recorded other comprehensive income of $11.7 million, or 0.5% of revenues, for the nine months ended March 28, 2025, compared with other comprehensive income of $3.5 million, or 0.2% of revenues, for the nine months ended March 29, 2024. The increase in other comprehensive income was mainly due to (1) higher unrealized gain from mark-to-market of available-for-sale debt securities of $7.5 million, and (2) unrealized gain from foreign currency translation adjustment of $1.2

[0001408710-25-000023:mdna:123]
million, offset by (1) lower gain from a retirement benefits plan of $0.3 million, and (2) lower unrealized gain from mark-to-market of forward contracts and interest rate swap agreements of $0.2 million.

[0001408710-25-000023:mdna:124]
[same as prior period, unchanged from 0001408710-25-000008:mdna:120]

[0001408710-25-000023:mdna:125]
[same as prior period, unchanged from 0001408710-25-000008:mdna:121]

[0001408710-25-000023:mdna:126]
We primarily finance our operations through cash flow from operating activities. As of March 28, 2025, we had cash, cash equivalents, and short-term investments of $950.7 million and no outstanding debt. As of March 29, 2024, we had cash, cash equivalents, and short-term investments of $794.0 million and outstanding debt of $3.0 million.

[0001408710-25-000023:mdna:127]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents was 4.1% and 4.3% for the three and nine months ended March 28, 2025, respectively, and 4.5% and 4.3% for the three and nine months ended March 29, 2024, respectively.

[0001408710-25-000023:mdna:128]
[same as prior period, unchanged from 0001408710-25-000008:mdna:124]

[0001408710-25-000023:mdna:129]
As of March 29, 2024, we had long-term borrowing under our credit facility agreement of $3.0 million. As of March 28, 2025, we had no outstanding balance under our credit facility agreement. To better manage our cash on hand, we held short-term investments of $643.8 million as of March 28, 2025.

[0001408710-25-000023:mdna:130]
We believe that our current cash and cash equivalents, short-term investments, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q. We also believe that our current manufacturing capacity is sufficient to meet our anticipated production requirements for at least the next few quarters. In February 2025, we began construction of a new manufacturing facility of approximately 2.0 million square feet at our Chonburi campus. The total expected cost of the project is approximately $132.5 million (Thai baht 4.45 billion).

[0001408710-25-000023:mdna:131]
[same as prior period, unchanged from 0001408710-25-000008:mdna:127]

[0001408710-25-000023:mdna:132]
|  | Nine Months Ended |
| (in thousands) | March 28, 2025 |  | March 29, 2024 |
| Net cash provided by operating activities | $ | 273,272 |  |  | $ | 330,084 |  |
| Net cash used in investing activities | $ | (253,126) |  |  | $ | (118,615) |  |
| Net cash used in financing activities | $ | (124,393) |  |  | $ | (57,800) |  |
| Net increase in cash and cash equivalents | $ | (104,247) |  |  | $ | 153,669 |  |

[0001408710-25-000023:mdna:133]
[same as prior period, unchanged from 0001408710-25-000008:mdna:129]

[0001408710-25-000023:mdna:134]
Cash provided by operating activities is net income adjusted for certain non-cash items and changes in certain assets and liabilities. The decrease in cash provided by operating activities during the nine months ended March 28, 2025 as compared to the nine months ended March 29, 2024 was primarily due to (1) a change in inventories of $133.6 million due to new products and higher sales volume, and (2) a decrease in other payables of $17.2 million, offset by (1) a change in other current and non-current assets of $31.2 million, (2) an increase in trade payables of $30.9 million, and (3) an increase in net income of $30.2 million.

[0001408710-25-000023:mdna:135]
[same as prior period, unchanged from 0001408710-25-000008:mdna:131]

[0001408710-25-000023:mdna:136]
Investing cash flows consist primarily of investment purchases, sales, maturities, and disposals; and capital expenditures. The increase in cash used in investing activities for the nine months ended March 28, 2025 as compared to cash used in investing activities for the nine months ended March 29, 2024 was primarily due to an increase in investment purchases, and an increase in capital expenditures to support certain customers.

[0001408710-25-000023:mdna:137]
[same as prior period, unchanged from 0001408710-25-000008:mdna:133]

[0001408710-25-000023:mdna:138]
Financing cash flows consist primarily of repayment of long-term debt, share repurchases, and withholding tax related to net share settlement of restricted share units. The increase in cash used in financing activities for the nine months ended March 28, 2025 as compared to the nine months ended March 29, 2024 was due to an increase in share repurchases and higher withholding tax related to net share settlement of restricted share units, offset by lower repayment of long-term borrowings.

[0001408710-25-000023:mdna:139]
[same as prior period, unchanged from 0001408710-25-000008:mdna:135]

[0001408710-25-000023:mdna:140]
[same as prior period, unchanged from 0001408710-25-000008:mdna:136]

[0001408710-25-000023:mdna:141]
39
