# FN 8-K — 0001408710-25-000021 filed 2025-05-05

## item codes, every 8-K on or before 2025-05-06

- 2025-05-05 0001408710-25-000021 — 2.02, 9.01
- 2025-03-13 0001408710-25-000010 — 1.01, 3.02, 7.01, 9.01
- 2025-02-03 0001408710-25-000006 — 2.02, 9.01
- 2024-12-20 0001408710-24-000044 — 5.02
- 2024-12-13 0001408710-24-000042 — 5.07
- 2024-11-04 0001408710-24-000038 — 2.02, 9.01
- 2024-08-19 0001408710-24-000030 — 2.02, 5.02, 9.01
- 2024-06-14 0001408710-24-000023 — 5.02
- 2024-05-06 0001408710-24-000017 — 2.02, 9.01
- 2024-02-05 0001408710-24-000007 — 2.02, 9.01
- 2023-12-13 0001408710-23-000038 — 5.07
- 2023-11-06 0001408710-23-000034 — 2.02, 9.01
- 2023-08-21 0001408710-23-000026 — 2.02, 5.02, 9.01
- 2023-05-08 0001408710-23-000016 — 2.02, 5.02, 9.01
- 2023-02-06 0001408710-23-000006 — 2.02, 9.01
- 2022-12-13 0001408710-22-000062 — 5.07
- 2022-11-07 0001408710-22-000058 — 2.02, 9.01
- 2022-08-15 0001408710-22-000041 — 2.02, 5.02, 9.01
- 2022-05-02 0001408710-22-000026 — 2.02, 9.01
- 2022-01-31 0001408710-22-000016 — 2.02, 9.01
- 2022-01-19 0001408710-22-000010 — 5.02
- 2022-01-06 0001408710-22-000006 — 5.02
- 2021-12-10 0001408710-21-000051 — 5.07
- 2021-11-01 0001408710-21-000045 — 2.02, 9.01
- 2021-08-16 0001408710-21-000031 — 2.02, 5.02, 9.01
- 2021-05-03 0001408710-21-000019 — 2.02, 9.01
- 2021-02-01 0001408710-21-000008 — 2.02, 9.01
- 2020-12-11 0001193125-20-315861 — 5.07
- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2025-05-06

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001408710-25-000021:8k_2_02:1]
EX-99.1
2
fn-2025505xex991q325.htm
EX-99.1

[0001408710-25-000021:8k_2_02:2]
Document

[0001408710-25-000021:8k_2_02:3]
Exhibit 99.1

[0001408710-25-000021:8k_2_02:4]
Fabrinet Announces Third Quarter Fiscal Year 2025 Financial Results

[0001408710-25-000021:8k_2_02:5]
•Record Third Quarter Revenue Exceeds Guidance Range

[0001408710-25-000021:8k_2_02:6]
BANGKOK, Thailand – May 5, 2025 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its third fiscal quarter ended March 28, 2025.

[0001408710-25-000021:8k_2_02:7]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “We had a very strong third quarter with revenue of $872 million dollars, which was above our guidance range. We delivered another strong telecom performance with growth that more than offset an anticipated sequential decline in datacom revenue. Our team continued to execute very well, producing non-GAAP EPS that also exceeded our guidance. Looking ahead, we remain optimistic and confident in our ability to deliver strong execution in the fourth quarter and into fiscal 2026.”

[0001408710-25-000021:8k_2_02:8]
Third Quarter Fiscal Year 2025 Financial Highlights

[0001408710-25-000021:8k_2_02:9]
GAAP Results

[0001408710-25-000021:8k_2_02:10]
•Revenue for the third quarter of fiscal year 2025 was $871.8 million, compared to $731.5 million for the third quarter of fiscal year 2024.

[0001408710-25-000021:8k_2_02:11]
•GAAP net income for the third quarter of fiscal year 2025 was $81.3 million, compared to $80.9 million for the third quarter of fiscal year 2024.

[0001408710-25-000021:8k_2_02:12]
•GAAP net income per diluted share for the third quarter of fiscal year 2025 was $2.25, compared to $2.21 for the third quarter of fiscal year 2024.

[0001408710-25-000021:8k_2_02:13]
Non-GAAP Results

[0001408710-25-000021:8k_2_02:14]
•Non-GAAP net income for the third quarter of fiscal year 2025 was $91.2 million, compared to $87.7 million for the third quarter of fiscal year 2024.

[0001408710-25-000021:8k_2_02:15]
•Non-GAAP net income per diluted share for the third quarter of fiscal year 2025 was $2.52, compared to $2.39 for the third quarter of fiscal year 2024.

[0001408710-25-000021:8k_2_02:16]
Business Outlook

[0001408710-25-000021:8k_2_02:17]
Based on information available as of May 5, 2025, Fabrinet is issuing guidance for its fourth fiscal quarter ending June 27, 2025, as follows:

[0001408710-25-000021:8k_2_02:18]
•Fabrinet expects fourth quarter revenue to be in the range of $860 million to $900 million.

[0001408710-25-000021:8k_2_02:19]
•GAAP net income per diluted share is expected to be in the range of $2.32 to $2.47, based on approximately 36.3 million fully diluted shares outstanding.

[0001408710-25-000021:8k_2_02:20]
•Non-GAAP net income per diluted share is expected to be in the range of $2.55 to $2.70, based on approximately 36.3 million fully diluted shares outstanding.

[0001408710-25-000021:8k_2_02:21]
Guidance for non-GAAP net income per diluted share excludes share-based compensation expenses and certain non-recurring items. A reconciliation of non-GAAP net income per diluted share to the corresponding GAAP measure is available at the end of this press release.

[0001408710-25-000021:8k_2_02:22]
Conference Call Information

[0001408710-25-000021:8k_2_02:23]
| What: |  | Fabrinet Third Quarter Fiscal Year 2025 Financial Results Call |
| When: |  | May 5, 2025 |
| Time: |  | 5:00 p.m. ET |
| Live Call and Replay: |  | https://investor.fabrinet.com/events-and-presentations/events |

[0001408710-25-000021:8k_2_02:24]
A recorded version of this webcast will be available approximately two hours after the call and accessible at http://investor.fabrinet.com. The webcast will be archived on Fabrinet’s website for a period of one year.

[0001408710-25-000021:8k_2_02:25]
About Fabrinet

[0001408710-25-000021:8k_2_02:26]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China, and Israel. For more information visit: www.fabrinet.com.

[0001408710-25-000021:8k_2_02:27]
Forward-Looking Statements

[0001408710-25-000021:8k_2_02:28]
Non-GAAP Financial Measures

[0001408710-25-000021:8k_2_02:29]
In addition to reporting financial results in accordance with GAAP, we provide investors with certain non-GAAP financial measures. These non-GAAP financial measures are in addition to, and not a substitute for or superior to, measures of financial performance prepared in accordance with GAAP. We believe these non-GAAP financial measures provide investors with useful supplemental information to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, we use some of these non-GAAP financial measures to measure company performance for the purposes of determining employee incentive plan compensation.

[0001408710-25-000021:8k_2_02:30]
Non-GAAP gross profit, non-GAAP operating profit, non-GAAP net income and non-GAAP net income per diluted share exclude: share-based compensation expenses; severance payment and others; restructuring and other related costs; legal and litigation; and amortization of deferred debt issuance costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations.

[0001408710-25-000021:8k_2_02:31]
Non-GAAP free cash flow is net cash provided by (used in) operating activities, minus capital expenditures (purchase of property, plant and equipment). We use free cash flow to measure our ability to generate additional cash from our business operations.

[0001408710-25-000021:8k_2_02:32]
There are a number of limitations related to the use of these non-GAAP financial measures versus their nearest GAAP equivalents. For example, other companies may calculate non-GAAP financial measures differently or may use other measures to evaluate their performance, all of which could reduce the usefulness of our non-GAAP financial measures as tools for comparison. We urge you to review the reconciliations of our non-GAAP financial measures to the most directly comparable GAAP financial measures, and not to rely on any single financial measure to evaluate our business.

[0001408710-25-000021:8k_2_02:33]
Investor Contact:

[0001408710-25-000021:8k_2_02:34]
Garo Toomajanian

[0001408710-25-000021:8k_2_02:35]
ir@fabrinet.com

[0001408710-25-000021:8k_2_02:36]
FABRINET

[0001408710-25-000021:8k_2_02:37]
CONSOLIDATED BALANCE SHEETS

[0001408710-25-000021:8k_2_02:38]
| (in thousands of U.S. dollars, except share data and par value) | March 28,2025 |  | June 28,2024 |
|  | (unaudited) |  |  |
| Assets |  |  |  |
| Current assets |  |  |  |
| Cash and cash equivalents | $ | 306,905 |  |  | $ | 409,973 |  |
| Short-term investments | 643,772 |  |  | 448,630 |  |
| Trade accounts receivable, net of allowance for expected credit losses of $1,255 and $1,629, respectively | 658,301 |  |  | 592,452 |  |
| Inventories | 531,338 |  |  | 463,206 |  |
| Prepaid expenses | 19,396 |  |  | 10,620 |  |
| Other current assets | 84,731 |  |  | 87,810 |  |
| Total current assets | 2,244,443 |  |  | 2,012,691 |  |
| Non-current assets |  |  |  |
| Property, plant and equipment, net | 354,489 |  |  | 307,240 |  |
| Intangibles, net | 2,173 |  |  | 2,321 |  |
| Operating right-of-use assets | 6,021 |  |  | 5,336 |  |
| Deferred tax assets | 11,589 |  |  | 10,446 |  |
| Other non-current assets | 586 |  |  | 485 |  |
| Total non-current assets | 374,858 |  |  | 325,828 |  |
| Total Assets | $ | 2,619,301 |  |  | $ | 2,338,519 |  |
| Liabilities and Shareholders’ Equity |  |  |  |
| Current liabilities |  |  |  |
| Trade accounts payable | 521,226 |  |  | 441,835 |  |
| Fixed assets payable | 33,101 |  |  | 14,380 |  |
| Operating lease liabilities, current portion | 1,709 |  |  | 1,355 |  |
| Income tax payable | 8,090 |  |  | 3,937 |  |
| Accrued payroll, bonus and related expenses | 24,170 |  |  | 22,116 |  |
| Accrued expenses | 32,420 |  |  | 19,916 |  |
| Other payables | 54,331 |  |  | 54,403 |  |
| Total current liabilities | 675,047 |  |  | 557,942 |  |
| Non-current liabilities |  |  |  |
| Deferred tax liability | 1,371 |  |  | 4,895 |  |
| Operating lease liability, non-current portion | 4,012 |  |  | 3,635 |  |
| Severance liabilities | 28,337 |  |  | 24,093 |  |
| Other non-current liabilities | 3,340 |  |  | 2,209 |  |
| Total non-current liabilities | 37,060 |  |  | 34,832 |  |
| Total Liabilities | 712,107 |  |  | 592,774 |  |
| Shareholders’ equity |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of March 28, 2025 and June 28, 2024) | — |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 39,596,609 shares and 39,457,462 shares issued as of March 28, 2025 and June 28, 2024, respectively; and 35,830,476 shares and 36,145,242 shares outstanding as of March 28, 2025 and June 28, 2024, respectively) | 396 |  |  | 395 |  |
| Additional paid-in capital | 229,957 |  |  | 222,044 |  |
| Less: Treasury shares (3,766,133 shares and 3,312,220 shares as of March 28, 2025 and June 28, 2024, respectively) | (337,798) |  |  | (234,323) |  |
| Accumulated other comprehensive income (loss) | 8,549 |  |  | (3,141) |  |
| Retained earnings | 2,006,090 |  |  | 1,760,770 |  |
| Total Shareholders’ Equity | 1,907,194 |  |  | 1,745,745 |  |
| Total Liabilities and Shareholders’ Equity | $ | 2,619,301 |  |  | $ | 2,338,519 |  |

[0001408710-25-000021:8k_2_02:39]
FABRINET

[0001408710-25-000021:8k_2_02:40]
CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME (UNAUDITED)

[0001408710-25-000021:8k_2_02:41]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands of U.S. dollars, except per share data) | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
| Revenues | $ | 871,799 |  |  | $ | 731,535 |  |  | $ | 2,509,635 |  |  | $ | 2,129,706 |  |
| Cost of revenues | (769,616) |  |  | (640,600) |  |  | (2,207,577) |  |  | (1,866,037) |  |
| Gross profit | 102,183 |  |  | 90,935 |  |  | 302,058 |  |  | 263,669 |  |
| Selling, general and administrative expenses | (22,063) |  |  | (19,628) |  |  | (65,300) |  |  | (59,373) |  |
| Restructuring and other related costs | (1,264) |  |  | — |  |  | (1,367) |  |  | — |  |
| Operating income | 78,856 |  |  | 71,307 |  |  | 235,391 |  |  | 204,296 |  |
| Interest income | 10,145 |  |  | 8,509 |  |  | 32,392 |  |  | 22,155 |  |
| Interest expense | — |  |  | (26) |  |  | — |  |  | (107) |  |
| Foreign exchange gain (loss), net | (2,675) |  |  | 3,348 |  |  | (5,728) |  |  | (25) |  |
| Other income (expense), net | (30) |  |  | 175 |  |  | (111) |  |  | 60 |  |
| Income before income taxes | 86,296 |  |  | 83,313 |  |  | 261,944 |  |  | 226,379 |  |
| Income tax expense | (5,006) |  |  | (2,397) |  |  | (16,624) |  |  | (11,264) |  |
| Net income | 81,290 |  |  | 80,916 |  |  | 245,320 |  |  | 215,115 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities | 3,350 |  |  | (1,739) |  |  | 9,647 |  |  | 2,155 |  |
| Change in net unrealized gain (loss) on derivative instruments | 1,790 |  |  | (7,328) |  |  | 907 |  |  | 1,062 |  |
| Change in net retirement benefits plan – prior service cost | — |  |  | 137 |  |  | — |  |  | 271 |  |
| Change in foreign currency translation adjustment | 1,060 |  |  | 75 |  |  | 1,136 |  |  | (31) |  |
| Total other comprehensive income (loss), net of tax | 6,200 |  |  | (8,855) |  |  | 11,690 |  |  | 3,457 |  |
| Net comprehensive income | $ | 87,490 |  |  | $ | 72,061 |  |  | $ | 257,010 |  |  | $ | 218,572 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 2.26 |  |  | $ | 2.23 |  |  | $ | 6.80 |  |  | $ | 5.93 |  |
| Diluted | $ | 2.25 |  |  | $ | 2.21 |  |  | $ | 6.75 |  |  | $ | 5.88 |  |
| Weighted-average number of ordinary shares outstanding (in thousands of shares) |  |  |  |  |  |  |  |
| Basic | 35,914 |  |  | 36,250 |  |  | 36,094 |  |  | 36,278 |  |
| Diluted | 36,172 |  |  | 36,603 |  |  | 36,327 |  |  | 36,574 |  |

[0001408710-25-000021:8k_2_02:42]
FABRINET

[0001408710-25-000021:8k_2_02:43]
CONSOLIDATED STATEMENTS OF CASH FLOWS (UNAUDITED)

[0001408710-25-000021:8k_2_02:44]
|  | Nine Months Ended |
| (in thousands of U.S. dollars) | March 28,2025 |  | March 29,2024 |
| Cash flows from operating activities |  |  |  |
| Net income for the period | $ | 245,320 |  |  | $ | 215,115 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 39,223 |  |  | 36,602 |  |
| (Gain) loss on disposal of property, plant and equipment and intangibles | (39) |  |  | (147) |  |
| Amortization of discount (premium) of short-term investments | (3,435) |  |  | (2,317) |  |
| (Reversal of) allowance for expected credit losses | (374) |  |  | 1,874 |  |
| Unrealized loss (gain) on exchange rate and fair value of foreign currency forward contracts | 4,067 |  |  | (2,135) |  |
| Amortization of fair value at hedge inception of interest rate swaps | — |  |  | (198) |  |
| Share-based compensation | 24,903 |  |  | 21,440 |  |
| Customer warrant | 3,929 |  |  | — |  |
| Deferred income tax expense (benefit) | (4,182) |  |  | 1,125 |  |
| Other non-cash expenses | 82 |  |  | 193 |  |
| Changes in operating assets and liabilities |  |  |  |
| Trade accounts receivable | (65,271) |  |  | (54,089) |  |
| Inventories | (68,132) |  |  | 65,442 |  |
| Other current assets and non-current assets | (2,357) |  |  | (33,548) |  |
| Trade accounts payable | 79,196 |  |  | 48,268 |  |
| Income tax payable | 4,180 |  |  | (1,068) |  |
| Accrued expenses | 12,643 |  |  | 1,493 |  |
| Other payables | (152) |  |  | 29,309 |  |
| Severance liabilities | 2,131 |  |  | 2,249 |  |
| Other current liabilities and non-current liabilities | 1,540 |  |  | 476 |  |
| Net cash provided by operating activities | 273,272 |  |  | 330,084 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of short-term investments | (304,189) |  |  | (268,461) |  |
| Proceeds from sales of short-term investments | — |  |  | 10,000 |  |
| Proceeds from maturities of short-term investments | 122,129 |  |  | 173,120 |  |
| Purchase of property, plant and equipment | (70,668) |  |  | (34,825) |  |
| Purchase of intangibles | (514) |  |  | (768) |  |
| Proceeds from disposal of property, plant and equipment | 116 |  |  | 2,319 |  |
| Net cash used in investing activities | (253,126) |  |  | (118,615) |  |
| Cash flows from financing activities |  |  |  |
| Repayment of long-term borrowings | — |  |  | (9,141) |  |
| Repurchase of ordinary shares | (103,475) |  |  | (35,943) |  |
| Withholding tax related to net share settlement of restricted share units | (20,918) |  |  | (12,716) |  |
| Net cash used in financing activities | (124,393) |  |  | (57,800) |  |
| Net increase (decrease) in cash and cash equivalents | $ | (104,247) |  |  | $ | 153,669 |  |
| Movement in cash and cash equivalents |  |  |  |
| Cash and cash equivalents at the beginning of period | $ | 409,973 |  |  | $ | 231,368 |  |
| Increase (decrease) in cash and cash equivalents | (104,247) |  |  | 153,669 |  |
| Effect of exchange rate on cash and cash equivalents | 1,179 |  |  | 74 |  |
| Cash and cash equivalents at the end of period | $ | 306,905 |  |  | $ | 385,111 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment-related payables | $ | 33,101 |  |  | $ | 9,229 |  |

[0001408710-25-000021:8k_2_02:45]
FABRINET

[0001408710-25-000021:8k_2_02:46]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES (UNAUDITED)

[0001408710-25-000021:8k_2_02:47]
Reconciliation of GAAP Gross Profit and GAAP Gross Margin to Non-GAAP Gross Profit and Non-GAAP Gross Margin

[0001408710-25-000021:8k_2_02:48]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands of U.S. dollars) | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
| Revenues | $ | 871,799 |  |  |  |  | $ | 731,535 |  |  |  |  | $ | 2,509,635 |  |  |  |  | $ | 2,129,706 |  |  |  |
| Gross profit (GAAP) | $ | 102,183 |  |  | 11.7 | % |  | $ | 90,935 |  |  | 12.4 | % |  | $ | 302,058 |  |  | 12.0 | % |  | $ | 263,669 |  |  | 12.4 | % |
| Share-based compensation expenses | 2,221 |  |  |  |  | 1,561 |  |  |  |  | 7,883 |  |  |  |  | 5,427 |  |  |  |
| Gross profit (Non-GAAP) | $ | 104,404 |  |  | 12.0 | % |  | $ | 92,496 |  |  | 12.6 | % |  | $ | 309,941 |  |  | 12.4 | % |  | $ | 269,096 |  |  | 12.6 | % |

[0001408710-25-000021:8k_2_02:49]
Reconciliation of GAAP Operating Profit and GAAP Operating Margin to Non-GAAP Operating Profit and Non-GAAP Operating Margin

[0001408710-25-000021:8k_2_02:50]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands of U.S. dollars) | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
| Revenues | $ | 871,799 |  |  |  |  | $ | 731,535 |  |  |  |  | $ | 2,509,635 |  |  |  |  | $ | 2,129,706 |  |  |  |
| Operating profit (GAAP) | $ | 78,856 |  |  | 9.0 | % |  | $ | 71,307 |  |  | 9.7 | % |  | $ | 235,391 |  |  | 9.4 | % |  | $ | 204,296 |  |  | 9.6 | % |
| Share-based compensation expenses | 7,783 |  |  |  |  | 6,726 |  |  |  |  | 24,903 |  |  |  |  | 21,440 |  |  |  |
| Restructuring and other related costs | 1,264 |  |  |  |  | — |  |  |  |  | 1,367 |  |  |  |  | — |  |  |  |
| Legal and litigation | 827 |  |  |  |  | — |  |  |  |  | 827 |  |  |  |  | — |  |  |  |
| Severance payment and others | — |  |  |  |  | — |  |  |  |  | 748 |  |  |  |  | — |  |  |  |
| Operating profit (Non-GAAP) | $ | 88,730 |  |  | 10.2 | % |  | $ | 78,033 |  |  | 10.7 | % |  | $ | 263,236 |  |  | 10.5 | % |  | $ | 225,736 |  |  | 10.6 | % |

[0001408710-25-000021:8k_2_02:51]
FABRINET

[0001408710-25-000021:8k_2_02:52]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES (UNAUDITED)

[0001408710-25-000021:8k_2_02:53]
Reconciliation of GAAP Net Income and EPS to Non-GAAP Net Income and EPS

[0001408710-25-000021:8k_2_02:54]
|  | Three Months Ended |  | Nine Months Ended |
|  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
| (in thousands of U.S. dollars, except per share data) | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |
| GAAP measures | $ | 81,290 |  |  | $ | 2.25 |  |  | $ | 80,916 |  |  | $ | 2.21 |  |  | $ | 245,320 |  |  | $ | 6.75 |  |  | $ | 215,115 |  |  | $ | 5.88 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 2,221 |  |  | 0.06 |  |  | 1,561 |  |  | 0.04 |  |  | 7,883 |  |  | 0.22 |  |  | 5,427 |  |  | 0.15 |  |
| Total related to cost of revenues | 2,221 |  |  | 0.06 |  |  | 1,561 |  |  | 0.04 |  |  | 7,883 |  |  | 0.22 |  |  | 5,427 |  |  | 0.15 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 5,562 |  |  | 0.16 |  |  | 5,165 |  |  | 0.14 |  |  | 17,020 |  |  | 0.47 |  |  | 16,013 |  |  | 0.44 |  |
| Legal and litigation | 827 |  |  | 0.02 |  |  | — |  |  | — |  |  | 827 |  |  | 0.02 |  |  | — |  |  | — |  |
| Severance payment and others | — |  |  | — |  |  | — |  |  | — |  |  | 748 |  |  | 0.02 |  |  | — |  |  | — |  |
| Total related to selling, general and administrative expenses | 6,389 |  |  | 0.18 |  |  | 5,165 |  |  | 0.14 |  |  | 18,595 |  |  | 0.51 |  |  | 16,013 |  |  | 0.44 |  |
| Related to other income and expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other related costs | 1,264 |  |  | 0.03 |  |  | — |  |  | — |  |  | 1,367 |  |  | 0.04 |  |  | — |  |  | — |  |
| Amortization of deferred debt issuance costs | — |  |  | — |  |  | 8 |  |  | 0.00 |  |  | — |  |  | — |  |  | 24 |  |  | 0.00 |  |
| Total related to other income and expense | 1,264 |  |  | 0.03 |  |  | 8 |  |  | 0.00 |  |  | 1,367 |  |  | 0.04 |  |  | 24 |  |  | 0.00 |  |
| Total related to net income & EPS | 9,874 |  |  | 0.27 |  |  | 6,734 |  |  | 0.18 |  |  | 27,845 |  |  | 0.77 |  |  | 21,464 |  |  | 0.59 |  |
| Non-GAAP measures | $ | 91,164 |  |  | $ | 2.52 |  |  | $ | 87,650 |  |  | $ | 2.39 |  |  | $ | 273,165 |  |  | $ | 7.52 |  |  | $ | 236,579 |  |  | $ | 6.47 |  |
| Shares used in computing diluted net income per share (in thousands of shares) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  | 36,172 |  |  |  |  | 36,603 |  |  |  |  | 36,327 |  |  |  |  | 36,574 |  |
| Non-GAAP diluted shares |  |  | 36,172 |  |  |  |  | 36,603 |  |  |  |  | 36,327 |  |  |  |  | 36,574 |  |

[0001408710-25-000021:8k_2_02:55]
FABRINET

[0001408710-25-000021:8k_2_02:56]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW (UNAUDITED)

[0001408710-25-000021:8k_2_02:57]
| (in thousands of U.S. dollars) |  | Three Months Ended |  | Nine Months Ended |
|  |  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
| Net cash provided by operating activities |  | $ | 74,186 |  |  | $ | 100,870 |  |  | $ | 273,272 |  |  | $ | 330,084 |  |
| Less: Purchase of property, plant and equipment |  | (28,518) |  |  | (13,589) |  |  | (70,668) |  |  | (34,825) |  |
| Non-GAAP free cash flow |  | $ | 45,668 |  |  | $ | 87,281 |  |  | $ | 202,604 |  |  | $ | 295,259 |  |

[0001408710-25-000021:8k_2_02:58]
FABRINET

[0001408710-25-000021:8k_2_02:59]
GUIDANCE FOR QUARTER ENDING JUNE 27, 2025

[0001408710-25-000021:8k_2_02:60]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-25-000021:8k_2_02:61]
|  | DilutedEPS |
| GAAP net income per diluted share | $2.32 to $2.47 |
| Related to cost of revenues: |  |
| Share-based compensation expenses | 0.08 |
| Total related to cost of revenues | 0.08 |
| Related to selling, general and administrative expenses: |  |
| Share-based compensation expenses | 0.15 |
| Total related to selling, general and administrative expenses | 0.15 |
| Total related to net income & EPS | 0.23 |
| Non-GAAP net income per diluted share | $2.55 to $2.70 |
