# FN notes — 0001408710-25-000023


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001408710-25-000023:notes:1]
[same as prior period, unchanged from 0001408710-25-000008:notes:1]

[0001408710-25-000023:notes:2]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of March 28, 2025 and for the three and nine months ended March 28, 2025 and March 29, 2024 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 28, 2024.

[0001408710-25-000023:notes:3]
[same as prior period, unchanged from 0001408710-25-000008:notes:3]

[0001408710-25-000023:notes:4]
The results for the three and nine months ended March 28, 2025 may not be indicative of results for the year ending June 27, 2025 or any future periods.

[0001408710-25-000023:notes:5]
[same as prior period, unchanged from 0001408710-25-000008:notes:5]

[0001408710-25-000023:notes:6]
The preparation of the Company’s unaudited condensed consolidated financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent liabilities at the date of the financial statements and the reported amount of total revenues and expenses during the year. The Company bases estimates on historical experience and various assumptions about the future that are believed to be reasonable based on available information. The Company’s reported financial position or results of operations may be materially different under different conditions or when using different estimates and assumptions, particularly with respect to significant accounting policies, which are discussed below. Significant assumptions are used in accounting for share-based compensation, the fair value of warrant shares at grant date, allowance for expected credit losses, income taxes, and inventory obsolescence. Due to the inherent uncertainty involved in making estimates, actual results reported in future periods may be different from these estimates. In the event that the Company's estimates or assumptions prove to be different from actual results, adjustments will be made in subsequent periods to reflect more current information.

[0001408710-25-000023:notes:7]
[same as prior period, unchanged from 0001408710-25-000008:notes:7]

[0001408710-25-000023:notes:8]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended March 28, 2025 and March 29, 2024 consisted of 13 weeks. The nine months ended March 28, 2025 and March 29, 2024 consisted of 39 weeks. Fiscal year 2025 will comprise 52 weeks and will end on June 27, 2025.

[0001408710-25-000023:notes:9]
[same as prior period, unchanged from 0001408710-25-000008:notes:9]

[0001408710-25-000023:notes:10]
In November 2023, the Financial Accounting Standards Board ("FASB") issued ASU 2023-07, “Segment Reporting (Topic 280), Improvements to Reportable Segment Disclosures,” which is intended to improve reportable segment disclosure requirements, primarily through additional disclosures about significant segment expenses. This ASU is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. This ASU is effective for the Company's annual periods beginning June 29, 2024, and interim periods beginning June 28, 2025, and will be applied retrospectively to all prior periods presented in the financial statements. The Company is currently evaluating the ASU to determine its impact on the Company's disclosures.

[0001408710-25-000023:notes:11]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740), Improvements to Income Tax Disclosures,” which requires more detailed income tax disclosures. This ASU requires entities to disclose disaggregated information about their effective tax rate reconciliation as well as expanded information on income taxes paid by jurisdiction. This ASU is effective for all entities for fiscal years beginning after December 15, 2024, with early adoption permitted for annual financial statements that have not yet been issued or made available for issuance. This ASU will be effective for the Company beginning in fiscal year 2026. The Company is currently assessing the impact to its disclosures.

[0001408710-25-000023:notes:12]
In November 2024, the FASB issued ASU 2024-03, “Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), Disaggregation of Income Statement Expenses,” which requires additional notes to financial statements. This ASU requires entities to include certain current disclosures in the same tabular format disclosure as the other disaggregation requirements in the amendments in this ASU. This ASU is effective for all entities for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027, with early adoption permitted. This ASU is effective for the Company's annual periods beginning June 26, 2027, and interim periods beginning July 1, 2028, and will be applied retrospectively to all prior periods presented in the financial statements. The Company is currently evaluating the ASU to determine its impact on the Company's disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001408710-25-000023:notes:13]
[same as prior period, unchanged from 0001408710-25-000008:notes:13]

[0001408710-25-000023:notes:14]
[same as prior period, unchanged from 0001408710-25-000008:notes:14]

[0001408710-25-000023:notes:15]
[same as prior period, unchanged from 0001408710-25-000008:notes:15]

[0001408710-25-000023:notes:16]
| (in thousands, except percentages) | Three Months EndedMarch 28, 2025 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 28, 2025 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 401,769 |  |  |  |  | $ | 1,080,701 |  |  |  |
| Others (1) | 1,357 |  |  |  |  | 4,306 |  |  |  |
| Total revenue in North America | 403,126 |  |  | 46.2 | % |  | 1,085,007 |  |  | 43.2 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 226,406 |  |  |  |  | 758,030 |  |  |  |
| India | 86,027 |  |  |  |  | 238,486 |  |  |  |
| Hong Kong | 26,773 |  |  |  |  | 65,735 |  |  |  |
| Thailand | 15,995 |  |  |  |  | 41,185 |  |  |  |
| China | 14,694 |  |  |  |  | 40,216 |  |  |  |
| Singapore | 10,704 |  |  |  |  | 33,948 |  |  |  |
| Japan | 10,425 |  |  |  |  | 27,980 |  |  |  |
| Malaysia | 8,224 |  |  |  |  | 23,287 |  |  |  |
| Others | 589 |  |  |  |  | 1,790 |  |  |  |
| Total revenue in Asia-Pacific and others | 399,837 |  |  | 45.9 | % |  | 1,230,657 |  |  | 49.0 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 36,905 |  |  |  |  | 108,617 |  |  |  |
| Germany | 11,822 |  |  |  |  | 32,033 |  |  |  |
| Others | 20,109 |  |  |  |  | 53,321 |  |  |  |
| Total revenue in Europe | $ | 68,836 |  |  | 7.9 | % |  | $ | 193,971 |  |  | 7.8 | % |
| Total revenue | $ | 871,799 |  |  | 100.0 | % |  | $ | 2,509,635 |  |  | 100.0 | % |

[0001408710-25-000023:notes:17]
| (in thousands, except percentages) | Three Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 268,475 |  |  |  |  | $ | 761,622 |  |  |  |
| Others (1) | 3,401 |  |  |  |  | 10,192 |  |  |  |
| Total revenue in North America | 271,876 |  |  | 37.2 | % |  | 771,814 |  |  | 36.3 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 275,022 |  |  |  |  | 752,736 |  |  |  |
| India | 63,055 |  |  |  |  | 208,865 |  |  |  |
| Malaysia | 30,993 |  |  |  |  | 100,938 |  |  |  |
| Hong Kong | 15,147 |  |  |  |  | 43,085 |  |  |  |
| Thailand | 13,059 |  |  |  |  | 36,489 |  |  |  |
| China | 12,309 |  |  |  |  | 53,831 |  |  |  |
| Japan | 5,772 |  |  |  |  | 18,408 |  |  |  |
| Others | 1,655 |  |  |  |  | 4,390 |  |  |  |
| Total revenue in Asia-Pacific and others | 417,012 |  |  | 57.0 | % |  | 1,218,742 |  |  | 57.2 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 18,164 |  |  |  |  | 66,808 |  |  |  |
| Germany | 10,148 |  |  |  |  | 33,323 |  |  |  |
| Others | 14,335 |  |  |  |  | 39,019 |  |  |  |
| Total revenue in Europe | $ | 42,647 |  |  | 5.8 | % |  | $ | 139,150 |  |  | 6.5 | % |
| Total revenue | $ | 731,535 |  |  | 100.0 | % |  | $ | 2,129,706 |  |  | 100.0 | % |

[0001408710-25-000023:notes:18]
[same as prior period, unchanged from 0001408710-25-000008:notes:18]

[0001408710-25-000023:notes:19]
[same as prior period, unchanged from 0001408710-25-000008:notes:19]

[0001408710-25-000023:notes:20]
| (in thousands, except percentages) | Three Months EndedMarch 28, 2025 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 28, 2025 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 251,105 |  |  |  |  | $ | 879,087 |  |  |  |
| Telecom | 406,126 |  |  |  |  | 1,051,609 |  |  |  |
| Total revenue - Optical communications | $ | 657,231 |  |  | 75.4 | % |  | $ | 1,930,696 |  |  | 76.9 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 129,468 |  |  |  |  | $ | 336,456 |  |  |  |
| Industrial laser | 40,464 |  |  |  |  | 113,332 |  |  |  |
| Others | 44,636 |  |  |  |  | 129,151 |  |  |  |
| Total revenue - Non-optical communications | $ | 214,568 |  |  | 24.6 | % |  | $ | 578,939 |  |  | 23.1 | % |
| Total revenue | $ | 871,799 |  |  | 100.0 | % |  | $ | 2,509,635 |  |  | 100.0 | % |

[0001408710-25-000023:notes:21]
| (in thousands, except percentages) | Three Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |  | Nine Months EndedMarch 29, 2024 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 305,478 |  |  |  |  | $ | 835,642 |  |  |  |
| Telecom | 285,970 |  |  |  |  | 856,997 |  |  |  |
| Total revenue - Optical communications | $ | 591,448 |  |  | 80.9 | % |  | $ | 1,692,639 |  |  | 79.5 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 73,636 |  |  |  |  | $ | 241,166 |  |  |  |
| Industrial laser | 30,319 |  |  |  |  | 90,582 |  |  |  |
| Others | 36,132 |  |  |  |  | 105,319 |  |  |  |
| Total revenue - Non-optical communications | $ | 140,087 |  |  | 19.1 | % |  | $ | 437,067 |  |  | 20.5 | % |
| Total revenue | $ | 731,535 |  |  | 100.0 | % |  | $ | 2,129,706 |  |  | 100.0 | % |

[0001408710-25-000023:notes:22]
[same as prior period, unchanged from 0001408710-25-000008:notes:22]

[0001408710-25-000023:notes:23]
[same as prior period, unchanged from 0001408710-25-000008:notes:23]

[0001408710-25-000023:notes:24]
As of March 28, 2025 and June 28, 2024, the Company's contract assets were de minimis.

[0001408710-25-000023:notes:25]
[same as prior period, unchanged from 0001408710-25-000008:notes:25]

[0001408710-25-000023:notes:26]
The following tables summarize the activity in the Company’s contract liabilities during the nine months ended March 28, 2025:

[0001408710-25-000023:notes:27]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 28, 2024 | $ | 7,846 |  |
| Advance payments received during the period | 11,534 |  |
| Revenue recognized | (10,455) |  |
| Ending balance, March 28, 2025 | $ | 8,925 |  |

[0001408710-25-000023:notes:28]
Customer Warrant

[0001408710-25-000023:notes:29]
Warrants issued to customers are accounted for as equity instruments and measured in accordance with ASC 718, Compensation – Stock Compensation. For awards granted to a customer which are not in exchange for distinct goods or services, the fair value of the awards earned based on service or performance conditions is recorded as a reduction of the transaction price, in accordance with ASC 606, Revenue from Contracts with Customers.

[0001408710-25-000023:notes:30]
To determine the fair value of warrants in accordance with ASC 718, the Company uses the Black-Scholes option pricing model, based in part on assumptions for which management is required to use judgment. Based on the fair value of the awards, the Company determines the amount of warrant expense based on the customer’s achievement of vesting conditions, which is recorded as a reduction of revenues on the unaudited condensed consolidated statement of operations. The dilutive impact of customer warrants is determined using the treasury stock method.

[0001408710-25-000023:notes:31]
For the three and nine months ended March 28, 2025, the Company recognized $3.9 million as a reduction to revenue on the unaudited condensed consolidated statements of operations.


## us-gaap:EarningsPerShareTextBlock

[0001408710-25-000023:notes:32]
Earnings per ordinary share
Basic earnings per ordinary share is computed by dividing reported net income by the weighted-average number of ordinary shares outstanding during each period. Diluted earnings per ordinary share is computed by calculating the effect of potential dilutive ordinary shares outstanding during the period using the treasury stock method. Dilutive ordinary equivalent shares consist of restricted share units, performance share units and warrant shares.

[0001408710-25-000023:notes:33]
[same as prior period, unchanged from 0001408710-25-000008:notes:29]

[0001408710-25-000023:notes:34]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands, except per share data) | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
| Net income attributable to shareholders | $ | 81,290 |  |  | $ | 80,916 |  |  | $ | 245,320 |  |  | $ | 215,115 |  |
| Weighted-average number of ordinary shares outstanding | 35,914 |  |  | 36,250 |  |  | 36,094 |  |  | 36,278 |  |
| Incremental shares arising from the assumed vesting of restricted share units and performance share units | 243 |  |  | 353 |  |  | 228 |  |  | 296 |  |
| Incremental shares arising from the assumed vesting of customer warrant | 15 |  |  | — |  |  | 5 |  |  | — |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share | 36,172 |  |  | 36,603 |  |  | 36,327 |  |  | 36,574 |  |
| Basic earnings per ordinary share | $ | 2.26 |  |  | $ | 2.23 |  |  | $ | 6.80 |  |  | $ | 5.93 |  |
| Diluted earnings per ordinary share | $ | 2.25 |  |  | $ | 2.21 |  |  | $ | 6.75 |  |  | $ | 5.88 |  |


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001408710-25-000023:notes:35]
[same as prior period, unchanged from 0001408710-25-000008:notes:31]

[0001408710-25-000023:notes:36]
|  |  |  | Fair Value |
| (in thousands) | CarryingCost |  | UnrealizedGain/(Loss) |  | Cash andCashEquivalents |  | Short-term Investments |  | OtherInvestments |
| As of March 28, 2025 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 306,857 |  |  | $ | — |  |  | $ | 306,857 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 48 |  |  | — |  |  | 48 |  |  | — |  |  | — |  |
| Certificates of deposit and time deposits | 246,426 |  |  | 2,579 |  |  | — |  |  | 249,005 |  |  | — |  |
| Corporate debt securities | 131,504 |  |  | 5,083 |  |  | — |  |  | 136,587 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 257,372 |  |  | 808 |  |  | — |  |  | 258,180 |  |  | — |  |
| Total | $ | 942,207 |  |  | $ | 8,470 |  |  | $ | 306,905 |  |  | $ | 643,772 |  |  | $ | — |  |
| As of June 28, 2024 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 409,938 |  |  | $ | — |  |  | $ | 409,938 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 35 |  |  | — |  |  | 35 |  |  | — |  |  | — |  |
| Certificates of deposit and time deposits | 134,288 |  |  | (5) |  |  | — |  |  | 134,283 |  |  | — |  |
| Corporate debt securities | 137,695 |  |  | (932) |  |  | — |  |  | 136,763 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 177,824 |  |  | (240) |  |  | — |  |  | 177,584 |  |  | — |  |
| Total | $ | 859,780 |  |  | $ | (1,177) |  |  | $ | 409,973 |  |  | $ | 448,630 |  |  | $ | — |  |

[0001408710-25-000023:notes:37]
[same as prior period, unchanged from 0001408710-25-000008:notes:33]

[0001408710-25-000023:notes:38]
The following table summarizes the cost and estimated fair value of debt securities classified as available-for-sale securities based on stated effective maturities as of March 28, 2025 and June 28, 2024:

[0001408710-25-000023:notes:39]
|  | March 28, 2025 |  | June 28, 2024 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 234,076 |  |  | $ | 236,659 |  |  | $ | 110,671 |  |  | $ | 110,669 |  |
| Due between one to five years | 401,226 |  |  | 407,113 |  |  | 339,136 |  |  | 337,961 |  |
| Total | $ | 635,302 |  |  | $ | 643,772 |  |  | $ | 449,807 |  |  | $ | 448,630 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001408710-25-000023:notes:40]
[same as prior period, unchanged from 0001408710-25-000008:notes:36]

[0001408710-25-000023:notes:41]
[same as prior period, unchanged from 0001408710-25-000008:notes:37]

[0001408710-25-000023:notes:42]
[same as prior period, unchanged from 0001408710-25-000008:notes:38]

[0001408710-25-000023:notes:43]
[same as prior period, unchanged from 0001408710-25-000008:notes:39]

[0001408710-25-000023:notes:44]
[same as prior period, unchanged from 0001408710-25-000008:notes:40]

[0001408710-25-000023:notes:45]
[same as prior period, unchanged from 0001408710-25-000008:notes:41]

[0001408710-25-000023:notes:46]
|  | Fair Value Measurements at Reporting Date Using |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of March 28, 2025 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 48 |  |  |  | $ | — |  |  | $ | 48 |  |
| Certificates of deposit and time deposits | — |  |  | 249,005 |  |  |  | — |  |  | 249,005 |  |
| Corporate debt securities | — |  |  | 136,587 |  |  |  | — |  |  | 136,587 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 258,180 |  |  |  | — |  |  | 258,180 |  |
| Derivative assets – current portion | — |  |  | 347 |  | (1) |  | — |  |  | 347 |  |
| Total | $ | — |  |  | $ | 644,167 |  |  |  | $ | — |  |  | $ | 644,167 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | (1,129) |  | (2) |  | $ | — |  |  | $ | (1,129) |  |
| Total | $ | — |  |  | $ | (1,129) |  |  |  | $ | — |  |  | $ | (1,129) |  |

[0001408710-25-000023:notes:47]
|  | Fair Value Measurements at Reporting Date Using |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of June 28, 2024 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 35 |  |  |  | $ | — |  |  | $ | 35 |  |
| Certificates of deposit and time deposits | — |  |  | 134,283 |  |  |  | — |  |  | 134,283 |  |
| Corporate debt securities | — |  |  | 136,763 |  |  |  | — |  |  | 136,763 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 177,584 |  |  |  | — |  |  | 177,584 |  |
| Derivative assets – current portion | — |  |  | 15 |  | (3) |  | — |  |  | 15 |  |
| Total | $ | — |  |  | $ | 448,680 |  |  |  | $ | — |  |  | $ | 448,680 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | (2,244) |  | (4) |  | $ | — |  |  | $ | (2,244) |  |
| Total | $ | — |  |  | $ | (2,244) |  |  |  | $ | — |  |  | $ | (2,244) |  |

[0001408710-25-000023:notes:48]
(1)Foreign currency forward contracts with an aggregate notional amount of $50.0 million.

[0001408710-25-000023:notes:49]
(2)Foreign currency forward contracts with an aggregate notional amount of $105.0 million and 0.4 million Canadian dollars.

[0001408710-25-000023:notes:50]
[same as prior period, unchanged from 0001408710-25-000008:notes:46]

[0001408710-25-000023:notes:51]
[same as prior period, unchanged from 0001408710-25-000008:notes:47]

[0001408710-25-000023:notes:52]
[same as prior period, unchanged from 0001408710-25-000008:notes:48]

[0001408710-25-000023:notes:53]
[same as prior period, unchanged from 0001408710-25-000008:notes:49]

[0001408710-25-000023:notes:54]
[same as prior period, unchanged from 0001408710-25-000008:notes:50]

[0001408710-25-000023:notes:55]
[same as prior period, unchanged from 0001408710-25-000008:notes:51]

[0001408710-25-000023:notes:56]
[same as prior period, unchanged from 0001408710-25-000008:notes:52]

[0001408710-25-000023:notes:57]
[same as prior period, unchanged from 0001408710-25-000008:notes:53]

[0001408710-25-000023:notes:58]
[same as prior period, unchanged from 0001408710-25-000008:notes:54]

[0001408710-25-000023:notes:59]
As of March 28, 2025, the Company had 155 outstanding U.S. dollar foreign currency forward contracts against Thai baht, with an aggregate notional amount of $155.0 million and maturity dates ranging from April 2025 through October 2025 and one outstanding Canadian dollar foreign currency forward contract with a notional amount of 0.4 million Canadian dollars and a maturity date in June 2025.

[0001408710-25-000023:notes:60]
[same as prior period, unchanged from 0001408710-25-000008:notes:56]

[0001408710-25-000023:notes:61]
As of March 28, 2025, the hedging relationship over foreign currency forward contracts designated for hedge accounting was determined to be highly effective based on the performance of retrospective and prospective regression testing. As of March 28, 2025, the amount in accumulated other comprehensive income (“AOCI”) expected to be reclassified into earnings within 12 months was a loss of $0.2 million.

[0001408710-25-000023:notes:62]
[same as prior period, unchanged from 0001408710-25-000008:notes:58]

[0001408710-25-000023:notes:63]
During the three and nine months ended March 28, 2025, the Company included an unrealized gain of $1.6 million and $0.6 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-25-000023:notes:64]
During the three and nine months ended March 29, 2024, the Company included an unrealized loss of $3.7 million and $0.8 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-25-000023:notes:65]
[same as prior period, unchanged from 0001408710-25-000008:notes:62]

[0001408710-25-000023:notes:66]
|  |  |  | Three Months Ended |  | Nine Months Ended |
| (in thousands) | Financialstatementsline item |  | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
| Derivatives gain (loss) recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Othercomprehensiveincome (loss) |  | $ | 1,505 |  |  | $ | (8,120) |  |  | $ | 1,448 |  |  | $ | 1,434 |  |
| Interest rate swaps | Othercomprehensiveincome (loss) |  | — |  |  | (41) |  |  | — |  |  | (194) |  |
| Total derivatives gain (loss) recognized in other comprehensive income (loss) |  |  | $ | 1,505 |  |  | $ | (8,161) |  |  | $ | 1,448 |  |  | $ | 1,240 |  |
| Derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings: |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Cost of revenues |  | $ | 2,255 |  |  | $ | (2,805) |  |  | $ | (2,231) |  |  | $ | 5,650 |  |
| Foreign currency forward contracts | SG&A |  | 176 |  |  | (121) |  |  | (169) |  |  | 233 |  |
| Foreign currency forward contracts | Foreign exchange gain (loss), net |  | (1,963) |  |  | 4,250 |  |  | 1,970 |  |  | (6,170) |  |
| Interest rate swaps | Interest expense |  | — |  |  | (44) |  |  | — |  |  | (198) |  |
| Total derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings |  |  | $ | 468 |  |  | $ | 1,280 |  |  | $ | (430) |  |  | $ | (485) |  |
| Change in net unrealized gain (loss) on derivatives instruments |  |  | $ | 1,973 |  |  | $ | (6,881) |  |  | $ | 1,018 |  |  | $ | 755 |  |

[0001408710-25-000023:notes:67]
[same as prior period, unchanged from 0001408710-25-000008:notes:64]

[0001408710-25-000023:notes:68]
[same as prior period, unchanged from 0001408710-25-000008:notes:65]

[0001408710-25-000023:notes:69]
|  | March 28,2025 |  | June 28,2024 |
| (in thousands) | DerivativeAssets |  | DerivativeLiabilities |  | DerivativeAssets |  | DerivativeLiabilities |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts | $ | 61 |  |  | $ | (701) |  |  | $ | — |  |  | $ | (1,088) |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward contracts | 286 |  |  | (428) |  |  | 15 |  |  | (1,156) |  |
| Derivatives, gross balances | $ | 347 |  |  | $ | (1,129) |  |  | $ | 15 |  |  | $ | (2,244) |  |

[0001408710-25-000023:notes:70]
[same as prior period, unchanged from 0001408710-25-000008:notes:67]

[0001408710-25-000023:notes:71]
[same as prior period, unchanged from 0001408710-25-000008:notes:68]


## us-gaap:InventoryDisclosureTextBlock

[0001408710-25-000023:notes:72]
[same as prior period, unchanged from 0001408710-25-000008:notes:69]

[0001408710-25-000023:notes:73]
| (in thousands) | As of March 28,2025 |  | As of June 28,2024 |
| Raw materials | $ | 146,342 |  |  | $ | 138,488 |  |
| Work in progress | 324,518 |  |  | 266,107 |  |
| Finished goods | 36,227 |  |  | 39,701 |  |
| Goods in transit | 24,251 |  |  | 18,910 |  |
| Total inventories | $ | 531,338 |  |  | $ | 463,206 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001408710-25-000023:notes:74]
Leases
The Company leases facilities under non-cancelable operating lease agreements. The Company leases a portion of its capital equipment and vehicles, certain land and buildings for its facilities in Thailand, the Cayman Islands, the PRC, the U.S., Israel and Singapore under operating lease arrangements that expire at various dates through 2034. Certain of these lease arrangements provide the Company the ability to extend the lease term following the expiration of the current term. However, the Company has excluded all lease extension options from its right of use (“ROU”) assets and lease liabilities as the Company is not reasonably assured that it will exercise these options. None of the lease agreements contain residual value guarantees provided by the lessee.

[0001408710-25-000023:notes:75]
[same as prior period, unchanged from 0001408710-25-000008:notes:72]

[0001408710-25-000023:notes:76]
As of March 28, 2025, the maturities of the Company’s operating lease liabilities, by fiscal year, were as follows:

[0001408710-25-000023:notes:77]
| (in thousands) |  |  |
| 2025 (remaining three months) | $ | 512 |  |  |
| 2026 | 2,054 |  |  |
| 2027 | 1,243 |  |  |
| 2028 | 795 |  |  |
| 2029 | 761 |  |  |
| Thereafter | 1,410 |  |  |
| Total undiscounted lease payments | 6,775 |  |  |
| Less imputed interest | (1,054) |  |  |
| Total present value of lease liabilities | $ | 5,721 |  | (1) |

[0001408710-25-000023:notes:78]
[same as prior period, unchanged from 0001408710-25-000008:notes:75]

[0001408710-25-000023:notes:79]
[same as prior period, unchanged from 0001408710-25-000008:notes:76]

[0001408710-25-000023:notes:80]
Rental expense for long-term leases for the three and nine months ended March 28, 2025 was $0.5 million and $1.4 million, respectively, and for the three and nine months ended March 29, 2024 was $0.4 million and $1.5 million, respectively.

[0001408710-25-000023:notes:81]
Rental expense for short-term leases for the three and nine months ended March 28, 2025 was immaterial, and for the three and nine months ended March 29, 2024 was $0.1 million and $0.8 million, respectively.

[0001408710-25-000023:notes:82]
[same as prior period, unchanged from 0001408710-25-000008:notes:79]

[0001408710-25-000023:notes:83]
|  | As ofMarch 28, 2025 |  | As ofJune 28, 2024 |
| Weighted-average remaining lease term (in years) | 5.4 |  | 5.6 |
| Weighted-average discount rate | 6.5 | % |  | 5.6 | % |

[0001408710-25-000023:notes:84]
The following table presents supplemental disclosure for the unaudited condensed consolidated statements of cash flows related to operating leases for the three and nine months ended March 28, 2025 and March 29, 2024:

[0001408710-25-000023:notes:85]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands) | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |
| Operating cash flows from operating leases | $ | 513 |  |  | $ | 442 |  |  | $ | 1,758 |  |  | $ | 2,186 |  |
| ROU assets obtained in exchange for lease liabilities | $ | 47 |  |  | $ | 632 |  |  | $ | 1,984 |  |  | $ | 3,406 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001408710-25-000023:notes:86]
[same as prior period, unchanged from 0001408710-25-000008:notes:83]

[0001408710-25-000023:notes:87]
| (in thousands) | As ofMarch 28, 2025 |  | As ofJune 28, 2024 |  |  |
| Software |  |  |  |  |  |
| Gross carrying amount | $ | 11,952 |  |  | $ | 11,398 |  |  |  |
| Accumulated amortization | (9,779) |  |  | (9,077) |  |  |  |
| Net | $ | 2,173 |  |  | $ | 2,321 |  |  |  |

[0001408710-25-000023:notes:88]
The Company recorded amortization expense relating to intangibles of $0.2 million for each of the three months ended March 28, 2025 and March 29, 2024, and $0.7 million and $0.8 million for the nine months ended March 28, 2025 and March 29, 2024, respectively.

[0001408710-25-000023:notes:89]
[same as prior period, unchanged from 0001408710-25-000008:notes:86]

[0001408710-25-000023:notes:90]
| (years) | As ofMarch 28, 2025 |  | As ofJune 28, 2024 |
| Software | 1.4 |  | 2.1 |

[0001408710-25-000023:notes:91]
Based on the carrying amount of intangibles as of March 28, 2025, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001408710-25-000023:notes:92]
| (in thousands) |  |
| 2025 (remaining three months) | $ | 269 |  |
| 2026 | 781 |  |
| 2027 | 532 |  |
| 2028 | 358 |  |
| 2029 | 177 |  |
| Thereafter | 56 |  |
| Total | $ | 2,173 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001408710-25-000023:notes:93]
Income taxes
As of March 28, 2025 and June 28, 2024, the liability for uncertain tax positions including accrued interest and penalties was $2.3 million and $1.3 million, respectively.

[0001408710-25-000023:notes:94]
The Company files income tax returns in the United States and foreign tax jurisdictions. The tax years from 2017 to 2023 remain open to examination by U.S. federal and state, and foreign tax authorities. The Company is currently under examination by the U.S. Internal Revenue Service for fiscal year 2022 and fiscal year 2023. The Company’s income tax is recognized based on the best estimate of the expected annual effective tax rate for the full financial year of each entity in the Company, adjusted for discrete items arising in that quarter. If the Company’s estimated annual effective tax rate changes, the Company makes a cumulative adjustment in that quarter.

[0001408710-25-000023:notes:95]
The effective tax rate for the Company for the three months ended March 28, 2025 and March 29, 2024 was 5.8% and 2.9%, respectively, of net income. The increase was due to higher income subject to tax and a discrete expense related to continuing assessment of potential tax exposures.

[0001408710-25-000023:notes:96]
The effective tax rate for the Company for the nine months ended March 28, 2025 and March 29, 2024 was 6.3% and 5.0%, respectively, of net income. The increase was due to higher income subject to tax and a discrete expense due to continuing assessment of potential tax exposures during the nine months ended March 28, 2025, offset by a full valuation allowance for deferred tax assets that was set up during the nine months ended March 29, 2024 for the Company's subsidiary in Israel.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001408710-25-000023:notes:97]
[same as prior period, unchanged from 0001408710-25-000008:notes:94]

[0001408710-25-000023:notes:98]
[same as prior period, unchanged from 0001408710-25-000008:notes:95]

[0001408710-25-000023:notes:99]
The effect of recording share-based compensation expense for the three and nine months ended March 28, 2025 and March 29, 2024 was as follows:

[0001408710-25-000023:notes:100]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands) | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |
| Restricted share units | $ | 4,777 |  |  | $ | 3,833 |  |  | $ | 15,920 |  |  | $ | 12,800 |  |
| Performance share units | 3,006 |  |  | 2,893 |  |  | 8,983 |  |  | 8,640 |  |
| Total share-based compensation expense | 7,783 |  |  | 6,726 |  |  | 24,903 |  |  | 21,440 |  |
| Tax effect on share-based compensation expense | — |  |  | — |  |  | — |  |  | — |  |
| Net effect on share-based compensation expense | $ | 7,783 |  |  | $ | 6,726 |  |  | $ | 24,903 |  |  | $ | 21,440 |  |

[0001408710-25-000023:notes:101]
[same as prior period, unchanged from 0001408710-25-000008:notes:98]

[0001408710-25-000023:notes:102]
|  | Three Months Ended |  | Nine Months Ended |
| (in thousands) | March 28,2025 |  | March 29,2024 |  | March 28,2025 |  | March 29,2024 |
| Cost of revenue | $ | 2,221 |  |  | $ | 1,561 |  |  | $ | 7,883 |  |  | $ | 5,427 |  |
| Selling, general and administrative expense | 5,562 |  |  | 5,165 |  |  | 17,020 |  |  | 16,013 |  |
| Total share-based compensation expense | $ | 7,783 |  |  | $ | 6,726 |  |  | $ | 24,903 |  |  | $ | 21,440 |  |

[0001408710-25-000023:notes:103]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the three and nine months ended March 28, 2025 and March 29, 2024.

[0001408710-25-000023:notes:104]
[same as prior period, unchanged from 0001408710-25-000008:notes:101]

[0001408710-25-000023:notes:105]
[same as prior period, unchanged from 0001408710-25-000008:notes:102]

[0001408710-25-000023:notes:106]
[same as prior period, unchanged from 0001408710-25-000008:notes:103]

[0001408710-25-000023:notes:107]
[same as prior period, unchanged from 0001408710-25-000008:notes:104]

[0001408710-25-000023:notes:108]
The following table summarizes the number of equity awards outstanding and ordinary shares available for grant under each of the Equity Incentive Plans as of March 28, 2025:

[0001408710-25-000023:notes:109]
| (share units) | Restricted Share Units outstanding |  | Performance Share Units outstanding |  | Ordinary Shares available for future grant |
| 2020 Plan | 270,488 |  |  | 120,916 |  |  | 1,587,166 |  |
| 2017 Inducement Plan | — |  |  | — |  |  | 111,347 |  |
| Total | 270,488 |  |  | 120,916 |  |  | 1,698,513 |  |

[0001408710-25-000023:notes:110]
[same as prior period, unchanged from 0001408710-25-000008:notes:107]

[0001408710-25-000023:notes:111]
[same as prior period, unchanged from 0001408710-25-000008:notes:108]

[0001408710-25-000023:notes:112]
[same as prior period, unchanged from 0001408710-25-000008:notes:109]

[0001408710-25-000023:notes:113]
[same as prior period, unchanged from 0001408710-25-000008:notes:110]

[0001408710-25-000023:notes:114]
[same as prior period, unchanged from 0001408710-25-000008:notes:111]

[0001408710-25-000023:notes:115]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 28, 2024 | 306,660 |  |  | $ | 129.01 |  |
| Granted | 111,922 |  |  | $ | 259.19 |  |
| Vested | (132,797) |  |  | $ | 118.43 |  |
| Forfeited | (15,297) |  |  | $ | 165.48 |  |
| Balance as of March 28, 2025 | 270,488 |  |  | $ | 186.00 |  |

[0001408710-25-000023:notes:116]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 30, 2023 | 368,765 |  |  | $ | 97.49 |  |
| Granted | 119,097 |  |  | $ | 162.02 |  |
| Vested | (161,927) |  |  | $ | 88.75 |  |
| Forfeited | (14,370) |  |  | $ | 119.71 |  |
| Balance as of March 29, 2024 | 311,565 |  |  | $ | 125.67 |  |

[0001408710-25-000023:notes:117]
[same as prior period, unchanged from 0001408710-25-000008:notes:114]

[0001408710-25-000023:notes:118]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 28, 2024 | 171,078 |  |  | $ | 135.31 |  |
| Granted | 46,980 |  |  | $ | 261.84 |  |
| Vested | (97,142) |  |  | $ | 117.35 |  |
| Forfeited | — |  |  | $ | — |  |
| Balance as of March 28, 2025 | 120,916 |  |  | $ | 198.90 |  |

[0001408710-25-000023:notes:119]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 30, 2023 | 204,016 |  |  | $ | 108.81 |  |
| Granted | 73,936 |  |  | $ | 158.91 |  |
| Vested | (106,874) |  |  | 101.05 |  |
| Forfeited | — |  |  | $ | — |  |
| Balance as of March 29, 2024 | 171,078 |  |  | $ | 135.31 |  |

[0001408710-25-000023:notes:120]
As of March 28, 2025, there was $22.3 million and $10.2 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.7 and 1.1 years, respectively.

[0001408710-25-000023:notes:121]
For the nine months ended March 28, 2025 and March 29, 2024, the Company withheld an aggregate of 90,792 shares and 102,543 shares, respectively, upon the vesting of restricted share units and performance shares units, based upon the closing share price on the vesting date to settle employee tax withholding obligations. For the nine months ended March 28, 2025 and March 29, 2024, the Company then remitted cash of $20.9 million and $12.7 million, respectively, to the appropriate taxing authorities and presented it as a financing activity within the unaudited condensed consolidated statements of cash flows. The payment was recorded as a reduction of additional paid-in capital.

[0001408710-25-000023:notes:122]
On March 12, 2025, the Company issued a warrant (the “Warrant”) to Amazon.com NV Investment Holdings LLC to acquire up to 381,922 ordinary shares (the “Warrant Shares”) of the Company at an exercise price of $208.48 per share. The Warrant allows for cashless exercise and expires on March 12, 2032.

[0001408710-25-000023:notes:123]
Upon issuance of the Warrant, 38,192 of the Warrant Shares vested. The remainder of the Warrant Shares are subject to vesting in multiple tranches over the term of the Warrant based on payments to the Company from or on behalf of Amazon.com, Inc. ("Amazon") or its affiliates under a commercial agreement or otherwise. Upon the consummation of an acquisition transaction or the termination of the commercial agreement by Amazon for cause, the unvested portion of the Warrant will vest in full. The exercise price and the number of Warrant Shares are subject to customary antidilution adjustments.

[0001408710-25-000023:notes:124]
Using the Black-Scholes option pricing model, the grant date fair value of the Warrant was determined to be $102.88 per share, for a total fair value of $39.3 million. The grant date fair value of the Warrant was estimated as of the issuance date using the following assumptions:

[0001408710-25-000023:notes:125]
| Expected dividend yield | — |  |
| Risk-free interest rate | 3.8 | % |
| Expected volatility | 45.2 | % |
| Expected term (in years) | 7 years |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001408710-25-000023:notes:126]
[same as prior period, unchanged from 0001408710-25-000008:notes:119]

[0001408710-25-000023:notes:127]
[same as prior period, unchanged from 0001408710-25-000008:notes:120]

[0001408710-25-000023:notes:128]
For the three and nine months ended March 28, 2025, Fabrinet issued 11,421 and 139,147 ordinary shares, respectively, upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-25-000023:notes:129]
For the three and nine months ended March 29, 2024, Fabrinet issued 15,080 and 166,258 ordinary shares, respectively, upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-25-000023:notes:130]
[same as prior period, unchanged from 0001408710-25-000008:notes:123]

[0001408710-25-000023:notes:131]
[same as prior period, unchanged from 0001408710-25-000008:notes:124]

[0001408710-25-000023:notes:132]
In August 2017, the Company’s board of directors approved a share repurchase program to permit the Company to repurchase up to $30.0 million worth of its issued and outstanding ordinary shares in the open market in accordance with applicable rules and regulations. In February 2018, May 2019, August 2020, August 2022, August 2023, August 2024, and January 2025, the Company’s board of directors approved an increase of $30.0 million, $50.0 million, $58.5 million, $78.7 million, $47.6 million, $139.5 million, and $100.0 million, respectively, to the original share repurchase authorization, bringing the aggregate authorization to $534.3 million.

[0001408710-25-000023:notes:133]
During the nine months ended March 28, 2025, 453,913 shares were repurchased under the program, at an average price per share (excluding other direct costs) of $227.94, for an aggregate purchase price of $103.5 million. As of March 28, 2025, the Company had a remaining authorization to repurchase up to $196.5 million worth of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001408710-25-000023:notes:134]
Accumulated other comprehensive income (loss)
The changes in AOCI for the nine months ended March 28, 2025 and March 29, 2024 were as follows:

[0001408710-25-000023:notes:135]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  |  |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 28, 2024 | $ | (1,179) |  |  | $ | (980) |  |  |  |  | $ | (982) |  |  | $ | (3,141) |  |
| Other comprehensive income (loss) before reclassification | 9,647 |  |  | 1,448 |  |  |  |  | 1,136 |  |  | 12,231 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | — |  |  | (430) |  |  |  |  | — |  |  | (430) |  |
| Tax effects | — |  |  | (111) |  |  |  |  | — |  |  | (111) |  |
| Other comprehensive income (loss) | $ | 9,647 |  |  | $ | 907 |  |  |  |  | $ | 1,136 |  |  | $ | 11,690 |  |
| Balance as of March 28, 2025 | $ | 8,468 |  |  | $ | (73) |  |  |  |  | $ | 154 |  |  | $ | 8,549 |  |

[0001408710-25-000023:notes:136]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 30, 2023 | $ | (3,279) |  |  | $ | (3,541) |  |  | $ | (330) |  |  | $ | (965) |  |  | $ | (8,115) |  |
| Other comprehensive income (loss) before reclassification | 2,154 |  |  | 1,240 |  |  | — |  |  | (31) |  |  | 3,363 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | 1 |  |  | (485) |  |  | 250 |  |  | — |  |  | (234) |  |
| Tax effects | — |  |  | 307 |  |  | 21 |  |  | — |  |  | 328 |  |
| Other comprehensive income (loss) | $ | 2,155 |  |  | $ | 1,062 |  |  | $ | 271 |  |  | $ | (31) |  |  | $ | 3,457 |  |
| Balance as of March 29, 2024 | $ | (1,124) |  |  | $ | (2,479) |  |  | $ | (59) |  |  | $ | (996) |  |  | $ | (4,658) |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001408710-25-000023:notes:137]
Commitments and contingencies
Bank guarantees

[0001408710-25-000023:notes:138]
As of March 28, 2025 and June 28, 2024, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.2 million and $2.0 million, respectively, or Thai baht 75.7 million and 73.2 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the subsidiary's operations related to the Israeli Customs department.

[0001408710-25-000023:notes:139]
Purchase obligations

[0001408710-25-000023:notes:140]
Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001408710-25-000023:notes:141]
As of March 28, 2025, the Company had purchase obligations and other commitments to third parties of $1.27 billion.

[0001408710-25-000023:notes:142]
Capital expenditures

[0001408710-25-000023:notes:143]
In February 2025, the Company entered into a construction contract with a local contractor for construction of a new

[0001408710-25-000023:notes:144]
manufacturing building at the Company's Chonburi campus. The contract price is approximately $132.5 million (Thai baht

[0001408710-25-000023:notes:145]
4.45 billion).

[0001408710-25-000023:notes:146]
As of March 28, 2025, the Company had total capital expenditure commitments to third parties of $174.3 million.

[0001408710-25-000023:notes:147]
Indemnification of directors and officers

[0001408710-25-000023:notes:148]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001408710-25-000023:notes:149]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.

[0001408710-25-000023:notes:150]
Credit facility agreement

[0001408710-25-000023:notes:151]
On March 9, 2023, Fabrinet Thailand and the Parent Company (collectively, the “Borrowers”) and the Bank of Ayudhya Public Company Limited (the "Bank") entered into a credit facility agreement (the “2023 Credit Facility Agreement”), which provided a facility of $55.0 million.

[0001408710-25-000023:notes:152]
During the three months ended December 27, 2024, the Borrowers and the Bank amended the 2023 Credit Facility Agreement to reduce the facility to $30.0 million, which may be used for, among other things, an overdraft facility.

[0001408710-25-000023:notes:153]
As of March 28, 2025, there was no amount outstanding under the 2023 Credit Facility Agreement.

[0001408710-25-000023:notes:154]
Under the 2023 Credit Facility Agreement, the Borrowers are required to maintain a debt-to-equity ratio of less than or equal to 1.5 times for Fabrinet Thailand and 1.0 times for the Parent Company.

[0001408710-25-000023:notes:155]
As of March 28, 2025, the Borrowers were in compliance with all of their financial covenants under the 2023 Credit Facility Agreement.

[0001408710-25-000023:notes:156]
Litigation and claim

[0001408710-25-000023:notes:157]
On June 28, 2024, Ngan In Leng and First Laser Limited (collectively, the “Plaintiffs”) filed a complaint in the Fuzhou Intermediate People’s Court (the “Court”) in Fuzhou, China against Fujian Enterprises (Holdings) Co., Ltd. (“FEHC”), Jian An Investment Limited (“Jian”), and Casix, Inc. (“Casix”), the Company's wholly-owned subsidiary located in the PRC. The complaint alleges unjust enrichment related to a purported investment in Casix by the Plaintiffs in 1997, which predates the Company's acquisition of Casix from JDS Uniphase Corporation. The Plaintiffs have requested that the Court order FEHC to return the unjust enrichment to the Plaintiffs in the amount of RMB 400 million, with interest from March 1, 2000, and order Jian and Casix to bear joint and several liability for all payment obligations of FEHC.

[0001408710-25-000023:notes:158]
In September 2024, the Court dismissed the lawsuit in its entirety based on jurisdictional grounds. The Plaintiffs have since appealed the Court’s ruling to the High People's Court of Fujian Province (the "Appellate Court"). In their appeal, the Plaintiffs now claim that Casix is the primary obligor to return the alleged unjust enrichment to the Plaintiffs. On November 24, 2024, the Appellate Court agreed to hear the appeal. At this time, the Company is not able to quantify any potential liability in connection with this litigation because of the early stage of this litigation.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001408710-25-000023:notes:159]
Restructuring and other related costs
In January 2025, the Company implemented a restructuring initiative aimed at enhancing operational effectiveness and streamlining activities within its subsidiary located in Thailand. As a result of the restructuring, the Company incurred total charges of $1.3 million, which were primarily related to employee severance and other termination benefits. These severance-related charges reflect the costs associated with workforce reductions across various functions within the Thailand operations.

[0001408710-25-000023:notes:160]
The restructuring charges have been recognized in the condensed consolidated statements of operations within "Restructuring and other related charges" for the three months ended March 28, 2025. The Company recognizes severance-related charges depending on whether the termination benefits are provided under an ongoing benefit arrangement or under a one-time benefit arrangement. The Company recognizes the charges once the benefits have been communicated to employees.

[0001408710-25-000023:notes:161]
As of March 28, 2025, there was no restructuring liability balance.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001408710-25-000023:notes:162]
Business segments and geographic information
Operating segments are defined as components of an enterprise that engage in business activities for which discrete financial information is available that is evaluated regularly by the chief operating decision maker (the “CODM”) in deciding how to allocate resources and in assessing performance. The Company’s CODM is Fabrinet’s Chief Executive Officer. As of March 28, 2025, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001408710-25-000023:notes:163]
[same as prior period, unchanged from 0001408710-25-000008:notes:151]

[0001408710-25-000023:notes:164]
[same as prior period, unchanged from 0001408710-25-000008:notes:152]

[0001408710-25-000023:notes:165]
| (in thousands) |  | March 28,2025 |  | June 28,2024 |
| Long-Lived Assets: |  |  |  |  |
| Thailand |  | $ | 311,518 |  |  | $ | 261,141 |  |
| U.S. |  | 27,850 |  |  | 28,914 |  |
| China |  | 13,415 |  |  | 14,586 |  |
| Israel |  | 1,281 |  |  | 2,160 |  |
| Others |  | 425 |  |  | 439 |  |
| Total |  | $ | 354,489 |  |  | $ | 307,240 |  |

[0001408710-25-000023:notes:166]
[same as prior period, unchanged from 0001408710-25-000008:notes:154]

[0001408710-25-000023:notes:167]
The Company had four and three customers that each contributed to 10% or more of the Company's total trade accounts receivable as of March 28, 2025 and June 28, 2024, respectively.

[0001408710-25-000023:notes:168]
During the nine months ended March 28, 2025 and March 29, 2024, the Company had two customers and three customers, respectively, that each contributed 10% or more of the Company's revenues. Such customers together accounted for 47.5% and 56.4% of the Company revenues during the respective periods.
