# FN notes — 0001408710-25-000008


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001408710-25-000008:notes:1]
[same as prior period, unchanged from 0001408710-24-000040:notes:2]

[0001408710-25-000008:notes:2]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of December 27, 2024 and for the three and six months ended December 27, 2024 and December 29, 2023 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 28, 2024.

[0001408710-25-000008:notes:3]
[same as prior period, unchanged from 0001408710-24-000040:notes:4]

[0001408710-25-000008:notes:4]
The results for the three and six months ended December 27, 2024 may not be indicative of results for the year ending June 27, 2025 or any future periods.

[0001408710-25-000008:notes:5]
[same as prior period, unchanged from 0001408710-24-000040:notes:6]

[0001408710-25-000008:notes:6]
[same as prior period, unchanged from 0001408710-24-000040:notes:7]

[0001408710-25-000008:notes:7]
[same as prior period, unchanged from 0001408710-24-000040:notes:8]

[0001408710-25-000008:notes:8]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended December 27, 2024 and December 29, 2023 consisted of 13 weeks. Fiscal year 2025 will comprise 52 weeks and will end on June 27, 2025.

[0001408710-25-000008:notes:9]
[same as prior period, unchanged from 0001408710-24-000040:notes:12]

[0001408710-25-000008:notes:10]
In November 2023, the Financial Accounting Standards Board ("FASB") issued ASU 2023-07, “Segment Reporting (Topic 280), Improvements to Reportable Segment Disclosures,” which is intended to improve reportable segment disclosure requirements, primarily through additional disclosures about significant segment expenses. This ASU is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. This ASU is effective for the Company's annual periods beginning June 29, 2024, and interim periods beginning June 28, 2025, and will be applied retrospectively to all prior periods presented in the financial statements. The Company is currently evaluating the ASU to determine its impact on the Company's disclosures.

[0001408710-25-000008:notes:11]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740), Improvements to Income Tax Disclosures,” which requires more detailed income tax disclosures. This ASU requires entities to disclose disaggregated information about their effective tax rate reconciliation as well as expanded information on income taxes paid by jurisdiction. This ASU is effective for all entities for fiscal years beginning after December 15, 2024, with early adoption permitted for annual financial statements that have not yet been issued or made available for issuance. This ASU will be effective for the Company beginning with fiscal year 2026. The Company is currently assessing the impact to its disclosures.

[0001408710-25-000008:notes:12]
In November 2024, the FASB issued ASU 2024-03, “Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), Disaggregation of Income Statement Expenses,” which requires additional notes to financial statements. This ASU requires entities to include certain current disclosures in the same tabular format disclosure as the other disaggregation requirements in the amendments in this ASU. This ASU is effective for all entities for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027, with early adoption permitted. This ASU is effective for the Company's annual periods beginning June 26, 2027, and interim periods beginning July 1, 2028, and will be applied retrospectively to all prior periods presented in the financial statements. The Company is currently evaluating the ASU to determine its impact on the Company's disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001408710-25-000008:notes:13]
[same as prior period, unchanged from 0001408710-24-000040:notes:14]

[0001408710-25-000008:notes:14]
[same as prior period, unchanged from 0001408710-24-000040:notes:15]

[0001408710-25-000008:notes:15]
[same as prior period, unchanged from 0001408710-24-000040:notes:16]

[0001408710-25-000008:notes:16]
| (in thousands, except percentages) | Three Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 371,112 |  |  |  |  | $ | 678,932 |  |  |  |
| Others (1) | 1,291 |  |  |  |  | 2,949 |  |  |  |
| Total revenue in North America | 372,403 |  |  | 44.7 | % |  | 681,881 |  |  | 41.6 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 240,671 |  |  |  |  | 531,624 |  |  |  |
| India | 75,629 |  |  |  |  | 152,459 |  |  |  |
| Hong Kong | 20,415 |  |  |  |  | 38,962 |  |  |  |
| Thailand | 14,069 |  |  |  |  | 25,190 |  |  |  |
| China | 13,650 |  |  |  |  | 25,522 |  |  |  |
| Singapore | 12,481 |  |  |  |  | 23,244 |  |  |  |
| Japan | 8,976 |  |  |  |  | 17,555 |  |  |  |
| Malaysia | 7,565 |  |  |  |  | 15,063 |  |  |  |
| Others | 726 |  |  |  |  | 1,201 |  |  |  |
| Total revenue in Asia-Pacific and others | 394,182 |  |  | 47.3 | % |  | 830,820 |  |  | 50.7 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 39,262 |  |  |  |  | 71,712 |  |  |  |
| Germany | 10,867 |  |  |  |  | 20,211 |  |  |  |
| Others | 16,894 |  |  |  |  | 33,212 |  |  |  |
| Total revenue in Europe | $ | 67,023 |  |  | 8.0 | % |  | $ | 125,135 |  |  | 7.7 | % |
| Total revenue | $ | 833,608 |  |  | 100.0 | % |  | $ | 1,637,836 |  |  | 100.0 | % |

[0001408710-25-000008:notes:17]
| (in thousands, except percentages) | Three Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |  | Six Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 238,288 |  |  |  |  | $ | 493,147 |  |  |  |
| Others (1) | 3,331 |  |  |  |  | 6,791 |  |  |  |
| Total revenue in North America | 241,619 |  |  | 33.9 | % |  | 499,938 |  |  | 35.8 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 267,038 |  |  |  |  | 477,714 |  |  |  |
| India | 75,033 |  |  |  |  | 145,810 |  |  |  |
| Malaysia | 36,626 |  |  |  |  | 69,945 |  |  |  |
| China | 21,262 |  |  |  |  | 41,522 |  |  |  |
| Hong Kong | 12,150 |  |  |  |  | 27,938 |  |  |  |
| Thailand | 10,403 |  |  |  |  | 23,430 |  |  |  |
| Japan | 5,826 |  |  |  |  | 12,636 |  |  |  |
| Others | 1,570 |  |  |  |  | 2,735 |  |  |  |
| Total revenue in Asia-Pacific and others | 429,908 |  |  | 60.3 | % |  | 801,730 |  |  | 57.3 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 18,870 |  |  |  |  | 48,644 |  |  |  |
| Germany | 10,395 |  |  |  |  | 23,175 |  |  |  |
| Others | 11,902 |  |  |  |  | 24,684 |  |  |  |
| Total revenue in Europe | $ | 41,167 |  |  | 5.8 | % |  | $ | 96,503 |  |  | 6.9 | % |
| Total revenue | $ | 712,694 |  |  | 100.0 | % |  | $ | 1,398,171 |  |  | 100.0 | % |

[0001408710-25-000008:notes:18]
[same as prior period, unchanged from 0001408710-24-000040:notes:18]

[0001408710-25-000008:notes:19]
[same as prior period, unchanged from 0001408710-24-000040:notes:19]

[0001408710-25-000008:notes:20]
| (in thousands, except percentages) | Three Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 299,101 |  |  |  |  | $ | 627,982 |  |  |  |
| Telecom | 348,049 |  |  |  |  | 645,483 |  |  |  |
| Total revenue - Optical communications | $ | 647,150 |  |  | 77.6 | % |  | $ | 1,273,465 |  |  | 77.8 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 104,247 |  |  |  |  | $ | 206,988 |  |  |  |
| Industrial laser | 37,542 |  |  |  |  | 72,868 |  |  |  |
| Others | 44,669 |  |  |  |  | 84,515 |  |  |  |
| Total revenue - Non-optical communications | $ | 186,458 |  |  | 22.4 | % |  | $ | 364,371 |  |  | 22.2 | % |
| Total revenue | $ | 833,608 |  |  | 100.0 | % |  | $ | 1,637,836 |  |  | 100.0 | % |

[0001408710-25-000008:notes:21]
| (in thousands, except percentages) | Three Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |  | Six Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 288,121 |  |  |  |  | $ | 530,164 |  |  |  |
| Telecom | 279,813 |  |  |  |  | 571,027 |  |  |  |
| Total revenue - Optical communications | $ | 567,934 |  |  | 79.7 | % |  | $ | 1,101,191 |  |  | 78.8 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 79,172 |  |  |  |  | $ | 167,530 |  |  |  |
| Industrial laser | 30,348 |  |  |  |  | 60,263 |  |  |  |
| Others | 35,240 |  |  |  |  | 69,187 |  |  |  |
| Total revenue - Non-optical communications | $ | 144,760 |  |  | 20.3 | % |  | $ | 296,980 |  |  | 21.2 | % |
| Total revenue | $ | 712,694 |  |  | 100.0 | % |  | $ | 1,398,171 |  |  | 100.0 | % |

[0001408710-25-000008:notes:22]
[same as prior period, unchanged from 0001408710-24-000040:notes:21]

[0001408710-25-000008:notes:23]
[same as prior period, unchanged from 0001408710-24-000040:notes:22]

[0001408710-25-000008:notes:24]
As of December 27, 2024 and June 28, 2024, the Company's contract assets were de minimis.

[0001408710-25-000008:notes:25]
[same as prior period, unchanged from 0001408710-24-000040:notes:24]

[0001408710-25-000008:notes:26]
The following tables summarize the activity in the Company’s contract liabilities during the six months ended December 27, 2024:

[0001408710-25-000008:notes:27]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 28, 2024 | $ | 7,846 |  |
| Advance payments received during the period | 5,615 |  |
| Revenue recognized | (4,845) |  |
| Ending balance, December 27, 2024 | $ | 8,616 |  |


## us-gaap:EarningsPerShareTextBlock

[0001408710-25-000008:notes:28]
[same as prior period, unchanged from 0001408710-24-000040:notes:27]

[0001408710-25-000008:notes:29]
[same as prior period, unchanged from 0001408710-24-000040:notes:28]

[0001408710-25-000008:notes:30]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands, except per share data) | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
| Net income attributable to shareholders | $ | 86,636 |  |  | $ | 69,110 |  |  | $ | 164,030 |  |  | $ | 134,199 |  |
| Weighted-average number of ordinary shares outstanding | 36,163 |  |  | 36,328 |  |  | 36,183 |  |  | 36,292 |  |
| Incremental shares arising from the assumed vesting of restricted share units and performance share units | 239 |  |  | 311 |  |  | 222 |  |  | 268 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share | 36,402 |  |  | 36,639 |  |  | 36,405 |  |  | 36,560 |  |
| Basic earnings per ordinary share | $ | 2.40 |  |  | $ | 1.90 |  |  | $ | 4.53 |  |  | $ | 3.70 |  |
| Diluted earnings per ordinary share | $ | 2.38 |  |  | $ | 1.89 |  |  | $ | 4.51 |  |  | $ | 3.67 |  |


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001408710-25-000008:notes:31]
[same as prior period, unchanged from 0001408710-24-000040:notes:30]

[0001408710-25-000008:notes:32]
|  |  |  | Fair Value |
| (in thousands) | CarryingCost |  | UnrealizedGain/(Loss) |  | Cash andCashEquivalents |  | Short-term investments |  | OtherInvestments |
| As of December 27, 2024 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 352,399 |  |  | $ | — |  |  | $ | 352,399 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 51,273 |  |  | (10) |  |  | 51,263 |  |  | — |  |  | — |  |
| Certificates of deposit and time deposits | 135,026 |  |  | 1,824 |  |  | — |  |  | 136,850 |  |  | — |  |
| Corporate debt securities | 136,515 |  |  | 2,848 |  |  | — |  |  | 139,363 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 254,297 |  |  | 459 |  |  | — |  |  | 254,756 |  |  | — |  |
| Total | $ | 929,510 |  |  | $ | 5,121 |  |  | $ | 403,662 |  |  | $ | 530,969 |  |  | $ | — |  |
| As of June 28, 2024 |  |  |  |  |  |  |  |  |  |
| Cash | $ | 409,938 |  |  | $ | — |  |  | $ | 409,938 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents | 35 |  |  | — |  |  | 35 |  |  | — |  |  | — |  |
| Certificates of deposit and time deposits | 134,288 |  |  | (5) |  |  | — |  |  | 134,283 |  |  | — |  |
| Corporate debt securities | 137,695 |  |  | (932) |  |  | — |  |  | 136,763 |  |  | — |  |
| U.S. agency and U.S. treasury securities | 177,824 |  |  | (240) |  |  | — |  |  | 177,584 |  |  | — |  |
| Total | $ | 859,780 |  |  | $ | (1,177) |  |  | $ | 409,973 |  |  | $ | 448,630 |  |  | $ | — |  |

[0001408710-25-000008:notes:33]
All highly liquid investments with original maturities of three months or less at the date of purchase are classified as cash equivalents. Management determines the appropriate classification of its investments at the time of purchase. The Company may sell certain of its short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s short-term investments generally range from three months to three years.

[0001408710-25-000008:notes:34]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of December 27, 2024 and June 28, 2024:

[0001408710-25-000008:notes:35]
|  | December 27, 2024 |  | June 28, 2024 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 122,647 |  |  | $ | 124,479 |  |  | $ | 110,671 |  |  | $ | 110,669 |  |
| Due between one to five years | 403,191 |  |  | 406,490 |  |  | 339,136 |  |  | 337,961 |  |
| Total | $ | 525,838 |  |  | $ | 530,969 |  |  | $ | 449,807 |  |  | $ | 448,630 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001408710-25-000008:notes:36]
[same as prior period, unchanged from 0001408710-24-000040:notes:35]

[0001408710-25-000008:notes:37]
[same as prior period, unchanged from 0001408710-24-000040:notes:36]

[0001408710-25-000008:notes:38]
[same as prior period, unchanged from 0001408710-24-000040:notes:37]

[0001408710-25-000008:notes:39]
[same as prior period, unchanged from 0001408710-24-000040:notes:38]

[0001408710-25-000008:notes:40]
[same as prior period, unchanged from 0001408710-24-000040:notes:39]

[0001408710-25-000008:notes:41]
[same as prior period, unchanged from 0001408710-24-000040:notes:40]

[0001408710-25-000008:notes:42]
|  | Fair Value Measurements at Reporting Date Using |
| (in thousands) | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| As of December 27, 2024 |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash equivalents | $ | — |  |  | $ | 51,263 |  |  |  | $ | — |  |  | $ | 51,263 |  |
| Certificates of deposit and time deposits | — |  |  | 136,850 |  |  |  | — |  |  | 136,850 |  |
| Corporate debt securities | — |  |  | 139,363 |  |  |  | — |  |  | 139,363 |  |
| U.S. agency and U.S. treasury securities | — |  |  | 254,756 |  |  |  | — |  |  | 254,756 |  |
| Derivative assets – current portion | — |  |  | 645 |  | (1) |  | — |  |  | 645 |  |
| Total | $ | — |  |  | $ | 582,877 |  |  |  | $ | — |  |  | $ | 582,877 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Derivative liabilities – current portion | $ | — |  |  | $ | (2,932) |  |  |  | $ | — |  |  | $ | (2,932) |  |
| Total | $ | — |  |  | $ | (2,932) |  | (2) |  | $ | — |  |  | $ | (2,932) |  |

[0001408710-25-000008:notes:43]
[same as prior period, unchanged from 0001408710-24-000040:notes:42]

[0001408710-25-000008:notes:44]
(1)Foreign currency forward contracts with an aggregate notional amount of $27.0 million.

[0001408710-25-000008:notes:45]
(2)Foreign currency forward contracts with an aggregate notional amount of $119.0 million and 0.3 million Canadian dollars.

[0001408710-25-000008:notes:46]
[same as prior period, unchanged from 0001408710-24-000040:notes:45]

[0001408710-25-000008:notes:47]
[same as prior period, unchanged from 0001408710-24-000040:notes:46]

[0001408710-25-000008:notes:48]
[same as prior period, unchanged from 0001408710-24-000040:notes:47]

[0001408710-25-000008:notes:49]
[same as prior period, unchanged from 0001408710-24-000040:notes:48]

[0001408710-25-000008:notes:50]
[same as prior period, unchanged from 0001408710-24-000040:notes:49]

[0001408710-25-000008:notes:51]
[same as prior period, unchanged from 0001408710-24-000040:notes:50]

[0001408710-25-000008:notes:52]
[same as prior period, unchanged from 0001408710-24-000040:notes:51]

[0001408710-25-000008:notes:53]
[same as prior period, unchanged from 0001408710-24-000040:notes:52]

[0001408710-25-000008:notes:54]
[same as prior period, unchanged from 0001408710-24-000040:notes:53]

[0001408710-25-000008:notes:55]
As of December 27, 2024, the Company had 146 outstanding U.S. dollar foreign currency forward contracts against Thai baht, with an aggregate notional amount of $146.0 million and maturity dates ranging from January 2025 through July 2025 and one outstanding Canadian dollar foreign currency forward contract with a notional amount of 0.3 million Canadian dollars and a maturity date in March 2025.

[0001408710-25-000008:notes:56]
[same as prior period, unchanged from 0001408710-24-000040:notes:55]

[0001408710-25-000008:notes:57]
As of December 27, 2024, the hedging relationship over foreign currency forward contracts designated for hedge accounting was determined to be highly effective based on the performance of retrospective and prospective regression testing. As of December 27, 2024, the amount in accumulated other comprehensive income (“AOCI”) expected to be reclassified into earnings within 12 months was a loss of $2.1 million.

[0001408710-25-000008:notes:58]
[same as prior period, unchanged from 0001408710-24-000040:notes:57]

[0001408710-25-000008:notes:59]
During the three and six months ended December 27, 2024, the Company included unrealized loss of $5.1 million and $1.0 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-25-000008:notes:60]
During the three and six months ended December 29, 2023, the Company included unrealized gain of $2.6 million and $2.9 million, respectively, from changes in the fair value of a foreign currency forward contract that was not designated for

[0001408710-25-000008:notes:61]
hedge accounting in earnings as foreign exchange gain (loss), net in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-25-000008:notes:62]
[same as prior period, unchanged from 0001408710-24-000040:notes:59]

[0001408710-25-000008:notes:63]
|  |  |  | Three Months Ended |  | Six Months Ended |
| (in thousands) | Financialstatementsline item |  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
| Derivatives gain (loss) recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Othercomprehensiveincome (loss) |  | $ | (13,303) |  |  | $ | 11,119 |  |  | $ | (57) |  |  | $ | 9,554 |  |
| Interest rate swaps | Othercomprehensiveincome (loss) |  | — |  |  | (75) |  |  | — |  |  | (153) |  |
| Total derivatives gain (loss) recognized in other comprehensive income (loss) |  |  | $ | (13,303) |  |  | $ | 11,044 |  |  | $ | (57) |  |  | $ | 9,401 |  |
| Derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings: |  |  |  |  |  |  |  |  |  |
| Foreign currency forward contracts | Cost of revenues |  | $ | (5,905) |  |  | $ | 4,783 |  |  | $ | (4,486) |  |  | $ | 8,455 |  |
| Foreign currency forward contracts | SG&A |  | (451) |  |  | 199 |  |  | (345) |  |  | 354 |  |
| Foreign currency forward contracts | Foreign exchange gain (loss), net |  | 9,842 |  |  | (7,205) |  |  | 3,933 |  |  | (10,420) |  |
| Interest rate swaps | Interest expense |  | — |  |  | (65) |  |  | — |  |  | (154) |  |
| Total derivatives (gain) loss reclassified from accumulated other comprehensive income (loss) into earnings |  |  | $ | 3,486 |  |  | $ | (2,288) |  |  | $ | (898) |  |  | $ | (1,765) |  |
| Change in net unrealized gain (loss) on derivatives instruments |  |  | $ | (9,817) |  |  | $ | 8,756 |  |  | $ | (955) |  |  | $ | 7,636 |  |

[0001408710-25-000008:notes:64]
[same as prior period, unchanged from 0001408710-24-000040:notes:61]

[0001408710-25-000008:notes:65]
[same as prior period, unchanged from 0001408710-24-000040:notes:62]

[0001408710-25-000008:notes:66]
|  | December 27,2024 |  | June 28,2024 |
| (in thousands) | DerivativeAssets |  | DerivativeLiabilities |  | DerivativeAssets |  | DerivativeLiabilities |
| Derivatives not designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward and option contracts | $ | 467 |  |  | $ | (565) |  |  | $ | — |  |  | $ | (1,088) |  |
| Derivatives designated as hedging instruments |  |  |  |  |  |  |  |
| Foreign currency forward contracts | 178 |  |  | (2,367) |  |  | 15 |  |  | (1,156) |  |
| Derivatives, gross balances | $ | 645 |  |  | $ | (2,932) |  |  | $ | 15 |  |  | $ | (2,244) |  |

[0001408710-25-000008:notes:67]
[same as prior period, unchanged from 0001408710-24-000040:notes:64]

[0001408710-25-000008:notes:68]
[same as prior period, unchanged from 0001408710-24-000040:notes:65]


## us-gaap:InventoryDisclosureTextBlock

[0001408710-25-000008:notes:69]
[same as prior period, unchanged from 0001408710-24-000040:notes:66]

[0001408710-25-000008:notes:70]
| (in thousands) | As of December 27,2024 |  | As of June 28,2024 |
| Raw materials | $ | 115,138 |  |  | $ | 138,488 |  |
| Work in progress | 304,481 |  |  | 266,107 |  |
| Finished goods | 49,786 |  |  | 39,701 |  |
| Goods in transit | 19,754 |  |  | 18,910 |  |
| Total inventories | $ | 489,159 |  |  | $ | 463,206 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001408710-25-000008:notes:71]
[same as prior period, unchanged from 0001408710-24-000040:notes:68]

[0001408710-25-000008:notes:72]
[same as prior period, unchanged from 0001408710-24-000040:notes:69]

[0001408710-25-000008:notes:73]
As of December 27, 2024, the maturities of the Company’s operating lease liabilities, by fiscal year, were as follows:

[0001408710-25-000008:notes:74]
| (in thousands) |  |  |
| 2025 (remaining six months) | $ | 1,020 |  |  |
| 2026 | 2,040 |  |  |
| 2027 | 1,230 |  |  |
| 2028 | 784 |  |  |
| 2029 | 753 |  |  |
| Thereafter | 1,410 |  |  |
| Total undiscounted lease payments | 7,237 |  |  |
| Less imputed interest | (1,144) |  |  |
| Total present value of lease liabilities | $ | 6,093 |  | (1) |

[0001408710-25-000008:notes:75]
(1)Includes current portion of operating lease liabilities of $1.7 million.

[0001408710-25-000008:notes:76]
[same as prior period, unchanged from 0001408710-24-000040:notes:73]

[0001408710-25-000008:notes:77]
Rental expense for long-term leases for the three and six months ended December 27, 2024 was $0.4 million and $0.9 million, respectively, and for the three and six months ended December 29, 2023 was $0.5 million and $1.1 million, respectively.

[0001408710-25-000008:notes:78]
Rental expense for short-term leases for the three and six months ended December 27, 2024 was immaterial, and for the three and six months ended December 29, 2023 was $0.3 million, and $0.7 million, respectively.

[0001408710-25-000008:notes:79]
[same as prior period, unchanged from 0001408710-24-000040:notes:76]

[0001408710-25-000008:notes:80]
|  | As ofDecember 27, 2024 |  | As ofJune 28, 2024 |
| Weighted-average remaining lease term (in years) | 5.4 |  | 5.6 |
| Weighted-average discount rate | 6.4 | % |  | 5.6 | % |

[0001408710-25-000008:notes:81]
The following table presents supplemental disclosure for the unaudited condensed consolidated statements of cash flows related to operating leases for the three and six months ended December 27, 2024 and December 29, 2023:

[0001408710-25-000008:notes:82]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands) | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
| Cash paid for amounts included in the measurement of lease liabilities |  |  |  |  |  |  |  |
| Operating cash flows from operating leases | $ | 501 |  |  | $ | 785 |  |  | $ | 1,245 |  |  | $ | 1,744 |  |
| ROU assets obtained in exchange for lease liabilities | $ | 1,778 |  |  | $ | 118 |  |  | $ | 1,937 |  |  | $ | 5,054 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001408710-25-000008:notes:83]
[same as prior period, unchanged from 0001408710-24-000040:notes:80]

[0001408710-25-000008:notes:84]
| (in thousands) | As ofDecember 27, 2024 |  | As ofJune 28, 2024 |  |  |
| Software |  |  |  |  |  |
| Gross Carrying Amount | $ | 11,613 |  |  | $ | 11,398 |  |  |  |
| Accumulated Amortization | (9,551) |  |  | (9,077) |  |  |  |
| Net | $ | 2,062 |  |  | $ | 2,321 |  |  |  |

[0001408710-25-000008:notes:85]
The Company recorded amortization expense relating to intangibles of $0.2 million and $0.3 million for the three months ended December 27, 2024 and December 29, 2023, respectively, and $0.5 million and $0.6 million for the six months ended December 27, 2024 and December 29, 2023, respectively.

[0001408710-25-000008:notes:86]
[same as prior period, unchanged from 0001408710-24-000040:notes:84]

[0001408710-25-000008:notes:87]
| (years) | As ofDecember 27, 2024 |  | As ofJune 28, 2024 |
| Software | 1.7 |  | 2.1 |

[0001408710-25-000008:notes:88]
Based on the carrying amount of intangibles as of December 27, 2024, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001408710-25-000008:notes:89]
| (in thousands) |  |
| 2025 (remaining six months) | $ | 563 |  |
| 2026 | 662 |  |
| 2027 | 459 |  |
| 2028 | 288 |  |
| 2029 | 88 |  |
| Thereafter | 2 |  |
| Total | $ | 2,062 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001408710-25-000008:notes:90]
Income taxes
As of December 27, 2024 and June 28, 2024, the liability for uncertain tax positions including accrued interest and penalties was $2.3 million and $1.3 million, respectively.

[0001408710-25-000008:notes:91]
The Company files income tax returns in the United States and foreign tax jurisdictions. The tax years from 2017 to 2023 remain open to examination by U.S. federal and state, and foreign tax authorities. The Company is currently under examination by the U.S. Internal Revenue Service for the fiscal year ended June 24, 2022. The Company’s income tax is recognized based on the best estimate of the expected annual effective tax rate for the full financial year of each entity in the Company, adjusted for discrete items arising in that quarter. If the Company’s estimated annual effective tax rate changes, the Company makes a cumulative adjustment in that quarter.

[0001408710-25-000008:notes:92]
The effective tax rate for the Company for the three months ended December 27, 2024 and December 29, 2023 was 8.7% and 5.2%, respectively, of net income. The increase was due to higher income subject to tax and a discrete expense related to continuing assessment of potential tax exposures.

[0001408710-25-000008:notes:93]
The effective tax rate for the Company for the six months ended December 27, 2024 and December 29, 2023 was 6.6% and 6.2%, respectively, of net income. The increase was due to higher income subject to tax and a discrete expense due to a continuing assessment of potential tax exposures during the six months ended December 27, 2024, offset by a full valuation allowance for deferred tax assets that was set up during the six months ended December 29, 2023 for the Company's subsidiary in Israel.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001408710-25-000008:notes:94]
[same as prior period, unchanged from 0001408710-24-000040:notes:91]

[0001408710-25-000008:notes:95]
[same as prior period, unchanged from 0001408710-24-000040:notes:92]

[0001408710-25-000008:notes:96]
The effect of recording share-based compensation expense for the three and six months ended December 27, 2024 and December 29, 2023 was as follows:

[0001408710-25-000008:notes:97]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands) | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |
| Restricted share units | $ | 5,430 |  |  | $ | 4,088 |  |  | $ | 11,143 |  |  | $ | 8,967 |  |
| Performance share units | 3,008 |  |  | 2,893 |  |  | 5,977 |  |  | 5,747 |  |
| Total share-based compensation expense | 8,438 |  |  | 6,981 |  |  | 17,120 |  |  | 14,714 |  |
| Tax effect on share-based compensation expense | — |  |  | — |  |  | — |  |  | — |  |
| Net effect on share-based compensation expense | $ | 8,438 |  |  | $ | 6,981 |  |  | $ | 17,120 |  |  | $ | 14,714 |  |

[0001408710-25-000008:notes:98]
[same as prior period, unchanged from 0001408710-24-000040:notes:95]

[0001408710-25-000008:notes:99]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands) | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
| Cost of revenue | $ | 2,764 |  |  | $ | 1,701 |  |  | $ | 5,662 |  |  | $ | 3,866 |  |
| Selling, general and administrative expense | 5,674 |  |  | 5,280 |  |  | 11,458 |  |  | 10,848 |  |
| Total share-based compensation expense | $ | 8,438 |  |  | $ | 6,981 |  |  | $ | 17,120 |  |  | $ | 14,714 |  |

[0001408710-25-000008:notes:100]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the three and six months ended December 27, 2024 and December 29, 2023.

[0001408710-25-000008:notes:101]
[same as prior period, unchanged from 0001408710-24-000040:notes:98]

[0001408710-25-000008:notes:102]
[same as prior period, unchanged from 0001408710-24-000040:notes:99]

[0001408710-25-000008:notes:103]
[same as prior period, unchanged from 0001408710-24-000040:notes:100]

[0001408710-25-000008:notes:104]
[same as prior period, unchanged from 0001408710-24-000040:notes:101]

[0001408710-25-000008:notes:105]
The following table summarizes the number of equity awards outstanding and ordinary shares available for grant under each of the Equity Incentive Plans as of December 27, 2024:

[0001408710-25-000008:notes:106]
| (share units) | Restricted Share Units outstanding |  | Performance Share Units outstanding |  | Ordinary Shares available for future grant |
| 2020 Plan | 285,740 |  |  | 120,916 |  |  | 1,592,062 |  |
| 2017 Inducement Plan | — |  |  | — |  |  | 111,347 |  |
| Total | 285,740 |  |  | 120,916 |  |  | 1,703,409 |  |

[0001408710-25-000008:notes:107]
[same as prior period, unchanged from 0001408710-24-000040:notes:104]

[0001408710-25-000008:notes:108]
[same as prior period, unchanged from 0001408710-24-000040:notes:105]

[0001408710-25-000008:notes:109]
[same as prior period, unchanged from 0001408710-24-000040:notes:106]

[0001408710-25-000008:notes:110]
[same as prior period, unchanged from 0001408710-24-000040:notes:107]

[0001408710-25-000008:notes:111]
[same as prior period, unchanged from 0001408710-24-000040:notes:108]

[0001408710-25-000008:notes:112]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 28, 2024 | 306,660 |  |  | $ | 129.01 |  |
| Granted | 107,026 |  |  | $ | 260.95 |  |
| Vested | (120,452) |  |  | $ | 114.39 |  |
| Forfeited | (7,494) |  |  | $ | 151.56 |  |
| Balance as of December 27, 2024 | 285,740 |  |  | $ | 184.00 |  |

[0001408710-25-000008:notes:113]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 30, 2023 | 368,765 |  |  | $ | 97.49 |  |
| Granted | 114,159 |  |  | $ | 160.54 |  |
| Vested | (145,067) |  |  | $ | 86.07 |  |
| Forfeited | (10,093) |  |  | $ | 120.71 |  |
| Balance as of December 29, 2023 | 327,764 |  |  | $ | 123.79 |  |

[0001408710-25-000008:notes:114]
[same as prior period, unchanged from 0001408710-24-000040:notes:111]

[0001408710-25-000008:notes:115]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 28, 2024 | 171,078 |  |  | $ | 135.31 |  |
| Granted | 46,980 |  |  | $ | 261.84 |  |
| Vested | (97,142) |  |  | $ | 117.35 |  |
| Forfeited | — |  |  | $ | — |  |
| Balance as of December 27, 2024 | 120,916 |  |  | $ | 198.90 |  |

[0001408710-25-000008:notes:116]
|  | NumberofShares |  | Weighted-Average GrantDate Fair ValuePer Share |
| Balance as of June 30, 2023 | 204,016 |  |  | $ | 108.81 |  |
| Granted | 73,936 |  |  | $ | 158.91 |  |
| Vested | (106,874) |  |  | 101.05 |  |
| Forfeited | — |  |  | $ | — |  |
| Balance as of December 29, 2023 | 171,078 |  |  | $ | 135.31 |  |

[0001408710-25-000008:notes:117]
As of December 27, 2024, there was $27.3 million and $13.2 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the Equity Incentive Plans that is expected to be recorded over a weighted-average period of 2.8 and 1.3 years, respectively.

[0001408710-25-000008:notes:118]
For the six months ended December 27, 2024 and December 29, 2023, the Company withheld an aggregate of 89,868 shares and 100,763 shares, respectively, upon the vesting of restricted share units and performance shares units, based upon the closing share price on the vesting date to settle employee tax withholding obligations. For the six months ended December 27, 2024 and December 29, 2023, the Company then remitted cash of $20.7 million and $12.4 million, respectively, to the appropriate taxing authorities and presented it as a financing activity within the unaudited condensed consolidated statements of cash flows. The payment was recorded as a reduction of additional paid-in capital.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001408710-25-000008:notes:119]
[same as prior period, unchanged from 0001408710-24-000040:notes:116]

[0001408710-25-000008:notes:120]
[same as prior period, unchanged from 0001408710-24-000040:notes:117]

[0001408710-25-000008:notes:121]
For the three and six months ended December 27, 2024, Fabrinet issued 5,329 and 127,726 ordinary shares, respectively, upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-25-000008:notes:122]
For the three and six months ended December 29, 2023, Fabrinet issued 4,384 and 151,178 ordinary shares, respectively, upon the vesting of restricted share units and performance share units under the Equity Incentive Plans, net of shares withheld.

[0001408710-25-000008:notes:123]
[same as prior period, unchanged from 0001408710-24-000040:notes:120]

[0001408710-25-000008:notes:124]
[same as prior period, unchanged from 0001408710-24-000040:notes:121]

[0001408710-25-000008:notes:125]
[same as prior period, unchanged from 0001408710-24-000040:notes:122]

[0001408710-25-000008:notes:126]
During the six months ended December 27, 2024, 291,780 shares were repurchased under the program, at an average price per share (excluding other direct costs) of $235.43, for an aggregate purchase price of $68.7 million. As of December 27, 2024, the Company had a remaining authorization to repurchase up to $131.3 million worth of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001408710-25-000008:notes:127]
Accumulated other comprehensive income (loss)
The changes in AOCI for the six months ended December 27, 2024 and December 29, 2023 were as follows:

[0001408710-25-000008:notes:128]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  |  |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 28, 2024 | $ | (1,179) |  |  | $ | (980) |  |  |  |  | $ | (982) |  |  | $ | (3,141) |  |
| Other comprehensive income (loss) before reclassification | 6,297 |  |  | (57) |  |  |  |  | 76 |  |  | 6,316 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | — |  |  | (898) |  |  |  |  | — |  |  | (898) |  |
| Tax effects | — |  |  | 72 |  |  |  |  | — |  |  | 72 |  |
| Other comprehensive income (loss) | $ | 6,297 |  |  | $ | (883) |  |  |  |  | $ | 76 |  |  | $ | 5,490 |  |
| Balance as of December 27, 2024 | $ | 5,118 |  |  | $ | (1,863) |  |  |  |  | $ | (906) |  |  | $ | 2,349 |  |

[0001408710-25-000008:notes:129]
| (in thousands) | Unrealized net(Losses)/Gains onAvailable-for-saleSecurities |  | Unrealized net(Losses)/Gainson DerivativeInstruments |  | Retirementbenefit plan -Prior servicecost |  | ForeignCurrencyTranslationAdjustment |  | Total |
| Balance as of June 30, 2023 | $ | (3,279) |  |  | $ | (3,541) |  |  | $ | (330) |  |  | $ | (965) |  |  | $ | (8,115) |  |
| Other comprehensive income (loss) before reclassification | 3,893 |  |  | 9,401 |  |  | — |  |  | (106) |  |  | 13,188 |  |
| Amounts reclassified out of AOCI to the unaudited condensed consolidated statements of operations and comprehensive income | 1 |  |  | (1,765) |  |  | 158 |  |  | — |  |  | (1,606) |  |
| Tax effects | — |  |  | 754 |  |  | (24) |  |  | — |  |  | 730 |  |
| Other comprehensive income (loss) | $ | 3,894 |  |  | $ | 8,390 |  |  | $ | 134 |  |  | $ | (106) |  |  | $ | 12,312 |  |
| Balance as of December 29, 2023 | $ | 615 |  |  | $ | 4,849 |  |  | $ | (196) |  |  | $ | (1,071) |  |  | $ | 4,197 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001408710-25-000008:notes:130]
Commitments and contingencies
Bank guarantees

[0001408710-25-000008:notes:131]
As of December 27, 2024 and June 28, 2024, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.2 million and $2.0 million, respectively, or Thai baht 75.7 million and 73.2 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the subsidiary's operations related to the Israeli Customs department.

[0001408710-25-000008:notes:132]
Purchase obligations

[0001408710-25-000008:notes:133]
Purchase obligations represent legally binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001408710-25-000008:notes:134]
As of December 27, 2024, the Company had purchase obligations and other commitments to third parties of $1.27 billion.

[0001408710-25-000008:notes:135]
Capital expenditures

[0001408710-25-000008:notes:136]
As of December 27, 2024, the Company had total capital expenditure commitments to third parties of $45.2 million.

[0001408710-25-000008:notes:137]
Indemnification of directors and officers

[0001408710-25-000008:notes:138]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001408710-25-000008:notes:139]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.

[0001408710-25-000008:notes:140]
Credit facility agreement

[0001408710-25-000008:notes:141]
On March 9, 2023, Fabrinet Thailand and the Parent Company (collectively, the “Borrowers”) and the Bank of Ayudhya Public Company Limited (the "Bank") entered into a credit facility agreement (the “2023 Credit Facility Agreement”), which provided a facility of $55.0 million.

[0001408710-25-000008:notes:142]
During the three months ended December 27, 2024, the Borrowers and the Bank amended the 2023 Credit Facility Agreement to reduce the facility to $30.0 million, which may be used for, among other things, an overdraft facility.

[0001408710-25-000008:notes:143]
As of December 27, 2024, there was no amount outstanding under the 2023 Credit Facility Agreement.

[0001408710-25-000008:notes:144]
Under the 2023 Credit Facility Agreement, the Borrowers are required to maintain a debt-to-equity ratio of less than or equal to 1.5 times for Fabrinet Thailand and 1.0 times for the Parent Company.

[0001408710-25-000008:notes:145]
As of December 27, 2024, the Borrowers were in compliance with all of their financial covenants under the 2023 Credit Facility Agreement.

[0001408710-25-000008:notes:146]
Litigation and claim

[0001408710-25-000008:notes:147]
On June 28, 2024, Ngan In Leng and First Laser Limited (collectively, the “Plaintiffs”) filed a complaint in the Fuzhou Intermediate People’s Court (the “Court”) in Fuzhou, China against Fujian Enterprises (Holdings) Co., Ltd. (“FEHC”), Jian An Investment Limited (“Jian”), and Casix, Inc. (“Casix”), the Company's wholly-owned subsidiary located in the PRC. The complaint alleges unjust enrichment related to a purported investment in Casix by the Plaintiffs in 1997, which predates the Company's acquisition of Casix from JDS Uniphase Corporation. The Plaintiffs have requested that the Court order FEHC to return the unjust enrichment to the Plaintiffs in the amount of RMB 400 million, with interest from March 1, 2000, and order Jian and Casix to bear joint and several liability for all payment obligations of FEHC.

[0001408710-25-000008:notes:148]
In September 2024, the Court dismissed the lawsuit in its entirety based on jurisdictional grounds. The Plaintiffs have since appealed the Court’s ruling to the High People's Court of Fujian Province (the "Appellate Court"). In their appeal, the

[0001408710-25-000008:notes:149]
Plaintiffs now claim that Casix is the primary obligor to return the alleged unjust enrichment to the Plaintiffs. On November 24, 2024, the Appellate Court agreed to hear the appeal. At this time, the Company is not able to quantify any potential liability in connection with this litigation due to its pending status and preliminary nature.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001408710-25-000008:notes:150]
Business segments and geographic information
Operating segments are defined as components of an enterprise that engage in business activities for which discrete financial information is available that is evaluated regularly by the chief operating decision maker (the “CODM”) in deciding how to allocate resources and in assessing performance. The Company’s CODM is Fabrinet’s Chief Executive Officer. As of December 27, 2024, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001408710-25-000008:notes:151]
[same as prior period, unchanged from 0001408710-24-000040:notes:147]

[0001408710-25-000008:notes:152]
[same as prior period, unchanged from 0001408710-24-000040:notes:148]

[0001408710-25-000008:notes:153]
| (in thousands) |  | December 27,2024 |  | June 28,2024 |
| Long-Lived Assets: |  |  |  |  |
| Thailand |  | $ | 279,268 |  |  | $ | 261,141 |  |
| U.S. |  | 28,378 |  |  | 28,914 |  |
| China |  | 14,004 |  |  | 14,586 |  |
| Israel |  | 1,569 |  |  | 2,160 |  |
| Others |  | 429 |  |  | 439 |  |
| Total |  | $ | 323,648 |  |  | $ | 307,240 |  |

[0001408710-25-000008:notes:154]
[same as prior period, unchanged from 0001408710-24-000040:notes:150]

[0001408710-25-000008:notes:155]
The Company had three customers that each contributed to 10% or more of the Company's total trade accounts receivable as of December 27, 2024 and June 28, 2024.

[0001408710-25-000008:notes:156]
During the six months ended December 27, 2024 and December 29, 2023, the Company had two customers and three customers, respectively, that each contributed 10% or more of the Company's revenues. Such customers together accounted for 50.5% and 53.9% of the Company revenues during the respective periods.


## us-gaap:SubsequentEventsTextBlock

[0001408710-25-000008:notes:157]
Subsequent event
In January 2025, the Company’s board of directors approved the repurchase of up to an additional $100.0 million of the Company’s outstanding ordinary shares, bringing the aggregate authorization under the Company’s existing share repurchase program to $534.3 million.
