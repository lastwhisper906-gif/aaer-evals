# FN note change history — 0001408710-24-000040 → 0001408710-25-000008


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-02-04):
[0001408710-25-000008:note_history:1]
As of December 27, 2024 and June 28, 2024, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.2 million and $2.0 million, respectively, or Thai baht 75.7 million and 73.2 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the subsidiary's operations related to the Israeli Customs department.
  (was, 2024-11-05, similarity 0.9925):
[0001408710-24-000040:note_history:1]
As of September 27, 2024 and June 28, 2024, there were outstanding bank guarantees on behalf of the Company's subsidiary in Thailand for electricity usage and other normal business expenses totaling $2.3 million and $2.0 million, respectively, or Thai baht 75.7 million and 73.2 million, respectively. In addition, there were other immaterial bank guarantees on behalf of the Company's subsidiary in Israel to support the subsidiary's operations related to the Israeli Customs department.

- changed (2025-02-04):
[0001408710-25-000008:note_history:2]
As of December 27, 2024, the Company had purchase obligations and other commitments to third parties of $1.27 billion.
  (was, 2024-11-05, similarity 0.9772):
[0001408710-24-000040:note_history:2]
As of September 27, 2024, the Company had purchase obligations and other commitments to third parties of $1.11 billion.

- changed (2025-02-04):
[0001408710-25-000008:note_history:3]
As of December 27, 2024, the Company had total capital expenditure commitments to third parties of $45.2 million.
  (was, 2024-11-05, similarity 0.9761):
[0001408710-24-000040:note_history:3]
As of September 27, 2024, the Company had total capital expenditure commitments to third parties of $21.3 million.

- changed (2025-02-04):
[0001408710-25-000008:note_history:4]
During the three months ended December 27, 2024, the Borrowers and the Bank amended the 2023 Credit Facility Agreement to reduce the facility to $30.0 million, which may be used for, among other things, an overdraft facility.
  (was, 2024-11-05, similarity 0.7321):
[0001408710-24-000040:note_history:4]
During the three months ended September 27, 2024, the Borrowers and the Bank agreed to amend the 2023 Credit Facility Agreement to reduce the facility to $30.0 million, which may be used for, among other things, an overdraft facility. The Company expects to finalize the amendment to the 2023 Credit Facility Agreement during the three months ending December 27, 2024.

- changed (2025-02-04):
[0001408710-25-000008:note_history:5]
As of December 27, 2024, there was no amount outstanding under the 2023 Credit Facility Agreement.
  (was, 2024-11-05, similarity 0.9721):
[0001408710-24-000040:note_history:5]
As of September 27, 2024, there was no amount outstanding under the 2023 Credit Facility Agreement.

- changed (2025-02-04):
[0001408710-25-000008:note_history:6]
As of December 27, 2024, the Borrowers were in compliance with all of their financial covenants under the 2023 Credit Facility Agreement.
  (was, 2024-11-05, similarity 0.9805):
[0001408710-24-000040:note_history:6]
As of September 27, 2024, the Borrowers were in compliance with all of their financial covenants under the 2023 Credit Facility Agreement.

- added (2025-02-04):
[0001408710-25-000008:note_history:7]
In September 2024, the Court dismissed the lawsuit in its entirety based on jurisdictional grounds. The Plaintiffs have since appealed the Court’s ruling to the High People's Court of Fujian Province (the "Appellate Court"). In their appeal, the

- added (2025-02-04):
[0001408710-25-000008:note_history:8]
Plaintiffs now claim that Casix is the primary obligor to return the alleged unjust enrichment to the Plaintiffs. On November 24, 2024, the Appellate Court agreed to hear the appeal. At this time, the Company is not able to quantify any potential liability in connection with this litigation due to its pending status and preliminary nature.

- removed (2025-02-04):
[0001408710-24-000040:note_history:9]
In September 2024, the Court dismissed the lawsuit in its entirety based on jurisdictional grounds. The Plaintiffs have since appealed the Court's ruling to the High People's Court of Fujian Province (the "Appellate Court"). In their appeal, the Plaintiffs now claim that Casix is the primary obligor to return the alleged unjust enrichment to the Plaintiffs. The matter is currently pending before the Appellate Court. At this time, the Company is not able to quantify any potential liability in connection with this litigation due to its pending status and preliminary nature.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-02-04):
[0001408710-25-000008:note_history:10]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of December 27, 2024 and for the three and six months ended December 27, 2024 and December 29, 2023 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 28, 2024.
  (was, 2024-11-05, similarity 0.9669):
[0001408710-24-000040:note_history:10]
The accompanying unaudited condensed consolidated financial statements for Fabrinet as of September 27, 2024 and for the three months ended September 27, 2024 and September 29, 2023 include normal recurring adjustments necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP” or "GAAP") for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 28, 2024.

- changed (2025-02-04):
[0001408710-25-000008:note_history:11]
The results for the three and six months ended December 27, 2024 may not be indicative of results for the year ending June 27, 2025 or any future periods.
  (was, 2024-11-05, similarity 0.9537):
[0001408710-24-000040:note_history:11]
The results for the three months ended September 27, 2024 may not be indicative of results for the year ending June 27, 2025 or any future periods.

- changed (2025-02-04):
[0001408710-25-000008:note_history:12]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended December 27, 2024 and December 29, 2023 consisted of 13 weeks. Fiscal year 2025 will comprise 52 weeks and will end on June 27, 2025.
  (was, 2024-11-05, similarity 0.9692):
[0001408710-24-000040:note_history:12]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended September 27, 2024 and September 29, 2023 consisted of 13 weeks. Fiscal year 2025 will comprise 52 weeks and will end on June 27, 2025.

- changed (2025-02-04):
[0001408710-25-000008:note_history:13]
In November 2023, the Financial Accounting Standards Board ("FASB") issued ASU 2023-07, “Segment Reporting (Topic 280), Improvements to Reportable Segment Disclosures,” which is intended to improve reportable segment disclosure requirements, primarily through additional disclosures about significant segment expenses. This ASU is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. This ASU is effective for the Company's annual periods beginning June 29, 2024, and interim periods beginning June 28, 2025, and will be applied retrospectively to all prior periods presented in the financial statements. The Company is currently evaluating the ASU to determine its impact on the Company's disclosures.
  (was, 2024-11-05, similarity 0.6926):
[0001408710-24-000040:note_history:13]
In November 2023, the Financial Accounting Standards Board ("FASB") issued ASU 2023-07, “Segment Reporting (Topic 280), Improvements to Reportable Segment Disclosures,” which is intended to improve reportable segment disclosure requirements, primarily through additional disclosures about significant segment expenses. This ASU is effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, with early adoption permitted. This ASU is effective for the Company's annual periods beginning June 29, 2024, and interim periods beginning June 28, 2025, and will be applied retrospectively to all prior periods presented in the financial statements. The Company is currently evaluating the ASU to determine its impact on the Company's disclosures.
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740), Improvements to Income Tax Disclosures,” which requires more detailed income tax disclosures. This ASU requires entities to disclose disaggregated information about their effective tax rate reconciliation as well as expanded information on income taxes paid by jurisdiction. This ASU is effective for all entities for fiscal years beginning after December 15, 2024, with early adoption permitted for annual financial statements that have not yet been issued or made available for issuance. This ASU will be effective for the Company in the first quarter of fiscal year 2026. The Company is currently assessing the impact to its disclosures.

- added (2025-02-04):
[0001408710-25-000008:note_history:14]
In December 2023, the FASB issued ASU 2023-09, “Income Taxes (Topic 740), Improvements to Income Tax Disclosures,” which requires more detailed income tax disclosures. This ASU requires entities to disclose disaggregated information about their effective tax rate reconciliation as well as expanded information on income taxes paid by jurisdiction. This ASU is effective for all entities for fiscal years beginning after December 15, 2024, with early adoption permitted for annual financial statements that have not yet been issued or made available for issuance. This ASU will be effective for the Company beginning with fiscal year 2026. The Company is currently assessing the impact to its disclosures.

- added (2025-02-04):
[0001408710-25-000008:note_history:15]
In November 2024, the FASB issued ASU 2024-03, “Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), Disaggregation of Income Statement Expenses,” which requires additional notes to financial statements. This ASU requires entities to include certain current disclosures in the same tabular format disclosure as the other disaggregation requirements in the amendments in this ASU. This ASU is effective for all entities for fiscal years beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027, with early adoption permitted. This ASU is effective for the Company's annual periods beginning June 26, 2027, and interim periods beginning July 1, 2028, and will be applied retrospectively to all prior periods presented in the financial statements. The Company is currently evaluating the ASU to determine its impact on the Company's disclosures.

- removed (2025-02-04):
[0001408710-24-000040:note_history:16]
Adoption of New Accounting Standards

- removed (2025-02-04):
[0001408710-24-000040:note_history:17]
No new accounting standard was adopted during the three months ended September 27, 2024.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-02-04):
[0001408710-25-000008:note_history:18]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of December 27, 2024 and June 28, 2024:
  (was, 2024-11-05, similarity 0.9829):
[0001408710-24-000040:note_history:18]
The following table summarizes the cost and estimated fair value of short-term investments classified as available-for-sale securities based on stated effective maturities as of September 27, 2024 and June 28, 2024:

- changed (2025-02-04):
[0001408710-25-000008:note_history:19]
|  | December 27, 2024 |  | June 28, 2024 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 122,647 |  |  | $ | 124,479 |  |  | $ | 110,671 |  |  | $ | 110,669 |  |
| Due between one to five years | 403,191 |  |  | 406,490 |  |  | 339,136 |  |  | 337,961 |  |
| Total | $ | 525,838 |  |  | $ | 530,969 |  |  | $ | 449,807 |  |  | $ | 448,630 |  |
  (was, 2024-11-05, similarity 0.9884):
[0001408710-24-000040:note_history:19]
|  | September 27, 2024 |  | June 28, 2024 |
| (in thousands) | CarryingCost |  | Fair Value |  | CarryingCost |  | Fair Value |
| Due within one year | $ | 112,061 |  |  | $ | 113,287 |  |  | $ | 110,671 |  |  | $ | 110,669 |  |
| Due between one to five years | 390,491 |  |  | 394,906 |  |  | 339,136 |  |  | 337,961 |  |
| Total | $ | 502,552 |  |  | $ | 508,193 |  |  | $ | 449,807 |  |  | $ | 448,630 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-02-04):
[0001408710-25-000008:note_history:20]
| (in thousands, except percentages) | Three Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 371,112 |  |  |  |  | $ | 678,932 |  |  |  |
| Others (1) | 1,291 |  |  |  |  | 2,949 |  |  |  |
| Total revenue in North America | 372,403 |  |  | 44.7 | % |  | 681,881 |  |  | 41.6 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 240,671 |  |  |  |  | 531,624 |  |  |  |
| India | 75,629 |  |  |  |  | 152,459 |  |  |  |
| Hong Kong | 20,415 |  |  |  |  | 38,962 |  |  |  |
| Thailand | 14,069 |  |  |  |  | 25,190 |  |  |  |
| China | 13,650 |  |  |  |  | 25,522 |  |  |  |
| Singapore | 12,481 |  |  |  |  | 23,244 |  |  |  |
| Japan | 8,976 |  |  |  |  | 17,555 |  |  |  |
| Malaysia | 7,565 |  |  |  |  | 15,063 |  |  |  |
| Others | 726 |  |  |  |  | 1,201 |  |  |  |
| Total revenue in Asia-Pacific and others | 394,182 |  |  | 47.3 | % |  | 830,820 |  |  | 50.7 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 39,262 |  |  |  |  | 71,712 |  |  |  |
| Germany | 10,867 |  |  |  |  | 20,211 |  |  |  |
| Others | 16,894 |  |  |  |  | 33,212 |  |  |  |
| Total revenue in Europe | $ | 67,023 |  |  | 8.0 | % |  | $ | 125,135 |  |  | 7.7 | % |
| Total revenue | $ | 833,608 |  |  | 100.0 | % |  | $ | 1,637,836 |  |  | 100.0 | % |
  (was, 2024-11-05, similarity 0.9411):
[0001408710-24-000040:note_history:20]
| (in thousands, except percentages) | Three Months EndedSeptember 27, 2024 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 29, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 307,820 |  |  |  |  | $ | 254,859 |  |  |  |
| Others (1) | 1,658 |  |  |  |  | 3,460 |  |  |  |
| Total revenue in North America | 309,478 |  |  | 38.5 | % |  | 258,319 |  |  | 37.7 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 290,953 |  |  |  |  | 210,676 |  |  |  |
| India | 76,830 |  |  |  |  | 70,777 |  |  |  |
| Hong Kong | 18,547 |  |  |  |  | 15,788 |  |  |  |
| China | 11,872 |  |  |  |  | 20,260 |  |  |  |
| Thailand | 11,121 |  |  |  |  | 13,027 |  |  |  |
| Singapore | 10,763 |  |  |  |  | 683 |  |  |  |
| Malaysia | 7,498 |  |  |  |  | 33,319 |  |  |  |
| Others | 9,054 |  |  |  |  | 7,292 |  |  |  |
| Total revenue in Asia-Pacific and others | 436,638 |  |  | 54.3 | % |  | 371,822 |  |  | 54.2 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 32,450 |  |  |  |  | 29,774 |  |  |  |
| Germany | 9,344 |  |  |  |  | 12,780 |  |  |  |
| Others | 16,318 |  |  |  |  | 12,782 |  |  |  |
| Total revenue in Europe | $ | 58,112 |  |  | 7.2 | % |  | $ | 55,336 |  |  | 8.1 | % |
| Total revenue | $ | 804,228 |  |  | 100.0 | % |  | $ | 685,477 |  |  | 100.0 | % |

- added (2025-02-04):
[0001408710-25-000008:note_history:21]
| (in thousands, except percentages) | Three Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |  | Six Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 238,288 |  |  |  |  | $ | 493,147 |  |  |  |
| Others (1) | 3,331 |  |  |  |  | 6,791 |  |  |  |
| Total revenue in North America | 241,619 |  |  | 33.9 | % |  | 499,938 |  |  | 35.8 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 267,038 |  |  |  |  | 477,714 |  |  |  |
| India | 75,033 |  |  |  |  | 145,810 |  |  |  |
| Malaysia | 36,626 |  |  |  |  | 69,945 |  |  |  |
| China | 21,262 |  |  |  |  | 41,522 |  |  |  |
| Hong Kong | 12,150 |  |  |  |  | 27,938 |  |  |  |
| Thailand | 10,403 |  |  |  |  | 23,430 |  |  |  |
| Japan | 5,826 |  |  |  |  | 12,636 |  |  |  |
| Others | 1,570 |  |  |  |  | 2,735 |  |  |  |
| Total revenue in Asia-Pacific and others | 429,908 |  |  | 60.3 | % |  | 801,730 |  |  | 57.3 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 18,870 |  |  |  |  | 48,644 |  |  |  |
| Germany | 10,395 |  |  |  |  | 23,175 |  |  |  |
| Others | 11,902 |  |  |  |  | 24,684 |  |  |  |
| Total revenue in Europe | $ | 41,167 |  |  | 5.8 | % |  | $ | 96,503 |  |  | 6.9 | % |
| Total revenue | $ | 712,694 |  |  | 100.0 | % |  | $ | 1,398,171 |  |  | 100.0 | % |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-02-04):
[0001408710-25-000008:note_history:22]
As of December 27, 2024 and June 28, 2024, the Company's contract assets were de minimis.
  (was, 2024-11-05, similarity 0.9682):
[0001408710-24-000040:note_history:22]
As of September 27, 2024 and June 28, 2024, the Company's contract assets were de minimis.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-02-04):
[0001408710-25-000008:note_history:23]
| (in thousands, except percentages) | Three Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 371,112 |  |  |  |  | $ | 678,932 |  |  |  |
| Others (1) | 1,291 |  |  |  |  | 2,949 |  |  |  |
| Total revenue in North America | 372,403 |  |  | 44.7 | % |  | 681,881 |  |  | 41.6 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 240,671 |  |  |  |  | 531,624 |  |  |  |
| India | 75,629 |  |  |  |  | 152,459 |  |  |  |
| Hong Kong | 20,415 |  |  |  |  | 38,962 |  |  |  |
| Thailand | 14,069 |  |  |  |  | 25,190 |  |  |  |
| China | 13,650 |  |  |  |  | 25,522 |  |  |  |
| Singapore | 12,481 |  |  |  |  | 23,244 |  |  |  |
| Japan | 8,976 |  |  |  |  | 17,555 |  |  |  |
| Malaysia | 7,565 |  |  |  |  | 15,063 |  |  |  |
| Others | 726 |  |  |  |  | 1,201 |  |  |  |
| Total revenue in Asia-Pacific and others | 394,182 |  |  | 47.3 | % |  | 830,820 |  |  | 50.7 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 39,262 |  |  |  |  | 71,712 |  |  |  |
| Germany | 10,867 |  |  |  |  | 20,211 |  |  |  |
| Others | 16,894 |  |  |  |  | 33,212 |  |  |  |
| Total revenue in Europe | $ | 67,023 |  |  | 8.0 | % |  | $ | 125,135 |  |  | 7.7 | % |
| Total revenue | $ | 833,608 |  |  | 100.0 | % |  | $ | 1,637,836 |  |  | 100.0 | % |
  (was, 2024-11-05, similarity 0.9411):
[0001408710-24-000040:note_history:23]
| (in thousands, except percentages) | Three Months EndedSeptember 27, 2024 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 29, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 307,820 |  |  |  |  | $ | 254,859 |  |  |  |
| Others (1) | 1,658 |  |  |  |  | 3,460 |  |  |  |
| Total revenue in North America | 309,478 |  |  | 38.5 | % |  | 258,319 |  |  | 37.7 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 290,953 |  |  |  |  | 210,676 |  |  |  |
| India | 76,830 |  |  |  |  | 70,777 |  |  |  |
| Hong Kong | 18,547 |  |  |  |  | 15,788 |  |  |  |
| China | 11,872 |  |  |  |  | 20,260 |  |  |  |
| Thailand | 11,121 |  |  |  |  | 13,027 |  |  |  |
| Singapore | 10,763 |  |  |  |  | 683 |  |  |  |
| Malaysia | 7,498 |  |  |  |  | 33,319 |  |  |  |
| Others | 9,054 |  |  |  |  | 7,292 |  |  |  |
| Total revenue in Asia-Pacific and others | 436,638 |  |  | 54.3 | % |  | 371,822 |  |  | 54.2 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 32,450 |  |  |  |  | 29,774 |  |  |  |
| Germany | 9,344 |  |  |  |  | 12,780 |  |  |  |
| Others | 16,318 |  |  |  |  | 12,782 |  |  |  |
| Total revenue in Europe | $ | 58,112 |  |  | 7.2 | % |  | $ | 55,336 |  |  | 8.1 | % |
| Total revenue | $ | 804,228 |  |  | 100.0 | % |  | $ | 685,477 |  |  | 100.0 | % |

- added (2025-02-04):
[0001408710-25-000008:note_history:24]
| (in thousands, except percentages) | Three Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |  | Six Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |
| North America |  |  |  |  |  |  |  |
| U.S. | $ | 238,288 |  |  |  |  | $ | 493,147 |  |  |  |
| Others (1) | 3,331 |  |  |  |  | 6,791 |  |  |  |
| Total revenue in North America | 241,619 |  |  | 33.9 | % |  | 499,938 |  |  | 35.8 | % |
| Asia-Pacific and others |  |  |  |  |  |  |  |
| Israel | 267,038 |  |  |  |  | 477,714 |  |  |  |
| India | 75,033 |  |  |  |  | 145,810 |  |  |  |
| Malaysia | 36,626 |  |  |  |  | 69,945 |  |  |  |
| China | 21,262 |  |  |  |  | 41,522 |  |  |  |
| Hong Kong | 12,150 |  |  |  |  | 27,938 |  |  |  |
| Thailand | 10,403 |  |  |  |  | 23,430 |  |  |  |
| Japan | 5,826 |  |  |  |  | 12,636 |  |  |  |
| Others | 1,570 |  |  |  |  | 2,735 |  |  |  |
| Total revenue in Asia-Pacific and others | 429,908 |  |  | 60.3 | % |  | 801,730 |  |  | 57.3 | % |
| Europe |  |  |  |  |  |  |  |
| U.K. | 18,870 |  |  |  |  | 48,644 |  |  |  |
| Germany | 10,395 |  |  |  |  | 23,175 |  |  |  |
| Others | 11,902 |  |  |  |  | 24,684 |  |  |  |
| Total revenue in Europe | $ | 41,167 |  |  | 5.8 | % |  | $ | 96,503 |  |  | 6.9 | % |
| Total revenue | $ | 712,694 |  |  | 100.0 | % |  | $ | 1,398,171 |  |  | 100.0 | % |

- added (2025-02-04):
[0001408710-25-000008:note_history:25]
| (in thousands, except percentages) | Three Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 299,101 |  |  |  |  | $ | 627,982 |  |  |  |
| Telecom | 348,049 |  |  |  |  | 645,483 |  |  |  |
| Total revenue - Optical communications | $ | 647,150 |  |  | 77.6 | % |  | $ | 1,273,465 |  |  | 77.8 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 104,247 |  |  |  |  | $ | 206,988 |  |  |  |
| Industrial laser | 37,542 |  |  |  |  | 72,868 |  |  |  |
| Others | 44,669 |  |  |  |  | 84,515 |  |  |  |
| Total revenue - Non-optical communications | $ | 186,458 |  |  | 22.4 | % |  | $ | 364,371 |  |  | 22.2 | % |
| Total revenue | $ | 833,608 |  |  | 100.0 | % |  | $ | 1,637,836 |  |  | 100.0 | % |

- added (2025-02-04):
[0001408710-25-000008:note_history:26]
| (in thousands, except percentages) | Three Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |  | Six Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 288,121 |  |  |  |  | $ | 530,164 |  |  |  |
| Telecom | 279,813 |  |  |  |  | 571,027 |  |  |  |
| Total revenue - Optical communications | $ | 567,934 |  |  | 79.7 | % |  | $ | 1,101,191 |  |  | 78.8 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 79,172 |  |  |  |  | $ | 167,530 |  |  |  |
| Industrial laser | 30,348 |  |  |  |  | 60,263 |  |  |  |
| Others | 35,240 |  |  |  |  | 69,187 |  |  |  |
| Total revenue - Non-optical communications | $ | 144,760 |  |  | 20.3 | % |  | $ | 296,980 |  |  | 21.2 | % |
| Total revenue | $ | 712,694 |  |  | 100.0 | % |  | $ | 1,398,171 |  |  | 100.0 | % |

- changed (2025-02-04):
[0001408710-25-000008:note_history:27]
As of December 27, 2024 and June 28, 2024, the Company's contract assets were de minimis.
  (was, 2024-11-05, similarity 0.9682):
[0001408710-24-000040:note_history:27]
As of September 27, 2024 and June 28, 2024, the Company's contract assets were de minimis.

- changed (2025-02-04):
[0001408710-25-000008:note_history:28]
The following tables summarize the activity in the Company’s contract liabilities during the six months ended December 27, 2024:
  (was, 2024-11-05, similarity 0.9478):
[0001408710-24-000040:note_history:28]
The following tables summarize the activity in the Company’s contract liabilities during the three months ended September 27, 2024:

- changed (2025-02-04):
[0001408710-25-000008:note_history:29]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 28, 2024 | $ | 7,846 |  |
| Advance payments received during the period | 5,615 |  |
| Revenue recognized | (4,845) |  |
| Ending balance, December 27, 2024 | $ | 8,616 |  |
  (was, 2024-11-05, similarity 0.9834):
[0001408710-24-000040:note_history:29]
| (in thousands) | ContractLiabilities |
| Beginning balance, June 28, 2024 | $ | 7,846 |  |
| Advance payments received during the period | 2,627 |  |
| Revenue recognized | (1,550) |  |
| Ending balance, September 27, 2024 | $ | 8,923 |  |

- removed (2025-02-04):
[0001408710-24-000040:note_history:30]
| (in thousands, except percentages) | Three Months EndedSeptember 27, 2024 |  | As a % of TotalRevenues |  | Three Months EndedSeptember 29, 2023 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 328,881 |  |  |  |  | $ | 242,043 |  |  |  |
| Telecom | 297,434 |  |  |  |  | 291,214 |  |  |  |
| Total revenue - Optical communications | $ | 626,315 |  |  | 77.9 | % |  | $ | 533,257 |  |  | 77.8 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 102,741 |  |  |  |  | $ | 88,358 |  |  |  |
| Industrial laser | 35,326 |  |  |  |  | 29,915 |  |  |  |
| Others | 39,846 |  |  |  |  | 33,947 |  |  |  |
| Total revenue - Non-optical communications | $ | 177,913 |  |  | 22.1 | % |  | $ | 152,220 |  |  | 22.2 | % |
| Total revenue | $ | 804,228 |  |  | 100.0 | % |  | $ | 685,477 |  |  | 100.0 | % |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2025-02-04):
[0001408710-25-000008:note_history:31]
Subsequent event
In January 2025, the Company’s board of directors approved the repurchase of up to an additional $100.0 million of the Company’s outstanding ordinary shares, bringing the aggregate authorization under the Company’s existing share repurchase program to $534.3 million.
