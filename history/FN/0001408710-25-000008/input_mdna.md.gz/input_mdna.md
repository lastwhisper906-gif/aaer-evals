# FN MD&A — 0001408710-25-000008


## mdna

[0001408710-25-000008:mdna:1]
[same as prior period, unchanged from 0001408710-24-000040:mdna:1]

[0001408710-25-000008:mdna:2]
[same as prior period, unchanged from 0001408710-24-000040:mdna:2]

[0001408710-25-000008:mdna:3]
[same as prior period, unchanged from 0001408710-24-000040:mdna:3]

[0001408710-25-000008:mdna:4]
[same as prior period, unchanged from 0001408710-24-000040:mdna:4]

[0001408710-25-000008:mdna:5]
•our expectation that the portion of our revenues attributable to customers in regions outside of North America for the remainder of fiscal year 2025 will be in line with the portion of revenues attributable to such customers during the six months ended December 27, 2024;

[0001408710-25-000008:mdna:6]
[same as prior period, unchanged from 0001408710-24-000040:mdna:6]

[0001408710-25-000008:mdna:7]
[same as prior period, unchanged from 0001408710-24-000040:mdna:7]

[0001408710-25-000008:mdna:8]
[same as prior period, unchanged from 0001408710-24-000040:mdna:8]

[0001408710-25-000008:mdna:9]
[same as prior period, unchanged from 0001408710-24-000040:mdna:9]

[0001408710-25-000008:mdna:10]
[same as prior period, unchanged from 0001408710-24-000040:mdna:10]

[0001408710-25-000008:mdna:11]
[same as prior period, unchanged from 0001408710-24-000040:mdna:11]

[0001408710-25-000008:mdna:12]
[same as prior period, unchanged from 0001408710-24-000040:mdna:12]

[0001408710-25-000008:mdna:13]
[same as prior period, unchanged from 0001408710-24-000040:mdna:13]

[0001408710-25-000008:mdna:14]
[same as prior period, unchanged from 0001408710-24-000040:mdna:14]

[0001408710-25-000008:mdna:15]
[same as prior period, unchanged from 0001408710-24-000040:mdna:15]

[0001408710-25-000008:mdna:16]
[same as prior period, unchanged from 0001408710-24-000040:mdna:16]

[0001408710-25-000008:mdna:17]
[same as prior period, unchanged from 0001408710-24-000040:mdna:17]

[0001408710-25-000008:mdna:18]
[same as prior period, unchanged from 0001408710-24-000040:mdna:18]

[0001408710-25-000008:mdna:19]
[same as prior period, unchanged from 0001408710-24-000040:mdna:19]

[0001408710-25-000008:mdna:20]
[same as prior period, unchanged from 0001408710-24-000040:mdna:20]

[0001408710-25-000008:mdna:21]
[same as prior period, unchanged from 0001408710-24-000040:mdna:21]

[0001408710-25-000008:mdna:22]
[same as prior period, unchanged from 0001408710-24-000040:mdna:22]

[0001408710-25-000008:mdna:23]
[same as prior period, unchanged from 0001408710-24-000040:mdna:23]

[0001408710-25-000008:mdna:24]
[same as prior period, unchanged from 0001408710-24-000040:mdna:24]

[0001408710-25-000008:mdna:25]
[same as prior period, unchanged from 0001408710-24-000040:mdna:25]

[0001408710-25-000008:mdna:26]
[same as prior period, unchanged from 0001408710-24-000040:mdna:26]

[0001408710-25-000008:mdna:27]
[same as prior period, unchanged from 0001408710-24-000040:mdna:27]

[0001408710-25-000008:mdna:28]
[same as prior period, unchanged from 0001408710-24-000040:mdna:28]

[0001408710-25-000008:mdna:29]
[same as prior period, unchanged from 0001408710-24-000040:mdna:29]

[0001408710-25-000008:mdna:30]
The percentage of our revenues generated from a bill-to location outside of North America decreased from 66.1% in the three months ended December 29, 2023 to 55.3% in the three months ended December 27, 2024, primarily because of an increase in revenue from a customer in the United States.

[0001408710-25-000008:mdna:31]
The percentage of our revenues generated from a bill-to location outside of North America decreased from 64.2% in the six months ended December 29, 2023 to 58.4% in the six months ended December 27, 2024, primarily because of an increase in revenue from a customer in the United States.

[0001408710-25-000008:mdna:32]
Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside North America for the remainder of fiscal year 2025 will be in line with the portion of revenues attributable to such customers during the six months ended December 27, 2024.

[0001408710-25-000008:mdna:33]
[same as prior period, unchanged from 0001408710-24-000040:mdna:32]

[0001408710-25-000008:mdna:34]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27, 2024 |  | December 29, 2023 |  | December 27, 2024 |  | December 29, 2023 |
| North America | 44.7 | % |  | 33.9 | % |  | 41.6 | % |  | 35.8 | % |
| Asia-Pacific and others | 47.3 |  |  | 60.3 |  |  | 50.7 |  |  | 57.3 |  |
| Europe | 8.0 |  |  | 5.8 |  |  | 7.7 |  |  | 6.9 |  |
|  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001408710-25-000008:mdna:35]
[same as prior period, unchanged from 0001408710-24-000040:mdna:34]

[0001408710-25-000008:mdna:36]
[same as prior period, unchanged from 0001408710-24-000040:mdna:35]

[0001408710-25-000008:mdna:37]
[same as prior period, unchanged from 0001408710-24-000040:mdna:36]

[0001408710-25-000008:mdna:38]
[same as prior period, unchanged from 0001408710-24-000040:mdna:37]

[0001408710-25-000008:mdna:39]
[same as prior period, unchanged from 0001408710-24-000040:mdna:38]

[0001408710-25-000008:mdna:40]
[same as prior period, unchanged from 0001408710-24-000040:mdna:39]

[0001408710-25-000008:mdna:41]
[same as prior period, unchanged from 0001408710-24-000040:mdna:40]

[0001408710-25-000008:mdna:42]
[same as prior period, unchanged from 0001408710-24-000040:mdna:41]

[0001408710-25-000008:mdna:43]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative and other support personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other general expenses not related to cost of revenues. In fiscal year 2025, we expect our SG&A expenses will increase compared with our fiscal year 2024 SG&A expenses, mainly due to increases in employee costs and research and development ("R&D") expenses.

[0001408710-25-000008:mdna:44]
[same as prior period, unchanged from 0001408710-24-000040:mdna:43]

[0001408710-25-000008:mdna:45]
[same as prior period, unchanged from 0001408710-24-000040:mdna:44]

[0001408710-25-000008:mdna:46]
[same as prior period, unchanged from 0001408710-24-000040:mdna:45]

[0001408710-25-000008:mdna:47]
[same as prior period, unchanged from 0001408710-24-000040:mdna:46]

[0001408710-25-000008:mdna:48]
[same as prior period, unchanged from 0001408710-24-000040:mdna:47]

[0001408710-25-000008:mdna:49]
[same as prior period, unchanged from 0001408710-24-000040:mdna:48]

[0001408710-25-000008:mdna:50]
|  | As of December 27, 2024 |  | As of June 28, 2024 |
| (in thousands, except percentages) | ForeignCurrency |  | $ |  | % |  | ForeignCurrency |  | $ |  | % |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 1,092,745 |  |  | 32,017 |  |  | 72.2 | % |  | 1,046,000 |  |  | 28,385 |  |  | 72.5 | % |
| RMB | 65,857 |  |  | 9,160 |  |  | 20.7 |  |  | 42,852 |  |  | 6,013 |  |  | 15.4 |  |
| GBP | 2,533 |  |  | 3,173 |  |  | 7.1 |  |  | 3,778 |  |  | 4,773 |  |  | 12.1 |  |
| Total |  |  | $ | 44,350 |  |  | 100.0 | % |  |  |  | $ | 39,171 |  |  | 100.0 | % |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 3,813,466 |  |  | 111,734 |  |  | 89.4 | % |  | 3,263,391 |  |  | 88,559 |  |  | 87.4 | % |
| RMB | 93,306 |  |  | 12,979 |  |  | 10.4 |  |  | 78,418 |  |  | 11,003 |  |  | 10.9 |  |
| GBP | 253 |  |  | 317 |  |  | 0.2 |  |  | 1,359 |  |  | 1,717 |  |  | 1.7 |  |
| Total |  |  | $ | 125,030 |  |  | 100.0 | % |  |  |  | $ | 101,279 |  |  | 100.0 | % |

[0001408710-25-000008:mdna:51]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable, accrued employee benefits and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of December 27, 2024, there was $146.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 28, 2024, there was $135.0 million of foreign currency forward contracts outstanding on the Thai baht payables.

[0001408710-25-000008:mdna:52]
The RMB assets represent cash and cash equivalents, trade accounts receivable, other receivables, and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable, accrued payroll, bonus and related expenses, and other payables. As of December 27, 2024 and June 28, 2024, we did not have any derivative contracts denominated in RMB.

[0001408710-25-000008:mdna:53]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable, accrued expenses, and other payables. As of December 27, 2024 and June 28, 2024, we did not have any derivative contracts denominated in GBP.

[0001408710-25-000008:mdna:54]
For the three months ended December 27, 2024 and December 29, 2023, we recorded unrealized loss of $5.1 million and unrealized gain of $2.6 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-25-000008:mdna:55]
For the six months ended December 27, 2024 and December 29, 2023, we recorded unrealized loss of $1.0 million and unrealized gain $2.9 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-25-000008:mdna:56]
[same as prior period, unchanged from 0001408710-24-000040:mdna:54]

[0001408710-25-000008:mdna:57]
[same as prior period, unchanged from 0001408710-24-000040:mdna:55]

[0001408710-25-000008:mdna:58]
[same as prior period, unchanged from 0001408710-24-000040:mdna:56]

[0001408710-25-000008:mdna:59]
[same as prior period, unchanged from 0001408710-24-000040:mdna:57]

[0001408710-25-000008:mdna:60]
[same as prior period, unchanged from 0001408710-24-000040:mdna:58]

[0001408710-25-000008:mdna:61]
[same as prior period, unchanged from 0001408710-24-000040:mdna:59]

[0001408710-25-000008:mdna:62]
[same as prior period, unchanged from 0001408710-24-000040:mdna:60]

[0001408710-25-000008:mdna:63]
[same as prior period, unchanged from 0001408710-24-000040:mdna:61]

[0001408710-25-000008:mdna:64]
[same as prior period, unchanged from 0001408710-24-000040:mdna:62]

[0001408710-25-000008:mdna:65]
In addition, the General Administration of Taxation has issued circulars concerning employee share options. Under these circulars, our employees working in the PRC who exercise share options will be subject to PRC individual income tax. Our PRC subsidiary has obligations to file documents related to employee share options with relevant tax authorities and withhold individual income taxes of those employees who exercise their share options.

[0001408710-25-000008:mdna:66]
[same as prior period, unchanged from 0001408710-24-000040:mdna:65]

[0001408710-25-000008:mdna:67]
[same as prior period, unchanged from 0001408710-24-000040:mdna:66]

[0001408710-25-000008:mdna:68]
[same as prior period, unchanged from 0001408710-24-000040:mdna:67]

[0001408710-25-000008:mdna:69]
[same as prior period, unchanged from 0001408710-24-000040:mdna:68]

[0001408710-25-000008:mdna:70]
As of December 27, 2024, the corporate income tax rates for our subsidiaries in the PRC, the U.S., the U.K. and Israel are 25%, 21%, 25% and 23%, respectively.

[0001408710-25-000008:mdna:71]
[same as prior period, unchanged from 0001408710-24-000040:mdna:70]

[0001408710-25-000008:mdna:72]
[same as prior period, unchanged from 0001408710-24-000040:mdna:71]

[0001408710-25-000008:mdna:73]
[same as prior period, unchanged from 0001408710-24-000040:mdna:72]

[0001408710-25-000008:mdna:74]
[same as prior period, unchanged from 0001408710-24-000040:mdna:73]

[0001408710-25-000008:mdna:75]
[same as prior period, unchanged from 0001408710-24-000040:mdna:74]

[0001408710-25-000008:mdna:76]
[same as prior period, unchanged from 0001408710-24-000040:mdna:75]

[0001408710-25-000008:mdna:77]
| (in thousands) | Three Months Ended |  | Six Months Ended |
| December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
| Revenues | $ | 833,608 |  |  | $ | 712,694 |  |  | $ | 1,637,836 |  |  | $ | 1,398,171 |  |
| Cost of revenues | (732,759) |  |  | (624,364) |  |  | (1,437,961) |  |  | (1,225,437) |  |
| Gross profit | 100,849 |  |  | 88,330 |  |  | 199,875 |  |  | 172,734 |  |
| Selling, general and administrative expenses | (21,206) |  |  | (19,316) |  |  | (43,237) |  |  | (39,745) |  |
| Restructuring and other related costs | (46) |  |  | — |  |  | (103) |  |  | — |  |
| Operating income | 79,597 |  |  | 69,014 |  |  | 156,535 |  |  | 132,989 |  |
| Interest income | 11,314 |  |  | 7,748 |  |  | 22,247 |  |  | 13,646 |  |
| Interest expense | — |  |  | (36) |  |  | — |  |  | (81) |  |
| Foreign exchange gain (loss), net | 4,042 |  |  | (3,788) |  |  | (3,053) |  |  | (3,373) |  |
| Other income (expense), net | (62) |  |  | (35) |  |  | (81) |  |  | (115) |  |
| Income before income taxes | 94,891 |  |  | 72,903 |  |  | 175,648 |  |  | 143,066 |  |
| Income tax expense | (8,255) |  |  | (3,793) |  |  | (11,618) |  |  | (8,867) |  |
| Net income | 86,636 |  |  | 69,110 |  |  | 164,030 |  |  | 134,199 |  |
| Other comprehensive income (loss), net of tax | (9,509) |  |  | 11,699 |  |  | 5,490 |  |  | 12,312 |  |
| Net comprehensive income | $ | 77,127 |  |  | $ | 80,809 |  |  | $ | 169,520 |  |  | $ | 146,511 |  |

[0001408710-25-000008:mdna:78]
[same as prior period, unchanged from 0001408710-24-000040:mdna:77]

[0001408710-25-000008:mdna:79]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
| Revenues | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenues | (87.9) |  |  | (87.6) |  |  | (87.8) |  |  | (87.6) |  |
| Gross profit | 12.1 |  |  | 12.4 |  |  | 12.2 |  |  | 12.4 |  |
| Selling, general and administrative expenses | (2.6) |  |  | (2.7) |  |  | (2.6) |  |  | (2.9) |  |
| Restructuring and other related costs | 0.0 |  |  | — |  |  | 0.0 |  |  | — |  |
| Operating income | 9.5 |  |  | 9.7 |  |  | 9.6 |  |  | 9.5 |  |
| Interest income | 1.4 |  |  | 1.1 |  |  | 1.3 |  |  | 1.0 |  |
| Interest expense | — |  |  | 0.0 |  |  | — |  |  | 0.0 |  |
| Foreign exchange gain (loss), net | 0.5 |  |  | (0.6) |  |  | (0.2) |  |  | (0.3) |  |
| Other income (expense), net | 0.0 |  |  | 0.0 |  |  | 0.0 |  |  | 0.0 |  |
| Income before income taxes | 11.4 |  |  | 10.2 |  |  | 10.7 |  |  | 10.2 |  |
| Income tax expense | (1.0) |  |  | (0.5) |  |  | (0.7) |  |  | (0.6) |  |
| Net income | 10.4 |  |  | 9.7 |  |  | 10.0 |  |  | 9.6 |  |
| Other comprehensive income (loss), net of tax | (1.1) |  |  | 1.6 |  |  | 0.3 |  |  | 0.9 |  |
| Net comprehensive income | 9.3 | % |  | 11.3 | % |  | 10.3 | % |  | 10.5 | % |

[0001408710-25-000008:mdna:80]
33

[0001408710-25-000008:mdna:81]
[same as prior period, unchanged from 0001408710-24-000040:mdna:80]

[0001408710-25-000008:mdna:82]
| (in thousands, except percentages) | Three Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |  | Six Months EndedDecember 27, 2024 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 299,101 |  |  |  |  | $ | 627,982 |  |  |  |
| Telecom | 348,049 |  |  |  |  | 645,483 |  |  |  |
| Total revenue - Optical communications | $ | 647,150 |  |  | 77.6 | % |  | $ | 1,273,465 |  |  | 77.8 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 104,247 |  |  |  |  | $ | 206,988 |  |  |  |
| Industrial laser | 37,542 |  |  |  |  | 72,868 |  |  |  |
| Others | 44,669 |  |  |  |  | 84,515 |  |  |  |
| Total revenue - Non-optical communications | $ | 186,458 |  |  | 22.4 | % |  | $ | 364,371 |  |  | 22.2 | % |
| Total revenue | $ | 833,608 |  |  | 100.0 | % |  | $ | 1,637,836 |  |  | 100.0 | % |

[0001408710-25-000008:mdna:83]
| (in thousands, except percentages) | Three Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |  | Six Months EndedDecember 29, 2023 |  | As a % of TotalRevenues |
| Optical communications |  |  |  |  |  |  |  |
| Datacom | $ | 288,121 |  |  |  |  | $ | 530,164 |  |  |  |
| Telecom | 279,813 |  |  |  |  | 571,027 |  |  |  |
| Total revenue - Optical communications | $ | 567,934 |  |  | 79.7 | % |  | $ | 1,101,191 |  |  | 78.8 | % |
| Non-optical communications |  |  |  |  |  |  |  |
| Automotive | $ | 79,172 |  |  |  |  | $ | 167,530 |  |  |  |
| Industrial laser | 30,348 |  |  |  |  | 60,263 |  |  |  |
| Others | 35,240 |  |  |  |  | 69,187 |  |  |  |
| Total revenue - Non-optical communications | $ | 144,760 |  |  | 20.3 | % |  | $ | 296,980 |  |  | 21.2 | % |
| Total revenue | $ | 712,694 |  |  | 100.0 | % |  | $ | 1,398,171 |  |  | 100.0 | % |

[0001408710-25-000008:mdna:84]
Comparison of Three and Six Months Ended December 27, 2024 with Three and Six Months Ended December 29, 2023

[0001408710-25-000008:mdna:85]
[same as prior period, unchanged from 0001408710-24-000040:mdna:83]

[0001408710-25-000008:mdna:86]
Our revenues increased by $120.9 million, or 17.0%, to $833.6 million for the three months ended December 27, 2024, compared with $712.7 million for the three months ended December 29, 2023. This increase was primarily due to an increase in our key customers’ demand for optical communications products. Revenues from optical communications products, which represented $647.2 million, or 77.6%, of our revenues for the three months ended December 27, 2024, increased by $79.2 million, or 13.9%, compared to the same period in the prior fiscal year, mainly due to an increase in revenues from data communication products, primarily for artificial intelligence applications, and an increase in revenues from telecommunication products during the three months ended December 27, 2024. Revenues from non-optical communications products, which represented $186.5 million, or 22.4%, of our revenues for the three months ended December 27, 2024, increased by $41.7 million, or 28.8%, compared to the same period in the prior fiscal year, primarily due to growth in automotive revenue, as short-term inventory absorption issues have substantially subsided.

[0001408710-25-000008:mdna:87]
Our revenues increased by $239.6 million, or 17.1%, to $1,637.8 million for the six months ended December 27, 2024, compared with $1,398.2 million for the six months ended December 29, 2023. This increase was primarily due to an increase in our key customers’ demand for optical communications products. Revenues from optical communications products, which represented $1,273.5 million, or 77.8%, of our revenues for the six months ended December 27, 2024, increased by $172.3 million, or 15.6%, compared to the same period in the prior fiscal year, mainly due to an increase in revenues from data communication products, primarily for artificial intelligence applications, and an increase in revenues from telecommunication products during the six months ended December 27, 2024. Revenues from non-optical communications products, which represented $364.4 million, or 22.2%, of our revenues for the six months ended December 27, 2024, increased by $67.4 million, or 22.7%, compared to the same period in the prior fiscal year, primarily due to growth in automotive revenue, as short-term inventory absorption issues have substantially subsided.

[0001408710-25-000008:mdna:88]
[same as prior period, unchanged from 0001408710-24-000040:mdna:85]

[0001408710-25-000008:mdna:89]
Our cost of revenues increased by $108.4 million, or 17.4%, to $732.8 million, or 87.9% of revenues, for the three months ended December 27, 2024, compared with $624.4 million, or 87.6% of revenues, for the three months ended December 29, 2023. The increase was in line with the increase in sales volume.

[0001408710-25-000008:mdna:90]
Our cost of revenues increased by $212.6 million, or 17.3%, to $1,438.0 million, or 87.8% of revenues, for the six months ended December 27, 2024, compared with $1,225.4 million, or 87.6% of revenues, for the six months ended December 29, 2023. This increase was in line with the increase in sales volume.

[0001408710-25-000008:mdna:91]
[same as prior period, unchanged from 0001408710-24-000040:mdna:87]

[0001408710-25-000008:mdna:92]
Our gross profit increased by $12.5 million, or 14.2%, to $100.8 million, or 12.1% of revenues, for the three months ended December 27, 2024, compared with $88.3 million, or 12.4% of revenues, for the three months ended December 29, 2023. The increase was primarily due to an increase in sales volume.

[0001408710-25-000008:mdna:93]
Our gross profit increased by $27.2 million, or 15.7%, to $199.9 million, or 12.2% of revenues, for the six months ended December 27, 2024, compared with $172.7 million, or 12.4% of revenues, for the six months ended December 29, 2023. The increase was primarily due to an increase in sales volume.

[0001408710-25-000008:mdna:94]
[same as prior period, unchanged from 0001408710-24-000040:mdna:89]

[0001408710-25-000008:mdna:95]
Our SG&A expenses increased by $1.9 million, or 9.8%, to $21.2 million, or 2.6% of revenues, for the three months ended December 27, 2024, compared with $19.3 million, or 2.7% of revenues, for the three months ended December 29, 2023. The increase was primarily due to (1) an increase in executive compensation related expenses of $2.2 million, (2) an increase in R&D expenses of $0.4 million, (3) an increase in share-based compensation expenses of $0.4 million, and (4) an increase in legal expenses of $0.3 million, offset by a net decrease in allowance for expected credit losses of $1.5 million.

[0001408710-25-000008:mdna:96]
Our SG&A expenses increased by $3.5 million, or 8.8%, to $43.2 million, or 2.6% of revenues, for the six months ended December 27, 2024, compared with $39.7 million, or 2.9% of revenues, for the six months ended December 29, 2023. The increase was primarily due to (1) an increase in executive compensation related expenses of $2.6 million, (2) an increase in R&D expenses of $0.9 million, (3) an increase in severance expenses of $0.7 million, (4) an increase in legal expenses of $0.7 million, and (5) an increase in share-based compensation expenses of $0.6 million, offset by a net decrease in allowance for expected credit losses of $2.0 million.

[0001408710-25-000008:mdna:97]
[same as prior period, unchanged from 0001408710-24-000040:mdna:91]

[0001408710-25-000008:mdna:98]
Our operating income increased by $10.6 million, or 15.4%, to $79.6 million, or 9.5% of revenues, for the three months ended December 27, 2024, compared with $69.0 million, or 9.7% of revenues, for the three months ended December 29, 2023. The increase was primarily due to an increase in revenues.

[0001408710-25-000008:mdna:99]
Our operating income increased by $23.5 million, or 17.7%, to $156.5 million, or 9.6% of revenues, for the six months ended December 27, 2024, compared with $133.0 million, or 9.5% of revenues, for the six months ended December 29, 2023. The increase was primarily due to an increase in revenues.

[0001408710-25-000008:mdna:100]
[same as prior period, unchanged from 0001408710-24-000040:mdna:93]

[0001408710-25-000008:mdna:101]
Our interest income increased by $3.6 million, or 46.8%, to $11.3 million, or 1.4% of revenues, for the three months ended December 27, 2024, compared with $7.7 million, or 1.1% of revenues, for the three months ended December 29, 2023. The increase was primarily due to an increase in average cash balance and short-term investment during the three months ended December 27, 2024 compared to the same period in the prior fiscal year.

[0001408710-25-000008:mdna:102]
Our interest income increased by $8.6 million, or 63.2%, to $22.2 million, or 1.3% of revenues, for the six months ended December 27, 2024, compared with $13.6 million, or 1.0% of revenues, for the six months ended December 29, 2023. The increase was primarily due to an increase in average cash balance and short-term investment during the six months ended December 27, 2024 compared to same period in the prior fiscal year.

[0001408710-25-000008:mdna:103]
[same as prior period, unchanged from 0001408710-24-000040:mdna:95]

[0001408710-25-000008:mdna:104]
Our interest expense decreased for the three and six months ended December 27, 2024, compared with the three and six months ended December 29, 2023, due to the full repayment of our long-term loan balance.

[0001408710-25-000008:mdna:105]
[same as prior period, unchanged from 0001408710-24-000040:mdna:97]

[0001408710-25-000008:mdna:106]
We recorded foreign exchange gain, net of $4.0 million, or 0.5% of revenues, for the three months ended December 27, 2024, compared with foreign exchange loss, net of $3.8 million, or 0.6% of revenues, for the three months ended December 29, 2023. The foreign exchange gain was mainly due to (1) unrealized gain from revaluation of outstanding Thai baht assets and liabilities of $14.0 million, (2) unrealized gain from revaluation of currencies other than Thai baht of $2.0 million, and (3) lower realized gain from payment/receipt of $0.5 million, offset by (1) unrealized loss from mark-to-market forward contracts of $7.7 million, and (2) foreign exchange loss, totaling $1.0 million from our subsidiaries in the PRC and the U.K.

[0001408710-25-000008:mdna:107]
We recorded foreign exchange loss, net of $3.1 million, or 0.2% of revenues, for the six months ended December 27, 2024, compared with foreign exchange loss, net of $3.4 million, or 0.3% or revenues, for the six months ended December 29, 2023. The decrease in foreign exchange loss was mainly due to (1) lower unrealized loss from revaluation of outstanding Thai baht assets and liabilities of $2.8 million, and (2) unrealized gain from revaluation of currencies other than Thai baht of $1.6 million, offset by (1) unrealized loss from mark-to-market forward contracts of $3.9 million, and (2) higher realized loss from payment/receipt of $0.2 million.

[0001408710-25-000008:mdna:108]
[same as prior period, unchanged from 0001408710-24-000040:mdna:99]

[0001408710-25-000008:mdna:109]
We recorded income before income taxes of $94.9 million for the three months ended December 27, 2024, compared with $72.9 million for the three months ended December 29, 2023.

[0001408710-25-000008:mdna:110]
We recorded income before income taxes of $175.6 million for the six months ended December 27, 2024, compared with $143.1 million for the six months ended December 29, 2023.

[0001408710-25-000008:mdna:111]
[same as prior period, unchanged from 0001408710-24-000040:mdna:101]

[0001408710-25-000008:mdna:112]
Our provision for income tax reflects effective tax rates of 8.7% and 5.2% for the three months ended December 27, 2024 and December 29, 2023, respectively. The increase was due to higher income subject to tax and a discrete expense related to continuing assessment of potential tax exposures.

[0001408710-25-000008:mdna:113]
Our provision for income tax reflects effective tax rates of 6.6% and 6.2% for the six months ended December 27, 2024 and December 29, 2023, respectively. The increase was due to higher income subject to tax and a discrete expense related to a continuing assessment of potential tax exposures during the six months ended December 27, 2024, offset by a full valuation allowance for deferred tax assets that was set up during the six months ended December 29, 2023 for our subsidiary in Israel.

[0001408710-25-000008:mdna:114]
[same as prior period, unchanged from 0001408710-24-000040:mdna:103]

[0001408710-25-000008:mdna:115]
We recorded net income of $86.6 million, or 10.4% of revenues, for the three months ended December 27, 2024, compared with $69.1 million, or 9.7% of revenues, for the three months ended December 29, 2023.

[0001408710-25-000008:mdna:116]
We recorded net income of $164.0 million, or 10.0% of revenues, for the six months ended December 27, 2024, compared with $134.2 million, or 9.6% of revenues, for the six months ended December 29, 2023.

[0001408710-25-000008:mdna:117]
[same as prior period, unchanged from 0001408710-24-000040:mdna:105]

[0001408710-25-000008:mdna:118]
We recorded other comprehensive loss of $9.5 million, or 1.1% of revenues, for the three months ended December 27, 2024, compared with other comprehensive income of $11.7 million, or 1.6% of revenues, for the three months ended December 29, 2023. The change was mainly due to (1) unrealized loss from mark-to-market of forward contracts and interest rate swap agreements of $18.4 million, and (2) unrealized loss from mark-to-market of available-for-sale debt securities of $3.4 million, offset by (1) unrealized gain from foreign currency translation adjustment of $0.6 million.

[0001408710-25-000008:mdna:119]
We recorded other comprehensive income of $5.5 million, or 0.3% of revenues, for the six months ended December 27, 2024, compared with other comprehensive income of $12.3 million, or 0.9% of revenues, for the six months ended December 29, 2023. The decrease in other comprehensive income was mainly due to (1) unrealized loss from mark-to-market of forward contracts and interest rate swap agreements of $9.3 million, and (2) lower gain from retirement benefits plan of $0.1 million, offset by (1) higher unrealized gain from mark-to-market of available-for-sale debt securities of $2.4 million, and (2) unrealized gain from foreign currency translation adjustment of $0.2 million.

[0001408710-25-000008:mdna:120]
[same as prior period, unchanged from 0001408710-24-000040:mdna:107]

[0001408710-25-000008:mdna:121]
[same as prior period, unchanged from 0001408710-24-000040:mdna:108]

[0001408710-25-000008:mdna:122]
We primarily finance our operations through cash flow from operating activities. As of December 27, 2024, we had cash, cash equivalents, and short-term investments of $934.6 million and no outstanding debt. As of December 29, 2023, we had cash, cash equivalents, and short-term investments of $740.6 million and outstanding debt of $6.1 million.

[0001408710-25-000008:mdna:123]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents was 4.2% and 4.4% for the three and six months ended December 27, 2024, respectively, and 4.3% and 4.2% for the three and six months ended December 29, 2023, respectively.

[0001408710-25-000008:mdna:124]
Our cash investments are made in accordance with an investment policy approved by the audit committee of our board of directors. In general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed income securities are primarily classified as available-for-sale and are recorded at fair value. The cost of securities sold is based on the specific identification method. Unrealized gains and losses on these securities are recorded as other comprehensive income (loss) and are reported as a separate component of shareholders’ equity.

[0001408710-25-000008:mdna:125]
As of December 29, 2023, we had long-term borrowing under our credit facility agreement of $6.1 million. As of December 27, 2024, we had no outstanding balance under our credit facility agreement. To better manage our cash on hand, we held short-term investments of $531.0 million as of December 27, 2024.

[0001408710-25-000008:mdna:126]
We believe that our current cash and cash equivalents, short-term investments, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q. We also believe that our current manufacturing capacity is sufficient to meet our anticipated production requirements for at least the next few quarters. In January 2025, we began construction of a new manufacturing facility of approximately 2.0 million square feet at our Chonburi campus. The total expected cost of the project is approximately $130.4 million (Thai baht 4.45 billion).

[0001408710-25-000008:mdna:127]
[same as prior period, unchanged from 0001408710-24-000040:mdna:116]

[0001408710-25-000008:mdna:128]
|  | Six Months Ended |
| (in thousands) | December 27, 2024 |  | December 29, 2023 |
| Net cash provided by operating activities | $ | 199,086 |  |  | $ | 229,214 |  |
| Net cash used in investing activities | $ | (116,074) |  |  | $ | (101,853) |  |
| Net cash used in financing activities | $ | (89,414) |  |  | $ | (24,818) |  |
| Net increase in cash and cash equivalents | $ | (6,402) |  |  | $ | 102,543 |  |

[0001408710-25-000008:mdna:129]
[same as prior period, unchanged from 0001408710-24-000040:mdna:118]

[0001408710-25-000008:mdna:130]
Cash provided by operating activities is net income adjusted for certain non-cash items and changes in certain assets and liabilities. The decrease in cash provided by operating activities during the six months ended December 27, 2024 as compared to the six months ended December 29, 2023 was primarily due to (1) a change in inventories of $130.8 million due to new products and higher sales volume, and (2) a decrease in cash receipts related to the timing collection of trade receivables of $33.3 million, offset by (1) an increase in trade payables of $95.3 million, (2) an increase in net income of $29.8 million, and (3) a change in other current and non-current assets of $25.9 million.

[0001408710-25-000008:mdna:131]
[same as prior period, unchanged from 0001408710-24-000040:mdna:120]

[0001408710-25-000008:mdna:132]
Investing cash flows consist primarily of investment purchases, sales, maturities, and disposals; and capital expenditures. The increase in cash used in investing activities for the six months ended December 27, 2024 as compared to cash used in investing activities for the six months ended December 29, 2023 was primarily due to an increase in capital expenditures.

[0001408710-25-000008:mdna:133]
[same as prior period, unchanged from 0001408710-24-000040:mdna:122]

[0001408710-25-000008:mdna:134]
Financing cash flows consist primarily of repayment of long-term debt, share repurchases, and withholding tax related to net share settlement of restricted share units. The increase in cash used in financing activities for the six months ended December 27, 2024 as compared to the six months ended December 29, 2023 was due to an increase in share repurchases and higher withholding tax related to net share settlement of restricted share units, offset by lower repayment of long-term borrowings.

[0001408710-25-000008:mdna:135]
[same as prior period, unchanged from 0001408710-24-000040:mdna:124]

[0001408710-25-000008:mdna:136]
[same as prior period, unchanged from 0001408710-24-000040:mdna:125]

[0001408710-25-000008:mdna:137]
38
