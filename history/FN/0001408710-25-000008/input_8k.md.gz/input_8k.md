# FN 8-K — 0001408710-25-000006 filed 2025-02-03

## item codes, every 8-K on or before 2025-02-04

- 2025-02-03 0001408710-25-000006 — 2.02, 9.01
- 2024-12-20 0001408710-24-000044 — 5.02
- 2024-12-13 0001408710-24-000042 — 5.07
- 2024-11-04 0001408710-24-000038 — 2.02, 9.01
- 2024-08-19 0001408710-24-000030 — 2.02, 5.02, 9.01
- 2024-06-14 0001408710-24-000023 — 5.02
- 2024-05-06 0001408710-24-000017 — 2.02, 9.01
- 2024-02-05 0001408710-24-000007 — 2.02, 9.01
- 2023-12-13 0001408710-23-000038 — 5.07
- 2023-11-06 0001408710-23-000034 — 2.02, 9.01
- 2023-08-21 0001408710-23-000026 — 2.02, 5.02, 9.01
- 2023-05-08 0001408710-23-000016 — 2.02, 5.02, 9.01
- 2023-02-06 0001408710-23-000006 — 2.02, 9.01
- 2022-12-13 0001408710-22-000062 — 5.07
- 2022-11-07 0001408710-22-000058 — 2.02, 9.01
- 2022-08-15 0001408710-22-000041 — 2.02, 5.02, 9.01
- 2022-05-02 0001408710-22-000026 — 2.02, 9.01
- 2022-01-31 0001408710-22-000016 — 2.02, 9.01
- 2022-01-19 0001408710-22-000010 — 5.02
- 2022-01-06 0001408710-22-000006 — 5.02
- 2021-12-10 0001408710-21-000051 — 5.07
- 2021-11-01 0001408710-21-000045 — 2.02, 9.01
- 2021-08-16 0001408710-21-000031 — 2.02, 5.02, 9.01
- 2021-05-03 0001408710-21-000019 — 2.02, 9.01
- 2021-02-01 0001408710-21-000008 — 2.02, 9.01
- 2020-12-11 0001193125-20-315861 — 5.07
- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2025-02-04

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001408710-25-000006:8k_2_02:1]
EX-99.1
2
fn-2025203xex991q225.htm
EX-99.1

[0001408710-25-000006:8k_2_02:2]
Document

[0001408710-25-000006:8k_2_02:3]
Exhibit 99.1

[0001408710-25-000006:8k_2_02:4]
Fabrinet Announces Second Quarter Fiscal Year 2025 Financial Results

[0001408710-25-000006:8k_2_02:5]
•Record Second Quarter Revenue and Earnings Per Share Above Guidance Ranges

[0001408710-25-000006:8k_2_02:6]
BANGKOK, Thailand – February 3, 2025 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its second fiscal quarter ended December 27, 2024.

[0001408710-25-000006:8k_2_02:7]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “With continued business momentum, we exceeded our guidance for revenue and net income per share in the second quarter. Our telecom performance was very strong and benefited from both increasing demand for datacenter interconnect products as well as early progress from recent systems wins. While datacom demand has slightly moderated near-term we continue to anticipate more rapid growth as next-generation products ramp production. With several positive trends, we are very optimistic as we look to the third quarter and beyond.”

[0001408710-25-000006:8k_2_02:8]
Second Quarter Fiscal Year 2025 Financial Highlights

[0001408710-25-000006:8k_2_02:9]
GAAP Results

[0001408710-25-000006:8k_2_02:10]
•Revenue for the second quarter of fiscal year 2025 was $833.6 million, compared to $712.7 million for the second quarter of fiscal year 2024.

[0001408710-25-000006:8k_2_02:11]
•GAAP net income for the second quarter of fiscal year 2025 was $86.6 million, compared to $69.1 million for the second quarter of fiscal year 2024.

[0001408710-25-000006:8k_2_02:12]
•GAAP net income per diluted share for the second quarter of fiscal year 2025 was $2.38, compared to $1.89 for the second quarter of fiscal year 2024.

[0001408710-25-000006:8k_2_02:13]
Non-GAAP Results

[0001408710-25-000006:8k_2_02:14]
•Non-GAAP net income for the second quarter of fiscal year 2025 was $95.1 million, compared to $76.1 million for the second quarter of fiscal year 2024.

[0001408710-25-000006:8k_2_02:15]
•Non-GAAP net income per diluted share for the second quarter of fiscal year 2025 was $2.61, compared to $2.08 for the second quarter of fiscal year 2024.

[0001408710-25-000006:8k_2_02:16]
Share Repurchase Program Expanded

[0001408710-25-000006:8k_2_02:17]
Fabrinet also announced that its Board of Directors has approved an expansion of its share repurchase program, authorizing the repurchase of up to an additional $100.0 million of Fabrinet’s ordinary shares. The addition brings the aggregate authorization under Fabrinet’s existing share repurchase program to $534.3 million.

[0001408710-25-000006:8k_2_02:18]
Business Outlook

[0001408710-25-000006:8k_2_02:19]
Based on information available as of February 3, 2025, Fabrinet is issuing guidance for its third fiscal quarter ending March 28, 2025, as follows:

[0001408710-25-000006:8k_2_02:20]
•Fabrinet expects third quarter revenue to be in the range of $850 million to $870 million.

[0001408710-25-000006:8k_2_02:21]
•GAAP net income per diluted share is expected to be in the range of $2.32 to $2.40, based on approximately 36.3 million fully diluted shares outstanding.

[0001408710-25-000006:8k_2_02:22]
•Non-GAAP net income per diluted share is expected to be in the range of $2.55 to $2.63, based on approximately 36.3 million fully diluted shares outstanding.

[0001408710-25-000006:8k_2_02:23]
Guidance for non-GAAP net income per diluted share excludes share-based compensation expenses and certain non-recurring items. A reconciliation of non-GAAP net income per diluted share to the corresponding GAAP measure is available at the end of this press release.

[0001408710-25-000006:8k_2_02:24]
Conference Call Information

[0001408710-25-000006:8k_2_02:25]
| What: |  | Fabrinet Second Quarter Fiscal Year 2025 Financial Results Call |
| When: |  | February 3, 2025 |
| Time: |  | 5:00 p.m. ET |
| Live Call and Replay: |  | https://investor.fabrinet.com/events-and-presentations/events |

[0001408710-25-000006:8k_2_02:26]
A recorded version of this webcast will be available approximately two hours after the call and accessible at http://investor.fabrinet.com. The webcast will be archived on Fabrinet’s website for a period of one year.

[0001408710-25-000006:8k_2_02:27]
About Fabrinet

[0001408710-25-000006:8k_2_02:28]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China, and Israel. For more information visit: www.fabrinet.com.

[0001408710-25-000006:8k_2_02:29]
Forward-Looking Statements

[0001408710-25-000006:8k_2_02:30]
Non-GAAP Financial Measures

[0001408710-25-000006:8k_2_02:31]
In addition to reporting financial results in accordance with GAAP, we provide investors with certain non-GAAP financial measures. These non-GAAP financial measures are in addition to, and not a substitute for or superior to, measures of financial performance prepared in accordance with GAAP. We believe these non-GAAP financial measures provide investors with useful supplemental information to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, we use some of these non-GAAP financial measures to measure company performance for the purposes of determining employee incentive plan compensation.

[0001408710-25-000006:8k_2_02:32]
Non-GAAP gross profit, non-GAAP operating profit, non-GAAP net income and non-GAAP net income per diluted share exclude: share-based compensation expenses; severance payment and others; restructuring and other related costs; and amortization of deferred debt issuance costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations.

[0001408710-25-000006:8k_2_02:33]
Non-GAAP free cash flow is net cash provided by (used in) operating activities, minus capital expenditures (purchase of property, plant and equipment). We use free cash flow to measure our ability to generate additional cash from our business operations.

[0001408710-25-000006:8k_2_02:34]
There are a number of limitations related to the use of these non-GAAP financial measures versus their nearest GAAP equivalents. For example, other companies may calculate non-GAAP financial measures differently or may use other measures to evaluate their performance, all of which could reduce the usefulness of our non-GAAP financial measures as tools for comparison. We urge you to review the reconciliations of our non-GAAP financial measures to the most directly comparable GAAP financial measures, and not to rely on any single financial measure to evaluate our business.

[0001408710-25-000006:8k_2_02:35]
Investor Contact:

[0001408710-25-000006:8k_2_02:36]
Garo Toomajanian

[0001408710-25-000006:8k_2_02:37]
ir@fabrinet.com

[0001408710-25-000006:8k_2_02:38]
FABRINET

[0001408710-25-000006:8k_2_02:39]
CONSOLIDATED BALANCE SHEETS

[0001408710-25-000006:8k_2_02:40]
| (in thousands of U.S. dollars, except share data and par value) | December 27,2024 |  | June 28,2024 |
|  | (unaudited) |  |  |
| Assets |  |  |  |
| Current assets |  |  |  |
| Cash and cash equivalents | $ | 403,662 |  |  | $ | 409,973 |  |
| Short-term investments | 530,969 |  |  | 448,630 |  |
| Trade accounts receivable, net of allowance for expected credit losses of $1,245 and $1,629, respectively | 680,094 |  |  | 592,452 |  |
| Inventories | 489,159 |  |  | 463,206 |  |
| Prepaid expenses | 17,734 |  |  | 10,620 |  |
| Other current assets | 77,394 |  |  | 87,810 |  |
| Total current assets | 2,199,012 |  |  | 2,012,691 |  |
| Non-current assets |  |  |  |
| Property, plant and equipment, net | 323,648 |  |  | 307,240 |  |
| Intangibles, net | 2,062 |  |  | 2,321 |  |
| Operating right-of-use assets | 6,397 |  |  | 5,336 |  |
| Deferred tax assets | 10,694 |  |  | 10,446 |  |
| Other non-current assets | 592 |  |  | 485 |  |
| Total non-current assets | 343,393 |  |  | 325,828 |  |
| Total Assets | $ | 2,542,405 |  |  | $ | 2,338,519 |  |
| Liabilities and Shareholders’ Equity |  |  |  |
| Current liabilities |  |  |  |
| Trade accounts payable | 529,016 |  |  | 441,835 |  |
| Fixed assets payable | 20,594 |  |  | 14,380 |  |
| Operating lease liabilities, current portion | 1,676 |  |  | 1,355 |  |
| Income tax payable | 8,214 |  |  | 3,937 |  |
| Accrued payroll, bonus and related expenses | 20,598 |  |  | 22,116 |  |
| Accrued expenses | 29,112 |  |  | 19,916 |  |
| Other payables | 53,950 |  |  | 54,403 |  |
| Total current liabilities | 663,160 |  |  | 557,942 |  |
| Non-current liabilities |  |  |  |
| Deferred tax liability | 1,039 |  |  | 4,895 |  |
| Operating lease liability, non-current portion | 4,417 |  |  | 3,635 |  |
| Severance liabilities | 27,572 |  |  | 24,093 |  |
| Other non-current liabilities | 3,246 |  |  | 2,209 |  |
| Total non-current liabilities | 36,274 |  |  | 34,832 |  |
| Total Liabilities | 699,434 |  |  | 592,774 |  |
| Shareholders’ equity |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of December 27, 2024 and June 28, 2024) | — |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 39,585,188 shares and 39,457,462 shares issued as of December 27, 2024 and June 28, 2024, respectively; and 35,981,188 shares and 36,145,242 shares outstanding as of December 27, 2024 and June 28, 2024, respectively) | 396 |  |  | 395 |  |
| Additional paid-in capital | 218,449 |  |  | 222,044 |  |
| Less: Treasury shares (3,604,000 shares and 3,312,220 shares as of December 27, 2024 and June 28, 2024, respectively) | (303,023) |  |  | (234,323) |  |
| Accumulated other comprehensive income (loss) | 2,349 |  |  | (3,141) |  |
| Retained earnings | 1,924,800 |  |  | 1,760,770 |  |
| Total Shareholders’ Equity | 1,842,971 |  |  | 1,745,745 |  |
| Total Liabilities and Shareholders’ Equity | $ | 2,542,405 |  |  | $ | 2,338,519 |  |

[0001408710-25-000006:8k_2_02:41]
FABRINET

[0001408710-25-000006:8k_2_02:42]
CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME (UNAUDITED)

[0001408710-25-000006:8k_2_02:43]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands of U.S. dollars, except per share data) | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
| Revenues | $ | 833,608 |  |  | $ | 712,694 |  |  | $ | 1,637,836 |  |  | $ | 1,398,171 |  |
| Cost of revenues | (732,759) |  |  | (624,364) |  |  | (1,437,961) |  |  | (1,225,437) |  |
| Gross profit | 100,849 |  |  | 88,330 |  |  | 199,875 |  |  | 172,734 |  |
| Selling, general and administrative expenses | (21,206) |  |  | (19,316) |  |  | (43,237) |  |  | (39,745) |  |
| Restructuring and other related costs | (46) |  |  | — |  |  | (103) |  |  | — |  |
| Operating income | 79,597 |  |  | 69,014 |  |  | 156,535 |  |  | 132,989 |  |
| Interest income | 11,314 |  |  | 7,748 |  |  | 22,247 |  |  | 13,646 |  |
| Interest expense | — |  |  | (36) |  |  | — |  |  | (81) |  |
| Foreign exchange gain (loss), net | 4,042 |  |  | (3,788) |  |  | (3,053) |  |  | (3,373) |  |
| Other income (expense), net | (62) |  |  | (35) |  |  | (81) |  |  | (115) |  |
| Income before income taxes | 94,891 |  |  | 72,903 |  |  | 175,648 |  |  | 143,066 |  |
| Income tax expense | (8,255) |  |  | (3,793) |  |  | (11,618) |  |  | (8,867) |  |
| Net income | 86,636 |  |  | 69,110 |  |  | 164,030 |  |  | 134,199 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities | (521) |  |  | 2,946 |  |  | 6,297 |  |  | 3,894 |  |
| Change in net unrealized gain (loss) on derivative instruments | (9,416) |  |  | 8,951 |  |  | (883) |  |  | 8,390 |  |
| Change in net retirement benefits plan – prior service cost | — |  |  | 8 |  |  | — |  |  | 134 |  |
| Change in foreign currency translation adjustment | 428 |  |  | (206) |  |  | 76 |  |  | (106) |  |
| Total other comprehensive income (loss), net of tax | (9,509) |  |  | 11,699 |  |  | 5,490 |  |  | 12,312 |  |
| Net comprehensive income | $ | 77,127 |  |  | $ | 80,809 |  |  | $ | 169,520 |  |  | $ | 146,511 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 2.40 |  |  | $ | 1.90 |  |  | $ | 4.53 |  |  | $ | 3.70 |  |
| Diluted | $ | 2.38 |  |  | $ | 1.89 |  |  | $ | 4.51 |  |  | $ | 3.67 |  |
| Weighted-average number of ordinary shares outstanding (in thousands of shares) |  |  |  |  |  |  |  |
| Basic | 36,163 |  |  | 36,328 |  |  | 36,183 |  |  | 36,292 |  |
| Diluted | 36,402 |  |  | 36,639 |  |  | 36,405 |  |  | 36,560 |  |

[0001408710-25-000006:8k_2_02:44]
FABRINET

[0001408710-25-000006:8k_2_02:45]
CONSOLIDATED STATEMENTS OF CASH FLOWS (UNAUDITED)

[0001408710-25-000006:8k_2_02:46]
|  | Six Months Ended |
| (in thousands of U.S. dollars) | December 27,2024 |  | December 29,2023 |
| Cash flows from operating activities |  |  |  |
| Net income for the period | $ | 164,030 |  |  | $ | 134,199 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 25,796 |  |  | 24,186 |  |
| (Gain) loss on disposal of property, plant and equipment and intangibles | (37) |  |  | (111) |  |
| Amortization of discount (premium) of short-term investments | (2,225) |  |  | (1,397) |  |
| (Reversal of) allowance for expected credit losses | (384) |  |  | 1,776 |  |
| Unrealized loss (gain) on exchange rate and fair value of foreign currency forward contracts | 1,345 |  |  | 3,287 |  |
| Amortization of fair value at hedge inception of interest rate swaps | — |  |  | (154) |  |
| Share-based compensation | 17,120 |  |  | 14,714 |  |
| Deferred income tax expense (benefit) | (3,493) |  |  | 1,117 |  |
| Other non-cash expenses | 30 |  |  | 89 |  |
| Changes in operating assets and liabilities |  |  |  |
| Trade accounts receivable | (87,178) |  |  | (53,873) |  |
| Inventories | (25,953) |  |  | 104,818 |  |
| Other current assets and non-current assets | 9,536 |  |  | (16,360) |  |
| Trade accounts payable | 88,272 |  |  | (6,980) |  |
| Income tax payable | 4,304 |  |  | 1,531 |  |
| Accrued expenses | 8,124 |  |  | 4,272 |  |
| Other payables | 186 |  |  | 20,700 |  |
| Severance liabilities | 1,565 |  |  | 1,395 |  |
| Other current liabilities and non-current liabilities | (1,952) |  |  | (3,995) |  |
| Net cash provided by operating activities | 199,086 |  |  | 229,214 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of short-term investments | (155,936) |  |  | (164,971) |  |
| Proceeds from sales of short-term investments | — |  |  | 10,000 |  |
| Proceeds from maturities of short-term investments | 82,129 |  |  | 72,824 |  |
| Purchase of property, plant and equipment | (42,150) |  |  | (21,236) |  |
| Purchase of intangibles | (227) |  |  | (518) |  |
| Proceeds from disposal of property, plant and equipment | 110 |  |  | 2,048 |  |
| Net cash used in investing activities | (116,074) |  |  | (101,853) |  |
| Cash flows from financing activities |  |  |  |
| Repayment of long-term borrowings | — |  |  | (6,094) |  |
| Repurchase of ordinary shares | (68,700) |  |  | (6,372) |  |
| Withholding tax related to net share settlement of restricted share units | (20,714) |  |  | (12,352) |  |
| Net cash used in financing activities | (89,414) |  |  | (24,818) |  |
| Net increase (decrease) in cash and cash equivalents | $ | (6,402) |  |  | $ | 102,543 |  |
| Movement in cash and cash equivalents |  |  |  |
| Cash and cash equivalents at the beginning of period | $ | 409,973 |  |  | $ | 231,368 |  |
| Increase (decrease) in cash and cash equivalents | (6,402) |  |  | 102,543 |  |
| Effect of exchange rate on cash and cash equivalents | 91 |  |  | 142 |  |
| Cash and cash equivalents at the end of period | $ | 403,662 |  |  | $ | 334,053 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment-related payables | $ | 20,594 |  |  | $ | 12,983 |  |

[0001408710-25-000006:8k_2_02:47]
FABRINET

[0001408710-25-000006:8k_2_02:48]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES (UNAUDITED)

[0001408710-25-000006:8k_2_02:49]
Reconciliation of GAAP Gross Profit and GAAP Gross Margin to Non-GAAP Gross Profit and Non-GAAP Gross Margin

[0001408710-25-000006:8k_2_02:50]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands of U.S. dollars) | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
| Revenues | $ | 833,608 |  |  |  |  | $ | 712,694 |  |  |  |  | $ | 1,637,836 |  |  |  |  | $ | 1,398,171 |  |  |  |
| Gross profit (GAAP) | $ | 100,849 |  |  | 12.1 | % |  | $ | 88,330 |  |  | 12.4 | % |  | $ | 199,875 |  |  | 12.2 | % |  | $ | 172,734 |  |  | 12.4 | % |
| Share-based compensation expenses | 2,764 |  |  |  |  | 1,701 |  |  |  |  | 5,662 |  |  |  |  | 3,866 |  |  |  |
| Gross profit (Non-GAAP) | $ | 103,613 |  |  | 12.4 | % |  | $ | 90,031 |  |  | 12.6 | % |  | $ | 205,537 |  |  | 12.5 | % |  | $ | 176,600 |  |  | 12.6 | % |

[0001408710-25-000006:8k_2_02:51]
Reconciliation of GAAP Operating Profit and GAAP Operating Margin to Non-GAAP Operating Profit and Non-GAAP Operating Margin

[0001408710-25-000006:8k_2_02:52]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands of U.S. dollars) | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
| Revenues | $ | 833,608 |  |  |  |  | $ | 712,694 |  |  |  |  | $ | 1,637,836 |  |  |  |  | $ | 1,398,171 |  |  |  |
| Operating profit (GAAP) | $ | 79,597 |  |  | 9.5 | % |  | $ | 69,014 |  |  | 9.7 | % |  | $ | 156,535 |  |  | 9.6 | % |  | $ | 132,989 |  |  | 9.5 | % |
| Share-based compensation expenses | 8,438 |  |  |  |  | 6,981 |  |  |  |  | 17,120 |  |  |  |  | 14,714 |  |  |  |
| Severance payment and others | 18 |  |  |  |  | — |  |  |  |  | 748 |  |  |  |  | — |  |  |  |
| Restructuring and other related costs | 46 |  |  |  |  | — |  |  |  |  | 103 |  |  |  |  | — |  |  |  |
| Operating profit (Non-GAAP) | $ | 88,099 |  |  | 10.6 | % |  | $ | 75,995 |  |  | 10.7 | % |  | $ | 174,506 |  |  | 10.7 | % |  | $ | 147,703 |  |  | 10.6 | % |

[0001408710-25-000006:8k_2_02:53]
FABRINET

[0001408710-25-000006:8k_2_02:54]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES (UNAUDITED)

[0001408710-25-000006:8k_2_02:55]
Reconciliation of GAAP Net Income and EPS to Non-GAAP Net Income and EPS

[0001408710-25-000006:8k_2_02:56]
|  | Three Months Ended |  | Six Months Ended |
|  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
| (in thousands of U.S. dollars, except per share data) | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |
| GAAP measures | $ | 86,636 |  |  | $ | 2.38 |  |  | $ | 69,110 |  |  | $ | 1.89 |  |  | $ | 164,030 |  |  | $ | 4.51 |  |  | $ | 134,199 |  |  | $ | 3.67 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 2,764 |  |  | 0.08 |  |  | 1,701 |  |  | 0.05 |  |  | 5,662 |  |  | 0.16 |  |  | 3,866 |  |  | 0.11 |  |
| Total related to cost of revenues | 2,764 |  |  | 0.08 |  |  | 1,701 |  |  | 0.05 |  |  | 5,662 |  |  | 0.16 |  |  | 3,866 |  |  | 0.11 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 5,674 |  |  | 0.15 |  |  | 5,280 |  |  | 0.14 |  |  | 11,458 |  |  | 0.31 |  |  | 10,848 |  |  | 0.30 |  |
| Severance payment and others | 18 |  |  | 0.00 |  |  | — |  |  | — |  |  | 748 |  |  | 0.02 |  |  | — |  |  | — |  |
| Total related to selling, general and administrative expenses | 5,692 |  |  | 0.15 |  |  | 5,280 |  |  | 0.14 |  |  | 12,206 |  |  | 0.33 |  |  | 10,848 |  |  | 0.30 |  |
| Related to other income and expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other related costs | 46 |  |  | 0.00 |  |  | — |  |  | — |  |  | 103 |  |  | 0.00 |  |  | — |  |  | — |  |
| Amortization of deferred debt issuance costs | — |  |  | — |  |  | 8 |  |  | 0.00 |  |  | — |  |  | — |  |  | 16 |  |  | 0.00 |  |
| Total related to other income and expense | 46 |  |  | 0.00 |  |  | 8 |  |  | 0.00 |  |  | 103 |  |  | 0.00 |  |  | 16 |  |  | 0.00 |  |
| Total related to net income & EPS | 8,502 |  |  | 0.23 |  |  | 6,989 |  |  | 0.19 |  |  | 17,971 |  |  | 0.49 |  |  | 14,730 |  |  | 0.41 |  |
| Non-GAAP measures | $ | 95,138 |  |  | $ | 2.61 |  |  | $ | 76,099 |  |  | $ | 2.08 |  |  | $ | 182,001 |  |  | $ | 5.00 |  |  | $ | 148,929 |  |  | $ | 4.08 |  |
| Shares used in computing diluted net income per share (in thousands of shares) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  | 36,402 |  |  |  |  | 36,639 |  |  |  |  | 36,405 |  |  |  |  | 36,560 |  |
| Non-GAAP diluted shares |  |  | 36,402 |  |  |  |  | 36,639 |  |  |  |  | 36,405 |  |  |  |  | 36,560 |  |

[0001408710-25-000006:8k_2_02:57]
FABRINET

[0001408710-25-000006:8k_2_02:58]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW (UNAUDITED)

[0001408710-25-000006:8k_2_02:59]
| (in thousands of U.S. dollars) |  | Three Months Ended |  | Six Months Ended |
|  |  | December 27,2024 |  | December 29,2023 |  | December 27,2024 |  | December 29,2023 |
| Net cash provided by operating activities |  | $ | 115,904 |  |  | $ | 84,165 |  |  | $ | 199,086 |  |  | $ | 229,214 |  |
| Less: Purchase of property, plant and equipment |  | (21,900) |  |  | (9,801) |  |  | (42,150) |  |  | (21,236) |  |
| Non-GAAP free cash flow |  | $ | 94,004 |  |  | $ | 74,364 |  |  | $ | 156,936 |  |  | $ | 207,978 |  |

[0001408710-25-000006:8k_2_02:60]
FABRINET

[0001408710-25-000006:8k_2_02:61]
GUIDANCE FOR QUARTER ENDING MARCH 28, 2025

[0001408710-25-000006:8k_2_02:62]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-25-000006:8k_2_02:63]
|  | DilutedEPS |
| GAAP net income per diluted share | $2.32 to $2.40 |
| Related to cost of revenues: |  |
| Share-based compensation expenses | 0.08 |
| Total related to cost of revenues | 0.08 |
| Related to selling, general and administrative expenses: |  |
| Share-based compensation expenses | 0.15 |
| Total related to selling, general and administrative expenses | 0.15 |
| Total related to net income & EPS | 0.23 |
| Non-GAAP net income per diluted share | $2.55 to $2.63 |
