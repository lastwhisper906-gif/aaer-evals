# FN MD&A — 0001193125-15-172043


## mdna

[0001193125-15-172043:mdna:1]
[same as prior period, unchanged from 0001193125-15-031475:mdna:1]

[0001193125-15-172043:mdna:2]
[same as prior period, unchanged from 0001193125-15-031475:mdna:2]

[0001193125-15-172043:mdna:3]
[same as prior period, unchanged from 0001193125-15-031475:mdna:3]

[0001193125-15-172043:mdna:4]
|  | • |  | our expectation that the portion of our future revenues attributable to customers in regions outside of North America will decrease compared with the portion of those revenues for the nine months ended March 27, 2015; |

[0001193125-15-172043:mdna:5]
[same as prior period, unchanged from 0001193125-15-031475:mdna:5]

[0001193125-15-172043:mdna:6]
[same as prior period, unchanged from 0001193125-15-031475:mdna:6]

[0001193125-15-172043:mdna:7]
|  | • |  | our expectation that our fiscal year 2015 selling, general and administrative (SG&A) expenses will increase on an absolute dollar basis and as a percentage of revenue compared to fiscal year 2014; |

[0001193125-15-172043:mdna:8]
|  | • |  | our expectation that, in addition to incremental costs associated with growing our business generally, we will incur additional SG&A expenses as a result of expanding our business in the United States; |

[0001193125-15-172043:mdna:9]
|  | • |  | our expectation that our employee costs will increase in Thailand and the People’s Republic of China (PRC); |

[0001193125-15-172043:mdna:10]
[same as prior period, unchanged from 0001193125-15-031475:mdna:10]

[0001193125-15-172043:mdna:11]
[same as prior period, unchanged from 0001193125-15-031475:mdna:11]

[0001193125-15-172043:mdna:12]
[same as prior period, unchanged from 0001193125-15-031475:mdna:12]

[0001193125-15-172043:mdna:13]
[same as prior period, unchanged from 0001193125-15-031475:mdna:13]

[0001193125-15-172043:mdna:14]
[same as prior period, unchanged from 0001193125-15-031475:mdna:14]

[0001193125-15-172043:mdna:15]
[same as prior period, unchanged from 0001193125-15-031475:mdna:15]

[0001193125-15-172043:mdna:16]
[same as prior period, unchanged from 0001193125-15-031475:mdna:16]

[0001193125-15-172043:mdna:17]
[same as prior period, unchanged from 0001193125-15-031475:mdna:17]

[0001193125-15-172043:mdna:18]
[same as prior period, unchanged from 0001193125-15-031475:mdna:18]

[0001193125-15-172043:mdna:19]
[same as prior period, unchanged from 0001193125-15-031475:mdna:19]

[0001193125-15-172043:mdna:20]
[same as prior period, unchanged from 0001193125-15-031475:mdna:20]

[0001193125-15-172043:mdna:21]
[same as prior period, unchanged from 0001193125-15-031475:mdna:21]

[0001193125-15-172043:mdna:22]
[same as prior period, unchanged from 0001193125-15-031475:mdna:22]

[0001193125-15-172043:mdna:23]
[same as prior period, unchanged from 0001193125-15-031475:mdna:23]

[0001193125-15-172043:mdna:24]
[same as prior period, unchanged from 0001193125-15-031475:mdna:24]

[0001193125-15-172043:mdna:25]
During the fourth quarter of our fiscal year 2014, we discovered certain violations of our policies and procedures relating to finished goods
held in our warehouse on behalf of our customers (we refer to finished goods held in our warehouse on behalf of our customers as consignment goods or consignment inventory, and when the finished goods are sold we refer to the related revenue as
consignment revenue). Specifically, we identified violations related to certain employees in one of our business units colluding to cause the improper recognition of revenues for certain goods by recording consignment revenues on goods before such
goods were finished.

[0001193125-15-172043:mdna:26]
In connection with the above, the Audit Committee of our Board of Directors initiated an investigation concerning
various accounting cut-off issues in fiscal year 2014, specifically the transfer of unfinished goods to consignment inventory and other inventory cut-off issues. The investigation found certain process deficiencies concerning the potential to
invoice unfinished goods held under consignment arrangements and the need for certain remedial measures. The investigation did not find executive officer involvement in the identified violations.

[0001193125-15-172043:mdna:27]
We continue to develop remedial steps to address these significant deficiencies and improve our internal control over our financial reporting.
Specifically, during the nine months ended March 27, 2015, we implemented the following remedial measures for the deficiencies identified in the investigation:

[0001193125-15-172043:mdna:28]
|  | 1. | Dismissed an employee involved in the violations. |

[0001193125-15-172043:mdna:29]
|  | 2. | Provided training to staff from all departments at the manager level and above on: |

[0001193125-15-172043:mdna:30]
|  | a. | Our Code of Business Conduct, which provided guidance and further clarity to our employees on our policies and procedures related to the conduct of business; and |

[0001193125-15-172043:mdna:31]
|  | b. | Our revenue recognition policies, using the services of a third party advisor. This training focused on the scope and application of the Company’s policies concerning revenue recognition and related cut-off procedures. |

[0001193125-15-172043:mdna:32]
|  | 3. | Evaluated existing inventory procedures and enhanced such procedures, or where necessary, designed and implemented new procedures, including : |

[0001193125-15-172043:mdna:33]
|  | a. | The segregation and storage of consignment inventory in a secure designated warehouse; and |

[0001193125-15-172043:mdna:34]
|  | b. | Physical check of finished goods when our production division delivers products to the designated warehouse. |

[0001193125-15-172043:mdna:35]
[same as prior period, unchanged from 0001193125-15-031475:mdna:31]

[0001193125-15-172043:mdna:36]
Based on an analysis prepared by Fabrinet, it was determined that the potential exposure relating to the control deficiencies identified during
the investigation was not material to our consolidated financial statements for fiscal year 2014. Further, we assessed these control deficiencies to be significant deficiencies rather than material weaknesses on the basis that there was no executive
officer involvement in the violations, the potential misstatements were not material to the consolidated financial statements, and the Audit Committee was actively involved in the investigation.

[0001193125-15-172043:mdna:37]
[same as prior period, unchanged from 0001193125-15-031475:mdna:33]

[0001193125-15-172043:mdna:38]
Subsequent to completion of the Audit Committee’s investigation, we evaluated our accounting practices surrounding consignment inventory
and consignment revenue. Based on that evaluation, we determined that for certain volume supply agreements with our customers, not all of the revenue recognition criteria prescribed by U.S. GAAP and Staff Accounting Bulletin No. 104 had been
met at the time revenue was recorded. Specifically, we misapplied the guidance when assessing the terms of these agreements with respect to when title and risk of loss transfers to our customers. As a result, we determined that certain sales
previously recognized did not qualify for revenue recognition in the periods in which they were recognized. We evaluated the impact of the errors on both a quantitative and qualitative basis under the guidance of ASC 250-Accounting Changes and Error
Corrections and determined that the errors did not have a material impact to the previously issued consolidated financial statements. We assessed the control implications and concluded that the deficiency constituted a material weakness in internal
control over financial reporting (refer to Part I, Item 4 for additional information).

[0001193125-15-172043:mdna:39]
Had adjustments in the prior period been made
to reflect revenues that were inappropriately recorded in the three and nine months ended March 28, 2014, revenues for the three and nine months ended March 28, 2014 would have been $2.0 million higher and $1.7 million lower, respectively.

[0001193125-15-172043:mdna:40]
During the nine months ended March 27, 2015, we amended certain volume supply agreements such that under certain conditions we
recognize consignment revenue upon products being delivered to our secure designated warehouse. Specifically, we recognize consignment revenue when the goods are completed and ready for shipment, and title and risk of loss have passed to the
customer. As a result, in the nine months ended March 27, 2015, we recorded revenue of $8.0 million with $0.8 million gross profit from these amended volume supply agreements.

[0001193125-15-172043:mdna:41]
[same as prior period, unchanged from 0001193125-15-031475:mdna:37]

[0001193125-15-172043:mdna:42]
We suspended
production at all of our manufacturing facilities in Thailand from October 17, 2011 through November 14, 2011 due to severe flooding in Thailand. We never resumed, and have permanently ceased, production at our Chokchai facility. We
submitted claims for losses to our insurance companies, all of which were settled as of the end of fiscal year 2014.

[0001193125-15-172043:mdna:43]
In the three and
nine month ended March 28, 2014, we received from our insurer a final payment of $38.6 million and $45.2 million against our claim for owned and consigned equipment and inventory claims, respectively, which we recognized as income related to
flooding. This income was offset by other expenses from write-offs of advance payments to a customer due to flood losses of $0.5 million.

[0001193125-15-172043:mdna:44]
During the nine months ended March 28, 2014, we fulfilled our obligations to a customer in accordance with a settlement agreement entered
into during the third quarter of fiscal year 2013 by making a final cash payment of $5.3 million and transferring equipment, with an aggregate value of $2.3 million, to such customer. Also, we fulfilled our obligations to a customer’s insurers
in accordance with a settlement agreement entered into during the fourth quarter of fiscal year 2013 by making a final payment of $2.3 million.

[0001193125-15-172043:mdna:45]
[same as prior period, unchanged from 0001193125-15-031475:mdna:41]

[0001193125-15-172043:mdna:46]
Our total revenues increased by $21.8 million, or 13.0%, to $189.5 million for the three months ended March 27, 2015, compared with $167.7
million for the three months ended March 28, 2014. Our total revenues increased by $49.4 million, or 9.5%, to $567.1 million for the nine months ended March 27, 2015, compared with $517.8 million for the nine months ended March 28,
2014.The increase was primarily due to an increase in our customers’ demand for both optical and non-optical communications manufacturing services during the three and nine months ended March 27, 2015.

[0001193125-15-172043:mdna:47]
[same as prior period, unchanged from 0001193125-15-031475:mdna:43]

[0001193125-15-172043:mdna:48]
[same as prior period, unchanged from 0001193125-15-031475:mdna:44]

[0001193125-15-172043:mdna:49]
We generate
revenues from three geographic regions: North America, Asia-Pacific and Europe. Revenues are attributed to a particular geographic area based on the bill-to location of our customers, notwithstanding that our customers may ultimately ship their
products to end customers in a different geographic region. Virtually all of our revenues are derived from our manufacturing facilities in Asia-Pacific.

[0001193125-15-172043:mdna:50]
The percentage of our revenues generated from a bill-to location outside of North America increased from 49.4% in the three months ended
March 28, 2014 to 50.7% in the three months ended March 27, 2015, primarily because of an increase in sales to our customers in the Asia-Pacific region. The percentage of our revenue generated from a bill-to location outside North America
decreased from 52.1% in the nine months ended March 28, 2014 to 51.0% in the nine months ended March 27, 2015, primarily because of a decrease in sales to our customers in Europe. We expect that the portion of our future revenues
attributable to customers in regions outside North America will decrease as compared with the three and nine months ended March 27, 2015.

[0001193125-15-172043:mdna:51]
[same as prior period, unchanged from 0001193125-15-031475:mdna:47]

[0001193125-15-172043:mdna:52]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 27,2015 |  |  | March 28,2014 |  |  | March 27,2015 |  |  | March 28,2014 |  |
| North America |  |  | 49.3 | % |  |  | 50.6 | % |  |  | 49.0 | % |  |  | 47.9 | % |
| Asia-Pacific |  |  | 37.6 |  |  |  | 32.0 |  |  |  | 38.8 |  |  |  | 33.1 |  |
| Europe |  |  | 13.1 |  |  |  | 17.4 |  |  |  | 12.2 |  |  |  | 19.0 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-15-172043:mdna:53]
[same as prior period, unchanged from 0001193125-15-031475:mdna:49]

[0001193125-15-172043:mdna:54]
We enter into supply agreements with our customers which generally have an initial term of up to three years, subject to automatic renewals for
subsequent one-year terms unless expressly terminated. Although there are no minimum purchase requirements in our supply agreements, our customers provide us with rolling forecasts of their demand requirements. Our supply agreements generally
include provisions for pricing and periodic review of pricing, consignment of our customer’s unique production equipment to us, and the sharing of benefits from cost-savings derived from our efforts. We are generally required to purchase
materials, which may include long lead-time materials and materials that are subject to minimum order quantities and/or non-cancelable or non-returnable terms, to meet the stated demands of our customers. After procuring materials, we manufacture
products for our customers based on purchase orders that contain terms regarding product quantities, delivery locations and delivery dates. Our customers generally are obligated to purchase finished goods that we have manufactured according to their
demand requirements. Materials that are not consumed by our customers within a specified period of time, or are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under
our contracts. Once materials are designated as either excess or obsolete inventory, our customers are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products.

[0001193125-15-172043:mdna:55]
[same as prior period, unchanged from 0001193125-15-031475:mdna:51]

[0001193125-15-172043:mdna:56]
The key components of our cost of revenues are material costs, employee costs, and infrastructure-related costs. Material costs generally
represent the majority of our cost of revenues. Several of the materials we require to manufacture products for our customers are customized for their products and often sourced from a single supplier or in some cases, our own subsidiaries.
Shortages from sole-source suppliers due to yield loss, quality concerns, and capacity constraints, among other factors, may increase our expenses and negatively impact our gross profit margin or total revenues in a given quarter. Material costs
include scrap material. Historically, scrap rate diminishes during a product’s life cycle due to process, fixturing and test improvement, and optimization.

[0001193125-15-172043:mdna:57]
A second significant element of our cost of revenues is employee costs, including indirect employee costs related to design, configuration and
optimization of manufacturing processes for our customers, quality testing, materials testing and other engineering services; and direct costs related to our manufacturing employees. Direct employee costs include employee salaries, insurance and
benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a lesser extent, costs to recruit,
train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand and the PRC; the fluctuation of the Thai baht and Chinese Renminbi (RMB) against our functional currency, the U.S. dollar; and our ability to
retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to mitigate
these cost increases through improvements in employee productivity, employee retention, and asset utilization.

[0001193125-15-172043:mdna:58]
Our infrastructure costs
are comprised of depreciation, utilities, facilities management, and overhead costs. Most of our facility leases are long-term agreements. Our depreciation costs include buildings and fixed assets, primarily at our Pinehurst campus in Thailand, and
capital equipment located at each of our manufacturing locations.

[0001193125-15-172043:mdna:59]
During the three and nine months ended March 27, 2015,
discretionary merit-based bonus awards were made to our non-executive employees. Charges included in cost of revenues for bonus distributions to non-executive employees were $0.6 million and $0.5 million for the three months ended March 27,
2015 and March 28, 2014, respectively, and $1.8 million and $1.6 million for the nine months ended March 27, 2015 and March 28, 2014, respectively.

[0001193125-15-172043:mdna:60]
Share-based compensation expense included in cost of revenues was $0.4 million and $0.3 million for the three months ended March 27, 2015
and March 28, 2014, respectively, and $1.1 million and $0.9 million for the nine months ended March 27, 2015 and March 28, 2014, respectively.

[0001193125-15-172043:mdna:61]
[same as prior period, unchanged from 0001193125-15-031475:mdna:57]

[0001193125-15-172043:mdna:62]
[same as prior period, unchanged from 0001193125-15-031475:mdna:58]

[0001193125-15-172043:mdna:63]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and
administrative, and other support personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense, and other general
expenses not related to cost of revenues. In fiscal year 2015, we expect our SG&A expenses will increase on an absolute dollar basis and as a percentage of revenue compared with fiscal year 2014 due to the startup expenses of our facility in the
United States.

[0001193125-15-172043:mdna:64]
The compensation committee of our board of directors approved a fiscal year 2015 executive incentive plan with
quantitative objectives, based on achieving certain revenue and non-GAAP earnings per share targets for our fiscal year ending June 26, 2015, as well as qualitative objectives, based on achieving individual performance goals. Bonuses under our
fiscal year 2015 executive incentive plan are payable after the end of fiscal year 2015. In fiscal year 2014, the compensation committee approved a fiscal year 2014 executive incentive plan with quantitative objectives, based on achieving certain
revenue and gross margin percentage targets for our fiscal year ended June 27, 2014, as well as qualitative objectives, based on achieving individual performance goals. In the three months ended December 26, 2014, the compensation
committee awarded bonuses to our executive employees for Company and individual achievements of performance under our fiscal 2014 executive incentive plan. Discretionary merit-based bonus awards were also available to our non-executive employees and
were payable as of March 27, 2015.

[0001193125-15-172043:mdna:65]
Charges included in SG&A expenses for bonus distributions to non-executive and executive
employees were $1.4 million and $0.7 million for the three months ended March 27, 2015 and March 28, 2014, respectively, and $2.6 million and $2.2 million for the nine months ended March 27, 2015 and March 28, 2014, respectively.

[0001193125-15-172043:mdna:66]
Share-based compensation expense included in SG&A expenses was $1.6 million and $1.2 million for the three months ended
March 27, 2015 and March 28, 2014, respectively, and $4.7 million and $3.7 million for the nine months ended March 27, 2015 and March 28, 2014, respectively.

[0001193125-15-172043:mdna:67]
[same as prior period, unchanged from 0001193125-15-031475:mdna:64]

[0001193125-15-172043:mdna:68]
[same as prior period, unchanged from 0001193125-15-031475:mdna:65]

[0001193125-15-172043:mdna:69]
As a result of our international operations, we are exposed to foreign exchange risk arising from various currency exposures
primarily with respect to the Thai baht. Although a majority of our total revenues is denominated in U.S. dollars, a substantial portion of our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rates
between the Thai baht and the U.S. dollar have fluctuated substantially in recent years and may continue to fluctuate substantially in the future. We report our financial results in U.S. dollars and our results of operations have been and may
continue to be negatively impacted owing to appreciation of the Thai baht against the U.S. dollar. Smaller portions of our expenses are incurred in a variety of other currencies, including RMB, Canadian dollars, Euros, and Japanese yen, the
appreciation of which may also negatively impact our financial results.

[0001193125-15-172043:mdna:70]
In addition, we are exposed to foreign exchange risk in
connection with the credit facility and cross currency swap arrangements we entered into with TMB Bank Public Company Limited (the “Bank”) in May 2011 for the construction of Pinehurst Building 6. The terms of the contract with the Bank
provide the following facilities: (1) a term loan facility for up to Thai baht 960 million (equal to $30.0 million) with a fixed interest rate of 5.28% per annum, (2) a hedging facility for currency interest rate swaps with a
notional amount of $30.0 million, and (3) a settlement limit of Thai baht 65 million, subject to certain terms and conditions as set forth therein. Borrowings and interest under the term loan have been scheduled to be repaid on a quarterly
basis between September 2011 and March 2017. As of March 27, 2015, we had outstanding borrowings under the term loan facility of $12.0 million. Under the terms of the cross currency swap arrangement amounts drawn in Thai baht were converted to
U.S. dollars for repayment by us on a quarterly basis at the floating rate of 3-month London Interbank Offered Rate (LIBOR) plus 2.8% per annum.

[0001193125-15-172043:mdna:71]
In order to manage the risks arising from fluctuations in foreign currency exchange rates, we use derivative financial instruments. We may
enter into short-term forward exchange currency contracts or put option contracts to help manage currency exposures associated with certain assets and liabilities, primarily short-term obligations. The forward exchange contracts and put option
contracts generally had original maturities of one to six months, and no forward exchange contract or put option contract has had an original maturity greater than one year. All foreign currency exchange contracts are recognized on the condensed
consolidated balance sheet at fair value. As we do not apply hedge accounting to these instruments, the change in the fair value of the derivatives is recorded in foreign exchange (loss) gain, net on the condensed consolidated statements of
operations and comprehensive income. The gains and losses on our forward exchange contracts and put option contracts generally offset losses and gains on the assets, liabilities, and transactions economically hedged and, accordingly, generally do
not subject us to the risk of significant accounting losses.

[0001193125-15-172043:mdna:72]
We had foreign currency assets and liabilities in Thai baht and RMB as
follows:

[0001193125-15-172043:mdna:73]
|  |  | As of March 27, 2015 |  |  | As of June 27, 2014 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 535,823 |  |  | $ | 16,446 |  |  |  | 51.2 |  |  |  | 1,536,887 |  |  | $ | 47,318 |  |  |  | 79.6 |  |
| RMB |  |  | 96,250 |  |  |  | 15,677 |  |  |  | 48.8 |  |  |  | 74,813 |  |  |  | 12,156 |  |  |  | 20.4 |  |
| Total |  |  |  |  |  | $ | 32,123 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 59,474 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 901,342 |  |  | $ | 27,665 |  |  |  | 85.9 |  |  |  | 735,490 |  |  | $ | 22,644 |  |  |  | 81.1 |  |
| RMB |  |  | 27,991 |  |  |  | 4,559 |  |  |  | 14.1 |  |  |  | 32,512 |  |  |  | 5,283 |  |  |  | 18.9 |  |
| Total |  |  |  |  |  | $ | 32,224 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 27,927 |  |  |  | 100.0 |  |

[0001193125-15-172043:mdna:74]
26

[0001193125-15-172043:mdna:75]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and
other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets
and liabilities denominated in the same currency in accordance with management’s policy. As of March 27, 2015 and June 27, 2014, there were $45.0 million and $15.0 million, respectively, in put option contracts outstanding on the Thai
baht payables.

[0001193125-15-172043:mdna:76]
The RMB assets represent cash and cash equivalents, accounts receivable and other current assets. The RMB liabilities
represent trade accounts payable, accrued expenses and other payables. As of March 27, 2015 and June 27, 2014, we did not have any selling RMB to U.S. dollar forward or put option contracts.

[0001193125-15-172043:mdna:77]
As of March 27, 2015 and June 27, 2014, unrealized gain from the fair market value of derivatives amounted to $0.2 million and $0.1
million, respectively.

[0001193125-15-172043:mdna:78]
[same as prior period, unchanged from 0001193125-15-031475:mdna:74]

[0001193125-15-172043:mdna:79]
[same as prior period, unchanged from 0001193125-15-031475:mdna:75]

[0001193125-15-172043:mdna:80]
[same as prior period, unchanged from 0001193125-15-031475:mdna:76]

[0001193125-15-172043:mdna:81]
[same as prior period, unchanged from 0001193125-15-031475:mdna:77]

[0001193125-15-172043:mdna:82]
[same as prior period, unchanged from 0001193125-15-031475:mdna:78]

[0001193125-15-172043:mdna:83]
[same as prior period, unchanged from 0001193125-15-031475:mdna:79]

[0001193125-15-172043:mdna:84]
[same as prior period, unchanged from 0001193125-15-031475:mdna:80]

[0001193125-15-172043:mdna:85]
Circular 142 regulates the conversion by a foreign-invested company of foreign currency into RMB by
restricting how the converted RMB may be used. Circular 142 requires that the registered capital of a foreign-invested enterprise settled in RMB converted from foreign currencies may only be used for purposes within the business scope approved by
the applicable governmental authority and may not be used for equity investments within the PRC. In addition, SAFE strengthened its oversight of the flow and use of the registered capital of foreign-invested enterprises settled in RMB converted from
foreign currencies. The use of such RMB capital may not be changed without SAFE’s approval and may not be used to repay RMB loans if the proceeds of such loans have not been used.

[0001193125-15-172043:mdna:86]
[same as prior period, unchanged from 0001193125-15-031475:mdna:82]

[0001193125-15-172043:mdna:87]
[same as prior period, unchanged from 0001193125-15-031475:mdna:83]

[0001193125-15-172043:mdna:88]
[same as prior period, unchanged from 0001193125-15-031475:mdna:84]

[0001193125-15-172043:mdna:89]
[same as prior period, unchanged from 0001193125-15-031475:mdna:85]

[0001193125-15-172043:mdna:90]
[same as prior period, unchanged from 0001193125-15-031475:mdna:86]

[0001193125-15-172043:mdna:91]
Throughout the period of our
operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption is currently available to us from
July 2010 through June 2015 on income generated from the manufacture of products at Pinehurst Building 5 and from July 2012 through June 2020 on income generated from the manufacture of products at Pinehurst Building 6. Such preferential tax
treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years. Additionally,
in December 2011, the Thailand Revenue Department announced a reduction in corporate income tax rates for tax periods beginning on or after January 1, 2012. As a result of the announcement, corporate income tax rates for our Thai subsidiary
were reduced from 30% in fiscal year 2012 to 23% in fiscal year 2013, and 20% in fiscal year 2014 and fiscal year 2015. In November 2014, the Thailand Revenue Department announced an extension of the 20% corporate income tax rate for another year to
fiscal year 2016.

[0001193125-15-172043:mdna:92]
Our subsidiary in China had been granted a tax privilege to reduce its corporate income tax rate from 25% to 15% but
the privilege expired on December 31, 2013.

[0001193125-15-172043:mdna:93]
[same as prior period, unchanged from 0001193125-15-031475:mdna:90]

[0001193125-15-172043:mdna:94]
[same as prior period, unchanged from 0001193125-15-031475:mdna:91]

[0001193125-15-172043:mdna:95]
Our critical accounting policies
are disclosed in our Annual Report on Form 10-K for the fiscal year ended June 27, 2014. During the second quarter of fiscal year 2015, we invested in marketable securities. The accounting policy is disclosed in Note 4 of the Notes to our
unaudited condensed consolidated financial statements. In addition, a portion of our revenue is generated from consignment inventory segregated and stored on our customer’s request at a secure designated warehouse. The accounting policy
relating to this revenue is further disclosed in Note 2 of the Notes to our unaudited condensed consolidated financial statements under the revenue recognition section of such note.

[0001193125-15-172043:mdna:96]
[same as prior period, unchanged from 0001193125-15-031475:mdna:93]

[0001193125-15-172043:mdna:97]
[same as prior period, unchanged from 0001193125-15-031475:mdna:94]

[0001193125-15-172043:mdna:98]
| (amount in thousands) |  | Three Months Ended |  |  | Nine Months Ended |  |
|  | March 27,2015 |  |  | March 28,2014 |  |  | March 27,2015 |  |  | March 28,2014 |  |
| Revenues |  | $ | 189,453 |  |  | $ | 167,657 |  |  | $ | 567,131 |  |  | $ | 517,770 |  |
| Cost of revenues |  |  | (167,796 | ) |  |  | (150,374 | ) |  |  | (503,907 | ) |  |  | (461,312 | ) |
| Gross profit |  |  | 21,657 |  |  |  | 17,283 |  |  |  | 63,224 |  |  |  | 56,458 |  |
| Selling, general and administrative expenses |  |  | (9,670 | ) |  |  | (7,352 | ) |  |  | (28,721 | ) |  |  | (20,959 | ) |
| Expenses related to reduction in workforce |  |  | — |  |  |  | — |  |  |  | (1,153 | ) |  |  | — |  |
| Income related to flooding, net |  |  | — |  |  |  | 38,151 |  |  |  | — |  |  |  | 44,748 |  |
| Operating income |  |  | 11,987 |  |  |  | 48,082 |  |  |  | 33,350 |  |  |  | 80,247 |  |
| Interest income |  |  | 258 |  |  |  | 560 |  |  |  | 956 |  |  |  | 1,262 |  |
| Interest expense |  |  | (125 | ) |  |  | (172 | ) |  |  | (375 | ) |  |  | (566 | ) |
| Foreign exchange (loss) gain, net |  |  | (87 | ) |  |  | (254 | ) |  |  | (110 | ) |  |  | 46 |  |
| Other (expense) income |  |  | (75 | ) |  |  | 173 |  |  |  | (106 | ) |  |  | 544 |  |
| Income before income taxes |  |  | 11,958 |  |  |  | 48,389 |  |  |  | 33,715 |  |  |  | 81,533 |  |
| Income tax expense |  |  | (1,113 | ) |  |  | (727 | ) |  |  | (3,108 | ) |  |  | (135 | ) |
| Net income |  |  | 10,845 |  |  |  | 47,662 |  |  |  | 30,607 |  |  |  | 81,398 |  |
| Other comprehensive income |  |  | 512 |  |  |  | — |  |  |  | 26 |  |  |  | — |  |
| Net comprehensive income |  | $ | 11,357 |  |  | $ | 47,662 |  |  | $ | 30,633 |  |  | $ | 81,398 |  |

[0001193125-15-172043:mdna:99]
The following table sets forth a summary of our unaudited condensed consolidated statements of operations and
comprehensive income as a percentage of total revenues for the periods indicated.

[0001193125-15-172043:mdna:100]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 27,2015 |  |  | March 28,2014 |  |  | March 27,2015 |  |  | March 28,2014 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (88.6 | ) |  |  | (89.7 | ) |  |  | (88.8 | ) |  |  | (89.1 | ) |
| Gross profit |  |  | 11.4 |  |  |  | 10.3 |  |  |  | 11.2 |  |  |  | 10.9 |  |
| Selling, general and administrative expenses |  |  | (5.1 | ) |  |  | (4.4 | ) |  |  | (5.1 | ) |  |  | (4.0 | ) |
| Expenses related to reduction in workforce |  |  | — |  |  |  | — |  |  |  | (0.2 | ) |  |  | — |  |
| Income related to flooding, net |  |  | — |  |  |  | 22.8 |  |  |  | — |  |  |  | 8.6 |  |
| Operating income |  |  | 6.3 |  |  |  | 28.7 |  |  |  | 5.9 |  |  |  | 15.5 |  |
| Interest income |  |  | 0.2 |  |  |  | 0.3 |  |  |  | 0.2 |  |  |  | 0.2 |  |
| Interest expense |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | (0.1 | ) |
| Foreign exchange (loss) gain, net |  |  | (0.1 | ) |  |  | (0.2 | ) |  |  | (0.0 | ) |  |  | 0.0 |  |
| Other (expense) income |  |  | (0.0 | ) |  |  | 0.1 |  |  |  | (0.0 | ) |  |  | 0.1 |  |
| Income before income taxes |  |  | 6.3 |  |  |  | 28.8 |  |  |  | 5.9 |  |  |  | 15.7 |  |
| Income tax expense |  |  | (0.6 | ) |  |  | (0.4 | ) |  |  | (0.6 | ) |  |  | 0.0 |  |
| Net income |  |  | 5.7 |  |  |  | 28.4 |  |  |  | 5.4 |  |  |  | 15.7 |  |
| Other comprehensive income |  |  | 0.3 |  |  |  | — |  |  |  | 0.0 |  |  |  | — |  |
| Net comprehensive income |  |  | 6.0 | % |  |  | 28.4 | % |  |  | 5.4 | % |  |  | 15.7 | % |

[0001193125-15-172043:mdna:101]
[same as prior period, unchanged from 0001193125-15-031475:mdna:98]

[0001193125-15-172043:mdna:102]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27,2015 |  |  | March 28,2014 |  |  | March 27,2015 |  |  | March 28,2014 |  |
| Optical communications |  | $ | 136,537 |  |  | $ | 119,770 |  |  | $ | 405,600 |  |  | $ | 374,040 |  |
| Lasers, sensors and other |  |  | 52,916 |  |  |  | 47,887 |  |  |  | 161,531 |  |  |  | 143,730 |  |
| Total |  | $ | 189,453 |  |  | $ | 167,657 |  |  | $ | 567,131 |  |  | $ | 517,770 |  |

[0001193125-15-172043:mdna:103]
[same as prior period, unchanged from 0001193125-15-031475:mdna:100]

[0001193125-15-172043:mdna:104]
29

[0001193125-15-172043:mdna:105]
Comparison of Three and Nine Months Ended March 27, 2015 with Three and Nine Months Ended
March 28, 2014

[0001193125-15-172043:mdna:106]
[same as prior period, unchanged from 0001193125-15-031475:mdna:102]

[0001193125-15-172043:mdna:107]
Our total revenues increased by $21.8 million, or 13.0%, to $189.5 million for the three months ended March 27, 2015, compared with $167.7
million for the three months ended March 28, 2014. This increase was primarily due to an increase in customers’ demand for both optical and non-optical communications manufacturing services during the three months ended March 27,
2015. Revenues from optical communications products represented 72.1% of our total revenues for the three months ended March 27, 2015, compared to 71.4% for the three months ended March 28, 2014.

[0001193125-15-172043:mdna:108]
Our total revenues increased by $49.4 million, or 9.5%, to $567.1 million for the nine months ended March 27, 2015, compared with $517.8
million for the nine months ended March 28, 2014. This increase was primarily due to an increase in customers’ demand for both optical and non-optical communications manufacturing services during the nine months ended March 27, 2015.
Revenues from optical communications products represented 71.5% of our total revenues for the nine months ended March 27, 2015, compared to 72.2% for the nine months ended March 28, 2014.

[0001193125-15-172043:mdna:109]
[same as prior period, unchanged from 0001193125-15-031475:mdna:105]

[0001193125-15-172043:mdna:110]
Our
cost of revenues increased by $17.4 million, or 11.6%, to $167.8million, or 88.6% of total revenues, for the three months ended March 27, 2015, compared with $150.4 million, or 89.7% of total revenues, for the three months ended March 28,
2014. The percentage increase in cost of revenues was lower in percentage terms as compared with the percentage increase of total revenues primarily due to a change in favorable product mix during the three months ended March 27, 2015. Cost of
revenues also included share-based compensation expense of $0.4 million for the three months ended March 27, 2015, compared with $0.3 million for the three months ended March 28, 2014.

[0001193125-15-172043:mdna:111]
Our cost of revenues increased by $42.6 million, or 9.2%, to $504.0 million, or 88.9% of total revenues, for the nine months ended
March 27, 2015, compared with $461.3 million, or 89.1% of total revenues, for the nine months ended March 28, 2014. The percentage increase in cost of revenue was lower in percentage terms as compared with the percentage increase of total
revenues primarily due to a change in favorable product mix during the nine months ended March 27, 2015. Cost of revenues also included share-based compensation expense of $1.1 million for the nine months ended March 27, 2015, compared
with $0.9 million for the nine months ended March 28, 2014.

[0001193125-15-172043:mdna:112]
[same as prior period, unchanged from 0001193125-15-031475:mdna:108]

[0001193125-15-172043:mdna:113]
Our gross profit increased by $4.4 million, or 25.3%, to $21.7 million, or 11.4% of total revenues, for the three months ended March 27,
2015, compared with $17.3 million, or 10.3% of total revenues, for the three months ended March 28, 2014. Our gross profit increased by $6.8 million, or 12.0%, to $63.2 million, or 11.2% of total revenues, for the nine months ended
March 27, 2015, compared with $56.5 million, or 10.9% of total revenues, for the nine months ended March 28, 2014.

[0001193125-15-172043:mdna:114]
The
improvement in gross profit margin during the three and nine months ended March 27, 2015, compared with the three and nine months ended March 28, 2014, was related to the change in product mix during the three and nine months ended
March 27, 2015.

[0001193125-15-172043:mdna:115]
[same as prior period, unchanged from 0001193125-15-031475:mdna:111]

[0001193125-15-172043:mdna:116]
Our SG&A expenses increased by $2.3 million, or 31.1%, to $9.6 million, or 5.1% of total revenues, for the three months ended
March 27, 2015, compared with $7.4 million, or 4.4% of total revenues, for the three months ended March 28, 2014. Our SG&A expenses increased in absolute dollars and as a percentage of revenue due primarily to an increase in executive
salaries and other benefits of $0.5 million, an increase in expenses relating to our new facility in the United States of $1.1 million, and an increase in sales and marketing expenses of $0.2 million. We also recorded share-based compensation
charges of $1.6 million for the three months ended March 27, 2015, compared with $1.2 million for the three months ended March 28, 2014.

[0001193125-15-172043:mdna:117]
Our SG&A expenses increased by $7.7 million, or 36.9%, to $28.7 million, or 5.1% of total
revenues, for the nine months ended March 27, 2015, compared with $21.0 million, or 4.0% of total revenues, for the nine months ended March 28, 2014. Our SG&A expenses increased in absolute dollars and as a percentage of revenue due
primarily to $4.1 million in costs relating to our Audit Committee investigation concerning various accounting cut-off issues in fiscal year 2014, an increase in expenses relating to our new facility in the United States of $1.1 million, and an
increase in sales and marketing expenses of $1.1 million. We also recorded share-based compensation charges of $4.7 million for the nine months ended March 27, 2015, compared with $3.7 million for the nine months ended March 28, 2014.

[0001193125-15-172043:mdna:118]
Expenses related to reduction in workforce.

[0001193125-15-172043:mdna:119]
During the nine months ended March 27, 2015, we implemented a reduction in workforce and incurred expenses of approximately $1.2 million
which represented severance and benefits costs associated with the termination of approximately 100 employees in accordance with contractual obligations and local regulations.

[0001193125-15-172043:mdna:120]
[same as prior period, unchanged from 0001193125-15-031475:mdna:116]

[0001193125-15-172043:mdna:121]
In the three months ended March 27, 2015, we did not have income related to flooding. In the three months ended March 28, 2014, we
recognized $38.6 million of income related to flooding, which consisted of a final payment from our insurers against our claim for owned and customer-owned equipment and inventory, offsets by a recognition of $0.5 million of other expenses from
write-offs of advance payments to a customer due to flood losses.

[0001193125-15-172043:mdna:122]
In the nine months ended March 27, 2015, we did not have income
related to flooding. In the nine months ended March 28, 2014, we recognized $45.2 million of income related to flooding, which consisted of payments from our insurers against our claim for owned and customer-owned equipment and inventory,
offsets by a recognition of $0.5 million of other expenses from write-offs of advance payments to a customer due to flood losses.

[0001193125-15-172043:mdna:123]
[same as prior period, unchanged from 0001193125-15-031475:mdna:118]

[0001193125-15-172043:mdna:124]
Our
operating income decreased by $36.1 million to $12.0 million, or 6.3% of total revenues, for the three months ended March 27, 2015, compared with $48.1 million, or 28.7% of total revenues, for the three months ended March 28, 2014.

[0001193125-15-172043:mdna:125]
Our operating income decreased by $46.9 million to $33.4 million, or 5.9% of total revenues, for the nine months ended March 27, 2015,
compared with $80.2 million, or 15.5% of total revenues, for the nine months ended March 28, 2014.

[0001193125-15-172043:mdna:126]
[same as prior period, unchanged from 0001193125-15-031475:mdna:121]

[0001193125-15-172043:mdna:127]
Our interest income decreased by $0.3 million to $0.3 million, or 0.1% of total revenues, for the three months ended March 27, 2015,
compared with $0.6 million for the three months ended March 28, 2014. Our interest income decreased by $0.3 million to $1.0 million, or 0.2% of total revenue, for the nine months ended March 27, 2015, compared with $1.3 million for the
nine months ended March 28, 2014.

[0001193125-15-172043:mdna:128]
Interest expense.

[0001193125-15-172043:mdna:129]
Our interest expense decreased by $0.1 million to $0.1 million for the three months ended March 27, 2015, compared with $0.2 million for
the three months ended March 28, 2014. Our interest expense decreased by $0.2 million to $0.4 million for the nine months ended March 27, 2015, compared with $0.6 million for the nine months ended March 28, 2014. These decreases were
due to a decrease in our average long-term loan balances resulting from repayment during the fourth quarter of fiscal year 2014.

[0001193125-15-172043:mdna:130]
[same as prior period, unchanged from 0001193125-15-031475:mdna:125]

[0001193125-15-172043:mdna:131]
We recorded income before income taxes of $12.0 million and $33.7 million for the three and nine months ended March 27, 2015,
respectively, compared with income before income taxes of $48.4 million and $81.5 million for the three and nine months ended March 28, 2014, respectively.

[0001193125-15-172043:mdna:132]
[same as prior period, unchanged from 0001193125-15-031475:mdna:127]

[0001193125-15-172043:mdna:133]
Our
provision for income tax reflects an effective tax rate of 9.3% for the three months ended March 27, 2015, compared with an effective tax rate of 1.5% for the three months ended March 28, 2014. The increase was primarily due to the fact
that we had higher taxable income during the three months ended March 27, 2015 as compared to the three months ended March 28, 2014 because the income related to flooding of $38.2 million that was recognized during the three months ended
March 28, 2014 was not subject to income tax.

[0001193125-15-172043:mdna:134]
Our provision for income tax reflects an effective tax rate of 9.2% for the nine months ended
March 27, 2015, compared with an effective tax rate of 0.2% for the nine months ended March 28, 2014. The increase was primarily due to the fact that we had higher taxable income during the nine months ended March 27, 2015 as compared
to the nine months ended March 28, 2014 because the income related to flooding of $44.7 million that was recognized during the nine months ended March 28, 2014 was not subject to income tax. This impact was offset with the reversal of
liabilities for uncertain tax positions, including accrued interest of $1.5 million in the nine months ended March 27, 2015 and an increase in deferred tax assets of $0.6 million from the increase in the income tax rate of the Company’s
subsidiary in China from 15% in the nine months ended March 28, 2014 to 25% in the nine months ended March 27, 2015 due to the expiration of a tax privilege.

[0001193125-15-172043:mdna:135]
[same as prior period, unchanged from 0001193125-15-031475:mdna:130]

[0001193125-15-172043:mdna:136]
We recorded
net income of $10.8 million, or 5.7% of total revenues, for the three months ended March 27, 2015, compared with $47.7 million, or 28.4% of total revenues, for the three months ended March 28, 2014.

[0001193125-15-172043:mdna:137]
We recorded net income of $30.6 million, or 5.4% of total revenues, for the nine months ended March 27, 2015, compared with $81.4
million, or 15.7% of total revenues, for the nine months ended March 28, 2014.

[0001193125-15-172043:mdna:138]
Other comprehensive income.

[0001193125-15-172043:mdna:139]
We recorded other comprehensive income related to accumulated net unrealized gain on available-for-sale investments of $0.5 million and $0.02
million for the three and nine months ended March 27, 2015, respectively.

[0001193125-15-172043:mdna:140]
[same as prior period, unchanged from 0001193125-15-031475:mdna:135]

[0001193125-15-172043:mdna:141]
[same as prior period, unchanged from 0001193125-15-031475:mdna:136]

[0001193125-15-172043:mdna:142]
We primarily finance our operations through cash flow from operations. As of March 27, 2015 and March 28, 2014, we had cash, cash
equivalents, and marketable securities of $254.3 million and $233.5 million, respectively, and outstanding debt of $42.0 million and $21.7 million, respectively.

[0001193125-15-172043:mdna:143]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of
three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents for the three and nine months ended March 27, 2015 was 0.7% and 0.6%, respectively, and for the
three and nine months ended March 28, 2014 was 1.1% and 1.0%, respectively.

[0001193125-15-172043:mdna:144]
Our cash investments are made in accordance with an
investment policy approved by the Audit Committee of our Board of Directors. In general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years.
Our investments in fixed income securities are primarily classified as available-for-sale securities and are recorded at fair value. The cost of securities sold is based on the specific identification method. Unrealized gains and losses on these
securities are recorded as other comprehensive income (loss) and are reported as a separate component of shareholders’ equity.

[0001193125-15-172043:mdna:145]
As of
June 27, 2014, all claims that we submitted to our insurance companies for flood related losses had been settled. We recognized $38.6 million and $45.2 million as income related to flooding in the three and nine months ended March 28,
2014, respectively, towards full and final settlement of our owned and consigned equipment and inventory claims. This income was offset by the recognition of $0.5 million of other expense in connection with write-offs of advance payments to a
customer due to flood losses.

[0001193125-15-172043:mdna:146]
During the nine months ended March 28, 2014, we made a cash payment of $5.2 million and transferred
equipment, with an aggregate value of $2.3 million, to a customer towards full and final settlement for flood-related losses incurred by this customer in accordance with the settlement agreement entered into during fiscal 2013 with such customer. In
addition, during the nine months ended March 28, 2014, we fulfilled our obligations to a customer’s insurers by making a payment of $2.2 million for full and final settlement of our liability to such insurer for damages to customer-owned
inventory that occurred during the flooding, in accordance with a settlement agreement entered into during fiscal year 2013 with such insurer. We also made a cash payment of $0.1 million towards other flood-related settlements during the nine months
ended March 28, 2014.

[0001193125-15-172043:mdna:147]
We believe that our current cash and cash equivalents, marketable securities, cash flow from
operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that
we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001193125-15-172043:mdna:148]
We believe that our current manufacturing capacity,
including our new facility in the United States, is sufficient to meet our anticipated production requirements for at least the next 12 months. We maintain a long-term credit facility associated with construction of production facilities at our
Pinehurst campus in Thailand that will come due within the next 24 months. We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay this obligation.

[0001193125-15-172043:mdna:149]
The following table shows our cash flows for the periods indicated:

[0001193125-15-172043:mdna:150]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27,2015 |  |  | March 28,2014 |  |
| Net cash provided by operating activities |  | $ | 40,481 |  |  | $ | 58,604 |  |
| Net cash (used in) provided by investing activities |  | $ | (169,159 | ) |  | $ | 30,515 |  |
| Net cash provided by (used in) financing activities |  | $ | 24,122 |  |  | $ | (3,493 | ) |
| Net (decrease) increase in cash and cash equivalents |  | $ | (104,556 | ) |  | $ | 85,626 |  |
| Cash and cash equivalent, beginning of period |  | $ | 233,477 |  |  | $ | 149,716 |  |
| Cash and cash equivalents, end of period |  | $ | 128,946 |  |  | $ | 233,664 |  |

[0001193125-15-172043:mdna:151]
[same as prior period, unchanged from 0001193125-15-031475:mdna:146]

[0001193125-15-172043:mdna:152]
Net cash provided by operating activities decreased by $18.1 million, or 30.9%, to $40.5 million for the nine months ended March 27, 2015,
compared with net cash provided by operating activities of $58.6 million for the nine months ended March 28, 2014. This decrease was due to a number of factors, including a decrease of $50.8 million in net income from the period, against which
the income from flooding of $45.2 million in fiscal 2014 needs to be offset, a decrease of $7.4 million in the proceeds from insurers for the final settlement of inventory losses related to flooding, a decrease in changes in accounts payable of
$16.2 million and a decrease in collections from customers of $ 18.9 million, an increase in the changes in inventory of $ 17.1 million to support customer demands in the subsequent quarter and an increase in changes in final settlement of
flood-related liabilities to third parties in the third quarter of fiscal year 2014 of $7.5 million.

[0001193125-15-172043:mdna:153]
[same as prior period, unchanged from 0001193125-15-031475:mdna:148]

[0001193125-15-172043:mdna:154]
Net cash used in investing activities increased by $199.7 million, or 654.3%, to $169.2 million for the nine months ended March 27, 2015,
compared with net cash provided in investing activities of $30.5 million for the nine months ended March 28, 2014. This increase in net cash used in investing activities was primarily due to an increase of $126.2 million in available-for-sale
securities and an increase of $35.7 million in purchase of property, plant, and equipment for the purpose of expanding our manufacturing operations in the United States, as well as a decrease of $37.8 million in proceeds from insurers in settlement
of claims related to flood damage.

[0001193125-15-172043:mdna:155]
[same as prior period, unchanged from 0001193125-15-031475:mdna:150]

[0001193125-15-172043:mdna:156]
Net cash provided by financing activities increased by $27.6 million, or 790.6%, to $24.1 million for the nine months ended March 27,
2015, compared with net cash used in financing activities of $3.5 million for the nine months ended March 28, 2014. This increase in net cash provided by financing activities was primarily due to an increase in proceeds from a revolving loan of
$30.0 million to purchase land and a building in the United States and a decrease of $3.2 million in proceeds from the issuance of ordinary shares under employee share option plans, offset by the payment of debt issuance costs of $1.8 million from
our credit facility agreement and a decrease in repayment of the Company’s long-term loans of $2.8 million due to the payment to extinguish one of the long-term loan contracts in April 2014.

[0001193125-15-172043:mdna:157]
[same as prior period, unchanged from 0001193125-15-031475:mdna:152]

[0001193125-15-172043:mdna:158]
[same as prior period, unchanged from 0001193125-15-031475:mdna:153]

[0001193125-15-172043:mdna:159]
[same as prior period, unchanged from 0001193125-15-031475:mdna:154]

[0001193125-15-172043:mdna:160]
See Note 2 of Notes to Unaudited Condensed Consolidated Financial Statements for recent accounting pronouncements that could have an effect on
us.
