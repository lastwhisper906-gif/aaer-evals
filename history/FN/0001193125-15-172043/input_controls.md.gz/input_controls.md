# FN 10-Q controls and the auditor's report


## item_4_controls

[0001193125-15-172043:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0001193125-15-172043:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001193125-15-172043:item_4_controls:3]
Our management is responsible for establishing and maintaining disclosure controls and procedures designed to ensure that the information we are required to
disclose in reports we file or submit under the Securities Exchange Act of 1934, as amended (“Exchange Act”), (i) is recorded, processed, summarized, and reported within time periods specified in the rules and forms of the Securities
and Exchange Commission, and (ii) is accumulated and communicated to Fabrinet’s management, including our Chief Executive Officer (“CEO”) and Chief Financial Officer (“CFO”), as appropriate, to allow timely decisions
regarding required disclosure.

[0001193125-15-172043:item_4_controls:4]
Our management, including our CEO and CFO, evaluated the effectiveness of our disclosure controls and procedures (as
defined in Rule 13a-15(e) of the Exchange Act), as of March 27, 2015, the end of the period covered by this Quarterly Report on Form 10-Q. Disclosure controls and procedures include, without limitation, controls and procedures designed to
ensure that information required to be disclosed by a company in the reports that it files or submits under the Exchange Act is accumulated and communicated to the Company’s management, including its principal executive and principal financial
officers, as appropriate to allow timely decisions regarding required disclosure. Based on their evaluation, our CEO and CFO concluded that the Company’s disclosure controls and procedures were not effective as of that date.

[0001193125-15-172043:item_4_controls:5]
Remediation Steps

[0001193125-15-172043:item_4_controls:6]
As disclosed in our Annual
Report for the fiscal year ended June 27, 2014, we identified a material weakness in our internal control over financial reporting such that our disclosure controls and procedures related to revenue recognition for certain volume supply
agreements with our customers were not effective. Specifically, we determined that we did not apply appropriate U.S. GAAP knowledge and expertise when assessing the terms of these arrangements with respect to when title and risk of loss transfers to
our customers.

[0001193125-15-172043:item_4_controls:7]
35

[0001193125-15-172043:item_4_controls:8]
During the third quarter of fiscal year 2015, our management, under the supervision of our CEO and CFO, undertook
the following actions intended to remedy this material weakness, and to improve our control processes and procedures with respect to revenue recognition:

[0001193125-15-172043:item_4_controls:9]
|  | • |  | We have engaged a technical accounting consultant to enhance awareness and understanding of U.S. GAAP standards and principles related to relevant technical accounting topics, especially revenue recognition and cut-off criteria. We also will continue to enhance our technical accounting training, led by appropriate technical accounting experts to improve awareness and understanding of all relevant accounting standards to ensure compliance with U.S. GAAP. |

[0001193125-15-172043:item_4_controls:10]
|  | • |  | We conducted mandatory revenue recognition training for our management staff using a third party advisor. The training focused on the scope and application of our policy concerning revenue recognition. |

[0001193125-15-172043:item_4_controls:11]
|  | • |  | We are implementing procedures to ensure that significant existing customer contracts and other contracts undergo a comprehensive review to ensure that the financial accounting for such contracts is in compliance with U.S. GAAP and that the contracts properly reflect our current business practices. |

[0001193125-15-172043:item_4_controls:12]
|  | • |  | We are implementing procedures to ensure that all new customer and other new significant contracts undergo a comprehensive review at inception to ensure that the financial accounting for such contracts is in compliance with U.S. GAAP and that the contracts properly reflect our current business practices. |

[0001193125-15-172043:item_4_controls:13]
|  | • |  | All contracts covered above will be reviewed on a quarterly basis to ensure that the existing applicability of the accounting treatment under U.S. GAAP remains appropriate. |

[0001193125-15-172043:item_4_controls:14]
We believe that these remedial steps represent significant improvements to our internal controls. We will continue to assess the effectiveness of our
remediation efforts in connection with our evaluations of internal control over financial reporting. If not fully remediated, further remediation measures may be required, which may result in additional implementation time. In addition, under the
direction of the Audit Committee, management will continue to review and make necessary changes to the overall design of the system of internal controls, and the control environment, to improve the overall effectiveness of internal control over
financial reporting.

[0001193125-15-172043:item_4_controls:15]
Changes in Internal Control over Financial Reporting

[0001193125-15-172043:item_4_controls:16]
Other than as discussed above, there have been no changes in the Company’s internal control over financial reporting during the three months ended
March 27, 2015 that materially affected, or are reasonably likely to materially affect, the Company’s internal control over financial reporting.

[0001193125-15-172043:item_4_controls:17]
36
