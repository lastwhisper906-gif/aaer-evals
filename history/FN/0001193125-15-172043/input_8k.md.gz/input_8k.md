# FN 8-K — 0001193125-15-169069 filed 2015-05-04

## item codes, every 8-K on or before 2015-05-05

- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2015-05-05

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-169069:8k_2_02:1]
EX-99.1
2
d918617dex991.htm
EX-99.1

[0001193125-15-169069:8k_2_02:2]
EX-99.1

[0001193125-15-169069:8k_2_02:3]
Exhibit 99.1

[0001193125-15-169069:8k_2_02:4]
Fabrinet Announces Third Quarter Fiscal 2015 Financial Results

[0001193125-15-169069:8k_2_02:5]
BANGKOK, Thailand – May 4, 2015 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical,
electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for the third quarter ended March 27, 2015.

[0001193125-15-169069:8k_2_02:6]
Fabrinet reported total revenue of $189.5 million for the third quarter of fiscal 2015, an increase of 13% compared to total revenue of $167.7 million for the
comparable period in fiscal 2014. GAAP net income for the third quarter of fiscal 2015 was $10.8 million, or $0.30 per diluted share, compared to GAAP net income of $47.7 million, or $1.33 per diluted share, in the third quarter of fiscal 2014. GAAP
net income for the third quarter of fiscal 2014 was positively impacted by $38.2 million, or $1.07 per diluted share, due to the collection of final insurance proceeds. Non-GAAP net income in the third quarter of fiscal 2015 was $13.0 million, or
$0.36 per diluted share, compared to non-GAAP net income of $12.3 million, or $0.34 per diluted share, in the same period a year ago.

[0001193125-15-169069:8k_2_02:7]
Tom Mitchell, Chief
Executive Officer of Fabrinet, said, “Our third quarter results were solid, with revenue and EPS ahead of our expectations. Our initiatives to expand our new product introduction and advanced packaging capabilities are well underway and we are
on track to ship our first products from our new west coast facility in the current quarter.”

[0001193125-15-169069:8k_2_02:8]
Business Outlook

[0001193125-15-169069:8k_2_02:9]
Based on information available as of May 4, 2015, Fabrinet is issuing guidance for the fourth quarter of fiscal 2015 as follows:

[0001193125-15-169069:8k_2_02:10]
Fabrinet expects fourth quarter revenue to be in the range of $195 million to $199 million. GAAP net income per share is expected to be in the range of $0.33
to $0.35 with expected non-GAAP net income per share of $0.37 to $0.39, based on approximately 36 million fully diluted shares outstanding.

[0001193125-15-169069:8k_2_02:11]
Conference Call Information

[0001193125-15-169069:8k_2_02:12]
| What: |  | Fabrinet Third Quarter 2015 Financial Results Conference Call |
| When: |  | Monday, May 4, 2015 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic |
|  |  | (253) 237-1137, international |
|  |  | Passcode: 18428518 |
| Replay: |  | (855) 859-2056, domestic |
|  |  | (404) 537-3406, international |
|  |  | Passcode: 18428518 |
| Webcast: |  | http://investor.fabrinet.com (live and replay) |

[0001193125-15-169069:8k_2_02:13]
This press release and any other information related to the call will also be posted on Fabrinet’s website at
http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-15-169069:8k_2_02:14]
About Fabrinet

[0001193125-15-169069:8k_2_02:15]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original
equipment manufacturers of complex products, such as optical communication components, modules and subsystems, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire
manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and test. Fabrinet focuses on production of high complexity products in any mix and any volume.
Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the People’s Republic of China and the United States. For more information visit: www.fabrinet.com.

[0001193125-15-169069:8k_2_02:16]
Forward-Looking Statements

[0001193125-15-169069:8k_2_02:17]
Use of Non-GAAP
Financials

[0001193125-15-169069:8k_2_02:18]
The Company refers to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful
supplemental information regarding the Company’s ongoing operational performance. Non-GAAP net income excludes share-based compensation expenses, executive separation costs, and income (expense) related to flooding. We have excluded these items
in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP
financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001193125-15-169069:8k_2_02:19]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our
competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure company
performance for the purposes of determining employee incentive plan compensation.

[0001193125-15-169069:8k_2_02:20]
SOURCE: Fabrinet

[0001193125-15-169069:8k_2_02:21]
Investor Contact:

[0001193125-15-169069:8k_2_02:22]
Jennifer Predmore

[0001193125-15-169069:8k_2_02:23]
215-428-1797

[0001193125-15-169069:8k_2_02:24]
ir@fabrinet.com

[0001193125-15-169069:8k_2_02:25]
Fabrinet

[0001193125-15-169069:8k_2_02:26]
Consolidated Balance Sheets

[0001193125-15-169069:8k_2_02:27]
As of March 27, 2015 and June 27, 2014

[0001193125-15-169069:8k_2_02:28]
| (in thousands of U.S. dollars, except share data) |  | March 27,2015 |  |  | June 27,2014 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 128,946 |  |  | $ | 233,477 |  |
| Marketable securities |  |  | 125,398 |  |  |  | — |  |
| Trade accounts receivable, net |  |  | 120,054 |  |  |  | 101,168 |  |
| Inventory, net |  |  | 126,660 |  |  |  | 124,570 |  |
| Deferred tax assets |  |  | 1,486 |  |  |  | 1,561 |  |
| Prepaid expenses |  |  | 2,272 |  |  |  | 1,691 |  |
| Other current assets |  |  | 1,822 |  |  |  | 2,010 |  |
| Total current assets |  |  | 506,638 |  |  |  | 464,477 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 133,998 |  |  |  | 97,244 |  |
| Intangibles, net |  |  | 45 |  |  |  | 72 |  |
| Deferred tax assets |  |  | 1,690 |  |  |  | 1,775 |  |
| Deferred debt issuance cost |  |  | 2,573 |  |  |  | 989 |  |
| Total non-current assets |  |  | 138,306 |  |  |  | 100,080 |  |
| Total assets |  | $ | 644,944 |  |  | $ | 564,557 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Bank borrowings, including revolving loan and current portion of long-term loan from banks |  | $ | 36,000 |  |  | $ | 6,000 |  |
| Trade accounts payable |  |  | 103,053 |  |  |  | 94,853 |  |
| Equipment-related payable |  |  | 4,170 |  |  |  | 1,130 |  |
| Income tax payable |  |  | 979 |  |  |  | 1,024 |  |
| Accrued payroll, bonus and related expenses |  |  | 9,977 |  |  |  | 8,612 |  |
| Accrued expenses |  |  | 7,120 |  |  |  | 4,345 |  |
| Other payables |  |  | 6,258 |  |  |  | 4,665 |  |
| Total current liabilities |  |  | 167,557 |  |  |  | 120,629 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term loans from bank, non-current portion |  |  | 6,000 |  |  |  | 10,500 |  |
| Deferred tax liability |  |  | 1,017 |  |  |  | 1,040 |  |
| Severance liabilities |  |  | 5,001 |  |  |  | 4,453 |  |
| Other non-current liabilities |  |  | 1,691 |  |  |  | 1,099 |  |
| Total non-current liabilities |  |  | 13,709 |  |  |  | 17,092 |  |
| Total liabilities |  |  | 181,266 |  |  |  | 137,721 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of March 27, 2015 and June 27, 2014) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 35,426,140 shares and 35,152,772 shares issued and outstanding as of March 27, 2015 and June 27, 2014, respectively) |  |  | 354 |  |  |  | 352 |  |
| Additional paid-in capital |  |  | 87,088 |  |  |  | 80,882 |  |
| Retained earnings |  |  | 376,210 |  |  |  | 345,602 |  |
| Accumulated other comprehensive income |  |  | 26 |  |  |  | — |  |
| Total shareholders’ equity |  |  | 463,678 |  |  |  | 426,836 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 644,944 |  |  | $ | 564,557 |  |

[0001193125-15-169069:8k_2_02:29]
Fabrinet

[0001193125-15-169069:8k_2_02:30]
Consolidated Statements of Operations and Comprehensive Income

[0001193125-15-169069:8k_2_02:31]
For the three and nine months ended March 27, 2015 and March 28, 2014

[0001193125-15-169069:8k_2_02:32]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 27, |  |  | March 28, |  |  | March 27, |  |  | March 28, |  |
| (in thousands of U.S. dollars, except share data) |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Revenues |  | $ | 189,453 |  |  | $ | 167,657 |  |  | $ | 567,131 |  |  | $ | 517,770 |  |
| Cost of revenues |  |  | (167,796 | ) |  |  | (150,374 | ) |  |  | (503,907 | ) |  |  | (461,312 | ) |
| Gross profit |  |  | 21,657 |  |  |  | 17,283 |  |  |  | 63,224 |  |  |  | 56,458 |  |
| Selling, general and administrative expenses |  |  | (9,670 | ) |  |  | (7,352 | ) |  |  | (28,721 | ) |  |  | (20,959 | ) |
| Expenses related to reduction in workforce |  |  | — |  |  |  | — |  |  |  | (1,153 | ) |  |  | — |  |
| Income related to flooding, net |  |  | — |  |  |  | 38,151 |  |  |  | — |  |  |  | 44,748 |  |
| Operating income |  |  | 11,987 |  |  |  | 48,082 |  |  |  | 33,350 |  |  |  | 80,247 |  |
| Interest income |  |  | 258 |  |  |  | 560 |  |  |  | 956 |  |  |  | 1,262 |  |
| Interest expense |  |  | (125 | ) |  |  | (172 | ) |  |  | (375 | ) |  |  | (566 | ) |
| Foreign exchange (loss) gain, net |  |  | (87 | ) |  |  | (254 | ) |  |  | (110 | ) |  |  | 46 |  |
| Other (expense) income |  |  | (75 | ) |  |  | 173 |  |  |  | (106 | ) |  |  | 544 |  |
| Income before income taxes |  |  | 11,958 |  |  |  | 48,389 |  |  |  | 33,715 |  |  |  | 81,533 |  |
| Income tax expense |  |  | (1,113 | ) |  |  | (727 | ) |  |  | (3,108 | ) |  |  | (135 | ) |
| Net income |  |  | 10,845 |  |  |  | 47,662 |  |  |  | 30,607 |  |  |  | 81,398 |  |
| Other comprehensive income, before tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in fair value of marketable securities |  |  | 450 |  |  |  | — |  |  |  | (43 | ) |  |  | — |  |
| Less: Reclassification adjustment for net loss realized and included in net income |  |  | 62 |  |  |  | — |  |  |  | 69 |  |  |  | — |  |
| Total change in unrealized gain on marketable securities, before tax |  |  | 512 |  |  |  | — |  |  |  | 26 |  |  |  | — |  |
| Income tax expense related to items of other comprehensive income |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total other comprehensive income, net of tax |  |  | 512 |  |  |  | — |  |  |  | 26 |  |  |  | — |  |
| Net comprehensive income |  | $ | 11,357 |  |  | $ | 47,662 |  |  | $ | 30,633 |  |  | $ | 81,398 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.31 |  |  | $ | 1.36 |  |  | $ | 0.87 |  |  | $ | 2.33 |  |
| Diluted |  | $ | 0.30 |  |  | $ | 1.33 |  |  | $ | 0.85 |  |  | $ | 2.29 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 35,406 |  |  |  | 35,078 |  |  |  | 35,328 |  |  |  | 34,878 |  |
| Diluted |  |  | 36,110 |  |  |  | 35,790 |  |  |  | 35,871 |  |  |  | 35,504 |  |

[0001193125-15-169069:8k_2_02:33]
Fabrinet

[0001193125-15-169069:8k_2_02:34]
Consolidated Statements of Cash Flows

[0001193125-15-169069:8k_2_02:35]
For the nine months ended March 27, 2015 and March 28, 2014

[0001193125-15-169069:8k_2_02:36]
|  |  | Nine Months Ended |  |
|  |  | March 27, |  |  | March 28, |  |
| (in thousands of U. S. dollars) |  | 2015 |  |  | 2014 |  |
| Cash flows from operating activities |  |  |  |  |  |
| Net income for the period |  | $ | 30,607 |  |  | $ | 81,398 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 9,261 |  |  |  | 7,685 |  |
| Amortization of intangibles |  |  | 61 |  |  |  | 72 |  |
| Loss from sales and maturities of available-for-sale securities |  |  | 62 |  |  |  | — |  |
| Gain on disposal of property, plant and equipment |  |  | (41 | ) |  |  | (1 | ) |
| Amortization of investment premium |  |  | 757 |  |  |  | — |  |
| Amortization of deferred debt issuance costs |  |  | 377 |  |  |  | — |  |
| Income related to flooding |  |  | — |  |  |  | (45,211 | ) |
| Proceeds from insurers for inventory losses related to flooding |  |  | — |  |  |  | 7,416 |  |
| Reversal of allowance for doubtful accounts |  |  | 3 |  |  |  | (62 | ) |
| Unrealized (gain) loss on exchange rate and fair value of derivative |  |  | (55 | ) |  |  | 1,027 |  |
| Share-based compensation |  |  | 5,806 |  |  |  | 4,538 |  |
| Deferred income tax |  |  | 137 |  |  |  | (132 | ) |
| Other non-cash expenses |  |  | 1,141 |  |  |  | 255 |  |
| Reversal of uncertain tax positions |  |  | — |  |  |  | (1,538 | ) |
| Inventory obsolescence |  |  | 332 |  |  |  | 673 |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | (18,889 | ) |  |  | 37 |  |
| Inventory |  |  | (2,422 | ) |  |  | (19,537 | ) |
| Other current assets and non-current assets |  |  | (574 | ) |  |  | (889 | ) |
| Trade accounts payable |  |  | 8,200 |  |  |  | 24,392 |  |
| Income tax payable |  |  | (45 | ) |  |  | 351 |  |
| Other current liabilities and non-current liabilities |  |  | 5,763 |  |  |  | 5,642 |  |
| Liabilities to third parties due to flood losses |  |  | — |  |  |  | (7,512 | ) |
| Net cash provided by operating activities |  |  | 40,481 |  |  |  | 58,604 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of available-for-sale securities |  |  | (159,396 | ) |  |  | — |  |
| Proceeds from sales of available-for-sale securities |  |  | 22,873 |  |  |  | — |  |
| Proceeds from maturities of available-for-sale securities |  |  | 10,332 |  |  |  | — |  |
| Purchase of property, plant and equipment |  |  | (42,980 | ) |  |  | (7,280 | ) |
| Purchase of intangibles |  |  | (34 | ) |  |  | (1 | ) |
| Proceeds from disposal of property, plant and equipment |  |  | 46 |  |  |  | 1 |  |
| Proceeds from insurers in settlement of claims related to flood damage |  |  | — |  |  |  | 37,795 |  |
| Net cash (used in) provided by investing activities |  |  | (169,159 | ) |  |  | 30,515 |  |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Payment of debt issuance costs |  |  | (1,780 | ) |  |  | — |  |
| Proceed from revolving loan |  |  | 30,000 |  |  |  | — |  |
| Repayment of long-term loans from bank |  |  | (4,500 | ) |  |  | (7,251 | ) |
| Proceeds from issuance of ordinary shares under employee share option plans |  |  | 736 |  |  |  | 3,956 |  |
| Withholding tax related to net share settlement of restricted share units |  |  | (334 | ) |  |  | (198 | ) |
| Net cash provided by (used in) financing activities |  |  | 24,122 |  |  |  | (3,493 | ) |
| Net (decrease) increase in cash and cash equivalents |  | $ | (104,556 | ) |  | $ | 85,626 |  |

[0001193125-15-169069:8k_2_02:37]
Fabrinet

[0001193125-15-169069:8k_2_02:38]
Consolidated Statements of Cash Flows (continued)

[0001193125-15-169069:8k_2_02:39]
For
the nine months ended March 27, 2015 and March 28, 2014

[0001193125-15-169069:8k_2_02:40]
|  |  | Nine Months Ended |  |
|  |  | March 27, |  |  | March 28, |  |
| (in thousands of U. S. dollars) |  | 2015 |  |  | 2014 |  |
| Movement in cash and cash equivalents |  |  |  |  |  |  |  |  |
| Cash and cash equivalents at beginning of period |  | $ | 233,477 |  |  | $ | 149,716 |  |
| (Decrease) increase in cash and cash equivalents |  |  | (104,556 | ) |  |  | 85,626 |  |
| Effect of exchange rate on cash and cash equivalents |  |  | 25 |  |  |  | (1,678 | ) |
| Cash and cash equivalents at end of period |  | $ | 128,946 |  |  | $ | 233,664 |  |

[0001193125-15-169069:8k_2_02:41]
Fabrinet

[0001193125-15-169069:8k_2_02:42]
Reconciliation of GAAP measures to non-GAAP measures

[0001193125-15-169069:8k_2_02:43]
(in thousands of U.S. dollars, except per share data)

[0001193125-15-169069:8k_2_02:44]
(unaudited)

[0001193125-15-169069:8k_2_02:45]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 27, |  |  | March 27, |  |  | March 28, |  |  | March 28, |  |  | March 27, |  |  | March 27, |  |  | March 28, |  |  | March 28, |  |
|  |  | 2015 |  |  | 2015 |  |  | 2014 |  |  | 2014 |  |  | 2015 |  |  | 2015 |  |  | 2014 |  |  | 2014 |  |
|  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |
| GAAP measures |  |  | 10,845 |  |  |  | 0.30 |  |  |  | 47,662 |  |  |  | 1.33 |  |  |  | 30,607 |  |  |  | 0.85 |  |  |  | 81,398 |  |  |  | 2.29 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 379 |  |  |  | 0.01 |  |  |  | 290 |  |  |  | 0.01 |  |  |  | 1,107 |  |  |  | 0.03 |  |  |  | 888 |  |  |  | 0.03 |  |
| Total related to gross profit |  |  | 379 |  |  |  | 0.01 |  |  |  | 290 |  |  |  | 0.01 |  |  |  | 1,107 |  |  |  | 0.03 |  |  |  | 888 |  |  |  | 0.03 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,630 |  |  |  | 0.05 |  |  |  | 1,188 |  |  |  | 0.03 |  |  |  | 4,699 |  |  |  | 0.13 |  |  |  | 3,650 |  |  |  | 0.10 |  |
| Executive separation cost |  |  | — |  |  |  | — |  |  |  | 547 |  |  |  | 0.02 |  |  |  | — |  |  |  | — |  |  |  | 547 |  |  |  | 0.02 |  |
| Investigation costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 4,100 |  |  |  | 0.11 |  |  |  | — |  |  |  | — |  |
| Total related to selling, general and administrative expenses |  |  | 1,630 |  |  |  | 0.05 |  |  |  | 1,735 |  |  |  | 0.05 |  |  |  | 8,799 |  |  |  | 0.25 |  |  |  | 4,197 |  |  |  | 0.12 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income related to flooding, net |  |  | — |  |  |  | — |  |  |  | (38,151 | ) |  |  | (1.07 | ) |  |  | — |  |  |  | — |  |  |  | (44,748 | ) |  |  | (1.26 | ) |
| Unrealized loss on exchange, net of interest income incurred from income related to flooding |  |  | — |  |  |  | — |  |  |  | 744 |  |  |  | 0.02 |  |  |  | — |  |  |  | — |  |  |  | 744 |  |  |  | 0.02 |  |
| Expenses related to reduction in workforce |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,153 |  |  |  | 0.03 |  |  |  | — |  |  |  | — |  |
| Amortization of debt issuance costs |  |  | 149 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |  |  | 377 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |
| Total related to other incomes and other expenses |  |  | 149 |  |  |  | 0.00 |  |  |  | (37,407 | ) |  |  | (1.05 | ) |  |  | 1,530 |  |  |  | 0.04 |  |  |  | (44,004 | ) |  |  | (1.24 | ) |
| Related to income tax benefit |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax benefit |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (187 | ) |  |  | (0.01 | ) |  |  | — |  |  |  | — |  |
| Total related to income tax benefit |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (187 | ) |  |  | (0.01 | ) |  |  | — |  |  |  | — |  |
| Total related to net income & EPS |  |  | 2,158 |  |  |  | 0.06 |  |  |  | (35,382 | ) |  |  | (0.99 | ) |  |  | 11,249 |  |  |  | 0.31 |  |  |  | (38,919 | ) |  |  | (1.10 | ) |
| Non-GAAP measures |  |  | 13,003 |  |  |  | 0.36 |  |  |  | 12,280 |  |  |  | 0.34 |  |  |  | 41,856 |  |  |  | 1.16 |  |  |  | 42,479 |  |  |  | 1.20 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 36,110 |  |  |  |  |  |  |  | 35,790 |  |  |  |  |  |  |  | 35,871 |  |  |  |  |  |  |  | 35,504 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 36,110 |  |  |  |  |  |  |  | 35,790 |  |  |  |  |  |  |  | 35,871 |  |  |  |  |  |  |  | 35,504 |  |
