# FN notes — 0001193125-15-172043


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001193125-15-172043:notes:1]
[same as prior period, unchanged from 0001193125-15-031475:notes:1]

[0001193125-15-172043:notes:2]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of March 27, 2015 and for the three
 and nine months ended March 27, 2015 and March 28, 2014
 includes only normal recurring adjustments, necessary for a fair
 statement of the financial statements set forth herein, in
 accordance with accounting principles generally accepted in the
 United States of America (“U.S. GAAP”) for interim
 financial information and rules and regulations of the Securities
 and Exchange Commission (“SEC”). Accordingly, such
 information does not include all of the information and footnotes
 required by U.S. GAAP for annual financial statements. For further
 information, please refer to the consolidated financial statements
 and footnotes thereto included in the Company’s Annual Report
 on Form 10-K for the year ended June 27, 2014.

[0001193125-15-172043:notes:3]
The balance sheet as of June 27, 2014 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three and nine
 months ended March 27, 2015 and March 28, 2014 may not be
 indicative of results for the year ending June 26, 2015 or any
 future periods.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-15-172043:notes:4]
The following table summarizes the cost and estimated fair value of
 fixed income securities classified as available-for-sale securities
 based on stated effective maturities as of March 27, 2015:

[0001193125-15-172043:notes:5]
| (amount in thousands) |  | Carrying Cost |  |  | Fair Value |  |
| Due within one year |  | $ | 37,218 |  |  | $ | 37,216 |  |
| Due between one to three years |  |  | 88,154 |  |  |  | 88,182 |  |
| Total |  | $ | 125,372 |  |  | $ | 125,398 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-15-172043:notes:6]
| 15. | Commitments and contingencies |

[0001193125-15-172043:notes:7]
Bank guarantees

[0001193125-15-172043:notes:8]
As of March 27, 2015 and June 27, 2014, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $0.8 million and $0.3 million, respectively.

[0001193125-15-172043:notes:9]
Operating lease commitments

[0001193125-15-172043:notes:10]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in Cayman Islands,
 China, and New Jersey under operating lease arrangements that
 expire in various calendar years through 2020. Rental expense under
 these operating leases amounted to $0.8 million and $0.7 million
 for the nine months ended March 27, 2015 and March 28,
 2014, respectively.

[0001193125-15-172043:notes:11]
As of March 27, 2015, the future minimum lease payments due
 under non-cancelable leases were as follows at the end of each
 fiscal year below:

[0001193125-15-172043:notes:12]
| (amount in thousands) |  |  |  |
| 2015 |  | $ | 291 |  |
| 2016 |  |  | 1,118 |  |
| 2017 |  |  | 1,103 |  |
| 2018 |  |  | 1,103 |  |
| 2019 |  |  | 615 |  |
| Thereafter |  |  | 452 |  |
| Total minimum operating lease payments |  | $ | 4,682 |  |

[0001193125-15-172043:notes:13]
Purchase obligations

[0001193125-15-172043:notes:14]
Purchase obligations represent legally-binding commitments to
 purchase inventory and other commitments made in the normal course
 of business to meet operational requirements. Although open
 purchase orders are considered enforceable and legally binding,
 their terms generally give the Company the option to cancel,
 reschedule and/or adjust its requirements based on its business
 needs prior to the delivery of goods or performance of services.
 Obligations to purchase inventory and other commitments are
 generally expected to be fulfilled within one year.

[0001193125-15-172043:notes:15]
As of March 27, 2015, the Company had an outstanding
 commitment to third parties of $2.5 million.

[0001193125-15-172043:notes:16]
Indemnification of directors and officers

[0001193125-15-172043:notes:17]
Cayman Islands law does not limit the extent to which a
 company’s memorandum and articles of association may provide
 for indemnification of directors and officers, except to the extent
 any such provision may be held by the Cayman Islands courts to be
 contrary to public policy, such as to provide indemnification
 against civil fraud or the consequences of committing a crime.
 Fabrinet’s amended and restated memorandum and articles of
 association provide for indemnification of directors and officers
 for actions, costs, charges, losses, damages and expenses incurred
 in their capacities as such, except that such indemnification does
 not extend to any matter in respect of any fraud or dishonesty that
 may attach to any of them.

[0001193125-15-172043:notes:18]
In accordance with Fabrinet’s form of indemnification
 agreement for its directors and officers, Fabrinet has agreed to
 indemnify its directors and officers against certain liabilities
 and expenses incurred by such persons in connection with claims by
 reason of their being such a director or officer. Fabrinet
 maintains a director and officer liability insurance policy that
 may enable it to recover a portion of any future amounts paid under
 the indemnification agreements.


## us-gaap:DebtDisclosureTextBlock

[0001193125-15-172043:notes:19]
| 10. | Borrowings |

[0001193125-15-172043:notes:20]
The Company’s total borrowing, including revolving and
 long-term borrowings, consisted of the following:

[0001193125-15-172043:notes:21]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  |  | As of March 27, 2015 |  |  | As of June 27, 2014 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  |  | April 2015 | (2) |  | $ | 30,000 |  |  | $ | — |  |
| Current portion of long-term borrowing |  |  |  | 6,000 |  |  |  | 6,000 |  |
|  |  |  | $ | 36,000 |  |  | $ | 6,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  |  | March 2017 |  |  | $ | 12,000 |  |  | $ | 16,500 |  |
| Less: Current portion |  |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  | $ | 6,000 |  |  | $ | 10,500 |  |

[0001193125-15-172043:notes:22]
| (1) | LIBOR is London Interbank Offered Rate. |

[0001193125-15-172043:notes:23]
| (2) | On April 16, 2015, the Company sent a notice to the bank to renew the maturity date of this revolving borrowing. The bank approved the notice and extended the maturity date to May 18, 2015. |

[0001193125-15-172043:notes:24]
On April 25, 2014, a subsidiary entered into an amendment to
 the bank borrowing agreement. Under the amendment of the contract,
 the long-term loan is secured by certain property, plant and
 equipment. The carrying amount of assets secured and pledged as
 collateral as of March 27, 2015 and June 27, 2014 was
 $50.6 million and $52.3 million, respectively. This subsidiary is
 also required to comply with the maximum ratios of debt to equity
 and minimum levels of debt service coverage ratios, and Fabrinet
 must maintain an effective shareholding ratio. The carrying amounts
 of bank borrowings approximate their fair value.

[0001193125-15-172043:notes:25]
As of March 27, 2015 and June 27, 2014, the Company was
 in compliance with its long-term bank borrowing agreement. In
 addition to financial ratios, certain of the Company’s credit
 facilities include customary events of default.

[0001193125-15-172043:notes:26]
The movements of long-term loans were as follows for the nine
 months ended March 27, 2015 and March 28, 2014:

[0001193125-15-172043:notes:27]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27, 2015 |  |  | March 28, 2014 |  |
| Opening net book amount |  | $ | 16,500 |  |  | $ | 28,911 |  |
| Repayment during the period |  |  | (4,500 | ) |  |  | (7,251 | ) |
| Closing net book amount |  | $ | 12,000 |  |  | $ | 21,660 |  |

[0001193125-15-172043:notes:28]
As of March 27, 2015, future maturities of long-term debt were
 as follows at the end of each fiscal year below:

[0001193125-15-172043:notes:29]
| (amount in thousands) |  |  |  |
| 2015 |  | $ | 1,500 |  |
| 2016 |  |  | 6,000 |  |
| 2017 |  |  | 4,500 |  |
| Total |  | $ | 12,000 |  |

[0001193125-15-172043:notes:30]
Credit facilities:

[0001193125-15-172043:notes:31]
Fabrinet entered into a syndicated senior credit facility agreement
 (the “Facility Agreement”) with a consortium of banks
 on May 22, 2014. The Facility Agreement, led by Bank of
 America, provides for a $200.0 million credit line, comprised of a
 $150.0 million revolving loan facility and a $50.0 million delayed
 draw term loan facility. The revolving loan facility contains an
 accordion feature permitting Fabrinet to request an increase in the
 facility up to $100.0 million subject to customary terms and
 conditions and provided that no default or event of default exists
 at the time of request. The revolving loan facility terminates and
 all amounts outstanding are due and payable in full on May 22,
 2019. The principal amount of any drawn term loans must be repaid
 according to the scheduled quarterly amortization payments, with
 final payment of all amounts outstanding, plus accrued interest,
 being due May 22, 2019.

[0001193125-15-172043:notes:32]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allows the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. As of March 27, 2015, the
 outstanding revolving borrowing under the Facility Agreement was
 $30.0 million, resulting in available credit facilities of $170.0
 million. Borrowings under the revolving credit facility are
 classified as current liabilities in the unaudited condensed
 consolidated balance sheet as the Company has the periodic option
 to renew, or pay all or a portion of, the outstanding balance at
 the end of the maturity date, which is in the range of 1 to 6
 months, without premium or penalty, upon notice to the
 administrative agent. On April 16, 2015, the Company sent a
 notice to the bank to renew the maturity date of this revolving
 borrowing. The bank approved the notice and extended the maturity
 date to May 18, 2015.

[0001193125-15-172043:notes:33]
Loans under the Facility Agreement bear interest, at
 Fabrinet’s option, at a rate per annum equal to a LIBOR rate
 plus a spread of 1.75% to 2.50%, or a base rate, determined in
 accordance with the Facility Agreement, plus a spread of 0.75% to
 1.50%, in each case with such spread determined based on
 Fabrinet’s consolidated total leverage ratio for the
 preceding four fiscal quarter period. Interest is due and payable
 quarterly in arrears for loans bearing interest at the base rate
 and at the end of an interest period (or at each three-month
 interval in the case of loans with interest periods greater than
 three months) in the case of loans bearing interest at the LIBOR
 rate.

[0001193125-15-172043:notes:34]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or the
 equivalent under the local law, can be effected. The Facility
 Agreement contains customary affirmative and negative covenants.
 Negative covenants include, among other things, limitations on
 liens, indebtedness, investments, mergers, sales of assets, changes
 in the nature of the business, dividends and distributions,
 affiliate transactions and capital expenditures. The Facility
 Agreement contains financial covenants requiring Fabrinet to
 maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage
 ratio of not more than 2.50:1.00; and (iv) a minimum quick
 ratio of not less than 1.10:1.00. Each of these financial covenants
 is calculated on a consolidated basis for the consecutive four
 fiscal quarter period then ended. As of March 27, 2015, the
 Company was in compliance with all covenants under the Facility
 Agreement.

[0001193125-15-172043:notes:35]
The Facility Agreement also contains customary events of default
 including, among other things, payment defaults, breaches of
 covenants or representations and warranties, cross-defaults with
 certain other indebtedness, bankruptcy and insolvency events and
 change in control of Fabrinet, subject to grace periods in certain
 instances. Upon an event of default, the lenders may terminate
 their commitments, declare all or a portion of the outstanding
 obligations payable by Fabrinet to be immediately due and payable
 and exercise other rights and remedies provided for under the
 Facility Agreement.

[0001193125-15-172043:notes:36]
Fabrinet intends to use the proceeds of the credit line to finance
 its future manufacturing buildings in the United States and
 Thailand, and for general corporate purposes including mergers and
 acquisitions of complementary manufacturing businesses or
 technology, although Fabrinet has no current commitments with
 respect to any such acquisitions.

[0001193125-15-172043:notes:37]
Undrawn available credit facilities as of March 27, 2015 and
 June 27, 2014 were as follows:

[0001193125-15-172043:notes:38]
| (amount in thousands) |  | March 27, 2015 |  |  | June 27, 2014 |  |
| Short-term |  | $ | 1,535 |  |  | $ | 1,539 |  |
| Long-term |  | $ | 170,000 |  |  | $ | — |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-15-172043:notes:39]
[same as prior period, unchanged from 0001193125-15-031475:notes:37]

[0001193125-15-172043:notes:40]
Basic earnings per ordinary share is computed by dividing reported
 net income by the weighted-average number of ordinary shares
 outstanding during each period. Diluted earnings per ordinary share
 is computed by dividing reported net income by the weighted-average
 number of ordinary shares and dilutive ordinary equivalent shares
 outstanding during each period. Dilutive ordinary equivalent shares
 consist of share options and restricted share units. The earnings
 per ordinary share was calculated as follows:

[0001193125-15-172043:notes:41]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands except per share amounts) |  | March 27, 2015 |  |  | March 28, 2014 |  |  | March 27, 2015 |  |  | March 28, 2014 |  |
| Net income attributable to shareholders |  | $ | 10,845 |  |  | $ | 47,662 |  |  | $ | 30,607 |  |  | $ | 81,398 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  | 35,406 |  |  |  | 35,078 |  |  |  | 35,328 |  |  |  | 34,878 |  |
| Incremental shares arising from the assumed exercise of share options and vesting of restricted share units (thousands of shares) |  |  | 704 |  |  |  | 712 |  |  |  | 543 |  |  |  | 626 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 36,110 |  |  |  | 35,790 |  |  |  | 35,871 |  |  |  | 35,504 |  |
| Basic earnings per ordinary share |  | $ | 0.31 |  |  | $ | 1.36 |  |  | $ | 0.87 |  |  | $ | 2.33 |  |
| Diluted earnings per ordinary share |  | $ | 0.30 |  |  | $ | 1.33 |  |  | $ | 0.85 |  |  | $ | 2.29 |  |
| Outstanding share options excluded in the computation of diluted earnings per ordinary share (1) |  |  |  |  |  |  |  |  |  |  | 69,354 |  |  |  | 44,644 |  |

[0001193125-15-172043:notes:42]
| (1) | These share options were not included in the computation of diluted earnings per ordinary share for three and nine months ended March 27, 2015 and March 28, 2014, respectively, because the exercise price of the options was greater than the average market price of the underlying shares. |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-15-172043:notes:43]
[same as prior period, unchanged from 0001193125-15-031475:notes:41]

[0001193125-15-172043:notes:44]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27, 2015 |  |  | March 28, 2014 |  |  | March 27, 2015 |  |  | March 28, 2014 |  |
| North America |  | $ | 93,335 |  |  | $ | 84,842 |  |  | $ | 278,036 |  |  | $ | 247,993 |  |
| Asia-Pacific |  |  | 71,251 |  |  |  | 53,680 |  |  |  | 219,967 |  |  |  | 171,373 |  |
| Europe |  |  | 24,867 |  |  |  | 29,135 |  |  |  | 69,128 |  |  |  | 98,404 |  |
|  |  | $ | 189,453 |  |  | $ | 167,657 |  |  | $ | 567,131 |  |  | $ | 517,770 |  |


## us-gaap:ScheduleOfShareBasedCompensationRestrictedStockUnitsAwardActivityTableTextBlock

[0001193125-15-172043:notes:45]
[same as prior period, unchanged from 0001193125-15-031475:notes:43]

[0001193125-15-172043:notes:46]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 27, 2014 |  |  | 762,295 |  |  | $ | 14.23 |  |
| Granted |  |  | 608,544 |  |  | $ | 17.52 |  |
| Issued |  |  | (241,231 | ) |  | $ | 17.70 |  |
| Forfeited |  |  | (24,612 | ) |  | $ | 15.95 |  |
| Balance as of March 27, 2015 |  |  | 1,104,996 |  |  | $ | 15.97 |  |

[0001193125-15-172043:notes:47]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 28, 2013 |  |  | 545,668 |  |  | $ | 12.81 |  |
| Granted |  |  | 475,838 |  |  | $ | 15.31 |  |
| Issued |  |  | (170,468 | ) |  | $ | 12.93 |  |
| Forfeited |  |  | (12,404 | ) |  | $ | 14.60 |  |
| Balance as of March 28, 2014 |  |  | 838,634 |  |  | $ | 14.18 |  |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-15-172043:notes:48]
[same as prior period, unchanged from 0001193125-15-031475:notes:48]

[0001193125-15-172043:notes:49]
Use of Estimates

[0001193125-15-172043:notes:50]
The preparation of the Company’s condensed consolidated
 financial statements in conformity with U.S. GAAP requires
 management to make estimates and assumptions that affect the
 reported amounts of assets and liabilities and disclosure of
 contingent liabilities at the date of the financial statements, and
 the reported amount of total revenues and expense during the year.
 The Company bases estimates on historical experience and various
 assumptions about the future that are believed to be reasonable
 based on available information. The Company’s reported
 financial position or results of operations may be materially
 different under different conditions or when using different
 estimates and assumptions, particularly with respect to significant
 accounting policies, which are discussed below. Significant
 assumptions are used in accounting for share-based compensation,
 allowance for doubtful accounts, income taxes, and inventory
 obsolescence, among others. Due to the inherent uncertainty
 involved in making estimates, actual results reported in future
 periods may be different from these estimates. In the event that
 estimates or assumptions prove to differ from actual results,
 adjustments will be made in subsequent periods to reflect more
 current information.

[0001193125-15-172043:notes:51]
[same as prior period, unchanged from 0001193125-15-031475:notes:49]

[0001193125-15-172043:notes:52]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended
 March 27, 2015 and March 28, 2014 each consisted of 13
 weeks. The nine months ended March 27, 2015 and March 28,
 2014 each consisted of 39 weeks. Fiscal year 2015 will be comprised
 of 52 weeks and will end on June 26, 2015.

[0001193125-15-172043:notes:53]
[same as prior period, unchanged from 0001193125-15-031475:notes:51]

[0001193125-15-172043:notes:54]
Financial instruments that potentially subject the Company to
 concentrations of credit risk consist of cash and cash equivalents,
 marketable securities, derivatives, and accounts receivable.

[0001193125-15-172043:notes:55]
Cash, cash equivalents, and marketable securities are maintained
 with several financial institutions. Deposits held with banks may
 exceed the amount of insurance provided on such deposits.
 Generally, these deposits may be redeemed upon demand and are
 maintained with financial institutions with reputable credit and
 therefore bear minimal credit risk. The Company seeks to mitigate
 its credit risks by spreading such risks across multiple
 counterparties and monitoring the risk profiles of these
 counterparties. The Company limits its investments in marketable
 securities to securities with a maturity not in excess of three
 years, and all marketable securities that the Company invests in
 are rated A1, P-1, F1, or better.

[0001193125-15-172043:notes:56]
[same as prior period, unchanged from 0001193125-15-031475:notes:54]

[0001193125-15-172043:notes:57]
[same as prior period, unchanged from 0001193125-15-031475:notes:55]

[0001193125-15-172043:notes:58]
Certain customers may request the Company to store finished
 products purchased by them at the Company’s warehouse. In
 these instances, the Company receives a written request from the
 customer asking the Company to hold the inventory at the
 Company’s warehouse and the ordered goods are segregated in
 the Company’s warehouse from other inventory and cannot be
 used to fulfil other customer orders. In these situations revenue
 is only recognized when persuasive evidence of the sales
 arrangement exists, the goods are completed and ready for shipment,
 pricing is fixed or determinable, collection is reasonable assured,
 and title and risk of loss have passed to the customer.

[0001193125-15-172043:notes:59]
[same as prior period, unchanged from 0001193125-15-031475:notes:57]

[0001193125-15-172043:notes:60]
In April 2015, the Financial Accounting Standards Board (FASB)
 issued Accounting Standards Update (ASU) 2015-03, “Interest -
 Imputation of Interest (Subtopic 835-30): Simplifying the
 Presentation of Debt Issuance Costs”. The update requires
 debt issuance costs related to a recognized debt liability be
 presented in the balance sheet as a direct deduction from the
 carrying amount of the related debt liability instead of being
 presented as an asset. Debt disclosures will include the face
 amount of the debt liability and the effective interest rate. The
 update requires retrospective application and represents a change
 in accounting principle. The update is effective for fiscal years
 beginning after December 15, 2015. Early adoption is permitted
 for financial statements that have not been previously issued. The
 Company is currently evaluating the impact of adoption of this
 update on its consolidated financial statements.

[0001193125-15-172043:notes:61]
In February 2015, the FASB issued ASU 2015-02, “Consolidation
 (Topic 810): Amendments to the Consolidation Analysis”. ASU
 No. 2015-02 amended the process that a reporting entity must
 perform to determine whether it should consolidate certain types of
 legal entities. ASU No. 2015-02 is effective for fiscal years,
 and for interim periods within those fiscal years beginning after
 December 15, 2015. Early adoption is permitted, including
 adoption in an interim period. The Company is currently evaluating
 the impact of adoption of this update on its consolidated financial
 statements.

[0001193125-15-172043:notes:62]
In January 2015, the FASB issued ASU No. 2015-01,
 “Income Statement – Extraordinary and Unusual Items
 (Subtopic 225-20): Simplifying Income Statement Presentation by
 Eliminating the Concept of Extraordinary Items”. The
 objective of this amendment is to reduce the complexity in
 accounting standards by eliminating the concept of extraordinary
 items from U.S. GAAP. Presently, an event or transaction is
 presumed to be an ordinary and usual activity of the reporting
 entity unless evidence clearly supports its classification as an
 extraordinary item. The following criteria must both be met for
 extraordinary classification: (a) the underlying event or
 transaction should possess a high degree of abnormality and be of a
 type clearly unrelated to, or only incidentally related to, the
 ordinary and typical activities of the entity; and (b) the
 underlying event or transaction should not reasonably be expected
 to recur in the foreseeable future. This amendment is effective for
 fiscal years and interim periods beginning after December 15,
 2015. Early adoption is permitted provided that the guidance is
 applied from the beginning of the fiscal year of adoption. The
 Company does not expect that the adoption of this update will have
 an effect on its consolidated financial statements.

[0001193125-15-172043:notes:63]
In August 2014, the FASB issued ASU No. 2014-15,
 “Presentation of Financial Statements – Going Concern
 (Subtopic 205-40): Disclosure of Uncertainties about an
 Entity’s Ability to Continue as a Going Concern”. The
 amendments require management to evaluate, for each annual and
 interim reporting period, an entity’s ability to continue as
 a going concern when relevant conditions and events, considered in
 the aggregate, indicate that it is probable that the entity will be
 unable to meet its obligations that become due within one year
 after the date that the financial statements are issued (or
 available to be issued). This ASU is effective for annual periods
 and interim reporting periods beginning after December 15,
 2016. The Company does not expect that the adoption of this update
 will have an effect on its consolidated financial statements.

[0001193125-15-172043:notes:64]
In June 2014, the FASB issued ASU No. 2014-12,
 “Compensation – Stock Compensation (Topic 718):
 Accounting for Share-Based Payments When the Terms of an Award
 Provide That a Performance Target Could Be Achieved After the
 Requisite Service Period”. This ASU requires that a
 performance target that affects vesting, and that could be achieved
 after the requisite service period, be treated as a performance
 condition. As such, the performance target should not be reflected
 in estimating the grant date fair value of the award. This update
 further clarifies that compensation cost should be recognized in
 the period in which it becomes probable that the performance target
 will be achieved and should represent the compensation cost
 attributable to the period(s) for which the requisite service has
 already been rendered. This update is required to be adopted by all
 public companies for annual periods and interim reporting periods
 beginning after December 15, 2015. Early adoption of this ASU
 is permitted. The Company is currently evaluating the impact of
 adoption of this update on its consolidated financial
 statements.

[0001193125-15-172043:notes:65]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue
 from Contracts with Customers (Topic 606), issued as a new Topic,
 Accounting Standards Codification”. The core principle of
 this amendment is that an entity should recognize revenue to depict
 the transfer of promised goods or services to customers in an
 amount that reflects the consideration to which the entity expects
 to be entitled in exchange for those goods or services. This ASU is
 effective for annual reporting periods beginning after
 December 15, 2016, including interim periods within that
 reporting period, with earlier adoption not being permitted. This
 ASU can be adopted either retrospectively to each prior reporting
 period presented or as a cumulative-effect adjustment as of the
 date of adoption. The Company is currently evaluating the impact of
 adoption of this update on its consolidated financial
 statements.


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001193125-15-172043:notes:66]
[same as prior period, unchanged from 0001193125-15-031475:notes:67]

[0001193125-15-172043:notes:67]
[same as prior period, unchanged from 0001193125-15-031475:notes:68]

[0001193125-15-172043:notes:68]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Gain |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of March 27, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | — |  |  | $ | — |  |  | $ | 124,064 |  |  | $ | — |  |
| Cash equivalents |  |  | 4,882 |  |  |  | — |  |  |  | 4,882 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 102,761 |  |  |  | 25 |  |  |  | — |  |  |  | 102,786 |  |
| U.S. agency and U.S. treasury securities |  |  | 18,670 |  |  |  | — |  |  |  | — |  |  |  | 18,670 |  |
| Sovereign and municipal securities |  |  | 3,941 |  |  |  | 1 |  |  |  | — |  |  |  | 3,942 |  |
| Total |  | $ | 130,254 |  |  | $ | 26 |  |  | $ | 128,946 |  |  | $ | 125,398 |  |

[0001193125-15-172043:notes:69]
|  |  |  |  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Loss |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of June 27, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | — |  |  | $ | — |  |  | $ | 214,283 |  |  | $ | — |  |
| Cash equivalents |  |  | — |  |  |  | — |  |  |  | 19,194 |  |  |  | — |  |
| Total |  | $ | — |  |  | $ | — |  |  | $ | 233,477 |  |  | $ | — |  |

[0001193125-15-172043:notes:70]
All highly liquid investments with original maturities of three
 months or less at the date of purchase are classified as cash
 equivalents. Management determines the appropriate classification
 of its investments at the time of purchase and reevaluates the
 designations at each balance sheet date. The Company may sell
 certain of its marketable securities prior to their stated
 maturities for strategic reasons including, but not limited to,
 anticipation of credit deterioration and duration management. The
 maturities of the Company’s marketable securities generally
 range from three months to three years. The Company’s
 marketable securities investments consist of investment in U.S.
 Treasuries and fixed income securities and have been classified and
 accounted for as available-for-sale.

[0001193125-15-172043:notes:71]
The Company’s investments in available-for-sale securities
 are reported at fair value. Unrealized gains and losses related to
 changes in the fair value of securities are recognized in
 accumulated other comprehensive income, net of tax, in the
 Company’s condensed consolidated balance sheets. Changes in
 the fair value of available-for-sale securities impact the
 Company’s net income only when such securities are sold or
 other-than-temporary impairment is recognized. Realized gains and
 losses on the sale of securities are determined by specific
 identification of each security’s cost basis. During the
 three and nine months ended March 27, 2015, the net realized
 loss recognized by the Company was $0.1 million and $0.1 million,
 respectively.

[0001193125-15-172043:notes:72]
[same as prior period, unchanged from 0001193125-15-031475:notes:72]

[0001193125-15-172043:notes:73]
As of March 27, 2015, the Company considered the declines in
 market value of its available-for-sale securities investment
 portfolio to be temporary in nature and did not consider any of its
 securities other-than-temporarily impaired. The Company typically
 invests in highly-rated securities, and its investment policy
 generally limits the amount of credit exposure to any one issuer.
 The policy requires investments generally to be investment grade,
 with the primary objective of minimizing the potential risk of
 principal loss. Fair values were determined for each individual
 security in the investment portfolio. When evaluating an investment
 for other-than-temporary impairment, the Company reviews factors
 such as the length of time and extent to which fair value has been
 below its cost basis, the financial condition of the issuer and any
 changes thereto, changes in market interest rates, and the
 Company’s intent to sell, or whether it is more likely than
 not it will be required to sell, the investment before recovery of
 the investment’s cost basis. No impairment losses were
 recorded for the three and nine months ended March 27,
 2015.

[0001193125-15-172043:notes:74]
As of March 27, 2015, cash, cash equivalents, and marketable
 securities included bank deposits of $40.0 million held in various
 financial institutions located in the United States in order to
 support the availability of the Facility Agreement and comply with
 covenants. Under the terms and conditions of the Facility
 Agreement, the Company shall maintain cash, cash equivalents and/or
 marketable securities in an aggregate amount not less than $40.0
 million in unencumbered deposits, and/or securities in accounts
 located in the United States at all times during the term of the
 Facility Agreement. As discussed in Note 10, the Company must
 comply with this covenant from and after the effective date of the
 Facility Agreement.


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-15-172043:notes:75]
| (amount in thousands) |  | As of March 27, 2015 |  |  | As of June 27, 2014 |  |
| Raw materials |  | $ | 44,443 |  |  | $ | 40,885 |  |
| Work in progress |  |  | 64,216 |  |  |  | 56,376 |  |
| Finished goods |  |  | 15,117 |  |  |  | 22,970 |  |
| Goods in transit |  |  | 5,776 |  |  |  | 6,899 |  |
|  |  |  | 129,552 |  |  |  | 127,130 |  |
| Less: Inventory obsolescence |  |  | (2,892 | ) |  |  | (2,560 | ) |
| Inventory, net |  | $ | 126,660 |  |  | $ | 124,570 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-15-172043:notes:76]
[same as prior period, unchanged from 0001193125-15-031475:notes:76]

[0001193125-15-172043:notes:77]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 27, 2014 |  |  | 865,890 |  |  |  |  |  |  | $ | 16.27 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (50,867 | ) |  |  |  |  |  | $ | 14.50 |  |  |  |  |  |
| Forfeited |  |  | (8,249 | ) |  |  |  |  |  | $ | 15.91 |  |  |  |  |  |
| Expired |  |  | (6,787 | ) |  |  |  |  |  | $ | 20.80 |  |  |  |  |  |
| Balance as of March 27, 2015 |  |  | 799,987 |  |  |  | 741,957 |  |  | $ | 16.34 |  |  |  |  |  |

[0001193125-15-172043:notes:78]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price |  |  | Weighted- Average Grant Date Fair Value |  |
| Balance as of June 28, 2013 |  |  | 1,277,311 |  |  |  |  |  |  | $ | 15.37 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (311,474 | ) |  |  |  |  |  | $ | 12.70 |  |  |  |  |  |
| Forfeited |  |  | (12,754 | ) |  |  |  |  |  | $ | 16.18 |  |  |  |  |  |
| Expired |  |  | (30,848 | ) |  |  |  |  |  | $ | 16.93 |  |  |  |  |  |
| Balance as of March 28, 2014 |  |  | 922,235 |  |  |  | 640,676 |  |  | $ | 16.20 |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-15-172043:notes:79]
| 16. | Business segments and geographic information |

[0001193125-15-172043:notes:80]
Operating segments are defined as components of an enterprise for
 which separate financial information is available that is evaluated
 regularly by the chief operating decision maker in deciding how to
 allocate resources and in assessing performance. The
 Company’s chief operating decision maker is Fabrinet’s
 chief executive officer. As of March 27, 2015 and
 March 28, 2014, the Company operated and internally managed a
 single operating segment. Accordingly, the Company does not
 accumulate discrete information with respect to separate product
 lines and does not have separate reportable segments.

[0001193125-15-172043:notes:81]
[same as prior period, unchanged from 0001193125-15-031475:notes:80]

[0001193125-15-172043:notes:82]
As of March 27, 2015 and March 28, 2014, the Company had
 approximately $25.8 million and $0.3 million of long-lived assets
 based in North America, with the substantial remainder of assets
 based in Asia-Pacific.

[0001193125-15-172043:notes:83]
[same as prior period, unchanged from 0001193125-15-031475:notes:82]

[0001193125-15-172043:notes:84]
The Company had two customers that each contributed to 10% or more
 of its total account receivable as of March 27, 2015 and
 June 27, 2014, respectively.


## us-gaap:AccountingChangesAndErrorCorrectionsTextBlock

[0001193125-15-172043:notes:85]
| 19. | Revenue recognition error related to finished goods awaiting shipment to customers under certain volume supply agreements with customers |

[0001193125-15-172043:notes:86]
As disclosed in the Company’s Annual Report on Form 10-K for
 the fiscal year ended June 27, 2014, the Company determined
 that certain finished goods sales recognized in each of the first
 three quarterly reporting periods in the fiscal year ended
 June 27, 2014 did not qualify for revenue recognition in the
 period in which they were recorded. The Company evaluated the
 impact of the errors and determined that the errors did not have a
 material impact to the consolidated financial statements for the
 fiscal year ended June 27, 2014, or the interim consolidated
 financial statements for each of the quarters within fiscal year
 2014. Accordingly, the Company has not made any adjustments to the
 unaudited condensed consolidated financial statements for the three
 and nine months ended March 28, 2014.

[0001193125-15-172043:notes:87]
Had adjustments been made in the three and nine months ended
 March 28, 2014, to reflect revenues and cost of revenues that
 were inappropriately recorded, revenues, cost of revenues, and net
 income for the three months ended March 28, 2014, would have
 been $2.0 million, $1.8 million, and $0.2 million higher,
 respectively, and for the nine months ended March 28, 2014,
 would have been $1.7 million, $1.5 million, and $0.2 million lower,
 respectively.


## us-gaap:DisclosureOfShareBasedCompensationArrangementsByShareBasedPaymentAwardTextBlock

[0001193125-15-172043:notes:88]
The effect of recording share-based compensation expense for the
 three and nine months ended March 27, 2015 and March 28,
 2014 was as follows:

[0001193125-15-172043:notes:89]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27, 2015 |  |  | March 28, 2014 |  |  | March 27, 2015 |  |  | March 28, 2014 |  |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share options |  | $ | 6 |  |  | $ | 172 |  |  | $ | 197 |  |  | $ | 710 |  |
| Restricted share units |  |  | 2,003 |  |  |  | 1,306 |  |  |  | 5,609 |  |  |  | 3,828 |  |
| Total share-based compensation expense |  |  | 2,009 |  |  |  | 1,478 |  |  |  | 5,806 |  |  |  | 4,538 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 2,009 |  |  | $ | 1,478 |  |  | $ | 5,806 |  |  | $ | 4,538 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-15-172043:notes:90]
[same as prior period, unchanged from 0001193125-15-031475:notes:89]


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-15-172043:notes:91]
[same as prior period, unchanged from 0001193125-15-031475:notes:90]

[0001193125-15-172043:notes:92]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27, 2015 |  |  | March 28, 2014 |  |  | March 27, 2015 |  |  | March 28, 2014 |  |
| Cost of revenue |  | $ | 379 |  |  | $ | 290 |  |  | $ | 1,107 |  |  | $ | 888 |  |
| Selling, general and administrative expense |  |  | 1,630 |  |  |  | 1,188 |  |  |  | 4,699 |  |  |  | 3,650 |  |
| Total share-based compensation expense |  | $ | 2,009 |  |  | $ | 1,478 |  |  | $ | 5,806 |  |  | $ | 4,538 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-15-172043:notes:93]
Based on the carrying amount of intangibles as of March 27,
 2015, and assuming no future impairment of the underlying assets,
 the estimated future amortization at the end of each fiscal year in
 June is as follows:

[0001193125-15-172043:notes:94]
| (amount in thousands) |  |  |  |
| 2015 |  | $ | 8 |  |
| 2016 |  |  | 12 |  |
| 2017 |  |  | 8 |  |
| 2018 |  |  | 7 |  |
| 2019 |  |  | 7 |  |
| Thereafter |  |  | 3 |  |
| Total |  | $ | 45 |  |


## us-gaap:ScheduleOfCreditLossesForFinancingReceivablesCurrentTableTextBlock

[0001193125-15-172043:notes:95]
[same as prior period, unchanged from 0001193125-15-031475:notes:94]

[0001193125-15-172043:notes:96]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 27, 2015 |  |  | March 28, 2014 |  |
| Balance, beginning of period |  | $ | 37 |  |  | $ | 109 |  |
| Charged to expense/(Credited to income) |  |  | 3 |  |  |  | (62 | ) |
| Balance, end of period |  | $ | 40 |  |  | $ | 47 |  |


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001193125-15-172043:notes:97]
[same as prior period, unchanged from 0001193125-15-031475:notes:96]

[0001193125-15-172043:notes:98]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net |  |
| As of March 27, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 3,492 |  |  | $ | (3,447 | ) |  | $ | 45 |  |
| Total intangibles |  | $ | 3,492 |  |  | $ | (3,447 | ) |  | $ | 45 |  |

[0001193125-15-172043:notes:99]
[same as prior period, unchanged from 0001193125-15-031475:notes:98]


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-15-172043:notes:100]
For the nine months ended March 27, 2015, the changes in
 accumulated other comprehensive income, net of tax were as
 follows:

[0001193125-15-172043:notes:101]
| (amount in thousands) |  | Unrealized Gain on Available-for-Sale Securities |  |
| Balance as of June 27, 2014 |  | $ | — |  |
| Other comprehensive income before reclassification adjustment |  |  | (43 | ) |
| Less: Reclassification adjustment for net loss realized and included in other expense in net income |  |  | 69 |  |
| Net current-period other comprehensive income |  | $ | 26 |  |
| Balance as of March 27, 2015 |  | $ | 26 |  |


## us-gaap:ShareBasedCompensationArrangementByShareBasedPaymentAwardOptionsVestedAndExpectedToVestOutstandingAndExercisableTableTextBlock

[0001193125-15-172043:notes:102]
The following summarizes information for share options outstanding
 as of March 27, 2015 under the Share Option Plans:

[0001193125-15-172043:notes:103]
|  |  | Number of Shares Underlying Options |  |  | Exercise Price Per Share |  |  | Weighted- Average Remaining Contractual Life (years) |  |  | Aggregate Intrinsic Value (amount in thousands) |  |
|  |  |  | 6,665 |  |  | $ | 5.75 |  |  |  | 1.39 |  |  |  |  |  |
|  |  |  | 8,368 |  |  | $ | 13.77 |  |  |  | 2.41 |  |  |  |  |  |
|  |  |  | 420,454 |  |  | $ | 16.83 |  |  |  | 2.55 |  |  |  |  |  |
|  |  |  | 30,000 |  |  | $ | 15.05 |  |  |  | 2.61 |  |  |  |  |  |
|  |  |  | 25,344 |  |  | $ | 25.50 |  |  |  | 2.80 |  |  |  |  |  |
|  |  |  | 7,400 |  |  | $ | 26.16 |  |  |  | 2.86 |  |  |  |  |  |
|  |  |  | 8,300 |  |  | $ | 23.62 |  |  |  | 3.11 |  |  |  |  |  |
|  |  |  | 69,364 |  |  | $ | 15.16 |  |  |  | 3.39 |  |  |  |  |  |
|  |  |  | 193,521 |  |  | $ | 14.12 |  |  |  | 3.62 |  |  |  |  |  |
|  |  |  | 22,760 |  |  | $ | 19.36 |  |  |  | 3.87 |  |  |  |  |  |
|  |  |  | 5,550 |  |  | $ | 18.60 |  |  |  | 3.93 |  |  |  |  |  |
|  |  |  | 2,261 |  |  | $ | 12.83 |  |  |  | 4.12 |  |  |  |  |  |
| Options outstanding |  |  | 799,987 |  |  |  |  |  |  |  | 2.94 |  |  | $ | 2,030 |  |
| Options exercisable |  |  | 741,957 |  |  |  |  |  |  |  | 2.89 |  |  | $ | 1,815 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-15-172043:notes:104]
| 13. | Shareholders’ equity |

[0001193125-15-172043:notes:105]
[same as prior period, unchanged from 0001193125-15-031475:notes:104]

[0001193125-15-172043:notes:106]
[same as prior period, unchanged from 0001193125-15-031475:notes:105]

[0001193125-15-172043:notes:107]
For the nine months ended March 27, 2015, Fabrinet issued
 50,867 ordinary shares upon the exercise of options, for cash
 consideration at a weighted-average exercise price of $14.50 per
 share, and 222,501 ordinary shares upon the vesting of restricted
 share units, net of shares withheld.

[0001193125-15-172043:notes:108]
For the nine months ended March 28, 2014, Fabrinet issued
 311,474 ordinary shares upon the exercise of options, for cash
 consideration at a weighted-average exercise price of $12.70 per
 share, and 158,325 ordinary shares upon the vesting of restricted
 share units, net of shares withheld.

[0001193125-15-172043:notes:109]
[same as prior period, unchanged from 0001193125-15-031475:notes:108]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-15-172043:notes:110]
| 11. | Income taxes |

[0001193125-15-172043:notes:111]
As of March 27, 2015 and June 27, 2014, the liability for
 uncertain tax positions including accrued interest and penalties
 was $1.5 million and $0.9 million, respectively. The Company
 expects the estimated amount of liability associated with its
 uncertain tax positions to decrease within the next 12 months
 due to the lapse of the applicable statute of limitations in
 foreign tax jurisdictions.

[0001193125-15-172043:notes:112]
The Company files income tax returns in the United States and
 foreign tax jurisdictions. The tax years from 2010 to 2014 remain
 open to examination by U.S. federal and state tax authorities, and
 foreign tax authorities. The Company’s income tax is
 recognized based on the best estimate of the expected annual
 effective tax rate for the full financial year of each entity in
 the Company, adjusted for discrete items arising in that quarter.
 If the Company’s estimated annual effective tax rate changes,
 the Company makes a cumulative adjustment in that quarter.

[0001193125-15-172043:notes:113]
The effective tax rate for the Company for the three months ended
 March 27, 2015 and March 28, 2014 was 9.3% and 1.5% of
 net income, respectively. The increase in the effective tax rate
 for the three months ended March 27, 2015 was primarily due to
 the fact that the Company had higher taxable income during the
 three months ended March 27, 2015 as compared to the three
 months ended March 28, 2014 because the income related to
 flooding of $38.2 million that was recognized during the three
 months ended March 28, 2014 was not subject to income tax.

[0001193125-15-172043:notes:114]
The effective tax rate for the Company for the nine months ended
 March 27, 2015 and March 28, 2014 was 9.2% and 0.2% of
 net income, respectively. The increase in the effective tax rate
 for the nine months ended March 27, 2015 was primarily due to
 the fact that the Company had higher taxable income during the nine
 months ended March 27, 2015 as compared to the nine months
 ended March 28, 2014 because the income related to flooding of
 $44.7 million that was recognized during the nine months ended
 March 28, 2014 was not subject to income tax. This impact was
 offset by the reversal of liabilities for uncertain tax positions,
 including accrued interest of $1.5 million in the nine months ended
 March 27, 2015, and an increase in deferred tax assets of $0.6
 million from the increase in the income tax rate of the
 Company’s subsidiary in China from 15% in the nine months
 ended March 28, 2014 to 25% in the nine months ended
 March 27, 2015 due to the expiration of a tax privilege.


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001193125-15-172043:notes:115]
| 17. | Income related to flooding |

[0001193125-15-172043:notes:116]
The Company suspended production at all of its manufacturing
 facilities in Thailand from October 17, 2011 through
 November 14, 2011 due to severe flooding in Thailand. The
 Company never resumed, and has permanently ceased, production at
 its Chokchai facility. The Company submitted claims for losses to
 its insurance companies, all of which were settled as of the end of
 fiscal year 2014.

[0001193125-15-172043:notes:117]
In the three and nine months ended March 28, 2014, the Company
 received from its insurer a final payment of $38.6 million and
 $45.2 million against its claim for owned and consigned equipment
 and inventory claims, respectively, which the Company recognized as
 income related to flooding. This income was offset by other
 expenses from write-offs of advance payments to a customer due to
 flood losses of $0.5 million.

[0001193125-15-172043:notes:118]
During the nine months ended March 28, 2014, the Company
 fulfilled its obligations to a customer in accordance with a
 settlement agreement entered into during the third quarter of
 fiscal year 2013 by making a final cash payment of $5.3 million and
 transferring equipment, with an aggregate value of $2.3 million, to
 such customer. Also, the Company fulfilled its obligations to a
 customer’s insurers in accordance with a settlement agreement
 entered into during the fourth quarter of fiscal year 2013 by
 making a final payment of $2.3 million.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-15-172043:notes:119]
| 12. | Share-based compensation |

[0001193125-15-172043:notes:120]
[same as prior period, unchanged from 0001193125-15-031475:notes:126]

[0001193125-15-172043:notes:121]
[same as prior period, unchanged from 0001193125-15-031475:notes:127]

[0001193125-15-172043:notes:122]
The Company did not capitalize any share-based compensation expense
 as part of any asset costs during the three and nine months ended
 March 27, 2015 and March 28, 2014.

[0001193125-15-172043:notes:123]
[same as prior period, unchanged from 0001193125-15-031475:notes:129]

[0001193125-15-172043:notes:124]
Share options have been granted to directors and employees. As of
 March 27, 2015, there were 6,665 share options outstanding
 under Fabrinet’s Amended and Restated 1999 Share Option Plan
 (the “1999 Plan”). Additional option grants may not be
 made under the 1999 Plan.

[0001193125-15-172043:notes:125]
As of March 27, 2015, there were an aggregate of 793,322 share
 options outstanding, 1,104,996 restricted share units outstanding,
 and 2,978,612 ordinary shares available for future grant under
 Fabrinet’s 2010 Performance Incentive Plan (the “2010
 Plan”). The 1999 Plan and 2010 Plan are collectively referred
 to as the “Share Option Plans”.

[0001193125-15-172043:notes:126]
[same as prior period, unchanged from 0001193125-15-031475:notes:132]

[0001193125-15-172043:notes:127]
Fabrinet’s board of directors has the authority to determine
 the type of option and the number of shares subject to an option.
 Options generally vest and become exercisable over four years and
 expire, if not exercised, within seven years of the grant date. In
 the case of a grantee’s first grant, 25 percent of the
 underlying shares subject to an option vest 12 months after the
 vesting commencement date and 1/48 of the underlying shares vest
 monthly over each of the subsequent 36 months. In the case of
 any additional grants to a grantee, 1/48 of the underlying shares
 subject to an option vest monthly over four years, commencing one
 month after the vesting commencement date.

[0001193125-15-172043:notes:128]
As of March 27, 2015, there was $0.03 million of unrecognized
 compensation expense related to share options under the Share
 Option Plans that is expected to be recognized over a
 weighted-average period of 0.62 years.

[0001193125-15-172043:notes:129]
[same as prior period, unchanged from 0001193125-15-031475:notes:136]

[0001193125-15-172043:notes:130]
[same as prior period, unchanged from 0001193125-15-031475:notes:137]

[0001193125-15-172043:notes:131]
As of March 27, 2015, there was $9.4 million of unrecognized
 share-based compensation expense related to restricted share units
 under the 2010 Plan that is expected to be recorded over a
 weighted-average period of 2.97 years.

[0001193125-15-172043:notes:132]
For the nine months ended March 27, 2015 and March 28,
 2014, the Company withheld an aggregate of 18,730 shares and 12,143
 shares, respectively, upon the vesting of restricted share units,
 based upon the closing share price on the vesting date to settle
 the employees’ minimum statutory obligation for the
 applicable income and other employment taxes. For the nine months
 ended March 27, 2015 and March 28, 2014, the Company then
 remitted cash of $0.3 million and $0.2 million, respectively, to
 the appropriate taxing authorities, and presented it in a financing
 activity within the condensed consolidated statements of cash
 flows. The payment had the effect on shares issued by the Company
 as it reduced the number of shares that would have been issued on
 the vesting date and was recorded as a reduction of additional
 paid-in capital.


## us-gaap:FairValueAssetsAndLiabilitiesMeasuredOnRecurringAndNonrecurringBasisTableTextBlock

[0001193125-15-172043:notes:133]
[same as prior period, unchanged from 0001193125-15-031475:notes:140]

[0001193125-15-172043:notes:134]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of March 27, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 4,882 |  |  | $ | — |  |  | $ | 4,882 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 102,786 |  |  |  | — |  |  |  | 102,786 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 18,670 |  |  |  | — |  |  |  | 18,670 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 3,942 |  |  |  | — |  |  |  | 3,942 |  |
| Derivative assets |  |  | — |  |  |  | 183 | (1) |  |  | — |  |  |  | 183 |  |
| Total |  | $ | — |  |  | $ | 130,463 |  |  | $ | — |  |  | $ | 130,463 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 20 | (2) |  | $ | — |  |  | $ | 20 |  |
| Total |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |

[0001193125-15-172043:notes:135]
| (1) | Foreign currency options with notional amount of $40.0 million. |

[0001193125-15-172043:notes:136]
| (2) | Foreign currency options with notional amount of $5.0 million and forward contracts with notional amount of Canadian dollars 0.4 million. |

[0001193125-15-172043:notes:137]
[same as prior period, unchanged from 0001193125-15-031475:notes:144]

[0001193125-15-172043:notes:138]
[same as prior period, unchanged from 0001193125-15-031475:notes:145]

[0001193125-15-172043:notes:139]
[same as prior period, unchanged from 0001193125-15-031475:notes:146]


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-15-172043:notes:140]
[same as prior period, unchanged from 0001193125-15-031475:notes:147]

[0001193125-15-172043:notes:141]
[same as prior period, unchanged from 0001193125-15-031475:notes:148]

[0001193125-15-172043:notes:142]
[same as prior period, unchanged from 0001193125-15-031475:notes:149]

[0001193125-15-172043:notes:143]
Level 2 inputs are inputs other than quoted prices included within
 Level 1 that are observable for assets or liabilities, either
 directly or indirectly. If the assets or liabilities have a
 specified (contractual) term, Level 2 inputs must be observable for
 substantially the full term of assets or liabilities.

[0001193125-15-172043:notes:144]
[same as prior period, unchanged from 0001193125-15-031475:notes:151]

[0001193125-15-172043:notes:145]
[same as prior period, unchanged from 0001193125-15-031475:notes:152]

[0001193125-15-172043:notes:146]
[same as prior period, unchanged from 0001193125-15-031475:notes:153]

[0001193125-15-172043:notes:147]
The Company uses foreign currency contracts to manage the foreign
 exchange risk associated with certain foreign currency-denominated
 assets and liabilities. As a result of foreign currency
 fluctuations, the U.S. dollar equivalent values of its foreign
 currency-denominated assets and liabilities change. The Company has
 not designated such foreign currency contracts as hedging
 instruments under the accounting standard for derivatives and
 hedging. The forward exchange contracts and option contracts
 outstanding as of March 27, 2015 and June 27, 2014 had a
 maturity in one to six months duration. The Company minimizes the
 credit risk in derivative instruments by limiting its exposure to
 any single counterparty and by entering into derivative instruments
 only with counterparties that meet the Company’s minimum
 credit quality standard.

[0001193125-15-172043:notes:148]
[same as prior period, unchanged from 0001193125-15-031475:notes:155]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-15-172043:notes:149]
| 9. | Intangibles |

[0001193125-15-172043:notes:150]
The Company recorded amortization expense relating to intangibles
 of $0.02 million and $0.02 million for the three months ended
 March 27, 2015 and March 28, 2014, respectively, and
 $0.06 million and $0.07 million for the nine months ended
 March 27, 2015 and March 28, 2014, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001193125-15-172043:notes:151]
| 8. | Property, Plant and Equipment |

[0001193125-15-172043:notes:152]
On February 24, 2015, one of Fabrinet’s subsidiaries
 purchased a building of approximately 74,000 square feet and the
 associated 4.05 acres of land located in Santa Clara, California,
 for the purpose of expanding the Company’s manufacturing
 facilities in the United States. The purchase price of the land and
 building was $17.0 million and $8.5 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-15-172043:notes:153]
| 14. | Accumulated other comprehensive income |

[0001193125-15-172043:notes:154]
The Company’s accumulated other comprehensive income consists
 of the accumulated net unrealized loss and the reclassification
 adjustment for net loss realized and included in other expense in
 net income on available-for-sale securities. For the nine months
 ended March 27, 2015, the changes in accumulated other
 comprehensive income, net of tax were as follows:


## fn:AllowanceForDoubtfulAccountsTextBlock

[0001193125-15-172043:notes:155]
[same as prior period, unchanged from 0001193125-15-031475:notes:160]


## fn:ExpensesRelatedToReductionInWorkforceDisclosureTextBlock

[0001193125-15-172043:notes:156]
| 18. | Expenses related to reduction in workforce |

[0001193125-15-172043:notes:157]
As part of the Company’s ongoing efforts to achieve greater
 efficiencies in all areas of its business, during the nine months
 ended March 27, 2015, the Company implemented a reduction in
 workforce and incurred expenses of approximately $1.2 million,
 which represented severance and benefits costs incurred for the
 termination of approximately 100 employees in accordance with
 contractual obligations and local regulations.
