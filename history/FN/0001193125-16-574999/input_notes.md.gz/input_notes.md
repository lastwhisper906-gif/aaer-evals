# FN notes — 0001193125-16-574999


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-16-574999:notes:1]
| 8. | Intangibles |

[0001193125-16-574999:notes:2]
[same as prior period, unchanged from 0001193125-16-447643:notes:2]

[0001193125-16-574999:notes:3]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net |  |
| As of March 25, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 3,631 |  |  | $ | (3,262 | ) |  | $ | 369 |  |
| Total intangibles |  | $ | 3,631 |  |  | $ | (3,262 | ) |  | $ | 369 |  |
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net |  |
| As of June 26, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 3,357 |  |  | $ | (3,220 | ) |  | $ | 137 |  |
| Total intangibles |  | $ | 3,357 |  |  | $ | (3,220 | ) |  | $ | 137 |  |

[0001193125-16-574999:notes:4]
The Company recorded amortization expense relating to intangibles
 of $0.02 million and $0.02 million for the three months ended
 March 25, 2016 and March 27, 2015, respectively, and
 $0.04 million and $0.06 million for the nine months ended
 March 25, 2016 and March 27, 2015, respectively.

[0001193125-16-574999:notes:5]
Based on the carrying amount of intangibles as of March 25,
 2016, and assuming no future impairment of the underlying assets,
 the estimated future amortization during each fiscal year was as
 follows:

[0001193125-16-574999:notes:6]
| (amount in thousands) |  |  |  |
| 2016 |  | $ | 22 |  |
| 2017 |  |  | 86 |  |
| 2018 |  |  | 84 |  |
| 2019 |  |  | 83 |  |
| 2020 |  |  | 71 |  |
| Thereafter |  |  | 23 |  |
| Total |  | $ | 369 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-16-574999:notes:7]
[same as prior period, unchanged from 0001193125-16-447643:notes:10]

[0001193125-16-574999:notes:8]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 25, 2016 |  |  | March 27, 2015 |  |  | March 25, 2016 |  |  | March 27, 2015 |  |
| North America |  | $ | 138,687 |  |  | $ | 93,335 |  |  | $ | 369,284 |  |  | $ | 278,036 |  |
| Asia-Pacific |  |  | 88,433 |  |  |  | 71,251 |  |  |  | 256,676 |  |  |  | 219,967 |  |
| Europe |  |  | 23,768 |  |  |  | 24,867 |  |  |  | 74,399 |  |  |  | 69,128 |  |
|  |  | $ | 250,888 |  |  | $ | 189,453 |  |  | $ | 700,359 |  |  | $ | 567,131 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-16-574999:notes:9]
[same as prior period, unchanged from 0001193125-16-447643:notes:12]

[0001193125-16-574999:notes:10]
| (amount in thousands) |  | As of March 25, 2016 |  |  | As of June 26, 2015 |  |
| Raw materials |  | $ | 47,582 |  |  | $ | 46,065 |  |
| Work in progress |  |  | 82,707 |  |  |  | 69,174 |  |
| Finished goods |  |  | 16,431 |  |  |  | 11,843 |  |
| Goods in transit |  |  | 5,875 |  |  |  | 6,488 |  |
|  |  |  | 152,595 |  |  |  | 133,570 |  |
| Less: Inventory obsolescence |  |  | (2,613 | ) |  |  | (2,957 | ) |
| Inventory, net |  | $ | 149,982 |  |  | $ | 130,613 |  |


## us-gaap:DebtDisclosureTextBlock

[0001193125-16-574999:notes:11]
| 9. | Borrowings |

[0001193125-16-574999:notes:12]
The Company’s total borrowings, including revolving and
 long-term borrowings, consisted of the following:

[0001193125-16-574999:notes:13]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  |  | As of March 25, 2016 |  |  | As of June 26, 2015 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  |  | April 2016 | (2) |  | $ | 44,000 |  |  | $ | 30,000 |  |
| Current portion of long-term borrowing |  |  |  | 6,000 |  |  |  | 6,000 |  |
|  |  |  | $ | 50,000 |  |  | $ | 36,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  |  | March 2017 |  |  | $ | 6,000 |  |  | $ | 10,500 |  |
| Less: Current portion |  |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  | $ | — |  |  | $ | 4,500 |  |

[0001193125-16-574999:notes:14]
|  | (1) | LIBOR is London Interbank Offered Rate. |

[0001193125-16-574999:notes:15]
|  | (2) | In April 2016, the maturity date of these revolving borrowings were extended to mature in May 2016. |

[0001193125-16-574999:notes:16]
Under the long-term borrowing contract of a subsidiary, the loan is
 secured by certain property, plant and equipment. The carrying
 amount of assets secured and pledged as collateral to such loan as
 of March 25, 2016 and June 26, 2015 was $48.2 million and
 $50.0 million, respectively. This subsidiary is also required to
 comply with maximum ratios of debt to equity and minimum levels of
 debt service coverage ratios, and Fabrinet must maintain an
 effective shareholding ratio. The carrying amounts of bank
 borrowings approximate their fair value.

[0001193125-16-574999:notes:17]
As of March 25, 2016 and June 26, 2015, the Company was
 in compliance with its long-term bank borrowing agreement. In
 addition to financial ratios, certain of the Company’s credit
 facilities include customary events of default.

[0001193125-16-574999:notes:18]
The movements of long-term loans were as follows for the nine
 months ended March 25, 2016 and March 27, 2015:

[0001193125-16-574999:notes:19]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 25, 2016 |  |  | March 27, 2015 |  |
| Opening book amount |  | $ | 10,500 |  |  | $ | 16,500 |  |
| Repayments during the period |  |  | (4,500 | ) |  |  | (4,500 | ) |
| Closing book amount |  | $ | 6,000 |  |  | $ | 12,000 |  |

[0001193125-16-574999:notes:20]
As of March 25, 2016, future maturities of long-term debt
 during each fiscal year were as follows:

[0001193125-16-574999:notes:21]
| (amount in thousands) |  |  |  |
| 2016 |  | $ | 1,500 |  |
| 2017 |  |  | 4,500 |  |
| Total |  | $ | 6,000 |  |

[0001193125-16-574999:notes:22]
Credit facilities:

[0001193125-16-574999:notes:23]
Fabrinet entered into a syndicated senior credit facility agreement
 (the “Facility Agreement”) with a consortium of banks
 on May 22, 2014. The Facility Agreement, led by Bank of
 America, provides for a $200.0 million credit line, comprised of a
 $150.0 million revolving loan facility and a $50.0 million delayed
 draw term loan facility. The revolving loan facility contains an
 accordion feature permitting Fabrinet to request an increase in the
 facility up to $100.0 million subject to customary terms and
 conditions and provided that no default or event of default exists
 at the time of request. The revolving loan facility terminates and
 all amounts outstanding are due and payable in full on May 22,
 2019. The principal amount of any drawn term loans must be repaid
 according to scheduled quarterly amortization payments, with final
 payment of all amounts outstanding, plus accrued interest, being
 due May 22, 2019.

[0001193125-16-574999:notes:24]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. As of
 March 25, 2016, the outstanding revolving borrowing under the
 Facility Agreement was $44.0 million, resulting in available credit
 facilities of $156.0 million. Borrowings under the revolving credit
 facility are classified as current liabilities in the unaudited
 condensed consolidated balance sheets as the Company has the
 periodic option to renew or pay, all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. During April 2016, the Company
 sent notices to the bank to renew the maturity date of its
 revolving borrowings. The bank approved the notices and extended
 the maturity to May 2016.

[0001193125-16-574999:notes:25]
Loans under the Facility Agreement bear interest, at
 Fabrinet’s option, at a rate per annum equal to a LIBOR rate
 plus a spread of 1.75% to 2.50%, or a base rate plus a spread of
 0.75% to 1.50%, determined in accordance with the Facility
 Agreement in each case with such spread determined based on
 Fabrinet’s consolidated total leverage ratio for the
 preceding four fiscal quarter period. Interest is due and payable
 quarterly in arrears for loans bearing interest at the base rate
 and at the end of an interest period (or at each three-month
 interval in the case of loans with interest periods greater than
 three months) in the case of loans bearing interest at the LIBOR
 rate.

[0001193125-16-574999:notes:26]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or the
 equivalent under the local law, can be effected.

[0001193125-16-574999:notes:27]
The Facility Agreement contains customary affirmative and negative
 covenants. Negative covenants include, among other things,
 limitations on liens, indebtedness, investments, mergers, sales of
 assets, changes in the nature of the business, dividends and
 distributions, affiliate transactions and capital expenditures. The
 Facility Agreement contains financial covenants requiring Fabrinet
 to maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage
 ratio of not more than 2.50:1.00; and (iv) a minimum quick
 ratio of not less than 1.10:1.00. Each of these financial covenants
 is calculated on a consolidated basis for the consecutive four
 fiscal quarter period then ended. As of March 25, 2016, the
 Company was in compliance with all covenants under the Facility
 Agreement.

[0001193125-16-574999:notes:28]
The Facility Agreement also contains customary events of default
 including, among other things, payment defaults, breaches of
 covenants or representations and warranties, cross-defaults with
 certain other indebtedness, bankruptcy and insolvency events and
 change in control of Fabrinet, subject to grace periods in certain
 instances. Upon an event of default, the lenders may terminate
 their commitments, declare all or a portion of the outstanding
 obligations payable by Fabrinet to be immediately due and payable
 and exercise other rights and remedies provided for under the
 Facility Agreement.

[0001193125-16-574999:notes:29]
Fabrinet intends to use the proceeds of the credit line to finance
 its future manufacturing buildings in the United States and
 Thailand, and for general corporate purposes including mergers and
 acquisitions of complementary manufacturing businesses or
 technology, although Fabrinet has no current commitments with
 respect to any such acquisitions.

[0001193125-16-574999:notes:30]
Undrawn available credit facilities classified by available period
 of future borrowing as of March 25, 2016 and June 26,
 2015 were as follows:

[0001193125-16-574999:notes:31]
| (amount in thousands) |  | March 25, 2016 |  |  | June 26, 2015 |  |
| Short-term |  | $ | 1,415 |  |  | $ | 1,480 |  |
| Long-term |  | $ | 156,000 |  |  | $ | 170,000 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-16-574999:notes:32]
| 11. | Share-based compensation |

[0001193125-16-574999:notes:33]
[same as prior period, unchanged from 0001193125-16-447643:notes:35]

[0001193125-16-574999:notes:34]
[same as prior period, unchanged from 0001193125-16-447643:notes:36]

[0001193125-16-574999:notes:35]
The effect of recording share-based compensation expense for the
 three and nine months ended March 25, 2016 and March 27,
 2015 was as follows:

[0001193125-16-574999:notes:36]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 25, 2016 |  |  | March 27, 2015 |  |  | March 25, 2016 |  |  | March 27, 2015 |  |
| Share-based compensation (income)/expense by type of award: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share options |  | $ | (1 | ) |  | $ | 6 |  |  | $ | 17 |  |  | $ | 197 |  |
| Restricted share units |  |  | 2,000 |  |  |  | 2,003 |  |  |  | 7,765 |  |  |  | 5,609 |  |
| Total share-based compensation expense |  |  | 1,999 |  |  |  | 2,009 |  |  |  | 7,782 |  |  |  | 5,806 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 1,999 |  |  | $ | 2,009 |  |  | $ | 7,782 |  |  | $ | 5,806 |  |

[0001193125-16-574999:notes:37]
[same as prior period, unchanged from 0001193125-16-447643:notes:39]

[0001193125-16-574999:notes:38]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 25, 2016 |  |  | March 27, 2015 |  |  | March 25, 2016 |  |  | March 27, 2015 |  |
| Cost of revenue |  | $ | 517 |  |  | $ | 379 |  |  | $ | 1,594 |  |  | $ | 1,107 |  |
| Selling, general and administrative expense |  |  | 1,482 |  |  |  | 1,630 |  |  |  | 6,188 |  |  |  | 4,699 |  |
| Total share-based compensation expense |  | $ | 1,999 |  |  | $ | 2,009 |  |  | $ | 7,782 |  |  | $ | 5,806 |  |

[0001193125-16-574999:notes:39]
The Company did not capitalize any share-based compensation expense
 as part of any asset costs during the three and nine months ended
 March 25, 2016 and March 27, 2015.

[0001193125-16-574999:notes:40]
[same as prior period, unchanged from 0001193125-16-447643:notes:42]

[0001193125-16-574999:notes:41]
Share options have been granted to directors and employees. As of
 March 25, 2016, there were 5 share options outstanding under
 Fabrinet’s Amended and Restated 1999 Share Option Plan (the
 “1999 Plan”). Additional option grants may not be made
 under the 1999 Plan.

[0001193125-16-574999:notes:42]
As of March 25, 2016, there were an aggregate of 591,525 share
 options outstanding, 1,148,602 restricted share units outstanding,
 and 2,276,054 ordinary shares available for future grant under
 Fabrinet’s 2010 Performance Incentive Plan (the “2010
 Plan”). The 1999 Plan and 2010 Plan are collectively referred
 to as the “Share Option Plans”.

[0001193125-16-574999:notes:43]
[same as prior period, unchanged from 0001193125-16-447643:notes:45]

[0001193125-16-574999:notes:44]
[same as prior period, unchanged from 0001193125-16-447643:notes:46]

[0001193125-16-574999:notes:45]
[same as prior period, unchanged from 0001193125-16-447643:notes:47]

[0001193125-16-574999:notes:46]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price Per Share |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 26, 2015 |  |  | 792,019 |  |  |  | 758,451 |  |  | $ | 16.33 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (198,334 | ) |  |  |  |  |  | $ | 16.77 |  |  |  |  |  |
| Forfeited |  |  | (755 | ) |  |  |  |  |  | $ | 17.10 |  |  |  |  |  |
| Expired |  |  | (1,400 | ) |  |  |  |  |  | $ | 23.62 |  |  |  |  |  |
| Balance as of March 25, 2016 |  |  | 591,530 |  |  |  | 591,488 |  |  | $ | 16.16 |  |  |  |  |  |

[0001193125-16-574999:notes:47]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price Per Share |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 27, 2014 |  |  | 865,890 |  |  |  | 666,305 |  |  | $ | 16.27 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (50,867 | ) |  |  |  |  |  | $ | 14.50 |  |  |  |  |  |
| Forfeited |  |  | (8,249 | ) |  |  |  |  |  | $ | 15.91 |  |  |  |  |  |
| Expired |  |  | (6,787 | ) |  |  |  |  |  | $ | 20.80 |  |  |  |  |  |
| Balance as of March 27, 2015 |  |  | 799,987 |  |  |  | 741,957 |  |  | $ | 16.34 |  |  |  |  |  |

[0001193125-16-574999:notes:48]
The following summarizes information for share options outstanding
 as of March 25, 2016 under the Share Option Plans:

[0001193125-16-574999:notes:49]
|  |  | Number of Shares Underlying Options |  |  | Exercise Price Per Share |  |  | Weighted- Average Remaining Contractual Life (years) |  |  | Aggregate Intrinsic Value (amount in thousands) |  |
|  |  |  | 5 |  |  | $ | 5.75 |  |  |  | 0.65 |  |  |  |  |  |
|  |  |  | 315,482 |  |  | $ | 16.83 |  |  |  | 1.55 |  |  |  |  |  |
|  |  |  | 30,000 |  |  | $ | 15.05 |  |  |  | 1.61 |  |  |  |  |  |
|  |  |  | 12,300 |  |  | $ | 25.50 |  |  |  | 1.81 |  |  |  |  |  |
|  |  |  | 2,400 |  |  | $ | 26.16 |  |  |  | 1.86 |  |  |  |  |  |
|  |  |  | 20,853 |  |  | $ | 15.16 |  |  |  | 2.40 |  |  |  |  |  |
|  |  |  | 184,039 |  |  | $ | 14.12 |  |  |  | 2.63 |  |  |  |  |  |
|  |  |  | 20,818 |  |  | $ | 19.36 |  |  |  | 2.88 |  |  |  |  |  |
|  |  |  | 5,550 |  |  | $ | 18.60 |  |  |  | 2.93 |  |  |  |  |  |
|  |  |  | 83 |  |  | $ | 12.83 |  |  |  | 3.12 |  |  |  |  |  |
| Options outstanding |  |  | 591,530 |  |  |  |  |  |  |  | 1.99 |  |  | $ | 8,535 |  |
| Options exercisable |  |  | 591,488 |  |  |  |  |  |  |  | 1.99 |  |  | $ | 8,535 |  |

[0001193125-16-574999:notes:50]
As of March 25, 2016, there was $23.64 of unrecognized
 share-based compensation expense related to share options under the
 Share Option Plans that is expected to be recorded over a
 weighted-average period of 0.08 years.

[0001193125-16-574999:notes:51]
[same as prior period, unchanged from 0001193125-16-447643:notes:53]

[0001193125-16-574999:notes:52]
[same as prior period, unchanged from 0001193125-16-447643:notes:54]

[0001193125-16-574999:notes:53]
On May 24, 2015 the Company entered into an amended and
 restated employment agreement with an executive of the Company that
 provides for accelerated vesting of equity awards under certain
 circumstances. Under the agreement, any equity award granted to the
 executive after February 20, 2017, shall vest over a period
 not longer than two years following the applicable grant date. If
 the executive’s employment with the Company continues through
 and including February 20, 2017, any outstanding equity award
 grants before February 20, 2017 will become 100% vested.

[0001193125-16-574999:notes:54]
[same as prior period, unchanged from 0001193125-16-447643:notes:56]

[0001193125-16-574999:notes:55]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 26, 2015 |  |  | 1,140,927 |  |  | $ | 16.03 |  |
| Granted |  |  | 586,142 |  |  | $ | 19.82 |  |
| Issued |  |  | (492,124 | )(1) |  | $ | 15.53 |  |
| Forfeited |  |  | (86,343 | ) |  | $ | 17.44 |  |
| Balance as of March 25, 2016 |  |  | 1,148,602 |  |  | $ | 17.56 |  |

[0001193125-16-574999:notes:56]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 27, 2014 |  |  | 762,295 |  |  | $ | 14.23 |  |
| Granted |  |  | 608,544 |  |  | $ | 17.52 |  |
| Issued |  |  | (241,231 | ) |  | $ | 17.70 |  |
| Forfeited |  |  | (24,612 | ) |  | $ | 15.95 |  |
| Balance as of March 27, 2015 |  |  | 1,104,996 |  |  | $ | 15.97 |  |

[0001193125-16-574999:notes:57]
|  | (1) | Includes 283 shares vested on March 25, 2016, but not settled. |

[0001193125-16-574999:notes:58]
As of March 25, 2016, there was $9.3 million of unrecognized
 share-based compensation expense related to restricted share units
 under the 2010 Plan that is expected to be recorded over a
 weighted-average period of 2.78 years.

[0001193125-16-574999:notes:59]
For the nine months ended March 25, 2016 and March 27,
 2015, the Company withheld an aggregate of 111,584 shares and
 18,730 shares, respectively, upon the vesting of restricted share
 units, based upon the closing share price on the vesting date to
 settle the employees’ minimum statutory obligation for the
 applicable income and other employment taxes. For the nine months
 ended March 25, 2016 and March 27, 2015, the Company then
 remitted cash of $2.4 million and $0.3 million, respectively, to
 the appropriate taxing authorities, and presented it in a financing
 activity within the unaudited condensed consolidated statements of
 cash flows. The payment had the effect on shares issued by the
 Company as it reduced the number of shares that would have been
 issued on the vesting date and was recorded as a reduction of
 additional paid-in capital.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-16-574999:notes:60]
| 15. | Business segments and geographic information |

[0001193125-16-574999:notes:61]
Operating segments are defined as components of an enterprise for
 which separate financial information is available that is evaluated
 regularly by the chief operating decision maker in deciding how to
 allocate resources and in assessing performance. The
 Company’s chief operating decision maker is Fabrinet’s
 chief executive officer. As of March 25, 2016 and
 March 27, 2015, the Company operated and internally managed a
 single operating segment. Accordingly, the Company does not
 accumulate discrete information with respect to separate product
 lines and does not have separate reportable segments.

[0001193125-16-574999:notes:62]
[same as prior period, unchanged from 0001193125-16-447643:notes:65]

[0001193125-16-574999:notes:63]
As of March 25, 2016 and March 27, 2015, the Company had
 approximately $33.4 million and $25.8 million of long-lived assets
 based in North America, with the substantial remainder of assets
 based in Asia-Pacific.

[0001193125-16-574999:notes:64]
[same as prior period, unchanged from 0001193125-16-447643:notes:67]

[0001193125-16-574999:notes:65]
The Company had two customers that each contributed to 10% or more
 of its total account receivable as of March 25, 2016 and
 June 26, 2015, respectively.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-16-574999:notes:66]
The following table summarizes the cost and estimated fair value of
 marketable securities classified as available-for-sale securities
 based on stated effective maturities as of March 25, 2016:

[0001193125-16-574999:notes:67]
| (amount in thousands) |  | Carrying Cost |  |  | Fair Value |  |
| Due within one year |  | $ | 23,066 |  |  | $ | 23,070 |  |
| Due between one to three years |  |  | 121,669 |  |  |  | 121,738 |  |
| Total |  | $ | 144,735 |  |  | $ | 144,808 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001193125-16-574999:notes:68]
[same as prior period, unchanged from 0001193125-16-447643:notes:71]

[0001193125-16-574999:notes:69]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of March 25, 2016 and for the three
 and nine months ended March 25, 2016 and March 27, 2015
 includes only normal recurring adjustments, necessary for a fair
 statement of the financial statements set forth herein, in
 accordance with accounting principles generally accepted in the
 United States of America (“U.S. GAAP”) for interim
 financial information and rules and regulations of the Securities
 and Exchange Commission (“SEC”). Accordingly, such
 information does not include all of the information and footnotes
 required by U.S. GAAP for annual financial statements. For further
 information, please refer to the consolidated financial statements
 and footnotes thereto included in Fabrinet’s Annual Report on
 Form 10-K for the year ended June 26, 2015.

[0001193125-16-574999:notes:70]
The balance sheet as of June 26, 2015 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three and nine
 months ended March 25, 2016 and March 27, 2015 may not be
 indicative of results for the year ending June 24, 2016 or any
 future periods.


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-16-574999:notes:71]
[same as prior period, unchanged from 0001193125-16-447643:notes:74]

[0001193125-16-574999:notes:72]
[same as prior period, unchanged from 0001193125-16-447643:notes:75]

[0001193125-16-574999:notes:73]
[same as prior period, unchanged from 0001193125-16-447643:notes:76]

[0001193125-16-574999:notes:74]
[same as prior period, unchanged from 0001193125-16-447643:notes:77]

[0001193125-16-574999:notes:75]
[same as prior period, unchanged from 0001193125-16-447643:notes:78]

[0001193125-16-574999:notes:76]
[same as prior period, unchanged from 0001193125-16-447643:notes:79]

[0001193125-16-574999:notes:77]
[same as prior period, unchanged from 0001193125-16-447643:notes:80]

[0001193125-16-574999:notes:78]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of March 25, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 2,315 |  |  | $ | — |  |  | $ | 2,315 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 116,558 |  |  |  | — |  |  |  | 116,558 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 27,752 |  |  |  | — |  |  |  | 27,752 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 498 |  |  |  | — |  |  |  | 498 |  |
| Derivative assets |  |  | — |  |  |  | 674 | (1) |  |  | — |  |  |  | 674 |  |
| Total |  | $ | — |  |  | $ | 147,797 |  |  | $ | — |  |  | $ | 147,797 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 2,334 | (2) |  | $ | — |  |  | $ | 2,334 |  |
| Total |  | $ | — |  |  | $ | 2,334 |  |  | $ | — |  |  | $ | 2,334 |  |
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 26, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 7,430 |  |  | $ | — |  |  | $ | 7,430 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 120,101 |  |  |  | — |  |  |  | 120,101 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 21,027 |  |  |  | — |  |  |  | 21,027 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 1,738 |  |  |  | — |  |  |  | 1,738 |  |
| Derivative assets |  |  | — |  |  |  | 4 | (3) |  |  | — |  |  |  | 4 |  |
| Total |  | $ | — |  |  | $ | 150,300 |  |  | $ | — |  |  | $ | 150,300 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 371 | (4) |  | $ | — |  |  | $ | 371 |  |
| Total |  | $ | — |  |  | $ | 371 |  |  | $ | — |  |  | $ | 371 |  |

[0001193125-16-574999:notes:79]
|  | (1) | Foreign currency forward contracts with notional amount of $30.0 million. |

[0001193125-16-574999:notes:80]
|  | (2) | Foreign currency forward contracts with notional amount of $102.0 million and Canadian Dollars 0.3 million. |

[0001193125-16-574999:notes:81]
|  | (3) | Foreign currency options with notional amount of $3.0 million and forward contracts with notional amount of Canadian Dollars 0.4 million. |

[0001193125-16-574999:notes:82]
|  | (4) | Foreign currency options with notional amount of $41.0 million. |

[0001193125-16-574999:notes:83]
[same as prior period, unchanged from 0001193125-16-447643:notes:86]

[0001193125-16-574999:notes:84]
As a result of foreign currency rate fluctuations, the U.S. dollar
 equivalent values of the Company’s foreign currency
 denominated assets and liabilities change. The Company uses foreign
 currency contracts to manage the foreign exchange risk associated
 with certain foreign currency denominated assets and liabilities
 and other foreign currency transactions. The Company minimizes the
 credit risk in derivative instruments by limiting its exposure to
 any single counterparty and by entering into derivative instruments
 only with counterparties that meet the Company’s minimum
 credit quality standard. As of March 25, 2016 and
 June 26, 2015, the Company recognized the fair value of
 foreign currency forward contracts and options of $1.7 million and
 $0.4 million, respectively, as derivative liabilities in condensed
 consolidated balance sheet.

[0001193125-16-574999:notes:85]
As of March 25, 2016, the Company hedges forecasted foreign
 currency transactions related to its operating expenses and other
 costs and the construction costs of a new manufacturing building at
 the Company’s Chonburi campus with certain forward contracts,
 designated as cash flow hedges. The Company had six outstanding
 forward contracts with notional amount of $30.0 million, mature
 during April 2016 to September 2016. The Company included
 unrealized gain of $0.7 million from changes in fair value of
 foreign currency forward contracts, designated as hedging
 instrument, in accumulated other comprehensive income in unaudited
 condensed consolidated balance sheets. There was no ineffective
 portion during the three and nine months ended March 25, 2016.
 As of March 27, 2015, the Company had no foreign currency
 forward contracts designated as cash flow hedges.

[0001193125-16-574999:notes:86]
The following table presents the effect of foreign currency forward
 contracts, designated as cash flow hedges, and their classification
 within comprehensive income:

[0001193125-16-574999:notes:87]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 25, 2016 |  |  | March 27, 2015 |  |
| Currency contracts that hedge costs of sales |  | $ | 483 |  |  | $ | — |  |
| Currency contracts that hedge operating expenses |  |  | 36 |  |  |  | — |  |
| Currency contracts that hedge construction costs |  |  | 155 |  |  |  | — |  |
|  |  | $ | 674 |  |  | $ | — |  |

[0001193125-16-574999:notes:88]
There was no discontinued of cash flow hedges which recognized in
 the unaudited condensed consolidated statements of operations and
 comprehensive income during the three and nine months ended
 March 25, 2016.

[0001193125-16-574999:notes:89]
As of March 25, 2016, the Company had 17 outstanding foreign
 currency forward contracts with notional amount of $102.0 million
 and Canadian Dollars 0.3 million, maturing during June 2016 to
 December 2016. These foreign currency forward contracts were not
 designated for hedge accounting and were used to hedge fluctuations
 in the U.S. Dollar value of forecasted transactions
 denominated in Thai Baht and Canadian Dollar. During the nine
 months ended March 25, 2016, the Company included unrealized
 loss of $2.3 million from changes in fair value of foreign currency
 contracts in earnings in unaudited condensed consolidated
 statements of operations and comprehensive income.

[0001193125-16-574999:notes:90]
As of March 27, 2015, the Company had 46 outstanding foreign
 currency forward contracts and options with notional amount of
 $45.0 million and Canadian Dollars 0.4 million, maturing
 during April 2015 to July 2015. These foreign currency forward
 contracts and options were not designated for hedge accounting and
 were used to hedge fluctuations in the U.S. Dollar value of
 forecasted transactions denominated in Thai Baht and Canadian
 Dollar. During the nine months ended March 27, 2015, the
 Company included unrealized gain of $0.2 million from changes in
 fair value of foreign currency contracts in earnings in unaudited
 condensed consolidated statements of operations and comprehensive
 income.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-16-574999:notes:91]
[same as prior period, unchanged from 0001193125-16-447643:notes:90]

[0001193125-16-574999:notes:92]
[same as prior period, unchanged from 0001193125-16-447643:notes:91]

[0001193125-16-574999:notes:93]
[same as prior period, unchanged from 0001193125-16-447643:notes:92]

[0001193125-16-574999:notes:94]
[same as prior period, unchanged from 0001193125-16-447643:notes:93]

[0001193125-16-574999:notes:95]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended
 March 25, 2016 and March 27, 2015 each consisted of 13
 weeks. The nine months ended March 25, 2016 and March 27,
 2015 each consisted of 39 weeks. Fiscal year 2016 will be comprised
 of 52 weeks and will end on June 24, 2016.

[0001193125-16-574999:notes:96]
[same as prior period, unchanged from 0001193125-16-447643:notes:95]

[0001193125-16-574999:notes:97]
[same as prior period, unchanged from 0001193125-16-447643:notes:96]

[0001193125-16-574999:notes:98]
[same as prior period, unchanged from 0001193125-16-447643:notes:97]

[0001193125-16-574999:notes:99]
[same as prior period, unchanged from 0001193125-16-447643:notes:98]

[0001193125-16-574999:notes:100]
Derivatives

[0001193125-16-574999:notes:101]
The derivatives assets and liabilities are recognized on the
 consolidated balance sheets as other current assets or accrued
 expenses at fair value.

[0001193125-16-574999:notes:102]
The Company applies hedge accounting to arrangements that qualify
 and are designated for cash flow hedge accounting treatment. Hedge
 accounting is discontinued prospectively if the hedging
 relationship ceases to be effective or the hedging or hedged items
 cease to exist as a result of maturity, sale, termination or
 cancellation.

[0001193125-16-574999:notes:103]
Derivatives designated and qualifying as hedges of the exposure to
 variability in expected future cash flows, or other types of
 forecasted transactions, are considered cash flow hedges which
 include forward currency contracts. In a cash flow hedging
 relationship, the effective portion of the change in the fair value
 of the hedging derivative is initially recorded in accumulated
 other comprehensive income (loss), while any ineffective portion is
 recognized directly in earnings, as a component of other income
 (expense). The portion of gain or loss on the derivative instrument
 remains in accumulated other comprehensive (loss) income until the
 forecasted transaction is recognized in earnings.

[0001193125-16-574999:notes:104]
The Company also enters into derivative contracts that are intended
 to economically hedge certain of the Company’s risks. The
 changes in the fair value of the derivatives are recorded directly
 in earnings as a component of other income (expense), net. In
 accordance with the fair value measurement guidance, the
 Company’s accounting policy is to measure the credit risk of
 our derivative financial instruments that are subject to master
 netting agreements on a net basis by counterparty portfolio. The
 Company executes derivative instruments with financial institutions
 that are credit-worthy, defined as institutions that hold an
 investment grade credit rating.

[0001193125-16-574999:notes:105]
[same as prior period, unchanged from 0001193125-16-447643:notes:99]

[0001193125-16-574999:notes:106]
In March 2016, the Financial Accounting Standards Board
 (“FASB”) issued Accounting Standards Update
 (“ASU”) 2016-09, “Compensation - Stock
 Compensation (Topic 718): Improvements to Employee Share-Based
 Payment Accounting”. This ASU simplifies several aspects of
 the accounting for share-based payment award transactions,
 including, the income tax consequences, classification of awards as
 either equity or liabilities and classification on the statement of
 cash flows. The amendments in this update are effective for annual
 periods beginning after December 15, 2016, and interim periods
 within those annual periods, for public companies. Early adoption
 is permitted for any entity in any interim or annual period. The
 Company is currently evaluating the impact of adoption of this
 update on its consolidated financial statements.

[0001193125-16-574999:notes:107]
In March 2016, the FASB issued ASU 2016-08, “Revenue from
 Contracts with Customers (Topic 606): Principal versus Agent
 Considerations (Reporting Revenue Gross versus Net)” to
 clarify the implementation guidance on principal versus agent
 considerations. The effective date and transition requirements for
 this amendments are the same as ASU 2014-09, which defers by one
 year. The Company is currently evaluating the impact of adoption of
 this update on its consolidated financial statements.

[0001193125-16-574999:notes:108]
In March 2016, the FASB issued ASU 2016-05, “Derivatives and
 Hedging (Topic 815)”, to clarify that a change in the
 counterparty to a derivative instrument that has been designated as
 a hedging instrument under Topic 815, does not, in and of itself,
 require designation of the hedging relationship, provided that all
 other hedge accounting criteria continue to be met. This guidance
 is effective for public entities for financial statements issued
 for fiscal years beginning after December 15, 2016 and interim
 periods within those fiscal years. Early adoption is permitted. The
 Company is currently evaluating the impact of adoption of this
 update on its consolidated financial statements.

[0001193125-16-574999:notes:109]
In February 2016, the FASB issued ASU 2016-02, “Lease (Topic
 842)”. The core principle of Topic 842 is that a lessee
 should recognize the lease assets and liabilities that arise from
 leases in the statement of financial position. For public business
 entities, this update is effective for fiscal years beginning after
 December 15, 2018, including interim periods within those
 fiscal years. Early application is permitted. The Company is
 currently evaluating the impact of adoption of this update on its
 consolidated financial statements.

[0001193125-16-574999:notes:110]
In January 2016, the FASB issued ASU 2016-01, “Financial
 Instruments - Overall (Subtopic 825-10): Recognition and
 Measurement of Financial Assets and Financial Liabilities”.
 This new guidance requires certain equity investments to be
 measured at fair value, use of the exit price notion and separate
 presentation of financial assets and financial liabilities by
 measurement category and form of financial asset on the balance
 sheet or the accompanying notes to the financial statements. The
 ASU on recognition and measurement will take effect for public
 companies for fiscal years beginning after December 15, 2017,
 including interim periods within those fiscal years. The
 Company is currently evaluating the impact of adoption of this
 update on its consolidated financial statements.

[0001193125-16-574999:notes:111]
In November 2015, the FASB issued ASU 2015-17, “Balance Sheet
 Classification of Deferred Taxes”, which will require
 entities to present deferred tax assets (“DTAs”) and
 deferred tax liabilities (“DTLs”) as non-current in a
 classified balance sheet. The ASU simplifies the current guidance,
 which requires entities to separately present DTAs and DTLs as
 current and non-current in a classified balance sheet. For public
 business entities, the amendments in this ASU are effective for
 financial statements issued for annual periods beginning after
 December 15, 2016, and interim periods within those annual
 periods. The Company is currently evaluating the impact of adoption
 of this update on its consolidated financial statements.

[0001193125-16-574999:notes:112]
In August 2015, the FASB issued ASU 2015-15, “Interest
 – Imputation of Interest (Subtopic 835-30): Presentation and
 Subsequent Measurement of Debt Issuance Costs Associated with
 Line-of-Credit Arrangements”. This ASU amended ASU 2015-03
 regarding debt issuance costs related to the line-of-credit
 arrangement. The Company does not anticipate that the adoption of
 this update will have an effect on its consolidated financial
 statements.

[0001193125-16-574999:notes:113]
In July 2015, the FASB issued ASU 2015-11, “Inventory (Topic
 330): Simplifying the Measurement of Inventory”. The update
 provides the guidance that an entity, that measured inventory by
 using first-in, first-out or average cost, should measure inventory
 at the lower of cost and net realizable value. Subsequent
 measurement is unchanged for inventory measured using last-in,
 first-out or the retail inventory method. The update is effective
 for fiscal years beginning after December 15, 2016, including
 interim periods within these fiscal years. This update should be
 applied prospectively with earlier application permitted as of the
 beginning of an interim or annual reporting date. The Company is
 currently evaluating the impact of adoption of this update on its
 consolidated financial statements.

[0001193125-16-574999:notes:114]
In April 2015, the FASB issued ASU 2015-03, “Interest -
 Imputation of Interest (Subtopic 835-30): Simplifying the
 Presentation of Debt Issuance Costs”. The update requires
 debt issuance costs related to a recognized debt liability be
 presented in the balance sheet as a direct deduction from the
 carrying amount of the related debt liability instead of being
 presented as an asset. Debt disclosures will include the face
 amount of the debt liability and the effective interest rate. The
 update requires retrospective application and represents a change
 in accounting principle. The update is effective for fiscal years
 beginning after December 15, 2015. Early adoption is permitted
 for financial statements that have not been previously issued. The
 Company is currently evaluating the impact of adoption of this
 update on its consolidated financial statements.

[0001193125-16-574999:notes:115]
In February 2015, the FASB issued ASU 2015-02, “Consolidation
 (Topic 810): Amendments to the Consolidation Analysis”. ASU
 No. 2015-02 amended the process that a reporting entity must
 perform to determine whether it should consolidate certain types of
 legal entities. ASU No. 2015-02 is effective for fiscal years,
 and for interim periods within those fiscal years beginning after
 December 15, 2015. Early adoption is permitted, including
 adoption in an interim period. The Company is currently evaluating
 the impact of adoption of this update on its consolidated financial
 statements.

[0001193125-16-574999:notes:116]
In January 2015, the FASB issued ASU No. 2015-01,
 “Income Statement – Extraordinary and Unusual Items
 (Subtopic 225-20): Simplifying Income Statement Presentation by
 Eliminating the Concept of Extraordinary Items”. The
 objective of this amendment is to reduce the complexity in
 accounting standards by eliminating the concept of extraordinary
 items from U.S. GAAP. The following criteria must both be met for
 extraordinary classification: (a) the underlying event or
 transaction should possess a high degree of abnormality and be of a
 type clearly unrelated to, or only incidentally related to, the
 ordinary and typical activities of the entity; and (b) the
 underlying event or transaction should not reasonably be expected
 to recur in the foreseeable future. This amendment is effective for
 fiscal years and interim periods beginning after December 15,
 2015. Early adoption is permitted provided that the guidance is
 applied from the beginning of the fiscal year of adoption. The
 Company does not expect that the adoption of this update will have
 an effect on its consolidated financial statements.

[0001193125-16-574999:notes:117]
In August 2014, the FASB issued ASU No. 2014-15,
 “Presentation of Financial Statements – Going Concern
 (Subtopic 205-40): Disclosure of Uncertainties about an
 Entity’s Ability to Continue as a Going Concern”. The
 amendments require management to evaluate, for each annual and
 interim reporting period, an entity’s ability to continue as
 a going concern when relevant conditions and events, considered in
 the aggregate, indicate that it is probable that the entity will be
 unable to meet its obligations that become due within one year
 after the date that the financial statements are issued (or
 available to be issued). This ASU is effective for annual periods
 and interim reporting periods beginning after December 15,
 2016. The Company does not expect that the adoption of this update
 will have an effect on its consolidated financial statements.

[0001193125-16-574999:notes:118]
In June 2014, the FASB issued ASU No. 2014-12,
 “Compensation – Stock Compensation (Topic 718):
 Accounting for Share-Based Payments When the Terms of an Award
 Provide That a Performance Target Could Be Achieved After the
 Requisite Service Period”. This ASU requires that a
 performance target that affects vesting, and that could be achieved
 after the requisite service period, be treated as a performance
 condition. As such, the performance target should not be reflected
 in estimating the grant date fair value of the award. Compensation
 cost should be recognized in the period in when performance target
 will probably be achieved and should represent attributable to the
 period(s) for which the requisite service has already been
 rendered. This update is required to be adopted by all public
 companies for annual periods and interim reporting periods
 beginning after December 15, 2015, with early adoption
 permitted. The Company does not expect that the adoption of this
 update will have an effect on its consolidated financial
 statements.

[0001193125-16-574999:notes:119]
In May 2014, the FASB issued ASU 2014-09, “Revenue from
 Contracts with Customers (Topic 606), issued as a new Topic,
 Accounting Standards Codification”. The core principle of
 this amendment is that an entity should recognize revenue to depict
 the transfer of promised goods or services to customers in an
 amount that reflects the consideration to which the entity expects
 to be entitled in exchange for those goods or services. This ASU is
 effective, as amended by ASU 2015-14, for annual reporting periods
 beginning after December 15, 2017, including interim periods
 within that reporting period. Earlier application of this guidance
 is permitted by not before the original date of December 15,
 2016, which can be adopted either retrospectively to each prior
 reporting period presented or as a cumulative-effect adjustment as
 of the date of adoption. In April 2016, the FASB issued ASU
 2016-10, with the same effective date as ASU 2015-14, to address
 the potential diversity in practice at initial application and
 cost; and the complexity of applying Topic 606, both at transition
 and on an ongoing basis related to identification of performance
 obligations and licensing arrangements. The Company is currently
 evaluating the impact of adoption of this update on its
 consolidated financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001193125-16-574999:notes:120]
[same as prior period, unchanged from 0001193125-16-447643:notes:113]

[0001193125-16-574999:notes:121]
[same as prior period, unchanged from 0001193125-16-447643:notes:114]

[0001193125-16-574999:notes:122]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands except per share amounts) |  | March 25, 2016 |  |  | March 27, 2015 |  |  | March 25, 2016 |  |  | March 27, 2015 |  |
| Net income attributable to shareholders |  | $ | 20,822 |  |  | $ | 10,845 |  |  | $ | 42,228 |  |  | $ | 30,607 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  | 35,964 |  |  |  | 35,406 |  |  |  | 35,785 |  |  |  | 35,328 |  |
| Incremental shares arising from the assumed exercise of share options and vesting of restricted share units (thousands of shares) |  |  | 1,125 |  |  |  | 704 |  |  |  | 958 |  |  |  | 543 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 37,089 |  |  |  | 36,110 |  |  |  | 36,743 |  |  |  | 35,871 |  |
| Basic earnings per ordinary share |  | $ | 0.58 |  |  | $ | 0.31 |  |  | $ | 1.18 |  |  | $ | 0.87 |  |
| Diluted earnings per ordinary share |  | $ | 0.56 |  |  | $ | 0.30 |  |  | $ | 1.15 |  |  | $ | 0.85 |  |
| Outstanding share options excluded in the computation of diluted earnings per ordinary share (1) |  |  | — |  |  |  | 69,354 |  |  |  | — |  |  |  | 69,354 |  |

[0001193125-16-574999:notes:123]
|  | (1) | These share options were not included in the computation of diluted earnings per ordinary share because the exercise price of the options was greater than the average market price of the underlying shares. |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-16-574999:notes:124]
| 13. | Accumulated other comprehensive income (loss) |

[0001193125-16-574999:notes:125]
The changes in accumulated other comprehensive income (loss) for
 the nine months ended March 25, 2016 were as follows:

[0001193125-16-574999:notes:126]
| (amount in thousands) |  | Unrealized net (Losses)/Gains on Marketable Securities |  |  | Unrealized net Gains on Derivative Instruments |  |  | Total |  |
| Balance as of June 26, 2015 |  | $ | (44 | ) |  | $ | — |  |  | $ | (44 | ) |
| Other comprehensive income before reclassification adjustment |  |  | 2,645 |  |  |  | 674 |  |  |  | 3,319 |  |
| Amounts reclassified out of accumulated other comprehensive income to interest income in unaudited condensed consolidated statement of operations and comprehensive income |  |  | (2,528 | ) |  |  | — |  |  |  | (2,528 | ) |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income |  | $ | 117 |  |  | $ | 674 |  |  | $ | 791 |  |
| Balance as of March 25, 2016 |  | $ | 73 |  |  | $ | 674 |  |  | $ | 747 |  |


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001193125-16-574999:notes:127]
[same as prior period, unchanged from 0001193125-16-447643:notes:120]

[0001193125-16-574999:notes:128]
[same as prior period, unchanged from 0001193125-16-447643:notes:121]

[0001193125-16-574999:notes:129]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Gain/(Loss) |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of March 25, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 125,642 |  |  | $ | — |  |  | $ | 125,642 |  |  | $ | — |  |
| Cash equivalents |  |  | 2,315 |  |  |  | — |  |  |  | 2,315 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 116,439 |  |  |  | 119 |  |  |  | — |  |  |  | 116,558 |  |
| U.S. agency and U.S. treasury securities |  |  | 27,798 |  |  |  | (46 | ) |  |  | — |  |  |  | 27,752 |  |
| Sovereign and municipal securities |  |  | 498 |  |  |  | — |  |  |  | — |  |  |  | 498 |  |
| Total |  | $ | 272,692 |  |  | $ | 73 |  |  | $ | 127,957 |  |  | $ | 144,808 |  |

[0001193125-16-574999:notes:130]
|  |  |  |  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized (Loss)/Gain |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of June 26, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 105,548 |  |  | $ | — |  |  | $ | 105,548 |  |  | $ | — |  |
| Cash equivalents |  |  | 7,430 |  |  |  | — |  |  |  | 7,430 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 120,144 |  |  |  | (43 | ) |  |  | — |  |  |  | 120,101 |  |
| U.S. agency and U.S. treasury securities |  |  | 21,029 |  |  |  | (2 | ) |  |  | — |  |  |  | 21,027 |  |
| Sovereign and municipal securities |  |  | 1,737 |  |  |  | 1 |  |  |  | — |  |  |  | 1,738 |  |
| Total |  | $ | 255,888 |  |  | $ | (44 | ) |  | $ | 112,978 |  |  | $ | 142,866 |  |

[0001193125-16-574999:notes:131]
[same as prior period, unchanged from 0001193125-16-447643:notes:124]

[0001193125-16-574999:notes:132]
During the three and nine months ended March 25, 2016, the
 Company recognized realized loss of $0.1 million and $0.2 million,
 respectively.

[0001193125-16-574999:notes:133]
As of March 25, 2016, the Company considered the declines in
 market value of its marketable securities investment portfolio to
 be temporary in nature and did not consider any of its securities
 other-than-temporarily impaired. The Company typically invests in
 highly-rated securities, and its investment policy generally limits
 the amount of credit exposure to any one issuer. The policy
 requires investments generally to be investment grade, with the
 primary objective of minimizing the potential risk of principal
 loss. Fair values were determined for each individual security in
 the investment portfolio. When evaluating an investment for
 other-than-temporary impairment, the Company reviews factors such
 as the length of time and extent to which fair value has been below
 its cost basis, the financial condition of the issuer and any
 changes thereto, changes in market interest rates, and the
 Company’s intent to sell, or whether it is more likely than
 not it will be required to sell, the investment before recovery of
 the investment’s cost basis. No impairment losses were
 recorded for the three and nine months ended March 25,
 2016.

[0001193125-16-574999:notes:134]
As of March 25, 2016, cash, cash equivalents, and marketable
 securities included bank deposits of $40.0 million held in various
 financial institutions located in the United States in order to
 support the availability of the Facility Agreement (as defined in
 Note 9) and comply with covenants. As discussed in Note 9, under
 the terms and conditions of the Facility Agreement, the Company
 shall maintain cash, cash equivalents and/or marketable securities
 in an aggregate amount not less than $40.0 million in unencumbered
 deposits, and/or securities in accounts located in the United
 States at all times during the term of the Facility Agreement. The
 Company must comply with the covenant from and after the effective
 date of the Facility Agreement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-16-574999:notes:135]
| 10. | Income taxes |

[0001193125-16-574999:notes:136]
As of March 25, 2016 and June 26, 2015, the liability for
 uncertain tax positions including accrued interest and penalties
 was $1.7 million and $1.6 million, respectively. The Company
 expects the estimated amount of liability associated with its
 uncertain tax positions to decrease within the next 12 months
 due to the lapse of the applicable statute of limitations in
 foreign tax jurisdictions.

[0001193125-16-574999:notes:137]
[same as prior period, unchanged from 0001193125-16-447643:notes:130]

[0001193125-16-574999:notes:138]
The effective tax rate for the Company for the three months ended
 March 25, 2016 and March 27, 2015 was 5.8% and 7.0% of
 net income, respectively. The decrease in the effective tax rate
 for the three months ended March 25, 2016 was primarily due to
 the fact that the Company had lower taxable income during the three
 months ended March 25, 2016 as compared to the three months
 ended March 27, 2015.

[0001193125-16-574999:notes:139]
The effective tax rate for the Company for the nine months ended
 March 25, 2016 and March 27, 2015 was 6.4% and 6.6% of
 net income, respectively. The slight decrease in the effective tax
 rate for the nine months ended March 25, 2016 was primarily
 due to the fact that the Company had lower taxable income during
 the nine months ended March 25, 2016 as compared to the nine
 months ended March 27, 2015.


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001193125-16-574999:notes:140]
| 16. | Other income related to flooding |

[0001193125-16-574999:notes:141]
During the week of August 10, 2015, the Company’s
 subsidiary in China temporarily suspended production in its
 manufacturing facility due to flooding caused by Typhoon Soudelor.
 The subsidiary resumed operations on August 15, 2015. During
 the three months ended March 25, 2016, the Company received a
 final payment of $0.8 million from an insurer against the
 Company’s claim for flood damage.

[0001193125-16-574999:notes:142]
During the three months ended March 25, 2016, the Company
 recognized other income related to flooding of $0.9 million, which
 primarily consisted of a payment of $0.8 million from an insurer
 against the Company’s claim for flood damage.

[0001193125-16-574999:notes:143]
During the nine months ended March 25, 2016, the Company
 recognized other income related to flooding of $0.04 million, which
 mainly consisted of $0.8 million from an insurer against the
 Company’s claim for flood damage, offset by expenses in
 relation to flood of $0.8 million, which mainly consisted of $0.6
 million of repaired cost of equipment and $0.2 million of inventory
 losses.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-16-574999:notes:144]
| 12. | Shareholders’ equity |

[0001193125-16-574999:notes:145]
[same as prior period, unchanged from 0001193125-16-447643:notes:137]

[0001193125-16-574999:notes:146]
[same as prior period, unchanged from 0001193125-16-447643:notes:138]

[0001193125-16-574999:notes:147]
For the nine months ended March 25, 2016, Fabrinet issued
 198,334 ordinary shares upon the exercise of options, for cash
 consideration at a weighted-average exercise price of $16.77 per
 share, and 380,257 ordinary shares upon the vesting of restricted
 share units, net of shares withheld.

[0001193125-16-574999:notes:148]
For the nine months ended March 27, 2015, Fabrinet issued
 50,867 ordinary shares upon the exercise of options, for cash
 consideration at a weighted-average exercise price of $14.50 per
 share, and 222,501 ordinary shares upon the vesting of restricted
 share units, net of shares withheld.

[0001193125-16-574999:notes:149]
[same as prior period, unchanged from 0001193125-16-447643:notes:141]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-16-574999:notes:150]
| 14. | Commitments and contingencies |

[0001193125-16-574999:notes:151]
Bank guarantees

[0001193125-16-574999:notes:152]
As of March 25, 2016 and June 26, 2015, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $0.8 million and $0.8 million, respectively.

[0001193125-16-574999:notes:153]
Operating lease commitments

[0001193125-16-574999:notes:154]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, and New Jersey under operating lease arrangements
 that expire in various calendar years through 2020. Rental expense
 under these operating leases amounted to $0.9 million and $0.8
 million for the nine months ended March 25, 2016 and
 March 27, 2015, respectively.

[0001193125-16-574999:notes:155]
As of March 25, 2016, the future minimum lease payments due
 under non-cancelable leases during each fiscal year were as
 follows:

[0001193125-16-574999:notes:156]
| (amount in thousands) |  |  |  |
| 2016 |  | $ | 289 |  |
| 2017 |  |  | 1,039 |  |
| 2018 |  |  | 1,040 |  |
| 2019 |  |  | 581 |  |
| 2020 |  |  | 372 |  |
| Thereafter |  |  | 18 |  |
| Total minimum operating lease payments |  | $ | 3,339 |  |

[0001193125-16-574999:notes:157]
Purchase obligations

[0001193125-16-574999:notes:158]
Purchase obligations represent legally-binding commitments to
 purchase inventory and other commitments made in the normal course
 of business to meet operational requirements. Although open
 purchase orders are considered enforceable and legally binding,
 their terms generally give the Company the option to cancel,
 reschedule and/or adjust its requirements based on its business
 needs prior to the delivery of goods or performance of services.
 Obligations to purchase inventory and other commitments are
 generally expected to be fulfilled within one year.

[0001193125-16-574999:notes:159]
As of March 25, 2016, the Company had an outstanding
 commitment to third parties of approximately $35.4 million, mainly
 related to the construction of a new manufacturing building at the
 Company’s Chonburi campus.

[0001193125-16-574999:notes:160]
Indemnification of directors and officers

[0001193125-16-574999:notes:161]
Cayman Islands law does not limit the extent to which a
 company’s memorandum and articles of association may provide
 for indemnification of directors and officers, except to the extent
 any such provision may be held by the Cayman Islands courts to be
 contrary to public policy, such as to provide indemnification
 against civil fraud or the consequences of committing a crime.
 Fabrinet’s amended and restated memorandum and articles of
 association provide for indemnification of directors and officers
 for actions, costs, charges, losses, damages and expenses incurred
 in their capacities as such, except that such indemnification does
 not extend to any matter in respect of any fraud or dishonesty that
 may attach to any of them.

[0001193125-16-574999:notes:162]
In accordance with Fabrinet’s form of indemnification
 agreement for its directors and officers, Fabrinet has agreed to
 indemnify its directors and officers against certain liabilities
 and expenses incurred by such persons in connection with claims by
 reason of their being such a director or officer. Fabrinet
 maintains a director and officer liability insurance policy that
 may enable it to recover a portion of any future amounts paid under
 the indemnification agreements.


## us-gaap:ScheduleOfCreditLossesForFinancingReceivablesCurrentTableTextBlock

[0001193125-16-574999:notes:163]
[same as prior period, unchanged from 0001193125-16-447643:notes:157]

[0001193125-16-574999:notes:164]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 25, 2016 |  |  | March 27, 2015 |  |
| Balance, beginning of period |  | $ | 50 |  |  | $ | 37 |  |
| (Credit) charged to expense |  |  | (7 | ) |  |  | 3 |  |
| Balance, end of period |  | $ | 43 |  |  | $ | 40 |  |


## fn:AllowanceForDoubtfulAccountsTextBlock

[0001193125-16-574999:notes:165]
[same as prior period, unchanged from 0001193125-16-447643:notes:159]
