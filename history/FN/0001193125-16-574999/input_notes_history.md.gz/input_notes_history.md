# FN note change history — 0001193125-16-447643 → 0001193125-16-574999


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-05-03):
[0001193125-16-574999:note_history:1]
As of March 25, 2016 and June 26, 2015, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $0.8 million and $0.8 million, respectively.
  (was, 2016-02-02, similarity 0.97):
[0001193125-16-447643:note_history:1]
As of December 25, 2015 and June 26, 2015, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $0.8 million and $0.8 million, respectively.

- changed (2016-05-03):
[0001193125-16-574999:note_history:2]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, and New Jersey under operating lease arrangements
 that expire in various calendar years through 2020. Rental expense
 under these operating leases amounted to $0.9 million and $0.8
 million for the nine months ended March 25, 2016 and
 March 27, 2015, respectively.
  (was, 2016-02-02, similarity 0.8983):
[0001193125-16-447643:note_history:2]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, and New Jersey under operating lease arrangements
 that expire in various calendar years through 2020. Rental expense
 under these operating leases amounted to $0.6 million and $0.5
 million for the six months ended December 25, 2015 and
 December 26, 2014, respectively.

- changed (2016-05-03):
[0001193125-16-574999:note_history:3]
As of March 25, 2016, the future minimum lease payments due
 under non-cancelable leases during each fiscal year were as
 follows:
  (was, 2016-02-02, similarity 0.7923):
[0001193125-16-447643:note_history:3]
As of December 25, 2015, the future minimum lease payments due
 under non-cancelable leases were as follows at the end of each
 fiscal year below:

- changed (2016-05-03):
[0001193125-16-574999:note_history:4]
As of March 25, 2016, the Company had an outstanding
 commitment to third parties of approximately $35.4 million, mainly
 related to the construction of a new manufacturing building at the
 Company’s Chonburi campus.
  (was, 2016-02-02, similarity 0.9684):
[0001193125-16-447643:note_history:4]
As of December 25, 2015, the Company had an outstanding
 commitment to third parties of approximately $33.3 million, mainly
 related to the construction of a new manufacturing building at the
 Company’s Chonburi campus.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-05-03):
[0001193125-16-574999:note_history:5]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of March 25, 2016 and for the three
 and nine months ended March 25, 2016 and March 27, 2015
 includes only normal recurring adjustments, necessary for a fair
 statement of the financial statements set forth herein, in
 accordance with accounting principles generally accepted in the
 United States of America (“U.S. GAAP”) for interim
 financial information and rules and regulations of the Securities
 and Exchange Commission (“SEC”). Accordingly, such
 information does not include all of the information and footnotes
 required by U.S. GAAP for annual financial statements. For further
 information, please refer to the consolidated financial statements
 and footnotes thereto included in Fabrinet’s Annual Report on
 Form 10-K for the year ended June 26, 2015.
  (was, 2016-02-02, similarity 0.955):
[0001193125-16-447643:note_history:5]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of December 25, 2015 and for the
 three and six months ended December 25, 2015 and
 December 26, 2014 includes only normal recurring adjustments,
 necessary for a fair statement of the financial statements set
 forth herein, in accordance with accounting principles generally
 accepted in the United States of America (“U.S. GAAP”)
 for interim financial information and rules and regulations of the
 Securities and Exchange Commission (“SEC”).
 Accordingly, such information does not include all of the
 information and footnotes required by U.S. GAAP for annual
 financial statements. For further information, please refer to the
 consolidated financial statements and footnotes thereto included in
 Fabrinet’s Annual Report on Form 10-K for the year ended
 June 26, 2015.

- changed (2016-05-03):
[0001193125-16-574999:note_history:6]
The balance sheet as of June 26, 2015 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three and nine
 months ended March 25, 2016 and March 27, 2015 may not be
 indicative of results for the year ending June 24, 2016 or any
 future periods.
  (was, 2016-02-02, similarity 0.8945):
[0001193125-16-447643:note_history:6]
The balance sheet as of June 26, 2015 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three and six
 months ended December 25, 2015 and December 26, 2014 may
 not be indicative of results for the year ending June 24, 2016
 or any future periods.

- changed (2016-05-03):
[0001193125-16-574999:note_history:7]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended
 March 25, 2016 and March 27, 2015 each consisted of 13
 weeks. The nine months ended March 25, 2016 and March 27,
 2015 each consisted of 39 weeks. Fiscal year 2016 will be comprised
 of 52 weeks and will end on June 24, 2016.
  (was, 2016-02-02, similarity 0.8019):
[0001193125-16-447643:note_history:7]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended
 December 25, 2015 and December 26, 2014 each consisted of
 13 weeks. The six months ended December 25, 2015 and
 December 26, 2014 each consisted of 26 weeks. Fiscal year 2016
 will be comprised of 52 weeks and will end on June 24,
 2016.

- added (2016-05-03):
[0001193125-16-574999:note_history:8]
Derivatives

- added (2016-05-03):
[0001193125-16-574999:note_history:9]
The derivatives assets and liabilities are recognized on the
 consolidated balance sheets as other current assets or accrued
 expenses at fair value.

- added (2016-05-03):
[0001193125-16-574999:note_history:10]
The Company applies hedge accounting to arrangements that qualify
 and are designated for cash flow hedge accounting treatment. Hedge
 accounting is discontinued prospectively if the hedging
 relationship ceases to be effective or the hedging or hedged items
 cease to exist as a result of maturity, sale, termination or
 cancellation.

- added (2016-05-03):
[0001193125-16-574999:note_history:11]
Derivatives designated and qualifying as hedges of the exposure to
 variability in expected future cash flows, or other types of
 forecasted transactions, are considered cash flow hedges which
 include forward currency contracts. In a cash flow hedging
 relationship, the effective portion of the change in the fair value
 of the hedging derivative is initially recorded in accumulated
 other comprehensive income (loss), while any ineffective portion is
 recognized directly in earnings, as a component of other income
 (expense). The portion of gain or loss on the derivative instrument
 remains in accumulated other comprehensive (loss) income until the
 forecasted transaction is recognized in earnings.

- added (2016-05-03):
[0001193125-16-574999:note_history:12]
The Company also enters into derivative contracts that are intended
 to economically hedge certain of the Company’s risks. The
 changes in the fair value of the derivatives are recorded directly
 in earnings as a component of other income (expense), net. In
 accordance with the fair value measurement guidance, the
 Company’s accounting policy is to measure the credit risk of
 our derivative financial instruments that are subject to master
 netting agreements on a net basis by counterparty portfolio. The
 Company executes derivative instruments with financial institutions
 that are credit-worthy, defined as institutions that hold an
 investment grade credit rating.

- added (2016-05-03):
[0001193125-16-574999:note_history:13]
In March 2016, the Financial Accounting Standards Board
 (“FASB”) issued Accounting Standards Update
 (“ASU”) 2016-09, “Compensation - Stock
 Compensation (Topic 718): Improvements to Employee Share-Based
 Payment Accounting”. This ASU simplifies several aspects of
 the accounting for share-based payment award transactions,
 including, the income tax consequences, classification of awards as
 either equity or liabilities and classification on the statement of
 cash flows. The amendments in this update are effective for annual
 periods beginning after December 15, 2016, and interim periods
 within those annual periods, for public companies. Early adoption
 is permitted for any entity in any interim or annual period. The
 Company is currently evaluating the impact of adoption of this
 update on its consolidated financial statements.

- added (2016-05-03):
[0001193125-16-574999:note_history:14]
In March 2016, the FASB issued ASU 2016-08, “Revenue from
 Contracts with Customers (Topic 606): Principal versus Agent
 Considerations (Reporting Revenue Gross versus Net)” to
 clarify the implementation guidance on principal versus agent
 considerations. The effective date and transition requirements for
 this amendments are the same as ASU 2014-09, which defers by one
 year. The Company is currently evaluating the impact of adoption of
 this update on its consolidated financial statements.

- added (2016-05-03):
[0001193125-16-574999:note_history:15]
In March 2016, the FASB issued ASU 2016-05, “Derivatives and
 Hedging (Topic 815)”, to clarify that a change in the
 counterparty to a derivative instrument that has been designated as
 a hedging instrument under Topic 815, does not, in and of itself,
 require designation of the hedging relationship, provided that all
 other hedge accounting criteria continue to be met. This guidance
 is effective for public entities for financial statements issued
 for fiscal years beginning after December 15, 2016 and interim
 periods within those fiscal years. Early adoption is permitted. The
 Company is currently evaluating the impact of adoption of this
 update on its consolidated financial statements.

- added (2016-05-03):
[0001193125-16-574999:note_history:16]
In February 2016, the FASB issued ASU 2016-02, “Lease (Topic
 842)”. The core principle of Topic 842 is that a lessee
 should recognize the lease assets and liabilities that arise from
 leases in the statement of financial position. For public business
 entities, this update is effective for fiscal years beginning after
 December 15, 2018, including interim periods within those
 fiscal years. Early application is permitted. The Company is
 currently evaluating the impact of adoption of this update on its
 consolidated financial statements.

- changed (2016-05-03):
[0001193125-16-574999:note_history:17]
In January 2016, the FASB issued ASU 2016-01, “Financial
 Instruments - Overall (Subtopic 825-10): Recognition and
 Measurement of Financial Assets and Financial Liabilities”.
 This new guidance requires certain equity investments to be
 measured at fair value, use of the exit price notion and separate
 presentation of financial assets and financial liabilities by
 measurement category and form of financial asset on the balance
 sheet or the accompanying notes to the financial statements. The
 ASU on recognition and measurement will take effect for public
 companies for fiscal years beginning after December 15, 2017,
 including interim periods within those fiscal years. The
 Company is currently evaluating the impact of adoption of this
 update on its consolidated financial statements.
  (was, 2016-02-02, similarity 0.8266):
[0001193125-16-447643:note_history:17]
In January 2016, the Financial Accounting Standards Board
 (“FASB”) issued Accounting Standards Update
 (“ASU”) 2016-01, “Financial
 Instruments – Overall (Subtopic 825-10): Recognition and
 Measurement of Financial Assets and Financial Liabilities”.
 This new guidance makes targeted improvements to existing U.S. GAAP
 by requiring certain equity investments to be measured at fair
 value, requiring use of the exit price notion when measuring the
 fair value of financial instruments for disclosure purposes and
 requiring separate presentation of financial assets and financial
 liabilities by measurement category and form of financial asset
 (that is, securities or loans and receivables) on the balance sheet
 or the accompanying notes to the financial statements. The ASU on
 recognition and measurement will take effect for public companies
 for fiscal years beginning after December 15, 2017, including
 interim periods within those fiscal years. The Company is
 currently evaluating the impact of adoption of this update on its
 consolidated financial statements.

- added (2016-05-03):
[0001193125-16-574999:note_history:18]
In August 2015, the FASB issued ASU 2015-15, “Interest
 – Imputation of Interest (Subtopic 835-30): Presentation and
 Subsequent Measurement of Debt Issuance Costs Associated with
 Line-of-Credit Arrangements”. This ASU amended ASU 2015-03
 regarding debt issuance costs related to the line-of-credit
 arrangement. The Company does not anticipate that the adoption of
 this update will have an effect on its consolidated financial
 statements.

- changed (2016-05-03):
[0001193125-16-574999:note_history:19]
In July 2015, the FASB issued ASU 2015-11, “Inventory (Topic
 330): Simplifying the Measurement of Inventory”. The update
 provides the guidance that an entity, that measured inventory by
 using first-in, first-out or average cost, should measure inventory
 at the lower of cost and net realizable value. Subsequent
 measurement is unchanged for inventory measured using last-in,
 first-out or the retail inventory method. The update is effective
 for fiscal years beginning after December 15, 2016, including
 interim periods within these fiscal years. This update should be
 applied prospectively with earlier application permitted as of the
 beginning of an interim or annual reporting date. The Company is
 currently evaluating the impact of adoption of this update on its
 consolidated financial statements.
  (was, 2016-02-02, similarity 0.9031):
[0001193125-16-447643:note_history:19]
In July 2015, the FASB issued ASU 2015-11, “Inventory (Topic
 330): Simplifying the Measurement of Inventory”. The update
 provides the guidance that an entity, that measured inventory by
 using first-in, first-out or average cost, should measure inventory
 at the lower of cost and net realizable value. Net realizable value
 is the estimated selling prices in the ordinary course of business,
 less reasonably predictable costs of completion, disposal, and
 transportation. Subsequent measurement is unchanged for inventory
 measured using last-in, first-out or the retail inventory method.
 The update is effective for fiscal years beginning after
 December 15, 2016, including interim periods within these
 fiscal years. This update should be applied prospectively with
 earlier application permitted as of the beginning of an interim or
 annual reporting date. The Company is currently evaluating the
 impact of adoption of this update on its consolidated financial
 statements.

- changed (2016-05-03):
[0001193125-16-574999:note_history:20]
In April 2015, the FASB issued ASU 2015-03, “Interest -
 Imputation of Interest (Subtopic 835-30): Simplifying the
 Presentation of Debt Issuance Costs”. The update requires
 debt issuance costs related to a recognized debt liability be
 presented in the balance sheet as a direct deduction from the
 carrying amount of the related debt liability instead of being
 presented as an asset. Debt disclosures will include the face
 amount of the debt liability and the effective interest rate. The
 update requires retrospective application and represents a change
 in accounting principle. The update is effective for fiscal years
 beginning after December 15, 2015. Early adoption is permitted
 for financial statements that have not been previously issued. The
 Company is currently evaluating the impact of adoption of this
 update on its consolidated financial statements.
  (was, 2016-02-02, similarity 0.9988):
[0001193125-16-447643:note_history:20]
In April 2015, the FASB issued ASU 2015-03,
 “Interest – Imputation of Interest (Subtopic
 835-30): Simplifying the Presentation of Debt Issuance
 Costs”. The update requires debt issuance costs related to a
 recognized debt liability be presented in the balance sheet as a
 direct deduction from the carrying amount of the related debt
 liability instead of being presented as an asset. Debt disclosures
 will include the face amount of the debt liability and the
 effective interest rate. The update requires retrospective
 application and represents a change in accounting principle. The
 update is effective for fiscal years beginning after
 December 15, 2015. Early adoption is permitted for financial
 statements that have not been previously issued. The Company is
 currently evaluating the impact of adoption of this update on its
 consolidated financial statements.

- changed (2016-05-03):
[0001193125-16-574999:note_history:21]
In January 2015, the FASB issued ASU No. 2015-01,
 “Income Statement – Extraordinary and Unusual Items
 (Subtopic 225-20): Simplifying Income Statement Presentation by
 Eliminating the Concept of Extraordinary Items”. The
 objective of this amendment is to reduce the complexity in
 accounting standards by eliminating the concept of extraordinary
 items from U.S. GAAP. The following criteria must both be met for
 extraordinary classification: (a) the underlying event or
 transaction should possess a high degree of abnormality and be of a
 type clearly unrelated to, or only incidentally related to, the
 ordinary and typical activities of the entity; and (b) the
 underlying event or transaction should not reasonably be expected
 to recur in the foreseeable future. This amendment is effective for
 fiscal years and interim periods beginning after December 15,
 2015. Early adoption is permitted provided that the guidance is
 applied from the beginning of the fiscal year of adoption. The
 Company does not expect that the adoption of this update will have
 an effect on its consolidated financial statements.
  (was, 2016-02-02, similarity 0.9208):
[0001193125-16-447643:note_history:21]
In January 2015, the FASB issued ASU No. 2015-01,
 “Income Statement – Extraordinary and Unusual Items
 (Subtopic 225-20): Simplifying Income Statement Presentation by
 Eliminating the Concept of Extraordinary Items”. The
 objective of this amendment is to reduce the complexity in
 accounting standards by eliminating the concept of extraordinary
 items from U.S. GAAP. Presently, an event or transaction is
 presumed to be an ordinary and usual activity of the reporting
 entity unless evidence clearly supports its classification as an
 extraordinary item. The following criteria must both be met for
 extraordinary classification: (a) the underlying event or
 transaction should possess a high degree of abnormality and be of a
 type clearly unrelated to, or only incidentally related to, the
 ordinary and typical activities of the entity; and (b) the
 underlying event or transaction should not reasonably be expected
 to recur in the foreseeable future. This amendment is effective for
 fiscal years and interim periods beginning after December 15,
 2015. Early adoption is permitted provided that the guidance is
 applied from the beginning of the fiscal year of adoption. The
 Company does not expect that the adoption of this update will have
 an effect on its consolidated financial statements.

- added (2016-05-03):
[0001193125-16-574999:note_history:22]
In June 2014, the FASB issued ASU No. 2014-12,
 “Compensation – Stock Compensation (Topic 718):
 Accounting for Share-Based Payments When the Terms of an Award
 Provide That a Performance Target Could Be Achieved After the
 Requisite Service Period”. This ASU requires that a
 performance target that affects vesting, and that could be achieved
 after the requisite service period, be treated as a performance
 condition. As such, the performance target should not be reflected
 in estimating the grant date fair value of the award. Compensation
 cost should be recognized in the period in when performance target
 will probably be achieved and should represent attributable to the
 period(s) for which the requisite service has already been
 rendered. This update is required to be adopted by all public
 companies for annual periods and interim reporting periods
 beginning after December 15, 2015, with early adoption
 permitted. The Company does not expect that the adoption of this
 update will have an effect on its consolidated financial
 statements.

- added (2016-05-03):
[0001193125-16-574999:note_history:23]
In May 2014, the FASB issued ASU 2014-09, “Revenue from
 Contracts with Customers (Topic 606), issued as a new Topic,
 Accounting Standards Codification”. The core principle of
 this amendment is that an entity should recognize revenue to depict
 the transfer of promised goods or services to customers in an
 amount that reflects the consideration to which the entity expects
 to be entitled in exchange for those goods or services. This ASU is
 effective, as amended by ASU 2015-14, for annual reporting periods
 beginning after December 15, 2017, including interim periods
 within that reporting period. Earlier application of this guidance
 is permitted by not before the original date of December 15,
 2016, which can be adopted either retrospectively to each prior
 reporting period presented or as a cumulative-effect adjustment as
 of the date of adoption. In April 2016, the FASB issued ASU
 2016-10, with the same effective date as ASU 2015-14, to address
 the potential diversity in practice at initial application and
 cost; and the complexity of applying Topic 606, both at transition
 and on an ongoing basis related to identification of performance
 obligations and licensing arrangements. The Company is currently
 evaluating the impact of adoption of this update on its
 consolidated financial statements.

- removed (2016-05-03):
[0001193125-16-447643:note_history:24]
In August 2015, the FASB issued ASU 2015-15, “Interest
 – Imputation of Interest (Subtopic 835-30): Presentation and
 Subsequent Measurement of Debt Issuance Costs Associated with
 Line-of-Credit Arrangements”. This ASU amended the
 presentation or subsequent measurement of debt issuance costs
 related to the line-of-credit arrangement. The Company is currently
 evaluating the impact of adoption of this update on its
 consolidated financial statements.

- removed (2016-05-03):
[0001193125-16-447643:note_history:25]
In August 2015, the FASB issued ASU 2015-14, “Revenue from
 Contracts with Customers (Topic 666): Deferral of the Effective
 Date”. This amendment deferred the effective date of ASU
 2014-09 for all entities by one year. The Company is currently
 evaluating the impact of adoption of this update on its
 consolidated financial statements.

- removed (2016-05-03):
[0001193125-16-447643:note_history:26]
In June 2014, the FASB issued ASU No. 2014-12,
 “Compensation – Stock Compensation (Topic 718):
 Accounting for Share-Based Payments When the Terms of an Award
 Provide That a Performance Target Could Be Achieved After the
 Requisite Service Period”. This ASU requires that a
 performance target that affects vesting, and that could be achieved
 after the requisite service period, be treated as a performance
 condition. As such, the performance target should not be reflected
 in estimating the grant date fair value of the award. This update
 further clarifies that compensation cost should be recognized in
 the period in which it becomes probable that the performance target
 will be achieved and should represent the compensation cost
 attributable to the period(s) for which the requisite service has
 already been rendered. This update is required to be adopted by all
 public companies for annual periods and interim reporting periods
 beginning after December 15, 2015. Early adoption of this ASU
 is permitted. The Company does not expect that the adoption of this
 update will have an effect on its consolidated financial
 statements.

- removed (2016-05-03):
[0001193125-16-447643:note_history:27]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue
 from Contracts with Customers (Topic 606), issued as a new Topic,
 Accounting Standards Codification”. The core principle of
 this amendment is that an entity should recognize revenue to depict
 the transfer of promised goods or services to customers in an
 amount that reflects the consideration to which the entity expects
 to be entitled in exchange for those goods or services. This ASU is
 effective for annual reporting periods beginning after
 December 15, 2016, including interim periods within that
 reporting period, with earlier adoption not being permitted. This
 ASU can be adopted either retrospectively to each prior reporting
 period presented or as a cumulative-effect adjustment as of the
 date of adoption. The Company is currently evaluating the impact of
 adoption of this update on its consolidated financial
 statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-03):
[0001193125-16-574999:note_history:28]
The Company’s total borrowings, including revolving and
 long-term borrowings, consisted of the following:
  (was, 2016-02-02, similarity 0.9952):
[0001193125-16-447643:note_history:28]
The Company’s total borrowing, including revolving and
 long-term borrowings, consisted of the following:

- added (2016-05-03):
[0001193125-16-574999:note_history:29]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  |  | As of March 25, 2016 |  |  | As of June 26, 2015 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  |  | April 2016 | (2) |  | $ | 44,000 |  |  | $ | 30,000 |  |
| Current portion of long-term borrowing |  |  |  | 6,000 |  |  |  | 6,000 |  |
|  |  |  | $ | 50,000 |  |  | $ | 36,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  |  | March 2017 |  |  | $ | 6,000 |  |  | $ | 10,500 |  |
| Less: Current portion |  |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  | $ | — |  |  | $ | 4,500 |  |

- changed (2016-05-03):
[0001193125-16-574999:note_history:30]
|  | (1) | LIBOR is London Interbank Offered Rate. |
  (was, 2016-02-02, similarity 0.98):
[0001193125-16-447643:note_history:30]
| (1) | LIBOR is London Interbank Offered Rate. |

- changed (2016-05-03):
[0001193125-16-574999:note_history:31]
|  | (2) | In April 2016, the maturity date of these revolving borrowings were extended to mature in May 2016. |
  (was, 2016-02-02, similarity 0.9194):
[0001193125-16-447643:note_history:31]
| (2) | In January 2016, the maturity date of these revolving borrowings were extended to mature in February 2016. |

- changed (2016-05-03):
[0001193125-16-574999:note_history:32]
Under the long-term borrowing contract of a subsidiary, the loan is
 secured by certain property, plant and equipment. The carrying
 amount of assets secured and pledged as collateral to such loan as
 of March 25, 2016 and June 26, 2015 was $48.2 million and
 $50.0 million, respectively. This subsidiary is also required to
 comply with maximum ratios of debt to equity and minimum levels of
 debt service coverage ratios, and Fabrinet must maintain an
 effective shareholding ratio. The carrying amounts of bank
 borrowings approximate their fair value.
  (was, 2016-02-02, similarity 0.9878):
[0001193125-16-447643:note_history:32]
Under the long-term borrowing contract of a subsidiary, the loan is
 secured by certain property, plant and equipment. The carrying
 amount of assets secured and pledged as collateral to such loan as
 of December 25, 2015 and June 26, 2015 was $48.8 million
 and $50.0 million, respectively. This subsidiary is also required
 to comply with maximum ratios of debt to equity and minimum levels
 of debt service coverage ratios, and Fabrinet must maintain an
 effective shareholding ratio. The carrying amounts of bank
 borrowings approximate their fair value.

- changed (2016-05-03):
[0001193125-16-574999:note_history:33]
As of March 25, 2016 and June 26, 2015, the Company was
 in compliance with its long-term bank borrowing agreement. In
 addition to financial ratios, certain of the Company’s credit
 facilities include customary events of default.
  (was, 2016-02-02, similarity 0.9701):
[0001193125-16-447643:note_history:33]
As of December 25, 2015 and June 26, 2015, the Company
 was in compliance with its long-term bank borrowing agreement. In
 addition to financial ratios, certain of the Company’s credit
 facilities include customary events of default.

- changed (2016-05-03):
[0001193125-16-574999:note_history:34]
The movements of long-term loans were as follows for the nine
 months ended March 25, 2016 and March 27, 2015:
  (was, 2016-02-02, similarity 0.8867):
[0001193125-16-447643:note_history:34]
The movements of long-term loans were as follows for the six months
 ended December 25, 2015 and December 26, 2014:

- changed (2016-05-03):
[0001193125-16-574999:note_history:35]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 25, 2016 |  |  | March 27, 2015 |  |
| Opening book amount |  | $ | 10,500 |  |  | $ | 16,500 |  |
| Repayments during the period |  |  | (4,500 | ) |  |  | (4,500 | ) |
| Closing book amount |  | $ | 6,000 |  |  | $ | 12,000 |  |
  (was, 2016-02-02, similarity 0.8926):
[0001193125-16-447643:note_history:35]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 25, 2015 |  |  | December 26, 2014 |  |
| Opening book amount |  | $ | 10,500 |  |  | $ | 16,500 |  |
| Repayment during the period |  |  | (3,000 | ) |  |  | (3,000 | ) |
| Closing book amount |  | $ | 7,500 |  |  | $ | 13,500 |  |

- changed (2016-05-03):
[0001193125-16-574999:note_history:36]
As of March 25, 2016, future maturities of long-term debt
 during each fiscal year were as follows:
  (was, 2016-02-02, similarity 0.9519):
[0001193125-16-447643:note_history:36]
As of December 25, 2015, future maturities of long-term debt
 during each fiscal year were as follows:

- changed (2016-05-03):
[0001193125-16-574999:note_history:37]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. As of
 March 25, 2016, the outstanding revolving borrowing under the
 Facility Agreement was $44.0 million, resulting in available credit
 facilities of $156.0 million. Borrowings under the revolving credit
 facility are classified as current liabilities in the unaudited
 condensed consolidated balance sheets as the Company has the
 periodic option to renew or pay, all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. During April 2016, the Company
 sent notices to the bank to renew the maturity date of its
 revolving borrowings. The bank approved the notices and extended
 the maturity to May 2016.
  (was, 2016-02-02, similarity 0.979):
[0001193125-16-447643:note_history:37]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. As of
 December 25, 2015, the outstanding revolving borrowing under
 the Facility Agreement was $48.0 million, resulting in available
 credit facilities of $152.0 million. Borrowings under the revolving
 credit facility are classified as current liabilities in the
 unaudited condensed consolidated balance sheets as the Company has
 the periodic option to renew, or pay all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. During January 2016, the
 Company sent notices to the bank to renew the maturity date of its
 revolving borrowings. The bank approved the notices and extended
 the maturity to February 2016.

- changed (2016-05-03):
[0001193125-16-574999:note_history:38]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or the
 equivalent under the local law, can be effected.
  (was, 2016-02-02, similarity 0.6124):
[0001193125-16-447643:note_history:38]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or the
 equivalent under the local law, can be effected. The Facility
 Agreement contains customary affirmative and negative covenants.
 Negative covenants include, among other things, limitations on
 liens, indebtedness, investments, mergers, sales of assets, changes
 in the nature of the business, dividends and distributions,
 affiliate transactions and capital expenditures. The Facility
 Agreement contains financial covenants requiring Fabrinet to
 maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage
 ratio of not more than 2.50:1.00; and (iv) a minimum quick
 ratio of not less than 1.10:1.00. Each of these financial covenants
 is calculated on a consolidated basis for the consecutive four
 fiscal quarter period then ended. As of December 25, 2015, the
 Company was in compliance with all covenants under the Facility
 Agreement.

- added (2016-05-03):
[0001193125-16-574999:note_history:39]
The Facility Agreement contains customary affirmative and negative
 covenants. Negative covenants include, among other things,
 limitations on liens, indebtedness, investments, mergers, sales of
 assets, changes in the nature of the business, dividends and
 distributions, affiliate transactions and capital expenditures. The
 Facility Agreement contains financial covenants requiring Fabrinet
 to maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage
 ratio of not more than 2.50:1.00; and (iv) a minimum quick
 ratio of not less than 1.10:1.00. Each of these financial covenants
 is calculated on a consolidated basis for the consecutive four
 fiscal quarter period then ended. As of March 25, 2016, the
 Company was in compliance with all covenants under the Facility
 Agreement.

- changed (2016-05-03):
[0001193125-16-574999:note_history:40]
Undrawn available credit facilities classified by available period
 of future borrowing as of March 25, 2016 and June 26,
 2015 were as follows:
  (was, 2016-02-02, similarity 0.9663):
[0001193125-16-447643:note_history:40]
Undrawn available credit facilities classified by available period
 of future borrowing as of December 25, 2015 and June 26,
 2015 were as follows:

- changed (2016-05-03):
[0001193125-16-574999:note_history:41]
| (amount in thousands) |  | March 25, 2016 |  |  | June 26, 2015 |  |
| Short-term |  | $ | 1,415 |  |  | $ | 1,480 |  |
| Long-term |  | $ | 156,000 |  |  | $ | 170,000 |  |
  (was, 2016-02-02, similarity 0.9665):
[0001193125-16-447643:note_history:41]
| (amount in thousands) |  | December 25, 2015 |  |  | June 26, 2015 |  |
| Short-term |  | $ | 1,386 |  |  | $ | 1,480 |  |
| Long-term |  | $ | 152,000 |  |  | $ | 170,000 |  |

- removed (2016-05-03):
[0001193125-16-447643:note_history:42]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  | As of December 25, 2015 |  |  | As of June 26, 2015 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  | January 2016 (2) |  | $ | 48,000 |  |  | $ | 30,000 |  |
| Current portion of long-term borrowing |  |  | 6,000 |  |  |  | 6,000 |  |
|  |  | $ | 54,000 |  |  | $ | 36,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | March 2017 |  | $ | 7,500 |  |  | $ | 10,500 |  |
| Less: Current portion |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  | $ | 1,500 |  |  | $ | 4,500 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-03):
[0001193125-16-574999:note_history:43]
The movements of long-term loans were as follows for the nine
 months ended March 25, 2016 and March 27, 2015:
  (was, 2016-02-02, similarity 0.8867):
[0001193125-16-447643:note_history:43]
The movements of long-term loans were as follows for the six months
 ended December 25, 2015 and December 26, 2014:

- changed (2016-05-03):
[0001193125-16-574999:note_history:44]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 25, 2016 |  |  | March 27, 2015 |  |
| Opening book amount |  | $ | 10,500 |  |  | $ | 16,500 |  |
| Repayments during the period |  |  | (4,500 | ) |  |  | (4,500 | ) |
| Closing book amount |  | $ | 6,000 |  |  | $ | 12,000 |  |
  (was, 2016-02-02, similarity 0.8926):
[0001193125-16-447643:note_history:44]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 25, 2015 |  |  | December 26, 2014 |  |
| Opening book amount |  | $ | 10,500 |  |  | $ | 16,500 |  |
| Repayment during the period |  |  | (3,000 | ) |  |  | (3,000 | ) |
| Closing book amount |  | $ | 7,500 |  |  | $ | 13,500 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-03):
[0001193125-16-574999:note_history:45]
The Company’s total borrowings, including revolving and
 long-term borrowings, consisted of the following:
  (was, 2016-02-02, similarity 0.9952):
[0001193125-16-447643:note_history:45]
The Company’s total borrowing, including revolving and
 long-term borrowings, consisted of the following:

- added (2016-05-03):
[0001193125-16-574999:note_history:46]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  |  | As of March 25, 2016 |  |  | As of June 26, 2015 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  |  | April 2016 | (2) |  | $ | 44,000 |  |  | $ | 30,000 |  |
| Current portion of long-term borrowing |  |  |  | 6,000 |  |  |  | 6,000 |  |
|  |  |  | $ | 50,000 |  |  | $ | 36,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  |  | March 2017 |  |  | $ | 6,000 |  |  | $ | 10,500 |  |
| Less: Current portion |  |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  | $ | — |  |  | $ | 4,500 |  |

- changed (2016-05-03):
[0001193125-16-574999:note_history:47]
|  | (1) | LIBOR is London Interbank Offered Rate. |
  (was, 2016-02-02, similarity 0.98):
[0001193125-16-447643:note_history:47]
| (1) | LIBOR is London Interbank Offered Rate. |

- changed (2016-05-03):
[0001193125-16-574999:note_history:48]
|  | (2) | In April 2016, the maturity date of these revolving borrowings were extended to mature in May 2016. |
  (was, 2016-02-02, similarity 0.9194):
[0001193125-16-447643:note_history:48]
| (2) | In January 2016, the maturity date of these revolving borrowings were extended to mature in February 2016. |

- removed (2016-05-03):
[0001193125-16-447643:note_history:49]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  | As of December 25, 2015 |  |  | As of June 26, 2015 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  | January 2016 (2) |  | $ | 48,000 |  |  | $ | 30,000 |  |
| Current portion of long-term borrowing |  |  | 6,000 |  |  |  | 6,000 |  |
|  |  | $ | 54,000 |  |  | $ | 36,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | March 2017 |  | $ | 7,500 |  |  | $ | 10,500 |  |
| Less: Current portion |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  | $ | 1,500 |  |  | $ | 4,500 |  |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-03):
[0001193125-16-574999:note_history:50]
Undrawn available credit facilities classified by available period
 of future borrowing as of March 25, 2016 and June 26,
 2015 were as follows:
  (was, 2016-02-02, similarity 0.9663):
[0001193125-16-447643:note_history:50]
Undrawn available credit facilities classified by available period
 of future borrowing as of December 25, 2015 and June 26,
 2015 were as follows:

- changed (2016-05-03):
[0001193125-16-574999:note_history:51]
| (amount in thousands) |  | March 25, 2016 |  |  | June 26, 2015 |  |
| Short-term |  | $ | 1,415 |  |  | $ | 1,480 |  |
| Long-term |  | $ | 156,000 |  |  | $ | 170,000 |  |
  (was, 2016-02-02, similarity 0.9665):
[0001193125-16-447643:note_history:51]
| (amount in thousands) |  | December 25, 2015 |  |  | June 26, 2015 |  |
| Short-term |  | $ | 1,386 |  |  | $ | 1,480 |  |
| Long-term |  | $ | 152,000 |  |  | $ | 170,000 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-05-03):
[0001193125-16-574999:note_history:52]
As of March 25, 2016, future maturities of long-term debt
 during each fiscal year were as follows:
  (was, 2016-02-02, similarity 0.9519):
[0001193125-16-447643:note_history:52]
As of December 25, 2015, future maturities of long-term debt
 during each fiscal year were as follows:


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2016-05-03):
[0001193125-16-447643:note_history:53]
| 18. | Subsequent event |

- removed (2016-05-03):
[0001193125-16-447643:note_history:54]
During January 2016, the Company incurred severance expenses of
 approximately $0.7 million in connection with a separation
 agreement which the Company entered into with a former named
 executive officer who resigned from the Company effective
 December 31, 2015.
