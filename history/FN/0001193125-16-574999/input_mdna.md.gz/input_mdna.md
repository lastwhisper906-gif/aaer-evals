# FN MD&A — 0001193125-16-574999


## mdna

[0001193125-16-574999:mdna:1]
[same as prior period, unchanged from 0001193125-16-447643:mdna:1]

[0001193125-16-574999:mdna:2]
[same as prior period, unchanged from 0001193125-16-447643:mdna:2]

[0001193125-16-574999:mdna:3]
[same as prior period, unchanged from 0001193125-16-447643:mdna:3]

[0001193125-16-574999:mdna:4]
|  | • |  | our expectation that the portion of our future revenues attributable to customers in regions outside of North America will continue to decrease compared with the portion of those revenues for the nine months ended March 25, 2016; |

[0001193125-16-574999:mdna:5]
[same as prior period, unchanged from 0001193125-16-447643:mdna:6]

[0001193125-16-574999:mdna:6]
|  | • |  | our expectation that our fiscal year 2016 selling, general and administrative (“SG&A”) expenses will increase on an absolute dollar basis and as a percentage of revenue compared to fiscal year 2015; |

[0001193125-16-574999:mdna:7]
|  | • |  | our expectation that our employee costs will increase in Thailand and the People’s Republic of China (“PRC”); |

[0001193125-16-574999:mdna:8]
[same as prior period, unchanged from 0001193125-16-447643:mdna:9]

[0001193125-16-574999:mdna:9]
[same as prior period, unchanged from 0001193125-16-447643:mdna:10]

[0001193125-16-574999:mdna:10]
[same as prior period, unchanged from 0001193125-16-447643:mdna:11]

[0001193125-16-574999:mdna:11]
[same as prior period, unchanged from 0001193125-16-447643:mdna:12]

[0001193125-16-574999:mdna:12]
[same as prior period, unchanged from 0001193125-16-447643:mdna:13]

[0001193125-16-574999:mdna:13]
[same as prior period, unchanged from 0001193125-16-447643:mdna:14]

[0001193125-16-574999:mdna:14]
[same as prior period, unchanged from 0001193125-16-447643:mdna:15]

[0001193125-16-574999:mdna:15]
[same as prior period, unchanged from 0001193125-16-447643:mdna:16]

[0001193125-16-574999:mdna:16]
[same as prior period, unchanged from 0001193125-16-447643:mdna:17]

[0001193125-16-574999:mdna:17]
[same as prior period, unchanged from 0001193125-16-447643:mdna:18]

[0001193125-16-574999:mdna:18]
[same as prior period, unchanged from 0001193125-16-447643:mdna:19]

[0001193125-16-574999:mdna:19]
We provide advanced optical
packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers (“OEMs”) of complex products such as optical communication components, modules and sub-systems, industrial
lasers, medical devices and sensors. We offer a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, complex
printed circuit board assembly, advanced packaging, integration, final assembly and test. Although, we focus primarily on low-volume production of a wide variety of high complexity products, which we refer to as “low-volume, high-mix”, we
also have the capability to accommodate high-volume production. Based on our experience with, and positive feedback we have received from our customers, we believe we are a global leader in providing these services to the optical communications,
industrial lasers, automotive, medical and sensors markets.

[0001193125-16-574999:mdna:20]
Our customer base includes companies in complex industries that require
advanced precision manufacturing capabilities such as optical communications, industrial lasers, automotive and sensors. The products that we manufacture for our OEM customers include selective switching products; tunable transponders and
transceivers; active optical cables; solid state, diode-pumped, gas and fiber lasers; and sensors. In many cases, we are the sole outsourced manufacturing partner used by our customers for the products that we produce for them.

[0001193125-16-574999:mdna:21]
[same as prior period, unchanged from 0001193125-16-447643:mdna:22]

[0001193125-16-574999:mdna:22]
[same as prior period, unchanged from 0001193125-16-447643:mdna:23]

[0001193125-16-574999:mdna:23]
During the week of August 10, 2015, our subsidiary in China temporarily suspended production in its manufacturing facility due to
flooding caused by Typhoon Soudelor. The subsidiary resumed operations on August 15, 2015. During the three months ended March 25, 2016, we received a final payment of $0.8 million from an insurer against our claim for flood damage.

[0001193125-16-574999:mdna:24]
During the three months ended March 25, 2016, we recognized other income related to flooding of $0.9 million, which primarily consisted
of a payment of $0.8 million from an insurer against our claim for flood damage.

[0001193125-16-574999:mdna:25]
During the nine months ended March 25, 2016, we
recognized other income related to flooding of $0.04 million, which mainly consisted of $0.8 million from an insurer against our claim for flood damage, offset by expenses in relation to flood of $0.8 million, which mainly consisted of $0.6 million
of repaired cost of equipment and $0.2 million of inventory losses.

[0001193125-16-574999:mdna:26]
[same as prior period, unchanged from 0001193125-16-447643:mdna:28]

[0001193125-16-574999:mdna:27]
Our total revenues increased by $61.4 million, or 32.4%, to $250.9 million for the three months ended March 25, 2016, compared with $189.5
million for the three months ended March 27, 2015. Our total revenues increased by $133.2 million, or 23.5%, to $700.4 million for the nine months ended March 25, 2016, compared with $567.1 million for the nine months ended March 27,
2015. The increases were primarily due to (i) an increase in our customers’ demand for both optical and non-optical communications manufacturing services during the three and nine months ended March 25, 2016 and (ii) our
inability to recognize $4.6 million of consignment revenue during the three and nine months ended March 27, 2015, respectively, because of certain consignment revenue recognition issues previously disclosed that result in lower revenue in the
prior period. We refer to finished goods held in our warehouse on behalf of our customers as consignment goods or consignment inventory, and when the finished goods are sold, we refer to the related revenue as consignment revenue.

[0001193125-16-574999:mdna:28]
We believe our ability to expand our relationships with existing customers and attract new
customers is due to a number of factors, including our broad range of complex engineering and manufacturing service offerings, flexible low-cost manufacturing platform, process optimization capabilities, advanced supply chain management, excellent
customer service, and experienced management team. While we expect the prices we charge for our manufactured products to decrease over time (partly as a result of competitive market forces), we still believe we will be able to maintain favorable
pricing for our services because of our ability to reduce cycle time, adjust our product mix by focusing on more complicated products, improve product quality and yields, and reduce material costs for the products we manufacture. We believe these
capabilities have enabled us to help our OEM customers reduce their manufacturing costs while maintaining or improving the design, quality, reliability, and delivery times for their products.

[0001193125-16-574999:mdna:29]
[same as prior period, unchanged from 0001193125-16-447643:mdna:31]

[0001193125-16-574999:mdna:30]
[same as prior period, unchanged from 0001193125-16-447643:mdna:32]

[0001193125-16-574999:mdna:31]
The percentage of our revenues generated from a bill-to location outside of North America decreased from 50.7% in the three months ended
March 27, 2015 to 44.7% in the three months ended March 25, 2016 and from 51.0% in the nine months ended March 27, 2015 to 47.3% in the nine months ended March 25, 2016, primarily because of a decrease in sales to our customers
in Asia-Pacific and Europe. We expect that the portion of our future revenues attributable to customers in regions outside North America will continue to decrease as compared with the portion of revenues attributable to such customers during the
nine months ended March 25, 2016.

[0001193125-16-574999:mdna:32]
[same as prior period, unchanged from 0001193125-16-447643:mdna:34]

[0001193125-16-574999:mdna:33]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 25,2016 |  |  | March 27,2015 |  |  | March 25,2016 |  |  | March 27,2015 |  |
| North America |  |  | 55.3 | % |  |  | 49.3 | % |  |  | 52.7 | % |  |  | 49.0 | % |
| Asia-Pacific |  |  | 35.2 |  |  |  | 37.6 |  |  |  | 36.7 |  |  |  | 38.8 |  |
| Europe |  |  | 9.5 |  |  |  | 13.1 |  |  |  | 10.6 |  |  |  | 12.2 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-16-574999:mdna:34]
[same as prior period, unchanged from 0001193125-16-447643:mdna:36]

[0001193125-16-574999:mdna:35]
[same as prior period, unchanged from 0001193125-16-447643:mdna:37]

[0001193125-16-574999:mdna:36]
[same as prior period, unchanged from 0001193125-16-447643:mdna:38]

[0001193125-16-574999:mdna:37]
The key components of
our cost of revenues are material costs, employee costs, and infrastructure-related costs. Material costs generally represent the majority of our cost of revenues. Several of the materials we require to manufacture products for our customers are
customized for their products and often sourced from a single supplier or in some cases, our own subsidiaries. Shortages from sole-source suppliers due to yield loss, quality concerns and capacity constraints, among other factors, may increase our
expenses and negatively impact our gross profit margin or total revenues in a given quarter. Material costs include scrap material. Historically, scrap rate diminishes during a product’s life cycle due to process, fixturing and test improvement
and optimization.

[0001193125-16-574999:mdna:38]
A second significant element of our cost of revenues is employee costs, including indirect
employee costs related to design, configuration and optimization of manufacturing processes for our customers, quality testing, materials testing and other engineering services; and direct costs related to our manufacturing employees. Direct
employee costs include employee salaries, insurance and benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support
our growth and, to a lesser extent, costs to recruit, train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand and the PRC, the fluctuation of the Thai baht and Chinese Renminbi (“RMB”)
against our functional currency, the U.S. dollar, and our ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may impact our ability to sustain our
competitive advantage and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention and asset utilization.

[0001193125-16-574999:mdna:39]
Our infrastructure costs are comprised of depreciation, utilities, facilities management and overhead costs. Most of our facility leases are
long-term agreements. Our depreciation costs include buildings and fixed assets, primarily at our Pinehurst campus in Thailand, and capital equipment located at each of our manufacturing locations.

[0001193125-16-574999:mdna:40]
During the three and nine months ended March 25, 2016, discretionary merit-based bonus awards were made to our non-executive employees.
Charges included in cost of revenues for bonus distributions to non-executive employees were $0.7 million and $0.6 million for the three months ended March 25, 2016 and March 27, 2015, respectively, and $2.2 million and $1.8 million for
the nine months ended March 25, 2016 and March 27, 2015, respectively.

[0001193125-16-574999:mdna:41]
Share-based compensation expense included in cost of
revenues was $0.5 million and $0.4 million for the three months ended March 25, 2016 and March 27, 2015, respectively, and $1.6 million and $1.1 million for the nine months ended March 25, 2016 and March 27, 2015, respectively.

[0001193125-16-574999:mdna:42]
We expect to incur incremental costs of revenue as a result of our planned expansion into new geographic markets, though we are not able
to determine the amount of these incremental expenses.

[0001193125-16-574999:mdna:43]
Selling, General and Administrative Expenses

[0001193125-16-574999:mdna:44]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative and other support
personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other general expenses not related to cost of
revenues. In fiscal year 2016, we expect our SG&A expenses will increase on an absolute dollar basis and as a percentage of revenue compared with fiscal year 2015 due to the startup expenses of our new manufacturing facility in the United
States.

[0001193125-16-574999:mdna:45]
The compensation committee of our board of directors approved a fiscal year 2016 executive incentive plan with quantitative
objectives, based on achieving certain revenue and non-GAAP earnings per share targets for our fiscal year ending June 24, 2016, as well as qualitative objectives, based on achieving individual performance goals. Bonuses under our fiscal year
2016 executive incentive plan are payable after the end of fiscal year 2016. In fiscal year 2015, the compensation committee approved a fiscal year 2015 executive incentive plan with quantitative objectives, based on achieving certain revenue and
non-GAAP earnings per share targets for our fiscal year ended June 26, 2015, as well as qualitative objectives, based on achieving individual performance goals. In the three months ended September 25, 2015, the compensation committee
awarded bonuses to our executive employees for Company and individual achievements of performance under our fiscal 2015 executive incentive plan. Discretionary merit-based bonus awards were also available to our non-executive employees and were
payable as of March 25, 2016.

[0001193125-16-574999:mdna:46]
Charges included in SG&A expenses for bonus distributions to non-executive and executive employees
were $1.4 million and $1.4 million for the three months ended March 25, 2016 and March 27, 2015, respectively, and $3.6 million and $2.6 million for the nine months ended March 25, 2016 and March 27, 2015, respectively.

[0001193125-16-574999:mdna:47]
Share-based compensation expense included in SG&A expenses was $1.5 million and $1.6 million for the three months ended March 25,
2016 and March 27, 2015, respectively, and $6.2 million and $4.7 million for the nine months ended March 25, 2016 and March 27, 2015, respectively.

[0001193125-16-574999:mdna:48]
26

[0001193125-16-574999:mdna:49]
[same as prior period, unchanged from 0001193125-16-447643:mdna:50]

[0001193125-16-574999:mdna:50]
[same as prior period, unchanged from 0001193125-16-447643:mdna:51]

[0001193125-16-574999:mdna:51]
As a result of
our international operations, we are exposed to foreign exchange risk arising from various currency exposures primarily with respect to the Thai baht. Although a majority of our total revenues is denominated in U.S. dollars, a substantial portion of
our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rate between the Thai baht and the U.S. dollar has fluctuated substantially in recent years and may continue to fluctuate substantially in the future.
We report our financial results in U.S. dollars and our results of operations have been and may continue to be negatively impacted owing to appreciation of the Thai baht against the U.S. dollar. Smaller portions of our expenses are incurred in a
variety of other currencies, including RMB, Canadian dollars, Euros, and Japanese yen, the appreciation of which may also negatively impact our financial results.

[0001193125-16-574999:mdna:52]
In addition, we are exposed to foreign exchange risk in connection with the long-term loan and cross currency swap arrangements we entered
into with TMB Bank Public Company Limited (the “Bank”) in May 2011 for the construction of Pinehurst Building 6. The terms of the contract with the Bank provide the following facilities: (1) a term loan facility for up to Thai baht
960 million (equal to $30.0 million) with a fixed interest rate of 5.28% per annum, (2) a hedging facility for currency interest rate swaps with a notional amount of $30.0 million, and (3) a settlement limit of Thai baht
65 million, subject to certain terms and conditions as set forth therein. Borrowings and interest under the term loan have been scheduled to be repaid on a quarterly basis between September 2011 and March 2017. As of March 25, 2016, we had
outstanding borrowings under the term loan facility of $6.0 million. Under the terms of the cross currency swap arrangements, amounts drawn in Thai baht were converted to U.S. dollars for repayment by us on a quarterly basis at the floating rate of
London Interbank Offered Rate (LIBOR) plus 2.8% per annum.

[0001193125-16-574999:mdna:53]
In order to manage the risks arising from fluctuations in foreign
currency exchange rates, we use derivative instruments. We may enter into exchange currency forward or put option contracts to manage foreign currency exposures associated with certain assets and liabilities and other forecasted foreign currency
transactions and may designate these instruments as hedging instruments. The forward and put option contracts generally have maturities of one to eighteen months. All foreign currency exchange contracts are recognized in the unaudited condensed
consolidated balance sheet at fair value. Gain or loss on our forward and put option contracts generally offset the assets, liabilities, and transactions economically hedged.

[0001193125-16-574999:mdna:54]
We had foreign currency denominated assets and liabilities in Thai baht and RMB as follows:

[0001193125-16-574999:mdna:55]
|  |  | As of March 25, 2016 |  |  | As of June 26, 2015 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 786,996 |  |  | $ | 22,276 |  |  |  | 93.7 |  |  |  | 377,785 |  |  | $ | 11,596 |  |  |  | 51.3 |  |
| RMB |  |  | 9,814 |  |  |  | 1,505 |  |  |  | 6.3 |  |  |  | 67,455 |  |  |  | 11,029 |  |  |  | 48.7 |  |
| Total |  |  |  |  |  | $ | 23,781 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 22,625 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,184,745 |  |  | $ | 33,534 |  |  |  | 89.7 |  |  |  | 860,425 |  |  | $ | 26,410 |  |  |  | 88.8 |  |
| RMB |  |  | 25,167 |  |  |  | 3,859 |  |  |  | 10.3 |  |  |  | 20,461 |  |  |  | 3,347 |  |  |  | 11.2 |  |
| Total |  |  |  |  |  | $ | 37,393 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 29,757 |  |  |  | 100.0 |  |

[0001193125-16-574999:mdna:56]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other
current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and
offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of March 25, 2016 and June 26, 2015, there were $132.0 million in forward contracts and $44.0 million in put option
contracts, respectively, outstanding against forecasted Thai baht payables.

[0001193125-16-574999:mdna:57]
The RMB assets represent cash and cash equivalents, accounts
receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of March 25, 2016 and June 26, 2015, we did not have any forward or put option contracts
denominated in RMB.

[0001193125-16-574999:mdna:58]
For the nine months ended March 25, 2016 and March 27, 2015, we recorded loss of $2.3 million and gain of
$0.2 million, respectively, related to derivatives that are not designated as hedging instruments in our condensed consolidated statements of operations and comprehensive income.

[0001193125-16-574999:mdna:59]
[same as prior period, unchanged from 0001193125-16-447643:mdna:61]

[0001193125-16-574999:mdna:60]
[same as prior period, unchanged from 0001193125-16-447643:mdna:62]

[0001193125-16-574999:mdna:61]
[same as prior period, unchanged from 0001193125-16-447643:mdna:63]

[0001193125-16-574999:mdna:62]
[same as prior period, unchanged from 0001193125-16-447643:mdna:64]

[0001193125-16-574999:mdna:63]
|  | • |  | Notice on Perfecting Practices Concerning Foreign Exchange Settlement Regarding the Capital Contribution by Foreign-invested Enterprises, as promulgated by the State Administration of Foreign Exchange, or State Administration of Foreign Exchange (“SAFE”), on August 29, 2008, or Circular 142. |

[0001193125-16-574999:mdna:64]
Under the Exchange Rules,
RMB is freely convertible into foreign currencies for current account items, including the distribution of dividends, interest payments, trade and service-related foreign exchange transactions. However, conversion of RMB for capital account items,
such as direct investments, loans, security investments and repatriation of investments, is still subject to the approval of SAFE.

[0001193125-16-574999:mdna:65]
Under
the Administration Rules, foreign-invested enterprises may only buy, sell, or remit foreign currencies at banks authorized to conduct foreign exchange business after providing valid commercial documents and relevant supporting documents and, in the
case of capital account item transactions, obtaining approval from SAFE. Capital investments by foreign-invested enterprises outside of the PRC are also subject to limitations, which include approvals by the Ministry of Commerce, SAFE and the State
Development and Reform Commission.

[0001193125-16-574999:mdna:66]
[same as prior period, unchanged from 0001193125-16-447643:mdna:68]

[0001193125-16-574999:mdna:67]
[same as prior period, unchanged from 0001193125-16-447643:mdna:69]

[0001193125-16-574999:mdna:68]
[same as prior period, unchanged from 0001193125-16-447643:mdna:70]

[0001193125-16-574999:mdna:69]
Furthermore, our transfer of funds to our subsidiaries in Thailand and the PRC are each subject to approval by governmental authorities in
case of an increase in registered capital, or subject to registration with governmental authorities in case of a shareholder loan. These limitations on the flow of funds between our subsidiaries and us could restrict our ability to act in response
to changing market conditions.

[0001193125-16-574999:mdna:70]
[same as prior period, unchanged from 0001193125-16-447643:mdna:72]

[0001193125-16-574999:mdna:71]
[same as prior period, unchanged from 0001193125-16-447643:mdna:73]

[0001193125-16-574999:mdna:72]
Throughout the period of our operations in Thailand, we have generally received income tax and
other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption is currently available to us through June 2020 on income generated from the manufacture of products
at Pinehurst Building 6. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in
Thailand for at least 15 years. In December 2011, the Thailand Revenue Department announced a reduction in corporate income tax rates for tax periods beginning on or after January 1, 2012. As a result, corporate income tax rates for our Thai
subsidiary were reduced from 23% in fiscal year 2013 to 20% in fiscal years 2014 to 2016. Additionally, in March 2016, the Thailand Revenue Department announced corporate income tax rates for tax periods beginning on or after January 1, 2016.
As a result, corporate income tax rates for our Thai subsidiary remain at 20% from fiscal year 2017 onward.

[0001193125-16-574999:mdna:73]
Critical Accounting Policies and Use of
Estimates

[0001193125-16-574999:mdna:74]
We prepare our condensed consolidated financial statements in conformity with U.S. GAAP, which requires us to make estimates
and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent liabilities on the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses during the
financial reporting period. We continually evaluate these estimates and assumptions based on the most recently available information, our own historical experience and on various other assumptions that we believe to be reasonable under the
circumstances, the results form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Because the use of estimates is an integral component of the financial reporting
process, actual results could differ from those estimates. Some of our accounting policies require higher degrees of judgment than others in their application. We consider the policies discussed below to be critical to an understanding of our
condensed consolidated financial statements, as their application places the most significant demands on our management’s judgment.

[0001193125-16-574999:mdna:75]
Our critical accounting policies are disclosed in our Annual Report on Form 10-K for the fiscal year ended June 26, 2015.

[0001193125-16-574999:mdna:76]
[same as prior period, unchanged from 0001193125-16-447643:mdna:78]

[0001193125-16-574999:mdna:77]
The following
table sets forth a summary of our unaudited condensed consolidated statements of operations and comprehensive income. Note that period-to-period comparisons of operating results should not be relied upon as indicative of future performance.

[0001193125-16-574999:mdna:78]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 25,2016 |  |  | March 27,2015 |  |  | March 25,2016 |  |  | March 27,2015 |  |
| Revenues |  | $ | 250,888 |  |  | $ | 189,453 |  |  | $ | 700,359 |  |  | $ | 567,131 |  |
| Cost of revenues |  |  | (219,711 | ) |  |  | (167,796 | ) |  |  | (614,678 | ) |  |  | (503,907 | ) |
| Gross profit |  |  | 31,177 |  |  |  | 21,657 |  |  |  | 85,681 |  |  |  | 63,224 |  |
| Selling, general and administrative expenses |  |  | (12,299 | ) |  |  | (9,670 | ) |  |  | (37,914 | ) |  |  | (28,721 | ) |
| Other income related to flooding |  |  | 900 |  |  |  | — |  |  |  | 36 |  |  |  | — |  |
| Expenses related to reduction in workforce |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,153 | ) |
| Operating income |  |  | 19,778 |  |  |  | 11,987 |  |  |  | 47,803 |  |  |  | 33,350 |  |
| Interest income |  |  | 213 |  |  |  | 258 |  |  |  | 1,110 |  |  |  | 956 |  |
| Interest expense |  |  | (335 | ) |  |  | (125 | ) |  |  | (1,156 | ) |  |  | (375 | ) |
| Foreign exchange gain (loss), net |  |  | 3,080 |  |  |  | (87 | ) |  |  | (1,246 | ) |  |  | (110 | ) |
| Other income (expense) |  |  | 57 |  |  |  | (75 | ) |  |  | 266 |  |  |  | (106 | ) |
| Income before income taxes |  |  | 22,793 |  |  |  | 11,958 |  |  |  | 46,777 |  |  |  | 33,715 |  |
| Income tax expense |  |  | (1,971 | ) |  |  | (1,113 | ) |  |  | (4,549 | ) |  |  | (3,108 | ) |
| Net income |  |  | 20,822 |  |  |  | 10,845 |  |  |  | 42,228 |  |  |  | 30,607 |  |
| Other comprehensive income, net of tax |  |  | 1,014 |  |  |  | 512 |  |  |  | 791 |  |  |  | 26 |  |
| Net comprehensive income |  | $ | 21,836 |  |  | $ | 11,357 |  |  | $ | 43,019 |  |  | $ | 30,633 |  |

[0001193125-16-574999:mdna:79]
The following table sets forth a summary of our unaudited condensed consolidated statements of
operations and comprehensive income as a percentage of total revenues for the periods indicated.

[0001193125-16-574999:mdna:80]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 25,2016 |  |  | March 27,2015 |  |  | March 25,2016 |  |  | March 27,2015 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (87.6 | ) |  |  | (88.6 | ) |  |  | (87.8 | ) |  |  | (88.8 | ) |
| Gross profit |  |  | 12.4 |  |  |  | 11.4 |  |  |  | 12.2 |  |  |  | 11.2 |  |
| Selling, general and administrative expenses |  |  | (4.9 | ) |  |  | (5.1 | ) |  |  | (5.4 | ) |  |  | (5.1 | ) |
| Other income related to flooding |  |  | 0.4 |  |  |  | — |  |  |  | 0.0 |  |  |  | — |  |
| Expenses related to reduction in workforce |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.2 | ) |
| Operating income |  |  | 7.9 |  |  |  | 6.3 |  |  |  | 6.8 |  |  |  | 5.9 |  |
| Interest income |  |  | 0.1 |  |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.2 |  |
| Interest expense |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | (0.2 | ) |  |  | (0.1 | ) |
| Foreign exchange gain (loss), net |  |  | 1.2 |  |  |  | (0.1 | ) |  |  | (0.2 | ) |  |  | (0.0 | ) |
| Other income (expense) |  |  | 0.0 |  |  |  | (0.0 | ) |  |  | 0.1 |  |  |  | (0.0 | ) |
| Income before income taxes |  |  | 9.1 |  |  |  | 6.3 |  |  |  | 6.7 |  |  |  | 5.9 |  |
| Income tax expense |  |  | (0.8 | ) |  |  | (0.6 | ) |  |  | (0.7 | ) |  |  | (0.6 | ) |
| Net income |  |  | 8.3 |  |  |  | 5.7 |  |  |  | 6.0 |  |  |  | 5.4 |  |
| Other comprehensive income, net of tax |  |  | 0.4 |  |  |  | 0.3 |  |  |  | 0.1 |  |  |  | 0.0 |  |
| Net comprehensive income |  |  | 8.7 | % |  |  | 6.0 | % |  |  | 6.1 | % |  |  | 5.4 | % |

[0001193125-16-574999:mdna:81]
[same as prior period, unchanged from 0001193125-16-447643:mdna:83]

[0001193125-16-574999:mdna:82]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 25,2016 |  |  | March 27,2015 |  |  | March 25,2016 |  |  | March 27,2015 |  |
| Optical communications |  | $ | 192,173 |  |  | $ | 136,537 |  |  | $ | 515,629 |  |  | $ | 405,600 |  |
| Lasers, sensors and other |  |  | 58,715 |  |  |  | 52,916 |  |  |  | 184,730 |  |  |  | 161,531 |  |
| Total |  | $ | 250,888 |  |  | $ | 189,453 |  |  | $ | 700,359 |  |  | $ | 567,131 |  |

[0001193125-16-574999:mdna:83]
[same as prior period, unchanged from 0001193125-16-447643:mdna:85]

[0001193125-16-574999:mdna:84]
Comparison of Three and Nine Months Ended March 25, 2016 with Three and Nine Months
Ended March 27, 2015

[0001193125-16-574999:mdna:85]
[same as prior period, unchanged from 0001193125-16-447643:mdna:88]

[0001193125-16-574999:mdna:86]
Our total revenues increased by $61.4 million, or 32.4%, to $250.9 million for the three months ended March 25, 2016, compared with $189.5
million for the three months ended March 27, 2015. This increase was primarily due to (i) an increase in customers’ demand for both optical and non-optical communications manufacturing services during the three months ended
March 25, 2016 and (ii) our inability to recognize $4.6 million of consignment revenue during the three months ended March 27, 2015 because of certain consignment revenue recognition issues previously disclosed that result in lower
revenue in the prior period. Revenues from optical communications products represented 76.6% of our total revenues for the three months ended March 25, 2016, compared to 72.1% for the three months ended March 27, 2015.

[0001193125-16-574999:mdna:87]
Our total revenues increased by $133.2 million, or 23.5%, to $700.4 million for the nine months ended March 25, 2016, compared with
$567.1 million for the nine months ended March 27, 2015. This increase was primarily due to (i) an increase in customers’ demand for both optical and non-optical communications manufacturing services during the nine months ended
March 25, 2016 and (ii) our inability to recognize $4.6 million of consignment revenue during the nine months ended March 27, 2015 because of certain consignment revenue recognition issues previously disclosed that result in lower
revenue in the prior period. Revenues from optical communications products represented 73.6% of our total revenues for the nine months ended March 25, 2016, compared to 71.5% for the nine months ended March 27, 2015.

[0001193125-16-574999:mdna:88]
[same as prior period, unchanged from 0001193125-16-447643:mdna:91]

[0001193125-16-574999:mdna:89]
Our cost of revenues increased by $51.9 million, or 30.9%, to $219.7 million, or 87.6% of total revenues, for the three months ended
March 25, 2016, compared with $167.8 million, or 88.6% of total revenues, for the three months ended March 27, 2015. The increase in cost of revenues on an absolute dollar basis was primarily due to an increase in sales volume, partially
offset by a more favorable product mix. Cost of revenues also included share-based compensation expense of $0.5 million for the three months ended March 25, 2016, compared with $0.4 million for the three months ended March 27, 2015.

[0001193125-16-574999:mdna:90]
Our cost of revenues increased by $110.8 million, or 22.0%, to $614.7 million, or 87.8% of total revenues, for the nine months ended
March 25, 2016, compared with $503.9 million, or 88.8% of total revenues, for the nine months ended March 27, 2015. The increase in cost of revenues on an absolute dollar basis was primarily due to an increase in sales volume, partially
offset by a more favorable product mix. Cost of revenues also included share-based compensation expense of $1.6 million for the nine months ended March 25, 2016, compared with $1.1 million for the nine months ended March 27, 2015.

[0001193125-16-574999:mdna:91]
[same as prior period, unchanged from 0001193125-16-447643:mdna:94]

[0001193125-16-574999:mdna:92]
Our gross
profit increased by $9.5 million, or 44.0%, to $31.2 million, or 12.4% of total revenues, for the three months ended March 25, 2016, compared with $21.7 million, or 11.4% of total revenues, for the three months ended March 27, 2015. Our
gross profit increased by $22.5 million, or 35.5%, to $85.7 million, or 12.2% of total revenues, for the nine months ended March 25, 2016, compared with $63.2 million, or 11.2% of total revenues, for the nine months ended March 27, 2015.

[0001193125-16-574999:mdna:93]
The improvement in gross profit margin during the three and nine months ended March 25, 2016, compared with the three and nine
months ended March 27, 2015, was related to a more favorable product mix during the three and nine months ended March 25, 2016.

[0001193125-16-574999:mdna:94]
[same as prior period, unchanged from 0001193125-16-447643:mdna:97]

[0001193125-16-574999:mdna:95]
Our
SG&A expenses increased by $2.6 million, or 27.2%, to $12.3 million, or 4.9% of total revenues, for the three months ended March 25, 2016, compared with $9.7 million, or 5.1% of total revenues, for the three months ended March 27,
2015. Our SG&A expenses increased in absolute dollars due primarily to an increase in expenses relating to our new manufacturing facility in the United States of $0.8 million and severance and related payments of $0.7 million to an employee who
left the Company in January 2016. We also recorded share-based compensation charges of $1.5 million for the three months ended March 25, 2016, compared with $1.6 million for the three months ended March 27, 2015.

[0001193125-16-574999:mdna:96]
Our SG&A expenses increased by $9.2 million, or 32.0%, to $37.9 million, or 5.4% of total revenues, for the nine months ended
March 25, 2016, compared with $28.7 million, or 5.1% of total revenues, for the nine months ended March 27, 2015. Our SG&A expenses increased in absolute dollars and as a percentage of revenue due primarily to an increase in expenses
relating to our new manufacturing facility in the United States of $4.9 million, an increase in sales and marketing expenses of $1.8 million to support the expansion of our operations and severance and related payments of $1.4 million to employees
who left the Company during the nine months ended March 25, 2016. We also recorded share-based compensation charges of $6.2 million for the nine months ended March 25, 2016, compared with $4.7 million for the nine months ended
March 27, 2015.

[0001193125-16-574999:mdna:97]
Other income related to flooding.

[0001193125-16-574999:mdna:98]
In the three months ended March 25, 2016, we recognized other income related to flooding of $0.9 million, which primarily consisted of a
payment of $0.8 million from an insurer against our claim for flood damage.

[0001193125-16-574999:mdna:99]
In the nine months ended March 25, 2016, we recognized
other income related to flooding of $0.04 million, which mainly consisted of $0.8 million from an insurer against our claim for flood damage, offset by expenses in relation to flood of $0.8 million, which mainly consisted of $0.6 million of repaired
cost of equipment and $0.2 million of inventory losses.

[0001193125-16-574999:mdna:100]
Expenses related to reduction in workforce.

[0001193125-16-574999:mdna:101]
During the nine months ended March 27, 2015, we implemented a reduction in workforce and incurred expenses of approximately $1.2 million
which represented severance and benefits costs associated with the termination of approximately 100 employees in accordance with contractual obligations and local regulations.

[0001193125-16-574999:mdna:102]
[same as prior period, unchanged from 0001193125-16-447643:mdna:104]

[0001193125-16-574999:mdna:103]
Our operating income increased by $7.8 million to $19.8 million, or 7.9% of total revenues, for the three months ended March 25, 2016,
compared with $12.0 million, or 6.3% of total revenues, for the three months ended March 27, 2015.

[0001193125-16-574999:mdna:104]
Our operating income increased by
$14.5 million to $47.8 million, or 6.8% of total revenues, for the nine months ended March 25, 2016, compared with $33.4 million, or 5.9% of total revenues, for the nine months ended March 27, 2015.

[0001193125-16-574999:mdna:105]
[same as prior period, unchanged from 0001193125-16-447643:mdna:107]

[0001193125-16-574999:mdna:106]
Our
interest income decreased by $0.1 million to $0.2 million, or 0.1% of total revenues, for the three months ended March 25, 2016, compared with $0.3 million, or 0.2% of total revenues, for the three months ended March 27, 2015.

[0001193125-16-574999:mdna:107]
Our interest income increased by $0.2 million to $1.1 million, or 0.2% of total revenues, for the nine months ended March 25, 2016,
compared with $0.9 million, or 0.2% of total revenues, for the nine months ended March 27, 2015.

[0001193125-16-574999:mdna:108]
[same as prior period, unchanged from 0001193125-16-447643:mdna:110]

[0001193125-16-574999:mdna:109]
Our interest expense increased by $0.2 million to $0.3 million for the three months ended March 25, 2016, compared with $0.1 million for
the three months ended March 27, 2015. Our interest expense increased by $0.8 million to $1.2 million for the nine months ended March 25, 2016, compared with $0.4 million for the nine months ended March 27, 2015.

[0001193125-16-574999:mdna:110]
The increases were due to increases in the average balance of our bank borrowings resulting from a drawdown of a revolving loan under our
Facility Agreement taken during second quarter of fiscal year 2016, as well as the amortization of additional deferred debt issuance costs.

[0001193125-16-574999:mdna:111]
[same as prior period, unchanged from 0001193125-16-447643:mdna:112]

[0001193125-16-574999:mdna:112]
Our foreign exchange gain (loss), net, increased by $3.2 million to foreign exchange gain, net, of $3.1 million, or 1.2% of total revenues, for
the three months ended March 25, 2016, compared with foreign exchange loss, net, of $0.1 million, or 0.1% of total revenues, for the three months ended March 27, 2015. Our foreign exchange loss, net, increased by $1.1 million to $1.2
million, or 0.2% of total revenues, for the nine months ended March 25, 2016, compared with $0.1 million, or 0.02% of total revenues, for the nine months ended March 27, 2015. The increase was due to changes in the fair value of
outstanding derivatives as of March 25, 2016 that were not designated as hedges for accounting.

[0001193125-16-574999:mdna:113]
[same as prior period, unchanged from 0001193125-16-447643:mdna:114]

[0001193125-16-574999:mdna:114]
We recorded income before income taxes of $22.8 million and $46.8 million for the three and nine months ended March 25, 2016,
respectively, compared with $12.0 million and $33.7 million for the three and nine months ended March 27, 2015, respectively.

[0001193125-16-574999:mdna:115]
[same as prior period, unchanged from 0001193125-16-447643:mdna:116]

[0001193125-16-574999:mdna:116]
Our
provision for income tax reflects an effective tax rate of 5.8% for the three months ended March 25, 2016, compared with an effective tax rate of 7.0% for the three months ended March 27, 2015. The decrease was primarily due to the fact
that we had lower taxable income during the three months ended March 25, 2016 as compared to the three months ended March 27, 2015.

[0001193125-16-574999:mdna:117]
Our provision for income tax reflects an effective tax rate of 6.4% for the nine months ended March 25, 2016, compared with an effective
tax rate of 6.6% for the nine months ended March 27, 2015. The slight decrease was primarily due to the fact that we had lower taxable income during the nine months ended March 25, 2016 as compared to the nine months ended March 27,
2015.

[0001193125-16-574999:mdna:118]
[same as prior period, unchanged from 0001193125-16-447643:mdna:119]

[0001193125-16-574999:mdna:119]
We recorded net income of $20.8 million, or 8.3% of total revenues, for the three months ended March 25, 2016, compared with $10.8
million, or 5.7% of total revenues, for the three months ended March 27, 2015.

[0001193125-16-574999:mdna:120]
We recorded net income of $42.2 million, or 6.0% of
total revenues, for the nine months ended March 25, 2016, compared with $30.6 million, or 5.4% of total revenues, for the nine months ended March 27, 2015.

[0001193125-16-574999:mdna:121]
Other comprehensive income.

[0001193125-16-574999:mdna:122]
We recorded other comprehensive income of $1.0 million, or 0.4% of total revenues, for the three months ended March 25, 2016, compared
with $0.5 million, or 0.3% of total revenues, for the three months ended March 27, 2015.

[0001193125-16-574999:mdna:123]
We recorded other comprehensive income of
$0.8 million, or 0.1% of total revenues, for the nine months ended March 25, 2016, compared with $0.02 million, or 0.01% of total revenues, for the nine months ended March 27, 2015.

[0001193125-16-574999:mdna:124]
[same as prior period, unchanged from 0001193125-16-447643:mdna:125]

[0001193125-16-574999:mdna:125]
[same as prior period, unchanged from 0001193125-16-447643:mdna:126]

[0001193125-16-574999:mdna:126]
We primarily finance our operations through cash flow from operations. As of March 25, 2016 and March 27, 2015, we had cash, cash
equivalents, and marketable securities of $272.8 million and $254.3 million, respectively, and outstanding debt of $50.0 million and $42.0 million, respectively.

[0001193125-16-574999:mdna:127]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of
three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents for the three and nine months ended March 25, 2016 was 0.5% and 0.9%, respectively, and for the
three and nine months ended March 27, 2015 was 0.7% and 0.6%, respectively.

[0001193125-16-574999:mdna:128]
Our cash investments are made in accordance with an
investment policy approved by the Audit Committee of our Board of Directors. In general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years.
Our investments in fixed income securities are primarily classified as available-for-sale and are recorded at fair value. The cost of securities sold is based on the specific identification method. Unrealized gains and losses on these securities are
recorded as other comprehensive income (loss) and are reported as a separate component of shareholders’ equity.

[0001193125-16-574999:mdna:129]
During the three
months ended March 25, 2016, we repaid a revolving loan of $4.0 million under our Facility Agreement; as a result, as of March 25, 2016, we had a short-term borrowing of $44.0 million under our Facility Agreement. In addition, to better
manage our cash on hand, we invested in short-term marketable securities of $144.8 million as of March 25, 2016.

[0001193125-16-574999:mdna:130]
We believe that our
current cash and cash equivalents, marketable securities, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for the next 12 months. Our ability to
sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001193125-16-574999:mdna:131]
In December 2015, we began construction of a new manufacturing facility at our Chonburi campus, which we expect to complete in the first
quarter of fiscal year 2017. We believe that our current manufacturing capacity is sufficient to meet our anticipated production requirements for at least the next few quarters. Should there be a major delay in construction beyond our estimated
completion date, we may not have the capacity to meet our anticipated production requirements. We maintain a long-term loan associated with construction of production facilities at our Pinehurst campus in Thailand which will be due within the next
12 months. We also have a sufficient credit facility in place to fund the amount needed to construct a new building at our Chonburi campus. We anticipate that our internally generated working capital, along with our cash and cash equivalents will be
adequate to repay these obligations.

[0001193125-16-574999:mdna:132]
[same as prior period, unchanged from 0001193125-16-447643:mdna:133]

[0001193125-16-574999:mdna:133]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 25,2016 |  |  | March 27,2015 |  |
| Net cash provided by operating activities |  | $ | 41,356 |  |  | $ | 40,481 |  |
| Net cash used in investing activities |  | $ | (35,820 | ) |  | $ | (169,159 | ) |
| Net cash provided by financing activities |  | $ | 9,948 |  |  | $ | 24,122 |  |
| Net increase (decrease) in cash and cash equivalents |  | $ | 15,484 |  |  | $ | (104,556 | ) |
| Cash and cash equivalents, beginning of period |  | $ | 112,978 |  |  | $ | 233,477 |  |
| Cash and cash equivalents, end of period |  | $ | 127,957 |  |  | $ | 128,946 |  |

[0001193125-16-574999:mdna:134]
[same as prior period, unchanged from 0001193125-16-447643:mdna:135]

[0001193125-16-574999:mdna:135]
Net cash provided by operating activities increased by $0.9 million, or 2.2%, to $41.4 million for the nine months ended March 25, 2016,
compared with net cash provided by operating activities of $40.5 million for the nine months ended March 27, 2015. This increase was due to numbers of factors, including an increase in net income of $11.6 million and a decrease in payments to
vendors of $22.3 million, offset by increases in accounts receivable of $18.1 million and inventory of $16.8 million due to higher sales and customer demand.

[0001193125-16-574999:mdna:136]
[same as prior period, unchanged from 0001193125-16-447643:mdna:137]

[0001193125-16-574999:mdna:137]
Net
cash used in investing activities decreased by $133.3 million, or 78.8%, to $35.8 million for the nine months ended March 25, 2016, compared with net cash used in investing activities of $169.2 million for the nine months ended March 27,
2015. This decrease was primarily due to a net decrease in available-for-sale securities of $123.6 million and a decrease in purchase of property, plant, and equipment of $9.4 million.

[0001193125-16-574999:mdna:138]
[same as prior period, unchanged from 0001193125-16-447643:mdna:139]

[0001193125-16-574999:mdna:139]
Net
cash provided by financing activities decreased by $14.2 million, or 58.8%, to $9.9 million for the nine months ended March 25, 2016, compared with net cash provided by financing activities of $24.1 million for the nine months ended
March 27, 2015. This decrease was primarily due to a decrease of $12.0 million in drawdowns under our Facility Agreement during the nine months ended March 25, 2016 as compared to the nine months ended March 27, 2015.

[0001193125-16-574999:mdna:140]
[same as prior period, unchanged from 0001193125-16-447643:mdna:141]

[0001193125-16-574999:mdna:141]
[same as prior period, unchanged from 0001193125-16-447643:mdna:142]

[0001193125-16-574999:mdna:142]
[same as prior period, unchanged from 0001193125-16-447643:mdna:143]

[0001193125-16-574999:mdna:143]
[same as prior period, unchanged from 0001193125-16-447643:mdna:144]
