# FN 8-K — 0001193125-16-572657 filed 2016-05-02

## item codes, every 8-K on or before 2016-05-03

- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2016-05-03

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-572657:8k_2_02:1]
EX-99.1
2
d189864dex991.htm
EX-99.1

[0001193125-16-572657:8k_2_02:2]
EX-99.1

[0001193125-16-572657:8k_2_02:3]
Exhibit 99.1

[0001193125-16-572657:8k_2_02:4]
Fabrinet Announces Third Quarter Fiscal-Year 2016 Financial Results

[0001193125-16-572657:8k_2_02:5]
BANGKOK, Thailand – May 2, 2016 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical,
electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its third fiscal quarter ended March 25, 2016.

[0001193125-16-572657:8k_2_02:6]
Tom Mitchell, Chief Executive Officer of Fabrinet, said, “We delivered a strong third quarter with revenue and earnings per share above expectations. In
the third quarter we particularly benefited from positive trends in the optical industry, which resulted in higher than expected demand from new customer programs and increasing production from existing customer programs. With robust industry
trends, we expect the momentum we are experiencing to continue into the fourth quarter. Construction on the first building of our new campus in Thailand is progressing faster than anticipated. While we have sufficient capacity to meet near-term
demand, we now expect the building, which will significantly increase our capacity, to be completed by the end of the first quarter of fiscal-year 2017 with first customer shipments beginning in the third quarter. Our new campus will ultimately more
than double our manufacturing space, enabling us to continue to scale our business for many years.”

[0001193125-16-572657:8k_2_02:7]
Third Quarter Fiscal-Year 2016 Financial
Highlights

[0001193125-16-572657:8k_2_02:8]
GAAP Results

[0001193125-16-572657:8k_2_02:9]
|  | • |  | Revenue was $250.9 million for the third quarter of fiscal year 2016, an increase of 32% compared to total revenue of $189.5 million for the comparable period in fiscal year 2015. |

[0001193125-16-572657:8k_2_02:10]
|  | • |  | GAAP net income for the third quarter of fiscal year 2016 was $20.8 million, compared to GAAP net income of $10.8 million in the third quarter of fiscal year 2015. |

[0001193125-16-572657:8k_2_02:11]
|  | • |  | GAAP net income per diluted share for the third quarter of fiscal year 2016 was $0.56, compared to GAAP net income per diluted share of $0.30 in the third quarter of fiscal year 2015. |

[0001193125-16-572657:8k_2_02:12]
Non-GAAP Results

[0001193125-16-572657:8k_2_02:13]
|  | • |  | Non-GAAP net income in the third quarter of fiscal 2016 was $20.8 million, an increase of 60% compared to non-GAAP net income of $13.0 million in the same period a year ago. |

[0001193125-16-572657:8k_2_02:14]
|  | • |  | Non-GAAP net income per diluted share in the third quarter of fiscal 2016 was $0.56, an increase from non-GAAP net income per diluted share of $0.36 in the same period a year ago. |

[0001193125-16-572657:8k_2_02:15]
Business Outlook

[0001193125-16-572657:8k_2_02:16]
Based on information available as of
May 2, 2016, Fabrinet is issuing guidance for the fourth quarter of fiscal 2016 ending June 24, 2016, as follows:

[0001193125-16-572657:8k_2_02:17]
|  | • |  | Fabrinet expects fourth quarter revenue to be in the range of $260 million to $264 million. |

[0001193125-16-572657:8k_2_02:18]
|  | • |  | GAAP net income per diluted share is expected to be in the range of $0.55 to $0.57, based on approximately 37.2 million fully diluted shares outstanding. |

[0001193125-16-572657:8k_2_02:19]
|  | • |  | Non-GAAP net income per diluted share is expected to be in the range of $0.59 to $0.61, based on approximately 37.2 million fully diluted shares outstanding. |

[0001193125-16-572657:8k_2_02:20]
Conference Call Information

[0001193125-16-572657:8k_2_02:21]
| What: |  | Fabrinet Third Quarter Fiscal-Year 2016 Financial Results Conference Call |
| When: |  | Monday, May 2, 2016 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic (253) 237-1137, international Passcode: 94054682 |
| Replay: |  | (855) 859-2056, domestic (404) 537-3406, international Passcode: 94054682 |
| Webcast: |  | http://investor.fabrinet.com (live and replay) |

[0001193125-16-572657:8k_2_02:22]
1

[0001193125-16-572657:8k_2_02:23]
This press release and any other information related to the call will also be posted on Fabrinet’s website
at http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-16-572657:8k_2_02:24]
About Fabrinet

[0001193125-16-572657:8k_2_02:25]
Fabrinet is a leading provider of
advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, industrial lasers
and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging,
integration, final assembly and test. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the People’s Republic of China
and the United States of America. For more information visit: www.fabrinet.com.

[0001193125-16-572657:8k_2_02:26]
Forward-Looking Statements

[0001193125-16-572657:8k_2_02:27]
Use of Non-GAAP Financials

[0001193125-16-572657:8k_2_02:28]
The Company refers to
the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding the Company’s ongoing operational performance. Non-GAAP net income excludes share-based compensation
expenses, executive separation costs, investigation costs, income related to flooding, expenses related to reduction in workforce, amortization of debt issuance costs and unrealized gain or loss on foreign currency. We have excluded these items in
order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP
financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001193125-16-572657:8k_2_02:29]
These non-GAAP financial measures are used to: (1) measure company performance against historical results,
(2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial
measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001193125-16-572657:8k_2_02:30]
SOURCE: Fabrinet

[0001193125-16-572657:8k_2_02:31]
Investor Contact:

[0001193125-16-572657:8k_2_02:32]
Garo Toomajanian

[0001193125-16-572657:8k_2_02:33]
617-956-6728

[0001193125-16-572657:8k_2_02:34]
ir@fabrinet.com

[0001193125-16-572657:8k_2_02:35]
Fabrinet

[0001193125-16-572657:8k_2_02:36]
Unaudited Condensed Consolidated Balance Sheets

[0001193125-16-572657:8k_2_02:37]
As of
March 25, 2016 and June 26, 2015

[0001193125-16-572657:8k_2_02:38]
| (in thousands of U.S. dollars, except share data) |  | March 25,2016 |  |  | June 26,2015 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 127,957 |  |  | $ | 112,978 |  |
| Marketable securities |  |  | 144,808 |  |  |  | 142,866 |  |
| Trade accounts receivable, net |  |  | 172,129 |  |  |  | 134,952 |  |
| Inventory, net |  |  | 149,982 |  |  |  | 130,613 |  |
| Deferred tax assets |  |  | 1,361 |  |  |  | 1,662 |  |
| Prepaid expenses |  |  | 2,381 |  |  |  | 2,135 |  |
| Other current assets |  |  | 5,136 |  |  |  | 1,833 |  |
| Total current assets |  |  | 603,754 |  |  |  | 527,039 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 160,441 |  |  |  | 140,654 |  |
| Intangibles, net |  |  | 369 |  |  |  | 137 |  |
| Deferred tax assets |  |  | 1,455 |  |  |  | 2,249 |  |
| Deferred debt issuance costs and others |  |  | 2,511 |  |  |  | 2,424 |  |
| Total non-current assets |  |  | 164,776 |  |  |  | 145,464 |  |
| Total Assets |  | $ | 768,530 |  |  | $ | 672,503 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Bank borrowings, including revolving loan and current portion of long-term loan from bank |  | $ | 50,000 |  |  | $ | 36,000 |  |
| Trade accounts payable |  |  | 146,445 |  |  |  | 115,319 |  |
| Income tax payable |  |  | 1,323 |  |  |  | 1,470 |  |
| Accrued payroll, bonus and related expenses |  |  | 11,340 |  |  |  | 9,804 |  |
| Accrued expenses |  |  | 7,123 |  |  |  | 6,405 |  |
| Other payables |  |  | 12,713 |  |  |  | 12,050 |  |
| Total current liabilities |  |  | 228,944 |  |  |  | 181,048 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term loans from bank, non-current portion |  |  | — |  |  |  | 4,500 |  |
| Deferred tax liability |  |  | 696 |  |  |  | 737 |  |
| Severance liabilities |  |  | 6,200 |  |  |  | 5,477 |  |
| Other non-current liabilities |  |  | 1,990 |  |  |  | 1,797 |  |
| Total non-current liabilities |  |  | 8,886 |  |  |  | 12,511 |  |
| Total Liabilities |  |  | 237,830 |  |  |  | 193,559 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; No shares issued and outstanding as of March 25, 2016 and June 26, 2015) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 36,016,245 shares and 35,437,654 shares issued and outstanding as of March 25, 2016 and June 26, 2015, respectively) |  |  | 360 |  |  |  | 354 |  |
| Additional paid-in capital |  |  | 98,120 |  |  |  | 89,390 |  |
| Retained earnings |  |  | 431,473 |  |  |  | 389,244 |  |
| Accumulated other comprehensive income (loss) |  |  | 747 |  |  |  | (44 | ) |
| Total Shareholders’ Equity |  |  | 530,700 |  |  |  | 478,944 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 768,530 |  |  | $ | 672,503 |  |

[0001193125-16-572657:8k_2_02:39]
Fabrinet

[0001193125-16-572657:8k_2_02:40]
Unaudited Condensed Consolidated Statements of Operations and Comprehensive Income

[0001193125-16-572657:8k_2_02:41]
For the three and nine months ended March 25, 2016 and March 27,2015

[0001193125-16-572657:8k_2_02:42]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (in thousands of U.S. dollars, except per share amounts) |  | March 25,2016 |  |  | March 27,2015 |  |  | March 25,2016 |  |  | March 27,2015 |  |
| Revenues |  | $ | 250,888 |  |  | $ | 189,453 |  |  | $ | 700,359 |  |  | $ | 567,131 |  |
| Cost of revenues |  |  | (219,711 | ) |  |  | (167,796 | ) |  |  | (614,678 | ) |  |  | (503,907 | ) |
| Gross profit |  |  | 31,177 |  |  |  | 21,657 |  |  |  | 85,681 |  |  |  | 63,224 |  |
| Selling, general and administrative expenses |  |  | (12,299 | ) |  |  | (9,670 | ) |  |  | (37,914 | ) |  |  | (28,721 | ) |
| Other income related to flooding |  |  | 900 |  |  |  | — |  |  |  | 36 |  |  |  | — |  |
| Expenses related to reduction in workforce |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,153 | ) |
| Operating income |  |  | 19,778 |  |  |  | 11,987 |  |  |  | 47,803 |  |  |  | 33,350 |  |
| Interest income |  |  | 213 |  |  |  | 258 |  |  |  | 1,110 |  |  |  | 956 |  |
| Interest expense |  |  | (335 | ) |  |  | (125 | ) |  |  | (1,156 | ) |  |  | (375 | ) |
| Foreign exchange gain (loss), net |  |  | 3,080 |  |  |  | (87 | ) |  |  | (1,246 | ) |  |  | (110 | ) |
| Other income (expense) |  |  | 57 |  |  |  | (75 | ) |  |  | 266 |  |  |  | (106 | ) |
| Income before income taxes |  |  | 22,793 |  |  |  | 11,958 |  |  |  | 46,777 |  |  |  | 33,715 |  |
| Income tax expense |  |  | (1,971 | ) |  |  | (1,113 | ) |  |  | (4,549 | ) |  |  | (3,108 | ) |
| Net income |  |  | 20,822 |  |  |  | 10,845 |  |  |  | 42,228 |  |  |  | 30,607 |  |
| Other comprehensive income, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in net unrealized gains on marketable securities |  |  | 292 |  |  |  | 512 |  |  |  | 117 |  |  |  | 26 |  |
| Change in net unrealized gains on derivatives instruments |  |  | 722 |  |  |  | — |  |  |  | 674 |  |  |  | — |  |
| Total other comprehensive income, net of tax |  |  | 1,014 |  |  |  | 512 |  |  |  | 791 |  |  |  | 26 |  |
| Net comprehensive income |  | $ | 21,836 |  |  | $ | 11,357 |  |  | $ | 43,019 |  |  | $ | 30,633 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.58 |  |  | $ | 0.31 |  |  | $ | 1.18 |  |  | $ | 0.87 |  |
| Diluted |  | $ | 0.56 |  |  | $ | 0.30 |  |  | $ | 1.15 |  |  | $ | 0.85 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 35,964 |  |  |  | 35,406 |  |  |  | 35,785 |  |  |  | 35,328 |  |
| Diluted |  |  | 37,089 |  |  |  | 36,110 |  |  |  | 36,743 |  |  |  | 35,871 |  |

[0001193125-16-572657:8k_2_02:43]
Fabrinet

[0001193125-16-572657:8k_2_02:44]
Unaudited Condensed Consolidated Statements of Cash Flows

[0001193125-16-572657:8k_2_02:45]
For the nine months ended March 25, 2016 and March 27, 2015

[0001193125-16-572657:8k_2_02:46]
|  |  | Nine Months Ended |  |
| (in thousands of U.S. dollars) |  | March 25,2016 |  |  | March 27,2015 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income for the period |  | $ | 42,228 |  |  | $ | 30,607 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 12,793 |  |  |  | 9,322 |  |
| Gain on disposal of property, plant and equipment |  |  | (13 | ) |  |  | (41 | ) |
| Loss from sales and maturities of available-for-sale securities |  |  | 190 |  |  |  | 62 |  |
| Amortization of investment premium |  |  | 605 |  |  |  | 757 |  |
| Amortization of deferred debt issuance costs |  |  | 543 |  |  |  | 377 |  |
| Income related to flooding |  |  | (828 | ) |  |  | — |  |
| Proceeds from insurer in settlement of claims related to flood damage |  |  | 272 |  |  |  | — |  |
| (Reversal of) allowance for doubtful accounts |  |  | (7 | ) |  |  | 3 |  |
| Unrealized loss (gain) on exchange rate and fair value of derivative instruments |  |  | 2,406 |  |  |  | (286 | ) |
| Share-based compensation |  |  | 7,782 |  |  |  | 5,806 |  |
| Deferred income tax |  |  | 1,054 |  |  |  | 137 |  |
| Other non-cash expenses |  |  | 1,171 |  |  |  | 1,153 |  |
| (Reversal of) inventory obsolescence |  |  | (344 | ) |  |  | 332 |  |
| Loss from written-off inventory |  |  | 233 |  |  |  | — |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | (37,015 | ) |  |  | (18,832 | ) |
| Inventory |  |  | (19,258 | ) |  |  | (2,422 | ) |
| Other current assets and non-current assets |  |  | (3,803 | ) |  |  | (570 | ) |
| Trade accounts payable |  |  | 30,731 |  |  |  | 8,419 |  |
| Income tax payable |  |  | (114 | ) |  |  | (45 | ) |
| Other current liabilities and non-current liabilities |  |  | 2,730 |  |  |  | 5,702 |  |
| Net cash provided by operating activities |  |  | 41,356 |  |  |  | 40,481 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of marketable securities |  |  | (85,644 | ) |  |  | (159,396 | ) |
| Proceeds from sales of marketable securities |  |  | 28,735 |  |  |  | 22,873 |  |
| Proceeds from maturities of marketable securities |  |  | 54,290 |  |  |  | 10,332 |  |
| Purchase of property, plant and equipment |  |  | (33,545 | ) |  |  | (42,980 | ) |
| Purchase of intangibles |  |  | (274 | ) |  |  | (34 | ) |
| Proceeds from disposal of property, plant and equipment |  |  | 62 |  |  |  | 46 |  |
| Proceeds from insurer in settlement of equipment claims related to flood damage |  |  | 556 |  |  |  | — |  |
| Net cash used in investing activities |  |  | (35,820 | ) |  |  | (169,159 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Payment of debt issuance costs |  |  | (506 | ) |  |  | (1,780 | ) |
| Proceeds from revolving loans |  |  | 18,000 |  |  |  | 30,000 |  |
| Repayment of long-term loans from bank |  |  | (8,500 | ) |  |  | (4,500 | ) |
| Proceeds from issuance of ordinary shares under employee share option plans |  |  | 3,326 |  |  |  | 736 |  |
| Withholding tax related to net share settlement of restricted share units |  |  | (2,372 | ) |  |  | (334 | ) |
| Net cash provided by financing activities |  |  | 9,948 |  |  |  | 24,122 |  |
| Net increase (decrease) in cash and cash equivalents |  |  | 15,484 |  |  |  | (104,556 | ) |
| Movement in cash and cash equivalents |  |  |  |  |  |  |  |  |
| Cash and cash equivalents at beginning of period |  |  | 112,978 |  |  |  | 233,477 |  |
| Increase (decrease) in cash and cash equivalents |  |  | 15,484 |  |  |  | (104,556 | ) |
| Effect of exchange rate on cash and cash equivalents |  |  | (505 | ) |  |  | 25 |  |
| Cash and cash equivalents at end of period |  | $ | 127,957 |  |  | $ | 128,946 |  |
| Non-cash investing and financing activities |  |  |  |  |  |  |  |  |
| Construction and equipment-related payables |  | $ | 5,068 |  |  | $ | 4,170 |  |

[0001193125-16-572657:8k_2_02:47]
Fabrinet

[0001193125-16-572657:8k_2_02:48]
Unaudited Reconciliation of GAAP measures to non-GAAP measures

[0001193125-16-572657:8k_2_02:49]
(in thousands of U.S. dollars, except per share data)

[0001193125-16-572657:8k_2_02:50]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 25,2016 |  |  | March 25,2016 |  |  | March 27,2015 |  |  | March 27,2015 |  |  | March 25,2016 |  |  | March 25,2016 |  |  | March 27,2015 |  |  | March 27,2015 |  |
|  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |
| GAAP measures |  |  | 20,822 |  |  |  | 0.56 |  |  |  | 10,845 |  |  |  | 0.30 |  |  |  | 42,228 |  |  |  | 1.15 |  |  |  | 30,607 |  |  |  | 0.85 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 517 |  |  |  | 0.01 |  |  |  | 379 |  |  |  | 0.01 |  |  |  | 1,594 |  |  |  | 0.04 |  |  |  | 1,107 |  |  |  | 0.03 |  |
| Total related to gross profit |  |  | 517 |  |  |  | 0.01 |  |  |  | 379 |  |  |  | 0.01 |  |  |  | 1,594 |  |  |  | 0.04 |  |  |  | 1,107 |  |  |  | 0.03 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,482 |  |  |  | 0.04 |  |  |  | 1,630 |  |  |  | 0.05 |  |  |  | 6,188 |  |  |  | 0.17 |  |  |  | 4,699 |  |  |  | 0.13 |  |
| Executive separation costs |  |  | 808 |  |  |  | 0.02 |  |  |  | — |  |  |  | — |  |  |  | 1,360 |  |  |  | 0.04 |  |  |  | — |  |  |  | — |  |
| Investigation costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 4,100 |  |  |  | 0.11 |  |
| Total related to selling, general and administrative expenses |  |  | 2,290 |  |  |  | 0.06 |  |  |  | 1,630 |  |  |  | 0.05 |  |  |  | 7,548 |  |  |  | 0.21 |  |  |  | 8,799 |  |  |  | 0.25 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income related to flooding |  |  | (900 | ) |  |  | (0.02 | ) |  |  | — |  |  |  | — |  |  |  | (36 | ) |  |  | (0.00 | ) |  |  | — |  |  |  | — |  |
| Expenses related to reduction in workforce |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 1,153 |  |  |  | 0.03 |  |
| Amortization of debt issuance costs |  |  | 184 |  |  |  | 0.00 |  |  |  | 149 |  |  |  | 0.00 |  |  |  | 542 |  |  |  | 0.01 |  |  |  | 377 |  |  |  | 0.01 |  |
| (Gain)/loss on foreign currency |  |  | (3,183 | ) |  |  | (0.09 | ) |  |  | — |  |  |  | — |  |  |  | 2,296 |  |  |  | 0.06 |  |  |  | — |  |  |  | — |  |
| Total related to other incomes and other expenses |  |  | (3,899 | ) |  |  | (0.11 | ) |  |  | 149 |  |  |  | 0.00 |  |  |  | 2,802 |  |  |  | 0.08 |  |  |  | 1,530 |  |  |  | 0.04 |  |
| Related to income tax expense (benefit): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense (benefit) |  |  | 1,119 |  |  |  | 0.03 |  |  |  | — |  |  |  | — |  |  |  | 1,119 |  |  |  | 0.03 |  |  |  | (187 | ) |  |  | (0.01 | ) |
| Total related to income tax expense (benefit) |  |  | 1,119 |  |  |  | 0.03 |  |  |  | — |  |  |  | — |  |  |  | 1,119 |  |  |  | 0.03 |  |  |  | (187 | ) |  |  | (0.01 | ) |
| Total related to net income & EPS |  |  | 27 |  |  |  | 0.00 |  |  |  | 2,158 |  |  |  | 0.06 |  |  |  | 13,063 |  |  |  | 0.36 |  |  |  | 11,249 |  |  |  | 0.31 |  |
| Non-GAAP measures |  |  | 20,849 |  |  |  | 0.56 |  |  |  | 13,003 |  |  |  | 0.36 |  |  |  | 55,291 |  |  |  | 1.50 |  |  |  | 41,856 |  |  |  | 1.16 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 37,089 |  |  |  |  |  |  |  | 36,110 |  |  |  |  |  |  |  | 36,743 |  |  |  |  |  |  |  | 35,871 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 37,089 |  |  |  |  |  |  |  | 36,110 |  |  |  |  |  |  |  | 36,743 |  |  |  |  |  |  |  | 35,871 |  |
