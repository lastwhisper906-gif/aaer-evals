# FN note change history — 0001193125-19-028336 → 0001193125-19-139609


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001193125-19-139609:note_history:1]
|  | 16. | Commitments and contingencies |
  (was, 2019-02-05, similarity 0.9737):
[0001193125-19-028336:note_history:1]
| 16. | Commitments and contingencies |

- changed (2019-05-07):
[0001193125-19-139609:note_history:2]
As of March 29, 2019 and June 29, 2018, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business amounting to $1.6 million and $1.5 million, respectively.
  (was, 2019-02-05, similarity 0.9104):
[0001193125-19-028336:note_history:2]
As of December 28, 2018 and June 29, 2018, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business amounting to $1.5 million.

- changed (2019-05-07):
[0001193125-19-139609:note_history:3]
The Company leases a portion of its capital equipment, vehicles, and certain land and buildings for its facilities in Thailand, the Cayman Islands, China, the United States and the United Kingdom under operating lease arrangements that expire in various years through 2023. Rental expense under these operating leases amounted to $1.4 million and $1.3 million for the nine months ended March 29, 2019 and March 30, 2018, respectively.
  (was, 2019-02-05, similarity 0.9001):
[0001193125-19-028336:note_history:3]
The Company leases a portion of its capital equipment, vehicles, and certain land and buildings for its facilities in Thailand, Cayman Islands, China, the United States and the United Kingdom under operating lease arrangements that expire in various years through 2023. Rental expense under these operating leases amounted to $0.9 million and $0.9 million for the six months ended December 28, 2018 and December 29, 2017, respectively.

- changed (2019-05-07):
[0001193125-19-139609:note_history:4]
As of March 29, 2019, the future minimum lease payments due under non-cancelable operating leases during each fiscal year were as follows:
  (was, 2019-02-05, similarity 0.9663):
[0001193125-19-028336:note_history:4]
As of December 28, 2018, the future minimum lease payments due under 
non-cancelable
 operating leases during each fiscal year were as follows:

- changed (2019-05-07):
[0001193125-19-139609:note_history:5]
| (amount in thousands) |  |  |  |
| 2019 (remaining three months) |  | $ | 450 |  |
| 2020 |  |  | 1,739 |  |
| 2021 |  |  | 1,336 |  |
| 2022 |  |  | 1,208 |  |
| 2023 |  |  | 1,182 |  |
| Thereafter |  |  | 227 |  |
| Total minimum operating lease payments |  | $ | 6,142 |  |
  (was, 2019-02-05, similarity 0.7947):
[0001193125-19-028336:note_history:5]
| (amount in thousands) |  |  |  |
| 2019 (remaining six months) |  | $ | 212 |  |
| 2020 |  |  | 397 |  |
| 2021 |  |  | 102 |  |
| Total minimum capital lease payments |  | $ | 711 |  |

- changed (2019-05-07):
[0001193125-19-139609:note_history:6]
As of March 29, 2019, the future minimum lease payments due under non-cancelable capital leases during each fiscal year were as follows:
  (was, 2019-02-05, similarity 0.9658):
[0001193125-19-028336:note_history:6]
As of December 28, 2018, the future minimum lease payments due under non-cancelable capital leases during each fiscal year were as follows:

- added (2019-05-07):
[0001193125-19-139609:note_history:7]
| (amount in thousands) |  |  |  |
| 2019 (remaining three months) |  | $ | 110 |  |
| 2020 |  |  | 410 |  |
| 2021 |  |  | 105 |  |
| Total minimum capital lease payments |  | $ | 625 |  |

- changed (2019-05-07):
[0001193125-19-139609:note_history:8]
As of March 29, 2019, the Company had an outstanding commitment to third parties of $8.6 million.
  (was, 2019-02-05, similarity 0.9503):
[0001193125-19-028336:note_history:8]
As of December 28, 2018, the Company had an outstanding commitment to third parties of $4.6 million.

- removed (2019-05-07):
[0001193125-19-028336:note_history:9]
| (amount in thousands) |  |  |  |
| 2019 (remaining six months) |  | $ | 905 |  |
| 2020 |  |  | 1,724 |  |
| 2021 |  |  | 1,322 |  |
| 2022 |  |  | 1,194 |  |
| 2023 |  |  | 1,168 |  |
| Thereafter |  |  | 225 |  |
| Total minimum operating lease payments |  | $ | 6,538 |  |

- removed (2019-05-07):
[0001193125-19-028336:note_history:10]
On December 23, 2016, the Company entered into an agreement to purchase a parcel of land in Chonburi, Thailand, to support the expansion of the Company’s production in Thailand. The aggregate purchase price was approximately $5.6 million, of which the first installment of $1.1 million was paid by the Company on January 10, 2017 and the remainder was fully paid on December 25, 2017.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001193125-19-139609:note_history:11]
|  | 2. | Accounting policies |
  (was, 2019-02-05, similarity 0.9643):
[0001193125-19-028336:note_history:11]
| 2. | Accounting policies |

- changed (2019-05-07):
[0001193125-19-139609:note_history:12]
The accompanying condensed consolidated financial statements for Fabrinet as of March 29, 2019 and for the three and nine months ended March 29, 2019 and March 30, 2018 include normal recurring adjustments, necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 29, 2018.
  (was, 2019-02-05, similarity 0.9537):
[0001193125-19-028336:note_history:12]
The accompanying condensed consolidated financial statements for Fabrinet as of December 28, 2018 and for the three and six months ended December 28, 2018 and December 29, 2017 includes normal recurring adjustments, necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 
10-K
 for the year ended June 29, 2018.

- changed (2019-05-07):
[0001193125-19-139609:note_history:13]
The balance sheet as of June 29, 2018 has been derived from the audited financial statements at that date but does not include all of the information and footnotes required by U.S. GAAP for complete financial statements. The results for the three and nine months ended March 29, 2019 may not be indicative of results for the year ending June 28, 2019 or any future periods.
  (was, 2019-02-05, similarity 0.9331):
[0001193125-19-028336:note_history:13]
The balance sheet as of June 29, 2018 has been derived from the audited financial statements at that date but does not include all of the information and footnotes required by U.S. GAAP for complete financial statements. The results for the three and six months ended December 28, 2018 may not be indicative of results for the year ending June 28, 2019 or any future periods.

- changed (2019-05-07):
[0001193125-19-139609:note_history:14]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended March 29, 2019 and March 30, 2018 each consisted of 13 weeks. The nine months ended March 29, 2019 and March 30, 2018 each consisted of 39 weeks. Fiscal year 2019 will be comprised of 52 weeks and will end on June 28, 2019.
  (was, 2019-02-05, similarity 0.8019):
[0001193125-19-028336:note_history:14]
The Company utilizes a 
52-53
 week fiscal year ending on the Friday in June closest to June 30. The three months ended December 28, 2018 and December 29, 2017 each consisted of 13 weeks. The six months ended December 28, 2018 and December 29, 2017 each consisted of 26 weeks. Fiscal year 2019 will be comprised of 52 weeks and will end on June 28, 2019.

- changed (2019-05-07):
[0001193125-19-139609:note_history:15]
The cumulative effect adjustment recorded was based on the timing difference of revenue recognition between ASC 605 and ASC 606 related to certain manufacturing contracts with vendor-managed inventory arrangements. Under ASC 605, revenue for such contracts was recognized at the earlier of when the inventory was consumed by the customers or if not consumed, on the expiration of time specified in the contract. On adoption of ASC 606, revenue is recognized when inventory is shipped to customers.
  (was, 2019-02-05, similarity 0.9959):
[0001193125-19-028336:note_history:15]
The cumulative effect adjustment recorded was based on the timing difference of revenue recognition between ASC 605 and ASC 606 related to certain manufacturing contracts with vendor-managed inventory arrangements. Under ASC 605, revenue for such contracts was recognized at the earlier of when the inventory was consumed by the customers or if not consumed, on the expiration of time specified in the contract. On adoption of ASC 606, revenue is recognized when inventory is shipped to the customers.

- changed (2019-05-07):
[0001193125-19-139609:note_history:16]
The following table shows the impact of adoption of ASC 606 on the adoption date of June 29, 2018 on the condensed consolidated balance sheets:
  (was, 2019-02-05, similarity 0.9851):
[0001193125-19-028336:note_history:16]
The following table shows the impact of adoption of ASC 606 on adoption date of June 29, 2018 on the condensed consolidated balance sheets:

- changed (2019-05-07):
[0001193125-19-139609:note_history:17]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | Balance atJune 29, 2018 |  |  | Adjustment |  |  | Balance atJune 30, 2018 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract assets |  | $ | — |  |  | $ | 9,877 | (1) |  | $ | 9,877 |  |
| Inventory, net |  | $ | 257,687 |  |  | $ | (8,672 | )(2) |  | $ | 249,015 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 632,423 |  |  | $ | 1,205 | (3 |  | $ | 633,628 |  |
  (was, 2019-02-05, similarity 0.9646):
[0001193125-19-028336:note_history:17]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | Balance atJune 29, 2018 |  |  | Adjustment |  |  | Balance atJune 30, 2018 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract assets |  | $ | — |  |  | $ | 9,877 | (1) |  | $ | 9,877 |  |
| Inventory, net |  | $ | 257,687 |  |  | $ | (8,672 | )(2) |  | $ | 249,015 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 632,423 |  |  | $ | 1,205 | (3) |  | $ | 633,628 |  |

- changed (2019-05-07):
[0001193125-19-139609:note_history:18]
|  | (1) | Majority of adjustment relates to certain manufacturing contracts with vendor-managed inventory arrangements for which revenue was recognized on shipment. |
  (was, 2019-02-05, similarity 0.9939):
[0001193125-19-028336:note_history:18]
| (1) | Majority of adjustment relates to certain manufacturing contracts with vendor-managed inventory arrangements for which revenue was recognized on shipment. |

- changed (2019-05-07):
[0001193125-19-139609:note_history:19]
|  | (2) | Adjustment relates to reduction of finished goods inventory for certain vendor-managed inventory arrangements. |
  (was, 2019-02-05, similarity 0.9917):
[0001193125-19-028336:note_history:19]
| (2) | Adjustment relates to reduction of finished goods inventory for certain vendor-managed inventory arrangements. |

- changed (2019-05-07):
[0001193125-19-139609:note_history:20]
|  | (3) | Adjustment relates to cumulative effect adjustment upon adoption of ASC 606. |
  (was, 2019-02-05, similarity 0.9881):
[0001193125-19-028336:note_history:20]
| (3) | Adjustment relates to cumulative effect adjustment upon adoption of ASC 606. |

- added (2019-05-07):
[0001193125-19-139609:note_history:21]
In March 2019, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2019-01, “Leases (Topic 842), Codification Improvements.” This ASU provided guidance transition disclosure in the annual period in which a change in accounting principle is made. For public business entities, this update is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its consolidated financial statements.

- changed (2019-05-07):
[0001193125-19-139609:note_history:22]
In August 2018, the FASB issued ASU 2018-13, “Fair Value Measurement (Topic 820), Disclosure Framework – Changes to the Disclosure Requirements for Fair Value Measurement.” This ASU is intended to improve the effectiveness of disclosures in the notes to the financial statements including 1) the development of a framework that promotes consistent decisions by the FASB about disclosure requirements and 2) the appropriate exercise of discretion by reporting entities. The amendment modifies the disclosure requirements on transferring between level 1 and level 2 and valuation processes of level 3 fair value measurements. The amendments in this update are effective for all entities for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company is currently evaluating the impact of the adoption of this update on its consolidated financial 
statements.
  (was, 2019-02-05, similarity 0.9703):
[0001193125-19-028336:note_history:22]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued ASU 
2018-13,
 “Fair Value Measurement (Topic 820), Disclosure Framework – Changes to the Disclosure Requirements for Fair Value Measurement." This ASU is intended to improve the effectiveness of disclosures in the notes to the financial statements including 1) the development of a framework that promotes consistent decisions by the Board about disclosure requirements and 2) the appropriate exercise of discretion by reporting entities. The amendment modifies the disclosure requirements on transferring between level 1 and level 2 and valuation processes of level 3 fair value measurements. The amendments in this update are effective for all entities for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company is currently evaluating the impact of the adoption of this update on its consolidated financial statements.

- changed (2019-05-07):
[0001193125-19-139609:note_history:23]
In January 2017, the FASB issued ASU 2017-04, “Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.” This amendment modified the concept of impairment assessment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. Public companies that are SEC filers should adopt the amendment for annual and any interim goodwill impairment tests in fiscal years beginning after December 15, 2019. Early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017. The Company does not expect the amendments will impact its consolidated financial statements.
  (was, 2019-02-05, similarity 0.9974):
[0001193125-19-028336:note_history:23]
In January 2017, the FASB issued ASU 
2017-04,
 “Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.” This amendment modified the concept of impairment assessment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. Public companies that are SEC filers should adopt the amendment for its annual and any interim goodwill impairment tests in fiscal years beginning after December 15, 2019. Early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017. The Company does not expect the amendments will impact its consolidated financial statements.

- added (2019-05-07):
[0001193125-19-139609:note_history:24]
New Accounting Pronouncements – adopted by the Company

- added (2019-05-07):
[0001193125-19-139609:note_history:25]
In November 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2017-14, “Income Statement – Reporting Comprehensive Income (Topic 220), Revenue Recognition (Topic 605), and Revenue from Contracts with Customers (Topic 606): Amendments to SEC Paragraphs Pursuant to the Staff Accounting Bulletin (“SAB”) No. 116 and SEC Release No. 33-10403”. This ASU amended, superseded and added certain SEC paragraphs in Topic 220, Topic 605 and Topic 606 to reflect the August 2017 issuance of SEC Staff Accounting Bulletin (SAB) 116 and SEC Release No. 33-10403. The SEC staff issued SAB 116 to align its revenue guidance with Accounting Standards Codification (ASC) 606. For public business entities, this update is effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years. Early application is permitted. The Company adopted this standard along with the implementation of ASC 606 effective June 30, 2018 with immaterial impact to the unaudited condensed consolidated financial statements.

- added (2019-05-07):
[0001193125-19-139609:note_history:26]
In September 2017, the FASB issued ASU 2017-13, “Revenue Recognition (Topic 605), Revenue from Contracts with Customers (Topic 606), Leases (Topic 840), and Leases (Topic 842): Amendments to SEC Paragraphs Pursuant to the Staff Announcement at the July 20, 2017 EITF Meeting and Rescission of Prior SEC Staff Announcements and Observer Comments.” The amendment delays the mandatory adoption of Topic 606 and Topic 842 for certain entities, revises the guidance related to performance-based incentive fees in Topic 605 and revises the guidance related to leases in Topic 840 and Topic 842. The revisions to the lease guidance eliminate language specific to certain sale-leaseback arrangements, guarantees of lease residual assets and loans made by lessees to owner-lessors. Also included is an amendment to Topic 842 to retain the guidance in Topic 840 covering the impact of changes in tax rates on investments in leveraged leases. This guidance, which is effective immediately, generally relates to the adoption of Topic 606 and Topic 842. The Company adopted this standard along with the implementation of ASC 606 effective June 30, 2018 with immaterial impact to the unaudited condensed consolidated financial statements.

- added (2019-05-07):
[0001193125-19-139609:note_history:27]
In January 2017, the FASB issued ASU 2017-03, “Accounting Changes and Error Corrections (Topic 250) and Investments – Equity Method and Joint Ventures (Topic 323): Accounting for Investments in Qualified Affordable Housing Projects: Amendments to SEC Paragraphs Pursuant to Staff Announcements at the September 22, 2016 and November 17, 2016 EITF Meetings.” The amendment provides guidance to the Company in relation to the disclosure of the impact that ASU 2014-09, ASU 2016-02 and ASU 2016-13 will have on the Company’s financial statements when adopted. The Company adopted this standard along with the implementation of ASC 606 effective June 30, 2018 with immaterial impact to the unaudited condensed consolidated financial statements.

- added (2019-05-07):
[0001193125-19-139609:note_history:28]
In August 2016, the FASB issued ASU 2016-15, “Classification of Certain Cash Receipts and Cash Payments (a consensus of the Emerging Issues Task Force).” The amendments in this ASU provide guidance on the presentation of certain cash receipts and cash payments in the statement of cash flows in order to reduce diversity in existing practice. The amendments in ASU 2016-15 are effective for public business entities for fiscal years beginning after December 15, 2017, and interim periods within those fiscal years. Early adoption is permitted, including adoption in an interim period. The Company adopt this new update effective June 30, 2018 with no impact to the unaudited condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001193125-19-139609:note_history:29]
| Rate (1) |  | Conditions |  |  | Maturity |  |  | As ofMarch 29,2019 |  |  | As ofJune 29,2018 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current portion of long-term borrowing |  |  | $ | 3,250 |  |  | $ | 3,250 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.50% per annum |  |  | Repayable in quarterlyinstallments |  |  |  | June 2023 |  |  | $ | 61,750 |  |  | $ | 64,188 |  |
|  |  |  |  |  |  |  |  | 61,750 |  |  | 64,188 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (3,250 | ) |  |  | (3,250 | ) |
| Non-current portion of long-term borrowing |  |  |  |  |  |  |  |  |  | $ | 58,500 |  |  | $ | 60,938 |  |
  (was, 2019-02-05, similarity 0.9408):
[0001193125-19-028336:note_history:29]
| Rate (1) |  | Conditions |  | Maturity |  |  | As ofDecember 28,2018 |  |  | As ofJune 29,2018 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |
| Current portion of long-term borrowing |  |  | $ | 3,250 |  |  | $ | 3,250 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.50% per annum |  | Repayable in quarterly installments |  |  | June 2023 |  |  | $ | 63,375 |  |  | $ | 64,188 |  |
|  |  |  |  |  |  |  |  |  | 63,375 |  |  |  | 64,188 |  |
| Less: Current portion |  |  |  |  |  |  |  |  | (3,250 | ) |  |  | (3,250 | ) |
| Non-current portion of long-term borrowings |  |  |  |  |  |  |  | $ | 60,125 |  |  | $ | 60,938 |  |

- changed (2019-05-07):
[0001193125-19-139609:note_history:30]
The movements of long-term borrowing for the nine months ended March 29, 2019 and March 30, 2018 were as follows:
  (was, 2019-02-05, similarity 0.8868):
[0001193125-19-028336:note_history:30]
The movements of long-term borrowings for the six months ended December 28, 2018 and December 29, 2017 were as follows:

- added (2019-05-07):
[0001193125-19-139609:note_history:31]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 29,2019 |  |  | March 30,2018 |  |
| Opening balance |  | $ | 64,188 |  |  | $ | 36,400 |  |
| Repayments during the period |  |  | (2,438 | ) |  |  | (10,200 | ) |
| Closing balance |  | $ | 61,750 |  |  | $ | 26,200 |  |

- changed (2019-05-07):
[0001193125-19-139609:note_history:32]
As of March 29, 2019, future maturities of long-term borrowing during each fiscal year were as follows:
  (was, 2019-02-05, similarity 0.9495):
[0001193125-19-028336:note_history:32]
As of December 28, 2018, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2019-05-07):
[0001193125-19-139609:note_history:33]
| (amount in thousands) |  |  |  |
| 2019 (remaining three months) |  | $ | 813 |  |
| 2020 |  |  | 3,250 |  |
| 2021 |  |  | 3,250 |  |
| 2022 |  |  | 3,250 |  |
| 2023 |  |  | 51,187 |  |
| Total |  | $ | 61,750 |  |
  (was, 2019-02-05, similarity 0.9748):
[0001193125-19-028336:note_history:33]
| (amount in thousands) |  |  |  |
| 2019 (remaining six months) |  | $ | 2,438 |  |
| 2020 |  |  | 3,250 |  |
| 2021 |  |  | 3,250 |  |
| 2022 |  |  | 3,250 |  |
| 2023 |  |  | 51,187 |  |
| Total |  | $ | 63,375 |  |

- changed (2019-05-07):
[0001193125-19-139609:note_history:34]
On June 4, 2018, the Company entered into the Fifth Amendment to the Facility Agreement to (i) reduce the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) extend the termination date of the revolving commitments from May 22, 2019 to June 4, 2023, (iii) refinance the then-existing term loan and revolving loans under the Facility Agreement into a $65.0 million term loan and (iv) reduce the applicable interest rate margins and commitment fees. Term loans must be repaid in quarterly installments, beginning on June 30, 2018, with the remaining outstanding principal and accrued and unpaid interest being due and payable on June 4, 2023. After giving effect to the amendment, $65.0 million aggregate principal amount of term loans and no revolving loans were outstanding under the Facility Agreement. In addition, the Fifth Amendment to the Facility Agreement contains an accordion feature permitting the Company to request an increase in the revolving loan facility to provide up to an aggregate of $200.0 million in additional commitments, subject to customary terms and conditions, and provided that no default or event of default exists at the time of such request. As of March 29, 2019 and June 29, 2
0
18, $61.8 million and $64.2 million aggregate principal amount of term loans, respectively, and no revolving loans were outstanding under the Facility Agreement.
  (was, 2019-02-05, similarity 0.8596):
[0001193125-19-028336:note_history:34]
On June 4, 2018, the Company entered into the Fifth Amendment to the Facility Agreement to (i) reduce the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) extend the termination date of the revolving commitments from May 22, 2019 to June 4, 2023, (iii) refinance the then-existing term loan and revolving loans under the Facility Agreement into a $65.0 million term loan and (iv) reduce the applicable interest rate margins and commitment fees. Term loans must be repaid in quarterly installments, beginning on June 30, 2018, with the remaining outstanding principal and accrued and unpaid interest being due and payable on June 4, 2023. After giving effect to the amendment, $65.0 million aggregate principal amount of term loans and no revolving loans were outstanding under the Facility Agreement as of June 28, 2018. In addition, the Fifth Amendment to the Facility Agreement contains an accordion feature permitting the Company to request an increase in the revolving loan facility to provide up to an aggregate of $200.0 million in additional commitments, subject to customary terms and conditions, and provided that no default or event of default exists at the time of such request. The Fifth Amendment is considered debt extinguishment of which the Company recognized interest expenses of $0.1 million from remaining unamortized debt issuance costs in consolidated statements of operations and comprehensive income. As of December 28, 2018 and June 29, 2018, $63.4 million and $64.2 million aggregate principal amount of term loans and no revolving loans were outstanding under the Facility Agreement.

- changed (2019-05-07):
[0001193125-19-139609:note_history:35]
Fabrinet’s obligations under the Facility Agreement are guaranteed by certain of existing and future material of its direct subsidiaries. In addition, the Facility Agreement is secured by Fabrinet’s present and future accounts receivable, deposit accounts and cash, and a pledge of the capital stock of certain of Fabrinet’s direct subsidiaries. Fabrinet is required to maintain at least $40.0 million of cash, cash equivalents, and marketable securities at financial institutions located in the United States. Further, Fabrinet is required to maintain any of its deposits accounts or securities accounts with balances in excess of $20.0 million in a jurisdiction where a control agreement, or the equivalent under the local law, can be effected.
  (was, 2019-02-05, similarity 0.9926):
[0001193125-19-028336:note_history:35]
Fabrinet’s obligations under the Facility Agreement are guaranteed by certain of its existing and future material direct subsidiaries. In addition, the Facility Agreement is secured by Fabrinet’s present and future accounts receivable, deposit accounts and cash, and a pledge of the capital stock of certain of Fabrinet’s direct subsidiaries. Fabrinet is required to maintain at least $40.0 million of cash, cash equivalents, and marketable securities at financial institutions located in the United States. Further, Fabrinet is required to maintain any of its deposits accounts or securities accounts with balances in excess of $20.0 million in a jurisdiction where a control agreement, or the equivalent under the local law, can be effected.

- changed (2019-05-07):
[0001193125-19-139609:note_history:36]
Moreover, the Fifth Amendment to the Facility Agreement amends customary affirmative and negative covenants. Negative covenants include, among other things, limitations on liens, indebtedness, investments, mergers, sales of assets, changes in the nature of the business, dividends and distributions, affiliate transactions and capital expenditures. The Facility Agreement contains financial covenants requiring Fabrinet to maintain: (1) a minimum tangible net worth of not less than $338.0 million plus 50% of quarterly net income after June 30, 2018, exclusive of quarterly losses; (2) a minimum debt service coverage ratio of not less than 1.50:1.00; (3) a maximum total leverage ratio of not more than 2.50:1.00; and (4) a minimum quick ratio of not less than 1.10:1.00. Each of these financial covenants is calculated on a consolidated basis for the consecutive four fiscal quarter period then ended. As of March 29, 2019, the Company was in compliance with all covenants under the Facility Agreement.
  (was, 2019-02-05, similarity 0.9892):
[0001193125-19-028336:note_history:36]
Moreover, the Fifth Amendment of Facility Agreement amends customary affirmative and negative covenants. Negative covenants include, among other things, limitations on liens, indebtedness, investments, mergers, sales of assets, changes in the nature of the business, dividends and distributions, affiliate transactions and capital expenditures. The Facility Agreement contains financial covenants requiring Fabrinet to maintain: (1) a minimum tangible net worth of not less than $338.0 million plus 50% of quarterly net income after June 30, 2018, exclusive of quarterly losses; (2) a minimum debt service coverage ratio of not less than 1.50:1.00; (3) a maximum total leverage ratio of not more than 2.50:1.00; and (4) a minimum quick ratio of not less than 1.10:1.00. Each of these financial covenants is calculated on a consolidated basis for the consecutive four fiscal quarter period then ended. As of December 28, 2018, the Company was in compliance with all covenants under the Facility Agreement.

- changed (2019-05-07):
[0001193125-19-139609:note_history:37]
On July 25, 2018, the Company entered into the Swap Agreement, which the Company did not designate as a hedging instrument. The Swap Agreement was used to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. The terms of the Swap Agreement effectively convert the floating interest rate of the term loans under the Facility Agreement to the fixed interest rate of 2.86% per annum through maturity in June 2023. The swap transactions are due and settled 
monthly. During the nine months ended March 29, 2019, the Company included a net loss of $0.2 million from the Swap Agreement in interest expense in the condensed consolidated statements of operations and comprehensive income.
  (was, 2019-02-05, similarity 0.8253):
[0001193125-19-028336:note_history:37]
On July 25, 2018, the Company entered into the Swap Agreement, which the Company did not designate as a hedging instrument. The Swap Agreement was used to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. The terms of the Swap Agreement effectively convert the floating interest rate of the term loans under the Facility Agreement to the fixed interest rate of 2.86% per annum through maturity in June 2023. The swap transactions are due and settled monthly.

- changed (2019-05-07):
[0001193125-19-139609:note_history:38]
Undrawn available credit facilities classified by availability period of future borrowing as of March 29, 2019 and June 29, 2018 were as follows:
  (was, 2019-02-05, similarity 0.967):
[0001193125-19-028336:note_history:38]
Undrawn available credit facilities classified by availability period of future borrowing as of December 28, 2018 and June 29, 2018 were as follows:

- changed (2019-05-07):
[0001193125-19-139609:note_history:39]
| (amount in thousands) |  | March 29,2019 |  |  | June 29,2018 |  |
| Expiring within one year |  | $ | — |  |  | $ | — |  |
| Expiring beyond one year |  | $ | 25,000 |  |  | $ | 25,000 |  |
  (was, 2019-02-05, similarity 0.9718):
[0001193125-19-028336:note_history:39]
| (amount in thousands) |  | December 28,2018 |  |  | June 29,2018 |  |
| Expiring within one year |  | $ | — |  |  | $ | — |  |
| Expiring beyond one year |  | $ | 25,000 |  |  | $ | 25,000 |  |

- removed (2019-05-07):
[0001193125-19-028336:note_history:40]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 28,2018 |  |  | December 29,2017 |  |
| Opening balance |  | $ | 64,188 |  |  | $ | 36,400 |  |
| Repayments during the period |  |  | (813 | ) |  |  | (6,800 | ) |
| Closing balance |  | $ | 63,375 |  |  | $ | 29,600 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001193125-19-139609:note_history:41]
The movements of long-term borrowing for the nine months ended March 29, 2019 and March 30, 2018 were as follows:
  (was, 2019-02-05, similarity 0.8868):
[0001193125-19-028336:note_history:41]
The movements of long-term borrowings for the six months ended December 28, 2018 and December 29, 2017 were as follows:

- added (2019-05-07):
[0001193125-19-139609:note_history:42]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 29,2019 |  |  | March 30,2018 |  |
| Opening balance |  | $ | 64,188 |  |  | $ | 36,400 |  |
| Repayments during the period |  |  | (2,438 | ) |  |  | (10,200 | ) |
| Closing balance |  | $ | 61,750 |  |  | $ | 26,200 |  |

- removed (2019-05-07):
[0001193125-19-028336:note_history:43]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 28,2018 |  |  | December 29,2017 |  |
| Opening balance |  | $ | 64,188 |  |  | $ | 36,400 |  |
| Repayments during the period |  |  | (813 | ) |  |  | (6,800 | ) |
| Closing balance |  | $ | 63,375 |  |  | $ | 29,600 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001193125-19-139609:note_history:44]
| Rate (1) |  | Conditions |  |  | Maturity |  |  | As ofMarch 29,2019 |  |  | As ofJune 29,2018 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current portion of long-term borrowing |  |  | $ | 3,250 |  |  | $ | 3,250 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.50% per annum |  |  | Repayable in quarterlyinstallments |  |  |  | June 2023 |  |  | $ | 61,750 |  |  | $ | 64,188 |  |
|  |  |  |  |  |  |  |  | 61,750 |  |  | 64,188 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (3,250 | ) |  |  | (3,250 | ) |
| Non-current portion of long-term borrowing |  |  |  |  |  |  |  |  |  | $ | 58,500 |  |  | $ | 60,938 |  |
  (was, 2019-02-05, similarity 0.9408):
[0001193125-19-028336:note_history:44]
| Rate (1) |  | Conditions |  | Maturity |  |  | As ofDecember 28,2018 |  |  | As ofJune 29,2018 |  |
| Short-term borrowings: |  |  |  |  |  |  |  |  |  |  |
| Current portion of long-term borrowing |  |  | $ | 3,250 |  |  | $ | 3,250 |  |
| Long-term borrowings: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.50% per annum |  | Repayable in quarterly installments |  |  | June 2023 |  |  | $ | 63,375 |  |  | $ | 64,188 |  |
|  |  |  |  |  |  |  |  |  | 63,375 |  |  |  | 64,188 |  |
| Less: Current portion |  |  |  |  |  |  |  |  | (3,250 | ) |  |  | (3,250 | ) |
| Non-current portion of long-term borrowings |  |  |  |  |  |  |  | $ | 60,125 |  |  | $ | 60,938 |  |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001193125-19-139609:note_history:45]
| (amount in thousands) |  | March 29,2019 |  |  | June 29,2018 |  |
| Expiring within one year |  | $ | — |  |  | $ | — |  |
| Expiring beyond one year |  | $ | 25,000 |  |  | $ | 25,000 |  |
  (was, 2019-02-05, similarity 0.9718):
[0001193125-19-028336:note_history:45]
| (amount in thousands) |  | December 28,2018 |  |  | June 29,2018 |  |
| Expiring within one year |  | $ | — |  |  | $ | — |  |
| Expiring beyond one year |  | $ | 25,000 |  |  | $ | 25,000 |  |

- removed (2019-05-07):
[0001193125-19-028336:note_history:46]
Undrawn available credit facilities classified by availability period of future borrowing as of December 28, 2018 and June 29, 2018 were as follows:


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001193125-19-139609:note_history:47]
As of March 29, 2019, future maturities of long-term borrowing during each fiscal year were as follows:
  (was, 2019-02-05, similarity 0.9495):
[0001193125-19-028336:note_history:47]
As of December 28, 2018, future maturities of long-term borrowings during each fiscal year were as follows:

- changed (2019-05-07):
[0001193125-19-139609:note_history:48]
| (amount in thousands) |  |  |  |
| 2019 (remaining three months) |  | $ | 813 |  |
| 2020 |  |  | 3,250 |  |
| 2021 |  |  | 3,250 |  |
| 2022 |  |  | 3,250 |  |
| 2023 |  |  | 51,187 |  |
| Total |  | $ | 61,750 |  |
  (was, 2019-02-05, similarity 0.9748):
[0001193125-19-028336:note_history:48]
| (amount in thousands) |  |  |  |
| 2019 (remaining six months) |  | $ | 2,438 |  |
| 2020 |  |  | 3,250 |  |
| 2021 |  |  | 3,250 |  |
| 2022 |  |  | 3,250 |  |
| 2023 |  |  | 51,187 |  |
| Total |  | $ | 63,375 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001193125-19-139609:note_history:49]
| (amount in thousands) |  | Three MonthsEndedMarch 29,2019 |  |  | As a % of TotalRevenues |  |  | Nine MonthsEndedMarch 29,2019 |  |  | As a % of TotalRevenues |  |
| North America |  | $ | 195,504 |  |  |  | 49.0 | % |  | $ | 558,028 |  |  |  | 47.3 | % |
| Asia-Pacific |  |  | 151,263 |  |  |  | 37.9 |  |  |  | 469,921 |  |  |  | 39.9 |  |
| Europe |  |  | 52,184 |  |  |  | 13.1 |  |  |  | 151,259 |  |  |  | 12.8 |  |
|  |  | $ | 398,951 |  |  |  | 100.0 | % |  | $ | 1,179,208 |  |  |  | 100.0 | % |
  (was, 2019-02-05, similarity 0.9239):
[0001193125-19-028336:note_history:49]
| (amount in thousands) |  | Three MonthsEndedDecember 28,2018 |  |  | As a % of TotalRevenues |  |  | Six MonthsEndedDecember 28,2018 |  |  | As a % of TotalRevenues |  |
| North America |  | $ | 182,698 |  |  |  | 45.3 | % |  | $ | 362,524 |  |  |  | 46.5 | % |
| Asia-Pacific |  |  | 166,711 |  |  |  | 41.4 |  |  |  | 318,658 |  |  |  | 40.8 |  |
| Europe |  |  | 53,671 |  |  |  | 13.3 |  |  |  | 99,075 |  |  |  | 12.7 |  |
|  |  | $ | 403,080 |  |  |  | 100.0 | % |  | $ | 780,257 |  |  |  | 100.0 | % |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001193125-19-139609:note_history:50]
|  | 3. | Revenues |
  (was, 2019-02-05, similarity 0.9412):
[0001193125-19-028336:note_history:50]
| 3. | Revenues |

- changed (2019-05-07):
[0001193125-19-139609:note_history:51]
The Company manufactures products that are customized to customers’ specifications; however, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for overtime recognition are not met. On the evaluation of the contracts, the Company identified that it did not have contractual rights to bill profit for work in progress in the event of a contract termination which is expected to be infrequent. Further, in limited circumstances, substantive acceptance by the customer exists which results in the deferral of revenue until acceptance is formally received from the customer. Judgment may be required in determining if the acceptance clause is substantive.
  (was, 2019-02-05, similarity 0.9987):
[0001193125-19-028336:note_history:51]
The Company manufactures products that are customized to customers’ specifications, however, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for overtime recognition are not met. On the evaluation of the contracts, the Company identified that it did not have contractual rights to bill profit for work in progress in the event of a contract termination which is expected to be infrequent. Further, in limited circumstances, substantive acceptance by the customer exists which results in the deferral of revenue until acceptance is formally received from the customer. Judgment may be required in determining if the acceptance clause is substantive.

- changed (2019-05-07):
[0001193125-19-139609:note_history:52]
A contract asset is recognized when the Company has recognized revenues, but not yet an invoice for payment. Contract assets are classified separately on the condensed consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. The following table summarizes the activity in the Company’s contract assets during the nine-month period ended March 29, 2019:
  (was, 2019-02-05, similarity 0.9752):
[0001193125-19-028336:note_history:52]
A contract asset is recognized when the Company has recognized revenues, but not yet an invoice for payment. Contract assets are classified separately on the condensed consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. The following table summarizes the activity in the Company’s contract assets during the 
six-month
 period ended December 28, 2018:

- changed (2019-05-07):
[0001193125-19-139609:note_history:53]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 30, 2018 |  | $ | — |  |
| Cumulative effect adjustment upon adoption of ASC 606 |  |  | 9,877 |  |
| Revenue recognized |  |  | 89,131 |  |
| Amounts collected or invoiced |  |  | (88,465 | ) |
| Ending balance, March 29, 2019 |  | $ | 10,543 |  |
  (was, 2019-02-05, similarity 0.9236):
[0001193125-19-028336:note_history:53]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 30, 2018 |  | $ | — |  |
| Cumulative effect adjustment at June 30, 2018 |  |  | 9,877 |  |
| Revenue recognized |  |  | 58,484 |  |
| Amounts collected or invoiced |  |  | (55,025 | ) |
| Ending balance, December 28, 2018 |  | $ | 13,336 |  |

- changed (2019-05-07):
[0001193125-19-139609:note_history:54]
The Company continually evaluates whether advance payment arrangements with customers result in the recognition of contract liabilities. No such liabilities existed as of March 29, 2019 or June 29, 2018. Separately, accounts receivable, net, represents receivables from contracts with customers.
  (was, 2019-02-05, similarity 0.9755):
[0001193125-19-028336:note_history:54]
The Company continually evaluates whether advanced payment arrangements with customers result in the recognition of contract liabilities. No such liabilities existed as of December 28, 2018 or June 29, 2018. Separately, accounts receivable, net, represents receivables from contracts with customers.

- changed (2019-05-07):
[0001193125-19-139609:note_history:55]
The Company has elected the practical expedient to recognize the incremental costs of obtaining a contract as an expense when incurred if the amortization period of the asset that the Company otherwise would have recognized is one year or less. During the three and nine months ended March 29, 2019, the Company did not have any incremental costs of obtaining a contract.
  (was, 2019-02-05, similarity 0.9344):
[0001193125-19-028336:note_history:55]
The Company has elected the practical expedient to recognize the incremental costs of obtaining a contract as an expense when incurred if the amortization period of the asset that the Company otherwise would have recognized is one year or less. During the three and six months ended December 28, 2018, the Company did not have any incremental costs of obtaining a contract.

- changed (2019-05-07):
[0001193125-19-139609:note_history:56]
Shipping costs billed to customers are recorded as revenue. Shipping and handling expense related to costs incurred to deliver product are recognized within cost of goods sold. The Company accounts for shipping and handling activities that occur after control has transferred as a fulfillment cost, as opposed to a separate performance obligation, and the costs of shipping and handling are recognized concurrently with the related revenue.
  (was, 2019-02-05, similarity 0.8896):
[0001193125-19-028336:note_history:56]
Shipping costs billed to customers are recorded as revenue. Shipping and handling expense related to costs incurred to deliver product are recognized within cost of goods sold. The Company accounts for shipping and handling activities that occur after control has transferred as a fulfillment cost as opposed to a separate performance obligation, and the costs of shipping and handling are recognized concurrently with the related revenue.

- changed (2019-05-07):
[0001193125-19-139609:note_history:57]
In accordance with the new revenue standard requirements, the disclosure of the impact of adoption of ASC 606 on the Company’s condensed consolidated statements of operations and comprehensive income for the three and nine months ended March 29, 2019 and condensed consolidated balance sheets as of March 29, 2019 was as follows:
  (was, 2019-02-05, similarity 0.7418):
[0001193125-19-028336:note_history:57]
In accordance with the new revenue standard requirements, the disclosure of the impact of adoption
 of ASC 606 
 on the Company’s condensed consolidated statements of operations and comprehensive income for the three and six months ended December 28, 2018 and condensed consolidated balance sheets as of December 28, 2018 was as follows:

- changed (2019-05-07):
[0001193125-19-139609:note_history:58]
Condensed Consolidated Statement of Operations and Comprehensive Income (Unaudited)
  (was, 2019-02-05, similarity 0.7132):
[0001193125-19-028336:note_history:58]
Condensed Consolidated Statement of Operations

- changed (2019-05-07):
[0001193125-19-139609:note_history:59]
Three and Nine Months Ended March 29, 2019
  (was, 2019-02-05, similarity 0.8158):
[0001193125-19-028336:note_history:59]
Three and Six Months Ended December 28, 2018

- changed (2019-05-07):
[0001193125-19-139609:note_history:60]
|  |  | Impact of Adopting ASC 606 (Three months) |  |  | Impact of Adopting ASC 606 (Nine months) |  |
| (amount in thousands) |  | As Reported |  |  | Adjustment |  |  | Balance withoutASC 606 Adoption |  |  | As Reported |  |  | Adjustment |  |  | Balance withoutASC 606 Adoption |  |
| Revenues |  | $ | 398,951 |  |  | $ | 2,793 | (1) |  | $ | 401,744 |  |  | $ | 1,179,208 |  |  | $ | (666 | )(1) |  | $ | 1,178,542 |  |
| Cost of revenues |  | $ | (352,193 | ) |  | $ | (2,699 | )(2) |  | $ | (354,892 | ) |  | $ | (1,046,610 | ) |  | $ | 341 | (2) |  | $ | (1,046,269 | ) |
| Gross profit |  | $ | 46,758 |  |  | $ | 94 | (3) |  | $ | 46,852 |  |  | $ | 132,598 |  |  | $ | (325 | )(3) |  | $ | 132,273 |  |
| Net income |  | $ | 28,635 |  |  | $ | 94 | (3) |  | $ | 28,729 |  |  | $ | 87,998 |  |  | $ | (325 | )(3) |  | $ | 87,673 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.78 |  |  | $ | 0.00 |  |  | $ | 0.78 |  |  | $ | 2.39 |  |  | $ | (0.01 | ) |  | $ | 2.38 |  |
| Diluted |  | $ | 0.76 |  |  | $ | 0.00 |  |  | $ | 0.76 |  |  | $ | 2.35 |  |  | $ | (0.01 | ) |  | $ | 2.34 |  |
  (was, 2019-02-05, similarity 0.8819):
[0001193125-19-028336:note_history:60]
|  |  | Impact of Adopting ASC 606 (Three months) |  |  | Impact of Adopting ASC 606 (Six months) |  |
| (amount in thousands) |  | As Reported |  |  | Adjustment |  |  | Balance without ASC606 Adoption |  |  | As Reported |  |  | Adjustment |  |  | Balance without ASC606 Adoption |  |
| Revenues |  | $ | 403,080 |  |  | $ | (3,179 | )(1) |  | $ | 399,901 |  |  | $ | 780,257 |  |  | $ | (3,459 | )(1) |  | $ | 776,798 |  |
| Cost of revenues |  | $ | (357,516 | ) |  | $ | 2,791 | (2) |  | $ | (354,725 | ) |  | $ | (694,417 | ) |  | $ | 3,040 | (2) |  | $ | (691,377 | ) |
| Gross profit |  | $ | 45,564 |  |  | $ | (388 | )(3) |  | $ | 45,176 |  |  | $ | 85,840 |  |  | $ | (419 | )(3) |  | $ | 85,421 |  |
| Net income |  | $ | 31,513 |  |  | $ | (388 | )(3) |  | $ | 31,125 |  |  | $ | 59,363 |  |  | $ | (419 | )(3) |  | $ | 58,944 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.86 |  |  | $ | (0.02 | ) |  | $ | (0.84 | ) |  | $ | 1.62 |  |  | $ | (0.02 | ) |  | $ | 1.60 |  |
| Diluted |  | $ | 0.84 |  |  | $ | (0.01 | ) |  | $ | (0.83 | ) |  | $ | 1.59 |  |  | $ | (0.01 | ) |  | $ | 1.58 |  |

- changed (2019-05-07):
[0001193125-19-139609:note_history:61]
|  | (1) | Adjustment relates to certain manufacturing contracts with vendor-managed inventory arrangements for which revenue was recognized at shipping. |
  (was, 2019-02-05, similarity 0.9935):
[0001193125-19-028336:note_history:61]
| (1) | Adjustment relates to certain manufacturing contracts with vendor-managed inventory arrangements for which revenue was recognized at shipping. |

- added (2019-05-07):
[0001193125-19-139609:note_history:62]
Condensed

- changed (2019-05-07):
[0001193125-19-139609:note_history:63]
Consolidated Balance Sheets (Unaudited)
  (was, 2019-02-05, similarity 0.7105):
[0001193125-19-028336:note_history:63]
Condensed Consolidated Balance Sheets

- changed (2019-05-07):
[0001193125-19-139609:note_history:64]
As of March 29, 2019
  (was, 2019-02-05, similarity 0.7273):
[0001193125-19-028336:note_history:64]
As of December 28, 2018

- changed (2019-05-07):
[0001193125-19-139609:note_history:65]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | As Reported |  |  | Adjustments |  |  | Balancewithout ASC606 Adoption |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract assets |  | $ | 10,543 |  |  | $ | (10,543 | )(1) |  | $ | — |  |
| Inventory, net |  | $ | 285,431 |  |  | $ | 9,013 | (2) |  | $ | 294,444 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 721,626 |  |  | $ | (1,530 | )(3) |  | $ | 720,096 |  |
  (was, 2019-02-05, similarity 0.9856):
[0001193125-19-028336:note_history:65]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | As Reported |  |  | Adjustments |  |  | Balance withoutASC 606Adoption |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract assets |  | $ | 13,336 |  |  | $ | (13,336 | )(1) |  | $ | — |  |
| Inventory, net |  | $ | 277,893 |  |  | $ | 11,712 | (2) |  | $ | 289,605 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 692,991 |  |  | $ | (1,624 | )(3) |  | $ | 691,367 |  |

- changed (2019-05-07):
[0001193125-19-139609:note_history:66]
Total revenues are attributed to a particular geographic area based on the bill-to-location of customers. The Company operates primarily in three geographic regions: North America, Asia-Pacific and Europe. The following table presents total revenues by geographic regions:
  (was, 2019-02-05, similarity 0.7991):
[0001193125-19-028336:note_history:66]
the customers. The Company operates primarily in three geographic regions: North America, Asia-Pacific and Europe. The following table presents total revenues by geographic regions:

- changed (2019-05-07):
[0001193125-19-139609:note_history:67]
| (amount in thousands) |  | Three MonthsEndedMarch 29,2019 |  |  | As a % of TotalRevenues |  |  | Nine MonthsEndedMarch 29,2019 |  |  | As a % of TotalRevenues |  |
| North America |  | $ | 195,504 |  |  |  | 49.0 | % |  | $ | 558,028 |  |  |  | 47.3 | % |
| Asia-Pacific |  |  | 151,263 |  |  |  | 37.9 |  |  |  | 469,921 |  |  |  | 39.9 |  |
| Europe |  |  | 52,184 |  |  |  | 13.1 |  |  |  | 151,259 |  |  |  | 12.8 |  |
|  |  | $ | 398,951 |  |  |  | 100.0 | % |  | $ | 1,179,208 |  |  |  | 100.0 | % |
  (was, 2019-02-05, similarity 0.9239):
[0001193125-19-028336:note_history:67]
| (amount in thousands) |  | Three MonthsEndedDecember 28,2018 |  |  | As a % of TotalRevenues |  |  | Six MonthsEndedDecember 28,2018 |  |  | As a % of TotalRevenues |  |
| North America |  | $ | 182,698 |  |  |  | 45.3 | % |  | $ | 362,524 |  |  |  | 46.5 | % |
| Asia-Pacific |  |  | 166,711 |  |  |  | 41.4 |  |  |  | 318,658 |  |  |  | 40.8 |  |
| Europe |  |  | 53,671 |  |  |  | 13.3 |  |  |  | 99,075 |  |  |  | 12.7 |  |
|  |  | $ | 403,080 |  |  |  | 100.0 | % |  | $ | 780,257 |  |  |  | 100.0 | % |

- changed (2019-05-07):
[0001193125-19-139609:note_history:68]
| (amount in thousands) |  | Three MonthsEndedMarch 29,2019 |  |  | As a % of TotalRevenues |  |  | Nine MonthsEndedMarch 29,2019 |  |  | As a % of TotalRevenues |  |
| Optical communications |  | $ | 298,139 |  |  |  | 74.7 | % |  | $ | 884,454 |  |  |  | 75.0 | % |
| Lasers, sensors and other |  |  | 100,812 |  |  |  | 25.3 |  |  |  | 294,754 |  |  |  | 25.0 |  |
|  |  | $ | 398,951 |  |  |  | 100.0 | % |  | $ | 1,179,208 |  |  |  | 100.0 | % |
  (was, 2019-02-05, similarity 0.9175):
[0001193125-19-028336:note_history:68]
| (amount in thousands) |  | Three MonthsEndedDecember 28,2018 |  |  | As a % of TotalRevenues |  |  | Six MonthsEndedDecember 28,2018 |  |  | As a % of TotalRevenues |  |
| Optical communications |  | $ | 305,547 |  |  |  | 75.8 | % |  | $ | 586,315 |  |  |  | 75.1 | % |
| Lasers, sensors and other |  |  | 97,533 |  |  |  | 24.2 |  |  |  | 193,942 |  |  |  | 24.9 |  |
|  |  | $ | 403,080 |  |  |  | 100.0 | % |  | $ | 780,257 |  |  |  | 100.0 | % |

- removed (2019-05-07):
[0001193125-19-028336:note_history:69]
:

- removed (2019-05-07):
[0001193125-19-028336:note_history:70]
Total revenues are attributed to a particular geographic area based on

- removed (2019-05-07):
[0001193125-19-028336:note_history:71]
the bill-to-location of


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2019-05-07):
[0001193125-19-139609:note_history:72]
| 18. | Subsequent events |

- added (2019-05-07):
[0001193125-19-139609:note_history:73]
On December 13, 2018, Thailand’s National Legislative Assembly (NLA) passed an amendment bill to the Thai Labour Protection Act B.E. 2541 (1998) to increase the required severance payment compensation for employees with 20 or more years of service from 300 days of wage to 400 days of wage. The law became effective on May 4, 2019. The Company has engaged an independent actuary to consider the effect of this change.

- added (2019-05-07):
[0001193125-19-139609:note_history:74]
In

- added (2019-05-07):
[0001193125-19-139609:note_history:75]
May 2019

- added (2019-05-07):
[0001193125-19-139609:note_history:76]
, Fabrinet’s board of directors approved the repurchase of up to an additional $50.0 million of Fabrinet’s outstanding ordinary shares, bringing the aggregate authorization under Fabrinet’s existing share repurchase program to $110.0 million.
