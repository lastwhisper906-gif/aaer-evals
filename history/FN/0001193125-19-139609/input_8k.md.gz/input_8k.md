# FN 8-K — 0001193125-19-138338 filed 2019-05-06

## item codes, every 8-K on or before 2019-05-07

- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2019-05-07

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-19-138338:8k_2_02:1]
EX-99.1
3
d767787dex991.htm
EX-99.1

[0001193125-19-138338:8k_2_02:2]
EX-99.1

[0001193125-19-138338:8k_2_02:3]
Exhibit 99.1

[0001193125-19-138338:8k_2_02:4]
Fabrinet Announces Third Quarter Fiscal Year 2019 Financial Results

[0001193125-19-138338:8k_2_02:5]
|  | • |  | Revenue and EPS Exceed Guidance Ranges |

[0001193125-19-138338:8k_2_02:6]
|  | • |  | Gross Margin Increases to Highest Level in Seven Quarters |

[0001193125-19-138338:8k_2_02:7]
|  | • |  | Year-to-Date Cash Flow From Operations of $105.5 Million Up 17% From Year-Ago Period |

[0001193125-19-138338:8k_2_02:8]
BANGKOK, Thailand –
May 6, 2019 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products,
today announced its financial results for its third quarter ended March 29, 2019.

[0001193125-19-138338:8k_2_02:9]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “We
exceeded our guidance for revenue and profitability in the third quarter on both an ASC 605 and ASC 606 basis, primarily due to increasing demand from the telecom market. In addition, we were pleased to see
non-GAAP gross margins return to within our target range. With new business wins and strong customer relationships, we are optimistic that we can deliver a strong fourth quarter resulting in a record year for
revenue and profitability.”

[0001193125-19-138338:8k_2_02:10]
Third Quarter Fiscal Year 2019 Financial Highlights

[0001193125-19-138338:8k_2_02:11]
As of the first quarter of fiscal 2019, Fabrinet is reporting results under the new revenue recognition standard Accounting Standards Codification Topic 606
(“ASC 606”), using the modified retrospective method. Financial results for reporting periods prior to fiscal year 2019 are presented as previously disclosed in conformity with the old revenue recognition standard Accounting Standards
Codification Topic 605 (“ASC 605”). A reconciliation to ASC 605 is included at the end of this press release.

[0001193125-19-138338:8k_2_02:12]
GAAP Results

[0001193125-19-138338:8k_2_02:13]
|  | • |  | Revenue for the third quarter of fiscal year 2019 was $399.0 million, compared to revenue of $332.2 million for the comparable period in fiscal year 2018. |

[0001193125-19-138338:8k_2_02:14]
|  | • |  | GAAP net income for the third quarter of fiscal year 2019 was $28.6 million, compared to GAAP net income of $21.1 million for the third quarter of fiscal year 2018. GAAP net income for the third quarter of fiscal year 2019 included a foreign exchange loss of ($3.1) million, or ($0.08) per diluted share, compared to a foreign exchange loss of ($2.4) million, or ($0.06) per diluted share, for the third quarter of fiscal year 2018. |

[0001193125-19-138338:8k_2_02:15]
|  | • |  | GAAP net income per diluted share for the third quarter of fiscal year 2019 was $0.76, compared to GAAP net income per diluted share of $0.55 for the third quarter of fiscal year 2018. |

[0001193125-19-138338:8k_2_02:16]
|  | • |  | Cash flow from operations for the first three quarters of fiscal 2019 was $105.5 million, compared to $89.8 million for the first three quarters of fiscal 2018. |

[0001193125-19-138338:8k_2_02:17]
Non-GAAP Results

[0001193125-19-138338:8k_2_02:18]
|  | • |  | Non-GAAP net income for the third quarter of fiscal year 2019 was $34.3 million, compared to non-GAAP net income of $26.9 million for the third quarter of fiscal year 2018. Non-GAAP net income for the third quarter of fiscal year 2019 included a foreign exchange loss of ($3.1) million, or ($0.08) per diluted share, compared to a foreign exchange loss of ($2.4) million, or ($0.06) per diluted share, for the third quarter of fiscal year 2018. |

[0001193125-19-138338:8k_2_02:19]
|  | • |  | Non-GAAP net income per diluted share for the third quarter of fiscal year 2019 was $0.92, compared to non-GAAP net income per diluted share of $0.71 for the same period in fiscal year 2018. |

[0001193125-19-138338:8k_2_02:20]
Share Repurchase Program Update

[0001193125-19-138338:8k_2_02:21]
During the third quarter of fiscal 2019, Fabrinet repurchased 100,000 ordinary shares at an average price of $53.78. On May 1, 2019, Fabrinet’s Board
of Directors approved the repurchase of up to an additional $50.0 million of Fabrinet’s ordinary shares, bringing the aggregate authorization under Fabrinet’s existing share repurchase program to $110.0 million, with
$62.2 million currently remaining.

[0001193125-19-138338:8k_2_02:22]
Business Outlook

[0001193125-19-138338:8k_2_02:23]
The guidance provided below for the fourth quarter of fiscal 2019 is based on ASC 605; however, we will report revenues for such quarter based on ASC 606. As
of the first quarter of fiscal 2019, Fabrinet is reporting results under ASC 606, which it is adopting for fiscal year 2019 on a modified retrospective method. A reconciliation to ASC 605 is included at the end of this press release.

[0001193125-19-138338:8k_2_02:24]
Based on information available as of May 6, 2019, Fabrinet is issuing guidance for the fourth quarter of its fiscal year 2019 ending June 28, 2019,
as follows:

[0001193125-19-138338:8k_2_02:25]
|  | • |  | Fabrinet expects fourth quarter revenue to be in the range of $396 million to $404 million. |

[0001193125-19-138338:8k_2_02:26]
|  | • |  | GAAP net income per diluted share is expected to be in the range of $0.78 to $0.82, based on approximately 37.6 million fully diluted shares outstanding. |

[0001193125-19-138338:8k_2_02:27]
|  | • |  | Non-GAAP net income per diluted share is expected to be in the range of $0.92 to $0.96, based on approximately 37.6 million fully diluted shares outstanding. |

[0001193125-19-138338:8k_2_02:28]
Conference Call Information

[0001193125-19-138338:8k_2_02:29]
| What: |  | Fabrinet Third Quarter Fiscal Year 2019 Financial Results Call |
| When: |  | Monday, May 6, 2019 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic |
|  |  | (253) 237-1137, international |
|  |  | Passcode: 1558338 |
| Replay: |  | (855) 859-2056, domestic |
|  |  | (404) 537-3406, international |
|  |  | Passcode: 1558338 |
| Webcast: |  | http://investor.fabrinet.com/ (live and replay) |

[0001193125-19-138338:8k_2_02:30]
This press release and any other information related to the call will also be posted on Fabrinet’s website at
http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-19-138338:8k_2_02:31]
About Fabrinet

[0001193125-19-138338:8k_2_02:32]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original
equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and
electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of
high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China and the United Kingdom. For more information
visit: www.fabrinet.com.

[0001193125-19-138338:8k_2_02:33]
Forward-Looking Statements

[0001193125-19-138338:8k_2_02:34]
Use of Non-GAAP Financials

[0001193125-19-138338:8k_2_02:35]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful
supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; depreciation of fair value uplift; severance payments; executive search
expenses; amortization of intangibles; business combination expenses; amortization of debt issuance costs; restructuring charges; and ASC 606 adjustments. We have excluded these items in order to enhance investors’ understanding of our
underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial
measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001193125-19-138338:8k_2_02:36]
These non-GAAP financial measures are used to: (1) measure company performance against historical results,
(2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001193125-19-138338:8k_2_02:37]
SOURCE: Fabrinet

[0001193125-19-138338:8k_2_02:38]
Investor Contact:

[0001193125-19-138338:8k_2_02:39]
Garo Toomajanian

[0001193125-19-138338:8k_2_02:40]
ir@fabrinet.com

[0001193125-19-138338:8k_2_02:41]
FABRINET

[0001193125-19-138338:8k_2_02:42]
CONDENSED CONSOLIDATED BALANCE SHEETS (unaudited)

[0001193125-19-138338:8k_2_02:43]
| (in thousands of U.S. dollars, except share data) |  | March 29,2019 |  |  | June 29,2018 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 166,407 |  |  | $ | 158,102 |  |
| Restricted cash in connection with business acquisition |  |  | — |  |  |  | 3,331 |  |
| Short-term investments |  |  | 242,484 |  |  |  | 174,269 |  |
| Trade accounts receivable, net |  |  | 265,110 |  |  |  | 246,912 |  |
| Contract assets |  |  | 10,543 |  |  |  | — |  |
| Inventory, net |  |  | 285,431 |  |  |  | 257,687 |  |
| Prepaid expenses |  |  | 12,299 |  |  |  | 8,061 |  |
| Other current assets |  |  | 5,236 |  |  |  | 5,948 |  |
| Total current assets |  |  | 987,510 |  |  |  | 854,310 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 209,084 |  |  |  | 219,640 |  |
| Intangibles, net |  |  | 4,112 |  |  |  | 4,880 |  |
| Goodwill |  |  | 3,823 |  |  |  | 3,828 |  |
| Deferred tax assets |  |  | 5,734 |  |  |  | 5,280 |  |
| Other non-current assets |  |  | 354 |  |  |  | 80 |  |
| Total non-current assets |  |  | 223,107 |  |  |  | 233,708 |  |
| Total Assets |  | $ | 1,210,617 |  |  | $ | 1,088,018 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Bank borrowings |  | $ | 3,250 |  |  | $ | 3,250 |  |
| Trade accounts payable |  |  | 256,282 |  |  |  | 220,159 |  |
| Capital lease liability, current portion |  |  | 417 |  |  |  | 451 |  |
| Income tax payable |  |  | 2,651 |  |  |  | 709 |  |
| Deferred liability in connection with business acquisition |  |  | — |  |  |  | 3,331 |  |
| Accrued payroll, bonus and related expenses |  |  | 17,900 |  |  |  | 13,476 |  |
| Accrued expenses |  |  | 8,772 |  |  |  | 9,013 |  |
| Other payables |  |  | 16,370 |  |  |  | 19,728 |  |
| Total current liabilities |  |  | 305,642 |  |  |  | 270,117 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term loan from bank |  |  | 58,500 |  |  |  | 60,938 |  |
| Deferred tax liability |  |  | 3,177 |  |  |  | 2,284 |  |
| Capital lease liability, non-current portion |  |  | 209 |  |  |  | 516 |  |
| Severance liabilities |  |  | 11,837 |  |  |  | 10,162 |  |
| Other non-current liabilities |  |  | 2,364 |  |  |  | 3,062 |  |
| Total non-current liabilities |  |  | 76,087 |  |  |  | 76,962 |  |
| Total Liabilities |  |  | 381,729 |  |  |  | 347,079 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of March 29, 2019 and June 29, 2018) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 38,216,231 shares and 37,723,733 shares issued; and 36,827,128 shares and 36,434,630 shares outstanding as of March 29, 2019 and June 29, 2018, respectively) |  |  | 382 |  |  |  | 377 |  |
| Additional paid-in capital |  |  | 154,738 |  |  |  | 151,797 |  |
| Less: Treasury shares (1,389,103 shares and 1,289,103 shares as of March 29, 2019 and June 29, 2018, respectively) |  |  | (47,779 | ) |  |  | (42,401 | ) |
| Accumulated other comprehensive loss |  |  | (79 | ) |  |  | (1,257 | ) |
| Retained earnings |  |  | 721,626 |  |  |  | 632,423 |  |
| Total Shareholders’ Equity |  |  | 828,888 |  |  |  | 740,939 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 1,210,617 |  |  | $ | 1,088,018 |  |

[0001193125-19-138338:8k_2_02:44]
FABRINET

[0001193125-19-138338:8k_2_02:45]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-19-138338:8k_2_02:46]
AND COMPREHENSIVE INCOME (unaudited)

[0001193125-19-138338:8k_2_02:47]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (in thousands of U.S. dollars, except per share amounts) |  | March 29,2019 |  |  | March 30,2018 |  |  | March 29,2019 |  |  | March 30,2018 |  |
| Revenues |  | $ | 398,951 |  |  | $ | 332,213 |  |  | $ | 1,179,208 |  |  | $ | 1,026,598 |  |
| Cost of revenues |  |  | (352,193 | ) |  |  | (295,280 | ) |  |  | (1,046,610 | ) |  |  | (912,167 | ) |
| Gross profit |  |  | 46,758 |  |  |  | 36,933 |  |  |  | 132,598 |  |  |  | 114,431 |  |
| Selling, general and administrative expenses |  |  | (14,132 | ) |  |  | (12,418 | ) |  |  | (41,296 | ) |  |  | (41,253 | ) |
| Expenses related to reduction in workforce |  |  | (323 | ) |  |  | — |  |  |  | (727 | ) |  |  | (1,776 | ) |
| Operating income |  |  | 32,303 |  |  |  | 24,515 |  |  |  | 90,575 |  |  |  | 71,402 |  |
| Interest income |  |  | 2,144 |  |  |  | 1,149 |  |  |  | 4,770 |  |  |  | 2,554 |  |
| Interest expense |  |  | (1,423 | ) |  |  | (820 | ) |  |  | (3,673 | ) |  |  | (2,499 | ) |
| Foreign exchange loss, net |  |  | (3,055 | ) |  |  | (2,428 | ) |  |  | (408 | ) |  |  | (5,710 | ) |
| Other income, net |  |  | 159 |  |  |  | 91 |  |  |  | 798 |  |  |  | 438 |  |
| Income before income taxes |  |  | 30,128 |  |  |  | 22,507 |  |  |  | 92,062 |  |  |  | 66,185 |  |
| Income tax expense |  |  | (1,493 | ) |  |  | (1,454 | ) |  |  | (4,064 | ) |  |  | (4,786 | ) |
| Net income |  |  | 28,635 |  |  |  | 21,053 |  |  |  | 87,998 |  |  |  | 61,399 |  |
| Other comprehensive income (loss), net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities |  |  | 513 |  |  |  | (616 | ) |  |  | 1,399 |  |  |  | (1,048 | ) |
| Change in net unrealized loss on derivative instruments |  |  | (1 | ) |  |  | — |  |  |  | (2 | ) |  |  | (1 | ) |
| Change in foreign currency translation adjustment |  |  | 486 |  |  |  | 789 |  |  |  | (219 | ) |  |  | 1,358 |  |
| Total other comprehensive income, net of tax |  |  | 998 |  |  |  | 173 |  |  |  | 1,178 |  |  |  | 309 |  |
| Net comprehensive income |  | $ | 29,633 |  |  | $ | 21,226 |  |  | $ | 89,176 |  |  | $ | 61,708 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.78 |  |  | $ | 0.56 |  |  | $ | 2.39 |  |  | $ | 1.64 |  |
| Diluted |  | $ | 0.76 |  |  | $ | 0.55 |  |  | $ | 2.35 |  |  | $ | 1.61 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |
| Basic |  |  | 36,891 |  |  |  | 37,275 |  |  |  | 36,786 |  |  |  | 37,400 |  |
| Diluted |  |  | 37,539 |  |  |  | 38,055 |  |  |  | 37,383 |  |  |  | 38,125 |  |

[0001193125-19-138338:8k_2_02:48]
FABRINET

[0001193125-19-138338:8k_2_02:49]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited)

[0001193125-19-138338:8k_2_02:50]
|  |  | Nine Months Ended |  |
| (in thousands of U.S. dollars) |  | March 29,2019 |  |  | March 30,2018 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income for the period |  | $ | 87,998 |  |  | $ | 61,399 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 22,521 |  |  |  | 21,288 |  |
| Loss (gain) on disposal of property, plant and equipment |  |  | 81 |  |  |  | (153 | ) |
| Loss on disposal of intangibles |  |  | 149 |  |  |  | — |  |
| (Gain) loss from sales and maturities of available-for-sale securities |  |  | (196 | ) |  |  | 362 |  |
| Amortization of investment premium |  |  | (604 | ) |  |  | (31 | ) |
| Amortization of deferred debt issuance costs |  |  | — |  |  |  | 433 |  |
| Allowance for doubtful accounts |  |  | 12 |  |  |  | 44 |  |
| Unrealized (gain) loss on exchange rate and fair value of derivative instruments |  |  | (5,351 | ) |  |  | 1,393 |  |
| Share-based compensation |  |  | 13,373 |  |  |  | 17,704 |  |
| Deferred income tax |  |  | 438 |  |  |  | 19 |  |
| Other non-cash expenses |  |  | 1,142 |  |  |  | 1,941 |  |
| Inventory (reversal of inventory) obsolescence |  |  | 280 |  |  |  | (291 | ) |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | (17,942 | ) |  |  | 21,411 |  |
| Contract assets |  |  | (666 | ) |  |  | — |  |
| Inventory |  |  | (36,698 | ) |  |  | (973 | ) |
| Other current assets and non-current assets |  |  | (1,568 | ) |  |  | (9,853 | ) |
| Trade accounts payable |  |  | 37,576 |  |  |  | (22,518 | ) |
| Income tax payable |  |  | 1,942 |  |  |  | (1,678 | ) |
| Other current liabilities and non-current liabilities |  |  | 3,017 |  |  |  | (703 | ) |
| Net cash provided by operating activities |  |  | 105,504 |  |  |  | 89,794 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of short-term investments |  |  | (202,328 | ) |  |  | (84,519 | ) |
| Proceeds from sales of short-term investments |  |  | 85,941 |  |  |  | 22,169 |  |
| Proceeds from maturities of short-term investments |  |  | 50,370 |  |  |  | 42,977 |  |
| Purchase of property, plant and equipment |  |  | (13,211 | ) |  |  | (28,268 | ) |
| Purchase of intangibles |  |  | (290 | ) |  |  | (1,487 | ) |
| Proceeds from disposal of property, plant and equipment |  |  | 473 |  |  |  | 202 |  |
| Net cash used in investing activities |  |  | (79,045 | ) |  |  | (48,926 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Proceeds of short-term loans from bank |  |  | — |  |  |  | 5,000 |  |
| Repayment of short-term loans from bank |  |  | — |  |  |  | (1,003 | ) |
| Repayment of long-term loans from bank |  |  | (2,438 | ) |  |  | (10,200 | ) |
| Repayment of capital lease liability |  |  | (342 | ) |  |  | (293 | ) |
| Repurchase of ordinary shares |  |  | (5,378 | ) |  |  | (22,407 | ) |
| Proceeds from issuance of ordinary shares under employee share option plans |  |  | — |  |  |  | 993 |  |
| Release of restricted cash held in connection with business acquisition |  |  | (3,478 | ) |  |  | — |  |
| Withholding tax related to net share settlement of restricted share units |  |  | (10,427 | ) |  |  | (4,030 | ) |
| Net cash used in financing activities |  |  | (22,063 | ) |  |  | (31,940 | ) |
| Net increase in cash, cash equivalents and restricted cash |  |  | 4,396 |  |  |  | 8,928 |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |  |  |  |  |  |
| Cash, cash equivalents and restricted cash at beginning of period |  |  | 161,433 |  |  |  | 137,137 |  |
| Increase in cash, cash equivalents and restricted cash |  |  | 4,396 |  |  |  | 8,928 |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash |  |  | 578 |  |  |  | (89 | ) |
| Cash, cash equivalents and restricted cash at end of period |  | $ | 166,407 |  |  | $ | 145,976 |  |
| Non-cash investing and financing activities |  |  |  |  |  |  |  |  |
| Construction, software-related and equipment-related payables |  | $ | 3,286 |  |  | $ | 4,684 |  |

[0001193125-19-138338:8k_2_02:51]
FABRINET

[0001193125-19-138338:8k_2_02:52]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS (unaudited)

[0001193125-19-138338:8k_2_02:53]
(Continued)

[0001193125-19-138338:8k_2_02:54]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within
the condensed consolidated balance sheets that sum to the total of the same amounts shown in the condensed consolidated statements of cash flows:

[0001193125-19-138338:8k_2_02:55]
| (amount in thousands) |  | As ofMarch 29,2019 |  |  | As ofMarch 30,2018 |  |
| Cash and cash equivalents |  | $ | 166,407 |  |  | $ | 142,407 |  |
| Restricted cash in connection with business acquisition |  |  | — |  |  |  | 3,569 |  |
| Cash, cash equivalents and restricted cash |  | $ | 166,407 |  |  | $ | 145,976 |  |

[0001193125-19-138338:8k_2_02:56]
FABRINET

[0001193125-19-138338:8k_2_02:57]
RECONCILIATION OF ASC 605 TO ASC 606

[0001193125-19-138338:8k_2_02:58]
|  |  | Three Months EndedMarch 29, 2019 |  |
| (in thousands of U.S. dollars, except per share amounts) |  | As reportedunderASC 606 |  |  | Adjustment |  |  | ASC 605 |  |
| Revenues |  | $ | 398,951 |  |  | $ | 2,793 |  |  | $ | 401,744 |  |
| Cost of revenues |  |  | (350,874 | ) |  |  | (2,699 | ) |  |  | (353,573 | ) |
| Gross profit |  |  | 48,077 |  |  |  | 94 |  |  |  | 48,171 |  |
| Selling, general and administrative expenses |  |  | (10,061 | ) |  |  | — |  |  |  | (10,061 | ) |
| Operating income |  |  | 38,016 |  |  |  | 94 |  |  |  | 38,110 |  |
| Interest income |  |  | 2,144 |  |  |  | — |  |  |  | 2,144 |  |
| Interest expense |  |  | (1,423 | ) |  |  | — |  |  |  | (1,423 | ) |
| Foreign exchange loss |  |  | (3,055 | ) |  |  | — |  |  |  | (3,055 | ) |
| Other income |  |  | 159 |  |  |  | — |  |  |  | 159 |  |
| Income before income taxes |  |  | 35,841 |  |  |  | 94 |  |  |  | 35,935 |  |
| Income tax expense |  |  | (1,493 | ) |  |  | — |  |  |  | (1,493 | ) |
| Net income |  |  | 34,348 |  |  |  | 94 |  |  |  | 34,442 |  |
| Other comprehensive income, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in net unrealized gain on available-for-sale securities |  |  | 513 |  |  |  | — |  |  |  | 513 |  |
| Change in net unrealized loss on derivative instruments |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |
| Change in foreign currency translation adjustment |  |  | 486 |  |  |  | — |  |  |  | 486 |  |
| Total other comprehensive income, net of tax |  |  | 998 |  |  |  | — |  |  |  | 998 |  |
| Net comprehensive income |  | $ | 35,346 |  |  | $ | 94 |  |  | $ | 35,440 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.93 |  |  | $ | 0.00 |  |  | $ | 0.93 |  |
| Diluted |  | $ | 0.92 |  |  | $ | 0.00 |  |  | $ | 0.92 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |
| Basic |  |  | 36,891 |  |  |  | — |  |  |  | 36,891 |  |
| Diluted |  |  | 37,539 |  |  |  | — |  |  |  | 37,539 |  |

[0001193125-19-138338:8k_2_02:59]
| FABRINET RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 29, 2019(ASC 606) |  |  | March 30, 2018(ASC 605) |  |  | March 29, 2019(ASC 606) |  |  | March 30, 2018(ASC 605) |  |
| (in thousands of U.S. dollars, except per share data) |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |  | Netincome |  |  | DilutedEPS |  |
| GAAP measures |  |  | 28,635 |  |  |  | 0.76 |  |  |  | 21,053 |  |  |  | 0.55 |  |  |  | 87,998 |  |  |  | 2.35 |  |  |  | 61,399 |  |  |  | 1.61 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,237 |  |  |  | 0.03 |  |  |  | 1,564 |  |  |  | 0.04 |  |  |  | 4,384 |  |  |  | 0.12 |  |  |  | 5,277 |  |  |  | 0.14 |  |
| Depreciation of fair value uplift |  |  | 82 |  |  |  | 0.00 |  |  |  | 88 |  |  |  | 0.00 |  |  |  | 255 |  |  |  | 0.01 |  |  |  | 241 |  |  |  | 0.00 |  |
| ASC 606 adoption impact on gross profit |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (31 | ) |  |  | (0.00 | ) |  |  | — |  |  |  | — |  |
| Total related to gross profit |  |  | 1,319 |  |  |  | 0.04 |  |  |  | 1,652 |  |  |  | 0.04 |  |  |  | 4,608 |  |  |  | 0.12 |  |  |  | 5,518 |  |  |  | 0.14 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 3,187 |  |  |  | 0.08 |  |  |  | 3,762 |  |  |  | 0.10 |  |  |  | 8,989 |  |  |  | 0.24 |  |  |  | 12,427 |  |  |  | 0.33 |  |
| Expenses related to CFO/CEO search |  |  | 285 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 857 |  |  |  | 0.02 |  |  |  | 204 |  |  |  | 0.00 |  |
| Amortization of intangibles |  |  | 163 |  |  |  | 0.00 |  |  |  | 205 |  |  |  | 0.01 |  |  |  | 531 |  |  |  | 0.01 |  |  |  | 582 |  |  |  | 0.02 |  |
| Business combination expenses |  |  | 88 |  |  |  | 0.00 |  |  |  | — |  |  |  | — |  |  |  | 328 |  |  |  | 0.01 |  |  |  | 117 |  |  |  | 0.00 |  |
| Severance payment |  |  | 348 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 949 |  |  |  | 0.03 |  |  |  | — |  |  |  | — |  |
| Total related to selling, general and administrative expenses |  |  | 4,071 |  |  |  | 0.11 |  |  |  | 3,967 |  |  |  | 0.11 |  |  |  | 11,654 |  |  |  | 0.31 |  |  |  | 13,329 |  |  |  | 0.35 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other expenses in relation to reduction in workforce |  |  | 323 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 727 |  |  |  | 0.02 |  |  |  | 1,776 |  |  |  | 0.05 |  |
| Amortization of debt issuance costs |  |  | — |  |  |  | — |  |  |  | 238 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 778 |  |  |  | 0.02 |  |
| Total related to other incomes and other expenses |  |  | 323 |  |  |  | 0.01 |  |  |  | 238 |  |  |  | 0.01 |  |  |  | 727 |  |  |  | 0.02 |  |  |  | 2,554 |  |  |  | 0.07 |  |
| Total related to net income & EPS |  |  | 5,713 |  |  |  | 0.15 |  |  |  | 5,857 |  |  |  | 0.16 |  |  |  | 16,989 |  |  |  | 0.45 |  |  |  | 21,401 |  |  |  | 0.56 |  |
| Non-GAAP measures |  |  | 34,348 |  |  |  | 0.92 |  |  |  | 26,910 |  |  |  | 0.71 |  |  |  | 104,987 |  |  |  | 2.81 |  |  |  | 82,800 |  |  |  | 2.17 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 37,539 |  |  |  |  |  |  |  | 38,055 |  |  |  |  |  |  |  | 37,383 |  |  |  |  |  |  |  | 38,125 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 37,539 |  |  |  |  |  |  |  | 38,055 |  |  |  |  |  |  |  | 37,383 |  |  |  |  |  |  |  | 38,125 |  |

[0001193125-19-138338:8k_2_02:60]
FABRINET

[0001193125-19-138338:8k_2_02:61]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW

[0001193125-19-138338:8k_2_02:62]
| (amount in thousands) |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 29,2019 |  |  | March 30,2018 |  |  | March 29,2019 |  |  | March 30,2018 |  |
| Net cash provided by operating activities |  | $ | 36,206 |  |  | $ | 52,681 |  |  | $ | 105,504 |  |  | $ | 89,794 |  |
| Less: Purchase of property, plant and equipment |  |  | (3,479 | ) |  |  | (6,863 | ) |  |  | (13,211 | ) |  |  | (28,268 | ) |
| Non-GAAP free cash flow |  | $ | 32,727 |  |  | $ | 45,818 |  |  | $ | 92,293 |  |  | $ | 61,526 |  |

[0001193125-19-138338:8k_2_02:63]
FABRINET

[0001193125-19-138338:8k_2_02:64]
GUIDANCE FOR QUARTER ENDING JUNE 28, 2019

[0001193125-19-138338:8k_2_02:65]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001193125-19-138338:8k_2_02:66]
|  |  | Diluted EPS |  |
| GAAP net income per diluted share: |  | $ | 0.78 to $0.82 |  |
| Related to cost of revenues: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.04 |  |
| Total related to gross profit |  |  | 0.04 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |
| Share-based compensation expenses |  |  | 0.09 |  |
| Expenses related to our CFO search |  |  | 0.01 |  |
| Total related to selling, general and administrative expenses |  |  | 0.10 |  |
| Total related to net income & EPS |  |  | 0.14 |  |
| Non-GAAP net income per diluted share |  | $ | 0.92 to $0.96 |  |

## item 5.02 — body, verbatim

[0001193125-19-138338:8k_body:1]
Item 5.02

[0001193125-19-138338:8k_body:2]
Results of Operations and Financial Condition.

[0001193125-19-138338:8k_body:3]
On May 1, 2019, Fabrinet and David T. Mitchell, Fabrinet’s Chairman of the Board, entered into a letter agreement (the “Amendment”) to
amend Mr. Mitchell’s two, performance-based restricted share unit awards, each covering 69,885 ordinary shares of Fabrinet (at target and maximum performance), that were granted to him on August 24, 2017 (the “PSU Awards”)
under Fabrinet’s 2010 Performance Incentive Plan and applicable award agreements thereunder. Under the terms of the PSU Award agreements, each of the PSU Awards is settled entirely in the form of Fabrinet ordinary shares if and when the
PSU Award vests. As a result of the Amendment, upon any vesting and settlement of the PSU Awards, 42% of the shares otherwise issuable upon such vesting automatically will be settled instead in the form of cash.

[0001193125-19-138338:8k_body:4]
The foregoing description of the Amendment is a summary and is qualified in its entirety by the terms of the Amendment, a copy of which is attached hereto as
Exhibit 10.1.
