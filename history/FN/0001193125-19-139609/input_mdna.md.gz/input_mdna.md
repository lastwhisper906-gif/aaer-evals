# FN MD&A — 0001193125-19-139609


## mdna

[0001193125-19-139609:mdna:1]
ITEM 2. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION
AND RESULTS OF OPERATIONS

[0001193125-19-139609:mdna:2]
[same as prior period, unchanged from 0001193125-19-028336:mdna:2]

[0001193125-19-139609:mdna:3]
[same as prior period, unchanged from 0001193125-19-028336:mdna:3]

[0001193125-19-139609:mdna:4]
|  | • |  | our expectation that the portion of our future revenues attributable to customers in regions outside of North America will be in line with the portion of those revenues for the nine months ended March 29, 2019; |

[0001193125-19-139609:mdna:5]
[same as prior period, unchanged from 0001193125-19-028336:mdna:5]

[0001193125-19-139609:mdna:6]
[same as prior period, unchanged from 0001193125-19-028336:mdna:6]

[0001193125-19-139609:mdna:7]
[same as prior period, unchanged from 0001193125-19-028336:mdna:7]

[0001193125-19-139609:mdna:8]
[same as prior period, unchanged from 0001193125-19-028336:mdna:9]

[0001193125-19-139609:mdna:9]
[same as prior period, unchanged from 0001193125-19-028336:mdna:10]

[0001193125-19-139609:mdna:10]
[same as prior period, unchanged from 0001193125-19-028336:mdna:11]

[0001193125-19-139609:mdna:11]
[same as prior period, unchanged from 0001193125-19-028336:mdna:12]

[0001193125-19-139609:mdna:12]
[same as prior period, unchanged from 0001193125-19-028336:mdna:13]

[0001193125-19-139609:mdna:13]
[same as prior period, unchanged from 0001193125-19-028336:mdna:14]

[0001193125-19-139609:mdna:14]
[same as prior period, unchanged from 0001193125-19-028336:mdna:15]

[0001193125-19-139609:mdna:15]
[same as prior period, unchanged from 0001193125-19-028336:mdna:16]

[0001193125-19-139609:mdna:16]
[same as prior period, unchanged from 0001193125-19-028336:mdna:17]

[0001193125-19-139609:mdna:17]
[same as prior period, unchanged from 0001193125-19-028336:mdna:18]

[0001193125-19-139609:mdna:18]
[same as prior period, unchanged from 0001193125-19-028336:mdna:19]

[0001193125-19-139609:mdna:19]
[same as prior period, unchanged from 0001193125-19-028336:mdna:20]

[0001193125-19-139609:mdna:20]
[same as prior period, unchanged from 0001193125-19-028336:mdna:21]

[0001193125-19-139609:mdna:21]
[same as prior period, unchanged from 0001193125-19-028336:mdna:22]

[0001193125-19-139609:mdna:22]
[same as prior period, unchanged from 0001193125-19-028336:mdna:23]

[0001193125-19-139609:mdna:23]
[same as prior period, unchanged from 0001193125-19-028336:mdna:24]

[0001193125-19-139609:mdna:24]
[same as prior period, unchanged from 0001193125-19-028336:mdna:25]

[0001193125-19-139609:mdna:25]
[same as prior period, unchanged from 0001193125-19-028336:mdna:26]

[0001193125-19-139609:mdna:26]
[same as prior period, unchanged from 0001193125-19-028336:mdna:27]

[0001193125-19-139609:mdna:27]
The percentage of our revenues generated from a
bill-to location outside of North America decreased slightly from 51.6% in the three months ended March 30, 2018 to 51.0% in the three months ended March 29, 2019, and decreased from 54.2% in the
nine months ended March 30, 2018 to 52.7% in the nine months ended March 29, 2019, primarily because the increase in sales to our customers in North America was higher than the increase in sales to our customers outside of North America.
Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside North America will be in line with the portion of revenues attributable
to such customers during the nine months ended March 29, 2019.

[0001193125-19-139609:mdna:28]
[same as prior period, unchanged from 0001193125-19-028336:mdna:29]

[0001193125-19-139609:mdna:29]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 29,2019 |  |  | March 30,2018 |  |  | March 29,2019 |  |  | March 30,2018 |  |
| North America |  |  | 49.0 | % |  |  | 48.4 | % |  |  | 47.3 | % |  |  | 45.8 | % |
| Asia-Pacific |  |  | 37.9 |  |  |  | 36.9 |  |  |  | 39.9 |  |  |  | 38.5 |  |
| Europe |  |  | 13.1 |  |  |  | 14.7 |  |  |  | 12.8 |  |  |  | 15.7 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-19-139609:mdna:30]
[same as prior period, unchanged from 0001193125-19-028336:mdna:31]

[0001193125-19-139609:mdna:31]
[same as prior period, unchanged from 0001193125-19-028336:mdna:32]

[0001193125-19-139609:mdna:32]
[same as prior period, unchanged from 0001193125-19-028336:mdna:33]

[0001193125-19-139609:mdna:33]
[same as prior period, unchanged from 0001193125-19-028336:mdna:34]

[0001193125-19-139609:mdna:34]
[same as prior period, unchanged from 0001193125-19-028336:mdna:35]

[0001193125-19-139609:mdna:35]
[same as prior period, unchanged from 0001193125-19-028336:mdna:36]

[0001193125-19-139609:mdna:36]
[same as prior period, unchanged from 0001193125-19-028336:mdna:37]

[0001193125-19-139609:mdna:37]
[same as prior period, unchanged from 0001193125-19-028336:mdna:38]

[0001193125-19-139609:mdna:38]
[same as prior period, unchanged from 0001193125-19-028336:mdna:39]

[0001193125-19-139609:mdna:39]
The compensation committee of our board of directors approved a fiscal year 2019 executive incentive plan with quantitative objectives that
are based solely on achieving certain revenue targets and non-U.S. GAAP gross margin targets for our fiscal year ending June 28, 2019. Bonuses under the fiscal year 2019 executive incentive plan are payable
after the end of fiscal year 2019. In fiscal year 2018, the compensation committee approved a fiscal year 2018 executive incentive plan with quantitative objectives that were based solely on achieving certain revenue targets and non-U.S. GAAP gross margin targets for our fiscal year ended June 29, 2018. Because we did not achieve the targets under our fiscal year 2018 executive incentive plan, no bonuses were paid under such plan.
Discretionary merit-based bonus awards are also available to our non-executive employees and payable on a quarterly basis.

[0001193125-19-139609:mdna:40]
[same as prior period, unchanged from 0001193125-19-028336:mdna:42]

[0001193125-19-139609:mdna:41]
[same as prior period, unchanged from 0001193125-19-028336:mdna:43]

[0001193125-19-139609:mdna:42]
As a result of our international operations, we are exposed to foreign exchange risk arising from various currency exposures
primarily with respect to the Thai baht. Although a majority of our total revenues is denominated in U.S. dollars, a substantial portion of our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rate
between the Thai baht and the U.S. dollar has fluctuated substantially in recent years and may continue to fluctuate substantially in the future. We report our financial results in U.S. dollars and our results of operations have been and could in
the future be negatively impacted if the Thai baht appreciates against the U.S. dollar. Smaller portions of our expenses are incurred in a variety of other currencies, including RMB, GBP, Canadian dollars, Euros, and Japanese yen, the appreciation
of which may also negatively impact our financial results.

[0001193125-19-139609:mdna:43]
In order to manage the risks arising from fluctuations in foreign currency
exchange rates, we use derivative instruments. We may enter into foreign currency exchange forward or option contracts to manage foreign currency exposures associated with certain assets and liabilities and other forecasted foreign currency
transactions and may designate these instruments as hedging instruments. The forward and option contracts generally have maturities of up to 12 months. All foreign currency exchange contracts are recognized in the condensed consolidated balance
sheets at fair value. Gain or loss on our forward and option contracts generally offset the assets, liabilities, and transactions economically hedged.

[0001193125-19-139609:mdna:44]
[same as prior period, unchanged from 0001193125-19-028336:mdna:46]

[0001193125-19-139609:mdna:45]
|  |  | As of March 29, 2019 |  |  | As of June 29, 2018 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 638,497 |  |  | $ | 20,072 |  |  |  | 60.0 |  |  |  | 980,778 |  |  | $ | 29,568 |  |  |  | 60.7 |  |
| RMB |  |  | 48,983 |  |  |  | 7,275 |  |  |  | 21.7 |  |  |  | 18,455 |  |  |  | 2,789 |  |  |  | 5.7 |  |
| GBP |  |  | 4,674 |  |  |  | 6,114 |  |  |  | 18.3 |  |  |  | 12,514 |  |  |  | 16,392 |  |  |  | 33.6 |  |
| Total |  |  |  |  |  | $ | 33,461 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 48,749 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,874,891 |  |  | $ | 58,940 |  |  |  | 88.6 |  |  |  | 1,401,473 |  |  | $ | 42,251 |  |  |  | 84.5 |  |
| RMB |  |  | 27,134 |  |  |  | 4,030 |  |  |  | 6.1 |  |  |  | 19,893 |  |  |  | 3,007 |  |  |  | 6.0 |  |
| GBP |  |  | 2,714 |  |  |  | 3,549 |  |  |  | 5.3 |  |  |  | 3,615 |  |  |  | 4,735 |  |  |  | 9.5 |  |
| Total |  |  |  |  |  | $ | 66,519 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 49,993 |  |  |  | 100.0 |  |

[0001193125-19-139609:mdna:46]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other
current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and
offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of March 29, 2019 there were $98.0 million in foreign currency forward contracts and $5.0 million in foreign currency
option contracts outstanding on the Thai baht payables. As of June 29, 2018, there were $7.0 million in foreign currency forward contracts and $30.0 million in foreign currency option contracts outstanding on the Thai baht payables.

[0001193125-19-139609:mdna:47]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities represent
trade accounts payable, accrued expenses, income tax payable and other payables. As of March 29, 2019 and June 29, 2018, we did not have any derivative contracts denominated in RMB.

[0001193125-19-139609:mdna:48]
The GBP assets represent cash, trade accounts receivable and other current assets. The GBP liabilities represent trade accounts payable and
other payables. As of March 29, 2019 and June 29, 2018, we did not have any derivative contracts denominated in GBP.

[0001193125-19-139609:mdna:49]
For the
nine months ended March 29, 2019 and March 30, 2018, we recorded unrealized gain of $1.5 million and recorded unrealized loss of $26 thousand, respectively, related to derivatives that are not designated as hedging instruments in
the condensed consolidated statements of operations and comprehensive income.

[0001193125-19-139609:mdna:50]
[same as prior period, unchanged from 0001193125-19-028336:mdna:52]

[0001193125-19-139609:mdna:51]
[same as prior period, unchanged from 0001193125-19-028336:mdna:53]

[0001193125-19-139609:mdna:52]
[same as prior period, unchanged from 0001193125-19-028336:mdna:54]

[0001193125-19-139609:mdna:53]
[same as prior period, unchanged from 0001193125-19-028336:mdna:55]

[0001193125-19-139609:mdna:54]
[same as prior period, unchanged from 0001193125-19-028336:mdna:56]

[0001193125-19-139609:mdna:55]
[same as prior period, unchanged from 0001193125-19-028336:mdna:57]

[0001193125-19-139609:mdna:56]
[same as prior period, unchanged from 0001193125-19-028336:mdna:58]

[0001193125-19-139609:mdna:57]
[same as prior period, unchanged from 0001193125-19-028336:mdna:59]

[0001193125-19-139609:mdna:58]
[same as prior period, unchanged from 0001193125-19-028336:mdna:60]

[0001193125-19-139609:mdna:59]
[same as prior period, unchanged from 0001193125-19-028336:mdna:61]

[0001193125-19-139609:mdna:60]
[same as prior period, unchanged from 0001193125-19-028336:mdna:62]

[0001193125-19-139609:mdna:61]
[same as prior period, unchanged from 0001193125-19-028336:mdna:63]

[0001193125-19-139609:mdna:62]
Our effective tax rate is a function of the mix of tax rates in the various jurisdictions in which we do business. We are domiciled in the
Cayman Islands. Under the current laws of the Cayman Islands, we are not subject to tax in the Cayman Islands on income or capital gains. We initially received this undertaking for a 20-year period ending
August 24, 2019, but were recently granted a renewal until March 6, 2039.

[0001193125-19-139609:mdna:63]
Throughout the period of our operations in Thailand,
we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption is currently available to us through June 2020 and June
2026 on income generated from projects to manufacture certain products at our Pinehurst campus and Chonburi campus, respectively. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products
out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted (i.e., at least until June 2020 in the case of our
Pinehurst campus and until June 2026 in the case of our Chonburi campus). Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001193125-19-139609:mdna:64]
The Tax Cuts and Jobs Act, or the Tax Reform Act, was enacted on December 22, 2017 and provides for significant changes to U.S. tax law.
Among other provisions, the Tax Reform Act reduces the U.S. corporate income tax rate to 21% effective in 2018. The Tax Reform Act also contains a number of provisions that may impact us in future years. Since the Tax Reform Act was recently
finalized and ongoing guidance and accounting interpretation is expected over the next twelve months, we have made certain provisional accounting estimates, as permitted under Staff Accounting Bulletin No. 118. The U.S. Treasury Department, the
IRS, and other standard-setting bodies could interpret or issue guidance on how provisions of the Tax Reform Act will be applied or otherwise administered that is different from our interpretation. At December 28, 2018, we have completed our
accounting for all of the enactment-date income tax effects of the Tax Reform Act and concluded that the impact to us is immaterial.

[0001193125-19-139609:mdna:65]
[same as prior period, unchanged from 0001193125-19-028336:mdna:67]

[0001193125-19-139609:mdna:66]
[same as prior period, unchanged from 0001193125-19-028336:mdna:68]

[0001193125-19-139609:mdna:67]
[same as prior period, unchanged from 0001193125-19-028336:mdna:69]

[0001193125-19-139609:mdna:68]
On June 30, 2018, we adopted ASC 606 using the modified retrospective method, which was applied to
those contracts which were not completed as of June 29, 2018. The modified retrospective method requires us to recognize the cumulative effect of the adoption of ASC 606, for all contracts with customers, to the opening balance of equity at
June 30, 2018. Accordingly, the comparative financial information as of June 29, 2018 has not been adjusted and continues to be reported under ASC 605, Revenue Recognition (“ASC 605”). Refer to Note 2 – Accounting policies
and Note 3 – Revenues to the condensed consolidated financial statements for further details.

[0001193125-19-139609:mdna:69]
37

[0001193125-19-139609:mdna:70]
[same as prior period, unchanged from 0001193125-19-028336:mdna:72]

[0001193125-19-139609:mdna:71]
[same as prior period, unchanged from 0001193125-19-028336:mdna:73]

[0001193125-19-139609:mdna:72]
| (amount in thousands) |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 29,2019 |  |  | March 30,2018 |  |  | March 29,2019 |  |  | March 30,2018 |  |
| Revenues |  | $ | 398,951 |  |  | $ | 332,213 |  |  | $ | 1,179,208 |  |  | $ | 1,026,598 |  |
| Cost of revenues |  |  | (352,193 | ) |  |  | (295,280 | ) |  |  | (1,046,610 | ) |  |  | (912,167 | ) |
| Gross profit |  |  | 46,758 |  |  |  | 36,933 |  |  |  | 132,598 |  |  |  | 114,431 |  |
| Selling, general and administrative expenses |  |  | (14,132 | ) |  |  | (12,418 | ) |  |  | (41,296 | ) |  |  | (41,253 | ) |
| Expenses related to reduction in workforce |  |  | (323 | ) |  |  | — |  |  |  | (727 | ) |  |  | (1,776 | ) |
| Operating income |  |  | 32,303 |  |  |  | 24,515 |  |  |  | 90,575 |  |  |  | 71,402 |  |
| Interest income |  |  | 2,144 |  |  |  | 1,149 |  |  |  | 4,770 |  |  |  | 2,554 |  |
| Interest expense |  |  | (1,423 | ) |  |  | (820 | ) |  |  | (3,673 | ) |  |  | (2,499 | ) |
| Foreign exchange loss, net |  |  | (3,055 | ) |  |  | (2,428 | ) |  |  | (408 | ) |  |  | (5,710 | ) |
| Other income |  |  | 159 |  |  |  | 91 |  |  |  | 798 |  |  |  | 438 |  |
| Income before income taxes |  |  | 30,128 |  |  |  | 22,507 |  |  |  | 92,062 |  |  |  | 66,185 |  |
| Income tax expense |  |  | (1,493 | ) |  |  | (1,454 | ) |  |  | (4,064 | ) |  |  | (4,786 | ) |
| Net income |  |  | 28,635 |  |  |  | 21,053 |  |  |  | 87,998 |  |  |  | 61,399 |  |
| Other comprehensive income, net of tax |  |  | 998 |  |  |  | 173 |  |  |  | 1,178 |  |  |  | 309 |  |
| Net comprehensive income |  | $ | 29,633 |  |  | $ | 21,226 |  |  | $ | 89,176 |  |  | $ | 61,708 |  |

[0001193125-19-139609:mdna:73]
[same as prior period, unchanged from 0001193125-19-028336:mdna:75]

[0001193125-19-139609:mdna:74]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 29,2019 |  |  | March 30,2018 |  |  | March 29,2019 |  |  | March 30,2018 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (88.3 | ) |  |  | (88.9 | ) |  |  | (88.8 | ) |  |  | (88.9 | ) |
| Gross profit |  |  | 11.7 |  |  |  | 11.1 |  |  |  | 11.2 |  |  |  | 11.1 |  |
| Selling, general and administrative expenses |  |  | (3.5 | ) |  |  | (3.7 | ) |  |  | (3.5 | ) |  |  | (4.0 | ) |
| Expenses related to reduction in workforce |  |  | (0.1 | ) |  |  | — |  |  |  | (0.1 | ) |  |  | (0.2 | ) |
| Operating income |  |  | 8.1 |  |  |  | 7.4 |  |  |  | 7.6 |  |  |  | 6.9 |  |
| Interest income |  |  | 0.5 |  |  |  | 0.3 |  |  |  | 0.4 |  |  |  | 0.2 |  |
| Interest expense |  |  | (0.4 | ) |  |  | (0.2 | ) |  |  | (0.3 | ) |  |  | (0.2 | ) |
| Foreign exchange gain, net |  |  | (0.8 | ) |  |  | (0.7 | ) |  |  | 0.0 |  |  |  | (0.6 | ) |
| Other income |  |  | 0.1 |  |  |  | 0.0 |  |  |  | 0.1 |  |  |  | 0.0 |  |
| Income before income taxes |  |  | 7.5 |  |  |  | 6.8 |  |  |  | 7.8 |  |  |  | 6.3 |  |
| Income tax expense |  |  | (0.4 | ) |  |  | (0.4 | ) |  |  | (0.3 | ) |  |  | (0.5 | ) |
| Net income |  |  | 7.1 |  |  |  | 6.4 |  |  |  | 7.5 |  |  |  | 5.8 |  |
| Other comprehensive income, net of tax |  |  | 0.3 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.0 |  |
| Net comprehensive income |  |  | 7.4 | % |  |  | 6.5 | % |  |  | 7.6 | % |  |  | 5.8 | % |

[0001193125-19-139609:mdna:75]
[same as prior period, unchanged from 0001193125-19-028336:mdna:77]

[0001193125-19-139609:mdna:76]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 29,2019 |  |  | March 30,2018 |  |  | March 29,2019 |  |  | March 30,2018 |  |
| Optical communications |  | $ | 298,139 |  |  | $ | 240,798 |  |  | $ | 884,454 |  |  | $ | 758,299 |  |
| Lasers, sensors and other |  |  | 100,812 |  |  |  | 91,415 |  |  |  | 294,754 |  |  |  | 268,299 |  |
| Total |  | $ | 398,951 |  |  | $ | 332,213 |  |  | $ | 1,179,208 |  |  | $ | 1,026,598 |  |

[0001193125-19-139609:mdna:77]
[same as prior period, unchanged from 0001193125-19-028336:mdna:79]

[0001193125-19-139609:mdna:78]
Comparison of Three and Nine Months Ended March 29, 2019 with Three and Nine Months Ended
March 30, 2018

[0001193125-19-139609:mdna:79]
[same as prior period, unchanged from 0001193125-19-028336:mdna:81]

[0001193125-19-139609:mdna:80]
Our total revenues increased by $66.7 million, or 20.1%, to $399.0 million for the three months ended March 29, 2019, compared
with $332.2 million for the three months ended March 30, 2018. This increase was primarily due to an increase in our customers’ demand for both optical and non-optical communications
manufacturing services during the three months ended March 29, 2019. Revenues from optical and non-optical communications products increased by $57.3 million and $9.4 million, or 23.8% and
10.3%, respectively, for the three months ended March 29, 2019.

[0001193125-19-139609:mdna:81]
Our total revenues increased by $152.6 million, or 14.9%, to
$1,179.2 million for the nine months ended March 29, 2019, compared with $1,026.6 million for the nine months ended March 30, 2018. This increase was primarily due to an increase in our customers’ demand for both optical and
non-optical communications manufacturing services during the nine months ended March 29, 2019. Revenues from optical and non-optical communications products
increased by $126.2 million and $26.4 million, or 16.6% and 9.9%, respectively, for the nine months ended March 29, 2019.

[0001193125-19-139609:mdna:82]
[same as prior period, unchanged from 0001193125-19-028336:mdna:84]

[0001193125-19-139609:mdna:83]
Our
cost of revenues increased by $56.9 million, or 19.3%, to $352.2 million, or 88.3% of total revenues, for the three months ended March 29, 2019, compared with $295.3 million, or 88.9% of total revenues, for the three months ended
March 30, 2018. This increase in cost of revenues was in line with the increase in sales volume.

[0001193125-19-139609:mdna:84]
Our cost of revenues increased by
$134.4 million, or 14.7%, to $1,046.6 million, or 88.8% of total revenues, for the nine months ended March 29, 2019, compared with $912.2 million, or 88.9% of total revenues, for the nine months ended March 30, 2018. This
increase in cost of revenues was in line with the increase in sales volume.

[0001193125-19-139609:mdna:85]
[same as prior period, unchanged from 0001193125-19-028336:mdna:87]

[0001193125-19-139609:mdna:86]
Our gross profit increased by $9.8 million, or 26.6%, to $46.8 million, or 11.7% of total revenues, for the three months ended
March 29, 2019, compared with $36.9 million, or 11.1% of total revenues, for the three months ended March 30, 2018. The increase was primarily due to an increase in revenue and effective cost controls.

[0001193125-19-139609:mdna:87]
Our gross profit increased by $18.2 million, or 15.9%, to $132.6 million, or 11.2% of total revenues, for the nine months ended
March 29, 2019, compared with $114.4 million, or 11.1% of total revenues, for the nine months ended March 30, 2018. The increase was primarily due to an increase in revenues.

[0001193125-19-139609:mdna:88]
[same as prior period, unchanged from 0001193125-19-028336:mdna:90]

[0001193125-19-139609:mdna:89]
Our
SG&A expenses increased by $1.7 million, or 13.8%, to $14.1 million, or 3.5% of total revenues, for the three months ended March 29, 2019, compared with $12.4 million, or 3.7% of total revenues, for the three months ended
March 30, 2018. The increase was primarily due to (1) an increase in executive bonuses of $1.5 million, (2) an increase of $0.5 million in salary and fringe benefits due to the hiring of new executives, and (3) an
increase of $0.2 million in the expenses of our new subsidiary in Israel which we established in March 2018, partially offset by (1) a decrease in executive and management expenses of $0.4 million relating to our former Executive
Chairman becoming a non-employee director at the end of June 2018 and (2) a decrease in share-based compensation expenses of $0.6 million because we did not expect to achieve the pre-defined
performance targets.

[0001193125-19-139609:mdna:90]
Our SG&A expenses remained flat at $41.3 million, or 3.5% of total revenues, for the nine months ended
March 29, 2019, compared with $41.3 million, or 4.0% of total revenues, for the nine months ended March 30, 2018.

[0001193125-19-139609:mdna:91]
[same as prior period, unchanged from 0001193125-19-028336:mdna:93]

[0001193125-19-139609:mdna:92]
Our
operating income increased by $7.8 million to $32.3 million, or 8.1% of total revenues, for the three months ended March 29, 2019, compared with $24.5 million, or 7.4% of total revenues, for the three months ended March 30,
2018. The increase was primarily due to an increase in gross profit and a decrease in SG&A expenses.

[0001193125-19-139609:mdna:93]
Our operating income increased by $19.2 million to $90.6 million, or 7.7% of total
revenues, for the nine months ended March 29, 2019, compared with $71.4 million, or 6.9% of total revenues, for the nine months ended March 30, 2018. The increase was primarily due to a decrease in SG&A expenses.

[0001193125-19-139609:mdna:94]
[same as prior period, unchanged from 0001193125-19-028336:mdna:96]

[0001193125-19-139609:mdna:95]
Our
interest income increased by $1.0 million, or 86.6%, to $2.1 million, or 0.5% of total revenues, for the three months ended March 29, 2019, compared with $1.1 million, or 0.3% of total revenues, for the three months ended
March 30, 2018. The increase was primarily due to the higher weighted average interest rate compared to the same period in the last year and an increase in the average balance of our outstanding cash.

[0001193125-19-139609:mdna:96]
Our interest income increased by $2.2 million, or 86.8%, to $4.8 million, or 0.4% of total revenues, for the nine months ended
March 29, 2019, compared with $2.6 million, or 0.2% of total revenues, for the nine months ended March 30, 2018. The increase was primarily due to the higher weighted average interest rate compared to the same period in the last year
and an increase in the average balance of our outstanding cash.

[0001193125-19-139609:mdna:97]
[same as prior period, unchanged from 0001193125-19-028336:mdna:99]

[0001193125-19-139609:mdna:98]
Our interest expense increased by $0.6 million to $1.4 million for the three months ended March 29, 2019, compared with
$0.8 million for the three months ended March 30, 2018. The increase was due to a $0.1 million decrease in interest expense on our term loan, which was offset by the unrealized loss of $0.7 million for mark-to-market of interest rate swap related to our term loan.

[0001193125-19-139609:mdna:99]
Our interest expense increased by $1.2 million to $3.7 million for the nine months ended March 29, 2019, compared with
$2.5 million for the nine months ended March 30, 2018. The increase was due to a $0.4 million decrease in interest expense on our term loan, which was offset by the unrealized loss of $1.6 million for mark-to-market of interest rate swap related to our term loan.

[0001193125-19-139609:mdna:100]
Foreign exchange loss, net.

[0001193125-19-139609:mdna:101]
We recorded foreign exchange loss, net of $3.1 million for the three months ended March 29, 2019, compared with a $2.4 million
loss for the three months ended March 30, 2018. The increase was mainly due to unrealized loss of $1.0 million for mark-to-market of forward contracts related
to hedging of Thai Baht spending, as Thai Baht was depreciated as of March 29, 2019.

[0001193125-19-139609:mdna:102]
We recorded foreign exchange loss, net of
$0.4 million for the nine months ended March 29, 2019, compared with a $5.7 million loss for the nine months ended March 30, 2018. The decrease was due to realized foreign exchange gain from receipts and payments of
$0.8 million for the nine months ended March 29, 2019 as compared to $4.4 million realized foreign exchange loss from receipts and payments for the nine months ended March 30, 2018.

[0001193125-19-139609:mdna:103]
[same as prior period, unchanged from 0001193125-19-028336:mdna:104]

[0001193125-19-139609:mdna:104]
We recorded income before income taxes of $30.1 million and $92.1 million for the three and nine months ended March 29, 2019,
respectively, compared with $22.5 million and $66.2 million for the three and nine months ended March 30, 2018, respectively.

[0001193125-19-139609:mdna:105]
[same as prior period, unchanged from 0001193125-19-028336:mdna:106]

[0001193125-19-139609:mdna:106]
Our
provision for income tax reflects an effective tax rate of 5.2% and 6.2% for the three months ended March 29, 2019 and March 30, 2018, respectively. The decrease was primarily due to the fact that we had higher income derived from a
“no tax” jurisdiction during the three months ended March 29, 2019 as compared to the three months ended March 30, 2018.

[0001193125-19-139609:mdna:107]
Our provision for income tax reflects an effective tax rate of 5.2% and 6.3% for the nine months ended March 29, 2019 and March 30,
2018, respectively. The decrease was primarily due to the fact that we had higher income derived from a “no tax” jurisdiction during the nine months ended March 29, 2019 as compared to the three months ended March 30, 2018.

[0001193125-19-139609:mdna:108]
[same as prior period, unchanged from 0001193125-19-028336:mdna:109]

[0001193125-19-139609:mdna:109]
We recorded net income of $28.6 million, or 7.1% of total revenues, for the three months ended March 29, 2019, compared with
$21.1 million, or 6.4% of total revenues, for the three months ended March 30, 2018. The increase was primarily due to (1) an increase in gross profit of $9.8 million due to an increase in revenue and effective cost control, and
(2) a net increase in interest income and expense of $0.4 million, partially offset by (1) a net increase in SG&A expenses of $1.7 million, (2) an increase in expenses related to reduction in workforce of
$0.3 million, and (3) a net increase in foreign exchange loss of $0.6 million.

[0001193125-19-139609:mdna:110]
We recorded net income of
$88.0 million, or 7.5% of total revenues, for the nine months ended March 29, 2019, compared with $61.4 million, or 5.8% of total revenues, for the nine months ended March 30, 2018. The increase was primarily due to (1) an
increase in gross profit of $18.2 million due to an increase of revenue, (2) a decrease in expenses related to reduction in workforce of $1.0 million, (3) a net increase in interest income and expense of $1.0 million, and
(4) a net decrease in foreign exchange loss of $5.3 million.

[0001193125-19-139609:mdna:111]
[same as prior period, unchanged from 0001193125-19-028336:mdna:112]

[0001193125-19-139609:mdna:112]
We recorded other comprehensive income of $1.0 million, or 0.3% of total revenues, for the three months ended March 29, 2019,
compared with other comprehensive income of $0.2 million, or 0.1% of total revenues, for the three months ended March 30, 2018. The increase of $0.8 million was primarily due to an increase in net unrealized gain on available-for-sale securities of $1.1 million, partially offset by a decrease in foreign currency translation adjustments of $0.3 million.

[0001193125-19-139609:mdna:113]
We recorded other comprehensive income of $1.2 million, or 0.1% of total revenues, for the nine months ended March 29, 2019,
compared with other comprehensive income of $0.3 million, or 0.0% of total revenues, for the nine months ended March 30, 2018. The increase of $0.9 million was primarily due to an increase in net unrealized gain on available-for-sale securities of $2.5 million, partially offset by a decrease in foreign currency translation adjustments of $1.6 million.

[0001193125-19-139609:mdna:114]
Liquidity and Capital Resources

[0001193125-19-139609:mdna:115]
Cash Flows and
Working Capital

[0001193125-19-139609:mdna:116]
We primarily finance our operations through cash flow from operations. As of March 29, 2019 and
March 30, 2018, we had cash, cash equivalents, and short-term investments of $408.9 million and $311.9 million, respectively, and outstanding debt of $61.8 million and $65.1 million, respectively.

[0001193125-19-139609:mdna:117]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of
three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents for the three and nine months ended March 29, 2019 was 2.3% and 1.9%, respectively, and for the
three and nine months ended March 30, 2018 was 1.2% and 1.1%, respectively.

[0001193125-19-139609:mdna:118]
Our cash investments are made in accordance with an
investment policy approved by the Audit Committee of our board of directors. In general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an
effective maturity that exceeds three years. Our investments in fixed income securities are primarily classified as available-for-sale and are recorded at fair value.
The cost of securities sold is based on the specific identification method. Unrealized gains and losses on these securities are recorded as other comprehensive income (loss) and are reported as a separate component of shareholders’ equity.

[0001193125-19-139609:mdna:119]
During the nine months ended March 29, 2019, we repaid a term loan of $2.4 million under our Facility Agreement; as a result, as of
March 29, 2019, we had a long-term borrowing of $61.8 million under our Facility Agreement. We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations.
To better manage our cash on hand, we held investments in short-term marketable securities, liquidity fund, certificates of deposit and time deposit of $242.5 million as of March 29, 2019.

[0001193125-19-139609:mdna:120]
We believe that our current cash and cash equivalents, short-term investments, cash flow from operations, and funds available through our
credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of
this Quarterly Report on Form 10-Q.

[0001193125-19-139609:mdna:121]
We also believe that our current manufacturing capacity is sufficient to meet our
anticipated production requirements for at least the next few quarters.

[0001193125-19-139609:mdna:122]
The following table shows our cash flows for the periods
indicated:

[0001193125-19-139609:mdna:123]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 29,2019 |  |  | March 30,2018 |  |
| Net cash provided by operating activities |  | $ | 105,504 |  |  | $ | 89,794 |  |
| Net cash used in investing activities |  | $ | (79,045 | ) |  | $ | (48,926 | ) |
| Net cash used in financing activities |  | $ | (22,063 | ) |  | $ | (31,940 | ) |
| Net increase in cash, cash equivalents and restricted cash |  | $ | 4,396 |  |  | $ | 8,928 |  |

[0001193125-19-139609:mdna:124]
[same as prior period, unchanged from 0001193125-19-028336:mdna:125]

[0001193125-19-139609:mdna:125]
Net cash provided by operating activities increased by $15.7 million, or 17.5%, to $105.5 million for the nine months ended
March 29, 2019, compared with net cash provided by operating activities of $89.8 million for the nine months ended March 30, 2018. This increase was primarily due to (1) an increase in net income of $26.6 million, (2) a
decrease of $60.1 million in payments to trade accounts payable due to better working capital management, and (3) an increase in income tax payable of $3.6 million primarily from higher taxable income. These increases were offset by
(1) an increase of $39.4 million from trade accounts receivable due to an increase in revenues, and (2) an increase in inventory of $35.7 million primarily due to an increase in work in process resulting from an increase in
customer demand.

[0001193125-19-139609:mdna:126]
[same as prior period, unchanged from 0001193125-19-028336:mdna:127]

[0001193125-19-139609:mdna:127]
Net cash used in investing activities increased by $30.1 million, or 61.6%, to $79.0 million for the nine months ended March 29,
2019, compared with net cash used in investing activities of $48.9 million for the nine months ended March 30, 2018. This increase was primarily due to net cash invested in short-term investments of $46.6 million; offset by a decrease
of investments in property, plant and equipment of $15.1 million primarily due to no new major investments.

[0001193125-19-139609:mdna:128]
[same as prior period, unchanged from 0001193125-19-028336:mdna:129]

[0001193125-19-139609:mdna:129]
Net cash used in financing activities decreased by $9.9 million, or 30.9%, to $22.0 million for the nine months ended
March 29, 2019, compared with net cash used in financing activities of $31.9 million for the nine months ended March 30, 2018. This decrease was primarily due to (1) a decrease of $1.0 million in payments of a short-term
loan, (2) a decrease of $7.8 million in payments of a long-term loan; and (3) a decrease of $17.0 million in payments to repurchase our ordinary shares. These decreases were offset by (1) the release of restricted cash in
connection with a business acquisition of $3.5 million, (2) an increase in withholding tax related to net share settlement of restricted share units of $6.4 million, (3) a decrease in cash received from issuance of ordinary
shares under employee share option plans of $1.0 million, and (4) a decrease in proceeds of a short-term loan from a bank of $5.0 million.

[0001193125-19-139609:mdna:130]
[same as prior period, unchanged from 0001193125-19-028336:mdna:131]

[0001193125-19-139609:mdna:131]
[same as prior period, unchanged from 0001193125-19-028336:mdna:132]

[0001193125-19-139609:mdna:132]
[same as prior period, unchanged from 0001193125-19-028336:mdna:133]

[0001193125-19-139609:mdna:133]
[same as prior period, unchanged from 0001193125-19-028336:mdna:134]
