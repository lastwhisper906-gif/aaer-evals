# FN notes — 0001193125-19-139609


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001193125-19-139609:notes:1]
Basis of presentation

[0001193125-19-139609:notes:2]
The accompanying condensed consolidated financial statements for Fabrinet as of March 29, 2019 and for the three and nine months ended March 29, 2019 and March 30, 2018 include normal recurring adjustments, necessary for a fair statement of the financial statements set forth herein, in accordance with accounting principles generally accepted in the United States of America (“U.S. GAAP”) for interim financial information and the rules and regulations of the Securities and Exchange Commission (“SEC”). Accordingly, such information does not include all of the information and footnotes required by U.S. GAAP for annual financial statements. For further information, please refer to the consolidated financial statements and footnotes thereto included in Fabrinet’s Annual Report on Form 10-K for the year ended June 29, 2018.

[0001193125-19-139609:notes:3]
The balance sheet as of June 29, 2018 has been derived from the audited financial statements at that date but does not include all of the information and footnotes required by U.S. GAAP for complete financial statements. The results for the three and nine months ended March 29, 2019 may not be indicative of results for the year ending June 28, 2019 or any future periods.


## fn:ChangesInAccountingPolicyTextBlock

[0001193125-19-139609:notes:4]
Changes in Accounting Policies

[0001193125-19-139609:notes:5]
Except for the adoption of the new revenue recognition accounting standard described below and as disclosed in Note 3—Revenues, the Company has consistently applied the accounting policies to all periods presented in these condensed consolidated financial statements.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-19-139609:notes:6]
Adoption of New Accounting Standard

[0001193125-19-139609:notes:7]
On June 30, 2018, the Company adopted Revenue from Contracts with Customers (Topic 606), which created Accounting Standards Codification Topic 606 (“ASC 606”), using the modified retrospective method applied to those contracts which were not completed as of June 29, 2018. The modified retrospective method requires the Company to recognize the cumulative effect of the adoption of ASC 606, for all contracts with customers, to the opening balance of equity at June 30, 2018. Accordingly, the Company’s comparative financial information as of June 29, 2018 has not been adjusted and continues to be reported under ASC 605, Revenue Recognition (“ASC 605”).

[0001193125-19-139609:notes:8]
The cumulative effect adjustment recorded was based on the timing difference of revenue recognition between ASC 605 and ASC 606 related to certain manufacturing contracts with vendor-managed inventory arrangements. Under ASC 605, revenue for such contracts was recognized at the earlier of when the inventory was consumed by the customers or if not consumed, on the expiration of time specified in the contract. On adoption of ASC 606, revenue is recognized when inventory is shipped to customers.

[0001193125-19-139609:notes:9]
The following table shows the impact of adoption of ASC 606 on the adoption date of June 29, 2018 on the condensed consolidated balance sheets:

[0001193125-19-139609:notes:10]
Condensed Consolidated Balance Sheets

[0001193125-19-139609:notes:11]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | Balance atJune 29, 2018 |  |  | Adjustment |  |  | Balance atJune 30, 2018 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract assets |  | $ | — |  |  | $ | 9,877 | (1) |  | $ | 9,877 |  |
| Inventory, net |  | $ | 257,687 |  |  | $ | (8,672 | )(2) |  | $ | 249,015 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 632,423 |  |  | $ | 1,205 | (3 |  | $ | 633,628 |  |

[0001193125-19-139609:notes:12]
|  | (1) | Majority of adjustment relates to certain manufacturing contracts with vendor-managed inventory arrangements for which revenue was recognized on shipment. |

[0001193125-19-139609:notes:13]
|  | (2) | Adjustment relates to reduction of finished goods inventory for certain vendor-managed inventory arrangements. |

[0001193125-19-139609:notes:14]
|  | (3) | Adjustment relates to cumulative effect adjustment upon adoption of ASC 606. |


## fn:DescriptionOfNewAccountingPronouncementsNotYetAdoptedPolicyTextBlock

[0001193125-19-139609:notes:15]
New Accounting Pronouncements – not yet adopted by the Company

[0001193125-19-139609:notes:16]
In March 2019, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2019-01, “Leases (Topic 842), Codification Improvements.” This ASU provided guidance transition disclosure in the annual period in which a change in accounting principle is made. For public business entities, this update is effective for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its consolidated financial statements.

[0001193125-19-139609:notes:17]
In August 2018, the FASB issued ASU 2018-13, “Fair Value Measurement (Topic 820), Disclosure Framework – Changes to the Disclosure Requirements for Fair Value Measurement.” This ASU is intended to improve the effectiveness of disclosures in the notes to the financial statements including 1) the development of a framework that promotes consistent decisions by the FASB about disclosure requirements and 2) the appropriate exercise of discretion by reporting entities. The amendment modifies the disclosure requirements on transferring between level 1 and level 2 and valuation processes of level 3 fair value measurements. The amendments in this update are effective for all entities for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company is currently evaluating the impact of the adoption of this update on its consolidated financial 
statements.

[0001193125-19-139609:notes:18]
In July 2018, the FASB issued ASU 2018-11, “Leases (Topic 842), Target Improvements.” This ASU provided guidance on comparative reporting requirements for initial adoption. This ASU also provides additional guidance for lessors, on separating lease and non-lease components in a contract and allocating the consideration in the contract to the separate components. For public business entities, this update is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its consolidated financial statements.

[0001193125-19-139609:notes:19]
In July 2018, the FASB issued ASU 2018-10, “Codification Improvements to Topic 842, Leases.” The amendment in this update affects narrow aspects of the guidance issued in the amendments in update 2016-02 on various matters. For public business entities, this update is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early adoption is permitted. The Company is currently evaluating the impact of the adoption of this update on its consolidated financial statements.

[0001193125-19-139609:notes:20]
In January 2017, the FASB issued ASU 2017-04, “Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment.” This amendment modified the concept of impairment assessment from the condition that exists when the carrying amount of goodwill exceeds its implied fair value to the condition that exists when the carrying amount of a reporting unit exceeds its fair value. Public companies that are SEC filers should adopt the amendment for annual and any interim goodwill impairment tests in fiscal years beginning after December 15, 2019. Early adoption is permitted for interim or annual goodwill impairment tests performed on testing dates after January 1, 2017. The Company does not expect the amendments will impact its consolidated financial statements.

[0001193125-19-139609:notes:21]
In February 2016, the FASB issued ASU 2016-02, “Lease (Topic 842).” The core principle of Topic 842 is that a lessee should recognize the lease assets and liabilities that arise from leases in the statement of financial position. For public business entities, this update is effective for fiscal years beginning after December 15, 2018, including interim periods within those fiscal years. Early application is permitted. The Company is currently evaluating the impact of the adoption of this update on its consolidated financial statements.

[0001193125-19-139609:notes:22]
New Accounting Pronouncements – adopted by the Company

[0001193125-19-139609:notes:23]
In November 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2017-14, “Income Statement – Reporting Comprehensive Income (Topic 220), Revenue Recognition (Topic 605), and Revenue from Contracts with Customers (Topic 606): Amendments to SEC Paragraphs Pursuant to the Staff Accounting Bulletin (“SAB”) No. 116 and SEC Release No. 33-10403”. This ASU amended, superseded and added certain SEC paragraphs in Topic 220, Topic 605 and Topic 606 to reflect the August 2017 issuance of SEC Staff Accounting Bulletin (SAB) 116 and SEC Release No. 33-10403. The SEC staff issued SAB 116 to align its revenue guidance with Accounting Standards Codification (ASC) 606. For public business entities, this update is effective for fiscal years beginning after December 15, 2017, including interim periods within those fiscal years. Early application is permitted. The Company adopted this standard along with the implementation of ASC 606 effective June 30, 2018 with immaterial impact to the unaudited condensed consolidated financial statements.

[0001193125-19-139609:notes:24]
In September 2017, the FASB issued ASU 2017-13, “Revenue Recognition (Topic 605), Revenue from Contracts with Customers (Topic 606), Leases (Topic 840), and Leases (Topic 842): Amendments to SEC Paragraphs Pursuant to the Staff Announcement at the July 20, 2017 EITF Meeting and Rescission of Prior SEC Staff Announcements and Observer Comments.” The amendment delays the mandatory adoption of Topic 606 and Topic 842 for certain entities, revises the guidance related to performance-based incentive fees in Topic 605 and revises the guidance related to leases in Topic 840 and Topic 842. The revisions to the lease guidance eliminate language specific to certain sale-leaseback arrangements, guarantees of lease residual assets and loans made by lessees to owner-lessors. Also included is an amendment to Topic 842 to retain the guidance in Topic 840 covering the impact of changes in tax rates on investments in leveraged leases. This guidance, which is effective immediately, generally relates to the adoption of Topic 606 and Topic 842. The Company adopted this standard along with the implementation of ASC 606 effective June 30, 2018 with immaterial impact to the unaudited condensed consolidated financial statements.

[0001193125-19-139609:notes:25]
In January 2017, the FASB issued ASU 2017-03, “Accounting Changes and Error Corrections (Topic 250) and Investments – Equity Method and Joint Ventures (Topic 323): Accounting for Investments in Qualified Affordable Housing Projects: Amendments to SEC Paragraphs Pursuant to Staff Announcements at the September 22, 2016 and November 17, 2016 EITF Meetings.” The amendment provides guidance to the Company in relation to the disclosure of the impact that ASU 2014-09, ASU 2016-02 and ASU 2016-13 will have on the Company’s financial statements when adopted. The Company adopted this standard along with the implementation of ASC 606 effective June 30, 2018 with immaterial impact to the unaudited condensed consolidated financial statements.

[0001193125-19-139609:notes:26]
In August 2016, the FASB issued ASU 2016-15, “Classification of Certain Cash Receipts and Cash Payments (a consensus of the Emerging Issues Task Force).” The amendments in this ASU provide guidance on the presentation of certain cash receipts and cash payments in the statement of cash flows in order to reduce diversity in existing practice. The amendments in ASU 2016-15 are effective for public business entities for fiscal years beginning after December 15, 2017, and interim periods within those fiscal years. Early adoption is permitted, including adoption in an interim period. The Company adopt this new update effective June 30, 2018 with no impact to the unaudited condensed consolidated financial statements.


## us-gaap:EarningsPerShareTextBlock

[0001193125-19-139609:notes:27]
[same as prior period, unchanged from 0001193125-19-028336:notes:74]

[0001193125-19-139609:notes:28]
[same as prior period, unchanged from 0001193125-19-028336:notes:75]

[0001193125-19-139609:notes:29]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands except per share amounts) |  | March 29,2019 |  |  | March 30,2018 |  |  | March 29,2019 |  |  | March 30,2018 |  |
| Net income attributable to shareholders |  | $ | 28,635 |  |  | $ | 21,053 |  |  | $ | 87,998 |  |  | $ | 61,399 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  | 36,891 |  |  |  | 37,275 |  |  |  | 36,786 |  |  |  | 37,400 |  |
| Incremental shares arising from the assumed exercise of share options and vesting of restricted share units (thousands of shares) |  |  | 648 |  |  |  | 780 |  |  |  | 597 |  |  |  | 725 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 37,539 |  |  |  | 38,055 |  |  |  | 37,383 |  |  |  | 38,125 |  |
| Basic earnings per ordinary share |  | $ | 0.78 |  |  | $ | 0.56 |  |  | $ | 2.39 |  |  | $ | 1.64 |  |
| Diluted earnings per ordinary share |  | $ | 0.76 |  |  | $ | 0.55 |  |  | $ | 2.35 |  |  | $ | 1.61 |  |
| Outstanding performance share units excluded from the computation of diluted earnings per ordinary share (thousands of shares) (1) |  |  | 401 |  |  |  | 284 |  |  |  | 401 |  |  |  | 284 |  |

[0001193125-19-139609:notes:30]
|  | (1) | Outstanding performance share units were not included in the computation of diluted earnings per ordinary shares because they are not expected to vest based on the Company’s current assessment of the related performance obligations. |

[0001193125-19-139609:notes:31]
As of March 29, 2019 and March 30, 2018, there were no anti-dilutive share options.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-19-139609:notes:32]
|  | 17. | Business segments and geographic information |

[0001193125-19-139609:notes:33]
Operating segments are defined as components of an enterprise for which separate financial information is available that is evaluated regularly by the chief operating decision maker in deciding how to allocate resources and in assessing performance. The Company’s chief operating decision maker is Fabrinet’s chief executive officer. As of March 29, 2019, the Company operated and internally managed a single operating segment. Accordingly, the Company does not accumulate discrete information with respect to separate product lines and does not have separate reportable segments.

[0001193125-19-139609:notes:34]
Total revenues are attributed to a particular geographic area based on the bill-to-location of the customers. The Company operates primarily in three geographic regions: North America, Asia-Pacific and Europe. The following table presents total revenues by geographic regions:

[0001193125-19-139609:notes:35]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 29,2019 |  |  | March 30,2018 |  |  | March 29,2019 |  |  | March 30,2018 |  |
| North America |  | $ | 195,504 |  |  | $ | 160,926 |  |  | $ | 558,028 |  |  | $ | 470,084 |  |
| Asia-Pacific |  |  | 151,263 |  |  |  | 122,631 |  |  |  | 469,921 |  |  |  | 395,848 |  |
| Europe |  |  | 52,184 |  |  |  | 48,656 |  |  |  | 151,259 |  |  |  | 160,666 |  |
|  |  | $ | 398,951 |  |  | $ | 332,213 |  |  | $ | 1,179,208 |  |  | $ | 1,026,598 |  |

[0001193125-19-139609:notes:36]
As of March 29, 2019 and March 30, 2018, the Company had approximately $31.7 million and $33.7 million, respectively, of long-lived assets based in North America, with the substantial remainder of assets based in Asia-Pacific and Europe.

[0001193125-19-139609:notes:37]
[same as prior period, unchanged from 0001193125-19-028336:notes:37]

[0001193125-19-139609:notes:38]
The Company had two customers that each contributed to 10% or more of the Company’s total trade accounts receivable as of both March
 29, 2019 and June 29, 2018.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-19-139609:notes:39]
|  | 16. | Commitments and contingencies |

[0001193125-19-139609:notes:40]
Bank guarantees

[0001193125-19-139609:notes:41]
As of March 29, 2019 and June 29, 2018, there were outstanding bank guarantees given by a bank on behalf of our subsidiary in Thailand for electricity usage and other normal business amounting to $1.6 million and $1.5 million, respectively.

[0001193125-19-139609:notes:42]
Operating lease commitments

[0001193125-19-139609:notes:43]
The Company leases a portion of its capital equipment, vehicles, and certain land and buildings for its facilities in Thailand, the Cayman Islands, China, the United States and the United Kingdom under operating lease arrangements that expire in various years through 2023. Rental expense under these operating leases amounted to $1.4 million and $1.3 million for the nine months ended March 29, 2019 and March 30, 2018, respectively.

[0001193125-19-139609:notes:44]
As of March 29, 2019, the future minimum lease payments due under non-cancelable operating leases during each fiscal year were as follows:

[0001193125-19-139609:notes:45]
| (amount in thousands) |  |  |  |
| 2019 (remaining three months) |  | $ | 450 |  |
| 2020 |  |  | 1,739 |  |
| 2021 |  |  | 1,336 |  |
| 2022 |  |  | 1,208 |  |
| 2023 |  |  | 1,182 |  |
| Thereafter |  |  | 227 |  |
| Total minimum operating lease payments |  | $ | 6,142 |  |

[0001193125-19-139609:notes:46]
Capital lease commitments

[0001193125-19-139609:notes:47]
In connection with the acquisition of Fabrinet UK, the Company assumed the capital lease commitments of several machines and equipment, with various expiration dates until September 2020. The equipment can be purchased at the determined prices upon expiration of such contracts.

[0001193125-19-139609:notes:48]
As of March 29, 2019, the future minimum lease payments due under non-cancelable capital leases during each fiscal year were as follows:

[0001193125-19-139609:notes:49]
| (amount in thousands) |  |  |  |
| 2019 (remaining three months) |  | $ | 110 |  |
| 2020 |  |  | 410 |  |
| 2021 |  |  | 105 |  |
| Total minimum capital lease payments |  | $ | 625 |  |

[0001193125-19-139609:notes:50]
Purchase obligations

[0001193125-19-139609:notes:51]
Purchase obligations represent legally-binding commitments to purchase inventory and other commitments made in the normal course of business to meet operational requirements. Although open purchase orders are considered enforceable and legally binding, their terms generally give the Company the option to cancel, reschedule and/or adjust its requirements based on its business needs prior to the delivery of goods or performance of services. Obligations to purchase inventory and other commitments are generally expected to be fulfilled within one year.

[0001193125-19-139609:notes:52]
As of March 29, 2019, the Company had an outstanding commitment to third parties of $8.6 million.

[0001193125-19-139609:notes:53]
Indemnification of directors and officers

[0001193125-19-139609:notes:54]
Cayman Islands law does not limit the extent to which a company’s memorandum and articles of association may provide for indemnification of directors and officers, except to the extent any such provision may be held by the Cayman Islands courts to be contrary to public policy, such as to provide indemnification against civil fraud or the consequences of committing a crime. Fabrinet’s amended and restated memorandum and articles of association provide for indemnification of directors and officers for actions, costs, charges, losses, damages and expenses incurred in their capacities as such, except that such indemnification does not extend to any matter in respect of any fraud or dishonesty that may attach to any of them.

[0001193125-19-139609:notes:55]
In accordance with Fabrinet’s form of indemnification agreement for its directors and officers, Fabrinet has agreed to indemnify its directors and officers against certain liabilities and expenses incurred by such persons in connection with claims by reason of their being such a director or officer. Fabrinet maintains a director and officer liability insurance policy that may enable it to recover a portion of any future amounts paid under the indemnification agreements.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-19-139609:notes:56]
|  | 14. | Shareholders’ equity |

[0001193125-19-139609:notes:57]
[same as prior period, unchanged from 0001193125-19-028336:notes:155]

[0001193125-19-139609:notes:58]
[same as prior period, unchanged from 0001193125-19-028336:notes:156]

[0001193125-19-139609:notes:59]
For the three months ended March 29, 2019, Fabrinet issued 78,072 ordinary shares upon the vesting of restricted share units, net of shares withheld.

[0001193125-19-139609:notes:60]
For the nine months ended March 29, 2019, Fabrinet issued 492,498 ordinary shares upon the vesting of restricted share units, net of shares withheld.

[0001193125-19-139609:notes:61]
[same as prior period, unchanged from 0001193125-19-028336:notes:159]

[0001193125-19-139609:notes:62]
[same as prior period, unchanged from 0001193125-19-028336:notes:160]

[0001193125-19-139609:notes:63]
In August 2017, the Company’s board of directors approved a share repurchase program to permit the Company to repurchase up to $30.0 million worth of its issued and outstanding ordinary shares in the open market in accordance with applicable rules and regulations. In February 2018, the Company’s board of directors approved a $30.0 million increase to the share repurchase authorization. During the three and nine months ended March 29, 2019, 100,000 shares were repurchased under the program, at an average price per share of $ 53.78, totaling $ 5.4 million. As of March 29, 2019, the Company had a remaining authorization to purchase up to an additional $12.2 million worth of its ordinary shares under the share repurchase program. Shares repurchased under the share repurchase program are held as treasury shares.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-19-139609:notes:64]
|  | 13. | Share-based compensation |

[0001193125-19-139609:notes:65]
[same as prior period, unchanged from 0001193125-19-028336:notes:163]

[0001193125-19-139609:notes:66]
[same as prior period, unchanged from 0001193125-19-028336:notes:164]

[0001193125-19-139609:notes:67]
The effect of recording share-based compensation expense for the three and nine months ended March 29, 2019 and March 30, 2018 was as follows:

[0001193125-19-139609:notes:68]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 29,2019 |  |  | March 30,2018 |  |  | March 29,2019 |  |  | March 30,2018 |  |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restricted share units |  |  | 3,621 |  |  |  | 3,904 |  |  |  | 11,650 |  |  |  | 13,338 |  |
| Performance share units |  |  | 803 |  |  |  | 1,422 |  |  |  | 1,723 |  |  |  | 4,366 |  |
| Total share-based compensation expense |  |  | 4,424 |  |  |  | 5,326 |  |  |  | 13,373 |  |  |  | 17,704 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 4,424 |  |  | $ | 5,326 |  |  | $ | 13,373 |  |  | $ | 17,704 |  |

[0001193125-19-139609:notes:69]
[same as prior period, unchanged from 0001193125-19-028336:notes:167]

[0001193125-19-139609:notes:70]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | March 29,2019 |  |  | March 30,2018 |  |  | March 29,2019 |  |  | March 30,2018 |  |
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cost of revenue |  | $ | 1,237 |  |  | $ | 1,564 |  |  | $ | 4,384 |  |  | $ | 5,277 |  |
| Selling, general and administrative expense |  |  | 3,187 |  |  |  | 3,762 |  |  |  | 8,989 |  |  |  | 12,427 |  |
| Total share-based compensation expense |  | $ | 4,424 |  |  | $ | 5,326 |  |  | $ | 13,373 |  |  | $ | 17,704 |  |

[0001193125-19-139609:notes:71]
The Company did not capitalize any share-based compensation expense as part of any asset costs during the three and nine months ended March 29, 2019 and March 30, 2018.

[0001193125-19-139609:notes:72]
[same as prior period, unchanged from 0001193125-19-028336:notes:170]

[0001193125-19-139609:notes:73]
Fabrinet maintains the following equity incentive plans: the Amended and Restated 2010 Performance Incentive Plan (the “2010 Plan”) and the 2017 Inducement Equity Incentive Plan (the “2017 Inducement Plan”).

[0001193125-19-139609:notes:74]
On December 14, 2017, Fabrinet’s shareholders approved an amendment to the 2010 Plan to increase the number of ordinary shares authorized for issuance under the 2010 Plan by 2,100,000 shares. As of March 29, 2019, there were an aggregate of 777,790 restricted share units outstanding and 455,358 performance share units outstanding under the 2010 Plan. As of March 29, 2019, there were 1,882,529 ordinary shares available for future grant under the 2010 Plan.

[0001193125-19-139609:notes:75]
On November 2, 2017, Fabrinet adopted the 2017 Inducement Plan with a reserve of 160,000 ordinary shares authorized for future issuance solely for the granting of inducement share options and equity awards to new key employees. The 2017 Inducement Plan was adopted without shareholder approval in reliance on the “employment inducement exemption” provided under the rules of the New York Stock Exchange. As of March 29, 2019, there were an aggregate of 36,490 restricted share units outstanding and 97,306 performance share units outstanding under the 2017 Inducement Plan. As of March 29, 2019, there were 14,041 ordinary shares available for future grant under the 2017 Inducement Plan.

[0001193125-19-139609:notes:76]
[same as prior period, unchanged from 0001193125-19-028336:notes:174]

[0001193125-19-139609:notes:77]
Fabrinet’s board of directors has the authority to determine the type of option and the number of shares subject to an option. Options generally vest and become exercisable over four years and expire, if not exercised, within seven years of the grant date. In the case of a grantee’s first grant, 25 percent of the underlying shares vest 12 months after the vesting commencement date and 1/
4
8 of the underlying shares vest monthly over each of the subsequent 
3
6 months. In the case of any additional grants to a grantee, 
1
/48 of the underlying shares vest monthly over four years, commencing one month after the vesting commencement date. Share options have been granted to directors and employees.

[0001193125-19-139609:notes:78]
The following summarizes share option activity under the 2010 Plan:

[0001193125-19-139609:notes:79]
|  |  | NumberofShares |  |  | Number ofExercisableOptions |  |  | Weighted-AverageExercisePrice |  |  | Weighted-AverageGrantDate FairValue |  |
| Balance as of June 29, 2018 |  |  | 2,900 |  |  |  | 2,900 |  |  | $ | 15.16 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Forfeited |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Expired |  |  | (2,900 | ) |  |  |  |  |  | $ | 15.16 |  |  |  |  |  |
| Balance as of March 29, 2019 |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |
| Balance as of June 30, 2017 |  |  | 96,688 |  |  |  | 96,688 |  |  | $ | 15.70 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (62,862 | ) |  |  |  |  |  | $ | 15.80 |  |  |  |  |  |
| Forfeited |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Expired |  |  | (1,500 | ) |  |  |  |  |  | $ | 25.05 |  |  |  |  |  |
| Balance as of March 30, 2018 |  |  | 32,326 |  |  |  | 32,326 |  |  | $ | 15.05 |  |  |  |  |  |

[0001193125-19-139609:notes:80]
As of March 29, 2019, there was no unrecognized compensation cost under the 2010 Plan.

[0001193125-19-139609:notes:81]
[same as prior period, unchanged from 0001193125-19-028336:notes:179]

[0001193125-19-139609:notes:82]
[same as prior period, unchanged from 0001193125-19-028336:notes:180]

[0001193125-19-139609:notes:83]
Restricted share units granted to employees generally vest in equal installments over three or four years on each anniversary of the vesting commencement date. Restricted share units granted to non-employee directors generally cliff vest 100% on the first of January, approximately one year from the grant date, provided the director continues to serve through such date.

[0001193125-19-139609:notes:84]
Performance share units granted to executives will vest, if at all, at the end of a two-year performance period based on the Company’s achievement of pre-defined performance criteria, which consist of revenue targets and non-U.S. GAAP gross margin targets. The actual number of performance share units that may vest at the end of a performance period ranges from
 0% to 100% of the award grant.

[0001193125-19-139609:notes:85]
The following table summarizes restricted share unit activity under the 2010 Plan and the 2017 Inducement Plan:

[0001193125-19-139609:notes:86]
|  |  | NumberofShares |  |  | Weighted-AverageGrantDateFair ValuePer Share |  |
| Balance as of June 29, 2018 |  |  | 1,073,580 |  |  | $ | 35.19 |  |
| Granted |  |  | 341,748 |  |  | $ | 48.77 |  |
| Issued |  |  | (496,854 | ) |  | $ | 34.08 |  |
| Forfeited |  |  | (104,194 | ) |  | $ | 38.50 |  |
| Balance as of March 29, 2019 |  |  | 814,280 |  |  | $ | 41.14 |  |
| Balance as of June 30, 2017 |  |  | 1,058,605 |  |  | $ | 31.59 |  |
| Granted |  |  | 474,777 |  |  | $ | 36.04 |  |
| Issued |  |  | (337,937 | ) |  | $ | 28.01 |  |
| Forfeited |  |  | (95,981 | ) |  | $ | 33.52 |  |
| Balance as of March 30, 2018 |  |  | 1,099,464 |  |  | $ | 34.44 |  |

[0001193125-19-139609:notes:87]
The following table summarizes performance share unit activity under the 2010 Plan and the 2017 Inducement Plan:

[0001193125-19-139609:notes:88]
|  |  | NumberofShares |  |  | Weighted-AverageGrantDateFair ValuePer Share |  |
| Balance as of June 29, 2018 |  |  | 605,892 |  |  | $ | 38.41 |  |
| Granted |  |  | 201,994 |  |  | $ | 48.02 |  |
| Issued |  |  | (227,268 | ) |  | $ | 40.48 |  |
| Forfeited |  |  | (27,954 | ) |  | $ | 39.35 |  |
| Balance as of March 29, 2019 |  |  | 552,664 |  |  | $ | 41.02 |  |
| Balance as of June 30, 2017 |  |  | 227,268 |  |  | $ | 40.48 |  |
| Granted |  |  | 378,624 |  |  | $ | 37.16 |  |
| Issued |  |  | — |  |  |  | — |  |
| Forfeited |  |  | — |  |  |  | — |  |
| Balance as of March 30, 2018 |  |  | 605,892 |  |  | $ | 38.41 |  |

[0001193125-19-139609:notes:89]
As of March 29, 2019, there was $14.7 million and $2.6 million of unrecognized share-based compensation expense related to restricted share units and performance share units, respectively, under the 2010 Plan and the 2017 Inducement Plan that is expected to be recorded over a weighted-average period of 2.59 years and 1.41 years, respectively.

[0001193125-19-139609:notes:90]
For the nine months ended March 29, 2019 and March 30, 2018, the Company withheld an aggregate of 231,624 shares and 101,080 shares, respectively, upon the vesting of restricted share units, based upon the closing share price on the vesting date, to settle the employees’ minimum statutory obligation for the applicable income and other employment taxes. For the nine months ended March 29, 2019 and March 30, 2018, the Company then remitted cash of $10.4 million and $4.0 million, respectively, to the appropriate tax authorities, and presented it as a financing activity within the condensed consolidated statements of cash flows. The payment had the effect on shares issued by the Company as it reduced the number of shares that would have been issued on the vesting date and was recorded as a reduction of additional paid-in capital.


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001193125-19-139609:notes:91]
[same as prior period, unchanged from 0001193125-19-028336:notes:79]

[0001193125-19-139609:notes:92]
[same as prior period, unchanged from 0001193125-19-028336:notes:80]

[0001193125-19-139609:notes:93]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | CarryingCost |  |  | UnrealizedLoss |  |  | Cash andCashEquivalents |  |  | MarketableSecurities |  |  | OtherInvestments |  |
| As of March 29, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 160,494 |  |  | $ | — |  |  | $ | 160,494 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 5,913 |  |  |  | — |  |  |  | 5,913 |  |  |  | — |  |  |  | — |  |
| Liquidity fund |  |  | 20,387 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 20,387 |  |
| Certificates of deposit and time deposit |  |  | 26,027 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 26,027 |  |
| Corporate bonds and commercial papers |  |  | 130,418 |  |  |  | (154 | ) |  |  | — |  |  |  | 130,264 |  |  |  | — |  |
| U.S. agency and U.S. treasury securities |  |  | 65,895 |  |  |  | (89 | ) |  |  | — |  |  |  | 65,806 |  |  |  | — |  |
| Sovereign and municipal securities |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 409,134 |  |  | $ | (243 | ) |  | $ | 166,407 |  |  | $ | 196,070 |  |  | $ | 46,414 |  |
| As of June 29, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | 146,778 |  |  | $ | — |  |  | $ | 146,778 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 11,324 |  |  |  | — |  |  |  | 11,324 |  |  |  | — |  |  |  | — |  |
| Liquidity fund |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Certificates of deposit and time deposit |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 128,441 |  |  |  | (736 | ) |  |  | — |  |  |  | 127,705 |  |  |  | — |  |
| U.S. agency and U.S. treasury securities |  |  | 43,734 |  |  |  | (324 | ) |  |  | — |  |  |  | 43,410 |  |  |  | — |  |
| Sovereign and municipal securities |  |  | 3,185 |  |  |  | (31 | ) |  |  | — |  |  |  | 3,154 |  |  |  | — |  |
| Total |  | $ | 333,462 |  |  | $ | (1,091 | ) |  | $ | 158,102 |  |  | $ | 174,269 |  |  | $ | — |  |

[0001193125-19-139609:notes:94]
All highly liquid investments with original maturities of three months or less at the date of purchase are classified as cash equivalents. Management determines the appropriate classification of its investments at the time of purchase and re-evaluates the designations at each balance sheet date. The Company may sell certain of its short-term investments prior to their stated maturities for strategic reasons including, but not limited to, anticipation of credit deterioration and duration management. The maturities of the Company’s short-term investments generally range from three months to three years. The Company’s investments in marketable securities consist of investments in U.S. Treasuries and fixed income securities and have been classified and accounted for as available-for-sale.

[0001193125-19-139609:notes:95]
The following table summarizes the cost and estimated fair value of marketable securities classified as available-for-sale securities based on stated effective maturities as of March 29, 2019:

[0001193125-19-139609:notes:96]
| (amount in thousands) |  | Carrying Cost |  |  | Fair Value |  |
| Due within one year |  | $ | 63,149 |  |  | $ | 63,146 |  |
| Due between one to three years |  |  | 126,071 |  |  |  | 125,861 |  |
| Due after three years |  |  | 7,093 |  |  |  | 7,063 |  |
| Total |  | $ | 196,313 |  |  | $ | 196,070 |  |

[0001193125-19-139609:notes:97]
During the nine months ended March 29, 2019, the Company recognized a realized gain of $0.2 million from sales and maturities of available-for-sale securities.

[0001193125-19-139609:notes:98]
As of March 29, 2019, 
the Company considered the declines in market value of its short-term investments portfolio to be temporary in nature and did not consider any of its securities other-than-temporarily impaired. The Company typically invests in highly-rated securities, and its investment policy generally limits the amount of credit exposure to any one issuer. The policy requires investments generally to be investment grade, with the primary objective of minimizing the potential risk of principal loss. Fair values were determined for each individual security in the investment portfolio. When evaluating an investment for other-than-temporary impairment, the Company reviews factors such as the length of time and extent to which fair value has been below its cost basis, the financial condition of the issuer and any changes thereto, changes in market interest rates, and the Company’s intent to sell, or whether it is more likely than not it will be required to sell, the investment before recovery of the investment’s cost basis. No impairment losses were recorded for the nine months ended
 March 29, 2019.

[0001193125-19-139609:notes:99]
As of March 29, 2019, cash, 
cash equivalents, and short-term investments included bank deposits of
 $40.0 
million held in various financial institutions located in the United States in order to support the availability of the Facility Agreement (as defined in Note 11) and comply with covenants. Under the terms and conditions of the Facility Agreement, the Company must maintain cash, cash equivalents and/or marketable securities in an aggregate amount not less than $40.0 million in unencumbered deposits, and/or securities in accounts located in the United States at all times during the term of the Facility Agreement. As discussed in Note 11, the Company must comply with this covenant from and after the effective date of the Facility Agreement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-19-139609:notes:100]
|  | 12. | Income taxes |

[0001193125-19-139609:notes:101]
As of March 29, 2019 and June 29, 2018, the liability for uncertain tax positions including accrued interest and penalties was $1.8 million and $2.3 million, respectively.

[0001193125-19-139609:notes:102]
[same as prior period, unchanged from 0001193125-19-028336:notes:192]

[0001193125-19-139609:notes:103]
The Company’s effective tax rate is a function of the mix of tax rates in various jurisdictions. The Company is domiciled in the Cayman Islands. Under the current laws of the Cayman Islands, the Company is not subject to tax in the Cayman Islands on income or capital gains. The Company initially received this undertaking for a 20-year period ending August 24, 2019, but was recently granted a renewal until March 6, 2039.

[0001193125-19-139609:notes:104]
The Company’s effective tax rate for the three months ended March 29, 2019 and March 30, 2018 was 
5.2% and 6.2%, 
respectively, of net income. The decrease was primarily due to the fact that the Company had higher income derived from a “no tax” jurisdiction during the three months ended March 29, 2019 as compared with the three months ended March 30, 2018.

[0001193125-19-139609:notes:105]
The Company’s effective tax rate for the nine months ended March 29, 2019 and March 30, 2018 was 
5.2% and 6.3%, 
respectively, of net income. The decrease was primarily due to the fact that the Company had higher income derived from a “no tax” jurisdiction during the nine months ended March 29, 2019, as compared with the nine months ended March 30, 2018.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock

[0001193125-19-139609:notes:106]
The movements of long-term borrowing for the nine months ended March 29, 2019 and March 30, 2018 were as follows:

[0001193125-19-139609:notes:107]
|  |  | Nine Months Ended |  |
| (amount in thousands) |  | March 29,2019 |  |  | March 30,2018 |  |
| Opening balance |  | $ | 64,188 |  |  | $ | 36,400 |  |
| Repayments during the period |  |  | (2,438 | ) |  |  | (10,200 | ) |
| Closing balance |  | $ | 61,750 |  |  | $ | 26,200 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock

[0001193125-19-139609:notes:108]
As of March 29, 2019, future maturities of long-term borrowing during each fiscal year were as follows:

[0001193125-19-139609:notes:109]
| (amount in thousands) |  |  |  |
| 2019 (remaining three months) |  | $ | 813 |  |
| 2020 |  |  | 3,250 |  |
| 2021 |  |  | 3,250 |  |
| 2022 |  |  | 3,250 |  |
| 2023 |  |  | 51,187 |  |
| Total |  | $ | 61,750 |  |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock

[0001193125-19-139609:notes:110]
| (amount in thousands) |  | March 29,2019 |  |  | June 29,2018 |  |
| Expiring within one year |  | $ | — |  |  | $ | — |  |
| Expiring beyond one year |  | $ | 25,000 |  |  | $ | 25,000 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-19-139609:notes:111]
|  | 10. | Goodwill |

[0001193125-19-139609:notes:112]
[same as prior period, unchanged from 0001193125-19-028336:notes:92]

[0001193125-19-139609:notes:113]
| (amount in thousands) |  | Goodwill |  |
| Balance as of June 29, 2018 |  | $ | 3,828 |  |
| Foreign currency translation adjustment |  |  | (5 | ) |
| Balance as of March 29, 2019 |  | $ | 3,823 |  |
| Balance as of June 30, 2017 |  | $ | 3,806 |  |
| Foreign currency translation adjustment |  |  | 22 |  |
| Balance as of June 29, 2018 |  | $ | 3,828 |  |

[0001193125-19-139609:notes:114]
[same as prior period, unchanged from 0001193125-19-028336:notes:94]


## us-gaap:InventoryDisclosureTextBlock

[0001193125-19-139609:notes:115]
|  | 8. | Inventory |

[0001193125-19-139609:notes:116]
| (amount in thousands) |  | As ofMarch 29,2019 |  |  | As ofJune 29,2018 |  |
| Raw materials |  | $ | 104,322 |  |  | $ | 100,241 |  |
| Work in progress |  |  | 154,407 |  |  |  | 121,797 |  |
| Finished goods |  |  | 19,902 |  |  |  | 20,690 |  |
| Goods in transit |  |  | 9,638 |  |  |  | 17,516 |  |
|  |  |  | 288,269 |  |  |  | 260,244 |  |
| Less: Inventory obsolescence |  |  | (2,838 | ) |  |  | (2,557 | ) |
| Inventory, net |  | $ | 285,431 |  |  | $ | 257,687 |  |


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001193125-19-139609:notes:117]
|  | 7. | Trade accounts receivable, net |

[0001193125-19-139609:notes:118]
| (amount in thousands) |  | As ofMarch 29,2019 |  |  | As ofJune 29,2018 |  |
| Trade accounts receivable |  | $ | 265,182 |  |  | $ | 246,972 |  |
| Less: allowance for doubtful account |  |  | (72 | ) |  |  | (60 | ) |
| Trade accounts receivable, net |  | $ | 265,110 |  |  | $ | 246,912 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-19-139609:notes:119]
|  | 6. | Fair value of financial instruments |

[0001193125-19-139609:notes:120]
[same as prior period, unchanged from 0001193125-19-028336:notes:196]

[0001193125-19-139609:notes:121]
[same as prior period, unchanged from 0001193125-19-028336:notes:197]

[0001193125-19-139609:notes:122]
[same as prior period, unchanged from 0001193125-19-028336:notes:198]

[0001193125-19-139609:notes:123]
[same as prior period, unchanged from 0001193125-19-028336:notes:199]

[0001193125-19-139609:notes:124]
[same as prior period, unchanged from 0001193125-19-028336:notes:200]

[0001193125-19-139609:notes:125]
The following table provides details of the financial instruments measured at fair value on a recurring basis, including:

[0001193125-19-139609:notes:126]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of March 29, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 5,913 |  |  | $ | — |  |  | $ | 5,913 |  |
| Liquidity fund |  |  | — |  |  |  | 20,387 |  |  |  | — |  |  |  | 20,387 |  |
| Certificates of deposit and time deposit |  |  | — |  |  |  | 26,027 |  |  |  | — |  |  |  | 26,027 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 130,264 |  |  |  | — |  |  |  | 130,264 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 65,806 |  |  |  | — |  |  |  | 65,806 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Derivative assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | — |  |  | $ | 248,397 |  |  | $ | — |  |  | $ | 248,397 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 2,626 | (1) |  | $ | — |  |  | $ | 2,626 |  |
| Total |  | $ | — |  |  | $ | 2,626 |  |  | $ | — |  |  | $ | 2,626 |  |
| As of June 29, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 11,324 |  |  | $ | — |  |  | $ | 11,324 |  |
| Liquidity fund |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Certificates of deposit and time deposit |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 127,705 |  |  |  | — |  |  |  | 127,705 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 43,410 |  |  |  | — |  |  |  | 43,410 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 3,154 |  |  |  | — |  |  |  | 3,154 |  |
| Derivative assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | — |  |  | $ | 185,593 |  |  | $ | — |  |  | $ | 185,593 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 1,745 | (2) |  | $ | — |  |  | $ | 1,745 |  |
| Total |  | $ | — |  |  | $ | 1,745 |  |  |  | — |  |  | $ | 1,745 |  |

[0001193125-19-139609:notes:127]
| (1) | Foreign currency forward contracts with a notional amount of $98.0 million and Canadian dollars of $0.4 million. Foreign currency option contracts with a notional amount of $5.0 million. Interest rate swap agreement with a notional amount of $64.2 million subject to the Amortization Schedule—as of March 29, 2019, the outstanding amount was $61.8 million. |

[0001193125-19-139609:notes:128]
| (2) | Foreign currency forward contracts with a notional amount of $7.0 million and Canadian dollars of $0.4 million. Foreign currency option contracts with a notional amount of $30.0 million. |

[0001193125-19-139609:notes:129]
[same as prior period, unchanged from 0001193125-19-028336:notes:201]

[0001193125-19-139609:notes:130]
As a result of foreign currency rate fluctuations, the U.S. dollar equivalent values of the Company’s foreign currency denominated assets and liabilities also fluctuate. The Company uses foreign currency contracts to manage the foreign exchange risk associated with certain foreign currency denominated assets and liabilities and other foreign currency transactions. The Company minimizes the credit risk in derivative instruments by limiting its exposure to any single counterparty and by entering into derivative instruments only with counterparties that meet the Company’s minimum credit quality standard. As of March
 29, 2019, the Company recognized the fair value of foreign currency forward contracts and foreign currency option contracts of $1.0 
million 
and

[0001193125-19-139609:notes:131]
fair value of interest rate swap of $1.6 million as derivative liabilities in the condensed consolidated balance sheets under other current liabilities. As of June 29, 2018, the Company recognized the fair value of foreign currency forward contracts and foreign currency option contracts of $1.7 million as derivative liabilities in the consolidated balance sheets under other current liabilities.

[0001193125-19-139609:notes:132]
As of March 29, 2019 and June 29, 2018, the Company had no foreign currency forward contracts designated as cash flow hedges.

[0001193125-19-139609:notes:133]
On July 25, 2018, 
the Company entered into an interest rate swap agreement (the “Swap Agreement”), which the Company did not designate as a hedging instrument. The Swap Agreement was used to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. The Swap Agreement has a notional amount of
 $64.2 million and it effectively converts the floating interest rate of the term loans under the Facility Agreement to the fixed interest rate of 2.86% per annum through maturity in June 2023. The swap transactions are due and settled monthly. During the nine months ended March 29, 2019, 
the Company included a net unrealized loss of $1.6 million from the Swap Agreement in interest expense in the condensed consolidated statements of operations and comprehensive income.

[0001193125-19-139609:notes:134]
As of March 29, 2019, 
the Company had forty-five outstanding foreign currency forward contracts with an aggregate notional amount of
 $98.0 
million, one outstanding U.S. dollar foreign currency option contract with a notional amount of
 $5.0 million and one outstanding Canadian dollars forward contract with notional amount of $0.4 
million with maturity dates ranging from April to

[0001193125-19-139609:notes:135]
August
 2019. These foreign currency forward contracts and option contracts were not designated for hedge accounting and were used to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht and Canadian dollars. During the nine months ended March 29, 2019, the Company included an unrealized 
gain 
of

[0001193125-19-139609:notes:136]
$1.5 
million 
from

[0001193125-19-139609:notes:137]
changes in the fair value of foreign currency contracts in earnings as foreign exchange loss, net in the condensed consolidated statements of operations and comprehensive income.

[0001193125-19-139609:notes:138]
As of March 30, 2018, the Company had six outstanding foreign currency forward contracts with an aggregate notional amount of $14.0 million and Canadian dollars 0.1 
million, with maturity dates ranging from April to June
 2018. These foreign currency forward contracts were not designated for hedge accounting and were used to hedge fluctuations in the U.S. dollar value of forecasted transactions denominated in Thai baht and Canadian dollars. During the nine months ended March 30, 2018, the Company included an unrealized loss of $26 thousand from changes in the fair value of foreign currency contracts in earnings as foreign exchange loss, net in the condensed consolidated statements of operations and comprehensive income.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-19-139609:notes:139]
|  | 9. | Intangibles |

[0001193125-19-139609:notes:140]
[same as prior period, unchanged from 0001193125-19-028336:notes:103]

[0001193125-19-139609:notes:141]
| (amount in thousands) |  | GrossCarryingAmount |  |  | AccumulatedAmortization |  |  | ForeignCurrencyTranslationAdjustment |  |  | Net |  |
| As of March 29, 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 6,450 |  |  | $ | (4,740 | ) |  | $ | — |  |  | $ | 1,710 |  |
| Customer relationships |  |  | 4,373 |  |  |  | (1,934 | ) |  |  | (38 | ) |  |  | 2,401 |  |
| Backlog |  |  | 119 |  |  |  | (118 | ) |  |  | — |  |  |  | 1 |  |
| Total intangibles |  | $ | 10,942 |  |  | $ | (6,792 | ) |  | $ | (38 | ) |  | $ | 4,112 |  |
| As of June 29, 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 6,269 |  |  | $ | (4,324 | ) |  | $ | — |  |  | $ | 1,945 |  |
| Customer relationships |  |  | 4,373 |  |  |  | (1,413 | ) |  |  | (42 | ) |  |  | 2,918 |  |
| Backlog |  |  | 119 |  |  |  | (101 | ) |  |  | (1 | ) |  |  | 17 |  |
| Total intangibles |  | $ | 10,761 |  |  | $ | (5,838 | ) |  | $ | (43 | ) |  | $ | 4,880 |  |

[0001193125-19-139609:notes:142]
The Company recorded amortization expense relating to intangibles of $0.3 million and $0.5 million for the three months ended March 29, 2019 and March 30, 2018, respectively, and $0.9 million and $1.4 million for the nine months ended March 29, 2019 and March 30, 2018, respectively.

[0001193125-19-139609:notes:143]
[same as prior period, unchanged from 0001193125-19-028336:notes:106]

[0001193125-19-139609:notes:144]
| (years) |  | As of March 29,2019 |  |  | As of June 29,2018 |  |
| Customer relationships |  |  | 5.6 |  |  |  | 6.1 |  |
| Backlog |  |  | 0.3 |  |  |  | 0.9 |  |

[0001193125-19-139609:notes:145]
Based on the carrying amount of intangibles as of March 29, 2019, and assuming no future impairment of the underlying assets, the estimated future amortization during each fiscal year was as follows:

[0001193125-19-139609:notes:146]
| (amount in thousands) |  |  |  |
| 2019 (remaining three months) |  | $ | 421 |  |
| 2020 |  |  | 1,130 |  |
| 2021 |  |  | 952 |  |
| 2022 |  |  | 718 |  |
| 2023 |  |  | 454 |  |
| Thereafter |  |  | 437 |  |
| Total |  | $ | 4,112 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001193125-19-139609:notes:147]
|  | 3. | Revenues |

[0001193125-19-139609:notes:148]
[same as prior period, unchanged from 0001193125-19-028336:notes:40]

[0001193125-19-139609:notes:149]
[same as prior period, unchanged from 0001193125-19-028336:notes:41]

[0001193125-19-139609:notes:150]
The Company manufactures products that are customized to customers’ specifications; however, control of the products is typically transferred to the customer at the point in time the product is either shipped or delivered, depending on the terms of the arrangement, as the criteria for overtime recognition are not met. On the evaluation of the contracts, the Company identified that it did not have contractual rights to bill profit for work in progress in the event of a contract termination which is expected to be infrequent. Further, in limited circumstances, substantive acceptance by the customer exists which results in the deferral of revenue until acceptance is formally received from the customer. Judgment may be required in determining if the acceptance clause is substantive.

[0001193125-19-139609:notes:151]
[same as prior period, unchanged from 0001193125-19-028336:notes:43]

[0001193125-19-139609:notes:152]
Customers generally are obligated to purchase finished goods that the Company has manufactured according to their demand requirements. Materials that are not consumed by customers within a specified period of time, or are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under the Company’s contracts. Once materials are designated as either excess or obsolete inventory, customers are typically required to purchase such inventory from the Company even if the customer has chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

[0001193125-19-139609:notes:153]
[same as prior period, unchanged from 0001193125-19-028336:notes:45]

[0001193125-19-139609:notes:154]
[same as prior period, unchanged from 0001193125-19-028336:notes:46]

[0001193125-19-139609:notes:155]
[same as prior period, unchanged from 0001193125-19-028336:notes:47]

[0001193125-19-139609:notes:156]
[same as prior period, unchanged from 0001193125-19-028336:notes:48]

[0001193125-19-139609:notes:157]
A contract asset is recognized when the Company has recognized revenues, but not yet an invoice for payment. Contract assets are classified separately on the condensed consolidated balance sheets and transferred to accounts receivable when rights to payment become unconditional. The following table summarizes the activity in the Company’s contract assets during the nine-month period ended March 29, 2019:

[0001193125-19-139609:notes:158]
| (amount in thousands) |  | Contract Assets |  |
| Beginning balance, June 30, 2018 |  | $ | — |  |
| Cumulative effect adjustment upon adoption of ASC 606 |  |  | 9,877 |  |
| Revenue recognized |  |  | 89,131 |  |
| Amounts collected or invoiced |  |  | (88,465 | ) |
| Ending balance, March 29, 2019 |  | $ | 10,543 |  |

[0001193125-19-139609:notes:159]
The Company continually evaluates whether advance payment arrangements with customers result in the recognition of contract liabilities. No such liabilities existed as of March 29, 2019 or June 29, 2018. Separately, accounts receivable, net, represents receivables from contracts with customers.

[0001193125-19-139609:notes:160]
[same as prior period, unchanged from 0001193125-19-028336:notes:52]

[0001193125-19-139609:notes:161]
The Company has elected the practical expedient to recognize the incremental costs of obtaining a contract as an expense when incurred if the amortization period of the asset that the Company otherwise would have recognized is one year or less. During the three and nine months ended March 29, 2019, the Company did not have any incremental costs of obtaining a contract.

[0001193125-19-139609:notes:162]
[same as prior period, unchanged from 0001193125-19-028336:notes:54]

[0001193125-19-139609:notes:163]
Shipping costs billed to customers are recorded as revenue. Shipping and handling expense related to costs incurred to deliver product are recognized within cost of goods sold. The Company accounts for shipping and handling activities that occur after control has transferred as a fulfillment cost, as opposed to a separate performance obligation, and the costs of shipping and handling are recognized concurrently with the related revenue.

[0001193125-19-139609:notes:164]
In accordance with the new revenue standard requirements, the disclosure of the impact of adoption of ASC 606 on the Company’s condensed consolidated statements of operations and comprehensive income for the three and nine months ended March 29, 2019 and condensed consolidated balance sheets as of March 29, 2019 was as follows:

[0001193125-19-139609:notes:165]
Condensed Consolidated Statement of Operations and Comprehensive Income (Unaudited)

[0001193125-19-139609:notes:166]
Three and Nine Months Ended March 29, 2019

[0001193125-19-139609:notes:167]
|  |  | Impact of Adopting ASC 606 (Three months) |  |  | Impact of Adopting ASC 606 (Nine months) |  |
| (amount in thousands) |  | As Reported |  |  | Adjustment |  |  | Balance withoutASC 606 Adoption |  |  | As Reported |  |  | Adjustment |  |  | Balance withoutASC 606 Adoption |  |
| Revenues |  | $ | 398,951 |  |  | $ | 2,793 | (1) |  | $ | 401,744 |  |  | $ | 1,179,208 |  |  | $ | (666 | )(1) |  | $ | 1,178,542 |  |
| Cost of revenues |  | $ | (352,193 | ) |  | $ | (2,699 | )(2) |  | $ | (354,892 | ) |  | $ | (1,046,610 | ) |  | $ | 341 | (2) |  | $ | (1,046,269 | ) |
| Gross profit |  | $ | 46,758 |  |  | $ | 94 | (3) |  | $ | 46,852 |  |  | $ | 132,598 |  |  | $ | (325 | )(3) |  | $ | 132,273 |  |
| Net income |  | $ | 28,635 |  |  | $ | 94 | (3) |  | $ | 28,729 |  |  | $ | 87,998 |  |  | $ | (325 | )(3) |  | $ | 87,673 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.78 |  |  | $ | 0.00 |  |  | $ | 0.78 |  |  | $ | 2.39 |  |  | $ | (0.01 | ) |  | $ | 2.38 |  |
| Diluted |  | $ | 0.76 |  |  | $ | 0.00 |  |  | $ | 0.76 |  |  | $ | 2.35 |  |  | $ | (0.01 | ) |  | $ | 2.34 |  |

[0001193125-19-139609:notes:168]
|  | (1) | Adjustment relates to certain manufacturing contracts with vendor-managed inventory arrangements for which revenue was recognized at shipping. |

[0001193125-19-139609:notes:169]
[same as prior period, unchanged from 0001193125-19-028336:notes:61]

[0001193125-19-139609:notes:170]
[same as prior period, unchanged from 0001193125-19-028336:notes:62]

[0001193125-19-139609:notes:171]
Condensed

[0001193125-19-139609:notes:172]
Consolidated Balance Sheets (Unaudited)

[0001193125-19-139609:notes:173]
As of March 29, 2019

[0001193125-19-139609:notes:174]
|  |  | Impact of Adopting ASC 606 |  |
| (amount in thousands) |  | As Reported |  |  | Adjustments |  |  | Balancewithout ASC606 Adoption |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Contract assets |  | $ | 10,543 |  |  | $ | (10,543 | )(1) |  | $ | — |  |
| Inventory, net |  | $ | 285,431 |  |  | $ | 9,013 | (2) |  | $ | 294,444 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 721,626 |  |  | $ | (1,530 | )(3) |  | $ | 720,096 |  |

[0001193125-19-139609:notes:175]
| (1) | Majority of adjustment relates to certain manufacturing contracts with vendor-managed inventory arrangements for which revenue was recognized on shipment. |

[0001193125-19-139609:notes:176]
[same as prior period, unchanged from 0001193125-19-028336:notes:65]

[0001193125-19-139609:notes:177]
| (3) | Adjustment relates to cumulative effect adjustment upon adoption of ASC 606. |

[0001193125-19-139609:notes:178]
[same as prior period, unchanged from 0001193125-19-028336:notes:66]

[0001193125-19-139609:notes:179]
Total revenues are attributed to a particular geographic area based on the bill-to-location of customers. The Company operates primarily in three geographic regions: North America, Asia-Pacific and Europe. The following table presents total revenues by geographic regions:

[0001193125-19-139609:notes:180]
| (amount in thousands) |  | Three MonthsEndedMarch 29,2019 |  |  | As a % of TotalRevenues |  |  | Nine MonthsEndedMarch 29,2019 |  |  | As a % of TotalRevenues |  |
| North America |  | $ | 195,504 |  |  |  | 49.0 | % |  | $ | 558,028 |  |  |  | 47.3 | % |
| Asia-Pacific |  |  | 151,263 |  |  |  | 37.9 |  |  |  | 469,921 |  |  |  | 39.9 |  |
| Europe |  |  | 52,184 |  |  |  | 13.1 |  |  |  | 151,259 |  |  |  | 12.8 |  |
|  |  | $ | 398,951 |  |  |  | 100.0 | % |  | $ | 1,179,208 |  |  |  | 100.0 | % |

[0001193125-19-139609:notes:181]
[same as prior period, unchanged from 0001193125-19-028336:notes:72]

[0001193125-19-139609:notes:182]
| (amount in thousands) |  | Three MonthsEndedMarch 29,2019 |  |  | As a % of TotalRevenues |  |  | Nine MonthsEndedMarch 29,2019 |  |  | As a % of TotalRevenues |  |
| Optical communications |  | $ | 298,139 |  |  |  | 74.7 | % |  | $ | 884,454 |  |  |  | 75.0 | % |
| Lasers, sensors and other |  |  | 100,812 |  |  |  | 25.3 |  |  |  | 294,754 |  |  |  | 25.0 |  |
|  |  | $ | 398,951 |  |  |  | 100.0 | % |  | $ | 1,179,208 |  |  |  | 100.0 | % |


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-19-139609:notes:183]
|  | 2. | Accounting policies |

[0001193125-19-139609:notes:184]
[same as prior period, unchanged from 0001193125-19-028336:notes:5]

[0001193125-19-139609:notes:185]
[same as prior period, unchanged from 0001193125-19-028336:notes:6]

[0001193125-19-139609:notes:186]
[same as prior period, unchanged from 0001193125-19-028336:notes:7]

[0001193125-19-139609:notes:187]
The Company utilizes a 52-53 week fiscal year ending on the Friday in June closest to June 30. The three months ended March 29, 2019 and March 30, 2018 each consisted of 13 weeks. The nine months ended March 29, 2019 and March 30, 2018 each consisted of 39 weeks. Fiscal year 2019 will be comprised of 52 weeks and will end on June 28, 2019.

[0001193125-19-139609:notes:188]
[same as prior period, unchanged from 0001193125-19-028336:notes:20]

[0001193125-19-139609:notes:189]
[same as prior period, unchanged from 0001193125-19-028336:notes:21]

[0001193125-19-139609:notes:190]
Cash, cash equivalents, and short-term investments are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. The Company seeks to mitigate its credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties. The Company limits its investments in short-term investments to term deposits and marketable securities to securities with a maturity not in excess of three years, and all marketable securities that the Company invests in are rated A1, P-1, F1, or better.

[0001193125-19-139609:notes:191]
[same as prior period, unchanged from 0001193125-19-028336:notes:23]


## us-gaap:DebtDisclosureTextBlock

[0001193125-19-139609:notes:192]
| 11. | Borrowings |

[0001193125-19-139609:notes:193]
The Company’s total borrowings, including short-term and long-term borrowings, consisted of the following:

[0001193125-19-139609:notes:194]
| Rate (1) |  | Conditions |  |  | Maturity |  |  | As ofMarch 29,2019 |  |  | As ofJune 29,2018 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current portion of long-term borrowing |  |  | $ | 3,250 |  |  | $ | 3,250 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Term loan borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR +1.50% per annum |  |  | Repayable in quarterlyinstallments |  |  |  | June 2023 |  |  | $ | 61,750 |  |  | $ | 64,188 |  |
|  |  |  |  |  |  |  |  | 61,750 |  |  | 64,188 |  |
| Less: Current portion |  |  |  |  |  |  |  |  |  |  | (3,250 | ) |  |  | (3,250 | ) |
| Non-current portion of long-term borrowing |  |  |  |  |  |  |  |  |  | $ | 58,500 |  |  | $ | 60,938 |  |

[0001193125-19-139609:notes:195]
| (1) | LIBOR is London Interbank Offered Rate. |

[0001193125-19-139609:notes:196]
Credit facilities:

[0001193125-19-139609:notes:197]
The Company entered into a syndicated senior credit facility agreement (the “Facility Agreement”) with a consortium of banks on May 22, 2014. The Facility Agreement, led by Bank of America, provided for a $200.0 million credit line, comprised of a $150.0 million revolving loan facility and a $50.0 million delayed draw term loan facility. The revolving loan facility contains an accordion feature permitting Fabrinet to request an increase in the facility up to $100.0 million subject to customary terms and conditions and provided that no default or event of default exists at the time of request.

[0001193125-19-139609:notes:198]
On February 26, 2015, the Company entered into the Second Amendment to the Facility Agreement. The amendment extended the availability period for draws on the term loan facility from May 21, 2015 to July 31, 2015. It also allowed the Company, upon the satisfaction of certain conditions, to designate from time to time one or more of its subsidiaries as borrowers under the Facility Agreement. On July 31, 2015, the Company entered into the Third Amendment to the Facility Agreement. This amendment extended the availability period for draws on the term loan facility from July 31, 2015 to July 31, 2016. On July 22, 2016, the Company entered into the Fourth Amendment to the Facility Agreement to change the timing of filing certain financial information with the bank.

[0001193125-19-139609:notes:199]
Loans under the Facility Agreement bear interest, at Fabrinet’s option, at a rate per annum equal to a LIBOR rate plus a spread of 1.75% to 2.50%, or a base rate, determined in accordance with the Facility Agreement, plus a spread of 0.75% to 1.50%, in each case with such spread determined based on Fabrinet’s consolidated total leverage ratio for the preceding four fiscal quarter period. Interest is due and payable quarterly in arrears for loans bearing interest at the base rate and at the end of an interest period (or at each three-month interval in the case of loans with interest periods greater than three months) in the case of loans bearing interest at the LIBOR rate.

[0001193125-19-139609:notes:200]
Fabrinet’s obligations under the Facility Agreement are guaranteed by certain of its existing and future direct material subsidiaries. In addition, the Facility Agreement is secured by Fabrinet’s present and future accounts receivable, deposit accounts and cash, and a pledge of the capital stock of certain of Fabrinet’s direct subsidiaries. Fabrinet is required to maintain at least $40.0 million of cash, cash equivalents, and marketable securities at financial institutions located in the United States. Further, Fabrinet is required to maintain any of its deposits accounts or securities accounts with balances in excess of $10.0 million in a jurisdiction where a control agreement, or the equivalent under the local law, can be effected.

[0001193125-19-139609:notes:201]
The Facility Agreement contains customary affirmative and negative covenants. Negative covenants include, among other things, limitations on liens, indebtedness, investments, mergers, sales of assets, changes in the nature of the business, dividends and distributions, affiliate transactions and capital expenditures. The Facility Agreement contains financial covenants requiring Fabrinet to maintain: (i) a minimum tangible net worth of not less than $200.0 million plus 50% of quarterly net income, exclusive of quarterly losses; (ii) a minimum debt service coverage ratio of not less than 1.50:1.00; (iii) a maximum senior leverage ratio of not more than 2.50:1.00; and (iv) a minimum quick ratio of not less than 1.10:1.00. Each of these financial covenants is calculated on a consolidated basis for the consecutive four fiscal quarter period then ended.

[0001193125-19-139609:notes:202]
The Facility Agreement also contains customary events of default including, among other things, payment defaults, breaches of covenants or representations and warranties, cross-defaults with certain other indebtedness, bankruptcy and insolvency events and change in control of Fabrinet, subject to grace periods in certain instances. Upon an event of default, the lenders may terminate their commitments, declare all or a portion of the outstanding obligations payable by Fabrinet to be immediately due and payable and exercise other rights and remedies provided for under the Facility Agreement.

[0001193125-19-139609:notes:203]
On June 4, 2018, the Company entered into the Fifth Amendment to the Facility Agreement to (i) reduce the revolving commitments thereunder from $150.0 million to $25.0 million, (ii) extend the termination date of the revolving commitments from May 22, 2019 to June 4, 2023, (iii) refinance the then-existing term loan and revolving loans under the Facility Agreement into a $65.0 million term loan and (iv) reduce the applicable interest rate margins and commitment fees. Term loans must be repaid in quarterly installments, beginning on June 30, 2018, with the remaining outstanding principal and accrued and unpaid interest being due and payable on June 4, 2023. After giving effect to the amendment, $65.0 million aggregate principal amount of term loans and no revolving loans were outstanding under the Facility Agreement. In addition, the Fifth Amendment to the Facility Agreement contains an accordion feature permitting the Company to request an increase in the revolving loan facility to provide up to an aggregate of $200.0 million in additional commitments, subject to customary terms and conditions, and provided that no default or event of default exists at the time of such request. As of March 29, 2019 and June 29, 2
0
18, $61.8 million and $64.2 million aggregate principal amount of term loans, respectively, and no revolving loans were outstanding under the Facility Agreement.

[0001193125-19-139609:notes:204]
After the Fifth Amendment, loans under the Facility Agreement bear interest, at Fabrinet’s option, at a rate per annum equal to a LIBOR rate plus a spread of 1.50% to 2.25%, or a base rate plus a spread of 0.50% to 1.25%, determined in accordance with the Facility Agreement in each case with such spread determined based on Fabrinet’s consolidated total leverage ratio for the preceding four fiscal quarter period.

[0001193125-19-139609:notes:205]
Fabrinet’s obligations under the Facility Agreement are guaranteed by certain of existing and future material of its direct subsidiaries. In addition, the Facility Agreement is secured by Fabrinet’s present and future accounts receivable, deposit accounts and cash, and a pledge of the capital stock of certain of Fabrinet’s direct subsidiaries. Fabrinet is required to maintain at least $40.0 million of cash, cash equivalents, and marketable securities at financial institutions located in the United States. Further, Fabrinet is required to maintain any of its deposits accounts or securities accounts with balances in excess of $20.0 million in a jurisdiction where a control agreement, or the equivalent under the local law, can be effected.

[0001193125-19-139609:notes:206]
Moreover, the Fifth Amendment to the Facility Agreement amends customary affirmative and negative covenants. Negative covenants include, among other things, limitations on liens, indebtedness, investments, mergers, sales of assets, changes in the nature of the business, dividends and distributions, affiliate transactions and capital expenditures. The Facility Agreement contains financial covenants requiring Fabrinet to maintain: (1) a minimum tangible net worth of not less than $338.0 million plus 50% of quarterly net income after June 30, 2018, exclusive of quarterly losses; (2) a minimum debt service coverage ratio of not less than 1.50:1.00; (3) a maximum total leverage ratio of not more than 2.50:1.00; and (4) a minimum quick ratio of not less than 1.10:1.00. Each of these financial covenants is calculated on a consolidated basis for the consecutive four fiscal quarter period then ended. As of March 29, 2019, the Company was in compliance with all covenants under the Facility Agreement.

[0001193125-19-139609:notes:207]
Fabrinet intends to use the proceeds of the credit line to finance its future expansion in the United States and Thailand, and for general corporate purposes including mergers and acquisitions of complementary manufacturing businesses or technology, although Fabrinet has no current commitments with respect to any such acquisitions.

[0001193125-19-139609:notes:208]
On July 25, 2018, the Company entered into the Swap Agreement, which the Company did not designate as a hedging instrument. The Swap Agreement was used to mitigate interest rate risk and improve the interest rate profile of the Company’s debt obligations. The terms of the Swap Agreement effectively convert the floating interest rate of the term loans under the Facility Agreement to the fixed interest rate of 2.86% per annum through maturity in June 2023. The swap transactions are due and settled 
monthly. During the nine months ended March 29, 2019, the Company included a net loss of $0.2 million from the Swap Agreement in interest expense in the condensed consolidated statements of operations and comprehensive income.

[0001193125-19-139609:notes:209]
Undrawn available credit facilities classified by availability period of future borrowing as of March 29, 2019 and June 29, 2018 were as follows:


## us-gaap:SubsequentEventsTextBlock

[0001193125-19-139609:notes:210]
| 18. | Subsequent events |

[0001193125-19-139609:notes:211]
On December 13, 2018, Thailand’s National Legislative Assembly (NLA) passed an amendment bill to the Thai Labour Protection Act B.E. 2541 (1998) to increase the required severance payment compensation for employees with 20 or more years of service from 300 days of wage to 400 days of wage. The law became effective on May 4, 2019. The Company has engaged an independent actuary to consider the effect of this change.

[0001193125-19-139609:notes:212]
In

[0001193125-19-139609:notes:213]
May 2019

[0001193125-19-139609:notes:214]
, Fabrinet’s board of directors approved the repurchase of up to an additional $50.0 million of Fabrinet’s outstanding ordinary shares, bringing the aggregate authorization under Fabrinet’s existing share repurchase program to $110.0 million.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-19-139609:notes:215]
|  | 15. | Accumulated other comprehensive income (loss) |

[0001193125-19-139609:notes:216]
The 
changes in AOCI for the nine months ended March 29, 2019 and March 30, 2018 were as follows:

[0001193125-19-139609:notes:217]
| (amount in thousands) |  | Unrealized net(Losses) GainsonAvailable-for-salesecurities |  |  | Unrealizednet(Losses)GainsonDerivativeInstruments |  |  | ForeignCurrencyTranslationAdjustment |  |  | Total |  |
| Balance as of June 29, 2018 |  | $ | (1,091 | ) |  | $ | 33 |  |  | $ | (199 | ) |  | $ | (1,257 | ) |
| Other comprehensive income (loss) before reclassification adjustment |  |  | 1,203 |  |  |  | — |  |  |  | (219 | ) |  |  | 984 |  |
| Amounts reclassified out of AOCI to foreign exchange loss in the condensed consolidated statements of operations and comprehensive income |  |  | 196 |  |  |  | (2 | ) |  |  | — |  |  |  | 194 |  |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income (loss) |  | $ | 1,399 |  |  | $ | (2 | ) |  | $ | (219 | ) |  | $ | 1,178 |  |
| Balance as of March 29, 2019 |  | $ | 308 |  |  | $ | 31 |  |  | $ | (418 | ) |  | $ | (79 | ) |
| Balance as of June 30, 2017 |  | $ | (72 | ) |  | $ | 34 |  |  | $ | (310 | ) |  | $ | (348 | ) |
| Other comprehensive (loss) income before reclassification adjustment |  |  | (361 | ) |  |  | — |  |  |  | 1,358 |  |  |  | 997 |  |
| Amounts reclassified out of AOCI to foreign exchange loss in the condensed consolidated statements of operations and comprehensive income |  |  | (687 | ) |  |  | (1 | ) |  |  | — |  |  |  | (688 | ) |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive (loss) income |  | $ | (1,048 | ) |  | $ | (1 | ) |  | $ | 1,358 |  |  | $ | 309 |  |
| Balance as of March 30, 2018 |  | $ | (1,120 | ) |  | $ | 33 |  |  | $ | 1,048 |  |  | $ | (39 | ) |
