# FN MD&A — 0001193125-16-447643


## mdna

[0001193125-16-447643:mdna:1]
[same as prior period, unchanged from 0001193125-15-364290:mdna:1]

[0001193125-16-447643:mdna:2]
[same as prior period, unchanged from 0001193125-15-364290:mdna:2]

[0001193125-16-447643:mdna:3]
[same as prior period, unchanged from 0001193125-15-364290:mdna:3]

[0001193125-16-447643:mdna:4]
|  | • |  | our expectation that the portion of our future revenues attributable to customers in regions outside of North America will continue to decrease compared with the portion of those revenues for the six months ended December 25, 2015; |

[0001193125-16-447643:mdna:5]
[same as prior period, unchanged from 0001193125-15-364290:mdna:5]

[0001193125-16-447643:mdna:6]
[same as prior period, unchanged from 0001193125-15-364290:mdna:6]

[0001193125-16-447643:mdna:7]
[same as prior period, unchanged from 0001193125-15-364290:mdna:7]

[0001193125-16-447643:mdna:8]
[same as prior period, unchanged from 0001193125-15-364290:mdna:9]

[0001193125-16-447643:mdna:9]
[same as prior period, unchanged from 0001193125-15-364290:mdna:10]

[0001193125-16-447643:mdna:10]
[same as prior period, unchanged from 0001193125-15-364290:mdna:11]

[0001193125-16-447643:mdna:11]
[same as prior period, unchanged from 0001193125-15-364290:mdna:12]

[0001193125-16-447643:mdna:12]
[same as prior period, unchanged from 0001193125-15-364290:mdna:13]

[0001193125-16-447643:mdna:13]
[same as prior period, unchanged from 0001193125-15-364290:mdna:14]

[0001193125-16-447643:mdna:14]
[same as prior period, unchanged from 0001193125-15-364290:mdna:15]

[0001193125-16-447643:mdna:15]
[same as prior period, unchanged from 0001193125-15-364290:mdna:16]

[0001193125-16-447643:mdna:16]
[same as prior period, unchanged from 0001193125-15-364290:mdna:17]

[0001193125-16-447643:mdna:17]
[same as prior period, unchanged from 0001193125-15-364290:mdna:18]

[0001193125-16-447643:mdna:18]
[same as prior period, unchanged from 0001193125-15-364290:mdna:19]

[0001193125-16-447643:mdna:19]
[same as prior period, unchanged from 0001193125-15-364290:mdna:20]

[0001193125-16-447643:mdna:20]
[same as prior period, unchanged from 0001193125-15-364290:mdna:21]

[0001193125-16-447643:mdna:21]
[same as prior period, unchanged from 0001193125-15-364290:mdna:22]

[0001193125-16-447643:mdna:22]
[same as prior period, unchanged from 0001193125-15-364290:mdna:23]

[0001193125-16-447643:mdna:23]
[same as prior period, unchanged from 0001193125-15-364290:mdna:24]

[0001193125-16-447643:mdna:24]
During the week of August 10, 2015, our subsidiary in China temporarily suspended production in its manufacturing facility due to
flooding caused by Typhoon Soudelor. The subsidiary resumed operations on August 15, 2015. During the three months ended December 25, 2015, we did not recognize expenses in relation to flood. During the six months ended December 25,
2015, we recognized $0.9 million of losses incurred from the event in the unaudited condensed consolidated statements of operations and comprehensive income and submitted claims to our insurers for inventory and equipment losses attributable to the
effects of the flooding.

[0001193125-16-447643:mdna:25]
A number of exclusions and limitations in the insurance policies (such as coinsurance, facilities location
sub-limits and policy covenants) may reduce the aggregate amount that we will ultimately recover from our insurers. Based on the information that we have at the time of filing this Quarterly Report on Form 10-Q, we believe that we will ultimately
recover a majority of our losses.

[0001193125-16-447643:mdna:26]
The following is a summary of all known losses incurred from this event and recognized in the unaudited
condensed consolidated statements of operations and comprehensive income for the six months ended December 25, 2015.

[0001193125-16-447643:mdna:27]
[same as prior period, unchanged from 0001193125-15-364290:mdna:28]

[0001193125-16-447643:mdna:28]
[same as prior period, unchanged from 0001193125-15-364290:mdna:29]

[0001193125-16-447643:mdna:29]
Our total revenues increased by $44.7 million, or 23.7%, to $233.0 million for the three months ended December 25, 2015, compared with
$188.4 million for the three months ended December 26, 2014. Our total revenues increased by $71.8 million, or 19.0%, to $449.5 million for the six months ended December 25, 2015, compared with $377.7 million for the six months ended
December 26, 2014. The increases were primarily due to (i) an increase in our customers’ demand for both optical and non-optical communications manufacturing services during the three and six months ended December 25, 2015 and
(ii) our inability to recognize $4.8 million of consignment revenue during the three and six months ended December 26, 2014, respectively, because of certain consignment revenue recognition issues previously disclosed. We refer to finished
goods held in our warehouse on behalf of our customers as consignment goods or consignment inventory, and when the finished goods are sold, we refer to the related revenue as consignment revenue.

[0001193125-16-447643:mdna:30]
We believe our ability to expand our relationships with existing customers and attract new customers is due to a number of factors, including
our broad range of complex engineering and manufacturing service offerings, flexible low-cost manufacturing platform, process optimization capabilities, advanced supply chain management, excellent customer service, and experienced management team.
While we expect the prices we charge for our manufactured products to decrease over time (partly as a result of competitive market forces), we still believe we will be able to maintain favorable pricing for our services because of our ability to
reduce cycle time, adjust our product mix by focusing on more complicated products, improve product quality and yields, and reduce material costs for the products we manufacture. We believe these capabilities have enabled us to help our OEM
customers reduce their manufacturing costs while maintaining or improving the design, quality, reliability, and delivery times for their products.

[0001193125-16-447643:mdna:31]
[same as prior period, unchanged from 0001193125-15-364290:mdna:32]

[0001193125-16-447643:mdna:32]
[same as prior period, unchanged from 0001193125-15-364290:mdna:33]

[0001193125-16-447643:mdna:33]
The percentage of our revenues generated from a bill-to location outside of North America decreased from 50.3% in the three months ended
December 26, 2014 to 46.7% in the three months ended December 25, 2015 and from 51.1% in the six months ended December 26, 2014 to 48.7% in the six months ended December 25, 2015, primarily because of a decrease in sales to our
customers in Asia-Pacific and Europe. We expect that the portion of our future revenues attributable to customers in regions outside North America will continue to decrease as compared with the portion of revenues attributable to such customers
during the six months ended December 25, 2015.

[0001193125-16-447643:mdna:34]
The following table presents percentages of total revenues by geographic regions:

[0001193125-16-447643:mdna:35]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 25,2015 |  |  | December 26,2014 |  |  | December 25,2015 |  |  | December 26,2014 |  |
| North America |  |  | 53.3 | % |  |  | 49.7 | % |  |  | 51.3 | % |  |  | 48.9 | % |
| Asia-Pacific |  |  | 36.2 |  |  |  | 37.7 |  |  |  | 37.4 |  |  |  | 39.4 |  |
| Europe |  |  | 10.5 |  |  |  | 12.6 |  |  |  | 11.3 |  |  |  | 11.7 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-16-447643:mdna:36]
[same as prior period, unchanged from 0001193125-15-364290:mdna:37]

[0001193125-16-447643:mdna:37]
[same as prior period, unchanged from 0001193125-15-364290:mdna:38]

[0001193125-16-447643:mdna:38]
[same as prior period, unchanged from 0001193125-15-364290:mdna:39]

[0001193125-16-447643:mdna:39]
The key components of our cost of revenues are material costs, employee costs, and infrastructure-related costs. Material costs generally
represent the majority of our cost of revenues. Several of the materials we require to manufacture products for our customers are customized for their products and often sourced from a single supplier or in some cases, our own subsidiaries.
Shortages from sole-source suppliers due to yield loss, quality concerns, and capacity constraints, among other factors, may increase our expenses and negatively impact our gross profit margin or total revenues in a given quarter. Material costs
include scrap material. Historically, scrap rate diminishes during a product’s life cycle due to process, fixturing and test improvement, and optimization.

[0001193125-16-447643:mdna:40]
A second significant element of our cost of revenues is employee costs, including indirect employee costs related to design, configuration and
optimization of manufacturing processes for our customers, quality testing, materials testing and other engineering services; and direct costs related to our manufacturing employees. Direct employee costs include employee salaries, insurance and
benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a lesser extent, costs to recruit,
train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand and the PRC; the fluctuation of the Thai baht and Chinese Renminbi (RMB) against our functional currency, the U.S. dollar; and our ability to
retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to mitigate
these cost increases through improvements in employee productivity, employee retention, and asset utilization.

[0001193125-16-447643:mdna:41]
Our infrastructure costs
are comprised of depreciation, utilities, facilities management, and overhead costs. Most of our facility leases are long-term agreements. Our depreciation costs include buildings and fixed assets, primarily at our Pinehurst campus in Thailand, and
capital equipment located at each of our manufacturing locations.

[0001193125-16-447643:mdna:42]
During the three and six months ended December 25, 2015,
discretionary merit-based bonus awards were made to our non-executive employees. Charges included in cost of revenues for bonus distributions to non-executive employees were $0.7 million and $0.6 million for the three months ended December 25,
2015 and December 26, 2014, respectively, and $1.5 million and $1.2 million for the six months ended December 25, 2015 and December 26, 2014, respectively.

[0001193125-16-447643:mdna:43]
Share-based compensation expense included in cost of revenues was $0.5 million and $0.4 million for the three months ended December 25,
2015 and December 26, 2014, respectively, and $1.1 million and $0.7 million for the six months ended December 25, 2015 and December 26, 2014, respectively.

[0001193125-16-447643:mdna:44]
We expect to incur significant incremental costs of revenue as a result of our continued diversification into the industrial lasers,
automotive, and sensors markets and other end-markets outside of the optical communications market or our further development of customized optics and glass manufacturing capabilities. We also expect to incur incremental costs of revenue as a result
of our planned expansion into new geographic markets, though we are not able to determine the amount of these incremental expenses.

[0001193125-16-447643:mdna:45]
Selling, General
and Administrative Expenses

[0001193125-16-447643:mdna:46]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and
administrative, and other support personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense, and other general
expenses not related to cost of revenues. In fiscal year 2016, we expect our SG&A expenses will increase on an absolute dollar basis and as a percentage of revenue compared with fiscal year 2015 due to the startup expenses of our new
manufacturing facility in the United States.

[0001193125-16-447643:mdna:47]
The compensation committee of our board of directors approved a fiscal year 2016 executive
incentive plan with quantitative objectives, based on achieving certain revenue and non-GAAP earnings per share targets for our fiscal year ending June 24, 2016, as well as qualitative objectives, based on achieving individual performance
goals. Bonuses under our fiscal year 2016 executive incentive plan are payable after the end of fiscal year 2016. In fiscal year 2015, the compensation committee approved a fiscal year 2015 executive incentive plan with quantitative objectives,
based on achieving certain revenue and non-GAAP earnings per share targets for our fiscal year ended June 26, 2015, as well as qualitative objectives, based on achieving individual performance goals. In the three months ended September 25,
2015, the compensation committee awarded bonuses to our executive employees for Company and individual achievements of performance under our fiscal 2015 executive incentive plan. Discretionary merit-based bonus awards were also available to our
non-executive employees and were payable as of December 25, 2015.

[0001193125-16-447643:mdna:48]
Charges included in SG&A expenses for bonus distributions to non-executive and executive
employees were $1.6 million and $0.6 million for the three months ended December 25, 2015 and December 26, 2014, respectively, and $2.2 million and $1.2 million for the six months ended December 25, 2015 and December 26, 2014,
respectively.

[0001193125-16-447643:mdna:49]
Share-based compensation expense included in SG&A expenses was $2.6 million and $1.6 million for the three months ended
December 25, 2015 and December 26, 2014, respectively, and $4.7 million and $3.1 million for the six months ended December 25, 2015 and December 26, 2014, respectively.

[0001193125-16-447643:mdna:50]
[same as prior period, unchanged from 0001193125-15-364290:mdna:52]

[0001193125-16-447643:mdna:51]
[same as prior period, unchanged from 0001193125-15-364290:mdna:53]

[0001193125-16-447643:mdna:52]
As a result of our international operations, we are exposed to foreign exchange risk arising from various currency exposures primarily with
respect to the Thai baht. Although a majority of our total revenues is denominated in U.S. dollars, a substantial portion of our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rate between the Thai
baht and the U.S. dollar has fluctuated substantially in recent years and may continue to fluctuate substantially in the future. We report our financial results in U.S. dollars and our results of operations have been and may continue to be
negatively impacted owing to appreciation of the Thai baht against the U.S. dollar. Smaller portions of our expenses are incurred in a variety of other currencies, including RMB, Canadian dollars, Euros, and Japanese yen, the appreciation of which
may also negatively impact our financial results.

[0001193125-16-447643:mdna:53]
In addition, we are exposed to foreign exchange risk in connection with the long-term
loan and cross currency swap arrangements we entered into with TMB Bank Public Company Limited (the “Bank”) in May 2011 for the construction of Pinehurst Building 6. The terms of the contract with the Bank provide the following facilities:
(1) a term loan facility for up to Thai baht 960 million (equal to $30.0 million) with a fixed interest rate of 5.28% per annum, (2) a hedging facility for currency interest rate swaps with a notional amount of $30.0 million, and
(3) a settlement limit of Thai baht 65 million, subject to certain terms and conditions as set forth therein. Borrowings and interest under the term loan have been scheduled to be repaid on a quarterly basis between September 2011 and
March 2017. As of December 25, 2015, we had outstanding borrowings under the term loan facility of $7.5 million. Under the terms of the cross currency swap arrangement amounts drawn in Thai baht were converted to U.S. dollars for repayment by
us on a quarterly basis at the floating rate of London Interbank Offered Rate (LIBOR) plus 2.8% per annum.

[0001193125-16-447643:mdna:54]
In order to manage the
risks arising from fluctuations in foreign currency exchange rates, we use derivative financial instruments. We may enter into forward exchange currency contracts or put option contracts to help manage currency exposures associated with certain
assets and liabilities, primarily short-term obligations. The forward exchange contracts and put option contracts generally have original maturities of one to eighteen months. All foreign currency exchange contracts are recognized on the unaudited
condensed consolidated balance sheet at fair value. As we did not apply hedge accounting to these instruments, the change in the fair value of the derivatives is recorded in foreign exchange (loss) gain, net on the condensed consolidated statements
of operations and comprehensive income. The gains and losses on our forward exchange contracts and put option contracts generally offset the assets, liabilities, and transactions economically hedged.

[0001193125-16-447643:mdna:55]
[same as prior period, unchanged from 0001193125-15-364290:mdna:57]

[0001193125-16-447643:mdna:56]
|  |  | As of December 25, 2015 |  |  | As of June 26, 2015 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 393,596 |  |  | $ | 10,912 |  |  |  | 66.1 |  |  |  | 377,785 |  |  | $ | 11,596 |  |  |  | 51.3 |  |
| RMB |  |  | 36,273 |  |  |  | 5,605 |  |  |  | 33.9 |  |  |  | 67,455 |  |  |  | 11,029 |  |  |  | 48.7 |  |
| Total |  |  |  |  |  | $ | 16,517 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 22,625 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 1,036,513 |  |  | $ | 28,736 |  |  |  | 83.5 |  |  |  | 860,425 |  |  | $ | 26,410 |  |  |  | 88.8 |  |
| RMB |  |  | 36,684 |  |  |  | 5,669 |  |  |  | 16.5 |  |  |  | 20,461 |  |  |  | 3,347 |  |  |  | 11.2 |  |
| Total |  |  |  |  |  | $ | 34,405 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 29,757 |  |  |  | 100.0 |  |

[0001193125-16-447643:mdna:57]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other
current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and
liabilities

[0001193125-16-447643:mdna:58]
denominated in the same currency in accordance with management’s policy. As of December 25, 2015, there were $181.5 million in forward contracts outstanding on the Thai baht payables.
As of June 26, 2015, there were $41.0 million in put option contracts outstanding on the Thai baht payables.

[0001193125-16-447643:mdna:59]
The RMB assets
represent cash and cash equivalents, accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses and other payables. As of December 25, 2015 and June 26, 2015, we did not have any
selling RMB to U.S. dollar forward or put option contracts.

[0001193125-16-447643:mdna:60]
We have not designated the foreign currency forward contracts and option
contracts as hedging instruments under the accounting standard for derivatives and hedging. Accordingly, for the three months ended December 25, 2015 and December 26, 2014, we recorded an amount of $6.2 million for the unrealized gain from
changes in the fair market value of the derivatives and $0.1 million for the unrealized loss from changes in the fair market value of the derivatives, respectively, in our condensed consolidated statements of operations and comprehensive income.

[0001193125-16-447643:mdna:61]
[same as prior period, unchanged from 0001193125-15-364290:mdna:62]

[0001193125-16-447643:mdna:62]
[same as prior period, unchanged from 0001193125-15-364290:mdna:63]

[0001193125-16-447643:mdna:63]
[same as prior period, unchanged from 0001193125-15-364290:mdna:64]

[0001193125-16-447643:mdna:64]
[same as prior period, unchanged from 0001193125-15-364290:mdna:65]

[0001193125-16-447643:mdna:65]
[same as prior period, unchanged from 0001193125-15-364290:mdna:66]

[0001193125-16-447643:mdna:66]
Under the Exchange Rules, RMB is
freely convertible into foreign currencies for current account items, including the distribution of dividends, interest payments, trade and service-related foreign exchange transactions. However, conversion of RMB for capital account items, such as
direct investments, loans, security investments, and repatriation of investments, is still subject to the approval of SAFE.

[0001193125-16-447643:mdna:67]
Under the
Administration Rules, foreign-invested enterprises may only buy, sell, or remit foreign currencies at banks authorized to conduct foreign exchange business after providing valid commercial documents and relevant supporting documents and, in the case
of capital account item transactions, obtaining approval from SAFE. Capital investments by foreign-invested enterprises outside of the PRC are also subject to limitations, which include approvals by the Ministry of Commerce, SAFE, and the State
Development and Reform Commission.

[0001193125-16-447643:mdna:68]
Circular 142 regulates the conversion by a foreign-invested company of foreign currency into RMB by
restricting how the converted RMB may be used. Circular 142 requires that the registered capital of a foreign-invested enterprise settled in RMB converted from foreign currencies may only be used for purposes within the business scope approved by
the applicable governmental authority and may not be used for equity investments within the PRC. In addition, SAFE strengthened its oversight of the flow and use of the registered capital of foreign-invested enterprises settled in RMB converted from
foreign currencies. The use of such RMB capital may not be changed without SAFE’s approval and may not be used to repay RMB loans if the proceeds of such loans have not been used.

[0001193125-16-447643:mdna:69]
[same as prior period, unchanged from 0001193125-15-364290:mdna:70]

[0001193125-16-447643:mdna:70]
[same as prior period, unchanged from 0001193125-15-364290:mdna:71]

[0001193125-16-447643:mdna:71]
Furthermore, our transfer of funds to our subsidiaries in Thailand and the PRC are each subject
to approval by governmental authorities in case of an increase in registered capital, or subject to registration with governmental authorities in case of a shareholder loan. These limitations on the flow of funds between our subsidiaries and us
could restrict our ability to act in response to changing market conditions.

[0001193125-16-447643:mdna:72]
[same as prior period, unchanged from 0001193125-15-364290:mdna:73]

[0001193125-16-447643:mdna:73]
[same as prior period, unchanged from 0001193125-15-364290:mdna:74]

[0001193125-16-447643:mdna:74]
Throughout the period of our
operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption is currently available to us
through June 2020 on income generated from the manufacture of products at Pinehurst Building 6. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement
not to move our manufacturing facilities out of our current province in Thailand for at least 15 years. Additionally, in December 2011, the Thailand Revenue Department announced a reduction in corporate income tax rates for tax periods beginning on
or after January 1, 2012. As a result of the announcement, corporate income tax rates for our Thai subsidiary were reduced from 23% in fiscal year 2013 to 20% in fiscal year 2014, fiscal year 2015, and fiscal year 2016.

[0001193125-16-447643:mdna:75]
[same as prior period, unchanged from 0001193125-15-364290:mdna:76]

[0001193125-16-447643:mdna:76]
[same as prior period, unchanged from 0001193125-15-364290:mdna:77]

[0001193125-16-447643:mdna:77]
[same as prior period, unchanged from 0001193125-15-364290:mdna:78]

[0001193125-16-447643:mdna:78]
[same as prior period, unchanged from 0001193125-15-364290:mdna:79]

[0001193125-16-447643:mdna:79]
[same as prior period, unchanged from 0001193125-15-364290:mdna:80]

[0001193125-16-447643:mdna:80]
| (amount in thousands) |  | Three Months Ended |  |  | Six Months Ended |  |
|  | December 25,2015 |  |  | December 26,2014 |  |  | December 25,2015 |  |  | December 26,2014 |  |
| Revenues |  | $ | 233,038 |  |  | $ | 188,353 |  |  | $ | 449,471 |  |  | $ | 377,678 |  |
| Cost of revenues |  |  | (204,545 | ) |  |  | (167,292 | ) |  |  | (394,967 | ) |  |  | (336,111 | ) |
| Gross profit |  |  | 28,493 |  |  |  | 21,061 |  |  |  | 54,504 |  |  |  | 41,567 |  |
| Selling, general and administrative expenses |  |  | (13,715 | ) |  |  | (10,314 | ) |  |  | (25,615 | ) |  |  | (19,051 | ) |
| Other expenses in relation to flood |  |  | — |  |  |  | — |  |  |  | (864 | ) |  |  | — |  |
| Expenses related to reduction in workforce |  |  | — |  |  |  | (1,153 | ) |  |  | — |  |  |  | (1,153 | ) |
| Operating income |  |  | 14,778 |  |  |  | 9,594 |  |  |  | 28,025 |  |  |  | 21,363 |  |
| Interest income |  |  | 455 |  |  |  | 324 |  |  |  | 897 |  |  |  | 698 |  |
| Interest expense |  |  | (419 | ) |  |  | (117 | ) |  |  | (821 | ) |  |  | (250 | ) |
| Foreign exchange gain (loss), net |  |  | 6,166 |  |  |  | 83 |  |  |  | (4,326 | ) |  |  | (23 | ) |
| Other income (expense) |  |  | 106 |  |  |  | (134 | ) |  |  | 209 |  |  |  | (31 | ) |
| Income before income taxes |  |  | 21,086 |  |  |  | 9,750 |  |  |  | 23,984 |  |  |  | 21,757 |  |
| Income tax expense |  |  | (1,283 | ) |  |  | (1,024 | ) |  |  | (2,578 | ) |  |  | (1,995 | ) |
| Net income |  |  | 19,803 |  |  |  | 8,726 |  |  |  | 21,406 |  |  |  | 19,762 |  |
| Other comprehensive loss, net of tax |  |  | (310 | ) |  |  | (486 | ) |  |  | (223 | ) |  |  | (486 | ) |
| Net comprehensive income |  | $ | 19,493 |  |  | $ | 8,240 |  |  | $ | 21,183 |  |  | $ | 19,276 |  |

[0001193125-16-447643:mdna:81]
The following table sets forth a summary of our unaudited condensed consolidated statements of operations and comprehensive
income as a percentage of total revenues for the periods indicated.

[0001193125-16-447643:mdna:82]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 25,2015 |  |  | December 26,2014 |  |  | December 25,2015 |  |  | December 26,2014 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (87.8 | ) |  |  | (88.8 | ) |  |  | (87.9 | ) |  |  | (89.0 | ) |
| Gross profit |  |  | 12.2 |  |  |  | 11.2 |  |  |  | 12.1 |  |  |  | 11.0 |  |
| Selling, general and administrative expenses |  |  | (5.9 | ) |  |  | (5.5 | ) |  |  | (5.7 | ) |  |  | (5.1 | ) |
| Other expenses in relation to flood |  |  | — |  |  |  | — |  |  |  | (0.2 | ) |  |  | — |  |
| Expenses related to reduction in workforce |  |  | — |  |  |  | (0.6 | ) |  |  | — |  |  |  | (0.3 | ) |
| Operating income |  |  | 6.3 |  |  |  | 5.1 |  |  |  | 6.2 |  |  |  | 5.6 |  |
| Interest income |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.2 |  |
| Interest expense |  |  | (0.2 | ) |  |  | (0.1 | ) |  |  | (0.2 | ) |  |  | (0.1 | ) |
| Foreign exchange gain (loss), net |  |  | 2.7 |  |  |  | 0.0 |  |  |  | (1.0 | ) |  |  | (0.0 | ) |
| Other income (expense) |  |  | 0.1 |  |  |  | (0.1 | ) |  |  | 0.1 |  |  |  | (0.0 | ) |
| Income before income taxes |  |  | 9.1 |  |  |  | 5.1 |  |  |  | 5.3 |  |  |  | 5.7 |  |
| Income tax expense |  |  | (0.6 | ) |  |  | (0.5 | ) |  |  | (0.5 | ) |  |  | (0.5 | ) |
| Net income |  |  | 8.5 |  |  |  | 4.6 |  |  |  | 4.8 |  |  |  | 5.2 |  |
| Other comprehensive loss, net of tax |  |  | (0.1 | ) |  |  | (0.3 | ) |  |  | (0.1 | ) |  |  | (0.2 | ) |
| Net comprehensive income |  |  | 8.4 | % |  |  | 4.3 | % |  |  | 4.7 | % |  |  | 5.0 | % |

[0001193125-16-447643:mdna:83]
[same as prior period, unchanged from 0001193125-15-364290:mdna:84]

[0001193125-16-447643:mdna:84]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands) |  | December 25,2015 |  |  | December 26,2014 |  |  | December 25,2015 |  |  | December 26,2014 |  |
| Optical communications |  | $ | 168,694 |  |  | $ | 133,807 |  |  | $ | 323,456 |  |  | $ | 269,063 |  |
| Lasers, sensors and other |  |  | 64,344 |  |  |  | 54,546 |  |  |  | 126,015 |  |  |  | 108,615 |  |
| Total |  | $ | 233,038 |  |  | $ | 188,353 |  |  | $ | 449,471 |  |  | $ | 377,678 |  |

[0001193125-16-447643:mdna:85]
[same as prior period, unchanged from 0001193125-15-364290:mdna:86]

[0001193125-16-447643:mdna:86]
29

[0001193125-16-447643:mdna:87]
Comparison of Three and Six Months Ended December 25, 2015 with Three and Six Months Ended
December 26, 2014

[0001193125-16-447643:mdna:88]
[same as prior period, unchanged from 0001193125-15-364290:mdna:88]

[0001193125-16-447643:mdna:89]
Our total revenues increased by $44.7 million, or 23.7%, to $233.0 million for the three months ended December 25, 2015, compared with
$188.4 million for the three months ended December 26, 2014. This increase was primarily due to (i) an increase in customers’ demand for both optical and non-optical communications manufacturing services during the three months ended
December 25, 2015 and (ii) our inability to recognize $4.8 million of consignment revenue during the three months ended December 26, 2014 because of certain consignment revenue recognition issues previously disclosed. Revenues from
optical communications products represented 72.4% of our total revenues for the three months ended December 25, 2015, compared to 71.0% for the three months ended December 26, 2014.

[0001193125-16-447643:mdna:90]
Our total revenues increased by $71.8 million, or 19.0%, to $449.5 million for the six months ended December 25, 2015, compared with
$377.7 million for the six months ended December 26, 2014. This increase was primarily due to (i) an increase in customers’ demand for both optical and non-optical communications manufacturing services during the six months ended
December 25, 2015 and (ii) our inability to recognize $4.8 million of consignment revenue during the six months ended December 26, 2014 because of certain consignment revenue recognition issues previously disclosed. Revenues from
optical communications products represented 72.0% of our total revenues for the six months ended December 25, 2015, compared to 71.2% for the six months ended December 26, 2014.

[0001193125-16-447643:mdna:91]
[same as prior period, unchanged from 0001193125-15-364290:mdna:90]

[0001193125-16-447643:mdna:92]
Our
cost of revenues increased by $37.3 million, or 22.3%, to $204.5 million, or 87.8% of total revenues, for the three months ended December 25, 2015, compared with $167.3 million, or 88.8% of total revenues, for the three months ended
December 26, 2014. The increase in cost of revenues on an absolute dollar basis was primarily due to an increase in sales volume, partially offset by a more favorable product mix. Cost of revenues also included share-based compensation expense
of $0.5 million for the three months ended December 25, 2015, compared with $0.4 million for the three months ended December 26, 2014.

[0001193125-16-447643:mdna:93]
Our cost of revenues increased by $58.9 million, or 17.5%, to $395.0 million, or 87.9% of total revenues, for the six months ended
December 25, 2015, compared with $336.1 million, or 89.0% of total revenues, for the six months ended December 26, 2014. The increase in cost of revenues on an absolute dollar basis was primarily due to an increase in sales volume,
partially offset by a more favorable product mix. Cost of revenues also included share-based compensation expense of $1.1 million for the six months ended December 25, 2015, compared with $0.7 million for the six months ended December 26,
2014.

[0001193125-16-447643:mdna:94]
[same as prior period, unchanged from 0001193125-15-364290:mdna:92]

[0001193125-16-447643:mdna:95]
Our gross profit increased by $7.4 million, or 35.3%, to $28.5 million, or 12.2% of total revenues, for the three months ended
December 25, 2015, compared with $21.1 million, or 11.2% of total revenues, for the three months ended December 26, 2014. Our gross profit increased by $12.9 million, or 31.1%, to $54.5 million, or 12.1% of total revenues, for the six
months ended December 25, 2015, compared with $41.6 million, or 11.0% of total revenues, for the six months ended December 26, 2014.

[0001193125-16-447643:mdna:96]
The improvement in gross profit margin during the three and six months ended December 25, 2015, compared with the three and six months
ended December 26, 2014, was related to a more favorable product mix during the three and six months ended December 25, 2015.

[0001193125-16-447643:mdna:97]
[same as prior period, unchanged from 0001193125-15-364290:mdna:95]

[0001193125-16-447643:mdna:98]
Our
SG&A expenses increased by $3.4 million, or 33.0%, to $13.7 million, or 5.9% of total revenues, for the three months ended December 25, 2015, compared with $10.3 million, or 5.5% of total revenues, for the three months ended
December 26, 2014. Our SG&A expenses increased in absolute dollars and as a percentage of revenue due primarily to an increase in expenses relating to our new manufacturing facility in the United States of $1.9 million and severance and
related payments of $0.6 million to an employee who left the Company in December 2015. We also recorded share-based compensation charges of $2.6 million for the three months ended December 25, 2015, compared with $1.6 million for the three
months ended December 26, 2014.

[0001193125-16-447643:mdna:99]
Our SG&A expenses increased by $6.6 million, or 34.5%, to $25.6 million, or 5.7% of total
revenues, for the six months ended December 25, 2015, compared with $19.1 million, or 5.0% of total revenues, for the six months ended December 26, 2014. Our SG&A expenses increased in absolute dollars and as a percentage of revenue
due primarily to an increase in expenses relating to our new manufacturing facility in the United States of $4.1 million and an increase in sales and marketing expenses of $1.6 million. We also recorded share-based compensation charges of $4.7
million for the six months ended December 25, 2015, compared with $3.1 million for the six months ended December 26, 2014.

[0001193125-16-447643:mdna:100]
[same as prior period, unchanged from 0001193125-15-364290:mdna:97]

[0001193125-16-447643:mdna:101]
In the three months ended December 25, 2015, we did not have expense in relation to flood. In the six months ended December 25, 2015,
we recognized other expenses in relation to flood, which mainly consisted of $0.6 million of repaired cost of equipment and $0.2 million of inventory losses, which occurred at our subsidiary in China in August 2015.

[0001193125-16-447643:mdna:102]
Expenses related to reduction in workforce

[0001193125-16-447643:mdna:103]
During the three months ended December 26, 2014, we implemented a reduction in workforce and incurred expenses of approximately $1.2
million which represented severance and benefits costs associated with the termination of approximately 100 employees in accordance with contractual obligations and local regulations.

[0001193125-16-447643:mdna:104]
[same as prior period, unchanged from 0001193125-15-364290:mdna:99]

[0001193125-16-447643:mdna:105]
Our
operating income increased by $5.2 million to $14.8 million, or 6.3% of total revenues, for the three months ended December 25, 2015, compared with $9.6 million, or 5.1% of total revenues, for the three months ended December 26, 2014.

[0001193125-16-447643:mdna:106]
Our operating income increased by $6.7 million to $28.0 million, or 6.2% of total revenues, for the six months ended December 25, 2015,
compared with $21.4 million, or 5.7% of total revenues, for the six months ended December 26, 2014.

[0001193125-16-447643:mdna:107]
[same as prior period, unchanged from 0001193125-15-364290:mdna:101]

[0001193125-16-447643:mdna:108]
Our interest income increased by $0.2 million to $0.5 million, or 0.2% of total revenues, for the three months ended December 25, 2015,
compared with $0.3 million, or 0.2% of total revenues, for the three months ended December 26, 2014.

[0001193125-16-447643:mdna:109]
Our interest income increased
by $0.2 million to $0.9 million, or 0.2% of total revenues, for the six months ended December 25, 2015, compared with $0.7 million, or 0.2% of total revenues, for the six months ended December 26, 2014.

[0001193125-16-447643:mdna:110]
[same as prior period, unchanged from 0001193125-15-364290:mdna:105]

[0001193125-16-447643:mdna:111]
Our
interest expense increased by $0.3 million to $0.4 million for the three months ended December 25, 2015, compared with $0.1 million for the three months ended December 26, 2014. Our interest expense increased by $0.5 million to $0.8
million for the six months ended December 25, 2015, compared with $0.3 million for the six months ended December 26, 2014. The increases were due to an increase in the average balance of our bank borrowings resulting from a drawdown of a
revolving loan under our Facility Agreement taken during the third quarter of fiscal year 2015, as well as the amortization of additional deferred debt issuance costs.

[0001193125-16-447643:mdna:112]
Foreign exchange gain (loss), net.

[0001193125-16-447643:mdna:113]
Our foreign exchange gain, net, increased by $6.1 million to $6.2 million, or 2.7% of total revenues, for the three months ended
December 25, 2015, compared with $0.1 million, or 0.1% of total revenues, for the three months ended December 26, 2014. Our foreign exchange loss, net, increased by $4.3 million to $4.3 million, or 1.0% of total revenues, for the six
months ended December 25, 2015, compared with $0.01 million, or 0.01% of total revenues, for the six months ended December 26, 2014. The increases were due to changes in the fair value of outstanding derivatives as of December 25,
2015.

[0001193125-16-447643:mdna:114]
[same as prior period, unchanged from 0001193125-15-364290:mdna:107]

[0001193125-16-447643:mdna:115]
We recorded income before income taxes of $21.1 million and $24.0 million for the three and six months ended December 25, 2015,
respectively, compared with income before income taxes of $9.8 million and $21.8 million for the three and six months ended December 26, 2014, respectively.

[0001193125-16-447643:mdna:116]
[same as prior period, unchanged from 0001193125-15-364290:mdna:109]

[0001193125-16-447643:mdna:117]
Our provision for income tax reflects an effective tax rate of 6.1% for the three months ended December 25, 2015, compared with an
effective tax rate of 10.5% for the three months ended December 26, 2014. The decrease was primarily due to the fact that the Company had lower taxable income during the three months ended December 25, 2015 as compared to the three months
ended December 26, 2014 because of an increase in unrealized gain from changes in the fair value of derivatives during the three months ended December 25, 2015, which are not subject to tax.

[0001193125-16-447643:mdna:118]
Our provision for income tax reflects an effective tax rate of 10.7% for the six months ended December 25, 2015, compared with an
effective tax rate of 9.2% for the six months ended December 26, 2014. The increase was primarily due to the fact that we had higher taxable income during the six months ended December 25, 2015 as compared to the six months ended
December 26, 2014, due to the expiration of a tax privilege of our subsidiary in Thailand.

[0001193125-16-447643:mdna:119]
[same as prior period, unchanged from 0001193125-15-364290:mdna:111]

[0001193125-16-447643:mdna:120]
We recorded net income of $19.8 million, or 8.5% of total revenues, for the three months ended December 25, 2015, compared with $8.7
million, or 4.6% of total revenues, for the three months ended December 26, 2014.

[0001193125-16-447643:mdna:121]
We recorded net income of $21.4 million, or 4.8%
of total revenues, for the six months ended December 25, 2015, compared with $19.8 million, or 5.2% of total revenues, for the six months ended December 26, 2014.

[0001193125-16-447643:mdna:122]
Other comprehensive loss.

[0001193125-16-447643:mdna:123]
We recorded other comprehensive loss of $0.3 million, or 0.1% of total revenues, for the three months ended December 25, 2015, compared
with $0.5 million, or 0.3% of total revenues, for the three months ended December 26, 2014.

[0001193125-16-447643:mdna:124]
We recorded other comprehensive loss of
$0.2 million, or 0.1% of total revenues, for the six months ended December 25, 2015, compared with $0.5 million, or 0.1% of total revenues, for the six months ended December 26, 2014.

[0001193125-16-447643:mdna:125]
[same as prior period, unchanged from 0001193125-15-364290:mdna:115]

[0001193125-16-447643:mdna:126]
[same as prior period, unchanged from 0001193125-15-364290:mdna:116]

[0001193125-16-447643:mdna:127]
We primarily finance our operations through cash flow from operations. As of December 25, 2015 and December 26, 2014, we had cash,
cash equivalents, and marketable securities of $266.6 million and $253.3 million, respectively, and outstanding debt of $55.5 million and $13.5 million, respectively.

[0001193125-16-447643:mdna:128]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of
three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents for the three and six months ended December 25, 2015 was 1.2% and 0.6%, respectively, and for the
three and six months ended December 26, 2014 was 0.7% and 0.6%, respectively.

[0001193125-16-447643:mdna:129]
[same as prior period, unchanged from 0001193125-15-364290:mdna:119]

[0001193125-16-447643:mdna:130]
During the three months ended December 25, 2015, we borrowed an additional $18.0 million under our Facility Agreement, $12.4 million of
which was used to fund the purchase of land in Chonburi, Thailand. As of December 25, 2015, we had a short-term borrowing of $48.0 million under our Facility Agreement. In addition, to better manage our cash on hand, we invested in short-term
marketable securities of $135.2 million as of December 25, 2015.

[0001193125-16-447643:mdna:131]
We believe that our current cash and cash equivalents, marketable
securities, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for the next 12 months. Our ability to sustain our working capital position is
subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001193125-16-447643:mdna:132]
In September 2015, we entered into an agreement to purchase land in Chonburi, Thailand. In
December 2015, the land purchase was completed and we began construction of a new manufacturing facility on such land, which we expect to complete in the second quarter of fiscal year 2017. We believe that our current manufacturing capacity is
sufficient to meet our anticipated production requirements for at least the next few quarters. Should there be a major delay in construction beyond our estimated completion date, we may not have the capacity to meet our anticipated production
requirements. We maintain a long-term loan associated with construction of production facilities at our Pinehurst campus in Thailand that will come due within the next 15 months. We also have a sufficient credit facility in place to fund the amount
needed to construct a new building at our Chonburi campus. We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations.

[0001193125-16-447643:mdna:133]
[same as prior period, unchanged from 0001193125-15-364290:mdna:123]

[0001193125-16-447643:mdna:134]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 25,2015 |  |  | December 26,2014 |  |
| Net cash provided by operating activities |  | $ | 23,704 |  |  | $ | 30,601 |  |
| Net cash used in investing activities |  | $ | (19,648 | ) |  | $ | (147,433 | ) |
| Net cash provided by (used in) financing activities |  | $ | 14,955 |  |  | $ | (4,624 | ) |
| Net increase (decrease) in cash and cash equivalents |  | $ | 19,011 |  |  | $ | (121,456 | ) |
| Cash and cash equivalent, beginning of period |  | $ | 112,978 |  |  | $ | 233,477 |  |
| Cash and cash equivalents, end of period |  | $ | 131,359 |  |  | $ | 111,971 |  |

[0001193125-16-447643:mdna:135]
[same as prior period, unchanged from 0001193125-15-364290:mdna:125]

[0001193125-16-447643:mdna:136]
Net cash provided by operating activities decreased by $6.9 million, or 22.5%, to $23.7 million for the six months ended December 25,
2015, compared with net cash provided by operating activities of $30.6 million for the six months ended December 26, 2014. This decrease was due to numbers of factors, including an increase in accounts receivable of $9.6 million and inventory
of $6.5 million related to higher sales and customer demand and an increase in payments to vendors of $4.2 million, offset by an increase in the unrealized loss exchange rate and fair value of derivatives of $5.6 million and an increase in
depreciation of $2.4 million.

[0001193125-16-447643:mdna:137]
[same as prior period, unchanged from 0001193125-15-364290:mdna:127]

[0001193125-16-447643:mdna:138]
Net cash used in investing activities decreased by $127.8 million, or 86.7%, to $19.6 million for the six months ended December 25, 2015,
compared with net cash used in investing activities of $147.4 million for the six months ended December 26, 2014. This decrease was primarily due to a net decrease in available-for-sale securities of $149.0 million, offset by an increase in
purchase of property, plant, and equipment of $21.0 million primarily to support our manufacturing operations in the United States and construct a new facility in Thailand.

[0001193125-16-447643:mdna:139]
[same as prior period, unchanged from 0001193125-15-364290:mdna:129]

[0001193125-16-447643:mdna:140]
Net
cash provided by financing activities increased by $19.6 million, or 423.4%, to $15.0 million for the six months ended December 25, 2015, compared with net cash used in financing activities of $4.6 million for the six months ended
December 26, 2014. This increase was primarily due to a drawdown of $18.0 million under our Facility Agreement, $12.4 million of which was used to fund the purchase of land in Chonburi, Thailand during the three months ended December 25,
2015.

[0001193125-16-447643:mdna:141]
[same as prior period, unchanged from 0001193125-15-364290:mdna:131]

[0001193125-16-447643:mdna:142]
[same as prior period, unchanged from 0001193125-15-364290:mdna:132]

[0001193125-16-447643:mdna:143]
[same as prior period, unchanged from 0001193125-15-364290:mdna:133]

[0001193125-16-447643:mdna:144]
[same as prior period, unchanged from 0001193125-15-364290:mdna:134]
