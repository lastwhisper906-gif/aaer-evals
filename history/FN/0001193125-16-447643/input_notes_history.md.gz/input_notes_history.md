# FN note change history — 0001193125-15-364290 → 0001193125-16-447643


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-02-02):
[0001193125-16-447643:note_history:1]
As of December 25, 2015 and June 26, 2015, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $0.8 million and $0.8 million, respectively.
  (was, 2015-11-03, similarity 0.984):
[0001193125-15-364290:note_history:1]
As of September 25, 2015 and June 26, 2015, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $0.7 million and $0.8 million, respectively.

- changed (2016-02-02):
[0001193125-16-447643:note_history:2]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, and New Jersey under operating lease arrangements
 that expire in various calendar years through 2020. Rental expense
 under these operating leases amounted to $0.6 million and $0.5
 million for the six months ended December 25, 2015 and
 December 26, 2014, respectively.
  (was, 2015-11-03, similarity 0.9364):
[0001193125-15-364290:note_history:2]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, and New Jersey under operating lease arrangements
 that expire in various calendar years through 2020. Rental expense
 under these operating leases amounted to $0.3 million and $0.2
 million for the three months ended September 25, 2015 and
 September 26, 2014, respectively.

- changed (2016-02-02):
[0001193125-16-447643:note_history:3]
As of December 25, 2015, the future minimum lease payments due
 under non-cancelable leases were as follows at the end of each
 fiscal year below:
  (was, 2015-11-03, similarity 0.9819):
[0001193125-15-364290:note_history:3]
As of September 25, 2015, the future minimum lease payments
 due under non-cancelable leases were as follows at the end of each
 fiscal year below:

- changed (2016-02-02):
[0001193125-16-447643:note_history:4]
| (amount in thousands) |  |  |  |
| 2016 |  | $ | 590 |  |
| 2017 |  |  | 1,034 |  |
| 2018 |  |  | 1,034 |  |
| 2019 |  |  | 572 |  |
| 2020 |  |  | 368 |  |
| Thereafter |  |  | 19 |  |
| Total minimum operating lease payments |  | $ | 3,617 |  |
  (was, 2015-11-03, similarity 0.9307):
[0001193125-15-364290:note_history:4]
| (amount in thousands) |  |  |  |
| 2016 |  | $ | 827 |  |
| 2017 |  |  | 949 |  |
| 2018 |  |  | 948 |  |
| 2019 |  |  | 479 |  |
| 2020 |  |  | 290 |  |
| Total minimum operating lease payments |  | $ | 3,493 |  |

- changed (2016-02-02):
[0001193125-16-447643:note_history:5]
As of December 25, 2015, the Company had an outstanding
 commitment to third parties of approximately $33.3 million, mainly
 related to the construction of a new manufacturing building at the
 Company’s Chonburi campus.
  (was, 2015-11-03, similarity 0.6):
[0001193125-15-364290:note_history:5]
As of September 25, 2015, the Company had an outstanding
 commitment to third parties of $4.1 million.

- removed (2016-02-02):
[0001193125-15-364290:note_history:6]
Purchase of land

- removed (2016-02-02):
[0001193125-15-364290:note_history:7]
On September 2, 2015, the Company entered into an agreement to
 purchase a parcel of land in Chonburi, Thailand, to support the
 expansion of the Company’s production in Thailand. The
 aggregate purchase price is approximately $11.8 million, of which
 $2.4 million has been deposited by the Company into escrow. The
 Company will pay the balance of the purchase price at the close of
 escrow, which is expected to occur on or before December 22,
 2015. The Company recorded this deposit as deposits and non-current
 assets on the unaudited condensed balance sheet as of
 September 25, 2015.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-02-02):
[0001193125-16-447643:note_history:8]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of December 25, 2015 and for the
 three and six months ended December 25, 2015 and
 December 26, 2014 includes only normal recurring adjustments,
 necessary for a fair statement of the financial statements set
 forth herein, in accordance with accounting principles generally
 accepted in the United States of America (“U.S. GAAP”)
 for interim financial information and rules and regulations of the
 Securities and Exchange Commission (“SEC”).
 Accordingly, such information does not include all of the
 information and footnotes required by U.S. GAAP for annual
 financial statements. For further information, please refer to the
 consolidated financial statements and footnotes thereto included in
 Fabrinet’s Annual Report on Form 10-K for the year ended
 June 26, 2015.
  (was, 2015-11-03, similarity 0.9666):
[0001193125-15-364290:note_history:8]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of September 25, 2015 and for the
 three months ended September 25, 2015 and September 26,
 2014 includes only normal recurring adjustments, necessary for a
 fair statement of the financial statements set forth herein, in
 accordance with accounting principles generally accepted in the
 United States of America (“U.S. GAAP”) for interim
 financial information and rules and regulations of the Securities
 and Exchange Commission (“SEC”). Accordingly, such
 information does not include all of the information and footnotes
 required by U.S. GAAP for annual financial statements. For further
 information, please refer to the consolidated financial statements
 and footnotes thereto included in Fabrinet’s Annual Report on
 Form 10-K for the year ended June 26, 2015.

- changed (2016-02-02):
[0001193125-16-447643:note_history:9]
The balance sheet as of June 26, 2015 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three and six
 months ended December 25, 2015 and December 26, 2014 may
 not be indicative of results for the year ending June 24, 2016
 or any future periods.
  (was, 2015-11-03, similarity 0.8984):
[0001193125-15-364290:note_history:9]
The balance sheet as of June 26, 2015 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three months
 ended September 25, 2015 and September 26, 2014 may not
 be indicative of results for the year ending June 24, 2016 or
 any future periods.

- changed (2016-02-02):
[0001193125-16-447643:note_history:10]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended
 December 25, 2015 and December 26, 2014 each consisted of
 13 weeks. The six months ended December 25, 2015 and
 December 26, 2014 each consisted of 26 weeks. Fiscal year 2016
 will be comprised of 52 weeks and will end on June 24,
 2016.
  (was, 2015-11-03, similarity 0.7374):
[0001193125-15-364290:note_history:10]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended
 September 25, 2015 and September 26, 2014 each consisted
 of 13 weeks. Fiscal year 2016 will be comprised of 52 weeks and
 will end on June 24, 2016.

- added (2016-02-02):
[0001193125-16-447643:note_history:11]
In January 2016, the Financial Accounting Standards Board
 (“FASB”) issued Accounting Standards Update
 (“ASU”) 2016-01, “Financial
 Instruments – Overall (Subtopic 825-10): Recognition and
 Measurement of Financial Assets and Financial Liabilities”.
 This new guidance makes targeted improvements to existing U.S. GAAP
 by requiring certain equity investments to be measured at fair
 value, requiring use of the exit price notion when measuring the
 fair value of financial instruments for disclosure purposes and
 requiring separate presentation of financial assets and financial
 liabilities by measurement category and form of financial asset
 (that is, securities or loans and receivables) on the balance sheet
 or the accompanying notes to the financial statements. The ASU on
 recognition and measurement will take effect for public companies
 for fiscal years beginning after December 15, 2017, including
 interim periods within those fiscal years. The Company is
 currently evaluating the impact of adoption of this update on its
 consolidated financial statements.

- added (2016-02-02):
[0001193125-16-447643:note_history:12]
In November 2015, the FASB issued ASU 2015-17, “Balance Sheet
 Classification of Deferred Taxes”, which will require
 entities to present deferred tax assets (“DTAs”) and
 deferred tax liabilities (“DTLs”) as non-current in a
 classified balance sheet. The ASU simplifies the current guidance,
 which requires entities to separately present DTAs and DTLs as
 current and non-current in a classified balance sheet. For public
 business entities, the amendments in this ASU are effective for
 financial statements issued for annual periods beginning after
 December 15, 2016, and interim periods within those annual
 periods. The Company is currently evaluating the impact of adoption
 of this update on its consolidated financial statements.

- changed (2016-02-02):
[0001193125-16-447643:note_history:13]
In August 2015, the FASB issued ASU 2015-15, “Interest
 – Imputation of Interest (Subtopic 835-30): Presentation and
 Subsequent Measurement of Debt Issuance Costs Associated with
 Line-of-Credit Arrangements”. This ASU amended the
 presentation or subsequent measurement of debt issuance costs
 related to the line-of-credit arrangement. The Company is currently
 evaluating the impact of adoption of this update on its
 consolidated financial statements.
  (was, 2015-11-03, similarity 0.8933):
[0001193125-15-364290:note_history:13]
In August 2015, the Financial Accounting Standards Board
 (“FASB”) issued Accounting Standards Update
 (“ASU”) 2015-15, “Interest – Imputation of
 Interest (Subtopic 835-30): Presentation and Subsequent Measurement
 of Debt Issuance Costs Associated with Line-of-Credit
 Arrangements”. This ASU amended the presentation or
 subsequent measurement of debt issuance costs related to the
 line-of-credit arrangement. The Company is currently evaluating the
 impact of adoption of this update on its consolidated financial
 statements.

- changed (2016-02-02):
[0001193125-16-447643:note_history:14]
In April 2015, the FASB issued ASU 2015-03,
 “Interest – Imputation of Interest (Subtopic
 835-30): Simplifying the Presentation of Debt Issuance
 Costs”. The update requires debt issuance costs related to a
 recognized debt liability be presented in the balance sheet as a
 direct deduction from the carrying amount of the related debt
 liability instead of being presented as an asset. Debt disclosures
 will include the face amount of the debt liability and the
 effective interest rate. The update requires retrospective
 application and represents a change in accounting principle. The
 update is effective for fiscal years beginning after
 December 15, 2015. Early adoption is permitted for financial
 statements that have not been previously issued. The Company is
 currently evaluating the impact of adoption of this update on its
 consolidated financial statements.
  (was, 2015-11-03, similarity 0.9988):
[0001193125-15-364290:note_history:14]
In April 2015, the FASB issued ASU 2015-03, “Interest -
 Imputation of Interest (Subtopic 835-30): Simplifying the
 Presentation of Debt Issuance Costs”. The update requires
 debt issuance costs related to a recognized debt liability be
 presented in the balance sheet as a direct deduction from the
 carrying amount of the related debt liability instead of being
 presented as an asset. Debt disclosures will include the face
 amount of the debt liability and the effective interest rate. The
 update requires retrospective application and represents a change
 in accounting principle. The update is effective for fiscal years
 beginning after December 15, 2015. Early adoption is permitted
 for financial statements that have not been previously issued. The
 Company is currently evaluating the impact of adoption of this
 update on its consolidated financial statements.

- changed (2016-02-02):
[0001193125-16-447643:note_history:15]
In June 2014, the FASB issued ASU No. 2014-12,
 “Compensation – Stock Compensation (Topic 718):
 Accounting for Share-Based Payments When the Terms of an Award
 Provide That a Performance Target Could Be Achieved After the
 Requisite Service Period”. This ASU requires that a
 performance target that affects vesting, and that could be achieved
 after the requisite service period, be treated as a performance
 condition. As such, the performance target should not be reflected
 in estimating the grant date fair value of the award. This update
 further clarifies that compensation cost should be recognized in
 the period in which it becomes probable that the performance target
 will be achieved and should represent the compensation cost
 attributable to the period(s) for which the requisite service has
 already been rendered. This update is required to be adopted by all
 public companies for annual periods and interim reporting periods
 beginning after December 15, 2015. Early adoption of this ASU
 is permitted. The Company does not expect that the adoption of this
 update will have an effect on its consolidated financial
 statements.
  (was, 2015-11-03, similarity 0.9427):
[0001193125-15-364290:note_history:15]
In June 2014, the FASB issued ASU No. 2014-12,
 “Compensation – Stock Compensation (Topic 718):
 Accounting for Share-Based
 Payments When the Terms of an Award Provide That a Performance
 Target Could Be Achieved After the Requisite Service Period”.
 This ASU requires that a performance target that affects vesting,
 and that could be achieved after the requisite service period, be
 treated as a performance condition. As such, the performance target
 should not be reflected in estimating the grant date fair value of
 the award. This update further clarifies that compensation cost
 should be recognized in the period in which it becomes probable
 that the performance target will be achieved and should represent
 the compensation cost attributable to the period(s) for which the
 requisite service has already been rendered. This update is
 required to be adopted by all public companies for annual periods
 and interim reporting periods beginning after December 15,
 2015. Early adoption of this ASU is permitted. The Company is
 currently evaluating the impact of adoption of this update on its
 consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-02-02):
[0001193125-16-447643:note_history:16]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  | As of December 25, 2015 |  |  | As of June 26, 2015 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  | January 2016 (2) |  | $ | 48,000 |  |  | $ | 30,000 |  |
| Current portion of long-term borrowing |  |  | 6,000 |  |  |  | 6,000 |  |
|  |  | $ | 54,000 |  |  | $ | 36,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | March 2017 |  | $ | 7,500 |  |  | $ | 10,500 |  |
| Less: Current portion |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  | $ | 1,500 |  |  | $ | 4,500 |  |
  (was, 2015-11-03, similarity 0.9272):
[0001193125-15-364290:note_history:16]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  | As of September 25, 2015 |  |  | As of June 26, 2015 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  | October 2015(2) |  | $ | 30,000 |  |  | $ | 30,000 |  |
| Current portion of long-term borrowing |  |  |  |  | 6,000 |  |  |  | 6,000 |  |
|  |  |  |  |  |  | $ | 36,000 |  |  | $ | 36,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | March 2017 |  | $ | 9,000 |  |  | $ | 10,500 |  |
| Less: Current portion |  |  |  |  |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  |  |  |  | $ | 3,000 |  |  | $ | 4,500 |  |

- changed (2016-02-02):
[0001193125-16-447643:note_history:17]
| (2) | In January 2016, the maturity date of these revolving borrowings were extended to mature in February 2016. |
  (was, 2015-11-03, similarity 0.7729):
[0001193125-15-364290:note_history:17]
| (2) | On October 16, 2015, the maturity date of this revolving borrowing was extended to November 23, 2015. |

- changed (2016-02-02):
[0001193125-16-447643:note_history:18]
Under the long-term borrowing contract of a subsidiary, the loan is
 secured by certain property, plant and equipment. The carrying
 amount of assets secured and pledged as collateral to such loan as
 of December 25, 2015 and June 26, 2015 was $48.8 million
 and $50.0 million, respectively. This subsidiary is also required
 to comply with maximum ratios of debt to equity and minimum levels
 of debt service coverage ratios, and Fabrinet must maintain an
 effective shareholding ratio. The carrying amounts of bank
 borrowings approximate their fair value.
  (was, 2015-11-03, similarity 0.966):
[0001193125-15-364290:note_history:18]
Under the long-term borrowing contract of a subsidiary, the loan is
 secured by certain property, plant and equipment. The carrying
 amount of assets secured and pledged as collateral as of
 September 25, 2015 and June 26, 2015 was $49.4 million
 and $50.0 million, respectively. This subsidiary is also required
 to comply with the maximum ratios of debt to equity and minimum
 levels of debt service coverage ratios, and Fabrinet must maintain
 an effective shareholding ratio. The carrying amounts of bank
 borrowings approximate their fair value.

- changed (2016-02-02):
[0001193125-16-447643:note_history:19]
As of December 25, 2015 and June 26, 2015, the Company
 was in compliance with its long-term bank borrowing agreement. In
 addition to financial ratios, certain of the Company’s credit
 facilities include customary events of default.
  (was, 2015-11-03, similarity 0.9841):
[0001193125-15-364290:note_history:19]
As of September 25, 2015 and June 26, 2015, the Company
 was in compliance with its long-term bank borrowing agreement. In
 addition to financial ratios, certain of the Company’s credit
 facilities include customary events of default.

- changed (2016-02-02):
[0001193125-16-447643:note_history:20]
The movements of long-term loans were as follows for the six months
 ended December 25, 2015 and December 26, 2014:
  (was, 2015-11-03, similarity 0.9151):
[0001193125-15-364290:note_history:20]
The movements of long-term loans were as follows for the three
 months ended September 25, 2015 and September 26,
 2014:

- changed (2016-02-02):
[0001193125-16-447643:note_history:21]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 25, 2015 |  |  | December 26, 2014 |  |
| Opening book amount |  | $ | 10,500 |  |  | $ | 16,500 |  |
| Repayment during the period |  |  | (3,000 | ) |  |  | (3,000 | ) |
| Closing book amount |  | $ | 7,500 |  |  | $ | 13,500 |  |
  (was, 2015-11-03, similarity 0.876):
[0001193125-15-364290:note_history:21]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 25, 2015 |  |  | September 26, 2014 |  |
| Opening net book amount |  | $ | 10,500 |  |  | $ | 16,500 |  |
| Repayment during the period |  |  | (1,500 | ) |  |  | (1,500 | ) |
| Closing net book amount |  | $ | 9,000 |  |  | $ | 15,000 |  |

- changed (2016-02-02):
[0001193125-16-447643:note_history:22]
As of December 25, 2015, future maturities of long-term debt
 during each fiscal year were as follows:
  (was, 2015-11-03, similarity 0.7549):
[0001193125-15-364290:note_history:22]
As of September 25, 2015, future maturities of long-term debt
 were as follows at the end of each fiscal year below:

- changed (2016-02-02):
[0001193125-16-447643:note_history:23]
Fabrinet entered into a syndicated senior credit facility agreement
 (the “Facility Agreement”) with a consortium of banks
 on May 22, 2014. The Facility Agreement, led by Bank of
 America, provides for a $200.0 million credit line, comprised of a
 $150.0 million revolving loan facility and a $50.0 million delayed
 draw term loan facility. The revolving loan facility contains an
 accordion feature permitting Fabrinet to request an increase in the
 facility up to $100.0 million subject to customary terms and
 conditions and provided that no default or event of default exists
 at the time of request. The revolving loan facility terminates and
 all amounts outstanding are due and payable in full on May 22,
 2019. The principal amount of any drawn term loans must be repaid
 according to scheduled quarterly amortization payments, with final
 payment of all amounts outstanding, plus accrued interest, being
 due May 22, 2019.
  (was, 2015-11-03, similarity 0.9977):
[0001193125-15-364290:note_history:23]
Fabrinet entered into a syndicated senior credit facility agreement
 (the “Facility Agreement”) with a consortium of banks
 on May 22, 2014. The Facility Agreement, led by Bank of
 America, provides for a $200.0 million credit line, comprised of a
 $150.0 million revolving loan facility and a $50.0 million delayed
 draw term loan facility. The revolving loan facility contains an
 accordion feature permitting Fabrinet to request an increase in the
 facility up to $100.0 million subject to customary terms and
 conditions and provided that no default or event of default exists
 at the time of request. The revolving loan facility terminates and
 all amounts outstanding are due and payable in full on May 22,
 2019. The principal amount of any drawn term loans must be repaid
 according to the scheduled quarterly amortization payments, with
 final payment of all amounts outstanding, plus accrued interest,
 being due May 22, 2019.

- changed (2016-02-02):
[0001193125-16-447643:note_history:24]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. As of
 December 25, 2015, the outstanding revolving borrowing under
 the Facility Agreement was $48.0 million, resulting in available
 credit facilities of $152.0 million. Borrowings under the revolving
 credit facility are classified as current liabilities in the
 unaudited condensed consolidated balance sheets as the Company has
 the periodic option to renew, or pay all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. During January 2016, the
 Company sent notices to the bank to renew the maturity date of its
 revolving borrowings. The bank approved the notices and extended
 the maturity to February 2016.
  (was, 2015-11-03, similarity 0.949):
[0001193125-15-364290:note_history:24]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allows the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. As of
 September 25, 2015, the outstanding revolving borrowing under
 the Facility Agreement was $30.0 million, resulting in available
 credit facilities of $170.0 million. Borrowings under the revolving
 credit facility are classified as current liabilities in the
 unaudited condensed consolidated balance sheet as the Company has
 the periodic option to renew, or pay all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. On October 16, 2015, the
 Company sent a notice to the bank to renew the maturity date of
 this revolving borrowing. The bank approved the notice and extended
 the maturity date to November 23, 2015.

- changed (2016-02-02):
[0001193125-16-447643:note_history:25]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or the
 equivalent under the local law, can be effected. The Facility
 Agreement contains customary affirmative and negative covenants.
 Negative covenants include, among other things, limitations on
 liens, indebtedness, investments, mergers, sales of assets, changes
 in the nature of the business, dividends and distributions,
 affiliate transactions and capital expenditures. The Facility
 Agreement contains financial covenants requiring Fabrinet to
 maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage
 ratio of not more than 2.50:1.00; and (iv) a minimum quick
 ratio of not less than 1.10:1.00. Each of these financial covenants
 is calculated on a consolidated basis for the consecutive four
 fiscal quarter period then ended. As of December 25, 2015, the
 Company was in compliance with all covenants under the Facility
 Agreement.
  (was, 2015-11-03, similarity 0.9979):
[0001193125-15-364290:note_history:25]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or
 the equivalent under the local law, can be effected. The Facility
 Agreement contains customary affirmative and negative covenants.
 Negative covenants include, among other things, limitations on
 liens, indebtedness, investments, mergers, sales of assets, changes
 in the nature of the business, dividends and distributions,
 affiliate transactions and capital expenditures. The Facility
 Agreement contains financial covenants requiring Fabrinet to
 maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage
 ratio of not more than 2.50:1.00; and (iv) a minimum quick
 ratio of not less than 1.10:1.00. Each of these financial covenants
 is calculated on a consolidated basis for the consecutive four
 fiscal quarter period then ended. As of September 25, 2015,
 the Company was in compliance with all covenants under the Facility
 Agreement.

- changed (2016-02-02):
[0001193125-16-447643:note_history:26]
Undrawn available credit facilities classified by available period
 of future borrowing as of December 25, 2015 and June 26,
 2015 were as follows:
  (was, 2015-11-03, similarity 0.9815):
[0001193125-15-364290:note_history:26]
Undrawn available credit facilities classified by available period
 of future borrowing as of September 25, 2015 and June 26,
 2015 were as follows:

- changed (2016-02-02):
[0001193125-16-447643:note_history:27]
| (amount in thousands) |  | December 25, 2015 |  |  | June 26, 2015 |  |
| Short-term |  | $ | 1,386 |  |  | $ | 1,480 |  |
| Long-term |  | $ | 152,000 |  |  | $ | 170,000 |  |
  (was, 2015-11-03, similarity 0.9817):
[0001193125-15-364290:note_history:27]
| (amount in thousands) |  | September 25, 2015 |  |  | June 26, 2015 |  |
| Short-term |  | $ | 1,380 |  |  | $ | 1,480 |  |
| Long-term |  | $ | 170,000 |  |  | $ | 170,000 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-02-02):
[0001193125-16-447643:note_history:28]
The movements of long-term loans were as follows for the six months
 ended December 25, 2015 and December 26, 2014:
  (was, 2015-11-03, similarity 0.9151):
[0001193125-15-364290:note_history:28]
The movements of long-term loans were as follows for the three
 months ended September 25, 2015 and September 26,
 2014:

- changed (2016-02-02):
[0001193125-16-447643:note_history:29]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 25, 2015 |  |  | December 26, 2014 |  |
| Opening book amount |  | $ | 10,500 |  |  | $ | 16,500 |  |
| Repayment during the period |  |  | (3,000 | ) |  |  | (3,000 | ) |
| Closing book amount |  | $ | 7,500 |  |  | $ | 13,500 |  |
  (was, 2015-11-03, similarity 0.876):
[0001193125-15-364290:note_history:29]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 25, 2015 |  |  | September 26, 2014 |  |
| Opening net book amount |  | $ | 10,500 |  |  | $ | 16,500 |  |
| Repayment during the period |  |  | (1,500 | ) |  |  | (1,500 | ) |
| Closing net book amount |  | $ | 9,000 |  |  | $ | 15,000 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-02-02):
[0001193125-16-447643:note_history:30]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  | As of December 25, 2015 |  |  | As of June 26, 2015 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  | January 2016 (2) |  | $ | 48,000 |  |  | $ | 30,000 |  |
| Current portion of long-term borrowing |  |  | 6,000 |  |  |  | 6,000 |  |
|  |  | $ | 54,000 |  |  | $ | 36,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | March 2017 |  | $ | 7,500 |  |  | $ | 10,500 |  |
| Less: Current portion |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  | $ | 1,500 |  |  | $ | 4,500 |  |
  (was, 2015-11-03, similarity 0.9272):
[0001193125-15-364290:note_history:30]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  | As of September 25, 2015 |  |  | As of June 26, 2015 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  | October 2015(2) |  | $ | 30,000 |  |  | $ | 30,000 |  |
| Current portion of long-term borrowing |  |  |  |  | 6,000 |  |  |  | 6,000 |  |
|  |  |  |  |  |  | $ | 36,000 |  |  | $ | 36,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | March 2017 |  | $ | 9,000 |  |  | $ | 10,500 |  |
| Less: Current portion |  |  |  |  |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  |  |  |  |  | $ | 3,000 |  |  | $ | 4,500 |  |

- changed (2016-02-02):
[0001193125-16-447643:note_history:31]
| (2) | In January 2016, the maturity date of these revolving borrowings were extended to mature in February 2016. |
  (was, 2015-11-03, similarity 0.7729):
[0001193125-15-364290:note_history:31]
| (2) | On October 16, 2015, the maturity date of this revolving borrowing was extended to November 23, 2015. |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-02-02):
[0001193125-16-447643:note_history:32]
Undrawn available credit facilities classified by available period
 of future borrowing as of December 25, 2015 and June 26,
 2015 were as follows:
  (was, 2015-11-03, similarity 0.9815):
[0001193125-15-364290:note_history:32]
Undrawn available credit facilities classified by available period
 of future borrowing as of September 25, 2015 and June 26,
 2015 were as follows:

- changed (2016-02-02):
[0001193125-16-447643:note_history:33]
| (amount in thousands) |  | December 25, 2015 |  |  | June 26, 2015 |  |
| Short-term |  | $ | 1,386 |  |  | $ | 1,480 |  |
| Long-term |  | $ | 152,000 |  |  | $ | 170,000 |  |
  (was, 2015-11-03, similarity 0.9817):
[0001193125-15-364290:note_history:33]
| (amount in thousands) |  | September 25, 2015 |  |  | June 26, 2015 |  |
| Short-term |  | $ | 1,380 |  |  | $ | 1,480 |  |
| Long-term |  | $ | 170,000 |  |  | $ | 170,000 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-02-02):
[0001193125-16-447643:note_history:34]
As of December 25, 2015, future maturities of long-term debt
 during each fiscal year were as follows:
  (was, 2015-11-03, similarity 0.7549):
[0001193125-15-364290:note_history:34]
As of September 25, 2015, future maturities of long-term debt
 were as follows at the end of each fiscal year below:


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2016-02-02):
[0001193125-16-447643:note_history:35]
During January 2016, the Company incurred severance expenses of
 approximately $0.7 million in connection with a separation
 agreement which the Company entered into with a former named
 executive officer who resigned from the Company effective
 December 31, 2015.

- removed (2016-02-02):
[0001193125-15-364290:note_history:36]
Executive officer separation agreement

- removed (2016-02-02):
[0001193125-15-364290:note_history:37]
On September 29, 2015, the Company entered into a Separation
 Agreement and Release (the “Separation Agreement”) with
 an executive officer who resigned from the Company effective
 December 31, 2015 (the “Separation Date”). During
 the period from October 1, 2015 through the Separation Date,
 the officer will continue as an employee and provide certain
 transition services. In connection with the Separation Agreement,
 the Company will incur severance expenses of approximately $0.7
 million during the second quarter of fiscal year 2016.

- removed (2016-02-02):
[0001193125-15-364290:note_history:38]
Capital expenditure commitment

- removed (2016-02-02):
[0001193125-15-364290:note_history:39]
In October 2015, the Company entered into a construction contract
 with local contractor for construction of new manufacturing
 building at the Company’s Chonburi campus. The contract price
 is approximately of $30.4 million.
