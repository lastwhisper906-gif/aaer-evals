# FN 8-K — 0001193125-16-446099 filed 2016-02-01

## item codes, every 8-K on or before 2016-02-02

- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2016-02-02

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-446099:8k_2_02:1]
EX-99.1
2
d97737dex991.htm
EX-99.1

[0001193125-16-446099:8k_2_02:2]
EX-99.1

[0001193125-16-446099:8k_2_02:3]
Exhibit 99.1

[0001193125-16-446099:8k_2_02:4]
Fabrinet Announces Second Quarter Fiscal-Year 2016 Financial Results

[0001193125-16-446099:8k_2_02:5]
BANGKOK, Thailand – February 1, 2016 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical,
electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its second fiscal quarter ended December 25, 2015.

[0001193125-16-446099:8k_2_02:6]
Tom Mitchell, Chief Executive Officer of Fabrinet, said, “We delivered a strong second quarter with record revenue and strong profitability. Upside in
the quarter was driven by a combination of growth from new customer programs and increasing production from existing customer programs, as we benefit from technology investments that we continue to make. While we have sufficient capacity to meet our
growing customer demand for several quarters, construction of the first new building at our new campus outside Bangkok is underway, which will help drive further profitable growth over the longer-term.”

[0001193125-16-446099:8k_2_02:7]
Second quarter Fiscal-Year 2016 Financial Highlights

[0001193125-16-446099:8k_2_02:8]
GAAP Results

[0001193125-16-446099:8k_2_02:9]
|  | • |  | Revenue was $233.0 million for the second quarter of fiscal year 2016, an increase of 24% compared to total revenue of $188.4 million for the comparable period in fiscal year 2015. |

[0001193125-16-446099:8k_2_02:10]
|  | • |  | GAAP net income for the second quarter of fiscal year 2016 was $19.8 million, compared to GAAP net income of $8.7 million in the second quarter of fiscal year 2015. |

[0001193125-16-446099:8k_2_02:11]
|  | • |  | GAAP net income per diluted share for the second quarter of fiscal year 2016 was $0.54, compared to GAAP net income per diluted share of $0.24 in the second quarter of fiscal year 2015. |

[0001193125-16-446099:8k_2_02:12]
Non-GAAP Results

[0001193125-16-446099:8k_2_02:13]
|  | • |  | Non-GAAP net income in the second quarter of fiscal 2016 was $18.2 million, an increase of 26% compared to non-GAAP net income of $14.4 million in the same period a year ago. |

[0001193125-16-446099:8k_2_02:14]
|  | • |  | Non-GAAP net income per diluted share in the second quarter of fiscal 2016 was $0.50, an increase from non-GAAP net income per diluted share of $0.40 in the same period a year ago. |

[0001193125-16-446099:8k_2_02:15]
Business Outlook

[0001193125-16-446099:8k_2_02:16]
Based on information available as of
February 1, 2016, Fabrinet is issuing guidance for the third quarter of fiscal 2016 ending March 25, 2016, as follows:

[0001193125-16-446099:8k_2_02:17]
|  | • |  | Fabrinet expects third quarter revenue to be in the range of $240 million to $244 million. |

[0001193125-16-446099:8k_2_02:18]
|  | • |  | GAAP net income per diluted share is expected to be in the range of $0.47 to $0.49, based on approximately 36.8 million fully diluted shares outstanding. |

[0001193125-16-446099:8k_2_02:19]
|  | • |  | Non-GAAP net income per diluted share is expected to be in the range of $0.52 to $0.54, based on approximately 36.8 million fully diluted shares outstanding. |

[0001193125-16-446099:8k_2_02:20]
Conference Call Information

[0001193125-16-446099:8k_2_02:21]
| What: |  | Fabrinet Second quarter Fiscal-Year 2016 Financial Results Conference Call |
| When: |  | Monday, February 1, 2016 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic (253) 237-1137, international Passcode: 25405326 |
| Replay: |  | (855) 859-2056, domestic (404) 537-3406, international Passcode: 25405326 |
| Webcast: |  | http://investor.fabrinet.com (live and replay) |

[0001193125-16-446099:8k_2_02:22]
This press release and any other information related to the call will also be posted on Fabrinet’s website at
http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-16-446099:8k_2_02:23]
About Fabrinet

[0001193125-16-446099:8k_2_02:24]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original
equipment manufacturers of complex products, such as optical communication components, modules and subsystems, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire
manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and test. Fabrinet focuses on production of high complexity products in any mix and any volume.
Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the People’s Republic of China and the United States of America. For more information visit: www.fabrinet.com.

[0001193125-16-446099:8k_2_02:25]
Forward-Looking Statements

[0001193125-16-446099:8k_2_02:26]
Use of Non-GAAP Financials

[0001193125-16-446099:8k_2_02:27]
The Company refers to
the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding the Company’s ongoing operational performance. Non-GAAP net income excludes share-based compensation
expenses, executive separation costs, investigation cost, expenses related to flooding, expenses related to reduction in workforce, amortization of debt issuance costs and unrealized gain or loss on foreign currency. We have excluded these items in
order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP
financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001193125-16-446099:8k_2_02:28]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our
competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure company
performance for the purposes of determining employee incentive plan compensation.

[0001193125-16-446099:8k_2_02:29]
SOURCE: Fabrinet

[0001193125-16-446099:8k_2_02:30]
Investor Contact:

[0001193125-16-446099:8k_2_02:31]
Garo Toomajanian

[0001193125-16-446099:8k_2_02:32]
ir@fabrinet.com

[0001193125-16-446099:8k_2_02:33]
Fabrinet

[0001193125-16-446099:8k_2_02:34]
Unaudited Condensed Consolidated Balance Sheets

[0001193125-16-446099:8k_2_02:35]
As of
December 25, 2015 and June 26, 2015

[0001193125-16-446099:8k_2_02:36]
| (in thousands of U.S. dollars, except share data) |  | December 25,2015 |  |  | June 26,2015 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 131,359 |  |  | $ | 112,978 |  |
| Marketable securities |  |  | 135,199 |  |  |  | 142,866 |  |
| Trade accounts receivable, net |  |  | 147,430 |  |  |  | 134,952 |  |
| Inventory, net |  |  | 140,862 |  |  |  | 130,613 |  |
| Deferred tax assets |  |  | 1,555 |  |  |  | 1,662 |  |
| Prepaid expenses |  |  | 1,003 |  |  |  | 2,135 |  |
| Other current assets |  |  | 1,612 |  |  |  | 1,833 |  |
| Total current assets |  |  | 559,020 |  |  |  | 527,039 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 159,415 |  |  |  | 140,654 |  |
| Intangibles, net |  |  | 321 |  |  |  | 137 |  |
| Deferred tax assets |  |  | 2,249 |  |  |  | 2,249 |  |
| Deferred debt issuance costs and others |  |  | 2,581 |  |  |  | 2,424 |  |
| Total non-current assets |  |  | 164,566 |  |  |  | 145,464 |  |
| Total Assets |  | $ | 723,586 |  |  | $ | 672,503 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Bank borrowings, including revolving loan and current portion of Long-term loan from bank |  | $ | 54,000 |  |  | $ | 36,000 |  |
| Trade accounts payable |  |  | 114,911 |  |  |  | 115,319 |  |
| Income tax payable |  |  | 1,757 |  |  |  | 1,470 |  |
| Accrued payroll, bonus and related expenses |  |  | 9,528 |  |  |  | 9,804 |  |
| Accrued expenses |  |  | 12,512 |  |  |  | 6,405 |  |
| Other payables |  |  | 14,445 |  |  |  | 12,050 |  |
| Total current liabilities |  |  | 207,153 |  |  |  | 181,048 |  |
| Non-current liabilities |  |  |  |  |
| Long-term loans from bank, non-current portion |  |  | 1,500 |  |  |  | 4,500 |  |
| Deferred tax liability |  |  | 1,043 |  |  |  | 737 |  |
| Severance liabilities |  |  | 5,767 |  |  |  | 5,477 |  |
| Other non-current liabilities |  |  | 1,899 |  |  |  | 1,797 |  |
| Total non-current liabilities |  |  | 10,209 |  |  |  | 12,511 |  |
| Total Liabilities |  |  | 217,362 |  |  |  | 193,559 |  |
| Commitments and contingencies |  |  |  |  |
| Shareholders’ equity |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of December 25, 2015 and June 26, 2015) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 35,871,740 shares and 35,437,654 shares issued and outstanding as of December 25, 2015 and June 26, 2015, respectively) |  |  | 359 |  |  |  | 354 |  |
| Additional paid-in capital |  |  | 95,482 |  |  |  | 89,390 |  |
| Retained earnings |  |  | 410,650 |  |  |  | 389,244 |  |
| Accumulated other comprehensive loss |  |  | (267 | ) |  |  | (44 | ) |
| Total Shareholders’ Equity |  |  | 506,224 |  |  |  | 478,944 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 723,586 |  |  | $ | 672,503 |  |

[0001193125-16-446099:8k_2_02:37]
Fabrinet

[0001193125-16-446099:8k_2_02:38]
Unaudited Condensed Consolidated Statements of Operations and Comprehensive Income

[0001193125-16-446099:8k_2_02:39]
For the three and six months ended December 25, 2015 and December 26, 2014

[0001193125-16-446099:8k_2_02:40]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (in thousands of U.S. dollars, except per share amounts) |  | December 25,2015 |  |  | December 26,2014 |  |  | December 25,2015 |  |  | December 26,2014 |  |
| Revenues |  | $ | 233,038 |  |  | $ | 188,353 |  |  | $ | 449,471 |  |  | $ | 377,678 |  |
| Cost of revenues |  |  | (204,545 | ) |  |  | (167,292 | ) |  |  | (394,967 | ) |  |  | (336,111 | ) |
| Gross profit |  |  | 28,493 |  |  |  | 21,061 |  |  |  | 54,504 |  |  |  | 41,567 |  |
| Selling, general and administrative expenses |  |  | (13,715 | ) |  |  | (10,314 | ) |  |  | (25,615 | ) |  |  | (19,051 | ) |
| Other expenses in relation to flood |  |  | — |  |  |  | — |  |  |  | (864 | ) |  |  | — |  |
| Expenses related to reduction in workforce |  |  | — |  |  |  | (1,153 | ) |  |  | — |  |  |  | (1,153 | ) |
| Operating income |  |  | 14,778 |  |  |  | 9,594 |  |  |  | 28,025 |  |  |  | 21,363 |  |
| Interest income |  |  | 455 |  |  |  | 324 |  |  |  | 897 |  |  |  | 698 |  |
| Interest expense |  |  | (419 | ) |  |  | (117 | ) |  |  | (821 | ) |  |  | (250 | ) |
| Foreign exchange gain (loss), net |  |  | 6,166 |  |  |  | 83 |  |  |  | (4,326 | ) |  |  | (23 | ) |
| Other income (expense) |  |  | 106 |  |  |  | (134 | ) |  |  | 209 |  |  |  | (31 | ) |
| Income before income taxes |  |  | 21,086 |  |  |  | 9,750 |  |  |  | 23,984 |  |  |  | 21,757 |  |
| Income tax expense |  |  | (1,283 | ) |  |  | (1,024 | ) |  |  | (2,578 | ) |  |  | (1,995 | ) |
| Net income |  |  | 19,803 |  |  |  | 8,726 |  |  |  | 21,406 |  |  |  | 19,762 |  |
| Other comprehensive loss, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Change in net unrealized holding losses on marketable securities |  |  | (262 | ) |  |  | (486 | ) |  |  | (175 | ) |  |  | (486 | ) |
| Other |  |  | (48 | ) |  |  | — |  |  |  | (48 | ) |  |  | — |  |
| Total other comprehensive loss, net of tax |  |  | (310 | ) |  |  | (486 | ) |  |  | (223 | ) |  |  | (486 | ) |
| Net comprehensive income |  | $ | 19,493 |  |  | $ | 8,240 |  |  | $ | 21,183 |  |  | $ | 19,276 |  |
| Earnings per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.55 |  |  | $ | 0.25 |  |  | $ | 0.60 |  |  | $ | 0.56 |  |
| Diluted |  | $ | 0.54 |  |  | $ | 0.24 |  |  | $ | 0.59 |  |  | $ | 0.55 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 35,812 |  |  |  | 35,349 |  |  |  | 35,695 |  |  |  | 35,289 |  |
| Diluted |  |  | 36,826 |  |  |  | 35,917 |  |  |  | 36,570 |  |  |  | 35,752 |  |

[0001193125-16-446099:8k_2_02:41]
Fabrinet

[0001193125-16-446099:8k_2_02:42]
Unaudited Condensed Consolidated Statements of Cash Flows

[0001193125-16-446099:8k_2_02:43]
For the six months ended December 25, 2015 and December 26, 2014

[0001193125-16-446099:8k_2_02:44]
|  |  | Six Months Ended |  |
| (in thousands of U.S. dollars) |  | December 25,2015 |  |  | December 26,2014 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income for the period |  | $ | 21,406 |  |  | $ | 19,762 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 8,268 |  |  |  | 5,907 |  |
| Amortization of intangibles |  |  | 26 |  |  |  | 42 |  |
| Gain on disposal of property, plant and equipment |  |  | (49 | ) |  |  | (46 | ) |
| Loss from sales and maturities of available-for-sale securities |  |  | 124 |  |  |  | — |  |
| Amortization of investment premium |  |  | 457 |  |  |  | 298 |  |
| Amortization of deferred debt issuance costs |  |  | 358 |  |  |  | 228 |  |
| Reversal of allowance for doubtful accounts |  |  | (7 | ) |  |  | (3 | ) |
| Unrealized loss (gain) on exchange rate and fair value of derivative |  |  | 5,566 |  |  |  | (19 | ) |
| Share-based compensation |  |  | 5,783 |  |  |  | 3,797 |  |
| Deferred income tax |  |  | 413 |  |  |  | (84 | ) |
| Other non-cash expenses |  |  | 765 |  |  |  | 725 |  |
| (Reversal of) inventory obsolescence |  |  | (478 | ) |  |  | 317 |  |
| Loss from written-off inventory |  |  | 233 |  |  |  | — |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | (12,486 | ) |  |  | (2,949 | ) |
| Inventory |  |  | (10,004 | ) |  |  | (3,551 | ) |
| Other current assets and non-current assets |  |  | 1,019 |  |  |  | (34 | ) |
| Trade accounts payable |  |  | (405 | ) |  |  | 3,852 |  |
| Income tax payable |  |  | 320 |  |  |  | 386 |  |
| Other current liabilities and non-current liabilities |  |  | 2,395 |  |  |  | 1,973 |  |
| Net cash provided by operating activities |  |  | 23,704 |  |  |  | 30,601 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of marketable securities |  |  | (53,258 | ) |  |  | (143,684 | ) |
| Proceeds from sales of marketable securities |  |  | 25,709 |  |  |  | 1,056 |  |
| Proceeds from maturities of marketable securities |  |  | 34,460 |  |  |  | 543 |  |
| Purchase of property, plant and equipment |  |  | (26,407 | ) |  |  | (5,372 | ) |
| Purchase of intangibles |  |  | (210 | ) |  |  | (22 | ) |
| Proceeds from disposal of property, plant and equipment |  |  | 58 |  |  |  | 46 |  |
| Net cash used in investing activities |  |  | (19,648 | ) |  |  | (147,433 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Payment of debt issuance costs |  |  | (359 | ) |  |  | (1,746 | ) |
| Proceeds from revolving loans |  |  | 18,000 |  |  |  | — |  |
| Repayment of long-term loans from bank |  |  | (3,000 | ) |  |  | (3,000 | ) |
| Proceeds from issuance of ordinary shares under employee share option plans |  |  | 2,025 |  |  |  | 415 |  |
| Withholding tax related to net share settlement of restricted share units |  |  | (1,711 | ) |  |  | (293 | ) |
| Net cash provided by (used in) financing activities |  |  | 14,955 |  |  |  | (4,624 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 19,011 |  |  |  | (121,456 | ) |
| Movement in cash and cash equivalents |  |  |  |  |  |  |  |  |
| Cash and cash equivalents at beginning of period |  |  | 112,978 |  |  |  | 233,477 |  |
| Increase (decrease) in cash and cash equivalents |  |  | 19,011 |  |  |  | (121,456 | ) |
| Effect of exchange rate on cash and cash equivalents |  |  | (630 | ) |  |  | (50 | ) |
| Cash and cash equivalents at end of period |  | $ | 131,359 |  |  | $ | 111,971 |  |
| Non-cash investing and financing activities |  |  |  |  |  |  |  |  |
| Construction and equipment-related payables |  | $ | 6,657 |  |  | $ | 10,919 |  |

[0001193125-16-446099:8k_2_02:45]
Fabrinet

[0001193125-16-446099:8k_2_02:46]
Reconciliation of GAAP measures

[0001193125-16-446099:8k_2_02:47]
(in thousands of U.S. dollars, except per share data)

[0001193125-16-446099:8k_2_02:48]
(unaudited)

[0001193125-16-446099:8k_2_02:49]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | December 25,2015 |  |  | December 25,2015 |  |  | December 26,2014 |  |  | December 26,2014 |  |  | December 25,2015 |  |  | December 25,2015 |  |  | December 26,2014 |  |  | December 26,2014 |  |
|  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |
| GAAP measures |  |  | 19,803 |  |  |  | 0.54 |  |  |  | 8,726 |  |  |  | 0.24 |  |  |  | 21,406 |  |  |  | 0.59 |  |  |  | 19,762 |  |  |  | 0.55 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 540 |  |  |  | 0.01 |  |  |  | 360 |  |  |  | 0.01 |  |  |  | 1,077 |  |  |  | 0.03 |  |  |  | 728 |  |  |  | 0.02 |  |
| Total related to gross profit |  |  | 540 |  |  |  | 0.01 |  |  |  | 360 |  |  |  | 0.01 |  |  |  | 1,077 |  |  |  | 0.03 |  |  |  | 728 |  |  |  | 0.02 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 2,570 |  |  |  | 0.07 |  |  |  | 1,570 |  |  |  | 0.04 |  |  |  | 4,706 |  |  |  | 0.13 |  |  |  | 3,069 |  |  |  | 0.09 |  |
| Executive separation cost |  |  | 552 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |  |  | 552 |  |  |  | 0.01 |  |  |  | — |  |  |  | — |  |
| Investigation cost |  |  | — |  |  |  | — |  |  |  | 2,500 |  |  |  | 0.07 |  |  |  | — |  |  |  | — |  |  |  | 4,100 |  |  |  | 0.11 |  |
| Total related to selling, general and administrative expenses |  |  | 3,122 |  |  |  | 0.08 |  |  |  | 4,070 |  |  |  | 0.11 |  |  |  | 5,258 |  |  |  | 0.14 |  |  |  | 7,169 |  |  |  | 0.20 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Expenses related to flooding |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 864 |  |  |  | 0.02 |  |  |  | — |  |  |  | — |  |
| Expenses related to reduction in workforce |  |  | — |  |  |  | — |  |  |  | 1,153 |  |  |  | 0.03 |  |  |  | — |  |  |  | — |  |  |  | 1,153 |  |  |  | 0.03 |  |
| Amortization of debt issuance costs |  |  | 187 |  |  |  | 0.01 |  |  |  | 228 |  |  |  | 0.01 |  |  |  | 358 |  |  |  | 0.01 |  |  |  | 228 |  |  |  | 0.01 |  |
| (Gain)/loss on foreign currency |  |  | (5,418 | ) |  |  | (0.15 | ) |  |  | — |  |  |  | — |  |  |  | 5,479 |  |  |  | 0.15 |  |  |  | — |  |  |  | — |  |
| Total related to other incomes and other expenses |  |  | (5,231 | ) |  |  | (0.14 | ) |  |  | 1,381 |  |  |  | 0.04 |  |  |  | 6,701 |  |  |  | 0.18 |  |  |  | 1,381 |  |  |  | 0.04 |  |
| Related to income tax benefit: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income tax benefit |  |  | — |  |  |  | — |  |  |  | (187 | ) |  |  | (0.01 | ) |  |  | — |  |  |  | — |  |  |  | (187 | ) |  |  | (0.01 | ) |
| Total related to income tax benefit |  |  | — |  |  |  | — |  |  |  | (187 | ) |  |  | (0.01 | ) |  |  | — |  |  |  | — |  |  |  | (187 | ) |  |  | (0.01 | ) |
| Total related to net income & EPS |  |  | (1,569 | ) |  |  | (0.04 | ) |  |  | 5,624 |  |  |  | 0.16 |  |  |  | 13,036 |  |  |  | 0.35 |  |  |  | 9,091 |  |  |  | 0.25 |  |
| Non-GAAP measures |  |  | 18,234 |  |  |  | 0.50 |  |  |  | 14,350 |  |  |  | 0.40 |  |  |  | 34,442 |  |  |  | 0.94 |  |  |  | 28,853 |  |  |  | 0.81 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 36,826 |  |  |  |  |  |  |  | 35,917 |  |  |  |  |  |  |  | 36,570 |  |  |  |  |  |  |  | 35,752 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 36,826 |  |  |  |  |  |  |  | 35,917 |  |  |  |  |  |  |  | 36,570 |  |  |  |  |  |  |  | 35,752 |  |
