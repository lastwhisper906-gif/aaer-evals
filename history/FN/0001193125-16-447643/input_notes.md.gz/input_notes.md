# FN notes — 0001193125-16-447643


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-16-447643:notes:1]
| 9. | Intangibles |

[0001193125-16-447643:notes:2]
[same as prior period, unchanged from 0001193125-15-364290:notes:2]

[0001193125-16-447643:notes:3]
| (amount in thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net |  |
| As of December 25, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |
| Software |  | $ | 3,567 |  |  | $ | (3,246 | ) |  | $ | 321 |  |
| Total intangibles |  | $ | 3,567 |  |  | $ | (3,246 | ) |  | $ | 321 |  |

[0001193125-16-447643:notes:4]
[same as prior period, unchanged from 0001193125-15-364290:notes:4]

[0001193125-16-447643:notes:5]
The Company recorded amortization expense relating to intangibles
 of $0.01 million and $0.02 million for the three months ended
 December 25, 2015 and December 26, 2014, respectively,
 and $0.02 million and $0.04 million for the six months ended
 December 25, 2015 and December 26, 2014,
 respectively.

[0001193125-16-447643:notes:6]
Based on the carrying amount of intangibles as of December 25,
 2015, and assuming no future impairment of the underlying assets,
 the estimated future amortization at the end of each fiscal year in
 June is as follows:

[0001193125-16-447643:notes:7]
| (amount in thousands) |  |  |  |
| 2016 |  | $ | 37 |  |
| 2017 |  |  | 70 |  |
| 2018 |  |  | 69 |  |
| 2019 |  |  | 69 |  |
| 2020 |  |  | 64 |  |
| Thereafter |  |  | 12 |  |
| Total |  | $ | 321 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001193125-16-447643:notes:8]
| 8. | Property, plant and equipment |

[0001193125-16-447643:notes:9]
On September 2, 2015, the Company entered into an agreement to
 purchase a parcel of land in Chonburi, Thailand, to support the
 expansion of the Company’s production capacity and
 capabilities in Thailand. Title to the land was transferred to the
 Company on December 22, 2015. The aggregate purchase price was
 approximately $12.4 million. The Company recorded the purchase of
 this land in property, plant and equipment on the unaudited
 condensed consolidated balance sheets as of December 25,
 2015.


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-16-447643:notes:10]
[same as prior period, unchanged from 0001193125-15-364290:notes:8]

[0001193125-16-447643:notes:11]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands) |  | December 25, 2015 |  |  | December 26, 2014 |  |  | December 25, 2015 |  |  | December 26, 2014 |  |
| North America |  | $ | 124,154 |  |  | $ | 93,658 |  |  | $ | 230,597 |  |  | $ | 184,701 |  |
| Asia-Pacific |  |  | 84,354 |  |  |  | 70,914 |  |  |  | 168,243 |  |  |  | 148,716 |  |
| Europe |  |  | 24,530 |  |  |  | 23,781 |  |  |  | 50,631 |  |  |  | 44,261 |  |
|  |  | $ | 233,038 |  |  | $ | 188,353 |  |  | $ | 449,471 |  |  | $ | 377,678 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-16-447643:notes:12]
[same as prior period, unchanged from 0001193125-15-364290:notes:10]

[0001193125-16-447643:notes:13]
| (amount in thousands) |  | As of December 25, 2015 |  |  | As of June 26, 2015 |  |
| Raw materials |  | $ | 49,306 |  |  | $ | 46,065 |  |
| Work in progress |  |  | 70,817 |  |  |  | 69,174 |  |
| Finished goods |  |  | 17,770 |  |  |  | 11,843 |  |
| Goods in transit |  |  | 5,448 |  |  |  | 6,488 |  |
|  |  |  | 143,341 |  |  |  | 133,570 |  |
| Less: Inventory obsolescence |  |  | (2,479 | ) |  |  | (2,957 | ) |
| Inventory, net |  | $ | 140,862 |  |  | $ | 130,613 |  |


## us-gaap:DebtDisclosureTextBlock

[0001193125-16-447643:notes:14]
| 10. | Borrowings |

[0001193125-16-447643:notes:15]
The Company’s total borrowing, including revolving and
 long-term borrowings, consisted of the following:

[0001193125-16-447643:notes:16]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Maturity |  | As of December 25, 2015 |  |  | As of June 26, 2015 |  |
| Short-term borrowing: |  |  |  |  |  |  |  |  |
| Revolving borrowing: |  |  |  |  |  |  |  |  |
| LIBOR + 1.75% per annum |  | Repayable in 1 to 6 months |  | January 2016 (2) |  | $ | 48,000 |  |  | $ | 30,000 |  |
| Current portion of long-term borrowing |  |  | 6,000 |  |  |  | 6,000 |  |
|  |  | $ | 54,000 |  |  | $ | 36,000 |  |
| Long-term borrowing: |  |  |  |  |  |  |  |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | March 2017 |  | $ | 7,500 |  |  | $ | 10,500 |  |
| Less: Current portion |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  | $ | 1,500 |  |  | $ | 4,500 |  |

[0001193125-16-447643:notes:17]
| (1) | LIBOR is London Interbank Offered Rate. |

[0001193125-16-447643:notes:18]
| (2) | In January 2016, the maturity date of these revolving borrowings were extended to mature in February 2016. |

[0001193125-16-447643:notes:19]
Under the long-term borrowing contract of a subsidiary, the loan is
 secured by certain property, plant and equipment. The carrying
 amount of assets secured and pledged as collateral to such loan as
 of December 25, 2015 and June 26, 2015 was $48.8 million
 and $50.0 million, respectively. This subsidiary is also required
 to comply with maximum ratios of debt to equity and minimum levels
 of debt service coverage ratios, and Fabrinet must maintain an
 effective shareholding ratio. The carrying amounts of bank
 borrowings approximate their fair value.

[0001193125-16-447643:notes:20]
As of December 25, 2015 and June 26, 2015, the Company
 was in compliance with its long-term bank borrowing agreement. In
 addition to financial ratios, certain of the Company’s credit
 facilities include customary events of default.

[0001193125-16-447643:notes:21]
The movements of long-term loans were as follows for the six months
 ended December 25, 2015 and December 26, 2014:

[0001193125-16-447643:notes:22]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 25, 2015 |  |  | December 26, 2014 |  |
| Opening book amount |  | $ | 10,500 |  |  | $ | 16,500 |  |
| Repayment during the period |  |  | (3,000 | ) |  |  | (3,000 | ) |
| Closing book amount |  | $ | 7,500 |  |  | $ | 13,500 |  |

[0001193125-16-447643:notes:23]
As of December 25, 2015, future maturities of long-term debt
 during each fiscal year were as follows:

[0001193125-16-447643:notes:24]
| (amount in thousands) |  |  |  |
| 2016 |  | $ | 3,000 |  |
| 2017 |  |  | 4,500 |  |
| Total |  | $ | 7,500 |  |

[0001193125-16-447643:notes:25]
Credit facilities:

[0001193125-16-447643:notes:26]
Fabrinet entered into a syndicated senior credit facility agreement
 (the “Facility Agreement”) with a consortium of banks
 on May 22, 2014. The Facility Agreement, led by Bank of
 America, provides for a $200.0 million credit line, comprised of a
 $150.0 million revolving loan facility and a $50.0 million delayed
 draw term loan facility. The revolving loan facility contains an
 accordion feature permitting Fabrinet to request an increase in the
 facility up to $100.0 million subject to customary terms and
 conditions and provided that no default or event of default exists
 at the time of request. The revolving loan facility terminates and
 all amounts outstanding are due and payable in full on May 22,
 2019. The principal amount of any drawn term loans must be repaid
 according to scheduled quarterly amortization payments, with final
 payment of all amounts outstanding, plus accrued interest, being
 due May 22, 2019.

[0001193125-16-447643:notes:27]
On February 26, 2015, the Company entered into the Second
 Amendment to the Facility Agreement. The amendment extended the
 availability period for draws on the term loan facility from
 May 21, 2015 to July 31, 2015. It also allowed the
 Company, upon the satisfaction of certain conditions, to designate
 from time to time one or more of its subsidiaries as borrowers
 under the Facility Agreement. On July 31, 2015, the Company
 entered into the Third Amendment to the Facility Agreement. The
 amendment extended the availability period for draws on the term
 loan facility from July 31, 2015 to July 31, 2016. As of
 December 25, 2015, the outstanding revolving borrowing under
 the Facility Agreement was $48.0 million, resulting in available
 credit facilities of $152.0 million. Borrowings under the revolving
 credit facility are classified as current liabilities in the
 unaudited condensed consolidated balance sheets as the Company has
 the periodic option to renew, or pay all or a portion of, the
 outstanding balance at the end of the maturity date, which is in
 the range of one to six months, without premium or penalty, upon
 notice to the administrative agent. During January 2016, the
 Company sent notices to the bank to renew the maturity date of its
 revolving borrowings. The bank approved the notices and extended
 the maturity to February 2016.

[0001193125-16-447643:notes:28]
Loans under the Facility Agreement bear interest, at
 Fabrinet’s option, at a rate per annum equal to a LIBOR rate
 plus a spread of 1.75% to 2.50%, or a base rate plus a spread of
 0.75% to 1.50%, determined in accordance with the Facility
 Agreement in each case with such spread determined based on
 Fabrinet’s consolidated total leverage ratio for the
 preceding four fiscal quarter period. Interest is due and payable
 quarterly in arrears for loans bearing interest at the base rate
 and at the end of an interest period (or at each three-month
 interval in the case of loans with interest periods greater than
 three months) in the case of loans bearing interest at the LIBOR
 rate.

[0001193125-16-447643:notes:29]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet is required to
 maintain at least $40.0 million of cash, cash equivalents, and
 marketable securities at financial institutions located in the
 United States. Further, Fabrinet is required to maintain any of its
 deposits accounts or securities accounts with balances in excess of
 $10.0 million in a jurisdiction where a control agreement, or the
 equivalent under the local law, can be effected. The Facility
 Agreement contains customary affirmative and negative covenants.
 Negative covenants include, among other things, limitations on
 liens, indebtedness, investments, mergers, sales of assets, changes
 in the nature of the business, dividends and distributions,
 affiliate transactions and capital expenditures. The Facility
 Agreement contains financial covenants requiring Fabrinet to
 maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage
 ratio of not more than 2.50:1.00; and (iv) a minimum quick
 ratio of not less than 1.10:1.00. Each of these financial covenants
 is calculated on a consolidated basis for the consecutive four
 fiscal quarter period then ended. As of December 25, 2015, the
 Company was in compliance with all covenants under the Facility
 Agreement.

[0001193125-16-447643:notes:30]
The Facility Agreement also contains customary events of default
 including, among other things, payment defaults, breaches of
 covenants or representations and warranties, cross-defaults with
 certain other indebtedness, bankruptcy and insolvency events and
 change in control of Fabrinet, subject to grace periods in certain
 instances. Upon an event of default, the lenders may terminate
 their commitments, declare all or a portion of the outstanding
 obligations payable by Fabrinet to be immediately due and payable
 and exercise other rights and remedies provided for under the
 Facility Agreement.

[0001193125-16-447643:notes:31]
Fabrinet intends to use the proceeds of the credit line to finance
 its future manufacturing buildings in the United States and
 Thailand, and for general corporate purposes including mergers and
 acquisitions of complementary manufacturing businesses or
 technology, although Fabrinet has no current commitments with
 respect to any such acquisitions.

[0001193125-16-447643:notes:32]
Undrawn available credit facilities classified by available period
 of future borrowing as of December 25, 2015 and June 26,
 2015 were as follows:

[0001193125-16-447643:notes:33]
| (amount in thousands) |  | December 25, 2015 |  |  | June 26, 2015 |  |
| Short-term |  | $ | 1,386 |  |  | $ | 1,480 |  |
| Long-term |  | $ | 152,000 |  |  | $ | 170,000 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-16-447643:notes:34]
| 12. | Share-based compensation |

[0001193125-16-447643:notes:35]
[same as prior period, unchanged from 0001193125-15-364290:notes:33]

[0001193125-16-447643:notes:36]
[same as prior period, unchanged from 0001193125-15-364290:notes:34]

[0001193125-16-447643:notes:37]
The effect of recording share-based compensation expense for the
 three and six months ended December 25, 2015 and
 December 26, 2014 was as follows:

[0001193125-16-447643:notes:38]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands) |  | December 25, 2015 |  |  | December 26, 2014 |  |  | December 25, 2015 |  |  | December 26, 2014 |  |
| Share-based compensation expense by type of award: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share options |  | $ | 2 |  |  | $ | 71 |  |  | $ | 18 |  |  | $ | 191 |  |
| Restricted share units |  |  | 3,108 |  |  |  | 1,859 |  |  |  | 5,765 |  |  |  | 3,606 |  |
| Total share-based compensation expense |  |  | 3,110 |  |  |  | 1,930 |  |  |  | 5,783 |  |  |  | 3,797 |  |
| Tax effect on share-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net effect on share-based compensation expense |  | $ | 3,110 |  |  | $ | 1,930 |  |  | $ | 5,783 |  |  | $ | 3,797 |  |

[0001193125-16-447643:notes:39]
Share-based compensation expense was recorded in the unaudited
 condensed consolidated statements of operations and comprehensive
 income as follows:

[0001193125-16-447643:notes:40]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands) |  | December 25, 2015 |  |  | December 26, 2014 |  |  | December 25, 2015 |  |  | December 26, 2014 |  |
| Cost of revenue |  | $ | 540 |  |  | $ | 360 |  |  | $ | 1,077 |  |  | $ | 728 |  |
| Selling, general and administrative expense |  |  | 2,570 |  |  |  | 1,570 |  |  |  | 4,706 |  |  |  | 3,069 |  |
| Total share-based compensation expense |  | $ | 3,110 |  |  | $ | 1,930 |  |  | $ | 5,783 |  |  | $ | 3,797 |  |

[0001193125-16-447643:notes:41]
The Company did not capitalize any share-based compensation expense
 as part of any asset costs during the three and six months ended
 December 25, 2015 and December 26, 2014.

[0001193125-16-447643:notes:42]
[same as prior period, unchanged from 0001193125-15-364290:notes:40]

[0001193125-16-447643:notes:43]
Share options have been granted to directors and employees. As of
 December 25, 2015, there were 310 share options outstanding
 under Fabrinet’s Amended and Restated 1999 Share Option Plan
 (the “1999 Plan”). Additional option grants may not be
 made under the 1999 Plan.

[0001193125-16-447643:notes:44]
As of December 25, 2015, there were an aggregate of 660,717
 share options outstanding, 1,276,859 restricted share units
 outstanding, and 2,499,260 ordinary shares available for future
 grant under Fabrinet’s 2010 Performance Incentive Plan (the
 “2010 Plan”). The 1999 Plan and 2010 Plan are
 collectively referred to as the “Share Option
 Plans”.

[0001193125-16-447643:notes:45]
[same as prior period, unchanged from 0001193125-15-364290:notes:43]

[0001193125-16-447643:notes:46]
[same as prior period, unchanged from 0001193125-15-364290:notes:44]

[0001193125-16-447643:notes:47]
[same as prior period, unchanged from 0001193125-15-364290:notes:45]

[0001193125-16-447643:notes:48]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price Per Share |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 26, 2015 |  |  | 792,019 |  |  |  | 758,451 |  |  | $ | 16.33 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (130,779 | ) |  |  |  |  |  | $ | 15.48 |  |  |  |  |  |
| Forfeited |  |  | (213 | ) |  |  |  |  |  | $ | 14.43 |  |  |  |  |  |
| Expired |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Balance as of December 25, 2015 |  |  | 661,027 |  |  |  | 660,035 |  |  | $ | 16.50 |  |  |  |  |  |

[0001193125-16-447643:notes:49]
|  |  | Number of Shares |  |  | Number of Exercisable Options |  |  | Weighted- Average Exercise Price Per Share |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 27, 2014 |  |  | 865,890 |  |  |  | 666,305 |  |  | $ | 16.27 |  |  |  |  |  |
| Granted |  |  | — |  |  |  |  |  |  |  | — |  |  |  | — |  |
| Exercised |  |  | (26,677 | ) |  |  |  |  |  | $ | 15.58 |  |  |  |  |  |
| Forfeited |  |  | (3,521 | ) |  |  |  |  |  | $ | 16.93 |  |  |  |  |  |
| Expired |  |  | (3,804 | ) |  |  |  |  |  | $ | 19.47 |  |  |  |  |  |
| Balance as of December 26, 2014 |  |  | 831,888 |  |  |  | 743,800 |  |  | $ | 16.27 |  |  |  |  |  |

[0001193125-16-447643:notes:50]
The following summarizes information for share options outstanding
 as of December 25, 2015 under the Share Option Plans:

[0001193125-16-447643:notes:51]
|  |  | Number of Shares Underlying Options |  |  | Exercise Price Per Share |  |  | Weighted- Average Remaining Contractual Life (years) |  |  | Aggregate Intrinsic Value (amount in thousands) |  |
|  |  |  | 310 |  |  | $ | 5.75 |  |  |  | 0.90 |  |  |  |  |  |
|  |  |  | 345,338 |  |  | $ | 16.83 |  |  |  | 1.80 |  |  |  |  |  |
|  |  |  | 30,000 |  |  | $ | 15.05 |  |  |  | 1.86 |  |  |  |  |  |
|  |  |  | 23,844 |  |  | $ | 25.50 |  |  |  | 2.05 |  |  |  |  |  |
|  |  |  | 7,400 |  |  | $ | 26.16 |  |  |  | 2.11 |  |  |  |  |  |
|  |  |  | 8,300 |  |  | $ | 23.62 |  |  |  | 2.36 |  |  |  |  |  |
|  |  |  | 25,859 |  |  | $ | 15.16 |  |  |  | 2.65 |  |  |  |  |  |
|  |  |  | 191,121 |  |  | $ | 14.12 |  |  |  | 2.88 |  |  |  |  |  |
|  |  |  | 22,760 |  |  | $ | 19.36 |  |  |  | 3.13 |  |  |  |  |  |
|  |  |  | 5,550 |  |  | $ | 18.60 |  |  |  | 3.18 |  |  |  |  |  |
|  |  |  | 545 |  |  | $ | 12.83 |  |  |  | 3.37 |  |  |  |  |  |
| Options outstanding |  |  | 661,027 |  |  |  |  |  |  |  | 2.23 |  |  | $ | 5,043 |  |
| Options exercisable |  |  | 660,035 |  |  |  |  |  |  |  | 2.22 |  |  | $ | 5,037 |  |

[0001193125-16-447643:notes:52]
As of December 25, 2015, there was $60 of unrecognized
 compensation expense related to share options under the Share
 Option Plans that is expected to be recognized over a
 weighted-average period of 0.18 years.

[0001193125-16-447643:notes:53]
[same as prior period, unchanged from 0001193125-15-364290:notes:50]

[0001193125-16-447643:notes:54]
[same as prior period, unchanged from 0001193125-15-364290:notes:51]

[0001193125-16-447643:notes:55]
[same as prior period, unchanged from 0001193125-15-364290:notes:52]

[0001193125-16-447643:notes:56]
[same as prior period, unchanged from 0001193125-15-364290:notes:53]

[0001193125-16-447643:notes:57]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 26, 2015 |  |  | 1,140,927 |  |  | $ | 16.03 |  |
| Granted |  |  | 539,772 |  |  | $ | 19.57 |  |
| Issued |  |  | (388,425 | )(1) |  | $ | 15.27 |  |
| Forfeited |  |  | (15,415 | ) |  | $ | 18.39 |  |
| Balance as of December 25, 2015 |  |  | 1,276,859 |  |  | $ | 17.27 |  |

[0001193125-16-447643:notes:58]
|  |  | Number of Shares |  |  | Weighted- Average Grant Date Fair Value Per Share |  |
| Balance as of June 27, 2014 |  |  | 762,295 |  |  | $ | 14.23 |  |
| Granted |  |  | 557,798 |  |  | $ | 17.62 |  |
| Issued |  |  | (209,119 | )(2) |  | $ | 17.72 |  |
| Forfeited |  |  | (13,370 | ) |  | $ | 15.68 |  |
| Balance as of December 26, 2014 |  |  | 1,097,604 |  |  | $ | 16.03 |  |

[0001193125-16-447643:notes:59]
| (1) | Includes 849 shares vested on December 1, 2015, but not settled as of December 25, 2015. |

[0001193125-16-447643:notes:60]
| (2) | Includes 283 shares vested on December 23, 2014, but not settled as of December 26, 2014. |

[0001193125-16-447643:notes:61]
As of December 25, 2015, there was $11.4 million of
 unrecognized share-based compensation expense related to restricted
 share units under the 2010 Plan that is expected to be recorded
 over a weighted-average period of 2.92 years.

[0001193125-16-447643:notes:62]
For the six months ended December 25, 2015 and
 December 26, 2014, the Company withheld an aggregate of 84,269
 shares and 16,399 shares, respectively, upon the vesting of
 restricted share units, based upon the closing share price on the
 vesting date to settle the employees’ minimum statutory
 obligation for the applicable income and other employment taxes.
 For the six months ended December 25, 2015 and
 December 26, 2014, the Company then remitted cash of $1.7
 million and $0.3 million, respectively, to the appropriate taxing
 authorities, and presented it in a financing activity within the
 unaudited condensed consolidated statements of cash flows. The
 payment had the effect on shares issued by the Company as it
 reduced the number of shares that would have been issued on the
 vesting date and was recorded as a reduction of additional paid-in
 capital.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-16-447643:notes:63]
| 16. | Business segments and geographic information |

[0001193125-16-447643:notes:64]
Operating segments are defined as components of an enterprise for
 which separate financial information is available that is evaluated
 regularly by the chief operating decision maker in deciding how to
 allocate resources and in assessing performance. The
 Company’s chief operating decision maker is Fabrinet’s
 chief executive officer. As of December 25, 2015 and
 December 26, 2014, the Company operated and internally managed
 a single operating segment. Accordingly, the Company does not
 accumulate discrete information with respect to separate product
 lines and does not have separate reportable segments.

[0001193125-16-447643:notes:65]
[same as prior period, unchanged from 0001193125-15-364290:notes:61]

[0001193125-16-447643:notes:66]
As of December 25, 2015 and December 26, 2014, the
 Company had approximately $33.6 million and $0.3 million of
 long-lived assets based in North America, with the substantial
 remainder of assets based in Asia-Pacific.

[0001193125-16-447643:notes:67]
[same as prior period, unchanged from 0001193125-15-364290:notes:63]

[0001193125-16-447643:notes:68]
The Company had three and two customers that each contributed to
 10% or more of its total account receivable as of December 25,
 2015 and June 26, 2015, respectively.


## us-gaap:AvailableForSaleSecuritiesTextBlock

[0001193125-16-447643:notes:69]
The following table summarizes the cost and estimated fair value of
 marketable securities classified as available-for-sale securities
 based on stated effective maturities as of December 25,
 2015:

[0001193125-16-447643:notes:70]
| (amount in thousands) |  | Carrying Cost |  |  | Fair Value |  |
| Due within one year |  | $ | 16,075 |  |  | $ | 16,068 |  |
| Due between one to three years |  |  | 119,343 |  |  |  | 119,131 |  |
| Total |  | $ | 135,418 |  |  | $ | 135,199 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001193125-16-447643:notes:71]
[same as prior period, unchanged from 0001193125-15-364290:notes:67]

[0001193125-16-447643:notes:72]
The accompanying unaudited condensed consolidated financial
 statements for Fabrinet as of December 25, 2015 and for the
 three and six months ended December 25, 2015 and
 December 26, 2014 includes only normal recurring adjustments,
 necessary for a fair statement of the financial statements set
 forth herein, in accordance with accounting principles generally
 accepted in the United States of America (“U.S. GAAP”)
 for interim financial information and rules and regulations of the
 Securities and Exchange Commission (“SEC”).
 Accordingly, such information does not include all of the
 information and footnotes required by U.S. GAAP for annual
 financial statements. For further information, please refer to the
 consolidated financial statements and footnotes thereto included in
 Fabrinet’s Annual Report on Form 10-K for the year ended
 June 26, 2015.

[0001193125-16-447643:notes:73]
The balance sheet as of June 26, 2015 has been derived from
 the audited financial statements at that date but does not include
 all of the information and footnotes required by U.S. GAAP for
 complete financial statements. The results for the three and six
 months ended December 25, 2015 and December 26, 2014 may
 not be indicative of results for the year ending June 24, 2016
 or any future periods.


## us-gaap:FairValueDisclosuresTextBlock

[0001193125-16-447643:notes:74]
[same as prior period, unchanged from 0001193125-15-364290:notes:70]

[0001193125-16-447643:notes:75]
[same as prior period, unchanged from 0001193125-15-364290:notes:71]

[0001193125-16-447643:notes:76]
[same as prior period, unchanged from 0001193125-15-364290:notes:72]

[0001193125-16-447643:notes:77]
[same as prior period, unchanged from 0001193125-15-364290:notes:73]

[0001193125-16-447643:notes:78]
[same as prior period, unchanged from 0001193125-15-364290:notes:74]

[0001193125-16-447643:notes:79]
[same as prior period, unchanged from 0001193125-15-364290:notes:75]

[0001193125-16-447643:notes:80]
[same as prior period, unchanged from 0001193125-15-364290:notes:76]

[0001193125-16-447643:notes:81]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of December 25, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 11,372 |  |  | $ | — |  |  | $ | 11,372 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 113,794 |  |  |  | — |  |  |  | 113,794 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 20,674 |  |  |  | — |  |  |  | 20,674 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 731 |  |  |  | — |  |  |  | 731 |  |
| Total |  | $ | — |  |  | $ | 146,571 |  |  | $ | — |  |  | $ | 146,571 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 6,209 | (1) |  | $ | — |  |  | $ | 6,209 |  |
| Total |  | $ | — |  |  | $ | 6,209 |  |  | $ | — |  |  | $ | 6,209 |  |

[0001193125-16-447643:notes:82]
|  |  | Fair Value Measurements at Reporting Date Using |  |
| (amount in thousands) |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| As of June 26, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents |  | $ | — |  |  | $ | 7,430 |  |  | $ | — |  |  | $ | 7,430 |  |
| Corporate bonds and commercial papers |  |  | — |  |  |  | 120,101 |  |  |  | — |  |  |  | 120,101 |  |
| U.S. agency and U.S. treasury securities |  |  | — |  |  |  | 21,027 |  |  |  | — |  |  |  | 21,027 |  |
| Sovereign and municipal securities |  |  | — |  |  |  | 1,738 |  |  |  | — |  |  |  | 1,738 |  |
| Derivative assets |  |  | — |  |  |  | 4 | (2) |  |  | — |  |  |  | 4 |  |
| Total |  | $ | — |  |  | $ | 150,300 |  |  | $ | — |  |  | $ | 150,300 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities |  | $ | — |  |  | $ | 371 | (3) |  | $ | — |  |  | $ | 371 |  |
| Total |  | $ | — |  |  | $ | 371 |  |  | $ | — |  |  | $ | 371 |  |

[0001193125-16-447643:notes:83]
| (1) | Foreign currency forward contracts with notional amount of $181.5 million and Canadian Dollars 0.4 million. |

[0001193125-16-447643:notes:84]
[same as prior period, unchanged from 0001193125-15-364290:notes:79]

[0001193125-16-447643:notes:85]
[same as prior period, unchanged from 0001193125-15-364290:notes:80]

[0001193125-16-447643:notes:86]
[same as prior period, unchanged from 0001193125-15-364290:notes:81]

[0001193125-16-447643:notes:87]
[same as prior period, unchanged from 0001193125-15-364290:notes:82]

[0001193125-16-447643:notes:88]
The derivative assets and liabilities are classified in other
 current assets and accrued expenses, respectively, on the unaudited
 condensed consolidated balance sheets. As of December 25, 2015
 and June 26, 2015, the forward contracts and option contracts
 outstanding had a maturity date in one to eighteen months duration.
 The Company has not designated the foreign currency contracts as
 hedging instruments under the accounting standard for derivatives
 and hedging.

[0001193125-16-447643:notes:89]
The effects of derivative instruments which are not designated as
 hedging instruments on the Company’s unaudited condensed
 consolidated statements of operations and comprehensive income were
 a gain from foreign currency forward contracts of $6.2 million for
 the three months ended December 25, 2015, and a loss from
 foreign currency put option contracts of $0.1 million and a gain
 from foreign currency put option contracts of $0.02 million for the
 three months ended December 26, 2014.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock

[0001193125-16-447643:notes:90]
[same as prior period, unchanged from 0001193125-15-364290:notes:85]

[0001193125-16-447643:notes:91]
[same as prior period, unchanged from 0001193125-15-364290:notes:86]

[0001193125-16-447643:notes:92]
[same as prior period, unchanged from 0001193125-15-364290:notes:87]

[0001193125-16-447643:notes:93]
[same as prior period, unchanged from 0001193125-15-364290:notes:88]

[0001193125-16-447643:notes:94]
The Company utilizes a 52-53 week fiscal year ending on the Friday
 in June closest to June 30. The three months ended
 December 25, 2015 and December 26, 2014 each consisted of
 13 weeks. The six months ended December 25, 2015 and
 December 26, 2014 each consisted of 26 weeks. Fiscal year 2016
 will be comprised of 52 weeks and will end on June 24,
 2016.

[0001193125-16-447643:notes:95]
[same as prior period, unchanged from 0001193125-15-364290:notes:90]

[0001193125-16-447643:notes:96]
[same as prior period, unchanged from 0001193125-15-364290:notes:91]

[0001193125-16-447643:notes:97]
[same as prior period, unchanged from 0001193125-15-364290:notes:92]

[0001193125-16-447643:notes:98]
[same as prior period, unchanged from 0001193125-15-364290:notes:93]

[0001193125-16-447643:notes:99]
[same as prior period, unchanged from 0001193125-15-364290:notes:94]

[0001193125-16-447643:notes:100]
In January 2016, the Financial Accounting Standards Board
 (“FASB”) issued Accounting Standards Update
 (“ASU”) 2016-01, “Financial
 Instruments – Overall (Subtopic 825-10): Recognition and
 Measurement of Financial Assets and Financial Liabilities”.
 This new guidance makes targeted improvements to existing U.S. GAAP
 by requiring certain equity investments to be measured at fair
 value, requiring use of the exit price notion when measuring the
 fair value of financial instruments for disclosure purposes and
 requiring separate presentation of financial assets and financial
 liabilities by measurement category and form of financial asset
 (that is, securities or loans and receivables) on the balance sheet
 or the accompanying notes to the financial statements. The ASU on
 recognition and measurement will take effect for public companies
 for fiscal years beginning after December 15, 2017, including
 interim periods within those fiscal years. The Company is
 currently evaluating the impact of adoption of this update on its
 consolidated financial statements.

[0001193125-16-447643:notes:101]
In November 2015, the FASB issued ASU 2015-17, “Balance Sheet
 Classification of Deferred Taxes”, which will require
 entities to present deferred tax assets (“DTAs”) and
 deferred tax liabilities (“DTLs”) as non-current in a
 classified balance sheet. The ASU simplifies the current guidance,
 which requires entities to separately present DTAs and DTLs as
 current and non-current in a classified balance sheet. For public
 business entities, the amendments in this ASU are effective for
 financial statements issued for annual periods beginning after
 December 15, 2016, and interim periods within those annual
 periods. The Company is currently evaluating the impact of adoption
 of this update on its consolidated financial statements.

[0001193125-16-447643:notes:102]
In August 2015, the FASB issued ASU 2015-15, “Interest
 – Imputation of Interest (Subtopic 835-30): Presentation and
 Subsequent Measurement of Debt Issuance Costs Associated with
 Line-of-Credit Arrangements”. This ASU amended the
 presentation or subsequent measurement of debt issuance costs
 related to the line-of-credit arrangement. The Company is currently
 evaluating the impact of adoption of this update on its
 consolidated financial statements.

[0001193125-16-447643:notes:103]
In August 2015, the FASB issued ASU 2015-14, “Revenue from
 Contracts with Customers (Topic 666): Deferral of the Effective
 Date”. This amendment deferred the effective date of ASU
 2014-09 for all entities by one year. The Company is currently
 evaluating the impact of adoption of this update on its
 consolidated financial statements.

[0001193125-16-447643:notes:104]
In July 2015, the FASB issued ASU 2015-11, “Inventory (Topic
 330): Simplifying the Measurement of Inventory”. The update
 provides the guidance that an entity, that measured inventory by
 using first-in, first-out or average cost, should measure inventory
 at the lower of cost and net realizable value. Net realizable value
 is the estimated selling prices in the ordinary course of business,
 less reasonably predictable costs of completion, disposal, and
 transportation. Subsequent measurement is unchanged for inventory
 measured using last-in, first-out or the retail inventory method.
 The update is effective for fiscal years beginning after
 December 15, 2016, including interim periods within these
 fiscal years. This update should be applied prospectively with
 earlier application permitted as of the beginning of an interim or
 annual reporting date. The Company is currently evaluating the
 impact of adoption of this update on its consolidated financial
 statements.

[0001193125-16-447643:notes:105]
In April 2015, the FASB issued ASU 2015-03,
 “Interest – Imputation of Interest (Subtopic
 835-30): Simplifying the Presentation of Debt Issuance
 Costs”. The update requires debt issuance costs related to a
 recognized debt liability be presented in the balance sheet as a
 direct deduction from the carrying amount of the related debt
 liability instead of being presented as an asset. Debt disclosures
 will include the face amount of the debt liability and the
 effective interest rate. The update requires retrospective
 application and represents a change in accounting principle. The
 update is effective for fiscal years beginning after
 December 15, 2015. Early adoption is permitted for financial
 statements that have not been previously issued. The Company is
 currently evaluating the impact of adoption of this update on its
 consolidated financial statements.

[0001193125-16-447643:notes:106]
In February 2015, the FASB issued ASU 2015-02, “Consolidation
 (Topic 810): Amendments to the Consolidation Analysis”. ASU
 No. 2015-02 amended the process that a reporting entity must
 perform to determine whether it should consolidate certain types of
 legal entities. ASU No. 2015-02 is effective for fiscal years,
 and for interim periods within those fiscal years beginning after
 December 15, 2015. Early adoption is permitted, including
 adoption in an interim period. The Company is currently evaluating
 the impact of adoption of this update on its consolidated financial
 statements.

[0001193125-16-447643:notes:107]
In January 2015, the FASB issued ASU No. 2015-01,
 “Income Statement – Extraordinary and Unusual Items
 (Subtopic 225-20): Simplifying Income Statement Presentation by
 Eliminating the Concept of Extraordinary Items”. The
 objective of this amendment is to reduce the complexity in
 accounting standards by eliminating the concept of extraordinary
 items from U.S. GAAP. Presently, an event or transaction is
 presumed to be an ordinary and usual activity of the reporting
 entity unless evidence clearly supports its classification as an
 extraordinary item. The following criteria must both be met for
 extraordinary classification: (a) the underlying event or
 transaction should possess a high degree of abnormality and be of a
 type clearly unrelated to, or only incidentally related to, the
 ordinary and typical activities of the entity; and (b) the
 underlying event or transaction should not reasonably be expected
 to recur in the foreseeable future. This amendment is effective for
 fiscal years and interim periods beginning after December 15,
 2015. Early adoption is permitted provided that the guidance is
 applied from the beginning of the fiscal year of adoption. The
 Company does not expect that the adoption of this update will have
 an effect on its consolidated financial statements.

[0001193125-16-447643:notes:108]
In August 2014, the FASB issued ASU No. 2014-15,
 “Presentation of Financial Statements – Going Concern
 (Subtopic 205-40): Disclosure of Uncertainties about an
 Entity’s Ability to Continue as a Going Concern”. The
 amendments require management to evaluate, for each annual and
 interim reporting period, an entity’s ability to continue as
 a going concern when relevant conditions and events, considered in
 the aggregate, indicate that it is probable that the entity will be
 unable to meet its obligations that become due within one year
 after the date that the financial statements are issued (or
 available to be issued). This ASU is effective for annual periods
 and interim reporting periods beginning after December 15,
 2016. The Company does not expect that the adoption of this update
 will have an effect on its consolidated financial statements.

[0001193125-16-447643:notes:109]
In June 2014, the FASB issued ASU No. 2014-12,
 “Compensation – Stock Compensation (Topic 718):
 Accounting for Share-Based Payments When the Terms of an Award
 Provide That a Performance Target Could Be Achieved After the
 Requisite Service Period”. This ASU requires that a
 performance target that affects vesting, and that could be achieved
 after the requisite service period, be treated as a performance
 condition. As such, the performance target should not be reflected
 in estimating the grant date fair value of the award. This update
 further clarifies that compensation cost should be recognized in
 the period in which it becomes probable that the performance target
 will be achieved and should represent the compensation cost
 attributable to the period(s) for which the requisite service has
 already been rendered. This update is required to be adopted by all
 public companies for annual periods and interim reporting periods
 beginning after December 15, 2015. Early adoption of this ASU
 is permitted. The Company does not expect that the adoption of this
 update will have an effect on its consolidated financial
 statements.

[0001193125-16-447643:notes:110]
In May 2014, the FASB issued ASU No. 2014-09, “Revenue
 from Contracts with Customers (Topic 606), issued as a new Topic,
 Accounting Standards Codification”. The core principle of
 this amendment is that an entity should recognize revenue to depict
 the transfer of promised goods or services to customers in an
 amount that reflects the consideration to which the entity expects
 to be entitled in exchange for those goods or services. This ASU is
 effective for annual reporting periods beginning after
 December 15, 2016, including interim periods within that
 reporting period, with earlier adoption not being permitted. This
 ASU can be adopted either retrospectively to each prior reporting
 period presented or as a cumulative-effect adjustment as of the
 date of adoption. The Company is currently evaluating the impact of
 adoption of this update on its consolidated financial
 statements.


## us-gaap:ScheduleOfOtherNonoperatingIncomeExpenseTableTextBlock

[0001193125-16-447643:notes:111]
The following is a summary of all known losses incurred from this
 event and recognized in the unaudited condensed consolidated
 statements of operations and comprehensive income for the six
 months ended December 25, 2015.

[0001193125-16-447643:notes:112]
[same as prior period, unchanged from 0001193125-15-364290:notes:105]


## us-gaap:EarningsPerShareTextBlock

[0001193125-16-447643:notes:113]
[same as prior period, unchanged from 0001193125-15-364290:notes:106]

[0001193125-16-447643:notes:114]
[same as prior period, unchanged from 0001193125-15-364290:notes:107]

[0001193125-16-447643:notes:115]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (amount in thousands except per share amounts) |  | December 25, 2015 |  |  | December 26, 2014 |  |  | December 25, 2015 |  |  | December 26, 2014 |  |
| Net income attributable to shareholders |  | $ | 19,803 |  |  | $ | 8,726 |  |  | $ | 21,406 |  |  | $ | 19,762 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  | 35,812 |  |  |  | 35,349 |  |  |  | 35,695 |  |  |  | 35,289 |  |
| Incremental shares arising from the assumed exercise of share options and vesting of restricted share units (thousands of shares) |  |  | 1,014 |  |  |  | 568 |  |  |  | 875 |  |  |  | 463 |  |
| Weighted-average number of ordinary shares for diluted earnings per ordinary share (thousands of shares) |  |  | 36,826 |  |  |  | 35,917 |  |  |  | 36,570 |  |  |  | 35,752 |  |
| Basic earnings per ordinary share |  | $ | 0.55 |  |  | $ | 0.25 |  |  | $ | 0.60 |  |  | $ | 0.56 |  |
| Diluted earnings per ordinary share |  | $ | 0.54 |  |  | $ | 0.24 |  |  | $ | 0.59 |  |  | $ | 0.55 |  |
| Outstanding share options excluded in the computation of diluted earnings per ordinary share (1) |  |  | 31,244 |  |  |  | 71,580 |  |  |  | 31,244 |  |  |  | 71,580 |  |

[0001193125-16-447643:notes:116]
| (1) | These share options were not included in the computation of diluted earnings per ordinary share because the exercise price of the options was greater than the average market price of the underlying shares. |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001193125-16-447643:notes:117]
| 14. | Accumulated other comprehensive loss |

[0001193125-16-447643:notes:118]
The changes in accumulated other comprehensive loss, net of tax,
 for the six months ended December 25, 2015 were as
 follows:

[0001193125-16-447643:notes:119]
| (amount in thousands) |  | Unrealized Holding Losses on Marketable Securities |  |  | Other |  |  | Total |  |
| Balance as of June 26, 2015 |  | $ | (44 | ) |  | $ | — |  |  | $ | (44 | ) |
| Other comprehensive loss before reclassification adjustment |  |  | (218 | ) |  |  | (48 | ) |  |  | (266 | ) |
| Amounts reclassified out of accumulated other comprehensive loss |  |  | 43 |  |  |  | — |  |  |  | 43 |  |
| Tax effects |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive loss |  | $ | (175 | ) |  | $ | (48 | ) |  | $ | (223 | ) |
| Balance as of December 25, 2015 |  | $ | (219 | ) |  | $ | (48 | ) |  | $ | (267 | ) |


## us-gaap:CashCashEquivalentsAndMarketableSecuritiesTextBlock

[0001193125-16-447643:notes:120]
[same as prior period, unchanged from 0001193125-15-364290:notes:113]

[0001193125-16-447643:notes:121]
[same as prior period, unchanged from 0001193125-15-364290:notes:114]

[0001193125-16-447643:notes:122]
|  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized Loss |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of December 25, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | — |  |  | $ | — |  |  | $ | 119,987 |  |  | $ | — |  |
| Cash equivalents |  |  | 11,372 |  |  |  | — |  |  |  | 11,372 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 113,942 |  |  |  | (148 | ) |  |  | — |  |  |  | 113,794 |  |
| U.S. agency and U.S. treasury securities |  |  | 20,745 |  |  |  | (71 | ) |  |  | — |  |  |  | 20,674 |  |
| Sovereign and municipal securities |  |  | 731 |  |  |  | — |  |  |  | — |  |  |  | 731 |  |
| Total |  | $ | 146,790 |  |  | $ | (219 | ) |  | $ | 131,359 |  |  | $ | 135,199 |  |

[0001193125-16-447643:notes:123]
|  |  |  |  |  |  |  |  | Fair Value |  |
| (amount in thousands) |  | Carrying Cost |  |  | Unrealized (Loss)/ Gain |  |  | Cash and Cash Equivalents |  |  | Marketable Securities |  |
| As of June 26, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash |  | $ | — |  |  | $ | — |  |  | $ | 105,548 |  |  | $ | — |  |
| Cash equivalents |  |  | 7,430 |  |  |  | — |  |  |  | 7,430 |  |  |  | — |  |
| Corporate bonds and commercial papers |  |  | 120,144 |  |  |  | (43 | ) |  |  | — |  |  |  | 120,101 |  |
| U.S. agency and U.S. treasury securities |  |  | 21,029 |  |  |  | (2 | ) |  |  | — |  |  |  | 21,027 |  |
| Sovereign and municipal securities |  |  | 1,737 |  |  |  | 1 |  |  |  | — |  |  |  | 1,738 |  |
| Total |  | $ | 150,340 |  |  | $ | (44 | ) |  | $ | 112,978 |  |  | $ | 142,866 |  |

[0001193125-16-447643:notes:124]
[same as prior period, unchanged from 0001193125-15-364290:notes:116]

[0001193125-16-447643:notes:125]
During the three and six months ended December 25, 2015, the
 net realized loss recognized by the Company was $0.03 million and
 $0.1 million, respectively.

[0001193125-16-447643:notes:126]
As of December 25, 2015, the Company considered the declines
 in market value of its marketable securities investment portfolio
 to be temporary in nature and did not consider any of its
 securities other-than-temporarily impaired. The Company typically
 invests in highly-rated securities, and its investment policy
 generally limits the amount of credit exposure to any one issuer.
 The policy requires investments generally to be investment grade,
 with the primary objective of minimizing the potential risk of
 principal loss. Fair values were determined for each individual
 security in the investment portfolio. When evaluating an investment
 for other-than-temporary impairment, the Company reviews factors
 such as the length of time and extent to which fair value has been
 below its cost basis, the financial condition of the issuer and any
 changes thereto, changes in market interest rates, and the
 Company’s intent to sell, or whether it is more likely than
 not it will be required to sell, the investment before recovery of
 the investment’s cost basis. No impairment losses were
 recorded for the three and six months ended December 25,
 2015.

[0001193125-16-447643:notes:127]
As of December 25, 2015, cash, cash equivalents, and
 marketable securities included bank deposits of $40.0 million held
 in various financial institutions located in the United States in
 order to support the availability of the Facility Agreement (as
 defined in Note 10) and comply with covenants. As discussed in Note
 10, under the terms and conditions of the Facility Agreement, the
 Company shall maintain cash, cash equivalents and/or marketable
 securities in an aggregate amount not less than $40.0 million in
 unencumbered deposits, and/or securities in accounts located in the
 United States at all times during the term of the Facility
 Agreement. As discussed in Note 10, the Company must comply with
 this covenant from and after the effective date of the Facility
 Agreement.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-16-447643:notes:128]
| 11. | Income taxes |

[0001193125-16-447643:notes:129]
As of December 25, 2015 and June 26, 2015, the liability
 for uncertain tax positions including accrued interest and
 penalties was $1.7 million and $1.6 million, respectively. The
 Company expects the estimated amount of liability associated with
 its uncertain tax positions to decrease within the next
 12 months due to the lapse of the applicable statute of
 limitations in foreign tax jurisdictions.

[0001193125-16-447643:notes:130]
[same as prior period, unchanged from 0001193125-15-364290:notes:122]

[0001193125-16-447643:notes:131]
The effective tax rate for the Company for the three months ended
 December 25, 2015 and December 26, 2014 was 6.1% and
 10.5% of net income, respectively. The decrease in the effective
 tax rate for the three months ended December 25, 2015 was
 primarily due to the fact that the Company had lower taxable income
 during the three months ended December 25, 2015 as compared to
 the three months ended December 26, 2014 because of an
 increase in unrealized gain from changes in the fair value of
 derivatives during the three months ended December 25, 2015,
 which are not subject to tax.

[0001193125-16-447643:notes:132]
The effective tax rate for the Company for the six months ended
 December 25, 2015 and December 26, 2014 was 10.7% and
 9.2% of net income, respectively. The increase in the effective tax
 rate for the six months ended December 25, 2015 was primarily
 due to the fact that the Company had higher taxable income during
 the six months ended December 25, 2015 as compared to the six
 months ended December 26, 2014, due to the expiration of a tax
 privilege of the Company’s subsidiary in Thailand.


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0001193125-16-447643:notes:133]
| 17. | Other expenses in relation to flood |

[0001193125-16-447643:notes:134]
During the week of August 10, 2015, the Company’s
 subsidiary in China temporarily suspended production in its
 manufacturing facility due to flooding caused by Typhoon Soudelor.
 The subsidiary resumed operations on August 15, 2015. During
 the three months ended December 25, 2015, the Company did not
 recognize expenses in relation to flood. During the six months
 ended December 25, 2015, the Company recognized $0.9 million
 of losses incurred from the event in the unaudited condensed
 consolidated statements of operations and comprehensive income and
 submitted claims to its insurers for inventory and equipment losses
 attributable to the effects of the flooding.

[0001193125-16-447643:notes:135]
A number of exclusions and limitations in the insurance policies
 (such as coinsurance, facilities location sub-limits and policy
 covenants) may reduce the aggregate amount that the Company will
 ultimately recover from its insurers. Based on the information that
 the Company has at this time, the Company believes that it will
 ultimately recover a majority of its losses. The Company will
 recognize insurance recoveries if and when they become realizable
 and probable.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-16-447643:notes:136]
| 13. | Shareholders’ equity |

[0001193125-16-447643:notes:137]
[same as prior period, unchanged from 0001193125-15-364290:notes:128]

[0001193125-16-447643:notes:138]
[same as prior period, unchanged from 0001193125-15-364290:notes:129]

[0001193125-16-447643:notes:139]
For the six months ended December 25, 2015, Fabrinet issued
 130,779 ordinary shares upon the exercise of options, for cash
 consideration at a weighted-average exercise price of $15.48 per
 share, and 303,307 ordinary shares upon the vesting of restricted
 share units, net of shares withheld.

[0001193125-16-447643:notes:140]
For the six months ended December 26, 2014, Fabrinet issued
 26,677 ordinary shares upon the exercise of options, for cash
 consideration at a weighted-average exercise price of $15.58 per
 share, and 192,437 ordinary shares upon the vesting of restricted
 share units, net of shares withheld.

[0001193125-16-447643:notes:141]
[same as prior period, unchanged from 0001193125-15-364290:notes:132]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-16-447643:notes:142]
| 15. | Commitments and contingencies |

[0001193125-16-447643:notes:143]
Bank guarantees

[0001193125-16-447643:notes:144]
As of December 25, 2015 and June 26, 2015, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $0.8 million and $0.8 million, respectively.

[0001193125-16-447643:notes:145]
Operating lease commitments

[0001193125-16-447643:notes:146]
The Company leases a portion of its office, capital equipment, and
 certain land and buildings for its facilities in the Cayman
 Islands, China, and New Jersey under operating lease arrangements
 that expire in various calendar years through 2020. Rental expense
 under these operating leases amounted to $0.6 million and $0.5
 million for the six months ended December 25, 2015 and
 December 26, 2014, respectively.

[0001193125-16-447643:notes:147]
As of December 25, 2015, the future minimum lease payments due
 under non-cancelable leases were as follows at the end of each
 fiscal year below:

[0001193125-16-447643:notes:148]
| (amount in thousands) |  |  |  |
| 2016 |  | $ | 590 |  |
| 2017 |  |  | 1,034 |  |
| 2018 |  |  | 1,034 |  |
| 2019 |  |  | 572 |  |
| 2020 |  |  | 368 |  |
| Thereafter |  |  | 19 |  |
| Total minimum operating lease payments |  | $ | 3,617 |  |

[0001193125-16-447643:notes:149]
Purchase obligations

[0001193125-16-447643:notes:150]
Purchase obligations represent legally-binding commitments to
 purchase inventory and other commitments made in the normal course
 of business to meet operational requirements. Although open
 purchase orders are considered enforceable and legally binding,
 their terms generally give the Company the option to cancel,
 reschedule and/or adjust its requirements based on its business
 needs prior to the delivery of goods or performance of services.
 Obligations to purchase inventory and other commitments are
 generally expected to be fulfilled within one year.

[0001193125-16-447643:notes:151]
As of December 25, 2015, the Company had an outstanding
 commitment to third parties of approximately $33.3 million, mainly
 related to the construction of a new manufacturing building at the
 Company’s Chonburi campus.

[0001193125-16-447643:notes:152]
Indemnification of directors and officers

[0001193125-16-447643:notes:153]
Cayman Islands law does not limit the extent to which a
 company’s memorandum and articles of association may provide
 for indemnification of directors and officers, except to the extent
 any such provision may be held by the Cayman Islands courts to be
 contrary to public policy, such as to provide indemnification
 against civil fraud or the consequences of committing a crime.
 Fabrinet’s amended and restated memorandum and articles of
 association provide for indemnification of directors and officers
 for actions, costs, charges, losses, damages and expenses incurred
 in their capacities as such, except that such indemnification does
 not extend to any matter in respect of any fraud or dishonesty that
 may attach to any of them.

[0001193125-16-447643:notes:154]
In accordance with Fabrinet’s form of indemnification
 agreement for its directors and officers, Fabrinet has agreed to
 indemnify its directors and officers against certain liabilities
 and expenses incurred by such persons in connection with claims by
 reason of their being such a director or officer. Fabrinet
 maintains a director and officer liability insurance policy that
 may enable it to recover a portion of any future amounts paid under
 the indemnification agreements.


## us-gaap:SubsequentEventsTextBlock

[0001193125-16-447643:notes:155]
| 18. | Subsequent event |

[0001193125-16-447643:notes:156]
During January 2016, the Company incurred severance expenses of
 approximately $0.7 million in connection with a separation
 agreement which the Company entered into with a former named
 executive officer who resigned from the Company effective
 December 31, 2015.


## us-gaap:ScheduleOfCreditLossesForFinancingReceivablesCurrentTableTextBlock

[0001193125-16-447643:notes:157]
[same as prior period, unchanged from 0001193125-15-364290:notes:153]

[0001193125-16-447643:notes:158]
|  |  | Six Months Ended |  |
| (amount in thousands) |  | December 25, 2015 |  |  | December 26, 2014 |  |
| Balance, beginning of period |  | $ | 50 |  |  | $ | 37 |  |
| Credited to income |  |  | (7 | ) |  |  | (3 | ) |
| Balance, end of period |  | $ | 43 |  |  | $ | 34 |  |


## fn:AllowanceForDoubtfulAccountsTextBlock

[0001193125-16-447643:notes:159]
[same as prior period, unchanged from 0001193125-15-364290:notes:155]
