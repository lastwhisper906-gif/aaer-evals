# FN MD&A — 0001408710-23-000028


## mdna

[0001408710-23-000028:mdna:1]
ITEM 7.MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS.

[0001408710-23-000028:mdna:2]
•our goals and strategies;

[0001408710-23-000028:mdna:3]
•our and our customers’ estimates regarding future revenues, operating results, expenses, capital requirements and liquidity;

[0001408710-23-000028:mdna:4]
•our belief that we will be able to maintain favorable pricing on our services;

[0001408710-23-000028:mdna:5]
•our expectation that the portion of our future revenues attributable to customers in regions outside of North America will increase compared with the portion of those revenues for fiscal year 2023;

[0001408710-23-000028:mdna:6]
•our expectation that we will incur incremental costs of revenue as a result of our planned expansion of our business into new geographic markets;

[0001408710-23-000028:mdna:7]
•our expectation that our fiscal year 2024 selling, general and administrative (“SG&A”) expenses will increase compared to our fiscal year 2023 SG&A expenses;

[0001408710-23-000028:mdna:8]
•our expectation that our employee costs will increase in Thailand and the People’s Republic of China (“PRC”);

[0001408710-23-000028:mdna:9]
•our future capital expenditures and our needs for additional financing;

[0001408710-23-000028:mdna:10]
•the expansion of our manufacturing capacity, including into new geographies;

[0001408710-23-000028:mdna:11]
•the growth rates of our existing markets and potential new markets;

[0001408710-23-000028:mdna:12]
•our ability, and the ability of our customers and suppliers, to respond successfully to technological or industry developments;

[0001408710-23-000028:mdna:13]
•our expectations regarding the potential impact of macroeconomic conditions and international political instability on our business, financial condition and operating results;

[0001408710-23-000028:mdna:14]
•our suppliers’ estimates regarding future costs;

[0001408710-23-000028:mdna:15]
•our ability to increase our penetration of existing markets and to penetrate new markets;

[0001408710-23-000028:mdna:16]
•our plans to diversify our sources of revenues;

[0001408710-23-000028:mdna:17]
•our plans to execute acquisitions;

[0001408710-23-000028:mdna:18]
•trends in the optical communications, industrial lasers, and sensors markets, including trends to outsource the production of components used in those markets;

[0001408710-23-000028:mdna:19]
•our ability to attract and retain a qualified management team and other qualified personnel and advisors; and

[0001408710-23-000028:mdna:20]
•competition in our existing and new markets.

[0001408710-23-000028:mdna:21]
Overview

[0001408710-23-000028:mdna:22]
For an overview of our business, see PART I – ITEM 1. BUSINESS.

[0001408710-23-000028:mdna:23]
Fiscal Years

[0001408710-23-000028:mdna:24]
We utilize a 52-53 week fiscal year ending on the last Friday in June. Our fiscal years 2023, 2022, and 2021 ended on June 30, 2023, June 24, 2022 and June 25, 2021, and consisted of 53 weeks, 52 weeks and 52 weeks, respectively.

[0001408710-23-000028:mdna:25]
Revenues

[0001408710-23-000028:mdna:26]
We believe we are able to expand our relationships with existing customers and attract new customers due to, among other factors, our broad range of complex engineering and manufacturing service offerings, flexible low-cost manufacturing platform, process optimization capabilities, advanced supply chain management, excellent customer service, and experienced management team. Although we expect the prices we charge for our manufactured products to decrease over time (partly as a result of competitive market forces), we believe we will be able to continue to maintain favorable pricing for our services because of our ability to reduce cycle time, adjust our product mix by focusing on more complicated products, improve product quality and yields, and reduce material costs for the products we manufacture. We believe these capabilities have enabled us to help our OEM customers reduce their manufacturing costs while maintaining or improving the design, quality, reliability, and delivery times for their products.

[0001408710-23-000028:mdna:27]
Revenues, by percentage, from individual customers representing 10% or more of our revenues is set forth in Note 21 of our audited consolidated financial statements. Because we depend upon a small number of customers for a significant percentage of our total revenues, a reduction in orders from, a loss of, or any other adverse actions by, any one of these customers would reduce our revenues and could have a material adverse effect on our business, operating results and share price. Moreover, our customer concentration increases the concentration of our accounts receivable and payment default by any of our key customers will negatively impact our exposure. Many of our existing and potential customers have substantial debt burdens, have experienced financial distress or have static or declining revenues, all of which may be exacerbated by the continued uncertainty in the global economies. Certain customers have gone out of business or have been acquired or announced their withdrawal from segments of the optics market. We generate significant accounts payable and inventory for the services that we provide to our customers, which could expose us to substantial and potentially unrecoverable costs if we do not receive payment from our customers. Therefore, any financial difficulties that our key customers experience could materially and adversely affect our operating results and financial condition by generating charges for inventory write-offs, provisions for doubtful accounts, and increases in working capital requirements due to increased days inventory and in accounts receivable.

[0001408710-23-000028:mdna:28]
Furthermore, reliance on a small number of customers gives those customers substantial purchasing power and leverage in negotiating contracts with us. In addition, although we enter into master supply agreements with our customers, the level of business to be transacted under those agreements is not guaranteed. Instead, we are awarded business under those agreements on a project-by-project basis. Some of our customers have at times significantly reduced or delayed the volume of manufacturing services that they order from us. If we are unable to maintain our relationships with our existing significant customers, our business, financial condition and operating results could be harmed.

[0001408710-23-000028:mdna:29]
We expect that disruptions in our supply chain and fluctuations in the availability of parts and materials will continue to have an adverse impact on our ability to generate revenue, despite strong demand from our customers. Furthermore, in some cases, our efforts to identify and secure alternative supply chain sources has resulted in our customers or their end customers requiring requalification and validation of components, a process that can often be lengthy and has negatively impacted the timing of our revenue. In addition, we expect the near-term inventory correction that our optical communications customers are experiencing to persist, which will have an adverse impact on our ability to generate revenue.

[0001408710-23-000028:mdna:30]
Revenues by Geography

[0001408710-23-000028:mdna:31]
We generate revenues from three geographic regions: North America, Asia-Pacific and others, and Europe. Revenues are attributed to a particular geographic area based on the bill-to-location of our customers, notwithstanding that our customers may ultimately ship their products to end customers in a different geographic region. The substantial majority of our revenues are derived from our manufacturing facilities in Asia-Pacific.

[0001408710-23-000028:mdna:32]
The percentage of our revenues generated from a bill-to location outside of North America increased from 50.7% in fiscal year 2022 to 52.0% in fiscal year 2023, which was partially due to a decrease in sales to our customers in Europe by 4.9%. Based on the short- and medium-term indications and forecasts from our customers, we expect that the portion of our

[0001408710-23-000028:mdna:33]
future revenues attributable to customers in regions outside of North America will increase as compared with the portion of revenues attributable to such customers during fiscal year 2023.

[0001408710-23-000028:mdna:34]
The following table presents percentages of total revenues by geographic regions:

[0001408710-23-000028:mdna:35]
|  | Years Ended |
|  | June 30, 2023 |  | June 24, 2022 |  | June 25, 2021 |
| North America | 48.0 | % |  | 49.3 | % |  | 47.2 | % |
| Asia-Pacific | 43.2 |  |  | 37.0 |  |  | 35.6 |  |
| Europe | 8.8 |  |  | 13.7 |  |  | 17.2 |  |
|  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001408710-23-000028:mdna:36]
Our Contracts

[0001408710-23-000028:mdna:37]
We enter into supply agreements with our customers which generally have an initial term of up to three years, subject to automatic renewals for subsequent one-year terms unless expressly terminated. Although there are no minimum purchase requirements in our supply agreements, our customers provide us with rolling forecasts of their demand requirements. Our supply agreements generally include provisions for pricing and periodic review of pricing, consignment of our customer’s unique production equipment to us, and the sharing of benefits from cost-savings derived from our efforts. We are generally required to purchase materials, which may include long lead-time materials and materials that are subject to minimum order quantities and/or non-cancelable or non-returnable terms, to meet the stated demands of our customers. After procuring materials, we manufacture products for our customers based on purchase orders that contain terms regarding product quantities, delivery locations and delivery dates. Our customers generally are obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by our customers within a specified period of time, or that are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under our contracts. Once materials are designated as either excess or obsolete inventory, our customers are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

[0001408710-23-000028:mdna:38]
Cost of Revenues

[0001408710-23-000028:mdna:39]
The key components of our cost of revenues are material costs, employee costs, and infrastructure-related costs. Material costs generally represent the majority of our cost of revenues. Several of the materials we require to manufacture products for our customers are customized for their products and often sourced from a single supplier or in some cases, our own subsidiaries. Shortages from sole-source suppliers due to yield loss, quality concerns and capacity constraints, among other factors, may increase our expenses and negatively impact our gross profit margin or total revenues in a given quarter. Material costs include scrap material. Historically, scrap rate diminishes during a product’s life cycle due to process, fixturing and test improvement and optimization.

[0001408710-23-000028:mdna:40]
A second significant element of our cost of revenues is employee costs, including indirect employee costs related to design, configuration and optimization of manufacturing processes for our customers, quality testing, materials testing and other engineering services; and direct costs related to our manufacturing employees. Direct employee costs include employee salaries, insurance and benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a lesser extent, costs to recruit, train and retain employees. Our cost of revenues is significantly impacted by salary levels in Thailand, the PRC and the United Kingdom, the fluctuation of the Thai baht, RMB and GBP against our functional currency, the U.S. dollar, and our ability to retain our employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. Wage increases may impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention and asset utilization.

[0001408710-23-000028:mdna:41]
Our infrastructure costs are comprised of depreciation, utilities, facilities management and overhead costs. Most of our facility leases are long-term agreements. Our depreciation costs include buildings and fixed assets, primarily at our Pinehurst and Chonburi campuses in Thailand, and capital equipment located at each of our manufacturing locations.

[0001408710-23-000028:mdna:42]
We expect to incur incremental costs of revenue as a result of our planned expansion into new geographic markets, though we are not able to determine the amount of these incremental expenses.

[0001408710-23-000028:mdna:43]
During fiscal years 2023, 2022 and 2021, discretionary merit-based bonus awards were made to our non-executive employees. Charges included in cost of revenues for bonus awards to non-executive employees were $6.8 million, $6.0 million and $5.6 million for fiscal years 2023, 2022 and 2021, respectively.

[0001408710-23-000028:mdna:44]
Share-based compensation expense included in cost of revenues was $6.7 million, $6.0 million and $6.2 million for fiscal years 2023, 2022 and 2021, respectively.

[0001408710-23-000028:mdna:45]
We expect to incur incremental costs of revenue as a result of our planned expansion into new geographic markets, though we are not able to determine the amount of these incremental expenses.

[0001408710-23-000028:mdna:46]
Selling, General and Administrative Expenses

[0001408710-23-000028:mdna:47]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative and other support personnel, including research and development expenses related to the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense and other general expenses not related to cost of revenues. In fiscal year 2024, we expect our SG&A expenses will increase compared with our fiscal year 2023 SG&A expenses, mainly due to increase in employee costs, sales and marketing cost and investing in information technology hardware.

[0001408710-23-000028:mdna:48]
The compensation committee of our board of directors approved a fiscal year 2023 executive incentive plan with quantitative objectives based solely on achieving certain revenue targets and non-U.S. GAAP operating margin targets for fiscal year 2023. Bonuses under the fiscal year 2023 executive incentive plan are payable after the end of fiscal year 2023. In fiscal year 2022, the compensation committee approved a fiscal year 2022 executive incentive plan with quantitative objectives that were based solely on achieving certain revenue targets and non-U.S. GAAP operating margin targets for fiscal year 2022. In August 2022, the compensation committee awarded bonuses to our executive employees for Company achievements of performance under our fiscal year 2022 executive incentive plan. Discretionary merit-based bonus awards are also available to our non-executive employees and payable on a quarterly basis.

[0001408710-23-000028:mdna:49]
Charges included in SG&A expenses for bonus distributions to non-executive and executive employees were $6.1 million, $5.0 million and $4.6 million for fiscal years 2023, 2022 and 2021, respectively.

[0001408710-23-000028:mdna:50]
Share-based compensation expense included in SG&A expenses was $20.9 million, $22.1 million and $19.3 million for fiscal years 2023, 2022 and 2021, respectively.

[0001408710-23-000028:mdna:51]
Additional Financial Disclosures

[0001408710-23-000028:mdna:52]
Foreign Exchange

[0001408710-23-000028:mdna:53]
As a result of our international operations, we are exposed to foreign exchange risk arising from various currency exposures, and primarily with respect to the Thai baht. Although a majority of our total revenues is denominated in U.S. dollars, a substantial portion of our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rate between the Thai baht and the U.S. dollar has fluctuated substantially in recent years and may continue to fluctuate substantially in the future. We report our financial results in U.S. dollars and our results of operations have been and could in the future be negatively impacted if the Thai baht appreciates against the U.S. dollar. Smaller portions of our expenses are incurred in a variety of other currencies, including RMB, GBP, Canadian dollars, Euros, and Japanese yen, the appreciation of which may also negatively impact our financial results.

[0001408710-23-000028:mdna:54]
In order to manage the risks arising from fluctuations in foreign currency exchange rates, we use derivative instruments. We may enter into foreign currency exchange forward or put option contracts to manage foreign currency exposures associated with certain assets and liabilities and other forecasted foreign currency transactions and may designate these instruments as hedging instruments. The forward and put option contracts generally have maturities of up to 12 months. All foreign currency exchange contracts are recognized in the consolidated balance sheets at fair value. Gains or losses on our forward and put option contracts generally present gross amount in the assets, liabilities, and transactions economically hedged.

[0001408710-23-000028:mdna:55]
We had foreign currency denominated assets and liabilities in Thai baht, RMB and GBP as follows:

[0001408710-23-000028:mdna:56]
|  | As of June 30, 2023 |  | As of June 24, 2022 |
| (in thousands, except percentages) | ForeignCurrency |  | $ |  | % |  | ForeignCurrency |  | $ |  | % |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 754,443 |  |  | $ | 21,198 |  |  | 61.1 |  |  | 753,924 |  |  | $ | 21,213 |  |  | 64.0 |  |
| RMB | 65,669 |  |  | 9,088 |  |  | 26.2 |  |  | 34,382 |  |  | 5,132 |  |  | 15.5 |  |
| GBP | 3,487 |  |  | 4,401 |  |  | 12.7 |  |  | 5,544 |  |  | 6,801 |  |  | 20.5 |  |
| Total |  |  | $ | 34,687 |  |  | 100.0 |  |  |  |  | $ | 33,146 |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 2,956,730 |  |  | $ | 83,078 |  |  | 93.5 |  |  | 2,393,112 |  |  | $ | 67,336 |  |  | 84.8 |  |
| RMB | 40,477 |  |  | 5,602 |  |  | 6.3 |  |  | 61,191 |  |  | 9,133 |  |  | 11.5 |  |
| GBP | 114 |  |  | 144 |  |  | 0.2 |  |  | 2,379 |  |  | 2,918 |  |  | 3.7 |  |
| Total |  |  | $ | 88,824 |  |  | 100.0 |  |  |  |  | $ | 79,387 |  |  | 100.0 |  |

[0001408710-23-000028:mdna:57]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and liabilities denominated in the same currency in accordance with management’s policy. As of June 30, 2023, there was $143.0 million in foreign currency forward contracts outstanding on the Thai baht payables. As of June 24, 2022, there was $135.0 million in foreign currency forward contracts outstanding on the Thai baht payables.

[0001408710-23-000028:mdna:58]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of June 30, 2023 and June 24, 2022, we did not have any derivative contracts denominated in RMB.

[0001408710-23-000028:mdna:59]
The GBP assets represent cash and trade accounts receivable. The GBP liabilities represent trade accounts payable and other payables. As of June 30, 2023 and June 24, 2022, we did not have any derivative contracts denominated in GBP.

[0001408710-23-000028:mdna:60]
For fiscal years 2023 and 2022, we recorded an unrealized gain of $0.4 million and unrealized loss of $0.8 million, respectively, related to derivatives that are not designated as hedging instruments in the consolidated statements of operations and comprehensive income.

[0001408710-23-000028:mdna:61]
Currency Regulation and Dividend Distribution

[0001408710-23-000028:mdna:62]
Foreign exchange regulation in the PRC is primarily governed by the following rules:

[0001408710-23-000028:mdna:63]
•Foreign Currency Administration Rules, as amended on August 5, 2008, or the Exchange Rules;

[0001408710-23-000028:mdna:64]
•Administration Rules of the Settlement, Sale and Payment of Foreign Exchange (1996), or the Administration Rules; and

[0001408710-23-000028:mdna:65]
•Notice on Perfecting Practices Concerning Foreign Exchange Settlement Regarding the Capital Contribution by Foreign-invested Enterprises, as promulgated by the State Administration of Foreign Exchange (“SAFE”), on August 29, 2008, or Circular 142.

[0001408710-23-000028:mdna:66]
Under the Exchange Rules, RMB is freely convertible into foreign currencies for current account items, including the distribution of dividends, interest payments, trade and service-related foreign exchange transactions. However, conversion of RMB for capital account items, such as direct investments, loans, security investments and repatriation of investments, is still subject to the approval of SAFE.

[0001408710-23-000028:mdna:67]
Under the Administration Rules, foreign-invested enterprises may only buy, sell, or remit foreign currencies at banks authorized to conduct foreign exchange business after providing valid commercial documents and relevant supporting documents and, in the case of capital account item transactions, obtaining approval from SAFE. Capital investments by foreign-invested enterprises outside of the PRC are also subject to limitations, which include approvals by the Ministry of Commerce, SAFE and the State Development and Reform Commission.

[0001408710-23-000028:mdna:68]
Circular 142 regulates the conversion by a foreign-invested company of foreign currency into RMB by restricting how the converted RMB may be used. Circular 142 requires that the registered capital of a foreign-invested enterprise settled in RMB converted from foreign currencies may only be used for purposes within the business scope approved by the applicable governmental authority and may not be used for equity investments within the PRC. In addition, SAFE strengthened its oversight of the flow and use of the registered capital of foreign-invested enterprises settled in RMB converted from foreign currencies. The use of such RMB capital may not be changed without SAFE’s approval and may not be used to repay RMB loans if the proceeds of such loans have not been used.

[0001408710-23-000028:mdna:69]
On January 5, 2007, SAFE promulgated the Detailed Rules for Implementing the Measures for the Administration on Individual Foreign Exchange, or the Implementation Rules. Under the Implementation Rules, PRC citizens who are granted share options by an overseas publicly-listed company are required, through a PRC agent or PRC subsidiary of such overseas publicly-listed company, to register with SAFE and complete certain other procedures.

[0001408710-23-000028:mdna:70]
In addition, the General Administration of Taxation has issued circulars concerning employee share options. Under these circulars, our employees working in the PRC who exercise share options will be subject to PRC individual income tax. Our PRC subsidiary has obligations to file documents related to employee share options with relevant tax authorities and withhold individual income taxes of those employees who exercise their share options.

[0001408710-23-000028:mdna:71]
Furthermore, our transfer of funds to our subsidiaries in Thailand and the PRC are each subject to approval by governmental authorities in case of an increase in registered capital, or subject to registration with governmental authorities in case of a shareholder loan. These limitations on the flow of funds between our subsidiaries and us could restrict our ability to act in response to changing market conditions.

[0001408710-23-000028:mdna:72]
Income Tax

[0001408710-23-000028:mdna:73]
Our effective tax rate is a function of the mix of tax rates in the various jurisdictions in which we do business. We are domiciled in the Cayman Islands. Under the current laws of the Cayman Islands, we are not subject to tax in the Cayman Islands on income or capital gains until March 6, 2039.

[0001408710-23-000028:mdna:74]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption on income generated from projects to manufacture certain products at our Chonburi campus is currently available to us through June 2026. Similar preferential tax treatment was available to us through June 2020 with respect to products manufactured at our Pinehurst campus Building 6. After June 2020, 50% of our income generated from products manufactured at our Pinehurst campus will be exempted from tax through June 2025. New preferential tax treatment is available to us for products manufactured at our Chonburi campus Building 9, where income generated will be tax exempt through 2031, capped at our actual investment amount. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years from the date on which preferential tax treatment was granted. Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001408710-23-000028:mdna:75]
The corporate income tax rates for our subsidiaries in the PRC, the U.S., the U.K. and Israel are 25%, 21%, 25% and 23%, respectively.

[0001408710-23-000028:mdna:76]
Critical Accounting Policies and Use of Estimates

[0001408710-23-000028:mdna:77]
We prepare our consolidated financial statements in conformity with U.S. GAAP, which requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent liabilities on the date of the consolidated financial statements and the reported amounts of revenues and expenses during the financial reporting period. We continually evaluate these estimates and assumptions based on the most recently available information, our own historical experience and on various other assumptions that we believe to be reasonable under the circumstances. The evaluation results form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Because the use of estimates is an integral component of the financial reporting process, actual results could differ from those estimates. Some of our accounting policies require higher degrees of judgment than others in their application. We consider the policies discussed below to be critical to an understanding of our consolidated financial statements, as their application places the most significant demands on our management’s judgment.

[0001408710-23-000028:mdna:78]
A quantitative sensitivity analysis is provided where such information is reasonably available, can be reliably estimated, and provides material information to investors. The amounts used to assess sensitivity are included for illustrative purposes only and do not represent management’s predictions of variability.

[0001408710-23-000028:mdna:79]
Our critical accounting policies and the adoption of new accounting policies are disclosed in Note 2 – Summary of significant accounting policies. There were no changes to our accounting policies.

[0001408710-23-000028:mdna:80]
Revenue Recognition

[0001408710-23-000028:mdna:81]
We derive total revenues primarily from the assembly of products under supply agreements with our customers and the fabrication of customized optics and glass. We recognize revenue relating to contracts that depict the transfer of promised goods or services to customers in an amount reflecting the consideration to which we expect to be entitled in exchange for such goods or services. In order to meet this requirement, we apply the following five steps: (1) identify the contract with a customer, (2) identify the performance obligations in the contract, (3) determine the transaction price, (4) allocate the transaction price to the performance obligations in the contract, and (5) recognize revenue when a performance obligation is satisfied. Revenue is recognized net of any taxes collected from customers, which is subsequently remitted to governmental authorities.

[0001408710-23-000028:mdna:82]
A performance obligation is a contractual promise to transfer a distinct good or service to the customer. In contracts with multiple performance obligations, we identify each performance obligation and evaluate whether such obligation is distinct within the context of the contract at contract inception. The majority of our contracts have a single performance obligation, as the promise to transfer the individual goods or services is not separately identifiable from other promises under the contracts and, therefore, is not distinct.

[0001408710-23-000028:mdna:83]
Management uses judgment to identify performance obligations within a contract and to determine whether multiple promised goods or services in a contract should be accounted for separately or as a group. Judgment is also used in interpreting commercial terms and determining when transfer of control occurs. Moreover, judgment is used to estimate the contract’s transaction price and allocate it to each performance obligation. Any material changes in the identification of performance obligations, determination and allocation of the transaction price to performance obligations, and determination of when transfer of control occurs to the customer, could impact the timing and amount of revenue recognition, which could have a material effect on our financial condition and results of operations.

[0001408710-23-000028:mdna:84]
Long-Lived Assets

[0001408710-23-000028:mdna:85]
We review property, plant and equipment for impairment on a quarterly basis or when events or changes in circumstances indicate the carrying amount of an asset may not be recoverable. An impairment loss is recognized when the carrying amount of a long-lived asset or assets group exceeds its fair value. Recoverability of property and equipment is measured by comparing carrying amount to the projected undiscounted cash flows the property and equipment are expected to generate. If such assets are considered to be impaired, the impairment loss recognized, if any, is the amount by which the carrying amount of the property and equipment exceeds its fair value. The estimate of projected cash flows involves numerous assumptions which require significant judgment by us, including, but not limited to, future use of the assets for our operations versus sale or disposal of the assets, future selling prices for our products, and future production and sales volumes. In addition, significant judgment is required in determining the groups of assets for which impairment tests are separately performed.

[0001408710-23-000028:mdna:86]
Allowance for Doubtful Accounts

[0001408710-23-000028:mdna:87]
We perform ongoing credit evaluations of our customers’ financial condition and make provisions for doubtful accounts based on the outcomes of these credit evaluations. We evaluate the collectability of our accounts receivable based on specific customer circumstances, current economic trends, historical experience with collections, and the age of past due receivables. Changes in circumstances, such as an unexpected material adverse change in a major customer’s ability to meet its financial obligation to us or its payment trends, may require us to further adjust estimates of the recoverability of amounts due to us, which could have a material adverse effect on our business, financial condition and results of operations.

[0001408710-23-000028:mdna:88]
Inventory Valuation

[0001408710-23-000028:mdna:89]
Our inventory is stated at the lower of cost (on a first-in, first-out basis) or market value. Our industry is characterized by rapid technological change, short-term customer commitments, and rapid changes in demand. We make provisions for estimated excess and obsolete inventory based on regular reviews of inventory quantities on hand on a quarterly basis and the latest forecasts of product demand and production requirements from our customers. If actual market conditions or our customers’ product demands are less favorable than those projected, additional provisions may be required. In addition, unanticipated changes in liquidity or the financial positions of our customers or changes in economic conditions may require additional provisions for inventory due to our customers’ inability to fulfill their contractual obligations. As the market conditions or our customers’ product demands are inherently difficult to predict, the actual volumes may vary significantly from projected volumes. Differences in forecasted volume used in calculating excess and obsolete inventory can result in a material adverse effect on our business, financial condition and results of operations. During fiscal year 2023 and fiscal year 2022, a change of 10% for excess and obsolete materials, based on product demand and production requirements from our customers, would have affected our net income by approximately $1.0 million and $0.7 million, respectively.

[0001408710-23-000028:mdna:90]
Deferred Income Taxes

[0001408710-23-000028:mdna:91]
Our deferred income tax assets represent temporary differences between the carrying amount and the tax basis of existing assets and liabilities that will result in deductible and payable amounts in future years, including net operating loss carry forwards. Based on estimates, the carrying value of our net deferred tax assets assumes that it is more likely than not that we will be able to generate sufficient future taxable income in certain tax jurisdictions to realize these deferred income tax assets. Our judgments regarding future profitability may change depending on future market conditions, changes in U.S. or international tax laws, or other factors. If these estimates and related assumptions change in the future, we may be required to increase or decrease our valuation allowance against the deferred tax assets, resulting in additional or lesser income tax expense.

[0001408710-23-000028:mdna:92]
During fiscal year 2020, one of our subsidiaries in the U.S. generated net operating loss and management expected that such subsidiary would continue to have net operating losses in the foreseeable future; therefore, management believed it was more likely than not that all of the deferred tax assets of such subsidiary would not be utilized. Thus, a full valuation allowance of $2.1 million for the deferred tax assets was set up as of the end of fiscal year 2020.

[0001408710-23-000028:mdna:93]
During fiscal year 2021, our subsidiaries in the U.S. generated taxable income sufficient for the utilization of loss carryforwards due to better operating performance and effective control of operating expenses. Management determined that it was more likely than not that future taxable income would be sufficient to allow utilization of the deferred tax assets. Thus, a full valuation allowance of $2.1 million for the deferred tax assets was released as of June 25, 2021 and no valuation allowances for deferred tax assets of our subsidiaries in the U.S. have been set up as of June 24, 2022 and June 30, 2023.

[0001408710-23-000028:mdna:94]
During fiscal year 2020, our subsidiary in the U.K. also generated net operating loss and management expected that such subsidiary would continue to have net operating losses in the foreseeable future. Therefore, management believed it was more likely than not that all of the deferred tax assets of such subsidiary would not be utilized. Thus, a full valuation allowance of $1.6 million for the deferred tax assets was set up as of the end of fiscal year 2020. A full valuation allowance of $4.9 million and $2.1 million were set up for the fiscal year ended June 24, 2022 and June 25, 2021, respectively.

[0001408710-23-000028:mdna:95]
During fiscal year 2023, our subsidiary in the U.K. generated taxable income and was able to utilize loss carryforwards. Management determined that it was more likely than not that future taxable income would be sufficient to allow utilization of the deferred tax assets. Thus, a full valuation allowance of $1.6 million for the deferred tax assets was released as of June 30, 2023.

[0001408710-23-000028:mdna:96]
Results of Operations

[0001408710-23-000028:mdna:97]
The following table sets forth a summary of our consolidated statements of operations and comprehensive income. Note that period-to-period comparisons of operating results should not be relied upon as indicative of future performance.

[0001408710-23-000028:mdna:98]
|  | Years Ended |
| (in thousands) | June 30, 2023 |  | June 24, 2022 |  | June 25, 2021 |
| Revenues | $ | 2,645,237 |  |  | $ | 2,262,224 |  |  | $ | 1,879,350 |  |
| Cost of revenues | (2,308,964) |  |  | (1,983,630) |  |  | (1,657,987) |  |
| Gross profit | 336,273 |  |  | 278,594 |  |  | 221,363 |  |
| Selling, general and administrative expenses | (77,673) |  |  | (73,941) |  |  | (70,567) |  |
| Restructuring and other related costs | (6,896) |  |  | (135) |  |  | (43) |  |
| Operating income | 251,704 |  |  | 204,518 |  |  | 150,753 |  |
| Interest income | 11,234 |  |  | 2,205 |  |  | 3,783 |  |
| Interest expense | (1,472) |  |  | (432) |  |  | (1,100) |  |
| Foreign exchange gain (loss), net | (1,211) |  |  | 2,302 |  |  | 508 |  |
| Other income (expense), net | (159) |  |  | (1,627) |  |  | (3,460) |  |
| Income before income taxes | 260,096 |  |  | 206,966 |  |  | 150,484 |  |
| Income tax expense | (12,183) |  |  | (6,586) |  |  | (2,143) |  |
| Net income | 247,913 |  |  | 200,380 |  |  | 148,341 |  |
| Other comprehensive income (loss), net of tax | 4,678 |  |  | (6,527) |  |  | (5,119) |  |
| Net comprehensive income | $ | 252,591 |  |  | $ | 193,853 |  |  | $ | 143,222 |  |

[0001408710-23-000028:mdna:99]
The following table sets forth a summary of our consolidated statements of operations and comprehensive income as a percentage of total revenues for the periods indicated.

[0001408710-23-000028:mdna:100]
|  | Years Ended |
|  | June 30, 2023 |  | June 24, 2022 |  | June 25, 2021 |
| Revenues | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenues | (87.3) |  |  | (87.7) |  |  | (88.2) |  |
| Gross profit | 12.7 |  |  | 12.3 |  |  | 11.8 |  |
| Selling, general and administrative expenses | (2.9) |  |  | (3.3) |  |  | (3.8) |  |
| Restructuring and other related costs | (0.3) |  |  | 0.0 |  |  | 0.0 |  |
| Operating income | 9.5 |  |  | 9.0 |  |  | 8.0 |  |
| Interest income | 0.4 |  |  | 0.1 |  |  | 0.2 |  |
| Interest expense | (0.1) |  |  | 0.0 |  |  | 0.0 |  |
| Foreign exchange gain (loss), net | 0.0 |  |  | 0.1 |  |  | 0.0 |  |
| Other income (expense), net | 0.0 |  |  | (0.1) |  |  | (0.2) |  |
| Income before income taxes | 9.8 |  |  | 9.1 |  |  | 8.0 |  |
| Income tax expense | (0.4) |  |  | (0.3) |  |  | (0.1) |  |
| Net income | 9.4 |  |  | 8.8 |  |  | 7.9 |  |
| Other comprehensive income (loss), net of tax | 0.2 |  |  | (0.3) |  |  | (0.3) |  |
| Net comprehensive income | 9.6 | % |  | 8.5 | % |  | 7.6 | % |

[0001408710-23-000028:mdna:101]
42

[0001408710-23-000028:mdna:102]
The following table sets forth our revenues by end market for the periods indicated.

[0001408710-23-000028:mdna:103]
|  | Years Ended |
| (in thousands) | June 30, 2023 |  | June 24, 2022 |  | June 25, 2021 |
| Optical communications | $ | 2,008,347 |  |  | $ | 1,782,799 |  |  | $ | 1,441,338 |  |
| Lasers, sensors, and other | 636,890 |  |  | 479,425 |  |  | 438,012 |  |
| Total | $ | 2,645,237 |  |  | $ | 2,262,224 |  |  | $ | 1,879,350 |  |

[0001408710-23-000028:mdna:104]
We operate and internally manage a single operating segment. As such, discrete information with respect to separate product lines and segments is not accumulated.

[0001408710-23-000028:mdna:105]
Comparison of Fiscal Year 2023 with Fiscal Year 2022

[0001408710-23-000028:mdna:106]
Revenues. Our revenues increased by $383.0 million, or 16.9%, to $2,645.2 million for fiscal year 2023, compared with $2,262.2 million for fiscal year 2022. This increase was primarily due to an increase in our key customers’ demand for fiscal year 2023. Revenues from optical communications products represented 75.9% of our revenues for fiscal year 2023, compared with 78.8% for fiscal year 2022.

[0001408710-23-000028:mdna:107]
Cost of revenues. Our cost of revenues increased by $325.4 million, or 16.4%, to $2,309.0 million, or 87.3% of revenues, for fiscal year 2023, compared with $1,983.6 million, or 87.7% of revenues, for fiscal year 2022. The increase in cost of revenues was primarily due to a proportional increase in sales volume.

[0001408710-23-000028:mdna:108]
Gross profit. Our gross profit increased by $57.7 million, or 20.7%, to $336.3 million, or 12.7% of revenues, for fiscal year 2023, compared with $278.6 million, or 12.3% of revenues, for fiscal year 2022. The increase was primarily due to sales volume and product mix.

[0001408710-23-000028:mdna:109]
SG&A expenses. Our SG&A expenses increased by $3.8 million, or 5.1%, to $77.7 million, or 2.9% of revenues, for fiscal year 2023, compared with $73.9 million, or 3.3% of revenues, for fiscal year 2022. Our SG&A expenses increased during fiscal year 2023, compared with fiscal year 2022, mainly due to (1) recognizing an actuarial loss on obligation of $1.1 million in fiscal year 2023, compared with recognizing an actuarial gain on obligation of $1.5 million in fiscal year 2022; (2) an increase in executive benefits of $1.0 million; (3) an increase in R&D expenses of $0.8 million; (4) an increase in legal and consulting fees of $0.6 million; and (5) an increase in insurance expenses of $0.3 million; offset by a net decrease in allowance for doubtful accounts of $1.5 million.

[0001408710-23-000028:mdna:110]
Restructuring and other related costs. We recorded restructuring and other related costs for fiscal year 2023 of $6.9 million.

[0001408710-23-000028:mdna:111]
Operating income. Our operating income increased by $47.2 million, or 23.1%, to $251.7 million, or 9.5% of revenues, for fiscal year 2023, compared with $204.5 million, or 9.0% of revenues, for fiscal year 2022.

[0001408710-23-000028:mdna:112]
Interest income. Our interest income increased by $9.0 million to $11.2 million for fiscal year 2023, compared with $2.2 million for fiscal year 2022. The increase was primarily due to a higher weighted average interest rate in fiscal year 2023 compared with fiscal year 2022.

[0001408710-23-000028:mdna:113]
Interest expense. Our interest expense increased by $1.1 million to $1.5 million for fiscal year 2023, compared with $0.4 million for fiscal year 2022. The increase was primarily due to (1) lower interest expense capitalized of $0.9 million following the completion of a new manufacturing building at our Chonburi campus in July 2022, and (2) lower amortization of the fair value of interest rate swaps of $0.3 million during fiscal year 2023; offset by lower interest expense due to a decrease in the amount of outstanding long-term loans.

[0001408710-23-000028:mdna:114]
Foreign exchange gain (loss), net. We recorded foreign exchange loss, net of $1.2 million for fiscal year 2023, compared with foreign exchange gain, net of $2.3 million for fiscal year 2022. The foreign exchange loss was mainly due to (1) unrealized foreign exchange loss from revaluation of outstanding Thai baht assets and liabilities of $3.5 million for fiscal year 2023, and (2) realized foreign exchange loss from payment/receipt of $3.1 million for fiscal year 2023, offset by (1) foreign exchange gain from subsidiaries in the PRC and the U.K., totaling $1.5 million for fiscal year 2023, (2) unrealized foreign exchange gain from mark-to-market of forward contracts of $1.2 million for fiscal year 2023, and (3) unrealized foreign exchange gain from revaluation of other currencies of $0.4 million for fiscal year 2023.

[0001408710-23-000028:mdna:115]
Income before income taxes. We recorded income before income taxes of $260.1 million for fiscal year 2023, compared with $207.0 million for fiscal year 2022.

[0001408710-23-000028:mdna:116]
Income tax expense. Our provision for income tax reflects an effective tax rate of 4.7% and 3.2% for fiscal year 2023 and fiscal year 2022, respectively. The increase was primarily due to higher income subject to tax in fiscal year 2023, as compared to fiscal year 2022.

[0001408710-23-000028:mdna:117]
Net income. We recorded net income of $247.9 million, or 9.4% of revenues, for fiscal year 2023, compared with net income of $200.4 million, or 8.8% of revenues, for fiscal year 2022.

[0001408710-23-000028:mdna:118]
Other comprehensive income (loss). We recorded other comprehensive income of $4.7 million, or 0.2% of revenues, for fiscal year 2023, compared with other comprehensive loss of $6.5 million, or 0.3% of revenues, for fiscal year 2022. The other comprehensive income was mainly due to (1) unrealized gain from mark-to-market of available-for-sale debt securities of $9.1 million for fiscal year 2023, and (2) unrealized gain from mark-to-market of forward contracts and interest rate swap agreement of $2.1 million for fiscal year 2023.

[0001408710-23-000028:mdna:119]
Comparison of Fiscal Year 2022 with Fiscal Year 2021

[0001408710-23-000028:mdna:120]
Revenues. Our revenues increased by $382.8 million, or 20.4%, to $2,262.2 million for fiscal year 2022, compared with $1,879.4 million for fiscal year 2021. This increase was primarily due to an increase in customers’ demand for optical communications manufacturing services, particularly telecom manufacturing services, for fiscal year 2022. Revenues from optical communications products represented 78.8% of our revenues for fiscal year 2022, compared with 76.7% for fiscal year 2021.

[0001408710-23-000028:mdna:121]
Cost of revenues. Our cost of revenues increased by $325.6 million, or 19.6%, to $1,983.6 million, or 87.7% of revenues, for fiscal year 2022, compared with $1,658.0 million, or 88.2% of revenues, for fiscal year 2021. The increase in cost of revenues was primarily due to a proportional increase in sales volume.

[0001408710-23-000028:mdna:122]
Gross profit. Our gross profit increased by $57.2 million, or 25.8%, to $278.6 million, or 12.3% of revenues, for fiscal year 2022, compared with $221.4 million, or 11.8% of revenues, for fiscal year 2021.

[0001408710-23-000028:mdna:123]
SG&A expenses. Our SG&A expenses increased by $3.3 million, or 4.7%, to $73.9 million, or 3.3% of revenues, for fiscal year 2022, compared with $70.6 million, or 3.8% of revenues, for fiscal year 2021. Our SG&A expenses increased during fiscal year 2022, compared with fiscal year 2021, mainly due to (1) an increase in share-based compensation expenses of $2.8 million from an increase in awards of performance share units and restricted share units; (2) a net increase in allowance for doubtful accounts of $1.6 million primarily due to a specific provision set up for one customer in fiscal year 2022; and (3) an increase in executive bonuses of $0.6 million; offset by actuarial gain on obligation of $1.5 million in fiscal year 2022.

[0001408710-23-000028:mdna:124]
Operating income. Our operating income increased by $53.7 million, or 35.6%, to $204.5 million, or 9.0% of revenues, for fiscal year 2022, compared with $150.8 million, or 8.0% of revenues, for fiscal year 2021.

[0001408710-23-000028:mdna:125]
Interest income. Our interest income decreased by $1.6 million to $2.2 million for fiscal year 2022, compared with $3.8 million for fiscal year 2021. The decrease was primarily due to a lower weighted average interest rate in fiscal year 2022 compared with fiscal year 2021.

[0001408710-23-000028:mdna:126]
Interest expense. Our interest expense decreased by $0.7 million to $0.4 million for fiscal year 2022, compared with $1.1 million for fiscal year 2021. The decrease was primarily due to (1) interest expense capitalized to a new manufacturing building at our Chonburi campus of $0.9 million in fiscal year 2022, and (2) lower loan interest expense of $0.2 million in fiscal year 2022; offset by lower amortization of the fair value of interest rate swaps of $0.4 million in fiscal year 2022.

[0001408710-23-000028:mdna:127]
Foreign exchange gain (loss), net. We recorded foreign exchange gain, net of $2.3 million for fiscal year 2022, compared with foreign exchange gain, net of $0.5 million for fiscal year 2021. The increase in foreign exchange gain was mainly due to (1) realized foreign exchange gain from payment/receipt of $1.1 million for fiscal year 2022, as compared to realized foreign exchange loss from payment/receipt of 1.0 million for fiscal year 2021, (2) higher unrealized foreign exchange gain from revaluation of outstanding Thai baht assets and liabilities of $1.6 million, and (3) lower unrealized foreign exchange loss from mark-to-market of forward contracts of $0.7 million, offset by (1) realized foreign exchange loss from subsidiaries in the PRC and the U.K., totaling $1.2 million for fiscal year 2022, as compared to realized foreign exchange gain from subsidiaries in the PRC and the U.K., totaling $1.3 million for fiscal year 2021, and (2) lower unrealized foreign exchange gain from revaluation of other currencies of $0.1 million.

[0001408710-23-000028:mdna:128]
Income before income taxes. We recorded income before income taxes of $207.0 million for fiscal year 2022, compared with $150.5 million for fiscal year 2021.

[0001408710-23-000028:mdna:129]
Income tax expense. Our provision for income tax reflects an effective tax rate of 3.2% and 1.4% for fiscal year 2022 and fiscal year 2021, respectively. The increase was primarily due to higher income subject to tax as well as more income subjected to tax in jurisdictions with higher tax rate in fiscal year 2022, as compared to fiscal year 2021.

[0001408710-23-000028:mdna:130]
Net income. We recorded net income of $200.4 million, or 8.8% of total revenues, for fiscal year 2022, compared with net income of $148.3 million, or 7.9% of total revenues, for fiscal year 2021.

[0001408710-23-000028:mdna:131]
Other comprehensive income (loss). We recorded other comprehensive loss of $6.5 million, or 0.3% of revenues, for fiscal year 2022, compared with other comprehensive loss of $5.1 million, or 0.3% of revenues, for fiscal year 2021. The increase in other comprehensive loss was mainly due to (1) higher unrealized loss from mark-to-market of available-for-sale debt securities of $5.1 million, and (2) unrealized loss from foreign currency translation adjustment of $0.2 million for fiscal year 2022, as compared to unrealized gain from foreign currency translation adjustment of $0.6 million for fiscal year 2021; offset by lower unrealized loss from mark-to-market of forward contracts and interest rate swap agreement of $4.5 million.

[0001408710-23-000028:mdna:132]
Liquidity and Capital Resources

[0001408710-23-000028:mdna:133]
Cash Flows and Working Capital

[0001408710-23-000028:mdna:134]
We primarily finance our operations through cash flow from operating activities. As of June 30, 2023 and June 24, 2022, we had cash, cash equivalents, and short-term investments of $550.5 million and $478.2 million, respectively, and outstanding debt of $12.2 million and $27.4 million, respectively.

[0001408710-23-000028:mdna:135]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted average interest rate on our cash and cash equivalents for fiscal year 2023, fiscal year 2022 and fiscal year 2021 was 2.4%, 0.5% and 0.7%, respectively.

[0001408710-23-000028:mdna:136]
Our cash investments are made in accordance with an investment policy approved by the audit committee of our board of directors. In general, our investment policy requires that securities purchased be rated A1, P-1, F1 or better. No security may have an effective maturity that exceeds three years. Our investments in fixed income securities are primarily classified as available-for-sale and held-to-maturity. Investments in debt securities that we have the positive intent and ability to hold to maturity are carried at amortized cost and classified as held-to-maturity. Investments in debt securities that are not classified as held-to-maturity are carried at fair value and classified as available-for-sale with any unrealized gains and losses included in AOCI in the consolidated balance sheets. We determine realized gains or losses on sale of available-for-sale debt securities on a specific identification method and record such gains or losses as interest income in the consolidated statements of operations and comprehensive income.

[0001408710-23-000028:mdna:137]
As of June 30, 2023 and June 24, 2022, we had long-term borrowing under our credit facility agreement of $12.2 million and $27.4 million, respectively (See Note 13 of the Notes to Consolidated Financial Statements for further details). We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held short-term investments of $319.1 million as of June 30, 2023.

[0001408710-23-000028:mdna:138]
We believe that our current cash and cash equivalents, short-term investments, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months following the filing of this Annual Report on Form 10-K. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Item 1A of this Annual Report on Form 10-K.

[0001408710-23-000028:mdna:139]
We also believe that our current manufacturing capacity is sufficient to meet our anticipated production requirements for at least the next few quarters.

[0001408710-23-000028:mdna:140]
The following table shows our cash flows for the periods indicated:

[0001408710-23-000028:mdna:141]
|  | Years Ended |
| (in thousands) | June 30, 2023 |  | June 24, 2022 |  | June 25, 2021 |
| Net cash provided by operating activities | $ | 213,310 |  |  | $ | 124,246 |  |  | $ | 122,157 |  |
| Net cash used in investing activities | $ | (98,717) |  |  | $ | (135,543) |  |  | $ | (8,934) |  |
| Net cash used in financing activities | $ | (80,984) |  |  | $ | (92,934) |  |  | $ | (42,754) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | 33,609 |  |  | $ | (104,231) |  |  | $ | 70,469 |  |
| Cash, cash equivalents and restricted cash, beginning of period | $ | 198,365 |  |  | $ | 303,123 |  |  | $ | 232,832 |  |
| Cash, cash equivalents and restricted cash, end of period | $ | 231,368 |  |  | $ | 198,365 |  |  | $ | 303,123 |  |

[0001408710-23-000028:mdna:142]
Operating Activities

[0001408710-23-000028:mdna:143]
Cash provided by operating activities is net income adjusted for certain non-cash items and changes in certain assets and liabilities. The increase in cash provided by operating activities for fiscal year 2023 as compared to fiscal year 2022 was primarily driven by higher net income and was also affected by cash-favorable working capital changes.

[0001408710-23-000028:mdna:144]
Investing Activities

[0001408710-23-000028:mdna:145]
Investing cash flows consist primarily of investment purchases, sales, maturities, and disposals; and capital expenditures. Cash used in investing activities was lower for fiscal year 2023 as compared to cash used in investing activities for fiscal year 2022 primarily due to lower capital expenditures and net proceeds from sales and maturities of short-term investments.

[0001408710-23-000028:mdna:146]
Financing Activities

[0001408710-23-000028:mdna:147]
Financing cash flows consist primarily of repayment of long-term debt, share repurchases, and withholding tax related to net share settlement of restricted share units. Cash used in financing activities was lower for fiscal year 2023 as compared to the fiscal year 2022 primarily due to less cash paid for share repurchases and a decrease in withholding tax related to net share settlement of restricted share units, offset by an increase in the repayment of long-term borrowings due to an additional installment from the additional week in the first quarter of fiscal year 2023.

[0001408710-23-000028:mdna:148]
Material Cash Requirements for Contractual Obligations

[0001408710-23-000028:mdna:149]
As of June 30, 2023, we had material cash requirements of $13.5 million including scheduled payments within one year of $13.4 million and after one year of $0.1 million. These material cash requirements consisted of the following contractual and other obligations.

[0001408710-23-000028:mdna:150]
Term Loan and Interest Expenses

[0001408710-23-000028:mdna:151]
As of June 30, 2023, there was $12.2 million outstanding under the term loan that will mature on June 30, 2024 (see Note 13), which only consists of scheduled debt payments within one year of $12.2 million.

[0001408710-23-000028:mdna:152]
Operating Lease

[0001408710-23-000028:mdna:153]
As of June 30, 2023, we have certain operating lease arrangements under which the lease payments are calculated using the straight-line method. Our rental expenses under these leases which will be paid within one year is $1.2 million and after one year is $0.1 million.

[0001408710-23-000028:mdna:154]
Capital Expenditures

[0001408710-23-000028:mdna:155]
The following table sets forth our capital expenditures, which include amounts for which payments have been accrued, for the periods indicated.

[0001408710-23-000028:mdna:156]
|  | Years Ended |
| (in thousands) | June 30, 2023 |  | June 24, 2022 |  | June 25, 2021 |
| Capital expenditures | $ | 66,712 |  |  | $ | 80,462 |  |  | $ | 52,054 |  |

[0001408710-23-000028:mdna:157]
During fiscal year 2023, fiscal year 2022, and fiscal year 2021, we invested in a manufacturing building at our Chonburi campus and continued to purchase equipment to support the expansion of our manufacturing facilities in Thailand, the PRC and Israel. We expect our capital expenditures for fiscal year 2024 to increase compared to fiscal year 2023 mainly due to the purchase of manufacturing equipment to support the expansion of manufacturing facilities and investment in our information technology infrastructure.

[0001408710-23-000028:mdna:158]
Recent Accounting Pronouncements

[0001408710-23-000028:mdna:159]
See Note 2 of the Notes to Consolidated Financial Statements for recent accounting pronouncements that could have an effect on us.
