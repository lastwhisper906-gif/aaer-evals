# FN 8-K — 0001408710-23-000026 filed 2023-08-21

## item codes, every 8-K on or before 2023-08-22

- 2023-08-21 0001408710-23-000026 — 2.02, 5.02, 9.01
- 2023-05-08 0001408710-23-000016 — 2.02, 5.02, 9.01
- 2023-02-06 0001408710-23-000006 — 2.02, 9.01
- 2022-12-13 0001408710-22-000062 — 5.07
- 2022-11-07 0001408710-22-000058 — 2.02, 9.01
- 2022-08-15 0001408710-22-000041 — 2.02, 5.02, 9.01
- 2022-05-02 0001408710-22-000026 — 2.02, 9.01
- 2022-01-31 0001408710-22-000016 — 2.02, 9.01
- 2022-01-19 0001408710-22-000010 — 5.02
- 2022-01-06 0001408710-22-000006 — 5.02
- 2021-12-10 0001408710-21-000051 — 5.07
- 2021-11-01 0001408710-21-000045 — 2.02, 9.01
- 2021-08-16 0001408710-21-000031 — 2.02, 5.02, 9.01
- 2021-05-03 0001408710-21-000019 — 2.02, 9.01
- 2021-02-01 0001408710-21-000008 — 2.02, 9.01
- 2020-12-11 0001193125-20-315861 — 5.07
- 2020-11-02 0001193125-20-283944 — 2.02, 9.01
- 2020-08-17 0001193125-20-222468 — 2.02, 5.02, 9.01
- 2020-05-04 0001193125-20-132426 — 2.02, 9.01
- 2020-02-12 0001193125-20-033191 — 5.02 — amendment of 0001193125-20-022972
- 2020-02-03 0001193125-20-022972 — 2.02, 5.02, 9.01
- 2019-12-13 0001193125-19-313898 — 5.02, 5.07
- 2019-11-04 0001193125-19-283396 — 2.02, 9.01
- 2019-09-12 0001193125-19-243945 — 1.01, 2.01, 2.03, 9.01
- 2019-08-20 0001193125-19-224743 — 5.02, 9.01
- 2019-08-19 0001193125-19-224520 — 2.02, 9.01
- 2019-05-06 0001193125-19-138338 — 2.02, 5.02, 9.01
- 2019-02-28 0001193125-19-057650 — 5.02, 9.01
- 2019-02-04 0001193125-19-027031 — 2.02, 9.01
- 2018-12-14 0001193125-18-349957 — 5.07
- 2018-08-20 0001193125-18-252936 — 2.02, 5.02, 8.01, 9.01
- 2018-06-20 0001193125-18-197919 — 5.02, 8.01
- 2018-06-07 0001193125-18-186122 — 1.01, 2.03, 9.01
- 2018-05-07 0001193125-18-154488 — 2.02, 5.02, 9.01
- 2018-02-05 0001193125-18-032203 — 2.02, 9.01
- 2018-01-16 0001193125-18-011278 — 5.02, 9.01
- 2017-12-15 0001193125-17-370763 — 5.02, 5.07, 9.01
- 2017-11-06 0001193125-17-334331 — 2.02, 9.01
- 2017-09-25 0001193125-17-293052 — 5.02, 9.01
- 2017-08-23 0001193125-17-265638 — 5.02
- 2017-08-21 0001193125-17-263714 — 2.02, 8.01, 9.01
- 2017-05-08 0001193125-17-162642 — 2.02, 9.01
- 2017-02-06 0001193125-17-031868 — 2.02, 5.02, 8.01, 9.01
- 2016-12-16 0001193125-16-795809 — 5.07
- 2016-11-07 0001193125-16-761705 — 2.02, 9.01
- 2016-11-04 0001193125-16-759459 — 5.02, 9.01
- 2016-08-18 0001193125-16-685226 — 5.02, 9.01
- 2016-08-15 0001193125-16-681934 — 2.02, 9.01
- 2016-05-02 0001193125-16-572657 — 2.02, 9.01
- 2016-02-01 0001193125-16-446099 — 2.02, 9.01
- 2015-12-18 0001193125-15-407709 — 5.07
- 2015-11-05 0001193125-15-368266 — 1.01
- 2015-11-02 0001193125-15-362448 — 2.02, 9.01
- 2015-10-01 0001193125-15-335333 — 5.02, 9.01
- 2015-09-09 0001193125-15-315896 — 1.01
- 2015-08-28 0001193125-15-306834 — 5.02
- 2015-08-19 0001193125-15-296096 — 5.02
- 2015-08-17 0001193125-15-293289 — 2.02, 9.01
- 2015-08-05 0001193125-15-278665 — 1.01, 2.03, 9.01
- 2015-05-29 0001193125-15-206635 — 5.02
- 2015-05-04 0001193125-15-169069 — 2.02, 9.01
- 2015-03-02 0001193125-15-073223 — 1.01, 2.03, 9.01
- 2015-02-17 0000950123-15-003303 — 1.01
- 2015-02-12 0001193125-15-046712 — 5.02, 9.01
- 2015-02-02 0001193125-15-029705 — 2.02, 9.01
- 2014-12-23 0001193125-14-452703 — 5.07
- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2023-08-22

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001408710-23-000026:8k_2_02:1]
EX-99.1
2
fn-20230815xex991q423.htm
EX-99.1

[0001408710-23-000026:8k_2_02:2]
Document

[0001408710-23-000026:8k_2_02:3]
Exhibit 99.1

[0001408710-23-000026:8k_2_02:4]
Fabrinet Announces Fourth Quarter and Fiscal Year 2023 Financial Results

[0001408710-23-000026:8k_2_02:5]
•Fourth Quarter Revenue and Earnings Per Share Exceed Guidance

[0001408710-23-000026:8k_2_02:6]
BANGKOK, Thailand – August 21, 2023 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for its fourth quarter and fiscal year ended June 30, 2023.

[0001408710-23-000026:8k_2_02:7]
Seamus Grady, Chief Executive Officer of Fabrinet, said, “We exceeded our guidance for revenue and earnings per share in the fourth quarter. During the quarter we saw very strong growth in datacom revenue, driven by new AI products, which more than offset anticipated headwinds from inventory adjustments at some customers. Our strong fourth quarter results helped produce record performances for revenue, profitability and cash flow in fiscal 2023. As we look to the first quarter of fiscal 2024, we are optimistic that new datacom programs can continue to offset inventory absorption in the industry, and that we can extend our track record of strong execution.”

[0001408710-23-000026:8k_2_02:8]
Fourth Quarter Fiscal Year 2023 Financial Highlights

[0001408710-23-000026:8k_2_02:9]
GAAP Results

[0001408710-23-000026:8k_2_02:10]
•Revenue for the fourth quarter of fiscal year 2023 was $655.9 million, compared to $587.9 million for the fourth quarter of fiscal year 2022.

[0001408710-23-000026:8k_2_02:11]
•GAAP net income for the fourth quarter of fiscal year 2023 was $60.8 million, compared to $56.2 million for the fourth quarter of fiscal year 2022.

[0001408710-23-000026:8k_2_02:12]
•GAAP net income per diluted share for the fourth quarter of fiscal year 2023 was $1.65, compared to $1.51 for the fourth quarter of fiscal year 2022.

[0001408710-23-000026:8k_2_02:13]
Non-GAAP Results

[0001408710-23-000026:8k_2_02:14]
•Non-GAAP net income for the fourth quarter of fiscal year 2023 was $68.4 million, compared to $62.6 million for the fourth quarter of fiscal year 2022.

[0001408710-23-000026:8k_2_02:15]
•Non-GAAP net income per diluted share for the fourth quarter of fiscal year 2023 was $1.86, compared to $1.68 for the fourth quarter of fiscal year 2022.

[0001408710-23-000026:8k_2_02:16]
Fiscal Year 2023 Financial Highlights

[0001408710-23-000026:8k_2_02:17]
GAAP Results

[0001408710-23-000026:8k_2_02:18]
•Revenue for fiscal year 2023 was $2.65 billion, compared to $2.26 billion for fiscal year 2022.

[0001408710-23-000026:8k_2_02:19]
•GAAP net income for fiscal year 2023 was $247.9 million, compared to $200.4 million for fiscal year 2022.

[0001408710-23-000026:8k_2_02:20]
•GAAP net income per diluted share for fiscal year 2023 was $6.73, compared to $5.36 for fiscal year 2022.

[0001408710-23-000026:8k_2_02:21]
Non-GAAP Results

[0001408710-23-000026:8k_2_02:22]
•Non-GAAP net income for fiscal year 2023 was $282.7 million, compared to $229.2 million for fiscal year 2022.

[0001408710-23-000026:8k_2_02:23]
•Non-GAAP net income per diluted share for fiscal year 2023 was $7.67, compared to $6.13 for fiscal year 2022.

[0001408710-23-000026:8k_2_02:24]
Share Repurchase Program Expanded

[0001408710-23-000026:8k_2_02:25]
Fabrinet also announced that its Board of Directors has approved the repurchase of up to an additional $47.6 million of Fabrinet’s ordinary shares, bringing the aggregate authorization under Fabrinet’s existing share repurchase program to $294.8 million, with $100.0 million currently remaining.

[0001408710-23-000026:8k_2_02:26]
Business Outlook

[0001408710-23-000026:8k_2_02:27]
Based on information available as of August 21, 2023, Fabrinet is issuing guidance for its first fiscal quarter ending September 29, 2023, as follows:

[0001408710-23-000026:8k_2_02:28]
•Fabrinet expects first quarter revenue to be in the range of $650 million to $670 million.

[0001408710-23-000026:8k_2_02:29]
•GAAP net income per diluted share is expected to be in the range of $1.60 to $1.67, based on approximately 36.5 million fully diluted shares outstanding.

[0001408710-23-000026:8k_2_02:30]
•Non-GAAP net income per diluted share is expected to be in the range of $1.83 to $1.90, based on approximately 36.5 million fully diluted shares outstanding.

[0001408710-23-000026:8k_2_02:31]
Guidance for non-GAAP net income per diluted share excludes share-based compensation expenses and certain non-recurring items. A reconciliation of non-GAAP net income per diluted share to the corresponding GAAP measure is available at the end of this press release.

[0001408710-23-000026:8k_2_02:32]
Conference Call Information

[0001408710-23-000026:8k_2_02:33]
| What: |  | Fabrinet Fourth Quarter Fiscal Year 2023 Financial Results Call |
| When: |  | August 21, 2023 |
| Time: |  | 5:00 p.m. ET |
| Live Call and Replay: |  | https://investor.fabrinet.com/events-and-presentations/events |

[0001408710-23-000026:8k_2_02:34]
A recorded version of this webcast will be available approximately two hours after the call and accessible at http://investor.fabrinet.com. The webcast will be archived on Fabrinet’s website for a period of one year.

[0001408710-23-000026:8k_2_02:35]
About Fabrinet

[0001408710-23-000026:8k_2_02:36]
Fabrinet is a leading provider of advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, automotive components, medical devices, industrial lasers and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging, integration, final assembly and testing. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the United States of America, the People’s Republic of China and Israel. For more information visit: www.fabrinet.com.

[0001408710-23-000026:8k_2_02:37]
Forward-Looking Statements

[0001408710-23-000026:8k_2_02:38]
Use of Non-GAAP Financials

[0001408710-23-000026:8k_2_02:39]
We refer to the non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding our ongoing operational performance. Non-GAAP net income excludes: share-based compensation expenses; depreciation of fair value uplift; amortization of intangibles; severance payment and others; restructuring and other related costs; and amortization of deferred debt issuance costs. We have excluded these items in order to enhance investors’ understanding of our underlying operations. The use of these non-GAAP financial measures has material limitations because they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial measures.

[0001408710-23-000026:8k_2_02:40]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in making financial and operational decisions. In addition, these non-GAAP financial measures are used to measure company performance for the purposes of determining employee incentive plan compensation.

[0001408710-23-000026:8k_2_02:41]
Investor Contact:

[0001408710-23-000026:8k_2_02:42]
Garo Toomajanian

[0001408710-23-000026:8k_2_02:43]
ir@fabrinet.com

[0001408710-23-000026:8k_2_02:44]
FABRINET

[0001408710-23-000026:8k_2_02:45]
CONSOLIDATED BALANCE SHEETS

[0001408710-23-000026:8k_2_02:46]
| (in thousands of U.S. dollars, except share data and par value) | June 30,2023 |  | June 24,2022 |
|  | (unaudited) |  |  |
| Assets |  |  |  |
| Current assets |  |  |  |
| Cash and cash equivalents | $ | 231,368 |  |  | $ | 197,996 |  |
| Short-term restricted cash | — |  |  | 220 |  |
| Short-term investments | 319,100 |  |  | 280,157 |  |
| Trade accounts receivable, net of allowance for doubtful accounts of $965 and $1,271, respectively | 531,767 |  |  | 452,670 |  |
| Inventories | 519,576 |  |  | 557,145 |  |
| Prepaid expenses | 7,849 |  |  | 11,626 |  |
| Other current assets | 42,880 |  |  | 25,357 |  |
| Total current assets | 1,652,540 |  |  | 1,525,171 |  |
| Non-current assets |  |  |  |
| Long-term restricted cash | — |  |  | 149 |  |
| Property, plant and equipment, net | 310,350 |  |  | 292,277 |  |
| Intangibles, net | 2,394 |  |  | 3,508 |  |
| Operating right-of-use assets | 1,634 |  |  | 4,084 |  |
| Deferred tax assets | 12,095 |  |  | 9,800 |  |
| Other non-current assets | 635 |  |  | 652 |  |
| Total non-current assets | 327,108 |  |  | 310,470 |  |
| Total Assets | $ | 1,979,648 |  |  | $ | 1,835,641 |  |
| Liabilities and Shareholders’ Equity |  |  |  |
| Current liabilities |  |  |  |
| Long-term borrowings, current portion, net | $ | 12,156 |  |  | $ | 12,156 |  |
| Trade accounts payable | 381,129 |  |  | 439,684 |  |
| Fixed assets payable | 13,526 |  |  | 9,085 |  |
| Operating lease liabilities, current portion | 1,201 |  |  | 2,319 |  |
| Income tax payable | 6,024 |  |  | 2,898 |  |
| Accrued payroll, bonus and related expenses | 23,748 |  |  | 20,374 |  |
| Accrued expenses | 20,447 |  |  | 24,758 |  |
| Other payables | 23,654 |  |  | 27,213 |  |
| Total current liabilities | 481,885 |  |  | 538,487 |  |
| Non-current liabilities |  |  |  |
| Long-term borrowings, non-current portion, net | — |  |  | 15,202 |  |
| Deferred tax liability | 4,799 |  |  | 6,001 |  |
| Operating lease liabilities, non-current portion | 66 |  |  | 1,476 |  |
| Severance liabilities | 22,159 |  |  | 18,384 |  |
| Other non-current liabilities | 2,081 |  |  | 2,409 |  |
| Total non-current liabilities | 29,105 |  |  | 43,472 |  |
| Total Liabilities | 510,990 |  |  | 581,959 |  |
| Shareholders’ equity |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of June 30, 2023 and June 24, 2022) | — |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 39,284,176 shares and 39,048,700 shares issued as of June 30, 2023 and June 24, 2022, respectively; and 36,183,682 shares and 36,436,683 shares outstanding as of June 30, 2023 and June 24, 2022, respectively) | 393 |  |  | 390 |  |
| Additional paid-in capital | 206,624 |  |  | 196,667 |  |
| Less: Treasury shares (3,100,494 shares and 2,612,017 shares as of June 30, 2023 and June 24, 2022, respectively) | (194,833) |  |  | (147,258) |  |
| Accumulated other comprehensive income (loss) | (8,115) |  |  | (12,793) |  |
| Retained earnings | 1,464,589 |  |  | 1,216,676 |  |
| Total Shareholders’ Equity | 1,468,658 |  |  | 1,253,682 |  |
| Total Liabilities and Shareholders’ Equity | $ | 1,979,648 |  |  | $ | 1,835,641 |  |

[0001408710-23-000026:8k_2_02:47]
FABRINET

[0001408710-23-000026:8k_2_02:48]
CONSOLIDATED STATEMENTS OF OPERATIONS AND COMPREHENSIVE INCOME

[0001408710-23-000026:8k_2_02:49]
|  | Three Months Ended |  | Year Ended |
| (in thousands of U.S. dollars, except per share data) | June 30,2023 |  | June 24,2022 |  | June 30,2023 |  | June 24,2022 |
|  | (unaudited) |  | (unaudited) |  | (unaudited) |  |  |
| Revenues | $ | 655,871 |  |  | $ | 587,874 |  |  | $ | 2,645,237 |  |  | $ | 2,262,224 |  |
| Cost of revenues | (573,576) |  |  | (512,941) |  |  | (2,308,964) |  |  | (1,983,630) |  |
| Gross profit | 82,295 |  |  | 74,933 |  |  | 336,273 |  |  | 278,594 |  |
| Selling, general and administrative expenses | (19,869) |  |  | (18,529) |  |  | (77,673) |  |  | (73,941) |  |
| Restructuring and other related costs | (1,024) |  |  | — |  |  | (6,896) |  |  | (135) |  |
| Operating income | 61,402 |  |  | 56,404 |  |  | 251,704 |  |  | 204,518 |  |
| Interest income | 4,024 |  |  | 735 |  |  | 11,234 |  |  | 2,205 |  |
| Interest expense | (293) |  |  | (85) |  |  | (1,472) |  |  | (432) |  |
| Foreign exchange gain (loss), net | 1,911 |  |  | 1,304 |  |  | (1,211) |  |  | 2,302 |  |
| Other income (expense), net | 19 |  |  | (276) |  |  | (159) |  |  | (1,627) |  |
| Income before income taxes | 67,063 |  |  | 58,082 |  |  | 260,096 |  |  | 206,966 |  |
| Income tax expense | (6,277) |  |  | (1,893) |  |  | (12,183) |  |  | (6,586) |  |
| Net income | 60,786 |  |  | 56,189 |  |  | 247,913 |  |  | 200,380 |  |
| Other comprehensive income (loss), net of tax |  |  |  |  |  |  |  |
| Change in net unrealized gain (loss) on available-for-sale securities | 971 |  |  | (2,711) |  |  | 2,739 |  |  | (6,326) |  |
| Change in net unrealized gain (loss) on derivative instruments | (2,894) |  |  | (3,321) |  |  | 1,541 |  |  | (578) |  |
| Change in net retirement benefits plan – prior service cost | 135 |  |  | 174 |  |  | 473 |  |  | 622 |  |
| Change in foreign currency translation adjustment | (46) |  |  | (47) |  |  | (75) |  |  | (245) |  |
| Total other comprehensive income (loss), net of tax | (1,834) |  |  | (5,905) |  |  | 4,678 |  |  | (6,527) |  |
| Net comprehensive income | $ | 58,952 |  |  | $ | 50,284 |  |  | $ | 252,591 |  |  | $ | 193,853 |  |
| Earnings per share |  |  |  |  |  |  |  |
| Basic | $ | 1.67 |  |  | $ | 1.53 |  |  | $ | 6.79 |  |  | $ | 5.43 |  |
| Diluted | $ | 1.65 |  |  | $ | 1.51 |  |  | $ | 6.73 |  |  | $ | 5.36 |  |
| Weighted-average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |
| Basic | 36,337 |  |  | 36,668 |  |  | 36,515 |  |  | 36,876 |  |
| Diluted | 36,737 |  |  | 37,222 |  |  | 36,855 |  |  | 37,394 |  |

[0001408710-23-000026:8k_2_02:50]
FABRINET

[0001408710-23-000026:8k_2_02:51]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001408710-23-000026:8k_2_02:52]
|  | Year Ended |
| (in thousands of U.S. dollars) | June 30,2023 |  | June 24,2022 |
|  | (unaudited) |  |  |
| Cash flows from operating activities |  |  |  |
| Net income | $ | 247,913 |  |  | $ | 200,380 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |
| Depreciation and amortization | 43,832 |  |  | 38,738 |  |
| Non-cash restructuring charges and other related costs | 2,201 |  |  | — |  |
| (Gain) loss on disposal and impairment of property, plant and equipment | (1,506) |  |  | (101) |  |
| (Gain) loss from sales and maturities of available-for-sale securities | 92 |  |  | 13 |  |
| Amortization of discount (premium) of short-term investments | 280 |  |  | 3,691 |  |
| Amortization of deferred debt issuance costs | 31 |  |  | 32 |  |
| (Reversal of) allowance for doubtful accounts | (307) |  |  | 1,171 |  |
| Unrealized loss (gain) on exchange rate and fair value of foreign currency forward contracts | 175 |  |  | (2,832) |  |
| Amortization of fair value at hedge inception of interest rate swaps | (587) |  |  | (937) |  |
| Share-based compensation | 28,127 |  |  | 28,048 |  |
| Deferred income tax | (3,484) |  |  | (191) |  |
| Other non-cash expenses | 601 |  |  | 1,390 |  |
| Changes in operating assets and liabilities |  |  |  |
| Trade accounts receivable | (76,917) |  |  | (105,550) |  |
| Inventories | 37,449 |  |  | (135,011) |  |
| Other current assets and non-current assets | (13,568) |  |  | (6,430) |  |
| Trade accounts payable | (58,596) |  |  | 93,499 |  |
| Income tax payable | 2,977 |  |  | (761) |  |
| Severance liabilities | 3,753 |  |  | 1,033 |  |
| Other current liabilities and non-current liabilities | 844 |  |  | 8,064 |  |
| Net cash provided by operating activities | 213,310 |  |  | 124,246 |  |
| Cash flows from investing activities |  |  |  |
| Purchase of short-term investments | (217,005) |  |  | (198,318) |  |
| Proceeds from sales of short-term investments | 30,179 |  |  | 19,463 |  |
| Proceeds from maturities of short-term investments | 150,252 |  |  | 133,632 |  |
| Purchase of property, plant and equipment | (61,360) |  |  | (89,588) |  |
| Purchase of intangibles | (911) |  |  | (995) |  |
| Proceeds from disposal of property, plant and equipment | 128 |  |  | 263 |  |
| Net cash used in investing activities | (98,717) |  |  | (135,543) |  |
| Cash flows from financing activities |  |  |  |
| Repayment of long-term borrowings | (15,233) |  |  | (12,188) |  |
| Repayment of finance lease liability | (9) |  |  | (7) |  |
| Repurchase of ordinary shares | (47,575) |  |  | (59,915) |  |
| Withholding tax related to net share settlement of restricted share units | (18,167) |  |  | (20,824) |  |
| Net cash used in financing activities | (80,984) |  |  | (92,934) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | 33,609 |  |  | $ | (104,231) |  |
| Movement in cash, cash equivalents and restricted cash |  |  |  |
| Cash, cash equivalents and restricted cash at the beginning of period | $ | 198,365 |  |  | $ | 303,123 |  |
| Increase (decrease) in cash, cash equivalents and restricted cash | 33,609 |  |  | (104,231) |  |
| Effect of exchange rate on cash, cash equivalents and restricted cash | (606) |  |  | (527) |  |
| Cash, cash equivalents and restricted cash at the end of period | $ | 231,368 |  |  | $ | 198,365 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment related payables | $ | 13,526 |  |  | $ | 9,085 |  |

[0001408710-23-000026:8k_2_02:53]
FABRINET

[0001408710-23-000026:8k_2_02:54]
CONSOLIDATED STATEMENTS OF CASH FLOWS (Continued)

[0001408710-23-000026:8k_2_02:55]
| Supplemental disclosures | Year Ended |
| (in thousands of U.S. dollars) | June 30,2023 |  | June 24,2022 |
|  | (unaudited) |  |  |
| Cash paid for |  |  |  |
| Interest | $ | 2,377 |  |  | $ | 2,244 |  |
| Taxes | $ | 14,158 |  |  | $ | 9,296 |  |
| Cash received for interest | $ | 11,048 |  |  | $ | 1,603 |  |
| Non-cash investing and financing activities |  |  |  |
| Construction, software and equipment related payables | $ | 13,526 |  |  | $ | 9,085 |  |

[0001408710-23-000026:8k_2_02:56]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the consolidated balance sheets that sum to the total of the same amounts shown in the consolidated statements of cash flows:

[0001408710-23-000026:8k_2_02:57]
|  | As of |
| (in thousands of U.S. dollars) | June 30,2023 |  | June 24,2022 |
|  | (unaudited) |  |  |
| Cash and cash equivalents | $ | 231,368 |  |  | $ | 197,996 |  |
| Restricted cash | — |  |  | 369 |  |
| Cash, cash equivalents and restricted cash | $ | 231,368 |  |  | $ | 198,365 |  |

[0001408710-23-000026:8k_2_02:58]
FABRINET

[0001408710-23-000026:8k_2_02:59]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES (UNAUDITED)

[0001408710-23-000026:8k_2_02:60]
|  | Three Months Ended |  | Year Ended |
|  | June 30,2023 |  | June 24,2022 |  | June 30,2023 |  | June 24,2022 |
| (in thousands of U.S. dollars, except share data) | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |  | Net income |  | Diluted EPS |
| GAAP measures | $ | 60,786 |  |  | $ | 1.65 |  |  | $ | 56,189 |  |  | $ | 1.51 |  |  | $ | 247,913 |  |  | $ | 6.73 |  |  | $ | 200,380 |  |  | $ | 5.36 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 1,636 |  |  | 0.05 |  |  | 1,388 |  |  | 0.04 |  |  | 6,664 |  |  | 0.18 |  |  | 5,967 |  |  | 0.16 |  |
| Depreciation of fair value uplift | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 92 |  |  | 0.00 |  |
| Total related to gross profit | 1,636 |  |  | 0.05 |  |  | 1,388 |  |  | 0.04 |  |  | 6,664 |  |  | 0.18 |  |  | 6,059 |  |  | 0.16 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses | 4,936 |  |  | 0.13 |  |  | 4,959 |  |  | 0.13 |  |  | 20,939 |  |  | 0.57 |  |  | 22,081 |  |  | 0.59 |  |
| Amortization of intangibles | — |  |  | — |  |  | 94 |  |  | 0.00 |  |  | 224 |  |  | 0.01 |  |  | 422 |  |  | 0.01 |  |
| Severance payment and others | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 105 |  |  | 0.00 |  |
| Total related to selling, general and administrative expenses | 4,936 |  |  | 0.13 |  |  | 5,053 |  |  | 0.13 |  |  | 21,163 |  |  | 0.58 |  |  | 22,608 |  |  | 0.60 |  |
| Related to other income and expense: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Restructuring and other related costs | 1,024 |  |  | 0.03 |  |  | — |  |  | — |  |  | 6,896 |  |  | 0.18 |  |  | 135 |  |  | 0.01 |  |
| Amortization of deferred debt issuance costs | 8 |  |  | 0.00 |  |  | 8 |  |  | 0.00 |  |  | 32 |  |  | 0.00 |  |  | 32 |  |  | 0.00 |  |
| Total related to other income and expense | 1,032 |  |  | 0.03 |  |  | 8 |  |  | 0.00 |  |  | 6,928 |  |  | 0.18 |  |  | 167 |  |  | 0.01 |  |
| Total related to net income & EPS | 7,604 |  |  | 0.21 |  |  | 6,449 |  |  | 0.17 |  |  | 34,755 |  |  | 0.94 |  |  | 28,834 |  |  | 0.77 |  |
| Non-GAAP measures | $ | 68,390 |  |  | $ | 1.86 |  |  | $ | 62,638 |  |  | $ | 1.68 |  |  | $ | 282,668 |  |  | $ | 7.67 |  |  | $ | 229,214 |  |  | $ | 6.13 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  | 36,737 |  |  |  |  | 37,222 |  |  |  |  | 36,855 |  |  |  |  | 37,394 |  |
| Non-GAAP diluted shares |  |  | 36,737 |  |  |  |  | 37,222 |  |  |  |  | 36,855 |  |  |  |  | 37,394 |  |

[0001408710-23-000026:8k_2_02:61]
FABRINET

[0001408710-23-000026:8k_2_02:62]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES TO FREE CASH FLOW (UNAUDITED)

[0001408710-23-000026:8k_2_02:63]
| (in thousands of U.S. dollars) |  | Three Months Ended |  | Year Ended |
|  |  | June 30,2023 |  | June 24,2022 |  | June 30,2023 |  | June 24,2022 |
| Net cash provided by operating activities |  | $ | 71,088 |  |  | $ | 16,349 |  |  | $ | 213,310 |  |  | $ | 124,246 |  |
| Less: Purchase of property, plant and equipment |  | (17,938) |  |  | (14,261) |  |  | (61,360) |  |  | (89,588) |  |
| Non-GAAP free cash flow |  | $ | 53,150 |  |  | $ | 2,088 |  |  | $ | 151,950 |  |  | $ | 34,658 |  |

[0001408710-23-000026:8k_2_02:64]
FABRINET

[0001408710-23-000026:8k_2_02:65]
GUIDANCE FOR QUARTER ENDING SEPTEMBER 29, 2023

[0001408710-23-000026:8k_2_02:66]
RECONCILIATION OF GAAP MEASURES TO NON-GAAP MEASURES

[0001408710-23-000026:8k_2_02:67]
|  | DilutedEPS |
| GAAP net income per diluted share: | $1.60 to $1.67 |
| Related to cost of revenues: |  |
| Share-based compensation expenses | 0.07 |
| Total related to gross profit | 0.07 |
| Related to selling, general and administrative expenses: |  |
| Share-based compensation expenses | 0.16 |
| Total related to selling, general and administrative expenses | 0.16 |
| Total related to net income & EPS | 0.23 |
| Non-GAAP net income per diluted share | $1.83 to $1.90 |

## item 5.02 — body, verbatim

[0001408710-23-000026:8k_body:1]
Item 5.02    Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001408710-23-000026:8k_body:2]
Fiscal 2024 Executive Incentive Plan

[0001408710-23-000026:8k_body:3]
On August 15, 2023, the Compensation Committee (the “Compensation Committee”) of the board of directors of Fabrinet adopted an executive incentive plan (the “Cash Bonus Plan”) for the Company’s fiscal year ending June 28, 2024 (“fiscal 2024”). The Cash Bonus Plan is an incentive program designed to motivate participants to achieve the Company’s financial objectives, and to reward them for their achievements when those objectives are met. All of the Company’s executive officers pursuant to Section 16 of the Exchange Act are eligible to participate in the Cash Bonus Plan (individually, a “Participant,” and collectively, the “Participants”). The Cash Bonus Plan provides for target and maximum bonus amounts as set forth in the table below. The maximum bonus that a Participant may receive under the Cash Bonus Plan is 120% of such Participant’s target bonus.

[0001408710-23-000026:8k_body:4]
Name

[0001408710-23-000026:8k_body:5]
Fiscal 2024 Target Bonus

[0001408710-23-000026:8k_body:6]
Fiscal 2024 Maximum Bonus

[0001408710-23-000026:8k_body:7]
Seamus Grady

[0001408710-23-000026:8k_body:8]
$1,625,000

[0001408710-23-000026:8k_body:9]
$1,950,000

[0001408710-23-000026:8k_body:10]
Dr. Harpal Gill

[0001408710-23-000026:8k_body:11]
$1,378,000

[0001408710-23-000026:8k_body:12]
$1,653,600

[0001408710-23-000026:8k_body:13]
Csaba Sverha

[0001408710-23-000026:8k_body:14]
$501,500

[0001408710-23-000026:8k_body:15]
$601,800

[0001408710-23-000026:8k_body:16]
Edward Archer

[0001408710-23-000026:8k_body:17]
$408,000

[0001408710-23-000026:8k_body:18]
$489,600

[0001408710-23-000026:8k_body:19]
The amount of bonus actually paid to a Participant under the Cash Bonus Plan will be based 50% on the extent of achievement of a fiscal 2024 revenue metric and 50% on the extent of achievement of a fiscal 2024 non-GAAP operating margin metric. As achievement of each financial metric is considered independently from the other, the Company must meet a threshold for each metric in order for a Participant to receive any credit for that metric. If the Company achieves 100% of a target financial metric, bonuses would be paid out at 100% of the target amount with respect to that financial metric component. If the Company achieves 105% or more of a target financial metric, bonuses would be paid out at 120% of the target amount (which is the maximum) with respect to that financial metric component. Achievement of the revenue or non-GAAP operating margin metric for fiscal 2024 at a level between 100% and 105% of the target metric will result in a bonus amount for the applicable metric that is scaled from 100% to 120% of the target amount in a linear fashion. Achievement of the revenue or non-GAAP operating margin metric for fiscal 2024 at a level between 90% and 100% of the target metric will result in a bonus amount for the applicable metric that is scaled from 20% to 100% of the target amount in a linear fashion.

[0001408710-23-000026:8k_body:20]
Fiscal 2024 Salaries

[0001408710-23-000026:8k_body:21]
On August 15, 2023, the Compensation Committee approved an increase to the annual base salaries of the Company’s named executive officers set forth below, effective as of July 1, 2023, the first day of fiscal 2024.

[0001408710-23-000026:8k_body:22]
Name

[0001408710-23-000026:8k_body:23]
Title

[0001408710-23-000026:8k_body:24]
Previous Annual Base Salary

[0001408710-23-000026:8k_body:25]
Fiscal 2024 Annual Base Salary

[0001408710-23-000026:8k_body:26]
Change

[0001408710-23-000026:8k_body:27]
Seamus Grady

[0001408710-23-000026:8k_body:28]
Chief Executive Officer

[0001408710-23-000026:8k_body:29]
$1,150,000

[0001408710-23-000026:8k_body:30]
$1,250,000

[0001408710-23-000026:8k_body:31]
8.7%

[0001408710-23-000026:8k_body:32]
Dr. Harpal Gill

[0001408710-23-000026:8k_body:33]
President and Chief Operating Officer

[0001408710-23-000026:8k_body:34]
$1,040,300

[0001408710-23-000026:8k_body:35]
$1,060,000

[0001408710-23-000026:8k_body:36]
1.9%

[0001408710-23-000026:8k_body:37]
Csaba Sverha

[0001408710-23-000026:8k_body:38]
Executive Vice President, Chief Financial Officer

[0001408710-23-000026:8k_body:39]
$575,000

[0001408710-23-000026:8k_body:40]
$590,000

[0001408710-23-000026:8k_body:41]
2.6%

[0001408710-23-000026:8k_body:42]
Edward Archer

[0001408710-23-000026:8k_body:43]
Executive Vice President, Sales & Marketing

[0001408710-23-000026:8k_body:44]
$500,000

[0001408710-23-000026:8k_body:45]
$510,000

[0001408710-23-000026:8k_body:46]
2.0%

[0001408710-23-000026:8k_body:47]
Equity Award Grants

[0001408710-23-000026:8k_body:48]
On August 15, 2023, the Compensation Committee approved the grant, effective as of August 24, 2023 (the “Grant Date”), of the following dollar values of restricted share units (“RSUs”), performance share units (“PSUs”) and “stretch” PSUs (“Stretch PSUs”), rounded down to the nearest whole share, to the Company’s named executive officers as a component of their fiscal 2023 compensation:

[0001408710-23-000026:8k_body:49]
Name

[0001408710-23-000026:8k_body:50]
Grant Date Value of RSUs

[0001408710-23-000026:8k_body:51]
Grant Date Value of PSUs

[0001408710-23-000026:8k_body:52]
Grant Date Value of “Stretch” PSUs

[0001408710-23-000026:8k_body:53]
Seamus Grady

[0001408710-23-000026:8k_body:54]
$2,600,000

[0001408710-23-000026:8k_body:55]
$2,600,000

[0001408710-23-000026:8k_body:56]
$2,600,000

[0001408710-23-000026:8k_body:57]
Dr. Harpal Gill

[0001408710-23-000026:8k_body:58]
$1,625,000

[0001408710-23-000026:8k_body:59]
$1,625,000

[0001408710-23-000026:8k_body:60]
$1,625,000

[0001408710-23-000026:8k_body:61]
Csaba Sverha

[0001408710-23-000026:8k_body:62]
$900,000

[0001408710-23-000026:8k_body:63]
$900,000

[0001408710-23-000026:8k_body:64]
$900,000

[0001408710-23-000026:8k_body:65]
Edward Archer

[0001408710-23-000026:8k_body:66]
$750,000

[0001408710-23-000026:8k_body:67]
$750,000

[0001408710-23-000026:8k_body:68]
$750,000

[0001408710-23-000026:8k_body:69]
The grants will be made under the Company’s 2020 Equity Incentive Plan. The RSUs will be scheduled to vest in equal annual installments over a period of three years on each anniversary of the Grant Date, subject to the individual’s continued service with the Company through each such vesting date.

[0001408710-23-000026:8k_body:70]
The PSUs will vest, if at all, following a 2-year performance period, on the date the Compensation Committee certifies achievement of the performance criteria set forth below, subject to the individual’s continued service with the Company through such vesting date. Vesting of the PSUs will be based 50% on achievement of a cumulative fiscal 2024 and fiscal 2025 revenue goal (the “PSU Revenue Target”) and 50% on achievement of a cumulative fiscal 2024 and fiscal 2025 non-GAAP operating margin goal (the “PSU Operating Margin Target”). As achievement of each financial goal is considered independently from the other, the Company must meet a threshold for each goal in order for an individual to receive any credit for that goal. If the Company achieves 100% or more of a target financial goal, the PSUs will vest as to 100% of the PSUs allocated to that financial goal. Achievement of the PSU Revenue Target or the PSU Operating Margin Target at a level between 90% and 100% will result in a number of shares vesting for the applicable goal that is scaled from 20% to 100% of the PSUs allocated to that goal in a linear fashion.

[0001408710-23-000026:8k_body:71]
The Stretch PSUs will vest, if at all, following a 2-year performance period, on the date the Compensation Committee certifies achievement of the performance criteria set forth below, subject to the individual’s continued service with the Company through such vesting date. Vesting of the Stretch PSUs will be based 50% on achievement of a cumulative fiscal 2024 and fiscal 2025 revenue goal that is 5% higher than the PSU Revenue Target (the “Stretch PSU Revenue Target”) and 50% on achievement of a cumulative fiscal 2024 and fiscal 2025 non-GAAP operating margin goal that is 5% higher than the PSU Operating Margin Target (the “Stretch PSU Operating Margin Target”). As achievement of each financial goal is considered independently from the other, the Company must meet a threshold for each goal in order for an individual to receive any credit for that goal. The Company must exceed the PSU Revenue Target or the PSU Operating Margin Target in order for any of the Stretch PSUs to vest. If the Company achieves 100% or more of a target financial goal, the Stretch PSUs will vest as to 100% of the PSUs allocated to that financial goal. Achievement of the Stretch PSU Revenue Target at a level between its threshold PSU Revenue Target and 100% will result in a number of shares vesting for that goal that is scaled from 0% to 100% of the PSUs allocated to that goal in a linear fashion. Achievement of the Stretch PSU Operating Margin Target at a level between its threshold PSU Operating Margin Target and 100% will result in a number of shares vesting for that goal that is scaled from 0% to 100% of the PSUs allocated to that goal in a linear fashion.

[0001408710-23-000026:8k_body:72]
In the event of a change in control of Fabrinet, the awards of PSUs and Stretch PSUs described above that are then outstanding will be treated as follows. To the extent that the performance period has not yet been completed as of the change in control, (1) the performance period for any Company revenue goals will be shortened to end shortly before the change in control and achievement of revenue will be measured based on goals that are prorated for the shortened performance period, and (2) the performance period for any Company operating margin goals will be deemed to be the last four consecutive fiscal quarters of the Company completed before the change in control. Any PSUs for which such applicable goal is deemed achieved will be scheduled to vest subject to the individual’s continued service with Fabrinet through the last date of the award’s original performance period, and will be treated as a time-based award that may be eligible for certain vesting acceleration under Mr. Grady’s Change in Control and Severance Agreement or the Fabrinet Executive Change in Control and Severance Plan, as applicable, upon a qualifying termination during a specified change in control period.
