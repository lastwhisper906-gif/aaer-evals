# FN note change history — 0001193125-14-184830 → 0001193125-14-398478


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-11-05):
[0001193125-14-398478:note_history:1]
| 13. | Commitments and contingencies |
  (was, 2014-05-06, similarity 0.9737):
[0001193125-14-184830:note_history:1]
| 12. |  | Commitments and contingencies |

- changed (2014-11-05):
[0001193125-14-398478:note_history:2]
As of
 September 26, 2014 and June 27, 2014, there were
 outstanding bank guarantees given by banks on behalf of Fabrinet
 Thailand for electricity usage and other normal business amounting
 to $0.8 million and $0.3 million, respectively.
  (was, 2014-05-06, similarity 0.9353):
[0001193125-14-184830:note_history:2]
As of
 March 28, 2014 and June 28, 2013, there were outstanding
 bank guarantees given by banks on behalf of Fabrinet Thailand for
 electricity usage and other normal business amounting to $322 and
 $336, respectively.

- changed (2014-11-05):
[0001193125-14-398478:note_history:3]
The Company
 leases a portion of its capital equipment and certain land and
 buildings for its facilities in China and New Jersey under
 operating lease arrangements that expire in various calendar years
 through 2020. Rental expense under these operating leases amounted
 to $0.2 million and $0.2 million for the three months ended
 September 26, 2014 and September 27, 2013,
 respectively.
  (was, 2014-05-06, similarity 0.8147):
[0001193125-14-184830:note_history:3]
The Company
 leases a portion of certain land and buildings for its facilities
 in China and New Jersey, under operating lease arrangements that
 expire in various calendar years through 2020. Rental expense under
 these operating leases amounted to $667 and $585 for the nine
 months ended March 28, 2014 and March 29, 2013,
 respectively.

- changed (2014-11-05):
[0001193125-14-398478:note_history:4]
As of
 September 26, 2014, the future minimum lease payments due
 under non-cancelable leases are as follows at the end of each
 fiscal year below:
  (was, 2014-05-06, similarity 0.9524):
[0001193125-14-184830:note_history:4]
As of
 March 28, 2014, the future minimum lease payments due under
 non-cancelable leases were as follows at the end of each fiscal
 year below:

- changed (2014-11-05):
[0001193125-14-398478:note_history:5]
| (amount in thousands) |  |  |  |
| 2015 |  | $ | 741 |  |
| 2016 |  |  | 943 |  |
| 2017 |  |  | 928 |  |
| 2018 |  |  | 928 |  |
| 2019 |  |  | 441 |  |
| Thereafter |  |  | 279 |  |
| Total minimum operating lease payments |  | $ | 4,260 |  |
  (was, 2014-05-06, similarity 0.9034):
[0001193125-14-184830:note_history:5]
| 2014 |  |  | 247 |  |
| 2015 |  |  | 989 |  |
| 2016 |  |  | 943 |  |
| 2017 |  |  | 928 |  |
| 2018 |  |  | 928 |  |
| Thereafter |  |  | 720 |  |
| Total minimum operating lease payments |  | $ | 4,755 |  |

- changed (2014-11-05):
[0001193125-14-398478:note_history:6]
As of
 September 26, 2014, there were no outstanding capital
 expenditure commitments.
  (was, 2014-05-06, similarity 0.9342):
[0001193125-14-184830:note_history:6]
As of
 March 28, 2014, there were no outstanding capital expenditure
 commitments.

- removed (2014-11-05):
[0001193125-14-184830:note_history:7]
Contingent
 liability

- removed (2014-11-05):
[0001193125-14-184830:note_history:8]
In the first
 week of October 2013, the Company authorized a customer to return a
 number of units of its product manufactured at the Company’s
 Pinehurst facility, due to functional failure. After investigation,
 the Company found that the affected products were produced during
 the first quarter of fiscal 2014. On March 28, 2014, the
 Company entered into a settlement agreement with the customer for
 the losses as a result of the product failure. The settled amount
 was $487 and recorded in the nine months ended March 28,
 2014.


## us-gaap:BasisOfPresentationAndSignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-11-05):
[0001193125-14-398478:note_history:9]
| 2. | Accounting policies |
  (was, 2014-05-06, similarity 0.9643):
[0001193125-14-184830:note_history:9]
| 2. |  | Accounting policies |

- changed (2014-11-05):
[0001193125-14-398478:note_history:10]
The condensed
 consolidated financial statements of Fabrinet included herein have
 been prepared on a basis consistent with the June 27, 2014
 audited consolidated financial statements and include all material
 adjustments, consisting of normal recurring adjustments, necessary
 to fairly present the information set forth therein. These
 condensed consolidated financial statements should be read in
 conjunction with the June 27, 2014 audited consolidated
 financial statements and notes thereto. The year-end condensed
 balance sheet data was derived from audited financial statements
 but does not include all disclosures required by accounting
 principles generally accepted in the United States (“U.S.
 GAAP”).
  (was, 2014-05-06, similarity 0.9921):
[0001193125-14-184830:note_history:10]
The condensed
 consolidated financial statements of Fabrinet included herein have
 been prepared on a basis consistent with the June 28, 2013
 audited consolidated financial statements and include all material
 adjustments, consisting of normal recurring adjustments, necessary
 to fairly present the information set forth therein. These
 condensed consolidated financial statements should be read in
 conjunction with the June 28, 2013 audited consolidated
 financial statements and notes thereto. The year-end condensed
 balance sheet data was derived from audited financial statements
 but does not include all disclosures required by accounting
 principles generally accepted in the United States of America
 (“U.S. GAAP”).

- changed (2014-11-05):
[0001193125-14-398478:note_history:11]
The preparation
 of the Company’s condensed consolidated financial statements
 in conformity with U.S. GAAP requires management to make estimates
 and assumptions that affect the reported amounts of assets and
 liabilities and disclosure of contingent liabilities at the date of
 the financial statements, and the reported amount of total revenues
 and expense during the year. The Company bases estimates on
 historical experience and various assumptions about the future that
 are believed to be reasonable based on available information. The
 Company’s reported financial position or results of
 operations may be materially different under different conditions
 or when using different estimates and assumptions, particularly
 with respect to significant accounting policies, which are
 discussed below. Significant assumptions are used in accounting for
 share-based compensation, allowance for doubtful accounts, income
 taxes, and inventory obsolescence, among others. Due to the
 inherent uncertainty involved in making estimates, actual results
 reported in future periods may be different from these estimates.
 In the event that estimates or assumptions prove to differ from
 actual results, adjustments will be made in subsequent periods to
 reflect more current information.
  (was, 2014-05-06, similarity 0.7343):
[0001193125-14-184830:note_history:11]
The preparation
 of the Company’s condensed consolidated financial statements
 in conformity with U.S. GAAP requires management to make estimates
 and assumptions that affect the reported amounts of assets and
 liabilities and disclosure of contingent liabilities at the date of
 the financial statements, and the reported amount of total revenues
 and expense during the year. The Company bases estimates on
 historical experience and various assumptions about the future that
 are believed to be reasonable based on available information. The
 Company’s reported financial position or results of
 operations may be materially different under different conditions
 or when using different estimates and assumptions, particularly
 with respect to significant accounting policies, which are
 discussed below. Significant assumptions are used in accounting for
 share-based compensation, allowance for doubtful accounts, income
 taxes and inventory obsolescence, among others. Due to the inherent
 uncertainty involved in making estimates, actual results reported
 in future periods may be different from these estimates. In the
 event that estimates or assumptions prove to differ from actual
 results, adjustments will be made in subsequent periods to reflect
 more current information.

- changed (2014-11-05):
[0001193125-14-398478:note_history:12]
The Company
 utilizes a 52-53 week fiscal year ending on the Friday in June
 closest to June 30. The three months ended September 26,
 2014 and September 27, 2013 each consisted of 13 weeks. Fiscal
 year 2015 will be comprised of 52 weeks and will end on
 June 26, 2015.
  (was, 2014-05-06, similarity 0.7817):
[0001193125-14-184830:note_history:12]
The Company
 utilizes a 52-53 week fiscal year ending on the Friday in June
 closest to June 30. The three months ended March 28, 2014
 and March 29, 2013 each consisted of 13 weeks. The nine months
 ended March 28, 2014 and March 29, 2013 each consisted of
 39 weeks. Fiscal year 2014 will be comprised of 52 weeks and will
 end on June 27, 2014.

- changed (2014-11-05):
[0001193125-14-398478:note_history:13]
Financial
 instruments that potentially subject the Company to concentrations
 of credit risk consist of cash and cash equivalents, derivatives
 and accounts receivable.
  (was, 2014-05-06, similarity 0.9592):
[0001193125-14-184830:note_history:13]
Financial
 instruments that potentially subject the Company to concentrations
 of credit risk consist of cash and cash equivalents and accounts
 receivable.

- added (2014-11-05):
[0001193125-14-398478:note_history:14]
Cash and cash
 equivalents are maintained with several financial institutions.
 Deposits held with banks may exceed the amount of insurance
 provided on such deposits. Generally, these deposits may be
 redeemed upon demand and are maintained with financial institutions
 with reputable credit and therefore bear minimal credit risk. The
 Company seeks to mitigate its credit risks by spreading such risks
 across multiple counterparties and monitoring the risk profiles of
 these counterparties.

- added (2014-11-05):
[0001193125-14-398478:note_history:15]
The Company
 performs ongoing credit evaluations for credit worthiness of its
 customers and usually does not require collateral from its
 customers. Management has implemented a program to closely monitor
 near term cash collection and credit exposures to mitigate any
 material losses.

- added (2014-11-05):
[0001193125-14-398478:note_history:16]
New
 Accounting Pronouncements – not yet adopted by the
 Company

- added (2014-11-05):
[0001193125-14-398478:note_history:17]
In August 2014,
 The Financial Accounting Standards Board (FASB) issued Accounting
 Standard Update (ASU) No. 2014-15, “Presentation of
 Financial Statements – Going Concern (Subtopic 205-40):
 Disclosure of Uncertainties about an Entity’s Ability to
 Continue as a Going Concern”. The amendments require
 management to evaluate, for each annual and interim reporting
 period, an entity’s ability to continue as a going concern
 when relevant conditions and events, considered in the aggregate,
 indicate that it is probable that the entity will be unable to meet
 its obligations that become due within one year after the date that
 the financial statements are issued (or available to be issued).
 This ASU is effective for annual periods and interim reporting
 periods beginning after December 15, 2016. The Company does
 not expect that the adoption of this update will have an effect on
 its consolidated financial statements.

- added (2014-11-05):
[0001193125-14-398478:note_history:18]
In June 2014,
 the FASB issued ASU No. 2014-12, “Compensation –
 Stock Compensation (Topic 718): Accounting for Share-Based Payments
 When the Terms of an Award Provide That a Performance Target Could
 Be Achieved After the Requisite Service Period”. This ASU
 requires that a performance target that affects vesting, and that
 could be achieved after the requisite service period, be treated as
 a performance condition. As such, the performance target should not
 be reflected in estimating the grant date fair value of the award.
 This update further clarifies that compensation cost should be
 recognized in the period in which it becomes probable that the
 performance target will be achieved and should represent the
 compensation cost attributable to the period(s) for which the
 requisite service has already been rendered. This update is
 required to be adopted by all public companies for annual periods
 and interim reporting periods beginning after December 15,
 2015. Early adoption of this ASU is permitted. The Company is
 currently evaluating the impact of adoption of this update on its
 consolidated financial statements.

- added (2014-11-05):
[0001193125-14-398478:note_history:19]
In May 2014,
 the FASB issued ASU No. 2014-09, “Revenue from Contracts
 with Customers (Topic 606), issued as a new Topic, Accounting
 Standards Codification”. The core principle of this amendment
 is that an entity should recognize revenue to depict the transfer
 of promised goods or services to customers in an amount that
 reflects the consideration to which the entity expects to be
 entitled in exchange for those goods or services. This ASU is
 effective for annual reporting periods beginning after
 December 15, 2016, including interim periods within that
 reporting period, with earlier adoption not being permitted. This
 ASU can be adopted either retrospectively to each prior reporting
 period presented or as a cumulative-effect adjustment as of the
 date of adoption. The Company is currently evaluating the impact of
 adoption of this update on its consolidated financial
 statements.

- changed (2014-11-05):
[0001193125-14-398478:note_history:20]
Recently
 Adopted Accounting Pronouncements
  (was, 2014-05-06, similarity 0.8649):
[0001193125-14-184830:note_history:20]
Recent
 accounting pronouncements

- added (2014-11-05):
[0001193125-14-398478:note_history:21]
In July 2013,
 the FASB issued ASU No. 2013-11, “Income Taxes (Topic
 740): Presentation of an Unrecognized Tax Benefit When a Net
 Operating Loss Carryforward, a Similar Tax Loss, or a Tax Credit
 Carryforward Exists”. This ASU provides guidance for netting
 of unrecognized tax benefits (UTBs) against a deferred tax asset
 for a loss or other carryforward that would apply in settlement of
 the uncertain tax positions. Under this new guidance, UTBs will be
 netted against all available same-jurisdiction loss or other tax
 carryforwards that would be utilized, rather than only against
 carryforwards that are created by the UTBs. This guidance is
 effective for fiscal years, and interim periods within those years,
 beginning after December 15, 2013. The Company adopted this
 ASU in the first quarter of fiscal year 2015. Adoption of this
 guidance did not have a material impact on the Company’s
 unaudited condensed consolidated financial statements.

- added (2014-11-05):
[0001193125-14-398478:note_history:22]
In April 2013,
 the FASB issued ASU No. 2013-07, “Presentation of
 Financial Statements (Topic 205): Liquidation Basis of
 Accounting”. The amendments require an entity to prepare its
 financial statements using the liquidation basis of accounting when
 liquidation is imminent. The amendments require financial
 statements prepared using the liquidation basis of accounting to
 present relevant information about an entity’s expected
 resources in liquidation by measuring and presenting assets at the
 amount of the expected cash proceeds from liquidation. This
 guidance is effective for entities that determine liquidation is
 imminent during annual reporting periods beginning after
 December 15, 2013 and interim reporting periods therein. The
 Company adopted this ASU in the first quarter of fiscal year 2015.
 Adoption of this guidance did not have a material impact on the
 Company’s unaudited condensed consolidated financial
 statements.

- added (2014-11-05):
[0001193125-14-398478:note_history:23]
In March 2013,
 the FASB issued ASU No. 2013-05, “Foreign Currency
 Matters (Topic 830): Parents’ Accounting for the Cumulative
 Translation Adjustment upon Derecognition of Certain Subsidiaries
 or Groups of Assets within a Foreign Entity or of an Investment in
 a Foreign Entity”. This ASU permits an entity to release
 cumulative translation adjustments into net income when a reporting
 entity (parent) ceases to have a controlling financial interest in
 a subsidiary or group of assets that is a business within a foreign
 entity. Accordingly, the cumulative translation adjustment should
 be released into net income only if the sale or transfer results in
 the complete or substantially complete liquidation of the foreign
 entity in which the subsidiary or group of assets had resided, or,
 if a controlling financial interest is no longer held. The guidance
 is effective for fiscal years beginning after December 15,
 2013, with early adoption being permitted. The Company adopted this
 ASU in the first quarter of fiscal year 2015. Adoption of this
 guidance did not have a material impact on the Company’s
 unaudited condensed consolidated financial statements.

- added (2014-11-05):
[0001193125-14-398478:note_history:24]
In February
 2013, the FASB issued ASU No. 2013-04, “Liabilities
 (Topic 405): Obligations Resulting from Joint and Several Liability
 Arrangements for which the Total Amount of the Obligation is Fixed
 at the Reporting Date”. The guidance in this update requires
 an entity to measure obligations resulting from joint and several
 liability arrangements for which the total amount of the obligation
 within the scope of this guidance is fixed at the reporting date,
 as the sum of the following: (a) the amount the reporting
 entity agreed to pay on the basis of its arrangement among its
 co-obligors, and (b) any additional amount the reporting
 entity expects to pay on behalf of its co-obligors. The guidance
 also requires an entity to disclose the nature and amount of the
 obligation as well as other information about those obligations.
 This guidance is effective for fiscal years, and interim periods
 within those years, beginning after December 15, 2013. The
 Company adopted this ASU in the first quarter of fiscal year 2015.
 Adoption of this guidance did not have a material impact on the
 Company’s unaudited condensed consolidated financial
 statements.

- removed (2014-11-05):
[0001193125-14-184830:note_history:25]
As of
 March 28, 2014, the Company’s cash and cash equivalents
 were held in deposits and highly liquid investment products with
 maturities of three months or less with banks and other financial
 institutions having credit ratings of A minus or above. The Company
 had two customers that each contributed to 10% or more of its total
 accounts receivable as of March 28, 2014 and June 28,
 2013, respectively.

- removed (2014-11-05):
[0001193125-14-184830:note_history:26]
Accounts
 receivable include amounts due from customers that are monitored by
 the Company for credit worthiness. Management has implemented a
 program to closely monitor near term cash collection and credit
 exposures and believes no material loss will be
 incurred.

- removed (2014-11-05):
[0001193125-14-184830:note_history:27]
In July 2013,
 the Financial Accounting Standards Board (“FASB”)
 issued Accounting Standards Update (“ASU”)
 No. 2013-11 — Income Taxes (Topic 740) —
 Presentation of an Unrecognized Tax Benefit When a Net Operating
 Loss Carryforward, a Similar Tax Loss, or a Tax Credit Carryforward
 Exists. The guidance suggested that an unrecognized tax benefit or
 a portion of an unrecognized of tax benefit, should be presented in
 the financial statements as a reduction to a deferred tax assets
 for a net operating loss carryforward, a similar tax loss, or a tax
 loss creditforward, except as follows. To the extent a net
 operating loss carryforward, a similar tax loss, or a tax loss
 creditforward is not available at the reporting date under tax law
 of the applicable jurisdiction to settle any additional income
 taxes that would result from the disallowance of a tax position or
 the tax loss of the applicable jurisdiction does not required the
 entity to use, and the entity does not intended to use, the
 deferred tax assets for such purpose, the unrecognized tax benefit
 should be presented in the financial statement as a liabilities and
 should not be combined with deferred tax assets. The assessment of
 whether a deferred tax asset is available is based on the
 unrecognized tax benefit and deferred tax asset that exist at the
 reporting date and should be made presuming disallowance of the tax
 position at the reporting date. This guidance is effective for
 fiscal years, and interim periods within those years, beginning
 after December 15, 2013. The Company does not expect that the
 adoption of this guidance will have an effect on its consolidated
 financial statements.

- removed (2014-11-05):
[0001193125-14-184830:note_history:28]
In April 2013,
 the FASB issued ASU No. 2013-07 – Presentation of
 Financial Statements (Topic 205) — Liquidation Basis of
 Accounting. The amendments require an entity to prepare its
 financial statements using the liquidation basis of accounting when
 liquidation is imminent. Liquidation is imminent when the
 likelihood is remote that the entity will return from liquidation
 and either (a) a plan for liquidation is approved by the
 person or persons with the authority to make such a plan effective
 and the likelihood is remote that the execution of the plan will be
 blocked by other parties, or (b) a plan for liquidation is
 being imposed by other forces (for example, involuntary
 bankruptcy). If a plan for liquidation was specified in the
 entity’s governing documents from the entity’s
 inception (for example, limited-life entities), the entity should
 apply the liquidation basis of accounting only if the approved plan
 for liquidation differs from the plan for liquidation that was
 specified at the entity’s inception. The amendments require
 financial statements prepared using the liquidation basis of
 accounting to present relevant information about an entity’s
 expected resources in liquidation by measuring and presenting
 assets at the amount of the expected cash proceeds from
 liquidation. The entity should include in its presentation of
 assets any items it had not previously recognized under U.S. GAAP
 but that it expects to either sell in liquidation or use in
 settling liabilities (for example, trademarks). An entity should
 recognize and measure its liabilities in accordance with U.S. GAAP
 that otherwise applies to those liabilities. The entity should not
 anticipate that it will be legally released from being the primary
 obligor under those liabilities, either judicially or by creditors.
 The entity also is required to accrue and separately present the
 costs that it expects to incur and the income that it expects to
 earn during the expected duration of the liquidation, including any
 costs associated with sale or settlement of those assets and
 liabilities. Additionally, the amendments require disclosures about
 an entity’s plan for liquidation, the methods and significant
 assumptions used to measure assets and liabilities, the type and
 amount of costs and income accrued, and the expected duration of
 the liquidation process. This guidance is effective for entities
 that determine liquidation is imminent during annual reporting
 periods beginning after December 15, 2013 and interim
 reporting periods therein. The Company does not expect that the
 adoption of this guidance will have an effect on its consolidated
 financial statements.

- removed (2014-11-05):
[0001193125-14-184830:note_history:29]
In March 2013,
 the FASB issued ASU No. 2013-05 – Foreign Currency
 Matters (Topic 830) — Parents’ Accounting for the
 Cumulative Translation Adjustment upon Derecognition of Certain
 Subsidiaries or Groups of Assets within a Foreign Entity or of an
 Investment in a Foreign Entity. When a reporting entity (parent)
 ceases to have a controlling financial interest in a subsidiary or
 group of assets that is a nonprofit activity or a business (other
 than a sale of in substance real estate or conveyance of oil and
 gas mineral rights) within a foreign entity, the parent is required
 to apply the guidance in Subtopic 830-30 to release any related
 cumulative translation adjustment into net income. Accordingly, the
 cumulative translation adjustment should be released into net
 income only if the sale or transfer results in the complete or
 substantially complete liquidation of the foreign entity in which
 the subsidiary or group of assets had resided. For an equity method
 investment that is a foreign entity, the partial sale guidance in
 Section 830-30-40 still applies. As such, a pro rata portion
 of the cumulative translation adjustment should be released into
 net income upon a partial sale of such an equity method investment.
 However, this treatment does not apply to an equity method
 investment that is not a foreign entity. In those instances, the
 cumulative translation adjustment is released into net income only
 if the partial sale represents a complete or substantially complete
 liquidation of the foreign entity that contains the equity method
 investment. Additionally, the amendments in this Update clarify
 that the sale of an investment in a foreign entity includes both
 (1) events that result in the loss of a controlling financial
 interest in a foreign entity (that is, irrespective of any retained
 investment) and (2) events that result in an acquirer
 obtaining control of an acquiree in which it held an equity
 interest immediately before the acquisition date (sometimes also
 referred to as a step acquisition). Accordingly, the cumulative
 translation adjustment should be released into net income upon the
 occurrence of those events. This guidance is effective
 prospectively for fiscal years and interim reporting periods within
 those years beginning after December 15, 2013. The Company
 does not expect that the adoption of this guidance will have an
 effect on its consolidated financial statements.

- removed (2014-11-05):
[0001193125-14-184830:note_history:30]
In February
 2013, the FASB issued ASU No. 2013-04 – Liabilities
 (Topic 405) — Obligations Resulting from Joint and Several
 Liability Arrangements for which the Total Amount of the Obligation
 is fixed at the Reporting Date. The guidance in this update
 requires an entity to measure obligations resulting from joint and
 several liability arrangements for which the total amount of the
 obligation within the scope of this guidance is fixed at the
 reporting date, as the sum of the following: (a) the amount
 the reporting entity agreed to pay on the basis of its arrangement
 among its co-obligors, and (b) any additional amount the
 reporting entity expects to pay on behalf of its co-obligors. The
 guidance also requires an entity to disclose the nature and amount
 of the obligation as well as other information about those
 obligations. This guidance is effective for fiscal years, and
 interim periods within those years, beginning after
 December 15, 2013. The Company does not expect that the
 adoption of this guidance will have an effect on its consolidated
 financial statements.

- removed (2014-11-05):
[0001193125-14-184830:note_history:31]
In January
 2013, the FASB issued ASU No. 2013-01 – Balance Sheet
 (Topic 210) — Clarifying the Scope of Disclosure about
 Offsetting Assets and Liabilities. The amendments clarify that the
 scope of Update 2011-11 applies to derivatives accounted for in
 accordance with Topic 815, Derivatives and Hedging, including
 bifurcated embedded derivatives, repurchase agreements and reverse
 repurchase agreements, and securities borrowing and securities
 lending transactions that are either offset in accordance with
 Section 210-20-45 or Section 815-10-45 or subject to an
 enforceable master netting arrangement or similar agreement. This
 guidance is effective for fiscal years beginning on or after
 January 1, 2013, and interim periods within those annual
 periods. The Company adopted this guidance in the first quarter of
 fiscal year 2014. This guidance did not impact the Company’s
 presentation, financial position, or results of
 operations.

- removed (2014-11-05):
[0001193125-14-184830:note_history:32]
In July 2012,
 the FASB issued ASU No. 2012-02 – Intangibles —
 Goodwill and Other (Topic 350) – Testing Indefinite-Lived
 Intangible Assets for Impairment. Under the amendments in ASU
 No. 2012-02, an entity has the option first to assess
 qualitative factors to determine whether the existence of events
 and circumstances indicates that it is more likely than not that
 the indefinite-lived intangible asset is impaired. If, after
 assessing the totality of events and circumstances, an entity
 concludes that it is not more likely than not that the
 indefinite-lived intangible asset is impaired, then the entity is
 not required to take further action. However, if an entity
 concludes otherwise, then it is required to determine the fair
 value of the indefinite-lived intangible asset and perform the
 quantitative impairment test by comparing the fair value with the
 carrying amount in accordance with Subtopic 350-30. This guidance
 is effective for fiscal years beginning after September 15,
 2012. The Company adopted this guidance in the first quarter of
 fiscal year 2014. This guidance did not impact the Company’s
 presentation, financial position, or results of
 operations.

- removed (2014-11-05):
[0001193125-14-184830:note_history:33]
In December
 2011, the FASB issued ASU No. 2011-11 – Balance Sheet
 (Topic 210) – Disclosures about Offsetting Assets and
 Liabilities. The amendments in ASU No. 2011-11 will enhance
 disclosures required by U.S. GAAP by requiring improved information
 about financial instruments and derivative instruments that are
 either (1) offset in accordance with Section 210-20-45 or
 Section 815-10-45 or (2) subject to an enforceable master
 netting arrangement or similar agreement, irrespective of whether
 they are offset in accordance with Section 210-20-45 or
 Section 815-10-45. Information about offsetting and related
 arrangements will enable users of an entity’s financial
 statements to understand the effect of those arrangements on an
 entity’s financial position, including the effect or
 potential effect of rights of setoff associated with certain
 financial instruments and derivative instruments in the scope of
 ASU No. 2011-11. This guidance is effective for annual
 reporting periods beginning on or after January 1, 2013, and
 interim periods within those annual periods. The Company adopted
 this guidance in the first quarter of fiscal year 2014. This
 guidance did not impact the Company’s presentation, financial
 position, or results of operations.


## fn:LongTermDebtTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2014-11-05):
[0001193125-14-184830:note_history:34]
The movements of
 long-term loans were as follows for the nine months ended
 March 28, 2014 and March 29, 2013:

- removed (2014-11-05):
[0001193125-14-184830:note_history:35]
|  |  | Nine Months Ended |  |
|  |  | March 28, 2014 |  |  | March 29, 2013 |  |
| Opening net book amount |  | $ | 28,911 |  |  | $ | 38,579 |  |
| Repayment during the period |  |  | (7,251 | ) |  |  | (7,251 | ) |
| Closing net book amount |  | $ | 21,660 |  |  | $ | 31,328 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-05):
[0001193125-14-398478:note_history:36]
| 9. | Borrowings |
  (was, 2014-05-06, similarity 0.9474):
[0001193125-14-184830:note_history:36]
| 8. |  | Borrowings |

- changed (2014-11-05):
[0001193125-14-398478:note_history:37]
Bank borrowing
 and long-term debt was comprised of the following:
  (was, 2014-05-06, similarity 0.9924):
[0001193125-14-184830:note_history:37]
Bank borrowings
 and long-term debt was comprised of the following:

- added (2014-11-05):
[0001193125-14-398478:note_history:38]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Term |  | As of September 26, 2014 |  |  | As of June 27, 2014 |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | June 2012 – March 2017 |  | $ | 15,000 |  |  | $ | 16,500 |  |
| Less: Current portion |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  | $ | 9,000 |  |  | $ | 10,500 |  |

- added (2014-11-05):
[0001193125-14-398478:note_history:39]
On
 April 25, 2014, a subsidiary entered into an amendment to the
 bank borrowing agreement. Under the amendment of the contract, the
 long-term loan is secured by certain property, plant and equipment.
 The carrying amount of assets secured and pledged as collateral as
 of September 26, 2014 and June 27, 2014 was $51.7 million
 and $52.3 million, respectively. This subsidiary is also required
 to comply with the maximum ratios of debt to equity and minimum
 levels of debt service coverage ratios and Fabrinet must maintain
 effective shareholding ratio. The carrying amounts of bank
 borrowings approximate their fair value.

- changed (2014-11-05):
[0001193125-14-398478:note_history:40]
As of
 September 26, 2014 and June 27, 2014, the Company was in
 compliance with its long-term bank borrowing agreement. In addition
 to financial ratios, certain of the Company’s packing credits
 and long-term loans include customary events of default.
  (was, 2014-05-06, similarity 0.6955):
[0001193125-14-184830:note_history:40]
The long-term
 loans prescribe maximum ratios of debt to equity and minimum levels
 of debt service coverage ratios. As of March 28, 2014 and
 June 28, 2013, the Company was in compliance with its
 long-term loan agreements. In addition to financial ratios, certain
 of the Company’s packing credits and long-term loans include
 customary events of default.

- changed (2014-11-05):
[0001193125-14-398478:note_history:41]
The movements
 of long-term loans were as follows for the three months ended
 September 26, 2014 and September 27, 2013:
  (was, 2014-05-06, similarity 0.8696):
[0001193125-14-184830:note_history:41]
The movements
 of long-term loans were as follows for the nine months ended
 March 28, 2014 and March 29, 2013:

- changed (2014-11-05):
[0001193125-14-398478:note_history:42]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 26, 2014 |  |  | September 27, 2013 |  |
| Opening net book amount |  | $ | 16,500 |  |  | $ | 28,911 |  |
| Repayment during the period |  |  | (1,500 | ) |  |  | (2,417 | ) |
| Closing net book amount |  | $ | 15,000 |  |  | $ | 26,494 |  |
  (was, 2014-05-06, similarity 0.8191):
[0001193125-14-184830:note_history:42]
|  |  | Nine Months Ended |  |
|  |  | March 28, 2014 |  |  | March 29, 2013 |  |
| Opening net book amount |  | $ | 28,911 |  |  | $ | 38,579 |  |
| Repayment during the period |  |  | (7,251 | ) |  |  | (7,251 | ) |
| Closing net book amount |  | $ | 21,660 |  |  | $ | 31,328 |  |

- changed (2014-11-05):
[0001193125-14-398478:note_history:43]
As of
 September 26, 2014, future maturities of long-term debt were
 as follows at the end of each fiscal year below:
  (was, 2014-05-06, similarity 0.9533):
[0001193125-14-184830:note_history:43]
As of
 March 28, 2014, future maturities of long-term debt were as
 follows at the end of each fiscal year below:

- changed (2014-11-05):
[0001193125-14-398478:note_history:44]
| (amount in thousands) |  |  |  |
| 2015 |  | $ | 4,500 |  |
| 2016 |  |  | 6,000 |  |
| 2017 |  |  | 4,500 |  |
| Total |  | $ | 15,000 |  |
  (was, 2014-05-06, similarity 0.8421):
[0001193125-14-184830:note_history:44]
| 2014 |  | $ | 5,160 |  |
| 2015 |  |  | 6,000 |  |
| 2016 |  |  | 6,000 |  |
| 2017 |  |  | 4,500 |  |
| Total |  | $ | 21,660 |  |

- added (2014-11-05):
[0001193125-14-398478:note_history:45]
Fabrinet
 entered into a syndicated senior credit facility agreement (the
 “Facility Agreement”) with a consortium of banks on
 May 22, 2014. The Facility Agreement, led by Bank of America,
 provides for a $200.0 million credit line, comprised of a $150.0
 million revolving loan facility and a $50.0 million delayed draw
 term loan facility. The revolving loan facility contains an
 accordion feature permitting Fabrinet to request an increase in the
 facility up to $100.0 million subject to customary terms and
 conditions and provided that no default or event of default exists
 at the time of request. The revolving loan facility terminates and
 all amounts outstanding are due and payable in full on May 22,
 2019. The principal amount of any drawn term loans must be repaid
 according to the scheduled quarterly amortization payments, with
 final payment of all amounts outstanding, plus accrued interest,
 being due May 22, 2019. As of September 26, 2014, no
 amounts were outstanding under the Facility Agreement.

- added (2014-11-05):
[0001193125-14-398478:note_history:46]
Loans under the
 Facility Agreement bear interest, at Fabrinet’s option, at a
 rate per annum equal to a LIBOR rate plus a spread of 1.75% to
 2.50%, or a base rate, determined in accordance with the Facility
 Agreement, plus a spread of 0.75% to 1.50%, in each case with such
 spread determined based on Fabrinet’s consolidated total
 leverage ratio for the preceding four fiscal quarter period.
 Interest is due and payable quarterly in arrears for loans bearing
 interest at the base rate and at the end of an interest period (or
 at each three-month interval in the case of loans with interest
 periods greater than three months) in the case of loans bearing
 interest at the LIBOR rate. The applicable spreads and commitment
 fees will increase in the event that Fabrinet’s Thailand
 subsidiary is unable to guarantee the obligations under the
 Facility Agreement within 180 days after the closing
 date.

- added (2014-11-05):
[0001193125-14-398478:note_history:47]
Fabrinet’s obligations under the Facility Agreement are
 guaranteed by certain of its existing and future direct material
 subsidiaries. In addition, the Facility Agreement is secured by
 Fabrinet’s present and future accounts receivable, deposit
 accounts and cash, and a pledge of the capital stock of certain of
 Fabrinet’s direct subsidiaries. Fabrinet shall maintain at
 least $40.0 million of cash, cash equivalents, and marketable
 securities at financial institutions located in the United States.
 Further, Fabrinet is required to maintain any of its deposits
 accounts or securities accounts with balances in excess of $10.0
 million in a jurisdiction where a control agreement, or the
 equivalent under the local law, can be effected. The Facility
 Agreement contains customary affirmative and negative covenants.
 Negative covenants include, among other things, limitations on
 liens, indebtedness, investments, mergers, sales of assets, changes
 in the nature of the business, dividends and distributions,
 affiliate transactions and capital expenditures. The Facility
 Agreement contains financial covenants requiring Fabrinet to
 maintain: (i) a minimum tangible net worth of not less than
 $200.0 million plus 50% of quarterly net income, exclusive of
 quarterly losses; (ii) a minimum debt service coverage ratio
 of not less than 1.50:1.00; (iii) a maximum senior leverage
 ratio of not more than 2.50:1.00; and (iv) a minimum quick
 ratio of not less than 1.10:1.00. Each of these financial covenants
 is calculated on a consolidated basis for the consecutive four
 fiscal quarter period then ended. As of September 26, 2014,
 the Company was in compliance with all covenants under the Facility
 Agreement.

- added (2014-11-05):
[0001193125-14-398478:note_history:48]
The Facility
 Agreement also contains customary events of default including,
 among other things, payment defaults, breaches of covenants or
 representations and warranties, cross-defaults with certain other
 indebtedness, bankruptcy and insolvency events and change in
 control of Fabrinet, subject to grace periods in certain instances.
 Upon an event of default, the lenders may terminate their
 commitments, declare all or a portion of the outstanding
 obligations payable by Fabrinet to be immediately due and payable
 and exercise other rights and remedies provided for under the
 Facility Agreement. The undrawn credit facility of $200.0 million
 became available on July 15, 2014.

- added (2014-11-05):
[0001193125-14-398478:note_history:49]
Fabrinet
 intends to use the proceeds of the credit line to finance its
 future manufacturing building in Thailand, and for general
 corporate purposes including mergers and acquisitions of
 complementary manufacturing businesses or technology, although
 Fabrinet has no current commitments with respect to any such
 acquisitions.

- changed (2014-11-05):
[0001193125-14-398478:note_history:50]
Undrawn
 available credit facilities as of September 26, 2014 and
 June 27, 2014 were as follows:
  (was, 2014-05-06, similarity 0.9398):
[0001193125-14-184830:note_history:50]
Undrawn
 available credit facilities as of March 28, 2014 and
 June 28, 2013 were as follows:

- changed (2014-11-05):
[0001193125-14-398478:note_history:51]
| (amount in thousands) |  | September 26, 2014 |  |  | June 27, 2014 |  |
| Bank borrowings: |  |  |  |  |
| Short-term loans |  | $ | 1,548 |  |  | $ | 1,539 |  |
| Long-term loans |  | $ | 200,000 |  |  |  | — |  |
  (was, 2014-05-06, similarity 0.7192):
[0001193125-14-184830:note_history:51]
|  |  | March 28, 2014 |  |  | June 28, 2013 |  |
| Bank borrowings: |  |  |  |  |  |  |  |  |
| Short-term loans |  | $ | 5,228 |  |  | $ | 5,461 |  |

- removed (2014-11-05):
[0001193125-14-184830:note_history:52]
|  |  | March 28, 2014 |  |  | June 28, 2013 |  |
| Long-term loans from bank |  | $ | 21,660 |  |  | $ | 28,911 |  |
| Total borrowings |  | $ | 21,660 |  |  | $ | 28,911 |  |
| Long-term loans from bank consisted of: |  |  |  |  |  |  |  |  |
| Current portion |  | $ | 9,660 |  |  | $ | 9,668 |  |
| Non-current portion |  | $ | 12,000 |  |  | $ | 19,243 |  |

- removed (2014-11-05):
[0001193125-14-184830:note_history:53]
As of
 March 28, 2014 and June 28, 2013, the Company had
 outstanding borrowings under long-term loan agreements with banks
 totaling $21,660 and $28,911, respectively, which consisted
 of:

- removed (2014-11-05):
[0001193125-14-184830:note_history:54]
| Contract No. |  | Amount |  |  | Interest Rate (%) |  | Conditions |  | Repayment Term |
|  | March 28, 2014 |  |  | June 28, 2013 |  |  |  |  |
| 1 |  | $ | 18,000 |  |  | $ | 22,500 |  |  | LIBOR(1) + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | June 2012 to March 2017 |
| 2 |  |  | 3,660 |  |  |  | 6,411 |  |  | SIBOR(2) + 1.5% per annum |  | Repayable in quarterly installments within 8 years |  | May 2009 to February 2015 |
| Total |  | $ | 21,660 |  |  | $ | 28,911 |  |  |  |  |  |  |  |

- removed (2014-11-05):
[0001193125-14-184830:note_history:55]
| (2) | SIBOR is Singapore Interbank Offered Rate. |

- removed (2014-11-05):
[0001193125-14-184830:note_history:56]
Certain of the
 long-term loans are secured by certain property, plant and
 equipment. The carrying amount of assets secured and pledged as
 collateral was $21,102 and $21,815 as of March 28, 2014 and
 June 28, 2013, respectively. The carrying amounts of
 borrowings approximate their fair value.

- removed (2014-11-05):
[0001193125-14-184830:note_history:57]
Subsequent to
 the quarter-end:

- removed (2014-11-05):
[0001193125-14-184830:note_history:58]
|  | (a) | On April 25, 2014, a subsidiary entered into an amendment to the long-term loan contract No.1. Under the amendment of the contract, the long-term loan is secured by certain property, plant and equipment. The carrying amount of assets secured and pledged as collateral as of March 28, 2014 was $52,894. The subsidiary is also required to comply with the maximum ratios of debt to equity and minimum levels of debt service coverage ratios and Fabrinet must maintain effective shareholding ratio. |

- removed (2014-11-05):
[0001193125-14-184830:note_history:59]
|  | (b) | On April 28, 2014, the subsidiary made an early repayment of long-term loan contract No.2 which included principal, interest expense and an early repayment fee of $3,707. As of March 28, 2014, this loan was classified in long-term loans from bank, current portion. |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-11-05):
[0001193125-14-398478:note_history:60]
Bank borrowing
 and long-term debt was comprised of the following:

- added (2014-11-05):
[0001193125-14-398478:note_history:61]
| (amount in thousands) |  |  |  |  |  |  |  |  |  |  |
| Rate (1) |  | Conditions |  | Term |  | As of September 26, 2014 |  |  | As of June 27, 2014 |  |
| LIBOR + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | June 2012 – March 2017 |  | $ | 15,000 |  |  | $ | 16,500 |  |
| Less: Current portion |  |  | (6,000 | ) |  |  | (6,000 | ) |
| Non-current portion |  | $ | 9,000 |  |  | $ | 10,500 |  |

- removed (2014-11-05):
[0001193125-14-184830:note_history:62]
As of
 March 28, 2014 and June 28, 2013, the Company had
 outstanding borrowings under long-term loan agreements with banks
 totaling $21,660 and $28,911, respectively, which consisted
 of:

- removed (2014-11-05):
[0001193125-14-184830:note_history:63]
| Contract No. |  | Amount |  |  | Interest Rate (%) |  | Conditions |  | Repayment Term |
|  | March 28, 2014 |  |  | June 28, 2013 |  |  |  |  |
| 1 |  | $ | 18,000 |  |  | $ | 22,500 |  |  | LIBOR(1) + 2.8% per annum |  | Repayable in quarterly installments within 6 years |  | June 2012 to March 2017 |
| 2 |  |  | 3,660 |  |  |  | 6,411 |  |  | SIBOR(2) + 1.5% per annum |  | Repayable in quarterly installments within 8 years |  | May 2009 to February 2015 |
| Total |  | $ | 21,660 |  |  | $ | 28,911 |  |  |  |  |  |  |  |

- removed (2014-11-05):
[0001193125-14-184830:note_history:64]
| (2) | SIBOR is Singapore Interbank Offered Rate. |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-11-05):
[0001193125-14-398478:note_history:65]
The movements
 of long-term loans were as follows for the three months ended
 September 26, 2014 and September 27, 2013:

- added (2014-11-05):
[0001193125-14-398478:note_history:66]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 26, 2014 |  |  | September 27, 2013 |  |
| Opening net book amount |  | $ | 16,500 |  |  | $ | 28,911 |  |
| Repayment during the period |  |  | (1,500 | ) |  |  | (2,417 | ) |
| Closing net book amount |  | $ | 15,000 |  |  | $ | 26,494 |  |

- removed (2014-11-05):
[0001193125-14-184830:note_history:67]
Bank borrowings
 and long-term debt was comprised of the following:

- removed (2014-11-05):
[0001193125-14-184830:note_history:68]
|  |  | March 28, 2014 |  |  | June 28, 2013 |  |
| Long-term loans from bank |  | $ | 21,660 |  |  | $ | 28,911 |  |
| Total borrowings |  | $ | 21,660 |  |  | $ | 28,911 |  |
| Long-term loans from bank consisted of: |  |  |  |  |  |  |  |  |
| Current portion |  | $ | 9,660 |  |  | $ | 9,668 |  |
| Non-current portion |  | $ | 12,000 |  |  | $ | 19,243 |  |


## us-gaap:ScheduleOfLineOfCreditFacilitiesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-05):
[0001193125-14-398478:note_history:69]
Undrawn
 available credit facilities as of September 26, 2014 and
 June 27, 2014 were as follows:
  (was, 2014-05-06, similarity 0.9398):
[0001193125-14-184830:note_history:69]
Undrawn
 available credit facilities as of March 28, 2014 and
 June 28, 2013 were as follows:

- changed (2014-11-05):
[0001193125-14-398478:note_history:70]
| (amount in thousands) |  | September 26, 2014 |  |  | June 27, 2014 |  |
| Bank borrowings: |  |  |  |  |
| Short-term loans |  | $ | 1,548 |  |  | $ | 1,539 |  |
| Long-term loans |  | $ | 200,000 |  |  |  | — |  |
  (was, 2014-05-06, similarity 0.7192):
[0001193125-14-184830:note_history:70]
|  |  | March 28, 2014 |  |  | June 28, 2013 |  |
| Bank borrowings: |  |  |  |  |  |  |  |  |
| Short-term loans |  | $ | 5,228 |  |  | $ | 5,461 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-05):
[0001193125-14-398478:note_history:71]
As of
 September 26, 2014, future maturities of long-term debt were
 as follows at the end of each fiscal year below:
  (was, 2014-05-06, similarity 0.9533):
[0001193125-14-184830:note_history:71]
As of
 March 28, 2014, future maturities of long-term debt were as
 follows at the end of each fiscal year below:

- changed (2014-11-05):
[0001193125-14-398478:note_history:72]
| (amount in thousands) |  |  |  |
| 2015 |  | $ | 4,500 |  |
| 2016 |  |  | 6,000 |  |
| 2017 |  |  | 4,500 |  |
| Total |  | $ | 15,000 |  |
  (was, 2014-05-06, similarity 0.8421):
[0001193125-14-184830:note_history:72]
| 2014 |  | $ | 5,160 |  |
| 2015 |  |  | 6,000 |  |
| 2016 |  |  | 6,000 |  |
| 2017 |  |  | 4,500 |  |
| Total |  | $ | 21,660 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2014-11-05):
[0001193125-14-398478:note_history:73]
| 17. | Subsequent event |
  (was, 2014-05-06, similarity 0.9412):
[0001193125-14-184830:note_history:73]
| 15. |  | Subsequent events |

- added (2014-11-05):
[0001193125-14-398478:note_history:74]
As part of the
 Company’s ongoing efforts to achieve greater efficiencies in
 all areas of its business, on October 10, 2014, the Company
 implemented a reduction in workforce and incurred expenses of
 approximately $1.0 million, which represented severance and
 benefits costs incurred for the termination of approximately 100
 employees in accordance with contractual obligations and local
 regulations. The Company will record this expense in the next
 quarter.

- removed (2014-11-05):
[0001193125-14-184830:note_history:75]
As discussed in
 the note 8, subsequent to the quarter-end;

- removed (2014-11-05):
[0001193125-14-184830:note_history:76]
|  | (a) | On April 25, 2014, a subsidiary entered into an amendment to the long-term loan contract No.1. Under the amendment of the contract, the long-term loan is secured by certain property, plant and equipment. The carrying amount of assets secured and pledged as collateral as of March 28, 2014 was $52,894. The subsidiary is also required to comply with the maximum ratios of debt to equity and minimum levels of debt service coverage ratios and Fabrinet must maintain effective shareholding ratio. |

- removed (2014-11-05):
[0001193125-14-184830:note_history:77]
|  | (b) | On April 28, 2014, the subsidiary made an early repayment of long-term loan contract No.2 which included principal, interest expense and early repayment fee of $3,707. As of March 28, 2014, this loan classified in long-term loans from bank, current portion. |
