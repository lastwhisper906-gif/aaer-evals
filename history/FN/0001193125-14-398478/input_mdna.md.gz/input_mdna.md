# FN MD&A — 0001193125-14-398478


## mdna

[0001193125-14-398478:mdna:1]
[same as prior period, unchanged from 0001193125-14-184830:mdna:1]

[0001193125-14-398478:mdna:2]
[same as prior period, unchanged from 0001193125-14-184830:mdna:2]

[0001193125-14-398478:mdna:3]
[same as prior period, unchanged from 0001193125-14-184830:mdna:3]

[0001193125-14-398478:mdna:4]
|  | • |  | our expectation that the portion of our future revenues attributable to customers in regions outside of North America will decrease compared to the portion of those revenues for the three months ended September 26, 2014; |

[0001193125-14-398478:mdna:5]
[same as prior period, unchanged from 0001193125-14-184830:mdna:5]

[0001193125-14-398478:mdna:6]
[same as prior period, unchanged from 0001193125-14-184830:mdna:6]

[0001193125-14-398478:mdna:7]
|  | • |  | our expectation that our fiscal year 2015 selling, general and administrative (SG&A) expenses will increase on an absolute dollar basis and remain flat as a percentage of revenue compared to fiscal 2014; |

[0001193125-14-398478:mdna:8]
|  | • |  | our expectation that, aside from the usual incremental costs associated with growing our business, we will not incur material incremental SG&A expenses as a result of our continued diversification into the industrial lasers and sensors markets; and other end-markets outside of the optical communications market or our further development of customized optics and glass manufacturing capabilities; |

[0001193125-14-398478:mdna:9]
[same as prior period, unchanged from 0001193125-14-184830:mdna:9]

[0001193125-14-398478:mdna:10]
[same as prior period, unchanged from 0001193125-14-184830:mdna:10]

[0001193125-14-398478:mdna:11]
|  | • |  | the expansion of our manufacturing capacity, including into new geographies; |

[0001193125-14-398478:mdna:12]
[same as prior period, unchanged from 0001193125-14-184830:mdna:12]

[0001193125-14-398478:mdna:13]
|  | • |  | our ability, and the ability of our customers and suppliers, to respond successfully to technological or industry developments; |

[0001193125-14-398478:mdna:14]
[same as prior period, unchanged from 0001193125-14-184830:mdna:14]

[0001193125-14-398478:mdna:15]
|  | • |  | our ability to increase our penetration of existing markets and to penetrate new markets; |

[0001193125-14-398478:mdna:16]
[same as prior period, unchanged from 0001193125-14-184830:mdna:16]

[0001193125-14-398478:mdna:17]
|  | • |  | trends in the optical communications, industrial lasers, and sensors markets, including trends to outsource the production of components used in those markets; |

[0001193125-14-398478:mdna:18]
[same as prior period, unchanged from 0001193125-14-184830:mdna:18]

[0001193125-14-398478:mdna:19]
[same as prior period, unchanged from 0001193125-14-184830:mdna:19]

[0001193125-14-398478:mdna:20]
[same as prior period, unchanged from 0001193125-14-184830:mdna:20]

[0001193125-14-398478:mdna:21]
We provide
advanced optical packaging and precision optical, electro-mechanical and electronic manufacturing services to original equipment manufacturers (OEMs) of complex products such as optical communication components, modules and sub-systems, industrial
lasers and sensors. We offer a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging,
integration, final assembly and test. Although, we focus primarily on low-volume production of a wide variety of high complexity products, which we refer to as “low-volume, high-mix”, we also have the capability to accommodate high-volume
production. Based on our experience with, and positive feedback we have received from our customers, we believe we are a global leader in providing these services to the optical communications, industrial lasers, automotive, and sensors markets.

[0001193125-14-398478:mdna:22]
Our customer base includes companies in complex industries that require advanced precision manufacturing capabilities such as
optical communications, industrial lasers, automotive, and sensors. The products that we manufacture for our OEM customers include selective switching products; tunable transponders and transceivers; active optical cables; solid state, diode-pumped,
gas and fiber lasers; and sensors. In many cases, we are the sole outsourced manufacturing partner used by our customers for the products that we produce for them.

[0001193125-14-398478:mdna:23]
We also design and fabricate application-specific crystals; prisms; mirrors; laser components; substrates, and other custom and standard borosilicate, clear fused quartz, and synthetic fused silica glass
products. We incorporate our customized optics and glass into many of the products we manufacture for our OEM customers, and we also sell customized optics and glass in the merchant market.

[0001193125-14-398478:mdna:24]
Audit Committee Investigation

[0001193125-14-398478:mdna:25]
During the fourth quarter of our fiscal year
2014, the Company identified violations of our policies and procedures relating to finished goods held in our warehouse on behalf of our customers (the Company refers to finished goods held in our warehouse on behalf of our customers as consignment
goods or consignment inventory and when the finished goods are sold the Company refers to the related revenue as consignment revenue). Specifically, the Company identified violations related to certain employees in one business unit colluding to
cause the improper recognition of revenues for certain goods by recording consignment revenues on goods before such goods were finished.

[0001193125-14-398478:mdna:26]
In connection with the above, the Audit Committee of our Board of Directors initiated an investigation concerning various accounting cut-off issues in fiscal year 2014, specifically the transfer of
unfinished goods to consignment inventory and other inventory cut-off considerations. The investigation found certain process weaknesses concerning the potential to invoice unfinished goods held under consignment arrangements and the need for
certain remedial measures.

[0001193125-14-398478:mdna:27]
The Company is working to complete the following recommended remedial measures that were
identified through the investigation:

[0001193125-14-398478:mdna:28]
|  | • |  | Mandatory training on revenue recognition policies and related cut-off procedures; and |

[0001193125-14-398478:mdna:29]
|  | • |  | Process improvements, including certain controls relating to finished goods recorded as consignment inventory. |

[0001193125-14-398478:mdna:30]
The investigation did not find executive officer involvement in the identified violations.

[0001193125-14-398478:mdna:31]
Impact of the Findings of the Investigation on the Financial Statements and Internal Control

[0001193125-14-398478:mdna:32]
Based on an analysis prepared by the Company, it was determined that the potential exposure relating to the control deficiencies
identified during the investigation was not material to our consolidated financial statements for the fiscal year 2014. Further, the Company assessed these control deficiencies to be significant deficiencies rather than material weaknesses on the
basis that there was no executive officer involvement in the violations, the potential misstatements were not material to the financial statements and the Audit Committee was actively involved in the investigation.

[0001193125-14-398478:mdna:33]
Consignment Revenue Recognition

[0001193125-14-398478:mdna:34]
Subsequent to completion of the Audit Committee’s investigation, the Company evaluated its accounting practices surrounding
consignment inventory and consignment revenue. Based on that evaluation, the Company determined that for certain volume supply agreements with our customers not all of the revenue recognition criteria prescribed by U.S. GAAP and Staff Accounting
Bulletin No. 104 had been met at the time revenue was recorded. Specifically, the Company misapplied the guidance when assessing the terms of these agreements with respect to when title and risk of loss transfers to our customers. As a result,
the Company determined that certain sales previously recognized did not qualify for revenue recognition in the periods in which they were recognized. The Company has evaluated the impact of the errors on both a quantitative and qualitative basis
under the guidance of ASC 250-Accounting Changes and Error Corrections and determined that the errors did not have a material impact to the previously issued consolidated financial statements. The Company has assessed the control implications and
concluded that the deficiency constituted a material weakness in internal control over financial reporting (refer to Part I, Item 4 for additional information).

[0001193125-14-398478:mdna:35]
Had adjustments in the prior period been made to reflect revenues in the appropriate quarter in the three months ended September 27, 2013, revenues for the three months ended September 27, 2013
would have been $2.7 million higher.

[0001193125-14-398478:mdna:36]
[same as prior period, unchanged from 0001193125-14-184830:mdna:24]

[0001193125-14-398478:mdna:37]
We suspended production at all of our manufacturing facilities in Thailand from October 17, 2011 through November 14, 2011 due to severe flooding in Thailand. We never resumed, and have
permanently ceased, production at our Chokchai facility. We submitted claims for losses to our insurance companies, all of which have been settled as of fiscal year 2014.

[0001193125-14-398478:mdna:38]
In the three months ended September 27, 2013, we received from our insurers an interim payment of $6.6 million against our claim for owned inventory losses and owned equipment losses which we
recognized as income related to flooding.

[0001193125-14-398478:mdna:39]
During the three months ended September 27, 2013, we fulfilled our obligations
to a customer in accordance with the settlement agreement entered into during the third quarter of fiscal 2013 by making a final cash payment to such customer of $3.8 million and by transferring equipment, with an aggregate value of $2.3 million, to
such customer. Accordingly, our liability to such customer for any and all flood-related losses has been satisfied in full. Also, we fulfilled our obligations to a customer’s insurers in accordance with the settlement agreement entered into
during the fourth quarter of fiscal 2013 by making a final payment of $2.2 million. Accordingly, our liability to such insurer for damages to customer-owned inventory, which occurred during the flooding, has been satisfied in full. We also entered
into other flood-related settlements of $0.05 million during the three months ended September 27, 2013.

[0001193125-14-398478:mdna:40]
[same as prior period, unchanged from 0001193125-14-184830:mdna:30]

[0001193125-14-398478:mdna:41]
Our total revenues increased by $17.8 million, or 10.4%, to $189.3 million for the three months ended September 26, 2014, compared
with $171.6 million for the three months ended September 27, 2013. The increase was primarily due to an increase in our customers’ demand for both optical and non-optical communications manufacturing services during the three months ended
September 26, 2014.

[0001193125-14-398478:mdna:42]
We believe our ability to expand our relationships with existing customers and attract new customers
is due to a number of factors, including our broad range of complex engineering and manufacturing service offerings, flexible low-cost manufacturing platform, process optimization capabilities, advanced supply chain management, excellent customer
service, and experienced management team. While we expect the prices we charge for our manufactured products to decrease over time (partly as a result of competitive market forces), we still believe we will be able to maintain favorable pricing for
our services because of our ability to reduce cycle time, adjust our product mix by focusing on more complicated products, improve product quality and yields, and reduce material costs for the products we manufacture. We believe these capabilities
have enabled us to help our OEM customers reduce their manufacturing costs while maintaining or improving the design, quality, reliability, and delivery times for their products.

[0001193125-14-398478:mdna:43]
[same as prior period, unchanged from 0001193125-14-184830:mdna:33]

[0001193125-14-398478:mdna:44]
We generate revenues from three geographic
regions: North America, Asia-Pacific and Europe. Revenues are attributed to a particular geographic area based on the bill-to location of our customers, notwithstanding that our customers may ultimately ship their products to end customers in a
different geographic region. Virtually all of our revenues are derived from our manufacturing facilities in Asia-Pacific.

[0001193125-14-398478:mdna:45]
The percentage of our revenues generated from bill-to location outside of North America
decreased from 54.1% in the three months ended September 27, 2013 to 51.9% in the three months ended September 26, 2014, primarily because of a decrease in sales volume of our customers in those regions. We expect that the portion of our
future revenues attributable to customers in regions outside North America will decrease as compared with the first quarter of fiscal year 2015.

[0001193125-14-398478:mdna:46]
[same as prior period, unchanged from 0001193125-14-184830:mdna:36]

[0001193125-14-398478:mdna:47]
|  |  | Three Months Ended |  |
|  |  | September 26,2014 |  |  | September 27,2013 |  |
| North America |  |  | 48.1 | % |  |  | 45.9 | % |
| Asia-Pacific |  |  | 41.1 |  |  |  | 33.8 |  |
| Europe |  |  | 10.8 |  |  |  | 20.3 |  |
|  |  |  | 100.0 | % |  |  | 100.0 | % |

[0001193125-14-398478:mdna:48]
[same as prior period, unchanged from 0001193125-14-184830:mdna:38]

[0001193125-14-398478:mdna:49]
We enter into supply agreements with our customers which generally have an initial term of up to three years, subject to automatic renewals for subsequent one-year terms unless expressly terminated.
Although there are no minimum purchase requirements in our supply agreements, our customers do provide us with rolling forecasts of their demand requirements. Our supply agreements generally include provisions for pricing and periodic review of
pricing, consignment of our customer’s unique production equipment to us, and the sharing of benefits from cost-savings derived from our efforts. We are generally required to purchase materials, which may include long lead-time materials and
materials that are subject to minimum order quantities and/or non-cancelable or non-returnable terms, to meet the stated demands of our customers. After procuring materials, we manufacture products for our customers based on purchase orders that
contain terms regarding product quantities, delivery locations and delivery dates. Our customers generally are obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by
our customers within a specified period of time, or are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under our contracts. Once materials are designated as either
excess or obsolete inventory, our customers are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products.

[0001193125-14-398478:mdna:50]
[same as prior period, unchanged from 0001193125-14-184830:mdna:40]

[0001193125-14-398478:mdna:51]
The key components of our cost of revenues are material
costs, employee costs, and infrastructure-related costs. Material costs generally represent the majority of our cost of revenues. Several of the materials we require to manufacture products for our customers are customized for their products and
often sourced from a single supplier or in some cases, our own subsidiaries. Shortages from sole-source suppliers due to yield loss, quality concerns, and capacity constraints, among other factors, may increase our expenses and negatively impact our
gross profit margin or total revenues in a given quarter. Material costs include scrap material. Historically, scrap rate diminishes during a product’s life cycle due to process, fixturing and test improvement, and optimization.

[0001193125-14-398478:mdna:52]
A second significant element of our cost of revenues is employee costs, including indirect employee costs related to design;
configuration and optimization of manufacturing processes for our customers, quality testing; materials testing and other engineering services; and direct costs related to our manufacturing employees. Direct employee costs include employee salaries,
insurance and benefits, merit-based bonuses, recruitment, training and retention. Historically, our employee costs have increased primarily due to increases in the number of employees necessary to support our growth and, to a lesser extent, costs to
recruit, train and retain employees. Our cost of revenues are significantly impacted by salary levels in Thailand and the PRC; the fluctuation of the Thai baht and RMB against our functional currency, the U.S. dollar; and our ability to retain our
employees. We expect our employee costs to increase as wages continue to increase in Thailand and the PRC. For example, effective April 1, 2012, the Thai government increased minimum daily wages from 215 Thai baht to 300 Thai baht. Wage
increases may impact our ability to sustain our competitive advantage and may reduce our profit margin. We seek to mitigate these cost increases through improvements in employee productivity, employee retention, and asset utilization.

[0001193125-14-398478:mdna:53]
Our infrastructure costs are comprised of depreciation, utilities, facilities management, and overhead costs. Most of our facility leases
are long-term agreements. Our depreciation costs include buildings and fixed assets, primarily at our Pinehurst campus in Thailand, and capital equipment located at each of our manufacturing locations.

[0001193125-14-398478:mdna:54]
During the three months ended September 26, 2014, discretionary merit-based bonus
awards were made to our non-executive employees. Charges included in cost of revenues for bonus distributions to non-executive employees were $0.6 million and $0.6 million for the three months ended September 26, 2014 and September 27,
2013, respectively.

[0001193125-14-398478:mdna:55]
Share-based compensation expense included in cost of revenues was $0.4 million and $0.3 million for the
three months ended September 26, 2014 and September 27, 2013, respectively.

[0001193125-14-398478:mdna:56]
We expect to incur significant
incremental costs of revenue as a result of our continued diversification into the industrial lasers, automotive, and sensors markets and other end-markets outside of the optical communications market or our further development of customized optics
and glass manufacturing capabilities. We also expect to incur incremental costs of revenue as a result of our planned expansion into new geographic markets, though we are not able to determine the amount of these incremental expenses.

[0001193125-14-398478:mdna:57]
[same as prior period, unchanged from 0001193125-14-184830:mdna:47]

[0001193125-14-398478:mdna:58]
Our SG&A expenses primarily consist of corporate employee costs for sales and marketing, general and administrative, and other support personnel, including research and development expenses related to
the design of customized optics and glass, travel expenses, legal and other professional fees, share-based compensation expense, and other general expenses not related to cost of revenues. In fiscal year 2015, we expect our SG&A expenses will
increase on an absolute dollar basis and remain flat as a percentage of revenue compared with fiscal year 2014.

[0001193125-14-398478:mdna:59]
The
compensation committee of our board of directors approved a fiscal year 2015 executive incentive plan with quantitative objectives, based on achieving certain revenue and non-GAAP earnings per share targets for our fiscal year ending June 26,
2015, as well as qualitative objectives, based on achieving individual performance goals. Bonuses under our fiscal year 2015 executive incentive plan are payable after the end of fiscal year 2015. In fiscal year 2014, the compensation committee
approved a fiscal year 2014 executive incentive plan with quantitative objectives, based on achieving certain revenue and gross margin percentage targets for our fiscal year ended June 27, 2014, as well as qualitative objectives, based on
achieving individual performance goals. Bonuses under our fiscal 2014 executive incentive plan were payable as of September 26, 2014. Discretionary merit-based bonus awards were also available to our non-executive employees and were payable as
of September 26, 2014.

[0001193125-14-398478:mdna:60]
Charges included in SG&A expenses for bonus distributions to non-executive and executive
employees were $0.7 million and $0.8 million for the three months ended September 26, 2014 and September 27, 2013, respectively.

[0001193125-14-398478:mdna:61]
Share-based compensation expense included in SG&A expenses was $1.5 million and $1.3 million for the three months ended September 26, 2014 and September 27, 2013, respectively.

[0001193125-14-398478:mdna:62]
[same as prior period, unchanged from 0001193125-14-184830:mdna:52]

[0001193125-14-398478:mdna:63]
[same as prior period, unchanged from 0001193125-14-184830:mdna:53]

[0001193125-14-398478:mdna:64]
[same as prior period, unchanged from 0001193125-14-184830:mdna:54]

[0001193125-14-398478:mdna:65]
As a result of our international operations, we are exposed to foreign exchange risk arising from various currency exposures primarily with respect to the Thai baht. Although a majority of our total
revenues is denominated in U.S. dollars, a substantial portion of our payroll plus certain other operating expenses are incurred and paid in Thai baht. The exchange rates between the Thai baht and the U.S. dollar have fluctuated substantially in
recent years and may continue to fluctuate substantially in the future. We report our financial results in U.S. dollars and our results of operations have been and may continue to be negatively impacted owing to appreciation of the Thai baht against
the U.S. dollar. Smaller portions of our expenses are incurred in a variety of other currencies, including RMB, Canadian dollars, Euros, and Japanese yen, the appreciation of which may also negatively impact our financial results.

[0001193125-14-398478:mdna:66]
In addition, we are exposed to foreign exchange risk in connection with the credit facility and cross currency swap arrangements we
entered into with TMB Bank Public Company Limited (the “Bank”) in May 2011 for the construction of Pinehurst Building 6. The terms of the contract with the Bank provide the following facilities: (1) a term loan facility for up to Thai
baht 960 million (equal to $30.0 million) with a fixed interest rate of 5.28% per annum, (2) a hedging facility for currency interest rate swaps with a notional amount of $30.0 million, and (3) a settlement limit of Thai baht
65 million, subject to certain terms and conditions as set forth therein. As of March 30, 2012, we had drawn down the entire $30.0 million available under the term loan facility. Borrowings and interest under the term loan have been
scheduled to be repaid on a quarterly basis between September 2011 and March 2017. As of September 26, 2014, we had outstanding borrowings under the term loan facility of $15.0 million. Under the terms of the cross currency swap arrangement
amounts drawn in Thai baht were converted to U.S. dollars for repayment by us on a quarterly basis at the floating rate of 3-month London Interbank Offered Rate (LIBOR) plus 2.8% per annum.

[0001193125-14-398478:mdna:67]
In order to manage the risks arising from fluctuations in foreign currency exchange rates, we use derivative financial instruments. We
may enter into short-term forward exchange currency contracts or put option contracts to help manage currency exposures associated with certain assets and liabilities, primarily short-term obligations. The forward exchange contracts and put option
contracts generally had original maturities of one to six months, and no forward exchange contract or put option contract has had an original maturity greater than one year. All foreign currency exchange contracts are recognized on the condensed
consolidated balance sheet at fair value. As we do not apply hedge accounting to these instruments, the change in the fair value of the derivatives are recorded in foreign exchange (loss) gain, net on the condensed consolidated statements of
operations and comprehensive income. The gains and losses on our forward exchange contracts and put option contracts generally offset losses and gains on the assets, liabilities, and transactions economically hedged and, accordingly, generally do
not subject us to the risk of significant accounting losses.

[0001193125-14-398478:mdna:68]
We had foreign currency assets and liabilities in Thai baht and
RMB as follows:

[0001193125-14-398478:mdna:69]
|  |  | As of September 26, 2014 |  |  | As of June 27, 2014 |  |
| (amount in thousands, except percentages) |  | Currency |  |  | $ |  |  | % |  |  | Currency |  |  | $ |  |  | % |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 543,378 |  |  | $ | 16,828 |  |  |  | 62.3 |  |  |  | 1,536,887 |  |  | $ | 47,318 |  |  |  | 79.6 |  |
| RMB |  |  | 62,640 |  |  |  | 10,184 |  |  |  | 37.7 |  |  |  | 74,813 |  |  |  | 12,156 |  |  |  | 20.4 |  |
| Total |  |  |  |  |  | $ | 27,012 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 59,474 |  |  |  | 100.0 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht |  |  | 819,498 |  |  | $ | 25,379 |  |  |  | 85.5 |  |  |  | 735,490 |  |  | $ | 22,644 |  |  |  | 81.1 |  |
| RMB |  |  | 26,445 |  |  |  | 4,299 |  |  |  | 14.5 |  |  |  | 32,512 |  |  |  | 5,283 |  |  |  | 18.9 |  |
| Total |  |  |  |  |  | $ | 29,678 |  |  |  | 100.0 |  |  |  |  |  |  | $ | 27,927 |  |  |  | 100.0 |  |

[0001193125-14-398478:mdna:70]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other
current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses and other payables. We manage our exposure to fluctuations in foreign exchange rates by the use of foreign currency contracts and offsetting assets and
liabilities denominated in the same currency in accordance with management’s policy. As of September 26, 2014 and June 27, 2014, there were $30.0 million and $15.0 million in put option contracts outstanding on the Thai baht payables,
respectively.

[0001193125-14-398478:mdna:71]
The RMB assets represent cash and cash equivalents, accounts receivable and other current assets. The RMB
liabilities represent trade accounts payable, accrued expenses and other payables. As of September 26, 2014 and June 27, 2014, we did not have any selling RMB to U.S. dollar forward or put option contracts.

[0001193125-14-398478:mdna:72]
As of September 26, 2014 and June 27, 2014, unrealized gain from the fair market
value of derivatives amounted to $0.2 million and $0.1 million, respectively.

[0001193125-14-398478:mdna:73]
Currency Regulation and Dividend
Distribution

[0001193125-14-398478:mdna:74]
[same as prior period, unchanged from 0001193125-14-184830:mdna:64]

[0001193125-14-398478:mdna:75]
[same as prior period, unchanged from 0001193125-14-184830:mdna:65]

[0001193125-14-398478:mdna:76]
[same as prior period, unchanged from 0001193125-14-184830:mdna:66]

[0001193125-14-398478:mdna:77]
[same as prior period, unchanged from 0001193125-14-184830:mdna:67]

[0001193125-14-398478:mdna:78]
Under the Exchange Rules, RMB is freely convertible into foreign currencies for current account items, including the distribution of dividends, interest payments, trade and service-related foreign
exchange transactions. However, conversion of RMB for capital account items, such as direct investments, loans, security investments, and repatriation of investments, is still subject to the approval of SAFE.

[0001193125-14-398478:mdna:79]
Under the Administration Rules, foreign-invested enterprises may only buy, sell, or remit foreign currencies at banks authorized to
conduct foreign exchange business after providing valid commercial documents and relevant supporting documents and, in the case of capital account item transactions, obtaining approval from SAFE. Capital investments by foreign-invested enterprises
outside of the PRC are also subject to limitations, which include approvals by the Ministry of Commerce, SAFE, and the State Development and Reform Commission.

[0001193125-14-398478:mdna:80]
[same as prior period, unchanged from 0001193125-14-184830:mdna:70]

[0001193125-14-398478:mdna:81]
On January 5, 2007, SAFE
promulgated the Detailed Rules for Implementing the Measures for the Administration on Individual Foreign Exchange, or the Implementation Rules. Under the Implementation Rules, PRC citizens who are granted share options by an overseas
publicly-listed company are required, through a PRC agent or PRC subsidiary of such overseas publicly-listed company, to register with SAFE and complete certain other procedures.

[0001193125-14-398478:mdna:82]
In addition, the General Administration of Taxation has issued circulars concerning employee share options. Under these circulars, our
employees working in the PRC who exercise share options will be subject to PRC individual income tax. Our PRC subsidiary has obligations to file documents related to employee share options with relevant tax authorities and withhold individual income
taxes of those employees who exercise their share options.

[0001193125-14-398478:mdna:83]
Furthermore, our transfer of funds to our subsidiaries in Thailand
and the PRC are each subject to approval by governmental authorities in case of an increase in registered capital, or subject to registration with governmental authorities in case of a shareholder loan. These limitations on the flow of funds between
our subsidiaries and us could restrict our ability to act in response to changing market conditions.

[0001193125-14-398478:mdna:84]
[same as prior period, unchanged from 0001193125-14-184830:mdna:74]

[0001193125-14-398478:mdna:85]
[same as prior period, unchanged from 0001193125-14-184830:mdna:75]

[0001193125-14-398478:mdna:86]
Throughout the period of
our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption is currently available to us
from July 2010 through June 2015 on income generated from the manufacture

[0001193125-14-398478:mdna:87]
of products at Pinehurst Building 5 and from July 2012 through June 2020 on income generated from the manufacture of products at Pinehurst Building 6. Such preferential tax treatment is
contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in Thailand for at least 15 years. Additionally, in December
2011, the Thailand Revenue Department announced a reduction in corporate income tax rates for tax periods beginning on or after January 1, 2012. As a result of the announcement, corporate income tax rates for our Thai subsidiary were reduced
from 30% in fiscal year 2012 to 23% in fiscal year 2013, and 20% in fiscal year 2014 and fiscal year 2015.

[0001193125-14-398478:mdna:88]
Our subsidiary in
China had been granted a tax privilege to reduce its corporate income tax rate from 25% to 15% but the privilege expired on December 31, 2013. Currently, we are preparing an application to renew this tax privilege and plan to submit it in
fiscal year 2015; however, there can be no assurances that such tax privilege will be renewed.

[0001193125-14-398478:mdna:89]
Critical Accounting Policies and Use of
Estimates

[0001193125-14-398478:mdna:90]
We prepare our condensed consolidated financial statements in conformity with U.S. GAAP, which requires us to
make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent liabilities on the date of the condensed consolidated financial statements and the reported amounts of revenues and expenses
during the financial reporting period. We continually evaluate these estimates and assumptions based on the most recently available information, our own historical experience and on various other assumptions that we believe to be reasonable under
the circumstances, the results form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Because the use of estimates is an integral component of the financial reporting
process, actual results could differ from those estimates. Some of our accounting policies require higher degrees of judgment than others in their application. We consider the policies discussed below to be critical to an understanding of our
condensed consolidated financial statements, as their application places the most significant demands on our management’s judgment.

[0001193125-14-398478:mdna:91]
Our critical accounting policies are disclosed in our Annual Report on Form 10-K for the fiscal year ended June 27, 2014. There were no material changes to our critical accounting policies during the
three months ended September 26, 2014.

[0001193125-14-398478:mdna:92]
[same as prior period, unchanged from 0001193125-14-184830:mdna:81]

[0001193125-14-398478:mdna:93]
The following table sets forth a summary of our unaudited condensed consolidated statements of operations and comprehensive income. Note
that period-to-period comparisons of operating results should not be relied upon as indicative of future performance.

[0001193125-14-398478:mdna:94]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 26,2014 |  |  | September 27,2013 |  |
| Revenues |  | $ | 189,325 |  |  | $ | 171,551 |  |
| Cost of revenues |  |  | (168,819 | ) |  |  | (152,906 | ) |
| Gross profit |  |  | 20,506 |  |  |  | 18,645 |  |
| Selling, general and administrative expenses |  |  | (8,737 | ) |  |  | (6,694 | ) |
| Income related to flooding, net |  |  | — |  |  |  | 6,597 |  |
| Operating income |  |  | 11,769 |  |  |  | 18,548 |  |
| Interest income |  |  | 374 |  |  |  | 364 |  |
| Interest expense |  |  | (133 | ) |  |  | (206 | ) |
| Foreign exchange (loss) gain, net |  |  | (106 | ) |  |  | 1,088 |  |
| Other income |  |  | 103 |  |  |  | 184 |  |
| Income before income taxes |  |  | 12,007 |  |  |  | 19,978 |  |
| Income tax expense |  |  | (971 | ) |  |  | (781 | ) |
| Net income |  |  | 11,036 |  |  |  | 19,197 |  |
| Other comprehensive income |  |  | — |  |  |  | — |  |
| Net comprehensive income |  | $ | 11,036 |  |  | $ | 19,197 |  |

[0001193125-14-398478:mdna:95]
The following table sets forth a summary of our unaudited condensed consolidated statements
of operations and comprehensive income as a percentage of total revenues for the periods indicated.

[0001193125-14-398478:mdna:96]
|  |  | Three Months Ended |  |
|  |  | September 26,2014 |  |  | September 27,2013 |  |
| Revenues |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of revenues |  |  | (89.2 | ) |  |  | (89.1 | ) |
| Gross profit |  |  | 10.8 |  |  |  | 10.9 |  |
| Selling, general and administrative expenses |  |  | (4.6 | ) |  |  | (3.9 | ) |
| Income related to flooding, net |  |  | — |  |  |  | 3.8 |  |
| Operating income |  |  | 6.2 |  |  |  | 10.8 |  |
| Interest income |  |  | 0.2 |  |  |  | 0.2 |  |
| Interest expense |  |  | (0.1 | ) |  |  | (0.1 | ) |
| Foreign exchange (loss) gain, net |  |  | (0.1 | ) |  |  | 0.6 |  |
| Other income |  |  | 0.1 |  |  |  | 0.1 |  |
| Income before income taxes |  |  | 6.3 |  |  |  | 11.6 |  |
| Income tax expense |  |  | (0.5 | ) |  |  | (0.4 | ) |
| Net income |  |  | 5.8 |  |  |  | 11.2 |  |
| Other comprehensive income |  |  | — |  |  |  | — |  |
| Net comprehensive income |  |  | 5.8 | % |  |  | 11.2 | % |

[0001193125-14-398478:mdna:97]
[same as prior period, unchanged from 0001193125-14-184830:mdna:86]

[0001193125-14-398478:mdna:98]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 26,2014 |  |  | September 27,2013 |  |
| Optical communications |  | $ | 135,256 |  |  | $ | 124,528 |  |
| Lasers, sensors and other |  |  | 54,069 |  |  |  | 47,023 |  |
| Total |  | $ | 189,325 |  |  | $ | 171,551 |  |

[0001193125-14-398478:mdna:99]
[same as prior period, unchanged from 0001193125-14-184830:mdna:88]

[0001193125-14-398478:mdna:100]
Comparison of Three Months Ended September 26, 2014 with Three Months
Ended September 27, 2013

[0001193125-14-398478:mdna:101]
[same as prior period, unchanged from 0001193125-14-184830:mdna:91]

[0001193125-14-398478:mdna:102]
Our total revenues increased by $17.8 million, or 10.4%, to $189.3 million for the three months ended September 26, 2014, compared
with $171.6 million for the three months ended September 27, 2013. This increase was primarily due to an increase in customers’ demand for both optical and non-optical communications manufacturing services during the three months ended
September 26, 2014. Revenues from optical communications products represented 71.4% of our total revenues for the three months ended September 26, 2014, compared to 72.6% for the three months ended September 27, 2013.

[0001193125-14-398478:mdna:103]
[same as prior period, unchanged from 0001193125-14-184830:mdna:94]

[0001193125-14-398478:mdna:104]
Our cost of revenues increased by $15.9 million, or 10.4%, to $168.8 million, or 89.2% of total revenues, for the three months ended September 26, 2014, compared with $152.9 million, or 89.1% of
total revenues, for the three months ended September 27, 2013. This increase was primarily due to an increase in production costs which were in-line with an increase in revenues during the three months ended September 26, 2014. Cost of
revenues also included share-based compensation expense of $0.4 million for the three months ended September 26, 2014, compared with $0.3 million for the three months ended September 27, 2013.

[0001193125-14-398478:mdna:105]
[same as prior period, unchanged from 0001193125-14-184830:mdna:97]

[0001193125-14-398478:mdna:106]
Our gross profit increased by $1.9 million, or 10.0%, to $20.5 million, or 10.8% of total revenues, for the three months ended
September 26, 2014, compared with $18.6 million, or 10.9% of total revenues, for the three months ended September 27, 2013. The slight decrease in gross profit margin during the three months ended September 26, 2014, compared with the
three months ended September 27, 2013, was related to an increase in production costs during the three months ended September 26, 2014.

[0001193125-14-398478:mdna:107]
[same as prior period, unchanged from 0001193125-14-184830:mdna:100]

[0001193125-14-398478:mdna:108]
Our SG&A expenses increased by $2.0 million, or
30.5%, to $8.7 million, or 4.6% of total revenues, for the three months ended September 26, 2014, compared with $6.7 million, or 3.9% of total revenues, for the three months ended September 27, 2013. Our SG&A expenses increased in
absolute dollars and as a percentage of revenue due primarily to $1.6 million of investigation costs relating to our Audit Committee investigation concerning various accounting cut-off issues in fiscal year 2014. We also recorded share-based
compensation charges of $1.5 million for the three months ended September 26, 2014, compared with $1.3 million for the three months ended September 27, 2013.

[0001193125-14-398478:mdna:109]
[same as prior period, unchanged from 0001193125-14-184830:mdna:103]

[0001193125-14-398478:mdna:110]
In the three months ended September 26,
2014, we did not have income related to flooding. In the three months ended September 27, 2013, we recognized $6.6 million of income related to flooding, which consisted of an interim payment from our insurers against our claim for owned and
customer-owned inventory losses.

[0001193125-14-398478:mdna:111]
[same as prior period, unchanged from 0001193125-14-184830:mdna:106]

[0001193125-14-398478:mdna:112]
Our operating income decreased by $6.8 million to $11.8 million, or 6.2% of total revenues, for the three months ended September 26,
2014, compared with $18.5 million, or 10.8% of total revenues, for the three months ended September 27, 2013.

[0001193125-14-398478:mdna:113]
[same as prior period, unchanged from 0001193125-14-184830:mdna:109]

[0001193125-14-398478:mdna:114]
Our interest income remained flat at $0.4 million for the three months ended September 26, 2014, compared with $0.4 million for the three months ended September 27, 2013.

[0001193125-14-398478:mdna:115]
[same as prior period, unchanged from 0001193125-14-184830:mdna:111]

[0001193125-14-398478:mdna:116]
Our interest expense decreased by $0.1 million to $0.1 million for the three months ended September 26, 2014, compared with $0.2 million for the three months ended September 27, 2013. These
decreases were due to a decrease in our average long-term loan balances resulting from repayment during the fourth quarter of fiscal year 2014.

[0001193125-14-398478:mdna:117]
[same as prior period, unchanged from 0001193125-14-184830:mdna:113]

[0001193125-14-398478:mdna:118]
We recorded income before income taxes of
$12.0 million for the three months ended September 26, 2014, compared with income before income taxes of $20.0 million for the three months ended September 27, 2013.

[0001193125-14-398478:mdna:119]
[same as prior period, unchanged from 0001193125-14-184830:mdna:115]

[0001193125-14-398478:mdna:120]
Our provision for income tax reflects an effective tax
rate of 8.1% for the three months ended September 26, 2014, compared with an effective tax rate of 3.9% for the three months ended September 27, 2013. The increase was primarily due to the fact that the income tax rate of our subsidiary in
China increased from 15% in the three months ended September 27, 2013 to 25% in the three months ended September 26, 2014 due to the expiration of a tax privilege, as well as the fact that we had lower net income during the three months
ended September 26, 2014 from income related to flooding of $6.6 million that was not subject to income tax.

[0001193125-14-398478:mdna:121]
Net
income.

[0001193125-14-398478:mdna:122]
We recorded net income of $11.0 million, or 5.8% of total revenues, for the three months ended September 26,
2014, compared with $19.2 million, or 11.2% of total revenues, for the three months ended September 27, 2013.

[0001193125-14-398478:mdna:123]
Liquidity and Capital Resources

[0001193125-14-398478:mdna:124]
[same as prior period, unchanged from 0001193125-14-184830:mdna:122]

[0001193125-14-398478:mdna:125]
We primarily finance our operations through cash flow from operations. As of September 26, 2014 and September 27, 2013, we had cash and cash equivalents approximately $244.7 million and $163.9
million, respectively and outstanding debt approximately $15.0 million and $26.5 million, respectively.

[0001193125-14-398478:mdna:126]
Our cash and cash
equivalents, which primarily consist of cash on hand, demand deposits and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted average interest rate on our cash and
cash equivalents for the three months ended September 26, 2014 and for the three months ended September 27, 2013 was 0.6% and 1.0%, respectively.

[0001193125-14-398478:mdna:127]
As of September 26, 2014, all claims that we submitted to our insurance companies for flood related losses have been settled. For the three months ended September 27, 2013, we recognized $6.6
million of income related to flooding which consisted of an interim payment from our insurers against our claim for owned and customer-owned inventory losses.

[0001193125-14-398478:mdna:128]
In the three months ended September 27, 2013, we fulfilled our obligations to a customer in accordance with the settlement agreement entered into during the third quarter of fiscal 2013 by making a
final cash payment to such customer of $3.8 million and by transferring equipment, with an aggregate value of $2.3 million, to such customer. Accordingly, our liability to such customer for any and all flood-related losses has been satisfied in
full. Also, during the three months ended September 27, 2013, we fulfilled our obligations to a customer’s insurers in accordance with the settlement agreement entered into during the fourth quarter of fiscal 2013 by making a final payment
of $2.2 million. Accordingly, our liability to such insurer for damages to customer-owned inventory, which occurred during the flooding, has been satisfied in full. We also entered into other flood-related settlements of $0.05 million during the
three months ended September 27, 2013.

[0001193125-14-398478:mdna:129]
We believe that our current cash and cash equivalents, cash flow from operations,
and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss
in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001193125-14-398478:mdna:130]
We believe that our current manufacturing capacity is
sufficient to meet anticipated production requirements for at least the next 12 months. We maintain a long-term credit facility associated with construction of production facilities at our Pinehurst campus in Thailand that will come due within the
next 30 months. We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay this obligation.

[0001193125-14-398478:mdna:131]
The following table shows our net cash provided by operating activities, net cash used in investing activities and net cash used in financing activities for the periods indicated:

[0001193125-14-398478:mdna:132]
|  |  | Three Months Ended |  |
| (amount in thousands) |  | September 26,2014 |  |  | September 27,2013 |  |
| Net cash provided by operating activities |  | $ | 15,833 |  |  | $ | 18,137 |  |
| Net cash used in investing activities |  | $ | (1,464 | ) |  | $ | (1,253 | ) |
| Net cash used in financing activities |  | $ | (3,257 | ) |  | $ | (2,464 | ) |
| Net increase in cash and cash equivalents |  | $ | 11,112 |  |  | $ | 14,420 |  |
| Cash and cash equivalents, beginning of period |  | $ | 233,477 |  |  | $ | 149,716 |  |
| Cash and cash equivalents, end of period |  | $ | 244,683 |  |  | $ | 163,860 |  |

[0001193125-14-398478:mdna:133]
[same as prior period, unchanged from 0001193125-14-184830:mdna:133]

[0001193125-14-398478:mdna:134]
Net cash provided by operating activities decreased by $2.3 million, or 12.7%, to $15.8 million for the three months ended September 26, 2014, compared with net cash provided by operating activities
of $18.1 million for the three months ended September 27, 2013. This decrease was primarily due to a decrease of $8.1 million in net income from operations resulting from a decrease in proceeds from insurers for inventory losses related to
flooding, offset by a decrease of $6.0 million in flood-related liabilities to third parties.

[0001193125-14-398478:mdna:135]
[same as prior period, unchanged from 0001193125-14-184830:mdna:135]

[0001193125-14-398478:mdna:136]
Net cash used in investing activities increased by $0.2 million, or 16.8%, to $1.5 million for the three months ended September 26,
2014, compared with net cash used in investing activities of $1.3 million for the three months ended September 27, 2013. This increase in net cash used in investing activities was primarily due to an increase 0.2 million in purchase of
property, plant, and equipment to support the operations.

[0001193125-14-398478:mdna:137]
[same as prior period, unchanged from 0001193125-14-184830:mdna:137]

[0001193125-14-398478:mdna:138]
Net cash used in financing activities increased by $0.8 million, or 32.2%, to $3.3 million for the three months ended September 26,
2014, compared with $2.5 million for the three months ended September 27, 2013. This increase in net cash used in financing activities was primarily due to the payment of debt issuance costs of $1.6 million from our credit facility agreement,
offset by a decrease in repayment of the Company’s long-term loans due to the payment to extinguish one of the long-term loan contracts in April 2014.

[0001193125-14-398478:mdna:139]
[same as prior period, unchanged from 0001193125-14-184830:mdna:139]

[0001193125-14-398478:mdna:140]
We have not entered into
any financial guarantees or other commitments to guarantee the payment obligations of any third parties. In addition, we have not entered into any derivative contracts that are not reflected in our condensed consolidated financial statements.
Furthermore, we do not have any retained or contingent interest in assets transferred to an unconsolidated entity that serves as credit, liquidity or market risk support to such entity. We also do not have any variable interest in any unconsolidated
entity that provides financing, liquidity, market risk or credit support to us or engages in leasing, hedging or research and development services with us.

[0001193125-14-398478:mdna:141]
[same as prior period, unchanged from 0001193125-14-184830:mdna:141]

[0001193125-14-398478:mdna:142]
See Note 2 of Notes to Unaudited
Condensed Consolidated Financial Statements for recent accounting pronouncements that could have an effect on us.
