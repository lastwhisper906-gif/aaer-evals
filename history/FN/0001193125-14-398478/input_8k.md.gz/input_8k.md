# FN 8-K — 0001193125-14-394096 filed 2014-11-03

## item codes, every 8-K on or before 2014-11-05

- 2014-11-03 0001193125-14-394096 — 2.02, 5.02, 9.01
- 2014-10-23 0001193125-14-380217 — 5.02
- 2014-10-16 0001193125-14-373872 — 2.02, 9.01
- 2014-10-02 0001193125-14-362200 — 3.01
- 2014-10-01 0001193125-14-360772 — 1.01
- 2014-09-25 0001193125-14-353261 — 8.01, 9.01
- 2014-05-29 0001193125-14-217512 — 1.01, 8.01, 9.01
- 2014-05-23 0001193125-14-211510 — 1.01, 2.03, 9.01
- 2014-05-05 0001193125-14-182534 — 2.02, 9.01
- 2014-02-26 0001193125-14-069722 — 5.02, 9.01
- 2014-02-07 0001193125-14-040845 — 5.02
- 2014-02-03 0001193125-14-033060 — 2.02, 9.01
- 2013-12-20 0001193125-13-480989 — 5.07
- 2013-11-04 0001193125-13-425279 — 2.02, 5.02, 9.01
- 2013-08-12 0001193125-13-330996 — 2.02, 5.02, 9.01
- 2013-04-29 0001193125-13-182301 — 2.02, 9.01
- 2013-03-15 0001193125-13-110310 — 1.01, 8.01, 9.01
- 2013-02-28 0001193125-13-084122 — 5.02
- 2013-02-08 0001193125-13-044619 — 1.01, 9.01
- 2013-02-04 0001193125-13-036734 — 2.02, 9.01
- 2012-12-21 0001193125-12-513038 — 5.02, 5.07
- 2012-11-05 0001193125-12-451987 — 2.02, 5.02, 9.01
- 2012-08-20 0001193125-12-362020 — 2.02, 5.02, 8.01, 9.01
- 2012-05-07 0001193125-12-215072 — 2.02, 9.01
- 2012-03-16 0001193125-12-119634 — 5.02
- 2012-02-16 0001193125-12-065309 — 5.02
- 2012-02-06 0001193125-12-041431 — 2.02, 5.02, 9.01
- 2012-01-17 0001193125-12-013861 — 5.02, 9.01
- 2011-12-15 0001193125-11-342473 — 5.07
- 2011-11-07 0001193125-11-299845 — 2.02, 8.01, 9.01
- 2011-10-24 0001193125-11-277916 — 7.01
- 2011-10-21 0001193125-11-277444 — 5.02
- 2011-10-21 0001193125-11-276599 — 7.01
- 2011-08-16 0001193125-11-224363 — 1.01, 2.03, 9.01
- 2011-08-15 0001193125-11-223184 — 2.02, 9.01
- 2011-02-17 0001193125-11-039084 — 5.02
- 2011-01-31 0001193125-11-018930 — 2.02, 5.02, 9.01
- 2010-12-23 0001193125-10-287631 — 5.02, 5.07, 9.01
- 2010-11-04 0001193125-10-248153 — 5.02
- 2010-11-01 0001193125-10-242695 — 2.02, 9.01
- 2010-10-19 0001193125-10-231700 — 5.02
- 2010-08-18 0001193125-10-192335 — 2.02, 9.01

## late-filing notifications on or before 2014-11-05

- 2014-09-10 0001193125-14-338054 — NT 10-K, for the period ended 2014-06-27

## item 2.02 — earnings release, exhibit 99.1

[0001193125-14-394096:8k_2_02:1]
EX-99.1
2
d814341dex991.htm
EX-99.1

[0001193125-14-394096:8k_2_02:2]
EX-99.1

[0001193125-14-394096:8k_2_02:3]
Exhibit 99.1

[0001193125-14-394096:8k_2_02:4]
Fabrinet Announces First Quarter 2015 Financial Results

[0001193125-14-394096:8k_2_02:5]
BANGKOK, Thailand – November 3, 2014 – Fabrinet (NYSE: FN), a leading provider of advanced optical packaging and precision optical,
electro-mechanical and electronic manufacturing services to original equipment manufacturers of complex products, today announced its financial results for the first quarter ended September 26, 2014.

[0001193125-14-394096:8k_2_02:6]
Fabrinet reported total revenue of $189.3 million for the first quarter of fiscal 2015, an increase of 10.3% compared to total revenue of $171.6 million for
the comparable period in fiscal 2014. GAAP net income for the first quarter of fiscal 2015 was $11.0 million, or $0.31 per diluted share, compared to GAAP net income of $19.2 million, or $0.55 per diluted share, in the first quarter of fiscal 2014.
Non-GAAP net income in the first quarter of fiscal 2015 was $14.5 million, or $0.41 per diluted share, an increase of 2.1% compared to non-GAAP net income of $14.2 million, or $0.40 per diluted share, in the same period a year ago.

[0001193125-14-394096:8k_2_02:7]
Tom Mitchell, Chief Executive Officer of Fabrinet, said, “Fiscal 2015 is off to a strong start and I am particularly pleased with the contribution from
new programs in the quarter. While the demand environment remains uncertain, I am confident that our focus on total customer satisfaction will enable us to deliver on our financial goals for the fiscal year.”

[0001193125-14-394096:8k_2_02:8]
Business Outlook

[0001193125-14-394096:8k_2_02:9]
Based on information available as of
November 3, 2014, Fabrinet is issuing guidance for the second quarter of fiscal 2015 as follows:

[0001193125-14-394096:8k_2_02:10]
Fabrinet expects second quarter revenue to be in the
range of $181 million to $185 million. GAAP net income per share is expected to be in the range of $0.22 to $0.24 with expected non-GAAP net income per share of $0.37 to $0.39, based on approximately 36 million fully diluted shares outstanding.

[0001193125-14-394096:8k_2_02:11]
Conference Call Information

[0001193125-14-394096:8k_2_02:12]
| What: |  | Fabrinet First Quarter 2015 Financial Results Conference Call |
| When: |  | Monday, November 3, 2014 |
| Time: |  | 5:00 p.m. ET |
| Live Call: |  | (888) 357-3694, domestic |
|  |  | (253) 237-1137, international |
|  |  | Passcode: 25412759 |
| Replay: |  | (855) 859-2056, domestic |
|  |  | (404) 537-3406, international |
|  |  | Passcode: 25412759 |
| Webcast: |  | http://investor.fabrinet.com (live and replay) |

[0001193125-14-394096:8k_2_02:13]
This press release and any other information related to the call will also be posted on Fabrinet’s website at
http://investor.fabrinet.com. A recorded version of this webcast will be available approximately two hours after the call and will be archived on Fabrinet’s website for a period of one year.

[0001193125-14-394096:8k_2_02:14]
About Fabrinet

[0001193125-14-394096:8k_2_02:15]
Fabrinet is a leading provider of
advanced optical packaging and precision optical, electro-mechanical, and electronic manufacturing services to original equipment manufacturers of complex products, such as optical communication components, modules and subsystems, industrial lasers
and sensors. Fabrinet offers a broad range of advanced optical and electro-mechanical capabilities across the entire manufacturing process, including process design and engineering, supply chain management, manufacturing, advanced packaging,
integration, final assembly and test. Fabrinet focuses on production of high complexity products in any mix and any volume. Fabrinet maintains engineering and manufacturing resources and facilities in Thailand, the People’s Republic of China
and the United States. For more information visit: www.fabrinet.com.

[0001193125-14-394096:8k_2_02:16]
Forward-Looking Statements

[0001193125-14-394096:8k_2_02:17]
Use of Non-GAAP Financials

[0001193125-14-394096:8k_2_02:18]
The Company refers to the
non-GAAP financial measures cited above in making operating decisions because they provide meaningful supplemental information regarding the Company’s ongoing operational performance. Non-GAAP net income excludes share-based compensation
expenses, investigation costs and income related to flooding. We have excluded these items in order to enhance investors’ understanding of our ongoing operations. The use of these non-GAAP financial measures has material limitations because
they should not be used to evaluate our company without reference to their corresponding GAAP financial measures. As such, we compensate for these material limitations by using these non-GAAP financial measures in conjunction with GAAP financial
measures.

[0001193125-14-394096:8k_2_02:19]
These non-GAAP financial measures are used to: (1) measure company performance against historical results, (2) facilitate comparisons
to our competitors’ operating results, and (3) allow greater transparency with respect to information used by management in financial and operational decision making. In addition, these non-GAAP financial measures are used to measure
company performance for the purposes of determining employee incentive plan compensation.

[0001193125-14-394096:8k_2_02:20]
SOURCE: Fabrinet

[0001193125-14-394096:8k_2_02:21]
Investor Contact:

[0001193125-14-394096:8k_2_02:22]
Jennifer Predmore

[0001193125-14-394096:8k_2_02:23]
215-428-1797

[0001193125-14-394096:8k_2_02:24]
ir@fabrinet.com

[0001193125-14-394096:8k_2_02:25]
Fabrinet

[0001193125-14-394096:8k_2_02:26]
Consolidated Balance Sheets

[0001193125-14-394096:8k_2_02:27]
As of September 26,
2014 and June 27, 2014

[0001193125-14-394096:8k_2_02:28]
| (in thousands of U.S. dollars, except share data) |  | September 26,2014 |  |  | June 27,2014 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 244,683 |  |  | $ | 233,477 |  |
| Trade accounts receivable, net |  |  | 107,943 |  |  |  | 101,168 |  |
| Inventory, net |  |  | 128,672 |  |  |  | 124,570 |  |
| Deferred tax assets |  |  | 1,642 |  |  |  | 1,561 |  |
| Prepaid expenses |  |  | 1,638 |  |  |  | 1,691 |  |
| Other current assets |  |  | 2,467 |  |  |  | 2,010 |  |
| Total current assets |  |  | 487,045 |  |  |  | 464,477 |  |
| Non-current assets |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  |  | 98,058 |  |  |  | 97,244 |  |
| Intangibles, net |  |  | 51 |  |  |  | 72 |  |
| Deferred tax assets |  |  | 1,775 |  |  |  | 1,775 |  |
| Deferred debt issuance costs |  |  | 2,559 |  |  |  | 989 |  |
| Total non-current assets |  |  | 102,443 |  |  |  | 100,080 |  |
| Total assets |  | $ | 589,488 |  |  | $ | 564,557 |  |
| Liabilities and Shareholders’ Equity |  |  |  |  |  |  |  |  |
| Current liabilities |  |  |  |  |  |  |  |  |
| Long-term loans from bank, current portion |  | $ | 6,000 |  |  | $ | 6,000 |  |
| Trade accounts payable |  |  | 101,783 |  |  |  | 94,853 |  |
| Income tax payable |  |  | 1,484 |  |  |  | 1,024 |  |
| Accrued payroll, bonus and related expenses |  |  | 10,919 |  |  |  | 8,612 |  |
| Accrued expenses |  |  | 5,238 |  |  |  | 4,345 |  |
| Other payables |  |  | 8,445 |  |  |  | 5,795 |  |
| Total current liabilities |  |  | 133,869 |  |  |  | 120,629 |  |
| Non-current liabilities |  |  |  |  |  |  |  |  |
| Long-term loans from bank, non-current portion |  |  | 9,000 |  |  |  | 10,500 |  |
| Deferred tax liability |  |  | 1,128 |  |  |  | 1,040 |  |
| Severance liabilities |  |  | 4,671 |  |  |  | 4,453 |  |
| Other non-current liabilities |  |  | 1,268 |  |  |  | 1,099 |  |
| Total non-current liabilities |  |  | 16,067 |  |  |  | 17,092 |  |
| Total liabilities |  |  | 149,936 |  |  |  | 137,721 |  |
| Commitments and contingencies |  |  |  |  |  |  |  |  |
| Shareholders’ equity |  |  |  |  |  |  |  |  |
| Preferred shares (5,000,000 shares authorized, $0.01 par value; no shares issued and outstanding as of September 26, 2014 and June 27, 2014) |  |  | — |  |  |  | — |  |
| Ordinary shares (500,000,000 shares authorized, $0.01 par value; 35,319,755 shares and 35,152,772 shares issued and outstanding as of September 26, 2014 and June 27, 2014, respectively) |  |  | 353 |  |  |  | 352 |  |
| Additional paid-in capital |  |  | 82,561 |  |  |  | 80,882 |  |
| Retained earnings |  |  | 356,638 |  |  |  | 345,602 |  |
| Total shareholders’ equity |  |  | 439,552 |  |  |  | 426,836 |  |
| Total Liabilities and Shareholders’ Equity |  | $ | 589,488 |  |  | $ | 564,557 |  |

[0001193125-14-394096:8k_2_02:29]
Fabrinet

[0001193125-14-394096:8k_2_02:30]
Consolidated Statements of Operations and Comprehensive Income

[0001193125-14-394096:8k_2_02:31]
For the three months ended September 26, 2014 and September 27, 2013

[0001193125-14-394096:8k_2_02:32]
|  |  | Three Months Ended |  |
|  |  | September 26, |  |  | September 27, |  |
| (in thousands of U.S. dollars, except share data) |  | 2014 |  |  | 2013 |  |
| Revenues |  | $ | 189,325 |  |  | $ | 171,551 |  |
| Cost of revenues |  |  | (168,819 | ) |  |  | (152,906 | ) |
| Gross profit |  |  | 20,506 |  |  |  | 18,645 |  |
| Selling, general and administrative expenses |  |  | (8,737 | ) |  |  | (6,694 | ) |
| Income related to flooding |  |  | — |  |  |  | 6,597 |  |
| Operating income |  |  | 11,769 |  |  |  | 18,548 |  |
| Interest income |  |  | 374 |  |  |  | 364 |  |
| Interest expense |  |  | (133 | ) |  |  | (206 | ) |
| Foreign exchange (loss) gain, net |  |  | (106 | ) |  |  | 1,088 |  |
| Other income |  |  | 103 |  |  |  | 184 |  |
| Income before income taxes |  |  | 12,007 |  |  |  | 19,978 |  |
| Income tax expense |  |  | (971 | ) |  |  | (781 | ) |
| Net income |  |  | 11,036 |  |  |  | 19,197 |  |
| Other comprehensive income |  |  | — |  |  |  | — |  |
| Net comprehensive income |  | $ | 11,036 |  |  | $ | 19,197 |  |
| Earnings per share |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.31 |  |  | $ | 0.55 |  |
| Diluted |  | $ | 0.31 |  |  | $ | 0.55 |  |
| Weighted average number of ordinary shares outstanding (thousands of shares) |  |  |  |  |  |  |  |  |
| Basic |  |  | 35,230 |  |  |  | 34,674 |  |
| Diluted |  |  | 35,587 |  |  |  | 35,138 |  |

[0001193125-14-394096:8k_2_02:33]
Fabrinet

[0001193125-14-394096:8k_2_02:34]
Consolidated Statements of Cash Flows

[0001193125-14-394096:8k_2_02:35]
For the three
months ended September 26, 2014 and September 27, 2013

[0001193125-14-394096:8k_2_02:36]
|  |  | Three Months Ended |  |
|  |  | September 26, |  |  | September 27, |  |
| (in thousands of U.S. dollars) |  | 2014 |  |  | 2013 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income for the period |  | $ | 11,036 |  |  | $ | 19,197 |  |
| Adjustments to reconcile net income to net cash provided by operating activities |  |  |  |  |  |  |  |  |
| Depreciation |  |  | 2,887 |  |  |  | 2,509 |  |
| Amortization of intangibles |  |  | 21 |  |  |  | 28 |  |
| Gain on disposal of property, plant and equipment |  |  | (46 | ) |  |  | — |  |
| Income related to flooding |  |  | — |  |  |  | (6,597 | ) |
| Proceeds from insurers for inventory losses related to flooding |  |  | — |  |  |  | 6,597 |  |
| Reversal of allowance for doubtful accounts |  |  | (1 | ) |  |  | (53 | ) |
| Unrealized gain on exchange rate and fair value of derivative |  |  | (208 | ) |  |  | (808 | ) |
| Share-based compensation |  |  | 1,867 |  |  |  | 1,563 |  |
| Deferred income tax |  |  | 6 |  |  |  | 438 |  |
| Other non-cash expenses |  |  | 387 |  |  |  | 218 |  |
| Inventory obsolescence |  |  | 515 |  |  |  | — |  |
| Changes in operating assets and liabilities |  |  |  |  |  |  |  |  |
| Trade accounts receivable |  |  | (6,773 | ) |  |  | (7,348 | ) |
| Inventory |  |  | (4,617 | ) |  |  | (5,566 | ) |
| Other current assets and non-current assets |  |  | (404 | ) |  |  | 60 |  |
| Trade accounts payable |  |  | 6,930 |  |  |  | 13,189 |  |
| Income tax payable |  |  | 460 |  |  |  | 124 |  |
| Other current liabilities and non-current liabilities |  |  | 3,773 |  |  |  | 550 |  |
| Liabilities to third parties due to flood losses |  |  | — |  |  |  | (5,964 | ) |
| Net cash provided by operating activities |  |  | 15,833 |  |  |  | 18,137 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchase of property, plant and equipment |  |  | (1,510 | ) |  |  | (1,253 | ) |
| Proceeds from insurers in settlement of claims related to flood damage |  |  | 46 |  |  |  | — |  |
| Net cash used in investing activities |  |  | (1,464 | ) |  |  | (1,253 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Payment of debt issuance costs |  |  | (1,570 | ) |  |  | — |  |
| Repayment of long-term loans from bank |  |  | (1,500 | ) |  |  | (2,417 | ) |
| Proceeds from issuance of ordinary shares under employee share option plans |  |  | 2 |  |  |  | 43 |  |
| Withholding tax related to net share settlement of restricted share units |  |  | (189 | ) |  |  | (90 | ) |
| Net cash used in financing activities |  |  | (3,257 | ) |  |  | (2,464 | ) |
| Net increase in cash and cash equivalents |  | $ | 11,112 |  |  | $ | 14,420 |  |
| Movement in cash and cash equivalents |  |  |  |  |  |  |  |  |
| Cash and cash equivalents at beginning of period |  | $ | 233,477 |  |  | $ | 149,716 |  |
| Increase in cash and cash equivalents |  |  | 11,112 |  |  |  | 14,420 |  |
| Effect of exchange rate on cash and cash equivalents |  |  | 94 |  |  |  | (276 | ) |
| Cash and cash equivalents at end of period |  | $ | 244,683 |  |  | $ | 163,860 |  |

[0001193125-14-394096:8k_2_02:37]
Fabrinet

[0001193125-14-394096:8k_2_02:38]
Reconciliation of GAAP measures to non-GAAP measures

[0001193125-14-394096:8k_2_02:39]
(in thousands of U.S. dollars, except per share data)

[0001193125-14-394096:8k_2_02:40]
(unaudited)

[0001193125-14-394096:8k_2_02:41]
|  |  | Three Months Ended |  |
|  |  | September 26, |  |  | September 26, |  |  | September 27, |  |  | September 27, |  |
|  |  | 2014 |  |  | 2014 |  |  | 2013 |  |  | 2013 |  |
|  |  | Net income |  |  | Diluted EPS |  |  | Net income |  |  | Diluted EPS |  |
| GAAP measures |  |  | 11,036 |  |  |  | 0.31 |  |  |  | 19,197 |  |  |  | 0.55 |  |
| Items reconciling GAAP net income & EPS to non-GAAP net income & EPS: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Related to cost of revenues: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 368 |  |  |  | 0.01 |  |  |  | 307 |  |  |  | 0.01 |  |
| Total related to gross profit |  |  | 368 |  |  |  | 0.01 |  |  |  | 307 |  |  |  | 0.01 |  |
| Related to selling, general and administrative expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expenses |  |  | 1,499 |  |  |  | 0.04 |  |  |  | 1,256 |  |  |  | 0.04 |  |
| Investigation costs |  |  | 1,600 |  |  |  | 0.05 |  |  |  | — |  |  |  | — |  |
| Total related to selling, general and administrative expenses |  |  | 3,099 |  |  |  | 0.09 |  |  |  | 1,256 |  |  |  | 0.04 |  |
| Related to other incomes and other expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Income related to flooding |  |  | — |  |  |  | — |  |  |  | (6,597 | ) |  |  | (0.19 | ) |
| Total related to other incomes and other expenses |  |  | — |  |  |  | — |  |  |  | (6,597 | ) |  |  | (0.19 | ) |
| Total related to net income & EPS |  |  | 3,467 |  |  |  | 0.10 |  |  |  | (5,034 | ) |  |  | (0.14 | ) |
| Non-GAAP measures |  |  | 14,503 |  |  |  | 0.41 |  |  |  | 14,163 |  |  |  | 0.40 |  |
| Shares used in computing diluted net income per share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted shares |  |  |  |  |  |  | 35,587 |  |  |  |  |  |  |  | 35,138 |  |
| Non-GAAP diluted shares |  |  |  |  |  |  | 35,587 |  |  |  |  |  |  |  | 35,138 |  |

## item 5.02 — body, verbatim

[0001193125-14-394096:8k_body:1]
Item 5.02

[0001193125-14-394096:8k_body:2]
Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001193125-14-394096:8k_body:3]
Fiscal 2014 Executive Incentive Plan

[0001193125-14-394096:8k_body:4]
On
October 29, 2014, the Compensation Committee (the “Committee”) of the Company’s board of directors adopted an executive incentive plan (the “Bonus Plan”) for the Company’s fiscal year ending June 26, 2015
(“fiscal 2015”). The Bonus Plan is an incentive program designed to motivate participants to achieve the Company’s financial and other performance objectives, and to reward them for their achievements when those objectives are met.
All of the Company’s executive officers pursuant to Section 16 of the Securities Exchange Act of 1934 are eligible to participate in the Bonus Plan (individually, a “Participant,” and collectively, the “Participants”).
The Bonus Plan provides for a target bonus amount expressed as a percentage of a Participant’s annual base salary, as set forth in the table below. The maximum bonus that a Participant may receive under the Bonus Plan is two times such
Participant’s target bonus.

[0001193125-14-394096:8k_body:5]
Executive Officer

[0001193125-14-394096:8k_body:6]
Fiscal 2015 Target Bonus
(as a % of Base Salary)

[0001193125-14-394096:8k_body:7]
Fiscal 2015 Maximum Bonus
(as a % of Base Salary)

[0001193125-14-394096:8k_body:8]
David T. Mitchell

[0001193125-14-394096:8k_body:9]
120%

[0001193125-14-394096:8k_body:10]
240%

[0001193125-14-394096:8k_body:11]
Dr. Harpal Gill

[0001193125-14-394096:8k_body:12]
95%

[0001193125-14-394096:8k_body:13]
190%

[0001193125-14-394096:8k_body:14]
Toh-Seng Ng

[0001193125-14-394096:8k_body:15]
70%

[0001193125-14-394096:8k_body:16]
140%

[0001193125-14-394096:8k_body:17]
John Marchetti

[0001193125-14-394096:8k_body:18]
65%

[0001193125-14-394096:8k_body:19]
130%

[0001193125-14-394096:8k_body:20]
The amount of bonus actually paid to a Participant will be based 20% on achievement of fiscal 2015 individual
performance objectives, 40% on achievement of a fiscal 2015 revenue target and 40% on achievement of a fiscal 2015 non-GAAP earnings per share target. As achievement of each financial target is considered independently from the other, the Company
must meet a threshold for each factor in order for a Participant to receive any credit for that factor. If the Company achieves 100% of a target financial metric, bonuses would be paid out at 100% of target with respect to that financial metric
component. If the Company achieves 90% of a target financial metric, bonuses would be paid out at 50% of target with respect to that financial metrics component. If the Company achieves 105% of a target financial metric, maximum bonuses would be
paid out at 200% of target with respect to that financial metric component. Achievement of the financial targets at levels between 90% and 100% and between 100% and 105% will result in a bonus amount that is scaled in a linear fashion. In its sole
discretion, the Committee shall determine if the fiscal 2015 individual performance objectives have been met and may award up to 200% of target for that component of the bonus.

[0001193125-14-394096:8k_body:21]
Performance Share Unit Plan

[0001193125-14-394096:8k_body:22]
The
Committee also approved a plan to grant restricted share units (“RSUs”) in fiscal 2016 to the Company’s executive officers, the amount of which may be increased based on the Company’s achievement of a fiscal 2015 revenue target,
as described below. The number of shares to be granted under each RSU award will be equal to (a) the dollar value of the executive’s award (which may be increased based on the Company’s financial performance), divided by (b) the
higher of (i) the fair market value of an ordinary share of the Company on the grant date or (ii) $10.00, with the quotient rounded down to the nearest whole share. If the Company does not achieve the fiscal 2015 revenue target, a minimum
dollar value of RSUs will be granted. If the Company achieves the fiscal 2015 revenue target, two times the minimum dollar value of RSUs will be granted. If the Company achieves 105%

[0001193125-14-394096:8k_body:23]
or more of the fiscal 2015 revenue target, three times the minimum dollar value of RSUs will be granted. Achievement of the fiscal 2015 revenue target at levels between 100% and 105% will result
in a dollar value of RSUs being granted based on linear interpolation. The RSUs will be scheduled to vest as to 25% of the shares on each of the one-, two-, three- and four-year anniversaries of the grant date, subject to the executive’s
continued employment or other service. The table below sets forth the minimum, target and maximum dollar value of RSUs that may be awarded to the Company’s executive officers.

[0001193125-14-394096:8k_body:24]
Executive Officer

[0001193125-14-394096:8k_body:25]
Minimum Dollar Value of
RSUs

[0001193125-14-394096:8k_body:26]
Target Dollar Value of
RSUs

[0001193125-14-394096:8k_body:27]
Maximum Dollar Value
of RSUs

[0001193125-14-394096:8k_body:28]
Mr. Mitchell

[0001193125-14-394096:8k_body:29]
$

[0001193125-14-394096:8k_body:30]
1,367,000

[0001193125-14-394096:8k_body:31]
$

[0001193125-14-394096:8k_body:32]
2,733,000

[0001193125-14-394096:8k_body:33]
$

[0001193125-14-394096:8k_body:34]
4,100,000

[0001193125-14-394096:8k_body:35]
Dr. Gill

[0001193125-14-394096:8k_body:36]
$

[0001193125-14-394096:8k_body:37]
500,000

[0001193125-14-394096:8k_body:38]
$

[0001193125-14-394096:8k_body:39]
1,000,000

[0001193125-14-394096:8k_body:40]
$

[0001193125-14-394096:8k_body:41]
1,500,000

[0001193125-14-394096:8k_body:42]
Mr. Ng

[0001193125-14-394096:8k_body:43]
$

[0001193125-14-394096:8k_body:44]
457,000

[0001193125-14-394096:8k_body:45]
$

[0001193125-14-394096:8k_body:46]
913,000

[0001193125-14-394096:8k_body:47]
$

[0001193125-14-394096:8k_body:48]
1,370,000

[0001193125-14-394096:8k_body:49]
Mr. Marchetti

[0001193125-14-394096:8k_body:50]
$

[0001193125-14-394096:8k_body:51]
243,000

[0001193125-14-394096:8k_body:52]
$

[0001193125-14-394096:8k_body:53]
485,000

[0001193125-14-394096:8k_body:54]
$

[0001193125-14-394096:8k_body:55]
728,000
