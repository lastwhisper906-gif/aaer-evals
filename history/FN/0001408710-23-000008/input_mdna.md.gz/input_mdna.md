# FN MD&A — 0001408710-23-000008


## mdna

[0001408710-23-000008:mdna:1]
[same as prior period, unchanged from 0001408710-22-000060:mdna:1]

[0001408710-23-000008:mdna:2]
[same as prior period, unchanged from 0001408710-22-000060:mdna:2]

[0001408710-23-000008:mdna:3]
[same as prior period, unchanged from 0001408710-22-000060:mdna:3]

[0001408710-23-000008:mdna:4]
[same as prior period, unchanged from 0001408710-22-000060:mdna:4]

[0001408710-23-000008:mdna:5]
•our expectation that the portion of our revenues attributable to customers in regions outside of North America for the remainder of fiscal year 2023 will be in line with the portion of revenues attributable to such customers during the six months ended December 30, 2022;

[0001408710-23-000008:mdna:6]
[same as prior period, unchanged from 0001408710-22-000060:mdna:6]

[0001408710-23-000008:mdna:7]
[same as prior period, unchanged from 0001408710-22-000060:mdna:7]

[0001408710-23-000008:mdna:8]
[same as prior period, unchanged from 0001408710-22-000060:mdna:8]

[0001408710-23-000008:mdna:9]
[same as prior period, unchanged from 0001408710-22-000060:mdna:9]

[0001408710-23-000008:mdna:10]
[same as prior period, unchanged from 0001408710-22-000060:mdna:10]

[0001408710-23-000008:mdna:11]
[same as prior period, unchanged from 0001408710-22-000060:mdna:11]

[0001408710-23-000008:mdna:12]
[same as prior period, unchanged from 0001408710-22-000060:mdna:12]

[0001408710-23-000008:mdna:13]
[same as prior period, unchanged from 0001408710-22-000060:mdna:13]

[0001408710-23-000008:mdna:14]
[same as prior period, unchanged from 0001408710-22-000060:mdna:14]

[0001408710-23-000008:mdna:15]
[same as prior period, unchanged from 0001408710-22-000060:mdna:15]

[0001408710-23-000008:mdna:16]
[same as prior period, unchanged from 0001408710-22-000060:mdna:16]

[0001408710-23-000008:mdna:17]
[same as prior period, unchanged from 0001408710-22-000060:mdna:17]

[0001408710-23-000008:mdna:18]
[same as prior period, unchanged from 0001408710-22-000060:mdna:18]

[0001408710-23-000008:mdna:19]
[same as prior period, unchanged from 0001408710-22-000060:mdna:19]

[0001408710-23-000008:mdna:20]
[same as prior period, unchanged from 0001408710-22-000060:mdna:20]

[0001408710-23-000008:mdna:21]
[same as prior period, unchanged from 0001408710-22-000060:mdna:21]

[0001408710-23-000008:mdna:22]
[same as prior period, unchanged from 0001408710-22-000060:mdna:22]

[0001408710-23-000008:mdna:23]
[same as prior period, unchanged from 0001408710-22-000060:mdna:23]

[0001408710-23-000008:mdna:24]
[same as prior period, unchanged from 0001408710-22-000060:mdna:24]

[0001408710-23-000008:mdna:25]
[same as prior period, unchanged from 0001408710-22-000060:mdna:25]

[0001408710-23-000008:mdna:26]
In the three months ended December 30, 2022, our subsidiary in Thailand relaxed certain precautionary measures in accordance with the termination of Thailand’s emergency decree related to COVID-19, which lowered the status of COVID-19 to a communicable disease under surveillance. In China, the relaxation of restrictions across the country has coincided with a surge in COVID-19 infections, which peaked in the last week of December. While the surge in China significantly disrupted our operations there, our operating results were not significantly affected due to the successful execution of our contingency plan and various precautionary measures we have undertaken. However, any worsening of the COVID-19 surge in China or the international pandemic may result in more stringent measures being implemented by local authorities, such as shutting down our manufacturing facilities, which would have a significant negative impact on our operations.

[0001408710-23-000008:mdna:27]
[same as prior period, unchanged from 0001408710-22-000060:mdna:27]

[0001408710-23-000008:mdna:28]
[same as prior period, unchanged from 0001408710-22-000060:mdna:28]

[0001408710-23-000008:mdna:29]
[same as prior period, unchanged from 0001408710-22-000060:mdna:29]

[0001408710-23-000008:mdna:30]
•Given our $527.6 million in cash, cash equivalents and short-term investments, and our total debt of approximately $18.3 million as of December 30, 2022, we believe we are in a solid position from a capital and financial resources perspective. We expect that current cash and cash equivalent balances and short-term investments, and cash flows generated from operations will be sufficient to meet our domestic and international working capital needs and other capital and liquidity requirements for at least the next 12 months.

[0001408710-23-000008:mdna:31]
[same as prior period, unchanged from 0001408710-22-000060:mdna:31]

[0001408710-23-000008:mdna:32]
We believe we are able to expand our relationships with existing customers and attract new customers due to, among other factors, our broad range of complex engineering and manufacturing service offerings, flexible low-cost manufacturing platform, process optimization capabilities, advanced supply chain management, excellent customer service, and experienced management team. Although we expect the prices we charge for our manufactured products to decrease over time (partly as a result of competitive market forces), we believe we will be able to continue to maintain favorable pricing for our services because of our ability to reduce cycle time, adjust our product mix by focusing on more complicated products, improve product quality and yields, and reduce material costs for the products we manufacture. We believe these capabilities have enabled us to help our OEM customers reduce their manufacturing costs while maintaining or improving the design, quality, reliability, and delivery times for their products.

[0001408710-23-000008:mdna:33]
We expect that disruptions in our supply chain and fluctuations in the availability of parts and materials will continue to have a significant impact on our ability to generate revenue, despite strong demand from our customers. These supply chain disruptions have been exacerbated by recent global events, such as (1) COVID-related lockdowns in China, which caused freight and logistics issues and unforeseen delays, and (2) the armed conflict between Russia and Ukraine. While we have no significant direct business in Ukraine or Russia, the conflict has negatively impacted demand from some of our automotive customers that have other suppliers in the region. Moreover, if the facilities of our subsidiary in Fuzhou, China were to be locked down due to the recent surge in COVID-19 cases, we would be negatively impacted since we and some of our customers rely on the optics components that are manufactured in such facilities. Furthermore, in some cases, our efforts to identify and secure alternative supply chain sources has resulted in our customers or their end customers requiring requalification and validation of components, a process that can often be lengthy and has negatively impacted the timing of our revenue. We expect these supply constraints to continue, and potentially worsen, for at least the next 12 months.

[0001408710-23-000008:mdna:34]
[same as prior period, unchanged from 0001408710-22-000060:mdna:35]

[0001408710-23-000008:mdna:35]
[same as prior period, unchanged from 0001408710-22-000060:mdna:36]

[0001408710-23-000008:mdna:36]
The percentage of our revenues generated from a bill-to location outside of North America decreased from 56.4% in the three months ended December 24, 2021 to 51.5% in the three months ended December 30, 2022, primarily because the increase in sales to our customers outside of North America was lower than the increase in sales to our customers in North America.

[0001408710-23-000008:mdna:37]
The percentage of our revenues generated from a bill-to location outside of North America decreased from 55.5% in the six months ended December 24, 2021 to 49.2% in the six months ended December 30, 2022, primarily because the increase in sales to our customers outside of North America was lower than the increase in sales to our customers in North America.

[0001408710-23-000008:mdna:38]
Based on the short and medium-term indications and forecasts from our customers, we expect that the portion of our future revenues attributable to customers in regions outside North America for the remainder of fiscal year 2023 will be in line with the portion of revenues attributable to such customers during the six months ended December 30, 2022.

[0001408710-23-000008:mdna:39]
[same as prior period, unchanged from 0001408710-22-000060:mdna:39]

[0001408710-23-000008:mdna:40]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30, 2022 |  | December 24, 2021 |  | December 30, 2022 |  | December 24, 2021 |
| North America | 48.5 | % |  | 43.6 | % |  | 50.8 | % |  | 44.5 | % |
| Asia-Pacific and others | 43.1 |  |  | 39.2 |  |  | 40.5 |  |  | 38.6 |  |
| Europe | 8.4 |  |  | 17.2 |  |  | 8.7 |  |  | 16.9 |  |
|  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |

[0001408710-23-000008:mdna:41]
[same as prior period, unchanged from 0001408710-22-000060:mdna:41]

[0001408710-23-000008:mdna:42]
We enter into supply agreements with our customers which generally have an initial term of up to three years, subject to automatic renewals for subsequent one-year terms unless expressly terminated. Although there are no minimum purchase requirements in our supply agreements, our customers provide us with rolling forecasts of their demand requirements. Our

[0001408710-23-000008:mdna:43]
supply agreements generally include provisions for pricing and periodic review of pricing, consignment of our customer’s unique production equipment to us, and the sharing of benefits from cost-savings derived from our efforts. We are generally required to purchase materials, which may include long lead-time materials and materials that are subject to minimum order quantities and/or non-cancelable or non-returnable terms, to meet the stated demands of our customers. After procuring materials, we manufacture products for our customers based on purchase orders that contain terms regarding product quantities, delivery locations and delivery dates. Our customers generally are obligated to purchase finished goods that we have manufactured according to their demand requirements. Materials that are not consumed by our customers within a specified period of time, or that are no longer required due to a product’s cancellation or end-of-life, are typically designated as excess or obsolete inventory under our contracts. Once materials are designated as either excess or obsolete inventory, our customers are typically required to purchase such inventory from us even if they have chosen to cancel production of the related products. The excess or obsolete inventory is shipped to the customer and revenue is recognized upon shipment.

[0001408710-23-000008:mdna:44]
[same as prior period, unchanged from 0001408710-22-000060:mdna:44]

[0001408710-23-000008:mdna:45]
[same as prior period, unchanged from 0001408710-22-000060:mdna:45]

[0001408710-23-000008:mdna:46]
[same as prior period, unchanged from 0001408710-22-000060:mdna:46]

[0001408710-23-000008:mdna:47]
[same as prior period, unchanged from 0001408710-22-000060:mdna:47]

[0001408710-23-000008:mdna:48]
[same as prior period, unchanged from 0001408710-22-000060:mdna:48]

[0001408710-23-000008:mdna:49]
[same as prior period, unchanged from 0001408710-22-000060:mdna:49]

[0001408710-23-000008:mdna:50]
[same as prior period, unchanged from 0001408710-22-000060:mdna:50]

[0001408710-23-000008:mdna:51]
[same as prior period, unchanged from 0001408710-22-000060:mdna:51]

[0001408710-23-000008:mdna:52]
[same as prior period, unchanged from 0001408710-22-000060:mdna:52]

[0001408710-23-000008:mdna:53]
[same as prior period, unchanged from 0001408710-22-000060:mdna:53]

[0001408710-23-000008:mdna:54]
[same as prior period, unchanged from 0001408710-22-000060:mdna:54]

[0001408710-23-000008:mdna:55]
[same as prior period, unchanged from 0001408710-22-000060:mdna:55]

[0001408710-23-000008:mdna:56]
[same as prior period, unchanged from 0001408710-22-000060:mdna:56]

[0001408710-23-000008:mdna:57]
|  | As of December 30, 2022 |  | As of June 24, 2022 |
| (amount in thousands, except percentages) | Currency |  | $ |  | % |  | Currency |  | $ |  | % |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 817,723 |  |  | $ | 23,661 |  |  | 70.9 | % |  | 753,924 |  |  | $ | 21,213 |  |  | 64.0 | % |
| RMB | 26,669 |  |  | 3,829 |  |  | 11.5 |  |  | 34,382 |  |  | 5,132 |  |  | 15.5 |  |
| GBP | 4,883 |  |  | 5,886 |  |  | 17.6 |  |  | 5,544 |  |  | 6,801 |  |  | 20.5 |  |
| Total |  |  | $ | 33,376 |  |  | 100.0 | % |  |  |  | $ | 33,146 |  |  | 100.0 | % |
| Liabilities |  |  |  |  |  |  |  |  |  |  |  |
| Thai baht | 2,910,629 |  |  | $ | 84,220 |  |  | 89.9 | % |  | 2,393,112 |  |  | $ | 67,336 |  |  | 84.8 | % |
| RMB | 50,234 |  |  | 7,213 |  |  | 7.7 |  |  | 61,191 |  |  | 9,133 |  |  | 11.5 |  |
| GBP | 1,897 |  |  | 2,287 |  |  | 2.4 |  |  | 2,379 |  |  | 2,918 |  |  | 3.7 |  |
| Total |  |  | $ | 93,720 |  |  | 100.0 | % |  |  |  | $ | 79,387 |  |  | 100.0 | % |

[0001408710-23-000008:mdna:58]
The Thai baht assets represent cash and cash equivalents, trade accounts receivable, deposits and other current assets. The Thai baht liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of December 30, 2022, there was $130.0 million of foreign currency forward contracts outstanding on the Thai baht payables. As of June 24, 2022, there was $135.0 million of foreign currency forward contracts outstanding on the Thai baht payables.

[0001408710-23-000008:mdna:59]
The RMB assets represent cash and cash equivalents, trade accounts receivable and other current assets. The RMB liabilities represent trade accounts payable, accrued expenses, income tax payable and other payables. As of December 30, 2022 and June 24, 2022, we did not have any derivative contracts denominated in RMB.

[0001408710-23-000008:mdna:60]
The GBP assets represent cash, trade accounts receivable, and other current assets. The GBP liabilities represent trade accounts payable and other payables. As of December 30, 2022 and June 24, 2022, we did not have any derivative contracts denominated in GBP.

[0001408710-23-000008:mdna:61]
For the three months ended December 30, 2022 and December 24, 2021, we recorded a gain of $4.2 million and $1.1 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-23-000008:mdna:62]
For the six months ended December 30, 2022 and December 24, 2021, we recorded a gain of $4.0 million and $0.5 million, respectively, related to derivatives that are not designated as hedging instruments in the unaudited condensed consolidated statements of operations and comprehensive income.

[0001408710-23-000008:mdna:63]
[same as prior period, unchanged from 0001408710-22-000060:mdna:62]

[0001408710-23-000008:mdna:64]
[same as prior period, unchanged from 0001408710-22-000060:mdna:63]

[0001408710-23-000008:mdna:65]
[same as prior period, unchanged from 0001408710-22-000060:mdna:64]

[0001408710-23-000008:mdna:66]
[same as prior period, unchanged from 0001408710-22-000060:mdna:65]

[0001408710-23-000008:mdna:67]
[same as prior period, unchanged from 0001408710-22-000060:mdna:66]

[0001408710-23-000008:mdna:68]
[same as prior period, unchanged from 0001408710-22-000060:mdna:67]

[0001408710-23-000008:mdna:69]
Under the Administration Rules, foreign-invested enterprises may only buy, sell, or remit foreign currencies at banks authorized to conduct foreign exchange business after providing valid commercial documents and relevant supporting documents and, in the case of capital account item transactions, obtaining approval from SAFE. Capital investments by foreign-invested enterprises outside of the PRC are also subject to limitations, which include approvals by the Ministry of Commerce, SAFE and the State Development and Reform Commission.

[0001408710-23-000008:mdna:70]
[same as prior period, unchanged from 0001408710-22-000060:mdna:70]

[0001408710-23-000008:mdna:71]
[same as prior period, unchanged from 0001408710-22-000060:mdna:71]

[0001408710-23-000008:mdna:72]
[same as prior period, unchanged from 0001408710-22-000060:mdna:72]

[0001408710-23-000008:mdna:73]
[same as prior period, unchanged from 0001408710-22-000060:mdna:73]

[0001408710-23-000008:mdna:74]
[same as prior period, unchanged from 0001408710-22-000060:mdna:74]

[0001408710-23-000008:mdna:75]
[same as prior period, unchanged from 0001408710-22-000060:mdna:75]

[0001408710-23-000008:mdna:76]
Throughout the period of our operations in Thailand, we have generally received income tax and other incentives from the Thailand Board of Investment. Preferential tax treatment from the Thai government in the form of a corporate tax exemption on income generated from projects to manufacture certain products at our Chonburi campus is currently available to us through June 2026. Similar preferential tax treatment was available to us through June 2020 with respect to products manufactured at our Pinehurst campus Building 6. After June 2020, 50% of our income generated from products manufactured at our Pinehurst campus will be exempted from tax through June 2025. New preferential tax treatment is available to us for products manufactured at our Chonburi campus Building 9, where income generated will be tax exempt through 2031, capped at our actual investment amount. Such preferential tax treatment is contingent on various factors, including the export of our customers’ products out of Thailand and our agreement not to move our manufacturing facilities out of our current province in

[0001408710-23-000008:mdna:77]
Thailand for at least 15 years from the date on which preferential tax treatment was granted. Currently, the corporate income tax rate for our Thai subsidiary is 20%.

[0001408710-23-000008:mdna:78]
[same as prior period, unchanged from 0001408710-22-000060:mdna:77]

[0001408710-23-000008:mdna:79]
[same as prior period, unchanged from 0001408710-22-000060:mdna:78]

[0001408710-23-000008:mdna:80]
We prepare our unaudited condensed consolidated financial statements in conformity with U.S. GAAP, which requires us to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent liabilities on the date of the unaudited condensed consolidated financial statements and the reported amounts of revenues and expenses during the financial reporting period. We continually evaluate these estimates and assumptions based on the most recently available information, our own historical experience and on various other assumptions that we believe to be reasonable under the circumstances, the results form the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Because the use of estimates is an integral component of the financial reporting process, actual results could differ from those estimates. Some of our accounting policies require higher degrees of judgment than others in their application. We consider the policies discussed below to be critical to an understanding of our unaudited condensed consolidated financial statements, as their application places the most significant demands on our management’s judgment.

[0001408710-23-000008:mdna:81]
[same as prior period, unchanged from 0001408710-22-000060:mdna:81]

[0001408710-23-000008:mdna:82]
[same as prior period, unchanged from 0001408710-22-000060:mdna:82]

[0001408710-23-000008:mdna:83]
[same as prior period, unchanged from 0001408710-22-000060:mdna:83]

[0001408710-23-000008:mdna:84]
| (in thousands) | Three Months Ended |  | Six Months Ended |
| December 30,2022 |  | December 24,2021 |  | December 30,2022 |  | December 24,2021 |
| Revenues | $ | 668,656 |  |  | $ | 566,633 |  |  | $ | 1,324,085 |  |  | $ | 1,109,955 |  |
| Cost of revenues | (583,441) |  |  | (497,262) |  |  | (1,156,114) |  |  | (976,987) |  |
| Gross profit | 85,215 |  |  | 69,371 |  |  | 167,971 |  |  | 132,968 |  |
| Selling, general and administrative expenses | (18,930) |  |  | (17,791) |  |  | (39,495) |  |  | (38,378) |  |
| Expenses related to reduction in workforce | — |  |  | (135) |  |  | — |  |  | (135) |  |
| Operating income | 66,285 |  |  | 51,445 |  |  | 128,476 |  |  | 94,455 |  |
| Interest income | 2,334 |  |  | 295 |  |  | 3,893 |  |  | 1,056 |  |
| Interest expense | (389) |  |  | (238) |  |  | (780) |  |  | (274) |  |
| Foreign exchange gain (loss), net | (3,904) |  |  | (364) |  |  | (1,819) |  |  | 1,408 |  |
| Other income (expense), net | (68) |  |  | (1,055) |  |  | (209) |  |  | (1,315) |  |
| Income before income taxes | 64,258 |  |  | 50,083 |  |  | 129,561 |  |  | 95,330 |  |
| Income tax expense | (1,101) |  |  | (1,204) |  |  | (1,789) |  |  | (1,800) |  |
| Net income | 63,157 |  |  | 48,879 |  |  | 127,772 |  |  | 93,530 |  |
| Other comprehensive income (loss), net of tax | 12,344 |  |  | 2,473 |  |  | 10,079 |  |  | 1,077 |  |
| Net comprehensive income | $ | 75,501 |  |  | $ | 51,352 |  |  | $ | 137,851 |  |  | $ | 94,607 |  |

[0001408710-23-000008:mdna:85]
[same as prior period, unchanged from 0001408710-22-000060:mdna:85]

[0001408710-23-000008:mdna:86]
|  | Three Months Ended |  | Six Months Ended |
|  | December 30,2022 |  | December 24,2021 |  | December 30,2022 |  | December 24,2021 |
| Revenues | 100.0 | % |  | 100.0 | % |  | 100.0 | % |  | 100.0 | % |
| Cost of revenues | (87.3) |  |  | (87.8) |  |  | (87.3) |  |  | (88.0) |  |
| Gross profit | 12.7 |  |  | 12.2 |  |  | 12.7 |  |  | 12.0 |  |
| Selling, general and administrative expenses | (2.8) |  |  | (3.1) |  |  | (3.0) |  |  | (3.5) |  |
| Expenses related to reduction in workforce | — |  |  | 0.0 |  |  | — |  |  | 0.0 |  |
| Operating income | 9.9 |  |  | 9.1 |  |  | 9.7 |  |  | 8.5 |  |
| Interest income | 0.4 |  |  | 0.1 |  |  | 0.3 |  |  | 0.1 |  |
| Interest expense | (0.1) |  |  | (0.1) |  |  | (0.1) |  |  | 0.1 |  |
| Foreign exchange gain (loss), net | (0.6) |  |  | (0.1) |  |  | (0.1) |  |  | 0.1 |  |
| Other income (expense), net | 0.0 |  |  | (0.2) |  |  | 0.0 |  |  | (0.2) |  |
| Income before income taxes | 9.6 |  |  | 8.8 |  |  | 9.8 |  |  | 8.6 |  |
| Income tax expense | (0.2) |  |  | (0.2) |  |  | (0.1) |  |  | (0.2) |  |
| Net income | 9.4 |  |  | 8.6 |  |  | 9.7 |  |  | 8.4 |  |
| Other comprehensive income (loss), net of tax | 1.9 |  |  | 0.5 |  |  | 0.7 |  |  | 0.1 |  |
| Net comprehensive income | 11.3 | % |  | 9.1 | % |  | 10.4 | % |  | 8.5 | % |

[0001408710-23-000008:mdna:87]
[same as prior period, unchanged from 0001408710-22-000060:mdna:88]

[0001408710-23-000008:mdna:88]
|  | Three Months Ended |  | Six Months Ended |
| (in thousands) | December 30,2022 |  | December 24,2021 |  | December 30,2022 |  | December 24,2021 |
| Optical communications | $ | 506,056 |  |  | $ | 450,783 |  |  | $ | 1,003,617 |  |  | $ | 878,084 |  |
| Lasers, sensors and other | 162,600 |  |  | 115,850 |  |  | 320,468 |  |  | 231,871 |  |
| Total | $ | 668,656 |  |  | $ | 566,633 |  |  | $ | 1,324,085 |  |  | $ | 1,109,955 |  |

[0001408710-23-000008:mdna:89]
[same as prior period, unchanged from 0001408710-22-000060:mdna:90]

[0001408710-23-000008:mdna:90]
Comparison of Three and Six Months Ended December 30, 2022 with Three and Six Months Ended December 24, 2021

[0001408710-23-000008:mdna:91]
Revenues

[0001408710-23-000008:mdna:92]
Our revenues increased by $102.1 million, or 18.0%, to $668.7 million for the three months ended December 30, 2022, compared with $566.6 million for the three months ended December 24, 2021. This increase was due to an increase in our key customers’ demand during the three months ended December 30, 2022. Revenues from optical communications products increased by $55.3 million, or 12.3%, and revenue from non-optical communications products increased by $46.8 million, or 40.4%, for the three months ended December 30, 2022, compared to the same period in the prior fiscal year.

[0001408710-23-000008:mdna:93]
Our revenues increased by $214.1 million, or 19.3%, to $1,324.1 million for the six months ended December 30, 2022, compared with $1,110.0 million for the six months ended December 24, 2021. This increase was due to (1) an increase in our key customers’ demand during the six months ended December 30, 2022, and (2) the positive impact of an additional week of revenue during the six months ended December 30, 2022. Revenues from optical communications products increased by $125.5 million, or 14.3%, and revenue from non-optical communications products increased by $88.6 million, or 38.2%, for the six months ended December 30, 2022, compared to the same period in the prior fiscal year.

[0001408710-23-000008:mdna:94]
Cost of revenues

[0001408710-23-000008:mdna:95]
Our cost of revenues increased by $86.1 million, or 17.3%, to $583.4 million, or 87.3% of revenues, for the three months ended December 30, 2022, compared with $497.3 million, or 87.8% of revenues, for the three months ended December 24, 2021. This increase in cost of revenues on an absolute dollar basis was in line with the increase in sales volume.

[0001408710-23-000008:mdna:96]
Our cost of revenues increased by $179.1 million, or 18.3%, to $1,156.1 million, or 87.3% of revenues, for the six months ended December 30, 2022, compared with $977.0 million, or 88.0% of revenues, for the six months ended December 24, 2021. This increase in cost of revenues on an absolute dollar basis was in line with the increase in sales volume.

[0001408710-23-000008:mdna:97]
Gross profit

[0001408710-23-000008:mdna:98]
Our gross profit increased by $15.8 million, or 22.8%, to $85.2 million, or 12.7% of revenues, for the three months ended December 30, 2022, compared with $69.4 million, or 12.2% of revenues, for the three months ended December 24, 2021. The increase was primarily due to an increase in sales volume.

[0001408710-23-000008:mdna:99]
Our gross profit increased by $35.0 million, or 26.3%, to $168.0 million, or 12.7% of revenues, for the six months ended December 30, 2022, compared with $133.0 million, or 12.0% of revenues, for the six months ended December 24, 2021. The increase was primarily due to an increase in sales volume.

[0001408710-23-000008:mdna:100]
SG&A expenses

[0001408710-23-000008:mdna:101]
Our SG&A expenses increased by $1.1 million, or 6.2%, to $18.9 million, or 2.8% of revenues, for the three months ended December 30, 2022, compared with $17.8 million, or 3.1% of revenues, for the three months ended December 24, 2021. The increase was primarily due to (1) an increase in executive compensation and benefit of $0.3 million, (2) an increase in legal and consulting fees of $0.3 million, (3) an increase in allowance for doubtful debt of $0.3 million, and (4) an increase in insurance expenses of $0.1 million.

[0001408710-23-000008:mdna:102]
Our SG&A expenses increased by $1.1 million, or 2.9%, to $39.5 million, or 3.0% of revenues, for the six months ended December 30, 2022, compared with $38.4 million, or 3.5% of revenues, for the six months ended December 24, 2021. The increase was primarily due to (1) an increase in executive benefit of $0.5 million, (2) an increase in legal and consulting fees of $0.3 million, and (3) an increase in allowance for doubtful debt of $0.2 million.

[0001408710-23-000008:mdna:103]
Operating income

[0001408710-23-000008:mdna:104]
Our operating income increased by $14.9 million, or 29.0%, to $66.3 million, or 9.9% of revenues, for the three months ended December 30, 2022, compared with $51.4 million, or 9.1% of revenues, for the three months ended December 24, 2021. The increase was primarily due to an increase in revenues.

[0001408710-23-000008:mdna:105]
Our operating income increased by $34.0 million, or 36.0%, to $128.5 million, or 9.7% of revenues, for the six months ended December 30, 2022, compared with $94.5 million, or 8.5% of revenues, for the six months ended December 24, 2021. The increase was primarily due to an increase in revenues.

[0001408710-23-000008:mdna:106]
Interest income

[0001408710-23-000008:mdna:107]
Our interest income increased by $2.0 million, or 666.7%, to $2.3 million, or 0.3% of revenues, for the three months ended December 30, 2022, compared with $0.3 million, or 0.1% of revenues, for the three months ended December 24, 2021. The increase was primarily due to a higher weighted average interest rate during the three months ended December 30, 2022 compared to same period in the prior fiscal year.

[0001408710-23-000008:mdna:108]
Our interest income increased by $2.8 million, or 254.5%, to $3.9 million, or 0.3% of revenues, for the six months ended December 30, 2022, compared with $1.1 million, or 0.1% of revenues, for the six months ended December 24, 2021. The increase was primarily due to a higher weighted average interest rate during the six months ended December 30, 2022 compared to same period in the prior fiscal year.

[0001408710-23-000008:mdna:109]
Interest expense

[0001408710-23-000008:mdna:110]
Our interest expense increased by $0.2 million to $0.4 million for the three months ended December 30, 2022, compared with $0.2 million for the three months ended December 24, 2021. The increase was primarily due to (1) lower interest expense capitalized of $0.1 million following the completion of a new manufacturing building at our Chonburi campus in July 2022, and (2) lower amortization of the fair value of interest rate swaps of $0.1 million during the three months ended December 30, 2022.

[0001408710-23-000008:mdna:111]
Our interest expense increased by $0.5 million to $0.8 million for the six months ended December 30, 2022, compared with $0.3 million for the six months ended December 24, 2021. The increase was primarily due to (1) lower interest expense capitalized of $0.3 million following the completion of a new manufacturing building at our Chonburi campus in July 2022, and (2) lower amortization of the fair value of interest rate swaps of $0.2 million during the six months ended December 30, 2022.

[0001408710-23-000008:mdna:112]
Foreign exchange gain (loss), net

[0001408710-23-000008:mdna:113]
We recorded foreign exchange loss, net of $3.9 million for the three months ended December 30, 2022, compared with foreign exchange loss, net of $0.4 million for the three months ended December 24, 2021. The increase in foreign exchange loss was mainly due to (1) higher unrealized loss from revaluation of outstanding Thai baht assets and liabilities of $5.7 million for the three months ended December 30, 2022, (2) realized loss from payment/receipt of $1.0 million for the three months ended December 30, 2022, and (3) higher unrealized loss from revaluation of currencies other than Thai baht of $0.8 million for the three months ended December 30, 2022, offset by (1) higher unrealized gain from mark-to-market forward contracts of $3.1 million for the three months ended December 30, 2022, and (2) foreign exchange gain, totaling $0.9 million for the three months ended December 30, 2022 from our subsidiaries in the PRC and the U.K.

[0001408710-23-000008:mdna:114]
We recorded foreign exchange loss, net of $1.8 million for the six months ended December 30, 2022, compared with foreign exchange gain, net of $1.4 million for the six months ended December 24, 2021. The increase in foreign exchange loss was mainly due to (1) unrealized loss from revaluation of outstanding Thai baht assets and liabilities of $5.8 million for the six months ended December 30, 2022, (2) lower realized gain from payment/receipt of $0.7 million for the six months ended December 30, 2022, and (3) higher unrealized loss from revaluation of currencies other than Thai baht of $0.5 million for the six months ended December 30, 2022, offset by (1) higher unrealized gain from mark-to-market forward contracts of $3.4 million for the six months ended December 30, 2022, and (2) lower foreign exchange loss, totaling $0.4 million for the six months ended December 30, 2022 from our subsidiaries in the PRC and the U.K.

[0001408710-23-000008:mdna:115]
Income before income taxes

[0001408710-23-000008:mdna:116]
We recorded income before income taxes of $64.3 million for the three months ended December 30, 2022, compared with $50.1 million for the three months ended December 24, 2021.

[0001408710-23-000008:mdna:117]
We recorded income before income taxes of $129.6 million for the six months ended December 30, 2022, compared with $95.3 million for the six months ended December 24, 2021.

[0001408710-23-000008:mdna:118]
Income tax expense

[0001408710-23-000008:mdna:119]
Our provision for income tax reflects effective tax rates of 1.7% and 2.4% for the three months ended December 30, 2022 and December 24, 2021, respectively. The decrease was primarily due to an increase in income not subject to tax during the second quarter of fiscal year 2023 as compared to the same period in fiscal year 2022.

[0001408710-23-000008:mdna:120]
Our provision for income tax reflects effective tax rates of 1.4% and 1.9% for the six months ended December 30, 2022 and December 24, 2021, respectively. The decrease was primarily due to an increase in income not subject to tax during the first half of fiscal year 2023 as compared to the same period in fiscal year 2022.

[0001408710-23-000008:mdna:121]
Net income

[0001408710-23-000008:mdna:122]
We recorded net income of $63.2 million, or 9.4% of revenues, for the three months ended December 30, 2022, compared with $48.9 million, or 8.6% of revenues, for the three months ended December 24, 2021.

[0001408710-23-000008:mdna:123]
We recorded net income of $127.8 million, or 9.7% of revenues, for the six months ended December 30, 2022, compared with $93.5 million, or 8.4% of revenues, for the six months ended December 24, 2021.

[0001408710-23-000008:mdna:124]
Other comprehensive income (loss)

[0001408710-23-000008:mdna:125]
We recorded other comprehensive income of $12.3 million, or 1.9% of revenues, for the three months ended December 30, 2022, compared with other comprehensive income of $2.5 million, or 0.5% of revenues, for the three months ended December 24, 2021. The increase in other comprehensive income was mainly due to (1) higher unrealized gain from mark-to-market of forward contracts and interest rate swap agreement of $7.9 million for the three months ended December 30, 2022, and (2) unrealized gain from mark-to-market of available-for-sale debt securities of $2.1 million for the three months ended December 30, 2022, offset by unrealized loss from foreign currency translation adjustment of $0.1 million for the three months ended December 30, 2022.

[0001408710-23-000008:mdna:126]
We recorded other comprehensive income of $10.1 million, or 0.7% of revenues, for the six months ended December 30, 2022, compared with other comprehensive gain of $1.1 million, or 0.1% of revenues, for the six months ended December 24, 2021. The increase in other comprehensive income was mainly due to (1) higher unrealized gain from mark-to-market of forward contracts and interest rate swap agreement of $7.9 million for the six months ended December 30, 2022, (2) lower unrealized loss from mark-to-market of available-for-sale debt securities of $0.9 million for the six months ended December 30, 2022, and (3) higher unrealized gain from foreign currency translation adjustment of $0.3 million for the six months ended December 30, 2022.

[0001408710-23-000008:mdna:127]
[same as prior period, unchanged from 0001408710-22-000060:mdna:105]

[0001408710-23-000008:mdna:128]
[same as prior period, unchanged from 0001408710-22-000060:mdna:106]

[0001408710-23-000008:mdna:129]
We primarily finance our operations through cash flow from operations. As of December 30, 2022 and December 24, 2021, we had cash, cash equivalents, and short-term investments of $527.6 million and $519.9 million, respectively, and outstanding debt of $18.3 million and $33.5 million, respectively.

[0001408710-23-000008:mdna:130]
Our cash and cash equivalents, which primarily consist of cash on hand, demand deposits, and liquid investments with original maturities of three months or less, are placed with banks and other financial institutions. The weighted-average interest rate on our cash and cash equivalents was 2.0% and 1.8% for the three and six months ended December 30, 2022, respectively, and 0.3% and 0.5% for the three and six months ended December 24, 2021, respectively.

[0001408710-23-000008:mdna:131]
[same as prior period, unchanged from 0001408710-22-000060:mdna:109]

[0001408710-23-000008:mdna:132]
During the six months ended December 30, 2022, we repaid $9.1 million of the term loan under our credit facility agreement with the Bank of Ayudhya Public Company Limited. As a result, as of December 30, 2022, we had a long-term borrowing of $18.3 million under such credit facility agreement (see Note 10 of Notes to Unaudited Condensed Consolidated Financial Statements for further details). We anticipate that our internally generated working capital, along with our cash and cash equivalents will be adequate to repay these obligations. To better manage our cash on hand, we held short-term investments of $276.8 million as of December 30, 2022.

[0001408710-23-000008:mdna:133]
We believe that our current cash and cash equivalents, short-term investments, cash flow from operations, and funds available through our credit facility will be sufficient to meet our working capital and capital expenditure needs for at least the next 12 months. Our ability to sustain our working capital position is subject to a number of risks that we discuss in Part II, Item 1A of this Quarterly Report on Form 10-Q.

[0001408710-23-000008:mdna:134]
[same as prior period, unchanged from 0001408710-22-000060:mdna:112]

[0001408710-23-000008:mdna:135]
[same as prior period, unchanged from 0001408710-22-000060:mdna:113]

[0001408710-23-000008:mdna:136]
|  | Six Months Ended |
| (in thousands) | December 30, 2022 |  | December 24, 2021 |
| Net cash provided by operating activities | $ | 105,100 |  |  | $ | 57,568 |  |
| Net cash used in investing activities | $ | (21,580) |  |  | $ | (53,777) |  |
| Net cash used in financing activities | $ | (31,045) |  |  | $ | (29,773) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | $ | 52,475 |  |  | $ | (25,982) |  |

[0001408710-23-000008:mdna:137]
[same as prior period, unchanged from 0001408710-22-000060:mdna:115]

[0001408710-23-000008:mdna:138]
Cash provided by operating activities is net income adjusted for certain non-cash items and changes in certain assets and liabilities. The increase in cash provided by operating activities during the six months ended December 30, 2022 as compared to the six months ended December 24, 2021 was primarily driven by higher net income and was also affected by cash-favorable working capital changes.

[0001408710-23-000008:mdna:139]
[same as prior period, unchanged from 0001408710-22-000060:mdna:117]

[0001408710-23-000008:mdna:140]
Investing cash flows consist primarily of investment purchases, sales, maturities, and disposals; and capital expenditures. Cash provided by investing activities was higher for the six months ended December 30, 2022 as compared to cash used in investing activities for the six months ended December 24, 2021 primarily due to fewer investment purchases, an increase in proceeds from the sale of short-term investments, and a decrease in capital expenditures, offset by a decrease in proceeds from maturities of short-term investments.

[0001408710-23-000008:mdna:141]
[same as prior period, unchanged from 0001408710-22-000060:mdna:119]

[0001408710-23-000008:mdna:142]
Financing cash flows consist primarily of repayment of long-term debt, share repurchases, and withholding tax related to net share settlement of restricted share units. Cash used in financing activities was higher for the six months ended December 30, 2022 as compared to the six months ended December 24, 2021 primarily due to an increase in the repayment of long-term borrowings due to an additional installment from the additional week in the first quarter of fiscal year 2023 and an increase in cash paid for share repurchases, offset by a decrease in withholding tax related to net share settlement of restricted share units.

[0001408710-23-000008:mdna:143]
[same as prior period, unchanged from 0001408710-22-000060:mdna:121]

[0001408710-23-000008:mdna:144]
[same as prior period, unchanged from 0001408710-22-000060:mdna:122]
